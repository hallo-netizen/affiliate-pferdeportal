<?php
if (!defined('ABSPATH')) { return; }

/** Stable read-only compatibility contract for the editorial-plan compiler. */
final class PSTE_Compiler_Read_Capability {
    public const CONTRACT='PSTE_COMPILER_READ_CAPABILITY_V1';
    public const CAPABILITY_VERSION='1.5.0';
    public const TOPIC_METADATA_SCHEMA='PSTE_COMPILER_TOPIC_METADATA_V4_INTENT_TITLE_KEYWORD_BOUND';
    public const BOUNDED_READER_CONTRACT='PSTE_COMPILER_BOUNDED_READERS_V1';

    /** @return array<string,mixed> */
    public static function describe(): array {
        $required=[
            'PSTE_Plugin::isReady','PSTE_Repository::allCandidates','PSTE_Analytics::priorities',
            'PSTE_Repository::compilerTopicPage','PSTE_Repository::compilerGscCategoryPage','PSTE_Snapshot::compilerInventoryPage',
            'PSTE_Editorializer::RULESET','PSTE_Editorial_Quality_Gate::CONTRACT','PSTE_Intent_Profile::CONTRACT','PSTE_Intent_Profile::targetKeyword',
        ];
        $out=[
            'contract'=>self::CONTRACT,'capability_version'=>self::CAPABILITY_VERSION,
            'topic_metadata_schema'=>self::TOPIC_METADATA_SCHEMA,
            'bounded_reader_contract'=>self::BOUNDED_READER_CONTRACT,
            'bounded_topic_max_records'=>25,'bounded_inventory_max_records'=>25,'bounded_gsc_category_max_records'=>50,
            'engine_schema'=>(string)(defined('PSTE_SCHEMA_VERSION')?PSTE_SCHEMA_VERSION:12),
            'editorial_ruleset'=>(string)PSTE_Editorializer::RULESET,
            'editorial_quality_contract'=>(string)PSTE_Editorial_Quality_Gate::CONTRACT,
            'intent_profile_contract'=>(string)PSTE_Intent_Profile::CONTRACT,
            'target_keyword_contract'=>'PSTE_TARGET_KEYWORD_V1_INTENT_BOUND_PPM_TITLE_COMPATIBLE',
            'intent_first'=>true,
            'intent_metadata_internal_only'=>true,
            'required_read_symbols'=>$required,
            'handoff_fields'=>['title','target_keyword','category','article_type','plan_slot'],
            'content_or_design_payload_allowed'=>false,'write_capability_exposed'=>false,
        ];
        $out['capability_sha256']=self::hash($out);
        return $out;
    }

    public static function validateRuntime(): array {
        $missing=[];
        foreach(['PSTE_Plugin'=>['isReady'],'PSTE_Repository'=>['allCandidates','compilerTopicPage','compilerGscCategoryPage'],'PSTE_Snapshot'=>['compilerInventoryPage'],'PSTE_Analytics'=>['priorities','coverageState','priorityScore','strategicWeight']] as $class=>$methods){
            if(!class_exists($class)){$missing[]=$class;continue;}foreach($methods as $m)if(!method_exists($class,$m))$missing[]=$class.'::'.$m;
        }
        foreach(['PSTE_Editorializer','PSTE_Editorial_Quality_Gate','PSTE_Intent_Profile'] as $class)if(!class_exists($class))$missing[]=$class;
        if(class_exists('PSTE_Editorializer')&&!defined('PSTE_Editorializer::RULESET'))$missing[]='PSTE_Editorializer::RULESET';
        if(class_exists('PSTE_Editorial_Quality_Gate')&&!defined('PSTE_Editorial_Quality_Gate::CONTRACT'))$missing[]='PSTE_Editorial_Quality_Gate::CONTRACT';
        if(class_exists('PSTE_Intent_Profile')&&!defined('PSTE_Intent_Profile::CONTRACT'))$missing[]='PSTE_Intent_Profile::CONTRACT';
        if(class_exists('PSTE_Intent_Profile')&&!method_exists('PSTE_Intent_Profile','targetKeyword'))$missing[]='PSTE_Intent_Profile::targetKeyword';
        if($missing)return ['ok'=>false,'status'=>'PSTE_COMPILER_READ_CAPABILITY_BLOCKED','reason_codes'=>['PSTE_COMPILER_READ_SYMBOL_MISSING'],'missing'=>array_values(array_unique($missing)),'capability'=>[],'write_attempted'=>false];
        try{$d=self::describe();}catch(Throwable $e){return ['ok'=>false,'status'=>'PSTE_COMPILER_READ_CAPABILITY_BLOCKED','reason_codes'=>['PSTE_COMPILER_READ_CAPABILITY_DESCRIBE_FAILED'],'missing'=>[],'capability'=>[],'error_code'=>self::safeCode($e->getMessage()),'write_attempted'=>false];}
        return ['ok'=>true,'status'=>'PSTE_COMPILER_READ_CAPABILITY_PASS','capability'=>$d,'write_attempted'=>false];
    }

    /** @return array<string,mixed> */
    public static function topicPage(?array $cursor=null,int $limit=10): array {
        return PSTE_Repository::compilerTopicPage($cursor,$limit);
    }

    /** @return array<string,mixed> */
    public static function inventoryPage(?array $cursor=null,int $limit=10,?array $structure=null): array {
        return PSTE_Snapshot::compilerInventoryPage($cursor,$limit,$structure);
    }

    /** @return array<string,mixed> */
    public static function gscCategoryPage(string $propertyUrl,int $afterCategoryId=0,int $limit=25): array {
        return PSTE_Repository::compilerGscCategoryPage($propertyUrl,$afterCategoryId,$limit);
    }

    /**
     * Exact projection of PSTE_Analytics::coverage() from bounded aggregate inputs.
     * No scoring rule is changed; this helper only removes the need to rematerialize the
     * complete post/topic domains in one request.
     *
     * @return array<string,mixed> keyed by topic_family_key
     */
    public static function coverageFromAggregates(array $baseline,array $actual,array $planned,array $volumes,array $gscSummary): array {
        $leaf=is_array($baseline)?(array)($baseline['leaf_categories']??[]):[];$categoryToFamily=[];$families=[];
        foreach($leaf as $cat){$id=(int)($cat['term_id']??0);$key=(string)($cat['topic_family_key']??PSTE_Normalizer::categoryFamilyKey((string)($cat['name']??'')));if($id<=0||$key==='')continue;$categoryToFamily[$id]=$key;if(!isset($families[$key]))$families[$key]=['topic_family_key'=>$key,'topic_family_name'=>(string)($cat['topic_family_name']??PSTE_Normalizer::categoryFamilyName((string)($cat['name']??''))),'category_ids'=>[]];$families[$key]['category_ids'][]=$id;}
        $gscFamily=[];foreach($gscSummary as $categoryId=>$row){$key=$categoryToFamily[(int)$categoryId]??'';if($key==='')continue;if(!isset($gscFamily[$key]))$gscFamily[$key]=['impressions'=>0.0,'clicks'=>0.0];$gscFamily[$key]['impressions']+=(float)($row['impressions']??0);$gscFamily[$key]['clicks']+=(float)($row['clicks']??0);}
        $totalImpressions=0.0;$totalVolume=0.0;foreach($families as $key=>$family){$totalImpressions+=(float)($gscFamily[$key]['impressions']??0);$totalVolume+=(float)($volumes[$key]??0);}
        $totalActual=max(1,array_sum(array_map('intval',$actual)));$rows=[];
        foreach($families as $key=>$family){$imp=(float)($gscFamily[$key]['impressions']??0);$vol=(float)($volumes[$key]??0);$hasGsc=$totalImpressions>0&&$imp>0;$hasVolume=$totalVolume>0&&$vol>0;$gscShare=$totalImpressions>0?$imp/$totalImpressions:0.0;$volumeShare=$totalVolume>0?$vol/$totalVolume:0.0;
            if($hasGsc&&$hasVolume)$demandShare=($gscShare*0.60)+($volumeShare*0.40);elseif($hasGsc)$demandShare=$gscShare;elseif($hasVolume)$demandShare=$volumeShare;else $demandShare=0.0;
            $hasData=$hasGsc||$hasVolume;$actualShare=((int)($actual[$key]??0))/$totalActual;$expected=$hasData?max(0.5,$demandShare*$totalActual):null;$coverage=$expected!==null?round((((int)($actual[$key]??0))/$expected)*100,1):null;$representative=(int)($family['category_ids'][0]??0);
            $rows[$key]=['category_id'=>$representative,'category_ids'=>$family['category_ids'],'category_name'=>$family['topic_family_name'],'category_slug'=>$key,'topic_family_key'=>$key,'published'=>(int)($actual[$key]??0),'planned_pass'=>(int)($planned[$key]??0),'gsc_impressions'=>$imp,'gsc_clicks'=>(float)($gscFamily[$key]['clicks']??0),'candidate_volume'=>$vol,'demand_share_pct'=>round($demandShare*100,2),'content_share_pct'=>round($actualShare*100,2),'expected_articles'=>$expected!==null?round($expected,2):null,'coverage_pct'=>$coverage,'state'=>PSTE_Analytics::coverageState($coverage),'strategic_weight'=>PSTE_Analytics::strategicWeight($representative)];
        }
        return $rows;
    }

    /** Exact projection of one PSTE_Analytics::priorities() row. @return array<string,mixed> */
    public static function priorityForCandidate(array $c,array $coverageBy): array {
        $planning=(string)($c['planning_suitability']??'NO');if(!in_array($planning,['YES','PROVISIONAL'],true))return ['eligible'=>false];
        $decision=(string)($c['pool_status']??$c['decision']??'REVIEW_REQUIRED');$categoryId=(int)($c['target_category_id']??0);$familyKey=(string)($c['topic_family_key']??PSTE_Normalizer::categoryFamilyKey((string)($c['target_category_name']??'')));$coverage=$coverageBy[$familyKey]??null;
        $gapScore=10.0;if($coverage&&$coverage['coverage_pct']!==null)$gapScore=min(30.0,max(0.0,(100.0-(float)$coverage['coverage_pct'])*0.3));
        $sources=[];foreach(($c['evidence']??[]) as $e){$s=(string)($e['source']??'');if($s!=='')$sources[$s]=true;}$demandScore=isset($sources['GSC'])?25.0:(isset($sources['PAA'])?22.0:(isset($sources['PAA_RELATED'])?15.0:8.0));
        $volume=max(0,(float)($c['metrics']['search_volume']??0));$volumeScore=$volume>0?min(15.0,(log10(1+$volume)/log10(1001))*15.0):0.0;$strategic=min(10.0,max(0.0,PSTE_Analytics::strategicWeight($categoryId)));$risk=$decision==='PASS'?10.0:3.0;$season=self::seasonalityScore((array)($c['metrics']['monthly_searches']??[]));$readiness=self::readinessScore($c);
        $score=PSTE_Analytics::priorityScore(['coverage_gap'=>$gapScore,'real_demand'=>$demandScore,'search_volume_trend'=>$volumeScore,'strategic_category'=>$strategic,'low_cannibalization_risk'=>$risk,'seasonality'=>$season,'data_readiness'=>$readiness]);
        return ['eligible'=>true,'candidate_id'=>(string)($c['candidate_id']??''),'priority_score'=>$score,'intent'=>(string)($c['metrics']['search_intent']??''),'components'=>['coverage_gap'=>round($gapScore,1),'real_demand'=>round($demandScore,1),'search_volume_trend'=>round($volumeScore,1),'strategic_category'=>round($strategic,1),'low_cannibalization_risk'=>round($risk,1),'seasonality'=>round($season,1),'data_readiness'=>round($readiness,1)]];
    }

    private static function seasonalityScore(array $monthly): float {if(count($monthly)<3)return 2.0;$values=[];foreach($monthly as $m){$v=(float)($m['search_volume']??0);if($v>=0)$values[]=$v;}if(count($values)<3)return 2.0;$latest=$values[0]??0;$avg=array_sum($values)/count($values);return $avg>0&&$latest>$avg*1.2?5.0:2.5;}
    private static function readinessScore(array $c): float {$score=0.0;if(!empty($c['metrics']['search_intent']))$score+=1.5;if(($c['metrics']['search_volume']??null)!==null)$score+=1.0;if(!empty($c['evidence']))$score+=1.0;return min(5.0,$score);}

    private static function safeCode(string $v): string {$v=strtoupper(trim($v));$v=(string)preg_replace('/[^A-Z0-9_:\-]+/','_',$v);return substr($v!==''?$v:'PSTE_COMPILER_CAPABILITY_FAILED',0,160);}

    private static function hash(array $v): string {
        $copy=$v;unset($copy['capability_sha256']);$copy=self::canonicalize($copy);
        $json=function_exists('wp_json_encode')?wp_json_encode($copy,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($copy,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
        if(!is_string($json))throw new RuntimeException('PSTE_COMPILER_CAPABILITY_HASH_FAILED');return hash('sha256',$json);
    }
    private static function canonicalize($v){
        if(!is_array($v))return $v;if($v===[])return [];
        $isList=array_keys($v)===range(0,count($v)-1);if($isList)return array_map([self::class,'canonicalize'],$v);
        ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;
    }
}
