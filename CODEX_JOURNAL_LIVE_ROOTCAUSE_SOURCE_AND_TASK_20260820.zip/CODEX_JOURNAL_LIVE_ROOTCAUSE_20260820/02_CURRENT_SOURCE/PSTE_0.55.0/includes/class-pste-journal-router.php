<?php
if (!defined('ABSPATH')) { return; }

/**
 * Journal extension adapter. It does not decide Journal from a family miss.
 * It consumes only independently verified extension evidence from the signed registry.
 */
final class PSTE_Journal_Router {
    public const CONTRACT='PSTE_JOURNAL_ROUTER_V2_EXPLICIT_EXTENSION_EVIDENCE_ONLY';
    private const TYPE='Journal';

    /** @return array<string,mixed> */
    public static function evaluateAfterFamilyMiss(string $raw,array $baseline,array $registry,array $relevance,array $seoEvidence=[]): array {
        $raw=self::clean($raw);
        $base=['contract'=>self::CONTRACT,'status'=>'NOT_APPLICABLE','ok'=>false,'article_type'=>self::TYPE,'raw_query'=>$raw,'reason_codes'=>[],
            'target_category'=>[],'canonical_plan_category_slug'=>'','family_key'=>'','family_name'=>'','normalization'=>[],'intent_profile'=>[],
            'semantic_consensus'=>[],'title_pipeline'=>[],'title'=>'','target_keyword'=>'','domain_risk'=>[],'runtime_category_resolution'=>[],
            'extension_evidence'=>[],'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'write_attempted'=>false];
        if($raw===''||empty($relevance['ok']))return self::withReasons($base,'NOT_APPLICABLE',['PSTE_JOURNAL_ROUTER_RELEVANCE_REQUIRED']);

        // Critical architecture rule: a failed existing family/type/category decision is never Journal evidence.
        $proof=PSTE_Article_Type_Extension_Registry::verifyEligibility(self::TYPE,$raw,$seoEvidence);$base['extension_evidence']=$proof;
        if(empty($proof['ok']))return self::withReasons($base,'NOT_APPLICABLE',array_merge(['PSTE_JOURNAL_ROUTER_EXPLICIT_SCOPE_AND_INTENT_REQUIRED'],(array)($proof['reason_codes']??[])));

        $risk=PSTE_Domain_Risk_Gate::evaluate($raw,self::TYPE);$base['domain_risk']=$risk;
        if(empty($risk['ok']))return self::withReasons($base,'REVIEW_REQUIRED',array_merge(['PSTE_JOURNAL_ROUTER_DOMAIN_RISK_REVIEW'],(array)($risk['reason_codes']??[])));

        $ext=PSTE_Article_Type_Extension_Registry::extension(self::TYPE);
        $categorySpec=PSTE_Article_Type_Extension_Registry::categoryBySlug($ext,(string)($proof['category_slug']??''));
        if(!$categorySpec)return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_JOURNAL_ROUTER_SIGNED_CATEGORY_BINDING_MISSING']);
        $resolved=self::resolveRuntimeCategory($categorySpec);$base['runtime_category_resolution']=$resolved;
        if(empty($resolved['ok']))return self::withReasons($base,'CATEGORY_UNAVAILABLE',array_merge(['PSTE_JOURNAL_ROUTER_RUNTIME_CATEGORY_NOT_CONFIRMED'],(array)($resolved['reason_codes']??[])));

        $target=['ok'=>true,'term_id'=>(int)$resolved['term_id'],'name'=>(string)$resolved['name'],'slug'=>(string)$resolved['slug'],'taxonomy'=>'category','article_type'=>self::TYPE,'topic_family_name'=>'Pferde','journal_category'=>true];
        $familyKey=hash('sha256','PSTE_JOURNAL_EXPLICIT_SCOPE_V2|'.PSTE_Normalizer::exactTopicIdentityText($raw));$familyName='Pferde';
        $normalization=['contract'=>'PSTE_EDITORIAL_TOPIC_NORMALIZER_V2','raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),'family'=>$familyName,
            'normalized_topic'=>rtrim($raw," ?\t\n\r\0\x0B"),'subject_topic'=>$familyName,'semantic_probe'=>PSTE_Editorial_Topic_Normalizer::semanticProbe($raw),
            'qualifier'=>'','relation'=>'','detected_action'=>'','intent_signals'=>[],'status'=>'PASS','reason_codes'=>['PSTE_JOURNAL_EXPLICIT_SCOPE_MEANING_PRESERVED'],
            'review_flags'=>[],'raw_query_modified'=>false,'write_attempted'=>false];
        $intent=self::intentFromProof($raw,$proof);
        $title=trim((string)($proof['title']??''));$targetKeyword=trim((string)($proof['target_keyword']??''));
        if($title===''||$targetKeyword==='')return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_JOURNAL_ROUTER_EXPLICIT_TITLE_AND_KEYWORD_REQUIRED']);
        $pipeline=PSTE_Title_Pipeline::validateExistingTitle($title,$raw,$familyName,self::TYPE,$registry,$intent,$targetKeyword,(string)$normalization['normalized_topic']);
        $base['title_pipeline']=$pipeline;$base['title']=(string)($pipeline['title']??'');$base['target_keyword']=(string)($pipeline['target_keyword']??'');
        if(empty($pipeline['ok']))return self::withReasons($base,'REVIEW_REQUIRED',array_merge(['PSTE_JOURNAL_ROUTER_EXISTING_TITLE_RULES_NOT_PASS'],self::pipelineReasons($pipeline)));

        $semantic=self::journalConsensus($familyKey,$familyName,$target,$proof);
        $base['target_category']=$target;$base['canonical_plan_category_slug']=(string)($categorySpec['canonical_plan_slug']??'');$base['family_key']=$familyKey;$base['family_name']=$familyName;
        $base['normalization']=$normalization;$base['intent_profile']=$intent;$base['semantic_consensus']=$semantic;
        $base['plan_slot']=(string)($proof['plan_slot']??'');$base['plan_item_key']=(string)($proof['plan_item_key']??'');
        $base['ok']=true;$base['status']='JOURNAL_ROUTE_PASS';$base['reason_codes']=['PSTE_JOURNAL_ROUTER_EXPLICIT_EXTENSION_EVIDENCE_PASS'];
        return $base;
    }

    /** @return array<string,array<string,mixed>> */
    public static function categories(): array {
        $ext=PSTE_Article_Type_Extension_Registry::extension(self::TYPE);$out=[];$i=0;
        foreach((array)($ext['category_policy']['categories']??[]) as $c){$out['category_'.$i++]=(array)$c;}return $out;
    }

    /** @return array<string,mixed> */
    private static function resolveRuntimeCategory(array $spec): array {
        if(!function_exists('get_term_by'))return ['ok'=>false,'status'=>'WORDPRESS_TERM_API_UNAVAILABLE','reason_codes'=>['PSTE_JOURNAL_ROUTER_TERM_API_UNAVAILABLE'],'term_id'=>0,'name'=>'','slug'=>''];
        $matches=[];foreach((array)($spec['runtime_slugs']??[]) as $slug){$term=get_term_by('slug',(string)$slug,'category');if(!$term||(function_exists('is_wp_error')&&is_wp_error($term)))continue;$id=(int)($term->term_id??0);$actualSlug=trim((string)($term->slug??''));$name=trim((string)($term->name??''));if($id>0&&$actualSlug!=='')$matches[$id]=['term_id'=>$id,'name'=>$name,'slug'=>$actualSlug,'taxonomy'=>(string)($term->taxonomy??'category'),'parent'=>(int)($term->parent??0)];}
        if(count($matches)!==1)return ['ok'=>false,'status'=>count($matches)>1?'AMBIGUOUS':'NOT_FOUND','reason_codes'=>[count($matches)>1?'PSTE_JOURNAL_ROUTER_CATEGORY_AMBIGUOUS':'PSTE_JOURNAL_ROUTER_CATEGORY_NOT_FOUND'],'term_id'=>0,'name'=>'','slug'=>''];
        $m=array_values($matches)[0];if((string)$m['taxonomy']!=='category')return ['ok'=>false,'status'=>'TAXONOMY_MISMATCH','reason_codes'=>['PSTE_JOURNAL_ROUTER_CATEGORY_TAXONOMY_MISMATCH'],'term_id'=>0,'name'=>'','slug'=>''];
        $canonical=(string)($spec['canonical_plan_slug']??'');if($canonical!==''&&!in_array((string)$m['slug'],array_values(array_unique(array_filter(array_merge([$canonical],(array)($spec['runtime_slugs']??[]))))),true))return ['ok'=>false,'status'=>'SLUG_MISMATCH','reason_codes'=>['PSTE_JOURNAL_ROUTER_CATEGORY_SLUG_MISMATCH'],'term_id'=>0,'name'=>'','slug'=>''];
        return ['ok'=>true,'status'=>'RESOLVED','reason_codes'=>['PSTE_JOURNAL_ROUTER_CATEGORY_RUNTIME_CONFIRMED'],'term_id'=>(int)$m['term_id'],'name'=>(string)$m['name'],'slug'=>(string)$m['slug'],'taxonomy'=>'category','parent'=>(int)$m['parent']];
    }

    /** @return array<string,mixed> */
    private static function intentFromProof(string $raw,array $proof): array {
        $p=['contract'=>'PSTE_INTENT_PROFILE_V4_EVIDENCE_BOUND','ok'=>true,'status'=>'PASS','search_intent'=>'EDITORIAL_INFORMATION','primary_user_goal'=>'EDITORIAL_INFORMATION','primary_article_type_candidate'=>self::TYPE,
            'intent_angle'=>'EXPLICIT_JOURNAL_SCOPE','evidence_authority'=>(string)($proof['authority_mode']??''),'scope_status'=>(string)($proof['scope_status']??''),'intent_status'=>(string)($proof['intent_status']??''),'raw_query_sha256'=>hash('sha256',$raw),'write_attempted'=>false];
        $p['profile_sha256']=hash('sha256',self::stable($p));return $p;
    }
    /** @return array<string,mixed> */
    private static function journalConsensus(string $familyKey,string $familyName,array $target,array $proof): array {return ['contract'=>'PSTE_JOURNAL_ROUTING_CONSENSUS_V1','status'=>'CONSENSUS_PASS','ok'=>true,'type_consensus'=>true,'category_consensus'=>true,'family_consensus'=>true,'resolved_article_type'=>self::TYPE,'resolved_category'=>$target,'journal_family_key'=>$familyKey,'journal_family_name'=>$familyName,'canonical_plan_category_slug'=>(string)($proof['category_slug']??''),'selection_policy'=>'EXPLICIT_JOURNAL_SCOPE_AND_INTENT_ONLY','extension_evidence_sha256'=>hash('sha256',self::stable($proof)),'other_article_type_routing_consumed'=>false,'write_attempted'=>false,'reason_codes'=>['PSTE_JOURNAL_EXPLICIT_SCOPE_CONSENSUS_PASS']];}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');return trim((string)preg_replace('/\s+/u',' ',$v));}
    /** @return list<string> */
    private static function pipelineReasons(array $p): array {return array_values(array_unique(array_filter(array_merge((array)($p['deterministic']['reason_codes']??[]),(array)($p['language']['reason_codes']??[]),(array)($p['editorial_quality']['reason_codes']??[])))));}
    /** @return array<string,mixed> */
    private static function withReasons(array $base,string $status,array $reasons): array {$base['status']=$status;$base['ok']=$status==='JOURNAL_ROUTE_PASS';$base['reason_codes']=array_values(array_unique(array_filter(array_map('strval',$reasons))));return $base;}
    private static function stable($value): string {$value=self::canon($value);$json=function_exists('wp_json_encode')?wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($json)?$json:'';}
    private static function canon($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canon'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canon($x);return $v;}
}
