<?php
if (!defined('ABSPATH')) { return; }

/**
 * Generic read-only router for signed additive article-type extensions.
 * A core miss is only the point at which extensions may be asked; it is never evidence.
 */
final class PSTE_Article_Type_Extension_Router {
    public const CONTRACT='PSTE_ARTICLE_TYPE_EXTENSION_ROUTE_V1';

    /** @return array<string,mixed> */
    public static function evaluateAfterCoreMiss(string $raw,array $baseline,array $registry,array $relevance,array $seoEvidence=[]): array {
        $base=['contract'=>self::CONTRACT,'status'=>'NOT_APPLICABLE','ok'=>false,'article_type'=>'','raw_query'=>self::clean($raw),'reason_codes'=>[],
            'target_category'=>[],'canonical_plan_category_slug'=>'','family_key'=>'','family_name'=>'','normalization'=>[],'intent_profile'=>[],
            'semantic_consensus'=>[],'title_pipeline'=>[],'title'=>'','target_keyword'=>'','domain_risk'=>[],'runtime_category_resolution'=>[],
            'extension_evidence'=>[],'manifest_sha256'=>'','plan_slot'=>'','plan_item_key'=>'','five_field_handoff_created'=>false,
            'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'write_attempted'=>false];
        if($base['raw_query']===''||empty($relevance['ok']))return self::withReasons($base,'NOT_APPLICABLE',['PSTE_EXTENSION_ROUTER_RELEVANCE_REQUIRED']);
        $verified=PSTE_Article_Type_Extension_Registry::verifiedManifest();if(empty($verified['ok']))return self::withReasons($base,'REVIEW_REQUIRED',(array)($verified['reason_codes']??['PSTE_EXTENSION_MANIFEST_NOT_VERIFIED']));
        $base['manifest_sha256']=(string)($verified['manifest_sha256']??'');
        $matches=[];$reviews=[];
        foreach((array)($verified['manifest']['extensions']??[]) as $id=>$ext){
            $type=(string)($ext['display_name']??$ext['article_type_id']??$id);
            $proof=PSTE_Article_Type_Extension_Registry::verifyEligibility($type,$base['raw_query'],$seoEvidence);
            if(empty($proof['ok']))continue;
            $route=self::routeOne($type,(array)$ext,$base['raw_query'],$registry,$proof);
            if(!empty($route['ok']))$matches[]=$route;elseif(($route['status']??'')!=='NOT_APPLICABLE')$reviews[]=$route;
        }
        if(count($matches)>1)return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_EXTENSION_ROUTER_AMBIGUOUS_MULTIPLE_EXTENSION_MATCHES']);
        if(count($matches)===1)return $matches[0];
        if($reviews){$r=$reviews[0];$r['reason_codes']=array_values(array_unique(array_merge(['PSTE_EXTENSION_ROUTER_PROVEN_EXTENSION_REQUIRES_REVIEW'],(array)($r['reason_codes']??[]))));return $r;}
        return self::withReasons($base,'NOT_APPLICABLE',['PSTE_EXTENSION_ROUTER_NO_EXPLICIT_EXTENSION_EVIDENCE']);
    }

    /** @return array<string,mixed> */
    private static function routeOne(string $type,array $ext,string $raw,array $registry,array $proof): array {
        $base=['contract'=>self::CONTRACT,'status'=>'REVIEW_REQUIRED','ok'=>false,'article_type'=>$type,'raw_query'=>$raw,'reason_codes'=>[],
            'target_category'=>[],'canonical_plan_category_slug'=>'','family_key'=>'','family_name'=>'','normalization'=>[],'intent_profile'=>[],
            'semantic_consensus'=>[],'title_pipeline'=>[],'title'=>'','target_keyword'=>'','domain_risk'=>[],'runtime_category_resolution'=>[],
            'extension_evidence'=>$proof,'manifest_sha256'=>(string)($proof['manifest_sha256']??''),'plan_slot'=>(string)($proof['plan_slot']??''),'plan_item_key'=>(string)($proof['plan_item_key']??''),
            'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'write_attempted'=>false];
        $risk=PSTE_Domain_Risk_Gate::evaluate($raw,$type);$base['domain_risk']=$risk;if(empty($risk['ok']))return self::withReasons($base,'REVIEW_REQUIRED',array_merge(['PSTE_EXTENSION_ROUTER_DOMAIN_RISK_REVIEW'],(array)($risk['reason_codes']??[])));
        $categorySpec=PSTE_Article_Type_Extension_Registry::categoryBySlug($ext,(string)($proof['category_slug']??''));if(!$categorySpec)return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_EXTENSION_ROUTER_SIGNED_CATEGORY_BINDING_MISSING']);
        $resolved=self::resolveRuntimeCategory($categorySpec);$base['runtime_category_resolution']=$resolved;if(empty($resolved['ok']))return self::withReasons($base,'CATEGORY_UNAVAILABLE',array_merge(['PSTE_EXTENSION_ROUTER_RUNTIME_CATEGORY_NOT_CONFIRMED'],(array)($resolved['reason_codes']??[])));
        $target=['ok'=>true,'term_id'=>(int)$resolved['term_id'],'name'=>(string)$resolved['name'],'slug'=>(string)$resolved['slug'],'taxonomy'=>'category','article_type'=>$type,'article_type_extension'=>true];
        $familyName=trim((string)($ext['scope_family_name']??'Pferde'));$familyKey=hash('sha256','PSTE_EXTENSION_EXPLICIT_SCOPE_V1|'.self::norm($type).'|'.PSTE_Normalizer::exactTopicIdentityText($raw));
        $normalization=['contract'=>'PSTE_EDITORIAL_TOPIC_NORMALIZER_V2','raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),'family'=>$familyName,'normalized_topic'=>rtrim($raw," ?\t\n\r\0\x0B"),'subject_topic'=>$familyName,'semantic_probe'=>PSTE_Editorial_Topic_Normalizer::semanticProbe($raw),'qualifier'=>'','relation'=>'','detected_action'=>'','intent_signals'=>[],'status'=>'PASS','reason_codes'=>['PSTE_EXTENSION_EXPLICIT_SCOPE_MEANING_PRESERVED'],'review_flags'=>[],'raw_query_modified'=>false,'write_attempted'=>false];
        $intent=self::intentFromProof($raw,$proof,$type);$title=trim((string)($proof['title']??''));$keyword=trim((string)($proof['target_keyword']??''));if($title===''||$keyword==='')return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_EXTENSION_ROUTER_EXPLICIT_TITLE_AND_KEYWORD_REQUIRED']);
        $pipeline=PSTE_Title_Pipeline::validateExistingTitle($title,$raw,$familyName,$type,$registry,$intent,$keyword,(string)$normalization['normalized_topic']);$base['title_pipeline']=$pipeline;$base['title']=(string)($pipeline['title']??'');$base['target_keyword']=(string)($pipeline['target_keyword']??'');if(empty($pipeline['ok']))return self::withReasons($base,'REVIEW_REQUIRED',array_merge(['PSTE_EXTENSION_ROUTER_EXISTING_TITLE_RULES_NOT_PASS'],self::pipelineReasons($pipeline)));
        $semantic=['contract'=>'PSTE_ARTICLE_TYPE_EXTENSION_CONSENSUS_V1','status'=>'CONSENSUS_PASS','ok'=>true,'type_consensus'=>true,'category_consensus'=>true,'family_consensus'=>true,'resolved_article_type'=>$type,'resolved_category'=>$target,'extension_family_key'=>$familyKey,'extension_family_name'=>$familyName,'canonical_plan_category_slug'=>(string)($categorySpec['canonical_plan_slug']??''),'selection_policy'=>(string)($ext['activation_policy']??''),'extension_evidence_sha256'=>hash('sha256',self::stable($proof)),'other_article_type_routing_consumed'=>false,'write_attempted'=>false,'reason_codes'=>['PSTE_EXTENSION_EXPLICIT_SCOPE_CONSENSUS_PASS']];
        $base['target_category']=$target;$base['canonical_plan_category_slug']=(string)($categorySpec['canonical_plan_slug']??'');$base['family_key']=$familyKey;$base['family_name']=$familyName;$base['normalization']=$normalization;$base['intent_profile']=$intent;$base['semantic_consensus']=$semantic;$base['ok']=true;$base['status']='EXTENSION_ROUTE_PASS';$base['reason_codes']=['PSTE_EXTENSION_ROUTER_EXPLICIT_EVIDENCE_PASS'];return $base;
    }

    /** @return array<string,mixed> */
    private static function resolveRuntimeCategory(array $spec): array {
        if(!function_exists('get_term_by'))return ['ok'=>false,'status'=>'WORDPRESS_TERM_API_UNAVAILABLE','reason_codes'=>['PSTE_EXTENSION_ROUTER_TERM_API_UNAVAILABLE'],'term_id'=>0,'name'=>'','slug'=>''];
        $matches=[];foreach((array)($spec['runtime_slugs']??[]) as $slug){$term=get_term_by('slug',(string)$slug,'category');if(!$term||(function_exists('is_wp_error')&&is_wp_error($term)))continue;$id=(int)($term->term_id??0);$actual=trim((string)($term->slug??''));if($id>0&&$actual!=='')$matches[$id]=['term_id'=>$id,'name'=>trim((string)($term->name??'')),'slug'=>$actual,'taxonomy'=>(string)($term->taxonomy??'category'),'parent'=>(int)($term->parent??0)];}
        if(count($matches)!==1)return ['ok'=>false,'status'=>count($matches)>1?'AMBIGUOUS':'NOT_FOUND','reason_codes'=>[count($matches)>1?'PSTE_EXTENSION_ROUTER_CATEGORY_AMBIGUOUS':'PSTE_EXTENSION_ROUTER_CATEGORY_NOT_FOUND'],'term_id'=>0,'name'=>'','slug'=>''];
        $m=array_values($matches)[0];if((string)$m['taxonomy']!=='category')return ['ok'=>false,'status'=>'TAXONOMY_MISMATCH','reason_codes'=>['PSTE_EXTENSION_ROUTER_CATEGORY_TAXONOMY_MISMATCH'],'term_id'=>0,'name'=>'','slug'=>''];return ['ok'=>true,'status'=>'RESOLVED','reason_codes'=>['PSTE_EXTENSION_ROUTER_CATEGORY_RUNTIME_CONFIRMED']]+$m;
    }
    private static function intentFromProof(string $raw,array $proof,string $type): array {$p=['contract'=>'PSTE_INTENT_PROFILE_V4_EVIDENCE_BOUND','ok'=>true,'status'=>'PASS','search_intent'=>'EDITORIAL_INFORMATION','primary_user_goal'=>'EDITORIAL_INFORMATION','primary_article_type_candidate'=>$type,'intent_angle'=>'EXPLICIT_ARTICLE_TYPE_EXTENSION_SCOPE','evidence_authority'=>(string)($proof['authority_mode']??''),'scope_status'=>(string)($proof['scope_status']??''),'intent_status'=>(string)($proof['intent_status']??''),'raw_query_sha256'=>hash('sha256',$raw),'write_attempted'=>false];$p['profile_sha256']=hash('sha256',self::stable($p));return $p;}
    private static function withReasons(array $base,string $status,array $r): array {$base['status']=$status;$base['ok']=$status==='EXTENSION_ROUTE_PASS';$base['reason_codes']=array_values(array_unique(array_filter(array_map('strval',$r))));return $base;}
    private static function pipelineReasons(array $p): array {return array_values(array_unique(array_filter(array_merge((array)($p['deterministic']['reason_codes']??[]),(array)($p['language']['reason_codes']??[]),(array)($p['editorial_quality']['reason_codes']??[])))));}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');return trim((string)preg_replace('/\s+/u',' ',$v));}
    private static function norm(string $v): string {$v=function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);$v=strtr($v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);return trim((string)preg_replace('/[^a-z0-9]+/u','',$v));}
    private static function stable($v): string {$v=self::canon($v);$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($j)?$j:'';}
    private static function canon($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canon'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canon($x);return $v;}
}
