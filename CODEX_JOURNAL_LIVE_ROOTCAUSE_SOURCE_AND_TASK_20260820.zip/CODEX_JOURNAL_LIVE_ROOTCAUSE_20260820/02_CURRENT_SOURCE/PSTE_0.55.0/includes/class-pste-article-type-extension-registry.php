<?php
if (!defined('ABSPATH')) { return; }

/**
 * Signed, declarative extension registry. It has no domain/routing authority.
 * Existing article types remain owned by the unchanged core registry; only additive extensions use this contract.
 */
final class PSTE_Article_Type_Extension_Registry {
    public const CONTRACT='ARTICLE_TYPE_EXTENSION_MANIFEST_V1';
    public const EVIDENCE_CONTRACT='ARTICLE_TYPE_EXTENSION_EVIDENCE_V1';
    private const MANIFEST='contracts/article-type-extension-manifest-v1.json';
    private const SIGNATURE='contracts/article-type-extension-manifest-v1.sig';
    private const PUBLIC_KEY_B64='3ivO6TMox5vRbBRq4GvBYP3f0M1raWpEXtW7WI9H+nk=';
    private static ?array $cache=null;

    /** @return array<string,mixed> */
    public static function verifiedManifest(): array {
        if(self::$cache!==null)return self::$cache;
        $path=PSTE_DIR.self::MANIFEST;$sigPath=PSTE_DIR.self::SIGNATURE;
        $base=['ok'=>false,'status'=>'BLOCKED_EXTENSION_MANIFEST','reason_codes'=>[],'manifest'=>[],'manifest_sha256'=>'','write_attempted'=>false];
        if(!is_file($path)||!is_file($sigPath))return self::$cache=self::fail($base,'PSTE_EXTENSION_MANIFEST_MISSING');
        $bytes=(string)file_get_contents($path);$manifest=json_decode($bytes,true);
        if(!is_array($manifest)||($manifest['contract']??'')!==self::CONTRACT)return self::$cache=self::fail($base,'PSTE_EXTENSION_MANIFEST_INVALID');
        if(!function_exists('sodium_crypto_sign_verify_detached'))return self::$cache=self::fail($base,'PSTE_EXTENSION_SIGNATURE_RUNTIME_UNAVAILABLE');
        $sig=base64_decode(trim((string)file_get_contents($sigPath)),true);$pub=base64_decode(self::PUBLIC_KEY_B64,true);
        if(!is_string($sig)||!is_string($pub)||!sodium_crypto_sign_verify_detached($sig,$bytes,$pub))return self::$cache=self::fail($base,'PSTE_EXTENSION_SIGNATURE_INVALID');
        if(($manifest['status']??'')!=='SIGNED_ACTIVE'||($manifest['selection_policy']??'')!=='EXPLICIT_SCOPE_AND_INTENT_ONLY_NO_FALLBACK')return self::$cache=self::fail($base,'PSTE_EXTENSION_MANIFEST_POLICY_INVALID');
        $base['ok']=true;$base['status']='PASS';$base['manifest']=$manifest;$base['manifest_sha256']=hash('sha256',$bytes);return self::$cache=$base;
    }

    /** @return array<string,mixed> */
    public static function extension(string $type): array {
        $v=self::verifiedManifest();if(empty($v['ok']))return [];
        $canon=self::norm($type);foreach((array)($v['manifest']['extensions']??[]) as $id=>$ext){$aliases=array_map([self::class,'norm'],(array)($ext['aliases']??[]));$aliases[]=self::norm((string)$id);$aliases[]=self::norm((string)($ext['article_type_id']??''));if(in_array($canon,$aliases,true))return (array)$ext;}return [];
    }

    /**
     * Independent proof verifier. It never selects Journal from a family miss.
     * It accepts only signed immutable gold bindings or an externally produced explicit scope+intent envelope.
     * @return array<string,mixed>
     */
    public static function verifyEligibility(string $type,string $raw,array $evidenceSource=[]): array {
        $base=['contract'=>self::EVIDENCE_CONTRACT,'ok'=>false,'status'=>'NOT_PROVEN','article_type'=>$type,'scope_status'=>'UNPROVEN','intent_status'=>'UNPROVEN','authority_mode'=>'','title'=>'','target_keyword'=>'','category_name'=>'','category_slug'=>'','plan_slot'=>'','plan_item_key'=>'','reason_codes'=>[],'manifest_sha256'=>'','write_attempted'=>false];
        $v=self::verifiedManifest();if(empty($v['ok']))return self::fail($base,'PSTE_EXTENSION_MANIFEST_NOT_VERIFIED');$base['manifest_sha256']=(string)$v['manifest_sha256'];
        $ext=self::extension($type);if(!$ext)return self::fail($base,'PSTE_EXTENSION_TYPE_NOT_REGISTERED');
        if(trim((string)($ext['activation_policy']??''))===''||($ext['fallback_activation_allowed']??true)!==false||($ext['self_generated_intent_allowed']??true)!==false)return self::fail($base,'PSTE_EXTENSION_ACTIVATION_POLICY_INVALID');
        $needle=self::identity($raw);
        foreach((array)($ext['gold_bindings']??[]) as $binding){
            $kw=self::identity((string)($binding['target_keyword']??''));$title=self::identity((string)($binding['title']??''));
            if($needle!==''&&($needle===$kw||$needle===$title)){
                $base['ok']=true;$base['status']='PROVEN';$base['scope_status']='PROVEN';$base['intent_status']='PROVEN';$base['authority_mode']='SIGNED_GOLD_BINDING';
                foreach(['title','target_keyword','category_name','category_slug','plan_slot','plan_item_key','binding_sha256'] as $f)$base[$f]=(string)($binding[$f]??'');
                $base['reason_codes']=['PSTE_EXTENSION_SIGNED_GOLD_SCOPE_AND_INTENT_PROVEN'];return $base;
            }
        }
        $ev=is_array($evidenceSource['article_type_extension_evidence']??null)?(array)$evidenceSource['article_type_extension_evidence']:[];
        if(!$ev||($ev['contract']??'')!==self::EVIDENCE_CONTRACT)return self::fail($base,'PSTE_EXTENSION_EXPLICIT_EVIDENCE_MISSING');
        if(self::norm((string)($ev['article_type']??''))!==self::norm($type))return self::fail($base,'PSTE_EXTENSION_EVIDENCE_TYPE_MISMATCH');
        if(($ev['scope_status']??'')!=='PROVEN'||($ev['intent_status']??'')!=='PROVEN')return self::fail($base,'PSTE_EXTENSION_SCOPE_OR_INTENT_NOT_PROVEN');
        $authority=trim((string)($ev['evidence_authority']??''));if($authority===''||str_contains(self::norm($authority),'router'))return self::fail($base,'PSTE_EXTENSION_EVIDENCE_AUTHORITY_NOT_INDEPENDENT');
        $boundRaw=self::identity((string)($ev['raw_query']??''));if($boundRaw===''||$boundRaw!==$needle)return self::fail($base,'PSTE_EXTENSION_EVIDENCE_QUERY_BINDING_MISMATCH');
        $title=trim((string)($ev['title']??''));$kw=trim((string)($ev['target_keyword']??''));$slug=trim((string)($ev['category_slug']??''));if($title===''||$kw===''||$slug==='')return self::fail($base,'PSTE_EXTENSION_EVIDENCE_EXACT_FIVE_PREBINDING_INCOMPLETE');
        $category=self::categoryBySlug($ext,$slug);if(!$category)return self::fail($base,'PSTE_EXTENSION_EVIDENCE_CATEGORY_NOT_REGISTERED');
        $hashClaim=trim((string)($ev['evidence_sha256']??''));$hashInput=['contract'=>self::EVIDENCE_CONTRACT,'article_type'=>(string)$ev['article_type'],'raw_query'=>(string)$ev['raw_query'],'scope_status'=>(string)$ev['scope_status'],'intent_status'=>(string)$ev['intent_status'],'evidence_authority'=>$authority,'title'=>$title,'target_keyword'=>$kw,'category_slug'=>$slug,'plan_slot'=>(string)($ev['plan_slot']??'')];
        $actual=hash('sha256',self::stable($hashInput));if($hashClaim===''||!hash_equals($actual,$hashClaim))return self::fail($base,'PSTE_EXTENSION_EVIDENCE_HASH_MISMATCH');
        $base['ok']=true;$base['status']='PROVEN';$base['scope_status']='PROVEN';$base['intent_status']='PROVEN';$base['authority_mode']='EXTERNAL_EXPLICIT_SCOPE';$base['title']=$title;$base['target_keyword']=$kw;$base['category_name']=(string)$category['name'];$base['category_slug']=(string)$category['canonical_plan_slug'];$base['plan_slot']=(string)($ev['plan_slot']??'');$base['reason_codes']=['PSTE_EXTENSION_EXTERNAL_SCOPE_AND_INTENT_PROVEN'];return $base;
    }

    /** @return array<string,mixed> */
    public static function categoryBySlug(array $ext,string $slug): array {foreach((array)($ext['category_policy']['categories']??[]) as $c){$slugs=array_values(array_unique(array_filter(array_merge([(string)($c['canonical_plan_slug']??'')],array_map('strval',(array)($c['runtime_slugs']??[]))))));if(in_array($slug,$slugs,true))return (array)$c;}return [];}
    private static function fail(array $base,string $reason): array {$base['reason_codes']=array_values(array_unique(array_merge((array)($base['reason_codes']??[]),[$reason])));return $base;}
    private static function identity(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');$v=self::norm((string)preg_replace('/[^\p{L}\p{N}\s]+/u',' ',$v));return trim((string)preg_replace('/\s+/u',' ',$v));}
    private static function norm(string $v): string {$v=function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);$v=strtr($v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);return trim((string)preg_replace('/[^a-z0-9]+/u','',$v));}
    private static function stable($v): string {if(is_array($v)){if(array_keys($v)===range(0,count($v)-1)){$v=array_map([self::class,'stableValue'],$v);}else{ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::stableValue($x);}}$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($j)?$j:'';}
    private static function stableValue($v){if(!is_array($v))return $v;if($v===[])return [];if(array_keys($v)===range(0,count($v)-1))return array_map([self::class,'stableValue'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::stableValue($x);return $v;}
}
