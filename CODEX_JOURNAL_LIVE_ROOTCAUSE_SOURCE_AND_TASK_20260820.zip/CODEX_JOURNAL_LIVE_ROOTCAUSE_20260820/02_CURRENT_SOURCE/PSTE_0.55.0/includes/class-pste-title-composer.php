<?php
if (!defined('ABSPATH')) { return; }

/**
 * Intent-aware metadata-only planning-title composer.
 * SEO intent/focus is already bound before this class is called.
 * No article content, prompt, outline, fact, link, HTML, formatting or design instruction is generated.
 *
 * Hard rule: never add semantically empty filler merely to make a title look editorial.
 * The target keyword must remain a contiguous, meaning-preserving phrase somewhere in the final title.
 * Position 1 is not mandatory. Additional wording is allowed only when it expresses the already-bound
 * article type and remains grammatically simple.
 */
final class PSTE_Title_Composer {
    public const CONTRACT='PSTE_TITLE_COMPOSER_V11_SINGLE_TITLE_AUTHORITY_BERATUNG_VARIATION';

    public static function compose(string $source,string $family,string $type,array $portalContextTerms=[],array $intentProfile=[],string $targetKeyword=''): string {
        $source=self::clean($source);$family=self::clean($family);if($source===''||$family==='')return '';
        $canon=PSTE_Article_Type_Registry::canonicalType($type);
        if($canon==='journal'){
            // Journal is extension-evidence only. The generic composer must never turn a raw search
            // phrase into an approved Journal title. A separately bound title is validated through
            // PSTE_Title_Pipeline::validateExistingTitle() by the explicit extension router.
            return '';
        }
        $normalized=PSTE_Editorial_Topic_Normalizer::normalize($source,$family,$portalContextTerms);
        $subject=self::titleSurface((string)($normalized['subject_topic']??''),false);if($subject==='')return '';
        $targetKeyword=self::titleSurface($targetKeyword,false);if($targetKeyword==='')$targetKeyword=$subject;
        if(($normalized['status']??'')!=='PASS'&&!PSTE_Normalizer::isQuestion($source))return '';
        $action=self::titleSurface((string)($normalized['detected_action']??''),false);
        $angle=trim((string)($intentProfile['intent_angle']??''));
        $base=$targetKeyword;
        $title='';

        if($canon==='faq'){
            // FAQ target keyword is the canonical question without punctuation; only the terminal question mark is added.
            $title=$base.'?';
        }elseif($canon==='beratung'){
            // Beratung is decision support. The exact target keyword remains contiguous. Only the
            // already-bound Beratung surface is varied deterministically to prevent one repeated
            // generic title schema across the portal. Intent, keyword, category and slot stay unchanged.
            $title=self::hasTypeIntent($base,$canon)?$base:self::beratungFallback($base);
        }elseif($canon==='vergleich'){
            $title=preg_match('/\b(vergleich\w*|gegenüberstell\w*|gegenueberstell\w*)\b/iu',$base)?$base:$base.' im Vergleich';
        }elseif($canon==='pflege'){
            // Procedural action is already part of the target keyword. If the phrase is short,
            // add a natural procedural lead while keeping the exact keyword contiguous.
            $title=$base;
            if(self::wordCount($title)<3)$title='Schritt für Schritt '.$base;
        }elseif($canon==='kosten'){
            $title=$base;
        }elseif($canon==='sicherheit'){
            $title=self::hasTypeIntent($base,$canon)?$base:$base.' Gefahren erkennen und vermeiden';
        }elseif($canon==='installation'){
            $verb=$action!==''?$action:'installieren';$title=preg_match('/\b'.preg_quote($verb,'/').'\w*\b/iu',$base)?$base:$base.' richtig '.$verb;
        }elseif($canon==='anwendung'){
            $verb=$action!==''?$action:'anwenden';$title=preg_match('/\b'.preg_quote($verb,'/').'\w*\b/iu',$base)?$base:$base.' richtig '.$verb;
        }elseif($canon==='lagerung'){
            $verb=$action!==''?$action:'lagern';$title=preg_match('/\b'.preg_quote($verb,'/').'\w*\b/iu',$base)?$base:$base.' richtig '.$verb;
        }elseif($canon==='uebungen'){
            $title=self::hasTypeIntent($base,$canon)?$base:$base.' Übungen für das Training';
        }else return '';

        $title=self::capitalize(self::titleSurface($title,$canon==='faq'));
        if($title===''||!self::containsKeyword($title,$targetKeyword))return '';
        return $title;
    }

    /** Deterministic wording variation for the one existing Beratung fallback rule only. */
    private static function beratungFallback(string $base): string {
        $variants=[
            $base.' gezielt auswählen',
            $base.' passend auswählen',
            $base.' nach wichtigen Kriterien auswählen',
            $base.' anhand wichtiger Kriterien auswählen',
        ];
        $raw=hash('sha256',self::lower($base),true);$index=ord($raw[0])%count($variants);
        return $variants[$index];
    }

    /** All punctuation/special separators are removed. Only a single terminal ? survives for FAQ. */
    private static function titleSurface(string $v,bool $question): string {
        $v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');
        $v=(string)preg_replace('/[^\p{L}\p{N}\s?]+/u',' ',$v);
        $v=str_replace('?',' ',$v);$v=trim((string)preg_replace('/\s+/u',' ',$v));
        if($v==='')return '';
        return $v.($question?'?':'');
    }

    private static function hasTypeIntent(string $title,string $canon): bool {
        if($canon==='faq')return str_ends_with(trim($title),'?');
        if(!class_exists('PSTE_Article_Type_Intent_Ontology'))return false;
        foreach(PSTE_Article_Type_Intent_Ontology::strongSignals($title) as $type){
            if(PSTE_Article_Type_Registry::canonicalType((string)$type)===$canon)return true;
        }
        return false;
    }

    private static function containsKeyword(string $title,string $keyword): bool {
        $title=trim(rtrim($title,'?'));$keyword=trim($keyword);if($title===''||$keyword==='')return false;
        $t=self::lower($title);$k=self::lower($keyword);return function_exists('mb_strpos')?mb_strpos($t,$k,0,'UTF-8')!==false:strpos($t,$k)!==false;
    }
    private static function wordCount(string $v): int {return count(array_values(array_filter(preg_split('/\s+/u',trim(rtrim($v,'?')))?:[])));}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');$v=trim((string)preg_replace('/\s+/u',' ',$v));return trim($v);}
    private static function capitalize(string $v): string {if($v==='')return '';$f=function_exists('mb_substr')?mb_substr($v,0,1,'UTF-8'):substr($v,0,1);$r=function_exists('mb_substr')?mb_substr($v,1,null,'UTF-8'):substr($v,1);$f=function_exists('mb_strtoupper')?mb_strtoupper($f,'UTF-8'):strtoupper($f);return $f.$r;}
    private static function lower(string $v): string{return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
}
