# 0.55.0 – Signed additive article-type extension architecture rootfix

- Consumes the shared signed `ARTICLE_TYPE_EXTENSION_MANIFEST_V1`.
- Replaces family-miss Journal fallback with a generic additive extension point; a core miss is never evidence.
- Requires independent extension scope + intent evidence; self-generated router evidence is fail-closed.
- Applies the existing title-quality path to Journal and adds Journal-only strict raw keyword-chain rejection without changing non-Journal output.
- Keeps request-bounded context/sandbox/redaction-plan infrastructure from 0.54.0 unchanged.
- Separates extension-registry fingerprinting from legacy article-type/family identity so `+1` extension does not globally invalidate unrelated records.
