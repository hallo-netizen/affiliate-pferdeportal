# PSTE 0.54.0

Technischer Compiler-Lesecapability-Rootfix: bounded Topic- und Inventory-Reader fuer den asynchronen Redaktionsplan. Keine Aenderung an Editorial-, Titel-, Artikeltyp-, Kategorie-, Sandbox-, Recherche-, Content- oder Publish-Logik.
