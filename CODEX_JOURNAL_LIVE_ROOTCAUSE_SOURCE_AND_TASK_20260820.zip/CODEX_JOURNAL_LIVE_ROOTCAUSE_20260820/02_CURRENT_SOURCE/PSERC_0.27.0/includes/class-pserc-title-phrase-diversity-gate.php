<?php
if (!defined('ABSPATH')) { return; }

/**
 * Read-only extension title diversity veto. It never rewrites a title and is enabled only
 * when the signed extension manifest declares phrase_family_repetition_forbidden=true.
 * Existing core article types therefore keep their byte/semantic path unchanged.
 */
final class PSERC_Title_Phrase_Diversity_Gate {
    public const CONTRACT='PSERC_EXTENSION_TITLE_PHRASE_DIVERSITY_V1';

    /** @return array<string,mixed> */
    public static function evaluate(array $topic,array $prepared): array {
        $type=(string)($topic['article_type']??'');$ext=PSERC_Article_Type_Extension_Registry::extension($type);
        $base=['contract'=>self::CONTRACT,'ok'=>true,'status'=>'PASS','article_type'=>$type,'phrase_fingerprints'=>[],'collision'=>[],'reason_codes'=>[],'write_attempted'=>false];
        if(!$ext||($ext['title_policy']['phrase_family_repetition_forbidden']??false)!==true)return $base;
        $title=(string)($topic['production_title']??$topic['title']??'');$keyword=(string)($topic['target_keyword']??'');
        $phrases=self::phrases($title,$keyword);$base['phrase_fingerprints']=$phrases;
        if(!$phrases)return $base;
        foreach($prepared as $other){
            if(self::norm((string)($other['article_type']??''))!==self::norm($type))continue;
            $otherTitle=(string)($other['production_title']??$other['title']??'');$otherKeyword=(string)($other['target_keyword']??'');
            $otherPhrases=self::phrases($otherTitle,$otherKeyword);$shared=array_values(array_intersect($phrases,$otherPhrases));
            if($shared){$base['ok']=false;$base['status']='REVIEW_REQUIRED';$base['collision']=['with_title_sha256'=>hash('sha256',$otherTitle),'shared_phrase_sha256'=>hash('sha256',$shared[0])];$base['reason_codes']=['PSERC_EXTENSION_REPEATED_TITLE_PHRASE_FORBIDDEN'];return $base;}
        }
        return $base;
    }

    /** @return list<string> */
    private static function phrases(string $title,string $keyword): array {
        $surface=self::lower(trim((string)preg_replace('/\s+/u',' ',rtrim($title,'?'))));
        $kw=self::lower(trim((string)preg_replace('/\s+/u',' ',rtrim($keyword,'?'))));
        if($kw!=='')$surface=trim((string)preg_replace('/'.preg_quote($kw,'/').'/iu',' ',$surface,1));
        $surface=trim((string)preg_replace('/[^\p{L}\p{N}\s-]+/u',' ',$surface));$words=array_values(array_filter(preg_split('/\s+/u',$surface)?:[]));
        if(count($words)<2)return [];
        $out=[];$max=min(4,count($words));
        // Two-to-four word residual phrases are the stable template surface after the immutable
        // target keyword has been removed. Repeating one of them is a repeated title phrase.
        for($n=2;$n<=$max;$n++)for($i=0;$i+$n<=count($words);$i++){$p=implode(' ',array_slice($words,$i,$n));if(strlen($p)>=8)$out[$p]=true;}
        return array_keys($out);
    }
    private static function lower(string $v): string{return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
    private static function norm(string $v): string {$v=strtr(trim($v),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$v=self::lower($v);return trim((string)preg_replace('/[^a-z0-9]+/','',$v));}
}
