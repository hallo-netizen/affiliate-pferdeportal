<?php
if (!defined('ABSPATH')) { return; }

/** Signed, read-only extension registry verifier. No routing or editorial domain logic. */
final class PSERC_Article_Type_Extension_Registry {
    public const CONTRACT='ARTICLE_TYPE_EXTENSION_MANIFEST_V1';
    private const MANIFEST='contracts/article-type-extension-manifest-v1.json';
    private const SIGNATURE='contracts/article-type-extension-manifest-v1.sig';
    private const PUBLIC_KEY_B64='3ivO6TMox5vRbBRq4GvBYP3f0M1raWpEXtW7WI9H+nk=';
    private static ?array $cache=null;

    /** @return array<string,mixed> */
    public static function verified(): array {
        if(self::$cache!==null)return self::$cache;
        $base=['ok'=>false,'status'=>'BLOCKED_EXTENSION_MANIFEST','reason_codes'=>[],'manifest'=>[],'manifest_sha256'=>'','write_attempted'=>false];
        $path=PSERC_DIR.self::MANIFEST;$sigPath=PSERC_DIR.self::SIGNATURE;
        if(!is_file($path)||!is_file($sigPath))return self::$cache=self::fail($base,'PSERC_EXTENSION_MANIFEST_MISSING');
        $bytes=(string)file_get_contents($path);$m=json_decode($bytes,true);
        if(!is_array($m)||($m['contract']??'')!==self::CONTRACT)return self::$cache=self::fail($base,'PSERC_EXTENSION_MANIFEST_INVALID');
        if(!function_exists('sodium_crypto_sign_verify_detached'))return self::$cache=self::fail($base,'PSERC_EXTENSION_SIGNATURE_RUNTIME_UNAVAILABLE');
        $sig=base64_decode(trim((string)file_get_contents($sigPath)),true);$pub=base64_decode(self::PUBLIC_KEY_B64,true);
        if(!is_string($sig)||!is_string($pub)||!sodium_crypto_sign_verify_detached($sig,$bytes,$pub))return self::$cache=self::fail($base,'PSERC_EXTENSION_SIGNATURE_INVALID');
        if(($m['status']??'')!=='SIGNED_ACTIVE'||($m['selection_policy']??'')!=='EXPLICIT_SCOPE_AND_INTENT_ONLY_NO_FALLBACK')return self::$cache=self::fail($base,'PSERC_EXTENSION_POLICY_INVALID');
        $base['ok']=true;$base['status']='PASS';$base['manifest']=$m;$base['manifest_sha256']=hash('sha256',$bytes);return self::$cache=$base;
    }
    /** @return array<string,mixed> */
    public static function extension(string $type): array {$v=self::verified();if(empty($v['ok']))return [];$n=self::norm($type);foreach((array)($v['manifest']['extensions']??[]) as $id=>$ext){$aliases=array_map([self::class,'norm'],(array)($ext['aliases']??[]));$aliases[]=self::norm((string)$id);$aliases[]=self::norm((string)($ext['article_type_id']??''));if(in_array($n,$aliases,true))return (array)$ext;}return [];}
    /** @return array<string,mixed> */
    public static function verifyTopicBinding(array $topic): array {
        $base=['ok'=>false,'status'=>'BLOCKED_EXTENSION_TOPIC_BINDING','reason_codes'=>[],'manifest_sha256'=>'','write_attempted'=>false];$v=self::verified();if(empty($v['ok']))return self::fail($base,'PSERC_EXTENSION_MANIFEST_NOT_VERIFIED');$base['manifest_sha256']=(string)$v['manifest_sha256'];
        $type=(string)($topic['article_type']??'');$ext=self::extension($type);if(!$ext)return self::fail($base,'PSERC_EXTENSION_TYPE_NOT_REGISTERED');
        if(trim((string)($ext['activation_policy']??''))===''||($ext['fallback_activation_allowed']??true)!==false||($ext['self_generated_intent_allowed']??true)!==false)return self::fail($base,'PSERC_EXTENSION_ACTIVATION_POLICY_INVALID');
        $routing=(array)($topic['article_type_extension_routing']??$topic['journal_routing']??[]);$ev=(array)($routing['extension_evidence']??[]);
        if(($routing['contract']??'')!=='PSTE_ARTICLE_TYPE_EXTENSION_ROUTE_V1'||($routing['status']??'')!=='EXTENSION_ROUTE_PASS'||empty($routing['ok']))return self::fail($base,'PSERC_EXTENSION_GENERIC_ROUTE_PROOF_REQUIRED');
        if(($ev['contract']??'')!=='ARTICLE_TYPE_EXTENSION_EVIDENCE_V1'||empty($ev['ok'])||($ev['scope_status']??'')!=='PROVEN'||($ev['intent_status']??'')!=='PROVEN')return self::fail($base,'PSERC_EXTENSION_SCOPE_OR_INTENT_NOT_PROVEN');
        if(!in_array((string)($ev['authority_mode']??''),(array)($ext['evidence_policy']['allowed_authority_modes']??[]),true))return self::fail($base,'PSERC_EXTENSION_EVIDENCE_AUTHORITY_NOT_ALLOWED');
        $slug=trim((string)($topic['category_slug']??''));if($slug===''||!self::categoryAllowed($ext,$slug))return self::fail($base,'PSERC_EXTENSION_CATEGORY_NOT_REGISTERED');
        $title=trim((string)($topic['production_title']??$topic['title']??''));$keyword=trim((string)($topic['target_keyword']??''));if($title===''||$keyword==='')return self::fail($base,'PSERC_EXTENSION_TITLE_OR_KEYWORD_MISSING');
        if((string)($ev['title']??'')!==$title||(string)($ev['target_keyword']??'')!==$keyword)return self::fail($base,'PSERC_EXTENSION_TITLE_KEYWORD_BINDING_MISMATCH');
        $base['ok']=true;$base['status']='PASS';$base['reason_codes']=['PSERC_EXTENSION_TOPIC_BINDING_PASS'];$base['authority_mode']=(string)$ev['authority_mode'];return $base;
    }
    /** @return bool */
    private static function categoryAllowed(array $ext,string $slug): bool {foreach((array)($ext['category_policy']['categories']??[]) as $c){$all=array_merge([(string)($c['canonical_plan_slug']??'')],array_map('strval',(array)($c['runtime_slugs']??[])));if(in_array($slug,$all,true))return true;}return false;}
    private static function fail(array $base,string $r): array {$base['reason_codes']=array_values(array_unique(array_merge((array)($base['reason_codes']??[]),[$r])));return $base;}
    private static function norm(string $v): string {$v=function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);$v=strtr($v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);return trim((string)preg_replace('/[^a-z0-9]+/u','',$v));}
}
