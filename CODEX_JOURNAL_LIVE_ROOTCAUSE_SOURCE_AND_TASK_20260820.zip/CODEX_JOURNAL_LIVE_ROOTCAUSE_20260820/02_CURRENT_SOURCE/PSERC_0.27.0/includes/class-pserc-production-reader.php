<?php
if (!defined('ABSPATH')) { return; }

/**
 * Read-only capability binding to signed Portal Production Machine 6.7.9.
 * Journal remains additive and is accepted only when the PPM Journal type, canonical slots
 * and normal-draft release are all present in the signed release state. No production write
 * or alternate workflow is introduced by the compiler.
 *
 * Unlike the old implementation this does not freeze unrelated source bytes in
 * the compiler. It validates the production machine's own self-hashed contracts,
 * the protected quality hashes declared by the normal-draft release contract,
 * the exact public intake policy and the internally declared editorial-plan
 * counts. Any relevant drift still blocks; harmless comments or unrelated files
 * no longer require a compiler rebuild.
 */
final class PSERC_Production_Reader {
    private const REQUIRED_INTERFACE_FILES=[
        'portal-production-machine.php',
        'contracts/article-type-templates.json',
        'contracts/journal-article-type-release-v1.json',
        'contracts/article-type-extension-manifest-v1.json',
        'contracts/article-type-extension-manifest-v1.sig',
        'contracts/editorial-plan-governance-v1.json',
        'contracts/canonical-complete-editorial-plan-v1.json',
        'contracts/normal-draft-release-v1.json',
        'contracts/production-plan-v4.json',
        'contracts/production-plan-v5.json',
        'includes/content-validator.php',
        'includes/plan-validator.php',
        'includes/editorial-plan-registry.php',
        'includes/normal-draft-pipeline.php',
        'includes/normal-draft-release-validator.php',
        'includes/normal-draft-adapter.php',
        'includes/article-type-validator.php',
        'includes/article-type-extension-registry.php',
        'includes/systemwide-duplicate-guard.php',
        'includes/production-wave-governor.php',
    ];

    public static function snapshot(?string $forcedRoot=null): array {
        $root=$forcedRoot!==null?rtrim($forcedRoot,'/\\').DIRECTORY_SEPARATOR:self::locateRoot();
        if($root==='')return self::blocked('PSERC_PRODUCTION_MACHINE_NOT_FOUND','Portal Production Machine wurde nicht gefunden.');
        foreach(self::REQUIRED_INTERFACE_FILES as $relative){if(!is_file($root.$relative))return self::blocked('PSERC_PRODUCTION_INTERFACE_FILE_MISSING','Eine erforderliche Produktionsschnittstelle fehlt.',['file'=>$relative]);}
        $version=self::pluginVersion($root.'portal-production-machine.php');
        if(!hash_equals('6.7.9',$version))return self::blocked('PSERC_PRODUCTION_VERSION_UNSUPPORTED','Die installierte Production Machine besitzt nicht die freigegebene Version 6.7.9.',['expected'=>'6.7.9','actual'=>$version]);

        $types=self::readJson($root.'contracts/article-type-templates.json');
        $journalTypeContract=self::readJson($root.'contracts/journal-article-type-release-v1.json');
        $extensionManifest=self::readJson($root.'contracts/article-type-extension-manifest-v1.json');
        $governance=self::readJson($root.'contracts/editorial-plan-governance-v1.json');
        $plan=self::readJson($root.'contracts/canonical-complete-editorial-plan-v1.json');
        $normalRelease=self::readJson($root.'contracts/normal-draft-release-v1.json');
        $planV4=self::readJson($root.'contracts/production-plan-v4.json');
        $planV5=self::readJson($root.'contracts/production-plan-v5.json');
        if(!$types||!$journalTypeContract||!$extensionManifest||!$governance||!$plan||!$normalRelease||!$planV4||!$planV5)return self::blocked('PSERC_PRODUCTION_CONTRACT_INVALID','Mindestens ein benötigter Produktionsvertrag ist keine gültige JSON-Datei.');
        $localExtension=PSERC_Article_Type_Extension_Registry::verified();
        if(empty($localExtension['ok']))return self::blocked('PSERC_LOCAL_EXTENSION_MANIFEST_INVALID','Die lokale signierte Beitragsart-Registry ist nicht verifizierbar.',$localExtension);
        $ppmManifestHash=hash_file('sha256',$root.'contracts/article-type-extension-manifest-v1.json');
        if(!hash_equals((string)$localExtension['manifest_sha256'],(string)$ppmManifestHash))return self::blocked('PSERC_PPM_EXTENSION_MANIFEST_MISMATCH','PSTE/PSERC und PPM konsumieren nicht byteidentisch dieselbe signierte Beitragsart-Registry.',['local'=>(string)$localExtension['manifest_sha256'],'ppm'=>$ppmManifestHash]);
        $ppmSig=base64_decode(trim((string)file_get_contents($root.'contracts/article-type-extension-manifest-v1.sig')),true);$ppmPub=base64_decode('3ivO6TMox5vRbBRq4GvBYP3f0M1raWpEXtW7WI9H+nk=',true);$ppmBytes=(string)file_get_contents($root.'contracts/article-type-extension-manifest-v1.json');
        if(!function_exists('sodium_crypto_sign_verify_detached')||!is_string($ppmSig)||!is_string($ppmPub)||!sodium_crypto_sign_verify_detached($ppmSig,$ppmBytes,$ppmPub))return self::blocked('PSERC_PPM_EXTENSION_SIGNATURE_INVALID','Die von PPM gelesene gemeinsame Beitragsart-Registry besitzt keine gültige Ed25519-Signatur.');
        if(($extensionManifest['selection_policy']??'')!=='EXPLICIT_SCOPE_AND_INTENT_ONLY_NO_FALLBACK')return self::blocked('PSERC_PPM_EXTENSION_POLICY_INVALID','Die gemeinsame Beitragsart-Registry erlaubt einen unzulässigen Fallback.');
        $journalRegistration=self::journalRegistration($root,$plan,$journalTypeContract);
        if(empty($journalRegistration['ok']))return $journalRegistration;
        foreach([
            'contracts/canonical-complete-editorial-plan-v1.json'=>$plan,
            'contracts/normal-draft-release-v1.json'=>$normalRelease,
            'contracts/journal-article-type-release-v1.json'=>$journalTypeContract,
        ] as $relative=>$contract){$check=self::validateSelfHash($contract,$relative);if(empty($check['ok']))return $check;}
        foreach([
            'contracts/article-type-templates.json'=>$types,
            'contracts/editorial-plan-governance-v1.json'=>$governance,
        ] as $relative=>$contract){if(isset($contract['contract_self_sha256'])){$check=self::validateSelfHash($contract,$relative);if(empty($check['ok']))return $check;}}

        $releaseCheck=self::validateNormalRelease($root,$normalRelease,$types,$journalTypeContract);if(empty($releaseCheck['ok']))return $releaseCheck;
        $slots=array_values(array_filter((array)($plan['slots']??[]),'is_array'));
        $declared=(int)($plan['counts']['total_slots']??0);
        if($declared<=0||count($slots)!==$declared)return self::blocked('PSERC_EDITORIAL_PLAN_DECLARED_COUNT_MISMATCH','Die intern deklarierte Planpositionszahl stimmt nicht mit dem selbstgehashten Plan überein.',['declared'=>$declared,'actual'=>count($slots)]);
        $ids=[];foreach($slots as $slot){$id=trim((string)($slot['canonical_article_id']??''));if($id===''||isset($ids[$id]))return self::blocked('PSERC_EDITORIAL_PLAN_SLOT_ID_INVALID','Der kanonische Plan enthält eine leere oder doppelte Plan-ID.',['canonical_article_id'=>$id]);$ids[$id]=true;}

        $planningRegistered=[];$extensionDefinitions=[];$extensionContractHashes=[];
        foreach((array)($extensionManifest['extensions']??[]) as $ext){
            if(!is_array($ext))continue;
            $name=trim((string)($ext['display_name']??''));
            if($name===''||($ext['handoff_policy']['draft_supported']??false)!==true||($ext['handoff_policy']['publish_allowed']??true)!==false)continue;
            $contractRelative=trim((string)($ext['ppm_capabilities']['type_definition_contract']??''));
            if($contractRelative==='')return self::blocked('PSERC_EXTENSION_TYPE_CONTRACT_UNDECLARED','Eine registrierte Beitragsart besitzt keinen deklarativen PPM-Beitragstypvertrag.',['article_type'=>$name]);
            $contractPath=$root.ltrim($contractRelative,'/\\');$extensionContract=self::readJson($contractPath);
            if(!$extensionContract)return self::blocked('PSERC_EXTENSION_TYPE_CONTRACT_INVALID','Der deklarative Beitragstypvertrag einer Erweiterung fehlt oder ist ungültig.',['article_type'=>$name,'contract'=>$contractRelative]);
            $selfCheck=self::validateSelfHash($extensionContract,$contractRelative);if(empty($selfCheck['ok']))return $selfCheck;
            $definition=(array)($extensionContract['type_definition']??[]);
            if((string)($definition['article_type']??'')!==$name||($definition['production_allowed']??null)!==true||($definition['publish_allowed']??null)!==false)return self::blocked('PSERC_EXTENSION_TYPE_DEFINITION_INVALID','Der deklarierte Erweiterungstyp verletzt die Draft-only-Beitragsart-Capability.',['article_type'=>$name,'contract'=>$contractRelative]);
            $extensionDefinitions[$name]=$definition;$extensionContractHashes[$contractRelative]=hash_file('sha256',$contractPath);$planningRegistered[]=$name;
        }
        $planningRegistered=array_values(array_unique($planningRegistered));
        $governanceAllowed=array_values(array_unique(array_merge(array_map('strval',(array)($governance['first_wave']['allowed_article_types']??[])),$planningRegistered)));
        $definitions=(array)($types['types']??[]);foreach($extensionDefinitions as $name=>$definition)$definitions[$name]=$definition;$requiredCertification=strtoupper(trim((string)($types['certification_policy']['production_requires']??'CERTIFIED')));
        $releaseAllowed=array_values(array_unique(array_merge(array_map('strval',(array)($normalRelease['allowed_article_types']??[])),$planningRegistered)));$releaseBindings=(array)($normalRelease['type_bindings']??[]);
        $registered=[];$globallyCertified=[];$normalDraftSupported=[];$runtime=[];
        foreach($governanceAllowed as $type){
            if(!isset($definitions[$type])||!is_array($definitions[$type]))continue;
            $definition=$definitions[$type];$isExtension=in_array($type,$planningRegistered,true);$productionAllowed=($definition['production_allowed']??false)===true;$certificationStatus=strtoupper(trim((string)($definition['certification_status']??'')));$globallyReady=$productionAllowed&&$requiredCertification!==''&&($isExtension||hash_equals($requiredCertification,$certificationStatus));$releaseListed=in_array($type,$releaseAllowed,true);
            $hasFrozenBinding=isset($releaseBindings[$type])&&is_array($releaseBindings[$type]);$bindingMatches=$hasFrozenBinding?self::bindingMatches($definition,$releaseBindings[$type]):$isExtension;
            $normalReady=$releaseListed&&$bindingMatches&&$globallyReady;$registered[]=$type;if($globallyReady)$globallyCertified[]=$type;if($normalReady)$normalDraftSupported[]=$type;
            $runtime[$type]=['governance_allowed'=>true,'definition_present'=>true,'extension_manifest_registered'=>$isExtension,'global_production_allowed'=>$productionAllowed,'global_certification_status'=>$certificationStatus,'global_required_certification_status'=>$requiredCertification,'global_production_ready'=>$globallyReady,'normal_draft_release_listed'=>$releaseListed,'normal_draft_type_binding_matches'=>$bindingMatches,'normal_draft_production_ready'=>$normalReady,'effective_release_path'=>$normalReady?'NORMAL_DRAFT_RELEASE_SCOPE_V1':'NONE','reason_codes'=>$normalReady?[]:['NORMAL_DRAFT_RELEASE_TYPE_BINDING_MISMATCH']];
        }
        if(!$registered)return self::blocked('PSERC_NO_REGISTERED_ARTICLE_TYPES','Kein Beitragstyp des Produktionsvertrags konnte gelesen werden.');
        if(!$normalDraftSupported)return self::blocked('PSERC_NORMAL_DRAFT_RELEASE_HAS_NO_SUPPORTED_TYPES','Der normale Draft-Freigabepfad gibt aktuell keinen Beitragstyp frei.');

        $hashes=[];foreach(self::REQUIRED_INTERFACE_FILES as $relative)$hashes[$relative]=hash_file('sha256',$root.$relative);foreach($extensionContractHashes as $relative=>$hash)$hashes[$relative]=$hash;
        return ['ok'=>true,'status'=>'PRODUCTION_READ_ONLY_NORMAL_DRAFT_CAPABILITY_PASS','root'=>$root,'version'=>$version,'hashes'=>$hashes,'baseline_sha256'=>PSERC_Stable_Json::hash(['version'=>$version,'release_self_hash'=>(string)$normalRelease['contract_self_sha256'],'plan_self_hash'=>(string)$plan['contract_self_sha256'],'protected_quality_hashes'=>(array)($normalRelease['protected_quality_hashes']??[]),'article_type_extension_manifest_sha256'=>$ppmManifestHash,'extension_type_contract_hashes'=>$extensionContractHashes]),'article_type_contract'=>$types,'article_type_extension_manifest'=>$extensionManifest,'article_type_extension_manifest_sha256'=>$ppmManifestHash,'governance'=>$governance,'plan'=>$plan,'production_plan_v4'=>$planV4,'production_plan_v5'=>$planV5,'normal_draft_release'=>$normalRelease,'normal_draft_release_sha256'=>hash_file('sha256',$root.'contracts/normal-draft-release-v1.json'),'normal_draft_release_self_hash'=>(string)$normalRelease['contract_self_sha256'],'registered_article_types'=>$registered,'planning_registered_article_types'=>$planningRegistered,'globally_certified_article_types'=>$globallyCertified,'supported_article_types'=>$normalDraftSupported,'normal_draft_supported_article_types'=>$normalDraftSupported,'article_type_runtime'=>$runtime,'journal_registration'=>$journalRegistration,'required_certification_status'=>$requiredCertification,'batch_policy'=>['minimum_articles'=>(int)$normalRelease['minimum_articles'],'maximum_articles'=>(int)$normalRelease['maximum_articles'],'maximum_articles_per_type'=>(int)$normalRelease['maximum_articles_per_type'],'publish_allowed'=>(bool)$normalRelease['publish_allowed'],'wissen_allowed'=>(bool)$normalRelease['wissen_allowed'],'scope_mode'=>(string)$normalRelease['scope_mode']],'editorial_plan_slot_count'=>$declared,'binding_mode'=>'SELF_HASHED_CAPABILITY_AND_PROTECTED_QUALITY','write_attempted'=>false];
    }

    public static function titleContract(array $snapshot,string $articleType): array {$ext=PSERC_Article_Type_Extension_Registry::extension($articleType);if($ext){$declared=(array)($ext['title_policy']??[]);$journal=(array)($snapshot['journal_registration']['title_contract']??[]);return array_merge($journal,$declared);} $types=(array)($snapshot['article_type_contract']['types']??[]);return isset($types[$articleType]['title_contract'])&&is_array($types[$articleType]['title_contract'])?$types[$articleType]['title_contract']:[];}
    private static function journalRegistration(string $ppmRoot,array $plan,array $journalTypeContract): array {
        $localRoot=defined('PSERC_DIR')?rtrim((string)PSERC_DIR,'/\\').DIRECTORY_SEPARATOR:dirname(__DIR__).DIRECTORY_SEPARATOR;
        $localPath=$localRoot.'contracts'.DIRECTORY_SEPARATOR.'journal-article-type-v1.json';
        $ppmJournalPath=$ppmRoot.'contracts'.DIRECTORY_SEPARATOR.'journal-content-block-v1.json';
        if(!is_file($localPath)||!is_file($ppmJournalPath))return self::blocked('PSERC_JOURNAL_REGISTRATION_CONTRACT_MISSING','Journal-Registrierungsvertrag oder signiertes PPM-Journalregister fehlt.');
        $local=self::readJson($localPath);$ppmJournal=self::readJson($ppmJournalPath);
        if(!$local||!$ppmJournal)return self::blocked('PSERC_JOURNAL_REGISTRATION_CONTRACT_INVALID','Journal-Registrierungsvertrag oder PPM-Journalregister ist ungültig.');
        $claimed=strtolower(trim((string)($local['contract_self_sha256']??'')));$copy=$local;unset($copy['contract_self_sha256']);$actual=PSERC_Stable_Json::hash($copy);
        if(!preg_match('/^[a-f0-9]{64}$/',$claimed)||!hash_equals($claimed,$actual))return self::blocked('PSERC_JOURNAL_REGISTRATION_SELF_HASH_MISMATCH','Der lokale Journal-Registrierungsvertrag ist nicht selbstkonsistent.');
        if((string)($local['article_type']??'')!=='Journal'||(string)($local['ppm_bridge']['required_ppm_version']??'')!=='6.7.9')return self::blocked('PSERC_JOURNAL_REGISTRATION_SCOPE_INVALID','Der Journal-Registrierungsvertrag besitzt nicht den freigegebenen Scope.');
        $journalDefinition=(array)($journalTypeContract['type_definition']??[]);
        if((string)($journalTypeContract['contract']??'')!=='PPM679_JOURNAL_ARTICLE_TYPE_RELEASE_V1'||(string)($journalDefinition['article_type']??'')!=='Journal'||($journalDefinition['production_allowed']??null)!==true||($journalDefinition['publish_allowed']??null)!==false||strtoupper((string)($journalDefinition['certification_status']??''))!=='SIGNED_NORMAL_DRAFT_RELEASE_ACTIVE')return self::blocked('PSERC_PPM679_JOURNAL_TYPE_RELEASE_INVALID','Der signierte PPM-Journal-Beitragstyp ist nicht aktiv oder verletzt die Draft-only-Grenze.');
        $block=(array)($ppmJournal['content_block']??[]);$allowed=array_values(array_map('strtolower',array_map('strval',(array)($block['allowed_article_types']??[]))));
        if(!in_array('journal',$allowed,true)||($block['draft_generation_allowed']??null)!==true||($block['automatic_publish_allowed']??null)!==false)return self::blocked('PSERC_PPM679_SIGNED_JOURNAL_BRIDGE_INVALID','Das PPM-Journalregister besitzt nicht den erwarteten signierten Draft-only-Journalstatus.');
        $journalSlots=[];$ids=[];$slotsByCategory=[];$preservedLegacyCount=0;
        foreach((array)($plan['slots']??[]) as $slot){
            if(!is_array($slot)||strtolower((string)($slot['content_block']??''))!=='journal')continue;
            if((string)($slot['article_type']??'')!=='Journal')return self::blocked('PSERC_PPM679_JOURNAL_SLOT_TYPE_DRIFT','Ein Journal-Planplatz ist nicht dem signierten Beitragstyp Journal zugeordnet.');
            if(($slot['draft_generation_allowed']??null)!==true||($slot['publish_allowed']??null)!==false||($slot['production_supported_by_current_engine']??null)!==true)return self::blocked('PSERC_PPM679_JOURNAL_SLOT_RELEASE_DRIFT','Ein Journal-Planplatz verletzt die signierte Draft-only-Freigabe.');
            if((string)($slot['legacy_article_type']??'')==='Wissen')$preservedLegacyCount++;
            $id=trim((string)($slot['canonical_article_id']??''));if($id===''||isset($ids[$id]))return self::blocked('PSERC_PPM679_JOURNAL_SLOT_ID_INVALID','Journal-Plan-ID fehlt oder ist doppelt.');
            $ids[$id]=true;$journalSlots[]=$slot;$cat=trim((string)($slot['category_slug']??''));if($cat!=='')$slotsByCategory[$cat][]=$slot;
        }
        $expected=(int)($local['ppm_bridge']['expected_existing_journal_slot_count']??45);if(count($journalSlots)!==$expected)return self::blocked('PSERC_PPM679_JOURNAL_SLOT_COUNT_DRIFT','Die Zahl der signierten Journal-Planplätze hat sich geändert.',['expected'=>$expected,'actual'=>count($journalSlots)]);
        $expectedPreserved=(int)($local['ppm_bridge']['expected_preserved_legacy_journal_slot_count']??40);if($preservedLegacyCount!==$expectedPreserved)return self::blocked('PSERC_PPM679_JOURNAL_LEGACY_IDENTITY_DRIFT','Die Zahl der migrierten alten Wissen/Journal-Planplätze ist nicht exakt erhalten.',['expected'=>$expectedPreserved,'actual'=>$preservedLegacyCount]);
        $categories=array_values(array_filter((array)($ppmJournal['categories']??[]),'is_array'));
        if(count($categories)!==9||count($categories)!==(int)($ppmJournal['category_count']??-1))return self::blocked('PSERC_PPM679_JOURNAL_CATEGORY_COUNT_DRIFT','Das PPM-Journalregister muss exakt neun intern konsistente Kategorien enthalten.');
        $ppmCategorySlugs=[];foreach($categories as $category){$slug=trim((string)($category['slug']??''));if($slug!=='')$ppmCategorySlugs[$slug]=$category;}
        $bridge=[];
        foreach((array)($local['category_scope']['categories']??[]) as $spec){
            if(!is_array($spec))continue;$canonical=trim((string)($spec['canonical_plan_slug']??''));$requires=!empty($spec['signed_plan_slot_required']);$group=$canonical!==''?(array)($slotsByCategory[$canonical]??[]):[];
            if(!$requires||$canonical===''||!isset($ppmCategorySlugs[$canonical]))return self::blocked('PSERC_JOURNAL_CATEGORY_NOT_IN_SIGNED_PPM_REGISTRY','Eine Journal-Kategorie fehlt im signierten PPM-Register.',['canonical_plan_slug'=>$canonical]);
            if(count($group)!==5)return self::blocked('PSERC_JOURNAL_CATEGORY_SLOT_COUNT_DRIFT','Eine Journal-Kategorie besitzt nicht exakt fünf signierte PPM-Planplätze.',['canonical_plan_slug'=>$canonical,'actual'=>count($group)]);
            $bridge[]=['key'=>(string)($spec['key']??''),'name'=>(string)($spec['name']??''),'canonical_plan_slug'=>$canonical,'runtime_slugs'=>array_values(array_unique(array_map('strval',(array)($spec['runtime_slugs']??[])))),'signed_plan_slot_available'=>true,'signed_plan_slot_count'=>5,'canonical_article_ids'=>array_values(array_map(static fn($s)=>(string)($s['canonical_article_id']??''),$group)),'ppm_legacy_article_type'=>'Wissen','ppm_active_article_type'=>'Journal','draft_release_active'=>true];
        }
        if(count($bridge)!==9)return self::blocked('PSERC_JOURNAL_CATEGORY_BRIDGE_COUNT_INVALID','Der Journal-Kategorie-Bridge muss exakt neun Kategorien enthalten.',['actual'=>count($bridge)]);
        return ['ok'=>true,'status'=>'PSERC_JOURNAL_SIGNED_NORMAL_DRAFT_REGISTRATION_PASS','article_type'=>'Journal','canonical_type_id'=>'journal','scope'=>'JOURNAL_CONTENT_BLOCK_ONLY','title_contract'=>(array)($local['title_contract']??[]),'structure_contract'=>(array)($local['structure_contract']??[]),'selection_policy'=>(string)($local['selection_policy']??''),'ppm_bridge'=>['version'=>'6.7.9','legacy_internal_article_type'=>'Wissen','external_article_type'=>'Journal','canonical_slot_count'=>count($journalSlots),'preserved_legacy_slot_count'=>$preservedLegacyCount,'canonical_article_ids'=>array_keys($ids),'canonical_article_ids_sha256'=>PSERC_Stable_Json::hash(array_keys($ids)),'active_signed_journal_category_count'=>count($categories),'registered_runtime_journal_category_count'=>count($bridge),'ppm_journal_registry_sha256'=>hash_file('sha256',$ppmJournalPath),'ppm_journal_type_contract_sha256'=>hash_file('sha256',$ppmRoot.'contracts'.DIRECTORY_SEPARATOR.'journal-article-type-release-v1.json'),'ppm_canonical_plan_sha256'=>hash_file('sha256',$ppmRoot.'contracts'.DIRECTORY_SEPARATOR.'canonical-complete-editorial-plan-v1.json'),'ppm_signed_release_updated'=>true,'normal_draft_release_active'=>true],'category_bridge'=>$bridge,'new_category'=>(array)($local['category_scope']['new_category']??[]),'sandbox_redaktionsplan_binding'=>(array)($local['sandbox_redaktionsplan_binding']??[]),'five_field_handoff'=>(array)($local['five_field_handoff']??[]),'runtime_route_activation'=>(string)($local['runtime_route_activation']??''),'normal_draft_release'=>true,'publish_allowed'=>false,'workflow_change'=>false,'textmachine_change'=>false,'other_article_type_rule_change'=>false,'write_attempted'=>false];
    }

    private static function validateSelfHash(array $contract,string $relative): array {$claimed=strtolower(trim((string)($contract['contract_self_sha256']??'')));$copy=$contract;unset($copy['contract_self_sha256']);$actual=PSERC_Stable_Json::hash($copy);return preg_match('/^[a-f0-9]{64}$/',$claimed)&&hash_equals($claimed,$actual)?['ok'=>true]:self::blocked('PSERC_PRODUCTION_CONTRACT_SELF_HASH_MISMATCH','Ein Produktionsvertrag ist nicht selbstkonsistent.',['file'=>$relative,'expected'=>$actual,'actual'=>$claimed]);}
    private static function validateNormalRelease(string $root,array $release,array $types,array $journalTypeContract): array {
        $exact=['contract'=>'NORMAL_DRAFT_RELEASE_SCOPE_V1','version'=>'1.1.0','scope_mode'=>'REUSABLE_NORMAL_DRAFT_1_TO_4','minimum_articles'=>1,'maximum_articles'=>4,'maximum_articles_per_type'=>1,'wissen_allowed'=>true,'journal_draft_release_allowed'=>true,'publish_allowed'=>false,'global_article_type_flags_may_change'=>false,'canonical_articles_must_be_pre_researched'=>true,'plugin_text_generation_allowed'=>false,'existing_content_update_allowed'=>false,'existing_content_delete_allowed'=>false];
        foreach($exact as $field=>$wanted)if(PSERC_Stable_Json::hash($release[$field]??null)!==PSERC_Stable_Json::hash($wanted))return self::blocked('PSERC_NORMAL_DRAFT_RELEASE_POLICY_MISMATCH','Der normale Draft-Freigabevertrag besitzt nicht die geprüfte Sicherheitsgrenze.',['field'=>$field,'expected'=>$wanted,'actual'=>$release[$field]??null]);
        $allowed=array_values((array)($release['allowed_article_types']??[]));if(!$allowed||count($allowed)!==count(array_unique(array_map('strval',$allowed))))return self::blocked('PSERC_NORMAL_DRAFT_RELEASE_TYPES_INVALID','Die Typfreigabe ist leer oder enthält Duplikate.');
        $definitions=(array)($types['types']??[]);$journalDefinition=(array)($journalTypeContract['type_definition']??[]);if($journalDefinition)$definitions['Journal']=$journalDefinition;$bindings=(array)($release['type_bindings']??[]);foreach($allowed as $type){$type=(string)$type;if(!isset($definitions[$type])||!is_array($definitions[$type])||!isset($bindings[$type])||!is_array($bindings[$type])||!self::bindingMatches($definitions[$type],$bindings[$type]))return self::blocked('PSERC_NORMAL_DRAFT_RELEASE_TYPE_BINDING_MISMATCH','Ein freigegebener Beitragstyp besitzt keine gültige Bindung.',['article_type'=>$type]);}
        foreach((array)($release['protected_quality_hashes']??[]) as $relative=>$wanted){$path=$root.ltrim((string)$relative,'/\\');$got=is_file($path)?hash_file('sha256',$path):'';if($got===''||!hash_equals((string)$wanted,$got))return self::blocked('PSERC_NORMAL_DRAFT_RELEASE_PROTECTED_HASH_MISMATCH','Eine geschützte Qualitätsdatei ist verändert.',['file'=>$relative,'expected'=>$wanted,'actual'=>$got]);}
        return ['ok'=>true,'status'=>'NORMAL_DRAFT_RELEASE_READ_ONLY_PASS','write_attempted'=>false];
    }
    private static function bindingMatches(array $definition,array $binding): bool {$actual=['production_allowed'=>$definition['production_allowed']??null,'certification_status'=>$definition['certification_status']??null,'definition_hash'=>$definition['certification_evidence']['definition_hash']??null,'evidence_hash'=>$definition['certification_evidence']['evidence_hash']??null];return hash_equals(PSERC_Stable_Json::hash($binding),PSERC_Stable_Json::hash($actual));}
    private static function pluginVersion(string $path): string {$head=(string)file_get_contents($path,false,null,0,8192);return preg_match('/^[ \t\/*#@]*Version:\s*(.+)$/mi',$head,$m)?trim((string)$m[1]):'';}
    private static function locateRoot(): string {$base=defined('WP_PLUGIN_DIR')?rtrim((string)WP_PLUGIN_DIR,'/\\').DIRECTORY_SEPARATOR:'';if($base==='')return '';$direct=$base.'portal-production-machine'.DIRECTORY_SEPARATOR;if(is_file($direct.'portal-production-machine.php'))return $direct;$matches=glob($base.'*'.DIRECTORY_SEPARATOR.'portal-production-machine.php')?:[];return count($matches)===1?dirname($matches[0]).DIRECTORY_SEPARATOR:'';}
    private static function readJson(string $path): ?array {if(!is_file($path))return null;$decoded=json_decode((string)file_get_contents($path),true);return is_array($decoded)?$decoded:null;}
    private static function blocked(string $status,string $message,array $extra=[]): array {return array_merge(['ok'=>false,'status'=>$status,'message'=>$message,'write_attempted'=>false],$extra);}
}
