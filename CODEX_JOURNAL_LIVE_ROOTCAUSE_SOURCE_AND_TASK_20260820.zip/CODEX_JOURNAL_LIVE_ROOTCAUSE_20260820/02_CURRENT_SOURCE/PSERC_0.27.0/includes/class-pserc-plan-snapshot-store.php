<?php
if (!defined('ABSPATH')) { return; }

/**
 * Record-local persistence for the asynchronous Redaktionsplan compile.
 * Technical storage only; no post/term/meta/content/prompt writes.
 */
final class PSERC_Plan_Snapshot_Store {
    public const JOB_OPTION='pserc_plan_compile_job_v1';
    public const ACTIVE_OPTION='pserc_plan_active_snapshot_v1';
    public const LEASE_OPTION='pserc_plan_compile_lease_v1';
    public const FENCE_OPTION='pserc_plan_compile_fence_v1';
    private const RECORD_CONTRACT='PSERC_PLAN_RECORD_V1';
    private const NAMED_CONTRACT='PSERC_PLAN_NAMED_RECORD_V1';
    private const READY_CONTRACT='PSERC_PLAN_READY_INDEX_ROW_V1';
    private const READY_BATCH_MAX_BYTES=2097152;

    public static function generationId(string $uuid): string {return substr(hash('sha256',$uuid),0,20);}

    public static function getJob(): array {$v=get_option(self::JOB_OPTION,[]);return is_array($v)?$v:[];}
    public static function putJob(array $job): void {
        self::assertWorkerFence((string)($job['generation']??''));
        update_option(self::JOB_OPTION,$job,false);$read=self::getJob();
        if(!hash_equals(PSERC_Stable_Json::hash($job),PSERC_Stable_Json::hash($read)))throw new RuntimeException('PSERC_PLAN_JOB_READBACK_MISMATCH');
    }
    public static function getActive(): array {$v=get_option(self::ACTIVE_OPTION,[]);return is_array($v)?$v:[];}
    public static function activate(array $header): void {
        self::assertWorkerFence((string)($header['generation']??''));
        $copy=$header;unset($copy['snapshot_sha256']);$header['snapshot_sha256']=PSERC_Stable_Json::hash($copy);update_option(self::ACTIVE_OPTION,$header,false);$read=self::getActive();
        if(!self::verifyHeader($read)||!hash_equals((string)$header['snapshot_sha256'],(string)$read['snapshot_sha256']))throw new RuntimeException('PSERC_PLAN_ACTIVE_READBACK_MISMATCH');
    }
    public static function verifyHeader(array $header): bool {
        if(($header['contract']??'')!=='PSERC_PLAN_SNAPSHOT_V1')return false;$decl=(string)($header['snapshot_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$decl))return false;
        $copy=$header;unset($copy['snapshot_sha256']);return hash_equals($decl,PSERC_Stable_Json::hash($copy));
    }

    public static function putRecord(string $generation,string $kind,int $index,array $payload): void {
        self::assertWorkerFence($generation);
        if($index<0)throw new RuntimeException('PSERC_PLAN_RECORD_INDEX_INVALID');$env=['contract'=>self::RECORD_CONTRACT,'generation'=>$generation,'kind'=>$kind,'index'=>$index,'payload_sha256'=>PSERC_Stable_Json::hash($payload),'payload'=>$payload];$env['record_sha256']=self::recordHash($env);
        $key=self::recordKey($generation,$kind,$index);update_option($key,$env,false);$read=get_option($key,[]);if(!is_array($read))throw new RuntimeException('PSERC_PLAN_RECORD_READBACK_MISSING_'.$kind.'_'.$index);self::assertRecord($read,$generation,$kind,$index);if(!hash_equals((string)$env['record_sha256'],(string)($read['record_sha256']??'')))throw new RuntimeException('PSERC_PLAN_RECORD_READBACK_MISMATCH_'.$kind.'_'.$index);
    }
    public static function getRecord(string $generation,string $kind,int $index): ?array {
        $v=get_option(self::recordKey($generation,$kind,$index),null);if($v===null||$v===false)return null;if(!is_array($v))throw new RuntimeException('PSERC_PLAN_RECORD_INVALID_'.$kind.'_'.$index);self::assertRecord($v,$generation,$kind,$index);return (array)$v['payload'];
    }
    /** @return list<array<string,mixed>> */
    public static function getRange(string $generation,string $kind,int $start,int $limit): array {$out=[];$limit=max(1,min(50,$limit));for($i=max(0,$start);$i<$start+$limit;$i++){ $v=self::getRecord($generation,$kind,$i);if($v===null)break;$out[]=$v;}return $out;}
    public static function recordExists(string $generation,string $kind,int $index): bool {return get_option(self::recordKey($generation,$kind,$index),null)!==null;}
    public static function deleteRecord(string $generation,string $kind,int $index): void {self::assertWorkerFence($generation);delete_option(self::recordKey($generation,$kind,$index));}

    /** Named record used for exact duplicate indexes. Lowest order wins deterministically. */
    public static function putNamedMin(string $generation,string $kind,string $name,int $order,array $payload): void {
        self::assertWorkerFence($generation);
        $key=self::namedKey($generation,$kind,$name);$old=get_option($key,null);if(is_array($old)){self::assertNamed($old,$generation,$kind,$name);if((int)($old['order']??PHP_INT_MAX)<=$order)return;}
        $env=['contract'=>self::NAMED_CONTRACT,'generation'=>$generation,'kind'=>$kind,'name_sha256'=>hash('sha256',$name),'order'=>$order,'payload_sha256'=>PSERC_Stable_Json::hash($payload),'payload'=>$payload];$env['record_sha256']=self::namedHash($env);update_option($key,$env,false);$read=get_option($key,[]);if(!is_array($read))throw new RuntimeException('PSERC_PLAN_NAMED_READBACK_MISSING_'.$kind);self::assertNamed($read,$generation,$kind,$name);if(!hash_equals((string)$env['record_sha256'],(string)($read['record_sha256']??'')))throw new RuntimeException('PSERC_PLAN_NAMED_READBACK_MISMATCH_'.$kind);
    }
    public static function getNamed(string $generation,string $kind,string $name): ?array {
        $v=get_option(self::namedKey($generation,$kind,$name),null);if($v===null||$v===false)return null;if(!is_array($v))throw new RuntimeException('PSERC_PLAN_NAMED_RECORD_INVALID_'.$kind);self::assertNamed($v,$generation,$kind,$name);return ['order'=>(int)$v['order'],'payload'=>(array)$v['payload']];
    }

    /** Create the two narrow technical sort/index tables once at job INIT. */
    public static function ensureReadyIndexTable(): void {
        global $wpdb;if(!isset($wpdb)||!is_object($wpdb)||empty($wpdb->prefix)||!method_exists($wpdb,'query'))throw new RuntimeException('PSERC_PLAN_INDEX_DB_UNAVAILABLE');$ready=self::readyTable();$candidate=self::candidateTable();
        $charset=method_exists($wpdb,'get_charset_collate')?(string)$wpdb->get_charset_collate():'';
        $readySql="CREATE TABLE $ready (generation varchar(32) NOT NULL,ready_seq bigint unsigned NOT NULL,final_index bigint unsigned NOT NULL,plan_slot char(64) NOT NULL,sort_title varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,title_identity_sha256 char(64) NOT NULL,binding_json longtext NOT NULL,binding_sha256 char(64) NOT NULL,PRIMARY KEY (generation,ready_seq),UNIQUE KEY generation_slot (generation,plan_slot),UNIQUE KEY generation_title (generation,title_identity_sha256),KEY generation_sort (generation,sort_title,ready_seq)) $charset";
        /* priority_rank is 1000-(priority_score*10), so one all-ASC binary key reproduces the old PHP sort: priority DESC, allocation title ASC, pool key ASC, stable source order. */
        $candidateSql="CREATE TABLE $candidate (generation varchar(32) NOT NULL,source_seq bigint unsigned NOT NULL,priority_rank smallint unsigned NOT NULL,sort_title varbinary(512) NOT NULL,pool_key varbinary(128) NOT NULL,PRIMARY KEY (generation,source_seq),KEY generation_order (generation,priority_rank,sort_title,pool_key,source_seq)) $charset";
        if(!function_exists('dbDelta')&&defined('ABSPATH')){ $upgrade=rtrim((string)ABSPATH,'/').'/wp-admin/includes/upgrade.php'; if(is_file($upgrade))require_once $upgrade; }
        foreach([[$readySql,'PSERC_PLAN_READY_INDEX_CREATE_FAILED'],[$candidateSql,'PSERC_PLAN_CANDIDATE_INDEX_CREATE_FAILED']] as [$sql,$code]){
            if(function_exists('dbDelta')){dbDelta($sql);}else{$safe=preg_replace('/^CREATE TABLE /','CREATE TABLE IF NOT EXISTS ',$sql,1);$r=$wpdb->query($safe);if($r===false&&(string)($wpdb->last_error??'')!=='')throw new RuntimeException($code);}
        }
        if(method_exists($wpdb,'get_var')){foreach([[$ready,'PSERC_PLAN_READY_INDEX_TABLE_MISSING'],[$candidate,'PSERC_PLAN_CANDIDATE_INDEX_TABLE_MISSING']] as [$table,$code]){$exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table));if((string)$exists!==$table)throw new RuntimeException($code);}}
    }

    /** Persist one eligible candidate's *existing* compiler order key. No title/priority decision is made here. */
    public static function putCandidateIndex(string $generation,int $sourceSeq,float $priorityScore,string $sortTitle,string $poolKey): void {
        self::assertWorkerFence($generation);$sortTitle=(string)$sortTitle;$poolKey=(string)$poolKey;
        if($sourceSeq<0||$sortTitle===''||$poolKey==='')throw new RuntimeException('PSERC_PLAN_CANDIDATE_INDEX_INPUT_INVALID');
        /* PHP compares two numeric strings numerically, whereas VARBINARY is lexical. Fail closed instead of silently changing the inherited comparator. */
        if(is_numeric($sortTitle)||is_numeric($poolKey))throw new RuntimeException('PSERC_PLAN_CANDIDATE_SORT_NUMERIC_STRING_UNSUPPORTED');
        if(strlen($sortTitle)>512||strlen($poolKey)>128)throw new RuntimeException('PSERC_PLAN_CANDIDATE_SORT_KEY_BUDGET_EXCEEDED');
        $scaled=(int)round($priorityScore*10);if($scaled<0||$scaled>1000)throw new RuntimeException('PSERC_PLAN_CANDIDATE_PRIORITY_OUT_OF_RANGE');$rank=1000-$scaled;
        global $wpdb;$table=self::candidateTable();$prior=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE generation=%s AND source_seq=%d",$generation,$sourceSeq),defined('ARRAY_A')?ARRAY_A:'ARRAY_A');
        if($prior){if(is_object($prior))$prior=(array)$prior;self::assertCandidateRow($prior,$generation,$sourceSeq);if((int)$prior['priority_rank']!==$rank||!hash_equals((string)$prior['sort_title'],$sortTitle)||!hash_equals((string)$prior['pool_key'],$poolKey))throw new RuntimeException('PSERC_PLAN_CANDIDATE_INDEX_REPLAY_CONFLICT');return;}
        $ok=$wpdb->insert($table,['generation'=>$generation,'source_seq'=>$sourceSeq,'priority_rank'=>$rank,'sort_title'=>$sortTitle,'pool_key'=>$poolKey],['%s','%d','%d','%s','%s']);if($ok===false)throw new RuntimeException('PSERC_PLAN_CANDIDATE_INDEX_WRITE_FAILED');
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE generation=%s AND source_seq=%d",$generation,$sourceSeq),defined('ARRAY_A')?ARRAY_A:'ARRAY_A');$row=is_array($row)?$row:(array)$row;self::assertCandidateRow($row,$generation,$sourceSeq);if((int)($row['priority_rank']??-1)!==$rank||!hash_equals((string)($row['sort_title']??''),$sortTitle)||!hash_equals((string)($row['pool_key']??''),$poolKey))throw new RuntimeException('PSERC_PLAN_CANDIDATE_INDEX_READBACK_MISMATCH');
    }

    /** Keyset-next candidate in the exact inherited eligible sort order. @return array<string,mixed>|null */
    public static function nextCandidateIndex(string $generation,?array $cursor=null): ?array {
        global $wpdb;$table=self::candidateTable();
        if($cursor===null){$sql=$wpdb->prepare("SELECT * FROM $table WHERE generation=%s ORDER BY priority_rank ASC,sort_title ASC,pool_key ASC,source_seq ASC LIMIT 1",$generation);}else{
            $r=(int)($cursor['priority_rank']??-1);$t=(string)($cursor['sort_title']??'');$p=(string)($cursor['pool_key']??'');$s=(int)($cursor['source_seq']??-1);if($r<0||$t===''||$p===''||$s<0)throw new RuntimeException('PSERC_PLAN_CANDIDATE_CURSOR_INVALID');
            $sql=$wpdb->prepare("SELECT * FROM $table WHERE generation=%s AND (priority_rank>%d OR (priority_rank=%d AND (sort_title>%s OR (sort_title=%s AND (pool_key>%s OR (pool_key=%s AND source_seq>%d)))))) ORDER BY priority_rank ASC,sort_title ASC,pool_key ASC,source_seq ASC LIMIT 1",$generation,$r,$r,$t,$t,$p,$p,$s);
        }
        $row=$wpdb->get_row($sql,defined('ARRAY_A')?ARRAY_A:'ARRAY_A');if(!$row)return null;if(is_object($row))$row=(array)$row;$seq=(int)($row['source_seq']??-1);self::assertCandidateRow($row,$generation,$seq);$next=['priority_rank'=>(int)$row['priority_rank'],'sort_title'=>(string)$row['sort_title'],'pool_key'=>(string)$row['pool_key'],'source_seq'=>$seq];return ['source_seq'=>$seq,'cursor'=>$next,'priority_score'=>(1000-(int)$row['priority_rank'])/10.0];
    }
    public static function candidateCount(string $generation): int {global $wpdb;$table=self::candidateTable();$v=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE generation=%s",$generation));return max(0,(int)$v);}

    public static function putReadyIndex(string $generation,int $readySeq,int $finalIndex,array $binding): void {
        self::assertWorkerFence($generation);
        $batch=self::batchFromItems([$binding]);$boundary=PSERC_Metadata_Boundary::validateBatch($batch);if(empty($boundary['ok']))throw new RuntimeException((string)($boundary['status']??'PSERC_PLAN_READY_BINDING_INVALID'));
        $slot=(string)($binding['plan_slot']??'');$title=(string)($binding['title']??'');$identity=self::titleIdentitySha256($title);$json=PSERC_Stable_Json::encode($binding);$hash=hash('sha256',$json);global $wpdb;$table=self::readyTable();
        $prior=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE generation=%s AND ready_seq=%d",$generation,$readySeq),defined('ARRAY_A')?ARRAY_A:'ARRAY_A');if($prior){if(is_object($prior))$prior=(array)$prior;self::assertReadyRow($prior,$generation,$readySeq);if((int)($prior['final_index']??-1)!==$finalIndex||!hash_equals((string)($prior['binding_sha256']??''),$hash))throw new RuntimeException('PSERC_PLAN_READY_INDEX_REPLAY_CONFLICT');return;}
        $ok=$wpdb->insert($table,['generation'=>$generation,'ready_seq'=>$readySeq,'final_index'=>$finalIndex,'plan_slot'=>$slot,'sort_title'=>$title,'title_identity_sha256'=>$identity,'binding_json'=>$json,'binding_sha256'=>$hash],['%s','%d','%d','%s','%s','%s','%s','%s']);
        if($ok===false){$err=strtoupper((string)($wpdb->last_error??''));if(str_contains($err,'DUPLICATE'))throw new RuntimeException('PSERC_PLAN_READY_DUPLICATE_TITLE_OR_SLOT');throw new RuntimeException('PSERC_PLAN_READY_INDEX_WRITE_FAILED');}
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE generation=%s AND ready_seq=%d",$generation,$readySeq),defined('ARRAY_A')?ARRAY_A:'ARRAY_A');$row=is_array($row)?$row:[];self::assertReadyRow($row,$generation,$readySeq);if((int)($row['final_index']??-1)!==$finalIndex||!hash_equals((string)($row['binding_sha256']??''),$hash))throw new RuntimeException('PSERC_PLAN_READY_INDEX_READBACK_MISMATCH');
    }

    /** @return array<string,mixed> */
    public static function getReadyPage(string $generation,?array $cursor=null,int $limit=50): array {
        global $wpdb;$limit=max(1,min(50,$limit));$table=self::readyTable();$title=(string)($cursor['title']??'');$seq=(int)($cursor['seq']??-1);
        if($cursor===null)$sql=$wpdb->prepare("SELECT * FROM $table WHERE generation=%s ORDER BY sort_title ASC, ready_seq ASC LIMIT %d",$generation,$limit);
        else $sql=$wpdb->prepare("SELECT * FROM $table WHERE generation=%s AND (sort_title>%s OR (sort_title=%s AND ready_seq>%d)) ORDER BY sort_title ASC, ready_seq ASC LIMIT %d",$generation,$title,$title,$seq,$limit);
        $rows=$wpdb->get_results($sql,defined('ARRAY_A')?ARRAY_A:'ARRAY_A');if(!is_array($rows))throw new RuntimeException('PSERC_PLAN_READY_INDEX_READ_FAILED');$items=[];$last=null;
        foreach($rows as $row){if(is_object($row))$row=(array)$row;self::assertReadyRow($row,$generation,(int)$row['ready_seq']);$binding=json_decode((string)$row['binding_json'],true);$items[]=['binding'=>$binding,'final_index'=>(int)$row['final_index'],'ready_seq'=>(int)$row['ready_seq'],'title'=>(string)$row['sort_title']];$last=['title'=>(string)$row['sort_title'],'seq'=>(int)$row['ready_seq']];}
        return ['items'=>$items,'next_cursor'=>$last,'complete'=>count($rows)<$limit,'item_count'=>count($rows)];
    }
    public static function getReadyBySlot(string $generation,string $slot): ?array {
        global $wpdb;$table=self::readyTable();$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE generation=%s AND plan_slot=%s LIMIT 1",$generation,$slot),defined('ARRAY_A')?ARRAY_A:'ARRAY_A');if(!$row)return null;if(is_object($row))$row=(array)$row;self::assertReadyRow($row,$generation,(int)$row['ready_seq']);return ['binding'=>(array)json_decode((string)$row['binding_json'],true),'final_index'=>(int)$row['final_index'],'ready_seq'=>(int)$row['ready_seq'],'title'=>(string)$row['sort_title']];
    }
    public static function readyCount(string $generation): int {global $wpdb;$table=self::readyTable();$v=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE generation=%s",$generation));return max(0,(int)$v);}

    /** Explicit export helper. Snapshot-bound, no compiler call; memory capped by the inherited 2 MiB metadata budget. */
    public static function materializeReadyBatch(array $header): array {
        if(!self::verifyHeader($header))throw new RuntimeException('PSERC_PLAN_ACTIVE_HEADER_INVALID');$generation=(string)$header['generation'];$items=[];$cursor=null;$bytes=0;
        do{$page=self::getReadyPage($generation,$cursor,50);foreach((array)$page['items'] as $row){$b=(array)($row['binding']??[]);$items[]=$b;$bytes+=strlen(PSERC_Stable_Json::encode($b))+1;if($bytes>self::READY_BATCH_MAX_BYTES)throw new RuntimeException('PSERC_PLAN_EXACT_FIVE_BATCH_BYTE_BUDGET_EXCEEDED');}$cursor=$page['next_cursor']??null;}while(empty($page['complete']));
        $batch=self::batchFromItems($items);$boundary=PSERC_Metadata_Boundary::validateBatch($batch);if(empty($boundary['ok']))throw new RuntimeException((string)($boundary['status']??'PSERC_PLAN_FINAL_BATCH_INVALID'));return $batch;
    }
    /** @param list<array<string,mixed>> $items @return array<string,mixed> */
    public static function batchFromItems(array $items): array {$batch=['contract'=>'PSERC_TEXTMACHINE_METADATA_BATCH_V2','status'=>$items?'READY_FOR_TEXTMACHINE_METADATA_INTAKE':'NO_READY_ITEMS','item_count'=>count($items),'maximum_articles'=>0,'maximum_articles_per_type'=>0,'publish_allowed'=>false,'content_or_format_payload_present'=>false,'items'=>array_values($items)];$batch['batch_sha256']=PSERC_Stable_Json::hash($batch);return $batch;}

    /** Build a minimal supervisor-compatible manifest for a selected READY batch. */
    public static function manifestForSelectedBatch(array $header,array $selectedBatch): array {
        if(!self::verifyHeader($header))throw new RuntimeException('PSERC_PLAN_ACTIVE_HEADER_INVALID');$generation=(string)$header['generation'];$details=[];
        foreach((array)($selectedBatch['items']??[]) as $meta){if(!is_array($meta))continue;$slot=(string)($meta['plan_slot']??'');$ready=self::getReadyBySlot($generation,$slot);if(!is_array($ready))throw new RuntimeException('PSERC_PLAN_READY_DETAIL_INDEX_MISSING');if(!hash_equals(PSERC_Stable_Json::hash((array)$ready['binding']),PSERC_Stable_Json::hash($meta)))throw new RuntimeException('PSERC_PLAN_READY_BINDING_MISMATCH');$item=self::getRecord($generation,'final_item',(int)$ready['final_index']);if(!is_array($item)||($item['status']??'')!=='READY_FOR_METADATA_HANDOFF')throw new RuntimeException('PSERC_PLAN_READY_DETAIL_INVALID');$details[]=$item;}
        $manifest=(array)($header['manifest_base']??[]);$manifest['items']=$details;$manifest['next_textmachine_metadata_batch']=$selectedBatch;$manifest['metadata_boundary']=PSERC_Metadata_Boundary::validateBatch($selectedBatch);$manifest['manifest_sha256']=PSERC_Stable_Json::hash($manifest);return $manifest;
    }

    private static function assertWorkerFence(string $generation): void {
        if(!class_exists('PSERC_Plan_Compile_Job')||!method_exists('PSERC_Plan_Compile_Job','storageFenceContext'))return;
        $ctx=(array)PSERC_Plan_Compile_Job::storageFenceContext();if(empty($ctx['active']))return;
        $lease=get_option(self::LEASE_OPTION,[]);if(!is_array($lease)||!hash_equals((string)($ctx['token']??''),(string)($lease['token']??''))||(int)($ctx['fence']??0)!==(int)($lease['fence']??-1)||($generation!==''&&!hash_equals($generation,(string)($lease['generation']??'')))||(int)($lease['expires_at']??0)<time())throw new RuntimeException('PSERC_PLAN_STALE_FENCE_WRITE_BLOCKED');
    }

    private static function readyTable(): string {global $wpdb;return (string)$wpdb->prefix.'pserc_plan_ready_index';}
    private static function candidateTable(): string {global $wpdb;return (string)$wpdb->prefix.'pserc_plan_candidate_index';}
    private static function titleIdentitySha256(string $title): string {$v=trim((string)preg_replace('/\s+/u',' ',$title));$v=function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);return hash('sha256',$v);}
    private static function assertReadyRow(array $row,string $generation,int $readySeq): void {
        if(!$row||!hash_equals($generation,(string)($row['generation']??''))||(int)($row['ready_seq']??-1)!==$readySeq)throw new RuntimeException('PSERC_PLAN_READY_INDEX_BINDING_MISMATCH');$json=(string)($row['binding_json']??'');$decl=(string)($row['binding_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$decl)||!hash_equals($decl,hash('sha256',$json)))throw new RuntimeException('PSERC_PLAN_READY_INDEX_HASH_MISMATCH');$binding=json_decode($json,true);if(!is_array($binding)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException('PSERC_PLAN_READY_INDEX_JSON_INVALID');if(!hash_equals((string)($row['plan_slot']??''),(string)($binding['plan_slot']??''))||!hash_equals((string)($row['sort_title']??''),(string)($binding['title']??''))||!hash_equals((string)($row['title_identity_sha256']??''),self::titleIdentitySha256((string)($binding['title']??''))))throw new RuntimeException('PSERC_PLAN_READY_INDEX_PAYLOAD_BINDING_MISMATCH');
    }
    private static function assertCandidateRow(array $row,string $generation,int $sourceSeq): void {
        if(!$row||!hash_equals($generation,(string)($row['generation']??''))||(int)($row['source_seq']??-1)!==$sourceSeq)throw new RuntimeException('PSERC_PLAN_CANDIDATE_INDEX_BINDING_MISMATCH');$rank=(int)($row['priority_rank']??-1);$title=(string)($row['sort_title']??'');$pool=(string)($row['pool_key']??'');if($rank<0||$rank>1000||$title===''||$pool===''||strlen($title)>512||strlen($pool)>128||is_numeric($title)||is_numeric($pool))throw new RuntimeException('PSERC_PLAN_CANDIDATE_INDEX_ROW_INVALID');
    }

    private static function recordKey(string $generation,string $kind,int $index): string {$g=preg_replace('/[^a-z0-9]/','',strtolower($generation));$k=preg_replace('/[^a-z0-9_]/','',strtolower($kind));if($g===''||$k==='')throw new RuntimeException('PSERC_PLAN_RECORD_KEY_INVALID');return 'pserc_plan_'.$g.'_'.$k.'_'.str_pad((string)$index,6,'0',STR_PAD_LEFT);}
    private static function namedKey(string $generation,string $kind,string $name): string {$g=preg_replace('/[^a-z0-9]/','',strtolower($generation));$k=preg_replace('/[^a-z0-9_]/','',strtolower($kind));if($g===''||$k===''||$name==='')throw new RuntimeException('PSERC_PLAN_NAMED_KEY_INVALID');return 'pserc_plan_'.$g.'_'.$k.'_'.substr(hash('sha256',$name),0,40);}
    private static function recordHash(array $env): string {$copy=$env;unset($copy['record_sha256']);return PSERC_Stable_Json::hash($copy);}
    private static function namedHash(array $env): string {$copy=$env;unset($copy['record_sha256']);return PSERC_Stable_Json::hash($copy);}
    private static function assertRecord(array $env,string $generation,string $kind,int $index): void {if(($env['contract']??'')!==self::RECORD_CONTRACT||!hash_equals($generation,(string)($env['generation']??''))||!hash_equals($kind,(string)($env['kind']??''))||(int)($env['index']??-1)!==$index)throw new RuntimeException('PSERC_PLAN_RECORD_BINDING_MISMATCH_'.$kind.'_'.$index);$payload=(array)($env['payload']??[]);if(!hash_equals((string)($env['payload_sha256']??''),PSERC_Stable_Json::hash($payload)))throw new RuntimeException('PSERC_PLAN_RECORD_PAYLOAD_HASH_MISMATCH_'.$kind.'_'.$index);if(!hash_equals((string)($env['record_sha256']??''),self::recordHash($env)))throw new RuntimeException('PSERC_PLAN_RECORD_HASH_MISMATCH_'.$kind.'_'.$index);}
    private static function assertNamed(array $env,string $generation,string $kind,string $name): void {if(($env['contract']??'')!==self::NAMED_CONTRACT||!hash_equals($generation,(string)($env['generation']??''))||!hash_equals($kind,(string)($env['kind']??''))||!hash_equals(hash('sha256',$name),(string)($env['name_sha256']??'')))throw new RuntimeException('PSERC_PLAN_NAMED_BINDING_MISMATCH_'.$kind);$payload=(array)($env['payload']??[]);if(!hash_equals((string)($env['payload_sha256']??''),PSERC_Stable_Json::hash($payload))||!hash_equals((string)($env['record_sha256']??''),self::namedHash($env)))throw new RuntimeException('PSERC_PLAN_NAMED_HASH_MISMATCH_'.$kind);}
}
