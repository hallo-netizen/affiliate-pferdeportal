<?php
if (!defined('ABSPATH')) { return; }

/**
 * Read-only semantic duplicate/cannibalisation gate.
 *
 * Root-cause invariant:
 * - semantic uniqueness is decided here, never by canonical plan-slot labels;
 * - canonical slots are technical capacity only;
 * - no article text, HTML, formatting or design is generated or changed;
 * - no runtime reassignment is performed.
 */
final class PSERC_Semantic_Duplicate_Gate {
    private const TITLE_BLOCK_JACCARD = 0.72;
    private const TITLE_REVIEW_JACCARD = 0.52;
    private const CORE_BLOCK_CONTAINMENT = 0.90;
    private const CORE_REVIEW_CONTAINMENT = 0.72;

    /** @return array<string,mixed> */
    public static function againstExisting(array $topic,array $snapshot): array {
        $title=self::identityTitle($topic);
        $exact=PSERC_Existing_Content_Reader::match($snapshot,$title);
        if($exact!==null){
            return self::result('BLOCKED_DUPLICATE',['EXISTING_CONTENT_EXACT_OR_IDENTITY_DUPLICATE'],[$exact]);
        }
        $matches=[];
        foreach((array)($snapshot['items']??[]) as $item){
            if(!is_array($item))continue;
            $cmp=self::compareTopicToExisting($topic,$item);
            if(($cmp['decision']??'PASS')!=='PASS')$matches[]=$cmp;
        }
        return self::aggregate($matches,'EXISTING_CONTENT');
    }

    /** @param list<array<string,mixed>> $acceptedTopics @return array<string,mixed> */
    public static function againstPreparedCandidates(array $topic,array $acceptedTopics): array {
        $matches=[];
        foreach($acceptedTopics as $other){
            if(!is_array($other))continue;
            $cmp=self::compareTopics($topic,$other);
            if(($cmp['decision']??'PASS')!=='PASS')$matches[]=$cmp;
        }
        return self::aggregate($matches,'METADATA_CANDIDATES');
    }

    /** Chunk-local exact/semantic scan using the unchanged comparison logic. @return array<string,mixed> */
    public static function scanExistingChunk(array $topic,array $items): array {
        $title=self::identityTitle($topic);$exact=PSERC_Existing_Content_Reader::match(['items'=>$items],$title);
        if($exact!==null)return ['exact'=>$exact,'matches'=>[]];$matches=[];
        foreach($items as $item){if(!is_array($item))continue;$cmp=self::compareTopicToExisting($topic,$item);if(($cmp['decision']??'PASS')!=='PASS')$matches[]=$cmp;}
        return ['exact'=>null,'matches'=>$matches];
    }
    /** @return list<array<string,mixed>> */
    public static function scanPreparedChunk(array $topic,array $items): array {$matches=[];foreach($items as $other){if(!is_array($other))continue;$cmp=self::compareTopics($topic,$other);if(($cmp['decision']??'PASS')!=='PASS')$matches[]=$cmp;}return $matches;}
    /** @return array<string,mixed> */
    public static function aggregateMatches(array $matches,string $scope): array {return self::aggregate($matches,$scope);}
    /** Exact-existing result with the identical legacy result envelope. @return array<string,mixed> */
    public static function exactExistingResult(array $exact): array {return self::result('BLOCKED_DUPLICATE',['EXISTING_CONTENT_EXACT_OR_IDENTITY_DUPLICATE'],[$exact]);}

    /** Precompute immutable duplicate-comparison input without changing the legacy algorithm. @return array<string,mixed> */
    public static function projectTopic(array $topic): array {
        $family=self::family($topic);$title=self::identityTitle($topic);$query=self::query($topic);
        return [
            'contract'=>'PSERC_DUPLICATE_PROJECTION_V1','kind'=>'TOPIC','family'=>$family,'family_tokens'=>self::tokens($family),'family_bucket'=>self::familyBucket($family),
            'title'=>$title,'query'=>$query,'article_type'=>trim((string)($topic['article_type']??'')),
            'title_base_tokens'=>self::tokens($title),'query_base_tokens'=>self::tokens($query!==''?$query:$title),
            'identity'=>['seo_topic_id'=>(string)($topic['candidate_id']??$topic['pool_key']??''),'category_slug'=>(string)($topic['category_slug']??'')],
        ];
    }

    /** @return array<string,mixed> */
    public static function projectExisting(array $item): array {
        $family=self::existingFamily($item);$title=trim((string)($item['title']??''));
        return [
            'contract'=>'PSERC_DUPLICATE_PROJECTION_V1','kind'=>'EXISTING','family'=>$family,'family_tokens'=>self::tokens($family),'family_bucket'=>self::familyBucket($family),
            'title'=>$title,'query'=>$title,'article_type'=>trim((string)($item['article_type']??'')),
            'title_base_tokens'=>self::tokens($title),'query_base_tokens'=>self::tokens($title),
            'identity'=>['post_id'=>(int)($item['post_id']??0),'status'=>(string)($item['status']??''),'canonical_article_id'=>(string)($item['canonical_article_id']??''),'category_slug'=>(string)($item['category_slug']??'')],
            'exact'=>[
                'normalized_title'=>(string)($item['normalized_title']??''),
                'normalized_slug'=>(string)($item['normalized_slug']??''),
                'topic_identity'=>(string)($item['topic_identity']??''),
                'slug'=>(string)($item['slug']??''),
            ],
        ];
    }

    public static function familyBucketForProjection(array $projection): string {return (string)($projection['family_bucket']??'');}
    public static function familiesCompatible(array $a,array $b): bool {
        $ta=(array)($a['family_tokens']??[]);$tb=(array)($b['family_tokens']??[]);
        return $ta&&$tb&&self::containment($ta,$tb)>=0.90;
    }

    /** @return list<array{name:string,reason:string,priority:int}> */
    public static function exactLookupKeysForTopic(array $topic): array {
        $title=self::identityTitle($topic);$k=PSERC_Existing_Content_Reader::duplicateIdentityKeys($title);$out=[];
        if((string)($k['normalized_title']??'')!=='')$out[]=['name'=>'title:'.$k['normalized_title'],'reason'=>'EXACT_NORMALIZED_TITLE','priority'=>0];
        if((string)($k['normalized_slug']??'')!=='')$out[]=['name'=>'slug:'.$k['normalized_slug'],'reason'=>'NORMALIZED_SLUG','priority'=>1];
        if((string)($k['topic_identity']??'')!=='')$out[]=['name'=>'identity:'.$k['topic_identity'],'reason'=>'SEMANTIC_TOPIC_IDENTITY','priority'=>2];
        return $out;
    }

    /** @return list<array{name:string,reason:string,priority:int}> */
    public static function exactIndexEntriesForExisting(array $projection): array {
        $e=(array)($projection['exact']??[]);$out=[];
        if((string)($e['normalized_title']??'')!=='')$out[]=['name'=>'title:'.$e['normalized_title'],'reason'=>'EXACT_NORMALIZED_TITLE','priority'=>0];
        if((string)($e['normalized_slug']??'')!=='')$out[]=['name'=>'slug:'.$e['normalized_slug'],'reason'=>'NORMALIZED_SLUG','priority'=>1];
        if((string)($e['topic_identity']??'')!=='')$out[]=['name'=>'identity:'.$e['topic_identity'],'reason'=>'SEMANTIC_TOPIC_IDENTITY','priority'=>2];
        return $out;
    }

    /** @return array<string,mixed> */
    public static function exactMatchEnvelope(array $projection,string $reason): array {
        $i=(array)($projection['identity']??[]);$e=(array)($projection['exact']??[]);
        return ['reason'=>$reason,'post_id'=>(int)($i['post_id']??0),'status'=>(string)($i['status']??''),'title'=>(string)($projection['title']??''),'slug'=>(string)($e['slug']??''),'canonical_article_id'=>(string)($i['canonical_article_id']??''),'topic_identity'=>(string)($e['topic_identity']??'')];
    }

    /** Bounded aggregate state; retains the exact legacy top-five and first-sorted representative of every reason. @return array<string,mixed> */
    public static function newAggregateState(string $scope): array {return ['contract'=>'PSERC_DUPLICATE_AGGREGATE_STATE_V1','scope'=>$scope,'top'=>[],'reason_best'=>[]];}
    public static function mergeAggregateState(array $state,array $matches): array {
        $pool=array_values(array_filter(array_merge((array)($state['top']??[]),$matches),'is_array'));self::sortMatches($pool);$state['top']=array_slice($pool,0,5);
        $rb=(array)($state['reason_best']??[]);
        foreach($matches as $m){if(!is_array($m))continue;foreach((array)($m['reason_codes']??[]) as $reason){$reason=(string)$reason;if($reason==='')continue;if(!isset($rb[$reason])){$rb[$reason]=$m;continue;}$pair=[$rb[$reason],$m];self::sortMatches($pair);$rb[$reason]=$pair[0];}}
        $state['reason_best']=$rb;return $state;
    }
    public static function finalizeAggregateState(array $state): array {
        $top=(array)($state['top']??[]);if(!$top)return self::result('PASS',[],[],['scope'=>(string)($state['scope']??'')]);
        self::sortMatches($top);$decision=(string)($top[0]['decision']??'REVIEW_REQUIRED');
        $reasonRows=[];foreach((array)($state['reason_best']??[]) as $reason=>$m)$reasonRows[]=['reason'=>(string)$reason,'match'=>(array)$m];
        usort($reasonRows,static function($a,$b){$pair=[(array)$a['match'],(array)$b['match']];self::sortMatches($pair);if($pair[0]===(array)$a['match']&&$pair[0]!== (array)$b['match'])return -1;if($pair[0]===(array)$b['match']&&$pair[0]!== (array)$a['match'])return 1;return strcmp((string)$a['reason'],(string)$b['reason']);});
        $reasons=array_map(static fn($x)=>(string)$x['reason'],$reasonRows);
        $final=array_slice($top,0,5);foreach($final as &$m)unset($m['_projection_source_order']);unset($m);return self::result($decision,$reasons,$final,['scope'=>(string)($state['scope']??'')]);
    }

    /** @return list<array<string,mixed>> */
    public static function scanExistingProjectedChunk(array $topicProjection,array $rows): array {
        $matches=[];foreach($rows as $p){if(!is_array($p)||!self::familiesCompatible($topicProjection,$p))continue;$cmp=self::compareProjected($topicProjection,$p);if(($cmp['decision']??'PASS')!=='PASS')$matches[]=$cmp;}return $matches;
    }
    /** @return list<array<string,mixed>> */
    public static function scanPreparedProjectedChunk(array $topicProjection,array $rows): array {
        $matches=[];foreach($rows as $p){if(!is_array($p)||!self::familiesCompatible($topicProjection,$p))continue;$cmp=self::compareProjected($topicProjection,$p);if(($cmp['decision']??'PASS')!=='PASS')$matches[]=$cmp;}return $matches;
    }

    private static function compareProjected(array $a,array $b): array {
        $familyA=(string)($a['family']??'');$familyTokens=(array)($a['family_tokens']??[]);
        if($familyA===''||!self::familiesCompatible($a,$b))return ['decision'=>'PASS'];
        $titleA=(string)($a['title']??'');$queryA=(string)($a['query']??'');$typeA=(string)($a['article_type']??'');
        $titleB=(string)($b['title']??'');$queryB=(string)($b['query']??'');$typeB=(string)($b['article_type']??'');
        $titleTokensA=self::semanticTokensFromBase((array)($a['title_base_tokens']??[]),$familyTokens);
        $titleTokensB=self::semanticTokensFromBase((array)($b['title_base_tokens']??[]),$familyTokens);
        $queryTokensA=self::semanticTokensFromBase((array)($a['query_base_tokens']??[]),$familyTokens);
        $queryTokensB=self::semanticTokensFromBase((array)($b['query_base_tokens']??[]),$familyTokens);
        $out=self::compareTokenSets($titleA,$queryA,$typeA,$familyA,$titleB,$queryB,$typeB,$titleTokensA,$titleTokensB,$queryTokensA,$queryTokensB,(array)($b['identity']??[]));$out['_projection_source_order']=(int)($b['_projection_source_order']??PHP_INT_MAX);return $out;
    }
    /** @param list<string> $base @param list<string> $familyTokens @return list<string> */
    private static function semanticTokensFromBase(array $base,array $familyTokens): array {
        $stop=self::stopWords();$family=array_fill_keys($familyTokens,true);$out=[];
        foreach($base as $t){$t=(string)$t;if($t===''||isset($stop[$t])||isset($family[$t]))continue;$out[$t]=true;}$out=array_keys($out);sort($out,SORT_STRING);return $out;
    }
    /** @return array<string,bool> */
    private static function stopWords(): array {
        static $map=null;if($map!==null)return $map;$list=['der','die','das','den','dem','des','ein','eine','einer','einem','einen','und','oder','von','fuer','bei','beim','im','in','auf','mit','zu','zum','zur','am','an','als','aus','durch','nach','vor','ueber','unter','ich','du','man','muss','muessen','soll','sollte','sollen','ist','sind','war','werden','wird','was','wie','welche','welcher','welches','welchen','wann','warum','wieso','weshalb','worauf','kann','koennen','darf','duerfen','gibt','braucht','benoetigt','richtig','klar','fachgerecht','wichtig','wichtige','sinnvoll','sinnvolle','beurteilen','einordnen','umsetzen','vorgehen','eigenschaft','eigenschaften'];$map=array_fill_keys($list,true);return $map;
    }
    private static function familyBucket(string $family): string {$t=self::tokens($family);return $t?substr(hash('sha256',implode('|',$t)),0,16):'none';}
    private static function sortMatches(array &$matches): void {
        usort($matches,static function($a,$b){$rank=['BLOCKED_DUPLICATE'=>0,'REVIEW_REQUIRED'=>1,'PASS'=>2];return [($rank[$a['decision']??'PASS']??9),-(float)($a['title_jaccard']??0),-(float)($a['core_containment']??0),(string)($a['other_title']??''),(int)($a['_projection_source_order']??PHP_INT_MAX)]<=>[($rank[$b['decision']??'PASS']??9),-(float)($b['title_jaccard']??0),-(float)($b['core_containment']??0),(string)($b['other_title']??''),(int)($b['_projection_source_order']??PHP_INT_MAX)];});
    }
    /** @return array<string,mixed> */
    private static function compareTokenSets(string $titleA,string $queryA,string $typeA,string $familyA,string $titleB,string $queryB,string $typeB,array $titleTokensA,array $titleTokensB,array $queryTokensA,array $queryTokensB,array $identity): array {
        $titleJ=self::jaccard($titleTokensA,$titleTokensB);$titleContain=self::containment($titleTokensA,$titleTokensB);$coreContain=self::containment($queryTokensA,$queryTokensB);$coreInter=count(array_intersect($queryTokensA,$queryTokensB));$sameType=self::norm($typeA)!==''&&self::norm($typeA)===self::norm($typeB);$exactCore=$queryTokensA&&$queryTokensB&&$queryTokensA===$queryTokensB;$smallCore=min(count($queryTokensA),count($queryTokensB));$reasons=[];$decision='PASS';
        if($sameType&&(($titleJ>=self::TITLE_BLOCK_JACCARD&&count(array_intersect($titleTokensA,$titleTokensB))>=2)||$exactCore||($smallCore>=1&&$coreContain>=self::CORE_BLOCK_CONTAINMENT&&$coreInter===$smallCore&&$titleContain>=0.45))){$decision='BLOCKED_DUPLICATE';$reasons[]='HIGH_CONFIDENCE_SAME_FAMILY_SAME_TYPE_ANSWER_OVERLAP';}
        elseif(!$sameType&&$smallCore>=1&&$coreContain>=self::CORE_BLOCK_CONTAINMENT&&$coreInter===$smallCore){$decision='REVIEW_REQUIRED';$reasons[]='CROSS_TYPE_SAME_FAMILY_CORE_OVERLAP';}
        elseif($titleJ>=self::TITLE_REVIEW_JACCARD&&count(array_intersect($titleTokensA,$titleTokensB))>=2){$decision='REVIEW_REQUIRED';$reasons[]='STRONG_TITLE_SEMANTIC_OVERLAP';}
        elseif($smallCore>=2&&$coreContain>=self::CORE_REVIEW_CONTAINMENT&&$coreInter>=2){$decision='REVIEW_REQUIRED';$reasons[]='STRONG_QUERY_CORE_OVERLAP';}
        return array_merge(['decision'=>$decision,'reason_codes'=>$reasons,'same_family'=>true,'same_article_type'=>$sameType,'candidate_title'=>$titleA,'candidate_query'=>$queryA,'other_title'=>$titleB,'other_query'=>$queryB,'family'=>$familyA,'candidate_article_type'=>$typeA,'other_article_type'=>$typeB,'title_jaccard'=>round($titleJ,6),'title_containment'=>round($titleContain,6),'core_containment'=>round($coreContain,6),'core_intersection'=>$coreInter,'candidate_core_tokens'=>$queryTokensA,'other_core_tokens'=>$queryTokensB,'comparison_basis'=>'FAMILY_SCOPED_TOKEN_OVERLAP_MANUAL_TITLE_OVERRIDE_HAS_ZERO_IDENTITY_AUTHORITY_NO_CANONICAL_SLOT_LABELS_NO_WORKING_TITLE_AUTHORITY'],$identity);
    }

    /** @return array<string,mixed> */
    private static function aggregate(array $matches,string $scope): array {
        if(!$matches)return self::result('PASS',[],[],['scope'=>$scope]);
        usort($matches,static function($a,$b){
            $rank=['BLOCKED_DUPLICATE'=>0,'REVIEW_REQUIRED'=>1,'PASS'=>2];
            return [($rank[$a['decision']??'PASS']??9),-(float)($a['title_jaccard']??0),-(float)($a['core_containment']??0),(string)($a['other_title']??'')]
                <=>[($rank[$b['decision']??'PASS']??9),-(float)($b['title_jaccard']??0),-(float)($b['core_containment']??0),(string)($b['other_title']??'')];
        });
        $decision=(string)($matches[0]['decision']??'REVIEW_REQUIRED');
        $reasons=[];foreach($matches as $m){foreach((array)($m['reason_codes']??[]) as $r)$reasons[(string)$r]=true;}
        return self::result($decision,array_keys($reasons),array_slice($matches,0,5),['scope'=>$scope]);
    }

    /** @return array<string,mixed> */
    private static function compareTopicToExisting(array $topic,array $item): array {
        $familyA=self::family($topic);
        $familyB=self::existingFamily($item);
        if($familyA===''||$familyB===''||!self::sameFamily($familyA,$familyB))return ['decision'=>'PASS'];
        $titleA=self::identityTitle($topic);
        $titleB=trim((string)($item['title']??''));
        $typeA=trim((string)($topic['article_type']??''));
        $typeB=trim((string)($item['article_type']??''));
        return self::compare($titleA,self::query($topic),$typeA,$familyA,$titleB,$titleB,$typeB,$familyB,[
            'post_id'=>(int)($item['post_id']??0),'status'=>(string)($item['status']??''),'canonical_article_id'=>(string)($item['canonical_article_id']??''),'category_slug'=>(string)($item['category_slug']??''),
        ]);
    }

    /** @return array<string,mixed> */
    private static function compareTopics(array $a,array $b): array {
        $familyA=self::family($a);$familyB=self::family($b);
        if($familyA===''||$familyB===''||!self::sameFamily($familyA,$familyB))return ['decision'=>'PASS'];
        return self::compare(
            self::identityTitle($a),self::query($a),trim((string)($a['article_type']??'')),$familyA,
            self::identityTitle($b),self::query($b),trim((string)($b['article_type']??'')),$familyB,
            ['seo_topic_id'=>(string)($b['candidate_id']??$b['pool_key']??''),'category_slug'=>(string)($b['category_slug']??'')]
        );
    }

    /** @return array<string,mixed> */
    private static function compare(string $titleA,string $queryA,string $typeA,string $familyA,string $titleB,string $queryB,string $typeB,string $familyB,array $identity): array {
        $familyTokens=self::tokens($familyA);
        $titleTokensA=self::semanticTokens($titleA,$familyTokens);
        $titleTokensB=self::semanticTokens($titleB,$familyTokens);
        $queryTokensA=self::semanticTokens($queryA!==''?$queryA:$titleA,$familyTokens);
        $queryTokensB=self::semanticTokens($queryB!==''?$queryB:$titleB,$familyTokens);
        $titleJ=self::jaccard($titleTokensA,$titleTokensB);
        $titleContain=self::containment($titleTokensA,$titleTokensB);
        $coreContain=self::containment($queryTokensA,$queryTokensB);
        $coreInter=count(array_intersect($queryTokensA,$queryTokensB));
        $sameType=self::norm($typeA)!==''&&self::norm($typeA)===self::norm($typeB);
        $exactCore=$queryTokensA&&$queryTokensB&&$queryTokensA===$queryTokensB;
        $smallCore=min(count($queryTokensA),count($queryTokensB));
        $reasons=[];$decision='PASS';

        // High-confidence duplicate: same family + same article type + either strong title paraphrase
        // or the same/contained distinctive query core. This is type-agnostic with respect to slots.
        if($sameType&&(
            ($titleJ>=self::TITLE_BLOCK_JACCARD&&count(array_intersect($titleTokensA,$titleTokensB))>=2)
            ||$exactCore
            ||($smallCore>=1&&$coreContain>=self::CORE_BLOCK_CONTAINMENT&&$coreInter===$smallCore&&$titleContain>=0.45)
        )){
            $decision='BLOCKED_DUPLICATE';$reasons[]='HIGH_CONFIDENCE_SAME_FAMILY_SAME_TYPE_ANSWER_OVERLAP';
        }elseif(!$sameType&&$smallCore>=1&&$coreContain>=self::CORE_BLOCK_CONTAINMENT&&$coreInter===$smallCore){
            // Same feature/action across different article types is not silently declared a duplicate:
            // it needs a human scope decision because FAQ/advice/comparison can legitimately differ.
            $decision='REVIEW_REQUIRED';$reasons[]='CROSS_TYPE_SAME_FAMILY_CORE_OVERLAP';
        }elseif($titleJ>=self::TITLE_REVIEW_JACCARD&&count(array_intersect($titleTokensA,$titleTokensB))>=2){
            $decision='REVIEW_REQUIRED';$reasons[]='STRONG_TITLE_SEMANTIC_OVERLAP';
        }elseif($smallCore>=2&&$coreContain>=self::CORE_REVIEW_CONTAINMENT&&$coreInter>=2){
            $decision='REVIEW_REQUIRED';$reasons[]='STRONG_QUERY_CORE_OVERLAP';
        }

        return array_merge([
            'decision'=>$decision,'reason_codes'=>$reasons,'same_family'=>true,'same_article_type'=>$sameType,
            'candidate_title'=>$titleA,'candidate_query'=>$queryA,'other_title'=>$titleB,'other_query'=>$queryB,
            'family'=>$familyA,'candidate_article_type'=>$typeA,'other_article_type'=>$typeB,
            'title_jaccard'=>round($titleJ,6),'title_containment'=>round($titleContain,6),'core_containment'=>round($coreContain,6),'core_intersection'=>$coreInter,
            'candidate_core_tokens'=>$queryTokensA,'other_core_tokens'=>$queryTokensB,
            'comparison_basis'=>'FAMILY_SCOPED_TOKEN_OVERLAP_MANUAL_TITLE_OVERRIDE_HAS_ZERO_IDENTITY_AUTHORITY_NO_CANONICAL_SLOT_LABELS_NO_WORKING_TITLE_AUTHORITY',
        ],$identity);
    }

    /** @return array<string,mixed> */
    private static function result(string $decision,array $reasons,array $matches,array $extra=[]): array {
        $status=match($decision){'BLOCKED_DUPLICATE'=>'PSERC_SEMANTIC_DUPLICATE_BLOCKED','REVIEW_REQUIRED'=>'PSERC_SEMANTIC_OVERLAP_REVIEW_REQUIRED',default=>'PSERC_SEMANTIC_DUPLICATE_PASS'};
        return array_merge(['ok'=>$decision==='PASS','decision'=>$decision,'status'=>$status,'reason_codes'=>array_values(array_unique(array_map('strval',$reasons))),'matches'=>$matches,'write_attempted'=>false],$extra);
    }

    private static function query(array $topic): string {
        $profile=is_array($topic['intent_profile']??null)?$topic['intent_profile']:[];
        foreach(['source_query','raw_user_question','primary_longtail_query','canonical_query'] as $k){$v=trim((string)($topic[$k]??''));if($v!=='')return $v;}
        $v=trim((string)($profile['raw_query']??''));if($v!=='')return $v;
        return self::identityTitle($topic);
    }
    private static function identityTitle(array $topic): string {
        $v=trim((string)($topic['semantic_identity_title']??''));if($v!=='')return $v;
        return trim((string)($topic['production_title']??''));
    }
    private static function family(array $topic): string {
        $profile=is_array($topic['intent_profile']??null)?$topic['intent_profile']:[];
        foreach([(string)($profile['family']??''),(string)($topic['topic_family_name']??''),(string)($topic['resolved_family']??'')] as $v){if(trim($v)!=='')return trim($v);}
        $name=trim((string)($topic['category_name']??''));
        return trim((string)preg_replace('/^[^\s]+\s+/u','',$name));
    }
    private static function existingFamily(array $item): string {
        $v=trim((string)($item['topic_family_name']??''));if($v!=='')return $v;
        $name=trim((string)($item['category_name']??''));return trim((string)preg_replace('/^[^\s]+\s+/u','',$name));
    }
    private static function sameFamily(string $a,string $b): bool {
        $ta=self::tokens($a);$tb=self::tokens($b);if(!$ta||!$tb)return false;
        return self::containment($ta,$tb)>=0.90;
    }

    /** @param list<string> $familyTokens @return list<string> */
    private static function semanticTokens(string $value,array $familyTokens): array {
        $stop=['der','die','das','den','dem','des','ein','eine','einer','einem','einen','und','oder','von','fuer','bei','beim','im','in','auf','mit','zu','zum','zur','am','an','als','aus','durch','nach','vor','ueber','unter','ich','du','man','muss','muessen','soll','sollte','sollen','ist','sind','war','werden','wird','was','wie','welche','welcher','welches','welchen','wann','warum','wieso','weshalb','worauf','kann','koennen','darf','duerfen','gibt','braucht','benoetigt','richtig','klar','fachgerecht','wichtig','wichtige','sinnvoll','sinnvolle','beurteilen','einordnen','umsetzen','vorgehen','eigenschaft','eigenschaften'];
        $family=array_fill_keys($familyTokens,true);$out=[];
        foreach(self::tokens($value) as $t){if(in_array($t,$stop,true)||isset($family[$t]))continue;$out[$t]=true;}
        $out=array_keys($out);sort($out,SORT_STRING);return $out;
    }
    /** @return list<string> */
    private static function tokens(string $value): array {
        $n=self::norm($value);$out=[];
        foreach(explode(' ',$n) as $t){if(strlen($t)<2)continue;$t=self::stem($t);if($t!=='')$out[$t]=true;}
        $out=array_keys($out);sort($out,SORT_STRING);return $out;
    }
    private static function stem(string $t): string {
        foreach(['ierungen','ierung','tionen','tion','ungen','ung','ern','en','er','es','e','n','s'] as $s){if(strlen($t)>strlen($s)+4&&str_ends_with($t,$s)){return substr($t,0,-strlen($s));}}
        return $t;
    }
    /** @param list<string> $a @param list<string> $b */
    private static function jaccard(array $a,array $b): float {if(!$a||!$b)return 0.0;$i=count(array_intersect($a,$b));$u=count(array_unique(array_merge($a,$b)));return $u?$i/$u:0.0;}
    /** @param list<string> $a @param list<string> $b */
    private static function containment(array $a,array $b): float {if(!$a||!$b)return 0.0;$i=count(array_intersect($a,$b));$m=min(count($a),count($b));return $m?$i/$m:0.0;}
    private static function norm(string $value): string {
        $value=strtr(trim($value),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss','–'=>' ','—'=>' ','-'=>' ']);
        $value=function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);
        $value=(string)preg_replace('/[^a-z0-9]+/u',' ',$value);return trim((string)preg_replace('/\s+/u',' ',$value));
    }
}
