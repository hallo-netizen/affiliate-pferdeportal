<?php
if (!defined('ABSPATH')) { return; }
final class PSERC_Plan_Metrics {
    public static function start(string $phase): array {return ['phase'=>$phase,'started'=>microtime(true),'memory_start'=>memory_get_usage(true),'queries_start'=>isset($GLOBALS['wpdb']->num_queries)?(int)$GLOBALS['wpdb']->num_queries:0];}
    public static function finish(array $m,int $recordsRead=0,int $recordsWritten=0,int $bytesRead=0): array {
        return ['phase'=>(string)($m['phase']??''),'wall_ms'=>(int)round((microtime(true)-(float)($m['started']??microtime(true)))*1000),'peak_bytes'=>memory_get_peak_usage(true),'memory_delta_bytes'=>max(0,memory_get_usage(true)-(int)($m['memory_start']??0)),'query_count'=>max(0,(isset($GLOBALS['wpdb']->num_queries)?(int)$GLOBALS['wpdb']->num_queries:0)-(int)($m['queries_start']??0)),'records_read'=>$recordsRead,'records_written'=>$recordsWritten,'bytes_read'=>$bytesRead];
    }
}
