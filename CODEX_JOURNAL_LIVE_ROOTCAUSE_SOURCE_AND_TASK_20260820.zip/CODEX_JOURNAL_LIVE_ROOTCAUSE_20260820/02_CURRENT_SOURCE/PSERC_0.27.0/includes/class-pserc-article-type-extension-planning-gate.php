<?php
if (!defined('ABSPATH')) { return; }

/** Generic read-only consistency gate for signed additive article-type extensions. */
final class PSERC_Article_Type_Extension_Planning_Gate {
    public const CONTRACT='PSERC_ARTICLE_TYPE_EXTENSION_PLANNING_GATE_V1';
    /** @return array<string,mixed> */
    public static function evaluate(array $topic,array $production): array {
        $type=trim((string)($topic['article_type']??''));$ext=PSERC_Article_Type_Extension_Registry::extension($type);if(!$ext)return self::blocked('EXTENSION_TYPE_NOT_REGISTERED');
        $proof=PSERC_Article_Type_Extension_Registry::verifyTopicBinding($topic);if(empty($proof['ok']))return self::blocked('EXTENSION_TOPIC_BINDING_INVALID',['extension_registry'=>$proof]);
        $routing=(array)($topic['article_type_extension_routing']??$topic['journal_routing']??[]);
        if(($routing['contract']??'')!=='PSTE_ARTICLE_TYPE_EXTENSION_ROUTE_V1'||($routing['status']??'')!=='EXTENSION_ROUTE_PASS'||empty($routing['ok'])||self::norm((string)($routing['article_type']??''))!==self::norm($type))return self::blocked('EXTENSION_ROUTING_PROOF_INVALID');
        $semantic=(array)($topic['semantic_consensus']??[]);if(($semantic['contract']??'')!=='PSTE_ARTICLE_TYPE_EXTENSION_CONSENSUS_V1'||($semantic['status']??'')!=='CONSENSUS_PASS'||empty($semantic['ok'])||empty($semantic['type_consensus'])||empty($semantic['category_consensus'])||empty($semantic['family_consensus'])||self::norm((string)($semantic['resolved_article_type']??''))!==self::norm($type))return self::blocked('EXTENSION_SEMANTIC_CONSENSUS_INVALID');
        if(($ext['fallback_activation_allowed']??true)!==false||($ext['self_generated_intent_allowed']??true)!==false)return self::blocked('EXTENSION_ACTIVATION_POLICY_INVALID');
        $topicTarget=['term_id'=>(int)($topic['category_id']??0),'name'=>trim((string)($topic['category_name']??'')),'slug'=>trim((string)($topic['category_slug']??''))];$routeTarget=(array)($routing['target_category']??[]);
        if($topicTarget['term_id']<=0||$topicTarget['name']===''||$topicTarget['slug']==='')return self::blocked('EXTENSION_CATEGORY_ASSIGNMENT_INCOMPLETE');
        if((int)($routeTarget['term_id']??0)!==$topicTarget['term_id']||!hash_equals(trim((string)($routeTarget['slug']??'')),$topicTarget['slug'])||strcasecmp(self::surface((string)($routeTarget['name']??'')),self::surface($topicTarget['name']))!==0)return self::blocked('EXTENSION_ROUTING_CATEGORY_MISMATCH');
        if(!self::categoryAllowed($ext,$topicTarget['slug']))return self::blocked('EXTENSION_CATEGORY_NOT_REGISTERED');
        $live=self::liveTermCheck($topicTarget);if(empty($live['ok']))return self::blocked('EXTENSION_LIVE_TERM_MISMATCH',['live_term_check'=>$live]);
        $slots=[];foreach((array)($production['plan']['slots']??[]) as $slot){if(!is_array($slot)||self::norm((string)($slot['article_type']??''))!==self::norm($type))continue;if((string)($slot['category_slug']??'')===$topicTarget['slug'])$slots[]=$slot;}
        if(!$slots)return self::blocked('EXTENSION_NO_SIGNED_CANONICAL_SLOT_FOR_CATEGORY');
        return ['contract'=>self::CONTRACT,'status'=>'PASS','ok'=>true,'reason_codes'=>[],'assigned_category_id'=>$topicTarget['term_id'],'assigned_category_name'=>$topicTarget['name'],'assigned_category_slug'=>$topicTarget['slug'],'assigned_article_type'=>$type,'canonical_plan_category_slug'=>(string)($routing['canonical_plan_category_slug']??''),'signed_plan_slot_available'=>true,'signed_plan_slot_count'=>count($slots),'canonical_article_ids'=>array_values(array_map(static fn($s)=>(string)($s['canonical_article_id']??''),$slots)),'live_term_check'=>$live,'extension_registry'=>$proof,'semantic_consensus_sha256'=>PSERC_Stable_Json::hash($semantic),'extension_routing_sha256'=>PSERC_Stable_Json::hash($routing),'write_attempted'=>false];
    }
    private static function categoryAllowed(array $ext,string $slug): bool {foreach((array)($ext['category_policy']['categories']??[]) as $c){$all=array_merge([(string)($c['canonical_plan_slug']??'')],array_map('strval',(array)($c['runtime_slugs']??[])));if(in_array($slug,$all,true))return true;}return false;}
    private static function liveTermCheck(array $target): array {if(!function_exists('get_term'))return ['ok'=>true,'status'=>'NOT_AVAILABLE_IN_LOCAL_TEST_ENV','read_only'=>true,'write_attempted'=>false];$term=get_term((int)$target['term_id'],'category');if(!$term||(function_exists('is_wp_error')&&is_wp_error($term)))return ['ok'=>false,'status'=>'TERM_NOT_FOUND','read_only'=>true,'write_attempted'=>false];$actual=['term_id'=>(int)($term->term_id??0),'name'=>trim((string)($term->name??'')),'slug'=>trim((string)($term->slug??'')),'taxonomy'=>trim((string)($term->taxonomy??''))];$ok=$actual['term_id']===(int)$target['term_id']&&hash_equals($actual['slug'],(string)$target['slug'])&&strcasecmp(self::surface($actual['name']),self::surface((string)$target['name']))===0&&$actual['taxonomy']==='category';return ['ok'=>$ok,'status'=>$ok?'LIVE_TERM_EXACT_PASS':'LIVE_TERM_EXACT_MISMATCH','actual'=>$actual,'read_only'=>true,'write_attempted'=>false];}
    private static function surface(string $v): string {return trim(html_entity_decode($v,ENT_QUOTES|ENT_HTML5,'UTF-8'));}
    private static function norm(string $v): string {$v=strtr(trim($v),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$v=function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);return trim((string)preg_replace('/[^a-z0-9]+/u','',$v));}
    private static function blocked(string $r,array $x=[]): array {return array_merge(['contract'=>self::CONTRACT,'status'=>'BLOCKED','ok'=>false,'reason_codes'=>[$r],'message'=>$r,'write_attempted'=>false],$x);}
}
