<?php
if (!defined('ABSPATH')) { return; }

/**
 * Constant-size dependency identity for the asynchronous plan snapshot.
 *
 * Important: this class deliberately does not hash the complete WordPress inventory,
 * topic payloads or the site baseline on normal admin reads. Relevant WordPress writes
 * advance narrow technical revisions; PSTE topic changes are represented by indexed
 * high-water marks plus the completed Context generation. This prevents an unrelated
 * draft from globally invalidating the Redaktionsplan while remaining fail-closed for
 * inputs actually consumed by the compiler.
 */
final class PSERC_Plan_Dependency_Fingerprint {
    public const CONTRACT='PSERC_PLAN_DEPENDENCY_FINGERPRINT_V3_COMPONENT_SCOPED';
    public const INVENTORY_REV_OPTION='pserc_plan_inventory_revision_v1';
    public const STRUCTURE_REV_OPTION='pserc_plan_structure_revision_v1';

    public static function initInvalidationHooks(): void {
        if(!function_exists('add_action'))return;
        add_action('save_post_post',[self::class,'onPostSaved'],100,3);
        add_action('transition_post_status',[self::class,'onPostTransition'],100,3);
        add_action('before_delete_post',[self::class,'onPostDelete'],10,2);
        add_action('set_object_terms',[self::class,'onObjectTerms'],100,6);
        foreach(['added_post_meta','updated_post_meta','deleted_post_meta'] as $hook)add_action($hook,[self::class,'onPostMeta'],100,4);
        foreach(['created_category','edited_category','delete_category'] as $hook)add_action($hook,[self::class,'onCategoryStructureChanged'],100,4);
        add_action('updated_option',[self::class,'onOptionUpdated'],100,3);
        add_action('added_option',[self::class,'onOptionAdded'],100,2);
        add_action('deleted_option',[self::class,'onOptionDeleted'],100,1);
    }

    /** @return array<string,mixed> */
    public static function current(?array $forcedCategoryIds=null): array {
        global $wpdb;
        $context=get_option(defined('PSTE_OPTION_CONTEXT_JOB')?PSTE_OPTION_CONTEXT_JOB:'pste_context_refresh_job_v1',[]);if(!is_array($context))$context=[];
        $schema=(string)get_option(defined('PSTE_OPTION_SCHEMA')?PSTE_OPTION_SCHEMA:'pste_schema_version','');
        $ids=[];
        if($forcedCategoryIds!==null){foreach($forcedCategoryIds as $id){$id=(int)$id;if($id>0)$ids[$id]=true;}}
        else{
            $baseline=get_option(defined('PSTE_OPTION_SITE_BASELINE')?PSTE_OPTION_SITE_BASELINE:'pste_site_baseline_v1',[]);if(!is_array($baseline))$baseline=[];
            foreach((array)($baseline['leaf_categories']??[]) as $leaf){$id=(int)($leaf['term_id']??0);if($id>0)$ids[$id]=true;}
        }
        $ids=array_values(array_map('intval',array_keys($ids)));sort($ids,SORT_NUMERIC);

        $topic=[];
        if(isset($wpdb)&&is_object($wpdb)&&method_exists($wpdb,'get_var')){
            $prefix=(string)($wpdb->prefix??'').'pste_';
            foreach(['topic_pool','topic_occurrences','topic_assignments','topic_history','runs'] as $suffix){
                $v=$wpdb->get_var('SELECT COALESCE(MAX(id),0) FROM '.$prefix.$suffix);
                if((string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSERC_PLAN_DEPENDENCY_TOPIC_WATERMARK_READ_FAILED_'.strtoupper($suffix));
                $topic[$suffix]=(int)$v;
            }
        }

        $gscProperty=(string)get_option(defined('PSTE_OPTION_GSC_SELECTED_PROPERTY')?PSTE_OPTION_GSC_SELECTED_PROPERTY:'pste_gsc_selected_property_v1','');
        $gscLast=get_option(defined('PSTE_OPTION_GSC_LAST_SYNC')?PSTE_OPTION_GSC_LAST_SYNC:'pste_gsc_last_sync_v1',[]);if(!is_array($gscLast))$gscLast=[];
        $structureComponent=[
            'schema'=>$schema,
            'context_status'=>(string)($context['status']??''),
            'context_generation'=>(int)($context['generation']??0),
            'final_structure_sha256'=>(string)($context['final_structure_sha256']??''),
            'final_plan_sha256'=>(string)($context['final_plan_sha256']??''),
            'structure_revision'=>(int)get_option(self::STRUCTURE_REV_OPTION,0),
        ];
        $topicComponent=[
            'pste_version'=>defined('PSTE_VERSION')?(string)PSTE_VERSION:'',
            'schema'=>$schema,
            'context_index_manifest_sha256'=>(string)($context['context_index_manifest_sha256']??''),
            'topic_watermarks'=>$topic,
            'gsc'=>[
                'property'=>$gscProperty,
                'synced_at_utc'=>(string)($gscLast['synced_at_utc']??''),
                'accepted_row_count'=>(int)($gscLast['accepted_row_count']??0),
                'source_row_count'=>(int)($gscLast['source_row_count']??0),
                'response_bundle_sha256'=>(string)($gscLast['response_bundle_sha256']??''),
            ],
        ];
        $inventoryComponent=['revision'=>(int)get_option(self::INVENTORY_REV_OPTION,0)];
        $payload=[
            'contract'=>self::CONTRACT,
            'production_category_ids'=>$ids,
            'context'=>[
                'status'=>(string)($context['status']??''),
                'generation'=>(int)($context['generation']??0),
                'job_uuid'=>(string)($context['job_uuid']??''),
                'final_structure_sha256'=>(string)($context['final_structure_sha256']??''),
                'final_plan_sha256'=>(string)($context['final_plan_sha256']??''),
                'context_index_manifest_sha256'=>(string)($context['context_index_manifest_sha256']??''),
            ],
            'structure_component'=>$structureComponent,
            'topic_component'=>$topicComponent,
            'inventory_component'=>$inventoryComponent,
        ];
        $payload['structure_source_sha256']=PSERC_Stable_Json::hash($structureComponent);
        $payload['topic_source_sha256']=PSERC_Stable_Json::hash($topicComponent);
        $payload['inventory_source_sha256']=PSERC_Stable_Json::hash($inventoryComponent);
        $payload['fingerprint_sha256']=PSERC_Stable_Json::hash($payload);
        return $payload;
    }

    public static function isCurrent(array $expected): bool {
        try{$now=self::current((array)($expected['production_category_ids']??[]));}catch(Throwable $e){return false;}
        $a=(string)($expected['fingerprint_sha256']??'');$b=(string)($now['fingerprint_sha256']??'');
        return preg_match('/^[a-f0-9]{64}$/',$a)&&hash_equals($a,$b);
    }
    public static function componentEqual(array $a,array $b,string $component): bool {$key=$component.'_source_sha256';$x=(string)($a[$key]??'');$y=(string)($b[$key]??'');return preg_match('/^[a-f0-9]{64}$/',$x)&&hash_equals($x,$y);}

    public static function onPostSaved(int $postId,$post,bool $update): void {if(self::postIsRelevant($postId,$post))self::bump(self::INVENTORY_REV_OPTION);}
    public static function onPostTransition(string $new,string $old,$post): void {$id=(int)($post->ID??0);if($id>0&&$new!==$old&&self::postIsRelevant($id,$post))self::bump(self::INVENTORY_REV_OPTION);}
    public static function onPostDelete(int $postId,$post=null): void {if(self::postIsRelevant($postId,$post))self::bump(self::INVENTORY_REV_OPTION);}
    public static function onPostMeta($metaId,$postId,$metaKey,$metaValue=null): void {if(!in_array((string)$metaKey,['_ppm679_canonical_article_id','_ppm679_plan_slot_sha256'],true))return;if(self::postIsRelevant((int)$postId,null))self::bump(self::INVENTORY_REV_OPTION);}

    public static function onObjectTerms($objectId,$terms,$ttIds,$taxonomy,$append,$oldTtIds): void {
        if((string)$taxonomy!=='category')return;$wanted=array_fill_keys(self::productionCategoryIds(),true);if(!$wanted)return;
        $termIds=[];
        if(function_exists('wp_get_post_categories'))foreach((array)wp_get_post_categories((int)$objectId,['fields'=>'ids']) as $id)$termIds[(int)$id]=true;
        foreach(self::termIdsFromTaxonomyIds(array_merge((array)$ttIds,(array)$oldTtIds)) as $id)$termIds[(int)$id]=true;
        foreach(array_keys($termIds) as $id)if(isset($wanted[(int)$id])){self::bump(self::INVENTORY_REV_OPTION);return;}
    }
    public static function onCategoryStructureChanged(...$args): void {self::bump(self::STRUCTURE_REV_OPTION);}
    public static function onOptionUpdated(string $option,$old,$new): void {
        if(in_array($option,[self::INVENTORY_REV_OPTION,self::STRUCTURE_REV_OPTION],true))return;
        $baseline=defined('PSTE_OPTION_SITE_BASELINE')?PSTE_OPTION_SITE_BASELINE:'pste_site_baseline_v1';
        if($option===$baseline){self::bump(self::STRUCTURE_REV_OPTION);return;}
        if($option==='ppm679_editorial_plan_runtime_state_v1')self::bump(self::INVENTORY_REV_OPTION);
    }
    public static function onOptionAdded(string $option,$value): void {self::onOptionUpdated($option,null,$value);}
    public static function onOptionDeleted(string $option): void {self::onOptionUpdated($option,null,null);}

    private static function postIsRelevant(int $postId,$post=null): bool {
        if($postId<=0)return false;
        if(is_object($post)&&isset($post->post_type)&&(string)$post->post_type!=='post')return false;
        if(function_exists('wp_is_post_revision')&&wp_is_post_revision($postId))return false;
        $wanted=array_fill_keys(self::productionCategoryIds(),true);if(!$wanted)return false;
        if(!function_exists('wp_get_post_categories'))return true; // fail closed when taxonomy read is unavailable
        $ids=wp_get_post_categories($postId,['fields'=>'ids']);if(!is_array($ids))return true;
        foreach($ids as $id)if(isset($wanted[(int)$id]))return true;
        return false;
    }
    /** @return list<int> */
    private static function productionCategoryIds(): array {
        if(class_exists('PSERC_Plan_Snapshot_Store')){$active=PSERC_Plan_Snapshot_Store::getActive();$ids=(array)($active['dependency']['production_category_ids']??[]);if($ids){$out=[];foreach($ids as $id){$id=(int)$id;if($id>0)$out[$id]=true;}return array_keys($out);}}
        $baseline=get_option(defined('PSTE_OPTION_SITE_BASELINE')?PSTE_OPTION_SITE_BASELINE:'pste_site_baseline_v1',[]);$out=[];foreach((array)($baseline['leaf_categories']??[]) as $leaf){$id=(int)($leaf['term_id']??0);if($id>0)$out[$id]=true;}return array_keys($out);
    }
    /** @return list<int> */
    private static function termIdsFromTaxonomyIds(array $ttIds): array {
        $ids=[];foreach($ttIds as $id){$id=(int)$id;if($id>0)$ids[$id]=true;}if(!$ids)return [];
        global $wpdb;if(!isset($wpdb)||!is_object($wpdb)||empty($wpdb->term_taxonomy)||!method_exists($wpdb,'get_col'))return [];
        $sql='SELECT term_id FROM '.$wpdb->term_taxonomy.' WHERE term_taxonomy_id IN ('.implode(',',array_map('intval',array_keys($ids))).')';return array_values(array_map('intval',(array)$wpdb->get_col($sql)));
    }
    private static function bump(string $option): void {$v=max(0,(int)get_option($option,0))+1;update_option($option,$v,false);}
}
