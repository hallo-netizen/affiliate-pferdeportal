<?php
if (!defined('ABSPATH')) { return; }

final class PSERC_Admin {
    private const SLUG='portal-seo-editorial-plan-compiler';
    private const NONCE='pserc_plan_compile_job_v1';

    public static function init(): void {
        add_action('admin_menu',[self::class,'menu'],40);
        add_action('admin_post_pserc_export_live_preview',[self::class,'exportLivePreview']);
        add_action('wp_ajax_pserc_plan_compile_start',[self::class,'ajaxStart']);
        add_action('wp_ajax_pserc_plan_compile_advance',[self::class,'ajaxAdvance']);
    }
    public static function menu(): void {$parent=class_exists('PSTE_Admin')?'portal-seo-topic-engine':null;if($parent)add_submenu_page($parent,'SEO Redaktionsplan','SEO Redaktionsplan','manage_options',self::SLUG,[self::class,'page']);else add_menu_page('SEO Redaktionsplan','SEO Redaktionsplan','manage_options',self::SLUG,[self::class,'page'],'dashicons-media-spreadsheet',59);}

    public static function page(): void {
        if(!current_user_can('manage_options'))return;
        echo '<div class="wrap"><h1>SEO-Redaktionsplan Metadaten-Vorschau <small>'.esc_html(defined('PSERC_BUILD')?PSERC_BUILD:PSERC_VERSION).'</small></h1>';
        echo '<div class="notice notice-info inline"><p><strong>Schreibfreier Metadatenmodus:</strong> Diese Seite liest ausschließlich einen bereits aufgebauten, hashgebundenen Plan-Snapshot. Der globale Compiler läuft nicht mehr im Seitenaufruf.</p></div>';
        $active=PSERC_Plan_Snapshot_Store::getActive();$current=PSERC_Plan_Snapshot_Store::verifyHeader($active)&&PSERC_Plan_Dependency_Fingerprint::isCurrent((array)($active['dependency']??[]));
        if($current){self::renderActive($active);echo '</div>';return;}
        $job=PSERC_Plan_Snapshot_Store::getJob();$view=(($job['contract']??'')===PSERC_Plan_Compile_Job::CONTRACT)?$job:[];
        if(($view['status']??'')==='BLOCKED'){
            self::renderBlocked((string)($view['error_code']??'PSERC_PLAN_BUILD_BLOCKED'),'Der technische Plan-Snapshot wurde fail-closed blockiert. Es wurde kein Artikel und kein Produktionsinhalt verändert.',['phase'=>$view['phase']??'','last_tick_metrics'=>$view['last_tick_metrics']??[]]);
            echo '<p><button class="button" id="pserc-plan-rebuild">Technischen Plan-Snapshot neu aufbauen</button></p>';
        } else {
            $phase=(string)($view['phase']??'START');$topics=(int)($view['topic_count']??0);$eligible=(int)($view['eligible_count']??0);$candidate=(int)($view['candidate_index']??0);$ready=(int)($view['ready_count']??0);
            echo '<div class="notice notice-warning inline" id="pserc-plan-status"><p><strong>Redaktionsplan wird request-begrenzt aufgebaut.</strong> <span id="pserc-plan-text">'.esc_html($phase).' · Themen '.$topics.' · geeignet '.$eligible.' · geprüft '.$candidate.' · READY '.$ready.'</span></p></div>';
        }
        self::renderJobScript(($view['status']??'')==='BLOCKED');echo '</div>';
    }

    private static function renderActive(array $header): void {
        $counts=(array)($header['counts']??[]);$descriptor=(array)($header['ready_batch_descriptor']??[]);$base=(array)($header['manifest_base']??[]);$bindings=(array)($base['bindings']??[]);$release=(array)($base['production_release']??[]);$generation=(string)($header['generation']??'');
        $afterTitle=isset($_GET['pserc_after_title'])?(string)wp_unslash($_GET['pserc_after_title']):'';$afterSeq=isset($_GET['pserc_after_seq'])?(int)$_GET['pserc_after_seq']:-1;$cursor=($afterTitle!==''&&$afterSeq>=0)?['title'=>$afterTitle,'seq'=>$afterSeq]:null;
        try{$page=PSERC_Plan_Snapshot_Store::getReadyPage($generation,$cursor,50);}catch(Throwable $e){self::renderBlocked('PSERC_PLAN_READY_PREVIEW_READ_FAILED','Der aktive Snapshot ist vorhanden, aber die gebundene READY-Vorschau konnte nicht verifiziert werden.',['detail'=>$e->getMessage()]);return;}
        $total=(int)($descriptor['item_count']??0);$items=[];foreach((array)($page['items']??[]) as $row)$items[]=(array)($row['binding']??[]);
        echo '<div class="notice notice-success inline"><p><strong>METADATEN-VORSCHAU PASS:</strong> Snapshot <code>'.esc_html(substr((string)($header['snapshot_sha256']??''),0,16)).'…</code> ist aktuell. '.esc_html((string)$total).' Position(en) enthalten je exakt fünf freigegebene Planungsfelder.</p></div>';
        echo '<p><strong>SEO:</strong> Version <code>'.esc_html((string)($bindings['seo_version']??'')).'</code>, Schema <code>'.esc_html((string)($bindings['seo_schema']??'')).'</code><br><strong>Textmaschine:</strong> Version <code>'.esc_html((string)($bindings['production_version']??'')).'</code><br><strong>Modus:</strong> <code>READ_ONLY_METADATA_ONLY</code> · <strong>Veröffentlichen:</strong> nein</p>';
        echo '<h2>Nächster reiner Metadatenblock</h2>';
        if(!$items)echo '<div class="notice notice-warning inline"><p>Aktuell ist kein vollständig kompatibler Metadatenblock verfügbar.</p></div>';
        else{echo '<table class="widefat striped"><thead><tr><th>Beitragsart</th><th>SEO-geprüfter Titel</th><th>Longtail-Zielkeyword</th><th>Kategorie</th><th>Planplatz</th></tr></thead><tbody>';foreach($items as $item){echo '<tr><td><strong>'.esc_html((string)($item['article_type']??'')).'</strong></td><td>'.esc_html((string)($item['title']??'')).'</td><td><code>'.esc_html((string)($item['target_keyword']??'')).'</code></td><td><code>'.esc_html((string)($item['category']??'')).'</code></td><td><code>'.esc_html((string)($item['plan_slot']??'')).'</code></td></tr>';}echo '</tbody></table>';if(empty($page['complete'])&&is_array($page['next_cursor']??null)){$c=(array)$page['next_cursor'];$url=add_query_arg(['page'=>self::SLUG,'pserc_after_title'=>(string)$c['title'],'pserc_after_seq'=>(int)$c['seq']],admin_url('admin.php'));echo '<p><a class="button" href="'.esc_url($url).'">Nächste 50 anzeigen</a></p>';}}
        echo '<h2>Gesamtstatus</h2><p><strong>SEO-Themen gesamt:</strong> '.esc_html((string)($counts['seo_all']??0)).' · <strong>geeignet:</strong> '.esc_html((string)($counts['seo_eligible']??0)).' · <strong>zurückgehalten:</strong> '.esc_html((string)($counts['seo_held']??0)).'<br><strong>Metadaten-Handoff bereit:</strong> '.esc_html((string)($counts['READY_FOR_METADATA_HANDOFF']??0)).' · <strong>Semantisch blockiert:</strong> '.esc_html((string)($counts['BLOCKED_EXISTING_CONTENT_DUPLICATE']??0)).' · <strong>Portalprüfung blockiert:</strong> '.esc_html((string)($counts['BLOCKED_PORTAL_TOPIC_EVIDENCE']??0)).'</p>';
        echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page='.self::SLUG)).'">Erste 50 anzeigen</a></p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pserc_export_live_preview');echo '<input type="hidden" name="action" value="pserc_export_live_preview">';submit_button('Reine Metadaten-Vorschau als JSON herunterladen','secondary','submit',false);echo '</form>';
        echo '<details style="margin-top:18px"><summary>Technische Bindungen anzeigen</summary><pre style="white-space:pre-wrap">'.esc_html(wp_json_encode(['snapshot_sha256'=>$header['snapshot_sha256']??'','system_boundary'=>$base['system_boundary']??[],'bindings'=>$bindings,'production_release'=>$release,'counts'=>$counts,'metrics'=>$header['metrics']??[]],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)).'</pre></details>';
        PSERC_Production_Trigger::renderPanel($descriptor,$release);
    }

    public static function exportLivePreview(): void {
        if(!current_user_can('manage_options'))wp_die('Nicht erlaubt.');check_admin_referer('pserc_export_live_preview');$header=PSERC_Plan_Snapshot_Store::getActive();if(!PSERC_Plan_Snapshot_Store::verifyHeader($header)||!PSERC_Plan_Dependency_Fingerprint::isCurrent((array)($header['dependency']??[])))wp_die('PSERC_PLAN_SNAPSHOT_STALE_OR_MISSING');
        try{$batch=PSERC_Plan_Snapshot_Store::materializeReadyBatch($header);$manifest=(array)$header['manifest_base'];$manifest['items']=[];$manifest['next_textmachine_metadata_batch']=$batch;$manifest['metadata_boundary']=PSERC_Metadata_Boundary::validateBatch($batch);$manifest['manifest_sha256']=PSERC_Stable_Json::hash($manifest);}catch(Throwable $e){wp_die('PSERC_PLAN_SNAPSHOT_EXPORT_BLOCKED: '.esc_html($e->getMessage()));}
        $json=wp_json_encode($manifest,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT|JSON_PRESERVE_ZERO_FRACTION);nocache_headers();header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="seo-redaktionsplan-metadaten-snapshot-'.(string)$header['snapshot_sha256'].'.json"');echo $json;exit;
    }

    public static function ajaxStart(): void {self::ajaxGuard();self::emitJson(PSERC_Plan_Compile_Job::start());}
    public static function ajaxAdvance(): void {self::ajaxGuard();self::emitJson(PSERC_Plan_Compile_Job::advance());}
    private static function ajaxGuard(): void {if(!current_user_can('manage_options'))self::emitJson(['ok'=>false,'status'=>'BLOCKED','error_code'=>'PSERC_PLAN_CAPABILITY_BLOCKED'],403);check_ajax_referer(self::NONCE,'nonce');}
    private static function emitJson(array $payload,int $status=200): void {if(function_exists('wp_send_json'))wp_send_json($payload,$status);header('Content-Type: application/json; charset=utf-8',true,$status);echo json_encode($payload);exit;}

    private static function renderJobScript(bool $blocked): void {
        $nonce=wp_create_nonce(self::NONCE);$ajax=admin_url('admin-ajax.php');$startAction=$blocked?'pserc_plan_compile_start':'pserc_plan_compile_start';
        echo '<script>(function(){const ajax='.wp_json_encode($ajax).',nonce='.wp_json_encode($nonce).';let stopped=false,requests=0;const max=20000;const status=document.getElementById("pserc-plan-text");function text(v){if(status)status.textContent=v;}async function call(action){const body=new URLSearchParams({action,nonce});const c=new AbortController();const t=setTimeout(()=>c.abort(),20000);let r;try{r=await fetch(ajax,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"},body:body.toString(),signal:c.signal});}finally{clearTimeout(t);}let j;try{j=await r.json();}catch(e){throw new Error("PSERC_PLAN_AJAX_INVALID_JSON_HTTP_"+r.status);}if(!r.ok||!j)return Promise.reject(new Error((j&&j.error_code)||("PSERC_PLAN_AJAX_HTTP_"+r.status)));return j;}async function loop(force){if(stopped||requests++>max)return;try{let j=await call(force?"pserc_plan_compile_start":"pserc_plan_compile_start");force=false;if(j.status==="COMPLETE"){location.reload();return;}if(j.status==="BLOCKED"){text("BLOCKED · "+(j.error_code||"UNKNOWN"));stopped=true;return;}while(!stopped&&requests++<max){j=await call("pserc_plan_compile_advance");text((j.phase||"")+" · Themen "+(j.topic_count||0)+" · geeignet "+(j.eligible_count||0)+" · geprüft "+(j.candidate_index||0)+" · READY "+(j.ready_count||0));if(j.status==="COMPLETE"){location.reload();return;}if(j.status==="BLOCKED"){text("BLOCKED · "+(j.error_code||"UNKNOWN")+" · Phase "+(j.phase||""));stopped=true;return;}await new Promise(r=>setTimeout(r,50));}}catch(e){text("BLOCKED · "+e.message);stopped=true;}}const b=document.getElementById("pserc-plan-rebuild");if(b)b.addEventListener("click",()=>{b.disabled=true;stopped=false;requests=0;loop(true);});'.($blocked?'':'loop(false);').'})();</script>';
    }

    /** @param array<string,mixed> $context */
    private static function renderBlocked(string $code,string $message,array $context=[]): void {echo '<div class="notice notice-error inline"><p><strong>METADATEN-VORSCHAU BLOCKED:</strong> <code>'.esc_html($code).'</code><br>'.esc_html($message).'<br><strong>Es wurde nichts an Artikeln verändert.</strong></p>';if($context)echo '<details open><summary><strong>Technische Ursache</strong></summary><pre style="white-space:pre-wrap">'.esc_html(wp_json_encode($context,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)).'</pre></details>';echo '</div>';}
}
