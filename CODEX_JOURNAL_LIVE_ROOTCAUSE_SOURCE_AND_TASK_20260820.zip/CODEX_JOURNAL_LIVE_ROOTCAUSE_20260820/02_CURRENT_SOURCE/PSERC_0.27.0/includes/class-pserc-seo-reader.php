<?php
if (!defined('ABSPATH')) { return; }

/** Read-only adapter for the active SEO topic engine. */
final class PSERC_SEO_Reader {

    public static function snapshot(): array {
        $sourceBinding=PSERC_SEO_Source_Binding::validate();
        if(empty($sourceBinding['ok']))return self::blocked((string)$sourceBinding['status'],(string)($sourceBinding['message']??'PSERC_SEO_SOURCE_BINDING_BLOCKED'),['source_binding'=>$sourceBinding]);
        if (!class_exists('PSTE_Plugin')||!class_exists('PSTE_Repository')||!class_exists('PSTE_Editorializer')) {
            return self::blocked('PSERC_SEO_ENGINE_UNAVAILABLE','Die aktive Portal SEO Themenengine ist nicht vollständig geladen.');
        }
        if (!method_exists('PSTE_Plugin','isReady')||!PSTE_Plugin::isReady()) {
            return self::blocked('PSERC_SEO_ENGINE_NOT_READY','Die Portal SEO Themenengine ist nicht READY.');
        }
        $schema=(string)get_option(defined('PSTE_OPTION_SCHEMA')?PSTE_OPTION_SCHEMA:'pste_schema_version','');
        $expectedSchema=(string)($sourceBinding['engine_schema']??'');
        if ($expectedSchema===''||!hash_equals($expectedSchema,$schema)) {
            return self::blocked(
                'PSERC_SEO_SCHEMA_UNSUPPORTED',
                'Das Laufzeitschema der SEO-Themenengine stimmt nicht mit dem stabilen Lesefähigkeitsvertrag überein.',
                ['expected'=>$expectedSchema,'actual'=>$schema]
            );
        }
        $all=PSTE_Repository::allCandidates();
        if (!is_array($all)) { return self::blocked('PSERC_SEO_TOPIC_READ_FAILED','Der Themenpool konnte nicht gelesen werden.'); }
        $priorityMap=[];
        if (class_exists('PSTE_Analytics')&&method_exists('PSTE_Analytics','priorities')) {
            foreach ((array)PSTE_Analytics::priorities() as $row) {
                $candidateId=(string)($row['candidate_id']??'');
                if ($candidateId!=='') { $priorityMap[$candidateId]=$row; }
            }
        }
        $eligible=[];$held=[];
        foreach ($all as $candidate) {
            if (!is_array($candidate)) { continue; }
            $candidateId=(string)($candidate['candidate_id']??'');
            if ($candidateId!==''&&isset($priorityMap[$candidateId])) {
                $candidate['priority_score']=(float)($priorityMap[$candidateId]['priority_score']??0);
                $candidate['search_intent']=$candidate['search_intent']??($priorityMap[$candidateId]['intent']??'');
            }
            $normalized=self::normalizeCandidate($candidate);
            if ($normalized['eligibility_status']==='ELIGIBLE') { $eligible[]=$normalized; }
            else { $held[]=$normalized; }
        }
        usort($eligible,static fn($a,$b)=>[-(float)$a['priority_score'],$a['allocation_order_title'],$a['pool_key']]<=>[-(float)$b['priority_score'],$b['allocation_order_title'],$b['pool_key']]);
        return [
            'ok'=>true,
            'status'=>'SEO_TOPIC_POOL_READ_ONLY_PASS',
            'version'=>defined('PSTE_VERSION')?(string)PSTE_VERSION:'unknown',
            'schema'=>$schema,
            'source_binding_sha256'=>(string)$sourceBinding['binding_sha256'],
            'source_binding_file_count'=>(int)$sourceBinding['required_file_count'],
            'capability_binding_sha256'=>(string)($sourceBinding['capability_sha256']??''),
            'capability_required_symbol_count'=>(int)($sourceBinding['required_symbol_count']??0),
            'all_count'=>count($all),
            'eligible'=>$eligible,
            'held'=>$held,
            'eligible_count'=>count($eligible),
            'held_count'=>count($held),
            'snapshot_sha256'=>PSERC_Stable_Json::hash(['version'=>defined('PSTE_VERSION')?(string)PSTE_VERSION:'unknown','schema'=>$schema,'eligible'=>$eligible,'held'=>$held]),
            'write_attempted'=>false,
        ];
    }

    public static function normalizeCandidate(array $candidate): array {
        $forbiddenPayloadField=PSERC_Metadata_Boundary::forbiddenContentPath($candidate,'candidate');
        $status=strtoupper(trim((string)($candidate['pool_status']??$candidate['automatic_pool_status']??$candidate['decision']??'')));
        $decision=strtoupper(trim((string)($candidate['decision']??'')));
        $planning=strtoupper(trim((string)($candidate['planning_suitability']??'')));
        $role=strtoupper(trim((string)($candidate['topic_role']??$candidate['candidate_role']??'')));
        $light=strtoupper(trim((string)($candidate['traffic_light']['code']??'')));
        $title=class_exists('PSTE_Editorializer')?PSTE_Editorializer::displayTitle($candidate):(string)($candidate['editorial_title']??$candidate['canonical_query']??'');
        $manualOverride=is_array($candidate['manual_title_override']??null)?(array)$candidate['manual_title_override']:[];
        $allocationOrderTitle=(($manualOverride['contract']??'')==='PSTE_MANUAL_TITLE_OVERRIDE_V1'&&trim((string)($manualOverride['base_title']??''))!=='')?trim((string)$manualOverride['base_title']):trim($title);
        $type=trim((string)($candidate['suggested_article_type']??$candidate['proposed_article_type']??''));
        $categoryId=(int)($candidate['suggested_category_id']??$candidate['target_category_id']??0);
        $categoryName=trim((string)($candidate['suggested_category_name']??$candidate['target_category_name']??''));
        $categorySlug=trim((string)($candidate['suggested_category_slug']??$candidate['target_category_slug']??''));
        $categoryResolutionSource=$categorySlug!==''?'SEO_CANDIDATE_DIRECT':'';

        // 0.5.0 hard rule: no runtime editorial reassignment in the compiler.
        // Stored SEO metadata is read verbatim and then independently checked by
        // the semantic firewall. A wrong assignment is blocked, never repaired.
        if (isset($candidate['assignments'])&&is_array($candidate['assignments'])) {
            foreach ($candidate['assignments'] as $assignment) {
                if (!is_array($assignment)) { continue; }
                if ($categoryId<=0&&(int)($assignment['category_id']??0)>0) { $categoryId=(int)$assignment['category_id']; }
                if ($categoryName===''&&trim((string)($assignment['category_name']??''))!=='') { $categoryName=trim((string)$assignment['category_name']); }
                if ($type===''&&trim((string)($assignment['article_type']??''))!=='') { $type=trim((string)$assignment['article_type']); }
                $payload=is_array($assignment['payload']??null)?$assignment['payload']:[];
                if ($categorySlug===''&&trim((string)($payload['category_slug']??''))!=='') {
                    $categorySlug=trim((string)$payload['category_slug']);
                    $categoryResolutionSource='SEO_ASSIGNMENT_PAYLOAD';
                }
            }
        }
        if ($categorySlug===''&&$categoryId>0) {
            $resolved=self::categoryById($categoryId);
            if ($resolved['slug']!=='') {
                $categorySlug=$resolved['slug'];
                if ($categoryName===''&&$resolved['name']!=='') { $categoryName=$resolved['name']; }
                $categoryResolutionSource=$resolved['source'];
            }
        }
        $variant=trim((string)($candidate['editorial_variant_of']??''));
        $contextState=strtoupper(trim((string)($candidate['context_state']??'')));
        $handoffFields=array_values(array_map('strval',(array)($candidate['metadata_handoff_fields']??[])));$handoffStatus=(string)($candidate['textmachine_handoff_status']??'');$handoffContractOk=$handoffFields===['title','target_keyword','category','article_type','plan_slot']&&$handoffStatus==='READY_FOR_COMPILER_CAPABILITY_CHECK';
        $eligible=$forbiddenPayloadField===''&&$handoffContractOk&&$decision==='PASS'&&$planning==='YES'&&in_array($status,['PASS','APPROVED','AUTO_RESOLVED'],true)&&$role==='ARTICLE_TOPIC'&&$light==='GREEN'&&in_array($contextState,['CURRENT','NOT_REQUIRED'],true)&&$variant===''&&$title!==''&&$type!==''&&$categorySlug!=='';
        $reasons=[];
        if($forbiddenPayloadField!=='')$reasons[]='SEO_FORBIDDEN_CONTENT_OR_FORMAT_PAYLOAD';
        if(!$handoffContractOk)$reasons[]='SEO_EXACT_FIVE_FIELD_HANDOFF_CONTRACT_NOT_READY';
        if ($decision!=='PASS')$reasons[]='SEO_DECISION_NOT_PASS';
        if ($planning!=='YES')$reasons[]='SEO_PLANNING_NOT_YES';
        if (!in_array($status,['PASS','APPROVED','AUTO_RESOLVED'],true))$reasons[]='SEO_STATUS_NOT_RELEASED';
        if ($role!=='ARTICLE_TOPIC')$reasons[]='SEO_ROLE_NOT_ARTICLE_TOPIC';
        if ($light!=='GREEN')$reasons[]='SEO_TRAFFIC_LIGHT_NOT_GREEN';
        if (!in_array($contextState,['CURRENT','NOT_REQUIRED'],true))$reasons[]='SEO_PORTAL_CONTEXT_NOT_CURRENT';
        if ($variant!=='')$reasons[]='SEO_KEYWORD_VARIANT_NOT_PRODUCING';
        if ($title==='')$reasons[]='SEO_TITLE_MISSING';
        if ($type==='')$reasons[]='SEO_ARTICLE_TYPE_MISSING';
        if ($categorySlug==='')$reasons[]=$status==='REASSIGNED'?'SEO_REASSIGNED_CATEGORY_SLUG_UNRESOLVED':'SEO_CATEGORY_SLUG_MISSING';
        $priority=(float)($candidate['priority_score']??$candidate['metrics']['priority_score']??0.0);
        $normalized=[
            'pool_key'=>(string)($candidate['pool_key']??$candidate['global_topic_uuid']??''),
            'candidate_id'=>(string)($candidate['candidate_id']??''),
            'source_query'=>self::firstNonEmptyRawQuery($candidate),
            'raw_user_question'=>(string)($candidate['raw_user_question']??''),
            'primary_longtail_query'=>(string)($candidate['primary_longtail_query']??''),
            'canonical_query'=>(string)($candidate['canonical_query']??''),
            'topic_family_name'=>(string)($candidate['topic_family_name']??''),
            'topic_family_key'=>(string)($candidate['topic_family_key']??''),
            'production_title'=>trim($title),
            'allocation_order_title'=>$allocationOrderTitle,
            'semantic_identity_title'=>$allocationOrderTitle,
            'target_keyword'=>trim((string)($candidate['target_keyword']??'')),
            'target_keyword_contract'=>is_array($candidate['target_keyword_contract']??null)?$candidate['target_keyword_contract']:[],
            'article_type'=>$type,
            'category_id'=>$categoryId,
            'category_name'=>$categoryName,
            'category_slug'=>$categorySlug,
            'category_resolution_source'=>$categoryResolutionSource,
            'runtime_assignment_changed'=>false,
            'runtime_assignment_reason'=>'RUNTIME_REASSIGNMENT_DISABLED_FAIL_CLOSED',
            'search_intent'=>(string)($candidate['intent_profile']['search_intent']??$candidate['metrics']['search_intent']??$candidate['search_intent']??''),
            'intent_angle'=>(string)($candidate['intent_profile']['intent_angle']??$candidate['intent_angle']??''),
            'intent_profile'=>is_array($candidate['intent_profile']??null)?$candidate['intent_profile']:[],
            'intent_portfolio'=>array_values(array_filter((array)($candidate['intent_portfolio']??[]),'is_array')),
            'search_volume'=>(float)($candidate['metrics']['search_volume']??0),
            'priority_score'=>$priority,
            'context_state'=>$contextState,
            'portal_context'=>is_array($candidate['portal_context']??null)?$candidate['portal_context']:[],
            'research_context'=>is_array($candidate['research_context']??null)?$candidate['research_context']:[],
            'editorialization'=>is_array($candidate['editorialization']??null)?$candidate['editorialization']:[],
            'normalized_editorial_topic'=>(string)($candidate['normalized_editorial_topic']??''),
            'editorial_quality_gate'=>is_array($candidate['editorial_quality_gate']??null)?$candidate['editorial_quality_gate']:[],
            'editorial_dual_strand'=>is_array($candidate['editorial_dual_strand']??null)?$candidate['editorial_dual_strand']:[],
            'raw_keyword_preserved'=>(string)($candidate['raw_keyword_preserved']??''),
            'raw_keyword_sha256'=>(string)($candidate['raw_keyword_sha256']??''),
            'query_record'=>is_array($candidate['query_record']??null)?$candidate['query_record']:[],
            'query_aliases'=>array_values(array_filter((array)($candidate['query_aliases']??[]),'is_array')),
            'semantic_consensus'=>is_array($candidate['semantic_consensus']??null)?$candidate['semantic_consensus']:[],
            'domain_risk'=>is_array($candidate['domain_risk']??null)?$candidate['domain_risk']:[],
            'freshness'=>is_array($candidate['freshness']??null)?$candidate['freshness']:[],
            'title_quality'=>is_array($candidate['title_quality']??null)?$candidate['title_quality']:[],
            'language_quality'=>is_array($candidate['language_quality']??null)?$candidate['language_quality']:[],
            'pre_title_duplicate_gate'=>is_array($candidate['pre_title_duplicate_gate']??null)?$candidate['pre_title_duplicate_gate']:[],
            'category_gap_proposal'=>is_array($candidate['category_gap_proposal']??null)?$candidate['category_gap_proposal']:[],
            'article_type_registry_sha256'=>(string)($candidate['article_type_registry_sha256']??''),
            'research_job_contract'=>(string)($candidate['research_job_contract']??''),
            'research_run_status'=>(string)($candidate['research_run_status']??''),
            'metadata_handoff_fields'=>array_values(array_map('strval',(array)($candidate['metadata_handoff_fields']??[]))),
            'textmachine_handoff_status'=>(string)($candidate['textmachine_handoff_status']??''),
            'closest_existing_matches'=>array_values(array_filter((array)($candidate['closest_existing_matches']??[]),'is_array')),
            'evidence'=>array_values(array_filter((array)($candidate['evidence']??[]),'is_array')),
            'pool_status'=>$status,
            'decision'=>$decision,
            'planning_suitability'=>$planning,
            'topic_role'=>$role,
            'traffic_light'=>$light,
            'editorial_variant_of'=>$variant,
            'forbidden_payload_field'=>$forbiddenPayloadField,
            'reason_codes'=>array_values(array_unique(array_map('strval',(array)($candidate['reason_codes']??[])))),
            'eligibility_status'=>$eligible?'ELIGIBLE':'HELD',
            'eligibility_reasons'=>$reasons,
        ];
        if(PSERC_Article_Type_Extension_Registry::extension($type)){
            $normalized['article_type_extension_routing']=is_array($candidate['article_type_extension_routing']??null)?$candidate['article_type_extension_routing']:(is_array($candidate['journal_routing']??null)?$candidate['journal_routing']:[]);
            if($type==='Journal')$normalized['journal_routing']=$normalized['article_type_extension_routing']; // compatibility export only
        }
        return $normalized;
    }

    private static function categoryById(int $categoryId): array {
        $baselineKey=defined('PSTE_OPTION_SITE_BASELINE')?PSTE_OPTION_SITE_BASELINE:'pste_site_baseline_v1';
        $baseline=function_exists('get_option')?get_option($baselineKey,[]):[];
        foreach ((is_array($baseline)?(array)($baseline['leaf_categories']??[]):[]) as $category) {
            if ((int)($category['term_id']??0)!==$categoryId) { continue; }
            return [
                'slug'=>trim((string)($category['slug']??'')),
                'name'=>trim((string)($category['name']??'')),
                'source'=>'SEO_SITE_BASELINE_BY_ID',
            ];
        }
        if (function_exists('get_term')) {
            $term=get_term($categoryId);
            $valid=is_object($term)&&(!function_exists('is_wp_error')||!is_wp_error($term));
            if ($valid) {
                $slug=trim((string)($term->slug??''));
                if ($slug!=='') { return ['slug'=>$slug,'name'=>trim((string)($term->name??'')),'source'=>'WORDPRESS_TERM_BY_ID']; }
            }
        }
        return ['slug'=>'','name'=>'','source'=>''];
    }

    private static function blocked(string $status,string $message,array $extra=[]): array {
        return array_merge(['ok'=>false,'status'=>$status,'message'=>$message,'write_attempted'=>false],$extra);
    }
    private static function firstNonEmptyRawQuery(array $candidate): string {
        foreach(['raw_keyword_preserved','raw_user_question','primary_longtail_query','canonical_query'] as $field){$v=self::cleanRaw((string)($candidate[$field]??''));if($v!=='')return $v;}
        $record=is_array($candidate['query_record']??null)?(array)$candidate['query_record']:[];
        foreach(['raw_query','measured_query','language_corrected_query'] as $field){$v=self::cleanRaw((string)($record[$field]??''));if($v!=='')return $v;}
        return '';
    }
    private static function cleanRaw(string $v): string {$v=trim(html_entity_decode(strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8'));return trim((string)preg_replace('/\s+/u',' ',$v));}

}
