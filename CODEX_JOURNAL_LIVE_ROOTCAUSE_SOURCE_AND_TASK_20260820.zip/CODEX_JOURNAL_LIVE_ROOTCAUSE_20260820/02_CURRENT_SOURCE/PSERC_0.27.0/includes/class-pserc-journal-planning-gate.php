<?php
if (!defined('ABSPATH')) { return; }

/**
 * Journal-only read-only consistency gate.
 * It verifies the PSTE Journal routing result against the local Journal registration and,
 * when WordPress term APIs are available, against the current live category term.
 * It creates no category, plan slot, content, handoff or production output.
 */
final class PSERC_Journal_Planning_Gate {
    public const CONTRACT='PSERC_JOURNAL_PLANNING_GATE_V2_SIGNED_EXTENSION_EVIDENCE';

    /** @return array<string,mixed> */
    public static function evaluate(array $topic,array $production): array {
        if(self::norm((string)($topic['article_type']??''))!=='journal')return self::blocked('JOURNAL_TYPE_REQUIRED');
        $extension=PSERC_Article_Type_Extension_Registry::verifyTopicBinding($topic);
        if(empty($extension['ok']))return self::blocked('JOURNAL_EXTENSION_EVIDENCE_INVALID',['extension_registry'=>$extension]);
        $registration=(array)($production['journal_registration']??[]);
        if(empty($registration['ok'])||($registration['status']??'')!=='PSERC_JOURNAL_SIGNED_NORMAL_DRAFT_REGISTRATION_PASS')return self::blocked('JOURNAL_REGISTRATION_NOT_VALID');
        $routing=(array)($topic['journal_routing']??[]);
        if(($routing['contract']??'')!=='PSTE_JOURNAL_ROUTER_V2_EXPLICIT_EXTENSION_EVIDENCE_ONLY'||($routing['status']??'')!=='JOURNAL_ROUTE_PASS'||empty($routing['ok']))return self::blocked('JOURNAL_ROUTING_PROOF_INVALID');
        if(self::norm((string)($routing['article_type']??''))!=='journal')return self::blocked('JOURNAL_ROUTING_TYPE_MISMATCH');

        $topicTarget=['term_id'=>(int)($topic['category_id']??0),'name'=>trim((string)($topic['category_name']??'')),'slug'=>trim((string)($topic['category_slug']??''))];
        $routeTarget=(array)($routing['target_category']??[]);
        if($topicTarget['term_id']<=0||$topicTarget['name']===''||$topicTarget['slug']==='')return self::blocked('JOURNAL_CATEGORY_ASSIGNMENT_INCOMPLETE');
        if((int)($routeTarget['term_id']??0)!==$topicTarget['term_id'])return self::blocked('JOURNAL_ROUTING_CATEGORY_ID_MISMATCH');
        if(!hash_equals(trim((string)($routeTarget['slug']??'')),$topicTarget['slug']))return self::blocked('JOURNAL_ROUTING_CATEGORY_SLUG_MISMATCH');
        if(strcasecmp(self::nameSurface((string)($routeTarget['name']??'')),self::nameSurface($topicTarget['name']))!==0)return self::blocked('JOURNAL_ROUTING_CATEGORY_NAME_MISMATCH');

        $semantic=(array)($topic['semantic_consensus']??[]);
        if(($semantic['contract']??'')!=='PSTE_JOURNAL_ROUTING_CONSENSUS_V1'||($semantic['status']??'')!=='CONSENSUS_PASS'||empty($semantic['ok'])||empty($semantic['type_consensus'])||empty($semantic['category_consensus'])||empty($semantic['family_consensus']))return self::blocked('JOURNAL_SEMANTIC_CONSENSUS_INVALID');
        if(($semantic['selection_policy']??'')!=='EXPLICIT_JOURNAL_SCOPE_AND_INTENT_ONLY')return self::blocked('JOURNAL_SELECTION_POLICY_INVALID');
        if(self::norm((string)($semantic['resolved_article_type']??''))!=='journal')return self::blocked('JOURNAL_SEMANTIC_TYPE_MISMATCH');
        $resolved=(array)($semantic['resolved_category']??[]);
        if((int)($resolved['term_id']??0)!==$topicTarget['term_id']||!hash_equals(trim((string)($resolved['slug']??'')),$topicTarget['slug']))return self::blocked('JOURNAL_SEMANTIC_CATEGORY_MISMATCH');

        $bridge=self::bridgeForRuntimeSlug((array)($registration['category_bridge']??[]),$topicTarget['slug']);
        if(!$bridge)return self::blocked('JOURNAL_CATEGORY_NOT_REGISTERED',['category_slug'=>$topicTarget['slug']]);
        $routeCanonical=trim((string)($routing['canonical_plan_category_slug']??''));
        $semanticCanonical=trim((string)($semantic['canonical_plan_category_slug']??''));
        $bridgeCanonical=trim((string)($bridge['canonical_plan_slug']??''));
        if(!hash_equals($routeCanonical,$bridgeCanonical)||!hash_equals($semanticCanonical,$bridgeCanonical))return self::blocked('JOURNAL_CANONICAL_PLAN_CATEGORY_BINDING_MISMATCH');

        $live=self::liveTermCheck($topicTarget);
        if(empty($live['ok']))return self::blocked('JOURNAL_LIVE_TERM_MISMATCH',['live_term_check'=>$live]);

        return [
            'contract'=>self::CONTRACT,'status'=>'PSERC_JOURNAL_ASSIGNMENT_CONSISTENCY_PASS','ok'=>true,'reason_codes'=>[],
            'assigned_category_id'=>$topicTarget['term_id'],'assigned_category_name'=>$topicTarget['name'],'assigned_category_slug'=>$topicTarget['slug'],
            'assigned_article_type'=>'Journal','canonical_plan_category_slug'=>$bridgeCanonical,
            'signed_plan_slot_available'=>!empty($bridge['signed_plan_slot_available']),'signed_plan_slot_count'=>(int)($bridge['signed_plan_slot_count']??0),
            'category_bridge'=>$bridge,'live_term_check'=>$live,'extension_registry'=>$extension,
            'semantic_consensus_sha256'=>PSERC_Stable_Json::hash($semantic),'journal_routing_sha256'=>PSERC_Stable_Json::hash($routing),
            'write_attempted'=>false,
        ];
    }

    /** @return array<string,mixed>|null */
    private static function bridgeForRuntimeSlug(array $bridges,string $slug): ?array {
        foreach($bridges as $bridge){if(!is_array($bridge))continue;foreach((array)($bridge['runtime_slugs']??[]) as $allowed)if(hash_equals((string)$allowed,$slug))return $bridge;}return null;
    }
    /** @return array<string,mixed> */
    private static function liveTermCheck(array $target): array {
        if(!function_exists('get_term'))return ['ok'=>true,'status'=>'NOT_AVAILABLE_IN_LOCAL_TEST_ENV','read_only'=>true,'write_attempted'=>false];
        $term=get_term((int)$target['term_id'],'category');
        if(!$term||(function_exists('is_wp_error')&&is_wp_error($term)))return ['ok'=>false,'status'=>'TERM_NOT_FOUND','read_only'=>true,'write_attempted'=>false];
        $actual=['term_id'=>(int)($term->term_id??0),'name'=>trim((string)($term->name??'')),'slug'=>trim((string)($term->slug??'')),'taxonomy'=>trim((string)($term->taxonomy??''))];
        $ok=$actual['term_id']===(int)$target['term_id']&&hash_equals($actual['slug'],(string)$target['slug'])&&strcasecmp(self::nameSurface($actual['name']),self::nameSurface((string)$target['name']))===0&&$actual['taxonomy']==='category';
        return ['ok'=>$ok,'status'=>$ok?'LIVE_TERM_EXACT_PASS':'LIVE_TERM_EXACT_MISMATCH','actual'=>$actual,'read_only'=>true,'write_attempted'=>false];
    }
    private static function nameSurface(string $value): string {return trim(html_entity_decode($value,ENT_QUOTES|ENT_HTML5,'UTF-8'));}
    private static function norm(string $value): string {$value=strtr(trim($value),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$value=function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);return trim((string)preg_replace('/[^a-z0-9]+/u','',$value));}
    /** @return array<string,mixed> */
    private static function blocked(string $reason,array $extra=[]): array{return array_merge(['contract'=>self::CONTRACT,'status'=>'PSERC_JOURNAL_ASSIGNMENT_CONSISTENCY_BLOCKED','ok'=>false,'reason_codes'=>[$reason],'message'=>$reason,'write_attempted'=>false],$extra);}
}
