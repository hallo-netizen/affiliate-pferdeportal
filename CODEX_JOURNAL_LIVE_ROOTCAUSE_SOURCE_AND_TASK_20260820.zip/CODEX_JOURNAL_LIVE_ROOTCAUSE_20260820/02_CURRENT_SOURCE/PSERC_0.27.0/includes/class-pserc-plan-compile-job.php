<?php
if (!defined('ABSPATH')) { return; }

/**
 * Bounded, resumable Redaktionsplan compiler orchestration.
 * No article/content/design/prompt writes. Every worker invocation performs one bounded phase/tick.
 */
final class PSERC_Plan_Compile_Job {
    public const CONTRACT='PSERC_PLAN_COMPILE_JOB_V1_BOUNDED_GENERATION';
    private const TOPIC_BATCH=10;
    private const INVENTORY_BATCH=5;
    private const NORMALIZE_BATCH=10;
    private const DUP_BATCH=25;
    private const LEASE_TTL=25;
    private static string $leaseToken='';
    private static int $leaseFence=0;

    /** Start only if no current active generation exists. */
    public static function start(): array {
        $dep=PSERC_Plan_Dependency_Fingerprint::current();
        $context=(array)($dep['context']??[]);
        if((string)($context['status']??'')!=='COMPLETE')return self::blockedView('PSERC_PLAN_PSTE_CONTEXT_NOT_COMPLETE');
        $active=PSERC_Plan_Snapshot_Store::getActive();
        $activeValid=PSERC_Plan_Snapshot_Store::verifyHeader($active);
        if($activeValid&&PSERC_Plan_Dependency_Fingerprint::isCurrent((array)($active['dependency']??[])))return self::viewFromActive($active);
        $reuseTopic=null;if($activeValid&&PSERC_Plan_Dependency_Fingerprint::componentEqual((array)($active['dependency']??[]),$dep,'topic')&&PSERC_Plan_Dependency_Fingerprint::componentEqual((array)($active['dependency']??[]),$dep,'structure')){$tp=(array)($active['topic_projection']??[]);if((int)($tp['topic_count']??0)>=0&&(string)($tp['generation']??'')!=='')$reuseTopic=$tp;}
        $old=PSERC_Plan_Snapshot_Store::getJob();
        if(($old['contract']??'')===self::CONTRACT&&($old['status']??'')==='RUNNING'&&hash_equals((string)($old['dependency']['fingerprint_sha256']??''),(string)($dep['fingerprint_sha256']??'')))return self::publicView($old);
        $uuid=function_exists('wp_generate_uuid4')?wp_generate_uuid4():hash('sha256',microtime(true).'|'.mt_rand());$generation=PSERC_Plan_Snapshot_Store::generationId($uuid);
        $job=[
            'contract'=>self::CONTRACT,'job_uuid'=>$uuid,'generation'=>$generation,'status'=>'RUNNING','phase'=>'INIT','cursor'=>0,'seq'=>0,'error_code'=>'','started_at_utc'=>gmdate('c'),'updated_at_utc'=>gmdate('c'),'dependency'=>$dep,
            'topic_cursor'=>null,'topic_count'=>$reuseTopic?(int)($reuseTopic['topic_count']??0):0,'planned'=>$reuseTopic?(array)($reuseTopic['planned']??[]):[],'volumes'=>$reuseTopic?(array)($reuseTopic['volumes']??[]):[],'topic_source_generation'=>$reuseTopic?(string)$reuseTopic['generation']:$generation,'reuse_topic_projection'=>$reuseTopic!==null,'inventory_cursor'=>null,'inventory_count'=>0,'actual'=>[],'existing_count'=>0,'supplemental_cursor'=>0,'occupied_cursor'=>0,'occupied_ids'=>[],'gsc_cursor'=>0,'gsc_summary'=>[],'gsc_property'=>'',
            'normalize_cursor'=>0,'eligible_count'=>0,'held_count'=>0,'candidate_index'=>0,'candidate_sort_cursor'=>null,'prepared_count'=>0,'final_count'=>0,'ready_count'=>0,'slot_index'=>0,'reserved_ids'=>[],'counts'=>PSERC_Compiler::countTemplate(),'existing_families'=>[],'prepared_families'=>[],'ready_chain_sha256'=>str_repeat('0',64),'ready_items_json_bytes'=>0,
            'metrics'=>['ticks'=>0,'max_wall_ms'=>0,'max_peak_bytes'=>0,'max_queries'=>0,'max_records_read'=>0,'max_records_written'=>0,'max_bytes_read'=>0],
        ];
        PSERC_Plan_Snapshot_Store::putJob($job);return self::publicView($job);
    }

    public static function advance(): array {
        $job=PSERC_Plan_Snapshot_Store::getJob();if(($job['contract']??'')!==self::CONTRACT)return self::start();
        if(($job['status']??'')!=='RUNNING')return self::publicView($job);
        if(!self::acquireLease($job))return self::publicView($job,['lease_busy'=>true]);
        $metric=PSERC_Plan_Metrics::start((string)$job['phase']);$reads=0;$writes=0;$bytes=0;
        try{
            [$job,$reads,$writes,$bytes]=self::tick($job);
            $m=PSERC_Plan_Metrics::finish($metric,$reads,$writes,$bytes);$job['last_tick_metrics']=$m;self::accumulateMetrics($job,$m);$job['updated_at_utc']=gmdate('c');PSERC_Plan_Snapshot_Store::putJob($job);self::releaseLease();return self::publicView($job);
        }catch(Throwable $e){
            $job['status']='BLOCKED';$job['error_code']=self::safeError($e->getMessage());$job['error_phase']=(string)($job['phase']??'');$job['updated_at_utc']=gmdate('c');$m=PSERC_Plan_Metrics::finish($metric,$reads,$writes,$bytes);$job['last_tick_metrics']=$m;self::accumulateMetrics($job,$m);try{PSERC_Plan_Snapshot_Store::putJob($job);}catch(Throwable $ignored){}self::releaseLease();return self::publicView($job);
        }
    }

    /** @return array{0:array,1:int,2:int,3:int} */
    private static function tick(array $job): array {
        $phase=(string)$job['phase'];$gen=(string)$job['generation'];
        if($phase==='INIT'){
            PSERC_Plan_Snapshot_Store::ensureReadyIndexTable();
            $package=PSERC_Package_Integrity::validate();if(empty($package['ok']))throw new RuntimeException((string)($package['status']??'PSERC_PACKAGE_INTEGRITY_BLOCKED'));
            $production=PSERC_Production_Reader::snapshot();if(empty($production['ok']))throw new RuntimeException((string)($production['status']??'PSERC_PRODUCTION_SNAPSHOT_BLOCKED'));
            $titleCompat=PSERC_Title_Rule_Compatibility::inspect($production);if(empty($titleCompat['ok']))throw new RuntimeException('PSERC_TITLE_RULE_CONTRACT_CONFLICT');
            $baseline=get_option(defined('PSTE_OPTION_SITE_BASELINE')?PSTE_OPTION_SITE_BASELINE:'pste_site_baseline_v1',[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSERC_PLAN_BASELINE_MISSING');
            $structure=PSERC_Portal_Structure_Gate::validate($baseline,null);if(empty($structure['ok']))throw new RuntimeException((string)($structure['status']??'PSERC_PORTAL_STRUCTURE_BLOCKED'));
            $source=PSERC_SEO_Source_Binding::validate();if(empty($source['ok']))throw new RuntimeException((string)($source['status']??'PSERC_SEO_CAPABILITY_BLOCKED'));
            $schema=(string)get_option(defined('PSTE_OPTION_SCHEMA')?PSTE_OPTION_SCHEMA:'pste_schema_version','');if(!hash_equals((string)($source['engine_schema']??''),$schema))throw new RuntimeException('PSERC_SEO_SCHEMA_UNSUPPORTED');
            $runtimeState=get_option('ppm679_editorial_plan_runtime_state_v1',[]);if(!is_array($runtimeState))$runtimeState=[];foreach((array)($runtimeState['items']??[]) as $id=>$row){$canonical=trim((string)($row['canonical_article_id']??$id));if($canonical!=='')$job['occupied_ids'][$canonical]=true;}
            PSERC_Plan_Snapshot_Store::putRecord($gen,'bootstrap',0,['package'=>$package,'production'=>$production,'title_compatibility'=>$titleCompat,'baseline'=>$baseline,'structure'=>$structure,'source_binding'=>$source,'schema'=>$schema]);
            $job['phase']='OCCUPIED';return [$job,0,1,0];
        }
        if($phase==='OCCUPIED'){
            $page=PSERC_Existing_Content_Reader::occupiedCanonicalIdPage((int)($job['occupied_cursor']??0),25);if(empty($page['ok']))throw new RuntimeException((string)($page['status']??'PSERC_OCCUPIED_CANONICAL_IDS_BLOCKED'));foreach((array)($page['items']??[]) as $id){$id=trim((string)$id);if($id!=='')$job['occupied_ids'][$id]=true;}
            $job['occupied_cursor']=(int)($page['next_cursor']??$job['occupied_cursor']);if(!empty($page['complete']))$job['phase']=!empty($job['reuse_topic_projection'])?'INVENTORY':'TOPICS';return [$job,(int)($page['row_count']??0),0,0];
        }
        if($phase==='TOPICS'){
            $page=PSTE_Compiler_Read_Capability::topicPage(is_array($job['topic_cursor'])?$job['topic_cursor']:null,self::TOPIC_BATCH);$items=(array)($page['items']??[]);$start=(int)$job['topic_count'];
            foreach($items as $i=>$c){if(!is_array($c))continue;PSERC_Plan_Snapshot_Store::putRecord($gen,'raw_topic',$start+$i,$c);if(empty($c['discovery_only'])){$key=(string)($c['topic_family_key']??PSTE_Normalizer::categoryFamilyKey((string)($c['target_category_name']??'')));if($key!==''){if(in_array((string)($c['planning_suitability']??'NO'),['YES','PROVISIONAL'],true))$job['planned'][$key]=($job['planned'][$key]??0)+1;$job['volumes'][$key]=($job['volumes'][$key]??0)+max(0,(int)($c['metrics']['search_volume']??0));}}}
            $job['topic_count']=$start+count($items);$job['topic_cursor']=$page['next_cursor']??null;if(!empty($page['complete'])){$job['phase']='INVENTORY';$job['inventory_cursor']=null;}
            return [$job,count($items),count($items),(int)($page['metrics']['payload_bytes']??0)];
        }
        if($phase==='INVENTORY'){
            $boot=self::bootstrap($gen);$page=PSTE_Compiler_Read_Capability::inventoryPage(is_array($job['inventory_cursor'])?$job['inventory_cursor']:null,self::INVENTORY_BATCH,(array)$boot['structure']);$items=(array)($page['items']??[]);$raw=(array)($page['raw_rows']??[]);$invStart=(int)$job['inventory_count'];$exStart=(int)$job['existing_count'];
            foreach($items as $item){if(!is_array($item))continue;if(($item['status']??'')==='publish'){$key=(string)($item['topic_family_key']??'');if($key!=='')$job['actual'][$key]=($job['actual'][$key]??0)+1;}}
            $converted=PSERC_Existing_Content_Reader::boundedFromRows($raw,'PSTE_BOUNDED_INVENTORY_REUSE');$projectionWrites=0;foreach((array)($converted['items']??[]) as $item)$projectionWrites+=self::storeExistingProjection($job,(array)$item);
            $job['inventory_count']=$invStart+count($items);$job['existing_count']=$exStart+(int)($converted['item_count']??0);$job['inventory_cursor']=$page['next_cursor']??null;if(!empty($page['complete'])){$job['phase']='SUPPLEMENT';$job['supplemental_cursor']=0;}
            return [$job,count($items),$projectionWrites,(int)($page['metrics']['content_bytes']??0)];
        }
        if($phase==='SUPPLEMENT'){
            $page=PSERC_Existing_Content_Reader::supplementalPage((int)$job['supplemental_cursor'],self::INVENTORY_BATCH);if(empty($page['ok']))throw new RuntimeException((string)($page['status']??'PSERC_EXISTING_SUPPLEMENTAL_BLOCKED'));
            $start=(int)$job['existing_count'];$items=(array)($page['items']??[]);$projectionWrites=0;foreach($items as $item)$projectionWrites+=self::storeExistingProjection($job,(array)$item);$job['existing_count']=$start+count($items);$job['supplemental_cursor']=(int)($page['next_cursor']??$job['supplemental_cursor']);if(!empty($page['complete'])){$job['phase']='GSC';$job['gsc_cursor']=0;$job['gsc_summary']=[];$job['gsc_property']=(string)get_option(defined('PSTE_OPTION_GSC_SELECTED_PROPERTY')?PSTE_OPTION_GSC_SELECTED_PROPERTY:'pste_gsc_selected_property_v1','');}
            return [$job,count($items),$projectionWrites,(int)($page['content_bytes']??0)];
        }
        if($phase==='GSC'){
            $page=PSTE_Compiler_Read_Capability::gscCategoryPage((string)($job['gsc_property']??''),(int)($job['gsc_cursor']??0),25);$items=(array)($page['items']??[]);
            foreach($items as $categoryId=>$row)$job['gsc_summary'][(int)$categoryId]=(array)$row;
            $job['gsc_cursor']=(int)($page['next_cursor']??$job['gsc_cursor']);if(!empty($page['complete']))$job['phase']='COVERAGE';
            return [$job,count($items),0,0];
        }
        if($phase==='COVERAGE'){
            $boot=self::bootstrap($gen);$coverage=PSTE_Compiler_Read_Capability::coverageFromAggregates((array)$boot['baseline'],(array)$job['actual'],(array)$job['planned'],(array)$job['volumes'],(array)($job['gsc_summary']??[]));PSERC_Plan_Snapshot_Store::putRecord($gen,'coverage',0,$coverage);$job['phase']='NORMALIZE';$job['normalize_cursor']=0;return [$job,count($coverage),1,0];
        }
        if($phase==='NORMALIZE'){
            $coverage=PSERC_Plan_Snapshot_Store::getRecord($gen,'coverage',0);if(!is_array($coverage))throw new RuntimeException('PSERC_PLAN_COVERAGE_RECORD_MISSING');$boot=self::bootstrap($gen);$start=(int)$job['normalize_cursor'];$end=min((int)$job['topic_count'],$start+self::NORMALIZE_BATCH);$read=0;$write=0;
            for($i=$start;$i<$end;$i++){ $raw=PSERC_Plan_Snapshot_Store::getRecord((string)($job['topic_source_generation']??$gen),'raw_topic',$i);if(!is_array($raw))throw new RuntimeException('PSERC_PLAN_RAW_TOPIC_MISSING');$read++;$prio=PSTE_Compiler_Read_Capability::priorityForCandidate($raw,$coverage);if(!empty($prio['eligible'])){$raw['priority_score']=(float)($prio['priority_score']??0);$raw['search_intent']=$raw['search_intent']??($prio['intent']??'');}$norm=PSERC_SEO_Reader::normalizeCandidate($raw);if(($norm['eligibility_status']??'')==='ELIGIBLE'){$ctx=self::projectGateContext($norm,(array)$boot['baseline'],(array)$boot['structure']);$seq=(int)$job['eligible_count'];PSERC_Plan_Snapshot_Store::putRecord($gen,'eligible',$seq,['topic'=>$norm,'baseline'=>$ctx['baseline'],'structure'=>$ctx['structure']]);PSERC_Plan_Snapshot_Store::putCandidateIndex($gen,$seq,(float)($norm['priority_score']??0),(string)($norm['allocation_order_title']??''),(string)($norm['pool_key']??''));$job['eligible_count']++;$write+=2;}else{$job['held_count']++;}}
            $job['normalize_cursor']=$end;if($end>=(int)$job['topic_count']){$indexed=PSERC_Plan_Snapshot_Store::candidateCount($gen);if($indexed!==(int)$job['eligible_count'])throw new RuntimeException('PSERC_PLAN_CANDIDATE_INDEX_COUNT_MISMATCH');$job['phase']='CANDIDATE';$job['candidate_index']=0;$job['candidate_sort_cursor']=null;}
            return [$job,$read,$write,0];
        }
        if($phase==='CANDIDATE')return self::tickCandidate($job);
        if($phase==='SLOT')return self::tickSlot($job);
        if($phase==='READY_VERIFY'){
            $count=PSERC_Plan_Snapshot_Store::readyCount($gen);if($count!==(int)$job['ready_count'])throw new RuntimeException('PSERC_PLAN_READY_INDEX_COUNT_MISMATCH');$job['phase']='ACTIVATE';return [$job,1,0,0];
        }
        if($phase==='ACTIVATE')return self::tickActivate($job);
        throw new RuntimeException('PSERC_PLAN_PHASE_UNKNOWN_'.$phase);
    }

    /** @return array{0:array,1:int,2:int,3:int} */
    private static function tickCandidate(array $job): array {
        $gen=(string)$job['generation'];
        if((int)$job['candidate_index']>=(int)$job['eligible_count']){$job['phase']='SLOT';$job['slot_index']=0;return [$job,0,0,0];}
        $work=PSERC_Plan_Snapshot_Store::getRecord($gen,'candidate_work',0);
        if(!is_array($work)||empty($work)){
            $order=PSERC_Plan_Snapshot_Store::nextCandidateIndex($gen,is_array($job['candidate_sort_cursor']??null)?(array)$job['candidate_sort_cursor']:null);if(!is_array($order))throw new RuntimeException('PSERC_PLAN_CANDIDATE_ORDER_MISSING');$env=PSERC_Plan_Snapshot_Store::getRecord($gen,'eligible',(int)$order['source_seq']);if(!is_array($env))throw new RuntimeException('PSERC_PLAN_ELIGIBLE_RECORD_MISSING');$topic=(array)$env['topic'];$sortCursor=(array)$order['cursor'];$boot=self::bootstrap($gen);
            if(abs((float)($topic['priority_score']??0)-(float)($order['priority_score']??0))>0.000001)throw new RuntimeException('PSERC_PLAN_CANDIDATE_PRIORITY_INDEX_MISMATCH');
            $technical=PSERC_Technical_Strand::evaluate($topic,(array)$boot['production'],(array)$env['structure'],(array)$env['baseline']);$editorial=PSERC_Editorial_Strand::evaluate($topic);self::decorateTopic($topic,$technical,$editorial);
            if(empty($technical['ok']))return self::finishReview($job,$topic,(string)($technical['primary_status']??'BLOCKED_TECHNICAL_STRAND'),(array)($technical['reason_codes']??['TECHNICAL_STRAND_BLOCKED']),[],$sortCursor);
            if(empty($editorial['ok']))return self::finishReview($job,$topic,'BLOCKED_EDITORIAL_STRAND',(array)($editorial['reason_codes']??['EDITORIAL_STRAND_BLOCKED']),[],$sortCursor);
            $projection=PSERC_Semantic_Duplicate_Gate::projectTopic($topic);$exact=self::lookupExistingExact($gen,$topic);
            if($exact!==null){$agg=PSERC_Semantic_Duplicate_Gate::exactExistingResult($exact);$topic['semantic_duplicate_gate']=$agg;return self::finishReview($job,$topic,'BLOCKED_EXISTING_CONTENT_DUPLICATE',['EXISTING_CONTENT_EXACT_OR_IDENTITY_DUPLICATE'],$agg,$sortCursor);}
            $work=['topic'=>$topic,'baseline'=>(array)$env['baseline'],'structure'=>(array)$env['structure'],'sort_cursor'=>$sortCursor,'projection'=>$projection,'stage'=>'EXISTING','buckets'=>self::compatibleBuckets($projection,(array)($job['existing_families']??[])),'bucket_pos'=>0,'cursor'=>0,'aggregate'=>PSERC_Semantic_Duplicate_Gate::newAggregateState('EXISTING_CONTENT')];
            PSERC_Plan_Snapshot_Store::putRecord($gen,'candidate_work',0,$work);return [$job,2,1,0];
        }
        $topic=(array)$work['topic'];$projection=(array)$work['projection'];$stage=(string)$work['stage'];$buckets=(array)($work['buckets']??[]);$pos=(int)($work['bucket_pos']??0);$cursor=(int)($work['cursor']??0);
        if($stage==='EXISTING'||$stage==='PREPARED'){
            $families=$stage==='EXISTING'?(array)($job['existing_families']??[]):(array)($job['prepared_families']??[]);$kindPrefix=$stage==='EXISTING'?'existing_family_':'prepared_family_';$scope=$stage==='EXISTING'?'EXISTING_CONTENT':'METADATA_CANDIDATES';$reads=0;
            if($pos<count($buckets)){
                $bucket=(string)$buckets[$pos];$meta=(array)($families[$bucket]??[]);$count=(int)($meta['count']??0);$rows=PSERC_Plan_Snapshot_Store::getRange($gen,$kindPrefix.$bucket,$cursor,self::DUP_BATCH);$reads=count($rows);
                $matches=$stage==='EXISTING'?PSERC_Semantic_Duplicate_Gate::scanExistingProjectedChunk($projection,$rows):PSERC_Semantic_Duplicate_Gate::scanPreparedProjectedChunk($projection,$rows);
                $work['aggregate']=PSERC_Semantic_Duplicate_Gate::mergeAggregateState((array)$work['aggregate'],$matches);$cursor+=count($rows);
                if($cursor>=$count){$pos++;$cursor=0;}$work['bucket_pos']=$pos;$work['cursor']=$cursor;
                PSERC_Plan_Snapshot_Store::putRecord($gen,'candidate_work',0,$work);return [$job,$reads,1,0];
            }
            $agg=PSERC_Semantic_Duplicate_Gate::finalizeAggregateState((array)$work['aggregate']);$topic['semantic_duplicate_gate']=$agg;
            if(($agg['decision']??'PASS')==='BLOCKED_DUPLICATE'){PSERC_Plan_Snapshot_Store::deleteRecord($gen,'candidate_work',0);return self::finishReview($job,$topic,$stage==='EXISTING'?'BLOCKED_EXISTING_CONTENT_DUPLICATE':'BLOCKED_DUPLICATE_METADATA_CANDIDATE',(array)($agg['reason_codes']??[$stage==='EXISTING'?'EXISTING_CONTENT_DUPLICATE':'DUPLICATE_WITHIN_METADATA_CANDIDATES']),$agg,(array)($work['sort_cursor']??[]));}
            if(($agg['decision']??'PASS')==='REVIEW_REQUIRED'){PSERC_Plan_Snapshot_Store::deleteRecord($gen,'candidate_work',0);return self::finishReview($job,$topic,'REVIEW_REQUIRED_SEMANTIC_OVERLAP',(array)($agg['reason_codes']??['SEMANTIC_OVERLAP_REVIEW_REQUIRED']),$agg,(array)($work['sort_cursor']??[]));}
            if($stage==='EXISTING'){
                $work=['topic'=>$topic,'baseline'=>(array)$work['baseline'],'structure'=>(array)$work['structure'],'sort_cursor'=>(array)($work['sort_cursor']??[]),'projection'=>$projection,'stage'=>'PREPARED','buckets'=>self::compatibleBuckets($projection,(array)($job['prepared_families']??[])),'bucket_pos'=>0,'cursor'=>0,'aggregate'=>PSERC_Semantic_Duplicate_Gate::newAggregateState('METADATA_CANDIDATES')];PSERC_Plan_Snapshot_Store::putRecord($gen,'candidate_work',0,$work);return [$job,0,1,0];
            }
            $keyword=PSERC_Target_Keyword::derive($topic,(string)($topic['production_title']??''),null);$topic['preallocation_keyword']=$keyword;if(($keyword['status']??'')!=='PASS'){PSERC_Plan_Snapshot_Store::deleteRecord($gen,'candidate_work',0);return self::finishReview($job,$topic,'REVIEW_REQUIRED_TARGET_KEYWORD',(array)($keyword['errors']??['TARGET_KEYWORD_BLOCKED']),[],(array)($work['sort_cursor']??[]));}
            $evidence=PSERC_Portal_Topic_Evidence_Gate::evaluate(PSERC_Compiler::evidenceView($topic),(array)$work['structure']);$topic['portal_topic_evidence_gate']=$evidence;if(empty($evidence['ok'])){PSERC_Plan_Snapshot_Store::deleteRecord($gen,'candidate_work',0);return self::finishReview($job,$topic,'BLOCKED_PORTAL_TOPIC_EVIDENCE',(array)($evidence['reason_codes']??['PORTAL_TOPIC_EVIDENCE_BLOCKED']),[],(array)($work['sort_cursor']??[]));}
            $preparedIndex=(int)$job['prepared_count'];PSERC_Plan_Snapshot_Store::putRecord($gen,'prepared',$preparedIndex,['topic'=>$topic,'structure'=>(array)$work['structure']]);$preparedProjection=PSERC_Semantic_Duplicate_Gate::projectTopic($topic);$preparedProjection['_projection_source_order']=$preparedIndex;$bucket=PSERC_Semantic_Duplicate_Gate::familyBucketForProjection($preparedProjection);$local=(int)($job['prepared_families'][$bucket]['count']??0);PSERC_Plan_Snapshot_Store::putRecord($gen,'prepared_family_'.$bucket,$local,$preparedProjection);$job['prepared_families'][$bucket]=['family'=>(string)($preparedProjection['family']??''),'family_tokens'=>(array)($preparedProjection['family_tokens']??[]),'count'=>$local+1];$job['prepared_count']++;$job['candidate_sort_cursor']=(array)($work['sort_cursor']??[]);if(!$job['candidate_sort_cursor'])throw new RuntimeException('PSERC_PLAN_CANDIDATE_SORT_CURSOR_MISSING');$job['candidate_index']++;PSERC_Plan_Snapshot_Store::deleteRecord($gen,'candidate_work',0);return [$job,0,2,0];
        }
        throw new RuntimeException('PSERC_PLAN_CANDIDATE_STAGE_UNKNOWN');
    }

    private static function storeExistingProjection(array &$job,array $item): int {
        $gen=(string)$job['generation'];$projection=PSERC_Semantic_Duplicate_Gate::projectExisting($item);$bucket=PSERC_Semantic_Duplicate_Gate::familyBucketForProjection($projection);$local=(int)($job['existing_families'][$bucket]['count']??0);$postId=(int)($item['post_id']??0);$projection['_projection_source_order']=$postId>0?$postId:(int)$job['existing_count']+$local;
        PSERC_Plan_Snapshot_Store::putRecord($gen,'existing_family_'.$bucket,$local,$projection);$writes=1;$job['existing_families'][$bucket]=['family'=>(string)($projection['family']??''),'family_tokens'=>(array)($projection['family_tokens']??[]),'count'=>$local+1];
        foreach(PSERC_Semantic_Duplicate_Gate::exactIndexEntriesForExisting($projection) as $entry){PSERC_Plan_Snapshot_Store::putNamedMin($gen,'existing_exact',(string)$entry['name'],$postId>0?$postId:PHP_INT_MAX,['projection'=>$projection,'reason'=>(string)$entry['reason'],'priority'=>(int)$entry['priority']]);$writes++;}
        return $writes;
    }
    /** @return list<string> */
    private static function compatibleBuckets(array $projection,array $families): array {$out=[];foreach($families as $bucket=>$meta){if(PSERC_Semantic_Duplicate_Gate::familiesCompatible($projection,(array)$meta))$out[]=(string)$bucket;}sort($out,SORT_STRING);return $out;}
    private static function lookupExistingExact(string $gen,array $topic): ?array {
        $hits=[];foreach(PSERC_Semantic_Duplicate_Gate::exactLookupKeysForTopic($topic) as $entry){$row=PSERC_Plan_Snapshot_Store::getNamed($gen,'existing_exact',(string)$entry['name']);if($row===null)continue;$payload=(array)$row['payload'];$hits[]=['order'=>(int)$row['order'],'priority'=>(int)$entry['priority'],'projection'=>(array)($payload['projection']??[]),'reason'=>(string)$entry['reason']];}
        if(!$hits)return null;usort($hits,static fn($a,$b)=>[(int)$a['order'],(int)$a['priority']]<=>[(int)$b['order'],(int)$b['priority']]);return PSERC_Semantic_Duplicate_Gate::exactMatchEnvelope((array)$hits[0]['projection'],(string)$hits[0]['reason']);
    }

    /** @return array{0:array,1:int,2:int,3:int} */
    private static function finishReview(array $job,array $topic,string $status,array $reasons,array $duplicate,array $sortCursor=[]): array {
        if(!$sortCursor)throw new RuntimeException('PSERC_PLAN_CANDIDATE_SORT_CURSOR_MISSING');$gen=(string)$job['generation'];$item=PSERC_Compiler::reviewItem($topic,$status,$reasons,$duplicate);PSERC_Plan_Snapshot_Store::putRecord($gen,'final_item',(int)$job['final_count'],$item);$job['final_count']++;$job['counts'][$status]=($job['counts'][$status]??0)+1;$job['candidate_sort_cursor']=$sortCursor;$job['candidate_index']++;return [$job,1,1,0];
    }

    /** @return array{0:array,1:int,2:int,3:int} */
    private static function tickSlot(array $job): array {
        $gen=(string)$job['generation'];if((int)$job['slot_index']>=(int)$job['prepared_count']){$job['phase']='READY_VERIFY';return [$job,0,0,0];}
        $env=PSERC_Plan_Snapshot_Store::getRecord($gen,'prepared',(int)$job['slot_index']);if(!is_array($env))throw new RuntimeException('PSERC_PLAN_PREPARED_RECORD_MISSING');$topic=(array)$env['topic'];$structure=(array)$env['structure'];$boot=self::bootstrap($gen);$occupied=array_values(array_unique(array_merge(array_keys((array)$job['occupied_ids']),(array)$job['reserved_ids'])));$alloc=PSERC_Slot_Allocator::allocate([$topic],(array)$boot['production'],$occupied);$rows=(array)($alloc['items']??[]);if(count($rows)!==1)throw new RuntimeException('PSERC_PLAN_SLOT_ALLOCATION_CARDINALITY_INVALID');$row=(array)$rows[0];$slot=(array)($row['slot']??[]);$cid=(string)($slot['canonical_article_id']??'');if($cid!=='')$job['reserved_ids'][]=$cid;
        $item=PSERC_Compiler::finalizeAllocationRow($row,(array)$boot['production'],$structure);$idx=(int)$job['final_count'];PSERC_Plan_Snapshot_Store::putRecord($gen,'final_item',$idx,$item);$job['final_count']++;$status=(string)$item['status'];$job['counts'][$status]=($job['counts'][$status]??0)+1;
        if($status==='READY_FOR_METADATA_HANDOFF'){$binding=(array)$item['metadata_binding'];$json=PSERC_Stable_Json::encode($binding);$nextBytes=(int)$job['ready_items_json_bytes']+strlen($json)+1;if($nextBytes>2097152)throw new RuntimeException('PSERC_PLAN_EXACT_FIVE_BATCH_BYTE_BUDGET_EXCEEDED');PSERC_Plan_Snapshot_Store::putReadyIndex($gen,(int)$job['ready_count'],$idx,$binding);$job['ready_chain_sha256']=hash('sha256',(string)$job['ready_chain_sha256'].'|'.PSERC_Stable_Json::hash($binding));$job['ready_items_json_bytes']=$nextBytes;$job['ready_count']++;}
        $job['slot_index']++;return [$job,1,$status==='READY_FOR_METADATA_HANDOFF'?2:1,0];
    }

    /** @return array{0:array,1:int,2:int,3:int} */
    private static function tickActivate(array $job): array {
        $gen=(string)$job['generation'];$current=PSERC_Plan_Dependency_Fingerprint::current((array)($job['dependency']['production_category_ids']??[]));if(!hash_equals((string)($job['dependency']['fingerprint_sha256']??''),(string)($current['fingerprint_sha256']??'')))throw new RuntimeException('PSERC_PLAN_DEPENDENCY_CHANGED_DURING_BUILD');
        $readyCount=PSERC_Plan_Snapshot_Store::readyCount($gen);if($readyCount!==(int)$job['ready_count'])throw new RuntimeException('PSERC_PLAN_READY_INDEX_COUNT_MISMATCH');
        $descriptor=['contract'=>'PSERC_READY_BATCH_DESCRIPTOR_V1','status'=>$readyCount>0?'READY_FOR_TEXTMACHINE_METADATA_INTAKE':'NO_READY_ITEMS','item_count'=>$readyCount,'maximum_articles'=>0,'maximum_articles_per_type'=>0,'publish_allowed'=>false,'content_or_format_payload_present'=>false,'ready_chain_sha256'=>(string)$job['ready_chain_sha256'],'items_json_bytes'=>(int)$job['ready_items_json_bytes']];
        $boot=self::bootstrap($gen);$counts=array_merge(['seo_all'=>(int)$job['topic_count'],'seo_eligible'=>(int)$job['eligible_count'],'seo_held'=>(int)$job['held_count'],'compiled_items'=>(int)$job['final_count'],'next_metadata_batch_items'=>$readyCount],(array)$job['counts']);
        $manifestBase=self::manifestBase($boot,$job,$counts,$descriptor);$header=['contract'=>'PSERC_PLAN_SNAPSHOT_V1','generation'=>$gen,'job_uuid'=>(string)$job['job_uuid'],'created_at_utc'=>gmdate('c'),'dependency'=>$job['dependency'],'topic_projection'=>['generation'=>(string)($job['topic_source_generation']??$gen),'topic_count'=>(int)$job['topic_count'],'planned'=>(array)$job['planned'],'volumes'=>(array)$job['volumes'],'topic_source_sha256'=>(string)($job['dependency']['topic_source_sha256']??'')],'counts'=>$counts,'ready_batch_descriptor'=>$descriptor,'manifest_base'=>$manifestBase,'metrics'=>$job['metrics'],'publish_allowed'=>false];PSERC_Plan_Snapshot_Store::activate($header);$active=PSERC_Plan_Snapshot_Store::getActive();
        $job['status']='COMPLETE';$job['phase']='COMPLETE';$job['error_code']='';$job['snapshot_sha256']=(string)($active['snapshot_sha256']??'');return [$job,1,1,0];
    }

    private static function manifestBase(array $boot,array $job,array $counts,array $descriptor): array {
        $p=(array)$boot['production'];$package=(array)$boot['package'];$source=(array)$boot['source_binding'];$structure=(array)$boot['structure'];
        return [
            'contract'=>'PSERC_METADATA_ONLY_READ_ONLY_PREVIEW_V5_DUAL_STRAND','version'=>'5.0.0','compiler_version'=>(string)PSERC_VERSION,'created_at_utc'=>gmdate('c'),'mode'=>'READ_ONLY_METADATA_ONLY_EXACT_FIVE_FIELDS',
            'system_boundary'=>['production_machine_modified'=>false,'production_center_modified'=>false,'editorial_guard_modified'=>false,'design_plugin_modified'=>false,'posts_terms_urls_yoast_modified'=>false,'existing_articles_modified'=>false,'production_started'=>false,'draft_created'=>false,'publish_allowed'=>false,'wordpress_database_write_attempted'=>false,'plugin_option_write_attempted'=>true,'server_file_write_attempted'=>false,'article_text_emitted'=>false,'html_emitted'=>false,'fact_pack_emitted'=>false,'headings_tables_lists_links_emitted'=>false],
            'hard_rules'=>['question_title_always_faq'=>true,'journal_question_title_registered_exception'=>true,'category_must_match_article_type'=>true,'semantic_category_family_must_match_source_query'=>true,'runtime_reassignment_forbidden'=>true,'portal_internal_topic_evidence_required'=>true,'external_serp_evidence_required'=>false,'text_machine_is_only_content_and_format_authority'=>true,'metadata_handoff_exact_scalar_fields'=>['title','target_keyword','category','article_type','plan_slot'],'unsupported_metadata_only_intake_must_block'=>true,'existing_title_slug_and_topic_duplicates_blocked'=>true,'canonical_slot_is_technical_capacity_only'=>true,'direct_ppm_consumer_claimed'=>false,'approved_research_text_process_required'=>true,'ppm_package_requires_canonical_article_id_before_preflight'=>true,'plan_slot_identity_contract'=>PSERC_Plan_Slot_Identity::CONTRACT,'plan_slot_identity_excludes_working_title_and_intent_angle'=>true,'semantic_duplicate_gate_is_separate_from_slot_capacity'=>true,'ready_requires_technical_editorial_and_e2e_pass'=>true,'textmachine_target_keyword_exact_title_binding_prevalidated'=>true,'raw_keyword_remains_separately_preserved'=>true],
            'bindings'=>['compiler_version'=>(string)PSERC_VERSION,'compiler_build'=>(string)PSERC_BUILD,'compiler_package_binding_sha256'=>(string)$package['binding_sha256'],'production_version'=>(string)$p['version'],'production_baseline_sha256'=>(string)$p['baseline_sha256'],'production_file_hashes'=>$p['hashes'],'canonical_plan_file_sha256'=>(string)$p['hashes']['contracts/canonical-complete-editorial-plan-v1.json'],'normal_draft_release_sha256'=>(string)$p['normal_draft_release_sha256'],'normal_draft_release_self_hash'=>(string)$p['normal_draft_release_self_hash'],'seo_version'=>defined('PSTE_VERSION')?(string)PSTE_VERSION:'','seo_schema'=>(string)$boot['schema'],'seo_snapshot_sha256'=>(string)($job['dependency']['fingerprint_sha256']??''),'seo_source_binding_sha256'=>(string)$source['binding_sha256'],'seo_source_binding_file_count'=>(int)$source['required_file_count'],'seo_capability_binding_sha256'=>(string)($source['capability_sha256']??''),'seo_capability_required_symbol_count'=>(int)($source['required_symbol_count']??0),'portal_structure_registry_sha256'=>(string)$structure['registry_sha256'],'portal_structure_category_count'=>(int)$structure['category_count'],'portal_structure_live_baseline_sha256'=>(string)$structure['live_baseline_sha256'],'occupied_canonical_ids_sha256'=>PSERC_Stable_Json::hash(array_values(array_keys((array)$job['occupied_ids']))),'plan_slot_identity'=>PSERC_Plan_Slot_Identity::contract(),'existing_content_snapshot_sha256'=>hash('sha256',(string)$job['generation'].'|existing|'.(int)$job['existing_count']),'existing_content_item_count'=>(int)$job['existing_count']],
            'existing_content_inventory'=>['status'=>'PSERC_EXISTING_CONTENT_BOUNDED_GENERATION_PASS','source'=>'WORDPRESS_BOUNDED_GENERATION','item_count'=>(int)$job['existing_count'],'snapshot_sha256'=>hash('sha256',(string)$job['generation'].'|existing|'.(int)$job['existing_count']),'write_attempted'=>false],
            'production_release'=>['registered_article_types'=>$p['registered_article_types'],'planning_registered_article_types'=>(array)($p['planning_registered_article_types']??[]),'journal_registration'=>(array)($p['journal_registration']??[]),'metadata_candidate_article_types'=>$p['supported_article_types'],'batch_policy'=>['minimum_articles'=>1,'maximum_articles'=>0,'maximum_articles_per_type'=>0,'zero_means_unbounded'=>true,'scope_mode'=>'USER_SELECTED_READY_SET_UNBOUNDED','publish_allowed'=>false,'wissen_allowed'=>true],'ppm_internal_execution_policy'=>$p['batch_policy'],'publish_allowed'=>false],
            'title_rule_compatibility'=>$boot['title_compatibility'],'counts'=>$counts,'ready_batch_descriptor'=>$descriptor,'persistence'=>['server_storage'=>true,'wordpress_option_storage'=>true,'record_local_generation'=>true,'atomic_snapshot_activation'=>true,'preview_exists_only_in_current_response_or_browser_download'=>false],'next_step'=>(int)($descriptor['item_count']??0)>0?'APPROVED_RESEARCH_TEXT_PROCESS_INTAKE_REQUIRED':'NO_ARTICLE_TEST_ITEM_FAIL_CLOSED',
        ];
    }

    private static function bootstrap(string $gen): array {$b=PSERC_Plan_Snapshot_Store::getRecord($gen,'bootstrap',0);if(!is_array($b))throw new RuntimeException('PSERC_PLAN_BOOTSTRAP_MISSING');return $b;}
    private static function projectGateContext(array $topic,array $baseline,array $structure): array {
        $id=(int)($topic['category_id']??0);$slug=(string)($topic['category_slug']??'');$leaf=[];foreach((array)($baseline['leaf_categories']??[]) as $c){if(!is_array($c))continue;if(($id>0&&(int)($c['term_id']??0)===$id)||($slug!==''&&hash_equals((string)($c['slug']??''),$slug))){$leaf[]=$c;}}
        $entry=is_array($structure['by_slug'][$slug]??null)?(array)$structure['by_slug'][$slug]:null;$miniBaseline=['contract'=>'PSTE_SITE_BASELINE_V1','leaf_categories'=>$leaf];$miniStructure=['ok'=>true,'status'=>(string)($structure['status']??'PASS'),'by_slug'=>$entry?[$slug=>$entry]:[],'capitalization_vocabulary'=>(array)($structure['capitalization_vocabulary']??[])];return ['baseline'=>$miniBaseline,'structure'=>$miniStructure];
    }
    private static function decorateTopic(array &$topic,array $technical,array $editorial): void {$topic['technical_strand_report']=$technical;$topic['editorial_strand_report']=$editorial;$topic['assignment_consistency_gate']=(array)($technical['assignment_consistency_gate']??[]);$topic['semantic_assignment_gate']=$topic['assignment_consistency_gate'];$topic['title_gate_initial']=(array)($technical['title_gate']??[]);$topic['language_gate']=(array)($technical['language_gate']??[]);$topic['editorial_outcome_gate']=(array)($editorial['editorial_outcome_gate']??[]);}
    private static function publicView(array $job,array $extra=[]): array {return array_merge(['ok'=>($job['status']??'')!=='BLOCKED','contract'=>self::CONTRACT,'status'=>(string)($job['status']??''),'phase'=>(string)($job['phase']??''),'generation'=>(string)($job['generation']??''),'topic_count'=>(int)($job['topic_count']??0),'eligible_count'=>(int)($job['eligible_count']??0),'candidate_index'=>(int)($job['candidate_index']??0),'prepared_count'=>(int)($job['prepared_count']??0),'ready_count'=>(int)($job['ready_count']??0),'error_code'=>(string)($job['error_code']??''),'last_tick_metrics'=>(array)($job['last_tick_metrics']??[]),'write_scope'=>'PSERC_TECHNICAL_OPTIONS_ONLY','publish_allowed'=>false],$extra);}
    private static function viewFromActive(array $active): array {return ['ok'=>true,'contract'=>self::CONTRACT,'status'=>'COMPLETE','phase'=>'COMPLETE','generation'=>(string)($active['generation']??''),'ready_count'=>(int)($active['counts']['READY_FOR_METADATA_HANDOFF']??0),'snapshot_sha256'=>(string)($active['snapshot_sha256']??''),'publish_allowed'=>false];}
    private static function blockedView(string $code): array {return ['ok'=>false,'contract'=>self::CONTRACT,'status'=>'BLOCKED','phase'=>'PRECONDITION','error_code'=>$code,'publish_allowed'=>false];}
    private static function safeError(string $s): string {$s=strtoupper((string)preg_replace('/[^A-Za-z0-9_]+/','_',trim($s)));$s=trim($s,'_');return substr($s!==''?$s:'PSERC_PLAN_UNKNOWN_ERROR',0,180);}
    private static function accumulateMetrics(array &$job,array $m): void {$job['metrics']['ticks']=(int)($job['metrics']['ticks']??0)+1;foreach(['wall_ms'=>'max_wall_ms','peak_bytes'=>'max_peak_bytes','query_count'=>'max_queries','records_read'=>'max_records_read','records_written'=>'max_records_written','bytes_read'=>'max_bytes_read'] as $src=>$dst)$job['metrics'][$dst]=max((int)($job['metrics'][$dst]??0),(int)($m[$src]??0));}

    /** Technical fencing context consumed by the record store before every worker write. @return array<string,mixed> */
    public static function storageFenceContext(): array {return ['active'=>self::$leaseToken!=='','token'=>self::$leaseToken,'fence'=>self::$leaseFence];}

    private static function acquireLease(array $job): bool {
        $token=hash('sha256',(string)$job['job_uuid'].'|'.microtime(true).'|'.mt_rand());$payload=['token'=>$token,'job_uuid'=>(string)$job['job_uuid'],'generation'=>(string)$job['generation'],'expires_at'=>time()+self::LEASE_TTL];$owned=add_option(PSERC_Plan_Snapshot_Store::LEASE_OPTION,$payload,'',false);
        if(!$owned){$old=get_option(PSERC_Plan_Snapshot_Store::LEASE_OPTION,[]);if(!is_array($old)||(int)($old['expires_at']??0)>=time())return false;delete_option(PSERC_Plan_Snapshot_Store::LEASE_OPTION);$owned=add_option(PSERC_Plan_Snapshot_Store::LEASE_OPTION,$payload,'',false);if(!$owned)return false;}
        $f=max(0,(int)get_option(PSERC_Plan_Snapshot_Store::FENCE_OPTION,0))+1;update_option(PSERC_Plan_Snapshot_Store::FENCE_OPTION,$f,false);$payload['fence']=$f;update_option(PSERC_Plan_Snapshot_Store::LEASE_OPTION,$payload,false);self::$leaseToken=$token;self::$leaseFence=$f;return true;
    }
    private static function releaseLease(): void {if(self::$leaseToken==='')return;$old=get_option(PSERC_Plan_Snapshot_Store::LEASE_OPTION,[]);if(is_array($old)&&hash_equals(self::$leaseToken,(string)($old['token']??''))&&(int)($old['fence']??0)===self::$leaseFence)delete_option(PSERC_Plan_Snapshot_Store::LEASE_OPTION);self::$leaseToken='';self::$leaseFence=0;}
}
