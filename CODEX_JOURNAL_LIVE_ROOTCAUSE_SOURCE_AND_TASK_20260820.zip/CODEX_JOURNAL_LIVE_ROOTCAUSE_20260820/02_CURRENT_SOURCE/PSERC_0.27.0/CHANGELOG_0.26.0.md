# PSERC 0.26.0

Root-Cause-Rebuild des Redaktionsplan-Ladepfads: bounded/resumable Compile-Job, record-lokale technische Generation, atomarer Snapshot und bounded read-only Admin-GET. Keine Aenderung an fachlichen Gates, Exact Five, PPM, Artikelinhalt, Titelregeln, Kategorien oder Publish.
