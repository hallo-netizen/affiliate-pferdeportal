# 0.27.0 – Signed Article-Type Extension Architecture Rootfix

- Consumes the shared signed `ARTICLE_TYPE_EXTENSION_MANIFEST_V1` used by PSTE and PPM.
- Journal requires independently proven explicit scope + intent; family/type/category miss is never evidence.
- Journal planning and portal-topic evidence independently re-verify the extension proof.
- Production Reader requires byte-identical signed extension manifests in PSERC and PPM.
- Existing FAQ/Beratung/Vergleich/Pflege decision and title logic is unchanged.
- Request-bounded resumable plan compilation and atomic snapshot activation from 0.26.0 remain unchanged.
