# START HIER

1. `05_CODEX_AUFTRAG_JOURNAL_LIVE_ROOTCAUSE_20260820.md` lesen.
2. Danach `01_MASTER_BINDING/` vollständig lesen; diese Regeln sind verbindlich.
3. `04_LIVE_EVIDENCE/` ist der echte aktuelle Livebefund.
4. `02_CURRENT_SOURCE/` ist der aktuell installierte Source-Stand.
5. `03_PRE_JOURNAL_REFERENCE/` dient ausschließlich zur Regressions-/Ursachenabgrenzung. Nicht zurückrollen oder blind kopieren.
