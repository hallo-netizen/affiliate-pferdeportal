# CODEX-AUFTRAG – JOURNAL LIVE-ROOTCAUSE / KEIN SYMPTOMFIX

## Oberste Autorität
Lies zuerst vollständig `01_MASTER_BINDING/`. Diese Dateien sind verbindlich. Keine eigene fachliche Regel erfinden und keine vorhandene Regel umdeuten.

## Ausgangslage
Installierter Stand und zu prüfender Source-Stand:
- PSTE 0.55.0
- PSERC 0.27.0
- PPM 6.7.9 Signed Extension Rootfix

Vor der Journal-Erweiterung lief der normale Artikelworkflow. Seit der neuen Beitragsart Journal ist der Live-Redaktionsplan wieder blockiert. Ziel ist NICHT, einzelne Fehlermeldungen wegzupatchen, sondern die Ursache so zu reparieren, dass additive Beitragsarten den bestehenden Workflow nicht erneut beschädigen.

## Bereits live belegter Fehler – nicht erneut raten
Die Dateien unter `04_LIVE_EVIDENCE/` stammen aus dem aktuell installierten Live-Stand.

1. PSTE-Livebestand: 562 Kandidaten.
2. 67 Kandidaten haben `decision=PASS` / Planung geeignet.
3. Diese 67 bestehen aus:
   - 55 Journal
   - 11 Beratung
   - 1 Pflege
4. Der PSERC-Live-Snapshot erzeugt daraus:
   - 0 READY
   - 55 `BLOCKED_CATEGORY_ARTICLE_TYPE_MISMATCH`
   - 12 `HELD_NO_ACTIVE_NORMAL_DRAFT_RELEASE`
5. Besonders wichtig: Die 55 live als PASS gespeicherten Journal-Kandidaten tragen noch den ALTEN Routing-Vertrag:
   - `journal_routing.contract = PSTE_JOURNAL_ROUTER_V1`
   - `semantic_consensus.selection_policy = FALLBACK_ONLY_AFTER_EXISTING_PRODUCT_FAMILY_MISS`
6. Das widerspricht dem verbindlichen aktuellen Master und dem aktuellen Source:
   - `EXPLICIT_SCOPE_AND_INTENT_ONLY_NO_FALLBACK`
   - nur zwei autorisierte Journal-Goldpiloten: `Wie alt werden Pferde?` und `Können Pferde schwimmen?`
7. Der aktuelle PSERC-Source verlangt für Extensions dagegen korrekt:
   - `PSTE_ARTICLE_TYPE_EXTENSION_ROUTE_V1`
   - `EXTENSION_ROUTE_PASS`
   - `PSTE_ARTICLE_TYPE_EXTENSION_CONSENSUS_V1`
   - unabhängige `ARTICLE_TYPE_EXTENSION_EVIDENCE_V1`
8. Damit ist ein zentraler Verdacht bereits stark belegt: neuer Source + alter persistierter PSTE-Kandidatenzustand werden live gemischt. Festzustellen ist exakt, warum die alte Journal-Entscheidung trotz 0.55.0 noch im aktiven Kandidatenbestand produktionsrelevant bleibt und warum der lokale 562er Test dies nicht erkannt hat.

## Hauptauftrag
Führe eine vollständige Root-Cause-Analyse über PSTE -> PSERC -> PPM durch und liefere einen EINZIGEN ursachenbezogenen Patchstand, der den Master erfüllt.

### A. Reproduktion
- Reproduziere den Live-Fehler aus den beiden JSON-Dateien unter `04_LIVE_EVIDENCE/` lokal.
- Beweise für die 55 Journal-Blocker den konkreten untersten Reason-Code, nicht nur den aggregierten PSERC-Status.
- Prüfe die beiden Goldpiloten separat.
- Prüfe die 53 übrigen Journal-PASS-Kandidaten separat.
- Prüfe die 12 Beratung/Pflege-Kandidaten separat; keine Vermischung mit dem Journal-Rootcause.

### B. Persistenz-/Migrationsursache
Ermittle exakt:
- warum PSTE 0.55.0 einen aktiven Bestand exportiert, der noch `PSTE_JOURNAL_ROUTER_V1` und `FALLBACK_ONLY_AFTER_EXISTING_PRODUCT_FAMILY_MISS` enthält;
- ob Kandidaten beim Plugin-Update nicht neu bewertet, nicht invalidiert, falsch gemerged oder durch Legacy-Fallbackfelder wieder als aktuell akzeptiert werden;
- welche Fingerprints/Schema-/Dependency-Gates die veralteten Extension-Felder hätten erkennen müssen;
- warum `verifiedExtensionAutomaticRelease()` bzw. die aktuelle Extension-Validierung die 55 alten PASS-Zustände nicht bereits im exportierten aktiven Bestand auf `REVIEW/BLOCKED/NON-JOURNAL` zurückgestuft hat;
- warum der lokale reale 562er Test „2 Journal-Gold / 560 kein automatisches Journal“ PASS melden konnte, obwohl der echte Liveexport 55 Journal-PASS enthält. Dieser falsche PASS muss als Testlücke reproduziert und geschlossen werden.

### C. Zielzustand
Nach dem Patch muss auf dem echten 562er Livebestand gelten:
- exakt die zwei signierten Goldpiloten dürfen Journal-PASS sein;
- die übrigen 560 dürfen durch die Journal-Extension keine automatische Journal-Zuordnung erhalten;
- insbesondere die 53 aktuell alten Journal-PASS müssen fail-closed aus Journal herausfallen, OHNE sie willkürlich einem anderen Artikeltyp zuzuweisen;
- keine globale Neuvalidierung fachlich unabhängiger Core-Daten nur wegen +1 Extension;
- keine Änderung bestehender FAQ-/Beratung-/Vergleich-/Pflege-Entscheidungen;
- keine Änderung bestehender Titel-, Kategorie-, Intent-, Slot-, Prompt-, Text-, HTML-, Design- oder Publishlogik;
- kein manueller PASS und kein manueller Workflow-Bypass;
- kein Löschen/Neuanlegen des gesamten Bestands als Reparaturstrategie;
- wenn eine Datenmigration nötig ist, ausschließlich eng begrenzt auf tatsächlich extension-abhängige persistierte Felder/Records und deterministisch/fail-closed.

### D. Redaktionsplan-Ziel
Nach korrekter bounded Revalidierung müssen die zwei Goldpiloten über den NORMALEN Workflow bis zum Metadaten-Handoff gelangen können.
Die 53 alten falschen Journal-PASS dürfen dort nicht mehr als Journal-Kandidaten erscheinen.
Die 12 Core-Holds sind getrennt zu analysieren. Sie dürfen den Journal-Fix nicht aufblasen. Wenn sie bereits vor Journal absichtlich durch bestehende PPM-Releaseverträge gehalten wurden, dokumentiere das und ändere daran NICHTS. Wenn Journal sie verändert hat, beweise die Regression gegen `03_PRE_JOURNAL_REFERENCE/`.

### E. Pflichtregression
Mindestens folgende Tests neu bzw. erweitert:
1. Echter `pste-global-seo-topic-map-20260820-115025-utc.json` als Regressionseingang.
2. Altvertrag `PSTE_JOURNAL_ROUTER_V1` darf unter aktuellem Extension-Manifest niemals READY/AUTO_RESOLVED bleiben.
3. `FALLBACK_ONLY_AFTER_EXISTING_PRODUCT_FAMILY_MISS` muss als veraltete/unerlaubte Extension-Evidenz fail-closed behandelt werden.
4. Beide Goldpiloten werden aus demselben Livebestand deterministisch in den neuen Generic-Extension-Vertrag überführt/revalidiert und PASS.
5. Die übrigen 53 alten Journal-PASS werden NICHT Journal-PASS.
6. Core-Kandidaten vor/nach Patch byte-/entscheidungsidentisch, soweit die Masterregel dies verlangt.
7. +1 Extension Isolationstest.
8. Source und Fresh-Unpack identische Tests.
9. PPM vollständige bestehende Testsuite.
10. Verbotene WordPress-Write-Callsites unverändert / keine neue Publish-Eskalation.

## Verbotene Lösungen
- Kein `if Journal then allow` in PSERC.
- Kein Abschwächen von `BLOCKED_CATEGORY_ARTICLE_TYPE_MISMATCH` oder Extension-Gates.
- Kein Akzeptieren des alten `PSTE_JOURNAL_ROUTER_V1` als neuen gültigen Beweis.
- Kein Adapter, der alten Fallback-PASS blind in `PSTE_ARTICLE_TYPE_EXTENSION_ROUTE_V1` umetikettiert.
- Kein globales Löschen des Topic-Pools.
- Kein kompletter Neuaufbau von Inventory/Context/Sandbox als Voraussetzung für +1 Beitragsart.
- Keine Änderung der Textmaschine oder ihrer Qualitäts-/Promptlogik.
- Keine Änderung an Core-Artikeltypen, nur damit Tests grün werden.

## Erwartete Lieferung
1. Root-Cause-Report mit exakter Fehlerkette und betroffenen Persistenz-/Codepfaden.
2. Liste aller geänderten Produktionsdateien mit Begründung.
3. Patch/Source als neuer sauberer Stand – nur wenn alle Pflichtprüfungen PASS sind.
4. Vollständige Positiv-/Negativ-Regressionsberichte inklusive echtem 562er Liveexport.
5. Fresh-Unpack-Prüfung und Hashparität.
6. Klare Aussage, welche Plugins tatsächlich neu installiert werden müssen.
7. KEINE Installations-ZIP, falls irgendein Gesamtworkflow-Test offen oder FAIL ist.

## Priorität
Primäres Ziel ist, den normalen Veröffentlichungsworkflow schnell und sauber wieder freizugeben. Nicht weiter architektonisch erweitern, wenn die nachgewiesene Ursache enger behoben werden kann. Trotzdem keine symptomatische Ausnahme für die zwei Goldtitel: die Persistenz-/Vertragsursache muss allgemein für additive Beitragsarten korrekt gelöst werden.
