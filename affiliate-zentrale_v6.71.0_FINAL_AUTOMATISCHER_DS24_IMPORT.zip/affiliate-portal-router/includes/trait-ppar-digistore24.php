<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Digistore24 adapter.
 *
 * Contract:
 * - read-only API access only;
 * - banner-only provider, never product/listing output;
 * - no provider-specific cron; use the central automation cursor only;
 * - API affiliation proof for automation; manual confirmation only for manual import;
 * - provider-local failures never starve other automation providers.
 */
trait PPAR_Digistore24_Trait {
    /** @var array In-request context for the current DS24 refresh; never persisted as authority. */
    private $digistore24_operation_context = array();
    private function digistore24_register_hooks() {
        add_filter('ppar_affiliate_provider_registry', array($this, 'digistore24_provider_registry'), 10, 2);
        add_filter('ppar_affiliate_provider_access_snapshot', array($this, 'digistore24_provider_access_snapshot'), 10, 4);
        add_filter('ppar_affiliate_provider_access_save', array($this, 'digistore24_provider_access_save'), 10, 4);
        add_filter('ppar_affiliate_provider_access_test', array($this, 'digistore24_provider_access_test'), 10, 4);
        add_filter('ppar_affiliate_automation_scheduled_sources', array($this, 'digistore24_automation_scheduled_sources'), 10, 3);
        add_filter('ppar_affiliate_automation_dispatch', array($this, 'digistore24_automation_dispatch'), 10, 5);
        add_action('ppar_affiliate_render_provider_access_card_digistore24', array($this, 'digistore24_render_access_card'), 10, 3);
        add_action('ppar_affiliate_render_provider_specialist_digistore24', array($this, 'digistore24_render_specialist'), 10, 3);
        add_action('admin_post_ppar_digistore24_marketplace_refresh', array($this, 'digistore24_handle_marketplace_refresh'));
        add_action('admin_post_ppar_digistore24_source_register', array($this, 'digistore24_handle_source_register'));
        add_action('admin_post_ppar_digistore24_sources_bulk_register', array($this, 'digistore24_handle_sources_bulk_register'));
        add_action('admin_post_ppar_digistore24_bulk_refresh', array($this, 'digistore24_handle_bulk_refresh'));
        add_action('admin_post_ppar_digistore24_partnership', array($this, 'digistore24_handle_partnership'));
        add_action('admin_post_ppar_digistore24_import_banners', array($this, 'digistore24_handle_import_banners'));
        add_action('shutdown', array($this, 'digistore24_final_publication_guard'), 999);
    }

    public function digistore24_provider_registry($registry, $contract_version = '') {
        $registry = is_array($registry) ? $registry : array();
        $registry['digistore24'] = array(
            'label' => 'Digistore24',
            'state' => 'active',
            'access_owner' => 'adapter',
            'specialist_menu' => true,
            'specialist_slug' => 'affiliate-portal-provider-digistore24',
            'capabilities' => array('credentials','connection_test','marketplace','partners','automation','creatives','outputs','veto'),
        );
        return $registry;
    }

    private function digistore24_settings_defaults() {
        return array(
            'enabled' => false,
            'enable_requested' => false,
            'api_key' => '',
            'tested_key_fingerprint' => '',
            'affiliate_id' => '',
            'last_status' => 'not_configured',
            'last_checked' => 0,
            'last_message' => '',
        );
    }

    private function digistore24_settings() {
        $stored = get_option('ppar_network_digistore24_v1', array());
        $stored = is_array($stored) ? $stored : array();
        return array_merge($this->digistore24_settings_defaults(), $stored);
    }

    private function digistore24_normalize_affiliate_id($value) {
        $raw = trim(sanitize_text_field((string) $value));
        if ($raw === '') {
            return '';
        }
        $safe = preg_replace('/[^0-9A-Za-z._-]/', '', $raw);
        // Affiliate identity is attribution-critical: never silently rewrite the
        // API-reported ID into a different URL segment. Non-canonical values are
        // rejected until a real read-only API test provides an exact safe ID.
        return is_string($safe) && $safe !== '' && hash_equals($raw, $safe) ? $safe : '';
    }

    private function digistore24_update_settings($settings) {
        $settings = array_merge($this->digistore24_settings_defaults(), is_array($settings) ? $settings : array());
        $settings['enabled'] = !empty($settings['enabled']);
        $settings['enable_requested'] = !empty($settings['enable_requested']);
        $settings['api_key'] = trim((string) ($settings['api_key'] ?? ''));
        $settings['tested_key_fingerprint'] = preg_replace('/[^a-f0-9]/', '', strtolower((string) ($settings['tested_key_fingerprint'] ?? '')));
        $settings['affiliate_id'] = $this->digistore24_normalize_affiliate_id($settings['affiliate_id'] ?? '');
        $settings['last_status'] = sanitize_key((string) ($settings['last_status'] ?? 'not_configured'));
        $settings['last_checked'] = absint($settings['last_checked'] ?? 0);
        $settings['last_message'] = sanitize_text_field((string) ($settings['last_message'] ?? ''));
        update_option('ppar_network_digistore24_v1', $settings, false);
        return $settings;
    }

    private function digistore24_api_key($settings = null) {
        if (defined('PPAR_DIGISTORE24_API_KEY') && trim((string) PPAR_DIGISTORE24_API_KEY) !== '') {
            return trim((string) PPAR_DIGISTORE24_API_KEY);
        }
        $settings = is_array($settings) ? $settings : $this->digistore24_settings();
        return trim((string) ($settings['api_key'] ?? ''));
    }

    private function digistore24_key_fingerprint($key) {
        $key = trim((string) $key);
        return $key === '' ? '' : hash('sha256', $key);
    }

    private function digistore24_fingerprint_matches($settings = null) {
        $settings = is_array($settings) ? $settings : $this->digistore24_settings();
        $key = $this->digistore24_api_key($settings);
        $tested = strtolower(trim((string) ($settings['tested_key_fingerprint'] ?? '')));
        return $key !== '' && strlen($tested) === 64 && hash_equals($tested, $this->digistore24_key_fingerprint($key));
    }

    private function digistore24_automation_ready($settings = null) {
        $settings = is_array($settings) ? $settings : $this->digistore24_settings();
        $affiliate_id = $this->digistore24_normalize_affiliate_id($settings['affiliate_id'] ?? '');
        return !empty($settings['enabled'])
            && $this->digistore24_fingerprint_matches($settings)
            && $affiliate_id !== '';
    }

    public function digistore24_provider_access_snapshot($snapshot, $provider, $definition = array(), $contract_version = '') {
        if (sanitize_key((string) $provider) !== 'digistore24') {
            return $snapshot;
        }
        $settings = $this->digistore24_settings();
        $key = $this->digistore24_api_key($settings);
        $snapshot = is_array($snapshot) ? $snapshot : array();
        $snapshot['provider'] = 'digistore24';
        $snapshot['label'] = 'Digistore24';
        $snapshot['configured'] = $key !== '';
        $snapshot['enabled'] = $this->digistore24_automation_ready($settings);
        $snapshot['status'] = sanitize_key((string) ($settings['last_status'] ?? ($key !== '' ? 'credentials_saved' : 'not_configured')));
        $snapshot['last_checked'] = absint($settings['last_checked'] ?? 0);
        $snapshot['message'] = sanitize_text_field((string) ($settings['last_message'] ?? ''));
        if ($key === '') {
            $snapshot['status'] = 'not_configured';
            $snapshot['enabled'] = false;
        } elseif (!$this->digistore24_fingerprint_matches($settings) && $snapshot['status'] === 'connected') {
            $snapshot['status'] = 'credentials_saved';
            $snapshot['enabled'] = false;
        }
        return $snapshot;
    }

    public function digistore24_provider_access_save($handled, $provider, $raw, $contract_version = '') {
        if (sanitize_key((string) $provider) !== 'digistore24') {
            return $handled;
        }
        $raw = is_array($raw) ? $raw : array();
        $previous = $this->digistore24_settings();
        $settings = $previous;
        $mode = sanitize_key((string) ($_POST['ppar_provider_action'] ?? 'save'));
        $requested_enabled = !empty($raw['enabled']);
        $constant_key = defined('PPAR_DIGISTORE24_API_KEY') && trim((string) PPAR_DIGISTORE24_API_KEY) !== '';
        $submitted_key = trim((string) ($raw['api_key'] ?? ''));
        $remove_key = !$constant_key && !empty($raw['remove_api_key']);

        if (!$constant_key) {
            if ($submitted_key !== '') {
                $settings['api_key'] = $submitted_key;
            }
            if ($remove_key) {
                $settings['api_key'] = '';
            }
        }

        $old_key = $this->digistore24_api_key($previous);
        $new_key = $this->digistore24_api_key($settings);
        $credentials_changed = !hash_equals($this->digistore24_key_fingerprint($old_key), $this->digistore24_key_fingerprint($new_key));

        $settings['enable_requested'] = $requested_enabled;
        if ($credentials_changed || $new_key === '') {
            $settings['enabled'] = false;
            $settings['tested_key_fingerprint'] = '';
            $settings['affiliate_id'] = '';
            $settings['last_status'] = $new_key === '' ? 'not_configured' : 'credentials_saved';
            $settings['last_message'] = $new_key === ''
                ? 'Digistore24-API-Schlüssel fehlt; Provider bleibt deaktiviert.'
                : 'Digistore24-API-Schlüssel geändert; erneuter read-only API-Test erforderlich.';
            $settings['last_checked'] = 0;
        } else {
            $fingerprint_ok = $this->digistore24_fingerprint_matches($settings);
            $affiliate_id_ok = $this->digistore24_normalize_affiliate_id($settings['affiliate_id'] ?? '') !== '';
            $settings['enabled'] = $requested_enabled && $fingerprint_ok && $affiliate_id_ok;
            if (!$requested_enabled) {
                $settings['last_message'] = 'Digistore24-Verbindung gespeichert; Nutzung ist bewusst deaktiviert.';
            } elseif (!$fingerprint_ok || !$affiliate_id_ok) {
                $settings['last_status'] = 'credentials_saved';
                $settings['last_message'] = 'Digistore24-Zugang gespeichert; Aktivierung bleibt bis zum erfolgreichen read-only API-Test mit verwertbarer Affiliate-ID gesperrt.';
            }
        }

        // In save_test mode the subsequent generic test callback may fulfill the
        // remembered enable request in the same request, but never before PASS.
        if ($mode === 'save_test' && $new_key !== '') {
            $settings['enabled'] = false;
        }
        return $this->digistore24_update_settings($settings);
    }

    public function digistore24_provider_access_test($handled, $provider, $contract_version = '') {
        if (sanitize_key((string) $provider) !== 'digistore24') {
            return $handled;
        }
        $settings = $this->digistore24_settings();
        $key = $this->digistore24_api_key($settings);
        if ($key === '') {
            $current_settings = $this->digistore24_settings();
            if ($this->digistore24_api_key($current_settings) !== '') {
                return new WP_Error('digistore24_credentials_changed_during_test', 'Digistore24-Zugang wurde während des API-Tests geändert; Ergebnis wird verworfen und der neue Zugang bleibt unangetastet.');
            }
            $settings = $current_settings;
            $settings['enabled'] = false;
            $settings['last_status'] = 'not_configured';
            $settings['last_checked'] = time();
            $settings['last_message'] = 'Digistore24-API-Schlüssel fehlt.';
            $this->digistore24_update_settings($settings);
            return new WP_Error('digistore24_api_key_missing', 'Digistore24-API-Schlüssel fehlt.');
        }
        $request_key_fingerprint = $this->digistore24_key_fingerprint($key);
        $response = $this->digistore24_api_call('getUserInfo');
        if (is_wp_error($response)) {
            $current_settings = $this->digistore24_settings();
            $current_key_fingerprint = $this->digistore24_key_fingerprint($this->digistore24_api_key($current_settings));
            if (!hash_equals($request_key_fingerprint, $current_key_fingerprint)) {
                return new WP_Error('digistore24_credentials_changed_during_test', 'Digistore24-Zugang wurde während des API-Tests geändert; Fehler des alten Zugangs wird verworfen und der neue Zugang bleibt unangetastet.');
            }
            $settings = $current_settings;
            $settings['enabled'] = false;
            $settings['last_status'] = 'failed';
            $settings['last_checked'] = time();
            $settings['last_message'] = 'Read-only API-Test fehlgeschlagen: ' . $response->get_error_message();
            $this->digistore24_update_settings($settings);
            return $response;
        }
        $response_key_fingerprint = strtolower(trim((string) ($response['key_fingerprint'] ?? '')));
        $current_settings = $this->digistore24_settings();
        $current_key_fingerprint = $this->digistore24_key_fingerprint($this->digistore24_api_key($current_settings));
        if ($response_key_fingerprint === ''
            || !hash_equals($request_key_fingerprint, $response_key_fingerprint)
            || !hash_equals($current_key_fingerprint, $response_key_fingerprint)) {
            // A concurrent credential change must win. Never overwrite a newer
            // key with the stale settings snapshot that started this API test.
            return new WP_Error('digistore24_credentials_changed_during_test', 'Digistore24-Zugang wurde während des API-Tests geändert; Ergebnis wird verworfen und der neue Zugang bleibt unangetastet.');
        }
        $settings = $current_settings;
        $data = is_array($response['data'] ?? null) ? $response['data'] : array();
        $affiliate_raw = trim(sanitize_text_field((string) ($data['user_name'] ?? '')));
        $affiliate_id = $this->digistore24_normalize_affiliate_id($affiliate_raw);
        if ($affiliate_raw === '') {
            $settings['enabled'] = false;
            $settings['tested_key_fingerprint'] = '';
            $settings['affiliate_id'] = '';
            $settings['last_status'] = 'failed';
            $settings['last_checked'] = time();
            $settings['last_message'] = 'Digistore24 antwortete, aber die Affiliate-ID (user_name) fehlt.';
            $this->digistore24_update_settings($settings);
            return new WP_Error('digistore24_user_name_missing', 'Digistore24-API-Test ohne verwertbare Affiliate-ID.');
        }
        if ($affiliate_id === '') {
            $settings['enabled'] = false;
            $settings['tested_key_fingerprint'] = '';
            $settings['affiliate_id'] = '';
            $settings['last_status'] = 'failed';
            $settings['last_checked'] = time();
            $settings['last_message'] = 'Digistore24 antwortete mit einer Affiliate-ID, die nicht unverändert als sicherer Tracking-Pfad verwendet werden kann.';
            $this->digistore24_update_settings($settings);
            return new WP_Error('digistore24_user_name_invalid', 'Digistore24-API-Test lieferte keine kanonische, provisionssicher verwendbare Affiliate-ID.');
        }
        $settings['tested_key_fingerprint'] = $this->digistore24_key_fingerprint($key);
        $settings['affiliate_id'] = $affiliate_id;
        $settings['last_status'] = 'connected';
        $settings['last_checked'] = time();
        $settings['enabled'] = !empty($settings['enable_requested']);
        $settings['last_message'] = $settings['enabled']
            ? 'Digistore24 read-only API erfolgreich geprüft; Verbindung ist aktiviert.'
            : 'Digistore24 read-only API erfolgreich geprüft; Verbindung bleibt bewusst deaktiviert.';
        $this->digistore24_update_settings($settings);
        return array('status'=>'connected','message'=>$settings['last_message'],'affiliate_id'=>$affiliate_id);
    }

    private function digistore24_api_allowed_methods() {
        // Only documented read-only endpoints that this plugin actually uses.
        // Digistore24 currently exposes no documented endpoint that lists all
        // vendor partnerships of the logged-in affiliate. Marketplace calls may
        // enrich a source but never create partnership authority.
        return array('getUserInfo','listMarketplaceEntries','getMarketplaceEntry','validateAffiliate');
    }

    private function digistore24_api_safe_params($method, $params = array()) {
        $method = trim((string) $method);
        $params = is_array($params) ? $params : array();
        if ($method === 'getUserInfo' || $method === 'listMarketplaceEntries') {
            return array();
        }
        if ($method === 'getMarketplaceEntry') {
            $entry_id = trim((string) ($params['entry_id'] ?? $params['entryId'] ?? ''));
            if ($entry_id === '' || !ctype_digit($entry_id) || (string) absint($entry_id) !== $entry_id) {
                return new WP_Error('digistore24_api_entry_id_invalid', 'Marketplace-Entry-ID ist nicht kanonisch numerisch.');
            }
            return array('entry_id'=>$entry_id);
        }
        if ($method === 'validateAffiliate') {
            $identity = $this->digistore24_current_tested_identity();
            $expected_affiliate = $this->digistore24_normalize_affiliate_id($identity['affiliate_id'] ?? '');
            $affiliate_name = $this->digistore24_normalize_affiliate_id($params['affiliate_name'] ?? $params['affiliateName'] ?? '');
            if ($expected_affiliate === '' || $affiliate_name === '' || !hash_equals($expected_affiliate, $affiliate_name)) {
                return new WP_Error('digistore24_api_affiliate_identity_mismatch', 'validateAffiliate darf nur für die aktuell erfolgreich geprüfte eigene Affiliate-ID ausgeführt werden.');
            }
            $raw_ids = trim((string) ($params['product_ids'] ?? $params['productIds'] ?? ''));
            if ($raw_ids === '') {
                return new WP_Error('digistore24_api_product_ids_missing', 'validateAffiliate benötigt mindestens eine Produkt-ID.');
            }
            $ids = array_values(array_unique(array_map('trim', explode(',', $raw_ids))));
            if (!$ids || count($ids) > 50) {
                return new WP_Error('digistore24_api_product_ids_invalid', 'validateAffiliate erlaubt in diesem Vertrag 1 bis 50 kanonische Produkt-IDs.');
            }
            foreach ($ids as $id) {
                if ($id === '' || !ctype_digit($id) || (string) absint($id) !== $id) {
                    return new WP_Error('digistore24_api_product_id_invalid', 'validateAffiliate enthält eine nicht-kanonische Produkt-ID.');
                }
            }
            return array('affiliate_name'=>$affiliate_name, 'product_ids'=>implode(',', $ids));
        }
        return new WP_Error('digistore24_api_method_blocked', 'Nicht freigegebener Digistore24-API-Pfad blockiert.');
    }

    private function digistore24_api_call($method, $params = array()) {
        $method = trim((string) $method);
        if (!in_array($method, $this->digistore24_api_allowed_methods(), true)) {
            return new WP_Error('digistore24_api_method_blocked', 'Nicht freigegebener Digistore24-API-Pfad blockiert.');
        }
        $settings = $this->digistore24_settings();
        $key = $this->digistore24_api_key($settings);
        if ($key === '') {
            return new WP_Error('digistore24_api_key_missing', 'Digistore24-API-Schlüssel fehlt.');
        }
        $safe_params = $this->digistore24_api_safe_params($method, $params);
        if (is_wp_error($safe_params)) { return $safe_params; }
        $url = 'https://www.digistore24.com/api/call/' . rawurlencode($method);
        if ($safe_params) {
            $url = add_query_arg($safe_params, $url);
        }
        $response = wp_safe_remote_get($url, array(
            'timeout' => 20,
            'redirection' => 0,
            'limit_response_size' => 4 * 1024 * 1024,
            'headers' => array(
                'Accept' => 'application/json',
                'X-DS-API-KEY' => $key,
            ),
        ));
        if (is_wp_error($response)) {
            return new WP_Error('digistore24_api_http', 'Digistore24-API nicht erreichbar: ' . $response->get_error_message());
        }
        $code = absint(wp_remote_retrieve_response_code($response));
        if ($code < 200 || $code >= 300) {
            return new WP_Error('digistore24_api_http_status', 'Digistore24-API antwortete mit HTTP ' . $code . '.');
        }
        $body = (string) wp_remote_retrieve_body($response);
        $decoded = json_decode($body, true);
        if (!is_array($decoded)) {
            return new WP_Error('digistore24_api_json', 'Digistore24-API lieferte keine gültige JSON-Antwort.');
        }
        $result = strtolower(trim((string) ($decoded['result'] ?? '')));
        if ($result !== 'success') {
            $message = sanitize_text_field((string) ($decoded['message'] ?? $decoded['error'] ?? 'API-Ergebnis ist nicht success.'));
            return new WP_Error('digistore24_api_result', 'Digistore24-API-Fehler: ' . $message);
        }
        $data = $decoded['data'] ?? array();
        if (!is_array($data)) {
            $data = array();
        }
        return array(
            'result'=>'success',
            'data'=>$data,
            'http_code'=>$code,
            // PII-free request identity. Callers use this only to reject stale
            // responses when credentials are rotated concurrently.
            'key_fingerprint'=>$this->digistore24_key_fingerprint($key),
        );
    }

    private function digistore24_semantic_support_url($payload) {
        $found = array();
        $walk = function($value, $path = '') use (&$walk, &$found) {
            if (is_array($value)) {
                foreach ($value as $key => $child) {
                    $key = sanitize_key((string) $key);
                    $walk($child, $path === '' ? $key : ($path . '.' . $key));
                }
                return;
            }
            if (!is_string($value) && !is_numeric($value)) { return; }
            $url = esc_url_raw(trim((string) $value));
            if (!$this->digistore24_is_https_url($url)) { return; }
            $semantic = sanitize_key(str_replace('.', '_', $path));
            // Marketplace payloads have historically used different field names.
            // Accept only keys that explicitly describe affiliate/support/advertising
            // material. Never reinterpret a sales/checkout/buyer support URL.
            $positive = (
                (str_contains($semantic, 'affiliate') && (str_contains($semantic, 'support') || str_contains($semantic, 'material') || str_contains($semantic, 'media'))) ||
                str_contains($semantic, 'werbemittel') ||
                (str_contains($semantic, 'advert') && (str_contains($semantic, 'material') || str_contains($semantic, 'media') || str_contains($semantic, 'support'))) ||
                str_contains($semantic, 'promo_material') ||
                str_contains($semantic, 'promomaterial') ||
                str_contains($semantic, 'support_page') ||
                str_contains($semantic, 'supportpage')
            );
            $negative = str_contains($semantic, 'buyer') || str_contains($semantic, 'customer') || str_contains($semantic, 'checkout') || str_contains($semantic, 'orderform') || str_contains($semantic, 'salespage') || str_contains($semantic, 'thankyou');
            if ($positive && !$negative) { $found[$url] = true; }
        };
        $walk(is_array($payload) ? $payload : array());
        return $found ? (string) array_key_first($found) : '';
    }

    private function digistore24_normalize_marketplace_entry($entry) {
        $entry = is_array($entry) ? $entry : array();
        $id = trim((string) ($entry['id'] ?? ''));
        if ($id === '') {
            return new WP_Error('digistore24_entry_invalid', 'Marketplace-Eintrag ohne ID blockiert.');
        }
        if (!ctype_digit($id)) {
            return new WP_Error('digistore24_entry_id_invalid', 'Marketplace-Entry-ID ist nicht kanonisch numerisch und wird nicht stillschweigend verändert.');
        }
        $approval = strtolower(trim((string) ($entry['approval_status'] ?? '')));
        // Candidate inventory is fail-closed: only entries Digistore24 itself
        // marks as approved are worth an affiliation recheck. Empty/pending/
        // rejected marketplace status must never inflate the automatic run.
        if ($approval !== 'approved') {
            return new WP_Error('digistore24_entry_not_approved', 'Marketplace-Eintrag ' . $id . ' ist nicht ausdrücklich freigegeben (' . sanitize_key($approval !== '' ? $approval : 'missing') . ').');
        }
        $main_product_id = trim((string) ($entry['main_product_id'] ?? ''));
        if ($main_product_id !== '' && (!ctype_digit($main_product_id) || (string) absint($main_product_id) !== $main_product_id)) {
            return new WP_Error('digistore24_main_product_id_invalid', 'Digistore24-Hauptprodukt-ID ist nicht kanonisch numerisch und wird nicht für Tracking/Fallback verwendet.');
        }
        $all_product_ids = array();
        foreach ((array) ($entry['all_product_ids'] ?? array()) as $raw_product_id) {
            $product_id = trim((string) $raw_product_id);
            if ($product_id !== '' && ctype_digit($product_id) && (string) absint($product_id) === $product_id) {
                $all_product_ids[$product_id] = true;
            }
        }
        if ($main_product_id !== '') { $all_product_ids[$main_product_id] = true; }
        return array(
            'id' => $id,
            'main_product_id' => $main_product_id,
            'all_product_ids' => array_keys($all_product_ids),
            'approval_status' => $approval,
            'approval_status_msg' => sanitize_text_field((string) ($entry['approval_status_msg'] ?? '')),
            'headline' => sanitize_text_field((string) ($entry['headline'] ?? '')),
            'description' => sanitize_textarea_field(wp_strip_all_tags((string) ($entry['description'] ?? ''))),
            'product_category' => sanitize_text_field((string) ($entry['product_category'] ?? '')),
            'product_category_id' => absint($entry['product_category_id'] ?? 0),
            'affiliate_share' => isset($entry['affiliate_share']) && is_numeric($entry['affiliate_share']) ? (float) $entry['affiliate_share'] : null,
            'stats_stars' => isset($entry['stats_stars']) && is_numeric($entry['stats_stars']) ? (float) $entry['stats_stars'] : null,
            'stats_count_orders' => absint($entry['stats_count_orders'] ?? 0),
            'support_url' => $this->digistore24_semantic_support_url($entry),
        );
    }

    private function digistore24_current_tested_identity($settings = null) {
        $settings = is_array($settings) ? $settings : $this->digistore24_settings();
        if (!$this->digistore24_fingerprint_matches($settings)) {
            return array('key_fingerprint'=>'','affiliate_id'=>'');
        }
        $key = $this->digistore24_api_key($settings);
        $affiliate_id = $this->digistore24_normalize_affiliate_id($settings['affiliate_id'] ?? '');
        if ($key === '' || $affiliate_id === '') {
            return array('key_fingerprint'=>'','affiliate_id'=>'');
        }
        return array(
            'key_fingerprint' => $this->digistore24_key_fingerprint($key),
            'affiliate_id' => $affiliate_id,
        );
    }

    private function digistore24_bool($value) {
        if (is_bool($value)) { return $value; }
        if (is_int($value) || is_float($value)) { return (int) $value === 1; }
        $value = strtolower(trim((string) $value));
        return in_array($value, array('1','true','yes','y','on','active'), true);
    }

    private function digistore24_canonical_promolink($product_id, $affiliate_id = '') {
        $product_id = trim((string) $product_id);
        if ($product_id === '' || !ctype_digit($product_id) || (string) absint($product_id) !== $product_id) { return ''; }
        if ($affiliate_id === '') {
            $settings = $this->digistore24_settings();
            $affiliate_id = $this->digistore24_normalize_affiliate_id($settings['affiliate_id'] ?? '');
        } else {
            $affiliate_id = $this->digistore24_normalize_affiliate_id($affiliate_id);
        }
        if ($affiliate_id === '') { return ''; }
        return 'https://www.checkout-ds24.com/redir/' . rawurlencode($product_id) . '/' . rawurlencode($affiliate_id);
    }

    /*
     * Digistore24 exposes no documented endpoint that directly lists all vendor
     * partnerships of the current affiliate. The documented Marketplace response
     * does expose an approval_status per entry, so it is used only as candidate
     * inventory. No subject/horse keyword is allowed to exclude an approved entry.
     * Every product ID must still pass the documented read-only validateAffiliate
     * endpoint for the exact currently tested Affiliate-ID before it becomes
     * source authority. getAffiliateCommission is deliberately not used because
     * it is a vendor-side commission-setting path, not our partnership inventory.
     */

    private function digistore24_discovery_domain_profile() {
        $domain_terms = array('pferd','pferde','pony','fohlen','reitsport','reiter','horsemanship','equestrian','equine');
        $negative_terms = array('hund','hunde','katze','katzen','kleintier','kleintiere','vogel','voegel','exoten');
        if (method_exists($this, 'output_portal_registry')) {
            $registry = $this->output_portal_registry();
            if (is_array($registry)) {
                foreach ($registry as $portal) {
                    if (!is_array($portal) || empty($portal['enabled']) || empty($portal['local'])) { continue; }
                    $domain_terms = array_merge($domain_terms, (array) ($portal['domain_terms'] ?? array()));
                    $negative_terms = array_merge($negative_terms, (array) ($portal['negative_terms'] ?? array()));
                    break;
                }
            }
        }
        $domain_terms = array_values(array_unique(array_filter(array_map('sanitize_text_field', $domain_terms))));
        $negative_terms = array_values(array_unique(array_filter(array_map('sanitize_text_field', $negative_terms))));
        return array('domain_terms'=>$domain_terms, 'negative_terms'=>$negative_terms);
    }

    private function digistore24_marketplace_entry_matches_portal_domain($entry) {
        $entry = is_array($entry) ? $entry : array();
        $profile = $this->digistore24_discovery_domain_profile();
        $text = remove_accents(strtolower(wp_strip_all_tags(implode(' ', array_filter(array_map('strval', array(
            $entry['headline'] ?? '', $entry['description'] ?? '', $entry['product_category'] ?? '',
        )))))));
        $text = trim((string) preg_replace('/[^a-z0-9]+/', ' ', $text));
        if ($text === '') { return false; }
        foreach ((array) ($profile['negative_terms'] ?? array()) as $term) {
            $term = trim(remove_accents(strtolower((string) $term)));
            if ($term !== '' && preg_match('/\b' . preg_quote($term, '/') . '[a-z0-9]*\b/', $text)) { return false; }
        }
        foreach ((array) ($profile['domain_terms'] ?? array()) as $term) {
            $term = trim(remove_accents(strtolower((string) $term)));
            if ($term !== '' && preg_match('/\b' . preg_quote($term, '/') . '[a-z0-9]*\b/', $text)) { return true; }
        }
        return false;
    }

    private function digistore24_validate_affiliation_product($product_id) {
        $product_id = trim((string) $product_id);
        if ($product_id === '' || !ctype_digit($product_id) || (string) absint($product_id) !== $product_id) {
            return new WP_Error('digistore24_product_id_invalid', 'Digistore24-Produkt-ID ist nicht kanonisch numerisch.');
        }
        $identity_before = $this->digistore24_current_tested_identity();
        $affiliate_id = $this->digistore24_normalize_affiliate_id($identity_before['affiliate_id'] ?? '');
        $fp_before = strtolower(trim((string) ($identity_before['key_fingerprint'] ?? '')));
        if ($affiliate_id === '' || strlen($fp_before) !== 64) {
            return new WP_Error('digistore24_identity_not_tested', 'Aktueller Digistore24-Zugang besitzt keine erfolgreich geprüfte Identität.');
        }
        $response = $this->digistore24_api_call('validateAffiliate', array(
            'affiliate_name'=>$affiliate_id,
            'product_ids'=>$product_id,
        ));
        if (is_wp_error($response)) { return $response; }
        $identity_after = $this->digistore24_current_tested_identity();
        $fp_after = strtolower(trim((string) ($identity_after['key_fingerprint'] ?? '')));
        $response_fp = strtolower(trim((string) ($response['key_fingerprint'] ?? '')));
        if (strlen($response_fp) !== 64 || !hash_equals($fp_before, $response_fp) || !hash_equals($fp_after, $response_fp)
            || !hash_equals($affiliate_id, $this->digistore24_normalize_affiliate_id($identity_after['affiliate_id'] ?? ''))) {
            return new WP_Error('digistore24_identity_changed_during_request', 'Digistore24-Zugang wurde während validateAffiliate geändert; Antwort wird verworfen.');
        }
        $data = is_array($response['data'] ?? null) ? $response['data'] : array();
        if (!array_key_exists('have_affiliation', $data) || !array_key_exists('affiliation_status', $data)) {
            return new WP_Error('digistore24_validate_affiliate_schema_invalid', 'validateAffiliate lieferte keinen vollständigen Partnerschaftsnachweis.');
        }
        $invalid_affiliate = $this->digistore24_bool($data['invalid_affiliate_name'] ?? false);
        $have_affiliation = $this->digistore24_bool($data['have_affiliation'] ?? false);
        $status = sanitize_key((string) ($data['affiliation_status'] ?? ''));
        $valid_ids = array_values(array_filter(array_map('trim', explode(',', (string) ($data['valid_product_ids'] ?? '')))));
        $invalid_ids = array_values(array_filter(array_map('trim', explode(',', (string) ($data['invalid_product_ids'] ?? '')))));
        $product_valid = !$valid_ids || in_array($product_id, $valid_ids, true);
        if (in_array($product_id, $invalid_ids, true)) { $product_valid = false; }
        return array(
            'product_id'=>$product_id,
            'approved'=>!$invalid_affiliate && $have_affiliation && $status === 'approved' && $product_valid,
            'have_affiliation'=>$have_affiliation,
            'affiliation_status'=>$status,
            'invalid_affiliate_name'=>$invalid_affiliate,
            'product_valid'=>$product_valid,
            'status_message'=>sanitize_text_field((string) ($data['affiliation_status_msg'] ?? '')),
            'checked_at'=>time(),
            'affiliate_id'=>$affiliate_id,
            'key_fingerprint'=>$response_fp,
        );
    }

    private function digistore24_discover_approved_partnership_sources() {
        if (!$this->digistore24_automation_ready()) {
            return new WP_Error('digistore24_not_ready', 'Digistore24 ist nicht aktiviert oder der aktuelle Zugang wurde nicht erfolgreich geprüft.');
        }
        $identity = $this->digistore24_current_tested_identity();
        $store = $this->digistore24_marketplace_store();
        $existing_by_product = array();
        $known_support_by_entry = array();
        foreach ((array) ($store['items'] ?? array()) as $item) {
            if (!is_array($item)) { continue; }
            $pid = trim((string) ($item['main_product_id'] ?? $item['id'] ?? ''));
            if ($pid !== '' && ctype_digit($pid) && (string) absint($pid) === $pid) {
                $existing_by_product[$pid] = $item;
            }
            $entry_id = trim((string) ($item['marketplace_entry_id'] ?? ''));
            $support = (string) ($item['support_url'] ?? '');
            if ($entry_id !== '' && ctype_digit($entry_id) && $this->digistore24_is_https_url($support)) {
                $known_support_by_entry[$entry_id] = esc_url_raw($support);
            }
        }

        // Automatic inventory starts with the documented Marketplace response.
        // The normalizer keeps only entries explicitly marked approved by
        // Digistore24. This is still candidate evidence only; validateAffiliate is
        // the final per-product partnership proof. Crucially, there is NO horse/
        // dog/text exclusion before that proof.
        $market = $this->digistore24_fetch_marketplace_index();
        $market_error = is_wp_error($market) ? $market : null;
        $market_by_product = $market_error ? array() : (array) ($market['by_product'] ?? array());
        $market_by_entry = $market_error ? array() : (array) ($market['by_entry'] ?? array());
        if (!$market_error) {
            $market_fp = strtolower(trim((string) ($market['key_fingerprint'] ?? '')));
            if (strlen($market_fp) !== 64 || !hash_equals((string) ($identity['key_fingerprint'] ?? ''), $market_fp)) {
                return new WP_Error('digistore24_marketplace_identity_mismatch', 'Marketplace-Abruf gehört nicht zum aktuell getesteten Digistore24-Zugang.');
            }
        }
        if ($market_error && !$existing_by_product) {
            return new WP_Error('digistore24_discovery_inventory_unavailable', 'Digistore24-Marketplace-Inventar ist nicht lesbar; bestehende Ausgaben bleiben unverändert.');
        }

        $candidate_meta = array();
        $candidate_order = array();
        $push_candidate = function($pid, $meta) use (&$candidate_meta, &$candidate_order) {
            $pid = trim((string) $pid);
            if ($pid === '' || !ctype_digit($pid) || (string) absint($pid) !== $pid) { return; }
            if (!isset($candidate_meta[$pid])) { $candidate_order[] = $pid; $candidate_meta[$pid] = array(); }
            if (is_array($meta)) { $candidate_meta[$pid] = array_merge($candidate_meta[$pid], $meta); }
        };

        // 1) portal-relevant approved marketplace entries are merely a PRIORITY.
        // They are not an exclusion criterion. This keeps the common horse case
        // fast without repeating the old generic-name false negative.
        foreach ($market_by_entry as $entry) {
            if (!is_array($entry) || !$this->digistore24_marketplace_entry_matches_portal_domain($entry)) { continue; }
            foreach ((array) ($entry['all_product_ids'] ?? array()) as $pid) { $push_candidate($pid, $entry); }
            $push_candidate((string) ($entry['main_product_id'] ?? ''), $entry);
        }
        // 2) every other explicitly approved marketplace product follows. This is
        // the root-cause fix: generic vendor names, mixed animal wording or a weak
        // category can no longer make a confirmed partnership disappear.
        foreach ($market_by_product as $pid => $entry) { $push_candidate($pid, $entry); }
        // 3) already verified local LKG sources missing from the current Marketplace
        // remain revalidation candidates and are appended last so the remote cursor
        // remains stable across repeated runs.
        foreach ($existing_by_product as $pid => $item) { $push_candidate($pid, $item); }

        if (!$candidate_order) {
            return array(
                'status'=>'partial','candidate_count'=>0,'batch_count'=>0,'validated'=>0,'approved'=>0,
                'needs_support_url'=>0,'blocked'=>0,'errors'=>0,'cursor_next'=>0,'items'=>array_values($existing_by_product),
                'marketplace_product_count'=>count($market_by_product),
                'message'=>'Kein lesbarer Digistore24-Produktkandidat vorhanden; bestehende Quellen bleiben unverändert.',
            );
        }
        $cursor = absint($store['discovery_cursor'] ?? 0);
        if ($cursor >= count($candidate_order)) { $cursor = 0; }
        $batch_count = min(50, count($candidate_order) - $cursor);
        $batch_ids = array_slice($candidate_order, $cursor, $batch_count);
        $next_cursor = ($cursor + $batch_count) >= count($candidate_order) ? 0 : ($cursor + $batch_count);

        $next_by_product = $existing_by_product;
        $validated = 0; $approved = 0; $blocked = 0; $needs_support = 0; $errors = 0;
        foreach ($batch_ids as $pid) {
            $proof = $this->digistore24_validate_affiliation_product($pid);
            if (is_wp_error($proof)) { $errors++; continue; }
            $validated++;
            $previous = is_array($existing_by_product[$pid] ?? null) ? $existing_by_product[$pid] : array();
            if (empty($proof['approved'])) {
                if ($previous) {
                    $previous['approval_status'] = sanitize_key((string) ($proof['affiliation_status'] ?? 'no_affiliation'));
                    $previous['product_is_active'] = false;
                    $previous['affiliation_checked_at'] = absint($proof['checked_at'] ?? time());
                    $previous['affiliation_affiliate_id'] = (string) ($proof['affiliate_id'] ?? '');
                    $previous['affiliation_key_fingerprint'] = (string) ($proof['key_fingerprint'] ?? '');
                    $previous['affiliation_source'] = 'digistore24_api_validate_affiliate';
                    $next_by_product[$pid] = $previous;
                }
                $blocked++;
                continue;
            }
            $meta = is_array($candidate_meta[$pid] ?? null) ? $candidate_meta[$pid] : array();
            if (isset($market_by_product[$pid]) && is_array($market_by_product[$pid])) {
                $meta = array_merge($meta, $market_by_product[$pid]);
            }
            $marketplace_entry_id = trim((string) ($meta['marketplace_entry_id'] ?? $meta['id'] ?? ''));
            if ($marketplace_entry_id !== '' && !ctype_digit($marketplace_entry_id)) { $marketplace_entry_id = ''; }
            $support_url = (string) ($previous['support_url'] ?? '');
            if (!$this->digistore24_is_https_url($support_url)) { $support_url = (string) ($meta['support_url'] ?? ''); }
            if (!$this->digistore24_is_https_url($support_url) && $marketplace_entry_id !== '' && isset($known_support_by_entry[$marketplace_entry_id])) {
                $support_url = (string) $known_support_by_entry[$marketplace_entry_id];
            }
            if (!$this->digistore24_is_https_url($support_url)) { $support_url = ''; $needs_support++; }
            elseif ($marketplace_entry_id !== '') { $known_support_by_entry[$marketplace_entry_id] = esc_url_raw($support_url); }
            $promolink = $this->digistore24_canonical_promolink($pid, (string) ($proof['affiliate_id'] ?? ''));
            $headline = sanitize_text_field((string) ($meta['headline'] ?? $previous['headline'] ?? ('Digistore24 Produkt ' . $pid)));
            $entry = array_merge($previous, $meta, array(
                'id'=>$pid,
                'marketplace_entry_id'=>$marketplace_entry_id,
                'main_product_id'=>$pid,
                'headline'=>$headline,
                'support_url'=>$support_url,
                'promolink'=>$promolink,
                'source_kind'=>'digistore24_api_approved_affiliation',
                'approval_status'=>'approved',
                'product_is_active'=>true,
                'affiliation_checked_at'=>absint($proof['checked_at'] ?? time()),
                'affiliation_affiliate_id'=>(string) ($proof['affiliate_id'] ?? ''),
                'affiliation_key_fingerprint'=>(string) ($proof['key_fingerprint'] ?? ''),
                'affiliation_source'=>'digistore24_api_validate_affiliate',
            ));
            $next_by_product[$pid] = $entry;
            $approved++;
        }
        $items = array_values($next_by_product);
        usort($items, static function ($a, $b) {
            return strnatcasecmp((string) ($a['headline'] ?? $a['main_product_id'] ?? ''), (string) ($b['headline'] ?? $b['main_product_id'] ?? ''));
        });
        $store['items'] = $items;
        $store['last_checked'] = time();
        $store['last_status'] = $errors > 0 || $blocked > 0 || $needs_support > 0 || $market_error ? 'partial' : 'success';
        $store['last_message'] = $validated . ' von ' . $batch_count . ' Kandidaten via validateAffiliate geprüft; ' . $approved . ' bestätigt; ' . $needs_support . ' benötigen eine Vendor-Werbemittelseite; ' . $blocked . ' nicht bestätigt; ' . $errors . ' API-Fehler.';
        $store['key_fingerprint'] = (string) ($identity['key_fingerprint'] ?? '');
        $store['affiliate_id'] = (string) ($identity['affiliate_id'] ?? '');
        $store['discovery_cursor'] = $next_cursor;
        update_option('ppar_digistore24_marketplace_v1', $store, false);
        return array(
            'status'=>$store['last_status'],'candidate_count'=>count($candidate_order),'batch_count'=>$batch_count,
            'validated'=>$validated,'approved'=>$approved,'needs_support_url'=>$needs_support,
            'blocked'=>$blocked,'errors'=>$errors,'cursor_next'=>$next_cursor,'items'=>$items,
            'marketplace_product_count'=>count($market_by_product),
            'marketplace_error'=>$market_error ? sanitize_key((string) $market_error->get_error_code()) : '',
            'message'=>$store['last_message'],
        );
    }

    private function digistore24_fetch_marketplace_index() {
        $response = $this->digistore24_api_call('listMarketplaceEntries');
        if (is_wp_error($response)) { return $response; }
        $data = is_array($response['data'] ?? null) ? $response['data'] : array();
        if (!isset($data['entries']) || !is_array($data['entries'])) {
            return new WP_Error('digistore24_marketplace_schema_invalid_entries', 'Digistore24-Marktplatzantwort enthält keine gültige entries-Liste.');
        }
        $by_product = array(); $by_entry = array();
        foreach ($data['entries'] as $raw) {
            $entry = $this->digistore24_normalize_marketplace_entry($raw);
            if (is_wp_error($entry)) { continue; }
            $by_entry[(string) $entry['id']] = $entry;
            foreach ((array) ($entry['all_product_ids'] ?? array()) as $product_id) { $by_product[(string) $product_id] = $entry; }
            if ((string) ($entry['main_product_id'] ?? '') !== '') { $by_product[(string) $entry['main_product_id']] = $entry; }
        }
        return array('by_product'=>$by_product,'by_entry'=>$by_entry,'key_fingerprint'=>(string) ($response['key_fingerprint'] ?? ''));
    }

    private function digistore24_entry_has_fresh_affiliation($entry, $max_age = 21600) {
        $entry = is_array($entry) ? $entry : array();
        $identity = $this->digistore24_current_tested_identity();
        $affiliate_id = $this->digistore24_normalize_affiliate_id($identity['affiliate_id'] ?? '');
        $saved_affiliate = $this->digistore24_normalize_affiliate_id($entry['affiliation_affiliate_id'] ?? '');
        $saved_fp = strtolower(trim((string) ($entry['affiliation_key_fingerprint'] ?? '')));
        $identity_ok = $affiliate_id !== '' && $saved_affiliate !== '' && hash_equals($affiliate_id, $saved_affiliate)
            && (string) ($identity['key_fingerprint'] ?? '') !== '' && strlen($saved_fp) === 64
            && hash_equals((string) $identity['key_fingerprint'], $saved_fp);
        if (!$identity_ok
            || strtolower((string) ($entry['approval_status'] ?? '')) !== 'approved'
            || !$this->digistore24_bool($entry['product_is_active'] ?? false)) {
            return false;
        }

        // Explicit bulk/single-source confirmation is the documented fallback
        // when Digistore24 provides no partnership-list API. It remains bound to
        // the exact tested API identity and is invalidated immediately by a
        // credential/Affiliate-ID change. Asset, tracking, target and slot are
        // still revalidated on every publication path.
        $authority = sanitize_key((string) ($entry['affiliation_source'] ?? ''));
        if (in_array($authority, array('admin_confirmed_bulk','admin_confirmed_single','admin_confirmed_legacy'), true)) {
            return absint($entry['affiliation_checked_at'] ?? 0) > 0;
        }

        // API-origin proof, if ever present from an older compatible state, keeps
        // its original freshness boundary.
        $checked_at = absint($entry['affiliation_checked_at'] ?? 0);
        return in_array($authority, array('digistore24_api_approved_affiliation','digistore24_api_validate_affiliate'), true)
            && $checked_at > 0 && $checked_at <= time()
            && (time() - $checked_at) <= max(60, absint($max_age));
    }

    private function digistore24_marketplace_store() {
        $stored = get_option('ppar_digistore24_marketplace_v1', array());
        $stored = is_array($stored) ? $stored : array();
        $stored = array_merge(array(
            'items'=>array(),
            'last_checked'=>0,
            'last_status'=>'never',
            'last_message'=>'',
            'blocked'=>0,
            'key_fingerprint'=>'',
            'affiliate_id'=>'',
            'last_operation_at'=>0,
            'last_operation_status'=>'',
            'last_operation_message'=>'',
            'last_operation_entry_id'=>'',
            'last_operation_final_status'=>'',
            'last_operation_final_message'=>'',
            'automation_cursor'=>0,
            'discovery_cursor'=>0,
        ), $stored);

        // Credential-identity boundary: marketplace cache is account-derived.
        // Never expose an old account's cached entries under a different or
        // currently unverified API key. The stored cache remains recoverable if
        // the exact previously tested credential identity is restored.
        $identity = $this->digistore24_current_tested_identity();
        $stored_fp = strtolower(trim((string) ($stored['key_fingerprint'] ?? '')));
        $stored_affiliate = sanitize_text_field((string) ($stored['affiliate_id'] ?? ''));
        $identity_ok = $stored_fp !== ''
            && strlen($stored_fp) === 64
            && (string) ($identity['key_fingerprint'] ?? '') !== ''
            && hash_equals($stored_fp, (string) $identity['key_fingerprint'])
            && $stored_affiliate !== ''
            && hash_equals($stored_affiliate, (string) ($identity['affiliate_id'] ?? ''));
        if (!$identity_ok && !empty($stored['items'])) {
            $stored['items'] = array();
            $stored['last_status'] = 'credentials_changed';
            $stored['last_message'] = 'Gespeicherte Digistore24-Quellen gehören nicht zum aktuell erfolgreich geprüften Zugang und bleiben ausgeblendet.';
        } elseif ($identity_ok && !empty($stored['items'])) {
            // One-way in-memory migration for sources that were already manually
            // verified before the explicit authority marker existed. The source
            // must still have a real tracking link and an HTTPS Vendor page.
            foreach ($stored['items'] as &$legacy_item) {
                if (!is_array($legacy_item)) { continue; }
                if (sanitize_key((string) ($legacy_item['source_kind'] ?? '')) !== 'digistore24_approved_vendor_source') { continue; }
                if (sanitize_key((string) ($legacy_item['affiliation_source'] ?? '')) !== '') { continue; }
                $pid = trim((string) ($legacy_item['main_product_id'] ?? $legacy_item['id'] ?? ''));
                $support = (string) ($legacy_item['support_url'] ?? '');
                $promo = (string) ($legacy_item['promolink'] ?? '');
                if ($pid === '' || !$this->digistore24_is_https_url($support) || !$this->digistore24_tracking_url_allowed($promo, $pid, $support)) { continue; }
                $legacy_item['approval_status'] = 'approved';
                $legacy_item['product_is_active'] = true;
                $legacy_item['affiliation_checked_at'] = max(1, absint($stored['last_checked'] ?? time()));
                $legacy_item['affiliation_affiliate_id'] = (string) $identity['affiliate_id'];
                $legacy_item['affiliation_key_fingerprint'] = (string) $identity['key_fingerprint'];
                $legacy_item['affiliation_source'] = 'admin_confirmed_legacy';
            }
            unset($legacy_item);
        }
        return $stored;
    }

    private function digistore24_marketplace_item($entry_id) {
        $entry_id = preg_replace('/[^0-9]/', '', (string) $entry_id);
        $store = $this->digistore24_marketplace_store();
        foreach ((array) ($store['items'] ?? array()) as $item) {
            if (is_array($item) && (string) ($item['id'] ?? '') === $entry_id) {
                return $item;
            }
        }
        return array();
    }

    private function digistore24_refresh_marketplace() {
        if (!$this->digistore24_fingerprint_matches()) {
            return new WP_Error('digistore24_key_not_tested', 'Aktueller Digistore24-Schlüssel wurde noch nicht erfolgreich read-only geprüft.');
        }
        $identity_before = $this->digistore24_current_tested_identity();
        $response = $this->digistore24_api_call('listMarketplaceEntries');
        if (is_wp_error($response)) {
            return $response;
        }
        $identity_after = $this->digistore24_current_tested_identity();
        $response_fp = strtolower(trim((string) ($response['key_fingerprint'] ?? '')));
        if ($response_fp === ''
            || !hash_equals((string) ($identity_before['key_fingerprint'] ?? ''), $response_fp)
            || !hash_equals((string) ($identity_after['key_fingerprint'] ?? ''), $response_fp)) {
            return new WP_Error('digistore24_identity_changed_during_request', 'Digistore24-Zugang wurde während des Marketplace-Abrufs geändert; Antwort wird verworfen.');
        }
        $data = is_array($response['data'] ?? null) ? $response['data'] : array();
        // Live fail-closed schema gate. `listMarketplaceEntries` is documented to
        // return data.entries. V6.63.0 silently converted a missing/malformed or
        // empty entries payload into a misleading successful 0/0 marketplace
        // refresh. That makes a transport/API success indistinguishable from a
        // usable marketplace result and can hide a schema/permission problem.
        if (!array_key_exists('entries', $data)) {
            $keys = array_slice(array_values(array_filter(array_map('sanitize_key', array_keys($data)))), 0, 12);
            $suffix = $keys ? ' Vorhandene data-Schlüssel: ' . implode(', ', $keys) . '.' : ' data ist leer.';
            return new WP_Error('digistore24_marketplace_schema_missing_entries', 'Digistore24-Marktplatzantwort enthält kein data.entries-Feld.' . $suffix);
        }
        if (!is_array($data['entries'])) {
            return new WP_Error('digistore24_marketplace_schema_invalid_entries', 'Digistore24-Marktplatzantwort enthält data.entries nicht als Liste. Antwort wird nicht als erfolgreicher Abruf gewertet.');
        }
        $entries = $data['entries'];
        if (!$entries) {
            return new WP_Error('digistore24_marketplace_empty_unverified', 'Digistore24 lieferte data.entries als leere Liste. 0/0 wird fail-closed nicht als Marketplace-PASS gewertet; bestehender Cache und öffentliche Ausgabe bleiben unverändert.');
        }
        $previous_store = $this->digistore24_marketplace_store();
        $previous_urls = array();
        foreach ((array) ($previous_store['items'] ?? array()) as $previous_item) {
            if (is_array($previous_item) && $this->digistore24_is_https_url((string) ($previous_item['support_url'] ?? ''))) {
                $previous_urls[(string) ($previous_item['id'] ?? '')] = (string) $previous_item['support_url'];
            }
        }
        $items = array();
        $blocked = 0;
        foreach ($entries as $entry) {
            $normalized = $this->digistore24_normalize_marketplace_entry($entry);
            if (is_wp_error($normalized)) {
                $blocked++;
                continue;
            }
            if (isset($previous_urls[(string) $normalized['id']])) { $normalized['support_url'] = $previous_urls[(string) $normalized['id']]; }
            $items[] = $normalized;
        }
        usort($items, static function ($a, $b) {
            return strnatcasecmp((string) ($a['headline'] ?? ''), (string) ($b['headline'] ?? ''));
        });
        $identity = $this->digistore24_current_tested_identity();
        if ((string) ($identity['key_fingerprint'] ?? '') === '' || (string) ($identity['affiliate_id'] ?? '') === '') {
            return new WP_Error('digistore24_identity_not_tested', 'Aktueller Digistore24-Zugang besitzt keine erfolgreich geprüfte Identität.');
        }
        $store = array(
            'items' => $items,
            'last_checked' => time(),
            'last_status' => 'success',
            'last_message' => count($items) . ' freigegebene/kompatible Marketplace-Einträge gespeichert; ' . $blocked . ' explizit nicht freigegebene Einträge blockiert.',
            'blocked' => $blocked,
            'key_fingerprint' => (string) $identity['key_fingerprint'],
            'affiliate_id' => (string) $identity['affiliate_id'],
        );
        update_option('ppar_digistore24_marketplace_v1', $store, false);
        return array('status'=>'success','count'=>count($items),'blocked'=>$blocked,'items'=>$items);
    }

    private function digistore24_refresh_marketplace_entry($entry_id) {
        $requested_entry_id = preg_replace('/[^0-9]/', '', (string) $entry_id);
        if ($requested_entry_id === '') {
            return new WP_Error('digistore24_entry_id_missing', 'Marketplace-Entry-ID fehlt.');
        }
        if (!$this->digistore24_fingerprint_matches()) {
            return new WP_Error('digistore24_key_not_tested', 'Aktueller Digistore24-Schlüssel wurde noch nicht erfolgreich read-only geprüft.');
        }
        $identity_before = $this->digistore24_current_tested_identity();
        $response = $this->digistore24_api_call('getMarketplaceEntry', array('entryId'=>$requested_entry_id));
        if (is_wp_error($response)) {
            return $response;
        }
        $identity_after = $this->digistore24_current_tested_identity();
        $response_fp = strtolower(trim((string) ($response['key_fingerprint'] ?? '')));
        if ($response_fp === ''
            || !hash_equals((string) ($identity_before['key_fingerprint'] ?? ''), $response_fp)
            || !hash_equals((string) ($identity_after['key_fingerprint'] ?? ''), $response_fp)) {
            return new WP_Error('digistore24_identity_changed_during_request', 'Digistore24-Zugang wurde während des Marketplace-Detailabrufs geändert; Antwort wird verworfen.');
        }
        $data = is_array($response['data'] ?? null) ? $response['data'] : array();
        // Some API clients/spec variants expose the entry in data.entry; prefer it
        // when present, otherwise the detail data itself is the entry.
        $entry = isset($data['entry']) && is_array($data['entry']) ? array_merge($data, $data['entry']) : $data;
        $normalized = $this->digistore24_normalize_marketplace_entry($entry);
        if (is_wp_error($normalized)) {
            return $normalized;
        }
        if ((string) ($normalized['id'] ?? '') !== $requested_entry_id) {
            return new WP_Error('digistore24_entry_id_mismatch', 'Digistore24-Detailantwort gehört nicht zur angeforderten Marketplace-Entry-ID und wird verworfen.');
        }
        $store = $this->digistore24_marketplace_store();
        $previous = $this->digistore24_marketplace_item($requested_entry_id);
        if ($this->digistore24_is_https_url((string) ($previous['support_url'] ?? ''))) { $normalized['support_url'] = (string) $previous['support_url']; }
        $items = array();
        $replaced = false;
        foreach ((array) ($store['items'] ?? array()) as $item) {
            if (is_array($item) && (string) ($item['id'] ?? '') === (string) $normalized['id']) {
                $items[] = $normalized;
                $replaced = true;
            } elseif (is_array($item)) {
                $items[] = $item;
            }
        }
        if (!$replaced) {
            $items[] = $normalized;
        }
        $identity = $this->digistore24_current_tested_identity();
        if ((string) ($identity['key_fingerprint'] ?? '') === '' || (string) ($identity['affiliate_id'] ?? '') === '') {
            return new WP_Error('digistore24_identity_not_tested', 'Aktueller Digistore24-Zugang besitzt keine erfolgreich geprüfte Identität.');
        }
        $store['items'] = $items;
        $store['last_checked'] = time();
        $store['key_fingerprint'] = (string) $identity['key_fingerprint'];
        $store['affiliate_id'] = (string) $identity['affiliate_id'];
        update_option('ppar_digistore24_marketplace_v1', $store, false);
        return $normalized;
    }

    public function digistore24_automation_scheduled_sources($sources, $registry = array(), $contract_version = '') {
        $sources = is_array($sources) ? $sources : array();
        if (!$this->digistore24_automation_ready()) { return $sources; }
        $sources[] = array(
            'key' => 'digistore24:confirmed-sources',
            'provider' => 'digistore24',
            'partner_external_id' => 'confirmed-sources',
        );
        return $sources;
    }

    public function digistore24_automation_dispatch($handled, $provider, $source, $manual = false, $contract_version = '') {
        if (sanitize_key((string) $provider) !== 'digistore24') {
            return $handled;
        }
        if (!$this->digistore24_automation_ready()) {
            return array(
                'immediate'=>true,
                'provider'=>'digistore24',
                'summary'=>array('status'=>'partial','message'=>'Digistore24 ist nicht aktiviert oder der aktuelle Schlüssel wurde nicht erfolgreich geprüft.'),
            );
        }

        $discovery = $this->digistore24_discover_approved_partnership_sources();
        $discovery_error = is_wp_error($discovery) ? $discovery : null;
        $store = $this->digistore24_marketplace_store();
        $items = array_values(array_filter((array) ($store['items'] ?? array()), 'is_array'));
        $total = count($items);
        if (!$items) {
            $message = $discovery_error
                ? 'Digistore24-Partnerschaftssuche fehlgeschlagen: ' . $discovery_error->get_error_message() . ' Bestehende öffentliche Ausgaben bleiben unverändert.'
                : sanitize_text_field((string) ($discovery['message'] ?? 'Keine bestätigten Digistore24-Partnerschaften gefunden.'));
            return array(
                'immediate'=>true,
                'provider'=>'digistore24',
                'summary'=>array(
                    'status'=>'partial','source_count'=>0,'batch_count'=>0,'automation_processed'=>0,
                    'automation_imported'=>0,'requires_support_url'=>0,'automation_blocked'=>0,
                    'discovery_candidate_count'=>is_array($discovery) ? absint($discovery['candidate_count'] ?? 0) : 0,
                    'discovery_validated'=>is_array($discovery) ? absint($discovery['validated'] ?? 0) : 0,
                    'discovery_approved'=>is_array($discovery) ? absint($discovery['approved'] ?? 0) : 0,
                    'discovery_error'=>$discovery_error ? sanitize_key((string) $discovery_error->get_error_code()) : '',
                    'message'=>$message,
                ),
            );
        }

        // Bounded but starvation-free: up to 50 sources per run, then continue
        // from the persisted cursor on the next central run.
        $cursor = absint($store['automation_cursor'] ?? 0);
        if ($cursor >= $total) { $cursor = 0; }
        $batch_count = min(50, $total - $cursor);
        $batch = array_slice($items, $cursor, $batch_count);
        $next_cursor = ($cursor + $batch_count) >= $total ? 0 : ($cursor + $batch_count);
        $store['automation_cursor'] = $next_cursor;
        update_option('ppar_digistore24_marketplace_v1', $store, false);

        $processed = 0; $imported = 0; $needs_url = 0; $blocked = 0; $operation_sources = array();
        foreach ($batch as $entry) {
            $processed++;
            if (!$this->digistore24_entry_has_fresh_affiliation($entry)) { $blocked++; continue; }
            $product_id = (string) ($entry['main_product_id'] ?? '');
            if ($product_id === '' || !ctype_digit($product_id) || (string) absint($product_id) !== $product_id) { $blocked++; continue; }
            $support_url = (string) ($entry['support_url'] ?? '');
            if (!$this->digistore24_is_https_url($support_url)) { $needs_url++; continue; }
            $promolink = (string) ($entry['promolink'] ?? '');
            if (!$this->digistore24_tracking_url_allowed($promolink, $product_id, $support_url)) { $blocked++; continue; }
            $entry_id = (string) ($entry['id'] ?? $product_id);
            $banner_result = $this->digistore24_import_vendor_banners($entry_id, $support_url, true);
            if (is_wp_error($banner_result)) { $blocked++; continue; }
            $imported += absint($banner_result['imported'] ?? 0);
            $operation_sources[] = array('entry_id'=>$entry_id,'identity_hashes'=>(array) ($banner_result['identity_hashes'] ?? array()));
        }
        if ($operation_sources) { $this->digistore24_operation_context = array('sources'=>$operation_sources); }
        $discovery_partial = $discovery_error || (is_array($discovery) && sanitize_key((string) ($discovery['status'] ?? '')) !== 'success');
        return array('immediate'=>true,'provider'=>'digistore24','summary'=>array(
            'status'=>$blocked > 0 || $needs_url > 0 || $discovery_partial ? 'partial' : 'success',
            'source_count'=>$total,
            'batch_count'=>$batch_count,
            'cursor_next'=>$next_cursor,
            'confirmed_sources'=>$total,
            'discovery_candidate_count'=>is_array($discovery) ? absint($discovery['candidate_count'] ?? 0) : 0,
            'discovery_validated'=>is_array($discovery) ? absint($discovery['validated'] ?? 0) : 0,
            'discovery_approved'=>is_array($discovery) ? absint($discovery['approved'] ?? 0) : 0,
            'discovery_error'=>$discovery_error ? sanitize_key((string) $discovery_error->get_error_code()) : '',
            'automation_processed'=>$processed,
            'automation_imported'=>$imported,
            'requires_support_url'=>$needs_url,
            'automation_blocked'=>$blocked,
            'message'=>($discovery_error ? 'Partnerschaftssuche teilweise fehlgeschlagen; vorhandene gültige Quellen wurden weiter geprüft. ' : '') . $processed . ' von ' . $total . ' bestätigten DS24-Quellen geprüft; ' . $imported . ' Banner importiert; ' . $needs_url . ' benötigen eine Vendor-Werbemittelseite; ' . $blocked . ' blockiert.',
        ));
    }

    private function digistore24_register_approved_source($product_id, $support_url, $promolink, $label = '', $allow_incomplete = false, $authority = 'admin_confirmed_single') {
        $product_id = trim((string) $product_id);
        if ($product_id === '' || !ctype_digit($product_id) || (string) absint($product_id) !== $product_id) {
            return new WP_Error('digistore24_product_id_invalid', 'Digistore24-Produkt-ID muss eine kanonische numerische ID sein.');
        }
        $support_url = esc_url_raw((string) $support_url);
        if ($support_url !== '' && !$this->digistore24_is_https_url($support_url)) {
            return new WP_Error('digistore24_support_url_invalid', 'Vendor-Supportseite muss eine gültige HTTPS-URL sein.');
        }
        if ($support_url === '' && !$allow_incomplete) {
            return new WP_Error('digistore24_support_url_invalid', 'Vendor-Supportseite muss angegeben werden.');
        }
        if (!$this->digistore24_fingerprint_matches()) {
            return new WP_Error('digistore24_key_not_tested', 'Aktueller Digistore24-Schlüssel wurde noch nicht erfolgreich read-only geprüft.');
        }
        $promolink = esc_url_raw((string) $promolink);
        if ($promolink === '') { $promolink = $this->digistore24_canonical_promolink($product_id); }
        if (!$this->digistore24_tracking_url_allowed($promolink, $product_id, $support_url)) {
            return new WP_Error('digistore24_promolink_invalid', 'Der Promolink passt nicht zur Produkt-ID, Vendor-Domain oder aktuell getesteten Digistore24-Affiliate-ID.');
        }
        $identity = $this->digistore24_current_tested_identity();
        if ((string) ($identity['key_fingerprint'] ?? '') === '' || (string) ($identity['affiliate_id'] ?? '') === '') {
            return new WP_Error('digistore24_identity_not_tested', 'Aktueller Digistore24-Zugang besitzt keine erfolgreich geprüfte Identität.');
        }
        $store = $this->digistore24_marketplace_store();
        $items = array();
        $replaced = false;
        $safe_label = sanitize_text_field((string) $label);
        $entry = array(
            'id'=>$product_id,
            'main_product_id'=>$product_id,
            'headline'=>$safe_label !== '' ? $safe_label : 'Digistore24 Produkt ' . $product_id,
            'description'=>'',
            'product_category'=>'',
            'support_url'=>$support_url,
            'promolink'=>$promolink,
            'source_kind'=>'digistore24_approved_vendor_source',
            'approval_status'=>'approved',
            'product_is_active'=>true,
            'affiliation_checked_at'=>time(),
            'affiliation_affiliate_id'=>(string) $identity['affiliate_id'],
            'affiliation_key_fingerprint'=>(string) $identity['key_fingerprint'],
            'affiliation_source'=>in_array(sanitize_key((string) $authority), array('admin_confirmed_bulk','admin_confirmed_single'), true) ? sanitize_key((string) $authority) : 'admin_confirmed_single',
        );
        foreach ((array) ($store['items'] ?? array()) as $item) {
            if (!is_array($item)) { continue; }
            if ((string) ($item['id'] ?? '') === $product_id) {
                $entry = array_merge($item, $entry);
                $items[] = $entry;
                $replaced = true;
            } else {
                $items[] = $item;
            }
        }
        if (!$replaced) { $items[] = $entry; }
        $store['items'] = $items;
        $store['last_checked'] = time();
        $store['last_status'] = 'source_verified';
        $store['last_message'] = 'Bestätigte DS24-Quelle ' . $product_id . ' für den aktuell geprüften Affiliate-Zugang gebunden; Trackinglink geprüft' . ($support_url !== '' ? ' und Vendor-Werbemittelseite hinterlegt.' : '; Vendor-Werbemittelseite noch erforderlich.');
        $store['key_fingerprint'] = (string) $identity['key_fingerprint'];
        $store['affiliate_id'] = (string) $identity['affiliate_id'];
        update_option('ppar_digistore24_marketplace_v1', $store, false);
        return $entry;
    }

    private function digistore24_partnerships() {
        $stored = get_option('ppar_digistore24_partnerships_v1', array());
        return is_array($stored) ? $stored : array();
    }

    private function digistore24_partnership_confirmed($entry_id) {
        $entry_id = preg_replace('/[^0-9]/', '', (string) $entry_id);
        $items = $this->digistore24_partnerships();
        $record = $entry_id !== '' && isset($items[$entry_id]) && is_array($items[$entry_id]) ? $items[$entry_id] : array();
        if (empty($record['confirmed'])) {
            return false;
        }
        $identity = $this->digistore24_current_tested_identity();
        $saved_fp = strtolower(trim((string) ($record['key_fingerprint'] ?? '')));
        $saved_affiliate = sanitize_text_field((string) ($record['affiliate_id'] ?? ''));
        $identity_ok = $saved_fp !== ''
            && strlen($saved_fp) === 64
            && (string) ($identity['key_fingerprint'] ?? '') !== ''
            && hash_equals($saved_fp, (string) $identity['key_fingerprint'])
            && $saved_affiliate !== ''
            && hash_equals($saved_affiliate, (string) ($identity['affiliate_id'] ?? ''));
        if (!$identity_ok) {
            return false;
        }
        // Partnership is meaningful only for an entry still present in the
        // current identity-bound marketplace cache. A removed/revoked/unknown
        // entry must not retain import authority from an old confirmation.
        return !empty($this->digistore24_marketplace_item($entry_id));
    }

    private function digistore24_set_partnership($entry_id, $confirmed) {
        $entry_id = preg_replace('/[^0-9]/', '', (string) $entry_id);
        if ($entry_id === '') {
            return new WP_Error('digistore24_entry_id_missing', 'Marketplace-Entry-ID fehlt.');
        }
        $items = $this->digistore24_partnerships();
        if ($confirmed) {
            $identity = $this->digistore24_current_tested_identity();
            if ((string) ($identity['key_fingerprint'] ?? '') === '' || (string) ($identity['affiliate_id'] ?? '') === '') {
                return new WP_Error('digistore24_partnership_identity_required', 'Partnerschaftsbestätigung erfordert den aktuell erfolgreich geprüften Digistore24-Zugang.');
            }
            if (empty($this->digistore24_marketplace_item($entry_id))) {
                return new WP_Error('digistore24_marketplace_entry_required', 'Partnerschaft kann nur für einen aktuell im geprüften Digistore24-Marktplatz vorhandenen Eintrag bestätigt werden.');
            }
            $items[$entry_id] = array(
                'confirmed'=>1,
                'confirmed_at'=>time(),
                'key_fingerprint'=>(string) $identity['key_fingerprint'],
                'affiliate_id'=>(string) $identity['affiliate_id'],
            );
        } else {
            unset($items[$entry_id]);
        }
        update_option('ppar_digistore24_partnerships_v1', $items, false);
        return true;
    }

    private function digistore24_is_https_url($url) {
        $url = esc_url_raw((string) $url);
        return $url !== '' && wp_http_validate_url($url) && strtolower((string) wp_parse_url($url, PHP_URL_SCHEME)) === 'https';
    }

    private function digistore24_tracking_url_allowed($url, $expected_product_id = '', $expected_vendor_url = '') {
        $url = esc_url_raw(html_entity_decode((string) $url, ENT_QUOTES, 'UTF-8'));
        if (!$this->digistore24_is_https_url($url)) {
            return false;
        }
        $settings = $this->digistore24_settings();
        $affiliate_id = $this->digistore24_normalize_affiliate_id($settings['affiliate_id'] ?? '');
        if ($affiliate_id === '' || !$this->digistore24_fingerprint_matches($settings)) {
            return false;
        }
        $expected_product_id = trim((string) $expected_product_id);
        if ($expected_product_id !== '' && (!ctype_digit($expected_product_id) || (string) absint($expected_product_id) !== $expected_product_id)) {
            return false;
        }
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        $port = wp_parse_url($url, PHP_URL_PORT);
        if ($port !== null && absint($port) !== 443) {
            return false;
        }

        // Official Digistore24 promolink. Product and Affiliate-ID are both
        // encoded in deterministic path positions and are verified exactly.
        if (in_array($host, array('checkout-ds24.com','www.checkout-ds24.com'), true)) {
            $query = (string) wp_parse_url($url, PHP_URL_QUERY);
            if ($query !== '') {
                $query_args = array();
                parse_str(html_entity_decode($query, ENT_QUOTES, 'UTF-8'), $query_args);
                foreach (array_keys($query_args) as $query_key) {
                    if (strtolower((string) $query_key) === 'aff') { return false; }
                }
            }
            $path = trim((string) wp_parse_url($url, PHP_URL_PATH), '/');
            $segments = array_values(array_filter(array_map('rawurldecode', explode('/', $path)), 'strlen'));
            $first = strtolower((string) ($segments[0] ?? ''));
            if ($first === 'redir') {
                $product_id = (string) ($segments[1] ?? '');
                $path_affiliate = (string) ($segments[2] ?? '');
                return count($segments) >= 3 && count($segments) <= 4
                    && $product_id !== '' && ctype_digit($product_id)
                    && ($expected_product_id === '' || hash_equals($expected_product_id, $product_id))
                    && $path_affiliate !== '' && hash_equals($affiliate_id, $path_affiliate);
            }
            if ($first === 'content') {
                $product_id = (string) ($segments[1] ?? '');
                $content_id = (string) ($segments[2] ?? '');
                $path_affiliate = (string) ($segments[3] ?? '');
                return count($segments) >= 4 && count($segments) <= 5
                    && $product_id !== '' && ctype_digit($product_id)
                    && ($expected_product_id === '' || hash_equals($expected_product_id, $product_id))
                    && $content_id !== '' && ctype_digit($content_id)
                    && $path_affiliate !== '' && hash_equals($affiliate_id, $path_affiliate);
            }
            return false;
        }

        // Digistore24 also officially supports vendor-domain promocode links in
        // the form https://vendor.example/path/#aff=AFFILIATE[&cam=...]. For a
        // stored source this is accepted only on the same Vendor domain as the
        // explicitly supplied HTTPS support/creative page.
        if ($expected_vendor_url === '' || !$this->digistore24_is_https_url($expected_vendor_url)) {
            return false;
        }
        $vendor_host = strtolower((string) wp_parse_url($expected_vendor_url, PHP_URL_HOST));
        $normal_host = static function ($value) { return preg_replace('/^www\./i', '', strtolower((string) $value)); };
        if ($normal_host($host) === '' || !hash_equals($normal_host($vendor_host), $normal_host($host))) {
            return false;
        }
        $fragment = (string) wp_parse_url($url, PHP_URL_FRAGMENT);
        if ($fragment === '') { return false; }
        $fragment_args = array();
        parse_str($fragment, $fragment_args);
        $fragment_affiliate = sanitize_text_field((string) ($fragment_args['aff'] ?? ''));
        return $fragment_affiliate !== '' && hash_equals($affiliate_id, $fragment_affiliate);
    }

    private function digistore24_partner_link_fallback($entry) {
        $entry = is_array($entry) ? $entry : array();
        $product_id = trim((string) ($entry['main_product_id'] ?? ''));
        $support_url = (string) ($entry['support_url'] ?? '');
        $promolink = (string) ($entry['promolink'] ?? '');
        return $this->digistore24_tracking_url_allowed($promolink, $product_id, $support_url) ? esc_url_raw($promolink) : '';
    }

    private function digistore24_resolve_url($base_url, $candidate) {
        $candidate = trim(html_entity_decode((string) $candidate, ENT_QUOTES, 'UTF-8'));
        if ($candidate === '') {
            return '';
        }
        if (preg_match('#^https?://#i', $candidate)) {
            return esc_url_raw($candidate);
        }
        if (strpos($candidate, '//') === 0) {
            return esc_url_raw('https:' . $candidate);
        }
        $base = wp_parse_url($base_url);
        if (!is_array($base) || empty($base['host'])) {
            return '';
        }
        $scheme = strtolower((string) ($base['scheme'] ?? 'https'));
        $origin = $scheme . '://' . (string) $base['host'];
        if (!empty($base['port'])) {
            $origin .= ':' . absint($base['port']);
        }
        if (strpos($candidate, '/') === 0) {
            return esc_url_raw($origin . $candidate);
        }
        $path = (string) ($base['path'] ?? '/');
        $dir = preg_replace('#/[^/]*$#', '/', $path);
        return esc_url_raw($origin . $dir . $candidate);
    }

    private function digistore24_parse_vendor_banners($html, $support_url, $entry) {
        $html = (string) $html;
        $entry = is_array($entry) ? $entry : array();
        $fallback = $this->digistore24_partner_link_fallback($entry);
        $banners = array();
        $seen = array();
        if ($html === '' || $fallback === ''
            || !$this->digistore24_tracking_url_allowed($fallback, (string) ($entry['main_product_id'] ?? ''), $support_url)) {
            return $banners;
        }

        $positive_self = '/(?:werbebanner|werbemittel|banner)/iu';
        $positive_label = '/(?:werbebanner|werbemittel|banner)[^\\r\\n<>]{0,140}\\.(?:png|jpe?g|gif|webp)/iu';
        $negative = '/(?:\\bwerde\\b.{0,48}\\baffiliate\\b|\\baffiliate\\b.{0,48}\\bwerden\\b|\\bpartner(?:schaft)?\\b.{0,48}\\bwerden\\b)/iu';

        $resolve_img_src = function ($attrs) use ($support_url) {
            $attrs = (string) $attrs;
            foreach (array('data-lazy-src','data-src','data-original') as $src_attr) {
                if (preg_match('#\\b' . preg_quote($src_attr, '#') . '\\s*=\\s*(["\\\'])(.*?)\\1#is', $attrs, $m)) {
                    $candidate = $this->digistore24_resolve_url($support_url, $m[2]);
                    if ($this->digistore24_is_https_url($candidate)) { return $candidate; }
                }
            }
            if (preg_match('#\\bsrcset\\s*=\\s*(["\\\'])(.*?)\\1#is', $attrs, $m)) {
                $srcset = array_values(array_filter(array_map('trim', explode(',', (string) $m[2]))));
                $best = ''; $best_score = -1;
                foreach ($srcset as $srcset_item) {
                    $parts = preg_split('/\\s+/', trim($srcset_item));
                    $candidate_url = (string) ($parts[0] ?? '');
                    $descriptor = strtolower((string) ($parts[1] ?? ''));
                    $score = is_numeric(rtrim($descriptor, 'wx')) ? (float) rtrim($descriptor, 'wx') : 0;
                    $candidate = $this->digistore24_resolve_url($support_url, $candidate_url);
                    if ($this->digistore24_is_https_url($candidate) && $score >= $best_score) { $best = $candidate; $best_score = $score; }
                }
                if ($best !== '') { return $best; }
            }
            if (preg_match('#\\bsrc\\s*=\\s*(["\\\'])(.*?)\\1#is', $attrs, $m)) {
                $candidate = $this->digistore24_resolve_url($support_url, $m[2]);
                if ($this->digistore24_is_https_url($candidate)) { return $candidate; }
            }
            return '';
        };

        $add_banner = function ($src, $alt, $tracking_url, $evidence_text = '') use (&$banners, &$seen) {
            $key = hash('sha256', (string) $src . '|' . (string) $tracking_url);
            if (isset($seen[$key])) { return; }
            $seen[$key] = true;
            $banners[] = array(
                'tracking_url'=>esc_url_raw((string) $tracking_url),
                'image_url'=>esc_url_raw((string) $src),
                'alt_text'=>sanitize_text_field((string) $alt),
                // Preserve only image-local evidence. This is intentionally not
                // arbitrary page text: output classification may use it as the
                // concrete creative proof required by the central safety model.
                'evidence_text'=>sanitize_text_field((string) $evidence_text),
            );
        };

        // Token-based local-context parser. It deliberately never scans an
        // arbitrary raw byte window across page columns. This works without
        // ext-dom (which is not guaranteed on WordPress hosts) and pairs an
        // image only with its recent visible banner filename/label.
        $tokens = preg_split('#(<[^>]+>)#is', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        $context = '';
        $protected_depth = 0;
        $current_tracking = '';
        foreach ((array) $tokens as $token) {
            if ($token === '') { continue; }
            if ($token[0] !== '<') {
                $text = trim(preg_replace('/\\s+/u', ' ', wp_strip_all_tags(html_entity_decode((string) $token, ENT_QUOTES, 'UTF-8'))));
                if ($text !== '') {
                    $context = trim($context . ' ' . $text);
                    if (strlen($context) > 520) { $context = substr($context, -520); }
                }
                continue;
            }

            if (preg_match('#^</\\s*(aside|nav|header|footer)\\b#i', $token)) {
                $protected_depth = max(0, $protected_depth - 1);
                $context = '';
                $current_tracking = '';
                continue;
            }
            if (preg_match('#^<\\s*(aside|nav|header|footer)\\b#i', $token)) {
                $protected_depth++;
                $context = '';
                $current_tracking = '';
                continue;
            }
            if (preg_match('#^<\\s*hr\\b#i', $token)) {
                $context = '';
                $current_tracking = '';
                continue;
            }
            if (preg_match('#^</\\s*a\\b#i', $token)) {
                $current_tracking = '';
                continue;
            }
            if (preg_match('#^<\\s*a\\b([^>]*)>#is', $token, $a_match)) {
                $current_tracking = '';
                if (preg_match('#\\bhref\\s*=\\s*(["\\\'])(.*?)\\1#is', (string) ($a_match[1] ?? ''), $href_match)) {
                    $href = $this->digistore24_resolve_url($support_url, $href_match[2]);
                    if ($this->digistore24_tracking_url_allowed($href, (string) ($entry['main_product_id'] ?? ''), $support_url)) {
                        $current_tracking = $href;
                    }
                }
                continue;
            }
            if (!preg_match('#^<\\s*img\\b([^>]*)>#is', $token, $img_match)) { continue; }

            $attrs = (string) ($img_match[1] ?? '');
            $src = $resolve_img_src($attrs);
            if (!$this->digistore24_is_https_url($src)) { continue; }
            $alt = ''; $title = '';
            if (preg_match('#\\balt\\s*=\\s*(["\\\'])(.*?)\\1#is', $attrs, $m)) { $alt = sanitize_text_field(wp_strip_all_tags(html_entity_decode((string) $m[2], ENT_QUOTES, 'UTF-8'))); }
            if (preg_match('#\\btitle\\s*=\\s*(["\\\'])(.*?)\\1#is', $attrs, $m)) { $title = sanitize_text_field(wp_strip_all_tags(html_entity_decode((string) $m[2], ENT_QUOTES, 'UTF-8'))); }
            $basename = basename((string) wp_parse_url($src, PHP_URL_PATH));
            $self_text = html_entity_decode(trim($alt . ' ' . $title . ' ' . $basename), ENT_QUOTES, 'UTF-8');
            if (preg_match($negative, $self_text) || preg_match($negative, $context)) { continue; }

            // In sidebars/navigation, require the image itself to say Banner;
            // a banner label elsewhere on the page can never authorize it.
            $self_positive = preg_match($positive_self, $self_text) === 1;
            if ($protected_depth > 0 && !$self_positive) { continue; }
            $label_positive = preg_match($positive_label, $context) === 1;
            if (!$self_positive && !$label_positive) { continue; }

            $tracking_url = $current_tracking !== '' ? $current_tracking : $fallback;
            if (!$this->digistore24_tracking_url_allowed($tracking_url, (string) ($entry['main_product_id'] ?? ''), $support_url)) { continue; }
            // Alt/title are often empty on vendor pages, while the explicit
            // banner filename carries the decisive topic signal (for example
            // Pferdetraining). Keep that image-local evidence instead of
            // discarding it and forcing the central classifier into review.
            $creative_evidence = trim(implode(' ', array_filter(array($alt, $title, rawurldecode($basename)))));
            $add_banner($src, $alt !== '' ? $alt : $title, $tracking_url, $creative_evidence);
        }
        return $banners;
    }

    private function digistore24_reconcile_vendor_banners($entry_id, $seen_identity_hashes) {
        $entry_id = preg_replace('/[^0-9]/', '', (string) $entry_id);
        $seen_identity_hashes = array_fill_keys(array_values(array_filter(array_map('sanitize_text_field', (array) $seen_identity_hashes))), true);
        if ($entry_id === '' || !$seen_identity_hashes) { return; }
        global $wpdb;
        $table = $this->creative_library_table();
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, identity_hash FROM {$table} WHERE provider=%s AND partner_external_id=%s AND source_kind=%s AND availability_state<>'inactive_missing'",
            'digistore24', 'entry-' . $entry_id, 'digistore24_vendor_banner'
        ), ARRAY_A);
        foreach ((array) $rows as $row) {
            $identity_hash = sanitize_text_field((string) ($row['identity_hash'] ?? ''));
            if ($identity_hash !== '' && isset($seen_identity_hashes[$identity_hash])) { continue; }
            $wpdb->update($table, array(
                'availability_state'=>'inactive_missing',
                'missing_count'=>2,
                'selected'=>0,
            ), array('id'=>absint($row['id'] ?? 0)));
        }
    }

    /**
     * Converge the exact freshly imported DS24 source through the existing
     * central pipeline in the same admin action: real image verification ->
     * portal classification -> slot gate -> inactive draft materialization.
     * This is orchestration only; every safety/target/output decision remains
     * inside the shared provider-neutral core. The immediate request converges a
     * bounded first batch; every imported remainder stays active for the central
     * re-entrant reassignment pass instead of being discarded.
     */
    private function digistore24_converge_imported_banners($entry_id, $identity_hashes) {
        $entry_id = preg_replace('/[^0-9]/', '', (string) $entry_id);
        $identity_hashes = array_slice(array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) $identity_hashes)))), 0, 20);
        $summary = array('processed'=>0,'verified'=>0,'planned'=>0,'drafts'=>0,'active'=>0,'review'=>0,'blocked'=>0,'errors'=>array());
        if ($entry_id === '' || !$identity_hashes) { return $summary; }
        global $wpdb;
        $table = $this->creative_library_table();
        foreach ($identity_hashes as $identity_hash) {
            if (!preg_match('/^[a-f0-9]{64}$/', strtolower($identity_hash))) {
                $summary['blocked']++;
                $summary['errors']['digistore24_identity_invalid'] = 'Importiertes Digistore24-Werbemittel besitzt keine gültige Identität.';
                continue;
            }
            $row = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$table} WHERE identity_hash=%s AND provider=%s AND partner_external_id=%s AND source_kind=%s AND source_status='active' AND availability_state='active' LIMIT 1",
                strtolower($identity_hash), 'digistore24', 'entry-' . $entry_id, 'digistore24_vendor_banner'
            ), ARRAY_A);
            if (!is_array($row)) {
                $summary['blocked']++;
                $summary['errors']['digistore24_imported_row_missing'] = 'Importiertes Digistore24-Werbemittel ist nach dem Speichern nicht mehr aktiv verfügbar.';
                continue;
            }
            $summary['processed']++;
            if (!method_exists($this, 'creative_library_ensure_asset_verified')) {
                $summary['blocked']++;
                $summary['errors']['digistore24_asset_verifier_missing'] = 'Zentrale Bildprüfung fehlt.';
                continue;
            }
            $verified = $this->creative_library_ensure_asset_verified($row, false);
            if (is_wp_error($verified)) {
                $summary['blocked']++;
                $summary['errors'][sanitize_key((string) $verified->get_error_code())] = $verified->get_error_message();
                continue;
            }
            $summary['verified']++;
            if (!method_exists($this, 'output_plan_creative')) {
                $summary['blocked']++;
                $summary['errors']['digistore24_output_model_missing'] = 'Zentrales Ausgabeobjekt-Modell fehlt.';
                continue;
            }
            $planned = $this->output_plan_creative($verified, true);
            if (is_wp_error($planned)) {
                $summary['blocked']++;
                $summary['errors'][sanitize_key((string) $planned->get_error_code())] = $planned->get_error_message();
                continue;
            }
            $summary['planned'] += absint($planned['created'] ?? 0);
            $summary['drafts'] += absint($planned['drafts'] ?? 0);
            $summary['active'] += absint($planned['active'] ?? 0);
            $summary['review'] += absint($planned['review'] ?? 0);
            $summary['blocked'] += absint($planned['blocked'] ?? 0);
            foreach ((array) ($planned['errors'] ?? array()) as $code => $message) {
                $summary['errors'][sanitize_key((string) $code)] = sanitize_text_field((string) $message);
            }
        }
        return $summary;
    }

    private function digistore24_store_support_url($entry_id, $support_url) {
        if (!$this->digistore24_is_https_url($support_url)) { return new WP_Error('digistore24_support_url_invalid', 'Vendor-Supportseite muss eine gültige HTTPS-URL sein.'); }
        $store = $this->digistore24_marketplace_store(); $found = false;
        foreach ((array) ($store['items'] ?? array()) as &$item) {
            if (is_array($item) && (string) ($item['id'] ?? '') === (string) $entry_id) { $item['support_url'] = esc_url_raw($support_url); $found = true; break; }
        }
        unset($item);
        if (!$found) { return new WP_Error('digistore24_marketplace_entry_required', 'Vendor-URL gehört zu keinem aktuellen Marketplace-Eintrag.'); }
        update_option('ppar_digistore24_marketplace_v1', $store, false); return true;
    }

    /**
     * The approved DS24 source label belongs to the exact product/source the
     * admin has bound with product ID + real promolink + HTTPS vendor page.
     * It may contribute topic evidence only when it itself contains an explicit
     * horse-domain signal. Generic partner labels never unlock automation.
     * English equestrian terms are normalized to the existing German portal
     * vocabulary so the provider-neutral target classifier can match the real
     * Pferde-Atelier taxonomy without a DS24-specific target hardcode.
     */
    private function digistore24_approved_source_subject_evidence($entry) {
        $entry = is_array($entry) ? $entry : array();
        if (!in_array(sanitize_key((string) ($entry['source_kind'] ?? '')), array('digistore24_approved_vendor_source','digistore24_api_approved_affiliation'), true)) {
            return '';
        }
        $headline = sanitize_text_field((string) ($entry['headline'] ?? ''));
        if ($headline === '') { return ''; }
        $normalized = remove_accents(strtolower(wp_strip_all_tags($headline)));
        $normalized = trim((string) preg_replace('/[^a-z0-9]+/', ' ', $normalized));
        $has_horse_signal = preg_match('/\b(?:pferd[a-z0-9]*|pony[a-z0-9]*|fohlen[a-z0-9]*|reitsport[a-z0-9]*|reiter[a-z0-9]*|horsemanship|equestrian|equine)\b/', $normalized) === 1;
        if (!$has_horse_signal) { return ''; }
        $canonical = array($headline);
        if (preg_match('/\bhorsemanship\b/', $normalized)) {
            $canonical[] = 'pferd training reitsport';
        } elseif (preg_match('/\bequestrian\b/', $normalized)) {
            $canonical[] = 'pferd reitsport';
        } elseif (preg_match('/\bequine\b/', $normalized)) {
            $canonical[] = 'pferd';
        }
        return sanitize_text_field(trim(implode(' ', array_unique(array_filter($canonical)))));
    }

    private function digistore24_import_vendor_banners($entry_id, $support_url, $automatic = false) {
        $entry_id = preg_replace('/[^0-9]/', '', (string) $entry_id);
        if ($entry_id === '') { return new WP_Error('digistore24_source_required', 'Freigegebene Digistore24-Bannerquelle fehlt.'); }

        $cached_entry = $this->digistore24_marketplace_item($entry_id);
        if (!$cached_entry) {
            return new WP_Error('digistore24_source_required', 'Freigegebene Digistore24-Bannerquelle fehlt.');
        }
        if (!$this->digistore24_entry_has_fresh_affiliation($cached_entry)) {
            return new WP_Error('digistore24_affiliation_not_fresh', 'Digistore24-Partnerschaft ist nicht frisch als approved+active für die aktuell geprüfte Affiliate-ID belegt.');
        }
        $product_id = (string) ($cached_entry['main_product_id'] ?? '');
        $promolink = (string) ($cached_entry['promolink'] ?? '');
        if (!$this->digistore24_tracking_url_allowed($promolink, $product_id, $support_url)) {
            return new WP_Error('digistore24_promolink_invalid', 'Gespeicherter Digistore24-Promolink passt nicht mehr zur Produkt-ID, Vendor-Domain oder aktuell getesteten Affiliate-ID.');
        }
        if (!$this->digistore24_is_https_url($support_url)) {
            return new WP_Error('digistore24_support_url_invalid', 'Vendor-Supportseite muss eine gültige HTTPS-URL sein.');
        }
        $stored_url = $this->digistore24_store_support_url($entry_id, $support_url);
        if (is_wp_error($stored_url)) { return $stored_url; }
        $entry = $this->digistore24_marketplace_item($entry_id);
        if (!$entry || !$this->digistore24_entry_has_fresh_affiliation($entry)) {
            return new WP_Error('digistore24_affiliation_not_fresh', 'Freigegebene Digistore24-Bannerquelle ist nach dem Speichern nicht mehr frisch als approved+active belegt.');
        }
        $response = wp_safe_remote_get(esc_url_raw($support_url), array(
            'timeout'=>20,
            // No implicit redirects: every fetched support page must itself be
            // the explicitly validated HTTPS URL. A real vendor redirect can be
            // supplied as its final HTTPS destination during the live gate.
            'redirection'=>0,
            'limit_response_size'=>2 * 1024 * 1024,
            'headers'=>array('Accept'=>'text/html,application/xhtml+xml'),
        ));
        if (is_wp_error($response)) {
            return new WP_Error('digistore24_support_fetch_failed', 'Vendor-Supportseite konnte nicht sicher geladen werden: ' . $response->get_error_message());
        }
        $code = absint(wp_remote_retrieve_response_code($response));
        if ($code < 200 || $code >= 300) {
            return new WP_Error('digistore24_support_http_status', 'Vendor-Supportseite antwortete mit HTTP ' . $code . '.');
        }
        $banners = $this->digistore24_parse_vendor_banners((string) wp_remote_retrieve_body($response), $support_url, $entry);
        // Import every real banner found on the explicitly bound Vendor page.
        // Processing remains bounded later: the first batch converges now and
        // any remainder is picked up by the existing central reassignment pass.
        $banners = array_values((array) $banners);
        if (!$banners) {
            return new WP_Error('digistore24_no_valid_banners', 'Keine zulässigen Digistore24-Vendor-Banner mit gültigem Trackinglink gefunden.');
        }
        $imported = 0;
        $blocked = 0;
        $seen_identity_hashes = array();
        foreach ($banners as $index => $banner) {
            $row = array(
                'external_id' => 'ds24-' . $entry_id . '-' . substr(hash('sha256', (string) $banner['image_url'] . '|' . (string) $banner['tracking_url']), 0, 24),
                'creative_type' => 'banner',
                'title' => (string) ($banner['alt_text'] ?? '') !== '' ? (string) $banner['alt_text'] : (string) ($entry['headline'] ?? 'Digistore24 Banner'),
                'description' => (string) ($entry['description'] ?? ''),
                // Feed the central provider-neutral classifier with evidence
                // that belongs to this exact banner. Provider/category metadata
                // is additive but can never replace concrete creative evidence.
                'tags' => trim(implode(' ', array_filter(array(
                    (string) ($entry['product_category'] ?? ''),
                    (string) ($banner['evidence_text'] ?? ''),
                    // Source-subject evidence is allowed only after the source
                    // itself passed product-ID/promolink/vendor-page binding and
                    // only if the approved source label carries an explicit
                    // horse-domain signal. Generic partner names remain inert.
                    $this->digistore24_approved_source_subject_evidence($entry),
                )))),
                'image_url' => (string) $banner['image_url'],
                'destination_url' => (string) $banner['tracking_url'],
                'tracking_url' => (string) $banner['tracking_url'],
                'status' => 'active',
                'alt_text' => (string) ($banner['alt_text'] ?? ''),
            );
            $mapping = $this->creative_library_detect_mapping(array_keys($row));
            $normalized = $this->creative_library_normalize_row($row, $mapping, array(
                'provider'=>'digistore24',
                'partner_external_id'=>'entry-' . $entry_id,
                'partner_name'=>'Digistore24 · ' . ((string) ($entry['headline'] ?? '') !== '' ? (string) $entry['headline'] : 'Marketplace ' . $entry_id),
                'source_kind'=>'digistore24_vendor_banner',
                'run_uuid'=>'',
            ));
            if (is_wp_error($normalized)) {
                $blocked++;
                continue;
            }
            if (sanitize_key((string) ($normalized['creative_type'] ?? '')) !== 'banner') {
                $blocked++;
                continue;
            }
            $status = $this->creative_library_upsert($normalized);
            if ($status === 'blocked') {
                $blocked++;
                continue;
            }
            $imported++;
            $seen_identity_hashes[] = sanitize_text_field((string) ($normalized['identity_hash'] ?? ''));
        }
        $convergence = array('processed'=>0,'verified'=>0,'planned'=>0,'drafts'=>0,'active'=>0,'review'=>0,'blocked'=>0,'errors'=>array());
        if ($imported > 0) {
            $this->digistore24_reconcile_vendor_banners($entry_id, $seen_identity_hashes);
            // Converge a bounded first batch immediately through the existing
            // central gates. Imported remainder stays active and is reconsidered
            // by the regular provider-independent reassignment cycle.
            $convergence = $this->digistore24_converge_imported_banners($entry_id, $seen_identity_hashes);
        }
        return array(
            'status'=>'success','imported'=>$imported,'blocked'=>$blocked,'found'=>count($banners),
            'identity_hashes'=>array_values(array_unique(array_filter($seen_identity_hashes))),
            'convergence'=>$convergence,
        );
    }

    public function digistore24_render_access_card($provider = '', $definition = array(), $contract_version = '') {
        $settings = $this->digistore24_settings();
        $has_constant = defined('PPAR_DIGISTORE24_API_KEY') && trim((string) PPAR_DIGISTORE24_API_KEY) !== '';
        ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="ppar_provider_access_save">
            <input type="hidden" name="provider" value="digistore24">
            <?php wp_nonce_field('ppar_provider_access_digistore24','ppar_provider_nonce'); ?>
            <p><label><input type="checkbox" name="ppar_provider[digistore24][enabled]" value="1" <?php checked(!empty($settings['enabled']) && $this->digistore24_fingerprint_matches($settings)); ?>> Verbindung verwenden</label></p>
            <p><label>Read-only API-Schlüssel <span class="ppar-saved"><?php echo esc_html($has_constant ? 'über wp-config.php' : (trim((string)($settings['api_key'] ?? '')) !== '' ? 'gespeichert' : 'nicht gespeichert')); ?></span><br><input type="password" autocomplete="new-password" name="ppar_provider[digistore24][api_key]" value="" placeholder="<?php echo esc_attr($has_constant ? 'über wp-config.php gesetzt' : 'leer lassen zum Beibehalten'); ?>"></label></p>
            <?php if (!$has_constant) : ?><details><summary>Zugangsdaten entfernen</summary><p><label><input type="checkbox" name="ppar_provider[digistore24][remove_api_key]" value="1"> API-Schlüssel entfernen</label></p></details><?php endif; ?>
            <p class="description">Read-only API: eigene Affiliate-Identität via getUserInfo. Die automatische Partnerschaftssynchronisation nutzt ausdrücklich freigegebene Marketplace-Einträge nur als Kandidaten und bestätigt jede Produkt-ID anschließend separat mit validateAffiliate. Bereits bestätigte Quellen bleiben als Last-Known-Good erhalten.</p>
            <div class="ppar-v240-actions"><button class="button button-primary" name="ppar_provider_action" value="save">Speichern</button><button class="button" name="ppar_provider_action" value="save_test">Speichern &amp; API prüfen</button></div>
        </form>
        <?php
    }

    public function digistore24_render_specialist($provider = '', $definition = array(), $contract_version = '') {
        $settings = $this->digistore24_settings();
        $store = $this->digistore24_marketplace_store();
        $items = (array) ($store['items'] ?? array());
        $operation_status = sanitize_key((string) ($store['last_operation_status'] ?? ''));
        $operation_message = sanitize_text_field((string) ($store['last_operation_message'] ?? ''));
        $final_status = sanitize_key((string) ($store['last_operation_final_status'] ?? ''));
        $final_message = sanitize_text_field((string) ($store['last_operation_final_message'] ?? ''));
        $show_operation = sanitize_key((string) ($_GET['ppar_provider_saved'] ?? '')) === 'digistore24'
            || isset($_GET['ppar_provider_error']);
        ?>
        <?php if ($show_operation && $operation_message !== '') : ?>
            <div class="notice <?php echo $operation_status === 'failed' ? 'notice-error' : 'notice-info'; ?> inline"><p><strong>Digistore24-Lauf:</strong> <?php echo esc_html($operation_message); ?></p></div>
        <?php endif; ?>
        <?php if ($show_operation && $final_message !== '') : ?>
            <div class="notice <?php echo in_array($final_status, array('review','failed','quarantine','incomplete'), true) ? 'notice-warning' : 'notice-info'; ?> inline"><p><strong>Schlussprüfung:</strong> <?php echo esc_html($final_message); ?></p></div>
        <?php endif; ?>
        <section class="postbox" style="padding:18px;margin-top:18px">
            <h2>Bestätigte Digistore24-Partnerschaften</h2>
            <p>Die Affiliate-Zentrale liest die von Digistore24 ausdrücklich als <strong>approved</strong> gemeldeten Marketplace-Einträge ein und prüft danach <strong>jede enthaltene Produkt-ID</strong> read-only mit <code>validateAffiliate</code> für die aktuell getestete eigene Affiliate-ID. Produktname, Vendorname oder Themenwörter dürfen vorher keine bestätigte Partnerschaft herausfiltern. Erst der erfolgreiche Einzel-Nachweis erzeugt eine Quelle; Bannerimport, Zuordnung und regelmäßiger Recheck laufen anschließend zentral weiter.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="ppar_digistore24_bulk_refresh">
                <?php wp_nonce_field('ppar_digistore24_bulk_refresh','ppar_digistore24_nonce'); ?>
                <p><button class="button button-primary" type="submit" <?php disabled(!$this->digistore24_fingerprint_matches($settings)); ?>>Alle bestätigten Partnerschaften synchronisieren</button></p>
                <p class="description">Pro Lauf werden bis zu 50 von Digistore24 als approved gemeldete Produktkandidaten einzeln nachgeprüft; weitere folgen über den gespeicherten Cursor. Fehlende Werbemittelseiten oder Fehler einzelner Partner stoppen die übrigen nicht.</p>
            </form>
            <details style="margin-top:12px"><summary><strong>Manuelle Sammelübernahme (Fallback)</strong></summary>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-top:12px">
                    <input type="hidden" name="action" value="ppar_digistore24_sources_bulk_register">
                    <?php wp_nonce_field('ppar_digistore24_sources_bulk_register','ppar_digistore24_nonce'); ?>
                    <p><label>Je Zeile: <code>Produkt-ID[TAB]HTTPS-Werbemittelseite[TAB]Bezeichnung</code> — Werbemittelseite und Bezeichnung dürfen zunächst leer bleiben<br>
                    <textarea class="large-text code" rows="8" name="sources_tsv" placeholder="53213&#9;https://vendor.example/werbemittel/&#9;MKA Horsemanship Academy"></textarea></label></p>
                    <p><button class="button" type="submit" <?php disabled(!$this->digistore24_fingerprint_matches($settings)); ?>>Quellen gesammelt übernehmen</button></p>
                    <p class="description">Maximal 50 Zeilen. Der sichere Digistore24-Promolink wird automatisch aus Produkt-ID und geprüfter Affiliate-ID gebildet. Fehlt die Werbemittelseite, bleibt die Quelle sichtbar und wird nicht veröffentlicht, bis die Seite hinterlegt ist.</p>
                </form>
            </details>
        </section>
        <section class="postbox" style="padding:18px;margin-top:18px">
            <h2>Einzelquelle (Fallback)</h2>
            <p>Digistore24 ist ausschließlich Banner-Provider. Verwendet werden nur eine konkrete Produkt-ID, der von Digistore24 ausgegebene echte Promolink und die echte Vendor-Werbemittelseite. Die Affiliate-ID im Promolink muss exakt zum aktuell getesteten Digistore24-Zugang passen.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="ppar_digistore24_source_register">
                <?php wp_nonce_field('ppar_digistore24_source_register','ppar_digistore24_nonce'); ?>
                <p><label>Digistore24 Produkt-ID<br><input type="text" inputmode="numeric" pattern="[0-9]+" name="product_id" required placeholder="z. B. 53213"></label></p>
                <p><label>Von Digistore24 ausgegebener Promolink<br><input class="large-text" type="url" name="promolink" required placeholder="https://www.checkout-ds24.com/redir/... oder https://vendor.../#aff=..."></label></p>
                <p><label>Vendor-Support-/Werbemittelseite (HTTPS)<br><input class="large-text" type="url" name="support_url" required placeholder="https://..."></label></p>
                <p><label>Bezeichnung (optional)<br><input class="regular-text" type="text" name="label" placeholder="z. B. MKA Horsemanship Academy"></label></p>
                <p><button class="button button-primary" type="submit" <?php disabled(!$this->digistore24_fingerprint_matches($settings)); ?>>Promolink prüfen &amp; Vendor-Banner importieren</button></p>
                <p class="description">Fail-closed: Import nur bei passender Produkt-ID, aktuell getesteter Affiliate-ID, echtem Digistore24-/Vendor-Promolink und gültiger HTTPS-Werbemittelseite.</p>
            </form>
            <p><strong>Letzter DS24-Quellstatus:</strong> <?php echo !empty($store['last_checked']) ? esc_html(wp_date('d.m.Y H:i',(int)$store['last_checked'])) : 'nie'; ?> · <?php echo esc_html((string)($store['last_message'] ?? '')); ?></p>
        </section>
        <?php foreach ($items as $entry) : if (!is_array($entry)) { continue; } $entry_id=(string)($entry['id']??''); ?>
        <section class="postbox" style="padding:18px;margin-top:14px">
            <h3><?php echo esc_html((string)($entry['headline'] ?? ('Digistore24 Produkt ' . $entry_id))); ?></h3>
            <p><strong>Produkt-ID:</strong> <?php echo esc_html((string)($entry['main_product_id'] ?? $entry_id)); ?> · <strong>Quelle:</strong> <?php echo $this->digistore24_entry_has_fresh_affiliation($entry) ? 'bestätigt' : 'nicht freigegeben'; ?></p>
            <?php if (!$this->digistore24_is_https_url((string)($entry['support_url'] ?? ''))) : ?><p><strong>Werbemittelseite fehlt:</strong> Für diesen Partner ist einmalig die echte HTTPS-Vendor-Werbemittelseite erforderlich.</p><?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="ppar_digistore24_import_banners"><input type="hidden" name="entry_id" value="<?php echo esc_attr($entry_id); ?>">
                <?php wp_nonce_field('ppar_digistore24_import_banners_' . $entry_id,'ppar_digistore24_nonce'); ?>
                <p><strong>Promolink:</strong> <code><?php echo esc_html((string)($entry['promolink'] ?? '')); ?></code></p>
                <label>Vendor-Support-/Werbemittelseite (HTTPS)<br><input class="large-text" type="url" name="support_url" value="<?php echo esc_attr((string)($entry['support_url'] ?? '')); ?>" required></label>
                <p><button class="button" type="submit">Promolink erneut prüfen &amp; Banner aktualisieren</button></p>
            </form>
        </section>
        <?php endforeach;
    }

    private function digistore24_record_operation_feedback($message, $error = false, $entry_id = '', $final_status = '', $final_message = '') {
        $stored = get_option('ppar_digistore24_marketplace_v1', array());
        $stored = is_array($stored) ? $stored : array();
        $stored['last_operation_at'] = time();
        $stored['last_operation_status'] = $error ? 'failed' : 'completed';
        $stored['last_operation_message'] = sanitize_text_field((string) $message);
        $stored['last_operation_entry_id'] = preg_replace('/[^0-9]/', '', (string) $entry_id);
        if ($final_status !== '') {
            $stored['last_operation_final_status'] = sanitize_key((string) $final_status);
            $stored['last_operation_final_message'] = sanitize_text_field((string) $final_message);
        } else {
            // A new operation must never display final evidence from an older run.
            $stored['last_operation_final_status'] = '';
            $stored['last_operation_final_message'] = '';
        }
        update_option('ppar_digistore24_marketplace_v1', $stored, false);
    }

    private function digistore24_redirect_specialist($message = '', $error = false, $entry_id = '') {
        if ($message !== '') {
            $this->digistore24_record_operation_feedback($message, $error, $entry_id);
        }
        $args = array('page'=>'affiliate-portal-provider-digistore24');
        if ($message !== '') {
            $args[$error ? 'ppar_provider_error' : 'ppar_provider_saved'] = $error ? rawurlencode(sanitize_text_field($message)) : 'digistore24';
        }
        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
        exit;
    }

    private function digistore24_parse_bulk_source_line($line) {
        $line = trim((string) $line);
        if ($line === '') { return new WP_Error('digistore24_bulk_line_empty', 'Leere Quellenzeile.'); }
        $parts = strpos($line, "\t") !== false ? explode("\t", $line) : explode(';', $line);
        $parts = array_values(array_map('trim', $parts));
        $product_id = (string) ($parts[0] ?? '');
        $promolink = ''; $support_url = ''; $label = '';

        // A canonical DS24 redir link may be used instead of the product ID.
        if ($this->digistore24_is_https_url($product_id)) {
            $candidate = esc_url_raw($product_id);
            $path = trim((string) wp_parse_url($candidate, PHP_URL_PATH), '/');
            $segments = array_values(array_filter(array_map('rawurldecode', explode('/', $path)), 'strlen'));
            if (strtolower((string) ($segments[0] ?? '')) !== 'redir' || !ctype_digit((string) ($segments[1] ?? ''))) {
                return new WP_Error('digistore24_bulk_promolink_invalid', 'Promolink-Zeile enthält keine kanonische Digistore24-Produkt-ID.');
            }
            $product_id = (string) $segments[1];
            $promolink = $candidate;
            $support_url = esc_url_raw((string) ($parts[1] ?? ''));
            $label = sanitize_text_field((string) ($parts[2] ?? ''));
        } else {
            if ($product_id === '' || !ctype_digit($product_id) || (string) absint($product_id) !== $product_id) {
                return new WP_Error('digistore24_product_id_invalid', 'Digistore24-Produkt-ID muss eine kanonische numerische ID sein.');
            }
            $second = (string) ($parts[1] ?? '');
            $third = (string) ($parts[2] ?? '');
            $fourth = (string) ($parts[3] ?? '');
            if ($second !== '' && $this->digistore24_is_https_url($second)
                && in_array(strtolower((string) wp_parse_url($second, PHP_URL_HOST)), array('checkout-ds24.com','www.checkout-ds24.com'), true)) {
                // Legacy 4-column format: product | promolink | support | label.
                $promolink = esc_url_raw($second);
                $support_url = esc_url_raw($third);
                $label = sanitize_text_field($fourth);
            } else {
                // KISS bulk format: product | support page | optional label.
                $support_url = esc_url_raw($second);
                $label = sanitize_text_field($third);
            }
        }
        if ($promolink === '') { $promolink = $this->digistore24_canonical_promolink($product_id); }
        return array('product_id'=>$product_id,'promolink'=>$promolink,'support_url'=>$support_url,'label'=>$label);
    }

    public function digistore24_handle_sources_bulk_register() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_digistore24_sources_bulk_register','ppar_digistore24_nonce');
        $raw = isset($_POST['sources_tsv']) ? (string) wp_unslash($_POST['sources_tsv']) : '';
        $lines = preg_split('/\r\n|\r|\n/', $raw);
        $lines = array_values(array_filter(array_map('trim', (array) $lines), 'strlen'));
        if (!$lines) { $this->digistore24_redirect_specialist('Keine Quellenzeilen angegeben.', true); }
        if (count($lines) > 50) { $this->digistore24_redirect_specialist('Maximal 50 Digistore24-Quellen pro Sammelübernahme.', true); }
        $saved = 0; $blocked = 0; $first_error = '';
        foreach ($lines as $line) {
            $parsed = $this->digistore24_parse_bulk_source_line($line);
            if (is_wp_error($parsed)) {
                $blocked++;
                if ($first_error === '') { $first_error = $parsed->get_error_message(); }
                continue;
            }
            $result = $this->digistore24_register_approved_source(
                (string) $parsed['product_id'], (string) $parsed['support_url'], (string) $parsed['promolink'],
                (string) $parsed['label'], true, 'admin_confirmed_bulk'
            );
            if (is_wp_error($result)) {
                $blocked++;
                if ($first_error === '') { $first_error = $result->get_error_message(); }
                continue;
            }
            $saved++;
        }
        $message = sprintf('%d Digistore24-Quellen gesammelt übernommen · %d blockiert.', $saved, $blocked);
        // One action, not two: every successfully registered source immediately
        // enters the same bounded central DS24 sync. Invalid lines do not abort
        // the valid remainder. The shutdown finalizer keeps the exact readback.
        if ($saved > 0) {
            $sync = $this->digistore24_automation_dispatch(null, 'digistore24', array('provider'=>'digistore24','partner_external_id'=>'confirmed-sources'), true, self::PROVIDER_CONTRACT_VERSION);
            if (is_array($sync) && is_array($sync['summary'] ?? null)) {
                $summary = $sync['summary'];
                $message .= sprintf(' Automatisch synchronisiert: %d Quellen geprüft · %d Banner importiert · %d benötigen noch Eingabe · %d blockiert.',
                    absint($summary['automation_processed'] ?? 0), absint($summary['automation_imported'] ?? 0),
                    absint($summary['requires_support_url'] ?? 0), absint($summary['automation_blocked'] ?? 0));
            } elseif (is_wp_error($sync)) {
                $message .= ' Synchronisation: ' . sanitize_text_field($sync->get_error_message());
            }
        }
        if ($first_error !== '') { $message .= ' Erster Hinweis: ' . sanitize_text_field($first_error); }
        $this->digistore24_redirect_specialist($message, $saved <= 0, '');
    }

    public function digistore24_handle_bulk_refresh() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_digistore24_bulk_refresh','ppar_digistore24_nonce');
        $result = $this->digistore24_automation_dispatch(null, 'digistore24', array('provider'=>'digistore24','partner_external_id'=>'confirmed-sources'), true, self::PROVIDER_CONTRACT_VERSION);
        if (is_wp_error($result)) { $this->digistore24_redirect_specialist($result->get_error_message(), true); }
        $summary = is_array($result['summary'] ?? null) ? $result['summary'] : array();
        $message = sanitize_text_field((string) ($summary['message'] ?? ''));
        if ($message === '') {
            $message = sprintf('%d von %d bestätigten Quellen geprüft · %d Banner importiert · %d benötigen eine Werbemittelseite · %d blockiert.',
                absint($summary['automation_processed'] ?? 0), absint($summary['source_count'] ?? 0), absint($summary['automation_imported'] ?? 0),
                absint($summary['requires_support_url'] ?? 0), absint($summary['automation_blocked'] ?? 0));
        }
        $error = sanitize_key((string) ($summary['status'] ?? '')) === 'failed';
        $this->digistore24_redirect_specialist($message, $error, '');
    }

    public function digistore24_handle_source_register() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_digistore24_source_register','ppar_digistore24_nonce');
        $product_id = trim((string) ($_POST['product_id'] ?? ''));
        $promolink = esc_url_raw((string) ($_POST['promolink'] ?? ''));
        $support_url = esc_url_raw((string) ($_POST['support_url'] ?? ''));
        $label = sanitize_text_field((string) ($_POST['label'] ?? ''));
        $source = $this->digistore24_register_approved_source($product_id, $support_url, $promolink, $label);
        if (is_wp_error($source)) {
            $this->digistore24_redirect_specialist($source->get_error_message(), true);
        }
        $result = $this->digistore24_import_vendor_banners((string) ($source['id'] ?? $product_id), $support_url, false);
        if (is_wp_error($result)) {
            $message = $result->get_error_message();
        } else {
            $flow = is_array($result['convergence'] ?? null) ? $result['convergence'] : array();
            $message = sprintf(
                '%d echte Vendor-Banner importiert · %d Bilder geprüft · %d Ausgabeobjekte geplant · %d Entwürfe vorbereitet · %d Review · %d blockiert.',
                absint($result['imported'] ?? 0), absint($flow['verified'] ?? 0), absint($flow['planned'] ?? 0),
                absint($flow['drafts'] ?? 0), absint($flow['review'] ?? 0), absint($result['blocked'] ?? 0) + absint($flow['blocked'] ?? 0)
            );
            if (!empty($flow['errors'])) {
                $message .= ' Erster Gate-Hinweis: ' . sanitize_text_field((string) reset($flow['errors']));
            }
        }
        if (!is_wp_error($result)) {
            $this->digistore24_operation_context = array('sources'=>array(array(
                'entry_id'=>(string) ($source['id'] ?? $product_id),
                'identity_hashes'=>(array) ($result['identity_hashes'] ?? array()),
            )));
        }
        $this->digistore24_redirect_specialist($message, is_wp_error($result), (string) ($source['id'] ?? $product_id));
    }

    public function digistore24_handle_marketplace_refresh() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_digistore24_marketplace_refresh','ppar_digistore24_nonce');
        $this->digistore24_redirect_specialist('Der nicht offiziell dokumentierte Marketplace-API-Abruf ist deaktiviert. Bitte konkrete Produkt-ID, echten Promolink und Vendor-Werbemittelseite verwenden.', true);
    }

    public function digistore24_handle_partnership() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $entry_id = preg_replace('/[^0-9]/', '', (string) ($_POST['entry_id'] ?? ''));
        check_admin_referer('ppar_digistore24_partnership_' . $entry_id,'ppar_digistore24_nonce');
        $result = $this->digistore24_set_partnership($entry_id, !empty($_POST['confirmed']));
        $this->digistore24_redirect_specialist(is_wp_error($result) ? $result->get_error_message() : 'Partnerschaftsstatus gespeichert.', is_wp_error($result));
    }

    public function digistore24_handle_import_banners() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $entry_id = preg_replace('/[^0-9]/', '', (string) ($_POST['entry_id'] ?? ''));
        check_admin_referer('ppar_digistore24_import_banners_' . $entry_id,'ppar_digistore24_nonce');
        $support_url = esc_url_raw((string) ($_POST['support_url'] ?? ''));
        $result = $this->digistore24_import_vendor_banners($entry_id, $support_url);
        if (is_wp_error($result)) {
            $message = $result->get_error_message();
        } else {
            $flow = is_array($result['convergence'] ?? null) ? $result['convergence'] : array();
            $message = sprintf(
                '%d Vendor-Banner aktualisiert · %d Bilder geprüft · %d Ausgabeobjekte geplant · %d Entwürfe vorbereitet · %d Review · %d blockiert.',
                absint($result['imported'] ?? 0), absint($flow['verified'] ?? 0), absint($flow['planned'] ?? 0),
                absint($flow['drafts'] ?? 0), absint($flow['review'] ?? 0), absint($result['blocked'] ?? 0) + absint($flow['blocked'] ?? 0)
            );
            if (!empty($flow['errors'])) {
                $message .= ' Erster Gate-Hinweis: ' . sanitize_text_field((string) reset($flow['errors']));
            }
        }
        if (!is_wp_error($result)) {
            $this->digistore24_operation_context = array('sources'=>array(array(
                'entry_id'=>$entry_id,
                'identity_hashes'=>(array) ($result['identity_hashes'] ?? array()),
            )));
        }
        $this->digistore24_redirect_specialist($message, is_wp_error($result), $entry_id);
    }

    public function digistore24_final_publication_guard() {
        if (!method_exists($this, 'output_objects_table') || !method_exists($this, 'output_finalize_digistore24_object')) { return; }
        global $wpdb;
        if (!is_object($wpdb)) { return; }
        $table = $this->output_objects_table();

        // Phase 1: only new inactive candidates enter the full final gate. A
        // failed candidate is retired without touching a published LKG.
        $drafts = $wpdb->get_results("SELECT * FROM {$table} WHERE provider='digistore24' AND status='draft' ORDER BY updated_at ASC LIMIT 120", ARRAY_A);
        foreach ((array) $drafts as $object) {
            $result = $this->output_finalize_digistore24_object($object);
            if (is_wp_error($result)) {
                $this->output_deactivate_materialized_object($object, $result->get_error_message());
                $wpdb->update($table, array('status'=>'review','decision_reason'=>$result->get_error_message(),'updated_at'=>time()), array('id'=>absint($object['id'] ?? 0)));
            }
        }

        // Phase 2: already published LKGs are never reinterpreted as a failed
        // candidate merely because a new target/source fingerprint exists. They
        // remain live while hard safety still holds; genuine safety revocations
        // still deactivate them immediately and fail closed.
        if (!method_exists($this, 'output_digistore24_lkg_hard_safety')) { return; }
        $published = $wpdb->get_results("SELECT * FROM {$table} WHERE provider='digistore24' AND status='published' ORDER BY updated_at ASC LIMIT 120", ARRAY_A);
        foreach ((array) $published as $object) {
            $safe = $this->output_digistore24_lkg_hard_safety($object);
            if (is_wp_error($safe)) {
                $this->output_deactivate_materialized_object($object, $safe->get_error_message());
                $wpdb->update($table, array('status'=>'quarantine','decision_reason'=>$safe->get_error_message(),'updated_at'=>time()), array('id'=>absint($object['id'] ?? 0)));
            }
        }

        // Persist an exact, source-bound live-gate readback for the admin page.
        // This is evidence only; it does not participate in any publication decision.
        $context = is_array($this->digistore24_operation_context) ? $this->digistore24_operation_context : array();
        $sources = array_values(array_filter((array) ($context['sources'] ?? array()), 'is_array'));
        if (!$sources && !empty($context['entry_id'])) {
            $sources[] = array('entry_id'=>$context['entry_id'],'identity_hashes'=>(array) ($context['identity_hashes'] ?? array()));
        }
        if ($sources) {
            $counts = array('published'=>0,'review'=>0,'draft'=>0,'quarantine'=>0,'superseded'=>0,'other'=>0);
            $source_ids = array();
            foreach ($sources as $source_context) {
                $entry_id = preg_replace('/[^0-9]/', '', (string) ($source_context['entry_id'] ?? ''));
                $hashes = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) ($source_context['identity_hashes'] ?? array())))));
                if ($entry_id === '' || !$hashes) { $counts['other']++; continue; }
                $source_ids[] = $entry_id;
                foreach ($hashes as $identity_hash) {
                    if (!preg_match('/^[a-f0-9]{64}$/', strtolower($identity_hash))) { $counts['other']++; continue; }
                    $rows = $wpdb->get_results($wpdb->prepare(
                        "SELECT status FROM {$table} WHERE provider=%s AND partner_external_id=%s AND creative_identity_hash=%s",
                        'digistore24', 'entry-' . $entry_id, strtolower($identity_hash)
                    ), ARRAY_A);
                    if (!$rows) { $counts['other']++; continue; }
                    foreach ((array) $rows as $row) {
                        $status = sanitize_key((string) ($row['status'] ?? ''));
                        if (isset($counts[$status])) { $counts[$status]++; } else { $counts['other']++; }
                    }
                }
            }
            $source_ids = array_values(array_unique($source_ids));
            $final_status = ($counts['review'] > 0 || $counts['quarantine'] > 0) ? 'review'
                : (($counts['published'] <= 0 || $counts['draft'] > 0 || $counts['other'] > 0) ? 'incomplete' : 'completed');
            $source_label = count($source_ids) === 1 ? $source_ids[0] : (count($source_ids) . ' Quellen');
            $final_message = sprintf(
                'Quelle %s · %d veröffentlicht · %d ersetzt · %d Review · %d Quarantäne · %d Draft-Rest · %d ungeklärt.',
                $source_label, $counts['published'], $counts['superseded'], $counts['review'], $counts['quarantine'], $counts['draft'], $counts['other']
            );
            $operation_store = get_option('ppar_digistore24_marketplace_v1', array());
            $operation_store = is_array($operation_store) ? $operation_store : array();
            $this->digistore24_record_operation_feedback(
                (string) ($operation_store['last_operation_message'] ?? ''),
                false,
                count($source_ids) === 1 ? $source_ids[0] : '',
                $final_status,
                $final_message
            );
        }
    }
}
