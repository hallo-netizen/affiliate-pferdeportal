<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Admin {
    private const PARENT='portal-seo-topic-engine';
    private const SHORTPATH_TRACE_OPTION='pste_shortpath_diagnostics_v1';
    private const TITLE_DESK_REENTRY_HOOK='pste_title_desk_reentry';
    private const TITLE_DESK_REENTRY_STATE='pste_title_desk_reentry_state_v1';
    private const TITLE_DESK_REENTRY_LOCK='pste_title_desk_reentry_lock_v1';
    private const TITLE_DESK_REENTRY_LOOPBACK='pste_title_desk_reentry_continue';
    private const TITLE_DESK_REENTRY_CHUNK=8;
    private const TITLE_DESK_REENTRY_SECONDS=12.0;
    private const TABS=[
        'overview'=>['slug'=>'portal-seo-topic-engine','label'=>'Produktion'],
        'review'=>['slug'=>'portal-seo-topic-engine-review','label'=>'Themenprüfung'],
        'sources'=>['slug'=>'portal-seo-topic-engine-sources','label'=>'Datenquellen'],
        'settings'=>['slug'=>'portal-seo-topic-engine-settings','label'=>'Einstellungen'],
    ];
    private const VISIBLE_TABS=['overview','review','sources','settings'];

    public static function isOwnPageRequest(): bool {
        $page=isset($_GET['page'])?(string)$_GET['page']:'';
        if($page==='')return false;
        $allowed=[self::PARENT];
        foreach(self::TABS as $tab)$allowed[]=(string)($tab['slug']??'');
        return in_array($page,array_values(array_unique(array_filter($allowed,'strlen'))),true);
    }

    public static function init(): void {
        if(PSTE_Plugin::isReady()){require_once PSTE_DIR.'includes/class-pste-storage-maintenance.php';PSTE_Storage_Admin::init();}
        // Transport continuation only. The existing topic owner remains the sole decision-maker.
        add_action('wp_ajax_'.self::TITLE_DESK_REENTRY_LOOPBACK,[self::class,'continueTitleDeskReentry']);
        add_action('wp_ajax_nopriv_'.self::TITLE_DESK_REENTRY_LOOPBACK,[self::class,'continueTitleDeskReentry']);
        if(PSTE_Plugin::isReady())PSTE_Mini_Workflow::init();
        add_action('admin_menu',[self::class,'menu'],20);
        add_action('admin_menu',[self::class,'hideInternalCompilerMenus'],999);
        add_action('admin_notices',[self::class,'activeNotice'],20);
        add_action('admin_bar_menu',[self::class,'adminBar'],99);
        add_filter('plugin_action_links_'.plugin_basename(PSTE_DIR.'portal-seo-topic-engine.php'),[self::class,'pluginActionLinks']);
        $actions=['pste_retry_safe_migration'=>'retrySafeMigration','pste_export_workflow_diagnostics'=>'exportWorkflowDiagnostics','pste_export_automatic_protocol'=>'exportAutomaticProtocol','pste_export_flight_protocol'=>'exportFlightProtocol'];
        if(PSTE_Plugin::isReady()){
            $actions=array_merge($actions,[
                'pste_save_settings'=>'saveSettings','pste_save_credentials'=>'saveCredentials','pste_capture_baseline'=>'captureBaseline',
                'pste_connection_test'=>'connectionTest','pste_export_overlay'=>'exportOverlay','pste_export_topic_map'=>'exportTopicMap','pste_export_planning_topics'=>'exportPlanningTopics','pste_shortpath_create_export'=>'shortPathCreateExport','pste_shortpath_diagnostics_download'=>'shortPathDiagnosticsDownload',
                'pste_import_gsc'=>'importGsc','pste_save_gsc_client'=>'saveGscClient','pste_gsc_connect'=>'gscConnect',
                'pste_gsc_oauth_callback'=>'gscOauthCallback','pste_gsc_test'=>'gscTest','pste_gsc_save_property'=>'gscSaveProperty','pste_gsc_sync'=>'gscSync',
                'pste_gsc_disconnect'=>'gscDisconnect','pste_save_category_weights'=>'saveCategoryWeights','pste_import_editorial_plan'=>'importEditorialPlan',
                'pste_review_candidate'=>'reviewCandidate','pste_set_candidate_type'=>'setCandidateType','pste_title_desk_export'=>'exportTitleDesk','pste_title_desk_import'=>'importTitleDesk','pste_process_context_batch'=>'processContextBatch','pste_repair_price_intents'=>'repairPriceIntents',
                'pste_import_existing_evidence_reentry'=>'importExistingEvidenceReentry',
                'pste_sandbox_export'=>'sandboxExport','pste_sandbox_review_relevance'=>'sandboxReviewRelevance','pste_sandbox_confirm_internal'=>'sandboxConfirmInternal',
            ]);
        }
        foreach($actions as $action=>$method)add_action('admin_post_'.$action,[self::class,$method]);
        add_action('wp_ajax_pste_safe_migration_start',[self::class,'safeMigrationStartAjax']);
        add_action('wp_ajax_pste_safe_migration_advance',[self::class,'safeMigrationAdvanceAjax']);
        if(PSTE_Plugin::isReady()){
            add_action('wp_ajax_pste_context_advance',[self::class,'contextAdvanceAjax']);
            add_action('wp_ajax_pste_research_start',[self::class,'researchStartAjax']);
            add_action('wp_ajax_pste_research_advance',[self::class,'researchAdvanceAjax']);
            add_action('wp_ajax_pste_research_status',[self::class,'researchStatusAjax']);
            add_action('wp_ajax_pste_research_cancel',[self::class,'researchCancelAjax']);
            add_action('wp_ajax_pste_research_orphan_cancel',[self::class,'researchOrphanCancelAjax']);
            add_action('wp_ajax_pste_breadth_research_start',[self::class,'breadthResearchStartAjax']);
            add_action('wp_ajax_pste_breadth_research_advance',[self::class,'breadthResearchAdvanceAjax']);
            add_action('wp_ajax_pste_breadth_research_status',[self::class,'breadthResearchStatusAjax']);
            add_action('wp_ajax_pste_breadth_research_cancel',[self::class,'breadthResearchCancelAjax']);
            add_action('wp_ajax_pste_sandbox_start',[self::class,'sandboxStartAjax']);
            add_action('wp_ajax_pste_sandbox_advance',[self::class,'sandboxAdvanceAjax']);
            add_action('wp_ajax_pste_sandbox_cancel_unknown',[self::class,'sandboxCancelUnknownAjax']);
            add_action('wp_ajax_pste_shortpath_diagnostics',[self::class,'shortPathDiagnosticsAjax']);
            add_action('wp_ajax_pste_production_auto_status',[self::class,'productionAutoStatusAjax']);
            add_action('wp_ajax_pste_production_auto_step',[self::class,'productionAutoStepAjax']);
            add_action('wp_ajax_pste_production_auto_cancel',[self::class,'productionAutoCancelAjax']);
            add_action('wp_ajax_pste_clean_reset',[self::class,'cleanResetAjax']);
            add_action('wp_ajax_pste_evidence_read_batch',[self::class,'evidenceReadBatchAjax']);
            add_action('wp_ajax_pste_evidence_history_batch',[self::class,'evidenceHistoryBatchAjax']);
        }
    }

    public static function menu(): void {
        add_menu_page('Portal SEO Themenengine','SEO Themenengine','manage_options',self::PARENT,[self::class,'pageOverview'],'dashicons-chart-area',58);
        add_submenu_page(self::PARENT,'Produktion','Produktion','manage_options',self::PARENT,[self::class,'pageOverview']);
        foreach(self::VISIBLE_TABS as $key){if($key==='overview')continue;$tab=self::TABS[$key];add_submenu_page(self::PARENT,$tab['label'],$tab['label'],'manage_options',$tab['slug'],[self::class,'page'.ucfirst($key)]);}
    }
    public static function hideInternalCompilerMenus(): void {
        if(function_exists('remove_submenu_page')){
            remove_submenu_page(self::PARENT,'portal-seo-editorial-plan-compiler');
            remove_submenu_page(self::PARENT,'pserc-storage-maintenance');
        }
    }
    public static function activeNotice(): void {
        if(!current_user_can('manage_options'))return;
        if(isset($_GET['page'])&&str_starts_with((string)$_GET['page'],'portal-seo-topic-engine'))return;
        $boot=PSTE_Plugin::bootStatus();
        $status=(string)($boot['status']??'PENDING');
        $label=$status==='READY'?'einsatzbereit':'aktiv, Datenmigration noch nicht ausgeführt';
        echo '<div class="notice notice-info"><p><strong>Portal SEO Themenengine ist '.esc_html($label).'.</strong> <a href="'.esc_url(admin_url('admin.php?page='.self::PARENT)).'">Themenengine öffnen</a></p></div>';
    }
    public static function adminBar($bar): void {if(current_user_can('manage_options'))$bar->add_node(['id'=>'pste-admin-bar','title'=>'SEO Themenengine','href'=>admin_url('admin.php?page='.self::PARENT)]);}
    public static function pluginActionLinks(array $links): array {array_unshift($links,'<a href="'.esc_url(admin_url('admin.php?page='.self::PARENT)).'">Öffnen</a>');return $links;}
    public static function pageOverview(): void {self::render('overview');}
    public static function pageReview(): void {self::render('review');}
    public static function pageSources(): void {self::render('sources');}
    public static function pageSettings(): void {self::render('settings');}

    private static function render(string $tab): void {
        PSTE_Auth::assertAdmin();echo '<div class="wrap pste-wrap"><h1>Portal SEO Themenengine <span style="font-size:14px;font-weight:400">'.esc_html(PSTE_VERSION).'</span></h1>';self::styles();self::notices();
        $boot=PSTE_Plugin::bootStatus();
        if(!PSTE_Plugin::isReady()){
            self::renderSafeBoot($boot);
            echo '</div>';
            return;
        }
        self::tabs($tab);
        echo '<div class="notice notice-info"><p><strong>Read-only gegenüber dem Portal:</strong> Die Engine schreibt nur in eigene <code>pste_</code>-Speicher. Keine Artikel, Kategorien, URLs, Yoast-Einstellungen oder Produktionsregeln werden verändert.</p></div>';
        try{
            match($tab){'review'=>self::renderReview(),'sources'=>self::renderSources(),'settings'=>self::renderSettings(),default=>self::renderOverview()};
        }catch(Throwable $e){
            self::renderOperationalFailure($e);
        }
        echo '</div>';
    }


    /** Read-only export: current canonical owners, no reclassification or replay. */
    private static function diagnosticFields($record,array $allowed): array {
        if(!is_array($record))return [];
        $out=[];foreach($allowed as $key){if(array_key_exists($key,$record)){
            $v=$record[$key];if(is_scalar($v)||$v===null)$out[$key]=$v;
        }}return $out;
    }

    /** Query only existing status owners; never read or export credentials or topic payloads. */
    public static function workflowDiagnosticsSnapshot(): array {
        $out=['contract'=>'PSTE_WORKFLOW_STATUS_READ_ONLY_V1','generated_utc'=>gmdate('c'),
            'pste_version'=>PSTE_VERSION,'read_only'=>true,'no_provider_calls'=>true,
            'no_article_or_category_changes'=>true,'sections'=>[]];
        $sections=[
            'boot'=>static function(){return self::diagnosticFields(PSTE_Plugin::bootStatus(),['status','stage','error_code','schema','version']);},
            'credentials'=>static function(){return self::diagnosticFields(PSTE_Credentials::status(),['configured','stored_in_wordpress','login_source','password_source','encrypted_at_rest','error_code']);},
            'portal_baseline'=>static function(){return self::diagnosticFields(PSTE_Snapshot::baselineStatus((array)get_option(PSTE_OPTION_SITE_BASELINE,[])),['status','error_code','structure_hash','captured_at_utc','reason']);},
            'portal_context'=>static function(){return self::diagnosticFields(PSTE_Context_Refresh::status(),['status','error_code','phase','processed','total','started_at_utc','updated_at_utc','payload_repair_cursor','payload_repair_total','sandbox_processed','sandbox_total','sandbox_record_store_migration_status','sandbox_record_store_migration_cursor','sandbox_record_store_verification_cursor']);},
            'production'=>static function(){return self::diagnosticFields(self::productionAutoState(),['stage','status','terminal','ready_count','progress_text','started_at_utc','last_activity_utc','elapsed_seconds','last_activity_age_seconds','error_code']);},
            'research_driver'=>static function(){return self::diagnosticFields(PSTE_Research_Driver::status(),['status','health_code','last_error','step_number','last_step','last_result_code','last_progress_at_utc','step_started_at_utc','last_unfinished_step_started_at_utc','step_completed_at_utc','last_step_duration_ms','active_step_age_seconds','overdue_seconds','lock_active','lock_expires_at','lock_expired_owner','next_run_at_utc','no_progress_count','step_exception_count','last_exception_code']);},
            'existing_audit'=>static function(){return self::diagnosticFields(PSTE_Breadth_Research_Queue::peek(),['status','existing_only','local_backlog_processed','local_backlog_total','local_backlog_cursor','local_backlog_complete','local_backlog_title_candidates','usable_candidate_count','resume_recheck_until','resume_recheck_cursor','resume_recheck_checked','last_error','completion_reason','updated_at_utc']);},
            'pserc_job'=>static function(){return class_exists('PSERC_Plan_Snapshot_Store')?self::diagnosticFields(PSERC_Plan_Snapshot_Store::getJob(),['status','phase','error_code','candidate_index','eligible_count','prepared_count','ready_count','updated_at_utc']):['status'=>'PLUGIN_NOT_LOADED'];},
            'title_desk_reentry'=>static function(){return self::titleDeskReentryDiagnostics();},
        ];
        foreach($sections as $name=>$read){try{$out['sections'][$name]=['read'=>'PASS','data'=>$read()];}
            catch(Throwable $e){$code=strtoupper(trim((string)$e->getMessage()));
                $out['sections'][$name]=['read'=>'BLOCKED','error_code'=>substr((string)preg_replace('/[^A-Z0-9_:-]+/','_',$code),0,160)];}}
        return $out;
    }

    /**
     * Read existing topic-owner evidence for this title handoff; never evaluate,
     * retry, repair, promote or classify any topic. The owner has already run.
     * Only the current job's keys are read, capped by the original 100-key import.
     */
    public static function titleDeskReentryDiagnostics(): array {
        $state=get_option(self::TITLE_DESK_REENTRY_STATE,[]);
        $report=get_transient('pste_title_desk_reentry_report');
        $state=is_array($state)?$state:[];
        $report=is_array($report)?$report:[];
        $done=array_values(array_unique(array_filter(array_map('strval',(array)($state['done']??[])))));
        $pending=array_values(array_unique(array_filter(array_map('strval',(array)($state['pending']??[])))));
        $blocked=[];
        foreach((array)($report['blocked']??[]) as $item){
            if(!is_array($item))continue;
            $key=(string)($item['pool_key']??'');
            if($key==='')continue;
            $blocked[$key]=(string)($item['error_code']??'');
        }
        // Old 0.57.141 jobs may have already processed a few keys before
        // 0.57.142 adopted their remaining queue. Preserve their known failures.
        $keys=array_values(array_unique(array_merge($done,$pending,array_keys($blocked))));
        $keys=array_slice($keys,0,100);
        $out=['status'=>(string)($state['status']??'NOT_AVAILABLE'),
            'total'=>(int)($report['scheduled']??$state['total']??0),
            'processed' => (int)($report['processed']??count($done)),
            'held'=>(int)($report['held']??count($blocked)),
            'pending_count'=>count($pending),
            'last_transport_error'=>(string)($state['last_error']??''),
            'read_only'=>true,'topic_owner_rerun'=>false,'items'=>[],
            'hold_reason_counts'=>[], 'redaktionsbuero_routed'=>0,
            'unavailable_historical_results'=>0];
        if(!$keys)return $out;
        $rows=[];
        global $wpdb;
        $table=PSTE_Repository::table('topic_pool');
        foreach(array_chunk($keys,30) as $chunk){
            $placeholders=implode(',',array_fill(0,count($chunk),'%s'));
            $query=$wpdb->prepare("SELECT pool_key,manual_status,automatic_pool_status,planning_suitability,context_state,payload_json FROM $table WHERE pool_key IN ($placeholders)",...$chunk);
            $found=$wpdb->get_results($query,ARRAY_A);
            if(!is_array($found)||((string)($wpdb->last_error??''))!=='')throw new RuntimeException('PSTE_TITLE_DESK_REPORT_DB_READ_FAILED');
            foreach($found as $row){
                $k=(string)($row['pool_key']??'');
                if($k!=='')$rows[$k]=$row;
            }
        }
        $doneIndex=array_fill_keys($done,true);
        $pendingIndex=array_fill_keys($pending,true);
        $outcomes=is_array($state['outcomes']??null)?(array)$state['outcomes']:[];
        foreach($keys as $key){
            $saved=(array)($rows[$key]??[]);
            $payload=json_decode((string)($saved['payload_json']??''),true);
            $payload=is_array($payload)?$payload:[];
            $path=is_array($payload['normal_metadata_path']??null)?$payload['normal_metadata_path']:[];
            $gate=is_array($payload['planning_readiness_gate']??null)?$payload['planning_readiness_gate']:[];
            $review=is_array($payload['existing_evidence_reentry_review_result']??null)?$payload['existing_evidence_reentry_review_result']:[];
            $post=is_array($payload['retained_title_candidate_postpass_block']??null)?$payload['retained_title_candidate_postpass_block']:[];
            $outcome=is_array($outcomes[$key]??null)?$outcomes[$key]:[];
            $error=(string)($outcome['error_code']??$blocked[$key]??'');
            $status=(string)($outcome['status']??'');
            if($status===''){
                if(isset($pendingIndex[$key]))$status='PENDING';
                elseif(isset($blocked[$key]))$status=$error==='PSTE_TITLE_DESK_REENTRY_OWNER_NOT_READY'?'HELD':'BLOCKED';
                elseif(isset($doneIndex[$key]))$status='UNKNOWN_LEGACY_RESULT';
                else $status='UNKNOWN_LEGACY_RESULT';
            }
            $reasons=[];
            foreach([(array)($gate['reason_codes']??[]),(array)($path['reason_codes']??[])] as $reasonGroup){
                foreach($reasonGroup as $reason){
                    if(!is_string($reason)||$reason===''||$reason==='PSTE_NORMAL_METADATA_PATH_PASS')continue;
                    if(preg_match('/^[A-Z0-9_:-]{3,160}$/',$reason))$reasons[]=$reason;
                }
            }
            foreach([(string)($post['reason']??''),(string)($review['mismatch']??'')] as $reason){
                if($reason!==''&&preg_match('/^[A-Z0-9_:-]{3,160}$/',$reason))$reasons[]=$reason;
            }
            $reasons=array_values(array_unique($reasons));
            $first=$reasons[0]??($error?:'NO_STORED_REASON_AVAILABLE');
            if($status==='HELD'||$status==='BLOCKED'){
                $out['hold_reason_counts'][$first]=(int)($out['hold_reason_counts'][$first]??0)+1;
            }
            if($status==='UNKNOWN_LEGACY_RESULT')$out['unavailable_historical_results']++;
            $query=(string)($payload['raw_user_question']??$payload['primary_longtail_query']??$payload['canonical_query']??$payload['query_record']['raw_query']??'');
            $flow=is_array($path['worker_flow']??null)?(array)$path['worker_flow']:[];
            if(isset($doneIndex[$key])&&!empty($path['category_backlog_required'])
                &&(string)($flow['storage']??'')==='CATEGORY_ROOM_TOPIC_POOL')
                $out['redaktionsbuero_routed']++;
            $out['items'][]=[
                'work_destination'=>(string)($flow['storage']??'NOT_STORED'),
                'category_review_required'=>!empty($path['category_backlog_required']),
                'editorial_area'=>(string)($path['editorial_area']??'UNDECIDED'),
                'work_group'=>(string)($flow['work_group']??''),
                'pool_key'=>$key,'result'=>$status,
                'keyword'=>substr($query,0,250),
                'title'=>substr((string)($payload['editorial_title']??''),0,250),
                'owner_error_code'=>$error,
                'normal_path_status'=>(string)($path['status']??'NOT_STORED'),
                'planning_gate_status'=>(string)($gate['status']??'NOT_STORED'),
                // Show the single existing owner verdict and its stored evidence.
                // This report performs no further content or duplicate checks.
                'planning_next_action'=>(string)($gate['next_action']??''),
                'existing_match_evidence'=>array_map(static function($m): array {
                    $owner=(array)($m['keyword_ownership']??[]);
                    return [
                        'post_id'=>(int)($m['post_id']??0),
                        'title'=>substr((string)($m['title']??''),0,240),
                        'source'=>substr((string)($m['source']??''),0,80),
                        'authority'=>(string)($m['keyword_ownership_authority']??$owner['existing_keyword_authority']??'NOT_SPECIFIED'),
                    ];
                },array_slice((array)($gate['matches']??[]),0,3)),
                'planning_suitability'=>(string)($saved['planning_suitability']??'NOT_STORED'),
                'context_state'=>(string)($saved['context_state']??'NOT_STORED'),
                'automatic_pool_status'=>(string)($saved['automatic_pool_status']??'NOT_STORED'),
                'reason_codes'=>$reasons,
                'reason_evidence_available'=>!empty($reasons),
            ];
        }
        arsort($out['hold_reason_counts'],SORT_NUMERIC);
        return $out;
    }

    public static function exportWorkflowDiagnostics(): void {
        PSTE_Auth::assertAdmin('pste_export_workflow_diagnostics',(string)($_POST['_wpnonce']??''));
        self::jsonDownload(self::workflowDiagnosticsSnapshot(),'pferdeatelier-workflow-status-'.gmdate('Ymd-His').'.json');
    }

    private static function renderOperationalFailure(Throwable $e): void {
        $raw=strtoupper(trim((string)$e->getMessage()));
        $code=(string)preg_replace('/[^A-Z0-9_:-]+/','_',$raw);
        $code=substr($code!==''?$code:'PSTE_ADMIN_PAGE_FAILED',0,160);
        echo '<div class="notice notice-error inline"><p><strong>Diese Themenengine-Seite wurde sicher blockiert.</strong><br>WordPress und das übrige Backend bleiben erreichbar.<br><strong>Fehlercode:</strong> <code>'.esc_html($code).'</code></p></div>';
    }

    private static function renderSafeBoot(array $boot): void {
        $status=(string)($boot['status']??'PENDING');
        $stage=(string)($boot['stage']??'NOT_STARTED');
        $code=(string)($boot['error_code']??'');
        $message=(string)($boot['message']??'');
        $class=$status==='BLOCKED'?'notice-error':'notice-warning';
        echo '<div class="notice '.esc_attr($class).' inline"><p><strong>Sicherer Pluginstart: '.esc_html($status).'</strong></p>';
        echo '<p><strong>Stufe:</strong> <code>'.esc_html($stage).'</code>';
        if($code!=='')echo '<br><strong>Fehlercode:</strong> <code>'.esc_html($code).'</code>';
        if($message!=='')echo '<br><strong>Meldung:</strong> '.esc_html($message);
        echo '</p><p>Die Themenengine führt in diesem Zustand keine Recherche, keinen Portalabgleich und keine Produktionsübergabe aus. Das WordPress-Backend bleibt erreichbar.</p></div>';
        echo '<section class="pste-box"><h2>Sichere Migration</h2>';
        $job=PSTE_Safe_Migration_Job::current();$public=is_array($job)?PSTE_Safe_Migration_Job::publicState($job):[];$jobStatus=(string)($public['status']??'NOT_STARTED');
        $buttonLabel=in_array($jobStatus,['RUNNING','PAUSED_ERROR'],true)?'Sichere Migration fortsetzen':'Sichere Datenmigration starten';
        echo '<button type="button" class="button button-primary" id="pste-safe-migration-start">'.esc_html($buttonLabel).'</button><div id="pste-safe-migration-feedback" class="notice notice-info inline" style="display:none;margin-top:12px"><p></p></div>';
        if($public){echo '<p><strong>Job:</strong> <code>'.esc_html($jobStatus).'</code> · <strong>Phase:</strong> <code>'.esc_html((string)($public['phase']??'')).'</code><br><strong>Legacy/Identität:</strong> '.esc_html((string)($public['legacy_identity_progress']??0)).' / '.esc_html((string)($public['legacy_identity_total']??0)).' · <strong>Editorial vorbereiten:</strong> '.esc_html((string)($public['editorial_prepare_progress']??0)).' / '.esc_html((string)($public['editorial_total']??0)).' · <strong>Editorial finalisieren:</strong> '.esc_html((string)($public['editorial_finalize_progress']??0)).' / '.esc_html((string)($public['editorial_total']??0)).' · <strong>Sandbox:</strong> '.esc_html((string)($public['sandbox_progress']??0)).' / '.esc_html((string)($public['sandbox_total']??0)).'</p>';}
        echo '<p><strong>Gespeichertes Schema:</strong> <code>'.esc_html((string)($boot['schema']??'')).'</code> · <strong>Pluginversion:</strong> <code>'.esc_html((string)($boot['version']??PSTE_VERSION)).'</code></p>';
        $cfg=wp_json_encode(['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('pste_safe_migration_ajax'),'job'=>$public,'redirect'=>admin_url('admin.php?page='.self::PARENT.'&safe_migration_complete=1')],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        echo '<script>(function(){"use strict";const cfg='.$cfg.',btn=document.getElementById("pste-safe-migration-start"),box=document.getElementById("pste-safe-migration-feedback");const sleep=ms=>new Promise(r=>setTimeout(r,ms));function msg(t,e){if(!box)return;box.style.display="block";box.className="notice "+(e?"notice-error":"notice-info")+" inline";box.querySelector("p").textContent=t;}function show(j){let stream="";if(j.phase==="SANDBOX_RECORD_STORE_MIGRATION"&&Number(j.sandbox_record_store_source_bytes||0)>0){const total=Number(j.sandbox_record_store_source_bytes||0),pre=Number(j.sandbox_record_store_prehash_progress||0),post=Number(j.sandbox_record_store_posthash_progress||0),st=j.sandbox_record_store_migration_status||"";if(st==="SOURCE_HASH_BEFORE")stream=" · Sandbox-Quellhash "+pre+" / "+total;else if(st==="SOURCE_HASH_AFTER")stream=" · Sandbox-Abschlusshash "+post+" / "+total;}let verify="";if(j.phase==="FINAL_TOPIC_VERIFY_BATCH")verify=" · Abschlussprüfung "+Number(j.editorial_final_verify_progress||0)+" / "+Number(j.editorial_total||0);else if(j.phase==="EDITORIAL_CORE_VERIFY_BATCH")verify=" · Kernprüfung "+Number(j.editorial_core_verify_progress||0)+" / "+Number(j.editorial_total||0);msg("Migration: "+j.status+" · Phase "+j.phase+" · Identität "+j.legacy_identity_progress+" / "+j.legacy_identity_total+" · Editorial "+j.editorial_prepare_progress+" / "+j.editorial_total+" → "+j.editorial_finalize_progress+" / "+j.editorial_total+" · Sandbox "+j.sandbox_progress+" / "+j.sandbox_total+" · Record-Scan "+j.sandbox_record_scan_progress+" / "+j.sandbox_record_scan_total+stream+verify,false);}async function call(action,data){const body=new URLSearchParams(Object.assign({action:action,nonce:cfg.nonce},data||{}));let response,raw;try{response=await fetch(cfg.ajax_url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8","Accept":"application/json"},body:body.toString()});raw=await response.text();}catch(cause){const e=new Error("PSTE_AJAX_TRANSPORT_OUTCOME_UNKNOWN_"+action);e.psteTransport=true;e.cause=cause;throw e;}let json;try{json=JSON.parse((raw||"").replace(/^\uFEFF/,"").trim());}catch(cause){const e=new Error("PSTE_AJAX_TRANSPORT_OUTCOME_UNKNOWN_"+action);e.psteTransport=true;e.httpStatus=response.status;e.responseLength=(raw||"").length;e.cause=cause;throw e;}if(!response.ok||!json.success)throw new Error((json.data&&json.data.error_code)||("PSTE_AJAX_REQUEST_FAILED_HTTP_"+response.status));return json.data;}function progressKey(j){if(j.progress_token)return j.progress_token;return [j.status,j.phase,j.legacy_identity_progress,j.legacy_identity_history_repaired,j.payload_integrity_progress,j.editorial_raw_progress,j.editorial_prepare_progress,j.editorial_variant_progress,j.editorial_finalize_progress,j.editorial_core_verify_progress,j.editorial_final_verify_progress,j.sandbox_progress,j.sandbox_record_store_status,j.sandbox_record_store_migration_status,j.sandbox_record_store_prehash_progress,j.sandbox_record_store_migration_progress,j.sandbox_record_store_verification_progress,j.sandbox_record_store_posthash_progress,j.sandbox_record_store_receipt_sha256,j.sandbox_record_scan_progress].join("|");}async function loop(job,resume){let cur=job,first=!!resume,stalled=0;for(;;){show(cur);if(cur.status==="COMPLETE"){window.location.href=cfg.redirect;return;}if(cur.status==="PAUSED_ERROR"&&!first){msg("Sicher angehalten: "+(cur.last_error||"PSTE_SAFE_MIGRATION_PAUSED"),true);return;}const before=progressKey(cur);await sleep(180);const d=await call("pste_safe_migration_advance",{job_uuid:cur.job_uuid,explicit_resume:first?"1":"0"});cur=d.job;first=false;const after=progressKey(cur);stalled=after===before?stalled+1:0;if(stalled>=8)throw new Error("PSTE_SAFE_MIGRATION_STALLED");}}if(btn)btn.addEventListener("click",async()=>{btn.disabled=true;try{let job=cfg.job;if(!job||!job.job_uuid||job.status==="COMPLETE"){const d=await call("pste_safe_migration_start",{});job=d.job;}await loop(job,job.status==="PAUSED_ERROR");}catch(e){msg(e.message||"PSTE_SAFE_MIGRATION_FAILED",true);btn.disabled=false;}});})();</script></section>';
    }

    private static function renderOverview(): void {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        $baselineState=is_array($baseline)?PSTE_Snapshot::baselineStatus($baseline):['status'=>'NOT_CAPTURED'];
        $context=PSTE_Context_Refresh::status();
        $stats=PSTE_Repository::productionCandidateStats();
        $candidateQueue=null;try{$candidateQueue=PSTE_Breadth_Research_Queue::peek();}catch(Throwable $ignored){}
        self::renderExistingCandidateOverview($candidateQueue,$stats);

        echo '<details class="pste-box" style="margin-top:18px"><summary><strong>Systemstatus &amp; Wartung</strong> <span style="font-weight:400">(nur bei Bedarf)</span></summary>';
        echo '<p><strong>Portalbestand:</strong> <code>'.esc_html((string)($baselineState['status']??'NOT_CAPTURED')).'</code> · <strong>Portalabgleich:</strong> <code>'.esc_html((string)($context['status']??'NOT_STARTED')).'</code> · <strong>gespeicherte Themen:</strong> '.esc_html((string)($stats['total_topics']??0)).' · <strong>planbar:</strong> '.esc_html((string)($stats['planning_ready']??0)).'.</p>';
        if((string)($context['status']??'')==='BLOCKED')echo '<div class="notice notice-error inline"><p><strong>Portalabgleich blockiert:</strong> <code>'.esc_html((string)($context['error_code']??'PSTE_CONTEXT_REFRESH_FAILED')).'</code></p></div>';
        if(is_array($baseline)&&(int)($baseline['quarantined_category_count']??0)>0)echo '<p><strong>Sicher gesperrte Kategorien:</strong> '.esc_html((string)(int)$baseline['quarantined_category_count']).'. Sie werden nicht automatisch zugeordnet.</p>';
        $priceRepair=get_option(PSTE_OPTION_PRICE_INTENT_REPAIR,[]);$priceStatus=is_array($priceRepair)?(string)($priceRepair['status']??''):'';
        if(!in_array($priceStatus,['PASS','PARTIAL_PASS','BLOCKED'],true))self::actionForm('pste_repair_price_intents','pste_repair_price_intents','Einmalige Preis-Longtail-Korrektur ausführen');
        echo '</details>';
    }

    private static function renderExistingCandidateOverview($candidateQueue,array $stats=[]): void {
        $psercReady=class_exists('PSERC_Plan_Compile_Job')&&class_exists('PSERC_Plan_Snapshot_Store')&&class_exists('PSERC_Plan_Dependency_Fingerprint');
        $queueStatus=is_array($candidateQueue)?(string)($candidateQueue['status']??''):'';
        $queueProcessed=is_array($candidateQueue)?(int)($candidateQueue['local_backlog_processed']??0):0;
        $queueTotal=is_array($candidateQueue)?(int)($candidateQueue['local_backlog_total']??0):0;
        echo '<section class="pste-box" id="pste-production-center"><h2>Artikelproduktion</h2><p><strong>Zwei Wege.</strong> Automatik verarbeitet den vorhandenen Bestand. Kurzer Dienstweg nimmt bewusst vorgegebene Themen ohne neue DataForSEO-Recherche auf.</p>';
        PSTE_Mini_Workflow::renderManualBrief();
        echo '<div class="pste-two"><div class="pste-box" style="margin:0"><h3>Automatik</h3><p>Verarbeitet vorhandene Kandidaten in kleinen, wiederaufnehmbaren Blöcken und führt anschließend die Redaktionsplanprüfung aus. Sobald Artikel READY sind, wird genau eine Produktionsdatei heruntergeladen.</p>';
        echo '<p><strong>Gespeichert:</strong> '.esc_html((string)($stats['total_topics']??0)).' Themen · <strong>aktuell planbar:</strong> '.esc_html((string)($stats['planning_ready']??0)).'</p>';
        $held=max(0,(int)($stats['total_topics']??0)-(int)($stats['planning_ready']??0));
        echo '<details style="margin:8px 0 12px"><summary><strong>Warum nicht mehr planbar?</strong> '.esc_html((string)$held).' derzeit nicht bereit</summary>';
        echo '<p><strong>Fachliche Einordnung aller Themen:</strong> Artikelthema <strong>'.esc_html((string)($stats['role_article_all']??0)).'</strong> · bereits abgedeckt/Dublette <strong>'.esc_html((string)($stats['role_covered_all']??0)).'</strong> · Recherche oder kein Artikelthema <strong>'.esc_html((string)($stats['role_research_all']??0)).'</strong>.</p>';
        echo '<p><strong>Zusätzlicher technischer Kontextstatus:</strong> '.esc_html((string)($stats['context_open']??0)).' Themen nicht CURRENT. Diese Zahl <em>überschneidet sich</em> mit den drei Rollen und darf nicht addiert werden.</p>';
        echo '<p><em>Die Rollen stammen aus gespeicherten Entscheidungen. Ob die Gründe zutreffen, weist erst die vollständige Nur-Lese-Auswertung unten nach.</em></p></details>';
        $evidenceBootstrap=get_option(PSTE_OPTION_EXISTING_EVIDENCE_BOOTSTRAP,[]);
        if(is_array($evidenceBootstrap)&&($evidenceBootstrap['status']??'')==='PASS')echo '<p><strong>Geprüftes Bestandspotenzial:</strong> '.esc_html((string)($evidenceBootstrap['reanalyzed']??0)).' vorhandene Entscheidungen gezielt erneut geprüft · '.esc_html((string)($evidenceBootstrap['usable_after_reentry']??0)).' danach unmittelbar planbar · 0 Provider · kein Vollscan.</p>';
        echo '<p><button type="button" class="button button-primary" id="pste-production-auto-start"'.($psercReady?'':' disabled').'>Automatik starten / fortsetzen</button> <button type="button" class="button" id="pste-production-auto-stop" style="display:none">Anhalten</button></p>';
        echo '<div id="pste-production-auto-box" class="notice notice-info inline"><p><strong>Status:</strong> <span id="pste-production-auto-status">'.esc_html($queueStatus!==''?$queueStatus:'BEREIT').'</span><br><span id="pste-production-auto-detail">'.($queueProcessed>0?esc_html((string)$queueProcessed.($queueTotal>0?' / '.(string)$queueTotal:'')).' Bestandszeilen geprüft.':'Noch kein Lauf aktiv.').'</span></p></div>';
        echo '<form id="pste-production-export-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_export_planning_topics');echo '<input type="hidden" name="action" value="pste_export_planning_topics"></form>';
        echo '<p><button type="button" class="button button-primary" id="pste-production-download-ready" style="display:none">Produktionsdatei herunterladen</button></p>';
        echo '<div id="pste-production-ready-wrap" style="display:none;margin-top:14px"><h4 style="margin-bottom:6px">Freigegebene Artikel</h4><div style="overflow:auto"><table class="widefat striped"><thead><tr><th>Titel</th><th>Zielkeyword</th><th>Kategorie</th><th>Artikeltyp</th><th>Planplatz</th></tr></thead><tbody id="pste-production-ready-body"></tbody></table></div></div>';
        echo '</div>';
        self::renderCleanResetControl();
        echo '<div class="pste-box" style="margin:0"><h3>Kurzer Dienstweg</h3><p>Ein Thema pro Zeile. Das System erkennt den passenden internen Weg selbst. Keine neue DataForSEO-Recherche; Bestands-, Kategorie- und Dublettenprüfungen bleiben erhalten.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_shortpath_create_export');echo '<input type="hidden" name="action" value="pste_shortpath_create_export"><p><textarea name="manual_topics" rows="6" style="width:100%" placeholder="Ein Thema pro Zeile" required></textarea></p>';
        submit_button('Kurzen Dienstweg starten','secondary','submit',false);echo '</form></div></div>';
        $manualRun=sanitize_text_field((string)($_GET['pste_manual_k0_run']??''));
        // The automation and the short path are different runs. Never present an old
        // shortpath trace as a live automation event. Both are read-only projections.
        $auto=self::automationDiagnosticsSnapshot();
        echo '<details class="pste-box" style="margin-top:12px" open><summary><strong>Automatik – Bestands-/Fehlerprotokoll</strong></summary>';
        echo '<p>Status: <strong>'.esc_html((string)$auto['status']).'</strong> · Bestandszeilen: '.esc_html((string)$auto['processed']).' / '.esc_html((string)$auto['total']).' · Provideraufrufe in lokaler Prüfung: '.esc_html((string)$auto['local_provider_calls']).'</p>';
        if((string)$auto['audit_recheck_reason']!=='')echo '<p>Grund der lokalen Nachprüfung: <code>'.esc_html((string)$auto['audit_recheck_reason']).'</code></p>';
        if((string)$auto['queue_error']!=='')echo '<p>Warteschlangenfehler: <code>'.esc_html((string)$auto['queue_error']).'</code></p>';
        if((string)$auto['driver_error']!=='')echo '<p>Automatikfehler: <code>'.esc_html((string)$auto['driver_error']).'</code></p>';
        echo '<p>Dieses Protokoll zeigt die aktuelle Bestands-/Automatikprüfung, nicht den älteren kurzen Dienstweg.</p>';
        echo '<p>Alle gespeicherten Details stehen in der einzigen <strong>Gesamtdiagnose</strong> direkt darunter.</p></details>';
        self::renderEvidenceAuditControl();
        self::renderShortPathDiagnostics($manualRun);
        if($manualRun!==''){
            $run=PSTE_Repository::runByUuid($manualRun);
            if(!is_array($run)||(string)($run['seed']??'')!=='MANUAL_TOPIC_INTAKE'){
                echo '<div class="notice notice-error inline"><p>Kurzer Dienstweg: angeforderte Themenauswahl nicht gefunden.</p></div>';
            }elseif(!$psercReady){
                echo '<div class="notice notice-error inline"><p>Kurzer Dienstweg: Redaktionsplan-Compiler nicht aktiv.</p></div>';
            }else{
                echo '<div class="pste-box" style="margin-top:12px"><strong>Kurzer Dienstweg – ausschließlich gewählte Themen</strong><p id="pste-manual-k0-status">Vorhandene Themenauswahl. Hier wird kein neuer Redaktionsplanlauf gestartet.</p>';
                echo '<form id="pste-manual-k0-export" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
                wp_nonce_field('pste_export_planning_topics');
                echo '<input type="hidden" name="action" value="pste_export_planning_topics"><input type="hidden" name="pste_manual_k0_run" value="'.esc_attr($manualRun).'">';
                echo '<button type="submit" class="button" id="pste-manual-k0-download">Nur freigegebene ausgewählte Artikel herunterladen</button></form></div>';
                // Manual view is passive. Loading/refreshing must never start or advance the global PSERC plan.
                echo '<p><strong>Hinweis:</strong> Dieser Kurzweg startet keinen globalen Redaktionsplanlauf. Wenn noch kein passender freigegebener Planplatz existiert, erscheint ein konkreter Fehler im Diagnoseprotokoll.</p>';
            }
        }
        if(!$psercReady)echo '<div class="notice notice-error inline"><p><strong>Automatik blockiert:</strong> Redaktionsplan-Compiler fehlt oder ist nicht aktiv.</p></div>';
        $autostart=!empty($_GET['pste_autostart'])&&!empty($_GET['shortpath_started']);
        $cfg=wp_json_encode(['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('pste_production_auto_ajax'),'autostart'=>$autostart],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        echo '<script>(function(){"use strict";const cfg='.$cfg.',start=document.getElementById("pste-production-auto-start"),stop=document.getElementById("pste-production-auto-stop"),status=document.getElementById("pste-production-auto-status"),detail=document.getElementById("pste-production-auto-detail"),box=document.getElementById("pste-production-auto-box"),form=document.getElementById("pste-production-export-form"),download=document.getElementById("pste-production-download-ready"),readyWrap=document.getElementById("pste-production-ready-wrap"),readyBody=document.getElementById("pste-production-ready-body");if(!start||!status||!detail||!form)return;let running=false,lastReply=Date.now(),timer=null,runId=0;const fmt=s=>{s=Math.max(0,Number(s||0));const m=Math.floor(s/60),r=Math.floor(s%60);return m>0?m+"m "+r+"s":r+"s";};async function call(action,data){const c=new AbortController(),to=setTimeout(()=>c.abort(),30000);try{const body=new URLSearchParams(Object.assign({action:action,nonce:cfg.nonce},data||{})),r=await fetch(cfg.ajax_url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8","Accept":"application/json"},body:body.toString(),signal:c.signal}),raw=await r.text();let j;try{j=JSON.parse((raw||"").replace(/^\uFEFF/,"").trim());}catch(e){throw new Error("PSTE_AJAX_INVALID_JSON_HTTP_"+r.status);}if(!r.ok||!j.success)throw new Error((j.data&&j.data.error_code)||("HTTP_"+r.status));lastReply=Date.now();return j.data;}catch(e){if(e&&e.name==="AbortError")throw new Error("PSTE_SERVER_RESPONSE_TIMEOUT_30S");throw e;}finally{clearTimeout(to);}}function renderReady(items){if(!readyWrap||!readyBody)return;readyBody.replaceChildren();items=Array.isArray(items)?items:[];for(const item of items){const tr=document.createElement("tr");for(const key of ["title","target_keyword","category","article_type","plan_slot"]){const td=document.createElement("td");td.textContent=String(item&&item[key]||"");tr.appendChild(td);}readyBody.appendChild(tr);}readyWrap.style.display=items.length?"block":"none";}function render(x){x=x||{};const stage=String(x.stage||"BEREIT"),st=String(x.status||"BEREIT"),terminal=String(x.terminal||"");status.textContent=stage+" · "+st;let parts=[];if(x.progress_text)parts.push(String(x.progress_text));if(x.ready_count!==undefined)parts.push("freigegeben "+Number(x.ready_count||0));if(x.elapsed_seconds!==undefined&&Number(x.elapsed_seconds||0)>0)parts.push("Laufzeit "+fmt(x.elapsed_seconds));if(x.last_activity_age_seconds!==undefined&&Number(x.last_activity_age_seconds||0)>0)parts.push("letzte Aktivität vor "+fmt(x.last_activity_age_seconds));if(x.error_code)parts.push("Fehler "+String(x.error_code));detail.textContent=parts.join(" · ")||"Bereit.";box.className="notice "+(terminal==="READY"?"notice-success":(terminal==="BLOCKED"?"notice-error":"notice-info"))+" inline";renderReady(x.ready_items||[]);if(download)download.style.display=terminal==="READY"?"inline-block":"none";if(terminal==="READY")start.disabled=true;else if(!running)start.disabled=false;}function finish(terminal){running=false;start.disabled=terminal==="READY";stop.style.display="none";}async function loop(owned){if(!running||owned!==runId)return;try{const x=await call("pste_production_auto_step",{});if(!running||owned!==runId)return;render(x);if(x.terminal==="READY"){finish("READY");detail.textContent+=" · Produktionsdatei wird geladen …";form.submit();return;}if(["BLOCKED","NO_READY","CANCELLED"].includes(String(x.terminal||""))){finish(String(x.terminal||""));return;}timer=setTimeout(()=>loop(owned),1500);}catch(e){if(!running||owned!==runId)return;const reason=String(e&&e.message||"PSTE_PRODUCTION_FAILED");if((e instanceof TypeError||/Failed to fetch|NetworkError|PSTE_SERVER_RESPONSE_TIMEOUT_30S/i.test(reason))&&await recoverReadOnly(owned))return;finish("BLOCKED");box.className="notice notice-error inline";status.textContent="GESTOPPT";detail.textContent=reason;}}async function recoverReadOnly(owned){for(let attempt=0;attempt<3;attempt++){await new Promise(resolve=>setTimeout(resolve,(attempt+1)*1500));if(!running||owned!==runId)return true;try{const x=await call("pste_production_auto_status",{});if(!running||owned!==runId)return true;render(x);if(x.terminal==="READY"){finish("READY");form.submit();return true;}if(["BLOCKED","NO_READY","CANCELLED"].includes(String(x.terminal||""))){finish(String(x.terminal||""));return true;}timer=setTimeout(()=>loop(owned),1500);return true;}catch(error){/* Read-only retry; never replay an uncertain write request. */}}return false;}function begin(){if(running||start.disabled)return;const owned=++runId;running=true;lastReply=Date.now();start.disabled=true;stop.style.display="inline-block";loop(owned);}start.addEventListener("click",begin);if(download)download.addEventListener("click",()=>form.submit());stop.addEventListener("click",async()=>{const stopped=++runId;running=false;if(timer){clearTimeout(timer);timer=null;}try{const x=await call("pste_production_auto_cancel",{});if(stopped!==runId||running)return;render(x);}catch(e){if(stopped!==runId||running)return;status.textContent="ANGEHALTEN";detail.textContent=(e&&e.message)||"Fortsetzbar.";}if(stopped===runId&&!running)finish("PAUSED");});async function initial(){const initialRun=runId;try{const x=await call("pste_production_auto_status",{});if(initialRun!==runId)return;render(x);if(cfg.autostart){try{const u=new URL(window.location.href);u.searchParams.delete("pste_autostart");u.searchParams.delete("shortpath_started");history.replaceState({},"",u.toString());}catch(e){}if(!(["READY","NO_READY","BLOCKED"].includes(String(x.terminal||""))))begin();}}catch(e){/* passive page remains usable */}}initial();setInterval(()=>{if(running&&Date.now()-lastReply>120000){running=false;finish("BLOCKED");box.className="notice notice-error inline";status.textContent="HÄNGT";detail.textContent="Seit mehr als 120 Sekunden keine Serverantwort. Der gespeicherte Stand bleibt erhalten; mit demselben Knopf fortsetzen.";}},5000);})();</script>';
        echo '</section>';
    }

    private static function renderReview(): void {
        $rawFilter=sanitize_text_field((string)($_GET['pool_filter']??'attention'));$lowerFilter=strtolower($rawFilter);$filter=in_array($lowerFilter,['attention','all','traffic_red','traffic_yellow','traffic_green'],true)?$lowerFilter:strtoupper(sanitize_key($rawFilter));$allowed=['attention','all','traffic_red','traffic_yellow','traffic_green','PASS','AUTO_RESOLVED','REVIEW_REQUIRED','PROVISIONAL_ACCEPTED','PROVISIONAL_REASSIGN','DISCOVERY_ONLY','BLOCKED_FOR_CATEGORY','APPROVED','REASSIGNED','REJECTED'];if(!in_array($filter,$allowed,true))$filter='attention';$search=sanitize_text_field((string)($_GET['pool_search']??''));$areaFilter=strtoupper(sanitize_key((string)($_GET['pool_area']??'')));if(!in_array($areaFilter,['FACH','MAGAZIN','UNDECIDED'],true))$areaFilter='';$page=self::reviewReadPage($filter,$search,$areaFilter);$rows=$page['items'];$stats=PSTE_Repository::adminTopicPoolStats();$context=PSTE_Context_Refresh::status();
        echo '<h2>Portalweite Themenprüfung</h2><p><strong>Die Ampel zeigt ausschließlich den menschlichen Prüfbedarf.</strong> Rolle, Planungseignung, Kategorie, Artikeltyp und Priorität sind davon getrennt.</p>';
        if((string)($context['status']??'NOT_STARTED')!=='COMPLETE'){
            $contextError=(string)($context['error_code']??'');
            echo '<div class="notice notice-error inline"><p><strong>Systemprüfung nicht abgeschlossen:</strong> Portalabgleich '.esc_html((string)($context['status']??'NOT_STARTED')).' ('.esc_html((string)($context['processed']??0)).' von '.esc_html((string)($context['total']??0)).'). Planung bleibt fail-closed blockiert. Die Themenampel zeigt weiterhin nur den fachlichen Prüfbedarf.';
            if($contextError!=='')echo '<br><strong>Fehlercode:</strong> <code>'.esc_html($contextError).'</code>';
            echo '</p></div>';
        }
        // The existing title workshop is an export / language-edit / title-only import workflow.
        // PHP does not generate, repair or approve titles. This is not a production handoff.
        PSTE_Mini_Workflow::renderKeywords();
        echo '<section class="pste-box"><h3>Titelwerkstatt – nur Sprachsystem formuliert</h3>';
        echo '<p>Offene Themen für die Sprachwerkstatt als JSON exportieren, Titel außerhalb von PHP formulieren und dieselbe JSON-Datei zurückimportieren. Nur <code>title</code>, <code>approved</code> und optional <code>editorial_review</code> bearbeiten. Eine Titelkorrektur vergibt keine Kategorie, keinen Planplatz und keine Produktionsfreigabe.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline-block;margin-right:16px">';wp_nonce_field('pste_title_desk_export');echo '<input type="hidden" name="action" value="pste_title_desk_export"><label>Ab Datensatz-ID <input name="cursor_id" type="number" min="0" step="1" value="0" style="width:105px"></label> ';submit_button('Titel zur Sprachwerkstatt exportieren (bis 100)','secondary','submit',false);echo '</form>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" enctype="multipart/form-data" style="display:inline-block">';wp_nonce_field('pste_title_desk_import');echo '<input type="hidden" name="action" value="pste_title_desk_import"><label>Sprachtitel-JSON <input name="title_desk_json" type="file" accept=".json,application/json" required></label> ';submit_button('Nur geprüfte Titel importieren','secondary','submit',false);echo '</form>';
        $titleImport=get_transient('pste_title_desk_last_import');
        if(is_array($titleImport)){
            echo '<p><strong>Titelimport:</strong> '.esc_html((string)(int)($titleImport['saved']??0)).' gespeichert; '
                .esc_html((string)(int)($titleImport['needs_language_correction']??0))
                .' zur Korrektur in derselben Sprachwerkstatt. Bereits gespeicherte Titel bleiben erhalten.</p>';
        }
        $titleResume=get_transient('pste_title_desk_reentry_report');
        if(is_array($titleResume)&&(int)($titleResume['scheduled']??0)>0){
            echo '<p><small>Gezielte Weitergabe nach Titelimport: '.esc_html((string)(int)($titleResume['processed']??0))
                .' von '.esc_html((string)(int)$titleResume['scheduled']).' Themen bearbeitet; '
                .esc_html((string)(int)($titleResume['held']??0)).' zurückgestellt. Keine neue Keywordrecherche.</small></p>';
            $jobState=get_option(self::TITLE_DESK_REENTRY_STATE,[]);
            if(is_array($jobState)&&($jobState['status']??'')==='RUNNING'&&($jobState['last_error']??'')!=='')
                echo '<p><small><strong>Automatische Fortsetzung wartet:</strong> '.esc_html((string)$jobState['last_error']).'. Der Auftrag bleibt erhalten.</small></p>';
            if(!empty($titleResume['blocked'])){
                $last=end($titleResume['blocked']);
                echo '<p><small><strong>Letzte Rückstellung:</strong> '.esc_html((string)($last['error_code']??''))
                    .' ('.esc_html((string)($last['pool_key']??'')).')</small></p>';
                echo '<p><small><strong>Einzelgründe je Thema:</strong> In der <em>Gesamtdiagnose</em>, Abschnitt <code>workflow_status.sections.title_desk_reentry</code>. Die Prüfung liest nur vorhandene Entscheidungsbelege.</small></p>';
            }
        }
        if(is_array($titleResume)&&(int)($titleResume['held']??0)>0){
            try{
                $reasons=self::titleDeskReentryDiagnostics();
                if(!empty($reasons['hold_reason_counts'])){
                    echo '<p><strong>Dokumentierte Rückstellungsgründe:</strong></p><ul>';
                    foreach(array_slice((array)$reasons['hold_reason_counts'],0,5,true) as $code=>$number){
                        echo '<li>'.esc_html((string)$code).': '.esc_html((string)(int)$number).' Thema/Themen</li>';
                    }
                    echo '</ul><p><small>Nur bisher gespeicherte Entscheidungen. Vollständige Einzelangaben im Workflow-Download.</small></p>';
                }else echo '<p><small>Keine Einzelgründe gespeichert. Keine neue Entscheidung durch die Anzeige.</small></p>';
            }catch(Throwable $ignored){echo '<p><small>Rückstellungsgründe gerade nicht lesbar; bisherige Entscheidungen bleiben unverändert.</small></p>';}
        }
        echo '<p><small>Der JSON-Export enthält <code>next_cursor</code> für den nächsten Stapel. Ein unvollständiger Artikel bleibt im bisherigen Klärstatus. K0 und PSERC erhalten aus diesem Schritt keine neue Freigabe.</small></p></section>';
        echo '<div class="pste-grid">';self::metric('Globale Themen',$stats['TOTAL']??0);self::metric('Fundstellen',$stats['OCCURRENCES']??0);self::metric('Rot',$stats['RED']??0);self::metric('Gelb',$stats['YELLOW']??0);self::metric('Merge-Kandidaten',$stats['MERGE_CANDIDATES']??0);echo '</div>';
        echo '<form method="get" class="pste-box"><input type="hidden" name="page" value="'.esc_attr(self::TABS['review']['slug']).'"><label>Ansicht <select name="pool_filter">';$labels=['attention'=>'Rot und Gelb','traffic_red'=>'Nur Rot','traffic_yellow'=>'Nur Gelb','traffic_green'=>'Nur Grün','all'=>'Alle globalen Themen','PASS'=>'Automatisch eingeordnete Artikelthemen','AUTO_RESOLVED'=>'Historisch automatisch eingeordnete Themen','DISCOVERY_ONLY'=>'Recherchebegriffe/Oberbegriffe','BLOCKED_FOR_CATEGORY'=>'Zwischengespeichert, blockiert oder bereits abgedeckt','APPROVED'=>'Manuell freigegeben','REASSIGNED'=>'Manuell zugeordnet','REJECTED'=>'Verworfen'];foreach($labels as $value=>$label)echo '<option value="'.esc_attr($value).'" '.selected($filter,$value,false).'>'.esc_html($label).'</option>';echo '</select></label> <label>Bereich <select name="pool_area">';foreach([''=>'Alle Bereiche','FACH'=>'Hauptnavigation','MAGAZIN'=>'Magazin','UNDECIDED'=>'Noch ungeklärt'] as $v=>$label)echo '<option value="'.esc_attr($v).'" '.selected($areaFilter,$v,false).'>'.esc_html($label).'</option>';echo '</select></label> <label>Suche <input type="search" name="pool_search" value="'.esc_attr($search).'" placeholder="Thema oder Kategorie"></label> ';submit_button('Ansicht filtern','secondary','submit',false);echo '</form>';
        echo '<table class="widefat striped pste-table pste-review-table"><thead><tr><th>Ampel</th><th>Globales Thema</th><th>Rolle</th><th>Zielkategorie</th><th>Artikeltyp</th><th>Planung</th><th>Prüfgrund</th><th>Aktion</th></tr></thead><tbody>';
        foreach($rows as $c){$light=(array)($c['traffic_light']??PSTE_Repository::trafficLightForStatus((string)($c['pool_status']??'REVIEW_REQUIRED'),(string)($c['context_state']??'PENDING')));$role=(string)($c['topic_role']??'RESEARCH_KEYWORD');$planning=(string)($c['planning_suitability']??'BLOCKED');$assign=self::primaryAssignment($c);$editorialArea=self::currentEditorialArea($c);$manualEditorialArea=self::manualReviewArea($c);$hard=PSTE_Topic_Policy::presentHardCodes($c);$nonOver=PSTE_Topic_Policy::presentNonOverridableCodes($c);$reason=self::humanReviewReason($c);
            echo '<tr><td><span class="pste-light pste-light-'.esc_attr(strtolower((string)$light['code'])).'">'.esc_html((string)$light['label']).'</span><br><small>'.esc_html((string)$light['meaning']).'</small></td>';
            echo '<td><strong>'.esc_html(PSTE_Editorializer::displayTitle($c)).'</strong><br><small>ID: '.esc_html((string)$c['pool_key']).'</small><details><summary>Technische Details</summary><p><strong>Fundstellen:</strong> '.esc_html((string)count((array)($c['occurrences']??[]))).'<br><strong>Reason Codes:</strong> '.esc_html(implode(', ',(array)($c['reason_codes']??[]))).'<br><strong>Kontext:</strong> '.esc_html((string)($c['context_state']??'PENDING')).'</p></details>';
            echo '</td>';
            $system=PSTE_Topic_Policy::systemState((string)($c['context_state']??'PENDING'));
            $displayType=(string)($assign['article_type']??($c['proposed_article_type']??'—'));$manualCandidateType=(string)($c['manual_candidate_article_type']??'');
            echo '<td>'.esc_html(PSTE_Topic_Policy::roleLabel($role)).'</td><td>'.esc_html((string)($assign['category_name']??'—')).'<br><small>Automatischer Bereich: '.esc_html(self::editorialAreaLabel($editorialArea)).'</small>';if($manualEditorialArea!=='')echo '<br><small>Manuell vorgemerkt: <strong>'.esc_html(self::editorialAreaLabel($manualEditorialArea)).'</strong> (keine Produktionsfreigabe)</small>';if(strpos((string)($c['manual_note']??''),'Bereichsvormerkung:')===0||strpos((string)($c['manual_note']??''),'Bereich händisch geprüft:')===0)echo '<br><small><strong>'.esc_html((string)($c['manual_note']??'')).'</strong></small>';echo '</td><td>'.esc_html($displayType);
            if($manualCandidateType!=='')echo '<br><small>Manuelle Kandidatenart: <strong>'.esc_html($manualCandidateType).'</strong></small>';
            echo '<details style="margin-top:6px"><summary style="cursor:pointer">Beitragsart korrigieren</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:6px">';wp_nonce_field('pste_set_candidate_type');echo '<input type="hidden" name="action" value="pste_set_candidate_type"><input type="hidden" name="pool_key" value="'.esc_attr((string)$c['pool_key']).'"><select name="candidate_article_type"><option value="">Automatik</option><option value="Produktwahl"'.selected($manualCandidateType,'Produktwahl',false).'>Produktwahl</option>';foreach(self::availableArticleTypes() as $candidateType)echo '<option value="'.esc_attr($candidateType).'"'.selected($manualCandidateType,$candidateType,false).'>'.esc_html($candidateType).'</option>';echo '</select><br><input type="text" name="review_note" class="regular-text" placeholder="Optionaler Hinweis">';submit_button('Korrektur speichern','secondary','submit',false);echo '</form></details></td><td><strong>'.esc_html(PSTE_Topic_Policy::planningLabel($planning)).'</strong><br><small>Systemprüfung: '.esc_html((string)$system['label']).'</small></td><td>'.esc_html($reason).'</td><td>';
            if(!in_array((string)($c['context_state']??'PENDING'),['CURRENT','NOT_REQUIRED'],true)){echo '<em>Keine manuelle Entscheidung möglich. Zuerst Portalabgleich abschließen.</em>';}elseif((string)$light['code']==='GREEN'&&(string)($c['manual_status']??'')!=='REASSIGNED'&&empty($c['manual_editorial_resolution'])){echo '<em>Keine Aktion nötig.</em>';}else{echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_review_candidate');echo '<input type="hidden" name="action" value="pste_review_candidate"><input type="hidden" name="pool_key" value="'.esc_attr((string)$c['pool_key']).'"><select name="review_status"><option value="AUTO">Keine Änderung – Automatik beibehalten</option>';
                if(!$nonOver)echo '<option value="APPROVED">Als Thema freigeben</option>';echo '<option value="REVIEW_REQUIRED">Weiter offen lassen</option><option value="BLOCKED_FOR_CATEGORY">Als bereits abgedeckt/blockiert markieren</option><option value="DISCOVERY_ONLY">Nur als Recherchebegriff behalten</option><option value="REASSIGNED">Anderer Kategorie zuordnen (bisherig)</option><option value="ROUTE_FACH">Grenzfall: Hauptnavigation wählen</option><option value="ROUTE_MAGAZIN">Grenzfall: Magazin wählen</option><option value="ROUTE_REVIEW">Grenzfall: im Redaktionsbüro lassen</option><option value="REJECTED">Endgültig verwerfen</option></select><br><input list="pste-global-category-list" name="target_category_name" class="regular-text" placeholder="Zielkategorie (nur Umordnung)"><br><select name="target_article_type"><option value="">Artikeltyp aus Zielkategorie</option>';foreach(self::availableArticleTypes() as $type)echo '<option value="'.esc_attr($type).'">'.esc_html($type).'</option>';echo '</select><br><small>Grenzfall: Bereich auswählen und, falls vorhanden, eine bestehende Zielkategorie eintragen. Ohne passende Kategorie bleibt das Thema im Redaktionsbüro. Keine automatische Produktionsfreigabe.</small><br><input type="text" name="review_note" class="regular-text" placeholder="Begründung">';if($hard&&!$nonOver)echo '<p class="pste-hard-warning"><label><input type="checkbox" name="confirm_hard_override" value="1"> Harte Sperre bewusst übersteuern</label><br><small>Nur mit Begründung. Betroffene Regeln: '.esc_html(implode(', ',$hard)).'</small></p>';if($nonOver)echo '<p class="pste-hard-warning"><strong>Nicht übersteuerbare technische Sperre:</strong> '.esc_html(implode(', ',$nonOver)).'</p>';submit_button('Entscheidung speichern','secondary','submit',false);echo '</form>';}
            echo '</td></tr>';
        }
        if(!$rows)self::emptyRow(8,'In diesem Abschnitt keine passenden Themen. Weitere Themen gegebenenfalls auf der nächsten Seite.');echo '</tbody></table>';if($page['next_token']!==''){ $url=add_query_arg(['page'=>self::TABS['review']['slug'],'pool_filter'=>$filter,'pool_area'=>$areaFilter,'pool_search'=>$search,'pool_cursor'=>$page['next_token']],admin_url('admin.php'));echo '<p><a class="button" href="'.esc_url($url).'">Weitere Themen anzeigen</a></p>'; }self::globalCategoryDatalist();
    
        $showSandbox=((string)($_GET['sandbox_view']??''))==='1';
        echo '<hr style="margin:28px 0"><h2>Offene Rest- und Sandboxfälle</h2>';
        if($showSandbox){self::renderSandboxReviewSection();}
        else echo '<p>Nur laden, wenn tatsächlich ein fail-closed Restfall geprüft werden muss. Dadurch bleibt die normale Themenprüfung datenbank- und performance-schonend.</p><p><a class="button" href="'.esc_url(admin_url('admin.php?page='.self::TABS['review']['slug'].'&sandbox_view=1')).'">Restfälle prüfen</a></p>';
    }

    /** Read only the already-decided area from the existing current metadata path. */
    private static function currentEditorialArea(array $candidate): string {
        $path=is_array($candidate['normal_metadata_path']??null)?$candidate['normal_metadata_path']:[];
        if(($path['contract']??'')!==PSTE_Normal_Metadata_Path::CONTRACT
            ||!PSTE_Normal_Metadata_Path::payloadMatchesNormalPath($candidate,$path))return 'UNDECIDED';
        $area=(string)($path['editorial_area']??'UNDECIDED');
        return in_array($area,['FACH','MAGAZIN'],true)?$area:'UNDECIDED';
    }

    /** A saved human area choice is a review label, never automatic or production authority. */
    private static function manualReviewArea(array $candidate): string {
        $persisted=(array)($candidate['manual_editorial_resolution']??[]);
        if(($persisted['contract']??'')==='PSTE_AUTHENTICATED_EDITOR_RESOLUTION_V1'
            &&in_array((string)($persisted['area']??''),['FACH','MAGAZIN'],true))
            return (string)$persisted['area'];
        if(!in_array((string)($candidate['manual_status']??''),['REASSIGNED','REVIEW_REQUIRED'],true))return '';
        $note=(string)($candidate['manual_note']??'');
        foreach(['Bereichsvormerkung: ','Bereich händisch geprüft: '] as $prefix){
            if(!str_starts_with($note,$prefix))continue;
            $rest=substr($note,strlen($prefix));
            if(str_starts_with($rest,'Hauptnavigation.'))return 'FACH';
            if(str_starts_with($rest,'Magazin.'))return 'MAGAZIN';
            if(str_starts_with($rest,'noch ungeklärt.'))return 'UNDECIDED';
        }
        return '';
    }

    /** One review-room filter: explicit human choice first; otherwise the original auto owner. */
    private static function reviewEditorialArea(array $candidate): string {
        $manual=self::manualReviewArea($candidate);
        return $manual!==''?$manual:self::currentEditorialArea($candidate);
    }

    private static function editorialAreaLabel(string $area): string {
        return $area==='FACH'?'Hauptnavigation':($area==='MAGAZIN'?'Magazin':'Noch ungeklärt');
    }

    private static function primaryAssignment(array $candidate): array {
        // Current normal-path metadata is authoritative for the UI. Historical assignments remain
        // evidence, but may not repaint a freshly reclassified Journal item as its former FAQ type.
        $currentCategory=trim((string)($candidate['target_category_name']??''));$currentType=trim((string)($candidate['proposed_article_type']??''));
        if($currentCategory!==''&&$currentType!=='')return ['category_name'=>$currentCategory,'article_type'=>$currentType,'assignment_status'=>'CURRENT_METADATA','confidence'=>1.0];
        // A bound current area/category decision has priority over historical assignment rows.
        // A missing leaf must appear as missing in the ONE review room, not as the old category.
        $path=is_array($candidate['normal_metadata_path']??null)?$candidate['normal_metadata_path']:[];
        if($path){
            // A stale or tampered path cannot authorize a historical category either.
            if(($path['contract']??'')!==PSTE_Normal_Metadata_Path::CONTRACT
                ||!PSTE_Normal_Metadata_Path::payloadMatchesNormalPath($candidate,$path))
                return ['category_name'=>'—','article_type'=>'—','assignment_status'=>'CURRENT_METADATA_UNVERIFIED','confidence'=>0.0];
            return ['category_name'=>$currentCategory!==''?$currentCategory:'—',
                'article_type'=>$currentType!==''?$currentType:(string)($path['article_type']??'—'),
                'assignment_status'=>'CURRENT_UNASSIGNED','confidence'=>0.0];
        }
        $assignments=(array)($candidate['assignments']??[]);$rank=['CONFIRMED'=>0,'PROVISIONAL_ACCEPTED'=>1,'OBSERVED'=>2,'SUGGESTED'=>3,'EXISTING'=>4,'PLANNED'=>5];usort($assignments,static fn($a,$b)=>[$rank[(string)($a['assignment_status']??'')]??9,-(float)($a['confidence']??0)]<=>[$rank[(string)($b['assignment_status']??'')]??9,-(float)($b['confidence']??0)]);return $assignments[0]??['category_name'=>'','article_type'=>''];
    }

    /** Existing read-only topic-page reader, bounded even when 4488+ topics are stored. */
    private static function reviewReadPage(string $filter,string $search,string $areaFilter=''): array {
        $raw=isset($_GET['pool_cursor'])?(string)$_GET['pool_cursor']:'';
        $cursor=null;
        if($raw!==''){
            if(strlen($raw)>256||!preg_match('/^[A-Za-z0-9_-]+$/D',$raw))throw new RuntimeException('PSTE_REVIEW_CURSOR_INVALID');
            $decoded=base64_decode(strtr($raw,'-_','+/'),true);
            $c=is_string($decoded)?json_decode($decoded,true):null;
            if(!is_array($c)||!is_string($c['last_seen_at']??null)||strlen($c['last_seen_at'])>80||($c['last_seen_at']??'')===''||!is_int($c['id']??null)||$c['id']<=0)throw new RuntimeException('PSTE_REVIEW_CURSOR_INVALID');
            $cursor=['last_seen_at'=>$c['last_seen_at'],'id'=>$c['id']];
        }
        $found=[];$complete=false;$searchNorm=PSTE_Normalizer::exactTopicIdentityText($search);
        // Eight batches of ten at most, only one bounded relation batch alive at a time.
        // The last page is consumed fully before its cursor is used, so no topic is skipped.
        for($i=0;$i<8;$i++){
            $part=PSTE_Repository::adminTopicPoolPage($cursor,10,$search);
            foreach((array)($part['items']??[]) as $candidate){
                $status=(string)($candidate['pool_status']??'REVIEW_REQUIRED');
                $light=(string)($candidate['traffic_light']['code']??'RED');
                if($filter==='attention'&&!in_array($light,['RED','YELLOW'],true))continue;
                if($filter==='traffic_red'&&$light!=='RED')continue;
                if($filter==='traffic_yellow'&&$light!=='YELLOW')continue;
                if($filter==='traffic_green'&&$light!=='GREEN')continue;
                if($filter==='REASSIGNED'){
                    if($status!=='REASSIGNED'
                        &&(string)($candidate['manual_editorial_resolution']['contract']??'')!=='PSTE_AUTHENTICATED_EDITOR_RESOLUTION_V1')continue;
                }elseif(!in_array($filter,['all','attention','traffic_red','traffic_yellow','traffic_green'],true)&&$status!==$filter)continue;
                if($areaFilter!==''&&self::reviewEditorialArea($candidate)!==$areaFilter)continue;
                if($searchNorm!==''&&!str_contains(PSTE_Normalizer::exactTopicIdentityText(PSTE_Editorializer::displayTitle($candidate).' '.implode(' ',array_map(static fn($c)=>(string)($c['category_name']??''),(array)($candidate['found_categories']??[])))),$searchNorm))continue;
                $found[]=$candidate;
            }
            $complete=!empty($part['complete']);
            $cursor=is_array($part['next_cursor']??null)?$part['next_cursor']:null;
            unset($part);
            if($complete||!is_array($cursor)||count($found)>=20)break;
        }
        $next='';
        if(!$complete&&is_array($cursor)&&($cursor['last_seen_at']??'')!==''){
            $next=rtrim(strtr(base64_encode(wp_json_encode(['last_seen_at'=>(string)$cursor['last_seen_at'],'id'=>(int)$cursor['id']],JSON_UNESCAPED_SLASHES)),'+/','-_'),'=');
        }
        return ['items'=>$found,'next_token'=>$next,'complete'=>$complete,'write_attempted'=>false];
    }

    private static function humanReviewReason(array $candidate): string {
        $path=is_array($candidate['normal_metadata_path']??null)?$candidate['normal_metadata_path']:[];
        if(!empty($path['category_backlog_required'])
            &&(string)($path['worker_flow']['storage']??'')==='CATEGORY_ROOM_TOPIC_POOL')
            return 'Redaktionsbüro: Fachkategorie oder Magazin prüfen; sonst offen behalten';
        $codes=(array)($candidate['reason_codes']??[]);$labels=['FAQ_NATURAL_QUESTION_WITHOUT_PUNCTUATION'=>'Natürliche Frage ohne Fragezeichen erkannt','FAQ_RECOMMENDATION_OR_SUPERLATIVE_REVIEW'=>'Empfehlungs-/Vergleichsabsicht erkannt','CONFLICTING_TARGET_ASSIGNMENTS'=>'Mehrere gleich plausible Zielkategorien','ANSWER_EQUIVALENT_EXISTING'=>'Inhalt vermutlich bereits vorhanden','ANSWER_EQUIVALENT_PLANNED'=>'Thema vermutlich bereits geplant','CATEGORY_HEAD_INTENT_COLLISION'=>'Oberbegriff wird bereits durch die Kategorie abgedeckt','STALE_YEAR_SPECIFIC_QUERY'=>'Veralteter Jahresbegriff','CONTEXT_REFRESH_FAILED'=>'Technischer Portalabgleich fehlgeschlagen','CONTEXT_REFRESH_STALE'=>'Bestand änderte sich während des Abgleichs','GLOBAL_IDENTITY_MIGRATION_CONFLICT'=>'Widersprüchliche Altentscheidungen','MERGE_CANDIDATE_REVIEW_REQUIRED'=>'Mögliche Themenzusammenführung prüfen','EXACT_EDITORIAL_INTENT_VARIANT'=>'Gleiche redaktionelle Suchintention bereits als Hauptthema vorhanden','PSTE_PORTAL_RELEVANCE_PROVEN_FAMILY_ASSIGNMENT_NOT_PROVEN'=>'Portal relevant; interne Zuordnung und redaktionelle Umformulierung ausstehend','PSTE_SANDBOX_INTERNAL_CLARIFICATION_REQUIRED'=>'Zur internen Zuordnung und redaktionellen Umformulierung zwischengespeichert','EDITORIAL_TARGET_CATEGORY_MISSING'=>'Passende vorhandene Zielkategorie fehlt'];foreach($labels as $code=>$label)if(in_array($code,$codes,true))return $label;$status=(string)($candidate['pool_status']??'');if($status==='PROVISIONAL_REASSIGN')return 'Eindeutige Umordnung vorläufig angenommen';if($status==='PROVISIONAL_ACCEPTED')return 'Plausible automatische Einordnung';if($status==='DISCOVERY_ONLY')return 'Kein eigenständiges Produktionsthema';if($status==='BLOCKED_FOR_CATEGORY')return 'Bereits abgedeckt oder für diese Zuordnung ungeeignet';return 'Automatisch eindeutig eingeordnet';
    }

    private static function renderCoverage(): void {$rows=PSTE_Analytics::coverage();echo '<h2>Thematische Abdeckung</h2><p><strong>Abdeckung</strong> vergleicht den Anteil vorhandener Beiträge mit dem durch GSC-Impressionen und bestätigte Keywordnachfrage abgeleiteten Bedarfsanteil. Ohne belastbare Nachfragedaten wird nicht geraten, sondern „Daten fehlen“ angezeigt.</p>';echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_save_category_weights');echo '<input type="hidden" name="action" value="pste_save_category_weights"><table class="widefat striped pste-table"><thead><tr><th>Themenfamilie</th><th>Beiträge</th><th>PASS geplant</th><th>GSC-Impressionen</th><th>Keywordvolumen</th><th>Bedarfsanteil</th><th>Inhaltsanteil</th><th>Abdeckung</th><th>Status</th><th>Strategie 0–10</th></tr></thead><tbody>';foreach($rows as $r)echo '<tr><td>'.esc_html($r['category_name']).'</td><td>'.esc_html((string)$r['published']).'</td><td>'.esc_html((string)$r['planned_pass']).'</td><td>'.esc_html(number_format((float)$r['gsc_impressions'],0,',','.')).'</td><td>'.esc_html(number_format((float)$r['candidate_volume'],0,',','.')).'</td><td>'.esc_html(number_format((float)$r['demand_share_pct'],2,',','.').' %').'</td><td>'.esc_html(number_format((float)$r['content_share_pct'],2,',','.').' %').'</td><td>'.esc_html($r['coverage_pct']===null?'—':number_format((float)$r['coverage_pct'],1,',','.').' %').'</td><td>'.self::badge($r['state'],self::coverageLabel($r['state'])).'</td><td><input style="width:70px" type="number" min="0" max="10" step="0.5" name="weights['.esc_attr((string)$r['category_id']).']" value="'.esc_attr((string)$r['strategic_weight']).'"></td></tr>';if(!$rows)self::emptyRow(10,'Gesamtbestand noch nicht erfasst.');echo '</tbody></table>';submit_button('Strategische Gewichtung speichern','secondary');echo '</form><p><strong>Yoast-Hinweis:</strong> Die Engine ändert Yoast niemals automatisch. Bei starken Unter-/Überdeckungen zeigt sie lediglich, wo Kategorie-Indexierung, SEO-Titel, interne Schwerpunktsetzung oder Zusammenlegung redaktionell geprüft werden sollten.</p>';}

    private static function renderSources(): void {
        $data=PSTE_Credentials::status();$dataConnection=PSTE_Credentials::connectionStatus();$gsc=PSTE_GSC_Credentials::status();$sites=get_option(PSTE_OPTION_GSC_SITES_CACHE,[]);$selected=(string)get_option(PSTE_OPTION_GSC_SELECTED_PROPERTY,'');$lastSync=get_option(PSTE_OPTION_GSC_LAST_SYNC,[]);
        echo '<h2>Datenquellen</h2><div class="notice notice-info inline"><p><strong>Klare Aufgabe:</strong> DataForSEO liefert Longtail-Vorschläge, verwandte Suchbegriffe, Keyword-Ideen und jeweils das exakt zugehörige Suchvolumen. Die Engine verwaltet die Suchbegriffe und vorhandenen Kategorien. Neue Artikeltitel werden ausschließlich durch die Sprachwerkstatt formuliert und anschließend importiert. Im normalen Rechercheworkflow gibt es keine Google-Live-SERP-Prüfung. Reale Google-SERPs werden ausschließlich im isolierten Semantic-Sandbox-Review verwendet und haben keinen direkten Produktionspfad.</p></div><div class="pste-two"><section>';
        self::connectionPanel('DataForSEO',$dataConnection,'Longtail-Vorschläge, verwandte Keywords und Suchvolumen');
        if (!empty($data['error_code'])) {
            echo '<div class="notice notice-error inline"><p><strong>Gespeicherter DataForSEO-Zugang nicht lesbar.</strong> Alte verschlüsselte Werte bleiben unverändert. Zur sicheren Wiederherstellung entweder einen vollständigen Base64-Zugangscode oder <strong>API Login UND API Password</strong> eingeben und speichern. Einzelne Felder reichen hier nicht. Die gespeicherten SEO-Themen und Redaktionspläne werden dabei nicht verändert.</p></div>';
        }
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_save_credentials');echo '<input type="hidden" name="action" value="pste_save_credentials"><table class="form-table"><tr><th>API-Zugangscode (Base64)</th><td><input class="large-text code" type="password" name="api_credentials_base64" autocomplete="new-password" placeholder="Base64-Code aus der DataForSEO-E-Mail einfügen"><p class="description">Der Base64-Code wird nicht gespeichert.</p></td></tr><tr><th colspan="2"><hr><span style="font-weight:400">Alternativ getrennt eingeben:</span></th></tr><tr><th>API Login</th><td><input class="regular-text" name="api_login" autocomplete="off" placeholder="'.esc_attr($data['configured']?'gespeichert: '.$data['masked_login']:'API Login eingeben').'"><p class="description">'.(!empty($data['error_code'])?'Bei nicht lesbarem Zugang Login und Passwort vollständig neu eingeben.':'Leer lassen = gespeichert behalten.').'</p></td></tr><tr><th>API Password</th><td><input class="regular-text" type="password" name="api_password" autocomplete="new-password" placeholder="'.esc_attr($data['configured']?'gespeichert – leer lassen':'API Password eingeben').'"></td></tr></table>';submit_button('DataForSEO-Zugang speichern');echo '</form>';if($data['configured'])self::actionForm('pste_connection_test','pste_connection_test','Verbindung kostenfrei prüfen');echo '</section><section>';
        self::connectionPanel('Google Search Console',$gsc,'Optional: reale eigene Suchanfragen und Impressionen');
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_save_gsc_client');echo '<input type="hidden" name="action" value="pste_save_gsc_client"><table class="form-table"><tr><th>Google OAuth Client ID</th><td><input class="regular-text" name="client_id" autocomplete="off" placeholder="'.esc_attr($gsc['configured']?'gespeichert: '.$gsc['masked_client_id']:'Client ID eingeben').'"></td></tr><tr><th>Google OAuth Client Secret</th><td><input class="regular-text" type="password" name="client_secret" autocomplete="new-password" placeholder="'.esc_attr($gsc['configured']?'gespeichert – leer lassen':'Client Secret eingeben').'"></td></tr><tr><th>Authorized redirect URI</th><td><input class="large-text code" readonly value="'.esc_attr($gsc['redirect_uri']).'"></td></tr></table>';submit_button('Google-Zugang speichern');echo '</form>';
        if($gsc['configured']&&$gsc['status']!=='CONNECTED')self::actionForm('pste_gsc_connect','pste_gsc_connect','Mit Google verbinden','primary');
        if($gsc['status']==='CONNECTED'){self::actionForm('pste_gsc_test','pste_gsc_test','Verbindung und Properties neu prüfen');self::actionForm('pste_gsc_disconnect','pste_gsc_disconnect','Google-Verbindung trennen');}
        echo '</section></div>';
        if($gsc['status']==='CONNECTED'){
            echo '<section class="pste-box"><h3>Search-Console-Property und Datenabruf</h3><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_gsc_save_property');echo '<input type="hidden" name="action" value="pste_gsc_save_property"><select name="property_url" required><option value="">Property auswählen</option>';
            foreach(($sites['items']??[]) as $site){$url=(string)$site['site_url'];echo '<option value="'.esc_attr($url).'" '.selected($selected,$url,false).'>'.esc_html($url.' · '.$site['permission_level']).'</option>';}
            echo '</select> ';submit_button('Property speichern','secondary','submit',false);echo '</form>';
            if($selected!==''){self::actionForm('pste_gsc_sync','pste_gsc_sync','Search-Console-Daten jetzt read-only abrufen','primary');if(!empty($lastSync['synced_at_utc']))echo '<p>Letzter Abruf: '.esc_html((string)$lastSync['synced_at_utc']).' · '.esc_html((string)($lastSync['saved_rows']??0)).' gespeicherte Zeilen</p>';}
            echo '</section>';
        }
        echo '<section class="pste-box"><h3>Manueller Search-Console-CSV-Fallback</h3><form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_import_gsc');echo '<input type="hidden" name="action" value="pste_import_gsc"><input type="file" name="gsc_csv" accept=".csv,text/csv" required> ';submit_button('CSV read-only importieren','secondary','submit',false);echo '</form></section>';
    }

    private static function renderSandboxReviewSection(): void {
        $statusFilter=trim((string)($_GET['sandbox_status']??''));$queryFilter=trim((string)($_GET['sandbox_query']??''));$page=max(1,(int)($_GET['sandbox_page']??1));
        try{$adminSnapshot=PSTE_Semantic_Review_Sandbox::adminBoundedSnapshot($statusFilter,$queryFilter,$page,50);}catch(Throwable $e){echo '<h2>Semantic Review Sandbox</h2><div class="notice notice-error inline"><p><strong>Sandbox sicher angehalten:</strong> '.esc_html((string)$e->getMessage()).'. Kein vollständiger Legacy-Bestand wurde in den Speicher geladen.</p></div>';return;}
        $summary=(array)$adminSnapshot['summary'];$records=(array)$adminSnapshot['records'];$filteredRecords=$records;$filteredTotal=(int)($adminSnapshot['filtered_total']??count($records));$pages=(int)($adminSnapshot['pages']??1);$s=PSTE_Plugin::settings();$job=$summary['job']??null;$c=(array)($summary['counts']??[]);
        echo '<h2>Semantic Review Sandbox</h2>';
        echo '<div class="notice notice-warning inline"><p><strong>Hauptregel 1:</strong> Diese Sandbox ist vollständig getrennt von Artikeln, Textmaschine, PPM, Compiler, HTML und Design. Sie erzeugt keinen Produktions-Handoff und besitzt keinen Apply-Button.</p></div>';
        $maintenance=PSTE_Sandbox_Maintenance_Health::snapshot();$maintenanceBad=(string)($maintenance['schedule_status']??'MISSING')!=='SCHEDULED'||in_array((string)($maintenance['run_health']??'UNKNOWN'),['FAIL','OVERDUE'],true);
        echo '<div class="notice '.($maintenanceBad?'notice-error':'notice-info').' inline"><p><strong>Interne Wiederprüfung:</strong> Zeitplan '.esc_html((string)($maintenance['schedule_status']??'UNKNOWN')).' · Laufstatus '.esc_html((string)($maintenance['run_health']??'UNKNOWN')).(($maintenance['current_error_code']??'')!==''?' · Fehler <code>'.esc_html((string)$maintenance['current_error_code']).'</code>':'').'. Strukturlücken bleiben gespeichert; ein ausgefallener Wartungslauf wird sichtbar protokolliert.</p></div>';
        echo '<p><strong>Workflow:</strong> V2-Hauptgate → alle blockierten Longtails dauerhaft erhalten → <strong>Relevanz zuerst</strong> anhand realer SEO-/SERP-Evidenz → nur bestätigte relevante Fälle werden danach intern auf Familie, Kategorie und Titelprobe geprüft. Lokaler Portalbegriff, Familiennähe und Ausschlüsse sind vorher ausschließlich Hinweise und niemals ein Relevanzurteil.</p>';
        echo '<div class="pste-grid">';
        $internalReviewCount=(int)($c['MATCHER_REVIEW']??0)+(int)($c['PROPOSAL_READY_FOR_REVIEW']??0)+(int)($c['MULTIPLE_FAMILIES_REVIEW']??0)+(int)($c['REVIEW_REQUIRED']??0);
        foreach([['Gespeichert',(int)($c['TOTAL_RETAINED']??0)],['Relevanzprüfung offen',(int)($c['PENDING_EXTERNAL_RELEVANCE']??0)],['Providerfehler zurückgestellt',(int)($c['DEFERRED_PROVIDER_ERROR']??0)],['Providerfehler · manuell prüfen',(int)($c['PROVIDER_TASK_REVIEW_REQUIRED']??0)],['Extern relevant',(int)($c['RELEVANT_FOR_PORTAL']??0)],['Extern unklar / manuell prüfen',(int)($c['UNCERTAIN_REVIEW']??0)],['Nicht relevant · gespeichert',(int)($c['RETAINED_NOT_RELEVANT']??0)],['Interne Zuordnung prüfen',$internalReviewCount],['Strukturlücken nach Relevanz',(int)($c['STRUCTURE_GAP']??0)],['Für normalen Reentry vorgemerkt',(int)($c['READY_FOR_NORMAL_REENTRY_REVIEW']??0)]] as $m)echo '<div class="pste-metric"><strong>'.esc_html((string)$m[1]).'</strong><span>'.esc_html($m[0]).'</span></div>';
        echo '</div>';
        $binding=(array)($summary['binding']??[]);if($binding)echo '<p><strong>Gebunden an Dry-run:</strong> <code>'.esc_html(substr((string)($binding['dry_run_sha256']??''),0,16)).'…</code> · <strong>Registry:</strong> <code>'.esc_html(substr((string)($binding['registry_sha256']??''),0,16)).'…</code></p>';
        if($records)self::actionForm('pste_sandbox_export','pste_sandbox_export','Sandbox vollständig exportieren','secondary');
        $externalOpen=(int)($c['PENDING_EXTERNAL_RELEVANCE']??0)+(int)($c['STALE_REVIEW_REQUIRED']??0)+(int)($c['DEFERRED_PROVIDER_ERROR']??0);
        if($externalOpen>0){
            if((string)($s['environment']??'sandbox')!=='production')echo '<div class="notice notice-warning inline"><p><strong>Reale Relevanzprüfung gesperrt:</strong> DataForSEO steht aktuell auf Sandbox; für echte Google-SERP-Evidenz ist Production erforderlich.</p></div>';
            elseif(empty($s['feature_enabled']))echo '<div class="notice notice-warning inline"><p>Kostenpflichtige Recherche ist in den Einstellungen deaktiviert.</p></div>';
            else{
                $nonce=wp_create_nonce('pste_sandbox_ajax');$redirect=admin_url('admin.php?page='.self::TABS['review']['slug'].'&sandbox_view=1&sandbox_complete=1');
                if(is_array($job)&&in_array((string)($job['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))echo '<div class="pste-box"><p><strong>Sandbox-Lauf:</strong> <span id="pste-sandbox-status">'.esc_html((string)$job['status']).'</span> · <span id="pste-sandbox-progress">'.esc_html((string)$job['progress'].' von '.(string)$job['total']).'</span> · Kosten <span id="pste-sandbox-cost">'.esc_html(number_format((float)$job['actual_cost'],6,'.','')).' USD</span> · danach noch <span id="pste-sandbox-remaining">'.esc_html((string)($job['remaining_open_after_batch']??0)).'</span> offen</p>'.((string)$job['last_error']!==''?'<p><strong>Letzter Fehler:</strong> <code>'.esc_html((string)$job['last_error']).'</code></p>':'').'<button type="button" class="button button-primary" id="pste-sandbox-resume">Lauf fortsetzen</button>'.((string)$job['status']==='OUTCOME_UNKNOWN'?'<p><label><input type="checkbox" id="pste-sandbox-provider-checked"> Providerkonto auf die möglicherweise berechnete Anfrage geprüft</label></p><button type="button" class="button" id="pste-sandbox-cancel">Geprüften unklaren Lauf verwerfen</button>':'').'</div>';
                else echo '<p><label><input type="checkbox" id="pste-sandbox-confirm-cost"> Kosten für den nächsten Block realer Google-SERP-Relevanzprüfungen bestätigen</label> <button type="button" class="button button-primary" id="pste-sandbox-start">Nächsten Relevanz-Prüfblock starten</button></p>';
                echo '<div id="pste-sandbox-feedback" class="notice notice-info inline" style="display:none"><p></p></div>';
                $config=wp_json_encode(['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>$nonce,'redirect'=>$redirect,'job'=>$job],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                echo '<script>(function(){"use strict";const cfg='.$config.',feedback=document.getElementById("pste-sandbox-feedback"),start=document.getElementById("pste-sandbox-start"),resume=document.getElementById("pste-sandbox-resume"),cancel=document.getElementById("pste-sandbox-cancel");const sleep=ms=>new Promise(r=>setTimeout(r,ms));function msg(t,e){if(!feedback)return;feedback.style.display="block";feedback.className="notice "+(e?"notice-error":"notice-info")+" inline";feedback.querySelector("p").textContent=t;}function render(j){const s=document.getElementById("pste-sandbox-status"),p=document.getElementById("pste-sandbox-progress"),c=document.getElementById("pste-sandbox-cost"),r=document.getElementById("pste-sandbox-remaining");if(s)s.textContent=j.status;if(p)p.textContent=j.progress+" von "+j.total;if(c)c.textContent=Number(j.actual_cost||0).toFixed(6)+" USD";if(r)r.textContent=String(j.remaining_open_after_batch||0);msg("Sandbox: "+j.status+" · "+j.progress+" von "+j.total,false);}async function call(a,d){const body=new URLSearchParams(Object.assign({action:a,nonce:cfg.nonce},d||{}));const r=await fetch(cfg.ajax_url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8"},body:body.toString()});const raw=await r.text();let j;try{j=JSON.parse((raw||"").replace(/^\uFEFF/,"").trim());}catch(e){throw new Error("PSTE_SANDBOX_AJAX_INVALID_JSON_HTTP_"+r.status+"_LEN_"+(raw||"").length);}if(!r.ok||!j.success)throw new Error((j.data&&j.data.error_code)||"PSTE_SANDBOX_AJAX_FAILED");return j.data;}async function loop(job,explicit){let cur=job,first=!!explicit;for(let guard=0;guard<200;guard++){render(cur);if(cur.status==="COMPLETE"||cur.status==="NOTHING_TO_DO"){window.location.href=cfg.redirect;return;}if(cur.status==="PAUSED_ERROR"&&!first){msg("Sicher angehalten: "+(cur.last_error||"PSTE_SANDBOX_PAUSED"),true);return;}if(cur.status==="OUTCOME_UNKNOWN"){msg("Unbekannter Providerausgang. Keine automatische Wiederholung.",true);return;}await sleep(250);const d=await call("pste_sandbox_advance",{job_uuid:cur.job_uuid,explicit_resume:first?"1":"0"});cur=d.job;first=false;}throw new Error("PSTE_SANDBOX_LOOP_GUARD");}if(start)start.addEventListener("click",async()=>{try{if(!document.getElementById("pste-sandbox-confirm-cost").checked)throw new Error("Bitte Kosten bestätigen.");start.disabled=true;const d=await call("pste_sandbox_start",{confirm_cost:"1"});await loop(d.job,false);}catch(e){msg(e.message,true);start.disabled=false;}});if(resume)resume.addEventListener("click",async()=>{try{resume.disabled=true;await loop(cfg.job,true);}catch(e){msg(e.message,true);resume.disabled=false;}});if(cancel)cancel.addEventListener("click",async()=>{try{const checked=document.getElementById("pste-sandbox-provider-checked");if(!checked||!checked.checked)throw new Error("Providerkonto zuerst prüfen.");const d=await call("pste_sandbox_cancel_unknown",{job_uuid:cfg.job.job_uuid,provider_checked:"1"});render(d.job);window.location.reload();}catch(e){msg(e.message,true);}});})();</script>';
            }
        }
        echo '<h3>Erhaltene Kandidaten</h3><form method="get" style="margin:0 0 12px 0"><input type="hidden" name="page" value="'.esc_attr(self::TABS['review']['slug']).'"><input type="hidden" name="sandbox_view" value="1"><label>Status <select name="sandbox_status"><option value="" '.($statusFilter===''?'selected':'').'>Alle</option><option value="manual" '.($statusFilter==='manual'?'selected':'').'>Manuell entschieden</option><option value="uncertain" '.($statusFilter==='uncertain'?'selected':'').'>Relevanz unklar</option><option value="internal" '.($statusFilter==='internal'?'selected':'').'>Interne Zuordnung prüfen</option><option value="structure" '.($statusFilter==='structure'?'selected':'').'>Strukturlücken</option><option value="not_relevant" '.($statusFilter==='not_relevant'?'selected':'').'>Nicht relevant</option><option value="reentry" '.($statusFilter==='reentry'?'selected':'').'>Reentry</option></select></label> <label>Keyword <input type="search" name="sandbox_query" value="'.esc_attr($queryFilter).'" placeholder="z. B. wassertröge"></label> ';submit_button('Filtern','secondary','submit',false);echo ' <a class="button" href="'.esc_url(admin_url('admin.php?page='.self::TABS['review']['slug'].'&sandbox_view=1')).'">Filter zurücksetzen</a><span style="margin-left:12px">'.esc_html((string)$filteredTotal).' Treffer · Seite '.esc_html((string)$page).' von '.esc_html((string)$pages).' · '.esc_html((string)($c['TOTAL_RETAINED']??0)).' insgesamt</span></form>';
        echo '<table class="widefat striped pste-table"><thead><tr><th>Longtail</th><th>Lokale Hinweise (nur Evidenz)</th><th>Ausschlüsse</th><th>Externe Relevanz</th><th>Nächste Familie (nur Diagnose)</th><th>Interner Vorschlag erst nach Relevanz</th><th>Status</th><th>Review</th></tr></thead><tbody>';
        if(!$filteredRecords)self::emptyRow(8,($c['TOTAL_RETAINED']??0)?'Keine Einträge für diesen Filter.':'Noch keine Sandbox-Synchronisierung.');
        foreach($filteredRecords as $r){
            $nearest=array_values((array)($r['nearest_rejected_families']??[]));$names=[];foreach($nearest as $n)$names[]=trim((string)($n['family_name']??''));
            $dataflowStatus=(string)($r['dataflow_status']??'MIGRATION_REQUIRED');$portal=(array)($r['portal_relevance']??[]);$matched=array_values((array)($r['local_matched_terms']??[]));$ex=(array)($r['exclusion_evidence']??[]);$nearestEx=(array)($ex['nearest_family_hits']??[]);
            $ext=(array)($r['external_relevance']??[]);$in=(array)($r['internal_proposal']??[]);$proposal=(array)($in['review_proposal']??[]);
            $localText=$dataflowStatus!=='VERIFIED'?'Datenfluss noch nicht verifiziert':($matched?('Portalwort erkannt: '.implode(', ',$matched).' · kein Relevanzurteil'):'kein eindeutiger lokaler Portalhinweis');$registryEx=(int)($ex['registry_wide_hit_count']??0);$exText=$dataflowStatus!=='VERIFIED'?'Datenfluss noch nicht verifiziert':($nearestEx?(count($nearestEx).' Treffer bei nächster Familie · '.$registryEx.' registryweit'):($registryEx>0?($registryEx.' registryweite Ausschlusstreffer · nur Evidenz'):'keine aktiven Ausschlusstreffer'));
            $extText=PSTE_Semantic_Review_Sandbox::effectiveRelevanceStatusForAdmin($r);$status=(string)($r['status']??'');
            echo '<tr><td><strong>'.esc_html((string)$r['query']).'</strong><br><small>Volumen: '.esc_html($r['search_volume']===null?'—':(string)$r['search_volume']).'</small></td><td>'.esc_html($localText).'</td><td>'.esc_html($exText).'<br><small>'.esc_html($dataflowStatus==='VERIFIED'?'vollständig gespeichert und Datenfluss verifiziert':'Migration/Verifikation erforderlich').'</small></td><td>'.esc_html($extText);
            if($ext){$ev=array_slice((array)($ext['evidence']??[]),0,5);if($ev){echo '<details><summary>SERP-Evidenz</summary><ol>';foreach($ev as $e)echo '<li><strong>'.esc_html((string)($e['title']??'' )).'</strong><br><small>'.esc_html((string)($e['domain']??'')).'</small></li>';echo '</ol></details>';}}
            echo '</td><td>'.esc_html($names?implode(' / ',$names):'—').'</td><td>'.esc_html((string)($proposal['planning_title_probe']??'—')).'<br><small>'.esc_html((string)($proposal['category_slug']??'')).' '.esc_html((string)($proposal['article_type']??'')).'</small></td><td><code>'.esc_html($status).'</code></td><td>';
            $reviewableExternal=((($ext['contract']??'')===PSTE_Sandbox_SEO_Relevance::CONTRACT)||(($ext['contract']??'')==='PSTE_SANDBOX_EXTERNAL_PROVIDER_OUTCOME_V1'&&!empty($ext['reviewable_external_evidence'])))&&(string)($ext['environment']??'')==='production'&&(string)($ext['status']??'')==='UNCERTAIN_REVIEW'&&preg_match('/^[a-f0-9]{64}$/',(string)($ext['response_sha256']??''));
            $currentAd=(array)($r['relevance_adjudication']??[]);$currentDecision=(string)($currentAd['decision']??'');$manualDecision=in_array($currentDecision,['RELEVANT_FOR_PORTAL','NOT_RELEVANT_FOR_PORTAL'],true)&&in_array((string)($currentAd['decision_source']??''),['EXPLICIT_ADMIN_REVIEW','EXPLICIT_ADMIN_REVIEW_REVISION'],true)&&preg_match('/^[a-f0-9]{64}$/',(string)($currentAd['decision_sha256']??''));$renderedReview=false;
            if($reviewableExternal&&($status==='UNCERTAIN_REVIEW'||$manualDecision)){
                $currentSha=$manualDecision?(string)($currentAd['decision_sha256']??''):'';
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-bottom:8px">';wp_nonce_field('pste_sandbox_review_relevance');echo '<input type="hidden" name="action" value="pste_sandbox_review_relevance"><input type="hidden" name="sandbox_id" value="'.esc_attr((string)$r['sandbox_id']).'"><input type="hidden" name="expected_response_sha256" value="'.esc_attr((string)$ext['response_sha256']).'"><input type="hidden" name="expected_current_decision_sha256" value="'.esc_attr($currentSha).'"><select name="relevance_decision" required><option value="">Entscheidung…</option><option value="RELEVANT_FOR_PORTAL" '.($currentDecision==='RELEVANT_FOR_PORTAL'?'selected':'').'>Für Portal relevant</option><option value="NOT_RELEVANT_FOR_PORTAL" '.($currentDecision==='NOT_RELEVANT_FOR_PORTAL'?'selected':'').'>Nicht relevant</option></select><br><input type="text" class="regular-text" name="review_note" placeholder="'.esc_attr($manualDecision?'Korrektur begründen':'Kurze Begründung').'" required> ';submit_button($manualDecision?'Relevanzentscheidung ändern':'Relevanzentscheidung speichern','secondary','submit',false);if($manualDecision)echo '<br><small>Alte Entscheidung bleibt revisionssicher erhalten · aktuelle Revision: '.esc_html((string)max(1,(int)($currentAd['revision']??1))).'</small>';echo '</form>';$renderedReview=true;
            }
            if(in_array($status,['MATCHER_REVIEW','PROPOSAL_READY_FOR_REVIEW'],true)&&$in&&$proposal){
                $proposalSha=(string)($r['internal_proposal_sha256']??'');
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_sandbox_confirm_internal');echo '<input type="hidden" name="action" value="pste_sandbox_confirm_internal"><input type="hidden" name="sandbox_id" value="'.esc_attr((string)$r['sandbox_id']).'"><input type="hidden" name="expected_proposal_sha256" value="'.esc_attr($proposalSha).'"><input type="text" class="regular-text" name="review_note" placeholder="Zuordnung geprüft" required> ';submit_button('Für normalen Reentry vormerken','secondary','submit',false);echo '</form>';$renderedReview=true;
            }
            if(!$renderedReview){if($status==='DEFERRED_PROVIDER_ERROR')echo '<em>Providerfehler isoliert; Kandidat bleibt erhalten und wird erst nach den normalen offenen Fällen erneut versucht.</em>';elseif($status==='PROVIDER_TASK_REVIEW_REQUIRED')echo '<em>Providerfehler dauerhaft gespeichert; keine automatische Wiederholung mehr.</em>';elseif($status==='STRUCTURE_GAP')echo '<em>Strukturlücke bleibt erhalten; keine automatische Zuordnung.</em>';elseif($status==='READY_FOR_NORMAL_REENTRY_REVIEW')echo '<strong>Vorgemerkt.</strong><br><small>Noch kein Produktions-Handoff.</small>';else echo '—';}
            echo '</td></tr>';
        }
        echo '</tbody></table>';if($pages>1){echo '<p>';for($i=max(1,$page-2);$i<=min($pages,$page+2);$i++){if($i===$page)echo ' <strong>'.esc_html((string)$i).'</strong> ';else echo ' <a class="button button-small" href="'.esc_url(add_query_arg(['page'=>self::TABS['review']['slug'],'sandbox_view'=>1,'sandbox_status'=>$statusFilter,'sandbox_query'=>$queryFilter,'sandbox_page'=>$i],admin_url('admin.php'))).'">'.esc_html((string)$i).'</a> ';}echo '</p>';}echo '<p><small>Kein Datensatz wird gelöscht. Lokale Hinweise, Ausschlusssignale, Familiennähe, externe Evidenz und Review-Historie bleiben je Kandidat erhalten. Vor bestätigter Relevanz wird keine Familie, Kategorie oder Titelprobe freigegeben. Unklare externe Evidenz kann ausschließlich ausdrücklich menschlich entschieden werden; auch eine interne Bestätigung erzeugt noch keinen Produktions-Handoff.</small></p>';
    }

    private static function renderSettings(): void {
        try{PSTE_Research_Job::current();}catch(Throwable $ignored){}try{PSTE_Breadth_Research_Queue::current();}catch(Throwable $ignored){}
        $s=PSTE_Plugin::settings();$baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$state=is_array($baseline)?PSTE_Snapshot::baselineStatus($baseline):['status'=>'NOT_CAPTURED'];
        echo '<h2>Einstellungen und einheitlicher Rechercheworkflow</h2><p><strong>Ein Themenlauf = ein Klick.</strong> Danach sind Longtails recherchiert, redaktionell vorgeprüft und gegen den eigenen Portalbestand abgeglichen; Titel werden ausschließlich durch die Sprachwerkstatt formuliert.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_save_settings');echo '<input type="hidden" name="action" value="pste_save_settings"><table class="form-table"><tr><th>Kostenpflichtige Longtail-Recherche</th><td><label><input type="checkbox" name="feature_enabled" value="1" '.checked(!empty($s['feature_enabled']),true,false).'> aktivieren</label></td></tr><tr><th>DataForSEO-Umgebung</th><td><select name="environment"><option value="sandbox" '.selected($s['environment'],'sandbox',false).'>Sandbox</option><option value="production" '.selected($s['environment'],'production',false).'>Production</option></select></td></tr><tr><th>Location</th><td><input name="location" value="'.esc_attr($s['location']).'"></td></tr><tr><th>Language</th><td><input name="language" value="'.esc_attr($s['language']).'"></td></tr><tr><th>Maximum Cost per Run</th><td><input type="number" step="0.01" min="0.01" max="10" name="run_budget_usd" value="'.esc_attr((string)$s['run_budget_usd']).'"> USD</td></tr><tr><th>GSC-Standardzeitraum</th><td><input type="number" min="7" max="480" name="gsc_default_days" value="'.esc_attr((string)$s['gsc_default_days']).'"> Tage</td></tr></table>';submit_button('Einstellungen speichern');echo '</form>';
        echo '<h3>Harte Grenzen</h3><table class="widefat striped" style="max-width:850px"><tbody>';self::row('Website-Gesamtbild',(string)($state['status']??'NOT_CAPTURED'));self::row('Google-Live-SERP-Prüfung','NUR SEMANTIC SANDBOX · KEIN HAUPTFILTER / KEINE PRODUKTION');self::row('Artikelinhalt / HTML / Design','UNANTASTBAR');self::row('Automatische Yoast-Änderungen','VERBOTEN');self::row('Automatische Artikelproduktion','VERBOTEN');echo '</tbody></table>';
        echo '<details style="margin-top:18px;max-width:900px"><summary><strong>Strategische Gewichtung</strong> <span style="font-weight:400">(nur bei Bedarf)</span></summary>';
        self::renderCoverage();
        echo '</details>';
        echo '<details style="margin-top:18px;max-width:900px"><summary><strong>Wartung &amp; erweiterte Recherche</strong> <span style="font-weight:400">(normal nicht nötig)</span></summary>';
        PSTE_Storage_Admin::renderBox();
        self::actionForm('pste_capture_baseline','pste_capture_baseline','Gesamtbestand neu erfassen');
        self::renderRunControls();
        echo '</details>';
    }


    private static function renderRunControls(): void {
        $s=PSTE_Plugin::settings();
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        $families=is_array($baseline)?PSTE_Category_Context::familyAnchors($baseline):[];
        $familyProgressInput=array_map(static fn(array $family)=>['term_id'=>(int)$family['term_id'],'name'=>(string)$family['topic_family_name'],'slug'=>(string)$family['topic_family_key']],$families);
        $progress=PSTE_Repository::categoryProgress($familyProgressInput);$latest=PSTE_Repository::latestRun();
        $active=null;$breadth=null;$activeError='';$breadthError='';
        try{$active=PSTE_Research_Job::peek();}catch(Throwable $e){$activeError=sanitize_text_field((string)$e->getMessage());}
        try{$breadth=PSTE_Breadth_Research_Queue::peek();}catch(Throwable $e){$breadthError=sanitize_text_field((string)$e->getMessage());}
        $driver=PSTE_Research_Driver::status();
        echo '<h3>Longtails recherchieren, Titel bilden und Kategorien zuordnen</h3>';
        echo '<p><strong>Schrittbetrieb:</strong> Der Server verarbeitet immer genau einen gespeicherten Arbeitsschritt. Der Browser startet, zeigt Status und kann abbrechen; er entscheidet niemals, welcher Recherche-/Provider-/FINALIZE-Schritt als Nächstes ausgeführt wird.</p>';
        if(empty($s['feature_enabled'])){echo '<p><em>Kostenpflichtige Longtail-Recherche ist AUS.</em></p>';return;}
        if($activeError!==''||$breadthError!==''){echo '<div class="notice notice-error inline"><p><strong>Gespeicherter Rechercheauftrag ist ungültig:</strong> '.esc_html(trim($activeError.' '.$breadthError)).'</p></div>';return;}
        $nonce=wp_create_nonce('pste_research_ajax');$breadthStatus=is_array($breadth)?(string)($breadth['status']??''):'';$breadthActive=is_array($breadth)&&in_array($breadthStatus,['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true);$breadthExistingOnly=is_array($breadth)&&!empty($breadth['existing_only']);$breadthLabel=$breadthExistingOnly?'Bestandsaufbereitung':'Produktionswelle';$singleActive=is_array($active);$breadthDisplay=$breadthActive?'block':'none';$startDisplay=(!$breadthActive&&!$singleActive)?'block':'none';
        echo '<div class="pste-box"><strong>Server-Driver:</strong> <span id="pste-driver-status">'.esc_html((string)($driver['status']??'IDLE')).'</span> · <span id="pste-driver-health">'.esc_html((string)($driver['health_code']??'')).'</span><br><span id="pste-driver-message">'.esc_html((string)($driver['message']??'')).'</span><br><small>Schritt <span id="pste-driver-step-number">'.esc_html((string)($driver['step_number']??0)).'</span> · <span id="pste-driver-last-step">'.esc_html((string)($driver['last_step']??'')).'</span> · letzter Fortschritt <span id="pste-driver-last-progress">'.esc_html((string)($driver['last_progress_at_utc']??'')).'</span></small></div>';
        echo '<div class="pste-box" id="pste-active-breadth" style="display:'.esc_attr($breadthDisplay).'"><p><strong>'.esc_html($breadthLabel).':</strong> <span id="pste-breadth-status">'.esc_html($breadthStatus!==''?$breadthStatus:'RUNNING').'</span> · neue planbare Themen <strong><span id="pste-breadth-usable">'.esc_html((string)($breadth['usable_candidate_count']??0)).'</span> / <span id="pste-breadth-target-display">'.esc_html((string)($breadth['target_usable']??40)).'</span></strong> · <span id="pste-breadth-progress">'.($breadthExistingOnly?esc_html((string)($breadth['local_backlog_processed']??0)).' Bestandszeilen geprüft':esc_html((string)($breadth['completed_count']??0)).' von max. '.esc_html((string)($breadth['max_items']??$breadth['item_count']??40)).' Familien').'</span> · geparkte blockierte Schritte <span id="pste-breadth-blocked">'.esc_html((string)($breadth['blocked_count']??0)).'</span></p><p id="pste-breadth-detail"></p><p><small>'.($breadthExistingOnly?'Provider-Abfragen: ausgeschlossen · ':'').'Aktiver Serverzustand: <span id="pste-breadth-live-health">'.esc_html((string)($driver['health_code']??'')).'</span></small></p>';
        echo '<button type="button" class="button button-primary" id="pste-breadth-resume" style="display:'.esc_attr(in_array($breadthStatus,['PAUSED_ERROR','OUTCOME_UNKNOWN'],true)?'inline-block':'none').'">Gespeicherten Block erneut prüfen</button> ';
        echo '<button type="button" class="button" id="pste-breadth-cancel">'.esc_html($breadthLabel).' sicher abbrechen</button></div>';
        echo '<div class="pste-box" id="pste-breadth-start-box" style="display:'.esc_attr($startDisplay).'"><h4>Produktionswelle</h4><p>Bereits gespeicherte Recherche-, Themen-, Sandbox-, Coverage- und Redaktionsplandaten werden weiterverwendet. Ein blockierter Kindlauf wird vollständig archiviert und stoppt nicht automatisch unabhängige Familien.</p><label><strong>Ziel neue eindeutige PSTE-PASS-Themen:</strong> <input id="pste-breadth-target" type="number" min="1" max="200" value="40" style="width:80px"></label> &nbsp; <label><strong>Max. Themenfamilien:</strong> <input id="pste-breadth-max" type="number" min="1" max="40" value="40" style="width:70px"></label><br><br><label><input type="checkbox" id="pste-breadth-confirm-cost"> Kosten bestätigen</label> <button type="button" class="button button-primary" id="pste-breadth-start">Produktionswelle starten</button></div>';
        if($breadthActive){
            // Active breadth controls are rendered above and kept live by AJAX without a page reload.
        }elseif($singleActive){
            $status=(string)$active['status'];echo '<div class="pste-box" id="pste-active-research"><p><strong>Gespeicherter Einzellauf:</strong> <span id="pste-job-status">'.esc_html($status).'</span> · <span id="pste-job-progress">'.esc_html((string)$active['progress']).' von '.esc_html((string)$active['total_provider_steps']).'</span> · Kosten <span id="pste-job-cost">'.esc_html(number_format((float)$active['actual_cost'],6,'.','')).' USD</span></p><p id="pste-job-detail"></p>';
            if(in_array($status,['PAUSED_ERROR','OUTCOME_UNKNOWN'],true))echo '<button type="button" class="button button-primary" id="pste-resume-research">Gespeicherten Block erneut prüfen</button> ';
            if($status==='OUTCOME_UNKNOWN')echo '<label><input type="checkbox" id="pste-provider-checked"> Providerkonto wurde auf die möglicherweise berechnete Anfrage geprüft</label> <button type="button" class="button" id="pste-cancel-research">Geprüften unklaren Lauf beenden</button>';
            echo '</div>';
        }else{
            if(is_array($breadth)&&$breadthStatus==='COMPLETE'){
                if($breadthExistingOnly)echo '<div class="notice notice-success inline"><p><strong>Bestandsaufbereitung abgeschlossen:</strong> '.esc_html((string)($breadth['usable_candidate_count']??0)).' neue planbare Themen · <code>'.esc_html((string)($breadth['completion_reason']??'COMPLETE')).'</code>. <strong>Nächster Schritt:</strong> auf der Produktionsseite die Automatik fortsetzen.</p></div>';
                else echo '<div class="notice notice-success inline"><p><strong>Letzte Produktionswelle abgeschlossen:</strong> '.esc_html((string)($breadth['usable_candidate_count']??0)).' neue eindeutige PASS-Themen · '.esc_html((string)($breadth['blocked_count']??0)).' blockierte Einzelschritte verlustfrei geparkt · <code>'.esc_html((string)($breadth['completion_reason']??'COMPLETE')).'</code>.</p></div>';
            }
            $rank=['NOT_ANALYZED'=>0,'BLOCKED'=>1,'ANALYZED'=>2];usort($progress['items'],static fn($a,$b)=>[$rank[$a['state']]??9,$a['name']]<=>[$rank[$b['state']]??9,$b['name']]);
            echo '<details style="margin-top:14px"><summary>Einzelne Themenfamilie manuell recherchieren</summary><form id="pste-run-form" style="margin-top:12px"><label><strong>Themenfamilie</strong><br><select id="pste-category-select" required><option value="">Themenfamilie auswählen</option>';
            foreach($progress['items'] as $i){if(strcasecmp((string)$i['name'],'Uncategorized')===0)continue;echo '<option value="'.esc_attr((string)$i['term_id']).'" data-name="'.esc_attr(strtolower((string)$i['name'])).'" data-state="'.esc_attr((string)$i['state']).'" data-seed="'.esc_attr((string)$i['name']).'">'.esc_html($i['name'].' · '.$i['state']).'</option>';}
            echo '</select></label> &nbsp; <label><strong>Ausgangsbegriff</strong><br><input id="pste-seed" required></label><br><br><label><input type="checkbox" id="pste-confirm-cost" required> Kosten bestätigen</label> <button type="submit" class="button" id="pste-start-research">Einzellauf starten</button></form></details>';
        }
        echo '<div id="pste-research-feedback" class="notice notice-info inline" style="display:none"><p></p></div>';
                $config=wp_json_encode(['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>$nonce,'active'=>$active,'breadth'=>$breadth,'driver'=>$driver],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        echo '<script>(function(){"use strict";const cfg='.$config.';let job=cfg.active||null,queue=cfg.breadth||null,driver=cfg.driver||{};const activeStates=["RUNNING","PAUSED_ERROR","OUTCOME_UNKNOWN"],feedback=document.getElementById("pste-research-feedback"),startBox=document.getElementById("pste-breadth-start-box"),activeBox=document.getElementById("pste-active-breadth");if(queue&&!activeStates.includes(String(queue.status||"")))queue=null;function msg(t,e){if(!feedback)return;feedback.style.display="block";feedback.className="notice "+(e?"notice-error":"notice-info")+" inline";feedback.querySelector("p").textContent=t;}function setBreadthActive(on){if(startBox)startBox.style.display=on?"none":"block";if(activeBox)activeBox.style.display=on?"block":"none";}function ageText(v){if(!v)return "noch kein Fortschritt";const t=Date.parse(v);if(!Number.isFinite(t))return String(v);const sec=Math.max(0,Math.floor((Date.now()-t)/1000));return sec<60?"vor "+sec+" s":"vor "+Math.floor(sec/60)+" min "+(sec%60)+" s";}async function call(action,data){const body=new URLSearchParams(Object.assign({action,nonce:cfg.nonce},data||{}));const r=await fetch(cfg.ajax_url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8","Accept":"application/json"},body:body.toString()});const raw=await r.text();let j;try{j=JSON.parse((raw||"").replace(/^\\uFEFF/,"").trim());}catch(e){throw new Error("PSTE_AJAX_INVALID_JSON_HTTP_"+r.status);}if(!r.ok||!j.success)throw new Error((j.data&&j.data.error_code)||("PSTE_AJAX_REQUEST_FAILED_HTTP_"+r.status));return j.data;}function renderDriver(d){driver=d||driver;const s=document.getElementById("pste-driver-status"),h=document.getElementById("pste-driver-health"),m=document.getElementById("pste-driver-message"),n=document.getElementById("pste-driver-step-number"),ls=document.getElementById("pste-driver-last-step"),lp=document.getElementById("pste-driver-last-progress"),bh=document.getElementById("pste-breadth-live-health");if(s)s.textContent=driver.status||"IDLE";if(h)h.textContent=driver.health_code||"";if(m)m.textContent=driver.message||"";if(n)n.textContent=String(driver.step_number||0);if(ls)ls.textContent=driver.last_step||"";if(lp)lp.textContent=ageText(driver.last_progress_at_utc||driver.step_started_at_utc||"");if(bh){const timing=Number(driver.active_step_age_seconds||0)>0?"aktiver Schritt seit "+Number(driver.active_step_age_seconds||0)+" s":"letzter Schritt "+Number(driver.last_step_duration_ms||0)+" ms";bh.textContent=(driver.status||"IDLE")+" · "+(driver.health_code||"")+" · "+timing+" · "+ageText(driver.last_progress_at_utc||driver.step_started_at_utc||"");}if(driver.status==="BLOCKED"||driver.health_code==="PSTE_DRIVER_STEP_OVERDUE"||driver.health_code==="PSTE_DRIVER_WAKEUP_OVERDUE")msg("SYSTEMSTATUS: HÄNGT-BLOCKED · "+(driver.last_error||driver.health_code||"PSTE_DRIVER_BLOCKED")+" · Stand ist gespeichert.",true);}function jobText(j){if(!j)return "";let x="Datenquellen "+Number(j.progress||0)+" von "+Number(j.total_provider_steps||0)+" · Fragen "+String(j.questions_state||"NOT_STARTED");if(j.phase==="FINALIZE"){const st=String(j.finalize_stage||"PREPARE");x+=" · Abschluss "+st;if(st==="PREPARE_CANDIDATES")x+=" "+Number(j.finalize_prepare_cursor||0)+"/"+Number(j.finalize_prepare_total||0);if(st==="PREPARE_COMMIT")x+=" "+Number(j.finalize_prepare_commit_cursor||0)+"/"+Number(j.finalize_total||0);if(st==="SANDBOX_BATCH")x+=" "+Number(j.finalize_sandbox_cursor||0)+"/"+Number(j.finalize_total||0);if(st==="CONTEXT_BATCH")x+=" "+Number(j.finalize_context_cursor||0)+"/"+Number(j.finalize_total||0);}return x;}function renderJob(j){job=j||job;if(!job)return;const s=document.getElementById("pste-job-status"),p=document.getElementById("pste-job-progress"),c=document.getElementById("pste-job-cost"),d=document.getElementById("pste-job-detail");if(s)s.textContent=job.status||"";if(p)p.textContent=jobText(job);if(c)c.textContent=Number(job.actual_cost||0).toFixed(6)+" USD";if(d)d.textContent=(job.last_error?"Fehler: "+job.last_error+" · ":"")+"Server-Driver entscheidet den nächsten Schritt.";}function renderQueue(q){queue=q||queue;if(!queue)return;setBreadthActive(true);const s=document.getElementById("pste-breadth-status"),p=document.getElementById("pste-breadth-progress"),u=document.getElementById("pste-breadth-usable"),tgt=document.getElementById("pste-breadth-target-display"),b=document.getElementById("pste-breadth-blocked"),d=document.getElementById("pste-breadth-detail"),resume=document.getElementById("pste-breadth-resume");if(s)s.textContent=queue.status||"";if(p)p.textContent=queue.existing_only?(Number(queue.local_backlog_processed||0)+" Bestandszeilen geprüft"):(Number(queue.completed_count||0)+" von max. "+Number(queue.max_items||queue.item_count||0)+" Familien");if(u)u.textContent=Number(queue.usable_candidate_count||0);if(tgt)tgt.textContent=Number(queue.target_usable||0);if(b)b.textContent=Number(queue.blocked_count||0);if(resume)resume.style.display=["PAUSED_ERROR","OUTCOME_UNKNOWN"].includes(String(queue.status||""))?"inline-block":"none";const cur=(queue.items||[])[Number(queue.current_index||0)],child=queue.child||null;let text=queue.local_backlog_reused?"Lokaler Bestand: vollständige Prüfung wiederverwendet.":(!queue.local_backlog_complete?"Lokaler Bestand: "+Number(queue.local_backlog_processed||0)+" geprüft.":"");if(cur)text+=(text?" ":"")+"Aktuell: "+String(cur.family||"")+".";if(child)text+=" Kindlauf: "+jobText(child)+".";if(queue.last_blocked_error)text+=" Zuletzt geparkt: "+queue.last_blocked_error+".";if(d)d.textContent=text;}async function refresh(){let requestedQueueUuid="";try{if(queue&&queue.queue_uuid){requestedQueueUuid=String(queue.queue_uuid||"");const d=await call("pste_breadth_research_status",{queue_uuid:requestedQueueUuid});if(!queue||String(queue.queue_uuid||"")!==requestedQueueUuid)return;renderQueue(d.queue);renderDriver(d.driver);if(["COMPLETE","CANCELLED"].includes(String(d.queue.status||""))){msg((d.queue.existing_only?"Bestandsaufbereitung ":"Produktionswelle ")+d.queue.status+" · "+String(d.queue.completion_reason||""),false);queue=null;setBreadthActive(false);return;}}else if(job&&job.job_uuid){const d=await call("pste_research_status",{job_uuid:job.job_uuid});if(d.job)renderJob(d.job);renderDriver(d.driver);if(["COMPLETE","CANCELLED"].includes(String((d.driver||{}).status||"")))msg("Einzellauf "+d.driver.status+".",false);}}catch(e){if(requestedQueueUuid&&queue&&String(queue.queue_uuid||"")!==requestedQueueUuid)return;msg(e.message||"PSTE_STATUS_READ_FAILED",true);}}const bs=document.getElementById("pste-breadth-start");if(bs)bs.addEventListener("click",async()=>{try{const c=document.getElementById("pste-breadth-confirm-cost");if(!c||!c.checked)throw new Error("Bitte Kosten bestätigen.");bs.disabled=true;const target=document.getElementById("pste-breadth-target"),max=document.getElementById("pste-breadth-max"),d=await call("pste_breadth_research_start",{target_usable:target?target.value:"40",max_items:max?max.value:"40",confirm_cost:"1"});queue=d.queue;job=null;setBreadthActive(true);renderQueue(queue);renderDriver(d.driver);msg("Server-Driver gestartet. Fortschritt wird automatisch aktualisiert.",false);}catch(e){msg(e.message,true);bs.disabled=false;}});const br=document.getElementById("pste-breadth-resume");if(br)br.addEventListener("click",async()=>{try{const d=await call("pste_breadth_research_advance",{queue_uuid:queue.queue_uuid,explicit_resume:"1"});renderQueue(d.queue);renderDriver(d.driver);msg("Gespeicherter Block zur erneuten serverseitigen Prüfung freigegeben.",false);}catch(e){msg(e.message,true);}});const bc=document.getElementById("pste-breadth-cancel");if(bc)bc.addEventListener("click",async()=>{if(!queue||!queue.queue_uuid)return;if(!confirm((queue&&queue.existing_only?"Bestandsaufbereitung":"Produktionswelle")+" sicher abbrechen? Bereits gespeicherte Daten bleiben erhalten."))return;try{const d=await call("pste_breadth_research_cancel",{queue_uuid:queue.queue_uuid});renderQueue(d.queue);renderDriver(d.driver||driver);msg("Abbruch gespeichert. Bereits recherchierte Daten bleiben erhalten.",false);}catch(e){msg(e.message,true);}});const f=document.getElementById("pste-run-form");if(f){const sel=document.getElementById("pste-category-select"),seed=document.getElementById("pste-seed");sel.addEventListener("change",()=>{const o=sel.selectedOptions[0];if(o)seed.value=o.dataset.seed||"";});f.addEventListener("submit",async e=>{e.preventDefault();try{const d=await call("pste_research_start",{category_id:sel.value,seed:seed.value,confirm_cost:document.getElementById("pste-confirm-cost").checked?"1":"0"});job=d.job;queue=null;setBreadthActive(false);renderJob(job);renderDriver(d.driver);msg("Einzellauf an den Server-Driver übergeben.",false);}catch(x){msg(x.message,true);}});}const rr=document.getElementById("pste-resume-research");if(rr)rr.addEventListener("click",async()=>{try{const d=await call("pste_research_advance",{job_uuid:job.job_uuid,explicit_resume:"1"});if(d.job)renderJob(d.job);renderDriver(d.driver);msg("Gespeicherter Block zur erneuten serverseitigen Prüfung freigegeben.",false);}catch(e){msg(e.message,true);}});const rc=document.getElementById("pste-cancel-research");if(rc)rc.addEventListener("click",async()=>{try{const ck=document.getElementById("pste-provider-checked");if(!ck||!ck.checked)throw new Error("Providerprüfung muss bestätigt werden.");const d=await call("pste_research_cancel",{job_uuid:job.job_uuid,provider_checked:"1"});renderDriver(d.driver||driver);msg("Unklarer Lauf beendet; Archiv bleibt erhalten.",false);}catch(e){msg(e.message,true);}});setBreadthActive(!!queue);renderDriver(driver);if(queue)renderQueue(queue);if(job&&!queue)renderJob(job);setInterval(refresh,2000);refresh();})();</script>';
        if($latest){echo '<p><strong>Letzter abgeschlossener Lauf:</strong> '.esc_html((string)$latest['status']).' · '.esc_html((string)($latest['payload']['usable_candidate_count']??0)).' direkt nutzbare Themen.</p>';self::actionForm('pste_export_overlay','pste_export_overlay','Letztes Overlay exportieren');self::actionForm('pste_export_topic_map','pste_export_topic_map','Gesamte Themenkarte exportieren');}
    }

    public static function saveSettings(): void {try{PSTE_Auth::assertAdmin('pste_save_settings',(string)($_POST['_wpnonce']??''));PSTE_Credentials::assertNoCredentialPayload($_POST);$s=PSTE_Plugin::settings();$s['feature_enabled']=isset($_POST['feature_enabled']);$s['environment']=($_POST['environment']??'sandbox')==='production'?'production':'sandbox';$s['location']=sanitize_text_field((string)($_POST['location']??'Germany'));$s['language']=sanitize_text_field((string)($_POST['language']??'German'));$s['run_budget_usd']=min(10,max(.01,(float)($_POST['run_budget_usd']??8)));$s['gsc_default_days']=min(480,max(7,(int)($_POST['gsc_default_days']??90)));update_option(PSTE_OPTION_SETTINGS,$s,false);self::redirect('settings','updated=1');}catch(Throwable $e){self::blocked('settings',$e);}}
    public static function saveCredentials(): void {try{PSTE_Auth::assertAdmin('pste_save_credentials',(string)($_POST['_wpnonce']??''));PSTE_Credentials::saveFromAdmin((string)($_POST['api_login']??''),(string)($_POST['api_password']??''),(string)($_POST['api_credentials_base64']??''));self::redirect('sources','credentials_saved=1');}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function captureBaseline(): void {try{PSTE_Auth::assertAdmin('pste_capture_baseline',(string)($_POST['_wpnonce']??''));PSTE_Runner::captureSiteBaseline();self::redirect('overview','baseline_captured=1');}catch(Throwable $e){self::blocked('overview',$e);}}
    public static function importExistingEvidenceReentry(): void {
        PSTE_Auth::assertAdmin('pste_import_existing_evidence_reentry',(string)($_POST['_wpnonce']??''));
        if(empty($_FILES['existing_evidence_reentry_json']['tmp_name'])||!is_uploaded_file($_FILES['existing_evidence_reentry_json']['tmp_name']))wp_die('PSTE_EXISTING_EVIDENCE_REENTRY_UPLOAD_MISSING');
        try{$raw=(string)file_get_contents($_FILES['existing_evidence_reentry_json']['tmp_name']);$decoded=json_decode($raw,true,512,JSON_THROW_ON_ERROR);if(!is_array($decoded))throw new RuntimeException('PSTE_EXISTING_EVIDENCE_REENTRY_JSON_INVALID');$result=PSTE_Repository::bindExistingEvidenceReentryDecisions($decoded,get_current_user_id());if(($result['status']??'')!=='PASS'||(int)($result['provider_calls']??-1)!==0||!empty($result['production_authority'])||!empty($result['article_or_taxonomy_write_attempted']))throw new RuntimeException('PSTE_EXISTING_EVIDENCE_REENTRY_IMPORT_RESULT_INVALID');set_transient('pste_existing_evidence_reentry_import_result',$result,300);self::redirect('review','sandbox_view=1&existing_evidence_reentry_imported=1');}catch(Throwable $e){self::blocked('review',$e);}
    }

    /**
     * A bounded flight recorder for the EXISTING automation. No topic decisions,
     * provider calls, new workers, or WP article/category writes. Changes in the
     * normal stage and counters are recorded at the regular existing AJAX boundary.
     * Never store raw titles, keywords, page contents or credentials.
     */
    private static function recordAutomaticProtocol(array $state,string $source,string $overrideError=''): void {
        try{
            $queue=PSTE_Breadth_Research_Queue::peek();
            $context=PSTE_Context_Refresh::status();
            $job=class_exists('PSERC_Plan_Snapshot_Store')?PSERC_Plan_Snapshot_Store::getJob():[];
            $queue=is_array($queue)?$queue:[];
            $context=is_array($context)?$context:[];
            $job=is_array($job)?$job:[];
            $code=$overrideError!==''?$overrideError:(string)($state['error_code']??'');
            $code=substr((string)preg_replace('/[^A-Z0-9_:\-]/','_',strtoupper($code)),0,160);
            $event=[
                'stage'=>substr((string)($state['stage']??'UNKNOWN'),0,36),
                'status'=>substr((string)($state['status']??'UNKNOWN'),0,36),
                'terminal'=>substr((string)($state['terminal']??''),0,24),
                'error_code'=>$code,
                'context_status'=>substr((string)($context['status']??''),0,36),
                'context_phase'=>substr((string)($context['phase']??''),0,64),
                'context_processed'=>(int)($context['processed']??0),
                'context_total'=>(int)($context['total']??0),
                'audit_status'=>substr((string)($queue['status']??''),0,36),
                'audit_processed'=>(int)($queue['local_backlog_processed']??0),
                'audit_total'=>(int)($queue['local_backlog_total']??0),
                'audit_title_candidates'=>(int)($queue['local_backlog_title_candidates']??0),
                'audit_usable_candidates'=>(int)($queue['usable_candidate_count']??0),
                'audit_error'=>substr((string)preg_replace('/[^A-Z0-9_:\-]/','_',strtoupper((string)($queue['last_error']??''))),0,160),
                'compiler_status'=>substr((string)($job['status']??''),0,36),
                'compiler_phase'=>substr((string)($job['phase']??''),0,36),
                'compiler_processed'=>(int)($job['candidate_index']??0),
                'compiler_eligible'=>(int)($job['eligible_count']??0),
                'compiler_prepared'=>(int)($job['prepared_count']??0),
                'compiler_ready'=>(int)($job['ready_count']??0),
            ];
            $fingerprint=hash('sha256',(string)wp_json_encode($event));
            $log=get_option('pste_automatic_protocol_v1',[]);
            if(!is_array($log)||($log['contract']??'')!=='PSTE_AUTOMATIC_PROTOCOL_V1')$log=['contract'=>'PSTE_AUTOMATIC_PROTOCOL_V1','events'=>[]];
            if(hash_equals((string)($log['last_fingerprint']??''),$fingerprint))return;
            $event['at_utc']=gmdate('c');
            $event['source']=$source;
            $events=(array)($log['events']??[]);
            $events[]=$event;
            $log['events']=array_slice($events,-100);
            $log['last_fingerprint']=$fingerprint;
            $log['last_seen_utc']=$event['at_utc'];
            update_option('pste_automatic_protocol_v1',$log,false);
        }catch(Throwable $ignored){/* diagnostics must never alter the normal workflow */}
    }

    private static function automaticProtocolSuccess(array $state,int $level): void {
        self::recordAutomaticProtocol($state,'AUTOMATIK');
        self::ajaxSuccess($state,$level);
    }
    private static function automaticProtocolError(Throwable $error,int $level): void {
        self::recordAutomaticProtocol(['stage'=>'ERROR','status'=>'BLOCKED','terminal'=>'BLOCKED'],'AUTOMATIK_ERROR',self::safeErrorCode($error));
        self::ajaxError($error,$level,400);
    }

    /** Snapshot used both by the legacy endpoint and the single complete diagnosis. */
    private static function automaticProtocolSnapshot(): array {
        $log=get_option('pste_automatic_protocol_v1',[]);
        if(!is_array($log)||($log['contract']??'')!=='PSTE_AUTOMATIC_PROTOCOL_V1')$log=['contract'=>'PSTE_AUTOMATIC_PROTOCOL_V1','events'=>[]];
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        $baseline=is_array($baseline)?$baseline:[];
        $report=[
            'contract'=>'PSTE_AUTOMATIC_PROTOCOL_REPORT_V1',
            'generated_at_utc'=>gmdate('c'),
            'pste_version'=>PSTE_VERSION,
            'read_only'=>true,
            'no_provider_calls'=>true,
            'no_topic_or_portal_writes'=>true,
            'scope'=>'CURRENT_STORED_STATUS_AND_RECORDED_AUTOMATIC_STEPS',
            'note'=>'Historical decisions before installation cannot be recreated as exact past events.',
            'site_baseline'=>[
                'captured_at_utc'=>(string)($baseline['captured_at_utc']??''),
                'categories'=>(int)($baseline['category_count']??0),
                'leaf_categories'=>(int)($baseline['leaf_category_count']??0),
            ],
            'topic_state_groups'=>PSTE_Repository::automaticProtocolStatusMatrix(),
            'summary'=>PSTE_Repository::productionCandidateStats(),
            'events'=>array_values((array)($log['events']??[])),
        ];
        return $report;
    }

    /** Read-only legacy endpoint, retained for existing bookmarked requests. */
    public static function exportAutomaticProtocol(): void {
        PSTE_Auth::assertAdmin('pste_export_automatic_protocol',(string)($_POST['_wpnonce']??''));
        self::jsonDownload(self::automaticProtocolSnapshot(),'pste-ablaufprotokoll-'.gmdate('Ymd-His').'-utc.json');
    }

    /** All stages since this version, including compiler and persisted topic decisions. */
    public static function exportFlightProtocol(): void {
        PSTE_Auth::assertAdmin('pste_export_flight_protocol',(string)($_POST['_wpnonce']??''));
        self::jsonDownload(PSTE_Flight_Recorder::report(35),'pste-workflow-flugschreiber-'.gmdate('Ymd-His').'-utc.json');
    }


    public static function evidenceHistoryBatchAjax():void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_evidence_audit',(string)($_POST['nonce']??''));
            $cursor=isset($_POST['cursor'])&&is_string($_POST['cursor'])?substr($_POST['cursor'],0,130):'';
            $ceiling=isset($_POST['ceiling'])&&is_string($_POST['ceiling'])?substr($_POST['ceiling'],0,130):'';
            self::ajaxSuccess(PSTE_Flight_Recorder::historySummaryBatch($cursor,$ceiling),$level);
        }catch(Throwable $e){self::ajaxError($e,$level,400);}
    }

    /** Read-only status evidence. No state updates, provider calls or worker invocations. */
    public static function evidenceReadBatchAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_evidence_audit',(string)($_POST['nonce']??''));
            $cursor=isset($_POST['cursor'])?filter_var($_POST['cursor'],FILTER_VALIDATE_INT):0;
            $high=isset($_POST['max_id'])?filter_var($_POST['max_id'],FILTER_VALIDATE_INT):0;
            if($cursor===false||$high===false)throw new RuntimeException('PSTE_EVIDENCE_INVALID_REQUEST');
            $read=PSTE_Evidence_Audit::batch((int)$cursor,(int)$high);
            if((int)$cursor===0&&(int)$high===0){
                $read['workflow_status']=self::workflowDiagnosticsSnapshot();
                $read['automatic_protocol']=self::automaticProtocolSnapshot();
                $read['flight_report']=PSTE_Flight_Recorder::report(35);
                $read['shortpath_diagnostics']=self::shortPathDiagnosticsPayload('');
            }
            self::ajaxSuccess($read,$level);
        }catch(Throwable $e){self::ajaxError($e,$level,400);}
    }
    private static function renderEvidenceAuditControl(): void {
        $config=wp_json_encode(['ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('pste_evidence_audit')],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        echo '<section class="pste-box" style="margin-top:12px"><h3>Gesamtdiagnose</h3><p>Ein einziger Bericht: Workflow-Zustand, Automatik- und Kurzwegfehler, gespeicherte Entscheidungen und vollständige vorhandene Protokollhistorie. Nur lesen – keine neue Prüfung, keine Freigabe, keine Anbieteraufrufe.</p>';
        echo '<button type="button" class="button button-secondary" id="pste-evidence-start">Gesamtdiagnose herunterladen (nur lesen)</button> <span id="pste-evidence-progress" aria-live="polite"></span>';
        echo '<p id="pste-evidence-summary"></p><p id="pste-evidence-download-wrap" style="display:none"><a class="button button-secondary" id="pste-evidence-download-link" download>Diagnose-Datei direkt herunterladen</a></p></section>';
        $javascript=<<<'PSTE_EVIDENCE_JS'
(function () {
  'use strict';
  const btn = document.getElementById('pste-evidence-start');
  const progress = document.getElementById('pste-evidence-progress');
  const summaryEl = document.getElementById('pste-evidence-summary');
  const directLink = document.getElementById('pste-evidence-download-link');
  const linkWrap = document.getElementById('pste-evidence-download-wrap');
  if (!btn || !directLink || !linkWrap) return;

  let processing = false, cursor = 0, high = 0, state = null;
  let scanComplete = false, historyCursor = '', historyCeiling = '', blobUrl = null;
  function counter(map, key, n = 1) { map[key] = (map[key] || 0) + n; }
  function makeState() {
    return {
      contract: 'PSTE_STORED_DECISION_EVIDENCE_V3', read_only: true,
      generated_at_utc: '', topics: 0, expected_total: null,
      role_counts: {}, context_counts: {}, role_context_counts: {},
      role_pool_status_counts: {}, reason_codes_by_role: {}, flags_by_role: {},
      sample_topics_by_role: {},
      disclaimer: 'Counts describe persisted decisions only; they do not prove a duplicate is real. Historical write events cannot be reconstructed.'
    };
  }
  function accumulate(r) {
    const role = r.role || 'UNKNOWN'; state.topics++;
    counter(state.role_counts, role);
    counter(state.context_counts, r.context || 'UNKNOWN');
    counter(state.role_context_counts, role + ' | ' + (r.context || 'UNKNOWN'));
    counter(state.role_pool_status_counts, role + ' | ' + (r.pool_status || 'UNKNOWN'));
    if (!state.reason_codes_by_role[role]) state.reason_codes_by_role[role] = {};
    for (const reason of r.reason_codes || []) counter(state.reason_codes_by_role[role], reason);
    if (!state.flags_by_role[role]) state.flags_by_role[role] = {};
    for (const key of ['category_missing','payload_invalid','source_query_missing','reason_code_truncated'])
      if (r[key]) counter(state.flags_by_role[role], key);
    if (role === 'ALREADY_COVERED' && !r.coverage_code_present)
      counter(state.flags_by_role[role], 'coverage_evidence_code_absent');
    if (role === 'RESEARCH_KEYWORD' && r.normal_path === 'NORMAL_PASS')
      counter(state.flags_by_role[role], 'research_role_but_normal_path_pass');
    if (!state.sample_topics_by_role[role]) state.sample_topics_by_role[role] = [];
    if (state.sample_topics_by_role[role].length < 4) state.sample_topics_by_role[role].push(r.sample);
  }
  function ensureHistory() {
    if (!state.workflow_history) state.workflow_history = {
      contract: 'PSTE_FLIGHT_ALL_HISTORY_SUMMARY_V1', read_only: true,
      batches: 0, invalid_batches: 0, events: 0, groups: {}, errors: {},
      reasons: {}, mass_changes: [], complete: false
    };
    return state.workflow_history;
  }
  // A persistent, human-clickable link is a fallback if the browser rejects a
  // scripted download after many asynchronous requests. Keep it until replaced.
  function offerDownload(complete, autoClick) {
    state.generated_at_utc = new Date().toISOString();
    state.evidence_scan_complete = scanComplete;
    if (!complete) ensureHistory().complete = false;
    const json = JSON.stringify(state, null, 2);
    const nextUrl = URL.createObjectURL(new Blob([json], {type:'application/json;charset=utf-8'}));
    const oldUrl = blobUrl;
    blobUrl = nextUrl;
    directLink.href = nextUrl;
    directLink.download = 'pste-gesamtdiagnose-' + new Date().toISOString().slice(0, 10) +
      (complete ? '' : '-teilbericht') + '.json';
    directLink.textContent = complete ?
      'Gesamtdiagnose erneut herunterladen' :
      'Gesicherte Diagnose jetzt herunterladen (Historie noch unvollständig)';
    linkWrap.style.display = 'block';
    if (oldUrl) URL.revokeObjectURL(oldUrl);
    if (autoClick) {
      try { directLink.click(); }
      catch (error) { summaryEl.textContent = 'Datei vorbereitet. Bitte den direkten Download-Link anklicken.'; }
    }
  }
  async function request(action, values) {
    const body = new URLSearchParams(Object.assign({action, nonce:cfg.nonce}, values));
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 30000);
    let response;
    try {
      response = await fetch(cfg.ajax, {method:'POST',credentials:'same-origin',
        headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8','Accept':'application/json'},
        body:body.toString(), signal:ctrl.signal});
    } finally {clearTimeout(timer);}
    const raw = await response.text();
    let envelope;
    try {envelope = JSON.parse(raw.replace(/^\uFEFF/, '').trim());}
    catch (error) {throw Error('PSTE_EVIDENCE_AJAX_INVALID_JSON');}
    if (!response.ok || !envelope.success)
      throw Error((envelope.data && envelope.data.error_code) || 'PSTE_EVIDENCE_READ_FAILED');
    return envelope.data;
  }
  async function getHistoryPage() {
    // Retry only READ requests. Never rerun a production write or reset here.
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        return await request('pste_evidence_history_batch', {cursor:historyCursor, ceiling:historyCeiling});
      } catch (error) {
        if (attempt === 2) throw error;
        await new Promise(resolve => setTimeout(resolve, (attempt + 1) * 350));
      }
    }
  }
  async function summarizeHistory() {
    const history = ensureHistory();
    delete history.read_error_code;
    for (let n = 0; n < 100000; n++) {
      const page = await getHistoryPage();
      if (!page || page.contract !== 'PSTE_FLIGHT_HISTORY_PAGE_V1')
        throw Error('PSTE_FLIGHT_HISTORY_INVALID_BATCH');
      if (!historyCeiling) historyCeiling = page.ceiling || '';
      if (historyCeiling && (page.ceiling || '') !== historyCeiling)
        throw Error('PSTE_FLIGHT_HISTORY_CEILING_CHANGED');
      history.batches += page.batches || 0;
      history.invalid_batches += page.invalid_batches || 0;
      history.events += page.events || 0;
      for (const [key,count] of Object.entries(page.groups || {})) counter(history.groups,key,count);
      for (const [key,count] of Object.entries(page.errors || {})) counter(history.errors,key,count);
      for (const [key,count] of Object.entries(page.reasons || {})) counter(history.reasons,key,count);
      for (const row of page.mass_changes || [])
        if (history.mass_changes.length < 50) history.mass_changes.push(row);
      progress.textContent = 'Themen: ' + state.topics + ' · gespeicherte Arbeitsschritte: ' + history.events;
      if (!page.done && (!page.cursor || page.cursor === historyCursor))
        throw Error('PSTE_FLIGHT_HISTORY_CURSOR_NOT_ADVANCING');
      // Save the last cursor even for a final page. If its content is invalid,
      // retrying must not count that same page twice.
      if (page.cursor && page.cursor !== historyCursor) historyCursor = page.cursor;
      if (page.done) {history.complete = true; break;}
    }
    if (!history.complete) throw Error('PSTE_FLIGHT_HISTORY_PAGE_LIMIT');
    if (history.invalid_batches > 0)
      throw Error('PSTE_FLIGHT_HISTORY_CORRUPTED_BATCHES_' + history.invalid_batches);
  }
  async function scanTopics() {
    for (;;) {
      const data = await request('pste_evidence_read_batch', {cursor:String(cursor), max_id:String(high)});
      if (!data || data.contract !== 'PSTE_EVIDENCE_BATCH_V1' || data.max_id < high || data.cursor < cursor)
        throw Error('PSTE_EVIDENCE_BATCH_INVALID');
      if (!high) { high = data.max_id; state.expected_total = data.initial_total; }
      if (high !== data.max_id) throw Error('PSTE_EVIDENCE_CEILING_CHANGED');
      if (state.topics === 0) {
        if (data.workflow_status) state.workflow_status = data.workflow_status;
        if (data.automatic_protocol) state.automatic_protocol = data.automatic_protocol;
        if (data.shortpath_diagnostics) state.shortpath_diagnostics = data.shortpath_diagnostics;
        if (data.flight_report) state.workflow_trace = data.flight_report;
      }
      for (const r of data.rows || []) accumulate(r);
      cursor = data.cursor;
      progress.textContent = 'Themen: ' + state.topics +
        (state.expected_total === null ? '' : ' / ' + state.expected_total);
      if (data.done) {
        if (state.expected_total !== null && state.topics !== state.expected_total)
          throw Error('PSTE_EVIDENCE_TOTAL_CHANGED_DURING_SCAN');
        scanComplete = true;
        ensureHistory();
        offerDownload(false, false); // immediately available; history is NOT a download prerequisite
        summaryEl.textContent = 'Themen vollständig gelesen. Diagnose bereits direkt speicherbar. Historie wird ergänzt.';
        break;
      }
      if (!(data.rows || []).length) throw Error('PSTE_EVIDENCE_NO_FORWARD_PROGRESS');
      await new Promise(resolve => setTimeout(resolve, 40));
    }
  }
  btn.addEventListener('click', async () => {
    if (processing) return;
    processing = true; btn.disabled = true;
    if (!state) {state = makeState(); cursor = 0; high = 0; scanComplete = false;
      historyCursor = ''; historyCeiling = '';}
    try {
      if (!scanComplete) await scanTopics();
      try {
        await summarizeHistory();
        offerDownload(true, true);
        summaryEl.textContent = 'Gesamtdiagnose abgeschlossen: ' + state.topics +
          ' Themen, ' + state.workflow_history.events +
          ' gespeicherte Arbeitsschritte. Download angeboten; direkter Link bleibt verfügbar.';
        btn.textContent = 'Gesamtdiagnose neu einlesen';
        state = null; cursor = 0; high = 0; scanComplete = false;
        historyCursor = ''; historyCeiling = '';
      } catch (historyError) {
        const history = ensureHistory(); history.complete = false;
        history.read_error_code = String(historyError.message || 'PSTE_FLIGHT_HISTORY_READ_FAILED');
        offerDownload(false, true);
        summaryEl.textContent = 'Diagnose ohne vollständige Historie gesichert (' +
          history.read_error_code + '). Beim nächsten Klick nur die Historie fortsetzen, nicht die Themen erneut lesen.';
        btn.textContent = 'Nur Historie fortsetzen';
      }
    } catch (scanError) {
      summaryEl.textContent = 'Themenauswertung angehalten: ' +
        String(scanError.message || 'PSTE_EVIDENCE_READ_FAILED') +
        '. Erneuter Klick setzt sie am gespeicherten Stand fort.';
    } finally { processing = false; btn.disabled = false; }
  });
})();
PSTE_EVIDENCE_JS;
        echo '<script>(function(cfg){'.$javascript.'})('.$config.');</script>';
    }

    public static function productionAutoStatusAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{PSTE_Auth::assertAdmin('pste_production_auto_ajax',(string)($_POST['nonce']??''));self::automaticProtocolSuccess(self::productionAutoState(),$level);}
        catch(Throwable $e){self::ajaxError($e,$level,400);}
    }

    public static function productionAutoStepAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_production_auto_ajax',(string)($_POST['nonce']??''));
            $storage=PSTE_Storage_Maintenance::current();
            if(is_array($storage)&&in_array((string)($storage['status']??''),['RUNNING','PAUSED_ERROR'],true))throw new RuntimeException('PSTE_PRODUCTION_STORAGE_MAINTENANCE_ACTIVE');
            $queue=PSTE_Breadth_Research_Queue::peek();
            if(is_array($queue)&&in_array((string)($queue['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true)&&empty($queue['existing_only'])){
                $oldStatus=(string)($queue['status']??'');
                $driver=PSTE_Research_Driver::status();
                $staleReviewCodes=[
                    'PSTE_EXISTING_EVIDENCE_REENTRY_REVIEW_CANDIDATE_MISMATCH',
                    'PSTE_EXISTING_EVIDENCE_REENTRY_REVIEW_TITLE_MISMATCH',
                    'PSTE_EXISTING_EVIDENCE_REENTRY_REVIEW_RAW_MISMATCH',
                ];
                $driverCode=(string)($driver['last_error']??'');
                $queueCode=(string)($queue['last_error']??'');
                if($oldStatus!=='PAUSED_ERROR'||(string)($driver['status']??'')!=='BLOCKED'||
                    !in_array($driverCode,$staleReviewCodes,true)||
                    !in_array($queueCode,$staleReviewCodes,true))
                    throw new RuntimeException('PSTE_PRODUCTION_OTHER_RESEARCH_ACTIVE');
                // An already blocked prior provider wave is not an active provider request.
                // The existing requestCancel implementation fences child ownership, unresolved
                // provider outcomes and in-flight work. It retains prior keyword results.
                $oldUuid=trim((string)($queue['queue_uuid']??''));
                if($oldUuid==='')throw new RuntimeException('PSTE_PRODUCTION_OTHER_RESEARCH_QUEUE_ID_MISSING');
                $cancelled=PSTE_Breadth_Research_Queue::requestCancel($oldUuid);
                if((string)($cancelled['status']??'')!=='CANCELLED'){
                    // Do not claim processing succeeded while a provider operation remains unresolved.
                    self::automaticProtocolSuccess(['stage'=>'BESTAND','status'=>'WARTET','terminal'=>'','ready_count'=>0,'ready_items'=>[],
                        'progress_text'=>'Vorherige pausierte Recherche wird über den bestehenden sicheren Abbruch abgeschlossen.',
                        'error_code'=>'','publish_allowed'=>false],$level);
                    return;
                }
                $queue=PSTE_Breadth_Research_Queue::peek();
                if(!is_array($queue)||(string)($queue['status']??'')!=='CANCELLED')
                    throw new RuntimeException('PSTE_PRODUCTION_PREVIOUS_QUEUE_CANCEL_READBACK_MISMATCH');
            }
            $preflight=self::productionAutoPortalPreflightStep($queue);
            if($preflight){self::automaticProtocolSuccess(self::productionAutoState(),$level);return;}
            // Preflight may finish/rebind the real saved queue. Do not decide on
            // the snapshot read BEFORE preflight and accidentally start a second audit.
            $queue=PSTE_Breadth_Research_Queue::peek();
            if(is_array($queue)&&in_array((string)($queue['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){
                $qs=(string)($queue['status']??'');$uuid=(string)($queue['queue_uuid']??'');
                if(in_array($qs,['PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){
                    PSTE_Breadth_Research_Queue::requestExistingOnlyResume($uuid,PSTE_Plugin::settings());PSTE_Research_Driver::kick(0,'PRODUCTION_AUTOMATION_RESUME_EXISTING');
                }else{
                    $driver=PSTE_Research_Driver::status();
                    if(in_array((string)($driver['status']??''),['BLOCKED','IDLE'],true))PSTE_Research_Driver::kick(0,'PRODUCTION_AUTOMATION_RECOVER_EXISTING');
                }
                self::automaticProtocolSuccess(self::productionAutoState(),$level);return;
            }
            // A stopped duplicate audit must regain its signed checkpoint BEFORE the
            // compiler checks its completed receipt. Otherwise the UI stays CANCELLED
            // forever while repeated AJAX clicks silently advance the compiler.
            if(is_array($queue)&&!empty($queue['existing_only'])&&(string)($queue['status']??'')==='CANCELLED'){
                $restored=PSTE_Breadth_Research_Queue::startExistingOnly(200,PSTE_Plugin::settings());
                if((string)($restored['status']??'')==='RUNNING')PSTE_Research_Driver::kick(0,'PRODUCTION_AUTOMATION_RESUME_EXISTING');
                self::automaticProtocolSuccess(self::productionAutoState(),$level);return;
            }
            if(!class_exists('PSERC_Plan_Compile_Job')||!class_exists('PSERC_Plan_Snapshot_Store')||!class_exists('PSERC_Plan_Dependency_Fingerprint'))throw new RuntimeException('PSTE_PRODUCTION_PSERC_REQUIRED');
            // A currently valid *compiler* snapshot cannot replace an outdated
            // semantic audit. Test the audit fingerprint BEFORE short-circuiting
            // to a previously READY compiler generation or advancing an old job.
            // The completed existing-only audit is signed. Never bootstrap a fixed
            // legacy 110-topic fixture or silently re-sign the entire audit here.
            // Existing safe reentries remain available through their original explicit path.
            $auditCurrent=PSTE_Breadth_Research_Queue::existingOnlyAuditCurrent();
            if(!$auditCurrent){
                // Previous entire source audit is signed and its data are unchanged:
                // an updated editorial plan must not force the full backlog replay.
                // All other drift remains fail-closed with the saved queue untouched.
                $auditCurrent=PSTE_Breadth_Research_Queue::reuseCompletedAuditForEditorialPlanOnly();
            }
            if(!$auditCurrent){
                // The driver can finish or resume a 4,880-row checkpoint between
                // the two existing readbacks. Prefer that persisted queue over
                // launching another full 5,014-row pass.
                $latest=PSTE_Breadth_Research_Queue::peek();
                if(is_array($latest)&&!empty($latest['existing_only'])&&
                    in_array((string)($latest['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){
                    self::automaticProtocolSuccess(self::productionAutoState(),$level);return;
                }
                PSTE_Breadth_Research_Queue::startExistingOnly(200,PSTE_Plugin::settings());PSTE_Research_Driver::kick(0,'PRODUCTION_AUTOMATION_START_EXISTING');
                self::automaticProtocolSuccess(self::productionAutoState(),$level);return;
            }
            $job=PSERC_Plan_Snapshot_Store::getJob();
            if(($job['contract']??'')===PSERC_Plan_Compile_Job::CONTRACT&&(string)($job['status']??'')==='RUNNING'){
                $view=PSERC_Plan_Compile_Job::advance();if((string)($view['status']??'')==='BLOCKED')throw new RuntimeException((string)($view['error_code']??'PSERC_PLAN_BUILD_BLOCKED'));
                self::automaticProtocolSuccess(self::productionAutoState(),$level);return;
            }
            $active=PSERC_Plan_Snapshot_Store::getActive();
            if(PSERC_Plan_Snapshot_Store::verifyHeader($active)&&PSERC_Plan_Dependency_Fingerprint::isCurrent((array)($active['dependency']??[]))){self::automaticProtocolSuccess(self::productionAutoState(),$level);return;}
            $view=PSERC_Plan_Compile_Job::start();if((string)($view['status']??'')==='BLOCKED')throw new RuntimeException((string)($view['error_code']??'PSERC_PLAN_BUILD_BLOCKED'));
            self::automaticProtocolSuccess(self::productionAutoState(),$level);
        }catch(Throwable $e){
            // Another server request can own the same bounded topic-pool step.
            // This is transient coordination, not proof that the production failed.
            // Never clear/steal the lock or start a competing worker here.
            $coordinationCodes=['PSTE_BREADTH_QUEUE_STEP_ALREADY_RUNNING',
                'PSTE_RESEARCH_CONTROL_START_LOCKED','PSTE_BREADTH_QUEUE_ALREADY_ACTIVE',
                'PSTE_EXISTING_ONLY_RESUME_STATE_INVALID'];
            if(in_array((string)$e->getMessage(),$coordinationCodes,true)){
                try{
                    $current=PSTE_Breadth_Research_Queue::peek();
                    $lock=PSTE_Breadth_Research_Queue::queueLockStatus();
                    $queueStatus=(string)($current['status']??'');
                    // Only a proven active existing-only queue is retryable.
                    // A stale error and missing owner are NEVER treated as progress.
                    if(is_array($current)&&!empty($current['existing_only'])&&
                        ($queueStatus==='RUNNING'||($queueStatus==='PAUSED_ERROR'&&!empty($lock['locked'])))){
                        $result=self::productionAutoState();
                        $result['stage']='BESTAND';$result['status']='WARTET';$result['terminal']='';
                        $result['progress_text']='Ein bestehender Prüfschritt arbeitet bereits. Es wurde kein zweiter gestartet.';
                        $result['error_code']='';
                        self::automaticProtocolSuccess($result,$level);return;
                    }
                }catch(Throwable $ignored){/* preserve the explicit error if state cannot be verified */}
            }
            // A concurrent local worker may have saved a RUNNING queue after an
            // older COMPLETE snapshot rejected an append-only restart. This is
            // not evidence of stopped work: read its signed current state once.
            if((string)$e->getMessage()==='PSTE_EXISTING_ONLY_COMPLETED_AUDIT_CHANGED_PROGRESS_PRESERVED'){
                try{
                    $saved=PSTE_Breadth_Research_Queue::peek();
                    if(is_array($saved)&&!empty($saved['existing_only'])&&
                        (string)($saved['status']??'')==='RUNNING'&&
                        (int)($saved['local_backlog_processed']??0)>0){
                        self::automaticProtocolSuccess(self::productionAutoState(),$level);return;
                    }
                }catch(Throwable $ignored){/* retain original explicit failure */}
            }
            self::automaticProtocolError($e,$level);
        }
    }

    /**
     * One-click preflight owned by Automatik. It first tries the compact rebind proven by the
     * existing completed context index. A full bounded context refresh is used only when no such
     * completed compact source exists. No provider call is allowed in either path.
     */
    private static function productionAutoPortalPreflightStep(?array $queue=null): bool {
        // Existing in-flight context owns its immutable baseline and its request-bounded steps.
        // Finish its recorded state first; final freshness gates still verify structure,
        // inventory and editorial plan before COMPLETE. Do not rebase before advancing it.
        $activeContext=PSTE_Context_Refresh::status();
        $activeStatus=(string)($activeContext['status']??'NOT_STARTED');
        if(in_array($activeStatus,['PENDING','RUNNING'],true)){
            if(!PSTE_Plugin::isReady())throw new RuntimeException('PSTE_PRODUCTION_SAFE_BOOT_NOT_READY');
            $next=PSTE_Context_Refresh::processBatch();
            if((string)($next['status']??'')==='BLOCKED')throw new RuntimeException((string)($next['error_code']??'PSTE_PRODUCTION_CONTEXT_REFRESH_BLOCKED'));
            if(!empty($next['_pste_lease_waiting'])){
                // Never present a lock-denied no-op as a successful context step.
                // The lease is fenced: never delete/steal an unexpired lock.
                $now=time();$expires=(int)($next['_pste_lease_expires_at']??0);
                $updated=strtotime((string)($next['updated_at_utc']??''));
                if($expires<=0||$expires<=$now)throw new RuntimeException('PSTE_CONTEXT_LEASE_REACQUIRE_FAILED');
                if($expires>$now+125)throw new RuntimeException('PSTE_CONTEXT_LEASE_EXPIRY_INVALID');
                if($updated===false||$now-$updated>150)throw new RuntimeException('PSTE_CONTEXT_LEASE_NO_PROGRESS');
                return true; // A recent legitimately busy cron/AJAX request may finish shortly.
            }
            if(!in_array((string)($next['status']??''),['PENDING','RUNNING','COMPLETE'],true))throw new RuntimeException('PSTE_PRODUCTION_CONTEXT_STEP_STATE_INVALID');
            return true;
        }
        if($activeStatus==='BLOCKED'){
            // The context worker already has a guarded final-structure resume. Route the existing
            // Automatik button through that worker instead of permanently rejecting its job.
            if(PSTE_Context_Refresh::isResumableBlockedFinalStructure($activeContext)){
                $preflight=PSTE_Runner::productionAutomationBaselinePreflight();
                if(!empty($preflight['full_context_refresh_required'])||!empty($preflight['changed'])){
                    // A genuinely changed portal structure cannot use the old immutable context
                    // index. Use the existing normal baseline capture; never reuse stale slots.
                    $fresh=PSTE_Runner::captureSiteBaseline();
                    if((string)($fresh['status']??'')!=='CURRENT')throw new RuntimeException('PSTE_PRODUCTION_FRESH_STRUCTURE_INVALID');
                    return true;
                }
                $next=PSTE_Context_Refresh::processBatch();
                if((string)($next['status']??'')==='BLOCKED')throw new RuntimeException((string)($next['error_code']??'PSTE_PRODUCTION_CONTEXT_REFRESH_BLOCKED'));
                if(!empty($next['_pste_lease_waiting']))throw new RuntimeException('PSTE_CONTEXT_RESUME_LEASE_BUSY');
                return true;
            }
            if(PSTE_Context_Refresh::isResumableBlockedSandboxStore($activeContext)){
                $next=PSTE_Context_Refresh::processBatch();
                if((string)($next['status']??'')==='BLOCKED')throw new RuntimeException((string)($next['error_code']??'PSTE_PRODUCTION_CONTEXT_REFRESH_BLOCKED'));
                if(!empty($next['_pste_lease_waiting']))throw new RuntimeException('PSTE_CONTEXT_RESUME_LEASE_BUSY');
                return true;
            }
            throw new RuntimeException((string)($activeContext['error_code']??'PSTE_PRODUCTION_CONTEXT_REFRESH_BLOCKED'));
        }
        $result=PSTE_Runner::productionAutomationBaselinePreflight();
        if(!empty($result['full_context_refresh_required'])){
            $context=PSTE_Context_Refresh::status();$status=(string)($context['status']??'NOT_STARTED');
            if(in_array($status,['PENDING','RUNNING'],true)){
                $next=PSTE_Context_Refresh::processBatch();if((string)($next['status']??'')==='BLOCKED')throw new RuntimeException((string)($next['error_code']??'PSTE_PRODUCTION_CONTEXT_REFRESH_BLOCKED'));return true;
            }
            if($status==='BLOCKED')throw new RuntimeException((string)($context['error_code']??'PSTE_PRODUCTION_CONTEXT_REFRESH_BLOCKED'));
            PSTE_Runner::captureSiteBaseline();return true;
        }
        if(!empty($result['changed'])){
            if(is_array($queue)&&!empty($queue['existing_only'])&&in_array((string)($queue['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){
                PSTE_Breadth_Research_Queue::rebindExistingOnlyForProduction((string)($queue['queue_uuid']??''));PSTE_Research_Driver::kick(0,'PRODUCTION_AUTOMATION_COMPACT_REBIND_EXISTING');
            }
            return true;
        }
        $context=PSTE_Context_Refresh::status();$status=(string)($context['status']??'NOT_STARTED');
        if(in_array($status,['PENDING','RUNNING'],true)){
            $next=PSTE_Context_Refresh::processBatch();if((string)($next['status']??'')==='BLOCKED')throw new RuntimeException((string)($next['error_code']??'PSTE_PRODUCTION_CONTEXT_REFRESH_BLOCKED'));return true;
        }
        if($status==='BLOCKED')throw new RuntimeException((string)($context['error_code']??'PSTE_PRODUCTION_CONTEXT_REFRESH_BLOCKED'));
        return false;
    }

    public static function productionAutoCancelAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_production_auto_ajax',(string)($_POST['nonce']??''));
            $queue=PSTE_Breadth_Research_Queue::peek();
            if(is_array($queue)&&!empty($queue['existing_only'])&&in_array((string)($queue['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){
                $queue=PSTE_Breadth_Research_Queue::requestCancel((string)($queue['queue_uuid']??''));
                if((string)($queue['status']??'')==='CANCELLED')PSTE_Research_Driver::kick(0,'PRODUCTION_AUTOMATION_CANCEL_RECONCILE');
            }
            $state=self::productionAutoState();$state['status']='ANGEHALTEN';$state['terminal']='PAUSED';$state['progress_text']='Gespeicherter Stand bleibt erhalten. Derselbe Knopf setzt später fort.';
            self::ajaxSuccess($state,$level);
        }catch(Throwable $e){self::ajaxError($e,$level,400);}
    }

    /** One read-only status projection for the existing two-stage production path. */
    private static function productionAutoState(): array {
        $now=time();$base=['stage'=>'BEREIT','status'=>'BEREIT','terminal'=>'','ready_count'=>0,'ready_items'=>[],'progress_text'=>'Vorhandenes Potenzial kann verarbeitet werden.','started_at_utc'=>'','last_activity_utc'=>'','elapsed_seconds'=>0,'last_activity_age_seconds'=>0,'error_code'=>''];
        $queue=null;try{$queue=PSTE_Breadth_Research_Queue::peek();}catch(Throwable $e){return array_merge($base,['stage'=>'BESTAND','status'=>'BLOCKIERT','terminal'=>'BLOCKED','error_code'=>'PSTE_BREADTH_QUEUE_EVIDENCE_INVALID','progress_text'=>'Gespeicherter Prüfstand ist nicht verifizierbar. Keine automatische Fortsetzung.']);}
        $driver=[];try{$driver=PSTE_Research_Driver::status();}catch(Throwable $ignored){}
        $context=[];try{$context=PSTE_Context_Refresh::status();}catch(Throwable $ignored){}
        $contextStatus=(string)($context['status']??'');if(in_array($contextStatus,['PENDING','RUNNING'],true)) {
            $processed=(int)($context['processed']??0);$total=(int)($context['total']??0);$phase=(string)($context['phase']??'PORTALABGLEICH');$started=(string)($context['started_at_utc']??'');$updated=(string)($context['updated_at_utc']??'');
            $detail='Portalstruktur wird intern abgeglichen · '.$processed.($total>0?' / '.$total:'').' · '.$phase;
            if($phase==='PAYLOAD_INTEGRITY_AUDIT')$detail.=' · Bestandsprüfung '.(int)($context['payload_repair_cursor']??0).' / '.(int)($context['payload_repair_total']??$total);
            if($phase==='SANDBOX_RECORD_STORE_MIGRATION'){
                $migrationStatus=(string)($context['sandbox_record_store_migration_status']??'PENDING');
                $sandboxTotal=(int)($context['sandbox_record_store_count']??0);
                if($migrationStatus==='HASH_VERIFY'){
                    $detail.=' · Sandbox-Hashprüfung '.(int)($context['sandbox_record_store_verification_cursor']??0).' / '.$sandboxTotal;
                }else{
                    $detail.=' · Sandbox '.$migrationStatus.' · Datensätze '.(int)($context['sandbox_record_store_migration_cursor']??0).' / '.$sandboxTotal;
                }
            }
            if($phase==='SANDBOX_BINDING_BATCH')$detail.=' · Sandbox-Bindung '.(int)($context['sandbox_processed']??0).' / '.(int)($context['sandbox_total']??0);
            $idle=self::secondsSince($updated,$now);$stale=$idle>=180;
            return array_merge($base,['stage'=>'PORTALABGLEICH','status'=>$stale?'STOCKT (GESPEICHERT)':$contextStatus,'terminal'=>$stale?'BLOCKED':'','progress_text'=>$detail.($stale?' · Seit 180 Sekunden keine gespeicherte Aktivität.':''),'started_at_utc'=>$started,'last_activity_utc'=>$updated,'elapsed_seconds'=>self::secondsSince($started,$now),'last_activity_age_seconds'=>$idle,'error_code'=>$stale?'PSTE_PORTALABGLEICH_180S_OHNE_AKTIVITAET':'']);
        }
        if((string)($context['status']??'')==='BLOCKED')return array_merge($base,['stage'=>'PORTALABGLEICH','status'=>'BLOCKIERT','terminal'=>'BLOCKED','error_code'=>(string)($context['error_code']??'PSTE_PRODUCTION_CONTEXT_REFRESH_BLOCKED'),'progress_text'=>'Portalstruktur konnte nicht sicher abgeglichen werden.']);
        if(is_array($queue)&&in_array((string)($queue['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){
            if(empty($queue['existing_only']))return array_merge($base,['stage'=>'BESTAND','status'=>'BLOCKIERT','terminal'=>'BLOCKED','error_code'=>'PSTE_PRODUCTION_OTHER_RESEARCH_ACTIVE','progress_text'=>'Eine andere Recherche läuft.']);
            $started=(string)($queue['created_at_utc']??'');$updated=(string)($queue['updated_at_utc']??'');$processed=(int)($queue['local_backlog_processed']??0);$total=(int)($queue['local_backlog_total']??0);$titles=(int)($queue['local_backlog_title_candidates']??0);$usable=(int)($queue['usable_candidate_count']??0);$qs=(string)($queue['status']??'RUNNING');$driverStatus=(string)($driver['status']??'');$error=(string)($queue['last_error']??'');
            if($driverStatus==='BLOCKED'&&$error==='')$error=(string)($driver['last_error']??$driver['health_code']??'PSTE_RESEARCH_DRIVER_BLOCKED');
            $prior=(array)($queue['previous_completed_queue']??[]);
            $oldCount=(string)($prior['status']??'')==='COMPLETE'?(int)($prior['local_backlog_processed']??0):0;
            $history=$oldCount>0?' · Vorheriger abgeschlossener Prüfstand: '.$oldCount.' Zeilen erhalten':'';
            $reason=(string)($queue['logic_recheck_source']??'');
            if(in_array($reason,['SEMANTIC_LOGIC_CHANGED','AUDIT_EVIDENCE_RECHECK'],true))$history.=' · Aktueller Zähler: Neubewertung nach Regeländerung';
            $age=self::secondsSince($updated,$now);
            $stale=$qs==='RUNNING'&&$age>=180;
            // Read-only diagnosis. Neither history nor existing checkpoints are changed.
            if($stale&&$error==='')$error='PSTE_BESTANDSLAUF_180S_OHNE_GESPEICHERTEN_SCHRITT';
            $terminal=($stale||$qs==='PAUSED_ERROR'||$qs==='OUTCOME_UNKNOWN'||$driverStatus==='BLOCKED')?'BLOCKED':'';
            return array_merge($base,['stage'=>'BESTAND','status'=>$stale?'STOCKT (GESPEICHERT)':($driverStatus==='BLOCKED'?'BLOCKIERT (GESPEICHERT)':$qs),'terminal'=>$terminal,'progress_text'=>$processed.($total>0?' / '.$total:'').' Bestandszeilen dieser Prüfung · '.$titles.' neue Titelkandidaten · '.$usable.' neu planbar'.$history,'started_at_utc'=>$started,'last_activity_utc'=>$updated,'elapsed_seconds'=>self::secondsSince($started,$now),'last_activity_age_seconds'=>$age,'error_code'=>$error]);
        }
        if(is_array($queue)&&!empty($queue['existing_only'])&&(string)($queue['status']??'')==='CANCELLED'){
            $processed=(int)($queue['local_backlog_processed']??0);$total=(int)($queue['local_backlog_total']??0);
            $started=(string)($queue['created_at_utc']??'');$updated=(string)($queue['updated_at_utc']??'');
            return array_merge($base,['stage'=>'BESTAND','status'=>'ANGEHALTEN','terminal'=>'PAUSED',
                'progress_text'=>$processed.($total>0?' / '.$total:'').' Bestandszeilen gespeichert · '.(int)($queue['local_backlog_title_candidates']??0).' neue Titelkandidaten. Fortsetzen behält den bestätigten Stand.',
                'started_at_utc'=>$started,'last_activity_utc'=>$updated,'elapsed_seconds'=>self::secondsSince($started,$now),'last_activity_age_seconds'=>self::secondsSince($updated,$now)]);
        }
        if(!class_exists('PSERC_Plan_Compile_Job')||!class_exists('PSERC_Plan_Snapshot_Store')||!class_exists('PSERC_Plan_Dependency_Fingerprint'))return array_merge($base,['stage'=>'REDAKTIONSPLAN','status'=>'BLOCKIERT','terminal'=>'BLOCKED','error_code'=>'PSTE_PRODUCTION_PSERC_REQUIRED','progress_text'=>'Redaktionsplan-Compiler nicht verfügbar.']);
        $active=PSERC_Plan_Snapshot_Store::getActive();
        if(PSERC_Plan_Snapshot_Store::verifyHeader($active)&&PSERC_Plan_Dependency_Fingerprint::isCurrent((array)($active['dependency']??[]))){
            // The compiler's signed snapshot alone does not prove the earlier PSTE
            // thematic audit is current. The SAME source-of-truth guard already
            // used by the automation step must govern the displayed READY state.
            try{$auditCurrent=PSTE_Breadth_Research_Queue::existingOnlyAuditCurrent();}
            catch(Throwable $e){return array_merge($base,['stage'=>'BESTAND','status'=>'BLOCKIERT','terminal'=>'BLOCKED',
                'error_code'=>'PSTE_PRODUCTION_AUDIT_EVIDENCE_INVALID',
                'progress_text'=>'Gespeicherte Bestandsprüfung ist nicht verifizierbar. Keine Freigabe alter Ergebnisse.']);}
            if(!$auditCurrent)return array_merge($base,['stage'=>'BESTAND','status'=>'AKTUALISIERUNG ERFORDERLICH','terminal'=>'',
                'ready_count'=>0,'ready_items'=>[],
                'progress_text'=>'Ein alter Redaktionsplan bleibt erhalten, ist aber nicht freigegeben. Automatik aktualisiert zuerst die Themenentscheidungen.']);
            $batch=PSERC_Plan_Snapshot_Store::materializeReadyBatch($active);$count=(int)($batch['item_count']??0);
            if($count<=0)return array_merge($base,['stage'=>'REDAKTIONSPLAN','status'=>'ABGESCHLOSSEN','terminal'=>'NO_READY','ready_count'=>0,'progress_text'=>'Prüfung vollständig. Aktuell 0 Artikel freigegeben.']);
            // PSERC has already made the single READY decision and signed its current
            // source dependency. Do not recompute title/category/type against a later
            // PSTE display projection: that would silently discard approved rows.
            self::validateK0ReadyBatch($batch);
            $items=array_values((array)$batch['items']);
            return array_merge($base,['stage'=>'DATEI','status'=>$count>0?'BEREIT':'ABGESCHLOSSEN','terminal'=>$count>0?'READY':'NO_READY','ready_count'=>$count,'ready_items'=>$items,'progress_text'=>$count>0?$count.' Artikel sind für die Produktion freigegeben.':'Keine aktuellen Automatik-Artikel freigegeben.']);
        }
        $job=PSERC_Plan_Snapshot_Store::getJob();
        if(($job['contract']??'')===PSERC_Plan_Compile_Job::CONTRACT){
            $js=(string)($job['status']??'');$phase=(string)($job['phase']??'');$started=(string)($job['started_at_utc']??'');$updated=(string)($job['updated_at_utc']??'');$progress='Phase '.$phase.' · Kandidaten '.(int)($job['candidate_index']??0).' / '.(int)($job['eligible_count']??0).' · vorbereitet '.(int)($job['prepared_count']??0);
            return array_merge($base,['stage'=>'REDAKTIONSPLAN','status'=>$js!==''?$js:'BEREIT','terminal'=>$js==='BLOCKED'?'BLOCKED':'','ready_count'=>(int)($job['ready_count']??0),'progress_text'=>$progress,'started_at_utc'=>$started,'last_activity_utc'=>$updated,'elapsed_seconds'=>self::secondsSince($started,$now),'last_activity_age_seconds'=>self::secondsSince($updated,$now),'error_code'=>(string)($job['error_code']??'')]);
        }
        if(is_array($queue)&&!empty($queue['existing_only'])&&(string)($queue['status']??'')==='COMPLETE')return array_merge($base,['stage'=>'BESTAND','status'=>'ABGESCHLOSSEN','progress_text'=>(int)($queue['local_backlog_processed']??0).' Bestandszeilen geprüft. Redaktionsplanprüfung ist der nächste automatische Schritt.']);
        return $base;
    }

    private static function secondsSince(string $utc,int $now): int {$t=$utc!==''?(strtotime($utc)?:0):0;return $t>0?max(0,$now-$t):0;}

    public static function connectionTest(): void {PSTE_Auth::assertAdmin('pste_connection_test',(string)($_POST['_wpnonce']??''));$s=PSTE_Plugin::settings();try{$r=PSTE_Runner::connectionTest($s['environment']);PSTE_Credentials::recordConnectionSuccess($s['environment']);set_transient('pste_connection_test_result',$r,300);self::redirect('sources','connection_ok=1');}catch(Throwable $e){PSTE_Credentials::recordConnectionError($s['environment'],$e->getMessage());self::blocked('sources',$e);}}
    public static function saveGscClient(): void {try{PSTE_Auth::assertAdmin('pste_save_gsc_client',(string)($_POST['_wpnonce']??''));PSTE_GSC_Credentials::saveClient((string)($_POST['client_id']??''),(string)($_POST['client_secret']??''));self::redirect('sources','gsc_client_saved=1');}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function gscConnect(): void {try{PSTE_Auth::assertAdmin('pste_gsc_connect',(string)($_POST['_wpnonce']??''));wp_safe_redirect(PSTE_GSC_Client::authorizationUrl());exit;}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function gscOauthCallback(): void {try{PSTE_Auth::assertAdmin();if(!empty($_GET['error']))throw new RuntimeException('PSTE_GSC_OAUTH_'.sanitize_key((string)$_GET['error']));PSTE_GSC_Client::handleCallback(sanitize_text_field((string)($_GET['code']??'')),sanitize_text_field((string)($_GET['state']??'')));self::redirect('sources','gsc_connected=1');}catch(Throwable $e){PSTE_GSC_Credentials::recordStatus('ERROR',$e->getMessage(),null);self::blocked('sources',$e);}}
    public static function gscTest(): void {try{PSTE_Auth::assertAdmin('pste_gsc_test',(string)($_POST['_wpnonce']??''));PSTE_GSC_Client::listSites();PSTE_GSC_Credentials::recordStatus('CONNECTED',null,null);self::redirect('sources','gsc_test_ok=1');}catch(Throwable $e){PSTE_GSC_Credentials::recordStatus('ERROR',$e->getMessage(),null);self::blocked('sources',$e);}}
    public static function gscSaveProperty(): void {try{PSTE_Auth::assertAdmin('pste_gsc_save_property',(string)($_POST['_wpnonce']??''));$url=sanitize_text_field((string)($_POST['property_url']??''));$sites=get_option(PSTE_OPTION_GSC_SITES_CACHE,[]);$allowed=array_column($sites['items']??[],'site_url');if($url===''||!in_array($url,$allowed,true))throw new RuntimeException('PSTE_GSC_PROPERTY_NOT_ALLOWED');update_option(PSTE_OPTION_GSC_SELECTED_PROPERTY,$url,false);self::redirect('sources','gsc_property_saved=1');}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function gscSync(): void {try{PSTE_Auth::assertAdmin('pste_gsc_sync',(string)($_POST['_wpnonce']??''));$property=(string)get_option(PSTE_OPTION_GSC_SELECTED_PROPERTY,'');PSTE_Runner::syncSearchConsole($property,sanitize_text_field((string)($_POST['start_date']??'')),sanitize_text_field((string)($_POST['end_date']??'')));self::redirect('sources','gsc_synced=1');}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function gscDisconnect(): void {PSTE_Auth::assertAdmin('pste_gsc_disconnect',(string)($_POST['_wpnonce']??''));PSTE_GSC_Credentials::disconnect();self::redirect('sources','gsc_disconnected=1');}
    public static function saveCategoryWeights(): void {try{PSTE_Auth::assertAdmin('pste_save_category_weights',(string)($_POST['_wpnonce']??''));PSTE_Analytics::saveStrategicWeights(is_array($_POST['weights']??null)?$_POST['weights']:[]);self::redirect('settings','weights_saved=1');}catch(Throwable $e){self::blocked('settings',$e);}}
    public static function importEditorialPlan(): void {
        PSTE_Auth::assertAdmin('pste_import_editorial_plan',(string)($_POST['_wpnonce']??''));
        if(empty($_FILES['editorial_plan_json']['tmp_name'])||!is_uploaded_file($_FILES['editorial_plan_json']['tmp_name']))wp_die('PSTE_EDITORIAL_PLAN_UPLOAD_MISSING');
        try{
            $raw=(string)file_get_contents($_FILES['editorial_plan_json']['tmp_name']);
            $decoded=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
            if(!is_array($decoded))throw new RuntimeException('PSTE_EDITORIAL_PLAN_JSON_INVALID');

            // Same upload surface also accepts the general category/research ownership handoff.
            // It is stored separately and never masquerades as an already planned article list.
            $handoff=class_exists('PSTE_Article_Ownership_Gate')?PSTE_Article_Ownership_Gate::extractHandoff($decoded):null;
            if(is_array($handoff)){
                $snapshot=PSTE_Article_Ownership_Gate::normalizeHandoff($handoff);
                $snapshot['imported_at_utc']=gmdate('c');
                $snapshot['snapshot_sha256']=self::ownershipSnapshotHash($snapshot);
                update_option(PSTE_OPTION_EDITORIAL_OWNERSHIP_IMPORT,$snapshot,false);
                self::redirect('sources','editorial_ownership_imported=1');
                return;
            }

            $items=[];if(isset($decoded['items'])&&is_array($decoded['items']))$items=$decoded['items'];elseif(isset($decoded['articles'])&&is_array($decoded['articles']))$items=$decoded['articles'];elseif(isset($decoded['next_textmachine_metadata_batch']['items'])&&is_array($decoded['next_textmachine_metadata_batch']['items']))$items=$decoded['next_textmachine_metadata_batch']['items'];elseif(self::isList($decoded))$items=$decoded;
            if(!$items)throw new RuntimeException('PSTE_EDITORIAL_PLAN_ITEMS_MISSING');
            $clean=[];foreach($items as $item){if(!is_array($item))continue;$title=trim((string)($item['title']??$item['primary_longtail_query']??$item['article_title']??''));if($title==='')continue;$planSlot=trim((string)($item['plan_slot']??$item['plan_slot_sha256']??''));$clean[]=['title'=>$title,'primary_longtail_query'=>(string)($item['primary_longtail_query']??$title),'target_keyword'=>(string)($item['target_keyword']??''),'category_id'=>(int)($item['category_id']??$item['target_category_id']??0),'category_name'=>(string)($item['category_name']??$item['target_category_name']??''),'category_slug'=>(string)($item['category_slug']??$item['target_category_slug']??$item['category']??''),'article_type'=>(string)($item['article_type']??''),'topic_family_name'=>(string)($item['topic_family_name']??''),'topic_family_key'=>(string)($item['topic_family_key']??''),'intent_cluster_id'=>(string)($item['intent_cluster_id']??''),'headings'=>is_array($item['headings']??null)?array_values($item['headings']):[],'canonical_article_id'=>(string)($item['canonical_article_id']??''),'plan_slot'=>$planSlot,'plan_slot_sha256'=>$planSlot,'source_reference'=>(string)($item['canonical_article_id']??($planSlot!==''?$planSlot:'')),'status'=>(string)($item['status']??'PLANNED')];}
            if(!$clean)throw new RuntimeException('PSTE_EDITORIAL_PLAN_VALID_ITEMS_MISSING');
            update_option(PSTE_OPTION_EDITORIAL_PLAN_IMPORT,['contract'=>'PSTE_IMPORTED_EDITORIAL_PLAN_V1','imported_at_utc'=>gmdate('c'),'items'=>$clean],false);
            self::redirect('sources','editorial_plan_imported=1');
        }catch(Throwable $e){self::blocked('sources',$e);}
    }

    private static function ownershipSnapshotHash(array $snapshot): string {
        unset($snapshot['snapshot_sha256']);
        $stable=function($v)use(&$stable){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map($stable,$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=$stable($x);return $v;};
        $snapshot=$stable($snapshot);$json=wp_json_encode($snapshot,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($json))throw new RuntimeException('PSTE_EDITORIAL_OWNERSHIP_HASH_FAILED');return hash('sha256',$json);
    }

    public static function reviewCandidate(): void {
        PSTE_Auth::assertAdmin('pste_review_candidate',(string)($_POST['_wpnonce']??''));
        try{$poolKey=sanitize_text_field((string)($_POST['pool_key']??''));$status=sanitize_key((string)($_POST['review_status']??''));$status=strtoupper($status);$categoryId=(int)($_POST['target_category_id']??0);$categoryName=sanitize_text_field((string)($_POST['target_category_name']??''));if($categoryId<=0&&$categoryName!=='')$categoryId=PSTE_Repository::categoryIdFromName($categoryName);$articleType=sanitize_text_field((string)($_POST['target_article_type']??''));$note=sanitize_text_field((string)($_POST['review_note']??''));
            // Reuse the existing manual decision / category reentry, never invent a new routing authority.
            if(in_array($status,['ROUTE_FACH','ROUTE_MAGAZIN','ROUTE_REVIEW'],true)){
                // Same context safety as the existing review UI; fail closed on forged/stale forms.
                global $wpdb;$table=PSTE_Repository::table('topic_pool');
                $row=$wpdb->get_row($wpdb->prepare("SELECT context_state,payload_json FROM $table WHERE pool_key=%s",$poolKey),ARRAY_A);
                if(!is_array($row)||!in_array((string)($row['context_state']??''),['CURRENT','NOT_REQUIRED'],true))throw new RuntimeException('PSTE_MANUAL_AREA_CONTEXT_NOT_CURRENT');
                $area=$status==='ROUTE_FACH'?'FACH':($status==='ROUTE_MAGAZIN'?'MAGAZIN':'UNDECIDED');
                if($area==='UNDECIDED'||$categoryId<=0){
                    $status='REVIEW_REQUIRED';$categoryId=0;$articleType='';
                    $note=trim('Bereichsvormerkung: '.($area==='FACH'?'Hauptnavigation':($area==='MAGAZIN'?'Magazin':'noch ungeklärt')).'. Kategorie offen. '.$note);
                }else{
                    // A manual click may never override a genuine hard/quality/signed block.
                    $payload=json_decode((string)($row['payload_json']??''),true);
                    if(!is_array($payload))throw new RuntimeException('PSTE_MANUAL_AREA_TOPIC_EVIDENCE_MISSING');
                    if(PSTE_Topic_Policy::presentHardCodes($payload)||PSTE_Topic_Policy::presentNonOverridableCodes($payload))throw new RuntimeException('PSTE_MANUAL_AREA_HARD_BLOCK_REVIEW_REQUIRED');
                    $term=function_exists('get_term')?get_term($categoryId,'category'):null;
                    if(!$term||(function_exists('is_wp_error')&&is_wp_error($term))||($term->taxonomy??'')!=='category')throw new RuntimeException('PSTE_MANUAL_AREA_CATEGORY_NOT_CURRENT');
                    $slug=trim((string)($term->slug??''));$journalSlugs=[];
                    foreach((array)(PSTE_Journal_Article_Type::definition()['journal_categories']['categories']??[]) as $spec){
                        foreach((array)($spec['runtime_slugs']??[]) as $journalSlug)$journalSlugs[(string)$journalSlug]=true;
                    }
                    $journal=isset($journalSlugs[$slug]);
                    if($area==='MAGAZIN'){
                        if(!$journal)throw new RuntimeException('PSTE_MANUAL_AREA_CATEGORY_NOT_MAGAZIN');
                        $articleType='Journal';
                    }else{
                        if($journal)throw new RuntimeException('PSTE_MANUAL_AREA_CATEGORY_NOT_FACH');
                        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$leaf=null;
                        foreach((is_array($baseline)?(array)($baseline['leaf_categories']??[]):[]) as $item){
                            if(!is_array($item)||(int)($item['term_id']??0)!==$categoryId)continue;
                            if($leaf!==null)throw new RuntimeException('PSTE_MANUAL_AREA_CATEGORY_AMBIGUOUS');$leaf=$item;
                        }
                        if($leaf===null||trim((string)($leaf['slug']??''))!==$slug)throw new RuntimeException('PSTE_MANUAL_AREA_CATEGORY_NOT_IN_BASELINE');
                        $articleType=trim((string)($leaf['article_type']??''));
                        if($articleType===''||strcasecmp($articleType,'Journal')===0)throw new RuntimeException('PSTE_MANUAL_AREA_FACH_TYPE_UNVERIFIED');
                    }
                    $status='REASSIGNED';$note=trim('Bereich händisch geprüft: '.($area==='FACH'?'Hauptnavigation':'Magazin').'. '.$note);
                }
            }
            PSTE_Repository::saveManualDecision($poolKey,$status,$categoryId,$articleType,$note,get_current_user_id(),!empty($_POST['confirm_hard_override']));
            if($status==='REASSIGNED'&&class_exists('PSTE_Context_Refresh')&&class_exists('PSTE_Context_Index_Store')){
                // Reuse the existing provider-free recheck for this ONE reviewed topic.
                // Failure never turns a provisional manual decision into a production PASS.
                try{
                    $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
                    $context=PSTE_Context_Refresh::status();
                    if(is_array($baseline)&&($baseline['contract']??'')==='PSTE_SITE_BASELINE_V1'
                        &&(string)($context['status']??'')==='COMPLETE'){
                        $binding=PSTE_Context_Index_Store::runtimeBinding($context,$baseline);
                        if(($binding['contract']??'')==='PSTE_CONTEXT_INDEX_RUNTIME_BINDING_V2'){
                            $poolRow=$wpdb->get_row($wpdb->prepare("SELECT id,candidate_id FROM $table WHERE pool_key=%s",$poolKey),ARRAY_A);
                            $id=(int)($poolRow['id']??0);$candidateId=(string)($poolRow['candidate_id']??'');
                            if($id>0&&preg_match('/^[a-f0-9]{64}$/',$candidateId))
                                PSTE_Repository::reanalyzeRetainedBacklogBatch($id-1,1,$baseline,$binding,[$candidateId]);
                        }
                    }
                }catch(Throwable $recheckError){
                    // Saved review remains provisional; no automatic production release.
                }
            }
            self::redirect('review','review_saved=1');}catch(Throwable $e){self::blocked('review',$e);}
    }



    public static function retrySafeMigration(): void {
        PSTE_Auth::assertAdmin('pste_retry_safe_migration',(string)($_POST['_wpnonce']??''));
        try{PSTE_Safe_Migration_Job::start('MANUAL_POST_FALLBACK');self::redirect('overview','safe_migration_started=1');}catch(Throwable $e){self::blocked('overview',$e);}
    }

    public static function safeMigrationStartAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{PSTE_Auth::assertAdmin('pste_safe_migration_ajax',(string)($_POST['nonce']??''));$job=PSTE_Safe_Migration_Job::start('MANUAL_AJAX');self::ajaxSuccess(['job'=>$job,'driver'=>$driver??PSTE_Research_Driver::status()],$level);}
        catch(Throwable $e){self::ajaxError($e,$level,400);}
    }
    public static function safeMigrationAdvanceAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_safe_migration_ajax',(string)($_POST['nonce']??''));
            $job=PSTE_Safe_Migration_Job::advance(sanitize_text_field((string)($_POST['job_uuid']??'')),!empty($_POST['explicit_resume']));
            self::ajaxSuccess(['job'=>$job],$level);
        }catch(Throwable $e){
            if((string)$e->getMessage()==='PSTE_SAFE_MIGRATION_STEP_ALREADY_RUNNING'){
                try{$cur=PSTE_Safe_Migration_Job::current();if(is_array($cur)){self::ajaxSuccess(['job'=>PSTE_Safe_Migration_Job::publicState($cur),'busy'=>true],$level);}}catch(Throwable $ignored){}
            }
            self::ajaxError($e,$level,400);
        }
    }

    public static function processContextBatch(): void {try{PSTE_Auth::assertAdmin('pste_process_context_batch',(string)($_POST['_wpnonce']??''));$job=PSTE_Context_Refresh::processBatch();if((string)($job['status']??'')==='BLOCKED')throw new RuntimeException((string)($job['error_code']??'PSTE_CONTEXT_REFRESH_FAILED'));self::redirect('overview','context_batch_processed=1');}catch(Throwable $e){self::blocked('overview',$e);}}

    public static function contextAdvanceAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_context_ajax',(string)($_POST['nonce']??''));
            $job=PSTE_Context_Refresh::processBatch();
            if((string)($job['status']??'')==='BLOCKED')throw new RuntimeException((string)($job['error_code']??'PSTE_CONTEXT_REFRESH_FAILED'));
            self::ajaxSuccess(['job'=>self::contextPublicState($job)],$level);
        }catch(Throwable $e){self::ajaxError($e,$level,400);}
    }

    public static function importGsc(): void {PSTE_Auth::assertAdmin('pste_import_gsc',(string)($_POST['_wpnonce']??''));if(empty($_FILES['gsc_csv']['tmp_name'])||!is_uploaded_file($_FILES['gsc_csv']['tmp_name']))wp_die('PSTE_GSC_UPLOAD_MISSING');try{update_option(PSTE_OPTION_FIRST_PARTY,PSTE_First_Party_Import::parseCsv($_FILES['gsc_csv']['tmp_name']),false);self::redirect('sources','gsc_imported=1');}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function repairPriceIntents(): void {
        PSTE_Auth::assertAdmin('pste_repair_price_intents',(string)($_POST['_wpnonce']??''));
        try{
            $report=PSTE_Repository::repairPriceIntentCandidates();
            $reportStatus=(string)($report['status']??'');
            if(!in_array($reportStatus,['PASS','PARTIAL_PASS','BLOCKED'],true))throw new RuntimeException('PSTE_PRICE_INTENT_REPAIR_NOT_PASSED');
            $keys=array_values(array_unique(array_filter(array_map('strval',(array)($report['context_refresh_pool_keys']??[])))));
            if($keys){
                $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
                if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
                $inventory=PSTE_Snapshot::inventory();$structure=PSTE_Snapshot::structure();$plan=PSTE_Snapshot::editorialPlan();
                if((string)($baseline['inventory_sha256']??'')!==(string)($inventory['sha256']??'')
                    ||(string)($baseline['structure_sha256']??'')!==(string)($structure['sha256']??'')
                    ||(string)($baseline['editorial_plan_sha256']??'NOT_AVAILABLE')!==(string)($plan['sha256']??'NOT_AVAILABLE')){
                    throw new RuntimeException('PSTE_PRICE_INTENT_REPAIR_SNAPSHOT_STALE');
                }
                $context=PSTE_Repository::refreshPortalContextForKeys($keys,$inventory,$plan,(string)$structure['sha256']);
                if((int)($context['processed']??-1)!==count($keys))throw new RuntimeException('PSTE_PRICE_INTENT_REPAIR_CONTEXT_REFRESH_INCOMPLETE');
                $report['context_refresh']=$context;
            }
            $marker=['status'=>$reportStatus,'completed_at_utc'=>gmdate('c'),'plugin_version'=>PSTE_VERSION,'report'=>$report];
            $marker['sha256']=hash('sha256',wp_json_encode($marker,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION));
            update_option(PSTE_OPTION_PRICE_INTENT_REPAIR,$marker,false);
            $readback=get_option(PSTE_OPTION_PRICE_INTENT_REPAIR,[]);
            if(!is_array($readback)||!hash_equals((string)$marker['sha256'],(string)($readback['sha256']??'')))throw new RuntimeException('PSTE_PRICE_INTENT_REPAIR_MARKER_NOT_PERSISTED');
            self::redirect('overview',$reportStatus==='PASS'?'price_intent_repaired=1':'price_intent_partial=1');
        }catch(Throwable $e){self::blocked('overview',$e);}
    }

    public static function researchStartAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            if(empty($_POST['confirm_cost']))throw new RuntimeException('PSTE_COST_CONFIRMATION_REQUIRED');
            $job=PSTE_Research_Job::start((int)($_POST['category_id']??0),sanitize_text_field((string)($_POST['seed']??'')),PSTE_Plugin::settings());$driver=PSTE_Research_Driver::kick(0,'START_SINGLE');
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job,'driver'=>$driver],$level);
    }
    public static function researchAdvanceAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            $uuid=sanitize_text_field((string)($_POST['job_uuid']??''));$job=PSTE_Research_Job::peek();
            if(!is_array($job)||!hash_equals($uuid,(string)($job['job_uuid']??'')))throw new RuntimeException('PSTE_RESEARCH_JOB_NOT_FOUND');
            $driver=PSTE_Research_Driver::kick(0,'MANUAL_RECHECK_SINGLE');
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job,'driver'=>$driver,'lock'=>PSTE_Research_Job::stepLockStatus(),'read_only'=>true],$level);
    }
    public static function breadthResearchStartAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            if(empty($_POST['confirm_cost']))throw new RuntimeException('PSTE_COST_CONFIRMATION_REQUIRED');
            $queue=PSTE_Breadth_Research_Queue::startUntil((int)($_POST['target_usable']??40),(int)($_POST['max_items']??40),PSTE_Plugin::settings());$driver=PSTE_Research_Driver::kick(0,'START_BREADTH');
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['queue'=>$queue,'driver'=>$driver??PSTE_Research_Driver::status()],$level);
    }
    public static function researchStatusAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            $job=PSTE_Research_Job::peek();$requested=sanitize_text_field((string)($_POST['job_uuid']??''));$driver=PSTE_Research_Driver::status();
            if(is_array($job)&&$requested!==''&&(string)($job['job_uuid']??'')!==$requested)throw new RuntimeException('PSTE_RESEARCH_JOB_NOT_FOUND');
            if(!is_array($job)&&$requested==='')throw new RuntimeException('PSTE_RESEARCH_JOB_NOT_FOUND');
            $lock=PSTE_Research_Job::stepLockStatus();
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job,'lock'=>$lock,'driver'=>$driver,'read_only'=>true],$level);
    }

    public static function breadthResearchStatusAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            $queue=PSTE_Breadth_Research_Queue::peek();
            $requested=sanitize_text_field((string)($_POST['queue_uuid']??''));
            if(!is_array($queue)||($requested!==''&&(string)($queue['queue_uuid']??'')!==$requested))throw new RuntimeException('PSTE_BREADTH_QUEUE_NOT_FOUND');
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['queue'=>$queue,'lock'=>PSTE_Breadth_Research_Queue::queueLockStatus(),'driver'=>PSTE_Research_Driver::status(),'read_only'=>true],$level);
    }
    public static function breadthResearchAdvanceAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            $uuid=sanitize_text_field((string)($_POST['queue_uuid']??''));$queue=PSTE_Breadth_Research_Queue::peek();
            if(!is_array($queue)||!hash_equals($uuid,(string)($queue['queue_uuid']??'')))throw new RuntimeException('PSTE_BREADTH_QUEUE_NOT_FOUND');
            $explicit=!empty($_POST['explicit_resume']);
            if($explicit&&array_key_exists('provider_fallback_allowed',$queue)&&empty($queue['provider_fallback_allowed'])){
                $queue=PSTE_Breadth_Research_Queue::requestExistingOnlyResume($uuid,PSTE_Plugin::settings());
            }
            $driver=PSTE_Research_Driver::kick(0,$explicit?'MANUAL_EXPLICIT_RECHECK_BREADTH':'MANUAL_RECHECK_BREADTH');
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['queue'=>$queue,'driver'=>$driver,'lock'=>PSTE_Breadth_Research_Queue::queueLockStatus(),'read_only'=>true],$level);
    }
    public static function breadthResearchCancelAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            $queue=PSTE_Breadth_Research_Queue::requestCancel(sanitize_text_field((string)($_POST['queue_uuid']??'')));if((string)($queue['status']??'')==='CANCELLED')PSTE_Research_Driver::kick(0,'CANCEL_RECONCILE_BREADTH');
        }catch(Throwable $e){
            if(in_array((string)$e->getMessage(),['PSTE_RESEARCH_STEP_ALREADY_RUNNING','PSTE_BREADTH_QUEUE_STEP_ALREADY_RUNNING'],true)){
                try{$current=PSTE_Breadth_Research_Queue::peek();$lock=PSTE_Breadth_Research_Queue::queueLockStatus();}catch(Throwable $ignored){$current=null;$lock=[];}
                if(is_array($current)){self::ajaxSuccess(['queue'=>$current,'busy'=>true,'retry_after_ms'=>(int)($lock['retry_after_ms']??1500),'lock'=>$lock,'read_only'=>true],$level);return;}
            }
            self::ajaxError($e,$level,400);return;
        }
        $busy=!empty($queue['cancel_requested'])&&(string)($queue['status']??'')!=='CANCELLED';
        self::ajaxSuccess(['queue'=>$queue,'busy'=>$busy,'retry_after_ms'=>$busy?1500:0,'lock'=>PSTE_Breadth_Research_Queue::queueLockStatus(),'driver'=>PSTE_Research_Driver::status()],$level);
    }

    public static function setCandidateType(): void {
        try{
            PSTE_Auth::assertAdmin('pste_set_candidate_type',(string)($_POST['_wpnonce']??''));
            $poolKey=sanitize_text_field((string)($_POST['pool_key']??''));$type=sanitize_text_field((string)($_POST['candidate_article_type']??''));$note=sanitize_text_field((string)($_POST['review_note']??''));
            PSTE_Repository::saveManualCandidateTypeOverride($poolKey,$type,$note,get_current_user_id());self::redirect('review','candidate_type_saved=1');
        }catch(Throwable $e){self::blocked('review',$e);}
    }

    public static function exportOverlay(): void {PSTE_Auth::assertAdmin('pste_export_overlay',(string)($_POST['_wpnonce']??''));$run=PSTE_Repository::latestRun();if(!$run)wp_die('PSTE_NO_RUN_AVAILABLE');self::jsonDownload(PSTE_Overlay::build($run,PSTE_Repository::candidatesForRun($run['run_uuid'])),'pste-seo-topic-overlay-'.gmdate('Ymd-His').'-utc.json');}
    public static function exportTopicMap(): void {PSTE_Auth::assertAdmin('pste_export_topic_map',(string)($_POST['_wpnonce']??''));$baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')wp_die('PSTE_SITE_BASELINE_REQUIRED');$guard=self::credentialFreeArtifactGuard();$tmp=tmpfile();if($tmp===false)throw new RuntimeException('PSTE_TOPIC_MAP_EXPORT_TEMPFILE_FAILED');try{$info=PSTE_Overlay::streamGlobalMapToResource($tmp,$baseline,$guard);$size=ftell($tmp);if($size===false||(int)$size!==(int)($info['bytes']??-1))throw new RuntimeException('PSTE_TOPIC_MAP_EXPORT_SIZE_MISMATCH');rewind($tmp);nocache_headers();header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="pste-global-seo-topic-map-'.gmdate('Ymd-His').'-utc.json"');header('Content-Length: '.(string)$size);fpassthru($tmp);exit;}finally{fclose($tmp);}}

    public static function shortPathCreateExport(): void {
        PSTE_Auth::assertAdmin('pste_shortpath_create_export',(string)($_POST['_wpnonce']??''));
        try{
            $raw=(string)($_POST['manual_topics']??'');$topics=[];foreach((preg_split('/\R/u',$raw)?:[]) as $line){$line=sanitize_text_field((string)$line);if(trim($line)!=='')$topics[]=$line;}
            if(!$topics)throw new RuntimeException('PSTE_SHORTPATH_TOPICS_REQUIRED');
            $groups=[];foreach($topics as $topic){$route=PSTE_Repository::inferManualWorkflowRouteFromText($topic);$groups[$route][]=$topic;}
            if(count($groups)!==1)throw new RuntimeException('PSTE_SHORTPATH_MIXED_INTERNAL_ROUTES_SPLIT_REQUIRED');
            $route=(string)array_key_first($groups);$routeTopics=(array)$groups[$route];
            $result=PSTE_Repository::importManualTopics($routeTopics,get_current_user_id(),$route);
            $traceRun=(string)($result['run_uuid']??'');
            if($traceRun!=='')self::shortPathTraceRecord($traceRun,'AUSWAHL_ERFASST',['route'=>$route,'topics'=>array_slice($routeTopics,0,50),'selected_count'=>count($routeTopics)]);
            if(($result['status']??'')!=='PASS'||(int)($result['provider_calls']??-1)!==0||!empty($result['production_authority'])||!empty($result['article_or_taxonomy_write_attempted']))throw new RuntimeException('PSTE_SHORTPATH_INTAKE_INVALID');
            if($route==='K0'){
                // The manual path must remain targeted. importManualTopics() has already run the
                // submitted rows through the provider-free normal metadata/readiness path; do not
                // start the global retained-backlog audit here. That audit belongs to Automatik.
                $direct=is_array($result['direct_processing']??null)?(array)$result['direct_processing']:[];
                $directStatus=(string)($direct['status']??'');
                self::shortPathTraceRecord((string)$result['run_uuid'],'DIREKTPRUEFUNG',['status'=>$directStatus,'processed'=>(int)($direct['processed']??0),'ready'=>(int)($direct['ready']??0),'not_ready'=>(int)($direct['not_ready']??0),'manual_decision_blocked'=>(int)($direct['manual_decision_blocked']??0)]);
                if($directStatus==='CONTEXT_REFRESH_REQUIRED')throw new RuntimeException('PSTE_SHORTPATH_K0_CONTEXT_REFRESH_REQUIRED');
                if($directStatus!=='COMPLETE')throw new RuntimeException('PSTE_SHORTPATH_K0_DIRECT_PROCESS_INCOMPLETE');
                if((int)($direct['provider_calls']??-1)!==0||!empty($direct['full_backlog_reanalysis_required'])||!empty($direct['production_authority'])||!empty($direct['article_or_taxonomy_write_attempted']))throw new RuntimeException('PSTE_SHORTPATH_K0_DIRECT_PROCESS_BOUNDARY_INVALID');
                // Even when zero are READY, read the selected rows once to record precise hold reasons.
                // The selection compiler fails closed; the global compiler is never started.
                // KISS: the existing PSERC direct compiler receives ONLY this manual run's
                // already checked K0 candidates. It never starts the global plan job.
                $selected=self::shortPathCompileExactManualSelection((string)$result['run_uuid']);
                self::shortPathTraceRecord((string)$result['run_uuid'],'AUSWAHL_FREIGEGEBEN',['selected_count'=>(int)$selected['item_count']]);
                self::jsonDownload($selected,'pste-kurzer-dienstweg-'.(string)$selected['batch_sha256'].'.json');
            }
            $payload=PSTE_Repository::createWorkBatch($route,get_current_user_id(),50);$profileData=is_array($payload['writer_profile']??null)?(array)$payload['writer_profile']:[];$required=(array)($profileData['required_item_fields']??[]);if(!$required)throw new RuntimeException('PSTE_SHORTPATH_REQUIRED_FIELDS_MISSING');
            foreach((array)($payload['items']??[]) as $index=>$item){if(!is_array($item))throw new RuntimeException('PSTE_SHORTPATH_ITEM_INVALID:'.(string)$index);foreach($required as $field){$value=$item[(string)$field]??null;if(!array_key_exists((string)$field,$item)||((is_string($value)||is_numeric($value))&&trim((string)$value)===''))throw new RuntimeException('PSTE_SHORTPATH_FIELD_MISSING:'.(string)$index.':'.(string)$field);}}
            self::jsonDownload($payload,'pste-kurzer-dienstweg-'.gmdate('Ymd-His').'-utc.json');
        }catch(Throwable $e){
            // The diagnostics themselves must never hide or change the existing failure path.
            try{self::shortPathTraceRecord(isset($traceRun)?$traceRun:'','KURZWEG_FEHLER',['error_code'=>self::safeErrorCode($e)]);}catch(Throwable $ignored){}
            self::blocked('overview',$e);
        }
    }

    /**
     * Existing PSERC direct, read-only compiler with ONLY the caller's selected K0
     * topics. Uses the existing PSTE compiler projection and PSERC eligibility,
     * duplicate, slot, quality and five-field gates; no global plan job or new store.
     */
    private static function shortPathCompileExactManualSelection(string $runUuid): array {
        global $wpdb;
        if(!preg_match('/^[0-9a-fA-F-]{36}$/',$runUuid))throw new RuntimeException('PSTE_SHORTPATH_RUN_UUID_INVALID');
        $run=PSTE_Repository::runByUuid($runUuid);
        if(!is_array($run)||(string)($run['seed']??'')!=='MANUAL_TOPIC_INTAKE')throw new RuntimeException('PSTE_SHORTPATH_RUN_NOT_MANUAL_INTAKE');
        if(!class_exists('PSERC_Compiler')||!class_exists('PSERC_SEO_Reader')||!class_exists('PSERC_SEO_Source_Binding')||!class_exists('PSERC_Stable_Json'))throw new RuntimeException('PSTE_SHORTPATH_PSERC_REQUIRED');
        $rows=$wpdb->get_results($wpdb->prepare('SELECT payload_json FROM '.PSTE_Repository::table('candidates').' WHERE run_uuid=%s ORDER BY id ASC LIMIT 51',$runUuid),ARRAY_A);
        if(!is_array($rows)||count($rows)>50||!$rows)throw new RuntimeException('PSTE_SHORTPATH_SELECTED_ROWS_INVALID');
        $wanted=[];
        foreach($rows as $row){
            $manual=PSTE_Repository::decodeStoredCandidatePayload((string)($row['payload_json']??''));
            if((string)($manual['manual_topic_intake']['contract']??'')!=='PSTE_MANUAL_TOPIC_INTAKE_V1'||PSTE_Repository::workflowRouteForCandidate($manual)!=='K0')throw new RuntimeException('PSTE_SHORTPATH_RUN_ROUTE_MISMATCH');
            $key=PSTE_Repository::globalTopicKeyForCandidate($manual);
            if($key==='')throw new RuntimeException('PSTE_SHORTPATH_POOL_KEY_MISSING');
            $wanted[$key]=(string)($manual['raw_user_question']??$manual['canonical_query']??'');
        }
        $eligible=[];$held=[];$found=[];$allowed=[];$cursor=null;$pages=0;
        do{
            $page=PSTE_Compiler_Read_Capability::topicPage($cursor,25);
            if((string)($page['contract']??'')!=='PSTE_COMPILER_PLANNING_TOPIC_PAGE_V1')throw new RuntimeException('PSTE_SHORTPATH_COMPILER_PAGE_INVALID');
            foreach((array)($page['items']??[]) as $candidate){
                if(!is_array($candidate))continue;
                $key=(string)($candidate['pool_key']??'');
                if(!array_key_exists($key,$wanted))continue;
                if(isset($found[$key]))throw new RuntimeException('PSTE_SHORTPATH_DUPLICATE_POOL_ROW');
                $found[$key]=true;
                if(PSTE_Repository::workflowRouteForCandidate($candidate)!=='K0')throw new RuntimeException('PSTE_SHORTPATH_SELECTED_ROUTE_CHANGED');
                $normal=PSERC_SEO_Reader::normalizeCandidate($candidate);
                if((string)($normal['eligibility_status']??'')!=='ELIGIBLE'){$held[]=['topic'=>(string)$wanted[$key],'status'=>'HELD','reason_codes'=>(array)($normal['eligibility_reasons']??[])];continue;}
                $eligible[]=$normal;
                $identity=self::k0FourFieldIdentity(['title'=>(string)($normal['production_title']??''),'target_keyword'=>(string)($normal['target_keyword']??''),'category'=>(string)($normal['category_slug']??''),'article_type'=>(string)($normal['article_type']??'')]);
                if($identity!=='')$allowed[$identity]=true;
            }
            $complete=!empty($page['complete']);$cursor=is_array($page['next_cursor']??null)?$page['next_cursor']:null;
            if(!$complete&&$cursor===null)throw new RuntimeException('PSTE_SHORTPATH_COMPILER_CURSOR_MISSING');
            if(++$pages>1000)throw new RuntimeException('PSTE_SHORTPATH_COMPILER_PAGE_LIMIT');
        }while(!$complete);
        foreach($wanted as $key=>$title){
            if(isset($found[$key]))continue;
            // The planning projection contains YES rows only. Read the exact rejected
            // pool row for this manual run, not the full inventory or a global compiler.
            $raw=$wpdb->get_row($wpdb->prepare('SELECT planning_suitability,automatic_pool_status,context_state,manual_status,payload_json FROM '.PSTE_Repository::table('topic_pool').' WHERE pool_key=%s LIMIT 1',$key),ARRAY_A);
            if(!is_array($raw)&&trim((string)($wpdb->last_error??''))!=='')throw new RuntimeException('PSTE_SHORTPATH_SELECTED_TOPIC_DIAG_READ_FAILED');
            $payload=is_array($raw)?json_decode((string)($raw['payload_json']??''),true):null;
            $payload=is_array($payload)?$payload:[];
            $path=is_array($payload['normal_metadata_path']??null)?$payload['normal_metadata_path']:[];
            $reasons=array_values(array_unique(array_filter(array_map('strval',array_merge(
                (array)($payload['reason_codes']??[]),
                (array)($path['reason_codes']??[])
            )),static fn($reason)=>$reason!=='')));
            if(!$reasons)$reasons=[is_array($raw)?'PSTE_SHORTPATH_SELECTED_TOPIC_NOT_PLANNABLE':'PSTE_SHORTPATH_SELECTED_TOPIC_NOT_IN_POOL'];
            $held[]=['topic'=>$title,'status'=>'NOT_PLANNABLE',
                'planning_suitability'=>(string)($raw['planning_suitability']??''),
                'pool_status'=>(string)($raw['automatic_pool_status']??$payload['pool_status']??''),
                'context_state'=>(string)($raw['context_state']??''),
                'manual_status'=>(string)($raw['manual_status']??''),
                'normal_path_status'=>(string)($path['status']??''),
                'reason_codes'=>array_slice($reasons,0,20)];
        }
        self::shortPathTraceRecord($runUuid,'GEZIELTE_PRUEFUNG',['selected_count'=>count($wanted),'ready'=>count($eligible),'not_ready'=>count($held),'outcomes'=>$held]);
        if(!$eligible)throw new RuntimeException('PSTE_SHORTPATH_NO_ELIGIBLE_SELECTED_TOPICS');
        $source=PSERC_SEO_Source_Binding::validate();
        if(empty($source['ok']))throw new RuntimeException('PSTE_SHORTPATH_PSERC_SOURCE_BINDING_BLOCKED');
        $schema=(string)get_option(defined('PSTE_OPTION_SCHEMA')?PSTE_OPTION_SCHEMA:'pste_schema_version','');
        if($schema===''||!hash_equals((string)($source['engine_schema']??''),$schema))throw new RuntimeException('PSTE_SHORTPATH_PSERC_SCHEMA_MISMATCH');
        $seo=['ok'=>true,'status'=>'SEO_TOPIC_POOL_READ_ONLY_PASS','version'=>(string)PSTE_VERSION,'schema'=>$schema,
            'source_binding_sha256'=>(string)($source['binding_sha256']??''),'source_binding_file_count'=>(int)($source['required_file_count']??0),
            'capability_binding_sha256'=>(string)($source['capability_sha256']??''),'capability_required_symbol_count'=>(int)($source['required_symbol_count']??0),
            'all_count'=>count($wanted),'eligible'=>$eligible,'held'=>$held,'eligible_count'=>count($eligible),'held_count'=>count($held),'write_attempted'=>false];
        $seo['snapshot_sha256']=PSERC_Stable_Json::hash(['version'=>$seo['version'],'schema'=>$schema,'eligible'=>$eligible,'held'=>$held]);
        $compiled=PSERC_Compiler::compile(null,$seo);
        if(empty($compiled['ok'])||(string)($compiled['status']??'')!=='PSERC_METADATA_ONLY_PREVIEW_PASS'){
            self::shortPathTraceRecord($runUuid,'PSERC_BLOCKIERT',['error_code'=>self::safeErrorCode(new RuntimeException((string)($compiled['status']??'PSERC_COMPILER_FAILED')))]);
            throw new RuntimeException('PSTE_SHORTPATH_PSERC_'.(string)($compiled['status']??'FAILED'));
        }
        $manifest=(array)($compiled['manifest']??[]);
        $outcomes=[];
        foreach((array)($manifest['items']??[]) as $item){
            if(!is_array($item))continue;
            $topic=(array)($item['topic']??[]);
            $outcomes[]=['topic'=>(string)($item['title']['production_title']??$topic['production_title']??$topic['semantic_identity_title']??''),'status'=>(string)($item['status']??'UNKNOWN'),'reason_codes'=>array_slice((array)($item['production_reason_codes']??$item['reason_codes']??[]),0,10)];
        }
        self::shortPathTraceRecord($runUuid,'PSERC_ERGEBNIS',['selected_count'=>count($wanted),'ready'=>(int)($compiled['ready_count']??0),'not_ready'=>max(0,count($wanted)-(int)($compiled['ready_count']??0)),'outcomes'=>$outcomes]);
        $batch=(array)($manifest['next_textmachine_metadata_batch']??[]);
        $selected=self::k0ReadyBatchFromPsercSnapshot($batch,$allowed);
        if((int)($selected['item_count']??0)>count($eligible))throw new RuntimeException('PSTE_SHORTPATH_OUTPUT_CARDINALITY_INVALID');
        return $selected;
    }

    /** Existing and only title rule source, transported unchanged to the external language desk. */
    private static function titleDeskGovernance(): array {
        $rulesRaw=@file_get_contents(PSTE_DIR.'contracts/intent-first-title-governance-v1.json');
        if(!is_string($rulesRaw))throw new RuntimeException('PSTE_TITLE_DESK_RULES_UNAVAILABLE');
        $rules=json_decode($rulesRaw,true,128,JSON_THROW_ON_ERROR);
        if(!is_array($rules)||($rules['contract']??'')!=='PSTE_INTENT_FIRST_TITLE_GOVERNANCE_V1')
            throw new RuntimeException('PSTE_TITLE_DESK_RULES_INVALID');
        return $rules;
    }

    /** Existing PSTE_TITLE_DESK_BATCH_V1 shape: stable source snapshot, no text creation. */
    public static function titleDeskItemFromRow(array $row): ?array {
        $payload=json_decode((string)($row['payload_json']??''),true);
        if(!is_array($payload))throw new RuntimeException('PSTE_TITLE_DESK_STORED_JSON_INVALID');
        $raw=PSTE_Editorializer::sourceQuery($payload);
        $poolKey=trim((string)($row['pool_key']??''));
        if($raw===''||$poolKey==='')return null;
        // The same title-only desk may also correct an existing production title.
        // Its existing protected writer validates all bound decisions before saving;
        // no category, type, keyword or plan authority is granted here.
        if(trim((string)($row['manual_status']??''))!==''||!empty($payload['existing_evidence_reentry_review']))return null;
        // Use the existing first worker's YES, not the title/category result.
        // Unconfirmed relevance stays with that worker; it is never declared NO here.
        $relevance=(array)($payload['normal_metadata_path']??[]);
        if(($relevance['portal_relevance']??'')!=='PROVEN')return null;
        $area=strtoupper(trim((string)($payload['editorial_area']??$payload['editorial_owner_area']??'UNDECIDED')));
        if(!in_array($area,['FACH','MAGAZIN','UNDECIDED'],true))$area='UNDECIDED';
        $productionTitle=trim((string)($payload['production_title']??''));
        $existing=$productionTitle!==''?$productionTitle:trim((string)($payload['editorial_title']??''));
        $item=[
            'pool_key'=>$poolKey,
            'raw_query'=>$raw,
            'article_type'=>(string)($payload['proposed_article_type']??$payload['suggested_article_type']??''),
            'seo_target_keyword'=>(string)($payload['target_keyword']??''),
            'existing_candidate_title'=>$existing,
            'editorial_area'=>$area,
            'category_slug'=>(string)($payload['target_category_slug']??''),
            'article_intent'=>(array)($payload['article_intent']??$payload['intent_profile']??[]),
            'planning_status'=>(string)($payload['planning_status']??($row['automatic_pool_status']??'REVIEW_REQUIRED')),
            'planning_reasons'=>array_values((array)($payload['planning_reasons']??[])),
        ];
        // Technical snapshot binding, not a keyword-/title-quality decision.
        $hash=self::stableJsonSha256($item);
        $item['title']='';$item['approved']=false;$item['source_sha256']=$hash;
        return $item;
    }

    /** Pure import preflight: one snapshot owner, no semantic recalculation. */
    public static function preflightTitleDeskImport(array $batch,callable $loadRow,bool $collectTitleCorrections=false): array {
        if(($batch['contract']??'')!=='PSTE_TITLE_DESK_BATCH_V1')throw new RuntimeException('PSTE_TITLE_DESK_CONTRACT_INVALID');
        // File identity only, not a second semantic title check. Older exports remain importable.
        if(array_key_exists('title_governance',$batch)&&$batch['title_governance']!==self::titleDeskGovernance()){
            // Existing exports made before the single-owner correction stay usable,
            // but an arbitrary or manipulated rule document must still fail closed.
            $historical=hash('sha256',json_encode($batch['title_governance'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            if(!hash_equals('fd271bfc0679d30da9f158c59dc12ff9fcc145fe35ab7754d26ea22610f43d03',$historical))
                throw new RuntimeException('PSTE_TITLE_DESK_RULES_CHANGED');
        }
        $items=$batch['items']??null;
        if(!is_array($items)||!array_is_list($items)||!$items||count($items)>100)throw new RuntimeException('PSTE_TITLE_DESK_ITEM_COUNT_INVALID');
        $approved=[];$seen=[];$corrections=[];
        foreach($items as $i=>$item){
            if(!is_array($item)||!is_string($item['pool_key']??null))throw new RuntimeException('PSTE_TITLE_DESK_ITEM_INVALID');
            $key=trim($item['pool_key']);if($key===''||isset($seen[$key]))throw new RuntimeException('PSTE_TITLE_DESK_ID_DUPLICATE_OR_EMPTY');$seen[$key]=true;
            if(!is_bool($item['approved']??null)||!is_string($item['title']??null))throw new RuntimeException('PSTE_TITLE_DESK_REVIEW_STATUS_INVALID');
            $row=$loadRow($key);if(!is_array($row))throw new RuntimeException('PSTE_TITLE_DESK_ORIGINAL_MISSING');
            $original=self::titleDeskItemFromRow($row);
            if($original===null)throw new RuntimeException('PSTE_TITLE_DESK_ORIGINAL_NOT_EDITABLE');
            // Unknown operational fields must never be accepted through a title-only import.
            foreach(array_keys($item) as $field){if(!array_key_exists($field,$original)&&$field!=='editorial_review')throw new RuntimeException('PSTE_TITLE_DESK_UNKNOWN_FIELD');}
            // The unchanged export is the only allowed source for its frozen fields.
            $exported=$item;
            foreach(['title','approved','editorial_review','source_sha256'] as $field)unset($exported[$field]);
            $declaredHash=(string)($item['source_sha256']??'');
            $actualHash=self::stableJsonSha256($exported);
            if(!hash_equals($actualHash,$declaredHash))throw new RuntimeException('PSTE_TITLE_DESK_EXPORT_BINDING_INVALID');
            $title=trim((string)preg_replace('/\s+/u',' ',$item['title']));
            $repeat=$item['approved']===true&&$title!==''&&hash_equals((string)$original['existing_candidate_title'],$title)
                &&(string)$original['existing_candidate_title']!==(string)$item['existing_candidate_title'];
            foreach($original as $field=>$value){
                if($field==='title'||$field==='approved')continue;
                // An exact retry is legal only when the sole changed field is the title.
                if($repeat&&in_array($field,['existing_candidate_title','source_sha256'],true))continue;
                if(!array_key_exists($field,$item)||$item[$field]!==$value)throw new RuntimeException('PSTE_TITLE_DESK_FROZEN_FIELD_CHANGED_'.$field);
            }
            if(array_key_exists('editorial_review',$item)&&!is_string($item['editorial_review']))throw new RuntimeException('PSTE_TITLE_DESK_REVIEW_INVALID');
            if(!is_string($item['title'])||preg_match('/[<>\x00-\x1F\x7F]/u',$item['title'])){
                if(!$collectTitleCorrections)throw new RuntimeException('PSTE_TITLE_DESK_TITLE_FORMAT_INVALID');
                $corrections[$key]='PSTE_TITLE_DESK_TITLE_FORMAT_INVALID';continue;
            }
            if($item['approved']!==true){
                // approved is a delivery marker, not a linguistic or SEO verdict.
                if($collectTitleCorrections)$corrections[$key]='PSTE_TITLE_DESK_TITLE_NOT_DELIVERED';
                continue;
            }
            if($title===''||strlen($title)>300){
                if(!$collectTitleCorrections)throw new RuntimeException('PSTE_TITLE_DESK_APPROVED_TITLE_INVALID');
                $corrections[$key]='PSTE_TITLE_DESK_APPROVED_TITLE_INVALID';continue;
            }
            if(array_key_exists('editorial_review',$item)&&trim($item['editorial_review'])==='')throw new RuntimeException('PSTE_TITLE_DESK_REVIEW_EMPTY');
            $approved[]=['pool_key'=>$key,'title'=>$title,'original_payload_json'=>(string)$row['payload_json']];
        }
        if(!$approved&&!$collectTitleCorrections)throw new RuntimeException('PSTE_TITLE_DESK_NO_APPROVED_TITLES');
        return $collectTitleCorrections?['approved'=>$approved,'corrections'=>$corrections]:$approved;
    }

    /** Existing admin action: export only original pool data and existing decisions. */
    public static function exportTitleDesk(): void {
        PSTE_Auth::assertAdmin('pste_title_desk_export',(string)($_POST['_wpnonce']??''));
        try {
            $cursor=filter_var($_POST['cursor_id']??0,FILTER_VALIDATE_INT,['options'=>['min_range'=>0]]);
            if($cursor===false)throw new RuntimeException('PSTE_TITLE_DESK_CURSOR_INVALID');
            $rows=PSTE_Repository::contextBatchRows((int)$cursor,100);
            $items=[];$next=(int)$cursor;
            foreach($rows as $row){$next=max($next,(int)($row['id']??0));$item=self::titleDeskItemFromRow($row);if($item!==null)$items[]=$item;}
            // Transport the existing title contract exactly, not a newly defined ruleset.
            $out=['contract'=>'PSTE_TITLE_DESK_BATCH_V1',
                'instruction'=>'Die Sprachwerkstatt schreibt fuer JEDEN uebergebenen Suchbegriff genau einen natuerlichen deutschen Artikeltitel. Vorhandene Keyword-Wortfolge bevorzugt uebernehmen, soweit sie fachlich und grammatisch sinnvoll ist; sonst nur so weit wie noetig umstellen oder beugen (z.B. Anhaenger Kamera Pferd zu Kamera fuer Pferdeanhaenger). Keine Pferderelevanz-, Beitragsart-, Keyword-, Kategorien- oder eigene Titel-Freigabeentscheidung. Nicht wegen fehlender Beitragsart, Zielkeyword oder Kategorie zurueckhalten. Bei vorhandenem Titel title setzen und approved=true als reine Kennzeichnung TITEL_GELIEFERT (keine Qualitaetsfreigabe); die anderen Daten unveraendert lassen. Ein wirklich leerer oder unlesbarer Titel geht technisch an dieselbe Schreibstelle zurueck. Nach Import entscheiden die bestehenden Fach- und Kategoriearbeiter.',
                'title_governance'=>self::titleDeskGovernance(),
                'created_utc'=>gmdate('c'),'next_cursor'=>$next,'has_more'=>(count($rows)===100),
                'items'=>$items];
            self::jsonDownload($out,'pferdeatelier-titelwerkstatt-'.$next.'.json');
        }catch(Throwable $e){self::blocked('review',$e);}
    }

    /** Existing title-only repository writer; no topic/category re-evaluation or new table. */
    public static function importTitleDesk(): void {
        PSTE_Auth::assertAdmin('pste_title_desk_import',(string)($_POST['_wpnonce']??''));
        try {
            $upload=(array)($_FILES['title_desk_json']??[]);
            $tmp=(string)($upload['tmp_name']??'');
            if((int)($upload['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||$tmp===''||!is_uploaded_file($tmp)||(int)($upload['size']??0)>3000000)throw new RuntimeException('PSTE_TITLE_DESK_UPLOAD_INVALID');
            $raw=file_get_contents($tmp);if(!is_string($raw)||strlen($raw)>3000000)throw new RuntimeException('PSTE_TITLE_DESK_UPLOAD_READ_FAILED');
            $batch=json_decode($raw,true,128,JSON_THROW_ON_ERROR);
            if(!is_array($batch))throw new RuntimeException('PSTE_TITLE_DESK_UPLOAD_JSON_INVALID');
            global $wpdb;$table=PSTE_Repository::table('topic_pool');
            $load=static function(string $key)use($wpdb,$table){
                $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE pool_key=%s",$key),ARRAY_A);
                if(!is_array($row)&&(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_TITLE_DESK_POOL_READ_FAILED');
                return $row;
            };
            // The importer never judges wording. It accepts the external language decision;
            // the existing protected title writer alone may veto a production-bound violation.
            // A title-only rejection goes back to THAT SAME external language desk; the other
            // approved titles continue. Broken source identity or writes still fail closed.
            $applied=self::applyTitleDeskImport($batch,$load,static function(string $poolKey,string $title): array{
                return PSTE_Repository::saveManualTitleOverride($poolKey,$title,get_current_user_id());
            });
            $scheduled=self::scheduleTitleDeskReentry($applied['reentry']);
            $previous=get_transient('pste_title_desk_reentry_report');
            $oldProcessed=is_array($previous)?(int)($previous['processed']??0):0;
            // Repeated or overlapping imports keep progress, never erase other titles' results.
            $report=['scheduled'=>$scheduled,'processed'=>$oldProcessed,'held'=>is_array($previous)?(int)($previous['held']??0):0,
                'blocked'=>is_array($previous)?(array)($previous['blocked']??[]):[]];
            if($oldProcessed===0 || $scheduled===$applied['saved'])$report=['scheduled'=>$scheduled,'processed'=>0,'held'=>0,'blocked'=>[]];
            set_transient('pste_title_desk_reentry_report',$report,86400);
            set_transient('pste_title_desk_last_import',['reviewed'=>$applied['reviewed'],'saved'=>$applied['saved'],
                'needs_language_correction'=>count($applied['correction_batch']['items']),'reentry_scheduled'=>$scheduled],300);
            self::kickTitleDeskReentry();
            // Return one original-format JSON containing ONLY unresolved titles. The language
            // desk can rework it without modifying any frozen keyword, type or category field.
            if($applied['correction_batch']['items']){
                self::jsonDownload($applied['correction_batch'],'pferdeatelier-titelkorrektur-'.gmdate('Ymd-His').'.json');
            }
            self::redirect('review','title_desk_imported=1');
        }catch(Throwable $e){self::blocked('review',$e);}
    }

    /** Existing title-only importer: single safe transport and correction-return loop. No new title owner. */
    public static function applyTitleDeskImport(array $batch,callable $load,callable $write): array {
        $preflight=self::preflightTitleDeskImport($batch,$load,true);
        $saved=0;$reentry=[];$corrections=$preflight['corrections'];
        foreach($preflight['approved'] as $topic){
            $current=$load($topic['pool_key']);
            if(!is_array($current)||(string)($current['payload_json']??'')!==$topic['original_payload_json'])
                throw new RuntimeException('PSTE_TITLE_DESK_SOURCE_CHANGED_DURING_IMPORT');
            try{$result=$write($topic['pool_key'],$topic['title']);}
            catch(Throwable $e){
                // Only a title-quality veto is repairable by the language workshop. Database,
                // permission, source/context and production failures must not be reinterpreted.
                if(!str_starts_with((string)$e->getMessage(),'PSTE_MANUAL_TITLE_OVERRIDE_INVALID_'))throw $e;
                $corrections[$topic['pool_key']]=substr($e->getMessage(),0,220);
                continue;
            }
            if(!is_array($result)||($result['status']??'')!=='PASS'||!empty($result['production_authority_granted']))
                throw new RuntimeException('PSTE_TITLE_DESK_UNEXPECTED_PRODUCTION_WRITE');
            if(empty($result['no_change'])){
                $saved++;
                // Only a newly delivered title triggers the existing topic owner.
                // An unchanged retry is not a second semantic decision or a new job.
                if((string)($current['planning_suitability']??'')!=='YES')$reentry[]=$topic['pool_key'];
            }
        }
        $repair=$batch;
        $repair['items']=[];
        foreach($batch['items'] as $item){
            $key=(string)$item['pool_key'];
            if(!array_key_exists($key,$corrections))continue;
            $item['approved']=false;
            $item['editorial_review']=$corrections[$key];
            $repair['items'][]=$item;
        }
        return ['reviewed'=>count($preflight['approved']),'saved'=>$saved,'reentry'=>$reentry,
            'correction_batch'=>$repair];
    }

    /** Queue/transport only: bounded steps, one existing fachliche owner per topic. */
    public static function scheduleTitleDeskReentry(array $poolKeys,bool $replayCompleted=false): int {
        $poolKeys=array_values(array_unique(array_map('strval',$poolKeys)));
        if(!$poolKeys)return 0;
        if(count($poolKeys)>100)throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_BATCH_TOO_LARGE');
        foreach($poolKeys as $key){
            if($key===''||strlen($key)>120||preg_match('/[^a-zA-Z0-9_:\-]/',$key))throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_KEY_INVALID');
        }
        $state=get_option(self::TITLE_DESK_REENTRY_STATE,[]);
        if(!is_array($state)||($state['status']??'')!=='RUNNING'){
            $state=self::newTitleDeskReentryState($poolKeys);
        }else{
            $pending=(array)($state['pending']??[]);
            // A version-specific MINI replay may revisit completed keys; ordinary
            // imports preserve their existing done set. Never lose unrelated work.
            $done=(array)($state['done']??[]);
            if($replayCompleted){
                $done=array_values(array_diff($done,$poolKeys));
                foreach($poolKeys as $key)unset($state['outcomes'][$key]);
            }
            foreach($poolKeys as $key)if(!in_array($key,$pending,true)&&!in_array($key,$done,true))$pending[]=$key;
            $state['done']=$done;
            $state['pending']=$pending;
            $state['total']=count($pending)+count($done);
        }
        self::storeTitleDeskReentryState($state);
        self::armTitleDeskReentryWatchdog();
        return (int)$state['total'];
    }

    private static function newTitleDeskReentryState(array $poolKeys): array {
        return ['status'=>'RUNNING','token'=>bin2hex(random_bytes(32)),
            'pending'=>array_values($poolKeys),'done'=>[],'total'=>count($poolKeys),
            'updated_at'=>time()];
    }

    private static function storeTitleDeskReentryState(array $state): void {
        $state['updated_at']=time();
        if(!update_option(self::TITLE_DESK_REENTRY_STATE,$state,false)
            &&get_option(self::TITLE_DESK_REENTRY_STATE,null)!==$state)
            throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_STATE_WRITE_FAILED');
        if(get_option(self::TITLE_DESK_REENTRY_STATE,null)!==$state)
            throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_STATE_READBACK_FAILED');
    }

    private static function armTitleDeskReentryWatchdog(): bool {
        if(!function_exists('wp_schedule_single_event'))return false;
        // One native WordPress-cron fallback for lost HTTP loopbacks. No extra worker.
        if(function_exists('wp_next_scheduled')&&wp_next_scheduled(self::TITLE_DESK_REENTRY_HOOK,[[]]))return true;
        return wp_schedule_single_event(time()+20,self::TITLE_DESK_REENTRY_HOOK,[[]])===true;
    }

    /** Existing WP-cron callback; old 0.57.141 jobs are adopted without losing progress. */
    public static function processTitleDeskReentry(array $poolKeys=[]): void {
        $state=get_option(self::TITLE_DESK_REENTRY_STATE,[]);
        if((!is_array($state)||!isset($state['status']))&&$poolKeys){
            // 0.57.141 scheduled its remaining keys directly as cron arguments.
            $poolKeys=array_values(array_unique(array_map('strval',$poolKeys)));
            if(count($poolKeys)>100)return;
            $report=get_transient('pste_title_desk_reentry_report');
            $state=self::newTitleDeskReentryState($poolKeys);
            $state['total']=max(count($poolKeys),count($poolKeys)+(int)(is_array($report)?($report['processed']??0):0));
            self::storeTitleDeskReentryState($state);
        }
        self::advanceTitleDeskReentry();
    }

    /** Signed, internal, non-blocking continuation. No public production authority. */
    public static function continueTitleDeskReentry(): void {
        $token=(string)($_POST['token']??'');
        $state=get_option(self::TITLE_DESK_REENTRY_STATE,[]);
        if(!is_array($state)||($state['status']??'')!=='RUNNING'||!preg_match('/^[a-f0-9]{64}$/',$token)
            ||!hash_equals((string)($state['token']??''),$token)){
            if(function_exists('status_header'))status_header(403);
            exit;
        }
        self::advanceTitleDeskReentry();
        exit;
    }

    private static function kickTitleDeskReentry(): void {
        $state=get_option(self::TITLE_DESK_REENTRY_STATE,[]);
        if(!is_array($state)||($state['status']??'')!=='RUNNING')return;
        if(!function_exists('wp_remote_post')||!function_exists('admin_url'))return;
        // If the host disallows loopbacks, the WP-cron watchdog stays scheduled.
        wp_remote_post(admin_url('admin-ajax.php'),['timeout'=>1,'blocking'=>false,
            'redirection'=>0,'body'=>['action'=>self::TITLE_DESK_REENTRY_LOOPBACK,
                'token'=>(string)$state['token']]]);
    }

    private static function acquireTitleDeskReentryLock(): string {
        $token=bin2hex(random_bytes(24));
        $lease=['owner'=>$token,'expires_at'=>time()+120];
        if(add_option(self::TITLE_DESK_REENTRY_LOCK,$lease,'',false))return $token;
        // Expired leases are retired only if the exact stored value is still present.
        $prior=get_option(self::TITLE_DESK_REENTRY_LOCK,[]);
        if(!is_array($prior)||(int)($prior['expires_at']??0)>=time())return '';
        global $wpdb;
        $raw=maybe_serialize($prior);
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",
            self::TITLE_DESK_REENTRY_LOCK,$raw));
        wp_cache_delete(self::TITLE_DESK_REENTRY_LOCK,'options');
        return add_option(self::TITLE_DESK_REENTRY_LOCK,$lease,'',false)?$token:'';
    }

    private static function releaseTitleDeskReentryLock(string $token): void {
        global $wpdb;
        $prior=get_option(self::TITLE_DESK_REENTRY_LOCK,[]);
        if(!is_array($prior)||!hash_equals((string)($prior['owner']??''),$token))return;
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",
            self::TITLE_DESK_REENTRY_LOCK,maybe_serialize($prior)));
        wp_cache_delete(self::TITLE_DESK_REENTRY_LOCK,'options');
    }

    /** Bounded work time; the state is saved after EACH topic, not after the whole batch. */
    private static function advanceTitleDeskReentry(): void {
        $lock=self::acquireTitleDeskReentryLock();
        if($lock==='')return;
        $continue=false;
        $paused=false;
        try{
            $state=get_option(self::TITLE_DESK_REENTRY_STATE,[]);
            if(!is_array($state)||($state['status']??'')!=='RUNNING')return;
            $start=microtime(true);
            for($i=0;$i<self::TITLE_DESK_REENTRY_CHUNK&&$state['pending'];$i++){
                if($i>0&&(microtime(true)-$start)>=self::TITLE_DESK_REENTRY_SECONDS)break;
                $key=(string)$state['pending'][0];
                $result=self::processOneTitleDeskReentry($key);
                // Availability and storage faults belong to the transport, not to the
                // category owner. Keep the current key queued instead of claiming it was handled.
                if(self::retryableTitleDeskReentryFault($result)){
                    $state['last_error']=(string)($result['error_code']??'PSTE_TITLE_DESK_REENTRY_RETRY');
                    self::storeTitleDeskReentryState($state);
                    $paused=true;
                    break;
                }
                self::recordTitleDeskReentry($result);
                array_shift($state['pending']);
                $state['done'][]=$key;
                if(!isset($state['outcomes'])||!is_array($state['outcomes']))$state['outcomes']=[];
                $state['outcomes'][$key]=['status'=>(string)($result['status']??'UNKNOWN'),'error_code'=>(string)($result['error_code']??'')];
                $state['last_error']='';
                self::storeTitleDeskReentryState($state);
            }
            if(!$state['pending']){
                $state['status']='COMPLETE';
                self::storeTitleDeskReentryState($state);
                if(function_exists('wp_clear_scheduled_hook'))wp_clear_scheduled_hook(self::TITLE_DESK_REENTRY_HOOK,[[]]);
            }else{
                // Do not start an immediate retry storm when a shared prerequisite is absent.
                $continue=!$paused;
                self::armTitleDeskReentryWatchdog();
            }
        }finally{self::releaseTitleDeskReentryLock($lock);}
        if($continue)self::kickTitleDeskReentry();
    }

    /** Only global infrastructure faults are retryable; ordinary fachliche holds stay final. */
    private static function retryableTitleDeskReentryFault(array $result): bool {
        if(($result['status']??'')!=='BLOCKED')return false;
        $code=(string)($result['error_code']??'');
        foreach(['PSTE_TITLE_DESK_REENTRY_PLUGIN_NOT_READY','PSTE_TITLE_DESK_REENTRY_BASELINE_REQUIRED',
            'PSTE_TITLE_DESK_REENTRY_CONTEXT_NOT_COMPLETE','PSTE_TITLE_DESK_REENTRY_BINDING_INVALID',
            'PSTE_TITLE_DESK_REENTRY_BOUNDARY_VIOLATION',
            'PSTE_RETAINED_BACKLOG_READ_FAILED','PSTE_RETAINED_BACKLOG_CONTEXT_BINDING_REQUIRED',
            'PSTE_RETAINED_BACKLOG_INVENTORY_BINDING_MISMATCH'] as $prefix){
            if(str_starts_with($code,$prefix))return true;
        }
        return false;
    }

    /** Existing owner performs exactly the same checks as 0.57.141; never promote here. */
    private static function processOneTitleDeskReentry(string $poolKey): array {
        $resultRecord=['status'=>'BLOCKED','pool_key'=>(string)$poolKey];
        try{
            if(!PSTE_Plugin::isReady())throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_PLUGIN_NOT_READY');
            if(!is_string($poolKey)||$poolKey===''||strlen($poolKey)>120||preg_match('/[^a-zA-Z0-9_:\-]/',$poolKey))throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_KEY_INVALID');
            global $wpdb;$table=PSTE_Repository::table('topic_pool');
            $row=$wpdb->get_row($wpdb->prepare("SELECT id,candidate_id,manual_status FROM $table WHERE pool_key=%s",$poolKey),ARRAY_A);
            if(!is_array($row)||(int)($row['id']??0)<1)throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_ROW_MISSING');
            if((string)($row['manual_status']??'')!=='')throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_MANUAL_REVIEW_UNCHANGED');
            $candidateId=(string)($row['candidate_id']??'');
            if(!preg_match('/^[a-f0-9]{64}$/',$candidateId))throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_ID_INVALID');
            $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
            if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_BASELINE_REQUIRED');
            $context=PSTE_Context_Refresh::status();
            if((string)($context['status']??'')!=='COMPLETE')throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_CONTEXT_NOT_COMPLETE');
            $binding=PSTE_Context_Index_Store::runtimeBinding($context,$baseline);
            if(($binding['contract']??'')!=='PSTE_CONTEXT_INDEX_RUNTIME_BINDING_V2')throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_BINDING_INVALID');
            $result=PSTE_Repository::reanalyzeRetainedBacklogBatch((int)$row['id']-1,1,$baseline,$binding,[$candidateId]);
            if((int)($result['processed']??0)!==1||(int)($result['provider_calls']??-1)!==0||!empty($result['article_or_taxonomy_write_attempted'])||!empty($result['production_handoff_attempted']))
                throw new RuntimeException('PSTE_TITLE_DESK_REENTRY_BOUNDARY_VIOLATION');
            // The existing topic owner alone decides readiness. A processed item is not necessarily usable.
            $usable=in_array($poolKey,(array)($result['usable_keys']??[]),true);
            $resultRecord=['status'=>$usable?'PASS':'HELD','pool_key'=>$poolKey,'promoted'=>(int)($result['promoted']??0)];
            if(!$usable)$resultRecord['error_code']='PSTE_TITLE_DESK_REENTRY_OWNER_NOT_READY';
        }catch(Throwable $e){
            $resultRecord=['status'=>'BLOCKED','pool_key'=>(string)$poolKey,
                'error_code'=>substr((string)preg_replace('/[^A-Z0-9_:\-]/i','_',strtoupper($e->getMessage())),0,160)];
        }
        return $resultRecord;
    }

    /** A failed topic remains visible even when later topics pass. */
    private static function recordTitleDeskReentry(array $result): void {
        set_transient('pste_title_desk_last_reentry',$result,3600);
        $report=get_transient('pste_title_desk_reentry_report');
        if(!is_array($report))$report=['scheduled'=>0,'processed'=>0,'held'=>0,'blocked'=>[]];
        $report['processed']=(int)($report['processed']??0)+1;
        if(($result['status']??'')!=='PASS'){
            $report['held']=(int)($report['held']??0)+1;
            $blocked=(array)($report['blocked']??[]);
            $blocked[]=['pool_key'=>(string)($result['pool_key']??''),'error_code'=>(string)($result['error_code']??'UNKNOWN')];
            $report['blocked']=array_slice($blocked,-100);
        }
        set_transient('pste_title_desk_reentry_report',$report,86400);
    }

    public static function exportPlanningTopics(): void {
        PSTE_Auth::assertAdmin('pste_export_planning_topics',(string)($_POST['_wpnonce']??''));
        try{
            if(!class_exists('PSERC_Plan_Snapshot_Store')||!class_exists('PSERC_Plan_Dependency_Fingerprint'))throw new RuntimeException('PSTE_K0_PSERC_PLUGIN_REQUIRED');
            $isManual=array_key_exists('pste_manual_k0_run',$_POST);
            $manualRun=sanitize_text_field((string)($_POST['pste_manual_k0_run']??''));
            // The normal production download must use the same audit authority as
            // UI state and the AJAX automation. An old READY file must NEVER be
            // exportable while the fresh topic audit is still outstanding.
            // Manual selected-topic exports keep their independently scoped rules.
            if(!$isManual&&!PSTE_Breadth_Research_Queue::existingOnlyAuditCurrent())
                throw new RuntimeException('PSTE_K0_AUTOMATIC_AUDIT_NOT_CURRENT');
            $header=PSERC_Plan_Snapshot_Store::getActive();
            if(!PSERC_Plan_Snapshot_Store::verifyHeader($header)||!PSERC_Plan_Dependency_Fingerprint::isCurrent((array)($header['dependency']??[])))throw new RuntimeException('PSTE_K0_PSERC_SNAPSHOT_STALE_OR_MISSING');
            $batch=PSERC_Plan_Snapshot_Store::materializeReadyBatch($header);
            // Automatik remains unchanged. Manual K0 can export ONLY this intake's identities.
            if($isManual&&$manualRun==='')throw new RuntimeException('PSTE_SHORTPATH_RUN_REQUIRED');
            if($isManual){
                $batch=self::k0ReadyBatchFromPsercSnapshot($batch,self::manualK0TopicIdentityIndex($manualRun));
            }else{
                // The signed current PSERC snapshot is the authority; no second
                // title/category/type decision during the automatic export.
                self::validateK0ReadyBatch($batch);
            }
            if($isManual)self::shortPathTraceRecord($manualRun,'EXPORT_ERSTELLT',['selected_count'=>(int)($batch['item_count']??0)]);
            PSTE_Flight_Recorder::handoff((int)($batch['item_count']??0),$isManual?'MANUAL_K0_METADATA':'AUTOMATIC_K0_METADATA');
            self::jsonDownload($batch,($manualRun!==''?'pste-kurzer-dienstweg-':'seo-redaktionsplan-produktionshandoff-').(string)$batch['batch_sha256'].'.json');
        }catch(Throwable $e){
            if(!empty($manualRun))try{self::shortPathTraceRecord($manualRun,'EXPORT_BLOCKIERT',['error_code'=>self::safeErrorCode($e)]);}catch(Throwable $ignored){}
            self::blocked('overview',$e);
        }
    }

    /**
     * Validate and return the exact PSERC handoff expected by K0.
     * No plan_slot generation, no PSERC rule duplication, no fallback conversion.
     * @param array<string,mixed> $snapshot
     * @param array<string,bool> $allowedK0Identities
     * @return array<string,mixed>
     */
    public static function k0ReadyBatchFromPsercSnapshot(array $snapshot,array $allowedK0Identities): array {
        $batch=(($snapshot['contract']??'')==='PSERC_TEXTMACHINE_METADATA_BATCH_V2')?$snapshot:(is_array($snapshot['next_textmachine_metadata_batch']??null)?(array)$snapshot['next_textmachine_metadata_batch']:[]);
        if(!$batch)throw new RuntimeException('PSTE_K0_PSERC_READY_BATCH_MISSING');
        self::validateK0ReadyBatch($batch);
        $selected=[];
        foreach((array)$batch['items'] as $item){$item=(array)$item;$identity=self::k0FourFieldIdentity($item);if($identity!==''&&isset($allowedK0Identities[$identity]))$selected[]=$item;}
        if(!$selected)throw new RuntimeException('PSTE_K0_PSERC_NO_CURRENT_K0_ITEMS');
        if(count($selected)===(int)$batch['item_count'])return $batch;
        $out=['contract'=>'PSERC_TEXTMACHINE_METADATA_BATCH_V2','status'=>'READY_FOR_TEXTMACHINE_METADATA_INTAKE','item_count'=>count($selected),'publish_allowed'=>false,'content_or_format_payload_present'=>false,'items'=>array_values($selected)];
        $out['batch_sha256']=self::stableJsonSha256($out);self::validateK0ReadyBatch($out);return $out;
    }

    /** @param array<string,mixed> $batch */
    public static function validateK0ReadyBatch(array $batch): void {
        // PSERC owns the handoff. PSTE may export its result, never re-decide it.
        if(!class_exists('PSERC_Metadata_Boundary'))throw new RuntimeException('PSTE_K0_PSERC_BOUNDARY_REQUIRED');
        PSERC_Metadata_Boundary::requireReadyBatchForExport($batch);
    }

    /** Exact manual K0 intake, matched against the existing read-only compiler projection. */
    private static function manualK0TopicIdentityIndex(string $runUuid): array {
        global $wpdb;
        if(!preg_match('/^[0-9a-fA-F-]{36}$/',$runUuid))throw new RuntimeException('PSTE_SHORTPATH_RUN_UUID_INVALID');
        $run=PSTE_Repository::runByUuid($runUuid);
        if(!is_array($run)||(string)($run['seed']??'')!=='MANUAL_TOPIC_INTAKE')throw new RuntimeException('PSTE_SHORTPATH_RUN_NOT_MANUAL_INTAKE');
        $rows=$wpdb->get_results($wpdb->prepare('SELECT payload_json FROM '.PSTE_Repository::table('candidates').' WHERE run_uuid=%s ORDER BY id ASC LIMIT 51',$runUuid),ARRAY_A);
        if($rows===null&&(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_SHORTPATH_RUN_TOPIC_READ_FAILED');
        if(count((array)$rows)>50)throw new RuntimeException('PSTE_SHORTPATH_RUN_TOO_MANY_TOPICS');
        $wanted=[];
        foreach((array)$rows as $row){
            $manual=PSTE_Repository::decodeStoredCandidatePayload((string)($row['payload_json']??''));
            if((string)($manual['manual_topic_intake']['contract']??'')!=='PSTE_MANUAL_TOPIC_INTAKE_V1')continue;
            if(PSTE_Repository::workflowRouteForCandidate($manual)!=='K0')continue;
            $key=PSTE_Repository::globalTopicKeyForCandidate($manual);
            if($key==='')throw new RuntimeException('PSTE_SHORTPATH_POOL_KEY_MISSING');
            $wanted[$key]=true;
        }
        if(!$wanted)throw new RuntimeException('PSTE_SHORTPATH_K0_NO_SELECTED_READY_TOPICS');
        $out=[];$cursor=null;$pages=0;
        do{
            // Same projection already consumed by PSERC; read-only, no research/backlog replay.
            $page=PSTE_Compiler_Read_Capability::topicPage($cursor,25);
            if((string)($page['contract']??'')!=='PSTE_COMPILER_PLANNING_TOPIC_PAGE_V1')throw new RuntimeException('PSTE_SHORTPATH_COMPILER_PAGE_INVALID');
            foreach((array)($page['items']??[]) as $candidate){
                if(!is_array($candidate))continue;
                $key=(string)($candidate['pool_key']??'');
                if(!isset($wanted[$key])||PSTE_Repository::workflowRouteForCandidate($candidate)!=='K0'||(string)($candidate['planning_suitability']??'')!=='YES')continue;
                $item=[
                    'title'=>trim(PSTE_Editorializer::displayTitle($candidate)),
                    'target_keyword'=>trim((string)($candidate['target_keyword']??'')),
                    'category'=>trim((string)($candidate['target_category_slug']??$candidate['suggested_category_slug']??'')),
                    'article_type'=>trim((string)($candidate['proposed_article_type']??$candidate['suggested_article_type']??'')),
                ];
                $identity=self::k0FourFieldIdentity($item);
                if($identity!=='')$out[$identity]=true;
            }
            $complete=!empty($page['complete']);
            $cursor=is_array($page['next_cursor']??null)?$page['next_cursor']:null;
            if(!$complete&&$cursor===null)throw new RuntimeException('PSTE_SHORTPATH_COMPILER_CURSOR_MISSING');
            if(++$pages>1000)throw new RuntimeException('PSTE_SHORTPATH_COMPILER_PAGE_LIMIT');
        }while(!$complete);
        if(!$out)throw new RuntimeException('PSTE_SHORTPATH_K0_NO_SELECTED_READY_TOPICS');
        return $out;
    }

    /** @param array<string,mixed> $item */
    private static function k0FourFieldIdentity(array $item): string {
        $parts=[];foreach(['title','target_keyword','category','article_type'] as $field){$v=trim((string)($item[$field]??''));if($v==='')return '';$parts[]=$v;}return hash('sha256',implode("\n",$parts));
    }
    /** @param array<string,mixed> $item */
    private static function k0FiveFieldIdentity(array $item): string {
        $parts=[];foreach(['article_type','category','plan_slot','target_keyword','title'] as $field)$parts[]=(string)($item[$field]??'');return hash('sha256',implode("\n",$parts));
    }
    /** @param mixed $value */
    private static function stableJsonSha256($value): string {
        $stable=function($v)use(&$stable){if(!is_array($v))return $v;if($v===[])return [];$isList=array_keys($v)===range(0,count($v)-1);if($isList)return array_map($stable,$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=$stable($x);return $v;};
        $json=wp_json_encode($stable($value),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($json))throw new RuntimeException('PSTE_K0_HANDOFF_HASH_ENCODE_FAILED');return hash('sha256',$json);
    }

    public static function sandboxExport(): void {
        PSTE_Auth::assertAdmin('pste_sandbox_export',(string)($_POST['_wpnonce']??''));$guard=self::credentialFreeArtifactGuard();$tmp=tmpfile();if($tmp===false)throw new RuntimeException('PSTE_SANDBOX_EXPORT_TEMPFILE_FAILED');
        try{$info=PSTE_Semantic_Review_Sandbox::streamExportToResource($tmp,$guard);$size=ftell($tmp);if($size===false||(int)$size!==(int)$info['bytes'])throw new RuntimeException('PSTE_SANDBOX_EXPORT_SIZE_MISMATCH');rewind($tmp);nocache_headers();header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="pste-semantic-review-sandbox-'.gmdate('Ymd-His').'-utc.json"');header('Content-Length: '.(string)$size);fpassthru($tmp);exit;}finally{fclose($tmp);}
    }
    public static function sandboxReviewRelevance(): void {try{PSTE_Auth::assertAdmin('pste_sandbox_review_relevance',(string)($_POST['_wpnonce']??''));$id=sanitize_text_field((string)($_POST['sandbox_id']??''));$decision=sanitize_text_field((string)($_POST['relevance_decision']??''));$expected=strtolower(sanitize_text_field((string)($_POST['expected_response_sha256']??'')));$expectedCurrent=strtolower(sanitize_text_field((string)($_POST['expected_current_decision_sha256']??'')));$note=sanitize_text_field((string)($_POST['review_note']??''));if($note==='')throw new RuntimeException('PSTE_SANDBOX_EXPLICIT_REVIEW_NOTE_REQUIRED');PSTE_Semantic_Review_Sandbox::reviewOrReviseRelevance($id,$decision,$expected,$expectedCurrent,$note,get_current_user_id());self::redirect('review','sandbox_view=1&sandbox_relevance_reviewed=1');}catch(Throwable $e){self::blocked('review',$e);}}
    public static function sandboxConfirmInternal(): void {try{PSTE_Auth::assertAdmin('pste_sandbox_confirm_internal',(string)($_POST['_wpnonce']??''));$id=sanitize_text_field((string)($_POST['sandbox_id']??''));$expected=strtolower(sanitize_text_field((string)($_POST['expected_proposal_sha256']??'')));$note=sanitize_text_field((string)($_POST['review_note']??''));if($note==='')throw new RuntimeException('PSTE_SANDBOX_INTERNAL_REVIEW_NOTE_REQUIRED');PSTE_Semantic_Review_Sandbox::confirmInternalProposalForNormalReentry($id,$expected,$note,get_current_user_id());self::redirect('review','sandbox_view=1&sandbox_internal_confirmed=1');}catch(Throwable $e){self::blocked('review',$e);}}
    public static function sandboxStartAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_sandbox_ajax',(string)($_POST['nonce']??''));
            if(empty($_POST['confirm_cost']))throw new RuntimeException('PSTE_COST_CONFIRMATION_REQUIRED');
            $job=PSTE_Semantic_Review_Sandbox::startAnalysis(PSTE_Plugin::settings());
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job],$level);
    }
    public static function sandboxAdvanceAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_sandbox_ajax',(string)($_POST['nonce']??''));
            $job=PSTE_Semantic_Review_Sandbox::advanceAnalysis(sanitize_text_field((string)($_POST['job_uuid']??'')),PSTE_Plugin::settings(),!empty($_POST['explicit_resume']));
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job],$level);
    }
    public static function sandboxCancelUnknownAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_sandbox_ajax',(string)($_POST['nonce']??''));
            if(empty($_POST['provider_checked']))throw new RuntimeException('PSTE_PROVIDER_ACCOUNT_CHECK_REQUIRED');
            $job=PSTE_Semantic_Review_Sandbox::cancelUnknownJob(sanitize_text_field((string)($_POST['job_uuid']??'')));
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job],$level);
    }

    public static function researchOrphanCancelAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            $requested=sanitize_text_field((string)($_POST['job_uuid']??''));
            $active=PSTE_Research_Job::current();
            if(!is_array($active)||!hash_equals((string)($active['job_uuid']??''),$requested))throw new RuntimeException('PSTE_RESEARCH_JOB_ID_MISMATCH');
            if(!in_array((string)($active['status']??''),['RUNNING','PAUSED_ERROR'],true))throw new RuntimeException('PSTE_SINGLE_SAFE_CANCEL_NOT_ALLOWED');
            $breadth=PSTE_Breadth_Research_Queue::current();
            if(is_array($breadth)&&in_array((string)($breadth['status']??''),['RUNNING','PAUSED_ERROR'],true))throw new RuntimeException('PSTE_SINGLE_SAFE_CANCEL_OWNED_BY_BREADTH');
            $job=PSTE_Research_Job::cancelForBreadthStop($requested);PSTE_Research_Driver::kick(0,'CANCEL_RECONCILE_SINGLE');
        }catch(Throwable $e){
            if((string)$e->getMessage()==='PSTE_RESEARCH_STEP_ALREADY_RUNNING'){
                try{$current=PSTE_Research_Job::current();}catch(Throwable $ignored){$current=null;}
                try{$breadth=PSTE_Breadth_Research_Queue::current();}catch(Throwable $ignored){$breadth=null;}
                if(is_array($current)&&hash_equals((string)($current['job_uuid']??''),$requested)&&(!is_array($breadth)||!in_array((string)($breadth['status']??''),['RUNNING','PAUSED_ERROR'],true))){self::ajaxSuccess(['job'=>$current,'busy'=>true,'retry_after_ms'=>1500],$level);return;}
            }
            self::ajaxError($e,$level,400);return;
        }
        self::ajaxSuccess(['job'=>$job,'busy'=>false,'provider_calls'=>0,'driver'=>PSTE_Research_Driver::status()],$level);
    }

    public static function researchCancelAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            $requested=sanitize_text_field((string)($_POST['job_uuid']??''));$job=PSTE_Research_Job::cancelAfterProviderCheck($requested,!empty($_POST['provider_checked']));PSTE_Research_Driver::kick(0,'CANCEL_RECONCILE_SINGLE');
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job,'driver'=>PSTE_Research_Driver::status()],$level);
    }


    /** Minimal bounded, admin-only diagnostic record. Never touches SEO candidates, snapshots or research state. */
    private static function shortPathTraceRecord(string $runUuid,string $event,array $data=[]): void {
        $runUuid=preg_match('/^[a-fA-F0-9-]{36}$/',$runUuid)?strtolower($runUuid):'';
        $event=(string)preg_replace('/[^A-Z0-9_]/','',strtoupper($event));
        $data=array_intersect_key($data,array_flip(['route','topics','selected_count','phase','status','generation','candidate_index','topic_count','planning_topic_count_expected','eligible_count','held_count','ready_count','ready','not_ready','processed','manual_decision_blocked','error_code','lease_busy','last_tick_metrics','outcomes']));
        if(isset($data['topics']))$data['topics']=array_map(static fn($v)=>substr((string)$v,0,400),array_slice((array)$data['topics'],0,50));
        if(isset($data['error_code']))$data['error_code']=substr((string)preg_replace('/[^A-Z0-9_:-]/','_',strtoupper((string)$data['error_code'])),0,180);
        if(isset($data['outcomes']))$data['outcomes']=array_map(static fn($r)=>['topic'=>substr((string)($r['topic']??''),0,240),'status'=>substr((string)($r['status']??''),0,80),'reason_codes'=>array_map(static fn($c)=>substr((string)preg_replace('/[^A-Z0-9_:-]/','_',strtoupper((string)$c)),0,140),array_slice((array)($r['reason_codes']??[]),0,12))],array_slice((array)$data['outcomes'],0,50));
        $state=get_option(self::SHORTPATH_TRACE_OPTION,[]);$events=is_array($state)&&is_array($state['events']??null)?$state['events']:[];
        $last=$events?end($events):null;
        $entry=['utc'=>gmdate('c'),'run_uuid'=>$runUuid,'event'=>$event,'data'=>$data];
        $same=is_array($last)&&($last['run_uuid']??'')===$runUuid&&($last['event']??'')===$event&&($last['data']??null)===$data;
        if($same)return;
        $events[]=$entry;
        update_option(self::SHORTPATH_TRACE_OPTION,['contract'=>'PSTE_SHORTPATH_DIAGNOSTICS_V1','events'=>array_slice($events,-80)],false);
    }

    /** Data copied only from the PSERC persisted job; no compiler execution here. */
    private static function shortPathSafeCompilerView(array $job): array {
        $out=[];
        foreach(['phase','status','generation','candidate_index','topic_count','planning_topic_count_expected','eligible_count','held_count','ready_count','error_code','lease_busy'] as $k){if(isset($job[$k]))$out[$k]=is_scalar($job[$k])?$job[$k]:'';}
        $m=is_array($job['last_tick_metrics']??null)?$job['last_tick_metrics']:[];
        $out['last_tick_metrics']=array_intersect_key($m,array_flip(['wall_ms','query_count','records_read','records_written']));
        return $out;
    }

    /** For a live shortpath run, the compiler may be global; do not attribute its counters to selected rows. */
    private static function shortPathCurrentCompiler(): array {
        if(!class_exists('PSERC_Plan_Snapshot_Store'))return ['status'=>'NICHT_INSTALLIERT'];
        try{return self::shortPathSafeCompilerView((array)PSERC_Plan_Snapshot_Store::getJob());}
        catch(Throwable $e){return ['status'=>'DIAGNOSE_NICHT_VERFUEGBAR','error_code'=>self::safeErrorCode($e)];}
    }

    /** Read only the EXISTING signed queue and driver options; no extra log tables. */
    private static function automationDiagnosticsSnapshot(): array {
        $v=['status'=>'NICHT_GESTARTET','processed'=>0,'total'=>0,'local_provider_calls'=>0,'audit_recheck_reason'=>'','queue_error'=>'','driver_error'=>''];
        try{
            $q=PSTE_Breadth_Research_Queue::peek();
            if(is_array($q)){
                $v['status']=(string)($q['status']??'UNBEKANNT');
                $v['processed']=(int)($q['local_backlog_processed']??0);
                $v['total']=(int)($q['local_backlog_total']??0);
                $v['local_provider_calls']=(int)($q['local_backlog_provider_calls']??0);
                $v['audit_recheck_reason']=(string)($q['audit_recheck_reason']??'');
                $v['queue_error']=(string)($q['last_error']??'');
            }
        }catch(Throwable $e){$v['queue_error']=self::safeErrorCode($e);}
        try{$d=PSTE_Research_Driver::status();$v['driver_error']=(string)($d['last_error']??'');}
        catch(Throwable $e){$v['driver_error']=self::safeErrorCode($e);}
        return $v;
    }

    private static function shortPathDiagnosticsPayload(string $runUuid=''): array {
        $state=get_option(self::SHORTPATH_TRACE_OPTION,[]);
        $events=is_array($state)&&is_array($state['events']??null)?$state['events']:[];
        if($runUuid===''){
            for($i=count($events)-1;$i>=0;$i--){
                $candidate=(string)($events[$i]['run_uuid']??'');
                if(preg_match('/^[a-fA-F0-9-]{36}$/',$candidate)){$runUuid=$candidate;break;}
            }
            if($runUuid===''){
                try{$latest=PSTE_Repository::latestRun();if(is_array($latest)&&($latest['seed']??'')==='MANUAL_TOPIC_INTAKE')$runUuid=(string)($latest['run_uuid']??'');}
                catch(Throwable $ignored){}
            }
        }
        if($runUuid!=='')$events=array_values(array_filter($events,static fn($e)=>is_array($e)&&($e['run_uuid']??'')===$runUuid));
        $selected=[];
        if($runUuid!==''&&preg_match('/^[0-9a-fA-F-]{36}$/',$runUuid)){
            try{
                $run=PSTE_Repository::runByUuid($runUuid);
                if(is_array($run)&&(string)($run['seed']??'')==='MANUAL_TOPIC_INTAKE'){
                    $items=PSTE_Repository::candidatesForRun($runUuid);
                    foreach(array_slice($items,0,50) as $item){
                        $reasons=array_slice((array)($item['reason_codes']??[]),0,12);
                        $selected[]=['topic'=>substr((string)($item['raw_user_question']??$item['editorial_title']??''),0,240),'status'=>substr((string)($item['pool_status']??$item['decision']??'UNBEKANNT'),0,80),'planning_suitability'=>substr((string)($item['planning_suitability']??''),0,40),'category'=>substr((string)($item['target_category_slug']??''),0,100),'article_type'=>substr((string)($item['proposed_article_type']??''),0,60),'reason_codes'=>array_map(static fn($v)=>substr((string)$v,0,140),$reasons)];
                    }
                }
            }catch(Throwable $e){$selected=[['status'=>'PSTE_DIAGNOSE_THEMEN_LESEFEHLER','reason_codes'=>[self::safeErrorCode($e)]]];}
        }
        $lastError=get_transient('pste_last_error');
        $lastError=is_array($lastError)?substr((string)preg_replace('/[^A-Za-z0-9_:-]/','_',(string)($lastError['error']??'')),0,180):'';
        return ['contract'=>'PSTE_SHORTPATH_DIAGNOSTICS_V1','as_of'=>gmdate('c'),'run_uuid'=>$runUuid,'compiler_is_global'=>true,'automatik'=>self::automationDiagnosticsSnapshot(),'compiler'=>self::shortPathCurrentCompiler(),'selected_topics'=>$selected,'last_ui_error_code'=>$lastError,'events'=>array_slice($events,-80),'provider_calls_by_diagnostic'=>0,'changes_to_topics_or_plans'=>false];
    }

    private static function shortPathDiagnosticsText(array $p): string {
        $c=(array)($p['compiler']??[]);
        $a=(array)($p['automatik']??[]);
        $rows=['Stand UTC: '.(string)($p['as_of']??''),
            'AUTOMATIK: '.(string)($a['status']??'NICHT_GESTARTET').' · Bestand '.(int)($a['processed']??0).' / '.(int)($a['total']??0).' · Provider '.(int)($a['local_provider_calls']??0)];
        if((string)($a['audit_recheck_reason']??'')!=='')$rows[]='AUTOMATIK NACHPRUEFUNG: '.(string)$a['audit_recheck_reason'];
        if((string)($a['queue_error']??'')!=='')$rows[]='AUTOMATIK WARTESCHLANGENFEHLER: '.(string)$a['queue_error'];
        if((string)($a['driver_error']??'')!=='')$rows[]='AUTOMATIK SERVERFEHLER: '.(string)$a['driver_error'];
        $rows[]='KURZER DIENSTWEG: '.(string)($p['run_uuid']??'(letzte Ereignisse)');
        $rows[]='Compiler (GESAMTBESTAND, nicht nur gewählte Themen): '.(string)($c['status']??'UNBEKANNT').' / '.(string)($c['phase']??'').' · geprüft '.(int)($c['candidate_index']??0).' · READY '.(int)($c['ready_count']??0).' · zurückgehalten '.(int)($c['held_count']??0);
        if(!empty($c['error_code']))$rows[]='Compiler-Fehlercode: '.(string)$c['error_code'];
        if(!empty($p['last_ui_error_code']))$rows[]='Letzter Bildschirm-Fehler: '.(string)$p['last_ui_error_code'];
        foreach((array)($p['selected_topics']??[]) as $topic){
            if(!is_array($topic))continue;
            $rows[]='THEMA: '.(string)($topic['topic']??'').' · '.(string)($topic['status']??'').' · planbar '.(string)($topic['planning_suitability']??'UNBEKANNT').' · '.(string)($topic['category']??'');
            if(!empty($topic['reason_codes']))$rows[]='    Grund: '.implode(', ',(array)$topic['reason_codes']);
        }
        foreach((array)($p['events']??[]) as $e){
            if(!is_array($e))continue;
            $d=(array)($e['data']??[]);
            $summary=(string)($d['phase']??$d['route']??'');
            if(isset($d['candidate_index']))$summary.=' · geprüft '.(int)$d['candidate_index'];
            if(isset($d['ready_count']))$summary.=' · READY '.(int)$d['ready_count'];
            if(isset($d['selected_count']))$summary.=' · Auswahl '.(int)$d['selected_count'];
            if(isset($d['ready']))$summary.=' · freigabefaehig '.(int)$d['ready'].' / nicht bereit '.(int)($d['not_ready']??0);
            if(!empty($d['error_code']))$summary.=' · FEHLER '.(string)$d['error_code'];
            $rows[]=(string)($e['utc']??'').'  '.(string)($e['event']??'').'  '.$summary;
            if(!empty($d['topics']))foreach((array)$d['topics'] as $t)$rows[]='    - '.(string)$t;
            if(!empty($d['outcomes']))foreach((array)$d['outcomes'] as $o)$rows[]='    '.(string)($o['topic']??'').' → '.(string)($o['status']??'').' ['.implode(', ',(array)($o['reason_codes']??[])).']';
        }
        return implode("\n",$rows);
    }

    private static function renderShortPathDiagnostics(string $manualRun): void {
        $p=self::shortPathDiagnosticsPayload($manualRun);
        $manualRun=(string)($p['run_uuid']??'');
        echo '<details class="pste-box" style="margin-top:12px" open><summary><strong>Kurzer Dienstweg – Fehlerprotokoll</strong> (letzte 80 Ereignisse)</summary>';
        echo '<p>Zeigt gespeicherte Kurzweg-Ereignisse und den <strong>globalen</strong> Compilerstatus. Keine erneute Recherche, kein Neustart.</p>';
        echo '<p id="pste-shortpath-trace-status">Zeitstempel UTC · '.esc_html((string)$p['as_of']).'</p>';
        echo '<pre id="pste-shortpath-trace" style="padding:12px;max-height:320px;overflow:auto;white-space:pre-wrap;background:#f6f7f7;border:1px solid #dcdcde">'.esc_html(self::shortPathDiagnosticsText($p)).'</pre>';
        echo '<p>Die gespeicherten Kurzweg-Ereignisse sind ebenfalls in der <strong>Gesamtdiagnose</strong> enthalten.</p></details>';
    }

    public static function shortPathDiagnosticsAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_shortpath_diagnostics',(string)($_POST['nonce']??''));
            $run=sanitize_text_field((string)($_POST['run_uuid']??''));
            if(!preg_match('/^[0-9a-fA-F-]{36}$/',$run))throw new RuntimeException('PSTE_DIAGNOSTIC_RUN_INVALID');
            $r=PSTE_Repository::runByUuid($run);
            if(!is_array($r)||(string)($r['seed']??'')!=='MANUAL_TOPIC_INTAKE')throw new RuntimeException('PSTE_DIAGNOSTIC_RUN_NOT_MANUAL');
            $clientErr=strtoupper(sanitize_text_field((string)($_POST['client_error_code']??'')));
            if($clientErr!=='')self::shortPathTraceRecord($run,'BROWSER_FEHLER',['error_code'=>$clientErr]);
            $c=self::shortPathCurrentCompiler();
            $status=(string)($c['status']??'');
            $event=$status==='BLOCKED'?'COMPILER_BLOCKIERT':($status==='COMPLETE'?'COMPILER_FERTIG':'COMPILER_PHASE');
            self::shortPathTraceRecord($run,$event,$c);
            $p=self::shortPathDiagnosticsPayload($run);
            self::ajaxSuccess(['as_of'=>$p['as_of'],'text'=>self::shortPathDiagnosticsText($p)],$level);
        }catch(Throwable $e){self::ajaxError($e,$level,400);}
    }

    public static function shortPathDiagnosticsDownload(): void {
        PSTE_Auth::assertAdmin('pste_shortpath_diagnostics',(string)($_POST['_wpnonce']??''));
        $run=sanitize_text_field((string)($_POST['run_uuid']??''));
        if($run!==''&&!preg_match('/^[0-9a-fA-F-]{36}$/',$run))wp_die('PSTE_DIAGNOSTIC_RUN_INVALID');
        $p=self::shortPathDiagnosticsPayload($run);
        self::jsonDownload($p,'pste-kurzweg-diagnose-'.gmdate('Ymd-His').'-utc.json');
    }

    /**
     * Hard JSON boundary for every PSTE admin AJAX response.
     * Any warning/notice/accidental echo emitted inside the PSTE action is discarded before
     * the JSON envelope is written. No provider request is retried here.
     */
    private static function ajaxBoundaryBegin(): int {
        $level=ob_get_level();
        ob_start();
        return $level;
    }
    private static function ajaxBoundaryClean(int $level): void {
        while(ob_get_level()>$level){@ob_end_clean();}
    }
    private static function ajaxSuccess(array $data,int $level): void {
        self::ajaxBoundaryClean($level);
        if(!headers_sent())header('X-PSTE-Ajax-Contract: PSTE_JSON_BOUNDARY_V1');
        wp_send_json_success($data);
    }
    private static function ajaxError(Throwable $e,int $level,int $status=400): void {
        $action=isset($_REQUEST['action'])&&is_string($_REQUEST['action'])?(string)$_REQUEST['action']:'';
        if(!in_array($action,['pste_evidence_read_batch','pste_evidence_history_batch'],true))PSTE_Flight_Recorder::event('WORKFLOW_ERROR','AJAX_BLOCKED',[
            'action'=>preg_replace('/[^a-z0-9_]/i','_',substr($action,0,70)),
            'error_code'=>self::safeErrorCode($e),'http_status'=>$status
        ]);
        self::ajaxBoundaryClean($level);
        if(!headers_sent())header('X-PSTE-Ajax-Contract: PSTE_JSON_BOUNDARY_V1');
        wp_send_json_error(['error_code'=>self::safeErrorCode($e)],$status);
    }

    private static function safeErrorCode(Throwable $e): string {$code=strtoupper(trim((string)$e->getMessage()));$code=(string)preg_replace('/[^A-Z0-9_:\-]/','_',$code);return substr($code!==''?$code:'PSTE_REQUEST_FAILED',0,180);}

    private static function isList($value): bool {
        if(!is_array($value))return false;
        $expected=0;
        foreach($value as $key=>$_){if($key!==$expected++)return false;}
        return true;
    }

    private static function globalCategoryDatalist(): void {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);echo '<datalist id="pste-global-category-list">';foreach((is_array($baseline)?($baseline['leaf_categories']??[]):[]) as $cat)echo '<option value="'.esc_attr((string)($cat['name']??'')).'"></option>';echo '</datalist>';
    }


    private static function tabs(string $active): void {echo '<nav class="nav-tab-wrapper">';foreach(self::VISIBLE_TABS as $key){$tab=self::TABS[$key];echo '<a class="nav-tab '.($active===$key?'nav-tab-active':'').'" href="'.esc_url(admin_url('admin.php?page='.$tab['slug'])).'">'.esc_html($key==='overview'?'Produktion':$tab['label']).'</a>';}echo '</nav>';}
    private static function connectionPanel(string $title,array $status,string $desc): void {echo '<div class="pste-connection"><h3>'.esc_html($title).' '.self::badge((string)$status['status'],(string)$status['label']).'</h3><p>'.esc_html($desc).'</p>';if(!empty($status['tested_at_utc']))echo '<p>Zuletzt geprüft: '.esc_html((string)$status['tested_at_utc']).' UTC</p>';if(!empty($status['error_code']))echo '<p>Fehlercode: <code>'.esc_html((string)$status['error_code']).'</code></p>';echo '</div>';}



    private static function priorityTable(array $rows,bool $full=false): void {echo '<table class="widefat striped pste-table"><thead><tr><th>Priorität</th><th>Kategorie</th><th>Thema</th><th>Typ</th><th>Status</th><th>Volumen</th>'.($full?'<th>Gewichtung</th>':'').'</tr></thead><tbody>';foreach($rows as $r){$parts=[];foreach(($r['components']??[]) as $k=>$v)$parts[]=$k.' '.$v;echo '<tr><td><strong>'.esc_html(number_format((float)$r['priority_score'],1,',','.')).'/100</strong></td><td>'.esc_html($r['category_name']).'</td><td>'.esc_html($r['topic']).'</td><td>'.esc_html($r['article_type']).'</td><td>'.self::badge($r['decision'],$r['decision']).'</td><td>'.esc_html(number_format((float)$r['search_volume'],0,',','.')).'</td>'.($full?'<td>'.esc_html(implode(' · ',$parts)).'</td>':'').'</tr>';}if(!$rows)self::emptyRow($full?7:6,'Noch keine priorisierbaren Themen.');echo '</tbody></table>';}
    /** @return list<string> */
    private static function availableArticleTypes(): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$types=[];
        foreach((is_array($baseline)?(array)($baseline['leaf_categories']??[]):[]) as $leaf){$type=trim((string)($leaf['article_type']??''));if($type!=='')$types[$type]=true;}
        $out=array_keys($types);sort($out,SORT_NATURAL|SORT_FLAG_CASE);return $out;
    }

    private static function card(string $title,string $value,string $note): void {echo '<section class="pste-card"><h3>'.esc_html($title).'</h3><div class="pste-card-value">'.$value.'</div><p>'.esc_html($note).'</p></section>';}
    private static function metric(string $label,$value): void {echo '<section class="pste-metric"><strong>'.esc_html((string)$value).'</strong><span>'.esc_html($label).'</span></section>';}
    private static function badge(string $state,string $label): string {$safe=strtolower(preg_replace('/[^a-z0-9_-]/i','-',$state));return '<span class="pste-badge pste-'.$safe.'">'.esc_html($label).'</span>';}
    private static function coverageLabel(string $state): string {return ['UNDERREPRESENTED'=>'UNTERBELICHTET','BALANCED'=>'AUSGEGLICHEN','OVERREPRESENTED'=>'ÜBERREPRÄSENTIERT','DATA_INSUFFICIENT'=>'DATEN FEHLEN'][$state]??$state;}
    private static function contextPublicState(array $job): array {
        $out=[];foreach(['contract','status','phase','payload_repair_status','payload_repair_cursor','payload_repair_total','processed','total','sandbox_record_store_status','sandbox_record_store_migration_status','sandbox_record_store_migration_cursor','sandbox_record_store_verification_cursor','sandbox_record_store_count','sandbox_binding_status','sandbox_processed','sandbox_total','dynamic_rebase_count','last_dynamic_rebase_reason','final_structure_mode','final_structure_rebase_count','error_code'] as $key)$out[$key]=$job[$key]??null;return $out;
    }

    private static function actionForm(string $action,string $nonce,string $label,string $class='secondary'): void {echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline-block;margin:8px 8px 8px 0">';wp_nonce_field($nonce);echo '<input type="hidden" name="action" value="'.esc_attr($action).'">';submit_button($label,$class,'submit',false);echo '</form>';}
    private static function row(string $k,string $v): void {echo '<tr><th style="width:280px">'.esc_html($k).'</th><td>'.esc_html($v).'</td></tr>';}
    private static function emptyRow(int $cols,string $text): void {echo '<tr><td colspan="'.esc_attr((string)$cols).'"><em>'.esc_html($text).'</em></td></tr>';}
    private static function redirect(string $tab,string $flag): void {$slug=self::TABS[$tab]['slug']??self::PARENT;wp_safe_redirect(admin_url('admin.php?page='.$slug.'&'.$flag));exit;}
    private static function blocked(string $tab,Throwable $e): void {
        PSTE_Flight_Recorder::event('WORKFLOW_ERROR','ADMIN_BLOCKED',[
            'screen'=>preg_replace('/[^A-Z0-9_]/i','_',substr($tab,0,32)),
            'error_code'=>self::safeErrorCode($e)]);
        $details=[];
        if(method_exists($e,'safeDetails'))$details=(array)$e->safeDetails();
        set_transient('pste_last_error',['status'=>'BLOCKED','error'=>$e->getMessage(),'details'=>self::safeDiagnosticDetails($details)],300);
        self::redirect($tab,'blocked=1');
    }
    /** @param array<string,mixed> $details @return array<string,mixed> */
    private static function safeDiagnosticDetails(array $details): array {
        $allowed=['http_code','provider_status_code','provider_message','task_index','tasks_count','tasks_error','method','path','attempt','response_sha256','reason_code','term_id','name','slug','article_type','expected_article_type','accepted_category_names','mapping_status','expected_product_page_slug','quarantined_category_count','unresolved_count','first_unresolved','first_quarantined','candidate_count','candidate_page_ids','post_id','category_ids','page_id','missing_parent_id','cycle_at','declared_count','actual_count','expected_sha256','actual_sha256'];
        $out=[];
        $clean=static function($value,int $depth=0) use (&$clean){
            if(is_int($value)||is_float($value)||is_bool($value))return $value;
            if(is_string($value)){$value=preg_replace('/[\x00-\x1F\x7F]+/u',' ',trim($value))??'';return function_exists('mb_substr')?mb_substr($value,0,240,'UTF-8'):substr($value,0,240);}
            if(!is_array($value)||$depth>=2)return null;
            $result=[];$count=0;foreach($value as $k=>$v){if($count++>=20)break;$safe=$clean($v,$depth+1);if($safe!==null)$result[is_int($k)?$k:(string)$k]=$safe;}return $result;
        };
        foreach($allowed as $key){
            if(!array_key_exists($key,$details))continue;$safe=$clean($details[$key]);if($safe!==null)$out[$key]=$safe;
        }
        return $out;
    }
    private static function credentialFreeArtifactGuard(): callable {
        $badKey='/(?:^|_)(?:password|passwd|secret|authorization|api[_-]?key|api[_-]?login|credentials?|dataforseo[_-]?(?:login|password)|client_secret|access_token|refresh_token|oauth_token)(?:$|_)/i';
        try{$dfs=PSTE_Credentials::resolve();$gsc=PSTE_GSC_Credentials::client();$tok=PSTE_GSC_Credentials::tokenBundle();}catch(Throwable $e){throw new RuntimeException('PSTE_EXPORT_CREDENTIAL_SAFETY_CHECK_FAILED');}
        $secrets=array_values(array_filter([(string)($dfs['login']??''),(string)($dfs['password']??''),(string)($gsc['client_id']??''),(string)($gsc['client_secret']??''),(string)($tok['access_token']??''),(string)($tok['refresh_token']??'')],static fn($v)=>$v!==''));
        return static function(array $payload) use($badKey,$secrets): void {$walk=function($item)use(&$walk,$badKey):void{if(!is_array($item))return;foreach($item as $k=>$v){if(preg_match($badKey,(string)$k))throw new RuntimeException('PSTE_EXPORT_SENSITIVE_KEY_PRESENT');if(is_array($v))$walk($v);}};$walk($payload);$raw=wp_json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($raw))throw new RuntimeException('PSTE_EXPORT_CREDENTIAL_SCAN_JSON_FAILED');foreach($secrets as $secret)if(str_contains($raw,$secret))throw new RuntimeException('PSTE_EXPORT_SECRET_VALUE_PRESENT');};
    }

    private static function jsonDownload(array $payload,string $filename,bool $scrub=true): void {nocache_headers();header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="'.$filename.'"');$out=$scrub?PSTE_GSC_Credentials::scrub(PSTE_Credentials::scrub($payload)):$payload;echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);exit;}
    private static function notices(): void {
        foreach(['pste_migration_notice','pste_context_notice'] as $noticeKey){
            $notice=get_transient($noticeKey);
            if(!is_array($notice))continue;
            delete_transient($noticeKey);
            $type=(string)($notice['type']??'success');
            $class=$type==='error'?'notice-error':($type==='info'?'notice-info':'notice-success');
            echo '<div class="notice '.esc_attr($class).'"><p>'.esc_html((string)($notice['message']??'Vorgang abgeschlossen.')).'</p></div>';
        }
        $messages=['updated'=>'Einstellungen gespeichert.','credentials_saved'=>'DataForSEO-Zugang gespeichert.','connection_ok'=>'DataForSEO-Verbindung erfolgreich geprüft.','baseline_captured'=>'Gesamtbestand erfasst.','gsc_client_saved'=>'Google-OAuth-Zugang gespeichert.','gsc_connected'=>'Search Console verbunden.','gsc_test_ok'=>'Search-Console-Verbindung erfolgreich geprüft.','gsc_property_saved'=>'Search-Console-Property gespeichert.','gsc_synced'=>'Search-Console-Daten abgerufen.','gsc_disconnected'=>'Google-Verbindung getrennt.','weights_saved'=>'Strategische Gewichtung gespeichert.','gsc_imported'=>'CSV importiert.','editorial_plan_imported'=>'Redaktionsplan-Snapshot read-only importiert.','editorial_ownership_imported'=>'Intent-/Kategorie-Owner-Handoff read-only importiert.','research_complete'=>'Longtail-Recherche, Titelbildung, Kategoriezuordnung und portalinterne Prüfung vollständig abgeschlossen.','review_saved'=>'Themenentscheidung gespeichert.','title_override_saved'=>'Titelkorrektur gespeichert. Kategorie, Artikeltyp und Zuordnung wurden nicht verändert.','context_batch_processed'=>'Portalabgleich-Batch erfolgreich verarbeitet.','context_complete'=>'Portalabgleich vollständig abgeschlossen.','safe_migration_ok'=>'Sichere Migration vollständig abgeschlossen.','price_intent_repaired'=>'Preis-Longtails wurden im internen Themenpool sicher neu zugeordnet.','price_intent_partial'=>'Preis-Longtail-Korrektur abgeschlossen: eindeutige Fälle wurden übernommen, unklare Einzelfälle blieben unverändert und sind auf der Übersicht protokolliert.','sandbox_relevance_reviewed'=>'Explizite Relevanzentscheidung wurde ausschließlich im Sandbox-Register gespeichert.','sandbox_internal_confirmed'=>'Interne Zuordnung wurde ausschließlich für den späteren normalen Reentry vorgemerkt. Kein Produktions-Handoff wurde erzeugt.','sandbox_complete'=>'Sandbox-Prüfung abgeschlossen. Kein Apply und keine Produktionsübergabe wurde ausgeführt.','candidate_type_saved'=>'Beitragsart-Korrektur wurde als Review-Hinweis gespeichert. Für eine echte Umordnung bitte die normale Entscheidung mit Zielkategorie verwenden.','existing_evidence_reentry_imported'=>'Geprüfte Bestandsentscheidungen wurden gebunden. Keine externe Recherche und keine Freigabe wurde ausgeführt.'];
        foreach($messages as $key=>$text)if(isset($_GET[$key])){$class=$key==='price_intent_partial'?'notice-warning':'notice-success';echo '<div class="notice '.esc_attr($class).'"><p>'.esc_html($text).'</p></div>';}
        $err=get_transient('pste_last_error');
        if(is_array($err)){
            delete_transient('pste_last_error');
            $details=is_array($err['details']??null)?$err['details']:[];
            echo '<div class="notice notice-error"><p><strong>BLOCKED:</strong> <code>'.esc_html((string)($err['error']??'UNBEKANNT')).'</code>';
            if($details){
                $message=trim((string)($details['provider_message']??''));
                if($message!=='')echo '<br><strong>Provider:</strong> '.esc_html($message);
                $technical=$details;unset($technical['provider_message']);
                if($technical)echo '<br><strong>Technische Details:</strong> <code>'.esc_html(wp_json_encode($technical,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'</code>';
            }
            echo '</p></div>';
        }
    }
    private static function styles(): void {echo '<style>
.pste-wrap .nav-tab-wrapper{margin-bottom:18px}.pste-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin:16px 0}.pste-card,.pste-metric,.pste-box,.pste-connection{background:#fff;border:1px solid #dcdcde;padding:16px}.pste-card h3,.pste-connection h3{margin-top:0}.pste-card-value{font-size:18px;font-weight:700}.pste-metric{text-align:center}.pste-metric strong{display:block;font-size:28px}.pste-metric span{display:block}.pste-two{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:18px}.pste-run-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;align-items:end}.pste-run-grid input,.pste-run-grid select{width:100%;max-width:100%}.pste-table td{vertical-align:top}.pste-badge{display:inline-block;padding:3px 8px;border-radius:999px;background:#e2e3e5;font-weight:700;font-size:12px}.pste-connected,.pste-pass,.pste-auto_resolved,.pste-current,.pste-balanced,.pste-publish,.pste-approved{background:#d7f0dd;color:#145c2b}.pste-error,.pste-blocked,.pste-stale,.pste-overrepresented,.pste-rejected,.pste-blocked_for_category{background:#f8d7da;color:#8a1f28}.pste-configured_untested,.pste-configured-unconnected,.pste-review_required,.pste-underrepresented,.pste-draft,.pste-reassign,.pste-reassigned,.pste-provisional_accepted,.pste-provisional_reassign{background:#fff3cd;color:#6f5100}.pste-discovery_only{background:#d7f0dd;color:#145c2b}.pste-data_insufficient,.pste-not_configured,.pste-not-captured,.pste-not_run{background:#e2e3e5;color:#41464b}
.pste-traffic-grid{display:grid;grid-template-columns:repeat(3,minmax(180px,1fr));gap:14px;margin:14px 0}.pste-traffic-card{display:grid;grid-template-columns:22px 1fr;column-gap:9px;align-items:center;text-decoration:none;background:#fff;border:2px solid #dcdcde;border-radius:8px;padding:14px;color:#1d2327}.pste-traffic-card strong{font-size:18px}.pste-traffic-card small{grid-column:2;display:block;margin-top:3px}.pste-traffic-dot{display:inline-block;width:16px;height:16px;border-radius:50%;background:#8c8f94;box-shadow:0 0 0 3px rgba(140,143,148,.15)}.pste-traffic-card-green{border-color:#46b450}.pste-traffic-card-yellow{border-color:#dba617}.pste-traffic-card-red{border-color:#d63638}.pste-traffic-card-green .pste-traffic-dot,.pste-traffic-green .pste-traffic-dot{background:#46b450}.pste-traffic-card-yellow .pste-traffic-dot,.pste-traffic-yellow .pste-traffic-dot{background:#dba617}.pste-traffic-card-red .pste-traffic-dot,.pste-traffic-red .pste-traffic-dot{background:#d63638}.pste-traffic{display:grid;grid-template-columns:18px 1fr;column-gap:7px;align-items:center;min-width:145px}.pste-traffic strong{font-size:13px}.pste-traffic small{grid-column:2;display:block;margin-top:2px}.pste-row-yellow td:first-child{border-left:4px solid #dba617}.pste-row-red td:first-child{border-left:4px solid #d63638}.pste-row-green td:first-child{border-left:4px solid #46b450}@media(max-width:782px){.pste-traffic-grid{grid-template-columns:1fr}}
.pste-review-table th:nth-child(1){width:110px}.pste-light{display:inline-block;padding:4px 10px;border-radius:999px;font-weight:700}.pste-light-green{background:#d7f0dd;color:#145c2b}.pste-light-yellow{background:#fff3cd;color:#6f5100}.pste-light-red{background:#f8d7da;color:#8a1f28}.pste-hard-warning{padding:8px;background:#fff3cd;border-left:4px solid #dba617}.pste-review-table details{margin-top:8px}.pste-review-table td{min-width:100px}</style>';}

    /** Separate, explicit staging-only maintenance operation; never part of ordinary Automatik. */
    private static function renderCleanResetControl(): void {
        if(!PSTE_Clean_Reset::isTestSite())return;
        $job=PSTE_Clean_Reset::status();
        $label=(string)($job['phase']??'NOT_STARTED');
        echo '<details class="pste-box" style="margin:12px 0" id="pste-clean-reset-panel"><summary><strong>Kontrollierter Neustart der Themenbewertungen (nur Testseite)</strong></summary>';
        echo '<p>Die vorhandenen Keywords, Kategorien und Beiträge bleiben. Vor dem Zurücksetzen wird eine vollständige Sicherung der Themenentscheidungen erstellt. Gespeicherte menschliche Entscheidungen bleiben geschützt.</p>';
        echo '<p><strong>Neustart-Status:</strong> <span id="pste-clean-reset-state">'.esc_html($label).'</span></p>';
        echo '<p><button type="button" class="button button-secondary" id="pste-clean-reset-button">Neustart sichern und vorbereiten</button></p>';
        echo '<p id="pste-clean-reset-detail" role="status"></p>';
        echo '</details>';
        $cfg=wp_json_encode(['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('pste_clean_reset_ajax')],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        echo '<script>(function(){"use strict";const c='.$cfg.',b=document.getElementById("pste-clean-reset-button"),st=document.getElementById("pste-clean-reset-state"),d=document.getElementById("pste-clean-reset-detail");if(!b)return;let busy=false;async function request(mode){let r=await fetch(c.ajax_url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8"},body:new URLSearchParams({action:"pste_clean_reset",nonce:c.nonce,mode}).toString()});let j;try{j=await r.json();}catch(e){throw Error("PSTE_RESET_RESPONSE_NOT_JSON_HTTP_"+r.status);}if(!r.ok||!j.success)throw Error((j.data&&j.data.error_code)||"PSTE_RESET_HTTP_"+r.status);return j.data;}function show(x){st.textContent=String(x.phase||"");d.textContent="Gesichert "+Number(x.backed_up||0)+"/"+Number(x.total||0)+" · zurückgesetzt "+Number(x.reset_processed||0)+"/"+Number(x.total||0)+" · "+String(x.message||"");}async function run(mode){if(busy)return;busy=true;b.disabled=true;try{let x=await request(mode);show(x);let n=0;while(!["COMPLETE","BLOCKED"].includes(x.phase||"")){x=await request("step");show(x);if(++n%10===0)await new Promise(res=>setTimeout(res,150));}if(x.phase==="COMPLETE")d.textContent+=" · Fertig. Jetzt kann die vorhandene Automatik neu bewerten.";}catch(e){d.textContent="Gestoppt: "+e.message+". Stand bleibt erhalten. Erneut anklicken setzt fort.";}finally{busy=false;b.disabled=false;}}b.addEventListener("click",()=>{if(!confirm("NUR TESTSEITE: Erst alle Themenentscheidungen sichern, dann alte automatische Bewertungen zurücksetzen. Keywords, Kategorien und Artikel bleiben. Fortfahren?"))return;run("start");});})();</script>';
    }

    public static function cleanResetAjax(): void {
        try {
            PSTE_Auth::assertAdmin('pste_clean_reset_ajax',(string)($_POST['nonce']??''));
            if(!PSTE_Clean_Reset::isTestSite())throw new RuntimeException('PSTE_CLEAN_RESET_STAGING_ONLY');
            $mode=(string)($_POST['mode']??'');
            if($mode==='start')$result=PSTE_Clean_Reset::start();
            elseif($mode==='step')$result=PSTE_Clean_Reset::advance();
            else throw new RuntimeException('PSTE_CLEAN_RESET_INVALID_MODE');
            wp_send_json_success($result);
        } catch(Throwable $e) {
            wp_send_json_error(['error_code'=>preg_replace('/[^A-Z0-9_:-]/','_',substr($e->getMessage(),0,150))],400);
        }
    }

}
