<?php
if (!defined('ABSPATH')) { return; }

/**
 * Explicit, request-bounded storage compaction for already persisted PSTE data.
 * No records are deleted and no logical payload is changed. It only rewrites PSTE-owned
 * storage through the same lossless codecs used for future writes.
 */
final class PSTE_Storage_Maintenance {
    public const CONTRACT='PSTE_STORAGE_MAINTENANCE_JOB_V1';
    private const PHASES=['RUNS','CANDIDATES','PARKED_JOBS','SANDBOX_LOGICAL','SANDBOX_RECORDS','COMPLETE'];

    /** @return array<string,mixed> */
    public static function start(string $mode='COMPACT'): array {
        PSTE_Plugin::assertReady();self::assertIdleForMaintenance();$mode=strtoupper(trim($mode));if(!in_array($mode,['COMPACT','RESTORE_LEGACY'],true))throw new RuntimeException('PSTE_STORAGE_MAINTENANCE_MODE_INVALID');$token=self::acquireLock();
        try{
            $existing=self::current();
            if(is_array($existing)&&in_array((string)($existing['status']??''),['RUNNING','PAUSED_ERROR'],true))return self::publicState($existing);
            $uuid=function_exists('wp_generate_uuid4')?wp_generate_uuid4():substr(hash('sha256',microtime(true).'|'.mt_rand()),0,32);
            $job=[
                'contract'=>self::CONTRACT,'job_uuid'=>$uuid,'mode'=>$mode,'status'=>'RUNNING','phase'=>'RUNS',
                'run_cursor'=>0,'candidate_cursor'=>0,'park_cursor'=>0,'sandbox_logical_cursor'=>0,'sandbox_cursor'=>0,
                'processed'=>['runs'=>0,'candidates'=>0,'parked_jobs'=>0,'sandbox_logical'=>0,'sandbox_records'=>0],
                'changed'=>['runs'=>0,'candidates'=>0,'parked_jobs'=>0,'sandbox_logical'=>0,'sandbox_records'=>0],
                'saved_bytes'=>['runs'=>0,'candidates'=>0,'parked_jobs'=>0,'sandbox_logical'=>0,'sandbox_records'=>0],
                'last_error'=>'','started_at_utc'=>gmdate('c'),'updated_at_utc'=>gmdate('c'),'completed_at_utc'=>'',
            ];self::save($job);return self::publicState($job);
        }finally{self::releaseLock($token);}
    }

    /** @return array<string,mixed>|null */
    public static function current(): ?array {
        $raw=get_option(PSTE_OPTION_STORAGE_MAINTENANCE_JOB,null);if($raw===null||$raw===false||$raw==='')return null;
        if(!is_array($raw)||($raw['contract']??'')!==self::CONTRACT)throw new RuntimeException('PSTE_STORAGE_MAINTENANCE_JOB_INVALID');return $raw;
    }

    /** @return array<string,mixed> */
    public static function advance(string $jobUuid,bool $resume=false): array {
        PSTE_Plugin::assertReady();self::assertIdleForMaintenance();$token=self::acquireLock();
        try{
            $job=self::current();if(!is_array($job)||!hash_equals((string)($job['job_uuid']??''),trim($jobUuid)))throw new RuntimeException('PSTE_STORAGE_MAINTENANCE_JOB_ID_MISMATCH');
            if((string)($job['status']??'')==='COMPLETE')return self::publicState($job);
            if((string)($job['status']??'')==='PAUSED_ERROR'&&!$resume)return self::publicState($job);
            if((string)($job['status']??'')==='PAUSED_ERROR'){$job['status']='RUNNING';$job['last_error']='';}
            try{$job=self::advancePhase($job);}catch(Throwable $e){$job['status']='PAUSED_ERROR';$job['last_error']=self::code($e->getMessage());$job['updated_at_utc']=gmdate('c');self::save($job);throw $e;}
            $job['updated_at_utc']=gmdate('c');if((string)$job['phase']==='COMPLETE'){$job['status']='COMPLETE';$job['completed_at_utc']=gmdate('c');}$job['last_error']='';self::save($job);return self::publicState($job);
        }finally{self::releaseLock($token);}
    }

    /** @return array<string,mixed> */
    private static function advancePhase(array $job): array {
        $phase=(string)($job['phase']??'');$mode=(string)($job['mode']??'COMPACT');$restore=$mode==='RESTORE_LEGACY';
        if(!in_array($mode,['COMPACT','RESTORE_LEGACY'],true))throw new RuntimeException('PSTE_STORAGE_MAINTENANCE_MODE_INVALID');
        if($phase==='RUNS'){$r=$restore?PSTE_Repository::restoreRunStorageBatch((int)$job['run_cursor'],4):PSTE_Repository::compactRunStorageBatch((int)$job['run_cursor'],4);self::merge($job,'runs',$r);$job['run_cursor']=(int)$r['cursor'];if(!empty($r['complete']))$job['phase']='CANDIDATES';return $job;}
        if($phase==='CANDIDATES'){$r=$restore?PSTE_Repository::restoreCandidateStorageBatch((int)$job['candidate_cursor'],12):PSTE_Repository::compactCandidateStorageBatch((int)$job['candidate_cursor'],12);self::merge($job,'candidates',$r);$job['candidate_cursor']=(int)$r['cursor'];if(!empty($r['complete']))$job['phase']='PARKED_JOBS';return $job;}
        if($phase==='PARKED_JOBS'){$r=$restore?PSTE_Research_Archive::restoreLegacyStorageBatch((int)$job['park_cursor'],3):PSTE_Research_Archive::compactStorageBatch((int)$job['park_cursor'],3);self::merge($job,'parked_jobs',$r);$job['park_cursor']=(int)$r['cursor'];if(!empty($r['complete']))$job['phase']=$restore?'SANDBOX_RECORDS':'SANDBOX_LOGICAL';return $job;}
        if($phase==='SANDBOX_LOGICAL'){
            if($restore){$job['phase']='SANDBOX_RECORDS';return $job;}
            if(!PSTE_Sandbox_Record_Store::isComplete()){$job['sandbox_deferred_reason']='PSTE_SANDBOX_RECORD_STORE_MIGRATION_INCOMPLETE';$job['phase']='COMPLETE';return $job;}
            $r=PSTE_Semantic_Review_Sandbox::compactRecordStoreBatch((int)($job['sandbox_logical_cursor']??0),12);self::merge($job,'sandbox_logical',$r);$job['sandbox_logical_cursor']=(int)$r['cursor'];if(!empty($r['complete']))$job['phase']='SANDBOX_RECORDS';return $job;
        }
        if($phase==='SANDBOX_RECORDS'){
            if(!PSTE_Sandbox_Record_Store::isComplete()){$job['sandbox_deferred_reason']='PSTE_SANDBOX_RECORD_STORE_MIGRATION_INCOMPLETE';$job['phase']='COMPLETE';return $job;}
            $r=$restore?PSTE_Sandbox_Record_Store::restoreLegacyStorageBatch((int)$job['sandbox_cursor'],12):PSTE_Sandbox_Record_Store::compactStorageBatch((int)$job['sandbox_cursor'],12);self::merge($job,'sandbox_records',$r);$job['sandbox_cursor']=(int)$r['cursor'];if(!empty($r['complete']))$job['phase']='COMPLETE';return $job;
        }
        if($phase==='COMPLETE')return $job;
        throw new RuntimeException('PSTE_STORAGE_MAINTENANCE_PHASE_INVALID');
    }

    private static function merge(array &$job,string $bucket,array $r): void {
        $job['processed'][$bucket]=(int)($job['processed'][$bucket]??0)+(int)($r['processed']??0);
        $job['changed'][$bucket]=(int)($job['changed'][$bucket]??0)+(int)($r['changed']??0);
        $job['saved_bytes'][$bucket]=(int)($job['saved_bytes'][$bucket]??0)+(int)($r['saved_bytes']??0);
        $job['last_batch']=['bucket'=>$bucket,'processed'=>(int)($r['processed']??0),'changed'=>(int)($r['changed']??0),'saved_bytes'=>(int)($r['saved_bytes']??0),'complete'=>!empty($r['complete'])];
    }

    /** @return array<string,mixed> */
    public static function publicState(array $job): array {
        $saved=(array)($job['saved_bytes']??[]);return [
            'contract'=>self::CONTRACT,'job_uuid'=>(string)($job['job_uuid']??''),'mode'=>(string)($job['mode']??'COMPACT'),'status'=>(string)($job['status']??''),'phase'=>(string)($job['phase']??''),
            'processed'=>(array)($job['processed']??[]),'changed'=>(array)($job['changed']??[]),'saved_bytes'=>$saved,'saved_bytes_total'=>array_sum(array_map('intval',$saved)),
            'run_cursor'=>(int)($job['run_cursor']??0),'candidate_cursor'=>(int)($job['candidate_cursor']??0),'park_cursor'=>(int)($job['park_cursor']??0),'sandbox_logical_cursor'=>(int)($job['sandbox_logical_cursor']??0),'sandbox_cursor'=>(int)($job['sandbox_cursor']??0),
            'sandbox_deferred_reason'=>(string)($job['sandbox_deferred_reason']??''),'last_error'=>(string)($job['last_error']??''),'started_at_utc'=>(string)($job['started_at_utc']??''),'updated_at_utc'=>(string)($job['updated_at_utc']??''),'completed_at_utc'=>(string)($job['completed_at_utc']??''),
        ];
    }

    private static function save(array $job): void {update_option(PSTE_OPTION_STORAGE_MAINTENANCE_JOB,$job,false);$read=get_option(PSTE_OPTION_STORAGE_MAINTENANCE_JOB,null);if(!is_array($read)||!hash_equals((string)($job['job_uuid']??''),(string)($read['job_uuid']??''))||(string)($job['phase']??'')!==(string)($read['phase']??'')||(string)($job['mode']??'COMPACT')!==(string)($read['mode']??'COMPACT'))throw new RuntimeException('PSTE_STORAGE_MAINTENANCE_JOB_SAVE_FAILED');}
    private static function assertIdleForMaintenance(): void {
        $active=get_option(defined('PSTE_OPTION_ACTIVE_RESEARCH_JOB')?PSTE_OPTION_ACTIVE_RESEARCH_JOB:'pste_active_longtail_research_job_v2',null);
        if(is_array($active)&&!empty($active))throw new RuntimeException('PSTE_STORAGE_MAINTENANCE_ACTIVE_RESEARCH_BLOCKED');
        $breadth=get_option(defined('PSTE_OPTION_BREADTH_RESEARCH_QUEUE')?PSTE_OPTION_BREADTH_RESEARCH_QUEUE:'pste_breadth_research_queue_v1',null);
        if(is_array($breadth)&&in_array((string)($breadth['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_STORAGE_MAINTENANCE_BREADTH_RESEARCH_BLOCKED');
        $context=get_option(defined('PSTE_OPTION_CONTEXT_JOB')?PSTE_OPTION_CONTEXT_JOB:'pste_context_refresh_job_v1',null);
        if(is_array($context)&&(string)($context['status']??'')==='RUNNING')throw new RuntimeException('PSTE_STORAGE_MAINTENANCE_CONTEXT_REFRESH_BLOCKED');
        $migration=get_option(defined('PSTE_OPTION_SAFE_MIGRATION_JOB')?PSTE_OPTION_SAFE_MIGRATION_JOB:'pste_safe_migration_job_v2',null);
        if(is_array($migration)&&in_array((string)($migration['status']??''),['RUNNING','PAUSED_ERROR'],true))throw new RuntimeException('PSTE_STORAGE_MAINTENANCE_SAFE_MIGRATION_BLOCKED');
    }
    private static function acquireLock(): string {$token=function_exists('wp_generate_uuid4')?wp_generate_uuid4():substr(hash('sha256',microtime(true).'|'.mt_rand()),0,32);$now=time();$lock=['token'=>$token,'expires_at'=>$now+60];if(add_option(PSTE_OPTION_STORAGE_MAINTENANCE_LOCK,$lock,'','no'))return $token;$raw=get_option(PSTE_OPTION_STORAGE_MAINTENANCE_LOCK,[]);if(is_array($raw)&&(int)($raw['expires_at']??0)<$now){delete_option(PSTE_OPTION_STORAGE_MAINTENANCE_LOCK);if(add_option(PSTE_OPTION_STORAGE_MAINTENANCE_LOCK,$lock,'','no'))return $token;}throw new RuntimeException('PSTE_STORAGE_MAINTENANCE_BUSY');}
    private static function releaseLock(string $token): void {$raw=get_option(PSTE_OPTION_STORAGE_MAINTENANCE_LOCK,[]);if(is_array($raw)&&hash_equals($token,(string)($raw['token']??'')))delete_option(PSTE_OPTION_STORAGE_MAINTENANCE_LOCK);}
    private static function code(string $v): string {$v=strtoupper(trim($v));$v=(string)preg_replace('/[^A-Z0-9_:\-]/','_',$v);return substr($v!==''?$v:'PSTE_STORAGE_MAINTENANCE_FAILED',0,180);}
}

/** Admin-only controller/UI for explicit PSTE storage maintenance. */
final class PSTE_Storage_Admin {
    public static function init(): void {
        add_action('wp_ajax_pste_storage_maintenance_start',[self::class,'startAjax']);
        add_action('wp_ajax_pste_storage_maintenance_advance',[self::class,'advanceAjax']);
    }

    public static function renderBox(): void {
        $job=PSTE_Storage_Maintenance::current();$public=is_array($job)?PSTE_Storage_Maintenance::publicState($job):[];$status=(string)($public['status']??'NOT_STARTED');$mode=(string)($public['mode']??'COMPACT');$saved=(int)($public['saved_bytes_total']??0);$label=in_array($status,['RUNNING','PAUSED_ERROR'],true)?'Speicherpflege fortsetzen':($status==='COMPLETE'&&$mode==='COMPACT'?'Speicherpflege erneut prüfen':'Speicherpflege starten');
        echo '<section class="pste-box"><h2>Datenbankspeicher</h2><p>Speicherpflege für PSTE-eigene Run-Snapshots, Kandidaten, geparkte Recherchejobs und Sandbox-Einzelrecords. Zusätzlich werden redundante, aus dem Topic-Pool wiederherstellbare Sandbox-Diagnosekopien entfernt. Keywords, Themen, Artikel, Kategorien, Review-Entscheidungen und Reentry-Bindungen bleiben erhalten.</p>';
        echo '<p><button type="button" class="button button-primary" id="pste-storage-maintenance-start">'.esc_html($label).'</button> <button type="button" class="button" id="pste-storage-legacy-restore">Legacy-Speicher für Rückkehr zu 0.57.12 herstellen</button></p><p class="description">Der zweite Knopf ist nur vor einem Downgrade gedacht. Er stellt komprimierte PSTE-Daten vollständig in das alte lesbare Speicherformat zurück und prüft jeden Batch per Readback.</p><div id="pste-storage-maintenance-feedback" class="notice notice-info inline" style="display:none"><p></p></div>';
        $cfg=wp_json_encode(['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('pste_storage_maintenance_ajax'),'job'=>$public,'saved'=>$saved],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        echo '<script>(function(){"use strict";const cfg='.$cfg.',btn=document.getElementById("pste-storage-maintenance-start"),restoreBtn=document.getElementById("pste-storage-legacy-restore"),box=document.getElementById("pste-storage-maintenance-feedback");const sleep=ms=>new Promise(r=>setTimeout(r,ms));function setDisabled(v){if(btn)btn.disabled=v;if(restoreBtn)restoreBtn.disabled=v;}function msg(t,e){if(!box)return;box.style.display="block";box.className="notice "+(e?"notice-error":"notice-info")+" inline";box.querySelector("p").textContent=t;}function show(j){const mb=(Number(j.saved_bytes_total||0)/1048576).toFixed(1),prefix=j.mode==="RESTORE_LEGACY"?"Rollback-Vorbereitung":"Speicherpflege";msg(prefix+": "+j.status+" · "+j.phase+(j.mode==="COMPACT"?" · bisher verlustfrei eingespart ca. "+mb+" MB":""),false);}async function call(action,data){const body=new URLSearchParams(Object.assign({action:action,nonce:cfg.nonce},data||{})),res=await fetch(cfg.ajax_url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8","Accept":"application/json"},body:body.toString()}),raw=await res.text();let json;try{json=JSON.parse((raw||"").replace(/^\uFEFF/,"").trim());}catch(e){throw new Error("PSTE_STORAGE_AJAX_INVALID_JSON");}if(!res.ok||!json.success)throw new Error((json.data&&json.data.error_code)||("PSTE_STORAGE_AJAX_HTTP_"+res.status));return json.data;}async function loop(job,resume){let cur=job,first=!!resume;for(let guard=0;guard<5000;guard++){show(cur);if(cur.status==="COMPLETE"){setDisabled(false);return;}if(cur.status==="PAUSED_ERROR"&&!first){setDisabled(false);msg("Sicher angehalten: "+(cur.last_error||"PSTE_STORAGE_MAINTENANCE_PAUSED"),true);return;}await sleep(150);const d=await call("pste_storage_maintenance_advance",{job_uuid:cur.job_uuid,explicit_resume:first?"1":"0"});cur=d.job;first=false;}throw new Error("PSTE_STORAGE_MAINTENANCE_GUARD_EXCEEDED");}async function start(mode){setDisabled(true);try{let job=cfg.job;if(!job||!job.job_uuid||job.status==="COMPLETE"||job.mode!==mode){const d=await call("pste_storage_maintenance_start",{mode:mode});job=d.job;}await loop(job,job.status==="PAUSED_ERROR");}catch(e){setDisabled(false);msg(e.message||"PSTE_STORAGE_MAINTENANCE_FAILED",true);}}if(btn)btn.addEventListener("click",()=>start("COMPACT"));if(restoreBtn)restoreBtn.addEventListener("click",()=>start("RESTORE_LEGACY"));})();</script></section>';
    }

    public static function startAjax(): void {
        $level=self::boundaryBegin();
        try{PSTE_Auth::assertAdmin('pste_storage_maintenance_ajax',(string)($_POST['nonce']??''));$job=PSTE_Storage_Maintenance::start(sanitize_text_field((string)($_POST['mode']??'COMPACT')));}catch(Throwable $e){self::error($e,$level,400);return;}
        self::success(['job'=>$job],$level);
    }
    public static function advanceAjax(): void {
        $level=self::boundaryBegin();
        try{PSTE_Auth::assertAdmin('pste_storage_maintenance_ajax',(string)($_POST['nonce']??''));$job=PSTE_Storage_Maintenance::advance(sanitize_text_field((string)($_POST['job_uuid']??'')),!empty($_POST['explicit_resume']));}catch(Throwable $e){self::error($e,$level,400);return;}
        self::success(['job'=>$job],$level);
    }
    private static function boundaryBegin(): int {$level=ob_get_level();ob_start();return $level;}
    private static function boundaryClean(int $level): void {while(ob_get_level()>$level){@ob_end_clean();}}
    private static function success(array $data,int $level): void {self::boundaryClean($level);if(!headers_sent())header('X-PSTE-Ajax-Contract: PSTE_JSON_BOUNDARY_V1');wp_send_json_success($data);}
    private static function error(Throwable $e,int $level,int $status): void {self::boundaryClean($level);if(!headers_sent())header('X-PSTE-Ajax-Contract: PSTE_JSON_BOUNDARY_V1');wp_send_json_error(['error_code'=>self::safeErrorCode($e)],$status);}
    private static function safeErrorCode(Throwable $e): string {$code=strtoupper(trim((string)$e->getMessage()));$code=(string)preg_replace('/[^A-Z0-9_:\-]/','_',$code);return substr($code!==''?$code:'PSTE_STORAGE_MAINTENANCE_FAILED',0,180);}
}
