<?php
if (!defined('ABSPATH')) { return; }

final class PSTE_Runner {
    /** @return array<string,mixed> */
    public static function makeCandidate(string $query,array $context): array {
        $categoryName=(string)($context['category_name']??'');$familyName=trim((string)($context['topic_family_name']??PSTE_Normalizer::categoryFamilyName($categoryName)));$familyKey=trim((string)($context['topic_family_key']??PSTE_Normalizer::categoryFamilyKey($categoryName)));
        $tuple=PSTE_Normalizer::intentTuple($query,$categoryName,(string)($context['answer_promise']??$query));$type=(string)($context['article_type']??'');
        return [
            'candidate_id'=>hash('sha256',$familyKey.'|'.PSTE_Normalizer::exactTopicIdentityText($query).'|'.PSTE_Article_Type_Registry::canonicalType($type)),
            'target_category_id'=>(int)($context['category_id']??0),'target_category_slug'=>(string)($context['category_slug']??''),'target_category_name'=>$categoryName,
            'suggested_category_id'=>(int)($context['category_id']??0),'suggested_category_slug'=>(string)($context['category_slug']??''),'suggested_category_name'=>$categoryName,
            'topic_family_name'=>$familyName,'topic_family_key'=>$familyKey,'proposed_article_type'=>$type,'suggested_article_type'=>$type,'article_type_source'=>'PSTE_SEMANTIC_DOUBLE_STRAND_V2',
            'primary_longtail_query'=>$query,'canonical_query'=>$query,'raw_user_question'=>PSTE_Normalizer::isQuestion($query)?PSTE_Normalizer::canonicalQuestion($query):'',
            'discovery_only'=>false,'candidate_role'=>'ARTICLE_TOPIC','derived_from_candidate_id'=>'','intent_cluster_id'=>PSTE_Normalizer::clusterId($tuple),'intent_tuple'=>$tuple,
            'head_term_collision'=>PSTE_Normalizer::text($query)===PSTE_Normalizer::categoryHead($categoryName),'evidence'=>array_values((array)($context['evidence']??[])),
            'metrics'=>$context['metrics']??['search_volume'=>null,'monthly_searches'=>[],'trend'=>null,'search_intent'=>null,'intent_probability'=>null],
            'closest_existing_matches'=>[],'decision'=>'REVIEW_REQUIRED','reason_codes'=>[],'human_review_required'=>false,'research_context'=>(array)($context['research_context']??[]),
        ];
    }

    /** Local fixture helper using the current semantic/title path, no network and no writes. */
    public static function fixturePilot(array $rawCandidates,array $inventory,array $structure,array $baseline=[]): array {
        if(!$baseline)$baseline=['contract'=>'PSTE_SITE_BASELINE_V1','taxonomy_contract'=>'PSTE_PORTAL_TAXONOMY_SNAPSHOT_V3','leaf_categories'=>array_values(array_filter($structure,static fn($r)=>!empty($r['is_leaf']))),'status'=>'CURRENT'];
        $registry=PSTE_Article_Type_Registry::build($baseline);$out=[];
        foreach($rawCandidates as $raw){
            $familyKey=(string)($raw['topic_family_key']??'');$family=(string)($raw['topic_family_name']??'');$query=(string)($raw['query']??'');
            $normalization=PSTE_Editorial_Topic_Normalizer::normalize($query,$family);$sourceEvidence=['metrics'=>['search_intent'=>$raw['search_intent']??null,'intent_probability'=>$raw['intent_probability']??null],'evidence'=>(array)($raw['evidence']??[])];
            $intentAnalysis=PSTE_Intent_Profile::analyzeBeforeType($query,$normalization,$family,$sourceEvidence);
            $semantic=PSTE_Semantic_Classifier::classify($query,(string)($raw['search_intent']??''),$registry,$familyKey);if(empty($semantic['ok'])){$out[]=['query'=>$query,'decision'=>'BLOCKED','intent_analysis'=>$intentAnalysis,'semantic_consensus'=>$semantic];continue;}
            $intentProfile=PSTE_Intent_Profile::bindArticleType($intentAnalysis,$semantic,$registry,$familyKey);if(empty($intentProfile['ok'])){$out[]=['query'=>$query,'decision'=>'BLOCKED','intent_analysis'=>$intentAnalysis,'intent_profile'=>$intentProfile,'semantic_consensus'=>$semantic];continue;}
            $target=(array)$semantic['resolved_category'];$record=PSTE_Query_Record::make($query,$raw['search_volume']??null,[],['FIXTURE'],[],gmdate('c'));$title=PSTE_Title_Pipeline::build($record,$family,(string)$semantic['resolved_article_type'],$registry,[],$intentProfile);$candidate=self::makeCandidate((string)$record['language_corrected_query'],['category_id'=>$target['term_id'],'category_slug'=>$target['slug'],'category_name'=>$target['name'],'topic_family_name'=>$family,'topic_family_key'=>$familyKey,'article_type'=>$semantic['resolved_article_type'],'evidence'=>(array)($raw['evidence']??[['source'=>'FIXTURE']]),'metrics'=>$sourceEvidence['metrics']]);$candidate['intent_analysis']=$intentAnalysis;$candidate['intent_profile']=$intentProfile;$candidate['editorial_title']=$title['title'];$candidate['production_title']=$title['title'];$candidate['target_keyword']=(string)($title['target_keyword']??'');$candidate['target_keyword_contract']=(array)($title['target_keyword_contract']??[]);$candidate['editorialization']=['contract'=>PSTE_Editorializer::RULESET,'resolved'=>$title['ok'],'eligible'=>$title['ok'],'title'=>$title['title'],'article_type'=>$semantic['resolved_article_type'],'intent_first'=>true];$candidate['decision']=$title['ok']?'PASS':'BLOCKED';$candidate['reason_codes']=array_values(array_unique(array_merge((array)($title['deterministic']['reason_codes']??[]),(array)($title['language']['reason_codes']??[]))));if($title['ok'])$candidate=PSTE_Planning_Readiness_Gate::apply($candidate,$inventory,$structure);$out[]=$candidate;
        }
        return $out;
    }

    public static function createRunSkeleton(int $categoryId,string $seed,array $settings): array {
        $inventory=PSTE_Snapshot::inventory();$structure=PSTE_Snapshot::structure();$plan=PSTE_Snapshot::editorialPlan();$estimated=PSTE_Cost_Guard::estimateCategoryResearch(100);
        PSTE_Cost_Guard::assertWithin($estimated,(float)$settings['run_budget_usd'],(float)$settings['absolute_ceiling_usd']);$now=gmdate('Y-m-d H:i:s');
        return ['run_uuid'=>wp_generate_uuid4(),'status'=>'READY_FOR_LONGTAIL_RESEARCH','category_id'=>$categoryId,'seed'=>$seed,'estimated_cost'=>$estimated,'actual_cost'=>0.0,'snapshot'=>['inventory'=>$inventory,'structure'=>$structure,'editorial_plan'=>$plan],
            'payload'=>['location'=>$settings['location'],'language'=>$settings['language'],'environment'=>$settings['environment'],'workflow'=>'LONGTAIL_RESEARCH_TO_METADATA_V2','provider_calls'=>3,'google_live_serp_used'=>false,'textmachine_write_attempted'=>false],'created_at'=>$now,'updated_at'=>$now];
    }

    public static function captureSiteBaseline(): array {
        $baseline=PSTE_Snapshot::siteBaseline();update_option(PSTE_OPTION_SITE_BASELINE,$baseline,false);$stored=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($stored)||!hash_equals((string)$baseline['baseline_sha256'],(string)($stored['baseline_sha256']??'')))throw new RuntimeException('PSTE_SITE_BASELINE_READBACK_MISMATCH');
        if(($baseline['status']??'')!=='CURRENT')return $baseline;
        $registry=PSTE_Article_Type_Registry::build($baseline);update_option(PSTE_OPTION_EDITORIAL_RULESET,['contract'=>'PSTE_SEMANTIC_TITLE_CONTRACT_V2','article_type_registry_sha256'=>$registry['registry_sha256'],'captured_at_utc'=>gmdate('c'),'legacy_reclassification_executed'=>false],false);
        $context=PSTE_Context_Refresh::start($baseline,'BASELINE_CAPTURE');
        $baseline['article_type_registry_sha256']=$registry['registry_sha256'];$baseline['portal_context_sync']=$context;
        $baseline['sandbox_binding_refresh']=[
            'contract'=>'PSTE_SANDBOX_BINDING_REFRESH_V2_BATCHED',
            'status'=>(string)($context['sandbox_binding_status']??'PENDING'),
            'total'=>(int)($context['sandbox_total']??0),
            'processed'=>(int)($context['sandbox_processed']??0),
            'source_stale'=>(int)($context['sandbox_source_stale']??0),
            'execution'=>'EXISTING_PORTAL_CONTEXT_JOB_REQUEST_BOUNDED',
            'external_provider_calls'=>0,
            'production_handoff_attempted'=>false,
            'article_or_taxonomy_write_attempted'=>false,
        ];
        return $baseline;
    }

    /**
     * Production-only compact baseline preflight.
     *
     * A real structural change may be accepted here only when a previously COMPLETE context job
     * exists. In that case the immutable compact context index is rehydrated from current snapshots;
     * the 4k+ topic pool is NOT traversed here. The normal Existing-Only pass remains responsible
     * for bounded 40-row topic revalidation before PSERC can consume the result.
     *
     * @return array<string,mixed>
     */
    public static function productionAutomationBaselinePreflight(): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return ['status'=>'FULL_CONTEXT_REFRESH_REQUIRED','reason'=>'PSTE_SITE_BASELINE_REQUIRED','changed'=>false,'full_context_refresh_required'=>true,'provider_calls'=>0];
        $status=PSTE_Snapshot::baselineStatus($baseline);
        if((string)($status['status']??'')==='BLOCKED')throw new RuntimeException((string)($status['reason']??'PSTE_PRODUCTION_SITE_STRUCTURE_INVALID'));

        // Inventory/plan drift and already-proven equivalent/display-only structure drift use the
        // existing safe rebase path. A completed context job can rehydrate its compact index lazily.
        $rebase=PSTE_Snapshot::rebaseResearchBaselineIfSafe($baseline);
        if(!empty($rebase['ok'])){
            $bound=(array)$rebase['baseline'];$context=PSTE_Context_Refresh::status();$binding=[];
            if((string)($context['status']??'')==='COMPLETE')$binding=PSTE_Context_Index_Store::runtimeBinding($context,$bound);
            return ['status'=>!empty($rebase['changed'])?'SAFE_REBOUND':'CURRENT','mode'=>(string)($rebase['mode']??'EXACT'),'changed'=>!empty($rebase['changed']),'baseline'=>$bound,'context_binding'=>$binding,'full_context_refresh_required'=>false,'provider_calls'=>0,'topic_pool_rows_scanned'=>0];
        }
        $code=(string)($rebase['error_code']??'PSTE_SITE_BASELINE_STALE');
        if($code!=='PSTE_SITE_STRUCTURE_STALE')throw new RuntimeException($code);
        if(empty($status['structure_changed']))throw new RuntimeException($code);

        // KISS structural rebind: current WordPress structure must itself be valid, and an already
        // completed context job must exist so only its compact index is rebuilt. No provider and no
        // topic-pool scan occur here. If no COMPLETE context exists, the caller must use the bounded
        // full context-refresh fallback instead of pretending a compact proof exists.
        $context=PSTE_Context_Refresh::status();
        if((string)($context['status']??'')!=='COMPLETE')return ['status'=>'FULL_CONTEXT_REFRESH_REQUIRED','reason'=>'PSTE_PRODUCTION_COMPACT_CONTEXT_REBIND_UNAVAILABLE','changed'=>false,'full_context_refresh_required'=>true,'provider_calls'=>0];
        if(PSTE_Research_Job::peek()!==null)throw new RuntimeException('PSTE_PRODUCTION_OTHER_RESEARCH_ACTIVE');
        $fresh=PSTE_Snapshot::siteBaseline();
        if(($fresh['status']??'')!=='CURRENT')throw new RuntimeException((string)($fresh['taxonomy_validation']['reason_code']??'PSTE_PRODUCTION_FRESH_BASELINE_BLOCKED'));
        update_option(PSTE_OPTION_SITE_BASELINE,$fresh,false);
        $stored=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($stored)||!hash_equals((string)($fresh['baseline_sha256']??''),(string)($stored['baseline_sha256']??'')))throw new RuntimeException('PSTE_PRODUCTION_BASELINE_REBIND_READBACK_MISMATCH');
        $registry=PSTE_Article_Type_Registry::build($stored);
        update_option(PSTE_OPTION_EDITORIAL_RULESET,['contract'=>'PSTE_SEMANTIC_TITLE_CONTRACT_V2','article_type_registry_sha256'=>$registry['registry_sha256'],'captured_at_utc'=>gmdate('c'),'legacy_reclassification_executed'=>false],false);
        $binding=PSTE_Context_Index_Store::runtimeBinding($context,$stored);
        foreach(['baseline_sha256','inventory_sha256','structure_sha256','editorial_plan_sha256'] as $field){
            $want=(string)($stored[$field]??'');$got=(string)($binding[$field]??'');
            if($want===''||!hash_equals($want,$got))throw new RuntimeException('PSTE_PRODUCTION_COMPACT_CONTEXT_REBIND_MISMATCH_'.$field);
        }
        return ['status'=>'COMPACT_STRUCTURE_REBOUND','mode'=>'COMPACT_CURRENT_SNAPSHOTS_ONLY','changed'=>true,'baseline'=>$stored,'context_binding'=>$binding,'full_context_refresh_required'=>false,'provider_calls'=>0,'topic_pool_rows_scanned'=>0];
    }

    public static function aggregateRunStatus(array $decisions): string {$decisions=array_values(array_filter(array_map('strval',$decisions)));if(!$decisions)return 'ANALYZED_NO_ELIGIBLE_CANDIDATE';return in_array('PASS',$decisions,true)?'ANALYZED':'ANALYZED_NO_ELIGIBLE_CANDIDATE';}
    public static function connectionTest(string $environment): array {$client=new PSTE_DataForSEO_Client($environment);$locations=$client->request('GET','/v3/dataforseo_labs/locations_and_languages');$status=$client->request('GET','/v3/dataforseo_labs/status');$result=['status'=>'PASS','locations'=>PSTE_DataForSEO_Client::sanitizedSummary($locations),'labs_status'=>PSTE_DataForSEO_Client::sanitizedSummary($status),'credentials'=>PSTE_Credentials::status()];if($environment==='production'){$user=$client->request('GET','/v3/appendix/user_data');$result['account']=PSTE_DataForSEO_Client::extractAccountStatus($user);}return $result;}
    public static function runPilot(int $categoryId,string $seed,array $settings): array {throw new RuntimeException('PSTE_SYNCHRONOUS_RESEARCH_WORKFLOW_REMOVED');}

    /**
     * Request-bounded PREPARE init. Builds only the bounded discovery/alias plan and
     * persists no portal/topic output. Expensive per-candidate semantic work is done
     * by researchFinalizePrepareCandidateBatch() in later server requests.
     */
    public static function researchFinalizePrepareInit(array $job): array {
        if(($job['contract']??'')!==PSTE_Research_Job::CONTRACT)throw new RuntimeException('PSTE_RESEARCH_JOB_CONTRACT_INVALID');
        $siteBaseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($siteBaseline)||($siteBaseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        $baselineState=PSTE_Snapshot::baselineStatus($siteBaseline);if(empty($baselineState['current']))throw new RuntimeException('PSTE_SITE_BASELINE_STALE');
        $selected=(array)($job['selected_category']??[]);$researchContext=(array)($job['research_context']??[]);
        $effectiveSeed=(string)($researchContext['effective_seed']??$job['seed']??'');$family=(string)($selected['topic_family_name']??'');$familyKey=(string)($selected['topic_family_key']??'');
        if($effectiveSeed===''||$family===''||$familyKey==='')throw new RuntimeException('PSTE_RESEARCH_JOB_CONTEXT_INVALID');
        $sourceDefinitions=['KEYWORD_SUGGESTION'=>'dataforseo_labs/google/keyword_suggestions/live','RELATED_SEARCH'=>'dataforseo_labs/google/related_keywords/live','KEYWORD_IDEA'=>'dataforseo_labs/google/keyword_ideas/live'];
        $researchVersion=(string)($job['version']??'2.2.0');if(!in_array($researchVersion,['2.1.0','2.2.0'],true))$sourceDefinitions['PAA']='serp/google/organic/task_post+task_get/advanced';
        $exact=[];$captured=gmdate('c');
        foreach($sourceDefinitions as $source=>$path){
            $stored=(array)($job['sources'][$source]??[]);self::assertStoredSource($source,$stored);$sourceCaptured=(string)($stored['captured_at_utc']??'');
            if($sourceCaptured===''||strtotime($sourceCaptured)===false)throw new RuntimeException('PSTE_RESEARCH_SOURCE_CAPTURED_AT_INVALID_'.$source);
            foreach((array)$stored['items'] as $item){$raw=(string)($item['keyword']??'');if(trim($raw)==='')continue;self::appendExact($exact,$raw,$item['search_volume']??null,(array)($item['monthly_searches']??[]),$source,(string)$stored['response_sha256'],$sourceCaptured,null,(array)($item['observation']??[]));}
        }
        foreach(PSTE_First_Party_Import::matching($effectiveSeed,(string)($selected['name']??''),get_option(PSTE_OPTION_FIRST_PARTY,[])) as $item){
            $raw=(string)($item['query']??'');if(trim($raw)==='')continue;$hash=hash('sha256',self::json($item));
            $obs=['observation_id'=>'obs:'.substr(hash('sha256',(string)$job['job_uuid'].'|GSC|'.$raw.'|'.$hash),0,32),'source_class'=>'GSC','provider'=>'GOOGLE_SEARCH_CONSOLE','query_kind'=>'FIRST_PARTY_QUERY','root_query'=>$effectiveSeed,'parent_observation_id'=>'','depth'=>1,'raw_value'=>$raw,'locale'=>(string)$job['location'],'language'=>(string)$job['language'],'parameters'=>['read_only'=>true],'retrieved_at_utc'=>$captured,'raw_response_sha256'=>$hash,'measurement_status'=>'UNMEASURED','relation'=>'RELATED_ENTITY','relation_evidence'=>['portal_query_match'],'freshness_status'=>'CURRENT','valid_until'=>gmdate('c',(strtotime($captured)?:time())+90*86400)];
            self::appendExact($exact,$raw,null,[],'GSC',$hash,$captured,$item,$obs);
        }
        $groups=array_values(self::aliasGroups($exact));
        foreach($groups as &$group){$group['intent']=['search_intent'=>null,'intent_probability'=>null];$group['rank_score']=self::rankScore((array)$group['canonical_record'],(array)$group['aliases'],$group['first_party']??null);}unset($group);
        usort($groups,static function($a,$b){$score=(int)$b['rank_score']<=>(int)$a['rank_score'];return $score!==0?$score:strcmp((string)$a['canonical_key'],(string)$b['canonical_key']);});
        $filter=['contract'=>'PSTE_FAMILY_FILTER_DIAGNOSTICS_V2','provider_rows_before_exact_dedup'=>array_sum(array_map(static fn($x)=>count((array)($x['items']??[])),(array)($job['sources']??[]))),'exact_rows_after_dedup'=>count($exact),'alias_groups_before_family_gate'=>count($groups),'family_match'=>0,'family_review'=>0,'family_no_match'=>0,'rejection_reason_counts'=>[],'rejection_samples'=>[],'alias_groups_after_family_gate'=>count($groups),'family_gate_dropped_before_topic_pool'=>0,'family_gate_drop_reason_counts'=>[],'family_gate_drop_samples'=>[],'all_deduped_groups_persisted'=>false];
        return ['contract'=>'PSTE_RESEARCH_FINALIZE_PREPARE_INIT_V1','groups'=>$groups,'family_filter'=>$filter,'total'=>count($groups)];
    }

    /** Builds and stages at most $limit candidates. No topic-pool/global candidate is published here. */
    public static function researchFinalizePrepareCandidateBatch(array $job,int $offset,int $limit): array {
        $uuid=trim((string)($job['job_uuid']??''));if($uuid==='')throw new RuntimeException('PSTE_RESEARCH_FINALIZE_RUN_UUID_REQUIRED');$limit=max(1,min(5,$limit));$offset=max(0,$offset);
        $groups=array_values((array)($job['finalize_prepare_groups']??[]));$total=count($groups);if($offset>$total)throw new RuntimeException('PSTE_RESEARCH_FINALIZE_PREPARE_CURSOR_INVALID');
        $siteBaseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($siteBaseline)||($siteBaseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        $baselineState=PSTE_Snapshot::baselineStatus($siteBaseline);if(empty($baselineState['current']))throw new RuntimeException('PSTE_SITE_BASELINE_STALE');
        $registry=PSTE_Article_Type_Registry::build($siteBaseline);$selected=(array)($job['selected_category']??[]);$researchContext=(array)($job['research_context']??[]);
        $family=(string)($selected['topic_family_name']??'');$familyKey=(string)($selected['topic_family_key']??'');if($family===''||$familyKey==='')throw new RuntimeException('PSTE_RESEARCH_JOB_CONTEXT_INVALID');
        $sourceDefinitions=['KEYWORD_SUGGESTION'=>'dataforseo_labs/google/keyword_suggestions/live','RELATED_SEARCH'=>'dataforseo_labs/google/related_keywords/live','KEYWORD_IDEA'=>'dataforseo_labs/google/keyword_ideas/live'];$researchVersion=(string)($job['version']??'2.2.0');if(!in_array($researchVersion,['2.1.0','2.2.0'],true))$sourceDefinitions['PAA']='serp/google/organic/task_post+task_get/advanced';
        $snapshot=(array)($job['snapshot']??[]);$structure=(array)($snapshot['structure']['items']??[]);$inventory=array_merge((array)($snapshot['inventory']['items']??[]),PSTE_Repository::previousCandidateInventory($uuid,$familyKey,$family),self::planItemsAsInventory((array)($snapshot['editorial_plan']['items']??[]),$structure));
        $filter=(array)($job['finalize_prepare_family_filter']??[]);if(($filter['contract']??'')!=='PSTE_FAMILY_FILTER_DIAGNOSTICS_V2')throw new RuntimeException('PSTE_RESEARCH_FINALIZE_FAMILY_FILTER_MISSING');
        $ids=[];$processed=0;$end=min($total,$offset+$limit);
        for($i=$offset;$i<$end;$i++){
            $group=(array)$groups[$i];$record=(array)($group['canonical_record']??[]);$query=(string)($record['language_corrected_query']??'');
            $membership=PSTE_Family_Membership::evaluate(PSTE_Editorial_Topic_Normalizer::semanticProbe($query),$registry,$familyKey);$v2Status=(string)($membership['v2_status']??(!empty($membership['ok'])?'MATCH':'REVIEW'));
            if($v2Status==='MATCH')$filter['family_match']=(int)($filter['family_match']??0)+1;
            else{$bucket=$v2Status==='REVIEW'?'family_review':'family_no_match';$filter[$bucket]=(int)($filter[$bucket]??0)+1;foreach((array)($membership['reason_codes']??[]) as $reason)$filter['rejection_reason_counts'][(string)$reason]=(int)($filter['rejection_reason_counts'][(string)$reason]??0)+1;if(count((array)($filter['rejection_samples']??[]))<50)$filter['rejection_samples'][]=['query'=>$query,'status'=>$v2Status,'reason_codes'=>array_values((array)($membership['reason_codes']??[])),'diagnostics'=>(array)($membership['diagnostics']??[])];}
            $group['family_membership_v2']=$membership;$group['research_origin_family_status']=$v2Status;
            $groupSources=self::groupSourceClasses($group);
            $candidate=self::candidateFromGroup($group,$job,$siteBaseline,$registry,$family,$familyKey,$researchContext,$inventory,$structure,$sourceDefinitions);
            if(self::shouldDropWeakKeywordIdeaGroup($group,$v2Status,$candidate)){
                $filter['family_gate_dropped_before_topic_pool']=(int)($filter['family_gate_dropped_before_topic_pool']??0)+1;$filter['family_gate_drop_reason_counts']['PSTE_KEYWORD_IDEA_ORIGIN_FAMILY_NO_MATCH_NOT_USABLE']=(int)($filter['family_gate_drop_reason_counts']['PSTE_KEYWORD_IDEA_ORIGIN_FAMILY_NO_MATCH_NOT_USABLE']??0)+1;
                if(count((array)($filter['family_gate_drop_samples']??[]))<50)$filter['family_gate_drop_samples'][]=['query'=>$query,'sources'=>$groupSources,'origin_family'=>$family,'candidate_decision'=>(string)($candidate['decision']??''),'planning_suitability'=>(string)($candidate['planning_suitability']??''),'reason_code'=>'PSTE_KEYWORD_IDEA_ORIGIN_FAMILY_NO_MATCH_NOT_USABLE'];$processed++;continue;
            }
            PSTE_Repository::stageResearchFinalizeCandidate($uuid,$candidate);$ids[]=(string)$candidate['candidate_id'];$processed++;
        }
        PSTE_Snapshot::assertUnchanged((array)$snapshot['inventory'],PSTE_Snapshot::inventory());PSTE_Snapshot::assertUnchanged((array)$snapshot['structure'],PSTE_Snapshot::structure());PSTE_Snapshot::assertUnchanged((array)$snapshot['editorial_plan'],PSTE_Snapshot::editorialPlan());
        ksort($filter['rejection_reason_counts'],SORT_STRING);ksort($filter['family_gate_drop_reason_counts'],SORT_STRING);$filter['alias_groups_after_family_gate']=max(0,(int)($filter['alias_groups_before_family_gate']??$total)-(int)($filter['family_gate_dropped_before_topic_pool']??0));$next=$offset+$processed;$filter['all_deduped_groups_persisted']=$next>=$total;
        return ['contract'=>'PSTE_RESEARCH_FINALIZE_PREPARE_CANDIDATE_BATCH_V1','processed'=>$processed,'next_cursor'=>$next,'total'=>$total,'candidate_ids'=>$ids,'family_filter'=>$filter,'complete'=>$next>=$total];
    }

    /**
     * Global bounded-by-contract pass after candidate generation. The candidate universe is
     * hard bounded by provider/GSC limits; this pass preserves the exact historical duplicate,
     * title-diversity and work-queue semantics before any topic-pool commit.
     */
    public static function researchFinalizePrepareGlobal(array $job): array {
        $uuid=trim((string)($job['job_uuid']??''));if($uuid==='')throw new RuntimeException('PSTE_RESEARCH_FINALIZE_RUN_UUID_REQUIRED');
        $ids=array_values(array_unique(array_filter(array_map('strval',(array)($job['finalize_prepare_candidate_ids']??[])))));$storedCount=PSTE_Repository::researchFinalizeCandidateCount($uuid);if($storedCount!==count($ids))throw new RuntimeException('PSTE_RESEARCH_FINALIZE_STAGING_COUNT_MISMATCH');$candidates=[];
        foreach($ids as $id)$candidates[]=PSTE_Repository::researchFinalizeStagedCandidate($uuid,$id);
        self::applyInternalDuplicates($candidates);
        $snapshot=(array)($job['snapshot']??[]);PSTE_Snapshot::assertUnchanged((array)$snapshot['inventory'],PSTE_Snapshot::inventory());PSTE_Snapshot::assertUnchanged((array)$snapshot['structure'],PSTE_Snapshot::structure());PSTE_Snapshot::assertUnchanged((array)$snapshot['editorial_plan'],PSTE_Snapshot::editorialPlan());
        PSTE_Work_Queue::attachAll($candidates,$uuid);$decisions=array_column($candidates,'decision');$usable=count(array_filter($candidates,static fn($c)=>($c['decision']??'')==='PASS'));$now=gmdate('Y-m-d H:i:s');
        $researchVersion=(string)($job['version']??'2.2.0');$selected=(array)($job['selected_category']??[]);$researchContext=(array)($job['research_context']??[]);$siteBaseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$registry=PSTE_Article_Type_Registry::build((array)$siteBaseline);$familyFilter=(array)($job['finalize_prepare_family_filter']??[]);
        $run=['run_uuid'=>$uuid,'status'=>self::aggregateRunStatus($decisions),'category_id'=>(int)$job['category_id'],'seed'=>(string)$job['seed'],'estimated_cost'=>(float)$job['estimated_cost'],'actual_cost'=>(float)$job['actual_cost'],'snapshot'=>$snapshot,
            'payload'=>['location'=>(string)$job['location'],'language'=>(string)$job['language'],'environment'=>(string)$job['environment'],'workflow'=>'LONGTAIL_RESEARCH_TO_METADATA_V2','execution_mode'=>'ONE_CLICK_AUTOMATIC_BROWSER_SEQUENCE','provider_calls'=>(int)($job['total_provider_steps']??3),'provider_steps_completed'=>(int)($job['progress']??0),'questions_required'=>!in_array($researchVersion,['2.1.0','2.2.0'],true),'questions_state'=>(string)($job['questions_state']??(!in_array($researchVersion,['2.1.0','2.2.0'],true)?'LEGACY_VISIBLE_STEP':'NOT_REQUIRED')),'questions_transport'=>(string)($job['questions_transport']??''),'google_live_serp_used'=>false,'completed_automatically'=>true,'manual_followup_steps_required'=>0,
                'research_limits'=>['depth_limit'=>2,'branch_limit'=>20,'provider_item_limit'=>100,'candidate_limit'=>'NO_DROP_ALL_DEDUPED_GROUPS_PERSISTED','cycle_protection'=>'EXACT_AND_SEMANTIC_ALIAS_HASH_DEDUPLICATION','repeat_paid_measurement'=>'FORBIDDEN_WITHIN_JOB'],
                'research_context'=>$researchContext,'selected_category'=>$selected,'article_type_registry_sha256'=>$registry['registry_sha256'],'family_identity_v2_registry_sha256'=>(string)($registry['family_identity_v2_registry_sha256']??''),'family_filter_diagnostics'=>$familyFilter,'candidate_summary'=>array_count_values($decisions),'candidate_count'=>count($candidates),'usable_candidate_count'=>$usable,'textmachine_write_attempted'=>false],
            'created_at'=>self::mysqlDate((string)($job['run_created_at']??'')),'updated_at'=>$now];
        $run['payload']['research_finalize_state']='PREPARED';$run['payload']['research_finalize_result_status']=(string)$run['status'];$run['payload']['sandbox_admissions']=0;$run['payload']['structure_gap_backlog_admissions']=0;$run['payload']['internal_clarification_admissions']=0;$run['payload']['sandbox_candidate_failures_isolated']=0;$run['payload']['sandbox_candidate_failure_codes']=[];$run['payload']['raw_keyword_preservation']='ALL_DEDUPED_GROUPS_PERSISTED';
        PSTE_Repository::saveRun($run);$commitIds=[];foreach($candidates as $candidate){PSTE_Repository::stageResearchFinalizeCandidate($uuid,$candidate);$commitIds[]=(string)$candidate['candidate_id'];}
        return ['contract'=>'PSTE_RESEARCH_FINALIZE_PREPARE_GLOBAL_V1','run'=>$run,'candidate_count'=>count($candidates),'commit_ids'=>$commitIds];
    }

    public static function researchFinalizePrepareCommitBatch(array $job,int $offset,int $limit): array {
        $uuid=trim((string)($job['job_uuid']??''));if($uuid==='')throw new RuntimeException('PSTE_RESEARCH_FINALIZE_RUN_UUID_REQUIRED');$ids=array_values(array_filter(array_map('strval',(array)($job['finalize_prepare_commit_ids']??[]))));$offset=max(0,$offset);$limit=max(1,min(5,$limit));$end=min(count($ids),$offset+$limit);$processed=0;
        for($i=$offset;$i<$end;$i++){PSTE_Repository::commitResearchFinalizeCandidate($uuid,$ids[$i]);$processed++;}
        $next=$offset+$processed;return ['contract'=>'PSTE_RESEARCH_FINALIZE_PREPARE_COMMIT_BATCH_V1','processed'=>$processed,'next_cursor'=>$next,'total'=>count($ids),'complete'=>$next>=count($ids)];
    }

    /** Final local processing after three bounded keyword-source steps. No network, post, term or text-machine writes. */
    public static function prepareResearchFinalizeJob(array $job): array {
        if(($job['contract']??'')!==PSTE_Research_Job::CONTRACT)throw new RuntimeException('PSTE_RESEARCH_JOB_CONTRACT_INVALID');$siteBaseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($siteBaseline)||($siteBaseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');$baselineState=PSTE_Snapshot::baselineStatus($siteBaseline);if(empty($baselineState['current']))throw new RuntimeException('PSTE_SITE_BASELINE_STALE');
        $registry=PSTE_Article_Type_Registry::build($siteBaseline);$selected=(array)($job['selected_category']??[]);$researchContext=(array)($job['research_context']??[]);$effectiveSeed=(string)($researchContext['effective_seed']??$job['seed']??'');$family=(string)($selected['topic_family_name']??'');$familyKey=(string)($selected['topic_family_key']??'');if($effectiveSeed===''||$family===''||$familyKey==='')throw new RuntimeException('PSTE_RESEARCH_JOB_CONTEXT_INVALID');
        $sourceDefinitions=['KEYWORD_SUGGESTION'=>'dataforseo_labs/google/keyword_suggestions/live','RELATED_SEARCH'=>'dataforseo_labs/google/related_keywords/live','KEYWORD_IDEA'=>'dataforseo_labs/google/keyword_ideas/live'];$researchVersion=(string)($job['version']??'2.2.0');if(!in_array($researchVersion,['2.1.0','2.2.0'],true))$sourceDefinitions['PAA']='serp/google/organic/task_post+task_get/advanced';
        $exact=[];$captured=gmdate('c');
        foreach($sourceDefinitions as $source=>$path){$stored=(array)($job['sources'][$source]??[]);self::assertStoredSource($source,$stored);$sourceCaptured=(string)($stored['captured_at_utc']??'');if($sourceCaptured===''||strtotime($sourceCaptured)===false)throw new RuntimeException('PSTE_RESEARCH_SOURCE_CAPTURED_AT_INVALID_'.$source);foreach((array)$stored['items'] as $item){$raw=(string)($item['keyword']??'');if(trim($raw)==='')continue;self::appendExact($exact,$raw,$item['search_volume']??null,(array)($item['monthly_searches']??[]),$source,(string)$stored['response_sha256'],$sourceCaptured,null,(array)($item['observation']??[]));}}
        foreach(PSTE_First_Party_Import::matching($effectiveSeed,(string)($selected['name']??''),get_option(PSTE_OPTION_FIRST_PARTY,[])) as $item){$raw=(string)($item['query']??'');if(trim($raw)==='')continue;$hash=hash('sha256',self::json($item));$obs=['observation_id'=>'obs:'.substr(hash('sha256',(string)$job['job_uuid'].'|GSC|'.$raw.'|'.$hash),0,32),'source_class'=>'GSC','provider'=>'GOOGLE_SEARCH_CONSOLE','query_kind'=>'FIRST_PARTY_QUERY','root_query'=>$effectiveSeed,'parent_observation_id'=>'','depth'=>1,'raw_value'=>$raw,'locale'=>(string)$job['location'],'language'=>(string)$job['language'],'parameters'=>['read_only'=>true],'retrieved_at_utc'=>$captured,'raw_response_sha256'=>$hash,'measurement_status'=>'UNMEASURED','relation'=>'RELATED_ENTITY','relation_evidence'=>['portal_query_match'],'freshness_status'=>'CURRENT','valid_until'=>gmdate('c',(strtotime($captured)?:time())+90*86400)];self::appendExact($exact,$raw,null,[],'GSC',$hash,$captured,$item,$obs);}
        $groups=self::aliasGroups($exact);$ranked=[];$familyFilter=['contract'=>'PSTE_FAMILY_FILTER_DIAGNOSTICS_V2','provider_rows_before_exact_dedup'=>array_sum(array_map(static fn($s)=>count((array)($s['items']??[])),(array)($job['sources']??[]))),'exact_rows_after_dedup'=>count($exact),'alias_groups_before_family_gate'=>count($groups),'family_match'=>0,'family_review'=>0,'family_no_match'=>0,'rejection_reason_counts'=>[],'rejection_samples'=>[]];
        foreach($groups as $group){
            $record=$group['canonical_record'];$query=(string)$record['language_corrected_query'];$membership=PSTE_Family_Membership::evaluate(PSTE_Editorial_Topic_Normalizer::semanticProbe($query),$registry,$familyKey);$v2Status=(string)($membership['v2_status']??(!empty($membership['ok'])?'MATCH':'REVIEW'));
            if($v2Status==='MATCH')$familyFilter['family_match']++;
            else{
                $bucket=$v2Status==='REVIEW'?'family_review':'family_no_match';$familyFilter[$bucket]++;
                foreach((array)($membership['reason_codes']??[]) as $reason)$familyFilter['rejection_reason_counts'][(string)$reason]=($familyFilter['rejection_reason_counts'][(string)$reason]??0)+1;
                if(count($familyFilter['rejection_samples'])<50)$familyFilter['rejection_samples'][]=['query'=>$query,'status'=>$v2Status,'reason_codes'=>array_values((array)($membership['reason_codes']??[])),'diagnostics'=>(array)($membership['diagnostics']??[])];
            }
            // Hard preservation rule: REVIEW/NO_MATCH is retained and routed, never dropped.
            $group['family_membership_v2']=$membership;$group['research_origin_family_status']=$v2Status;$group['intent']=['search_intent'=>null,'intent_probability'=>null];$group['rank_score']=self::rankScore($record,(array)$group['aliases'],$group['first_party']??null);$ranked[]=$group;
        }
        ksort($familyFilter['rejection_reason_counts'],SORT_STRING);$familyFilter['alias_groups_after_family_gate']=count($ranked);$familyFilter['all_deduped_groups_persisted']=true;
        usort($ranked,static function($a,$b){$score=(int)$b['rank_score']<=>(int)$a['rank_score'];return $score!==0?$score:strcmp((string)$a['canonical_key'],(string)$b['canonical_key']);});
        $snapshot=(array)($job['snapshot']??[]);$structure=(array)($snapshot['structure']['items']??[]);$inventory=array_merge((array)($snapshot['inventory']['items']??[]),PSTE_Repository::previousCandidateInventory((string)$job['job_uuid'],$familyKey,$family),self::planItemsAsInventory((array)($snapshot['editorial_plan']['items']??[]),$structure));$candidates=[];
        foreach($ranked as $group)$candidates[]=self::candidateFromGroup($group,$job,$siteBaseline,$registry,$family,$familyKey,$researchContext,$inventory,$structure,$sourceDefinitions);
        self::applyInternalDuplicates($candidates);
        // The candidates table has always had UNIQUE(run_uuid,candidate_id) and saveCandidate()
        // uses REPLACE. Distinct discovery groups can intentionally converge on the same
        // technical candidate_id (for example statement/question punctuation variants).
        // Mirror that long-standing last-write-wins persistence semantics *before* declaring
        // candidate_count, so the bounded FINALIZE operates on the exact rows that can exist
        // in storage instead of failing on a count that the schema cannot represent.
        $candidates=self::persistenceCandidateSet($candidates);
        // Rootfix 0.56.14: title diversity is a batch property, not an item-local word blacklist.
        // Harmonize only production-eligible Beratung metadata before persistence. All non-title
        // bindings and all content/design systems stay outside this operation.
        
        PSTE_Snapshot::assertUnchanged((array)$snapshot['inventory'],PSTE_Snapshot::inventory());PSTE_Snapshot::assertUnchanged((array)$snapshot['structure'],PSTE_Snapshot::structure());PSTE_Snapshot::assertUnchanged((array)$snapshot['editorial_plan'],PSTE_Snapshot::editorialPlan());
        PSTE_Work_Queue::attachAll($candidates,(string)$job['job_uuid']);
        $decisions=array_column($candidates,'decision');$usable=count(array_filter($candidates,static fn($c)=>($c['decision']??'')==='PASS'));$now=gmdate('Y-m-d H:i:s');
        $run=['run_uuid'=>(string)$job['job_uuid'],'status'=>self::aggregateRunStatus($decisions),'category_id'=>(int)$job['category_id'],'seed'=>(string)$job['seed'],'estimated_cost'=>(float)$job['estimated_cost'],'actual_cost'=>(float)$job['actual_cost'],'snapshot'=>$snapshot,
            'payload'=>['location'=>(string)$job['location'],'language'=>(string)$job['language'],'environment'=>(string)$job['environment'],'workflow'=>'LONGTAIL_RESEARCH_TO_METADATA_V2','execution_mode'=>'ONE_CLICK_AUTOMATIC_BROWSER_SEQUENCE','provider_calls'=>(int)($job['total_provider_steps']??3),'provider_steps_completed'=>(int)($job['progress']??0),'questions_required'=>!in_array($researchVersion,['2.1.0','2.2.0'],true),'questions_state'=>(string)($job['questions_state']??(!in_array($researchVersion,['2.1.0','2.2.0'],true)?'LEGACY_VISIBLE_STEP':'NOT_REQUIRED')),'questions_transport'=>(string)($job['questions_transport']??''),'google_live_serp_used'=>false,'completed_automatically'=>true,'manual_followup_steps_required'=>0,
                'research_limits'=>['depth_limit'=>2,'branch_limit'=>20,'provider_item_limit'=>100,'candidate_limit'=>'NO_DROP_ALL_DEDUPED_GROUPS_PERSISTED','cycle_protection'=>'EXACT_AND_SEMANTIC_ALIAS_HASH_DEDUPLICATION','repeat_paid_measurement'=>'FORBIDDEN_WITHIN_JOB'],
                'research_context'=>$researchContext,'selected_category'=>$selected,'article_type_registry_sha256'=>$registry['registry_sha256'],'family_identity_v2_registry_sha256'=>(string)($registry['family_identity_v2_registry_sha256']??''),'family_filter_diagnostics'=>$familyFilter,'candidate_summary'=>array_count_values($decisions),'candidate_count'=>count($candidates),'usable_candidate_count'=>$usable,'textmachine_write_attempted'=>false],
            'created_at'=>self::mysqlDate((string)($job['run_created_at']??'')),'updated_at'=>$now];
        $run['payload']['research_finalize_state']='PREPARED';$run['payload']['research_finalize_result_status']=(string)$run['status'];$run['payload']['sandbox_admissions']=0;$run['payload']['structure_gap_backlog_admissions']=0;$run['payload']['internal_clarification_admissions']=0;$run['payload']['sandbox_candidate_failures_isolated']=0;$run['payload']['sandbox_candidate_failure_codes']=[];$run['payload']['raw_keyword_preservation']='ALL_DEDUPED_GROUPS_PERSISTED';
        PSTE_Repository::saveRun($run);
        foreach($candidates as $candidate)PSTE_Repository::saveCandidate((string)$job['job_uuid'],$candidate);
        return $run;
    }

    /** @return array<string,mixed> */
    public static function researchFinalizeAdmissionBatch(array $job,int $offset,int $limit): array {
        $uuid=(string)($job['job_uuid']??'');if($uuid==='')throw new RuntimeException('PSTE_RESEARCH_FINALIZE_RUN_UUID_REQUIRED');$limit=max(1,min(10,$limit));
        $candidates=PSTE_Repository::researchFinalizeCandidateBatch($uuid,$offset,$limit);$items=[];
        foreach($candidates as $candidate){$poolKey=PSTE_Repository::globalTopicKeyForCandidate($candidate);$path=(array)($candidate['normal_metadata_path']??[]);$items[]=['pool_key'=>$poolKey,'normal_path'=>$path,'diagnostics'=>['reason_codes'=>(array)($candidate['reason_codes']??[]),'research_origin_family_key'=>(string)($candidate['research_origin_family_key']??''),'research_origin_family_name'=>(string)($candidate['research_origin_family_name']??''),'family_membership'=>(array)($candidate['family_membership_v2']??[])]];}
        PSTE_Sandbox_Record_Store::resetMetrics();$batch=PSTE_Semantic_Review_Sandbox::admitFromResearchFinalizeRecordLocalBatch($items,$uuid);$metrics=(array)($batch['record_store_metrics']??[]);
        if((int)($metrics['legacy_full_reads']??0)!==0||(int)($metrics['record_reads']??0)>$limit*4||(int)($metrics['record_writes']??0)>$limit)throw new RuntimeException('PSTE_RESEARCH_FINALIZE_SANDBOX_RECORD_LOCAL_BUDGET_VIOLATION');
        $sandboxAdmissions=0;$structureGapAdmissions=0;$internalClarificationAdmissions=0;$candidateFailures=0;$failureCodes=[];
        foreach((array)($batch['results']??[]) as $i=>$admission){$item=(array)($items[$i]??[]);$path=(array)($item['normal_path']??[]);$pathStatus=(string)($path['status']??'');$mode=(string)($path['sandbox_admission_mode']??'');if(!empty($admission['admitted']))$sandboxAdmissions++;if($pathStatus==='STRUCTURE_GAP'&&!empty($admission['admitted']))$structureGapAdmissions++;if($pathStatus==='SANDBOX_REQUIRED'&&$mode==='INTERNAL_CLARIFICATION'&&!empty($admission['admitted']))$internalClarificationAdmissions++;if(!empty($admission['isolated_candidate_failure'])){$candidateFailures++;$failureCodes[]=(string)($admission['error_code']??'PSTE_SANDBOX_CANDIDATE_FAILURE');}}
        return ['contract'=>'PSTE_RESEARCH_FINALIZE_SANDBOX_BATCH_V1','processed'=>count($candidates),'next_cursor'=>$offset+count($candidates),'sandbox_admissions'=>$sandboxAdmissions,'structure_gap_admissions'=>$structureGapAdmissions,'internal_clarification_admissions'=>$internalClarificationAdmissions,'candidate_failures'=>$candidateFailures,'candidate_failure_codes'=>array_values(array_unique(array_filter($failureCodes))),'record_store_metrics'=>$metrics];
    }

    /** @return array<string,mixed> */
    public static function researchFinalizeContextBatch(array $job,int $offset,int $limit): array {
        $uuid=(string)($job['job_uuid']??'');if($uuid==='')throw new RuntimeException('PSTE_RESEARCH_FINALIZE_RUN_UUID_REQUIRED');$limit=max(1,min(10,$limit));$candidates=PSTE_Repository::researchFinalizeCandidateBatch($uuid,$offset,$limit);$keys=[];
        foreach($candidates as $candidate)$keys[]=PSTE_Repository::globalTopicKeyForCandidate($candidate);
        $snapshot=(array)($job['snapshot']??[]);$baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        if($keys)PSTE_Repository::refreshPortalContextForKeys(array_values(array_unique($keys)),(array)($snapshot['inventory']??[]),(array)($snapshot['editorial_plan']??[]),(string)($baseline['structure_sha256']??''));
        return ['contract'=>'PSTE_RESEARCH_FINALIZE_CONTEXT_BATCH_V1','processed'=>count($candidates),'next_cursor'=>$offset+count($candidates)];
    }

    /** @return array<string,mixed> */
    public static function closeResearchCategory(array $job,array $counters): array {
        $version=(string)($job['version']??'');if($version!=='2.6.0')return ['contract'=>'PSTE_CATEGORY_CLOSE_V1','state'=>'LEGACY_NOT_APPLICABLE','coverage_state'=>'NOT_APPLICABLE','coverage_candidate_created'=>false];
        if((string)($job['questions_state']??'')!=='COMPLETE'||!is_array($job['sources']['PAA']['items']??null))throw new RuntimeException('PSTE_CATEGORY_CLOSE_QUESTIONS_NOT_COMPLETE');
        $uuid=(string)($job['job_uuid']??'');$decision=self::categoryExhaustionDecision($job,PSTE_Repository::candidatesForRun($uuid),$counters);if((string)$decision['state']!=='SEO_EXHAUSTED')return $decision;
        $coverage=self::createCoverageFallbackCandidate($job);$decision['coverage_state']=(string)$coverage['state'];$decision['coverage_candidate_created']=!empty($coverage['candidate_created']);$decision['coverage_candidate_id']=(string)($coverage['candidate_id']??'');$decision['coverage_reason']=(string)($coverage['reason']??'');return $decision;
    }

public static function categoryExhaustionDecision(array $job,array $candidates,array $counters=[]): array {
        if((string)($job['version']??'')!=='2.6.0')return ['contract'=>'PSTE_CATEGORY_CLOSE_V1','state'=>'LEGACY_NOT_APPLICABLE','coverage_state'=>'NOT_APPLICABLE','coverage_candidate_created'=>false];
        if((string)($job['questions_state']??'')!=='COMPLETE'||!is_array($job['sources']['PAA']['items']??null))return ['contract'=>'PSTE_CATEGORY_CLOSE_V1','state'=>'OPEN_REVIEW','reason'=>'QUESTIONS_NOT_COMPLETE','coverage_state'=>'BLOCKED','coverage_candidate_created'=>false];
        if((int)($counters['candidate_failures']??0)>0)return ['contract'=>'PSTE_CATEGORY_CLOSE_V1','state'=>'OPEN_REVIEW','reason'=>'CANDIDATE_FAILURES_PRESENT','coverage_state'=>'BLOCKED','coverage_candidate_created'=>false];
        $open=[];$usable=[];$resolved=[];
        foreach($candidates as $candidate){$role=(string)($candidate['topic_role']??PSTE_Topic_Policy::classifyRole($candidate));$planning=(string)($candidate['planning_suitability']??'BLOCKED');$context=(string)($candidate['context_state']??'PENDING');$status=(string)($candidate['pool_status']??$candidate['decision']??'REVIEW_REQUIRED');if(self::candidateProvablyCovered($candidate)){$resolved[]=['candidate_id'=>(string)($candidate['candidate_id']??''),'reason'=>'ALREADY_COVERED_PROVEN'];continue;}if(in_array($planning,[PSTE_Topic_Policy::PLAN_YES,PSTE_Topic_Policy::PLAN_PROVISIONAL],true)||(string)($candidate['decision']??'')==='PASS'){$usable[]=(string)($candidate['candidate_id']??'');continue;}$needsReview=!empty($candidate['sandbox_required'])||!empty($candidate['structure_gap_backlog_required'])||!in_array($context,['CURRENT','NOT_REQUIRED'],true)||in_array($status,['REVIEW_REQUIRED','PROVISIONAL_ACCEPTED','PROVISIONAL_REASSIGN','REASSIGN','REASSIGNED'],true)||!empty($candidate['human_review_required']);if($needsReview){$open[]=['candidate_id'=>(string)($candidate['candidate_id']??''),'status'=>$status,'context_state'=>$context,'role'=>$role];continue;}if(in_array($role,[PSTE_Topic_Policy::ROLE_NON_EDITORIAL,PSTE_Topic_Policy::ROLE_HEAD_TERM,PSTE_Topic_Policy::ROLE_STALE,PSTE_Topic_Policy::ROLE_KEYWORD_VARIANT,PSTE_Topic_Policy::ROLE_RESEARCH_KEYWORD,PSTE_Topic_Policy::ROLE_RESEARCH_CLUSTER],true)){$resolved[]=['candidate_id'=>(string)($candidate['candidate_id']??''),'reason'=>'NO_ELIGIBLE_SEO_SLOT'];continue;}$open[]=['candidate_id'=>(string)($candidate['candidate_id']??''),'status'=>$status,'context_state'=>$context,'role'=>$role];}
        if($usable)return ['contract'=>'PSTE_CATEGORY_CLOSE_V1','state'=>'SEO_HAS_CANDIDATE','usable_candidate_ids'=>$usable,'open_review_count'=>count($open),'coverage_state'=>'NOT_ALLOWED','coverage_candidate_created'=>false];if($open)return ['contract'=>'PSTE_CATEGORY_CLOSE_V1','state'=>'OPEN_REVIEW','open_review_count'=>count($open),'open_review'=>$open,'coverage_state'=>'BLOCKED','coverage_candidate_created'=>false];return ['contract'=>'PSTE_CATEGORY_CLOSE_V1','state'=>'SEO_EXHAUSTED','resolved_candidate_count'=>count($resolved),'open_review_count'=>0,'coverage_state'=>'ALLOWED','coverage_candidate_created'=>false];
    }

private static function candidateProvablyCovered(array $candidate): bool {
        $codes=array_values(array_unique(array_map('strval',(array)($candidate['reason_codes']??[]))));$coveredCodes=['PRE_TITLE_EXACT_DUPLICATE','PRE_TITLE_ANSWER_EQUIVALENT','EXACT_NORMALIZED_QUERY_DUPLICATE','SAME_INTENT_CLUSTER','CROSS_TYPE_ANSWER_EQUIVALENCE','CANONICAL_ARTICLE_OR_PLAN_SLOT_ALREADY_OWNED','ANSWER_EQUIVALENT_EXISTING','ANSWER_EQUIVALENT_PLANNED','EXACT_EDITORIAL_INTENT_VARIANT'];if(array_intersect($coveredCodes,$codes))return true;
        foreach(['planning_readiness_gate','pre_title_duplicate_gate'] as $field){$gate=(array)($candidate[$field]??[]);$reasons=array_values(array_map('strval',(array)($gate['reason_codes']??[])));if(!empty($gate)&&empty($gate['ok'])&&array_intersect($coveredCodes,$reasons))return true;}
        return false;
    }

private static function createCoverageFallbackCandidate(array $job): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');$registry=PSTE_Article_Type_Registry::build($baseline);$selected=(array)($job['selected_category']??[]);$familyKey=(string)($selected['topic_family_key']??'');$familyName=(string)($selected['topic_family_name']??'');if($familyKey===''||$familyName==='')throw new RuntimeException('PSTE_COVERAGE_FAMILY_MISSING');
        $snapshot=(array)($job['snapshot']??[]);$structure=(array)($snapshot['structure']['items']??[]);$inventory=(array)($snapshot['inventory']['items']??[]);$plan=(array)($snapshot['editorial_plan']['items']??[]);$occupied=[];foreach($inventory as $row){$id=(int)($row['category_id']??0);if($id>0)$occupied[$id]=true;}foreach($plan as $row){$id=(int)($row['category_id']??0);if($id>0)$occupied[$id]=true;}
        $missing=[];foreach(PSTE_Article_Type_Registry::availableTypes($registry,$familyKey) as $type){$target=PSTE_Article_Type_Registry::resolve($registry,$familyKey,$type);if(empty($target['ok']))continue;$id=(int)($target['term_id']??0);if($id>0&&empty($occupied[$id]))$missing[$type]=$target;}
        if(!$missing)return ['state'=>'NO_STRUCTURAL_COVERAGE_GAP','candidate_created'=>false,'reason'=>'ALL_FAMILY_ARTICLE_TYPES_ALREADY_HAVE_CONTENT_OR_PLAN'];
        $preferred=(string)($selected['selected_input_article_type']??'');$type=isset($missing[$preferred])?$preferred:(string)array_key_first($missing);$target=(array)$missing[$type];$query=trim((string)($target['name']??''));if($query==='')return ['state'=>'BLOCKED','candidate_created'=>false,'reason'=>'COVERAGE_TARGET_NAME_MISSING'];
        $candidate=self::makeCandidate($query,['category_id'=>0,'category_slug'=>'','category_name'=>'','topic_family_name'=>$familyName,'topic_family_key'=>$familyKey,'article_type'=>'','answer_promise'=>$query,'evidence'=>[['source'=>'COVERAGE_FALLBACK','source_reference'=>'SEO_EXHAUSTED_CATEGORY_STRUCTURE','captured_at_utc'=>gmdate('c'),'raw_value'=>$query]],'research_context'=>(array)($job['research_context']??[]),'metrics'=>['search_volume'=>null,'volume_status'=>'UNMEASURED','measured_query'=>'','monthly_searches'=>[],'trend'=>null,'search_intent'=>null,'intent_probability'=>null]]);
        $candidate['coverage_candidate']=true;$candidate['coverage_contract']='PSTE_SEO_EXHAUSTED_COVERAGE_CANDIDATE_V1';$candidate['coverage_target_article_type']=$type;$candidate['coverage_target_category_id']=(int)($target['term_id']??0);$candidate['research_origin_family_key']=$familyKey;$candidate['research_origin_family_name']=$familyName;$candidate['research_origin_category_id']=(int)($job['category_id']??0);$candidate['research_job_contract']=PSTE_Research_Job::CONTRACT;$candidate['research_run_status']='SEO_EXHAUSTED';$candidate['article_type_registry_sha256']=(string)$registry['registry_sha256'];
        $candidate=PSTE_Normal_Metadata_Path::applyToPayload($candidate,$baseline,$familyKey);$path=(array)($candidate['normal_metadata_path']??[]);if((string)($path['status']??'')!=='NORMAL_PASS')return ['state'=>'BLOCKED','candidate_created'=>false,'reason'=>'COVERAGE_NORMAL_PATH_NOT_PASS'];if((int)($candidate['target_category_id']??0)!==(int)($target['term_id']??0)||PSTE_Article_Type_Registry::canonicalType((string)($candidate['proposed_article_type']??''))!==PSTE_Article_Type_Registry::canonicalType($type))return ['state'=>'BLOCKED','candidate_created'=>false,'reason'=>'COVERAGE_TARGET_RECLASSIFIED'];
        $planInventory=array_merge($inventory,PSTE_Repository::previousCandidateInventory((string)$job['job_uuid'],(string)($candidate['topic_family_key']??''),(string)($candidate['topic_family_name']??'')),self::planItemsAsInventory($plan,$structure));$candidate=PSTE_Planning_Readiness_Gate::apply($candidate,$planInventory,$structure);if(trim((string)($candidate['plan_slot']??''))!==''||trim((string)($candidate['canonical_article_id']??''))!=='')throw new RuntimeException('PSTE_COVERAGE_MUST_NOT_ASSIGN_PLAN_SLOT');$candidate['coverage_passed_single_plan_gate']=true;$candidate['human_review_required']=(string)($candidate['decision']??'BLOCKED')!=='PASS';$candidate['discovery_only']=(string)($candidate['decision']??'BLOCKED')!=='PASS';
        $list=[$candidate];PSTE_Work_Queue::attachAll($list,(string)$job['job_uuid']);$candidate=$list[0];PSTE_Repository::saveCandidate((string)$job['job_uuid'],$candidate);$poolKey=PSTE_Repository::globalTopicKeyForCandidate($candidate);PSTE_Repository::refreshPortalContextForKeys([$poolKey],(array)($snapshot['inventory']??[]),(array)($snapshot['editorial_plan']??[]),(string)($baseline['structure_sha256']??''));
        $run=PSTE_Repository::runByUuid((string)$job['job_uuid']);if(is_array($run)){$summary=PSTE_Repository::researchRunDecisionSummary((string)$job['job_uuid']);$run['payload']['candidate_count']=(int)$summary['candidate_count'];$run['payload']['usable_candidate_count']=(int)$summary['usable_candidate_count'];$run['payload']['candidate_summary']=(array)$summary['candidate_summary'];$run['payload']['coverage_candidate_id']=(string)$candidate['candidate_id'];$run['payload']['coverage_candidate_plan_slot_assigned']=false;$run['payload']['coverage_candidate_single_plan_gate']=true;$run['updated_at']=gmdate('Y-m-d H:i:s');PSTE_Repository::saveRun($run);}
        return ['state'=>(string)($candidate['decision']??'BLOCKED')==='PASS'?'CANDIDATE_READY_FOR_COMPILER_GATE':'CANDIDATE_BLOCKED_BY_EXISTING_PLAN_GATE','candidate_created'=>true,'candidate_id'=>(string)$candidate['candidate_id'],'reason'=>(string)($candidate['reason_codes'][0]??'')];
    }

public static function completeResearchFinalizeJob(array $job,array $counters): array {
        $uuid=(string)($job['job_uuid']??'');
        $run=PSTE_Repository::runByUuid($uuid);
        if(!is_array($run))throw new RuntimeException('PSTE_RESEARCH_FINALIZE_RUN_MISSING');
        $summary=PSTE_Repository::researchRunDecisionSummary($uuid);
        $terminal=self::aggregateRunStatus(array_keys(array_filter((array)$summary['candidate_summary'],static fn($count)=>(int)$count>0)));
        $declared=(string)($run['payload']['research_finalize_result_status']??'');
        if($declared!==''&&!hash_equals($declared,$terminal))throw new RuntimeException('PSTE_RESEARCH_FINALIZE_TERMINAL_STATUS_MISMATCH');
        $preparedCount=(int)($run['payload']['candidate_count']??$summary['candidate_count']);
        if($preparedCount!==(int)$summary['candidate_count'])throw new RuntimeException('PSTE_RESEARCH_FINALIZE_TERMINAL_CANDIDATE_COUNT_MISMATCH');
        $run['status']=$terminal;
        $run['payload']['research_finalize_result_status']=$terminal;
        $run['payload']['candidate_count']=(int)$summary['candidate_count'];
        $run['payload']['usable_candidate_count']=(int)$summary['usable_candidate_count'];
        $run['payload']['candidate_summary']=(array)$summary['candidate_summary'];
        $run['payload']['sandbox_admissions']=(int)($counters['sandbox_admissions']??0);
        $run['payload']['structure_gap_backlog_admissions']=(int)($counters['structure_gap_admissions']??0);
        $run['payload']['internal_clarification_admissions']=(int)($counters['internal_clarification_admissions']??0);
        $run['payload']['sandbox_candidate_failures_isolated']=(int)($counters['candidate_failures']??0);
        $run['payload']['sandbox_candidate_failure_codes']=array_values(array_unique(array_filter(array_map('strval',(array)($counters['candidate_failure_codes']??[])))));
        $run['payload']['raw_keyword_preservation']='ALL_DEDUPED_GROUPS_PERSISTED';
        $run['payload']['category_close_state']=(string)($job['category_close_state']??'LEGACY_NOT_APPLICABLE');$run['payload']['coverage_state']=(string)($job['coverage_state']??'NOT_APPLICABLE');$run['payload']['coverage_candidate_id']=(string)($job['coverage_candidate_id']??($run['payload']['coverage_candidate_id']??''));$run['payload']['coverage_plan_slot_assigned']=false;
        $run['payload']['research_finalize_state']='COMPLETE';
        $run['payload']['research_finalize_terminal_readback']='PASS';
        $run['updated_at']=gmdate('Y-m-d H:i:s');
        PSTE_Repository::saveRun($run);
        $stored=PSTE_Repository::runByUuid($uuid);
        if(!is_array($stored)||!hash_equals($terminal,(string)($stored['status']??''))||(string)($stored['payload']['research_finalize_state']??'')!=='COMPLETE'||(int)($stored['payload']['candidate_count']??-1)!==(int)$summary['candidate_count']||(int)($stored['payload']['usable_candidate_count']??-1)!==(int)$summary['usable_candidate_count'])throw new RuntimeException('PSTE_RESEARCH_FINALIZE_TERMINAL_READBACK_MISMATCH');
        return $stored;
    }

    /**
     * Repairs the exact 0.56.6 terminal-readback regression: the active job is already gone,
     * research_finalize_state is COMPLETE, but the run row was last persisted as RUNNING.
     * No provider call, candidate mutation, topic decision change, post/term write or re-research.
     */
    public static function repairLatestCompletedResearchRunReadbackIfNeeded(): array {
        $run=PSTE_Repository::latestRun();
        if(!is_array($run))return ['status'=>'NO_RUN'];
        $payload=(array)($run['payload']??[]);
        if((string)($run['status']??'')!=='RUNNING'||(string)($payload['workflow']??'')!=='LONGTAIL_RESEARCH_TO_METADATA_V2'||(int)($payload['provider_steps_completed']??0)!==3||(string)($payload['research_finalize_state']??'')!=='COMPLETE')return ['status'=>'NO_REPAIR_REQUIRED','run_uuid'=>(string)($run['run_uuid']??'')];
        $uuid=(string)($run['run_uuid']??'');
        if($uuid==='')throw new RuntimeException('PSTE_RESEARCH_FINALIZE_REPAIR_RUN_UUID_MISSING');
        $summary=PSTE_Repository::researchRunDecisionSummary($uuid);
        $terminal=self::aggregateRunStatus(array_keys(array_filter((array)$summary['candidate_summary'],static fn($count)=>(int)$count>0)));
        $run['status']=$terminal;
        $run['payload']['research_finalize_result_status']=$terminal;
        $run['payload']['candidate_count']=(int)$summary['candidate_count'];
        $run['payload']['usable_candidate_count']=(int)$summary['usable_candidate_count'];
        $run['payload']['candidate_summary']=(array)$summary['candidate_summary'];
        $run['payload']['research_finalize_terminal_readback']='REPAIRED_0_56_6';
        $run['payload']['research_finalize_terminal_repair_provider_calls']=0;
        $run['payload']['research_finalize_terminal_repair_candidate_writes']=0;
        $run['payload']['research_finalize_terminal_repair_article_or_taxonomy_writes']=0;
        $run['updated_at']=gmdate('Y-m-d H:i:s');
        PSTE_Repository::saveRun($run);
        $stored=PSTE_Repository::runByUuid($uuid);
        if(!is_array($stored)||!hash_equals($terminal,(string)($stored['status']??''))||(string)($stored['payload']['research_finalize_state']??'')!=='COMPLETE'||(int)($stored['payload']['candidate_count']??-1)!==(int)$summary['candidate_count']||(int)($stored['payload']['usable_candidate_count']??-1)!==(int)$summary['usable_candidate_count'])throw new RuntimeException('PSTE_RESEARCH_FINALIZE_REPAIR_READBACK_MISMATCH');
        return ['status'=>'REPAIRED','run_uuid'=>$uuid,'terminal_status'=>$terminal,'candidate_count'=>(int)$summary['candidate_count'],'usable_candidate_count'=>(int)$summary['usable_candidate_count'],'provider_calls'=>0,'candidate_writes'=>0,'article_or_taxonomy_writes'=>0];
    }


    /** @return array<string,mixed> */
    private static function candidateFromGroup(array $group,array $job,array $baseline,array $registry,string $family,string $familyKey,array $researchContext,array $inventory,array $structure,array $sourceDefinitions): array {
        $record=(array)$group['canonical_record'];$query=(string)$record['language_corrected_query'];$intent=(array)$group['intent'];$evidence=[];
        foreach((array)$group['all_records'] as $aliasRecord){
            $observations=(array)($aliasRecord['observations']??[]);
            if($observations){foreach($observations as $obs){if(!is_array($obs))continue;$source=(string)($obs['source_class']??'');$evidence[]=['source'=>$source,'source_reference'=>$source==='GSC'?'Search Console read-only import':($sourceDefinitions[$source]??'DataForSEO Labs'),'observation_id'=>(string)($obs['observation_id']??''),'root_query'=>(string)($obs['root_query']??''),'parent_observation_id'=>(string)($obs['parent_observation_id']??''),'depth'=>(int)($obs['depth']??0),'query_kind'=>(string)($obs['query_kind']??''),'captured_at_utc'=>(string)($obs['retrieved_at_utc']??$aliasRecord['captured_at_utc']??''),'location'=>(string)($obs['locale']??$job['location']),'language'=>(string)($obs['language']??$job['language']),'raw_value'=>(string)($obs['raw_value']??$aliasRecord['raw_query']??''),'raw_response_sha256'=>(string)($obs['raw_response_sha256']??''),'freshness_status'=>(string)($obs['freshness_status']??'CURRENT')];}}
            else foreach((array)$aliasRecord['source_names'] as $source)$evidence[]=['source'=>$source,'source_reference'=>$source==='GSC'?'Search Console read-only import':($sourceDefinitions[$source]??'DataForSEO Labs'),'captured_at_utc'=>(string)$aliasRecord['captured_at_utc'],'location'=>(string)$job['location'],'language'=>(string)$job['language'],'raw_value'=>(string)$aliasRecord['raw_query'],'raw_response_sha256'=>(string)($aliasRecord['source_hashes'][$source]??'')];
        }
        $candidate=self::makeCandidate($query,['category_id'=>0,'category_slug'=>'','category_name'=>'','topic_family_name'=>$family,'topic_family_key'=>$familyKey,'article_type'=>'','answer_promise'=>$query,'evidence'=>$evidence,'research_context'=>$researchContext,'metrics'=>['search_volume'=>$record['search_volume'],'volume_status'=>$record['volume_status'],'measured_query'=>$record['measured_query'],'monthly_searches'=>$record['monthly_searches'],'trend'=>null,'search_intent'=>$intent['search_intent']??null,'intent_probability'=>$intent['intent_probability']??null]]);
        $candidate['query_record']=$record;$candidate['query_aliases']=array_values((array)$group['aliases']);$candidate['canonical_query']=$query;
        $candidate['research_origin_family_key']=$familyKey;$candidate['research_origin_family_name']=$family;$candidate['research_origin_category_id']=(int)$job['category_id'];$candidate['research_origin_family_status']=(string)($group['research_origin_family_status']??'');
        $candidate['family_membership_v2']=(array)($group['family_membership_v2']??[]);
        $candidate['article_type_registry_sha256']=(string)$registry['registry_sha256'];$candidate['research_job_contract']=PSTE_Research_Job::CONTRACT;$candidate['research_run_status']='COMPLETE';$candidate['research_rank_score']=(int)$group['rank_score'];
        $candidate['freshness']=is_array($record['freshness']??null)?$record['freshness']:['status'=>'CURRENT','retrieved_at'=>(string)$record['captured_at_utc'],'revalidation_class'=>'REGULARLY_CHANGING','valid_until'=>gmdate('c',(strtotime((string)$record['captured_at_utc'])?:time())+90*86400)];
        $candidate=PSTE_Normal_Metadata_Path::applyToPayload($candidate,$baseline,$familyKey);
        $path=(array)($candidate['normal_metadata_path']??[]);$pathStatus=(string)($path['status']??'REVIEW_REQUIRED');$resolvedFamilyKey=(string)($path['family_key']??'');
        $reasons=(array)($candidate['reason_codes']??[]);$decision=$pathStatus==='NORMAL_PASS'?'PASS':'BLOCKED';
        $candidate['pre_title_duplicate_gate']=['contract'=>PSTE_Planning_Readiness_Gate::PRE_TITLE_CONTRACT,'ok'=>false,'reason_codes'=>['PSTE_PLANNING_READINESS_NOT_RUN'],'matches'=>[],'title_surface_longtail_authority'=>false,'write_attempted'=>false];
        $semantic=(array)($candidate['semantic_consensus']??[]);$candidate['type_fit_evidence']=PSTE_Type_Fit_Probe::evaluate($semantic,(array)$group['all_records'],$registry);
        if(($candidate['type_fit_evidence']['status']??'')==='TYPE_EVIDENCE_CONFLICT_REVIEW'){$decision='BLOCKED';$reasons=array_merge($reasons,(array)$candidate['type_fit_evidence']['reason_codes']);}
        if(!empty($group['measurement_inconsistent'])){$decision='BLOCKED';$reasons[]='API_DATA_INCONSISTENT';}
        if($decision==='PASS'&&$resolvedFamilyKey!==''){
            $candidate['decision']='PASS';$candidate['reason_codes']=array_values(array_unique($reasons));
            $candidate=PSTE_Planning_Readiness_Gate::apply($candidate,$inventory,$structure);
            $decision=(string)($candidate['decision']??'BLOCKED');$reasons=(array)($candidate['reason_codes']??[]);
        }
        if($pathStatus==='STRUCTURE_GAP'&&$resolvedFamilyKey!==''){$candidate['category_gap_proposal']=PSTE_Category_Gap::proposal((string)$path['family_name'],$resolvedFamilyKey,(string)$path['article_type'],$semantic,$evidence,(string)($baseline['structure_sha256']??''),$registry);}
        $candidate['decision']=$decision;$candidate['reason_codes']=array_values(array_unique(array_filter(array_map('strval',$reasons))));$candidate['human_review_required']=$decision!=='PASS';$candidate['discovery_only']=$decision!=='PASS';if($decision!=='PASS')$candidate['candidate_role']='DISCOVERY_PROBE';
        $candidate['sandbox_required']=$pathStatus==='SANDBOX_REQUIRED';$candidate['structure_gap_backlog_required']=$pathStatus==='STRUCTURE_GAP';$candidate['sandbox_admission_mode']=(string)($path['sandbox_admission_mode']??'');
        return $candidate;
    }

    private static function assertStoredSource(string $source,array $stored): void {$hash=(string)($stored['response_sha256']??'');if(!is_array($stored['items']??null)||!preg_match('/^[a-f0-9]{64}$/',$hash))throw new RuntimeException('PSTE_RESEARCH_SOURCE_INVALID_'.$source);}
    /** @param array<string,mixed> $exact */
    private static function appendExact(array &$exact,string $raw,$volume,array $monthly,string $source,string $hash,string $captured,?array $firstParty,array $observation=[]): void {
        if(PSTE_Normalizer::exactTopicIdentityText($raw)==='')return;
        // The raw byte string is the first identity boundary. Case, punctuation and
        // spelling variants must survive separately until alias clustering.
        $key=hash('sha256',$raw);$volume=is_numeric($volume)?(int)$volume:null;
        if(!isset($exact[$key]))$exact[$key]=['raw'=>$raw,'volumes'=>[],'monthly'=>[],'sources'=>[],'hashes'=>[],'first_party'=>null,'observations'=>[]];
        $exact[$key]['sources'][$source]=true;$exact[$key]['hashes'][$source]=$hash;
        if($volume!==null)$exact[$key]['volumes'][$source]=$volume;if($monthly)$exact[$key]['monthly']=$monthly;
        if($firstParty)$exact[$key]['first_party']=$firstParty;if($observation)$exact[$key]['observations'][]=$observation;$previous=(string)($exact[$key]['captured']??'');if($previous===''||(strtotime($captured)?:0)>(strtotime($previous)?:0))$exact[$key]['captured']=$captured;
    }
    /** @return array<string,mixed> */
    private static function aliasGroups(array $exact): array {
        $groups=[];
        foreach($exact as $row){
            $values=array_values(array_unique(array_map('intval',(array)$row['volumes'])));
            $inconsistent=count($values)>1;$volume=$inconsistent?null:($values[0]??null);
            $record=PSTE_Query_Record::make((string)$row['raw'],$volume,(array)$row['monthly'],array_keys((array)$row['sources']),(array)$row['hashes'],(string)$row['captured'],(array)($row['observations']??[]));
            if($inconsistent){$record['volume_status']='UNAVAILABLE';$record['measured_query']='';$record['search_volume']=null;}
            $aliasKey=PSTE_Query_Record::aliasKey($record);if($aliasKey==='')continue;
            $groups[$aliasKey]['canonical_key']=$aliasKey;$groups[$aliasKey]['all_records'][]=$record;
            $groups[$aliasKey]['measurement_inconsistent']=!empty($groups[$aliasKey]['measurement_inconsistent'])||$inconsistent;
            if($row['first_party'])$groups[$aliasKey]['first_party']=$row['first_party'];
        }
        foreach($groups as &$group){
            usort($group['all_records'],static function($a,$b){
                $ac=(int)((string)$a['raw_query']===(string)$a['language_corrected_query']);$bc=(int)((string)$b['raw_query']===(string)$b['language_corrected_query']);
                return [$bc,count((array)$b['source_names']),(int)($b['search_volume']??-1)]<=>[$ac,count((array)$a['source_names']),(int)($a['search_volume']??-1)];
            });
            $group['canonical_record']=$group['all_records'][0];$canonicalExact=PSTE_Query_Record::canonicalKey($group['canonical_record']);
            $group['aliases']=[];
            foreach($group['all_records'] as $r){
                $relation=(string)$r['relation_to_canonical'];
                if(PSTE_Query_Record::canonicalKey($r)!==$canonicalExact)$relation='SYNONYM';
                $group['aliases'][]=['raw_query'=>$r['raw_query'],'normalized_query'=>$r['normalized_query'],'language_corrected_query'=>$r['language_corrected_query'],'relation_to_canonical'=>$relation,'source_names'=>$r['source_names'],'volume_status'=>$r['volume_status'],'search_volume'=>$r['search_volume'],'observation_ids'=>array_values(array_filter(array_map(static fn($o)=>is_array($o)?(string)($o['observation_id']??''):'',(array)($r['observations']??[]))))];
            }
        }
        unset($group);return $groups;
    }
    private static function shouldDropWeakKeywordIdeaGroup(array $group,string $v2Status,array $candidate=[]): bool {$sources=self::groupSourceClasses($group);if($v2Status!=='NO_MATCH'||count($sources)!==1||$sources[0]!=='KEYWORD_IDEA')return false;return (string)($candidate['decision']??'')!=='PASS';}
    /** @return list<string> */
    private static function groupSourceClasses(array $group): array {$sources=[];foreach((array)($group['all_records']??[]) as $record)foreach((array)($record['source_names']??[]) as $source){$source=trim((string)$source);if($source!=='')$sources[$source]=true;}foreach((array)($group['aliases']??[]) as $alias)foreach((array)($alias['source_names']??[]) as $source){$source=trim((string)$source);if($source!=='')$sources[$source]=true;}$out=array_keys($sources);sort($out,SORT_STRING);return $out;}
    private static function rankScore(array $record,array $aliases,?array $firstParty): int {$score=(int)($record['search_volume']??0);$sources=[];foreach($aliases as $a)foreach((array)($a['source_names']??[]) as $s)$sources[$s]=true;$score+=count($sources)*5000;$score+=(int)($firstParty['impressions']??0);if(PSTE_Normalizer::isQuestion((string)$record['language_corrected_query']) )$score+=2000;return $score;}
    public static function syncSearchConsole(string $siteUrl,string $startDate,string $endDate): array {$rows=[];$sourceCount=0;$responseHashes=[];for($pageIndex=0;$pageIndex<4;$pageIndex++){$response=PSTE_GSC_Client::queryAnalytics($siteUrl,$startDate,$endDate,$pageIndex*25000,25000);$batch=$response['rows']??[];$sourceCount+=count($batch);$responseHashes[]=hash('sha256',self::json($response));foreach($batch as $row){$keys=$row['keys']??[];$query=trim((string)($keys[0]??''));$page=trim((string)($keys[1]??''));if($query===''||$page===''||PSTE_First_Party_Import::containsPii($query))continue;[$postId,$categoryId]=self::resolvePageCategory($page);$rows[]=['query'=>$query,'page'=>$page,'post_id'=>$postId,'category_id'=>$categoryId,'clicks'=>(float)($row['clicks']??0),'impressions'=>(float)($row['impressions']??0),'ctr'=>(float)($row['ctr']??0),'position'=>(float)($row['position']??0)];}if(count($batch)<25000)break;}$saved=PSTE_Repository::replaceGscRows($siteUrl,$startDate,$endDate,$rows);$saved['source_row_count']=$sourceCount;$saved['accepted_row_count']=count($rows);$saved['response_bundle_sha256']=hash('sha256',implode('|',$responseHashes));$saved['pagination_limit_rows']=100000;update_option(PSTE_OPTION_GSC_LAST_SYNC,$saved,false);return $saved;}
    private static function resolvePageCategory(string $pageUrl): array {$postId=function_exists('url_to_postid')?(int)url_to_postid($pageUrl):0;if($postId>0){$cats=wp_get_post_categories($postId,['fields'=>'ids']);return[$postId,is_array($cats)&&$cats?(int)reset($cats):0];}$terms=get_categories(['hide_empty'=>false]);foreach($terms as $term){$link=get_category_link((int)$term->term_id);if(!is_wp_error($link)&&untrailingslashit((string)$link)===untrailingslashit($pageUrl))return[0,(int)$term->term_id];}return[0,0];}
    private static function applyInternalDuplicates(array &$candidates): void {
        $order=array_keys($candidates);$priorities=[];$signatures=[];
        foreach($order as $index){$priorities[$index]=self::duplicatePriority((array)$candidates[$index]);$signatures[$index]=self::duplicateSignature((array)$candidates[$index]);}
        usort($order,static function(int $a,int $b)use($candidates,$priorities):int{
            $pa=$priorities[$a];$pb=$priorities[$b];for($i=0;$i<3;$i++){if($pa[$i]!==$pb[$i])return $pb[$i]<=>$pa[$i];}
            return strcmp((string)($candidates[$a]['candidate_id']??''),(string)($candidates[$b]['candidate_id']??''));
        });
        $accepted=[];
        foreach($order as $index){
            if(($candidates[$index]['decision']??'')!=='PASS')continue;
            $duplicateOf=null;
            foreach($accepted as $owner){
                $a=$signatures[$index];$b=$signatures[$owner];
                $same=($a['category']===''||$b['category']==='')?self::sameAnswerIntent((array)$candidates[$index],(array)$candidates[$owner]):self::sameAnswerIntentSignature($a,$b);
                if($same){$duplicateOf=$owner;break;}
            }
            if($duplicateOf===null){$accepted[]=$index;continue;}
            $crossType=(string)$signatures[$index]['type']!==(string)$signatures[$duplicateOf]['type'];
            $candidates[$index]['decision']='BLOCKED';$candidates[$index]['discovery_only']=true;$candidates[$index]['candidate_role']='DISCOVERY_PROBE';$candidates[$index]['human_review_required']=true;
            $codes=['DUPLICATE_WITHIN_RESEARCH_RUN'];if($crossType)$codes[]='CROSS_TYPE_ANSWER_EQUIVALENCE';
            $candidates[$index]['reason_codes']=array_values(array_unique(array_merge((array)($candidates[$index]['reason_codes']??[]),$codes)));
            $candidates[$index]['duplicate_of_candidate_id']=(string)($candidates[$duplicateOf]['candidate_id']??'');
            $candidates[$index]['duplicate_of_title']=(string)$signatures[$duplicateOf]['title'];
        }
    }
    /** @return array{0:int,1:int,2:int} */
    private static function duplicatePriority(array $candidate): array {
        $sources=[];foreach((array)($candidate['evidence']??[]) as $e)if(is_array($e)&&trim((string)($e['source']??''))!=='')$sources[(string)$e['source']]=true;
        return [(int)($candidate['research_rank_score']??0),(int)($candidate['metrics']['search_volume']??-1),count($sources)];
    }
    
    private static function duplicateSignature(array $candidate): array {
            $query=(string)($candidate['primary_longtail_query']??$candidate['canonical_query']??'');$category=(string)($candidate['target_category_name']??'');$title=PSTE_Editorializer::displayTitle($candidate);
            $queryTuple=$category!==''?PSTE_Normalizer::intentTuple($query,$category):[];$titleTuple=$category!==''?PSTE_Normalizer::intentTuple($title,$category):[];
            return ['family'=>(string)($candidate['topic_family_key']??''),'cluster'=>(string)($candidate['intent_cluster_id']??''),'type'=>PSTE_Article_Type_Registry::canonicalType((string)($candidate['proposed_article_type']??'')),'category'=>$category,'title'=>$title,
                'query_tuple'=>$queryTuple,'query_tokens'=>PSTE_Normalizer::tokens($query),'query_context_tokens'=>$queryTuple?PSTE_Normalizer::tokens((string)($queryTuple['context']??'')):[],
                'title_tuple'=>$titleTuple,'title_tokens'=>PSTE_Normalizer::tokens($title),'title_context_tokens'=>$titleTuple?PSTE_Normalizer::tokens((string)($titleTuple['context']??'')):[]];
        }
    private static function sameAnswerIntentSignature(array $a,array $b): bool {
            $familyA=(string)($a['family']??'');$familyB=(string)($b['family']??'');if($familyA===''||$familyB===''||!hash_equals($familyA,$familyB))return false;
            $clusterA=(string)($a['cluster']??'');$clusterB=(string)($b['cluster']??'');if($clusterA!==''&&$clusterB!==''&&hash_equals($clusterA,$clusterB))return true;
            if(self::answerEquivalentSignature((array)$a['query_tuple'],(array)$b['query_tuple'],(array)$a['query_tokens'],(array)$b['query_tokens'],(array)$a['query_context_tokens'],(array)$b['query_context_tokens']))return true;
            return self::answerEquivalentSignature((array)$a['title_tuple'],(array)$b['title_tuple'],(array)$a['title_tokens'],(array)$b['title_tokens'],(array)$a['title_context_tokens'],(array)$b['title_context_tokens']);
        }
    private static function answerEquivalentSignature(array $aTuple,array $bTuple,array $aTokens,array $bTokens,array $aContextTokens,array $bContextTokens): bool {
            if((string)($aTuple['entity']??'')!==''&&(string)($bTuple['entity']??'')!==''&&(string)$aTuple['entity']!==(string)$bTuple['entity'])return false;
            if((string)($aTuple['user_goal']??'')===(string)($bTuple['user_goal']??'')&&(string)($aTuple['user_goal']??'')!=='information'){
                $contextA=(string)($aTuple['context']??'');$contextB=(string)($bTuple['context']??'');if($contextA===''&&$contextB==='')return true;
                if($contextA!==''&&$contextB!==''&&self::similarityTokens($aContextTokens,$bContextTokens)>=0.55)return true;
            }
            return self::similarityTokens($aTokens,$bTokens)>=0.78;
        }
    private static function similarityTokens(array $a,array $b): float {if(!$a||!$b)return 0.0;$intersection=count(array_intersect($a,$b));$union=count(array_unique(array_merge($a,$b)));return $union>0?round($intersection/$union,6):0.0;}
    private static function sameAnswerIntent(array $a,array $b): bool {
            $familyA=(string)($a['topic_family_key']??'');$familyB=(string)($b['topic_family_key']??'');if($familyA===''||$familyB===''||!hash_equals($familyA,$familyB))return false;
            $clusterA=(string)($a['intent_cluster_id']??'');$clusterB=(string)($b['intent_cluster_id']??'');if($clusterA!==''&&$clusterB!==''&&hash_equals($clusterA,$clusterB))return true;
            $queryA=(string)($a['primary_longtail_query']??$a['canonical_query']??'');$queryB=(string)($b['primary_longtail_query']??$b['canonical_query']??'');
            $categoryA=(string)($a['target_category_name']??'');$categoryB=(string)($b['target_category_name']??'');
            if(PSTE_Normalizer::answerEquivalent($queryA,$queryB,$categoryA,$categoryB))return true;
            return PSTE_Normalizer::answerEquivalent(PSTE_Editorializer::displayTitle($a),PSTE_Editorializer::displayTitle($b),$categoryA,$categoryB);
        }

    /** @return array<int,array<string,mixed>> */
    private static function persistenceCandidateSet(array $candidates): array {
        $byId=[];
        foreach($candidates as $candidate){
            if(!is_array($candidate))throw new RuntimeException('PSTE_RESEARCH_CANDIDATE_INVALID');
            $id=trim((string)($candidate['candidate_id']??''));
            if($id==='')throw new RuntimeException('PSTE_RESEARCH_CANDIDATE_ID_MISSING');
            // Deliberately overwrite the previous element: this is byte-for-byte equivalent
            // to the historical saveCandidate(REPLACE) order for UNIQUE(run_uuid,candidate_id).
            $byId[$id]=$candidate;
        }
        return array_values($byId);
    }

    private static function planItemsAsInventory(array $items,array $structure): array {return PSTE_Planning_Readiness_Gate::planItemsAsInventory($items,$structure);}
    private static function mysqlDate(string $value): string {$ts=strtotime($value);return gmdate('Y-m-d H:i:s',$ts===false?time():$ts);}
    private static function json($value): string {$json=function_exists('wp_json_encode')?wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($json)?$json:'';}
    public static function responseCost(array $response): float {return PSTE_DataForSEO_Client::cacheHit($response)?0.0:(float)(PSTE_DataForSEO_Client::externalResponse($response)['cost']??0.0);}
}
