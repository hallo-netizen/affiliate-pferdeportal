<?php
if (!defined('ABSPATH')) { return; }

/**
 * Read-only classifier for the editorial article type "Produktwahl".
 *
 * Produktwahl is reserved for queries that ask for one concrete purchasable
 * product (or a very small top choice) by a decisive selection criterion.
 * It never creates taxonomy, content or production authority.
 */
final class PSTE_Product_Choice_Classifier {
    public const CONTRACT='PSTE_PRODUCT_CHOICE_CLASSIFIER_V1';
    public const ARTICLE_TYPE='Produktwahl';

    /** @return array<string,mixed> */
    public static function evaluate(string $query,string $familyName='',string $familyStatus='',string $existingType=''): array {
        $query=self::clean($query);$familyName=self::clean($familyName);$familyStatus=strtoupper(trim($familyStatus));$existingType=trim($existingType);
        $base=[
            'contract'=>self::CONTRACT,'status'=>'NO_MATCH','ok'=>false,'article_type'=>'','query'=>$query,
            'family_name'=>$familyName,'family_status'=>$familyStatus,'existing_article_type'=>$existingType,
            'criterion'=>'','criterion_kind'=>'','reason_codes'=>[],'production_authority'=>false,
            'provider_calls'=>0,'write_attempted'=>false,
        ];
        if($query==='')return self::finish($base,'NO_MATCH',['PSTE_PRODUCT_CHOICE_QUERY_MISSING']);

        // Hard boundary: only a portal-proven concrete product family may become Produktwahl.
        // This prevents unrelated superlative questions (horse breeds, surgery, famous horses, etc.)
        // from being relabelled merely because they appeared inside a product research run.
        if($familyStatus!=='MATCH'||$familyName==='')return self::finish($base,'NO_MATCH',['PSTE_PRODUCT_CHOICE_PRODUCT_FAMILY_NOT_PROVEN']);

        // A direct A-vs-B/comparison request stays Vergleich. Produktwahl is the "which one wins this criterion?" lane.
        if(self::directComparison($query))return self::finish($base,'NO_MATCH',['PSTE_PRODUCT_CHOICE_DIRECT_COMPARISON_EXCLUDED']);

        $criterion=self::criterion($query,$familyName);
        if($criterion['value']==='')return self::finish($base,'NO_MATCH',['PSTE_PRODUCT_CHOICE_DECISIVE_SELECTION_CRITERION_MISSING']);

        // A superlative alone is insufficient if the wording is clearly informational about a value rather than a product choice.
        // The allowed surface must ask/seek a winning concrete item or use a compact product-choice search phrase.
        if(!self::choiceSurface($query))return self::finish($base,'REVIEW_REQUIRED',['PSTE_PRODUCT_CHOICE_WINNER_SURFACE_NOT_PROVEN']);

        $base['criterion']=$criterion['value'];$base['criterion_kind']=$criterion['kind'];$base['article_type']=self::ARTICLE_TYPE;$base['ok']=true;
        return self::finish($base,'MATCH',['PSTE_PRODUCT_CHOICE_HARD_MATCH']);
    }

    /** Manual export/review override; it never creates production authority. @return array<string,mixed> */
    public static function applyManualOverride(array $classification,string $manualArticleType): array {
        $manualArticleType=trim($manualArticleType);
        if($manualArticleType==='')return $classification;
        $classification['manual_override']=true;$classification['manual_article_type']=$manualArticleType;
        $classification['article_type']=$manualArticleType;
        $classification['status']='MANUAL_REVIEW_OVERRIDE';$classification['ok']=true;
        $classification['reason_codes']=array_values(array_unique(array_merge((array)($classification['reason_codes']??[]),['PSTE_MANUAL_ARTICLE_TYPE_REVIEW_OVERRIDE'])));
        $classification['production_authority']=false;$classification['write_attempted']=false;
        return $classification;
    }

    /** @return array{value:string,kind:string} */
    private static function criterion(string $query,string $familyName=''): array {
        $rules=[
            'QUIETEST'=>['leisest'],
            'LOUDEST'=>['lautest'],
            'LIGHTEST'=>['leichtest'],
            'HEAVIEST'=>['schwerst'],
            'CHEAPEST'=>['günstigst','guenstigst','billigst'],
            'MOST_EXPENSIVE'=>['teuerst'],
            'MOST_ECONOMICAL'=>['sparsamst','effizientest','energiesparendst'],
            'STRONGEST'=>['stärkst','staerkst','leistungsstärkst','leistungsstaerkst'],
            'SMALLEST'=>['kleinst'],
            'LARGEST'=>['größt','groesst'],
            'FASTEST'=>['schnellst'],
            'LONGEST'=>['längst','laengst'],
            'HIGHEST'=>['höchst','hoechst'],
            'LOWEST'=>['niedrigst','geringst'],
        ];
        foreach($rules as $kind=>$stems){
            foreach($stems as $stem){
                if(preg_match('/\b'.preg_quote($stem,'/').'[\p{L}]*\b/iu',$query,$m))return ['value'=>(string)$m[0],'kind'=>$kind];
            }
        }
        // "best" is intentionally narrow: do not match words such as "besticken" or "Bestimmung".
        if(preg_match('/\b(?:am\s+besten|beste|bester|bestes|besten|bestem)\b/iu',$query,$m))return ['value'=>(string)$m[0],'kind'=>'BEST'];

        // Future-safe German superlative fallback. It is deliberately narrower than a raw
        // "-st-" suffix test: nouns such as "Pferdebürste" must never become a criterion.
        // (1) "am <adjective>sten" is a strong grammatical superlative surface.
        if(preg_match('/\bam\s+([\p{L}]{4,}?sten)\b/iu',$query,$m)){
            $token=(string)$m[1];
            if(self::genericSuperlativeAllowed($token,$familyName))return ['value'=>(string)$m[0],'kind'=>'GENERIC_SUPERLATIVE'];
        }
        // (2) declined singular superlatives: "das sanfteste Gebiss", "welcher robusteste ...".
        // Plural/dative "-sten" forms are intentionally not accepted here because ordinary
        // product nouns/verbs frequently end in "-sten"; those are covered safely by (1).
        if(preg_match('/\b(?:der|die|das|ein|eine|einer|eines|welcher|welche|welches)\s+([\p{L}]{4,}?(?:ste|ster|stes|stem))\b/iu',$query,$m)){
            $token=(string)$m[1];
            if(self::genericSuperlativeAllowed($token,$familyName))return ['value'=>$token,'kind'=>'GENERIC_SUPERLATIVE'];
        }
        return ['value'=>'','kind'=>''];
    }

    private static function genericSuperlativeAllowed(string $token,string $familyName): bool {
        $token=self::lower($token);
        $ascii=strtr($token,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);
        // Structural/ordinal/informational superlatives are not product-selection criteria.
        foreach(['wichtigst','haeufigst','meist','erst','letzt','naechst','wenigst','allgemeinst','bekanntest'] as $blocked){
            if(str_starts_with($ascii,$blocked))return false;
        }
        // Never interpret the family noun itself as an adjectival criterion (e.g. Pferdebürste).
        $candidateStem=self::nominalStem($ascii);
        foreach(preg_split('/[^\p{L}0-9]+/u',self::lower($familyName),-1,PREG_SPLIT_NO_EMPTY)?:[] as $familyToken){
            $familyAscii=strtr((string)$familyToken,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);
            if($candidateStem!==''&&$candidateStem===self::nominalStem($familyAscii))return false;
        }
        return true;
    }

    private static function nominalStem(string $token): string {
        $token=trim($token);
        foreach(['ern','en','er','es','em','e','n','s'] as $suffix){
            if(strlen($token)>strlen($suffix)+4&&str_ends_with($token,$suffix)){
                if($suffix==='s'&&str_ends_with($token,'ss'))continue;
                return substr($token,0,-strlen($suffix));
            }
        }
        return $token;
    }

    private static function directComparison(string $query): bool {
        if(preg_match('/\b(vs\.?|versus|gegenüber|gegenueber|unterschied\w*|vergleich\w*)\b/iu',$query))return true;
        // "A oder B" is deliberately kept out of Produktwahl. It remains existing comparison/advice review logic.
        if(preg_match('/\S+\s+oder\s+\S+/iu',$query))return true;
        return false;
    }

    private static function choiceSurface(string $query): bool {
        $q=self::lower($query);
        // Natural direct product-choice questions.
        if(preg_match('/^(welcher|welche|welches|was)\b/iu',$q))return true;
        if(preg_match('/\bwelch(?:er|e|es|en|em)\b/iu',$q))return true;
        // Compact SEO phrase such as "leiseste schermaschine pferd" or "beste hufschuhe winter".
        if(!PSTE_Normalizer::isQuestion($query)&&count(PSTE_Token_Equivalence::tokens($query))>=2)return true;
        return false;
    }

    /** @param list<string> $reasons @return array<string,mixed> */
    private static function finish(array $base,string $status,array $reasons): array {
        $base['status']=$status;$base['reason_codes']=array_values(array_unique($reasons));
        if($status!=='MATCH'&&$status!=='MANUAL_REVIEW_OVERRIDE'){$base['ok']=false;$base['article_type']='';}
        return $base;
    }

    private static function clean(string $v): string {
        $v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');
        return trim((string)preg_replace('/\s+/u',' ',$v));
    }
    private static function lower(string $v): string {return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
}
