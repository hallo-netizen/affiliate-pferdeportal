<?php
if (!defined('ABSPATH')) { return; }

/**
 * Compact canonical producer→persisted-record→consumer contract for Sandbox diagnostics.
 *
 * V2 intentionally stores the large portal/exclusion/nearest components only once on the record
 * and binds them from sandbox_dataflow by SHA-256. The full normal-path object is not duplicated;
 * only its canonical hash plus a small human-readable summary are persisted. V1 remains readable
 * so existing records can be migrated request-bounded without invalidating historical evidence.
 */
final class PSTE_Sandbox_Record_Contract {
    public const CONTRACT='PSTE_SANDBOX_RECORD_DATAFLOW_V2_COMPACT';
    public const LEGACY_CONTRACT='PSTE_SANDBOX_RECORD_DATAFLOW_V1';
    public const ADMIN_VIEW_CONTRACT='PSTE_SANDBOX_ADMIN_VIEW_V1';

    /** @return array<string,mixed> */
    public static function fromNormalPath(string $query,array $normalPath,array $baseline,array $registry): array {
        $query=self::clean($query);if($query==='')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_QUERY_REQUIRED');
        if(($normalPath['contract']??'')!==PSTE_Normal_Metadata_Path::CONTRACT)throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_CONTRACT_INVALID');
        $rawSha=(string)($normalPath['raw_query_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$rawSha)||!hash_equals(hash('sha256',$query),$rawSha))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_RAW_MISMATCH');
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_BASELINE_REQUIRED');
        if(empty($registry['registry_sha256']))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_REGISTRY_REQUIRED');

        $portalContext=PSTE_Category_Context::portalContextEvidence($query,$baseline);
        if(($portalContext['contract']??'')!=='PSTE_PORTAL_CONTEXT_EVIDENCE_V3_PORTAL_SEEDS_FAIL_CLOSED')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_PORTAL_CONTEXT_INVALID');
        $gate=(array)($normalPath['portal_relevance_gate']??[]);$portal=$portalContext;
        $portal['status']=(string)($normalPath['portal_relevance']??'UNPROVEN');$portal['decision_status']=$portal['status'];
        $portal['source']=(string)($gate['source']??'CURRENT_NORMAL_PATH');$portal['decision_gate_contract']=(string)($gate['contract']??'');$portal['decision_gate_sha256']=$gate?self::hash($gate):'';$portal['diagnostic_only']=true;
        $nearest=self::nearestFromNormalPath($normalPath);$nearestFailures=self::nearestFailureReasons($normalPath);
        $exclusions=PSTE_Sandbox_Portal_Relevance::exclusionEvidence($query,$registry,$nearest);
        if(($exclusions['contract']??'')!=='PSTE_SANDBOX_EXCLUSION_EVIDENCE_V1')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_EXCLUSION_EVIDENCE_INVALID');
        $flow=self::compactFlow('PSTE_NORMAL_PATH_PLUS_CURRENT_PORTAL_CONTEXT',$query,self::hash($normalPath),$portal,$nearest,$nearestFailures,$exclusions);
        // V2 persists the large diagnostic components exactly once on the record and only their
        // hashes inside sandbox_dataflow. Carry them transiently from the producer into
        // applyToRecord(); they are stripped before sandbox_dataflow is persisted.
        $flow['_record_components']=[
            'portal_relevance'=>$portal,
            'nearest_rejected_families'=>array_values($nearest),
            'nearest_failure_reason_codes'=>array_values(array_map('strval',$nearestFailures)),
            'exclusion_evidence'=>$exclusions,
        ];
        return $flow;
    }

    /** @return array<string,mixed> */
    public static function fromLegacyRoute(string $query,array $route,array $nearest,array $nearestFailureReasons=[],array $normalPath=[]): array {
        $query=self::clean($query);if($query==='')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_QUERY_REQUIRED');
        $portal=(array)($route['portal_context']??[]);$exclusions=(array)($route['exclusion_evidence']??[]);
        if(($portal['contract']??'')!=='PSTE_PORTAL_CONTEXT_EVIDENCE_V3_PORTAL_SEEDS_FAIL_CLOSED')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_LEGACY_PORTAL_CONTEXT_INVALID');
        if(($exclusions['contract']??'')!=='PSTE_SANDBOX_EXCLUSION_EVIDENCE_V1')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_LEGACY_EXCLUSION_INVALID');
        $portal['status']='UNPROVEN';$portal['decision_status']='UNPROVEN';$portal['source']='LEGACY_DRY_RUN_DIAGNOSTIC';$portal['diagnostic_only']=true;
        return self::compactFlow('PSTE_LEGACY_DRY_RUN_ROUTE',$query,$normalPath?self::hash($normalPath):'',$portal,array_values($nearest),array_values(array_unique(array_filter(array_map('strval',$nearestFailureReasons),'strlen'))),$exclusions);
    }

    /** @return array<string,mixed> */
    public static function applyToRecord(array $record,array $flow,array $normalPath=[]): array {
        $components=is_array($flow['_record_components']??null)?(array)$flow['_record_components']:null;
        unset($flow['_record_components']);
        self::assertFlow($flow);
        if($components!==null){
            foreach(['portal_relevance','nearest_rejected_families','nearest_failure_reason_codes','exclusion_evidence'] as $field)if(!array_key_exists($field,$components))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_RECORD_COMPONENTS_INCOMPLETE');
            if(!hash_equals((string)$flow['portal_relevance_sha256'],self::hash($components['portal_relevance'])))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_PORTAL_COMPONENT_DRIFT');
            if(!hash_equals((string)$flow['nearest_rejected_families_sha256'],self::hash(array_values((array)$components['nearest_rejected_families']))))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NEAREST_COMPONENT_DRIFT');
            if(!hash_equals((string)$flow['nearest_failure_reason_codes_sha256'],self::hash(array_values(array_map('strval',(array)$components['nearest_failure_reason_codes'])))))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NEAREST_REASON_COMPONENT_DRIFT');
            if(!hash_equals((string)$flow['exclusion_evidence_sha256'],self::hash($components['exclusion_evidence'])))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_EXCLUSION_COMPONENT_DRIFT');
            $record['portal_relevance']=(array)$components['portal_relevance'];$record['nearest_rejected_families']=array_values((array)$components['nearest_rejected_families']);$record['nearest_failure_reason_codes']=array_values(array_map('strval',(array)$components['nearest_failure_reason_codes']));$record['exclusion_evidence']=(array)$components['exclusion_evidence'];
        }elseif(($flow['contract']??'')===self::LEGACY_CONTRACT){
            $record['portal_relevance']=(array)$flow['portal_relevance'];$record['nearest_rejected_families']=array_values((array)$flow['nearest_rejected_families']);$record['nearest_failure_reason_codes']=array_values(array_map('strval',(array)$flow['nearest_failure_reason_codes']));$record['exclusion_evidence']=(array)$flow['exclusion_evidence'];
        }
        if($normalPath){$record['normal_path_admission_sha256']=self::hash($normalPath);$record['normal_path_admission_summary']=self::normalPathSummary($normalPath);unset($record['normal_path_admission']);}
        $record['sandbox_dataflow']=$flow;return $record;
    }

    /** Convert an existing V1 record to V2 without recomputing domain decisions. */
    public static function compactStoredRecord(array $record): array {
        $flow=(array)($record['sandbox_dataflow']??[]);if(!$flow)return $record;self::assertFlow($flow);
        $normalHash=(string)($flow['normal_path_sha256']??'');
        if(is_array($record['normal_path_admission']??null)){$normal=(array)$record['normal_path_admission'];$actual=self::hash($normal);if($normalHash!==''&&!hash_equals($normalHash,$actual))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_STORED_ADMISSION_PATH_MISMATCH');$record['normal_path_admission_sha256']=$actual;$record['normal_path_admission_summary']=self::normalPathSummary($normal);unset($record['normal_path_admission']);}
        elseif($normalHash!==''&&!preg_match('/^[a-f0-9]{64}$/',(string)($record['normal_path_admission_sha256']??'')))$record['normal_path_admission_sha256']=$normalHash;
        if(($flow['contract']??'')===self::LEGACY_CONTRACT){
            foreach(['portal_relevance','nearest_rejected_families','nearest_failure_reason_codes','exclusion_evidence'] as $field)if(!array_key_exists($field,$record)&&array_key_exists($field,$flow))$record[$field]=$flow[$field];
            $flow=self::compactFlow((string)($flow['producer']??'PSTE_LEGACY_COMPACTED_DATAFLOW'),(string)($record['query']??''),(string)($flow['normal_path_sha256']??''),(array)($record['portal_relevance']??[]),array_values((array)($record['nearest_rejected_families']??[])),array_values(array_map('strval',(array)($record['nearest_failure_reason_codes']??[]))),(array)($record['exclusion_evidence']??[]));
            $record['sandbox_dataflow']=$flow;
        }
        self::verifyStoredRecordSelfConsistency($record);return $record;
    }

    /** @return array<string,mixed> */
    public static function verifyRecordAgainstNormalPath(array $record,array $normalPath,array $baseline,array $registry): array {
        $query=self::clean((string)($record['query']??''));$expected=self::fromNormalPath($query,$normalPath,$baseline,$registry);$stored=(array)($record['sandbox_dataflow']??[]);self::assertFlow($stored);
        foreach(['portal_relevance','nearest_rejected_families','exclusion_evidence'] as $field){$expectedHash=(string)($expected[$field.'_sha256']??'');if(!hash_equals($expectedHash,self::hash($record[$field]??null)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_RECORD_FIELD_MISMATCH_'.strtoupper($field));}
        $expectedNearestReasonHash=(string)($expected['nearest_failure_reason_codes_sha256']??'');if(!hash_equals($expectedNearestReasonHash,self::hash(array_values(array_map('strval',(array)($record['nearest_failure_reason_codes']??[]))))))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_RECORD_FIELD_MISMATCH_NEAREST_FAILURE_REASON_CODES');
        if(!hash_equals((string)$expected['normal_path_sha256'],(string)($stored['normal_path_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_HASH_MISMATCH');
        $admissionSha=(string)($record['normal_path_admission_sha256']??'');if($admissionSha!==''&&!hash_equals($admissionSha,self::hash($normalPath)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_ADMISSION_PATH_MISMATCH');
        self::verifyComponentBindings($record,$stored);
        return ['contract'=>'PSTE_SANDBOX_RECORD_DATAFLOW_VERIFY_V2','status'=>'PASS','query_sha256'=>(string)$expected['query_sha256'],'dataflow_sha256'=>(string)$stored['dataflow_sha256'],'write_attempted'=>false,'production_handoff_attempted'=>false];
    }

    /** @return array<string,mixed> */
    public static function adminView(array $record): array {
        $flow=(array)($record['sandbox_dataflow']??[]);self::assertFlow($flow);self::verifyComponentBindings($record,$flow);
        return ['contract'=>self::ADMIN_VIEW_CONTRACT,'sandbox_id'=>(string)($record['sandbox_id']??''),'query'=>(string)($record['query']??''),'search_volume'=>$record['search_volume']??null,'local_matched_terms'=>array_values((array)($record['portal_relevance']['matched_terms']??[])),'portal_relevance'=>(array)($record['portal_relevance']??[]),'exclusion_evidence'=>(array)($record['exclusion_evidence']??[]),'nearest_rejected_families'=>array_values((array)($record['nearest_rejected_families']??[])),'external_relevance'=>$record['external_relevance']??null,'relevance_adjudication'=>$record['relevance_adjudication']??null,'relevance_revision_count'=>count((array)($record['relevance_revision_archive']??[])),'current_relevance_proof'=>$record['current_relevance_proof']??null,'relevance_conflict'=>$record['relevance_conflict']??null,'internal_proposal'=>$record['internal_proposal']??null,'internal_proposal_sha256'=>(string)($record['internal_proposal_sha256']??''),'status'=>(string)($record['status']??''),'workflow_lane'=>(string)($record['workflow_lane']??''),'dataflow_status'=>'VERIFIED','dataflow_sha256'=>(string)$flow['dataflow_sha256'],'write_attempted'=>false,'production_handoff_attempted'=>false];
    }

    /** Validate one persisted current/legacy-contract record without recomputing domain decisions. */
    public static function verifyStoredRecordSelfConsistency(array $record): array {
        $flow=(array)($record['sandbox_dataflow']??[]);self::assertFlow($flow);$query=self::clean((string)($record['query']??''));
        if($query===''||!hash_equals((string)($flow['query_sha256']??''),hash('sha256',$query)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_STORED_QUERY_MISMATCH');self::verifyComponentBindings($record,$flow);
        $normalHash=(string)($flow['normal_path_sha256']??'');if($normalHash!==''){
            $storedSha=(string)($record['normal_path_admission_sha256']??'');
            if($storedSha===''){ $admission=(array)($record['normal_path_admission']??[]);if(!$admission||!hash_equals($normalHash,self::hash($admission)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_STORED_ADMISSION_PATH_MISMATCH');}
            elseif(!hash_equals($normalHash,$storedSha))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_STORED_ADMISSION_HASH_MISMATCH');
        }
        return ['contract'=>'PSTE_SANDBOX_STORED_RECORD_SELF_VERIFY_V2','status'=>'PASS','dataflow_sha256'=>(string)$flow['dataflow_sha256'],'write_attempted'=>false,'production_handoff_attempted'=>false];
    }

    public static function hasCurrentContract(array $record): bool {try{$flow=(array)($record['sandbox_dataflow']??[]);self::assertFlow($flow);return ($flow['contract']??'')===self::CONTRACT;}catch(Throwable $e){return false;}}

    /** @return array<string,mixed> */
    private static function compactFlow(string $producer,string $query,string $normalPathSha,array $portal,array $nearest,array $nearestFailures,array $exclusions): array {
        $query=self::clean($query);if($query==='')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_QUERY_REQUIRED');$payload=['contract'=>self::CONTRACT,'producer'=>$producer,'query_sha256'=>hash('sha256',$query),'normal_path_sha256'=>$normalPathSha,'portal_relevance_sha256'=>self::hash($portal),'nearest_rejected_families_sha256'=>self::hash(array_values($nearest)),'nearest_failure_reason_codes_sha256'=>self::hash(array_values(array_map('strval',$nearestFailures))),'exclusion_evidence_sha256'=>self::hash($exclusions),'write_attempted'=>false,'production_handoff_attempted'=>false];$payload['dataflow_sha256']=self::hash($payload);return $payload;
    }

    private static function verifyComponentBindings(array $record,array $flow): void {
        if(($flow['contract']??'')===self::LEGACY_CONTRACT){
            foreach(['portal_relevance','nearest_rejected_families','nearest_failure_reason_codes','exclusion_evidence'] as $field)if(self::hash($record[$field]??null)!==self::hash($flow[$field]??null))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_STORED_FIELD_MISMATCH_'.strtoupper($field));return;
        }
        if(!hash_equals((string)($flow['portal_relevance_sha256']??''),self::hash($record['portal_relevance']??null)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_PORTAL_COMPONENT_DRIFT');
        if(!hash_equals((string)($flow['nearest_rejected_families_sha256']??''),self::hash(array_values((array)($record['nearest_rejected_families']??[])))))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NEAREST_COMPONENT_DRIFT');
        if(!hash_equals((string)($flow['nearest_failure_reason_codes_sha256']??''),self::hash(array_values(array_map('strval',(array)($record['nearest_failure_reason_codes']??[]))))))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NEAREST_REASON_COMPONENT_DRIFT');
        if(!hash_equals((string)($flow['exclusion_evidence_sha256']??''),self::hash($record['exclusion_evidence']??null)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_EXCLUSION_COMPONENT_DRIFT');
    }

    /** @return array<string,mixed> */
    private static function normalPathSummary(array $normalPath): array {
        $target=(array)($normalPath['target_category']??[]);return ['contract'=>(string)($normalPath['contract']??''),'status'=>(string)($normalPath['status']??''),'ok'=>!empty($normalPath['ok']),'portal_relevance'=>(string)($normalPath['portal_relevance']??''),'family_key'=>(string)($normalPath['family_key']??''),'family_name'=>(string)($normalPath['family_name']??''),'article_type'=>(string)($normalPath['article_type']??''),'target_category_id'=>(int)($target['term_id']??0),'target_category_name'=>(string)($target['name']??''),'title'=>(string)($normalPath['title']??''),'target_keyword'=>(string)($normalPath['target_keyword']??''),'sandbox_admission_mode'=>(string)($normalPath['sandbox_admission_mode']??''),'reason_codes'=>array_values(array_unique(array_filter(array_map('strval',(array)($normalPath['reason_codes']??[]))))),'write_attempted'=>false];
    }

    /** @return array<int,array<string,mixed>> */
    private static function nearestFromNormalPath(array $normalPath): array {$fr=(array)($normalPath['family_resolution']??[]);$diag=(array)($fr['rejection_diagnostics']??[]);$nearest=(array)($diag['nearest_rejected_families']??$fr['nearest_rejected_families']??[]);if(!$nearest){$hint=(array)($normalPath['portal_relevance_gate']['family_hint']['resolution']??[]);$hd=(array)($hint['rejection_diagnostics']??[]);$nearest=(array)($hd['nearest_rejected_families']??$hint['nearest_rejected_families']??[]);}return array_values($nearest);}
    /** @return list<string> */
    private static function nearestFailureReasons(array $normalPath): array {$codes=[];$membership=(array)($normalPath['family_membership']??[]);$codes=array_merge($codes,(array)($membership['reason_codes']??[]));$fr=(array)($normalPath['family_resolution']??[]);$diag=(array)($fr['rejection_diagnostics']??[]);$codes=array_merge($codes,(array)($diag['nearest_failure_reason_codes']??[]));return array_values(array_unique(array_filter(array_map('strval',$codes),'strlen')));}
    private static function assertFlow(array $flow): void {
        $contract=(string)($flow['contract']??'');if(!in_array($contract,[self::CONTRACT,self::LEGACY_CONTRACT],true))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_CONTRACT_INVALID');$declared=(string)($flow['dataflow_sha256']??'');$copy=$flow;unset($copy['dataflow_sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(self::hash($copy),$declared))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_HASH_INVALID');
        if($contract===self::LEGACY_CONTRACT){foreach(['portal_relevance_sha256','nearest_rejected_families_sha256','exclusion_evidence_sha256'] as $f)if(!preg_match('/^[a-f0-9]{64}$/',(string)($flow[$f]??'')))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_COMPONENT_HASH_INVALID');if(!hash_equals((string)$flow['portal_relevance_sha256'],self::hash($flow['portal_relevance']??null)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_PORTAL_COMPONENT_DRIFT');if(!hash_equals((string)$flow['nearest_rejected_families_sha256'],self::hash($flow['nearest_rejected_families']??null)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NEAREST_COMPONENT_DRIFT');if(!hash_equals((string)$flow['exclusion_evidence_sha256'],self::hash($flow['exclusion_evidence']??null)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_EXCLUSION_COMPONENT_DRIFT');return;}
        foreach(['portal_relevance_sha256','nearest_rejected_families_sha256','nearest_failure_reason_codes_sha256','exclusion_evidence_sha256'] as $f)if(!preg_match('/^[a-f0-9]{64}$/',(string)($flow[$f]??'')))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_COMPONENT_HASH_INVALID');
    }
    private static function clean(string $v): string {return PSTE_Normal_Metadata_Path::canonicalInputQuery($v);}    
    private static function hash($v): string {$j=function_exists('wp_json_encode')?wp_json_encode(self::canonicalize($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode(self::canonicalize($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return hash('sha256',(string)$j);}    
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
}
