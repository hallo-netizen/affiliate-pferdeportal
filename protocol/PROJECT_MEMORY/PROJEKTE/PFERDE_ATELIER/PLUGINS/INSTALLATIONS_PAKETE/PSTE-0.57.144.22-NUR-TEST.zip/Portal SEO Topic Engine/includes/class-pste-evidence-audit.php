<?php
if (!defined('ABSPATH')) { return; }
/** Read-only, bounded inspection of persisted decisions. No provider, evaluator, reclassification or writes. */
final class PSTE_Evidence_Audit {
    private const PAGE_SIZE=40;
    private const SOURCES=['reason_codes'=>'SOURCE','normal_metadata_path'=>'NORMAL_PATH','planning_readiness_gate'=>'PLAN_GATE','pre_title_duplicate_gate'=>'DUPLICATE_GATE','portal_context'=>'PORTAL_CONTEXT','category_gate'=>'CATEGORY_GATE','editorialization'=>'EDITORIALIZATION'];
    private const COVERED=['EXACT_NORMALIZED_QUERY_DUPLICATE','SAME_INTENT_CLUSTER','CROSS_TYPE_ANSWER_EQUIVALENCE','CANONICAL_ARTICLE_OR_PLAN_SLOT_ALREADY_OWNED','ANSWER_EQUIVALENT_EXISTING','ANSWER_EQUIVALENT_PLANNED','PRE_TITLE_EXACT_SEO_KEYWORD_DUPLICATE','PRE_TITLE_ACTIVE_TITLE_CONTAINS_SOURCE_QUERY','PRE_TITLE_ANSWER_EQUIVALENT','SAME_PRIMARY_KEYWORD_SCOPE_WITHOUT_DISTINCT_LONGTAIL','SAME_LONGTAIL_KEYWORD_SCOPE'];
    private static function code($val): string {
        if(!is_scalar($val))return '';
        return substr(trim((string)preg_replace('/[^A-Z0-9_:-]/','_',strtoupper((string)$val)),'_'),0,110);
    }
    /** First-page count + fixed id ceiling; all future pages use index-backed id-range reads. */
    public static function batch(int $cursor=0,int $maxId=0): array {
        global $wpdb;
        if($cursor<0||$maxId<0||($maxId>0&&$cursor>$maxId))throw new RuntimeException('PSTE_EVIDENCE_CURSOR_INVALID');
        $table=PSTE_Repository::table('topic_pool');
        if($maxId===0){
            $meta=$wpdb->get_row("SELECT COALESCE(MAX(id),0) AS max_id, COUNT(*) AS total FROM $table",ARRAY_A);
            if(!is_array($meta)||(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_EVIDENCE_META_READ_FAILED');
            $maxId=(int)($meta['max_id']??0);$total=(int)($meta['total']??0);
        }else{$total=null;}
        $sql=$wpdb->prepare("SELECT id, topic_role, context_state, planning_suitability, automatic_pool_status, current_category_id, payload_json FROM $table WHERE id>%d AND id<=%d ORDER BY id ASC LIMIT %d",$cursor,$maxId,self::PAGE_SIZE);
        $rows=$maxId>0?$wpdb->get_results($sql,ARRAY_A):[];
        if(!is_array($rows)||(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_EVIDENCE_BATCH_READ_FAILED');
        $output=[];$next=$cursor;
        foreach($rows as $row){
            $next=(int)($row['id']??0);if($next<=$cursor)throw new RuntimeException('PSTE_EVIDENCE_CURSOR_NOT_ADVANCING');
            $payload=json_decode((string)($row['payload_json']??''),true);
            $valid=is_array($payload);if(!$valid)$payload=[];
            $reasons=[];
            foreach(self::SOURCES as $field=>$label){
                $section=$field==='reason_codes'?$payload:($payload[$field]??[]);
                if(!is_array($section))continue;
                foreach((array)($section['reason_codes']??[]) as $raw){
                    $code=self::code($raw);if($code!=='')$reasons[$label.':'.$code]=$code;
                }
                if($field==='portal_context'){
                    $code=self::code($section['error_code']??'');if($code!=='')$reasons['PORTAL_CONTEXT:'.$code]=$code;
                }
            }
            $duplicateEvidence=false;
            foreach($reasons as $code)if(in_array($code,self::COVERED,true)){$duplicateEvidence=true;break;}
            $query='';foreach(['canonical_query','primary_longtail_query','raw_user_question'] as $key){$q=trim((string)($payload[$key]??''));if($q!==''){$query=$q;break;}}
            $normal=is_array($payload['normal_metadata_path']??null)?$payload['normal_metadata_path']:[];
            $gate=is_array($payload['planning_readiness_gate']??null)?$payload['planning_readiness_gate']:[];
            $pre=is_array($payload['pre_title_duplicate_gate']??null)?$payload['pre_title_duplicate_gate']:[];
            $output[]=[
                'role'=>self::code($row['topic_role']??''),
                'context'=>self::code($row['context_state']??''),
                'planning'=>self::code($row['planning_suitability']??''),
                'pool_status'=>self::code($row['automatic_pool_status']??''),
                'category_missing'=>(int)($row['current_category_id']??0)<=0,
                'payload_invalid'=>!$valid,
                'source_query_missing'=>$query==='',
                'normal_path'=>self::code($normal['status']??''),
                'planning_gate'=>self::code($gate['status']??''),
                'duplicate_gate'=>self::code($pre['status']??''),
                'coverage_code_present'=>$duplicateEvidence,
                'reason_codes'=>array_slice(array_keys($reasons),0,48),
                'reason_code_truncated'=>count($reasons)>48,
                'sample'=>['topic'=>function_exists('mb_substr')?mb_substr($query,0,100,'UTF-8'):substr($query,0,100),'role'=>self::code($row['topic_role']??''),'context'=>self::code($row['context_state']??''),'normal_path'=>self::code($normal['status']??''),'reasons'=>array_slice(array_keys($reasons),0,12)]
            ];
        }
        return ['contract'=>'PSTE_EVIDENCE_BATCH_V1','read_only'=>true,'max_id'=>$maxId,'initial_total'=>$total,'cursor'=>$next,'rows'=>$output,'done'=>count($rows)<self::PAGE_SIZE || $next>=$maxId];
    }
}
