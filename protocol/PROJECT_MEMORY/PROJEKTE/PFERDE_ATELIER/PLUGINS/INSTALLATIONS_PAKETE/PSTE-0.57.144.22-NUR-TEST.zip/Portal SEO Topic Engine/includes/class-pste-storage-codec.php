<?php
if (!defined('ABSPATH')) { return; }

/**
 * Lossless storage-only codec for large PSTE-owned arrays.
 *
 * It never changes the logical array contract. Legacy plain JSON stays readable.
 * Compression is used only when zlib can both encode and decode and the packed
 * representation is smaller than the historical JSON representation.
 */
final class PSTE_Storage_Codec {
    public const CODEC='PSTE_DEFLATE_JSON_BASE64_V1';

    public static function encodeArrayText(array $value,string $context='PSTE_STORAGE'): string {
        $json=self::json($value,$context.'_JSON');
        $packed=self::packJson($json);
        if($packed===null)return $json;
        $envelope=['__pste_storage'=>self::CODEC,'sha256'=>hash('sha256',$json),'payload_b64'=>$packed];
        $encoded=self::json($envelope,$context.'_ENVELOPE');
        return strlen($encoded)<strlen($json)?$encoded:$json;
    }

    /** @return array<string,mixed> */
    public static function decodeArrayText(string $raw,string $context='PSTE_STORAGE'): array {
        $decoded=json_decode($raw,true);
        if(!is_array($decoded)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException($context.'_JSON_INVALID');
        if((string)($decoded['__pste_storage']??'')!==self::CODEC)return $decoded;
        $json=self::unpackJson((string)($decoded['payload_b64']??''),(string)($decoded['sha256']??''),$context);
        $logical=json_decode($json,true);
        if(!is_array($logical)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException($context.'_PACKED_JSON_INVALID');
        return $logical;
    }

    public static function isPackedText(string $raw): bool {
        $decoded=json_decode($raw,true);
        return is_array($decoded)&&json_last_error()===JSON_ERROR_NONE&&(string)($decoded['__pste_storage']??'')===self::CODEC;
    }

    /**
     * @return array{codec:string,sha256:string,blob_b64:string}|null
     */
    public static function packArray(array $value,string $context='PSTE_STORAGE'): ?array {
        $json=self::json($value,$context.'_JSON');$b64=self::packJson($json);if($b64===null)return null;
        $packed=['codec'=>self::CODEC,'sha256'=>hash('sha256',$json),'blob_b64'=>$b64];
        return strlen(serialize($packed))<strlen(serialize($value))?$packed:null;
    }

    /** @return array<string,mixed> */
    public static function unpackArray(array $packed,string $context='PSTE_STORAGE'): array {
        if((string)($packed['codec']??'')!==self::CODEC)throw new RuntimeException($context.'_CODEC_INVALID');
        $json=self::unpackJson((string)($packed['blob_b64']??''),(string)($packed['sha256']??''),$context);
        $logical=json_decode($json,true);if(!is_array($logical)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException($context.'_PACKED_JSON_INVALID');return $logical;
    }

    public static function logicalHash(array $value,string $context='PSTE_STORAGE'): string {return hash('sha256',self::json($value,$context.'_HASH'));}

    private static function packJson(string $json): ?string {
        if(!function_exists('gzdeflate')||!function_exists('gzinflate'))return null;
        $compressed=@gzdeflate($json,9);if(!is_string($compressed)||$compressed==='')return null;return base64_encode($compressed);
    }

    private static function unpackJson(string $b64,string $sha,string $context): string {
        if(!preg_match('/^[a-f0-9]{64}$/',$sha)||$b64===''||!function_exists('gzinflate'))throw new RuntimeException($context.'_PACKED_STORAGE_INVALID');
        $binary=base64_decode($b64,true);if(!is_string($binary))throw new RuntimeException($context.'_BASE64_INVALID');
        $json=@gzinflate($binary);if(!is_string($json)||$json===''||!hash_equals($sha,hash('sha256',$json)))throw new RuntimeException($context.'_HASH_MISMATCH');return $json;
    }

    private static function json($value,string $context): string {
        $j=function_exists('wp_json_encode')?wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
        if(!is_string($j))throw new RuntimeException($context.'_ENCODE_FAILED');return $j;
    }
}
