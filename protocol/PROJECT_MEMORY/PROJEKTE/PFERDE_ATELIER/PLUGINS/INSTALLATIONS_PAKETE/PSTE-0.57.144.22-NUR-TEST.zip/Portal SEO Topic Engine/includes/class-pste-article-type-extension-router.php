<?php
if (!defined('ABSPATH')) { return; }

/**
 * Generic read-only router for signed additive article-type extensions.
 * A core miss is only the point at which extensions may be asked; it is never evidence.
 */
final class PSTE_Article_Type_Extension_Router {
    public const CONTRACT='PSTE_ARTICLE_TYPE_EXTENSION_ROUTE_V1';

    /** @return array<string,mixed> */
    public static function evaluateAfterCoreMiss(string $raw,array $baseline,array $registry,array $relevance,array $seoEvidence=[],string $provenFamilyName=''): array {
        $base=['contract'=>self::CONTRACT,'status'=>'NOT_APPLICABLE','ok'=>false,'article_type'=>'','raw_query'=>self::clean($raw),'reason_codes'=>[],
            'target_category'=>[],'canonical_plan_category_slug'=>'','family_key'=>'','family_name'=>'','normalization'=>[],'intent_profile'=>[],
            'semantic_consensus'=>[],'title_pipeline'=>[],'title'=>'','target_keyword'=>'','domain_risk'=>[],'runtime_category_resolution'=>[],
            'extension_evidence'=>[],'manifest_sha256'=>'','plan_slot'=>'','plan_item_key'=>'','five_field_handoff_created'=>false,
            'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'write_attempted'=>false];
        if($base['raw_query']===''||empty($relevance['ok']))return self::withReasons($base,'NOT_APPLICABLE',['PSTE_EXTENSION_ROUTER_RELEVANCE_REQUIRED']);
        $verified=PSTE_Article_Type_Extension_Registry::verifiedManifest();if(empty($verified['ok']))return self::withReasons($base,'REVIEW_REQUIRED',(array)($verified['reason_codes']??['PSTE_EXTENSION_MANIFEST_NOT_VERIFIED']));
        $base['manifest_sha256']=(string)($verified['manifest_sha256']??'');
        $matches=[];$reviews=[];
        foreach((array)($verified['manifest']['extensions']??[]) as $id=>$ext){
            $type=(string)($ext['display_name']??$ext['article_type_id']??$id);
            $proof=PSTE_Article_Type_Extension_Registry::verifyEligibility($type,$base['raw_query'],$seoEvidence);
            if(empty($proof['ok']))continue;
            $route=self::routeOne($type,(array)$ext,$base['raw_query'],$registry,$proof,$provenFamilyName,(array)($seoEvidence['title_candidate_evidence']??[]));
            if(!empty($route['ok']))$matches[]=$route;elseif(($route['status']??'')!=='NOT_APPLICABLE')$reviews[]=$route;
        }
        if(count($matches)>1)return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_EXTENSION_ROUTER_AMBIGUOUS_MULTIPLE_EXTENSION_MATCHES']);
        if(count($matches)===1)return $matches[0];
        if($reviews){$r=$reviews[0];$r['reason_codes']=array_values(array_unique(array_merge(['PSTE_EXTENSION_ROUTER_PROVEN_EXTENSION_REQUIRES_REVIEW'],(array)($r['reason_codes']??[]))));return $r;}
        return self::withReasons($base,'NOT_APPLICABLE',['PSTE_EXTENSION_ROUTER_NO_EXPLICIT_EXTENSION_EVIDENCE']);
    }

    /** Already-validated category/intent route. This is NOT an external approval. */
    public static function fromClassifiedJournal(array $classified,string $raw): array {
        $base=['contract'=>self::CONTRACT,'status'=>'REVIEW_REQUIRED','ok'=>false,'article_type'=>'Journal','raw_query'=>$raw,
            'reason_codes'=>[],'target_category'=>[],'canonical_plan_category_slug'=>'','family_key'=>'','family_name'=>'',
            'normalization'=>[],'intent_profile'=>[],'semantic_consensus'=>[],'title_pipeline'=>[],'title'=>'','target_keyword'=>'',
            'domain_risk'=>[],'extension_evidence'=>[],'manifest_sha256'=>'','plan_slot'=>'','plan_item_key'=>'',
            'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'write_attempted'=>false];
        $verified=PSTE_Article_Type_Extension_Registry::verifiedManifest();
        if(empty($verified['ok']))return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_EXTENSION_MANIFEST_NOT_VERIFIED']);
        $ext=PSTE_Article_Type_Extension_Registry::extension('Journal');
        if(($verified['manifest']['selection_policy']??'')!=='UNIFIED_CATEGORY_INTENT_ROUTING_V1'
            ||($ext['activation_policy']??'')!=='SIGNED_CATEGORY_INTENT_OR_GOLD_V1')
            return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_UNIFIED_JOURNAL_POLICY_NOT_SIGNED']);
        $target=(array)($classified['target_category']??[]);
        $slug=(string)($target['slug']??'');
        $spec=PSTE_Article_Type_Extension_Registry::categoryBySlug($ext,$slug);
        $classification=(array)($classified['reason_codes']??[]);
        if(($classified['status']??'')!=='JOURNAL_AUTO_PASS'||empty($classified['ok'])
            ||!in_array('PSTE_JOURNAL_AUTO_HIGH_CONFIDENCE_PASS',$classification,true)
            ||!$spec||empty($target['ok'])||(int)($target['term_id']??0)<=0
            ||empty($classified['domain_risk']['ok'])||empty($classified['title_pipeline']['ok'])
            ||empty($classified['intent_profile']['ok'])||empty($classified['semantic_consensus']['ok'])
            ||(string)($classified['article_type']??'')!=='Journal'
            ||!hash_equals((string)($classified['raw_query']??''),$raw))
            return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_JOURNAL_CATEGORY_INTENT_NOT_VERIFIED']);
        $title=trim((string)($classified['title']??''));$kw=trim((string)($classified['target_keyword']??''));
        if($title===''||$kw==='')return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_JOURNAL_VERIFIED_TITLE_KEYWORD_MISSING']);
        $mode='SIGNED_CATEGORY_INTENT_ROUTING';
        if(!in_array($mode,(array)($ext['evidence_policy']['allowed_authority_modes']??[]),true))
            return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_JOURNAL_CATEGORY_INTENT_MODE_NOT_SIGNED']);
        $proof=['contract'=>PSTE_Article_Type_Extension_Registry::EVIDENCE_CONTRACT,'ok'=>true,'status'=>'PROVEN',
            'article_type'=>'Journal','scope_status'=>'PROVEN','intent_status'=>'PROVEN','authority_mode'=>$mode,
            'evidence_authority'=>PSTE_Journal_Semantic_Router::CONTRACT,
            'raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),
            'category_slug'=>$slug,'canonical_plan_category_slug'=>(string)$spec['canonical_plan_slug'],
            'category_id'=>(int)$target['term_id'],'category_name'=>(string)$target['name'],
            'title'=>$title,'target_keyword'=>$kw,'plan_slot'=>'','plan_item_key'=>'',
            'manifest_sha256'=>(string)$verified['manifest_sha256'],
            'classification_contract'=>PSTE_Journal_Semantic_Router::CONTRACT,
            'classification_status'=>'HIGH_CONFIDENCE_JOURNAL',
            'reason_codes'=>['PSTE_JOURNAL_SIGNED_CATEGORY_INTENT_PASS'],'write_attempted'=>false];
        $proof['evidence_sha256']=hash('sha256',self::stable($proof));
        $category=$target;$familyKey=(string)($classified['family_key']??'');$familyName=(string)($classified['family_name']??'');
        if($familyKey===''||$familyName==='')return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_JOURNAL_FAMILY_CONTEXT_MISSING']);
        $semantic=['contract'=>'PSTE_ARTICLE_TYPE_EXTENSION_CONSENSUS_V1','status'=>'CONSENSUS_PASS','ok'=>true,
            'type_consensus'=>true,'category_consensus'=>true,'family_consensus'=>true,
            'resolved_article_type'=>'Journal','resolved_category'=>$category,
            'extension_family_key'=>$familyKey,'extension_family_name'=>$familyName,
            'canonical_plan_category_slug'=>(string)$spec['canonical_plan_slug'],
            'selection_policy'=>(string)$ext['activation_policy'],
            'extension_evidence_sha256'=>hash('sha256',self::stable($proof)),
            'other_article_type_routing_consumed'=>false,'write_attempted'=>false,
            'reason_codes'=>['PSTE_JOURNAL_SIGNED_CATEGORY_INTENT_CONSENSUS_PASS']];
        foreach(['target_category'=>$category,'canonical_plan_category_slug'=>(string)$spec['canonical_plan_slug'],
            'family_key'=>$familyKey,'family_name'=>$familyName,'normalization'=>(array)$classified['normalization'],
            'intent_profile'=>(array)$classified['intent_profile'],'semantic_consensus'=>$semantic,
            'title_pipeline'=>(array)$classified['title_pipeline'],'title'=>$title,'target_keyword'=>$kw,
            'domain_risk'=>(array)$classified['domain_risk'],'extension_evidence'=>$proof,
            'manifest_sha256'=>(string)$verified['manifest_sha256']] as $k=>$value)$base[$k]=$value;
        $base['ok']=true;$base['status']='EXTENSION_ROUTE_PASS';
        $base['reason_codes']=['PSTE_JOURNAL_SIGNED_CATEGORY_INTENT_ROUTE_PASS'];
        return $base;
    }

    /** @return array<string,mixed> */
    private static function routeOne(string $type,array $ext,string $raw,array $registry,array $proof,string $provenFamilyName='',array $languageEvidence=[]): array {
        $base=['contract'=>self::CONTRACT,'status'=>'REVIEW_REQUIRED','ok'=>false,'article_type'=>$type,'raw_query'=>$raw,'reason_codes'=>[],
            'target_category'=>[],'canonical_plan_category_slug'=>'','family_key'=>'','family_name'=>'','normalization'=>[],'intent_profile'=>[],
            'semantic_consensus'=>[],'title_pipeline'=>[],'title'=>'','target_keyword'=>'','domain_risk'=>[],'runtime_category_resolution'=>[],
            'extension_evidence'=>$proof,'manifest_sha256'=>(string)($proof['manifest_sha256']??''),'plan_slot'=>(string)($proof['plan_slot']??''),'plan_item_key'=>(string)($proof['plan_item_key']??''),
            'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'write_attempted'=>false];
        $risk=PSTE_Domain_Risk_Gate::evaluate($raw,$type);$base['domain_risk']=$risk;if(empty($risk['ok']))return self::withReasons($base,'REVIEW_REQUIRED',array_merge(['PSTE_EXTENSION_ROUTER_DOMAIN_RISK_REVIEW'],(array)($risk['reason_codes']??[])));
        $categorySpec=PSTE_Article_Type_Extension_Registry::categoryBySlug($ext,(string)($proof['category_slug']??''));if(!$categorySpec)return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_EXTENSION_ROUTER_SIGNED_CATEGORY_BINDING_MISSING']);
        $familyName=$provenFamilyName!==''?trim($provenFamilyName):trim((string)($ext['scope_family_name']??'Pferde'));$familyKey=hash('sha256','PSTE_EXTENSION_EXPLICIT_SCOPE_V1|'.self::norm($type).'|'.PSTE_Normalizer::exactTopicIdentityText($raw));
        $normalization=['contract'=>'PSTE_EDITORIAL_TOPIC_NORMALIZER_V2','raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),'family'=>$familyName,'normalized_topic'=>rtrim($raw," ?\t\n\r\0\x0B"),'subject_topic'=>$familyName,'semantic_probe'=>PSTE_Editorial_Topic_Normalizer::semanticProbe($raw),'qualifier'=>'','relation'=>'','detected_action'=>'','intent_signals'=>[],'status'=>'PASS','reason_codes'=>['PSTE_EXTENSION_EXPLICIT_SCOPE_MEANING_PRESERVED'],'review_flags'=>[],'raw_query_modified'=>false,'write_attempted'=>false];
        $intent=self::intentFromProof($raw,$proof,$type);$title=trim((string)($proof['title']??''));$keyword=trim((string)($proof['target_keyword']??''));if($title===''||$keyword==='')return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_EXTENSION_ROUTER_EXPLICIT_TITLE_AND_KEYWORD_REQUIRED']);
        $pipeline=PSTE_Title_Pipeline::validateExistingTitle($title,$raw,$familyName,$type,$registry,$intent,$keyword,(string)$normalization['normalized_topic'],[],$languageEvidence);$base['title_pipeline']=$pipeline;$base['title']=(string)($pipeline['title']??'');$base['target_keyword']=(string)($pipeline['target_keyword']??'');if(empty($pipeline['ok']))return self::withReasons($base,'REVIEW_REQUIRED',array_merge(['PSTE_EXTENSION_ROUTER_EXISTING_TITLE_RULES_NOT_PASS'],self::pipelineReasons($pipeline)));
        // Existing signed title gate completes BEFORE a category can be missing.
        $resolved=self::resolveRuntimeCategory($categorySpec);$base['runtime_category_resolution']=$resolved;
        if(empty($resolved['ok'])){
            if(($resolved['status']??'')==='NOT_FOUND'){
                $base['family_key']=$familyKey;$base['family_name']=$familyName;
                $base['normalization']=$normalization;$base['intent_profile']=$intent;
                $base['canonical_plan_category_slug']=(string)($categorySpec['canonical_plan_slug']??'');
                $base['missing_category_name']=(string)($categorySpec['name']??'');
                return self::withReasons($base,'CATEGORY_UNAVAILABLE_TITLE_PASS',['PSTE_EXTENSION_SIGNED_TITLE_PASS_CATEGORY_NOT_FOUND']);
            }
            return self::withReasons($base,'CATEGORY_UNAVAILABLE',array_merge(['PSTE_EXTENSION_ROUTER_RUNTIME_CATEGORY_NOT_CONFIRMED'],(array)($resolved['reason_codes']??[])));
        }
        $target=['ok'=>true,'term_id'=>(int)$resolved['term_id'],'name'=>(string)$resolved['name'],'slug'=>(string)$resolved['slug'],'taxonomy'=>'category','article_type'=>$type,'article_type_extension'=>true];
        $semantic=['contract'=>'PSTE_ARTICLE_TYPE_EXTENSION_CONSENSUS_V1','status'=>'CONSENSUS_PASS','ok'=>true,'type_consensus'=>true,'category_consensus'=>true,'family_consensus'=>true,'resolved_article_type'=>$type,'resolved_category'=>$target,'extension_family_key'=>$familyKey,'extension_family_name'=>$familyName,'canonical_plan_category_slug'=>(string)($categorySpec['canonical_plan_slug']??''),'selection_policy'=>(string)($ext['activation_policy']??''),'extension_evidence_sha256'=>hash('sha256',self::stable($proof)),'other_article_type_routing_consumed'=>false,'write_attempted'=>false,'reason_codes'=>['PSTE_EXTENSION_EXPLICIT_SCOPE_CONSENSUS_PASS']];
        $base['target_category']=$target;$base['canonical_plan_category_slug']=(string)($categorySpec['canonical_plan_slug']??'');$base['family_key']=$familyKey;$base['family_name']=$familyName;$base['normalization']=$normalization;$base['intent_profile']=$intent;$base['semantic_consensus']=$semantic;$base['ok']=true;$base['status']='EXTENSION_ROUTE_PASS';$base['reason_codes']=['PSTE_EXTENSION_ROUTER_EXPLICIT_EVIDENCE_PASS'];return $base;
    }

    /** @return array<string,mixed> */
    private static function resolveRuntimeCategory(array $spec): array {
        if(!function_exists('get_term_by'))return ['ok'=>false,'status'=>'WORDPRESS_TERM_API_UNAVAILABLE','reason_codes'=>['PSTE_EXTENSION_ROUTER_TERM_API_UNAVAILABLE'],'term_id'=>0,'name'=>'','slug'=>''];
        $matches=[];foreach((array)($spec['runtime_slugs']??[]) as $slug){$term=get_term_by('slug',(string)$slug,'category');if(!$term||(function_exists('is_wp_error')&&is_wp_error($term)))continue;$id=(int)($term->term_id??0);$actual=trim((string)($term->slug??''));if($id>0&&$actual!=='')$matches[$id]=['term_id'=>$id,'name'=>trim((string)($term->name??'')),'slug'=>$actual,'taxonomy'=>(string)($term->taxonomy??'category'),'parent'=>(int)($term->parent??0)];}
        if(count($matches)!==1)return ['ok'=>false,'status'=>count($matches)>1?'AMBIGUOUS':'NOT_FOUND','reason_codes'=>[count($matches)>1?'PSTE_EXTENSION_ROUTER_CATEGORY_AMBIGUOUS':'PSTE_EXTENSION_ROUTER_CATEGORY_NOT_FOUND'],'term_id'=>0,'name'=>'','slug'=>''];
        $m=array_values($matches)[0];if((string)$m['taxonomy']!=='category')return ['ok'=>false,'status'=>'TAXONOMY_MISMATCH','reason_codes'=>['PSTE_EXTENSION_ROUTER_CATEGORY_TAXONOMY_MISMATCH'],'term_id'=>0,'name'=>'','slug'=>''];return ['ok'=>true,'status'=>'RESOLVED','reason_codes'=>['PSTE_EXTENSION_ROUTER_CATEGORY_RUNTIME_CONFIRMED']]+$m;
    }
    private static function intentFromProof(string $raw,array $proof,string $type): array {$p=['contract'=>'PSTE_INTENT_PROFILE_V4_EVIDENCE_BOUND','ok'=>true,'status'=>'PASS','search_intent'=>'EDITORIAL_INFORMATION','primary_user_goal'=>'EDITORIAL_INFORMATION','primary_article_type_candidate'=>$type,'intent_angle'=>'EXPLICIT_ARTICLE_TYPE_EXTENSION_SCOPE','evidence_authority'=>(string)($proof['authority_mode']??''),'scope_status'=>(string)($proof['scope_status']??''),'intent_status'=>(string)($proof['intent_status']??''),'raw_query_sha256'=>hash('sha256',$raw),'write_attempted'=>false];$p['profile_sha256']=hash('sha256',self::stable($p));return $p;}
    private static function withReasons(array $base,string $status,array $r): array {$base['status']=$status;$base['ok']=$status==='EXTENSION_ROUTE_PASS';$base['reason_codes']=array_values(array_unique(array_filter(array_map('strval',$r))));return $base;}
    private static function pipelineReasons(array $p): array {return array_values(array_unique(array_filter(array_merge((array)($p['deterministic']['reason_codes']??[]),(array)($p['language']['reason_codes']??[]),(array)($p['editorial_quality']['reason_codes']??[])))));}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');return trim((string)preg_replace('/\s+/u',' ',$v));}
    private static function norm(string $v): string {$v=function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);$v=strtr($v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);return trim((string)preg_replace('/[^a-z0-9]+/u','',$v));}
    private static function stable($v): string {$v=self::canon($v);$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($j)?$j:'';}
    private static function canon($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canon'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canon($x);return $v;}
}
