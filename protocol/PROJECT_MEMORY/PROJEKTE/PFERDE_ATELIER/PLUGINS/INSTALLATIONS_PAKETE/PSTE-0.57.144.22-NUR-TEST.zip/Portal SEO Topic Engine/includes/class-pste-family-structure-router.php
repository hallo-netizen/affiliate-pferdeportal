<?php
if (!defined('ABSPATH')) { return; }

/**
 * Read-only C-lane router for portal-relevant queries with no current family.
 *
 * A true NO_MATCH without any meaningful nearest existing family is not an
 * arbitrary matcher problem: under the active target contract it is a
 * structure decision. This router records that state generically for current
 * and future queries. It never assigns a family, never creates taxonomy and
 * never grants production authority.
 */
final class PSTE_Family_Structure_Router {
    public const CONTRACT='PSTE_FAMILY_STRUCTURE_ROUTER_V2';

    /** @return array<string,mixed> */
    public static function evaluate(string $raw,array $baseline,array $registry,array $familyResolution=[],array $relevance=[]): array {
        $raw=self::clean($raw);$status=(string)($familyResolution['status']??'');$diag=(array)($familyResolution['rejection_diagnostics']??[]);
        $base=[
            'contract'=>self::CONTRACT,'status'=>'REVIEW_REQUIRED','ok'=>false,'raw_query'=>$raw,
            'family_resolution_status'=>$status,
            'nearest_existing_family_count'=>(int)($diag['nearest_rejected_family_count']??0),
            'core_plausible_existing_family_count'=>(int)($diag['core_plausible_missing_discriminator_count']??0),
            'topic_surface'=>'','structural_context_hint'=>[],
            'reason_codes'=>[],'production_authority'=>false,'taxonomy_write_attempted'=>false,'write_attempted'=>false,
        ];
        if($raw==='')return self::finish($base,'REVIEW_REQUIRED',['PSTE_FAMILY_STRUCTURE_RAW_QUERY_MISSING']);
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return self::finish($base,'REVIEW_REQUIRED',['PSTE_FAMILY_STRUCTURE_BASELINE_INVALID']);
        if(empty($relevance['ok']))return self::finish($base,'REVIEW_REQUIRED',['PSTE_FAMILY_STRUCTURE_PORTAL_RELEVANCE_NOT_PROVEN']);
        if($status==='MATCH')return self::finish($base,'NO_MATCH',['PSTE_FAMILY_STRUCTURE_EXISTING_FAMILY_ALREADY_MATCHED']);

        $probe=PSTE_Editorial_Topic_Normalizer::semanticProbe($raw);if($probe==='')$probe=$raw;$base['topic_surface']=$probe;

        // Existing-family ambiguity remains a matcher/review problem. Never turn it into a new-family proposal.
        if($status==='REVIEW_REQUIRED'||$base['nearest_existing_family_count']>0||$base['core_plausible_existing_family_count']>0){
            return self::finish($base,'REVIEW_REQUIRED',['PSTE_FAMILY_STRUCTURE_EXISTING_FAMILY_REVIEW_REQUIRED']);
        }
        if($status!=='NO_MATCH')return self::finish($base,'REVIEW_REQUIRED',['PSTE_FAMILY_STRUCTURE_RESOLUTION_STATE_UNSUPPORTED']);

        // No existing family even reached meaningful subject-stage evidence. This is the
        // generic, future-safe definition of a structure gap after portal relevance PASS.
        $base['structural_context_hint']=self::bestBranchHint($probe,$baseline,$registry);
        $base['ok']=true;$base['status']='STRUCTURE_GAP';
        $base['reason_codes']=['PSTE_FAMILY_STRUCTURE_NO_EXISTING_FAMILY_SEMANTIC_NEIGHBOUR','PSTE_STRUCTURE_DECISION_REQUIRED_BEFORE_NORMAL_REENTRY'];
        return $base;
    }

    /** @return array<string,mixed> */
    private static function bestBranchHint(string $probe,array $baseline,array $registry): array {
        $queryTokens=PSTE_Family_Identity_V2::tokens($probe,false);if(!$queryTokens)return [];$matches=[];
        foreach(self::branchIndex($baseline,$registry) as $row){
            if((int)$row['depth']<2||(int)$row['descendant_family_count']<2)continue;
            $pageTokens=(array)$row['match_tokens'];if(!$pageTokens)continue;$ok=true;$matched=[];
            foreach($pageTokens as $term){$hit=false;foreach($queryTokens as $token){if(self::componentMatch((string)$token,(string)$term)){$hit=true;$matched[]=$term;break;}}if(!$hit){$ok=false;break;}}
            if(!$ok)continue;$score=count($pageTokens)*100+(int)$row['depth']*10+min(9,strlen((string)$row['name']));
            $matches[]=array_merge($row,['matched_tokens'=>array_values(array_unique($matched)),'specificity_score'=>$score]);
        }
        if(!$matches)return [];
        usort($matches,static fn($a,$b)=>[(int)$b['specificity_score'],(string)$a['slug'],(int)$a['id']]<=>[(int)$a['specificity_score'],(string)$b['slug'],(int)$b['id']]);
        $top=(int)$matches[0]['specificity_score'];$tops=array_values(array_filter($matches,static fn($m)=>(int)$m['specificity_score']===$top));
        if(count($tops)!==1)return ['status'=>'AMBIGUOUS','candidate_count'=>count($tops),'production_authority'=>false];
        $w=$tops[0];return ['status'=>'HINT_ONLY','page_id'=>(int)$w['id'],'page_name'=>(string)$w['name'],'page_slug'=>(string)$w['slug'],'path'=>(array)$w['path'],'matched_tokens'=>(array)$w['matched_tokens'],'descendant_family_count'=>(int)$w['descendant_family_count'],'production_authority'=>false];
    }

    /** @return list<array<string,mixed>> */
    private static function branchIndex(array $baseline,array $registry): array {
        $pages=[];foreach((array)($baseline['leaf_categories']??[]) as $leaf){if(!is_array($leaf))continue;$familyKey=trim((string)($leaf['topic_family_key']??''));if($familyKey==='')continue;$path=[];foreach((array)($leaf['portal_path_nodes']??[]) as $node){if(!is_array($node)||(string)($node['node_type']??'')!=='page')continue;$id=(int)($node['object_id']??0);$name=self::clean((string)($node['name']??''));$slug=self::clean((string)($node['slug']??''));if($id<=0||$name===''||$slug==='')continue;$path[]=['id'=>$id,'name'=>$name,'slug'=>$slug];$key=(string)$id;if(!isset($pages[$key]))$pages[$key]=['id'=>$id,'name'=>$name,'slug'=>$slug,'depth'=>count($path),'path'=>$path,'family_keys'=>[]];$pages[$key]['family_keys'][$familyKey]=true;}}
        $out=[];foreach($pages as $row){$tokens=self::meaningfulPageTokens((string)$row['name']);if(!$tokens)continue;$keys=array_keys((array)$row['family_keys']);sort($keys,SORT_STRING);$out[]=['id'=>(int)$row['id'],'name'=>(string)$row['name'],'slug'=>(string)$row['slug'],'depth'=>(int)$row['depth'],'path'=>(array)$row['path'],'match_tokens'=>$tokens,'descendant_family_count'=>count($keys),'descendant_family_keys'=>$keys];}return $out;
    }
    /** @return list<string> */
    private static function meaningfulPageTokens(string $name): array {$out=[];foreach(PSTE_Family_Identity_V2::tokens($name,false) as $token){$token=(string)$token;if(strlen($token)>=4)$out[$token]=true;}return array_keys($out);}
    private static function componentMatch(string $token,string $term): bool {if($token===$term)return true;if(strlen($term)<4||strlen($token)<4)return false;if(str_starts_with($token,$term)||str_ends_with($token,$term))return true;foreach(['t','st'] as $suffix)if(str_ends_with($token,$suffix)&&substr($token,0,-strlen($suffix))===$term)return true;return false;}
    /** @param list<string> $reasons @return array<string,mixed> */
    private static function finish(array $base,string $status,array $reasons): array {$base['status']=$status;$base['ok']=$status==='STRUCTURE_GAP';$base['reason_codes']=array_values(array_unique($reasons));return $base;}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');return trim((string)preg_replace('/\s+/u',' ',$v));}
}
