<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Analytics {
    private const ADMIN_BATCH=100;
    private const ADMIN_VIEW_LIMIT=500;

    /** @return iterable<int,array<string,mixed>> */
    private static function candidateStream(): iterable {
        $cursor=null;
        do{
            $page=PSTE_Repository::adminTopicPoolPage($cursor,self::ADMIN_BATCH);
            foreach((array)($page['items']??[]) as $candidate)if(is_array($candidate))yield $candidate;
            $cursor=is_array($page['next_cursor']??null)?$page['next_cursor']:null;
        }while(empty($page['complete'])&&is_array($cursor));
    }

    /** @return iterable<int,array<string,mixed>> */
    private static function inventoryStream(): iterable {
        $cursor=null;$structure=PSTE_Snapshot::structure();
        do{
            $page=PSTE_Snapshot::compilerInventoryPage($cursor,25,$structure);
            foreach((array)($page['items']??[]) as $item)if(is_array($item))yield $item;
            $cursor=is_array($page['next_cursor']??null)?$page['next_cursor']:null;
        }while(empty($page['complete'])&&is_array($cursor));
    }

    /**
     * Bounded admin excerpt. Never materializes the complete portal or topic relation domain.
     * The admin page labels this explicitly as a bounded view.
     */
    public static function topicRows(int $perSourceLimit=self::ADMIN_VIEW_LIMIT): array {
        $perSourceLimit=max(1,min(self::ADMIN_VIEW_LIMIT,$perSourceLimit));$rows=[];$seen=0;
        foreach(self::inventoryStream() as $item){if(!in_array((string)($item['status']??''),['publish','draft'],true))continue;$rows[]=[
            'source'=>'WORDPRESS','category_id'=>(int)($item['category_id']??0),'category_name'=>(string)($item['category_name']??''),'topic'=>(string)($item['title']??''),
            'article_type'=>trim((string)($item['article_type']??''))!==''?(string)$item['article_type']:self::articleTypeFromCategory((string)($item['category_name']??'')),'intent'=>null,'status'=>strtoupper((string)($item['status']??'')),
            'search_volume'=>null,'priority'=>null,'canonical_article_id'=>(string)($item['canonical_article_id']??''),'post_id'=>(int)($item['post_id']??0),
        ];if(++$seen>=$perSourceLimit)break;}
        $seen=0;foreach(self::candidateStream() as $c){if(!empty($c['discovery_only'])||(string)($c['planning_suitability']??'NO')==='NO')continue;$rows[]=[
            'source'=>'PSTE','category_id'=>(int)($c['target_category_id']??0),'category_name'=>(string)($c['target_category_name']??''),'topic'=>PSTE_Editorializer::displayTitle($c),
            'article_type'=>(string)($c['proposed_article_type']??''),'intent'=>(string)($c['metrics']['search_intent']??''),'status'=>(string)($c['pool_status']??$c['decision']??'REVIEW_REQUIRED'),
            'search_volume'=>$c['metrics']['search_volume']??null,'priority'=>null,'canonical_article_id'=>'','post_id'=>0,'candidate_id'=>(string)($c['candidate_id']??''),
        ];if(++$seen>=$perSourceLimit)break;}
        usort($rows,static fn($a,$b)=>[$a['category_name'],$a['source'],$a['topic']]<=>[$b['category_name'],$b['source'],$b['topic']]);return $rows;
    }

    /** Bounded admin excerpt. */
    public static function keywordRows(int $limit=self::ADMIN_VIEW_LIMIT): array {
        $limit=max(1,min(self::ADMIN_VIEW_LIMIT,$limit));$rows=[];
        foreach(PSTE_Repository::adminTopicPoolCandidates('all','',$limit) as $c){$sources=[];foreach(($c['evidence']??[]) as $e){$s=(string)($e['source']??'');if($s!=='')$sources[$s]=true;}$rows[]=[
            'category_name'=>(string)($c['target_category_name']??''),'keyword'=>PSTE_Editorializer::displayTitle($c),'raw_question'=>(string)($c['raw_user_question']??''),
            'intent'=>(string)($c['metrics']['search_intent']??''),'intent_probability'=>$c['metrics']['intent_probability']??null,'search_volume'=>$c['metrics']['search_volume']??null,
            'decision'=>(string)($c['decision']??'REVIEW_REQUIRED'),'pool_status'=>(string)($c['pool_status']??$c['decision']??'REVIEW_REQUIRED'),'article_type'=>(string)($c['proposed_article_type']??''),'sources'=>array_keys($sources),'candidate'=>$c,
        ];}usort($rows,static fn($a,$b)=>[$a['category_name'],$a['keyword']]<=>[$b['category_name'],$b['keyword']]);return $rows;
    }

    /** Exact portal-wide coverage computed from bounded streams. */
    public static function coverage(): array {
        $unused=[];
        return self::coverageWithArticleCounts($unused);
    }

    /** Reuse the existing bounded inventory and plan scans; never change the published coverage contract. */
    private static function coverageWithArticleCounts(array &$articleCounts): array {
        $articleCounts=[];
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$leaf=is_array($baseline)?($baseline['leaf_categories']??[]):[];$categoryToFamily=[];$families=[];
        foreach($leaf as $cat){$id=(int)($cat['term_id']??0);$key=(string)($cat['topic_family_key']??PSTE_Normalizer::categoryFamilyKey((string)($cat['name']??'')));if($id<=0||$key==='')continue;$categoryToFamily[$id]=$key;if(!isset($families[$key]))$families[$key]=['topic_family_key'=>$key,'topic_family_name'=>(string)($cat['topic_family_name']??PSTE_Normalizer::categoryFamilyName((string)($cat['name']??''))),'category_ids'=>[]];$families[$key]['category_ids'][]=$id;}
        $actual=[];foreach(self::inventoryStream() as $item){
            $status=(string)($item['status']??'');$categoryId=(int)($item['category_id']??0);
            if($categoryId>0&&in_array($status,['publish','draft'],true))$articleCounts[$categoryId]=($articleCounts[$categoryId]??0)+1;
            if($status!=='publish')continue;$key=(string)($item['topic_family_key']??'');if($key==='')$key=$categoryToFamily[$categoryId]??'';if($key!=='')$actual[$key]=($actual[$key]??0)+1;
        }
        $planned=[];$volumes=[];foreach(self::candidateStream() as $c){
            if(!empty($c['discovery_only']))continue;
            $planning=(string)($c['planning_suitability']??'NO');$categoryId=(int)($c['target_category_id']??0);
            if($categoryId>0&&in_array($planning,['YES','PROVISIONAL'],true))$articleCounts[$categoryId]=($articleCounts[$categoryId]??0)+1;
            $key=(string)($c['topic_family_key']??PSTE_Normalizer::categoryFamilyKey((string)($c['target_category_name']??'')));if($key==='')continue;
            if(in_array($planning,['YES','PROVISIONAL'],true))$planned[$key]=($planned[$key]??0)+1;
            $v=max(0,(int)($c['metrics']['search_volume']??0));$volumes[$key]=($volumes[$key]??0)+$v;
        }
        $gsc=PSTE_Repository::gscCategorySummary((string)get_option(PSTE_OPTION_GSC_SELECTED_PROPERTY,''));$gscFamily=[];foreach($gsc as $categoryId=>$row){$key=$categoryToFamily[(int)$categoryId]??'';if($key==='')continue;if(!isset($gscFamily[$key]))$gscFamily[$key]=['impressions'=>0.0,'clicks'=>0.0];$gscFamily[$key]['impressions']+=(float)($row['impressions']??0);$gscFamily[$key]['clicks']+=(float)($row['clicks']??0);}
        $totalImpressions=0.0;$totalVolume=0.0;foreach($families as $key=>$family){$totalImpressions+=(float)($gscFamily[$key]['impressions']??0);$totalVolume+=(float)($volumes[$key]??0);}
        $totalActual=max(1,array_sum($actual));$rows=[];
        foreach($families as $key=>$family){$imp=(float)($gscFamily[$key]['impressions']??0);$vol=(float)($volumes[$key]??0);$hasGsc=$totalImpressions>0&&$imp>0;$hasVolume=$totalVolume>0&&$vol>0;$gscShare=$totalImpressions>0?$imp/$totalImpressions:0.0;$volumeShare=$totalVolume>0?$vol/$totalVolume:0.0;
            if($hasGsc&&$hasVolume)$demandShare=($gscShare*0.60)+($volumeShare*0.40);elseif($hasGsc)$demandShare=$gscShare;elseif($hasVolume)$demandShare=$volumeShare;else $demandShare=0.0;
            $hasData=$hasGsc||$hasVolume;$actualShare=($actual[$key]??0)/$totalActual;$expected=$hasData?max(0.5,$demandShare*$totalActual):null;$coverage=$expected!==null?round((($actual[$key]??0)/$expected)*100,1):null;$state=self::coverageState($coverage);$representative=(int)($family['category_ids'][0]??0);
            $rows[]=['category_id'=>$representative,'category_ids'=>$family['category_ids'],'category_name'=>$family['topic_family_name'],'category_slug'=>$key,'topic_family_key'=>$key,'published'=>(int)($actual[$key]??0),'planned_pass'=>(int)($planned[$key]??0),'gsc_impressions'=>$imp,'gsc_clicks'=>(float)($gscFamily[$key]['clicks']??0),'candidate_volume'=>$vol,'demand_share_pct'=>round($demandShare*100,2),'content_share_pct'=>round($actualShare*100,2),'expected_articles'=>$expected!==null?round($expected,2):null,'coverage_pct'=>$coverage,'state'=>$state,'strategic_weight'=>self::strategicWeight($representative)];
        }
        usort($rows,static function($a,$b){$rank=['UNDERREPRESENTED'=>0,'DATA_INSUFFICIENT'=>1,'BALANCED'=>2,'OVERREPRESENTED'=>3];return [$rank[$a['state']]??9,$a['coverage_pct']??999,$a['category_name']]<=>[$rank[$b['state']]??9,$b['coverage_pct']??999,$b['category_name']];});return $rows;
    }

    /** Exact scoring, bounded input stream; result list itself is capped for admin rendering. */
    public static function priorities(int $limit=self::ADMIN_VIEW_LIMIT): array {
        $limit=max(1,min(self::ADMIN_VIEW_LIMIT,$limit));$articleCounts=[];$coverageBy=[];foreach(self::coverageWithArticleCounts($articleCounts) as $row)$coverageBy[(string)$row['topic_family_key']]=$row;$rows=[];
        // Only break identical SEO-priority scores; no quota, type reassignment or fabricated query.
        $compare=static fn($a,$b)=>[$b['priority_score'],$a['_article_count'],$a['topic']]<=>[$a['priority_score'],$b['_article_count'],$b['topic']];
        foreach(self::candidateStream() as $c){$planning=(string)($c['planning_suitability']??'NO');if(!in_array($planning,['YES','PROVISIONAL'],true))continue;$decision=(string)($c['pool_status']??$c['decision']??'REVIEW_REQUIRED');$categoryId=(int)($c['target_category_id']??0);$familyKey=(string)($c['topic_family_key']??PSTE_Normalizer::categoryFamilyKey((string)($c['target_category_name']??'')));$coverage=$coverageBy[$familyKey]??null;
            $gapScore=10.0;if($coverage&&$coverage['coverage_pct']!==null)$gapScore=min(30.0,max(0.0,(100.0-(float)$coverage['coverage_pct'])*0.3));
            $sources=[];foreach(($c['evidence']??[]) as $e){$s=(string)($e['source']??'');if($s!=='')$sources[$s]=true;}$demandScore=isset($sources['GSC'])?25.0:(isset($sources['PAA'])?22.0:(isset($sources['PAA_RELATED'])?15.0:8.0));
            $volume=max(0,(float)($c['metrics']['search_volume']??0));$volumeScore=$volume>0?min(15.0,(log10(1+$volume)/log10(1001))*15.0):0.0;$strategic=min(10.0,max(0.0,self::strategicWeight($categoryId)));$risk=$decision==='PASS'?10.0:3.0;$season=self::seasonalityScore($c['metrics']['monthly_searches']??[]);$readiness=self::readinessScore($c);
            $score=self::priorityScore(['coverage_gap'=>$gapScore,'real_demand'=>$demandScore,'search_volume_trend'=>$volumeScore,'strategic_category'=>$strategic,'low_cannibalization_risk'=>$risk,'seasonality'=>$season,'data_readiness'=>$readiness]);
            $rows[]=['candidate_id'=>(string)($c['candidate_id']??''),'topic'=>PSTE_Editorializer::displayTitle($c),'category_id'=>$categoryId,'category_name'=>(string)($c['target_category_name']??''),'topic_family_key'=>$familyKey,'article_type'=>(string)($c['proposed_article_type']??''),'decision'=>$decision,'planning_suitability'=>$planning,'priority_score'=>$score,'_article_count'=>$categoryId>0?($articleCounts[$categoryId]??0):PHP_INT_MAX,'components'=>['coverage_gap'=>round($gapScore,1),'real_demand'=>round($demandScore,1),'search_volume_trend'=>round($volumeScore,1),'strategic_category'=>round($strategic,1),'low_cannibalization_risk'=>round($risk,1),'seasonality'=>round($season,1),'data_readiness'=>round($readiness,1)],'search_volume'=>$volume,'intent'=>(string)($c['metrics']['search_intent']??''),'sources'=>array_keys($sources)];
            if(count($rows)>$limit*2){usort($rows,$compare);$rows=array_slice($rows,0,$limit);}
        }
        usort($rows,$compare);$rows=array_slice($rows,0,$limit);foreach($rows as &$row)unset($row['_article_count']);unset($row);return $rows;
    }

    /** Bounded display list; full count is calculated separately without retaining rows. */
    public static function conflicts(int $limit=self::ADMIN_VIEW_LIMIT): array {
        $limit=max(1,min(self::ADMIN_VIEW_LIMIT,$limit));$out=[];foreach(self::candidateStream() as $c){if(!empty($c['discovery_only']))continue;if(($c['decision']??'PASS')==='PASS')continue;$out[]=['topic'=>PSTE_Editorializer::displayTitle($c),'category_name'=>(string)($c['target_category_name']??''),'decision'=>(string)($c['decision']??''),'reason_codes'=>$c['reason_codes']??[],'matches'=>$c['closest_existing_matches']??[]];if(count($out)>=$limit)break;}return $out;
    }

    public static function summary(): array {
        $coverage=self::coverage();$counts=['UNDERREPRESENTED'=>0,'BALANCED'=>0,'OVERREPRESENTED'=>0,'DATA_INSUFFICIENT'=>0];foreach($coverage as $r)$counts[$r['state']]++;
        $stats=PSTE_Repository::adminTopicPoolStats();$priorities=self::priorities(5);$research=PSTE_Repository::researchCompleteness();global $wpdb;
        $postCount=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='post' AND post_status IN ('publish','draft')");
        $planningReady=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".PSTE_Repository::table('topic_pool')." WHERE planning_suitability='YES'");
        $conflicts=max(0,(int)($stats['TOTAL']??0)-(int)($stats['PASS']??0)-(int)($stats['APPROVED']??0)-(int)($stats['AUTO_RESOLVED']??0)-(int)($stats['DISCOVERY_ONLY']??0));
        return ['coverage_counts'=>$counts,'topic_count'=>$postCount+(int)($stats['TOTAL']??0),'priority_ready_count'=>$planningReady,'conflict_count'=>$conflicts,'top_priorities'=>$priorities,'pool_total'=>$stats['TOTAL']??0,'pool_review_required'=>$stats['REVIEW_REQUIRED']??0,'pool_occurrences'=>$stats['OCCURRENCES']??0,'pool_green'=>$stats['GREEN']??0,'pool_yellow'=>$stats['YELLOW']??0,'pool_red'=>$stats['RED']??0,'research'=>$research];
    }

    public static function saveStrategicWeights(array $input): void {
        $clean=[];foreach($input as $id=>$value){$id=(int)$id;if($id<=0)continue;$clean[$id]=min(10,max(0,(float)$value));}update_option(PSTE_OPTION_CATEGORY_WEIGHTS,$clean,false);
    }
    public static function strategicWeight(int $categoryId): float {$weights=get_option(PSTE_OPTION_CATEGORY_WEIGHTS,[]);return is_array($weights)&&isset($weights[$categoryId])?(float)$weights[$categoryId]:5.0;}

    public static function coverageState(?float $coverage): string {
        if($coverage===null)return 'DATA_INSUFFICIENT';
        $settings=PSTE_Plugin::settings();$under=(float)($settings['coverage_under_threshold']??70.0);$over=(float)($settings['coverage_over_threshold']??130.0);
        if($coverage<$under)return 'UNDERREPRESENTED';if($coverage>$over)return 'OVERREPRESENTED';return 'BALANCED';
    }

    public static function priorityScore(array $components): float {
        return round(min(100.0,max(0.0,array_sum(array_map('floatval',$components)))),1);
    }
    private static function seasonalityScore(array $monthly): float {if(count($monthly)<3)return 2.0;$values=[];foreach($monthly as $m){$v=(float)($m['search_volume']??0);if($v>=0)$values[]=$v;}if(count($values)<3)return 2.0;$latest=$values[0]??0;$avg=array_sum($values)/count($values);return $avg>0&&$latest>$avg*1.2?5.0:2.5;}
    private static function readinessScore(array $c): float {$score=0.0;if(!empty($c['metrics']['search_intent']))$score+=1.5;if(($c['metrics']['search_volume']??null)!==null)$score+=1.0;if(!empty($c['evidence']))$score+=1.0;return min(5.0,$score);}
    private static function articleTypeFromCategory(string $name): string {return PSTE_Normalizer::categoryArticleType($name);}
}
