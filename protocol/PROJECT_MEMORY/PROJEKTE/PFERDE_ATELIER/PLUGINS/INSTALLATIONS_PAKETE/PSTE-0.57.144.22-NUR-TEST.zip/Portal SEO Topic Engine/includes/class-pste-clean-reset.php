<?php
if(!defined('ABSPATH'))return;
/**
 * Explicit staging-only reset, not a new classifier or SEO gate.
 * A complete byte-preserving backup of every topic precedes all changes.
 * Context, raw evidence, approved human reviews and WordPress content are untouched.
 * After reset, the existing provider-free production path recomputes the decisions.
 */
final class PSTE_Clean_Reset {
    private const OPTION='pste_clean_decision_reset_v1';
    private const OLD_STATE='pste_clean_decision_old_state_v1';
    private const LIMIT=40;
    private const FIELDS=['automatic_decision','automatic_pool_status','topic_role','planning_suitability','context_state','current_category_id','context_synced_at'];

    public static function isTestSite(): bool {
        $host=strtolower((string)parse_url((string)home_url('/'),PHP_URL_HOST));
        return in_array($host,['oliver-beil.de','www.oliver-beil.de'],true);
    }
    private static function source(): string {return PSTE_Repository::table('topic_pool');}
    private static function backup(): string {return PSTE_Repository::table('topic_reset_backup_v1');}
    public static function status(): array {$v=get_option(self::OPTION,[]);return is_array($v)?$v:[];}

    private static function guardJobs(): void {
        if(!self::isTestSite())throw new RuntimeException('PSTE_CLEAN_RESET_STAGING_ONLY');
        if(!PSTE_Plugin::isReady())throw new RuntimeException('PSTE_CLEAN_RESET_BOOT_NOT_READY');
        $queue=PSTE_Breadth_Research_Queue::peek();
        if(is_array($queue)&&in_array((string)($queue['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))
            throw new RuntimeException('PSTE_CLEAN_RESET_AUTOMATIK_NOCH_AKTIV_ZUERST_ANHALTEN');
        $context=PSTE_Context_Refresh::status();
        if(in_array((string)($context['status']??''),['PENDING','RUNNING'],true))
            throw new RuntimeException('PSTE_CLEAN_RESET_CONTEXT_WORKER_ACTIVE');
        if(class_exists('PSERC_Plan_Snapshot_Store')){
            $p=PSERC_Plan_Snapshot_Store::getJob();
            if(in_array((string)($p['status']??''),['RUNNING','PENDING','PAUSED_ERROR'],true))
                throw new RuntimeException('PSTE_CLEAN_RESET_COMPILER_ACTIVE');
        }
        if(PSTE_Research_Job::peek()!==null)throw new RuntimeException('PSTE_CLEAN_RESET_RESEARCH_ACTIVE');
        // A clean rerun must have a proven current context source; fail BEFORE changing anything.
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_CLEAN_RESET_BASELINE_MISSING');
        if((string)($context['status']??'')!=='COMPLETE')throw new RuntimeException('PSTE_CLEAN_RESET_CONTEXT_NOT_COMPLETE');
        $binding=PSTE_Context_Index_Store::runtimeBinding($context,$baseline);
        if((string)($binding['contract']??'')!=='PSTE_CONTEXT_INDEX_RUNTIME_BINDING_V2')throw new RuntimeException('PSTE_CLEAN_RESET_BINDING_INVALID');
    }
    private static function sql(string $q,string $code): int {
        global $wpdb;$r=$wpdb->query($q);
        if($r===false)throw new RuntimeException($code.':'.substr((string)($wpdb->last_error??''),0,100));
        return (int)$r;
    }
    private static function count(string $table): int {
        global $wpdb;$n=$wpdb->get_var("SELECT COUNT(*) FROM $table");
        if($n===null&&(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_CLEAN_RESET_COUNT_FAILED');
        return (int)$n;
    }
    private static function maxId(string $table): int {
        global $wpdb;$n=$wpdb->get_var("SELECT COALESCE(MAX(id),0) FROM $table");
        if($n===null&&(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_CLEAN_RESET_MAX_ID_FAILED');
        return (int)$n;
    }
    private static function assertBackupIdentical(): void {
        global $wpdb;$src=self::source();$bak=self::backup();
        if(self::count($src)!==self::count($bak))throw new RuntimeException('PSTE_CLEAN_RESET_BACKUP_COUNT_MISMATCH');
        // One server-side comparison, no topic payload moved into PHP or browser.
        $q="SELECT COUNT(*) FROM $src p INNER JOIN $bak b ON p.id=b.id WHERE "
          ."BINARY p.payload_json <> BINARY b.payload_json OR p.pool_key <> b.pool_key "
          ."OR p.automatic_decision <> b.automatic_decision OR p.automatic_pool_status <> b.automatic_pool_status "
          ."OR p.topic_role <> b.topic_role OR p.planning_suitability <> b.planning_suitability "
          ."OR p.context_state <> b.context_state OR p.current_category_id <> b.current_category_id "
          ."OR p.manual_status <> b.manual_status OR p.last_seen_at <> b.last_seen_at";
        $different=$wpdb->get_var($q);
        if($different===null&&(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_CLEAN_RESET_BACKUP_COMPARE_READ_FAILED');
        if((int)$different!==0)throw new RuntimeException('PSTE_CLEAN_RESET_BACKUP_DIFFERENT_STOP_BEFORE_RESET');
    }
    private static function put(array $job): array {
        $job['updated_at_utc']=gmdate('c');
        update_option(self::OPTION,$job,false);
        $read=self::status();
        foreach(['phase','cursor','total','backed_up','reset_processed'] as $key)
            if(($read[$key]??null)!==($job[$key]??null))throw new RuntimeException('PSTE_CLEAN_RESET_JOB_WRITE_MISMATCH_'.$key);
        return $job;
    }
    public static function start(): array {
        $saved=self::status();
        if(($saved['phase']??'')==='COMPLETE')return $saved;
        if($saved)return $saved; // interruption/retry resumes, never drops the backup
        self::guardJobs();global $wpdb;
        $src=self::source();$bak=self::backup();$total=self::count($src);
        if($total<1)throw new RuntimeException('PSTE_CLEAN_RESET_EMPTY_SOURCE');
        $existing=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$bak));
        if((string)$existing===$bak)throw new RuntimeException('PSTE_CLEAN_RESET_BACKUP_EXISTS_REFUSE_OVERWRITE');
        // MySQL server copies in bounded SQL chunks: no 150-MB PHP export and no browser download.
        self::sql("CREATE TABLE $bak LIKE $src",'PSTE_CLEAN_RESET_BACKUP_CREATE_FAILED');
        if(self::count($bak)!==0)throw new RuntimeException('PSTE_CLEAN_RESET_BACKUP_NOT_EMPTY');
        return self::put(['contract'=>'PSTE_CLEAN_RESET_V1','phase'=>'BACKUP','total'=>$total,
            'max_id'=>self::maxId($src),'cursor'=>0,'backed_up'=>0,'reset_processed'=>0,
            'message'=>'Originalentscheidungen werden vollständig gesichert; noch nichts zurückgesetzt.',
            'created_at_utc'=>gmdate('c')]);
    }
    public static function advance(): array {
        $job=self::status();if(($job['contract']??'')!=='PSTE_CLEAN_RESET_V1')throw new RuntimeException('PSTE_CLEAN_RESET_NOT_STARTED');
        if(($job['phase']??'')==='COMPLETE')return $job;
        self::guardJobs();
        $r=PSTE_Breadth_Research_Queue::withTopicPoolWriteLock(static function()use($job){return self::advanceLocked($job);});
        if($r===null)throw new RuntimeException('PSTE_CLEAN_RESET_WRITER_BUSY_RETRY');
        return $r;
    }
    private static function advanceLocked(array $job): array {
        global $wpdb;$src=self::source();$bak=self::backup();
        if(self::count($src)!==(int)$job['total']||self::maxId($src)!==(int)$job['max_id'])
            throw new RuntimeException('PSTE_CLEAN_RESET_SOURCE_COUNT_CHANGED_STOP');
        $phase=(string)($job['phase']??'');$cursor=(int)($job['cursor']??0);
        if($phase==='BACKUP'){
            $ids=$wpdb->get_col($wpdb->prepare("SELECT id FROM $src WHERE id>%d ORDER BY id ASC LIMIT %d",$cursor,self::LIMIT));
            if(!is_array($ids))throw new RuntimeException('PSTE_CLEAN_RESET_BACKUP_READ_FAILED');
            if(!$ids){
                if(self::count($bak)!==(int)$job['total'])throw new RuntimeException('PSTE_CLEAN_RESET_BACKUP_INCOMPLETE');
                self::assertBackupIdentical();
                $job['phase']='RESET';$job['cursor']=0;
                $job['message']='Sicherung vollständig geprüft; jetzt nur automatische Entscheidungsfelder zurücksetzen.';
                return self::put($job);
            }
            $end=(int)end($ids);$n=count($ids);
            $copied=self::sql($wpdb->prepare("INSERT INTO $bak SELECT * FROM $src WHERE id>%d AND id<=%d ORDER BY id ASC",$cursor,$end),'PSTE_CLEAN_RESET_BACKUP_CHUNK_FAILED');
            if($copied!==$n)throw new RuntimeException('PSTE_CLEAN_RESET_BACKUP_CHUNK_COUNT_MISMATCH');
            $job['cursor']=$end;$job['backed_up']+=(int)$copied;
            if(self::count($bak)!==(int)$job['backed_up'])throw new RuntimeException('PSTE_CLEAN_RESET_BACKUP_READBACK_FAILED');
            return self::put($job);
        }
        if($phase==='RESET'){
            if(self::count($bak)!==(int)$job['total'])throw new RuntimeException('PSTE_CLEAN_RESET_BACKUP_GONE');
            $ids=$wpdb->get_col($wpdb->prepare("SELECT id FROM $src WHERE id>%d ORDER BY id ASC LIMIT %d",$cursor,self::LIMIT));
            if(!is_array($ids))throw new RuntimeException('PSTE_CLEAN_RESET_ROWS_READ_FAILED');
            if(!$ids){
                if((int)$job['reset_processed']!==(int)$job['total'])throw new RuntimeException('PSTE_CLEAN_RESET_RESET_COUNT_INCOMPLETE');
                $job['phase']='FINALIZE';$job['message']='Bewertungen zurückgesetzt, Abschluss wird bestätigt.';
                return self::put($job);
            }
            $end=(int)end($ids);
            // Source terms and manual review are untouched. Historical payloads and original category stay.
            self::sql($wpdb->prepare("UPDATE $src SET automatic_decision='REVIEW_REQUIRED',automatic_pool_status='REVIEW_REQUIRED',topic_role='RESEARCH_KEYWORD',planning_suitability='BLOCKED',context_state='PENDING',current_category_id=0,context_synced_at=NULL WHERE id>%d AND id<=%d AND manual_status=''",$cursor,$end),'PSTE_CLEAN_RESET_RESET_CHUNK_FAILED');
            $job['cursor']=$end;$job['reset_processed']+=count($ids);
            return self::put($job);
        }
        if($phase==='FINALIZE'){
            if(self::count($bak)!==(int)$job['total'])throw new RuntimeException('PSTE_CLEAN_RESET_BACKUP_VERIFICATION_FAILED');
            $old=get_option(self::OLD_STATE,null);
            if($old===null){
                $old=['contract'=>'PSTE_CLEAN_RESET_PRIOR_STATE_V1',
                    'queue'=>get_option(PSTE_OPTION_BREADTH_RESEARCH_QUEUE,null),
                    'receipt'=>get_option(PSTE_OPTION_RETAINED_BACKLOG_AUDIT,null),
                    'cancel'=>get_option(PSTE_OPTION_BREADTH_RESEARCH_CANCEL,null)];
                update_option(self::OLD_STATE,$old,false);
                if(get_option(self::OLD_STATE,null)!==$old)throw new RuntimeException('PSTE_CLEAN_RESET_OLD_STATE_SAVE_FAILED');
            }
            // Invalidate only the old audit orchestration, never the raw keyword sources.
            delete_option(PSTE_OPTION_BREADTH_RESEARCH_QUEUE);
            delete_option(PSTE_OPTION_RETAINED_BACKLOG_AUDIT);
            delete_option(PSTE_OPTION_BREADTH_RESEARCH_CANCEL);
            $poolKey=(string)$wpdb->get_var("SELECT pool_key FROM $src ORDER BY id ASC LIMIT 1");
            if(!preg_match('/^(?:[a-f0-9]{64}|[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12})$/i',$poolKey))throw new RuntimeException('PSTE_CLEAN_RESET_HISTORY_KEY_INVALID');
            $count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".PSTE_Repository::table('topic_history')." WHERE action=%s AND pool_key=%s AND details_json LIKE %s",'CLEAN_DECISIONS_RESET',$poolKey,'%"reset_contract":"PSTE_CLEAN_RESET_V1"%'));
            if($count===0){
                $ok=$wpdb->insert(PSTE_Repository::table('topic_history'),[
                    'pool_key'=>$poolKey,'action'=>'CLEAN_DECISIONS_RESET','from_status'=>'HISTORICAL',
                    'to_status'=>'REVIEW_REQUIRED','details_json'=>wp_json_encode(['reset_contract'=>'PSTE_CLEAN_RESET_V1','topics'=>$job['total'],'backup_verified'=>true,'raw_keywords_preserved'=>true]),
                    'user_id'=>(int)get_current_user_id(),'created_at'=>gmdate('Y-m-d H:i:s')
                ],['%s','%s','%s','%s','%s','%d','%s']);
                if($ok!==1)throw new RuntimeException('PSTE_CLEAN_RESET_HISTORY_WRITE_FAILED');
            }
            $job['phase']='COMPLETE';$job['cursor']=(int)$job['max_id'];
            $job['message']='Alte automatische Entscheidungen außer Kraft. Jetzt Automatik starten für die frische Bewertung (ohne Provider).';
            return self::put($job);
        }
        throw new RuntimeException('PSTE_CLEAN_RESET_UNKNOWN_PHASE');
    }
}
