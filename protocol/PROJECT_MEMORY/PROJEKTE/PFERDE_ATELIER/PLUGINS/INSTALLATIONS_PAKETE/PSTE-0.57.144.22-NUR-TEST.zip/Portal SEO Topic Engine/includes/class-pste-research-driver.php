<?php
if (!defined('ABSPATH')) { return; }

/**
 * Single server-side execution authority for research. One invocation performs at most
 * one bounded persisted workflow step. The browser never advances research work.
 */
final class PSTE_Research_Driver {
    public const CONTRACT='PSTE_RESEARCH_STEP_DRIVER_V1';
    private const LOCK_TTL=150;
    private const OVERDUE_AFTER=70;
    // Recover abandoned durable work only after BOTH the 150s driver and 180s
    // queue ownership windows have expired. This is a guard, not a new worker.
    private const STALE_RECOVERY_GRACE_SECONDS=210;
    private const MAX_NO_PROGRESS=5;
    private const LOOPBACK_MAX_DELAY_MS=5000;

    public static function register(): void {
        add_action(PSTE_RESEARCH_DRIVER_CRON_HOOK,[self::class,'tick']);
        add_action('wp_ajax_'.PSTE_RESEARCH_DRIVER_LOOPBACK_ACTION,[self::class,'loopback']);
        add_action('wp_ajax_nopriv_'.PSTE_RESEARCH_DRIVER_LOOPBACK_ACTION,[self::class,'loopback']);
        add_action('init',[self::class,'maybeKickExisting'],50);
    }

    /** Start/recover the one server driver. No domain work is executed in the caller request. */
    public static function kick(int $delayMs=0,string $reason='KICK'): array {
        $state=self::loadOrDefault();
        // A valid lock means the exact saved step is still owned. A status-only
        // timeout must never launch a competing step while that lock is live.
        $lock=self::lockStatus();
        if(!empty($lock['locked'])&&trim((string)($state['step_started_at_utc']??''))!=='')return self::publicStatus($state);
        if((string)($state['loopback_token']??'')==='')$state['loopback_token']=bin2hex(random_bytes(24));
        // The previous step is no longer locked. A fresh explicit kick must not inherit
        // its 70-second clock, otherwise the replacement is instantly reported BLOCKED.
        if(trim((string)($state['step_started_at_utc']??''))!==''){
            $state['last_unfinished_step_started_at_utc']=(string)$state['step_started_at_utc'];
            $state['step_started_at_utc']='';
        }
        $state['status']='RUNNING';$state['health_code']='PSTE_DRIVER_SCHEDULED';$state['last_error']='';$state['kick_reason']=self::code($reason);$state['next_run_at_utc']=gmdate('c',time()+(int)ceil(max(0,$delayMs)/1000));$state['updated_at_utc']=gmdate('c');
        self::save($state);
        self::dispatchLoopback((string)$state['loopback_token'],$delayMs);
        return self::publicStatus($state);
    }

    /** Server-request recovery only: re-dispatch a durable active run if its driver disappeared. */
    public static function maybeKickExisting(): void {
        if(!PSTE_Plugin::isReady())return;
        try{
            $queue=PSTE_Breadth_Research_Queue::peek();$job=PSTE_Research_Job::peek();
            $active=(is_array($queue)&&in_array((string)($queue['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))||is_array($job);
            if(!$active)return;
            $state=self::loadOrDefault();$updated=strtotime((string)($state['updated_at_utc']??''))?:0;$locked=self::lockStatus();$status=(string)($state['status']??'IDLE');$stateVersion=(string)($state['plugin_version']??'');
            // A deliberate BLOCKED state is durable and must not be erased by an observation request.
            // A later code version may explicitly re-enter the exact saved state after a fix.
            if(!$locked['locked']&&$status==='BLOCKED')return; // A plugin update never silently resumes a stopped research run.
            if(!$locked['locked']&&$status==='IDLE')self::kick(0,'SERVER_REQUEST_RECOVERY');
            elseif(!$locked['locked']&&$status==='RUNNING'&&$updated>0&&time()-$updated>15){
                $stepStart=strtotime((string)($state['step_started_at_utc']??''))?:0;
                if($stepStart>0&&time()-$stepStart>self::OVERDUE_AFTER){
                    // Previously this returned forever when a PHP request died after
                    // writing step_started_at_utc. The 957s incident is that state.
                    // Never steal live ownership or overwrite paused/blocked work.
                    if(time()-$stepStart<=self::STALE_RECOVERY_GRACE_SECONDS)return;
                    if(is_array($queue)){
                        if((string)($queue['status']??'')!=='RUNNING')return;
                        $queueLock=PSTE_Breadth_Research_Queue::queueLockStatus();
                        if(!empty($queueLock['locked']))return;
                    }
                    if(is_array($job)){
                        $jobStatus=(string)($job['status']??'');
                        if($jobStatus!=='RUNNING')return;
                        $jobLock=PSTE_Research_Job::stepLockStatus();
                        if(!empty($jobLock['locked']))return;
                    }
                    // The existing saved checkpoint and locks remain authoritative.
                    // A fresh bounded tick will re-read and validate them; no reset.
                    self::kick(0,'EXPIRED_STEP_RECOVERY');return;
                }
                self::kick(0,'STALE_DRIVER_RECOVERY');
            }
        }catch(Throwable $ignored){/* observation request must not be broken by recovery */}
    }

    /** Internal authenticated loopback. */
    public static function loopback(): void {
        $state=self::loadOrDefault();$provided=(string)($_POST['token']??'');$expected=(string)($state['loopback_token']??'');
        if($provided===''||$expected===''||!hash_equals($expected,$provided)){status_header(403);exit;}
        $delay=max(0,min(self::LOOPBACK_MAX_DELAY_MS,(int)($_POST['delay_ms']??0)));if($delay>0)usleep($delay*1000);
        self::tick();
        status_header(204);exit;
    }

    /** One bounded persisted step only. */
    public static function tick(): void {
        if(!PSTE_Plugin::isReady())return;
        try{$lock=self::acquireLock();}catch(Throwable $e){return;}
        $continue=false;$delay=0;$stepStartedMono=microtime(true);
        try{
            $state=self::loadOrDefault();$before=self::workflowSignature();
            $state['status']='RUNNING';$state['health_code']='PSTE_DRIVER_STEP_RUNNING';$state['step_started_at_utc']=gmdate('c');$state['step_completed_at_utc']='';$state['last_error']='';$state['step_number']=(int)($state['step_number']??0)+1;$state['last_step']=self::describeCurrentStep();$state['updated_at_utc']=gmdate('c');self::save($state);
            [$continue,$delay,$resultCode]=self::executeOneStep();
            $after=self::workflowSignature();$state=self::loadOrDefault();
            $same=hash_equals($before,$after);$expectedWait=self::expectedWait();
            $state['step_exception_count']=0;$state['last_exception_code']='';
            if(!$same){$state['last_progress_at_utc']=gmdate('c');$state['no_progress_count']=0;}
            elseif($continue&&!$expectedWait){$state['no_progress_count']=(int)($state['no_progress_count']??0)+1;}else{$state['no_progress_count']=0;}
            $qAfter=null;try{$qAfter=PSTE_Breadth_Research_Queue::peek();}catch(Throwable $ignored){}$completedNow=is_array($qAfter)?(int)($qAfter['completed_count']??0):0;$completedBefore=(int)($state['last_seen_completed_count']??0);$state['last_seen_completed_count']=$completedNow;
            if($completedNow>$completedBefore){$state['same_blocked_code_count']=0;$state['last_blocked_code']='';}
            if(str_starts_with($resultCode,'CHILD_PARKED_CONTINUE|')){
                $blockedCode=substr($resultCode,strlen('CHILD_PARKED_CONTINUE|'));$prior=(string)($state['last_blocked_code']??'');
                if(self::countsAsRepeatedSystemFailure($blockedCode)){
                    $state['same_blocked_code_count']=($prior!==''&&hash_equals($prior,$blockedCode))?(int)($state['same_blocked_code_count']??0)+1:1;$state['last_blocked_code']=$blockedCode;
                    if((int)$state['same_blocked_code_count']>=3){$continue=false;$state['status']='BLOCKED';$state['health_code']='PSTE_DRIVER_REPEATED_SYSTEM_FAILURE';$state['last_error']='PSTE_DRIVER_REPEATED_SYSTEM_FAILURE:'.$blockedCode;}
                }else{
                    $state['same_blocked_code_count']=0;$state['last_blocked_code']='';
                }
            }
            if($continue&&!$expectedWait&&(int)$state['no_progress_count']>=self::MAX_NO_PROGRESS){$continue=false;$state['status']='BLOCKED';$state['health_code']='PSTE_DRIVER_NO_PROGRESS_BLOCKED';$state['last_error']='PSTE_DRIVER_NO_PROGRESS_BLOCKED';}
            elseif((string)($state['status']??'')!=='BLOCKED'){$state['status']=$continue?'RUNNING':'IDLE';$state['health_code']=$continue?'PSTE_DRIVER_STEP_SAVED':'PSTE_DRIVER_NO_ACTIVE_WORK';$state['last_error']='';}
            if($resultCode!=='')$state['last_result_code']=$resultCode;
            $state['last_step_duration_ms']=(int)round((microtime(true)-$stepStartedMono)*1000);$state['step_completed_at_utc']=gmdate('c');$state['step_started_at_utc']='';$state['next_run_at_utc']=$continue?gmdate('c',time()+(int)ceil($delay/1000)):'';$state['updated_at_utc']=gmdate('c');self::save($state);
        }catch(Throwable $e){
            $state=self::loadOrDefault();$code=self::code($e->getMessage());$state['last_step_duration_ms']=(int)round((microtime(true)-$stepStartedMono)*1000);$state['step_completed_at_utc']=gmdate('c');$state['step_started_at_utc']='';$state['updated_at_utc']=gmdate('c');
            if(in_array($code,['PSTE_RESEARCH_STEP_ALREADY_RUNNING','PSTE_BREADTH_QUEUE_STEP_ALREADY_RUNNING','PSTE_SANDBOX_LOCKED','PSTE_BUDGET_RESERVATION_LOCKED'],true)){
                $state['last_exception_code']='';$state['step_exception_count']=0;$state['last_error']=$code;$state['status']='RUNNING';$state['health_code']='PSTE_DRIVER_COORDINATION_WAIT';$continue=true;$delay=1000;$state['next_run_at_utc']=gmdate('c',time()+1);
            }else{
                $prior=(string)($state['last_exception_code']??'');$count=($prior!==''&&hash_equals($prior,$code))?(int)($state['step_exception_count']??0)+1:1;$state['last_exception_code']=$code;$state['step_exception_count']=$count;$state['last_error']=$code;
                if($count<3){$state['status']='RUNNING';$state['health_code']='PSTE_DRIVER_STEP_RETRY_PENDING';$continue=true;$delay=1000;$state['next_run_at_utc']=gmdate('c',time()+1);}else{$state['status']='BLOCKED';$state['health_code']='PSTE_DRIVER_STEP_EXCEPTION_BLOCKED';$state['next_run_at_utc']='';$continue=false;}
            }
            self::save($state);
        }finally{self::releaseLock($lock);}
        if($continue){$state=self::loadOrDefault();self::dispatchLoopback((string)($state['loopback_token']??''),$delay);}
    }

    /** @return array{0:bool,1:int,2:string} */
    private static function executeOneStep(): array {
        $settings=PSTE_Plugin::settings();$queue=PSTE_Breadth_Research_Queue::peek();$job=PSTE_Research_Job::peek();if(is_array($job)&&(string)($job['status']??'')==='PAUSED_ERROR'){$recovered=PSTE_Research_Job::current();if(is_array($recovered))$job=$recovered;}
        if(is_array($queue)&&in_array((string)($queue['status']??''),['COMPLETE','CANCELLED'],true)&&!is_array($job))return [false,0,'QUEUE_TERMINAL'];
        if(is_array($queue)){
            $qStatus=(string)($queue['status']??'');
            $idx=(int)($queue['current_index']??0);$items=(array)($queue['items']??[]);$currentItem=(isset($items[$idx])&&is_array($items[$idx]))?$items[$idx]:[];
            // Crash-safe park reconciliation has priority over normal queue advancement. If the
            // child was already archived and its active pointer removed before queue bookkeeping
            // committed, this step reconciles that exact archive instead of starting a new child.
            if($qStatus==='RUNNING'&&(string)($currentItem['status']??'')==='BLOCKED_PENDING_PARK'){
                $reason=(string)($currentItem['last_error']??'PSTE_CHILD_BLOCKED');
                PSTE_Breadth_Research_Queue::parkBlockedCurrentAndContinue((string)$queue['queue_uuid'],$reason);
                return [true,0,'CHILD_PARKED_CONTINUE|'.self::code($reason)];
            }
            // Existing pre-0.57 paused/outcome queues are recovered only by parking their owned blocked child.
            if(is_array($job)&&in_array((string)($job['status']??''),['PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){
                PSTE_Breadth_Research_Queue::parkBlockedCurrentAndContinue((string)$queue['queue_uuid'],(string)($job['last_error']??'PSTE_CHILD_BLOCKED'));
                return [true,0,'CHILD_PARKED_CONTINUE|'.self::code((string)($job['last_error']??'PSTE_CHILD_BLOCKED'))];
            }
            if(in_array($qStatus,['PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){
                // No safely parkable owned child means a queue/global invariant is broken. Preserve everything.
                self::markSystemBlock((string)($queue['last_error']??'PSTE_BREADTH_QUEUE_BLOCKED'));
                return [false,0,'QUEUE_GLOBAL_BLOCK'];
            }
            if($qStatus==='RUNNING'){
                $next=PSTE_Breadth_Research_Queue::advance((string)$queue['queue_uuid'],$settings,false);$nextStatus=(string)($next['status']??'');
                if(in_array($nextStatus,['PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){$code=(string)($next['last_error']??'PSTE_BREADTH_QUEUE_BLOCKED');self::markSystemBlock($code);return [false,0,'QUEUE_GLOBAL_BLOCK|'.self::code($code)];}
                $child=(array)($next['child']??[]);$delay=((string)($child['coordination_wait_code']??'')==='PSTE_PAA_TASK_PENDING'||(string)($child['questions_state']??'')==='TASK_PENDING')?2000:0;
                return [$nextStatus==='RUNNING',$delay,'BREADTH_STEP_SAVED'];
            }
        }
        if(is_array($job)){
            $status=(string)($job['status']??'');
            if(in_array($status,['PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){
                PSTE_Research_Job::parkCurrent((string)$job['job_uuid'],(string)($job['last_error']??'PSTE_SINGLE_BLOCKED'),['driver_reason'=>(string)($job['last_error']??'PSTE_SINGLE_BLOCKED')]);
                return [false,0,'SINGLE_PARKED'];
            }
            if($status==='RUNNING'){
                $next=PSTE_Research_Job::advance((string)$job['job_uuid'],$settings,false);$nextStatus=(string)($next['status']??'');
                if($nextStatus==='COMPLETE')return [false,0,'SINGLE_COMPLETE'];
                $delay=((string)($next['coordination_wait_code']??'')==='PSTE_PAA_TASK_PENDING'||(string)($next['questions_state']??'')==='TASK_PENDING')?2000:0;
                return [true,$delay,'SINGLE_STEP_SAVED'];
            }
        }
        return [false,0,'NO_ACTIVE_WORK'];
    }

    private static function countsAsRepeatedSystemFailure(string $code): bool {
        return !in_array(self::code($code),['PSTE_CATEGORY_EXHAUSTION_NOT_PROVEN'],true);
    }

    private static function markSystemBlock(string $code): void {$state=self::loadOrDefault();$state['status']='BLOCKED';$state['health_code']='PSTE_DRIVER_GLOBAL_BLOCK';$state['last_error']=self::code($code);$state['updated_at_utc']=gmdate('c');self::save($state);}

    public static function status(): array {return self::publicStatus(self::loadOrDefault());}

    private static function publicStatus(array $state): array {
        $out=$state;unset($out['loopback_token'],$out['sha256']);$lock=self::lockStatus();$out['lock']=$lock;$started=strtotime((string)($state['step_started_at_utc']??''))?:0;$out['active_step_age_seconds']=$started>0?max(0,time()-$started):0;
        // The 70-second threshold is a warning, not proof that the step has died.
        // The single execution lock remains valid for 150 seconds. Reporting BLOCKED
        // earlier causes productionAutoStepAjax to kick the same step a second time.
        // Preserve an actual persisted BLOCKED state unconditionally.
        if($started>0&&time()-$started>self::OVERDUE_AFTER){
            $out['overdue_seconds']=time()-$started;
            if((string)($state['status']??'')==='RUNNING'&&!empty($lock['locked'])){
                $out['health_code']='PSTE_DRIVER_STEP_SLOW_LOCK_HELD';
                $out['status']='RUNNING';
            }elseif((string)($state['status']??'')==='RUNNING'){
                $out['status']='BLOCKED';$out['health_code']='PSTE_DRIVER_STEP_OVERDUE';$out['last_error']='PSTE_DRIVER_STEP_OVERDUE';
            }
        }
        $out['lock_active']=!empty($lock['locked']);
        $out['lock_expires_at']=(int)($lock['expires_at']??0);
        $out['lock_expired_owner']=!empty($lock['expired_owner']);
        try{$out['parked']=PSTE_Research_Archive::status();}catch(Throwable $e){$out['parked']=['count'=>0,'error'=>self::code($e->getMessage())];}
        return $out;
    }

    private static function expectedWait(): bool {
        try{$job=PSTE_Research_Job::peek();if(is_array($job)){if((string)($job['coordination_wait_code']??'')==='PSTE_PAA_TASK_PENDING'||(string)($job['questions_state']??'')==='TASK_PENDING')return true;if((string)($job['phase_state']??'')==='IN_FLIGHT')return true;}}catch(Throwable $ignored){}
        return false;
    }

    private static function describeCurrentStep(): string {
        try{$q=PSTE_Breadth_Research_Queue::peek();if(is_array($q)){$c=(array)($q['child']??[]);$phase=(string)($c['phase']??'CONTROL');$detail=$phase==='FINALIZE'?(string)($c['finalize_stage']??'PREPARE'):(string)($c['phase_state']??'');return 'BREADTH:'.(string)($q['current_index']??0).':'.$phase.':'.$detail;}$j=PSTE_Research_Job::peek();if(is_array($j)){$phase=(string)($j['phase']??'');$detail=$phase==='FINALIZE'?(string)($j['finalize_stage']??'PREPARE'):(string)($j['phase_state']??'');return 'SINGLE:'.$phase.':'.$detail;}}catch(Throwable $ignored){}return 'IDLE';
    }

    private static function workflowSignature(): string {
        $q=null;$j=null;try{$q=PSTE_Breadth_Research_Queue::peek();}catch(Throwable $e){$q=['error'=>self::code($e->getMessage())];}try{$j=PSTE_Research_Job::peek();}catch(Throwable $e){$j=['error'=>self::code($e->getMessage())];}
        return hash('sha256',self::json(['queue'=>$q,'job'=>$j]));
    }

    private static function dispatchLoopback(string $token,int $delayMs): void {
        $delay=max(0,min(self::LOOPBACK_MAX_DELAY_MS,$delayMs));
        // Arm one watchdog for the SAME driver before the fast loopback. This is not a second
        // engine: the same tick() plus driver lock is the only execution authority. It covers a
        // loopback request that appears accepted locally but is lost before reaching WordPress.
        if(function_exists('wp_next_scheduled')&&function_exists('wp_schedule_single_event')&&!wp_next_scheduled(PSTE_RESEARCH_DRIVER_CRON_HOOK))wp_schedule_single_event(time()+max(5,(int)ceil($delay/1000)+5),PSTE_RESEARCH_DRIVER_CRON_HOOK);
        if($token===''||!function_exists('wp_remote_post')||!function_exists('admin_url'))return;
        $r=wp_remote_post(admin_url('admin-ajax.php'),['timeout'=>1,'blocking'=>false,'redirection'=>0,'sslverify'=>apply_filters('https_local_ssl_verify',false),'body'=>['action'=>PSTE_RESEARCH_DRIVER_LOOPBACK_ACTION,'token'=>$token,'delay_ms'=>$delay]]);
        if(is_wp_error($r)){
            $state=self::loadOrDefault();$state['health_code']='PSTE_DRIVER_LOOPBACK_DISPATCH_FALLBACK_CRON';$state['last_error']=self::code($r->get_error_code());$state['updated_at_utc']=gmdate('c');self::save($state);
        }
    }

    private static function acquireLock(): string {$token=hash('sha256','driver|'.microtime(true).'|'.wp_generate_uuid4());$v=['token'=>$token,'expires_at'=>time()+self::LOCK_TTL];if(self::insertLockIfAbsent(PSTE_OPTION_RESEARCH_DRIVER_LOCK,$v)){return $token;}self::deleteExpiredLockAtomically(PSTE_OPTION_RESEARCH_DRIVER_LOCK);if(self::insertLockIfAbsent(PSTE_OPTION_RESEARCH_DRIVER_LOCK,$v))return $token;throw new RuntimeException('PSTE_RESEARCH_DRIVER_ALREADY_RUNNING');}
    private static function insertLockIfAbsent(string $option,array $value): bool {global $wpdb;$sql=$wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,%s)",$option,maybe_serialize($value),'off');$r=$wpdb->query($sql);if($r===false)throw new RuntimeException('PSTE_DRIVER_LOCK_INSERT_FAILED');wp_cache_delete($option,'options');return (int)$r===1;}
    private static function releaseLock(string $token): void {self::deleteOwnedLockAtomically(PSTE_OPTION_RESEARCH_DRIVER_LOCK,$token);}
    private static function deleteExpiredLockAtomically(string $option): void {global $wpdb;$raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$option));if(!is_string($raw)||$raw==='')return;$v=maybe_unserialize($raw);if(!is_array($v)||(int)($v['expires_at']??0)>=time())return;PSTE_DB_Write_Guard::query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$option,$raw),'PSTE_LOCK_ATOMIC_EXPIRED_DELETE_FAILED');wp_cache_delete($option,'options');}
    private static function deleteOwnedLockAtomically(string $option,string $token): void {global $wpdb;$raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$option));if(!is_string($raw)||$raw==='')return;$v=maybe_unserialize($raw);if(!is_array($v)||!hash_equals($token,(string)($v['token']??'')))return;PSTE_DB_Write_Guard::query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$option,$raw),'PSTE_LOCK_ATOMIC_RELEASE_FAILED');wp_cache_delete($option,'options');}
    private static function lockStatus(): array {$v=get_option(PSTE_OPTION_RESEARCH_DRIVER_LOCK,[]);if(!is_array($v)||empty($v['token']))return ['locked'=>false,'expires_at'=>0];$e=(int)($v['expires_at']??0);return ['locked'=>$e>=time(),'expires_at'=>$e,'expired_owner'=>$e>0&&$e<time()];}

    private static function defaults(): array {return ['contract'=>self::CONTRACT,'version'=>'1.0.0','plugin_version'=>(string)PSTE_VERSION,'status'=>'IDLE','health_code'=>'PSTE_DRIVER_IDLE','last_error'=>'','last_result_code'=>'','last_step'=>'','last_step_duration_ms'=>0,'step_number'=>0,'no_progress_count'=>0,'step_exception_count'=>0,'last_exception_code'=>'','same_blocked_code_count'=>0,'last_blocked_code'=>'','last_seen_completed_count'=>0,'last_progress_at_utc'=>'','step_started_at_utc'=>'','step_completed_at_utc'=>'','next_run_at_utc'=>'','loopback_token'=>'','created_at_utc'=>gmdate('c'),'updated_at_utc'=>gmdate('c')];}
    private static function loadOrDefault(): array {$v=get_option(PSTE_OPTION_RESEARCH_DRIVER_STATE,null);if($v===null||$v===false||$v==='')return self::defaults();if(!is_array($v)||!self::valid($v))throw new RuntimeException('PSTE_RESEARCH_DRIVER_STATE_INVALID');return $v;}
    private static function save(array $v): void {$v['contract']=self::CONTRACT;$v['version']='1.0.0';$v['plugin_version']=(string)PSTE_VERSION;if(empty($v['created_at_utc']))$v['created_at_utc']=gmdate('c');unset($v['sha256']);$v['sha256']=hash('sha256',self::json($v));update_option(PSTE_OPTION_RESEARCH_DRIVER_STATE,$v,false);$r=get_option(PSTE_OPTION_RESEARCH_DRIVER_STATE,null);if(!is_array($r)||!self::valid($r)||!hash_equals((string)$v['sha256'],(string)($r['sha256']??'')))throw new RuntimeException('PSTE_RESEARCH_DRIVER_STATE_READBACK_MISMATCH');}
    private static function valid(array $v): bool {if(($v['contract']??'')!==self::CONTRACT)return false;$d=(string)($v['sha256']??'');$c=$v;unset($c['sha256']);return preg_match('/^[a-f0-9]{64}$/',$d)===1&&hash_equals($d,hash('sha256',self::json($c)));}
    private static function json($v): string {$j=wp_json_encode(self::canonical($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($j))throw new RuntimeException('PSTE_RESEARCH_DRIVER_JSON_FAILED');return $j;}
    private static function canonical($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonical'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonical($x);return $v;}
    private static function code(string $v): string {$v=strtoupper(trim($v));$v=(string)preg_replace('/[^A-Z0-9_:\-]/','_',$v);return substr($v!==''?$v:'PSTE_DRIVER_FAILED',0,180);}
}
