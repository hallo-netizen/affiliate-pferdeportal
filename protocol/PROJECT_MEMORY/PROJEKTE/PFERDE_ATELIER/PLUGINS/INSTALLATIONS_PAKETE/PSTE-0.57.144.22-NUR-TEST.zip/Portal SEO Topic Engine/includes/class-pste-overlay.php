<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Overlay {
    public static function build(array $run, array $candidates): array {
        $overlay = [
            'contract'=>'SEO_TOPIC_OVERLAY_V1','schema_version'=>1,
            'source_plugin'=>['slug'=>'portal-seo-topic-engine','version'=>PSTE_VERSION],
            'run'=>[
                'run_id'=>$run['run_uuid'],'created_at_utc'=>gmdate('Y-m-d\TH:i:s\Z',strtotime($run['created_at'].' UTC')),'expires_at_utc'=>gmdate('Y-m-d\TH:i:s\Z', strtotime($run['created_at'].' UTC +30 days')),
                'location'=>$run['payload']['location'] ?? 'Germany','language'=>$run['payload']['language'] ?? 'German',
                'inventory_snapshot_sha256'=>$run['snapshot']['inventory']['sha256'] ?? '',
                'structure_snapshot_sha256'=>$run['snapshot']['structure']['sha256'] ?? '',
                'editorial_plan_snapshot_sha256'=>$run['snapshot']['editorial_plan']['sha256'] ?? 'NOT_AVAILABLE',
                'estimated_cost_usd'=>(float)$run['estimated_cost'],'actual_cost_usd'=>(float)$run['actual_cost'],'status'=>$run['status'],
                'family_filter_diagnostics'=>(array)($run['payload']['family_filter_diagnostics']??[]),
                'family_identity_v2_registry_sha256'=>(string)($run['payload']['family_identity_v2_registry_sha256']??''),
            ],
            'candidates'=>$candidates,
            'topic_pool_summary'=>PSTE_Repository::topicPoolStats(),
            'portal_research_completeness'=>PSTE_Repository::researchCompleteness(),
            'writes_to_existing_system'=>false,'production_gate_active'=>false,
        ];
        $overlay = PSTE_Credentials::scrub($overlay);
        $overlay['overlay_sha256'] = hash('sha256', wp_json_encode($overlay, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        return $overlay;
    }


    public static function buildGlobalMap(array $baseline, array $progress, array $candidates): array {
        $map=[
            'contract'=>'SEO_TOPIC_MAP_V1','schema_version'=>1,
            'source_plugin'=>['slug'=>'portal-seo-topic-engine','version'=>PSTE_VERSION],
            'generated_at_utc'=>gmdate('c'),
            'site_baseline'=>$baseline,
            'category_progress'=>$progress,
            'candidates'=>$candidates,
            'topic_pool_summary'=>PSTE_Repository::topicPoolStats(),
            'portal_research_completeness'=>PSTE_Repository::researchCompleteness(),
            'writes_to_existing_system'=>false,
            'production_gate_active'=>false,
            'family_identity_v2_dry_run_status'=>self::dryRunStatus(),
            'ppc_connection'=>'NONE_INFORMATIONAL_ONLY',
        ];
        $map=PSTE_Credentials::scrub($map);
        $map['topic_map_sha256']=hash('sha256',wp_json_encode($map,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        return $map;
    }

    /**
     * Memory-bounded full topic-map export. Reads the retained topic pool in bounded pages,
     * streams every candidate to the target resource and computes the legacy topic_map_sha256
     * over the logical object without materializing the complete candidate domain in memory.
     */
    public static function streamGlobalMapToResource($handle,array $baseline,?callable $guard=null): array {
        if(!is_resource($handle))throw new RuntimeException('PSTE_TOPIC_MAP_EXPORT_STREAM_HANDLE_INVALID');
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        $flags=JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION;
        $encode=static function($value)use($flags):string{$json=wp_json_encode($value,$flags);if(!is_string($json))throw new RuntimeException('PSTE_TOPIC_MAP_EXPORT_JSON_ENCODE_FAILED');return $json;};
        $clean=static function($value){return PSTE_GSC_Credentials::scrub(PSTE_Credentials::scrub($value));};
        $hash=hash_init('sha256');$bytes=0;
        $write=static function(string $chunk,bool $hashChunk=true)use($handle,$hash,&$bytes):void{
            $len=strlen($chunk);$off=0;while($off<$len){$n=fwrite($handle,substr($chunk,$off));if($n===false||$n===0)throw new RuntimeException('PSTE_TOPIC_MAP_EXPORT_STREAM_WRITE_FAILED');$off+=$n;$bytes+=$n;}if($hashChunk)hash_update($hash,$chunk);
        };
        $field=static function(string $key,$value,bool $first=false)use($clean,$encode,$guard,$write):void{
            $cleaned=$clean($value);if($guard!==null)$guard(is_array($cleaned)?$cleaned:['value'=>$cleaned]);$write(($first?'':',').$encode($key).':'.$encode($cleaned));
        };
        $generated=gmdate('c');$progress=PSTE_Repository::categoryProgress($baseline['leaf_categories']??[]);
        $write('{');
        $field('contract','SEO_TOPIC_MAP_V1',true);
        $field('schema_version',1);
        $field('source_plugin',['slug'=>'portal-seo-topic-engine','version'=>PSTE_VERSION]);
        $field('generated_at_utc',$generated);
        $field('site_baseline',$baseline);
        $field('category_progress',$progress);
        $write(','.$encode('candidates').':[');
        $stats=['TOTAL'=>0,'PASS'=>0,'REVIEW_REQUIRED'=>0,'REASSIGN'=>0,'DISCOVERY_ONLY'=>0,'BLOCKED_FOR_CATEGORY'=>0,'APPROVED'=>0,'REJECTED'=>0,'REASSIGNED'=>0,'GREEN'=>0,'YELLOW'=>0,'RED'=>0];
        $cursor=null;$seenCursor=[];$candidateCount=0;$firstCandidate=true;$pages=0;
        do{
            $page=PSTE_Repository::adminTopicPoolPage($cursor,100);$pages++;
            if(($page['contract']??'')!=='PSTE_ADMIN_TOPIC_PAGE_V1')throw new RuntimeException('PSTE_TOPIC_MAP_EXPORT_PAGE_CONTRACT_INVALID');
            $cleanedItems=$clean((array)($page['items']??[]));if(!is_array($cleanedItems))throw new RuntimeException('PSTE_TOPIC_MAP_EXPORT_CANDIDATE_PAGE_INVALID');if($guard!==null)$guard($cleanedItems);
            foreach($cleanedItems as $cleaned){
                if(!is_array($cleaned))throw new RuntimeException('PSTE_TOPIC_MAP_EXPORT_CANDIDATE_INVALID');
                $write(($firstCandidate?'':',').$encode($cleaned));$firstCandidate=false;$candidateCount++;
                $status=(string)($cleaned['pool_status']??'REVIEW_REQUIRED');$stats['TOTAL']++;$stats[$status]=($stats[$status]??0)+1;$light=(string)($cleaned['traffic_light']['code']??'RED');$stats[$light]=($stats[$light]??0)+1;
            }
            $complete=!empty($page['complete']);$next=is_array($page['next_cursor']??null)?$page['next_cursor']:null;
            if(!$complete){if(!is_array($next))throw new RuntimeException('PSTE_TOPIC_MAP_EXPORT_CURSOR_MISSING');$cursorKey=$encode($next);if(isset($seenCursor[$cursorKey]))throw new RuntimeException('PSTE_TOPIC_MAP_EXPORT_CURSOR_STALLED');$seenCursor[$cursorKey]=true;$cursor=$next;}else{$cursor=null;}
        }while(!$complete);
        $write(']');
        $relationStats=PSTE_Repository::adminTopicPoolStats();foreach(['OCCURRENCES','ASSIGNMENTS','MERGE_CANDIDATES'] as $k)$stats[$k]=(int)($relationStats[$k]??0);
        $field('topic_pool_summary',$stats);
        $field('portal_research_completeness',PSTE_Repository::researchCompleteness());
        $field('writes_to_existing_system',false);
        $field('production_gate_active',false);
        $field('family_identity_v2_dry_run_status',self::dryRunStatus());
        $field('ppc_connection','NONE_INFORMATIONAL_ONLY');
        // Legacy hash contract: hash the logical map object before topic_map_sha256 is added.
        hash_update($hash,'}');$topicMapSha=hash_final($hash);
        $hashField=','.$encode('topic_map_sha256').':'.$encode($topicMapSha).'}';
        $len=strlen($hashField);$off=0;while($off<$len){$n=fwrite($handle,substr($hashField,$off));if($n===false||$n===0)throw new RuntimeException('PSTE_TOPIC_MAP_EXPORT_STREAM_WRITE_FAILED');$off+=$n;$bytes+=$n;}
        return ['contract'=>'PSTE_TOPIC_MAP_STREAM_EXPORT_V1','bytes'=>$bytes,'candidate_count'=>$candidateCount,'page_count'=>$pages,'topic_map_sha256'=>$topicMapSha,'write_attempted'=>false];
    }

    private static function dryRunStatus(): array {$dry=get_option(PSTE_OPTION_FAMILY_V2_DRY_RUN,[]);return is_array($dry)&&($dry['contract']??'')===PSTE_Family_Reclassification_V2::DRY_RUN_CONTRACT?['status'=>'AVAILABLE','dry_run_sha256'=>(string)($dry['dry_run_sha256']??''),'source_snapshot_sha256'=>(string)($dry['source_snapshot_sha256']??''),'item_count'=>(int)($dry['item_count']??0)]:['status'=>'NOT_RUN'];}

    public static function validate(array $overlay): void {
        if (($overlay['contract'] ?? '') !== 'SEO_TOPIC_OVERLAY_V1' || ($overlay['schema_version'] ?? 0) !== 1) { throw new RuntimeException('PSTE_OVERLAY_CONTRACT_INVALID'); }
        if (($overlay['writes_to_existing_system'] ?? true) !== false || ($overlay['production_gate_active'] ?? true) !== false) { throw new RuntimeException('PSTE_OVERLAY_SCOPE_INVALID'); }
        $hash = $overlay['overlay_sha256'] ?? ''; unset($overlay['overlay_sha256']);
        $actual = hash('sha256', wp_json_encode($overlay, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        if (!hash_equals((string)$hash, $actual)) { throw new RuntimeException('PSTE_OVERLAY_HASH_INVALID'); }
    }
}
