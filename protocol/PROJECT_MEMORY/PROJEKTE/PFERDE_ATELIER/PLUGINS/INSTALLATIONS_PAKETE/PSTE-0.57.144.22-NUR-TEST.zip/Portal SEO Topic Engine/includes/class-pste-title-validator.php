<?php
if (!defined('ABSPATH')) { return; }

/** Mechanical portal title invariants only. Semantic intent is owned by the independent editorial/intent strand. */
final class PSTE_Title_Validator {
    /** @return array<string,mixed> */
    public static function validate(string $title,string $source,string $family,string $type,array $registry,string $targetKeyword=''): array {
        $r=[];$len=function_exists('mb_strlen')?mb_strlen($title,'UTF-8'):strlen($title);$canon=PSTE_Article_Type_Registry::canonicalType($type);$isFaq=$canon==='faq';$isJournal=$canon==='journal';
        if($title==='')$r[]='TITLE_EMPTY';if($len<8)$r[]='TITLE_TOO_SHORT';if($len>110)$r[]='TITLE_TOO_LONG';
        // Existing title composer preserves joined alphanumeric brand marks (e.g. R+V).
        // Keep rejecting stray '+' and all other unsupported punctuation.
        $specialSurface=(string)preg_replace('/(?<=\p{L})\+(?=\p{L})/u','',$title);
        if(preg_match($isJournal?'/[^\p{L}\p{N}\s?,:?–-]/u':'/[^\p{L}\p{N}\s?,?–-]/u',$specialSurface))$r[]='TITLE_SPECIAL_CHARACTER_FORBIDDEN';
        $qCount=substr_count($title,'?');
        if($isFaq){if($qCount!==1||!str_ends_with($title,'?'))$r[]='FAQ_TITLE_REQUIRES_SINGLE_TERMINAL_QUESTION_MARK';}
        elseif($isJournal){if($qCount>1||($qCount===1&&!str_ends_with($title,'?')))$r[]='JOURNAL_QUESTION_MARK_MUST_BE_SINGLE_TERMINAL_WHEN_USED';}
        else{if($qCount>0)$r[]='QUESTION_MARK_EXCLUSIVE_TO_FAQ';}
        if(preg_match('/<[^>]+>|\{\{|\[\[/u',$title))$r[]='TITLE_MARKUP_OR_TEMPLATE_ARTIFACT';
        if(preg_match('/\b([\p{L}\d]+)\s+\1\b/iu',$title))$r[]='TITLE_REPEATED_WORD';
        if(preg_match('/\s{2,}/u',$title))$r[]='TITLE_WHITESPACE_INVALID';
        if(self::hasArtificialGeneratorPhrase($title))$r[]='TITLE_ARTIFICIAL_GENERATOR_PHRASE_FORBIDDEN';
        if(self::hasForbiddenTitlePhraseFamily($title))$r[]='TITLE_FORBIDDEN_PHRASE_FAMILY';
        if($canon==='beratung'&&self::isRepeatedGenericBeratungSchema($title))$r[]='TITLE_BERATUNG_REPEATED_GENERIC_SCHEMA_FORBIDDEN';
        if($canon==='beratung'&&self::hasSyntheticBeratungFiller($title,$source,$targetKeyword))$r[]='TITLE_BERATUNG_SYNTHETIC_FILLER_FORBIDDEN';
        if(!$isFaq&&self::isKeywordStaccato($title,$type))$r[]='TITLE_KEYWORD_STACCATO_FORBIDDEN';
        if($isJournal&&self::isJournalKeywordStaccatoStrict($title))$r[]='TITLE_JOURNAL_KEYWORD_STACCATO_STRICT_FORBIDDEN';
        $targetKeyword=trim($targetKeyword);
        if($targetKeyword==='')$r[]='TITLE_TARGET_KEYWORD_MISSING';
        // Target keyword meaning is owned by the title/intent decision. No repeat substring veto here.
        return ['ok'=>!$r,'status'=>$r?'TITLE_TECHNICAL_REVIEW':'TITLE_TECHNICAL_PASS','reason_codes'=>array_values(array_unique($r)),'semantic_quality_claimed'=>false,'write_attempted'=>false,'target_keyword'=>$targetKeyword,'ppm_target_keyword_binding_prevalidated'=>false,'keyword_prefix_enforced'=>false,'keyword_position_1_required'=>false,'keyword_coverage_rule'=>'CENTRAL_TITLE_OWNER','validator_contract'=>'PSTE_TECHNICAL_TITLE_VALIDATOR_V11_NATURAL_BERATUNG_FILLER_HARDLOCK'];
    }

    public static function containsKeyword(string $title,string $keyword): bool {
        $title=trim(rtrim($title,'?'));$keyword=trim($keyword);if($title===''||$keyword==='')return false;
        $t=self::lower($title);$k=self::lower($keyword);return function_exists('mb_strpos')?mb_strpos($t,$k,0,'UTF-8')!==false:strpos($t,$k)!==false;
    }

    public static function isKeywordStaccato(string $title,string $type=''): bool {
        $canon=class_exists('PSTE_Article_Type_Registry')?PSTE_Article_Type_Registry::canonicalType($type):'';
        if($canon==='faq'||str_contains($title,'?'))return false;
        $clean=self::lower(trim((string)preg_replace('/\s+/u',' ',rtrim($title,'?'))));
        $parts=preg_split('/\s+/u',$clean)?:[];if(count($parts)<3)return false;
        // Natural German noun phrases are not staccato when they contain a grammatical relation.
        if(preg_match('/\b(?:der|die|das|den|dem|des|ein|eine|einer|einem|einen|mit|für|fuer|ohne|gegen|von|bei|beim|im|in|auf|unter|zum|zur|am|an|als|aus|durch|nach|vor|über|ueber|zwischen|und|oder)\b/u',$clean))return false;
        // Procedural/finite verb surfaces are natural compact titles, not keyword chains.
        if(preg_match('/\b(?:auswähl\w*|auswaehl\w*|wähl\w*|waehl\w*|find\w*|beacht\w*|entscheid\w*|plan\w*|pfleg\w*|reinig\w*|wasch\w*|kost\w*|preis\w*|sicher\w*|installier\w*|montier\w*|anwend\w*|benutz\w*|verwend\w*|nutz\w*|einsetz\w*|lager\w*|aufbewahr\w*|trainier\w*|übung\w*|uebung\w*|ist|sind|kann|können|koennen|soll|sollen|muss|müssen|muessen|eignet|braucht|imprägnier\w*|impraegnier\w*|reparier\w*|trockn\w*|wart\w*|fahr\w*|schütz\w*|schuetz\w*|vermeid\w*|prüf\w*|pruef\w*)\b/u',$clean))return false;
        return true;
    }
    public static function isJournalKeywordStaccatoStrict(string $title): bool {
        $clean=self::lower(trim((string)preg_replace('/\s+/u',' ',rtrim($title,'?'))));
        if($clean===''||str_contains($title,'?'))return false;
        $parts=preg_split('/\s+/u',$clean)?:[];if(count($parts)<4)return false;
        // Existing portal title principle: a natural German surface contains either a grammatical
        // relation/conjunction or an explicit finite/infinitive predicate.  Do not interpret noun
        // compounds such as "Fahrpraxis" as verbs merely because they start with "fahr".
        if(preg_match('/\b(?:der|die|das|den|dem|des|ein|eine|einer|einem|einen|mit|für|fuer|ohne|gegen|von|bei|beim|im|in|auf|unter|zum|zur|am|an|als|aus|durch|nach|vor|über|ueber|zwischen|und|oder)\b/u',$clean))return false;
        if(preg_match('/\b(?:ist|sind|war|waren|wird|werden|hat|haben|kann|können|koennen|darf|dürfen|duerfen|soll|sollen|muss|müssen|muessen|braucht|brauchen|eignet|eignen|lebt|leben|lernt|lernen|schwimmt|schwimmen|versteht|verstehen|füttert|fuettert|füttern|fuettern|pflegt|pflegen|trainiert|trainieren|reitet|reiten|hält|haelt|halten|wählt|waehlt|wählen|waehlen|findet|finden|prüft|prueft|prüfen|pruefen|vermeidet|vermeiden|schützt|schuetzt|schützen|schuetzen|kostet|kosten)\b/u',$clean))return false;
        return true;
    }

    public static function isRepeatedGenericBeratungSchema(string $title): bool {
        $clean=trim((string)preg_replace('/\s+/u',' ',$title));
        return (bool)preg_match('/^Passend(?:e|er|es|en|em)?\s+.+\s+richtig\s+ausw(?:ä|ae)hlen$/iu',$clean);
    }
    public static function hasForbiddenTitlePhraseFamily(string $title): bool {
        return (bool)preg_match('/\b(?:passend\s+ausw(?:ä|ae)hlen|(?:anhand|nach)\s+wichtige(?:n|r)\s+Kriterien\s+ausw(?:ä|ae)hlen|richtig\s+ausw(?:ä|ae)hlen|richtig\s+einordnen|fachlich\s+einordnen)\b/iu',$title);
    }
    public static function hasArtificialGeneratorPhrase(string $title): bool {
        // Global title-surface hardlock. Besides the legacy phrases, this explicitly blocks the
        // complete 0.56.12 Beratung filler bank so a later refactor cannot silently reintroduce
        // technically valid but stiff generator prose.
        return (bool)preg_match('/\b(?:(?:genauer|sorgf(?:ä|ae)ltig|bewusst)\s+(?:pr(?:ü|ue)fen|ausw(?:ä|ae)hlen|w(?:ä|ae)hlen|finden)|fachgerecht\s+umsetzen|sinnvoll\s+einordnen|nach\s+Nutzen\s+und\s+Einsatz\s+beurteilen|nach\s+Nutzen\s+und\s+Anforderungen\s+beurteilen|hinsichtlich\s+Nutzen\s+und\s+Einsatz\s+einordnen|passend\s+zum\s+Bedarf\s+einordnen|nach\s+Bedarf\s+beurteilen|nach\s+Anforderungen\s+beurteilen|passend\s+zum\s+Einsatz\s+einordnen|mit\s+einem\s+klaren\s+Vorgehen|sinnvoll\s+in\s+die\s+Praxis\s+umsetzen|transparent\s+beurteilen|realistisch\s+einordnen|passend\s+zum\s+Bedarf\s+finden|nach\s+Nutzung\s+und\s+Anforderungen\s+w(?:ä|ae)hlen|mit\s+Blick\s+auf\s+Bedarf\s+und\s+Nutzung\s+w(?:ä|ae)hlen|vor\s+der\s+Entscheidung\s+gezielt\s+pr(?:ü|ue)fen|mit\s+den\s+wichtigsten\s+Anforderungen\s+abgleichen|f(?:ü|ue)r\s+den\s+praktischen\s+Einsatz\s+bewerten|f(?:ü|ue)r\s+den\s+vorgesehenen\s+Einsatz\s+pr(?:ü|ue)fen|auf\s+Alltag\s+und\s+Anforderungen\s+abstimmen|vor\s+dem\s+Einsatz\s+systematisch\s+pr(?:ü|ue)fen|an\s+Bedarf\s+und\s+Nutzung\s+ausrichten|auf\s+Einsatz\s+und\s+Bedarf\s+abstimmen|mit\s+den\s+eigenen\s+Anforderungen\s+abgleichen|unter\s+realen\s+Einsatzbedingungen\s+bewerten|nach\s+dem\s+eigenen\s+Nutzungsprofil\s+ausrichten|f(?:ü|ue)r\s+Alltag\s+und\s+Einsatz\s+passend\s+finden|anhand\s+des\s+konkreten\s+Bedarfs\s+bewerten|vor\s+dem\s+Kauf\s+mit\s+dem\s+Bedarf\s+abgleichen|nach\s+Alltag\s+und\s+Einsatzprofil\s+w(?:ä|ae)hlen|vor\s+der\s+Nutzung\s+mit\s+dem\s+Bedarf\s+abgleichen|mit\s+dem\s+eigenen\s+Nutzungsbedarf\s+abgleichen|mit\s+Blick\s+auf\s+Nutzung\s+und\s+Priorit(?:ä|ae)ten\s+bewerten|nach\s+Einsatz\s+und\s+Priorit(?:ä|ae)ten\s+ausrichten|auf\s+den\s+vorgesehenen\s+Zweck\s+abstimmen|f(?:ü|ue)r\s+die\s+vorgesehene\s+Nutzung\s+pr(?:ü|ue)fen)\b/iu',$title);
    }

    public static function hasSyntheticBeratungFiller(string $title,string $source='',string $targetKeyword=''): bool {
        $surface=trim($title);$targetKeyword=trim($targetKeyword);
        if($targetKeyword!==''){
            $surface=(string)preg_replace('/'.preg_quote($targetKeyword,'/').'/iu',' ',$surface,1);
            $surface=trim((string)preg_replace('/\s+/u',' ',$surface));
        }
        if($surface==='')return false;
        if(preg_match('/\bmit\s+Blick\s+auf\b/iu',$surface))return true;
        if(preg_match('/\b(?:Nutzungsprofil|Einsatzprofil|Nutzungsbedarf|vorgesehen(?:e|en|er|es|em)?)\b/iu',$surface))return true;
        if(preg_match('/\b(?:systematisch|gezielt)\s+pr(?:ü|ue)fen\b/iu',$surface))return true;
        $abstract=preg_match_all('/\b(?:Bedarf|Nutzung|Anforderung(?:en)?|Priorit(?:ä|ae)t(?:en)?)\b/iu',$surface,$m);
        $office=preg_match('/\b(?:abgleich\w*|ausricht\w*|abstimm\w*|bewert\w*|beurteil\w*|einordn\w*)\b/iu',$surface);
        return $abstract>=2||($abstract>=1&&$office);
    }
    private static function lower(string $v): string{return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
}
