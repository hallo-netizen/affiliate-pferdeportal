<?php
if (!defined('ABSPATH')) { return; }

/** Durable one-step-at-a-time longtail research job. Execution is owned by PSTE_Research_Driver. */
final class PSTE_Research_Job {
    private static string $activeStepFenceToken='';
    private static function traceActiveJobRead(string $event,$job=null): void {
        $driver=get_option(PSTE_OPTION_RESEARCH_DRIVER_LOCK,[]);
        $queue=get_option(PSTE_OPTION_BREADTH_RESEARCH_LOCK,[]);
        $step=get_option(PSTE_OPTION_RESEARCH_STEP_LOCK,[]);
        $frames=array_slice(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS),1,7);
        $stack=[];foreach($frames as $f){$stack[]=(isset($f['class'])?$f['class'].'::':'').(string)($f['function']??'');}
        $uri=(string)($_SERVER['REQUEST_URI']??'CLI');
        error_log('PSTE_READTRACE event='.$event.' t='.sprintf('%.6f',microtime(true)).' pid='.getmypid().
            ' uuid='.(is_array($job)?(string)($job['job_uuid']??''):'NONE').
            ' sha='.(is_array($job)?(string)($job['sha256']??''):'NONE').
            ' phase='.(is_array($job)?(string)($job['phase']??''):'NONE').
            ' phase_state='.(is_array($job)?(string)($job['phase_state']??''):'NONE').
            ' status='.(is_array($job)?(string)($job['status']??''):'NONE').
            ' uri='.base64_encode($uri).
            ' driver_lock='.(is_array($driver)?(string)($driver['token']??''):'NONE').
            ' queue_lock='.(is_array($queue)?(string)($queue['token']??''):'NONE').
            ' job_lock='.(is_array($step)?(string)($step['token']??''):'NONE').
            ' stack='.base64_encode(implode('>',$stack)));
    }

    public const CONTRACT='PSTE_AUTOMATIC_LONGTAIL_RESEARCH_JOB_V2';
    public const VERSION='2.6.0';
    private const COMPATIBLE_VERSIONS=['2.1.0','2.2.0','2.3.0','2.4.0','2.5.0','2.6.0'];
    private const PROVIDER_STEPS=3;
    private const LEGACY_PAA_PROVIDER_STEPS=4;
    private const STEP_LOCK_TTL=90;
    private const IN_FLIGHT_UNKNOWN_AFTER=75;
    private const PROVIDER_SAFE_RETRY_LIMIT=1;
    private const TRANSIENT_COORDINATION_CODES=['PSTE_SANDBOX_LOCKED','PSTE_BUDGET_RESERVATION_LOCKED'];
    private const REPLAY_SAFE_LOCAL_FINALIZE_CODES=['PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_RAW_MISMATCH','PSTE_SANDBOX_DATAFLOW_PORTAL_COMPONENT_DRIFT','PSTE_SNAPSHOT_STALE_OR_CHANGED','PSTE_RESEARCH_FINALIZE_PREPARE_COUNT_MISMATCH'];
    private const FINALIZE_BATCH=5;
    private const FINALIZE_STALL_LIMIT=8;

    public static function start(int $categoryId,string $seed,array $settings,array $owner=[]): array {
        PSTE_Plugin::assertReady();$launchToken=self::acquireLaunchLock();
        try{
        $ownerKind=strtoupper(trim((string)($owner['kind']??'SINGLE')));
        if(!in_array($ownerKind,['SINGLE','BREADTH'],true))throw new RuntimeException('PSTE_RESEARCH_OWNER_KIND_INVALID');
        $ownerQueueUuid=$ownerKind==='BREADTH'?trim((string)($owner['queue_uuid']??'')):'';
        $ownerItemIndex=$ownerKind==='BREADTH'?(int)($owner['item_index']??-1):-1;
        if($ownerKind==='BREADTH'&&($ownerQueueUuid===''||$ownerItemIndex<0))throw new RuntimeException('PSTE_RESEARCH_BREADTH_OWNER_INVALID');
        if($ownerKind==='SINGLE'&&class_exists('PSTE_Breadth_Research_Queue')){
            try{$breadth=PSTE_Breadth_Research_Queue::peek();}catch(Throwable $e){throw new RuntimeException('PSTE_RESEARCH_START_BREADTH_STATE_INVALID');}
            if(is_array($breadth)&&in_array((string)($breadth['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_RESEARCH_START_BLOCKED_BY_ACTIVE_BREADTH');
        }
        PSTE_Repository::assertOwnJsonStorageReady();
        PSTE_Repository::repairInvalidTopicPayloads();
        if(empty($settings['feature_enabled']))throw new RuntimeException('PSTE_FEATURE_DISABLED');
        if(!PSTE_Credentials::configured())throw new RuntimeException('PSTE_CREDENTIALS_MISSING');
        $seed=trim($seed);if($categoryId<=0||strlen($seed)<3)throw new RuntimeException('PSTE_RESEARCH_INPUT_INVALID');
        if(self::rawJob()!==null)throw new RuntimeException('PSTE_RESEARCH_JOB_ALREADY_ACTIVE');
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        $rebase=PSTE_Snapshot::rebaseResearchBaselineIfSafe($baseline);
        if(empty($rebase['ok']))throw new RuntimeException((string)($rebase['error_code']??'PSTE_SITE_BASELINE_STALE'));
        $baseline=(array)$rebase['baseline'];
        $selected=PSTE_Category_Context::selectedCategory($categoryId,$baseline);$categoryId=(int)$selected['term_id'];
        $run=PSTE_Runner::createRunSkeleton($categoryId,$seed,$settings);
        $context=PSTE_Category_Context::researchContext($seed,$selected,(array)($run['snapshot']['structure']['items']??[]),function_exists('get_bloginfo')?(string)get_bloginfo('name'):'');
        $uuid=wp_generate_uuid4();$now=gmdate('c');
        $run['run_uuid']=$uuid;$run['status']='RESEARCH_RUNNING';$run['payload']['research_context']=$context;$run['payload']['selected_category']=$selected;
        $run['payload']['execution_mode']='SERVER_STEP_DRIVER_V1';$run['payload']['provider_calls']=self::PROVIDER_STEPS;$run['payload']['provider_steps_completed']=0;$run['payload']['questions_required']=true;$run['payload']['questions_state']='NOT_STARTED';$run['payload']['questions_transport']='ASYNC_DATAFORSEO_TASK';$run['payload']['manual_followup_steps_required']=0;
        $job=[
            'contract'=>self::CONTRACT,'version'=>self::VERSION,'job_uuid'=>$uuid,'status'=>'RUNNING','phase'=>'KEYWORD_SUGGESTIONS','phase_state'=>'IDLE',
            'progress'=>0,'total_provider_steps'=>self::PROVIDER_STEPS,'category_id'=>$categoryId,'seed'=>$seed,
            'environment'=>(string)$settings['environment'],'location'=>(string)$settings['location'],'language'=>(string)$settings['language'],
            'estimated_cost'=>(float)$run['estimated_cost'],'actual_cost'=>0.0,'budget_reserved'=>false,'selected_category'=>$selected,'research_context'=>$context,
            'snapshot'=>$run['snapshot'],'sources'=>[],'questions_required'=>true,'questions_state'=>'NOT_STARTED','questions_transport'=>'ASYNC_DATAFORSEO_TASK',
            'owner_kind'=>$ownerKind,'owner_queue_uuid'=>$ownerQueueUuid,'owner_item_index'=>$ownerItemIndex,
            'last_error'=>'','created_at_utc'=>$now,'updated_at_utc'=>$now,'run_created_at'=>(string)$run['created_at'],
        ];
        $job=self::withHash($job);if(!add_option(PSTE_OPTION_ACTIVE_RESEARCH_JOB,$job,'',false))throw new RuntimeException('PSTE_RESEARCH_JOB_ALREADY_ACTIVE');
        try{
            PSTE_Budget_Reservations::reserve($uuid,(float)$job['estimated_cost'],$settings,'CATEGORY_LONGTAIL_RESEARCH',1800);$job['budget_reserved']=true;$job['updated_at_utc']=gmdate('c');self::save($job);PSTE_Repository::saveRun($run);return self::summary($job);
        }catch(Throwable $e){try{PSTE_Budget_Reservations::release($uuid);}catch(Throwable $ignored){}self::deleteIfSame($job);throw $e;}
        }finally{self::releaseLaunchLock($launchToken);}
    }

    public static function advance(string $jobUuid,array $settings,bool $explicitResume=false): array {self::traceActiveJobRead('ADVANCE_ENTER',null);
        PSTE_Plugin::assertReady();
        $token=self::acquireStepLock();self::traceActiveJobRead('ADVANCE_AFTER_JOB_LOCK',null);self::$activeStepFenceToken=$token;
        try{
            PSTE_Repository::assertOwnJsonStorageReady();
            PSTE_Repository::repairInvalidTopicPayloads();
            $job=self::load();if(!hash_equals((string)$job['job_uuid'],trim($jobUuid)))throw new RuntimeException('PSTE_RESEARCH_JOB_ID_MISMATCH');
            if((string)$job['status']==='OUTCOME_UNKNOWN')return self::summary($job);
            if((string)$job['status']==='PAUSED_ERROR'){
                $pausedCode=(string)($job['last_error']??'');
                if(self::isTransientCoordinationCode($pausedCode)){$job=self::recoverTransientCoordinationPause($job,$pausedCode);}
                elseif($pausedCode==='PSTE_SITE_BASELINE_STALE'){$job=self::recoverSafeSiteContextPause($job);}
                elseif(self::isReplaySafeLocalFinalizeCode($pausedCode)&&self::canReplayLocalFinalize($job)){$job=self::recoverReplaySafeLocalFinalizePause($job,$pausedCode);}
                elseif(!$explicitResume)return self::summary($job);
                else{$job['status']='RUNNING';$job['last_error']='';$job['phase_state']='IDLE';unset($job['coordination_wait_code'],$job['coordination_wait_since_utc']);$job['updated_at_utc']=gmdate('c');self::save($job);}
            }
            if((string)$job['status']!=='RUNNING')return self::summary($job);
            $phase=(string)$job['phase'];$version=(string)($job['version']??'');
            if((string)$job['phase_state']==='IN_FLIGHT'){
                $cached=self::peekPhaseResponse($job);
                if(is_array($cached))return self::runProviderStep($job,$cached);
                $age=time()-(strtotime((string)$job['updated_at_utc'])?:time());if($age>=self::IN_FLIGHT_UNKNOWN_AFTER){$job['status']='OUTCOME_UNKNOWN';$job['last_error']='PSTE_PROVIDER_TRANSPORT_OUTCOME_UNKNOWN';$job['updated_at_utc']=gmdate('c');self::save($job);}return self::summary($job);
            }
            if(in_array($phase,['KEYWORD_SUGGESTIONS','RELATED_KEYWORDS','KEYWORD_IDEAS'],true)){
                try{$job=self::ensureInputsCurrent($job);self::ensureReservation($job,$settings);}catch(Throwable $e){$code=self::errorCode($e);if(self::isTransientCoordinationCode($code))return self::coordinationWait($job,$code);$job['status']='PAUSED_ERROR';$job['phase_state']='IDLE';$job['last_error']=$code;$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);}
                return self::runProviderStep($job);
            }
            if($phase==='PEOPLE_ALSO_ASK'){
                if(in_array($version,['2.4.0','2.5.0'],true))return self::advanceQuestionsTask($job,$settings,true);
                if($version==='2.3.0'){
                    try{$job=self::ensureInputsCurrent($job);self::ensureReservation($job,$settings);}catch(Throwable $e){$code=self::errorCode($e);if(self::isTransientCoordinationCode($code))return self::coordinationWait($job,$code);$job['status']='PAUSED_ERROR';$job['phase_state']='IDLE';$job['last_error']=$code;$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);}
                    return self::runProviderStep($job);
                }
                throw new RuntimeException('PSTE_RESEARCH_JOB_PHASE_INVALID');
            }
            if($phase==='QUESTIONS')return self::advanceQuestionsTask($job,$settings,false);
            if($phase==='FINALIZE'){try{$job=self::ensureInputsCurrent($job);}catch(Throwable $e){$code=self::errorCode($e);if(self::isTransientCoordinationCode($code))return self::finalizeCoordinationWait($job,$code);$job['status']='PAUSED_ERROR';$job['phase_state']='IDLE';$job['last_error']=$code;$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);}return self::finalize($job);}
            throw new RuntimeException('PSTE_RESEARCH_JOB_PHASE_INVALID');
        }finally{self::releaseStepLock($token);}
    }

    /**
     * Lossless park/cancel after an explicit provider-account check. The complete job is
     * archived and verified before the active pointer is removed.
     */
    public static function cancelAfterProviderCheck(string $jobUuid,bool $confirmed): array {
        PSTE_Plugin::assertReady();if(!$confirmed)throw new RuntimeException('PSTE_PROVIDER_CHECK_CONFIRMATION_REQUIRED');$token=self::acquireStepLock();
        try{$job=self::load();if(!hash_equals((string)$job['job_uuid'],trim($jobUuid)))throw new RuntimeException('PSTE_RESEARCH_JOB_ID_MISMATCH');if(!in_array((string)$job['status'],['OUTCOME_UNKNOWN','PAUSED_ERROR'],true))throw new RuntimeException('PSTE_RESEARCH_JOB_CANCEL_NOT_ALLOWED');return self::parkLoaded($job,'PSTE_CANCELLED_AFTER_PROVIDER_CHECK',['cancel_reason'=>'PROVIDER_CHECK_CONFIRMED']);}finally{self::releaseStepLock($token);}
    }

    /**
     * Losslessly park an active child because its owning breadth queue was explicitly stopped.
     * No provider request is created here. A locally persisted provider response is finalized first.
     */
    public static function cancelForBreadthStop(string $jobUuid): array {
        PSTE_Plugin::assertReady();$token=self::acquireStepLock();
        try{
            $job=self::load();if(!hash_equals((string)$job['job_uuid'],trim($jobUuid)))throw new RuntimeException('PSTE_RESEARCH_JOB_ID_MISMATCH');
            return self::parkLoaded($job,'PSTE_CANCELLED_BY_BREADTH_STOP',['cancel_reason'=>'BREADTH_STOP']);
        }finally{self::releaseStepLock($token);}
    }

    /**
     * Park the current job without losing any researched/source/finalize data.
     * Safe for PAUSED_ERROR/OUTCOME_UNKNOWN and for RUNNING states only when no provider request is IN_FLIGHT.
     * The archive is hash/readback verified before the active option is removed.
     */
    public static function parkCurrent(string $jobUuid,string $reason,array $context=[]): array {
        PSTE_Plugin::assertReady();$token=self::acquireStepLock();
        try{$job=self::load();if(!hash_equals((string)$job['job_uuid'],trim($jobUuid)))throw new RuntimeException('PSTE_RESEARCH_JOB_ID_MISMATCH');return self::parkLoaded($job,$reason,$context);}finally{self::releaseStepLock($token);}
    }

    private static function parkLoaded(array $job,string $reason,array $context=[]): array {
        $status=(string)($job['status']??'');$phaseState=(string)($job['phase_state']??'');
        if(!in_array($status,['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_RESEARCH_PARK_STATUS_INVALID');
        if($phaseState==='IN_FLIGHT'&&$status!=='OUTCOME_UNKNOWN')throw new RuntimeException('PSTE_RESEARCH_PARK_WAIT_IN_FLIGHT');
        if($phaseState==='PERSISTING'){
            $before=(int)($job['progress']??0);self::runProviderStep($job);$job=self::load();
            if((string)($job['status']??'')==='OUTCOME_UNKNOWN')throw new RuntimeException('PSTE_RESEARCH_PARK_PROVIDER_OUTCOME_UNKNOWN');
            if((int)($job['progress']??0)<=$before)throw new RuntimeException('PSTE_RESEARCH_PARK_LOCAL_PERSISTENCE_NOT_FINALIZED');
        }
        // Preserve the exact validated active job in the immutable archive first.
        $archive=PSTE_Research_Archive::store($job,$reason,$context);
        $read=PSTE_Research_Archive::get((string)$job['job_uuid']);
        if(!is_array($read)||!hash_equals((string)($archive['sha256']??''),(string)($read['sha256']??'')))throw new RuntimeException('PSTE_RESEARCH_PARK_ARCHIVE_VERIFY_FAILED');
        try{PSTE_Budget_Reservations::release((string)$job['job_uuid']);}catch(Throwable $ignored){}
        // Record the terminal operational disposition in the run, but never mutate the archived raw job.
        $progress=$job;$progress['status']='PARKED';$progress['budget_reserved']=false;$progress['last_error']=self::errorCode(new RuntimeException($reason));$progress['updated_at_utc']=gmdate('c');
        self::saveProgressRun($progress);
        self::deleteIfSame($job);
        if(self::rawJob()!==null)throw new RuntimeException('PSTE_RESEARCH_PARK_ACTIVE_POINTER_NOT_CLEARED');
        return ['contract'=>'PSTE_RESEARCH_PARK_RESULT_V1','status'=>'PARKED','job_uuid'=>(string)$job['job_uuid'],'archive'=>$archive,'reason'=>(string)$archive['park_reason'],'progress'=>(int)($job['progress']??0),'phase'=>(string)($job['phase']??''),'phase_state'=>(string)($job['phase_state']??''),'actual_cost'=>(float)($job['actual_cost']??0.0)];
    }

    public static function current(): ?array {self::traceActiveJobRead('CURRENT_ENTER',null);
        $job=self::rawJob();
        if($job===null){
            PSTE_Runner::repairLatestCompletedResearchRunReadbackIfNeeded();
            return null;
        }
        self::assertJob($job);
        if((string)($job['status']??'')==='PAUSED_ERROR'){
            $code=(string)($job['last_error']??'');
            if(self::isTransientCoordinationCode($code))$job=self::recoverTransientCoordinationPause($job,$code);
            elseif($code==='PSTE_SITE_BASELINE_STALE')$job=self::recoverSafeSiteContextPause($job);
            elseif(self::isReplaySafeLocalFinalizeCode($code)&&self::canReplayLocalFinalize($job))$job=self::recoverReplaySafeLocalFinalizePause($job,$code);
        }
        return self::summary($job);
    }


    /** Strictly read-only status for transport readback. Never recovers, resumes or advances work. */
    public static function peek(): ?array {
        $job=self::rawJob();if($job===null)return null;self::assertJob($job);return self::summary($job);
    }

    /** Read-only state of the short server-step lock. */
    public static function stepLockStatus(): array {
        $raw=get_option(PSTE_OPTION_RESEARCH_STEP_LOCK,[]);if(!is_array($raw)||empty($raw['token']))return ['locked'=>false,'expires_at'=>0,'retry_after_ms'=>0,'expired_owner'=>false];
        $expires=(int)($raw['expires_at']??0);$now=time();$locked=$expires>=$now;
        return ['locked'=>$locked,'expires_at'=>$expires,'retry_after_ms'=>$locked?max(750,min(3000,($expires-$now+1)*1000)):0,'expired_owner'=>!$locked&&$expires>0];
    }


    private static function advanceQuestionsTask(array $job,array $settings,bool $legacyVisibleStep): array {
        $uuid=(string)$job['job_uuid'];$seed=(string)($job['research_context']['effective_seed']??$job['seed']);
        try{
            $job=self::ensureInputsCurrent($job);self::ensureReservation($job,$settings);$client=new PSTE_DataForSEO_Client((string)$job['environment']);$cached=$client->peekPeopleAlsoAsk($seed,(string)$job['location'],(string)$job['language'],4);if(is_array($cached))return self::persistQuestionsResponse($job,$cached,$legacyVisibleStep);
            $taskId=trim((string)($job['paa_task_id']??''));
            if($taskId===''){$posted=$client->postPeopleAlsoAskTask($seed,(string)$job['location'],(string)$job['language'],4);$job=self::load();$job['paa_task_id']=(string)$posted['task_id'];$job['paa_task_cost_usd']=max(0.0,(float)($posted['cost']??0.0));$job['paa_task_posted_at_utc']=(string)($posted['posted_at_utc']??gmdate('c'));$job['phase_state']='TASK_PENDING';if(!$legacyVisibleStep)$job['questions_state']='TASK_PENDING';$job['coordination_wait_code']='PSTE_PAA_TASK_PENDING';$job['coordination_wait_since_utc']=gmdate('c');$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);}
            $postedAt=strtotime((string)($job['paa_task_posted_at_utc']??''));if($postedAt!==false&&time()-$postedAt>1800){$job['status']='PAUSED_ERROR';$job['phase_state']='TASK_PENDING';if(!$legacyVisibleStep)$job['questions_state']='ERROR';$job['last_error']='PSTE_PAA_TASK_TIMEOUT';unset($job['coordination_wait_code'],$job['coordination_wait_since_utc']);$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);}
            if(!$client->peopleAlsoAskTaskReady($taskId)){$job=self::load();$job['phase_state']='TASK_PENDING';if(!$legacyVisibleStep)$job['questions_state']='TASK_PENDING';$job['coordination_wait_code']='PSTE_PAA_TASK_PENDING';if(empty($job['coordination_wait_since_utc']))$job['coordination_wait_since_utc']=gmdate('c');$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);}
            $response=$client->getPeopleAlsoAskTask($taskId,$seed,(string)$job['location'],(string)$job['language'],4);$job=self::load();return self::persistQuestionsResponse($job,$response,$legacyVisibleStep);
        }catch(Throwable $e){$code=self::errorCode($e);$job=self::load();$job['status']=$code==='PSTE_PROVIDER_TRANSPORT_OUTCOME_UNKNOWN'?'OUTCOME_UNKNOWN':'PAUSED_ERROR';$job['phase_state']=$job['status']==='OUTCOME_UNKNOWN'?'TASK_UNKNOWN':((string)($job['paa_task_id']??'')!==''?'TASK_PENDING':'IDLE');if(!$legacyVisibleStep)$job['questions_state']='ERROR';$job['last_error']=$code;unset($job['coordination_wait_code'],$job['coordination_wait_since_utc']);$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);}
    }


    private static function persistQuestionsResponse(array $job,array $response,bool $legacyVisibleStep): array {
        $uuid=(string)$job['job_uuid'];$source='PAA';$meta=self::providerMeta($legacyVisibleStep?'PEOPLE_ALSO_ASK':'QUESTIONS',(string)($job['version']??self::VERSION));$items=array_values(PSTE_DataForSEO_Client::extractPeopleAlsoAskQuestions($response));$responseHash=PSTE_DataForSEO_Client::responseSha256($response);$captured=PSTE_DataForSEO_Client::retrievedAtUtc($response);$root=(string)($job['research_context']['effective_seed']??$job['seed']);
        foreach($items as $index=>&$item){$raw=(string)($item['keyword']??'');$itemSource=trim((string)($item['source_class']??'PAA'));if($itemSource==='')$itemSource='PAA';$depth=(int)($item['depth']??1);$seedQuestion=trim((string)($item['seed_question']??''));$parent=$seedQuestion!==''?'obs:'.substr(hash('sha256',$uuid.'|PAA-SEED|'.$seedQuestion),0,32):'';$item['observation']=['observation_id'=>'obs:'.substr(hash('sha256',$uuid.'|'.$itemSource.'|'.$index.'|'.$raw.'|'.$responseHash),0,32),'canonical_term_id'=>'','source_class'=>$itemSource,'provider'=>'DATAFORSEO_SERP','query_kind'=>$itemSource,'root_query'=>$root,'parent_observation_id'=>$parent,'depth'=>$depth,'raw_value'=>$raw,'locale'=>(string)$job['location'],'language'=>(string)$job['language'],'parameters'=>['path'=>(string)$meta['path'],'limit'=>null,'depth_limit'=>4,'branch_limit'=>null,'people_also_ask_click_depth'=>4],'retrieved_at_utc'=>$captured,'raw_response_sha256'=>$responseHash,'measurement_status'=>'UNMEASURED','relation'=>$itemSource==='PAA_RELATED'?'QUESTION_BRANCH':'GOOGLE_PAA','relation_evidence'=>[$itemSource],'freshness_status'=>'CURRENT','valid_until'=>gmdate('c',(strtotime($captured)?:time())+90*86400)];}unset($item);
        $stored=(array)($job['sources'][$source]??[]);if(empty($stored['accounting_complete'])){$stored=['path'=>(string)$meta['path'],'response_sha256'=>$responseHash,'items'=>$items,'cost'=>max(0.0,(float)($job['paa_task_cost_usd']??PSTE_Runner::responseCost($response))),'captured_at_utc'=>$captured,'accounting_complete'=>false,'sanitized_summary'=>PSTE_DataForSEO_Client::sanitizedSummary($response)];$job['sources'][$source]=$stored;self::save($job);PSTE_Repository::saveEvidence($uuid,$source,(string)$meta['path'],(array)$stored['sanitized_summary'],(string)$stored['response_sha256']);PSTE_Repository::recordCostOnce($uuid,(string)$meta['ledger'],PSTE_Cost_Guard::estimate((string)$meta['rate'],1,0),(float)$stored['cost']);$stored['accounting_complete']=true;$job['sources'][$source]=$stored;}
        $job['actual_cost']=0.0;foreach((array)$job['sources'] as $saved)if(!empty($saved['accounting_complete']))$job['actual_cost']+=(float)($saved['cost']??0.0);$job['actual_cost']=round($job['actual_cost'],6);if($legacyVisibleStep)$job['progress']=(int)$job['progress']+1;else $job['questions_state']='COMPLETE';$job['phase']='FINALIZE';$job['phase_state']='IDLE';$job['last_error']='';unset($job['coordination_wait_code'],$job['coordination_wait_since_utc'],$job['paa_task_id'],$job['paa_task_cost_usd'],$job['paa_task_posted_at_utc']);$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);
    }

    private static function runProviderStep(array $job,?array $recoveredResponse=null): array {
        $phase=(string)$job['phase'];$version=(string)($job['version']??self::VERSION);$meta=self::providerMeta($phase,$version);$source=(string)$meta['source'];$uuid=(string)$job['job_uuid'];
        try{
            $stored=(array)($job['sources'][$source]??[]);
            if(empty($stored['response_sha256'])||!is_array($stored['items']??null)){
                $response=$recoveredResponse;if($response===null)$response=self::peekPhaseResponse($job);if($response===null){$job['phase_state']='IN_FLIGHT';$job['provider_call_expected_fresh']=true;$job['updated_at_utc']=gmdate('c');self::save($job);$response=self::fetchPhaseResponse($job);}
                $isPaa=$phase==='PEOPLE_ALSO_ASK';$items=$isPaa?array_values(PSTE_DataForSEO_Client::extractPeopleAlsoAskQuestions($response)):array_values(array_slice(PSTE_DataForSEO_Client::extractKeywords($response),0,1000));
                $responseHash=PSTE_DataForSEO_Client::responseSha256($response);$captured=PSTE_DataForSEO_Client::retrievedAtUtc($response);$root=(string)($job['research_context']['effective_seed']??$job['seed']);
                foreach($items as $index=>&$item){$raw=(string)($item['keyword']??'');$itemSource=trim((string)($item['source_class']??$source));if($itemSource==='')$itemSource=$source;$depth=(int)($item['depth']??($phase==='KEYWORD_IDEAS'?2:1));$seedQuestion=trim((string)($item['seed_question']??''));$parent=$seedQuestion!==''?'obs:'.substr(hash('sha256',$uuid.'|PAA-SEED|'.$seedQuestion),0,32):($depth===2?'obs:'.substr(hash('sha256',$uuid.'|ROOT|'.$root),0,32):'');$item['observation']=['observation_id'=>'obs:'.substr(hash('sha256',$uuid.'|'.$itemSource.'|'.$index.'|'.$raw.'|'.$responseHash),0,32),'canonical_term_id'=>'','source_class'=>$itemSource,'provider'=>$isPaa?'DATAFORSEO_SERP':'DATAFORSEO_LABS','query_kind'=>$itemSource,'root_query'=>$root,'parent_observation_id'=>$parent,'depth'=>$depth,'raw_value'=>$raw,'locale'=>(string)$job['location'],'language'=>(string)$job['language'],'parameters'=>['path'=>(string)$meta['path'],'limit'=>$isPaa?null:100,'depth_limit'=>$isPaa?4:2,'branch_limit'=>$isPaa?null:20,'people_also_ask_click_depth'=>$isPaa?4:null],'retrieved_at_utc'=>$captured,'raw_response_sha256'=>$responseHash,'measurement_status'=>is_numeric($item['search_volume']??null)?'MEASURED':'UNMEASURED','relation'=>$itemSource==='PAA_RELATED'?'QUESTION_BRANCH':($itemSource==='PAA'?'GOOGLE_PAA':($source==='RELATED_SEARCH'?'RELATED_ENTITY':($source==='KEYWORD_IDEA'?'NARROWER_TOPIC':'DISCOVERED'))),'relation_evidence'=>[$itemSource],'freshness_status'=>'CURRENT','valid_until'=>gmdate('c',(strtotime($captured)?:time())+90*86400)];}unset($item);
                $cost=$isPaa&&isset($job['paa_task_cost_usd'])?max(0.0,(float)$job['paa_task_cost_usd']):PSTE_Runner::responseCost($response);if(!empty($job['provider_call_expected_fresh'])&&PSTE_DataForSEO_Client::cacheHit($response))$cost=(float)(PSTE_DataForSEO_Client::externalResponse($response)['cost']??0.0);$cost+=max(0.0,(float)($job['provider_retry_known_cost_usd']??0.0));
                $stored=['path'=>(string)$meta['path'],'response_sha256'=>$responseHash,'items'=>$items,'cost'=>$cost,'captured_at_utc'=>$captured,'accounting_complete'=>false,'sanitized_summary'=>PSTE_DataForSEO_Client::sanitizedSummary($response)];$job['sources'][$source]=$stored;unset($job['provider_call_expected_fresh']);$job['phase_state']='PERSISTING';$job['updated_at_utc']=gmdate('c');self::save($job);
            }
            $stored=(array)$job['sources'][$source];PSTE_Repository::saveEvidence($uuid,$source,(string)$meta['path'],(array)($stored['sanitized_summary']??[]),(string)$stored['response_sha256']);$billingItems=$phase==='PEOPLE_ALSO_ASK'?0:100;PSTE_Repository::recordCostOnce($uuid,(string)$meta['ledger'],PSTE_Cost_Guard::estimate((string)$meta['rate'],1,$billingItems),(float)($stored['cost']??0.0));$stored['accounting_complete']=true;$job['sources'][$source]=$stored;$job['actual_cost']=0.0;foreach((array)$job['sources'] as $saved)if(!empty($saved['accounting_complete']))$job['actual_cost']+=(float)($saved['cost']??0.0);
            $job['actual_cost']=round($job['actual_cost'],6);$job['progress']=(int)$job['progress']+1;$job['phase']=(string)$meta['next'];$job['phase_state']='IDLE';$job['last_error']='';unset($job['coordination_wait_code'],$job['coordination_wait_since_utc'],$job['provider_retry_count'],$job['provider_retry_known_cost_usd']);if($phase==='PEOPLE_ALSO_ASK')unset($job['paa_task_id'],$job['paa_task_cost_usd'],$job['paa_task_posted_at_utc']);$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);
        }catch(Throwable $e){
            $code=self::errorCode($e);$job=self::load();
            if(self::isSafeProviderRetryCode($code)&&(int)($job['provider_retry_count']??0)<self::PROVIDER_SAFE_RETRY_LIMIT){
                $known=0.0;if($e instanceof PSTE_Provider_Exception){$details=$e->safeDetails();$known=max(0.0,(float)($details['response_cost']??0.0));}
                $job['provider_retry_count']=(int)($job['provider_retry_count']??0)+1;
                $job['provider_retry_known_cost_usd']=round(max(0.0,(float)($job['provider_retry_known_cost_usd']??0.0))+$known,6);
                $job['status']='RUNNING';$job['phase_state']='RETRY_PENDING';$job['last_error']='';$job['coordination_wait_code']='PSTE_PROVIDER_SAFE_RETRY_PENDING';$job['coordination_wait_since_utc']=gmdate('c');$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);
            }
            $job['status']=$code==='PSTE_PROVIDER_TRANSPORT_OUTCOME_UNKNOWN'?'OUTCOME_UNKNOWN':'PAUSED_ERROR';$job['phase_state']=$job['status']==='OUTCOME_UNKNOWN'?'IN_FLIGHT':'IDLE';$job['last_error']=$code;$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);
        }
    }

    private static function isSafeProviderRetryCode(string $code): bool {return in_array($code,['PSTE_PROVIDER_HTTP_ERROR_429','PSTE_PROVIDER_HTTP_ERROR_500','PSTE_PROVIDER_HTTP_ERROR_503','PSTE_PROVIDER_TASK_ERROR_40101','PSTE_PROVIDER_TASK_ERROR_40103','PSTE_PROVIDER_TASK_ERROR_50401'],true);}

    private static function fetchPhaseResponse(array $job): array {
        $client=new PSTE_DataForSEO_Client((string)$job['environment']);$phase=(string)$job['phase'];$seed=(string)($job['research_context']['effective_seed']??$job['seed']);
        if($phase==='KEYWORD_SUGGESTIONS')return method_exists($client,'keywordSuggestionsDriverStep')?$client->keywordSuggestionsDriverStep($seed,(string)$job['location'],(string)$job['language'],100):$client->keywordSuggestions($seed,(string)$job['location'],(string)$job['language'],100);
        if($phase==='RELATED_KEYWORDS')return method_exists($client,'relatedKeywordsDriverStep')?$client->relatedKeywordsDriverStep($seed,(string)$job['location'],(string)$job['language'],100):$client->relatedKeywords($seed,(string)$job['location'],(string)$job['language'],100);
        if($phase==='KEYWORD_IDEAS')return method_exists($client,'keywordIdeasDriverStep')?$client->keywordIdeasDriverStep(self::discoverySeeds($job),(string)$job['location'],(string)$job['language'],100):$client->keywordIdeas(self::discoverySeeds($job),(string)$job['location'],(string)$job['language'],100);
        if($phase==='PEOPLE_ALSO_ASK')return $client->peopleAlsoAsk($seed,(string)$job['location'],(string)$job['language'],4);
        throw new RuntimeException('PSTE_RESEARCH_PROVIDER_PHASE_INVALID');
    }

    private static function peekPhaseResponse(array $job): ?array {
        $client=new PSTE_DataForSEO_Client((string)$job['environment']);$phase=(string)$job['phase'];$seed=(string)($job['research_context']['effective_seed']??$job['seed']);
        if($phase==='KEYWORD_SUGGESTIONS')return $client->peekKeywordSuggestions($seed,(string)$job['location'],(string)$job['language'],100);
        if($phase==='RELATED_KEYWORDS')return $client->peekRelatedKeywords($seed,(string)$job['location'],(string)$job['language'],100);
        if($phase==='KEYWORD_IDEAS')return $client->peekKeywordIdeas(self::discoverySeeds($job),(string)$job['location'],(string)$job['language'],100);
        if(in_array($phase,['PEOPLE_ALSO_ASK','QUESTIONS'],true))return $client->peekPeopleAlsoAsk($seed,(string)$job['location'],(string)$job['language'],4);
        return null;
    }

    private static function providerMeta(string $phase,string $version=self::VERSION): array {
        $keywordIdeasNext=in_array($version,['2.1.0','2.2.0'],true)?'FINALIZE':(in_array($version,['2.3.0','2.4.0','2.5.0'],true)?'PEOPLE_ALSO_ASK':'QUESTIONS');
        return match($phase){
            'KEYWORD_SUGGESTIONS'=>['source'=>'KEYWORD_SUGGESTION','path'=>'dataforseo_labs/google/keyword_suggestions/live','ledger'=>'keyword_suggestions','rate'=>'labs_keyword_suggestions_live','next'=>'RELATED_KEYWORDS'],
            'RELATED_KEYWORDS'=>['source'=>'RELATED_SEARCH','path'=>'dataforseo_labs/google/related_keywords/live','ledger'=>'related_keywords','rate'=>'labs_related_keywords_live','next'=>'KEYWORD_IDEAS'],
            'KEYWORD_IDEAS'=>['source'=>'KEYWORD_IDEA','path'=>'dataforseo_labs/google/keyword_ideas/live','ledger'=>'keyword_ideas','rate'=>'labs_keyword_ideas_live','next'=>$keywordIdeasNext],
            'PEOPLE_ALSO_ASK'=>['source'=>'PAA','path'=>in_array($version,['2.4.0','2.5.0'],true)?'serp/google/organic/task_post+task_get/advanced':'serp/google/organic/live/advanced','ledger'=>'people_also_ask','rate'=>'serp_google_organic_live_paa_depth4_guard','next'=>'FINALIZE'],
            'QUESTIONS'=>['source'=>'PAA','path'=>'serp/google/organic/task_post+task_get/advanced','ledger'=>'people_also_ask','rate'=>'serp_google_organic_live_paa_depth4_guard','next'=>'FINALIZE'],
            default=>throw new RuntimeException('PSTE_RESEARCH_PROVIDER_PHASE_INVALID'),
        };
    }

    /** @return list<string> */
    private static function discoverySeeds(array $job): array {
        // Research-depth selection only. The SEO provider keyword itself remains the
        // sole keyword/longtail authority; no title token or synthetic phrase is added here.
        $rows=[];
        foreach(['KEYWORD_SUGGESTION','RELATED_SEARCH'] as $source){
            foreach((array)($job['sources'][$source]['items']??[]) as $item){
                $q=trim((string)($item['keyword']??''));
                if($q==='')continue;
                $volume=max(0,(int)($item['search_volume']??0));
                if(!isset($rows[$q])||$volume>$rows[$q])$rows[$q]=$volume;
            }
        }
        if(!$rows)return [(string)($job['research_context']['effective_seed']??$job['seed'])];

        // Do not let high-volume head terms consume every KEYWORD_IDEAS seed.
        // Keep a bounded, deterministic mix of provider-returned phrases with 1-2,
        // 3, 4 and 5+ words. Word count influences discovery depth only; it never
        // determines whether a keyword is a longtail or changes the keyword text.
        $groups=['1_2'=>[],'3'=>[],'4'=>[],'5_plus'=>[]];
        foreach($rows as $q=>$volume){
            $words=preg_split('/\s+/u',trim((string)$q),-1,PREG_SPLIT_NO_EMPTY);
            $count=is_array($words)?count($words):1;
            $bucket=$count<=2?'1_2':($count===3?'3':($count===4?'4':'5_plus'));
            $groups[$bucket][$q]=(int)$volume;
        }
        $sortGroup=static function(array $g): array {
            uksort($g,static function(string $a,string $b)use($g): int{
                $v=((int)$g[$b])<=>((int)$g[$a]);
                return $v!==0?$v:strcmp($a,$b);
            });
            return $g;
        };
        foreach($groups as $k=>$g)$groups[$k]=$sortGroup($g);

        $selected=[];$quota=5;
        foreach(['1_2','3','4','5_plus'] as $bucket){
            foreach(array_keys($groups[$bucket]) as $q){
                $selected[$q]=true;
                if(count(array_intersect_key($selected,$groups[$bucket]))>=$quota)break;
            }
        }
        if(count($selected)<20){
            $remaining=$sortGroup(array_diff_key($rows,$selected));
            foreach(array_keys($remaining) as $q){$selected[$q]=true;if(count($selected)>=20)break;}
        }
        return array_slice(array_keys($selected),0,20);
    }
    private static function finalize(array $job): array {
        try{
            foreach(['KEYWORD_SUGGESTION','RELATED_SEARCH','KEYWORD_IDEA'] as $source)if(!isset($job['sources'][$source]['items'])||!is_array($job['sources'][$source]['items']))throw new RuntimeException('PSTE_RESEARCH_SOURCE_INCOMPLETE_'.$source);
            $version=(string)($job['version']??self::VERSION);if(self::questionsRequiredForVersion($version)){if(!isset($job['sources']['PAA']['items'])||!is_array($job['sources']['PAA']['items']))throw new RuntimeException('PSTE_RESEARCH_SOURCE_INCOMPLETE_PAA');if($version==='2.6.0'&&(string)($job['questions_state']??'')!=='COMPLETE')throw new RuntimeException('PSTE_RESEARCH_QUESTIONS_NOT_COMPLETE');}
            $stage=(string)($job['finalize_stage']??'PREPARE');
            if($stage==='PREPARE'){
                $init=PSTE_Runner::researchFinalizePrepareInit($job);$job['finalize_prepare_groups']=array_values((array)($init['groups']??[]));$job['finalize_prepare_family_filter']=(array)($init['family_filter']??[]);$job['finalize_prepare_total']=(int)($init['total']??count($job['finalize_prepare_groups']));$job['finalize_prepare_cursor']=0;$job['finalize_prepare_candidate_ids']=[];$job['finalize_prepare_commit_ids']=[];$job['finalize_prepare_commit_cursor']=0;$job['finalize_stage']='PREPARE_CANDIDATES';$job['finalize_sandbox_cursor']=0;$job['finalize_context_cursor']=0;$job['finalize_sandbox_admissions']=0;$job['finalize_structure_gap_admissions']=0;$job['finalize_internal_clarification_admissions']=0;$job['finalize_candidate_failures']=0;$job['finalize_candidate_failure_codes']=[];$job['finalize_stall_count']=0;$job['finalize_last_progress_key']='';$job=self::markFinalizeProgress($job);self::save($job);self::saveProgressRun($job);return self::summary($job);
            }
            if($stage==='PREPARE_CANDIDATES'){
                $cursor=(int)($job['finalize_prepare_cursor']??0);$total=(int)($job['finalize_prepare_total']??count((array)($job['finalize_prepare_groups']??[])));
                if($cursor<$total){$batch=PSTE_Runner::researchFinalizePrepareCandidateBatch($job,$cursor,self::FINALIZE_BATCH);$processed=(int)($batch['processed']??0);if($processed<=0)throw new RuntimeException('PSTE_RESEARCH_FINALIZE_PREPARE_BATCH_NO_PROGRESS');$job['finalize_prepare_cursor']=(int)($batch['next_cursor']??$cursor);$job['finalize_prepare_family_filter']=(array)($batch['family_filter']??$job['finalize_prepare_family_filter']);$ids=array_values(array_filter(array_map('strval',(array)($job['finalize_prepare_candidate_ids']??[]))));$seen=array_fill_keys($ids,true);foreach((array)($batch['candidate_ids']??[]) as $id){$id=(string)$id;if($id!==''&&!isset($seen[$id])){$ids[]=$id;$seen[$id]=true;}}$job['finalize_prepare_candidate_ids']=$ids;}
                if((int)($job['finalize_prepare_cursor']??0)>=$total)$job['finalize_stage']='PREPARE_GLOBAL';$job=self::markFinalizeProgress($job);self::save($job);self::saveProgressRun($job);return self::summary($job);
            }
            if($stage==='PREPARE_GLOBAL'){
                $prepared=PSTE_Runner::researchFinalizePrepareGlobal($job);$run=(array)($prepared['run']??[]);$total=(int)($prepared['candidate_count']??0);if($total!==(int)($run['payload']['candidate_count']??-1))throw new RuntimeException('PSTE_RESEARCH_FINALIZE_PREPARE_COUNT_MISMATCH');$job['finalize_total']=$total;$job['finalize_prepare_commit_ids']=array_values(array_filter(array_map('strval',(array)($prepared['commit_ids']??[]))));if(count($job['finalize_prepare_commit_ids'])!==$total)throw new RuntimeException('PSTE_RESEARCH_FINALIZE_PREPARE_COMMIT_ID_COUNT_MISMATCH');$job['finalize_prepare_commit_cursor']=0;$job['finalize_stage']='PREPARE_COMMIT';$job=self::markFinalizeProgress($job);self::save($job);self::saveProgressRun($job);return self::summary($job);
            }
            if($stage==='PREPARE_COMMIT'){
                $cursor=(int)($job['finalize_prepare_commit_cursor']??0);$total=count((array)($job['finalize_prepare_commit_ids']??[]));if($cursor<$total){$batch=PSTE_Runner::researchFinalizePrepareCommitBatch($job,$cursor,self::FINALIZE_BATCH);$processed=(int)($batch['processed']??0);if($processed<=0)throw new RuntimeException('PSTE_RESEARCH_FINALIZE_PREPARE_COMMIT_NO_PROGRESS');$job['finalize_prepare_commit_cursor']=(int)($batch['next_cursor']??$cursor);}
                if((int)($job['finalize_prepare_commit_cursor']??0)>=$total){$job['finalize_stage']='SANDBOX_STORE_READY';unset($job['finalize_prepare_groups'],$job['finalize_prepare_candidate_ids'],$job['finalize_prepare_commit_ids']);}$job=self::markFinalizeProgress($job);self::save($job);self::saveProgressRun($job);return self::summary($job);
            }
            if($stage==='SANDBOX_STORE_READY'){
                PSTE_Sandbox_Record_Store::resetMetrics();
                if(!PSTE_Sandbox_Record_Store::isComplete()){
                    if(PSTE_Sandbox_Record_Store::migrationActive())$manifest=PSTE_Sandbox_Record_Store::advanceMigration(3);
                    else{
                        try{$manifest=PSTE_Sandbox_Record_Store::restartMigrationFromCurrentLegacyIfStale();}
                        catch(Throwable $e){if(self::errorCode($e)==='PSTE_SANDBOX_RECORD_STORE_SOURCE_STALE_OR_BLOCKED')$manifest=PSTE_Sandbox_Record_Store::stageSourceIfNeeded();else throw $e;}
                    }
                    $metrics=PSTE_Sandbox_Record_Store::metrics();if((int)($metrics['legacy_full_reads']??0)!==0||(int)($metrics['source_bytes_read']??0)>8388608||(int)($metrics['record_reads']??0)>10||(int)($metrics['record_writes']??0)>10)throw new RuntimeException('PSTE_RESEARCH_FINALIZE_SANDBOX_MIGRATION_BUDGET_VIOLATION');
                    $job['finalize_sandbox_store_status']=(string)($manifest['status']??'RUNNING');$job['finalize_sandbox_store_cursor']=(int)($manifest['migration_cursor']??0);$job['finalize_sandbox_store_verify_cursor']=(int)($manifest['hash_cursor']??0);$job['finalize_sandbox_store_source_bytes']=(int)($manifest['source_bytes']??0);$job['finalize_sandbox_store_prehash_cursor']=(int)($manifest['prehash_cursor']??0);$job['finalize_sandbox_store_posthash_cursor']=(int)($manifest['posthash_cursor']??0);$job['finalize_record_store_metrics']=$metrics;
                    if(!PSTE_Sandbox_Record_Store::isComplete()){$job=self::markFinalizeProgress($job);self::save($job);self::saveProgressRun($job);return self::summary($job);}
                }
                $job['finalize_sandbox_store_status']='PASS';$job['finalize_stage']='SANDBOX_BATCH';$job=self::markFinalizeProgress($job);self::save($job);self::saveProgressRun($job);return self::summary($job);
            }
            if($stage==='SANDBOX_BATCH'){
                $total=(int)($job['finalize_total']??0);$cursor=(int)($job['finalize_sandbox_cursor']??0);
                if($cursor<$total){
                    $batch=PSTE_Runner::researchFinalizeAdmissionBatch($job,$cursor,self::FINALIZE_BATCH);$processed=(int)($batch['processed']??0);if($processed<=0)throw new RuntimeException('PSTE_RESEARCH_FINALIZE_SANDBOX_BATCH_NO_PROGRESS');
                    $job['finalize_sandbox_cursor']=(int)$batch['next_cursor'];$job['finalize_sandbox_admissions']=(int)($job['finalize_sandbox_admissions']??0)+(int)($batch['sandbox_admissions']??0);$job['finalize_structure_gap_admissions']=(int)($job['finalize_structure_gap_admissions']??0)+(int)($batch['structure_gap_admissions']??0);$job['finalize_internal_clarification_admissions']=(int)($job['finalize_internal_clarification_admissions']??0)+(int)($batch['internal_clarification_admissions']??0);$job['finalize_candidate_failures']=(int)($job['finalize_candidate_failures']??0)+(int)($batch['candidate_failures']??0);$job['finalize_candidate_failure_codes']=array_values(array_unique(array_merge((array)($job['finalize_candidate_failure_codes']??[]),(array)($batch['candidate_failure_codes']??[]))));$job['finalize_record_store_metrics']=(array)($batch['record_store_metrics']??[]);
                }
                if((int)($job['finalize_sandbox_cursor']??0)>=$total)$job['finalize_stage']='CONTEXT_BATCH';
                $job=self::markFinalizeProgress($job);self::save($job);self::saveProgressRun($job);return self::summary($job);
            }
            if($stage==='CONTEXT_BATCH'){
                $total=(int)($job['finalize_total']??0);$cursor=(int)($job['finalize_context_cursor']??0);
                if($cursor<$total){$batch=PSTE_Runner::researchFinalizeContextBatch($job,$cursor,self::FINALIZE_BATCH);$processed=(int)($batch['processed']??0);if($processed<=0)throw new RuntimeException('PSTE_RESEARCH_FINALIZE_CONTEXT_BATCH_NO_PROGRESS');$job['finalize_context_cursor']=(int)$batch['next_cursor'];}
                if((int)($job['finalize_context_cursor']??0)>=$total)$job['finalize_stage']=$version==='2.6.0'?'CATEGORY_CLOSE':'COMPLETE';
                $job=self::markFinalizeProgress($job);self::save($job);self::saveProgressRun($job);return self::summary($job);
            }
            if($stage==='CATEGORY_CLOSE'){
                $closed=PSTE_Runner::closeResearchCategory($job,['sandbox_admissions'=>(int)($job['finalize_sandbox_admissions']??0),'structure_gap_admissions'=>(int)($job['finalize_structure_gap_admissions']??0),'internal_clarification_admissions'=>(int)($job['finalize_internal_clarification_admissions']??0),'candidate_failures'=>(int)($job['finalize_candidate_failures']??0),'candidate_failure_codes'=>(array)($job['finalize_candidate_failure_codes']??[])]);
                $job['category_close_state']=(string)($closed['state']??'OPEN_REVIEW');$job['coverage_state']=(string)($closed['coverage_state']??'BLOCKED');$job['coverage_candidate_id']=(string)($closed['coverage_candidate_id']??'');
                if($job['category_close_state']==='OPEN_REVIEW'){$job['status']='PAUSED_ERROR';$job['last_error']='PSTE_CATEGORY_EXHAUSTION_NOT_PROVEN';$job['phase_state']='IDLE';$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);}
                $job['finalize_total']=PSTE_Repository::researchFinalizeCandidateCount((string)$job['job_uuid']);$job['finalize_stage']='COMPLETE';$job=self::markFinalizeProgress($job);self::save($job);self::saveProgressRun($job);return self::summary($job);
            }
            if($stage==='COMPLETE'){
                $run=PSTE_Runner::completeResearchFinalizeJob($job,['sandbox_admissions'=>(int)($job['finalize_sandbox_admissions']??0),'structure_gap_admissions'=>(int)($job['finalize_structure_gap_admissions']??0),'internal_clarification_admissions'=>(int)($job['finalize_internal_clarification_admissions']??0),'candidate_failures'=>(int)($job['finalize_candidate_failures']??0),'candidate_failure_codes'=>(array)($job['finalize_candidate_failure_codes']??[])]);
                $job['status']='COMPLETE';$job['phase']='COMPLETE';$job['phase_state']='IDLE';$job['last_error']='';$job['updated_at_utc']=gmdate('c');try{PSTE_Budget_Reservations::release((string)$job['job_uuid']);}catch(Throwable $ignored){}$job['budget_reserved']=false;self::deleteIfSame($job);$summary=self::summary($job);$summary['usable_candidate_count']=(int)($run['payload']['usable_candidate_count']??0);$summary['candidate_count']=(int)($run['payload']['candidate_count']??0);return $summary;
            }
            throw new RuntimeException('PSTE_RESEARCH_FINALIZE_STAGE_INVALID');
        }catch(Throwable $e){
            $job=self::load();$code=self::errorCode($e);
            if(self::isTransientCoordinationCode($code))return self::finalizeCoordinationWait($job,$code);
            $job['status']='PAUSED_ERROR';$job['phase_state']='IDLE';$job['last_error']=$code;$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);try{PSTE_Budget_Reservations::release((string)$job['job_uuid']);$job['budget_reserved']=false;self::save($job);}catch(Throwable $ignored){}return self::summary($job);
        }
    }

    private static function finalizeProgressKey(array $job): string {return implode('|',[(string)($job['finalize_stage']??'PREPARE'),(int)($job['finalize_prepare_cursor']??0),(int)($job['finalize_prepare_commit_cursor']??0),(int)($job['finalize_sandbox_cursor']??0),(int)($job['finalize_context_cursor']??0),(string)($job['finalize_sandbox_store_status']??''),(int)($job['finalize_sandbox_store_prehash_cursor']??0),(int)($job['finalize_sandbox_store_cursor']??0),(int)($job['finalize_sandbox_store_verify_cursor']??0),(int)($job['finalize_sandbox_store_posthash_cursor']??0)]);}
    private static function markFinalizeProgress(array $job): array {$key=self::finalizeProgressKey($job);$old=(string)($job['finalize_last_progress_key']??'');$job['finalize_stall_count']=$old!==''&&hash_equals($old,$key)?(int)($job['finalize_stall_count']??0)+1:0;$job['finalize_last_progress_key']=$key;unset($job['coordination_wait_code'],$job['coordination_wait_since_utc']);if((int)$job['finalize_stall_count']>=self::FINALIZE_STALL_LIMIT){$job['status']='PAUSED_ERROR';$job['last_error']='PSTE_RESEARCH_FINALIZE_STALLED';}$job['updated_at_utc']=gmdate('c');return $job;}
    private static function finalizeCoordinationWait(array $job,string $code): array {$key=self::finalizeProgressKey($job);$old=(string)($job['finalize_last_progress_key']??'');$stalls=$old!==''&&hash_equals($old,$key)?(int)($job['finalize_stall_count']??0)+1:1;$job['finalize_last_progress_key']=$key;$job['finalize_stall_count']=$stalls;$job['phase_state']='IDLE';$job['updated_at_utc']=gmdate('c');if($stalls>=self::FINALIZE_STALL_LIMIT){$job['status']='PAUSED_ERROR';$job['last_error']='PSTE_RESEARCH_FINALIZE_STALLED';$job['coordination_wait_code']=$code;self::save($job);self::saveProgressRun($job);return self::summary($job);}$job['status']='RUNNING';$job['last_error']='';$job['coordination_wait_code']=$code;if(empty($job['coordination_wait_since_utc']))$job['coordination_wait_since_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);}


    private static function ensureInputsCurrent(array $job): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        $rebase=PSTE_Snapshot::rebaseResearchBaselineIfSafe($baseline);
        if(empty($rebase['ok']))throw new RuntimeException((string)($rebase['error_code']??'PSTE_SITE_BASELINE_STALE'));
        $baseline=(array)$rebase['baseline'];
        $inventory=PSTE_Snapshot::inventory();$structure=PSTE_Snapshot::structure();$plan=PSTE_Snapshot::editorialPlan();
        if(!hash_equals((string)($baseline['structure_sha256']??''),(string)($structure['sha256']??''))){
            $equivalent=PSTE_Snapshot::effectiveProductionStructureEquivalent($baseline,$structure);
            if(empty($equivalent['ok']))throw new RuntimeException('PSTE_SITE_STRUCTURE_STALE');
        }

        $selected=PSTE_Category_Context::selectedCategory((int)$job['category_id'],$baseline);
        $oldSelected=(array)($job['selected_category']??[]);
        foreach(['term_id','slug','topic_family_key'] as $field)if((string)($oldSelected[$field]??'')!==(string)($selected[$field]??''))throw new RuntimeException('PSTE_RESEARCH_SELECTED_CATEGORY_IDENTITY_CHANGED_'.$field);

        $snapshot=(array)($job['snapshot']??[]);
        if(!is_array($snapshot['inventory']??null)||!is_array($snapshot['structure']??null)||!is_array($snapshot['editorial_plan']??null))throw new RuntimeException('PSTE_RESEARCH_JOB_SNAPSHOT_INVALID');
        $changed=!hash_equals((string)($snapshot['inventory']['sha256']??''),(string)($inventory['sha256']??''))
            ||!hash_equals((string)($snapshot['structure']['sha256']??''),(string)($structure['sha256']??''))
            ||!hash_equals((string)($snapshot['editorial_plan']['sha256']??''),(string)($plan['sha256']??''));
        if($changed){
            $receipt=[
                'contract'=>'PSTE_RESEARCH_SITE_CONTEXT_REBASE_V1','mode'=>(string)($rebase['mode']??'SAFE_DYNAMIC_CONTEXT_REBASE'),
                'old_inventory_sha256'=>(string)($snapshot['inventory']['sha256']??''),'new_inventory_sha256'=>(string)($inventory['sha256']??''),
                'old_structure_sha256'=>(string)($snapshot['structure']['sha256']??''),'new_structure_sha256'=>(string)($structure['sha256']??''),
                'old_editorial_plan_sha256'=>(string)($snapshot['editorial_plan']['sha256']??''),'new_editorial_plan_sha256'=>(string)($plan['sha256']??''),
                'old_baseline_sha256'=>(string)($rebase['old_baseline_sha256']??''),'new_baseline_sha256'=>(string)($rebase['new_baseline_sha256']??''),
                'provider_request_repeated'=>false,'rebased_at_utc'=>gmdate('c'),
            ];
            $receipt['sha256']=hash('sha256',self::canonicalJson($receipt));
            $job['snapshot']=['inventory'=>$inventory,'structure'=>$structure,'editorial_plan'=>$plan];$job['selected_category']=$selected;
            $job['site_context_rebase_receipt']=$receipt;$job['site_context_rebase_count']=(int)($job['site_context_rebase_count']??0)+1;
            $job['coordination_wait_code']='PSTE_SITE_CONTEXT_REBASED_SAFE';$job['coordination_wait_since_utc']=gmdate('c');$job['updated_at_utc']=gmdate('c');self::save($job);
        }
        return $job;
    }

    private static function recoverSafeSiteContextPause(array $job): array {
        try{$job=self::ensureInputsCurrent($job);}catch(Throwable $e){return $job;}
        $job['status']='RUNNING';$job['phase_state']='IDLE';$job['last_error']='';$job['coordination_wait_code']='PSTE_SITE_CONTEXT_REBASED_SAFE';$job['coordination_wait_since_utc']=gmdate('c');$job['updated_at_utc']=gmdate('c');self::save($job);return $job;
    }
    private static function ensureReservation(array &$job,array $settings): void {PSTE_Cost_Guard::assertWithin((float)$job['estimated_cost'],(float)$settings['run_budget_usd'],(float)$settings['absolute_ceiling_usd']);PSTE_Budget_Reservations::reserve((string)$job['job_uuid'],(float)$job['estimated_cost'],$settings,'CATEGORY_LONGTAIL_RESEARCH',1800);if(empty($job['budget_reserved'])){$job['budget_reserved']=true;$job['updated_at_utc']=gmdate('c');self::save($job);}}
    private static function saveProgressRun(array $job): void {
        $now=gmdate('Y-m-d H:i:s');$steps=self::providerStepsForVersion((string)($job['version']??self::VERSION));
        $progressPayload=['workflow'=>'LONGTAIL_RESEARCH_TO_METADATA_V2','execution_mode'=>'SERVER_STEP_DRIVER_V1','provider_calls'=>$steps,'provider_steps_completed'=>(int)$job['progress'],'google_live_serp_used'=>false,'manual_followup_steps_required'=>0,'phase'=>(string)$job['phase'],'last_error'=>(string)$job['last_error'],'coordination_wait_code'=>(string)($job['coordination_wait_code']??''),'research_context'=>(array)$job['research_context'],'selected_category'=>(array)$job['selected_category'],'questions_required'=>self::questionsRequiredForVersion((string)($job['version']??self::VERSION)),'questions_state'=>(string)($job['questions_state']??(self::questionsRequiredForVersion((string)($job['version']??self::VERSION))?'LEGACY_VISIBLE_STEP':'NOT_REQUIRED')),'questions_transport'=>(string)($job['questions_transport']??''),'finalize_stage'=>(string)($job['finalize_stage']??''),'finalize_total'=>(int)($job['finalize_total']??0),'finalize_prepare_cursor'=>(int)($job['finalize_prepare_cursor']??0),'finalize_prepare_total'=>(int)($job['finalize_prepare_total']??0),'finalize_prepare_commit_cursor'=>(int)($job['finalize_prepare_commit_cursor']??0),'finalize_sandbox_cursor'=>(int)($job['finalize_sandbox_cursor']??0),'finalize_context_cursor'=>(int)($job['finalize_context_cursor']??0),'finalize_sandbox_store_status'=>(string)($job['finalize_sandbox_store_status']??''),'finalize_sandbox_store_prehash_cursor'=>(int)($job['finalize_sandbox_store_prehash_cursor']??0),'finalize_sandbox_store_cursor'=>(int)($job['finalize_sandbox_store_cursor']??0),'finalize_sandbox_store_verify_cursor'=>(int)($job['finalize_sandbox_store_verify_cursor']??0),'finalize_sandbox_store_posthash_cursor'=>(int)($job['finalize_sandbox_store_posthash_cursor']??0),'category_close_state'=>(string)($job['category_close_state']??''),'coverage_state'=>(string)($job['coverage_state']??'')];
        $payload=$progressPayload;if((string)($job['phase']??'')==='FINALIZE'){$existing=PSTE_Repository::runByUuid((string)$job['job_uuid']);if(is_array($existing)){$existingPayload=(array)($existing['payload']??[]);if(in_array((string)($existingPayload['research_finalize_state']??''),['PREPARED','COMPLETE'],true))$payload=array_replace($existingPayload,$progressPayload);}}
        PSTE_Repository::saveRun(['run_uuid'=>(string)$job['job_uuid'],'status'=>(string)$job['status'],'category_id'=>(int)$job['category_id'],'seed'=>(string)$job['seed'],'estimated_cost'=>(float)$job['estimated_cost'],'actual_cost'=>(float)$job['actual_cost'],'snapshot'=>(array)$job['snapshot'],'payload'=>$payload,'created_at'=>self::mysqlDate((string)$job['run_created_at']),'updated_at'=>$now]);
    }
    private static function summary(array $job): array {return ['contract'=>self::CONTRACT,'version'=>(string)($job['version']??''),'job_uuid'=>(string)$job['job_uuid'],'status'=>(string)$job['status'],'phase'=>(string)$job['phase'],'phase_state'=>(string)$job['phase_state'],'transport_recovery_mode'=>self::transportRecoveryMode($job),'progress'=>(int)$job['progress'],'total_provider_steps'=>(int)$job['total_provider_steps'],'questions_required'=>self::questionsRequiredForVersion((string)($job['version']??self::VERSION)),'questions_state'=>(string)($job['questions_state']??(self::questionsRequiredForVersion((string)($job['version']??self::VERSION))?'LEGACY_VISIBLE_STEP':'NOT_REQUIRED')),'category_id'=>(int)$job['category_id'],'seed'=>(string)$job['seed'],'owner_kind'=>(string)($job['owner_kind']??''),'owner_queue_uuid'=>(string)($job['owner_queue_uuid']??''),'owner_item_index'=>(int)($job['owner_item_index']??-1),'effective_seed'=>(string)($job['research_context']['effective_seed']??$job['seed']),'estimated_cost'=>(float)$job['estimated_cost'],'actual_cost'=>(float)$job['actual_cost'],'last_error'=>(string)$job['last_error'],'coordination_wait_code'=>(string)($job['coordination_wait_code']??''),'coordination_wait_since_utc'=>(string)($job['coordination_wait_since_utc']??''),'finalize_stage'=>(string)($job['finalize_stage']??''),'finalize_total'=>(int)($job['finalize_total']??0),'finalize_prepare_cursor'=>(int)($job['finalize_prepare_cursor']??0),'finalize_prepare_total'=>(int)($job['finalize_prepare_total']??0),'finalize_prepare_commit_cursor'=>(int)($job['finalize_prepare_commit_cursor']??0),'finalize_sandbox_cursor'=>(int)($job['finalize_sandbox_cursor']??0),'finalize_context_cursor'=>(int)($job['finalize_context_cursor']??0),'finalize_sandbox_store_status'=>(string)($job['finalize_sandbox_store_status']??''),'finalize_sandbox_store_prehash_cursor'=>(int)($job['finalize_sandbox_store_prehash_cursor']??0),'finalize_sandbox_store_cursor'=>(int)($job['finalize_sandbox_store_cursor']??0),'finalize_sandbox_store_verify_cursor'=>(int)($job['finalize_sandbox_store_verify_cursor']??0),'finalize_sandbox_store_posthash_cursor'=>(int)($job['finalize_sandbox_store_posthash_cursor']??0),'finalize_stall_count'=>(int)($job['finalize_stall_count']??0),'category_close_state'=>(string)($job['category_close_state']??''),'coverage_state'=>(string)($job['coverage_state']??''),'coverage_candidate_id'=>(string)($job['coverage_candidate_id']??''),'manual_followup_steps_required'=>0,'google_live_serp_used'=>false,'updated_at_utc'=>(string)$job['updated_at_utc']];}
    /** Browser transport recovery class. Provider-bearing unknown outcomes stay fail-closed; persisted/read-only or local checkpoint work may resume. */
    private static function transportRecoveryMode(array $job): string {
        if((string)($job['status']??'')!=='RUNNING')return 'TERMINAL';
        $phase=(string)($job['phase']??'');$phaseState=(string)($job['phase_state']??'');
        if($phase==='FINALIZE'&&self::canReplayLocalFinalize($job))return 'LOCAL_CHECKPOINT_RETRY_SAFE';
        if($phase==='QUESTIONS'){
            $questions=(string)($job['questions_state']??'NOT_STARTED');
            if($questions==='TASK_PENDING')return 'PERSISTED_TASK_READ_RETRY_SAFE';
            if($questions==='COMPLETE')return 'LOCAL_CHECKPOINT_RETRY_SAFE';
            return 'PROVIDER_SIDE_EFFECT_FAIL_CLOSED';
        }
        if(in_array($phase,['KEYWORD_SUGGESTIONS','RELATED_KEYWORDS','KEYWORD_IDEAS','PEOPLE_ALSO_ASK'],true)){
            if(in_array($phaseState,['IN_FLIGHT','PERSISTING'],true))return 'PERSISTED_PROVIDER_STATE_RETRY_SAFE';
            return 'PROVIDER_SIDE_EFFECT_FAIL_CLOSED';
        }
        return 'FAIL_CLOSED';
    }

    private static function isTransientCoordinationCode(string $code): bool {return in_array($code,self::TRANSIENT_COORDINATION_CODES,true);}
    private static function isReplaySafeLocalFinalizeCode(string $code): bool {return in_array($code,self::REPLAY_SAFE_LOCAL_FINALIZE_CODES,true);}
    private static function canReplayLocalFinalize(array $job): bool {$version=(string)($job['version']??self::VERSION);if((string)($job['phase']??'')!=='FINALIZE'||(int)($job['progress']??-1)!==self::providerStepsForVersion($version))return false;foreach(['KEYWORD_SUGGESTION','RELATED_SEARCH','KEYWORD_IDEA'] as $source)if(!is_array($job['sources'][$source]['items']??null))return false;if(self::questionsRequiredForVersion($version)){if(!is_array($job['sources']['PAA']['items']??null))return false;if($version==='2.6.0'&&(string)($job['questions_state']??'')!=='COMPLETE')return false;}return true;}
    private static function recoverReplaySafeLocalFinalizePause(array $job,string $code): array {$receipt=hash('sha256','PSTE_LOCAL_FINALIZE_REPLAY_V1|'.(string)$job['job_uuid'].'|'.$code.'|'.(string)$job['progress']);if(hash_equals($receipt,(string)($job['local_finalize_replay_receipt']??'')))return $job;$job['status']='RUNNING';$job['phase_state']='IDLE';$job['last_error']='';$job['coordination_wait_code']='PSTE_LOCAL_FINALIZE_REPLAY_SAFE';$job['coordination_wait_since_utc']=gmdate('c');$job['local_finalize_replay_source_error']=$code;$job['local_finalize_replay_receipt']=$receipt;$job['updated_at_utc']=gmdate('c');self::save($job);return $job;}
    private static function coordinationWait(array $job,string $code): array {$job['status']='RUNNING';$job['phase_state']='IDLE';$job['last_error']='';if((string)($job['coordination_wait_code']??'')!==$code)$job['coordination_wait_since_utc']=gmdate('c');$job['coordination_wait_code']=$code;$job['updated_at_utc']=gmdate('c');self::save($job);return self::summary($job);}
    private static function recoverTransientCoordinationPause(array $job,string $code): array {$job['status']='RUNNING';$job['phase_state']='IDLE';$job['last_error']='';$job['coordination_wait_code']=$code;$job['coordination_wait_since_utc']=(string)($job['coordination_wait_since_utc']??gmdate('c'));$job['updated_at_utc']=gmdate('c');self::save($job);return $job;}
    private static function load(): array {$job=self::rawJob();if($job===null)throw new RuntimeException('PSTE_RESEARCH_JOB_MISSING');self::assertJob($job);return $job;}
    private static function rawJob(): ?array {$v=get_option(PSTE_OPTION_ACTIVE_RESEARCH_JOB,null);self::traceActiveJobRead('ACTIVE_JOB_OPTION_READ_1',$v);if($v===null||$v===false||$v==='')return null;if(!is_array($v))throw new RuntimeException('PSTE_RESEARCH_JOB_STORAGE_INVALID');return $v;}
    private static function save(array $job): void {if(self::$activeStepFenceToken!==''){$lock=get_option(PSTE_OPTION_RESEARCH_STEP_LOCK,[]);if(!is_array($lock)||!hash_equals(self::$activeStepFenceToken,(string)($lock['token']??'')))throw new RuntimeException('PSTE_RESEARCH_STEP_FENCE_LOST');}$job=self::withHash($job);error_log('PSTE_STATETRACE JOB_SAVE_ENTER t='.sprintf('%.6f',microtime(true)).' pid='.getmypid().' uuid='.(string)($job['job_uuid']??'').' phase='.(string)($job['phase']??'').' phase_state='.(string)($job['phase_state']??'').' status='.(string)($job['status']??'').' sha='.(string)($job['sha256']??''));$updateResult=update_option(PSTE_OPTION_ACTIVE_RESEARCH_JOB,$job,false);global $wpdb;$directRaw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",PSTE_OPTION_ACTIVE_RESEARCH_JOB));$direct=is_string($directRaw)?maybe_unserialize($directRaw):null;error_log('PSTE_STATETRACE JOB_WRITE_RESULT t='.sprintf('%.6f',microtime(true)).' pid='.getmypid().' update_result='.($updateResult?'1':'0').' db_error='.base64_encode((string)$wpdb->last_error).' direct_sha='.(is_array($direct)?(string)($direct['sha256']??''):'NON_ARRAY'));$stored=get_option(PSTE_OPTION_ACTIVE_RESEARCH_JOB,null);self::traceActiveJobRead('ACTIVE_JOB_OPTION_READ_2',$stored);$storedSha=is_array($stored)?(string)($stored['sha256']??''):'NON_ARRAY';error_log('PSTE_STATETRACE JOB_SAVE_READBACK t='.sprintf('%.6f',microtime(true)).' pid='.getmypid().' uuid='.(string)($job['job_uuid']??'').' wanted='.(string)($job['sha256']??'').' got='.$storedSha.' stored_phase='.(is_array($stored)?(string)($stored['phase']??''):'').' stored_phase_state='.(is_array($stored)?(string)($stored['phase_state']??''):'').' stored_status='.(is_array($stored)?(string)($stored['status']??''):'') );if(!is_array($stored)||!hash_equals((string)$job['sha256'],$storedSha)){error_log('PSTE_STATETRACE JOB_READBACK_MISMATCH t='.sprintf('%.6f',microtime(true)).' pid='.getmypid().' uuid='.(string)($job['job_uuid']??'').' wanted='.(string)($job['sha256']??'').' got='.$storedSha);throw new RuntimeException('PSTE_RESEARCH_JOB_READBACK_MISMATCH');}self::assertJob($stored);}
    private static function deleteIfSame(array $job): void {$stored=self::rawJob();$lock=get_option(PSTE_OPTION_RESEARCH_STEP_LOCK,[]);error_log('PSTE_STATETRACE JOB_DELETE_CHECK t='.sprintf('%.6f',microtime(true)).' pid='.getmypid().' uuid='.(string)($job['job_uuid']??'').' phase='.(string)($job['phase']??'').' status='.(string)($job['status']??'').' phase_state='.(string)($job['phase_state']??'').' stored_uuid='.(is_array($stored)?(string)($stored['job_uuid']??''):'NONE').' step_lock='.(is_array($lock)?(string)($lock['token']??''):'NONE'));if($stored!==null&&hash_equals((string)$job['job_uuid'],(string)($stored['job_uuid']??''))){$ok=delete_option(PSTE_OPTION_ACTIVE_RESEARCH_JOB);error_log('PSTE_STATETRACE JOB_DELETE_DONE t='.sprintf('%.6f',microtime(true)).' pid='.getmypid().' uuid='.(string)($job['job_uuid']??'').' phase='.(string)($job['phase']??'').' status='.(string)($job['status']??'').' ok='.($ok?'1':'0'));}}
    private static function withHash(array $job): array {
        $job['contract']=self::CONTRACT;$version=(string)($job['version']??'');if($version==='')$version=self::VERSION;if(!in_array($version,self::COMPATIBLE_VERSIONS,true))throw new RuntimeException('PSTE_RESEARCH_JOB_CONTRACT_INVALID');$job['version']=$version;unset($job['sha256']);$job['sha256']=hash('sha256',self::canonicalJson($job));return $job;
    }


    private static function providerStepsForVersion(string $version): int {return in_array($version,['2.3.0','2.4.0','2.5.0'],true)?self::LEGACY_PAA_PROVIDER_STEPS:self::PROVIDER_STEPS;}
    private static function questionsRequiredForVersion(string $version): bool {return in_array($version,['2.3.0','2.4.0','2.5.0','2.6.0'],true);}
    private static function assertJob(array $job): void {
        if(($job['contract']??'')!==self::CONTRACT||!in_array((string)($job['version']??''),self::COMPATIBLE_VERSIONS,true))throw new RuntimeException('PSTE_RESEARCH_JOB_CONTRACT_INVALID');$declared=(string)($job['sha256']??'');$copy=$job;unset($copy['sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(hash('sha256',self::canonicalJson($copy)),$declared))throw new RuntimeException('PSTE_RESEARCH_JOB_HASH_MISMATCH');if(!preg_match('/^[a-f0-9-]{20,64}$/i',(string)($job['job_uuid']??'')))throw new RuntimeException('PSTE_RESEARCH_JOB_UUID_INVALID');$ownerKind=(string)($job['owner_kind']??'');if($ownerKind!==''&&!in_array($ownerKind,['SINGLE','BREADTH'],true))throw new RuntimeException('PSTE_RESEARCH_OWNER_KIND_INVALID');if($ownerKind==='BREADTH'&&(trim((string)($job['owner_queue_uuid']??''))===''||(int)($job['owner_item_index']??-1)<0))throw new RuntimeException('PSTE_RESEARCH_BREADTH_OWNER_INVALID');$version=(string)$job['version'];$steps=self::providerStepsForVersion($version);if((int)($job['total_provider_steps']??0)!==$steps||(int)($job['progress']??-1)<0||(int)$job['progress']>$steps)throw new RuntimeException('PSTE_RESEARCH_JOB_PROGRESS_INVALID');if(!in_array((string)($job['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_RESEARCH_JOB_STATUS_INVALID');$phases=['KEYWORD_SUGGESTIONS','RELATED_KEYWORDS','KEYWORD_IDEAS','FINALIZE'];if(in_array($version,['2.3.0','2.4.0','2.5.0'],true))$phases[]='PEOPLE_ALSO_ASK';if($version==='2.6.0'){$phases[]='QUESTIONS';$qs=(string)($job['questions_state']??'NOT_STARTED');if(!in_array($qs,['NOT_STARTED','TASK_PENDING','COMPLETE','ERROR'],true))throw new RuntimeException('PSTE_RESEARCH_QUESTIONS_STATE_INVALID');}if(!in_array((string)($job['phase']??''),$phases,true))throw new RuntimeException('PSTE_RESEARCH_JOB_PHASE_INVALID');
    }
    private static function canonicalJson($value): string {$json=wp_json_encode(self::canonicalize($value),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($json))throw new RuntimeException('PSTE_RESEARCH_JOB_JSON_ENCODE_FAILED');return $json;}
    private static function canonicalize($value){if(!is_array($value))return $value;if($value===[])return [];$list=array_keys($value)===range(0,count($value)-1);if($list)return array_map([self::class,'canonicalize'],$value);ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=self::canonicalize($v);return $value;}
    private static function acquireLaunchLock(): string {$token=hash('sha256','launch|'.microtime(true).'|'.wp_generate_uuid4());$payload=['token'=>$token,'expires_at'=>time()+120];if(add_option(PSTE_OPTION_RESEARCH_CONTROL_LOCK,$payload,'',false))return $token;$existing=get_option(PSTE_OPTION_RESEARCH_CONTROL_LOCK,[]);if(is_array($existing)&&(int)($existing['expires_at']??0)<time()){self::deleteExpiredOptionLockAtomically(PSTE_OPTION_RESEARCH_CONTROL_LOCK);if(add_option(PSTE_OPTION_RESEARCH_CONTROL_LOCK,$payload,'',false))return $token;}throw new RuntimeException('PSTE_RESEARCH_CONTROL_START_LOCKED');}
    private static function releaseLaunchLock(string $token): void {self::deleteOwnedOptionLockAtomically(PSTE_OPTION_RESEARCH_CONTROL_LOCK,$token);}

    private static function acquireStepLock(): string {$token=hash('sha256',microtime(true).'|'.wp_generate_uuid4());$payload=['token'=>$token,'expires_at'=>time()+self::STEP_LOCK_TTL];if(self::insertOptionLockIfAbsent(PSTE_OPTION_RESEARCH_STEP_LOCK,$payload)){return $token;}self::deleteExpiredOptionLockAtomically(PSTE_OPTION_RESEARCH_STEP_LOCK);if(self::insertOptionLockIfAbsent(PSTE_OPTION_RESEARCH_STEP_LOCK,$payload))return $token;throw new RuntimeException('PSTE_RESEARCH_STEP_ALREADY_RUNNING');}
    private static function insertOptionLockIfAbsent(string $option,array $value): bool {global $wpdb;$r=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,%s)",$option,maybe_serialize($value),'off'));if($r===false)throw new RuntimeException('PSTE_RESEARCH_STEP_LOCK_INSERT_FAILED');wp_cache_delete($option,'options');wp_cache_delete('notoptions','options');return (int)$r===1;}
    private static function releaseStepLock(string $token): void {self::deleteOwnedOptionLockAtomically(PSTE_OPTION_RESEARCH_STEP_LOCK,$token);}
    private static function deleteExpiredOptionLockAtomically(string $option): void {global $wpdb;$raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$option));if(!is_string($raw)||$raw==='')return;$v=maybe_unserialize($raw);if(!is_array($v)||(int)($v['expires_at']??0)>=time())return;PSTE_DB_Write_Guard::query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$option,$raw),'PSTE_LOCK_ATOMIC_EXPIRED_DELETE_FAILED');wp_cache_delete($option,'options');}
    private static function deleteOwnedOptionLockAtomically(string $option,string $token): void {global $wpdb;$raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$option));if(!is_string($raw)||$raw==='')return;$v=maybe_unserialize($raw);if(!is_array($v)||!hash_equals($token,(string)($v['token']??'')))return;PSTE_DB_Write_Guard::query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$option,$raw),'PSTE_LOCK_ATOMIC_RELEASE_FAILED');wp_cache_delete($option,'options');}
    private static function errorCode(Throwable $e): string {$code=strtoupper(trim($e->getMessage()));$code=(string)preg_replace('/[^A-Z0-9_:\-]/','_',$code);return substr($code!==''?$code:'PSTE_RESEARCH_JOB_FAILED',0,180);}
    private static function mysqlDate(string $value): string {$ts=strtotime($value);return gmdate('Y-m-d H:i:s',$ts===false?time():$ts);}
}
