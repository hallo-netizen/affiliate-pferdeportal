<?php
if (!defined('ABSPATH')) { return; }

/**
 * Coordinates the controlled return from Sandbox into the normal SEO metadata path.
 * It owns no relevance/family/title decision rules; prepare() merely reruns the existing normal gates.
 */
final class PSTE_Normal_Reentry_Coordinator {
    /**
     * Provider-free bounded reuse pass for already-safe Sandbox candidates.
     * It only consumes existing AUTO_REENTRY_ELIGIBLE envelopes through the existing normal reentry path.
     * No provider call, no production handoff, no article/taxonomy write.
     * @return array<string,mixed>
     */
    public static function processProviderFreeExistingPotentialBatch(int $limit=25,bool $refreshStructureBacklog=false): array {
        PSTE_Plugin::assertReady();$limit=max(1,min(100,$limit));
        $backlog=$refreshStructureBacklog?PSTE_Semantic_Review_Sandbox::refreshInternalStructureBacklog(false):['contract'=>'PSTE_SANDBOX_PERIODIC_RECHECK_V2_HEALTH','status'=>'SKIPPED_NOT_REQUESTED'];
        $reentryChecked=0;$reentryApplied=0;$reentryFailed=0;$reentryFailures=[];
        foreach(PSTE_Semantic_Review_Sandbox::automaticReentryEnvelopes($limit) as $row){
            $sandboxId=(string)($row['sandbox_id']??'');$envelope=(array)($row['envelope']??[]);if($sandboxId===''||!$envelope)continue;$reentryChecked++;
            $envelopeSha=(string)($row['envelope_sha256']??'');
            try{$result=PSTE_Repository::applySandboxReentryEnvelope($envelope,$envelopeSha);}
            catch(Throwable $e){$code=self::safeCode($e->getMessage());$reentryFailed++;$reentryFailures[]=['sandbox_id'=>$sandboxId,'error_code'=>$code,'stage'=>'DB_APPLY'];PSTE_Semantic_Review_Sandbox::markNormalReentryFailed($sandboxId,$envelopeSha,$code);continue;}
            try{PSTE_Semantic_Review_Sandbox::markNormalReentryApplied($sandboxId,$envelopeSha,$result);$reentryApplied++;}
            catch(Throwable $e){$code=self::safeCode($e->getMessage());$reentryFailed++;$reentryFailures[]=['sandbox_id'=>$sandboxId,'error_code'=>$code,'stage'=>'SANDBOX_MARK_PENDING_RETRY'];}
        }
        $remaining=PSTE_Semantic_Review_Sandbox::automaticReentryEnvelopes(1)!==[];
        return ['contract'=>'PSTE_PROVIDER_FREE_EXISTING_POTENTIAL_REENTRY_V1','status'=>'PASS','backlog'=>$backlog,'reentry_checked'=>$reentryChecked,'reentry_applied'=>$reentryApplied,'reentry_failed'=>$reentryFailed,'reentry_failures'=>$reentryFailures,'more_auto_reentry_remaining'=>$remaining,'provider_calls'=>0,'production_handoff_created_by_sandbox'=>false,'article_or_taxonomy_write_attempted_by_sandbox'=>false];
    }

    /** Pure/read-only reentry preparation used by runtime and fixtures. @return array<string,mixed> */
    public static function prepare(array $envelope,array $currentPayload,array $baseline): array {
        if(($envelope['contract']??'')!=='PSTE_SANDBOX_REENTRY_ENVELOPE_V1'||($envelope['status']??'')!=='AUTO_REENTRY_ELIGIBLE')throw new RuntimeException('PSTE_SANDBOX_REENTRY_ENVELOPE_NOT_ELIGIBLE');
        if(!empty($envelope['five_field_handoff_created'])||!empty($envelope['production_handoff_attempted'])||!empty($envelope['article_or_taxonomy_write_attempted']))throw new RuntimeException('PSTE_SANDBOX_REENTRY_BOUNDARY_VIOLATION');
        $poolKey=(string)($envelope['pool_key']??'');$raw=(string)($envelope['raw_query']??'');$review=(array)($envelope['review_proposal']??[]);
        if($poolKey===''||$raw===''||!preg_match('/^[a-f0-9]{64}$/',(string)($envelope['raw_query_sha256']??''))||!hash_equals(hash('sha256',$raw),(string)$envelope['raw_query_sha256']))throw new RuntimeException('PSTE_SANDBOX_REENTRY_IDENTITY_INVALID');
        $storedRaw=PSTE_Normal_Metadata_Path::canonicalInputQuery(PSTE_Editorializer::sourceQuery($currentPayload));if($storedRaw===''||!hash_equals(hash('sha256',PSTE_Normal_Metadata_Path::canonicalInputQuery($raw)),hash('sha256',$storedRaw)))throw new RuntimeException('PSTE_SANDBOX_REENTRY_RAW_QUERY_CHANGED');$raw=PSTE_Normal_Metadata_Path::canonicalInputQuery($raw);
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_REENTRY_BASELINE_REQUIRED');
        $reviewFamilyKey=(string)($review['family_key']??'');if($reviewFamilyKey==='')throw new RuntimeException('PSTE_SANDBOX_REENTRY_FAMILY_REVIEW_MISSING');
        $relevanceProof=is_array($envelope['relevance_proof']??null)?(array)$envelope['relevance_proof']:(array)($review['relevance_proof']??[]);if(!$relevanceProof)throw new RuntimeException('PSTE_SANDBOX_REENTRY_RELEVANCE_PROOF_MISSING');
        // Transport/security validation only. The existing normal path is evaluated exactly
        // once by the repository's applyToPayload; this step must not re-decide family/title.
        return ['contract'=>'PSTE_SANDBOX_REENTRY_PREPARE_V2_SHARED_NORMAL_PATH','status'=>'PASS','pool_key'=>$poolKey,'raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),'family_key'=>$reviewFamilyKey,'relevance_proof'=>$relevanceProof,'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'write_attempted'=>false];
    }

    public static function processCron(): void {
        $trigger='SANDBOX_DAILY_CRON';
        try{
            PSTE_Sandbox_Maintenance_Health::recordAttempt($trigger);
            if(!PSTE_Plugin::isReady()){
                PSTE_Sandbox_Maintenance_Health::recordFailure($trigger,'PSTE_SANDBOX_MAINTENANCE_ENGINE_NOT_READY',['status'=>'BLOCKED_NOT_READY']);
                return;
            }
            $reuse=self::processProviderFreeExistingPotentialBatch(25,true);
            $report=['contract'=>'PSTE_SANDBOX_MAINTENANCE_RUN_V1','backlog'=>(array)($reuse['backlog']??[]),'reentry_checked'=>(int)($reuse['reentry_checked']??0),'reentry_applied'=>(int)($reuse['reentry_applied']??0),'reentry_failed'=>(int)($reuse['reentry_failed']??0),'reentry_failures'=>(array)($reuse['reentry_failures']??[]),'production_handoff_created_by_sandbox'=>false,'article_or_taxonomy_write_attempted_by_sandbox'=>false];
            if((string)($report['backlog']['status']??'')==='PARTIAL_FAILURE')PSTE_Sandbox_Maintenance_Health::recordFailure($trigger,'PSTE_SANDBOX_BACKLOG_PARTIAL_FAILURE',$report);
            else PSTE_Sandbox_Maintenance_Health::recordSuccess($trigger,$report);
        }catch(Throwable $e){
            $code=self::safeCode($e->getMessage());
            try{PSTE_Sandbox_Maintenance_Health::recordFailure($trigger,$code,['status'=>'OUTER_FAILURE']);}catch(Throwable $healthError){throw $healthError;}
        }
    }

    /** Legacy hook target. Automatic migration/retry is forbidden; explicit safe migration owns rebuilds. */
    public static function processEditorialMetadataRebuild(): void { return; }

    private static function safeCode(string $v): string {$v=strtoupper(trim($v));$v=(string)preg_replace('/[^A-Z0-9_:\-]+/','_',$v);return substr($v!==''?$v:'PSTE_NORMAL_REENTRY_FAILED',0,160);}
}
