<?php
if (!defined('ABSPATH')) { return; }

/** Pure orchestration: independent technical and editorial strands; no domain logic in the final AND gate. */
final class PSTE_Title_Pipeline {
    /** @return array<string,mixed> */
    public static function build(array $queryRecord,string $family,string $type,array $registry,array $portalContextTerms=[],array $intentProfile=[]): array {
        $raw=(string)($queryRecord['raw_query']??'');
        $source=(string)($queryRecord['language_corrected_query']??$raw);
        if(trim($raw)==='')$raw=$source;
        $normalization=PSTE_Editorial_Topic_Normalizer::normalize($source,$family,$portalContextTerms);
        $keywordMeta=PSTE_Intent_Profile::targetKeyword($source,$normalization,$type,$intentProfile);
        // The existing title-only import is the sole title authoring entrance.
        // No composer, raw-query-as-title, FAQ fallback or template candidate.
        // Other existing decisions stay intact; unfinished title work is retained.
        return [
            'contract'=>'PSTE_TITLE_PIPELINE_V9_UPSTREAM_PHRASE_FAMILY_HARDLOCK',
            'title'=>'','target_keyword'=>(string)($keywordMeta['target_keyword']??''),
            'target_keyword_contract'=>$keywordMeta,'normalization'=>$normalization,
            'deterministic'=>['ok'=>false,'status'=>'TITLE_REVIEW_REQUIRED','reason_codes'=>['PSTE_LANGUAGE_TITLE_REQUIRED']],
            'language'=>['ok'=>false,'status'=>'REVIEW_REQUIRED','reason_codes'=>['PSTE_LANGUAGE_TITLE_REQUIRED']],
            'editorial_quality'=>['ok'=>false,'status'=>'REVIEW_REQUIRED','reason_codes'=>['PSTE_LANGUAGE_TITLE_REQUIRED']],
            'ok'=>false,'technical_strand'=>['status'=>'REVIEW_REQUIRED','semantic_quality_claimed'=>false],
            'editorial_strand'=>['status'=>'REVIEW_REQUIRED','technical_result_consumed'=>false],
            'final_gate'=>['operator'=>'AND','status'=>'FAIL','domain_logic_present'=>false],
            'intent_profile'=>$intentProfile,'intent_profile_contract'=>(string)($intentProfile['contract']??''),
            'composition_contract'=>'PSTE_LANGUAGE_TITLE_IMPORT_ONLY_V1',
            'manual_override'=>false,'manual_override_changes_intent_or_assignment'=>false,
            'independence'=>'LANGUAGE_SYSTEM_ONLY_TITLE_AUTHOR_PHP_STORAGE_AND_VALIDATION_ONLY',
            'raw_query_preserved'=>true,'write_attempted'=>false
        ];
    }

    /**
     * Validates a manually supplied planning title against the exact same hard gates without
     * recomputing intent, article type, category or target keyword. This is deliberately title-only.
     * @return array<string,mixed>
     */
    public static function validateExistingTitle(string $title,string $raw,string $family,string $type,array $registry,array $intentProfile,string $targetKeyword,string $normalizedTopic='',array $existingNormalizerEvidence=[],array $languageEvidence=[]): array {
        // Revalidate the existing upstream topic decision instead of fabricating PASS.
        // This is the same existing normalizer used by build(); it does not reassign
        // intent, article type, title, target keyword, category or slot.
        $normalization=PSTE_Editorial_Topic_Normalizer::normalize($raw,$family,[]);
        // A Journal statement has already been classified and normalized by the
        // single Journal owner. Consume THAT bound normalizer result, rather than
        // issuing a conflicting second family/grammar decision for the same text.
        // Questions and all other title types keep the original path unchanged.
        if(PSTE_Article_Type_Registry::canonicalType($type)==='journal'
            && !PSTE_Normalizer::isQuestion($raw)
            && ($existingNormalizerEvidence['contract']??'')==='PSTE_EDITORIAL_TOPIC_NORMALIZER_V2'
            && ($existingNormalizerEvidence['status']??'')==='PASS'
            && ($existingNormalizerEvidence['raw_query_sha256']??'')===hash('sha256',$raw)
            && ($existingNormalizerEvidence['family']??'')===$family
            && ($existingNormalizerEvidence['normalized_topic']??'')===rtrim($raw," ?\t\n\r\0\x0B"))
            $normalization=$existingNormalizerEvidence;
        if($normalizedTopic!=='')$normalization['normalized_topic']=$normalizedTopic;
        $targetKeywordMeta=['contract'=>'PSTE_TARGET_KEYWORD_V1_INTENT_BOUND_PPM_TITLE_COMPATIBLE','status'=>$targetKeyword!==''?'PASS':'REVIEW_REQUIRED','ok'=>$targetKeyword!=='','target_keyword'=>$targetKeyword,'source'=>'PRESERVED_EXISTING_TARGET_KEYWORD','raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'','raw_query_remains_separately_preserved'=>true,'target_keyword_is_not_required_to_equal_raw_query'=>true,'ppm_exact_title_substring_required'=>false,'portal_exact_title_prefix_required'=>false,'portal_keyword_position_1_required'=>false,'intent_profile_sha256'=>(string)($intentProfile['profile_sha256']??''),'reason_codes'=>$targetKeyword!==''?[]:['PSTE_TARGET_KEYWORD_EMPTY'],'write_attempted'=>false,'target_keyword_sha256'=>$targetKeyword!==''?hash('sha256',$targetKeyword):''];
        // Sole linguistic authority: the externally approved title-desk import.
        // Never run a new wording, punctuation, style or grammatical verdict in PHP.
        // The WordPress side only consumes a title+source bound language decision.
        $proofValid=self::hasApprovedLanguageProof($languageEvidence,$title,$raw,$type);
        if(!$proofValid){
            $pending=self::build(['raw_query'=>$raw,'language_corrected_query'=>$raw],$family,$type,$registry,[],$intentProfile);
            $pending['normalization']=$normalization;
            $pending['title_proof_status']='LANGUAGE_DESK_APPROVAL_MISSING_OR_STALE';
            return $pending;
        }
        $keywordOk=!empty($targetKeywordMeta['ok']);
        $technical=['ok'=>$keywordOk,'status'=>$keywordOk?'TITLE_TECHNICAL_PASS':'TITLE_TECHNICAL_REVIEW',
            'reason_codes'=>$keywordOk?[]:['PSTE_TARGET_KEYWORD_EMPTY'],
            'semantic_quality_claimed'=>false,'write_attempted'=>false,'target_keyword'=>$targetKeyword,
            'ppm_target_keyword_binding_prevalidated'=>false,'keyword_prefix_enforced'=>false,
            'keyword_position_1_required'=>false,'keyword_coverage_rule'=>'EXTERNAL_LANGUAGE_DESK_DECISION'];
        $editorial=['contract'=>PSTE_Editorial_Quality_Gate::CONTRACT,'ok'=>true,'status'=>'PASS',
            'reason_codes'=>[],'review_flags'=>[],'raw_query_sha256'=>hash('sha256',$raw),
            'normalized_topic_sha256'=>hash('sha256',(string)($normalization['normalized_topic']??'')),
            'title_sha256'=>hash('sha256',$title),'family_sha256'=>hash('sha256',$family),
            'article_type'=>$type,'composer_called'=>false,'title_modified'=>false,
            'technical_gate_result_consumed'=>false,'write_attempted'=>false,
            'source'=>'LANGUAGE_TITLE_DESK_IMPORT_PROOF_CONSUMED'];
        $language=['ok'=>true,'status'=>'LANGUAGE_PASS','semantic_quality_claimed'=>false,'reason_codes'=>[],
            'source'=>'LANGUAGE_TITLE_DESK_IMPORT_PROOF_CONSUMED','write_attempted'=>false];
        $technicalStatus=$keywordOk?'PASS':'FAIL';
        $ok=$keywordOk&&($normalization['status']??'')==='PASS';
        return ['contract'=>'PSTE_TITLE_PIPELINE_V9_UPSTREAM_PHRASE_FAMILY_HARDLOCK',
            'title'=>$title,'target_keyword'=>$targetKeyword,'target_keyword_contract'=>$targetKeywordMeta,
            'normalization'=>$normalization,'deterministic'=>$technical,'language'=>$language,
            'editorial_quality'=>$editorial,'ok'=>$ok,
            'technical_strand'=>['status'=>$technicalStatus,'deterministic_status'=>$technical['status'],
                'language_status'=>'PASS','semantic_quality_claimed'=>false],
            'editorial_strand'=>['status'=>($normalization['status']??'')==='PASS'?'PASS':'FAIL',
                'normalization_status'=>(string)($normalization['status']??''),
                'quality_contract'=>PSTE_Editorial_Quality_Gate::CONTRACT,'technical_result_consumed'=>false],
            'final_gate'=>['operator'=>'AND','status'=>$ok?'PASS':'FAIL','domain_logic_present'=>false],
            'intent_profile'=>$intentProfile,'intent_profile_contract'=>(string)($intentProfile['contract']??''),
            'composition_contract'=>'PSTE_LANGUAGE_TITLE_IMPORT_ONLY_V1','manual_override'=>true,
            'manual_override_changes_intent_or_assignment'=>false,
            'independence'=>'LANGUAGE_DESK_ONLY_TITLE_OWNER_PHP_PROOF_CONSUMER',
            'title_proof_status'=>'VERIFIED','raw_query_preserved'=>true,'write_attempted'=>false];
    }

    /** Verify the existing importer-owned source/title identity, not the wording. */
    public static function hasApprovedLanguageProof(array $proof,string $title,string $raw,string $type=''): bool {
        if(($proof['contract']??'')!=='PSTE_STORED_SOURCE_TITLE_CANDIDATE_V1'
            ||($proof['source']??'')!=='LANGUAGE_TITLE_DESK_IMPORT'
            ||($proof['production_authority']??null)!==false
            ||($proof['family_category_type_authority']??null)!==false
            ||($proof['provider_call']??null)!==false)return false;
        if($title===''||$raw===''||!preg_match('/^[a-f0-9]{64}$/',(string)($proof['title_sha256']??''))
            ||!hash_equals(hash('sha256',$title),(string)$proof['title_sha256'])
            ||!hash_equals(hash('sha256',$raw),(string)($proof['raw_query_sha256']??'')))return false;
        // The title author has no article-type authority. Any later type change
        // belongs to the existing intent/type owner; this proof binds source/title only.
        return true;
    }


}
