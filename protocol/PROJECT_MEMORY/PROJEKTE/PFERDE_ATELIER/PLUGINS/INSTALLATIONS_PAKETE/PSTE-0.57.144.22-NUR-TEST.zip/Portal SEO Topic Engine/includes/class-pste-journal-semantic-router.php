<?php
if (!defined('ABSPATH')) { return; }

/**
 * Conservative automatic Journal routing for complex editorial questions.
 * This is metadata-only. It never allocates a production slot, creates content,
 * or bypasses duplicate/planning gates. Simple direct questions stay in FAQ.
 */
final class PSTE_Journal_Semantic_Router {
    public const CONTRACT='PSTE_JOURNAL_SEMANTIC_ROUTER_V1_HIGH_CONFIDENCE';

    /**
     * Explicit editorial intent is independent of an already matched Fach family.
     * These are GENERAL discourse intents, never topic/keyword- or category-name
     * exceptions. Simple direct questions keep FAQ/Fach priority.
     */
    public static function hasExplicitEditorialIntent(string $raw): bool {
        $q=self::lower(self::clean($raw));
        if($q===''||!class_exists('PSTE_Normalizer'))return false;
        if(PSTE_Normalizer::isQuestion($raw))
            return (bool)preg_match('/^(?:warum|wieso|weshalb)\b|^(?:was\s+(?:bedeutet|bewirkt)\b|wie\s+(?:beeinflusst|entsteht|entwickelt|verändert|veraendert)\b)|\b(?:welche\s+(?:folgen|auswirkungen|ursachen|zusammenhänge|zusammenhaenge))\b/iu',$q);
        // Statements need an explicit explanatory relationship, not a single
        // domain/product noun: no blanket magazine routing of search fragments.
        return (bool)preg_match('/\b(?:verstehen|erklärt|erklaert|hintergründe|hintergruende|zusammenhänge|zusammenhaenge|ursachen\s+und\s+folgen|bedeutung\s+für|bedeutung\s+fuer)\b/iu',$q)
            &&count(array_filter(preg_split('/\s+/u',$q)?:[]))>=3;
    }

    /** Pure classifier used by runtime and tests. @return array<string,mixed> */
    public static function classifyQuestion(string $raw): array {
        $raw=self::clean($raw);
        $base=['contract'=>self::CONTRACT,'ok'=>false,'status'=>'NOT_APPLICABLE','category_key'=>'','category_name'=>'','reason_codes'=>[],'raw_query'=>$raw,'write_attempted'=>false];
        if($raw===''||!class_exists('PSTE_Normalizer'))return self::fail($base,'PSTE_JOURNAL_AUTO_EMPTY_INPUT');
        $isQuestion=PSTE_Normalizer::isQuestion($raw);
        // The existing Journal classifier owns its editorial-intent finding ONCE.
        // The upstream one-time FACH/MAGAZIN switch reads this same evidence;
        // it must not run an additional lexical admission rule.
        $base['editorial_intent_proven']=self::hasExplicitEditorialIntent($raw);
        if(!$isQuestion&&!$base['editorial_intent_proven'])
            return self::fail($base,'PSTE_JOURNAL_AUTO_STATEMENT_INTENT_NOT_PROVEN');
        $q=self::lower(PSTE_Normalizer::exactTopicIdentityText($raw));
        if($q==='')return self::fail($base,'PSTE_JOURNAL_AUTO_EMPTY_NORMALIZED_QUESTION');

        // Existing Journal categories are equal contenders; old question-complexity
        // and DataForSEO-family admission requirements do not decide the type.
        // Product shopping remains on the existing Fach route.
        if(preg_match('/^(?:was\s+(?:kostet|kosten)\b|welch(?:e|es|er)\s+(?:futter|produkt|sattel|schermaschine|versicherung)\b)/u',$q)
            ||preg_match('/\b(?:testsieger|preisvergleich|kaufberatung|beste|besten|besser)\b/u',$q))
            return self::fail($base,'PSTE_JOURNAL_AUTO_PRODUCT_OR_PRICE_INTENT');
        // Retain the original Fach responsibility for direct factual quantities.
        if(preg_match('/^wie\s+(?:viel|viele|oft|hoch|schwer|breit|schnell)\b/u',$q))
            return self::fail($base,'PSTE_JOURNAL_AUTO_DIRECT_FACT_QUESTION');
        if($isQuestion && !preg_match('/^(?:warum|wieso|weshalb|wie\b|was\b|wann\b|welche\b|welcher\b|welches\b|wo\b|wer\b|sind\b|ist\b|kann\b|können\b|koennen\b|soll\b|sollte\b|muss\b|gibt\b|braucht\b|benötigt\b|benoetigt\b)/u',$q))
            return self::fail($base,'PSTE_JOURNAL_AUTO_NOT_A_READABLE_QUESTION');

        $domains=[];
        if(preg_match('/\b(?:zuegel|zuegeln|zügel|zügeln|reiten|reitet|reitweise|reitweisen|reithilfe|reithilfen|hilfengebung|schenkel|sitz|steigbügel|steigbuegel|galopp|trab|dressur|longieren|bodenarbeit|springen|springreiten|lenken|aeusseren|äusseren|äußeren|anlehnung|stellung|biegung|parade|paraden)\b/u',$q))$domains['training']='Ausbildung & Reitweisen';
        if(preg_match('/\b(?:verhalten|koerpersprache|körpersprache|angst|stress|herde|rangordnung|vertrauen|scheu|scheuen|aggressiv|aggression|ohren|mimik|wehrt|verweigert)\b/u',$q))$domains['understanding']='Pferde Verstehen';
        if(preg_match('/\b(?:offenstall|boxenhaltung|weidehaltung|herdenhaltung|paddocktrail|paddock\s*trail|haltung|haltungsform|haltungsformen|stallhaltung)\b/u',$q))$domains['housing']='Alltags-Pferde-Haltungsformen';
        if(preg_match('/\b(?:salzleckstein|salzlecksteine|heu|heuverzehr|futter|futters|fütterung|fuetterung|füttern|fuettern|fressen|futtern|ernährung|ernaehrung|weidegras|mineralfutter|kraftfutter|haferflocken|hafer|maisflocken|maiscobs|leinöl|leinoel|getreide|heulage|raufutter)\b/u',$q))$domains['feeding']='Pferdeernährung verstehen';
        if(!isset($domains['feeding'])&&!isset($domains['housing'])&&preg_match('/\b(?:weide|weidegang|koppel)\b/u',$q))$domains['housing']='Alltags-Pferde-Haltungsformen';
        if(preg_match('/\b(?:gesundheit|krankheit|krankheiten|lahmheit|kolik|koliken|husten|fieber|entzündung|entzuendung|tierarzt|verletzung|schmerzen|wunde|parasiten)\b/u',$q))$domains['health']='Pferdegesundheit verstehen';
        if(preg_match('/\b(?:pferderasse|pferderassen|pferdetyp|pferdetypen|warmblut|kaltblut|vollblut|pony|ponys|friese|haflinger|araber)\b/u',$q))$domains['breeds']='Pferderassen & Pferdetypen';
        if(preg_match('/\b(?:versicherung|versicherungen|pferdeversicherung|pferdeversicherungen|pferderecht|vorschriften|gesetz|gesetze|gesetzlich|haftung|kaufvertrag|stallmiete|stallkosten|unterhaltskosten|finanzierung|recht|steuern|pferdepass)\b/u',$q))$domains['law']='Recht, Finanzen & Organisation';
        if(preg_match('/\b(?:reitverein|gemeinschaft|reiterleben|reitergruppe|turnieralltag|stallgemeinschaft|pferdefreunde|gemeinschaftsleben)\b/u',$q))$domains['community']='Reiterleben & Community';

        if(count($domains)!==1)return self::fail($base,count($domains)>1?'PSTE_JOURNAL_AUTO_DOMAIN_AMBIGUOUS':'PSTE_JOURNAL_AUTO_DOMAIN_NOT_PROVEN');
        $key=(string)array_key_first($domains);$base['ok']=true;$base['status']='HIGH_CONFIDENCE_JOURNAL';$base['category_key']=$key;$base['category_name']=(string)$domains[$key];$base['reason_codes']=['PSTE_JOURNAL_AUTO_EDITORIAL_INTENT_AND_DOMAIN_PROVEN'];return $base;
    }

    /** Runtime metadata route. @return array<string,mixed> */
    public static function evaluate(string $raw,array $registry,string $sourceFamilyKey='',string $sourceFamilyName='',array $classification=[]): array {
        // Reuse the SAME category-independent classification made by the upstream
        // single area switch; never ask this same Journal owner to classify twice.
        if(($classification['contract']??'')!==self::CONTRACT
            ||(string)($classification['raw_query']??'')!==self::clean($raw))
            $classification=self::classifyQuestion($raw);
        $base=$classification+['article_type'=>'Journal','target_category'=>[],'family_key'=>'','family_name'=>'','normalization'=>[],'intent_profile'=>[],'semantic_consensus'=>[],'title_pipeline'=>[],'title'=>'','target_keyword'=>'','domain_risk'=>[],'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false];
        if(empty($classification['ok']))return $base;

        $spec=self::categorySpec((string)$classification['category_key']);
        if(!$spec)return self::fail($base,'PSTE_JOURNAL_AUTO_CATEGORY_SPEC_MISSING');
        $resolved=self::resolveRuntimeCategory($spec);
        $base['runtime_category_resolution']=$resolved;

        $risk=PSTE_Domain_Risk_Gate::evaluate($raw,'Journal');$base['domain_risk']=$risk;
        if(empty($risk['ok']))return self::fail($base,'PSTE_JOURNAL_AUTO_DOMAIN_RISK_REVIEW');

        // Journal scope/classification remains valid; title creation belongs ONLY to the language system.
        $title='';$targetKeyword='';
        $sourceFamilyName=trim($sourceFamilyName);$sourceFamilyKey=trim($sourceFamilyKey);
        // Journal category and semantic topic family are different concepts. For a query that already
        // has a proven portal family (e.g. Zügel), retain that family for title/duplicate semantics.
        // Using the broad Journal category name as the family made valid titles fail the existing
        // editorial family-presence gate (e.g. a Zügel question does not literally say
        // 'Ausbildung & Reitweisen'). No category/type authority is taken from this family binding.
        // Broad Journal category labels are not subject terms. When the query explicitly
        // names a horse and no narrower proven family exists, use that literal subject;
        // do not require editorial titles to repeat a magazine-section label.
        $literalHorse=(bool)preg_match('/\b(?:pferd|pferde|pferdes|pferden)\b/iu',$raw);
        $familyName=$sourceFamilyName!==''?$sourceFamilyName:
            ($literalHorse?'Pferd':self::questionSubject($raw,(string)$classification['category_key']));
        if($familyName==='')return self::fail($base,'PSTE_JOURNAL_AUTO_SUBJECT_NOT_PROVEN');
        $familyKey=$sourceFamilyKey!==''?$sourceFamilyKey:hash('sha256','PSTE_JOURNAL_AUTO_SCOPE_V1|'.(string)$classification['category_key'].'|'.PSTE_Normalizer::exactTopicIdentityText($raw));
        $normalization=['contract'=>'PSTE_EDITORIAL_TOPIC_NORMALIZER_V2','raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),'family'=>$familyName,'normalized_topic'=>rtrim($raw," ?\t\n\r\0\x0B"),'subject_topic'=>$familyName,'semantic_probe'=>PSTE_Editorial_Topic_Normalizer::semanticProbe($raw),'qualifier'=>'','relation'=>'','detected_action'=>'','intent_signals'=>['JOURNAL_COMPLEX_QUESTION'],'status'=>'PASS','reason_codes'=>['PSTE_JOURNAL_AUTO_MEANING_PRESERVED'],'review_flags'=>[],'raw_query_modified'=>false,'write_attempted'=>false];
        $intent=['contract'=>'PSTE_INTENT_PROFILE_V4_EVIDENCE_BOUND','ok'=>true,'status'=>'PASS','search_intent'=>'EDITORIAL_INFORMATION','primary_user_goal'=>'EDITORIAL_INFORMATION','primary_article_type_candidate'=>'Journal','intent_angle'=>'JOURNAL_COMPLEX_QUESTION','evidence_authority'=>self::CONTRACT,'scope_status'=>'PROVEN','intent_status'=>'PROVEN','raw_query_sha256'=>hash('sha256',$raw),'write_attempted'=>false];
        $intent['profile_sha256']=hash('sha256',self::stable($intent));
        // No second question/title composer in the Journal route. Keep class evidence
        // for the existing title-only import instead of pretending a finished title.
        $base['article_type']='Journal';$base['family_key']=$familyKey;$base['family_name']=$familyName;
        $base['normalization']=$normalization;$base['intent_profile']=$intent;
        $base['title']='';$base['target_keyword']='';$base['title_pipeline']=[];
        $base['runtime_category_resolution']=$resolved;
        $base['status']='REVIEW_REQUIRED';$base['ok']=false;
        $base['reason_codes']=['PSTE_LANGUAGE_TITLE_REQUIRED'];
        return $base;
    }

    /** A real subject from the original question, not the broad Magazin heading. */
    private static function questionSubject(string $raw,string $key): string {
        $subjects=['training'=>['Longieren','Bodenarbeit','Reiten','Steigbügel','Zügel','Dressur','Galopp','Trab','Springreiten'],
            'understanding'=>['Herde','Rangordnung','Verhalten','Körpersprache','Vertrauen','Stress','Angst'],
            'housing'=>['Weidehaltung','Weide','Offenstall','Stallhaltung','Paddocktrail','Haltung'],
            'feeding'=>['Salzleckstein','Haferflocken','Hafer','Leinöl','Heuverzehr','Fütterung','Ernährung','Futter','Heu'],
            'health'=>['Kolik','Husten','Lahmheit','Gesundheit'],
            'breeds'=>['Haflinger','Araber','Pony','Pferderassen'],
            'law'=>['Vorschriften','Pferdepass','Kaufvertrag','Versicherung','Haftung','Kosten'],
            'community'=>['Reitverein','Stallgemeinschaft','Turnieralltag']];
        foreach(($subjects[$key]??[]) as $subject){
            if(preg_match('/\b'.preg_quote($subject,'/').'(?:n|e|s|en)?\b/iu',$raw))return $subject;
        }
        return '';
    }

    /** @return array<string,mixed> */
    private static function categorySpec(string $key): array {
        $d=PSTE_Journal_Article_Type::definition();
        foreach((array)($d['journal_categories']['categories']??[]) as $row)if((string)($row['key']??'')===$key)return (array)$row;
        return [];
    }
    /** @return array<string,mixed> */
    private static function resolveRuntimeCategory(array $spec): array {
        if(!function_exists('get_term_by'))return ['ok'=>false,'status'=>'WORDPRESS_TERM_API_UNAVAILABLE','term_id'=>0,'name'=>'','slug'=>''];
        $matches=[];foreach((array)($spec['runtime_slugs']??[]) as $slug){$term=get_term_by('slug',(string)$slug,'category');if(!$term||(function_exists('is_wp_error')&&is_wp_error($term)))continue;$id=(int)($term->term_id??0);$actual=trim((string)($term->slug??''));if($id>0&&$actual!=='')$matches[$id]=['term_id'=>$id,'name'=>trim((string)($term->name??'')),'slug'=>$actual,'taxonomy'=>(string)($term->taxonomy??'category')];}
        if(count($matches)!==1)return ['ok'=>false,'status'=>count($matches)>1?'AMBIGUOUS':'NOT_FOUND','term_id'=>0,'name'=>'','slug'=>''];
        $m=array_values($matches)[0];if((string)$m['taxonomy']!=='category')return ['ok'=>false,'status'=>'TAXONOMY_MISMATCH','term_id'=>0,'name'=>'','slug'=>''];return ['ok'=>true,'status'=>'RESOLVED']+$m;
    }
    private static function fail(array $base,string $reason): array {$base['ok']=false;if(in_array((string)($base['status']??''),['HIGH_CONFIDENCE_JOURNAL','JOURNAL_AUTO_PASS'],true))$base['status']='REVIEW_REQUIRED';$base['reason_codes']=array_values(array_unique(array_merge((array)($base['reason_codes']??[]),[$reason])));return $base;}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');return trim((string)preg_replace('/\s+/u',' ',$v));}
    private static function lower(string $v): string {return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
    private static function stable($value): string {if(is_array($value)){if(array_keys($value)===range(0,count($value)-1))$value=array_map([self::class,'stableValue'],$value);else{ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=self::stableValue($v);}}$j=function_exists('wp_json_encode')?wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($j)?$j:'';}
    private static function stableValue($value){if(!is_array($value))return $value;if($value===[])return [];if(array_keys($value)===range(0,count($value)-1))return array_map([self::class,'stableValue'],$value);ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=self::stableValue($v);return $value;}
}
