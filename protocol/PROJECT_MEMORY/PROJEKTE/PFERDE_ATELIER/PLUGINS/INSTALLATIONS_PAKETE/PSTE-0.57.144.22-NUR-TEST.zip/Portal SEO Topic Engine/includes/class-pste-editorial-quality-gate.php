<?php
if (!defined('ABSPATH')) { return; }

/**
 * Independent editorial veto. It never composes, repairs or rewrites a title.
 * A PASS means only that this metadata title preserves the researched subject and is editorially usable.
 */
final class PSTE_Editorial_Quality_Gate {
    public const CONTRACT='PSTE_EDITORIAL_QUALITY_GATE_V4_HARD_TITLE_SURFACE_INTENT_SAFE';
    /** @return array<string,mixed> */
    public static function evaluate(string $title,string $raw,string $normalizedTopic,string $family,string $type,array $intentProfile=[],string $targetKeyword=''): array {
        $title=self::clean($title);$raw=self::clean($raw);$normalizedTopic=self::clean($normalizedTopic);$family=self::clean($family);$reasons=[];$review=[];
        $words=preg_split('/\s+/u',rtrim($title,'?'))?:[];$canon=PSTE_Article_Type_Registry::canonicalType($type);
        if($title==='')$reasons[]='EDITORIAL_TITLE_EMPTY';
        if(count($words)<2||count($words)>16)$reasons[]='EDITORIAL_TITLE_WORD_COUNT_OUTSIDE_SAFE_RANGE';
        if($family!==''&&!self::familySemanticallyPresent($title,$family))$reasons[]='EDITORIAL_TITLE_FAMILY_MISSING';
        if(str_contains($title,'mit Schwerpunkt'))$reasons[]='EDITORIAL_GENERIC_KEYWORD_BRIDGE_FORBIDDEN';
        if(preg_match('/\b(testsieger|garantiert|billigste|günstigste|guenstigste|beste|bester|bestes|besten)\b/iu',$title,$claim)&&($canon!=='faq'||!preg_match('/\b'.preg_quote((string)$claim[1],'/').'\b/iu',$raw)))$reasons[]='EDITORIAL_UNSUPPORTED_CLAIM_OR_SUPERLATIVE';
        if(PSTE_Normalizer::staleYear($raw)!==null||PSTE_Normalizer::staleYear($title)!==null)$reasons[]='EDITORIAL_STALE_YEAR_SPECIFIC_TOPIC';
        if(self::pureTransactional($raw))$reasons[]='EDITORIAL_NON_EDITORIAL_TRANSACTIONAL_QUERY';
        if(!self::meaningPreserved($title,$raw,$family,$canon))$reasons[]='EDITORIAL_SOURCE_MEANING_NOT_PRESERVED';
        // A source brand using a joined alphanumeric mark must never be silently rewritten
        // into a different brand name by the title/keyword sanitizer.
        if(preg_match_all('/(?<![\p{L}\p{N}])\p{L}+(?:\+\p{L}+)+(?![\p{L}\p{N}])/u',$raw,$brandHits)){
            foreach($brandHits[0] as $joinedBrand){if(!str_contains(self::lower($title),self::lower($joinedBrand)))$reasons[]='EDITORIAL_SOURCE_BRAND_SYMBOL_NOT_PRESERVED';}
        }
        if(PSTE_Title_Validator::hasArtificialGeneratorPhrase($title))$reasons[]='EDITORIAL_ARTIFICIAL_GENERATOR_PHRASE_FORBIDDEN';
        if($canon==='journal'&&PSTE_Normalizer::isQuestion($title)&&!self::questionSyntaxPlausible($title))$reasons[]='EDITORIAL_JOURNAL_QUESTION_GRAMMAR_NOT_PLAUSIBLE';
        $typeSignals=self::typeSignalAssessment($title,$canon,$targetKeyword,$family);
        if(empty($typeSignals['expected_visible']))$reasons[]='EDITORIAL_ARTICLE_TYPE_INTENT_NOT_VISIBLE_IN_TITLE';
        if(!empty($typeSignals['conflicting_types']))$reasons[]='EDITORIAL_ARTICLE_TYPE_INTENT_CONFLICT_IN_TITLE';
        if(PSTE_Title_Validator::isKeywordStaccato($title,$type))$reasons[]='EDITORIAL_KEYWORD_CHAIN_STYLE_FORBIDDEN';
        if($canon==='journal'&&PSTE_Title_Validator::isJournalKeywordStaccatoStrict($title))$reasons[]='EDITORIAL_JOURNAL_KEYWORD_CHAIN_STYLE_STRICT_FORBIDDEN';
        if($canon!=='faq'&&!self::nonFaqSurfacePlausible($title))$reasons[]='EDITORIAL_NONFAQ_SURFACE_NOT_PLAUSIBLE';
        if(self::hasDanglingRelation($title))$reasons[]='EDITORIAL_DANGLING_RELATION';
        if(self::redundantCompound($title))$reasons[]='EDITORIAL_REDUNDANT_COMPOUND';
        if($canon==='')$reasons[]='EDITORIAL_ARTICLE_TYPE_MISSING';
        if(self::normComparable($title)===self::normComparable($raw))$review[]='EDITORIAL_RAW_PHRASE_IDENTITY_STRICT_REVIEW_FLAG';

        // Raw identity is not itself a failure. It passes only if all independent quality rules pass.
        $status=$reasons?'FAIL':'PASS';
        return ['contract'=>self::CONTRACT,'ok'=>$status==='PASS','status'=>$status,'reason_codes'=>array_values(array_unique($reasons)),'review_flags'=>array_values(array_unique($review)),'raw_query_sha256'=>hash('sha256',$raw),'normalized_topic_sha256'=>hash('sha256',$normalizedTopic),'title_sha256'=>hash('sha256',$title),'family_sha256'=>hash('sha256',$family),'article_type'=>$type,'intent_profile_sha256'=>hash('sha256',self::stable($intentProfile)),'composer_called'=>false,'title_modified'=>false,'technical_gate_result_consumed'=>false,'write_attempted'=>false];
    }

    /** @return array{expected_visible:bool,conflicting_types:list<string>,strong_types:list<string>,suffix_types:list<string>} */
    private static function typeSignalAssessment(string $title,string $canon,string $targetKeyword='',string $family=''): array {
        if($canon==='faq')return ['expected_visible'=>PSTE_Normalizer::isQuestion($title)&&str_ends_with($title,'?'),'conflicting_types'=>[],'strong_types'=>[],'suffix_types'=>[]];
        if($canon==='journal'){
            $signals=[];foreach(PSTE_Article_Type_Intent_Ontology::strongSignals($title) as $type){$c=PSTE_Article_Type_Registry::canonicalType((string)$type);if($c!==''&&$c!=='journal')$signals[$c]=true;}
            return ['expected_visible'=>$title!=='','conflicting_types'=>array_keys($signals),'strong_types'=>array_keys($signals),'suffix_types'=>array_keys($signals)];
        }
        // Ownership boundary: the researched target keyword is immutable upstream evidence. A word inside
        // that keyword/family (for example "Sicherheitswesten") must never be reinterpreted here as a
        // competing article type. Only wording added by the title owner may create a new conflict.
        $immutable=self::clean($targetKeyword);if($immutable==='')$immutable=self::clean($family);
        $suffix=$title;
        if($immutable!==''){$pattern='/'.preg_quote($immutable,'/').'/iu';$stripped=preg_replace($pattern,' ',$title,1);if(is_string($stripped)&&$stripped!==$title)$suffix=self::clean($stripped);}
        $all=[];foreach(PSTE_Article_Type_Intent_Ontology::strongSignals($title) as $type){$c=PSTE_Article_Type_Registry::canonicalType((string)$type);if($c!=='')$all[$c]=true;}
        $suffixSet=[];foreach(PSTE_Article_Type_Intent_Ontology::strongSignals($suffix) as $type){$c=PSTE_Article_Type_Registry::canonicalType((string)$type);if($c!=='')$suffixSet[$c]=true;}
        $conflicts=array_values(array_filter(array_keys($suffixSet),static fn($type)=>$type!==$canon));
        $expectedVisible=isset($all[$canon]);
        // The article type is already bound before title validation. For Beratung only, accept
        // natural decision-support wording on the added title surface without teaching the
        // upstream article-type classifier new routing signals. This keeps classification frozen
        // while allowing natural titles beyond repeated Auswahl/Kriterien formulas.
        if($canon==='beratung'&&!$expectedVisible&&self::naturalBeratungSurface($suffix))$expectedVisible=true;
        return ['expected_visible'=>$expectedVisible,'conflicting_types'=>$conflicts,'strong_types'=>array_keys($all),'suffix_types'=>array_keys($suffixSet)];
    }
    private static function naturalBeratungSurface(string $surface): bool {
        $surface=self::clean($surface);if($surface==='')return false;
        // Beratung is already independently bound at this point. Accept ordinary editorial
        // decision-help language without forcing the title back into an Auswahl/Kriterien or
        // office-language vocabulary. These signals are title-surface only and never participate
        // in upstream article-type classification.
        return (bool)preg_match('/\b(?:acht\w*|wiss\w*|wichtig\w*|zähl\w*|zaehl\w*|unterscheid\w*|ausmach\w*|überseh\w*|ueberseh\w*|ankomm\w*|klär\w*|klaer\w*|entscheid\w*|eigenschaft\w*|auszeichn\w*|mach\w*|pass\w*|platzier\w*|sinnvoll\w*|eign\w*|geeignet\w*|frag\w*|prüf\w*|pruef\w*|find\w*|wähl\w*|waehl\w*)\b/iu',$surface);
    }
    private static function meaningPreserved(string $title,string $raw,string $family,string $boundType): bool {
        if($raw===''||$title==='')return false;
        if(PSTE_Normalizer::isQuestion($raw)){
            if($family!==''&&!self::familySemanticallyPresent($title,$family))return false;
            $source=self::questionMeaningTokens($raw,$family);if(!$source)return true;
            $target=PSTE_Token_Equivalence::tokens(str_replace('-',' ',$title));$covered=count(array_intersect($source,$target));
            if($covered/count($source)>=0.75)return true;
            // The EXISTING one intent ontology already equates source "kostet"
            // with title "Kosten". Do not overrule that decision by comparing
            // just the different inflections as if they were different topics.
            // Only an unambiguous same-type question-to-statement conversion
            // can use this: every remaining source qualifier must survive.
            if($boundType===''||$boundType==='faq')return false;
            $rawSignals=PSTE_Article_Type_Intent_Ontology::strongSignals($raw);
            $titleSignals=PSTE_Article_Type_Intent_Ontology::strongSignals($title);
            if(count($rawSignals)!==1||count($titleSignals)!==1
                ||PSTE_Article_Type_Registry::canonicalType((string)$rawSignals[0])!==$boundType
                ||PSTE_Article_Type_Registry::canonicalType((string)$titleSignals[0])!==$boundType)return false;
            $remaining=self::questionMeaningTokens(
                PSTE_Article_Type_Intent_Ontology::stripBoundTypeSignals($raw,$boundType),$family);
            // No non-intent long-tail qualifier may vanish; original category/
            // article-type and the exact keyword gates remain unchanged.
            return count(array_diff($remaining,$target))===0;
        }
        $required=PSTE_Editorial_Topic_Normalizer::semanticContentTokens($raw,$family);
        if(!$required)return $family!==''&&self::familySemanticallyPresent($title,$family);
        $titleTokens=PSTE_Token_Equivalence::tokens(str_replace('-',' ',$title));$covered=count(array_intersect($required,$titleTokens));
        return $covered/count($required)>=0.80;
    }

    /** @return list<string> */
    private static function questionMeaningTokens(string $raw,string $family): array {
        $tokens=PSTE_Token_Equivalence::tokens(str_replace('-',' ',$raw));$familyTokens=PSTE_Token_Equivalence::tokens(str_replace('-',' ',$family));
        $stop=[];foreach(['wie','was','wann','warum','wieso','weshalb','welche','welcher','welches','kann','koennen','darf','soll','ist','sind','gibt','braucht','eine','ein','einer','einem','einen','der','die','das','den','dem','des','ich','du','er','sie','es','wir','ihr','man','auf','an','im','in','mit','fuer','für','ohne','von','bei','zum','zur'] as $w)foreach(PSTE_Token_Equivalence::tokens($w) as $t)$stop[$t]=true;
        $out=[];foreach($tokens as $t)if(!isset($stop[$t])&&!in_array($t,$familyTokens,true))$out[]=$t;return array_values(array_unique($out));
    }
    private static function familySemanticallyPresent(string $value,string $family): bool {
        $actual=PSTE_Family_Identity_V2::tokens($value,false);$wanted=PSTE_Family_Identity_V2::tokens($family,false);if(!$actual||!$wanted)return false;
        foreach($wanted as $head){$found=false;foreach($actual as $token){if($token===$head||self::germanUmlautPluralEquivalent($token,$head)){$found=true;break;}foreach(['t','st'] as $suffix){if(strlen($token)>strlen($suffix)+4&&str_ends_with($token,$suffix)&&substr($token,0,-strlen($suffix))===$head){$found=true;break 2;}}}if(!$found)return false;}
        return true;
    }
    private static function germanUmlautPluralEquivalent(string $left,string $right): bool {
        if(strlen($left)<6||strlen($right)<6)return false;
        $fold=static function(string $v): string {return (string)(preg_replace('/([aou])e(?=[a-z])/','\1',$v)??$v);};
        $a=$fold($left);$b=$fold($right);if($a===$b)return true;
        foreach(['e','en','er','n','s'] as $suffix){if(strlen($a)>strlen($suffix)+5&&str_ends_with($a,$suffix)&&substr($a,0,-strlen($suffix))===$b)return true;if(strlen($b)>strlen($suffix)+5&&str_ends_with($b,$suffix)&&substr($b,0,-strlen($suffix))===$a)return true;}
        return false;
    }

    private static function questionSyntaxPlausible(string $title): bool {
        if(!PSTE_Normalizer::isQuestion($title)||!str_ends_with($title,'?'))return false;
        $q=self::clean(rtrim($title,'?'));if(str_contains($q,'–'))return true;
        $low=self::lower($q);
        if(preg_match('/^wie\b/u',$low)){
            if((bool)preg_match('/\b(ist|sind|kann|können|koennen|soll|sollen|muss|müssen|muessen|geht|funktioniert|passt|eignet|wird|werden|hat|haben|lässt|laesst|sollte|heißt|heisst)\b/u',$low))return true;
            // Natural German W-questions can start with a finite full verb: "Wie reinigt man ...?".
            // Require a finite-looking verb directly before a pronoun; telegraphic "Wie X installieren?" stays blocked.
            return (bool)preg_match('/^wie\s+[\p{L}-]{2,}\s+(man|ich|du|er|sie|es|wir|ihr)\b/u',$low);
        }
        if(preg_match('/^was\b/u',$low))return (bool)preg_match('/\b(ist|sind|kostet|kosten|kann|soll|braucht|benötigt|benoetigt|bedeutet|hilft|schadet|übernimmt|uebernimmt|deckt|bewirkt|bringt|prüft|prueft)\b/u',$low);
        if(preg_match('/^(welcher|welche|welches)\b/u',$low))return (bool)preg_match('/\b(ist|sind|passt|passen|eignet|eignen|hat|haben|kann|können|koennen|soll|sollen|braucht|benötigt|benoetigt|übernimmt|uebernimmt|gibt|deckt)\b/u',$low);
        if(preg_match('/^kann\b/u',$low))return (bool)preg_match('/^kann\s+(ich|man|ein|eine|der|die|das|es|das\s+.+)\b/u',$low);
        return true;
    }


    private static function nonFaqSurfacePlausible(string $title): bool {
        $clean=self::clean($title);if($clean==='')return false;
        // Deterministic grammar guard: reject known dangling/helper constructions and obviously
        // telegraphic chains. Natural compact noun/infinitive titles remain allowed.
        if(PSTE_Title_Validator::hasArtificialGeneratorPhrase($clean))return false;
        if((bool)preg_match('/\b(?:umsetzen|einordnen|beurteilen)\s*$/iu',$clean))return false;
        if((bool)preg_match('/\b(?:mit|für|fuer|von|bei|im|in|auf|unter|zum|zur)\s*$/iu',$clean))return false;
        return true;
    }

    private static function redundantCompound(string $title): bool {
        if(!preg_match_all('/\b([\p{L}\d]+)-([\p{L}\d]+)\b/u',$title,$matches,PREG_SET_ORDER))return false;
        foreach($matches as $m){$a=PSTE_Token_Equivalence::tokens((string)$m[1]);$b=PSTE_Token_Equivalence::tokens((string)$m[2]);foreach($a as $x)foreach($b as $y){$max=min(strlen($x),strlen($y),10);for($n=$max;$n>=4;$n--)if(substr($x,-$n)===substr($y,-$n))return true;}}
        return false;
    }
    private static function hasDanglingRelation(string $title): bool {return (bool)preg_match('/\b(mit|für|fuer|ohne|gegen|von|bei|im|in|auf|unter|zum|zur)\s+(im\s+Vergleich|sinnvoll|richtig|sicher|einordnen|imprägnier\w*|impraegnier\w*|reparier\w*|trockn\w*|wart\w*)\b/iu',$title);}
    private static function pureTransactional(string $query): bool {$t=(bool)preg_match('/\b(sale|angebot|angebote|rabatt|gutschein|coupon|shop|online\s+kaufen|bestellen)\b/iu',$query);$i=(bool)preg_match('/\b(preis|preise|kosten|kostet|budget|vergleich|test|reparieren|reinigen|waschen|pflegen|installieren|montieren|anwenden|dosieren|lagern|aufbewahren|übung|uebung)\b/iu',$query);return $t&&!$i;}
    private static function normComparable(string $v): string {$v=self::lower(self::clean($v));$v=strtr($v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);return trim((string)preg_replace('/[^a-z0-9]+/u',' ',$v));}
    private static function stable($value): string {$value=self::canonicalize($value);$json=function_exists('wp_json_encode')?wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($json)?$json:'';}
    private static function canonicalize($value){if(!is_array($value))return $value;if($value===[])return [];$list=array_keys($value)===range(0,count($value)-1);if($list)return array_map([self::class,'canonicalize'],$value);ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=self::canonicalize($v);return $value;}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');return trim((string)preg_replace('/\s+/u',' ',$v));}
    private static function lower(string $v): string{return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
}
