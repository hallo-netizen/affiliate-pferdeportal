<?php
if (!defined('ABSPATH')) { return; }

/** Lossless immutable parking store for interrupted/cancelled research jobs. */
final class PSTE_Research_Archive {
    public const CONTRACT='PSTE_RESEARCH_PARKED_JOB_V1';
    public const INDEX_CONTRACT='PSTE_RESEARCH_PARKED_INDEX_V1';

    /** @return array<string,mixed> */
    public static function store(array $job,string $reason,array $context=[]): array {
        $uuid=trim((string)($job['job_uuid']??''));
        if($uuid===''||!preg_match('/^[a-f0-9-]{20,64}$/i',$uuid))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_JOB_UUID_INVALID');
        $reason=self::code($reason!==''?$reason:'PSTE_RESEARCH_PARKED');
        $savedAt=gmdate('c');
        $record=[
            'contract'=>self::CONTRACT,
            'job_uuid'=>$uuid,
            'park_reason'=>$reason,
            'parked_at_utc'=>$savedAt,
            'plugin_version'=>(string)PSTE_VERSION,
            'owner_kind'=>(string)($job['owner_kind']??''),
            'owner_queue_uuid'=>(string)($job['owner_queue_uuid']??''),
            'owner_item_index'=>(int)($job['owner_item_index']??-1),
            'source_status'=>(string)($job['status']??''),
            'source_phase'=>(string)($job['phase']??''),
            'source_phase_state'=>(string)($job['phase_state']??''),
            'context'=>self::safeContext($context),
        ];
        $record=array_merge($record,self::packJob($job));
        $record['sha256']=self::hash($record);
        $key=self::optionKey($uuid);
        $existing=get_option($key,null);
        if(is_array($existing)){
            if(!self::valid($existing))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_EXISTING_INVALID');
            // Archive is immutable. A retry after a crash may re-store the exact same logical job.
            if(!hash_equals(hash('sha256',self::json(self::unpackJob($existing))),hash('sha256',self::json($job))))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_IMMUTABLE_CONFLICT');
            return self::publicRecord($existing);
        }
        update_option($key,$record,false);
        $stored=get_option($key,null);
        if(!is_array($stored)||!self::valid($stored)||!hash_equals((string)$record['sha256'],(string)($stored['sha256']??'')))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_READBACK_MISMATCH');
        $storedJob=self::unpackJob($stored);if(!hash_equals(hash('sha256',self::json($job)),hash('sha256',self::json($storedJob))))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_JOB_READBACK_MISMATCH');

        $index=self::indexRaw();
        $items=(array)($index['items']??[]);
        $items[$uuid]=[
            'job_uuid'=>$uuid,'park_reason'=>$reason,'parked_at_utc'=>$savedAt,
            'owner_kind'=>(string)($job['owner_kind']??''),'owner_queue_uuid'=>(string)($job['owner_queue_uuid']??''),
            'owner_item_index'=>(int)($job['owner_item_index']??-1),'source_status'=>(string)($job['status']??''),
            'source_phase'=>(string)($job['phase']??''),'archive_sha256'=>(string)$record['sha256'],
        ];
        ksort($items,SORT_STRING);
        $next=['contract'=>self::INDEX_CONTRACT,'items'=>$items,'updated_at_utc'=>$savedAt];
        $next['sha256']=self::hash($next);
        update_option(PSTE_OPTION_RESEARCH_PARKED_INDEX,$next,false);
        $read=get_option(PSTE_OPTION_RESEARCH_PARKED_INDEX,null);
        if(!is_array($read)||!self::validIndex($read)||!isset($read['items'][$uuid])||!hash_equals((string)$record['sha256'],(string)($read['items'][$uuid]['archive_sha256']??'')))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_INDEX_READBACK_MISMATCH');
        return self::publicRecord($record);
    }

    /** @return array<string,mixed>|null */
    public static function get(string $uuid): ?array {
        $uuid=trim($uuid);if($uuid==='')return null;
        $record=get_option(self::optionKey($uuid),null);if($record===null||$record===false||$record==='')return null;
        if(!is_array($record)||!self::valid($record))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_INVALID');
        $logical=$record;$logical['job']=self::unpackJob($record);unset($logical['job_codec'],$logical['job_blob_b64'],$logical['job_sha256']);return $logical;
    }

    /** Find a previously verified parked child for a breadth owner after a crash between archive and queue bookkeeping. */
    public static function findForOwner(string $queueUuid,int $itemIndex): ?array {
        $index=self::indexRaw();$matches=[];
        foreach((array)($index['items']??[]) as $row){if(!is_array($row))continue;if((string)($row['owner_kind']??'')!=='BREADTH')continue;if(!hash_equals($queueUuid,(string)($row['owner_queue_uuid']??'')))continue;if((int)($row['owner_item_index']??-1)!==$itemIndex)continue;$matches[]=$row;}
        if(!$matches)return null;usort($matches,static fn($a,$b)=>strcmp((string)($b['parked_at_utc']??''),(string)($a['parked_at_utc']??'')));$uuid=(string)($matches[0]['job_uuid']??'');return $uuid!==''?self::get($uuid):null;
    }

    /** @return array<string,mixed> */
    public static function status(): array {
        $index=self::indexRaw();$items=(array)($index['items']??[]);$recent=array_values($items);
        usort($recent,static fn($a,$b)=>strcmp((string)($b['parked_at_utc']??''),(string)($a['parked_at_utc']??'')));
        return ['contract'=>self::INDEX_CONTRACT,'count'=>count($items),'recent'=>array_slice($recent,0,10),'updated_at_utc'=>(string)($index['updated_at_utc']??'')];
    }

    /** @return array<string,mixed> */
    private static function indexRaw(): array {
        $raw=get_option(PSTE_OPTION_RESEARCH_PARKED_INDEX,null);
        if($raw===null||$raw===false||$raw==='')return ['contract'=>self::INDEX_CONTRACT,'items'=>[],'updated_at_utc'=>''];
        if(!is_array($raw)||!self::validIndex($raw))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_INDEX_INVALID');
        return $raw;
    }


    /** @return array<string,mixed> */
    private static function ensureStorageCodec(): void {if(!class_exists('PSTE_Storage_Codec',false))require_once PSTE_DIR.'includes/class-pste-storage-codec.php';}

    private static function packJob(array $job): array {
        self::ensureStorageCodec();
        $packed=PSTE_Storage_Codec::packArray($job,'PSTE_RESEARCH_ARCHIVE_JOB');
        return is_array($packed)?['job_codec'=>(string)$packed['codec'],'job_blob_b64'=>(string)$packed['blob_b64'],'job_sha256'=>(string)$packed['sha256']]:['job'=>$job];
    }
    /** @return array<string,mixed> */
    private static function unpackJob(array $record): array {
        if(array_key_exists('job',$record))return is_array($record['job'])?$record['job']:[];
        self::ensureStorageCodec();return PSTE_Storage_Codec::unpackArray(['codec'=>(string)($record['job_codec']??''),'blob_b64'=>(string)($record['job_blob_b64']??''),'sha256'=>(string)($record['job_sha256']??'')],'PSTE_RESEARCH_ARCHIVE_JOB');
    }

    /** Losslessly compact existing immutable parked jobs in bounded batches. */
    public static function compactStorageBatch(int $offset=0,int $limit=3): array {
        self::ensureStorageCodec();
        $offset=max(0,$offset);$limit=max(1,min(20,$limit));$index=self::indexRaw();$items=(array)($index['items']??[]);$uuids=array_keys($items);sort($uuids,SORT_STRING);$slice=array_slice($uuids,$offset,$limit);$processed=0;$changed=0;$beforeBytes=0;$afterBytes=0;
        foreach($slice as $uuid){$key=self::optionKey((string)$uuid);$raw=get_option($key,null);if(!is_array($raw)||!self::valid($raw))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_COMPACT_SOURCE_INVALID');$job=self::unpackJob($raw);$logicalHash=PSTE_Storage_Codec::logicalHash($job,'PSTE_RESEARCH_ARCHIVE_COMPACT');$beforeBytes+=strlen(serialize($raw));$base=$raw;unset($base['sha256'],$base['job'],$base['job_codec'],$base['job_blob_b64'],$base['job_sha256']);$next=array_merge($base,self::packJob($job));$next['sha256']=self::hash($next);$afterBytes+=strlen(serialize($next));
            if($next!==$raw){update_option($key,$next,false);$stored=get_option($key,null);if(!is_array($stored)||!self::valid($stored)||!hash_equals((string)$next['sha256'],(string)($stored['sha256']??'')))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_COMPACT_READBACK_MISMATCH');$readJob=self::unpackJob($stored);if(!hash_equals($logicalHash,PSTE_Storage_Codec::logicalHash($readJob,'PSTE_RESEARCH_ARCHIVE_COMPACT_READBACK')))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_COMPACT_LOGICAL_MISMATCH');$items[$uuid]['archive_sha256']=(string)$next['sha256'];$changed++;}
            $processed++;
        }
        if($changed>0){ksort($items,SORT_STRING);$nextIndex=['contract'=>self::INDEX_CONTRACT,'items'=>$items,'updated_at_utc'=>gmdate('c')];$nextIndex['sha256']=self::hash($nextIndex);update_option(PSTE_OPTION_RESEARCH_PARKED_INDEX,$nextIndex,false);$read=self::indexRaw();if(!hash_equals((string)$nextIndex['sha256'],(string)($read['sha256']??'')))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_COMPACT_INDEX_READBACK_MISMATCH');}
        $nextOffset=$offset+$processed;return ['contract'=>'PSTE_RESEARCH_ARCHIVE_STORAGE_COMPACTION_BATCH_V1','processed'=>$processed,'changed'=>$changed,'cursor'=>$nextOffset,'complete'=>$nextOffset>=count($uuids),'before_bytes'=>$beforeBytes,'after_bytes'=>$afterBytes,'saved_bytes'=>max(0,$beforeBytes-$afterBytes),'total'=>count($uuids)];
    }

    /** Restore archived jobs to the exact legacy raw-job envelope for safe downgrade. */
    public static function restoreLegacyStorageBatch(int $offset=0,int $limit=3): array {
        self::ensureStorageCodec();
        $offset=max(0,$offset);$limit=max(1,min(20,$limit));$index=self::indexRaw();$items=(array)($index['items']??[]);$uuids=array_keys($items);sort($uuids,SORT_STRING);$slice=array_slice($uuids,$offset,$limit);$processed=0;$changed=0;
        foreach($slice as $uuid){$key=self::optionKey((string)$uuid);$raw=get_option($key,null);if(!is_array($raw)||!self::valid($raw))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_RESTORE_SOURCE_INVALID');$job=self::unpackJob($raw);$logicalHash=PSTE_Storage_Codec::logicalHash($job,'PSTE_RESEARCH_ARCHIVE_RESTORE');$base=$raw;unset($base['sha256'],$base['job'],$base['job_codec'],$base['job_blob_b64'],$base['job_sha256']);$next=$base+['job'=>$job];$next['sha256']=self::hash($next);
            if($next!==$raw){update_option($key,$next,false);$stored=get_option($key,null);if(!is_array($stored)||!array_key_exists('job',$stored)||!self::valid($stored)||!hash_equals((string)$next['sha256'],(string)($stored['sha256']??'')))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_RESTORE_READBACK_MISMATCH');$readJob=(array)$stored['job'];if(!hash_equals($logicalHash,PSTE_Storage_Codec::logicalHash($readJob,'PSTE_RESEARCH_ARCHIVE_RESTORE_READBACK')))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_RESTORE_LOGICAL_MISMATCH');$items[$uuid]['archive_sha256']=(string)$next['sha256'];$changed++;}
            $processed++;
        }
        if($changed>0){ksort($items,SORT_STRING);$nextIndex=['contract'=>self::INDEX_CONTRACT,'items'=>$items,'updated_at_utc'=>gmdate('c')];$nextIndex['sha256']=self::hash($nextIndex);update_option(PSTE_OPTION_RESEARCH_PARKED_INDEX,$nextIndex,false);$read=self::indexRaw();if(!hash_equals((string)$nextIndex['sha256'],(string)($read['sha256']??'')))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_RESTORE_INDEX_READBACK_MISMATCH');}
        $nextOffset=$offset+$processed;return ['contract'=>'PSTE_RESEARCH_ARCHIVE_LEGACY_RESTORE_BATCH_V1','processed'=>$processed,'changed'=>$changed,'cursor'=>$nextOffset,'complete'=>$nextOffset>=count($uuids),'saved_bytes'=>0,'total'=>count($uuids)];
    }

    private static function optionKey(string $uuid): string {return PSTE_RESEARCH_PARKED_PREFIX.strtolower(preg_replace('/[^a-f0-9-]/i','',$uuid)??'');}
    private static function valid(array $record): bool {if(($record['contract']??'')!==self::CONTRACT)return false;$decl=(string)($record['sha256']??'');return preg_match('/^[a-f0-9]{64}$/',$decl)===1&&hash_equals($decl,self::hash($record));}
    private static function validIndex(array $record): bool {if(($record['contract']??'')!==self::INDEX_CONTRACT)return false;$decl=(string)($record['sha256']??'');return preg_match('/^[a-f0-9]{64}$/',$decl)===1&&hash_equals($decl,self::hash($record));}
    private static function hash(array $value): string {unset($value['sha256']);return hash('sha256',self::json($value));}
    private static function json($value): string {$j=wp_json_encode(self::canonical($value),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($j))throw new RuntimeException('PSTE_RESEARCH_ARCHIVE_JSON_FAILED');return $j;}
    private static function canonical($value){if(!is_array($value))return $value;if($value===[])return [];$list=array_keys($value)===range(0,count($value)-1);if($list)return array_map([self::class,'canonical'],$value);ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=self::canonical($v);return $value;}
    private static function code(string $v): string {$v=strtoupper(trim($v));$v=(string)preg_replace('/[^A-Z0-9_:\-]/','_',$v);return substr($v!==''?$v:'PSTE_RESEARCH_PARKED',0,180);}
    private static function safeContext(array $context): array {$out=[];foreach(['queue_uuid','item_index','family','category_id','driver_reason','cancel_reason'] as $k)if(array_key_exists($k,$context))$out[$k]=is_scalar($context[$k])?$context[$k]:'';return $out;}
    private static function publicRecord(array $r): array {return ['contract'=>self::CONTRACT,'job_uuid'=>(string)$r['job_uuid'],'park_reason'=>(string)$r['park_reason'],'parked_at_utc'=>(string)$r['parked_at_utc'],'owner_kind'=>(string)$r['owner_kind'],'owner_queue_uuid'=>(string)$r['owner_queue_uuid'],'owner_item_index'=>(int)$r['owner_item_index'],'source_status'=>(string)$r['source_status'],'source_phase'=>(string)$r['source_phase'],'sha256'=>(string)$r['sha256']];}
}
