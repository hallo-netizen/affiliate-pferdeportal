<?php
if (!defined('ABSPATH')) { return; }

/** Dynamic, read-only article-type registry built from the real portal baseline. */
final class PSTE_Article_Type_Registry {
    /**
     * Internal semantic family names for portal branches that intentionally share the same
     * visible leaf wording. WordPress category names/slugs remain untouched; only the PSTE
     * family identity used for routing is scoped. The mapping is slug-bound to the already
     * protected level-3 product page, so a visible label can stay stable without creating a
     * second ambiguous family in the semantic registry.
     *
     * One exact structural duplicate (the second Weidezaungeräte page) is deliberately given
     * a non-natural internal label. That makes it non-routable for normal user queries while
     * preserving the WordPress categories and plan references until a separate structural
     * cleanup is explicitly approved.
     */
    private const INTERNAL_FAMILY_NAMES_BY_PRODUCT_PAGE_SLUG=[
        'sicherheitshalfter'=>'Sicherheitshalfter im Training',
        'fohlenhalfter'=>'Halftertraining für Fohlen',
        'gesundheit-fellpflege-und-saison-schermaschinen'=>'Scheren bei Pferden',
        'weide-zauntechnik-weidezaungeraete'=>'Weidezaungeräte Strukturduplikat',
        'seniorenfutter'=>'Seniorenfütterung im Alter',
        'gesundheit-insekten-und-schutz-fliegensprays'=>'Hautschutz mit Fliegensprays',
        'gesundheit-insekten-und-schutz-fliegenmasken'=>'Gesichtsschutz mit Fliegenmasken',
        'gesundheit-insekten-und-schutz-bremsenfallen'=>'Bremsenstiche bei Pferden',
        'gesundheit-insekten-und-schutz-ekzemerdecken'=>'Hautschutz mit Ekzemerdecken',
        'kuehlgamaschen'=>'Kühlgamaschen für akute Kühlung',
        'training-bodenhindernisse-dualgassen'=>'Dualgassen mit Bodenhindernissen',
    ];

    /** @return array<string,mixed> */
    public static function build(array $baseline): array {
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_ARTICLE_TYPE_REGISTRY_BASELINE_INVALID');
        // Reuse only this request's identical snapshot. Never persist a registry across requests.
        // The full baseline fingerprint protects categories, article types and other portals even
        // when a producer has not refreshed its structure_sha256 yet.
        static $lastBaselineSha='';static $lastRegistry=[];
        $dynamicAliases=function_exists('has_filter')&&has_filter('pste_article_type_aliases')!==false;
        $baselineSha=$dynamicAliases?'':hash('sha256',serialize($baseline));
        if($baselineSha!==''&&$baselineSha===$lastBaselineSha&&$lastRegistry)return $lastRegistry;
        $types=[];$families=[];$byTerm=[];$bySlug=[];$nameIndex=[];$legacyIndex=[];
        foreach((array)($baseline['leaf_categories']??[]) as $leaf){
            if(!is_array($leaf))continue;
            $id=(int)($leaf['term_id']??0);$name=trim((string)($leaf['name']??''));$slug=trim((string)($leaf['slug']??''));
            $type=trim((string)($leaf['article_type']??$leaf['canonical_article_type']??PSTE_Normalizer::categoryArticleType($name)));
            $sourceFamily=trim((string)($leaf['topic_family_name']??PSTE_Normalizer::categoryFamilyName($name)));
            $family=self::internalFamilyName($leaf,$sourceFamily);
            $familyKey=trim((string)($leaf['topic_family_key']??PSTE_Normalizer::categoryFamilyKey($name)));
            if($id<=0||$name===''||$slug===''||$type===''||$family===''||$familyKey==='')continue;
            $canonical=self::canonicalType($type);
            $aliases=[$type,$canonical,self::ascii($type)];
            if(function_exists('apply_filters'))$aliases=(array)apply_filters('pste_article_type_aliases',$aliases,$type,$leaf);
            $aliases=array_values(array_unique(array_filter(array_map([self::class,'cleanAlias'],$aliases))));
            if(!isset($types[$canonical]))$types[$canonical]=[
                'canonical_type_id'=>$canonical,'visible_name'=>$type,'aliases'=>$aliases,
                'question_allowed'=>$canonical==='faq','handoff_code'=>$type,'leaf_count'=>0,
            ];
            else $types[$canonical]['aliases']=array_values(array_unique(array_merge($types[$canonical]['aliases'],$aliases)));
            $types[$canonical]['leaf_count']++;
            if(isset($families[$familyKey]['by_type'][$canonical])){
                $families[$familyKey]['by_type'][$canonical]['term_id']=0;
                $families[$familyKey]['by_type'][$canonical]['slug']='';
                $families[$familyKey]['by_type'][$canonical]['full_path']='';
                $byTerm[$id]=$familyKey;$bySlug[$slug]=$familyKey;
                continue;
            }
            $families[$familyKey]['topic_family_name']=$family;
            $families[$familyKey]['topic_family_key']=$familyKey;
            $families[$familyKey]['by_type'][$canonical]=[
                'term_id'=>$id,'parent'=>(int)($leaf['parent']??0),'name'=>$name,'slug'=>$slug,
                'article_type'=>$type,'canonical_type_id'=>$canonical,'topic_family_name'=>$family,'topic_family_key'=>$familyKey,
                'full_path'=>(string)($leaf['full_path']??''),
                'head_intent'=>(string)($leaf['head_intent']??''),
                'product_page_id'=>(int)($leaf['product_page_id']??0),
                'product_page_name'=>$family,
                'product_page_slug'=>(string)($leaf['product_page_slug']??''),
            ];
            $byTerm[$id]=$familyKey;$bySlug[$slug]=$familyKey;
            $nameKey=PSTE_Normalizer::exactTopicIdentityText($family);if($nameKey!=='')$nameIndex[$nameKey][$familyKey]=true;
            $legacy=PSTE_Normalizer::categoryFamilyKey($family);if($legacy!=='')$legacyIndex[$legacy][$familyKey]=true;
        }
        if(!$types||!$families)throw new RuntimeException('PSTE_ARTICLE_TYPE_REGISTRY_EMPTY');
        self::assertUniqueInternalFamilyNames($families);
        // Preserve the pre-extension registry identity for every existing family/type. Signed extensions are additive and tracked separately.
        $legacyTypes=$types;
        if(class_exists('PSTE_Article_Type_Extension_Registry')){
            $verified=PSTE_Article_Type_Extension_Registry::verifiedManifest();
            if(!empty($verified['ok']))foreach((array)($verified['manifest']['extensions']??[]) as $id=>$ext){
                if(!is_array($ext))continue;$visible=trim((string)($ext['display_name']??''));if($visible==='')continue;$canonical=self::canonicalType($visible);
                $aliases=array_values(array_unique(array_filter(array_map('strval',array_merge([$visible,(string)$id,(string)($ext['article_type_id']??'')],(array)($ext['aliases']??[]))))));
                if(!isset($types[$canonical]))$types[$canonical]=['canonical_type_id'=>$canonical,'visible_name'=>$visible,'aliases'=>$aliases,'question_allowed'=>(bool)($ext['title_policy']['question_or_statement_allowed']??false),'handoff_code'=>$visible,'leaf_count'=>0,'article_type_extension'=>true];
            }
        }
        foreach($families as $familyKey=>&$family){
            $values=[(string)($family['topic_family_name']??'')];$head=[];$products=[];
            foreach((array)($family['by_type']??[]) as $row){$values[]=(string)($row['head_intent']??'');$values[]=(string)($row['product_page_name']??'');if((string)($row['head_intent']??'')!=='')$head[]=(string)$row['head_intent'];if((string)($row['product_page_name']??'')!=='')$products[]=(string)$row['product_page_name'];}
            $tokens=[];foreach($values as $value)foreach(PSTE_Token_Equivalence::tokens($value) as $token)if(!preg_match('/^\d/',$token))$tokens[$token]=true;
            $all=array_keys($tokens);$anchors=[];if($all){$max=max(array_map('strlen',$all));$anchors=array_values(array_filter($all,static fn($t)=>strlen($t)===$max));}
            $modifier='';if(preg_match('/\b(\d+(?:[,.]\d+)?)\s*er\b/iu',(string)($family['topic_family_name']??''),$m))$modifier=str_replace(',','.',$m[1]);
            $qualifiers=array_values(array_diff($all,$anchors));$requiresQualifier=(bool)preg_match('/\\bfür\\b|\\bfuer\\b/iu',(string)($family['topic_family_name']??''));$family['identity']=['contract'=>'PSTE_FAMILY_IDENTITY_V1','anchor_tokens'=>$anchors,'qualifier_tokens'=>$qualifiers,'qualifier_required'=>$requiresQualifier,'all_tokens'=>$all,'numeric_modifier'=>$modifier,'head_intents'=>array_values(array_unique($head)),'product_page_names'=>array_values(array_unique($products))];
            $family['identity_v2']=PSTE_Family_Identity_V2::buildIdentity($family,$baseline);
        }unset($family);
        foreach($nameIndex as $k=>$set)$nameIndex[$k]=array_keys($set);
        foreach($legacyIndex as $k=>$set)$legacyIndex[$k]=array_keys($set);
        ksort($types,SORT_STRING);ksort($families,SORT_STRING);ksort($byTerm,SORT_NUMERIC);ksort($bySlug,SORT_STRING);ksort($nameIndex,SORT_STRING);ksort($legacyIndex,SORT_STRING);
        $legacyFamilies=$families;$v2Identities=[];
        foreach($legacyFamilies as $key=>&$legacyFamily){$v2Identities[$key]=(array)($legacyFamily['identity_v2']??[]);unset($legacyFamily['identity_v2']);}unset($legacyFamily);ksort($v2Identities,SORT_STRING);
        $legacyPayload=['contract'=>'PSTE_ARTICLE_TYPE_REGISTRY_V3','types'=>$legacyTypes,'families'=>$legacyFamilies,'by_term_id'=>$byTerm,'by_slug'=>$bySlug,'family_name_index'=>$nameIndex,'legacy_key_index'=>$legacyIndex,'structure_sha256'=>(string)($baseline['structure_sha256']??$baseline['structure_hash']??'')];
        $payload=['contract'=>'PSTE_ARTICLE_TYPE_REGISTRY_V3','types'=>$types,'families'=>$families,'by_term_id'=>$byTerm,'by_slug'=>$bySlug,'family_name_index'=>$nameIndex,'legacy_key_index'=>$legacyIndex,'structure_sha256'=>(string)($baseline['structure_sha256']??$baseline['structure_hash']??'')];
        $payload['registry_sha256']=hash('sha256',self::json($legacyPayload));
        $payload['family_identity_v2_registry_sha256']=hash('sha256',self::json($v2Identities));
        $extension=PSTE_Article_Type_Extension_Registry::verifiedManifest();
        $payload['article_type_extension_registry_sha256']=!empty($extension['ok'])?(string)$extension['manifest_sha256']:'';
        $payload['journal_registration_sha256']=isset($types['journal'])?hash('sha256',self::json((array)$types['journal'])):''; // compatibility only
        $payload['legacy_registry_hash_preserved']=true;
        if($baselineSha!==''){$lastBaselineSha=$baselineSha;$lastRegistry=$payload;}
        return $payload;
    }


    private static function internalFamilyName(array $leaf,string $sourceFamily): string {
        $slug=trim((string)($leaf['product_page_slug']??''));
        $mapped=trim((string)(self::INTERNAL_FAMILY_NAMES_BY_PRODUCT_PAGE_SLUG[$slug]??''));
        return $mapped!==''?$mapped:$sourceFamily;
    }

    /** @param array<string,array<string,mixed>> $families */
    private static function assertUniqueInternalFamilyNames(array $families): void {
        $seen=[];
        foreach($families as $familyKey=>$family){
            $name=trim((string)($family['topic_family_name']??''));
            $normalized=PSTE_Normalizer::exactTopicIdentityText($name);
            if($normalized==='')throw new RuntimeException('PSTE_ARTICLE_TYPE_REGISTRY_INTERNAL_FAMILY_NAME_EMPTY');
            if(isset($seen[$normalized])&&!hash_equals((string)$seen[$normalized],(string)$familyKey))throw new RuntimeException('PSTE_ARTICLE_TYPE_REGISTRY_DUPLICATE_INTERNAL_FAMILY_NAME');
            $seen[$normalized]=(string)$familyKey;
        }
    }

    public static function canonicalType(string $type): string {return str_replace(' ','_',PSTE_Normalizer::exactTopicIdentityText(trim($type)));}
    /** @return list<string> */
    public static function availableTypes(array $registry,string $familyKey): array {
        $out=[];foreach((array)($registry['families'][$familyKey]['by_type']??[]) as $row)$out[]=(string)$row['article_type'];
        sort($out,SORT_NATURAL|SORT_FLAG_CASE);return $out;
    }
    /** @return array<string,mixed> */
    public static function resolve(array $registry,string $familyKey,string $articleType): array {
        $canonical=self::canonicalType($articleType);$row=$registry['families'][$familyKey]['by_type'][$canonical]??null;
        if(!is_array($row)||(int)($row['term_id']??0)<=0||(string)($row['slug']??'')==='')return ['ok'=>false,'reason_code'=>'PSTE_TARGET_CATEGORY_EXACT_MATCH_MISSING','family_key'=>$familyKey,'article_type'=>$articleType];
        return array_merge(['ok'=>true],$row);
    }
    /** @return list<string> */
    public static function aliasesFor(array $registry,string $articleType): array {
        return array_values((array)($registry['types'][self::canonicalType($articleType)]['aliases']??[]));
    }
    public static function questionAllowed(array $registry,string $articleType): bool {
        return !empty($registry['types'][self::canonicalType($articleType)]['question_allowed']);
    }
    public static function visibleType(array $registry,string $canonical): string {
        return (string)($registry['types'][$canonical]['visible_name']??'');
    }
    private static function cleanAlias($value): string {return trim((string)$value);}
    private static function ascii(string $v): string {return strtr($v,['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);}
    private static function json(array $v): string {$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);return is_string($j)?$j:'';}
}
