<?php
if (!defined('ABSPATH')) { return; }

/** Persistent, fail-closed orchestrator for fixed or target-driven broad longtail research waves. */
final class PSTE_Breadth_Research_Queue {
    private static string $activeQueueFenceToken='';
    public const CONTRACT='PSTE_BREADTH_RESEARCH_QUEUE_V1';
    public const VERSION='1.8.0';
    private const COMPATIBLE_VERSIONS=['1.0.0','1.1.0','1.2.0','1.3.0','1.4.0','1.5.0','1.6.0','1.7.0','1.8.0'];
    private const QUEUE_LOCK_TTL=180;
    private const MAX_ITEMS=40;
    private const LEGACY_MAX_ITEMS=4;
    private const DEFAULT_TARGET_USABLE=40;
    private const DEFAULT_MAX_ITEMS=40;
    private const TRANSIENT_COORDINATION_CODES=['PSTE_RESEARCH_STEP_ALREADY_RUNNING','PSTE_SANDBOX_LOCKED','PSTE_BUDGET_RESERVATION_LOCKED'];
    private const REPLAY_SAFE_LOCAL_FINALIZE_CODES=['PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_RAW_MISMATCH','PSTE_SNAPSHOT_STALE_OR_CHANGED','PSTE_RESEARCH_FINALIZE_PREPARE_COUNT_MISMATCH'];
    private const BACKLOG_AUDIT_CONTRACT='PSTE_RETAINED_BACKLOG_AUDIT_RECEIPT_V1';
    private const BACKLOG_CHECKPOINT_CONTRACT='PSTE_RETAINED_BACKLOG_AUDIT_CHECKPOINT_V1';
    private const BACKLOG_AUDIT_LOGIC_VERSION='PSTE_RETAINED_BACKLOG_AUDIT_LOGIC_V4_SEMANTIC_DEPENDENCIES';
    private const LEGACY_05759_FULL_PLUGIN_AUDIT_LOGIC_SHA256='24d6674fd0ec09483d732d2f1ffb7dca8c657a41904d4180f91dd81aa8ab898c';
    private const LEGACY_05652_AUDIT_LOGIC_SHA256='cf760a1c584292af052704a2d575326a0ffb0675ea5435a0d398568f0d312ecc';

    public static function start(int $requestedCount,array $settings): array {
        // Legacy bounded breadth mode remains available for compatibility.
        return self::startQueue('FIXED_FAMILY_COUNT',0,max(1,min(self::LEGACY_MAX_ITEMS,$requestedCount)),max(1,min(self::LEGACY_MAX_ITEMS,$requestedCount)),$settings,true);
    }

    public static function startUntil(int $targetUsable,int $maxItems,array $settings): array {
        $targetUsable=max(1,min(200,$targetUsable>0?$targetUsable:self::DEFAULT_TARGET_USABLE));
        $maxItems=max(1,min(self::MAX_ITEMS,$maxItems>0?$maxItems:self::DEFAULT_MAX_ITEMS));
        return self::startQueue('TARGET_USABLE_CANDIDATES',$targetUsable,$maxItems,1,$settings,true);
    }

    /**
     * KISS lane: mine only already stored Sandbox/topic-pool potential.
     * Never opens a DataForSEO child job and never requires a cost confirmation.
     */
    public static function startExistingOnly(int $targetUsable,array $settings): array {
        $targetUsable=max(1,min(200,$targetUsable>0?$targetUsable:10));
        return self::startQueue('TARGET_USABLE_CANDIDATES',$targetUsable,1,0,$settings,false);
    }


    /** Read-only freshness check for the completed provider-free backlog audit. */
    public static function existingOnlyAuditCurrent(): bool {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return false;
        $context=PSTE_Context_Refresh::status();
        if((string)($context['status']??'')!=='COMPLETE')return false;
        try{$binding=PSTE_Context_Index_Store::runtimeBinding($context,$baseline);}catch(Throwable $e){return false;}
        if(($binding['contract']??'')!=='PSTE_CONTEXT_INDEX_RUNTIME_BINDING_V2')return false;
        // A receipt alone is not a complete audit. A previous partial targeted
        // update could resign it independently of the old completed checkpoint.
        $queue=self::raw();
        if(!is_array($queue))return false;
        self::assertQueue($queue);
        if((string)($queue['status']??'')!=='COMPLETE')return false;
        $receipt=get_option(PSTE_OPTION_RETAINED_BACKLOG_AUDIT,[]);
        if(self::completedAuditEvidenceIssue($queue,$receipt)!=='')return false;
        return self::canReuseBacklogAudit($binding);
    }

    /**
     * A new editorial plan does not turn an unchanged, completely audited topic pool
     * into 4,486 unexamined rows. Rebind only that one changed dependency.
     * Strictly refuse changed topic data, inventory, structure, baseline, logic,
     * incomplete queues or corrupted receipts. The signed completed queue is NEVER rewritten.
     */
    public static function reuseCompletedAuditForEditorialPlanOnly(): bool {
        $queue=self::raw();
        if(!is_array($queue))return false;
        self::assertQueue($queue);
        if((string)($queue['status']??'')!=='COMPLETE'||!array_key_exists('provider_fallback_allowed',$queue)||!empty($queue['provider_fallback_allowed']))return false;
        if(empty($queue['local_backlog_complete']))return false;
        $total=(int)($queue['local_backlog_total']??0);
        if($total<1||(int)($queue['local_backlog_processed']??-1)!==$total||(int)($queue['local_backlog_cursor']??0)<=0)return false;
        $checkpoint=(array)($queue['local_backlog_checkpoint']??[]);
        if(($checkpoint['contract']??'')!==self::BACKLOG_CHECKPOINT_CONTRACT||!self::validBacklogCheckpoint($checkpoint))return false;
        if((int)($checkpoint['processed_total']??-1)!==$total||(int)($checkpoint['cursor']??-1)!==(int)$queue['local_backlog_cursor'])return false;
        $old=get_option(PSTE_OPTION_RETAINED_BACKLOG_AUDIT,[]);
        if(!is_array($old)||($old['contract']??'')!==self::BACKLOG_AUDIT_CONTRACT||!self::validBacklogAuditReceipt($old))return false;
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return false;
        $context=PSTE_Context_Refresh::status();
        if((string)($context['status']??'')!=='COMPLETE')return false;
        try{
            $binding=PSTE_Context_Index_Store::runtimeBinding($context,$baseline);
            $current=self::backlogAuditInput($binding);
        }catch(Throwable $e){return false;}
        if((int)$current['backlog_row_count']!==$total)return false;
        // Reject all evidence drift except the plan fingerprint. This includes actual
        // payload changes, user edits, context, and executable decision logic.
        foreach(['audit_logic_sha256','baseline_sha256','inventory_sha256','structure_sha256','backlog_sha256','backlog_row_count'] as $field){
            if((string)($old[$field]??'')!==(string)($current[$field]??''))return false;
            if((string)($checkpoint[$field]??'')!==(string)($current[$field]??''))return false;
        }
        if((string)($old['editorial_plan_sha256']??'')===''
            ||(string)($current['editorial_plan_sha256']??'')===''
            ||hash_equals((string)$old['editorial_plan_sha256'],(string)$current['editorial_plan_sha256']))return false;
        // The existing compiler must still run its own up-to-date plan, duplicate,
        // category, title and article-release checks. This never grants a ready item.
        self::storeBacklogAuditReceipt($binding);
        return true;
    }

    /**
     * Historical helper kept for API compatibility. A partial cohort is NOT a new global
     * audit. Only identical completed data/logic can be acknowledged; never resign the
     * 4k+ completed receipt (or its signed checkpoint) based on 110 selected rows.
     */
    public static function refreshExistingOnlyAuditReceiptAfterTargetedReentry(): void {
        $queue=self::raw();
        if(!is_array($queue))throw new RuntimeException('PSTE_TARGETED_REENTRY_COMPLETE_QUEUE_REQUIRED');
        self::assertQueue($queue);
        if((string)($queue['status']??'')!=='COMPLETE'||empty($queue['local_backlog_complete'])
            ||!array_key_exists('provider_fallback_allowed',$queue)||!empty($queue['provider_fallback_allowed'])){
            throw new RuntimeException('PSTE_TARGETED_REENTRY_SIGNED_COMPLETED_AUDIT_REQUIRED');
        }
        $receipt=get_option(PSTE_OPTION_RETAINED_BACKLOG_AUDIT,[]);
        $checkpoint=(array)($queue['local_backlog_checkpoint']??[]);
        if(!is_array($receipt)||($receipt['contract']??'')!==self::BACKLOG_AUDIT_CONTRACT
            ||!self::validBacklogAuditReceipt($receipt)
            ||($checkpoint['contract']??'')!==self::BACKLOG_CHECKPOINT_CONTRACT
            ||!self::validBacklogCheckpoint($checkpoint)){
            throw new RuntimeException('PSTE_TARGETED_REENTRY_SIGNED_AUDIT_EVIDENCE_INVALID');
        }
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        $context=PSTE_Context_Refresh::status();
        if((string)($context['status']??'')!=='COMPLETE')throw new RuntimeException('PSTE_CONTEXT_COMPLETE_REQUIRED');
        $binding=PSTE_Context_Index_Store::runtimeBinding($context,$baseline);
        $current=self::backlogAuditInput($binding);
        // Both independently signed records must still describe the exact same full
        // revision and source. A genuinely modified source requires an independently
        // verified cohort transition, never this old one-step global receipt rewrite.
        foreach(['audit_logic_sha256','baseline_sha256','inventory_sha256','structure_sha256',
                 'editorial_plan_sha256','backlog_sha256','backlog_row_count'] as $key){
            if((string)($receipt[$key]??'')!==(string)($current[$key]??'')
                ||(string)($checkpoint[$key]??'')!==(string)($current[$key]??'')){
                throw new RuntimeException('PSTE_TARGETED_REENTRY_GLOBAL_AUDIT_DRIFT_PRESERVED');
            }
        }
        if((int)($queue['local_backlog_total']??0)!==(int)$current['backlog_row_count']
            ||(int)($queue['local_backlog_processed']??-1)!==(int)$current['backlog_row_count']
            ||(int)($checkpoint['processed_total']??-1)!==(int)$current['backlog_row_count']
            ||(int)($checkpoint['cursor']??-1)!==(int)($queue['local_backlog_cursor']??-2)){
            throw new RuntimeException('PSTE_TARGETED_REENTRY_COMPLETED_PREFIX_INVALID');
        }
        // No writes needed. This check intentionally has zero side effects.
    }

    private static function startQueue(string $mode,int $targetUsable,int $maxItems,int $initialItems,array $settings,bool $providerFallbackAllowed=true): array {
        PSTE_Plugin::assertReady();$launchToken=self::acquireLaunchLock();
        try{
        $existing=self::raw();
        // Never use an unsigned/damaged old queue as the source for a resumed job.
        if(is_array($existing))self::assertQueue($existing);
        if(is_array($existing)&&in_array((string)($existing['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_BREADTH_QUEUE_ALREADY_ACTIVE');
        if(PSTE_Research_Job::peek()!==null)throw new RuntimeException('PSTE_RESEARCH_JOB_ALREADY_ACTIVE');
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        $rebase=PSTE_Snapshot::rebaseResearchBaselineIfSafe($baseline);if(empty($rebase['ok']))throw new RuntimeException((string)($rebase['error_code']??'PSTE_SITE_BASELINE_STALE'));
        $baseline=(array)$rebase['baseline'];
        $candidates=$providerFallbackAllowed?self::openFamilies($baseline):[];
        if(!$candidates&&$mode!=='TARGET_USABLE_CANDIDATES')throw new RuntimeException('PSTE_BREADTH_NO_OPEN_FAMILIES');
        $selected=$providerFallbackAllowed&&$candidates?self::spread($candidates,max(1,min($maxItems,max(1,$initialItems)))):[];
        $baselineUsable=[];$contextBinding=[];$continuation=null;$previousCompletedQueue=null;
        if($mode==='TARGET_USABLE_CANDIDATES'){
            $baselineUsable=PSTE_Repository::usablePlanningTopicKeys();
            $context=PSTE_Context_Refresh::status();if((string)($context['status']??'')!=='COMPLETE')throw new RuntimeException('PSTE_PRODUCTION_WAVE_CONTEXT_COMPLETE_REQUIRED');
            $contextBinding=PSTE_Context_Index_Store::runtimeBinding($context,$baseline);
            // The old 0.57.83 could create a zero-cursor child after a completed audit.
            // When a repeated child was stopped, recover its verified completed predecessor
            // even if the child had already replayed 40, 200 or more of those old rows.
            if(!$providerFallbackAllowed&&is_array($existing)&&
               !in_array((string)($existing['logic_recheck_source']??''),['SEMANTIC_LOGIC_CHANGED','AUDIT_EVIDENCE_RECHECK'],true)&&
               (string)($existing['status']??'')==='CANCELLED'&&
               (string)($existing['completion_reason']??'')==='CANCELLED_BY_USER'&&
               empty($existing['local_backlog_complete'])&&
               (int)($existing['local_backlog_processed']??-1)>=0&&
               (int)($existing['local_backlog_cursor']??-1)>=0&&
               isset($existing['previous_completed_queue'])&&
               is_array($existing['previous_completed_queue'])&&
               (int)($existing['local_backlog_processed']??-1)<=(int)($existing['previous_completed_queue']['local_backlog_processed']??-2)&&
               (int)($existing['local_backlog_cursor']??-1)<=(int)($existing['previous_completed_queue']['local_backlog_cursor']??-2)){
                return self::recoverVerifiedPriorAfterZeroCancel($existing,$contextBinding);
            }
            // If the receipt proves a full audit but its complete queue was not embedded
            // in a stopped duplicate, never overwrite history with another zero/partial
            // replay. There is no independently verifiable cursor to restore from.
            if(!$providerFallbackAllowed&&is_array($existing)&&
               array_key_exists('provider_fallback_allowed',$existing)&&empty($existing['provider_fallback_allowed'])&&
               (string)($existing['status']??'')==='CANCELLED'&&
               empty($existing['local_backlog_complete'])&&
               !is_array($existing['previous_completed_queue']??null)){
                $receipt=get_option(PSTE_OPTION_RETAINED_BACKLOG_AUDIT,[]);
                if(is_array($receipt)&&($receipt['contract']??'')===self::BACKLOG_AUDIT_CONTRACT&&
                   self::validBacklogAuditReceipt($receipt)&&
                   (int)($receipt['backlog_row_count']??0)>(int)($existing['local_backlog_processed']??0)){
                    throw new RuntimeException('PSTE_EXISTING_ONLY_COMPLETED_RECEIPT_WITHOUT_PRIOR_QUEUE_PROGRESS_PRESERVED');
                }
            }
            // The production button must resume a validated stopped Existing-Only job.
            // Never replace a durable partial checkpoint with an unrequested zero-cursor run.
            $continuation=self::cancelledWaveContinuation($existing,$targetUsable,$maxItems,$contextBinding,$providerFallbackAllowed);
            if(!$providerFallbackAllowed&&is_array($existing)&&
               array_key_exists('provider_fallback_allowed',$existing)&&empty($existing['provider_fallback_allowed'])){
                $priorStatus=(string)($existing['status']??'');
                if($priorStatus==='CANCELLED'&&!is_array($continuation))throw new RuntimeException('PSTE_EXISTING_ONLY_SAVED_PROGRESS_CHANGED_OR_INVALID');
                if($priorStatus==='COMPLETE'){
                    // Completed existing-only work is a durable checkpoint, never an invitation
                    // to restart the entire audit. Only a provably appended tail may be examined;
                    // modified prior rows fail closed with the original signed state untouched.
                    $cp=(array)($existing['local_backlog_checkpoint']??[]);
                    $oldReceipt=get_option(PSTE_OPTION_RETAINED_BACKLOG_AUDIT,[]);
                    $invalid=self::completedAuditEvidenceIssue($existing,$oldReceipt);
                    if($invalid!==''){
                        // Do not trust or resign inconsistent historic receipts. A signed queue
                        // proves history, NOT that its old 4k decisions are still correct.
                        // Explicit production start uses the existing 40-row LOCAL worker to
                        // rebuild the complete decision proof; no provider, table or new route.
                        $repair=self::beginEvidenceRevalidation($existing,$contextBinding,$baselineUsable,$invalid);
                        return self::summary($repair,null);
                    }
                    // An unchanged completed audit is idempotent, even on repeated button clicks.
                    if(self::canReuseBacklogAudit($contextBinding))return self::summary($existing);
                    // The signed completed queue and receipt were verified above. If
                    // the source has changed at an unchanged row count (stored titles,
                    // portal baseline, inventory or structure), the EXISTING bounded
                    // local recheck must own the transition. Do not require the old
                    // source hash for a fresh audit; preserve that signed predecessor.
                    // A changed count still takes the stricter append/prefix route.
                    $currentAudit=self::backlogAuditInput($contextBinding);
                    if((int)($oldReceipt['backlog_row_count']??0)>0
                        && (int)$oldReceipt['backlog_row_count']===(int)$currentAudit['backlog_row_count']){
                        $sourceChanged=false;
                        foreach(['baseline_sha256','inventory_sha256','structure_sha256','backlog_sha256'] as $field){
                            $previous=(string)($oldReceipt[$field]??'');$latest=(string)($currentAudit[$field]??'');
                            if($previous!==''&&$latest!==''&&!hash_equals($previous,$latest)){$sourceChanged=true;break;}
                        }
                        if($sourceChanged){
                            $recheck=self::beginEvidenceRevalidation($existing,$contextBinding,$baselineUsable,'PSTE_AUDIT_SOURCE_CHANGED_LOCAL_RECHECK');
                            return self::summary($recheck,null);
                        }
                    }
                    // Unchanged source and changed semantic rules: existing dedicated
                    // logic recheck. Appended/deleted rows retain their own strict checks.
                    $newLogic=self::beginLogicChangedLocalRevalidation($existing,$oldReceipt,$contextBinding,$baselineUsable);
                    if(is_array($newLogic))return self::summary($newLogic,null);
                    return self::continueVerifiedAppendedBacklog($existing,$oldReceipt,$contextBinding);
                }
            }
            if(is_array($continuation))$baselineUsable=(array)$continuation['baseline_usable_topic_keys'];
        }
        $continuedBacklogComplete=is_array($continuation)&&!empty($continuation['local_backlog_complete']);
        $backlogReuse=$continuedBacklogComplete||($providerFallbackAllowed&&$mode==='TARGET_USABLE_CANDIDATES'&&self::canReuseBacklogAudit($contextBinding));
        // Never silently replay a stopped existing-only audit; its validated continuation above
        // owns the durable cursor. Provider-backed standalone checkpoints remain unchanged.
        $backlogCheckpoint=($providerFallbackAllowed&&!$backlogReuse&&$mode==='TARGET_USABLE_CANDIDATES')?self::reusableBacklogCheckpoint($existing,$contextBinding):null;
        $localBacklogTotal=$mode==='TARGET_USABLE_CANDIDATES'?PSTE_Repository::retainedBacklogRowCount():0;
        self::clearCancelRequest();$uuid=(!$providerFallbackAllowed&&is_array($continuation))?(string)$continuation['queue_uuid']:wp_generate_uuid4();$now=gmdate('c');
        $items=[];
        foreach($selected as $row)$items[]=self::queueItem($row);
        $queue=[
            'contract'=>self::CONTRACT,'version'=>self::VERSION,'queue_uuid'=>$uuid,'status'=>'RUNNING',
            'mode'=>$mode,'requested_count'=>$mode==='FIXED_FAMILY_COUNT'?count($items):$targetUsable,
            'target_usable'=>$targetUsable,'max_items'=>$maxItems,'provider_fallback_allowed'=>$providerFallbackAllowed,'usable_candidate_count'=>0,'raw_usable_candidate_count'=>0,'usable_topic_keys'=>[],'baseline_usable_topic_keys'=>$baselineUsable,'completion_reason'=>'',
            'continued_from_queue_uuid'=>is_array($continuation)&&!$providerFallbackAllowed?(string)($existing['continued_from_queue_uuid']??''):(is_array($continuation)?(string)$continuation['queue_uuid']:''),'continued_usable_candidate_count'=>0,
            'sandbox_reentry_complete'=>$mode!=='TARGET_USABLE_CANDIDATES'||(is_array($continuation)&&!empty($continuation['sandbox_reentry_complete'])),'sandbox_reentry_checked'=>is_array($continuation)?(int)($continuation['sandbox_reentry_checked']??0):0,'sandbox_reentry_applied'=>is_array($continuation)?(int)($continuation['sandbox_reentry_applied']??0):0,'sandbox_reentry_failed'=>is_array($continuation)?(int)($continuation['sandbox_reentry_failed']??0):0,'local_backlog_complete'=>$mode!=='TARGET_USABLE_CANDIDATES'||$backlogReuse,'local_backlog_reused'=>$backlogReuse,'local_backlog_resumed'=>is_array($backlogCheckpoint)||(is_array($continuation)&&!$continuedBacklogComplete),'local_backlog_total'=>$localBacklogTotal,'local_backlog_cursor'=>$continuedBacklogComplete?(int)($continuation['local_backlog_cursor']??0):(is_array($continuation)?(int)($continuation['local_backlog_cursor']??0):(is_array($backlogCheckpoint)?(int)($backlogCheckpoint['cursor']??0):0)),'local_backlog_processed'=>$continuedBacklogComplete?(int)($continuation['local_backlog_processed']??0):(is_array($continuation)?(int)($continuation['local_backlog_processed']??0):(is_array($backlogCheckpoint)?(int)($backlogCheckpoint['processed_total']??0):0)),'local_backlog_promoted'=>is_array($continuation)?(int)($continuation['local_backlog_promoted']??0):0,'local_backlog_title_candidates'=>is_array($continuation)?(int)($continuation['local_backlog_title_candidates']??0):0,'local_backlog_title_candidates_revalidated'=>is_array($continuation)?(int)($continuation['local_backlog_title_candidates_revalidated']??0):0,'local_backlog_structure_gaps'=>is_array($continuation)?(int)($continuation['local_backlog_structure_gaps']??0):0,'local_backlog_reviews'=>is_array($continuation)?(int)($continuation['local_backlog_reviews']??0):0,'local_backlog_retained_non_producing'=>is_array($continuation)?(int)($continuation['local_backlog_retained_non_producing']??0):0,'local_backlog_title_preview'=>is_array($continuation)?(array)($existing['local_backlog_title_preview']??[]):[],'local_backlog_provider_calls'=>0,'local_backlog_checkpoint'=>is_array($continuation)?(array)($continuation['local_backlog_checkpoint']??[]):(is_array($backlogCheckpoint)?$backlogCheckpoint:[]),'resume_recheck_until'=>is_array($continuation)?(int)($continuation['resume_recheck_until']??0):0,'resume_recheck_cursor'=>is_array($continuation)?(int)($continuation['resume_recheck_cursor']??0):0,'resume_recheck_fingerprint'=>is_array($continuation)?(string)($continuation['resume_recheck_fingerprint']??''):'','resume_recheck_checked'=>is_array($continuation)?(int)($continuation['resume_recheck_checked']??0):0,'context_binding'=>$contextBinding,
            'item_count'=>count($items),'current_index'=>0,'completed_count'=>0,'blocked_count'=>0,'items'=>$items,
            'last_error'=>'','coordination_wait_code'=>'','created_at_utc'=>is_array($continuation)&&!$providerFallbackAllowed?(string)($existing['created_at_utc']??$now):$now,'updated_at_utc'=>$now,
        ];
        if(is_array($continuation)&&!$providerFallbackAllowed&&
           (string)($existing['logic_recheck_source']??'')==='SEMANTIC_LOGIC_CHANGED'){
            $predecessor=$existing['previous_completed_queue']??null;
            if(!is_array($predecessor))throw new RuntimeException('PSTE_LOGIC_RECHECK_SIGNED_PREDECESSOR_MISSING');
            self::assertQueue($predecessor);
            $queue['logic_recheck_source']='SEMANTIC_LOGIC_CHANGED';
            $queue['previous_completed_queue']=$predecessor;
        }
        if(is_array($continuation)&&!$providerFallbackAllowed&&
           (string)($existing['logic_recheck_source']??'')==='AUDIT_EVIDENCE_RECHECK'){
            $predecessor=$existing['previous_completed_queue']??null;
            if(!is_array($predecessor))throw new RuntimeException('PSTE_AUDIT_EVIDENCE_PREDECESSOR_MISSING');
            self::assertQueue($predecessor);
            $queue['logic_recheck_source']='AUDIT_EVIDENCE_RECHECK';
            $queue['previous_completed_queue']=$predecessor;
            $queue['audit_recheck_reason']=(string)($existing['audit_recheck_reason']??'PSTE_AUDIT_EVIDENCE_RECHECK');
        }
        if(is_array($continuation)){
            $counted=self::countNewUniqueUsableTopics($queue);
            $queue['usable_topic_keys']=$counted['keys'];$queue['usable_candidate_count']=count($counted['keys']);
            $queue['continued_usable_candidate_count']=$queue['usable_candidate_count'];
        }
        self::save($queue);
        return self::summary($queue);
        }finally{self::releaseLaunchLock($launchToken);}
    }

    private static function queueItem(array $row): array {
        return [
            'category_id'=>(int)$row['category_id'],'seed'=>(string)$row['seed'],'family'=>(string)$row['family'],'root'=>(string)$row['root'],
            'status'=>'PENDING','child_job_uuid'=>'','parked_job_uuid'=>'','blocked_at_utc'=>'','actual_cost'=>0.0,'usable_candidate_count'=>0,'candidate_count'=>0,'last_error'=>'','coordination_wait_code'=>'',
        ];
    }

    /**
     * Rebind an active Existing-Only queue after the production preflight accepted a new current
     * baseline. The provider-free local pass restarts at cursor zero against the new compact binding.
     * No provider child, full context job, article/taxonomy write or production handoff is allowed.
     */
    public static function rebindExistingOnlyForProduction(string $queueUuid): array {
        $token=self::acquireQueueLock();
        try{
            $queue=self::load();
            if(!hash_equals((string)($queue['queue_uuid']??''),trim($queueUuid)))throw new RuntimeException('PSTE_BREADTH_QUEUE_ID_MISMATCH');
            if(!array_key_exists('provider_fallback_allowed',$queue)||!empty($queue['provider_fallback_allowed']))throw new RuntimeException('PSTE_EXISTING_ONLY_REBIND_REQUIRED');
            if(!in_array((string)($queue['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_EXISTING_ONLY_REBIND_STATE_INVALID');
            if(PSTE_Research_Job::peek()!==null)throw new RuntimeException('PSTE_EXISTING_ONLY_REBIND_CHILD_JOB_UNEXPECTED');
            $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
            $context=PSTE_Context_Refresh::status();if((string)($context['status']??'')!=='COMPLETE')throw new RuntimeException('PSTE_EXISTING_ONLY_REBIND_CONTEXT_COMPLETE_REQUIRED');
            $binding=PSTE_Context_Index_Store::runtimeBinding($context,$baseline);
            $old=(array)($queue['context_binding']??[]);
            foreach(['baseline_sha256','inventory_sha256','structure_sha256','editorial_plan_sha256'] as $field){
                if((string)($old[$field]??'')===''||(string)($binding[$field]??'')===''||!hash_equals((string)$old[$field],(string)$binding[$field])){
                    // A changed source requires a separately verified reentry; keep the original
                    // queue, counters and signed checkpoint intact rather than silently restarting.
                    throw new RuntimeException('PSTE_EXISTING_ONLY_INPUT_CHANGED_PROGRESS_PRESERVED');
                }
            }
            if((string)($queue['status']??'')!=='RUNNING'){
                $queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']='';$queue['updated_at_utc']=gmdate('c');
                self::save($queue);
            }
            return self::summary($queue,null);
        }finally{self::releaseQueueLock($token);}
    }

    /**
     * Resume only an Existing-Only queue without executing domain work in the admin request.
     * If WordPress inventory/editorial-plan context changed while the queue was paused, rebind the
     * compact completed context index and restart only the local retained-backlog audit. This never
     * starts a full portal-context refresh and never calls an external provider.
     */
    public static function requestExistingOnlyResume(string $queueUuid,array $settings): array {
        $token=self::acquireQueueLock();
        try{
            $queue=self::load();
            if(!hash_equals((string)($queue['queue_uuid']??''),trim($queueUuid)))throw new RuntimeException('PSTE_BREADTH_QUEUE_ID_MISMATCH');
            if(!array_key_exists('provider_fallback_allowed',$queue)||!empty($queue['provider_fallback_allowed']))throw new RuntimeException('PSTE_EXISTING_ONLY_RESUME_REQUIRED');
            if(!in_array((string)($queue['status']??''),['PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_EXISTING_ONLY_RESUME_STATE_INVALID');
            if(PSTE_Research_Job::peek()!==null)throw new RuntimeException('PSTE_EXISTING_ONLY_RESUME_CHILD_JOB_UNEXPECTED');

            $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
            if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
            $rebase=PSTE_Snapshot::rebaseResearchBaselineIfSafe($baseline);
            if(empty($rebase['ok']))throw new RuntimeException((string)($rebase['error_code']??'PSTE_SITE_BASELINE_STALE'));
            $baseline=(array)$rebase['baseline'];
            $context=PSTE_Context_Refresh::status();
            if((string)($context['status']??'')!=='COMPLETE')throw new RuntimeException('PSTE_EXISTING_ONLY_RESUME_CONTEXT_COMPLETE_REQUIRED');
            $binding=PSTE_Context_Index_Store::runtimeBinding($context,$baseline);
            $currentBacklogTotal=PSTE_Repository::retainedBacklogRowCount();
            if($currentBacklogTotal!==(int)($queue['local_backlog_total']??-1))throw new RuntimeException('PSTE_EXISTING_ONLY_ROW_COUNT_CHANGED_PROGRESS_PRESERVED');
            $old=(array)($queue['context_binding']??[]);$same=true;
            foreach(['baseline_sha256','inventory_sha256','structure_sha256','editorial_plan_sha256'] as $field){
                if((string)($old[$field]??'')===''||!hash_equals((string)($old[$field]??''),(string)($binding[$field]??''))){$same=false;break;}
            }
            // A previous version may already have created a zero-cursor *duplicate*
            // of a signed COMPLETE queue. Recover only while this duplicate is
            // PAUSED and ONLY for an explicit resume, under the existing queue lock.
            // A RUNNING queue is never modified here.
            $zeroRestartRepaired=false;
            $prior=$queue['previous_completed_queue']??null;
            if($same&&is_array($prior)&&
               in_array((string)($queue['logic_recheck_source']??''),['AUDIT_EVIDENCE_RECHECK','SEMANTIC_LOGIC_CHANGED'],true)&&
               (string)($prior['status']??'')==='COMPLETE'&&
               (int)($queue['local_backlog_processed']??0)<(int)($prior['local_backlog_processed']??0)){
                self::assertQueue($prior);
                $p=(array)($prior['local_backlog_checkpoint']??[]);
                $previousCount=(int)($prior['local_backlog_processed']??0);
                $previousCursor=(int)($prior['local_backlog_cursor']??0);
                if(!empty($prior['provider_fallback_allowed'])||empty($prior['local_backlog_complete'])||
                   $previousCount<1||$previousCursor<1||
                   $currentBacklogTotal!==$previousCount||
                   $previousCount!==(int)($prior['local_backlog_total']??-1)||
                   !self::validBacklogCheckpoint($p)||
                   (int)($p['processed_total']??-1)!==$previousCount||
                   (int)($p['cursor']??-1)!==$previousCursor||
                   (int)($p['backlog_row_count']??-1)!==$previousCount){
                    throw new RuntimeException('PSTE_ZERO_DUPLICATE_SIGNED_PREDECESSOR_INVALID_PROGRESS_PRESERVED');
                }
                // Restore COUNTERS of the signed predecessor, not its current
                // authority. Every earlier row must still pass the bounded recheck.
                $queue['local_backlog_cursor']=$previousCursor;
                $queue['local_backlog_processed']=$previousCount;
                $queue['local_backlog_checkpoint']=$p;
                $queue['local_backlog_complete']=false;
                $queue['local_backlog_resumed']=true;
                $queue['local_backlog_reused']=false;
                foreach(['local_backlog_promoted','local_backlog_title_candidates',
                         'local_backlog_title_candidates_revalidated','local_backlog_structure_gaps',
                         'local_backlog_reviews','local_backlog_retained_non_producing',
                         'local_backlog_title_preview','usable_topic_keys','usable_candidate_count'] as $field){
                    $queue[$field]=$prior[$field]??(is_array($queue[$field]??null)?[]:0);
                }
                $queue['resume_recheck_until']=$previousCursor;
                $queue['resume_recheck_cursor']=0;
                $queue['resume_recheck_checked']=0;
                $queue['resume_recheck_fingerprint']='';
                $zeroRestartRepaired=true;
            }
            $cp=(array)($queue['local_backlog_checkpoint']??[]);
            if(empty($queue['local_backlog_complete'])&&(int)($queue['local_backlog_processed']??0)>0){
                if(!self::validBacklogCheckpoint($cp))throw new RuntimeException('PSTE_EXISTING_ONLY_CHECKPOINT_INVALID');
                if((int)($cp['cursor']??-1)!==(int)($queue['local_backlog_cursor']??-2)||
                   (int)($cp['processed_total']??-1)!==(int)($queue['local_backlog_processed']??-2))throw new RuntimeException('PSTE_EXISTING_ONLY_CHECKPOINT_COUNTER_MISMATCH');
                $current=self::backlogAuditInput($binding);
                if((int)($cp['backlog_row_count']??-1)!==(int)($current['backlog_row_count']??-2))throw new RuntimeException('PSTE_EXISTING_ONLY_ROW_COUNT_CHANGED_PROGRESS_PRESERVED');
                // All existing-only resume entrances obey the same no-replay rule:
                // retain the signed checkpoint instead of reprocessing its entire prefix.
                if(!$same)throw new RuntimeException('PSTE_EXISTING_ONLY_INPUT_CHANGED_PROGRESS_PRESERVED');
                if($zeroRestartRepaired||!is_array(self::reusableBacklogCheckpoint(array_merge($queue,['status'=>'CANCELLED']),$binding))){
                    // The pool is mutable by this same worker (title evidence, normal metadata).
                    // The full-pool SHA can therefore change without added/deleted rows. Never
                    // treat an old signed checkpoint as CURRENT or skip its already checked prefix.
                    // Reverify every old row with the EXISTING bounded worker before advancing.
                    foreach(['baseline_sha256','inventory_sha256','structure_sha256','editorial_plan_sha256','backlog_row_count'] as $field){
                        if((string)($cp[$field]??'')===''||
                           (string)($cp[$field]??'')!==(string)($current[$field]??''))
                            throw new RuntimeException('PSTE_EXISTING_ONLY_INPUT_CHANGED_PROGRESS_PRESERVED');
                    }
                    $poolChanged=!hash_equals((string)($cp['backlog_sha256']??''),(string)($current['backlog_sha256']??''));
                    $logicChanged=!hash_equals((string)($cp['audit_logic_sha256']??''),(string)($current['audit_logic_sha256']??''));
                    if((string)($cp['backlog_sha256']??'')===''||
                       (string)($cp['audit_logic_sha256']??'')===''||
                       (!$poolChanged&&!$logicChanged&&!$zeroRestartRepaired))
                        throw new RuntimeException('PSTE_EXISTING_ONLY_INPUT_CHANGED_PROGRESS_PRESERVED');
                    // A resumed recheck must be bound to the exact most recent pool state.
                    // An unexpected mutation between its batches must not silently reuse
                    // a partly checked prefix, even when the total row count is the same.
                    $oldUntil=(int)($queue['resume_recheck_until']??0);
                    $oldCursor=(int)($queue['resume_recheck_cursor']??0);
                    $oldChecked=(int)($queue['resume_recheck_checked']??0);
                    $oldFingerprint=(string)($queue['resume_recheck_fingerprint']??'');
                    $canContinue=$oldUntil===(int)$cp['cursor']&&$oldCursor>0&&
                        $oldCursor<$oldUntil&&$oldChecked>0&&
                        $oldChecked<=(int)$cp['processed_total']&&
                        preg_match('/^[a-f0-9]{64}$/',$oldFingerprint)===1&&
                        hash_equals($oldFingerprint,(string)$current['backlog_sha256']);
                    $queue['resume_recheck_until']=(int)$cp['cursor'];
                    $queue['resume_recheck_cursor']=$canContinue?$oldCursor:0;
                    $queue['resume_recheck_checked']=$canContinue?$oldChecked:0;
                    $queue['resume_recheck_fingerprint']=$canContinue?$oldFingerprint:'';
                }
            }elseif(!$same||(!empty($queue['local_backlog_complete'])&&!self::canReuseBacklogAudit($binding)))
                throw new RuntimeException('PSTE_EXISTING_ONLY_INPUT_CHANGED_PROGRESS_PRESERVED');
            $queue['local_backlog_total']=$currentBacklogTotal;
            $queue['context_binding']=$binding;
            $queue['resume_context_rebound']=false;
            $queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']='';$queue['completion_reason']='';$queue['updated_at_utc']=gmdate('c');
            self::save($queue);return self::summary($queue,null);
        }finally{self::releaseQueueLock($token);}
    }

    public static function advance(string $queueUuid,array $settings,bool $explicitResume=false): array {
        $token=self::acquireQueueLock();
        try{return self::advanceLocked($queueUuid,$settings,$explicitResume);}finally{self::releaseQueueLock($token);}
    }

    private static function advanceLocked(string $queueUuid,array $settings,bool $explicitResume=false): array {
        $queue=self::load();
        if(!hash_equals((string)$queue['queue_uuid'],trim($queueUuid)))throw new RuntimeException('PSTE_BREADTH_QUEUE_ID_MISMATCH');
        if(self::cancelRequested($queue))return self::settleCancellation($queue);
        if(in_array((string)$queue['status'],['COMPLETE','CANCELLED'],true))return self::summary($queue);
        if((string)$queue['status']==='OUTCOME_UNKNOWN')return self::summary($queue);
        try{$child=PSTE_Research_Job::current();}catch(Throwable $e){return self::pause($queue,self::errorCode($e));}
        $ownership='NONE';if(is_array($child)){$ownership=self::childOwnershipState($child,$queue,(int)($queue['current_index']??0));if($ownership==='FOREIGN')return self::pause($queue,'PSTE_BREADTH_FOREIGN_ACTIVE_RESEARCH_JOB');}
        $queue=self::recoverTransientCoordinationPause($queue,$child);$queue=self::recoverSafeSiteContextPause($queue,$child);
        if((string)$queue['status']==='PAUSED_ERROR'){
            if(!$explicitResume)return self::summary($queue,$child);
            $queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']='';$queue['updated_at_utc']=gmdate('c');self::save($queue);
        }
        if((string)$queue['status']!=='RUNNING')throw new RuntimeException('PSTE_BREADTH_QUEUE_STATUS_INVALID');
        if((string)($queue['mode']??'')==='TARGET_USABLE_CANDIDATES'&&empty($queue['sandbox_reentry_complete']))return self::advanceSandboxExistingPotential($queue);
        if((string)($queue['mode']??'')==='TARGET_USABLE_CANDIDATES'&&empty($queue['local_backlog_complete']))return self::advanceLocalBacklog($queue);
        $idx=(int)$queue['current_index'];
        if($idx>=(int)$queue['item_count'])return self::completeOrExtend($queue);
        $item=(array)$queue['items'][$idx];
        if($child===null){
            try{
                $child=PSTE_Research_Job::start((int)$item['category_id'],(string)$item['seed'],$settings,['kind'=>'BREADTH','queue_uuid'=>(string)$queue['queue_uuid'],'item_index'=>$idx]);
                $queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['child_job_uuid']=(string)$child['job_uuid'];$queue['updated_at_utc']=gmdate('c');self::save($queue);
                if(self::cancelRequested($queue))return self::settleCancellation($queue,$child);
                return self::summary($queue,$child);
            }catch(Throwable $e){$code=self::errorCode($e);if($code==='PSTE_RESEARCH_JOB_ALREADY_ACTIVE'){try{$raced=PSTE_Research_Job::current();}catch(Throwable $ignored){$raced=null;}if(is_array($raced)&&self::childOwnershipState($raced,$queue,$idx)==='OWNED'){$queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['child_job_uuid']=(string)$raced['job_uuid'];$queue['coordination_wait_code']='PSTE_RESEARCH_JOB_ALREADY_ACTIVE';$queue['items'][$idx]['coordination_wait_code']='PSTE_RESEARCH_JOB_ALREADY_ACTIVE';$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue,$raced);}return self::pause($queue,'PSTE_BREADTH_CHILD_JOB_MISMATCH');}if(self::isTransientCoordinationCode($code))return self::coordinationWait($queue,$code,null);return self::pause($queue,$code);}
        }
        $expected=(string)($queue['items'][$idx]['child_job_uuid']??'');
        if($expected!==''&&!hash_equals($expected,(string)$child['job_uuid']))return self::pause($queue,'PSTE_BREADTH_CHILD_JOB_MISMATCH');
        if($expected===''){$queue['items'][$idx]['child_job_uuid']=(string)$child['job_uuid'];$queue['items'][$idx]['status']='RUNNING';self::save($queue);}
        try{$child=PSTE_Research_Job::advance((string)$child['job_uuid'],$settings,$explicitResume);}catch(Throwable $e){
            $code=self::errorCode($e);
            if(self::isTransientCoordinationCode($code))return self::coordinationWait($queue,$code,$child);
            return self::pause($queue,$code);
        }
        if(self::cancelRequested($queue))return self::settleCancellation($queue,$child);
        $childStatus=(string)($child['status']??'');
        if($childStatus==='COMPLETE'){
            $rawUsable=max(0,(int)($child['usable_candidate_count']??0));$candidateCount=max(0,(int)($child['candidate_count']??0));
            $queue['items'][$idx]['status']='COMPLETE';$queue['items'][$idx]['actual_cost']=(float)($child['actual_cost']??0.0);$queue['items'][$idx]['raw_usable_candidate_count']=$rawUsable;$queue['items'][$idx]['candidate_count']=$candidateCount;$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']='';$queue['coordination_wait_code']='';
            $queue['raw_usable_candidate_count']=max(0,(int)($queue['raw_usable_candidate_count']??0))+$rawUsable;
            if((string)($queue['mode']??'FIXED_FAMILY_COUNT')==='TARGET_USABLE_CANDIDATES'){
                $counted=self::countNewUniqueUsableTopics($queue,(string)($child['job_uuid']??$queue['items'][$idx]['child_job_uuid']??''));
                $queue['usable_topic_keys']=$counted['keys'];$queue['usable_candidate_count']=count($counted['keys']);
                $queue['items'][$idx]['usable_candidate_count']=(int)$counted['added'];$queue['items'][$idx]['count_status']=(string)$counted['status'];
            }else{
                $queue['items'][$idx]['usable_candidate_count']=$rawUsable;$queue['usable_candidate_count']=max(0,(int)($queue['usable_candidate_count']??0))+$rawUsable;
            }
            $queue['current_index']=$idx+1;$queue['completed_count']=(int)$queue['completed_count']+1;$queue['updated_at_utc']=gmdate('c');
            if(self::targetReached($queue))return self::complete($queue,'TARGET_REACHED');
            if((int)$queue['current_index']>=(int)$queue['item_count'])return self::completeOrExtend($queue);
            self::save($queue);return self::summary($queue,null);
        }
        if(in_array($childStatus,['PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){
            // A blocked child is a durable work-item state, not a production-wave abort.
            // Keep the child active for one more driver tick so it can be losslessly archived.
            $code=(string)($child['last_error']??($childStatus==='OUTCOME_UNKNOWN'?'PSTE_PROVIDER_TRANSPORT_OUTCOME_UNKNOWN':'PSTE_RESEARCH_PAUSED'));
            $queue['items'][$idx]['status']='BLOCKED_PENDING_PARK';$queue['items'][$idx]['last_error']=$code;$queue['items'][$idx]['blocked_at_utc']=gmdate('c');$queue['items'][$idx]['coordination_wait_code']='';
            $queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']='PSTE_BLOCKED_CHILD_PENDING_PARK';$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue,$child);
        }
        $wait=(string)($child['coordination_wait_code']??'');$queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['coordination_wait_code']=$wait;$queue['coordination_wait_code']=$wait;$queue['last_error']='';$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue,$child);
    }


    /** Resume only a signed stopped job. If inputs drifted, recheck just its completed prefix before advancing. */
    private static function cancelledWaveContinuation($existing,int $targetUsable,int $maxItems,array $binding,bool $providerFallbackAllowed): ?array {
        if(!is_array($existing))return null;
        self::assertQueue($existing);
        if((string)($existing['status']??'')!=='CANCELLED'||(string)($existing['completion_reason']??'')!=='CANCELLED_BY_USER')return null;
        if((string)($existing['mode']??'')!=='TARGET_USABLE_CANDIDATES')return null;
        if((int)($existing['target_usable']??0)!==$targetUsable||(int)($existing['max_items']??0)!==$maxItems)return null;
        $oldProviderFallback=!array_key_exists('provider_fallback_allowed',$existing)||!empty($existing['provider_fallback_allowed']);
        if($oldProviderFallback!==$providerFallbackAllowed||!array_key_exists('baseline_usable_topic_keys',$existing))return null;
        $oldBinding=(array)($existing['context_binding']??[]);
        if(($oldBinding['contract']??'')!=='PSTE_CONTEXT_INDEX_RUNTIME_BINDING_V2'||($binding['contract']??'')!=='PSTE_CONTEXT_INDEX_RUNTIME_BINDING_V2')return null;
        $same=true;
        foreach(['baseline_sha256','inventory_sha256','structure_sha256','editorial_plan_sha256'] as $key){
            $old=(string)($oldBinding[$key]??'');$current=(string)($binding[$key]??'');
            if($old===''||$current==='')return null;
            if(!hash_equals($old,$current))$same=false;
        }
        $queueUuid=trim((string)($existing['queue_uuid']??''));if($queueUuid==='')return null;
        $localComplete=!empty($existing['local_backlog_complete']);$validatedCheckpoint=null;
        $recheckUntil=0;$recheckCursor=0;$recheckFingerprint='';$recheckChecked=0;
        if($localComplete){if(!$same||!self::canReuseBacklogAudit($binding))return null;}
        else{
            $checkpoint=(array)($existing['local_backlog_checkpoint']??[]);
            $processed=(int)($existing['local_backlog_processed']??-1);
            $cursor=(int)($existing['local_backlog_cursor']??-1);
            if($cursor<0||$processed<0)return null;
            if($cursor===0&&$processed===0){$validatedCheckpoint=['cursor'=>0,'processed_total'=>0];}
            else{
                if(($checkpoint['contract']??'')!==self::BACKLOG_CHECKPOINT_CONTRACT||!self::validBacklogCheckpoint($checkpoint))return null;
                if((int)($checkpoint['cursor']??-1)!==$cursor||(int)($checkpoint['processed_total']??-1)!==$processed)return null;
                $current=self::backlogAuditInput($binding);
                // Row deletion/insertion or non-identical stored source logic must not be silently skipped.
                if((int)($checkpoint['backlog_row_count']??-1)!==(int)($current['backlog_row_count']??-2))return null;
                $validatedCheckpoint=self::reusableBacklogCheckpoint($existing,$binding);
                // Existing-only production may never silently recheck the previously saved
                // prefix after a STOP. A changed dependency needs its own verified safe
                // resolution; retain the signed queue unchanged and fail closed here.
                // Provider-backed research retains its original explicit prefix-recheck path.
                if(!$providerFallbackAllowed&&(!$same||!is_array($validatedCheckpoint)))return null;
                if(!$same||!is_array($validatedCheckpoint)){
                    // One bounded retry of the already checked prefix. Preserve its original cursor,
                    // processed count, candidate evidence and queue identity throughout the replay.
                    $recheckUntil=$cursor;$recheckCursor=0;
                    $previousUntil=(int)($existing['resume_recheck_until']??0);
                    $previousCursor=(int)($existing['resume_recheck_cursor']??0);
                    $previousFingerprint=(string)($existing['resume_recheck_fingerprint']??'');
                    if($previousUntil===$cursor&&$previousCursor>=0&&$previousCursor<$cursor&&$same&&preg_match('/^[a-f0-9]{64}$/',$previousFingerprint)===1&&hash_equals($previousFingerprint,(string)$current['backlog_sha256'])){
                        $recheckCursor=$previousCursor;$recheckChecked=(int)($existing['resume_recheck_checked']??0);
                    }
                    $recheckFingerprint=(string)$current['backlog_sha256'];
                    $validatedCheckpoint=$checkpoint; // signed evidence stays intact until bounded recheck finishes
                }
            }
        }
        $set=[];foreach((array)$existing['baseline_usable_topic_keys'] as $key){$key=trim((string)$key);if($key!=='')$set[$key]=true;}
        $keys=array_keys($set);sort($keys,SORT_STRING);
        return [
            'queue_uuid'=>$queueUuid,'baseline_usable_topic_keys'=>$keys,
            'sandbox_reentry_complete'=>!empty($existing['sandbox_reentry_complete']),
            'sandbox_reentry_checked'=>(int)($existing['sandbox_reentry_checked']??0),
            'sandbox_reentry_applied'=>(int)($existing['sandbox_reentry_applied']??0),
            'sandbox_reentry_failed'=>(int)($existing['sandbox_reentry_failed']??0),
            'local_backlog_complete'=>$localComplete,
            'local_backlog_cursor'=>$localComplete?(int)($existing['local_backlog_cursor']??0):(int)($validatedCheckpoint['cursor']??0),
            'local_backlog_processed'=>$localComplete?(int)($existing['local_backlog_processed']??0):(int)($validatedCheckpoint['processed_total']??0),
            'local_backlog_promoted'=>(int)($existing['local_backlog_promoted']??0),
            'local_backlog_title_candidates'=>(int)($existing['local_backlog_title_candidates']??0),
            'local_backlog_title_candidates_revalidated'=>(int)($existing['local_backlog_title_candidates_revalidated']??0),
            'local_backlog_structure_gaps'=>(int)($existing['local_backlog_structure_gaps']??0),
            'local_backlog_reviews'=>(int)($existing['local_backlog_reviews']??0),
            'local_backlog_retained_non_producing'=>(int)($existing['local_backlog_retained_non_producing']??0),
            'local_backlog_checkpoint'=>$localComplete?(array)($existing['local_backlog_checkpoint']??[]):(array)$validatedCheckpoint,
            'resume_recheck_until'=>$recheckUntil,'resume_recheck_cursor'=>$recheckCursor,'resume_recheck_fingerprint'=>$recheckFingerprint,'resume_recheck_checked'=>$recheckChecked,
        ];
    }

    /** Current strict PASS topics minus the wave-start PASS baseline. No title words or discovery history define identity. */
    private static function countNewUniqueUsableTopics(array $queue,string $runUuid=''): array {
        $baseline=[];foreach((array)($queue['baseline_usable_topic_keys']??[]) as $key){$key=trim((string)$key);if($key!=='')$baseline[$key]=true;}
        try{$current=PSTE_Repository::usablePlanningTopicKeys();}catch(Throwable $e){return ['keys'=>(array)($queue['usable_topic_keys']??[]),'added'=>0,'status'=>'LOCAL_COUNT_READ_FAILED'];}
        $keys=[];foreach($current as $key){$key=trim((string)$key);if($key!==''&&!isset($baseline[$key]))$keys[$key]=true;}$out=array_keys($keys);sort($out,SORT_STRING);
        $before=count((array)($queue['usable_topic_keys']??[]));return ['keys'=>$out,'added'=>max(0,count($out)-$before),'status'=>'PASS_BASELINE_DELTA'];
    }

    /** Mine the already retained SEO backlog first. This phase is local and performs zero provider requests. */
    /** Drain already-safe Sandbox reentries before touching external providers. */
    private static function advanceSandboxExistingPotential(array $queue): array {
        try{$reuse=PSTE_Normal_Reentry_Coordinator::processProviderFreeExistingPotentialBatch(25,false);}
        catch(Throwable $e){return self::pause($queue,self::errorCode($e));}
        if((int)($reuse['provider_calls']??-1)!==0||!empty($reuse['production_handoff_created_by_sandbox'])||!empty($reuse['article_or_taxonomy_write_attempted_by_sandbox']))return self::pause($queue,'PSTE_EXISTING_POTENTIAL_REENTRY_BOUNDARY_VIOLATION');
        $queue['sandbox_reentry_checked']=(int)($queue['sandbox_reentry_checked']??0)+(int)($reuse['reentry_checked']??0);
        $queue['sandbox_reentry_applied']=(int)($queue['sandbox_reentry_applied']??0)+(int)($reuse['reentry_applied']??0);
        $queue['sandbox_reentry_failed']=(int)($queue['sandbox_reentry_failed']??0)+(int)($reuse['reentry_failed']??0);
        $counted=self::countNewUniqueUsableTopics($queue);$queue['usable_topic_keys']=$counted['keys'];$queue['usable_candidate_count']=count($counted['keys']);$queue['updated_at_utc']=gmdate('c');
        if(self::targetReached($queue)&&!empty($queue['provider_fallback_allowed'])){$queue['sandbox_reentry_complete']=true;return self::complete($queue,'TARGET_REACHED_FROM_EXISTING_SANDBOX_POTENTIAL');}
        if(empty($reuse['more_auto_reentry_remaining']))$queue['sandbox_reentry_complete']=true;
        self::save($queue);return self::summary($queue,null);
    }

    private static function advanceLocalBacklog(array $queue): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return self::pause($queue,'PSTE_SITE_BASELINE_REQUIRED');
        $recheckUntil=(int)($queue['resume_recheck_until']??0);
        if($recheckUntil>0){
            $recheckCursor=(int)($queue['resume_recheck_cursor']??0);
            if($recheckCursor<$recheckUntil){
                try{
                    global $wpdb;
                    $table=PSTE_Repository::table('topic_pool');
                    $remaining=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE id>%d AND id<=%d AND manual_status=''",$recheckCursor,$recheckUntil));
                    if($remaining===null||(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_RECHECK_PREFIX_COUNT_READ_FAILED');
                    $bounded=(int)$remaining;
                    if($bounded<0||$bounded>(int)($queue['local_backlog_processed']??0))throw new RuntimeException('PSTE_RECHECK_PREFIX_COUNT_INVALID');
                    $checked=$bounded>0?PSTE_Repository::reanalyzeRetainedBacklogBatch($recheckCursor,min(40,$bounded),$baseline,(array)($queue['context_binding']??[])):['cursor'=>$recheckUntil,'processed'=>0,'provider_calls'=>0];
                    if((int)($checked['provider_calls']??-1)!==0)throw new RuntimeException('PSTE_RECHECK_PROVIDER_CALL_FORBIDDEN');
                    $next=(int)($checked['cursor']??$recheckCursor);
                    if($next<$recheckCursor||$next>$recheckUntil)throw new RuntimeException('PSTE_RECHECK_CURSOR_INVALID');
                    // No more IDs before the old signed cursor: completed prefix has been revalidated.
                    $queue['resume_recheck_cursor']=$next===$recheckCursor?$recheckUntil:$next;
                    $queue['resume_recheck_checked']=(int)($queue['resume_recheck_checked']??0)+(int)($checked['processed']??0);
                    $finger=PSTE_Repository::retainedBacklogFingerprint();
                    $queue['resume_recheck_fingerprint']=(string)($finger['sha256']??'');
                    $queue['updated_at_utc']=gmdate('c');self::save($queue);
                    return self::summary($queue,null);
                }catch(Throwable $e){return self::pause($queue,self::errorCode($e));}
            }
            if((int)($queue['resume_recheck_checked']??-1)!==(int)($queue['local_backlog_processed']??-2))return self::pause($queue,'PSTE_RECHECK_PREFIX_COUNT_CHANGED_PROGRESS_PRESERVED');
            // The prefix has been replayed with the CURRENT validated context. Only now move
            // the signed checkpoint forward to this post-recheck input; the old counter stays.
            try{$queue['local_backlog_checkpoint']=self::makeBacklogCheckpoint((array)($queue['context_binding']??[]),(int)$queue['local_backlog_cursor'],(int)$queue['local_backlog_processed']);}
            catch(Throwable $e){return self::pause($queue,self::errorCode($e));}
            $queue['resume_recheck_until']=0;$queue['resume_recheck_cursor']=0;$queue['resume_recheck_fingerprint']='';$queue['resume_recheck_checked']=0;
            $queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue,null);
        }
        try{$batch=PSTE_Repository::reanalyzeRetainedBacklogBatch((int)($queue['local_backlog_cursor']??0),40,$baseline,(array)($queue['context_binding']??[]));}catch(Throwable $e){return self::pause($queue,self::errorCode($e));}
        if((int)($batch['provider_calls']??-1)!==0)return self::pause($queue,'PSTE_RETAINED_BACKLOG_PROVIDER_CALL_CONTRACT_VIOLATION');
        $queue['local_backlog_cursor']=(int)($batch['cursor']??$queue['local_backlog_cursor']??0);$queue['local_backlog_processed']=(int)($queue['local_backlog_processed']??0)+(int)($batch['processed']??0);$queue['local_backlog_promoted']=(int)($queue['local_backlog_promoted']??0)+(int)($batch['promoted']??0);$queue['local_backlog_title_candidates']=(int)($queue['local_backlog_title_candidates']??0)+(int)($batch['title_candidates_generated']??0);$queue['local_backlog_title_candidates_revalidated']=(int)($queue['local_backlog_title_candidates_revalidated']??0)+(int)($batch['title_candidates_revalidated']??0);$queue['local_backlog_structure_gaps']=(int)($queue['local_backlog_structure_gaps']??0)+(int)($batch['structure_gap_revalidated']??0);$queue['local_backlog_reviews']=(int)($queue['local_backlog_reviews']??0)+(int)($batch['review_revalidated']??0);$queue['local_backlog_retained_non_producing']=(int)($queue['local_backlog_retained_non_producing']??0)+(int)($batch['retained_non_producing_revalidated']??0);$queue['local_backlog_provider_calls']=0;
        $preview=array_values(array_filter((array)($queue['local_backlog_title_preview']??[]),'is_array'));foreach((array)($batch['title_candidates']??[]) as $item){if(!is_array($item))continue;$preview[]=$item;if(count($preview)>50)$preview=array_slice($preview,-50);}$queue['local_backlog_title_preview']=$preview;
        $counted=self::countNewUniqueUsableTopics($queue);$queue['usable_topic_keys']=$counted['keys'];$queue['usable_candidate_count']=count($counted['keys']);$queue['updated_at_utc']=gmdate('c');
        $queue['local_backlog_checkpoint']=self::makeBacklogCheckpoint((array)($queue['context_binding']??[]),(int)$queue['local_backlog_cursor'],(int)$queue['local_backlog_processed']);
        // Existing-only means full stored-fundus traversal. A usable-title quota must never stop
        // that local scan early; only provider-backed production waves may stop at the target.
        if(self::targetReached($queue)&&!empty($queue['provider_fallback_allowed'])){ $queue['local_backlog_complete']=true;return self::complete($queue,'TARGET_REACHED_FROM_RETAINED_BACKLOG'); }
        if(!empty($batch['complete'])){
            if((int)($queue['local_backlog_processed']??0)!==PSTE_Repository::retainedBacklogRowCount())return self::pause($queue,'PSTE_BACKLOG_FINAL_COUNT_CHANGED_PROGRESS_PRESERVED');
            $queue['local_backlog_complete']=true;$queue['local_backlog_reused']=false;self::storeBacklogAuditReceipt((array)($queue['context_binding']??[]));
            if(empty($queue['provider_fallback_allowed']))return self::complete($queue,(int)($queue['local_backlog_title_candidates']??0)>0?'EXISTING_TITLE_CANDIDATES_GENERATED_NO_PROVIDER_CALL':'EXISTING_POTENTIAL_EXHAUSTED_NO_PROVIDER_CALL');
            if((int)($queue['item_count']??0)===0){$baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$open=self::openFamilies(is_array($baseline)?$baseline:[]);if(!$open)return self::complete($queue,'NO_OPEN_FAMILIES_AFTER_RETAINED_BACKLOG');$next=self::spread($open,1);$queue['items']=[self::queueItem((array)$next[0])];$queue['item_count']=1;}
        }
        self::save($queue);return self::summary($queue,null);
    }

    /** Reuse only a completed audit receipt whose data/context/audit semantics are still identical. */
    private static function canReuseBacklogAudit(array $binding): bool {
        if(($binding['contract']??'')!=='PSTE_CONTEXT_INDEX_RUNTIME_BINDING_V2')return false;
        $stored=get_option(PSTE_OPTION_RETAINED_BACKLOG_AUDIT,[]);if(!is_array($stored)||($stored['contract']??'')!==self::BACKLOG_AUDIT_CONTRACT)return false;
        if(!self::validBacklogAuditReceipt($stored))return false;
        try{$current=self::backlogAuditInput($binding);}catch(Throwable $e){return false;}
        foreach(['baseline_sha256','inventory_sha256','structure_sha256','editorial_plan_sha256','backlog_sha256','backlog_row_count'] as $key)if((string)($stored[$key]??'')!==(string)($current[$key]??''))return false;
        $storedLogic=(string)($stored['audit_logic_sha256']??'');
        if(hash_equals((string)$current['audit_logic_sha256'],$storedLogic))return true;
        // Never promote a legacy/changed audit by rewriting only the global receipt.
        // The bounded local worker must supply the new evidence before a new receipt.
        return false;
    }

    /** Exact cause of an invalid historic COMPLETE pair, using ONLY stored metadata. */
    private static function completedAuditEvidenceIssue(array $queue,$receipt): string {
        if(!array_key_exists('provider_fallback_allowed',$queue)||!empty($queue['provider_fallback_allowed']))return 'PSTE_AUDIT_QUEUE_NOT_EXISTING_ONLY';
        if(empty($queue['local_backlog_complete']))return 'PSTE_AUDIT_QUEUE_COMPLETE_FLAG_MISSING';
        $total=(int)($queue['local_backlog_total']??0);
        if($total<1||(int)($queue['local_backlog_processed']??-1)!==$total)return 'PSTE_AUDIT_QUEUE_COUNTER_MISMATCH';
        $cp=$queue['local_backlog_checkpoint']??null;
        if(!is_array($cp)||($cp['contract']??'')!==self::BACKLOG_CHECKPOINT_CONTRACT)return 'PSTE_AUDIT_CHECKPOINT_MISSING';
        if(!self::validBacklogCheckpoint($cp))return 'PSTE_AUDIT_CHECKPOINT_SIGNATURE_INVALID';
        if((int)($cp['processed_total']??-1)!==(int)$queue['local_backlog_processed']
            ||(int)($cp['cursor']??-1)!==(int)($queue['local_backlog_cursor']??-2))return 'PSTE_AUDIT_CHECKPOINT_COUNTER_MISMATCH';
        if(!is_array($receipt)||($receipt['contract']??'')!==self::BACKLOG_AUDIT_CONTRACT)return 'PSTE_AUDIT_RECEIPT_MISSING';
        if(!self::validBacklogAuditReceipt($receipt))return 'PSTE_AUDIT_RECEIPT_SIGNATURE_INVALID';
        if((int)($cp['backlog_row_count']??-1)!==$total||(int)($receipt['backlog_row_count']??-1)!==$total)
            return 'PSTE_AUDIT_PROOF_ROW_COUNT_MISMATCH';
        // The two valid signatures must also refer to the same audited data and
        // decision revision. A plan-only rebind is different and intentionally
        // does not invalidate the previously audited semantic decisions.
        foreach(['audit_logic_sha256','baseline_sha256','inventory_sha256','structure_sha256','backlog_sha256'] as $field){
            if((string)($cp[$field]??'')===''||(string)($receipt[$field]??'')===''||
                !hash_equals((string)$cp[$field],(string)$receipt[$field]))
                return 'PSTE_AUDIT_PROOF_PAIR_MISMATCH_'.strtoupper($field);
        }
        return '';
    }

    /** Reuse the EXISTING 40-row local worker when the historical audit proof is incomplete.
     * The signed old queue and old receipt are retained; neither is taken as a release.
     * Only the explicit start button can enter this path. */
    private static function beginEvidenceRevalidation(array $prior,array $binding,array $usable,string $reason): array {
        $current=self::backlogAuditInput($binding);
        $total=(int)($current['backlog_row_count']??0);
        if($total<1)throw new RuntimeException('PSTE_AUDIT_RECHECK_EMPTY_SOURCE_PROGRESS_PRESERVED');
        if(PSTE_Research_Job::peek()!==null)throw new RuntimeException('PSTE_AUDIT_RECHECK_RESEARCH_JOB_ACTIVE');
        $next=$prior;
        $next['logic_recheck_source']='AUDIT_EVIDENCE_RECHECK';
        $next['audit_recheck_reason']=$reason;
        $next['previous_completed_queue']=$prior;
        $next['queue_uuid']=wp_generate_uuid4();
        $next['status']='RUNNING';$next['last_error']='';$next['coordination_wait_code']='';$next['completion_reason']='';
        $next['context_binding']=$binding;
        $next['sandbox_reentry_complete']=true;
        // A completed audit is historical progress, not an empty new source. Preserve
        // the signed 5,014-row predecessor and use the EXISTING bounded prefix recheck.
        // A changed count cannot be silently treated as an unchanged complete prefix.
        $oldCheckpoint=(array)($prior['local_backlog_checkpoint']??[]);
        $oldProcessed=(int)($prior['local_backlog_processed']??0);
        $oldCursor=(int)($prior['local_backlog_cursor']??0);
        if((string)($prior['status']??'')!=='COMPLETE'||empty($prior['local_backlog_complete'])||
           !array_key_exists('provider_fallback_allowed',$prior)||!empty($prior['provider_fallback_allowed'])||
           $oldProcessed<1||$oldCursor<1||$oldProcessed!==(int)($prior['local_backlog_total']??-1)||
           $total!==$oldProcessed||!self::validBacklogCheckpoint($oldCheckpoint)||
           (int)($oldCheckpoint['cursor']??-1)!==$oldCursor||
           (int)($oldCheckpoint['processed_total']??-1)!==$oldProcessed||
           (int)($oldCheckpoint['backlog_row_count']??-1)!==$oldProcessed){
            throw new RuntimeException('PSTE_COMPLETE_RECHECK_PREFIX_PROOF_INVALID_PROGRESS_PRESERVED');
        }
        $next['local_backlog_complete']=false;$next['local_backlog_reused']=false;$next['local_backlog_resumed']=true;
        $next['local_backlog_total']=$total;$next['local_backlog_cursor']=$oldCursor;$next['local_backlog_processed']=$oldProcessed;
        // Preserve the old counts and preview until a new fully verified receipt exists.
        $next['local_backlog_provider_calls']=0;
        // Keep the preceding signed checkpoint for the entire recheck. Its new
        // fingerprint is signed only after every existing row has been examined.
        $next['local_backlog_checkpoint']=$oldCheckpoint;
        $next['resume_recheck_until']=$oldCursor;$next['resume_recheck_cursor']=0;$next['resume_recheck_fingerprint']='';$next['resume_recheck_checked']=0;
        $next['baseline_usable_topic_keys']=array_values(array_unique(array_map('strval',$usable)));
        $next['usable_topic_keys']=(array)($prior['usable_topic_keys']??[]);
        $next['usable_candidate_count']=(int)($prior['usable_candidate_count']??0);
        $next['items']=[];$next['item_count']=0;$next['current_index']=0;$next['completed_count']=0;$next['blocked_count']=0;
        $next['created_at_utc']=gmdate('c');$next['updated_at_utc']=gmdate('c');
        self::clearCancelRequest();self::save($next);
        return $next;
    }

    /**
     * Explicit, bounded local revalidation after a semantic-rule update. Never reinterpret
     * a signed 4k+ receipt as current, and never overwrite its completed queue evidence.
     * The existing worker processes 40 stored rows per step; no new workflow or storage.
     * @return array<string,mixed>|null Null means this was NOT a logic-only change.
     */
    private static function beginLogicChangedLocalRevalidation(array $prior,array $receipt,array $binding,array $currentUsable): ?array {
        $oldCheckpoint=(array)($prior['local_backlog_checkpoint']??[]);
        if(($oldCheckpoint['contract']??'')!==self::BACKLOG_CHECKPOINT_CONTRACT||!self::validBacklogCheckpoint($oldCheckpoint)
            ||($receipt['contract']??'')!==self::BACKLOG_AUDIT_CONTRACT||!self::validBacklogAuditReceipt($receipt))return null;
        $current=self::backlogAuditInput($binding);
        $oldLogic=(string)($receipt['audit_logic_sha256']??'');
        $newLogic=(string)($current['audit_logic_sha256']??'');
        if($oldLogic===''||$newLogic===''||hash_equals($oldLogic,$newLogic))return null;
        if(!hash_equals($oldLogic,(string)($oldCheckpoint['audit_logic_sha256']??'')))
            throw new RuntimeException('PSTE_EXISTING_ONLY_PREDECESSOR_LOGIC_PROOF_CONFLICT');
        // A changed source, inventory, structure or old row is NOT safe.
        // A strictly appended tail is allowed only after the old prefix is verified.
        foreach(['baseline_sha256','inventory_sha256','structure_sha256'] as $field){
            $before=(string)($receipt[$field]??'');$checkpoint=(string)($oldCheckpoint[$field]??'');$now=(string)($current[$field]??'');
            if($before===''||$checkpoint===''||$now===''||!hash_equals($before,$checkpoint)||!hash_equals($before,$now))
                throw new RuntimeException('PSTE_EXISTING_ONLY_LOGIC_RECHECK_SOURCE_CHANGED_PROGRESS_PRESERVED');
        }
        // The existing plan-only rebinder deliberately updates the completed receipt
        // without editing the signed old queue/checkpoint. Its *old* plan SHA may
        // differ, but the receipt must prove the CURRENT plan before any recheck.
        $receiptPlan=(string)($receipt['editorial_plan_sha256']??'');
        $currentPlan=(string)($current['editorial_plan_sha256']??'');
        $checkpointPlan=(string)($oldCheckpoint['editorial_plan_sha256']??'');
        if($receiptPlan===''||$currentPlan===''||$checkpointPlan===''||!hash_equals($receiptPlan,$currentPlan))
            throw new RuntimeException('PSTE_EXISTING_ONLY_LOGIC_RECHECK_PLAN_CHANGED_PROGRESS_PRESERVED');
        $total=(int)($current['backlog_row_count']??0);
        $oldCount=(int)($receipt['backlog_row_count']??0);
        $oldHash=(string)($receipt['backlog_sha256']??'');
        if($oldCount<1||$oldHash===''||$total<$oldCount
            ||$oldCount!==(int)($oldCheckpoint['backlog_row_count']??-1)
            ||!hash_equals($oldHash,(string)($oldCheckpoint['backlog_sha256']??''))
            ||$oldCount!==(int)($prior['local_backlog_total']??-1)
            ||$oldCount!==(int)($prior['local_backlog_processed']??-1)
            ||$oldCount!==(int)($oldCheckpoint['processed_total']??-1)
            ||(int)($oldCheckpoint['cursor']??0)!==(int)($prior['local_backlog_cursor']??-1))
            throw new RuntimeException('PSTE_EXISTING_ONLY_LOGIC_RECHECK_COMPLETED_COUNTERS_INVALID');
        if($total===$oldCount){
            if(!hash_equals($oldHash,(string)($current['backlog_sha256']??'')))
                throw new RuntimeException('PSTE_EXISTING_ONLY_LOGIC_RECHECK_SOURCE_CHANGED_PROGRESS_PRESERVED');
        }else{
            // Exact append-only continuation with changed logic: prove that every old
            // source row is byte-identical before starting a full LOCAL revalidation.
            // The existing SQL prefix reader is read-only and uses the same tuple hash.
            $prefix=self::retainedBacklogPrefixFingerprint((int)$oldCheckpoint['cursor']);
            if((int)($prefix['row_count']??-1)!==$oldCount||
               !hash_equals($oldHash,(string)($prefix['sha256']??'')))
                throw new RuntimeException('PSTE_EXISTING_ONLY_LOGIC_RECHECK_PREFIX_CHANGED_PROGRESS_PRESERVED');
        }
        if((string)($prior['status']??'')!=='COMPLETE'||empty($prior['local_backlog_complete'])
            ||!array_key_exists('provider_fallback_allowed',$prior)||!empty($prior['provider_fallback_allowed']))
            throw new RuntimeException('PSTE_EXISTING_ONLY_LOGIC_RECHECK_PREDECESSOR_INVALID');

        // The previous COMPLETE queue and receipt remain signed and recoverable.
        // Only the active queue's local cursor/counters are reset for the new rules.
        $next=$prior;
        $next['logic_recheck_source']='SEMANTIC_LOGIC_CHANGED';
        $next['previous_completed_queue']=$prior;
        $next['queue_uuid']=wp_generate_uuid4();
        $next['status']='RUNNING';$next['last_error']='';$next['coordination_wait_code']='';$next['completion_reason']='';
        $next['context_binding']=$binding;
        $next['sandbox_reentry_complete']=true;
        // A completed audit is historical progress, not an empty new source. Preserve
        // the signed 5,014-row predecessor and use the EXISTING bounded prefix recheck.
        // A changed count cannot be silently treated as an unchanged complete prefix.
        $oldCheckpoint=(array)($prior['local_backlog_checkpoint']??[]);
        $oldProcessed=(int)($prior['local_backlog_processed']??0);
        $oldCursor=(int)($prior['local_backlog_cursor']??0);
        if((string)($prior['status']??'')!=='COMPLETE'||empty($prior['local_backlog_complete'])||
           !array_key_exists('provider_fallback_allowed',$prior)||!empty($prior['provider_fallback_allowed'])||
           $oldProcessed<1||$oldCursor<1||$oldProcessed!==(int)($prior['local_backlog_total']??-1)||
           $total<$oldProcessed||!self::validBacklogCheckpoint($oldCheckpoint)||
           (int)($oldCheckpoint['cursor']??-1)!==$oldCursor||
           (int)($oldCheckpoint['processed_total']??-1)!==$oldProcessed||
           (int)($oldCheckpoint['backlog_row_count']??-1)!==$oldProcessed){
            throw new RuntimeException('PSTE_COMPLETE_RECHECK_PREFIX_PROOF_INVALID_PROGRESS_PRESERVED');
        }
        $next['local_backlog_complete']=false;$next['local_backlog_reused']=false;$next['local_backlog_resumed']=true;
        $next['local_backlog_total']=$total;$next['local_backlog_cursor']=$oldCursor;$next['local_backlog_processed']=$oldProcessed;
        // Preserve the old counts and preview until a new fully verified receipt exists.
        $next['local_backlog_provider_calls']=0;
        // Keep the preceding signed checkpoint for the entire recheck. Its new
        // fingerprint is signed only after every existing row has been examined.
        $next['local_backlog_checkpoint']=$oldCheckpoint;
        $next['resume_recheck_until']=$oldCursor;$next['resume_recheck_cursor']=0;$next['resume_recheck_fingerprint']='';$next['resume_recheck_checked']=0;
        $next['baseline_usable_topic_keys']=array_values(array_unique(array_map('strval',$currentUsable)));
        $next['usable_topic_keys']=(array)($prior['usable_topic_keys']??[]);
        $next['usable_candidate_count']=(int)($prior['usable_candidate_count']??0);
        $next['items']=[];$next['item_count']=0;$next['current_index']=0;$next['completed_count']=0;$next['blocked_count']=0;
        $next['created_at_utc']=gmdate('c');$next['updated_at_utc']=gmdate('c');
        self::clearCancelRequest();self::save($next);
        return $next;
    }

    /**
     * Reuse a signed completed audit for strictly append-only future keywords. An unchanged
     * prefix keeps its old cursor and count; changed/deleted prior rows are never replayed
     * automatically. The existing audit receipt remains untouched until the new tail ends.
     */
    private static function continueVerifiedAppendedBacklog(array $queue,array $receipt,array $binding): array {
        $cp=(array)($queue['local_backlog_checkpoint']??[]);
        $oldCount=(int)($queue['local_backlog_processed']??0);
        $cursor=(int)($queue['local_backlog_cursor']??0);
        $current=self::backlogAuditInput($binding);
        $oldHash=(string)($receipt['backlog_sha256']??'');
        if($oldCount<1||$cursor<1||$oldHash===''||
           (int)($cp['backlog_row_count']??-1)!==$oldCount||
           (int)($receipt['backlog_row_count']??-1)!==$oldCount||
           (string)($cp['backlog_sha256']??'')!==$oldHash){
            throw new RuntimeException('PSTE_EXISTING_ONLY_COMPLETED_AUDIT_CHANGED_PROGRESS_PRESERVED');
        }
        foreach(['audit_logic_sha256','baseline_sha256','inventory_sha256','structure_sha256','editorial_plan_sha256'] as $field){
            if((string)($receipt[$field]??'')===''||
               (string)($cp[$field]??'')!==(string)$receipt[$field]||
               (string)($current[$field]??'')!==(string)$receipt[$field]){
                throw new RuntimeException('PSTE_EXISTING_ONLY_COMPLETED_AUDIT_CHANGED_PROGRESS_PRESERVED');
            }
        }
        $newCount=(int)($current['backlog_row_count']??0);
        if($newCount<=$oldCount){
            throw new RuntimeException('PSTE_EXISTING_ONLY_COMPLETED_AUDIT_CHANGED_PROGRESS_PRESERVED');
        }
        $prefix=self::retainedBacklogPrefixFingerprint($cursor);
        if((int)$prefix['row_count']!==$oldCount||!hash_equals($oldHash,(string)$prefix['sha256'])){
            throw new RuntimeException('PSTE_EXISTING_ONLY_PRIOR_ROWS_CHANGED_PROGRESS_PRESERVED');
        }
        // Same queue identity and counters: no fresh job, no zero cursor, no nested history.
        $queue['status']='RUNNING';
        $queue['local_backlog_complete']=false;
        $queue['local_backlog_reused']=false;
        $queue['local_backlog_resumed']=true;
        $queue['local_backlog_total']=$newCount;
        $queue['context_binding']=$binding;
        $queue['local_backlog_checkpoint']=self::makeBacklogCheckpoint($binding,$cursor,$oldCount);
        $queue['last_error']='';$queue['completion_reason']='';$queue['coordination_wait_code']='';
        $queue['updated_at_utc']=gmdate('c');
        self::save($queue);
        return self::summary($queue);
    }

    /** Recover a signed predecessor of a stopped, redundant 0.57.83 re-audit. */
    private static function recoverVerifiedPriorAfterZeroCancel(array $stopped,array $binding): array {
        $prior=$stopped['previous_completed_queue'];
        if(!is_array($prior))throw new RuntimeException('PSTE_ZERO_CANCEL_PRIOR_EVIDENCE_INVALID_PROGRESS_PRESERVED');
        self::assertQueue($prior);
        $cp=(array)($prior['local_backlog_checkpoint']??[]);
        $oldCount=(int)($prior['local_backlog_processed']??0);
        $cursor=(int)($prior['local_backlog_cursor']??0);
        if((string)($prior['status']??'')!=='COMPLETE'||
           !array_key_exists('provider_fallback_allowed',$prior)||!empty($prior['provider_fallback_allowed'])||
           empty($prior['local_backlog_complete'])||$oldCount<1||$cursor<1||
           $oldCount!==(int)($prior['local_backlog_total']??-1)||
           !self::validBacklogCheckpoint($cp)||
           (int)($cp['cursor']??-1)!==$cursor||
           (int)($cp['processed_total']??-1)!==$oldCount||
           (int)($cp['backlog_row_count']??-1)!==$oldCount){
            throw new RuntimeException('PSTE_ZERO_CANCEL_PRIOR_EVIDENCE_INVALID_PROGRESS_PRESERVED');
        }
        $current=self::backlogAuditInput($binding);
        foreach(['audit_logic_sha256','baseline_sha256','inventory_sha256','structure_sha256','editorial_plan_sha256'] as $field){
            if((string)($cp[$field]??'')===''||
               (string)($cp[$field]??'')!==(string)($current[$field]??'')){
                throw new RuntimeException('PSTE_ZERO_CANCEL_PRIOR_INPUT_CHANGED_PROGRESS_PRESERVED');
            }
        }
        $total=(int)$current['backlog_row_count'];
        if($total<$oldCount)throw new RuntimeException('PSTE_ZERO_CANCEL_PRIOR_ROWS_MISSING_PROGRESS_PRESERVED');
        $prefix=self::retainedBacklogPrefixFingerprint($cursor);
        if((int)$prefix['row_count']!==$oldCount||
           !hash_equals((string)($cp['backlog_sha256']??''),(string)$prefix['sha256'])){
            throw new RuntimeException('PSTE_ZERO_CANCEL_PRIOR_ROWS_CHANGED_PROGRESS_PRESERVED');
        }
        // Keep the stopped queue's identity/history; inherit only verified prior counters.
        $stopped['status']=$total===$oldCount?'COMPLETE':'RUNNING';
        $stopped['local_backlog_complete']=$total===$oldCount;
        $stopped['local_backlog_resumed']=true;
        $stopped['local_backlog_reused']=$total===$oldCount;
        $stopped['local_backlog_total']=$total;
        $stopped['local_backlog_cursor']=$cursor;
        $stopped['local_backlog_processed']=$oldCount;
        $stopped['context_binding']=$binding;
        $stopped['sandbox_reentry_complete']=true;
        foreach(['local_backlog_promoted','local_backlog_title_candidates',
                 'local_backlog_title_candidates_revalidated','local_backlog_structure_gaps',
                 'local_backlog_reviews','local_backlog_retained_non_producing',
                 'local_backlog_title_preview'] as $field){
            $stopped[$field]=$prior[$field]??(is_array($stopped[$field]??null)?[]:0);
        }
        $stopped['local_backlog_checkpoint']=self::makeBacklogCheckpoint($binding,$cursor,$oldCount);
        $stopped['last_error']='';$stopped['coordination_wait_code']='';
        $stopped['completion_reason']=$total===$oldCount?(string)($prior['completion_reason']??'COMPLETE'):'';
        $stopped['updated_at_utc']=gmdate('c');
        self::clearCancelRequest();self::save($stopped);
        if($total===$oldCount)self::storeBacklogAuditReceipt($binding);
        return self::summary($stopped);
    }

    /** Hash the exact old rows with the unchanged Repository tuple contract; read-only. */
    private static function retainedBacklogPrefixFingerprint(int $maxId): array {
        global $wpdb;
        $table=PSTE_Repository::table('topic_pool');
        $sql=$wpdb->prepare("SELECT id,pool_key,last_run_uuid,automatic_decision,automatic_pool_status,topic_role,planning_suitability,context_state,structure_sha256,current_category_id,occurrence_count,last_seen_at,SHA2(payload_json,256) AS payload_sha256 FROM $table WHERE manual_status='' AND id<=%d ORDER BY id ASC",$maxId);
        $rows=$wpdb->get_results($sql,ARRAY_A);
        if($rows===null&&(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_RETAINED_BACKLOG_PREFIX_READ_FAILED');
        $ctx=hash_init('sha256');$count=0;
        foreach((array)$rows as $row){
            $count++;
            $tuple=[(int)($row['id']??0),(string)($row['pool_key']??''),(string)($row['last_run_uuid']??''),(string)($row['automatic_decision']??''),(string)($row['automatic_pool_status']??''),(string)($row['topic_role']??''),(string)($row['planning_suitability']??''),(string)($row['context_state']??''),(string)($row['structure_sha256']??''),(int)($row['current_category_id']??0),(int)($row['occurrence_count']??0),(string)($row['last_seen_at']??''),(string)($row['payload_sha256']??'')];
            $encoded=function_exists('wp_json_encode')?wp_json_encode($tuple,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):json_encode($tuple,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            if(!is_string($encoded))throw new RuntimeException('PSTE_RETAINED_BACKLOG_PREFIX_ENCODE_FAILED');
            hash_update($ctx,$encoded."\n");
        }
        return ['row_count'=>$count,'sha256'=>hash_final($ctx)];
    }

    /** Resume a validated partial local audit from the last durable cursor; never call it a full audit. */
    private static function reusableBacklogCheckpoint($existing,array $binding): ?array {
        if(!is_array($existing)||!in_array((string)($existing['status']??''),['CANCELLED','COMPLETE'],true))return null;
        $checkpoint=(array)($existing['local_backlog_checkpoint']??[]);if(($checkpoint['contract']??'')!==self::BACKLOG_CHECKPOINT_CONTRACT)return null;
        if(!self::validBacklogCheckpoint($checkpoint))return null;
        try{$current=self::backlogAuditInput($binding);}catch(Throwable $e){return null;}
        foreach(['audit_logic_sha256','baseline_sha256','inventory_sha256','structure_sha256','editorial_plan_sha256','backlog_sha256','backlog_row_count'] as $key)if((string)($checkpoint[$key]??'')!==(string)($current[$key]??''))return null;
        if((int)($checkpoint['cursor']??0)<=0||(int)($checkpoint['processed_total']??0)<=0)return null;
        return $checkpoint;
    }

    private static function makeBacklogCheckpoint(array $binding,int $cursor,int $processedTotal): array {
        $checkpoint=self::backlogAuditInput($binding);$checkpoint['contract']=self::BACKLOG_CHECKPOINT_CONTRACT;$checkpoint['cursor']=max(0,$cursor);$checkpoint['processed_total']=max(0,$processedTotal);$checkpoint['saved_at_utc']=gmdate('c');$checkpoint['sha256']=self::backlogCheckpointHash($checkpoint);return $checkpoint;
    }

    private static function validBacklogCheckpoint(array $checkpoint): bool {
        $decl=(string)($checkpoint['sha256']??'');return preg_match('/^[a-f0-9]{64}$/',$decl)===1&&hash_equals($decl,self::backlogCheckpointHash($checkpoint));
    }

    private static function backlogCheckpointHash(array $checkpoint): string {
        $parts=[(string)($checkpoint['contract']??self::BACKLOG_CHECKPOINT_CONTRACT),(string)($checkpoint['audit_logic_sha256']??''),(string)($checkpoint['baseline_sha256']??''),(string)($checkpoint['inventory_sha256']??''),(string)($checkpoint['structure_sha256']??''),(string)($checkpoint['editorial_plan_sha256']??''),(string)($checkpoint['backlog_sha256']??''),(string)($checkpoint['backlog_row_count']??0),(string)($checkpoint['cursor']??0),(string)($checkpoint['processed_total']??0),(string)($checkpoint['saved_at_utc']??'')];return hash('sha256',implode("\n",$parts));
    }

    private static function storeBacklogAuditReceipt(array $binding): void {
        $receipt=self::backlogAuditInput($binding);$receipt['contract']=self::BACKLOG_AUDIT_CONTRACT;$receipt['completed_at_utc']=gmdate('c');$receipt['sha256']=self::backlogAuditReceiptHash($receipt);
        update_option(PSTE_OPTION_RETAINED_BACKLOG_AUDIT,$receipt,false);
        $stored=get_option(PSTE_OPTION_RETAINED_BACKLOG_AUDIT,[]);if(!is_array($stored)||!self::validBacklogAuditReceipt($stored)||!hash_equals((string)$receipt['sha256'],(string)($stored['sha256']??'')))throw new RuntimeException('PSTE_RETAINED_BACKLOG_AUDIT_READBACK_MISMATCH');
    }

    private static function backlogAuditInput(array $binding): array {
        if(($binding['contract']??'')!=='PSTE_CONTEXT_INDEX_RUNTIME_BINDING_V2')throw new RuntimeException('PSTE_RETAINED_BACKLOG_CONTEXT_BINDING_REQUIRED');
        $finger=PSTE_Repository::retainedBacklogFingerprint();if(($finger['contract']??'')!=='PSTE_RETAINED_BACKLOG_FINGERPRINT_V1'||!preg_match('/^[a-f0-9]{64}$/',(string)($finger['sha256']??'')))throw new RuntimeException('PSTE_RETAINED_BACKLOG_FINGERPRINT_INVALID');
        return ['audit_logic_sha256'=>self::backlogAuditLogicHash(),'baseline_sha256'=>(string)($binding['baseline_sha256']??''),'inventory_sha256'=>(string)($binding['inventory_sha256']??''),'structure_sha256'=>(string)($binding['structure_sha256']??''),'editorial_plan_sha256'=>(string)($binding['editorial_plan_sha256']??''),'backlog_sha256'=>(string)$finger['sha256'],'backlog_row_count'=>(int)($finger['row_count']??0)];
    }


    /**
     * Conservative logic fingerprint for retained-backlog reuse. A stale audit is more dangerous
     * than an unnecessary local re-audit, so every executable PSTE class plus signed contracts /
     * fixtures that can influence routing are included. This deliberately over-invalidates on
     * unrelated PSTE logic changes, but it can never hide a changed normal-path dependency.
     */
    private static function backlogAuditLogicHash(): string {
        // Only files that can change retained-topic semantic/planning decisions belong here.
        // Admin UI, orchestration, version headers and unrelated fixtures must never force a 4k+ re-audit.
        $root=dirname(__DIR__);
        $relative=[
            'includes/class-pste-repository.php','includes/class-pste-normal-metadata-path.php',
            'includes/class-pste-family-identity-v2.php','includes/class-pste-family-structure-router.php',
            'includes/class-pste-product-choice-classifier.php','includes/class-pste-editorial-topic-normalizer.php',
            'includes/class-pste-intent-profile.php','includes/class-pste-editorial-quality-gate.php',
            'includes/class-pste-planning-readiness-gate.php','includes/class-pste-topic-policy.php',
            'includes/class-pste-title-pipeline.php',
            'includes/class-pste-cannibalization.php','includes/class-pste-article-type-registry.php',
            'includes/class-pste-editorializer.php'
        ];
        $ctx=hash_init('sha256');hash_update($ctx,self::BACKLOG_AUDIT_LOGIC_VERSION."\n");
        foreach($relative as $rel){$file=$root.'/'.$rel;if(!is_file($file))throw new RuntimeException('PSTE_RETAINED_BACKLOG_AUDIT_LOGIC_FILE_MISSING:'.$rel);$h=hash_file('sha256',$file);if(!is_string($h)||!preg_match('/^[a-f0-9]{64}$/',$h))throw new RuntimeException('PSTE_RETAINED_BACKLOG_AUDIT_LOGIC_HASH_FAILED');hash_update($ctx,$rel.'|'.$h."\n");}
        return hash_final($ctx);
    }

    private static function validBacklogAuditReceipt(array $receipt): bool {
        $decl=(string)($receipt['sha256']??'');return preg_match('/^[a-f0-9]{64}$/',$decl)===1&&hash_equals($decl,self::backlogAuditReceiptHash($receipt));
    }

    private static function backlogAuditReceiptHash(array $receipt): string {
        $parts=[(string)($receipt['contract']??self::BACKLOG_AUDIT_CONTRACT),(string)($receipt['audit_logic_sha256']??''),(string)($receipt['baseline_sha256']??''),(string)($receipt['inventory_sha256']??''),(string)($receipt['structure_sha256']??''),(string)($receipt['editorial_plan_sha256']??''),(string)($receipt['backlog_sha256']??''),(string)($receipt['backlog_row_count']??0),(string)($receipt['completed_at_utc']??'')];return hash('sha256',implode("\n",$parts));
    }

    private static function targetReached(array $queue): bool {
        return (string)($queue['mode']??'FIXED_FAMILY_COUNT')==='TARGET_USABLE_CANDIDATES'
            && (int)($queue['target_usable']??0)>0
            && (int)($queue['usable_candidate_count']??0)>=(int)$queue['target_usable'];
    }

    private static function completeOrExtend(array $queue): array {
        if((string)($queue['mode']??'FIXED_FAMILY_COUNT')!=='TARGET_USABLE_CANDIDATES')return self::complete($queue,'FIXED_FAMILY_COUNT_COMPLETE');
        if(self::targetReached($queue))return self::complete($queue,'TARGET_REACHED');
        if(empty($queue['provider_fallback_allowed']))return self::complete($queue,'EXISTING_POTENTIAL_EXHAUSTED_NO_PROVIDER_CALL');
        // Older/live queues can contain more than one row for the same category. The
        // configured ceiling is a family ceiling, not a queue-row ceiling: counting
        // rows here can therefore stop a 40-family run after fewer than 40 families.
        if(self::queuedFamilyCount($queue)>=(int)($queue['max_items']??self::DEFAULT_MAX_ITEMS))return self::complete($queue,'MAX_FAMILIES_REACHED');

        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return self::pause($queue,'PSTE_SITE_BASELINE_REQUIRED');
        $rebase=PSTE_Snapshot::rebaseResearchBaselineIfSafe($baseline);
        if(empty($rebase['ok']))return self::pause($queue,(string)($rebase['error_code']??'PSTE_SITE_BASELINE_STALE'));
        $baseline=(array)$rebase['baseline'];
        $already=[];foreach((array)($queue['items']??[]) as $item)$already[(int)($item['category_id']??0)]=true;
        $open=array_values(array_filter(self::openFamilies($baseline),static fn(array $row): bool=>empty($already[(int)($row['category_id']??0)])));
        if(!$open)return self::complete($queue,'NO_OPEN_FAMILIES');
        $next=self::spread($open,1);
        if(!$next)return self::complete($queue,'NO_OPEN_FAMILIES');
        $queue['items'][]=self::queueItem((array)$next[0]);$queue['item_count']=count($queue['items']);$queue['updated_at_utc']=gmdate('c');self::save($queue);
        return self::summary($queue,null);
    }

    /** Count distinct queued topic families; queue rows are not quota authority. */
    private static function queuedFamilyCount(array $queue): int {
        $families=[];
        foreach((array)($queue['items']??[]) as $item){
            if(!is_array($item))continue;
            $categoryId=(int)($item['category_id']??0);
            if($categoryId>0)$families[$categoryId]=true;
        }
        return count($families);
    }

    /**
     * Losslessly park the currently owned blocked child and continue the same production wave.
     * This is deliberately a separate bounded step: no new provider request is started here.
     */
    public static function parkBlockedCurrentAndContinue(string $queueUuid,string $reason=''): array {
        PSTE_Plugin::assertReady();$token=self::acquireQueueLock();
        try{
            $queue=self::load();if(!hash_equals((string)$queue['queue_uuid'],trim($queueUuid)))throw new RuntimeException('PSTE_BREADTH_QUEUE_ID_MISMATCH');
            if(in_array((string)($queue['status']??''),['COMPLETE','CANCELLED'],true))return self::summary($queue);
            $idx=(int)($queue['current_index']??0);if($idx>=(int)($queue['item_count']??0))return self::completeOrExtend($queue);
            $child=PSTE_Research_Job::peek();$park=null;$code=trim($reason);
            if(is_array($child)){
                if(!in_array(self::childOwnershipState($child,$queue,$idx),['OWNED','LEGACY_MATCH'],true))throw new RuntimeException('PSTE_BREADTH_BLOCKED_CHILD_OWNERSHIP_INVALID');
                $childStatus=(string)($child['status']??'');if(!in_array($childStatus,['PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_BREADTH_CHILD_NOT_BLOCKED_FOR_PARK');
                if($code==='')$code=(string)($child['last_error']??'PSTE_BREADTH_CHILD_BLOCKED');
                $park=PSTE_Research_Job::parkCurrent((string)$child['job_uuid'],$code,['queue_uuid'=>(string)$queue['queue_uuid'],'item_index'=>$idx,'family'=>(string)($queue['items'][$idx]['family']??''),'category_id'=>(int)($queue['items'][$idx]['category_id']??0),'driver_reason'=>$code]);
                $queue=self::load();
            }else{
                // Crash-safe reconciliation: archive may already be durable while queue bookkeeping was not.
                $archived=PSTE_Research_Archive::findForOwner((string)$queue['queue_uuid'],$idx);
                if(!is_array($archived))throw new RuntimeException('PSTE_BREADTH_BLOCKED_CHILD_MISSING_WITHOUT_ARCHIVE');
                $raw=(array)($archived['job']??[]);if($code==='')$code=(string)($archived['park_reason']??$raw['last_error']??'PSTE_BREADTH_CHILD_BLOCKED');
                $park=['job_uuid'=>(string)($archived['job_uuid']??''),'actual_cost'=>(float)($raw['actual_cost']??0.0)];
            }
            $queue['items'][$idx]['status']='BLOCKED_PARKED';$queue['items'][$idx]['parked_job_uuid']=(string)($park['job_uuid']??'');$queue['items'][$idx]['blocked_at_utc']=gmdate('c');$queue['items'][$idx]['last_error']=$code;$queue['items'][$idx]['coordination_wait_code']='';$queue['items'][$idx]['actual_cost']=(float)($park['actual_cost']??$queue['items'][$idx]['actual_cost']??0.0);
            $queue['blocked_count']=(int)($queue['blocked_count']??0)+1;$queue['current_index']=$idx+1;$queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']='';$queue['updated_at_utc']=gmdate('c');
            if((int)$queue['current_index']>=(int)$queue['item_count'])return self::completeOrExtend($queue);
            self::save($queue);return self::summary($queue,null);
        }finally{self::releaseQueueLock($token);}
    }

    public static function requestCancel(string $queueUuid): array {
        $queue=self::load();if(!hash_equals((string)$queue['queue_uuid'],trim($queueUuid)))throw new RuntimeException('PSTE_BREADTH_QUEUE_ID_MISMATCH');
        if(in_array((string)$queue['status'],['COMPLETE','CANCELLED'],true))return self::summary($queue);
        self::storeCancelRequest((string)$queue['queue_uuid']);
        $token=self::acquireQueueLock();
        try{$queue=self::load();if(!hash_equals((string)$queue['queue_uuid'],trim($queueUuid)))throw new RuntimeException('PSTE_BREADTH_QUEUE_ID_MISMATCH');return self::settleCancellation($queue);}finally{self::releaseQueueLock($token);}
    }

    /** Read-only queue snapshot for client status/readback. Never recovers, resumes or advances work. */
    public static function peek(): ?array {
        $q=self::raw();if($q===null)return null;self::assertQueue($q);
        $candidate=null;try{$candidate=PSTE_Research_Job::peek();}catch(Throwable $ignored){}
        $idx=(int)($q['current_index']??0);$child=null;$integrity='';
        if(is_array($candidate)){
            $ownership=self::childOwnershipState($candidate,$q,$idx);
            if(in_array($ownership,['OWNED','LEGACY_MATCH'],true))$child=$candidate;else $integrity='PSTE_BREADTH_FOREIGN_ACTIVE_RESEARCH_JOB';
        }
        return self::summary($q,$child,$integrity,$integrity!==''?$candidate:null);
    }

    public static function current(): ?array {
        $q=self::raw();if($q===null)return null;self::assertQueue($q);$candidate=null;try{$candidate=PSTE_Research_Job::current();}catch(Throwable $ignored){}
        $idx=(int)($q['current_index']??0);$child=null;$integrity='';
        if(is_array($candidate)){
            $ownership=self::childOwnershipState($candidate,$q,$idx);
            if(in_array($ownership,['OWNED','LEGACY_MATCH'],true))$child=$candidate;else $integrity='PSTE_BREADTH_FOREIGN_ACTIVE_RESEARCH_JOB';
        }
        if(self::cancelRequested($q))return self::summary($q,$child,$integrity,$integrity!==''?$candidate:null);
        if($integrity===''){$q=self::recoverTransientCoordinationPause($q,$child);$q=self::recoverSafeSiteContextPause($q,$child);}
        return self::summary($q,$child,$integrity,$integrity!==''?$candidate:null);
    }

    /** @return list<array{category_id:int,seed:string,family:string,root:string}> */
    public static function openFamilies(array $baseline): array {
        $families=PSTE_Category_Context::familyAnchors($baseline);
        $input=array_map(static fn(array $f)=>['term_id'=>(int)$f['term_id'],'name'=>(string)$f['topic_family_name'],'slug'=>(string)$f['topic_family_key']],$families);
        $progress=PSTE_Repository::categoryProgress($input);$states=[];
        foreach((array)($progress['items']??[]) as $p)$states[(int)($p['term_id']??0)]=(string)($p['state']??'');
        $rootStats=[];
        foreach($families as $f){
            $id=(int)$f['term_id'];$root=self::rootKey($id,$baseline);
            if(!isset($rootStats[$root]))$rootStats[$root]=['total'=>0,'processed'=>0];
            $rootStats[$root]['total']++;
            if(($states[$id]??'')!=='NOT_ANALYZED')$rootStats[$root]['processed']++;
        }
        $out=[];
        foreach($families as $f){$id=(int)$f['term_id'];if(($states[$id]??'')!=='NOT_ANALYZED')continue;$root=self::rootKey($id,$baseline);$out[]=['category_id'=>$id,'seed'=>(string)$f['topic_family_name'],'family'=>(string)$f['topic_family_name'],'root'=>$root,'root_processed_count'=>(int)($rootStats[$root]['processed']??0),'root_total_count'=>(int)($rootStats[$root]['total']??0)];}
        usort($out,static fn($a,$b)=>[(int)($a['root_processed_count']??0),(string)$a['root'],(string)$a['family'],(int)$a['category_id']]<=>[(int)($b['root_processed_count']??0),(string)$b['root'],(string)$b['family'],(int)$b['category_id']]);return $out;
    }

    /** @param list<array{category_id:int,seed:string,family:string,root:string}> $rows */
    public static function spread(array $rows,int $count): array {
        $count=max(1,min(self::MAX_ITEMS,$count));$groups=[];$processed=[];
        foreach($rows as $r){$root=(string)$r['root'];$groups[$root][]=$r;$processed[$root]=(int)($r['root_processed_count']??($processed[$root]??0));}
        foreach($groups as &$g)usort($g,static fn($a,$b)=>[(string)$a['family'],(int)$a['category_id']]<=>[(string)$b['family'],(int)$b['category_id']]);unset($g);
        $selected=[];
        while(count($selected)<$count){
            $roots=array_keys(array_filter($groups,static fn($g)=>$g!==[]));
            if(!$roots)break;
            usort($roots,static fn($a,$b)=>[(int)($processed[$a]??0),(string)$a]<=>[(int)($processed[$b]??0),(string)$b]);
            $moved=false;
            foreach($roots as $root){if(!$groups[$root])continue;$row=array_shift($groups[$root]);$selected[]=$row;$processed[$root]=(int)($processed[$root]??0)+1;$moved=true;if(count($selected)>=$count)break;}
            if(!$moved)break;
        }
        return $selected;
    }

    private static function rootKey(int $termId,array $baseline): string {
        foreach((array)($baseline['leaf_categories']??[]) as $leaf){if(!is_array($leaf)||(int)($leaf['term_id']??0)!==$termId)continue;$nodes=(array)($leaf['portal_path_nodes']??[]);if(isset($nodes[0])&&is_array($nodes[0])){$slug=trim((string)($nodes[0]['slug']??''));$name=trim((string)($nodes[0]['name']??''));if($slug!==''||$name!=='')return $slug!==''?$slug:$name;}$names=(array)($leaf['portal_ancestor_page_names']??[]);if(isset($names[0])&&trim((string)$names[0])!=='')return trim((string)$names[0]);}
        return 'ROOT_UNRESOLVED';
    }
    private static function recoverTransientCoordinationPause(array $queue,?array $child): array {
        $code=(string)($queue['last_error']??'');
        if((string)($queue['status']??'')!=='PAUSED_ERROR'||(!self::isTransientCoordinationCode($code)&&!self::isReplaySafeLocalFinalizeCode($code)))return $queue;
        if(!is_array($child)||(string)($child['status']??'')!=='RUNNING')return $queue;
        $idx=(int)($queue['current_index']??0);if(!isset($queue['items'][$idx])||!is_array($queue['items'][$idx]))return $queue;
        if(!in_array(self::childOwnershipState($child,$queue,$idx),['OWNED','LEGACY_MATCH'],true))return $queue;
        $actual=(string)($child['job_uuid']??'');if($actual==='')return $queue;$expected=(string)($queue['items'][$idx]['child_job_uuid']??'');
        if($expected==='')$queue['items'][$idx]['child_job_uuid']=$actual;
        $queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']=$code;$queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']=$code;$queue['updated_at_utc']=gmdate('c');self::save($queue);
        return $queue;
    }
    private static function recoverSafeSiteContextPause(array $queue,?array $child): array {
        if((string)($queue['status']??'')!=='PAUSED_ERROR'||(string)($queue['last_error']??'')!=='PSTE_SITE_BASELINE_STALE')return $queue;
        if(!is_array($child)||(string)($child['status']??'')!=='RUNNING'||(string)($child['coordination_wait_code']??'')!=='PSTE_SITE_CONTEXT_REBASED_SAFE')return $queue;
        $idx=(int)($queue['current_index']??0);if(!isset($queue['items'][$idx])||!is_array($queue['items'][$idx])||!in_array(self::childOwnershipState($child,$queue,$idx),['OWNED','LEGACY_MATCH'],true))return $queue;
        $queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']='PSTE_SITE_CONTEXT_REBASED_SAFE';$queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']='PSTE_SITE_CONTEXT_REBASED_SAFE';$queue['updated_at_utc']=gmdate('c');self::save($queue);return $queue;
    }

    private static function settleCancellation(array $queue,?array $child=null): array {
        if(!self::cancelRequested($queue))return self::summary($queue,$child);
        if(in_array((string)($queue['status']??''),['COMPLETE','CANCELLED'],true)){self::clearCancelRequest((string)$queue['queue_uuid']);return self::summary($queue,$child);}
        if($child===null){try{$child=PSTE_Research_Job::peek();}catch(Throwable $e){$child=null;}}
        $idx=(int)($queue['current_index']??0);$cancelResolution='';
        if(is_array($child)){
            $ownership=self::childOwnershipState($child,$queue,$idx);
            if($ownership==='FOREIGN'){
                // A foreign global research job must never make the owning breadth queue impossible to stop.
                // Cancel only the queue; preserve the foreign job so it can be handled by its own safe-cancel path.
                if(isset($queue['items'][$idx])&&is_array($queue['items'][$idx])&&(string)($queue['items'][$idx]['status']??'')!=='COMPLETE'){
                    $queue['items'][$idx]['status']='CANCELLED_FOREIGN_JOB_PRESERVED';$queue['items'][$idx]['last_error']='PSTE_BREADTH_FOREIGN_ACTIVE_RESEARCH_JOB';$queue['items'][$idx]['coordination_wait_code']='';
                }
                $cancelResolution='FOREIGN_ACTIVE_JOB_PRESERVED';
            }elseif((string)($child['status']??'')==='COMPLETE'){
                // Completion may delete the active child before the queue observes the cancel marker.
                // Persist the completed child evidence into queue history; never attempt a second cancel/write.
                if(isset($queue['items'][$idx])&&is_array($queue['items'][$idx])){
                    $queue['items'][$idx]['status']='COMPLETE_BEFORE_CANCEL';$queue['items'][$idx]['actual_cost']=(float)($child['actual_cost']??$queue['items'][$idx]['actual_cost']??0.0);$queue['items'][$idx]['raw_usable_candidate_count']=max(0,(int)($child['usable_candidate_count']??0));$queue['items'][$idx]['candidate_count']=max(0,(int)($child['candidate_count']??0));$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']='';
                }
                $cancelResolution='CHILD_COMPLETED_BEFORE_CANCEL';
            }else{
                try{$cancelled=PSTE_Research_Job::cancelForBreadthStop((string)$child['job_uuid']);}
                catch(Throwable $e){
                    $code=self::errorCode($e);
                    if(in_array($code,['PSTE_RESEARCH_STEP_ALREADY_RUNNING','PSTE_BREADTH_CANCEL_WAIT_IN_FLIGHT'],true)){
                        $queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']=$code;if(isset($queue['items'][$idx])&&is_array($queue['items'][$idx])){$queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']=$code;}$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue,$child);
                    }
                    if($code==='PSTE_BREADTH_CANCEL_PROVIDER_OUTCOME_UNKNOWN'){
                        $queue['status']='OUTCOME_UNKNOWN';$queue['last_error']=$code;$queue['coordination_wait_code']='';if(isset($queue['items'][$idx])&&is_array($queue['items'][$idx])){$queue['items'][$idx]['status']='OUTCOME_UNKNOWN';$queue['items'][$idx]['last_error']=$code;$queue['items'][$idx]['coordination_wait_code']='';}$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue,$child);
                    }
                    if($code==='PSTE_RESEARCH_JOB_MISSING'){$cancelResolution='CHILD_ALREADY_GONE';}
                    else throw $e;
                }
                if(isset($cancelled)&&is_array($cancelled)&&isset($queue['items'][$idx])&&is_array($queue['items'][$idx])){
                    $queue['items'][$idx]['status']='CANCELLED';$queue['items'][$idx]['actual_cost']=(float)($cancelled['actual_cost']??$queue['items'][$idx]['actual_cost']??0.0);$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']='';$cancelResolution='OWNED_CHILD_CANCELLED';
                }elseif($cancelResolution==='CHILD_ALREADY_GONE'&&isset($queue['items'][$idx])&&is_array($queue['items'][$idx])&&(string)($queue['items'][$idx]['status']??'')!=='COMPLETE'){
                    $queue['items'][$idx]['status']='CANCELLED_CHILD_ALREADY_GONE';$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']='';
                }
            }
        }elseif(isset($queue['items'][$idx])&&is_array($queue['items'][$idx])&&(string)($queue['items'][$idx]['status']??'')!=='COMPLETE'){
            $queue['items'][$idx]['status']='CANCELLED_NO_ACTIVE_CHILD';$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']='';$cancelResolution='NO_ACTIVE_CHILD';
        }else{$cancelResolution='NO_ACTIVE_CHILD';}
        for($i=$idx+1;$i<(int)($queue['item_count']??0);$i++)if(isset($queue['items'][$i])&&is_array($queue['items'][$i])&&(string)($queue['items'][$i]['status']??'')!=='COMPLETE'){$queue['items'][$i]['status']='CANCELLED_NOT_STARTED';$queue['items'][$i]['last_error']='';$queue['items'][$i]['coordination_wait_code']='';}
        $queue['status']='CANCELLED';$queue['completion_reason']='CANCELLED_BY_USER';$queue['cancel_resolution']=$cancelResolution;$queue['last_error']='';$queue['coordination_wait_code']='';$queue['cancelled_at_utc']=gmdate('c');$queue['updated_at_utc']=$queue['cancelled_at_utc'];self::save($queue);self::clearCancelRequest((string)$queue['queue_uuid']);return self::summary($queue,null,'',is_array($child)&&$cancelResolution==='FOREIGN_ACTIVE_JOB_PRESERVED'?$child:null);
    }

    private static function cancelMarker(): ?array {
        $m=get_option(PSTE_OPTION_BREADTH_RESEARCH_CANCEL,null);if($m===null||$m===false||$m==='')return null;if(!is_array($m))throw new RuntimeException('PSTE_BREADTH_CANCEL_STORAGE_INVALID');
        $decl=(string)($m['sha256']??'');$copy=$m;unset($copy['sha256']);if(($m['contract']??'')!=='PSTE_BREADTH_CANCEL_REQUEST_V1'||!preg_match('/^[a-f0-9]{64}$/',$decl)||!hash_equals(hash('sha256',self::canonicalJson($copy)),$decl))throw new RuntimeException('PSTE_BREADTH_CANCEL_REQUEST_INVALID');return $m;
    }
    private static function cancelRequested(array $queue): bool {$m=self::cancelMarker();return is_array($m)&&hash_equals((string)($queue['queue_uuid']??''),(string)($m['queue_uuid']??''));}
    private static function storeCancelRequest(string $queueUuid): void {$m=['contract'=>'PSTE_BREADTH_CANCEL_REQUEST_V1','queue_uuid'=>$queueUuid,'requested_at_utc'=>gmdate('c')];$m['sha256']=hash('sha256',self::canonicalJson($m));update_option(PSTE_OPTION_BREADTH_RESEARCH_CANCEL,$m,false);$stored=self::cancelMarker();if(!is_array($stored)||!hash_equals($queueUuid,(string)($stored['queue_uuid']??'')))throw new RuntimeException('PSTE_BREADTH_CANCEL_REQUEST_READBACK_MISMATCH');}
    private static function clearCancelRequest(string $queueUuid=''): void {$m=get_option(PSTE_OPTION_BREADTH_RESEARCH_CANCEL,null);if(!is_array($m)){if($queueUuid==='')delete_option(PSTE_OPTION_BREADTH_RESEARCH_CANCEL);return;}if($queueUuid===''||hash_equals($queueUuid,(string)($m['queue_uuid']??'')))delete_option(PSTE_OPTION_BREADTH_RESEARCH_CANCEL);}


    /** Read-only state of the breadth server-step lock. */
    public static function queueLockStatus(): array {
        $raw=get_option(PSTE_OPTION_BREADTH_RESEARCH_LOCK,[]);if(!is_array($raw)||empty($raw['token']))return ['locked'=>false,'expires_at'=>0,'retry_after_ms'=>0,'expired_owner'=>false];
        $expires=(int)($raw['expires_at']??0);$now=time();$locked=$expires>=$now;
        return ['locked'=>$locked,'expires_at'=>$expires,'retry_after_ms'=>$locked?max(750,min(3000,($expires-$now+1)*1000)):0,'expired_owner'=>!$locked&&$expires>0];
    }

    private static function acquireLaunchLock(): string {$token=hash('sha256','launch|'.microtime(true).'|'.wp_generate_uuid4());$payload=['token'=>$token,'expires_at'=>time()+120];if(add_option(PSTE_OPTION_RESEARCH_CONTROL_LOCK,$payload,'',false))return $token;$existing=get_option(PSTE_OPTION_RESEARCH_CONTROL_LOCK,[]);if(is_array($existing)&&(int)($existing['expires_at']??0)<time()){self::deleteExpiredOptionLockAtomically(PSTE_OPTION_RESEARCH_CONTROL_LOCK);if(add_option(PSTE_OPTION_RESEARCH_CONTROL_LOCK,$payload,'',false))return $token;}throw new RuntimeException('PSTE_RESEARCH_CONTROL_START_LOCKED');}
    private static function releaseLaunchLock(string $token): void {self::deleteOwnedOptionLockAtomically(PSTE_OPTION_RESEARCH_CONTROL_LOCK,$token);}

    /** Reuse the queue's existing atomic lock for the other topic-pool writer.
     * A context step is either serialized with a backlog step or left untouched.
     * Null means the lock was busy; no write was attempted. */
    public static function withTopicPoolWriteLock(callable $work): ?array {
        try { $token=self::acquireQueueLock(); }
        catch (RuntimeException $e) {
            if($e->getMessage()==='PSTE_BREADTH_QUEUE_STEP_ALREADY_RUNNING')return null;
            throw $e;
        }
        try { return $work(); }
        finally { self::releaseQueueLock($token); }
    }

    private static function acquireQueueLock(): string {$token=hash('sha256',microtime(true).'|'.wp_generate_uuid4());$payload=['token'=>$token,'expires_at'=>time()+self::QUEUE_LOCK_TTL];if(self::insertOptionLockIfAbsent(PSTE_OPTION_BREADTH_RESEARCH_LOCK,$payload)){self::$activeQueueFenceToken=$token;return $token;}self::deleteExpiredOptionLockAtomically(PSTE_OPTION_BREADTH_RESEARCH_LOCK);if(self::insertOptionLockIfAbsent(PSTE_OPTION_BREADTH_RESEARCH_LOCK,$payload)){self::$activeQueueFenceToken=$token;return $token;}throw new RuntimeException('PSTE_BREADTH_QUEUE_STEP_ALREADY_RUNNING');}
    private static function insertOptionLockIfAbsent(string $option,array $value): bool {global $wpdb;$r=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,%s)",$option,maybe_serialize($value),'off'));if($r===false)throw new RuntimeException('PSTE_BREADTH_QUEUE_LOCK_INSERT_FAILED');wp_cache_delete($option,'options');wp_cache_delete('notoptions','options');return (int)$r===1;}
    private static function releaseQueueLock(string $token): void {self::deleteOwnedOptionLockAtomically(PSTE_OPTION_BREADTH_RESEARCH_LOCK,$token);if(self::$activeQueueFenceToken!==''&&hash_equals(self::$activeQueueFenceToken,$token))self::$activeQueueFenceToken='';}

    private static function deleteExpiredOptionLockAtomically(string $option): void {global $wpdb;$raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$option));if(!is_string($raw)||$raw==='')return;$v=maybe_unserialize($raw);if(!is_array($v)||(int)($v['expires_at']??0)>=time())return;PSTE_DB_Write_Guard::query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$option,$raw),'PSTE_LOCK_ATOMIC_EXPIRED_DELETE_FAILED');wp_cache_delete($option,'options');}
    private static function deleteOwnedOptionLockAtomically(string $option,string $token): void {global $wpdb;$raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$option));if(!is_string($raw)||$raw==='')return;$v=maybe_unserialize($raw);if(!is_array($v)||!hash_equals($token,(string)($v['token']??'')))return;PSTE_DB_Write_Guard::query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$option,$raw),'PSTE_LOCK_ATOMIC_RELEASE_FAILED');wp_cache_delete($option,'options');}
    private static function isTransientCoordinationCode(string $code): bool {return in_array($code,self::TRANSIENT_COORDINATION_CODES,true);}
    private static function transportRecoveryMode(array $queue,?array $child): string {
        if((string)($queue['status']??'')!=='RUNNING')return 'TERMINAL';
        if((string)($queue['mode']??'')==='TARGET_USABLE_CANDIDATES'&&empty($queue['local_backlog_complete']))return 'LOCAL_CHECKPOINT_RETRY_SAFE';
        if(is_array($child))return (string)($child['transport_recovery_mode']??'FAIL_CLOSED');
        return 'LOCAL_CHECKPOINT_RETRY_SAFE';
    }

    private static function isReplaySafeLocalFinalizeCode(string $code): bool {return in_array($code,self::REPLAY_SAFE_LOCAL_FINALIZE_CODES,true);}
    private static function childOwnershipState(array $child,array $queue,int $idx): string {
        if(!isset($queue['items'][$idx])||!is_array($queue['items'][$idx]))return 'FOREIGN';
        $kind=strtoupper(trim((string)($child['owner_kind']??'')));
        if($kind==='BREADTH'){
            if(!hash_equals((string)($queue['queue_uuid']??''),(string)($child['owner_queue_uuid']??'')))return 'FOREIGN';
            if((int)($child['owner_item_index']??-1)!==$idx)return 'FOREIGN';
            return self::childMatchesItem($child,(array)$queue['items'][$idx])?'OWNED':'FOREIGN';
        }
        if($kind==='SINGLE')return 'FOREIGN';
        return self::childMatchesItem($child,(array)$queue['items'][$idx])?'LEGACY_MATCH':'FOREIGN';
    }
    private static function childMatchesItem(array $child,array $item): bool {$expected=(string)($item['child_job_uuid']??'');$actual=(string)($child['job_uuid']??'');if($actual===''||($expected!==''&&!hash_equals($expected,$actual)))return false;if(isset($child['category_id'])&&(int)$child['category_id']!==(int)($item['category_id']??0))return false;if(isset($child['seed'])&&trim((string)$child['seed'])!==trim((string)($item['seed']??$child['seed'])))return false;return true;}
    private static function coordinationWait(array $queue,string $code,?array $child): array {$idx=(int)($queue['current_index']??0);if(isset($queue['items'][$idx])&&is_array($queue['items'][$idx])){$queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']=$code;}if(is_array($child)&&isset($queue['items'][$idx])&&(string)($queue['items'][$idx]['child_job_uuid']??'')===''&&in_array(self::childOwnershipState($child,$queue,$idx),['OWNED','LEGACY_MATCH'],true))$queue['items'][$idx]['child_job_uuid']=(string)($child['job_uuid']??'');$queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']=$code;$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue,$child);}

    private static function complete(array $queue,string $reason='COMPLETE'): array {$queue['status']='COMPLETE';$queue['completion_reason']=$reason;$queue['last_error']='';$queue['coordination_wait_code']='';$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue);}
    private static function pause(array $queue,string $error): array {$idx=(int)$queue['current_index'];if(isset($queue['items'][$idx])){$queue['items'][$idx]['status']='PAUSED_ERROR';$queue['items'][$idx]['last_error']=$error;$queue['items'][$idx]['coordination_wait_code']='';}$queue['status']='PAUSED_ERROR';$queue['last_error']=$error;$queue['coordination_wait_code']='';$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue);}
    private static function summary(array $q,?array $child=null,string $integrityError='',?array $foreignChild=null): array {
        $m=self::cancelMarker();$cancel=is_array($m)&&hash_equals((string)($q['queue_uuid']??''),(string)($m['queue_uuid']??''));
        $mode=(string)($q['mode']??'FIXED_FAMILY_COUNT');$target=(int)($q['target_usable']??0);$usable=(int)($q['usable_candidate_count']??0);
        return ['contract'=>self::CONTRACT,'queue_uuid'=>(string)$q['queue_uuid'],'status'=>(string)$q['status'],'mode'=>$mode,'requested_count'=>(int)$q['requested_count'],'target_usable'=>$target,'usable_candidate_count'=>$usable,'raw_usable_candidate_count'=>(int)($q['raw_usable_candidate_count']??$usable),'target_achieved'=>$mode==='TARGET_USABLE_CANDIDATES'&&$target>0&&$usable>=$target,'max_items'=>(int)($q['max_items']??($q['item_count']??self::LEGACY_MAX_ITEMS)),'provider_fallback_allowed'=>!array_key_exists('provider_fallback_allowed',$q)||!empty($q['provider_fallback_allowed']),'existing_only'=>array_key_exists('provider_fallback_allowed',$q)&&empty($q['provider_fallback_allowed']),'completion_reason'=>(string)($q['completion_reason']??''),'continued_from_queue_uuid'=>(string)($q['continued_from_queue_uuid']??''),'continued_usable_candidate_count'=>(int)($q['continued_usable_candidate_count']??0),'sandbox_reentry_complete'=>!empty($q['sandbox_reentry_complete']),'sandbox_reentry_checked'=>(int)($q['sandbox_reentry_checked']??0),'sandbox_reentry_applied'=>(int)($q['sandbox_reentry_applied']??0),'sandbox_reentry_failed'=>(int)($q['sandbox_reentry_failed']??0),'local_backlog_complete'=>!empty($q['local_backlog_complete']),'local_backlog_reused'=>!empty($q['local_backlog_reused']),'local_backlog_resumed'=>!empty($q['local_backlog_resumed']),'transport_recovery_mode'=>self::transportRecoveryMode($q,$child),'local_backlog_total'=>(int)($q['local_backlog_total']??0),'local_backlog_cursor'=>(int)($q['local_backlog_cursor']??0),'local_backlog_processed'=>(int)($q['local_backlog_processed']??0),'local_backlog_promoted'=>(int)($q['local_backlog_promoted']??0),'local_backlog_title_candidates'=>(int)($q['local_backlog_title_candidates']??0),'local_backlog_title_candidates_revalidated'=>(int)($q['local_backlog_title_candidates_revalidated']??0),'local_backlog_structure_gaps'=>(int)($q['local_backlog_structure_gaps']??0),'local_backlog_reviews'=>(int)($q['local_backlog_reviews']??0),'local_backlog_retained_non_producing'=>(int)($q['local_backlog_retained_non_producing']??0),'local_backlog_title_preview'=>array_values(array_filter((array)($q['local_backlog_title_preview']??[]),'is_array')),'local_backlog_provider_calls'=>(int)($q['local_backlog_provider_calls']??0),'audit_recheck_source'=>(string)($q['logic_recheck_source']??''),'audit_recheck_reason'=>(string)($q['audit_recheck_reason']??''),'item_count'=>(int)$q['item_count'],'current_index'=>(int)$q['current_index'],'completed_count'=>(int)$q['completed_count'],'blocked_count'=>(int)($q['blocked_count']??0),'last_error'=>(string)$q['last_error'],'coordination_wait_code'=>(string)($q['coordination_wait_code']??''),'cancel_requested'=>$cancel,'cancel_requested_at_utc'=>$cancel?(string)($m['requested_at_utc']??''):'','cancelled_at_utc'=>(string)($q['cancelled_at_utc']??''),'created_at_utc'=>(string)($q['created_at_utc']??''),
            'items'=>array_map(static fn($i)=>['category_id'=>(int)$i['category_id'],'family'=>(string)$i['family'],'root'=>(string)$i['root'],'status'=>(string)$i['status'],'actual_cost'=>(float)$i['actual_cost'],'usable_candidate_count'=>(int)($i['usable_candidate_count']??0),'raw_usable_candidate_count'=>(int)($i['raw_usable_candidate_count']??($i['usable_candidate_count']??0)),'candidate_count'=>(int)($i['candidate_count']??0),'count_status'=>(string)($i['count_status']??''),'last_error'=>(string)$i['last_error'],'coordination_wait_code'=>(string)($i['coordination_wait_code']??''),'child_job_uuid'=>(string)($i['child_job_uuid']??''),'parked_job_uuid'=>(string)($i['parked_job_uuid']??''),'blocked_at_utc'=>(string)($i['blocked_at_utc']??'')],(array)$q['items']),'child'=>$child,'integrity_error'=>$integrityError,'foreign_active_job'=>is_array($foreignChild)?['job_uuid'=>(string)($foreignChild['job_uuid']??''),'status'=>(string)($foreignChild['status']??''),'category_id'=>(int)($foreignChild['category_id']??0),'seed'=>(string)($foreignChild['seed']??''),'owner_kind'=>(string)($foreignChild['owner_kind']??''),'owner_queue_uuid'=>(string)($foreignChild['owner_queue_uuid']??''),'owner_item_index'=>(int)($foreignChild['owner_item_index']??-1)]:null,'cancel_resolution'=>(string)($q['cancel_resolution']??''),'updated_at_utc'=>(string)$q['updated_at_utc']];
    }
    private static function raw(): ?array {$v=get_option(PSTE_OPTION_BREADTH_RESEARCH_QUEUE,null);if($v===null||$v===false||$v==='')return null;if(!is_array($v))throw new RuntimeException('PSTE_BREADTH_QUEUE_STORAGE_INVALID');return $v;}
    private static function load(): array {
        // Under the durable DB lock, never trust a get_option() snapshot cached by
        // an earlier operation in the same PHP request. Read the committed option
        // directly from the database; concurrent workers otherwise replay old cursors.
        if(self::$activeQueueFenceToken!==''){
            global $wpdb;
            $raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",PSTE_OPTION_BREADTH_RESEARCH_QUEUE));
            if(!is_string($raw)||$raw===''||(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_BREADTH_QUEUE_LOCKED_READ_FAILED');
            $q=maybe_unserialize($raw);
        }else{$q=self::raw();}
        if(!is_array($q))throw new RuntimeException('PSTE_BREADTH_QUEUE_MISSING');
        self::assertQueue($q);return $q;
    }
    private static function save(array $q): void {if(self::$activeQueueFenceToken!==''){$lock=get_option(PSTE_OPTION_BREADTH_RESEARCH_LOCK,[]);if(!is_array($lock)||!hash_equals(self::$activeQueueFenceToken,(string)($lock['token']??'')))throw new RuntimeException('PSTE_BREADTH_QUEUE_FENCE_LOST');}$q=self::withHash($q);update_option(PSTE_OPTION_BREADTH_RESEARCH_QUEUE,$q,false);$stored=get_option(PSTE_OPTION_BREADTH_RESEARCH_QUEUE,null);if(!is_array($stored)||!hash_equals((string)$q['sha256'],(string)($stored['sha256']??'')))throw new RuntimeException('PSTE_BREADTH_QUEUE_READBACK_MISMATCH');self::assertQueue($stored);}
    private static function withHash(array $q): array {$q['contract']=self::CONTRACT;$q['version']=self::VERSION;unset($q['sha256']);$q['sha256']=hash('sha256',self::canonicalJson($q));return $q;}
    private static function assertQueue(array $q): void {
        if(($q['contract']??'')!==self::CONTRACT||!in_array((string)($q['version']??''),self::COMPATIBLE_VERSIONS,true))throw new RuntimeException('PSTE_BREADTH_QUEUE_CONTRACT_INVALID');
        $decl=(string)($q['sha256']??'');$copy=$q;unset($copy['sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$decl)||!hash_equals(hash('sha256',self::canonicalJson($copy)),$decl))throw new RuntimeException('PSTE_BREADTH_QUEUE_HASH_MISMATCH');
        $itemCount=(int)($q['item_count']??0);$targetMode=(string)($q['mode']??'')==='TARGET_USABLE_CANDIDATES';$allowZero=in_array((string)($q['version']??''),['1.4.0','1.5.0','1.6.0','1.7.0','1.8.0'],true)&&$targetMode;
        $overFamilyLimit=$targetMode?self::queuedFamilyCount($q)>(int)($q['max_items']??self::DEFAULT_MAX_ITEMS):$itemCount>self::MAX_ITEMS;
        if($itemCount<($allowZero?0:1)||$overFamilyLimit)throw new RuntimeException('PSTE_BREADTH_QUEUE_SIZE_INVALID');
        if(!in_array((string)($q['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN','COMPLETE','CANCELLED'],true))throw new RuntimeException('PSTE_BREADTH_QUEUE_STATUS_INVALID');
        if(in_array((string)($q['version']??''),['1.3.0','1.4.0','1.5.0','1.6.0','1.7.0','1.8.0'],true)&&(string)($q['mode']??'')==='TARGET_USABLE_CANDIDATES'){
            if((int)($q['target_usable']??0)<1||(int)($q['max_items']??0)<1||(int)$q['max_items']>self::MAX_ITEMS)throw new RuntimeException('PSTE_BREADTH_TARGET_CONFIG_INVALID');
        }
    }
    private static function canonicalJson($value): string {$json=wp_json_encode(self::canonicalize($value),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($json))throw new RuntimeException('PSTE_BREADTH_QUEUE_JSON_ENCODE_FAILED');return $json;}
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
    private static function errorCode(Throwable $e): string {$code=strtoupper(trim((string)$e->getMessage()));$code=(string)preg_replace('/[^A-Z0-9_:\-]/','_',$code);return substr($code!==''?$code:'PSTE_BREADTH_QUEUE_FAILED',0,180);}
}
