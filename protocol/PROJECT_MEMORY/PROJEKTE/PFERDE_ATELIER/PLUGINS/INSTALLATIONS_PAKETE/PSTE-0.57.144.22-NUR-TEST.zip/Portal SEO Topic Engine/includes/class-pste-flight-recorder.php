<?php
if (!defined('ABSPATH')) { return; }
/**
 * PSTE continuous workflow evidence recorder, V3. Passive observations of
 * existing WordPress storage writes only. It does NOT re-evaluate any decision.
 * Each request saves one immutable batch of bounded sanitized events; batches
 * are not deleted/truncated by the recorder. No worker, no new database table.
 */
final class PSTE_Flight_Recorder {
    private const PREFIX='pste_flight_batch_v2_';
    private const HISTORY_PAGE_SIZE=48;
    private static string $requestId='';
    private static array $zeroRowSummary=[];
    private static array $buffer=[];
    private static bool $flushing=false;
    private static bool $registered=false;
    private static int $sequence=0;

    public static function init(): void {
        if(self::$registered)return;
        self::$registered=true;
        add_action('added_option',[self::class,'added'],10,2);
        add_action('updated_option',[self::class,'updated'],10,3);
        add_action('deleted_option',[self::class,'deleted'],10,1);
        add_action('transition_post_status',[self::class,'postTransition'],10,3);
        add_action('wp_after_insert_post',[self::class,'postWritten'],10,4);
        add_action('set_object_terms',[self::class,'postCategoryAssigned'],10,6);
        add_action('created_term',[self::class,'createdTerm'],10,3);
        add_action('edited_term',[self::class,'editedTerm'],10,3);
        add_action('delete_term',[self::class,'deletedTerm'],10,5);
        add_action('http_api_debug',[self::class,'providerHttp'],10,5);
        add_filter('query',[self::class,'compilerSqlAttempt'],10,1);
        add_action('pste_workflow_evidence',[self::class,'externalStageEvidence'],10,3);
        add_action('shutdown',[self::class,'finish'],1000);
    }
    public static function added($key,$value): void {self::observe((string)$key,$value,'CREATED');}
    public static function updated($key,$old,$value): void {self::observe((string)$key,$value,'UPDATED');}
    public static function deleted($key): void {self::observe((string)$key,[],'DELETED');}
    public static function postTransition($new,$old,$post): void {
        try {
            if(!is_object($post)||($post->post_type??'')!=='post'||$new===$old)return;
            self::event('WORDPRESS_POST','POST_STATUS',['item'=>hash('sha256',(string)($post->ID??'')),'from'=>self::code($old),'to'=>self::code($new)]);
        }catch(Throwable $ignored){}
    }
    /** WP post actions are observable even if a separate worker creates a draft; not a K0 internal trace. */
    public static function postWritten($postId,$post,$update,$postBefore): void {
        try{
            if(!is_object($post)||($post->post_type??'')!=='post')return;
            self::event('WORDPRESS_ARTICLE','POST_SAVED',[
                'post'=>substr(hash('sha256',(string)$postId),0,24),
                'update'=>(bool)$update,'status'=>self::code($post->post_status??''),
                'origin'=>'WORDPRESS_ONLY_NOT_K0_INTERNAL'
            ]);
        }catch(Throwable $ignored){}
    }
    public static function createdTerm($termId,$ttId,$taxonomy):void {self::termChange('CREATED',$termId,$taxonomy);}
    public static function editedTerm($termId,$ttId,$taxonomy):void {self::termChange('EDITED',$termId,$taxonomy);}
    public static function deletedTerm($termId,$ttId,$taxonomy,$deletedTerm,$objectIds):void {self::termChange('DELETED',$termId,$taxonomy);}
    private static function termChange(string $action,$termId,$taxonomy):void {
        if($taxonomy!=='category')return;
        self::event('WORDPRESS_CATEGORY',$action,['category'=>substr(hash('sha256',(string)$termId),0,24)]);
    }
    public static function postCategoryAssigned($postId,$terms,$termTaxonomyIds,$taxonomy,$append,$oldTermTaxonomyIds):void {
        try{
            if($taxonomy!=='category')return;
            self::event('ARTICLE_CATEGORY','ASSIGNED',['post'=>substr(hash('sha256',(string)$postId),0,24),
              'category_count'=>count(is_array($termTaxonomyIds)?$termTaxonomyIds:[])]);
        }catch(Throwable $ignored){}
    }
    /** Only the actual research service domains; no credentials, endpoint or request payload. */
    public static function providerHttp($response,$context,$class,$args,$url):void {
        if($context!=='response')return;
        try{
            $host=strtolower((string)parse_url((string)$url,PHP_URL_HOST));
            $provider='';
            if($host==='api.dataforseo.com'||str_ends_with($host,'.dataforseo.com'))$provider='DATAFORSEO';
            elseif($host==='searchconsole.googleapis.com'||$host==='www.googleapis.com'||$host==='oauth2.googleapis.com')$provider='GOOGLE_SEARCH_CONSOLE';
            if($provider==='')return;
            $error=function_exists('is_wp_error')&&is_wp_error($response);
            $code=$error?0:(function_exists('wp_remote_retrieve_response_code')?(int)wp_remote_retrieve_response_code($response):0);
            self::event('KEYWORD_SOURCE','HTTP_RESPONSE',['provider'=>$provider,'http_status'=>$code,'transport_error'=>$error]);
        }catch(Throwable $ignored){}
    }
    /** PSERC directly writes its index table; query filter sees ATTEMPTS, not commit success. */
    public static function compilerSqlAttempt($sql) {
        try{
            if(is_string($sql)&&preg_match('/^\s*(?:INSERT|UPDATE|REPLACE|DELETE)\b/i',$sql)
               &&preg_match('/^\s*(?:INSERT(?:\s+IGNORE)?\s+INTO|REPLACE\s+INTO|UPDATE|DELETE\s+FROM)\s+`?[a-z0-9_]*pserc_[a-z0-9_]+`?/i',$sql)){
                preg_match('/^\s*(INSERT|UPDATE|REPLACE|DELETE)/i',$sql,$m);
                self::event('PSERC_DB_SQL','ATTEMPT_UNVERIFIED',['operation'=>self::code($m[1]??'WRITE')]);
            }
        }catch(Throwable $ignored){}
        return $sql;
    }
    /** Optional cross-plugin bridge; only explicit status/reason codes, no raw data. */
    public static function externalStageEvidence($stage,$event,$meta=[]):void {
        try{
            if(!is_string($stage)||!is_string($event))return;
            $safe=[];
            foreach(['status','reason_code','error_code','processed','total','ready_count','held_count'] as $k){
                if(is_array($meta)&&isset($meta[$k])&&is_scalar($meta[$k]))$safe[$k]=is_numeric($meta[$k])?(int)$meta[$k]:self::code($meta[$k]);
            }
            self::event('EXTERNAL_'.self::code($stage),$event,$safe);
        }catch(Throwable $ignored){}
    }
    public static function observe(string $key,$value,string $change): void {
        try{
            if(self::$flushing||str_starts_with($key,'pste_flight_')||$key==='pste_automatic_protocol_v1')return;
            $group=self::stage($key);
            if($group==='')return;
            $isRecord=$group==='PSERC_RECORD';
            $value=is_array($value)?$value:[];
            $payload=$isRecord&&is_array($value['payload']??null)?$value['payload']:$value;
            $event=['option_kind'=>$isRecord?'COMPILER_RECORD':$key,'change'=>$change];
            $keys=['status','phase','stage','reason','error_code','last_error','completion_reason','context_state','topic_role','planning_suitability','automatic_pool_status','manual_status','primary_status','decision','category_id','article_type','processed','total','cursor_id','local_backlog_processed','local_backlog_total','local_backlog_title_candidates','usable_candidate_count','eligible_count','candidate_index','ready_count','prepared_count','held_count','topic_count','planning_topic_count_expected','saved','reviewed','generation','run_uuid','job_uuid'];
            foreach($keys as $k){
                if(!isset($payload[$k])||!is_scalar($payload[$k]))continue;
                if(is_int($payload[$k])||is_float($payload[$k]))$event[$k]=$payload[$k];
                else if(is_bool($payload[$k]))$event[$k]=$payload[$k];
                else if(in_array($k,['generation','run_uuid','job_uuid'],true))$event[$k]=substr(hash('sha256',(string)$payload[$k]),0,20);
                else $event[$k]=self::code($payload[$k]);
            }
            if($isRecord){
                $event['record_kind']=self::recordKind($key);
                foreach(['pool_key','topic_key','candidate_id','plan_slot','source_key'] as $k){if(isset($payload[$k])&&is_scalar($payload[$k])){$event['item']=substr(hash('sha256',(string)$payload[$k]),0,24);break;}}
            }
            $reasons=self::reasons($payload);
            if($reasons)$event['reason_codes']=$reasons;
            self::event($group,'PERSISTED',$event);
        }catch(Throwable $ignored){}
    }
    private static function stage(string $key): string {
        $map=[
          'pste_context_refresh_job_v1'=>'PORTAL_CONTEXT',
          'pste_site_baseline_v1'=>'PORTAL_STRUCTURE',
          'pste_active_longtail_research_job_v2'=>'KEYWORD_RESEARCH',
          'pste_research_driver_state_v1'=>'KEYWORD_RESEARCH',
          'pste_breadth_research_queue_v1'=>'EXISTING_AUDIT',
          'pste_retained_backlog_audit_v1'=>'EXISTING_AUDIT',
          'pste_existing_evidence_bootstrap_v1'=>'EXISTING_AUDIT',
          'pste_semantic_review_sandbox_v1'=>'SEO_REVIEW',
          'pste_title_desk_reentry_state_v1'=>'TITLE_WORKSHOP',
          'pste_editorial_plan_import_v1'=>'EDITORIAL_PLAN_IMPORT',
          'pste_boot_status_v1'=>'SYSTEM_BOOT',
          'pste_safe_migration_job_v2'=>'SYSTEM_BOOT',
          'pserc_plan_compile_job_v1'=>'PSERC_COMPILER',
          'pserc_plan_active_snapshot_v1'=>'PSERC_ACTIVATION',
        ];
        if(isset($map[$key]))return $map[$key];
        if(preg_match('/^pserc_plan_[a-f0-9]{20}_[a-z0-9_]+_[a-f0-9]{6,40}$/',$key))return 'PSERC_RECORD';
        // Record future state changes from previously unlisted workflow options too, without recording raw values.
        if(preg_match('/^(?:pste|pserc)_/',$key) && !preg_match('/credential|secret|password|oauth|access_token|refresh_token|private_key|api_key/i',$key))return 'OTHER_WORKFLOW_STATE';
        return '';
    }
    private static function recordKind(string $key): string {
        return preg_match('/^pserc_plan_[a-f0-9]{20}_([a-z0-9_]+)_[a-f0-9]{6,40}$/',$key,$m)?self::code($m[1]):'UNKNOWN';
    }
    private static function code($v): string {
        $s=strtoupper((string)$v);
        return substr(trim((string)preg_replace('/[^A-Z0-9_:\-]/','_',$s),'_'),0,120);
    }
    private static function reasons(array $source): array {
        $out=[];
        foreach(['reason_codes','reasons','blocking_codes','failure_reasons'] as $k){
            $raw=$source[$k]??[];
            if(is_string($raw))$raw=json_decode($raw,true)?:[];
            foreach(is_array($raw)?$raw:[] as $v){if(is_scalar($v)&&count($out)<12){$code=self::code($v);if($code!=='')$out[$code]=$code;}}
        }
        foreach(['normal_metadata_path','planning_readiness_gate','technical_strand_report','editorial_strand_report','editorial_outcome_gate','topic','portal_context','editorialization','metadata_gate','category_gate','semantic_duplicate_gate','title_gate_initial'] as $k){
            if(is_array($source[$k]??null))foreach(self::reasonsFlat($source[$k]) as $code){if(count($out)<12)$out[$code]=$code;}
        }
        foreach(['reason_code','error_code'] as $k){if(isset($source[$k])&&is_scalar($source[$k])){$c=self::code($source[$k]);if($c!=='')$out[$c]=$c;}}
        return array_slice(array_values($out),0,12);
    }
    private static function reasonsFlat(array $v): array {
        $out=[];foreach(['reason_codes','blocking_codes','reasons'] as $k)foreach(is_array($v[$k]??null)?$v[$k]:[] as $x){if(is_scalar($x)){$c=self::code($x);if($c!=='')$out[$c]=$c;}}
        return array_slice(array_values($out),0,12);
    }
    /** Called by existing PSTE database write guard only on successful writes. */
    public static function databaseWrite(string $operation,string $table,array $data,array $where,int $affected,string $writeCode): void {
        try{
            if($affected<=0){$k=self::code($writeCode);self::$zeroRowSummary[$k]=(self::$zeroRowSummary[$k]??0)+1;return;}
            $kind='';
            if(str_ends_with($table,'pste_topic_pool'))$kind='TOPIC_DECISION';
            elseif(str_ends_with($table,'pste_topic_assignments'))$kind='CATEGORY_ASSIGNMENT';
            elseif(str_ends_with($table,'pste_topic_history'))$kind='TOPIC_HISTORY';
            elseif(str_ends_with($table,'pste_candidates'))$kind='KEYWORD_CANDIDATE';
            if($kind==='')return;
            $e=['operation'=>self::code($operation),'write_code'=>self::code($writeCode),'affected'=>$affected,'transaction_commit_not_verified'=>true];
            foreach(['pool_key','topic_key','candidate_id','assignment_key','id'] as $key){if(isset($where[$key])||isset($data[$key])){$e['item']=substr(hash('sha256',(string)($where[$key]??$data[$key])),0,24);break;}}
            foreach(['automatic_pool_status','context_state','planning_suitability','topic_role','manual_status','assignment_status','action','from_status','to_status','article_type','current_category_id','category_id','automatic_decision','assignment_status','manual_article_type'] as $k){if(isset($data[$k])&&is_scalar($data[$k]))$e[$k]=is_numeric($data[$k])?(int)$data[$k]:self::code($data[$k]);}
            $reasons=[];
            foreach(['reason_codes_json','payload_json','details_json'] as $k){if(!isset($data[$k])||!is_string($data[$k]))continue;$p=json_decode($data[$k],true);if(is_array($p))$reasons=array_merge($reasons,self::reasons($p));}
            if($reasons)$e['reason_codes']=array_slice(array_values(array_unique($reasons)),0,12);
            elseif($kind==='TOPIC_DECISION'&&array_intersect(['BLOCKED','NO','RESEARCH_KEYWORD','ALREADY_COVERED'],array_values(array_intersect_key($e,array_flip(['planning_suitability','topic_role'])))))$e['reason_missing_in_written_fields']=true;
            if(isset($data['last_run_uuid'])&&is_scalar($data['last_run_uuid']))$e['run']=substr(hash('sha256',(string)$data['last_run_uuid']),0,20);
            if($kind==='TOPIC_DECISION'&&$operation==='INSERT')self::event('NEW_KEYWORD','PERSISTED',$e);
            self::event($kind,'PERSISTED',$e);
        }catch(Throwable $ignored){}
    }
    /** Compact state matrix before/after a direct topic-pool UPDATE/DELETE, never full topic payloads. */
    public static function beforeMassQuery(string $sql):?array {
        if(!preg_match('/^\s*(?:UPDATE|DELETE\s+FROM)\b/i',$sql)||stripos($sql,'pste_topic_pool')===false)return null;
        return self::stateMatrix();
    }
    private static function stateMatrix():array {
        global $wpdb;
        try{
            $table=PSTE_Repository::table('topic_pool');
            $sql="SELECT context_state,topic_role,planning_suitability,automatic_pool_status,COUNT(*) AS n FROM $table GROUP BY context_state,topic_role,planning_suitability,automatic_pool_status ORDER BY n DESC";
            $rows=$wpdb->get_results($sql,ARRAY_A);
            if(!is_array($rows))return ['read_error'=>'MASS_STATE_MATRIX_UNAVAILABLE'];
            $groups=[];$total=0;
            foreach($rows as $r){$n=(int)($r['n']??0);$total+=$n;if(count($groups)<60)$groups[]=[self::code($r['context_state']??''),self::code($r['topic_role']??''),self::code($r['planning_suitability']??''),self::code($r['automatic_pool_status']??''),$n];}
            return ['topics'=>$total,'group_count'=>count($rows),'groups'=>$groups,'truncated'=>count($rows)>60];
        }catch(Throwable $ignored){return ['read_error'=>'MASS_STATE_MATRIX_FAILED'];}
    }
    public static function rawQuery(string $code,string $sql,int $affected,?array $before=null):void {
        if(!preg_match('/^\s*(?:UPDATE|DELETE|INSERT|REPLACE|ALTER|DROP)\b/i',$sql))return;
        self::event('DIRECT_SQL_WRITE','SQL_APPLIED',[
            'write_code'=>self::code($code),'affected'=>$affected,'transaction_commit_not_verified'=>true]);
        if($before!==null)self::event('TOPIC_MASS_CHANGE','BEFORE_AFTER',[
            'write_code'=>self::code($code),'affected'=>$affected,'before'=>$before,'after'=>self::stateMatrix(),
            'commit_verified'=>false
        ]);
    }
    public static function massFailure(string $code,?array $before):void {
        if($before===null)return;
        self::event('TOPIC_MASS_CHANGE','FAILED',['write_code'=>self::code($code),'before'=>$before]);
    }
    public static function transaction(string $kind,string $writeCode): void {self::event('DB_TRANSACTION',self::code($kind),['write_code'=>self::code($writeCode)]);}
    public static function databaseFailure(string $kind,string $writeCode): void {self::event('DATABASE_WRITE','FAILED',['operation'=>self::code($kind),'write_code'=>self::code($writeCode)]);}
    public static function handoff(int $items,string $kind): void {self::event('METADATA_HANDOFF','EXPORTED',['item_count'=>$items,'kind'=>self::code($kind)]);}
    public static function event(string $stage,string $action,array $meta=[]): void {
        try{
            if(self::$flushing)return;
            if(self::$requestId==='')self::$requestId=substr(hash('sha256',microtime(true).'|'.(function_exists('wp_generate_uuid4')?wp_generate_uuid4():uniqid('',true))),0,16);
            $row=['at_utc'=>gmdate('c'),'request_id'=>self::$requestId,'request_sequence'=>++self::$sequence,'stage'=>self::code($stage),'event'=>self::code($action),'meta'=>$meta];
            // Never suppress an actual repeated write: repeated mass resets must be visible.
            self::$buffer[]=$row;
            // Save bounded memory even on long single-request operations.
            if(count(self::$buffer)>=150)self::flush();
        }catch(Throwable $ignored){}
    }
    private static function flush(): void {
        if(self::$flushing||!self::$buffer)return;
        self::$flushing=true;
        try{
            $batch=['contract'=>'PSTE_FLIGHT_BATCH_V2','version'=>defined('PSTE_VERSION')?PSTE_VERSION:'',
                'at_utc'=>gmdate('c'),'events'=>self::$buffer];
            $id=gmdate('Ymd_His').'_'.substr(hash('sha256',microtime(true).'|'.getmypid().'|'.(function_exists('wp_generate_uuid4')?wp_generate_uuid4():uniqid('',true))),0,22);
            // Atomic insert; each request uses a fresh name, no lost updates from concurrent workers.
            if(add_option(self::PREFIX.$id,$batch,'',false))self::$buffer=[];
            else if(function_exists('error_log'))error_log('PSTE_FLIGHT_WRITE_FAILED: workflow evidence batch not persisted');
        }catch(Throwable $ignored){}
        finally {self::$flushing=false;}
    }
    public static function finish(): void {
        try{
            foreach(self::$zeroRowSummary as $why=>$n){self::event('DATABASE_WRITE','NO_ROWS_CHANGED',['write_code'=>$why,'attempt_count'=>$n]);}
            self::$zeroRowSummary=[];
            if(function_exists('current_user_can')&&current_user_can('manage_options')){
                $action=isset($_REQUEST['action'])&&is_string($_REQUEST['action'])?(string)$_REQUEST['action']:'';
                if(!in_array($action,['pste_evidence_read_batch','pste_evidence_history_batch'],true)&&preg_match('/^(pste_|pserc_)[a-z0-9_]{2,70}$/',$action)&&!str_contains($action,'credential')&&!str_contains($action,'secret'))
                    self::event('ADMIN_OPERATION','REQUEST_END',['action'=>self::code($action),'http_status'=>function_exists('http_response_code')?http_response_code():0]);
            }
            self::flush();
        }catch(Throwable $ignored){}
    }
    /** Entire lifetime summary in bounded indexed pages: no 150MB file, no re-evaluation. */
    public static function historySummaryBatch(string $cursor='',string $ceiling=''):array {
        global $wpdb;
        $like=$wpdb->esc_like(self::PREFIX).'%';
        if($ceiling===''){
            $ceiling=(string)$wpdb->get_var($wpdb->prepare("SELECT MAX(option_name) FROM {$wpdb->options} WHERE option_name LIKE %s",$like));
        }
        if($ceiling===''||!str_starts_with($ceiling,self::PREFIX))return ['contract'=>'PSTE_FLIGHT_HISTORY_PAGE_V1','done'=>true,'cursor'=>'','ceiling'=>'','batches'=>0,'events'=>0,'groups'=>[],'errors'=>[],'reasons'=>[],'mass_changes'=>[]];
        if($cursor!==''&&!str_starts_with($cursor,self::PREFIX))throw new RuntimeException('PSTE_FLIGHT_CURSOR_INVALID');
        if(strcmp($cursor,$ceiling)>0)throw new RuntimeException('PSTE_FLIGHT_CURSOR_AFTER_CEILING');
        $sql=$wpdb->prepare("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name > %s AND option_name <= %s ORDER BY option_name ASC LIMIT ".self::HISTORY_PAGE_SIZE,$like,$cursor,$ceiling);
        $rows=$wpdb->get_results($sql,ARRAY_A);
        if(!is_array($rows))throw new RuntimeException('PSTE_FLIGHT_HISTORY_BATCH_READ_FAILED');
        $groups=[];$errors=[];$reasons=[];$mass=[];$count=0;$batches=0;$invalid=0;$next=$cursor;
        foreach($rows as $r){
            $next=(string)($r['option_name']??'');
            $batch=maybe_unserialize($r['option_value']??'');
            if(!is_array($batch)||($batch['contract']??'')!=='PSTE_FLIGHT_BATCH_V2'){$invalid++;continue;}
            $batches++;
            foreach((array)($batch['events']??[]) as $ev){
                if(!is_array($ev))continue;
                $count++;$stage=self::code($ev['stage']??'');$action=self::code($ev['event']??'');
                $key=$stage.' / '.$action;$groups[$key]=($groups[$key]??0)+1;
                $meta=is_array($ev['meta']??null)?$ev['meta']:[];
                foreach(['error_code','reason_code'] as $field){if(!empty($meta[$field])&&is_scalar($meta[$field])){$v=self::code($meta[$field]);$errors[$v]=($errors[$v]??0)+1;}}
                foreach(is_array($meta['reason_codes']??null)?$meta['reason_codes']:[] as $v){if(!is_scalar($v))continue;$reason=self::code($v);if($reason!=='')$reasons[$reason]=($reasons[$reason]??0)+1;}
                if($stage==='TOPIC_MASS_CHANGE'&&count($mass)<12){
                    $mass[]=['at_utc'=>(string)($ev['at_utc']??''),'result'=>$action,
                        'write_code'=>self::code($meta['write_code']??''),'affected'=>(int)($meta['affected']??0),
                        'before'=>$meta['before']??null,'after'=>$meta['after']??null];
                }
            }
        }
        return ['contract'=>'PSTE_FLIGHT_HISTORY_PAGE_V1','read_only'=>true,
            'cursor'=>$next,'ceiling'=>$ceiling,'done'=>count($rows)<self::HISTORY_PAGE_SIZE||$next===$ceiling,
            'batches'=>$batches,'invalid_batches'=>$invalid,'events'=>$count,'groups'=>$groups,'errors'=>$errors,'reasons'=>$reasons,'mass_changes'=>$mass];
    }

    /** Read-only: bounded last batches. Full history is retained as separate batches. */
    public static function report(int $maxBatches=40): array {
        global $wpdb;
        $limit=max(1,min(150,$maxBatches));$like=$wpdb->esc_like(self::PREFIX).'%';
        $sql=$wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name DESC LIMIT %d",$like,$limit);
        $rows=$wpdb->get_col($sql);
        $events=[];$batches=0;
        foreach(array_reverse(is_array($rows)?$rows:[]) as $raw){
            $batch=maybe_unserialize($raw);
            if(!is_array($batch)||($batch['contract']??'')!=='PSTE_FLIGHT_BATCH_V2')continue;
            $batches++;foreach((array)($batch['events']??[]) as $e)if(is_array($e))$events[]=$e;
        }
        $summary=[];
        foreach($events as $e){$s=(string)($e['stage']??'');$ev=(string)($e['event']??'');$k=$s.' / '.$ev;$summary[$k]=($summary[$k]??0)+1;}
        arsort($summary);
        $snapshot=['read_only'=>true];
        try{$snapshot['forensic_evidence']=PSTE_Forensic_Diagnostics::current();}
        catch(Throwable $e){$snapshot['forensic_error_code']='PSTE_FORENSIC_READ_FAILED';}
        try{$snapshot['topic_status_groups']=PSTE_Repository::automaticProtocolStatusMatrix();$snapshot['topic_counts']=PSTE_Repository::productionCandidateStats();}
        catch(Throwable $ignored){$snapshot['error_code']='PSTE_STORED_STATUS_READ_FAILED';}
        try{$job=get_option('pserc_plan_compile_job_v1',[]);$job=is_array($job)?$job:[];$snapshot['compiler']=['status'=>self::code($job['status']??''),'phase'=>self::code($job['phase']??''),'eligible_count'=>(int)($job['eligible_count']??0),'ready_count'=>(int)($job['ready_count']??0),'error_code'=>self::code($job['error_code']??'')];}catch(Throwable $ignored){}
        return ['contract'=>'PSTE_FLIGHT_REPORT_V2','generated_at_utc'=>gmdate('c'),'pste_version'=>PSTE_VERSION,
            'read_only'=>true,'history_since_install_only'=>true,'scope'=>'LATEST_STORED_BATCHES_NOT_PURGED','complete_historical_trace'=>false,
            'max_batches_in_report'=>$limit,'batches_in_report'=>$batches,'event_count'=>count($events),
            'grouped_event_counts'=>$summary,'stored_current_state'=>$snapshot,'events'=>$events,
            'coverage'=>['keyword_research'=>'PSTE_OPTION_CHANGES','portal_structure_and_context'=>'PSTE_OPTIONS_AND_SQL','topic_decisions'=>'PSTE_PERSISTED_WRITES',
                'category_assignment'=>'PERSISTED_WRITES','title_workshop'=>'PERSISTED_STATE_AND_REQUESTS',
                'editorial_compiler'=>'PSERC_OPTION_STATE_AND_RECORDS','metadata_handoff'=>'EXPORT_EVENT',
                'external_k0_internal_steps'=>'NOT_OBSERVABLE_WITHOUT_K0_HOOK','wordpress_post_writes'=>'POST_INSERT_AND_POST_TRANSITIONS','future_new_keywords'=>'PSTE_DB_INSERT_AND_OPTION_WRITES','mass_topic_mutation'=>'BEFORE_AFTER_STATUS_MATRIX','provider_http'=>'WORDPRESS_HTTP_TRANSPORT','compiler_sql'=>'ATTEMPT_ONLY_NOT_COMMIT_VERIFIED','wordpress_categories'=>'TERM_HOOKS']];
    }
}
