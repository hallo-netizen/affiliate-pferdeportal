<?php
if (!defined('ABSPATH')) { return; }
/**
 * Forensic evidence for the 5,016 historical topics. Read only, independent of
 * evaluator, planner and external providers. Counts actual persisted SQL columns
 * and timestamps; never changes a reason or replays a workflow step.
 */
final class PSTE_Forensic_Diagnostics {
    private static function error($wpdb,string $code): void {
        if((string)($wpdb->last_error??'')!=='')throw new RuntimeException($code);
    }
    private static function statusCode($value): string {
        return substr((string)preg_replace('/[^A-Z0-9_:-]/','_',strtoupper((string)$value)),0,100);
    }
    private static function statusFields($value,array $allowed): array {
        $out=[];if(!is_array($value))return $out;
        foreach($allowed as $k){if(!array_key_exists($k,$value))continue;
            $v=$value[$k];if(is_int($v)||is_bool($v)||is_float($v))$out[$k]=$v;
            elseif(is_string($v))$out[$k]=substr($v,0,110);
        }return $out;
    }
    public static function current(): array {
        global $wpdb;
        $table=PSTE_Repository::table('topic_pool');
        $hist=PSTE_Repository::table('topic_history');
        // No payload_json, no topic text; only persisted authority columns.
        $sql="SELECT context_state, COUNT(*) AS total,
          SUM(CASE WHEN planning_suitability='YES' THEN 1 ELSE 0 END) AS yes,
          SUM(CASE WHEN planning_suitability<>'YES' THEN 1 ELSE 0 END) AS not_yes,
          SUM(CASE WHEN context_synced_at IS NULL THEN 1 ELSE 0 END) AS never_synced,
          SUM(CASE WHEN current_category_id=0 THEN 1 ELSE 0 END) AS category_id_zero,
          MIN(context_synced_at) AS first_context_synced,
          MAX(context_synced_at) AS last_context_synced,
          MIN(last_seen_at) AS first_topic_seen,
          MAX(last_seen_at) AS last_topic_seen
          FROM $table GROUP BY context_state ORDER BY total DESC";
        $context=$wpdb->get_results($sql,ARRAY_A);self::error($wpdb,'PSTE_FORENSIC_CONTEXT_GROUP_FAILED');
        if(!is_array($context))throw new RuntimeException('PSTE_FORENSIC_CONTEXT_GROUP_FAILED');
        $contextGroups=[];$sum=0;
        foreach($context as $row){$n=(int)($row['total']??0);$sum+=$n;
            $contextGroups[]=['state'=>self::statusCode($row['context_state']??''),'topics'=>$n,
                'planning_yes'=>(int)($row['yes']??0),'planning_not_yes'=>(int)($row['not_yes']??0),
                'synced_at_missing'=>(int)($row['never_synced']??0),'category_id_zero'=>(int)($row['category_id_zero']??0),
                'first_context_synced'=>$row['first_context_synced']??null,
                'last_context_synced'=>$row['last_context_synced']??null,
                'first_topic_seen'=>$row['first_topic_seen']??null,'last_topic_seen'=>$row['last_topic_seen']??null];
        }
        // This is an independent reconciliation of the dashboard's 4,234 count.
        $open=0;foreach($contextGroups as $g)if(!in_array($g['state'],['CURRENT','NOT_REQUIRED'],true))$open+=(int)$g['topics'];
        $sql2="SELECT action, from_status, to_status, COUNT(*) AS total, MIN(created_at) AS first_at, MAX(created_at) AS last_at
          FROM $hist GROUP BY action,from_status,to_status ORDER BY total DESC LIMIT 120";
        $history=$wpdb->get_results($sql2,ARRAY_A);self::error($wpdb,'PSTE_FORENSIC_HISTORY_GROUP_FAILED');
        $historyGroups=[];
        foreach(is_array($history)?$history:[] as $r){$historyGroups[]=[
            'action'=>self::statusCode($r['action']??''),'from'=>self::statusCode($r['from_status']??''),
            'to'=>self::statusCode($r['to_status']??''),'count'=>(int)($r['total']??0),
            'first_at'=>$r['first_at']??null,'last_at'=>$r['last_at']??null];}
        $contextJob=[];$audit=[];
        try{$contextJob=self::statusFields(PSTE_Context_Refresh::status(),['status','phase','processed','total','completed_at_utc','updated_at_utc','started_at_utc','error_code','reason','structure_sha256']);}catch(Throwable $ignored){$contextJob=['read_error'=>'CONTEXT_JOB_UNAVAILABLE'];}
        try{$audit=self::statusFields(PSTE_Breadth_Research_Queue::peek(),['status','local_backlog_processed','local_backlog_total','usable_candidate_count','local_backlog_title_candidates','completion_reason','updated_at_utc','last_error','recheck_reason']);}catch(Throwable $ignored){$audit=['read_error'=>'EXISTING_AUDIT_UNAVAILABLE'];}
        return ['contract'=>'PSTE_FORENSIC_CURRENT_STATES_V1','read_only'=>true,
            'sources'=>['pste_topic_pool_context_state','pste_topic_history','context_refresh_job','existing_audit'],
            'topic_total'=>$sum,'context_not_current_or_not_required'=>$open,
            'context_groups'=>$contextGroups,'context_job'=>$contextJob,'existing_audit'=>$audit,
            'history_groups_top_120'=>$historyGroups,
            'classification_rule'=>"context_state NOT IN ('CURRENT','NOT_REQUIRED')",
            'proof_limitations'=>[
              'The 4,234 context-open topics are current database column values, not proof of why they were changed.',
              'Earlier mass updates are not recoverable as events unless contemporaneous logging existed.',
              'History table includes recorded actions only; missing historical actions cannot be inferred.',
              'New flight-recorder events are prospective; content production inside external K0 is not observable here.'
            ]];
    }
}
