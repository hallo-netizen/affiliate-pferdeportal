<?php
if (!defined('ABSPATH')) { return; }

/** Portal-internal duplicate, keyword-ownership and category-head protection. No SERP comparison. */
final class PSTE_Cannibalization {
    public const OWNERSHIP_CONTRACT='PSTE_KEYWORD_OWNERSHIP_LONGTAIL_V2_SEO_TOOL_ONLY';

    public static function decide(array $candidate,array $inventoryItems,array $categoryItems,array $unusedCalibration=[]): array {
        $reasons=[];$decision='PASS';$matches=[];
        $query=PSTE_Normal_Metadata_Path::canonicalInputQuery(PSTE_Editorializer::sourceQuery($candidate));
        $sourceQuery=$query;
        $approvedTitle=PSTE_Editorializer::displayTitle($candidate);
        $categoryName=(string)($candidate['target_category_name']??'');
        $categorySlug=(string)($candidate['target_category_slug']??'');
        $articleType=(string)($candidate['proposed_article_type']??'');
        $queryNorm=PSTE_Normalizer::exactTopicIdentityText($query);
        $headNorm=PSTE_Normalizer::exactTopicIdentityText(PSTE_Normalizer::categoryFamilyName($categoryName));
        $familyKey=(string)($candidate['topic_family_key']??PSTE_Normalizer::categoryFamilyKey($categoryName));
        $familyName=(string)($candidate['topic_family_name']??PSTE_Normalizer::categoryFamilyName($categoryName));
        $sources=array_values(array_unique(array_filter(array_map(static fn($e)=>(string)($e['source']??''),(array)($candidate['evidence']??[])))));

        if(!$sources)return ['decision'=>'BLOCKED','reason_codes'=>['SOURCE_PROVENANCE_MISSING'],'matches'=>[]];
        if($queryNorm===''||$queryNorm===$headNorm)return ['decision'=>'BLOCKED','reason_codes'=>['CATEGORY_HEAD_INTENT_COLLISION'],'matches'=>[]];
        if(PSTE_Normalizer::staleYear($sourceQuery)!==null)return ['decision'=>'BLOCKED','reason_codes'=>['STALE_YEAR_SPECIFIC_QUERY'],'matches'=>[]];
        if(self::pureTransactional($sourceQuery))return ['decision'=>'BLOCKED','reason_codes'=>['NON_EDITORIAL_TRANSACTIONAL_QUERY'],'matches'=>[]];
        if(empty($candidate['editorialization']['resolved'])){
            $reason=(string)($candidate['editorialization']['reason']??'EDITORIAL_TITLE_UNRESOLVED');
            return ['decision'=>'BLOCKED','reason_codes'=>[$reason],'matches'=>[]];
        }
        if($articleType==='FAQ'&&!PSTE_Normalizer::isQuestion($approvedTitle))return ['decision'=>'BLOCKED','reason_codes'=>['FAQ_NON_QUESTION_DISCOVERY_TERM'],'matches'=>[]];
        if(!in_array($articleType,['FAQ','Journal'],true)&&PSTE_Normalizer::isQuestion($approvedTitle))return ['decision'=>'BLOCKED','reason_codes'=>['QUESTION_TITLE_NOT_FAQ'],'matches'=>[]];

        foreach($inventoryItems as $item){
            if(!in_array((string)($item['status']??''),['publish','draft'],true))continue;
            $title=trim((string)($item['title']??''));if($title==='')continue;
            $itemCategory=(string)($item['category_name']??'');
            $itemFamily=(string)($item['topic_family_key']??PSTE_Normalizer::categoryFamilyKey($itemCategory));
            $sameFamily=$familyKey!==''&&$itemFamily!==''&&hash_equals($familyKey,$itemFamily);

            // Rootfix 0.56.16: target-keyword ownership is checked independently from title wording.
            // A different generator phrase can never create a second right to the same broad keyword scope.
            $ownership=self::keywordOwnershipCompare($sourceQuery,$familyName,$familyKey,$articleType,$categorySlug,$item);
            if(($ownership['decision']??'PASS')!=='PASS'){
                // Unknown ownership is not a proven duplicate. Retain the topic
                // for a distinct search-intent proposal; never send it to K0.
                if(($ownership['decision']??'')==='REVIEW_REQUIRED'){
                    if($decision!=='BLOCKED')$decision='REVIEW_REQUIRED';
                }else $decision='BLOCKED';
                $reasons=array_merge($reasons,(array)($ownership['reason_codes']??[]));
                $matches[]=[
                    'post_id'=>(int)($item['post_id']??0),'title'=>$title,'category_name'=>$itemCategory,
                    'matched_field'=>'KEYWORD_OWNERSHIP','matched_text'=>$title,'intent_similarity'=>0.0,
                    'answer_equivalence'=>false,'same_topic_family'=>true,'context_only'=>false,
                    'source'=>(string)($item['source']??'WORDPRESS'),'keyword_ownership'=>$ownership,
                ];
                continue;
            }

            $fields=[['type'=>'TITLE','text'=>$title]];
            foreach((array)($item['headings']??[]) as $heading){$heading=trim((string)$heading);if($heading!=='')$fields[]=['type'=>'HEADING','text'=>$heading];}
            $best=0.0;$bestField='TITLE';$bestText=$title;$equivalent=false;$exact=false;
            foreach($fields as $field){
                $text=(string)$field['text'];$sim=PSTE_Normalizer::similarity($query,$text);
                $isExact=PSTE_Normalizer::exactTopicIdentityText($query)===PSTE_Normalizer::exactTopicIdentityText($text);
                $isEquivalent=PSTE_Normalizer::answerEquivalent($query,$text,PSTE_Normalizer::categoryFamilyName($categoryName),PSTE_Normalizer::categoryFamilyName($itemCategory));
                if($sim>$best){$best=$sim;$bestField=(string)$field['type'];$bestText=$text;}
                $exact=$exact||$isExact;$equivalent=$equivalent||$isEquivalent;
            }
            if($exact){$reasons[]='EXACT_NORMALIZED_QUERY_DUPLICATE';$decision='BLOCKED';}
            if($equivalent){$reasons[]='CROSS_TYPE_ANSWER_EQUIVALENCE';$decision='BLOCKED';}
            if(($candidate['intent_cluster_id']??'')!==''&&hash_equals((string)$candidate['intent_cluster_id'],(string)($item['intent_cluster_id']??''))){$reasons[]='SAME_INTENT_CLUSTER';$decision='BLOCKED';}
            if($best>=0.40||$equivalent||$sameFamily){
                $matches[]=[
                    'post_id'=>(int)($item['post_id']??0),'title'=>$title,'category_name'=>$itemCategory,
                    'matched_field'=>$bestField,'matched_text'=>$bestText,'intent_similarity'=>$best,
                    'answer_equivalence'=>$equivalent,'same_topic_family'=>$sameFamily,
                    'context_only'=>$sameFamily&&!$equivalent&&$best<0.40,'source'=>(string)($item['source']??'WORDPRESS'),
                ];
            }
        }
        usort($matches,static fn($a,$b)=>[(int)(($b['matched_field']??'')==='KEYWORD_OWNERSHIP'),(int)$b['answer_equivalence'],(float)$b['intent_similarity']]<=>[(int)(($a['matched_field']??'')==='KEYWORD_OWNERSHIP'),(int)$a['answer_equivalence'],(float)$a['intent_similarity']]);
        $matches=array_slice($matches,0,8);

        foreach($categoryItems as $category){
            if((int)($category['term_id']??0)===(int)($candidate['target_category_id']??0))continue;
            $otherHead=PSTE_Normalizer::exactTopicIdentityText((string)($category['topic_family_name']??$category['name']??''));
            if($otherHead!==''&&$queryNorm===$otherHead){$reasons[]='CATEGORY_HEAD_INTENT_COLLISION';$decision='BLOCKED';}
        }
        if(($candidate['metrics']['search_volume']??null)===0)$reasons[]='ZERO_REPORTED_SEARCH_VOLUME_NOT_AUTOMATICALLY_REJECTED';
        if(!$matches&&$decision==='PASS')$reasons[]='PORTAL_INTERNAL_TOPIC_FREE';
        elseif($matches&&$decision==='PASS')$reasons[]='PORTAL_INTERNAL_FAMILY_CONTEXT_CHECKED';
        return ['decision'=>$decision,'reason_codes'=>array_values(array_unique($reasons)),'matches'=>$matches];
    }

    /**
     * Deterministic keyword-ownership / longtail separation check.
     * Title phrasing is not ownership. A second same-family/same-type page is allowed only
     * when its source query contains a distinct, meaningful longtail discriminator.
     * @return array<string,mixed>
     */
    public static function keywordOwnershipCompare(string $query,string $familyName,string $familyKey,string $articleType,string $categorySlug,array $item): array {
        $title=trim((string)($item['title']??''));
        if($query===''||$title==='')return self::ownershipResult('PASS',[],[],[],false,false,$item,[],'UNKNOWN_LEGACY_NO_SEO_KEYWORD');
        $itemCategory=(string)($item['category_name']??'');$itemSlug=(string)($item['category_slug']??'');
        $itemType=(string)($item['article_type']??PSTE_Normalizer::categoryArticleType($itemCategory));
        $candidateType=PSTE_Article_Type_Registry::canonicalType($articleType);$existingType=PSTE_Article_Type_Registry::canonicalType($itemType);
        if($candidateType===''||$existingType===''||$candidateType!==$existingType)return self::ownershipResult('PASS',[],[],[],false,false,$item,[],'NOT_SAME_ARTICLE_TYPE');

        $itemFamilyName=trim((string)($item['topic_family_name']??PSTE_Normalizer::categoryFamilyName($itemCategory)));
        $itemFamilyKey=trim((string)($item['topic_family_key']??''));
        $candidateFamilyText=PSTE_Normalizer::text($familyName);$itemFamilyText=PSTE_Normalizer::text($itemFamilyName);
        $sameCategory=$categorySlug!==''&&$itemSlug!==''&&hash_equals($categorySlug,$itemSlug);
        $sameFamilyKey=$familyKey!==''&&$itemFamilyKey!==''&&hash_equals($familyKey,$itemFamilyKey);
        $sameFamilyText=$candidateFamilyText!==''&&$itemFamilyText!==''&&hash_equals($candidateFamilyText,$itemFamilyText);
        if(!$sameCategory&&!$sameFamilyKey&&!$sameFamilyText)return self::ownershipResult('PASS',[],[],[],false,false,$item,[],'NOT_SAME_FAMILY');

        $candidateTokens=self::ownershipTokens($query,$familyName,$candidateType);
        $existingKeyword=trim((string)($item['target_keyword']??$item['seo_target_keyword']??''));
        $existingAuthority=$existingKeyword!==''?'SEO_TOOL_EXPLICIT':'UNKNOWN_LEGACY_NO_SEO_KEYWORD';

        // An unlabelled legacy article cannot claim every longtail in its family.
        // Use the existing one-owner comparison: retain a broad or potentially
        // overlapping query, but let a query with a demonstrably different
        // source-keyword modifier proceed. A renamed title never establishes
        // that modifier and never supplies SEO keyword ownership.
        if($existingKeyword===''){
            $legacyTitleTokens=self::ownershipTokens($title,$itemFamilyName!==''?$itemFamilyName:$familyName,$existingType);
            $shared=array_intersect($candidateTokens,$legacyTitleTokens);
            $potentialSameRoot=false;
            foreach($candidateTokens as $candidateToken){
                if(strlen($candidateToken)<5)continue;
                foreach($legacyTitleTokens as $legacyToken){
                    if(strlen($legacyToken)>=5&&substr($candidateToken,0,4)===substr($legacyToken,0,4)){
                        $potentialSameRoot=true;break 2;
                    }
                }
            }
            $distinctSourceScope=$candidateTokens!==[]&&$shared===[]&&!$potentialSameRoot
                &&PSTE_Normalizer::similarity($query,$title)<0.40
                &&!PSTE_Normalizer::answerEquivalent($query,$title,$familyName,$itemFamilyName);
            if($distinctSourceScope){
                return self::ownershipResult('PASS',[],
                    $candidateTokens,$legacyTitleTokens,true,true,$item,[],$existingAuthority);
            }
            return self::ownershipResult('REVIEW_REQUIRED',
                ['EXISTING_SAME_FAMILY_SEO_INTENT_NOT_PROVEN'],
                $candidateTokens,$legacyTitleTokens,true,true,$item,
                array_values($shared),$existingAuthority);
        }

        $existingTokens=self::ownershipTokens($existingKeyword,$itemFamilyName!==''?$itemFamilyName:$familyName,$existingType);
        $inter=array_values(array_intersect($candidateTokens,$existingTokens));sort($inter,SORT_STRING);
        $candidateBroad=!$candidateTokens;$existingBroad=!$existingTokens;
        $decision='PASS';$reasons=[];

        if($candidateBroad&&$existingBroad){
            $decision='BLOCKED_DUPLICATE';$reasons[]='SAME_PRIMARY_KEYWORD_SCOPE_WITHOUT_DISTINCT_LONGTAIL';
        }elseif($candidateTokens&&$existingTokens&&$candidateTokens===$existingTokens){
            $decision='BLOCKED_DUPLICATE';$reasons[]='SAME_LONGTAIL_KEYWORD_SCOPE';
        }elseif($candidateBroad&&!$existingBroad){
            $decision='REVIEW_REQUIRED';$reasons[]='BROAD_SCOPE_OVERLAPS_EXISTING_SPECIFIC_LONGTAIL';
        }elseif($candidateTokens&&$existingTokens&&$inter){
            $small=min(count($candidateTokens),count($existingTokens));
            if(count($inter)===$small){$decision='REVIEW_REQUIRED';$reasons[]='LONGTAIL_SCOPE_CONTAINMENT_REVIEW_REQUIRED';}
            else{$decision='REVIEW_REQUIRED';$reasons[]='LONGTAIL_SCOPE_PARTIAL_OVERLAP_REVIEW_REQUIRED';}
        }
        return self::ownershipResult($decision,$reasons,$candidateTokens,$existingTokens,true,true,$item,$inter,$existingAuthority);
    }

    /** @return list<string> */
    private static function ownershipTokens(string $value,string $familyName,string $articleType): array {
        $family=array_fill_keys(PSTE_Normalizer::tokens($familyName),true);
        $generic=['pferd'=>true,'pferde'=>true,'auswahl'=>true,'achten'=>true,'eignung'=>true,'passend'=>true,'wisse'=>true,'wissen'=>true,'ueber'=>true,'find'=>true,'pruef'=>true,'kriterium'=>true,'kriteri'=>true,'ratgeb'=>true,'ratgeber'=>true];
        // These terms express the Beratung surface itself, not a separate search need.
        if(PSTE_Article_Type_Registry::canonicalType($articleType)!=='beratung')$generic=['pferd'=>true,'pferde'=>true];
        $out=[];foreach(PSTE_Normalizer::tokens($value) as $token){if(isset($family[$token])||isset($generic[$token]))continue;$out[$token]=true;}
        $out=array_keys($out);sort($out,SORT_STRING);return $out;
    }

    /** @return array<string,mixed> */
    private static function ownershipResult(string $decision,array $reasons,array $candidateTokens,array $existingTokens,bool $sameFamily,bool $sameType,array $item,array $intersection=[],string $existingAuthority='UNKNOWN_LEGACY_NO_SEO_KEYWORD'): array {
        return [
            'contract'=>self::OWNERSHIP_CONTRACT,'decision'=>$decision,'reason_codes'=>$reasons,
            'same_family'=>$sameFamily,'same_article_type'=>$sameType,
            'candidate_longtail_tokens'=>$candidateTokens,'existing_longtail_tokens'=>$existingTokens,'intersection'=>$intersection,
            'existing_keyword_authority'=>$existingAuthority,'title_surface_has_longtail_authority'=>false,
            'existing_post_id'=>(int)($item['post_id']??0),'existing_title'=>(string)($item['title']??''),
            'write_attempted'=>false,
        ];
    }

    private static function pureTransactional(string $query): bool {
        $transactional=(bool)preg_match('/\b(sale|angebot|angebote|rabatt|gutschein|coupon|shop|online\s+kaufen|bestellen)\b/iu',$query);
        $informational=(bool)preg_match('/\b(preis|preise|kosten|vergleich|test|pflege|reinigen|waschen|ratgeber)\b/iu',$query);
        return $transactional&&!$informational;
    }
}
