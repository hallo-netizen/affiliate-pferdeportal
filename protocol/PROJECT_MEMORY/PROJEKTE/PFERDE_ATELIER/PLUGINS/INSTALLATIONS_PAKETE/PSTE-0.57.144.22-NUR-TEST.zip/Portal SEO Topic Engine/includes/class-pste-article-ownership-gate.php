<?php
if (!defined('ABSPATH')) { return; }

/**
 * General read-only bridge from an upstream category/research ownership handoff to article planning.
 * It never creates categories, articles, titles or content. Question wording has zero ownership authority.
 */
final class PSTE_Article_Ownership_Gate {
    public const CONTRACT='PSTE_ARTICLE_OWNERSHIP_GATE_V1';
    public const SNAPSHOT_CONTRACT='PSTE_IMPORTED_EDITORIAL_OWNERSHIP_V1';
    public const UPSTREAM_CONTRACT='APKW_EDITORIAL_INTENT_OWNERSHIP_HANDOFF_V1';

    /** @return array<string,mixed>|null */
    public static function extractHandoff(array $decoded): ?array {
        if(($decoded['contract']??'')===self::UPSTREAM_CONTRACT)return $decoded;
        if(is_array($decoded['editorial_handoff']??null)&&(($decoded['editorial_handoff']['contract']??'')===self::UPSTREAM_CONTRACT))return (array)$decoded['editorial_handoff'];
        if(is_array($decoded['research_evidence']['editorial_handoff']??null)&&(($decoded['research_evidence']['editorial_handoff']['contract']??'')===self::UPSTREAM_CONTRACT))return (array)$decoded['research_evidence']['editorial_handoff'];
        return null;
    }

    /** @return array<string,mixed> */
    public static function normalizeHandoff(array $handoff): array {
        if(($handoff['contract']??'')!==self::UPSTREAM_CONTRACT)throw new RuntimeException('PSTE_UPSTREAM_EDITORIAL_OWNERSHIP_CONTRACT_INVALID');
        if(empty($handoff['valid'])||($handoff['status']??'')!=='READY_FOR_DOWNSTREAM_EDITORIAL_PLANNING')throw new RuntimeException('PSTE_UPSTREAM_EDITORIAL_OWNERSHIP_NOT_READY');

        $owners=[];
        foreach((array)($handoff['category_owner_registry']??[]) as $row){
            if(!is_array($row))continue;$id=trim((string)($row['owner_concept_id']??''));if($id==='')throw new RuntimeException('PSTE_UPSTREAM_OWNER_ID_MISSING');
            if(isset($owners[$id]))throw new RuntimeException('PSTE_UPSTREAM_OWNER_ID_DUPLICATE');
            $owners[$id]=[
                'owner_concept_id'=>$id,
                'owner_block'=>(string)($row['owner_block']??''),
                'owner_pillar_role'=>(string)($row['owner_pillar_role']??''),
                'category_name'=>(string)($row['category_name']??''),
                'category_slug'=>(string)($row['category_slug']??''),
                'category_path'=>array_values(array_map('strval',(array)($row['category_path']??[]))),
                'research_cluster_id'=>(string)($row['research_cluster_id']??''),
                'primary_keyword'=>(string)($row['primary_keyword']??''),
                'search_intent'=>(string)($row['search_intent']??''),
                'intent_key'=>(string)($row['intent_key']??''),
            ];
        }
        if(!$owners)throw new RuntimeException('PSTE_UPSTREAM_OWNER_REGISTRY_EMPTY');

        $assignments=[];$byExact=[];
        foreach((array)($handoff['article_only_assignments']??[]) as $row){
            if(!is_array($row))continue;
            if(($row['binding_status']??'')!=='BOUND_SINGLE_OWNER')throw new RuntimeException('PSTE_UPSTREAM_ARTICLE_OWNER_NOT_BOUND');
            $query=trim((string)($row['article_intent_query']??''));$exact=PSTE_Normalizer::exactTopicIdentityText($query);
            $owner=trim((string)($row['owner_concept_id']??''));
            if($exact===''||$owner===''||!isset($owners[$owner]))throw new RuntimeException('PSTE_UPSTREAM_ARTICLE_ASSIGNMENT_INVALID');
            if(isset($byExact[$exact])&&!hash_equals((string)$byExact[$exact],$owner))throw new RuntimeException('PSTE_UPSTREAM_EXACT_INTENT_MULTIPLE_OWNERS');
            $byExact[$exact]=$owner;
            $assignments[]=[
                'article_intent_query'=>$query,
                'article_intent_key'=>(string)($row['article_intent_key']??$exact),
                'exact_intent_key'=>$exact,
                'owner_concept_id'=>$owner,
                'owner_category_name'=>(string)($row['owner_category_name']??$owners[$owner]['category_name']),
                'owner_category_path'=>array_values(array_map('strval',(array)($row['owner_category_path']??$owners[$owner]['category_path']))),
                'research_cluster_id'=>(string)($row['research_cluster_id']??''),
                'provider_main_intent'=>$row['provider_main_intent']??null,
                'search_volume'=>$row['search_volume']??null,
                'source'=>(string)($row['source']??''),
            ];
        }
        usort($assignments,static fn($a,$b)=>strcmp((string)$a['exact_intent_key'],(string)$b['exact_intent_key'])?:strcmp((string)$a['owner_concept_id'],(string)$b['owner_concept_id']));
        ksort($owners,SORT_STRING);ksort($byExact,SORT_STRING);
        $snapshot=[
            'contract'=>self::SNAPSHOT_CONTRACT,
            'upstream_contract'=>self::UPSTREAM_CONTRACT,
            'status'=>'READY',
            'category_owner_registry'=>array_values($owners),
            'article_only_assignments'=>$assignments,
            'exact_intent_owner_map'=>$byExact,
            'downstream_rules'=>(array)($handoff['downstream_rules']??[]),
            'question_form_has_ownership_authority'=>false,
            'semantic_intent_key_required_before_article_promotion'=>true,
            'write_attempted'=>false,
        ];
        $snapshot['snapshot_sha256']=self::hash($snapshot);
        return $snapshot;
    }

    /** @return array<string,mixed> */
    public static function importedSnapshot(): array {
        $stored=function_exists('get_option')?get_option(PSTE_OPTION_EDITORIAL_OWNERSHIP_IMPORT,null):null;
        if(!is_array($stored)||($stored['contract']??'')!==self::SNAPSHOT_CONTRACT)return ['contract'=>self::SNAPSHOT_CONTRACT,'status'=>'NOT_AVAILABLE','snapshot_sha256'=>'NOT_AVAILABLE','category_owner_registry'=>[],'article_only_assignments'=>[],'exact_intent_owner_map'=>[]];
        $declared=(string)($stored['snapshot_sha256']??'');if($declared===''||!hash_equals($declared,self::hash($stored)))throw new RuntimeException('PSTE_EDITORIAL_OWNERSHIP_SNAPSHOT_HASH_MISMATCH');
        return $stored;
    }

    /**
     * Fail-closed ownership gate before article promotion. semantic_intent_key is supplied by the
     * semantic article planner/clustering step; this gate enforces uniqueness but does not invent meaning.
     * @param list<array<string,mixed>> $existingSemanticOwners
     * @param list<array<string,mixed>> $legacyItems
     * @return array<string,mixed>
     */
    public static function evaluate(array $candidate,array $existingSemanticOwners=[],array $legacyItems=[],?array $snapshot=null): array {
        $snapshot=$snapshot??self::importedSnapshot();$reasons=[];$matches=[];
        $query=trim((string)($candidate['primary_longtail_query']??$candidate['canonical_query']??$candidate['article_intent_query']??''));
        $exact=PSTE_Normalizer::exactTopicIdentityText($query);
        $owner=trim((string)($candidate['owner_concept_id']??''));
        $semantic=trim((string)($candidate['semantic_intent_key']??$candidate['intent_owner_key']??''));
        if($exact==='')$reasons[]='PSTE_ARTICLE_OWNERSHIP_QUERY_MISSING';
        if($owner==='')$reasons[]='PSTE_ARTICLE_OWNER_CONCEPT_ID_MISSING';
        if($semantic==='')$reasons[]='PSTE_SEMANTIC_INTENT_KEY_MISSING';

        $owners=[];foreach((array)($snapshot['category_owner_registry']??[]) as $row)if(is_array($row)&&trim((string)($row['owner_concept_id']??''))!=='')$owners[(string)$row['owner_concept_id']]=$row;
        if(($snapshot['status']??'')==='READY'){
            if($owner!==''&&!isset($owners[$owner]))$reasons[]='PSTE_ARTICLE_OWNER_NOT_IN_UPSTREAM_REGISTRY';
            $expected=(string)($snapshot['exact_intent_owner_map'][$exact]??'');
            if($expected!==''&&$owner!==''&&!hash_equals($expected,$owner)){
                $reasons[]='PSTE_UPSTREAM_EXACT_INTENT_OWNER_MISMATCH';
                $matches[]=['source'=>'UPSTREAM_OWNERSHIP','exact_intent_key'=>$exact,'expected_owner_concept_id'=>$expected,'candidate_owner_concept_id'=>$owner];
            }
        }

        if($semantic!=='')foreach($existingSemanticOwners as $item){
            if(!is_array($item))continue;$key=trim((string)($item['semantic_intent_key']??$item['intent_owner_key']??''));if($key===''||!hash_equals($key,$semantic))continue;
            $reasons[]='PSTE_SEMANTIC_INTENT_ALREADY_OWNED';
            $matches[]=['source'=>'SEMANTIC_OWNER_REGISTRY','semantic_intent_key'=>$semantic,'owner_concept_id'=>(string)($item['owner_concept_id']??''),'title'=>(string)($item['title']??''),'primary_longtail_query'=>(string)($item['primary_longtail_query']??'')];
        }

        // Legacy safety: exact keyword/query and the existing conservative answer-equivalence guard stay active.
        foreach($legacyItems as $item){
            if(!is_array($item))continue;$title=trim((string)($item['title']??''));$keyword=trim((string)($item['target_keyword']??$item['seo_target_keyword']??''));
            $surface=$keyword!==''?$keyword:$title;if($surface==='')continue;
            $legacyExact=$exact!==''&&hash_equals($exact,PSTE_Normalizer::exactTopicIdentityText($surface));
            $equiv=$query!==''&&PSTE_Normalizer::answerEquivalent($query,$surface,(string)($candidate['owner_category_name']??''),(string)($item['category_name']??''));
            if(!$legacyExact&&!$equiv)continue;
            $reasons[]=$legacyExact?'PSTE_LEGACY_EXACT_INTENT_DUPLICATE':'PSTE_LEGACY_ANSWER_EQUIVALENT_DUPLICATE';
            $matches[]=['source'=>(string)($item['source']??'LEGACY_PORTAL'),'post_id'=>(int)($item['post_id']??0),'title'=>$title,'target_keyword'=>$keyword,'answer_equivalence'=>$equiv];
        }

        $reasons=array_values(array_unique($reasons));
        return [
            'contract'=>self::CONTRACT,
            'status'=>$reasons?'BLOCKED':'PASS','ok'=>$reasons===[],'decision'=>$reasons?'BLOCKED':'PASS',
            'reason_codes'=>$reasons,'matches'=>array_slice($matches,0,12),
            'candidate'=>['primary_longtail_query'=>$query,'exact_intent_key'=>$exact,'semantic_intent_key'=>$semantic,'owner_concept_id'=>$owner],
            'question_form_has_ownership_authority'=>false,
            'category_creation_or_rename_allowed'=>false,
            'write_attempted'=>false,
        ];
    }

    private static function hash(array $value): string {
        unset($value['snapshot_sha256']);$value=self::stable($value);
        $json=function_exists('wp_json_encode')?wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
        if(!is_string($json))throw new RuntimeException('PSTE_EDITORIAL_OWNERSHIP_HASH_FAILED');return hash('sha256',$json);
    }
    private static function stable($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'stable'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::stable($x);return $v;}
}
