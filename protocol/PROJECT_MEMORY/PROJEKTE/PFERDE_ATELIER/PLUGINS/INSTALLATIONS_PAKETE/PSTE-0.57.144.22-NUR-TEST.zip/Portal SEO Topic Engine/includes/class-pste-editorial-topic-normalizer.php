<?php
if (!defined('ABSPATH')) { return; }

/**
 * Preserves an arbitrary research phrase and derives two metadata-only views:
 *  - semantic_probe: family-matching probe with editorial intent noise removed
 *  - subject_topic: meaning-preserving subject phrase used by the title composer
 *
 * It never changes the stored raw query and never creates article content, structure or formatting.
 */
final class PSTE_Editorial_Topic_Normalizer {
    private const RELATIONS=['mit','für','fuer','ohne','gegen','bei','von','aus','im','in','auf','unter','über','ueber','zum','zur'];
    private const JOINERS=['und','oder'];

    /** Lexical intent policy is owned centrally by PSTE_Article_Type_Intent_Ontology. */

    /** @return array<string,mixed> */
    public static function normalize(string $raw,string $family='',array $portalContextTerms=[],array $portalScopeTerms=[]): array {
        // Preserve original question punctuation before the mechanical cleaner removes it.
        // This is evidence from the input, not a new route or a relaxed quality gate.
        $naturalQuestion=PSTE_Normalizer::isQuestion(trim($raw));
        $raw=self::clean($raw);$family=self::clean($family);
        $base=[
            'contract'=>'PSTE_EDITORIAL_TOPIC_NORMALIZER_V2',
            'raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),'family'=>$family,
            'normalized_topic'=>'','subject_topic'=>'','semantic_probe'=>'','qualifier'=>'','relation'=>'','relation_evidence'=>'NONE','relation_source'=>'NONE',
            'detected_action'=>self::detectAction($raw),'intent_signals'=>self::intentSignals($raw),
            'status'=>'REVIEW_REQUIRED','reason_codes'=>[],'review_flags'=>[],
            'raw_query_modified'=>false,'write_attempted'=>false,
        ];
        if($raw===''){ $base['reason_codes']=['EDITORIAL_TOPIC_RAW_QUERY_EMPTY']; return $base; }

        $probe=self::semanticProbe($raw);$base['semantic_probe']=$probe!==''?$probe:$raw;
        if($family===''){
            $topic=self::surfaceLoose($probe!==''?$probe:$raw);
            $base['normalized_topic']=$topic;$base['subject_topic']=$topic;
            $base['status']=$topic!==''?'PASS':'REVIEW_REQUIRED';
            $base['reason_codes']=$topic!==''?['EDITORIAL_TOPIC_NORMALIZED_WITHOUT_CONFIRMED_FAMILY_PROPOSAL_ONLY']:['EDITORIAL_TOPIC_NORMALIZATION_FAILED'];
            $base['review_flags'][]='EDITORIAL_TOPIC_NO_CONFIRMED_FAMILY';
            return $base;
        }

        if(!self::familySemanticallyPresent($raw,$family)){
            $base['reason_codes']=['EDITORIAL_TOPIC_FAMILY_NOT_SEMANTICALLY_PRESENT'];
            return $base;
        }

        // One single normalization decision. For a clear cost-question clause,
        // pass the untouched noun phrase through THIS existing relation parser
        // below, instead of running a second independent normalizer/verdict.
        $costQuestionSource='';
        if($naturalQuestion){
            $signals=PSTE_Article_Type_Intent_Ontology::strongSignals($raw);
            if($signals===['Kosten']&&preg_match('/^(?:was|wie viel)\s+kostet\s+(?:(?:ein|eine|einen|einem|einer|der|die|das)\s+)?(.+)$/iu',$raw,$q)){
                $clause=self::clean(rtrim((string)$q[1],'?'));
                if($clause!==''&&self::familySemanticallyPresent($clause,$family)){
                    $costQuestionSource=$raw;
                    $raw=$clause;
                }
            }
            if($costQuestionSource===''){
                $base['normalized_topic']=self::surfaceSentence($raw);
                $base['subject_topic']=$family;
                $base['status']='PASS';
                $base['reason_codes']=['EDITORIAL_TOPIC_NATURAL_QUESTION_PRESERVED'];
                return $base;
            }
        }

        $split=self::splitAroundFamily($raw,$family);
        if(empty($split['matched'])){
            $base['reason_codes']=['EDITORIAL_TOPIC_FAMILY_TOKEN_SPLIT_FAILED'];
            return $base;
        }

        $before=self::clean((string)$split['before']);$after=self::clean((string)$split['after']);
        // A complete, explicit cost lead-in is intent, not a preposed subject qualifier.
        // Keep raw/search keyword intact; this never guesses a relation or a category.
        // Examples: "Kosten für den Reitplatzbau" and "Kosten für die Reitplatzbeleuchtung".
        $explicitCostLead=(bool)preg_match('/^kosten\s+für\s+(?:den|die|das)\s*$/iu',$before)
            &&in_array('Kosten',PSTE_Article_Type_Intent_Ontology::strongSignals($raw),true);
        $beforeSubject=self::stripIntentOnly($before);$afterSubject=self::stripIntentOnly($after);
        if($explicitCostLead)$beforeSubject='';
        $beforeSubject=self::trimDanglingRelations($beforeSubject);$afterSubject=self::trimDanglingRelations($afterSubject);
        // Financing is an editorial intent tail, not a new topic family. When a proven cost signal
        // exists and the post-family residual starts with a financing verb, keep the raw query
        // immutable but remove that complete tail from family/qualifier semantics.
        $strongIntent=PSTE_Article_Type_Intent_Ontology::strongSignals($raw);
        if($beforeSubject===''&&preg_match('/^finanzier\w*\b/iu',$after)&&in_array('Kosten',$strongIntent,true)){
            $afterSubject='';$base['detected_action']='finanzieren';$base['intent_signals']=array_values(array_unique(array_merge((array)$base['intent_signals'],['KOSTEN','FINANZIERUNG'])));
        }
        // A portal identity token such as `Pferde` is domain scope, not an editorial qualifier.
        // Ignore it only when it is exactly the whole residual side; strong portal-domain seed terms
        // and additional qualifiers remain reviewable evidence and are never silently stripped.
        if(self::matchesPortalContext($beforeSubject,$portalScopeTerms))$beforeSubject='';
        if(self::matchesPortalContext($afterSubject,$portalScopeTerms))$afterSubject='';

        $subject=$family;$relation='';$qualifier='';$review=[];
        $beforeCount=self::wordCount($beforeSubject);$afterCount=self::wordCount($afterSubject);

        if($beforeSubject!==''&&$afterSubject===''){
            if($beforeCount===1&&!self::isRelation($beforeSubject)){
                $qualifier=self::surfaceToken($beforeSubject);
                if(self::matchesPortalContext($beforeSubject,$portalContextTerms)){
                    // Portal taxonomy/context proves topical relevance only. A bare adjacent token never proves
                    // a grammatical/semantic relation. In particular, "context + family" may not synthesize
                    // "family für context" (for example "Pferdedecken Regendecken" -> "Regendecken für Pferdedecken").
                    $relation='';$subject=$family;
                    $review[]='EDITORIAL_TOPIC_PORTAL_CONTEXT_RELATION_UNPROVEN';
                    $base['relation_evidence']='UNPROVEN_BARE_PORTAL_CONTEXT';
                    $base['relation_source']='PORTAL_CONTEXT_RELEVANCE_ONLY';
                }elseif(!preg_match('/(?:e|en|er|es|em)$/iu',$beforeSubject)){
                    // A bare noun/adjective dictionary-free fragment such as
                    // "X Y" is not proven German grammar. Do not turn it into a
                    // mechanically approved title by concatenating both tokens.
                    $review[]='EDITORIAL_TOPIC_PREPOSED_QUALIFIER_GRAMMAR_UNPROVEN';
                    $base['relation_evidence']='UNPROVEN_PREPOSED_GRAMMAR';
                    $base['relation_source']='RAW_QUERY';
                }else{
                    $relation='preposed_qualifier';$subject=trim($qualifier.' '.$family);
                    $base['relation_evidence']='RAW_PREPOSED_QUALIFIER';
                    $base['relation_source']='RAW_QUERY';
                }
            }else{
                $review[]='EDITORIAL_TOPIC_PREPOSED_MULTIWORD_QUALIFIER_REVIEW';
            }
        }elseif($beforeSubject===''&&$afterSubject!==''){
            if(preg_match('/^(mit|für|fuer|ohne|gegen|bei|von|aus|im|in|auf|unter|über|ueber|zum|zur)\s+(.+)$/iu',$afterSubject,$m)){
                $relation=self::normalizeRelation((string)$m[1]);$q=self::clean((string)$m[2]);
                $base['relation_evidence']='EXPLICIT_RAW_RELATION';$base['relation_source']='RAW_QUERY';
                if($q!==''&&!self::isIntentOnly($q)){
                    if(self::wordCount($q)===1){$qualifier=self::surfaceQualifier($q);$subject=$family.' '.$relation.' '.$qualifier;}
                    elseif($relation==='für' && preg_match('/^([\p{L}\p{N}-]+)\s+([\p{L}\p{N}-]+)$/u',$q,$audience)
                        && self::matchesPortalContext((string)$audience[2],array_merge($portalScopeTerms,$portalContextTerms))){
                        // KISS: explicit two-word portal audience remains exactly as written.
                        // No guessed relation, no keyword rewrite and no unknown audience shift.
                        $qualifier=self::clean((string)$audience[1].' '.self::uppercaseFirst((string)$audience[2]));
                        $subject=$family.' '.$relation.' '.$qualifier;
                        $base['relation_source']='RAW_QUERY_PORTAL_AUDIENCE_BOUND';
                    }elseif($relation==='für'&&self::wordCount($q)>=2&&self::wordCount($q)<=5
                        &&(
                            preg_match('/^(?:[\p{L}-]+|\d+)\s+(?:pferde|ponys)$/iu',$q)
                            ||preg_match('/^(?:pferde|ponys)\s+mit\s+(?:[\p{L}-]+\s+){0,2}[\p{L}-]+$/iu',$q)
                        )){
                        // Bounded, grammatical audience phrase with an explicit source
                        // preposition: adjective/number + horse audience, or audience
                        // + explicit "mit" complement. Other multiword fragments still
                        // require review. Original keyword is never rewritten.
                        $qualifier=(string)preg_replace_callback('/\b(pferde|ponys)\b/iu',static function($m){
                            return strtolower((string)$m[0])==='pferde'?'Pferde':'Ponys';
                        },$q);
                        // German noun after an explicit "mit" relation: retain lexical
                        // identity but render the head noun with standard capitalization.
                        if(preg_match('/\bmit\b/iu',$qualifier)){
                            $qualifier=(string)preg_replace_callback('/(\bmit\s+(?:[\p{L}-]+\s+){0,2})([\p{L}-]+)$/u',static function($m){
                                $last=(string)$m[2];$first=function_exists('mb_substr')?mb_substr($last,0,1,'UTF-8'):substr($last,0,1);
                                $rest=function_exists('mb_substr')?mb_substr($last,1,null,'UTF-8'):substr($last,1);
                                return $m[1].(function_exists('mb_strtoupper')?mb_strtoupper($first,'UTF-8'):strtoupper($first)).$rest;
                            },$qualifier);
                        }
                        $subject=$family.' '.$relation.' '.$qualifier;
                        $base['relation_source']='RAW_QUERY_EXPLICIT_BOUNDED_AUDIENCE';
                    }else $review[]='EDITORIAL_TOPIC_LONG_RELATIONAL_QUALIFIER_REVIEW';
                }
            }elseif($afterSubject!==''&&!self::isIntentOnly($afterSubject)){
                // A bare token after the family can mean brand, audience, material, location or something else.
                // Inventing a relation is unsafe, so the editorial strand must review it.
                $review[]='EDITORIAL_TOPIC_UNBOUND_POST_FAMILY_QUALIFIER_REVIEW';
            }
        }elseif($beforeSubject!==''&&$afterSubject!==''){
            // Two-sided residuals are frequently search-engine fragments. Never invent a relation.
            $review[]='EDITORIAL_TOPIC_TWO_SIDED_RESIDUAL_REVIEW';
        }

        // Preserve explicit type/action semantics in normalized_topic for the independent semantic classifier,
        // while subject_topic remains the clean subject for title composition.
        $normalized=self::canonicalFamilySurface($raw,$family);
        $normalized=self::surfaceSentence($normalized);
        $subject=self::clean($subject);
        $base['normalized_topic']=$normalized!==''?$normalized:$subject;
        $base['subject_topic']=$subject;
        $base['qualifier']=$qualifier;$base['relation']=$relation;$base['review_flags']=$review;
        $base['status']=$subject!==''&&!$review?'PASS':'REVIEW_REQUIRED';
        $base['reason_codes']=$base['status']==='PASS'?['EDITORIAL_TOPIC_MEANING_PRESERVING_NORMALIZATION']:array_values(array_unique(array_merge(['EDITORIAL_TOPIC_NORMALIZATION_REVIEW_REQUIRED'],$review)));
        if($costQuestionSource!==''){
            $base['normalized_topic']=self::surfaceSentence($costQuestionSource);
            if($base['status']==='PASS'){
                $base['cost_question_subject_proven_from_raw']=true;
                $base['reason_codes']=['EDITORIAL_TOPIC_NATURAL_QUESTION_PRESERVED'];
            }
        }
        return $base;
    }

    /** Family-matcher probe: removes only generic editorial/type signals, never source data. */
    public static function semanticProbe(string $raw): string {
        $value=self::clean($raw);if($value==='')return '';
        $value=PSTE_Article_Type_Intent_Ontology::stripIntentSignals($value);
        $value=self::clean((string)preg_replace('/[?:;!]+/u',' ',$value));
        return self::trimDanglingRelations($value);
    }

    /** Tokens that carry subject meaning after generic editorial intent has been removed. @return list<string> */
    public static function semanticContentTokens(string $raw,string $family=''): array {
        $probe=self::semanticProbe($raw);$tokens=PSTE_Token_Equivalence::tokens(str_replace('-',' ',$probe));
        if($family!=='')$tokens=array_values(array_diff($tokens,PSTE_Token_Equivalence::tokens(str_replace('-',' ',$family))));
        $stop=['fuer','mit','ohne','gegen','bei','von','aus','im','in','auf','unter','ueber','zum','zur','und','oder','ein','eine','einer','einem','einen','der','die','das','den','dem','des'];
        return array_values(array_unique(array_diff($tokens,$stop)));
    }

    /** Generic, non-applying suggestion used only after current portal structure has been rechecked. @return array<string,mixed> */
    public static function structureProposal(string $raw,string $articleType='',array $sourceEvidence=[],array $intentAnalysis=[]): array {
        $raw=self::clean($raw);$probe=self::semanticProbe($raw);$family=self::surfaceLoose($probe!==''?$probe:$raw);$type=trim($articleType);
        // Structure proposals only decide structure, never supply a title.
        $title='';$titleQuality=[];
        if(!$intentAnalysis&&$family!==''){
            $proposalNormalization=self::normalize($raw,'');
            $intentAnalysis=PSTE_Intent_Profile::analyzeBeforeType($raw,$proposalNormalization,$family,$sourceEvidence);
        }
        // Without a confirmed existing family/category, a proposal may not self-certify its own title.
        // Keep the candidate for later review/recheck, but it can never directly unlock reentry or production.
        $titleStatus='REVIEW_REQUIRED';
        return [
            'contract'=>'PSTE_STRUCTURE_PROPOSAL_V3_RETAINED_REVIEW_GATED','status'=>$family!==''?'PROPOSAL_ONLY':'REVIEW_REQUIRED',
            'raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),'normalized_topic'=>$probe,'proposed_family_name'=>$family,
            'proposed_category_name'=>$family!==''&&$type!==''?trim($type.' '.$family):'','proposed_article_type'=>$type,
            'proposed_article_type_status'=>$type!==''?'SEMANTICALLY_PROVEN':'REVIEW_REQUIRED',
            'intent_analysis'=>$intentAnalysis,'intent_first'=>true,
            'planning_title_proposal'=>$title,'planning_title_status'=>$titleStatus,'planning_title_quality'=>$titleQuality,
            'planning_title_quality_scope'=>'PROVISIONAL_ONLY_NO_CONFIRMED_FAMILY_SELF_APPROVAL_FORBIDDEN',
            'planning_title_may_enter_reentry'=>false,
            'proposal_requires_review'=>true,'taxonomy_write_attempted'=>false,'production_handoff_attempted'=>false,'write_attempted'=>false,
        ];
    }

    /** @return list<string> */
    private static function intentSignals(string $raw): array {
        $s=PSTE_Normalizer::isQuestion($raw)?['FAQ']:[];
        foreach(PSTE_Article_Type_Intent_Ontology::strongSignals($raw) as $type)$s[]=strtoupper(PSTE_Article_Type_Registry::canonicalType($type));
        return array_values(array_unique($s));
    }

    private static function detectAction(string $raw): string {
        $map=[
            '/\bimprägnier\w*\b/iu'=>'imprägnieren','/\bimpraegnier\w*\b/iu'=>'imprägnieren','/\breparier\w*\b/iu'=>'reparieren','/\breinig\w*\b/iu'=>'reinigen','/\bwasch\w*\b/iu'=>'waschen','/\btrockn\w*\b/iu'=>'trocknen','/\bpfleg\w*\b/iu'=>'pflegen','/\bwart\w*\b/iu'=>'warten',
            '/\binstallier\w*\b/iu'=>'installieren','/\bmontier\w*\b/iu'=>'montieren','/\baufbau\w*\b/iu'=>'aufbauen','/\banschließ\w*\b/iu'=>'anschließen','/\banschliess\w*\b/iu'=>'anschließen','/\beinbau\w*\b/iu'=>'einbauen','/\bbefestig\w*\b/iu'=>'befestigen','/\banbring\w*\b/iu'=>'anbringen','/\beinricht\w*\b/iu'=>'einrichten',
            '/\banwend\w*\b/iu'=>'anwenden','/\bbenutz\w*\b/iu'=>'benutzen','/\bverwend\w*\b/iu'=>'verwenden','/\beinsetz\w*\b/iu'=>'einsetzen','/\bdosier\w*\b/iu'=>'dosieren','/\banleg\w*\b/iu'=>'anlegen',
            '/\blager\w*\b/iu'=>'lagern','/\baufbewahr\w*\b/iu'=>'aufbewahren','/\bverstau\w*\b/iu'=>'verstauen',
        ];
        foreach($map as $pattern=>$action)if(preg_match($pattern,$raw))return $action;return '';
    }

    /** @return array{matched:bool,before:string,after:string} */
    private static function splitAroundFamily(string $raw,string $family): array {
        $words=preg_split('/\s+/u',self::clean($raw))?:[];$familyTokens=PSTE_Family_Identity_V2::tokens($family,false);$hits=[];
        foreach($words as $i=>$word){foreach(PSTE_Family_Identity_V2::tokens(trim($word,".,!?;:()[]{}\"'"),false) as $token){foreach($familyTokens as $familyToken)if(self::familyTokenEquivalent($token,$familyToken)){$hits[]=$i;break 2;}}}
        if(!$hits)return ['matched'=>false,'before'=>'','after'=>''];$first=min($hits);$last=max($hits);
        return ['matched'=>true,'before'=>self::clean(implode(' ',array_slice($words,0,$first))),'after'=>self::clean(implode(' ',array_slice($words,$last+1)))];
    }

    private static function canonicalFamilySurface(string $raw,string $family): string {
        // Replace the complete matched family span once. The old token-by-token replacement
        // inserted the whole family at the first matching token but left relation words that
        // belonged inside multi-token families in place. Example:
        // `Waschplatz für Pferde finanzieren ...` became
        // `Waschplatz für Pferde für finanzieren ...`, creating a fake second context target.
        $split=self::splitAroundFamily($raw,$family);
        if(empty($split['matched']))return self::clean($raw);
        return self::clean(trim((string)$split['before'].' '.$family.' '.(string)$split['after']));
    }

    private static function familySemanticallyPresent(string $raw,string $family): bool {
        $queryTokens=PSTE_Family_Identity_V2::tokens($raw,false);$familyTokens=PSTE_Family_Identity_V2::tokens($family,false);
        if(!$queryTokens||!$familyTokens)return false;
        foreach($familyTokens as $familyToken){$found=false;foreach($queryTokens as $queryToken)if(self::familyTokenEquivalent($queryToken,$familyToken)){$found=true;break;}if(!$found)return false;}
        return true;
    }

    private static function familyTokenEquivalent(string $token,string $familyToken): bool {
        if($token===$familyToken)return true;
        // Same conservative German grammatical tolerance as Family Identity V2.
        foreach(['t','st'] as $suffix){if(strlen($token)>strlen($suffix)+4&&str_ends_with($token,$suffix)&&substr($token,0,-strlen($suffix))===$familyToken)return true;}
        if(strlen($token)>=6&&strlen($familyToken)>=6){
            $fold=static function(string $v): string {return (string)(preg_replace('/([aou])e(?=[a-z])/','\1',$v)??$v);};
            $a=$fold($token);$b=$fold($familyToken);if($a===$b)return true;
            foreach(['e','en','er','n','s'] as $suffix){if(strlen($a)>strlen($suffix)+5&&str_ends_with($a,$suffix)&&substr($a,0,-strlen($suffix))===$b)return true;if(strlen($b)>strlen($suffix)+5&&str_ends_with($b,$suffix)&&substr($b,0,-strlen($suffix))===$a)return true;}
        }
        return false;
    }

    private static function stripIntentOnly(string $value): string {return self::clean(PSTE_Article_Type_Intent_Ontology::stripIntentSignals($value));}
    private static function isIntentOnly(string $value): bool {return self::semanticProbe($value)==='';}
    private static function trimDanglingRelations(string $value): string {$value=self::clean($value);do{$old=$value;$value=(string)(preg_replace('/^(mit|für|fuer|ohne|gegen|bei|von|aus|im|in|auf|unter|über|ueber|zum|zur)\s*$/iu','',$value)??$value);$value=(string)(preg_replace('/\b(mit|für|fuer|ohne|gegen|bei|von|aus|im|in|auf|unter|über|ueber|zum|zur)\s*$/iu','',$value)??$value);$value=self::clean($value);}while($value!==$old);return $value;}
    private static function isRelation(string $v): bool{return in_array(self::lower(self::clean($v)),self::RELATIONS,true);}
    private static function matchesPortalContext(string $value,array $terms): bool {
        $valueTokens=PSTE_Token_Equivalence::tokens($value);if(count($valueTokens)!==1)return false;
        foreach($terms as $term){$termTokens=PSTE_Token_Equivalence::tokens((string)$term);if(count($termTokens)===1&&$termTokens[0]===$valueTokens[0])return true;}
        return false;
    }
    private static function normalizeRelation(string $v): string {$v=self::lower($v);return $v==='fuer'?'für':($v==='ueber'?'über':$v);}

    private static function surfaceQualifier(string $value): string {
        $value=self::clean($value);if($value==='')return '';$parts=preg_split('/\s+/u',$value)?:[];$out=[];
        foreach($parts as $i=>$w){$l=self::lower($w);if(in_array($l,self::RELATIONS,true)){$out[]=self::normalizeRelation($l);continue;}if(in_array($l,self::JOINERS,true)){$out[]=$l;continue;}if($i===0)$w=self::uppercaseFirst($w);$out[]=$w;}
        return self::clean(implode(' ',$out));
    }
    private static function surfaceToken(string $value): string {return self::uppercaseFirst(self::clean($value));}
    private static function surfaceLoose(string $value): string {return self::surfaceSentence(self::clean($value));}
    private static function surfaceSentence(string $value): string {$value=self::clean($value);return $value===''?'':self::uppercaseFirst($value);}
    private static function wordCount(string $v): int {return count(array_values(array_filter(preg_split('/\s+/u',self::clean($v))?:[])));}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');$v=trim((string)preg_replace('/\s+/u',' ',$v));return trim($v," \t\n\r\0\x0B?:;!");}
    private static function uppercaseFirst(string $v): string {if($v==='')return '';$f=self::substr($v,0,1);$r=self::substr($v,1);$f=function_exists('mb_strtoupper')?mb_strtoupper($f,'UTF-8'):strtoupper($f);return $f.$r;}
    private static function lower(string $v): string{return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
    private static function substr(string $v,int $start,?int $length=null): string{return function_exists('mb_substr')?($length===null?mb_substr($v,$start,null,'UTF-8'):mb_substr($v,$start,$length,'UTF-8')):($length===null?substr($v,$start):substr($v,$start,$length));}
}
