<?php
if (!defined('ABSPATH')) { return; }

/**
 * Single pre-production duplicate/cannibalization authority shared by fresh research and
 * retained-backlog reanalysis. Title wording has zero SEO/longtail authority here.
 *
 * This class is metadata-only and read-only: it never writes WordPress state and never reads
 * article body content beyond the already-bound inventory projection supplied by the caller.
 */
final class PSTE_Planning_Readiness_Gate {
    public const CONTRACT='PSTE_PLANNING_READINESS_GATE_V1_PRETITLE_PARITY';
    public const PRE_TITLE_CONTRACT='PSTE_PRE_TITLE_DUPLICATE_GATE_V2_KEYWORD_OWNERSHIP';

    /** Reuse the already bound editorial-plan items as read-only inventory for the ONE existing gate. */
    public static function planItemsAsInventory(array $items,array $structure): array {$byId=[];$bySlug=[];foreach($structure as $row){if(!is_array($row))continue;$id=(int)($row['term_id']??0);$slug=trim((string)($row['slug']??''));if($id>0)$byId[$id]=$row;if($slug!=='')$bySlug[$slug]=$row;}$out=[];foreach($items as $item){$title=(string)($item['title']??$item['primary_longtail_query']??'');if($title==='')continue;$category=(string)($item['category_name']??'');$id=(int)($item['category_id']??0);$slug=trim((string)($item['category_slug']??''));$matched=$id>0&&isset($byId[$id])?$byId[$id]:($slug!==''&&isset($bySlug[$slug])?$bySlug[$slug]:[]);$key=(string)($matched['topic_family_key']??$item['topic_family_key']??PSTE_Normalizer::categoryFamilyKey($category));$out[]=['post_id'=>0,'title'=>$title,'status'=>'draft','category_name'=>$category,'topic_family_name'=>(string)($matched['topic_family_name']??PSTE_Normalizer::categoryFamilyName($category)),'topic_family_key'=>$key,'headings'=>is_array($item['headings']??null)?$item['headings']:[],'intent_cluster_id'=>(string)($item['intent_cluster_id']??''),'source'=>'EDITORIAL_PLAN_READ_ONLY'];}return $out;}

    /** @return array<string,mixed> */
    public static function evaluate(array $candidate,array $inventoryItems,array $categoryItems): array {
        $query=PSTE_Normal_Metadata_Path::canonicalInputQuery(PSTE_Editorializer::sourceQuery($candidate));
        if($query==='')$query=trim((string)($candidate['primary_longtail_query']??$candidate['canonical_query']??''));
        $familyName=trim((string)($candidate['topic_family_name']??''));
        $familyKey=trim((string)($candidate['topic_family_key']??''));
        $articleType=trim((string)($candidate['proposed_article_type']??$candidate['suggested_article_type']??''));
        $categorySlug=trim((string)($candidate['target_category_slug']??$candidate['suggested_category_slug']??''));

        $pre=self::preTitleDuplicate($query,$inventoryItems);
        if(empty($pre['ok'])){
            return [
                'contract'=>self::CONTRACT,'status'=>'BLOCKED','ok'=>false,'decision'=>'BLOCKED',
                'pre_title_duplicate_gate'=>$pre,'cannibalization'=>['decision'=>'NOT_RUN_PRE_TITLE_BLOCKED','reason_codes'=>[],'matches'=>[]],
                'reason_codes'=>(array)$pre['reason_codes'],'matches'=>(array)$pre['matches'],
                'semantic_identity_source'=>'SEO_SOURCE_QUERY_NOT_TITLE','title_surface_authority'=>false,
                'provider_calls'=>0,'write_attempted'=>false,'content_or_design_touched'=>false,
            ];
        }

        // Cannibalization receives a stable pre-title semantic surface. The visible title may contain
        // natural adjectives/adverbs, but those words must never create or remove duplicate authority.
        $stable=$candidate;
        if(!is_array($stable['editorialization']??null))$stable['editorialization']=[];
        $stable['editorialization']['resolved']=!empty($candidate['editorialization']['resolved']);
        $post=PSTE_Cannibalization::decide($stable,$inventoryItems,$categoryItems,[]);
        $decision=(string)($post['decision']??'BLOCKED');
        $ok=$decision==='PASS';
        return [
            'contract'=>self::CONTRACT,'status'=>$ok?'PASS':'BLOCKED','ok'=>$ok,'decision'=>$decision,
            'pre_title_duplicate_gate'=>$pre,'cannibalization'=>$post,
            'reason_codes'=>array_values(array_unique(array_merge((array)$pre['reason_codes'],(array)($post['reason_codes']??[])))),
            'matches'=>array_slice(array_values(array_merge((array)$pre['matches'],(array)($post['matches']??[]))),0,8),
            'semantic_identity_source'=>'SEO_SOURCE_QUERY_NOT_TITLE','title_surface_authority'=>false,
            'provider_calls'=>0,'write_attempted'=>false,'content_or_design_touched'=>false,
        ];
    }

    /** Re-evaluate ONLY this owner's coverage decision; never inherit its old blocks. */
    public static function apply(array $candidate,array $inventoryItems,array $categoryItems): array {
        $before=self::bindingSnapshot($candidate);
        $previous=(array)($candidate['planning_readiness_gate']??[]);
        $prior=(array)($previous['prior_owner_fields']??[]);
        $identity=hash('sha256',json_encode($before,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        $oldGateOwned=!empty($previous)&&($previous['contract']??'')===self::CONTRACT
            &&empty($previous['ok'])&&!empty($prior)
            &&hash_equals($identity,(string)($prior['binding_sha256']??''))
            &&(string)($candidate['decision']??'')==='BLOCKED'
            &&!empty($candidate['human_review_required'])&&!empty($candidate['discovery_only'])
            &&(string)($candidate['candidate_role']??'')==='DISCOVERY_PROBE';
        if($oldGateOwned){
            // Restore only fields this gate overrode. Preserve new independent
            // security errors and all original decisions/keyword/title bindings.
            foreach(['decision','human_review_required','discovery_only','candidate_role'] as $field){
                if(array_key_exists($field,$prior))$candidate[$field]=$prior[$field];
            }
            $currentReasons=array_values(array_map('strval',(array)($candidate['reason_codes']??[])));
            $oldGateReasons=array_values(array_map('strval',(array)($previous['reason_codes']??[])));
            $ownBase=(array)($prior['reason_codes']??[]);
            $candidate['reason_codes']=array_values(array_unique(array_merge(
                $ownBase,array_values(array_diff($currentReasons,$oldGateReasons))
            )));
        }
        // A gate may not take over another owner's rejection. If its last result
        // no longer matches its own stored receipt, the old block remains.
        $ownerFields=$oldGateOwned?$prior:[
            'binding_sha256'=>$identity,
            'decision'=>(string)($candidate['decision']??''),
            'human_review_required'=>!empty($candidate['human_review_required']),
            'discovery_only'=>!empty($candidate['discovery_only']),
            'candidate_role'=>(string)($candidate['candidate_role']??''),
            'reason_codes'=>array_values(array_map('strval',(array)($candidate['reason_codes']??[]))),
        ];
        $gate=self::evaluate($candidate,$inventoryItems,$categoryItems);
        $gate['prior_owner_fields']=$ownerFields;
        $candidate['pre_title_duplicate_gate']=(array)$gate['pre_title_duplicate_gate'];
        $candidate['planning_readiness_gate']=$gate;
        $candidate['closest_existing_matches']=(array)$gate['matches'];
        $candidate['reason_codes']=array_values(array_unique(array_merge(
            (array)($candidate['reason_codes']??[]),(array)$gate['reason_codes'])));
        if(empty($gate['ok'])){
            $candidate['decision']='BLOCKED';
            $candidate['human_review_required']=true;
            $candidate['discovery_only']=true;
            $candidate['candidate_role']='DISCOVERY_PROBE';
        }
        if($before!==self::bindingSnapshot($candidate))throw new RuntimeException('PSTE_PLANNING_READINESS_GATE_BINDING_DRIFT');
        return $candidate;
    }

    /** @return array<string,mixed> */
    private static function preTitleDuplicate(string $query,array $inventory): array {
        $reasons=[];$matches=[];
        foreach($inventory as $item){
            if(!in_array((string)($item['status']??''),['publish','draft'],true))continue;
            $title=trim((string)($item['title']??''));if($title==='')continue;
            $existingKeyword=trim((string)($item['target_keyword']??$item['seo_target_keyword']??''));
            $exact=$existingKeyword!==''&&PSTE_Normalizer::exactTopicIdentityText($query)===PSTE_Normalizer::exactTopicIdentityText($existingKeyword);
            if($exact){$reasons[]='PRE_TITLE_EXACT_SEO_KEYWORD_DUPLICATE';$matches[]=['post_id'=>(int)($item['post_id']??0),'title'=>$title,'source'=>(string)($item['source']??'WORDPRESS_READ_ONLY'),'keyword_ownership_authority'=>'SEO_TOOL_EXPLICIT','keyword_ownership'=>[]];continue;}
            // KISS coverage guard: an active WordPress title may prove that the complete stored
            // source query is already covered even when legacy content has no explicit SEO keyword.
            // This never invents keyword ownership and never rewrites a title; it only prevents a
            // second article when the complete query phrase is already present in the published title.
            if(self::activeTitleContainsSourceQuery($query,$title)){
                $reasons[]='PRE_TITLE_ACTIVE_TITLE_CONTAINS_SOURCE_QUERY';
                $matches[]=['post_id'=>(int)($item['post_id']??0),'title'=>$title,'source'=>(string)($item['source']??'WORDPRESS_READ_ONLY'),'keyword_ownership_authority'=>'ACTIVE_TITLE_COVERAGE_ONLY','keyword_ownership'=>[]];
                continue;
            }
            // All non-exact keyword ownership and semantic equivalence are evaluated exactly
            // once by PSTE_Cannibalization::decide below, not by a parallel pre-title owner.
        }
        return ['contract'=>self::PRE_TITLE_CONTRACT,'ok'=>!$reasons,'reason_codes'=>array_values(array_unique($reasons)),'matches'=>array_slice($matches,0,8),'title_surface_longtail_authority'=>false,'write_attempted'=>false];
    }


    /**
     * Conservative active-title coverage check for legacy posts without stored SEO keywords.
     * Only the complete source-query token sequence may match; one-word heads never qualify.
     * The tiny filler list handles wording-only variants and is deliberately local so canonical
     * topic identities/hashes remain untouched.
     */
    private static function activeTitleContainsSourceQuery(string $query,string $title): bool {
        $queryTokens=self::coverageSurfaceTokens($query);
        $titleTokens=self::coverageSurfaceTokens($title);
        if(count($queryTokens)<2||count($titleTokens)<count($queryTokens))return false;
        $q=' '.implode(' ',$queryTokens).' ';
        $t=' '.implode(' ',$titleTokens).' ';
        return str_contains($t,$q);
    }

    /** @return list<string> */
    private static function coverageSurfaceTokens(string $value): array {
        $normalized=PSTE_Normalizer::exactTopicIdentityText($value);
        if($normalized==='')return [];
        $fillers=['du','eigentlich'];
        return array_values(array_filter(explode(' ',$normalized),static fn($token)=>$token!==''&&!in_array($token,$fillers,true)));
    }

    /** Fields that a readiness gate is never allowed to alter. */
    private static function bindingSnapshot(array $candidate): array {
        $out=[];foreach(['candidate_id','pool_key','target_keyword','target_keyword_contract','topic_family_key','topic_family_name','proposed_article_type','suggested_article_type','target_category_id','target_category_slug','target_category_name','canonical_query','primary_longtail_query','raw_user_question','editorial_intent_key','intent_profile','plan_slot','canonical_article_id','production_title','editorial_title'] as $f)if(array_key_exists($f,$candidate))$out[$f]=$candidate[$f];
        return $out;
    }
}
