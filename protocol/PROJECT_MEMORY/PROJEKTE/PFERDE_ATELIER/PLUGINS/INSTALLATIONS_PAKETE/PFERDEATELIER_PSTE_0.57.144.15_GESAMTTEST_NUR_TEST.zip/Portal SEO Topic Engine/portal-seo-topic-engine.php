<?php
/**
 * Plugin Name: Portal SEO Themenengine
 * Description: Einfacher Longtail-Workflow: recherchiert Suchphrasen, übernimmt Sprachtitel und ordnet ausschließlich vorhandene Portalkategorien zu und prüft gegen den eigenen Bestand. Verändert keine Beiträge, Inhalte, Gestaltung oder Textproduktionsregeln.
 * Version: 0.57.144.15
 * Requires PHP: 8.0
 * Author: Workflow Automation
 */
if (!defined('ABSPATH')) { return; }

define('PSTE_VERSION', '0.57.144.15');
define('PSTE_DIR', __DIR__ . '/');
define('PSTE_OPTION_SETTINGS', 'pste_settings_v1');
define('PSTE_OPTION_SCHEMA', 'pste_schema_version');
define('PSTE_OPTION_FIRST_PARTY', 'pste_first_party_queries_v1');
define('PSTE_OPTION_CREDENTIAL_LOGIN', 'pste_dataforseo_login_v1');
define('PSTE_OPTION_CREDENTIAL_PASSWORD', 'pste_dataforseo_password_v1');
define('PSTE_OPTION_SITE_BASELINE', 'pste_site_baseline_v1');
define('PSTE_OPTION_CONNECTION_STATUS', 'pste_connection_status_v1');
define('PSTE_OPTION_CATEGORY_WEIGHTS', 'pste_category_weights_v1');
define('PSTE_OPTION_GSC_CLIENT_ID', 'pste_gsc_client_id_v1');
define('PSTE_OPTION_GSC_CLIENT_SECRET', 'pste_gsc_client_secret_v1');
define('PSTE_OPTION_GSC_TOKEN_BUNDLE', 'pste_gsc_token_bundle_v1');
define('PSTE_OPTION_GSC_CONNECTION_STATUS', 'pste_gsc_connection_status_v1');
define('PSTE_OPTION_GSC_SITES_CACHE', 'pste_gsc_sites_cache_v1');
define('PSTE_OPTION_GSC_SELECTED_PROPERTY', 'pste_gsc_selected_property_v1');
define('PSTE_OPTION_GSC_LAST_SYNC', 'pste_gsc_last_sync_v1');
define('PSTE_OPTION_BUDGET_RESERVATIONS', 'pste_budget_reservations_v1');
define('PSTE_OPTION_BUDGET_LOCK', 'pste_budget_reservation_lock_v1');
define('PSTE_OPTION_EDITORIAL_PLAN_IMPORT', 'pste_editorial_plan_import_v1');
define('PSTE_OPTION_WORK_BATCHES', 'pste_work_batches_v1');
define('PSTE_OPTION_05749_TARGETED_REPAIR', 'pste_05749_targeted_repair_v1');
define('PSTE_OPTION_EDITORIAL_OWNERSHIP_IMPORT', 'pste_editorial_ownership_import_v1');
define('PSTE_OPTION_CONTEXT_JOB', 'pste_context_refresh_job_v1');
define('PSTE_OPTION_CONTEXT_LEASE', 'pste_context_refresh_lease_v1');
define('PSTE_OPTION_CONTEXT_FENCE', 'pste_context_refresh_fence_v1');
define('PSTE_OPTION_CONTEXT_DIAGNOSTICS_RING', 'pste_context_diagnostics_ring_v1');
define('PSTE_OPTION_CONTEXT_SNAPSHOT_BUNDLE', 'pste_context_snapshot_bundle_v1');
define('PSTE_OPTION_CONTEXT_STAGE_INVENTORY', 'pste_context_stage_inventory_v1');
define('PSTE_OPTION_CONTEXT_STAGE_PLAN', 'pste_context_stage_plan_v1');
define('PSTE_OPTION_CONTEXT_STAGE_REGISTRY', 'pste_context_stage_registry_v1');
define('PSTE_OPTION_CONTEXT_INDEX_MANIFEST', 'pste_context_index_manifest_v2');
define('PSTE_OPTION_CONTEXT_INDEX_BUILD', 'pste_context_index_build_v2');
define('PSTE_CONTEXT_INDEX_SHARD_PREFIX', 'pste_context_index_shard_v2_');
define('PSTE_OPTION_BOOT_STATUS', 'pste_boot_status_v1');
define('PSTE_OPTION_SAFE_MIGRATION_JOB', 'pste_safe_migration_job_v2');
define('PSTE_OPTION_SAFE_MIGRATION_STEP_LOCK', 'pste_safe_migration_step_lock_v2');
define('PSTE_OPTION_SAFE_MIGRATION_PROTOCOL', 'pste_safe_migration_protocol_v2');
define('PSTE_SAFE_MIGRATION_PROTOCOL', 'PSTE_SAFE_MIGRATION_PROTOCOL_V7_0310_ARTICLE_INTENT_TITLE_GATE');
define('PSTE_OPTION_EDITORIAL_RULESET', 'pste_editorial_ruleset_v1');
define('PSTE_OPTION_PRICE_INTENT_REPAIR', 'pste_price_intent_repair_0109_v1');
define('PSTE_OPTION_ACTIVE_RESEARCH_JOB', 'pste_active_longtail_research_job_v2');
define('PSTE_OPTION_RESEARCH_STEP_LOCK', 'pste_longtail_research_step_lock_v2');
define('PSTE_OPTION_RESEARCH_CONTROL_LOCK', 'pste_research_control_start_lock_v1');
define('PSTE_OPTION_BREADTH_RESEARCH_QUEUE', 'pste_breadth_research_queue_v1');
define('PSTE_OPTION_BREADTH_RESEARCH_CANCEL', 'pste_breadth_research_cancel_v1');
define('PSTE_OPTION_BREADTH_RESEARCH_LOCK', 'pste_breadth_research_queue_lock_v1');
define('PSTE_OPTION_RETAINED_BACKLOG_AUDIT', 'pste_retained_backlog_audit_v1');
define('PSTE_OPTION_EXISTING_EVIDENCE_BOOTSTRAP', 'pste_existing_evidence_bootstrap_v1');
define('PSTE_OPTION_RESEARCH_DRIVER_STATE', 'pste_research_driver_state_v1');
define('PSTE_OPTION_RESEARCH_DRIVER_LOCK', 'pste_research_driver_lock_v1');
define('PSTE_RESEARCH_DRIVER_CRON_HOOK', 'pste_research_driver_step_v1');
define('PSTE_RESEARCH_DRIVER_LOOPBACK_ACTION', 'pste_driver_loopback');
define('PSTE_OPTION_RESEARCH_PARKED_INDEX', 'pste_park_index');
define('PSTE_RESEARCH_PARKED_PREFIX', 'pste_park_');
define('PSTE_OPTION_LEGACY_LIVE_ARCHIVE', 'pste_legacy_live_archive_v1');
define('PSTE_OPTION_FAMILY_V2_DRY_RUN', 'pste_family_v2_dry_run_v1');
define('PSTE_OPTION_FAMILY_V2_AUTHORIZATION', 'pste_family_v2_apply_authorization_v1');
define('PSTE_OPTION_FAMILY_V2_APPLY', 'pste_family_v2_apply_v1');
define('PSTE_OPTION_FAMILY_V2_ROLLBACK', 'pste_family_v2_rollback_v1');
define('PSTE_OPTION_SEMANTIC_SANDBOX', 'pste_semantic_review_sandbox_v1');
define('PSTE_OPTION_SEMANTIC_SANDBOX_LOCK', 'pste_semantic_review_sandbox_lock_v1');
define('PSTE_OPTION_SANDBOX_RECORD_MANIFEST', 'pste_semantic_sandbox_record_manifest_v1');
define('PSTE_OPTION_SANDBOX_RUNTIME_INDEX', 'pste_semantic_sandbox_runtime_index_v1');
define('PSTE_SANDBOX_RECORD_PREFIX', 'pste_semantic_sandbox_record_v1_');
define('PSTE_CONTEXT_CRON_HOOK', 'pste_context_refresh_batch');
define('PSTE_SANDBOX_INTERNAL_RECHECK_CRON_HOOK', 'pste_sandbox_internal_recheck_daily');
define('PSTE_EDITORIAL_METADATA_REBUILD_CRON_HOOK', 'pste_editorial_metadata_rebuild_once');
define('PSTE_OPTION_EDITORIAL_REBUILD_MARKER', 'pste_editorial_metadata_rebuild_marker_v1');
define('PSTE_OPTION_EDITORIAL_REBUILD_REPORT', 'pste_editorial_metadata_rebuild_report_v1');
define('PSTE_OPTION_SANDBOX_MAINTENANCE_HEALTH', 'pste_sandbox_maintenance_health_v1');
define('PSTE_OPTION_STORAGE_MAINTENANCE_JOB', 'pste_storage_maintenance_job_v1');
define('PSTE_OPTION_STORAGE_MAINTENANCE_LOCK', 'pste_storage_maintenance_lock_v1');
define('PSTE_SCHEMA_VERSION', 12);

foreach ([
    'includes/class-pste-diagnostic-exception.php',
    'includes/class-pste-auth.php',
    'includes/class-pste-secret-store.php',
    'includes/class-pste-credentials.php',
    'includes/class-pste-gsc-credentials.php',
    'includes/class-pste-db-write-guard.php',
    'includes/class-pste-flight-recorder.php',
    'includes/class-pste-forensic-diagnostics.php',
    'includes/class-pste-clean-reset.php',
    'includes/class-pste-evidence-audit.php',
    'includes/class-pste-cost-guard.php',
    'includes/class-pste-budget-reservations.php',
    'includes/class-pste-dataforseo-client.php',
    'includes/class-pste-sandbox-seo-relevance.php',
    'includes/class-pste-sandbox-provider-error-policy.php',
    'includes/class-pste-gsc-client.php',
    'includes/class-pste-normalizer.php',
    'includes/class-pste-article-type-intent-ontology.php',
    'includes/class-pste-product-choice-classifier.php',
    'includes/class-pste-family-identity-v2.php',
    'includes/class-pste-family-structure-router.php',
    'includes/class-pste-token-equivalence.php',
    'includes/class-pste-portal-category-map.php',
    'includes/class-pste-journal-article-type.php',
    'includes/class-pste-article-type-extension-registry.php',
    'includes/class-pste-article-type-extension-router.php',
    'includes/class-pste-journal-semantic-router.php',
    'includes/class-pste-article-type-registry.php',
    'includes/class-pste-query-record.php',
    'includes/class-pste-family-membership.php',
    'includes/class-pste-semantic-retriever-a.php',
    'includes/class-pste-semantic-retriever-b.php',
    'includes/class-pste-semantic-classifier.php',
    'includes/class-pste-portal-relevance-gate.php',
    'includes/class-pste-intent-profile.php',
    'includes/class-pste-normal-metadata-path.php',
    'includes/class-pste-editorial-topic-normalizer.php',
    'includes/class-pste-title-validator.php',
    'includes/class-pste-german-title-reviewer.php',
    'includes/class-pste-editorial-quality-gate.php',
    'includes/class-pste-title-pipeline.php',
    'includes/class-pste-title-diversity.php',
    'includes/class-pste-sandbox-internal-planner.php',
    'includes/class-pste-type-fit-probe.php',
    'includes/class-pste-category-gap.php',
    'includes/class-pste-work-queue.php',
    'includes/class-pste-domain-risk-gate.php',
    'includes/class-pste-category-context.php',
    'includes/class-pste-sandbox-portal-relevance.php',
    'includes/class-pste-sandbox-record-contract.php',
    'includes/class-pste-sandbox-record-store.php',
    'includes/class-pste-editorializer.php',
    'includes/class-pste-mini-workflow.php',
    'includes/class-pste-topic-policy.php',
    'includes/class-pste-context-evaluator.php',
    'includes/class-pste-context-index-store.php',
    'includes/class-pste-context-diagnostics.php',
    'includes/class-pste-context-refresh.php',
    'includes/class-pste-snapshot.php',
    'includes/class-pste-first-party-import.php',
    'includes/class-pste-repository.php',
    'includes/class-pste-family-reclassification-v2.php',
    'includes/class-pste-semantic-review-sandbox.php',
    'includes/class-pste-sandbox-maintenance-health.php',
    'includes/class-pste-normal-reentry-coordinator.php',
    'includes/class-pste-safe-migration-job.php',
    'includes/class-pste-cannibalization.php',
    'includes/class-pste-article-ownership-gate.php',
    'includes/class-pste-planning-readiness-gate.php',
    'includes/class-pste-overlay.php',
    'includes/class-pste-runner.php',
    'includes/class-pste-research-archive.php',
    'includes/class-pste-research-job.php',
    'includes/class-pste-breadth-research-queue.php',
    'includes/class-pste-research-driver.php',
    'includes/class-pste-analytics.php',
    'includes/class-pste-compiler-read-capability.php',
    'includes/class-pste-admin.php',
    'includes/class-pste-plugin.php',
] as $relative) { require_once PSTE_DIR . $relative; }

register_activation_hook(__FILE__, ['PSTE_Plugin', 'activate']);
PSTE_Plugin::init();
