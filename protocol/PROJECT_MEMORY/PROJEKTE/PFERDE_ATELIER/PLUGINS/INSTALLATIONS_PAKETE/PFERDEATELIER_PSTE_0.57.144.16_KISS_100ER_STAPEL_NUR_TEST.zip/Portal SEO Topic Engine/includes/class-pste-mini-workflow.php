<?php
if (!defined('ABSPATH')) { return; }
/**
 * Isolierter TEST-Zwischenweg. Keine Änderung an K0, PSERC, Beiträgen oder der
 * bisherigen Fachlogik. Die semantischen Entscheidungen kommen nur von außen.
 */
final class PSTE_Mini_Workflow {
    private const STORE = 'pste_mini_keyword_roundtrip_v1';
    private const CONTRACT = 'PSTE_RAW_KEYWORD_MINI_BATCH_V1';
    private const LIMITS = [100, 500, 1000, 2000];

    public static function init(): void {
        add_action('admin_post_pste_mini_keyword_export', [self::class, 'exportKeywords']);
        add_action('admin_post_pste_mini_keyword_import', [self::class, 'importKeywords']);
        add_action('admin_post_pste_mini_keyword_cancel', [self::class, 'cancelActive']);
        add_action('admin_post_pste_mini_results_export', [self::class, 'exportResults']);
        add_action('admin_post_pste_mini_title_repair_import', [self::class, 'importTitleCorrections']);
        add_action('admin_post_pste_mini_manual_brief', [self::class, 'manualArticleBrief']);
        add_action('admin_post_pste_mini_forward_to_plan', [self::class, 'forwardToPlan']);
        add_action('admin_post_pste_mini_batch_report', [self::class, 'exportBatchReport']);
    }

    /** The unchanged existing PSTE governance is the sole source for both title desks. */
    private static function titleGovernance(): array {
        $raw=@file_get_contents(PSTE_DIR.'contracts/intent-first-title-governance-v1.json');
        if(!is_string($raw))throw new RuntimeException('PSTE_MINI_TITLE_RULES_UNAVAILABLE');
        $governance=json_decode($raw,true,128,JSON_THROW_ON_ERROR);
        if(!is_array($governance)||($governance['contract']??'')!=='PSTE_INTENT_FIRST_TITLE_GOVERNANCE_V1')
            throw new RuntimeException('PSTE_MINI_TITLE_RULES_INVALID');
        return $governance;
    }

    /** Only objective hard title checks here; linguistic naturalness belongs to the external language desk. */
    public static function validateTitleText(string $title): void {
        $title=trim($title);
        $length=function_exists('mb_strlen')?mb_strlen($title,'UTF-8'):strlen($title);
        if($length<8||$length>110)throw new RuntimeException('PSTE_MINI_TITLE_LENGTH_INVALID');
        if(str_contains($title,':'))throw new RuntimeException('PSTE_MINI_TITLE_COLON_FORBIDDEN');
        // The original title governance permits natural German, a dash and terminal questions.
        if(preg_match('/[^\p{L}\p{N}\s,?–-]/u',$title))throw new RuntimeException('PSTE_MINI_TITLE_SPECIAL_CHARACTER_FORBIDDEN');
        $questionCount=substr_count($title,'?');
        if($questionCount>1||($questionCount===1&&!str_ends_with($title,'?')))
            throw new RuntimeException('PSTE_MINI_TITLE_QUESTION_MUST_END_TITLE');
        if(preg_match('/\s{2,}|\b([\p{L}\d]+)\s+\1\b/iu',$title))
            throw new RuntimeException('PSTE_MINI_TITLE_REPEATED_OR_WHITESPACE');
        if(PSTE_Title_Validator::hasArtificialGeneratorPhrase($title)||
            PSTE_Title_Validator::hasForbiddenTitlePhraseFamily($title)||
            PSTE_Title_Validator::isRepeatedGenericBeratungSchema($title))
            throw new RuntimeException('PSTE_MINI_TITLE_ARTIFICIAL_STYLE_FORBIDDEN');
    }

    private static function loadState(): array {
        $state=get_option(self::STORE, []);
        if(!is_array($state))throw new RuntimeException('PSTE_MINI_STATE_DAMAGED');
        $state += ['completed'=>[], 'active'=>null, 'last_report'=>[]];
        if(!is_array($state['completed'])||(!is_null($state['active'])&&!is_array($state['active'])))
            throw new RuntimeException('PSTE_MINI_STATE_DAMAGED');
        return $state;
    }
    private static function storeState(array $state): void {
        if(!update_option(self::STORE, $state, false)) {
            $read=get_option(self::STORE, null);
            if($read!==$state)throw new RuntimeException('PSTE_MINI_STATE_WRITE_FAILED');
        }
        if(get_option(self::STORE, null)!==$state)throw new RuntimeException('PSTE_MINI_STATE_READBACK_FAILED');
    }
    private static function sendJson(array $document, string $name): void {
        $raw=wp_json_encode($document,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
        if(!is_string($raw))throw new RuntimeException('PSTE_MINI_JSON_ENCODING_FAILED');
        nocache_headers();header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="'.$name.'"');
        header('Content-Length: '.strlen($raw));echo $raw;exit;
    }
    private static function fail(Throwable $e): void {wp_die('Mini-Workflow: '.esc_html($e->getMessage()));}

    public static function renderKeywords(): void {
        $state=self::loadState();$active=$state['active'];$last=(array)$state['last_report'];
        echo '<section class="pste-box"><h3>NEU · Rohkeywords extern prüfen (Testweg)</h3>';
        echo '<p>Alle bisher nicht in diesem Mini-Workflow abgeschlossenen Keywords – ohne inhaltliche Vorauswahl. Ein Stapel zurzeit. Erst Rückimport beendet ihn. Alte Titelwerkstatt bleibt unverändert.</p>';
        echo '<p><strong>Erledigte Keywords:</strong> '.esc_html((string)count($state['completed'])).' · <strong>Offener Stapel:</strong> '.esc_html((string)(is_array($active)?count((array)($active['items']??[])):0)).'</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_mini_keyword_export');
        echo '<input type="hidden" name="action" value="pste_mini_keyword_export"><label>Keywords pro Stapel <select name="mini_limit">';
        foreach(self::LIMITS as $limit)echo '<option value="'.(int)$limit.'"'.($limit===100?' selected':'').'>'.(int)$limit.'</option>';
        echo '</select></label> <button class="button button-primary" type="submit">'.($active?'Offenen Stapel erneut herunterladen':'Rohkeywords exportieren').'</button></form>';
        if($active){
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:9px">';wp_nonce_field('pste_mini_keyword_cancel');
            echo '<input type="hidden" name="action" value="pste_mini_keyword_cancel"><button class="button" type="submit" onclick="return confirm(\'Offenen Stapel verwerfen? Seine Keywords werden erneut exportierbar.\')">Stapel abbrechen (Keywords wieder offen)</button></form>';
        }
        echo '<form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:10px">';wp_nonce_field('pste_mini_keyword_import');
        echo '<input type="hidden" name="action" value="pste_mini_keyword_import"><label>Ergebnisdatei <input type="file" name="mini_result_json" accept=".json,application/json" required></label> <button class="button" type="submit">Ergebnisse übernehmen</button></form>';
        if($state['completed']){
            echo '<form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:9px">';wp_nonce_field('pste_mini_title_repair_import');
            echo '<input type="hidden" name="action" value="pste_mini_title_repair_import"><label>Korrigierte Titeldatei <input type="file" name="mini_corrected_titles_json" accept=".json,application/json" required></label> <button class="button" type="submit">Titelkorrekturen übernehmen</button></form>';
            echo '<p><small>Nur Titel dürfen geändert werden. Relevanz, Keywords, Suchabsichten und Kennungen bleiben erhalten. Die Titelqualität wurde extern geprüft.</small></p>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:9px">';wp_nonce_field('pste_mini_forward_to_plan');
            echo '<input type="hidden" name="action" value="pste_mini_forward_to_plan"><button class="button button-primary" type="submit">'.(!empty($state['plan_queued'])?'Bereits übergebene Titel nach Plugin-Update erneut prüfen':'Geprüfte Titel an bestehende Themenplanung übergeben').'</button></form>';
            if(is_array($state['last_plan_report']??null))echo '<p><small>Letzte Übergabe: '.esc_html((string)($state['last_plan_report']['forwarded']??0)).' Titel neu übernommen, '.esc_html((string)($state['last_plan_report']['scheduled']??0)).' zur Prüfung eingeplant, '.esc_html((string)($state['last_plan_report']['blocked']??0)).' zurückgestellt, '.esc_html((string)($state['last_plan_report']['additional']??0)).' weitere Ideen im Zwischenspeicher.</small></p>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:9px">';wp_nonce_field('pste_mini_results_export');
            echo '<input type="hidden" name="action" value="pste_mini_results_export"><button class="button" type="submit">Gespeicherte Entscheidungen und Titelideen exportieren</button></form>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:9px">';wp_nonce_field('pste_mini_batch_report');
            echo '<input type="hidden" name="action" value="pste_mini_batch_report"><button class="button" type="submit">Nur aktuellen Stapelbericht herunterladen (max. 100)</button></form>';
        }
        if($last)echo '<p><small>Letzter Import: '.esc_html((string)($last['keywords']??0)).' Keywords, '.esc_html((string)($last['titles']??0)).' Titelideen gespeichert. Keine Produktionsfreigabe.</small></p>';
        echo '</section>';
    }

    /** Existing read-only result owner; no 5,000-topic or 20,000-event scan. */
    public static function exportBatchReport(): void {
        try{
            PSTE_Auth::assertAdmin('pste_mini_batch_report',(string)($_POST['_wpnonce']??''));
            if(!class_exists('PSTE_Admin'))throw new RuntimeException('PSTE_MINI_REPORT_OWNER_MISSING');
            self::sendJson(['contract'=>'PSTE_MINI_CURRENT_BATCH_REPORT_V1',
                'generated_utc'=>gmdate('c'),'read_only'=>true,'pste_version'=>PSTE_VERSION,
                'title_desk_reentry'=>PSTE_Admin::titleDeskReentryDiagnostics()],
                'pste-stapelbericht-'.gmdate('Y-m-d').'.json');
        }catch(Throwable $e){self::fail($e);}
    }

    public static function exportResults(): void {
        try {
            PSTE_Auth::assertAdmin('pste_mini_results_export',(string)($_POST['_wpnonce']??''));
            $state=self::loadState();
            self::sendJson(['contract'=>'PSTE_MINI_RESULTS_FOR_EDITORIAL_V1','created_utc'=>gmdate('c'),
                'count'=>count($state['completed']),'items'=>array_values($state['completed']),
                'status'=>'STAGED_NOT_EDITORIALLY_APPROVED',
                'note'=>'Dies sind externe Relevanzentscheidungen und Titelideen. Kein Artikelbedarf, kein freier Parkplatz und keine Kannibalisierungsfreiheit wurde hier festgestellt.'],
                'pferdeatelier-mini-ergebnisse-'.gmdate('Ymd-His').'.json');
        }catch(Throwable $e){self::fail($e);}
    }

    public static function cancelActive(): void {
        try {
            PSTE_Auth::assertAdmin('pste_mini_keyword_cancel',(string)($_POST['_wpnonce']??''));
            $state=self::loadState();$state['active']=null;self::storeState($state);
            wp_safe_redirect(admin_url('admin.php?page=portal-seo-topic-engine-review&pste_mini_cancelled=1'));exit;
        }catch(Throwable $e){self::fail($e);}
    }

    /** Only source ID and original query are transported. No relevance filter. */
    public static function selectNewRows(callable $readPage, array $completed, int $limit): array {
        if(!in_array($limit,self::LIMITS,true))throw new RuntimeException('PSTE_MINI_LIMIT_INVALID');
        $items=[];$cursor=0;$invalid=0;$seen=[];$pages=0;
        do {
            $rows=$readPage($cursor, 500);
            if(!is_array($rows))throw new RuntimeException('PSTE_MINI_SOURCE_READ_FAILED');
            foreach($rows as $row){
                $id=(int)($row['id']??0);$key=trim((string)($row['pool_key']??''));
                if($id<=$cursor||$key==='')throw new RuntimeException('PSTE_MINI_SOURCE_ORDER_OR_ID_INVALID');
                $cursor=$id;
                if(isset($completed[$key])||isset($seen[$key]))continue;
                $seen[$key]=true;
                $payload=json_decode((string)($row['payload_json']??''),true);
                $raw=is_array($payload)?PSTE_Editorializer::sourceQuery($payload):'';
                if($raw===''){$invalid++;continue;}
                $items[]=['id'=>$id,'pool_key'=>$key,'raw_query'=>$raw,
                    'source_sha256'=>hash('sha256',$id.'|'.$key.'|'.$raw),
                    'decision'=>'','titles'=>[]];
                if(count($items)===$limit)break;
            }
            if(count($items)===$limit||count($rows)<500)break;
            $pages++;
            if($pages>20000)throw new RuntimeException('PSTE_MINI_SOURCE_SCAN_LIMIT');
        }while(true);
        return ['items'=>$items,'skipped_invalid'=>$invalid,'last_scanned_id'=>$cursor];
    }

    public static function createBatch(array $selected, string $batchId): array {
        if(!is_array($selected['items']??null)||!$selected['items'])throw new RuntimeException('PSTE_MINI_NO_OPEN_KEYWORDS');
        if(!preg_match('/^[a-zA-Z0-9_-]{6,100}$/',$batchId))throw new RuntimeException('PSTE_MINI_BATCH_ID_INVALID');
        return ['contract'=>self::CONTRACT,'batch_id'=>$batchId,'created_utc'=>gmdate('c'),
            'instruction'=>'Worker 1 entscheidet JA/NEIN/VIELLEICHT. Nur JA geht an Worker 2. Worker 2 kann mehrere sachlich verschiedene Suchabsichten mit je einem Titel vorschlagen. TITELREGELN BINDEND: natuerliche deutsche Formulierungen, niemals Doppelpunkte, keine Aufzaehlungs-/Keyword-Schablonen, keine kuenstlichen Floskeln; Fragezeichen nur am Ende eines Fragetitels; Suchintention erhalten. Die bestehende title_governance beachten. Keine Kannibalisierungs- oder Produktionsfreigabe durch Worker. Nur decision und titles bearbeiten; alle anderen Felder unveraendert lassen. Bei NEIN/VIELLEICHT titles leer.',
            'title_governance'=>self::titleGovernance(),
            'skipped_invalid_source_count'=>(int)($selected['skipped_invalid']??0),
            'items'=>$selected['items']];
    }

    private static function readRawRows(int $cursor,int $limit): array {
        global $wpdb;$table=PSTE_Repository::table('topic_pool');
        $query=$wpdb->prepare("SELECT id,pool_key,payload_json FROM $table WHERE id>%d ORDER BY id ASC LIMIT %d",$cursor,$limit);
        $rows=$wpdb->get_results($query,ARRAY_A);
        if(!is_array($rows)||(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_MINI_SOURCE_READ_FAILED');
        return $rows;
    }
    public static function exportKeywords(): void {
        try {
            PSTE_Auth::assertAdmin('pste_mini_keyword_export',(string)($_POST['_wpnonce']??''));
            $limit=(int)($_POST['mini_limit']??0);
            if(!in_array($limit,self::LIMITS,true))throw new RuntimeException('PSTE_MINI_LIMIT_INVALID');
            $state=self::loadState();
            if(is_array($state['active']))$batch=$state['active'];
            else {
                $selected=self::selectNewRows(static fn(int $cursor,int $size): array=>self::readRawRows($cursor,$size),$state['completed'],$limit);
                $batch=self::createBatch($selected,'mini-'.gmdate('YmdHis').'-'.substr(bin2hex(random_bytes(6)),0,12));
                $state['active']=$batch;self::storeState($state); // A lost download is retryable.
            }
            self::sendJson($batch,'pferdeatelier-rohkeywords-'.$batch['batch_id'].'.json');
        } catch(Throwable $e){self::fail($e);}
    }

    /** Pure preflight: the stored export is the sole source of truth, not the uploaded file. */
    public static function validateResult(array $original,array $received,callable $loadCurrent): array {
        if(($original['contract']??'')!==self::CONTRACT||($received['contract']??'')!==self::CONTRACT||
            ($original['batch_id']??'')!==($received['batch_id']??''))throw new RuntimeException('PSTE_MINI_WRONG_BATCH');
        // Existing exports without governance remain importable, but every new title must pass.
        if(array_key_exists('title_governance',$received)&&$received['title_governance']!==self::titleGovernance())
            throw new RuntimeException('PSTE_MINI_TITLE_RULES_CHANGED');
        $before=$original['items']??null;$after=$received['items']??null;
        if(!is_array($before)||!is_array($after)||count($before)!==count($after)||!array_is_list($after))
            throw new RuntimeException('PSTE_MINI_ITEM_COUNT_CHANGED');
        $finished=[];$stats=['JA'=>0,'NEIN'=>0,'VIELLEICHT'=>0,'titles'=>0];
        foreach($before as $i=>$frozen){
            $item=$after[$i]??null;
            if(!is_array($item))throw new RuntimeException('PSTE_MINI_ITEM_INVALID');
            $keys=array_keys($item);sort($keys);$allowed=array_keys($frozen);sort($allowed);
            if($keys!==$allowed)throw new RuntimeException('PSTE_MINI_ITEM_FIELDS_CHANGED');
            foreach(['id','pool_key','raw_query','source_sha256'] as $field){
                if(!array_key_exists($field,$item)||$item[$field]!==$frozen[$field])
                    throw new RuntimeException('PSTE_MINI_SOURCE_CHANGED_'.$field);
            }
            $current=$loadCurrent((string)$frozen['pool_key']);
            $payload=is_array($current)?json_decode((string)($current['payload_json']??''),true):null;
            $raw=is_array($payload)?PSTE_Editorializer::sourceQuery($payload):'';
            $actual=hash('sha256',(int)($current['id']??0).'|'.(string)($current['pool_key']??'').'|'.$raw);
            if(!is_array($current)||!hash_equals((string)$frozen['source_sha256'],$actual))
                throw new RuntimeException('PSTE_MINI_DATABASE_SOURCE_CHANGED');
            $decision=$item['decision']??null;
            if(!is_string($decision)||!in_array($decision,['JA','NEIN','VIELLEICHT'],true))
                throw new RuntimeException('PSTE_MINI_DECISION_REQUIRED');
            $titles=$item['titles']??null;
            if(!is_array($titles)||!array_is_list($titles))throw new RuntimeException('PSTE_MINI_TITLES_INVALID');
            if($decision!=='JA'&&$titles)throw new RuntimeException('PSTE_MINI_NON_JA_HAS_TITLES');
            if($decision==='JA'&&!$titles)throw new RuntimeException('PSTE_MINI_JA_WITHOUT_TITLE');
            $clean=[];
            foreach($titles as $title){
                if(!is_array($title)||count($title)!==2||!array_key_exists('intent',$title)||!array_key_exists('title',$title)||!is_string($title['intent'])||!is_string($title['title']))
                    throw new RuntimeException('PSTE_MINI_TITLE_SHAPE_INVALID');
                $intent=trim($title['intent']);$text=trim($title['title']);
                // A second linguistic/title quality gate is forbidden here.
                // Source identity and safe transport are validated below.
                if($intent===''||$text===''||strlen($intent)>240||strlen($text)>300||
                    preg_match('/[<>\x00-\x1f\x7f]/u',$intent.$text))throw new RuntimeException('PSTE_MINI_TITLE_TEXT_INVALID');
                $clean[]=['intent'=>$intent,'title'=>$text];
            }
            $finished[(string)$frozen['pool_key']]=['raw_query'=>$frozen['raw_query'],'decision'=>$decision,'titles'=>$clean,
                'batch_id'=>$original['batch_id'],'recorded_utc'=>gmdate('c')];
            $stats[$decision]++;$stats['titles']+=count($clean);
        }
        return ['completed'=>$finished,'stats'=>$stats];
    }

    /** Replaces only title strings for an already imported batch; everything else stays frozen. */
    public static function validateTitleCorrections(array $completed,array $document): array {
        if(($document['contract']??'')!=='PSTE_MINI_RESULTS_FOR_EDITORIAL_V1')
            throw new RuntimeException('PSTE_MINI_TITLE_REPAIR_WRONG_CONTRACT');
        $rows=$document['items']??null;$original=array_values($completed);
        if(!is_array($rows)||!array_is_list($rows)||count($rows)!==count($original)||
           ($document['count']??null)!==count($original))
            throw new RuntimeException('PSTE_MINI_TITLE_REPAIR_COUNT_CHANGED');
        $new=$completed;$keys=array_keys($completed);$updated=0;
        foreach($rows as $i=>$candidate){
            $saved=$original[$i];
            if(!is_array($candidate)||!array_is_list($candidate['titles']??null))
                throw new RuntimeException('PSTE_MINI_TITLE_REPAIR_SHAPE_INVALID');
            $skeleton=$saved;$proposed=$candidate;
            unset($skeleton['titles'],$proposed['titles']);
            if($skeleton!==$proposed)throw new RuntimeException('PSTE_MINI_TITLE_REPAIR_FROZEN_FIELDS_CHANGED');
            if(count($candidate['titles'])!==count($saved['titles']))
                throw new RuntimeException('PSTE_MINI_TITLE_REPAIR_INTENT_COUNT_CHANGED');
            $repaired=[];
            foreach($candidate['titles'] as $j=>$piece){
                if(!is_array($piece)||array_keys($piece)!==array_keys($saved['titles'][$j])||
                   !is_string($piece['title']??null)||($piece['intent']??null)!==$saved['titles'][$j]['intent'])
                    throw new RuntimeException('PSTE_MINI_TITLE_REPAIR_INTENT_CHANGED');
                $title=trim($piece['title']);
                if($title===''||strlen($title)>300||preg_match('/[<>\x00-\x1f\x7f]/u',$title))
                    throw new RuntimeException('PSTE_MINI_TITLE_REPAIR_TRANSPORT_INVALID');
                if($title!==$saved['titles'][$j]['title'])$updated++;
                $repaired[]=['intent'=>$piece['intent'],'title'=>$title];
            }
            $new[$keys[$i]]['titles']=$repaired;
        }
        return ['completed'=>$new,'title_changes'=>$updated];
    }

    public static function importTitleCorrections(): void {
        try {
            PSTE_Auth::assertAdmin('pste_mini_title_repair_import',(string)($_POST['_wpnonce']??''));
            $upload=(array)($_FILES['mini_corrected_titles_json']??[]);$path=(string)($upload['tmp_name']??'');
            if((int)($upload['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||$path===''||!is_uploaded_file($path)||
                (int)($upload['size']??0)>5000000)throw new RuntimeException('PSTE_MINI_TITLE_REPAIR_UPLOAD_INVALID');
            $raw=file_get_contents($path);if(!is_string($raw))throw new RuntimeException('PSTE_MINI_TITLE_REPAIR_READ_FAILED');
            $doc=json_decode($raw,true,128,JSON_THROW_ON_ERROR);
            if(!is_array($doc))throw new RuntimeException('PSTE_MINI_TITLE_REPAIR_INVALID');
            $state=self::loadState();
            $result=self::validateTitleCorrections($state['completed'],$doc);
            $state['completed']=$result['completed'];
            $state['last_title_repair']=['changes'=>$result['title_changes'],'recorded_utc'=>gmdate('c')];
            self::storeState($state);
            wp_safe_redirect(admin_url('admin.php?page=portal-seo-topic-engine-review&pste_mini_title_repaired=1'));exit;
        }catch(Throwable $e){self::fail($e);}
    }

    public static function importKeywords(): void {
        try {
            PSTE_Auth::assertAdmin('pste_mini_keyword_import',(string)($_POST['_wpnonce']??''));
            $state=self::loadState();$batch=$state['active'];
            if(!is_array($batch))throw new RuntimeException('PSTE_MINI_NO_ACTIVE_BATCH');
            $upload=(array)($_FILES['mini_result_json']??[]);$path=(string)($upload['tmp_name']??'');
            if((int)($upload['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||$path===''||!is_uploaded_file($path)||
                (int)($upload['size']??0)>2500000)throw new RuntimeException('PSTE_MINI_UPLOAD_INVALID');
            $raw=file_get_contents($path);if(!is_string($raw))throw new RuntimeException('PSTE_MINI_UPLOAD_FAILED');
            $result=json_decode($raw,true,128,JSON_THROW_ON_ERROR);
            if(!is_array($result))throw new RuntimeException('PSTE_MINI_RESULT_INVALID');
            global $wpdb;$table=PSTE_Repository::table('topic_pool');
            // Max. 20 kurze SQL-Abfragen statt bis zu 2.000 Einzelabfragen.
            $currentRows=[];
            foreach(array_chunk((array)$batch['items'],100) as $part){
                $ids=array_map(static fn(array $item): int=>(int)$item['id'],$part);
                $placeholders=implode(',',array_fill(0,count($ids),'%d'));
                $sql=$wpdb->prepare("SELECT id,pool_key,payload_json FROM $table WHERE id IN ($placeholders)",...$ids);
                $rows=$wpdb->get_results($sql,ARRAY_A);
                if(!is_array($rows)||(string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_MINI_DATABASE_READ_FAILED');
                foreach($rows as $row){
                    $key=(string)$row['pool_key'];
                    if(isset($currentRows[$key]))throw new RuntimeException('PSTE_MINI_SOURCE_DUPLICATE');
                    $currentRows[$key]=$row;
                }
            }
            $checked=self::validateResult($batch,$result,static fn(string $key): ?array=>$currentRows[$key]??null);
            foreach($checked['completed'] as $key=>$value){
                if(isset($state['completed'][$key]))throw new RuntimeException('PSTE_MINI_KEY_ALREADY_COMPLETED');
                $state['completed'][$key]=$value;
            }
            $state['active']=null;
            $state['last_report']=['keywords'=>count($checked['completed']),'titles'=>(int)$checked['stats']['titles'],
                'breakdown'=>$checked['stats'],'recorded_utc'=>gmdate('c')];
            self::storeState($state); // Titles staged only. Existing plan owner not invoked.
            wp_safe_redirect(admin_url('admin.php?page=portal-seo-topic-engine-review&pste_mini_imported=1'));exit;
        } catch(Throwable $e){self::fail($e);}
    }

    /**
     * No second quality or SEO decision. One existing pool row has one language title;
     * extra distinct intent suggestions stay in the MINI result until the existing
     * editorial owner creates a distinct plan identity. Nothing is lost or fanned out.
     * This preflight MUST finish before the first write.
     */
    public static function planHandoffPreflight(array $completed, callable $loadCurrent): array {
        $selected=[];$additional=0;$nonYes=0;
        foreach($completed as $poolKey=>$result){
            if(!is_array($result)||!in_array($result['decision']??null,['JA','NEIN','VIELLEICHT'],true))
                throw new RuntimeException('PSTE_MINI_PLAN_DECISION_MISSING');
            if($result['decision']!=='JA'){$nonYes++;continue;}
            if(!is_array($result['titles']??null)||!array_is_list($result['titles'])||!$result['titles'])
                throw new RuntimeException('PSTE_MINI_PLAN_TITLE_MISSING');
            $row=$loadCurrent((string)$poolKey);
            if(!is_array($row)||(string)($row['pool_key']??'')!==(string)$poolKey)
                throw new RuntimeException('PSTE_MINI_PLAN_SOURCE_MISSING');
            $payload=json_decode((string)($row['payload_json']??''),true);
            $raw=is_array($payload)?PSTE_Editorializer::sourceQuery($payload):'';
            if($raw===''||!hash_equals((string)($result['raw_query']??''),$raw))
                throw new RuntimeException('PSTE_MINI_PLAN_RAW_QUERY_CHANGED');
            $first=$result['titles'][0];
            if(!is_array($first)||!is_string($first['title']??null)||trim($first['title'])===''||
               preg_match('/[<>\x00-\x1f\x7f]/u',(string)$first['title']))
                throw new RuntimeException('PSTE_MINI_PLAN_TRANSPORT_INVALID');
            $selected[]=['pool_key'=>(string)$poolKey,'raw_query'=>$raw,
                'title'=>(string)$first['title'],
                'batch_id'=>(string)($result['batch_id']??''),
                'source_hash'=>hash('sha256',$raw.'|'.(string)$first['title'])];
            $additional+=count($result['titles'])-1;
        }
        if(!$selected)throw new RuntimeException('PSTE_MINI_PLAN_NO_YES_TITLES');
        return ['selected'=>$selected,'additional'=>$additional,'not_yes'=>$nonYes];
    }

    /** Hand-off to EXISTING PSTE title-storage and its ONE category/SEO owner. */
    public static function forwardToPlan(): void {
        try {
            PSTE_Auth::assertAdmin('pste_mini_forward_to_plan',(string)($_POST['_wpnonce']??''));
            if(!class_exists('PSTE_Admin')||!class_exists('PSTE_Repository'))
                throw new RuntimeException('PSTE_MINI_PLAN_OWNER_MISSING');
            $state=self::loadState();
            if(is_array($state['active'])||!$state['completed'])
                throw new RuntimeException('PSTE_MINI_PLAN_UNFINISHED_BATCH');
            global $wpdb;
            $table=PSTE_Repository::table('topic_pool');
            $keys=array_keys($state['completed']);$current=[];
            foreach(array_chunk($keys,100) as $part){
                $placeholder=implode(',',array_fill(0,count($part),'%s'));
                $rows=$wpdb->get_results($wpdb->prepare(
                    "SELECT pool_key,payload_json FROM $table WHERE pool_key IN ($placeholder)",...$part),ARRAY_A);
                if(!is_array($rows)||(string)($wpdb->last_error??'')!=='')
                    throw new RuntimeException('PSTE_MINI_PLAN_DATABASE_READ_FAILED');
                foreach($rows as $row){
                    $key=(string)($row['pool_key']??'');
                    if($key===''||isset($current[$key]))throw new RuntimeException('PSTE_MINI_PLAN_SOURCE_DUPLICATE');
                    $current[$key]=$row;
                }
            }
            $pre=self::planHandoffPreflight($state['completed'],
                static fn(string $key): ?array=>$current[$key]??null);
            $previous=is_array($state['plan_forwarded']??null)?$state['plan_forwarded']:[];
            $queued=is_array($state['plan_queued']??null)?$state['plan_queued']:[];
            $toQueue=[];$forwarded=0;$blocked=[];
            foreach($pre['selected'] as $item){
                $key=$item['pool_key'];
                try {
                    // The already authenticated MINI import owns the relevance JA/NEIN vote.
                    // Reuse its JA as a SOURCE-BOUND relevance receipt; not a family,
                    // category, planning or production approval. Never rerun that vote.
                    $external=['contract'=>'PSTE_MINI_RESULTS_FOR_EDITORIAL_V1',
                        'status'=>'RELEVANT_FOR_PORTAL','decision_source'=>'PSTE_MINI_ADMIN_IMPORT',
                        'batch_id'=>$item['batch_id']];
                    $proof=PSTE_Portal_Relevance_Gate::proofFromExternal($external,$item['raw_query']);
                    $out=PSTE_Repository::saveManualTitleOverride($key,$item['title'],get_current_user_id(),$proof);
                    if(($out['contract']??'')!=='PSTE_MANUAL_TITLE_OVERRIDE_RESULT_V1'||($out['status']??'')!=='PASS')
                        throw new RuntimeException('PSTE_MINI_PLAN_TITLE_WRITE_NOT_CONFIRMED');
                    if(($previous[$key]??'')!==$item['source_hash']){
                        $previous[$key]=$item['source_hash'];
                        $state['plan_forwarded']=$previous;
                        self::storeState($state); // checkpoint BEFORE queuing; retry resumes
                        $forwarded++;
                    }
                    // Recheck unchanged titles once after a code update, without rewriting the titles.
                    if(($queued[$key]??'')!==$item['source_hash'].'|'.PSTE_VERSION)$toQueue[$key]=$item['source_hash'];
                }catch(Throwable $e){$blocked[]=['pool_key'=>$key,
                    'reason_code'=>substr((string)preg_replace('/[^A-Z0-9_:\-]/i','_',strtoupper($e->getMessage())),0,140)];}
            }
            $scheduled=0;
            if($toQueue){
                $scheduled=PSTE_Admin::scheduleTitleDeskReentry(array_keys($toQueue),true);
                if($scheduled<=0)throw new RuntimeException('PSTE_MINI_PLAN_REENTRY_NOT_QUEUED');
                foreach($toQueue as $key=>$hash)$queued[$key]=$hash.'|'.PSTE_VERSION;
                $state['plan_queued']=$queued;
                self::storeState($state);
            }
            if($scheduled&&function_exists('set_transient')&&function_exists('get_transient')){
                $oldReport=get_transient('pste_title_desk_reentry_report');
                $existing=is_array($oldReport)?$oldReport:[];
                if(!$existing||$scheduled===count($toQueue))
                    $existing=['scheduled'=>$scheduled,'processed'=>0,'held'=>0,'blocked'=>[]];
                else $existing['scheduled']=max((int)($existing['scheduled']??0),$scheduled);
                set_transient('pste_title_desk_reentry_report',$existing,86400);
            }
            $state['last_plan_report']=['forwarded'=>$forwarded,'blocked'=>count($blocked),
                'held'=>$blocked,'additional'=>$pre['additional'],
                'not_yes'=>$pre['not_yes'],'scheduled'=>$scheduled,
                'recorded_utc'=>gmdate('c'),'production_approval'=>false];
            self::storeState($state);
            if($scheduled)PSTE_Admin::processTitleDeskReentry();
            wp_safe_redirect(admin_url('admin.php?page=portal-seo-topic-engine-review&pste_mini_to_plan=1'));exit;
        }catch(Throwable $e){self::fail($e);}
    }

    public static function renderManualBrief(): void {
        echo '<section class="pste-box"><h3>NEU · Manueller Schreibauftrag (Übergang, ohne K0)</h3>';
        echo '<p>Ein einzelnes Thema für die externe Artikelerstellung ausgeben – mit einer Bestandsübersicht für den redaktionellen Abgleich. Noch keine automatische Planfreigabe und kein WordPress-Beitrag.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_mini_manual_brief');
        echo '<input type="hidden" name="action" value="pste_mini_manual_brief">';
        echo '<p><label>Thema / gewünschter Titel<br><input type="text" name="manual_topic" style="width:100%;max-width:580px" maxlength="250" required></label></p>';
        echo '<p><label>Zielkeyword<br><input type="text" name="manual_keyword" style="width:100%;max-width:580px" maxlength="200" required></label></p>';
        echo '<p><button class="button" type="submit">Schreibauftrag mit Artikelbestand exportieren</button></p></form></section>';
    }

    /** Read-only inventory: never claim semantic duplicate clearance. */
    public static function manualArticleBrief(): void {
        try {
            PSTE_Auth::assertAdmin('pste_mini_manual_brief',(string)($_POST['_wpnonce']??''));
            $topic=trim(sanitize_text_field((string)($_POST['manual_topic']??'')));
            $keyword=trim(sanitize_text_field((string)($_POST['manual_keyword']??'')));
            if($topic===''||$keyword===''||strlen($topic)>250||strlen($keyword)>200)
                throw new RuntimeException('PSTE_MINI_MANUAL_TOPIC_REQUIRED');
            global $wpdb;
            $postsTable=$wpdb->posts;$pool=PSTE_Repository::table('topic_pool');
            $posts=$wpdb->get_results("SELECT ID,post_title,post_status FROM $postsTable WHERE post_type='post' AND post_status IN ('publish','future','draft','pending','private') ORDER BY ID DESC LIMIT 1201",ARRAY_A);
            if(!is_array($posts))throw new RuntimeException('PSTE_MINI_MANUAL_POSTS_UNAVAILABLE');
            $plans=$wpdb->get_results("SELECT pool_key,payload_json FROM $pool WHERE planning_suitability='YES' ORDER BY id DESC LIMIT 1201",ARRAY_A);
            if(!is_array($plans))throw new RuntimeException('PSTE_MINI_MANUAL_PLAN_UNAVAILABLE');
            $postComplete=count($posts)<=1200;$planComplete=count($plans)<=1200;
            $existing=[];
            foreach(array_slice($posts,0,1200) as $p){$existing[]=['post_id'=>(int)$p['ID'],'title'=>(string)$p['post_title'],'status'=>(string)$p['post_status']];}
            $scheduled=[];$missingPlanTitles=0;
            foreach(array_slice($plans,0,1200) as $p){
                $meta=json_decode((string)($p['payload_json']??''),true);
                if(!is_array($meta))throw new RuntimeException('PSTE_MINI_MANUAL_PLAN_PAYLOAD_INVALID');
                $title=PSTE_Editorializer::displayTitle($meta);
                if($title!=='')$scheduled[]=['pool_key'=>(string)$p['pool_key'],'title'=>$title];
                else $missingPlanTitles++;
            }
            self::sendJson(['contract'=>'PSTE_MANUAL_ARTICLE_BRIEF_V1','created_utc'=>gmdate('c'),
                'manual_request'=>['topic'=>$topic,'target_keyword'=>$keyword],
                'existing_wordpress_posts'=>$existing,'planned_pste_titles'=>$scheduled,
                'inventory_complete'=>['posts'=>$postComplete,'pste_plan'=>$planComplete&&$missingPlanTitles===0],
                'planned_rows_without_titles'=>$missingPlanTitles,
                'coverage_note'=>'PSERC-eigene Planstaende und semantische Doppelungen sind mit diesen Listen NICHT abschliessend geprueft.', 
                'status'=>'EDITORIAL_CHECK_REQUIRED',
                'instruction'=>'Vor der Artikelerstellung bestehende und geplante Texte auf dieselbe Suchabsicht pruefen. Dies ist ein manueller Zwischenweg ohne K0, keine automatische Dubletten-/Planfreigabe. Nur bei freiem eigenstaendigem Thema Artikel nach den bestehenden redaktionellen Regeln erstellen. WordPress-Aufnahme erfolgt manuell als Entwurf.',
                'no_k0_write'=>true,'no_posts_written'=>true], 'pferdeatelier-kurzauftrag-'.gmdate('Ymd-His').'.json');
        } catch(Throwable $e){self::fail($e);}
    }
}
