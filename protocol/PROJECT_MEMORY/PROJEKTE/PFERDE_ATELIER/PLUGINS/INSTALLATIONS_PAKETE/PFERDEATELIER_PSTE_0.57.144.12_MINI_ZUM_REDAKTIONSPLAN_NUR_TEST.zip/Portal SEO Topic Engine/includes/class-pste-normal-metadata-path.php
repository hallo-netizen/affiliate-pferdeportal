<?php
if (!defined('ABSPATH')) { return; }

/**
 * Single read-only semantic/editorial decision path for normal research, stored-topic rebuilds and Sandbox reentry.
 * It owns no persistence and can never create an article/text/design payload or a five-field production handoff.
 */
final class PSTE_Normal_Metadata_Path {
    public const CONTRACT='PSTE_NORMAL_METADATA_PATH_V2';

    /** @return array<string,mixed> */
    public static function evaluateRaw(string $raw,array $baseline,string $preferredFamilyKey='',array $relevanceProof=[],array $seoEvidence=[]): array {
        $result=self::evaluateSemanticRaw($raw,$baseline,$preferredFamilyKey,$relevanceProof,$seoEvidence);
        // One title authority: the existing isolated language-desk import.
        // No historical production title or signed category route is a second title author.
        if(($result['status']??'')!=='NORMAL_PASS')return $result;
        $languageTitle=self::persistedStoredTitleCandidate($seoEvidence);
        if($languageTitle!=='' && hash_equals($languageTitle,self::canonicalInputQuery((string)($result['title']??''))))return $result;
        $result['title']='';$result['title_pipeline']=[];$result['target_keyword']='';
        $result['ok']=false;$result['title_candidate_only']=true;
        // No imported language-desk title yet: unfinished title work, NOT a keyword rejection.
        return self::withReasons($result,'REVIEW_REQUIRED',['PSTE_LANGUAGE_TITLE_REQUIRED']);
    }

    private static function evaluateSemanticRaw(string $raw,array $baseline,string $preferredFamilyKey='',array $relevanceProof=[],array $seoEvidence=[]): array {
        $raw=self::canonicalInputQuery($raw);
        $base=[
            'contract'=>self::CONTRACT,'status'=>'REVIEW_REQUIRED','ok'=>false,'raw_query'=>$raw,
            'raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'','portal_relevance'=>'UNPROVEN',
            'family_key'=>'','family_name'=>'','family_resolution'=>[],'family_membership'=>[],'editorial_area'=>'UNDECIDED',
            'article_type_registry_sha256'=>'','family_identity_v2_registry_sha256'=>'',
            'portal_relevance_gate'=>[],'normalization'=>[],'intent_analysis'=>[],'semantic_consensus'=>[],'intent_profile'=>[],'article_type'=>'','target_category'=>[],
            'title_pipeline'=>[],'title'=>'','target_keyword'=>'','category_gap_proposal'=>[],'domain_risk'=>[],
            'reason_codes'=>[],'title_generated'=>false,'title_candidate_only'=>false,'title_candidate_source'=>'','title_candidate_source_sha256'=>'','sandbox_required'=>false,'sandbox_admission_mode'=>'',
            'structure_gap_backlog_required'=>false,'retained_non_producing'=>false,
            'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,
            'article_or_taxonomy_write_attempted'=>false,'write_attempted'=>false,
        ];
        if($raw==='')return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_NORMAL_PATH_RAW_QUERY_MISSING']);
        // Only a correction re-confirmed by the existing Query Record source is analysis input.
        // Raw identity, measured volumes, provenance and any bound relevance proof stay unchanged.
        $analysisRaw=$raw;$record=is_array($seoEvidence['query_record']??null)?$seoEvidence['query_record']:[];
        if(!$relevanceProof&&$record&&class_exists('PSTE_Query_Record')){
            $candidate=self::canonicalInputQuery((string)($record['language_corrected_query']??''));
            $rawSha=(string)($record['raw_query_sha256']??'');
            if($candidate!==''&&$candidate!==$raw&&(string)($record['raw_query']??'')===$raw
                &&preg_match('/^[a-f0-9]{64}$/',$rawSha)===1&&hash_equals(hash('sha256',$raw),$rawSha)
                &&hash_equals($candidate,self::canonicalInputQuery(PSTE_Query_Record::correct($raw)))){
                $analysisRaw=$candidate;
            }
        }
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_NORMAL_PATH_BASELINE_REQUIRED']);
        $registry=PSTE_Article_Type_Registry::build($baseline);
        if(empty($registry['registry_sha256']))return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_NORMAL_PATH_REGISTRY_INVALID']);
        $base['article_type_registry_sha256']=(string)$registry['registry_sha256'];
        $base['family_identity_v2_registry_sha256']=(string)($registry['family_identity_v2_registry_sha256']??'');

        // Rootfix: title-candidate creation is a read-only editorial surface and must not be
        // hidden behind later family/category/PSERC admission. It never grants production authority.
        $storedTitle=self::storedTitleCandidateFromPayload($seoEvidence,$baseline,$registry);
        if(!empty($storedTitle['title'])){
            $base['title']=(string)$storedTitle['title'];
            $base['title_generated']=true;
            $base['title_candidate_only']=true;
            $base['title_candidate_source']=(string)$storedTitle['source'];
            $base['title_candidate_source_sha256']=(string)$storedTitle['source_sha256'];
        }
        // The special retained-keyword classification below belongs only to durable stored-title
        // revalidation. It must never demote already-good normal planning rows that were created
        // through the regular research/title path.
        $persistedTitle=self::persistedStoredTitleCandidate($seoEvidence);

        // Hard ordering contract: portal relevance is the first semantic decision owner.
        // Any family resolution performed by that gate is temporary evidence only.
        $relevance=PSTE_Portal_Relevance_Gate::evaluateBeforeAssignment($analysisRaw,$baseline,$registry,$preferredFamilyKey,$relevanceProof);$base['portal_relevance_gate']=$relevance;
        if(empty($relevance['ok'])){
            $base['portal_relevance']='UNPROVEN';$base['sandbox_required']=true;$base['sandbox_admission_mode']='EXTERNAL_RELEVANCE';
            return self::withReasons($base,'SANDBOX_REQUIRED',array_merge(['PSTE_PORTAL_RELEVANCE_NOT_PROVEN','PSTE_SANDBOX_REQUIRED_BEFORE_EDITORIALIZATION'],(array)($relevance['reason_codes']??[])));
        }
        $base['portal_relevance']='PROVEN';
        // The existing repository supplies this only from an authenticated current
        // manual review row. Never treat historical payload fields as an editor vote.
        $human=(array)($seoEvidence['_pste_current_manual_choice']??[]);
        if(($human['source']??'')!=='AUTHENTICATED_CURRENT_REVIEW'
            ||(int)($human['reviewed_by']??0)<=0
            ||!hash_equals((string)($human['raw_query_sha256']??''),hash('sha256',$raw))
            ||!in_array((string)($human['area']??''),['FACH','MAGAZIN'],true))$human=[];
        if($human&&$human['area']==='MAGAZIN'){
            // The PRE-EXISTING signed extension contract independently checks this
            // exact title, keyword, registered category, risk and runtime term.
            $signed=PSTE_Article_Type_Extension_Router::evaluateAfterCoreMiss(
                $raw,$baseline,$registry,$relevance,$seoEvidence);
            $target=(array)($signed['target_category']??[]);
            $evidence=(array)($signed['extension_evidence']??[]);
            if(($signed['status']??'')==='EXTENSION_ROUTE_PASS'&&!empty($signed['ok'])
                &&(string)($signed['article_type']??'')==='Journal'
                &&(string)($evidence['authority_mode']??'')==='EXTERNAL_EXPLICIT_JOURNAL_SCOPE'
                &&(int)($target['term_id']??0)===(int)$human['term_id']
                &&(string)($target['slug']??'')===(string)$human['slug']
                &&($persistedTitle===''||hash_equals($persistedTitle,(string)($signed['title']??'')))){
                foreach(['title','target_keyword','title_pipeline','intent_profile',
                    'normalization','semantic_consensus'] as $field)$base[$field]=$signed[$field]??[];
                $base['editorial_area']='MAGAZIN';$base['title_generated']=true;
                $base['title_candidate_only']=false;$base['title_precheck_validated']=true;
                return self::acceptVerifiedExtension($base,$signed,'',$raw,$registry);
            }
            return self::withReasons($base,'REVIEW_REQUIRED',
                ['PSTE_MANUAL_MAGAZIN_SIGNED_ROUTE_NOT_PROVEN']);
        }
        // Decide Fach ownership once, BEFORE any article-type category lookup.
        // Membership proves the area, not the existence of a particular WP leaf.
        // KISS: the relevance gate has already resolved this very same query.
        // Its result is reusable only for byte-identical analysis input without a preferred family.
        $relevanceProbe=PSTE_Editorial_Topic_Normalizer::semanticProbe($analysisRaw);
        $hintResolution=(array)($relevance['family_hint']['resolution']??[]);
        $sameInput=$preferredFamilyKey==='' && $analysisRaw===$raw
            && ($relevanceProbe===$analysisRaw || $relevanceProbe===rtrim($analysisRaw," ?"))
            && ($hintResolution['contract']??'')==='PSTE_FAMILY_RESOLUTION_V2';
        $areaFamily=$sameInput?$hintResolution:PSTE_Family_Identity_V2::resolve($analysisRaw,$registry);
        $areaKey=(string)($areaFamily['winner']['family_key']??'');
        $areaMembership=[];$fachAreaOwner=false;
        $areaNeedsReview=($areaFamily['status']??'')==='REVIEW_REQUIRED';
        if(($areaFamily['status']??'')==='MATCH'){
            if($areaKey!=='' && isset($registry['families'][$areaKey])){
                $areaMembership=PSTE_Family_Membership::evaluate($analysisRaw,$registry,$areaKey);
                $fachAreaOwner=!empty($areaMembership['ok']);
            }
            // A tentative family MATCH without proven membership is not
            // positive evidence that the editorial Magazin owns this topic.
            if(!$fachAreaOwner)$areaNeedsReview=true;
        }
        // One area decision. A category's existence does not decide the area.
        // Reuse the existing editorial classifier as POSITIVE magazine evidence;
        // NO_MATCH of a Fach family alone never proves magazine ownership.
        // The existing Journal owner must receive explicit editorial intent BEFORE a
        // Fach family can monopolize the lane. This is not a second category decision:
        // the signed Journal route still checks title, risk and the real WP term.
        // One category-independent scope check by the EXISTING Journal owner.
        // Do not ask a second lexical predicate and do not let a known Fach
        // category prevent the Journal owner from supplying its semantic proof.
        $journalCandidate=class_exists('PSTE_Journal_Semantic_Router')
            ? PSTE_Journal_Semantic_Router::classifyQuestion($analysisRaw):[];
        $explicitJournalIntent=!empty($journalCandidate['editorial_intent_proven']);
        // A broad Journal domain word cannot prove MAGAZIN when the normal
        // Journal title/risk route is skipped for a retained title.
        // Existing signed extension evidence retains its own verification route.
        $journalConfirmed=!empty($journalCandidate['ok']);
        $journalFamilyName=($fachAreaOwner&&$areaKey!==''&&isset($registry['families'][$areaKey]))
            ?(string)($registry['families'][$areaKey]['topic_family_name']??''):'';
        $journalFamilyKey=$journalFamilyName!==''?$areaKey:'';
        // An explicitly editorial Journal subject is equal to Fach: a previously
        // matched Fach family is no veto. A merely generic/FAQ question still
        // keeps proven Fach ownership. The human's current decision remains binding.
        $base['editorial_area']=($human&&$human['area']==='FACH')?'FACH':
            (($journalConfirmed&&$explicitJournalIntent)?'MAGAZIN':
            ($fachAreaOwner?'FACH':($areaNeedsReview?'UNDECIDED':
            ($journalConfirmed?'MAGAZIN':'UNDECIDED'))));
        $journalAreaAllowed=$base['editorial_area']==='MAGAZIN';
        if($journalAreaAllowed
            && empty($seoEvidence['article_type_extension_evidence'])
            && class_exists('PSTE_Journal_Semantic_Router')
            && class_exists('PSTE_Article_Type_Extension_Router')){
            if(!empty($journalCandidate['ok'])){
                $journal=$persistedTitle!==''?(array)($base['journal_routing']??[]):PSTE_Journal_Semantic_Router::evaluate($raw,$registry,$journalFamilyKey,$journalFamilyName,$journalCandidate);
                $base['journal_routing']=$journal;
                // A retained title is non-authoritative. It can reenter the existing
                // Journal route only when the SAME words were independently validated.
                // Otherwise retain it in the normal title-repair path below.
                $sameJournalTitle=$persistedTitle==='' || (
                    !empty($journal['title_pipeline']['ok'])
                    &&$persistedTitle!=='' && hash_equals($persistedTitle,(string)($journal['title']??'')));
                // Area remains MAGAZIN when only its existing WordPress leaf is absent.
                // Keep the finished title and send the topic to the SAME category room.
                if($sameJournalTitle && ($journal['status']??'')==='CATEGORY_UNAVAILABLE_TITLE_PASS'
                    &&!empty($journal['title_pipeline']['ok'])){
                    foreach(['title','target_keyword','title_pipeline','intent_profile','normalization','semantic_consensus'] as $field)
                        $base[$field]=$journal[$field]??[];
                    $base['article_type']='Journal';
                    $base['family_key']=(string)($journal['family_key']??'');
                    $base['family_name']=(string)($journal['family_name']??'');
                    $base['title_generated']=true;
                    $base['title_candidate_source']='EXISTING_JOURNAL_TITLE_AWAITS_CATEGORY';
                    $base['title_candidate_source_sha256']=hash('sha256',(string)$base['title']);
                    $base['structure_gap_backlog_required']=true;
                    return self::withReasons($base,'STRUCTURE_GAP',['PSTE_VALID_JOURNAL_TITLE_CATEGORY_ABSENT']);
                }
                if($sameJournalTitle && ($journal['status']??'')==='JOURNAL_AUTO_PASS'&&!empty($journal['ok'])){
                    $ext=PSTE_Article_Type_Extension_Router::fromClassifiedJournal($journal,$raw);
                    $base['article_type_extension_routing']=$ext;
                    if(($ext['status']??'')==='EXTENSION_ROUTE_PASS'&&!empty($ext['ok'])){
                        foreach(['title','target_keyword','title_pipeline','intent_profile','normalization','semantic_consensus'] as $field)
                            $base[$field]=$ext[$field]??[];
                        $base['title_generated']=true;
                        $base['title_precheck_validated']=true;
                        $base['title_candidate_only']=false;
                        $base['title_candidate_source']='EXISTING_SIGNED_JOURNAL_TITLE';
                        $base['title_candidate_source_sha256']=hash('sha256',(string)$base['title']);
                        return self::acceptVerifiedExtension($base,$ext,'',$raw,$registry);
                    }
                }
                // An unverified Journal title/risk/manifest result is NOT a
                // confirmed Magazine owner. Keep the ordinary title-repair path,
                // but revoke that provisional lane before any other placement.
                // No language title yet is not evidence against the one area decision.
                $base['journal_title_pending']=true;
            }
        }
        $manualFachType=($human&&$human['area']==='FACH')?(string)$human['article_type']:'';
        $base=self::candidateTitleBeforeCategory($base,$analysisRaw,$registry,$persistedTitle,
            (string)($seoEvidence['target_keyword']??''),$seoEvidence,$manualFachType);

        // Central KISS decision: relevance and title quality are already decided.
        // A missing research family, article-type category or Magazin leaf is never a title veto.
        if(empty($base['title_pipeline']['ok']) || trim((string)$base['title'])===''){
            // The existing external title desk runs later. No title is not a keyword veto.
            return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_LANGUAGE_TITLE_REQUIRED']);
        }
        $base['title_candidate_only']=false; // finished editorial title, NOT a production authorization

        // Existing signed Fach/Magazin routes may give an unambiguous WP category.
        $signed=class_exists('PSTE_Article_Type_Extension_Router')
            ? PSTE_Article_Type_Extension_Router::evaluateAfterCoreMiss($raw,$baseline,$registry,$relevance,$seoEvidence):[];
        $base['article_type_extension_routing']=$signed;
        if(($signed['status']??'')==='EXTENSION_ROUTE_PASS'&&!empty($signed['ok'])
            && (int)($signed['target_category']['term_id']??0)>0
            && (string)($signed['target_category']['slug']??'')!==''
            && (($base['editorial_area']==='MAGAZIN' && strcasecmp((string)($signed['article_type']??''),'Journal')===0)
                || ($base['editorial_area']==='FACH' && strcasecmp((string)($signed['article_type']??''),'Journal')!==0))
            && self::samePreparedTitleType($base,(string)($signed['article_type']??'')))
            return self::acceptVerifiedExtension($base,$signed,$persistedTitle,$raw,$registry);
        // Reuse the Journal result already obtained by this same central decision.
        // Do not re-read the same WP term and repeat the identical Journal checks.
        $earlierJournal=(array)($base['journal_routing']??[]);
        $journal=(($earlierJournal['contract']??'')===PSTE_Journal_Semantic_Router::CONTRACT
                && ($earlierJournal['raw_query']??'')===PSTE_Normal_Metadata_Path::canonicalInputQuery($raw))
            ? $earlierJournal
            : ($journalAreaAllowed && class_exists('PSTE_Journal_Semantic_Router')?PSTE_Journal_Semantic_Router::evaluate($raw,$registry,$journalFamilyKey,$journalFamilyName,$journalCandidate):[]);
        if(!$journalAreaAllowed)$journal=[]; // No second area decision by a category.
        else $base['journal_routing']=$journal; // Retain existing failed proof as review evidence.
        if(($journal['status']??'')==='JOURNAL_AUTO_PASS'&&!empty($journal['ok'])
            &&class_exists('PSTE_Article_Type_Extension_Router')){
            $ext=PSTE_Article_Type_Extension_Router::fromClassifiedJournal($journal,$raw);
            if(!empty($ext['ok'])&&(int)($ext['target_category']['term_id']??0)>0
                && (string)($ext['target_category']['slug']??'')!==''
                && self::samePreparedTitleType($base,(string)($ext['article_type']??'')))
                return self::acceptVerifiedExtension($base,$ext,$persistedTitle,$raw,$registry);
        }

        // Category search is an optional placement operation, not a title approval.
        // Keep the existing signed/consensus-based category selection when it succeeds;
        // if it does not, collect the finished title in the existing separate review room.
        $probe=PSTE_Editorial_Topic_Normalizer::semanticProbe($analysisRaw);
        $resolved=$areaFamily;
        $base['family_resolution']=$resolved;
        $familyKey='';$familyName='';
        if(($resolved['status']??'')==='MATCH'){
            $key=(string)($resolved['winner']['family_key']??'');
            if($key!==''&&isset($registry['families'][$key])){
                $membership=($key===$areaKey)?$areaMembership:PSTE_Family_Membership::evaluate($analysisRaw,$registry,$key);
                $base['family_membership']=$membership;
                if(!empty($membership['ok'])){
                    $familyKey=$key;
                    $familyName=(string)($registry['families'][$key]['topic_family_name']??'');
                    $base['family_key']=$key;$base['family_name']=$familyName;
                }
            }
        }
        $typeOnly=PSTE_Semantic_Classifier::classifyTypeOnly($analysisRaw,$registry);
        // The title worker has already selected its article type from SEO intent.
        // Category search is placement only and cannot silently change that type.
        $titleType=(string)($base['title_pipeline']['editorial_quality']['article_type']??'');
        $type=$titleType!==''?$titleType:
            (!empty($typeOnly['ok'])?(string)($typeOnly['resolved_article_type']??''):
                (PSTE_Normalizer::isQuestion($raw)?'FAQ':'Beratung'));
        $base['article_type']=$type;
        $base['semantic_consensus']=$typeOnly;
        $base['domain_risk']=PSTE_Domain_Risk_Gate::evaluate($analysisRaw,$type);
        // The original risk assessment remains a title/content quality concern,
        // never a reason to claim a missing category or discard the original topic.
        $target=[];
        if($manualFachType!==''){
            $id=(int)$human['term_id'];
            $manualKey=(string)($registry['by_term_id'][$id]??'');
            $match=$manualKey!==''?PSTE_Article_Type_Registry::resolve(
                $registry,$manualKey,$type):[];
            if(!empty($match['ok'])&&(int)$match['term_id']===$id
                &&(string)$match['slug']===(string)$human['slug']){
                $target=$match;$familyKey=$manualKey;
                $familyName=(string)($registry['families'][$manualKey]['topic_family_name']??'');
                $base['family_key']=$familyKey;$base['family_name']=$familyName;
            }
        }
        if(!$target&&$manualFachType===''&&$familyKey!==''){
            // Category placement uses the existing exact family+article-type index.
            // Do not ask the old semantic double-strand to make a second editorial
            // or article-type decision after the central title worker already did.
            $match=PSTE_Article_Type_Registry::resolve($registry,$familyKey,$type);
            if(!empty($match['ok']))$target=$match;
        }
        if((int)($target['term_id']??0)>0&&(string)($target['slug']??'')!==''){
            // The existing risk/area decision must be complete BEFORE a production PASS.
            // A category match alone is not permission to bypass either decision.
            if(empty($base['domain_risk']['ok']))return self::withReasons($base,'REVIEW_REQUIRED',(array)($base['domain_risk']['reason_codes']??[]));
            if(!in_array((string)($base['editorial_area']??''),['FACH','MAGAZIN'],true))return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_EDITORIAL_AREA_DECISION_REQUIRED']);
            $base['target_category']=$target;
            $base['ok']=true;$base['status']='NORMAL_PASS';
            $base['reason_codes']=['PSTE_NORMAL_METADATA_PATH_PASS'];
            return self::attachWorkerFlow($base);
        }
        $base['structure_gap_backlog_required']=true;
        // Do not invent a new WP category, an article type/category match or a family.
        $base['category_gap_proposal']=PSTE_Category_Gap::proposal($familyName,$familyKey,$type,[],[],(string)($baseline['structure_sha256']??''),$registry);
        return self::withReasons($base,'STRUCTURE_GAP',['PSTE_TITLE_READY_CATEGORY_DECISION_OPEN']);
    }


    private static function candidateTitleBeforeCategory(array $base,string $raw,array $registry,string $storedTitle,string $storedTargetKeyword='',array $seoEvidence=[],string $editorChosenType=''): array {
        if($storedTitle!==''){
            // A retained title is immutable, but still receives the same pre-category validation.
            $base['title']=$storedTitle;$base['title_generated']=false;
            $base['title_candidate_only']=true;$base['title_candidate_source']='STORED_TITLE_AWAITS_HARD_REVALIDATION';
            $base['title_candidate_source_sha256']=hash('sha256',$storedTitle);
        }
        $question=PSTE_Normalizer::isQuestion($raw);
        $subject='';
        $normalized=PSTE_Editorial_Topic_Normalizer::normalize($raw,'');
        if(($normalized['status']??'')==='PASS')$subject=(string)($normalized['subject_topic']??'');
        if($subject===''){
            $scope=(array)($base['portal_relevance_gate']['context_evidence']['matched_terms']??[]);
            foreach((preg_split('/[^\p{L}\p{N}-]+/u',$raw)?:[]) as $word){
                foreach($scope as $seed){
                    $word=(string)$word;$seed=(string)$seed;
                    if(strlen($seed)>=4&&strlen($word)>strlen($subject)
                        &&(strcasecmp($word,$seed)===0||str_starts_with(strtolower($word),strtolower($seed))))$subject=$word;
                }
            }
        }
        if($subject==='')return $base;
        // Reuse the EXISTING SEO-intent worker before title creation. The earlier
        // hard-coded EDITORIAL_INFORMATION discarded proven search intent on every
        // new keyword; a category must never dictate the title's meaning.
        $intent=PSTE_Intent_Profile::analyzeBeforeType($raw,$normalized,'',$seoEvidence);
        $base['intent_analysis']=$intent;
        $base['intent_profile']=$intent;
        // The single SEO-intent result owns the type used for title validation.
        // Old question/family heuristics must not override it here.
        if(empty($intent['ok']))return $base;
        $type=$editorChosenType!==''?$editorChosenType:
            trim((string)($intent['primary_article_type_candidate']??''));
        if($type==='')return $base;
        // The human owns placement/type, not the separately derived SEO intent.
        // Keep original intent evidence unchanged; the EXISTING title-quality
        // pipeline must reject any semantic incompatibility.
        $base['article_type']=$type;
        // An existing registry-matched SEO-exhausted coverage assignment may choose an
        // article type ONLY when the query itself has no explicit FAQ/buy/compare goal.
        // The title worker still validates the wording; category placement remains later.
        if(!$question && ($intent['primary_user_goal']??'')==='EDITORIAL_INFORMATION'
            && !empty($seoEvidence['coverage_candidate'])
            && (string)($seoEvidence['research_job_contract']??'')===PSTE_Research_Job::CONTRACT
            && hash_equals((string)($registry['registry_sha256']??''),(string)($seoEvidence['article_type_registry_sha256']??''))){
            $familyKey=(string)($seoEvidence['research_origin_family_key']??'');
            $coverageType=(string)($seoEvidence['coverage_target_article_type']??'');
            $coverageId=(int)($seoEvidence['coverage_target_category_id']??0);
            $coverageTerm=$familyKey!==''&&$coverageType!==''&&$coverageId>0
                ? PSTE_Article_Type_Registry::resolve($registry,$familyKey,$coverageType) : [];
            if(!empty($coverageTerm['ok'])&&(int)($coverageTerm['term_id']??0)===$coverageId){
                $type=$coverageType;
                $base['coverage_title_hint']=['source'=>'EXISTING_COVERAGE_CANDIDATE_REGISTRY_MATCH',
                    'article_type'=>$coverageType,'term_id'=>$coverageId,'used_for_title_only'=>true];
            }
        }
        $pipeline=[];
        if($storedTitle!==''){
            // Do not regenerate an already stored wording. Invalid stored titles stay with the
            // existing title worker instead of being promoted or silently rewritten.
            $title=$storedTitle;
            $keyword=trim($storedTargetKeyword);
            if($keyword==='')$keyword=trim(PSTE_Normalizer::canonicalQuestion($raw)," ?\t\n\r\0\x0B");
            $pipeline=PSTE_Title_Pipeline::validateExistingTitle($title,$raw,$subject,$type,$registry,$intent,$keyword,$subject,[],(array)($seoEvidence['title_candidate_evidence']??[]));
        }else{
            $pipeline=PSTE_Title_Pipeline::build(['raw_query'=>$raw,'language_corrected_query'=>$raw],$subject,$type,$registry,[],$intent);
            $title='';
            $keyword=(string)($pipeline['target_keyword']??'');
        }
        if($title==='')return $base;
        $base['title']=$title;$base['target_keyword']=$keyword;$base['title_pipeline']=$pipeline;
        $base['title_generated']=false;$base['title_candidate_only']=true;
        $base['title_precheck_validated']=!empty($pipeline['ok']);
        $base['title_candidate_source']=$storedTitle!==''?'STORED_SOURCE_TITLE_CANDIDATE_REVALIDATED':'LANGUAGE_TITLE_IMPORT_ONLY';
        $base['title_candidate_source_sha256']=hash('sha256',$title);
        return $base;
    }

    /** Category placement cannot replace a title already approved by the central title worker. */
    private static function samePreparedTitleType(array $base,string $type): bool {
        $prepared=(string)($base['title_pipeline']['editorial_quality']['article_type']??'');
        return $type!=='' && $prepared!==''
            && PSTE_Article_Type_Registry::canonicalType($type)===PSTE_Article_Type_Registry::canonicalType($prepared);
    }

    /** Existing verified extension: use its category only, never a second title decision. */
    private static function acceptVerifiedExtension(array $base,array $extension,string $persistedTitle,string $raw,array $registry): array {
        $target=(array)($extension['target_category']??[]);
        $extensionArea=strcasecmp((string)($extension['article_type']??''),'Journal')===0?'MAGAZIN':'FACH';
        // The earlier owner decision is binding; a later signed category cannot
        // reverse it or produce an automatic release for an undecided owner.
        if(($base['editorial_area']??'UNDECIDED')!==$extensionArea
            ||!self::samePreparedTitleType($base,(string)($extension['article_type']??''))
            ||(int)($target['term_id']??0)<=0 || (string)($target['slug']??'')==='')return $base;
        $base['family_key']=(string)($extension['family_key']??'');
        $base['family_name']=(string)($extension['family_name']??'');
        $base['article_type']=(string)$extension['article_type'];
        $base['target_category']=$target;
        $base['article_type_extension_routing']=$extension;
        $base['domain_risk']=PSTE_Domain_Risk_Gate::evaluate($raw,$base['article_type']);
        if(empty($base['domain_risk']['ok']))return self::withReasons($base,'REVIEW_REQUIRED',(array)($base['domain_risk']['reason_codes']??[]));
        $base['status']='NORMAL_PASS';$base['ok']=true;
        $base['reason_codes']=['PSTE_NORMAL_METADATA_PATH_PASS','PSTE_ARTICLE_TYPE_EXTENSION_ROUTE_PASS'];
        // title / target_keyword / title_pipeline are immutable after the first title worker.
        return self::attachWorkerFlow($base);
    }

    /** Apply only SEO-topic metadata derived by evaluateRaw(); raw source fields remain byte-identical. */
    public static function applyToPayload(array $payload,array $baseline,string $preferredFamilyKey='',array $relevanceProof=[]): array {
        $raw=PSTE_Editorializer::sourceQuery($payload);
        $before=self::rawSourceInvariant($payload);
        // Historical derived family assignments are evidence only and must never become current authority
        // merely because they are present in a legacy payload. A preferred family is trusted only when its
        // current provenance is explicit: current research origin or a bound Sandbox reentry proof.
        $providedPreferred=trim($preferredFamilyKey);
        $researchPreferred=trim((string)($payload['research_origin_family_key']??''));
        $researchContract=trim((string)($payload['research_job_contract']??''));
        $trustedResearch=$providedPreferred!==''&&$researchPreferred!==''&&$researchContract!==''&&hash_equals($providedPreferred,$researchPreferred);
        $trustedReentry=$providedPreferred!==''&&!empty($relevanceProof);
        $preferredFamilyKey=($trustedResearch||$trustedReentry)?$providedPreferred:'';
        $result=self::evaluateRaw($raw,$baseline,$preferredFamilyKey,$relevanceProof,$payload);
        $result=self::applyManualTitleOverride($payload,$result,$raw,$baseline);
        $result=self::attachWorkerFlow($result);
        $payload['normal_metadata_path']=$result;
        $payload['raw_keyword_preserved']=$raw;$payload['raw_keyword_sha256']=$raw!==''?hash('sha256',$raw):'';
        $payload['metadata_handoff_fields']=['title','target_keyword','category','article_type','plan_slot'];
        $payload['textmachine_handoff_status']='BLOCKED_BEFORE_COMPILER';
        $payload['sandbox_required']=($result['status']??'')==='SANDBOX_REQUIRED';
        $payload['sandbox_admission_mode']=(string)($result['sandbox_admission_mode']??'');
        $payload['structure_gap_backlog_required']=!empty($result['structure_gap_backlog_required']);
        $payload['category_backlog_required']=!empty($result['category_backlog_required']);
        $payload['topic_work_group']=(string)($result['worker_flow']['work_group']??'RELEVANCE_REVIEW');
        $payload['retained_non_producing']=!empty($result['retained_non_producing']);
        $payload['category_gap_proposal']=(array)($result['category_gap_proposal']??[]);

        // Preserve former derived decisions as history/evidence, never as current authority.
        if(!isset($payload['source_target_category_id']))$payload['source_target_category_id']=(int)($payload['target_category_id']??0);
        if(!isset($payload['source_target_category_name']))$payload['source_target_category_name']=(string)($payload['target_category_name']??'');
        if(!isset($payload['source_proposed_article_type']))$payload['source_proposed_article_type']=(string)($payload['proposed_article_type']??'');
        if(!isset($payload['source_topic_family_key']))$payload['source_topic_family_key']=(string)($payload['topic_family_key']??'');
        if(!isset($payload['source_topic_family_name']))$payload['source_topic_family_name']=(string)($payload['topic_family_name']??'');
        if(!isset($payload['source_article_type_registry_sha256']))$payload['source_article_type_registry_sha256']=(string)($payload['article_type_registry_sha256']??'');

        // Current derived authority is always overwritten from the freshly recomputed path.
        // An unresolved current family must never leave a historical family looking current.
        $familyKey=(string)($result['family_key']??'');$familyName=(string)($result['family_name']??'');
        $payload['topic_family_key']=$familyKey;$payload['topic_family_name']=$familyName;
        $payload['article_type_registry_sha256']=(string)($result['article_type_registry_sha256']??'');
        $payload['family_identity_v2_registry_sha256']=(string)($result['family_identity_v2_registry_sha256']??'');
        $payload['derived_state_authority']=[
            'contract'=>'PSTE_DERIVED_STATE_AUTHORITY_V1',
            'normal_metadata_path_contract'=>self::CONTRACT,
            'editorial_ruleset'=>PSTE_Editorializer::RULESET,
            'raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'',
            'article_type_registry_sha256'=>(string)($result['article_type_registry_sha256']??''),
            'family_identity_v2_registry_sha256'=>(string)($result['family_identity_v2_registry_sha256']??''),
            'recomputed'=>true,
            'historical_derived_fields_authoritative'=>false,
        ];
        $payload['family_membership_v2']=(array)($result['family_membership']??[]);
        $payload['intent_analysis']=(array)($result['intent_analysis']??[]);
        $payload['semantic_consensus']=(array)($result['semantic_consensus']??[]);
        $payload['intent_profile']=(array)($result['intent_profile']??[]);
        $payload['intent_portfolio']=(array)($result['intent_profile']['secondary_branches']??[]);
        $payload['search_intent']=(string)($result['intent_profile']['search_intent']??'');
        $payload['intent_angle']=(string)($result['intent_profile']['intent_angle']??'');
        $payload['normalized_editorial_topic']=(string)($result['normalization']['normalized_topic']??'');
        $payload['domain_risk']=(array)($result['domain_risk']??[]);
        if(!empty($result['article_type_extension_routing'])&&is_array($result['article_type_extension_routing']))$payload['article_type_extension_routing']=(array)$result['article_type_extension_routing'];
        if(!empty($result['journal_routing'])&&is_array($result['journal_routing']))$payload['journal_routing']=(array)$result['journal_routing'];

        $title=(string)($result['title']??'');$type=(string)($result['article_type']??'');$pipeline=(array)($result['title_pipeline']??[]);
        $payload['editorial_title']=$title;
        if(($result['status']??'')==='NORMAL_PASS'&&empty($result['title_candidate_only']))$payload['production_title']=$title;
        else $payload['production_title']=''; // candidate-only wording must never retain stale production authority
        $payload['target_keyword']=(string)($result['target_keyword']??$pipeline['target_keyword']??'');$payload['target_keyword_contract']=(array)($pipeline['target_keyword_contract']??[]);
        $payload['editorial_quality_gate']=(array)($pipeline['editorial_quality']??[]);
        $payload['title_quality']=(array)($pipeline['deterministic']??[]);
        $payload['language_quality']=(array)($pipeline['language']??[]);
        $payload['editorial_dual_strand']=['technical'=>(array)($pipeline['technical_strand']??[]),'editorial'=>(array)($pipeline['editorial_strand']??[])];
        $payload['editorial_intent_key']=(string)($result['intent_profile']['intent_key']??'');

        $status=(string)($result['status']??'REVIEW_REQUIRED');
        $resolved=$status==='NORMAL_PASS';$eligible=$resolved&&$title!==''&&$type!=='';
        if($resolved)$payload['textmachine_handoff_status']='READY_FOR_COMPILER_CAPABILITY_CHECK';
        $payload['editorialization']=[
            'contract'=>PSTE_Editorializer::RULESET,'eligible'=>$eligible,'resolved'=>$resolved,'ambiguous'=>false,
            'article_type'=>$type,'title'=>$title,'normalized_topic'=>(string)($result['normalization']['normalized_topic']??''),
            'intent_key'=>(string)($result['intent_profile']['intent_key']??''),'search_intent'=>(string)($result['intent_profile']['search_intent']??''),'intent_angle'=>(string)($result['intent_profile']['intent_angle']??''),'intent_first'=>true,'seo_basis'=>(array)($result['intent_profile']['seo_basis']??[]),'signals'=>[],'reason'=>$status,'title_pipeline'=>$pipeline,
        ];
        if($type!==''){$payload['suggested_article_type']=$type;$payload['proposed_article_type']=$type;}
        else{$payload['suggested_article_type']='';$payload['proposed_article_type']='';}

        if($resolved){
            $target=(array)$result['target_category'];$id=(int)($target['term_id']??0);$name=(string)($target['name']??'');$slug=(string)($target['slug']??'');
            $payload['target_category_id']=$id;$payload['target_category_name']=$name;$payload['target_category_slug']=$slug;
            $payload['suggested_category_id']=$id;$payload['suggested_category_name']=$name;$payload['suggested_category_slug']=$slug;
            $intentKey=(string)($result['intent_profile']['intent_key']??'');
            $payload['editorialization']['intent_key']=$intentKey;$payload['editorial_intent_key']=$intentKey;
        }else{
            $payload['target_category_id']=0;$payload['target_category_name']='';$payload['target_category_slug']='';
            $payload['suggested_category_id']=0;$payload['suggested_category_name']='';$payload['suggested_category_slug']='';
        }

        // The recomputed normal path owns the CURRENT decision reasons. Historical reasons are
        // evidence in their original source records, never part of this new verdict.
        $reasons=array_values(array_unique(array_filter((array)($result['reason_codes']??[]))));
        // Remove obsolete pass claims before adding the current result.
        $reasons=array_values(array_diff($reasons,['EDITORIAL_TITLE_PIPELINE_V4_PASS','EDITORIAL_TITLE_PIPELINE_V5_PASS','ARTICLE_TYPE_AUTOMATICALLY_RESOLVED','PSTE_NORMAL_METADATA_PATH_PASS']));
        if($resolved){$reasons[]='PSTE_NORMAL_METADATA_PATH_PASS';$reasons[]='EDITORIAL_TITLE_PIPELINE_V5_PASS';$reasons[]='ARTICLE_TYPE_AUTOMATICALLY_RESOLVED';}
        $payload['reason_codes']=array_values(array_unique($reasons));
        if($status==='NORMAL_PASS'){$payload['decision']='PASS';$payload['human_review_required']=false;$payload['discovery_only']=false;}
        elseif($status==='STRUCTURE_GAP'||$status==='REVIEW_REQUIRED'){
            // The existing title/category/first-worker queue is unfinished work,
            // not a rejected topic and never a production release.
            $payload['decision']='REVIEW_REQUIRED';$payload['human_review_required']=true;$payload['discovery_only']=false;
        }
        else{$payload['decision']='BLOCKED';$payload['human_review_required']=true;$payload['discovery_only']=true;}

        if(self::rawSourceInvariant($payload)!==$before)throw new RuntimeException('PSTE_NORMAL_PATH_RAW_SOURCE_FIELD_MUTATION');
        return $payload;
    }


    /**
     * Re-applies an explicitly stored title-only override after the semantic path has been recomputed.
     * The override has zero authority over intent, category, article type or slot identity.
     * A stale/invalid override is ignored fail-safe; no PHP-generated fallback is available.
     * @return array<string,mixed>
     */
    private static function applyManualTitleOverride(array $sourcePayload,array $result,string $raw,array $baseline): array {
        $override=is_array($sourcePayload['manual_title_override']??null)?(array)$sourcePayload['manual_title_override']:[];
        if(!$override||($override['contract']??'')!=='PSTE_MANUAL_TITLE_OVERRIDE_V1')return $result;
        if(($result['status']??'')!=='NORMAL_PASS'||empty($result['ok']))return $result;
        $title=trim((string)($override['title']??''));$binding=(array)($override['binding']??[]);
        $pipeline=(array)($result['title_pipeline']??[]);$targetKeyword=(string)($result['target_keyword']??$pipeline['target_keyword']??'');
        $current=[
            'raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'',
            'family_key'=>(string)($result['family_key']??''),
            'article_type'=>(string)($result['article_type']??''),
            'category_id'=>(int)($result['target_category']['term_id']??0),
            'category_slug'=>(string)($result['target_category']['slug']??''),
            'intent_key'=>(string)($result['intent_profile']['intent_key']??''),
            'target_keyword_sha256'=>$targetKeyword!==''?hash('sha256',$targetKeyword):'',
        ];
        foreach($current as $key=>$value){if(!array_key_exists($key,$binding)||(string)$binding[$key]!== (string)$value){$result['manual_title_override_status']='STALE_NOT_APPLIED';$result['manual_title_override_reason']='BINDING_DRIFT_'.$key;return $result;}}
        $registry=PSTE_Article_Type_Registry::build($baseline);
        $validated=PSTE_Title_Pipeline::validateExistingTitle($title,$raw,(string)($result['family_name']??''),(string)($result['article_type']??''),$registry,(array)($result['intent_profile']??[]),$targetKeyword,(string)($result['normalization']['normalized_topic']??''),[],(array)($sourcePayload['title_candidate_evidence']??[]));
        if(empty($validated['ok'])){$result['manual_title_override_status']='INVALID_NOT_APPLIED';$result['manual_title_override_reason_codes']=self::pipelineReasons($validated);return $result;}
        $result['title']=$title;$result['title_pipeline']=$validated;$result['manual_title_override_status']='APPLIED';$result['manual_title_override_sha256']=hash('sha256',$title);return $result;
    }

    private static function hasBarePortalScopeFamilyAdjacency(string $title,string $family,array $portalScopeTerms): bool {
        if(PSTE_Normalizer::isQuestion($title)||$family===''||!$portalScopeTerms)return false;
        $words=preg_split('/\s+/u',self::canonicalInputQuery($title))?:[];$familyTokens=PSTE_Family_Identity_V2::tokens($family,false);$scope=[];
        foreach($portalScopeTerms as $term)foreach(PSTE_Family_Identity_V2::tokens((string)$term,false) as $token)$scope[$token]=true;
        if(!$scope||!$familyTokens)return false;$familyIndexes=[];$scopeIndexes=[];
        foreach($words as $i=>$word){$tokens=PSTE_Family_Identity_V2::tokens((string)$word,false);foreach($tokens as $token){if(isset($scope[$token]))$scopeIndexes[$i]=true;foreach($familyTokens as $head)if($token===$head)$familyIndexes[$i]=true;}}
        foreach(array_keys($scopeIndexes) as $si)foreach(array_keys($familyIndexes) as $fi)if(abs((int)$si-(int)$fi)===1)return true;
        return false;
    }

    /** Return only a genuinely persisted, non-authoritative stored-source title candidate. */
    public static function persistedStoredTitleCandidate(array $payload): string {
        $evidence=is_array($payload['title_candidate_evidence']??null)?(array)$payload['title_candidate_evidence']:[];
        // Legacy production/normal-path records and old manual title inputs are NOT authors.
        // Only the existing isolated language-desk import can supply title wording.
        if(($evidence['contract']??'')!=='PSTE_STORED_SOURCE_TITLE_CANDIDATE_V1'
            ||($evidence['source']??'')!=='LANGUAGE_TITLE_DESK_IMPORT'
            ||($evidence['production_authority']??null)!==false
            ||($evidence['family_category_type_authority']??null)!==false)return '';
        $raw=self::canonicalInputQuery(PSTE_Editorializer::sourceQuery($payload));
        $title=self::canonicalInputQuery((string)($payload['editorial_title']??''));
        if($raw===''||$title===''
            ||!hash_equals((string)($evidence['raw_query_sha256']??''),hash('sha256',$raw)))return '';
        // New imports bind their exact wording. Previously imported language titles
        // remain readable; they are not regenerated or promoted by this proof alone.
        $proofTitleSha=(string)($evidence['title_sha256']??'');
        if($proofTitleSha!==''&&!hash_equals($proofTitleSha,hash('sha256',$title)))return '';
        return $title;
    }

    /** @return array<string,mixed> */
    private static function rawSourceInvariant(array $payload): array {return [
        'raw_user_question'=>$payload['raw_user_question']??null,'primary_longtail_query'=>$payload['primary_longtail_query']??null,
        'canonical_query'=>$payload['canonical_query']??null,'query_record'=>$payload['query_record']??null,'query_aliases'=>$payload['query_aliases']??null,
    ];}

    /** @return array<string,mixed>|null */
    private static function retentionDecision(string $raw,string $family,array $portalScopeTerms=[]): ?array {
        if(PSTE_Normalizer::staleYear($raw)!==null)return ['reason_codes'=>['PSTE_RETAINED_NON_PRODUCING_STALE_YEAR_QUERY']];
        $transactional=(bool)preg_match('/\b(sale|angebot|angebote|rabatt|gutschein|coupon|shop|online\s+kaufen|bestellen|gebraucht\s+kaufen)\b/iu',$raw);
        $editorialSignal=PSTE_Article_Type_Intent_Ontology::hasExplicitIntentOrAmbiguity($raw);
        if($transactional&&!$editorialSignal)return ['reason_codes'=>['PSTE_RETAINED_NON_PRODUCING_TRANSACTIONAL_QUERY']];
        $probe=PSTE_Editorial_Topic_Normalizer::semanticProbe($raw);
        if(!self::hasEditorialIntentSignal($raw)){
            $probe=self::removeExactPortalScopeTokens($probe,$portalScopeTerms);
            if(self::sameTokenSet($probe,$family))return ['reason_codes'=>['PSTE_RETAINED_NON_PRODUCING_CATEGORY_HEAD_QUERY']];
        }
        return null;
    }
    private static function hasEditorialIntentSignal(string $raw): bool {
        return PSTE_Article_Type_Intent_Ontology::hasExplicitIntentOrAmbiguity($raw);
    }

    private static function removeExactPortalScopeTokens(string $value,array $portalScopeTerms): string {
        $tokens=PSTE_Family_Identity_V2::tokens($value,false);$scope=[];
        foreach($portalScopeTerms as $term)foreach(PSTE_Family_Identity_V2::tokens((string)$term,false) as $token)$scope[$token]=true;
        if(!$scope)return $value;$kept=array_values(array_filter($tokens,static fn($token)=>!isset($scope[$token])));return implode(' ',$kept);
    }

    private static function sameTokenSet(string $a,string $b): bool {
        $x=PSTE_Token_Equivalence::tokens(str_replace('-',' ',$a));$y=PSTE_Token_Equivalence::tokens(str_replace('-',' ',$b));
        $x=array_values(array_unique($x));$y=array_values(array_unique($y));sort($x,SORT_STRING);sort($y,SORT_STRING);return $x!==[]&&$x===$y;
    }

    /**
     * Build a non-authoritative title candidate from material that is already stored.
     * It intentionally runs before production family/category admission. The result may be shown
     * and exported, but it cannot populate production_title or satisfy planning/PSERC gates.
     *
     * Priority:
     * 1) stored user/PAA question;
     * 2) already stored normalized editorial formulation;
     * 3) the existing title pipeline using the immutable research-origin family only as
     *    candidate context (never as production family authority).
     *
     * @return array{title:string,source:string,source_sha256:string,production_authority:bool,provider_call:bool}
     */
    public static function storedTitleCandidateFromPayload(array $payload,array $baseline,array $registry=[]): array {
        // Raw query, PAA question and normalized text are NOT language-system titles.
        // Only the existing bound title-only import may author a title.
        return ['title'=>'','source'=>'','source_sha256'=>'','production_authority'=>false,'provider_call'=>false];
    }

    /** @return list<string> */
    private static function pipelineReasons(array $p): array {return array_values(array_unique(array_filter(array_merge((array)($p['deterministic']['reason_codes']??[]),(array)($p['language']['reason_codes']??[]),(array)($p['editorial_quality']['reason_codes']??[])))));}
    public static function canonicalInputQuery(string $v): string {$v=trim(html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8'));return trim((string)preg_replace('/\s+/u',' ',$v));}
    public static function sourceMatchesNormalPath(string $source,array $path): bool {$canonical=self::canonicalInputQuery($source);$pathRaw=self::canonicalInputQuery((string)($path['raw_query']??''));$pathSha=(string)($path['raw_query_sha256']??'');return $canonical!==''&&$pathRaw!==''&&preg_match('/^[a-f0-9]{64}$/',$pathSha)===1&&hash_equals($canonical,$pathRaw)&&hash_equals(hash('sha256',$pathRaw),$pathSha);}
    public static function payloadMatchesNormalPath(array $payload,array $path): bool {$pathRaw=self::canonicalInputQuery((string)($path['raw_query']??''));$pathSha=(string)($path['raw_query_sha256']??'');if($pathRaw===''||preg_match('/^[a-f0-9]{64}$/',$pathSha)!==1||!hash_equals(hash('sha256',$pathRaw),$pathSha))return false;$record=is_array($payload['query_record']??null)?(array)$payload['query_record']:[];$candidates=[PSTE_Editorializer::sourceQuery($payload),(string)($payload['primary_longtail_query']??''),(string)($payload['canonical_query']??''),(string)($payload['raw_user_question']??''),(string)($record['language_corrected_query']??''),(string)($record['raw_query']??'')];foreach($candidates as $candidate){$candidate=self::canonicalInputQuery((string)$candidate);if($candidate!==''&&hash_equals($candidate,$pathRaw))return true;}return false;}
    private static function clean(string $v): string {return self::canonicalInputQuery($v);}
    /** @return array<string,mixed> */
    private static function withReasons(array $base,string $status,array $reasons): array {
        $base['status']=$status;$base['ok']=$status==='NORMAL_PASS';
        $base['reason_codes']=array_values(array_unique(array_filter(array_map('strval',$reasons))));
        return self::attachWorkerFlow($base);
    }

    /** Lossless work checkpoint inside the EXISTING normal metadata payload. */
    private static function attachWorkerFlow(array $path): array {
        $raw=(string)($path['raw_query']??'');$status=(string)($path['status']??'REVIEW_REQUIRED');
        $steps=[];$next='';
        $relevance=(string)($path['portal_relevance']??'UNPROVEN');
        $steps['relevance']=['decision'=>$relevance==='PROVEN'?'GREEN':($raw===''?'RED':'YELLOW')];
        $title=(string)($path['title']??'');$pipeline=(array)($path['title_pipeline']??[]);
        $titleOk=$title!==''&&!empty($pipeline['ok']);
        $steps['title']=['decision'=>$titleOk?'GREEN':'YELLOW'];
        $type=(string)($path['article_type']??'');
        $risk=(array)($path['domain_risk']??[]);
        $term=(array)($path['target_category']??[]);
        $hasCategory=(int)($term['term_id']??0)>0&&(string)($term['slug']??'')!=='';
        // Read the ONE prior area decision; never infer OBEN/UNTEN again from
        // an available WP category or the article type selected by the title worker.
        $area=(string)($path['editorial_area']??'UNDECIDED');
        $areaProven=in_array($area,['FACH','MAGAZIN'],true);
        $laneOk=$areaProven&&$type!==''&&(!$risk||!empty($risk['ok']));
        $steps['lane']=['decision'=>$laneOk?'GREEN':'YELLOW',
            'type'=>$areaProven?$area:''];
        $steps['category']=['decision'=>$hasCategory?'GREEN':'YELLOW','slug'=>(string)($term['slug']??'')];
        foreach($steps as $name=>&$step){
            if($next!==''){$step['decision']='NOT_STARTED';continue;}
            if($step['decision']!=='GREEN')$next=$name;
        }unset($step);
        $reasonCodes=(array)($path['reason_codes']??[]);
        $categoryMissingConfirmed=$status==='STRUCTURE_GAP'&&$areaProven&&$titleOk&&$type!==''&&!$hasCategory
            &&(in_array('PSTE_VALID_JOURNAL_TITLE_CATEGORY_ABSENT',$reasonCodes,true)
                ||in_array('PSTE_SIGNED_TITLE_READY_CATEGORY_ABSENT',$reasonCodes,true)
                ||in_array('PSTE_PORTAL_RELEVANCE_PROVEN_FAMILY_ASSIGNMENT_NOT_PROVEN',$reasonCodes,true)
                ||in_array('PSTE_TITLE_READY_CATEGORY_DECISION_OPEN',$reasonCodes,true));
        // STRUCTURE_GAP caused by a missing research family is NOT a missing WP term.
        $path['category_backlog_required']=$categoryMissingConfirmed;
        // One decision, four separate work groups. Relevance not yet proven is
        // NEVER labelled as irrelevant; title work cannot leak into category review.
        // These are labels on the existing state, not an extra editor or database queue.
        $group=$relevance!=='PROVEN'?'RELEVANCE_REVIEW':
            (!$titleOk?'TITLE_WORK':
            ($status==='NORMAL_PASS'&&$hasCategory?'CATEGORY_ASSIGNED':
            ($status==='STRUCTURE_GAP'?'CATEGORY_REVIEW':'TITLE_WORK')));
        $path['work_group']=$group;
        $path['worker_flow']=[
            'contract'=>'PSTE_NORMAL_FOUR_STEPS_V1','steps'=>$steps,'work_group'=>$group,
            'next_step'=>$next,'resume_from'=>$next,
            'halt_reason_codes'=>$status==='NORMAL_PASS'?[]:$reasonCodes,
            'storage'=>$categoryMissingConfirmed?'CATEGORY_ROOM_TOPIC_POOL':(
                $status==='STRUCTURE_GAP'?'EXISTING_STRUCTURE_BACKLOG':(
                $status==='SANDBOX_REQUIRED'?'EXISTING_SANDBOX':(
                $status==='NORMAL_PASS'?'NORMAL_PATH':'EXISTING_RETAINED_QUEUE'))),
            'disposition'=>$status==='NORMAL_PASS'?'GREEN':(
                $status==='RETAINED_NON_PRODUCING'?'RED':'YELLOW'),
            'raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'',
            'article_type_registry_sha256'=>(string)($path['article_type_registry_sha256']??''),
            'write_attempted'=>false,
        ];
        // Never promote unresolved editorial/taxonomy decisions to production.
        if($status==='NORMAL_PASS'&&$next!=='')throw new RuntimeException('PSTE_WORKER_SEQUENCE_NORMAL_PASS_INCOMPLETE_'.strtoupper($next));
        return $path;
    }
}
