<?php
if (!defined('ABSPATH')) { exit; }

final class UGE_Frontend {
    private static string $title_initial = '';
    public static function init(): void {
        add_shortcode('universal_glossary', [__CLASS__, 'shortcode']);
        add_filter('the_content', [__CLASS__, 'inject_main_page'], 20);
        add_filter('template_include', [__CLASS__, 'template'], 99);
        add_action('wp_enqueue_scripts', [__CLASS__, 'assets']);
        add_filter('body_class', [__CLASS__, 'body_class']);
        add_filter('astra_post_featured_image_condition', [__CLASS__, 'astra_featured_image'], 999);
        add_filter('astra_featured_image_enabled', [__CLASS__, 'astra_featured_image'], 999);
        add_filter('astra_the_title_enabled', [__CLASS__, 'astra_title_enabled'], 999);
        add_action('wp_footer', [__CLASS__, 'render_design_breadcrumb_payload'], 19);
        add_action('wp_footer', [__CLASS__, 'home_interactions'], 60);
        add_action('wp_ajax_uge_search', [__CLASS__, 'ajax_search']);
        add_action('wp_ajax_nopriv_uge_search', [__CLASS__, 'ajax_search']);
    }

    public static function is_home_page(): bool {
        $cfg = UGE_Config::get();
        return (int)$cfg['main_page_id'] > 0 && is_page((int)$cfg['main_page_id']);
    }

    public static function requested_term_post(): ?WP_Post {
        if (empty($_SERVER['REQUEST_URI'])) { return null; }
        $cfg = UGE_Config::get();
        $base = trim((string)$cfg['rewrite_base'], '/');
        $segment = trim((string)$cfg['term_segment'], '/');
        if ($base === '' || $segment === '') { return null; }
        $path = trim((string)wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']), PHP_URL_PATH), '/');
        $prefix = $base . '/' . $segment . '/';
        if (!str_starts_with($path, $prefix)) { return null; }
        $tail = substr($path, strlen($prefix));
        if ($tail === '' || str_contains($tail, '/')) { return null; }
        $slug = sanitize_title(rawurldecode($tail));
        if ($slug === '') { return null; }
        $post = get_page_by_path($slug, OBJECT, UGE_Core::POST_TYPE);
        return ($post instanceof WP_Post && $post->post_status === 'publish') ? $post : null;
    }

    public static function is_glossary_view(): bool {
        return self::is_home_page() || is_tax(UGE_Core::TAXONOMY) || is_singular(UGE_Core::POST_TYPE) || self::requested_term_post() instanceof WP_Post;
    }

    public static function astra_featured_image($enabled) {
        return self::is_home_page() ? false : $enabled;
    }

    public static function astra_title_enabled($enabled) {
        return self::is_home_page() ? false : $enabled;
    }

    public static function body_class(array $classes): array {
        if (self::is_home_page()) { $classes[] = 'uge-glossary-home'; }
        if (is_tax(UGE_Core::TAXONOMY)) { $classes[] = 'uge-glossary-category'; }
        if (is_singular(UGE_Core::POST_TYPE) || self::requested_term_post() instanceof WP_Post) { $classes[] = 'uge-glossary-term'; }
        return $classes;
    }

    public static function inject_main_page(string $content): string {
        if (!is_singular('page') || !in_the_loop() || !is_main_query() || !self::is_home_page()) { return $content; }
        if (function_exists('has_shortcode') && has_shortcode($content, 'universal_glossary')) { return $content; }
        return self::render_home($content);
    }

    public static function shortcode(): string {
        return self::render_home('');
    }

    public static function template(string $template): string {
        if (is_singular(UGE_Core::POST_TYPE) || self::requested_term_post() instanceof WP_Post) {
            $candidate = UGE_DIR . 'templates/single-uge-term.php';
            return is_readable($candidate) ? $candidate : $template;
        }
        if (is_tax(UGE_Core::TAXONOMY)) {
            $candidate = UGE_DIR . 'templates/taxonomy-uge-group.php';
            return is_readable($candidate) ? $candidate : $template;
        }
        return $template;
    }

    public static function assets(): void {
        if (!self::is_glossary_view()) { return; }
        wp_register_style('uge', false, [], UGE_VERSION);
        wp_enqueue_style('uge');
        wp_add_inline_style('uge', self::css());
    }

    public static function home_url(): string {
        $page_id = (int)UGE_Config::get()['main_page_id'];
        return $page_id > 0 ? (string)get_permalink($page_id) : home_url('/' . trim((string)UGE_Config::get()['rewrite_base'], '/') . '/');
    }

    public static function navigation_icon(string $slug): string {
        $icons = [
            'rassen-zucht' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 17c2-5 5-9 10-10 2 1 4 3 5 6-3 0-5 1-6 4-2-1-5-1-9 0Z"/></svg>',
            'anatomie' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3c3 2 5 5 5 9s-2 7-5 9c-3-2-5-5-5-9s2-7 5-9Z"/><path d="M12 5v14M8 9h8M8 15h8"/></svg>',
            'gesundheit' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6Z"/></svg>',
            'haltung-fuetterung' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 20c8-2 12-8 14-16-8 2-14 6-14 16Z"/><path d="M7 17c3-4 6-7 10-10"/></svg>',
            'verhalten' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="8" cy="8" r="4"/><path d="M2 21c1-5 4-7 8-7s7 2 8 7"/></svg>',
            'reiten-ausbildung' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 16c3-6 7-9 13-9l3 4-4 2-2-2-3 6-7-1Z"/></svg>',
            'pferdesport' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4h10v5c0 4-2 6-5 6s-5-2-5-6V4Z"/><path d="M12 15v4m-4 2h8"/></svg>',
            'ausruestung-stall' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8c4 0 6 2 8 5 2-3 4-5 8-5v8c-3 2-13 2-16 0V8Z"/></svg>',
            'geschichte-kultur' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5c4-1 7 0 8 2v13c-1-2-4-3-8-2V5Zm16 0c-4-1-7 0-8 2v13c1-2 4-3 8-2V5Z"/></svg>',
            'kauf-recht-versicherung' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v18M7 6h10M6 8l-3 6h6L6 8Zm12 0-3 6h6l-3-6Z"/></svg>',
        ];
        return $icons[$slug] ?? '';
    }

    public static function render_navigation(bool $icons = false): string {
        $cfg = UGE_Config::get(); if (empty($cfg['show_groups'])) { return ''; }
        $groups=[]; foreach (UGE_Core::navigation_group_names() as $name) { $term=get_term_by('slug', sanitize_title($name), UGE_Core::TAXONOMY); if (!$term) {$term=get_term_by('name',$name,UGE_Core::TAXONOMY);} if ($term instanceof WP_Term) {$groups[]=$term;} }
        $current=is_tax(UGE_Core::TAXONOMY)?get_queried_object_id():0; ob_start();
        if ($icons) {
            echo '<section class="uge-topic-nav" aria-labelledby="uge-topic-title"><div class="uge-section-head"><span>Nach Themen stöbern</span><h2 id="uge-topic-title">Kategorien</h2></div><nav class="uge-topic-grid" aria-label="Glossar-Kategorien">';
            foreach($groups as $group){$url=get_term_link($group,UGE_Core::TAXONOMY);if(is_wp_error($url))continue;printf('<a class="uge-topic%s" href="%s"><span class="uge-topic-icon">%s</span><strong>%s</strong></a>',$current===(int)$group->term_id?' is-active':'',esc_url($url),self::navigation_icon(sanitize_title((string)$group->name)),esc_html($group->name));}
            echo '</nav></section>';
        } else {
            echo '<nav class="uge-nav" aria-label="Glossar-Bereiche"><div class="uge-nav-scroll">'; foreach($groups as $group){$url=get_term_link($group,UGE_Core::TAXONOMY);if(is_wp_error($url))continue;printf('<a class="%s" href="%s">%s</a>',$current===(int)$group->term_id?'is-active':'',esc_url($url),esc_html($group->name));} echo '</div></nav>';
        }
        return (string)ob_get_clean();
    }

    public static function resolve_related_term(string $label): ?WP_Post {
        $label = trim(wp_strip_all_tags($label));
        if ($label === '') { return null; }
        $matches = get_posts([
            'post_type' => UGE_Core::POST_TYPE,
            'post_status' => 'publish',
            'posts_per_page' => 3,
            'orderby' => 'ID',
            'order' => 'ASC',
            'title' => $label,
            'suppress_filters' => false,
        ]);
        $exact = [];
        foreach ($matches as $candidate) {
            if ($candidate instanceof WP_Post && trim(wp_strip_all_tags($candidate->post_title)) === $label) { $exact[] = $candidate; }
        }
        if (count($exact) === 1) { return $exact[0]; }
        if (count($exact) > 1) { return null; }
        $by_slug = get_page_by_path(sanitize_title($label), OBJECT, UGE_Core::POST_TYPE);
        return ($by_slug instanceof WP_Post && $by_slug->post_status === 'publish') ? $by_slug : null;
    }

    public static function render_design_breadcrumb_payload(): void {
        if (is_admin() || is_feed() || self::is_home_page()) { return; }
        $term = is_tax(UGE_Core::TAXONOMY) ? get_queried_object() : null;
        $post = self::requested_term_post();
        if (!$term instanceof WP_Term && !$post instanceof WP_Post) { return; }
        if ($post instanceof WP_Post) {
            $nav = UGE_Core::navigation_group_for_post($post->ID);
            $term = $nav instanceof WP_Term ? $nav : null;
        }
        $parts = [
            ['name'=>'Startseite','url'=>home_url('/')],
            ['name'=>'Glossar','url'=>self::home_url()],
        ];
        if ($term instanceof WP_Term) {
            $url = get_term_link($term, UGE_Core::TAXONOMY);
            $parts[] = ['name'=>$term->name,'url'=>$post instanceof WP_Post && !is_wp_error($url) ? (string)$url : ''];
        }
        if ($post instanceof WP_Post) { $parts[] = ['name'=>$post->post_title,'url'=>'']; }
        $visible=[];
        foreach ($parts as $part) {
            $name=trim((string)$part['name']); $url=trim((string)$part['url']);
            if ($name==='') { continue; }
            $visible[]=$url==='' ? '<span class="pftk-content-breadcrumb-current" aria-current="page">'.esc_html($name).'</span>' : '<a href="'.esc_url($url).'">'.esc_html($name).'</a>';
        }
        if (count($visible)<2) { return; }
        $nav='<nav class="pftk-content-breadcrumb" aria-label="Breadcrumb">'.implode('<span class="pftk-content-breadcrumb-separator" aria-hidden="true">›&nbsp;</span>',$visible).'</nav>';
        echo '<div id="uge-pftk-breadcrumb-payload" hidden><div class="pftk-universal-breadcrumb-wrap pftk-breadcrumb-mounted uge-pftk-breadcrumb-mounted">'.$nav.'</div></div>';
        echo '<style id="uge-pftk-breadcrumb-contract">'
            .'body.uge-glossary-category .site-content,body.uge-glossary-term .site-content{padding-top:var(--pftk-navigation-content-gap,18px)!important}'
            .'body.uge-glossary-category .ast-container,body.uge-glossary-term .ast-container{padding-top:0!important}'
            .'.pftk-universal-breadcrumb-wrap.pftk-breadcrumb-mounted{box-sizing:border-box!important;position:relative!important;width:min(calc(100vw - 32px),var(--pftk-breadcrumb-axis-width,900px))!important;max-width:none!important;margin:0 auto var(--pftk-breadcrumb-title-gap,10px)!important;transform:none!important;padding:0!important;clear:both!important}'
            .'.pftk-universal-breadcrumb-wrap.pftk-breadcrumb-mounted .pftk-content-breadcrumb{display:flex;flex-wrap:wrap;align-items:center;column-gap:7px;row-gap:5px;margin:0!important;font-size:14px;line-height:1.5;color:#72786F}'
            .'.pftk-universal-breadcrumb-wrap .pftk-content-breadcrumb-separator{display:inline-flex;align-items:center;margin-left:2px;margin-right:3px;color:#92988F!important}'
            .'.pftk-universal-breadcrumb-wrap .pftk-content-breadcrumb a,.pftk-universal-breadcrumb-wrap .pftk-content-breadcrumb a:visited{color:#72786F!important;font-weight:400!important;text-decoration:none!important}'
            .'.pftk-universal-breadcrumb-wrap .pftk-content-breadcrumb-current{color:#4F5650!important;font-weight:500!important;text-decoration:none!important}'
            .'body.uge-glossary-category .site-content>.pftk-breadcrumb-mounted+.ast-container,body.uge-glossary-term .site-content>.pftk-breadcrumb-mounted+.ast-container{margin-top:0!important;padding-top:0!important}'
            .'@media(max-width:921px){body.uge-glossary-category .site-content,body.uge-glossary-term .site-content{--pftk-navigation-content-gap:14px}}'
            .'@media(max-width:544px){body.uge-glossary-category .site-content,body.uge-glossary-term .site-content{--pftk-navigation-content-gap:10px}}'
            .'</style>';
        echo '<script>(function(){function mount(){var p=document.getElementById("uge-pftk-breadcrumb-payload");var s=document.querySelector(".site-content");if(!p||!s)return;if(s.querySelector(":scope > .pftk-breadcrumb-mounted")){p.remove();return;}var w=p.firstElementChild;if(!w)return;s.insertBefore(w,s.firstChild);p.remove();}if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",mount,{once:true});}else{mount();}})();</script>';
    }

    public static function render_breadcrumbs(?WP_Term $term=null, ?WP_Post $post=null): string {
        $parts=['<a href="'.esc_url(home_url('/')).'">Startseite</a>','<a href="'.esc_url(self::home_url()).'">Glossar</a>'];
        if($term instanceof WP_Term){$parts[]=$post instanceof WP_Post?'<a href="'.esc_url(get_term_link($term,UGE_Core::TAXONOMY)).'">'.esc_html($term->name).'</a>':'<span aria-current="page">'.esc_html($term->name).'</span>';}
        if($post instanceof WP_Post){$parts[]='<span aria-current="page">'.esc_html($post->post_title).'</span>';}
        return '<nav class="uge-breadcrumbs" aria-label="Breadcrumb">'.implode('<span class="uge-breadcrumb-sep">›</span>',$parts).'</nav>';
    }

    public static function render_search_tools(): string {
        $cfg = UGE_Config::get();
        if (empty($cfg['show_search']) && empty($cfg['show_az'])) { return ''; }
        ob_start();
        echo '<div class="uge-tools">';
        if (!empty($cfg['show_search'])) {
            $value = isset($_GET['glossar_s']) ? sanitize_text_field(wp_unslash($_GET['glossar_s'])) : '';
            printf('<form class="uge-search-form" method="get" action="%s" data-uge-ajax-url="%s" data-uge-nonce="%s"><label class="screen-reader-text" for="uge-search">Glossar durchsuchen</label><input id="uge-search" name="glossar_s" type="search" value="%s" placeholder="Begriff suchen …" autocomplete="off"><button type="submit">Suchen</button><span class="uge-search-status" role="status" aria-live="polite"></span><div class="uge-search-suggestions" hidden></div></form>', esc_url(self::home_url()), esc_url(admin_url('admin-ajax.php')), esc_attr(wp_create_nonce('uge_search')), esc_attr($value));
        }
        if (!empty($cfg['show_az'])) {
            echo '<nav class="uge-az" aria-label="Glossar A bis Z">';
            foreach (range('A', 'Z') as $letter) {
                $url = add_query_arg('glossar_letter', $letter, self::home_url());
                printf('<a href="%s">%s</a>', esc_url($url), esc_html($letter));
            }
            echo '</nav>';
        }
        echo '</div>';
        return (string)ob_get_clean();
    }

    private static function render_home(string $page_content): string {
        $cfg = UGE_Config::get();
     $query = isset($_GET['glossar_s']) ? trim(sanitize_text_field(wp_unslash($_GET['glossar_s']))) : '';
        $letter = isset($_GET['glossar_letter']) ? strtoupper(substr(sanitize_text_field(wp_unslash($_GET['glossar_letter'])), 0, 1)) : '';
        $filtered = $query !== '' || preg_match('/^[A-Z]$/', $letter);

        ob_start();
        echo '<div class="uge">';
        echo self::render_hero($page_content);
        echo self::render_search_tools();
        echo self::render_navigation(true);
        echo self::render_home_banner();
        echo '<div id="uge-live-results" class="uge-live-results" aria-live="polite">';

        if ($filtered) {
            echo self::render_filtered_results($query, $letter);
        } else {
            $terms = get_posts([
                'post_type' => UGE_Core::POST_TYPE,
                'post_status' => 'publish',
                'posts_per_page' => (int)$cfg['home_term_count'],
                'orderby' => 'modified',
                'order' => 'DESC',
                'no_found_rows' => true,
            ]);
            echo '<section class="uge-home-latest" aria-labelledby="uge-latest-title">';
            echo '<div class="uge-latest-head"><div class="uge-section-head"><span>Aktuell im Glossar</span><h2 id="uge-latest-title">Pferdewissen zum Entdecken</h2></div>';
            if (count($terms) > 3) {
                echo '<div class="uge-slider-controls" aria-label="Glossarbegriffe durchblättern"><button type="button" data-uge-slide="prev" aria-label="Vorherige Begriffe">&#8592;</button><button type="button" data-uge-slide="next" aria-label="Nächste Begriffe">&#8594;</button></div>';
            }
            echo '</div>';
            echo self::render_cards($terms, true);
            if (!$terms) { echo '<p>Es sind noch keine Glossarbegriffe veröffentlicht.</p>'; }
            echo '</section>';
            echo self::render_home_copy($page_content);
        }
        echo '</div>';
        echo '</div>';
        return (string)ob_get_clean();
    }

    private static function render_home_copy(string $page_content): string {
        $copy = trim($page_content);
        if ($copy === '' || (function_exists('has_shortcode') && has_shortcode($copy, 'universal_glossary'))) { return ''; }
        return '<section class="uge-home-copy">' . wp_kses_post($copy) . '</section>';
    }

    public static function home_interactions(): void {
        if (!self::is_home_page()) { return; }
        ?>
        <script>
        (function(){
            document.addEventListener('click',function(e){
                var button=e.target.closest('[data-uge-slide]');
                if(!button)return;
                var track=document.querySelector('[data-uge-slider]');
                if(!track)return;
                var card=track.querySelector('.uge-card');
                if(!card)return;
                var gap=parseFloat(getComputedStyle(track).gap)||16;
                var amount=card.getBoundingClientRect().width+gap;
                track.scrollBy({left:button.dataset.ugeSlide==='next'?amount:-amount,behavior:'smooth'});
            });

            var form=document.querySelector('.uge-search-form');
            var target=document.getElementById('uge-live-results');
            var suggestions=document.querySelector('.uge-search-suggestions');
            if(!form||!target||!suggestions||!window.fetch)return;
            var input=form.querySelector('input[name="glossar_s"]');
            var status=form.querySelector('.uge-search-status');
            if(!input)return;
            var timer=null, controller=null;
            function clearSuggestions(){suggestions.innerHTML='';suggestions.hidden=true;if(status)status.textContent='';}
            function requestSuggestions(){
                var q=input.value.trim();
                if(q.length<2){clearSuggestions();return;}
                if(controller)controller.abort();
                controller=new AbortController();
                var body=new FormData();
                body.append('action','uge_search'); body.append('nonce',form.dataset.ugeNonce||''); body.append('q',q);
                if(status)status.textContent='Suche läuft …';
                fetch(form.dataset.ugeAjaxUrl,{method:'POST',credentials:'same-origin',body:body,signal:controller.signal})
                  .then(function(r){if(!r.ok)throw new Error('http');return r.json();})
                  .then(function(data){
                    if(!data||!data.success||!data.data)return clearSuggestions();
                    var items=data.data.items||[];
                    if(!items.length){suggestions.innerHTML='<div class="uge-suggestion-empty">Kein passender Begriff</div>';suggestions.hidden=false;if(status)status.textContent='0 Treffer';return;}
                    suggestions.innerHTML=items.slice(0,8).map(function(item){return '<a class="uge-suggestion" href="'+item.url+'">'+item.title+'</a>';}).join('');
                    suggestions.hidden=false;if(status)status.textContent=items.length===1?'1 Treffer':items.length+' Treffer';
                  }).catch(function(err){if(err&&err.name==='AbortError')return;clearSuggestions();});
            }
            input.addEventListener('input',function(){window.clearTimeout(timer);timer=window.setTimeout(requestSuggestions,180);});
            input.addEventListener('focus',function(){if(input.value.trim().length>=2)requestSuggestions();});
            document.addEventListener('click',function(e){if(!form.contains(e.target)&&!suggestions.contains(e.target))clearSuggestions();});
        })();
        </script>
        <?php
    }

    public static function ajax_search(): void {
        check_ajax_referer('uge_search', 'nonce');
        $query = isset($_POST['q']) ? trim(sanitize_text_field(wp_unslash($_POST['q']))) : '';
        if ($query === '') {
            wp_send_json_success(['count' => 0, 'items' => []]);
        }
        $posts = self::search_posts($query, 12);
        $items = array_map(static function($post) {
            return [
                'title' => esc_html(get_the_title($post)),
                'url' => get_permalink($post),
            ];
        }, $posts);
        wp_send_json_success(['count' => count($posts), 'items' => $items]);
    }

    private static function search_posts(string $query, int $limit): array {
        $common = [
            'post_type' => UGE_Core::POST_TYPE,
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'orderby' => 'title',
            'order' => 'ASC',
            'no_found_rows' => true,
        ];
        $posts = get_posts(array_merge($common, ['s' => $query]));
        $meta = get_posts(array_merge($common, [
            'meta_query' => [
                'relation' => 'OR',
                ['key' => UGE_Core::meta_key('short_definition'), 'value' => $query, 'compare' => 'LIKE'],
                ['key' => UGE_Core::meta_key('synonyms'), 'value' => $query, 'compare' => 'LIKE'],
            ],
        ]));
        $by_id = [];
        foreach (array_merge($posts, $meta) as $post) {
            if ($post instanceof WP_Post) { $by_id[(int)$post->ID] = $post; }
        }
        $posts = array_values($by_id);
        usort($posts, static fn($a, $b) => strnatcasecmp((string)$a->post_title, (string)$b->post_title));
        return array_slice($posts, 0, $limit);
    }

    private static function render_hero(string $page_content): string {
        $cfg = UGE_Config::get();
        $page_id = (int)$cfg['main_page_id'];
        $title = $page_id > 0 ? get_the_title($page_id) : $cfg['label'];
        $excerpt = $page_id > 0 ? trim((string)get_post_field('post_excerpt', $page_id)) : '';
        if ($excerpt === '') {
            $plain = trim(wp_strip_all_tags(strip_shortcodes($page_content)));
            $excerpt = $plain !== '' ? wp_trim_words($plain, 28, '…') : '';
        }
        $image = $page_id > 0 ? get_the_post_thumbnail_url($page_id, 'full') : '';
        if (empty($image)) { $image = self::hero_fallback_url(); }
        $image_html = !empty($image) ? sprintf('<img class="uge-hero-image" src="%s" alt="%s" fetchpriority="high">', esc_url($image), esc_attr($title)) : '';
        $excerpt_html = $excerpt !== '' ? '<p>' . esc_html($excerpt) . '</p>' : '';
        return '<section class="uge-hero' . ($image === '' ? ' uge-hero-no-image' : '') . '">' . $image_html . '<div class="uge-hero-copy"><span>WISSEN</span><h1>' . esc_html($title) . '</h1>' . $excerpt_html . '</div><i aria-hidden="true"></i></section>';
    }

    private static function hero_fallback_url(): string {
        $url = plugins_url('assets/glossar-hero-books-stall.webp', UGE_FILE);
        return (string)apply_filters('uge_hero_image_url', $url, (int)(UGE_Config::get()['main_page_id'] ?? 0), 'embedded');
    }

    private static function render_home_banner(): string {
        $page_id = (int)(UGE_Config::get()['main_page_id'] ?? 0);
        ob_start();
        do_action('uge_ad_slot', 'home_banner', $page_id);
        $content = trim((string)ob_get_clean());
        return '<div class="uge-home-banner-slot" data-uge-ad-slot="home_banner">' . $content . '</div>';
    }

    private static function render_filtered_results(string $query, string $letter): string {
        $cfg = UGE_Config::get();
        $args = [
            'post_type' => UGE_Core::POST_TYPE,
            'post_status' => 'publish',
            'posts_per_page' => (int)$cfg['category_per_page'],
            'orderby' => 'title',
            'order' => 'ASC',
            'no_found_rows' => true,
        ];
        if ($query !== '') {
            $posts = self::search_posts($query, (int)$cfg['category_per_page']);
            $headline = 'Suchergebnisse für „' . esc_html($query) . '“';
            return '<section class="uge-section"><header class="uge-section-head"><h2>' . $headline . '</h2></header>' . self::render_cards($posts) . (!$posts ? '<p>Keine passenden Glossarbegriffe gefunden.</p>' : '') . '</section>';
        }
        if ($letter !== '' && preg_match('/^[A-Z]$/', $letter)) {
            self::$title_initial = $letter;
            $args['suppress_filters'] = false;
            add_filter('posts_where', [__CLASS__, 'posts_where_initial'], 20, 2);
        }
        $posts = get_posts($args);
        if (self::$title_initial !== '') {
            remove_filter('posts_where', [__CLASS__, 'posts_where_initial'], 20);
            self::$title_initial = '';
        }
        $headline = $query !== '' ? 'Suchergebnisse für „' . esc_html($query) . '“' : 'Begriffe mit ' . esc_html($letter);
        return '<section class="uge-section"><header class="uge-section-head"><h2>' . $headline . '</h2></header>' . self::render_cards($posts) . (!$posts ? '<p>Keine passenden Glossarbegriffe gefunden.</p>' : '') . '</section>';
    }

    public static function posts_where_initial(string $where, WP_Query $query): string {
        if (self::$title_initial === '') { return $where; }
        global $wpdb;
        $like = $wpdb->esc_like(self::$title_initial) . '%';
        return $where . $wpdb->prepare(" AND {$wpdb->posts}.post_title LIKE %s", $like);
    }

    public static function render_cards(array $posts, bool $slider = false): string {
        if (!$posts) { return ''; }
        ob_start();
        echo '<div class="uge-cards' . ($slider ? ' uge-cards-slider' : '') . '"' . ($slider ? ' data-uge-slider' : '') . '>';
        foreach ($posts as $post) {
            $definition = UGE_Core::term_value((int)$post->ID, 'short_definition');
            $nav_group = UGE_Core::navigation_group_for_post((int)$post->ID);
            $group = $nav_group instanceof WP_Term ? $nav_group->name : '';
            echo '<article class="uge-card">';
            echo '<div class="uge-card-copy">';
            if ($group !== '') { echo '<span>' . esc_html($group) . '</span>'; }
            echo '<h3><a href="' . esc_url(get_permalink($post)) . '">' . esc_html($post->post_title) . '</a></h3>';
            if ($definition !== '') { echo '<p>' . esc_html($definition) . '</p>'; }
            echo '<a class="uge-more" href="' . esc_url(get_permalink($post)) . '">Mehr erfahren</a>';
            echo '</div></article>';
        }
        echo '</div>';
        return (string)ob_get_clean();
    }

    public static function render_category_page(): string {
        $term = get_queried_object();
        if (!$term instanceof WP_Term || is_wp_error($term)) { return ''; }
        $cfg = UGE_Config::get();
        $page_content = (int)$cfg['main_page_id'] > 0 ? (string)get_post_field('post_content', (int)$cfg['main_page_id']) : '';
        $paged = max(1, (int)get_query_var('paged'));
        $q = new WP_Query([
            'post_type' => UGE_Core::POST_TYPE,
            'post_status' => 'publish',
            'posts_per_page' => (int)$cfg['category_per_page'],
            'paged' => $paged,
            'orderby' => 'title',
            'order' => 'ASC',
            'tax_query' => [[
                'taxonomy' => UGE_Core::TAXONOMY,
                'field' => 'term_id',
                'terms' => [(int)$term->term_id],
            ]],
        ]);
        ob_start();
        echo '<div class="uge">';
        echo self::render_hero($page_content);
        echo self::render_search_tools();
        echo self::render_navigation(true);
        echo '<section class="uge-section uge-category-section">';
        echo '<header class="uge-category-head"><span>WISSEN</span><h1>' . esc_html($term->name) . '</h1>';
        if (!empty($term->description)) { echo '<p>' . esc_html($term->description) . '</p>'; }
        echo '</header>';
        echo self::render_cards($q->posts);
        if (!$q->posts) { echo '<p>In diesem Bereich sind noch keine Begriffe veröffentlicht.</p>'; }
        if ($q->max_num_pages > 1) {
            echo '<nav class="uge-pagination" aria-label="Seitennavigation">';
            echo paginate_links(['total' => (int)$q->max_num_pages, 'current' => $paged, 'type' => 'list']);
            echo '</nav>';
        }
        echo '</section></div>';
        wp_reset_postdata();
        return (string)ob_get_clean();
    }

    private static function css(): string {
        $t = UGE_Config::design_tokens();
        $v = sprintf('--uge-olive:%s;--uge-olive2:%s;--uge-ochre:%s;--uge-paper:%s;--uge-text:%s;--uge-muted:%s;--uge-line:%s;--uge-surface:%s;',
            esc_attr($t['olive']), esc_attr($t['olive2']), esc_attr($t['ochre']), esc_attr($t['paper']), esc_attr($t['text']), esc_attr($t['muted']), esc_attr($t['line']), esc_attr($t['surface'])
        );
        return '.uge{'.$v.'width:min(100%,1320px);margin:0 auto;padding:0 28px 64px;color:var(--uge-text);font-family:inherit;box-sizing:border-box}.uge *{box-sizing:border-box}.uge a{text-decoration:none}.uge h1,.uge h2,.uge h3{font-family:var(--pa-global-title-font,"Cormorant Garamond",Georgia,"Times New Roman",serif)!important;color:var(--uge-olive)!important;font-weight:500}.uge-nav{margin:0 0 42px;border-top:1px solid var(--uge-line);border-bottom:1px solid var(--uge-line);background:#fff}.uge-nav-scroll{display:flex;gap:0;justify-content:center;align-items:center;flex-wrap:wrap;overflow:visible}.uge-nav a{flex:0 0 auto;padding:14px 16px;color:var(--uge-olive)!important;font-size:12px;font-weight:700;letter-spacing:.02em;white-space:nowrap}.uge-nav a:hover,.uge-nav a:focus-visible,.uge-nav a.is-active{color:var(--uge-ochre)!important}.uge-hero{position:relative;min-height:0;margin:0 0 28px;overflow:hidden;background:#F9F7F2}.uge-hero>i{position:absolute;z-index:5;inset:7px;border:1px solid rgba(53,66,42,.62);pointer-events:none}.uge-hero-image{display:block!important;position:relative!important;inset:auto!important;width:100%!important;max-width:100%!important;height:auto!important;min-height:0!important;aspect-ratio:auto!important;object-fit:contain!important;object-position:center!important;box-shadow:none!important}.uge-hero:after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(249,247,242,.995) 0%,rgba(249,247,242,.985) 31%,rgba(249,247,242,.82) 46%,rgba(249,247,242,.16) 63%,rgba(249,247,242,0) 74%)}.uge-hero-copy{position:absolute;z-index:2;display:flex;inset:0 auto 0 0;height:auto;min-height:0;width:min(610px,50%);padding:42px 54px;flex-direction:column;justify-content:center}.uge-hero-copy>span,.uge-section-head>span,.uge-category-head>span,.uge-card-copy>span{display:block;color:var(--uge-ochre);font-size:10px;font-weight:700;letter-spacing:.16em;text-transform:uppercase}.uge-hero h1{margin:8px 0 10px!important;font-size:clamp(32px,3.05vw,44px)!important;line-height:1.03!important}.uge-hero p{max-width:560px;margin:0!important;color:#1F231F;font-size:14px;line-height:1.48}.uge-hero-no-image{min-height:360px}.uge-hero-no-image:after{display:none}.uge-hero-no-image .uge-hero-copy{width:100%;max-width:760px}.uge-tools{margin:0 0 18px;padding:26px 24px 22px;border-top:1px solid rgba(53,66,42,.18);border-bottom:1px solid rgba(53,66,42,.18);background:var(--uge-paper)}.uge-search-form{position:relative;display:flex;max-width:760px;margin:0 auto 20px;padding-bottom:18px;z-index:20}.uge-search-form input{width:100%;min-height:48px;padding:11px 15px;border:1px solid rgba(53,66,42,.28);border-right:0;border-radius:0;background:#fff;color:var(--uge-text);font-size:14px}.uge-search-form button{min-height:48px;padding:0 21px;border:1px solid var(--uge-olive);border-radius:0;background:var(--uge-olive);color:#fff;font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase}.uge-search-form button:hover,.uge-search-form button:focus-visible{border-color:var(--uge-ochre);background:var(--uge-ochre)}.uge-search-status{position:absolute;left:0;bottom:0;color:var(--uge-muted);font-size:11px;line-height:1.2}.uge-search-suggestions{position:absolute;z-index:30;left:0;right:0;top:48px;border:1px solid var(--uge-line);background:#fff;box-shadow:0 10px 24px rgba(53,66,42,.12);text-align:left}.uge-search-suggestions[hidden]{display:none}.uge-suggestion{display:block;padding:12px 14px;border-bottom:1px solid var(--uge-line);color:var(--uge-olive)!important;font-size:14px;font-weight:700}.uge-suggestion:last-child{border-bottom:0}.uge-suggestion:hover,.uge-suggestion:focus-visible{background:var(--uge-paper)}.uge-suggestion-empty{padding:12px 14px;color:var(--uge-muted);font-size:13px}.uge-live-results{transition:opacity .15s ease}.uge-live-results.is-loading{opacity:.45;pointer-events:none}.uge-az{display:flex;gap:2px;justify-content:center;flex-wrap:wrap;overflow:visible;padding-bottom:3px}.uge-az a{display:flex;min-width:31px;height:31px;align-items:center;justify-content:center;color:var(--uge-olive)!important;font-size:11px;font-weight:700}.uge-az a:hover,.uge-az a:focus-visible{color:var(--uge-ochre)!important}.uge-breadcrumbs{display:flex;gap:7px;align-items:center;flex-wrap:wrap;width:min(calc(100vw - 32px),var(--pftk-breadcrumb-axis-width,900px));max-width:none;margin:0 auto 10px;color:#72786F;font-size:14px;line-height:1.5}.uge-breadcrumbs a{color:#72786F!important;font-weight:400!important;text-decoration:none!important}.uge-breadcrumbs a:hover,.uge-breadcrumbs a:focus-visible{color:#9A6400!important;text-decoration:underline!important;text-underline-offset:3px}.uge-breadcrumbs [aria-current="page"]{color:#4F5650;font-weight:500}.uge-breadcrumb-sep{margin-left:2px;margin-right:3px;color:#92988F;opacity:1}.uge-topic-nav{margin:30px 0 42px;padding-top:6px;border-top:1px solid var(--uge-line)}.uge-topic-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:20px 14px;justify-items:center;max-width:1120px;margin:0 auto}.uge-topic{display:flex;width:100%;max-width:180px;align-items:center;flex-direction:column;text-align:center;color:var(--uge-olive)!important}.uge-topic-icon{display:flex;width:58px;height:58px;align-items:center;justify-content:center;margin-bottom:9px;border-radius:50%;background:var(--uge-paper);color:var(--uge-olive)}.uge-topic-icon svg{width:30px;height:30px;fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}.uge-topic strong{font-size:12px;line-height:1.35}.uge-section{margin:40px 0}.uge-section-head,.uge-category-head{max-width:820px;margin:0 auto 22px;text-align:center}.uge-section-head h2,.uge-category-head h1{margin:6px 0 8px!important;font-size:clamp(30px,3vw,42px)!important;line-height:1.08!important}.uge-section-head p,.uge-category-head p{margin:0;color:var(--uge-muted);font-size:14px;line-height:1.6}.uge-home-latest{margin:44px 0 0}.uge-latest-head{display:flex;flex-direction:column;align-items:center;margin-bottom:22px}.uge-latest-head .uge-section-head{margin-bottom:0}.uge-slider-controls{position:static;display:flex;gap:7px;margin-top:14px}.uge-slider-controls button{display:flex;width:38px;height:38px;align-items:center;justify-content:center;border:1px solid rgba(53,66,42,.28);border-radius:0;background:#fff;color:var(--uge-olive);font-size:18px;cursor:pointer}.uge-slider-controls button:hover,.uge-slider-controls button:focus-visible{border-color:var(--uge-ochre);background:var(--uge-ochre);color:#fff}.uge-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.uge-cards-slider{display:flex;gap:16px;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;padding:2px 1px 8px}.uge-cards-slider::-webkit-scrollbar{display:none}.uge-cards-slider .uge-card{flex:0 0 calc((100% - 32px)/3);scroll-snap-align:start}.uge-card{display:flex;min-height:225px;border:1px solid var(--uge-line);background:#fff;transition:border-color .18s ease,transform .18s ease}.uge-card-copy{display:flex;width:100%;padding:24px 22px;flex-direction:column}.uge-card h3{margin:7px 0 9px!important;font-size:23px!important;line-height:1.13!important}.uge-card h3 a{color:var(--uge-olive)!important}.uge-card p{margin:0 0 16px;color:var(--uge-muted);font-size:14px;line-height:1.55}.uge-more{align-self:flex-start;margin-top:auto;color:#8E670D!important;font-size:10.5px;font-weight:700;letter-spacing:.04em;text-transform:uppercase}.uge-card:hover,.uge-card:focus-within{border-color:var(--uge-ochre);transform:translateY(-2px)}.uge-card:hover .uge-more,.uge-card:focus-within .uge-more{color:var(--uge-ochre)!important}.uge-home-copy{max-width:980px;margin:50px auto 0;padding:34px 0 0;border-top:1px solid rgba(53,66,42,.18);font-size:15px;line-height:1.72}.uge-home-copy h2{margin:0 0 14px!important;font-size:clamp(28px,3vw,38px)!important}.uge-home-copy p{margin:0 0 16px}.uge-pagination{margin:32px 0 0}.uge-pagination ul{display:flex;gap:7px;justify-content:center;margin:0;padding:0;list-style:none}.uge-pagination a,.uge-pagination span{display:flex;min-width:36px;height:36px;padding:0 8px;align-items:center;justify-content:center;border:1px solid var(--uge-line);color:var(--uge-olive)!important}.uge-pagination .current{border-color:var(--uge-olive);background:var(--uge-olive);color:#fff!important}.uge-single-wrap{width:min(100%,980px);margin:0 auto;padding:0 28px 64px}.uge-single-header{max-width:760px;margin:32px auto 26px;text-align:center}.uge-single-header h1{margin:7px 0 12px!important;font-size:clamp(34px,4vw,50px)!important;line-height:1.04!important}.uge-definition{margin:0!important;color:var(--uge-muted);font-size:18px;line-height:1.55}.uge-content{max-width:780px;margin:0 auto;font-size:16px;line-height:1.72}.uge-content h2{margin:34px 0 10px!important;font-size:30px!important}.uge-meta{max-width:780px;margin:32px auto 0;padding-top:20px;border-top:1px solid var(--uge-line);font-size:14px}.uge-ad-slot{max-width:780px;margin:30px auto}.uge-ad-slot:empty{display:none}.uge-home-banner-slot{width:100%;margin:0 0 42px}.uge-home-banner-slot:empty{display:none}body.uge-glossary-home #primary,body.uge-glossary-category #primary,body.uge-glossary-term #primary{margin-top:0!important}body.uge-glossary-home .entry-header{display:none!important}body.uge-glossary-home .entry-content>.uge{width:calc(100vw - 48px);max-width:1320px;margin-left:50%;margin-right:0;transform:translateX(-50%)}@media(max-width:1000px){.uge-topic-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.uge-cards{grid-template-columns:repeat(2,minmax(0,1fr))}.uge-cards-slider .uge-card{flex-basis:calc((100% - 16px)/2)}}@media(max-width:720px){.uge-topic-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:18px 10px}.uge{padding:14px 16px 44px}.uge-nav{margin-left:-16px;margin-right:-16px}.uge-nav-scroll{padding-left:8px}.uge-hero{display:flex;min-height:0;flex-direction:column}.uge-hero-image{display:block!important;position:relative!important;order:1;width:100%!important;max-width:100%!important;height:auto!important;min-height:0!important;aspect-ratio:auto!important;object-fit:contain!important;object-position:center!important}.uge-hero:after{display:none}.uge-hero-copy{position:relative;inset:auto;order:2;height:auto;min-height:0;width:100%;padding:25px 22px 28px;background:#F9F7F2}.uge-hero h1{font-size:clamp(30px,9vw,39px)!important}.uge-tools{margin-left:-16px;margin-right:-16px;padding:22px 16px 18px}.uge-search-form input{min-width:0}.uge-search-form button{padding:0 15px}.uge-az{justify-content:flex-start}.uge-latest-head{padding-right:0}.uge-latest-head .uge-section-head{text-align:center}.uge-slider-controls{position:static}.uge-cards{grid-template-columns:1fr}.uge-cards-slider .uge-card{flex-basis:88%}.uge-card{min-height:0}.uge-home-copy{margin-top:38px;padding-top:28px}.uge-single-wrap{padding:0 16px 44px}body.uge-glossary-home .entry-content>.uge{width:calc(100vw - 24px)}}';
    }
}
