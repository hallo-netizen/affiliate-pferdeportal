<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="primary">
    <?php echo UGE_Frontend::render_category_page(); ?>
</main>
<?php
get_footer();
