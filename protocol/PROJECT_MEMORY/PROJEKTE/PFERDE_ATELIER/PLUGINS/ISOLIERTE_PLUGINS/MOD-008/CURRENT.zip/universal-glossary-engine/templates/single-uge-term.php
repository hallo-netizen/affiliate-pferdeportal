<?php
if (!defined('ABSPATH')) { exit; }
get_header();
$uge_post = UGE_Frontend::requested_term_post();
if (!$uge_post instanceof WP_Post) {
    $queried = get_queried_object();
    $is_valid_term = $queried instanceof WP_Post && $queried->post_type === UGE_Core::POST_TYPE;
    $is_public = $is_valid_term && $queried->post_status === 'publish';
    $is_authorized_preview = $is_valid_term && is_preview() && current_user_can('edit_post', $queried->ID);
    $uge_post = ($is_public || $is_authorized_preview) ? $queried : null;
}
if ($uge_post instanceof WP_Post) :
    $GLOBALS['post'] = $uge_post;
    setup_postdata($uge_post);
    $groups = wp_get_post_terms($uge_post->ID, UGE_Core::TAXONOMY);
    $nav_group = UGE_Core::navigation_group_for_post($uge_post->ID);
    $group_name = $nav_group instanceof WP_Term ? $nav_group->name : UGE_Config::get()['label'];
    $definition = UGE_Core::term_value(get_the_ID(), 'short_definition');
    $synonyms = UGE_Core::term_value(get_the_ID(), 'synonyms');
    $related = UGE_Core::term_value(get_the_ID(), 'related_terms');
    ?>
    <main id="primary">
        <div class="uge"><?php echo UGE_Frontend::render_navigation(false); ?></div>
        <article class="uge-single-wrap">
            <header class="uge-single-header">
                <span class="uge-kicker"><?php echo esc_html($group_name); ?></span>
                <h1><?php the_title(); ?></h1>
                <?php if ($definition !== '') : ?><p class="uge-definition"><?php echo esc_html($definition); ?></p><?php endif; ?>
            </header>
            <div class="uge-ad-slot uge-ad-slot-top"><?php do_action('uge_ad_slot', 'top', $uge_post->ID); ?></div>
            <div class="uge-content"><?php
                echo apply_filters('the_content', (string)$uge_post->post_content);
                $primary_target = UGE_Core::primary_category_target($uge_post->ID);
                if ($primary_target) {
                    printf(
                        '<p class="uge-primary-category">Zum Themenbereich: <a href="%s">%s</a></p>',
                        esc_url((string)$primary_target['url']),
                        esc_html((string)$primary_target['label'])
                    );
                }
            ?></div>
            <div class="uge-ad-slot uge-ad-slot-inline"><?php do_action('uge_ad_slot', 'inline', $uge_post->ID); ?></div>
            <?php if ($synonyms !== '' || $related !== '') : ?>
                <div class="uge-meta">
                    <?php if ($synonyms !== '') : ?><p><strong>Synonyme:</strong> <?php echo esc_html($synonyms); ?></p><?php endif; ?>
                    <?php
                    $related_links = [];
                    if ($related !== '') {
                        foreach (preg_split('/[,;\n]+/', $related) ?: [] as $related_label) {
                            $related_label = trim((string)$related_label);
                            if ($related_label === '') { continue; }
                            $target = UGE_Frontend::resolve_related_term($related_label);
                            if ($target instanceof WP_Post && $target->post_status === 'publish') {
                                $related_links[] = '<a href="' . esc_url(get_permalink($target)) . '">' . esc_html(get_the_title($target)) . '</a>';
                            }
                        }
                    }
                    if ($related_links) {
                        echo '<p class="uge-related-links"><strong>Verwandte Begriffe:</strong> ' . implode(', ', $related_links) . '</p>';
                    }
                    $glossary_groups = wp_get_post_terms($uge_post->ID, UGE_Core::TAXONOMY);
                    if (!is_wp_error($glossary_groups) && $glossary_groups) {
                        $glossary_group = UGE_Core::navigation_group_for_post($uge_post->ID);
                        if (!$glossary_group instanceof WP_Term) { $glossary_group = $glossary_groups[0]; }
                        $group_url = get_term_link($glossary_group, UGE_Core::TAXONOMY);
                        if (!is_wp_error($group_url)) {
                            echo '<p class="uge-glossary-category-link"><strong>Glossar-Bereich:</strong> <a href="' . esc_url($group_url) . '">' . esc_html($glossary_group->name) . '</a></p>';
                        }
                    }
                    ?>
                </div>
            <?php endif; ?>
            <div class="uge-ad-slot uge-ad-slot-bottom"><?php do_action('uge_ad_slot', 'bottom', $uge_post->ID); ?></div>
        </article>
    </main>
    <?php
    wp_reset_postdata();
endif;
get_footer();
