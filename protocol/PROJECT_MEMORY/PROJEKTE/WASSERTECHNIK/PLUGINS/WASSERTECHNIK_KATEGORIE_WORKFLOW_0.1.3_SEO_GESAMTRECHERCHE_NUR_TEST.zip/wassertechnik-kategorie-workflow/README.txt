Wassertechnik Kategorie-Workflow WT001 v0.1.3 – W4 DataForSEO-Sammelrecherche

Ein Upgrade derselben WordPress-Pluginidentitaet von 0.1.2.

Einziger W4-SEO-Plan: 218 eindeutige Keyword/Owner-Kombinationen, 128 redaktionell verbesserte Suchbegriffe. Alles vorab kostenlos pruef- und exportierbar; WordPress-Bestandsreport bleibt rein lesend.

Neu: Eine NUR manuell (Administrator, Nonce, explizite Kostenfreigabe) startbare, einmalige DataForSEO-Gesamtrecherche mit exakt DREI Sammelabfragen fuer je die gleichen 218 Begriffe:
1) Google Ads Search Volume Live – Suchvolumen und Google-Ads-Anzeigenwettbewerb.
2) DataForSEO Labs Bulk Keyword Difficulty Live – Schwierigkeit organischer Google-Rankings.
3) DataForSEO Labs Search Intent Live – Suchabsicht pro Begriff.

Preise laut Anbieterpreisliste vom 14.11.2026: $0.09 + $0.03816 + $0.03816 = rund $0.16632. Ein Budgetwaechter verhindert Folgeaufrufe, sobald die Budgetpruefung von $0.25 verletzt wuerde. Da der Anbieter tatsaechliche Preise erst nach dem API-Aufruf meldet, ist keine absolute Abrechnungsobergrenze des Anbieters garantiert.

Sicherheit: Nur auf wasser.oliver-beil.de; keine automatische Abfrage, kein Cron, kein Import, kein WP-Post-/Kategorie-Schreibweg; vor dem ersten kostenpflichtigen Call atomare dauerhafte Einmalsperre. Keine automatischen Wiederholungen, auch nicht bei unklarer Anbieterantwort. Nach jedem Ergebnis Teilergebnis speichern. Gesamter Bericht als JSON im DataForSEO-Menue. Kein erneuter Preflight oder Zwischen-Plugin fuer die Recherche erforderlich.

Originale HAB-002 und Robotik bleiben unveraendert. Vorherige WP-Testversion 0.1.2 bleibt bis zu einem expliziten Update installiert.
