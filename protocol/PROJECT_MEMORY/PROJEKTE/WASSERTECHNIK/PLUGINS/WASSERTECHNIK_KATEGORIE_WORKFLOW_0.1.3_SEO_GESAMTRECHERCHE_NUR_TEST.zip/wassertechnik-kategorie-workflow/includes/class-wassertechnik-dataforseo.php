<?php
if (!defined('ABSPATH')) { exit; }
/** DataForSEO gateway for the existing Wassertechnik category plugin. No writes to site content. */
final class Wassertechnik_DataForSEO {
    private const PAGE = 'wassertechnik-dataforseo';
    private const OPT_LOGIN = 'wassertechnik_dataforseo_login_v1';
    private const OPT_PASSWORD = 'wassertechnik_dataforseo_password_v1';
    private const OPT_NOTICE = 'wassertechnik_dataforseo_notice_v1';
    private const OPT_PREFLIGHT = 'wassertechnik_dataforseo_preflight_v1';
    private const OPT_CONNECTION = 'wassertechnik_dataforseo_connection_v1';
    private const URL = 'https://api.dataforseo.com/v3/';
    public const FREE_ENDPOINT = 'appendix/user_data';

    public static function boot(): void {
        add_action('admin_menu',[self::class,'menu'],35);
        add_action('admin_post_wassertechnik_dfs_credentials',[self::class,'save_credentials']);
        add_action('admin_post_wassertechnik_dfs_connection',[self::class,'test_connection']);
        add_action('admin_post_wassertechnik_dfs_preflight',[self::class,'post_preflight']);
        add_action('admin_post_wassertechnik_dfs_preflight_export',[self::class,'export_preflight']);
    }
    public static function menu():void {
        add_submenu_page('wassertechnik-kategorie','Wassertechnik DataForSEO','DataForSEO','manage_options',self::PAGE,[self::class,'screen']);
    }
    private static function authorize(string $nonce):void {
        if (!current_user_can('manage_options')) wp_die('Administratorrechte erforderlich.');
        check_admin_referer($nonce);
    }
    public static function credentials():array {
        $login=defined('WASSERTECHNIK_DFS_LOGIN')?(string)WASSERTECHNIK_DFS_LOGIN:(string)get_option(self::OPT_LOGIN,'');
        $password=defined('WASSERTECHNIK_DFS_PASSWORD')?(string)WASSERTECHNIK_DFS_PASSWORD:(string)get_option(self::OPT_PASSWORD,'');
        return [trim($login),trim($password)];
    }
    public static function has_credentials():bool {
        [$a,$b]=self::credentials();return $a!==''&&$b!=='';
    }
    private static function go():void {wp_safe_redirect(admin_url('admin.php?page='.self::PAGE));exit;}
    private static function notify(bool $pass,string $message):void {
        update_option(self::OPT_NOTICE,['pass'=>$pass,'text'=>$message,'utc'=>gmdate('c')],false);
    }
    public static function save_credentials():void {
        self::authorize('wassertechnik_dfs_credentials');
        if(!defined('WASSERTECHNIK_DFS_LOGIN')) {
            $login=isset($_POST['dfs_login'])&&is_string($_POST['dfs_login'])?trim(sanitize_text_field(wp_unslash($_POST['dfs_login']))):'';
            if($login!=='')update_option(self::OPT_LOGIN,$login,false);
        }
        if(!defined('WASSERTECHNIK_DFS_PASSWORD')) {
            $password=isset($_POST['dfs_password'])&&is_string($_POST['dfs_password'])?trim(wp_unslash($_POST['dfs_password'])):'';
            if($password!=='')update_option(self::OPT_PASSWORD,$password,false);
        }
        self::free_check('Zugang gespeichert. '); self::go();
    }
    /** Single transport; no API activity except from explicit admin actions. */
    /** Free account connection test ONLY. No paid API endpoint exists in this preview. */
    private static function free_request(): array {
        [$login,$password]=self::credentials();
        if($login===''||$password==='')throw new RuntimeException('DataForSEO-Zugangsdaten fehlen.');
        $response=wp_remote_get(self::URL.self::FREE_ENDPOINT,[
            'timeout'=>30,'redirection'=>0,'sslverify'=>true,
            'headers'=>['Authorization'=>'Basic '.base64_encode($login.':'.$password),'Accept'=>'application/json']
        ]);
        if(is_wp_error($response))throw new RuntimeException('DataForSEO-Verbindung fehlgeschlagen.');
        $status=(int)wp_remote_retrieve_response_code($response);
        $data=json_decode((string)wp_remote_retrieve_body($response),true);
        if($status!==200||!is_array($data)|| (int)($data['status_code']??0)!==20000)
            throw new RuntimeException('DataForSEO-Verbindung nicht erfolgreich (HTTP '.$status.').');
        if(abs((float)($data['cost']??0))>0.00000001)
            throw new RuntimeException('Unerwartete Kosten im kostenlosen Test.');
        return $data;
    }
    private static function free_check(string $prefix=''):void {
        try{
            $r=self::free_request();
            if(abs((float)($r['cost']??0))>0.00000001)throw new RuntimeException('Unerwartete Kosten beim kostenlosen Verbindungstest.');
            $p=self::build_preflight();
            update_option(self::OPT_PREFLIGHT,$p,false);
            update_option(self::OPT_CONNECTION,['pass'=>true,'utc'=>gmdate('c')],false);
            self::notify(true,$prefix.'DataForSEO-Verbindung PASS (0 USD). '.(int)$p['unique_keywords'].' SEO-Begriffe kostenfrei vorbereitet; '.count($p['rejected']).' zu lange Begriffe.');
        }catch(Throwable $e){
            update_option(self::OPT_CONNECTION,['pass'=>false,'utc'=>gmdate('c')],false);
            self::notify(false,$prefix.$e->getMessage());
        }
    }
    public static function test_connection():void {
        self::authorize('wassertechnik_dfs_connection');
        self::free_check();self::go();
    }
    private static function normal(string $x):string {
        $x=trim(preg_replace('/\s+/u',' ',$x));return function_exists('mb_strtolower')?mb_strtolower($x,'UTF-8'):strtolower($x);
    }
    /** W4 SEO candidate pool: independent from the UNCHANGED legacy WP first-import plan. */
    private static function seo_manifest():array {
        $file=dirname(__DIR__).'/assets/wassertechnik-w4-seo-candidates.json';
        if(!is_readable($file))throw new RuntimeException('W4-SEO-Fachentwurf fehlt. Keine alte Keywordliste als Ersatz.');
        $data=json_decode((string)file_get_contents($file),true);
        if(!is_array($data)||($data['schema']??'')!=='wassertechnik-seo-candidates-w4-v2'
            ||($data['status']??'')!=='SEO_RECHERCHE_NUR_KEIN_WP_IMPORT_KEINE_SEO_FREIGABE'
            ||count((array)($data['records']??[]))!==218
            ||(int)($data['counts']['product_pages']??0)!==79
            ||(int)($data['counts']['facets']??0)!==105
            ||(int)($data['counts']['review_holds']??0)!==0)
            throw new RuntimeException('W4-SEO-Fachentwurf fehlerhaft oder unvollständig.');
        return $data;
    }
    public static function build_preflight():array {
        $manifest=self::seo_manifest();
        $keywords=[];$rejected=[];$count=['main'=>0,'group'=>0,'industry_hub'=>0,'industry_landing'=>0,'product_pages'=>0,'facets'=>0];
        $seen=[];$holdcount=0;
        foreach($manifest['records'] as $record){
            if(!is_array($record))throw new RuntimeException('Ungültiger W4-SEO-Datensatz.');
            $owner=(string)($record['id']??'');$kind=(string)($record['type']??'');
            $raw=(string)($record['keyword']??'');
            if($owner===''||isset($seen[$owner])||!in_array($kind,['main','group','industry_hub','industry_landing','product','category'],true))
                throw new RuntimeException('Mehrfache oder ungültige W4-SEO-ID.');
            $seen[$owner]=true;
            if($kind==='product')$count['product_pages']++;
            elseif($kind==='category')$count['facets']++;
            else $count[$kind]++;
            if(!empty($record['review_hold']))$holdcount++;
            $k=self::normal($raw);
            if($k===''||strlen($k)>80||count(preg_split('/\s+/u',$k))>10){
                $rejected[]=['owner'=>$owner,'keyword'=>$raw,'reason'=>'DataForSEO-Limit: 80 Zeichen oder 10 Wörter'];
                continue;
            }
            if(!isset($keywords[$k]))$keywords[$k]=['keyword'=>$k,'owners'=>[]];
            $keywords[$k]['owners'][]=['id'=>$owner,'type'=>$kind,
                'label'=>(string)($record['original_keyword']??$record['label']??$raw),
                'facet_label'=>(string)($record['label']??''),
                'world'=>(string)($record['world']??''),
                'review_hold'=>!empty($record['review_hold']),
                'editorial_status'=>(string)($record['editorial_status']??'NICHT_GEPRUEFT'),
                'paid_research_approved'=>false,
                'original_keyword'=>(string)($record['original_keyword']??$raw),
                'source'=>(string)($record['source']??'')];
        }
        if($count['main']!==8||$count['group']!==19||$count['industry_hub']!==1||$count['industry_landing']!==6||$count['product_pages']!==79||$count['facets']!==105||$holdcount!==0)
            throw new RuntimeException('W4-Mengenprüfung gescheitert. Kein Rückfall zum alten Profil.');
        $keywords=array_values($keywords);
        $fp=hash('sha256',wp_json_encode([$keywords,$rejected,$count,$manifest['source_sha256']],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        return ['schema'=>'wassertechnik-dfs-preflight-v1','version'=>'0.1.3','source'=>'W4_REDAKTIONELLER_KEYWORDPLAN_NICHT_GEMESSEN',
            'source_sha256'=>$manifest['source_sha256'],'review_holds'=>$holdcount,
            'editorial_rewrites'=>128,'paid_research_approved'=>false,
            'semantic_research_status'=>'NICHT_GEMESSEN',
            'location_name'=>'Germany','language_code'=>'de','count'=>$count,
            'unique_keywords'=>count($keywords),'keywords'=>$keywords,'rejected'=>$rejected,
            'fingerprint'=>$fp,'generated_at_utc'=>gmdate('c')];
    }
    public static function post_preflight():void {
        self::authorize('wassertechnik_dfs_preflight');
        try{
            $p=self::build_preflight();
            update_option(self::OPT_PREFLIGHT,$p,false);
            self::notify(true,$p['unique_keywords'].' Owner vollständig; 128 Suchvorschläge redaktionell überarbeitet, nicht bei Google gemessen. 0 API-Aufrufe, 0 Kosten. '.count($p['rejected']).' zu lange Begriffe.');
        }catch(Throwable $e){self::notify(false,$e->getMessage());}
        self::go();
    }
    public static function export_preflight():void {
        self::authorize('wassertechnik_dfs_preflight_export');
        try{$preflight=self::build_preflight();}
        catch(Throwable $e){wp_die('Keyword-Export blockiert: '.$e->getMessage());}
        nocache_headers();
        header('Content-Type: application/json; charset=UTF-8');
        header('Content-Disposition: attachment; filename="wassertechnik-w4-seo-vorabcheck-kostenlos.json"');
        echo wp_json_encode($preflight,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        exit;
    }
    public static function screen():void {
        if(!current_user_can('manage_options'))wp_die('Administratorrechte erforderlich.');
        $notice=get_option(self::OPT_NOTICE,[]);$pre=get_option(self::OPT_PREFLIGHT,[]);
        echo '<div class="wrap"><h1>Wassertechnik – DataForSEO</h1>';
        echo '<p>Einmalige Verbindung und gesammelte Keywordprüfung für den vorhandenen Wassertechnik-Baum. <strong>Keine automatischen Kosten, keine Seitenänderungen.</strong></p>';
        if(is_array($notice)&&!empty($notice['text']))echo '<div class="notice '.(!empty($notice['pass'])?'notice-success':'notice-error').'"><p>'.esc_html($notice['text']).'</p></div>';
        echo '<h2>1. Zugang und kostenloser Verbindungstest</h2>';
        echo '<p>Status: <strong>'.(self::has_credentials()?'Zugang vorhanden':'Zugang fehlt').'</strong> · Markt: Deutschland · Sprache: Deutsch.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('wassertechnik_dfs_credentials');
        echo '<input type="hidden" name="action" value="wassertechnik_dfs_credentials">';
        echo '<p><label>API-Login <input type="text" name="dfs_login" autocomplete="username" style="min-width:240px"'.(defined('WASSERTECHNIK_DFS_LOGIN')?' disabled':'').'></label> ';
        echo '<label>API-Passwort <input type="password" name="dfs_password" autocomplete="new-password" style="min-width:240px"'.(defined('WASSERTECHNIK_DFS_PASSWORD')?' disabled':'').'></label> ';
        submit_button('Zugang speichern + kostenlos prüfen','secondary','submit',false);echo '</p></form>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('wassertechnik_dfs_connection');
        echo '<input type="hidden" name="action" value="wassertechnik_dfs_connection">';submit_button('Verbindung kostenlos prüfen','secondary','submit',false);echo '</form>';
        echo '<h2>2. Kostenloser SEO-Sammelprüfplan</h2><p>Der Wassertechnik-W4-Fachentwurf umfasst 8 Hauptgruppen, 19 fachliche Untergruppen, 1 Industrie-Einstieg, 6 Industrie-Landingpages, 79 Produktseiten und 105 Inhaltskategorien (218 Eigentümer). <strong>128 zusammengesetzte Suchphrasen wurden anhand der vorhandenen Artikelideen redaktionell ersetzt. Alle 218 Suchvorschläge sind ungeprüft: keine Suchvolumina, keine SEO-Freigabe. Kein Import, keine Bezahl-API.</strong></p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('wassertechnik_dfs_preflight');
        echo '<input type="hidden" name="action" value="wassertechnik_dfs_preflight">';submit_button('Gesamte Keywordliste prüfen (kostenlos)','secondary','submit',false);echo '</form>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field('wassertechnik_dfs_preflight_export');
        echo '<input type="hidden" name="action" value="wassertechnik_dfs_preflight_export">';
        submit_button('SEO-Keywordliste als JSON herunterladen (kostenlos)','secondary','submit',false);
        echo '</form>';
        if(is_array($pre)&&!empty($pre['fingerprint']))echo '<p><strong>Letzte Vorbereitung:</strong> '.(int)$pre['unique_keywords'].' eindeutige Keywords · '.count((array)($pre['rejected']??[])).' ausgelassen · 0 USD.</p>';
        Wassertechnik_PaidResearch::panel();
        echo '</div>';
    }
}
