<?php
if (!defined('ABSPATH')) { exit; }
/** One explicitly confirmed, budgeted, read-only research run. Never imports WP content. */
final class Wassertechnik_PaidResearch {
    private const HOST = 'wasser.oliver-beil.de';
    private const LOCK = 'wassertechnik_dfs_013_once_lock';
    private const REPORT = 'wassertechnik_dfs_013_result';
    private const NOTICE = 'wassertechnik_dataforseo_notice_v1';
    private const MAX_USD = 0.25;
    private const ESTIMATED_USD = 0.16632; // 0.09 + 2*(0.012 + 218*0.00012), 14.11.2026 list price
    private const PRICES = ['volume'=>0.09,'difficulty'=>0.03816,'intent'=>0.03816];
    private const ENDPOINTS = [
        'volume'=>'keywords_data/google_ads/search_volume/live',
        'difficulty'=>'dataforseo_labs/google/bulk_keyword_difficulty/live',
        'intent'=>'dataforseo_labs/google/search_intent/live',
    ];

    public static function boot():void {
        add_action('admin_post_wassertechnik_dfs_013_paid',[self::class,'paid']);
        add_action('admin_post_wassertechnik_dfs_013_export',[self::class,'export']);
    }
    private static function verify_site():void {
        $host=(string)wp_parse_url(home_url('/'),PHP_URL_HOST);
        if(strtolower($host)!==self::HOST)throw new RuntimeException('SEO-Recherche ist nur für die bestätigte Wassertechnik-Testwebsite zugelassen.');
    }
    private static function auth(string $nonce):void {
        if(!current_user_can('manage_options'))wp_die('Administratorrechte erforderlich.');
        check_admin_referer($nonce);
        self::verify_site();
    }
    private static function notify(bool $pass,string $message):void {
        update_option(self::NOTICE,['pass'=>$pass,'text'=>$message,'utc'=>gmdate('c')],false);
    }
    private static function back():void {
        wp_safe_redirect(admin_url('admin.php?page=wassertechnik-dataforseo'));exit;
    }
    private static function normal(string $s):string {
        $s=trim(preg_replace('/\s+/u',' ',$s));
        return function_exists('mb_strtolower')?mb_strtolower($s,'UTF-8'):strtolower($s);
    }
    /** Does not use saved results or a second keyword owner registry. */
    public static function planned():array {
        self::verify_site();
        $pre=Wassertechnik_DataForSEO::build_preflight();
        if(($pre['version']??'')!=='0.1.3'||(int)($pre['unique_keywords']??0)!==218
            ||!empty($pre['rejected'])||!empty($pre['review_holds'])
            ||!empty($pre['paid_research_approved'])||count((array)($pre['keywords']??[]))!==218)
            throw new RuntimeException('W4-SEO-Profil nicht eindeutig vollständig. Kein kostenpflichtiger Aufruf.');
        $terms=[];$owners=[];
        foreach($pre['keywords'] as $item){
            $kw=self::normal((string)$item['keyword']);
            if($kw===''||strlen($kw)>80||count(preg_split('/\s+/u',$kw))>10
               ||isset($owners[$kw])||count((array)$item['owners'])!==1)
                throw new RuntimeException('W4-Wort/Owner-Verteilung ungültig.');
            $terms[]=$kw;
            $owners[$kw]=$item['owners'][0];
        }
        if(count(array_unique($terms))!==218)throw new RuntimeException('Doppelte Suchbegriffe.');
        return [$pre,$terms,$owners];
    }
    public static function panel():void {
        if(!current_user_can('manage_options'))return;
        echo '<h2>3. Einmalige SEO-Gesamtrecherche (kostenpflichtig)</h2>';
        echo '<p>218 bestehende W4-Suchbegriffe in <strong>drei Sammelabfragen</strong>: Suchvolumen, organische Ranking-Schwierigkeit und Suchabsicht. Keine Keyword-Suche in einer Schleife, kein WordPress-Import.</p>';
        echo '<p>Preis laut veröffentlichten DataForSEO-Tarifen am 14.11.2026: ungefähr <strong>0,17 USD</strong> insgesamt. Budgetprüfung im Plugin: <strong>0,25 USD</strong>. Der Anbieter kann Preise ändern; sein tatsächlicher Preis wird erst nach einer berechneten Anfrage gemeldet. Bei Überschreitung der Budgetprüfung werden weitere Abfragen gestoppt.</p>';
        echo '<p><a href="https://dataforseo.com/pricing/keywords-data/google-ads" target="_blank" rel="noopener">Google-Ads-Preise</a> · <a href="https://dataforseo.com/pricing/dataforseo-labs/dataforseo-google-api" target="_blank" rel="noopener">Labs-Preise</a></p>';
        $lock=get_option(self::LOCK,false);
        $report=get_option(self::REPORT,[]);
        if($lock!==false){
            echo '<p><strong>Dieser Auftrag wurde bereits ausgelöst oder gesperrt. Kein zweiter kostenpflichtiger Aufruf möglich.</strong></p>';
        } else {
            try {
                [$pre,$terms]=self::planned();
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
                wp_nonce_field('wassertechnik_dfs_013_paid');
                echo '<input type="hidden" name="action" value="wassertechnik_dfs_013_paid">';
                echo '<input type="hidden" name="plan_fingerprint" value="'.esc_attr($pre['fingerprint']).'">';
                echo '<p><label><input type="checkbox" name="explicit_paid_approval" value="1" required> Ich genehmige <strong>einmalig drei kostenpflichtige DataForSEO-Abfragen für genau diese 218 Begriffe</strong> zum veröffentlichten Richtpreis ca. 0,17 USD mit Stop-Grenze 0,25 USD. Mir ist bewusst, dass der API-Anbieter die tatsächlichen Preise festlegt.</label></p>';
                submit_button('218 Keywords einmal kostenpflichtig recherchieren','primary','submit',false);
                echo '</form>';
            } catch(Throwable $e){
                echo '<p><strong>Start blockiert:</strong> '.esc_html($e->getMessage()).'</p>';
            }
        }
        if(is_array($report)&&!empty($report['request_id'])){
            echo '<h2>4. SEO-Ergebnis herunterladen</h2>';
            echo '<p>Status: '.esc_html((string)$report['state']).' · abgeschlossene API-Abfragen: '.(int)count((array)$report['completed']).' / 3 · Anbieter-Kosten bisher: '.esc_html(number_format((float)$report['cost_usd'],5,'.','')).' USD · 218 angelegte Keyword-Zeilen. Fehlende Ergebnisse bleiben ausdrücklich leer.</p>';
            if(!empty($report['error']))echo '<p><strong>Hinweis:</strong> '.esc_html((string)$report['error']).'</p>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
            wp_nonce_field('wassertechnik_dfs_013_export');
            echo '<input type="hidden" name="action" value="wassertechnik_dfs_013_export">';
            submit_button('Gesamten SEO-Bericht als JSON herunterladen','secondary','submit',false);echo '</form>';
        }
    }
    /** Single HTTP POST, never retries, never sleeps, never schedules. */
    private static function fetch(string $endpoint,array $task):array {
        [$login,$password]=Wassertechnik_DataForSEO::credentials();
        if($login===''||$password==='')throw new RuntimeException('DataForSEO-Zugang fehlt.');
        $response=wp_remote_post('https://api.dataforseo.com/v3/'.$endpoint,[
            'timeout'=>80,'redirection'=>0,'sslverify'=>true,
            'headers'=>['Authorization'=>'Basic '.base64_encode($login.':'.$password),'Content-Type'=>'application/json','Accept'=>'application/json'],
            'body'=>wp_json_encode([$task],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
        ]);
        if(is_wp_error($response))throw new RuntimeException('Anbieter antwortet nicht. Nicht erneut kostenpflichtig absenden.');
        $status=(int)wp_remote_retrieve_response_code($response);
        $json=json_decode((string)wp_remote_retrieve_body($response),true);
        if(!is_array($json))throw new RuntimeException('Anbieterantwort unlesbar. Nicht wiederholen.');
        // Return provider response *including failures* so cost and task id are retained.
        $json['_http_status']=$status;
        return $json;
    }
    private static function cost(array $data):float {
        $top=(float)($data['cost']??0);
        $tasks=(array)($data['tasks']??[]);
        $sum=0.0;foreach($tasks as $t)if(is_array($t))$sum+=(float)($t['cost']??0);
        return max($top,$sum);
    }
    private static function items(array $data,string $endpoint):array {
        if((int)($data['_http_status']??0)!==200 || (int)($data['status_code']??0)!==20000 || (int)($data['tasks'][0]['status_code']??0)!==20000)
            throw new RuntimeException('DataForSEO meldet für '.$endpoint.' einen Fehler.');
        $tasks=$data['tasks'];if(count($tasks)!==1)throw new RuntimeException('Unerwartet mehrere Anbieter-Tasks.');
        $result=(array)($tasks[0]['result']??[]);
        $items=[];
        foreach($result as $r){
            if(!is_array($r))continue;
            if(isset($r['keyword'])){$items[]=$r;continue;}
            if(isset($r['items'])&&is_array($r['items']))foreach($r['items'] as $item)if(is_array($item))$items[]=$item;
        }
        return $items;
    }
    private static function apply(string $kind,array $items,array &$rows):int {
        $updated=0;
        foreach($items as $item){
            $kw=self::normal((string)($item['keyword']??''));
            if(!isset($rows[$kw]))continue; // returned keyword variants never generate new owners
            if($kind==='volume'){
                $rows[$kw]['search_volume']=isset($item['search_volume'])?(int)$item['search_volume']:null;
                $rows[$kw]['google_ads_competition']=$item['competition']??null;
                $rows[$kw]['google_ads_competition_index']=$item['competition_index']??null;
                $rows[$kw]['cpc_usd']=$item['cpc']??null;
                $rows[$kw]['monthly_searches']=$item['monthly_searches']??null;
            } elseif($kind==='difficulty') {
                $rows[$kw]['organic_keyword_difficulty']=isset($item['keyword_difficulty'])?(int)$item['keyword_difficulty']:null;
            } elseif($kind==='intent') {
                $i=$item['keyword_intent']??null;
                $rows[$kw]['search_intent']=is_array($i)?($i['label']??null):null;
                $rows[$kw]['search_intent_probability']=is_array($i)?($i['probability']??null):null;
                $rows[$kw]['secondary_intents']=$item['secondary_keyword_intents']??null;
            }
            $updated++;
        }
        return $updated;
    }
    public static function paid():void {
        self::auth('wassertechnik_dfs_013_paid');
        if((string)($_POST['explicit_paid_approval']??'')!=='1')wp_die('Kostenfreigabe fehlt.');
        try {
            [$pre,$terms,$owners]=self::planned();
            $posted=isset($_POST['plan_fingerprint'])&&is_string($_POST['plan_fingerprint'])?wp_unslash($_POST['plan_fingerprint']):'';
            if(!hash_equals((string)$pre['fingerprint'],$posted))throw new RuntimeException('Keywordplan hat sich geändert. Keine Kosten.');
            if(self::ESTIMATED_USD>self::MAX_USD)throw new RuntimeException('Preisobergrenze überschritten.');
            if(!Wassertechnik_DataForSEO::has_credentials())throw new RuntimeException('Zugang fehlt. Keine Kosten.');
            // Recheck existing lock before trying atomic insertion. Never expire/release after uncertain network response.
            if(get_option(self::LOCK,false)!==false)throw new RuntimeException('Bereits gestartet; kein Doppelaufruf.');
            $request_id=hash('sha256','wt013:'.$pre['fingerprint'].':Germany:de');
            if(!add_option(self::LOCK,['utc'=>gmdate('c'),'request_id'=>$request_id,'fingerprint'=>$pre['fingerprint']],'',false))
                throw new RuntimeException('Recherche bereits gestartet. Keine Doppelabrechnung.');
            $rows=[];
            foreach($terms as $kw)$rows[$kw]=[
                'keyword'=>$kw,'owner'=>$owners[$kw],'search_volume'=>null,
                'google_ads_competition'=>null,'google_ads_competition_index'=>null,
                'cpc_usd'=>null,'monthly_searches'=>null,'organic_keyword_difficulty'=>null,
                'search_intent'=>null,'search_intent_probability'=>null,'secondary_intents'=>null
            ];
            $report=[
                'schema'=>'wassertechnik-dfs-research-v1','plugin_version'=>'0.1.3',
                'request_id'=>$request_id,'source_fingerprint'=>$pre['fingerprint'],
                'source_sha256'=>$pre['source_sha256'],'state'=>'RUNNING','cost_usd'=>0.0,
                'estimated_cost_usd'=>self::ESTIMATED_USD,'budget_usd'=>self::MAX_USD,
                'location'=>'Germany','language'=>'de','keywords_requested'=>count($terms),
                'completed'=>[],'attempted'=>[],'error'=>null,'rows'=>array_values($rows),
                'notes'=>'Google Ads competition ist Anzeigenwettbewerb, nicht organische SEO-Konkurrenz. Keyword Difficulty ist separate organische Kennzahl. Fehlend (null) ist nicht 0. Keine automatische WordPress-Änderung.',
                'started_utc'=>gmdate('c')
            ];
            update_option(self::REPORT,$report,false);
            foreach(self::ENDPOINTS as $kind=>$endpoint){
                $estimate=(float)self::PRICES[$kind];
                if((float)$report['cost_usd']+$estimate>self::MAX_USD+0.0000001)
                    throw new RuntimeException('Restbudget unterschritten. Keine weiteren API-Aufrufe.');
                $task=['keywords'=>$terms];
                if($kind!=='intent'){$task['location_name']='Germany';$task['language_code']='de';}
                else $task['language_code']='de';
                if($kind==='volume')$task['search_partners']=false;
                $report['attempted'][]=['kind'=>$kind,'endpoint'=>$endpoint,'utc'=>gmdate('c'),'result'=>'BEGONNEN'];
                update_option(self::REPORT,$report,false); // record before paid operation
                $response=self::fetch($endpoint,$task);
                $reported_cost=self::cost($response);
                $report['cost_usd']+=(float)$reported_cost;
                $report['attempted'][count($report['attempted'])-1]['cost_usd']=$reported_cost;
                $report['attempted'][count($report['attempted'])-1]['provider_task_id']=$response['tasks'][0]['id']??null;
                $report['attempted'][count($report['attempted'])-1]['result']='ANTWORT_ERHALTEN';
                update_option(self::REPORT,$report,false);
                $items=self::items($response,$endpoint);
                $updated=self::apply($kind,$items,$rows);
                $report['completed'][]=['kind'=>$kind,'received_rows'=>count($items),'matched_rows'=>$updated,'cost_usd'=>$reported_cost];
                $report['rows']=array_values($rows);
                update_option(self::REPORT,$report,false); // durable after every endpoint
                if((float)$report['cost_usd']>self::MAX_USD+0.0000001)
                    throw new RuntimeException('Anbieter hat den Sicherheitsbetrag überschritten; Folgeschritte gestoppt.');
            }
            $report['state']='COMPLETED';$report['finished_utc']=gmdate('c');
            update_option(self::REPORT,$report,false);
            self::notify(true,'Gesamtrecherche 218 Begriffe abgeschlossen: 3 Sammelabfragen. Anbieter-Kosten '.number_format($report['cost_usd'],5,'.','').' USD. JSON-Bericht herunterladen.');
        }catch(Throwable $e){
            if(isset($report)&&is_array($report)){
                $report['state']='PARTIAL_STOPPED_NO_AUTO_RETRY';$report['error']=$e->getMessage();
                $report['finished_utc']=gmdate('c');update_option(self::REPORT,$report,false);
            }
            self::notify(false,'Recherche gestoppt: '.$e->getMessage().' Keine automatischen Wiederholungen. Vorhandene Teilergebnisse bleiben im JSON-Bericht.');
        }
        self::back();
    }
    public static function export():void {
        self::auth('wassertechnik_dfs_013_export');
        $report=get_option(self::REPORT,[]);
        if(!is_array($report)||empty($report['request_id']))wp_die('Noch keine Recherche vorhanden.');
        nocache_headers();
        header('Content-Type: application/json; charset=UTF-8');
        header('Content-Disposition: attachment; filename="wassertechnik-dataforseo-218-seo-ergebnis.json"');
        echo wp_json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        exit;
    }
}
