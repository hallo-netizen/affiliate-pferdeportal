Wassertechnik Kategorie-Workflow 0.1.0 – NUR SEO-VORSCHAU

Quelle: tatsaechliches Robotik-Kategorie-Workflow-Plugin 0.4.3 (14.11.2026), dessen DataForSEO- und Inventurmodule gezielt isoliert portiert wurden. Das HAB-002-Kategorieplugin liegt im Wassertechnik-Campus als separate unveraenderte Vergleichskopie, wurde fuer diesen Build jedoch NICHT als PHP-Quelle benutzt.

Bundled SEO manifest: 79 Produktseiten, 105 Inhaltskategorien (184 Begriffe), abgeglichen mit GitHub W4-Gesamtbaum Blob 74bfdbfbafe89c960e5ad843fca84349d74d6ee9. Die volle Liste mit 356 Themenrichtungen bleibt an der Originalstelle im Campus. Diese Kopie enthaelt keinen fertigen WP-Importplan und keine eigene doppelte Stammliste.

NUR: im WordPress-Backend kostenlose 184er SEO-Pruefliste erzeugen / JSON exportieren, auf Wunsch DataForSEO-Zugang kostenlos pruefen, Bestandsaufnahme lesen / JSON exportieren. KEIN WordPress-Import, KEINE Veroeffentlichung, KEINE automatischen Aufgaben, KEIN Frontend-Hook.

Bezahlte SEO-Aufrufe: in dieser Version technisch gesperrt (nicht nur ein deaktivierter Button). Die vorhandene Quellfunktion kann nicht ueber die Admin-Oberflaeche aufgerufen werden; ein direkter Aufruf wird abgewehrt.

Sicherheitsregel: separate WordPress Plugin-Identitaet, eigene Klassen, eigene Optionen, eigene Admin-Routen; keinerlei Zugriff auf Robotik-/Hab-&-Bewahr-Vorgaenge.

Vor dem ersten WP-Liveinsatz: eine neue, eigene Wassertechnik-WordPress-Seite nachweisen. Zur spaeteren SEO-Messung braucht es eine ausdruecklich freigegebene neue Version mit genau einem festgelegten vollstaendigen Fachplan.
