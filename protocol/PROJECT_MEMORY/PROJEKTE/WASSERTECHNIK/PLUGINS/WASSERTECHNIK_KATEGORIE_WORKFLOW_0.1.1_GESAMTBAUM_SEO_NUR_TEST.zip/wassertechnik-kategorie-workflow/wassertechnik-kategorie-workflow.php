<?php
/**
 * Plugin Name: Wassertechnik Kategorie-Workflow – SEO-Vorschau
 * Description: Isolierte Wassertechnik-Kopie des bewaehrten Kategorie-Workflows: Bestandspruefung und W4-DataForSEO-Vorbereitung. Kein Import oder Veroeffentlichen.
 * Version: 0.1.1
 * Requires at least: 6.4
 * Requires PHP: 8.1
 * Text Domain: wassertechnik-kategorie-workflow
 */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/includes/class-wassertechnik-inventory.php';
require_once __DIR__ . '/includes/class-wassertechnik-dataforseo.php';

final class Wassertechnik_Kategorie_Workflow {
    public const VERSION = '0.1.1';
    public static function boot():void {
        add_action('admin_menu',[self::class,'menu']);
        add_action('admin_post_wassertechnik_inventory_export',[self::class,'export_inventory']);
        Wassertechnik_DataForSEO::boot();
    }
    public static function menu():void {
        add_menu_page('Wassertechnik Kategorie','Wassertechnik Kategorie','manage_options','wassertechnik-kategorie',[self::class,'screen'],'dashicons-networking',58);
    }
    public static function export_inventory():void {
        if(!current_user_can('manage_options'))wp_die('Administratorrechte erforderlich.');
        check_admin_referer('wassertechnik_inventory_export');
        $data=Wassertechnik_Kategorie_Inventory::collect();
        nocache_headers();header('Content-Type: application/json; charset=UTF-8');
        header('Content-Disposition: attachment; filename="wassertechnik-bestand.json"');
        echo wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);exit;
    }
    public static function screen():void {
        if(!current_user_can('manage_options'))wp_die('Administratorrechte erforderlich.');
        echo '<div class="wrap"><h1>Wassertechnik – Kategorie</h1>';
        echo '<p><strong>Aktueller Fachplan W4:</strong> 8 Hauptbereiche, 19 Zwischenbereiche, 1 Industrieeinstieg, 6 Industrie-Landingvorschlaege, 79 Produktseiten, 105 Inhaltskategorien und 356 grobe Artikelideen. Kostenloser SEO-Pruefplan: 218 Begriffe.</p>';
        echo '<p>Die Quelle liegt im Wassertechnik-Kategoriebüro auf GitHub. Dieses Plugin liest nur den WordPress-Bestand und erstellt den kostenlosen Keywordplan für DataForSEO. Es importiert, veröffentlicht und verändert keine Seiten oder Kategorien.</p>';
        echo '<p><strong>Import technisch deaktiviert. Kostenpflichtige DataForSEO-Abfragen technisch deaktiviert.</strong> Eine spätere Freigabe braucht eine neue, separat geprüfte Version.</p>';
        echo '<h2>WordPress-Bestandsaufnahme (nur lesen)</h2>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field('wassertechnik_inventory_export');
        echo '<input type="hidden" name="action" value="wassertechnik_inventory_export">';
        submit_button('Einmaligen Gesamtbericht als JSON herunterladen','secondary','submit',false);
        echo '</form><p>Die Keywordliste findest du unter „Wassertechnik Kategorie → DataForSEO“.</p></div>';
    }
}
Wassertechnik_Kategorie_Workflow::boot();
