# Detailkonzept: Zuständigkeiten und Longtail-Potenziale

Alle untersten Contentkategorien besitzen vier eigenständige, unverbindliche Beitragspotenziale. Sie sind keine verbindlichen Redaktionsaufträge und reservieren keine Artikel-Keywords.

## Wasseraufbereitung
- Konzept-ID: `c_55bc4ff3d7e08f73`
- Suchintention: `informational-commercial`
- Scope: Zentraler Content- und Affiliate-Hub für Wasseraufbereitung; bündelt dauerhaft tragfähige Produkt-, Planungs- und Technikcluster.
- Ausschlüsse: Regionale Anbieterlisten; Magazinmeldungen; Produkte anderer Hauptäste mit nur ähnlichem Wortlaut

## Wasseraufbereitung/Hauswasserfilter
- Konzept-ID: `c_ff1859c90e82dcc1`
- Suchintention: `informational-commercial`
- Scope: Übergeordnete Kategorie für fachlich getrennte Untergruppen von Hauswasserfilter.
- Ausschlüsse: Einzelne Artikeltypen wie FAQ oder Vergleich; Anbieter- und Standortseiten; Nicht zugeordnete Nachbartechnologien

## Wasseraufbereitung/Hauswasserfilter/Feinfilter
- Konzept-ID: `c_80a02bf0ab59d7a7`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Feinfilter: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Feinfilter in der Hausinstallation: passende Filterfeinheit für Sand und Rost wählen
  1. Feinfilter vor einer Enthärtungsanlage: Einbaureihenfolge und Druckverlust richtig planen
  1. Feinfiltereinsatz wechseln: hygienisches Vorgehen und sinnvolle Wartungsintervalle
  1. 80, 100 oder 200 Mikrometer: welche Feinheit ein Hauswasserfilter wirklich braucht

## Wasseraufbereitung/Hauswasserfilter/Rückspülfilter
- Konzept-ID: `c_27b212b011c4053d`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Rückspülfilter: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Rückspülfilter auswählen: manuelle Rückspülung oder automatische Auslösung
  1. Rückspülfilter richtig bedienen: Dauer, Wasserbedarf und Entsorgung des Spülwassers
  1. Druckabfall hinter dem Rückspülfilter: Ursachen systematisch prüfen
  1. Rückspülfilter im Altbau nachrüsten: Platzbedarf, Ablauf und Anschlussgröße

## Wasseraufbereitung/Hauswasserfilter/Automatikfilter
- Konzept-ID: `c_e5ec31d986da1033`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Automatikfilter: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Automatikfilter mit Zeit- oder Differenzdrucksteuerung: welches Prinzip passt zur Anlage
  1. Automatikfilter im Mehrfamilienhaus dimensionieren: Durchfluss und Spitzenlasten
  1. Strom- und Spülwasserbedarf von Automatikfiltern realistisch vergleichen
  1. Automatikfilter warten: Sensoren, Ventile und Rückspülmechanik prüfen

## Wasseraufbereitung/Trinkwasserfilter
- Konzept-ID: `c_a6b262cbfff34594`
- Suchintention: `informational-commercial`
- Scope: Übergeordnete Kategorie für fachlich getrennte Untergruppen von Trinkwasserfilter.
- Ausschlüsse: Einzelne Artikeltypen wie FAQ oder Vergleich; Anbieter- und Standortseiten; Nicht zugeordnete Nachbartechnologien

## Wasseraufbereitung/Trinkwasserfilter/Tischfilter
- Konzept-ID: `c_0bfc52e8ffde3bcb`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Tischfilter: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Tischwasserfilter mit Aktivkohle: Geschmack, Chlor und Grenzen der Filterwirkung
  1. Kartuschenkosten bei Tischfiltern: Jahreskosten statt Gerätepreis vergleichen
  1. Entfernt ein Tischfilter Kalk: Härte, Karbonathärte und Werbeversprechen einordnen
  1. Keime im Tischwasserfilter vermeiden: Lagerung, Kühlung und Kartuschenwechsel

## Wasseraufbereitung/Trinkwasserfilter/Armaturfilter
- Konzept-ID: `c_d54cfe7d3bad8b76`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Armaturfilter: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Wasserfilter am Wasserhahn nachrüsten: Gewinde, Adapter und Platzbedarf prüfen
  1. Durchfluss oder Filterleistung: Zielkonflikte bei Armaturfiltern verstehen
  1. Armaturfilter für Mietwohnungen: rückbaubare Lösungen ohne Eingriff in die Leitung
  1. Kartusche am Armaturfilter wechseln: Druckentlastung und Dichtigkeitskontrolle

## Wasseraufbereitung/Trinkwasserfilter/Untertischfilter
- Konzept-ID: `c_e534e327b8572e0f`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Untertischfilter: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Untertischfilter mit separatem Hahn oder Drei-Wege-Armatur: Vor- und Nachteile
  1. Aktivkohle, Hohlfaser oder Membran: Filterstufen unter der Spüle vergleichen
  1. Untertischfilter bei wenig Schrankraum planen: Gehäuse, Schläuche und Wechselweg
  1. Leckageschutz für Untertischfilter: Absperrung, Sensor und Montagefehler

## Wasseraufbereitung/Trinkwasserfilter/Outdoorfilter
- Konzept-ID: `c_d602be7982dc1e7e`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Outdoorfilter: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Hohlfaser oder Keramik: Outdoor-Wasserfilter nach Wasserquelle auswählen
  1. Warum viele Outdoorfilter keine Viren entfernen: Porengröße und Einsatzgrenzen
  1. Outdoorfilter rückspülen und desinfizieren: Leistung unterwegs erhalten
  1. Durchflussmenge bei Schwerkraft-, Pump- und Flaschenfiltern vergleichen

## Wasseraufbereitung/Osmoseanlagen
- Konzept-ID: `c_f672da28aed423b1`
- Suchintention: `informational-commercial`
- Scope: Übergeordnete Kategorie für fachlich getrennte Untergruppen von Osmoseanlagen.
- Ausschlüsse: Einzelne Artikeltypen wie FAQ oder Vergleich; Anbieter- und Standortseiten; Nicht zugeordnete Nachbartechnologien

## Wasseraufbereitung/Osmoseanlagen/Auftisch-Osmose
- Konzept-ID: `c_7e8397c6fa57df77`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Auftisch-Osmose: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Auftisch-Osmoseanlage ohne Festanschluss: Wasserweg, Abwasser und Bedienung
  1. Auftisch-Osmose mit Heißwasserfunktion: Energiebedarf und Hygienepunkte
  1. Tankgröße und Tagesleistung bei Auftischanlagen richtig einschätzen
  1. Filterwechsel bei Auftisch-Osmose: Kosten und Verfügbarkeit vor dem Kauf prüfen

## Wasseraufbereitung/Osmoseanlagen/Untertisch-Osmose
- Konzept-ID: `c_2c066f9cb6bfcfaa`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Untertisch-Osmose: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Untertisch-Osmoseanlage einbauen: Abwasseranschluss, Druck und separate Armatur
  1. Untertisch-Osmose für Mietwohnungen: reversible Einbauvarianten
  1. Verkeimung im Osmosesystem vermeiden: Spülung, Stillstand und Filterwechsel
  1. Permeatleistung bei kaltem Leitungswasser realistisch berechnen

## Wasseraufbereitung/Osmoseanlagen/Direct-Flow-Osmose
- Konzept-ID: `c_622ff31488bf44c5`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Direct-Flow-Osmose: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Direct-Flow-Osmose dimensionieren: Membranleistung für mehrere Zapfstellen
  1. Direct-Flow oder Tankanlage: Druck, Wartezeit und Abwasserverhältnis vergleichen
  1. Boosterpumpe bei Direct-Flow-Anlagen: Geräusch, Strombedarf und Wartung
  1. Automatische Spülprogramme prüfen: was sie leisten und was nicht

## Wasseraufbereitung/Osmoseanlagen/Tank-Osmose
- Konzept-ID: `c_02bf922ea10b32ab`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Tank-Osmose: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Osmoseanlage mit Drucktank: nutzbares Volumen und Nachfüllzeit verstehen
  1. Drucktank hygienisch betreiben: Membran, Vordruck und Stagnation
  1. Tank-Osmose bei niedrigem Leitungsdruck: Boosterpumpe sinnvoll auswählen
  1. Geschmack nach dem Tank: Remineralisierung und Nachfilter kritisch vergleichen

## Wasseraufbereitung/Enthärtungsanlagen
- Konzept-ID: `c_7ea25ea4debb494e`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Enthärtungsanlagen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Enthärtungsanlage dimensionieren: Wasserhärte, Verbrauch und Kapazität zusammenführen
  1. Einzel- oder Doppelenthärtung: Unterschiede bei Dauerbetrieb und Regeneration
  1. Salzverbrauch einer Enthärtungsanlage: Einfluss von Einstellung und Rohwasserhärte
  1. Bypass und Verschneidung einstellen: gewünschte Resthärte sicher erreichen

## Wasseraufbereitung/UV-Anlagen
- Konzept-ID: `c_cfd4525c2660b2b6`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für UV-Anlagen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. UV-Anlage dimensionieren: Durchfluss, UV-Dosis und Wassertrübung berücksichtigen
  1. Vorfiltration vor UV-Desinfektion: wann Eisen und Trübstoffe die Wirkung mindern
  1. UV-Lampe und Quarzrohr warten: Betriebsstunden, Belag und Dichtigkeitsprüfung
  1. UV-Anlage mit Überwachung: Sensor, Alarm und Sicherheitsabschaltung vergleichen

## Wasseraufbereitung/Dosieranlagen
- Konzept-ID: `c_c3f381c7fc1d9666`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Dosieranlagen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Dosieranlage gegen Korrosion und Kalk: Einsatzgrenzen vor dem Einbau prüfen
  1. Dosiermenge einstellen: Wasserverbrauch, Impulsgeber und Wirkstoffkonzentration
  1. Dosiermittel nachfüllen: Lagerung, Hygiene und Dokumentation
  1. Dosierung oder Enthärtung: unterschiedliche Ziele und Folgekosten vergleichen

## Wasseraufbereitung/Filterzubehör
- Konzept-ID: `c_fc9bb8a24cdf0f29`
- Suchintention: `informational-commercial`
- Scope: Übergeordnete Kategorie für fachlich getrennte Untergruppen von Filterzubehör.
- Ausschlüsse: Einzelne Artikeltypen wie FAQ oder Vergleich; Anbieter- und Standortseiten; Nicht zugeordnete Nachbartechnologien

## Wasseraufbereitung/Filterzubehör/Ersatzfilter
- Konzept-ID: `c_45f9a534de2d22e1`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Ersatzfilter: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Ersatzfilter eindeutig zuordnen: Bauform, Anschluss und Herstellerkennung prüfen
  1. Originalfilter oder kompatible Kartusche: Passform, Leistung und Nachweisbarkeit
  1. Ersatzfilter bevorraten: Lagerdauer, Verpackung und hygienische Aufbewahrung
  1. Filterwechselkosten über fünf Jahre: versteckte Folgekosten eines Systems

## Wasseraufbereitung/Filterzubehör/Filtergehäuse
- Konzept-ID: `c_e3a9b6776402179a`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Filtergehäuse: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Filtergehäuse aus Kunststoff oder Metall: Druck, Temperatur und Trinkwasserkontakt
  1. Single-, Duo- oder Trio-Gehäuse: sinnvolle Stufenkombinationen planen
  1. Filtergehäuse abdichten: O-Ring, Gewinde und Anzugsmoment richtig behandeln
  1. Transparente Filtertassen: Vorteile, UV-Risiken und Einbauort

## Wasseraufbereitung/Filterzubehör/Anschlussadapter
- Konzept-ID: `c_7ef641054f9860e4`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Anschlussadapter: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Adapter für Wasserfilter auswählen: Zollmaß, Gewindeart und Dichtprinzip
  1. Drei-Wege-Armatur anschließen: Adapterketten und Druckverlust vermeiden
  1. Schnellsteckverbinder für Filteranlagen: Rohrmaß und Sicherungsclip prüfen
  1. Übergang von Kupfer, Edelstahl oder Kunststoff auf Filtersysteme planen

## Wasseranalyse
- Konzept-ID: `c_73352ca276a45229`
- Suchintention: `informational-commercial`
- Scope: Zentraler Content- und Affiliate-Hub für Wasseranalyse; bündelt dauerhaft tragfähige Produkt-, Planungs- und Technikcluster.
- Ausschlüsse: Regionale Anbieterlisten; Magazinmeldungen; Produkte anderer Hauptäste mit nur ähnlichem Wortlaut

## Wasseranalyse/Trinkwasseranalyse
- Konzept-ID: `c_66cfb43160c6f414`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Trinkwasseranalyse: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Brunnenwasseranalyse; Legionellenpflichtprüfung als eigener Cluster; Laboranbieter-Verzeichnis; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. Trinkwasseranalyse auswählen: welche Parameter zum Gebäude und zur Fragestellung passen
  1. Probe am Wasserhahn nehmen: Stagnations- und Zufallsprobe unterscheiden
  1. Kosten einer Trinkwasseranalyse: Basispaket, Schwermetalle und Mikrobiologie
  1. Laborbericht verstehen: Grenzwert, Bestimmungsgrenze und Messunsicherheit

## Wasseranalyse/Brunnenwasseranalyse
- Konzept-ID: `c_615db3441b597e54`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Brunnenwasseranalyse: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Allgemeine Trinkwasseranalyse aus dem öffentlichen Netz; Aufbereitungsprodukte; Anbietersuche nach Laboren; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. Brunnenwasser vor der Nutzung prüfen: sinnvolles Mindestpaket an Parametern
  1. Eisen, Mangan, Nitrat und Keime im Brunnenwasser gemeinsam bewerten
  1. Brunnenwasser saisonal beproben: Zeitpunkt nach Starkregen und Trockenperioden
  1. Analysewerte in eine passende Aufbereitungskette übersetzen

## Wasseranalyse/Legionellenprüfung
- Konzept-ID: `c_3750036f7cc5220d`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Legionellenprüfung: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Wann eine Legionellenprüfung erforderlich ist: Anlage, Nutzung und Betreiberrolle
  1. Probenahmestellen für Legionellen festlegen: Vorlauf, Rücklauf und entfernte Zapfstelle
  1. Legionellenbefund einordnen: KBE-Wert, technischer Maßnahmenwert und Risikoabschätzung
  1. Maßnahmen nach einem positiven Befund: Ursachenprüfung statt bloßer Sofortdesinfektion

## Wasseranalyse/Schadstoffanalyse
- Konzept-ID: `c_8e2f7beb0108b7b8`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Schadstoffanalyse: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Routine-Basisanalyse ohne konkrete Schadstofffrage; Legionellenprüfung; Schnelltests ohne Laborbestätigung; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. PFAS, Blei, Kupfer oder Arsen: zielgerichtetes Analysepaket zusammenstellen
  1. Komplettanalyse oder Einzelparameter: Kosten und Aussagekraft vergleichen
  1. Probenkette dokumentieren: Gefäß, Transport und Zuordnung der Entnahmestelle
  1. Auffälligen Messwert bestätigen: Kontrollprobe und mögliche Kontamination

## Wasseranalyse/Schnelltests
- Konzept-ID: `c_d2f1df282af61df6`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Schnelltests: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Teststreifen für Härte, Nitrat und Chlor: Genauigkeit und Ablesefehler
  1. Schnelltest richtig lagern: Feuchtigkeit, Haltbarkeit und Reagenzschutz
  1. Farbskala oder digitales Lesegerät: Reproduzierbarkeit im Heimgebrauch
  1. Wann ein Schnelltest nicht genügt und ein akkreditiertes Labor nötig ist

## Wasseranalyse/Messgeräte
- Konzept-ID: `c_8b047b8e2577ac57`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Messgeräte: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. pH, Leitfähigkeit und TDS: welche Größe ein Handmessgerät tatsächlich erfasst
  1. Messgerät kalibrieren: Pufferlösungen, Zellkonstante und Temperatur
  1. Automatische Temperaturkompensation richtig interpretieren
  1. Einsteigergerät oder Mehrparametergerät: Messbereich und Wartungsaufwand vergleichen

## Wasseranalyse/Probenahme
- Konzept-ID: `c_4f288186b12e47ae`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Probenahme: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Stagnationsprobe oder Spülprobe: passende Entnahmestrategie wählen
  1. Sterile Probenflasche verwenden: Hahnvorbereitung und Kontamination vermeiden
  1. Wasserprobe kühlen und transportieren: Zeitfenster für chemische und mikrobiologische Tests
  1. Repräsentative Probe aus Tank, Brunnen oder Leitung entnehmen

## Brunnen
- Konzept-ID: `c_9f8470214efbe88e`
- Suchintention: `informational-commercial`
- Scope: Zentraler Content- und Affiliate-Hub für Brunnen; bündelt dauerhaft tragfähige Produkt-, Planungs- und Technikcluster.
- Ausschlüsse: Regionale Anbieterlisten; Magazinmeldungen; Produkte anderer Hauptäste mit nur ähnlichem Wortlaut

## Brunnen/Brunnenbau
- Konzept-ID: `c_15246d9fbb40eacf`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Brunnenbau: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Brunnenbauverfahren vergleichen: Bohren, Schlagen und Schachten
  1. Brunnenkosten nach Tiefe, Geologie und Ausbau realistisch kalkulieren
  1. Standort für einen Brunnen prüfen: Zugänglichkeit, Schutzabstände und Wasserbedarf
  1. Brunnenbauer beauftragen: Leistungsbeschreibung, Bohrprofil und Abnahme

## Brunnen/Gartenbrunnen
- Konzept-ID: `c_b92daef8e5eefbca`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Gartenbrunnen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Gartenbrunnen nach Bewässerungsbedarf dimensionieren: Menge statt nur Tiefe
  1. Ansaughöhe beim Gartenbrunnen: wann eine Oberflächenpumpe nicht mehr reicht
  1. Gartenbrunnen winterfest machen: Leitung, Pumpe und Entnahmestelle entleeren
  1. Gartenbrunnen anmelden oder genehmigen: örtliche Vorgaben systematisch prüfen

## Brunnen/Schlagbrunnen
- Konzept-ID: `c_cc56b7d34e700ce3`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Schlagbrunnen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Geeigneter Boden für einen Schlagbrunnen: Korngröße, Grundwasserstand und Tiefe
  1. Filterrohr und Rammspitze auswählen: Durchmesser und Schlitzweite
  1. Schlagbrunnen herstellen: Muffen, Rammkopf und senkrechte Führung
  1. Schlagbrunnen liefert zu wenig Wasser: Verockerung, Versandung und Ansaughöhe

## Brunnen/Brunnenausbau
- Konzept-ID: `c_678e737ebcef5178`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Brunnenausbau: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Brunnenrohr und Filterstrecke auslegen: Durchmesser, Schlitzweite und Länge
  1. Filterkies richtig wählen: Abstimmung auf Boden und Filterrohr
  1. Brunnenkopf abdichten: Oberflächenwasser und Kleintiere fernhalten
  1. Pumpe im Brunnen positionieren: Abstand zu Filterstrecke und Brunnenboden

## Brunnen/Brunnenpflege
- Konzept-ID: `c_ae69fad7acbd0eff`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Brunnenpflege: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Brunnen reinigen: Sediment entfernen ohne Filterstrecke zu beschädigen
  1. Brunnen regenerieren: mechanische und chemische Verfahren unterscheiden
  1. Brunnenkamera einsetzen: Ausbauzustand und Schadstellen diagnostizieren
  1. Wartungsintervalle nach Wasserchemie und Förderbetrieb festlegen

## Brunnen/Brunnenwasser filtern
- Konzept-ID: `c_e1053bbf3a62270b`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Brunnenwasser filtern: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Allgemeine Trinkwasserfilter ohne Brunnenbezug; Brunnenwasseranalyse als eigener Analysecluster; Tiefbrunnenpumpen als Pumpencluster; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. Aufbereitung von Brunnenwasser aus Analysewerten planen
  1. Sediment, Eisen und Mangan in der richtigen Reihenfolge entfernen
  1. Desinfektion von Brunnenwasser: UV, Vorfiltration und Grenzen
  1. Rückspülbare Filter für Brunnenwasser nach Durchfluss dimensionieren

## Brunnen/Brunnenrecht
- Konzept-ID: `c_fcfff3b4e1d25abb`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Brunnenrecht: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Grundwasserentnahme nach WHG: erlaubnisfreie Nutzung und örtliche Grenzen
  1. Brunnenanzeige vorbereiten: Lageplan, Tiefe und Nutzungszweck dokumentieren
  1. Brunnenwasser als Trinkwasser nutzen: zusätzliche Pflichten und Untersuchungen
  1. Landes- und Kommunalrecht prüfen: warum pauschale Genehmigungsaussagen riskant sind

## Pumpen & Druck
- Konzept-ID: `c_8fa33636dc438300`
- Suchintention: `informational-commercial`
- Scope: Zentraler Content- und Affiliate-Hub für Pumpen & Druck; bündelt dauerhaft tragfähige Produkt-, Planungs- und Technikcluster.
- Ausschlüsse: Regionale Anbieterlisten; Magazinmeldungen; Produkte anderer Hauptäste mit nur ähnlichem Wortlaut

## Pumpen & Druck/Gartenpumpen
- Konzept-ID: `c_0857c58d5479a4bf`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Gartenpumpen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Gartenpumpe auswählen: Förderhöhe, Ansaughöhe und benötigte Wassermenge
  1. Selbstansaugende Gartenpumpe in Betrieb nehmen: Saugleitung vollständig befüllen
  1. Gartenpumpe ist laut: Kavitation, Befestigung und Luft in der Leitung prüfen
  1. Gartenpumpe für Regner dimensionieren: Druckbedarf und gleichzeitige Verbraucher

## Pumpen & Druck/Tauchpumpen
- Konzept-ID: `c_28002ac59caad115`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Tauchpumpen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Tauchpumpe für Tank oder Schacht auswählen: Eintauchtiefe und Kühlung
  1. Tauchpumpe mit Schwimmerschalter: Schaltpunkte und Mindestwasserstand
  1. Tauchpumpe fördert nicht: Drehrichtung, Luftpolster und verstopfter Einlauf
  1. Flachsaugende Tauchpumpe: erreichbarer Restwasserstand und Einsatzgrenzen

## Pumpen & Druck/Tiefbrunnenpumpen
- Konzept-ID: `c_4c19b8b4dfc6015c`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Tiefbrunnenpumpen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Tiefbrunnenpumpe dimensionieren: Brunnenleistung, Förderhöhe und Rohrverluste
  1. 3-Zoll oder 4-Zoll-Pumpe: Brunnenrohr und Kühlströmung berücksichtigen
  1. Tiefbrunnenpumpe richtig aufhängen: Seil, Kabel und Steigleitung
  1. Takten der Tiefbrunnenpumpe vermeiden: Druckbehälter und Steuerung abstimmen

## Pumpen & Druck/Schmutzwasserpumpen
- Konzept-ID: `c_629db1d0c14bf72d`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Schmutzwasserpumpen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Komplette Hebeanlagen; Regenwasserpumpen; Tiefbrunnenpumpen; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. Schmutzwasserpumpe nach Korngröße und freiem Durchgang auswählen
  1. Schmutzwasserpumpe im Keller einsetzen: Restwasser, Schlauch und Stromsicherheit
  1. Verstopfte Schmutzwasserpumpe reinigen: Laufrad und Einlauf kontrollieren
  1. Schmutzwasserpumpe für Baugrube: Schlammanteil und Dauerbetrieb bewerten

## Pumpen & Druck/Klarwasserpumpen
- Konzept-ID: `c_22d7abff47e2de25`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Klarwasserpumpen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Klarwasserpumpe für Pool, Tank oder Keller: Fördermenge und Restwasserstand
  1. Klarwasserpumpe mit flacher Absaugung richtig positionieren
  1. Schwimmerschalter bei engem Schacht: integrierte und externe Lösungen
  1. Klarwasser- oder Schmutzwasserpumpe: Medium und Korngröße entscheiden

## Pumpen & Druck/Hauswasserwerke
- Konzept-ID: `c_9a4fd29c1d8af231`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Hauswasserwerke: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Hauswasserwerk dimensionieren: Zapfstellen, Förderhöhe und Behältergröße
  1. Membrandruckbehälter am Hauswasserwerk: Vordruck prüfen und einstellen
  1. Hauswasserwerk schaltet ständig: Leckage, Rückschlagventil oder kleine Hysterese
  1. Hauswasserwerk für Brunnen oder Zisterne: Unterschiede bei Ansaugung und Schutz

## Pumpen & Druck/Druckerhöhungsanlagen
- Konzept-ID: `c_9dc62b0789174a07`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Druckerhöhungsanlagen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Druckerhöhungsanlage für ein Einfamilienhaus auslegen
  1. Konstantdruck oder Druckschalter: Komfort und Energiebedarf vergleichen
  1. Druckerhöhung direkt am Trinkwassernetz: Vordruckkontrolle und Absicherung
  1. Mehrpumpenanlage dimensionieren: Redundanz und Spitzenlasten

## Pumpen & Druck/Pumpensteuerung
- Konzept-ID: `c_289eaa4c0104a90c`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Pumpensteuerung: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Elektronische Pumpensteuerung oder Druckschalter: passende Schaltlogik wählen
  1. Trockenlaufschutz einstellen: Stromaufnahme, Druck oder Füllstand als Signal
  1. Frequenzsteuerung für Pumpen: konstanten Druck ohne Takten erreichen
  1. Füllstandsschalter verdrahten und Schaltpunkte betriebssicher festlegen

## Pumpen & Druck/Pumpenzubehör
- Konzept-ID: `c_34c77d2f4c53fe24`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Pumpenzubehör: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Saugschlauch und Saugrohr dimensionieren: Luftdichtheit und Druckverlust
  1. Rückschlagventil richtig einbauen: Einbaulage, Öffnungsdruck und Wartung
  1. Druckbehälter nachrüsten: Volumen und Vordruck zur Pumpe abstimmen
  1. Vorfilter an der Pumpe: Schutzwirkung gegen zusätzlichen Saugwiderstand abwägen

## Regenwasser
- Konzept-ID: `c_2b09f5a8c7127eb7`
- Suchintention: `informational-commercial`
- Scope: Zentraler Content- und Affiliate-Hub für Regenwasser; bündelt dauerhaft tragfähige Produkt-, Planungs- und Technikcluster.
- Ausschlüsse: Regionale Anbieterlisten; Magazinmeldungen; Produkte anderer Hauptäste mit nur ähnlichem Wortlaut

## Regenwasser/Regenspeicher
- Konzept-ID: `c_ad0de57c8e0c7c6f`
- Suchintention: `informational-commercial`
- Scope: Übergeordnete Kategorie für fachlich getrennte Untergruppen von Regenspeicher.
- Ausschlüsse: Einzelne Artikeltypen wie FAQ oder Vergleich; Anbieter- und Standortseiten; Nicht zugeordnete Nachbartechnologien

## Regenwasser/Regenspeicher/Regentonnen
- Konzept-ID: `c_a338c903cb14811d`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Regentonnen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Regentonne nach Dachfläche und Gartenbedarf dimensionieren
  1. Regentonne frostsicher betreiben: Entleerung, Auslauf und Material
  1. Regentonnen verbinden: gleiche Wasserstände ohne Leckagen
  1. Fallrohrsammler für Regentonnen: Filter, Überlaufstopp und Rohrgröße

## Regenwasser/Regenspeicher/Erdtanks
- Konzept-ID: `c_a524276b4cb59ba0`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Erdtanks: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Generische Trink- und Nutzwassertanks ohne Regenwasserbezug; Abwassertanks; Löschwassertanks; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. Regenwasser-Erdtank dimensionieren: Ertrag, Verbrauch und Überlauf berücksichtigen
  1. Erdtank einbauen: Baugrube, Grundwasser und befahrbare Abdeckung
  1. Kunststoff- oder Betonzisterne: Gewicht, Einbau und Wartung vergleichen
  1. Erdtank gegen Auftrieb sichern: Grundwasserstand und Herstellerangaben

## Regenwasser/Regenspeicher/Kellertanks
- Konzept-ID: `c_11b7a7b3af39fdcb`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Kellertanks: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Generische Kellertanks für Trink- oder Nutzwasser ohne Regenwasserbezug; Abwassertanks; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. Kellertank für Regenwasser modular planen: Türbreite und nutzbares Volumen
  1. Kellertank gegen Geruch und Überlauf absichern
  1. Kellertanks verbinden: kommunizierende Behälter und Reinigungszugang
  1. Tragfähigkeit des Aufstellorts für gefüllte Kellertanks prüfen

## Regenwasser/Regenwasserfilter
- Konzept-ID: `c_51f0c976b04bb151`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Regenwasserfilter: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Trinkwasserfilter und Hauswasserfilter; Filter für Brunnenwasser; Straßenabflussbehandlung ohne private Anlagenintention; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. Regenwasserfilter nach Dachfläche und Nutzung auswählen
  1. Fallrohrfilter, Korbfilter oder Wirbelfilter: Wartung und Wasserertrag vergleichen
  1. Filter vor der Zisterne einbauen: Gefälle und Notüberlauf planen
  1. Regenwasserfilter reinigen: Intervalle nach Dach und Baumbestand

## Regenwasser/Regenwasserpumpen
- Konzept-ID: `c_38634ac7d679560f`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Regenwasserpumpen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Allgemeine Pumpentypen ohne Regenwassersystembezug; Bewässerungsverteilung hinter der Pumpe; Brunnenpumpen; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. Zisternenpumpe für Garten oder Haus dimensionieren
  1. Schwimmende Entnahme: Wasser unter der Oberfläche statt vom Tankboden fördern
  1. Unterwasserpumpe oder Saugpumpe für Regenwasser vergleichen
  1. Regenwasserpumpe gegen Trockenlauf und häufiges Takten schützen

## Regenwasser/Hausnutzung
- Konzept-ID: `c_87839b5d9e584443`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Hausnutzung: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Gartenbewässerung als primäre Nutzung; Trinkwasseraufbereitung; allgemeine Zisternenwahl; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. Regenwasser für WC und Waschmaschine: Leitungsnetz strikt trennen
  1. Trinkwassernachspeisung mit freiem Auslauf sicher planen
  1. Regenwassernutzung im Haus wirtschaftlich berechnen: Verbrauch und Wartung
  1. Kennzeichnung von Betriebswasserleitungen und Zapfstellen umsetzen

## Regenwasser/Versickerungsanlagen
- Konzept-ID: `c_ae035e203001f393`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Versickerungsanlagen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Rigole dimensionieren: Dachfläche, Boden und Bemessungsregen
  1. Sickerschacht oder Mulde: Flächenbedarf und Wartung vergleichen
  1. Vorbehandlung vor der Versickerung: Sedimente und belastete Flächen
  1. Versickerungsleistung des Bodens mit einem einfachen Test abschätzen

## Regenwasser/Retentionsanlagen
- Konzept-ID: `c_d0ebf4c01429d446`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Retentionsanlagen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Retentionszisterne auslegen: Rückhaltevolumen und Drosselabfluss
  1. Regenwassernutzung und Retention in einem Tank kombinieren
  1. Drossel und Notüberlauf einer Retentionsanlage warten
  1. Retentionsvolumen bei Starkregen: kommunale Vorgaben in die Planung übernehmen

## Regenwasser/Zisternenpflege
- Konzept-ID: `c_f318c8b41a55be35`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Zisternenpflege: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Zisterne reinigen: wann Sedimentschicht entfernt werden sollte
  1. Geruch aus der Zisterne: Zulauf, Überlauf und Sauerstoff prüfen
  1. Mücken und Kleintiere aus der Zisterne fernhalten
  1. Inspektion von Pumpe, Filter und Nachspeisung als Wartungsplan bündeln

## Bewässerung
- Konzept-ID: `c_a77b226bf4219051`
- Suchintention: `informational-commercial`
- Scope: Zentraler Content- und Affiliate-Hub für Bewässerung; bündelt dauerhaft tragfähige Produkt-, Planungs- und Technikcluster.
- Ausschlüsse: Regionale Anbieterlisten; Magazinmeldungen; Produkte anderer Hauptäste mit nur ähnlichem Wortlaut

## Bewässerung/Tropfbewässerung
- Konzept-ID: `c_e269cbab96b89672`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Tropfbewässerung: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Tropfbewässerung dimensionieren: Tropfermenge, Leitungslänge und Druck
  1. Druckkompensierende oder einfache Tropfer: Höhenunterschiede berücksichtigen
  1. Tropfschlauch unter Mulch verlegen: Abstand und Verstopfungsschutz
  1. Tropfbewässerung winterfest machen und Leitungen spülen

## Bewässerung/Sprinklersysteme
- Konzept-ID: `c_bd5efc76eb86d237`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Sprinklersysteme: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Versenkregner planen: Wurfweiten überlappen statt Lücken erzeugen
  1. Kreis-, Viereck- oder Impulsregner: passende Flächenform wählen
  1. Sprinklerzonen nach verfügbarem Wasserdruck aufteilen
  1. Düsen eines Sprinklersystems reinigen und gleichmäßig einstellen

## Bewässerung/Bewässerungscomputer
- Konzept-ID: `c_b9636072f02d4544`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Bewässerungscomputer: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Bewässerungscomputer mit einem oder mehreren Ausgängen auswählen
  1. Bewässerungszeiten nach Bodenart und Pflanzenbedarf festlegen
  1. Bewässerungscomputer mit Wetterdaten: Nutzen und Ausfallrisiken
  1. Batterie, Ventil und Frostschutz bei Bewässerungscomputern warten

## Bewässerung/Bodenfeuchtesensoren
- Konzept-ID: `c_b0ed3ca95b4fd87e`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Bodenfeuchtesensoren: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Bodenfeuchtesensor richtig platzieren: Wurzelzone statt Oberfläche messen
  1. Schwellwert für automatische Bewässerung praktisch einstellen
  1. Kapazitive und tensiometrische Sensoren im Garten vergleichen
  1. Fehlmessungen durch Salz, Bodenart und schlechten Bodenkontakt erkennen

## Bewässerung/Gartenschläuche
- Konzept-ID: `c_b877053b93b555e2`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Gartenschläuche: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Gartenschlauch-Durchmesser nach Länge und Durchfluss auswählen
  1. Knicksicher, dehnbar oder flach: Schlauchtypen im Praxiseinsatz vergleichen
  1. Schlauchkupplungen abdichten: O-Ringe und Stecksysteme warten
  1. Schlauchwagen und Wandbox: Aufrollmechanik und Frostlagerung

## Bewässerung/Bewässerung planen
- Konzept-ID: `c_09d86ca4a0f36eef`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Bewässerung planen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regenwasserspeicherung und Brunnenbau; Einzelne Produktfamilien als vollständiger Zweitcluster; Landwirtschaftliche Großberegnung; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. Wasserbedarf eines Gartens nach Fläche, Pflanzen und Boden abschätzen
  1. Bewässerungszonen für Rasen, Beet und Gewächshaus trennen
  1. Regenwasser, Brunnen oder Leitungswasser als Quelle vergleichen
  1. Druck und Durchfluss vor der Planung eines Bewässerungssystems messen

## Wassertanks
- Konzept-ID: `c_87e18eb4ba857d09`
- Suchintention: `informational-commercial`
- Scope: Zentraler Content- und Affiliate-Hub für Wassertanks; bündelt dauerhaft tragfähige Produkt-, Planungs- und Technikcluster.
- Ausschlüsse: Regenwasserzisternen; Abwassertanks; Industrielle Prozessbehälter; Regionale Anbieter- und Firmensuche

## Wassertanks/Trinkwassertanks
- Konzept-ID: `c_4dcdddcf889e52ea`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Trinkwassertanks: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Trinkwassertank auswählen: Materialeignung, Lichtschutz und Reinigungszugang
  1. Trinkwassertank dimensionieren: Verbrauch, Reserve und Wasserwechsel
  1. Trinkwassertank desinfizieren: Konzentration, Einwirkzeit und Spülung
  1. Stagnation im Trinkwassertank vermeiden: Umwälzung und Entnahmeführung

## Wassertanks/IBC-Container
- Konzept-ID: `c_c1fc41c2854307e2`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für IBC-Container: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. IBC-Container für Wasser nutzen: Vorbefüllung und Materialfreigabe prüfen
  1. IBC vor Licht und Frost schützen: Abdeckung und Aufstellort
  1. Mehrere IBC verbinden: gleichmäßige Entnahme und sichere Armaturen
  1. IBC reinigen: Rückstände erkennen und schwer erreichbare Stellen behandeln

## Wassertanks/Mobile Wassertanks
- Konzept-ID: `c_cb6e85dbbb87ba54`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Mobile Wassertanks: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Mobiler Wassertank für Anhänger oder Fahrzeug: Gewicht und Ladungssicherung
  1. Faltkanister, Wassertasche oder starrer Tank: Einsatzdauer vergleichen
  1. Schwallbewegung in Transporttanks: Form und Befestigung berücksichtigen
  1. Mobile Tanks hygienisch trocknen und geruchsfrei lagern

## Wassertanks/Nutzwassertanks
- Konzept-ID: `c_524f1ddf3b32ec0e`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Nutzwassertanks: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Nutzwassertank für Garten oder Betrieb: Medium und Material abstimmen
  1. Oberirdischen Tank UV- und frostsicher aufstellen
  1. Entnahme aus Nutzwassertanks: Anschlussposition und Restvolumen
  1. Belüftung und Überlauf eines Nutzwassertanks dimensionieren

## Wassertanks/Löschwassertanks
- Konzept-ID: `c_679952a22facb8ec`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Löschwassertanks: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Löschwassertank dimensionieren: erforderliches Volumen und Entnahmekonzept
  1. Unterirdischer oder oberirdischer Löschwassertank: Zugang und Frostschutz
  1. Sauganschluss am Löschwassertank: Kennzeichnung und Freihaltung
  1. Inspektion von Löschwasservorräten: Füllstand, Dichtheit und Wasserqualität

## Wassertanks/Tankzubehör
- Konzept-ID: `c_7405ad96275999a0`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Tankzubehör: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Füllstandsanzeige für Tanks: mechanisch, hydrostatisch oder per Ultraschall
  1. Tankdurchführung dicht montieren: Bohrung, Dichtung und Wandstärke
  1. Überlauf, Belüftung und Entnahmeanschluss sinnvoll anordnen
  1. Tankreinigungszubehör auswählen: Bürsten, Pumpen und Inspektionsöffnung

## Abwassertechnik
- Konzept-ID: `c_b4e64ebaa1080fe7`
- Suchintention: `informational-commercial`
- Scope: Zentraler Content- und Affiliate-Hub für Abwassertechnik; bündelt dauerhaft tragfähige Produkt-, Planungs- und Technikcluster.
- Ausschlüsse: Regionale Anbieterlisten; Magazinmeldungen; Produkte anderer Hauptäste mit nur ähnlichem Wortlaut

## Abwassertechnik/Hebeanlagen
- Konzept-ID: `c_fc02b3c1b644d3b6`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Hebeanlagen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Hebeanlage dimensionieren: Zufluss, Förderhöhe und Druckleitung
  1. Fäkalien- oder Kleinhebeanlage: angeschlossene Entwässerungsgegenstände entscheiden
  1. Doppelhebeanlage für Ausfallsicherheit: Steuerung und Alarm
  1. Hebeanlage warten: Rückflussverhinderer, Behälter und Pumpe prüfen

## Abwassertechnik/Rückstauschutz
- Konzept-ID: `c_83310ec6a96c8c2b`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Rückstauschutz: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Rückstauverschluss oder Hebeanlage: Nutzung unterhalb der Rückstauebene
  1. Rückstauklappe regelmäßig prüfen: Verschluss, Dichtung und Alarm
  1. Elektronischer Rückstauautomat: Stromausfall und Notverschluss
  1. Rückstauschutz im Bestand nachrüsten: Leitungsführung und Zugänglichkeit

## Abwassertechnik/Grauwasseranlagen
- Konzept-ID: `c_6c6f8326734d479b`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Grauwasseranlagen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regenwassernutzung; kommunale Wasserwiederverwendung; Abwassertanks ohne Aufbereitung; Regionale Anbieter- und Firmensuche
- Unverbindliche Beitragspotenziale:
  1. Grauwasseranlage planen: Quellen, Verbrauch und Speichervolumen
  1. Grauwasser aufbereiten: biologische Stufe, Membran und Desinfektion
  1. Grauwasserleitungen vom Trinkwassernetz sicher trennen und kennzeichnen
  1. Wartungs- und Energiekosten einer Grauwasseranlage realistisch berechnen

## Abwassertechnik/Kleinkläranlagen
- Konzept-ID: `c_908a4f0604144128`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Kleinkläranlagen: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. SBR- oder Pflanzenkläranlage: Grundstück, Lastschwankung und Wartung vergleichen
  1. Kleinkläranlage dimensionieren: Einwohnerwerte und Spitzenbelastung
  1. Nachrüstung einer bestehenden Grube: technische und behördliche Prüfung
  1. Betriebsstörungen erkennen: Schlamm, Belüftung und Ablaufqualität

## Abwassertechnik/Abwassertanks
- Konzept-ID: `c_5ec9a4a2a799cca6`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Abwassertanks: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Abwassertank dimensionieren: Nutzung, Entleerungsintervall und Reserve
  1. Fäkalientank im Garten oder auf dem Freizeitgrundstück dicht einbauen
  1. Füllstandsalarm für Abwassertanks: Sensorposition und Ausfallsicherheit
  1. Geruch aus dem Abwassertank durch Entlüftung und dichte Anschlüsse reduzieren

## Abwassertechnik/Bodenabläufe
- Konzept-ID: `c_1f66a41f36344745`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Bodenabläufe: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Bodenablauf nach Sperrwasserhöhe und Ablaufleistung auswählen
  1. Geruchsverschluss im selten genutzten Ablauf vor Austrocknung schützen
  1. Bodenablauf im Keller gegen Rückstau richtig einordnen
  1. Bodenablauf reinigen: Rost, Einsatz und Anschlussleitung zugänglich halten

## Abwassertechnik/Revisionsschächte
- Konzept-ID: `c_1f75db9504ffe8cd`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Revisionsschächte: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Revisionsschacht positionieren: Richtungswechsel und Zugänglichkeit
  1. Kunststoff- oder Betonschacht: Einbau und Belastung vergleichen
  1. Revisionsschacht gegen Fremdwasser und Wurzeleinwuchs abdichten
  1. Kanalinspektion über den Revisionsschacht vorbereiten

## Abwassertechnik/Abwasserrohre
- Konzept-ID: `c_6b95f89aced54769`
- Suchintention: `informational-commercial`
- Scope: Verbindlicher Themenraum für Abwasserrohre: Auswahl, Dimensionierung, Einbau, Betrieb, Wartung und Fehlerdiagnose, soweit fachlich passend.
- Ausschlüsse: Regionale Anbieter- und Firmensuche; Einzelne Marken- oder Modellseiten als Kategorien; Konkrete Artikel-Longtails als Unterkategorien
- Unverbindliche Beitragspotenziale:
  1. Abwasserrohr-Durchmesser und Gefälle im Gebäude richtig wählen
  1. HT-, KG- und schallgedämmte Rohre: Einsatzbereiche trennen
  1. Rohrverbindungen dicht montieren: Dichtung, Gleitmittel und Einstecktiefe
  1. Belüftung von Abwasserleitungen: Unterdruck und leere Geruchsverschlüsse vermeiden

