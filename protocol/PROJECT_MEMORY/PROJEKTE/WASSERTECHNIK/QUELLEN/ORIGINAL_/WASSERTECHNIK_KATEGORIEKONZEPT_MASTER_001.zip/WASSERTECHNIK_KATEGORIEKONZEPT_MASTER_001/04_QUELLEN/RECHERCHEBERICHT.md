# Recherchebericht

## Vorgehen

Die bindende Master-ZIP wurde vollständig als Regel- und Prüfgrundlage übernommen. Das zusätzliche PDF wurde nur als Inspirationsquelle behandelt. Kategorien wurden anschließend gegen aktuelle öffentliche Primär- und Fachquellen geprüft.

## Leitfragen

- Welche Produkt- und Systemfamilien besitzen eigenständige Such- und Kaufintentionen?
- Welche Begriffe beschreiben lediglich Verfahren, Merkmale oder Anwendungsfälle und gehören deshalb nicht automatisch in die Navigation?
- Wo entstehen Überschneidungen zwischen Trinkwasseraufbereitung, Brunnen, Pumpen, Regenwasser, Bewässerung, Tanks und Abwasser?
- Welche Marktintentionen eignen sich für HivePress, ohne den Contentbaum zu spiegeln?
- Welche technischen und rechtlichen Bereiche verlangen aktuelle Primärquellen und spätere Fachprüfung?

## Beleglage

- UBA, DVGW, TrinkwV und DIN bestätigen die eigenständigen fachlichen Räume Trinkwasserqualität, Aufbereitung, Installation, Regenwassernutzung, Versickerung und Druckerhöhung.
- Herstellerquellen von Grundfos, GARDENA, GRAF und Grünbeck wurden ausschließlich zur aktuellen Produkt- und Marktsegmentierung verwendet, nicht als alleinige Grundlage für Sicherheits- oder Rechtsaussagen.
- Das Wasserhaushaltsgesetz und die Abwasserverordnung begründen die gesonderte Behandlung rechtlich sensibler Brunnen-, Versickerungs- und Abwasserthemen.

## Grenze

Es wurden keine kostenpflichtigen Keywordvolumen, SERP-Überschneidungen oder Affiliate-Programmdaten erhoben. Das Konzept ist deshalb ein belastbarer Strukturentwurf, aber noch keine abschließend extern geprüfte Produktionsfreigabe.
