# Kategoriekonzept Wasser & Wassertechnik

Status: `PROPOSED – EXTERNE PRÜFUNG AUSSTEHEND`

## Verbindlicher Umfang
Das Konzept bildet einen allgemeinen deutschen Affiliate- und Branchenportal-Entwurf für private und kleingewerbliche Wassertechnik. Es ist rein lesend und verändert weder WordPress noch HivePress.

## Empfohlene Content-Hauptnavigation
1. Wasseraufbereitung
2. Wasseranalyse
3. Brunnen
4. Pumpen & Druck
5. Regenwasser
6. Bewässerung
7. Wassertanks
8. Abwassertechnik

**Separat:** `Anbieter finden` als Marketplace-Einstieg und `Magazin` als eigenständiger redaktioneller Einstieg. Beide werden nicht in den Contentbaum eingemischt.

## Content / Affiliate
- **Wasseraufbereitung** — `wasseraufbereitung`
  - **Hauswasserfilter** — `hauswasserfilter`
    - **Feinfilter** — `feinfilter`
    - **Rückspülfilter** — `ruckspulfilter`
    - **Automatikfilter** — `automatikfilter`
  - **Trinkwasserfilter** — `trinkwasserfilter`
    - **Tischfilter** — `tischfilter`
    - **Armaturfilter** — `armaturfilter`
    - **Untertischfilter** — `untertischfilter`
    - **Outdoorfilter** — `outdoorfilter`
  - **Osmoseanlagen** — `osmoseanlagen`
    - **Auftisch-Osmose** — `auftisch-osmose`
    - **Untertisch-Osmose** — `untertisch-osmose`
    - **Direct-Flow-Osmose** — `direct-flow-osmose`
    - **Tank-Osmose** — `tank-osmose`
  - **Enthärtungsanlagen** — `enthartungsanlagen`
  - **UV-Anlagen** — `uv-anlagen`
  - **Dosieranlagen** — `dosieranlagen`
  - **Filterzubehör** — `filterzubehor`
    - **Ersatzfilter** — `ersatzfilter`
    - **Filtergehäuse** — `filtergehause`
    - **Anschlussadapter** — `anschlussadapter`
- **Wasseranalyse** — `wasseranalyse`
  - **Trinkwasseranalyse** — `trinkwasseranalyse`
  - **Brunnenwasseranalyse** — `brunnenwasseranalyse`
  - **Legionellenprüfung** — `legionellenprufung`
  - **Schadstoffanalyse** — `schadstoffanalyse`
  - **Schnelltests** — `schnelltests`
  - **Messgeräte** — `messgerate`
  - **Probenahme** — `probenahme`
- **Brunnen** — `brunnen`
  - **Brunnenbau** — `brunnenbau`
  - **Gartenbrunnen** — `gartenbrunnen`
  - **Schlagbrunnen** — `schlagbrunnen`
  - **Brunnenausbau** — `brunnenausbau`
  - **Brunnenpflege** — `brunnenpflege`
  - **Brunnenwasser filtern** — `brunnenwasser-filtern`
  - **Brunnenrecht** — `brunnenrecht`
- **Pumpen & Druck** — `pumpen-und-druck`
  - **Gartenpumpen** — `gartenpumpen`
  - **Tauchpumpen** — `tauchpumpen`
  - **Tiefbrunnenpumpen** — `tiefbrunnenpumpen`
  - **Schmutzwasserpumpen** — `schmutzwasserpumpen`
  - **Klarwasserpumpen** — `klarwasserpumpen`
  - **Hauswasserwerke** — `hauswasserwerke`
  - **Druckerhöhungsanlagen** — `druckerhohungsanlagen`
  - **Pumpensteuerung** — `pumpensteuerung`
  - **Pumpenzubehör** — `pumpenzubehor`
- **Regenwasser** — `regenwasser`
  - **Regenspeicher** — `regenspeicher`
    - **Regentonnen** — `regentonnen`
    - **Erdtanks** — `erdtanks`
    - **Kellertanks** — `kellertanks`
  - **Regenwasserfilter** — `regenwasserfilter`
  - **Regenwasserpumpen** — `regenwasserpumpen`
  - **Hausnutzung** — `hausnutzung`
  - **Versickerungsanlagen** — `versickerungsanlagen`
  - **Retentionsanlagen** — `retentionsanlagen`
  - **Zisternenpflege** — `zisternenpflege`
- **Bewässerung** — `bewasserung`
  - **Tropfbewässerung** — `tropfbewasserung`
  - **Sprinklersysteme** — `sprinklersysteme`
  - **Bewässerungscomputer** — `bewasserungscomputer`
  - **Bodenfeuchtesensoren** — `bodenfeuchtesensoren`
  - **Gartenschläuche** — `gartenschlauche`
  - **Bewässerung planen** — `bewasserung-planen`
- **Wassertanks** — `wassertanks`
  - **Trinkwassertanks** — `trinkwassertanks`
  - **IBC-Container** — `ibc-container`
  - **Mobile Wassertanks** — `mobile-wassertanks`
  - **Nutzwassertanks** — `nutzwassertanks`
  - **Löschwassertanks** — `loschwassertanks`
  - **Tankzubehör** — `tankzubehor`
- **Abwassertechnik** — `abwassertechnik`
  - **Hebeanlagen** — `hebeanlagen`
  - **Rückstauschutz** — `ruckstauschutz`
  - **Grauwasseranlagen** — `grauwasseranlagen`
  - **Kleinkläranlagen** — `kleinklaranlagen`
  - **Abwassertanks** — `abwassertanks`
  - **Bodenabläufe** — `bodenablaufe`
  - **Revisionsschächte** — `revisionsschachte`
  - **Abwasserrohre** — `abwasserrohre`

## Marketplace / HivePress
- **Dienstleister** — `dienstleister`
  - **Wasserlabore** — `wasserlabore`
  - **Brunnenbauer** — `brunnenbauer`
  - **Pumpenservice** — `pumpenservice`
  - **Aufbereitungstechnik** — `aufbereitungstechnik`
  - **Regenwasser-Fachbetriebe** — `regenwasser-fachbetriebe`
  - **Bewässerungsbau** — `bewasserungsbau`
  - **Tankservice** — `tankservice`
  - **Abwasser-Fachbetriebe** — `abwasser-fachbetriebe`
- **Fachhandel** — `fachhandel`
  - **Filter & Aufbereitung** — `filter-und-aufbereitung`
  - **Pumpenfachhandel** — `pumpenfachhandel`
  - **Bewässerungshandel** — `bewasserungshandel`
  - **Tankfachhandel** — `tankfachhandel`
  - **Messgerätehandel** — `messgeratehandel`
  - **Ersatzteilshops** — `ersatzteilshops`
- **Hersteller** — `hersteller`
  - **Aufbereitungssysteme** — `aufbereitungssysteme`
  - **Pumpen & Druck** — `pumpen-und-druck`
  - **Mess- & Steuertechnik** — `mess-und-steuertechnik`
  - **Tanks & Speicher** — `tanks-und-speicher`
  - **Regenwassertechnik** — `regenwassertechnik`
  - **Abwassertechnik** — `abwassertechnik`
- **Gebrauchtmarkt** — `gebrauchtmarkt`
  - **Pumpen** — `pumpen`
  - **Filteranlagen** — `filteranlagen`
  - **Osmoseanlagen** — `osmoseanlagen`
  - **Tanks & Zisternen** — `tanks-und-zisternen`
  - **Messgeräte** — `messgerate`
  - **Bewässerungstechnik** — `bewasserungstechnik`

## Magazin
- **Wasser im Alltag** — `wasser-im-alltag`
- **Haus & Garten** — `haus-und-garten`
- **Selbstversorgung** — `selbstversorgung`
- **Hygiene & Sicherheit** — `hygiene-und-sicherheit`
- **Umwelt & Ressourcen** — `umwelt-und-ressourcen`
- **Technik & Innovation** — `technik-und-innovation`

## Glossar
- **Aktivkohle** — `aktivkohle`
- **Adsorption** — `adsorption`
- **Enthärtung** — `enthartung`
- **Ionenaustausch** — `ionenaustausch`
- **Umkehrosmose** — `umkehrosmose`
- **Ultrafiltration** — `ultrafiltration`
- **UV-Desinfektion** — `uv-desinfektion`
- **Wasserhärte** — `wasserharte`
- **Leitfähigkeit** — `leitfahigkeit`
- **TDS-Wert** — `tds-wert`
- **Förderhöhe** — `forderhohe`
- **Fördermenge** — `fordermenge`
- **Druckverlust** — `druckverlust`
- **Kavitation** — `kavitation`
- **Betriebswasser** — `betriebswasser`
- **Grauwasser** — `grauwasser`
- **Retention** — `retention`
- **Versickerung** — `versickerung`
- **Rückstauebene** — `ruckstauebene`
- **Freier Auslauf** — `freier-auslauf`

## Bewusst ausgeschlossene Vollbereiche
- Pool- und Schwimmbadtechnik
- Teich- und Aquarientechnik
- kommunale Großwasserwirtschaft
- industrielle Prozesswassertechnik als eigener Vollbereich
- Heizungs-/Klimatechnik und allgemeine Sanitärplanung

Diese Bereiche sind fachlich angrenzend, würden aber die Suchintentionen, Navigation und Monetarisierungslogik des Portals unverhältnismäßig verbreitern. Sie können später als getrennte Portale oder ausdrücklich freigegebene Erweiterungsmodule geplant werden.
