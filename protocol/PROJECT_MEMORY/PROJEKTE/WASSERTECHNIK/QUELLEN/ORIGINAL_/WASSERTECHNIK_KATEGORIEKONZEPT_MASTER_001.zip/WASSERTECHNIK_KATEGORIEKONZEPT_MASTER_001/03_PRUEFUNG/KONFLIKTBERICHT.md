# Konflikt- und Abgrenzungsbericht

## Gesamturteil

Die wichtigsten Überschneidungen des Inspirations-PDFs wurden nicht übernommen, sondern nach Suchintention und Keyword-Eigentümerschaft aufgelöst.

## Verbindliche Entscheidungen

1. **FAQ, Kaufberatung, Vergleich, Topliste, Modelle, Kosten und Einsatzgebiete sind keine festen Kategorieebenen.** Sie bleiben mögliche Artikeltypen unter einer fachlichen Endkategorie.
2. **Regionale Seiten liegen nicht im Contentbaum.** Ort, Radius und Bundesland werden im Marketplace über Filter und indexierbare Suchseiten des späteren Marktplatzsystems gesteuert.
3. **Regenwasserfilter gehören ausschließlich zu `Regenwasser`.** Allgemeine Trinkwasser- und Hauswasserfilter liegen in `Wasseraufbereitung`.
4. **Brunnenwasseranalyse gehört zu `Wasseranalyse`; Brunnenwasser filtern gehört zu `Brunnen`.** Messung und technische Behandlung besitzen unterschiedliche Nutzeraufgaben.
5. **Tiefbrunnenpumpen gehören zu `Pumpen & Druck`.** Der Brunnenbereich darf sie erklären und verknüpfen, aber keinen zweiten vollständigen Pumpencluster bilden.
6. **Regenwasserspeicher gehören zu `Regenwasser`; generische Trink-, Nutz- und mobile Tanks gehören zu `Wassertanks`; Abwassertanks gehören zu `Abwassertechnik`.**
7. **Bewässerung beginnt hinter der Wasserquelle.** Speicherung, Brunnenbau und Regenwassergewinnung bleiben in ihren Eigentümerästen.
8. **HivePress spiegelt den Contentbaum nicht.** Die Struktur folgt Anbieter-, Händler-, Hersteller- und Gebrauchtmarktintentionen.
9. **Marken und Modelle werden nicht automatisch zu Kategorien.** Sie sind Filter-, Datenbank- oder Artikelobjekte, bis eigenständige Tragfähigkeit nachgewiesen ist.
10. **Pool, Teich, Aquarium, kommunale Großanlagen und industrielle Prozesswassertechnik sind ausgeschlossene Vollbereiche.** Dadurch bleibt das Portal navigierbar und kommerziell fokussiert.

## Dokumentierte Restrisiken

- Ohne kostenpflichtige Keyword- und SERP-Daten ist die spätere Aufteilung einzelner dichter Cluster wie Osmoseanlagen, Wasserfilter und Bewässerungssysteme noch zu bestätigen.
- Rechtliche Inhalte zu Brunnen, Versickerung, Trinkwasser und Abwasser ändern sich beziehungsweise unterscheiden sich regional; redaktionelle Veröffentlichung benötigt immer eine aktuelle Fachprüfung.
- Produktbegriffe wie „Entkalkungsanlage“ werden umgangssprachlich uneinheitlich verwendet. Primärer Eigentümer bleibt `Enthärtungsanlagen`; Synonyme werden kontrolliert zugeordnet.
