# Filter statt Kategorien

## Marketplace / HivePress

Folgende Merkmale werden verbindlich als Filter oder Attribute empfohlen und **nicht** als feste Kategorien angelegt:

- Standort: Bundesland, Ort, Radius und Einsatzgebiet
- Kundengruppe: privat, Gewerbe, Kommune, Landwirtschaft
- Leistung: Beratung, Planung, Verkauf, Installation, Wartung, Reparatur, Notdienst
- Anlagenbezug: Filter, Osmose, Enthärtung, Pumpe, Brunnen, Regenwasser, Bewässerung, Tank, Abwasser
- Zertifikate und Fachnachweise
- betreute Marken
- mobiler Vor-Ort-Service oder Werkstatt
- Angebotsart: neu, gebraucht, Miete, Servicevertrag
- Preis- oder Budgetklasse, sofern technisch sinnvoll

## Content / Affiliate

Diese Merkmale werden zunächst als Facetten, Vergleichsfelder oder Artikelvarianten geführt:

- Marke und Modell
- Preisbereich
- Material
- Nennweite und Anschlussgröße
- Durchfluss, Fördermenge, Förderhöhe und Druck
- Tankvolumen
- Stromversorgung und Steuerungsart
- Zielgruppe und Gebäudegröße
- Region und lokale Rechtslage

Eine spätere Kategorie ist nur zulässig, wenn eigenständige Suchintention, Mindestsubstanz und trennscharfe Eigentümerschaft nachgewiesen sind.
