ROBOTIK KATEGORIE-WORKFLOW 0.2.0 (NEUTRALSTART)

Installierbares WordPress-Plugin fuer das Projekt Robotik.
Kategorien werden NICHT in WordPress erzeugt. Es ist nur eine Planungs-/Pruefoberflaeche.

NEU gegenueber 0.1.0: CORE-Seiten brauchen role=group oder role=product.
WordPress-Inhaltskategorien koennen nur Kind einer role=product-Seite sein.
Produktseiten duerfen keine weiteren Unterseiten erhalten.
Optional: topic_directions als grobe Themenrichtungen, keine Artikelpflicht.

SICHERHEIT: Keine API-Schluessel, keine Altportal-Begriffe, keine Fremd-IDs,
keine automatischen Hintergrundlaeufe oder WP-Live-Importe.

Fuer den ersten Test WordPress >= 6.4 und PHP >= 8.1; nur in einer
frischen Testinstallation ohne anderes Kategorieplugin installieren.
