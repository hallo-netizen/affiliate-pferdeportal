Robotik Kategorie-Workflow 0.3.0 (Testkandidat)

Ein WordPress-Plugin: bestehende JSON-Entwurfspruefung 0.2.0 sowie manuelle
nur-lesende WordPress-Bestandsaufnahme. Keine Webseiten-/Term-/Beitragsschreiber.

WP Admin > Robotik Kategorie > Bestand pruefen bzw. EINEN Gesamtbericht herunterladen.
Der Export enthaelt Titel, Slugs, Status, IDs, Eltern- und Kategoriezuordnungen,
aber keine Volltexte. Er ist nur fuer eingeloggte Admins mit Sicherheitspruefung.

Magazin wird nur als moegliche Taxonomie erkannt; Ads/Affiliate, GitHub-Master,
Keywordanalyse, fachliche Eignung und Frontend sind NOCH NICHT angebunden.
Nicht als vollstaendige Kategorieabnahme missverstehen.

Naechste Stufe: Master-Revisionsabgleich, belastbare fachliche Recherche,
semantische Dubletten und kontrollierter WordPress-Writer nach Freigabe.
