Robotik Kategorie-Workflow 0.4.13
Bestehendes Plugin: ein Update, eine Gesamtfreigabe, eine Ergebnisdatei.
KORRIGIERT: Nach 227 Importaufgaben werden zuerst die bestehenden 104 Robotik-Seiten mit der vorhandenen V1-Veröffentlichung öffentlich gemacht, dann 68 neue Seiten mit der vorhandenen V65-Veröffentlichung und danach 16 weitere Typseiten plus 48 Rubriken. Gespeicherte Stände werden nicht überschrieben.
Admin: Robotik Kategorie > Gesamtabschluss (einmalig), Checkbox einmal und den Lauf fortsetzen. Keine Google-Adressen-Sperre, keine neue Tabelle, kein automatischer Job oder Frontend-Umbau. Die öffentliche Menüausgabe bleibt Aufgabe des vorhandenen Robotik-Strukturdesign-Plugins; Import und Veröffentlichung alleine ändern kein Theme.
