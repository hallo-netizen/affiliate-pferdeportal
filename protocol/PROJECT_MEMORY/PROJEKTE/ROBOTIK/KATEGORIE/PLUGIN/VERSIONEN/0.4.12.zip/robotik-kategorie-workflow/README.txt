Robotik Kategorie-Workflow 0.4.12
EIN Update, EINMALIGE Freigabe, EINE Gesamtdatei.
WordPress: Robotik Kategorie > Gesamtabschluss (einmalig).
Drei Phasen laufen automatisch durch: bestehende 227 Importaufgaben, 68 Seiten sichtbar machen, 16 neue Seiten plus 48 Kategorien. Bereits ausgefuehrte Arbeiten werden anhand des gespeicherten Standes uebersprungen. Kein Google-Adressen-Block, keine kostenpflichtigen APIs, kein zweites Plugin. Bei wirklichem Konflikt stoppt der Auftrag mit erhaltenem Fortschritt.
WP-Live-Arbeit erfordert die ausdrueckliche Checkboxfreigabe im Admin. Nur ein Nutzer kann die Freigabe erteilen. Alte Versionen sind Archiv.
