<?php
if (!defined('ABSPATH')) { exit; }

/** One bounded, manual, idempotent CORE importer; no companion plugin. */
final class Robotik_First_Import {
    private const PLAN='assets/robotik-first-import-plan.json';
    private const PREVIEW='robotik_first_import_preview_v1';
    private const STATE='robotik_first_import_state_v1';
    private const META='_robotik_kategorie_node_id';
    private const BATCH=12;

    public static function boot():void {
        add_action('admin_menu',[self::class,'menu'],30);
        add_action('admin_post_robotik_first_preview',[self::class,'post_preview']);
        add_action('admin_post_robotik_first_start',[self::class,'post_start']);
        add_action('wp_ajax_robotik_first_tick',[self::class,'ajax_tick']);
    }
    public static function menu():void {
        add_submenu_page('robotik-kategorie','Robotik Erstimport','Erstimport','manage_options','robotik-erstimport',[self::class,'screen']);
    }
    private static function authorized():void {
        if (!current_user_can('manage_options')) wp_die('Administratorrechte erforderlich.');
    }
    public static function plan():array {
        $json=file_get_contents(dirname(__DIR__).'/'.self::PLAN);
        $plan=json_decode((string)$json,true);
        if (!is_array($plan)) throw new RuntimeException('Verbindliches Importprofil fehlt oder ist unlesbar.');
        $err=Robotik_Kategorie_Workflow::validate($plan);
        if ($err) throw new RuntimeException('Profil ungueltig: '.implode(' | ',$err));
        if (($plan['project']??'')!=='robotik'||($plan['phase']??'')!=='final')throw new RuntimeException('Falsches Projekt oder keine finale Planung.');
        return $plan;
    }
    private static function order(array $plan):array {
        $nodes=[];
        foreach($plan['nodes'] as $n)$nodes[$n['id']]=$n;
        $depth=[];
        $visit=function(string $id) use (&$visit,&$depth,$nodes):int {
            if (isset($depth[$id]))return $depth[$id];
            $p=$nodes[$id]['parent']??null;
            return $depth[$id]=$p===null?0:1+$visit($p);
        };
        $pages=[];$cats=[];
        foreach($nodes as $n){
            if($n['pillar']!=='core')continue;
            if($n['kind']==='page')$pages[]=$n;
            elseif($n['kind']==='content_category')$cats[]=$n;
        }
        usort($pages,static fn($a,$b)=>$visit($a['id'])<=>$visit($b['id'])?:strcmp($a['id'],$b['id']));
        usort($cats,static fn($a,$b)=>strcmp($a['id'],$b['id']));
        return array_merge($pages,$cats);
    }
    /** Single inspection of current WordPress state; no writes. */
    private static function category_title(array $n,array $nodes):string {
        $owner=(string)($n['parent']??'');
        if(!isset($nodes[$owner])||($nodes[$owner]['role']??'')!=='product')throw new RuntimeException('Keine eindeutige Produktseite fuer Kategorie.');
        // WP terms are flat. Repeating "Kaufberatung" in parent=0 causes a WP term_exists error.
        // Use two keyword units: product name + facet; retain the short visible facet as term meta.
        return trim((string)$nodes[$owner]['title'].' '.(string)$n['title']);
    }
    private static function inventory():array {
        $page_ids=get_posts(['post_type'=>'page','post_status'=>'any','posts_per_page'=>-1,'fields'=>'ids','suppress_filters'=>true]);
        if (!is_array($page_ids))throw new RuntimeException('Seitenbestand konnte nicht gelesen werden.');
        $pages=[];$slugs=[];
        foreach($page_ids as $pid){
            $p=get_post((int)$pid);
            if(!$p||$p->post_type!=='page')continue;
            $marker=(string)get_post_meta((int)$pid,self::META,true);
            if($marker!==''){
                if(isset($pages[$marker]))throw new RuntimeException('Mehrfach gebundene Seiten-ID: '.$marker);
                $pages[$marker]=(int)$pid;
            }
            if ($p->post_name!=='')$slugs[$p->post_name][]=[$marker,(int)$pid];
        }
        $terms=get_terms(['taxonomy'=>'category','hide_empty'=>false]);
        if (is_wp_error($terms)||!is_array($terms))throw new RuntimeException('WP-Kategorien konnten nicht gelesen werden.');
        $cats=[];$cat_slugs=[];
        foreach($terms as $t){
            $marker=(string)get_term_meta((int)$t->term_id,self::META,true);
            if($marker!==''){
                if(isset($cats[$marker]))throw new RuntimeException('Mehrfach gebundene Kategorie-ID: '.$marker);
                $cats[$marker]=(int)$t->term_id;
            }
            $cat_slugs[$t->slug]=[$marker,(int)$t->term_id];
        }
        return ['pages'=>$pages,'cats'=>$cats,'page_slugs'=>$slugs,'cat_slugs'=>$cat_slugs];
    }
    public static function preview():array {
        $plan=self::plan();$order=self::order($plan);$inventory=self::inventory();$errors=[];
        if(!taxonomy_exists('category'))$errors[]='WordPress-Standardkategorie fehlt.';
        $nodes=[];$counts=['create_pages'=>0,'unchanged_pages'=>0,'create_categories'=>0,'unchanged_categories'=>0];
        foreach($order as $n){
            $id=(string)$n['id'];$slug=(string)$n['slug'];$is_page=$n['kind']==='page';
            $owner= $is_page?($inventory['pages'][$id]??0):($inventory['cats'][$id]??0);
            if($owner){
                if($is_page){
                    $existing=get_post($owner);
                    if(!$existing||$existing->post_name!==$slug||$existing->post_title!==$n['title'])$errors[]="Bestehende Produktseite geaendert: $id";
                    if($existing && !in_array($existing->post_status,['draft','pending','private'],true))$errors[]="Bereits veroeffentlichte Seite vorhanden: $id";
                }else{
                    $existing=get_term($owner,'category');
                    $name=self::category_title($n,$nodes);
                    if(!$existing||is_wp_error($existing)||$existing->slug!==$slug||$existing->name!==$name)$errors[]="Bestehende Kategorie veraendert: $id";
                }
                $counts[$is_page?'unchanged_pages':'unchanged_categories']++;
            } else {
                if($is_page && isset($inventory['page_slugs'][$slug]))$errors[]="Seiten-Slug bereits vergeben: $slug";
                if(!$is_page && isset($inventory['cat_slugs'][$slug]))$errors[]="Kategorie-Slug bereits vergeben: $slug";
                $counts[$is_page?'create_pages':'create_categories']++;
            }
            $nodes[$id]=$n;
        }
        // Existing owners must be correctly attached; otherwise never silently remap.
        foreach($order as $n){
            $id=$n['id'];$owner=$n['parent']??null;
            if(!$owner)continue;
            if(!isset($nodes[$owner])){$errors[]="Unbekannter Elternknoten: $id";continue;}
            if($n['kind']==='page' && isset($inventory['pages'][$id],$inventory['pages'][$owner])){
                if((int)get_post($inventory['pages'][$id])->post_parent!==$inventory['pages'][$owner])$errors[]="Falsche bestehende Elternseite: $id";
            }
            if($n['kind']==='content_category' && isset($inventory['cats'][$id],$inventory['pages'][$owner])){
                $bound=(int)get_term_meta($inventory['cats'][$id],'_robotik_product_page_id',true);
                if($bound!==$inventory['pages'][$owner])$errors[]="Falsche Produkt-Zuordnung: $id";
            }
        }
        $data=['schema'=>'robotik-first-import-preview-v1','plan_sha256'=>hash('sha256',wp_json_encode($plan,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),'counts'=>$counts,'errors'=>array_values(array_unique($errors)),'checked_at'=>gmdate('c')];
        $data['token']=hash('sha256',wp_json_encode([$data['plan_sha256'],$inventory['pages'],$inventory['cats'],$inventory['page_slugs'],$inventory['cat_slugs']]));
        return $data;
    }
    private static function redirect():void {wp_safe_redirect(admin_url('admin.php?page=robotik-erstimport'));exit;}
    public static function post_preview():void {
        self::authorized();check_admin_referer('robotik_first_preview');
        try{$v=self::preview();update_option(self::PREVIEW,$v,false);}catch(Throwable $e){update_option(self::PREVIEW,['errors'=>[$e->getMessage()]],false);}
        self::redirect();
    }
    public static function post_start():void {
        self::authorized();check_admin_referer('robotik_first_start');
        if(empty($_POST['robotik_import_confirm']))wp_die('Bestaetigung fehlt.');
        $old=get_option(self::PREVIEW,[]);
        if(!is_array($old)||!empty($old['errors'])||empty($old['token']))wp_die('Kein fehlerfreier Importplan vorhanden.');
        $prior=get_option(self::STATE,[]);
        if(is_array($prior)&&in_array($prior['status']??'',['WRITING','READBACK'],true))wp_die('Import bereits aktiv.');
        try{$fresh=self::preview();}catch(Throwable $e){wp_die('Neue Vorschau erforderlich: '.$e->getMessage());}
        if($fresh['errors']||!hash_equals((string)$old['token'],(string)$fresh['token']))wp_die('Bestand seit Vorschau geaendert oder Konflikte. Neue Vorschau erforderlich.');
        $state=['status'=>'WRITING','plan_sha256'=>$fresh['plan_sha256'],'index'=>0,'total'=>count(self::order(self::plan())),'created_pages'=>0,'created_categories'=>0,'verified'=>0,'error'=>'','started'=>gmdate('c')];
        update_option(self::STATE,$state,false);self::redirect();
    }
    private static function existing(string $kind,string $id):int {
        $inv=self::inventory();return (int)($kind==='page'?($inv['pages'][$id]??0):($inv['cats'][$id]??0));
    }
    private static function create(array $n,array $maps,array $nodes):array {
        $id=(string)$n['id'];$parent=(string)($n['parent']??'');$slug=(string)$n['slug'];
        if($n['kind']==='page'){
            if(isset($maps['pages'][$id]))return ['existing', $maps['pages'][$id]];
            if(isset($maps['page_slugs'][$slug]))throw new RuntimeException('Seiten-Slug belegt: '.$slug);
            $par=0;
            if($parent!==''){
                $par=(int)($maps['pages'][$parent]??0);
                if(!$par)throw new RuntimeException('Elternseite fehlt: '.$id);
            }
            $pid=wp_insert_post(['post_type'=>'page','post_status'=>'draft','post_title'=>$n['title'],'post_name'=>$slug,'post_parent'=>$par,'post_content'=>''],true);
            if(is_wp_error($pid)||!$pid)throw new RuntimeException('WP-Seite konnte nicht angelegt werden: '.$slug);
            update_post_meta((int)$pid,self::META,$id);
            update_post_meta((int)$pid,'_robotik_page_role',(string)$n['role']);
            $saved=get_post((int)$pid);
            if(!$saved||$saved->post_name!==$slug||$saved->post_status!=='draft'||(int)$saved->post_parent!==$par)throw new RuntimeException('WordPress hat die Seite anders gespeichert: '.$slug);
            return ['page',(int)$pid];
        }
        if(isset($maps['cats'][$id]))return ['existing',$maps['cats'][$id]];
        if(isset($maps['cat_slugs'][$slug]))throw new RuntimeException('Kategorie-Slug belegt: '.$slug);
        $page_id=(int)($maps['pages'][$parent]??0);if(!$page_id)throw new RuntimeException('Produktseite fehlt: '.$id);
        $name=self::category_title($n,$nodes);
        $term=wp_insert_term($name,'category',['slug'=>$slug,'parent'=>0]);
        if(is_wp_error($term)||empty($term['term_id']))throw new RuntimeException('WP-Kategorie konnte nicht angelegt werden: '.$slug);
        $tid=(int)$term['term_id'];
        update_term_meta($tid,self::META,$id);
        update_term_meta($tid,'_robotik_short_label',(string)$n['title']);
        update_term_meta($tid,'_robotik_product_page_id',$page_id);
        update_term_meta($tid,'_robotik_article_directions',wp_json_encode($n['topic_directions']??[],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        $saved=get_term($tid,'category');
        if(!$saved||is_wp_error($saved)||$saved->slug!==$slug)throw new RuntimeException('WordPress hat die Kategorie anders gespeichert: '.$slug);
        return ['category',$tid];
    }
    public static function advance():array {
        $state=get_option(self::STATE,[]);
        if(!is_array($state)||($state['status']??'')!=='WRITING')return is_array($state)?$state:['status'=>'BLOCKED'];
        try{
            $plan=self::plan();$sha=hash('sha256',wp_json_encode($plan,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            if(!hash_equals((string)$state['plan_sha256'],$sha))throw new RuntimeException('Profil seit Start geaendert.');
            $order=self::order($plan);$until=min(count($order),(int)$state['index']+self::BATCH);
            $nodes=[];foreach($plan['nodes'] as $x)$nodes[$x['id']]=$x;
            $maps=self::inventory(); // once per batch, not 193 complete DB scans
            while((int)$state['index']<$until){
                $n=$order[(int)$state['index']];
                [$what,$newid]=self::create($n,$maps,$nodes);
                if($what==='page'){$state['created_pages']++;$maps['pages'][$n['id']]=$newid;$maps['page_slugs'][$n['slug']]=[[$n['id'],$newid]];}
                if($what==='category'){$state['created_categories']++;$maps['cats'][$n['id']]=$newid;$maps['cat_slugs'][$n['slug']]=[$n['id'],$newid];}
                $state['index']++;
                update_option(self::STATE,$state,false);
            }
            if((int)$state['index']===count($order)){
                $inv=self::inventory();$err=[];
                foreach($order as $n){
                    $id=$n['id'];
                    if($n['kind']==='page'){
                        $p=get_post((int)($inv['pages'][$id]??0));$par=(string)($n['parent']??'');$pid=$par===''?0:(int)($inv['pages'][$par]??0);
                        if(!$p||$p->post_title!==$n['title']||$p->post_name!==$n['slug']||$p->post_status!=='draft'||(int)$p->post_parent!==$pid)$err[]='Seitenreadback: '.$id;
                    }else{
                        $t=get_term((int)($inv['cats'][$id]??0),'category');
                        if(!$t||is_wp_error($t)||$t->slug!==$n['slug']||$t->name!==self::category_title($n,$nodes)||
                          (int)get_term_meta((int)$t->term_id,'_robotik_product_page_id',true)!==(int)($inv['pages'][$n['parent']]??0))$err[]='Kategorienreadback: '.$id;
                    }
                }
                if($err)throw new RuntimeException('Readback unvollstaendig: '.implode(', ',array_slice($err,0,5)));
                $state['verified']=count($order);$state['status']='COMPLETE';$state['completed']=gmdate('c');
                update_option(self::STATE,$state,false);
            }
        }catch(Throwable $e){$state['status']='BLOCKED';$state['error']=$e->getMessage();update_option(self::STATE,$state,false);}
        return $state;
    }
    public static function ajax_tick():void {
        self::authorized();check_ajax_referer('robotik_first_tick');
        $state=self::advance();wp_send_json_success(['status'=>$state['status']??'BLOCKED','index'=>$state['index']??0,'total'=>$state['total']??0,'error'=>$state['error']??'']);
    }
    public static function screen():void {
        self::authorized();$p=get_option(self::PREVIEW,[]);$s=get_option(self::STATE,[]);
        echo '<div class="wrap"><h1>Robotik – Erstimport</h1><p>Verbindlicher Gesamtbaum im Plugin enthalten. Kein Datei-Upload. Die Vorschau schreibt nichts. Der Import erstellt nur Entwurfsseiten und WordPress-Beitragskategorien; Magazin und HivePress bleiben unberuehrt.</p>';
        echo '<form action="'.esc_url(admin_url('admin-post.php')).'" method="post"><input type="hidden" name="action" value="robotik_first_preview">';wp_nonce_field('robotik_first_preview');submit_button('1. Gesamtbaum pruefen (ohne Aenderung)','secondary');echo '</form>';
        if(is_array($p)&&isset($p['counts'])){
            $c=$p['counts'];echo '<h2>Vorschau</h2><p>Seiten neu '.(int)$c['create_pages'].' / vorhanden '.(int)$c['unchanged_pages'].' · Beitragskategorien neu '.(int)$c['create_categories'].' / vorhanden '.(int)$c['unchanged_categories'].'.</p>';
            if(empty($p['errors'])&&($s['status']??'')!=='COMPLETE'&&($s['status']??'')!=='WRITING'){
                echo '<form action="'.esc_url(admin_url('admin-post.php')).'" method="post"><input type="hidden" name="action" value="robotik_first_start">';wp_nonce_field('robotik_first_start');echo '<label><input type="checkbox" name="robotik_import_confirm" value="1" required> Gesamtimport nach dieser Vorschau starten (Seiten nur Entwurf)</label>';submit_button('2. Geprueften Gesamtbaum einmal uebernehmen','primary');echo '</form>';
            }
        }
        if(!empty($p['errors']))echo '<div class="notice notice-error"><p>'.esc_html(implode(' | ',$p['errors'])).'</p></div>';
        if(is_array($s)&&isset($s['status'])){
            echo '<h2>Ergebnis</h2><p id="robotik-import-status">'.esc_html($s['status']).' · '.(int)($s['index']??0).' / '.(int)($s['total']??0).' · Seiten angelegt '.(int)($s['created_pages']??0).' · Kategorien angelegt '.(int)($s['created_categories']??0).'</p>';
            if(!empty($s['error']))echo '<div class="notice notice-error"><p>'.esc_html($s['error']).'</p></div>';
            if(($s['status']??'')==='COMPLETE')echo '<div class="notice notice-success"><p>104 Seiten und 89 Kategorien im WordPress-Readback vollstaendig geprueft.</p></div>';
            if(($s['status']??'')==='WRITING'){
                $nonce=wp_create_nonce('robotik_first_tick');
                echo '<script>(function(){var nonce='.wp_json_encode($nonce).';function tick(){var f=new FormData();f.append("action","robotik_first_tick");f.append("_ajax_nonce",nonce);fetch(ajaxurl,{method:"POST",credentials:"same-origin",body:f}).then(r=>r.json()).then(j=>{if(!j.success)throw Error("Server meldet Fehler");var s=j.data;document.getElementById("robotik-import-status").textContent=s.status+" · "+s.index+" / "+s.total+(s.error?" · "+s.error:"");if(s.status==="WRITING")tick();else location.reload();}).catch(e=>{document.getElementById("robotik-import-status").textContent="Unterbrochen: "+e.message+". Seite neu laden setzt gespeicherten Import fort.";});}tick();})();</script>';
            }
        }
        echo '<p>Es werden keine alten Inhalte geloescht, keine fremden Profile uebernommen und keine WordPress-Seiten veroeffentlicht. Bei Fehler: STOPP, zuerst pruefen.</p></div>';
    }
}
