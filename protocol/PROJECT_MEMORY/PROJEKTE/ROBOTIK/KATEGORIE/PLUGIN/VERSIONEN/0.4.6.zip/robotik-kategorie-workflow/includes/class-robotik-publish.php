<?php
if (!defined('ABSPATH')) { exit; }
/** Manual, bounded publication of only the 104 marker-bound robotik CORE pages. */
final class Robotik_Publish {
    private const IMPORT_STATE='robotik_first_import_state_v1';
    private const STATE='robotik_first_publish_state_v1';
    private const PREVIEW='robotik_first_publish_preview_v1';
    private const MARKER='_robotik_kategorie_node_id';
    private const BATCH=12;

    public static function boot():void {
        add_action('admin_menu',[self::class,'menu'],31);
        add_action('admin_post_robotik_publish_preview',[self::class,'post_preview']);
        add_action('admin_post_robotik_publish_start',[self::class,'post_start']);
        add_action('wp_ajax_robotik_publish_tick',[self::class,'ajax_tick']);
    }
    public static function menu():void {
        add_submenu_page('robotik-kategorie','Robotik-Seiten veröffentlichen','Veröffentlichung','manage_options','robotik-veroeffentlichen',[self::class,'screen']);
    }
    private static function require_admin():void {
        if (!current_user_can('manage_options')) wp_die('Administratorrechte erforderlich.');
    }
    /** This is derived from the exact installed import manifest, not a second page list. */
    private static function expected():array {
        $import=get_option(self::IMPORT_STATE,[]);
        if (!is_array($import)||($import['status']??'')!=='COMPLETE'||(int)($import['verified']??0)!==193)
            throw new RuntimeException('Erstimport nicht vollstaendig mit 193/193 geprueften Objekten abgeschlossen.');
        $plan=Robotik_First_Import::plan();
        $sha=hash('sha256',wp_json_encode($plan,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        if (empty($import['plan_sha256'])||!hash_equals((string)$import['plan_sha256'],$sha))
            throw new RuntimeException('Importprofil unterscheidet sich vom abgeschlossenen Erstimport.');
        $pages=[];
        foreach($plan['nodes'] as $n) if(($n['pillar']??'')==='core'&&($n['kind']??'')==='page')$pages[(string)$n['id']]=$n;
        if(count($pages)!==104)throw new RuntimeException('Unerwartete Anzahl Robotik-Seiten im verbindlichen Profil.');
        return [$pages,$sha];
    }
    public static function preview():array {
        [$pages,$sha]=self::expected();
        $all=get_posts(['post_type'=>'page','post_status'=>'any','posts_per_page'=>-1,'fields'=>'ids','suppress_filters'=>true]);
        if(!is_array($all))throw new RuntimeException('WordPress-Seitenbestand nicht lesbar.');
        $by_marker=[];
        foreach($all as $id) {
            $marker=(string)get_post_meta((int)$id,self::MARKER,true);
            if($marker==='')continue;
            if(isset($by_marker[$marker]))throw new RuntimeException('Doppelte Robotik-Markierung: '.$marker);
            $by_marker[$marker]=(int)$id;
        }
        $errors=[];$count=['draft'=>0,'publish'=>0];
        $ids=[];
        foreach($pages as $marker=>$n){
            $id=$by_marker[$marker]??0;
            $p=$id?get_post($id):null;
            if(!$p||$p->post_type!=='page'){$errors[]='Seite fehlt: '.$n['title'];continue;}
            $parent=(string)($n['parent']??'');$expected_parent=$parent===''?0:(int)($by_marker[$parent]??0);
            if($parent!==''&&$expected_parent===0)$errors[]='Elternseite fehlt: '.$n['title'];
            if((int)$p->post_parent!==$expected_parent||$p->post_name!==$n['slug']||$p->post_title!==$n['title']||
                (string)get_post_meta($id,'_robotik_page_role',true)!==(string)$n['role'])$errors[]='Seite/Elternrolle verändert: '.$n['title'];
            if(!in_array($p->post_status,['publish','draft'],true))$errors[]='Unerwarteter Status: '.$n['title'];
            else $count[$p->post_status]++;
            $ids[$marker]=$id;
        }
        // Do not touch any other pages, even when they use an old/foreign marker.
        $token=hash('sha256',wp_json_encode([$sha,$ids,$count,wp_hash(implode('|',array_keys($pages)))],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        return ['valid'=>!$errors,'errors'=>$errors,'counts'=>$count,'ids'=>$ids,'token'=>$token,'plan_sha256'=>$sha,'expected'=>count($pages),'checked_at'=>gmdate('c')];
    }
    private static function redirect():void {wp_safe_redirect(admin_url('admin.php?page=robotik-veroeffentlichen'));exit;}
    public static function post_preview():void {
        self::require_admin();check_admin_referer('robotik_publish_preview');
        try{update_option(self::PREVIEW,self::preview(),false);}catch(Throwable $e){update_option(self::PREVIEW,['valid'=>false,'errors'=>[$e->getMessage()]],false);}
        self::redirect();
    }
    public static function post_start():void {
        self::require_admin();check_admin_referer('robotik_publish_start');
        if(empty($_POST['robotik_publish_confirm']))wp_die('Freigabebestätigung fehlt.');
        $prev=get_option(self::PREVIEW,[]);
        if(!is_array($prev)||empty($prev['valid'])||empty($prev['token']))wp_die('Fehlerfreie Vorschau fehlt.');
        $old=get_option(self::STATE,[]);
        if(is_array($old)&&($old['status']??'')==='WRITING')wp_die('Veröffentlichung läuft bereits.');
        try{$fresh=self::preview();}catch(Throwable $e){wp_die('Neue Vorschau erforderlich: '.$e->getMessage());}
        if(empty($fresh['valid'])||!hash_equals((string)$prev['token'],(string)$fresh['token']))wp_die('Bestand seit Vorschau verändert. Neue Prüfung erforderlich.');
        $state=['status'=>'WRITING','index'=>0,'total'=>104,'published'=>0,'already_published'=>0,'verified'=>0,'error'=>'','ids'=>array_values($fresh['ids']),'token'=>$fresh['token'],'started_at'=>gmdate('c')];
        update_option(self::STATE,$state,false);
        self::redirect();
    }
    public static function advance():array {
        $state=get_option(self::STATE,[]);
        if(!is_array($state)||($state['status']??'')!=='WRITING')return is_array($state)?$state:['status'=>'BLOCKED'];
        try{
            // Fail closed if the original import was not finalized.
            self::expected();
            $ids=(array)($state['ids']??[]);
            if(count($ids)!==104)throw new RuntimeException('Veröffentlichungsplan unvollständig.');
            $expected_ids=array_values(self::preview()['ids']);
            if($expected_ids!==$ids)throw new RuntimeException('WordPress-Seitenbindung seit Freigabe verändert.');
            $until=min(104,(int)$state['index']+self::BATCH);
            while((int)$state['index']<$until){
                $id=(int)$ids[(int)$state['index']];$p=get_post($id);
                if(!$p||$p->post_type!=='page'||!in_array($p->post_status,['draft','publish'],true))throw new RuntimeException('Seite vor Veröffentlichung verändert: '.$id);
                if($p->post_status==='draft'){
                    $out=wp_update_post(['ID'=>$id,'post_status'=>'publish'],true);
                    if(is_wp_error($out)||(int)$out!==$id)throw new RuntimeException('Veröffentlichung fehlgeschlagen: '.$id);
                    $new=get_post($id);
                    if(!$new||$new->post_status!=='publish'||$new->post_name!==$p->post_name||(int)$new->post_parent!==(int)$p->post_parent)
                        throw new RuntimeException('WordPress Readback nach Veröffentlichung fehlgeschlagen: '.$id);
                    $state['published']++;
                }else $state['already_published']++;
                $state['index']++;
                update_option(self::STATE,$state,false);
            }
            if((int)$state['index']===104){
                $after=self::preview();
                if(empty($after['valid'])||(int)($after['counts']['publish']??0)!==104)throw new RuntimeException('Abschlussprüfung: Nicht alle 104 Robotik-Seiten sind veröffentlicht.');
                $state['verified']=104;$state['status']='COMPLETE';$state['completed_at']=gmdate('c');
                unset($state['ids'],$state['token']);update_option(self::STATE,$state,false);
            }
        }catch(Throwable $e){$state['status']='BLOCKED';$state['error']=$e->getMessage();update_option(self::STATE,$state,false);}
        return $state;
    }
    public static function ajax_tick():void {
        self::require_admin();check_ajax_referer('robotik_publish_tick');
        $s=self::advance();wp_send_json_success(['status'=>$s['status']??'BLOCKED','index'=>$s['index']??0,'total'=>$s['total']??0,'error'=>$s['error']??'']);
    }
    public static function screen():void {
        self::require_admin();$p=get_option(self::PREVIEW,[]);$s=get_option(self::STATE,[]);
        echo '<div class="wrap"><h1>Robotik – Sammelveröffentlichung</h1><p>Nur die 104 durch den abgeschlossenen Erstimport markierten Robotik-Seiten. Keine Beiträge, Kategorien, fremden Seiten oder neuen Inhalte.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="robotik_publish_preview">';wp_nonce_field('robotik_publish_preview');submit_button('1. Seiten prüfen (schreibfrei)','secondary');echo '</form>';
        if(!empty($p['errors']))echo '<div class="notice notice-error"><p>'.esc_html(implode(' | ',array_slice((array)$p['errors'],0,5))).'</p></div>';
        if(!empty($p['valid'])){
            echo '<p><strong>Vorschau:</strong> '.(int)$p['expected'].' Robotik-Seiten · '.(int)$p['counts']['draft'].' Entwürfe · '.(int)$p['counts']['publish'].' veröffentlicht.</p>';
            if(($s['status']??'')!=='WRITING'&&(int)$p['counts']['draft']>0){
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="robotik_publish_start">';wp_nonce_field('robotik_publish_start');
                echo '<label><input name="robotik_publish_confirm" type="checkbox" required value="1"> Die überprüften Robotik-Seiten gesammelt veröffentlichen.</label>';submit_button('2. Alle Robotik-Seiten veröffentlichen','primary');echo '</form>';
            }
        }
        if(isset($s['status'])){
            echo '<p id="robotik-publish-status">'.esc_html($s['status']).' · '.(int)($s['index']??0).' / '.(int)($s['total']??0).'</p>';
            if(!empty($s['error']))echo '<div class="notice notice-error"><p>'.esc_html($s['error']).'</p></div>';
            if(($s['status']??'')==='COMPLETE')echo '<div class="notice notice-success"><p>104 von 104 Robotik-Seiten veröffentlicht und kontrolliert.</p></div>';
            if(($s['status']??'')==='WRITING'){
                $nonce=wp_create_nonce('robotik_publish_tick');
                echo '<script>(function(){var nonce='.wp_json_encode($nonce).';function tick(){var f=new FormData();f.append("action","robotik_publish_tick");f.append("_ajax_nonce",nonce);fetch(ajaxurl,{method:"POST",credentials:"same-origin",body:f}).then(r=>r.json()).then(j=>{if(!j.success)throw Error("Serverantwort ungültig");var s=j.data;document.getElementById("robotik-publish-status").textContent=s.status+" · "+s.index+" / "+s.total+(s.error?" · "+s.error:"");if(s.status==="WRITING")tick();else location.reload();}).catch(e=>{document.getElementById("robotik-publish-status").textContent="Unterbrochen: "+e.message+". Seite neu laden, bevor weitere Schritte erfolgen.";});}tick();})();</script>';
            }
        }
        echo '</div>';
    }
}
