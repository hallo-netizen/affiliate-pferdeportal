<?php
/**
 * Nur-lesende Bestandsaufnahme, ohne eigene Tabellen, Cron oder externe API.
 * Schreibt keine WordPress-Beitraege, -Seiten, -Kategorien oder Inserate.
 */
if (!defined('ABSPATH')) { exit; }

final class Robotik_Kategorie_Inventory {
    private const BATCH = 200;
    private const MAX_PER_TYPE = 30000;
    private const STATUSES = ['publish', 'draft', 'pending', 'private', 'future'];

    private static function items(string $post_type): array {
        if (!post_type_exists($post_type)) {
            return ['state' => 'NOT_CONFIGURED', 'count' => 0, 'complete' => false, 'items' => [], 'notes' => []];
        }
        $records = []; $notes = []; $seen = [];
        for ($offset = 0; $offset < self::MAX_PER_TYPE; $offset += self::BATCH) {
            $batch = get_posts([
                'post_type' => $post_type,
                'post_status' => self::STATUSES,
                'posts_per_page' => self::BATCH,
                'offset' => $offset,
                'orderby' => 'ID',
                'order' => 'ASC',
                'suppress_filters' => true,
                'no_found_rows' => true,
                'update_post_meta_cache' => false,
            ]);
            if (!is_array($batch)) {
                $notes[] = 'Bestandsabfrage lieferte kein Array.';
                return ['state' => 'ERROR', 'count' => count($records), 'complete' => false, 'items' => $records, 'notes' => $notes];
            }
            foreach ($batch as $post) {
                if (!is_object($post) || !isset($post->ID)) { continue; }
                $id = (int) $post->ID;
                if (isset($seen[$id])) {
                    $notes[] = 'Doppeltes Objekt in Bestandsabfrage: ' . $id;
                    continue;
                }
                $seen[$id] = true;
                $row = [
                    'id' => $id,
                    'parent_id' => (int) ($post->post_parent ?? 0),
                    'title' => (string) ($post->post_title ?? ''),
                    'slug' => (string) ($post->post_name ?? ''),
                    'status' => (string) ($post->post_status ?? ''),
                    'type' => $post_type,
                ];
                if ($post_type === 'post' || $post_type === 'hp_listing') {
                    $tax = ($post_type === 'post') ? 'category' : 'hp_listing_category';
                    if (taxonomy_exists($tax)) {
                        $terms = get_the_terms($id, $tax);
                        if (is_wp_error($terms)) {
                            $row['term_ids'] = [];
                            $notes[] = 'Term-Zuordnung bei Objekt ' . $id . ' konnte nicht gelesen werden.';
                        } else {
                            $row['term_ids'] = is_array($terms) ? array_values(array_map(static fn($term): int => (int) $term->term_id, $terms)) : [];
                        }
                    } else {
                        $row['term_ids'] = null;
                    }
                }
                $records[] = $row;
            }
            if (count($batch) < self::BATCH) {
                return ['state' => 'READ', 'count' => count($records), 'complete' => true, 'items' => $records, 'notes' => $notes];
            }
        }
        $notes[] = 'Sicherheitsgrenze von ' . self::MAX_PER_TYPE . ' Objekten erreicht, Bestand kann unvollstaendig sein.';
        return ['state' => 'LIMIT_REACHED', 'count' => count($records), 'complete' => false, 'items' => $records, 'notes' => $notes];
    }

    private static function terms(string $taxonomy): array {
        if (!taxonomy_exists($taxonomy)) {
            return ['state' => 'NOT_CONFIGURED', 'count' => 0, 'complete' => false, 'items' => [], 'notes' => []];
        }
        $rows = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false]);
        if (is_wp_error($rows) || !is_array($rows)) {
            return ['state' => 'ERROR', 'count' => 0, 'complete' => false, 'items' => [], 'notes' => ['Taxonomie konnte nicht gelesen werden.']];
        }
        $items = [];
        foreach ($rows as $term) {
            if (!is_object($term) || !isset($term->term_id)) { continue; }
            $items[] = [
                'id' => (int) $term->term_id,
                'parent_id' => (int) ($term->parent ?? 0),
                'name' => (string) ($term->name ?? ''),
                'slug' => (string) ($term->slug ?? ''),
                'count' => (int) ($term->count ?? 0),
            ];
        }
        return ['state' => 'READ', 'count' => count($items), 'complete' => true, 'items' => $items, 'notes' => []];
    }

    private static function hierarchy_issues(array $data, string $label): array {
        $issues = [];
        if (empty($data['complete'])) { return $issues; }
        $ids = array_fill_keys(array_column($data['items'], 'id'), true);
        foreach ($data['items'] as $row) {
            if ($row['parent_id'] > 0 && !isset($ids[$row['parent_id']])) {
                $issues[] = [
                    'status' => 'REVIEW',
                    'area' => $label,
                    'item_id' => $row['id'],
                    'detail' => 'Elterneintrag nicht im eingelesenen Bestand (kann Entwurf/Papierkorb sein).',
                ];
            }
        }
        return $issues;
    }

    public static function collect(): array {
        $pages = self::items('page');
        $posts = self::items('post');
        $categories = self::terms('category');
        $listing_categories = self::terms('hp_listing_category');
        $listings = self::items('hp_listing');
        $all_taxes = get_taxonomies([], 'objects');
        $editorial_candidates = [];
        if (is_array($all_taxes)) {
            foreach ($all_taxes as $tax_name => $tax) {
                $label = (string) ($tax->label ?? '');
                if (preg_match('/magazin|magazine|journal|editorial|glossar/i', (string) $tax_name . ' ' . $label)) {
                    $editorial_candidates[] = ['taxonomy' => (string) $tax_name, 'label' => $label, 'state' => 'DISCOVERED_NOT_CONFIRMED'];
                }
            }
        }
        $issues = array_merge(
            self::hierarchy_issues($pages, 'WP_SEITEN'),
            self::hierarchy_issues($categories, 'WP_KATEGORIEN'),
            self::hierarchy_issues($listing_categories, 'HIVEPRESS_KATEGORIEN')
        );
        $uncategorized = 0;
        if ($posts['complete'] && $categories['complete']) {
            foreach ($posts['items'] as $post) {
                if (isset($post['term_ids']) && is_array($post['term_ids']) && count($post['term_ids']) === 0) { $uncategorized++; }
            }
            if ($uncategorized) {
                $issues[] = ['status' => 'REVIEW', 'area' => 'WP_BEITRAEGE', 'detail' => $uncategorized . ' Beitraege ohne gelesene WordPress-Kategorie.'];
            }
        }
        return [
            'schema' => 'robotik-wp-inventory-v1',
            'plugin_version' => Robotik_Kategorie_Workflow::VERSION,
            'site_url' => home_url('/'),
            'created_utc' => gmdate('c'),
            'mode' => 'READ_ONLY_INVENTORY',
            'no_semantic_or_keyword_audit' => true,
            'pages' => $pages,
            'posts' => $posts,
            'categories' => $categories,
            'hivepress_listing_categories' => $listing_categories,
            'hivepress_listings' => $listings,
            'editorial_taxonomy_candidates' => $editorial_candidates,
            'editorial_status' => 'NOT_MAPPED',
            'affiliate_advertisement_status' => 'NOT_CONNECTED',
            'research_master_status' => 'NOT_CONNECTED',
            'keyword_research_status' => 'NOT_CONNECTED',
            'frontend_navigation_status' => 'NOT_CHECKED',
            'issues' => $issues,
        ];
    }

    public static function show(array $report): void {
        echo '<h2>Gesamtbestand (nur lesend)</h2>';
        echo '<p>Dies ist eine Bestandsaufnahme, keine inhaltliche Gesamtabnahme. Keine Seiten, Kategorien, Artikel oder Inserate werden angelegt oder veraendert.</p>';
        echo '<table class="widefat striped"><thead><tr><th>Bereich</th><th>Gefunden</th><th>Lesestatus</th></tr></thead><tbody>';
        $labels = [
            'pages' => 'WordPress-Seiten',
            'categories' => 'WordPress-Kategorien',
            'posts' => 'WordPress-Beitraege',
            'hivepress_listing_categories' => 'HivePress-Kategorien',
            'hivepress_listings' => 'HivePress-Inserate',
        ];
        foreach ($labels as $key => $label) {
            $set = $report[$key];
            echo '<tr><th>' . esc_html($label) . '</th><td>' . esc_html((string) $set['count']) . '</td><td>' . esc_html($set['state']) . '</td></tr>';
        }
        echo '</tbody></table>';
        echo '<p><strong>Magazin:</strong> ' . esc_html($report['editorial_status']) . '; erkannte moegliche Magazin-Taxonomien: ' . esc_html((string) count($report['editorial_taxonomy_candidates'])) . '. '; 
        echo '<strong>Werbeanzeigen/Affiliate:</strong> ' . esc_html($report['affiliate_advertisement_status']) . '. ';
        echo '<strong>GitHub-Fachmaster:</strong> ' . esc_html($report['research_master_status']) . '.</p>';
        echo '<p><strong>Pruefhinweise:</strong> ' . esc_html((string) count($report['issues'])) . '. '; 
        echo 'Weitere fachliche Pruefungen (Themenluecken, Randthemen, Dopplungen, Keywords, Frontend) sind NOCH NICHT ANGEBUNDEN.</p>';
        $n = 0;
        foreach ($report['issues'] as $issue) {
            if ($n++ >= 20) { break; }
            echo '<p>' . esc_html((string) ($issue['area'] ?? '')) . ': ' . esc_html((string) ($issue['detail'] ?? '')) . '</p>';
        }
        foreach (['pages','posts','categories','hivepress_listing_categories','hivepress_listings'] as $key) {
            foreach ($report[$key]['notes'] as $note) { echo '<p><strong>' . esc_html($key) . ':</strong> ' . esc_html($note) . '</p>'; }
        }
    }
}
