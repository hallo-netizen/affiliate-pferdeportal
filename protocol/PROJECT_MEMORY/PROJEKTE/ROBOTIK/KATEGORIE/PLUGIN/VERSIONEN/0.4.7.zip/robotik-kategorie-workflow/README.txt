Robotik Kategorie-Workflow 0.4.7 – EIN bestehendes Plugin, ersetzt 0.4.3 ohne Zweitinstallation.

Erhalten: bisheriger JSON-Kategorieentwurf, Bestandsaufnahme, Erstimport und Sammelveröffentlichung.
Neu: Robotik Kategorie > DataForSEO.
- API-Zugang einmal speichern und in demselben Schritt kostenlos Verbindung und Keyword-Vorschau prüfen.
- Alternativ kostenlosen Verbindungstest oder lokalen Sammel-Preflight erneut ausführen.
- Historischer 0.4.2-SEO-Bestand: 72 Produktnamen und 89 Rubriken aus dem Erstimportprofil. In 0.4.3 durch den separaten V52-SEO-Fachentwurf ersetzt; der 104er Erstimportplan selbst bleibt byteunveraendert.
- Google DataForSEO Keywords Overview, Keyword Ideas, Keyword Suggestions (Germany/de), ausschließlich manuelle kostenpflichtige Anfragen mit Checkbox, pro Klick höchstens ein API-Aufruf.
- Keine automatischen Bezahlaufrufe, keine Hintergrundläufe, keine Seiten-/Kategorien-Änderungen; keine Übernahme fremder Portal-Logins.
- Letzte Antwort als JSON exportieren, inklusive Kosten und verknüpften Produkt-IDs für exakte Ergebnisse.

Nachweisgrenzen: PHP-Lint und WordPress-Mocktests lokal bestanden. Ein echter Login/Provider-Live-Test ist erst nach Zugangseingabe auf der WordPress-Seite möglich.

V0.4.3 – Nur SEO-Sammelpruefplan auf V52 angehoben:
- Robotik Kategorie > DataForSEO: 141 vorlaeufige Robotertypen und 296 Rubrikvorschlaege, 16 fachliche HOLDs.
- KEIN WordPress-Seiten-/Kategorie-Import aus diesem neuen Fachentwurf.
- Der bisherige Erstimport (104 Seiten/89 WP-Kategorien) und die Sammelveroeffentlichung bleiben als Originalcode UNVERAENDERT.
- Keine Hintergrundaufrufe, keine neuen API-Gebuehren ohne manuellen Freigabeklick.
- Vor dem alten Erstimport den Gesamtplan gesondert pruefen; er enthaelt nicht V52.
- Bestehende Zugangsdaten, Berichte und gespeicherte Entwuerfe bleiben unangetastet.

Version 0.4.5 – V57 gebuendelte SEO-Gesamtrecherche im selben Plugin:
- Ein Kostenklick mit ausdruecklichem USD-Maximalbudget; eine automatisch vom geoeffneten WP-Backend abgearbeitete Auftragsliste (ohne Cron, ohne parallele WordPress-Schreibvorgaenge).
- 437 bestehende Keyword-Owner im Overview; acht einzelne Welt-Suchideen-Laeufe (alle 141 Produkttyp-Keywords als Ausgangspunkte, maximal 300 Ideen pro Hauptwelt).
- 16 geschuetzte SEO-HOLD-Faelle vergleichen ihre Google-Top-10-URLs mit fachlich passenden Vergleichsbegriffen; das ist Evidenz, keine automatische Kategoriefreigabe.
- Ein Gesamt-JSON mit gemessenen/nicht gemessenen Keywords, ungeprueften Suchideen, Anbieter-Kosten je Teilschritt und den Konflikt-Indizien.
- Keine automatische Wiederholung bei moeglicher Anbietergebuehr. Kein Import-/Publikationsprofil geaendert, keine Seiten oder Kategorien automatisch angelegt, keine URL veraendert.
- Vorherige Einzelabfragen bleiben aus Kompatibilitaet in einklappbarer Altsektion erhalten. V52-Forschungsgrundlagen und alter Erstimport sind unveraendert.

Version 0.4.5 (V58): Ausschliesslich manuelle, einmalige Wiederaufnahme eines BLOCKED_UNCERTAIN-0/38-Laufs nach nachgewiesenem DataForSEO-HTTP-50000 mit ausdruecklicher Zusatzkostenfreigabe. Kein Reset, keine neue Recherche und keine Aenderung des Import- oder SEO-Fachplans.

V0.4.6 – Fortsetzung des vorhandenen 3/38-Laufs: Bei gemeldetem Anbieter-HTTP500 keine Wiederholung der gescheiterten kostenpflichtigen Anfrage. Nach einer ausdruecklichen neuen Freigabe weiter mit den noch offenen Aufgaben im alten Budget; fehlende Keyword-Ideen als NICHT GEPRUEFT markieren. Weitere echte Anbieter-500er ebenfalls nicht erneut starten; Bericht kann als COMPLETE_WITH_GAPS enden. Kein Import-/Publikationsumbau.

V0.4.7 – V60: Fehler 40101 (Internal SE Server Error) als Anbieter-/Suchmaschinenfehler behandelt, ebenso 50000 und HTTP500. Die gesicherte BLOCKED_UNCERTAIN-Stelle 9/38 wird mitsamt 8 erfolgreichen und 1 bereits uebersprungenen Aufgabe ueber EINEN Admin-Klick mit unveraendertem Budget fortgesetzt. Fehlgeschlagene Schritte werden nicht erneut gesendet. Nachfolgende belegte Serverfehler werden automatisch uebersprungen und als Datenluecken markiert; Eingabefehler und unbekannte Antwortfehler bleiben blockiert. Alter WordPress-Importer, Seiten und Publisher unberuehrt.
