<?php
/** Minimal visual test for the Robotik homepage. Does not alter pages or menus in WordPress. */
if (!defined('ABSPATH')) { exit; }
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robotik-design-version" content="0.2.3">
<?php wp_head(); ?>
</head>
<body <?php body_class('rtd-preview-home'); ?>>
<?php
if (function_exists('wp_body_open')) wp_body_open();
Robotik_Strukturdesign::header();
?>
<main class="rtd-preview-stage" id="rtd-preview-stage" aria-label="Bereich für zukünftige Inhalte"></main>
<?php Robotik_Strukturdesign::footer(); wp_footer(); ?>
</body>
</html>
