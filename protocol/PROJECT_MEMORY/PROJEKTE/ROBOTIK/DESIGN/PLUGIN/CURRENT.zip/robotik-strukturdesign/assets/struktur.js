(function(){
  'use strict';
  function ready(){
    var head=document.getElementById('robotik-strukturkopf');
    var foot=document.getElementById('robotik-strukturfuss');
    if(!head||!foot||!document.body)return;
    document.body.insertBefore(head,document.body.firstChild);
    document.body.appendChild(foot);
    document.body.classList.add('rtd-mounted');
    var toggle=head.querySelector('.rtd-mobile-toggle');
    var sections=Array.prototype.slice.call(head.querySelectorAll('.rtd-section'));
    function hoverMode(){return window.matchMedia('(min-width:781px) and (hover:hover) and (pointer:fine)').matches;}
    function closeOthers(selected){sections.forEach(function(other){if(other!==selected){other.open=false;other.removeAttribute('data-pinned');}});}
    function closeAll(){sections.forEach(function(item){item.open=false;item.removeAttribute('data-pinned');});}
    if(toggle){toggle.addEventListener('click',function(){
      var open=head.classList.toggle('rtd-mobile-open');toggle.setAttribute('aria-expanded',open?'true':'false');
      if(!open)closeAll();
    });}
    sections.forEach(function(item){
      var summary=item.querySelector('summary');
      item.addEventListener('mouseenter',function(){
        if(!hoverMode())return;
        closeOthers(item);item.open=true; // details content is hidden by browsers unless open=true
      });
      item.addEventListener('mouseleave',function(){
        if(hoverMode()&&!item.hasAttribute('data-pinned'))item.open=false;
      });
      if(summary)summary.addEventListener('click',function(event){
        if(!hoverMode())return; // native <details> click for mobile / keyboard-only devices
        event.preventDefault();
        var pinned=item.getAttribute('data-pinned')==='true';
        closeOthers(item);
        if(pinned){item.removeAttribute('data-pinned');item.open=false;}
        else{item.setAttribute('data-pinned','true');item.open=true;}
      });
      item.addEventListener('toggle',function(){if(item.open)closeOthers(item);});
    });
    document.addEventListener('keydown',function(event){if(event.key!=='Escape')return;
      closeAll();head.classList.remove('rtd-mobile-open');
      if(toggle)toggle.setAttribute('aria-expanded','false');
    });
    document.addEventListener('click',function(event){if(head.contains(event.target))return;closeAll();});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);else ready();
})();
