Robotik Strukturdesign 0.2.2 – minimaler Header/Footer-Test, nur WordPress-Startseite.

Änderung gegenüber 0.2.0: Keine Theme-Startseite und keine Theme-Seitenspalten auf der Startseite mehr. Das Plugin gibt dort einen einfachen, vollständigen HTML-Rahmen mit echter WordPress-Kategorienavigation und Footer aus. Auf anderen Seiten bleibt das Theme erhalten. Kein Foto, keine Farben, keine künstlichen Produktlinks, keine Datenänderungen.

- Eine Kopfzeile mit ROBOTIK plus sieben Hauptkategorien; Mega-Menü bei Klick oder Mausberührung (Desktop) bzw. Touch (Mobil).
- Industrie in Gewerbe sichtbar abgesetzt, echte Subkategorien/Produktseiten aus importierten WordPress-Seiten.
- Ein echter Footer am Seitenende mit sieben Rubriken sowie nur vorhandenen echten Seiten für Nebenbereiche und Rechtstexte.
- Keine neue Pluginidentität: aktualisiert 'robotik-strukturdesign'. Das Kategorie-Plugin bleibt unangetastet.
- Scope: WordPress-Startseite. Auf den übrigen WordPress-Seiten bleibt das bisherige Theme unverändert.
- Nur lokale funktionale/visuelle Tests, keine unabhängige Live-WordPress-Abnahme.

0.2.2: Haerter WordPress-Startseitenweg template_redirect mit exakt abgegrenzter Root-URL; faellt nicht auf Theme-Bloglisten zurueck. Sichtbare Version im Footer; keine Kategorie/SEO-Aenderungen.

0.2.3: Strict home_url-Pfad-Abgleich repariert; öffentliche Root / und echte WP-Frontpage, selbst bei WP-Subdirectory/Reverse-Proxy. Vorrangige Route, keine Kategorie-/DataForSEO-Änderung.

Footer bewusst vereinfacht: keine zweite Kopie des Hauptkategoriebaums unten. Sieben Hauptkategorien NUR oben als Mega-Menü, unten kompakter Fußbereich für Magazin/Glossar/Roboterfinder/Anzeigenmarkt/Rechtliches.

0.2.4: Acht Welten, nur veroeffentlichte Links, nach Hoehe ausgeglichene Menuespalten, direkte Produktseiten als gemeinsame optische Liste, auch tiefe Industrie-Landingpages verlinkt; Beitragskategorien nur auf der passenden letzten Produktseite. Keine WP-Daten veraendert.

0.2.5: Der nachgewiesene Blanko-Menuefehler in 0.2.4 wurde zentral behoben: Admin sieht auch noch unveroeffentlichte importierte Robotikseiten mit WP-Vorschau-Links; normale Besucher ausschliesslich bereits veroeffentlichte Seiten. Die optische 8-Welten-Gruppierung und alle bisherigen Funktionen bleiben erhalten. 0.2.5 veraendert keine WP-Post-Status, keine Kategorien, keine URLs.
