Footer-Umzug – Robotik (Inhalte), Version 1.2.1

Diese isolierte Robotik-Fassung uebernimmt nur Footer-Seiten und ihren Inhalt sowie Footer-Menues.
Sie uebernimmt weder Layout noch Farben oder Theme-Design.
Sie aktualisiert oder loescht KEINE bestehenden Seiten oder Menues. Alle neu importierten
Seiten werden als ENTWURF angelegt und muessen vor Veroeffentlichung auf Markennamen,
Inhalte, Impressum, Datenschutz und Links geprueft werden.

Die bestehende 1.1.1 auf Pferdeatelier/Hobbydepot kann UNVERAENDERT bleiben.
Ihr JSON-Export kann in Robotik 1.2.1 in die Vorschau geladen werden.
Auch ein Export aus derselben 1.2.1 ist kompatibel.
Die Originale in Hobbydepot/Hab & Bewahr bleiben unangetastet. Das Plugin erzeugt
keine zusaetzliche WordPress-Tabelle und aendert keinen Core-Code.

WordPress -> Plugins -> Installieren -> Plugin hochladen
WordPress -> Werkzeuge -> Footer-Umzug
Auf Quelle exportieren. Auf Robotik die eine JSON-Datei hochladen, Vorschau ansehen,
explizit bestaetigen. Danach Entwuerfe redaktionell pruefen und selbst freigeben.

Sicherheit: nur Administratoren, Nonces, zweistufiger Import, keine Ueberschreibung,
Import nur einmal pro Vorschau, keine automatischen Fremd-Domain-Menue-Links,
keine ungeprueften Rechtstexte veroeffentlichen.
