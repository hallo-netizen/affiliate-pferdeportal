<?php
/**
 * Plugin Name: Footer-Umzug – Robotik (Inhalte)
 * Description: Footer-Seiten und Menues aus einer JSON-Datei uebertragen. Erst Vorschau, dann bewusste Freigabe. Ohne Design und ohne Ueberschreiben.
 * Version: 1.2.1
 * Author: OpenAI
 * Text Domain: robotik-footer-umzug
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Robotik_Footer_Umzug_Safe {
    const VERSION = '1.2.1';
    const SCHEMA = 'robotik_footer_transfer_v1';
    const MAX_BYTES = 4194304;

    public static function boot() {
        add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
        add_action( 'admin_post_robotik_footer_export', array( __CLASS__, 'export' ) );
        add_action( 'admin_post_robotik_footer_preview', array( __CLASS__, 'preview' ) );
        add_action( 'admin_post_robotik_footer_import', array( __CLASS__, 'import' ) );
    }
    public static function menu() {
        add_management_page( 'Footer-Umzug', 'Footer-Umzug', 'manage_options', 'robotik-footer-umzug', array( __CLASS__, 'admin_page' ) );
    }
    private static function gate( $action ) {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Keine Berechtigung.' ); }
        check_admin_referer( $action );
    }
    private static function key() { return 'robotik_footer_review_' . get_current_user_id(); }
    private static function go( $status ) { wp_safe_redirect( add_query_arg( array( 'page' => 'robotik-footer-umzug', 'status' => $status ), admin_url( 'tools.php' ) ) ); exit; }
    private static function is_footer( $name ) { return false !== stripos( (string) $name, 'footer' ) || false !== stripos( (string) $name, 'fuß' ) || false !== stripos( (string) $name, 'fuss' ); }
    private static function is_legal( $slug ) { return (bool) preg_match( '/(^|[-_])(datenschutz|impressum|agb|cookie|cookies|widerruf|rechtliches|werbung|werbekennzeichnung|haftung|privacy)([-_]|$)/i', (string) $slug ); }

    public static function admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $preview = get_transient( self::key() );
        echo '<div class="wrap"><h1>Footer-Umzug – nur Seiten und Inhalte</h1>';
        echo '<p>Keine Designuebertragung. Kein automatisches Ueberschreiben vorhandener Seiten. Rechtstexte werden ausschliesslich als Entwuerfe angelegt.</p>';
        if ( isset( $_GET['status'] ) ) { echo '<div class="notice notice-info"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['status'] ) ) ) . '</p></div>'; }
        echo '<h2>1. Auf der Quellseite: Footer exportieren</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="robotik_footer_export">';
        wp_nonce_field( 'robotik_footer_export' );
        submit_button( 'Eine Footer-JSON-Datei exportieren', 'secondary' ); echo '</form>';
        echo '<h2>2. Auf der Robotik-Seite: Datei pruefen</h2><form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        echo '<input type="hidden" name="action" value="robotik_footer_preview">'; wp_nonce_field( 'robotik_footer_preview' );
        echo '<input type="file" name="footer_json" accept=".json,application/json" required> ';
        submit_button( 'Nur Vorschau – noch nichts importieren', 'primary', 'submit', false ); echo '</form>';
        if ( is_array( $preview ) && isset( $preview['data'] ) ) {
            $data = $preview['data'];
            echo '<h2>3. Gepruefte Vorschau</h2><p><strong>Quelle: </strong>' . esc_html( $data['source'] ) . '</p>';
            echo '<table class="widefat striped"><thead><tr><th>Seite</th><th>Slug</th><th>Geplante Aktion</th></tr></thead><tbody>';
            foreach ( $data['pages'] as $p ) {
                $existing = get_page_by_path( $p['slug'], OBJECT, 'page' );
                $action = $existing ? 'Schon vorhanden – unveraendert lassen' : ( self::is_legal( $p['slug'] ) ? 'Neu als Entwurf (Rechtstext)' : 'Neu als Entwurf' );
                echo '<tr><td>' . esc_html( $p['title'] ) . '</td><td>' . esc_html( $p['slug'] ) . '</td><td>' . esc_html( $action ) . '</td></tr>';
            }
            echo '</tbody></table>';
            echo '<p>Footer-Menues: ' . esc_html( count( $data['menus'] ) ) . '. Menuepositionen werden nur bei vorhandenem passenden Footer-Platz zugewiesen; bestehende Zuweisungen nicht ueberschrieben.</p>';
            if ( self::mentions_older_portals( $data ) ) { echo '<div class="notice notice-warning inline"><p>Die Vorlage enthaelt Bezeichnungen oder Domains anderer Portale. Inhalte sind vor jeder Veroeffentlichung manuell fuer Robotik zu pruefen.</p></div>'; }
            echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
            echo '<input type="hidden" name="action" value="robotik_footer_import">';
            echo '<input type="hidden" name="proof" value="' . esc_attr( $preview['proof'] ) . '">';
            wp_nonce_field( 'robotik_footer_import' );
            echo '<p><label><input type="checkbox" name="confirm" value="yes" required> Ich habe die Vorschau geprueft. Neue Seiten werden nur als Entwurf angelegt, bestehende Seiten nicht geaendert.</label></p>';
            submit_button( 'Nur neue Entwuerfe und Footer-Menue-Eintraege uebernehmen', 'primary' );
            echo '</form>';
        }
        echo '</div>';
    }
    private static function mentions_older_portals( $data ) {
        $s = wp_json_encode( $data );
        return (bool) preg_match( '/pferde-atelier|pferdeatelier|hobbydepot|hab\s*(?:&|und)\s*bewahr|hobbyrausch/i', $s );
    }
    private static function menus_from_wp() {
        $locations = get_nav_menu_locations();
        $found = array();
        foreach ( wp_get_nav_menus() as $menu ) {
            $matched = self::is_footer( $menu->name ) || self::is_footer( $menu->slug );
            foreach ( $locations as $loc => $mid ) { if ( (int) $mid === (int) $menu->term_id && self::is_footer( $loc ) ) { $matched = true; } }
            if ( ! $matched ) { continue; }
            $items = array();
            $raw = wp_get_nav_menu_items( $menu->term_id );
            if ( is_array( $raw ) ) { foreach ( $raw as $item ) {
                $ref_page = ( 'post_type' === $item->type && 'page' === $item->object ) ? get_post( (int) $item->object_id ) : null;
                $items[] = array( 'page_slug' => ( $ref_page && 'page' === $ref_page->post_type ) ? $ref_page->post_name : '',
                    'old_id' => (int) $item->ID, 'old_parent' => (int) $item->menu_item_parent,
                    'title' => (string) $item->title, 'type' => (string) $item->type,
                    'object' => (string) $item->object, 'object_id' => (int) $item->object_id,
                    'url' => (string) $item->url, 'target' => (string) $item->target );
            } }
            $use_locations = array();
            foreach ( $locations as $loc => $mid ) { if ( (int) $mid === (int) $menu->term_id && self::is_footer( $loc ) ) { $use_locations[] = $loc; } }
            $found[] = array( 'name' => $menu->name, 'slug' => $menu->slug, 'locations' => $use_locations, 'items' => $items );
        }
        return $found;
    }
    public static function export() {
        self::gate( 'robotik_footer_export' );
        $menus = self::menus_from_wp(); $pages = array();
        foreach ( $menus as $menu ) { foreach ( $menu['items'] as $item ) {
            if ( 'post_type' !== $item['type'] || 'page' !== $item['object'] ) { continue; }
            $p = get_post( $item['object_id'] );
            if ( ! $p || 'page' !== $p->post_type ) { continue; }
            $pages[ $p->post_name ] = array( 'slug' => $p->post_name, 'title' => $p->post_title,
                'content' => $p->post_content, 'excerpt' => $p->post_excerpt, 'status' => $p->post_status );
        } }
        $data = array( 'schema' => self::SCHEMA, 'source' => home_url( '/' ), 'exported_at' => gmdate( 'c' ),
            'pages' => array_values( $pages ), 'menus' => $menus );
        $json = wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        if ( ! $json ) { wp_die( 'JSON konnte nicht erstellt werden.' ); }
        nocache_headers(); header( 'Content-Type: application/json; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="footer-seiten-' . gmdate( 'Ymd' ) . '.json"' );
        echo $json; exit;
    }
    private static function normalize_legacy( $old ) {
        // Actual 1.1.1 exporter uses associative maps: pages[source_post_id], menus[source_menu_id],
        // items with id/parent; footer_locations maps theme slot to menu ID.
        if ( empty( $old['format'] ) || ! isset( $old['source_url'], $old['pages'], $old['menus'] ) ||
             ! is_array( $old['pages'] ) || ! is_array( $old['menus'] ) ) { return null; }
        $pages = array(); $by_id = array();
        foreach ( $old['pages'] as $source_id => $p ) {
            if ( ! is_array( $p ) || empty( $p['title'] ) ) { continue; }
            $slug = sanitize_title( $p['slug'] ?? $p['title'] );
            if ( ! $slug ) { continue; }
            $pages[] = array( 'slug' => $slug, 'title' => (string) $p['title'],
                'content' => (string) ( $p['content'] ?? '' ), 'excerpt' => (string) ( $p['excerpt'] ?? '' ) );
            $by_id[ (string) ( $p['id'] ?? $source_id ) ] = $slug;
        }
        $menus = array();
        $locations = is_array( $old['footer_locations'] ?? null ) ? $old['footer_locations'] : array();
        foreach ( $old['menus'] as $source_id => $m ) {
            if ( ! is_array( $m ) ) { continue; }
            $items = array();
            foreach ( $m['items'] ?? array() as $item ) {
                if ( ! is_array( $item ) ) { continue; }
                $item['old_id'] = $item['id'] ?? 0;
                $item['old_parent'] = $item['parent'] ?? 0;
                $item['page_slug'] = ( ( $item['type'] ?? '' ) === 'post_type' && ( $item['object'] ?? '' ) === 'page' )
                    ? ( $by_id[ (string) ( $item['object_id'] ?? '' ) ] ?? '' ) : '';
                $items[] = $item;
            }
            $menu_id = (string) ( $m['id'] ?? $source_id );
            $m_locations = array();
            foreach ( $locations as $location => $id ) {
                if ( (string) $id === $menu_id && self::is_footer( $location ) ) { $m_locations[] = $location; }
            }
            $menus[] = array( 'name' => (string) ( $m['name'] ?? 'Footer' ), 'slug' => (string) ( $m['slug'] ?? sanitize_title( $m['name'] ?? 'Footer' ) ),
                'locations' => $m_locations, 'items' => $items );
        }
        return array( 'schema' => self::SCHEMA, 'source' => (string) $old['source_url'],
            'pages' => $pages, 'menus' => $menus );
    }
    private static function sanitize_data( $data ) {
        if ( is_array( $data ) && ! isset( $data['schema'] ) && isset( $data['format'] ) ) { $data = self::normalize_legacy( $data ); }
        if ( ! is_array( $data ) || ! isset( $data['schema'] ) || self::SCHEMA !== $data['schema'] ) { return new WP_Error( 'schema', 'Unbekanntes Exportformat. Bitte einen Footer-Umzug-Export 1.1.1 oder 1.2.1 verwenden.' ); }
        if ( empty( $data['pages'] ) || ! is_array( $data['pages'] ) || empty( $data['menus'] ) || ! is_array( $data['menus'] ) ) { return new WP_Error( 'empty', 'Keine verknuepften Footer-Seiten oder Menues enthalten.' ); }
        if ( count( $data['pages'] ) > 300 || count( $data['menus'] ) > 30 ) { return new WP_Error( 'many', 'Zu viele Seiten oder Menues.' ); }
        $clean = array( 'source' => esc_url_raw( $data['source'] ?? '' ), 'pages' => array(), 'menus' => array() );
        foreach ( $data['pages'] as $p ) {
            if ( ! is_array( $p ) || ! isset( $p['slug'], $p['title'], $p['content'] ) ) { return new WP_Error( 'pages', 'Fehlerhafter Seiten-Eintrag.' ); }
            $slug = sanitize_title( $p['slug'] );
            if ( ! $slug || strlen( $slug ) > 150 ) { return new WP_Error( 'slug', 'Ungueltiger Seitenslug.' ); }
            $clean['pages'][ $slug ] = array( 'slug' => $slug, 'title' => sanitize_text_field( $p['title'] ),
                'content' => wp_kses_post( (string) $p['content'] ), 'excerpt' => sanitize_textarea_field( $p['excerpt'] ?? '' ) );
        }
        if ( count( $clean['pages'] ) > 300 ) { return new WP_Error( 'pages', 'Seitenlimit ueberschritten.' ); }
        foreach ( $data['menus'] as $menu ) {
            if ( ! is_array( $menu ) || ! isset( $menu['name'], $menu['items'] ) || ! is_array( $menu['items'] ) || count( $menu['items'] ) > 500 ) { return new WP_Error( 'menu', 'Fehlerhafter Menue-Eintrag.' ); }
            $items = array();
            foreach ( $menu['items'] as $item ) {
                if ( ! is_array( $item ) || ! isset( $item['old_id'], $item['title'], $item['type'] ) ) { return new WP_Error( 'item', 'Fehlerhafter Menuepunkt.' ); }
                $items[] = array( 'page_slug' => sanitize_title( $item['page_slug'] ?? '' ),
                    'old_id' => absint( $item['old_id'] ), 'old_parent' => absint( $item['old_parent'] ?? 0 ),
                    'title' => sanitize_text_field( $item['title'] ), 'type' => sanitize_key( $item['type'] ),
                    'object' => sanitize_key( $item['object'] ?? '' ), 'object_id' => absint( $item['object_id'] ?? 0 ),
                    'url' => esc_url_raw( $item['url'] ?? '' ), 'target' => ( $item['target'] ?? '' ) === '_blank' ? '_blank' : '' );
            }
            $clean['menus'][] = array( 'name' => sanitize_text_field( $menu['name'] ), 'slug' => sanitize_title( $menu['slug'] ?? $menu['name'] ),
                'locations' => array_values( array_filter( array_map( 'sanitize_key', is_array( $menu['locations'] ?? null ) ? $menu['locations'] : array() ) ) ), 'items' => $items );
        }
        return $clean;
    }
    public static function preview() {
        self::gate( 'robotik_footer_preview' );
        if ( empty( $_FILES['footer_json'] ) || ! empty( $_FILES['footer_json']['error'] ) || empty( $_FILES['footer_json']['tmp_name'] ) ) { wp_die( 'Bitte eine JSON-Datei auswaehlen.' ); }
        $f = $_FILES['footer_json'];
        if ( $f['size'] > self::MAX_BYTES || $f['size'] < 10 || ! is_uploaded_file( $f['tmp_name'] ) ) { wp_die( 'Datei ungueltig oder zu gross.' ); }
        $raw = file_get_contents( $f['tmp_name'] );
        $decoded = json_decode( $raw, true, 40 );
        if ( ! is_array( $decoded ) ) { wp_die( 'Keine gueltige JSON-Datei.' ); }
        $data = self::sanitize_data( $decoded );
        if ( is_wp_error( $data ) ) { wp_die( esc_html( $data->get_error_message() ) ); }
        $proof = hash( 'sha256', wp_json_encode( $data ) );
        set_transient( self::key(), array( 'data' => $data, 'proof' => $proof ), 30 * MINUTE_IN_SECONDS );
        self::go( 'Vorschau bereit. WordPress wurde noch nicht veraendert.' );
    }
    private static function menu_item_args( $item, $created, $id_map, $source ) {
        $args = array( 'menu-item-title' => $item['title'], 'menu-item-status' => 'publish',
            'menu-item-parent-id' => isset( $id_map[ $item['old_parent'] ] ) ? $id_map[ $item['old_parent'] ] : 0 );
        if ( 'post_type' === $item['type'] && 'page' === $item['object'] ) {
            $raw = wp_parse_url( $item['url'], PHP_URL_PATH );
            $slug = $item['page_slug'] ?: sanitize_title( basename( trim( (string) $raw, '/' ) ) );
            if ( isset( $created[ $slug ] ) ) { $args['menu-item-type'] = 'post_type'; $args['menu-item-object'] = 'page'; $args['menu-item-object-id'] = $created[ $slug ]; return $args; }
            // Only use known target pages: never forward to an unknown old source site.
            return false;
        }
        if ( 'custom' !== $item['type'] ) { return false; }
        $url = $item['url'];
        $home = wp_parse_url( $source, PHP_URL_HOST ); $host = wp_parse_url( $url, PHP_URL_HOST );
        if ( $host && $home && strtolower( $home ) === strtolower( $host ) ) { return false; }
        if ( '' === $url || '#' === $url ) { $url = '#'; }
        if ( false === wp_http_validate_url( $url ) && '#' !== $url ) { return false; }
        $args['menu-item-type'] = 'custom'; $args['menu-item-url'] = $url; $args['menu-item-target'] = $item['target'];
        return $args;
    }
    public static function import() {
        self::gate( 'robotik_footer_import' );
        if ( ! isset( $_POST['confirm'] ) || 'yes' !== $_POST['confirm'] ) { wp_die( 'Explizite Zustimmung fehlt.' ); }
        $preview = get_transient( self::key() );
        $proof = sanitize_text_field( wp_unslash( $_POST['proof'] ?? '' ) );
        if ( ! is_array( $preview ) || empty( $preview['data'] ) || empty( $preview['proof'] ) || ! hash_equals( $preview['proof'], $proof ) ) { wp_die( 'Vorschau abgelaufen oder ungueltig. Bitte erneut pruefen.' ); }
        // Consume once, even if a later step returns an error: no blind double imports.
        delete_transient( self::key() ); $data = $preview['data'];
        $created = array(); $new_pages = 0; $new_menus = 0; $new_items = 0;
        foreach ( $data['pages'] as $p ) {
            $existing = get_page_by_path( $p['slug'], OBJECT, 'page' );
            if ( $existing ) { $created[ $p['slug'] ] = (int) $existing->ID; continue; }
            $id = wp_insert_post( wp_slash( array( 'post_type' => 'page', 'post_status' => 'draft',
                'post_name' => $p['slug'], 'post_title' => $p['title'], 'post_content' => $p['content'],
                'post_excerpt' => $p['excerpt'], 'post_author' => get_current_user_id() ) ), true );
            if ( ! is_wp_error( $id ) && $id ) { $created[ $p['slug'] ] = (int) $id; $new_pages++; }
        }
        $registered = get_registered_nav_menus(); $locations = get_nav_menu_locations();
        foreach ( $data['menus'] as $menu ) {
            $existing = wp_get_nav_menu_object( $menu['slug'] );
            if ( ! $existing ) { $existing = wp_get_nav_menu_object( $menu['name'] ); }
            if ( $existing ) { continue; } // Do not edit existing menus or their items.
            $id = wp_create_nav_menu( $menu['name'] );
            if ( is_wp_error( $id ) || ! $id ) { continue; }
            $new_menus++; $id_map = array();
            foreach ( $menu['items'] as $item ) {
                $args = self::menu_item_args( $item, $created, $id_map, $data['source'] );
                if ( ! $args ) { continue; }
                $new_id = wp_update_nav_menu_item( $id, 0, $args );
                if ( ! is_wp_error( $new_id ) && $new_id ) { $id_map[ $item['old_id'] ] = $new_id; $new_items++; }
            }
            foreach ( $menu['locations'] as $location ) {
                if ( ! self::is_footer( $location ) || ! isset( $registered[ $location ] ) || ! empty( $locations[ $location ] ) ) { continue; }
                $locations[ $location ] = $id;
            }
        }
        if ( ! empty( $locations ) ) { set_theme_mod( 'nav_menu_locations', $locations ); }
        self::go( sprintf( '%d neue Seiten als Entwurf, %d neue Menues, %d Menuepunkte. Vor Veroeffentlichung Portalnamen und Rechtstexte pruefen.', $new_pages, $new_menus, $new_items ) );
    }
}
Robotik_Footer_Umzug_Safe::boot();
