<?php
if (!defined('ABSPATH')) { exit; }

final class HDG_Core {
    public const POST_TYPE = 'hdg_term';
    public const TAXONOMY = 'hdg_world';
    public const META_PREFIX = '_hdg_';
    public const MAIN_PAGE_PATH = 'magazin/wissen-glossar';
    private const REWRITE_VERSION = '6';
    private const REWRITE_OPTION = 'hdg_rewrite_version';
    private const INDEX_QUERY_VAR = 'hdg_glossar_index';

    public static function init(): void {
        add_filter('query_vars', [__CLASS__, 'query_vars']);
        add_action('init', [__CLASS__, 'register_content']);
        add_action('init', [__CLASS__, 'ensure_worlds'], 20);
        add_action('init', [__CLASS__, 'cleanup_legacy_root'], 25);
        add_action('init', [__CLASS__, 'maybe_upgrade_rewrites'], 99);
        add_action('update_option_' . HDG_Config::OPTION, [__CLASS__, 'settings_updated'], 10, 2);
    }

    public static function activate(): void {
        self::register_content();
        self::ensure_worlds();
        self::cleanup_legacy_root();
        flush_rewrite_rules();
        update_option(self::REWRITE_OPTION, self::REWRITE_VERSION, false);
    }

    public static function deactivate(): void { flush_rewrite_rules(); }

    public static function query_vars(array $vars): array {
        $vars[] = self::INDEX_QUERY_VAR;
        return array_values(array_unique($vars));
    }

    public static function register_content(): void {
        $cfg = HDG_Config::get();
        $slug = HDG_Config::CANONICAL_BASE . '/' . trim($cfg['term_segment'], '/');

        register_post_type(self::POST_TYPE, [
            'labels' => [
                'name' => 'Glossarbegriffe',
                'singular_name' => 'Glossarbegriff',
                'add_new_item' => 'Glossarbegriff anlegen',
                'edit_item' => 'Glossarbegriff bearbeiten',
                'search_items' => 'Glossarbegriffe suchen',
            ],
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_rest' => true,
            'show_in_menu' => 'hdg-glossar',
            'has_archive' => false,
            'exclude_from_search' => false,
            'rewrite' => ['slug' => $slug, 'with_front' => false],
            'supports' => ['title', 'editor', 'revisions'],
            'map_meta_cap' => true,
        ]);

        register_taxonomy(self::TAXONOMY, [self::POST_TYPE], [
            'labels' => ['name' => 'Hobbywelten', 'singular_name' => 'Hobbywelt'],
            'public' => false,
            'publicly_queryable' => false,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
            'hierarchical' => false,
            'rewrite' => false,
        ]);

        // Exakte bestehende Portal-URL. Keine neue /glossar/-Route.
        add_rewrite_rule('^' . preg_quote(self::MAIN_PAGE_PATH, '#') . '/?$', 'index.php?' . self::INDEX_QUERY_VAR . '=1', 'top');
    }

    public static function ensure_worlds(): void {
        if (!taxonomy_exists(self::TAXONOMY)) { return; }
        foreach (HDG_Config::worlds() as $slug => $name) {
            if (!term_exists($slug, self::TAXONOMY)) {
                wp_insert_term($name, self::TAXONOMY, ['slug' => $slug]);
            }
        }
    }

    public static function cleanup_legacy_root(): void {
        // Nur die von 1.0.3 eindeutig selbst erzeugte falsche Root-Seite entfernen.
        $legacy = get_page_by_path('glossar', OBJECT, 'page');
        if ($legacy instanceof WP_Post
            && $legacy->post_title === 'Wissen & Glossar'
            && trim((string)$legacy->post_content) === '[hobby_depot_glossar]') {
            wp_trash_post((int)$legacy->ID);
        }
    }

    public static function settings_updated($old, $new): void {
        if (($old['term_segment'] ?? '') !== ($new['term_segment'] ?? '')) {
            flush_rewrite_rules(false);
        }
    }

    public static function maybe_upgrade_rewrites(): void {
        if ((string)get_option(self::REWRITE_OPTION, '') === self::REWRITE_VERSION) { return; }
        flush_rewrite_rules(false);
        update_option(self::REWRITE_OPTION, self::REWRITE_VERSION, false);
    }

    public static function is_index_route(): bool {
        if ((string)get_query_var(self::INDEX_QUERY_VAR, '') === '1') { return true; }
        // Fallback wirkt bereits beim ersten Request nach einem Plugin-Update, noch bevor Rewrite-Regeln neu geladen wurden.
        $uri = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '';
        if ($uri === '') { return false; }
        $request_path = trim((string)wp_parse_url($uri, PHP_URL_PATH), '/');
        $home_path = trim((string)wp_parse_url(home_url('/'), PHP_URL_PATH), '/');
        if ($home_path !== '') {
            if ($request_path === $home_path) { $request_path = ''; }
            elseif (str_starts_with($request_path, $home_path . '/')) { $request_path = substr($request_path, strlen($home_path) + 1); }
        }
        return trim($request_path, '/') === self::MAIN_PAGE_PATH;
    }

    public static function main_page_url(): string {
        return home_url('/' . self::MAIN_PAGE_PATH . '/');
    }

    public static function meta_key(string $field): string { return self::META_PREFIX . sanitize_key($field); }
    public static function get_meta(int $post_id, string $field): string { return (string)get_post_meta($post_id, self::meta_key($field), true); }
    public static function set_meta(int $post_id, string $field, $value): void { update_post_meta($post_id, self::meta_key($field), $value); }

    public static function current_world(int $post_id): ?WP_Term {
        $terms = wp_get_post_terms($post_id, self::TAXONOMY);
        return (!is_wp_error($terms) && !empty($terms) && $terms[0] instanceof WP_Term) ? $terms[0] : null;
    }

    public static function source_urls(int $post_id): array {
        $raw = get_post_meta($post_id, self::meta_key('sources'), true);
        return is_array($raw) ? array_values(array_filter(array_map('esc_url_raw', $raw))) : [];
    }
}
