<?php
/**
 * Plugin Name: Hobby Depot Glossar Core
 * Description: Zentrales Fachwörterbuch für Hobby Depot mit A–Z, Suche, Hobbywelten-Filtern und sicherem Draft-Manager.
 * Version: 1.0.25
 * Requires at least: 6.4
 * Requires PHP: 8.1
 * Author: OpenAI
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) { exit; }

define('HDG_VERSION', '1.0.25');
define('HDG_FILE', __FILE__);
define('HDG_DIR', plugin_dir_path(__FILE__));

require_once HDG_DIR . 'includes/class-hdg-config.php';
require_once HDG_DIR . 'includes/class-hdg-core.php';
require_once HDG_DIR . 'includes/class-hdg-manager.php';
require_once HDG_DIR . 'includes/class-hdg-frontend.php';
require_once HDG_DIR . 'includes/class-hdg-seo.php';

register_activation_hook(__FILE__, ['HDG_Core', 'activate']);
register_deactivation_hook(__FILE__, ['HDG_Core', 'deactivate']);

add_action('plugins_loaded', static function (): void {
    HDG_Core::init();
    HDG_Manager::init();
    HDG_Frontend::init();
    HDG_SEO::init();
});
