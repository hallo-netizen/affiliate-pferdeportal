<?php
if (!defined('ABSPATH')) { exit; }
$hdg_native = HDG_Frontend::native_shell_open('hdg-glossar-term-route');
while (have_posts()): the_post();
    $post = get_post();
    $id = get_the_ID();
    $world = HDG_Core::current_world($id);
    $def = HDG_Core::get_meta($id, 'short_definition');
    $related = HDG_Frontend::related_entries($id);
    $target = HDG_Frontend::primary_target($id);
    if (!$target) { $target = HDG_Frontend::world_main_target($world); }
    $world_url = $world ? HDG_Frontend::world_url($world->slug) : '';
    $content = apply_filters('the_content', get_the_content());
    $content = HDG_Frontend::strip_body_links((string)$content);
?>
<main class="hd-content-v150616 hdg-native-content" data-hdg-route="single">
<?php echo HDG_Frontend::breadcrumb_single($post, $world); ?>
<section id="primary" class="hdg-single">
    <article>
        <header class="hdg-single-head">
            <div class="hdg-eyebrow">Wissen</div>
            <h1><?php the_title(); ?></h1>
            <div class="hdg-single-rule"></div>
        </header>
        <div class="hdg-term-grid">
            <div>
                <?php if ($def): ?>
                    <section class="hdg-definition-box">
                        <div class="hdg-definition-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5.5c2.7-.8 5-.2 8 1.5 3-1.7 5.3-2.3 8-1.5v13c-2.7-.8-5-.2-8 1.5-3-1.7-5.3-2.3-8-1.5Z"/><path d="M12 7v13"/></svg></div>
                        <div><span class="hdg-definition-label">Kurz erklärt</span><p><?php echo esc_html($def); ?></p></div>
                    </section>
                <?php endif; ?>
                <div class="hdg-term-text"><?php echo $content; ?></div>
            </div>
            <aside class="hdg-term-aside">
                <?php
                if ($world) {
                    $body = $world_url !== ''
                        ? '<a href="' . esc_url($world_url) . '">' . esc_html($world->name) . '</a>'
                        : '<div class="hdg-aside-current">' . esc_html($world->name) . '</div>';
                    echo HDG_Frontend::aside_section('Hobbywelt', 'folder', $body);
                }
                if ($related) {
                    $body = '';
                    foreach ($related as $entry) {
                        $label = esc_html((string)($entry['label'] ?? ''));
                        $url = trim((string)($entry['url'] ?? ''));
                        $body .= $url !== ''
                            ? '<a href="' . esc_url($url) . '">' . $label . '</a>'
                            : '<span class="hdg-related-muted">' . $label . '</span>';
                    }
                    echo HDG_Frontend::aside_section('Verwandte Begriffe', 'link', $body);
                }
                echo HDG_Frontend::aside_ad(get_the_title());
                if ($target) {
                    echo HDG_Frontend::aside_section('Mehr zum Thema', 'folder', '<a href="' . esc_url($target['url']) . '">' . esc_html($target['label']) . '</a>');
                } elseif (current_user_can('edit_post', $id)) {
                    echo HDG_Frontend::aside_section('Mehr zum Thema', 'folder', '<div class="hdg-editor-note">Vor Veröffentlichung noch eine passende Hauptkategorie/Hauptseite zuordnen.</div>');
                }
                ?>
            </aside>
        </div>
        <?php echo HDG_Frontend::term_nav($id); ?>
    </article>
</section>
</main>
<?php endwhile; HDG_Frontend::native_shell_close($hdg_native);
