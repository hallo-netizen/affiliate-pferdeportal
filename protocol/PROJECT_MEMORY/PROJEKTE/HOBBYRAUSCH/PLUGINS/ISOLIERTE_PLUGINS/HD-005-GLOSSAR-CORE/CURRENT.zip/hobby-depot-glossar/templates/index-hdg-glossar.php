<?php
if (!defined('ABSPATH')) { exit; }
status_header(200);
$hdg_native = HDG_Frontend::native_shell_open('hdg-glossar-route');
?>
<main class="hd-content-v150616 hdg-native-content" data-hdg-route="index">
    <?php echo HDG_Frontend::breadcrumb_index(); ?>
    <?php echo HDG_Frontend::shortcode(); ?>
</main>
<?php HDG_Frontend::native_shell_close($hdg_native);
