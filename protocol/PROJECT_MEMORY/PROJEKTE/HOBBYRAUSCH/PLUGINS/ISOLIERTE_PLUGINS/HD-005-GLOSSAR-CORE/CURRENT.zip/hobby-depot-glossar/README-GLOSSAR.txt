Hobby Depot Glossar Core 1.0.6

Kanonische Haupt-URL:
/magazin/wissen-glossar/

Route wird auf template_redirect vor dem Hobby-Depot-Designrouter bedient.
Keine /glossar/-Zweitroute. Keine automatische zweite WordPress-Seite.

Live-Freigabe erst nach echtem WordPress-Readback.


1.0.7: Pferdeatelier-Glossarlogik übernommen: keine Bodylinks; Quellen nur intern gespeichert, nicht öffentlich; rechte Spalte Hobbywelt, verwandte Begriffe, optional Mehr zum Thema. Synonyme bleiben Metadaten, nicht eigener Frontendblock. Design unverändert.


1.0.11: Breadcrumbs benutzen exakt die native Hobby-Depot-Breadcrumb-Struktur und -Klassen (nicht Pferdeatelier-Optik). Begriffsnavigation unten nach Pferdeatelier-Konzept ohne Karten: Weiterwissen im Glossar, Glossar-Startseite, Zurück/Weiter. Verwandte Begriffe bleiben sichtbar, auch wenn der Zielbegriff noch nicht existiert; dann unverlinkt.


1.0.13: Glossar-Uebersicht auf native Hobby-Depot-Inhaltsbreite (bis 1440px) erweitert; Einzelbeitrag bewusst auf 1240px Lesebreite begrenzt. Mehr Abstand unter Breadcrumbs. Kurz-erklaert-Kasten mit linker Petrol-Linie. Definition und Body-Schrift groesser und einheitlicher; Sidebar-Text vergroessert.

1.0.13 hard-pass: native overview width 1440/952 at 1600/1024 viewports; single 1240/952; 16px breadcrumb gap; Kurz-erklärt 3px left petrol line; definition/body 16px.

1.0.14 PRODUKTIONSBESTAND
- 100 geprüfte Glossarbegriffe in 4 Batches à 25.
- Einmalige, idempotente Übernahme als Entwürfe beim ersten Admin-Aufruf nach Update.
- Kein Auto-Publish.
- Neue Inhaltsprüfung: erster Fließtextsatz darf die Kurzdefinition nicht zu stark wiederholen.
- Layout, Frontend-Templates und Routing gegenüber 1.0.13 unverändert.


1.0.16 IMPORT- UND DATEN-HARDPASS
- Behebt den lautlosen Komplettabbruch des eingebauten 100er-Imports bei bereits vorhandenen Pilotbegriffen/Slug-Konflikten.
- Vorhandene passende Pilotbegriffe werden sicher adoptiert und aktualisiert.
- Import prueft danach explizit 150/150 Begriffe und versucht bei Teilstand erneut.
- Admin-Hinweis zeigt Erfolg oder konkreten Importfehler statt lautlosem Abbruch.
- Layout, Route, Frontend und 100er-Inhaltsbestand unveraendert zu 1.0.14.

1.0.16 IMPORT- UND DATEN-HARDPASS
- 8 zuvor knapp zu kurze Fachtexte korrigiert: Serife, Schrötling, Trittfrequenz, Debouncing, Hot-Swap, Rektaszension, Münzzeichen, Fehlprägung.
- Wortzählung jetzt mit exakt derselben PHP-Logik geprüft wie der WordPress-Import.
- Direkter Test der echten privaten HDG_Manager::validate_batch()-Routine: Batches 1–6 PASS, insgesamt 150/150.
- Wortbereich im finalen Paket: 150–172 Wörter.
- Übergangsregel Kurzdefinition -> erster Fließtextsatz: PASS; höchste gemessene Überschneidung 0,3333 unter dem Blockierwert 0,35.


1.0.18 CYBERDUCK / AJAX-FIX / 200 BEGRIFFE
- Produktionsbestand auf 200 Glossarbegriffe erweitert (8 Batches à 25).
- admin-ajax.php und WordPress-Heartbeat duerfen den eingebauten Import nicht mehr ausloesen.
- Pro normalem Admin-Aufruf wird hoechstens ein 25er-Batch uebernommen.
- Simulation ab bestehendem 150er-Stand: AJAX 150->150 PASS; normaler Admin 150->175->200 PASS.
- Echte HDG_Manager::validate_batch()-Pruefung: 8/8 Batches PASS, 200/200 Begriffe.
- Wortbereich: 151-178.
- Layout, Route, Templates und Hero gegenueber 1.0.17 unveraendert.
- Cyberduck: lokalen Ordner hobby-depot-glossar direkt ueber /wp-content/plugins/hobby-depot-glossar/ kopieren/ersetzen.


1.0.22 – DESIGN-RENDER-HARDPASS
- aktive Glossar-Ausgabe lokal gerendert und für Start/Thema/Buchstabe/Suche geprüft
- Vorschautext 12.5 px, Link 11.5 px; stärkere Selektoren gegen Theme-Überschreibung
- individuelle Überschriften je Filterzustand
- Begriffsanzahl öffentlich entfernt
- Glossar-Startlink oben und unten
- Glossarroute setzt DONOTCACHEPAGE/nocache_headers und enthält HDG-Version im HTML zur eindeutigen Deploy-Prüfung

1.0.23: Hover-Effekt für alle Links „Zur Glossar-Startseite“ ergänzt (Farbwechsel + 2px Bewegung); sonst keine Layout- oder Inhaltsänderung.

1.0.24: Hover für Zur Glossar-Startseite korrigiert: keine Bewegung, Textfarbe bleibt #17313c sichtbar; Hover nur über Akzent-Unterstreichung/Inset-Linie. transform:none, opacity:1 und visibility:visible sind explizit abgesichert.

1.0.25: Glossarsuche nach Pferdeatelier-Prinzip: Ajax-Vorschau ab 2 Zeichen, max. 8 Treffer, ausschließlich veröffentlichte hdg_term-Glossarbegriffe; normales GET-Formular bleibt als Fallback.
