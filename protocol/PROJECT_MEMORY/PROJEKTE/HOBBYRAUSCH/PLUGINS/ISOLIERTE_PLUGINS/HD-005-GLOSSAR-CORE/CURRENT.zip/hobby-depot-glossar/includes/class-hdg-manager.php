<?php
if (!defined('ABSPATH')) { exit; }

final class HDG_Manager {
    private const BATCH_FORMAT = 'HD_GLOSSARY_BATCH_V1';
    private const MAX_BATCH = 25;
    private const MAX_BYTES = 5242880;
    private const BUNDLED_CONTENT_VERSION = '1.0.20-308';
    private const BUNDLED_TOTAL = 308;
    private const BUNDLED_BATCHES = 13;
    private const BUNDLED_OPTION = 'hdg_bundled_content_version';
    private const BUNDLED_NOTICE_OPTION = 'hdg_bundled_import_notice';

    public static function init(): void {
        add_action('admin_menu', [__CLASS__, 'menu']);
        add_action('admin_init', [__CLASS__, 'settings']);
        add_action('add_meta_boxes', [__CLASS__, 'meta_boxes']);
        add_action('save_post_' . HDG_Core::POST_TYPE, [__CLASS__, 'save_meta'], 10, 2);
        add_action('admin_post_hdg_batch_import', [__CLASS__, 'batch_import']);
        add_action('admin_post_hdg_export', [__CLASS__, 'export']);
        add_action('admin_init', [__CLASS__, 'maybe_import_bundled_batches'], 30);
        add_action('admin_notices', [__CLASS__, 'bundled_import_notice']);
    }

    public static function menu(): void {
        add_menu_page('Glossar', 'Glossar', 'edit_posts', 'hdg-glossar', [__CLASS__, 'dashboard'], 'dashicons-book-alt', 26);
        add_submenu_page('hdg-glossar', 'Alle Begriffe', 'Alle Begriffe', 'edit_posts', 'edit.php?post_type=' . HDG_Core::POST_TYPE);
        add_submenu_page('hdg-glossar', 'Neuer Begriff', 'Neuer Begriff', 'edit_posts', 'post-new.php?post_type=' . HDG_Core::POST_TYPE);
        add_submenu_page('hdg-glossar', 'Hobbywelten', 'Hobbywelten', 'manage_categories', 'edit-tags.php?taxonomy=' . HDG_Core::TAXONOMY . '&post_type=' . HDG_Core::POST_TYPE);
        add_submenu_page('hdg-glossar', 'Batch-Manager', 'Batch-Manager', 'manage_options', 'hdg-manager', [__CLASS__, 'manager_page']);
        add_submenu_page('hdg-glossar', 'Prüfbedarf', 'Prüfbedarf', 'edit_posts', 'hdg-review', [__CLASS__, 'review_page']);
        add_submenu_page('hdg-glossar', 'Einstellungen', 'Einstellungen', 'manage_options', 'hdg-settings', [__CLASS__, 'settings_page']);
    }

    public static function dashboard(): void {
        if (!current_user_can('edit_posts')) { return; }
        $published = wp_count_posts(HDG_Core::POST_TYPE)->publish ?? 0;
        $draft = wp_count_posts(HDG_Core::POST_TYPE)->draft ?? 0;
        echo '<div class="wrap"><h1>Hobby Depot Glossar</h1><p><strong>' . (int)$published . '</strong> veröffentlicht · <strong>' . (int)$draft . '</strong> Entwürfe.</p><p>Alle veröffentlichten Begriffe laufen zentral über die verbundene Glossar-Hauptseite. Hobbywelten dienen nur als Filter.</p></div>';
    }

    public static function settings(): void {
        register_setting('hdg_settings', HDG_Config::OPTION, ['sanitize_callback' => [HDG_Config::class, 'sanitize']]);
    }

    public static function settings_page(): void {
        if (!current_user_can('manage_options')) { return; }
        $c = HDG_Config::get();
        echo '<div class="wrap"><h1>Glossar – Einstellungen</h1><form method="post" action="options.php">';
        settings_fields('hdg_settings');
        self::input('label', 'Bezeichnung', $c['label']);
        self::input('term_segment', 'URL-Segment für Begriffe', $c['term_segment']);
        echo '<p><strong>Begriffe je Übersichtsseite</strong><br>16 (fest nach Glossar-Konzept)</p>';
        self::input('seo_title_pattern', 'SEO-Titel-Schema', $c['seo_title_pattern']);
        self::textarea('seo_description_pattern', 'Meta-Description-Schema', $c['seo_description_pattern']);
        submit_button();
        echo '</form></div>';
    }

    private static function input(string $key, string $label, string $value, string $type='text'): void {
        printf('<p><label><strong>%s</strong><br><input class="regular-text" type="%s" name="%s[%s]" value="%s"></label></p>', esc_html($label), esc_attr($type), esc_attr(HDG_Config::OPTION), esc_attr($key), esc_attr($value));
    }
    private static function textarea(string $key, string $label, string $value): void {
        printf('<p><label><strong>%s</strong><br><textarea class="large-text" rows="3" name="%s[%s]">%s</textarea></label></p>', esc_html($label), esc_attr(HDG_Config::OPTION), esc_attr($key), esc_textarea($value));
    }

    public static function meta_boxes(): void {
        add_meta_box('hdg-data', 'Glossar-Daten', [__CLASS__, 'meta_box'], HDG_Core::POST_TYPE, 'normal', 'high');
    }

    public static function meta_box(WP_Post $post): void {
        wp_nonce_field('hdg_save', 'hdg_nonce');
        $fields = [
            'external_id' => 'Stabile term-ID',
            'short_definition' => 'Kurzdefinition',
            'synonyms' => 'Synonyme',
            'related_slugs' => 'Verwandte Begriffe – Slugs (Komma)',
            'related_labels' => 'Verwandte Begriffe – sichtbare Namen (Komma, optional)',
            'seo_title' => 'SEO-Titel',
            'seo_description' => 'Meta-Description',
            'last_verified_at' => 'Zuletzt fachlich geprüft (YYYY-MM-DD)',
            'review_interval_months' => 'Prüfintervall (6/12/24)',
            'primary_target_type' => 'Hauptziel-Typ (page/category) – Pflicht vor Veröffentlichung',
            'primary_target_id' => 'Hauptziel-ID',
        ];
        foreach ($fields as $key => $label) {
            $value = HDG_Core::get_meta($post->ID, $key);
            $textarea = in_array($key, ['short_definition','seo_description'], true);
            echo '<p><label><strong>' . esc_html($label) . '</strong><br>';
            if ($textarea) printf('<textarea class="large-text" rows="3" name="hdg[%s]">%s</textarea>', esc_attr($key), esc_textarea($value));
            else printf('<input class="large-text" name="hdg[%s]" value="%s">', esc_attr($key), esc_attr($value));
            echo '</label></p>';
        }
        $sources = HDG_Core::source_urls($post->ID);
        echo '<p><label><strong>Quellen – eine URL pro Zeile</strong><br><textarea class="large-text" rows="4" name="hdg[sources]">' . esc_textarea(implode("\n", $sources)) . '</textarea></label></p>';
    }

    public static function save_meta(int $post_id, WP_Post $post): void {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (!isset($_POST['hdg_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hdg_nonce'])), 'hdg_save')) return;
        if (!current_user_can('edit_post', $post_id) || $post->post_type !== HDG_Core::POST_TYPE) return;
        $data = isset($_POST['hdg']) && is_array($_POST['hdg']) ? wp_unslash($_POST['hdg']) : [];
        foreach (['external_id','short_definition','synonyms','related_slugs','related_labels','seo_title','seo_description','last_verified_at','review_interval_months','primary_target_type','primary_target_id'] as $key) {
            HDG_Core::set_meta($post_id, $key, sanitize_textarea_field((string)($data[$key] ?? '')));
        }
        $sources = preg_split('/\R+/', (string)($data['sources'] ?? '')) ?: [];
        $sources = array_values(array_filter(array_map('esc_url_raw', array_map('trim', $sources))));
        update_post_meta($post_id, HDG_Core::meta_key('sources'), $sources);
    }

    public static function manager_page(): void {
        if (!current_user_can('manage_options')) { return; }
        $notice = isset($_GET['hdg_notice']) ? sanitize_text_field(wp_unslash($_GET['hdg_notice'])) : '';
        echo '<div class="wrap"><h1>Glossar – Batch-Manager</h1>';
        if ($notice) echo '<div class="notice notice-info"><p>' . esc_html($notice) . '</p></div>';
        echo '<p>Maximal 25 Begriffe pro Batch. Import immer als Entwurf. Kein Auto-Publish.</p>';
        echo '<form method="post" enctype="multipart/form-data" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="hdg_batch_import">';
        wp_nonce_field('hdg_batch_import', 'hdg_nonce');
        echo '<input type="file" name="hdg_json" accept="application/json,.json" required>';
        submit_button('Batch prüfen und als Entwürfe übernehmen');
        echo '</form><hr><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="hdg_export">';
        wp_nonce_field('hdg_export', 'hdg_nonce'); submit_button('Glossar exportieren', 'secondary'); echo '</form></div>';
    }

    public static function batch_import(): void {
        self::guard('hdg_batch_import');
        if (empty($_FILES['hdg_json']['tmp_name']) || (int)($_FILES['hdg_json']['size'] ?? 0) < 1 || (int)$_FILES['hdg_json']['size'] > self::MAX_BYTES) self::back('Import abgelehnt: ungültige Datei.');
        $data = json_decode((string)file_get_contents($_FILES['hdg_json']['tmp_name']), true);
        $errors = self::validate_batch($data);
        if ($errors) self::back('Import blockiert: ' . implode(' | ', array_slice($errors, 0, 6)));
        $created = self::import_rows($data['items']);
        self::back($created . ' Begriff(e) geprüft und als Entwurf übernommen.');
    }

    public static function maybe_import_bundled_batches(): void {
        // Niemals im WordPress-Heartbeat/AJAX oder in REST-Aufrufen importieren.
        // admin_init laeuft auch bei admin-ajax.php; dort darf keine Massenanlage starten.
        if ((function_exists('wp_doing_ajax') && wp_doing_ajax()) || (defined('DOING_AJAX') && DOING_AJAX)) return;
        if (defined('REST_REQUEST') && REST_REQUEST) return;
        if (!current_user_can('edit_posts')) return;
        if ((string)get_option(self::BUNDLED_OPTION, '') === self::BUNDLED_CONTENT_VERSION && self::bundled_count() === self::BUNDLED_TOTAL) return;

        $files = glob(HDG_DIR . 'data/HOBBY_DEPOT_GLOSSAR_BATCH_*_25_*.json') ?: [];
        sort($files, SORT_STRING);
        if (count($files) !== self::BUNDLED_BATCHES) {
            update_option(self::BUNDLED_NOTICE_OPTION, 'Glossar-Import blockiert: Es wurden nicht alle ' . self::BUNDLED_BATCHES . ' eingebauten 25er-Batches gefunden.', false);
            return;
        }

        $batches = [];
        $seen_ids = [];
        $seen_slugs = [];
        foreach ($files as $file) {
            $data = json_decode((string)file_get_contents($file), true);
            $errors = self::validate_batch($data, false);
            if ($errors) {
                update_option(self::BUNDLED_NOTICE_OPTION, 'Glossar-Import blockiert: ' . basename($file) . ': ' . implode(' | ', array_slice($errors, 0, 6)), false);
                return;
            }
            foreach ($data['items'] as $row) {
                $id = (string)$row['external_id'];
                $slug = sanitize_title((string)$row['slug']);
                if (isset($seen_ids[$id]) || isset($seen_slugs[$slug])) {
                    update_option(self::BUNDLED_NOTICE_OPTION, 'Glossar-Import blockiert: doppelte term-ID oder doppelter Slug im eingebauten Bestand.', false);
                    return;
                }
                $seen_ids[$id] = 1;
                $seen_slugs[$slug] = 1;
            }
            $batches[] = $data;
        }
        if (count($seen_ids) !== self::BUNDLED_TOTAL || count($seen_slugs) !== self::BUNDLED_TOTAL) {
            update_option(self::BUNDLED_NOTICE_OPTION, 'Glossar-Import blockiert: Der eingebaute Bestand umfasst nicht exakt ' . self::BUNDLED_TOTAL . ' eindeutige Begriffe.', false);
            return;
        }

        // Pro normalem Admin-Aufruf hoechstens EINEN 25er-Batch anfassen.
        // So bleibt der Import ressourcenschonend und kann nicht mehr parallel im AJAX-Heartbeat laufen.
        foreach ($batches as $data) {
            $needs_import = false;
            foreach ($data['items'] as $row) {
                $id = (string)$row['external_id'];
                $slug = sanitize_title((string)$row['slug']);
                $post_id = self::find_by_external_id($id);
                if (!$post_id && $slug !== '') {
                    $p = get_page_by_path($slug, OBJECT, HDG_Core::POST_TYPE);
                    if ($p instanceof WP_Post) $post_id = (int)$p->ID;
                }
                if ($post_id < 1) { $needs_import = true; break; }
            }
            if (!$needs_import) continue;

            self::import_rows($data['items']);
            $count = self::bundled_count();
            if ($count >= self::BUNDLED_TOTAL) {
                update_option(self::BUNDLED_OPTION, self::BUNDLED_CONTENT_VERSION, false);
                update_option(self::BUNDLED_NOTICE_OPTION, 'Glossar-Produktionsbestand erfolgreich geladen: ' . self::BUNDLED_TOTAL . '/' . self::BUNDLED_TOTAL . ' Begriffe vorhanden.', false);
            } else {
                update_option(self::BUNDLED_NOTICE_OPTION, 'Glossar-Import sicher fortgesetzt: ' . $count . '/' . self::BUNDLED_TOTAL . ' Begriffe vorhanden. Der naechste normale Admin-Aufruf uebernimmt den naechsten 25er-Batch.', false);
            }
            return;
        }

        $count = self::bundled_count();
        if ($count === self::BUNDLED_TOTAL) {
            update_option(self::BUNDLED_OPTION, self::BUNDLED_CONTENT_VERSION, false);
            update_option(self::BUNDLED_NOTICE_OPTION, 'Glossar-Produktionsbestand erfolgreich geladen: ' . self::BUNDLED_TOTAL . '/' . self::BUNDLED_TOTAL . ' Begriffe vorhanden.', false);
        } else {
            update_option(self::BUNDLED_NOTICE_OPTION, 'Glossar-Import unvollstaendig: ' . $count . '/' . self::BUNDLED_TOTAL . ' Begriffe gefunden.', false);
        }
    }

    public static function bundled_import_notice(): void {
        if (!current_user_can('edit_posts')) return;
        $msg = (string)get_option(self::BUNDLED_NOTICE_OPTION, '');
        if ($msg === '') return;
        $ok = str_contains($msg, self::BUNDLED_TOTAL . '/' . self::BUNDLED_TOTAL);
        $progress = str_contains($msg, 'sicher fortgesetzt');
        echo '<div class="notice ' . ($ok ? 'notice-success' : 'notice-error') . ' is-dismissible"><p>' . esc_html($msg) . '</p></div>';
    }

    private static function bundled_count(): int {
        $files = glob(HDG_DIR . 'data/HOBBY_DEPOT_GLOSSAR_BATCH_*_25_*.json') ?: [];
        $seen = [];
        foreach ($files as $file) {
            $data = json_decode((string)file_get_contents($file), true);
            if (!is_array($data) || empty($data['items']) || !is_array($data['items'])) continue;
            foreach ($data['items'] as $row) {
                $id = (string)($row['external_id'] ?? '');
                $slug = sanitize_title((string)($row['slug'] ?? ''));
                $post_id = self::find_by_external_id($id);
                if (!$post_id && $slug !== '') {
                    $p = get_page_by_path($slug, OBJECT, HDG_Core::POST_TYPE);
                    if ($p instanceof WP_Post) $post_id = (int)$p->ID;
                }
                if ($post_id > 0) $seen[$id] = 1;
            }
        }
        return count($seen);
    }

    private static function import_rows(array $rows): int {
        $processed = 0;
        foreach ($rows as $row) {
            $external_id = (string)$row['external_id'];
            $slug = sanitize_title((string)$row['slug']);
            $existing = self::find_by_external_id($external_id);
            if (!$existing && $slug !== '') {
                $same_slug = get_page_by_path($slug, OBJECT, HDG_Core::POST_TYPE);
                if ($same_slug instanceof WP_Post) {
                    $old_external_id = HDG_Core::get_meta((int)$same_slug->ID, 'external_id');
                    // Alte Pilotdatensaetze ohne stabile ID oder mit derselben ID sicher uebernehmen.
                    if ($old_external_id === '' || $old_external_id === $external_id) $existing = (int)$same_slug->ID;
                }
            }
            $postarr = [
                'post_type' => HDG_Core::POST_TYPE,
                'post_status' => 'draft',
                'post_title' => sanitize_text_field($row['term']),
                'post_name' => $slug,
                'post_content' => wp_kses_post($row['content']),
            ];
            if ($existing) $postarr['ID'] = $existing;
            $post_id = wp_insert_post($postarr, true);
            if (is_wp_error($post_id)) continue;
            wp_set_object_terms($post_id, sanitize_title($row['world']), HDG_Core::TAXONOMY, false);
            foreach (['external_id','short_definition','seo_title','seo_description','last_verified_at','review_interval_months'] as $key) HDG_Core::set_meta($post_id, $key, sanitize_text_field((string)$row[$key]));
            HDG_Core::set_meta($post_id, 'synonyms', implode(', ', array_map('sanitize_text_field', $row['synonyms'])));
            HDG_Core::set_meta($post_id, 'related_slugs', implode(', ', array_map('sanitize_title', $row['related_slugs'])));
            $related_labels = isset($row['related_terms']) && is_array($row['related_terms']) ? array_map('sanitize_text_field', $row['related_terms']) : [];
            HDG_Core::set_meta($post_id, 'related_labels', implode(', ', $related_labels));
            update_post_meta($post_id, HDG_Core::meta_key('sources'), array_values(array_map('esc_url_raw', $row['sources'])));
            $target = $row['primary_target'] ?? null;
            HDG_Core::set_meta($post_id, 'primary_target_type', is_array($target) ? sanitize_key((string)($target['type'] ?? '')) : '');
            HDG_Core::set_meta($post_id, 'primary_target_id', is_array($target) ? absint($target['id'] ?? 0) : 0);
            $processed++;
        }
        return $processed;
    }

    private static function opening_too_close(string $definition, string $content): bool {
        $definition = self::content_words($definition);
        $plain = trim(wp_strip_all_tags($content));
        $parts = preg_split('/(?<=[.!?])\s+/u', $plain, 2) ?: [];
        $opening = self::content_words((string)($parts[0] ?? ''));
        if (!$definition || !$opening) return false;
        $a = array_values(array_unique($definition));
        $b = array_values(array_unique($opening));
        $common = array_intersect($a, $b);
        $base = min(count($a), count($b));
        return $base > 0 && (count($common) / $base) > 0.35;
    }

    private static function content_words(string $text): array {
        $text = strtolower(strtr(wp_strip_all_tags($text), ['Ä'=>'ä','Ö'=>'ö','Ü'=>'ü','ẞ'=>'ß']));
        $text = str_replace('ß', 'ss', $text);
        $parts = preg_split('/[^\p{L}\p{N}-]+/u', $text, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $stop = array_flip(['der','die','das','ein','eine','einer','eines','einem','einen','ist','sind','wird','werden','bezeichnet','bedeutet','beschreibt','bei','beim','im','in','auf','aus','von','mit','und','oder','zu','zum','zur','für','durch','als','sich','den','dem','des','auch','dass','damit','nicht','noch','aber','kann']);
        return array_values(array_filter($parts, static fn($w) => strlen($w) > 2 && !isset($stop[$w])));
    }

    private static function validate_batch($data, bool $check_existing_slug = true): array {
        $errors = [];
        if (!is_array($data) || ($data['contract'] ?? '') !== self::BATCH_FORMAT || !isset($data['items']) || !is_array($data['items'])) return ['falscher Contract'];
        if (count($data['items']) < 1 || count($data['items']) > self::MAX_BATCH) return ['Batchgröße muss 1–25 sein'];
        $worlds = HDG_Config::worlds(); $seenIds=[]; $seenSlugs=[];
        foreach ($data['items'] as $i => $r) {
            $n=$i+1; if (!is_array($r)) { $errors[]="#{$n}: kein Datensatz"; continue; }
            $id=(string)($r['external_id']??''); $slug=sanitize_title((string)($r['slug']??'')); $term=trim((string)($r['term']??''));
            if (!preg_match('/^term-[a-z0-9][a-z0-9-]{1,80}$/', $id)) $errors[]="#{$n}: ungültige term-ID";
            if ($term==='') $errors[]="#{$n}: Begriff fehlt";
            if ($slug==='') $errors[]="#{$n}: Slug fehlt";
            if (isset($seenIds[$id])) $errors[]="#{$n}: doppelte term-ID"; $seenIds[$id]=1;
            if (isset($seenSlugs[$slug])) $errors[]="#{$n}: doppelter Slug"; $seenSlugs[$slug]=1;
            $world=sanitize_title((string)($r['world']??'')); if (!isset($worlds[$world])) $errors[]="#{$n}: ungültige Hobbywelt";
            $def=trim((string)($r['short_definition']??'')); if ($def==='') $errors[]="#{$n}: Kurzdefinition fehlt";
            $content=(string)($r['content']??'');
            if (preg_match('/<a\b/i',$content)) $errors[]="#{$n}: Bodylink verboten";
            $words=preg_split('/\s+/u', trim(wp_strip_all_tags($content))) ?: []; $wc=count(array_filter($words));
            if ($wc < 150 || $wc > 200) $errors[]="#{$n}: Fachtext nicht 150–200 Wörter";
            if ($def !== '' && self::opening_too_close($def, $content)) $errors[]="#{$n}: erster Fließtextsatz wiederholt Kurzdefinition zu stark";
            if (empty($r['related_slugs']) || !is_array($r['related_slugs'])) $errors[]="#{$n}: verwandter Begriff fehlt";
            if (isset($r['related_terms']) && (!is_array($r['related_terms']) || count($r['related_terms']) !== count($r['related_slugs']))) $errors[]="#{$n}: related_terms passt nicht zu related_slugs";
            if (empty($r['sources']) || !is_array($r['sources'])) $errors[]="#{$n}: Quellen fehlen";
            if (trim((string)($r['seo_title']??''))==='') $errors[]="#{$n}: SEO-Titel fehlt";
            if (trim((string)($r['seo_description']??''))==='') $errors[]="#{$n}: Meta-Description fehlt";
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/',(string)($r['last_verified_at']??''))) $errors[]="#{$n}: Prüfdatum fehlt/ungültig";
            if (!in_array((int)($r['review_interval_months']??0),[6,12,24],true)) $errors[]="#{$n}: Prüfintervall nur 6/12/24";
            $target=$r['primary_target']??null;
            if (!is_array($target) || !in_array(($target['type']??''),['page','category'],true) || absint($target['id']??0)<1) $errors[]="#{$n}: Hauptziel fehlt/ungültig";
            if ($check_existing_slug) {
                $existing=self::find_by_external_id($id); $sameSlug=get_page_by_path($slug, OBJECT, HDG_Core::POST_TYPE);
                if ($sameSlug instanceof WP_Post && (int)$sameSlug->ID !== (int)$existing) $errors[]="#{$n}: Slug existiert bereits";
            }
        }
        return $errors;
    }

    private static function find_by_external_id(string $id): int {
        if ($id==='') return 0;
        $q=get_posts(['post_type'=>HDG_Core::POST_TYPE,'post_status'=>'any','numberposts'=>1,'fields'=>'ids','meta_key'=>HDG_Core::meta_key('external_id'),'meta_value'=>$id]);
        return $q ? (int)$q[0] : 0;
    }

    public static function export(): void {
        self::guard('hdg_export');
        $posts=get_posts(['post_type'=>HDG_Core::POST_TYPE,'post_status'=>['publish','draft','pending','private'],'numberposts'=>-1,'orderby'=>'title','order'=>'ASC']);
        $items=[];
        foreach($posts as $p){
            $w=HDG_Core::current_world($p->ID);
            $items[]=[
                'external_id'=>HDG_Core::get_meta($p->ID,'external_id'),'term'=>$p->post_title,'slug'=>$p->post_name,'world'=>$w?$w->slug:'',
                'short_definition'=>HDG_Core::get_meta($p->ID,'short_definition'),'content'=>$p->post_content,
                'synonyms'=>array_values(array_filter(array_map('trim',explode(',',HDG_Core::get_meta($p->ID,'synonyms'))))),
                'related_slugs'=>array_values(array_filter(array_map('trim',explode(',',HDG_Core::get_meta($p->ID,'related_slugs'))))),
                'related_terms'=>array_values(array_filter(array_map('trim',explode(',',HDG_Core::get_meta($p->ID,'related_labels'))))),
                'sources'=>HDG_Core::source_urls($p->ID),'seo_title'=>HDG_Core::get_meta($p->ID,'seo_title'),'seo_description'=>HDG_Core::get_meta($p->ID,'seo_description'),
                'last_verified_at'=>HDG_Core::get_meta($p->ID,'last_verified_at'),'review_interval_months'=>(int)HDG_Core::get_meta($p->ID,'review_interval_months'),
                'primary_target'=>HDG_Core::get_meta($p->ID,'primary_target_id') ? ['type'=>HDG_Core::get_meta($p->ID,'primary_target_type'),'id'=>(int)HDG_Core::get_meta($p->ID,'primary_target_id')] : null,
            ];
        }
        nocache_headers(); header('Content-Type: application/json; charset=utf-8'); header('Content-Disposition: attachment; filename="hobby-depot-glossar-' . gmdate('Ymd-His') . '.json"');
        echo wp_json_encode(['contract'=>self::BATCH_FORMAT,'exported_at'=>gmdate('c'),'items'=>$items],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
    }

    public static function review_page(): void {
        if (!current_user_can('edit_posts')) return;
        $posts=get_posts(['post_type'=>HDG_Core::POST_TYPE,'post_status'=>['publish','draft'],'numberposts'=>-1,'orderby'=>'title','order'=>'ASC']);
        echo '<div class="wrap"><h1>Glossar – Prüfbedarf</h1><table class="widefat striped"><thead><tr><th>Begriff</th><th>Zuletzt geprüft</th><th>Intervall</th><th>Status</th></tr></thead><tbody>';
        $today=new DateTimeImmutable('today');
        foreach($posts as $p){ $date=HDG_Core::get_meta($p->ID,'last_verified_at'); $months=(int)HDG_Core::get_meta($p->ID,'review_interval_months'); $due='UNGEKLÄRT';
            if ($date && in_array($months,[6,12,24],true)) { try{$d=(new DateTimeImmutable($date))->modify('+'.$months.' months');$due=$d <= $today ? 'FÄLLIG' : 'OK';}catch(Throwable $e){} }
            printf('<tr><td><a href="%s">%s</a></td><td>%s</td><td>%s</td><td><strong>%s</strong></td></tr>',esc_url(get_edit_post_link($p->ID)),esc_html($p->post_title),esc_html($date),$months?esc_html((string)$months):'–',esc_html($due));
        }
        echo '</tbody></table></div>';
    }

    private static function guard(string $action): void {
        if (!current_user_can('manage_options')) wp_die('Keine Berechtigung.');
        $nonce=isset($_REQUEST['hdg_nonce'])?sanitize_text_field(wp_unslash($_REQUEST['hdg_nonce'])):'';
        if (!wp_verify_nonce($nonce,$action)) wp_die('Ungültige Sicherheitsprüfung.');
    }
    private static function back(string $msg): void { wp_safe_redirect(add_query_arg(['page'=>'hdg-manager','hdg_notice'=>$msg],admin_url('admin.php'))); exit; }
}
