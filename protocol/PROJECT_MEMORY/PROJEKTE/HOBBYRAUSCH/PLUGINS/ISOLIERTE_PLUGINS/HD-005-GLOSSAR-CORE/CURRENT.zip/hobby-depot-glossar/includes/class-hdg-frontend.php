<?php
if (!defined('ABSPATH')) { exit; }

final class HDG_Frontend {
    public static function init(): void {
        add_shortcode('hobby_depot_glossar', [__CLASS__, 'shortcode']);
        add_filter('pre_handle_404', [__CLASS__, 'handle_index_404'], 10, 2);
        // Exakte Glossarroute vor dem zentralen Hobby-Depot-Designrouter bedienen.
        add_action('template_redirect', [__CLASS__, 'serve_index_route'], -9999);
        add_filter('template_include', [__CLASS__, 'template'], PHP_INT_MAX);
        add_action('wp_enqueue_scripts', [__CLASS__, 'assets']);
        add_action('wp_ajax_hdg_search', [__CLASS__, 'ajax_search']);
        add_action('wp_ajax_nopriv_hdg_search', [__CLASS__, 'ajax_search']);
    }

    public static function shortcode(): string { return self::render_index(); }

    public static function serve_index_route(): void {
        if (is_admin() || !HDG_Core::is_index_route()) { return; }
        if (!defined('DONOTCACHEPAGE')) { define('DONOTCACHEPAGE', true); }
        if (function_exists('nocache_headers')) { nocache_headers(); }
        status_header(200);
        if (isset($GLOBALS['wp_query']) && is_object($GLOBALS['wp_query'])) {
            $GLOBALS['wp_query']->is_404 = false;
            $GLOBALS['wp_query']->is_home = false;
        }
        $candidate = HDG_DIR . 'templates/index-hdg-glossar.php';
        if (!is_readable($candidate)) { return; }
        include $candidate;
        exit;
    }

    public static function handle_index_404($preempt, $query) {
        if (!HDG_Core::is_index_route()) { return $preempt; }
        status_header(200);
        if (is_object($query)) { $query->is_404 = false; }
        return true;
    }

    public static function template(string $template): string {
        if (HDG_Core::is_index_route()) {
            $candidate = HDG_DIR . 'templates/index-hdg-glossar.php';
            return is_readable($candidate) ? $candidate : $template;
        }
        if (is_singular(HDG_Core::POST_TYPE)) {
            $candidate = HDG_DIR . 'templates/single-hdg-term.php';
            if (is_readable($candidate)) { return $candidate; }
        }
        return $template;
    }

    public static function assets(): void {
        if (!is_singular(HDG_Core::POST_TYPE) && !HDG_Core::is_index_route()) return;
        wp_register_style('hdg-style', false, [], HDG_VERSION);
        wp_enqueue_style('hdg-style');
        wp_add_inline_style('hdg-style', self::css());
    }

    private static function css(): string {
        return <<<'CSS'
.hdg,.hdg-single{--hdg-dark:#17313c;--hdg-accent:#0f8f95;--hdg-accent-deep:#0a777c;--hdg-cream:#eef8f7;--hdg-soft:#f7fbfb;--hdg-line:rgba(39,59,54,.16);--hdg-muted:#59656a;--hdg-gold:#0f8f95;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif}.hdg{width:min(calc(100% - 72px),var(--hd-content));margin:14px auto 0;padding:0 0 52px;color:var(--hdg-dark)}
.hdg a{color:inherit}.hdg-serif{font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif}
.hdg-hero{position:relative;min-height:218px;margin:0 0 16px;overflow:hidden;border:1px solid var(--hdg-line);background:var(--hdg-cream)}.hdg-hero img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}.hdg-hero:after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(247,251,251,.98) 0%,rgba(247,251,251,.96) 30%,rgba(238,248,247,.74) 48%,rgba(238,248,247,0) 70%)}.hdg-hero-copy{position:relative;z-index:2;width:min(49%,520px);padding:48px 42px 38px}.hdg-eyebrow{margin:0 0 8px;color:var(--hdg-accent-deep);font-size:10px;font-weight:800;letter-spacing:.18em;text-transform:uppercase}.hdg-hero h1{margin:0;color:var(--hdg-dark);font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;font-size:42px;font-weight:800;letter-spacing:-.025em;line-height:1}.hdg-hero p{margin:10px 0 0;color:#4d5b61;font-size:14px}
.hdg-search-panel{margin:0 0 26px;padding:18px 20px 16px;background:var(--hdg-cream);border:1px solid rgba(23,49,60,.08)}.hdg-search-row{display:grid;grid-template-columns:minmax(0,1fr) 116px;gap:0;max-width:none}.hdg-search-field{position:relative;display:block;min-width:0}.hdg-search{width:100%;height:46px;padding:0 16px;border:1px solid rgba(23,49,60,.18);border-right:0;background:#fff;font:inherit;color:var(--hdg-dark)}.hdg-search-suggestions{position:absolute;z-index:999;top:100%;left:0;right:0;border:1px solid rgba(23,49,60,.18);border-top:0;background:#fff;box-shadow:0 12px 24px rgba(23,49,60,.15);text-align:left}.hdg-search-suggestions[hidden]{display:none}.hdg-search-suggestion{display:block;padding:12px 14px;border-bottom:1px solid rgba(23,49,60,.12);color:#17313c!important;font-size:14px;font-weight:700;text-decoration:none!important}.hdg-search-suggestion:last-child{border-bottom:0}.hdg-search-suggestion:hover,.hdg-search-suggestion:focus-visible{background:var(--hdg-cream);color:var(--hdg-accent-deep)!important}.hdg-search-empty{display:block;padding:12px 14px;color:#657078;font-size:13px}.hdg .hdg-search-row button{height:46px;border:0!important;background:#0f8f95!important;color:#fff!important;font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;cursor:pointer;box-shadow:none!important;border-radius:0!important}.hdg .hdg-search-row button:hover{background:#0a777c!important}.hdg-az{display:flex;justify-content:space-between;gap:7px;flex-wrap:wrap;margin-top:13px}.hdg-az a{min-width:18px;padding:2px 3px;color:#31444c;font-size:10px;font-weight:750;text-align:center;text-decoration:underline;text-underline-offset:3px}.hdg-az a.is-active{color:var(--hdg-accent-deep);font-weight:900}
.hdg-world-section{margin:24px 0 28px}.hdg-section-title{display:flex;align-items:center;justify-content:center;gap:14px;margin:0 0 22px}.hdg-section-title:before,.hdg-section-title:after{content:"";width:76px;height:1px;background:#89bdc0}.hdg-section-title h2{margin:0;color:#17313c;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;font-size:27px;font-weight:800}.hdg-worlds{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:14px}.hdg-worlds a{display:flex;min-width:0;flex-direction:column;align-items:center;gap:8px;color:#17313c;font-size:10px;font-weight:700;line-height:1.2;text-align:center;text-decoration:none}.hdg-world-icon{display:grid;place-items:center;width:48px;height:48px;border-radius:50%;background:var(--hdg-cream);color:var(--hdg-dark);transition:.15s ease}.hdg-world-icon svg{width:23px;height:23px;fill:none;stroke:currentColor;stroke-width:1.65;stroke-linecap:round;stroke-linejoin:round}.hdg-worlds a:hover .hdg-world-icon,.hdg-worlds a.is-active .hdg-world-icon{background:var(--hdg-accent);color:#fff}.hdg-worlds a.is-active{color:var(--hdg-accent-deep)}
.hdg-ad{position:relative;margin:22px 0 30px;text-align:center}.hdg-ad-label{display:block;margin-bottom:7px;color:#6b7478;font-size:8px;letter-spacing:.09em;text-transform:uppercase}.hdg-ad-box{display:flex;min-height:88px;align-items:center;justify-content:center;border:1px dashed rgba(47,150,157,.36);background:#f7fbfb;color:#657078;font-size:11px}.hdg-ad.has-content .hdg-ad-box{border:0;background:transparent}.hdg-ad.has-content .hdg-ad-box>*{max-width:100%}
.hdg-all-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin:0 0 18px;padding:0 0 10px;border-bottom:1px solid rgba(23,49,60,.14)}.hdg-all-head h2{margin:0;color:#17313c;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;font-size:27px;font-weight:800}.hdg-glossary-home{display:inline-flex;flex:0 0 auto;align-items:center;color:#17313c!important;font-size:11px;font-weight:800;text-decoration:underline!important;text-decoration-color:rgba(23,49,60,.42)!important;text-underline-offset:3px;transition:text-decoration-color .15s ease,box-shadow .15s ease;transform:none!important;opacity:1!important;visibility:visible!important}.hdg-glossary-home:hover,.hdg-glossary-home:focus-visible{color:#17313c!important;text-decoration-color:#0f8f95!important;box-shadow:inset 0 -2px 0 rgba(15,143,149,.32);transform:none!important;opacity:1!important;visibility:visible!important}.hdg-pagination{display:flex;justify-content:center;align-items:center;gap:8px;flex-wrap:wrap;margin:18px 0}.hdg-pagination a,.hdg-pagination span{display:inline-flex;min-width:34px;min-height:32px;align-items:center;justify-content:center;padding:5px 9px;border:1px solid var(--hdg-line);background:#fff;color:#17313c;font-size:11px;font-weight:750;text-decoration:none}.hdg-pagination span[aria-current="page"]{border-color:var(--hdg-accent);background:var(--hdg-accent);color:#fff}.hdg-list-footer{display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:16px;margin-top:2px}.hdg-list-footer .hdg-pagination{grid-column:2;margin:18px 0}.hdg-list-footer .hdg-glossary-home{grid-column:3;justify-self:end}.hdg-list-footer.no-pages{grid-template-columns:1fr}.hdg-list-footer.no-pages .hdg-glossary-home{grid-column:1;justify-self:end;margin:16px 0 0}
.hdg-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.hdg-card{position:relative;display:flex;min-height:150px;padding:14px 14px 12px;flex-direction:column;border:1px solid rgba(23,49,60,.15);background:#fff}.hdg-card:hover{border-color:rgba(47,150,157,.5)}.hdg-card h3{margin:0 0 7px;color:#17313c;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;font-size:17px;font-weight:800;line-height:1.08}.hdg .hdg-card p{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:4;line-clamp:4;overflow:hidden;margin:0 0 12px;color:#657078;font-size:12.5px!important;line-height:1.5}.hdg .hdg-card-open{margin-top:auto;color:#17313c;font-size:11.5px!important;font-weight:800;text-decoration:underline;text-underline-offset:3px}.hdg .hdg-card-open:after{content:" →"}.hdg-card>a:first-child:after,.hdg-card h3 a:after{content:"";position:absolute;inset:0}.hdg-empty{grid-column:1/-1;padding:28px;background:var(--hdg-cream);color:var(--hdg-muted)}
.hdg-single{width:min(calc(100% - 72px),1240px);margin:16px auto 0;padding:0 0 58px;color:var(--hdg-dark)}.hdg-single-head{margin:0 0 16px}.hdg-single-head .hdg-eyebrow{margin-bottom:8px}.hdg-single h1{margin:0 0 14px;color:#17313c;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;font-size:50px;font-weight:800;letter-spacing:-.03em;line-height:1.02}.hdg-single-rule{height:1px;margin:0 0 18px;background:rgba(23,49,60,.14)}.hdg-term-grid{display:grid;grid-template-columns:minmax(0,2fr) minmax(280px,.82fr);gap:36px;align-items:start}.hdg-definition-box{display:grid;grid-template-columns:44px minmax(0,1fr);gap:12px;margin:0 0 24px;padding:18px 20px;border-top:3px solid var(--hdg-accent);border-left:3px solid var(--hdg-accent);background:#eef8f7}.hdg-definition-icon{display:grid;place-items:start center;padding-top:2px;color:var(--hdg-accent-deep)}.hdg-definition-icon svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.7}.hdg-definition-label{display:block;margin:0 0 6px;color:#0a777c;font-size:11px;font-weight:900;letter-spacing:.1em;text-transform:uppercase;line-height:1.35}.hdg-definition-box p{margin:0;color:#31444c;font-size:16px;font-weight:500;line-height:1.58}.hdg-term-text{color:#4d5b61;font-size:16px;line-height:1.72}.hdg-term-text p{margin:0 0 17px}.hdg-term-text a{color:inherit!important;text-decoration:none!important;pointer-events:none!important}.hdg-term-aside{display:flex;flex-direction:column;gap:14px}.hdg-aside-card{padding:17px 16px 15px;border-top:3px solid var(--hdg-accent);background:#eef8f7}.hdg-aside-card h2{display:flex;align-items:center;gap:8px;margin:0 0 12px;color:#17313c;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;font-size:20px;font-weight:800;line-height:1.08}.hdg-aside-card h2 svg{width:17px;height:17px;fill:none;stroke:currentColor;stroke-width:1.65}.hdg-aside-card a{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:7px 0;border-bottom:1px solid rgba(23,49,60,.11);color:#31444c;font-size:12.5px;font-weight:750;line-height:1.45;text-decoration:none}.hdg-aside-card a:last-child{border-bottom:0}.hdg-aside-card a:after{content:"→"}.hdg-aside-card .hdg-aside-current{color:#59656a;font-size:12.5px;font-weight:700;line-height:1.45}.hdg-aside-card.is-missing{display:none}.hdg-aside-ad{margin:0}.hdg-aside-ad .hdg-ad-box{min-height:210px}.hdg-aside-ad .hdg-ad-label{margin-bottom:5px}.hdg-editor-note{padding:8px 10px;background:#fff4d6;color:#72580d;font-size:11px;line-height:1.45}
.hdg-more-glossary{margin-top:32px;border-top:1px solid rgba(23,49,60,.14)}.hdg-more-head{display:flex;align-items:center;justify-content:space-between;gap:18px;padding:15px 0;border-bottom:1px solid rgba(23,49,60,.12)}.hdg-more-head strong{color:#657078;font-size:9.5px;font-weight:800;letter-spacing:.11em;text-transform:uppercase}.hdg-more-home{display:inline-flex;align-items:center;gap:7px;color:#17313c!important;font-size:11.5px;font-weight:800;text-decoration:none!important;transition:box-shadow .15s ease;transform:none!important;opacity:1!important;visibility:visible!important}.hdg-more-home:hover,.hdg-more-home:focus-visible{color:#17313c!important;box-shadow:inset 0 -2px 0 rgba(15,143,149,.32);transform:none!important;opacity:1!important;visibility:visible!important}.hdg-term-nav{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:54px;padding:28px 0 6px}.hdg-term-nav a{display:block;min-width:0;color:#17313c!important;text-decoration:none!important}.hdg-term-nav .prev{text-align:left}.hdg-term-nav .next{text-align:right;margin-left:auto}.hdg-term-nav small{display:block;margin-bottom:7px;color:#657078;font-size:9px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.hdg-term-nav strong{display:block;font-size:13px;font-weight:650;line-height:1.35}.hdg-term-nav a:hover strong{color:var(--hdg-accent-deep)}.hdg-related-muted{display:block;padding:8px 0;border-top:1px solid rgba(23,49,60,.10);color:#6b7478;font-size:12.5px;font-weight:650;line-height:1.45}.hdg-related-muted:first-of-type{border-top:0}
@media(max-width:980px){.hdg-worlds{grid-template-columns:repeat(4,minmax(0,1fr));row-gap:18px}.hdg-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.hdg-term-grid{grid-template-columns:minmax(0,1.6fr) minmax(220px,.9fr)}.hdg-hero-copy{width:58%}}
@media(max-width:760px){.hdg,.hdg-single{width:calc(100% - 24px);margin-top:12px}.hdg-hero{min-height:185px}.hdg-hero-copy{width:72%;padding:35px 22px 30px}.hdg-hero h1{font-size:35px}.hdg-search-panel{padding:14px}.hdg-search-row{grid-template-columns:1fr}.hdg-search{border-right:1px solid rgba(23,49,60,.18)}.hdg-search-row button{width:100%;margin-top:7px}.hdg-az{justify-content:flex-start}.hdg-worlds{grid-template-columns:repeat(4,minmax(0,1fr));gap:14px 8px}.hdg-section-title h2,.hdg-all-head h2{font-size:24px}.hdg-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.hdg-term-grid{grid-template-columns:1fr}.hdg-single h1{font-size:42px}.hdg-term-aside{margin-top:6px}}
@media(max-width:520px){.hdg-all-head{align-items:flex-start;flex-direction:column;gap:7px}.hdg-list-footer{display:flex;flex-direction:column;align-items:stretch;gap:0}.hdg-list-footer .hdg-pagination{order:1}.hdg-list-footer .hdg-glossary-home{order:2;align-self:flex-end;margin-top:0}.hdg-more-head{align-items:flex-start;flex-direction:column}.hdg-term-nav{gap:20px}.hdg-term-nav .next{text-align:right}.hdg-hero:after{background:linear-gradient(90deg,rgba(247,251,251,.97) 0%,rgba(238,248,247,.90) 60%,rgba(238,248,247,.34) 100%)}.hdg-hero-copy{width:88%}.hdg-worlds{grid-template-columns:repeat(2,minmax(0,1fr))}.hdg-grid{grid-template-columns:1fr}.hdg-card{min-height:126px}.hdg-section-title:before,.hdg-section-title:after{width:42px}}
CSS;
    }

    public static function world_icon(string $slug): string {
        $icons = [
            'gestalten' => '<path d="M12 3a9 9 0 1 0 0 18h1.2a2 2 0 0 0 0-4H12a1.5 1.5 0 0 1 0-3h2.5A6.5 6.5 0 0 0 21 7.5C21 5 17 3 12 3Z"/><circle cx="7.5" cy="9" r="1"/><circle cx="10.5" cy="6.8" r="1"/><circle cx="14" cy="6.8" r="1"/>',
            'fertigen' => '<path d="M14 6l4-4 4 4-4 4"/><path d="M13 7 4 16a3 3 0 0 0 4 4l9-9"/><path d="m4 4 6 6"/><path d="m3 3 3 1 1 3"/>',
            'technik' => '<circle cx="12" cy="12" r="3.2"/><path d="M12 2v2.2M12 19.8V22M22 12h-2.2M4.2 12H2M19.1 4.9l-1.6 1.6M6.5 17.5l-1.6 1.6M19.1 19.1l-1.6-1.6M6.5 6.5 4.9 4.9"/><circle cx="12" cy="12" r="7.2"/>',
            'forschen' => '<path d="M9 2h6M10 2v6l-5 9a3 3 0 0 0 2.6 4.5h8.8A3 3 0 0 0 19 17l-5-9V2"/><path d="M7.8 15h8.4"/>',
            'pflanzen' => '<path d="M20 4C12 4 6 8 5 16c7 1 13-2 15-12Z"/><path d="M4 20c3-6 8-10 14-13"/>',
            'tiere' => '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/><path d="M8 14c2-2 4-2 6 0-2 2-4 2-6 0Z"/><path d="m8 14-2-2v4l2-2Z"/><path d="M17 18c0-3 1-5 3-6"/>',
            'bewegen' => '<circle cx="14" cy="4.5" r="2"/><path d="m12 8-3 5 3 2 2-4 3 3"/><path d="m10 15-3 6M14 16l4 5M9 10l-4 2"/>',
            'sammeln' => '<path d="m3 7 9-4 9 4-9 4-9-4Z"/><path d="M3 7v10l9 4 9-4V7"/><path d="M12 11v10"/>',
        ];
        $inner = $icons[$slug] ?? '<circle cx="12" cy="12" r="7"/>';
        return '<svg viewBox="0 0 24 24" aria-hidden="true">' . $inner . '</svg>';
    }

    private static function icon_svg(string $name): string {
        $icons = [
            'book' => '<path d="M4 5.5c2.7-.8 5-.2 8 1.5 3-1.7 5.3-2.3 8-1.5v13c-2.7-.8-5-.2-8 1.5-3-1.7-5.3-2.3-8-1.5Z"/><path d="M12 7v13"/>',
            'folder' => '<path d="M3 6h7l2 2h9v11H3Z"/>',
            'link' => '<path d="M9.5 14.5 8 16a4 4 0 0 1-5.7-5.7l3-3A4 4 0 0 1 11 7"/><path d="m14.5 9.5 1.5-1.5a4 4 0 0 1 5.7 5.7l-3 3A4 4 0 0 1 13 17"/><path d="m8.5 15.5 7-7"/>',
            'megaphone' => '<path d="M4 13h3l9 4V7l-9 4H4Z"/><path d="M7 13l1 5h3"/>',
        ];
        return '<svg viewBox="0 0 24 24" aria-hidden="true">' . ($icons[$name] ?? $icons['book']) . '</svg>';
    }

    public static function design_profile_class(): string {
        $best = ''; $best_num = -1;
        foreach (get_declared_classes() as $class) {
            if (!preg_match('/^Hobby_Depot_Profile_V(\d+)$/', $class, $m)) { continue; }
            if (!is_callable([$class, 'render_header']) || !is_callable([$class, 'render_footer'])) { continue; }
            $num = (int)$m[1];
            if ($num > $best_num) { $best = $class; $best_num = $num; }
        }
        return $best;
    }

    public static function native_shell_open(string $body_extra = ''): bool {
        $profile = self::design_profile_class();
        if ($profile === '') { get_header(); return false; }
        echo '<!doctype html><html ' . get_language_attributes() . '><head><meta charset="' . esc_attr(get_bloginfo('charset')) . '"><meta name="viewport" content="width=device-width, initial-scale=1">';
        wp_head();
        echo '</head><body '; body_class(trim('hd-owned-content-template-v150688 ' . $body_extra)); echo '>';
        if (function_exists('wp_body_open')) { wp_body_open(); }
        call_user_func([$profile, 'render_header']);
        return true;
    }

    public static function native_shell_close(bool $native): void {
        if (!$native) { get_footer(); return; }
        $profile = self::design_profile_class();
        if ($profile !== '') { call_user_func([$profile, 'render_footer']); }
        wp_footer();
        echo '</body></html>';
    }

    private static function magazine_url(): string {
        $page = get_page_by_path('magazin', OBJECT, 'page');
        if ($page instanceof WP_Post && $page->post_status === 'publish') { return (string)get_permalink($page); }
        return home_url('/magazin/');
    }

    public static function world_url(string $slug): string {
        $slug = sanitize_title($slug);
        if ($slug === '' || !isset(HDG_Config::worlds()[$slug])) { return ''; }
        // Pferdeatelier-Prinzip: Themenwelt innerhalb des Glossars filtern, nicht aus dem Glossar herausführen.
        return add_query_arg('glossar_world', $slug, HDG_Core::main_page_url());
    }

    public static function breadcrumb_index(): string {
        $items = [
            ['label' => 'Startseite', 'url' => home_url('/')],
            ['label' => 'Magazin', 'url' => self::magazine_url()],
            ['label' => 'Wissen & Glossar', 'url' => ''],
        ];
        return self::breadcrumb_html($items);
    }

    public static function breadcrumb_single(WP_Post $post, ?WP_Term $world): string {
        $items = [
            ['label' => 'Startseite', 'url' => home_url('/')],
            ['label' => 'Magazin', 'url' => self::magazine_url()],
            ['label' => 'Wissen & Glossar', 'url' => HDG_Core::main_page_url()],
        ];
        if ($world) { $items[] = ['label' => $world->name, 'url' => self::world_url($world->slug)]; }
        $items[] = ['label' => $post->post_title, 'url' => ''];
        return self::breadcrumb_html($items);
    }

    private static function breadcrumb_html(array $items): string {
        $parts = [];
        foreach ($items as $item) {
            $label = trim((string)($item['label'] ?? ''));
            if ($label === '') { continue; }
            $url = trim((string)($item['url'] ?? ''));
            $parts[] = $url !== ''
                ? '<a href="' . esc_url($url) . '">' . esc_html($label) . '</a>'
                : '<span aria-current="page">' . esc_html($label) . '</span>';
        }
        return '<div class="hd-breadcrumb-wrap"><nav class="hd-breadcrumb" aria-label="Breadcrumb">' . implode('<b aria-hidden="true">›</b>', $parts) . '</nav></div>';
    }

    private static function ad_slot(string $slot, string $context = ''): string {
        $html = apply_filters('hdg_glossar_ad_html', '', $slot, $context);
        $has = is_string($html) && trim($html) !== '';
        if (!$has && !current_user_can('edit_posts')) { return ''; }
        $content = $has ? $html : '<span>Werbefläche für späteren Banner</span>';
        return '<section class="hdg-ad ' . ($has ? 'has-content' : 'is-preview') . '" data-hdg-ad-slot="' . esc_attr($slot) . '"><span class="hdg-ad-label">Anzeige</span><div class="hdg-ad-box">' . $content . '</div></section>';
    }

    public static function aside_ad(string $context = ''): string { return str_replace('class="hdg-ad ', 'class="hdg-ad hdg-aside-ad ', self::ad_slot('glossar_single_sidebar', $context)); }

    public static function term_url(WP_Post $post): string {
        if ($post->post_status === 'publish') { return (string)get_permalink($post); }
        if (current_user_can('edit_post', $post->ID)) { return (string)get_preview_post_link($post); }
        return '';
    }

    private static function search_items(string $search, int $limit = 8): array {
        $search = trim($search);
        $len = function_exists('mb_strlen') ? mb_strlen($search, 'UTF-8') : strlen($search);
        if ($len < 2) { return []; }
        $posts = get_posts([
            'post_type' => HDG_Core::POST_TYPE,
            'post_status' => 'publish',
            'posts_per_page' => max(16, $limit * 3),
            'orderby' => 'title',
            'order' => 'ASC',
            'no_found_rows' => true,
            's' => $search,
        ]);
        $out = [];
        foreach ((array)$posts as $post) {
            if (!$post instanceof WP_Post || $post->post_type !== HDG_Core::POST_TYPE || $post->post_status !== 'publish') { continue; }
            $url = self::term_url($post);
            if ($url === '') { continue; }
            $out[] = ['title' => (string)$post->post_title, 'url' => $url];
            if (count($out) >= $limit) { break; }
        }
        return $out;
    }

    public static function ajax_search(): void {
        check_ajax_referer('hdg_search', 'nonce');
        $search = isset($_REQUEST['q']) ? sanitize_text_field(wp_unslash((string)$_REQUEST['q'])) : '';
        wp_send_json_success(['items' => self::search_items($search, 8)]);
    }

    private static function search_script(): string {
        return <<<'HDGSEARCHJS'
<script id="hdg-search-v1025">
(function(){
 var form=document.querySelector('.hdg-search-row'),input=form?form.querySelector('.hdg-search'):null;
 if(!form||!input)return;
 var box=form.querySelector('.hdg-search-suggestions'),status=form.querySelector('[role="status"]'),timer=0,controller=null;
 function clearBox(){box.innerHTML='';box.hidden=true;if(status)status.textContent='';}
 function esc(v){return String(v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c];});}
 function fetchTerms(){
   var q=String(input.value||'').replace(/\s+/g,' ').trim(); if(q.length<2){clearBox();return;}
   if(controller)controller.abort(); controller=(typeof AbortController!=='undefined')?new AbortController():null;
   var body=new URLSearchParams({action:'hdg_search',nonce:form.getAttribute('data-hdg-nonce')||'',q:q});
   fetch(form.getAttribute('data-hdg-ajax-url'),{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString(),signal:controller?controller.signal:undefined,credentials:'same-origin'})
   .then(function(r){if(!r.ok)throw new Error('http');return r.json();})
   .then(function(data){
      var items=data&&data.success&&data.data&&Array.isArray(data.data.items)?data.data.items:[];
      if(!items.length){box.innerHTML='<span class="hdg-search-empty">Keine passenden Begriffe gefunden.</span>';box.hidden=false;if(status)status.textContent='Keine Treffer';return;}
      box.innerHTML=items.slice(0,8).map(function(it){return '<a class="hdg-search-suggestion" href="'+esc(it.url)+'">'+esc(it.title)+'</a>';}).join('');
      box.hidden=false;if(status)status.textContent=items.length+' Treffer';
   }).catch(function(e){if(e&&e.name==='AbortError')return;clearBox();});
 }
 input.addEventListener('input',function(){clearTimeout(timer);timer=setTimeout(fetchTerms,180);});
 input.addEventListener('focus',function(){if(input.value.trim().length>=2)fetchTerms();});
 document.addEventListener('click',function(e){if(!form.contains(e.target))clearBox();});
})();
</script>
HDGSEARCHJS;
    }

    private static function pagination_html(int $paged, int $max_pages, array $state): string {
        if ($max_pages <= 1) { return ''; }
        $base = HDG_Core::main_page_url();
        $out = '<nav class="hdg-pagination" aria-label="Glossar Seiten">';
        for ($i=1; $i <= $max_pages; $i++) {
            $args = ['glossar_page'=>$i];
            foreach (['glossar_s','glossar_world','glossar_letter'] as $key) {
                if (!empty($state[$key])) { $args[$key] = $state[$key]; }
            }
            $url = add_query_arg($args, $base);
            $out .= $i === $paged ? '<span aria-current="page">' . $i . '</span>' : '<a href="' . esc_url($url) . '">' . $i . '</a>';
        }
        return $out . '</nav>';
    }

    private static function render_index(): string {
        $cfg = HDG_Config::get();
        $q = isset($_GET['glossar_s']) ? sanitize_text_field(wp_unslash($_GET['glossar_s'])) : '';
        $letter = isset($_GET['glossar_letter']) ? strtoupper(sanitize_text_field(wp_unslash($_GET['glossar_letter']))) : '';
        $world = isset($_GET['glossar_world']) ? sanitize_title(wp_unslash($_GET['glossar_world'])) : '';
        $paged = max(1, isset($_GET['glossar_page']) ? absint($_GET['glossar_page']) : 1);
        $statuses = current_user_can('edit_posts') ? ['publish','draft'] : ['publish'];
        $args = ['post_type'=>HDG_Core::POST_TYPE,'post_status'=>$statuses,'numberposts'=>-1,'orderby'=>'title','order'=>'ASC'];
        if ($q !== '') { $args['s'] = $q; }
        if ($world !== '' && isset(HDG_Config::worlds()[$world])) { $args['tax_query'] = [['taxonomy'=>HDG_Core::TAXONOMY,'field'=>'slug','terms'=>$world]]; }
        $all = get_posts($args);
        if ($letter !== '' && preg_match('/^[A-Z]$/', $letter)) {
            $all = array_values(array_filter($all, static fn($p) => strtoupper(remove_accents(mb_substr($p->post_title,0,1))) === $letter));
        }
        $per = 16; // Pferdeatelier-Referenz: 4 x 4 Begriffe pro Seite.
        $total = count($all);
        $max_pages = max(1, (int)ceil($total / $per));
        if ($paged > $max_pages) { $paged = $max_pages; }
        $posts = array_slice($all, ($paged - 1) * $per, $per);
        $base = HDG_Core::main_page_url();
        $state = ['glossar_s'=>$q,'glossar_world'=>$world,'glossar_letter'=>$letter];
        $hero = plugins_url('assets/glossar-hero.webp', HDG_FILE);

        ob_start();
        echo '<!-- HDG_VERSION ' . esc_html(HDG_VERSION) . ' --><section class="hdg" data-hdg-central="1" data-hdg-version="' . esc_attr(HDG_VERSION) . '">';
        echo '<section class="hdg-hero"><img src="' . esc_url($hero) . '" alt="Kreativer Hobby-Arbeitsplatz mit verschiedenen Materialien und Werkzeugen" width="1432" height="526" decoding="async" fetchpriority="high"><div class="hdg-hero-copy"><div class="hdg-eyebrow">Wissen</div><h1>Glossar</h1><p>Begriffe rund ums Hobby einfach und verständlich erklärt.</p></div></section>';
        echo '<section class="hdg-search-panel"><form class="hdg-search-row" method="get" action="' . esc_url($base) . '" data-hdg-ajax-url="' . esc_url(admin_url('admin-ajax.php')) . '" data-hdg-nonce="' . esc_attr(wp_create_nonce('hdg_search')) . '"><span class="hdg-search-field"><input class="hdg-search" type="search" name="glossar_s" value="' . esc_attr($q) . '" placeholder="Begriff im Glossar suchen …" autocomplete="off"><span class="hdg-search-suggestions" hidden></span><span class="screen-reader-text" role="status" aria-live="polite"></span></span><button type="submit">Suchen</button></form>';
        echo '<nav class="hdg-az" aria-label="Glossar A bis Z"><a class="' . ($letter === '' ? 'is-active' : '') . '" href="' . esc_url($base) . '">Alle</a>';
        foreach (range('A','Z') as $l) { echo '<a class="' . ($letter === $l ? 'is-active' : '') . '" href="' . esc_url(add_query_arg('glossar_letter',$l,$base)) . '">' . $l . '</a>'; }
        echo '</nav></section>';
        echo '<section class="hdg-world-section"><header class="hdg-section-title"><h2>Themenbereiche</h2></header><nav class="hdg-worlds" aria-label="Nach Hobbywelt filtern">';
        foreach (HDG_Config::worlds() as $slug => $name) {
            $url = add_query_arg('glossar_world', $slug, $base);
            echo '<a class="' . ($world === $slug ? 'is-active' : '') . '" href="' . esc_url($url) . '"><span class="hdg-world-icon">' . self::world_icon($slug) . '</span><span>' . esc_html($name) . '</span></a>';
        }
        echo '</nav></section>';
        echo self::ad_slot('glossar_index_banner', 'index');
        $heading = 'Alle Glossarbegriffe';
        if ($q !== '') {
            $heading = 'Suchergebnisse';
        } elseif ($world !== '' && isset(HDG_Config::worlds()[$world])) {
            $heading = 'Begriffe zum Thema ' . HDG_Config::worlds()[$world];
        } elseif ($letter !== '' && preg_match('/^[A-Z]$/', $letter)) {
            $heading = 'Begriffe mit ' . $letter;
        }
        echo '<section class="hdg-all-head"><h2>' . esc_html($heading) . '</h2><a class="hdg-glossary-home" href="' . esc_url($base) . '">Zur Glossar-Startseite →</a></section>';
        echo self::pagination_html($paged, $max_pages, $state);
        echo '<div class="hdg-grid">';
        foreach ($posts as $p) {
            $def = HDG_Core::get_meta($p->ID, 'short_definition');
            $url = self::term_url($p);
            echo '<article class="hdg-card"><h3>';
            if ($url !== '') { echo '<a href="' . esc_url($url) . '">' . esc_html($p->post_title) . '</a>'; } else { echo esc_html($p->post_title); }
            echo '</h3>';
            if ($def) { echo '<p>' . esc_html($def) . '</p>'; }
            if ($url !== '') { echo '<a class="hdg-card-open" href="' . esc_url($url) . '">Zum Begriff</a>'; }
            echo '</article>';
        }
        if (!$posts) { echo '<p class="hdg-empty">Keine passenden Glossarbegriffe gefunden.</p>'; }
        echo '</div>';
        $bottom_pagination = self::pagination_html($paged, $max_pages, $state);
        echo '<div class="hdg-list-footer' . ($bottom_pagination === '' ? ' no-pages' : '') . '">' . $bottom_pagination . '<a class="hdg-glossary-home" href="' . esc_url($base) . '">Zur Glossar-Startseite →</a></div>';
        echo self::search_script();
        echo '</section>';
        return (string)ob_get_clean();
    }

    public static function related_entries(int $post_id): array {
        $slugs = array_values(array_filter(array_map('sanitize_title', array_map('trim', explode(',', HDG_Core::get_meta($post_id, 'related_slugs'))))));
        $labels_raw = array_values(array_filter(array_map('trim', explode(',', HDG_Core::get_meta($post_id, 'related_labels')))));
        $out = [];
        foreach ($slugs as $i => $slug) {
            $p = get_page_by_path($slug, OBJECT, HDG_Core::POST_TYPE);
            if ($p instanceof WP_Post) {
                $url = self::term_url($p);
                $out[] = ['label' => $p->post_title, 'url' => $url];
                continue;
            }
            $label = $labels_raw[$i] ?? self::humanize_related_slug($slug);
            $out[] = ['label' => $label, 'url' => ''];
        }
        return $out;
    }

    private static function humanize_related_slug(string $slug): string {
        $label = str_replace('-', ' ', $slug);
        $label = implode(' ', array_map('ucfirst', explode(' ', $label)));
        $known = [
            'Schaerfentiefe' => 'Schärfentiefe',
            'Haeutung' => 'Häutung',
        ];
        return $known[$label] ?? $label;
    }

    public static function related_posts(int $post_id): array {
        $out = [];
        foreach (self::related_entries($post_id) as $entry) {
            if (($entry['url'] ?? '') === '') { continue; }
            $slug = sanitize_title((string)$entry['label']);
            $p = get_page_by_path($slug, OBJECT, HDG_Core::POST_TYPE);
            if ($p instanceof WP_Post) { $out[] = $p; }
        }
        return $out;
    }

    public static function term_neighbors(int $post_id): array {
        $statuses = current_user_can('edit_posts') ? ['publish','draft'] : ['publish'];
        $posts = get_posts(['post_type'=>HDG_Core::POST_TYPE,'post_status'=>$statuses,'numberposts'=>-1,'orderby'=>'title','order'=>'ASC']);
        $posts = array_values(array_filter($posts, static fn($p) => $p instanceof WP_Post));
        $idx = null;
        foreach ($posts as $i => $p) { if ((int)$p->ID === $post_id) { $idx = $i; break; } }
        if ($idx === null) { return []; }
        $out = [];
        if ($idx > 0) { $out['prev'] = $posts[$idx-1]; }
        if ($idx + 1 < count($posts)) { $out['next'] = $posts[$idx+1]; }
        return $out;
    }

    public static function term_nav(int $post_id): string {
        $n = self::term_neighbors($post_id);
        $prev = '';
        $next = '';
        if (!empty($n['prev'])) {
            $url = self::term_url($n['prev']);
            if ($url !== '') { $prev = '<a class="prev" href="' . esc_url($url) . '"><small>← Zurück</small><strong>' . esc_html($n['prev']->post_title) . '</strong></a>'; }
        }
        if (!empty($n['next'])) {
            $url = self::term_url($n['next']);
            if ($url !== '') { $next = '<a class="next" href="' . esc_url($url) . '"><small>Weiter →</small><strong>' . esc_html($n['next']->post_title) . '</strong></a>'; }
        }
        if ($prev === '' && $next === '') { return ''; }
        return '<section class="hdg-more-glossary"><div class="hdg-more-head"><strong>Weiterwissen im Glossar</strong><a class="hdg-more-home" href="' . esc_url(HDG_Core::main_page_url()) . '">Zur Glossar-Startseite →</a></div><nav class="hdg-term-nav" aria-label="Weitere Glossarbegriffe"><div>' . $prev . '</div><div>' . $next . '</div></nav></section>';
    }

    public static function world_main_target(?WP_Term $world): ?array {
        if (!$world) { return null; }
        $slug = sanitize_title($world->slug);
        if ($slug === '') { return null; }
        $page = get_page_by_path($slug, OBJECT, 'page');
        if ($page instanceof WP_Post && $page->post_status === 'publish') {
            return ['url'=>(string)get_permalink($page),'label'=>$page->post_title];
        }
        $term = get_term_by('slug', $slug, 'category');
        if ($term instanceof WP_Term) {
            $url = get_term_link($term);
            if (!is_wp_error($url)) { return ['url'=>(string)$url,'label'=>$term->name]; }
        }
        return null;
    }

    public static function primary_target(int $post_id): ?array {
        $type = HDG_Core::get_meta($post_id, 'primary_target_type');
        $id = (int)HDG_Core::get_meta($post_id, 'primary_target_id');
        if ($id < 1) { return null; }
        if ($type === 'page') {
            $p = get_post($id);
            if ($p instanceof WP_Post && $p->post_status === 'publish') { return ['url'=>get_permalink($p),'label'=>get_the_title($p)]; }
        }
        if ($type === 'category') {
            $t = get_term($id, 'category');
            if ($t instanceof WP_Term && !is_wp_error($t)) {
                $url = get_term_link($t);
                if (!is_wp_error($url)) { return ['url'=>$url,'label'=>$t->name]; }
            }
        }
        return null;
    }

    public static function strip_body_links(string $html): string {
        $html = preg_replace('/<a\b[^>]*>/i', '', $html) ?? $html;
        return preg_replace('/<\/a>/i', '', $html) ?? $html;
    }

    public static function aside_section(string $title, string $icon, string $body, string $class = ''): string {
        return '<section class="hdg-aside-card ' . esc_attr($class) . '"><h2>' . self::icon_svg($icon) . esc_html($title) . '</h2>' . $body . '</section>';
    }
}
