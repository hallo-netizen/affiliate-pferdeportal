<?php
if (!defined('ABSPATH')) { exit; }

final class HDG_SEO {
    public static function init(): void {
        add_filter('document_title_parts',[__CLASS__,'title_parts'],20);
        add_action('wp_head',[__CLASS__,'fallback_meta'],1);
        add_filter('get_canonical_url',[__CLASS__,'canonical'],20,2);
        add_filter('wp_robots',[__CLASS__,'robots'],20);
        add_filter('wpseo_title',[__CLASS__,'yoast_title'],20);
        add_filter('wpseo_metadesc',[__CLASS__,'yoast_description'],20);
        add_filter('wpseo_canonical',[__CLASS__,'yoast_canonical'],20);
        add_filter('wpseo_robots',[__CLASS__,'yoast_robots'],20);
        add_action('wp_head',[__CLASS__,'schema'],30);
    }

    private static function term_title(int $id): string { $v=HDG_Core::get_meta($id,'seo_title'); return $v?:self::pattern(HDG_Config::get()['seo_title_pattern'],$id); }
    private static function term_description(int $id): string { $v=HDG_Core::get_meta($id,'seo_description'); return $v?:self::pattern(HDG_Config::get()['seo_description_pattern'],$id); }
    private static function pattern(string $p,int $id): string{return trim(strtr($p,['{term}'=>get_the_title($id),'{site}'=>get_bloginfo('name')]));}
    private static function is_filtered_main(): bool { return HDG_Core::is_index_route() && (isset($_GET['glossar_s'])||isset($_GET['glossar_letter'])||isset($_GET['glossar_world'])||absint($_GET['glossar_page']??1)>1); }

    public static function title_parts(array $parts): array {
        if(HDG_Core::is_index_route()){$parts['title']='Wissen & Glossar';return $parts;}
        if(is_singular(HDG_Core::POST_TYPE))$parts['title']=self::term_title(get_queried_object_id());
        return $parts;
    }
    public static function fallback_meta(): void {
        if(defined('WPSEO_VERSION'))return;
        if(HDG_Core::is_index_route()){echo "\n<meta name=\"description\" content=\"Fachbegriffe aus der Welt der Hobbys kurz und verständlich erklärt.\">";return;}
        if(is_singular(HDG_Core::POST_TYPE))printf("\n<meta name=\"description\" content=\"%s\">",esc_attr(self::term_description(get_queried_object_id())));
    }
    public static function canonical(string $canonical,$post): string { if(HDG_Core::is_index_route())return HDG_Core::main_page_url();if(is_singular(HDG_Core::POST_TYPE))return get_permalink(get_queried_object_id());return $canonical; }
    public static function robots(array $robots): array { if(self::is_filtered_main()){$robots['noindex']=true;unset($robots['index']);}return $robots; }
    public static function yoast_title(string $v): string { if(HDG_Core::is_index_route())return 'Wissen & Glossar';return is_singular(HDG_Core::POST_TYPE)?self::term_title(get_queried_object_id()):$v; }
    public static function yoast_description(string $v): string { if(HDG_Core::is_index_route())return 'Fachbegriffe aus der Welt der Hobbys kurz und verständlich erklärt.';return is_singular(HDG_Core::POST_TYPE)?self::term_description(get_queried_object_id()):$v; }
    public static function yoast_canonical(string $v): string { if(HDG_Core::is_index_route())return HDG_Core::main_page_url();if(is_singular(HDG_Core::POST_TYPE))return get_permalink(get_queried_object_id());return $v; }
    public static function yoast_robots($robots){if(!self::is_filtered_main())return $robots;if(is_array($robots)){$robots['index']='noindex';return $robots;}return 'noindex,follow';}
    public static function schema(): void { if(!is_singular(HDG_Core::POST_TYPE))return;$id=get_queried_object_id();$w=HDG_Core::current_world($id);$data=['@context'=>'https://schema.org','@type'=>'DefinedTerm','name'=>get_the_title($id),'description'=>HDG_Core::get_meta($id,'short_definition'),'url'=>get_permalink($id)];if($w)$data['inDefinedTermSet']=['@type'=>'DefinedTermSet','name'=>'Hobby Depot Glossar – '.$w->name,'url'=>HDG_Core::main_page_url()];echo "\n<script type=\"application/ld+json\">".wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."</script>\n"; }
}
