<?php
if (!defined('ABSPATH')) { exit; }

final class HDG_Config {
    public const OPTION = 'hdg_settings_v1';
    public const CANONICAL_BASE = 'magazin/wissen-glossar';

    public static function worlds(): array {
        return [
            'gestalten' => 'Gestalten',
            'fertigen' => 'Fertigen',
            'technik' => 'Technik',
            'forschen' => 'Forschen',
            'pflanzen' => 'Pflanzen',
            'tiere' => 'Tiere',
            'bewegen' => 'Bewegen',
            'sammeln' => 'Sammeln',
        ];
    }

    public static function defaults(): array {
        return [
            'label' => 'Glossar',
            'main_page_id' => 0,
            'rewrite_base' => self::CANONICAL_BASE,
            'term_segment' => 'begriff',
            'items_per_page' => 16,
            'seo_title_pattern' => '{term} – Bedeutung & Erklärung | {site}',
            'seo_description_pattern' => '{term}: verständlich erklärt im Hobby-Depot-Glossar.',
            'index_mode' => 'index',
        ];
    }

    public static function get(): array {
        $saved = get_option(self::OPTION, []);
        if (!is_array($saved)) { $saved = []; }
        $cfg = array_merge(self::defaults(), $saved);
        // HARDLOCK: Die bestehende Portal-URL darf nie durch alte/fehlerhafte Optionen verdoppelt werden.
        $cfg['rewrite_base'] = self::CANONICAL_BASE;
        $cfg['items_per_page'] = 16;
        return $cfg;
    }

    public static function sanitize(array $input): array {
        $d = self::defaults();
        $segment = sanitize_title($input['term_segment'] ?? $d['term_segment']);
        return [
            'label' => sanitize_text_field($input['label'] ?? $d['label']),
            'main_page_id' => 0,
            'rewrite_base' => self::CANONICAL_BASE,
            'term_segment' => $segment ?: $d['term_segment'],
            'items_per_page' => 16,
            'seo_title_pattern' => sanitize_text_field($input['seo_title_pattern'] ?? $d['seo_title_pattern']),
            'seo_description_pattern' => sanitize_text_field($input['seo_description_pattern'] ?? $d['seo_description_pattern']),
            'index_mode' => in_array(($input['index_mode'] ?? 'index'), ['index','noindex'], true) ? $input['index_mode'] : 'index',
        ];
    }
}
