<?php
/**
 * Temporary Hobby Depot single-article layout preview, integrated into HD-003.
 * No separate plugin. Runs once in the editor's admin session only.
 * No frontend writes, cron, network calls or category creation.
 * Existing article category can be corrected only if real leaf exists.
 */
if (!defined('ABSPATH')) { exit; }

/** Nur bei Aktivierung ausführen. Keine weiteren Schreibwege, kein Cron. */
add_action('admin_init', 'pftk_hd003_demo_import_once_v150787', 100);

function pftk_hd003_demo_import_once_v150787() {
    // Upgrading an active plugin does not fire activation hooks. Admin init does.
    // A stored completion marker prevents repeated creation even after deletion.
    if (get_option('pftk_hd003_demo_import_processed_v150787', false)) { return; }
    if (function_exists('wp_doing_ajax') && wp_doing_ajax()) { return; }
    if (function_exists('wp_doing_cron') && wp_doing_cron()) { return; }
    if (!current_user_can('edit_posts')) {
        return;
    }
    $existing = get_posts(array(
        'post_type' => 'post',
        'post_status' => array('publish','draft','pending','future','private','trash'),
        'posts_per_page' => 1,
        'fields' => 'ids',
        'meta_key' => '_hddemo_layout_key',
        'meta_value' => 'hddemo-zw-vl-20261101',
    ));
    if (!empty($existing)) {
        update_option('_hddemo_layout_post_id', (int)$existing[0], false);
        update_option('pftk_hd003_demo_import_processed_v150787', 1, false);
        return;
    }
    $post_id = wp_insert_post(array(
        'post_type' => 'post',
        'post_status' => 'draft',
        'post_title' => '[DESIGNTEST] Zweileiner oder Vierleiner – welcher Lenkdrachen passt zu dir?',
        'post_name' => 'designtest-zweileiner-oder-vierleiner-hobby-depot',
        'post_excerpt' => 'Beispiel zur Prüfung der Einzelbeiträge auf Hobby Depot. Keine Veröffentlichung, keine Affiliate-Empfehlung.',
        'post_author' => get_current_user_id(),
        'comment_status' => 'closed',
        'ping_status' => 'closed',
    ), true);
    if (is_wp_error($post_id)) {
        wp_die('Testartikel konnte nicht angelegt werden: ' . esc_html($post_id->get_error_message()));
    }
    add_post_meta($post_id, '_hddemo_layout_key', 'hddemo-zw-vl-20261101', true);
    update_post_meta($post_id, '_wpseo_meta-robots-noindex', '1');
    update_post_meta($post_id, '_hddemo_note', 'Nur Designvorschau; jederzeit löschbar; keine echten Affiliate-Links.');

    $asset = dirname(__DIR__) . '/assets/hobby-depot-v150787/lenkdrachen-testfoto.jpg';
    if (!is_readable($asset)) {
        wp_delete_post($post_id, true);
        wp_die('Testartikel nicht angelegt: das mitgelieferte Originalfoto ist im Plugin-ZIP nicht lesbar.');
    }
    $image_bytes = file_get_contents($asset);
    $uploaded = wp_upload_bits('hobby-depot-designtest-lenkdrachen.jpg', null, $image_bytes);
    if (!empty($uploaded['error']) || empty($uploaded['file']) || empty($uploaded['url'])) {
        wp_delete_post($post_id, true);
        wp_die('Testartikel nicht angelegt: WordPress konnte das mitgelieferte Foto nicht in die Mediathek übernehmen.');
    }
    $attachment_id = wp_insert_attachment(array(
        'post_mime_type' => 'image/jpeg',
        'post_title' => 'Hobby Depot Design-Test: Zweileiner in einer Küstenlandschaft',
        'post_excerpt' => 'Illustratives Testfoto – kein abgebildetes Produktmodell.',
        'post_content' => 'Testfoto für den temporären Designbeitrag.',
        'post_status' => 'inherit',
    ), $uploaded['file'], $post_id, true);
    if (is_wp_error($attachment_id) || !$attachment_id) {
        @unlink($uploaded['file']);
        wp_delete_post($post_id, true);
        wp_die('Testartikel nicht angelegt: WordPress konnte keinen Mediathek-Eintrag für das Foto erstellen.');
    }
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $metadata = wp_generate_attachment_metadata($attachment_id, $uploaded['file']);
    if ($metadata && !is_wp_error($metadata)) { wp_update_attachment_metadata($attachment_id, $metadata); }
    update_post_meta($attachment_id, '_wp_attachment_image_alt', 'Person steuert einen bunten Zweileiner-Lenkdrachen am Meer');
    $image_url = wp_get_attachment_url($attachment_id);
    if (!$image_url) {
        wp_delete_attachment($attachment_id, true);
        wp_delete_post($post_id, true);
        wp_die('Testartikel nicht angelegt: Die Foto-URL konnte nicht ermittelt werden.');
    }
    // Das Foto steht EINMAL als Inhaltsbild; kein zusätzliches Beitragsbild, um Doppelbilder zu vermeiden.
    $content = pftk_hd003_demo_content_v150787(esc_url($image_url));
    $updated = wp_update_post(array('ID' => $post_id, 'post_content' => $content), true);
    if (is_wp_error($updated)) {
        wp_delete_attachment($attachment_id, true);
        wp_delete_post($post_id, true);
        wp_die('Testartikel nicht angelegt: Der Inhalt konnte nicht gespeichert werden.');
    }

    // Unterste Kategorie nur verwenden, wenn sie bereits existiert. Nie selbst Kategorien erzeugen.
    $cat = get_term_by('slug', 'sportdrachen-drachen-leinen', 'category');
    if ($cat && !is_wp_error($cat)) {
        wp_set_post_terms($post_id, array((int)$cat->term_id), 'category', false);
    }
    update_option('_hddemo_layout_post_id', $post_id, false);
    update_option('pftk_hd003_demo_import_processed_v150787', 1, false);
}

/** Echte Links nur zu bereits vorhandenen veröffentlichten Seiten / belegten Kategorien. */
function pftk_hd003_demo_internal_links_v150787() {
    $links = array();
    $page = get_page_by_path('sportdrachen', OBJECT, 'page');
    if ($page && $page->post_status === 'publish') {
        $links[] = '<li><a href="' . esc_url(get_permalink($page)) . '">Sportdrachen: Überblick und Hobbyseite</a></li>';
    }
    $names = array(
        'sportdrachen-einstieg-wind' => 'Einstieg &amp; Wind',
        'sportdrachen-steuerung-figuren' => 'Steuerung &amp; Figuren',
        'sportdrachen-setup-pflege-reparatur' => 'Setup, Pflege &amp; Reparatur',
        'sportdrachen-vergleich-kaufberatung' => 'Vergleich &amp; Kaufberatung',
    );
    foreach ($names as $slug => $label) {
        $term = get_term_by('slug', $slug, 'category');
        if ($term && !is_wp_error($term) && (int)$term->count > 0) {
            $url = get_term_link($term);
            if (!is_wp_error($url)) { $links[] = '<li><a href="' . esc_url($url) . '">' . $label . '</a></li>'; }
        }
    }
    if (!$links) {
        // Keine erfundenen oder leeren URLs: funktionsfähige interne Sprungmarken als Layoutmuster.
        $links[] = '<li><a href="#hddemo-vergleich">Zum Vergleich in diesem Artikel</a></li>';
        $links[] = '<li><a href="#hddemo-praxis">Zur Checkliste in diesem Artikel</a></li>';
    }
    return '<ul class="wp-block-list">' . implode('', $links) . '</ul>';
}

function pftk_hd003_demo_content_v150787($image_url) {
    $related = pftk_hd003_demo_internal_links_v150787();
    $html = <<<'HTML'
<!-- wp:paragraph {"className":"hddemo-kicker"} -->
<p class="hddemo-kicker"><strong>HOBBY DEPOT · DESIGNTEST · SPORTDRACHEN / DRACHEN &amp; LEINEN</strong></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size">Zwei Leinen reichen für dynamische Kurven. Vier Leinen ermöglichen zusätzliche Kontrolle – aber auch einen anderen Einstieg. Hier siehst du, welche Unterschiede beim Kauf und beim Fliegen wirklich zählen.</p>
<!-- /wp:paragraph -->
<!-- wp:image {"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="__IMAGE_URL__" alt="Person mit buntem Zweileiner-Lenkdrachen auf einer weiten Wiese an der Küste"/><figcaption class="wp-element-caption">Beispielfoto für die Designprüfung: ein Zweileiner im Flug. Kein konkretes Produktmodell abgebildet.</figcaption></figure>
<!-- /wp:image -->
<!-- wp:group {"style":{"border":{"width":"1px","color":"#d6e8dd","radius":"12px"},"spacing":{"padding":{"top":"18px","bottom":"18px","left":"22px","right":"22px"}}}} -->
<div class="wp-block-group" style="border-color:#d6e8dd;border-width:1px;border-radius:12px;padding-top:18px;padding-right:22px;padding-bottom:18px;padding-left:22px"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Auf einen Blick</h3>
<!-- /wp:heading -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item --><li><strong>Zweileiner:</strong> lenken über links und rechts; gut für den Einstieg.</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>Vierleiner:</strong> zusätzliche Bremsleinen für präzisere Bewegungen.</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>Entscheidend:</strong> Erfahrung, Flugstil, Wind und Platz.</li><!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->
<!-- wp:html -->
<nav aria-label="Inhaltsverzeichnis des Testartikels" style="border:1px solid #dbe6e1;border-radius:12px;padding:18px 22px;margin:26px 0;background:#f6faf7"><strong>In diesem Artikel</strong><ol style="margin:12px 0 0 20px"><li><a href="#hddemo-unterschied">Steuerung und Fluggefühl</a></li><li><a href="#hddemo-vergleich">Vergleich als Tabelle</a></li><li><a href="#hddemo-praxis">Checkliste und erste Flugversuche</a></li><li><a href="#hddemo-produkte">Konkrete Produktbeispiele</a></li><li><a href="#hddemo-faq">Häufige Fragen</a></li></ol></nav>
<!-- /wp:html -->
<!-- wp:heading {"level":2,"anchor":"hddemo-unterschied"} -->
<h2 class="wp-block-heading" id="hddemo-unterschied">Was unterscheidet Zweileiner und Vierleiner?</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Ein <strong>Zweileiner</strong> reagiert auf unterschiedliche Zugbewegungen der linken und rechten Steuerleine. Wer rechts zieht, verändert die Flugrichtung nach rechts; durch wechselnde Impulse entstehen Kurven, Achter und mit Übung Schleifen. Für Anfänger ist diese Steuerungsart meist leichter zu begreifen.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>Ein <strong>Vierleiner</strong> ergänzt die beiden Steuerleinen um Bremsleinen. Je nach Modell kannst du damit die Fluggeschwindigkeit verändern, den Drachen kontrolliert stoppen und spezielle Figuren fliegen. Das verlangt eine bewusstere Handhaltung und mehr Übung.</p>
<!-- /wp:paragraph -->
<!-- wp:quote -->
<blockquote class="wp-block-quote"><p><strong>Merksatz:</strong> Mehr Leinen bedeuten nicht automatisch mehr Spaß. Entscheidend ist, welche Art von Flugbewegungen du lernen möchtest.</p></blockquote>
<!-- /wp:quote -->
<!-- wp:heading {"level":2,"anchor":"hddemo-vergleich"} -->
<h2 class="wp-block-heading" id="hddemo-vergleich">Zweileiner und Vierleiner im direkten Vergleich</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Die folgende Tabelle ist bewusst Teil des Designtests: Wir prüfen, wie Tabellen auf dem Desktop und auf dem Handy dargestellt werden.</p>
<!-- /wp:paragraph -->
<!-- wp:table {"hasFixedLayout":false} -->
<figure class="wp-block-table"><table><thead><tr><th>Kriterium</th><th>Zweileiner</th><th>Vierleiner</th></tr></thead><tbody><tr><td>Steuerung</td><td>Links / rechts ziehen</td><td>Steuern und zusätzlich bremsen</td></tr><tr><td>Einstieg</td><td>Meist unkomplizierter</td><td>Mehr Koordination notwendig</td></tr><tr><td>Fluggefühl</td><td>Dynamische Kurven und Loopings</td><td>Präzises Positionieren und Stoppen</td></tr><tr><td>Ausrüstung</td><td>Zwei Leinen und passende Griffe</td><td>Vier Leinen und passende Handles</td></tr><tr><td>Passt gut zu</td><td>Ersten Flugversuchen und Sportflug</td><td>Piloten mit Interesse an präziser Kontrolle</td></tr></tbody></table><figcaption class="wp-element-caption">Die Eigenschaften hängen immer auch vom konkreten Modell ab.</figcaption></figure>
<!-- /wp:table -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Für wen ist welcher Drachen sinnvoll?</h3>
<!-- /wp:heading -->
<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item --><li><strong>Du willst erst einmal sicher starten?</strong> Ein gutmütiger Zweileiner ist oft der einfachere Weg.</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>Du möchtest schnelle Kurven und klassische Flugfiguren?</strong> Schau dir sportliche Zweileiner an.</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>Du reizt präzises Schweben und Abbremsen?</strong> Ein Vierleiner kann besser zu deinen Zielen passen.</li><!-- /wp:list-item --></ul>
<!-- /wp:list -->
<!-- wp:html -->
<aside aria-label="Bannerplatz Testartikel" style="margin:32px 0;padding:24px 26px;border:2px solid #d2dfd6;border-radius:14px;background:linear-gradient(112deg,#eff7f2,#f5fbf8);text-align:center"><div style="font-size:11px;letter-spacing:.11em;text-transform:uppercase;color:#597869;font-weight:700">Anzeige · Bannerplatz im Artikel · Designmuster</div><h3 style="margin:10px 0;color:#194c39;font-size:25px">Drachen und Zubehör passend zum Flugstil</h3><p style="margin:10px auto 18px;max-width:550px">Hier könnte später ein automatisch befüllter Partnerbanner erscheinen – unabhängig vom normalen Ratgebertext.</p><a href="https://www.invento-hq.com/artikeluebersicht/Lenkdrachen.aspx" rel="noopener noreferrer" target="_blank" style="display:inline-block;padding:12px 22px;background:#216b4b;color:#ffffff;text-decoration:none;border-radius:7px;font-weight:700">Beispiel: Herstellerübersicht ansehen</a><p style="font-size:12px;margin:12px 0 0;color:#607267">Nur Testbanner. Noch keine Affiliate-Verknüpfung.</p></aside>
<!-- /wp:html -->
<!-- wp:heading {"level":2,"anchor":"hddemo-praxis"} -->
<h2 class="wp-block-heading" id="hddemo-praxis">Vor dem ersten Flug: kurze Checkliste</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Gerade bei einem neuen Sportdrachen entscheidet nicht die teuerste Ausstattung über den Einstieg, sondern ein sauberer Aufbau und die passende Windstärke. Diese nummerierte Liste zeigt zugleich, wie Arbeitsschritte im späteren Artikeldesign wirken können.</p>
<!-- /wp:paragraph -->
<!-- wp:list {"ordered":true} -->
<ol class="wp-block-list"><!-- wp:list-item --><li><strong>Windbereich prüfen:</strong> Beachte die Herstellerangaben deines konkreten Modells.</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>Platz wählen:</strong> Nutze eine ausreichend große, freie Flugfläche mit Abstand zu Menschen und Hindernissen.</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>Leinen kontrollieren:</strong> Sie sollten unbeschädigt, passend dimensioniert und nicht verdreht sein.</li><!-- /wp:list-item --><!-- wp:list-item --><li><strong>Ruhig beginnen:</strong> Starte mit einfachen Lenkbewegungen und steigere die Schwierigkeit erst nach sicheren Flugversuchen.</li><!-- /wp:list-item --></ol>
<!-- /wp:list -->
<!-- wp:group {"style":{"border":{"left":{"color":"#df9d36","width":"4px"}},"spacing":{"padding":{"top":"16px","bottom":"16px","left":"20px","right":"20px"}}}} -->
<div class="wp-block-group" style="border-left-color:#df9d36;border-left-width:4px;padding-top:16px;padding-right:20px;padding-bottom:16px;padding-left:20px;background:#fff8ed"><!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Wichtig für die Sicherheit</h3>
<!-- /wp:heading --><!-- wp:paragraph -->
<p>Nie in der Nähe von Stromleitungen, Straßen oder bei Gewitter fliegen. Bei starkem oder böigem Wind den Start verschieben. Modellbezogene Alters- und Windangaben sind maßgeblich.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
<!-- wp:heading {"level":2,"anchor":"hddemo-produkte"} -->
<h2 class="wp-block-heading" id="hddemo-produkte">Drei konkrete Modelle als Muster für Produktkacheln</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Die Modelle und Herstellerlinks sind real, aber die folgenden Karten dienen nur der <strong>Layoutprüfung</strong>. Es gibt hier keine automatisch aktualisierten Preise und keine eingerichteten Affiliate-Links.</p>
<!-- /wp:paragraph -->
<!-- wp:html -->
<div class="hddemo-product-grid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(215px,1fr));gap:16px;margin:24px 0 26px"><article style="padding:18px;border:1px solid #dce7de;border-radius:12px;background:white"><div style="height:70px;display:flex;align-items:center;justify-content:center;background:#edf7f1;border-radius:9px;color:#246c4c;font-size:12px;font-weight:700">PRODUKTKACHEL · ZWEILEINER</div><h3 style="font-size:19px;margin:16px 0 7px">HQ Bebop Prisma R2F</h3><p style="font-size:14px;margin:7px 0">145 cm Spannweite · zwei 20-m-Leinen · 3–5 Bft.</p><p style="font-size:13px;color:#657367">Preisfeld: Live-Partnerdaten vorgesehen</p><a href="https://www.invento-hq.com/artikeldetails/Bebop-Prisma-R2F.aspx" rel="noopener noreferrer" target="_blank" style="display:inline-block;padding:10px 14px;background:#246b4d;color:white;border-radius:6px;text-decoration:none">Herstellerdetails</a></article><article style="padding:18px;border:1px solid #dce7de;border-radius:12px;background:white"><div style="height:70px;display:flex;align-items:center;justify-content:center;background:#edf7f1;border-radius:9px;color:#246c4c;font-size:12px;font-weight:700">PRODUKTKACHEL · ZWEILEINER</div><h3 style="font-size:19px;margin:16px 0 7px">HQ Quickstep II Rainbow</h3><p style="font-size:14px;margin:7px 0">135 cm Spannweite · zwei 20-m-Leinen · 2–5 Bft.</p><p style="font-size:13px;color:#657367">Preisfeld: Live-Partnerdaten vorgesehen</p><a href="https://www.invento-hq.com/artikeldetails/Quickstep-II-Rainbow.aspx" rel="noopener noreferrer" target="_blank" style="display:inline-block;padding:10px 14px;background:#246b4d;color:white;border-radius:6px;text-decoration:none">Herstellerdetails</a></article><article style="padding:18px;border:1px solid #dce7de;border-radius:12px;background:white"><div style="height:70px;display:flex;align-items:center;justify-content:center;background:#edf7f1;border-radius:9px;color:#246c4c;font-size:12px;font-weight:700">PRODUKTKACHEL · VIERLEINER</div><h3 style="font-size:19px;margin:16px 0 7px">HQ Verve Aqua</h3><p style="font-size:14px;margin:7px 0">Vierleiner · 252 cm Spannweite · für präziseres Fliegen</p><p style="font-size:13px;color:#657367">Preisfeld: Live-Partnerdaten vorgesehen</p><a href="https://www.invento-hq.com/artikeluebersicht/Vierleiner.aspx" rel="noopener noreferrer" target="_blank" style="display:inline-block;padding:10px 14px;background:#246b4d;color:white;border-radius:6px;text-decoration:none">Herstellerdetails</a></article></div>
<!-- /wp:html -->
<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Passende Themen bei Hobby Depot</h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p>Diese Fläche zeigt spätere redaktionelle Querverweise. Links erscheinen nur, wenn passende Seiten oder bereits gefüllte Kategorien in WordPress tatsächlich vorhanden sind.</p>
<!-- /wp:paragraph -->
<!-- wp:html -->
<div class="hddemo-related" style="padding:16px 22px;border:1px solid #d6e5dd;background:#f8faf8;border-radius:10px">__RELATED_LINKS__</div>
<!-- /wp:html -->
<!-- wp:heading {"level":2,"anchor":"hddemo-faq"} -->
<h2 class="wp-block-heading" id="hddemo-faq">Häufige Fragen</h2>
<!-- /wp:heading -->
<!-- wp:details -->
<details class="wp-block-details"><summary>Sind vier Leinen grundsätzlich besser als zwei?</summary><p>Nein. Beide Bauarten eignen sich für unterschiedliche Flugstile. Zweileiner können beim Lernen einfacher sein; Vierleiner erlauben zusätzliche Steuerbewegungen.</p></details>
<!-- /wp:details -->
<!-- wp:details -->
<details class="wp-block-details"><summary>Kann ich mit einem Zweileiner bereits Tricks üben?</summary><p>Ja, abhängig vom Modell und vom eigenen Können sind viele Kurven und Flugfiguren möglich. Für gezielte Trickübungen gibt es entsprechend abgestimmte Drachen.</p></details>
<!-- /wp:details -->
<!-- wp:paragraph -->
<p><strong>Fazit:</strong> Für den ersten kontrollierten Lenkdrachenflug ist ein Zweileiner häufig der übersichtlichere Weg. Wer nach einiger Übung besonders präzise Manöver ausprobieren möchte, findet in Vierleinern eine andere Form der Herausforderung.</p>
<!-- /wp:paragraph -->
<!-- wp:separator -->
<hr class="wp-block-separator has-alpha-channel-opacity"/>
<!-- /wp:separator -->
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><em>Nur für die Gestaltung: Dieser Beitrag ist ein nicht veröffentlichter Test-Entwurf. Foto und Produktflächen illustrieren die Darstellung. Herstellerlinks sind keine Affiliate-Links.</em></p>
<!-- /wp:paragraph -->
HTML;
    return str_replace(array('__IMAGE_URL__','__RELATED_LINKS__'), array($image_url,$related), $html);
}

add_action('admin_notices','pftk_hd003_demo_admin_notice_v150787');
function pftk_hd003_demo_admin_notice_v150787() {
    if (!current_user_can('edit_posts')) { return; }
    $id = (int)get_option('_hddemo_layout_post_id', 0);
    if (!$id || !get_post($id)) { return; }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen || ($screen->base !== 'plugins' && $screen->id !== 'edit-post' && $screen->id !== 'edit-posts')) { return; }
    $edit = get_edit_post_link($id);
    $preview = get_preview_post_link($id);
    echo '<div class="notice notice-success is-dismissible"><p><strong>Hobby Depot Design-Test:</strong> Ein Entwurf mit Foto wurde angelegt. <a href="' . esc_url($edit) . '">Beitrag bearbeiten</a> &middot; <a href="' . esc_url($preview) . '" target="_blank" rel="noopener noreferrer">Frontend-Vorschau öffnen</a>. Der Testartikel ist ein Entwurf und kann später einzeln gelöscht werden. Das Designplugin bleibt aktiv.</p></div>';
}

/**
 * 1.50.788: rectify ONLY the published/preview design-test post's taxonomy.
 * No category is created; no post text, status, or any other article is changed.
 * One read-only check on authorized admin visits until the real leaf exists.
 */
add_action('admin_init','pftk_hd003_demo_repair_category_v150788',110);
function pftk_hd003_demo_repair_category_v150788() {
    if (get_option('pftk_hd003_demo_category_repaired_v150788',false)) { return; }
    if (!current_user_can('edit_posts')) { return; }
    if ((function_exists('wp_doing_ajax') && wp_doing_ajax())
        || (function_exists('wp_doing_cron') && wp_doing_cron())) { return; }
    $posts=get_posts(['post_type'=>'post','post_status'=>['publish','draft','future','pending','private'],
        'posts_per_page'=>1,'meta_key'=>'_hddemo_layout_key',
        'meta_value'=>'hddemo-zw-vl-20261101','fields'=>'ids','no_found_rows'=>true]);
    if (!$posts) { return; } // Deleted test article stays deleted.
    $post_id=(int)$posts[0];
    $term=get_term_by('slug','sportdrachen-drachen-leinen','category');
    if (!$term || is_wp_error($term) || !$term instanceof WP_Term) { return; }
    $attached=wp_get_post_terms($post_id,'category',['fields'=>'ids']);
    if (is_wp_error($attached)) { return; }
    if (!in_array((int)$term->term_id,array_map('intval',(array)$attached),true)) {
        $saved=wp_set_post_terms($post_id,[(int)$term->term_id],'category',false);
        if (is_wp_error($saved)) { return; }
    }
    update_option('pftk_hd003_demo_category_repaired_v150788',1,false);
}
