# Hobby Depot – Bildzentrale 1.50.769

Eine Bildentscheidung pro Hobby: `hobby_image_center_v150769`.
Eigener Master geht immer vor einem WordPress-Bild, dann HD007-gepruefter Master, Batik-Pilot, explizites WordPress-Titelbild der exakt gleichen Einzelseite, und zuletzt die fuenf geprueften breiten Zweitnutzungen. Keine generischen Elternbilder, keine Bildersuche im Frontend, kein Ersatzfoto.

Gleiche Bild-URL fuer Hobbyfinder und HD003-Hero; ein kleines praesentationsseitiges Sync-Skript vereinheitlicht HD007-Hobbyregister-Detailseiten, ohne HD007 zu veraendern. Ohne Bild wird ein moegliches generisches Detail-Hero verborgen.

Admin: WordPress-Menue > Bildzentrale (nur lesen). Keine neuen Tabellen, Datenoptionen oder Uploadregeln. Vorhandenes Archiv und Bilder unveraendert.

Live-WordPress nicht getestet; positive und negative lokal PHP und JS-DOM simuliert.
