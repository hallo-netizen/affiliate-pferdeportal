<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="primary" class="site-main pftk-glossar-group-main-v150534 pftk-glossar-main-v150481">
<?php if (class_exists('Pferde_Template_Kit')) { Pferde_Template_Kit::glossary_group_page_v150481(); } ?>
</main>
<?php get_footer();
