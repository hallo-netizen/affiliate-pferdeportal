<?php
if (!defined('ABSPATH')) { exit; }
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class('hd-owned-content-template-v150709'); ?>>
<?php
if (function_exists('wp_body_open')) { wp_body_open(); }
Hobby_Depot_Profile_V150709::render_header();
echo Hobby_Depot_Profile_V150709::render_owned_content();
Hobby_Depot_Profile_V150709::render_footer();
wp_footer();
?>
</body>
</html>
