<?php
if (!defined('ABSPATH')) { exit; }
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class('hd-owned-search-template-v150732'); ?>>
<?php
if (function_exists('wp_body_open')) { wp_body_open(); }
Hobby_Depot_Profile_V150709::render_header();
echo Hobby_Depot_Profile_V150709::render_search_results_page_v150732();
Hobby_Depot_Profile_V150709::render_footer();
?>
<script id="hd-search-more-v150789">(function(){
  document.addEventListener('click',function(e){
    var button=e.target.closest('button[data-hd-search-more="1"]');
    if(!button)return;
    var id=button.getAttribute('aria-controls');
    var list=document.getElementById(id);
    if(!list)return;
    var hidden=Array.prototype.slice.call(list.querySelectorAll('[data-hd-search-hidden="1"]'));
    hidden.slice(0,5).forEach(function(item){item.removeAttribute('hidden');item.removeAttribute('data-hd-search-hidden');});
    var remaining=list.querySelectorAll('[data-hd-search-hidden="1"]').length;
    if(remaining===0){button.remove();}
    else{var small=button.querySelector('small');if(small)small.textContent='('+Math.min(remaining,5)+' weitere)';}
  });
})();</script>
<?php
wp_footer();
?>
</body>
</html>
