<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<div id="content" class="site-content">
  <div class="ast-container">
    <?php echo Pferde_Template_Kit::render_leaf_category_archive_v150273(); ?>
  </div>
</div>
<?php get_footer();
