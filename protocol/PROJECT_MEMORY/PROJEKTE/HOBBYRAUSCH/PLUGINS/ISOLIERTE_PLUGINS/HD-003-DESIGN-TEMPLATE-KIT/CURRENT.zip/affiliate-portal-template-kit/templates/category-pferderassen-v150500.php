<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="primary" class="site-main pftk-rassen-main-v150500">
<?php if (class_exists('Pferde_Template_Kit')) { Pferde_Template_Kit::horse_breeds_category_page_v150500(); } ?>
</main>
<?php get_footer();
