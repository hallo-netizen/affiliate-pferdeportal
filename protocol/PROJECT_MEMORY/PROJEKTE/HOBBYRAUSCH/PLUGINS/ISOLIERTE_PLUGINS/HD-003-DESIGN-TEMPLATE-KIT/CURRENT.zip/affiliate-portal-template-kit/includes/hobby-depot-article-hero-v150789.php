<?php
/**
 * Hobby Depot: exactly one article header template for published/draft previews.
 * Rendered by the existing HD-003 profile between breadcrumb and article text.
 * A featured image wins; otherwise the first real content image is used.
 * All type, fonts, fades and text live in the template, not in image files.
 * Later text production may provide _hd_article_hero_claim (plain text only).
 */
if (!defined('ABSPATH')) { exit; }

function hd003_article_hero_data_v150789($post) {
    if (!$post instanceof WP_Post || (string)$post->post_type !== 'post') { return []; }
    $src = '';
    $from_inline = false;
    if (function_exists('get_the_post_thumbnail_url')) {
        $src = (string)get_the_post_thumbnail_url((int)$post->ID, 'full');
    }
    if ($src === '') {
        // Gutenberg image is a real content image. Never invent a substitute picture.
        $raw = (string)$post->post_content;
        if (preg_match('~<figure\b[^>]*\bclass=["\'][^"\']*\bwp-block-image\b[^"\']*["\'][^>]*>\s*(?:<a\b[^>]*>)?\s*<img\b[^>]*\bsrc=["\']([^"\']+)["\']~is', $raw, $m)) {
            $src = html_entity_decode((string)$m[1], ENT_QUOTES, 'UTF-8');
            $from_inline = true;
        }
    }
    if ($src === '') {
        // Legacy WordPress image blocks may not use a figure wrapper.
        if (preg_match('~<img\b[^>]*\bsrc=["\']([^"\']+)["\']~is', (string)$post->post_content, $m)) {
            $src = html_entity_decode((string)$m[1], ENT_QUOTES, 'UTF-8');
            $from_inline = true;
        }
    }
    // Trust only a WordPress upload or the site's own image address; never allow
    // data: or javascript: values to be interpolated into a visible image.
    $src = $src !== '' ? esc_url_raw($src, ['http','https']) : '';
    $claim = trim(wp_strip_all_tags((string)get_post_meta((int)$post->ID, '_hd_article_hero_claim', true)));
    if ($claim === '' && (string)get_post_meta((int)$post->ID, '_hddemo_layout_key', true) === 'hddemo-zw-vl-20261101') {
        $claim = 'Zwei oder vier Leinen? Finde deinen Flugstil.';
    }
    if ($claim === '') {
        $excerpt = trim(wp_strip_all_tags((string)$post->post_excerpt));
        if ($excerpt !== '' && stripos($excerpt,'Designvorschau') === false) {
            $claim = wp_trim_words($excerpt, 11, '…');
        }
    }
    if ($claim === '') {
        $claim = 'Wissen, das dein Hobby weiterbringt.';
    }
    if (function_exists('mb_substr')) { $claim = mb_substr($claim, 0, 104, 'UTF-8'); }
    else { $claim = substr($claim, 0, 104); }
    return ['src'=>$src, 'claim'=>$claim, 'inline'=>$from_inline];
}

function hd003_article_hero_markup_v150789($post) {
    if (!$post instanceof WP_Post || (string)$post->post_type !== 'post') { return ''; }
    $data = hd003_article_hero_data_v150789($post);
    $title = trim((string)get_the_title($post));
    $html = '<div class="hd-article-top-v150789"><div class="hd-article-heading-v150789">'
      . '<span class="hd-article-kicker-v150789">Fachartikel</span>'
      . '<h1>' . esc_html($title) . '</h1></div>';
    if (!empty($data['src'])) {
        $html .= '<figure class="hd-article-photo-hero-v150789" data-hd-hero-source="' . esc_attr($data['src']) . '">'
           . '<img src="' . esc_url($data['src']) . '" alt="' . esc_attr($title) . '" decoding="async" fetchpriority="high">'
           . '<div class="hd-article-hero-shade-v150789" aria-hidden="true"></div>'
           . '<figcaption class="hd-article-hero-claim-v150789"><span>' . esc_html($data['claim']) . '</span></figcaption>'
           . '</figure>';
    } else {
        // No image from the Bildzentrale yet: no fake photo or fabricated image URL.
        $html .= '<p class="hd-article-no-photo-v150789">' . esc_html($data['claim']) . '</p>';
    }
    return $html . '</div>';
}

function hd003_article_hero_body_classes_v150789($classes) {
    if (!is_admin() && function_exists('is_singular') && is_singular('post')) {
        $classes[] = 'hd-article-hero-v150789';
        $post = function_exists('get_queried_object') ? get_queried_object() : null;
        $data = hd003_article_hero_data_v150789($post);
        if (!empty($data['inline']) && !empty($data['src'])) {
            $classes[] = 'hd-article-inline-image-v150789';
        }
    }
    return $classes;
}
add_filter('body_class', 'hd003_article_hero_body_classes_v150789', 25);

function hd003_article_hero_style_v150789() {
    if (is_admin() || !function_exists('is_singular') || !is_singular('post')) { return; }
    ?>
<style id="hd003-article-hero-v150789">
/* An article has ONE breadcrumb, ONE h1 and ONE hero picture, if image exists. */
body.pftk-design-profile-hobby-depot.single-post .hd-universal-top-v150616{padding-bottom:0!important}
body.pftk-design-profile-hobby-depot.single-post .hd-universal-top-v150616 .hd-breadcrumb-wrap{margin-top:16px!important;margin-bottom:12px!important}
body.pftk-design-profile-hobby-depot.single-post .hd-article-top-v150789{width:min(calc(100% - 72px),1200px);margin:0 auto 12px!important}
body.pftk-design-profile-hobby-depot.single-post .hd-article-heading-v150789{padding:9px 0 18px!important;max-width:100%;border:0!important;background:#fff!important}
body.pftk-design-profile-hobby-depot.single-post .hd-article-kicker-v150789{display:block;margin:0 0 9px;color:#0d8c84;font:800 11px/1.3 -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;letter-spacing:.14em;text-transform:uppercase}
body.pftk-design-profile-hobby-depot.single-post .hd-article-heading-v150789 h1{display:block!important;margin:0!important;padding:0!important;max-width:1080px!important;border:0!important;background:transparent!important;color:#18363b!important;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif!important;font-size:clamp(32px,3.25vw,49px)!important;font-weight:800!important;line-height:1.13!important;letter-spacing:-.033em!important;text-align:left!important}
body.pftk-design-profile-hobby-depot.single-post .hd-article-photo-hero-v150789{position:relative!important;isolation:isolate!important;display:block!important;width:100%!important;max-width:none!important;height:clamp(280px,29vw,395px)!important;margin:0!important;padding:0!important;overflow:hidden!important;border:0!important;border-radius:2px!important;background:#f4f1e9!important;box-shadow:none!important;transform:none!important}
body.pftk-design-profile-hobby-depot.single-post .hd-article-photo-hero-v150789>img{position:absolute!important;z-index:0!important;inset:0!important;display:block!important;width:100%!important;height:100%!important;min-height:0!important;max-width:none!important;object-fit:cover!important;object-position:66% center!important;margin:0!important;border:0!important;border-radius:0!important;transform:none!important}
body.pftk-design-profile-hobby-depot.single-post .hd-article-hero-shade-v150789{position:absolute!important;z-index:1!important;inset:0!important;pointer-events:none!important;background:linear-gradient(90deg,#f5f1e9 0%,rgba(245,241,233,.98) 15%,rgba(245,241,233,.91) 29%,rgba(245,241,233,.56) 48%,rgba(245,241,233,.03) 67%,transparent 81%)!important}
body.pftk-design-profile-hobby-depot.single-post .hd-article-hero-claim-v150789{position:absolute!important;z-index:2!important;top:50%!important;left:clamp(20px,4.5vw,60px)!important;width:min(48%,520px)!important;max-width:520px!important;margin:0!important;padding:0 0 20px!important;transform:translateY(-50%)!important;white-space:normal!important;overflow:visible!important;color:#2b8a6c!important;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif!important;font-size:clamp(25px,2.55vw,37px)!important;font-weight:750!important;line-height:1.22!important;letter-spacing:-.025em!important;text-overflow:clip!important}
body.pftk-design-profile-hobby-depot.single-post .hd-article-hero-claim-v150789>span{position:relative!important;z-index:2!important;display:block!important}
body.pftk-design-profile-hobby-depot.single-post .hd-article-hero-claim-v150789::after{content:""!important;position:absolute!important;z-index:1!important;left:0!important;bottom:4px!important;width:72%!important;height:13px!important;border:0!important;border-radius:55% 37% 54% 36%!important;background:linear-gradient(96deg,rgba(35,151,140,.18),rgba(26,133,137,.39) 55%,rgba(197,162,112,.08))!important;filter:blur(4px)!important;transform:rotate(-1.4deg)!important;pointer-events:none!important}
body.pftk-design-profile-hobby-depot.single-post .hd-article-no-photo-v150789{color:#2b8a6c;font-size:22px;margin:0 0 18px}
/* Legacy Pferde single title and separate featured photograph are not Hobby Depot's design. */
html body.pftk-design-profile-hobby-depot.single-post #content article.post .entry-header,
html body.pftk-design-profile-hobby-depot.single-post #content article.post .ast-single-post-featured-section,
html body.pftk-design-profile-hobby-depot.single-post #content article.post .post-thumb,
html body.pftk-design-profile-hobby-depot.single-post #content article.post .post-thumb-img-content,
html body.pftk-design-profile-hobby-depot.single-post #content article.post .ast-blog-featured-section{display:none!important}
/* Inline image was re-used as hero. Keep content but avoid its duplicate photograph. */
html body.pftk-design-profile-hobby-depot.single-post.hd-article-inline-image-v150789 #content article.post .entry-content figure.wp-block-image:first-of-type{display:none!important}
html body.pftk-design-profile-hobby-depot.single-post.hd-article-inline-image-v150789 #content article.post .entry-content>.wp-block-image:first-of-type{display:none!important}
/* No legacy horse-article intro picture frame or card around the first paragraph. */
html body.pftk-design-profile-hobby-depot.single-post #content article.post .entry-content{width:min(calc(100vw - 72px),880px)!important;max-width:880px!important;margin:26px auto 70px!important;padding:0!important;transform:none!important;background:#fff!important}
html body.pftk-design-profile-hobby-depot.single-post #content article.post .entry-content>.pa-photo-intro-frame,
html body.pftk-design-profile-hobby-depot.single-post #content article.post .entry-content>.pa-article-intro{background:transparent!important;border:0!important;border-radius:0!important;padding:0!important;box-shadow:none!important}
@media(max-width:760px){
  body.pftk-design-profile-hobby-depot.single-post .hd-article-top-v150789{width:calc(100% - 24px)!important}
  body.pftk-design-profile-hobby-depot.single-post .hd-article-heading-v150789{padding:8px 0 14px!important}
  body.pftk-design-profile-hobby-depot.single-post .hd-article-heading-v150789 h1{font-size:clamp(28px,7vw,37px)!important}
  body.pftk-design-profile-hobby-depot.single-post .hd-article-photo-hero-v150789{height:330px!important}
  body.pftk-design-profile-hobby-depot.single-post .hd-article-photo-hero-v150789>img{object-position:62% center!important}
  body.pftk-design-profile-hobby-depot.single-post .hd-article-hero-shade-v150789{background:linear-gradient(90deg,rgba(245,241,233,.98),rgba(245,241,233,.89) 38%,rgba(245,241,233,.1) 95%)!important}
  body.pftk-design-profile-hobby-depot.single-post .hd-article-hero-claim-v150789{left:18px!important;max-width:75%!important;width:75%!important;font-size:clamp(23px,5vw,30px)!important}
  html body.pftk-design-profile-hobby-depot.single-post #content article.post .entry-content{width:calc(100% - 24px)!important;margin:18px auto 54px!important}
}
</style>
<?php
}
add_action('wp_head', 'hd003_article_hero_style_v150789', 999999);

function hd003_article_hero_deduplicate_inline_v150789() {
    if (is_admin() || !function_exists('is_singular') || !is_singular('post')) { return; }
    ?>
<script id="hd003-article-hero-dedupe-v150789">(function(){
var hero=document.querySelector('.hd-article-photo-hero-v150789');
if(!hero||!document.body.classList.contains('hd-article-inline-image-v150789'))return;
var source=hero.getAttribute('data-hd-hero-source');
if(!source)return;
var content=document.querySelector('body.single-post #content article.post .entry-content');
if(!content)return;
var images=content.querySelectorAll('img');
for(var i=0;i<images.length;i++){
 if(images[i].getAttribute('src')===source){var f=images[i].closest('figure.wp-block-image,.wp-block-image,figure');
   if(f){f.style.setProperty('display','none','important');}
   else{images[i].style.setProperty('display','none','important');}
   break;}
}
})();</script>
<?php
}
add_action('wp_footer', 'hd003_article_hero_deduplicate_inline_v150789', 998);
