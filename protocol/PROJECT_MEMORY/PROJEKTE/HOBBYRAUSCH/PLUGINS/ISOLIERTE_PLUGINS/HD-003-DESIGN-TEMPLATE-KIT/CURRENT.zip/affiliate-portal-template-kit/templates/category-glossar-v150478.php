<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="primary" class="site-main pftk-glossar-category-main-v150478 pftk-glossar-main-v150481">
<?php if (class_exists('Pferde_Template_Kit')) { Pferde_Template_Kit::glossary_category_page_v150478(); } ?>
</main>
<?php get_footer();
