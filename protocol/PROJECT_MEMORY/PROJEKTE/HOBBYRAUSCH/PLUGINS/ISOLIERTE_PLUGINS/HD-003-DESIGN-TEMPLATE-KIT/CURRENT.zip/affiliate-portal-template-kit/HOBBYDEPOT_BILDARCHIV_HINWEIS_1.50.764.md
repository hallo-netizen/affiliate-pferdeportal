Das eingebettete Bildarchiv enthält platzsparende WebP-Kopien und wird nicht automatisch auf der Website verwendet. Die Originaldateien sind im separaten Vollarchiv 1.50.762 erhalten.
