<?php
/** V1.50.424 – gruppierte Ergebnisseite der globalen Header-Suche. */
if (!defined('ABSPATH')) { exit; }
get_header();
if (class_exists('Pferde_Template_Kit') && method_exists('Pferde_Template_Kit', 'render_search_results_page_v150424')) {
    Pferde_Template_Kit::render_search_results_page_v150424();
}
get_footer();
