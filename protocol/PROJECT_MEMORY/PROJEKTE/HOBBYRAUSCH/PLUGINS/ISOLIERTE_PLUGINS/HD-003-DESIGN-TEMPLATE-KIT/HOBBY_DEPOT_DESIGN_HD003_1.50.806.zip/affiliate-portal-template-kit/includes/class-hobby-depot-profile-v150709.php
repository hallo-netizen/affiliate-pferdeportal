<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Hobby Depot profile for the shared Affiliate Portal Template Kit.
 * Stage 1 deliberately owns only the global brand frame + homepage.
 * Existing category/SEO structure remains authoritative and untouched.
 */
final class Hobby_Depot_Profile_V150709 {
    const PROFILE = 'hobby_depot';
    const RELEASE = '1.50.798';
    const RENTAL_OPTION = 'pftk_hobby_rental_slots_v1';
    const IMAGE_CENTER_OPTION = 'pftk_hd_bildzentrale_zuordnung_v150770';
    private static $front_rendered = false;
    private static $header_rendered = false;
    private static $footer_rendered = false;
    private static $rental_rendered = false;

    private static function world_slugs() {
        return ['gestalten','fertigen','technik','forschen','pflanzen','tiere','bewegen','sammeln'];
    }

    /**
     * Stable visual identity per CORE world. This mapping is intentionally
     * reusable by header, homepage cards and later hub/category/article levels.
     */
    public static function disable_apkw_auto_footer_v150709($enabled = true) {
        return false;
    }

    public static function world_accent($slug) {
        // One consistent petrol tone across all CORE icons for a stronger visual red thread.
        return '#2f969d';
    }

    public static function world_icon_svg($slug) {
        $icons = [
            'gestalten' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 1 0 0 18h1.2a2 2 0 0 0 0-4H12a1.5 1.5 0 0 1 0-3h2.5A6.5 6.5 0 0 0 21 7.5C21 5 17 3 12 3Z"/><circle cx="7.5" cy="9" r="1"/><circle cx="10.5" cy="6.8" r="1"/><circle cx="14" cy="6.8" r="1"/></svg>',
            'fertigen' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 6l4-4 4 4-4 4"/><path d="M13 7 4 16a3 3 0 0 0 4 4l9-9"/><path d="m4 4 6 6"/><path d="m3 3 3 1 1 3"/></svg>',
            'technik' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3.2"/><path d="M12 2v2.2M12 19.8V22M22 12h-2.2M4.2 12H2M19.1 4.9l-1.6 1.6M6.5 17.5l-1.6 1.6M19.1 19.1l-1.6-1.6M6.5 6.5 4.9 4.9"/><circle cx="12" cy="12" r="7.2"/></svg>',
            'forschen' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 2h6M10 2v6l-5 9a3 3 0 0 0 2.6 4.5h8.8A3 3 0 0 0 19 17l-5-9V2"/><path d="M7.8 15h8.4"/></svg>',
            'pflanzen' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 4C12 4 6 8 5 16c7 1 13-2 15-12Z"/><path d="M4 20c3-6 8-10 14-13"/></svg>',
            'tiere' => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/><path d="M8 14c2-2 4-2 6 0-2 2-4 2-6 0Z"/><path d="m8 14-2-2v4l2-2Z"/><path d="M17 18c0-3 1-5 3-6"/></svg>',
            'bewegen' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="14" cy="4.5" r="2"/><path d="m12 8-3 5 3 2 2-4 3 3"/><path d="m10 15-3 6M14 16l4 5M9 10l-4 2"/></svg>',
            'sammeln' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 7 9-4 9 4-9 4-9-4Z"/><path d="M3 7v10l9 4 9-4V7"/><path d="M12 11v10"/></svg>',
        ];
        return isset($icons[$slug]) ? $icons[$slug] : $icons['technik'];
    }

    public static function init() {
        add_action('wp_body_open', [__CLASS__, 'render_header'], 5);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_styles'], 20);
        // 1.50.745: Keine externen Google-Fonts. ListingHive/HivePress darf
        // fonts.googleapis.com weder als Stylesheet noch als Resource-Hint ausgeben.
        add_action('wp_enqueue_scripts', [__CLASS__, 'disable_external_google_fonts_v150745'], 1000000);
        add_action('wp_print_styles', [__CLASS__, 'disable_external_google_fonts_v150745'], 1000000);
        add_filter('wp_resource_hints', [__CLASS__, 'strip_google_font_resource_hints_v150745'], 1000000, 2);
        add_filter('the_content', [__CLASS__, 'normalize_service_content_v150741'], 998);
        add_action('wp_footer', [__CLASS__, 'render_header_js'], 35);
        // HD007's separate detail renderer displays the SAME central hobby master.
        add_action('wp_footer', [__CLASS__, 'sync_hd007_detail_image_v150769'], 36);
        // HD007-Verweiskarten: jedes Miniaturbild nur aus derselben Bildzentrale wie sein Hobby-Hero.
        add_action('wp_footer', [__CLASS__, 'sync_hd007_reference_images_v150771'], 37);
        add_action('admin_post_hd_bildzentrale_save_v150770', [__CLASS__, 'admin_bildzentrale_save_v150770']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'admin_bildzentrale_media_v150770']);
        // 1.50.735: globale Hobby-Depot-Suche wie beim Pferdeatelier, aber mit vier
        // fachlich getrennten Hobby-Depot-Welten: Hobbys | Magazin | Glossar | Anzeigen.
        add_action('wp_ajax_hd_main_search_v150732', [__CLASS__, 'main_search_ajax_v150732']);
        add_action('wp_ajax_nopriv_hd_main_search_v150732', [__CLASS__, 'main_search_ajax_v150732']);
        add_action('pre_get_posts', [__CLASS__, 'scope_market_search_v150744'], 19);
        // 1.50.709: HD-001 keeps its footer data/API, but HD-003 owns the visible footer.
        // Disable only APKW's automatic wp_footer renderer via its documented filter.
        add_filter('apkw_auto_footer_enabled', [__CLASS__, 'disable_apkw_auto_footer_v150709'], 9999);
        add_filter('body_class', [__CLASS__, 'body_classes'], 20);
        add_filter('template_include', [__CLASS__, 'route_template'], 99999);
        add_action('wp_body_open', [__CLASS__, 'render_universal_top'], 20);
        add_action('wp_body_open', [__CLASS__, 'render_market_top_v150743'], 25);
        add_action('wp_body_open', [__CLASS__, 'render_market_category_top_v150798'], 26);
        add_filter('render_block', [__CLASS__, 'suppress_theme_template_parts'], 99999, 2);
        add_action('wp_footer', [__CLASS__, 'render_footer'], 5);
        add_shortcode('affiliate_portal_startseite', [__CLASS__, 'shortcode_start']);
        add_filter('ppar_affiliate_slot_matrix', [__CLASS__, 'affiliate_slot_matrix'], 20, 3);
        add_filter('pftk_leaf_category_design_owns_affiliate_slots', [__CLASS__, 'owns_leaf_slots'], 20, 2);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('init', [__CLASS__, 'maybe_seed_demo_posts_v150637'], 30);
        add_action('init', [__CLASS__, 'maybe_seed_kettenhemd_demo_posts_v150687'], 31);
        add_action('admin_init', [__CLASS__, 'admin_init']);
        // 1.50.745: SEO-Titel/Description gehoeren zentral HD-002 (Hobby Depot SEO Themenengine).
        // HD-003 erzeugt bewusst keine zweite SEO-Wahrheit mehr.
        add_filter('the_content', [__CLASS__, 'render_faq_content_v150715'], 40);
        add_filter('the_content', [__CLASS__, 'render_magazine_content_fallback_v150721'], 45);
        add_filter('the_content', [__CLASS__, 'append_rental_to_content'], 999);
    }

    public static function disable_external_google_fonts_v150745() {
        if (is_admin()) { return; }
        global $wp_styles;
        if (is_object($wp_styles) && isset($wp_styles->registered) && is_array($wp_styles->registered)) {
            foreach ($wp_styles->registered as $handle => $style) {
                $src = is_object($style) && isset($style->src) ? (string)$style->src : '';
                if ($src === '') { continue; }
                if (stripos($src, 'fonts.googleapis.com') !== false || stripos($src, 'fonts.gstatic.com') !== false) {
                    wp_dequeue_style((string)$handle);
                    wp_deregister_style((string)$handle);
                }
            }
        }

        // Der bestehende Hobby-Depot-Entwurf benutzt bereits eine lokale/System-
        // Schriftkette. Sie wird hier nur hart gegen Theme-Poppins/Open-Sans
        // abgesichert; es entsteht keinerlei externer Font-Request.
        $handle = 'hd-local-system-fonts-v150745';
        if (function_exists('wp_register_style') && function_exists('wp_enqueue_style')) {
            wp_register_style($handle, false, [], self::RELEASE);
            wp_enqueue_style($handle);
            if (function_exists('wp_add_inline_style')) {
                wp_add_inline_style($handle,
                    'body.pftk-design-profile-hobby-depot,' .
                    'body.pftk-design-profile-hobby-depot button,' .
                    'body.pftk-design-profile-hobby-depot input,' .
                    'body.pftk-design-profile-hobby-depot select,' .
                    'body.pftk-design-profile-hobby-depot textarea{' .
                    'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif!important}' .
                    'body.pftk-design-profile-hobby-depot h1,' .
                    'body.pftk-design-profile-hobby-depot h2,' .
                    'body.pftk-design-profile-hobby-depot h3,' .
                    'body.pftk-design-profile-hobby-depot h4,' .
                    'body.pftk-design-profile-hobby-depot h5,' .
                    'body.pftk-design-profile-hobby-depot h6{' .
                    'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif!important}'
                );
            }
        }
    }

    public static function strip_google_font_resource_hints_v150745($urls, $relation_type) {
        if (!is_array($urls)) { return $urls; }
        if (!in_array((string)$relation_type, ['dns-prefetch', 'preconnect'], true)) { return $urls; }
        return array_values(array_filter($urls, static function($entry) {
            $url = is_array($entry) ? (string)($entry['href'] ?? '') : (string)$entry;
            return stripos($url, 'fonts.googleapis.com') === false
                && stripos($url, 'fonts.gstatic.com') === false;
        }));
    }

    public static function body_classes($classes) {
        $classes = is_array($classes) ? $classes : [];
        $classes[] = 'pftk-design-profile-hobby-depot';
        if (function_exists('wp_get_theme')) {
            $theme = wp_get_theme();
            $stylesheet = is_object($theme) ? strtolower((string)$theme->get_stylesheet()) : '';
            if ($stylesheet === 'listinghive') { $classes[] = 'hd-listinghive-v150616'; }
        }
        if (function_exists('is_front_page') && is_front_page()) { $classes[] = 'hd-home-v150616'; }
        if (self::is_hivepress_market_root_v150742()) { $classes[] = 'hd-market-root-v150744'; }
        if (self::is_hivepress_market_category_v150798()) { $classes[] = 'hd-market-category-v150798'; }
        if (function_exists('is_singular') && is_singular('page')) {
            $service_page = function_exists('get_queried_object') ? get_queried_object() : null;
            if ($service_page instanceof WP_Post && self::is_plain_service_page($service_page)) {
                $service_slug = sanitize_title((string)$service_page->post_name);
                $classes[] = 'hd-service-page-v150735';
                if ($service_slug !== '') { $classes[] = 'hd-service-' . $service_slug . '-v150735'; }
            }
        }
        return array_values(array_unique($classes));
    }

    private static function topic_icon_svg($title, $world_slug='') {
        $key = sanitize_title((string)$title);
        $icons = [
            'camera' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h4l1.5-2h5L16 7h4v12H4Z"/><circle cx="12" cy="13" r="3.4"/></svg>',
            'drone' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="2.3"/><path d="M7 7l3 3M17 7l-3 3M7 17l3-3M17 17l-3-3"/><circle cx="5" cy="5" r="2"/><circle cx="19" cy="5" r="2"/><circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/></svg>',
            'sun' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3.2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9 7 7M17 17l2.1 2.1M19.1 4.9 17 7M7 17l-2.1 2.1"/></svg>',
            'flask' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 18l-5-9V3"/><path d="M7.5 16h9"/></svg>',
            'print' => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3" width="14" height="6" rx="1"/><rect x="4" y="10" width="16" height="7" rx="2"/><path d="M7 17h10v4H7zM16 13h1"/></svg>',
            'cut' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 20 7-7M14 10l6-6M10 14l4-4"/><circle cx="7" cy="7" r="3"/><circle cx="17" cy="17" r="3"/></svg>',
            'paper' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h9l3 3v15H6Z"/><path d="M15 3v4h4M9 11h6M9 15h6"/></svg>',
            'brush' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14 4 6 6-8 8-6-6Z"/><path d="M5 13c-2 1-3 3-2 5 1 2 4 2 6 0"/></svg>',
            'thread' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 4h8l2 4-2 12H8L6 8Z"/><path d="M8 9h8M9 13h6M10 17h4"/></svg>',
            'cube' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 7 8-4 8 4-8 4Z"/><path d="M4 7v10l8 4 8-4V7M12 11v10"/></svg>',
            'tool' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 6l4-4 4 4-4 4"/><path d="M13 7 4 16a3 3 0 0 0 4 4l9-9"/></svg>',
            'chip' => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="7" width="10" height="10" rx="2"/><path d="M9 1v4M15 1v4M9 19v4M15 19v4M1 9h4M1 15h4M19 9h4M19 15h4"/></svg>',
            'leaf' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 4C12 4 6 8 5 16c7 1 13-2 15-12Z"/><path d="M4 20c3-6 8-10 14-13"/></svg>',
            'compass' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2.2 4.8-4.8 2.2 2.2-4.8Z"/></svg>',
            'aperture' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="2"/><path d="M12 3l4 6M20 8l-4 6M18 19h-7M6 20l3-6M3 10h7M7 4l5 4"/></svg>',
            'moon' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M18 16.5A8 8 0 0 1 8 6a8 8 0 1 0 10 10.5Z"/><path d="M4 19h6"/></svg>',
            'plate' => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="4" width="14" height="16" rx="1"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
            'wood' => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="6" width="16" height="12" rx="2"/><path d="M7 9c2-2 4-2 6 0s4 2 5 0M8 14c2-1 4-1 6 0"/></svg>',
            'linol' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 18 16 7l3 3L8 21H5Z"/><path d="M14 5l2-2 5 5-2 2"/></svg>',
        ];
        if (preg_match('/lochkamer/', $key)) return $icons['aperture'];
        if (preg_match('/dunkelkammer/', $key)) return $icons['moon'];
        if (preg_match('/nassplatten/', $key)) return $icons['plate'];
        if (preg_match('/holzschnitt/', $key)) return $icons['wood'];
        if (preg_match('/linolschnitt/', $key)) return $icons['linol'];
        if (preg_match('/drohn/', $key)) return $icons['drone'];
        if (preg_match('/cyan|sonnen|licht/', $key)) return $icons['sun'];
        if (preg_match('/dunkel|nassplatten|chem|labor/', $key)) return $icons['flask'];
        if (preg_match('/foto|kamera|lochkamer/', $key)) return $icons['camera'];
        if (preg_match('/sieb|druck/', $key)) return $icons['print'];
        if (preg_match('/linol|holzschnitt|schnitt|schnitz/', $key)) return $icons['cut'];
        if (preg_match('/papier|buch|karton/', $key)) return $icons['paper'];
        if (preg_match('/mal|zeich|pinsel|farbe/', $key)) return $icons['brush'];
        if (preg_match('/textil|stoff|naeh|wolle/', $key)) return $icons['thread'];
        if (preg_match('/miniatur|modell/', $key)) return $icons['cube'];
        if (preg_match('/elektr|robot|computer|smart|funk/', $key)) return $icons['chip'];
        if (preg_match('/pflanz|garten|bonsai|orchid|moos/', $key)) return $icons['leaf'];
        if (preg_match('/holz|metall|werk|leder|keramik/', $key)) return $icons['tool'];
        $fallback = ['camera','print','paper','brush','cube','compass'];
        $idx = abs(crc32($key !== '' ? $key : (string)$world_slug)) % count($fallback);
        return $icons[$fallback[$idx]];
    }

    private static function hub2_claim($title, $world_slug='') {
        $key = sanitize_title((string)$title);
        $map = [
            'druck-fotografie' => 'Bilder, die bleiben.',
            'druck-foto' => 'Bilder, die bleiben.',
            'malen-zeichnen' => 'Linie trifft Farbe.',
            'miniaturen-szenen' => 'Kleine Welten. Große Ideen.',
            'oberflaeche-deko' => 'Aus schlicht wird besonders.',
            'oberflache-deko' => 'Aus schlicht wird besonders.',
            'papierkunst' => 'Falten. Schneiden. Staunen.',
            'schrift-lettering' => 'Buchstaben mit Charakter.',
            'textilgestaltung' => 'Stoff für gute Ideen.',
            'buch-papier' => 'Papier kann mehr.',
            'genuss' => 'Selbst gemacht schmeckt besser.',
            'guss-form' => 'Bring Ideen in Form.',
            'guss-formen' => 'Bring Ideen in Form.',
            'heimwerken' => 'Mach es einfach selbst.',
            'holz' => 'Holz will gestaltet werden.',
            'keramik-glas' => 'Form trifft Feuer.',
            'leder' => 'Leder mit Charakter.',
            'metall' => 'Kraft trifft Präzision.',
            'naturmaterial' => 'Natur wird Idee.',
            'schmuck' => 'Kleine Stücke. Große Wirkung.',
            'textil' => 'Stoff wird Werkstück.',
            'audio-hifi' => 'Klang, der begeistert.',
            'holz-natur' => 'Holz will gestaltet werden.',
            'hydroponik-indoor' => 'Wachsen ohne Erde.',
            'modellbau' => 'Kleine Modelle. Große Technik.',
            'spotting-verkehr' => 'Sehen. Erkennen. Dokumentieren.',
            'citizen-science' => 'Beobachten, das zählt.',
            'natur-bestimmen' => 'Namen für das, was wächst.',
            'suchen-finden' => 'Draußen suchen. Echt finden.',
            'computer-retro' => 'Alte Technik. Neuer Blick.',
            'digitale-fertigung' => 'Idee. Datei. Objekt.',
            'elektronik' => 'Technik zum Anfassen.',
            'funk' => 'Verbinden über Distanz.',
            'mechanik-uhren' => 'Präzision in Bewegung.',
            'rc-modelltechnik' => 'Kontrolle. Tempo. Spaß.',
            'robotik-automation' => 'Bewegung mit System.',
            'smart-home' => 'Technik, die mitdenkt.',
            'astronomie' => 'Blick raus. Staunen an.',
            'messen-analysieren' => 'Messen macht sichtbar.',
            'mikroskopie' => 'Das Kleine ganz groß.',
            'naturbeobachtung' => 'Mehr sehen. Draußen verstehen.',
            'wetter-umwelt' => 'Zeichen lesen. Muster erkennen.',
            'bonsai-miniatur' => 'Ruhe in Form gebracht.',
            'essbare-pflanzen' => 'Ernten, was dich reizt.',
            'gaertnern' => 'Aus kleinen Schritten wächst mehr.',
            'gartnern' => 'Aus kleinen Schritten wächst mehr.',
            'hydro-indoor' => 'Wachsen ohne Erde.',
            'kakteen-sukkulenten' => 'Wenig Aufwand. Viel Charakter.',
            'moos-miniaturgaerten' => 'Kleine Landschaften mit Ruhe.',
            'moos-miniaturgarten' => 'Kleine Landschaften mit Ruhe.',
            'orchideen-exoten' => 'Anspruch, der sich lohnt.',
            'pilze-kulturen' => 'Züchten mit System.',
            'saatgut-zucht' => 'Vom Korn zur Kultur.',
            'zimmerpflanzen' => 'Mehr Grün. Weniger Grau.',
            'ameisen-insekten' => 'Kleine Tiere. Große Welten.',
            'aquaristik' => 'Eine Welt hinter Glas.',
            'gehegegestaltung' => 'Lebensräume mit Plan.',
            'imkerei-bestaeuber' => 'Summen mit Sinn.',
            'terraristik' => 'Lebensräume im Kleinen.',
            'wirbellose' => 'Ungewöhnlich spannend.',
            'zucht-futtertiere' => 'Kreisläufe verstehen.',
            'geschick-tricks' => 'Übung wird Können.',
            'klettern-seil' => 'Hoch hinaus. Sauber gesichert.',
            'outdoor' => 'Draußen beginnt das Abenteuer.',
            'rollen-balance' => 'Balance mit Flow.',
            'team-wettkampf' => 'Zusammen besser spielen.',
            'wasser' => 'Raus aufs Wasser.',
            'wind-drachen' => 'Wind im Rücken.',
            'wurf-ziel' => 'Treffen. Üben. Besser werden.',
            'alltagsobjekte' => 'Alltag wird Geschichte.',
            'muenzen-geld' => 'Kleine Stücke. Große Geschichte.',
            'munzen-geld' => 'Kleine Stücke. Große Geschichte.',
            'naturfunde' => 'Draußen finden. Drinnen bewahren.',
            'papier-dokumente' => 'Geschichten auf Papier.',
            'spielzeug-spiele' => 'Erinnerungen zum Sammeln.',
            'technik-medien' => 'Technik erzählt Zeitgeschichte.',
            'werbung-design' => 'Gestaltung, die bleibt.',
            'werkzeuge-geraete' => 'Werkzeug mit Geschichte.',
            'werkzeuge-gerate' => 'Werkzeug mit Geschichte.',
        ];
        if (isset($map[$key])) { return $map[$key]; }
        $title = trim((string)$title);
        return $title !== '' ? $title . ' neu entdecken.' : 'Neues entdecken.';
    }

    private static function hub2_editorial($page) {
        if (!$page instanceof WP_Post) { return []; }
        static $map = null;
        if ($map === null) {
            $map = [
            'malen-zeichnen' => ['hero'=>'Von der ersten Linie bis zum eigenen Bild.', 'lead'=>'Malen und Zeichnen sind Hobbys für alle, die Beobachtungen, Ideen oder Stimmungen mit Linien und Farbe sichtbar machen möchten. Du skizzierst, zeichnest oder malst auf Papier und Leinwand und lernst dabei Proportion, Licht, Perspektive und Farbwirkung kennen. Schon mit wenigen Stiften oder Farben kannst du anfangen; reizvoll ist, wie schnell eine eigene Handschrift entsteht.', 'more'=>'Bleistift, Kohle oder Fineliner reagieren unterschiedlich und eignen sich deshalb nicht für dieselben Aufgaben. Beim Malen kommen Farbmischung, Deckkraft, Trocknung und der Untergrund hinzu. Aquarell verlangt anderes Arbeiten als Acryl oder Öl, und Airbrush setzt kontrollierte Luft- und Farbmenge voraus. Für den Einstieg lohnt sich ein kleines, überschaubares Materialset und regelmäßiges Üben an echten Motiven statt ständig neuer Ausrüstung. Wenn du weiter bist, werden Bildaufbau, Farbwirkung, eigene Stilmittel und die bewusste Kombination mehrerer Techniken interessant. Beim Zeichnen stehen Linie und Beobachtung stärker im Vordergrund, beim Malen eher Farbe und Fläche.

Du findest hier deshalb sowohl Grundlagen als auch konkrete Richtungen wie Malen, Zeichnen und Airbrush – mit Blick auf Material, Arbeitsweise und typische Fehler. Wenn du zwischen den Richtungen wechselst, hilft ein Skizzenbuch als gemeinsamer Übungsraum: Dort kannst du dieselbe Form einmal zeichnerisch, einmal farbig und einmal stark vereinfacht untersuchen. So merkst du schnell, ob dich eher Beobachtung, Farbe, Materialwirkung oder freies Erfinden reizt. Gute Übungen müssen dabei nicht groß sein; kleine Studien zeigen Fortschritte oft deutlicher.'],
            'druck-foto' => ['hero'=>'Bilder gestalten, vervielfältigen und bewusst festhalten.', 'lead'=>'Druck und Fotografie versammeln Hobbys, bei denen Bilder aufgenommen, entwickelt, gedruckt oder bewusst vervielfältigt werden. Du arbeitest mit Kamera und Licht oder überträgst Motive per Linol-, Holz- oder Siebdruck auf Papier und andere Flächen. Wer Bilder nicht nur konsumieren, sondern ihren Entstehungsprozess gestalten möchte, findet hier viele sehr unterschiedliche Zugänge.', 'more'=>'Linolschnitt und Holzschnitt belohnen klare Planung, weil jeder Schnitt die spätere Fläche verändert; beim Siebdruck kommen Gewebe, Schablone und Farbauftrag dazu. In der Fotografie bestimmen Licht, Brennweite, Perspektive und Belichtung, wie ein Motiv wirkt. Analoge Verfahren wie Dunkelkammer- oder Nassplattenfotografie verlangen zusätzlich sauberes Arbeiten mit Material und Chemie. Cyanotypie und Lochkamera sind dagegen gute Wege, Bildentstehung sehr unmittelbar zu verstehen. Auch Drohnenfotografie gehört dazu, bringt aber eigene Regeln für Flug, Sicherheit und Bildgestaltung mit. Aufnahmeverfahren, Drucktechnik und Ausrüstung sollten zum gewünschten Bild passen; ein bewusst gewählter Prozess ist meist hilfreicher als möglichst viel Technik.

Gerade der Vergleich von handwerklichem Druck und fotografischer Aufnahme macht sichtbar, wie unterschiedlich ein Bild geplant, erzeugt und reproduziert werden kann. Für die Wahl eines Einstiegs lohnt sich die Frage, ob dich eher der einzelne Aufnahme-Moment oder ein wiederholbarer handwerklicher Prozess interessiert. Fotografie reagiert sofort auf Licht und Standpunkt, Druckverfahren stärker auf Vorbereitung und Material. Ein kleines Projekt mit nur einem Motiv macht diese Unterschiede besonders gut sichtbar und verhindert, dass Technik und Zubehör das eigentliche Bild überlagern.'],
            'textilgestaltung' => ['hero'=>'Farbe und Muster direkt auf Stoff bringen.', 'lead'=>'Textilgestaltung macht Stoff selbst zur kreativen Fläche. Du färbst, bindest, malst oder bedruckst Textilien und erzeugst mit Batik, Shibori, Seidenmalerei oder Textildruck eigene Muster. Das passt zu dir, wenn du Farbe und Material gern praktisch ausprobierst; für erste Projekte reichen Stoff, geeignete Farben und wenige einfache Hilfsmittel.', 'more'=>'Bei Batik schützt Wachs bestimmte Flächen vor der Farbe; Shibori arbeitet mit Faltungen, Bindungen und Druck, sodass Muster erst nach dem Öffnen sichtbar werden. Seidenmalerei lebt von fließender Farbe und kontrollierten Konturen, während Textildruck mit Stempeln, Sieben oder anderen Druckformen wiederholbare Motive ermöglicht. Wichtig sind waschfeste Farben, saubere Fixierung und Probestücke, denn ein Fehler lässt sich auf Stoff oft schlechter korrigieren als auf Papier. Für erste Versuche reichen kleine Stoffstücke und wenige Farben. Später kannst du mehrfarbig arbeiten, eigene Muster entwickeln oder Techniken kombinieren. Natur- und Kunstfasern nehmen Farbe unterschiedlich an, deshalb gehört die Stoffart immer zur Materialwahl.

Batik, Shibori, Seidenmalerei und Textildruck unterscheiden sich bei Farbauftrag, Reservierung, Stoffwahl und Fixierung deutlich voneinander. Auch die spätere Nutzung zählt: Ein Wandstück darf anders behandelt werden als ein Kleidungsstück, das regelmäßig getragen und gewaschen wird. Auch Musterplanung lässt sich sehr unterschiedlich angehen: frei und spontan, streng wiederholt oder aus einem einzelnen Motiv entwickelt. Ein Probestück zeigt dir, wie Farbe auf genau diesem Stoff aussieht und ob Fixierung, Waschbarkeit und Griff stimmen. So kannst du Fehler auf dem eigentlichen Werkstück vermeiden und zugleich herausfinden, welche Technik zu deiner Arbeitsweise passt.'],
            'miniaturen-szenen' => ['hero'=>'Kleine Maßstäbe, große Wirkung.', 'lead'=>'Miniaturen und Szenen lassen dich ganze Welten im kleinen Maßstab bauen. Du gestaltest Dioramen, Book Nooks, Puppenhäuser oder Architekturmodelle und kombinierst Form, Farbe, Licht und feine Details. Wer gern tüftelt, erzählt oder Dinge präzise nachbildet, findet hier besonders viel Spielraum. Wichtig sind zunächst ein gewählter Maßstab und wenige passende Grundmaterialien.', 'more'=>'Für Grundkörper eignen sich je nach Projekt Karton, Holz, Hartschaum, Kunststoff oder Modelliermassen. Beim Bemalen von Miniaturen sind dünne Farbschichten, saubere Grundierung und gezielte Schatten wichtiger als möglichst viele Farben. Dioramen gewinnen durch Bodenstrukturen, Vegetation und eine klare Blickführung; bei Book Nooks und Puppenhäusern kommt häufig Beleuchtung hinzu. Architekturmodellbau verlangt dagegen besonders saubere Kanten und exakte Maße. Du findest hier sowohl kreative Miniaturwelten als auch technischere Modellformen. Für Einsteiger sind kleine Szenen sinnvoll, weil sich Material, Kleber, Farbe und Alterung ausprobieren lassen, ohne dass das Projekt sofort ausufert. Der gewählte Maßstab bestimmt dabei, wie groß Figuren, Möbel, Gebäude und andere Strukturen zueinander sein müssen.

Bei größeren Szenen lohnt sich eine Baufolge von grob nach fein, damit Beleuchtung, Kabel oder tragende Teile nicht erst nach der Dekoration berücksichtigt werden. Der besondere Reiz entsteht oft aus dem Wechsel zwischen Planung und Illusion. Ein sauberer Maßstab schafft Glaubwürdigkeit, während Farbe, Licht und Gebrauchsspuren erzählen, was in der kleinen Szene passiert sein könnte. Fotografierst du dein Modell zwischendurch auf Augenhöhe, fallen unstimmige Größen, zu grobe Oberflächen oder leere Bereiche meist schneller auf als beim Blick von oben.'],
            'schrift-lettering' => ['hero'=>'Schreiben wird Gestaltung.', 'lead'=>'Schrift & Lettering macht Buchstaben selbst zum Gestaltungsmittel. Du zeichnest, schreibst und formst Wörter bewusst – mit Brushpen, Feder, Fineliner oder Tinte – und spielst mit Strichstärke, Abstand und Rhythmus. Der Reiz liegt darin, aus Sprache ein sichtbares Bild zu machen; dafür reichen zunächst Papier, ein passendes Schreibwerkzeug und etwas Übung.', 'more'=>'Beim Lettering werden Buchstaben eher gezeichnet als in einem Zug geschrieben. Du kannst Formen vorzeichnen, korrigieren, verbreitern, verzieren und zu einem eigenen Schriftbild zusammensetzen. Kalligrafie funktioniert anders: Hier entstehen die Buchstaben stärker aus der Bewegung von Hand und Werkzeug. Federwinkel, Druck, Tempo und Tintenfluss bestimmen, wie dünne und kräftige Striche aufeinander reagieren. Beim Schreiben mit dem Federkiel kommt zusätzlich das besondere Verhalten einer zugeschnittenen Feder hinzu. Für erste Versuche brauchst du kein großes Sortiment.

Ein geeignetes Schreibwerkzeug, glattes Papier, ein Linienraster und wenige Grundformen reichen, um ein Gefühl für Strichführung und Abstände zu entwickeln. Mit der Zeit kannst du verschiedene Alphabete, Ligaturen, Schmuckelemente und eigene Buchstabenformen ausprobieren oder Schrift mit Farbe und Illustration verbinden. Achte darauf, dass Feder, Tinte und Papier zusammenpassen: Zu raues Papier bremst feine Spitzen, zu dünnes Papier kann Tinte ausbluten lassen. Gerade diese Mischung aus Handwerk, Rhythmus und persönlicher Gestaltung macht Schrift & Lettering so vielseitig und unmittelbar.'],
            'papierkunst' => ['hero'=>'Papier wird Fläche, Form und Erinnerung.', 'lead'=>'Papierkunst zeigt, wie vielseitig ein scheinbar einfaches Material sein kann. Du faltest, schneidest, rollst, klebst und kombinierst Papier zu Origami, Quilling, Collagen oder Scrapbook-Seiten. Wer gern mit den Händen gestaltet und ohne große Werkstatt beginnen möchte, ist hier richtig. Papier, Klebstoff und wenige Schneid- oder Falzwerkzeuge reichen für viele erste Projekte.', 'more'=>'Beim Paper Quilling werden schmale Streifen gerollt, geformt und zu flachen oder räumlichen Motiven zusammengesetzt. Collagen geben dir mehr Freiheit: Fotos, Drucke, Fundstücke und bemalte Flächen können geschichtet und neu kombiniert werden. Scrapbooking verbindet Gestaltung mit Dokumentation und stellt zusätzlich Anforderungen an haltbare, möglichst säurefreie Materialien. Eine Schneidematte, gutes Messer, Lineal und der richtige Kleber decken bereits viele Projekte ab. Bevor du teure Spezialsets kaufst, lohnt es sich, mit kleinen Formaten zu testen, welche Arbeitsweise dir liegt. Papierstärke, Faserrichtung und saubere Schnitte beeinflussen dabei oft stärker das Ergebnis als aufwendiges Werkzeug.

Falten, Rollen, Schneiden und Collagieren stellen unterschiedliche Anforderungen an Papierstärke, Faserrichtung, Klebstoff und Werkzeug. Bei archivierten Fotos oder Dokumenten solltest du außerdem darauf achten, dass Kleber und Papiere langfristig keine Verfärbungen oder Schäden verursachen. Papier reagiert stark auf Laufrichtung, Feuchtigkeit und Druck. Schon deshalb lohnt es sich, Reste nicht wegzuwerfen, sondern für Klebe-, Falt- und Schneideproben zu nutzen. Wer mehrere Techniken kombiniert, sollte außerdem erst die Reihenfolge festlegen: Farbe, Kleber und Falz beeinflussen sich gegenseitig. Dadurch werden auch kleine Projekte sauberer und haltbarer.'],
            'oberflaeche-deko' => ['hero'=>'Oberflächen bekommen eine eigene Handschrift.', 'lead'=>'Oberfläche & Deko umfasst Hobbys, bei denen vorhandene Gegenstände, Schilder oder Glasflächen eine eigene Gestaltung bekommen. Du malst, ziehst Linien, verzierst und arbeitest mit Techniken wie Pinstriping, Schilder- oder Glasmalerei. Besonders reizvoll ist die direkte Veränderung eines Objekts. Dafür brauchst du vor allem geeignete Farben, saubere Untergründe und ruhige Handarbeit.', 'more'=>'Bei der Schildermalerei kommen Buchstabenaufbau, Layout und deckende Lackfarben hinzu; kleine Ungenauigkeiten fallen dort sofort auf. Glasmalerei funktioniert wiederum mit anderen Farbsystemen, weil die glatte Oberfläche kaum saugt und manche Produkte eingebrannt oder besonders ausgehärtet werden müssen. Vor jedem Projekt solltest du reinigen, entfetten und an einem Reststück testen, wie Farbe und Untergrund reagieren. Abkleben hilft nur dort, wo wirklich harte Kanten gewünscht sind – viele typische Arbeiten leben gerade von freier Hand. Vorbereitung und Materialverträglichkeit entscheiden mit darüber, ob Farbe sauber haftet und dauerhaft hält.

Pinstriping verlangt freie Linienkontrolle, Schildermalerei typografische Planung und Glasmalerei ein Farbsystem, das auf glattem Untergrund zuverlässig hält. Gerade bei Gebrauchsgegenständen muss außerdem geklärt werden, ob die fertige Oberfläche abriebfest, wetterfest oder gegen häufiges Reinigen beständig sein soll. Bei dekorierten Gebrauchsgegenständen zählt neben der Optik immer die spätere Beanspruchung. Eine Schale, ein Schild im Freien oder ein Glasobjekt brauchen unterschiedliche Farb- und Schutzsysteme. Markiere dir deshalb vorab, welche Flächen angefasst, gewaschen oder dem Wetter ausgesetzt werden. Diese praktische Frage entscheidet oft mehr über die Materialwahl als der gewünschte Stil.'],
            'holz' => ['hero'=>'Holz bearbeiten, verstehen und sinnvoll nutzen.', 'lead'=>'Holz und Naturmaterialien sind etwas für Menschen, die Formen gern direkt mit den Händen und Werkzeugen entstehen lassen. Du schnitzt, drechselst, flechtest oder restaurierst und lernst dabei, Faserrichtung, Feuchtigkeit und Materialhärte zu lesen. Der Reiz liegt im sichtbaren Fortschritt vom Rohmaterial zum fertigen Stück; gutes Werkzeug und ein passendes Material sind wichtiger als viel Zubehör.', 'more'=>'Grünholz ist weicher und eignet sich gut für Löffel oder freie Formen, verändert sich aber beim Trocknen. Beim Drechseln kommen sichere Werkstückspannung und saubere Werkzeugführung hinzu. Korb- und Weidenflechten nutzen die Biegsamkeit langer Naturfasern, während Besenbinden andere Bindetechniken verlangt. Brandmalerei gestaltet die Oberfläche mit Hitze; Möbelrestaurierung erfordert dagegen Zurückhaltung, damit originale Substanz nicht unnötig verloren geht. Für Holzwerken sind Messen, Sägen, Bohren, Verbinden und Oberflächenbehandlung die Grundlagen. Du findest hier sowohl handwerkliche Einstiege als auch spezialisierte Richtungen und erfährst, wann Materialwahl, Trocknung, Schutzkleidung oder eine stabile Werkbank wirklich wichtig werden. Besonders beim Schnitzen bestimmen Holzart, Faserverlauf und scharfe Werkzeuge, wie kontrolliert du Material abtragen kannst.

Bei restaurierten oder alten Werkstücken lohnt sich außerdem die Frage, was tatsächlich repariert werden muss und welche Gebrauchsspuren zur Geschichte des Stücks gehören. Holz verändert sich mit Feuchtigkeit, Faserrichtung und Trocknung. Deshalb lohnt es sich, vor einem Projekt nicht nur die Holzart, sondern auch den Faserverlauf zu lesen. Ein Probestück zeigt, wie sich Werkzeug und Oberfläche verhalten. Mit zunehmender Erfahrung lernst du, wann ein sauberer Schnitt, eine stabile Verbindung oder bewusst sichtbare Werkzeugspuren zum Charakter des Werkstücks gehören.'],
            'buch-papier' => ['hero'=>'Papier herstellen, binden und in Form bringen.', 'lead'=>'Buch & Papier verbindet feines Handwerk mit Dingen, die du später wirklich benutzen, verschenken oder sammeln kannst. Du bindest Bücher, schöpfst Papier, marmorierst Oberflächen oder schnitzt Stempel und arbeitest dabei erstaunlich präzise. Wer Papier als Material liebt und gern ruhig, sauber und Schritt für Schritt arbeitet, findet hier viele Projekte mit überschaubarer Grundausstattung.', 'more'=>'Papierherstellung beginnt dagegen bei Fasern, Pulpe, Schöpfrahmen und Trocknung; schon kleine Änderungen verändern Stärke und Oberfläche. Marmorpapier lebt von schwimmenden Farben und kontrolliertem Abzug, während selbst geschnitzte Stempel besonders von klaren Motiven und sauberem Schnitt profitieren. Zines zeigen, wie wenig Material nötig ist, um eigene Inhalte als kleines Heft zu veröffentlichen. Für viele Projekte reichen Messer, Lineal, Falzbein, Nadel, Faden und geeigneter Kleber. Papierart, Bindung, Falz und Klebstoff müssen zusammenpassen; saubere Vorbereitung wirkt sich stärker auf das Ergebnis aus als eine große Sammlung an Spezialwerkzeugen. Beim Buchbinden beeinflussen Falz, Laufrichtung, Heftung und Klebung direkt, wie sauber sich das fertige Buch später öffnen lässt.

Bei eigenen Büchern und Zines lohnt es sich außerdem, Format und Seitenzahl früh festzulegen, weil daraus Papierbedarf, Bindung und Umschlagkonstruktion entstehen. Bei Buch- und Papierarbeiten entscheidet Präzision vor allem an unscheinbaren Stellen: gleichmäßige Falze, rechtwinklige Schnitte und sauber dosierter Klebstoff. Eine einfache Pressmöglichkeit und ein scharfes Messer bringen oft mehr als viele Spezialwerkzeuge. Wenn du Materialien kombinierst, prüfe außerdem, wie Papier, Karton, Faden und Leim nach dem Trocknen miteinander arbeiten.'],
            'keramik-glas' => ['hero'=>'Formen, brennen und mit Licht arbeiten.', 'lead'=>'Keramik & Glas umfasst Hobbys, bei denen aus formbaren oder erhitzten Materialien dauerhafte Gefäße, Objekte und Dekorationen entstehen. Du töpferst, modellierst, schneidest, verschmilzt oder gravierst und arbeitest je nach Technik mit Ton, Glas, Werkzeugen und Hitze. Das ist besonders reizvoll, wenn du Materialveränderung gern unmittelbar erlebst und handwerkliche Prozesse mit Gestaltung verbinden möchtest.', 'more'=>'Raku nutzt einen sehr eigenen Brenn- und Abkühlprozess und erzeugt bewusst unvorhersehbare Oberflächen. Bei Tiffanyglas werden einzelne Glasstücke zugeschnitten, eingefasst und verlötet. Glasfusing verschmilzt kompatible Glassorten im Ofen, während Glasperlen und Glasblasen mit offener Flamme oder sehr hoher Hitze arbeiten. Glasgravur verändert dagegen die kalte Oberfläche mechanisch. Für Einsteiger ist entscheidend, zwischen Techniken mit eigener Ofen- oder Brennertechnik und solchen zu unterscheiden, die sich in einer normalen Werkstatt beginnen lassen. Je nach Verfahren werden Brennofen, Brenner oder Schneidwerkzeuge nötig; Schutzbrille, Lüftung und hitzefeste Arbeitsflächen gehören dann fest zum Arbeitsplatz. Beim Töpfern folgen auf Handaufbau oder Drehscheibe Trocknung, erster Brand, Glasur und meist ein weiterer Brand.

Bei allen Brennverfahren solltest du außerdem berücksichtigen, dass fremde Materialien und unbekannte Glassorten nicht beliebig miteinander kombiniert werden können. Die Arbeitsweise bestimmt hier stark, welches Werkzeug sinnvoll ist. Ton verzeiht Korrekturen, solange er noch feucht genug ist; heißes oder bereits gebranntes Material verlangt deutlich mehr Planung. Bei Glas kommt der kontrollierte Umgang mit Kanten und Temperatur hinzu. Kleine Probestücke helfen dir, Farben, Glasuren und Oberflächen zu verstehen, bevor du viel Material in ein größeres Projekt steckst.'],
            'guss-form' => ['hero'=>'Flüssiges Material wird feste Form.', 'lead'=>'Guss & Formen ist für alle spannend, die flüssige oder weiche Materialien in eine selbst bestimmte Form bringen möchten. Du gießt Resin, Jesmonite, Beton, Wachs oder Seife und arbeitest mit Formen, Pigmenten und Einlagen. Schon kleine Projekte liefern sichtbare Ergebnisse; entscheidend sind sauberes Mischen, passendes Material und Geduld beim Aushärten.', 'more'=>'Jesmonite härtet schnell und eignet sich gut für dekorative Objekte mit matter Oberfläche. Beton braucht andere Formen, längere Aushärtung und ausreichend stabile Wandstärken. Beim Kerzengießen spielen Wachsart, Docht und Gefäß zusammen; bei Seife sind Rezeptur und Verfahren entscheidend. Polymer Clay und Cold Porcelain werden dagegen modelliert und erst danach gehärtet oder getrocknet. Silikonformen können viele Projekte vereinfachen, sind aber nicht für jedes Material gleich geeignet. Harz, Beton, Wachs, Seife und andere Gießmaterialien unterscheiden sich bei Mischverhältnis, Aushärtung, Formtrennung und notwendiger Schutz- oder Lüftungstechnik. Bei Epoxidharz gehören exaktes Dosieren und ein sicherer Umgang mit nicht ausgehärtetem Material ausdrücklich zum Prozess.

Bei mehrteiligen Formen kommen außerdem Trennfugen, Entlüftung und sauberes Entformen hinzu – drei Punkte, die über Details und Ausschuss entscheiden können. Beim Gießen beginnt ein gutes Ergebnis schon vor dem eigentlichen Materialmix. Form, Trennmittel, Entlüftung und eine waagerechte Arbeitsfläche entscheiden mit darüber, ob Kanten sauber werden und Einschlüsse entstehen. Für Einsteiger sind kleine, einfache Formen sinnvoll. So kannst du Mischverhältnis, Aushärtung und Nachbearbeitung kennenlernen, ohne unnötig viel Material zu verbrauchen oder komplizierte Formen gleichzeitig beherrschen zu müssen.'],
            'genuss' => ['hero'=>'Lebensmittel selbst herstellen und Prozesse verstehen.', 'lead'=>'Genuss-Hobbys drehen sich darum, Lebensmittel und Getränke nicht nur zuzubereiten, sondern ihren Herstellungsprozess selbst zu verstehen und zu steuern. Du röstest, fermentierst, backst, braust, räucherst oder stellst Schokolade her. Wer Geschmack gern experimentell entdeckt, findet hier viel Tiefe. Meist brauchst du gute Rohstoffe, saubere Arbeitsmittel, Zeit und Aufmerksamkeit für Temperatur und Reife.', 'more'=>'Käseherstellung verlangt zusätzlich einen sicheren Umgang mit Milch, Kulturen und Reifung. Beim Räuchern geht es um Rauch, Temperatur und geeignete Lebensmittel, während Pralinen und Bean-to-Bar-Schokolade stark von genauer Temperierung profitieren. Bier und Cider bringen Gärführung, Messwerte und gründliche Reinigung ins Spiel. Gute Einsteigerprojekte sind überschaubar und lassen sich zuverlässig kontrollieren; komplexe Reifungen kommen später. Gärung, Reifung, Röstung und Fermentation brauchen jeweils andere Temperaturen, Zeiten und Hygieneschritte; Abweichungen zeigen sich direkt an Aroma, Textur oder Haltbarkeit. Sauerteig, Kimchi, Kombucha und Koji zeigen besonders deutlich, wie Mikroorganismen, Temperatur, Salzgehalt und Zeit das Ergebnis verändern.

Bei allen Lebensmitteln gilt außerdem: Geruch und Geschmack ersetzen keine sichere Prozessführung, wenn Temperatur, Haltbarkeit oder mögliche Fehlgärungen kritisch sind. Gerade bei selbst hergestellten Lebensmitteln lohnt sich ein kleines Protokoll. Menge, Temperatur, Zeit und verwendete Kulturen lassen sich später viel besser vergleichen als eine bloße Erinnerung. Saubere Gefäße und eindeutige Beschriftung sind dabei keine Bürokratie, sondern Teil des Handwerks. So erkennst du, welche Veränderung tatsächlich für Geschmack, Konsistenz oder Reife verantwortlich war und kannst gelungene Chargen später bewusst wiederholen.'],
            'metall' => ['hero'=>'Metall mit Hitze, Kraft und Präzision formen.', 'lead'=>'Metallhobbys verbinden Kraft, Hitze und erstaunlich präzise Handarbeit. Du schmiedest, gießt, biegst, schneidest oder verbindest Metall zu Werkzeugen, Schmuck, Geflechten und anderen Werkstücken. Wer robuste Materialien mag und gern nachvollzieht, wie sich Form unter Werkzeug und Temperatur verändert, findet hier einen besonders handwerklichen Bereich. Geeignete Werkzeuge und konsequente Sicherheit gehören von Anfang an dazu.', 'more'=>'Kunstschmieden erweitert das um dekorative Formen und Verbindungen. Beim Metallgießen oder Sandguss entsteht zuerst ein Modell und eine Form, bevor flüssiges Metall eingegossen wird – hier sind Hitze, Schutzkleidung und eine geeignete Arbeitsumgebung nicht verhandelbar. Kettenhemdflechten funktioniert dagegen kalt und präzise: Ringgröße, Drahtstärke und Flechtmuster bestimmen Gewicht und Beweglichkeit. Für erste Erfahrungen sind kalte Metallarbeiten oder betreute Schmiedekurse deutlich leichter zugänglich als eigener Guss. Hier kannst du vergleichen, welche Verfahren Platz, Hitzequelle oder Spezialwerkzeug brauchen und welche sich mit überschaubarer Ausstattung in einer kleinen Werkstatt beginnen lassen. Beim Schmieden wird erhitztes Metall unter Hammer und Amboss geformt; Temperatur und Schlagrichtung beeinflussen Kontrolle und Oberfläche.

Auch Funken, scharfe Kanten und schwere Werkstücke gehören zur Planung: Eine stabile Einspannung und freie Arbeitsfläche verhindern viele vermeidbare Probleme. Metallarbeiten unterscheiden sich stark danach, ob du Material trennst, kalt verformst, erhitzt oder verbindest. Darum lohnt es sich, Verfahren nicht nur nach dem gewünschten Ergebnis, sondern nach Arbeitsplatz und vorhandener Schutzausrüstung auszuwählen. Genaues Anreißen und Messen spart später viel Nacharbeit. Kleine Übungsstücke zeigen außerdem schnell, wie sich verschiedene Metalle unter Werkzeug und Wärme verhalten.'],
            'schmuck' => ['hero'=>'Kleine Werkstücke mit viel Präzision.', 'lead'=>'Schmuckherstellung ist kreatives Gestalten im kleinen Maßstab. Du formst, sägst, feilst, lötest, fädelst oder polierst Metall, Draht, Perlen und andere Materialien zu tragbaren Einzelstücken. Das eignet sich besonders für Menschen, die gern präzise arbeiten und persönliche Dinge herstellen. Für den Einstieg reicht eine kleine, zur gewählten Technik passende Werkzeug- und Materialauswahl.', 'more'=>'Schon einfache Ringe oder Anhänger zeigen, wie wichtig saubere Fugen und passende Temperaturen sind. Drahtschmuck kommt oft ohne Löttechnik aus, verlangt aber gleichmäßige Bögen, passende Drahtstärken und belastbare Ösen. Allgemeine Schmuckherstellung kann zusätzlich Perlen, Fassungen, Ketten oder Fundstücke einbeziehen. Für den Einstieg reichen wenige gute Zangen, Feilen und ein klar abgegrenztes Projekt. Edelmetalle solltest du erst einsetzen, wenn die Handgriffe sitzen; Übungsmaterial spart Geld und nimmt Druck aus dem Lernen. Sägen, Feilen, Biegen, Löten und Fassen verlangen je nach Werkstoff unterschiedliche Werkzeuge; präzise Maße und saubere Oberflächen entscheiden über Tragekomfort und Haltbarkeit. Bei kleinen Schmuckstücken fallen Maße, Verbindungen und Oberflächen besonders deutlich auf, deshalb lohnt sauberes Arbeiten von Anfang an.

Wenn Schmuck getragen werden soll, kommen Hautverträglichkeit, stabile Verschlüsse und abgerundete Kanten hinzu; ein schönes Stück muss im Alltag ebenso funktionieren. Schon wenige Millimeter verändern bei Schmuck Proportion und Tragegefühl. Zeichnungen oder einfache Papiermodelle helfen deshalb, Größe und Form vor dem Sägen oder Löten zu prüfen. Auch Hautkontakt spielt eine Rolle: Material, Kanten und Verschlüsse müssen nicht nur schön, sondern angenehm und belastbar sein. Mit der Zeit entwickelst du ein gutes Gefühl dafür, wann Zurückhaltung ein Stück stärker macht als zusätzliche Details.'],
            'leder' => ['hero'=>'Leder schneiden, formen, nähen und prägen.', 'lead'=>'Lederarbeiten verbinden robustes Material mit genauer Handarbeit. Du schneidest, nähst, formst, prägst und bearbeitest Kanten, um Taschen, Gürtel, Schuhe oder andere langlebige Stücke herzustellen. Wer gern praktisch arbeitet und ein Material mit sichtbarer Patina schätzt, findet hier viel Reiz. Wichtig sind passende Lederart, scharfe Werkzeuge und saubere, belastbare Verbindungen.', 'more'=>'Handnähte werden häufig mit vorgestochenen Löchern und Sattlerstich ausgeführt, weil sie sehr haltbar sind. Kanten können geschnitten, geschliffen, gefärbt und poliert werden. Beim Lederprägen wird die Oberfläche angefeuchtet und mit Punzen strukturiert. Sattlerarbeiten stellen höhere Anforderungen an Belastbarkeit und Passform; Schuhmacherei ergänzt Leisten, Sohlenaufbau und sehr genaue Maße. Für den Einstieg sind Etuis, Gürtel oder kleine Taschen sinnvoller als komplizierte tragende Werkstücke. Du findest hier die Unterschiede der Richtungen, geeignete Messer, Nadeln und Lochwerkzeuge sowie Hinweise dazu, wann Materialstärke, Nahtführung und Klebstoff wichtiger sind als dekorative Details.

Bei Taschen, Gürteln oder Schuhteilen lohnt es sich außerdem, Zugrichtungen und Belastung schon beim Zuschnitt zu berücksichtigen, damit Löcher und Nähte nicht ausreißen. Leder lässt sich nicht beliebig korrigieren: Ein Loch, Schnitt oder Prägeschlag bleibt sichtbar. Deshalb sind Schablonen, Markierungen und ein Probestück besonders nützlich. Dicke und Gerbung bestimmen, ob sich Material gut falten, nähen, formen oder punzieren lässt. Für saubere Ergebnisse lohnt es sich außerdem, Kanten bewusst zu bearbeiten statt sie nur nach dem Zuschnitt unverändert zu lassen.'],
            'textil' => ['hero'=>'Fasern, Fäden und Stoffe selbst verarbeiten.', 'lead'=>'Textile Hobbys verwandeln Fasern und Fäden Schritt für Schritt in Garn, Stoff, Kleidung oder dekorative Arbeiten. Du spinnst, webst, filzt, nähst, strickst, häkelst oder knotest und kannst sehr klein beginnen. Der Bereich passt zu dir, wenn du rhythmische Handarbeit, Materialgefühl und sichtbaren Fortschritt magst; Werkzeug und Aufwand hängen stark von der gewählten Technik ab.', 'more'=>'Filzen verbindet Fasern ohne klassisches Garn, entweder trocken mit Nadeln oder nass mit Feuchtigkeit, Seife und Reibung. Tufting arbeitet mit Flor in einem Trägergewebe, Quilten verbindet mehrere textile Lagen. Nähen verlangt Schnitt, Nahtzugabe und Maschinen- oder Handstiche, während Stricken und Häkeln Maschen aufbauen. Makramee und Klöppeln erzeugen Strukturen durch Knoten beziehungsweise gekreuzte Fäden. Für einen guten Einstieg solltest du eine Technik wählen und passende Fasern dazu nehmen, statt wahllos Material zu mischen. Beim Handspinnen entsteht aus Fasern Garn; beim Weben und Brettchenweben wird Garn anschließend zu Fläche und Muster.

Weben, Spinnen, Filzen, Quilten und Tufting formen textile Flächen auf ganz unterschiedliche Weise und brauchen entsprechend verschiedene Garne, Träger und Werkzeuge. Textile Techniken unterscheiden sich nicht nur im Werkzeug, sondern darin, wie Fäden miteinander verbunden oder Flächen aufgebaut werden. Ein kleines Musterstück verrät dir schnell, wie dicht, elastisch oder formstabil ein Material wird. Bei Garnen sind Stärke, Drehung und Faserart entscheidend. Wenn du diese Eigenschaften verstehst, kannst du Projekte gezielter planen und musst weniger über starre Materiallisten arbeiten.'],
            'heimwerken' => ['hero'=>'Reparieren, montieren und kleine Projekte sicher umsetzen.', 'lead'=>'Heimwerken bedeutet, Dinge im eigenen Umfeld selbst zu reparieren, montieren, verbessern oder neu zu bauen. Du misst, bohrst, sägst, schraubst und bearbeitest Oberflächen und lernst dabei, Material und Werkzeug sinnvoll einzusetzen. Das ist ideal, wenn du praktische Probleme gern eigenständig löst. Für viele erste Projekte reicht eine solide Grundausstattung und eine sichere Arbeitsweise.', 'more'=>'Dübel und Schrauben müssen zum Untergrund und zur Last passen; Holz, Mauerwerk und Gipskarton verlangen unterschiedliche Lösungen. Bei Wänden, Böden und Oberflächen geht es um Vorbereitung, passende Materialien und einen sauberen Aufbau. Kleine Bauprojekte helfen, Sägen, Verbinden und Montieren kontrolliert zu üben. Eine Werkstatt muss nicht groß sein, aber Werkzeuge sollten sicher erreichbar und Werkstücke stabil eingespannt sein. Schutzbrille, Gehörschutz oder Staubmaske sind je nach Arbeit keine Kür. Werkzeugwahl, Befestigung und Material sollten immer zum konkreten Projekt passen; für viele Reparaturen reichen wenige gute Grundwerkzeuge statt einer großen Spezialausstattung.

Gerade bei Arbeiten an Strom, Gas, tragenden Bauteilen oder komplexen Installationen ist zudem wichtig zu erkennen, wo Heimwerken endet und Facharbeit beginnt. Vor dem ersten Schnitt oder Bohrloch lohnt sich eine einfache Reihenfolge: messen, markieren, Befestigung und Material prüfen, erst dann arbeiten. Viele typische Fehler entstehen nicht durch mangelnde Kraft, sondern durch falsche Dübel, stumpfe Werkzeuge oder ungenaue Maße. Wer kleine Reparaturen sauber dokumentiert, weiß später außerdem leichter, welche Leitungen, Schrauben oder Ersatzteile an einer Stelle verbaut wurden.'],
            'modellbau' => ['hero'=>'Technik und Gestaltung im verkleinerten Maßstab.', 'lead'=>'Modellbau ist das Hobby für alle, die reale Vorbilder oder eigene Ideen im verkleinerten Maßstab nachbauen möchten. Du montierst, lackierst, detaillierst und je nach Modell auch mechanisierst oder steuerst Fahrzeuge, Schiffe, Flugzeuge oder Anlagen. Reizvoll ist die Mischung aus Planung, Präzision und Technik. Material und Werkzeug richten sich danach, ob dein Modell nur aussehen oder auch funktionieren soll.', 'more'=>'Funktionsmodelle ergänzen Antriebe, Servos, Elektronik oder andere bewegliche Komponenten. Beim Schiffsmodellbau kommen Dichtigkeit und Gewichtsverteilung hinzu, bei Flugmodellen Stabilität und Schwerpunkt. Automodelle verlangen je nach Maßstab Fahrwerk und Antrieb, Modellbahnen verbinden Landschaftsbau mit Gleis- und Elektrotechnik. Modellraketen brauchen besonders sorgfältige Beachtung zugelassener Antriebe, Startplätze und Sicherheitsabstände. Bausätze sind für den Einstieg sinnvoll, weil sie grundlegende Arbeitsschritte überschaubar halten; Eigenkonstruktionen geben später mehr Freiheit. Hier kannst du die Richtungen vergleichen und einschätzen, welche Werkzeuge, Materialien und technischen Kenntnisse für dein gewünschtes Modell tatsächlich nötig sind.

Bei motorisierten oder fliegenden Modellen kommen außerdem Betriebsregeln, sichere Testflächen und regelmäßige technische Kontrollen hinzu, bevor das Modell wirklich eingesetzt wird. Modellbau wird übersichtlicher, wenn du Baugruppen getrennt planst und Trockenproben machst, bevor etwas dauerhaft verklebt wird. Maßstab und Materialstärke müssen zusammenpassen, sonst wirken selbst sauber gebaute Teile zu grob. Je nach Modell kommen Lackierung, Elektrik oder Mechanik hinzu. Ein klarer Bauabschnitt nach dem anderen verhindert, dass feine Details später beim Montieren wieder beschädigt werden.'],
            'robotik-automation' => ['hero'=>'Mechanik, Elektronik und Code in Bewegung bringen.', 'lead'=>'Robotik und Automation verbinden Bauen, Elektronik und Programmierung zu Systemen, die sich bewegen, messen oder selbstständig reagieren. Du montierst Mechanik, steuerst Motoren, liest Sensoren aus und programmierst Abläufe. Wer gern tüftelt und Fehler systematisch löst, bekommt hier schnell sichtbare Erfolgsmomente. Ein kleines Kit oder wenige Komponenten reichen für einen sinnvollen Einstieg.', 'more'=>'Sensoren liefern Informationen über Abstand, Lage oder Umgebung; Mikrocontroller verarbeiten sie und steuern Motoren oder Servos. Für den Einstieg sind kleine Plattformen ideal, weil Fehler an Verkabelung oder Code überschaubar bleiben. Beim Roboterbau wird später die Stromversorgung wichtiger, ebenso saubere Kabelwege und eine Konstruktion, die Wartung zulässt. BattleBots-Modelle erhöhen die Anforderungen an Belastbarkeit und Schutz deutlich und sollten nur in dafür geeigneter Umgebung betrieben werden. Kleine Kits erleichtern den Einstieg, während eigene Konstruktionen mehr Freiheit bei Sensoren, Antrieben, Gehäuse und Programmierung bieten und entsprechend mehr Planung verlangen.

Wenn ein Projekt autonom arbeitet, lohnt sich außerdem ein klarer Not-Aus- oder Abschaltweg, damit Softwarefehler nicht zu unkontrollierter Bewegung führen. Ein guter Einstieg beginnt mit einer klaren Funktion: etwa einen Sensor auslesen, einen Motor gezielt bewegen oder eine einfache Reaktion programmieren. Erst wenn diese Teile einzeln zuverlässig laufen, lohnt sich ihre Verbindung. So bleibt Fehlersuche nachvollziehbar. Für eigene Projekte sind Schaltplan, Kabelführung und dokumentierter Code mindestens so wichtig wie das sichtbare Gehäuse oder die spektakuläre Bewegung.'],
            'computer-retro' => ['hero'=>'Alte Rechner verstehen, erhalten und wieder benutzen.', 'lead'=>'Retrocomputer als Hobby bedeutet, alte Rechner und Konsolen nicht nur zu sammeln, sondern ihre Technik wieder zu verstehen und zu benutzen. Du reinigst, reparierst, testest Hardware und bringst historische Software erneut zum Laufen. Das spricht Technikfans und Nostalgiker gleichermaßen an. Benötigt werden vor allem Geduld, passendes Werkzeug und ein vorsichtiger Umgang mit gealterter Elektronik.', 'more'=>'Korrosion, ausgelaufene Batterien oder gealterte Kondensatoren können Folgeschäden verursachen. Laufwerke brauchen häufig Reinigung oder neue Riemen; bei Bildausgabe und Datenträgern helfen passende Adapter, wenn sie reversibel eingesetzt werden. Mechanische Tastaturen bauen ist ein modernerer Zweig mit Schaltern, Layouts, Platinen und Gehäusen, während PC-Modding Gestaltung und Kühlung verbindet. Wer restauriert, sollte Änderungen dokumentieren und originale Teile möglichst erhalten. Du findest hier konkrete Einstiege in Retrocomputer, Konsolen, Tastaturen und Modding sowie Hinweise darauf, welche Arbeiten mit normalem Werkzeug machbar sind und wann Elektronikkenntnisse oder besondere Vorsicht nötig werden.

Bei alten Datenträgern ist außerdem ein frühes Backup sinnvoll, solange Laufwerk und Medium noch lesbar sind; die Originaldaten sind oft schwerer zu ersetzen als Hardware. Bei alter Hardware ist der Zustand wichtiger als ein schneller Startversuch. Sichtprüfung, passende Spannungsversorgung und dokumentierte Anschlüsse schützen seltene Geräte vor vermeidbaren Schäden. Für Sammler und Bastler gehört auch Software zum Erlebnis: originale Betriebssysteme, Spiele und zeittypische Peripherie zeigen erst, wie sich ein Rechner damals tatsächlich angefühlt hat. Ersatzteile sollten möglichst reversibel eingebaut und Änderungen dokumentiert werden.'],
            'digitale-fertigung' => ['hero'=>'Digitale Entwürfe in echte Teile verwandeln.', 'lead'=>'Digitale Fertigung verbindet Entwerfen am Computer mit einem greifbaren Ergebnis. Du modellierst oder scannst Formen und lässt sie per 3D-Druck, CNC-Fräse oder Laser als reales Teil entstehen. Wer Gestaltung und Technik gern kombiniert, kann hier vom kleinen Ersatzteil bis zum eigenen Objekt viel umsetzen. Nötig sind passende Software, eine geeignete Maschine und Materialkenntnis.', 'more'=>'Resin-Druck liefert feinere Details, verlangt aber sorgfältigen Umgang mit flüssigem Harz, Reinigung und Nachhärtung. CNC-Fräsen arbeitet Material ab und braucht sichere Werkstückspannung, passende Fräser und kontrollierte Vorschübe. Laser schneiden oder gravieren abhängig von Material, Leistung und Fokus; Absaugung und Brandschutz sind dabei zentral. CAD hilft dir, Maße und Konstruktion vor der Fertigung sauber festzulegen. Mit 3D-Scanning lassen sich reale Formen erfassen, meist aber nicht ohne Nachbearbeitung. 3D-Druck, CNC, Laser und Scan eignen sich für unterschiedliche Werkstoffe und Genauigkeiten; Bauraum, Absaugung, Materialkosten und Wartung gehören zur Maschinenwahl dazu. Beim FDM-Druck beeinflussen Material, Düsentemperatur, Schichthöhe und Bauteilorientierung direkt Stabilität und Oberfläche.

Vor der Fertigung lohnt außerdem eine kurze Plausibilitätsprüfung von Maßen und Toleranzen, denn digitale Präzision schützt nicht vor einem falsch konstruierten Teil. Der gemeinsame Nenner digitaler Fertigung ist die Übersetzung von Datei in Material. Ein sauberer Entwurf berücksichtigt deshalb schon Toleranzen, Werkzeugbreite, Materialstärke und Befestigung. Teststücke mit wenigen Zentimetern sparen viel Zeit und Material. Wenn du später mehrere Verfahren kombinierst, kannst du ihre Stärken gezielt nutzen: etwa präzise Zuschnitte, gedruckte Verbindungsteile oder gescannte Formen als Ausgangspunkt.'],
            'audio-hifi' => ['hero'=>'Klang verstehen, Technik entdecken und selbst bauen.', 'lead'=>'Audio & HiFi ist für Menschen, die Klang nicht nur hören, sondern verstehen und gezielt beeinflussen möchten. Du baust Lautsprecher, kombinierst Komponenten, misst oder vergleichst und passt Systeme an Raum und Hörgewohnheiten an. Der Reiz liegt darin, technische Entscheidungen unmittelbar hören zu können. Für den Einstieg reichen ein klar umrissenes Projekt, passende Bauteile und grundlegendes Werkzeug.', 'more'=>'Wer klassische Technik mag, findet beim Restaurieren von Plattenspielern Themen wie Mechanik, Tonabnehmer, Antrieb und Justage. Röhrenverstärker führen tiefer in Schaltung, Bauteile und Messpraxis – wegen hoher Spannungen gehört hier Sicherheit immer dazu. Mit Synthesizern, Eurorack und Effektpedalen wird es experimenteller: Du kannst Klänge selbst erzeugen, verändern und eigene Schaltungen ausprobieren. Wenn du einsteigst, sind überschaubare Projekte ideal, um Löten, Messen und Fehlersuche Schritt für Schritt zu lernen. Mit mehr Erfahrung werden Bauteilvergleich, Abstimmung, Reparatur und gezielte Verbesserungen interessanter.

Dabei spielen auch Werkzeug, Messgeräte, Budget und der sinnvolle Umfang eines Projekts eine Rolle. Bei netzbetriebenen Geräten und besonders bei Röhrentechnik ist außerdem wichtig, klar zwischen ungefährlichen Niedervoltprojekten und Arbeiten mit lebensgefährlichen Spannungen zu unterscheiden. Hören und Messen ergänzen sich in diesem Bereich. Ein Umbau kann technisch korrekt sein und trotzdem nicht zum Raum, Lautsprecher oder eigenen Hörziel passen. Dokumentiere daher Ausgangszustand und Änderungen, bevor du Bauteile ersetzt. Bei Netzspannung oder Röhrentechnik endet der sinnvolle Selbstbau dort, wo sichere Fachkenntnis fehlt; viele interessante Projekte liegen ohnehin im ungefährlichen Kleinspannungs- und Akustikbereich.'],
            'mechanik-uhren' => ['hero'=>'Feine Mechanik sichtbar machen und präzise bewegen.', 'lead'=>'Mechanik & Uhren zeigt besonders anschaulich, wie Zahnräder, Federn, Lager und Kräfte zusammenarbeiten. Du zerlegst, wartest, reparierst oder baust mechanische Systeme von der Armbanduhr bis zum Bewegungsmodell. Wer feinmechanische Zusammenhänge und präzise Handarbeit mag, findet hier viel Tiefe. Je nach Projekt reichen kleine Spezialwerkzeuge oder es braucht deutlich mehr Platz und Technik.', 'more'=>'Teile werden geprüft, gereinigt, sparsam geschmiert und wieder exakt zusammengesetzt. Eine Uhr selbst zu bauen verlangt zusätzlich Verständnis für Räderwerk, Hemmung und Gangregulierung. Modell-Dampfmaschinen und Stirlingmotoren machen thermische und mechanische Prozesse anschaulich, bringen aber heiße Flächen, Druck oder offene Wärmequellen mit sich. Im Modellmaschinenbau stehen Drehen, Fräsen und genaue Passungen stärker im Vordergrund. Für Einsteiger sind einfache Mechanismen oder Wartungsarbeiten sinnvoller als komplexe Uhrwerke. Uhren, Modellmaschinen und feine Mechanik verlangen je nach Größe andere Werkzeuge, doch Sauberkeit, präzise Passungen und sichere Betriebsbedingungen bleiben gemeinsame Grundlagen. Bei mechanischen Uhren sind ein sauberer Arbeitsplatz, passende Schraubendreher und eine geordnete Demontage wichtiger als Kraft.

Bei historischen Uhren und Maschinen sollte zudem dokumentiert werden, welche Teile original sind und welche ersetzt wurden, statt Gebrauchsspuren unnötig wegzupolieren. Feine Mechanik belohnt Ordnung am Arbeitsplatz. Kleine Teile sollten sortiert, ihre Lage fotografiert und nur mit passenden Werkzeugen bewegt werden. Bei Uhren ist zudem Sauberkeit entscheidend, weil Staub oder falsches Öl ganze Werke beeinträchtigen können. Modelle wie Stirling- oder Dampfmaschinen machen Bewegungsabläufe größer sichtbar und helfen, Kurbeln, Lager, Ventile und Übersetzungen besser zu verstehen.'],
            'elektronik' => ['hero'=>'Schaltungen verstehen und eigene Geräte bauen.', 'lead'=>'Elektronik ist das Hobby, bei dem aus Bauteilen, Leitungen und Programmen funktionierende Schaltungen und Geräte entstehen. Du lötest, misst, programmierst und testest – vom einfachen Sensor bis zu Arduino- oder Raspberry-Pi-Projekten. Das passt gut zu neugierigen Tüftlern, die verstehen möchten, warum etwas funktioniert. Grundwerkzeug, Messgerät und wenige Bauteile reichen zum Einstieg.', 'more'=>'Mikrocontroller wie Arduino eignen sich für Sensoren, LEDs, Motoren und kleine Automatisierungen; Raspberry Pi ist stärker, wenn ein komplettes Betriebssystem, Netzwerk oder aufwendigere Software gebraucht wird. Saubere Stromversorgung und gemeinsame Masse sind typische Stolperstellen. Beim Löten zählen richtige Temperatur, kurze Lötzeiten und mechanisch stabile Verbindungen. Für den Einstieg sind Niedervolt-Projekte deutlich sinnvoller als Netzspannung. Analoge Schaltungen, Mikrocontroller und kleine Computerprojekte führen zu unterschiedlichen Projekten, bauen aber auf denselben Grundlagen aus Stromversorgung, Bauteilen und Messung auf.

Ein einfacher Schaltplan und beschriftete Messpunkte sparen später viel Zeit, weil du Fehler nachvollziehen kannst, statt jedes Kabel immer wieder neu zu verfolgen. Elektronik wird leichter, wenn du Schaltungen in Funktionsblöcke zerlegst und Messpunkte von Anfang an mitdenkst. Ein Multimeter, ein begrenztes Netzteil und ein ordentliches Steckbrett reichen für viele erste Projekte. Bauteilwerte und Polarität sollten nachvollziehbar dokumentiert sein. So lernst du nicht nur, dass eine Schaltung funktioniert, sondern kannst auch erklären, warum sie sich bei einer Änderung anders verhält.'],
            'funk' => ['hero'=>'Signale senden, empfangen und ihren Weg verstehen.', 'lead'=>'Funkhobbys machen unsichtbare Signale hör- und messbar. Du sendest, empfängst, baust Antennen auf, hörst Funkverkehr oder stellst selbst Verbindungen über größere Entfernungen her. Wer Technik, Kommunikation und Experimentieren verbindet, findet hier ein ungewöhnlich lebendiges Feld. Je nach Funkdienst brauchst du ein passendes Gerät, Antenne und teilweise auch Kenntnisse, Zulassung oder Prüfung.', 'more'=>'CB-Funk arbeitet in einem fest geregelten Bereich mit zugelassenen Geräten. Amateurfunk eröffnet wesentlich mehr Möglichkeiten, setzt für den Sendebetrieb aber eine entsprechende Zulassung voraus. Antennenform, Länge, Standort und Kabelverluste beeinflussen Reichweite oft stärker als reine Sendeleistung. Beim Satellitenfunk kommen Bahnzeiten und gerichtete Antennen hinzu; Wettersonden-Tracking verbindet Funkempfang mit Positionsdaten. Funkpeilung nutzt Signalstärke und Richtung, um Sender zu lokalisieren. Empfang ist in vielen Bereichen ohne Sendebetrieb möglich; für aktives Senden gelten je nach Funkdienst eigene Frequenzen, Leistungsgrenzen und teilweise Zulassungen.

Gute Empfangspraxis umfasst außerdem Störquellen im eigenen Haushalt: Schaltnetzteile, USB-Geräte oder schlechte Kabel können schwache Signale überraschend stark überdecken. Beim Funk entscheidet nicht nur die Sendeleistung über eine Verbindung. Frequenz, Antenne, Standort, Ausbreitungsbedingungen und Betriebsart wirken zusammen. Empfangsprojekte sind deshalb ein unkomplizierter Einstieg, bevor du selbst sendest. Für sendende Anwendungen gehören die jeweiligen Frequenz- und Zulassungsregeln zur Grundausstattung. Ein Logbuch macht Beobachtungen vergleichbar und zeigt, welche Bedingungen tatsächlich gute Verbindungen ermöglichen.'],
            'smart-home' => ['hero'=>'Automatisieren, ohne das Zuhause unnötig kompliziert zu machen.', 'lead'=>'Smart Home bedeutet, Geräte im Zuhause so zu vernetzen, dass Licht, Heizung, Sensoren oder andere Funktionen automatisch und trotzdem kontrollierbar zusammenarbeiten. Du planst Abläufe, verbindest Komponenten und passt Regeln an deinen Alltag an. Das eignet sich für Technikfans mit praktischem Nutzen im Blick. Für den Einstieg reicht ein kleines, klar begrenztes Automationsprojekt.', 'more'=>'Funkstandards, Reichweite und Stromversorgung bestimmen, welche Sensoren und Aktoren sinnvoll sind. Lokale Steuerungen können unabhängiger vom Internet sein, verlangen aber mehr Einrichtung und Wartung. Bei Cloud-Systemen sind Datenschutz, Herstellerbindung und die Frage wichtig, was bei einem Dienstausfall noch funktioniert. Netzspannung gehört in fachkundige Hände; viele interessante Projekte lassen sich vollständig mit fertigen, zugelassenen Geräten und Niedervolt-Komponenten umsetzen. Ein übersichtlicher Systemaufbau mit klar benannten Geräten und wenigen nachvollziehbaren Automationen lässt sich stabiler betreiben und später leichter erweitern.

Für wichtige Funktionen sollte außerdem immer geklärt sein, was bei leerer Batterie, WLAN-Ausfall oder defekter Zentrale passiert und wie du manuell eingreifen kannst. Ein gutes Smart Home bleibt auch verständlich, wenn eine App oder Internetverbindung ausfällt. Plane deshalb zuerst Funktionen und manuelle Bedienung, dann Automationen. Ein sauber benanntes System mit dokumentierten Geräten und Regeln lässt sich später viel leichter erweitern. Besonders bei Licht, Heizung und Zutritt sollte Komfort nie bedeuten, dass grundlegende Bedienung oder Sicherheit von einer einzigen Cloud-Verbindung abhängen.'],
            'rc-modelltechnik' => ['hero'=>'Modelle steuern, abstimmen und wirklich beherrschen.', 'lead'=>'RC-Modelltechnik verbindet Modellbau mit echter Bewegung und Steuerung. Du fährst, fliegst oder steuerst Autos, Boote, Flugzeuge, Drohnen und andere Modelle und lernst dabei Mechanik, Elektronik und Fahr- oder Flugverhalten kennen. Besonders reizvoll ist, dass Änderungen sofort spürbar werden. Zum Einstieg brauchst du ein geeignetes Modell, Fernsteuerung, Energieversorgung und einen passenden sicheren Übungsort.', 'more'=>'Crawler und Scale-Modelle setzen auf Kontrolle und Geländegängigkeit, Drift- und Offroad-Modelle auf ganz andere Abstimmung. RC-Boote brauchen Dichtigkeit und Kühlung; Segelboote zusätzlich eine passende Segelsteuerung. Flugzeuge und Helikopter stellen höhere Anforderungen an Schwerpunkt, Stabilität und Pilotenkönnen. FPV-Drohnen verbinden schnelle Steuerung mit Kamera und Videosystem, während Racing besonders robuste Komponenten und viel Übung verlangt. Akkus müssen passend geladen, gelagert und überwacht werden. Hier kannst du die vielen Sparten vergleichen, Komponenten verstehen und einschätzen, ob ein Ready-to-Run-Modell, ein Bausatz oder ein eigener Aufbau für deinen Einstieg sinnvoll ist.

Bei Funkmodellen mit hoher Geschwindigkeit oder größerer Masse ist außerdem ein Fail-Safe wichtig, damit ein Signalverlust nicht einfach zu unkontrollierter Weiterfahrt führt. Bei ferngesteuerten Modellen gehören Fahr- oder Flugverhalten und Wartung zusammen. Akkuzustand, Befestigungen, Lenkung und Funkverbindung solltest du vor jeder Nutzung kurz prüfen. Änderungen an Übersetzung, Fahrwerk oder Schwerpunkt lassen sich am besten einzeln testen. So erkennst du, was das Modell tatsächlich verbessert, und vermeidest, dass mehrere Umbauten gleichzeitig neue Probleme verdecken.'],
            'astronomie' => ['hero'=>'Den Himmel beobachten, messen und fotografieren.', 'lead'=>'Astronomie als Hobby bedeutet, den Nachthimmel bewusst zu beobachten und Himmelsobjekte selbst zu finden, zu fotografieren oder zu vermessen. Du beschäftigst dich mit Mond, Planeten, Sternhaufen, Nebeln und Galaxien. Wer gern draußen beobachtet und Geduld mitbringt, erlebt hier echte Entdeckungsmomente. Schon Fernglas und Sternkarte reichen; Teleskop und Kamera können später dazukommen.', 'more'=>'Eine stabile Montierung ist oft wichtiger als ein größerer Tubus, weil Zittern und ungenaue Nachführung jedes Detail zunichtemachen. Astrofotografie erhöht die Anforderungen deutlich: Belichtungszeit, Nachführung, Fokus und Bildbearbeitung werden Teil des Hobbys. Sonnenbeobachtung darf ausschließlich mit dafür vorgesehenen, sicheren Filtern erfolgen; improvisierte Lösungen sind gefährlich. Radioastronomie arbeitet ganz anders und macht Himmelsquellen über empfangene Radiowellen sichtbar. Für Einsteiger sind Sternkarten, Fernglas und einfache Beobachtungsziele ein guter Start. Visuelle Beobachtung, Mond- und Planetenfotografie, Deep-Sky-Aufnahmen und Radioastronomie brauchen sehr unterschiedliche Ausrüstung und profitieren jeweils von klar gewählten Beobachtungszielen. Mond und Planeten stellen andere Anforderungen an Optik und Vergrößerung als lichtschwache Deep-Sky-Objekte.

Beobachtungsprotokolle mit Datum, Ort, Seeing und verwendeter Optik machen Fortschritt außerdem nachvollziehbar und helfen, vermeintliche Geräteprobleme von schlechten Bedingungen zu trennen. Für erfolgreiche Beobachtungen ist ein dunkler Standort oft wertvoller als ein größeres Teleskop. Sternkarten oder Planetariums-Apps helfen, Ziele passend zu Jahreszeit und Uhrzeit auszuwählen. Ein Beobachtungsbuch mit Datum, Wetter und verwendeter Vergrößerung macht Fortschritte sichtbar. Auch mit bloßem Auge oder Fernglas lassen sich viele Himmelsphänomene entdecken, bevor aufwendigere Optik sinnvoll wird.'],
            'mikroskopie' => ['hero'=>'Strukturen entdecken, die dem Auge verborgen bleiben.', 'lead'=>'Mikroskopie öffnet eine Welt, die mit bloßem Auge verborgen bleibt. Du bereitest kleine Proben vor, beleuchtest sie passend und untersuchst Zellen, Kristalle, Fasern, Wasserorganismen oder andere feine Strukturen. Das ist ideal für neugierige Beobachter, die genau hinschauen möchten. Ein ordentliches Mikroskop, Objektträger und einfache Präparierhilfen reichen für viele spannende Einstiege.', 'more'=>'Teich- und Gewässerproben zeigen schon mit wenig Aufwand eine enorme Vielfalt, verändern sich aber schnell und sollten frisch untersucht werden. Kristallmikroskopie und Polarisation machen Strukturen sichtbar, die im normalen Licht kaum auffallen. Mikrofotografie verlangt zusätzlich eine stabile Kameraanbindung und sauberen Fokus; mehr Megapixel ersetzen keine gute Optik. Vergrößerungsangaben sind nur sinnvoll, solange das Objektiv tatsächlich neue Details auflöst. Objektträger, Deckgläser, Pipetten und saubere Arbeitsweise gehören deshalb zur Grundausstattung. Mikroskoptyp, Beleuchtung und Präparation müssen zur Probe passen; hohe Vergrößerungsangaben allein sagen wenig darüber aus, wie viele Details tatsächlich sichtbar werden. Ein einfaches Durchlichtmikroskop eignet sich besonders für dünne, transparente Proben und lebende Mikroorganismen.

Wenn du Funde vergleichen möchtest, lohnt es sich außerdem, Vergrößerung und Beleuchtungsart bei Fotos mitzunotieren, statt nur einzelne spektakuläre Bilder zu sammeln. Gute Präparate sind wichtiger als maximale Vergrößerung. Beleuchtung, Kontrast und saubere Deckgläser entscheiden oft darüber, ob Strukturen erkennbar bleiben. Beginne mit häufigen, leicht verfügbaren Proben und notiere Vergrößerung und Präparation. Wer später fotografiert oder misst, profitiert besonders von reproduzierbaren Einstellungen, weil Bilder dann vergleichbar werden und kleine Veränderungen nicht mit wechselnder Beleuchtung verwechselt werden.'],
            'wetter-umwelt' => ['hero'=>'Wetter beobachten und Umweltdaten selbst erfassen.', 'lead'=>'Wetter & Umwelt macht Vorgänge messbar, die uns täglich umgeben. Du beobachtest Wolken, Wind, Niederschlag, Gewitter oder Luftqualität und kannst eigene Messreihen aufbauen und vergleichen. Wer Naturbeobachtung mit Daten verbinden möchte, findet hier einen direkten Einstieg. Schon Thermometer, Regenmesser, Wetter-App oder einfache Sensoren reichen, bevor eine komplette Wetterstation sinnvoll wird.', 'more'=>'Falsche Montage kann Werte deutlich verfälschen, etwa wenn Temperaturfühler direkte Sonne abbekommen oder Windmesser im Windschatten stehen. Wolkenbeobachtung funktioniert auch ohne Elektronik und schult den Blick für Wetterentwicklung. Gewittertracking kombiniert Radar-, Blitz- und eigene Beobachtungsdaten; Storm Spotting verlangt dabei vor allem Abstand und sichere Standorte, nicht Nähe zum Unwetter. Blitzfotografie braucht ebenfalls eine sichere Position und passende Kameraeinstellungen. Bei Luftqualitätsmessungen müssen Sensorgrenzen und Kalibrierung berücksichtigt werden. Hier lernst du, welche Messgrößen zusammengehören, wie du Daten vergleichbar dokumentierst und wann öffentliche Messnetze eine wichtige Ergänzung zu den eigenen Geräten sind. Sensoren müssen sinnvoll platziert sein, damit Messwerte nicht mit bloßem Wettergefühl oder ungünstigem Standort verwechselt werden.

Langfristige Daten werden besonders nützlich, wenn Standort und Sensoren nicht ständig verändert werden und Änderungen sauber dokumentiert bleiben. Messdaten werden erst interessant, wenn Ort, Zeitpunkt und Bedingungen dokumentiert sind. Ein einzelner Temperatur- oder Luftwert sagt wenig ohne Vergleich. Für Wetterbeobachtung kannst du deshalb mit wenigen verlässlichen Sensoren beginnen und später ergänzen. Bei Gewittern und Sturm bleibt Abstand wichtiger als die Messung: Beobachtungsplätze und Technik sollten so gewählt werden, dass du nicht wegen eines besseren Datensatzes unnötige Risiken eingehst.'],
            'naturbeobachtung' => ['hero'=>'Tiere finden, ohne sie unnötig zu stören.', 'lead'=>'Naturbeobachtung bedeutet, Tiere in ihrem Lebensraum zu finden, zu erkennen und möglichst ungestört zu erleben. Du beobachtest Vögel, Schmetterlinge, Amphibien oder andere Arten, lernst Verhalten und Lebensräume kennen und dokumentierst Sichtungen. Besonders reizvoll ist das für aufmerksame Menschen, die gern draußen unterwegs sind. Fernglas, Bestimmungshilfe und Geduld sind oft wichtiger als umfangreiche Ausrüstung.', 'more'=>'Wildkameras zeigen, was an einem Ort passiert, wenn niemand danebensteht, müssen aber rechtlich und rücksichtsvoll eingesetzt werden. Schmetterlinge, Libellen und Käfer sind stark an Wetter, Tageszeit und bestimmte Lebensräume gebunden. Tierspuren liefern Informationen auch dann, wenn das Tier selbst nicht sichtbar ist. Für gute Beobachtungen ist eine saubere Dokumentation mit Datum, Ort und Bedingungen wertvoller als hektisches Fotografieren. Ausrüstung unterstützt die Beobachtung, doch Abstand und störungsarmes Verhalten bleiben besonders an Brutplätzen, Quartieren und anderen empfindlichen Lebensräumen entscheidend. Bioakustik und Detektoren erschließen zusätzlich Tierstimmen und Fledermäuse, die sich nicht immer direkt beobachten lassen.

Bei seltenen oder störungsempfindlichen Arten sollten genaue Fundorte außerdem nicht gedankenlos öffentlich verbreitet werden, wenn dadurch zusätzlicher Besucherdruck entstehen kann. Geduld und ein ruhiger Standort bringen häufig mehr als ständiges Hinterherlaufen. Ein Fernglas, Bestimmungsbuch oder Aufnahmegerät ergänzt die Beobachtung, ersetzt aber nicht das genaue Hinschauen. Notiere Datum, Ort und Verhalten, wenn du später vergleichen möchtest. Gerade bei Brutplätzen, Nachtquartieren oder empfindlichen Arten sollte der Abstand groß genug bleiben, damit dein Interesse das Verhalten nicht verändert.'],
            'messen-analysieren' => ['hero'=>'Mit eigenen Messungen aus Vermutungen Daten machen.', 'lead'=>'Messen & Analysieren richtet sich an alle, die Natur und Alltag nicht nur beobachten, sondern mit eigenen Daten genauer verstehen möchten. Du misst etwa Wasserwerte, Strahlung, Boden, Licht oder andere Größen und vergleichst Ergebnisse über Zeit und Ort. Der Reiz liegt im überprüfbaren Ergebnis. Welche Geräte du brauchst, hängt vollständig von der gewählten Fragestellung ab.', 'more'=>'Bodenanalysen betrachten unter anderem pH, Nährstoffe und Struktur. Spektroskopie zerlegt Licht und macht charakteristische Linien oder Absorptionsbereiche sichtbar, während Elektrochemie Spannungen, Elektroden und Reaktionen direkt messbar macht. Jede Methode hat Messbereiche und Fehlerquellen. Kalibrierung, saubere Gefäße, gleiche Bedingungen und nachvollziehbare Notizen sind deshalb Teil des Experiments. Gefährliche Chemikalien sind für Hobbyversuche nicht nötig. Sinnvolle Messgrößen hängen von der Fragestellung ab; wiederholte Messungen, Kontrollproben und saubere Dokumentation verhindern, dass einzelne Zahlen zu schnell überbewertet werden.

Wiederholungsmessungen und Kontrollproben zeigen außerdem schnell, ob ein auffälliger Wert wirklich reproduzierbar ist oder nur durch Handhabung und Messgerät entstanden ist. Messgeräte liefern Zahlen, aber erst Kalibrierung, Probennahme und Vergleich machen daraus brauchbare Ergebnisse. Du lernst, Wasser, Boden, Licht oder chemische Eigenschaften mit passenden Methoden zu untersuchen und Werte kritisch einzuordnen. Für den Einstieg reichen wenige verlässliche Messgrößen; sauber beschriftete Proben und wiederholte Messungen sind oft wichtiger als ein Gerät mit möglichst vielen Funktionen, Anzeigen oder unnötigen Messbereichen.'],
            'spotting-verkehr' => ['hero'=>'Fahrzeuge erkennen, dokumentieren und vergleichen.', 'lead'=>'Spotting & Verkehr verbindet Beobachtung, Technikinteresse und Dokumentation. Du suchst gezielt Flugzeuge, Züge, Schiffe oder andere Fahrzeuge, erkennst Typen und Varianten und hältst besondere Sichtungen fotografisch oder schriftlich fest. Technikinteresse und die Freude, gezielt unterwegs zu sein, treffen hier direkt aufeinander. Kamera oder Fernglas helfen, wichtiger sind gute Standorte und verlässliche Informationen.', 'more'=>'Trainspotting kann Baureihen, Zugnummern und Strecken dokumentieren; Bahnflächen selbst sind dabei selbstverständlich tabu. Beim Ship Spotting helfen Schiffsname, IMO-Nummer, Typ und Hafenbewegungen bei der Zuordnung. Car Spotting konzentriert sich je nach Interesse auf seltene Modelle, Generationen oder besondere Ausführungen. Ein Fernglas und eine Kamera können nützlich sein, sind aber kein Muss. Wichtig sind Rücksicht, Verkehrs- und Grundstücksregeln sowie ein sauberer Umgang mit Personen auf Bildern. Flugzeuge, Züge, Schiffe und Fahrzeuge lassen sich nach unterschiedlichen Merkmalen dokumentieren; Standortwahl und freier, sicherer Blick sind dabei wichtiger als maximale Nähe. Flugpläne, Kennungen, Registrierungen und gute Beobachtungsplätze helfen dabei, Sichtungen später sicher einzuordnen.

Besonders bei Fotografie mit langen Brennweiten lohnt sich außerdem ein bewusster Standort, an dem du weder Verkehr noch Einsatzabläufe oder andere Personen behinderst. Spotting wird spannender, wenn aus einzelnen Fotos eine nachvollziehbare Dokumentation entsteht. Kennzeichen, Baureihe, Betreiber, Strecke oder Standort liefern Kontext, sofern ihre Erfassung rechtlich und praktisch unproblematisch ist. Gute Plätze erlauben freie Sicht, ohne Betriebsabläufe zu stören. Mit festen Kategorien und konsistenten Dateinamen wächst aus vielen Einzelbeobachtungen nach und nach ein persönliches Archiv.'],
            'citizen-science' => ['hero'=>'Beobachtungen sammeln, die wissenschaftlich nutzbar werden.', 'lead'=>'Citizen Science macht aus privaten Beobachtungen Daten, die in echten Forschungsprojekten genutzt werden können. Du zählst Arten, meldest Funde, misst Umweltwerte oder dokumentierst Veränderungen nach festgelegten Methoden. Das ist besonders spannend, wenn du Natur oder Wissenschaft magst und deine Freizeitbeobachtung einen größeren Nutzen haben soll. Meist reichen Smartphone, Sorgfalt und ein passendes Projekt.', 'more'=>'Insektenkartierung verlangt oft gute Fotos oder sichere Bestimmung, weil ähnliche Arten leicht verwechselt werden. Wildtiermonitoring kann Sichtungen, Spuren oder Kameradaten einbeziehen. Phänologie dokumentiert wiederkehrende Ereignisse wie Blühbeginn, Laubaustrieb oder Fruchtreife und wird besonders wertvoll, wenn dieselben Orte über längere Zeit beobachtet werden. Vor dem Start solltest du ein seriöses Projekt auswählen und dessen Vorgaben genau lesen. Standortdaten können bei empfindlichen Arten bewusst eingeschränkt werden. Wissenschaftlich nutzbare Meldungen brauchen ein festes Schema, verlässliche Bestimmung und passende Zusatzdaten; eine persönliche Artenliste erfüllt nicht automatisch dieselben Anforderungen. Definierte Zählregeln, feste Zeiträume und genaue Einträge machen Beobachtungen verschiedener Personen erst wirklich vergleichbar.

Wenn du regelmäßig mitmachst, wird Konstanz besonders wertvoll: dieselbe Methode am selben Ort kann langfristig mehr aussagen als viele zufällige Einzelbeobachtungen. Damit Beobachtungen wissenschaftlich nutzbar werden, müssen Methode und Meldeschema zum jeweiligen Projekt passen. Ein korrekt bestimmtes häufiges Tier kann wertvoller sein als ein spektakulärer, aber unsicherer Fund. Lies deshalb vorab, welche Angaben gebraucht werden. Fotos, Standortgenauigkeit und wiederholte Beobachtungen helfen häufig bei der Prüfung und machen deine Beiträge auch langfristig nachvollziehbar.'],
            'natur-bestimmen' => ['hero'=>'Arten erkennen, Merkmale vergleichen und sicher benennen.', 'lead'=>'Natur bestimmen heißt, Pflanzen, Pilze, Tiere, Spuren oder andere Funde anhand sichtbarer Merkmale möglichst sicher einzuordnen. Du vergleichst Form, Farbe, Struktur, Standort und weitere Kennzeichen und lernst dabei immer genauer hinzusehen. Wer gern draußen entdeckt und Namen mit Wissen verbinden möchte, braucht vor allem gute Bestimmungshilfen, Fotos, Lupe und Geduld.', 'more'=>'Pilzbestimmung ist besonders anspruchsvoll, weil Hut, Lamellen oder Röhren, Stiel, Geruch, Verfärbungen und Standort zusammengehören. Eine Bestimmung aus einem einzigen unscharfen Bild kann daher falsch sein. Apps sind gute Hinweise, aber kein sicherer Endpunkt. Gerade bei Pilzen gilt: Eine vermutete Art aus Internet oder App ist keine Grundlage für den Verzehr. Hier lernst du, welche Merkmale du dokumentieren solltest, welche Hilfsmittel sinnvoll sind und wann ein Fund besser unbestimmt bleibt, statt mit falscher Sicherheit benannt zu werden.

Ein eigenes Fotoarchiv mit Gesamtansicht und Detailmerkmalen hilft außerdem, spätere Vergleiche zu machen und Bestimmungen mit neuen Kenntnissen noch einmal zu prüfen. Bestimmen bedeutet, Merkmale systematisch zu vergleichen statt nach dem ersten ähnlichen Foto zu entscheiden. Bei Pflanzen, Pilzen, Flechten und Moosen zählen unterschiedliche Details wie Blätter, Sporenmerkmale, Wuchsform oder Standort. Lupe, Bestimmungsschlüssel und gute Fotos helfen dir weiter. Unsichere Funde bleiben bewusst unbestimmt; besonders bei Speisepilzen ersetzt eine Online-Einschätzung keine sichere Fachbestimmung.'],
            'bonsai-miniatur' => ['hero'=>'Bäume im Kleinen über Jahre bewusst gestalten.', 'lead'=>'Bonsai & Miniaturpflanzen verbindet Pflanzenpflege mit langfristiger Gestaltung. Du formst kleine Bäume oder begleitende Pflanzen über Jahre, schneidest, drahtest, topfst um und reagierst auf Wachstum und Jahreszeiten. Besonders wohl fühlen sich hier Pflanzenfreunde mit Geduld und Freude an genauer Beobachtung. Der Reiz liegt darin, dass sich ein lebendes Gestaltungsergebnis langsam mit dir weiterentwickelt.', 'more'=>'Drahten kann Äste lenken, darf aber nicht in die Rinde einschneiden. Penjing arbeitet häufig freier und bezieht Landschaftselemente ein; Saikei stellt kleine Landschaftsszenen aus mehreren Pflanzen, Steinen und Substrat zusammen. Besonders wichtig ist die Pflanzenart: Viele klassische Bonsai gehören dauerhaft nach draußen und gehen in warmen Wohnräumen langfristig ein. Kleine Schalen trocknen schneller aus, weshalb Gießen nicht nach Kalender, sondern nach Substrat und Wetter erfolgen sollte. Einsteiger profitieren von robusten Arten und guter Grundpflege mehr als von sofortigem starken Formschnitt.

Bonsai, Penjing und Saikei unterscheiden sich in Aufbau und Gestaltung, verlangen aber gleichermaßen passende Pflanzenarten, scharfes Werkzeug und langfristig konsequente Pflege. Langfristige Planung gehört hier zum Hobby. Fotos aus derselben Perspektive zeigen, wie sich Stamm, Krone und Wurzeln über Jahre verändern und ob Eingriffe wirklich den gewünschten Effekt haben. Nach starkem Umtopfen oder Schnitt braucht ein Baum Erholung statt sofort neuer Gestaltung. Wer Pflege und Formgebung trennt, hält die Pflanze gesünder und entwickelt gleichzeitig ein klareres Gefühl für Proportion und Reife.'],
            'zimmerpflanzen' => ['hero'=>'Pflanzen drinnen gesund halten und gezielt vermehren.', 'lead'=>'Zimmerpflanzen als Hobby bedeutet mehr als gelegentliches Gießen: Du stellst Pflanzen nach Licht, Wasserbedarf und Wuchs passend zusammen, vermehrst sie und beobachtest ihre Entwicklung. Von pflegeleichten Grünpflanzen bis zu anspruchsvollen Sammlerarten ist viel möglich. Das eignet sich für alle, die Zuhause lebendig gestalten und dabei Pflanzen wirklich verstehen möchten; Topf, Substrat und Standort sind die Basis.', 'more'=>'Deshalb sollte der Standort vor dem Gießrhythmus beurteilt werden. Staunässe entsteht häufig durch ungeeignetes Substrat oder fehlenden Abfluss, nicht nur durch zu viel Wasser. Seltene Zimmerpflanzen können besondere Ansprüche an Luftfeuchte oder Temperatur haben, sind aber nicht automatisch schwieriger. Bei der Pflanzenvermehrung unterscheiden sich Kopfstecklinge, Stammstücke, Teilung und bewurzelte Ableger deutlich. Sauberes Werkzeug und gesundes Ausgangsmaterial senken das Risiko von Fäulnis. Standort, Substrat, Topf und Vermehrungsmethode sollten zur jeweiligen Pflanzenart passen; ein einheitliches Pflegeprogramm für den gesamten Bestand führt schnell zu Problemen.

Bei neuen Pflanzen lohnt sich zudem eine kurze Quarantäne und Schädlingskontrolle, bevor sie direkt zwischen einen bereits gesunden Bestand gestellt werden. Viele Probleme lassen sich verhindern, wenn du Pflanzen nicht nach festen Wochentagen gießt, sondern Substrat, Topfgewicht und Jahreszeit beobachtest. Beim Vermehren lohnt sich eine eindeutige Beschriftung von Art, Datum und Methode. So erkennst du, welche Stecklinge wirklich zuverlässig bewurzeln. Neue Substrate oder Dünger sollten zunächst an wenigen Pflanzen getestet werden, bevor der ganze Bestand umgestellt wird.'],
            'kakteen-sukkulenten' => ['hero'=>'Mit wenig Wasser richtig umgehen.', 'lead'=>'Kakteen & Sukkulenten sind ideal, wenn dich ungewöhnliche Pflanzenformen, langsames Wachstum und angepasste Überlebensstrategien faszinieren. Du pflegst, sammelst und vermehrst wasserspeichernde Pflanzen und lernst, Licht, Substrat, Gießen und Ruhezeiten richtig einzuschätzen. Viele Arten brauchen wenig Platz. Entscheidend sind ein heller Standort, sehr durchlässiges Substrat und Zurückhaltung beim Wasser.', 'more'=>'Viele Arten wachsen saisonal und benötigen in Ruhephasen deutlich weniger Wasser. Mineralische Bestandteile im Substrat verbessern die Drainage und verhindern, dass Wurzeln lange nass stehen. Lithops haben besonders ausgeprägte Wachstumszyklen; falsches Gießen während des Blattwechsels kann Probleme verursachen. Nach einem dunklen Winter sollten Pflanzen langsam an intensive Sonne gewöhnt werden, damit sie nicht verbrennen. Umtopfen ist eine gute Gelegenheit, Wurzeln auf Fäulnis oder Schädlinge zu prüfen. Kakteen, andere Sukkulenten und Lithops unterscheiden sich in Wachstumsrhythmus und Wasserbedarf, brauchen aber gemeinsam viel Licht und dauerhaft gut drainierte Wurzelbereiche. Kakteen gehören botanisch zu den Sukkulenten, aber nicht jede sukkulente Pflanze ist ein Kaktus.

So lässt sich vermeiden, dass vermeintlich pflegeleichte Pflanzen ausgerechnet durch zu viel Aufmerksamkeit geschädigt werden. Bei der Vermehrung über Ableger, Stecklinge oder Samen gelten wiederum unterschiedliche Warte- und Trocknungszeiten, die du nicht einfach vom normalen Gießen ableiten solltest. Bei diesen Pflanzen ist Wachstum oft langsamer, als Anfänger erwarten. Veränderungen an Standort oder Bewässerung sollten deshalb nicht im Wochenrhythmus erfolgen. Ein mineralisch geprägtes Substrat und Töpfe mit gutem Abfluss erleichtern die Kontrolle. Blüten, neue Triebe und feste Gewebe sind verlässlichere Erfolgssignale als ständig feuchte Erde oder besonders schnelles Längenwachstum.'],
            'orchideen-exoten' => ['hero'=>'Ungewöhnliche Pflanzen nach ihren echten Bedürfnissen pflegen.', 'lead'=>'Orchideen & Exoten versammelt Pflanzen, deren Pflege oft stärker von Herkunft und Mikroklima abhängt als bei klassischen Zimmerpflanzen. Du kultivierst besondere Arten, beobachtest Blüte und Wachstum und passt Licht, Feuchtigkeit, Temperatur und Substrat gezielt an. Das ist reizvoll für Pflanzenfreunde, die gern genauer hinschauen und unterschiedliche Lebensweisen entdecken. Spezialtechnik ist nicht immer nötig, Wissen dagegen schon.', 'more'=>'Staunässe an den Wurzeln ist deshalb problematisch. Bromelien können Wasser in Blatttrichtern sammeln, während Tillandsien Feuchtigkeit über ihre Blätter aufnehmen und gute Luftzirkulation brauchen. Fleischfressende Pflanzen reagieren häufig empfindlich auf mineralreiches Leitungswasser und benötigen je nach Art ganz verschiedene Ruhephasen oder Lichtmengen. Dünger, der für normale Zimmerpflanzen passt, kann bei manchen Spezialisten zu viel sein. Bevor du eine seltene Art kaufst, lohnt sich deshalb ein Blick auf ihren natürlichen Standort. Orchideen, Bromelien, Tillandsien und Karnivoren brauchen jeweils eigene Kulturbedingungen; Zusatzlicht oder höhere Luftfeuchte sind nur sinnvoll, wenn der konkrete Standort sie tatsächlich erfordert. Viele Orchideen wachsen in der Natur nicht in normaler Erde, sondern auf Bäumen oder in sehr luftigen Substraten.

Gerade bei selten angebotenen Pflanzen sollte außerdem die legale, nachvollziehbare Herkunft wichtiger sein als der Reiz eines möglichst ungewöhnlichen Exemplars. Viele Exoten zeigen ihre Bedürfnisse direkt an Wurzeln und Blättern. Transparente Töpfe, luftige Aufhängungen oder offene Substrate machen diese Signale leichter sichtbar. Statt pauschal hohe Luftfeuchte zu erzeugen, solltest du immer auch Luftbewegung berücksichtigen. Bei Spezialarten lohnt sich vor dem Kauf die Frage, ob Temperatur und Licht deines Standorts dauerhaft passen – nicht nur während weniger Sommerwochen.'],
            'hydro-indoor' => ['hero'=>'Pflanzen ohne klassische Erde kontrolliert versorgen.', 'lead'=>'Hydro & Indoor umfasst Pflanzenkultur ohne klassische Gartenerde und Systeme, bei denen Wasser, Nährstoffe und Licht besonders kontrolliert werden. Du arbeitest mit Hydrokultur, Semi-Hydro oder Hydroponik und kannst Pflanzen auch unabhängig vom Garten kultivieren. Besonders interessant ist das für alle, die Pflanzen gern sauber, technisch oder platzsparend kultivieren möchten. Gefäße, Substratersatz, Nährlösung und passende Beleuchtung bilden die Grundlage.', 'more'=>'Hydroponische Systeme führen Nährlösung gezielt an die Wurzeln; Aeroponik hält sie noch stärker frei und besprüht sie. Dadurch werden pH-Wert, Nährstoffkonzentration und Sauerstoffversorgung wichtiger als bei normaler Blumenerde. Indoor-Growing braucht zusätzlich ausreichend Licht und Luftbewegung, während Microgreens wegen ihrer kurzen Kulturzeit besonders einfach starten können. Pumpen und Leitungen sollten leicht zu reinigen sein, denn stehende Nährlösung kann schnell Probleme verursachen. Hydrokultur, Semi-Hydro, Hydroponik und Aeroponik unterscheiden sich vor allem darin, wie Wurzeln mit Wasser, Nährstoffen und Sauerstoff versorgt werden. Klassische Hydrokultur arbeitet häufig mit anorganischem Substrat und Wasserreservoir, Semi-Hydro nutzt verwandte Prinzipien in vereinfachter Form.

Bei dauerhaft beleuchteten Indoor-Systemen lohnt sich außerdem der Blick auf Stromverbrauch und Wärmeentwicklung, damit Ertrag und technischer Aufwand in einem sinnvollen Verhältnis bleiben. Ein kleines System lässt sich leichter stabil halten und zeigt dir Zusammenhänge zwischen Wasserstand, Nährlösung und Wurzelgesundheit. Messe nur Werte, die du auch beurteilen kannst, und ändere nicht mehrere Faktoren gleichzeitig. Lichtzeiten und Pumpen sollten zuverlässig geschaltet sein. Wenn Pflanzen plötzlich schwächeln, prüfst du zuerst Wurzeln, Wasser und Temperatur, bevor du wahllos zusätzliche Nährstoffe zugibst.'],
            'pilze-kulturen' => ['hero'=>'Myzel verstehen und Speisepilze kontrolliert kultivieren.', 'lead'=>'Pilze & Kulturen bedeutet, Pilzwachstum nicht nur zu beobachten, sondern gezielt zu steuern. Du arbeitest mit Myzel, geeigneten Substraten und kontrollierten Bedingungen und kannst Speisepilze oder andere Kulturen über mehrere Entwicklungsphasen begleiten. Wer biologische Prozesse spannend findet und sorgfältig arbeitet, bekommt hier schnelle Einblicke. Sauberkeit, Temperatur, Feuchtigkeit und geeignetes Ausgangsmaterial sind entscheidend.', 'more'=>'Austernseitlinge sind beispielsweise deutlich unkomplizierter als viele anspruchsvollere Arten. Fertige Blöcke zeigen den Fruchtungsprozess ohne aufwendige Vorbereitung; eigene Substrate verlangen mehr Kontrolle über Feuchte und Verunreinigungen. Sauberkeit ist wichtig, weil Schimmel und andere Mikroorganismen schneller wachsen können als das gewünschte Myzel. Frischluft und Luftfeuchte beeinflussen Form und Wachstum der Fruchtkörper. Für den Einstieg sind bekannte Speisepilzkulturen sinnvoll; unbekannte Wildpilze sollten nicht einfach auf gut Glück vermehrt oder gegessen werden. Fertige Fruchtungsblöcke, Körnerbrut und selbst angesetzte Substrate verlangen unterschiedlich viel Kontrolle; mit jedem Schritt steigen auch Anforderungen an Sauberkeit und Prozessführung. Pilze beziehen ihre Energie aus organischem Material und brauchen deshalb ein Substrat, das zur jeweiligen Art passt.

Verbrauchtes Substrat und kontaminierte Ansätze sollten außerdem getrennt behandelt werden, damit sich unerwünschte Organismen nicht auf neue Kulturen übertragen. Kulturen verändern sich sichtbar: gesundes Myzel, ungewöhnliche Farben, Gerüche oder verlangsamtes Wachstum geben Hinweise auf den Zustand. Behälter und Chargen sollten deshalb beschriftet sein. Wer mehrere Arten parallel kultiviert, trennt Arbeitsmaterial möglichst sauber. So lässt sich nachvollziehen, welche Bedingungen funktionieren, und ein kontaminierter Ansatz gefährdet nicht automatisch alle anderen laufenden Kulturen.'],
            'saatgut-zucht' => ['hero'=>'Sorten erhalten, auswählen und gezielt weiterentwickeln.', 'lead'=>'Saatgut & Zucht richtet sich an Pflanzenfreunde, die Sorten nicht nur anbauen, sondern erhalten, auswählen oder über Generationen weiterentwickeln möchten. Du gewinnst Saatgut, beobachtest Merkmale, wählst Pflanzen aus und kannst gezielte Kreuzungen verfolgen. Der Reiz liegt in sichtbarer Veränderung über Zeit. Dafür brauchst du vor allem gesunde Pflanzen, Dokumentation, Geduld und saubere Trennung der Linien.', 'more'=>'Wer Saatgut sortenrein erhalten möchte, muss deshalb wissen, wie eine Pflanzenart bestäubt wird und welche Abstände oder Isolierungen nötig sind. Bei gezielten Kreuzungen ist genau dieser Austausch erwünscht: Elternpflanzen werden ausgewählt, Blüten kontrolliert bestäubt und Nachkommen später nach gewünschten Merkmalen beurteilt. Riesenkürbis-Zucht legt andere Schwerpunkte als Chili- oder Tomatenauswahl, doch überall braucht es saubere Beschriftung und Aufzeichnungen. Saatgut muss vollständig reif geerntet, richtig getrocknet und trocken gelagert werden. Saatguterhaltung bewahrt vorhandene Eigenschaften, gezielte Zucht verändert sie bewusst; beide Wege brauchen mehrere Generationen, eindeutige Beschriftung und konsequente Dokumentation. Bei samenfesten Sorten ist kontrollierte Bestäubung wichtig, weil Einkreuzungen die gewünschten Eigenschaften verändern können.

Gerade bei mehreren Linien verhindert eine eindeutige Kennzeichnung von Pflanze, Kreuzung und Erntejahr, dass die eigene Zucht nach einer Saison nicht mehr nachvollziehbar ist. Bei Zuchtprojekten lohnt sich eine klare Zielsetzung pro Saison, etwa Geschmack, Farbe, Reifezeit oder Wuchsform. Wenn du zu viele Merkmale gleichzeitig auswählst, wird die Beurteilung schnell unübersichtlich. Fotos und kurze Notizen zu jeder Linie helfen, Entscheidungen später nachzuvollziehen. Überschüssiges Saatgut bleibt trocken, kühl und eindeutig beschriftet, damit Herkunft und Jahr erhalten bleiben.'],
            'moos-miniaturgaerten' => ['hero'=>'Kleine Pflanzenszenen mit Moos und feinen Formen.', 'lead'=>'Moos & Miniaturgärten verbindet lebende Pflanzen mit Gestaltung im kleinen Maßstab. Du baust Terrarien, Mooslandschaften oder kleine Pflanzenszenen auf Steinen, Holz und Substraten und hältst ihr Mikroklima stabil. Das eignet sich besonders für Menschen, die ruhige Detailarbeit und grüne Miniaturwelten mögen. Gefäß, geeignetes Pflanzenmaterial, Licht und kontrollierte Feuchtigkeit reichen für viele erste Projekte.', 'more'=>'Kokedama umhüllt Wurzeln mit einer Substratkugel, die meist mit Moos bedeckt wird. Wabikusa arbeitet häufig mit feuchtigkeitsliebenden Pflanzen in kleinen, teils offenen Landschaften. Reine Mooskultur verlangt Arten, die zum vorhandenen Licht und zur Feuchtigkeit passen; nicht jedes draußen gefundene Moos hält sich dauerhaft im Wohnraum. Geschlossene Gefäße können Feuchtigkeit stabilisieren, erhöhen aber bei schlechter Belüftung das Risiko für Schimmel. Für Einsteiger sind offene, gut beobachtbare Arrangements leichter zu steuern. Kusamono, Kokedama, Mooskultur und Wabikusa unterscheiden sich in Aufbau und Bewässerung; Substrat, Luftfeuchte und Licht müssen zum jeweiligen kleinen Pflanzensystem passen. Kusamono setzt einzelne oder kombinierte Begleitpflanzen in bewusst gestaltete Schalen und stammt aus dem Umfeld der Bonsai-Kultur.

Steine und Holz sollten zudem nicht nur optisch passen, sondern so eingesetzt werden, dass Wasser ablaufen kann und empfindliche Pflanzen nicht dauerhaft vernässen. Mooslandschaften wirken nur dann dauerhaft ruhig, wenn Feuchtigkeit und Luftbewegung zusammenpassen. Ein geschlossener Behälter braucht andere Pflege als eine offene Schale. Steine, Holz und Pflanzen sollten vor dem Setzen hinsichtlich Größe und Richtung ausprobiert werden. So entsteht eine überzeugende kleine Landschaft, ohne dass ständig nachdekoriert werden muss oder empfindliche Moose unter ungeeigneten Begleitpflanzen verschwinden.'],
            'essbare-pflanzen' => ['hero'=>'Essbares auf kleinem oder großem Raum selbst anbauen.', 'lead'=>'Essbare Pflanzen selbst anzubauen reicht vom Kräutertopf bis zu Gemüse, Beeren und Obst auf Balkon, Terrasse oder im Garten. Du säst, pflanzt, pflegst und erntest und lernst dabei Standort, Wasser, Nährstoffe und Jahreszeiten kennen. Das ist besonders befriedigend, wenn du Lebensmittel gern vom Wachstum bis auf den Teller begleitest. Schon wenige Gefäße und ein sonniger Platz können reichen.', 'more'=>'Kübel trocknen schneller aus als Gartenboden und brauchen ausreichend Abfluss. Mehrjährige Kräuter haben andere Ansprüche als stark zehrendes Gemüse. Obst im Kübel funktioniert mit geeigneten Sorten und ausreichend großen Gefäßen, verlangt aber oft Geduld und regelmäßigen Schnitt. Aussaatzeit, Pflanzabstand und Erntefenster helfen, vorhandenen Platz sinnvoll zu nutzen. Pflanzenschutz beginnt mit gesundem Standort und regelmäßiger Kontrolle, nicht mit vorschnellen Mitteln. Balkon, Terrasse und Beet erlauben unterschiedliche Kulturen; Licht, Gefäßgröße, Wasser und tatsächlicher Platz bestimmen stärker über den Erfolg als eine möglichst große Sortenauswahl.

Mischkultur und Fruchtfolge können bei größeren Projekten zusätzlich helfen, Platz und Boden besser zu nutzen, ohne jede Saison dieselben Pflanzen an dieselbe Stelle zu setzen. Plane Anbauflächen nach Licht, Platz und tatsächlichem Verbrauch. Drei gut gepflegte Kräuter oder Gemüsesorten bringen oft mehr als ein überfülltes Beet. Bei Kübeln bestimmen Volumen und Wasserspeicher stark den Pflegeaufwand. Wiederholte Aussaaten verlängern die Ernte, während Fruchtfolge und Mischkultur im größeren Garten helfen können, Boden und Pflanzen über die Saison ausgewogener zu nutzen.'],
            'gaertnern' => ['hero'=>'Garten planen, Boden verstehen und Pflanzen passend pflegen.', 'lead'=>'Gärtnern bedeutet, einen Außenraum so zu planen und zu pflegen, dass Pflanzen, Boden und Nutzung zusammenpassen. Du säst, pflanzt, schneidest, verbesserst den Boden und beobachtest, wie sich dein Garten über die Jahreszeiten entwickelt. Wer gern draußen arbeitet und langfristige Veränderungen beobachtet, bekommt hier besonders viel zurück. Gute Standortkenntnis und einfache Werkzeuge sind wichtiger als viel Ausstattung.', 'more'=>'Kompost und organische Substanz verbessern viele Böden, ersetzen aber keine genaue Betrachtung von Struktur und Nährstoffbedarf. Pflanzzeiten unterscheiden sich je nach Art und Region. Bewässerung sollte tief genug wirken, statt Oberflächen ständig nur anzufeuchten. Mulch kann Wasser sparen und Bodenleben unterstützen, muss aber passend eingesetzt werden. Im Saisonverlauf kommen Schnitt, Pflege und Vorbereitung auf Hitze oder Frost hinzu. Werkzeuge müssen vor allem zur Gartengröße und Arbeit passen.

Boden, Licht, Wasser und vorhandene Strukturen geben vor, welche Maßnahmen sinnvoll sind; zusätzliche Produkte ersetzen weder Standortkenntnis noch eine schlüssige Gartenplanung. Ein Garten entwickelt sich über Jahre, deshalb lohnt sich Beobachtung vor Aktion. Notiere sonnige und schattige Bereiche, Staunässe, trockene Stellen und den Zustand vorhandener Pflanzen. Daraus entsteht ein Plan, der zum Grundstück passt. Mulch, Kompost und passende Pflanzabstände können Pflege reduzieren. Nicht jede freie Fläche muss sofort bepflanzt werden; Struktur, Wege und nutzbare Arbeitsflächen sind ebenso Teil eines funktionierenden, dauerhaft gut pflegbaren Gartens.'],
            'aquaristik' => ['hero'=>'Ein stabiles Wasserbiotop statt nur ein schönes Becken.', 'lead'=>'Aquaristik ist das Hobby, in einem begrenzten Wasservolumen einen stabilen Lebensraum für Fische, Garnelen, Pflanzen oder andere Wasserbewohner aufzubauen. Du gestaltest, filterst, fütterst und kontrollierst Wasserwerte und beobachtest dabei ein kleines Ökosystem. Das eignet sich für ruhige, genaue Beobachter. Becken, passende Technik und Geduld beim Einfahren sind wichtiger als schneller Besatz.', 'more'=>'Nano-Aquarien reagieren wegen ihres kleinen Volumens schneller auf Fehler, obwohl sie einfach wirken. Garnelen benötigen je nach Art passende Härte und Temperatur. Biotop- und Schwarzwasseraquarien orientieren sich stärker an natürlichen Lebensräumen und nutzen gezielt Holz, Laub oder gedämpftes Licht. Meerwasser- und Riffaquaristik erhöhen Aufwand und Messtechnik deutlich; Salzgehalt, Strömung und Beleuchtung müssen stabil sein. Quallenbecken brauchen eine besondere Wasserführung, damit die Tiere nicht verletzt werden. Beckenart, Technik und Besatz müssen als gemeinsames System geplant werden; ein langsamer Start und regelmäßige Beobachtung stabilisieren das Aquarium besser als schnelle Nachbesetzung. Im Süßwasser gehören passende Beckengröße, Wasserwerte und ein eingefahrener Stickstoffkreislauf zu den Grundlagen eines stabilen Betriebs.

Vor dem Besatz lohnt sich außerdem eine Prüfung der späteren Endgröße und Sozialstruktur, denn viele Probleme entstehen durch Tiere, die für das vorhandene Becken ungeeignet sind. Ein neues Becken braucht Zeit, bevor es biologisch stabil ist. Besatz, Fütterung und Filterleistung sollten deshalb schrittweise entwickelt werden. Regelmäßige Beobachtung von Tieren und Wasser ist hilfreicher als hektisches Nachregeln einzelner Werte. Wenn du Pflanzen, Hardscape und Tiere nach ihren gemeinsamen Ansprüchen auswählst, entsteht ein System, das langfristig leichter zu pflegen ist und natürlicher wirkt.'],
            'terraristik' => ['hero'=>'Lebensräume für Reptilien und andere Terrarientiere richtig planen.', 'lead'=>'Terraristik bedeutet, für Reptilien, Amphibien, Spinnen, Skorpione oder andere Terrarientiere einen passenden Lebensraum nachzubilden. Du planst Temperatur, Feuchtigkeit, Licht, Einrichtung und Rückzugsorte nach den Bedürfnissen der jeweiligen Art. Das ist faszinierend für Menschen, die Tierverhalten genau beobachten möchten. Gute Vorbereitung, sichere Technik und artgerechte Haltung stehen immer vor der Optik.', 'more'=>'Vogelspinnen benötigen meist weniger Technik, reagieren aber empfindlich auf ungeeignete Feuchtigkeit oder Absturzhöhen. Skorpione verlangen zusätzlich besonders sichere, ausbruchsfeste Behälter und vorsichtigen Umgang. Bodengrund, Verstecke und Struktur sollten zum natürlichen Verhalten passen. Thermometer und Hygrometer helfen, Bedingungen zu kontrollieren, ersetzen aber keine Kenntnis der Art. Futtertiere, Häutung und saisonale Veränderungen müssen ebenfalls berücksichtigt werden. Viele Tiere werden alt und brauchen dauerhaft Platz und Versorgung. Herkunft, Endgröße, Klima und Verhalten des Tieres bestimmen Gehege, Technik und Einrichtung und sollten vor jeder Anschaffung vollständig geklärt sein. Bei vielen Reptilien sind Temperaturzonen, UV-Versorgung und passende Beleuchtung zentrale Teile der Haltungsplanung.

Bei exotischen Arten solltest du zusätzlich prüfen, welche gesetzlichen Vorgaben, Nachweise oder Haltungsbeschränkungen an deinem Wohnort gelten können. Vor der Einrichtung solltest du die spätere Endgröße und Lebensweise der Tiere kennen. Kletternde, grabende oder nachtaktive Arten brauchen völlig unterschiedliche Strukturen. Messfühler gehören dorthin, wo sich das Tier tatsächlich aufhält. Rückzugsmöglichkeiten und Temperaturzonen geben ihm Wahlmöglichkeiten. Technik wird so geplant, dass Ausfälle erkennbar bleiben und Wartung möglich ist, ohne das ganze Terrarium auseinandernehmen zu müssen.'],
            'imkerei-bestaeuber' => ['hero'=>'Bestäuber fördern – vom Bienenvolk bis zum Garten.', 'lead'=>'Imkerei & Bestäuber reicht von der verantwortungsvollen Haltung eines Honigbienenvolks bis zur Gestaltung von Lebensräumen für Wildbienen, Hummeln und Schmetterlinge. Du beobachtest, pflegst, baust oder verbesserst Nist- und Futterangebote. Wer Insekten und ökologische Zusammenhänge spannend findet, kann hier praktisch viel bewirken. Aufwand und Ausrüstung unterscheiden sich je nach Projekt allerdings enorm.', 'more'=>'Schutzkleidung und geeignete Beuten gehören zur Ausstattung, wichtiger ist aber regelmäßige Betreuung. Wildbienenhotels funktionieren nur mit passenden Röhrendurchmessern, glatten Niströhren und einem geeigneten Standort; dekorative Füllmaterialien ohne Nutzen können entfallen. Hummelkästen stellen andere Ansprüche an Belüftung und Schutz. Schmetterlingsgärten helfen vor allem durch heimische Nektar- und Raupenfutterpflanzen sowie pestizidarme Pflege. Honigbienenhaltung und Förderung wildlebender Bestäuber sind unterschiedliche Aufgaben: Die eine verlangt dauerhafte Tierbetreuung, die andere vor allem geeignete Nahrung und Nistmöglichkeiten. Bei der Honigbienenhaltung gehören außerdem Volksentwicklung, Schwarmzeit, Krankheiten sowie geltende Melde- und Tierseuchenregeln zum nötigen Wissen.

Auch Wasserstellen, Blühzeiten und ein möglichst langes Nahrungsangebot im Jahresverlauf können für Bestäuber mehr bewirken als ein einzelnes dekoratives Nisthaus. Für heimische Wildbienen sind offene Bodenstellen und geeignete natürliche Nistplätze je nach Art ebenfalls wichtig. Ob Bienenvolk oder Wildbienenhilfe: Entscheidend ist das Umfeld. Blütenangebot über die Saison, Wasser, geeignete Nistplätze und möglichst wenig Pestizidbelastung wirken zusammen. Ein Insektenhotel ohne passende Nahrung bleibt wenig hilfreich. Wer Honigbienen hält, übernimmt zusätzlich Verantwortung für Gesundheit und Schwarmkontrolle. Für viele Gärten kann gezielte Lebensraumverbesserung der sinnvollere Einstieg sein als sofort ein eigenes Volk.'],
            'zucht-futtertiere' => ['hero'=>'Kleine Tierkulturen zuverlässig und hygienisch halten.', 'lead'=>'Zucht & Futtertiere umfasst kleine Tierkulturen wie Artemia, Daphnien, Triops oder Regenwürmer, die du beobachten oder als Futterquelle stabil halten kannst. Du steuerst Wasser, Futter, Temperatur und Hygiene und begleitest Vermehrung und Entwicklung. Das eignet sich für sorgfältige Tierhalter, die kleine Kreisläufe spannend finden. Meist reichen einfache Behälter und konsequente Pflege.', 'more'=>'Daphnien leben im Süßwasser und reagieren empfindlich auf schlechte Wasserqualität oder Überfütterung. Triops haben einen kurzen, besonderen Lebenszyklus und benötigen passende Temperatur sowie genügend Platz während des Wachstums. Regenwurmzucht funktioniert in feuchtem, aber gut belüftetem organischem Material und kann zugleich Küchenabfälle verwerten. Andere Futtertiere verlangen artgerechte Behälter und regelmäßige Erneuerung der Kulturen, damit sich Milben, Schimmel oder Gerüche nicht ausbreiten. Trockene und aquatische Kulturen brauchen unterschiedliche Behälter, Futter und Pflege; getrennte Reserveansätze schützen vor vollständigem Ausfall einer wichtigen Futtertierpopulation. Artemia werden häufig aus Dauereiern angesetzt und brauchen passendes Salzwasser sowie ausreichende Belüftung.

Futtertierkulturen sollten außerdem so geführt werden, dass Nährwert und Hygiene stimmen; eine große Menge schlecht versorgter Tiere ist kein hochwertiges Futter. Kleine Kulturen funktionieren am zuverlässigsten, wenn du Bestand, Futter und Feuchtigkeit regelmäßig beobachtest und nicht erst bei einem Zusammenbruch reagierst. Mehrere getrennte Ansätze können bei wichtigen Futtertieren sinnvoll sein. Behälter sollten leicht zu reinigen und eindeutig beschriftet sein. So erkennst du früh, ob Populationen kippen, Milben auftreten oder sich Futterreste stärker zersetzen als geplant.'],
            'ameisen-insekten' => ['hero'=>'Insekten beobachten und ihre Lebensweisen wirklich verstehen.', 'lead'=>'Ameisen & Insekten eröffnet Einblicke in Lebensweisen, die im Alltag oft verborgen bleiben. Du hältst oder beobachtest Ameisen, Stabschrecken, Gottesanbeterinnen, Käfer oder Schmetterlinge und begleitest Verhalten und Entwicklung. Das ist besonders reizvoll für geduldige Beobachter. Je nach Art brauchst du sichere Behälter, passendes Klima, geeignetes Futter und eine verlässliche Herkunft der Tiere.', 'more'=>'Stabschrecken leben von passenden Futterpflanzen und benötigen genug Höhe für problemlose Häutungen. Gottesanbeterinnen sind räuberisch und werden häufig einzeln gehalten. Käferzucht kann lange Larvenphasen im Substrat umfassen, während Schmetterlingszucht eng an geeignete Raupenfutterpflanzen gebunden ist. Temperatur und Luftfeuchte müssen kontrolliert werden, dürfen aber nicht durch schlechte Belüftung zu Schimmel führen. Einsteiger sollten robuste, legal verfügbare Arten wählen und sich vorab über Endgröße und Lebenszyklus informieren. Ameisen, Stabschrecken, Gottesanbeterinnen, Käfer und Schmetterlinge unterscheiden sich stark bei Futter, Entwicklung, Platz und Klima und brauchen entsprechend unterschiedliche Haltungssysteme.

Bei Arten mit besonderem Schutzstatus oder möglichem invasivem Risiko ist außerdem die rechtliche Herkunft und sichere Haltung vor jeder Anschaffung zu klären. Insektenhaltung wird interessanter, wenn du Verhalten wirklich beobachten kannst. Nestaufbau, Nahrungssuche, Häutung oder Brutpflege sind oft spannender als reine Größe oder Seltenheit. Die Anlage sollte deshalb Einblick ermöglichen, ohne ständig geöffnet zu werden. Ausbruchsschutz und artspezifische Temperatur- und Feuchtebereiche gehören von Anfang an dazu. Wildfänge und Herkunft sollten außerdem verantwortungsvoll und rechtlich sauber geklärt sein.'],
            'wirbellose' => ['hero'=>'Kleine Tiere mit erstaunlich vielfältigen Ansprüchen.', 'lead'=>'Wirbellose wie Asseln, Isopoden und Schnecken sind kleine Beobachtungstiere mit überraschend unterschiedlichen Ansprüchen. Du richtest kompakte Lebensräume ein, hältst Feuchtigkeit, Futter und Mineralversorgung stabil und kannst Verhalten oder Vermehrung verfolgen. Das passt gut zu Menschen mit wenig Platz und Freude an Details. Ein geeigneter Behälter, Substrat und ein stabiles Mikroklima sind die Grundlage.', 'more'=>'Laub, morsches Holz und geeignete Mineralquellen bilden bei vielen Arten einen wichtigen Teil der Ernährung. Isopoden-Zucht kann von robusten Einsteigerarten bis zu empfindlicheren Formen reichen, bei denen Temperatur und Feuchte enger passen müssen. Schnecken haben je nach Art ganz andere Ansprüche an Platz, Substrat und Kalk und können bei falscher Haltung schnell Gehäuseschäden entwickeln. Belüftung muss Feuchtigkeit erhalten, ohne Staunässe und Schimmel zu fördern. Asseln, Isopoden und Schnecken stellen je nach Art andere Ansprüche an Feuchte, Kalk und Futter; die genaue Bestimmung gehört deshalb vor die Einrichtung des Behälters. Viele Asseln brauchen einen Feuchtigkeitsgradienten, bei dem ein Bereich deutlich feuchter bleibt als andere Zonen.

Überschüssige Tiere dürfen zudem nicht einfach ausgesetzt werden; auch kleine Wirbellose können außerhalb ihres ursprünglichen Lebensraums ökologische Probleme verursachen. Bei Asseln, Isopoden und Schnecken bestimmen Bodengrund, Feuchtigkeit, Kalkversorgung und Verstecke viel stärker über den Erfolg als dekorative Technik. Ein Feuchtegradient erlaubt den Tieren, selbst passende Bereiche zu wählen. Futterreste werden sparsam gegeben und rechtzeitig entfernt. Wer Populationen dokumentiert, erkennt Veränderungen früh und kann Tiere trennen, bevor eine Box überbesetzt wird oder eine Art eine andere verdrängt.'],
            'gehegegestaltung' => ['hero'=>'Lebensräume bauen, die technisch und biologisch funktionieren.', 'lead'=>'Gehegegestaltung ist die Verbindung aus Tierhaltung, Bau und Klima. Du planst und baust Terrarien, Formicarien, Paludarien oder bioaktive Lebensräume so, dass Tiere sich artgerecht verhalten können und Technik, Reinigung und Kontrolle funktionieren. Das ist ideal für Tierhalter, die gern praktisch gestalten. Materialwahl, Belüftung, Beleuchtung und sichere Konstruktion richten sich immer nach der späteren Art.', 'more'=>'Bioaktive Systeme ergänzen lebende Pflanzen, Bodenschichten und kleine Zersetzer, wodurch ein funktionierender Boden entstehen kann – ganz wartungsfrei werden sie trotzdem nicht. Formicarien brauchen passende Nestbereiche, Feuchtezonen und zuverlässigen Ausbruchsschutz. Paludarien kombinieren Wasser- und Landteil und erhöhen damit die Anforderungen an Abdichtung, Filterung und Luftfeuchte. Kabel, Heizungen und Pumpen sollten zugänglich bleiben, ohne dass Tiere sie erreichen können. Vor dem Bau lohnt ein Plan mit Technik, Wartungswegen und späterer Endgröße. Bioaktive Terrarien, Formicarien, Paludarien und klassische Terrarien brauchen jeweils andere Lösungen für Belüftung, Wasserführung, Material und Wartungszugang.

Bei schweren Steinen, Wasserteilen oder hohen Aufbauten sollte außerdem die Tragfähigkeit des Beckens und ein sicherer Stand vor der Dekoration geprüft werden. Ein gutes Gehege verbindet Gestaltung mit Wartbarkeit. Wasserstellen, Drainage, Beleuchtung und Verstecke müssen erreichbar bleiben, ohne ständig die ganze Einrichtung zu zerstören. Pflanzen und Baumaterialien sollten für die geplanten Bewohner geeignet sein. Bevor Tiere einziehen, lohnt ein Testbetrieb: Temperatur, Feuchtigkeit, Wasserlauf und Technik lassen sich dann einige Tage beobachten und korrigieren, ohne dass bereits ein Tier davon abhängig ist.'],
            'outdoor' => ['hero'=>'Draußen unterwegs – mit Ausrüstung, die zum Vorhaben passt.', 'lead'=>'Outdoor-Hobbys bringen dich bewusst nach draußen – für eine kurze Tour, ein Wochenende oder mehrere Tage unterwegs. Du wanderst, campst, angelst, fährst Bikepacking oder kombinierst Land und Wasser beim Packrafting. Wer Bewegung, Natur und ein Stück Selbstständigkeit sucht, findet hier viele passende Möglichkeiten. Strecke, Wetter und Übernachtung bestimmen, welche Ausrüstung wirklich nötig ist.', 'more'=>'Bikepacking reduziert Gepäck und verteilt es direkt am Rad. Packrafting kombiniert Wandern mit einem leichten Boot und verlangt zusätzlich sichere Einschätzung von Gewässern. Beim Camping unterscheiden sich Zelt, Tarp und Hängematte deutlich bei Wetterschutz und Standortwahl; Wintercamping erhöht die Anforderungen an Schlafsystem und Kälteschutz. Bushcraft legt stärker Wert auf praktische Fertigkeiten, darf aber nicht mit beliebigem Feuer- oder Holzmachen verwechselt werden. Geocaching und Orientierungslauf bringen Navigation ins Spiel, Mikroabenteuer halten Planung bewusst klein. Bushcraft, Bikepacking, Packrafting, Camping und Mikroabenteuer unterscheiden sich in Ausrüstung und Reichweite; Wetter, Tourlänge und Erfahrung bestimmen, was du tatsächlich mitnehmen solltest. Beim Wandern und Radfahren sind passende Kleidung, Navigation und eine realistische Tourenplanung wichtiger als möglichst viel Zubehör.

Eine kleine Notfallreserve, geladene Kommunikation und eine Person, die deine Route kennt, sind bei abgelegenen Touren oft sinnvoller als ein weiteres Komfort-Gadget. Draußen entscheidet Planung häufig über Komfort und Sicherheit. Wetterbericht, Tageslicht, Wasser und Rückweg gehören deshalb genauso zur Vorbereitung wie Schlafsystem oder Rucksack. Teste neue Ausrüstung zunächst auf kurzen Touren. So merkst du, wo Druckstellen entstehen, was tatsächlich trocken bleibt und welche Gegenstände nur Gewicht verursachen. Mit Erfahrung wird die Ausrüstung meist einfacher statt umfangreicher.'],
            'rollen-balance' => ['hero'=>'Gleichgewicht trainieren und Bewegung kontrollieren.', 'lead'=>'Rollen & Balance versammelt Hobbys, bei denen du deinen Schwerpunkt aktiv kontrollierst und Bewegungen immer feiner ausgleichst. Dazu gehören Einrad, Slackline, Longboard und Balance Board. Wer körperliche Geschicklichkeit gern spielerisch trainiert, spürt hier schnell Fortschritte. Für den Einstieg brauchst du meist wenig Ausrüstung, aber einen sicheren Platz, an dem Fehler erlaubt sind.', 'more'=>'Mountain Unicycling bringt später Gelände, Bremsen und deutlich höhere Anforderungen hinzu. Slacklining beginnt bodennah mit kurzer Line; Highlining ist eine eigene, sicherheitskritische Disziplin und gehört in erfahrene Hände mit geeigneten Sicherungssystemen. Longboard Dancing arbeitet mit Schritten und Gewichtsverlagerung auf dem fahrenden Board, während Pumptrack und Mountainboarding stärker Geschwindigkeit und Untergrund einbeziehen. Ein Balance Board eignet sich gut für Grundlagen, ersetzt aber keine spezifische Fahrpraxis. Schutz, Umgebung und Schwierigkeit sollten zu deinem aktuellen Können passen; Fortschritt entsteht zuverlässiger durch kontrollierte Wiederholungen als durch zu frühe Sprünge in anspruchsvolle Tricks.

Bei bewegten Sportarten lohnt sich außerdem, Rollen, Achsen, Leinen oder Befestigungen regelmäßig zu prüfen, weil kleine Materialfehler unter Belastung schnell relevant werden. Fortschritt entsteht hier durch saubere Wiederholung und passende Schwierigkeit. Eine ebene, freie Fläche und Schutz vor unnötigen Stürzen sind für erste Bewegungen wertvoller als spektakuläre Tricks. Filme kurze Versuche, wenn du Haltung und Bewegungsablauf prüfen willst. Kleine Korrekturen an Blickrichtung, Körperspannung oder Fußposition verändern oft mehr als zusätzliche Kraft und machen neue Varianten später leichter lernbar.'],
            'wurf-ziel' => ['hero'=>'Technik wiederholen, Flugbahnen lesen und genauer treffen.', 'lead'=>'Wurf & Ziel umfasst Hobbys wie Bogenschießen, Discgolf, Boomerang oder Blasrohrsport, bei denen wiederholbare Bewegungen und präzises Treffen im Mittelpunkt stehen. Du trainierst Haltung, Ablauf und Flugbahn und bekommst direktes Feedback auf jeden Versuch. Konzentration und saubere Technik werden hier unmittelbar mit jedem Versuch sichtbar. Passende Ausrüstung und ein sicherer Zielbereich sind unverzichtbar.', 'more'=>'Discgolf arbeitet mit unterschiedlichen Scheiben für Distanz, Annäherung und Putts und lässt sich auf öffentlichen Anlagen vergleichsweise leicht beginnen. Boomerangs brauchen freie Flächen und passende Windbedingungen; nicht jedes Modell kehrt gleich zurück. Beim Blasrohrsport sind sichere Zielwände und klare Schussbereiche entscheidend. Für den Einstieg ist es sinnvoll, zuerst Bewegungsablauf und Trefferbild zu stabilisieren, statt sofort auf maximale Distanz zu gehen. Hier kannst du Sportarten, Ausrüstung und typische Lernschritte vergleichen und erkennst, welche Fläche und Sicherheitsabstände du jeweils wirklich brauchst. Beim Bogenschießen müssen Zuggewicht, Auszugslänge und Bogenart zur schießenden Person und ihrer Technik passen.

Pfeile, Scheiben, Boomerangs und andere Wurfgeräte sollten zudem regelmäßig auf Schäden kontrolliert werden, weil beschädigtes Material seine Flugbahn unvorhersehbar verändern kann. Konstanz ist wichtiger als einzelne Glückstreffer. Markiere Entfernungen und wiederhole wenige, klar definierte Bewegungen, bevor du Material oder Technik wechselst. Wind und Untergrund verändern je nach Disziplin das Ergebnis. Bei Bögen, Wurfgeräten oder Blasrohren gehört ein eindeutig gesicherter Zielbereich immer zur Übung. So kannst du Technik vergleichen, ohne dass Sicherheit vom jeweiligen Treffer abhängt.'],
            'wasser' => ['hero'=>'Auf und im Wasser sicherer und ausdauernder unterwegs sein.', 'lead'=>'Wasserhobbys reichen vom Schwimmen über Stand-up-Paddling und Kanutouren bis zum Freediving. Du bewegst dich im oder auf dem Wasser, verbesserst Technik und Ausdauer und lernst Bedingungen wie Strömung, Wind und Temperatur einzuschätzen. Wer Wasser liebt und Bewegung sucht, findet sehr unterschiedliche Intensitäten. Sicherheitsausrüstung und Können müssen immer zum Gewässer und zur Disziplin passen.', 'more'=>'SUP und Kanu bringen Wind, Strömung, Wassertemperatur und die richtige Schwimmhilfe ins Spiel; Touren sollten an Erfahrung und Rückweg angepasst werden. Freediving ist keine Disziplin für Alleintraining: Atemanhalteübungen im Wasser gehören immer mit geschulter Sicherung und klaren Abläufen zusammen. Hyperventilation vor dem Tauchen ist gefährlich und keine sinnvolle Abkürzung. Auch scheinbar ruhiges Wasser kann durch Kälte oder Wetterwechsel anspruchsvoll werden. Freediving, SUP, Kanutouren und Schwimmen stellen unterschiedliche Anforderungen an Technik, Ausdauer und Sicherheitsausrüstung; auch das Gewässer selbst entscheidet über die passende Vorbereitung.

Fortschritt bedeutet hier nicht nur mehr Strecke oder Tiefe, sondern vor allem bessere Technik und verlässliche Sicherheitsroutinen. Für Touren auf offenem Wasser gehören außerdem lokale Regeln, Ein- und Ausstiegsmöglichkeiten und eine realistische Einschätzung von Wind und Strömung zur Planung. Auf dem Wasser verändern Wind, Strömung und Temperatur die Anforderungen schnell. Plane deshalb nicht nur Strecke und Tempo, sondern auch Ein- und Ausstieg, Kleidung und mögliche Abbruchpunkte. Schwimmfähigkeit ersetzt keine passende Sicherheitsausrüstung. Wer Touren langsam verlängert und Bedingungen dokumentiert, entwickelt ein realistisches Gefühl für die eigene Reichweite und kann neue Gewässer besser einschätzen.'],
            'klettern-seil' => ['hero'=>'Klettern lernen und Sicherung wirklich beherrschen.', 'lead'=>'Klettern & Seil verbindet Bewegung, Technik und Vertrauen in Sicherungssysteme. Du boulderst in Absprunghöhe, kletterst mit Seil oder bewegst dich beim Baumklettern in ganz anderen Strukturen. Körperliche Herausforderung und Tüfteln greifen hier besonders eng ineinander. Für den Einstieg sind kontrollierte Bedingungen, passende Ausrüstung und sauber gelernte Sicherungsabläufe entscheidend.', 'more'=>'Bouldern braucht kein Seil, dafür kontrollierte Landungen, passende Matten und vernünftiges Risikomanagement. Draußen verändern Fels, Wetter und Routenkenntnis die Anforderungen. Baumklettern ist kein bloßes Hochklettern am Stamm: Seilsysteme, geeignete Ankerpunkte und der Schutz des Baums gehören dazu. Für Einsteiger sind Kurse und betreute Praxis sinnvoller als Materialkauf auf Verdacht. Bouldern, Sportklettern und Baumklettern nutzen verschiedene Sicherungs- und Bewegungstechniken; Schwierigkeit und Eigenständigkeit sollten erst mit zuverlässig beherrschten Grundlagen steigen.

Material mit Sicherheitsfunktion sollte außerdem nach Herstellervorgaben geprüft, gelagert und rechtzeitig ersetzt werden; improvisierte Reparaturen sind dort fehl am Platz. Auch Helmgebrauch, Partnerkommunikation und ein klarer Abbruch bei unsicheren Bedingungen gehören zur normalen Routine. Technik lässt sich am besten in kontrollierten Situationen lernen, bevor Höhe oder Schwierigkeit steigen. Knoten, Partnercheck und Materialzustand werden dabei zur festen Routine. Beim Bouldern verschiebt sich der Schwerpunkt stärker auf Bewegung und sinnvolles Abspringen. Für Seilklettern und Baumklettern ist qualifizierte Anleitung besonders wertvoll, weil Sicherungsfehler nicht durch Kraft oder Talent ausgeglichen werden können.'],
            'wind-drachen' => ['hero'=>'Wind lesen und Zugkräfte kontrollieren.', 'lead'=>'Wind & Drachen macht Luftströmung unmittelbar spürbar. Du steuerst Sport- und Trickdrachen, Powerkites oder Kite-Buggys und lernst, Windfenster, Zug und Geschwindigkeit einzuschätzen. Das ist besonders reizvoll für Menschen, die draußen Technik mit Bewegung verbinden möchten. Je nach Gerät reichen Leinen und freie Fläche oder es braucht deutlich mehr Sicherheitsraum und Schutzausrüstung.', 'more'=>'Beim Drachenbau beeinflussen Profil, Waage und Material das Flugverhalten direkt. Powerkites erzeugen deutlich mehr Zug und benötigen sichere Startflächen, Abstand zu Menschen und eine realistische Einschätzung des Windes. Landkiting und Kite Buggy verbinden den Schirm mit Bewegung am Boden und erhöhen Geschwindigkeit und Bremsweg erheblich. Stromleitungen, Straßen und Gewitter sind klare Ausschlusskriterien. Sportdrachen, Trick-Kites und Zugdrachen reagieren je nach Fläche, Leinen und Windstärke sehr unterschiedlich; ein kleineres System kann bei kräftigem Wind deutlich anspruchsvoller sein als erwartet.

Leinen können unter Zug gefährlich schneiden; deshalb gehören Handschutz, Abstand und ein freier Startkorridor bei stärkeren Schirmen zur vernünftigen Vorbereitung. Drachen reagieren unmittelbar auf Windfenster, Leinenlänge und kleine Steuerbewegungen. Eine große freie Fläche ohne Straßen, Leitungen oder Zuschauer ist deshalb Teil der Grundausstattung. Beginne bei moderatem Wind und lerne zuerst Start, Landung und kontrolliertes Entlasten der Leinen. So verstehst du Zugkräfte, bevor größere Flächen oder schnellere Modelle den Handlungsspielraum deutlich verkleinern und Fehler weniger verzeihen.'],
            'team-wettkampf' => ['hero'=>'Gemeinsam spielen, trainieren und fair konkurrieren.', 'lead'=>'Team & Wettkampf umfasst Hobbys, bei denen Regeln, Zusammenspiel und gemeinsames Training genauso wichtig sind wie individuelles Können. Von Ultimate Frisbee über Jugger und Teqball bis HEMA oder Drone Soccer reicht die Spannweite weit. Du erlebst Bewegung und Wettbewerb gemeinsam mit anderen und findest über eine Gruppe oder ein Training meist den besten Einstieg.', 'more'=>'Jugger kombiniert Teamsport mit klar geregelten Rollen und gepolsterter Ausrüstung. HEMA und historisches Fechten arbeiten mit rekonstruierten Kampftechniken und benötigen geeignetes Training sowie Schutz, bevor Tempo und Intensität steigen. Footgolf, Speedminton und Teqball sind leichter zugängliche Varianten bekannter Bewegungsmuster, haben aber jeweils eigene Spielfelder und Regeln. Drone Soccer bringt Technik und Teamtaktik zusammen und setzt geschützte Flugbereiche voraus. Welche Ausrüstung nötig ist, hängt deshalb stark vom Sport und Verein ab. Ultimate, Jugger, HEMA, Footgolf und andere Disziplinen setzen unterschiedliche Schwerpunkte auf Technik, Taktik, Bewegung und direkten Wettkampf.

Bei Kontaktsportarten oder Trainingswaffen ist außerdem entscheidend, dass Schutzstandard und Intensität gemeinsam festgelegt sind und nicht erst nach einem Treffer diskutiert werden. Neue Sportarten werden zugänglicher, wenn du zuerst Spielfluss und wenige Grundregeln verstehst. Technik und Taktik entwickeln sich danach gemeinsam mit Mitspielern. Eine lockere Trainingsgruppe ist oft der beste Einstieg, weil Material, Feldgröße und typische Abläufe direkt erlebt werden. Fairness und klare Absprachen gehören besonders bei körperbetonten oder ungewöhnlichen Disziplinen genauso zum Können wie Geschwindigkeit und Trefferquote.'],
            'geschick-tricks' => ['hero'=>'Kleine Bewegungen so lange verfeinern, bis sie sitzen.', 'lead'=>'Geschick & Tricks versammelt Hobbys, bei denen kleine Bewegungen durch Wiederholung erstaunlich präzise werden. Du übst mit Yo-Yo, Kendama, Diabolo, Poi, Karten oder Zauberwürfel und kannst fast überall kurze Trainingsphasen einbauen. Das ist ideal, wenn du sichtbaren Fortschritt und knifflige Abläufe magst. Meist brauchst du nur ein passendes Gerät und etwas Platz.', 'more'=>'Kendama trainiert Timing und Körperbewegung, Diabolo stärker Rhythmus und Beschleunigung. Poi erweitert Koordination auf beide Hände und braucht genug freien Raum. Contact Juggling arbeitet mit fließenden Illusionen und präziser Ballkontrolle, während Cardistry Karten als visuelles Bewegungsmaterial nutzt. Speedcubing ist weniger Fingerakrobatik allein als die Verbindung aus Lösungsstrategie, Blick voraus und flüssigen Drehungen. Pen Spinning lässt sich fast überall üben. Statt viele Tricks gleichzeitig anzufangen, lohnt es sich, Übergänge und Grundbewegungen wirklich sicher zu machen.

Yo-Yo, Kendama, Diabolo, Poi, Cardistry und ähnliche Hobbys unterscheiden sich im Material, werden aber alle über wiederholbare kleine Bewegungsabläufe gelernt. Videoaufnahmen in Zeitlupe können zusätzlich helfen, kleine Bewegungsfehler zu erkennen, die sich beim normalen Üben nur schwer selbst wahrnehmen lassen. Viele Trickhobbys brauchen kaum Platz, aber regelmäßige kurze Übung. Teile schwierige Bewegungen in kleine Abschnitte und wiederhole sie langsam, bevor Tempo dazukommt. Videoaufnahmen helfen, Handposition oder Flugbahn zu erkennen. Fortschritt zeigt sich oft zuerst darin, dass eine Bewegung reproduzierbar wird. Erst danach lohnt die nächste Variation; dadurch bleibt Lernen motivierend und Materialverschleiß überschaubar.'],
            'muenzen-geld' => ['hero'=>'Geldstücke lesen, einordnen und sinnvoll sammeln.', 'lead'=>'Münzen & Geld verbindet Sammeln mit Geschichte, Gestaltung und genauer Beobachtung. Du ordnest Münzen, Scheine oder andere Zahlungsmittel nach Land, Epoche, Prägung, Variante und Erhaltung und lernst, kleine Unterschiede zu erkennen. Geschichte wird hier an echten Objekten unmittelbar greifbar. Lupe, sichere Aufbewahrung und verlässliche Literatur reichen für einen guten Einstieg.', 'more'=>'Notgeld und Tokens haben oft einen starken regionalen Bezug, Medaillen dagegen keinen offiziellen Zahlungscharakter. Reinigung kann Oberflächen und Sammlerwert dauerhaft beschädigen; vermeintlicher Schmutz oder Patina gehört häufig zum historischen Zustand. Gewicht, Durchmesser und gute Fotos helfen bei der Bestimmung, ersetzen bei wertvollen Stücken aber keine fachliche Prüfung. Numismatik wird besonders interessant, wenn du ein klares Gebiet wählst und Herkunft dokumentierst. Sammelrichtung, Bestimmung, Erhaltung und Aufbewahrung hängen eng zusammen; Marktwerte sollten immer mit realen Vergleichsverkäufen statt bloßen Angebotspreisen abgeglichen werden.

Für bessere Vergleichbarkeit lohnt sich außerdem, Vorderseite, Rückseite, Rand und Maße nach demselben Schema zu fotografieren und Dubletten nicht nur nach Jahrgang zu bewerten. Beim Sammeln von Münzen und Papiergeld geht es um mehr als Alter oder Nennwert. Prägeort, Jahrgang, Variante, Erhaltung und historische Einordnung bestimmen, warum ein Stück interessant ist. Für den Einstieg brauchst du Lupe, schonende Aufbewahrung und verlässliche Literatur. Reinigen solltest du Sammlerstücke nicht vorschnell, weil selbst gut gemeinte Politur Oberfläche und Wert dauerhaft verändern kann.'],
            'papier-dokumente' => ['hero'=>'Gedruckte und geschriebene Zeitzeugnisse bewahren.', 'lead'=>'Papier & Dokumente umfasst Postkarten, Briefmarken, Exlibris, Landkarten und andere gedruckte oder geschriebene Zeitzeugnisse. Du sammelst, bestimmst, ordnest und bewahrst Stücke nach Herkunft, Motiv, Drucktechnik oder Nutzung. Wer Geschichte und Grafik in kleinen Details mag, findet hier viel Stoff. Wichtig sind schonende Aufbewahrung, trockene Hände und gute Informationen zur Einordnung.', 'more'=>'Exlibris erzählen über Besitzer und Grafik, Landkarten zusätzlich über Vermessung und historische Grenzen. Ephemera umfasst kurzlebige Drucksachen wie Tickets, Prospekte oder Etiketten, die gerade deshalb selten erhalten sind. Papier reagiert auf Licht, Feuchtigkeit und säurehaltige Materialien. Klarsichthüllen und Alben sollten archivgeeignet sein; Klebeband, Laminieren oder unsachgemäßes Glätten können dauerhafte Schäden verursachen. Postkarten, Karten, Briefmarken und andere Papierobjekte brauchen unterschiedliche Ordnungssysteme, profitieren aber gemeinsam von dokumentierter Herkunft und archivgeeigneter Aufbewahrung. So bleibt der historische Charakter erhalten, ohne jedes Stück unnötig zu behandeln.

Bei wertvollen oder fragilen Stücken sollte außerdem jede Beschriftung auf Hülle oder Träger erfolgen und nicht direkt auf dem historischen Papier. Papier altert vor allem durch Licht, Säure, Feuchtigkeit und ungeeignete Klebstoffe. Archivhüllen und säurefreie Unterlagen sind deshalb wichtiger als dekorative Aufbewahrung. Beschrifte Hüllen statt Originale und dokumentiere Vorder- und Rückseite. Bei Postkarten, Karten oder Ephemera liefern Stempel, Druckvermerke und handschriftliche Notizen oft zusätzlichen Kontext, der durch Zuschneiden oder Ablösen unwiederbringlich verloren gehen kann.'],
            'technik-medien' => ['hero'=>'Geräte und Medien als Technikgeschichte sammeln.', 'lead'=>'Technik & Medien macht Geräte und Datenträger vergangener Jahrzehnte zum Sammelgebiet. Du bewahrst, vergleichst und teils restaurierst Computer, Radios, Kameras, Taschenrechner, Füllhalter oder Tonträger und kannst manches wieder benutzen. Das ist spannend für Technik- und Designfans. Platz, Dokumentation und vorsichtige Prüfung sind wichtiger als möglichst schnelles Einschalten alter Geräte.', 'more'=>'Bei Kameras zählen Mechanik, Verschluss und Optik, bei Füllfederhaltern Feder, Füllsystem und eingetrocknete Tinte. Schallplatten, Kassetten und MiniDiscs brauchen wiederum passende Lagerung und funktionierende Abspielgeräte. Originalzustand, Zubehör und dokumentierte Herkunft können für Sammler wichtiger sein als eine glänzende Oberfläche. Aggressive Reinigung oder irreversible Umbauten sind deshalb selten eine gute erste Maßnahme. Funktionserhalt und konservierende Aufbewahrung müssen je nach Gerät gegeneinander abgewogen werden; Reparaturversuche ohne Diagnose können historische Technik stärker schädigen als ein dokumentierter Defekt.

Magnetische Medien und empfindliche Datenträger profitieren außerdem von einer digitalen Sicherung, wenn ihr Inhalt ebenso wichtig ist wie das physische Sammlerstück. Bei technischen Sammlungen zählt Funktion, aber auch Vollständigkeit. Netzteile, Kabel, Verpackungen oder Handbücher können ein Gerät historisch erst richtig einordnen. Bevor alte Elektronik eingeschaltet wird, sollte ihr Zustand geprüft werden. Digitale Inhalte lassen sich zusätzlich sichern, ohne das Original zu verändern. So bleibt die Sammlung benutzbar und gleichzeitig dokumentiert, auch wenn einzelne Datenträger oder Bauteile später ausfallen.'],
            'spielzeug-spiele' => ['hero'=>'Spielkultur sammeln – von Karten bis Modellautos.', 'lead'=>'Spielzeug & Spiele zu sammeln verbindet persönliche Erinnerung mit Produkt- und Designgeschichte. Du suchst Figuren, Karten, Würfel, Modellautos oder komplette Spiele und vergleichst Hersteller, Auflage, Zustand und Vollständigkeit. Das passt zu Sammlern, die Varianten und kleine Details mögen. Ein klarer Schwerpunkt und passende Aufbewahrung helfen, aus Einzelstücken eine nachvollziehbare Sammlung zu machen.', 'more'=>'Würfel können nach Material, System, Hersteller oder Gestaltung gesammelt werden. Modellautos bringen Maßstab, Marke und Modellgeneration ins Spiel und sollten so gelagert werden, dass feine Teile und Lack geschützt bleiben. Häufige Neuauflagen machen eine genaue Editionsbestimmung wichtig. Statt wahllos Einzelstücke zu kaufen, lohnt ein klarer Schwerpunkt und eine einfache Inventarliste mit Fotos. Figuren, Karten, Modellautos und Spiele unterscheiden sich bei Vollständigkeit und Zustandsbewertung; echte Varianten lassen sich nur mit Hersteller-, Auflagen- und Zubehörmerkmalen sicher trennen.

Bei kompletten Sets lohnt sich außerdem eine Teileliste, weil kleine Zubehörstücke, Anleitungen oder Einsätze den Unterschied zwischen vollständig und nur optisch komplett ausmachen können. Bei Spielzeug und Spielen sind kleine Varianten oft entscheidend: Auflage, Hersteller, Zubehör, Kartenrückseite oder Verpackung unterscheiden gewöhnliche von seltenen Ausgaben. Vollständigkeit sollte dokumentiert werden, ohne Teile unnötig zu restaurieren. Für häufiges Ansehen eignen sich Schutzhüllen oder Ersatzkomponenten, während empfindliche Originale separat lagern. So bleibt die Sammlung spielerisch zugänglich, ohne historische Substanz zu opfern oder empfindliche Originalteile unnötig zu beanspruchen.'],
            'naturfunde' => ['hero'=>'Funde aus der Natur erkennen, dokumentieren und bewahren.', 'lead'=>'Naturfunde sammeln bedeutet, Mineralien, Fossilien, Meteoriten, Muscheln oder Seeglas nicht nur mitzunehmen, sondern zu bestimmen und ihren Fundkontext zu bewahren. Du suchst, vergleichst, dokumentierst und ordnest Stücke. Das ist ideal für neugierige Menschen, die draußen entdecken möchten. Bestimmungshilfen und Fundnotizen sind ebenso wichtig wie die Frage, was am jeweiligen Ort gesammelt werden darf.', 'more'=>'Echte Meteoriten sind deutlich seltener als auffällige Schlacken oder eisenhaltige Steine, weshalb seriöse Bestimmung nötig ist. Seeglas und Muscheln erzählen über Herkunft und Verwitterung, Strandgut kann zusätzlich rechtliche oder ökologische Fragen aufwerfen. Mikrometeoriten erfordern saubere Probenahme, weil viele technische Partikel ähnlich aussehen. Schutzgebiete, Fundstellen und lokale Regeln können das Sammeln einschränken oder verbieten. Gute Etiketten mit Datum und Ort erhalten wissenschaftlichen und persönlichen Wert. Mineralien, Fossilien, Muscheln und andere Naturfunde brauchen unterschiedliche Lagerung; Fundort, Artenschutz und geologischer Kontext bestimmen mit, wie sinnvoll und verantwortungsvoll ein Stück gesammelt werden kann.

Empfindliche Mineralien oder organische Funde reagieren außerdem unterschiedlich auf Licht und Feuchtigkeit; eine einzige Aufbewahrungsbox ist deshalb nicht für jede Sammlung ideal. Naturfunde gewinnen durch Fundort und geologischen oder biologischen Kontext. Notiere deshalb Datum und möglichst genaue Herkunft, solange du sie sicher weißt. Manche Gebiete und Arten unterliegen Sammel- oder Schutzregeln; diese gehören vor der Suche geklärt. Zur Aufbewahrung brauchen Mineralien, Fossilien, Muscheln oder organische Funde unterschiedliche Bedingungen. Eine klare Etikettierung macht auch kleine Stücke wissenschaftlich und persönlich interessanter.'],
            'werbung-design' => ['hero'=>'Grafische Alltagskultur erkennen und erhalten.', 'lead'=>'Werbung & Design sammelt grafische Alltagskultur vergangener Jahrzehnte – etwa Reklame, Filmplakate sowie Blech- und Emailschilder. Du vergleichst Motive, Materialien, Drucktechniken, Alter und Zustand und lernst Originale von späteren Reproduktionen zu unterscheiden. Das reizt Menschen mit Sinn für Grafik und Zeitgeschichte. Gute Lagerung und vorsichtige Dokumentation erhalten mehr als aggressive Restaurierung.', 'more'=>'Herstellerangaben, Druckraster, Befestigungslöcher, Rückseite und bekannte Motivvarianten helfen bei der Datierung. Besonders beliebte Werbemotive werden häufig neu aufgelegt oder künstlich gealtert, weshalb Herkunft und Vergleichsstücke wichtig sind. Eine professionelle Restaurierung kann bei seltenen Objekten sinnvoll sein; vorschnelles Lackieren oder Nachmalen nimmt dagegen historische Substanz. Reklameschilder, Filmplakate und andere Werbeobjekte lassen sich über Material, Drucktechnik, Herstellermerkmale und bekannte Varianten auf Echtheit und Alter prüfen. So kannst du Gestaltung genießen, ohne Patina automatisch mit Schaden oder künstliche Alterung automatisch mit Echtheit zu verwechseln. Papierplakate reagieren empfindlich auf Licht und Feuchtigkeit; bei Blech- und Emailschildern sind Rost, Abplatzer und Reparaturen wichtige Zustandsmerkmale.

Bei gerahmten Papierobjekten sollten außerdem UV-Schutz, Abstand zum Glas und archivgeeignete Rückwände berücksichtigt werden, wenn sie dauerhaft gezeigt werden sollen. Bei grafischen Sammlerstücken lohnt sich der Vergleich mit zeitgenössischen Katalogen, Anzeigen oder Herstellerarchiven. So lassen sich Nachdrucke und spätere Varianten besser einordnen. Rahmen und Halterungen sollten reversibel sein und das Original nicht verkleben. Wenn du Motive nach Marke, Epoche oder Gestaltungsstil ordnest, wird aus einer Reihe schöner Einzelstücke zugleich ein sichtbarer Überblick über Designgeschichte und wechselnde Sehgewohnheiten.'],
            'werkzeuge-geraete' => ['hero'=>'Werkzeuge als Zeugnisse von Handwerk und Technik sammeln.', 'lead'=>'Werkzeuge & Geräte als Sammelgebiet erzählen unmittelbar, wie früher gearbeitet und gemessen wurde. Du suchst, bestimmst und bewahrst Hobel, Schraubstöcke, Messinstrumente und andere technische Arbeitsmittel und achtest auf Hersteller, Bauform und Nutzungsspuren. Das passt zu Menschen mit Interesse an Handwerk und Mechanik. Originalzustand und sichere Lagerung sind oft wichtiger als vollständige Restaurierung.', 'more'=>'Schraubstöcke zeigen Unterschiede bei Backen, Führung und Befestigung. Messinstrumente sind besonders interessant, wenn Skalen, Etuis oder Zubehör erhalten sind; ihre Genauigkeit sollte aber nicht ungeprüft vorausgesetzt werden. Rost lässt sich je nach Objekt vorsichtig stabilisieren, doch Schleifen und Neulackieren können Markierungen oder originale Oberflächen vernichten. Bewegliche Teile sollten nicht mit ungeeigneten Ölen geflutet werden. Eine Sammlung gewinnt durch Dokumentation von Herkunft und Funktion. Hobel, Schraubstöcke und Messinstrumente werden nach Bauform, Hersteller, Zustand und Funktion eingeordnet; Nutzung setzt zusätzlich voraus, dass tragende und bewegliche Teile noch sicher sind.

Vor einer tatsächlichen Nutzung sollte außerdem geprüft werden, ob Griffe, Spannteile und Material noch belastbar sind; Sammlerzustand ist nicht automatisch Betriebszustand. Werkzeuge erzählen besonders viel, wenn Nutzungsspuren lesbar bleiben. Stempel, Maßangaben, Patentnummern und konstruktive Details sollten deshalb vor jeder Reinigung fotografiert werden. Fehlende Teile lassen sich manchmal ergänzen, sollten aber als Ersatz dokumentiert bleiben. Für schwere Stücke sind stabile Regale und sichere Auflage wichtiger als dekorative Präsentation; alte Mechanik kann trotz Sammlerwert unerwartet klemmen oder kippen.'],
            'alltagsobjekte' => ['hero'=>'Gewöhnliche Dinge mit ungewöhnlicher Geschichte.', 'lead'=>'Alltagsobjekte werden spannend, sobald du ihre Varianten und Geschichte genauer betrachtest. Schlüssel, Schlösser, Knöpfe oder Parfümflakons erzählen von Technik, Material, Mode und Gebrauch. Du sammelst, vergleichst und dokumentierst nach Epoche, Hersteller oder Funktion. Das eignet sich für neugierige Sammler, die im Gewöhnlichen Besonderheiten entdecken. Schon kleine Stücke lassen sich platzsparend systematisch aufbauen.', 'more'=>'Vorhängeschlösser können technisch gesammelt werden, sollten aber nicht durch gewaltsame Öffnungsversuche beschädigt werden. Knöpfe unterscheiden sich nach Material, Herstellung, Motiv und Verwendung und lassen sich oft erst über die Rückseite genauer bestimmen. Parfümflakons verbinden Glasgestaltung, Marken- und Verpackungsgeschichte; Reste alter Flüssigkeiten sollten vorsichtig behandelt und Behälter nicht unnötig geöffnet werden. Reinigung muss zum Material passen, weil Metall, Glas, Kunststoff und Lack völlig unterschiedlich reagieren. Schlüssel, Schlösser, Knöpfe und Flakons werden übersichtlicher, wenn du nach Epoche, Material, Funktion oder Hersteller sammelst und Varianten konsequent dokumentierst.

Zusammengehörige Schlüssel-Schloss-Paare, Originalstopfen oder Verpackungen können zusätzlich viel Kontext liefern und sollten deshalb nicht vorschnell voneinander getrennt werden. Bei kleinen Alltagsobjekten lohnt sich eine klare Sammelidee, weil das Angebot fast unbegrenzt ist. Du kannst nach Epoche, Hersteller, Material, Funktion oder Region ordnen. Fotos und Maße helfen, ähnliche Varianten auseinanderzuhalten. Gerade bei Metall und Glas ist vorsichtige trockene Reinigung oft besser als aggressive Mittel. Originale Etiketten, Schlüsselanhänger oder Verpackungen solltest du als Teil der Geschichte mitbewahren.'],
            'suchen-finden' => ['hero'=>'Draußen suchen – mit Methode, Geduld und klaren Regeln.', 'lead'=>'Suchen & Finden macht den Weg zum Fund selbst zum Hobby. Beim Sondeln, Magnetfischen, Goldwaschen oder der Suche nach Fossilien und Bernstein bist du draußen unterwegs, liest Gelände und arbeitest mit unterschiedlichen Hilfsmitteln. Entdeckergeist und Recherche gehören hier unmittelbar zusammen. Besonders wichtig sind dabei Fundort, Genehmigungen und klare Regeln dafür, was geborgen oder behalten werden darf.', 'more'=>'Magnetfischen kann schwere oder gefährliche Gegenstände zutage bringen und ist örtlich eingeschränkt. Goldwaschen braucht geeignete Gewässer und viel Geduld, Edelstein- und Fossiliensuche geologisches Wissen über Fundschichten. Bernstein lässt sich an passenden Küsten und nach bestimmten Wetterlagen finden, während Mudlarking und Bottle Digging stark von lokalen Eigentums- und Grabungsregeln abhängen. Handschuhe, festes Schuhwerk und ein sicherer Umgang mit unbekannten Funden gehören zur Grundausstattung. Metalldetektion, Magnetfischen, Goldwaschen und andere Suchformen folgen unterschiedlichen Regeln und Methoden; Fundortdokumentation und geklärte Rechte sind oft wichtiger als die bloße Menge der Funde.

Bei Munition, Waffenresten oder unbekannten gefährlichen Gegenständen gilt außerdem: nicht weiter hantieren oder transportieren, sondern Fundstelle sichern und zuständige Stellen informieren. Vor jeder Suche steht die Frage, wo du legal und ohne Schäden arbeiten darfst. Eigentümerzustimmung, Schutzgebiete und regionale Fundregeln unterscheiden sich deutlich. Dokumentiere interessante Funde noch am Ort, bevor sie gereinigt werden. Bei unbekannten Metallobjekten, Munition oder möglichen Kampfmitteln gilt: Abstand halten und zuständige Stellen informieren. Gute Suche bedeutet nicht, jeden Fund unbedingt selbst bergen zu müssen.'],
            ];
        }
        $slug = sanitize_title((string)$page->post_name);
        $aliases = [
            'druck-fotografie'=>'druck-foto','oberflache-deko'=>'oberflaeche-deko','guss-formen'=>'guss-form',
            'hydroponik-indoor'=>'hydro-indoor','moos-miniaturgarten'=>'moos-miniaturgaerten','gartnern'=>'gaertnern',
            'imkerei-bestauber'=>'imkerei-bestaeuber','munzen-geld'=>'muenzen-geld','werkzeuge-gerate'=>'werkzeuge-geraete',
        ];
        if (!isset($map[$slug]) && isset($aliases[$slug])) { $slug = $aliases[$slug]; }
        return isset($map[$slug]) && is_array($map[$slug]) ? $map[$slug] : [];
    }
    private static function hub2_top_copy($page, $world_slug='') {
        if (!$page instanceof WP_Post) { return ''; }
        $editorial = self::hub2_editorial($page);
        if (!empty($editorial)) {
            return trim((string)($editorial['lead'] ?? '') . ' ' . (string)($editorial['more'] ?? ''));
        }
        // Fail closed: no generated template prose for Hub2. A genuinely authored manual text may still be used.
        $manual = self::page_intro_long($page);
        if ($manual !== '') {
            $manual = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($manual)));
            $wc = count(preg_split('/\s+/u', $manual, -1, PREG_SPLIT_NO_EMPTY));
            if ($wc >= 130 && $wc <= 220) { return $manual; }
        }
        return '';
    }

    private static function hub2_copy_parts($copy) {
        $copy=trim((string)$copy); if($copy===''){return ['',''];}
        $sentences=preg_split('/(?<=[.!?])\s+(?=[\p{Lu}ÄÖÜ0-9„])/u',$copy,-1,PREG_SPLIT_NO_EMPTY);
        if(!is_array($sentences) || count($sentences)<5){return [$copy,''];}
        $lead=[]; $more=[]; $words=0;
        foreach($sentences as $sentence){
            $wc=count(preg_split('/\s+/u',trim($sentence),-1,PREG_SPLIT_NO_EMPTY));
            if($words<72 || count($lead)<3){$lead[]=$sentence; $words+=$wc;} else {$more[]=$sentence;}
        }
        return [trim(implode(' ',$lead)), trim(implode(' ',$more))];
    }


    private static function hub2_layout_parts($copy) {
        $copy = trim((string)$copy);
        if ($copy === '') { return ['','','']; }
        $sentences = preg_split('/(?<=[.!?])\s+(?=[\p{Lu}ÄÖÜ0-9„])/u', $copy, -1, PREG_SPLIT_NO_EMPTY);
        if (!is_array($sentences) || !$sentences) { return [$copy,'','']; }
        $hero = trim((string)array_shift($sentences));
        $visible = []; $more = []; $words = 0;
        foreach ($sentences as $sentence) {
            $wc = count(preg_split('/\s+/u', trim($sentence), -1, PREG_SPLIT_NO_EMPTY));
            if ($words < 58 || count($visible) < 2) { $visible[] = $sentence; $words += $wc; }
            else { $more[] = $sentence; }
        }
        return [$hero, trim(implode(' ', $visible)), trim(implode(' ', $more))];
    }

    private static function render_hub2_intro_block($page, $world_slug='') {
        if (!$page instanceof WP_Post) { return ''; }
        $title = trim((string)get_the_title($page));
        $copy = self::hub2_top_copy($page, $world_slug);
        [$lead,$more]=self::hub2_copy_parts($copy);
        $claim=self::hub2_claim($title,$world_slug);
        $icon = '<span class="hd-page-title-icon hd-topic-title-icon">' . self::topic_icon_svg($title, $world_slug) . '</span>';
        $html='<section class="hd-page-intro hd-hub2-intro"><div class="hd-page-intro-copy"><span class="hd-page-kicker hd-hub2-claim">'.esc_html($claim).'</span><h1>'.$icon.esc_html($title).'</h1><div class="hd-hub2-intro-text">'.self::paragraph_markup($lead,2).'</div>';
        if($more!==''){$html.='<details class="hd-hub2-more"><summary>Mehr zu '.esc_html($title).' erfahren</summary><div>'.self::paragraph_markup_explicit_v150698($more).'</div></details>';}
        return $html.'</div></section>';
    }

    private static function page_by_path($paths) {
        foreach ((array)$paths as $path) {
            $path = trim((string)$path, '/');
            if ($path === '') { continue; }
            $page = get_page_by_path($path, OBJECT, 'page');
            if ($page instanceof WP_Post && $page->post_status === 'publish') { return $page; }
        }
        return null;
    }

    private static function page_link($paths) {
        $page = self::page_by_path($paths);
        return $page ? (string)get_permalink($page) : '';
    }

    private static function logo_url() {
        return plugin_dir_url(dirname(__FILE__)) . 'assets/hobby-depot-v150645/logo-variant3-v150645.png?ver=' . rawurlencode(self::RELEASE);
    }

    private static function asset_url($name) {
        return plugin_dir_url(dirname(__FILE__)) . 'assets/hobby-depot-v150617/' . ltrim((string)$name, '/') . '?ver=' . rawurlencode(self::RELEASE);
    }

    public static function world_hero_asset($slug) {
        $slug = sanitize_key((string)$slug);
        if (!in_array($slug, self::world_slugs(), true)) { $slug = 'gestalten'; }
        $url = self::asset_url($slug . '-v150616.webp');
        return (string)apply_filters('pftk_hobby_world_hero_asset', $url, $slug);
    }

    private static function topbar_links() { return ''; }

    private static function nav_pages() {
        $out = [];
        foreach (self::worlds() as $world) {
            $out[] = [
                'label' => $world['title'],
                'url' => $world['url'],
                'page' => $world['page'],
                'world' => $world,
            ];
        }
        return $out;
    }

    private static function footer_portal_pages() {
        $defs = [
            ['Hobbyfinder', ['magazin/hobbyfinder','hobbyfinder']],
            ['Magazin', ['magazin']],
            ['Anbieter', ['anbieter']],
        ];
        $out = [];
        foreach ($defs as $def) {
            $page = self::page_by_path($def[1]);
            if ($page) { $out[] = ['label'=>$def[0], 'url'=>get_permalink($page)]; }
        }
        return $out;
    }

    /**
     * 1.50.668 – same fail-closed principle as the proven Hab & Bewahr 0.1.20 fix:
     * once a central tree revision exists, the design MUST NOT invent a second
     * navigation authority from raw WordPress parent relationships.
     */
    private static function registry_revision() {
        if (function_exists('hd_category_registry_revision')) {
            return trim((string)hd_category_registry_revision());
        }
        return function_exists('get_option') ? trim((string)get_option('apkw_target_tree_active_revision_v1', '')) : '';
    }

    private static function registry_ready() {
        return function_exists('hd_category_registry_ready')
            && function_exists('hd_category_registry_find_node_by_object')
            && function_exists('hd_category_registry_children')
            && function_exists('hd_category_registry_resolve')
            && function_exists('hd_category_registry_node')
            && (bool)hd_category_registry_ready();
    }

    private static function registry_page_node($page_id) {
        $page_id = absint($page_id);
        if ($page_id < 1 || !self::registry_ready()) { return null; }
        $node = hd_category_registry_find_node_by_object($page_id, 'page');
        if (!is_array($node)) { return null; }
        if ((string)($node['status'] ?? 'active') !== 'active') { return null; }
        if ((string)($node['pillar'] ?? '') !== 'core') { return null; }
        if ((string)($node['object_type'] ?? '') !== 'page') { return null; }
        return $node;
    }

    private static function registry_child_nodes_for_page($page_id) {
        $node = self::registry_page_node($page_id);
        if (!is_array($node)) { return []; }
        $children = hd_category_registry_children((string)$node['node_id'], 'core');
        if (!is_array($children)) { return []; }
        usort($children, static function($a, $b) {
            $ao = (int)($a['nav_order'] ?? ($a['menu_order'] ?? 0));
            $bo = (int)($b['nav_order'] ?? ($b['menu_order'] ?? 0));
            if ($ao !== $bo) { return $ao <=> $bo; }
            return strnatcasecmp((string)($a['display_name'] ?? ''), (string)($b['display_name'] ?? ''));
        });
        return $children;
    }

    private static function direct_page_children($parent_id) {
        $parent_id = absint($parent_id);
        $revision = self::registry_revision();
        if ($revision !== '') {
            // Fail closed: an active central revision must never fall back to stale WP siblings/children.
            if (!self::registry_ready()) { return []; }
            $out = [];
            foreach (self::registry_child_nodes_for_page($parent_id) as $node) {
                if ((string)($node['object_type'] ?? '') !== 'page') { continue; }
                $obj = hd_category_registry_resolve((string)($node['node_id'] ?? ''));
                if ($obj instanceof WP_Post && $obj->post_type === 'page' && $obj->post_status === 'publish') { $out[] = $obj; }
            }
            return $out;
        }
        // Standalone preview only: no registered central revision exists at all.
        $pages = get_pages([
            'parent' => $parent_id,
            'post_status' => 'publish',
            'sort_column' => 'menu_order,post_title',
            'sort_order' => 'ASC',
        ]);
        return is_array($pages) ? $pages : [];
    }

    private static function direct_category_children_for_page($page) {
        if (!$page instanceof WP_Post || self::registry_revision() === '' || !self::registry_ready()) { return []; }
        $out = [];
        foreach (self::registry_child_nodes_for_page($page->ID) as $node) {
            if ((string)($node['object_type'] ?? '') !== 'category') { continue; }
            $obj = hd_category_registry_resolve((string)($node['node_id'] ?? ''));
            if ($obj instanceof WP_Term && (string)$obj->taxonomy === 'category') { $out[] = $obj; }
        }
        return $out;
    }

    private static function canonical_child_labels_for_page($page) {
        if (!$page instanceof WP_Post) { return []; }
        $labels = [];
        foreach (self::direct_page_children($page->ID) as $child) {
            if ($child instanceof WP_Post) { $labels[] = get_the_title($child); }
        }
        foreach (self::direct_category_children_for_page($page) as $term) {
            if ($term instanceof WP_Term) { $labels[] = $term->name; }
        }
        return array_values(array_unique(array_filter(array_map('trim', $labels))));
    }

    private static function mega_intermediate_children($world_page) {
        if (!$world_page instanceof WP_Post) { return []; }
        $children = self::direct_page_children($world_page->ID);
        if (self::registry_revision() === '' || !self::registry_ready()) { return $children; }
        $out = [];
        foreach ($children as $child) {
            if (!$child instanceof WP_Post) { continue; }
            $has_page_child = false;
            foreach (self::registry_child_nodes_for_page($child->ID) as $node) {
                if ((string)($node['object_type'] ?? '') === 'page' && (string)($node['status'] ?? 'active') === 'active') {
                    $has_page_child = true;
                    break;
                }
            }
            // Existing 1.50.669 WIP rule carried forward: only genuine intermediate
            // hub pages become mega columns. Direct hobby pages such as Heimwerken
            // or Gärtnern remain reachable on their world page and are not promoted
            // to a fake intermediate column.
            if ($has_page_child) { $out[] = $child; }
        }
        return $out;
    }

    private static function worlds() {
        $worlds = [];
        foreach (self::world_slugs() as $slug) {
            $page = self::page_by_path([$slug]);
            if (!$page) { continue; }
            $worlds[] = [
                'slug' => $slug,
                'page' => $page,
                'title' => get_the_title($page),
                'url' => get_permalink($page),
                'children' => self::mega_intermediate_children($page),
            ];
        }
        return $worlds;
    }

    private static function magazine_page_defs_v150719() {
        return [
            'hobbyfinder' => [
                'label' => 'Hobbyfinder',
                'asset' => 'hero-masters-v150684/suchen-finden.webp',
                'w' => 1600,
                'h' => 587,
                'claim' => 'Finde, was wirklich zu dir passt.',
                'hero' => 'Acht kurze Fragen bringen dich von deinen Wünschen zu einer überschaubaren Auswahl.',
                'lead' => 'Du suchst ein neues Hobby, weißt aber noch nicht genau, in welche Richtung es gehen soll? Hier startest du nicht mit einem Hobbynamen, sondern mit deinem Alltag: Wie viel Zeit hast du, wie viel Platz steht dir zur Verfügung und möchtest du eher Ruhe, Bewegung, Kreativität oder Gesellschaft?',
                'more' => 'Der Hobbyfinder grenzt die Auswahl Schritt für Schritt ein und zeigt dir anschließend Hobbys, die zu deinen Angaben passen. Dabei geht es nicht darum, dir ein Hobby vorzuschreiben. Die Ergebnisse sollen dir Orientierung geben und auch Ideen zeigen, auf die du selbst vielleicht nicht gekommen wärst.

Wenn du schon weißt, welches Hobby dich interessiert, bist du im Hobbyregister oder in den normalen Hobbybereichen besser aufgehoben. Der Finder ist vor allem für die Situation gedacht, in der du offen bist und verschiedene Möglichkeiten vergleichen möchtest. Angaben wie Budget, Zeit oder Platz helfen dabei, unrealistische Vorschläge früh auszusortieren, ohne die Auswahl unnötig eng zu machen.',
                'terms' => ['alleine','gruppe','zu-zweit'],
            ],
            'alter-lebensphasen' => [
                'label' => 'Alter & Lebensphasen',
                'asset' => 'hero-masters-v150684/alltagsobjekte.webp',
                'w' => 1600,
                'h' => 587,
                'claim' => 'Hobbys verändern sich mit dir.',
                'hero' => 'Ideen und Orientierung für unterschiedliche Lebensphasen und Alltagssituationen.',
                'lead' => 'Ein Hobby muss zu deinem Leben passen – und das verändert sich. Schule, Studium, Beruf, Familie, Ruhestand oder ein neuer Alltag bringen unterschiedliche Möglichkeiten mit sich. Hier findest du Beiträge, die Hobbys aus genau dieser Perspektive betrachten.',
                'more' => 'Im Mittelpunkt stehen nicht starre Altersgrenzen, sondern typische Situationen: Wie flexibel muss ein Hobby sein? Lässt es sich allein oder gemeinsam ausüben? Braucht es feste Termine, viel Ausrüstung oder körperliche Belastbarkeit? Ein Hobby, das mit zwanzig ideal ist, kann mit vierzig noch genauso gut passen – nur vielleicht unter anderen Bedingungen.

Die Beiträge geben deshalb Orientierung für Lebensphasen und Alltagssituationen, ohne Menschen in Schubladen zu stecken. Konkrete Informationen zu einem einzelnen Hobby findest du weiterhin in dessen Hobbyseite oder im Hobbyregister. Hier geht es um die Frage, welche Arten von Hobbys zu bestimmten Lebensumständen besonders gut passen können.

Auch Veränderungen innerhalb derselben Lebensphase spielen eine Rolle: mehr oder weniger freie Zeit, gesundheitliche Einschränkungen, ein Umzug oder neue soziale Kontakte können die Anforderungen an ein Hobby deutlich verschieben.',
                'terms' => [],
            ],
            'geschichte-herkunft' => [
                'label' => 'Geschichte & Herkunft',
                'asset' => 'hero-masters-v150684/papier-dokumente.webp',
                'w' => 1600,
                'h' => 587,
                'claim' => 'Jedes Hobby hat eine Geschichte.',
                'hero' => 'Wo Hobbys herkommen, wie sie sich entwickelt haben und was bis heute geblieben ist.',
                'lead' => 'Viele Hobbys haben eine längere Geschichte, als man auf den ersten Blick vermutet. Techniken, Spiele, Sammelgebiete und Freizeitbeschäftigungen entstehen aus Handwerk, Wissenschaft, Sport, Traditionen oder technischen Entwicklungen und verändern sich mit der Zeit.',
                'more' => 'Hier geht es darum, wo ein Hobby herkommt, wie es sich verbreitet hat und warum bestimmte Methoden, Begriffe oder Regeln heute so aussehen, wie sie aussehen. Dabei interessieren nicht nur berühmte Erfindungen oder große historische Daten, sondern auch kleine Entwicklungsschritte, regionale Besonderheiten und der Wandel vom Beruf oder Gebrauchszweck zum Hobby.

Die Rubrik ersetzt keine Anleitung und keine Hobbyseite. Wenn du wissen möchtest, wie du konkret einsteigst oder welche Ausrüstung du brauchst, findest du das im jeweiligen Fachbereich. Hier steht der Hintergrund im Mittelpunkt: Herkunft, Entwicklung, Tradition und die Geschichten hinter Dingen, die heute ganz selbstverständlich zu einem Hobby gehören.

Gerade bei traditionellen Hobbys lohnt sich der Blick darauf, welche Werkzeuge, Materialien oder Regeln historisch bedingt sind und welche erst durch moderne Technik hinzugekommen sind.',
                'terms' => [],
            ],
            'hobby-portraets' => [
                'label' => 'Hobby-Porträts',
                'asset' => 'hero-masters-v150684/citizen-science.webp',
                'w' => 1600,
                'h' => 587,
                'claim' => 'Ein Hobby. Näher betrachtet.',
                'hero' => 'Unbekannte, kleine und besondere Hobbys verständlich vorgestellt.',
                'lead' => 'Manche Hobbys kennt fast jeder, andere muss man erst einmal kennenlernen. In den Hobby-Porträts stellen wir einzelne Freizeitbeschäftigungen so vor, dass du schnell verstehst, was man dabei eigentlich macht und was ihren besonderen Reiz ausmacht.',
                'more' => 'Ein Porträt zeigt dir den Charakter eines Hobbys: typische Tätigkeiten, Atmosphäre, Einstieg und Besonderheiten. Vor allem kleine, seltene oder ungewöhnliche Hobbys bekommen hier Raum, wenn sie keine große eigene Fachwelt im Hauptportal benötigen. So kannst du entdecken, ob ein Thema grundsätzlich zu dir passt, bevor du tiefer einsteigst.

Besteht zu einem Hobby bereits eine umfangreiche CORE-Seite, wird im Magazin keine zweite konkurrierende Hobbyseite aufgebaut. Dann verweist das Porträt oder ein redaktioneller Beitrag auf den bestehenden Fachbereich. Das Hobbyregister bleibt zusätzlich die einheitliche Vergleichsebene mit festen Merkmalen wie Zeit, Kosten, Platz und Anforderungen.

Wo es sinnvoll ist, zeigen wir außerdem, welche Varianten eines Hobbys typisch sind und ob der Einstieg eher spontan, projektbezogen oder langfristig angelegt ist.',
                'terms' => [],
            ],
            'hobby-ideen-inspiration' => [
                'label' => 'Hobby-Ideen & Inspiration',
                'asset' => 'hero-masters-v150684/werbung-design.webp',
                'w' => 1600,
                'h' => 587,
                'claim' => 'Lust auf etwas Neues?',
                'hero' => 'Ideen nach Stimmung, Situation und Interesse – zum Stöbern und Ausprobieren.',
                'lead' => 'Du möchtest etwas Neues anfangen, aber nicht erst stundenlang nach einzelnen Hobbys suchen? Hier sammeln wir Ideen nach Stimmung, Situation und Interesse – von ruhigen Beschäftigungen zuhause bis zu Projekten, bei denen du draußen, kreativ oder technisch aktiv wirst.',
                'more' => 'Die Beiträge verbinden mehrere Hobbys zu einem gemeinsamen Thema. Das können zum Beispiel Hobbys für einen freien Nachmittag, kreative Ideen ohne große Anschaffung oder Beschäftigungen für schlechtes Wetter sein. Entscheidend ist nicht eine einzelne Hobbyart, sondern die Frage, welche Möglichkeiten zu einem bestimmten Wunsch passen.

Die Rubrik ist deshalb bewusst breiter als ein Hobby-Porträt. Sie soll neugierig machen und dir mehrere Wege zeigen. Wenn du anschließend ein konkretes Hobby genauer prüfen möchtest, führen die Beiträge zu den passenden Hobbyseiten oder ins Hobbyregister. Dort findest du die systematischen Informationen; hier geht es um Inspiration und die erste Idee.

Auch Gegensätze sind willkommen: etwas Ruhiges statt Bildschirmzeit, etwas Praktisches nach einem Bürotag oder ein Hobby, das bewusst keine große Vorbereitung braucht.',
                'terms' => [],
            ],
            'menschen-geschichten' => [
                'label' => 'Menschen & Geschichten',
                'asset' => 'hero-masters-v150684/naturbeobachtung.webp',
                'w' => 1389,
                'h' => 510,
                'claim' => 'Hobbys haben Gesichter.',
                'hero' => 'Persönliche Wege, besondere Projekte und die Menschen hinter ihren Hobbys.',
                'lead' => 'Hobbys bestehen nicht nur aus Material, Technik und Regeln. Oft sind es die Menschen dahinter, die ein Thema interessant machen: ihre Wege hinein, besondere Projekte, Sammlungen, Erfahrungen oder Gemeinschaften.',
                'more' => 'In dieser Rubrik stehen persönliche Geschichten im Vordergrund. Das kann jemand sein, der seit Jahrzehnten ein ungewöhnliches Sammelgebiet pflegt, eine Gruppe, die gemeinsam baut oder forscht, oder ein Mensch, der aus einer kleinen Freizeitidee ein außergewöhnliches Projekt entwickelt hat. Solche Beiträge dürfen subjektiv sein, solange klar bleibt, wessen Erfahrung erzählt wird.

Sachliche Grundlagen zu einem Hobby gehören weiterhin in den jeweiligen Fachbereich. Menschen & Geschichten ergänzt diese Informationen um Perspektiven, Motivation und gelebte Praxis. Dadurch wird sichtbar, wie unterschiedlich dasselbe Hobby aussehen kann und warum Menschen ganz verschiedene Dinge daran faszinieren.

Interviews, Reportagen und Erfahrungsstücke können dabei unterschiedliche Blickwinkel zeigen, ohne aus einer einzelnen persönlichen Erfahrung eine allgemeine Regel für alle zu machen. Auch Gemeinschaft, Austausch und die Rolle von Vereinen, Gruppen oder kleinen Szenen können Teil einer Geschichte sein.',
                'terms' => [],
            ],
            'neue-hobbys-trends' => [
                'label' => 'Neue Hobbys & Trends',
                'asset' => 'hero-masters-v150684/digitale-fertigung.webp',
                'w' => 1344,
                'h' => 494,
                'claim' => 'Was gerade neu entsteht.',
                'hero' => 'Neue Freizeitideen, technische Entwicklungen und Hobbys, die an Aufmerksamkeit gewinnen.',
                'lead' => 'Freizeit verändert sich. Neue Geräte, soziale Plattformen, Materialien und Ideen bringen Hobbys hervor, die vor wenigen Jahren kaum jemand kannte, während ältere Beschäftigungen plötzlich wieder populär werden.',
                'more' => 'Hier beobachten wir solche Entwicklungen: Was taucht neu auf? Welche Hobbys gewinnen sichtbar an Interesse? Welche Technik oder Szene sorgt dafür, dass sich eine Beschäftigung verändert? Ein Trend muss dabei nicht automatisch gut oder dauerhaft sein. Entscheidend ist, dass es einen nachvollziehbaren neuen Impuls gibt.

Die Rubrik unterscheidet sich von ungewöhnlichen Hobbys: Etwas kann sehr selten sein, ohne neu zu sein, und ein Trend kann vollkommen alltäglich wirken. Wenn aus einem Trend ein dauerhaft relevantes Hobby wird, bekommt es seinen Platz im normalen Hobbybestand. Bis dahin dient diese Rubrik dazu, Entwicklungen früh einzuordnen und interessante neue Richtungen sichtbar zu machen.

Wir schauen außerdem darauf, ob hinter einem Hype tatsächlich eine eigenständige Freizeitbeschäftigung steckt oder nur ein kurzfristiger Social-Media-Effekt ohne dauerhaften Hobbycharakter. So bleibt die Rubrik neugierig, ohne jede kurzfristige Mode sofort als neues Hobby zu behandeln.',
                'terms' => ['neu','trends'],
            ],
            'saison-drinnen-draussen' => [
                'label' => 'Saison, drinnen & draußen',
                'asset' => 'hero-masters-v150684/outdoor.webp',
                'w' => 1502,
                'h' => 552,
                'claim' => 'Passend zu Wetter und Jahreszeit.',
                'hero' => 'Hobbys für drinnen, draußen, Sommer, Winter und alles dazwischen.',
                'lead' => 'Nicht jedes Hobby passt zu jedem Wetter und jeder Jahreszeit. Manche Beschäftigungen leben vom Sommer, andere werden im Winter interessant, und viele lassen sich je nach Variante drinnen oder draußen ausüben.',
                'more' => 'Hier findest du Beiträge, die Hobbys nach Umgebung und Saison zusammenstellen. Dazu gehören Ideen für Regentage, Winterabende, warme Wochenenden oder Aktivitäten, für die du bewusst nach draußen möchtest. Wichtig ist dabei die praktische Frage: Welche Bedingungen braucht das Hobby wirklich und welche Alternativen gibt es, wenn Wetter oder Jahreszeit nicht mitspielen?

Die Einordnung ist eine redaktionelle Sicht auf bestehende Hobbys und keine eigene Hobbywelt. Ein konkretes Hobby bleibt an seiner normalen Stelle im Portal. Diese Rubrik hilft dir lediglich dabei, aus vielen Möglichkeiten diejenigen herauszufiltern, die zu Ort, Wetter und Jahreszeit passen.

Auch Übergänge sind interessant: Viele Outdoor-Hobbys haben Indoor-Trainingsformen, und manche Winterbeschäftigung lässt sich im Sommer mit anderen Schwerpunkten weiterführen. So bekommst du nicht nur saisonale Listen, sondern auch Hinweise darauf, wie flexibel ein Hobby tatsächlich ist.',
                'terms' => ['sommer','winter','draussen','zuhause'],
            ],
            'ungewoehnliche-skurrile-hobbys' => [
                'label' => 'Ungewöhnliche & skurrile Hobbys',
                'asset' => 'hero-masters-v150684/ameisen-insekten.webp',
                'w' => 1672,
                'h' => 614,
                'claim' => 'Anders kann richtig gut sein.',
                'hero' => 'Seltene, überraschende und herrlich spezielle Hobbys zum Entdecken.',
                'lead' => 'Es gibt Hobbys, bei denen man zweimal hinschaut – weil sie selten, überraschend oder einfach herrlich speziell sind. Genau solche Freizeitideen sammeln wir hier.',
                'more' => 'Ungewöhnlich bedeutet dabei nicht automatisch albern oder extrem. Manche Hobbys sind nur deshalb kaum bekannt, weil sie eine kleine Szene haben oder sehr spezielle Interessen verbinden. Andere sind tatsächlich skurril und leben gerade davon, dass sie mit üblichen Vorstellungen von Freizeit brechen. Entscheidend ist, dass es sich um eine echte Tätigkeit handelt und nicht nur um einen erfundenen Gag.

Kleine eigenständige Hobbys können hier zunächst über ein Hobby-Porträt vorgestellt werden. Im Hobbyregister bleiben sie trotzdem ganz normal auffindbar und vergleichbar. Wenn ein ungewöhnliches Hobby genügend fachliche Tiefe entwickelt, kann es zusätzlich eine eigene CORE-Seite bekommen. Diese Rubrik ist also vor allem die Bühne fürs Entdecken.

Dabei interessiert uns nicht nur der Überraschungseffekt, sondern auch, wie das Hobby praktisch funktioniert, welche Menschen es ausüben und was daran auf Dauer Spaß machen kann.',
                'terms' => ['ungewoehnlich','verrueckt'],
            ],
            'vergleiche-alternativen' => [
                'label' => 'Vergleiche & Alternativen',
                'asset' => 'hero-masters-v150684/spielzeug-spiele.webp',
                'w' => 1600,
                'h' => 587,
                'claim' => 'Was passt besser zu dir?',
                'hero' => 'Hobbys vergleichen, Unterschiede verstehen und passende Alternativen entdecken.',
                'lead' => 'Zwei Hobbys können auf den ersten Blick ähnlich wirken und im Alltag trotzdem völlig unterschiedlich sein. Hier vergleichen wir Freizeitideen miteinander und zeigen Alternativen, wenn ein Hobby grundsätzlich reizt, aber nicht ganz zu deinen Bedingungen passt.',
                'more' => 'Dabei geht es um Unterschiede wie Zeitbedarf, Kosten, Platz, körperliche Anforderungen, Lernkurve oder die Frage, ob du allein oder gemeinsam aktiv bist. Ein Vergleich soll dir helfen, eine Entscheidung zu treffen – nicht künstlich einen Sieger bestimmen. Oft ist die bessere Wahl einfach diejenige, die zu deinem Alltag und deinen Erwartungen passt.

Produktvergleiche innerhalb eines einzelnen Hobbys gehören nicht hierher, sondern in den jeweiligen Fachbereich. Diese Magazinrubrik vergleicht Hobbys, Hobbyarten oder sinnvolle Alternativen miteinander. Für die festen Merkmale einzelner Hobbys bleibt das Hobbyregister die einheitliche Datengrundlage.

Sinnvoll sind auch Alternativen innerhalb derselben Motivation: Wer etwas Kreatives sucht, braucht nicht zwingend Farbe; wer Bewegung möchte, muss nicht automatisch einen klassischen Sport wählen. Entscheidend ist immer der praktische Unterschied im Erleben und im Alltag.',
                'terms' => [],
            ],
            'wissen-glossar' => [
                'label' => 'Wissen & Glossar',
                'asset' => 'hero-masters-v150684/buch-papier.webp',
                'w' => 1433,
                'h' => 526,
                'claim' => 'Verstehen, was dahintersteckt.',
                'hero' => 'Begriffe, Methoden und Zusammenhänge verständlich erklärt und eingeordnet.',
                'lead' => 'Bei Hobbys begegnen dir ständig Begriffe, Methoden und Zusammenhänge, die nicht sofort verständlich sind. Hier greifen wir Themen auf, die über eine kurze Begriffsdefinition hinausgehen und etwas mehr Erklärung brauchen.',
                'more' => 'Ein Magazinbeitrag kann zum Beispiel erklären, warum eine bestimmte Technik funktioniert, wie sich Begriffe voneinander unterscheiden oder welcher Hintergrund hinter einer Methode steckt. Das eigentliche Glossar bleibt dagegen bewusst knapp: Dort wird ein einzelner Begriff eindeutig erklärt und mit passenden weiterführenden Inhalten verknüpft.

Die Grenze ist deshalb einfach: Glossar bedeutet nachschlagen, diese Rubrik bedeutet verstehen. Wenn ein Thema wiederum hauptsächlich zu einem konkreten Hobby gehört, liegt die ausführliche Fachinformation in dessen CORE-Bereich. Wissen & Glossar sammelt vor allem übergreifende Erklärungen und Hintergründe, die für mehrere Hobbys interessant sein können.

Typische Fragen sind etwa: Was unterscheidet zwei ähnliche Verfahren? Warum wird ein bestimmtes Material verwendet? Oder welche Grundidee steckt hinter einem Begriff, der in mehreren Hobbywelten auftaucht? Die Beiträge sollen solche Zusammenhänge verständlich erklären, ohne daraus ein zweites Lexikon zu machen.',
                'terms' => [],
            ],
            'zeit-budget-platz' => [
                'label' => 'Zeit, Budget & Platz',
                'asset' => 'hero-masters-v150684/mechanik-uhren.webp',
                'w' => 1672,
                'h' => 614,
                'claim' => 'Passend zu deinem Alltag.',
                'hero' => 'Hobbys nach Zeitaufwand, Kosten und verfügbarem Platz sinnvoll einordnen.',
                'lead' => 'Ein Hobby kann noch so spannend sein – wenn es nicht in deinen Alltag passt, bleibt es oft bei der Idee. Zeit, Kosten und verfügbarer Platz gehören deshalb zu den wichtigsten praktischen Kriterien bei der Auswahl.',
                'more' => 'Hier findest du Beiträge wie Hobbys für wenig Zeit, günstige Einstiegsideen oder Beschäftigungen, die auch in einer kleinen Wohnung funktionieren. Dabei geht es nicht um starre Grenzen, sondern um realistische Orientierung. Ein Hobby mit höherem Einstiegspreis kann durch Leihen trotzdem interessant sein, und ein eigentlich platzintensives Hobby lässt sich manchmal mit einer kompakten Variante beginnen.

Die festen Werte zu einzelnen Hobbys stammen aus dem Hobbyregister. Das Magazin nutzt diese Merkmale, um sinnvolle Gruppen und Alltagssituationen daraus zu machen. So entsteht keine zweite Datenwelt: Das Register beschreibt das einzelne Hobby, diese Rubrik hilft dir bei der Auswahl nach deinen Rahmenbedingungen.

Auch laufende Kosten, Aufbewahrung, Verbrauchsmaterial und die Länge einer typischen Einheit können wichtiger sein als der reine Anschaffungspreis oder die theoretisch benötigte Fläche.',
                'terms' => ['wenig-platz','wenig-zeit'],
            ],
        ];
    }

    private static function magazine_registry_page_node_v150720($page) {
        if (!$page instanceof WP_Post || !self::registry_ready()) { return null; }
        $node = hd_category_registry_find_node_by_object((int)$page->ID, 'page');
        if (!is_array($node)) { return null; }
        if ((string)($node['status'] ?? 'active') !== 'active') { return null; }
        if ((string)($node['pillar'] ?? '') !== 'editorial') { return null; }
        if ((string)($node['object_type'] ?? '') !== 'page') { return null; }
        return $node;
    }

    private static function magazine_registry_children_v150720($page) {
        $node = self::magazine_registry_page_node_v150720($page);
        if (!is_array($node)) { return []; }
        $children = hd_category_registry_children((string)$node['node_id'], 'editorial');
        if (!is_array($children)) { return []; }
        usort($children, static function($a,$b){
            $ao=(int)($a['nav_order'] ?? ($a['menu_order'] ?? 0));
            $bo=(int)($b['nav_order'] ?? ($b['menu_order'] ?? 0));
            if($ao!==$bo){return $ao<=>$bo;}
            return strnatcasecmp((string)($a['display_name'] ?? ''),(string)($b['display_name'] ?? ''));
        });
        return $children;
    }

    private static function magazine_items() {
        $defs = self::magazine_page_defs_v150719();
        $root = self::page_by_path(['magazin','journal']);
        $items = [];
        if ($root instanceof WP_Post && self::registry_ready()) {
            foreach (self::magazine_registry_children_v150720($root) as $node) {
                if ((string)($node['object_type'] ?? '') !== 'page') { continue; }
                $obj = hd_category_registry_resolve((string)($node['node_id'] ?? ''));
                if (!$obj instanceof WP_Post || $obj->post_status !== 'publish') { continue; }
                $slug = sanitize_title((string)$obj->post_name);
                if (!isset($defs[$slug])) { continue; }
                $items[] = [
                    'slug'=>$slug,
                    'label'=>(string)($defs[$slug]['label'] ?? get_the_title($obj)),
                    'url'=>(string)get_permalink($obj),
                    'asset'=>(string)($defs[$slug]['asset'] ?? ''),
                    'page_id'=>(int)$obj->ID,
                ];
            }
        }
        if ($items) { return $items; }

        // Standalone/fallback preview only: resolve the exact 12 existing page slugs.
        foreach ($defs as $slug => $def) {
            $page = self::page_by_path(['magazin/' . $slug, 'journal/' . $slug, $slug]);
            if (!$page instanceof WP_Post) { continue; }
            $items[] = [
                'slug' => $slug,
                'label' => (string)($def['label'] ?? get_the_title($page)),
                'url' => (string)get_permalink($page),
                'asset' => (string)($def['asset'] ?? ''),
                'page_id' => (int)$page->ID,
            ];
        }
        return $items;
    }

    private static function magazine_page_def_v150719($page) {
        if (!$page instanceof WP_Post || $page->post_type !== 'page') { return null; }
        $slug = sanitize_title((string)$page->post_name);
        $defs = self::magazine_page_defs_v150719();
        if (!isset($defs[$slug]) || !is_array($defs[$slug])) { return null; }
        $def = $defs[$slug];
        $def['slug'] = $slug;
        return $def;
    }

    private static function magazine_request_slug_v150722() {
        $uri = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '';
        if ($uri === '') { return ''; }
        $path = function_exists('wp_parse_url') ? wp_parse_url($uri, PHP_URL_PATH) : parse_url($uri, PHP_URL_PATH);
        if (!is_string($path) || $path === '') { return ''; }
        $decoded = rawurldecode($path);
        $parts = array_values(array_filter(explode('/', trim($decoded, '/')), static function($v){ return $v !== ''; }));
        $count = count($parts);
        if ($count < 2) { return ''; }
        $parent = sanitize_title((string)$parts[$count - 2]);
        $slug = sanitize_title((string)$parts[$count - 1]);
        if (!in_array($parent, ['magazin','journal'], true)) { return ''; }
        $defs = self::magazine_page_defs_v150719();
        return isset($defs[$slug]) ? $slug : '';
    }

    private static function magazine_page_by_slug_v150722($slug) {
        $slug = sanitize_title((string)$slug);
        if ($slug === '') { return null; }
        $page = self::page_by_path(['magazin/' . $slug, 'journal/' . $slug, $slug]);
        return $page instanceof WP_Post ? $page : null;
    }

    private static function is_magazine_target_page_v150719($page = null) {
        if (!$page instanceof WP_Post) {
            $page = function_exists('get_queried_object') ? get_queried_object() : null;
        }
        if (!$page instanceof WP_Post || $page->post_type !== 'page') { return false; }
        if (is_array(self::magazine_page_def_v150719($page))) { return true; }
        // Registry fallback: existing editorial child pages remain owned even if a future
        // permalink/slug adjustment occurs. No second structure is created.
        $node = self::magazine_registry_page_node_v150720($page);
        if (!is_array($node)) { return false; }
        $node_id = (string)($node['node_id'] ?? '');
        return $node_id !== '' && $node_id !== 'editorial:hub' && strpos($node_id, 'editorial:') === 0;
    }

    public static function render_magazine_content_fallback_v150721($content) {
        if (is_admin()) { return $content; }
        if (function_exists('in_the_loop') && !in_the_loop()) { return $content; }
        if (function_exists('is_main_query') && !is_main_query()) { return $content; }

        // 1.50.722: hard fallback for the 12 real /magazin/<slug>/ target URLs.
        // This does not depend on WordPress classifying the request as our editorial page.
        $request_slug = self::magazine_request_slug_v150722();
        if ($request_slug !== '') {
            $page = self::magazine_page_by_slug_v150722($request_slug);
            $rendered = self::render_magazine_target_by_slug_v150722($request_slug, $page);
            return $rendered !== '' ? $rendered : $content;
        }

        if (!function_exists('is_singular') || !is_singular('page')) { return $content; }
        $page = function_exists('get_queried_object') ? get_queried_object() : null;
        if (!$page instanceof WP_Post) { return $content; }
        if (self::is_magazine_root_page_v150717($page)) { return self::render_magazine_root_v150719($page); }
        if (self::is_magazine_target_page_v150719($page)) {
            $rendered = self::render_magazine_target_v150719($page);
            return $rendered !== '' ? $rendered : $content;
        }
        return $content;
    }

    private static function provider_items() {
        if (!taxonomy_exists('hp_listing_category')) { return []; }
        $names = ['Kurse & Workshops','Trainer & Coaches','Vereine & Gruppen','Werkstätten & Studios','Fachgeschäfte','Verleih','Reparatur & Service','Events & Reisen'];
        $items = [];
        foreach ($names as $name) {
            $term = get_term_by('name', $name, 'hp_listing_category');
            if (!$term instanceof WP_Term) { continue; }
            $url = get_term_link($term);
            if (!is_wp_error($url)) { $items[] = ['label' => $term->name, 'url' => $url]; }
        }
        return $items;
    }

    private static function mega_menu_visible_count($worlds) {
        // 1.50.670: Desktop-Mega-Menü zeigt bis zu zwei volle Reihen direkt.
        // Bei 5 Spalten sind das 10 echte Zwischenbereiche. Erst ab dem 11.
        // Bereich greift weiterhin der bestehende "Mehr Kategorien"-Mechanismus.
        // Keine Strukturänderung: ausschließlich Darstellungsgrenze.
        return 10;
    }

    private static function mega_menu_child_links($page, $limit = 4) {
        if (!$page instanceof WP_Post) { return []; }
        $items = [];
        $children = self::direct_page_children($page->ID);
        if ($children) {
            foreach ($children as $child) {
                if (!$child instanceof WP_Post) { continue; }
                $items[] = ['label'=>get_the_title($child), 'url'=>get_permalink($child)];
            }
        } else {
            foreach (self::direct_category_children_for_page($page) as $term) {
                if (!$term instanceof WP_Term) { continue; }
                $url = get_term_link($term);
                if (!is_wp_error($url)) { $items[] = ['label'=>$term->name, 'url'=>$url]; }
            }
        }
        $total = count($items);
        return ['items'=>array_slice($items, 0, max(0, (int)$limit)), 'total'=>$total];
    }

    private static function mega_menu_world($world, $visible_limit = 0) {
        if (!is_array($world) || empty($world['children']) || !is_array($world['children'])) { return ''; }
        $children = array_values(array_filter($world['children'], static function($child){ return $child instanceof WP_Post; }));
        if (!$children) { return ''; }
        $count = count($children);
        $limit = $visible_limit > 0 ? min($count, absint($visible_limit)) : $count;
        $html = '<div class="hd-mega hd-mega-reference" aria-label="' . esc_attr($world['title']) . '">';
        $html .= '<div class="hd-mega-head hd-mega-reference-head"><strong>' . esc_html($world['title']) . '</strong></div>';
        $html .= '<div class="hd-mega-columns" data-visible-count="'.intval($limit).'">';
        foreach ($children as $index => $child) {
            $extra = $index >= $limit ? ' is-extra' : '';
            $sub = self::mega_menu_child_links($child, 4);
            $html .= '<section class="hd-mega-column'.$extra.'">';
            $html .= '<a class="hd-mega-primary" href="'.esc_url(get_permalink($child)).'">'.esc_html(get_the_title($child)).'</a>';
            if (!empty($sub['items'])) {
                $html .= '<ul class="hd-mega-secondary">';
                foreach ($sub['items'] as $item) {
                    $html .= '<li><a href="'.esc_url($item['url']).'">'.esc_html($item['label']).'</a></li>';
                }
                if ((int)$sub['total'] > count($sub['items'])) {
                    $html .= '<li class="hd-mega-secondary-all"><a href="'.esc_url(get_permalink($child)).'">Alle Themen →</a></li>';
                }
                $html .= '</ul>';
            }
            $html .= '</section>';
        }
        $html .= '</div>';
        if ($count > $limit) {
            $html .= '<button class="hd-mega-more-toggle" type="button" aria-expanded="false"><span>Mehr Kategorien</span><b aria-hidden="true">＋</b></button>';
        } else {
            $html .= '<a class="hd-mega-all" href="'.esc_url($world['url']).'">Alle Kategorien <b>→</b></a>';
        }
        $html .= '</div>';
        return $html;
    }

    private static function mega_menu_list($items, $label) {
        if (!$items) { return ''; }
        $html = '<div class="hd-mega hd-mega-list" aria-label="' . esc_attr($label) . '"><ul>';
        foreach ($items as $item) { $html .= '<li><a href="' . esc_url($item['url']) . '">' . esc_html($item['label']) . '</a></li>'; }
        return $html . '</ul></div>';
    }

    public static function suppress_theme_template_parts($content, $block) {
        if (is_admin() || !is_array($block) || ($block['blockName'] ?? '') !== 'core/template-part') { return $content; }
        $slug = isset($block['attrs']['slug']) ? sanitize_key((string)$block['attrs']['slug']) : '';
        if ($slug === 'header' || $slug === 'footer') { return ''; }
        return $content;
    }

    private static function is_core_page_id($page_id) {
        return in_array(self::affiliate_page_type(absint($page_id)), ['hub1','hub2','category','leaf'], true);
    }

    private static function is_hobbyfinder_page($page = null) {
        if (!$page instanceof WP_Post) {
            $page = function_exists('get_queried_object') ? get_queried_object() : null;
        }
        if (!$page instanceof WP_Post || $page->post_type !== 'page') { return false; }
        return sanitize_title((string)$page->post_name) === 'hobbyfinder';
    }

    private static function is_magazine_root_page_v150717($page = null) {
        if (!$page instanceof WP_Post) {
            $page = function_exists('get_queried_object') ? get_queried_object() : null;
        }
        if (!$page instanceof WP_Post || $page->post_type !== 'page') { return false; }
        return in_array(sanitize_title((string)$page->post_name), ['journal','magazin'], true);
    }

    private static function is_owned_content_route() {
        if (is_admin() || (function_exists('is_front_page') && is_front_page())) { return false; }
        // 1.50.722: the 12 magazine target URLs are owned by HD-003 even if another
        // component changes the queried-object classification before template_include.
        if (self::magazine_request_slug_v150722() !== '') { return true; }
        if (function_exists('is_singular') && is_singular('page')) {
            $page = function_exists('get_queried_object') ? get_queried_object() : null;
            if ($page instanceof WP_Post && sanitize_title((string)$page->post_name) === 'agb-2') { return false; }
            if (self::is_magazine_root_page_v150717($page) || self::is_magazine_target_page_v150719($page) || self::is_hobbyfinder_page($page)) { return true; }
            return self::is_core_page_id(get_queried_object_id());
        }
        if (function_exists('is_category') && is_category()) { return true; }
        if (function_exists('is_tax') && is_tax('journal_cat')) { return true; }
        return false;
    }


    /**
     * 1.50.702: Footer-/Service-Seiten sind normale WordPress-Seiten.
     * Sie muessen ihren importierten Inhalt 1:1 zeigen und duerfen NICHT
     * zusaetzlich durch den generischen Hobby-Depot-Intro-/"Mehr erfahren"-
     * Renderer laufen. Sonst erscheint der Seiteninhalt doppelt.
     */
    private static function is_plain_service_page($page = null) {
        if (!$page instanceof WP_Post) {
            $page = function_exists('get_queried_object') ? get_queried_object() : null;
        }
        if (!$page instanceof WP_Post || $page->post_type !== 'page') { return false; }
        $slug = sanitize_title((string)$page->post_name);
        return in_array($slug, [
            'werben', 'werbung', 'werbung-im-hobby-depot', 'preise', 'kontakt', 'faq',
            'impressum', 'agb', 'agb-2', 'disclaimer', 'datenschutz', 'werbebedingungen', 'werb-anzeigebedingungen',
            'anzeigenmarkt'
        ], true);
    }

    private static function is_main_search_results_request_v150734() {
        if (is_admin()) { return false; }
        $marker = isset($_GET['hd_header_search']) ? sanitize_text_field(wp_unslash((string)$_GET['hd_header_search'])) : '';
        if ($marker !== '1') { return false; }
        $search = isset($_GET['s']) ? trim(sanitize_text_field(wp_unslash((string)$_GET['s']))) : '';
        if (function_exists('mb_substr')) { $search = mb_substr($search, 0, 80); }
        else { $search = substr($search, 0, 80); }
        return $search !== '';
    }

    public static function route_template($template) {
        if (is_admin()) { return $template; }
        // 1.50.735: Die Hobby-Depot-Hauptsuche gehoert uns, sobald unser eigener
        // Formularmarker plus Suchbegriff im Request stehen. Nicht mehr von
        // WordPress/ListingHive-is_search() abhaengig, damit auch Teilbegriffe wie
        // "Holz" sicher auf dieselbe Vier-Bereiche-Ergebnisseite wie das AJAX-Flyout gehen.
        if (self::is_main_search_results_request_v150734()) {
            $owned = dirname(__DIR__) . '/templates/hobby-depot-search-v150732.php';
            return is_readable($owned) ? $owned : $template;
        }
        if (function_exists('is_front_page') && is_front_page()) {
            $owned = dirname(__DIR__) . '/templates/hobby-depot-front-v150709.php';
            return is_readable($owned) ? $owned : $template;
        }
        if (self::is_owned_content_route()) {
            $owned = dirname(__DIR__) . '/templates/hobby-depot-content-v150709.php';
            return is_readable($owned) ? $owned : $template;
        }
        return $template;
    }

    private static function main_search_normalize_v150732($value) {
        $value = trim(wp_strip_all_tags((string)$value));
        if (function_exists('remove_accents')) { $value = remove_accents($value); }
        $value = strtolower($value);
        $value = preg_replace('/[^a-z0-9]+/u', ' ', $value);
        return trim(preg_replace('/\s+/u', ' ', (string)$value));
    }

    private static function main_search_match_score_v150732($query, $candidate) {
        $q = self::main_search_normalize_v150732($query);
        $c = self::main_search_normalize_v150732($candidate);
        if ($q === '' || $c === '') { return 0; }
        if ($c === $q) { return 500; }
        if (strpos($c, $q) === 0) { return 400; }
        if (strpos($c, $q) !== false) { return 300; }
        $tokens = array_values(array_filter(explode(' ', $q), static function($v){ return strlen($v) >= 2; }));
        if (!$tokens) { return 0; }
        $hits = 0;
        foreach ($tokens as $token) { if (strpos($c, $token) !== false) { $hits++; } }
        if ($hits !== count($tokens)) { return 0; }
        return 180 + ($hits * 10);
    }

    /**
     * 1.50.767: The search index is the complete hobby register, not the page tree.
     * A missing or unpublished detail page may NOT delete a legitimate search hit.
     * Resolve URLs only for ranked results to keep AJAX responsive on broad terms.
     */
    private static function main_search_hobbies_v150732($search, $limit=5) {
        if (!function_exists('hd_hobbyregister_records') || !function_exists('hd_hobbyregister_ready') || !hd_hobbyregister_ready()) { return []; }
        $limit = max(1, min(50, (int)$limit));
        $found = [];
        foreach ((array)hd_hobbyregister_records() as $row) {
            if (!is_array($row)) { continue; }
            $name = trim((string)($row['canonical_name'] ?? ''));
            if ($name === '') { continue; }
            $best = self::main_search_match_score_v150732($search, $name);
            foreach ((array)($row['aliases'] ?? []) as $alias) {
                $best = max($best, self::main_search_match_score_v150732($search, (string)$alias));
            }
            if ($best <= 0) { continue; }
            $found[] = ['title'=>$name,'score'=>$best,'identity'=>(array)($row['source_identity'] ?? [])];
        }
        usort($found, static function($a,$b){
            $cmp = ((int)$b['score']) <=> ((int)$a['score']);
            return $cmp !== 0 ? $cmp : strcasecmp((string)$a['title'], (string)$b['title']);
        });
        $out=[]; $seen=[];
        foreach ($found as $item) {
            $name = (string)$item['title'];
            $key = self::main_search_normalize_v150732($name);
            if ($key === '' || isset($seen[$key])) { continue; }
            $seen[$key]=true;
            // The register row itself is the evidence for its EXISTING HD007
            // hobby detail page. It is a virtual route, not a WP_Post or term.
            // 1.50.766/767 failed to search this target type and falsely said
            // 'noch keine eigene Seite' even with /hobbyregister/anthotypie/ open.
            $url=self::hobbyregister_detail_url_v150768($name);
            if ($url === '') {
                $source=$item['identity'];
                $target=self::hobbyfinder_target_v150705([
                    'name'=>$name,
                    'target_node_id'=>(string)($source['target_node_id'] ?? ''),
                    'world'=>(string)($source['natural_world'] ?? ''),
                ]);
                $url=trim((string)($target['url'] ?? ''));
                if ($url === '') { $url=self::main_search_exact_title_url_v150767($name); }
            }
            // The matched hobby stays visible regardless of URL resolution.
            $out[]=['title'=>$name,'url'=>$url];
            if (count($out) >= $limit) { break; }
        }
        return $out;
    }

    /** Only a published WordPress target with an exact visible title qualifies. */
    private static function main_search_exact_title_url_v150767($name) {
        if (!function_exists('get_posts') || !function_exists('get_the_title')) { return ''; }
        $expected=self::main_search_normalize_v150732($name);
        if ($expected === '') { return ''; }
        foreach (['page','hdg_term'] as $type) {
            if (function_exists('post_type_exists') && !post_type_exists($type)) { continue; }
            $posts=get_posts([
                'post_type'=>$type, 'post_status'=>'publish','s'=>$name,
                'posts_per_page'=>25,'no_found_rows'=>true,'suppress_filters'=>true,
            ]);
            foreach ((array)$posts as $post) {
                if (!$post instanceof WP_Post || (string)$post->post_status !== 'publish'
                    || (string)$post->post_type !== $type) { continue; }
                if (self::main_search_normalize_v150732(get_the_title($post)) !== $expected) { continue; }
                $url=(string)get_permalink($post);
                if (trim($url) !== '') { return $url; }
            }
        }
        return '';
    }

    private static function main_search_posts_v150732($search, $post_type, $limit=5, $journal_only=false) {
        $limit = max(1, min(100, (int)$limit));
        if (!function_exists('post_type_exists') || !post_type_exists($post_type)) { return []; }
        $args = [
            'post_type'=>$post_type,'post_status'=>'publish','posts_per_page'=>$limit,
            's'=>$search,'orderby'=>'relevance','order'=>'DESC','no_found_rows'=>true,
        ];
        if ($journal_only) {
            if (!taxonomy_exists('journal_cat') || !is_object_in_taxonomy($post_type,'journal_cat')) { return []; }
            $args['tax_query'] = [['taxonomy'=>'journal_cat','operator'=>'EXISTS']];
        }
        $out=[];
        foreach ((array)get_posts($args) as $post) {
            if (!$post instanceof WP_Post) { continue; }
            $url=(string)get_permalink($post); $title=trim((string)get_the_title($post));
            if ($url==='' || $title==='') { continue; }
            $out[]=['title'=>$title,'url'=>$url];
        }
        return $out;
    }

    private static function main_search_ads_v150732($search, $limit=5) {
        $limit = max(1,min(100,(int)$limit));
        $out=[]; $seen=[];
        $append=static function($title,$url) use (&$out,&$seen,$limit){
            $title=trim(wp_strip_all_tags((string)$title)); $url=trim((string)$url);
            if ($title==='' || $url==='' || count($out)>=$limit) { return; }
            $key=strtolower(rtrim($url,'/')); if(isset($seen[$key])) return;
            $seen[$key]=true; $out[]=['title'=>$title,'url'=>$url];
        };
        if (taxonomy_exists('hp_listing_category')) {
            $terms=get_terms(['taxonomy'=>'hp_listing_category','hide_empty'=>false,'search'=>$search,'number'=>$limit]);
            if (!is_wp_error($terms)) foreach ((array)$terms as $term) {
                if (!$term instanceof WP_Term) continue; $url=get_term_link($term);
                if (!is_wp_error($url)) $append($term->name,$url);
            }
        }
        if (count($out)<$limit && post_type_exists('hp_listing')) {
            foreach (self::main_search_posts_v150732($search,'hp_listing',$limit-count($out),false) as $item) $append($item['title'],$item['url']);
        }
        return $out;
    }

    /**
     * 1.50.788: one existing search, a fifth Fachwissen group.
     * Only real, published WordPress Fachartikel and real category terms.
     * Published journal_cat posts stay exclusively in Magazin.
     * Search uses WordPress's native title/content/excerpt index – no new table.
     */
    private static function main_search_subjects_v150788($search, $limit=5) {
        $limit=max(1,min(100,(int)$limit));
        $out=[]; $seen=[];
        $append=static function($title,$url,$kind,$score) use (&$out,&$seen) {
            $title=trim(wp_strip_all_tags((string)$title));
            $url=trim((string)$url);
            if ($title==='' || $url==='') { return; }
            $key=rtrim($url,'/');
            if (isset($seen[$key])) { return; }
            $seen[$key]=true;
            $out[]=['title'=>$title,'url'=>$url,'kind'=>$kind,'score'=>(int)$score];
        };
        // Fachkategorien sind vorhandene WordPress-Content-Kategorien,
        // nicht das separate Hobbyregister und nicht das HivePress-Verzeichnis.
        if (function_exists('taxonomy_exists') && taxonomy_exists('category') && function_exists('get_terms')) {
            $terms=get_terms(['taxonomy'=>'category','hide_empty'=>false,'search'=>$search,'number'=>max(10,min(100,$limit*2))]);
            if (!is_wp_error($terms)) foreach ((array)$terms as $term) {
                if (!$term instanceof WP_Term) { continue; }
                if (self::main_search_match_score_v150732($search,$term->name.' '.(string)$term->slug) <= 0) { continue; }
                $url=get_term_link($term);
                if (is_wp_error($url)) { continue; }
                $append($term->name,$url,'Fachkategorie',
                    self::main_search_match_score_v150732($search,$term->name)+25);
            }
        }
        // CORE-Bereichsseiten im oberen Kategoriebaum sind WordPress-Seiten.
        // Nur die belegte HD-004-Registry darf bestimmen, ob sie dazugehoeren.
        if (function_exists('hd_category_registry_ready') && function_exists('hd_category_registry_find_node_by_object')
            && hd_category_registry_ready() && function_exists('get_posts')) {
            $pages=get_posts(['post_type'=>'page','post_status'=>'publish',
                'posts_per_page'=>max(10,min(100,$limit*2)),'s'=>$search,
                'orderby'=>'relevance','no_found_rows'=>true,'ignore_sticky_posts'=>true]);
            foreach ((array)$pages as $page) {
                if (!$page instanceof WP_Post || $page->post_status!=='publish') { continue; }
                $node=hd_category_registry_find_node_by_object((int)$page->ID,'page');
                if (!is_array($node) || (string)($node['pillar'] ?? '')!=='core'
                    || (string)($node['status'] ?? 'active')!=='active') { continue; }
                $title=(string)get_the_title($page);
                $append($title,get_permalink($page),'Fachbereich',
                    self::main_search_match_score_v150732($search,$title)+40);
            }
        }
        // WP-Standardsuche findet Titel, Auszug und Inhalt, also auch "Zweileiner"
        // mitten im Text. Ein schon veröffentlichter Design-Testartikel zählt mit.
        if (function_exists('post_type_exists') && post_type_exists('post') && function_exists('get_posts')) {
            $args=['post_type'=>'post','post_status'=>'publish','posts_per_page'=>$limit,
                's'=>$search,'orderby'=>'relevance','order'=>'DESC','no_found_rows'=>true,
                'ignore_sticky_posts'=>true,'suppress_filters'=>false];
            if (function_exists('taxonomy_exists') && taxonomy_exists('journal_cat')
                && function_exists('is_object_in_taxonomy') && is_object_in_taxonomy('post','journal_cat')) {
                $args['tax_query']=[['taxonomy'=>'journal_cat','operator'=>'NOT EXISTS']];
            }
            foreach ((array)get_posts($args) as $post) {
                if (!$post instanceof WP_Post || $post->post_status!=='publish') { continue; }
                $title=trim((string)get_the_title($post));
                $url=get_permalink($post);
                $append($title,$url,'Fachartikel',
                    self::main_search_match_score_v150732($search,$title)+80);
            }
        }
        usort($out,static function($a,$b) {
            $score=((int)$b['score'])<=>((int)$a['score']);
            return $score!==0 ? $score : strcasecmp((string)$a['title'],(string)$b['title']);
        });
        return array_slice($out,0,$limit);
    }

    private static function main_search_groups_v150732($search, $limit=5) {
        $search = trim(sanitize_text_field((string)$search));
        if (function_exists('mb_substr')) { $search = mb_substr($search,0,80); } else { $search = substr($search,0,80); }
        $len = function_exists('mb_strlen') ? mb_strlen($search,'UTF-8') : strlen($search);
        if ($len < 2) { return ['hobbies'=>[],'subjects'=>[],'magazine'=>[],'glossary'=>[],'ads'=>[]]; }
        return [
            'hobbies'=>self::main_search_hobbies_v150732($search,$limit),
            'subjects'=>self::main_search_subjects_v150788($search,$limit),
            'magazine'=>self::main_search_posts_v150732($search,'post',$limit,true),
            'glossary'=>self::main_search_posts_v150732($search,'hdg_term',$limit,false),
            'ads'=>self::main_search_ads_v150732($search,$limit),
        ];
    }

    private static function main_search_group_html_v150732($items,$label,$slug) {
        $html='<section class="hd-main-search-group-v150732" data-hd-search-group="'.esc_attr($slug).'"><div class="hd-main-search-label-v150732">'.esc_html($label).'</div>';
        if (!$items) { return $html.'<div class="hd-main-search-empty-v150732">Keine Treffer</div></section>'; }
        foreach ((array)$items as $item) {
            $url=trim((string)($item['url'] ?? ''));
            if ($url !== '') {
                $kind=isset($item['kind']) ? '<small class="hd-search-kind-v150788">'.esc_html((string)$item['kind']).'</small>' : '';
                $html.='<a class="hd-main-search-result-v150732" href="'.esc_url($url).'">'.esc_html((string)$item['title']).$kind.'</a>';
            } else {
                $html.='<span class="hd-main-search-result-v150732 hd-main-search-no-target-v150767" title="Hobbytreffer ohne auflösbaren Link">'.esc_html((string)$item['title']).'</span>';
            }
        }
        return $html.'</section>';
    }

    public static function main_search_html_v150732($search,$limit=5) {
        $groups=self::main_search_groups_v150732($search,$limit);
        $html='<div class="hd-main-search-shell-v150732" role="listbox"><div class="hd-main-search-grid-v150732">';
        $html.=self::main_search_group_html_v150732($groups['hobbies'],'HOBBYS','hobbys');
        $html.=self::main_search_group_html_v150732($groups['subjects'],'FACHWISSEN','fachwissen');
        $html.=self::main_search_group_html_v150732($groups['magazine'],'MAGAZIN','magazin');
        $html.=self::main_search_group_html_v150732($groups['glossary'],'GLOSSAR','glossar');
        $html.=self::main_search_group_html_v150732($groups['ads'],'ANZEIGEN','anzeigen');
        $has=false; foreach($groups as $items){ if($items){$has=true;break;} }
        if ($has) {
            $url=add_query_arg(['s'=>trim((string)$search),'hd_header_search'=>'1'],home_url('/'));
            $html.='<a class="hd-main-search-all-v150732" href="'.esc_url($url).'">Alle Suchergebnisse anzeigen</a>';
        }
        return $html.'</div></div>';
    }

    public static function main_search_ajax_v150732() {
        if (function_exists('check_ajax_referer')) { check_ajax_referer('hd_main_search_v150732','nonce'); }
        $search=isset($_REQUEST['q']) ? sanitize_text_field(wp_unslash((string)$_REQUEST['q'])) : '';
        wp_send_json_success(['html'=>self::main_search_html_v150732($search,5)]);
    }

    /**
     * 1.50.789: result page is initially compact; each 'Mehr anzeigen'
     * reveals five more from the already bounded same native search results.
     * Header AJAX remains exactly as it was. No duplicate search index.
     */
    private static function render_search_page_group_v150732($items,$label,$slug) {
        $count=count((array)$items);
        // Empty groups add no long stacks of repeated 'Keine Treffer' boxes.
        $html='<section class="hd-search-page-group-v150732 hd-search-page-group-compact-v150789 hd-search-page-'.esc_attr($slug).'-v150732" data-hd-result-section="'.esc_attr($slug).'">'
           . '<div class="hd-search-group-header-v150789"><h2>'.esc_html($label).'</h2><span class="hd-search-total-v150789">'.esc_html((string)$count).($count>=50?'+':'').' Treffer</span></div>';
        if (!$items) { return $html.'<p class="hd-search-page-empty-v150732">Keine Treffer</p></section>'; }
        $html.='<div class="hd-search-page-list-v150732" id="hd-results-'.esc_attr($slug).'-v150789">';
        foreach ((array)$items as $i=>$item) {
            $hidden=$i>=5 ? ' hidden data-hd-search-hidden="1"' : '';
            $url=trim((string)($item['url'] ?? ''));
            if ($url !== '') {
                $kind=isset($item['kind']) ? '<small class="hd-search-kind-v150788">'.esc_html((string)$item['kind']).'</small>' : '';
                $html.='<a'. $hidden .' href="'.esc_url($url).'"><span>'.esc_html((string)$item['title']).$kind.'</span><b aria-hidden="true">→</b></a>';
            } else {
                $html.='<span'. $hidden .' class="hd-search-page-no-target-v150767">'.esc_html((string)$item['title']).'</span>';
            }
        }
        $html.='</div>';
        if ($count>5) {
            $next=min(5,$count-5);
            $html.='<button type="button" class="hd-search-more-v150789" data-hd-search-more="1" aria-controls="hd-results-'.esc_attr($slug).'-v150789" aria-expanded="false">'
                  .'Mehr anzeigen <small>('.esc_html((string)$next).' weitere)</small></button>';
        }
        return $html.'</section>';
    }

    public static function render_search_results_page_v150732() {
        $search = isset($_GET['s']) ? trim(sanitize_text_field(wp_unslash((string)$_GET['s']))) : trim((string)get_search_query());
        if (function_exists('mb_substr')) { $search = mb_substr($search, 0, 80); }
        else { $search = substr($search, 0, 80); }
        $groups=self::main_search_groups_v150732($search,50);
        $total=0; foreach($groups as $group){$total+=count((array)$group);}
        $html='<main class="hd-content-v150616 hd-search-page-v150732 hd-search-page-compact-v150789">'
             .'<section class="hd-search-page-head-v150732"><span>PORTALSUCHE</span>'
             .'<h1>Suchergebnisse für „'.esc_html($search).'“</h1>'
             .'<p>Fünf getrennte Bereiche. Zunächst fünf Treffer pro Bereich – weitere Ergebnisse nur auf Wunsch.</p></section>';
        if ($total===0) { return $html.'<p class="hd-search-page-no-results-v150789">Keine passenden Treffer gefunden. Probiere einen genaueren oder verwandten Suchbegriff.</p></main>'; }
        $html.='<div class="hd-search-page-grid-v150732">';
        $html.=self::render_search_page_group_v150732($groups['hobbies'],'Hobbys','hobbys');
        $html.=self::render_search_page_group_v150732($groups['subjects'],'Fachwissen','fachwissen');
        $html.=self::render_search_page_group_v150732($groups['magazine'],'Magazin','magazin');
        $html.=self::render_search_page_group_v150732($groups['glossary'],'Glossar','glossar');
        $html.=self::render_search_page_group_v150732($groups['ads'],'Anzeigen','anzeigen');
        return $html.'</div><p class="hd-search-page-limit-v150789">Pro Bereich werden maximal 50 passende Treffer berücksichtigt. Für weitere Ergebnisse bitte genauer suchen.</p></main>';
    }

    public static function render_header() {
        if (is_admin() || self::$header_rendered) { return; }
        self::$header_rendered = true;
        $worlds = self::worlds();
        $mega_visible_count = self::mega_menu_visible_count($worlds);
        echo '<header class="hd-header-v150616" data-hd-release="1.50.645" aria-label="Hobby Depot Hauptnavigation">';
        echo '<div class="hd-topbar-v150616"><div><span>Inspiration, Wissen &amp; Empfehlungen rund ums Hobby.</span></div></div>';
        $logo_url = esc_url(self::logo_url());
        echo '<div class="hd-head-v150616"><a class="hd-logo-v150616 hd-logo-composed-v150622" href="' . esc_url(home_url('/')) . '" aria-label="dein Hobby Depot – Startseite"><span class="hd-logo-parts-v150622" aria-hidden="true"><span class="hd-logo-mark-v150622" style="--hd-logo-image:url(&quot;' . $logo_url . '&quot;)"></span><span class="hd-logo-word-v150622" style="--hd-logo-image:url(&quot;' . $logo_url . '&quot;)"></span><span class="hd-logo-claim-v150622" style="--hd-logo-image:url(&quot;' . $logo_url . '&quot;)"></span></span><img class="hd-logo-full-v150622" src="' . $logo_url . '" alt="" aria-hidden="true" width="250" height="138"><span class="screen-reader-text">dein Hobby Depot – Hobbys. Ideen. Möglichkeiten.</span></a>';
        echo '<div class="hd-head-center-v150616"><form class="hd-search-v150616" role="search" method="get" action="' . esc_url(home_url('/')) . '" data-hd-search-ajax="' . esc_url(admin_url('admin-ajax.php')) . '" data-hd-search-nonce="' . esc_attr(wp_create_nonce('hd_main_search_v150732')) . '"><label class="screen-reader-text" for="hd-search-field-v150616">Suche</label><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.6"/><path d="m16 16 4 4"/></svg><input id="hd-search-field-v150616" type="search" name="s" value="' . esc_attr(get_search_query()) . '" placeholder="Nach Hobbys, Projekten oder Themen suchen …" autocomplete="off" aria-autocomplete="list" aria-expanded="false" aria-controls="hd-main-search-results-v150732"><input type="hidden" name="hd_header_search" value="1"><div id="hd-main-search-results-v150732" class="hd-main-search-results-v150732" aria-live="polite"></div></form>';
        echo '<nav id="hd-nav-v150616" class="hd-nav-v150616" aria-label="Hobbywelten"><ul>';
        foreach ($worlds as $world) {
            $mega = self::mega_menu_world($world, $mega_visible_count);
            $has = $mega !== '';
            $accent = self::world_accent($world['slug']);
            echo '<li class="hd-nav-item hd-world-' . esc_attr($world['slug']) . ' ' . ($has ? 'has-mega' : '') . '" style="--hd-world-accent:' . esc_attr($accent) . '"><a href="' . esc_url($world['url']) . '"><span class="hd-nav-world-label">' . esc_html($world['title']) . '</span></a>';
            if ($has) { echo '<button class="hd-sub-toggle-v150616" type="button" aria-expanded="false" aria-label="' . esc_attr($world['title'] . ' öffnen') . '"><span aria-hidden="true"></span></button>' . $mega; }
            echo '</li>';
        }
        echo '</ul></nav></div>';
        echo '<button class="hd-menu-toggle-v150616" type="button" aria-expanded="false" aria-controls="hd-nav-v150616"><span></span><span></span><span></span><b class="screen-reader-text">Menü öffnen</b></button></div></header>';
    }

    public static function render_header_js() {
        if (is_admin()) { return; }
        ?>
<script id="hd-header-v150616-js">
(function(){
  var h=document.querySelector('.hd-header-v150616');if(!h)return;
  var main=h.querySelector('.hd-menu-toggle-v150616');var nav=h.querySelector('.hd-nav-v150616');
  function positionMega(li){
    if(!li||window.innerWidth<761)return;
    var mega=li.querySelector(':scope > .hd-mega');if(!mega)return;
    var r=li.getBoundingClientRect();
    var w=Math.min(1180,Math.max(320,window.innerWidth-32));
    var wanted=Math.max(16,(window.innerWidth-w)/2);
    mega.style.setProperty('--hd-mega-left',(wanted-r.left)+'px');
    mega.style.setProperty('--hd-mega-width',w+'px');
  }
  function positionAll(){h.querySelectorAll('.has-mega').forEach(positionMega);}
  if(main&&nav){main.addEventListener('click',function(){var o=h.classList.toggle('is-open');main.setAttribute('aria-expanded',o?'true':'false');});}
  h.querySelectorAll('.hd-sub-toggle-v150616').forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();var li=b.closest('.has-mega');if(!li)return;positionMega(li);var o=li.classList.toggle('is-sub-open');b.setAttribute('aria-expanded',o?'true':'false');});});
  h.querySelectorAll('.has-mega').forEach(function(li){li.addEventListener('mouseenter',function(){positionMega(li);});li.addEventListener('focusin',function(){positionMega(li);});});
  h.querySelectorAll('.hd-mega-more-toggle').forEach(function(b){b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();var mega=b.closest('.hd-mega');if(!mega)return;var o=mega.classList.toggle('is-expanded');b.setAttribute('aria-expanded',o?'true':'false');var t=b.querySelector('span');if(t)t.textContent=o?'Weniger Kategorien':'Mehr Kategorien';var icon=b.querySelector('b');if(icon)icon.textContent=o?'−':'＋';positionMega(mega.closest('.has-mega'));});});
  window.addEventListener('resize',positionAll,{passive:true});
  window.addEventListener('scroll',positionAll,{passive:true});
  positionAll();
  var searchForm=h.querySelector('.hd-search-v150616'),searchInput=document.getElementById('hd-search-field-v150616'),searchBox=document.getElementById('hd-main-search-results-v150732');
  if(searchForm&&searchInput&&searchBox){
    var searchTimer=0,searchController=null,lastQuery='';
    function positionSearchBox(){
      if(window.innerWidth<=760){searchBox.style.left='0px';searchBox.style.right='0px';searchBox.style.width='100%';return;}
      var r=searchForm.getBoundingClientRect(),gutter=16,w=Math.min(1180,Math.max(320,window.innerWidth-(gutter*2)));
      var left=Math.max(gutter,Math.min(r.left,window.innerWidth-gutter-w));
      searchBox.style.left=(left-r.left)+'px';searchBox.style.right='auto';searchBox.style.width=w+'px';
    }
    function closeSearch(){searchBox.innerHTML='';searchInput.setAttribute('aria-expanded','false');}
    function runSearch(){
      var q=String(searchInput.value||'').replace(/\s+/g,' ').trim();
      if(q.length<2){closeSearch();return;}
      if(q===lastQuery&&searchBox.innerHTML)return; lastQuery=q;
      if(searchController)searchController.abort(); searchController=(typeof AbortController!=='undefined')?new AbortController():null;
      positionSearchBox();searchBox.innerHTML='<div class="hd-main-search-loading-v150732">Suche …</div>';searchInput.setAttribute('aria-expanded','true');
      var body=new URLSearchParams({action:'hd_main_search_v150732',nonce:searchForm.getAttribute('data-hd-search-nonce')||'',q:q});
      fetch(searchForm.getAttribute('data-hd-search-ajax'),{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString(),signal:searchController?searchController.signal:undefined})
      .then(function(r){if(!r.ok)throw new Error('http');return r.json();})
      .then(function(data){if(String(searchInput.value||'').replace(/\s+/g,' ').trim()!==q)return;searchBox.innerHTML=(data&&data.success&&data.data&&typeof data.data.html==='string')?data.data.html:'';positionSearchBox();searchInput.setAttribute('aria-expanded',searchBox.innerHTML?'true':'false');})
      .catch(function(err){if(err&&err.name==='AbortError')return;closeSearch();});
    }
    searchInput.addEventListener('input',function(){clearTimeout(searchTimer);searchTimer=setTimeout(runSearch,180);});
    searchInput.addEventListener('focus',function(){if(String(searchInput.value||'').trim().length>=2)runSearch();});
    searchInput.addEventListener('keydown',function(e){if(e.key==='Escape')closeSearch();});
    window.addEventListener('resize',positionSearchBox,{passive:true});document.addEventListener('click',function(e){if(!searchForm.contains(e.target))closeSearch();});
  }
})();
</script>
        <?php
    }

    public static function shortcode_start() { return self::render_start(); }

    private static function page_intro($page) {
        if (!$page instanceof WP_Post) { return ''; }
        foreach (['_pftk_category_intro_text','portal_category_intro','_portal_category_intro'] as $key) {
            $value = trim((string)get_post_meta($page->ID, $key, true));
            if ($value !== '') { return wp_trim_words(wp_strip_all_tags($value), 18, '…'); }
        }
        $excerpt = trim((string)$page->post_excerpt);
        if ($excerpt !== '') { return wp_trim_words(wp_strip_all_tags($excerpt), 18, '…'); }
        return '';
    }

    private static function responsive_image_markup($post_id, $fallback_url, $class, $alt, $sizes, $loading = 'lazy', $fetchpriority = '') {
        $post_id = absint($post_id);
        $attachment_id = $post_id > 0 ? absint(get_post_thumbnail_id($post_id)) : 0;
        $attrs = [
            'class' => sanitize_html_class((string)$class),
            'alt' => (string)$alt,
            'decoding' => 'async',
            'sizes' => (string)$sizes,
        ];
        if ($loading !== '') { $attrs['loading'] = (string)$loading; }
        if ($fetchpriority !== '') { $attrs['fetchpriority'] = (string)$fetchpriority; }
        if ($attachment_id > 0 && wp_attachment_is_image($attachment_id)) {
            // Full original + native srcset/sizes. Do not upscale a medium thumbnail.
            $html = wp_get_attachment_image($attachment_id, 'full', false, $attrs);
            if (is_string($html) && trim($html) !== '') { return $html; }
        }
        if (trim((string)$fallback_url) === '') { return ''; }
        $fallback_loading = $loading !== '' ? ' loading="' . esc_attr($loading) . '"' : '';
        $fallback_priority = $fetchpriority !== '' ? ' fetchpriority="' . esc_attr($fetchpriority) . '"' : '';
        return '<img class="' . esc_attr((string)$class) . '" src="' . esc_url((string)$fallback_url) . '" alt="' . esc_attr((string)$alt) . '" width="1400" height="620" decoding="async"' . $fallback_loading . $fallback_priority . '>';
    }

    private static function world_image_markup($world) {
        // 1.50.774: homepage has eight individually approved world photos, not hobby masters.
        $slug = sanitize_key((string)($world['slug'] ?? ''));
        if (!in_array($slug, self::world_slugs(), true)) { return ''; }
        return self::responsive_image_markup(0,
            self::asset_url('start-world-v150691/' . $slug . '.webp'),
            'hd-world-image hd-world-image-controlled',
            (string)($world['title'] ?? ''),
            '(max-width:760px) calc((100vw - 33px)/2), (max-width:1180px) calc((100vw - 114px)/4), 350px');
    }

    private static function hero_image_markup() {
        $desktop = self::asset_url('start-hero-text-v150616.jpg');
        $mobile = self::asset_url('start-hero-text-mobile-v150616.jpg');
        return '<picture class="hd-hero-picture"><source media="(max-width:1100px)" srcset="' . esc_url($mobile) . '"><img class="hd-hero-img" src="' . esc_url($desktop) . '" alt="Person bei einem kreativen Hobby – Mehr Zeit für das, was dich begeistert." width="1370" height="620" decoding="async" fetchpriority="high"></picture>';
    }

    private static function compact_world_intro($world) {
        $title = isset($world['title']) ? (string)$world['title'] : '';
        $map = [
            'Gestalten' => 'Malen, Formen, Handarbeit',
            'Fertigen' => 'Holz, Metall, Werkstoffe',
            'Technik' => 'Elektronik, RC, Digitales',
            'Forschen' => 'Wissen, Messen, Entdecken',
            'Pflanzen' => 'Gärtnern, Züchten, Indoor',
            'Tiere' => 'Pflege, Haltung, Beobachtung',
            'Bewegen' => 'Outdoor, Balance, Aktivsein',
            'Sammeln' => 'Suchen, Ordnen, Kuratieren',
        ];
        if (isset($map[$title])) { return $map[$title]; }
        $intro = self::page_intro($world['page']);
        return $intro !== '' ? $intro : 'Entdecken und ausprobieren';
    }

    private static function render_world_cards() {
        $worlds = self::worlds();
        if (!$worlds) { return ''; }
        $html = '<section class="hd-section hd-world-section"><header class="hd-section-head"><div><h2>Deine Hobbywelten</h2><p>Klick dich rein und finde Hobbys, die zu dir passen.</p></div></header><div class="hd-world-grid">';
        foreach ($worlds as $world) {
            $accent = self::world_accent($world['slug']);
            $html .= '<a class="hd-world-card hd-world-' . esc_attr($world['slug']) . '" style="--hd-world-accent:' . esc_attr($accent) . '" href="' . esc_url($world['url']) . '">' . self::world_image_markup($world) . '<div class="hd-world-card-meta"><span class="hd-world-icon">' . self::world_icon_svg($world['slug']) . '</span><strong>' . esc_html($world['title']) . '</strong><b aria-hidden="true">→</b></div></a>';
        }
        return $html . '</div></section>';
    }

    private static function real_editorial_cards() {
        $cards = [];
        $defs = [
            [
                'paths' => ['magazin/hobbyfinder','hobbyfinder'],
                'title' => 'Hobbyfinder',
                'text' => 'Finde Hobbys nach Zeit, Ort, Budget und Interesse.',
                'cta' => 'Jetzt Hobby finden',
                'class' => 'is-finder',
                'icon' => 'finder',
            ],
            [
                'paths' => ['magazin'],
                'title' => 'Neu im Magazin',
                'text' => 'Tipps, Anleitungen und Inspiration für deine nächste Idee.',
                'cta' => 'Zum Magazin',
                'class' => 'is-magazine',
                'icon' => 'magazine',
            ],
            [
                'paths' => ['magazin/wissen-glossar','wissen-glossar'],
                'title' => 'Wissen & Glossar',
                'text' => 'Begriffe, Grundlagen und Orientierung rund um deine Hobbywelten.',
                'cta' => 'Wissen entdecken',
                'class' => 'is-guide',
                'icon' => 'knowledge',
            ],
        ];
        foreach ($defs as $def) {
            $page = self::page_by_path($def['paths']);
            if (!$page) { continue; }
            $text = self::page_intro($page);
            $cards[] = [
                'title' => $def['title'],
                'text' => $text !== '' ? $text : $def['text'],
                'url' => get_permalink($page),
                'cta' => $def['cta'],
                'class' => $def['class'],
                'icon' => $def['icon'],
            ];
        }
        return array_slice($cards, 0, 3);
    }

    private static function editorial_icon_svg($key) {
        $icons = [
            'finder' => '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="22" cy="34" r="12"/><circle cx="42" cy="34" r="12"/><path d="M28 34h8M18 22l6-9h5M46 22l-6-9h-5"/><path d="M15 34h14M35 34h14"/></svg>',
            'magazine' => '<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M10 15c10-3 17-1 22 4v32c-5-5-12-7-22-4V15Z"/><path d="M54 15c-10-3-17-1-22 4v32c5-5 12-7 22-4V15Z"/><path d="M32 19v32"/></svg>',
            'knowledge' => '<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M24 45h16M26 51h12"/><path d="M21 34c-5-4-8-9-8-15a19 19 0 1 1 38 0c0 6-3 11-8 15-3 3-4 6-4 9H25c0-3-1-6-4-9Z"/><path d="M32 8v7M16 15l6 4M48 15l-6 4"/></svg>',
            'register' => '<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M14 12h36v40H14z"/><path d="M22 22h20M22 31h20M22 40h20"/><circle cx="18" cy="22" r="1"/><circle cx="18" cy="31" r="1"/><circle cx="18" cy="40" r="1"/></svg>',
        ];
        return isset($icons[$key]) ? $icons[$key] : $icons['knowledge'];
    }

    private static function render_editorial_cards() {
        $cards = self::real_editorial_cards();
        if (!$cards) { return ''; }
        $html = '<section class="hd-editorial-grid" aria-label="Hobbyfinder, Magazin und Wissen">';
        foreach ($cards as $card) {
            $html .= '<article class="hd-editorial-card ' . esc_attr($card['class']) . '"><div class="hd-editorial-copy"><span class="hd-editorial-icon">' . self::editorial_icon_svg($card['icon']) . '</span><div class="hd-editorial-text"><h2>' . esc_html($card['title']) . '</h2>' . ($card['text'] !== '' ? '<p>' . esc_html($card['text']) . '</p>' : '') . '<a href="' . esc_url($card['url']) . '">' . esc_html($card['cta']) . ' <b>→</b></a></div></div></article>';
        }
        return $html . '</section>';
    }

    private static function is_real_affiliate($html) {
        $html = trim((string)$html);
        if ($html === '') { return false; }
        $hay = strtolower($html . ' ' . wp_strip_all_tags($html));
        foreach (['data-ppar-placeholder','ppar-placeholder-slot','pftk-affiliate-slot-debug','pftk-affiliate-placeholder','affiliate-werbefläche','affiliate-werbeflaeche','noch nicht belegt','platzhalter'] as $marker) {
            if (strpos($hay, $marker) !== false) { return false; }
        }
        return stripos($html, '<a') !== false || stripos($html, '<img') !== false || stripos($html, '<iframe') !== false;
    }

    private static function affiliate_slot($slot) {
        if (!function_exists('shortcode_exists') || !shortcode_exists('pp_affiliate_slot')) { return ''; }
        $html = (string)do_shortcode('[pp_affiliate_slot type="' . esc_attr($slot) . '" intent="portal_context"]');
        return self::is_real_affiliate($html) ? $html : '';
    }

    private static function logged_in_preview() {
        return function_exists('is_user_logged_in') && is_user_logged_in();
    }

    private static function affiliate_preview_placeholder($kind, $slot) {
        if (!self::logged_in_preview()) { return ''; }
        $kind = $kind === 'banner' ? 'Affiliate-Banner' : 'Affiliate-Produkt';
        return '<div class="hd-affiliate-preview" data-hd-empty-slot="' . esc_attr((string)$slot) . '"><small>Nur eingeloggt sichtbar</small><strong>' . esc_html($kind) . '</strong><span>Platz aktuell nicht belegt</span></div>';
    }

    private static function render_products() {
        $products = [];
        for ($i=1; $i<=3; $i++) {
            $slot = 'hub_product_' . $i;
            $html = self::affiliate_slot($slot);
            if ($html === '') { $html = self::affiliate_preview_placeholder('product', $slot); }
            if ($html !== '') { $products[] = '<div class="hd-product-slot' . (strpos($html, 'hd-affiliate-preview') !== false ? ' is-preview' : '') . '" data-hd-slot="' . esc_attr($slot) . '">' . $html . '</div>'; }
        }
        if (!$products) { return ''; }
        $note = self::logged_in_preview() ? '<span class="hd-admin-preview-note">Leere Produktplätze siehst du nur im eingeloggten Zustand.</span>' : '';
        return '<section class="hd-section hd-products"><header class="hd-section-head"><div><h2>Passende Ausstattung</h2><p>Sinnvolle Empfehlungen für deinen Einstieg und deine Projekte. Wir verlinken zu ausgewählten Anbietern.</p>' . $note . '</div></header><div class="hd-product-grid">' . implode('', $products) . '</div></section>';
    }

    private static function render_affiliate_banner() {
        $slot = 'start_after_topics';
        $html = self::affiliate_slot($slot);
        $preview = false;
        if ($html === '') { $html = self::affiliate_preview_placeholder('banner', $slot); $preview = $html !== ''; }
        if ($html === '') { return ''; }
        return '<section class="hd-affiliate-banner' . ($preview ? ' is-preview' : '') . '" aria-label="Anzeige / Partner"><span class="hd-ad-label">Anzeige / Partner</span><div>' . $html . '</div></section>';
    }

    private static function popular_topic_items() {
        $defs = [
            ['Hobby-Ideen & Inspiration', ['magazin/hobby-ideen-inspiration','hobby-ideen-inspiration'], 'gestalten'],
            ['Ungewöhnliche & skurrile Hobbys', ['magazin/ungewoehnliche-skurrile-hobbys','ungewoehnliche-skurrile-hobbys'], 'forschen'],
            ['Wissen & Glossar', ['magazin/wissen-glossar','wissen-glossar'], 'technik'],
            ['Vergleiche & Alternativen', ['magazin/vergleiche-alternativen','vergleiche-alternativen'], 'sammeln'],
        ];
        $items = [];
        foreach ($defs as $def) {
            $page = self::page_by_path($def[1]);
            if (!$page) { continue; }
            $items[] = ['title'=>$def[0], 'url'=>get_permalink($page), 'icon'=>$def[2]];
        }
        return $items;
    }

    private static function render_popular_topics() {
        $items = self::popular_topic_items();
        if (!$items) { return ''; }
        $mag = self::page_link(['magazin']);
        $html = '<section class="hd-section hd-topics"><header class="hd-section-head"><div><h2>Beliebte Themen</h2><p>Ideen, Orientierung und ungewöhnliche Entdeckungen aus unserem Magazin.</p></div>' . ($mag !== '' ? '<a href="' . esc_url($mag) . '">Zum Magazin <b>→</b></a>' : '') . '</header><div class="hd-topic-grid hd-topic-grid-taxonomy">';
        foreach ($items as $item) {
            $html .= '<article><a href="' . esc_url($item['url']) . '"><span class="hd-topic-icon">' . self::world_icon_svg($item['icon']) . '</span><strong>' . esc_html($item['title']) . '</strong><b aria-hidden="true">→</b></a></article>';
        }
        return $html . '</div></section>';
    }

    /**
     * 1.50.790 – Werbe-Eigenmotiv für genau den bereits vorhandenen Mietslot.
     * Links werden ausschließlich aus realen veröffentlichten WP-Seiten gelesen.
     * Kein home_url-Ratefallback, keine Verdrahtung auf Preise statt Bedingungen.
     */
    private static function rental_terms_url_v150790() {
        return self::page_link([
            'werbebedingungen', 'werb-anzeigebedingungen',
            'werbe-und-anzeigenbedingungen', 'werbe-und-anzeigebedingungen',
            'werben/werbebedingungen', 'werbung/werbebedingungen',
        ]);
    }

    private static function rental_prices_url_v150790() {
        return self::page_link(['preise']);
    }

    /**
     * Freigegebenes Werbebanner VORLAGENFOTO 1:1 ohne jeden Beschnitt, Zoom,
     * Ausschnitt, Overlay, Farbkorrektur oder Neuaufbau der Schrift.
     * Lediglich klickbare transparente Zonen auf zwei eingebrannten Buttons.
     */
    private static function rental_hotspot_v150791($label, $url, $style) {
        $class = 'hd-own-ad-hotspot-v150791 ' . esc_attr($style);
        if ($url !== '') {
            return '<a class="' . $class . '" href="' . esc_url($url) . '" aria-label="' . esc_attr($label) . '" title="' . esc_attr($label) . '"><span class="screen-reader-text">' . esc_html($label) . '</span></a>';
        }
        // Keine geratene URL und kein irreführend klickbarer Platzhalter.
        return '<span class="' . $class . ' is-unavailable" aria-label="' . esc_attr($label) . ': Zielseite nicht veröffentlicht" title="Zielseite noch nicht veröffentlicht"></span>';
    }

    private static function rental_own_banner_v150791() {
        $art = self::asset_url('eigenwerbung-v150791/banner-freigabe-originalbild-2170x725.png');
        $terms = self::rental_terms_url_v150790();
        $prices = self::rental_prices_url_v150790();
        return '<div class="hd-own-ad-v150791" aria-label="Freie Werbefläche auf Hobby Depot">'
            . '<img class="hd-own-ad-art-v150791" src="' . esc_url($art) . '" alt="Hobby Depot – Hier könnte Ihre Werbung stehen" loading="lazy" width="2170" height="725">'
            . '<span class="hd-own-ad-title-v150792" aria-hidden="true">Hier könnte Ihre Werbung stehen</span>'
            . self::rental_hotspot_v150791('Werbebedingungen', $terms, 'is-terms')
            . self::rental_hotspot_v150791('Preise', $prices, 'is-prices')
            // Hover overlays affect ONLY the original interior button pixels.
            // Original full banner and its real rounded corners remain untouched.
            . '<img class="hd-own-ad-tint-v150794 is-terms" alt="" aria-hidden="true" decoding="async" src="' . esc_url(self::asset_url('eigenwerbung-v150794/button-hover-terms.png')) . '" width="2170" height="725">'
            . '<img class="hd-own-ad-tint-v150794 is-prices" alt="" aria-hidden="true" decoding="async" src="' . esc_url(self::asset_url('eigenwerbung-v150794/button-hover-prices.png')) . '" width="2170" height="725">'
            . '</div>';
    }

    private static function rental_settings() {
        $value = get_option(self::RENTAL_OPTION, []);
        return is_array($value) ? $value : [];
    }

    private static function rental_slot($placement) {
        $placement = sanitize_key((string)$placement);
        // Existing booked partner output has absolute precedence.
        $filtered = apply_filters('pftk_hobby_rental_slot_html', '', $placement);
        if (trim((string)$filtered) !== '') { return (string)$filtered; }
        $settings = self::rental_settings();
        $slot = isset($settings[$placement]) && is_array($settings[$placement]) ? $settings[$placement] : [];
        if (!empty($slot['active'])) {
            $image = esc_url_raw((string)($slot['image'] ?? ''));
            $url = esc_url_raw((string)($slot['url'] ?? ''));
            if ($image !== '' && $url !== '') {
                $label = trim((string)($slot['label'] ?? 'Partner')); if ($label === '') { $label = 'Partner'; }
                return '<a class="hd-rental-link is-booked" href="' . esc_url($url) . '" target="_blank" rel="sponsored noopener"><img src="' . esc_url($image) . '" alt="' . esc_attr($label) . '" loading="lazy"><span><small>Anzeige</small><strong>' . esc_html($label) . '</strong><b>Mehr erfahren →</b></span></a>';
            }
        }
        return self::rental_own_banner_v150791();
    }

    private static function render_rental_for($placement) {
        if (self::$rental_rendered) { return ''; }
        self::$rental_rendered = true;
        $html = self::rental_slot($placement);
        if ($html === '') { return ''; }
        return '<section class="hd-rental" aria-label="Werbeplatz">' . $html . '</section>';
    }

    private static function render_rental() {
        return self::render_rental_for('start');
    }

    private static function is_faq_page_v150715($page = null) {
        if (!$page instanceof WP_Post) {
            $page = function_exists('get_queried_object') ? get_queried_object() : null;
        }
        return $page instanceof WP_Post
            && $page->post_type === 'page'
            && sanitize_title((string)$page->post_name) === 'faq';
    }

    public static function render_faq_content_v150715($content) {
        if (is_admin() || !function_exists('is_singular') || !is_singular('page')) { return $content; }
        if (function_exists('in_the_loop') && !in_the_loop()) { return $content; }
        if (function_exists('is_main_query') && !is_main_query()) { return $content; }
        $page = function_exists('get_queried_object') ? get_queried_object() : null;
        if (!self::is_faq_page_v150715($page)) { return $content; }

        $sections = [
            'Hobby Depot & Orientierung' => [
                ['Was ist Hobby Depot?', 'Hobby Depot hilft dir, Hobbys zu entdecken, zu vergleichen und besser kennenzulernen. Du findest hier bekannte Hobbys genauso wie kleine, ungewöhnliche und seltene Freizeitideen.'],
                ['Für wen ist Hobby Depot gedacht?', 'Für alle, die ein neues Hobby suchen, sich über ein bestimmtes Hobby informieren oder einfach neue Ideen entdecken möchten. Es spielt keine Rolle, ob du gerade anfängst oder schon Erfahrung hast.'],
                ['Was ist der Unterschied zwischen Hobbyfinder, Hobbyregister und Hobbymagazin?', 'Der Hobbyfinder hilft dir, passende Hobbys nach deinen Wünschen zu finden. Im Hobbyregister kannst du gezielt stöbern und Hobbys vergleichen. Im Hobbymagazin findest du zusätzliche Ideen, Hintergründe und praktische Themen.'],
                ['Warum gibt es bei Hobby Depot auch ungewöhnliche Hobbys?', 'Weil ein gutes Hobby nicht bekannt sein muss. Gerade ungewöhnliche Hobbys können gut zu dir passen und dir Ideen zeigen, auf die du sonst vielleicht nicht gekommen wärst.'],
            ],
            'Hobby finden & vergleichen' => [
                ['Wie funktioniert der Hobbyfinder?', 'Du beantwortest einige einfache Fragen zu deinen Wünschen und deinem Alltag. Zum Beispiel zu Zeit, Platz, Budget oder dazu, ob du lieber allein oder mit anderen aktiv bist. Daraus werden passende Hobbys für dich ausgewählt.'],
                ['Nach welchen Eigenschaften werden die Hobbys verglichen?', 'Zum Beispiel nach Zeitaufwand, Kosten, Platzbedarf, körperlicher Aktivität, Lernaufwand, Ort und Wetterabhängigkeit. Auch Dinge wie Kraft, Koordination, Ausrüstung oder die Frage, ob du allein oder gemeinsam aktiv bist, spielen eine Rolle.'],
                ['Kann ich gezielt nach günstigen oder platzsparenden Hobbys suchen?', 'Ja. Du kannst Hobbys nach verschiedenen Merkmalen eingrenzen, zum Beispiel nach Budget, Platzbedarf, Zeitaufwand oder körperlichen Anforderungen.'],
                ['Kann ich auch einfach durch alle Hobbys stöbern?', 'Ja. Dafür gibt es das Hobbyregister. Dort kannst du unabhängig vom Hobbyfinder nach Hobbys suchen, stöbern und dich inspirieren lassen.'],
                ['Was mache ich, wenn ich noch gar nicht weiß, wonach ich suche?', 'Dann ist der Hobbyfinder ein guter Start. Du musst keinen Hobbynamen kennen. Es reicht, wenn du ungefähr weißt, was dir wichtig ist und was zu deinem Alltag passt.'],
            ],
            'Hobbyregister' => [
                ['Was ist das Hobbyregister?', 'Das Hobbyregister ist die zentrale Übersicht der Hobbys bei Hobby Depot. Dort findest du bekannte, seltene und ungewöhnliche Hobbys an einem Ort.'],
                ['Welche Informationen finde ich zu einem Hobby?', 'Du erfährst, worum es bei dem Hobby geht, was du dabei machst und was du dafür brauchst. Dazu kommen vergleichbare Angaben zu Zeit, Kosten, Platz, Anforderungen und weiteren praktischen Punkten.'],
                ['Kann ich Hobbys miteinander vergleichen?', 'Ja. Die Hobbys werden nach denselben grundlegenden Merkmalen eingeordnet. Dadurch kannst du zum Beispiel Kosten, Zeitbedarf, Platzbedarf oder körperliche Anforderungen besser vergleichen.'],
                ['Warum sind manche Hobbys ausführlicher beschrieben als andere?', 'Einige Hobbys haben bei Hobby Depot zusätzlich eigene Themenbereiche, Artikel oder weiterführende Inhalte. Andere werden zunächst kompakt im Hobbyregister vorgestellt.'],
                ['Werden neue Hobbys ergänzt?', 'Ja. Das Hobbyregister kann erweitert werden, wenn neue oder bisher fehlende Hobbys sinnvoll dazukommen.'],
                ['Kann ich ein fehlendes Hobby vorschlagen?', 'Ja. Wenn dir ein Hobby fehlt, schreib uns einfach über die Kontaktseite.'],
            ],
            'Hobbymagazin & Wissen' => [
                ['Was finde ich im Hobbymagazin?', 'Im Hobbymagazin findest du Ideen, Hintergründe, Trends und praktische Themen rund um Hobbys und Freizeit. Dort geht es auch um Themen, die über ein einzelnes Hobby hinausgehen.'],
                ['Was ist das Glossar?', 'Im Glossar erklären wir Begriffe, die bei Hobbys immer wieder auftauchen. So kannst du unbekannte Fachbegriffe schnell nachschlagen.'],
                ['Wo finde ich Anleitungen und Hintergrundwissen?', 'Je nach Thema findest du diese im passenden Hobbybereich oder im Hobbymagazin. Vom Hobbyregister aus führen dich passende Links zu weiterführenden Inhalten.'],
                ['Sind die Inhalte kostenlos?', 'Ja. Die redaktionellen Inhalte von Hobby Depot kannst du kostenlos lesen.'],
            ],
            'Anzeigen, Anbieter & Empfehlungen' => [
                ['Was finde ich im Anzeigenmarkt?', 'Im Anzeigenmarkt findest du Angebote rund um Hobbys. Das können zum Beispiel Ausrüstung, Dienstleistungen, Kurse oder andere hobbybezogene Angebote sein.'],
                ['Kann ich selbst eine Anzeige einstellen?', 'Ja. Wenn du etwas Passendes anbieten möchtest, kannst du den Anzeigenmarkt nutzen. Welche Möglichkeiten aktuell verfügbar sind, siehst du direkt dort.'],
                ['Können Unternehmen und Anbieter bei Hobby Depot werben?', 'Ja. Wenn du ein passendes Angebot, eine Dienstleistung oder ein Unternehmen rund um Hobbys vorstellen möchtest, findest du die Möglichkeiten unter „Werben im Hobby Depot“.'],
                ['Wo finde ich die Preise?', 'Die aktuellen Preisangaben findest du auf der Seite „Preise“.'],
                ['Verkauft Hobby Depot selbst Produkte?', 'Nein. Hobby Depot ist kein eigener Onlineshop. Wir stellen Informationen bereit und verweisen teilweise auf Angebote anderer Anbieter.'],
            ],
            'Transparenz & Kontakt' => [
                ['Verwendet Hobby Depot Affiliate-Links?', 'Ja. Einige Links können Affiliate-Links sein. Wenn du darüber bei einem Partner etwas kaufst, kann Hobby Depot dafür eine Provision erhalten.'],
                ['Entstehen mir durch einen Affiliate-Link zusätzliche Kosten?', 'Hobby Depot berechnet dir für die Nutzung eines Affiliate-Links keine zusätzlichen Kosten. Maßgeblich ist immer der Preis, den dir der jeweilige Anbieter anzeigt.'],
                ['Wie werden Produkte und Angebote ausgewählt?', 'Angebote sollen zum jeweiligen Hobby oder Thema passen. Eine mögliche Provision allein macht ein Angebot nicht automatisch zu einer Empfehlung.'],
                ['Wird bei Hobby Depot künstliche Intelligenz eingesetzt?', 'Ja. KI unterstützt uns zum Beispiel bei Recherche, Strukturierung, Formulierung und technischen Arbeiten. Deshalb weisen wir im Footer transparent darauf hin.'],
                ['Sind alle Angaben garantiert vollständig oder fehlerfrei?', 'Nein. Informationen können sich ändern und trotz sorgfältiger Arbeit können Fehler vorkommen. Bei wichtigen Fragen zu Sicherheit, Gesundheit, Recht oder technischen Vorgaben solltest du zusätzlich eine geeignete Fachquelle prüfen.'],
                ['Wie kann ich Hobby Depot kontaktieren?', 'Über die Kontaktseite kannst du uns eine Nachricht schicken. Dort kannst du auch Hinweise, Fragen oder Vorschläge senden.'],
            ],
        ];

        $html = '<div class="hd-faq-v150715"><p class="hd-faq-intro-v150715">Hier findest du kurze Antworten auf die wichtigsten Fragen rund um Hobby Depot, den Hobbyfinder, das Hobbyregister, unsere Inhalte und den Anzeigenmarkt.</p>';
        foreach ($sections as $heading => $items) {
            $html .= '<section class="hd-faq-section-v150715"><h2>' . esc_html($heading) . '</h2><div class="hd-faq-list-v150715">';
            foreach ($items as $item) {
                $html .= '<details class="hd-faq-item-v150715"><summary><span>' . esc_html($item[0]) . '</span><b aria-hidden="true"></b></summary><div class="hd-faq-answer-v150715"><p>' . esc_html($item[1]) . '</p></div></details>';
            }
            $html .= '</div></section>';
        }
        return $html . '</div>';
    }

    public static function append_rental_to_content($content) {
        if (is_admin() || (function_exists('is_front_page') && is_front_page()) || self::is_owned_content_route()) { return $content; }
        if (function_exists('in_the_loop') && !in_the_loop()) { return $content; }
        if (function_exists('is_main_query') && !is_main_query()) { return $content; }
        $placement = '';
        if (function_exists('is_singular') && is_singular('post')) {
            $placement = 'article';
        } else {
            $id = function_exists('get_the_ID') ? absint(get_the_ID()) : 0;
            $type = self::affiliate_page_type($id);
            if (in_array($type, ['hub1','hub2','category'], true)) { $placement = $type; }
        }
        if ($placement === '') { return $content; }
        return $content . self::render_rental_for($placement);
    }

    public static function render_start() {
        $finder = self::page_link(['magazin/hobbyfinder','hobbyfinder']);
        $hero = self::hero_image_markup();
        $out = '<main class="hd-home-v150616-main" data-hd-release="1.50.645">';
        $out .= '<section class="hd-hero-v150616"><div class="hd-hero-copy"><span>Kleine Ideen. Große Möglichkeiten.</span><h1>Entdecke dein<br><em>nächstes Hobby.</em></h1><p>Hobbys, die inspirieren. Wissen, kreative Ideen und passende Empfehlungen.</p>' . ($finder !== '' ? '<div class="hd-hero-actions hd-hero-finder-action"><span class="hd-hero-finder-prompt">Noch unsicher, was zu dir passt?</span><a class="is-primary" href="' . esc_url($finder) . '">Hobbyfinder starten <b>→</b></a></div>' : '') . '</div><div class="hd-hero-image">' . $hero . '</div></section>';
        $out .= self::render_world_cards();
        $out .= self::render_affiliate_banner();
        $out .= self::render_editorial_cards();
        $out .= self::render_rental();
        $out .= self::render_popular_topics();
        $out .= self::render_products();
        return $out . '</main>';
    }


    private static function page_intro_long($page) {
        if (!$page instanceof WP_Post) { return ''; }
        foreach (['_pftk_category_intro_text','portal_category_intro','_portal_category_intro'] as $key) {
            $value = trim((string)get_post_meta($page->ID, $key, true));
            if ($value !== '') { return trim(wp_strip_all_tags($value)); }
        }
        $excerpt = trim((string)$page->post_excerpt);
        if ($excerpt !== '') { return trim(wp_strip_all_tags($excerpt)); }
        $content = trim(wp_strip_all_tags(strip_shortcodes((string)$page->post_content)));
        if ($content !== '') { return trim(wp_trim_words($content, 240, '')); }
        return '';
    }

    private static function world_root_for_page($page) {
        if (!$page instanceof WP_Post) { return null; }
        $chain = array_reverse((array)get_post_ancestors($page));
        $root = $page;
        if ($chain) {
            $candidate = get_post((int)$chain[0]);
            if ($candidate instanceof WP_Post) { $root = $candidate; }
        }
        return in_array((string)$root->post_name, self::world_slugs(), true) ? $root : null;
    }

    private static function current_world_slug($page = null) {
        if (!$page instanceof WP_Post && function_exists('get_queried_object')) {
            $obj = get_queried_object();
            if ($obj instanceof WP_Post) { $page = $obj; }
        }
        if (!$page instanceof WP_Post) { return ''; }
        $revision = self::registry_revision();
        if ($revision !== '') {
            if (!self::registry_ready()) { return ''; }
            $node = self::registry_page_node($page->ID);
            $seen = [];
            while (is_array($node)) {
                $id = (string)($node['node_id'] ?? '');
                if ($id === '' || isset($seen[$id])) { return ''; }
                $seen[$id] = true;
                if (strpos($id, 'core:world:') === 0) { return sanitize_key((string)($node['slug'] ?? '')); }
                $parent_id = trim((string)($node['parent_id'] ?? ''));
                if ($parent_id === '') { return ''; }
                $node = hd_category_registry_node($parent_id);
            }
            return '';
        }
        $root = self::world_root_for_page($page);
        return $root instanceof WP_Post ? sanitize_key((string)$root->post_name) : '';
    }

    /**
     * 1.50.750: Exakte Leaf-Autoritaet aus HD-001 1.14.17 / V7.2.
     * Nur diese 3.376 Core-Kategorien erhalten das einheitliche Leaf-Layout.
     * Hoehere Seiten-/Kategorieebenen bleiben unberuehrt.
     */
    private static function leaf_category_map_v150750() {
        static $map = null;
        if (is_array($map)) { return $map; }
        $map = [];
        $file = dirname(__DIR__) . '/assets/hobby-depot-v150750/leaf-category-map-v150750.json';
        if (!is_file($file)) { return $map; }
        $raw = @file_get_contents($file);
        $decoded = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($decoded)) { $map = $decoded; }
        return $map;
    }

    private static function leaf_category_meta_v150750($term) {
        if (!$term instanceof WP_Term || (string)$term->taxonomy !== 'category') { return null; }
        $slug = sanitize_title((string)$term->slug);
        $map = self::leaf_category_map_v150750();
        $meta = $map[$slug] ?? null;
        return is_array($meta) ? $meta : null;
    }

    private static function leaf_category_intro_map_v150751() {
        static $map = null;
        if (is_array($map)) { return $map; }
        $map = [];
        $file = dirname(__DIR__) . '/assets/hobby-depot-v150751/leaf-category-intros-v150751.json';
        if (!is_file($file)) { return $map; }
        $raw = @file_get_contents($file);
        $decoded = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($decoded)) { $map = $decoded; }
        return $map;
    }

    private static function leaf_category_curated_intro_v150750($term, $meta) {
        if (!$term instanceof WP_Term || !is_array($meta)) { return ''; }
        $slug = sanitize_title((string)$term->slug);
        $map = self::leaf_category_intro_map_v150751();
        $text = trim((string)($map[$slug] ?? ''));
        return $text;
    }

    private static function breadcrumb_items() {
        $items = [['label'=>'Startseite','url'=>home_url('/')]];

        // 1.50.723: the magazine target hardroute deliberately works even when
        // WordPress does not classify the request as is_singular('page').
        // Breadcrumb ownership must therefore use the same real URL route.
        $magazine_request_slug = self::magazine_request_slug_v150722();
        if ($magazine_request_slug !== '') {
            $defs = self::magazine_page_defs_v150719();
            $def = isset($defs[$magazine_request_slug]) && is_array($defs[$magazine_request_slug])
                ? $defs[$magazine_request_slug]
                : [];
            $magazine_url = self::page_link(['magazin','journal']);
            if ($magazine_url === '') { $magazine_url = home_url('/magazin/'); }
            $items[] = ['label'=>'Magazin','url'=>$magazine_url];

            $label = trim((string)($def['label'] ?? ''));
            $page = self::magazine_page_by_slug_v150722($magazine_request_slug);
            if ($page instanceof WP_Post) {
                $page_title = trim((string)get_the_title($page));
                if ($page_title !== '') { $label = $page_title; }
            }
            if ($label === '') { $label = $magazine_request_slug; }
            $items[] = ['label'=>$label,'url'=>''];
            return $items;
        }

        if (function_exists('is_singular') && is_singular()) {
            $obj = get_queried_object();
            if ($obj instanceof WP_Post) {
                if ($obj->post_type === 'page') {
                    foreach (array_reverse((array)get_post_ancestors($obj)) as $aid) {
                        $p = get_post((int)$aid); if ($p instanceof WP_Post) { $items[]=['label'=>get_the_title($p),'url'=>get_permalink($p)]; }
                    }
                } elseif ($obj->post_type === 'post') {
                    $cats = get_the_category($obj->ID);
                    if (is_array($cats) && !empty($cats) && $cats[0] instanceof WP_Term) {
                        $chain = array_reverse((array)get_ancestors($cats[0]->term_id, 'category', 'taxonomy'));
                        foreach ($chain as $tid) { $t=get_term($tid,'category'); if ($t instanceof WP_Term) { $u=get_term_link($t); if (!is_wp_error($u)) {$items[]=['label'=>$t->name,'url'=>$u];} } }
                        $u=get_term_link($cats[0]); if (!is_wp_error($u)) {$items[]=['label'=>$cats[0]->name,'url'=>$u];}
                    }
                }
                $items[]=['label'=>get_the_title($obj),'url'=>''];
                return $items;
            }
        }
        if ((function_exists('is_category') && is_category()) || (function_exists('is_tax') && is_tax('journal_cat'))) {
            $term = get_queried_object();
            if ($term instanceof WP_Term) {
                // 1.50.750: WordPress-Term-Eltern bilden die HD-001-Seitenhierarchie nicht ab.
                // Fuer exakt bekannte Leaf-Kategorien kommt der vollstaendige Pfad aus der V7.2-Autoritaet.
                $leaf_meta = ((string)$term->taxonomy === 'category') ? self::leaf_category_meta_v150750($term) : null;
                if (is_array($leaf_meta)) {
                    foreach ((array)($leaf_meta['chain'] ?? []) as $crumb) {
                        if (!is_array($crumb)) { continue; }
                        $label = trim((string)($crumb['label'] ?? ''));
                        $path = trim((string)($crumb['path'] ?? ''), '/');
                        if ($label === '' || $path === '') { continue; }
                        $items[] = ['label'=>$label,'url'=>home_url('/'.$path.'/')];
                    }
                    $items[]=['label'=>$term->name,'url'=>''];
                    return $items;
                }

                $taxonomy=(string)$term->taxonomy;
                foreach (array_reverse((array)get_ancestors($term->term_id,$taxonomy,'taxonomy')) as $tid) {
                    $t=get_term($tid,$taxonomy); if ($t instanceof WP_Term) { $u=get_term_link($t); if (!is_wp_error($u)) {$items[]=['label'=>$t->name,'url'=>$u];} }
                }
                $items[]=['label'=>$term->name,'url'=>''];
            }
        }
        return $items;
    }

    private static function render_breadcrumb() {
        if (function_exists('is_front_page') && is_front_page()) { return ''; }
        $items=self::breadcrumb_items(); if (count($items)<2) { return ''; }
        $parts=[];
        foreach ($items as $i=>$item) {
            $label=trim((string)($item['label']??'')); if ($label==='') {continue;}
            $url=(string)($item['url']??'');
            $parts[]=$url!==''?'<a href="'.esc_url($url).'">'.esc_html($label).'</a>':'<span aria-current="page">'.esc_html($label).'</span>';
        }
        return '<div class="hd-breadcrumb-wrap"><nav class="hd-breadcrumb" aria-label="Breadcrumb">'.implode('<b aria-hidden="true">›</b>',$parts).'</nav></div>';
    }

    private static function intro_kicker($type) {
        $map=['hub1'=>'Hobbywelt','hub2'=>'Themenbereich','category'=>'Hobby','leaf'=>'Kategorie','term'=>'Kategorie','page'=>'Hobby Depot','post'=>'Ratgeber'];
        return $map[$type] ?? 'Hobby Depot';
    }

    private static function fallback_intro($title, $type) {
        $title=trim((string)$title); if ($title==='') {return '';}
        if ($type==='hub1') { return 'Entdecke die wichtigsten Bereiche, Hobbys und Ideen rund um ' . $title . '.'; }
        if ($type==='hub2') { return 'Finde passende Hobbys, Wissen und nächste Themen rund um ' . $title . '.'; }
        if ($type==='category' || $type==='leaf' || $type==='term') { return 'Orientierung, praktische Beiträge und passende Empfehlungen rund um ' . $title . '.'; }
        return 'Inspiration, Wissen und passende Empfehlungen rund um ' . $title . '.';
    }

    private static function category_text_profile($title, $type, $world_slug='') {
        $world_slug = sanitize_key((string)$world_slug);
        $profiles = [
            'gestalten' => ['focus'=>'kreative Techniken, Materialien und Projekte','criteria'=>'Idee, Technik, Material und gewünschtes Ergebnis'],
            'fertigen' => ['focus'=>'handwerkliche Verfahren, Werkstoffe und selbst gefertigte Dinge','criteria'=>'Werkstoff, Werkzeug, Technik und Aufwand'],
            'technik' => ['focus'=>'Elektronik, Robotik, RC, digitale Fertigung und technische Projekte','criteria'=>'Funktion, Bauteile, Werkzeug und Lernaufwand'],
            'forschen' => ['focus'=>'Beobachten, Messen, Experimentieren und Naturwissenschaft als Hobby','criteria'=>'Fragestellung, Methode, Ausrüstung und Dokumentation'],
            'pflanzen' => ['focus'=>'Pflanzenpflege, Zucht, Spezialkulturen und essbare Projekte','criteria'=>'Standort, Kulturform, Pflege und Zeitaufwand'],
            'tiere' => ['focus'=>'Aquaristik, Terraristik, Wirbellose, Insekten und Imkerei','criteria'=>'Tierart, Lebensraum, Pflegeaufwand und Verantwortung'],
            'bewegen' => ['focus'=>'Outdoor, Balance, Wasser, Klettern, Wind und aktive Freizeit','criteria'=>'Ort, Ausrüstung, Kondition und Sicherheitsanforderungen'],
            'sammeln' => ['focus'=>'Sammlungen, Bestimmung, Ordnung, Geschichte und Werterhalt','criteria'=>'Sammelgebiet, Zustand, Echtheit und Dokumentation'],
        ];
        if (isset($profiles[$world_slug])) { return $profiles[$world_slug]; }
        return ['focus'=>'Einstieg, Praxis, Wissen und passende Vertiefungen rund um ' . trim((string)$title),'criteria'=>'Einstieg, Material oder Ausrüstung, Praxis und typische Fragen'];
    }

    private static function human_list($items, $limit=6) {
        $items=array_values(array_filter(array_map(function($v){return trim((string)$v);},(array)$items)));
        $items=array_slice($items,0,max(1,(int)$limit));
        $n=count($items); if($n===0){return '';} if($n===1){return $items[0];}
        return implode(', ',array_slice($items,0,-1)).' und '.$items[$n-1];
    }

    private static function auto_category_intro_for_page($page, $type, $world_slug='') {
        if (!$page instanceof WP_Post) { return ''; }
        $title=trim((string)get_the_title($page)); if($title===''){return '';}
        $child_names=self::canonical_child_labels_for_page($page);
        $child_list=self::human_list($child_names,7);
        $profile=self::category_text_profile($title,$type,$world_slug);
        $focus=(string)$profile['focus']; $criteria=(string)$profile['criteria'];
        $parent=''; if((int)$page->post_parent>0){$pp=get_post((int)$page->post_parent); if($pp instanceof WP_Post){$parent=trim((string)get_the_title($pp));}}
        if($type==='hub1' && sanitize_key((string)$page->post_name)==='gestalten') {
            return 'Gestalten ist die Hobbywelt für alle, die Ideen sichtbar machen und mit Farben, Formen, Materialien oder Bildern etwas Eigenes schaffen möchten. Ob du malst, zeichnest, druckst, fotografierst, mit Papier arbeitest, Textilien gestaltest oder kleine Szenen baust: Entscheidend ist nicht ein perfektes Ergebnis, sondern der Weg von der ersten Idee zum fertigen Projekt. Viele Techniken lassen sich mit wenig Ausrüstung ausprobieren, andere werden mit Erfahrung, guten Werkzeugen und passendem Material immer vielseitiger. Wer neu einsteigt, kann sich zunächst an einfachen Projekten orientieren und später gezielt einzelne Techniken vertiefen. Ebenso wichtig sind Fragen zu Materialwahl, Arbeitsplatz, Kosten, Vorlagen, Fehlern und Möglichkeiten, eigene Arbeiten weiterzuentwickeln. In Hobby Depot verbinden wir deshalb praktische Einstiege mit Hintergrundwissen, Ideen und konkreten nächsten Schritten. Unter Gestalten findest du die Bereiche ' . ($child_list!==''?$child_list:'Malen & Zeichnen, Druck & Fotografie, Schrift & Lettering, Papierkunst, Textilgestaltung, Oberfläche & Deko und Miniaturen & Szenen') . '. So kannst du direkt in den Bereich wechseln, der zu deiner Idee, deinem Material und der Art von Projekt passt, die du ausprobieren möchtest.';
        }
        $where=$parent!==''?' innerhalb von '.$parent:'';
        $text=$title.' bündelt'.$where.' die wichtigsten Themen rund um '.$focus.'. ';
        $text.='Für den Einstieg hilft es, '.$criteria.' getrennt zu betrachten, statt sich sofort in Spezialfragen zu verlieren. ';
        if($child_list!==''){$text.='Die vorhandene nächste Ebene führt dich weiter zu '.$child_list.'. ';}
        $text.='Dort findest du jeweils verständliche Orientierung für Anfänger ebenso wie vertiefende Inhalte für Menschen, die das Thema bereits praktisch betreiben. ';
        $text.='Neben Grundlagen gehören typische Fehler, sinnvolle Ausrüstung oder Materialien, Kosten, Varianten und konkrete Projekte zu einer vollständigen Einordnung. ';
        $text.='Die Texte bleiben bewusst sachlich: Sie sollen erklären, Unterschiede sichtbar machen und dir helfen, den nächsten sinnvollen Schritt auszuwählen. ';
        $text.='Was du hier findest, richtet sich immer nach der tatsächlich vorhandenen Kategorie- und Beitragsstruktur. So bleibt der Weg von dieser Seite zur nächsten Ebene klar, ohne Themen künstlich zu erfinden oder doppelt anzulegen.';
        return trim($text);
    }

    private static function category_intro_for_page($page, $type, $world_slug='') {
        $manual=self::page_intro_long($page);
        if($manual!==''){return $manual;}
        return self::auto_category_intro_for_page($page,$type,$world_slug);
    }

    private static function category_intro_for_term($term) {
        if(!$term instanceof WP_Term){return '';}
        $stored=trim(wp_strip_all_tags((string)$term->description)); if($stored!==''){return $stored;}
        $children=get_terms(['taxonomy'=>$term->taxonomy,'parent'=>$term->term_id,'hide_empty'=>false,'orderby'=>'name','order'=>'ASC']);
        $names=[]; if(!is_wp_error($children)){foreach((array)$children as $child){if($child instanceof WP_Term){$names[]=$child->name;}}}
        $list=self::human_list($names,6); $title=trim((string)$term->name);
        $text=$title.' ordnet die wichtigsten Grundlagen, Praxisfragen und weiterführenden Themen dieser Kategorie ein. ';
        if($list!==''){$text.='Die nächste Ebene führt dich zu '.$list.'. ';}
        $text.='Für die Orientierung stehen verständliche Einstiege, typische Fragen, Material oder Ausrüstung, Kosten und praktische Anwendungen im Vordergrund. Gleichzeitig sollen erfahrene Nutzer schnell zu den vertiefenden Themen gelangen, ohne bereits bekannte Grundlagen mehrfach durchlaufen zu müssen. Die Struktur folgt deshalb immer den tatsächlich vorhandenen Unterkategorien und Beiträgen. Was du hier findest, wird aus der realen Portalstruktur abgeleitet. So bleibt der Weg zu passenden Beiträgen, Empfehlungen und der nächsten Kategorieebene klar und nachvollziehbar.';
        return $text;
    }

    private static function intro_lead($text, $words=36) {
        $text=trim((string)$text); if($text===''){return '';}
        return trim(wp_trim_words($text,max(12,(int)$words),'…'));
    }

    private static function paragraph_markup($text, $sentences_per_paragraph=2) {
        $text=trim((string)$text); if($text===''){return '';}
        $sentences=preg_split('/(?<=[.!?])\s+(?=[\p{Lu}ÄÖÜ0-9„])/u',$text,-1,PREG_SPLIT_NO_EMPTY);
        if(!is_array($sentences) || count($sentences)<2){return '<p>'.esc_html($text).'</p>';}
        $chunks=array_chunk($sentences,max(1,(int)$sentences_per_paragraph)); $html='';
        foreach($chunks as $chunk){$p=trim(implode(' ',$chunk)); if($p!==''){$html.='<p>'.esc_html($p).'</p>';}}
        return $html;
    }

    private static function paragraph_markup_explicit_v150698($text) {
        $text=trim((string)$text); if($text===''){return '';}
        $parts=preg_split('/\R\s*\R/u',$text,-1,PREG_SPLIT_NO_EMPTY);
        if(!is_array($parts) || count($parts)<2){return self::paragraph_markup($text,2);}
        $html='';
        foreach($parts as $part){$part=trim(preg_replace('/\s+/u',' ',(string)$part)); if($part!==''){$html.='<p>'.esc_html($part).'</p>';}}
        return $html;
    }

    private static function render_category_intro_editorial($text) {
        $text=trim((string)$text); if($text===''){return '';}
        $words=preg_split('/\s+/u',$text,-1,PREG_SPLIT_NO_EMPTY); $count=is_array($words)?count($words):0;
        if($count<130){return '<section class="hd-category-copy"><div class="hd-category-copy-inner">'.self::paragraph_markup($text,2).'</div></section>';}
        $sentences=preg_split('/(?<=[.!?])\s+(?=[\p{Lu}ÄÖÜ0-9„])/u',$text,-1,PREG_SPLIT_NO_EMPTY);
        if(!is_array($sentences) || count($sentences)<5){return '<section class="hd-category-copy"><div class="hd-category-copy-inner">'.self::paragraph_markup($text,2).'</div></section>';}
        $find=array_splice($sentences,-2); $body=array_values($sentences);
        $best=1; $delta=PHP_INT_MAX;
        for($i=1;$i<count($body);$i++){
            $lead=trim(implode(' ',array_slice($body,0,$i))); $more=trim(implode(' ',array_slice($body,$i)));
            $lw=count(preg_split('/\s+/u',$lead,-1,PREG_SPLIT_NO_EMPTY)); $mw=count(preg_split('/\s+/u',$more,-1,PREG_SPLIT_NO_EMPTY));
            if($mw<25){continue;} $d=abs($lw-55); if($d<$delta){$delta=$d;$best=$i;}
        }
        $lead=trim(implode(' ',array_slice($body,0,$best))); $more=trim(implode(' ',array_slice($body,$best))); $find_text=trim(implode(' ',$find));
        if($more===''||$find_text===''){return '<section class="hd-category-copy"><div class="hd-category-copy-inner">'.self::paragraph_markup($text,2).'</div></section>';}
        return '<section class="hd-category-copy" data-hd-intro="pferdeatelier-rule"><div class="hd-category-copy-inner">'.self::paragraph_markup($lead,2).'<details class="hd-category-more"><summary>Mehr erfahren</summary><div>'.self::paragraph_markup($more,2).'<div class="hd-category-find"><strong>Was du hier findest</strong>'.self::paragraph_markup($find_text,2).'</div></div></details></div></section>';
    }

    private static function render_page_intro_block($title, $intro, $type, $world_slug='') {
        $title=trim((string)$title); $intro=trim((string)$intro);
        if ($intro==='') {$intro=self::fallback_intro($title,$type);}
        $icon=$world_slug!==''?'<span class="hd-page-title-icon">'.self::world_icon_svg($world_slug).'</span>':'';
        return '<section class="hd-page-intro"><div class="hd-page-intro-copy"><span class="hd-page-kicker">'.esc_html(self::intro_kicker($type)).'</span><h1>'.$icon.esc_html($title).'</h1>'.($intro!==''?'<p>'.esc_html($intro).'</p>':'').'</div></section>';
    }

    private static function hub1_hero_copy($world_slug) {
        $map = [
            'gestalten' => 'Du möchtest etwas Eigenes machen und suchst den passenden Einstieg? Hier findest du kreative Wege mit Farbe, Papier, Stoff, Fotografie, Schrift, Oberflächen und kleinen Szenen. Fang einfach mit dem Bereich an, der dich spontan anspricht – den Rest kannst du später entdecken.',
            'fertigen' => 'Du arbeitest gern mit den Händen und möchtest am Ende etwas Greifbares vor dir haben? Hier findest du Werkstoffe, Techniken und Projekte von Holz und Metall bis Leder, Textil, Keramik, Schmuck und Heimwerken. Du kannst klein anfangen und dich Schritt für Schritt an anspruchsvollere Arbeiten wagen.',
            'technik' => 'Du willst verstehen, wie Dinge funktionieren, und lieber selbst bauen als nur benutzen? Hier findest du Elektronik, Robotik, Computer, Funk, Audio, digitale Fertigung, Mechanik, Smart Home und Modelltechnik. Such dir das Thema aus, bei dem du sofort Lust bekommst, etwas auszuprobieren.',
            'forschen' => 'Du beobachtest gern genauer und willst wissen, warum etwas so ist, wie es ist? Hier findest du Astronomie, Mikroskopie, Wetter, Naturbeobachtung und praktische Messmethoden. Vieles kannst du schon mit einfacher Ausrüstung beginnen und später gezielt vertiefen.',
            'pflanzen' => 'Du möchtest Pflanzen nicht nur hinstellen, sondern wirklich verstehen, pflegen und gestalten? Hier findest du alles von Zimmerpflanzen und Gärtnern bis Bonsai, Orchideen, Hydroponik, Pilzkulturen und essbaren Pflanzen. Wähle einfach die Pflanzenwelt, die zu deinem Platz und deiner Zeit passt.',
            'tiere' => 'Du interessierst dich für Tiere, ihre Lebensräume und eine verantwortungsvolle Haltung? Hier findest du Aquaristik, Terraristik, Insekten, Wirbellose, Imkerei, Futtertiere und Gehegegestaltung. Jede Richtung hat ihre eigenen Anforderungen – genau dabei helfen dir die einzelnen Themenbereiche.',
            'bewegen' => 'Du willst raus, dich ausprobieren oder eine neue Art von Bewegung entdecken? Hier findest du Outdoor-Ideen, Wasser, Klettern, Balance, Wurf- und Geschicklichkeitsthemen, Wind und gemeinsame Wettkämpfe. Entscheidend ist nicht Leistung, sondern dass die Aktivität zu dir und deinem Alltag passt.',
            'sammeln' => 'Du hebst Dinge nicht einfach auf, sondern möchtest Zusammenhänge, Geschichte und Besonderheiten entdecken? Hier findest du Sammelgebiete von Münzen und Dokumenten bis Technik, Spielzeug, Naturfunden, Design und Alltagsobjekten. So kannst du gezielt dort einsteigen, wo dich die Geschichten hinter den Dingen interessieren.',
        ];
        $world_slug = sanitize_key((string)$world_slug);
        return isset($map[$world_slug]) ? $map[$world_slug] : '';
    }

    private static function hub1_direct_child_by_slug($page, $slug) {
        if (!$page instanceof WP_Post) { return null; }
        $needle = sanitize_title((string)$slug);
        foreach (self::direct_page_children($page->ID) as $child) {
            if (!$child instanceof WP_Post) { continue; }
            if (sanitize_title((string)$child->post_name) === $needle) { return $child; }
        }
        return null;
    }

    private static function hub1_link_tokens($page, $text, $max_links = 1) {
        $text = (string)$text;
        $max_links = max(0, (int)$max_links);
        $parts = preg_split('/(\[\[[^\]]+\]\])/u', $text, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        if (!is_array($parts)) { return esc_html($text); }
        $html = '';
        $used = 0;
        foreach ($parts as $part) {
            if (preg_match('/^\[\[([^|\]]+)\|([^\]]+)\]\]$/u', $part, $m)) {
                $child = self::hub1_direct_child_by_slug($page, $m[1]);
                $label = trim((string)$m[2]);
                if ($child instanceof WP_Post && $used < $max_links) {
                    $html .= '<a href="' . esc_url(get_permalink($child)) . '">' . esc_html($label) . '</a>';
                    $used++;
                } else {
                    $html .= esc_html($label);
                }
            } else {
                $html .= esc_html($part);
            }
        }
        return $html;
    }

    private static function hub1_editorial_profile($world_slug) {
        $profiles = [
            'gestalten' => [
                'title' => 'Gestalten: aus einer Idee wird etwas Eigenes',
                'sections' => [
                    ['h'=>'Starte mit dem, was dich sofort reizt','p'=>[
                        'Du musst nicht zuerst eine perfekte Technik lernen. Wenn dich Farbe und Linie anziehen, führen dich [[malen-zeichnen|Malen & Zeichnen]] direkt zu passenden Einstiegen. Möchtest du Bilder vervielfältigen, fotografisch arbeiten oder mit Druck experimentieren, ist [[druck-foto|Druck & Fotografie]] der bessere Start. Für schnelle Projekte mit wenig Werkzeug eignet sich [[papierkunst|Papierkunst]] besonders gut.',
                        'Wichtig ist, dass du nicht nach dem „richtigen“ kreativen Hobby suchst, sondern nach einer Tätigkeit, bei der du gern Zeit vergisst. Viele Techniken lassen sich klein ausprobieren, bevor du Geld in Material oder Werkzeug steckst.'
                    ]],
                    ['h'=>'Material verändert die Idee','p'=>[
                        'Manchmal entsteht der Reiz erst durch das Material. In [[textilgestaltung|Textilgestaltung]] arbeitest du mit Stoff, Faden, Farbe und Struktur. Bei [[oberflaeche-deko|Oberfläche & Deko]] steht das Verändern, Veredeln und Kombinieren im Vordergrund. Wenn Sprache und Form zusammenkommen sollen, findest du in [[schrift-lettering|Schrift & Lettering]] einen ganz anderen Zugang zum Gestalten.',
                        'Probiere ruhig verschiedene Materialien nebeneinander. Erst im Tun merkst du, ob dir präzises Arbeiten, freies Experimentieren oder ein klar geplantes Projekt mehr liegt.'
                    ]],
                    ['h'=>'Kleine Welten dürfen groß wirken','p'=>[
                        'Wer gern baut, arrangiert und Geschichten im Kleinen erzählt, landet schnell bei [[miniaturen-szenen|Miniaturen & Szenen]]. Hier treffen Gestaltung, Handwerk und Geduld aufeinander. Genau diese Mischung macht den Bereich spannend: Du kannst malen, kleben, modellieren, altern, beleuchten oder ganze Szenen inszenieren.',
                        'Nimm dir am Anfang ein überschaubares Projekt vor. Ein einzelnes Motiv, eine kleine Szene oder ein neues Material reicht völlig. Gute Ideen wachsen meistens beim Machen.'
                    ]],
                ]
            ],
            'fertigen' => [
                'title' => 'Fertigen: mit Material, Werkzeug und den eigenen Händen',
                'sections' => [
                    ['h'=>'Welcher Werkstoff passt zu dir?','p'=>[
                        'Wenn du gern sägst, schleifst und Verbindungen baust, ist [[holz|Holz]] ein naheliegender Einstieg. Für härtere Werkstoffe und präzise Bearbeitung führt der Weg zu [[metall|Metall]]. Weicher und unmittelbarer arbeiten sich [[leder|Leder]] und [[textil|Textil]]. Wer Formen, Hitze und Oberflächen spannend findet, sollte sich [[keramik-glas|Keramik & Glas]] ansehen.',
                        'Du musst dich nicht dauerhaft festlegen. Viele gute Projekte kombinieren mehrere Materialien. Entscheidend ist zuerst, welche Art von Arbeit dir Spaß macht: grob und kräftig, fein und präzise oder ruhig und detailorientiert.'
                    ]],
                    ['h'=>'Formen, verbinden und veredeln','p'=>[
                        'Bei [[guss-form|Guss & Formen]] entsteht etwas Neues aus einer Form. [[schmuck|Schmuck]] verbindet Gestaltung mit sehr genauer Handarbeit. [[buch-papier|Buch & Papier]] zeigt, wie viel Handwerk in scheinbar einfachen Materialien steckt, während [[naturmaterial|Naturmaterial]] Holz, Fasern, Stein oder Fundstücke in den Mittelpunkt rückt.',
                        'Achte beim Einstieg weniger auf Spezialmaschinen und mehr auf einen sauberen Grundprozess. Ein gutes kleines Projekt bringt dir mehr als zehn Werkzeuge, deren Einsatz du noch nicht kennst.'
                    ]],
                    ['h'=>'Praktisch darf trotzdem Hobby sein','p'=>[
                        'Wenn du Dinge im Alltag verbessern, reparieren oder selbst bauen möchtest, findest du in [[heimwerken|Heimwerken]] viele direkte Projekte. Beim Bereich [[genuss|Genuss]] steht dagegen das Herstellen, Verfeinern und Ausprobieren im Mittelpunkt. Beides hat denselben Kern: Du machst etwas selbst und siehst unmittelbar, was aus deiner Arbeit entsteht.',
                        'Fang mit einem Projekt an, das du wirklich gebrauchen oder verschenken möchtest. Das gibt dir ein klares Ziel und macht den Lernweg deutlich angenehmer.'
                    ]],
                ]
            ],
            'technik' => [
                'title' => 'Technik: verstehen, bauen und ausprobieren',
                'sections' => [
                    ['h'=>'Vom Bauteil zum funktionierenden System','p'=>[
                        'Wenn du gern wissen möchtest, warum ein Gerät funktioniert, ist [[elektronik|Elektronik]] der klassische Einstieg. Sobald Sensoren, Motoren und Steuerungen zusammenspielen, wird [[robotik-automation|Robotik & Automation]] interessant. Möchtest du Technik im eigenen Zuhause sinnvoll einsetzen, führt [[smart-home|Smart Home]] dieselben Grundideen in einen alltagstauglichen Kontext.',
                        'Du brauchst dafür nicht sofort ein komplettes Labor. Ein kleines Projekt mit klarer Funktion ist der bessere Start: messen, schalten, steuern oder etwas automatisch reagieren lassen.'
                    ]],
                    ['h'=>'Digital trifft auf Mechanik','p'=>[
                        'Bei [[computer-retro|Computer & Retro]] geht es um Hardware, Systeme und Technikgeschichte. [[digitale-fertigung|Digitale Fertigung]] bringt Entwurf und Herstellung zusammen, etwa wenn aus einer digitalen Datei ein reales Bauteil entsteht. Wer Zahnräder, Bewegungen und Präzision liebt, findet in [[mechanik-uhren|Mechanik & Uhren]] eine ganz andere, sehr handfeste Seite der Technik.',
                        'Diese Bereiche wirken auf den ersten Blick unterschiedlich, trainieren aber dieselbe Fähigkeit: genau hinsehen, Zusammenhänge verstehen und Fehler Schritt für Schritt eingrenzen.'
                    ]],
                    ['h'=>'Klang, Signale und bewegte Modelle','p'=>[
                        'Für guten Klang und klassische Geräte lohnt sich ein Blick in [[audio-hifi|Audio & HiFi]]. Wenn dich Übertragung, Reichweite und Signale reizen, ist [[funk|Funk]] dein Bereich. Bei [[rc-modelltechnik|RC & Modelltechnik]] kommt schließlich Bewegung ins Spiel – hier verbinden sich Mechanik, Elektronik, Steuerung und oft auch viel Eigenbau.',
                        'Lass dich von Fachbegriffen nicht abschrecken. Technik wird verständlich, sobald du ein konkretes Problem vor dir hast und es in kleine Schritte zerlegst.'
                    ]],
                ]
            ],
            'forschen' => [
                'title' => 'Forschen: genauer hinsehen und eigene Fragen verfolgen',
                'sections' => [
                    ['h'=>'Vom Himmel bis ins Mikroskop','p'=>[
                        'In [[astronomie|Astronomie]] richtet sich dein Blick weit nach draußen: Mond, Planeten, Sterne und Himmelsereignisse lassen sich schon mit erstaunlich einfacher Ausrüstung beobachten. [[mikroskopie|Mikroskopie]] macht genau das Gegenteil und zeigt dir Strukturen, die mit bloßem Auge verborgen bleiben.',
                        'Beide Bereiche belohnen Geduld. Gute Beobachtung entsteht nicht durch möglichst viel Ausrüstung, sondern dadurch, dass du wiederholt hinschaust und Unterschiede bemerkst.'
                    ]],
                    ['h'=>'Die eigene Umgebung wird zum Forschungsfeld','p'=>[
                        'Bei [[naturbeobachtung|Naturbeobachtung]] kannst du direkt vor der Haustür anfangen. Tiere, Pflanzen, Spuren und jahreszeitliche Veränderungen liefern ständig neue Fragen. [[wetter-umwelt|Wetter & Umwelt]] ergänzt diesen Blick um Temperatur, Wolken, Luft, Niederschlag und langfristige Entwicklungen.',
                        'Notizen, Fotos und einfache Messreihen machen aus einzelnen Eindrücken schnell ein echtes Projekt. So erkennst du Muster, statt dich nur auf Erinnerung zu verlassen.'
                    ]],
                    ['h'=>'Messen statt raten','p'=>[
                        'Wenn dich Zahlen, Vergleiche und nachvollziehbare Ergebnisse reizen, führt kein Weg an [[messen-analysieren|Messen & Analysieren]] vorbei. Hier geht es darum, Beobachtungen sauber zu erfassen und sinnvoll auszuwerten.',
                        'Du musst dabei nicht wissenschaftlich perfekt arbeiten. Schon ein klarer Versuchsaufbau, dieselbe Messmethode und ein ordentliches Protokoll machen deine Ergebnisse deutlich aussagekräftiger.'
                    ]],
                ]
            ],
            'pflanzen' => [
                'title' => 'Pflanzen: finde die Kulturform, die zu dir passt',
                'sections' => [
                    ['h'=>'Vom Fensterbrett bis zum Garten','p'=>[
                        'Für einen unkomplizierten Start sind [[zimmerpflanzen|Zimmerpflanzen]] ideal, weil du sie direkt im Alltag beobachten kannst. Mit mehr Platz wird [[gaertnern|Gärtnern]] interessant. Wenn du nicht nur Grün, sondern auch Ernte möchtest, führt dich [[essbare-pflanzen|Essbare Pflanzen]] zu Kräutern, Gemüse und anderen nutzbaren Kulturen.',
                        'Entscheidend sind Licht, Platz und die Zeit, die du regelmäßig aufbringen möchtest. Die schönste Pflanze macht wenig Freude, wenn ihre Ansprüche dauerhaft nicht zu deinem Standort passen.'
                    ]],
                    ['h'=>'Spezielle Pflanzen, besondere Formen','p'=>[
                        '[[bonsai-miniatur|Bonsai & Miniatur]] verbindet Pflanzenpflege mit Gestaltung und sehr langfristigem Denken. [[kakteen-sukkulenten|Kakteen & Sukkulenten]] faszinieren durch Formen und Anpassung an trockene Bedingungen. Bei [[orchideen-exoten|Orchideen & Exoten]] spielen Klima, Licht und die richtige Kulturweise eine besonders große Rolle.',
                        'Gerade bei Spezialkulturen lohnt es sich, mit wenigen Exemplaren zu beginnen. So lernst du die Reaktionen der Pflanzen kennen, ohne dass die Pflege sofort unübersichtlich wird.'
                    ]],
                    ['h'=>'Neue Wege des Wachsens','p'=>[
                        '[[hydro-indoor|Hydroponik & Indoor]] zeigt, wie Pflanzen auch ohne klassischen Garten kultiviert werden können. In [[pilze-kulturen|Pilze & Kulturen]] gelten wiederum ganz andere Bedingungen. Mit [[saatgut-zucht|Saatgut & Zucht]] beginnt das Projekt schon beim Ausgangsmaterial, während [[moos-miniaturgaerten|Moos & Miniaturgärten]] kleine, kontrollierte Landschaften entstehen lässt.',
                        'Wenn du experimentierfreudig bist, findest du hier besonders viele Möglichkeiten. Ändere am Anfang aber immer nur wenige Bedingungen gleichzeitig – dann verstehst du auch, warum etwas gut oder schlecht funktioniert.'
                    ]],
                ]
            ],
            'tiere' => [
                'title' => 'Tiere: Lebensräume verstehen und Verantwortung übernehmen',
                'sections' => [
                    ['h'=>'Der Lebensraum kommt zuerst','p'=>[
                        'Bei [[aquaristik|Aquaristik]] und [[terraristik|Terraristik]] ist das eigentliche Hobby weit mehr als das Tier selbst. Wasserwerte, Temperatur, Licht, Struktur und Rückzugsmöglichkeiten bestimmen, ob ein Lebensraum funktioniert. [[gehegegestaltung|Gehegegestaltung]] setzt genau dort an und zeigt, wie Umgebung und Bedürfnisse zusammenpassen.',
                        'Bevor du ein Tier anschaffst, solltest du deshalb immer erst den Lebensraum planen. Viele spätere Probleme lassen sich vermeiden, wenn Platz, Technik und laufender Aufwand vorher realistisch eingeschätzt werden.'
                    ]],
                    ['h'=>'Kleine Tiere, große Beobachtungen','p'=>[
                        '[[ameisen-insekten|Ameisen & Insekten]] und [[wirbellose|Wirbellose]] eröffnen dir eine Welt, die oft direkt vor unseren Augen übersehen wird. Bei [[imkerei-bestaeuber|Imkerei & Bestäuber]] kommt zusätzlich der Blick auf ökologische Zusammenhänge und die Arbeit mit ganzen Völkern hinzu.',
                        'Diese Hobbys leben vom Beobachten. Wenn du gern Verhalten, Entwicklung und kleine Veränderungen wahrnimmst, kann gerade ein vermeintlich unscheinbares Tier besonders spannend sein.'
                    ]],
                    ['h'=>'Zucht braucht einen klaren Plan','p'=>[
                        'In [[zucht-futtertiere|Zucht & Futtertiere]] geht es nicht nur um Vermehrung, sondern um Versorgung, Platz, Genetik, Hygiene und die Frage, was mit den Tieren langfristig geschieht.',
                        'Plane deshalb immer vom dauerhaften Bedarf her und nicht von einem kurzfristigen Reiz. Verantwortungsvolle Tierhaltung bedeutet, dass die Bedürfnisse der Tiere vor dem eigenen Wunsch nach einem neuen Projekt stehen.'
                    ]],
                ]
            ],
            'bewegen' => [
                'title' => 'Bewegen: finde die Aktivität, die du wirklich gern machst',
                'sections' => [
                    ['h'=>'Rausgehen und neue Räume entdecken','p'=>[
                        '[[outdoor|Outdoor]] ist der breiteste Einstieg, wenn du Bewegung mit Natur und kleinen Abenteuern verbinden möchtest. Bei [[klettern-seil|Klettern & Seil]] kommen Technik, Vertrauen und Sicherheitswissen dazu. [[wasser|Wasser]] eröffnet wiederum Aktivitäten, bei denen Gleichgewicht, Umgebung und Wetter eine besondere Rolle spielen.',
                        'Wähle für den Anfang etwas, das du regelmäßig machen kannst. Ein erreichbarer Ort und wenig organisatorischer Aufwand sind oft wichtiger als die spektakulärste Sportart.'
                    ]],
                    ['h'=>'Balance, Ziel und Geschick','p'=>[
                        'In [[rollen-balance|Rollen & Balance]] lernst du viel über Körperspannung und saubere Bewegungsabläufe. [[geschick-tricks|Geschick & Tricks]] lebt vom Wiederholen kleiner Bewegungen, bis sie plötzlich funktionieren. Wenn du gern präzise arbeitest, passt [[wurf-ziel|Wurf & Ziel]] besonders gut.',
                        'Hier zählt Fortschritt in kleinen Schritten. Gerade am Anfang sind kurze, häufige Einheiten meist besser als seltene lange Sessions.'
                    ]],
                    ['h'=>'Wind, Team und gemeinsamer Wettbewerb','p'=>[
                        '[[wind-drachen|Wind & Drachen]] verbindet Bewegung mit Wetter und Technik. Wer lieber mit anderen aktiv ist, findet in [[team-wettkampf|Team & Wettkampf]] gemeinsame Ziele und direkte Rückmeldung.',
                        'Du musst dabei nicht auf Leistung trainieren. Auch lockere Treffen, kleine Challenges oder gemeinsames Lernen machen aus Bewegung ein Hobby, das sich langfristig leichter im Alltag hält.'
                    ]],
                ]
            ],
            'sammeln' => [
                'title' => 'Sammeln: aus einzelnen Dingen wird eine Geschichte',
                'sections' => [
                    ['h'=>'Ein gutes Sammelgebiet braucht Grenzen','p'=>[
                        'Bei [[muenzen-geld|Münzen & Geld]] oder [[papier-dokumente|Papier & Dokumente]] hilft eine klare Eingrenzung: Zeitraum, Region, Motiv, Ausgabe oder Zustand. Dadurch wird aus „alles aufheben“ eine Sammlung mit erkennbarem Profil.',
                        'Du musst am Anfang nicht wissen, wohin sich deine Sammlung entwickelt. Es reicht, wenn du Stücke dokumentierst und nach und nach merkst, welche Unterschiede dich wirklich interessieren.'
                    ]],
                    ['h'=>'Technik, Spielzeug und Werkzeuge erzählen Zeitgeschichte','p'=>[
                        '[[technik-medien|Technik & Medien]] zeigt, wie schnell sich Geräte und Formate verändern. [[spielzeug-spiele|Spielzeug & Spiele]] verbindet Design, Erinnerung und oft überraschend viel Kulturgeschichte. In [[werkzeuge-geraete|Werkzeuge & Geräte]] steht dagegen die Funktion und Entwicklung praktischer Dinge im Mittelpunkt.',
                        'Achte nicht nur auf Seltenheit. Zustand, Herkunft, Originalteile und eine nachvollziehbare Geschichte können für eine Sammlung genauso wichtig sein.'
                    ]],
                    ['h'=>'Fundstücke bekommen einen Zusammenhang','p'=>[
                        '[[naturfunde|Naturfunde]] beginnen oft draußen und brauchen später eine saubere Bestimmung und Aufbewahrung. [[werbung-design|Werbung & Design]] macht Gestaltung und Markenentwicklung sichtbar. [[alltagsobjekte|Alltagsobjekte]] zeigen schließlich, wie selbst ganz gewöhnliche Dinge mit der Zeit zu interessanten Zeugnissen werden.',
                        'Fotografiere, beschrifte und ordne früh. Eine gute Dokumentation macht deine Sammlung nicht nur übersichtlicher, sondern lässt dich später auch Zusammenhänge erkennen, die du beim einzelnen Fundstück noch gar nicht gesehen hast.'
                    ]],
                ]
            ],
        ];
        $world_slug = sanitize_key((string)$world_slug);
        return isset($profiles[$world_slug]) ? $profiles[$world_slug] : [];
    }

    private static function render_hub1_bottom_editorial($page, $world_slug) {
        if (!$page instanceof WP_Post) { return ''; }
        $profile = self::hub1_editorial_profile($world_slug);
        if (!$profile || empty($profile['sections'])) { return ''; }
        $html = '<section class="hd-hub1-bottom-copy"><div class="hd-hub1-bottom-inner"><h2>' . esc_html((string)$profile['title']) . '</h2>';
        foreach ((array)$profile['sections'] as $section) {
            $html .= '<section class="hd-hub1-copy-section"><h3>' . esc_html((string)($section['h'] ?? '')) . '</h3>';
            $section_link_budget = 1;
            foreach ((array)($section['p'] ?? []) as $paragraph) {
                $html .= '<p>' . self::hub1_link_tokens($page, (string)$paragraph, $section_link_budget) . '</p>';
                $section_link_budget = 0;
            }
            $html .= '</section>';
        }
        return $html . '</div></section>';
    }

    private static function render_world_hub_hero($page, $world_slug) {
        $title=get_the_title($page);
        $intro=self::hub1_hero_copy($world_slug);
        if($intro==='') {$intro=self::fallback_intro($title,'hub1');}
        // The core world has its own approved scene, independent of HD007 hobby images.
        $figure = in_array($world_slug, self::world_slugs(), true)
            ? '<figure><img src="'.esc_url(self::world_hero_asset($world_slug)).'" alt="'.esc_attr($title).'" width="1400" height="620" fetchpriority="high"></figure>'
            : '';
        return '<section class="hd-page-hero hd-page-hero-world'.($figure===''?' hd-center-no-photo-v150770':'').'"><div class="hd-page-hero-copy"><span class="hd-page-kicker">Hobbywelt</span><h1><span class="hd-page-title-icon">'.self::world_icon_svg($world_slug).'</span>'.esc_html($title).'</h1><p>'.esc_html($intro).'</p><a href="#hd-next-level">Themen entdecken <b>→</b></a></div>'.$figure.'</section>';
    }

    private static function hub2_card_subtitles_v150684() {
        return [
            'airbrush' => 'Farbe fein zerstäuben und kontrolliert schichten.',
            'malen' => 'Farbe, Fläche und eigene Bildideen.',
            'zeichnen' => 'Linie, Form, Schraffur und Perspektive.',
            'cyanotypie' => 'Sonnenlicht, Chemie und tiefblaue Fotogramme.',
            'drohnenfotografie' => 'Perspektiven aus der Luft bewusst gestalten.',
            'dunkelkammerfotografie' => 'Negative entwickeln und Abzüge im Labor belichten.',
            'fotografie' => 'Licht, Motiv und Bildaufbau bewusst einsetzen.',
            'holzschnitt' => 'Motive ins Holz schneiden und drucken.',
            'linolschnitt' => 'Linol schneiden, einfärben und sauber abdrucken.',
            'lochkamerafotografie' => 'Fotografieren mit Lochblende und langen Belichtungen.',
            'nassplattenfotografie' => 'Glasplatten beschichten, belichten und direkt entwickeln.',
            'siebdruck' => 'Schablonen, Siebe und kräftige Farbschichten.',
            'batik' => 'Stoff abbinden, färben und Muster entstehen lassen.',
            'seidenmalerei' => 'Fließende Farben kontrolliert auf Seide führen.',
            'shibori' => 'Falten, binden und reservieren für textile Muster.',
            'textildruck' => 'Motive und Farbe dauerhaft auf Stoff bringen.',
            'miniaturen-bemalen' => 'Grundierung, Farbschichten, Licht und feine Details.',
            'federkiel-schreiben' => 'Feder zuschneiden, Tinte führen und historische Schriftzüge schreiben.',
            'kalligrafie' => 'Federwinkel, Strichstärke und Rhythmus bewusst zusammenspielen lassen.',
            'lettering' => 'Buchstaben zeichnen, variieren und zu eigenen Schriftbildern verbinden.',
            'collage' => 'Bilder, Papier und Fundstücke neu zusammensetzen.',
            'origami' => 'Papier präzise falten und räumlich formen.',
            'paper-quilling' => 'Papierstreifen rollen, formen und zu Motiven setzen.',
            'scrapbooking' => 'Fotos, Erinnerungen und Papier kreativ arrangieren.',
            'glasmalerei' => 'Farbe transparent auf Glas gestalten.',
            'pinstriping' => 'Feine Linien freihändig auf Oberflächen ziehen.',
            'schildermalerei' => 'Buchstaben und Motive klassisch von Hand malen.',
            'brandmalerei' => 'Motive mit Hitze dauerhaft ins Holz zeichnen.',
            'drechseln' => 'Holz rotieren lassen und präzise Formen schneiden.',
            'gruenholzschnitzen' => 'Frisches Holz direkt mit Messer und Beil formen.',
            'holzwerken' => 'Sägen, hobeln, verbinden und Werkstücke bauen.',
            'loeffelschnitzen' => 'Löffel aus Rohholz schnitzen und sauber ausarbeiten.',
            'moebelrestaurierung' => 'Alte Möbel erhalten, reparieren und Oberflächen pflegen.',
            'schnitzen' => 'Holz mit Messer und Eisen plastisch formen.',
            'buchbinden' => 'Vom ersten Falz bis zum fertigen Buch.',
            'marmorpapier' => 'Farbe, Muster und Papier in Bewegung.',
            'papierherstellung' => 'Eigenes Papier Schritt für Schritt herstellen.',
            'stempel-schnitzen' => 'Eigene Motive schneiden und sauber drucken.',
            'zines-herstellen' => 'Kleine Hefte, große Ideen – selbst gemacht.',
            'glasblasen' => 'Heißes Glas am Rohr drehen und formen.',
            'glasfusing' => 'Glasteile im Ofen miteinander verschmelzen.',
            'glasgravur' => 'Motive kontrolliert in Glasoberflächen schneiden.',
            'glasperlen-drehen' => 'Glas am Brenner zu Perlen aufbauen.',
            'keramikglasuren' => 'Farbe, Oberfläche und Brennergebnis gezielt steuern.',
            'raku' => 'Keramik heiß entnehmen und spektakulär nachbehandeln.',
            'tiffanyglas' => 'Glasteile schneiden, einfassen und verlöten.',
            'toepfern' => 'Ton aufbauen, drehen und zu Gefäßen formen.',
            'betonkunst' => 'Beton gießen, strukturieren und dekorativ formen.',
            'cold-porcelain' => 'Lufttrocknende Modelliermasse fein ausarbeiten.',
            'epoxidharzkunst' => 'Harz, Pigmente und Einlagen kontrolliert gießen.',
            'jesmonite' => 'Mineralische Gießmasse färben und in Formen bringen.',
            'kerzengiessen' => 'Wachs, Docht und Form sauber aufeinander abstimmen.',
            'polymer-clay' => 'Modelliermasse formen, härten und detailliert gestalten.',
            'resin-casting' => 'Gießharz blasenarm mischen und präzise formen.',
            'seifenherstellung' => 'Fette, Lauge und Düfte zu eigener Seife verarbeiten.',
            'bean-to-bar-schokolade' => 'Kakaobohnen rösten, mahlen und zu Tafeln verarbeiten.',
            'bier-brauen' => 'Malz, Hopfen und Hefe zum eigenen Bier führen.',
            'cider-herstellen' => 'Apfelsaft vergären und Geschmack gezielt entwickeln.',
            'fermentation' => 'Mikroorganismen für Aroma und Haltbarkeit arbeiten lassen.',
            'kaffee-selbst-roesten' => 'Rohkaffee rösten und Röstprofile vergleichen.',
            'kimchi' => 'Gemüse salzen, würzen und lebendig fermentieren.',
            'koji' => 'Koji-Kulturen für Würze und Fermentation einsetzen.',
            'kombucha' => 'Tee mit Kultur säuern und aromatisch vergären.',
            'kaese-herstellen' => 'Milch säuern, gerinnen lassen und Käse reifen.',
            'pralinenherstellung' => 'Füllungen, Kuvertüre und Temperierung präzise verbinden.',
            'raeuchern' => 'Rauch, Temperatur und Zeit für Aroma steuern.',
            'sauerteig' => 'Mehl und Wasser zu einem aktiven Starter führen.',
            'kettenhemdflechten' => 'Ringe, Muster und bewegliche Geflechte.',
            'kunstschmieden' => 'Zierformen, Ornamente und geschmiedete Details.',
            'metallgiessen' => 'Formen vorbereiten und Metall kontrolliert gießen.',
            'sandguss' => 'Formkasten, Sand und saubere Gussformen.',
            'schmieden' => 'Hitze, Hammerführung und Formgebung am Amboss.',
            'drahtschmuck' => 'Draht biegen, wickeln und zu Schmuck formen.',
            'schmuckherstellung' => 'Metall, Steine und Verschlüsse zu Einzelstücken verbinden.',
            'silberschmieden' => 'Silber sägen, löten, treiben und polieren.',
            'lederarbeiten' => 'Leder schneiden, kanten, nähen und prägen.',
            'sattlerarbeiten' => 'Starkes Leder sauber vernähen und belastbar verbinden.',
            'brettchenweben' => 'Bänder mit gedrehten Kettfäden und Mustern weben.',
            'filzen' => 'Wolle verdichten und zu festen Formen verbinden.',
            'handspinnen' => 'Fasern ausziehen und zu gleichmäßigem Garn verspinnen.',
            'haekeln' => 'Maschen mit einer Nadel zu Flächen und Formen bauen.',
            'kloeppeln' => 'Fäden kreuzen und feine Spitzenmuster klöppeln.',
            'makramee' => 'Knoten zu dekorativen Flächen und Strukturen verbinden.',
            'nadelfilzen' => 'Wolle mit der Filznadel plastisch verdichten.',
            'nassfilzen' => 'Wolle mit Wasser und Reibung zu Flächen filzen.',
            'naehen' => 'Stoff zuschneiden und mit Nähten präzise verbinden.',
            'quilten' => 'Stofflagen verbinden und Muster mit Nähten gestalten.',
            'stricken' => 'Maschen mit zwei Nadeln zu elastischen Flächen formen.',
            'tufting' => 'Garn mit der Tufting-Gun in dichte Flächen setzen.',
            'weben' => 'Kette und Schuss zu eigenen Geweben verbinden.',
            'besenbinden' => 'Naturfasern bündeln und zu funktionalen Besen binden.',
            'korbflechten' => 'Ruten und Flechtmaterial zu stabilen Körben formen.',
            'weidenflechten' => 'Weidenruten wässern, biegen und tragfähig verflechten.',
            'battlebots-modellbau' => 'Robuste Kampfroboter konstruieren und für Matches abstimmen.',
            'roboterbau' => 'Mechanik, Elektronik und Steuerung zu Robotern verbinden.',
            'robotik' => 'Sensoren, Aktoren und Programme zusammenarbeiten lassen.',
            'pc-modding' => 'Gehäuse, Kühlung und Hardware individuell gestalten.',
            'retrocomputer' => 'Alte Rechner nutzen, pflegen und technisch einordnen.',
            'retrocomputer-restaurieren' => 'Vintage-Rechner reparieren und möglichst original erhalten.',
            'alte-spielekonsolen-restaurieren' => 'Konsolen reinigen, reparieren und wieder spielfähig machen.',
            'mechanische-tastaturen-bauen' => 'Switches, Layout und Gehäuse zur eigenen Tastatur kombinieren.',
            '3d-druck' => 'Digitale Modelle Schicht für Schicht entstehen lassen.',
            '3d-scanning' => 'Reale Objekte präzise als 3D-Daten erfassen.',
            'cad-als-hobby' => 'Bauteile und Formen digital konstruieren.',
            'cnc-fraesen' => 'Werkstücke computergesteuert präzise ausfräsen.',
            'lasercutting' => 'Material mit dem Laser exakt schneiden.',
            'lasergravieren' => 'Motive und Beschriftungen mit Laser einbringen.',
            'resin-3d-druck' => 'Feine Modelle mit Harz und Licht drucken.',
            'effektpedale-bauen' => 'Eigene Sounds löten, testen und verfeinern.',
            'eurorack' => 'Module kombinieren und ein eigenes Klangsystem aufbauen.',
            'hifi-selbstbau' => 'Komponenten auswählen und dein Setup selbst entwickeln.',
            'lautsprecherbau' => 'Gehäuse, Chassis und Weichen sinnvoll abstimmen.',
            'plattenspieler-restaurieren' => 'Mechanik pflegen, justieren und wieder sauber spielen lassen.',
            'roehrenverstaerker-bauen' => 'Schaltung, Bauteile und Sicherheit im Blick behalten.',
            'synthesizer-bauen' => 'Klangerzeugung, Oszillatoren und eigene Schaltungen.',
            'modell-dampfmaschinen' => 'Kleine Dampfmaschinen bauen, warten und betreiben.',
            'modellmaschinenbau' => 'Funktionsfähige Maschinen im kleinen Maßstab fertigen.',
            'stirlingmotoren' => 'Wärme in sichtbare mechanische Bewegung verwandeln.',
            'uhren-reparieren' => 'Uhrwerke zerlegen, reinigen und wieder regulieren.',
            'mechanische-uhren-bauen' => 'Räderwerk, Hemmung und Gehäuse zur Uhr verbinden.',
            'arduino' => 'Sensoren und Aktoren mit kleinen Controllern steuern.',
            'elektronikbasteln' => 'Schaltungen aufbauen, messen und sauber verlöten.',
            'mikrocontroller-projekte' => 'Kleine Controller für eigene Geräte programmieren.',
            'raspberry-pi-projekte' => 'Linux, Schnittstellen und Hardware zu Projekten verbinden.',
            'amateurfunk' => 'Funktechnik auf eigenen Frequenzen praktisch betreiben.',
            'cb-funk' => 'Direktfunk auf dem CB-Band nutzen und optimieren.',
            'funkpeilung' => 'Funksignale orten und Sender über Richtung finden.',
            'satellitenfunk' => 'Signale über Amateurfunksatelliten senden und empfangen.',
            'software-defined-radio' => 'Funkspektrum per Software sichtbar und hörbar machen.',
            'wettersonden-tracking' => 'Radiosonden empfangen, verfolgen und wiederfinden.',
            'heimautomatisierung' => 'Licht, Sensoren und Geräte intelligent vernetzen.',
            'drohnenbau' => 'Rahmen, Antrieb und Elektronik zur eigenen Drohne bauen.',
            'fpv-drohnen' => 'Drohnen aus Pilotenperspektive präzise fliegen.',
            'fpv-racing' => 'FPV-Drohnen auf Geschwindigkeit und Kurs abstimmen.',
            'rc-baumaschinen' => 'Bagger und Lader ferngesteuert im Modell bewegen.',
            'rc-boote' => 'Boote bauen, abstimmen und auf dem Wasser steuern.',
            'rc-crawling' => 'Langsam über Felsen und technische Hindernisse klettern.',
            'rc-drift' => 'Fahrwerk und Reifen für kontrollierte Drifts abstimmen.',
            'rc-flugzeuge' => 'Modelle bauen und sicher durch die Luft steuern.',
            'rc-helikopter' => 'Rotorkopf, Steuerung und Fluglage beherrschen.',
            'rc-lkw' => 'Nutzfahrzeuge detailreich bauen und ferngesteuert bewegen.',
            'rc-offroad' => 'Fahrwerk und Antrieb für loses Gelände abstimmen.',
            'rc-panzer' => 'Kettenfahrzeuge technisch und optisch im Modell bauen.',
            'rc-segelboote' => 'Segelstellung und Kurs ferngesteuert aufeinander abstimmen.',
            'rc-segelflug' => 'Thermik und sauberen Gleitflug im Modell nutzen.',
            'rc-u-boote' => 'Tauchtechnik und Steuerung unter Wasser beherrschen.',
            'scale-crawling' => 'Geländegängigkeit mit möglichst realistischer Optik verbinden.',
            'amateurastronomie' => 'Den Nachthimmel systematisch beobachten und einordnen.',
            'astrofotografie' => 'Himmelsobjekte lange belichten und sauber nachführen.',
            'deep-sky-fotografie' => 'Nebel und Galaxien mit langen Belichtungen sichtbar machen.',
            'mondfotografie' => 'Mondstrukturen scharf und kontrastreich aufnehmen.',
            'planetenfotografie' => 'Planeten mit hoher Vergrößerung detailreich abbilden.',
            'radioastronomie' => 'Kosmische Radiosignale empfangen und auswerten.',
            'sonnenbeobachtung' => 'Sonnenflecken und Aktivität mit geeignetem Filter beobachten.',
            'teleskop-astronomie' => 'Optik auswählen, ausrichten und Himmelsobjekte finden.',
            'gewaessermikroskopie' => 'Mikroleben aus Gewässerproben unter dem Mikroskop entdecken.',
            'hobby-mikroskopie' => 'Präparate vorbereiten und Strukturen im Kleinen untersuchen.',
            'kristallmikroskopie' => 'Kristalle wachsen lassen und ihre Formen mikroskopisch betrachten.',
            'mikrofotografie' => 'Mikroskopische Details sauber fotografisch dokumentieren.',
            'planktonbeobachtung' => 'Plankton sammeln, bestimmen und lebend beobachten.',
            'polarisationsmikroskopie' => 'Strukturen mit polarisiertem Licht sichtbar machen.',
            'teichwasser-mikroskopie' => 'Teichproben nehmen und ihre Bewohner bestimmen.',
            'blitzfotografie' => 'Blitze sicher aus Distanz fotografisch einfangen.',
            'gewittertracking' => 'Gewitterzellen auf Karten verfolgen und dokumentieren.',
            'luftqualitaetsmessung' => 'Feinstaub und Luftwerte mit Sensoren erfassen.',
            'storm-spotting' => 'Gewitterstrukturen beobachten und Wetterlagen einordnen.',
            'wetterbeobachtung' => 'Wolken, Wind und Wetterverlauf regelmäßig dokumentieren.',
            'private-wetterstation' => 'Temperatur, Wind, Regen und Luftdruck selbst messen.',
            'bioakustik' => 'Tierstimmen aufnehmen, analysieren und Arten zuordnen.',
            'birding' => 'Vögel beobachten, erkennen und sicher bestimmen.',
            'fledermausbeobachtung' => 'Fledermäuse mit Detektoren hören und beobachten.',
            'schmetterlingsbeobachtung' => 'Arten, Flugzeiten und Lebensräume aufmerksam verfolgen.',
            'wildkameras' => 'Wildtiere ungestört mit automatischen Kameras dokumentieren.',
            'bodenanalyse' => 'Bodenwerte messen und Eigenschaften von Böden vergleichen.',
            'elektrochemie-als-hobby' => 'Redoxreaktionen, Elektrolyse und Messungen praktisch untersuchen.',
            'plane-spotting' => 'Flugzeuge erkennen, fotografieren und Bewegungen dokumentieren.',
            'spektroskopie' => 'Licht in Spektren zerlegen und Stoffe erkennen.',
            'wasseranalyse' => 'Wasserwerte messen und chemisch einordnen.',
            'bonsai' => 'Bäume klein halten, formen und langfristig entwickeln.',
            'pflanzenvermehrung' => 'Pflanzen durch Teilung, Ableger oder Samen vermehren.',
            'stecklingszucht' => 'Triebe bewurzeln und zu kräftigen Jungpflanzen ziehen.',
            'seltene-zimmerpflanzen' => 'Besondere Arten kultivieren und Bedingungen gezielt anpassen.',
            'kakteen' => 'Kakteen trocken, hell und artspezifisch kultivieren.',
            'lithops' => 'Lebende Steine durch Ruhe- und Wachstumsphasen führen.',
            'sukkulenten' => 'Wasserspeichernde Pflanzen passend zu Licht und Substrat pflegen.',
            'bromelien' => 'Rosettenpflanzen zwischen Wassertrichter und Luftfeuchte pflegen.',
            'orchideenzucht' => 'Orchideen vermehren und auf Blüte kultivieren.',
            'tillandsien' => 'Luftpflanzen ohne Erde richtig versorgen.',
            'fleischfressende-pflanzen' => 'Karnivoren mit passendem Wasser und Substrat kultivieren.',
            'aeroponik' => 'Wurzeln frei hängen lassen und mit Nährnebel versorgen.',
            'hydrokultur' => 'Pflanzen in mineralischem Substrat mit Wasserstand kultivieren.',
            'hydroponik' => 'Nährlösung ohne Erde kontrolliert an die Wurzeln bringen.',
            'indoor-growing' => 'Licht, Klima und Nährstoffe im Innenraum steuern.',
            'microgreens' => 'Jungpflanzen dicht aussäen und früh ernten.',
            'semi-hydro' => 'Mineralisches Substrat und Reservoir für Zimmerpflanzen nutzen.',
            'pilzzucht' => 'Pilzmyzel auf geeignetem Substrat kultivieren.',
            'speisepilzzucht' => 'Essbare Pilze von der Kultur bis zur Ernte ziehen.',
            'chili-zucht' => 'Chilisorten auswählen, kreuzen und über Generationen stabilisieren.',
            'pflanzenkreuzungen' => 'Eigenschaften gezielt durch Bestäubung neu kombinieren.',
            'riesenkuerbis-zucht' => 'Genetik, Nährstoffe und Wachstum auf Größe ausrichten.',
            'saatguterhaltung' => 'Sorten durch saubere Vermehrung langfristig bewahren.',
            'tomatensorten-zucht' => 'Tomaten kreuzen, selektieren und eigene Linien entwickeln.',
            'kokedama' => 'Pflanzen in moosummantelten Ballen inszenieren.',
            'kusamono' => 'Gräser und kleine Pflanzen als stille Komposition gestalten.',
            'mooskultur' => 'Moose passend zu Feuchte, Licht und Untergrund kultivieren.',
            'wabikusa' => 'Wasserpflanzen emers zu kleinen Landschaften arrangieren.',
            'gemueseanbau' => 'Gemüse von Aussaat bis Ernte im eigenen Beet ziehen.',
            'biotop-aquarien' => 'Natürliche Lebensräume im Aquarium gezielt nachbilden.',
            'garnelenhaltung' => 'Garnelen mit passenden Wasserwerten und Struktur halten.',
            'meerwasseraquaristik' => 'Salzwasser, Technik und empfindliche Tiere stabil führen.',
            'nano-aquaristik' => 'Kleine Aquarien mit besonders sorgfältiger Balance betreiben.',
            'quallen-aquarium' => 'Strömung und Wasserqualität für Quallen abstimmen.',
            'riffaquaristik' => 'Korallenriff-Systeme mit Licht, Strömung und Chemie pflegen.',
            'schwarzwasser-aquarien' => 'Huminstoffreiche, weiche Gewässer naturgetreu nachbilden.',
            'reptilienhaltung' => 'Temperatur, Licht und Lebensraum reptiliengerecht gestalten.',
            'skorpionhaltung' => 'Verstecke, Klima und Sicherheit passend zur Art planen.',
            'vogelspinnenhaltung' => 'Boden, Feuchte und Rückzugsorte artgerecht einrichten.',
            'imkerei' => 'Bienenvölker führen, Honig ernten und Gesundheit beobachten.',
            'schmetterlingsgaerten' => 'Nektar- und Raupenpflanzen für Falter gezielt kombinieren.',
            'artemia-zucht' => 'Salinenkrebse zuverlässig als Lebendfutter vermehren.',
            'daphnien-zucht' => 'Wasserflöhe in stabilen Kulturen vermehren.',
            'futtertierzucht' => 'Lebendfutter bedarfsgerecht und hygienisch nachziehen.',
            'regenwurmzucht' => 'Würmer für Futter oder Kompost gezielt vermehren.',
            'triops' => 'Urzeitkrebse aus Dauereiern bis zur Reife aufziehen.',
            'ameisenhaltung' => 'Kolonien in passenden Nestern beobachten und versorgen.',
            'gottesanbeterinnen' => 'Mantiden einzeln halten, füttern und Häutungen begleiten.',
            'kaeferzucht' => 'Käfer vom Larvenstadium bis zum adulten Tier züchten.',
            'schmetterlingszucht' => 'Raupen füttern und Entwicklung bis zum Falter begleiten.',
            'stabschreckenhaltung' => 'Phasmiden mit Futterpflanzen und passendem Klima halten.',
            'asselhaltung' => 'Asseln in feuchten, strukturierten Habitaten pflegen.',
            'isopoden-zucht' => 'Farbformen und Arten von Isopoden gezielt vermehren.',
            'bioactive-terrariums' => 'Bodenleben, Pflanzen und Tiere zu einem System verbinden.',
            'formicarienbau' => 'Nestkammern, Arena und Klima für Ameisen konstruieren.',
            'angeln' => 'Gewässer lesen, Köder führen und Fische waidgerecht fangen.',
            'bikepacking' => 'Rad, Gepäck und Übernachtung für Touren minimal planen.',
            'bushcraft' => 'Draußen mit Werkzeug, Feuer und Naturmaterial arbeiten.',
            'camping' => 'Schlafplatz, Ausrüstung und Versorgung draußen organisieren.',
            'geocaching' => 'Koordinaten, Rätsel und Verstecke draußen verbinden.',
            'hammock-camping' => 'Hängematte, Tarp und Aufhängung sicher kombinieren.',
            'mikroabenteuer' => 'Kurze Auszeiten draußen ohne große Reise planen.',
            'orientierungslauf' => 'Karte, Kompass und Tempo im Gelände verbinden.',
            'packrafting' => 'Leichte Boote für kombinierte Land-Wasser-Touren nutzen.',
            'radfahren' => 'Touren, Technik und passendes Rad zusammenbringen.',
            'tarp-camping' => 'Mit Plane, Abspannpunkten und wenigen Teilen Schutz bauen.',
            'wandern' => 'Strecke, Tempo und Ausrüstung auf Tour abstimmen.',
            'wintercamping' => 'Kälte, Feuchtigkeit und Wärmeversorgung im Camp beherrschen.',
            'balance-board' => 'Gleichgewicht auf einer beweglichen Unterlage trainieren.',
            'einradfahren' => 'Balance, Pedaldruck und Körperhaltung auf einem Rad koordinieren.',
            'highlining' => 'Auf langen Lines in großer Höhe kontrolliert balancieren.',
            'longboard-dancing' => 'Schritte und Drehungen fließend auf dem Longboard verbinden.',
            'mountain-unicycling' => 'Einradtechnik auf Trails und unebenem Gelände einsetzen.',
            'mountainboarding' => 'Mit großen Rollen kontrolliert über Gelände fahren.',
            'pumptrack' => 'Kurven und Wellen ohne Treten durch Körperarbeit nutzen.',
            'slacklining' => 'Balance und Körperspannung auf dem Band halten.',
            '3d-bogenschiessen' => 'Auf dreidimensionale Ziele im Gelände schießen.',
            'blasrohrsport' => 'Pfeile mit Atemdruck präzise ins Ziel bringen.',
            'bogenschiessen' => 'Bogen, Auszug und sauberen Schussablauf abstimmen.',
            'boomerangwerfen' => 'Wurfwinkel und Rotation für die Rückkehr kontrollieren.',
            'discgolf' => 'Scheiben mit unterschiedlichen Flugbahnen Richtung Korb werfen.',
            'traditionelles-bogenschiessen' => 'Instinktiven Schuss und traditionelle Bögen verbinden.',
            'freediving' => 'Atemtechnik und Entspannung für Tauchgänge ohne Flasche.',
            'kanutouren' => 'Paddeltechnik, Strecke und Gepäck fürs Kanu planen.',
            'schwimmen' => 'Wasserlage, Atmung und Zugtechnik effizient verbinden.',
            'stand-up-paddling-touren' => 'Balance und Paddelschlag für längere SUP-Touren nutzen.',
            'baumklettern' => 'Mit Seiltechnik sicher in Baumkronen aufsteigen.',
            'bouldern' => 'Kraft, Technik und Bewegungsrätsel in Absprunghöhe.',
            'klettern' => 'Griffe, Tritte und Sicherung an der Wand verbinden.',
            'drachenbau' => 'Rahmen, Bespannung und Waage zum flugfähigen Drachen bauen.',
            'kite-buggy' => 'Zugdrachen nutzen, um einen Buggy kontrolliert anzutreiben.',
            'landkiten' => 'Kitezug am Boden kontrollieren und Fahrtechnik entwickeln.',
            'powerkiting' => 'Kraftvolle Lenkdrachen sicher beherrschen.',
            'sportdrachen' => 'Lenkdrachen präzise durch Figuren und Kurven führen.',
            'trick-kiting' => 'Drachen kontrolliert in komplexe Flugfiguren bringen.',
            'drone-soccer' => 'Drohnen im Team durch Tore und enge Manöver steuern.',
            'footgolf' => 'Fußball mit Präzision über einen Golfkurs spielen.',
            'hema' => 'Historische europäische Kampfkünste nach Quellen trainieren.',
            'jugger' => 'Laufspiel, Teamtaktik und gepolsterte Sportgeräte verbinden.',
            'speedminton' => 'Schnelles Rückschlagspiel ohne Netz und feste Feldgrenzen.',
            'teqball' => 'Fußballtechnik kontrolliert über den gewölbten Tisch spielen.',
            'ultimate-frisbee' => 'Laufwege und präzise Scheibenpässe im Team verbinden.',
            'historisches-fechten' => 'Historische Waffen mit Technik und Quellenarbeit trainieren.',
            'cardistry' => 'Spielkarten durch Fächer, Cuts und Flourishes bewegen.',
            'contact-juggling' => 'Kugeln scheinbar schwerelos über Hände und Körper führen.',
            'diabolo' => 'Rotation, Schnurführung und Tricks mit dem Diabolo verbinden.',
            'kendama' => 'Ball und Becher mit Rhythmus und Präzision kontrollieren.',
            'pen-spinning' => 'Stifte flüssig zwischen Fingern rotieren lassen.',
            'poi' => 'Gewichtete Schnüre in rhythmischen Figuren schwingen.',
            'speedcubing' => 'Zauberwürfel mit Algorithmen und Fingertechnik schnell lösen.',
            'yo-yo-tricks' => 'Schnurspannung, Rotation und Figuren am Yo-Yo kombinieren.',
            'banknoten' => 'Druck, Serien, Länder und Erhaltung von Geldscheinen.',
            'medaillen' => 'Anlässe, Prägungen und Gestaltung von Medaillen einordnen.',
            'muenzen' => 'Prägungen nach Zeit, Herkunft und Zustand sammeln.',
            'notgeld' => 'Regionale Ersatzwährungen und ihre Geschichte dokumentieren.',
            'numismatik' => 'Münzen wissenschaftlich bestimmen, ordnen und bewerten.',
            'tokens' => 'Marken und Wertzeichen nach Nutzung und Herkunft sammeln.',
            'briefmarken-sammeln' => 'Ausgaben, Motive und Stempel systematisch ordnen.',
            'ephemera-sammeln' => 'Vergängliche Drucksachen als Zeitzeugnisse bewahren.',
            'exlibris-sammeln' => 'Künstlerische Bucheignerzeichen sammeln und zuordnen.',
            'landkarten-sammeln' => 'Karten nach Region, Epoche und Darstellung vergleichen.',
            'historische-postkarten' => 'Ansichten, Verlage und Postgeschichte gemeinsam lesen.',
            'fuellfederhalter-sammeln' => 'Federn, Füllsysteme und Modelle historisch einordnen.',
            'kameras' => 'Kameratechnik, Formate und Modellgeschichte sammeln.',
            'kassetten' => 'Bandtypen, Editionen und Aufnahmen analog bewahren.',
            'minidiscs' => 'Recorder, Discs und frühe digitale Audiotechnik sammeln.',
            'radios' => 'Empfänger nach Epoche, Technik und Design einordnen.',
            'schallplatten' => 'Pressungen, Labels und Zustand von Vinyl vergleichen.',
            'taschenrechner' => 'Rechentechnik im Taschenformat nach Generationen sammeln.',
            'alte-computer' => 'Hardwaregeschichte durch originale Rechner bewahren.',
            'modellautos' => 'Maßstäbe, Hersteller und Fahrzeugvarianten sammeln.',
            'spielfiguren' => 'Figurenserien, Varianten und Zubehör zusammenführen.',
            'spielkarten' => 'Decks nach Gestaltung, Herkunft und Ausgabe sammeln.',
            'tarotdecks' => 'Illustrationsstile und Editionen verschiedener Tarotdecks sammeln.',
            'wuerfel' => 'Formen, Materialien und besondere Würfelsätze sammeln.',
            'fossilien-sammeln' => 'Versteinerungen bestimmen, präparieren und dokumentieren.',
            'meteoriten-suchen' => 'Außerirdisches Gestein erkennen und Fundstücke prüfen.',
            'mineralien-sammeln' => 'Kristalle nach Art, Fundort und Ausbildung ordnen.',
            'blechschilder' => 'Bedruckte Metallschilder als Werbe- und Designgeschichte sammeln.',
            'emailschilder' => 'Emaillierte Schilder nach Marke, Zustand und Alter einordnen.',
            'filmplakate' => 'Kinogeschichte über originale Plakate und Varianten sammeln.',
            'historische-reklame' => 'Alte Markenwerbung als Zeit- und Designzeugnis bewahren.',
            'hobel' => 'Hobel nach Bauart, Hersteller und Einsatzgebiet sammeln.',
            'messinstrumente' => 'Historische Messgeräte technisch und zeitlich einordnen.',
            'schraubstoecke' => 'Bauformen und Hersteller alter Spannwerkzeuge vergleichen.',
            'historische-werkzeuge-sammeln' => 'Werkzeuge nach Handwerk, Epoche und Funktion dokumentieren.',
            'knoepfe' => 'Knöpfe nach Material, Zeit und Gestaltung sammeln.',
            'parfuemflakons' => 'Flakons nach Design, Marke und Glasarbeit einordnen.',
            'schloesser' => 'Schließmechanik und Bauformen historischer Schlösser vergleichen.',
            'vorhaengeschloesser' => 'Vorhängeschlösser nach Technik, Form und Hersteller sammeln.',
            'alte-schluessel' => 'Schlüssel nach Form, Schlossart und Epoche ordnen.',
            'trainspotting' => 'Lokomotiven, Baureihen und Zugläufe systematisch dokumentieren.',
            'ship-spotting' => 'Schiffstypen, Reedereien und Routen vom Ufer aus erfassen.',
            'car-spotting' => 'Modelle, Generationen und seltene Fahrzeuge gezielt erkennen.',
            'nachtvogel-beobachtung' => 'Rufe, Silhouetten und Verhalten nachtaktiver Vögel beobachten.',
            'libellenbeobachtung' => 'Arten an Gewässern über Flugbild, Farbe und Sitzhaltung unterscheiden.',
            'kaeferbeobachtung' => 'Käfer über Körperform, Lebensraum und Verhalten genauer kennenlernen.',
            'tierspuren-dokumentieren' => 'Fährten, Fraßspuren und andere Hinweise fotografisch festhalten.',
            'wolkenbeobachtung' => 'Wolkenformen, Entwicklung und Wetterzusammenhang am Himmel verfolgen.',
            'dioramenbau' => 'Szenen mit Maßstab, Gelände, Figuren und Alterung glaubwürdig aufbauen.',
            'miniaturwelten' => 'Kleine Szenen aus Gebäuden, Figuren, Licht und Details gestalten.',
            'book-nooks' => 'Beleuchtete Miniaturszenen passgenau zwischen Büchern bauen.',
            'architekturmodellbau' => 'Gebäude und Räume maßstäblich, sauber und materialgerecht darstellen.',
            'sondeln-metalldetektion' => 'Suchflächen, Signale und Funddokumentation rechtssicher miteinander verbinden.',
            'magnetfischen' => 'Metallfunde aus Gewässern bergen und unbekannte Funde sicher einordnen.',
            'goldwaschen' => 'Sediment auswaschen und schwere Minerale konzentriert auslesen.',
            'edelsteinsuche' => 'Fundorte beurteilen und Mineralfunde schonend bergen und bestimmen.',
            'fossiliensuche' => 'Gesteinsschichten lesen und Fossilien mit Fundkontext dokumentieren.',
            'bernstein-suchen' => 'Strandbedingungen nutzen und echte Bernsteinfunde von Ähnlichem unterscheiden.',
            'mudlarking' => 'Historische Uferfunde suchen, einordnen und Fundregeln beachten.',
            'bottle-digging' => 'Alte Flaschenfundstellen erforschen und Glasfunde datieren.',
            'modellbahn' => 'Gleisplan, Landschaft, Fahrzeuge und Betrieb zu einer Anlage verbinden.',
            'schiffsmodellbau' => 'Rumpf, Decks und Takelage maßstäblich und sauber aufbauen.',
            'flugzeugmodellbau' => 'Zellen, Tragflächen, Lackierung und Details maßstäblich umsetzen.',
            'automodellbau' => 'Karosserie, Fahrwerk und Details eines Fahrzeugs im Maßstab nachbilden.',
            'funktionsmodelle' => 'Modelle mit beweglichen, steuerbaren oder technisch arbeitenden Funktionen bauen.',
            'modellraketen' => 'Modellraketen als geregeltes Hobby mit sicheren Starts und Bergung betreiben.',
            'vogelzaehlungen' => 'Arten und Individuen nach festem Schema erfassen und melden.',
            'insektenkartierung' => 'Insektenfunde bestimmen, verorten und für Verbreitungskarten dokumentieren.',
            'wildtiermonitoring' => 'Wildtiere mit standardisierten Beobachtungen langfristig erfassen.',
            'phaenologie' => 'Blüte, Austrieb und andere Jahreszeitenereignisse systematisch melden.',
            'pilzbestimmung' => 'Pilze über Merkmale und Standort einordnen, ohne Verzehrfreigabe zu ersetzen.',
            'pflanzenbestimmung' => 'Blätter, Blüten und Wuchsmerkmale mit Bestimmungsschlüsseln vergleichen.',
            'flechtenbestimmung' => 'Wuchsform, Farbe und Substrat zur Einordnung von Flechten nutzen.',
            'moosbestimmung' => 'Blättchen, Wuchsform und Standort unter Lupe genauer vergleichen.',
            'puppenhaeuser' => 'Räume, Möbel und Ausstattung in einem stimmigen Maßstab gestalten.',
            'schneckenhaltung' => 'Feuchte, Kalk, Futter und Rückzugsorte artgerecht abstimmen.',
            'seeglas-sammeln' => 'Geschliffene Glasstücke nach Farbe, Form und Herkunft dokumentieren.',
            'muscheln-sammeln' => 'Muschelschalen bestimmen, Fundorte notieren und Schutzregeln beachten.',
            'strandgut-sammeln' => 'Angespülte Funde auswählen, reinigen und nach Herkunft ordnen.',
            'mikrometeoriten-sammeln' => 'Kleine kosmische Partikel suchen, prüfen und nachvollziehbar dokumentieren.',
            'lederpraegen' => 'Muster und Motive kontrolliert in angefeuchtetes Leder einarbeiten.',
            'schuhmacherei' => 'Leisten, Schaft, Sohlen und Passform zu tragbaren Schuhen verbinden.',
            'penjing' => 'Bäume, Steine und Landschaftselemente als chinesische Miniaturszene gestalten.',
            'saikei' => 'Mehrere Pflanzen und Steine zu einer kleinen Landschaft komponieren.',
            'kraeuteranbau' => 'Küchen- und Teekräuter passend zu Licht, Boden und Ernte pflegen.',
            'obst-im-kuebel' => 'Kompakte Obstsorten in geeigneten Gefäßen dauerhaft versorgen.',
            'wildbienenhotels' => 'Nisthilfen mit passenden Röhren, Schutz und Umgebung sinnvoll bauen.',
            'hummelkaesten' => 'Nistkästen für Hummeln standortgerecht aufstellen und betreuen.',
            'paludarium' => 'Land- und Wasserbereich mit Pflanzen, Technik und Klima verbinden.',
            'terrarienbau' => 'Belüftung, Beleuchtung und Einrichtung passend zum Tier planen.',
        ];
    }

    private static function next_level_card_subtitle($child, $type, $world_slug='') {
        if (!$child instanceof WP_Post) { return ''; }
        $slug = sanitize_title((string)$child->post_name);
        $title_key = sanitize_title((string)get_the_title($child));

        if ($type === 'hub2') {
            $map = self::hub2_card_subtitles_v150684();
            if (isset($map[$slug])) { return (string)$map[$slug]; }
            if (isset($map[$title_key])) { return (string)$map[$title_key]; }
            // New/unmapped child: prefer a real editorial line; never fall back to a generic world template.
            $manual = self::page_intro($child);
            if ($manual !== '') {
                $manual = trim(wp_strip_all_tags($manual));
                return wp_trim_words($manual, 10, '…');
            }
            return '';
        }

        if ($world_slug === 'gestalten' && $type === 'hub1') {
            $map = [
                'druck-fotografie' => 'Drucken, belichten, gestalten.',
                'malen-zeichnen' => 'Farbe, Linie, Ausdruck.',
                'miniaturen-szenen' => 'Kleine Welten selbst bauen.',
                'oberflaeche-deko' => 'Veredeln, gestalten, dekorieren.',
                'oberflache-deko' => 'Veredeln, gestalten, dekorieren.',
                'papierkunst' => 'Falten, schneiden, formen.',
                'schrift-lettering' => 'Buchstaben kreativ gestalten.',
                'textilgestaltung' => 'Nähen, färben, verzieren.',
            ];
            $key = isset($map[$title_key]) ? $title_key : (isset($map[$slug]) ? $slug : '');
            if ($key === '') {
                foreach ($map as $candidate => $line) {
                    if (strpos($title_key, $candidate) !== false || strpos($slug, $candidate) !== false) { $key = $candidate; break; }
                }
            }
            if ($key !== '') { return $map[$key]; }
        }
        return '';
    }

    private static function next_level_child_photos_allowed_v150778($page, $type, $world_slug) {
        if (!$page instanceof WP_Post) { return false; }
        if ($type === 'hub1') { return true; }
        // Exactly the complete Hub2 category level across all eight CORE worlds.
        // Other depths, editorial pages, start page and register stay unchanged.
        return $type === 'hub2' && in_array(sanitize_key((string)$world_slug), self::world_slugs(), true);
    }

    private static function next_level_card_photo($child, $type, $world_slug, $index=0) {
        if (!$child instanceof WP_Post || !in_array($type, ['hub1','hub2'], true)) { return ''; }
        $img = self::category_image_v150774((string)$child->post_name, $child, $world_slug, true);
        if (empty($img['url'])) { return ''; }
        return '<span class="hd-next-photo"><img src="'.esc_url((string)$img['url']).'" alt="'.esc_attr(get_the_title($child)).'" loading="lazy" decoding="async"></span>';
    }

    private static function balanced_row_sizes($count) {
        $count=max(0,(int)$count); $rows=[];
        while($count>0) {
            if($count===4){$rows[] = 2; $rows[] = 2; break;}
            if($count>=3){$rows[] = 3; $count-=3; continue;}
            $rows[]=$count; break;
        }
        return $rows;
    }

    private static function card_row_sizes($count) {
        $sizes=[];
        foreach(self::balanced_row_sizes($count) as $row_size){ for($i=0;$i<$row_size;$i++){$sizes[]=$row_size;} }
        return $sizes;
    }

    private static function is_buch_papier_pilot($page, $type) {
        return $type === 'hub2' && $page instanceof WP_Post && sanitize_title((string)$page->post_name) === 'buch-papier';
    }
    private static function buch_papier_pilot_intro($page, $world_slug='') {
        if (!$page instanceof WP_Post) { return ''; }
        $title = trim((string)get_the_title($page));
        $editorial = self::hub2_editorial($page);
        if (!empty($editorial)) {
            $hero_intro = trim((string)($editorial['hero'] ?? ''));
            $visible = trim((string)($editorial['lead'] ?? ''));
            $more = trim((string)($editorial['more'] ?? ''));
        } else {
            $copy = self::hub2_top_copy($page, $world_slug);
            [$hero_intro,$visible,$more] = self::hub2_layout_parts($copy);
        }
        $visible = trim(preg_replace('/\s+/u', ' ', (string)$visible));
        $more = trim((string)$more);
        if ($more !== '') {
            $more_parts = preg_split('/\R\s*\R/u', $more);
            $more_parts = array_values(array_filter(array_map(static function($part){
                return trim(preg_replace('/\s+/u', ' ', (string)$part));
            }, (array)$more_parts), static function($part){ return $part !== ''; }));
            $more = implode("\n\n", $more_parts);
        }
        $slug = sanitize_title((string)$page->post_name);
        $center_image = self::category_image_v150774($slug, $page, $world_slug);
        $img = !empty($center_image['url']) ? (string)$center_image['url'] : '';
        $scene = ['w'=>!empty($center_image['width'])?(int)$center_image['width']:1600,
                  'h'=>!empty($center_image['height'])?(int)$center_image['height']:587];
        $claim = self::hub2_claim($title, $world_slug);
        $brush = plugin_dir_url(dirname(__FILE__)).'assets/hobby-depot-v150641/brush-underline-v150641.webp?ver='.rawurlencode(self::RELEASE);
        $hero_class = 'hd-page-intro hd-hub2-intro hd-bp-hero hd-hub2-hero-fullbleed hd-hub2-scene-preserve';
        if (!empty($scene['native600'])) { $hero_class .= ' hd-hub2-scene-native600'; }
        $scene_w = max(1, (int)($scene['w'] ?? 1600));
        $scene_h = max(1, (int)($scene['h'] ?? 587));
        $scene_style = '--hd-scene-w:'.$scene_w.'px;--hd-scene-h:'.$scene_h.'px;--hd-scene-ratio:'.$scene_w.'/'.$scene_h.';';
        if ($img==='') { $hero_class .= ' hd-center-no-photo-v150770'; }
        $html = '<section class="'.esc_attr($hero_class).'" style="'.esc_attr($scene_style).'"><div class="hd-bp-hero-copy">';
        $html .= '<span class="hd-bp-brush-claim" style="--hd-bp-brush:url(&quot;'.esc_url($brush).'&quot;)">'.esc_html($claim).'</span>';
        $html .= '<h1>'.esc_html($title).'</h1>';
        if($hero_intro!==''){$html.='<div class="hd-hub2-hero-intro">'.self::paragraph_markup($hero_intro,2).'</div>';}
        $html .= '</div>';
        if ($img!=='') { $html.='<div class="hd-bp-hero-media"><img src="'.esc_url($img).'" alt="'.esc_attr($title).'" decoding="async" fetchpriority="high"></div>'; }
        $html .= '</section>';
        if($visible!=='' || $more!==''){
            $longcopy_class = 'hd-hub2-longcopy';
            $longcopy_class .= ' hd-hub2-longcopy-benchmark-v150698';
            $html.='<section class="'.esc_attr($longcopy_class).'" aria-label="Mehr zu '.esc_attr($title).'">';
            if($visible!==''){$html.='<div class="hd-hub2-longcopy-lead"><p>'.esc_html($visible).'</p></div>';}
            if($more!==''){
                $html.='<details class="hd-hub2-more"><summary aria-label="Mehr zu '.esc_attr($title).' anzeigen"><span class="screen-reader-text">Mehr zu '.esc_html($title).' anzeigen</span></summary><div>'.self::paragraph_markup_explicit_v150698($more).'</div></details>';
            }
            $html.='</section>';
        }
        return $html;
    }

    private static function buch_papier_pilot_cards($page) {
        if (!$page instanceof WP_Post) { return ''; }
        $children=self::direct_page_children($page->ID); if(!$children){return '';}
        $photos=[
            'buchbinden'=>'buchbinden.webp',
            'marmorpapier'=>'marmorpapier.webp',
            'papierherstellung'=>'papierherstellung.webp',
            'stempel-schnitzen'=>'stempel-schnitzen.webp',
            'zines-herstellen'=>'zines-herstellen.webp',
            'zines'=>'zines-herstellen.webp',
        ];
        $lines=[
            'buchbinden'=>'Vom ersten Falz bis zum fertigen Buch.',
            'marmorpapier'=>'Farbe, Muster und Papier in Bewegung.',
            'papierherstellung'=>'Eigenes Papier Schritt für Schritt herstellen.',
            'stempel-schnitzen'=>'Eigene Motive schneiden und sauber drucken.',
            'zines-herstellen'=>'Kleine Hefte, große Ideen – selbst gemacht.',
            'zines'=>'Kleine Hefte, große Ideen – selbst gemacht.',
        ];
        $valid=[];
        foreach($children as $child){
            if(!$child instanceof WP_Post){continue;}
            $slug=sanitize_title((string)$child->post_name);
            $title_key=sanitize_title((string)get_the_title($child));
            $key=isset($photos[$slug])?$slug:(isset($photos[$title_key])?$title_key:'');
            if($key!==''){$valid[]=[$child,$key];}
        }
        if(!$valid){return '';}
        $count=count($valid); $rem=$count%3;
        $parts=self::integrated_affiliate_components('hub2',get_the_title($page));
        $banner_span=$rem===1?2:($rem===2?1:3);
        $banner=self::inline_partner_banner($parts,$banner_span);
        // Exact Ebene-1 rule: if a banner fills the incomplete final row, every category card remains a 1/3 card.
        $row_sizes=$banner!==''?array_fill(0,$count,3):self::card_row_sizes($count);
        $items=[];
        foreach($valid as $index=>$pair){
            [$child,$key]=$pair;
            $img = self::category_image_v150774((string)$child->post_name, $child, $world_slug, true);
            $line=$lines[$key]??'';
            $row_size=(int)($row_sizes[$index]??3); $row_class=' hd-row-size-'.max(1,min(3,$row_size));
            $photo=!empty($img['url'])?'<span class="hd-next-photo"><img src="'.esc_url((string)$img['url']).'" alt="'.esc_attr(get_the_title($child)).'" loading="lazy" decoding="async"></span>':'';
            $items[]='<a class="hd-next-card'.($photo!==''?' has-photo':'').$row_class.'" href="'.esc_url(get_permalink($child)).'">'.$photo.'<span class="hd-next-card-body"><span class="hd-next-copy"><strong>'.esc_html(get_the_title($child)).'</strong>'.($line!==''?'<small>'.esc_html($line).'</small>':'').'</span><b aria-hidden="true">→</b></span></a>';
        }
        $grid=implode('',$items); if($banner!==''){$grid.=$banner;}
        return '<section id="hd-next-level" class="hd-portal-section hd-next-level"><header><h2>Weiter in '.esc_html(get_the_title($page)).'</h2></header><div class="hd-next-grid hd-next-count-'.intval($count).' '.($count%2?'hd-next-odd':'hd-next-even').'">'.$grid.'</div></section>';
    }

    private static function render_next_level($page, $type, $world_slug) {
        if (!$page instanceof WP_Post) { return ''; }
        $children = self::direct_page_children($page->ID);
        $term_children = !$children ? self::direct_category_children_for_page($page) : [];
        if (!$children && !$term_children) { return ''; }

        $parts=self::integrated_affiliate_components($type,get_the_title($page));
        $count=$children ? count($children) : count($term_children);
        $rem=$count%3; $banner_span=$rem===1?2:($rem===2?1:3);
        $banner=self::inline_partner_banner($parts,$banner_span);
        $row_sizes=$banner!==''?array_fill(0,$count,3):self::card_row_sizes($count);
        $items=[]; $index=0;

        if ($children) {
            foreach ($children as $child) {
                if (!$child instanceof WP_Post) { continue; }
                $intro=self::next_level_card_subtitle($child,$type,$world_slug);
                $row_size=(int)($row_sizes[$index]??3); $row_class=' hd-row-size-'.max(1,min(3,$row_size)); $index++;
                // 1.50.778: Apply the already approved photo-card output consistently
                // to all CORE Hub2 category pages, with no changes to other depths.
                $photo = self::next_level_child_photos_allowed_v150778($page, $type, $world_slug)
                    ? self::next_level_card_photo($child,$type,$world_slug,$index-1)
                    : '';
                if ($photo !== '') {
                    $items[]='<a class="hd-next-card has-photo'.$row_class.'" href="'.esc_url(get_permalink($child)).'">'.$photo.'<span class="hd-next-card-body"><span class="hd-next-copy"><strong>'.esc_html(get_the_title($child)).'</strong>'.($intro!==''?'<small>'.esc_html($intro).'</small>':'').'</span><b aria-hidden="true">→</b></span></a>';
                } else {
                    $items[]='<a class="hd-next-card'.$row_class.'" href="'.esc_url(get_permalink($child)).'"><span class="hd-next-icon">'.self::topic_icon_svg(get_the_title($child),$world_slug).'</span><span class="hd-next-copy"><strong>'.esc_html(get_the_title($child)).'</strong>'.($intro!==''?'<small>'.esc_html($intro).'</small>':'').'</span><b aria-hidden="true">→</b></a>';
                }
            }
        } else {
            foreach ($term_children as $term) {
                if (!$term instanceof WP_Term) { continue; }
                $url=get_term_link($term); if(is_wp_error($url)){continue;}
                $row_size=(int)($row_sizes[$index]??3); $row_class=' hd-row-size-'.max(1,min(3,$row_size)); $index++;
                $desc=trim(wp_strip_all_tags((string)$term->description));
                $short=$desc!==''?wp_trim_words($desc,9,'…'):'';
                $items[]='<a class="hd-next-card'.$row_class.'" href="'.esc_url($url).'"><span class="hd-next-icon">'.self::topic_icon_svg($term->name,$world_slug).'</span><span class="hd-next-copy"><strong>'.esc_html($term->name).'</strong>'.($short!==''?'<small>'.esc_html($short).'</small>':'').'</span><b aria-hidden="true">→</b></a>';
            }
        }
        if (!$items) { return ''; }
        $grid=implode('',$items); if($banner!==''){$grid.=$banner;}
        return '<section id="hd-next-level" class="hd-portal-section hd-next-level"><header><h2>Weiter in '.esc_html(get_the_title($page)).'</h2></header><div class="hd-next-grid hd-next-count-'.intval($count).' '.($count%2?'hd-next-odd':'hd-next-even').'">'.$grid.'</div></section>';
    }

    private static function render_term_next_level($term) {
        if (!$term instanceof WP_Term) {return '';}
        $terms=get_terms(['taxonomy'=>$term->taxonomy,'parent'=>$term->term_id,'hide_empty'=>false,'orderby'=>'name','order'=>'ASC']);
        if (is_wp_error($terms) || !$terms) {return '';}
        $parts=self::integrated_affiliate_components('category',$term->name);
        $count=count($terms); $rem=$count%3; $banner_span=$rem===1?2:($rem===2?1:3);
        $banner=self::inline_partner_banner($parts,$banner_span);
        $row_sizes=$banner!==''?array_fill(0,$count,3):self::card_row_sizes($count);
        $items=[];$index=0;
        foreach ($terms as $child) {
            if (!$child instanceof WP_Term) {continue;}
            $u=get_term_link($child); if(is_wp_error($u)){continue;}
            $rs=(int)($row_sizes[$index]??3);$index++;
            $items[]='<a class="hd-next-card hd-row-size-'.max(1,min(3,$rs)).'" href="'.esc_url($u).'"><span class="hd-next-icon">'.self::leaf_category_icon_svg_v150687($child).'</span><span class="hd-next-copy"><strong>'.esc_html($child->name).'</strong>'.(trim(wp_strip_all_tags((string)$child->description))!==''?'<small>'.esc_html(wp_trim_words(wp_strip_all_tags((string)$child->description),7,'…')).'</small>':'').'</span><b aria-hidden="true">→</b></a>';
        }
        if(!$items){return '';}
        $grid=implode('',$items); if($banner!==''){$grid.=$banner;}
        return '<section id="hd-next-level" class="hd-portal-section hd-next-level"><header><h2>Weitere Kategorien</h2></header><div class="hd-next-grid hd-next-count-'.intval($count).' '.($count%2?'hd-next-odd':'hd-next-even').'">'.$grid.'</div></section>';
    }

    private static function integrated_affiliate_components($type, $context_title='') {
        $banner_slot=in_array($type,['hub1','hub2'],true)?'hub_after_cards':'product_after_category_tiles';
        $banner=self::affiliate_slot($banner_slot); $banner_preview=false;
        if($banner==='' && self::logged_in_preview()){ $banner=self::affiliate_preview_placeholder('Affiliate-Banner',$banner_slot); $banner_preview=$banner!==''; }
        $prefix=$type==='hub1'?'hub_product_':'category_product_'; $products=[];
        for($i=1;$i<=3;$i++){
            $slot=$prefix.$i; $html=self::affiliate_slot($slot); $preview=false;
            if($html==='' && self::logged_in_preview()){$html=self::affiliate_preview_placeholder('Affiliate-Produkt',$slot);$preview=$html!=='';}
            if($html!==''){$products[]=['html'=>$html,'preview'=>$preview,'slot'=>$slot];}
        }
        return ['banner'=>$banner,'banner_preview'=>$banner_preview,'products'=>$products];
    }

    private static function inline_partner_banner($component, $span=3) {
        $html=trim((string)($component['banner']??'')); if($html===''){return '';}
        $span=max(1,min(3,(int)$span));
        return '<div class="hd-next-partner-banner hd-banner-span-'.$span.(!empty($component['banner_preview'])?' is-preview':'').'" aria-label="Anzeige · Partner"><span>Anzeige · Partner</span><div>'.$html.'</div></div>';
    }

    private static function inline_partner_product($product) {
        $html=trim((string)($product['html']??'')); if($html===''){return '';}
        return '<div class="hd-next-partner-product'.(!empty($product['preview'])?' is-preview':'').'" aria-label="Anzeige · Partner"><span class="hd-next-partner-label">Anzeige · Partner</span><div class="hd-next-partner-content">'.$html.'</div></div>';
    }

    private static function integrated_affiliate_modules($type, $context_title='') {
        $parts=self::integrated_affiliate_components($type,$context_title); $out='';
        if(($parts['banner']??'')!==''){$out.=self::inline_partner_banner($parts);}
        foreach((array)($parts['products']??[]) as $product){$out.=self::inline_partner_product($product);}
        return $out;
    }

    private static function affiliate_banner_for_type($type) {
        $slot=in_array($type,['hub1','hub2'],true)?'hub_after_cards':'product_after_category_tiles';
        $html=self::affiliate_slot($slot); $preview=false;
        if ($html==='' && self::logged_in_preview()) {$html=self::affiliate_preview_placeholder('banner',$slot);$preview=true;}
        if ($html==='') {return '';}
        return '<aside class="hd-portal-section hd-native-partner hd-context-banner'.($preview?' is-preview':'').'" aria-label="Anzeige / Partner"><div class="hd-native-partner-label">Anzeige · Partner</div><div class="hd-context-banner-inner">'.$html.'</div></aside>';
    }

    private static function products_for_type($type, $context_title='') {
        $prefix=$type==='hub1'?'hub_product_':'category_product_'; $cards=[];
        for($i=1;$i<=3;$i++) { $slot=$prefix.$i; $html=self::affiliate_slot($slot); if($html===''&&self::logged_in_preview()){$html=self::affiliate_preview_placeholder('product',$slot);} if($html!==''){$cards[]='<div class="hd-context-product">'.$html.'</div>';} }
        if(!$cards){return '';}
        $context=trim((string)$context_title);
        if($type==='hub2' && $context!==''){
            $heading='Passende Produkte für '.$context;
        } else {
            $heading='Empfohlene Produkte'.($context!==''?' aus '.$context:'');
        }
        return '<section class="hd-portal-section hd-context-products hd-native-products"><header><span>Anzeige · Partner</span><h2>'.esc_html($heading).'</h2></header><div class="hd-context-product-grid">'.implode('',$cards).'</div></section>';
    }

    private static function category_ids_matching_page($page) {
        if (!$page instanceof WP_Post) {return [];}
        $ids=[]; $by_slug=get_category_by_slug((string)$page->post_name); if ($by_slug instanceof WP_Term) {$ids[]=(int)$by_slug->term_id;}
        $by_name=get_term_by('name',get_the_title($page),'category'); if ($by_name instanceof WP_Term) {$ids[]=(int)$by_name->term_id;}
        return array_values(array_unique(array_filter($ids)));
    }


    // One rule for all three existing article-card renderers. A real featured
    // image always wins. Only absent thumbnails use an existing, approved
    // hobby-master picture from HD003's canonical leaf-category mapping.
    private static function post_preview_photo_v150803($post) {
        if (!$post instanceof WP_Post) { return ''; }
        $img = (string)get_the_post_thumbnail_url($post->ID,'medium_large');
        if ($img !== '') { return $img; }
        $terms = get_the_category($post->ID);
        if (!is_array($terms)) { return ''; }
        foreach ($terms as $term) {
            if (!$term instanceof WP_Term || (string)$term->taxonomy !== 'category') { continue; }
            $entry = self::leaf_category_meta_v150750($term);
            if (!is_array($entry)) { continue; }
            $parent = sanitize_title((string)($entry['parent_slug'] ?? ''));
            if ($parent !== '') {
                $relative = 'hobby-depot-v150780/hobby-masters/'.$parent.'.webp';
                if (is_file(dirname(__DIR__).'/assets/'.$relative)) {
                    return plugins_url('affiliate-portal-template-kit/assets/'.$relative);
                }
            }
            $chain = (array)($entry['chain'] ?? array());
            $world_path = trim((string)($chain[0]['path'] ?? ''));
            $world = sanitize_key(explode('/',$world_path)[0]);
            if (in_array($world,array('gestalten','fertigen','technik','forschen',
                  'pflanzen','tiere','bewegen','sammeln'),true)) {
                $relative = 'hobby-depot-v150617/start-world-v150691/'.$world.'.webp';
                if (is_file(dirname(__DIR__).'/assets/'.$relative)) {
                    return self::asset_url('start-world-v150691/'.$world.'.webp');
                }
            }
        }
        return '';
    }

    private static function render_post_previews($page=null, $term=null, $limit=3, $extra_class='') {
        $limit=max(1,min(6,(int)$limit));
        $args=['post_type'=>'post','post_status'=>'publish','posts_per_page'=>$limit,'ignore_sticky_posts'=>true,'no_found_rows'=>true];
        if ($term instanceof WP_Term && $term->taxonomy==='category') {$args['cat']=(int)$term->term_id;}
        elseif ($page instanceof WP_Post) {
            $ids=self::category_ids_matching_page($page);
            if($ids){$args['category__in']=$ids;}
            elseif(strpos((string)$extra_class,'hd-post-previews-hub2')!==false && self::logged_in_preview()){
                $args['post_status']=['publish','private'];
                $args['meta_query']=[['key'=>'_hd_demo_post_v150637','value'=>'1','compare'=>'=']];
            } else {
                if(self::logged_in_preview()){return '<section class="hd-portal-section hd-post-previews"><header><span>Beiträge</span><h2>Beitragsvorschau</h2></header><div class="hd-empty-admin">Nur eingeloggt sichtbar: Für diese Seite ist noch keine gleichnamige Beitragskategorie gebunden.</div></section>';}
                return '';
            }
        }
        $posts=get_posts($args); if(!$posts){ if(self::logged_in_preview()){return '<section class="hd-portal-section hd-post-previews"><header><span>Beiträge</span><h2>Beitragsvorschau</h2></header><div class="hd-empty-admin">Nur eingeloggt sichtbar: Noch keine passenden Beiträge vorhanden.</div></section>';} return ''; }
        $cards=''; foreach($posts as $post){ if(!$post instanceof WP_Post){continue;} $img=self::post_preview_photo_v150803($post); $cards.='<article class="hd-post-card">'.($img!==''?'<a class="hd-post-image" href="'.esc_url(get_permalink($post)).'"><img src="'.esc_url($img).'" alt="'.esc_attr(get_the_title($post)).'" loading="lazy"></a>':'').'<div><h3><a href="'.esc_url(get_permalink($post)).'">'.esc_html(get_the_title($post)).'</a></h3><p>'.esc_html(wp_trim_words(wp_strip_all_tags((string)$post->post_excerpt),20,'…')).'</p><a class="hd-post-more" href="'.esc_url(get_permalink($post)).'">Weiterlesen →</a></div></article>'; }
        return '<section class="hd-portal-section hd-post-previews '.esc_attr($extra_class).'"><header><span>Beiträge</span><h2>'.($limit>=4?'Passende Beiträge':'Aktuelle Beiträge').'</h2></header><div class="hd-post-grid">'.$cards.'</div></section>';
    }

    private static function render_hub2_bottom_editorial($text, $title) {
        $body=self::render_category_intro_editorial($text);
        if($body===''){return '';}
        return '<section class="hd-portal-section hd-hub2-bottom-head"><header><span>Orientierung</span><h2>Mehr über '.esc_html($title).'</h2></header></section>'.$body;
    }

    private static function is_category_level_page($page, $type) {
        return $type === 'category' && $page instanceof WP_Post;
    }

    private static function category_level_copy_map_v150687() {
        static $map = null;
        if (is_array($map)) { return $map; }
        $map = [];
        $file = dirname(__DIR__) . '/assets/hobby-depot-v150687/category-level-copy-v150687.json';
        if (!is_file($file)) { return $map; }
        $raw = @file_get_contents($file);
        $decoded = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($decoded)) { $map = $decoded; }
        return $map;
    }

    private static function category_level_rollout_map_v150695() {
        static $map = null;
        if (is_array($map)) { return $map; }
        $map = [];
        $file = dirname(__DIR__) . '/assets/hobby-depot-v150695/category-level-copy-v150695.json';
        if (!is_file($file)) { return $map; }
        $raw = @file_get_contents($file);
        $decoded = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($decoded)) { $map = $decoded; }
        return $map;
    }

    private static function category_level_copy($page, $world_slug='') {
        if (!$page instanceof WP_Post) { return ['lead'=>'','more'=>'']; }
        $slug = sanitize_title((string)$page->post_name);
        $pilot = self::category_level_rollout_map_v150695();
        if (isset($pilot[$slug]) && is_array($pilot[$slug])) {
            return [
                'lead' => trim((string)($pilot[$slug]['lead'] ?? '')),
                'more' => trim((string)($pilot[$slug]['more'] ?? '')),
            ];
        }
        $map = self::category_level_copy_map_v150687();
        if (isset($map[$slug]) && is_array($map[$slug])) {
            return [
                'lead' => trim((string)($map[$slug]['lead'] ?? '')),
                'more' => trim((string)($map[$slug]['more'] ?? '')),
            ];
        }
        $full = self::category_intro_for_page($page, 'category', $world_slug);
        $words = preg_split('/\s+/u', trim($full), -1, PREG_SPLIT_NO_EMPTY);
        if (!is_array($words) || !$words) { return ['lead'=>'','more'=>'']; }
        $cut = min(55, max(45, (int)floor(count($words) * .32)));
        return [
            'lead' => implode(' ', array_slice($words,0,$cut)),
            'more' => implode(' ', array_slice($words,$cut)),
        ];
    }

    private static function semantic_icon_library_v150687() {
        return [
            'faq' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M9.7 9a2.5 2.5 0 1 1 4.5 1.5c-1.4 1.2-2.2 1.6-2.2 3.2"/><circle cx="12" cy="17.5" r=".8" fill="currentColor" stroke="none"/></svg>',
            'compare' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v18M5 6h14M7 6l-3 6h6L7 6ZM17 6l-3 6h6l-3-6ZM4 12h6M14 12h6"/></svg>',
            'basics' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5.5A3.5 3.5 0 0 1 7.5 2H11v17H7.5A3.5 3.5 0 0 0 4 22Z"/><path d="M20 5.5A3.5 3.5 0 0 0 16.5 2H13v17h3.5A3.5 3.5 0 0 1 20 22Z"/></svg>',
            'equipment' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6V4h6v2M4 8h16v11H4Z"/><path d="M4 12h16M10 12v2h4v-2"/></svg>',
            'tools' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 6l4-4 4 4-4 4"/><path d="M13 7 4 16a3 3 0 0 0 4 4l9-9"/></svg>',
            'materials' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 7 8-4 8 4-8 4Z"/><path d="m4 12 8 4 8-4M4 17l8 4 8-4"/></svg>',
            'pattern' => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="6" height="6"/><rect x="14" y="4" width="6" height="6"/><rect x="4" y="14" width="6" height="6"/><rect x="14" y="14" width="6" height="6"/></svg>',
            'shape' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h10M10 4l4 4-4 4M20 16H10M14 12l-4 4 4 4"/></svg>',
            'project' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4h10l4 4v12H5Z"/><path d="M15 4v5h5M8 14l2.5 2.5L16 11"/></svg>',
            'safety' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 20 6v5c0 5-3.4 8.5-8 10-4.6-1.5-8-5-8-10V6Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></svg>',
            'care' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7-4.2-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.8-7 10-7 10Z"/><path d="M12 9v6M9 12h6"/></svg>',
            'document' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h9l3 3v15H6Z"/><path d="M15 3v4h4M9 11h6M9 15h6"/></svg>',
            'storage' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 7 8-4 8 4-8 4Z"/><path d="M4 7v10l8 4 8-4V7M12 11v10"/></svg>',
            'buy' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5h2l2 10h10l3-7H6"/><circle cx="9" cy="19" r="1.5"/><circle cx="17" cy="19" r="1.5"/></svg>',
            'measure' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 17 17 4l3 3L7 20H4Z"/><path d="m10 11 3 3M13 8l3 3M7 14l3 3"/></svg>',
            'photo' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h4l1.5-2h5L16 7h4v12H4Z"/><circle cx="12" cy="13" r="3.4"/></svg>',
            'species' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v18M12 8 7 5M12 12l6-4M12 16l-5 3"/><circle cx="7" cy="5" r="2"/><circle cx="18" cy="8" r="2"/><circle cx="7" cy="19" r="2"/></svg>',
            'climate' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 4a2 2 0 0 1 4 0v9.2a4 4 0 1 1-4 0Z"/><path d="M12 7v8"/></svg>',
            'food' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 4v7M8 4v7M5 8h3M6.5 11v9M16 4v16M16 4c3 2 3 6 0 8"/></svg>',
            'training' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><path d="m14 10 6-6M16 4h4v4"/></svg>',
            'rules' => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/></svg>',
            'location' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11Z"/><circle cx="12" cy="10" r="2"/></svg>',
            'finish' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6Z"/><path d="m18 14 .9 2.1L21 17l-2.1.9L18 20l-.9-2.1L15 17l2.1-.9Z"/></svg>',
            'problem' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 9 17H3Z"/><path d="M12 9v5M12 17h.01"/></svg>',
            'technique' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/></svg>',
            'color' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 1 0 0 18h1.5a2 2 0 0 0 0-4H12a1.5 1.5 0 0 1 0-3h3a6 6 0 0 0 6-6c0-3-4-5-9-5Z"/><circle cx="7" cy="9" r="1"/><circle cx="10" cy="6.5" r="1"/><circle cx="14" cy="6.5" r="1"/></svg>',
            'prepare' => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 2h6v4H9ZM8 10h8M8 14h8M8 18h5"/></svg>',
            'cut' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 20 7-7M14 10l6-6M10 14l4-4"/><circle cx="7" cy="7" r="3"/><circle cx="17" cy="17" r="3"/></svg>',
            'thread' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 4h8l2 4-2 12H8L6 8Z"/><path d="M8 9h8M9 13h6M10 17h4"/></svg>',
            'print' => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3" width="14" height="6" rx="1"/><rect x="4" y="10" width="16" height="7" rx="2"/><path d="M7 17h10v4H7Z"/></svg>',
            'build' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 20h18M6 20V9l6-5 6 5v11M9 13h6M9 16h6"/></svg>',
            'electric' => '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="7" width="10" height="10" rx="2"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/></svg>',
            'water' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3s6 6.7 6 11a6 6 0 1 1-12 0c0-4.3 6-11 6-11Z"/></svg>',
            'plant' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 4C12 4 6 8 5 16c7 1 13-2 15-12Z"/><path d="M4 20c3-6 8-10 14-13"/></svg>',
            'motion' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="14" cy="5" r="2"/><path d="m12 9-3 5 3 2 2-4 3 3M10 16l-3 5M14 17l4 4"/></svg>',
            'clean' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14 4 6 6-8 8-6-6Z"/><path d="M5 13c-2 1-3 3-2 5 1 2 4 2 6 0"/></svg>',
            'data' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20V4M4 20h16"/><path d="m7 16 4-5 3 3 5-7"/></svg>',
            'heat' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3c2 4-1 5 1 8 1-2 3-3 4-5 2 4 3 7 1 11a6 6 0 0 1-11 0c-2-4 1-8 5-14Z"/></svg>',
            'default' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M8 12h8M12 8v8"/></svg>',
        ];
    }

    private static function leaf_category_icon_role_v150687($title, $slug='') {
        $key = sanitize_title(trim((string)$title).' '.trim((string)$slug));
        $rules = [
            ['faq|haeufige-fragen|fragen-antworten','faq'],
            ['vergleich|kaufberatung|kaufen|tauschen','compare'],
            ['einstieg|grundlage|grundlagen|erste-schritte','basics'],
            ['ausruestung|kosten|setup','equipment'],
            ['werkzeug|werkzeuge|maschine|maschinen','tools'],
            ['material|materialien|ring|ringe|substrat|medien','materials'],
            ['muster|grundmuster|layout|gestaltung','pattern'],
            ['farbe|farben|verlauf|tinte|pigment','color'],
            ['vorbereitung|grundierung|einrichten|planung|bestandsaufnahme','prepare'],
            ['schneiden|messer|saegen|feilen|kanten','cut'],
            ['naehen|garn|fasern|spindel|zwirnen|binden|wickeln|flechten','thread'],
            ['druck|registrierung|stempel|sieb','print'],
            ['bau|montage|geruest|rahmen|bauteile','build'],
            ['elektronik|antrieb|antenne|schaltung|loeten|loet','electric'],
            ['wasser|naehrloesung|giessen','water'],
            ['duengen|bestaeubung|pflanze|substrat','plant'],
            ['technik|praxis|grundtechnik|bewegung|taktik|schiess|pfeile','technique'],
            ['reinigung|praeparation|fixieren','clean'],
            ['daten|auswerten|melden','data'],
            ['waerme|brennen|gaerung','heat'],
            ['formen|uebergang|uebergaenge|konstruktion|bau-montage','shape'],
            ['projekt|projekte|finish|abschluss|nacharbeit|lackierung|details','project'],
            ['sicherheit|schutz|regeln','safety'],
            ['pflege|wartung|fehler|probleme|gesundheit','care'],
            ['dokument|archiv|dokumentation','document'],
            ['aufbewahrung|lagerung|sammlung','storage'],
            ['bestimmen|bestimmung|einordnen|echtheit|zustand','measure'],
            ['fotografie|foto|belichtung|fokus','photo'],
            ['arten|sorten|merkmale|zucht','species'],
            ['klima|temperatur|feuchte|wasserwerte','climate'],
            ['futter|fuetterung|ernte','food'],
            ['training|wurftechnik|tricks|technik-praxis','training'],
            ['orte|fundorte','location'],
            ['finish|oberflaeche','finish'],
            ['problem|fehler','problem'],
        ];
        foreach ($rules as $rule) { if (preg_match('/'.$rule[0].'/', $key)) { return $rule[1]; } }
        return 'default';
    }

    private static function leaf_category_icon_svg_v150687($term, $page=null, $world_slug='') {
        $title = $term instanceof WP_Term ? (string)$term->name : (string)$term;
        $slug = $term instanceof WP_Term ? (string)$term->slug : sanitize_title($title);
        $lib = self::semantic_icon_library_v150687();
        $role = self::leaf_category_icon_role_v150687($title,$slug);
        if ($role !== 'default' && isset($lib[$role])) { return $lib[$role]; }
        if ($page instanceof WP_Post) { return self::category_page_icon_svg_v150687($page,$world_slug); }
        return self::topic_icon_svg($title,$world_slug);
    }

    private static function category_page_icon_svg_v150687($page, $world_slug='') {
        if (!$page instanceof WP_Post) { return self::world_icon_svg($world_slug); }
        $key = sanitize_title((string)$page->post_name.' '.(string)get_the_title($page));
        if (preg_match('/kettenhemd|chainmail/', $key)) {
            return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9.2 8.1 6.6 10.7a4 4 0 0 0 5.7 5.7l2.6-2.6"/><path d="m14.8 15.9 2.6-2.6a4 4 0 0 0-5.7-5.7L9.1 10.2"/><path d="m8.8 12 6.4 0"/></svg>';
        }
        return self::topic_icon_svg(get_the_title($page), $world_slug);
    }

    private static function uppercase_text_start_v150688($text) {
        $text = trim((string)$text);
        if ($text === '') { return ''; }
        // Preserve established brand spellings while enforcing a capital sentence start everywhere else.
        if (preg_match('/^(eBay|iPhone|iPad)\b/u', $text)) { return $text; }
        if (!preg_match('/\p{L}/u', $text, $m, PREG_OFFSET_CAPTURE)) { return $text; }
        $letter = $m[0][0];
        $offset = $m[0][1];
        $upper = function_exists('mb_strtoupper') ? mb_strtoupper($letter, 'UTF-8') : strtoupper($letter);
        return substr($text, 0, $offset) . $upper . substr($text, $offset + strlen($letter));
    }

    private static function category_level_display_title_v150688($page) {
        $title = $page instanceof WP_Post ? trim((string)get_the_title($page)) : '';
        $slug = $page instanceof WP_Post ? sanitize_title((string)$page->post_name) : '';
        if ($slug === 'kettenhemdflechten') {
            return ['plain'=>'Kettenhemd flechten','html'=>'<span class="hd-kettenhemd-title-v150689" style="display:inline-block;white-space:nowrap;font-size:clamp(28px,8.5vw,50px);letter-spacing:-.02em">Kettenhemd&nbsp;flechten</span>'];
        }
        return ['plain'=>$title,'html'=>esc_html($title)];
    }

    private static function category_level_topics_heading_v150688($page) {
        if (!$page instanceof WP_Post) { return 'Mehr zum Hobby'; }
        $slug = sanitize_title((string)$page->post_name);
        // Curated only where a natural short form is certain. Generic fallback avoids awkward H1 duplication.
        if ($slug === 'kettenhemdflechten') { return 'Rund ums Kettenhemd'; }
        if ($slug === 'schuhmacherei') { return 'Mehr zur Schuhmacherei'; }
        $pilot = self::category_level_rollout_map_v150695();
        if (isset($pilot[$slug]['heading']) && trim((string)$pilot[$slug]['heading']) !== '') { return trim((string)$pilot[$slug]['heading']); }
        $title = trim((string)get_the_title($page));
        return $title !== '' ? ('Mehr über ' . $title) : 'Mehr zum Hobby';
    }

    private static function leaf_category_display_title_v150688($term) {
        if (!$term instanceof WP_Term) { return ''; }
        $role = self::leaf_category_icon_role_v150687((string)$term->name, (string)$term->slug);
        if ($role === 'faq') { return 'Häufige Fragen'; }
        return trim((string)$term->name);
    }

    private static function render_category_level_intro_v150687($page, $world_slug='', $has_hero=false) {
        if (!$page instanceof WP_Post) { return ''; }
        $copy = self::category_level_copy($page,$world_slug);
        $title = self::category_level_display_title_v150688($page);
        $icon = self::category_page_icon_svg_v150687($page,$world_slug);
        $pilot_class = sanitize_title((string)$page->post_name) === 'schuhmacherei' ? ' hd-catlevel-intro-schuhmacherei-v150695' : '';
        $html = '<section class="hd-catlevel-intro'.esc_attr($pilot_class).'"'
            . ($has_hero ? ' aria-label="'.esc_attr('Einführung zu ' . $title['plain']).'"' : ' aria-labelledby="hd-catlevel-title"') . '>';
        $html .= '<div class="hd-catlevel-intro-inner">';
        if (!$has_hero) {
            $html .= '<span class="hd-catlevel-title-icon" aria-hidden="true">'.$icon.'</span>';
            $html .= '<h1 id="hd-catlevel-title" aria-label="'.esc_attr($title['plain']).'">'.$title['html'].'</h1>';
        }
        if ($copy['lead'] !== '') { $html .= '<p class="hd-catlevel-lead">'.esc_html(self::uppercase_text_start_v150688($copy['lead'])).'</p>'; }
        if ($copy['more'] !== '') {
            $parts = preg_split('/\R\s*\R/u', trim((string)$copy['more']), -1, PREG_SPLIT_NO_EMPTY);
            if (!is_array($parts) || !$parts) { $parts = [$copy['more']]; }
            $paras = '';
            foreach (array_slice($parts, 0, 2) as $part) { $paras .= '<p>'.esc_html(self::uppercase_text_start_v150688(trim((string)$part))).'</p>'; }
            $html .= '<details class="hd-catlevel-more"><summary aria-label="Mehr zu '.esc_attr($title['plain']).' anzeigen"></summary><div>'.$paras.'</div></details>';
        }
        $html .= '</div></section>';
        return $html;
    }

    private static function leaf_category_subtitle_v150687($term, $page=null) {
        if (!$term instanceof WP_Term) { return ''; }
        $slug=sanitize_title((string)$term->slug);
        if ($page instanceof WP_Post && sanitize_title((string)$page->post_name)==='kettenhemdflechten') {
            $ketten=[
                'kettenhemdflechten-einstieg-grundlagen' => 'Material, Ringmaße und erste Handgriffe',
                'kettenhemdflechten-ausruestung-kosten' => 'Zangen, Ringe und Grundausstattung',
                'kettenhemdflechten-vergleich-kaufberatung' => 'Materialien, Ringtypen und Sets',
                'kettenhemdflechten-formen-uebergaenge' => 'Flächen, Kanten und Verbindungen',
                'kettenhemdflechten-grundmuster' => 'Flechtmuster und Aufbau',
                'kettenhemdflechten-projekte-finish' => 'Abschlüsse, Kanten und Finish',
                'kettenhemdflechten-ringe-werkzeuge' => 'Ringgrößen, Drahtstärken und Zangen',
                'kettenhemdflechten-faq' => 'Typische Probleme und Lösungen',
            ];
            if(isset($ketten[$slug])){return $ketten[$slug];}
        }
        $name = trim((string)$term->name);
        $topic = $page instanceof WP_Post ? trim((string)get_the_title($page)) : '';
        if ($page instanceof WP_Post && sanitize_title((string)$page->post_name) === 'schuhmacherei') {
            $schuh_key = sanitize_title($name);
            $schuh = [
                'einstieg-leisten' => 'Fußmaße, Leistenformen und erste Schritte',
                'ausruestung-kosten' => 'Grundwerkzeug, Materialien und Einstiegskosten',
                'vergleich-kaufberatung' => 'Werkzeuge, Leder und Sets im Vergleich',
                'leder-materialien' => 'Oberleder, Futter und Sohlenleder',
                'schnitt-schaft' => 'Schnittteile, Schaftaufbau und Formgebung',
                'sohle-verbindung' => 'Sohlenaufbau, Kleben, Nähen und Befestigen',
                'werkzeuge-maschinen' => 'Messer, Zangen, Ahlen und Maschinen',
                'passform-reparatur' => 'Passform, Verschleiß und Reparaturen',
                'faq-haeufige-fragen' => 'Material, Passform und Verarbeitung',
                'haeufige-fragen' => 'Material, Passform und Verarbeitung',
                'faq' => 'Material, Passform und Verarbeitung',
            ];
            if (isset($schuh[$schuh_key])) { return $schuh[$schuh_key]; }
        }
        $page_slug = $page instanceof WP_Post ? sanitize_title((string)$page->post_name) : '';
        $pilot = self::category_level_rollout_map_v150695();
        $subtitle_key = sanitize_title($name);
        if ($page_slug !== '' && isset($pilot[$page_slug]['subtitles'][$subtitle_key])) {
            return trim((string)$pilot[$page_slug]['subtitles'][$subtitle_key]);
        }
        $role = self::leaf_category_icon_role_v150687($name,$slug);
        $map = [
            'faq' => 'Typische Probleme, Sonderfälle und kurze Antworten',
            'compare' => 'Unterschiede, Qualitätsmerkmale und Auswahlkriterien',
            'basics' => 'Erste Arbeitsschritte, typische Fehler und wichtige Entscheidungen',
            'equipment' => 'Grundausstattung, Verbrauchsmaterial und typischer Preisrahmen',
            'tools' => 'Werkzeugtypen, Einsatzbereiche und Handhabung',
            'materials' => 'Eigenschaften, Qualitätsunterschiede und geeignete Anwendungen',
            'pattern' => 'Aufbau, Wiederholungen und typische Varianten',
            'shape' => 'Maße, Übergänge und Formvarianten',
            'project' => 'Planung, Arbeitsschritte und Abschluss',
            'safety' => 'Risiken, Schutzmaßnahmen und sichere Arbeitsweisen',
            'care' => 'Pflegeintervalle, Warnzeichen und häufige Probleme',
            'document' => 'Messwerte, Arbeitsschritte und nachvollziehbare Aufzeichnungen',
            'storage' => 'Schutz, Ordnung und geeignete Lagerbedingungen',
            'measure' => 'Merkmale, Messmethoden und Unterscheidungskriterien',
            'photo' => 'Licht, Aufnahmebedingungen und Dokumentation',
            'species' => 'Merkmale, Unterschiede und Ansprüche',
            'climate' => 'Temperatur, Feuchte, Licht und Luftbewegung',
            'food' => 'Versorgung, Mengen, Qualität und Rhythmus',
            'training' => 'Bewegungsablauf, Übungsaufbau und Fortschritt',
            'location' => 'Standorte, Bedingungen und geeignete Fundplätze',
            'finish' => 'Oberfläche, Schutz und sauberer Abschluss',
            'problem' => 'Ursachen, Fehlerbilder und Lösungen',
            'technique' => 'Arbeitsschritte, Kontrolle und typische Varianten',
            'color' => 'Farbauftrag, Übergänge und Materialwirkung',
            'prepare' => 'Ausgangsmaterial, Vorbereitung und Reihenfolge',
            'cut' => 'Schnittführung, Kanten und Formgebung',
            'thread' => 'Fasern, Verbindungen und Belastbarkeit',
            'print' => 'Übertragung, Passer und Druckergebnis',
            'build' => 'Bauteile, Verbindungen und Montagefolge',
            'electric' => 'Bauteile, Stromversorgung und Verbindungen',
            'water' => 'Wasserqualität, Versorgung und Messwerte',
            'plant' => 'Standort, Wachstum und Pflegebedingungen',
            'clean' => 'Reinigung, Materialschutz und Vorbereitung',
            'data' => 'Messwerte, Beobachtungen und Auswertung',
            'heat' => 'Temperatur, Dauer und Abkühlphase',
            'default' => '',
        ];
        return $map[$role] ?? '';
    }

    private static function render_category_level_term_cards_v150687($terms, $page=null, $world_slug='', $extra_class='') {
        $items = [];
        foreach ((array)$terms as $term) {
            if (!$term instanceof WP_Term) { continue; }
            $url = get_term_link($term); if (is_wp_error($url)) { continue; }
            $line = self::uppercase_text_start_v150688(self::leaf_category_subtitle_v150687($term,$page));
            $label = self::leaf_category_display_title_v150688($term);
            $items[] = '<a class="hd-next-card hd-catlevel-card" href="'.esc_url($url).'"><span class="hd-next-icon">'.self::leaf_category_icon_svg_v150687($term,$page,$world_slug).'</span><span class="hd-next-copy"><strong>'.esc_html($label).'</strong>'.($line!==''?'<small>'.esc_html($line).'</small>':'').'</span><b aria-hidden="true">→</b></a>';
        }
        if (!$items) { return ''; }
        return '<div class="hd-catlevel-grid '.esc_attr($extra_class).'">'.implode('',$items).'</div>';
    }

    private static function render_category_level_product_row_v150687($parts) {
        $cards = [];
        foreach ((array)($parts['products'] ?? []) as $product) {
            $html = self::inline_partner_product($product);
            if ($html !== '') { $cards[] = $html; }
        }
        if (!$cards) { return ''; }
        return '<section class="hd-portal-section hd-catlevel-products"><header><span>Anzeige · Partner</span><h2>Empfehlungen</h2></header><div class="hd-catlevel-product-grid">'.implode('',$cards).'</div></section>';
    }

    private static function direct_child_category_ids_v150687($page) {
        $ids=[];
        foreach (self::direct_category_children_for_page($page) as $term) {
            if ($term instanceof WP_Term) { $ids[]=(int)$term->term_id; }
        }
        return array_values(array_unique(array_filter($ids)));
    }

    private static function render_category_level_post_previews_v150687($page, $limit=4) {
        if (!$page instanceof WP_Post) { return ''; }
        $ids=self::direct_child_category_ids_v150687($page);
        if (!$ids) {
            if (self::logged_in_preview()) { return '<section class="hd-portal-section hd-post-previews hd-catlevel-posts"><header><span>Beiträge</span><h2>Passende Beiträge</h2></header><div class="hd-empty-admin">Nur eingeloggt sichtbar: Für diese Seite sind noch keine Beitragskategorien gebunden.</div></section>'; }
            return '';
        }
        $posts=get_posts(['post_type'=>'post','post_status'=>'publish','posts_per_page'=>max(3,min(4,(int)$limit)),'ignore_sticky_posts'=>true,'no_found_rows'=>true,'category__in'=>$ids]);
        if (!$posts) {
            if (self::logged_in_preview()) { return '<section class="hd-portal-section hd-post-previews hd-catlevel-posts"><header><span>Beiträge</span><h2>Passende Beiträge</h2></header><div class="hd-empty-admin">Nur eingeloggt sichtbar: Noch keine passenden Beiträge in den Unterkategorien vorhanden.</div></section>'; }
            return '';
        }
        $cards='';
        foreach($posts as $post){
            if(!$post instanceof WP_Post){continue;}
            $img=self::post_preview_photo_v150803($post);
            $excerpt=trim((string)$post->post_excerpt); if($excerpt===''){$excerpt=wp_strip_all_tags((string)$post->post_content);}
            $cards.='<article class="hd-post-card">'.($img!==''?'<a class="hd-post-image" href="'.esc_url(get_permalink($post)).'"><img src="'.esc_url($img).'" alt="'.esc_attr(get_the_title($post)).'" loading="lazy"></a>':'').'<div><h3><a href="'.esc_url(get_permalink($post)).'">'.esc_html(get_the_title($post)).'</a></h3><p>'.esc_html(wp_trim_words($excerpt,18,'…')).'</p><a class="hd-post-more" href="'.esc_url(get_permalink($post)).'">Weiterlesen →</a></div></article>';
        }
        return '<section class="hd-portal-section hd-post-previews hd-catlevel-posts"><header><span>Beiträge</span><h2>Passende Beiträge</h2></header><div class="hd-post-grid">'.$cards.'</div></section>';
    }

    private static function direct_category_level_term_entry_v150687($term) {
        if (!$term instanceof WP_Term || (string)$term->taxonomy !== 'category') { return null; }
        $map=self::category_level_copy_map_v150687();
        $slug=sanitize_title((string)$term->slug);
        $entry=$map[$slug] ?? null;
        return is_array($entry) && (string)($entry['object_type'] ?? '') === 'category' ? $entry : null;
    }

    private static function render_direct_category_level_term_intro_v150687($term) {
        $slug=sanitize_title((string)$term->slug);
        $is_ketten_faq_pilot=($slug === 'kettenhemdflechten-faq');
        $entry=self::direct_category_level_term_entry_v150687($term);
        // 1.50.747: Der Pilot darf NICHT von der alten category-level-copy-Map abhängen.
        // kettenhemdflechten-faq ist ein echter WordPress-Term, aber kein Eintrag dieser Seiten-Map.
        if (!is_array($entry) && !$is_ketten_faq_pilot) { return ''; }
        if (!is_array($entry)) { $entry=['lead'=>'','more'=>'','world'=>'fertigen']; }
        $title=trim((string)$term->name);
        $lead=trim((string)($entry['lead'] ?? ''));
        $more=trim((string)($entry['more'] ?? ''));
        $icon=self::leaf_category_icon_svg_v150687($term,null,(string)($entry['world'] ?? ''));

        // 1.50.747: Pilot fuer die gemeinsame Unterseiten-Architektur.
        // Nur FAQ Kettenhemdflechten: kein Hero-Bild, kurzer Einleitungstext,
        // danach Banner -> Beitragsvorschauen -> Anbieterprodukte.
        if ($is_ketten_faq_pilot) {
            $lead = 'Hier findest du kurze Antworten auf typische Fragen rund ums Kettenhemdflechten – von Ringgrößen und Materialien bis zu Fehlern beim Öffnen, Schließen und Verbinden der Ringe. Die Beiträge führen direkt zu den wichtigsten Praxisproblemen.';
            $more = '';
        }

        $html='<section class="hd-catlevel-intro'.(sanitize_title((string)$term->slug)==='kettenhemdflechten-faq'?' hd-ketten-faq-pilot-v150746':'').'" aria-labelledby="hd-catlevel-title"><div class="hd-catlevel-intro-inner">';
        $html.='<span class="hd-catlevel-title-icon" aria-hidden="true">'.$icon.'</span><h1 id="hd-catlevel-title">'.esc_html($title).'</h1>';
        if($lead!==''){$html.='<p class="hd-catlevel-lead">'.esc_html($lead).'</p>';}
        if($more!==''){$html.='<details class="hd-catlevel-more"><summary aria-label="Mehr zu '.esc_attr($title).' anzeigen"></summary><div><p>'.esc_html($more).'</p></div></details>';}
        return $html.'</div></section>';
    }

    private static function render_leaf_category_intro_v150750($term) {
        $meta = self::leaf_category_meta_v150750($term);
        if (!$term instanceof WP_Term || !is_array($meta)) { return ''; }
        $title = trim((string)$term->name);
        $intro = self::leaf_category_curated_intro_v150750($term, $meta);
        $icon = self::leaf_category_icon_svg_v150687($term, null, '');
        $html = '<section class="hd-catlevel-intro hd-leaf-intro-v150750" aria-labelledby="hd-catlevel-title"><div class="hd-catlevel-intro-inner">';
        $html .= '<span class="hd-catlevel-title-icon" aria-hidden="true">'.$icon.'</span><h1 id="hd-catlevel-title">'.esc_html($title).'</h1>';
        if ($intro !== '') { $html .= '<p class="hd-catlevel-lead">'.esc_html($intro).'</p>'; }
        return $html.'</div></section>';
    }

    private static function render_leaf_category_posts_v150750($term) {
        if (!$term instanceof WP_Term || (string)$term->taxonomy !== 'category') { return ''; }
        $posts = get_posts([
            'post_type'=>'post','post_status'=>'publish','posts_per_page'=>6,
            'ignore_sticky_posts'=>true,'no_found_rows'=>true,'cat'=>(int)$term->term_id,
        ]);

        // Der bereits abgenommene Kettenhemd-Pilot behaelt seine sechs Dummies,
        // bis echte Beitraege vorhanden sind. Auf allen anderen Leafs niemals Dummy-Inhalte erzeugen.
        if (!$posts && sanitize_title((string)$term->slug) === 'kettenhemdflechten-faq') {
            return self::render_kettenhemd_faq_demo_posts_v150746();
        }
        if (!$posts) { return ''; }

        $cards='';
        foreach ($posts as $post) {
            if (!$post instanceof WP_Post) { continue; }
            $img=self::post_preview_photo_v150803($post);
            $excerpt=trim((string)$post->post_excerpt);
            if ($excerpt==='') { $excerpt=wp_strip_all_tags((string)$post->post_content); }
            $cards.='<article class="hd-post-card">'.($img!==''?'<a class="hd-post-image" href="'.esc_url(get_permalink($post)).'"><img src="'.esc_url($img).'" alt="'.esc_attr(get_the_title($post)).'" loading="lazy"></a>':'').'<div><h3><a href="'.esc_url(get_permalink($post)).'">'.esc_html(get_the_title($post)).'</a></h3><p>'.esc_html(wp_trim_words($excerpt,18,'…')).'</p><a class="hd-post-more" href="'.esc_url(get_permalink($post)).'">Weiterlesen →</a></div></article>';
        }
        if ($cards==='') { return ''; }
        return '<section class="hd-portal-section hd-post-previews hd-leaf-posts-v150750"><header><h2>Passende Beiträge</h2></header><div class="hd-post-grid">'.$cards.'</div></section>';
    }

    private static function render_leaf_category_products_v150750($parts) {
        $providers = [
            'category_product_1' => 'Amazon',
            'category_product_2' => 'eBay',
            'category_product_3' => 'Idealo',
        ];
        $by_slot=[];
        foreach ((array)($parts['products'] ?? []) as $product) {
            $slot=(string)($product['slot'] ?? '');
            if ($slot!=='') { $by_slot[$slot]=$product; }
        }
        $columns='';
        foreach ($providers as $slot=>$provider) {
            if (!isset($by_slot[$slot])) { continue; }
            $html=self::inline_partner_product($by_slot[$slot]);
            if ($html==='') { continue; }
            $columns.='<div class="hd-provider-column-v150746" data-provider="'.esc_attr(strtolower($provider)).'"><h3>'.esc_html($provider).'</h3>'.$html.'</div>';
        }
        if ($columns==='') { return ''; }
        return '<section class="hd-portal-section hd-catlevel-products hd-leaf-products-v150750"><header><h2>Produkte & Empfehlungen</h2></header><div class="hd-provider-grid-v150746">'.$columns.'</div></section>';
    }

    private static function render_leaf_category_body_v150750($term) {
        if (!$term instanceof WP_Term || !is_array(self::leaf_category_meta_v150750($term))) { return ''; }
        $parts=self::integrated_affiliate_components('category',(string)$term->name);
        $out='';
        $banner=self::inline_partner_banner($parts,3);
        if ($banner!=='') { $out.='<section class="hd-portal-section hd-catlevel-banner hd-leaf-banner-v150750">'.$banner.'</section>'; }
        $out.=self::render_leaf_category_posts_v150750($term);
        $out.=self::render_leaf_category_products_v150750($parts);
        return $out;
    }

    private static function render_kettenhemd_faq_demo_posts_v150746() {
        $items = [
            ['Welche Ringgröße eignet sich zum Kettenhemdflechten?', 'Innendurchmesser und Drahtstärke bestimmen Gewicht, Beweglichkeit und wie leicht sich ein Muster schließen lässt.'],
            ['Wie viele Ringe braucht man für ein Kettenhemd?', 'Der Bedarf hängt von Ringmaß, Flechtmuster, Körpergröße und gewünschter Länge ab. Diese Faktoren entscheiden über die Stückzahl.'],
            ['Aluminium oder Stahl – welches Material eignet sich besser?', 'Aluminium ist leicht und gut für erste Projekte, Stahl robuster und näher am klassischen Kettengeflecht.'],
            ['Warum öffnen sich meine Ringe beim Flechten?', 'Häufig liegen die Ursachen bei falscher Zangenführung, ungünstigen Ringmaßen oder nicht bündig geschlossenen Ringstößen.'],
            ['Welche Zangen eignen sich zum Kettenhemdflechten?', 'Zwei gut greifende Zangen erleichtern sauberes Öffnen und Schließen und schonen dabei die Oberfläche der Ringe.'],
            ['Welches Flechtmuster eignet sich für Anfänger?', 'Einfache europäische Muster sind gut nachvollziehbar und zeigen schnell, wie Ringlage, Richtung und Spannung zusammenspielen.'],
        ];
        $cards='';
        foreach ($items as $item) {
            $cards.='<article class="hd-post-card hd-demo-post-v150746"><div><span class="hd-demo-post-kicker-v150746">Testartikel</span><h3>'.esc_html($item[0]).'</h3><p>'.esc_html($item[1]).'</p><span class="hd-post-more hd-demo-post-more-v150746">Vorschau →</span></div></article>';
        }
        return '<section class="hd-portal-section hd-post-previews hd-catlevel-posts hd-ketten-faq-posts-v150746"><header><h2>Passende Beiträge</h2></header><div class="hd-post-grid">'.$cards.'</div></section>';
    }

    private static function render_kettenhemd_faq_products_v150746($parts) {
        $providers = [
            'category_product_1' => 'Amazon',
            'category_product_2' => 'eBay',
            'category_product_3' => 'Idealo',
        ];
        $by_slot=[];
        foreach ((array)($parts['products'] ?? []) as $product) {
            $slot=(string)($product['slot'] ?? '');
            if ($slot!=='') { $by_slot[$slot]=$product; }
        }
        $columns='';
        foreach ($providers as $slot=>$provider) {
            if (!isset($by_slot[$slot])) { continue; }
            $html=self::inline_partner_product($by_slot[$slot]);
            if ($html==='') { continue; }
            $columns.='<div class="hd-provider-column-v150746" data-provider="'.esc_attr(strtolower($provider)).'"><h3>'.esc_html($provider).'</h3>'.$html.'</div>';
        }
        if ($columns==='') { return ''; }
        return '<section class="hd-portal-section hd-catlevel-products hd-ketten-faq-products-v150746"><header><h2>Produkte & Empfehlungen</h2></header><div class="hd-provider-grid-v150746">'.$columns.'</div></section>';
    }

    private static function render_direct_category_level_term_body_v150687($term) {
        if (!$term instanceof WP_Term) { return ''; }
        $parts=self::integrated_affiliate_components('category',(string)$term->name);

        // 1.50.746: exakt ein Pilot. Reihenfolge laut Abnahme:
        // kurzer Text (Intro oben) -> ein Banner -> 4 Beitragsvorschauen ->
        // Anbieterprodukte Amazon/eBay/Idealo nebeneinander. Kein Mietbanner danach.
        if (sanitize_title((string)$term->slug) === 'kettenhemdflechten-faq') {
            $out='';
            $banner=self::inline_partner_banner($parts,3);
            if($banner!==''){$out.='<section class="hd-portal-section hd-catlevel-banner hd-ketten-faq-banner-v150746">'.$banner.'</section>';}
            $out.=self::render_kettenhemd_faq_demo_posts_v150746();
            $out.=self::render_kettenhemd_faq_products_v150746($parts);
            return $out;
        }

        $out=self::render_category_level_product_row_v150687($parts);
        $banner=self::inline_partner_banner($parts,3);
        if($banner!==''){$out.='<section class="hd-portal-section hd-catlevel-banner">'.$banner.'</section>';}
        $out.=self::render_post_previews(null,$term,4,'hd-catlevel-posts');
        $out.=self::render_rental_for('category');
        return $out;
    }

    private static function render_category_level_body_v150687($page, $world_slug='') {
        if (!$page instanceof WP_Post) { return ''; }

        // V1.50.690 - abgenommener Detail-Level-Standard fuer die gesamte gleiche Seitenebene:
        // Banner direkt nach Intro; Kategorien geschlossen; Produkte danach; bis zu 4 Beitraege danach.
        if ($page instanceof WP_Post) {
            $terms = self::direct_category_children_for_page($page);
            $parts = self::integrated_affiliate_components('category', get_the_title($page));
            $out = '';

            $banner = self::inline_partner_banner($parts, 3);
            if ($banner !== '') {
                $out .= '<section class="hd-portal-section hd-catlevel-banner hd-catlevel-banner-first-v150690">'.$banner.'</section>';
            }

            if ($terms) {
                $out .= '<section class="hd-portal-section hd-catlevel-topics hd-catlevel-topics-all-v150690"><header><h2>'.esc_html(self::category_level_topics_heading_v150688($page)).'</h2></header>';
                $out .= self::render_category_level_term_cards_v150687($terms, $page, $world_slug, 'hd-catlevel-grid-all-v150690');
                $out .= '</section>';
            }

            $out .= self::render_category_level_product_row_v150687($parts);
            $out .= self::render_category_level_post_previews_v150687($page, 4);
            $out .= self::render_rental_for('category');
            return $out;
        }
        $terms = self::direct_category_children_for_page($page);
        $first = array_slice($terms, 0, 4);
        $rest = array_slice($terms, 4);
        $parts = self::integrated_affiliate_components('category', get_the_title($page));
        $out='';
        if ($first) {
            $out .= '<section class="hd-portal-section hd-catlevel-topics"><header><h2>'.esc_html(self::category_level_topics_heading_v150688($page)).'</h2></header>';
            $out .= self::render_category_level_term_cards_v150687($first,$page,$world_slug,'hd-catlevel-grid-first');
            $out .= '</section>';
        }
        $out .= self::render_category_level_product_row_v150687($parts);
        if ($rest) {
            $out .= '<section class="hd-portal-section hd-catlevel-topics hd-catlevel-topics-cont">'.self::render_category_level_term_cards_v150687($rest,$page,$world_slug,'hd-catlevel-grid-second').'</section>';
        }
        $banner = self::inline_partner_banner($parts, 3);
        if ($banner !== '') { $out .= '<section class="hd-portal-section hd-catlevel-banner">'.$banner.'</section>'; }
        $out .= self::render_category_level_post_previews_v150687($page,4);
        $out .= self::render_rental_for('category');
        return $out;
    }

    private static function ensure_demo_attachment_v150687($relative, $title) {
        $key = '_hd_demo_asset_v150687_' . md5((string)$relative);
        $existing = get_option($key, 0);
        if ($existing && get_post((int)$existing) instanceof WP_Post) { return (int)$existing; }
        $source = dirname(__DIR__) . '/assets/hobby-depot-v150617/' . ltrim((string)$relative,'/');
        if (!is_file($source)) { return 0; }
        if (!function_exists('wp_upload_bits')) { require_once ABSPATH . 'wp-admin/includes/file.php'; }
        if (!function_exists('wp_generate_attachment_metadata')) { require_once ABSPATH . 'wp-admin/includes/image.php'; }
        $bytes=@file_get_contents($source); if (!is_string($bytes) || $bytes==='') { return 0; }
        $name='hd-ketten-demo-'.substr(md5($relative),0,8).'.webp';
        $upload=wp_upload_bits($name,null,$bytes); if (!is_array($upload) || !empty($upload['error'])) { return 0; }
        $att=wp_insert_attachment(['post_mime_type'=>'image/webp','post_title'=>$title,'post_status'=>'inherit'],$upload['file']);
        if (is_wp_error($att) || !$att) { return 0; }
        $meta=wp_generate_attachment_metadata($att,$upload['file']); if (is_array($meta)) { wp_update_attachment_metadata($att,$meta); }
        update_option($key,(int)$att,false);
        return (int)$att;
    }

    public static function maybe_seed_kettenhemd_demo_posts_v150687() {
        if (get_option('pftk_hd_ketten_demo_v150687_seeded', false)) { return; }
        $defs = [
            ['slug'=>'kettenhemd-ringe-richtig-schliessen','title'=>'Kettenhemdflechten: Ringe sauber öffnen und schließen','excerpt'=>'So setzt du Zangen an, verdrehst Ringe statt sie auseinanderzuziehen und bekommst einen bündigen Ringstoß.','term'=>'kettenhemdflechten-einstieg-grundlagen','image'=>'subcategories/fertigen/metall-v150627.webp'],
            ['slug'=>'kettenhemd-european-4-in-1','title'=>'European 4-in-1: Das Grundmuster sauber aufbauen','excerpt'=>'Ein übersichtlicher Einstieg in Reihenfolge, Ringlage und die typischen Fehler beim klassischen 4-in-1-Geflecht.','term'=>'kettenhemdflechten-grundmuster','image'=>'subcategories/fertigen/metall-v150629.webp'],
            ['slug'=>'kettenhemd-ringe-zangen-auswahl','title'=>'Welche Ringe und Zangen passen für den Einstieg?','excerpt'=>'Ringdurchmesser, Drahtstärke, Material und Zangenform bestimmen, wie leicht sich ein Geflecht kontrolliert aufbauen lässt.','term'=>'kettenhemdflechten-ringe-werkzeuge','image'=>'subcategories/fertigen/metall-v150631.webp'],
            ['slug'=>'kettenhemd-kanten-abschluesse','title'=>'Kanten und Abschlüsse am Kettengeflecht sauber fertigstellen','excerpt'=>'So vermeidest du offene Ringstöße, unruhige Kanten und unnötige Spannung am Ende eines Projekts.','term'=>'kettenhemdflechten-projekte-finish','image'=>'subcategories/fertigen/metall-v150623.webp'],
        ];
        $ok=0;
        foreach($defs as $def){
            $term=get_term_by('slug',$def['term'],'category'); if(!$term instanceof WP_Term){continue;}
            $existing=get_page_by_path($def['slug'],OBJECT,'post');
            if($existing instanceof WP_Post){ $post_id=(int)$existing->ID; }
            else {
                $post_id=wp_insert_post(['post_type'=>'post','post_status'=>'publish','post_title'=>$def['title'],'post_name'=>$def['slug'],'post_excerpt'=>$def['excerpt'],'post_content'=>'<p>'.$def['excerpt'].'</p><p>Dieser Beitrag ist ein bewusst angelegter Dummy für die Layout- und Vorschauprüfung der Kettenhemdflechten-Seite. Er kann nach der Designabnahme durch den finalen Fachartikel ersetzt werden.</p>'],true);
                if(is_wp_error($post_id)||!$post_id){continue;}
            }
            wp_set_post_categories((int)$post_id,[(int)$term->term_id],false);
            update_post_meta((int)$post_id,'_hd_ketten_demo_v150687','1');
            $thumb=self::ensure_demo_attachment_v150687($def['image'],$def['title']);
            if($thumb>0){set_post_thumbnail((int)$post_id,$thumb);}
            $ok++;
        }
        if($ok===count($defs)){update_option('pftk_hd_ketten_demo_v150687_seeded',1,false);}
    }

    /**
     * 1.50.759: 50 new per-hobby image masters plus the 15 originals of 1.50.758.
     * An existing featured image or HD007 master is still preferred at call sites.
     * One file per hobby, both Finder and hero are derived from this same source.
     */
    private static function bundled_hobby_master_v150759($slug) {
        $slug = sanitize_title((string)$slug);
        $old = [
            'airbrush' => true,
            'altered-books' => true,
            'amateurfunk' => true,
            'anthotypie' => true,
            'aquaristik' => true,
            'aquascaping' => true,
            'automatenfiguren' => true,
            'balance-board' => true,
            'banknoten' => true,
            'baoding-balls' => true,
            'barometer' => true,
            'battlebots-modellbau' => true,
            'baumklettern' => true,
            'baumzucht-aus-samen' => true,
            'bean-to-bar-schokolade' => true,
        ];
        $new = [
            'aeroponik' => true,
            'bernstein-suchen' => true,
            'besenbinden' => true,
            'betonkunst' => true,
            'betonmobel' => true,
            'beyblade-tuning' => true,
            'bier-brauen' => true,
            'bierdeckel' => true,
            'bikepacking' => true,
            'bioactive-terrariums' => true,
            'bioakustik' => true,
            'biotop-aquarien' => true,
            'birding' => true,
            'bodenanalyse' => true,
            'bonsai' => true,
            'bromelien' => true,
            'chili-zucht' => true,
            'elektrochemie-als-hobby' => true,
            'fledermausbeobachtung' => true,
            'fleischfressende-pflanzen' => true,
            'garnelenhaltung' => true,
            'gemuseanbau' => true,
            'hydrokultur' => true,
            'hydroponik' => true,
            'indoor-growing' => true,
            'kakteen' => true,
            'kokedama' => true,
            'lithops' => true,
            'microgreens' => true,
            'mooskultur' => true,
            'orchideenzucht' => true,
            'pflanzenkreuzungen' => true,
            'pflanzenvermehrung' => true,
            'pilzzucht' => true,
            'plane-spotting' => true,
            'riesenkurbis-zucht' => true,
            'saatguterhaltung' => true,
            'saikei' => true,
            'schmetterlingsbeobachtung' => true,
            'seltene-zimmerpflanzen' => true,
            'semi-hydro' => true,
            'speisepilzzucht' => true,
            'spektroskopie' => true,
            'stecklingszucht' => true,
            'sukkulenten' => true,
            'tillandsien' => true,
            'tomatensorten-zucht' => true,
            'wabikusa' => true,
            'wasseranalyse' => true,
            'wildkameras' => true,
        ];
        $aliases = [
            'aeroponik' => 'aeroponik',
            'bernstein-suchen' => 'bernstein-suchen',
            'besenbinden' => 'besenbinden',
            'betonkunst' => 'betonkunst',
            'betonmobel' => 'betonmobel',
            'betonmoebel' => 'betonmobel',
            'beyblade-tuning' => 'beyblade-tuning',
            'bier-brauen' => 'bier-brauen',
            'bierdeckel' => 'bierdeckel',
            'bikepacking' => 'bikepacking',
            'bioactive-terrariums' => 'bioactive-terrariums',
            'bioakustik' => 'bioakustik',
            'biotop-aquarien' => 'biotop-aquarien',
            'birding' => 'birding',
            'bodenanalyse' => 'bodenanalyse',
            'bonsai' => 'bonsai',
            'bromelien' => 'bromelien',
            'chili-zucht' => 'chili-zucht',
            'elektrochemie-als-hobby' => 'elektrochemie-als-hobby',
            'fledermausbeobachtung' => 'fledermausbeobachtung',
            'fleischfressende-pflanzen' => 'fleischfressende-pflanzen',
            'garnelenhaltung' => 'garnelenhaltung',
            'gemueseanbau' => 'gemuseanbau',
            'gemuseanbau' => 'gemuseanbau',
            'hydrokultur' => 'hydrokultur',
            'hydroponik' => 'hydroponik',
            'indoor-growing' => 'indoor-growing',
            'kakteen' => 'kakteen',
            'kokedama' => 'kokedama',
            'lithops' => 'lithops',
            'microgreens' => 'microgreens',
            'mooskultur' => 'mooskultur',
            'orchideenzucht' => 'orchideenzucht',
            'pflanzenkreuzungen' => 'pflanzenkreuzungen',
            'pflanzenvermehrung' => 'pflanzenvermehrung',
            'pilzzucht' => 'pilzzucht',
            'plane-spotting' => 'plane-spotting',
            'riesenkuerbis-zucht' => 'riesenkurbis-zucht',
            'riesenkurbis-zucht' => 'riesenkurbis-zucht',
            'saatguterhaltung' => 'saatguterhaltung',
            'saikei' => 'saikei',
            'schmetterlingsbeobachtung' => 'schmetterlingsbeobachtung',
            'seltene-zimmerpflanzen' => 'seltene-zimmerpflanzen',
            'semi-hydro' => 'semi-hydro',
            'speisepilzzucht' => 'speisepilzzucht',
            'spektroskopie' => 'spektroskopie',
            'stecklingszucht' => 'stecklingszucht',
            'sukkulenten' => 'sukkulenten',
            'tillandsien' => 'tillandsien',
            'tomatensorten-zucht' => 'tomatensorten-zucht',
            'toepfern' => 'topfern',
            'wabikusa' => 'wabikusa',
            'wasseranalyse' => 'wasseranalyse',
            'wildkameras' => 'wildkameras',
        ];
        if (isset($aliases[$slug])) { $slug = $aliases[$slug]; }
        if (isset($old[$slug])) {
            $relative = 'assets/hobby-depot-v150758/hobby-masters/' . $slug . '.webp';
        } elseif (isset($new[$slug])) {
            $relative = 'assets/hobby-depot-v150759/hobby-masters/' . $slug . '.webp';
        } elseif ($slug === 'topfern') {
            // 1.50.760: Einzelbild aus Fehlgenerierung direkt korrekt dem Hobby Töpfern zugeordnet.
            $relative = 'assets/hobby-depot-v150760/hobby-masters/topfern.webp';
        } elseif ($slug === 'bogenschiessen' || $slug === 'pilzsuche') {
            // 1.50.761: Geprüfte freie Fehlmotive sofort einem passenden Hobby zugeordnet.
            $relative = 'assets/hobby-depot-v150761/hobby-masters/' . $slug . '.webp';
        } elseif ($slug === 'packrafting' || $slug === 'lederarbeiten') {
            // 1.50.765: Nach Bildprüfung neu als eigene Hobby-Master aufgenommen.
            $relative = 'assets/hobby-depot-v150765/hobby-masters/' . $slug . '.webp';
        } elseif ($slug === 'radfahren' || $slug === 'tarp-camping' || $slug === 'hammock-camping') {
            // 1.50.772: Drei gepruefte Einzelmotive; eigenes Foto je Hobby, zentral fuer alle Bildformate.
            $relative = 'assets/hobby-depot-v150772/hobby-masters/' . $slug . '.webp';
        } elseif (in_array($slug, ['sportdrachen', 'trick-kiting'], true)) {
            // 1.50.781: Only independently generated large originals are eligible.
            // The other eight small collage crops of 1.50.780 must NOT be used
            // as large hobby masters; HD007/central assigned originals remain valid.
            $relative = 'assets/hobby-depot-v150780/hobby-masters/' . $slug . '.webp';
        } elseif (in_array($slug, ['footgolf', 'speedminton', 'teqball', 'yo-yo-tricks', 'kendama', 'diabolo', 'poi', 'contact-juggling', 'cardistry', 'speedcubing', 'ephemera-sammeln', 'fuellfederhalter-sammeln', 'alte-computer', 'taschenrechner', 'radios', 'kameras', 'schallplatten', 'kassetten', 'minidiscs', 'spielfiguren', 'muenzen', 'wuerfel', 'emailschilder'], true)) {
            // 1.50.783: gepruefte hochaufloesende Einzelaufnahmen (keine Collagen).
            $relative = 'assets/hobby-depot-v150783/hobby-masters/' . $slug . '.webp';
        } else { return []; }
        $path = dirname(__DIR__) . '/' . $relative;
        if (!is_file($path)) { return []; }
        $size = @getimagesize($path);
        if (!is_array($size) || (int)$size[0] < 900 || (int)$size[1] < 300) { return []; }
        return [
            'url' => plugin_dir_url(dirname(__FILE__)) . $relative,
            'width' => (int)$size[0],
            'height' => (int)$size[1],
            'slug' => $slug,
        ];
    }

    /**
     * 1.50.759: Existing category imagery is assigned to at most ONE additional hobby.
     * 27 images are Finder-card-only (600x320); 5 wide images may fill a category hero.
     * Neither is a 3:2 Hobbyregister master. HD007 and featured master take priority.
     */
    /**
     * 1.50.766: look up the *actual* published page/term for a hobby.
     * Never guess /hobbyregister/<slug>/; on sites without that rewrite it
     * silently collapses to the register overview. No new table, option, or request.
     */
    private static function hobbyfinder_exact_target_v150766($name) {
        $slug = sanitize_title(trim((string)$name));
        if ($slug === '') { return null; }
        if (function_exists('get_posts')) {
            // WP's `name` matches post_name even for nested pages.
            foreach (['page','hdg_term'] as $post_type) {
                if ($post_type !== 'page' && function_exists('post_type_exists') && !post_type_exists($post_type)) { continue; }
                $posts = get_posts([
                    'post_type'=>$post_type, 'post_status'=>'publish', 'name'=>$slug,
                    'posts_per_page'=>15, 'no_found_rows'=>true, 'suppress_filters'=>true,
                ]);
                foreach ((array)$posts as $post) {
                    if (!$post instanceof WP_Post || (string)$post->post_status !== 'publish'
                        || sanitize_title((string)$post->post_name) !== $slug) { continue; }
                    // Only an exact slug is authoritative: no fuzzy match or overview page.
                    return $post;
                }
            }
        }
        if (function_exists('get_term_by')) {
            foreach (['category','journal_cat'] as $taxonomy) {
                if (function_exists('taxonomy_exists') && !taxonomy_exists($taxonomy)) { continue; }
                $term = get_term_by('slug',$slug,$taxonomy);
                if ($term instanceof WP_Term && sanitize_title((string)$term->slug) === $slug) { return $term; }
            }
        }
        return null;
    }

    /**
     * 1.50.768: HD007 already serves a distinct hobby DETAIL at
     * /hobbyregister/<hobby-slug>/; this is not a WordPress page/term.
     * Only call with a canonical record actually returned by the ready HD007
     * registry (search and Finder both obtain their rows from that registry).
     * Do not use the bare /hobbyregister/ listing as a hobby destination.
     */
    private static function hobbyregister_detail_url_v150768($canonical_name) {
        if (!function_exists('hd_hobbyregister_ready') || !hd_hobbyregister_ready()) { return ''; }
        $slug=sanitize_title(trim((string)$canonical_name));
        if ($slug === '' || $slug === 'hobbyregister' || !preg_match('/[a-z0-9]/i',$slug)) { return ''; }
        return home_url('/hobbyregister/' . $slug . '/');
    }

    private static function hobbyfinder_register_fallback_v150749($row) {
        // HD007 detail pages exist independently of WP page/category posts.
        // No image guessed: existing category/header check remains authoritative.
        return ['url'=>self::hobbyregister_detail_url_v150768((string)($row['name'] ?? '')), 'image'=>''];
    }

    private static function hobbyfinder_target_v150705($row) {
        $target = self::hobbyfinder_register_fallback_v150749($row);
        $name = trim((string)($row['name'] ?? ''));
        $node_id = trim((string)($row['target_node_id'] ?? ''));
        $obj = null;
        if ($node_id !== '' && function_exists('hd_category_registry_resolve')) {
            $obj = hd_category_registry_resolve($node_id);
            if ($obj instanceof WP_Post && ((string)$obj->post_status !== 'publish' || (string)$obj->post_type !== 'page')) {
                $obj = null;
            }
        }
        if (!$obj instanceof WP_Post && !$obj instanceof WP_Term) {
            $obj = self::hobbyfinder_exact_target_v150766($name);
        }
        // A parent category from target_node_id is NOT the hobby detail page.
        // Preserve the HD007 exact hobby link unless the object slug equals
        // this hobby's own slug. Prevents return to a wrong umbrella category.
        $hobby_slug=sanitize_title($name);
        if ($obj instanceof WP_Post && (string)$obj->post_status === 'publish'
            && sanitize_title((string)$obj->post_name) === $hobby_slug) {
            $target['url'] = (string)get_permalink($obj);
        } elseif ($obj instanceof WP_Term && sanitize_title((string)$obj->slug) === $hobby_slug) {
            $link=get_term_link($obj);
            if (!is_wp_error($link)) { $target['url']=(string)$link; }
        }
        // Single Bildzentrale decision by EXACT hobby, never by parent node.
        // If a WordPress page points to another slug, it may supply the LINK
        // but NOT a picture for the different hobby.
        $exact_page = $obj instanceof WP_Post && (string)$obj->post_status === 'publish'
            && sanitize_title((string)$obj->post_name) === sanitize_title($name) ? $obj : null;
        $img = self::hobby_image_center_v150769($name,$exact_page);
        $target['image'] = !empty($img['url']) ? (string)$img['url'] : '';
        return $target;
    }

    private static function hobbyfinder_rows_v150705() {
        if (!function_exists('hd_hobbyregister_ready') || !function_exists('hd_hobbyregister_finder_rows')) { return []; }
        if (!hd_hobbyregister_ready()) { return []; }
        $rows = hd_hobbyregister_finder_rows();
        if (!is_array($rows) || count($rows) !== 862) { return []; }
        $out = [];
        foreach ($rows as $row) {
            if (!is_array($row)) { continue; }
            $traits = is_array($row['traits'] ?? null) ? $row['traits'] : [];
            $profile = is_array($row['profile'] ?? null) ? $row['profile'] : [];
            $required = ['what_is_it','what_do_you_do','what_do_you_need','appeal'];
            $valid_profile = true;
            foreach ($required as $key) { if (trim((string)($profile[$key] ?? '')) === '') { $valid_profile = false; break; } }
            if (!$valid_profile) { continue; }
            $target = self::hobbyfinder_target_v150705($row);
            $out[] = [
                'id' => (string)($row['registry_id'] ?? ''),
                'name' => (string)($row['name'] ?? ''),
                'world' => (string)($row['world'] ?? ''),
                'url' => (string)$target['url'],
                'image' => (string)$target['image'],
                'motivation' => array_values((array)($traits['motivation_goals'] ?? [])),
                'social' => array_values((array)($traits['social_modes'] ?? [])),
                'dependency' => (string)($traits['social_dependency'] ?? ''),
                'location' => array_values((array)($traits['location_mode'] ?? [])),
                'time' => (string)($traits['session_length'] ?? ''),
                'budget' => (string)($traits['startup_budget'] ?? ''),
                'rental' => (string)($traits['rental_borrowing'] ?? ''),
                'space' => (string)($traits['active_space'] ?? ''),
                'physical' => (int)($traits['physical_intensity'] ?? 0),
                'pace' => (string)($traits['pace'] ?? ''),
                'schedule' => (string)($traits['schedule_flexibility'] ?? ''),
                'continuity' => (string)($traits['continuity_commitment'] ?? ''),
                'surprise' => (string)($traits['surprise_level'] ?? ''),
                'profile' => [
                    'what_is_it' => (string)$profile['what_is_it'],
                    'what_do_you_do' => (string)$profile['what_do_you_do'],
                    'what_do_you_need' => (string)$profile['what_do_you_need'],
                    'appeal' => (string)$profile['appeal'],
                ],
            ];
        }
        return count($out) === 862 ? $out : [];
    }

    private static function render_hobbyfinder_v150705($embedded_magazine_v150719=false) {
        $rows = self::hobbyfinder_rows_v150705();
        if (count($rows) !== 862) {
            return '<section class="hd-hf hd-hf-unavailable"><div class="hd-hf-inner"><p class="hd-hf-kicker">Hobby Depot</p><h1>Hobbyfinder</h1><p>Die Hobbyfinder-Daten werden gerade eingerichtet.</p></div></section>';
        }
        $json = wp_json_encode($rows, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json) || $json === '') { return ''; }
        $hero_json = wp_json_encode(self::asset_url('start-hero-text-v150616.jpg'), JSON_UNESCAPED_SLASHES);
        ob_start(); ?>
        <section class="hd-hf<?php echo $embedded_magazine_v150719 ? ' is-magazine-shell-v150719' : ''; ?>" data-hd-hobbyfinder="1.50.705">
          <div class="hd-hf-inner" id="hd-hf-app"></div>
        </section>
        <style id="hd-hf-style-v150705">
        .hd-hf{--hf-card:#fff;--hf-ink:#303236;--hf-muted:#74787d;--hf-line:#ddd9d1;--hf-green:var(--hd-petrol,#0f8f95);--hf-green-deep:var(--hd-petrol-deep,#0a777c);--hf-green2:#eef8f7;--hf-shadow:0 18px 45px rgba(34,38,42,.09);color:var(--hf-ink);padding:22px 0 72px}.hd-hf *{box-sizing:border-box}.hd-hf button{font:inherit}.hd-hf-inner{width:min(1050px,92vw);margin:0 auto}.hd-hf-topnav{display:flex;align-items:center;justify-content:center;gap:16px;margin:0 0 16px}.hd-hf-restart{display:inline-flex;align-items:center;gap:7px;min-height:34px;padding:0;border:0;background:transparent;color:#52656d;font-size:12px;font-weight:750;text-decoration:none;cursor:pointer}.hd-hf-restart:hover,.hd-hf-restart:focus-visible{color:var(--hf-green);outline:0}.hd-hf-hero{overflow:hidden;margin:0 auto 22px;border:1px solid rgba(63,71,75,.10);border-radius:5px;background:#f5f1e9}.hd-hf-hero-media{height:205px;overflow:hidden}.hd-hf-hero-media img{display:block;width:100%;height:100%;object-fit:cover;object-position:center 43%}.hd-hf-intro{max-width:760px;margin:0 auto 26px;text-align:center}.hd-hf-intro-kicker{margin:0 0 7px;color:var(--hf-green-deep);font-size:10px;font-weight:800;letter-spacing:.14em;text-transform:uppercase}.hd-hf h1{font-size:clamp(34px,4.2vw,52px);line-height:1.02;margin:0 0 10px;letter-spacing:-.035em;color:#17313c!important}.hd-hf-lead{font-size:16px;line-height:1.5;color:var(--hf-muted);margin:0 auto;max-width:650px}.hd-hf-progress-wrap{max-width:780px;margin:22px auto 34px}.hd-hf-progress-meta{display:flex;justify-content:space-between;font-size:12px;color:var(--hf-muted);margin-bottom:10px}.hd-hf-progress{height:7px;background:#dedbd4;border-radius:999px;overflow:hidden}.hd-hf-progress>i{display:block;height:100%;background:var(--hf-green);border-radius:999px;transition:.25s}.hd-hf-panel{max-width:900px;margin:auto}.hd-hf-question{text-align:center;font-size:clamp(25px,3vw,36px);margin:0 0 9px;letter-spacing:-.02em}.hd-hf-hint{text-align:center;color:var(--hf-muted);margin:0 0 24px}.hd-hf-choices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.hd-hf-choice{position:relative;display:grid;grid-template-columns:46px minmax(0,1fr) 22px;align-items:center;gap:13px;background:var(--hf-card);border:1px solid var(--hf-line);border-radius:18px;padding:17px 17px 17px 16px;text-align:left;min-height:92px;cursor:pointer;transition:.16s}.hd-hf-choice:hover{transform:translateY(-2px);box-shadow:var(--hf-shadow);border-color:rgba(15,143,149,.34)}.hd-hf-choice.is-selected{border:2px solid var(--hf-green);background:var(--hf-green2);padding:16px 16px 16px 15px}.hd-hf-choice-icon{display:grid;width:42px;height:42px;place-items:center;border-radius:50%;background:#f5f1e9;color:#56656a;transition:.16s}.hd-hf-choice-icon svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.hd-hf-choice.is-selected .hd-hf-choice-icon{background:#fff;color:var(--hf-green)}.hd-hf-choice-copy{min-width:0}.hd-hf-choice b{display:block;font-size:17px;margin-bottom:5px;color:#28373e}.hd-hf-choice small{display:block;color:var(--hf-muted);line-height:1.35}.hd-hf-choice-check{display:grid;width:21px;height:21px;place-items:center;border-radius:50%;background:var(--hf-green);color:#fff;font-size:12px;font-weight:900;opacity:0;transform:scale(.72);transition:.16s}.hd-hf-choice.is-selected .hd-hf-choice-check{opacity:1;transform:scale(1)}.hd-hf-actions{display:flex;justify-content:space-between;align-items:center;margin-top:24px}.hd-hf-btn{border:0;border-radius:999px;padding:13px 22px;cursor:pointer;text-decoration:none}.hd-hf-btn-primary{background:var(--hf-green);color:#fff;min-width:135px;font-weight:750}.hd-hf-btn-primary:hover,.hd-hf-btn-primary:focus-visible{background:var(--hf-green-deep);outline:0}.hd-hf-btn-ghost{background:transparent;color:var(--hf-muted)}.hd-hf-btn:disabled{opacity:.3;cursor:not-allowed}.hd-hf-results-head{display:flex;justify-content:space-between;gap:20px;align-items:end;margin:12px 0 24px}.hd-hf-results-head h2{font-size:38px;margin:0;color:#17313c}.hd-hf-mini{font-size:12px;color:var(--hf-green-deep);font-weight:800;letter-spacing:.08em;text-transform:uppercase}.hd-hf-surprise{border:1px solid var(--hf-line);background:#fff;border-radius:999px;padding:12px 16px;cursor:pointer}.hd-hf-surprise:hover,.hd-hf-surprise:focus-visible{border-color:var(--hf-green);color:var(--hf-green-deep);outline:0}.hd-hf-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;align-items:stretch}.hd-hf-card{background:#fff;border:1px solid var(--hf-line);border-radius:18px;overflow:hidden;display:flex;flex-direction:column;height:100%}.hd-hf-visual{height:154px;background:#f5f1e9;display:flex;align-items:center;justify-content:center;font-size:38px;font-weight:800;color:var(--hf-green);overflow:hidden}.hd-hf-visual img{display:block;width:100%;height:100%;object-fit:cover}.hd-hf-visual-fallback{display:grid;width:58px;height:58px;place-items:center;border-radius:50%;background:#fff;color:var(--hf-green);font-size:30px}.hd-hf-body{padding:18px;display:flex;flex-direction:column;flex:1}.hd-hf-score{font-size:12px;font-weight:800;color:var(--hf-green-deep);letter-spacing:.08em;text-transform:uppercase}.hd-hf-body h3{font-size:22px;margin:7px 0 12px}.hd-hf-profile{margin:13px 0 12px;display:grid;gap:7px}.hd-hf-profile p,.hd-hf-appeal{margin:0;font-size:12px;line-height:1.38;color:#444}.hd-hf-profile b,.hd-hf-appeal b{color:#222}.hd-hf-appeal{margin-top:12px;padding-top:10px;border-top:1px solid var(--hf-line)}.hd-hf-card-link{display:inline-flex;align-items:center;align-self:flex-start;margin-top:auto;padding-top:14px;color:var(--hf-green-deep);font-weight:800;text-decoration:none;transition:color .16s ease,transform .16s ease}.hd-hf-card-link:hover,.hd-hf-card-link:focus-visible{color:var(--hf-green);transform:translateX(4px);text-decoration:underline;text-underline-offset:3px;outline:0}.hd-hf-no-link{display:inline-flex;margin-top:auto;padding-top:14px;color:var(--hf-muted);font-size:12px}.hd-hf-foot-actions{display:flex;justify-content:center;gap:10px;margin-top:28px}.hd-hf-unavailable{padding:70px 0}.hd-hf-unavailable .hd-hf-inner{max-width:760px}.hd-hf-kicker{font-size:12px;text-transform:uppercase;letter-spacing:.12em;color:var(--hf-muted)}
.hd-hf.is-magazine-shell-v150719{padding-top:8px}.hd-hf.is-magazine-shell-v150719 .hd-hf-inner{width:min(1050px,calc(100% - 24px))}
                @media(max-width:720px){.hd-hf{padding-top:16px}.hd-hf-topnav{margin-bottom:12px}.hd-hf-hero-media{height:150px}.hd-hf-choices,.hd-hf-grid{grid-template-columns:1fr}.hd-hf-choice{min-height:82px}.hd-hf-results-head{align-items:start;flex-direction:column}.hd-hf h1{font-size:38px}.hd-hf-hero{margin-bottom:18px}}
        </style>
        <script id="hd-hf-script-v150705">
        (function(){
        const hobbies=<?php echo $json; ?>;
        const heroUrl=<?php echo $hero_json; ?>;
        const embeddedMagazine=<?php echo $embedded_magazine_v150719 ? 'true' : 'false'; ?>;
        const qs=[
        {id:'motivation',q:'Was soll dir dein Hobby vor allem geben?',hint:'Wähle bis zu zwei Dinge, die dir wichtig sind.',multi:2,opts:[['ruhe','Abschalten & Ruhe','Etwas, bei dem der Kopf leiser wird.'],['kreativ','Kreativ sein','Gestalten, bauen oder etwas Eigenes schaffen.'],['lernen','Lernen & tüfteln','Verstehen, ausprobieren, besser werden.'],['bewegung','Bewegung','Raus aus dem Kopf, rein in den Körper.'],['natur','Natur & Abenteuer','Draußen sein, entdecken, unterwegs sein.'],['sozial','Menschen treffen','Gemeinsam erleben statt allein versinken.'],['sammeln','Sammeln & ordnen','Finden, kuratieren, vervollständigen.'],['egal','Überrasch mich','Ich möchte bewusst offen bleiben.']]},
        {id:'social',q:'Wie möchtest du dein Hobby am liebsten machen?',hint:'Das kann auf Wunsch ein harter Filter sein.',opts:[['solo','Alleine','Unabhängig von anderen loslegen.'],['pair','Zu zweit','Gemeinsam mit einer Person.'],['group','Mit mehreren','Gruppe, Team oder Community.'],['egal','Flexibel / egal','Ich bin für alles offen.']]},
        {id:'place',q:'Wo möchtest du es machen?',hint:'Nur das auswählen, was für dich wirklich wichtig ist.',opts:[['in','Drinnen','Zuhause, Werkstatt, Halle oder Spezialort.'],['out','Draußen','Natur, Gelände, Wasser oder öffentlicher Raum.'],['both','Beides','Drinnen und draußen sind okay.'],['egal','Egal','Der Ort soll mich nicht einschränken.']]},
        {id:'time',q:'Wie viel Zeit möchtest du pro Einheit einplanen?',hint:'Nicht pro Woche – sondern für einen typischen Hobby-Moment.',opts:[['0','Unter 30 Minuten','Kurze Einheiten müssen möglich sein.'],['1','30–90 Minuten','Gut in einen normalen Alltag integrierbar.'],['2','1,5–4 Stunden','Ich nehme mir gern bewusst Zeit.'],['3','Halber Tag oder mehr','Darf ruhig ein kleines Ereignis sein.'],['egal','Egal','Zeit ist nicht der entscheidende Punkt.']]},
        {id:'budget',q:'Was darf der Einstieg ungefähr kosten?',hint:'Leihen oder Mieten kann teure Hobbys trotzdem möglich machen.',opts:[['0','Bis 25 €','So günstig wie möglich starten.'],['1','Bis 100 €','Ein überschaubares Einstiegsbudget.'],['2','Bis 300 €','Gute Grundausstattung ist okay.'],['3','Bis 1.000 €','Ich investiere, wenn es passt.'],['egal','Budget zweitrangig','Der Treffer ist wichtiger als der Preis.']]},
        {id:'space',q:'Wie viel Platz hast du?',hint:'Platz beim Ausüben – Lagerplatz können wir später feinjustieren.',opts:[['0','Fast keinen','Handfläche, Sofa, sehr kleine Fläche.'],['1','Tisch / kleine Ecke','Ein fester Tisch oder kleiner Bereich reicht.'],['3','Ein Zimmer / Bereich','Etwas mehr Bewegungs- oder Arbeitsfläche ist okay.'],['4','Viel Platz / Werkstatt','Auch größere Projekte oder Ausrüstung passen.'],['egal','Platz ist egal','Auch Halle, Gelände oder große Fläche ist möglich.']]},
        {id:'intensity',q:'Wie aktiv darf es sein?',hint:'Es geht um das typische Gefühl – nicht um Leistungssport.',opts:[['1','Sehr ruhig','Sitzen, konzentrieren, entspannen.'],['2','Etwas Bewegung','Nicht nur stillsitzen, aber entspannt.'],['4','Aktiv','Ich möchte mich deutlich bewegen.'],['5','Sportlich / Action','Anstrengung und Tempo sind willkommen.'],['egal','Egal','Ich lasse mich überraschen.']]},
        {id:'commitment',q:'Wie verbindlich darf dein Hobby sein?',hint:'Der letzte Schritt – danach kommen deine Treffer.',opts:[['spontan','Jederzeit spontan','Anfangen, aufhören, pausieren wann ich will.'],['flex','Flexibel planbar','Etwas Vorbereitung ist okay.'],['regular','Regelmäßig ist okay','Routine, Pflege oder Training schrecken mich nicht.'],['fixed','Feste Termine sind okay','Verein, Gruppe oder Buchung passt zu mir.'],['egal','Egal','Verbindlichkeit ist kein Ausschlusskriterium.']]}
        ];
        const A={motivation:[],social:null,place:null,time:null,budget:null,space:null,intensity:null,commitment:null};let step=0,surprise=false;
        const spaceRank={minimal:0,tischbereich:1,kleiner_bereich:2,raum:3,grosser_bereich:4,sehr_grosser_bereich:5},budgetRank={'0_bis_25':0,'25_bis_100':1,'100_bis_300':2,'300_bis_1000':3,'1000_plus':4},timeRank={unter_30_min:0,'30_bis_90_min':1,'90_bis_240_min':2,'halber_tag_plus':3};
        const mot={ruhe:['entspannen_abschalten'],kreativ:['kreativ_ausdruecken','bauen_herstellen'],lernen:['lernen_verstehen','herausforderung_meistern'],bewegung:['koerperlich_aktiv_sein'],natur:['natur_erleben','entdecken_abenteuer'],sozial:['sozialer_kontakt'],sammeln:['sammeln_ordnen']};
        const app=document.getElementById('hd-hf-app');if(!app)return;
        const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
        const svg=p=>`<svg viewBox="0 0 24 24" aria-hidden="true">${p}</svg>`;
        const ico={
        moon:svg('<path d="M20 15.2A8.5 8.5 0 1 1 8.8 4 7 7 0 0 0 20 15.2Z"/>'),spark:svg('<path d="m12 3 1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7-4.7-1.8 4.7-1.8L12 3Z"/><path d="m18 15 .8 2.2L21 18l-2.2.8L18 21l-.8-2.2L15 18l2.2-.8L18 15Z"/>'),book:svg('<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H11v16H6.5A2.5 2.5 0 0 0 4 21.5v-16Z"/><path d="M20 5.5A2.5 2.5 0 0 0 17.5 3H13v16h4.5a2.5 2.5 0 0 1 2.5 2.5v-16Z"/>'),move:svg('<path d="m13 5 3-2 2 3"/><path d="m11 8 3 2 2 5"/><path d="m10 10-3 3-4 1"/><path d="m12 14-2 6"/><path d="m16 15 4 3"/><circle cx="10" cy="4" r="2"/>'),tree:svg('<path d="M12 22V10"/><path d="M7 14c-2.5 0-4-1.7-4-4 0-2 1.5-3.5 3.4-3.8C7 3.8 9 2 11.5 2 14.5 2 17 4.5 17 7.5c2.3.2 4 2.1 4 4.5 0 2.8-2 5-5 5H8"/>'),people:svg('<circle cx="9" cy="8" r="3"/><path d="M3.5 20c.5-4 2.3-6 5.5-6s5 2 5.5 6"/><circle cx="17" cy="9" r="2.3"/><path d="M15.5 15.5c2.8-.7 4.7.8 5 3.5"/>'),collect:svg('<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>'),dice:svg('<rect x="4" y="4" width="16" height="16" rx="3"/><circle cx="9" cy="9" r="1"/><circle cx="15" cy="9" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="9" cy="15" r="1"/><circle cx="15" cy="15" r="1"/>'),user:svg('<circle cx="12" cy="8" r="3.5"/><path d="M5 21c.7-4.5 3-6.8 7-6.8s6.3 2.3 7 6.8"/>'),pair:svg('<circle cx="8" cy="9" r="3"/><circle cx="16" cy="9" r="3"/><path d="M2.5 20c.5-3.6 2.3-5.5 5.5-5.5S13 16.4 13.5 20"/><path d="M10.5 20c.5-3.6 2.3-5.5 5.5-5.5s5 1.9 5.5 5.5"/>'),group:svg('<circle cx="12" cy="7" r="2.8"/><circle cx="5.5" cy="10" r="2"/><circle cx="18.5" cy="10" r="2"/><path d="M6 21c.5-4.2 2.4-6.2 6-6.2s5.5 2 6 6.2"/><path d="M1.5 19c.4-2.8 1.7-4.2 4-4.2"/><path d="M22.5 19c-.4-2.8-1.7-4.2-4-4.2"/>'),shuffle:svg('<path d="M4 7h3c5 0 5 10 10 10h3"/><path d="m17 14 3 3-3 3"/><path d="M4 17h3c1.6 0 2.7-1 3.7-2.4"/><path d="M13.3 9.4C14.3 8 15.4 7 17 7h3"/><path d="m17 4 3 3-3 3"/>'),home:svg('<path d="m3 11 9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/>'),sun:svg('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'),both:svg('<path d="M4 7h16M4 17h16"/><circle cx="8" cy="7" r="3"/><circle cx="16" cy="17" r="3"/>'),clock:svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),wallet:svg('<path d="M4 6.5h14a2 2 0 0 1 2 2V18H5a2 2 0 0 1-2-2V7.5A2.5 2.5 0 0 1 5.5 5H17"/><path d="M20 11h-5a2 2 0 0 0 0 4h5"/>'),tiny:svg('<circle cx="12" cy="12" r="3"/><path d="M5 5h4M5 5v4M19 5h-4M19 5v4M5 19h4M5 19v-4M19 19h-4M19 19v-4"/>'),table:svg('<path d="M4 8h16v5H4zM7 13v7M17 13v7"/>'),room:svg('<rect x="4" y="4" width="16" height="16" rx="1"/><path d="M8 20v-8h8v8"/>'),workshop:svg('<path d="m14 6 4-4 4 4-4 4"/><path d="m16 8-9 9"/><path d="m5 15-3 3 4 4 3-3"/>'),leaf:svg('<path d="M20 4C11 4 5 8 5 15c0 3 2 5 5 5 7 0 10-7 10-16Z"/><path d="M6 19c3-5 6-8 11-11"/>'),walk:svg('<circle cx="12" cy="4" r="2"/><path d="m10 8 4 2 1 5"/><path d="m10 10-3 4"/><path d="m11 14-2 6"/><path d="m15 15 3 5"/>'),bolt:svg('<path d="m13 2-7 12h6l-1 8 7-12h-6l1-8Z"/>'),calendar:svg('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/>'),repeat:svg('<path d="M20 7h-9a5 5 0 0 0-5 5"/><path d="m17 4 3 3-3 3"/><path d="M4 17h9a5 5 0 0 0 5-5"/><path d="m7 20-3-3 3-3"/>')};
        const iconMap={motivation:{ruhe:'moon',kreativ:'spark',lernen:'book',bewegung:'move',natur:'tree',sozial:'people',sammeln:'collect',egal:'dice'},social:{solo:'user',pair:'pair',group:'group',egal:'shuffle'},place:{in:'home',out:'sun',both:'both',egal:'shuffle'},time:{'0':'clock','1':'clock','2':'clock','3':'clock',egal:'shuffle'},budget:{'0':'wallet','1':'wallet','2':'wallet','3':'wallet',egal:'shuffle'},space:{'0':'tiny','1':'table','3':'room','4':'workshop',egal:'shuffle'},intensity:{'1':'leaf','2':'walk','4':'move','5':'bolt',egal:'shuffle'},commitment:{spontan:'bolt',flex:'shuffle',regular:'repeat',fixed:'calendar',egal:'shuffle'}};
        function choiceIcon(q,x){return ico[(iconMap[q]||{})[x]||'spark']||ico.spark}
        function iconFor(w){return {gestalten:'◇',fertigen:'⬡',technik:'⌁',forschen:'✦',pflanzen:'♧',tiere:'○',bewegen:'↗',sammeln:'▦'}[w]||'✦'}
        function topnav(){return `<div class="hd-hf-topnav"><button type="button" class="hd-hf-restart" data-action="restart">↻ Neu starten</button></div>`}
        function hero(){if(embeddedMagazine)return '';return `<section class="hd-hf-hero"><div class="hd-hf-hero-media"><img src="${esc(heroUrl)}" alt="Hobbyideen entdecken" decoding="async" fetchpriority="high"></div></section><section class="hd-hf-intro"><p class="hd-hf-intro-kicker">Hobbyfinder</p><h1>Finde dein Hobby</h1><p class="hd-hf-lead">Acht kurze Fragen – danach bekommst du eine überschaubare Auswahl.</p></section>`}
        function resultVisual(h){return h.image?`<div class="hd-hf-visual"><img src="${esc(h.image)}" alt="${esc(h.name)}" loading="lazy" decoding="async"></div>`:''}
        function score(h){let s=0,reasons=[];let targets=[];(A.motivation||[]).filter(x=>x!=='egal').forEach(x=>targets.push(...(mot[x]||[])));if(targets.length){const uniq=[...new Set(targets)],hit=[...new Set(targets.filter(x=>(h.motivation||[]).includes(x)))].length/uniq.length;s+=22*hit;if(hit>.2)reasons.push('passt zu deinen Zielen')}else s+=11;if(A.social&&A.social!=='egal'){let ok=A.social==='solo'?(h.social||[]).includes('solo'):A.social==='pair'?(h.social||[]).includes('zu_zweit'):((h.social||[]).includes('gruppe')||(h.social||[]).includes('kleingruppe')||(h.social||[]).includes('community'));if(!ok)return null;s+=16;reasons.push(A.social==='solo'?'alleine möglich':A.social==='pair'?'zu zweit möglich':'mit mehreren möglich')}else s+=8;if(A.place&&A.place!=='egal'&&A.place!=='both'){const want=A.place==='in'?'drinnen':'draussen';if(!(h.location||[]).includes(want))return null;s+=14;reasons.push(want==='drinnen'?'drinnen':'draußen')}else s+=7;if(A.time&&A.time!=='egal'){const mx=+A.time,rv=timeRank[h.time];if(rv===undefined||rv>mx)return null;s+=12*(1-(rv/(mx+1))*.15);reasons.push('Zeitfenster passt')}else s+=6;if(A.budget&&A.budget!=='egal'){const mx=+A.budget,rv=budgetRank[h.budget];if(rv===undefined)return null;if(rv>mx&&!['leicht','teilweise'].includes(h.rental))return null;s+=12*(rv<=mx?1:.65);reasons.push(rv<=mx?'Budget passt':'Leihen/Mieten möglich')}else s+=6;if(A.space&&A.space!=='egal'){const mx=+A.space,rv=spaceRank[h.space];if(rv===undefined||rv>mx)return null;s+=10*(1-(rv/(mx+1))*.1);reasons.push('Platz passt')}else s+=5;if(A.intensity&&A.intensity!=='egal'){const diff=Math.abs((+h.physical)-(+A.intensity));s+=8*Math.max(0,1-diff/4);if(diff<=1)reasons.push('Aktivitätsniveau passt')}else s+=4;if(A.commitment==='spontan'){const ok=h.schedule==='jederzeit_spontan'&&h.continuity==='jederzeit_pausierbar';s+=6*(ok?1:.25);if(ok)reasons.push('spontan machbar')}else if(A.commitment==='regular'){s+=6*(['regelmaessige_bindung','laufende_pflicht'].includes(h.continuity)?1:.5)}else if(A.commitment==='fixed'){s+=6*(['feste_zeiten','termin_oder_buchung'].includes(h.schedule)?1:.65)}else s+=3;if(surprise)s+=({klassisch:0,nische:2,ungewoehnlich:5,sehr_schraeg:8}[h.surprise]||0);return{score:Math.min(100,Math.round(s)),reasons:[...new Set(reasons)].slice(0,3)}}
        function isSel(q,x){return q.multi?(A[q.id]||[]).includes(x):A[q.id]===x}function hasSel(q){return q.multi?(A[q.id]||[]).length>0:!!A[q.id]}
        function pick(x){const q=qs[step];if(q.multi){let a=A[q.id]||[];if(x==='egal')a=['egal'];else{a=a.filter(v=>v!=='egal');a.includes(x)?a=a.filter(v=>v!==x):(a.length<q.multi?a.push(x):a=[a[1],x])}A[q.id]=a}else A[q.id]=x;render()}
        function next(){if(hasSel(qs[step])){step++;render()}}function back(){if(step>0){step--;render()}}function edit(){step=0;render()}function resetAnswers(){A.motivation=[];A.social=null;A.place=null;A.time=null;A.budget=null;A.space=null;A.intensity=null;A.commitment=null;step=0;surprise=false;render()}function toggleSurprise(){surprise=!surprise;results()}
        function render(){if(step>=qs.length)return results();const q=qs[step];app.innerHTML=topnav()+(step===0?hero():'')+`<div class="hd-hf-progress-wrap"><div class="hd-hf-progress-meta"><span>Schritt ${step+1} von 8</span><span>${Math.round((step+1)/8*100)} %</span></div><div class="hd-hf-progress"><i style="width:${(step+1)/8*100}%"></i></div></div><section class="hd-hf-panel"><h2 class="hd-hf-question">${esc(q.q)}</h2><p class="hd-hf-hint">${esc(q.hint)}</p><div class="hd-hf-choices">${q.opts.map(o=>`<button type="button" class="hd-hf-choice ${isSel(q,o[0])?'is-selected':''}" data-pick="${esc(o[0])}"><span class="hd-hf-choice-icon" aria-hidden="true">${choiceIcon(q.id,o[0])}</span><span class="hd-hf-choice-copy"><b>${esc(o[1])}</b><small>${esc(o[2])}</small></span><span class="hd-hf-choice-check" aria-hidden="true">✓</span></button>`).join('')}</div><div class="hd-hf-actions"><button type="button" class="hd-hf-btn hd-hf-btn-ghost" data-action="back" ${step===0?'disabled':''}>← Zurück</button><button type="button" class="hd-hf-btn hd-hf-btn-primary" data-action="next" ${hasSel(q)?'':'disabled'}>Weiter →</button></div></section>`;bind()}
        function results(){const ranked=hobbies.map(h=>[h,score(h)]).filter(x=>x[1]).sort((a,b)=>b[1].score-a[1].score).slice(0,6);app.innerHTML=topnav()+`<div class="hd-hf-results-head"><div><div class="hd-hf-mini">DEINE AUSWAHL</div><h2>Das könnte zu dir passen.</h2></div><button type="button" class="hd-hf-surprise" data-action="surprise">${surprise?'✓ ':''}Überrasch mich</button></div><div class="hd-hf-grid">${ranked.map(([h,r])=>`<article class="hd-hf-card">${resultVisual(h)}<div class="hd-hf-body"><div class="hd-hf-score">${r.score} % passend</div><h3>${esc(h.name)}</h3><div class="hd-hf-profile"><p><b>Was ist das?</b> ${esc(h.profile.what_is_it)}</p><p><b>Was macht man?</b> ${esc(h.profile.what_do_you_do)}</p><p><b>Was braucht man?</b> ${esc(h.profile.what_do_you_need)}</p></div><p class="hd-hf-appeal"><b>Der Reiz:</b> ${esc(h.profile.appeal)}</p>${h.url?`<a class="hd-hf-card-link" href="${esc(h.url)}">Hobby ansehen →</a>`:`<span class="hd-hf-no-link">Zielseite noch nicht verfügbar</span>`}</div></article>`).join('')}</div><div class="hd-hf-foot-actions"><button type="button" class="hd-hf-btn hd-hf-btn-ghost" data-action="edit">← Auswahl verändern</button><button type="button" class="hd-hf-btn hd-hf-btn-primary" data-action="restart">Neu starten</button></div>`;bind()}
        function bind(){app.querySelectorAll('[data-pick]').forEach(b=>b.addEventListener('click',()=>pick(b.getAttribute('data-pick'))));const b=app.querySelector('[data-action="back"]');if(b)b.addEventListener('click',back);const n=app.querySelector('[data-action="next"]');if(n)n.addEventListener('click',next);const s=app.querySelector('[data-action="surprise"]');if(s)s.addEventListener('click',toggleSurprise);const e=app.querySelector('[data-action="edit"]');if(e)e.addEventListener('click',edit);app.querySelectorAll('[data-action="restart"]').forEach(r=>r.addEventListener('click',resetAnswers))}
        render();
        })();
        </script>
        <?php return (string)ob_get_clean();
    }



    private static function magazine_brush_url_v150719() {
        return plugin_dir_url(dirname(__FILE__)) . 'assets/hobby-depot-v150641/brush-underline-v150641.webp?ver=' . rawurlencode(self::RELEASE);
    }

    private static function render_magazine_hero_v150719($title, $def, $root=false) {
        $title = trim((string)$title);
        $def = is_array($def) ? $def : [];
        $claim = trim((string)($def['claim'] ?? ''));
        $intro = trim((string)($def['hero'] ?? ''));
        $asset = trim((string)($def['asset'] ?? ''));
        $scene_w = max(1,(int)($def['w'] ?? 1600));
        $scene_h = max(1,(int)($def['h'] ?? 587));
        if ($title === '' || $asset === '') { return ''; }
        $brush = self::magazine_brush_url_v150719();
        $img = self::asset_url($asset);
        $classes = 'hd-page-intro hd-hub2-intro hd-bp-hero hd-hub2-hero-fullbleed hd-hub2-scene-preserve hd-mag-hero-v150719';
        if ($root) { $classes .= ' is-magazine-root-v150719'; }
        $scene_style='--hd-scene-w:'.$scene_w.'px;--hd-scene-h:'.$scene_h.'px;--hd-scene-ratio:'.$scene_w.'/'.$scene_h.';';
        $html = '<section class="'.esc_attr($classes).'" style="'.esc_attr($scene_style).'">';
        $html .= '<div class="hd-bp-hero-copy">';
        if ($claim !== '') {
            $html .= '<span class="hd-bp-brush-claim" style="--hd-bp-brush:url(&quot;'.esc_url($brush).'&quot;)">'.esc_html($claim).'</span>';
        }
        $html .= '<h1>'.esc_html($title).'</h1>';
        if ($intro !== '') { $html .= '<div class="hd-hub2-hero-intro"><p>'.esc_html($intro).'</p></div>'; }
        $html .= '</div><div class="hd-bp-hero-media"><img src="'.esc_url($img).'" alt="'.esc_attr($title).'" decoding="async" fetchpriority="high"></div></section>';
        return $html;
    }

    private static function render_magazine_intro_v150719($title, $def) {
        $def = is_array($def) ? $def : [];
        $lead = trim((string)($def['lead'] ?? ''));
        $more = trim((string)($def['more'] ?? ''));
        if ($lead === '' && $more === '') { return ''; }
        $html = '<section class="hd-hub2-longcopy hd-hub2-longcopy-benchmark-v150698 hd-mag-intro-v150719" aria-label="Mehr zu '.esc_attr($title).'">';
        if ($lead !== '') { $html .= '<div class="hd-hub2-longcopy-lead"><p>'.esc_html($lead).'</p></div>'; }
        if ($more !== '') {
            $html .= '<details class="hd-hub2-more"><summary aria-label="Mehr zu '.esc_attr($title).' anzeigen"><span class="screen-reader-text">Mehr zu '.esc_html($title).' anzeigen</span></summary><div>'.self::paragraph_markup_explicit_v150698($more).'</div></details>';
        }
        return $html.'</section>';
    }

    private static function magazine_journal_terms_v150719($def, $page=null) {
        if (!is_array($def) || !taxonomy_exists('journal_cat')) { return []; }
        $terms = [];
        if ($page instanceof WP_Post && self::registry_ready()) {
            foreach (self::magazine_registry_children_v150720($page) as $node) {
                if ((string)($node['object_type'] ?? '') !== 'journal_cat') { continue; }
                $obj = hd_category_registry_resolve((string)($node['node_id'] ?? ''));
                if ($obj instanceof WP_Term && (string)$obj->taxonomy === 'journal_cat') { $terms[] = $obj; }
            }
            if ($terms) { return $terms; }
        }
        foreach ((array)($def['terms'] ?? []) as $slug) {
            $term = get_term_by('slug', sanitize_title((string)$slug), 'journal_cat');
            if ($term instanceof WP_Term) { $terms[] = $term; }
        }
        return $terms;
    }

    private static function magazine_query_posts_v150719($def=null, $limit=12, $affiliate_only=false, $page=null) {
        if (!taxonomy_exists('journal_cat')) { return []; }
        $args = [
            'post_type'=>'post',
            'post_status'=>'publish',
            'posts_per_page'=>max(1,min(24,(int)$limit)),
            'ignore_sticky_posts'=>true,
            'no_found_rows'=>true,
        ];
        $terms = is_array($def) ? self::magazine_journal_terms_v150719($def,$page) : [];
        if ($terms) {
            $args['tax_query'] = [[
                'taxonomy'=>'journal_cat',
                'field'=>'term_id',
                'terms'=>array_map(static function($term){ return (int)$term->term_id; }, $terms),
                'operator'=>'IN',
            ]];
        } elseif ($def === null) {
            $args['tax_query'] = [[
                'taxonomy'=>'journal_cat',
                'operator'=>'EXISTS',
            ]];
        } else {
            return [];
        }
        $posts = get_posts($args);
        if (!$posts) { return []; }
        $out = [];
        foreach ($posts as $post) {
            if (!$post instanceof WP_Post) { continue; }
            $is_aff = self::is_affiliate_article_v150719($post);
            if ($affiliate_only !== $is_aff) { continue; }
            $out[] = $post;
            if (count($out) >= $limit) { break; }
        }
        return $out;
    }

    private static function is_affiliate_article_v150719($post) {
        if (!$post instanceof WP_Post) { return false; }
        foreach (['_hd_affiliate_article','_pftk_affiliate_article','affiliate_article'] as $key) {
            $v = get_post_meta($post->ID, $key, true);
            if (in_array(strtolower(trim((string)$v)), ['1','yes','ja','true','affiliate'], true)) { return true; }
        }
        $hay = strtolower((string)$post->post_content);
        foreach (['affiliate_click=', '[pp_affiliate', 'data-ppar', 'rel="sponsored"', "rel='sponsored'"] as $marker) {
            if (strpos($hay, strtolower($marker)) !== false) { return true; }
        }
        return false;
    }

    private static function magazine_post_card_v150719($post, $badge='') {
        if (!$post instanceof WP_Post) { return ''; }
        $url = get_permalink($post);
        $img = (string)get_the_post_thumbnail_url($post->ID, 'medium_large');
        $excerpt = trim((string)$post->post_excerpt);
        if ($excerpt === '') { $excerpt = wp_strip_all_tags(strip_shortcodes((string)$post->post_content)); }
        $html = '<article class="hd-mag-post-card-v150719">';
        if ($img !== '') { $html .= '<a class="hd-mag-post-image-v150719" href="'.esc_url($url).'"><img src="'.esc_url($img).'" alt="'.esc_attr(get_the_title($post)).'" loading="lazy"></a>'; }
        $html .= '<div class="hd-mag-post-copy-v150719">'.($badge!==''?'<span class="hd-mag-post-badge-v150719">'.esc_html($badge).'</span>':'').'<h3><a href="'.esc_url($url).'">'.esc_html(get_the_title($post)).'</a></h3><p>'.esc_html(wp_trim_words($excerpt, 22, ' …')).'</p><a class="hd-mag-read-v150719" href="'.esc_url($url).'">Weiterlesen →</a></div></article>';
        return $html;
    }

    private static function render_magazine_banner_v150719() {
        $html = self::affiliate_slot('journal_banner');
        $preview = false;
        if ($html === '') { $html = self::affiliate_preview_placeholder('banner','journal_banner'); $preview = $html !== ''; }
        if ($html === '') { return ''; }
        return '<aside class="hd-mag-feed-banner-v150719'.($preview?' is-preview':'').'" aria-label="Anzeige / Partner"><span>Anzeige / Partner</span><div>'.$html.'</div></aside>';
    }

    private static function render_magazine_feed_v150719($def=null, $heading='Aktuelle Beiträge', $page=null, $include_banner=true) {
        $posts = self::magazine_query_posts_v150719($def, 6, false, $page);
        $banner = $include_banner ? self::render_magazine_banner_v150719() : '';
        if (!$posts) {
            if ($banner !== '') { return '<section class="hd-portal-section hd-mag-feed-v150719">'.$banner.'</section>'; }
            if (!self::logged_in_preview()) { return ''; }
            return '<section class="hd-portal-section hd-mag-feed-v150719"><header><span>Magazin</span><h2>'.esc_html($heading).'</h2></header><div class="hd-empty-admin">Nur eingeloggt sichtbar: Noch keine passenden Magazinbeiträge vorhanden.</div></section>';
        }
        $first = array_slice($posts,0,3);
        $second = array_slice($posts,3,3);
        $html = '<section class="hd-portal-section hd-mag-feed-v150719"><header><span>Magazin</span><h2>'.esc_html($heading).'</h2></header><div class="hd-mag-post-grid-v150719">';
        foreach ($first as $post) { $html .= self::magazine_post_card_v150719($post); }
        $html .= '</div>';
        if ($banner !== '') { $html .= $banner; }
        if ($second) {
            $html .= '<div class="hd-mag-post-grid-v150719 hd-mag-post-grid-second-v150719">';
            foreach ($second as $post) { $html .= self::magazine_post_card_v150719($post); }
            $html .= '</div>';
        }
        return $html.'</section>';
    }

    private static function render_magazine_products_v150719() {
        $items = [];
        for ($i=1; $i<=3; $i++) {
            $slot = 'journal_product_'.$i;
            $html = self::affiliate_slot($slot);
            if ($html === '') { $html = self::affiliate_preview_placeholder('product',$slot); }
            if ($html !== '') { $items[] = '<div class="hd-context-product">'.$html.'</div>'; }
        }
        if (!$items) { return ''; }
        return '<section class="hd-portal-section hd-mag-products-v150719"><header><span>Anzeige · Partner</span><h2>Passende Produkte</h2></header><div class="hd-context-product-grid">'.implode('',$items).'</div></section>';
    }

    private static function render_magazine_affiliate_articles_v150719($def=null, $page=null) {
        $posts = self::magazine_query_posts_v150719($def, 3, true, $page);
        if (!$posts) {
            if (!self::logged_in_preview()) { return ''; }
            return '<section class="hd-portal-section hd-mag-affiliate-v150719"><header><span>Empfehlungen</span><h2>Kaufberatung &amp; Affiliate-Artikel</h2></header><div class="hd-empty-admin">Nur eingeloggt sichtbar: Noch keine passenden Affiliate-Artikel vorhanden.</div></section>';
        }
        $cards = '';
        foreach ($posts as $post) { $cards .= self::magazine_post_card_v150719($post,'Empfehlung'); }
        return '<section class="hd-portal-section hd-mag-affiliate-v150719"><header><span>Empfehlungen</span><h2>Kaufberatung &amp; Affiliate-Artikel</h2></header><div class="hd-mag-post-grid-v150719">'.$cards.'</div></section>';
    }

    private static function render_magazine_grid_banner_v150721() {
        $html = self::affiliate_slot('journal_banner');
        $preview = false;
        if ($html === '') { $html = self::affiliate_preview_placeholder('banner','journal_banner'); $preview = $html !== ''; }
        if ($html === '') { return ''; }
        return '<aside class="hd-mag-grid-ad-v150721'.($preview?' is-preview':'').'" aria-label="Anzeige / Partner"><span>Anzeige / Partner</span><div>'.$html.'</div></aside>';
    }

    private static function render_magazine_grid_rental_v150721() {
        $html = self::rental_slot('journal');
        if ($html === '') { return ''; }
        return '<aside class="hd-mag-grid-rental-v150721" aria-label="Werbefläche"><span>Werbefläche</span><div>'.$html.'</div></aside>';
    }

    private static function render_magazine_portal_tools_v150726() {
        $finder = self::page_link(['magazin/hobbyfinder','hobbyfinder']);
        if ($finder === '') { $finder = home_url('/magazin/hobbyfinder/'); }
        $register = self::page_link(['hobbyregister','hobby-register']);
        if ($register === '') { $register = home_url('/hobbyregister/'); }
        $glossary = self::page_link(['magazin/wissen-glossar','wissen-glossar']);
        if ($glossary === '') { $glossary = home_url('/magazin/wissen-glossar/'); }
        $items = [
            ['title'=>'Hobbyfinder','text'=>'Finde mit wenigen Fragen Hobbys, die zu deinem Alltag passen.','url'=>$finder,'icon'=>'finder','cta'=>'Hobby finden'],
            ['title'=>'Hobbyregister','text'=>'Stöbere durch alle Hobbys und vergleiche Eigenschaften, Aufwand und Anforderungen.','url'=>$register,'icon'=>'register','cta'=>'Register öffnen'],
            ['title'=>'Glossar','text'=>'Schlage Begriffe, Methoden und Fachwörter rund um Hobbys direkt nach.','url'=>$glossary,'icon'=>'knowledge','cta'=>'Begriffe nachschlagen'],
        ];
        $html='<section class="hd-portal-section hd-mag-tools-v150726"><header><span>Orientierung</span><h2>Finden, nachschlagen, vergleichen</h2></header><div class="hd-mag-tools-grid-v150726">';
        foreach($items as $item){
            $html.='<a class="hd-mag-tool-v150726" href="'.esc_url($item['url']).'"><span class="hd-mag-tool-icon-v150726">'.self::editorial_icon_svg($item['icon']).'</span><span class="hd-mag-tool-copy-v150726"><strong>'.esc_html($item['title']).'</strong><small>'.esc_html($item['text']).'</small><b>'.esc_html($item['cta']).' →</b></span></a>';
        }
        return $html.'</div></section>';
    }

    private static function render_magazine_category_tiles_v150719() {
        $items = self::magazine_items();
        if (!$items) { return ''; }
        $parts = [];
        $index = 0;
        foreach ($items as $item) {
            $slug = sanitize_title((string)($item['slug'] ?? ''));
            if ($slug === 'hobbyfinder') { continue; }
            $label = trim((string)($item['label'] ?? ''));
            $url = trim((string)($item['url'] ?? ''));
            $asset = trim((string)($item['asset'] ?? ''));
            if ($label === '' || $url === '' || $asset === '') { continue; }
            $parts[] = '<a class="hd-mag-category-card-v150719" href="'.esc_url($url).'"><span class="hd-mag-category-media-v150719"><img src="'.esc_url(self::asset_url($asset)).'" alt="'.esc_attr($label).'" loading="lazy"></span><span class="hd-mag-category-copy-v150719"><strong>'.esc_html($label).'</strong><b aria-hidden="true">→</b></span></a>';
            $index++;
            if ($index === 6) {
                $ad = self::render_magazine_grid_banner_v150721();
                if ($ad !== '') { $parts[] = $ad; }
            }
            if ($index === 9) {
                $ad = self::render_magazine_grid_rental_v150721();
                if ($ad !== '') { $parts[] = $ad; }
            }
        }
        if (!$parts) { return ''; }
        return '<section class="hd-portal-section hd-mag-categories-v150719"><header><span>Entdecken</span><h2>Themen im Magazin</h2></header><div class="hd-mag-category-grid-v150719">'.implode('', $parts).'</div></section>';
    }

    private static function render_magazine_root_v150719($page) {
        $root_def = [
            'asset'=>'hero-masters-v150684/werbung-design.webp',
            'w'=>1600,
            'h'=>587,
            'claim'=>'Ideen, Wissen, Geschichten.',
            'hero'=>'Inspiration, Hintergründe und Empfehlungen rund um Hobbys und Freizeit.',
        ];
        $html = '<div class="hd-mag-v150719" data-hd-magazine="1.50.720">';
        $html .= self::render_magazine_hero_v150719('Hobbymagazin',$root_def,true);
        $html .= self::render_magazine_portal_tools_v150726();
        $html .= self::render_magazine_category_tiles_v150719();
        $html .= self::render_magazine_feed_v150719(null,'Neu im Magazin',null,false);
        $html .= self::render_magazine_products_v150719();
        $html .= self::render_magazine_affiliate_articles_v150719(null);
        return $html . self::magazine_styles_v150719() . '</div>';
    }

    private static function render_magazine_target_by_slug_v150722($slug, $page = null) {
        $slug = sanitize_title((string)$slug);
        $defs = self::magazine_page_defs_v150719();
        if ($slug === '' || !isset($defs[$slug]) || !is_array($defs[$slug])) { return ''; }
        $def = $defs[$slug];
        $def['slug'] = $slug;
        if (!$page instanceof WP_Post) { $page = self::magazine_page_by_slug_v150722($slug); }
        $title = $page instanceof WP_Post ? trim((string)get_the_title($page)) : '';
        if ($title === '') { $title = (string)($def['label'] ?? 'Magazin'); }
        $html = '<div class="hd-mag-v150719 hd-mag-target-v150719" data-hd-magazine-target="'.esc_attr($slug).'" data-hd-target-route="url-hard-v150722">';
        $html .= self::render_magazine_hero_v150719($title,$def,false);
        $html .= self::render_magazine_intro_v150719($title,$def);
        if ($slug === 'hobbyfinder') {
            $banner = self::render_magazine_grid_banner_v150721();
            if ($banner !== '') { $html .= '<section class="hd-portal-section hd-hf-banner-v150732">'.$banner.'</section>'; }
            $html .= self::render_hobbyfinder_v150705(true);
        } else {
            $html .= self::render_magazine_feed_v150719($def,'Passende Beiträge',$page);
            $html .= self::render_magazine_products_v150719();
            $html .= self::render_magazine_affiliate_articles_v150719($def,$page);
        }
        $html .= self::render_rental_for('journal');
        return $html . self::magazine_styles_v150719() . '</div>';
    }

    private static function render_magazine_target_v150719($page) {
        if (!$page instanceof WP_Post) { return ''; }
        $slug = sanitize_title((string)$page->post_name);
        return self::render_magazine_target_by_slug_v150722($slug, $page);
    }

    private static function magazine_styles_v150719() {
        return '<style id="hd-mag-style-v150722">
        .hd-content-v150616 .hd-mag-hero-v150719{margin-top:14px!important}
        .hd-content-v150616 .hd-mag-hero-v150719 .hd-bp-hero-copy h1{white-space:normal!important;width:auto!important;max-width:560px!important;font-size:clamp(38px,3.6vw,58px)!important}
        .hd-content-v150616 .hd-mag-hero-v150719 .hd-hub2-hero-intro,.hd-content-v150616 .hd-mag-hero-v150719 .hd-hub2-hero-intro p{white-space:normal!important;width:auto!important;max-width:530px!important}
        .hd-content-v150616 .hd-mag-target-v150719 .hd-mag-hero-v150719 .hd-bp-hero-media{display:block!important;visibility:visible!important;opacity:1!important}.hd-content-v150616 .hd-mag-target-v150719 .hd-mag-hero-v150719 .hd-bp-hero-media img{display:block!important;visibility:visible!important;opacity:1!important}
        .hd-content-v150616 .hd-mag-intro-v150719{margin-top:10px!important}
        .hd-mag-tools-grid-v150726{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.hd-mag-tool-v150726{display:grid;min-height:132px;padding:20px 18px;grid-template-columns:54px minmax(0,1fr);gap:15px;align-items:start;border:1px solid var(--hd-line);background:#fff;color:inherit!important;text-decoration:none!important}.hd-mag-tool-v150726:hover{border-color:rgba(15,143,149,.38)}.hd-mag-tool-icon-v150726{display:grid;width:52px;height:52px;border-radius:50%;place-items:center;background:#eaf5f4;color:var(--hd-petrol)}.hd-mag-tool-icon-v150726 svg{width:31px;height:31px;fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}.hd-mag-tool-copy-v150726{display:flex;min-width:0;flex-direction:column}.hd-mag-tool-copy-v150726 strong{color:#263b44;font-size:18px;line-height:1.15}.hd-mag-tool-copy-v150726 small{margin-top:6px;color:#68747a;font-size:12px;line-height:1.45}.hd-mag-tool-copy-v150726 b{margin-top:auto;padding-top:10px;color:var(--hd-petrol);font-size:11px;font-weight:800}
        .hd-mag-category-grid-v150719{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
        .hd-mag-grid-ad-v150721,.hd-mag-grid-rental-v150721{grid-column:1/-1;position:relative;display:block;width:100%;padding-top:15px}.hd-mag-grid-ad-v150721>span,.hd-mag-grid-rental-v150721>span{position:absolute;top:0;left:0;color:#7b8387;font-size:9px;font-weight:650;letter-spacing:.08em;text-transform:uppercase}.hd-mag-grid-ad-v150721>div,.hd-mag-grid-rental-v150721>div{overflow:hidden;border:1px solid var(--hd-line);border-radius:4px;background:#fff}.hd-mag-grid-ad-v150721 img{display:block;max-width:100%;height:auto;margin:auto}.hd-mag-grid-rental-v150721 .hd-rental-link{width:100%;margin:0!important}
        .hd-mag-category-card-v150719{display:block;overflow:hidden;border:1px solid var(--hd-line);border-radius:4px;background:#fff;color:inherit!important;text-decoration:none!important;transition:border-color .15s ease,box-shadow .15s ease,transform .15s ease}
        .hd-mag-category-card-v150719:hover{border-color:rgba(15,143,149,.35);box-shadow:0 8px 22px rgba(42,55,61,.06);transform:translateY(-1px)}
        .hd-mag-category-media-v150719{display:block;aspect-ratio:16/8;overflow:hidden;background:#f5f1e9}
        .hd-mag-category-media-v150719 img{display:block;width:100%;height:100%;object-fit:cover}
        .hd-mag-category-copy-v150719{display:grid;min-height:58px;padding:11px 13px;grid-template-columns:minmax(0,1fr) 18px;gap:8px;align-items:center}
        .hd-mag-category-copy-v150719 strong{color:#263b44;font-size:14px;line-height:1.18}
        .hd-mag-category-copy-v150719 b{color:var(--hd-petrol);font-size:17px;text-align:right}
        .hd-mag-post-grid-v150719{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
        .hd-mag-post-grid-second-v150719{margin-top:12px}
        .hd-mag-post-card-v150719{overflow:hidden;border:1px solid var(--hd-line);border-radius:4px;background:#fff}
        .hd-mag-post-image-v150719{display:block;aspect-ratio:16/9;overflow:hidden;background:#f5f1e9}
        .hd-mag-post-image-v150719 img{display:block;width:100%;height:100%;object-fit:cover}
        .hd-mag-post-copy-v150719{padding:13px 14px 15px}
        .hd-mag-post-badge-v150719{display:inline-block;margin-bottom:6px;color:var(--hd-petrol-deep);font-size:9px;font-weight:850;letter-spacing:.08em;text-transform:uppercase}
        .hd-mag-post-card-v150719 h3{margin:0 0 7px;font-size:16px!important;line-height:1.2!important}
        .hd-mag-post-card-v150719 h3 a{color:#213943!important}
        .hd-mag-post-card-v150719 p{margin:0 0 10px;color:#66747a;font-size:11.5px;line-height:1.45}
        .hd-mag-read-v150719{color:var(--hd-petrol-deep)!important;font-size:11px;font-weight:800}
        .hd-mag-feed-banner-v150719{position:relative;margin:14px 0 0;padding-top:14px}
        .hd-mag-feed-banner-v150719>span{position:absolute;top:0;left:0;color:#7b8387;font-size:9px;letter-spacing:.08em;text-transform:uppercase}
        .hd-mag-feed-banner-v150719>div{overflow:hidden;border:1px solid var(--hd-line);border-radius:4px;background:#fff;min-height:76px}
        .hd-mag-feed-banner-v150719 img{display:block;max-width:100%;height:auto;margin:auto}
        .hd-mag-subviews-v150719{margin-top:24px!important}
        .hd-mag-products-v150719,.hd-mag-affiliate-v150719{margin-top:24px!important}
        .hd-hf.is-magazine-shell-v150719{padding-bottom:34px}
        @media(max-width:980px){
          .hd-mag-category-grid-v150719,.hd-mag-post-grid-v150719{grid-template-columns:repeat(2,minmax(0,1fr))}
        }
        @media(max-width:760px){
          .hd-content-v150616 .hd-mag-hero-v150719{margin-top:10px!important}
          .hd-content-v150616 .hd-mag-hero-v150719 .hd-bp-hero-copy h1{font-size:clamp(34px,9vw,45px)!important}
          .hd-mag-category-grid-v150719{grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}
          .hd-mag-grid-ad-v150721,.hd-mag-grid-rental-v150721{grid-column:1/-1}
          .hd-mag-category-copy-v150719{min-height:54px;padding:9px 10px}
          .hd-mag-category-copy-v150719 strong{font-size:12.5px}
          .hd-mag-post-grid-v150719{grid-template-columns:1fr}
        }
        </style>';
    }


    /**
     * HD Bildzentrale – EIN Entscheidungsweg fuer jede Hobby-Bildquelle.
     * 1.50.769: Eigenes Hobby-Master gewinnt IMMER vor WordPress-Kategoriebildern.
     * Keine Ersatzzuteilung aus Oberkategorie, Weltkarte oder generischen Kacheln.
     * Die gleiche URL wird fuer Finder und Kategorie-Header benutzt.
     * HD007 Master sind die bereits belegten und geprueften Register-Dateien.
     */
    private static function hobby_image_center_v150769($hobby_slug, $page = null) {
        $slug = sanitize_title((string)$hobby_slug);
        if ($slug === '') { return []; }
        // Einzige editierbare Zuordnung: WordPress-Mediathek-ID in der Bildzentrale.
        // Kein Bild anderer Seiten, kein Titelbild, kein Elternkategorie-Fallback.
        $assignments = function_exists('get_option') ? get_option(self::IMAGE_CENTER_OPTION, []) : [];
        if (is_array($assignments) && isset($assignments[$slug])) {
            $attachment = (int)$assignments[$slug];
            if ($attachment > 0 && function_exists('get_attached_file') && function_exists('wp_get_attachment_image_url')
                && function_exists('wp_attachment_is_image') && wp_attachment_is_image($attachment)) {
                $file = (string)get_attached_file($attachment);
                $dim = $file !== '' && is_file($file) ? @getimagesize($file) : false;
                $url = (string)wp_get_attachment_image_url($attachment, 'full');
                if (is_array($dim) && (int)$dim[0] >= 900 && (int)$dim[1] >= 300 && $url !== '') {
                    return ['url'=>$url,'width'=>(int)$dim[0],'height'=>(int)$dim[1],'source'=>'bildzentrale'];
                }
            }
            return []; // explicit assignment invalid: never silently show something else.
        }
        $own = self::bundled_hobby_master_v150759($slug);
        if (!empty($own['url'])) {
            return ['url'=>(string)$own['url'], 'width'=>(int)$own['width'],
                'height'=>(int)$own['height'], 'source'=>'hobby-master'];
        }
        // Images in the HD007 register: one exact slug, no guessed media.
        if (defined('WP_PLUGIN_DIR') && function_exists('plugins_url')) {
            foreach (['/hd-hobbyregister-core*/assets/portraits/final-masters/' . $slug . '.webp',
                      '/hd-hobbyregister-core*/portraits/final-masters/' . $slug . '.webp'] as $pattern) {
                foreach ((array)glob(WP_PLUGIN_DIR . $pattern) as $file) {
                    if (!is_file($file)) { continue; }
                    $dim = @getimagesize($file);
                    if (!is_array($dim) || (int)$dim[0] < 900 || (int)$dim[1] < 300) { continue; }
                    return ['url'=>plugins_url(ltrim(substr($file,strlen(WP_PLUGIN_DIR)),'/')),
                        'width'=>(int)$dim[0], 'height'=>(int)$dim[1], 'source'=>'hd007-master'];
                }
            }
        }
        // Batik: established large master (existing design pilot).
        if ($slug === 'batik') {
            $file=dirname(__DIR__) . '/assets/hobby-depot-v150753/batik-hero.webp';
            $dim=is_file($file) ? @getimagesize($file) : false;
            if (is_array($dim) && (int)$dim[0]>=900 && (int)$dim[1]>=300) {
                return ['url'=>plugin_dir_url(dirname(__FILE__)) . 'assets/hobby-depot-v150753/batik-hero.webp',
                    'width'=>(int)$dim[0], 'height'=>(int)$dim[1], 'source'=>'batik-master'];
            }
        }
        // Keine Freigabe fuer bisherige WordPress-Seitenbilder oder Zweitnutzungen.
        return []; // Not assigned => absolutely NO picture.
    }

    /**
     * 1.50.774: Restore the exact, already approved images on CATEGORY pages/cards.
     * The hobby register still uses hobby_image_center_v150769() exclusively.
     * No parent-world substitutes or blind filename assignments.
     */
    /**
     * 1.50.779: Four Naturbeobachtung leaf cards lacked bundled photos.
     * Only for these exact WordPress child pages may an invalid/stale central
     * mapping fall through to their OWN verified featured image. No guessing
     * from the media library, parent images, or other page attachments.
     */
    private static function naturbeobachtung_leaf_mapping_recovery_v150779($slug, $page) {
        if (!$page instanceof WP_Post || (string)$page->post_type !== 'page') { return false; }
        if (!in_array(sanitize_title((string)$slug), [
            'kaeferbeobachtung',
            'libellenbeobachtung',
            'nachtvogel-beobachtung',
            'tierspuren-dokumentieren',
        ], true)) { return false; }
        if ((string)$page->post_status !== 'publish') { return false; }
        if (!function_exists('get_post') || (int)$page->post_parent <= 0) { return false; }
        $parent = get_post((int)$page->post_parent);
        if (!$parent instanceof WP_Post || sanitize_title((string)$parent->post_name) !== 'naturbeobachtung') { return false; }
        // A matching slug alone is not enough: the page must truly be beneath
        // the existing Forschen / Naturbeobachtung branch.
        $grandparent = (int)$parent->post_parent > 0 ? get_post((int)$parent->post_parent) : null;
        return $grandparent instanceof WP_Post && sanitize_title((string)$grandparent->post_name) === 'forschen';
    }

    private static function category_image_v150774($raw_slug, $page = null, $world_slug = '', $for_card = false) {
        $slug = sanitize_title((string)$raw_slug);
        if ($slug === '') { return []; }
        if ($page instanceof WP_Post && sanitize_title((string)$page->post_name) !== $slug) { return []; }
        // An explicit central assignment has priority even when it is invalid.
        $assigned = function_exists('get_option') ? get_option(self::IMAGE_CENTER_OPTION, []) : [];
        $central = self::hobby_image_center_v150769($slug, $page);
        // Only for the existing 70 first-level CORE category pages (Hub2):
        // an outdated/invalid central attachment must not hide the original category photo.
        // Valid explicit assignments keep their previous priority.
        $hub2_photo_page = $page instanceof WP_Post && self::affiliate_page_type($page->ID) === 'hub2';
        if (is_array($assigned) && array_key_exists($slug, $assigned)) {
            // Valid central assignment always wins. On just the four affected
            // Naturbeobachtung child pages, an invalid central ID must not
            // suppress their own existing WordPress featured image.
            $recover_own_photo = self::naturbeobachtung_leaf_mapping_recovery_v150779($slug, $page);
            if (!empty($central['url']) || (!$hub2_photo_page && !$recover_own_photo)) { return $central; }
        }
        // Prefer the category's own approved photo to a hobby portrait.
        $aliases = [
            'druck-fotografie'=>'druck-foto', 'oberflache-deko'=>'oberflaeche-deko',
            'guss-formen'=>'guss-form', 'hydroponik-indoor'=>'hydro-indoor',
            'moos-miniaturgarten'=>'moos-miniaturgaerten', 'gartnern'=>'gaertnern',
            'imkerei-bestauber'=>'imkerei-bestaeuber', 'munzen-geld'=>'muenzen-geld',
            'werkzeuge-gerate'=>'werkzeuge-geraete',
        ];
        $names = [$slug];
        $title = $page instanceof WP_Post ? sanitize_title((string)get_the_title($page)) : '';
        foreach ([$title, $aliases[$slug] ?? '', $aliases[$title] ?? ''] as $name) {
            if ($name !== '' && !in_array($name, $names, true)) { $names[] = $name; }
        }
        $root = dirname(__DIR__) . '/assets/hobby-depot-v150617/';
        $candidate = static function($rel) use ($root) {
            $file = $root . $rel;
            if (!is_file($file)) { return []; }
            $d = @getimagesize($file);
            if (!is_array($d) || (int)$d[0] < 500 || (int)$d[1] < 200) { return []; }
            return ['url'=>self::asset_url($rel), 'width'=>(int)$d[0],
                'height'=>(int)$d[1], 'source'=>'geprueftes-kategoriebild'];
        };
        // 1.50.778: The whole Hub2 category layer keeps its own approved originals.
        // The v150634 files can be only 200x107; then use the checked 600x320 original.
        // No low-resolution enlargement, parent-photo substitution or new file assignment.
        if ($hub2_photo_page) {
            $real_world = sanitize_key((string)self::current_world_slug($page));
            if (in_array($real_world, self::world_slugs(), true)) {
                $card_versions = ['v150634','v150629','v150627','v150623','v150616','v150624','v150631','v150670','v150671'];
                if ($for_card) {
                    foreach ($names as $name) {
                        foreach ($card_versions as $v) {
                            $hit = $candidate('subcategories/' . $real_world . '/' . $name . '-' . $v . '.webp');
                            if ($hit) { return $hit; }
                        }
                    }
                }
                foreach ($names as $name) {
                    $hit = $candidate('hero-masters-v150684/' . $name . '.webp');
                    if ($hit) { return $hit; }
                }
                foreach ($names as $name) {
                    foreach ($card_versions as $v) {
                        $hit = $candidate('subcategories/' . $real_world . '/' . $name . '-' . $v . '.webp');
                        if ($hit) { return $hit; }
                    }
                }
            }
        }
        // All non-Hub2 pages keep the existing image resolution code unmodified.
        // Restore the original dedicated card photograph before looking at hero imagery.
        $world = sanitize_key((string)$world_slug);
        if ($for_card && in_array($world, self::world_slugs(), true)) {
            foreach ($names as $name) {
                $hit = $candidate('subcategories/' . $world . '/' . $name . '-v150634.webp');
                if ($hit) { return $hit; }
            }
        }
        // Exact curated category hero, retaining the formerly displayed original.
        foreach ($names as $name) {
            $hit = $candidate('hero-masters-v150684/' . $name . '.webp');
            if ($hit) { return $hit; }
        }
        // Category cards had a separate unique image assigned for their own world.
        $world = sanitize_key((string)$world_slug);
        $worlds = in_array($world, self::world_slugs(), true) ? [$world] : self::world_slugs();
        foreach (['v150634','v150631','v150629','v150627','v150623','v150616'] as $suffix) {
            foreach ($names as $name) {
                $hits = [];
                foreach ($worlds as $w) {
                    $hit = $candidate('subcategories/' . $w . '/' . $name . '-' . $suffix . '.webp');
                    if ($hit) { $hits[] = $hit; }
                }
                // Unknown world: no photo if the slug matches multiple distinct collections.
                if (count($hits) === 1) { return $hits[0]; }
            }
        }
        // Only the real featured image of THIS exact WordPress page is eligible.
        if ($page instanceof WP_Post && function_exists('get_post_thumbnail_id')
            && function_exists('wp_attachment_is_image') && function_exists('wp_get_attachment_image_url')) {
            $attachment = (int)get_post_thumbnail_id($page->ID);
            if ($attachment > 0 && wp_attachment_is_image($attachment)) {
                $file = function_exists('get_attached_file') ? (string)get_attached_file($attachment) : '';
                $d = $file !== '' && is_file($file) ? @getimagesize($file) : false;
                $url = (string)wp_get_attachment_image_url($attachment, 'full');
                if (is_array($d) && (int)$d[0] >= 500 && (int)$d[1] >= 200 && $url !== '') {
                    return ['url'=>$url,'width'=>(int)$d[0],'height'=>(int)$d[1],
                        'source'=>'eigenes-wordpress-titelbild'];
                }
            }
        }
        if (!empty($central['url'])) { return $central; }
        return [];
    }

    /** Category header uses the single resolved category-specific image. */
    private static function category_hero_image_v150757($page) {
        if (!$page instanceof WP_Post || (string)$page->post_type !== 'page') { return []; }
        $img=self::category_image_v150774((string)$page->post_name,$page,self::current_world_slug($page));
        if (empty($img['url'])) { return []; }
        return ['html'=>'<img src="' . esc_url((string)$img['url']) . '" width="' . intval($img['width'])
                . '" height="' . intval($img['height']) . '" alt="' . esc_attr(trim((string)get_the_title($page)))
                . ' – Hobbybild" decoding="async" fetchpriority="high">',
            'source'=>(string)$img['source']];
    }

    /** One controlled hero; page intro below keeps its complete text and layout. */
    private static function render_category_hero_v150757($page, $image) {
        if (!$page instanceof WP_Post || empty($image['html'])) { return ''; }
        $slug = sanitize_title((string)$page->post_name);
        $title_data = self::category_level_display_title_v150688($page);
        $title = trim((string)($title_data['plain'] ?? get_the_title($page)));
        $titles = self::hub2_card_subtitles_v150684();
        $claim = trim((string)($titles[$slug] ?? ''));
        if ($slug === 'batik') { $claim = 'Stoffe färben. Muster entdecken.'; }
        if ($claim === '') { $claim = 'Ideen entdecken. Selbst ausprobieren.'; }
        $script = $slug === 'batik' ? 'Färben. Binden. Gestalten.' : 'Entdecken. Ausprobieren. Gestalten.';
        $brush = plugin_dir_url(dirname(__FILE__)) . 'assets/hobby-depot-v150641/brush-underline-v150641.webp';
        $html = '<section class="hd-category-hero-v150757" data-hd-category-hero="' . esc_attr($image['source']) . '" aria-label="' . esc_attr($title . ' – Titelbild') . '">'
            . '<div class="hd-category-hero-copy-v150757">'
            . '<span class="hd-category-hero-script-v150757" style="--hd-category-brush:url(&quot;' . esc_url($brush) . '&quot;)">' . esc_html($script) . '</span>'
            . '<h1>' . esc_html($title) . '</h1><p class="hd-category-hero-claim-v150757">' . esc_html($claim) . '</p>'
            . '</div><div class="hd-category-hero-media-v150757">' . $image['html'] . '</div></section>';
        $css = <<<'HD757CSS'
/* The same body width/margins used by .hd-catlevel-intro (1200px desktop, 24px mobile). */
.hd-content-v150616 > .hd-category-hero-v150757{box-sizing:border-box!important;position:relative!important;isolation:isolate!important;display:grid!important;grid-template-columns:minmax(0,1fr) minmax(0,52%)!important;width:min(calc(100% - 72px),var(--hd-content,1200px))!important;max-width:1200px!important;height:320px!important;min-height:320px!important;margin:5px auto 0!important;padding:0!important;overflow:hidden!important;background:#f5f1e9!important;border:0!important}
.hd-category-hero-v150757 .hd-category-hero-copy-v150757{position:relative!important;z-index:3!important;min-width:0!important;display:flex!important;flex-direction:column!important;align-items:flex-start!important;justify-content:center!important;padding:28px clamp(26px,4vw,64px)!important;box-sizing:border-box!important;text-align:left!important}
.hd-category-hero-v150757 .hd-category-hero-script-v150757{position:relative!important;display:inline-block!important;max-width:100%!important;margin:0 0 34px!important;padding:0 5px 0 2px!important;color:#0f858a!important;font-family:"Brush Script MT","Segoe Script","Bradley Hand",cursive!important;font-size:clamp(22px,2vw,28px)!important;font-weight:400!important;line-height:1!important;white-space:normal!important;transform:translateY(-8px) rotate(-1.2deg)!important}
.hd-category-hero-v150757 .hd-category-hero-script-v150757:after{content:""!important;position:absolute!important;left:1%!important;bottom:-10px!important;width:98%!important;height:10px!important;background-image:var(--hd-category-brush)!important;background-repeat:no-repeat!important;background-size:100% 100%!important;pointer-events:none!important}
.hd-category-hero-v150757 .hd-category-hero-copy-v150757 h1{display:block!important;margin:0 0 8px!important;padding:0!important;color:#17313c!important;font-family:Arial,Helvetica,sans-serif!important;font-size:clamp(38px,4vw,60px)!important;line-height:1.02!important;font-weight:800!important;letter-spacing:-.035em!important;text-align:left!important}
.hd-category-hero-v150757 .hd-category-hero-claim-v150757{margin:0!important;padding:0!important;color:#31444c!important;font-size:clamp(13px,1.05vw,16px)!important;line-height:1.48!important;font-weight:500!important;white-space:normal!important}
.hd-category-hero-v150757 .hd-category-hero-media-v150757{position:relative!important;grid-column:2!important;grid-row:1!important;min-width:0!important;height:320px!important;margin:0!important;overflow:hidden!important;background:#f5f1e9!important}
.hd-category-hero-v150757 .hd-category-hero-media-v150757 img{display:block!important;width:100%!important;height:100%!important;object-fit:cover!important;object-position:center 49%!important;border:0!important;box-shadow:none!important}
.hd-category-hero-v150757 .hd-category-hero-media-v150757:before{content:""!important;position:absolute!important;inset:0 auto 0 0!important;z-index:2!important;width:120px!important;pointer-events:none!important;background:linear-gradient(90deg,#f5f1e9 0%,rgba(245,241,233,.96) 18%,rgba(245,241,233,.71) 42%,rgba(245,241,233,0) 100%)!important}
@media(max-width:900px){.hd-content-v150616 > .hd-category-hero-v150757{grid-template-columns:1fr!important;grid-template-rows:auto auto!important;height:auto!important;min-height:0!important}.hd-category-hero-v150757 .hd-category-hero-copy-v150757{grid-column:1!important;grid-row:1!important;padding:26px 20px 22px!important}.hd-category-hero-v150757 .hd-category-hero-script-v150757{margin-bottom:30px!important;font-size:23px!important;transform:translateY(-5px) rotate(-1.2deg)!important}.hd-category-hero-v150757 .hd-category-hero-copy-v150757 h1{font-size:clamp(34px,9vw,48px)!important}.hd-category-hero-v150757 .hd-category-hero-claim-v150757{font-size:clamp(11px,2.65vw,14px)!important}.hd-category-hero-v150757 .hd-category-hero-media-v150757{grid-column:1!important;grid-row:2!important;width:100%!important;height:auto!important;aspect-ratio:600/320!important}.hd-category-hero-v150757 .hd-category-hero-media-v150757 img{height:100%!important;aspect-ratio:600/320!important}.hd-category-hero-v150757 .hd-category-hero-media-v150757:before{display:none!important}}
@media(max-width:760px){.hd-content-v150616 > .hd-category-hero-v150757{width:calc(100% - 24px)!important}}
@media(max-width:400px){.hd-category-hero-v150757 .hd-category-hero-copy-v150757{padding:22px 16px 20px!important}.hd-category-hero-v150757 .hd-category-hero-script-v150757{font-size:20px!important}.hd-category-hero-v150757 .hd-category-hero-claim-v150757{font-size:12px!important}}
HD757CSS;
        return $html . '<style id="hd-category-hero-css-v150757">' . $css . '</style>';
    }

    public static function render_owned_content() {
        self::$rental_rendered=false;
        $out='<main class="hd-content-v150616" data-hd-release="'.esc_attr(self::RELEASE).'">'.self::render_breadcrumb();
        // 1.50.722: render the target directly from its real /magazin/<slug>/ URL.
        $request_slug = self::magazine_request_slug_v150722();
        if ($request_slug !== '') {
            $request_page = self::magazine_page_by_slug_v150722($request_slug);
            return $out . self::render_magazine_target_by_slug_v150722($request_slug, $request_page) . '</main>';
        }
        if (function_exists('is_singular') && is_singular('page')) {
            $page=get_queried_object(); if(!$page instanceof WP_Post){return $out.'</main>';}
            if (self::is_magazine_root_page_v150717($page)) { return $out . self::render_magazine_root_v150719($page) . '</main>'; }
            if (self::is_magazine_target_page_v150719($page)) { return $out . self::render_magazine_target_v150719($page) . '</main>'; }
            if (self::is_hobbyfinder_page($page)) { return $out . self::render_hobbyfinder_v150705() . '</main>'; }
            $type=self::affiliate_page_type($page->ID); $world=self::current_world_slug($page);
            if (self::is_category_level_page($page,$type)) {
                // Important: decide the entire header from one verified image source.
                $category_hero_image = self::category_hero_image_v150757($page);
                $has_category_hero = !empty($category_hero_image['html']);
                if ($has_category_hero) { $out .= self::render_category_hero_v150757($page, $category_hero_image); }
                $out .= self::render_category_level_intro_v150687($page,$world,$has_category_hero);
                $out .= self::render_category_level_body_v150687($page,$world);
                return $out.'</main>';
            }
            $full=self::category_intro_for_page($page,$type,$world);
            if($type==='hub1') {
                $out.=self::render_world_hub_hero($page,$world);
            } elseif($type==='hub2') {
                // Portalweiter Rollout: exakt das akzeptierte Buch-&-Papier-Hero-/Fold-Layout.
                $out.=self::buch_papier_pilot_intro($page,$world);
            } else {
                $out.=self::render_page_intro_block(get_the_title($page),self::intro_lead($full,36),$type,$world);
                $out.=self::render_category_intro_editorial($full);
            }
            $next=self::render_next_level($page,$type,$world);
            $out.=$next;
            if($type==='hub2') {
                // Wie akzeptiert bei Buch & Papier: Kategorien/Banner im Raster → Produkte → 3 Beiträge → Werbeplatz → Ende.
                $out.=self::products_for_type('hub2',get_the_title($page));
                $out.=self::render_post_previews($page,null,3,'hd-post-previews-hub2 hd-bp-posts');
                $out.=self::render_rental_for('hub2');
            } else {
                if($next===''){$out.='<section class="hd-portal-section hd-next-level hd-next-level-empty">'.self::integrated_affiliate_modules($type,get_the_title($page)).'</section>';}
                $out.=self::render_rental_for(in_array($type,['hub1','category'],true)?$type:'category');
                $out.=self::render_post_previews($page,null);
                $out.=self::products_for_type($type,get_the_title($page));
                if($type==='hub1') { $out.=self::render_hub1_bottom_editorial($page,$world); }
            }
        } elseif ((function_exists('is_category') && is_category()) || (function_exists('is_tax') && is_tax('journal_cat'))) {
            $term=get_queried_object();
            if($term instanceof WP_Term){
                // 1.50.750: ausschliesslich die 3.376 exakten HD-001-Core-Leaf-Kategorien.
                // Alle hoeheren Ebenen und journal_cat bleiben im bisherigen Renderer.
                if(function_exists('is_category') && is_category() && is_array(self::leaf_category_meta_v150750($term))){
                    $out.=self::render_leaf_category_intro_v150750($term);
                    $out.=self::render_leaf_category_body_v150750($term);
                    return $out.'</main>';
                }
                if(function_exists('is_category') && is_category() && self::direct_category_level_term_entry_v150687($term)){
                    $out.=self::render_direct_category_level_term_intro_v150687($term);
                    $out.=self::render_direct_category_level_term_body_v150687($term);
                    return $out.'</main>';
                }
                $full=self::category_intro_for_term($term); $out.=self::render_page_intro_block($term->name,self::intro_lead($full,36),'term',''); $out.=self::render_category_intro_editorial($full); $next=self::render_term_next_level($term); $out.=$next; if($next===''){$out.='<section class="hd-portal-section hd-next-level hd-next-level-empty">'.self::integrated_affiliate_modules('category',$term->name).'</section>';} $out.=self::render_rental_for('category'); $out.=self::render_post_previews(null,$term); $out.=self::products_for_type('category',$term->name);
            }
        }
        return $out.'</main>';
    }

    /**
     * 1.50.741: Die Service-Seiten wurden aus einer frueheren Kubio-Installation
     * importiert, Kubio selbst ist im Hobby Depot aber nicht installiert.
     * Deshalb wird der importierte Alt-HTML-Inhalt hier einmal serverseitig
     * normalisiert. Kein Runtime-JS, kein MutationObserver, kein Klassenraten.
     */
    public static function normalize_service_content_v150741($content) {
        if (is_admin() || !is_string($content) || trim($content) === '') { return $content; }
        if (!function_exists('is_singular') || !is_singular('page')) { return $content; }
        $page = function_exists('get_queried_object') ? get_queried_object() : null;
        if (!$page instanceof WP_Post || !self::is_plain_service_page($page)) { return $content; }
        $slug = sanitize_title((string)$page->post_name);

        // Importierte Block-Kommentare haben im Zielportal keine Funktion mehr.
        $content = preg_replace('~<!--\\s*/?wp:kubio/.*?-->~is', '', $content);
        $content = preg_replace('~<!--\\s*wp:kubio/.*?/-->~is', '', $content);

        $heading_map = [];
        if ($slug === 'disclaimer') {
            $heading_map = [
                'rechtlicher hinweis und haftungsausschluss',
                'allgemeine informationen',
                'fachinformationen und sicherheit',
                'nutzung auf eigene verantwortung',
                'werbung, anzeigen und affiliate-links',
                'inhalte von dritten',
                'externe links',
                'urheberrecht',
                'hinweis auf fehlerhafte inhalte',
            ];
        } elseif ($slug === 'preise') {
            $heading_map = [
                'anzeigen in unserem anzeigenmarkt',
                'redaktionelle artikel & advertorials',
                'exklusive banner',
                'kurzbedingungen',
            ];
        }

        if ($heading_map) {
            $content = preg_replace_callback(
                '~<strong(?P<attrs>[^>]*)>(?P<html>.*?)</strong>(?P<brs>(?:\\s*<br\\s*/?>){0,2})~is',
                static function($m) use ($heading_map) {
                    $text = html_entity_decode(wp_strip_all_tags((string)$m['html']), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    $text = preg_replace('/\s+/u', ' ', trim((string)$text));
                    $key = function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
                    if (!in_array($key, $heading_map, true)) { return $m[0]; }
                    return '<p class="hd-service-subheading-v150741"><strong>' . $m['html'] . '</strong></p>';
                },
                $content
            );
        }

        // Preise: Tabellen bleiben inhaltlich unveraendert, bekommen aber eine
        // eindeutige Klasse. Die Breite wird ausschliesslich per zentralem CSS gesetzt.
        if ($slug === 'preise') {
            $content = preg_replace_callback('~<figure(?P<attrs>[^>]*)class="(?P<class>[^"]*\\bwp-block-table\\b[^"]*)"(?P<tail>[^>]*)>~is', static function($m) {
                $classes = trim((string)$m['class'] . ' hd-service-price-figure-v150741');
                return '<figure' . $m['attrs'] . 'class="' . esc_attr($classes) . '"' . $m['tail'] . '>';
            }, $content);
            $content = preg_replace_callback('~<table(?P<attrs>[^>]*)>~is', static function($m) {
                $attrs = (string)$m['attrs'];
                if (preg_match('~\\bclass="([^"]*)"~i', $attrs, $cm)) {
                    $classes = trim((string)$cm[1] . ' hd-service-price-table-v150741');
                    $attrs = preg_replace('~\\bclass="[^"]*"~i', 'class="' . esc_attr($classes) . '"', $attrs, 1);
                } else {
                    $attrs .= ' class="hd-service-price-table-v150741"';
                }
                return '<table' . $attrs . '>';
            }, $content);
        }

        // Exclusively AGB-2: remove the outdated last line, not any legal clauses.
        if ($slug === 'agb-2') {
            $content = preg_replace(
                '~(?:\s*<br\s*/?>){0,2}\s*(?:<p\b[^>]*>\s*)?<strong\b[^>]*>\s*Stand\s*:\s*</strong>\s*Juli\s+2016\s*(?:</p>\s*)?$~iu',
                '',
                $content,
                1
            );
        }

        // Doppelte Leerzeilen des Imports begrenzen, ohne Inhalte umzuschreiben.
        $content = preg_replace('~(?:\\s*<br\\s*/?>){3,}~i', '<br><br>', $content);
        return '<div class="hd-service-body-v150741">' . trim($content) . '</div>';
    }

    public static function render_universal_top() {
        if (is_admin() || (function_exists('is_front_page') && is_front_page())) {return;}
        // 1.50.703: Service-/Footer-Seiten behalten ihren importierten Inhalt 1:1,
        // brauchen aber genau EINEN sichtbaren Seitentitel. Deshalb nur Breadcrumb
        // + Titel ausgeben; kein generischer Introtext und kein "Mehr erfahren".
        if (function_exists('is_singular') && is_singular('page')) {
            $service_obj = get_queried_object();
            if ($service_obj instanceof WP_Post && self::is_plain_service_page($service_obj)) {
                $service_title = trim((string)get_the_title($service_obj));
                $service_image = self::asset_url('hero-masters-v150684/alltagsobjekte.webp');
                echo '<div class="hd-universal-top-v150616 hd-service-top-v150703 hd-service-top-v150735">'
                    . self::render_breadcrumb()
                    . '<section class="hd-service-hero-v150735"><div class="hd-service-hero-copy-v150735">'
                    . '<h1>' . esc_html($service_title) . '</h1>'
                    . '</div><figure class="hd-service-hero-media-v150735"><img src="' . esc_url($service_image) . '" alt="" width="1600" height="587" loading="eager" decoding="async"></figure></section></div>';
                return;
            }
        }
        if (self::is_owned_content_route()) {return;}
        if (function_exists('is_404') && is_404()) {return;}
        if (function_exists('is_singular') && is_singular(['page','post'])) {
            $obj=get_queried_object(); if(!$obj instanceof WP_Post){return;}
            $type=$obj->post_type==='post'?'post':'page';
            if($obj->post_type==='page'){
                $full=self::category_intro_for_page($obj,'page',''); if($full===''){$full=self::fallback_intro(get_the_title($obj),'page');}
                echo '<div class="hd-universal-top-v150616">'.self::render_breadcrumb().self::render_page_intro_block(get_the_title($obj),self::intro_lead($full,36),$type,'').self::render_category_intro_editorial($full).'</div>';
            } else {
                // 1.50.789: one editorial title above a true image hero.
                // Claim and photo are independently provided; no fixed text baked into images.
                echo '<div class="hd-universal-top-v150616">'.self::render_breadcrumb()
                    . (function_exists('hd003_article_hero_markup_v150789') ? hd003_article_hero_markup_v150789($obj) : '')
                    . '</div>';
            }
        }
    }

    private static function market_top_categories_v150743() {
        if (!function_exists('taxonomy_exists') || !taxonomy_exists('hp_listing_category')) { return []; }
        $defs = [
            'Kurse & Workshops' => 'hero-masters-v150684/heimwerken.webp',
            'Trainer & Coaches' => 'hero-masters-v150684/klettern-seil.webp',
            'Vereine & Gruppen' => 'hero-masters-v150684/team-wettkampf.webp',
            'Werkstätten & Studios' => 'hero-masters-v150684/werkzeuge-geraete.webp',
            'Fachgeschäfte' => 'hero-masters-v150684/alltagsobjekte.webp',
            'Verleih' => 'hero-masters-v150684/outdoor.webp',
            'Reparatur & Service' => 'hero-masters-v150684/mechanik-uhren.webp',
            'Events & Reisen' => 'hero-masters-v150684/spotting-verkehr.webp',
        ];
        $items = [];
        foreach ($defs as $name => $asset) {
            $term = get_term_by('name', $name, 'hp_listing_category');
            if (!$term instanceof WP_Term) { continue; }
            $url = get_term_link($term, 'hp_listing_category');
            if (is_wp_error($url)) { continue; }
            $items[] = [
                'term' => $term,
                'name' => (string)$term->name,
                'url' => (string)$url,
                'image' => self::asset_url($asset),
            ];
        }
        return $items;
    }

    private static function market_child_categories_v150743($parent_id) {
        $parent_id = absint($parent_id);
        if ($parent_id <= 0 || !function_exists('get_terms')) { return []; }
        $terms = get_terms([
            'taxonomy' => 'hp_listing_category',
            'hide_empty' => false,
            'parent' => $parent_id,
            'orderby' => 'name',
            'order' => 'ASC',
        ]);
        return is_array($terms) && !is_wp_error($terms) ? array_values(array_filter($terms, static function($term){ return $term instanceof WP_Term; })) : [];
    }

    private static function market_icon_svg_v150743($name) {
        $key = sanitize_title((string)$name);
        if (preg_match('~kurs|workshop|schule|lernen~', $key)) {
            return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h7a3 3 0 0 1 3 3v11a3 3 0 0 0-3-3H4Z"/><path d="M20 5h-4a3 3 0 0 0-3 3v11a3 3 0 0 1 3-3h4Z"/></svg>';
        }
        if (preg_match('~trainer|coach|beratung~', $key)) {
            return '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="7" r="3"/><path d="M6 21v-2a6 6 0 0 1 12 0v2"/><path d="M17 8h4M19 6v4"/></svg>';
        }
        if (preg_match('~verein|gruppe|club|gemeinschaft~', $key)) {
            return '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="8" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 21v-2a5 5 0 0 1 10 0v2M14 20v-1a4 4 0 0 1 7-2.5"/></svg>';
        }
        if (preg_match('~werkstatt|studio|atelier~', $key)) {
            return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m14 6 4-4 4 4-4 4"/><path d="M13 7 4 16a3 3 0 0 0 4 4l9-9"/></svg>';
        }
        if (preg_match('~fachgeschaeft|shop|handel|laden~', $key)) {
            return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h16l-1-5H5Z"/><path d="M5 9v11h14V9M9 20v-6h6v6"/></svg>';
        }
        if (preg_match('~verleih|miete|vermiet~', $key)) {
            return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h16v11H4Z"/><path d="M8 8V5h8v3M8 13h8M12 10v6"/></svg>';
        }
        if (preg_match('~reparatur|service|wartung~', $key)) {
            return '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 6a4 4 0 0 0-5 5L3 17l4 4 6-6a4 4 0 0 0 5-5l-3 3-4-4Z"/></svg>';
        }
        if (preg_match('~event|reise|treffen|messe~', $key)) {
            return '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/><path d="m9 15 2 2 4-4"/></svg>';
        }
        return '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/></svg>';
    }

    private static function render_market_search_v150743($category_id = 0) {
        $q = isset($_GET['s']) ? trim(sanitize_text_field(wp_unslash((string)$_GET['s']))) : '';
        $html = '<form class="hd-market-search-v150743" method="get" action="' . esc_url(self::hivepress_listings_url_v150742()) . '">';
        $html .= '<label class="screen-reader-text" for="hd-market-search-field-v150743">Anzeigen durchsuchen</label>';
        $html .= '<div class="hd-market-search-field-v150743"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4 4"/></svg><input id="hd-market-search-field-v150743" type="search" name="s" value="' . esc_attr($q) . '" placeholder="Anzeigen durchsuchen …" autocomplete="off"></div>';
        if (absint($category_id) > 0) { $html .= '<input type="hidden" name="_category" value="' . absint($category_id) . '">'; }
        $html .= '<input type="hidden" name="post_type" value="hp_listing"><input type="hidden" name="hd_market_search" value="1"><button type="submit">Suchen</button></form>';
        return $html;
    }

    public static function scope_market_search_v150744($query) {
        if (is_admin() || !is_object($query) || !method_exists($query, 'is_main_query') || !$query->is_main_query()) { return; }
        $marker = isset($_GET['hd_market_search']) ? sanitize_key(wp_unslash((string)$_GET['hd_market_search'])) : '';
        if ($marker !== '1') { return; }
        $query->set('post_type', 'hp_listing');
        $query->set('post_status', 'publish');
    }

    private static function render_market_banner_v150743() {
        $html = self::affiliate_slot('anzeigenmarkt_top_banner');
        $preview = false;
        if ($html === '') { $html = self::affiliate_preview_placeholder('banner', 'anzeigenmarkt_top_banner'); $preview = $html !== ''; }
        if ($html === '') { return ''; }
        return '<aside class="hd-market-banner-v150743' . ($preview ? ' is-preview' : '') . '" aria-label="Anzeige / Partner"><span>Anzeige / Partner</span><div>' . $html . '</div></aside>';
    }


    /**
     * All genuine HivePress listing-category archives, independent of root/parent/child.
     * No slug lists, no hard-coded term IDs, no new plugin, and no DB writes.
     */
    private static function is_hivepress_market_category_v150798() {
        if (is_admin() || !function_exists('is_tax') || !is_tax('hp_listing_category')) { return false; }
        $term = get_queried_object();
        return $term instanceof WP_Term && (string)$term->taxonomy === 'hp_listing_category';
    }

    public static function render_market_category_top_v150798() {
        if (!self::is_hivepress_market_category_v150798()) { return; }
        $term = get_queried_object();
        $title = trim((string)$term->name);
        if ($title === '') { return; }

        $submit = self::hivepress_submit_url_v150742();
        $hero = self::asset_url('anzeigenmarkt-hero-v150744.webp');
        $description = trim(wp_strip_all_tags((string)($term->description ?? '')));
        if ($description === '') { $description = 'Angebote und Anzeigen rund um dieses Hobby entdecken.'; }

        echo '<div class="hd-market-shell-v150743 hd-market-category-shell-v150798">';
        echo '<nav class="hd-market-breadcrumb-v150743" aria-label="Breadcrumb">';
        echo '<a href="' . esc_url(home_url('/')) . '">Startseite</a><span>›</span>';
        echo '<a href="' . esc_url(self::hivepress_listings_url_v150742()) . '">Anzeigenmarkt</a>';
        $ancestors = function_exists('get_ancestors') ? (array)get_ancestors((int)$term->term_id, 'hp_listing_category', 'taxonomy') : [];
        foreach (array_reverse($ancestors) as $ancestor_id) {
            $ancestor = get_term((int)$ancestor_id, 'hp_listing_category');
            if (!$ancestor instanceof WP_Term || is_wp_error($ancestor)) { continue; }
            $url = get_term_link($ancestor);
            if (is_wp_error($url) || !is_string($url) || $url === '') { continue; }
            echo '<span>›</span><a href="' . esc_url($url) . '">' . esc_html($ancestor->name) . '</a>';
        }
        echo '<span>›</span><strong>' . esc_html($title) . '</strong></nav>';
        echo '<section class="hd-market-hero-v150744"><div class="hd-market-hero-copy-v150744"><span>Anzeigenmarkt</span>';
        echo '<h1>' . esc_html($title) . '</h1><p>' . esc_html($description) . '</p>';
        if ($submit !== '') { echo '<a class="hd-market-submit-v150743" href="' . esc_url($submit) . '">Anzeige aufgeben</a>'; }
        echo '</div><div class="hd-market-hero-image-v150744"><img src="' . esc_url($hero) . '" alt="Historisches Anzeigenblatt auf einem Tisch" width="1030" height="210" decoding="async" fetchpriority="high"></div></section>';
        echo self::render_market_search_v150743((int)$term->term_id);
        echo '<section class="hd-market-native-head-v150744"><h2>Anzeigen in ' . esc_html($title) . '</h2><a href="' . esc_url(self::hivepress_listings_url_v150742()) . '">Alle Anzeigen ansehen →</a></section>';
        echo '</div>';
    }

    public static function render_market_top_v150743() {
        if (is_admin() || !self::is_hivepress_market_root_v150742()) { return; }

        $market_url = self::hivepress_listings_url_v150742();
        $submit = self::hivepress_submit_url_v150742();
        $hero = self::asset_url('anzeigenmarkt-hero-v150744.webp');

        echo '<div class="hd-market-shell-v150743 hd-market-shell-root-v150744">';
        echo '<nav class="hd-market-breadcrumb-v150743" aria-label="Breadcrumb"><a href="' . esc_url(home_url('/')) . '">Startseite</a><span>›</span><strong>Anzeigenmarkt</strong></nav>';
        echo '<section class="hd-market-hero-v150744"><div class="hd-market-hero-copy-v150744"><span>Anzeigenmarkt</span><h1>Anzeigenmarkt für Hobbys</h1><p>Kaufen, verkaufen, suchen oder anbieten – rund um dein Hobby.</p>';
        if ($submit !== '') { echo '<a class="hd-market-submit-v150743" href="' . esc_url($submit) . '">Anzeige aufgeben</a>'; }
        echo '</div><div class="hd-market-hero-image-v150744"><img src="' . esc_url($hero) . '" alt="Historisches Anzeigenblatt auf einem Tisch" width="1030" height="210" decoding="async" fetchpriority="high"></div></section>';
        echo self::render_market_search_v150743(0);
        // 1.50.786: market banner between search and category cards, never at top.
        echo self::render_market_banner_v150743();

        $items = self::market_top_categories_v150743();
        if ($items) {
            echo '<section class="hd-market-entry-v150743"><header><h2>Was suchst du?</h2><p>Wähle einen Bereich und entdecke passende Angebote.</p></header><div class="hd-market-photo-grid-v150743">';
            foreach ($items as $item) {
                echo '<a class="hd-market-photo-card-v150743" href="' . esc_url($item['url']) . '"><img src="' . esc_url($item['image']) . '" alt="" loading="lazy" decoding="async"><span><strong>' . esc_html($item['name']) . '</strong><b>Entdecken →</b></span></a>';
            }
            echo '</div></section>';
        }
        echo '<section class="hd-market-native-head-v150744"><h2>Aktuelle Anzeigen</h2><a href="' . esc_url($market_url) . '">Alle Anzeigen ansehen →</a></section>';
        echo '</div>';
    }

    /**
     * 1.50.742 – HivePress-Routen niemals aus importierten Footer-URLs erraten.
     * Der installierte HivePress-Router bleibt die einzige Autoritaet fuer
     * Anzeigenuebersicht, Konto und eigene Anzeigen. Fallbacks greifen nur,
     * wenn HivePress selbst nicht geladen ist.
     */
    private static function hivepress_route_url_v150742($route, $fallback = '') {
        $route = sanitize_key((string)$route);
        $fallback = trim((string)$fallback);
        if ($route !== '' && function_exists('hivepress')) {
            try {
                $core = hivepress();
                $router = is_object($core) ? $core->router : null;
                if (is_object($router) && method_exists($router, 'get_url')) {
                    $url = trim((string)$router->get_url($route));
                    if ($url !== '') { return $url; }
                }
            } catch (Throwable $e) {
                // Fallback below. Route lookup must never break page rendering.
            }
        }
        return $fallback;
    }

    private static function hivepress_listings_url_v150742() {
        $fallback = '';
        $page_id = absint(get_option('hp_page_listings'));
        if ($page_id > 0) {
            $url = trim((string)get_permalink($page_id));
            if ($url !== '') { $fallback = $url; }
        }
        if ($fallback === '' && function_exists('get_post_type_archive_link')) {
            $url = get_post_type_archive_link('hp_listing');
            if (is_string($url) && trim($url) !== '') { $fallback = trim($url); }
        }
        if ($fallback === '') { $fallback = home_url('/anzeigenmarkt/'); }
        return self::hivepress_route_url_v150742('listings_view_page', $fallback);
    }

    private static function hivepress_account_url_v150742() {
        return self::hivepress_route_url_v150742('user_account_page', home_url('/account/'));
    }

    private static function hivepress_user_listings_url_v150742() {
        return self::hivepress_route_url_v150742('listings_edit_page', home_url('/account/listings/'));
    }

    private static function hivepress_submit_url_v150742() {
        return self::hivepress_route_url_v150742('listing_submit_page', home_url('/submit-listing/'));
    }

    private static function hivepress_current_route_v150742() {
        if (!function_exists('hivepress')) { return ''; }
        try {
            $core = hivepress();
            $router = is_object($core) ? $core->router : null;
            if (is_object($router) && method_exists($router, 'get_current_route_name')) {
                return sanitize_key((string)$router->get_current_route_name());
            }
        } catch (Throwable $e) {
            return '';
        }
        return '';
    }

    private static function is_hivepress_market_root_v150742() {
        $route = self::hivepress_current_route_v150742();
        if ($route !== 'listings_view_page') { return false; }
        if (function_exists('is_tax') && is_tax()) { return false; }
        return true;
    }

    // 1.50.745: SEO-Metadaten werden ausschließlich von HD-002 / Hobby Depot SEO Themenengine erzeugt.

    private static function footer_market_links_v150742() {
        $items = [
            ['label'=>'Alle Anzeigen', 'url'=>self::hivepress_listings_url_v150742()],
        ];
        if (function_exists('is_user_logged_in') && is_user_logged_in()) {
            $items[] = ['label'=>'Meine Anzeigen', 'url'=>self::hivepress_user_listings_url_v150742()];
            $items[] = ['label'=>'Mein Konto', 'url'=>self::hivepress_account_url_v150742()];
            $items[] = ['label'=>'Konto abmelden', 'url'=>wp_logout_url(home_url('/'))];
        } else {
            $items[] = ['label'=>'Mein Konto', 'url'=>self::hivepress_account_url_v150742()];
        }
        return $items;
    }

    public static function render_footer() {
        if (is_admin() || self::$footer_rendered) { return; }
        self::$footer_rendered = true;

        $read_menu = static function($slug, $name) {
            $items = [];
            if (!function_exists('wp_get_nav_menu_object') || !function_exists('wp_get_nav_menu_items')) { return $items; }
            $menu = wp_get_nav_menu_object($slug);
            if (!$menu) { $menu = wp_get_nav_menu_object($name); }
            if (!$menu || empty($menu->term_id)) { return $items; }
            $raw = wp_get_nav_menu_items((int)$menu->term_id);
            if (!is_array($raw)) { return $items; }
            foreach ($raw as $item) {
                if (!is_object($item) || !empty($item->menu_item_parent)) { continue; }
                $label = trim((string)($item->title ?? ''));
                $url = trim((string)($item->url ?? ''));
                if ($label === '' || $url === '') { continue; }
                $items[] = ['label'=>$label, 'url'=>$url];
            }
            return $items;
        };
        $dedupe = static function($items) {
            $out = []; $seen = [];
            foreach ((array)$items as $item) {
                $label = trim((string)($item['label'] ?? ''));
                $url = trim((string)($item['url'] ?? ''));
                if ($label === '' || $url === '') { continue; }
                $key = strtolower(rtrim($url, '/'));
                if ($key === '') { $key = strtolower($label); }
                if (isset($seen[$key])) { continue; }
                $seen[$key] = true;
                $out[] = ['label'=>$label, 'url'=>$url];
            }
            return $out;
        };
        $render_column = static function($title, $items, $aria) {
            if (!$items) { return ''; }
            $html = '<nav class="hd-footer-menu-v150701" aria-label="' . esc_attr($aria) . '"><h3>' . esc_html($title) . '</h3><ul>';
            foreach ($items as $item) {
                $html .= '<li><a href="' . esc_url($item['url']) . '">' . esc_html($item['label']) . '</a></li>';
            }
            return $html . '</ul></nav>';
        };

        // 1.50.715: Footer bleibt vierspaltig; PB one öffnet extern in neuem Fenster.
        // Vorhandene Menü-URLs bleiben Quelle für Service/Rechtliches/Anzeigenmarkt;
        // Wissen wird aus den bestehenden Portalzielen sauber abgeleitet.
        $legal = $dedupe($read_menu('rechtliches', 'Rechtliches'));
        $info = $dedupe($read_menu('informationen', 'Informationen'));
        $year = function_exists('wp_date') ? wp_date('Y') : date('Y');

        $find_item_url = static function($items, $needles) {
            foreach ((array)$items as $item) {
                $label = sanitize_title((string)($item['label'] ?? ''));
                $url = (string)($item['url'] ?? '');
                foreach ((array)$needles as $needle) {
                    if ($needle !== '' && strpos($label, sanitize_title((string)$needle)) !== false && $url !== '') { return $url; }
                }
            }
            return '';
        };
        $make_item = static function($label, $url) {
            return $url !== '' ? ['label'=>$label, 'url'=>$url] : null;
        };
        $compact = static function($items) {
            return array_values(array_filter((array)$items, static function($item) { return is_array($item) && !empty($item['url']); }));
        };

        // Fail-safe nur fuer Rechtliches, falls der Import wirklich fehlt.
        if (!$legal) {
            foreach ([[['impressum'],'Impressum'],[['datenschutz'],'Datenschutz']] as $entry) {
                $url = self::page_link($entry[0]);
                if ($url !== '') { $legal[] = ['label'=>$entry[1], 'url'=>$url]; }
            }
        }

        // 1.50.797: AGB auch dann zeigen, wenn die WordPress-Seitenabfrage leer bleibt.
        // Der Pfad /agb/ ist aus dem vorhandenen Seitenexport bekannt.
        // Werbebedingungen gehoeren nur zu Service.
        $legal = array_values(array_filter($legal, static function($item) {
            $slug = sanitize_title((string)($item['label'] ?? ''));
            $path = parse_url((string)($item['url'] ?? ''), PHP_URL_PATH);
            $url_slug = sanitize_title((string)basename(trim((string)$path, '/')));
            return !in_array($slug, ['agb', 'werbebedingungen', 'werb-anzeigebedingungen'], true)
                && !in_array($url_slug, ['agb', 'werbebedingungen', 'werb-anzeigebedingungen'], true);
        }));
        $agb_url = self::page_link(['agb-2', 'agb']);
        if ($agb_url === '') { $agb_url = home_url('/agb-2/'); }
        $agb_position = count($legal);
        foreach ($legal as $index => $item) {
            if (sanitize_title((string)($item['label'] ?? '')) === 'impressum') {
                $agb_position = $index + 1;
                break;
            }
        }
        array_splice($legal, $agb_position, 0, [['label' => 'AGB', 'url' => $agb_url]]);


        $magazine_url = self::page_link(['magazin','journal']);
        if ($magazine_url === '') { $magazine_url = $find_item_url($info, ['hobby-magazin','magazin']); }
        if ($magazine_url === '') { $magazine_url = home_url('/magazin/'); }
        $faq_url = self::page_link(['faq']);
        if ($faq_url === '') { $faq_url = $find_item_url($info, ['faq','haeufige-fragen']); }
        if ($faq_url === '') { $faq_url = home_url('/faq/'); }
        $glossary_url = self::page_link(['magazin/wissen-glossar','wissen-glossar']);
        if ($glossary_url === '') { $glossary_url = home_url('/magazin/wissen-glossar/'); }
        $register_url = self::page_link(['hobbyregister','hobby-register']);
        if ($register_url === '') { $register_url = home_url('/hobbyregister/'); }
        $finder_url = self::page_link(['magazin/hobbyfinder','hobbyfinder']);
        if ($finder_url === '') { $finder_url = home_url('/magazin/hobbyfinder/'); }

        $knowledge = $compact([
            $make_item('Hobbymagazin', $magazine_url),
            $make_item('Hobbyfinder', $finder_url),
            $make_item('Hobbyregister', $register_url),
            $make_item('Glossar', $glossary_url),
        ]);

        $ad_url = $find_item_url($info, ['werben-im-hobby-depot','werben']);
        if ($ad_url === '') { $ad_url = self::page_link(['werbung','werbung-im-hobby-depot']); }
        $prices_url = $find_item_url($info, ['preise']);
        if ($prices_url === '') { $prices_url = self::page_link(['preise']); }
        $contact_url = $find_item_url($info, ['kontakt']);
        if ($contact_url === '') { $contact_url = self::page_link(['kontakt']); }
        $terms_url = self::page_link(['werb-anzeigebedingungen', 'werbebedingungen']);
        if ($terms_url === '') { $terms_url = home_url('/werb-anzeigebedingungen/'); }
        $service = $compact([
            $make_item('Werben im Hobby Depot', $ad_url),
            $make_item('Werbebedingungen', $terms_url),
            $make_item('Preise', $prices_url),
            $make_item('Kontakt', $contact_url),
            $make_item('FAQ', $faq_url),
        ]);

        // 1.50.742: Anzeigenmarkt-Footer nie wieder aus importierten festen URLs
        // rendern. Labels bleiben vertraut, Ziele kommen aus dem HivePress-Router.
        $market = $dedupe(self::footer_market_links_v150742());

        $footer_logo = self::asset_url('logo-footer-v150729.png');
        echo '<!-- HD-003 RUNTIME 1.50.742 --><footer class="hd-footer-v150616 hd-footer-imported-v150707" data-hd-runtime="1.50.742">'
            . '<div class="hd-footer-brand-v150724"><a href="'.esc_url(home_url('/')).'" class="hd-footer-brand-link-v150724" aria-label="Hobby Depot Startseite"><span class="hd-footer-logo-crop-v150726"><img src="'.esc_url($footer_logo).'" alt="Hobby Depot" loading="lazy" decoding="async"></span></a></div>'
            . '<div class="hd-footer-main-v150707">'
            . $render_column('Rechtliches', $legal, 'Rechtliches')
            . $render_column('Wissen', $knowledge, 'Wissen')
            . $render_column('Service', $service, 'Service')
            . $render_column('Anzeigenmarkt', $market, 'Anzeigenmarkt')
            . '</div></footer><div class="hd-footer-copyright-under-v150713"><div><small>* mithilfe von KI erstellt</small><div class="hd-footer-credit-v150713">© ' . esc_html((string)$year) . ' Hobby Depot <span aria-hidden="true">|</span> <a href="https://p-b.one/" target="_blank" rel="noopener noreferrer">PB one.</a></div></div></div>';
    }

    public static function affiliate_page_type($page_id) {
        $page_id = absint($page_id);
        if ($page_id <= 0) { return ''; }
        $front_id = absint(get_option('page_on_front'));
        if ($front_id > 0 && $page_id === $front_id) { return 'start'; }
        $post = get_post($page_id);
        if (!$post instanceof WP_Post || $post->post_type !== 'page' || $post->post_status !== 'publish') { return ''; }
        $slug = (string)$post->post_name;
        $magazine_page = self::page_by_path(['magazin','journal']);
        $magazine_id = $magazine_page instanceof WP_Post ? absint($magazine_page->ID) : 0;
        if (in_array($slug, ['magazin','journal'], true) || ($magazine_id > 0 && absint($post->post_parent) === $magazine_id)) { return 'journal'; }
        if ($slug === 'anbieter') { return 'anzeigenmarkt'; }

        $revision = self::registry_revision();
        if ($revision !== '') {
            if (!self::registry_ready()) { return ''; }
            $node = self::registry_page_node($page_id);
            if (!is_array($node)) { return ''; }
            $id = (string)($node['node_id'] ?? '');
            if (strpos($id, 'core:world:') === 0) { return 'hub1'; }
            $depth = 0; $seen = [];
            while (is_array($node)) {
                $nid = (string)($node['node_id'] ?? '');
                if ($nid === '' || isset($seen[$nid])) { return ''; }
                $seen[$nid] = true;
                $parent_id = trim((string)($node['parent_id'] ?? ''));
                if ($parent_id === '') { return ''; }
                $parent = hd_category_registry_node($parent_id);
                if (!is_array($parent)) { return ''; }
                $depth++;
                if (strpos((string)($parent['node_id'] ?? ''), 'core:world:') === 0) {
                    if ($depth === 1) { return 'hub2'; }
                    if ($depth === 2) { return 'category'; }
                    return 'leaf';
                }
                $node = $parent;
            }
            return '';
        }

        $ancestors = array_reverse(get_post_ancestors($post));
        $root = $post;
        if ($ancestors) { $root_candidate = get_post((int)$ancestors[0]); if ($root_candidate instanceof WP_Post) { $root = $root_candidate; } }
        if (!in_array((string)$root->post_name, self::world_slugs(), true)) { return ''; }
        $depth = count($ancestors);
        if ($depth === 0) { return 'hub1'; }
        if ($depth === 1) { return 'hub2'; }
        if ($depth === 2) { return 'category'; }
        return 'leaf';
    }

    public static function owns_leaf_slots($owns, $term_id) { return true; }

    public static function affiliate_slot_matrix($candidate, $portal, $adapter_version) {
        $product = ['creative_type'=>'product','ratio_min'=>0.55,'ratio_max'=>2.00,'min_width'=>180,'min_height'=>180,'crop'=>'contain','target_types'=>['page','category']];
        $wide = ['creative_type'=>'banner','ratio_min'=>5.00,'ratio_max'=>12.00,'min_width'=>600,'min_height'=>60,'crop'=>'contain','target_types'=>['page','category'],'upscale_max'=>1.10,'min_fill'=>0.60];
        $hobby = [
            'start_after_topics' => $wide + ['target_contexts'=>['start']],
            'hub_after_cards' => $wide + ['target_contexts'=>['hub1','hub2']],
            'product_after_category_tiles' => $wide + ['target_contexts'=>['hub2','category','leaf','leaf_category']],
            'post_inline_banner' => $wide + ['target_types'=>['post'],'target_contexts'=>['classic_post']],
            'journal_banner' => $wide + ['target_contexts'=>['journal']],
            'anzeigenmarkt_top_banner' => $wide + ['target_contexts'=>['anzeigenmarkt']],
            'hub_product_1' => $product + ['target_contexts'=>['start','hub1']],
            'hub_product_2' => $product + ['target_contexts'=>['start','hub1']],
            'hub_product_3' => $product + ['target_contexts'=>['start','hub1']],
            'category_product_1' => $product + ['target_contexts'=>['hub2','category','leaf','leaf_category']],
            'category_product_2' => $product + ['target_contexts'=>['hub2','category','leaf','leaf_category']],
            'category_product_3' => $product + ['target_contexts'=>['hub2','category','leaf','leaf_category']],
            'journal_product_1' => $product + ['target_contexts'=>['journal']],
            'journal_product_2' => $product + ['target_contexts'=>['journal']],
            'journal_product_3' => $product + ['target_contexts'=>['journal']],
        ];
        return array_merge(is_array($candidate) ? $candidate : [], $hobby);
    }

    private static function demo_featured_attachment_v150636($post_id, $asset_rel, $label) {
        if (!function_exists('wp_upload_bits')) { return 0; }
        $src = plugin_dir_path(dirname(__FILE__)) . 'assets/hobby-depot-v150617/' . ltrim((string)$asset_rel, '/');
        if (!is_file($src) || !is_readable($src)) { return 0; }
        $bytes = file_get_contents($src); if ($bytes === false) { return 0; }
        $name = 'hobby-depot-test-' . sanitize_title($label) . '-v150636.webp';
        $upload = wp_upload_bits($name, null, $bytes);
        if (!empty($upload['error']) || empty($upload['file'])) { return 0; }
        $filetype = wp_check_filetype($upload['file'], null);
        $attachment_id = wp_insert_attachment(['post_mime_type'=>$filetype['type'] ?: 'image/webp','post_title'=>sanitize_text_field($label),'post_status'=>'inherit'], $upload['file'], absint($post_id), true);
        if (is_wp_error($attachment_id) || !$attachment_id) { return 0; }
        if (!function_exists('wp_generate_attachment_metadata')) { require_once ABSPATH . 'wp-admin/includes/image.php'; }
        $meta = wp_generate_attachment_metadata($attachment_id, $upload['file']);
        if (is_array($meta)) { wp_update_attachment_metadata($attachment_id, $meta); }
        set_post_thumbnail(absint($post_id), absint($attachment_id));
        return absint($attachment_id);
    }

    public static function maybe_seed_demo_posts_v150637() {
        if (!current_user_can('manage_options')) { return; }
        $option = 'pftk_hd_demo_posts_v150637';
        $stored = get_option($option, []);
        $valid=[];
        if(is_array($stored)){ foreach($stored as $id){ $p=get_post(absint($id)); if($p instanceof WP_Post && $p->post_type==='post'){$valid[]=(int)$p->ID;} } }
        if(count($valid)>=4){return;}
        $cat_ids = get_categories(['hide_empty'=>false,'fields'=>'ids']);
        if (!is_array($cat_ids)) { $cat_ids=[]; }
        $cat_ids = array_values(array_unique(array_filter(array_map('absint',$cat_ids))));
        $journal_ids = [];
        if (taxonomy_exists('journal_cat') && is_object_in_taxonomy('post','journal_cat')) {
            $terms = get_terms(['taxonomy'=>'journal_cat','hide_empty'=>false,'fields'=>'ids']);
            if (!is_wp_error($terms) && is_array($terms)) { $journal_ids=array_values(array_unique(array_filter(array_map('absint',$terms)))); }
        }
        $defs = [
            ['slug'=>'hd-test-einstieg-v150636','title'=>'[TEST] Gut einsteigen: Was du am Anfang wirklich brauchst','excerpt'=>'Ein Testbeitrag für die Beitragsvorschau: Einstieg, erste Entscheidungen und sinnvolle Grundausstattung auf einen Blick.','asset'=>'subcategories/gestalten/druck-foto-v150634.webp'],
            ['slug'=>'hd-test-material-v150636','title'=>'[TEST] Material und Ausrüstung sinnvoll auswählen','excerpt'=>'Testinhalt für die Vorschau mit Bild. So wirkt ein Beitrag, der Material, Werkzeug und typische Auswahlfragen kompakt erklärt.','asset'=>'subcategories/fertigen/holz-v150634.webp'],
            ['slug'=>'hd-test-fehler-v150636','title'=>'[TEST] Typische Anfängerfehler und wie du sie vermeidest','excerpt'=>'Dieser Testbeitrag zeigt die spätere Kartenwirkung für praktische Ratgeber, Fehlerquellen und konkrete erste Schritte.','asset'=>'subcategories/technik/elektronik-v150634.webp'],
            ['slug'=>'hd-test-projekt-v150636','title'=>'[TEST] Vom ersten Versuch zum eigenen kleinen Projekt','excerpt'=>'Blindtext mit echter Vorschauwirkung: Idee, Planung, Durchführung und nächste Schritte in einem kompakten Ratgeberformat.','asset'=>'subcategories/pflanzen/gaertnern-v150634.webp'],
        ];
        $ids=[];
        foreach ($defs as $i=>$def) {
            $existing = get_page_by_path($def['slug'], OBJECT, 'post');
            if ($existing instanceof WP_Post) {
                $post_id=(int)$existing->ID;
                wp_update_post(['ID'=>$post_id,'post_status'=>'private','post_title'=>$def['title'],'post_excerpt'=>$def['excerpt']]);
            } else {
                $body='<p>Dies ist ein bewusst angelegter Testbeitrag für die Darstellung im Hobby-Depot-Design. Der Inhalt dient nur dazu, Überschrift, Beitragsfoto, Textauszug und Kartenhöhe realistisch beurteilen zu können.</p><p>Später steht hier ein echter redaktioneller Beitrag mit verständlichem Einstieg, praktischen Hinweisen, konkreten Beispielen und passenden nächsten Schritten. Für den aktuellen Designtest reicht dieser Blindtext.</p><p>Der Beitrag ist allen vorhandenen Beitragskategorien zugeordnet, damit die Vorschau auf den unterschiedlichen Kategorieebenen sichtbar geprüft werden kann.</p>';
                $post_id=wp_insert_post(['post_type'=>'post','post_status'=>'private','post_name'=>$def['slug'],'post_title'=>$def['title'],'post_excerpt'=>$def['excerpt'],'post_content'=>$body,'post_category'=>$cat_ids],true);
                if (is_wp_error($post_id) || !$post_id) { continue; }
            }
            update_post_meta($post_id,'_hd_demo_post_v150636',1);
            update_post_meta($post_id,'_hd_demo_post_v150637',1);
            update_post_meta($post_id,'_hd_seo_description',$def['excerpt']);
            wp_set_post_categories($post_id,$cat_ids,false);
            if ($journal_ids) { wp_set_object_terms($post_id,$journal_ids,'journal_cat',false); }
            if(!has_post_thumbnail($post_id)){self::demo_featured_attachment_v150636($post_id,$def['asset'],'Testbeitrag '.($i+1));}
            $ids[]=(int)$post_id;
        }
        if ($ids) { update_option($option,array_values(array_unique($ids)),false); }
    }

    public static function admin_init() {
        self::maybe_seed_demo_posts_v150637();
        if (get_option(self::RENTAL_OPTION, null) === null) { add_option(self::RENTAL_OPTION, [], '', false); }
        $release_key = 'pftk_hobby_depot_release_seen';
        if ((string)get_option($release_key, '') !== self::RELEASE) {
            update_option($release_key, self::RELEASE, false);
            if (function_exists('wp_cache_flush')) { wp_cache_flush(); }
            if (function_exists('rocket_clean_domain')) { rocket_clean_domain(); }
            if (function_exists('wp_cache_clear_cache')) { wp_cache_clear_cache(); }
            do_action('litespeed_purge_all');
        }
        register_setting('pftk_hobby_design', self::RENTAL_OPTION, ['type'=>'array','sanitize_callback'=>[__CLASS__,'sanitize_rental']]);
    }

    public static function sanitize_rental($value) {
        $value = is_array($value) ? $value : [];
        $out = [];
        foreach (['start','hub1','hub2','category','article'] as $key) {
            $slot = isset($value[$key]) && is_array($value[$key]) ? $value[$key] : [];
            $out[$key] = [
                'active' => !empty($slot['active']) ? 1 : 0,
                'image' => esc_url_raw((string)($slot['image'] ?? '')),
                'url' => esc_url_raw((string)($slot['url'] ?? '')),
                'label' => sanitize_text_field((string)($slot['label'] ?? '')),
            ];
        }
        return $out;
    }

    public static function admin_menu() {
        add_theme_page('Hobby Depot Design', 'Hobby Depot Design', 'manage_options', 'hobby-depot-design', [__CLASS__, 'admin_page']);
        add_menu_page('Hobby Depot Bildzentrale', 'Bildzentrale', 'manage_options', 'hobby-depot-bildzentrale', [__CLASS__, 'admin_bildzentrale_v150769'], 'dashicons-format-gallery', 62);
    }

    /**
     * HD007 owns the detail HTML and its own former, sometimes generic photograph.
     * Harmonize only the VISIBLE top hero on an actual /hobbyregister/<slug>/ page;
     * no duplicate image choice here – all decisions come from Bildzentrale.
     * No edit of HD007 files, no HTML output buffering, no new DB state.
     */
    public static function sync_hd007_detail_image_v150769() {
        if (!function_exists('hd_hobbyregister_ready') || !hd_hobbyregister_ready()
            || !function_exists('hd_hobbyregister_records')) { return; }
        $path=(string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''),PHP_URL_PATH);
        if (!preg_match('~^/hobbyregister/([a-z0-9-]+)/?$~i',$path,$hit)) { return; }
        $slug=sanitize_title((string)$hit[1]);
        $name='';
        foreach ((array)hd_hobbyregister_records() as $r) {
            if (!is_array($r)) { continue; }
            $item=trim((string)($r['canonical_name'] ?? ''));
            if ($item!=='' && sanitize_title($item)===$slug) { $name=$item; break; }
        }
        if ($name==='') { return; } // only confirmed HD007 detail entries
        $img=self::hobby_image_center_v150769($slug);
        $url=!empty($img['url']) ? (string)$img['url'] : '';
        if ($url === '') { return; } // no master: keep the existing HD007 photo unchanged.
        $url_js=function_exists('wp_json_encode') ? wp_json_encode($url) : json_encode($url);
        $name_js=function_exists('wp_json_encode') ? wp_json_encode($name) : json_encode($name);
        echo '<script id="hd-bildzentrale-hd007-sync-v150769">(function(){'
           . '"use strict";var url=' . $url_js . ',name=' . $name_js . ';'
           . 'var main=document.querySelector("main")||document.querySelector(".site-main");if(!main)return;'
           . 'var norm=function(s){return(s||"").trim().toLocaleLowerCase("de").replace(/\\s+/g," ")};'
           . 'var h=Array.from(main.querySelectorAll("h1")).find(function(x){return norm(x.textContent)===norm(name)});'
           . 'if(!h)return;var box=h.getBoundingClientRect();'
           . 'var shots=Array.from(main.querySelectorAll("img")).filter(function(el){'
           . 'var r=el.getBoundingClientRect();return r.width>=180&&r.height>=75'
           . '&&r.top>=box.top-180&&r.top<=box.bottom+340&&r.bottom>=box.top-120;});'
           . 'shots.sort(function(a,b){var x=a.getBoundingClientRect(),y=b.getBoundingClientRect();'
           . 'var ax=(x.left>=box.left?0:250)+Math.abs(x.top-box.top)+(x.width*x.height>40000?0:200);'
           . 'var by=(y.left>=box.left?0:250)+Math.abs(y.top-box.top)+(y.width*y.height>40000?0:200);'
           . 'return ax-by});'
           . 'if(shots.length){var el=shots[0];if(url){el.removeAttribute("srcset");'
           . 'el.removeAttribute("sizes");el.removeAttribute("data-srcset");'
           . 'el.removeAttribute("data-src");el.removeAttribute("data-lazy-src");'
           . 'var pic=el.closest("picture");if(pic)Array.from(pic.querySelectorAll("source")).forEach(function(src){src.removeAttribute("srcset")});'
           . 'el.setAttribute("src",url);el.setAttribute("data-hd-bildzentrale","master");'
           . ' }return;}'
           . 'var node=h,found=null;for(var j=0;j<5&&node;j++,node=node.parentElement){'
           . 'var scope=node.parentElement||node;var choices=Array.from(scope.querySelectorAll("div,section,header"));'
           . 'for(var i=0;i<choices.length&&i<30;i++){var c=choices[i],r=c.getBoundingClientRect();'
           . 'if(r.width<220||r.height<85||r.top<box.top-220||r.top>box.bottom+320)continue;'
           . 'if(getComputedStyle(c).backgroundImage!=="none"){found=c;break;}}if(found)break;}'
           . 'if(found){found.style.backgroundImage="url("+encodeURI(url)+")";'
           . 'found.setAttribute("data-hd-bildzentrale","master");}'
           . '})();</script>';
    }

    /**
     * HD007 rendert verwandte Hobbys selbst. Die Referenzkarten bekommen
     * ausschliesslich das bereits zentral freigegebene Master des VERLINKTEN
     * Hobbys; ohne Master bleibt nur der Text stehen. Kein WordPress-/HD007-
     * Thumbnail-Fallback, keine zweite Bildpruefung, kein Aendern von HD007.
     */
    public static function sync_hd007_reference_images_v150771() {
        if (!function_exists('hd_hobbyregister_ready') || !hd_hobbyregister_ready()
            || !function_exists('hd_hobbyregister_records')) { return; }
        $path=(string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''),PHP_URL_PATH);
        if (!preg_match('~^/hobbyregister(?:/[a-z0-9-]+)?/?$~i',$path)) { return; }
        $known=[]; $masters=[];
        foreach ((array)hd_hobbyregister_records() as $row) {
            if (!is_array($row)) { continue; }
            $name=trim((string)($row['canonical_name'] ?? ''));
            if ($name==='') { continue; }
            $slug=sanitize_title($name);
            if ($slug==='' || isset($known[$slug])) { continue; }
            // HD007-Datensaetze koennen einen stabilen Registry-Slug besitzen,
            // der nicht identisch mit dem WordPress-Slug des sichtbaren Namens ist.
            $keys=[$slug];
            $regid=(string)($row['registry_id'] ?? '');
            if (strpos($regid,'hobby:')===0) {
                $alias=sanitize_title(substr($regid,6));
                if ($alias!=='' && $alias!==$slug) { $keys[]=$alias; }
            }
            $resolved=self::hobby_image_center_v150769($slug);
            foreach ($keys as $key) {
                if (isset($known[$key])) { continue; }
                $known[$key]=1;
                if (!empty($resolved['url'])) { $masters[$key]=(string)$resolved['url']; }
            }
        }
        if (!$known) { return; }
        // JSON-Werte sind nur Ergebnisse der bestehenden zentralen PHP-Auswahl.
        $flags=JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT;
        $known_js=function_exists('wp_json_encode') ? wp_json_encode($known,$flags) : json_encode($known,$flags);
        $masters_js=function_exists('wp_json_encode') ? wp_json_encode($masters,$flags) : json_encode($masters,$flags);
        echo '<script id="hd-center-hd007-references-v150771">(function(){"use strict";'
           . 'var known='.$known_js.',master='.$masters_js.';'
           . <<<'JS'
function slugOf(a){
  if(!a||!a.getAttribute)return '';
  var href=a.getAttribute('href');if(!href)return '';
  var u;try{u=new URL(href,location.href)}catch(e){return ''}
  if(u.origin!==location.origin)return '';
  var m=u.pathname.match(/^\/hobbyregister\/([a-z0-9-]+)\/?$/i);
  return m?decodeURIComponent(m[1]).toLowerCase():'';
}
function mediaIn(root){
  if(!root||!root.querySelectorAll)return false;
  if(root.matches&&root.matches('img,picture'))return true;
  if(root.querySelector('img,picture,[style*="background-image"],'
    +'[class*="thumb"],[class*="image"],[class*="photo"],'
    +'[class*="-img"],[class*="media"]'))return true;
  return false;
}
function cardFor(link,slug){
  var n=link;
  for(var step=0;step<6&&n&&n!==document.body;step++,n=n.parentElement){
    if(!mediaIn(n))continue;
    var targets={},count=0;
    var anchors=Array.from(n.querySelectorAll('a[href]'));
    if(n.matches('a[href]'))anchors.unshift(n);
    anchors.forEach(function(a){var s=slugOf(a);if(s&&known[s]&&!targets[s]){targets[s]=1;count++}});
    // Never assign an entire sidebar/list image to one unrelated hobby.
    if(count>1)return null;
    if(count===1&&targets[slug])return n;
  }
  return null;
}
function setImage(el,url,slug){
  var mark=url||'__kein_master__';
  if(el.getAttribute('data-hd-center-img')===mark &&
     ((url&&el.getAttribute('src')===url&&!el.getAttribute('srcset'))||
      (!url&&!el.getAttribute('src')&&el.style.display==='none')))return;
  ['srcset','sizes','data-src','data-srcset','data-lazy-src','data-lazy-srcset','data-original','data-original-set'].forEach(function(n){el.removeAttribute(n)});
  var picture=el.closest('picture');
  if(picture)picture.querySelectorAll('source').forEach(function(s){s.removeAttribute('srcset');s.removeAttribute('data-srcset')});
  if(url){
    el.setAttribute('src',url);
    el.style.removeProperty('display');el.style.removeProperty('visibility');
    if(picture){picture.style.removeProperty('display');picture.style.removeProperty('visibility')}
  }
  el.setAttribute('data-hd-center-img',mark);
  el.setAttribute('data-hd-center-hobby',slug);
}
function setBackground(el,url,slug){
  if (!url) return;
  var mark=url;
  if(el.getAttribute('data-hd-center-bg')===mark)return;
  el.style.setProperty('background-image',url?'url("'+url.replace(/"/g,'%22')+'")':'none','important');
  el.setAttribute('data-hd-center-bg',mark);
  el.setAttribute('data-hd-center-hobby',slug);
}
function apply(){
  var seen=new Set();
  document.querySelectorAll('a[href*="hobbyregister/"]').forEach(function(a){
    var slug=slugOf(a);if(!slug||!known[slug])return;
    var root=cardFor(a,slug);if(!root||seen.has(root))return;
    seen.add(root);
    var url=Object.prototype.hasOwnProperty.call(master,slug)?master[slug]:'';
    if (!url) return; // no master: never suppress a previously visible thumbnail.
    // The actual miniatures of this one linked hobby, NOT images of the whole group.
    root.querySelectorAll('img').forEach(function(el){setImage(el,url,slug)});
    if(root.matches('img'))setImage(root,url,slug);
    var bg=[root].concat(Array.from(root.querySelectorAll('[style*="background-image"], [class*="thumb"], [class*="image"], [class*="photo"], [class*="-img"], [class*="media"]')));
    bg.forEach(function(el){
      if(el.tagName==='IMG'||el.tagName==='PICTURE')return;
      // Only an actual image surface; do not repaint card/panel backgrounds.
      var image=getComputedStyle(el).backgroundImage;
      if(image&&image!=='none')setBackground(el,url,slug);
    });
  });
}
apply();
// Lazy loaders may change src after page load; enforce the central decision again.
var scheduled=false;
var obs=new MutationObserver(function(mutations){
  if(!mutations.some(function(m){return m.type==='childList'||
       (m.type==='attributes'&&m.target.tagName==='IMG')}))return;
  if(scheduled)return;scheduled=true;
  requestAnimationFrame(function(){scheduled=false;apply()});
});
obs.observe(document.body,{subtree:true,childList:true,attributes:true,
  attributeFilter:['src','srcset','data-src','data-srcset']});
JS
           . '})();</script>';
    }

    public static function admin_bildzentrale_media_v150770($hook) {
        if ($hook === 'toplevel_page_hobby-depot-bildzentrale' && current_user_can('manage_options')
            && function_exists('wp_enqueue_media')) { wp_enqueue_media(); }
    }

    /** Neue Bildzuordnung wird ausschliesslich in der Bildzentrale gespeichert. */
    public static function admin_bildzentrale_save_v150770() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('hd_bildzentrale_save_v150770');
        $slug = sanitize_title((string)($_POST['hd_hobby_slug'] ?? ''));
        $action = sanitize_key((string)($_POST['hd_image_action'] ?? 'set'));
        $id = absint($_POST['hd_attachment_id'] ?? 0);
        $redirect = admin_url('admin.php?page=hobby-depot-bildzentrale');
        if ($slug==='' || !preg_match('/^[a-z0-9-]+$/',$slug)) {
            wp_safe_redirect(add_query_arg('hd_image_status','invalid_slug',$redirect)); exit;
        }
        // A slug must belong to a registered hobby OR existing published category page.
        $known = false;
        if (function_exists('hd_hobbyregister_ready') && hd_hobbyregister_ready()
            && function_exists('hd_hobbyregister_records')) {
            foreach ((array)hd_hobbyregister_records() as $r) {
                if (is_array($r) && sanitize_title((string)($r['canonical_name'] ?? ''))===$slug) { $known=true; break; }
            }
        }
        if (!$known && function_exists('get_posts')) {
            $pages=get_posts(['post_type'=>'page','post_status'=>'publish','name'=>$slug,
                'posts_per_page'=>4,'no_found_rows'=>true]);
            foreach ((array)$pages as $page) {
                if ($page instanceof WP_Post && (string)$page->post_status==='publish'
                    && sanitize_title((string)$page->post_name)===$slug) { $known=true; break; }
            }
        }
        if (!$known) { wp_safe_redirect(add_query_arg('hd_image_status','unknown',$redirect)); exit; }
        $data=get_option(self::IMAGE_CENTER_OPTION,[]);
        if (!is_array($data)) { $data=[]; }
        if ($action==='clear') {
            unset($data[$slug]); // built-in hobby master remains the approved default.
        } else {
            $file=$id>0 && function_exists('get_attached_file') ? (string)get_attached_file($id) : '';
            $dim=$file!=='' && is_file($file) ? @getimagesize($file) : false;
            if ($id<1 || !function_exists('wp_attachment_is_image') || !wp_attachment_is_image($id)
                || !is_array($dim) || (int)$dim[0]<900 || (int)$dim[1]<300) {
                wp_safe_redirect(add_query_arg('hd_image_status','invalid_image',$redirect)); exit;
            }
            $data[$slug]=$id;
        }
        update_option(self::IMAGE_CENTER_OPTION,$data,false);
        if (function_exists('wp_cache_flush')) { wp_cache_flush(); }
        if (function_exists('rocket_clean_domain')) { rocket_clean_domain(); }
        if (function_exists('wp_cache_clear_cache')) { wp_cache_clear_cache(); }
        if (function_exists('do_action')) { do_action('litespeed_purge_all'); }
        wp_safe_redirect(add_query_arg('hd_image_status','saved',$redirect)); exit;
    }

    /** Read-only listing of the SAME master decision as Finder and categories. */
    public static function admin_bildzentrale_v150769() {
        if (!current_user_can('manage_options')) { return; }
        echo '<div class="wrap"><h1>Hobby Depot – Bildzentrale</h1>';
        echo '<p><strong>Ein Motiv pro Hobby oder Kategorie.</strong> Nur in der Bildzentrale zugeordnete Fotos bzw. bereits integrierte freigegebene Master werden gezeigt. Sonst auf allen Ebenen kein Foto.</p>';
        $status=sanitize_key((string)($_GET['hd_image_status'] ?? ''));
        $messages=['saved'=>'Bildzentrale aktualisiert.','invalid_slug'=>'Ungueltiger Hobbyname.','unknown'=>'Hobby oder Kategorie unbekannt.','invalid_image'=>'Bitte ein Bild aus der Mediathek mit mindestens 900 × 300 Pixel waehlen.'];
        if (isset($messages[$status])) { echo '<div class="notice notice-info"><p>'.esc_html($messages[$status]).'</p></div>'; }
        echo '<h2>Bild zuordnen</h2><p>Hobby- oder Kategorie-Slug eingeben, Mediathek-Bild wählen und speichern. Danach wird es ohne weitere Einstellungen in Finder, Hobbyregister und Kategorie genutzt.</p>';
        echo '<form id="hd-center-form-v150770" method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        echo '<input type="hidden" name="action" value="hd_bildzentrale_save_v150770">';
        wp_nonce_field('hd_bildzentrale_save_v150770');
        echo '<label>Hobby/Kategorie-Slug: <input required name="hd_hobby_slug" id="hd-hobby-slug" class="regular-text" placeholder="z. B. anthotypie"></label> ';
        echo '<label>Mediathek-ID: <input name="hd_attachment_id" id="hd-attachment-id" type="number" min="1" style="width:110px"></label> ';
        echo '<button type="button" id="hd-select-image-v150770" class="button">Bild auswählen / hochladen</button> ';
        echo '<button type="submit" class="button button-primary" name="hd_image_action" value="set">Zuordnen</button> ';
        echo '<button type="submit" class="button" name="hd_image_action" value="clear" formnovalidate>Zuordnung zurücksetzen</button>';
        echo '</form>';
        echo '<script>(function(){var choose=document.getElementById("hd-select-image-v150770");if(!choose)return;choose.addEventListener("click",function(){if(!window.wp||!wp.media)return;var frame=wp.media({title:"Ein Hobbybild auswählen",multiple:false,library:{type:"image"}});frame.on("select",function(){var item=frame.state().get("selection").first();if(item)document.getElementById("hd-attachment-id").value=item.id;});frame.open();});})();</script>';

        if (!function_exists('hd_hobbyregister_ready') || !hd_hobbyregister_ready()
            || !function_exists('hd_hobbyregister_records')) {
            echo '<p>Das Hobbyregister (HD007) ist derzeit nicht verfügbar.</p></div>'; return;
        }
        $rows=[]; $count=0; $missing=0;
        foreach ((array)hd_hobbyregister_records() as $row) {
            if (!is_array($row)) { continue; }
            $name=trim((string)($row['canonical_name'] ?? ''));
            if ($name==='') { continue; }
            $img=self::hobby_image_center_v150769($name);
            if (empty($img['url'])) { $missing++; } else { $count++; }
            $rows[]=['name'=>$name,'img'=>$img];
        }
        echo '<p><strong>' . intval($count) . '</strong> Bildmaster / breite geprüfte Motive; '
           . '<strong>' . intval($missing) . '</strong> nicht mit einem solchen Bild belegt. '
           . 'Separate WordPress-Seitenbilder werden nicht automatisch uebernommen.</p>';
        echo '<table class="widefat striped"><thead><tr><th>Hobby</th><th>Bild</th><th>Herkunft</th><th>Bearbeiten</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            $img=$row['img']; echo '<tr><td>' . esc_html($row['name']) . '</td>';
            if (!empty($img['url'])) {
                echo '<td><img src="' . esc_url($img['url']) . '" alt="" width="96" loading="lazy"></td>';
                echo '<td>' . esc_html((string)$img['source']) . '</td>';
            } else { echo '<td>Kein Bild</td><td>Offen</td>'; }
            echo '<td><button type="button" class="button hd-center-choose-slug" data-slug="'.esc_attr(sanitize_title($row['name'])).'">Auswählen</button></td>';
            echo '</tr>';
        }
        echo '</tbody></table><script>document.querySelectorAll(".hd-center-choose-slug").forEach(function(b){b.addEventListener("click",function(){document.getElementById("hd-hobby-slug").value=b.getAttribute("data-slug");document.getElementById("hd-hobby-slug").scrollIntoView({block:"center"});});});</script></div>';
    }

    public static function admin_page() {
        if (!current_user_can('manage_options')) { return; }
        $all = self::rental_settings();
        echo '<div class="wrap"><h1>Hobby Depot Design</h1><p>Direkt vermietete Werbeflächen. Pro Seite/Kategorie maximal ein Platz. Unbelegt bleibt der Verkaufsplatz öffentlich als „Werbeplatz verfügbar“ sichtbar.</p><form method="post" action="options.php">';
        settings_fields('pftk_hobby_design');
        echo '<table class="form-table"><tbody>';
        foreach (['start'=>'Startseite','hub1'=>'Hub 1','hub2'=>'Hub 2','category'=>'Kategorie','article'=>'Beitrag'] as $key=>$label) {
            $s = isset($all[$key]) && is_array($all[$key]) ? $all[$key] : [];
            $base = esc_attr(self::RENTAL_OPTION . '[' . $key . ']');
            echo '<tr><th scope="row">' . esc_html($label) . '</th><td><label><input type="checkbox" name="' . $base . '[active]" value="1" ' . checked(!empty($s['active']), true, false) . '> aktiv</label><br><input class="regular-text" type="url" name="' . $base . '[image]" value="' . esc_attr((string)($s['image'] ?? '')) . '" placeholder="Bild-URL"><br><input class="regular-text" type="url" name="' . $base . '[url]" value="' . esc_attr((string)($s['url'] ?? '')) . '" placeholder="Ziel-URL"><br><input class="regular-text" type="text" name="' . $base . '[label]" value="' . esc_attr((string)($s['label'] ?? '')) . '" placeholder="Partner / Kampagne"></td></tr>';
        }
        echo '</tbody></table>'; submit_button('Speichern'); echo '</form></div>';
    }

    public static function enqueue_styles() {
        wp_register_style('pftk-hobby-depot-v150616', false, [], defined('Pferde_Template_Kit::VERSION') ? Pferde_Template_Kit::VERSION : '1.50.616');
        wp_enqueue_style('pftk-hobby-depot-v150616');
        wp_add_inline_style('pftk-hobby-depot-v150616', self::css());
    }

    private static function css() {
        return <<<'CSS'
:root{--hd-dark:#3f474b;--hd-dark2:#29383f;--hd-petrol:#0f8f95;--hd-petrol-deep:#0a777c;--hd-sand:#d5b485;--hd-cream:#fbfaf7;--hd-paper:#fff;--hd-line:rgba(63,71,75,.13);--hd-muted:#657078;--hd-content:1440px}

/* 1.50.730: zentrale Hobby-Depot-Inhaltsachse.
   Nur der BODY/Inhaltsbereich wird auf 1200 px begrenzt.
   Header und Footer behalten bewusst die bisherige 1440-px-Achse. */
body.pftk-design-profile-hobby-depot{--hd-content:1200px}
body.pftk-design-profile-hobby-depot .hd-header-v150616,
body.pftk-design-profile-hobby-depot .hd-footer-v150616{--hd-content:1440px}
html{overflow-x:hidden}body.pftk-design-profile-hobby-depot{margin:0!important;background:#fff!important;color:var(--hd-dark)!important;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif!important}body.pftk-design-profile-hobby-depot *{box-sizing:border-box}body.pftk-design-profile-hobby-depot a{color:inherit}
/* 1.50.770: no false substitute photographs or empty photo frame. */
.hd-page-hero-world.hd-center-no-photo-v150770{display:block!important;height:auto!important;min-height:0!important}
.hd-page-hero-world.hd-center-no-photo-v150770 .hd-page-hero-copy{width:100%!important;max-width:none!important}
.hd-hub2-intro.hd-center-no-photo-v150770{display:block!important;min-height:0!important;height:auto!important}
.hd-hub2-intro.hd-center-no-photo-v150770 .hd-bp-hero-copy{width:100%!important;max-width:none!important}
/* Theme shell neutralisation: the Hobby homepage itself owns the full layout. */
body.hd-home-v150616 .site-content,body.hd-home-v150616 #content,body.hd-home-v150616 .container,body.hd-home-v150616 .content-area,body.hd-home-v150616 .site-main,body.hd-home-v150616 article.page,body.hd-home-v150616 .entry-content{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}body.hd-home-v150616 .entry-header{display:none!important}body.hd-home-v150616 .entry-content>.wp-block-group,body.hd-home-v150616 .entry-content>.alignwide,body.hd-home-v150616 .entry-content>.alignfull{max-width:none!important;margin:0!important;padding:0!important}
.hd-header-v150616{position:relative;z-index:9999;width:100%;background:#f5f1e9;border-bottom:1px solid var(--hd-line);color:var(--hd-dark2)}
.hd-topbar-v150616{height:30px;border-bottom:1px solid rgba(63,71,75,.08);background:#fbfaf7;font-size:12px}.hd-topbar-v150616>div{display:flex;width:min(calc(100% - 72px),var(--hd-content));height:30px;margin:auto;align-items:center;justify-content:space-between;gap:24px}.hd-topbar-v150616 nav{display:flex;align-items:center;gap:10px}.hd-topbar-v150616 nav a{text-decoration:none}.hd-topbar-v150616 nav span{opacity:.45}
.hd-head-v150616{display:grid;width:min(calc(100% - 72px),var(--hd-content));min-height:118px;margin:auto;grid-template-columns:300px minmax(0,1fr) 44px;gap:30px;align-items:center}.hd-logo-v150616{display:flex;width:250px;height:112px;align-items:center;justify-content:flex-start;overflow:hidden}.hd-logo-v150616 img{display:block;width:238px;height:auto;max-height:110px;object-fit:contain;object-position:left center}.hd-head-center-v150616{display:grid;align-self:stretch;grid-template-rows:66px 44px;align-content:center}
.hd-search-v150616{position:relative;display:flex;width:min(100%,760px);height:42px;margin:auto;align-items:center;border:1px solid var(--hd-line);border-radius:6px;background:#fff;box-shadow:0 3px 14px rgba(42,55,61,.04)}.hd-search-v150616 svg{position:absolute;left:15px;width:18px;height:18px;fill:none;stroke:var(--hd-dark2);stroke-width:1.8}.hd-search-v150616 input{width:100%;height:100%;padding:0 18px 0 44px;border:0!important;outline:0!important;background:transparent!important;color:var(--hd-dark2);font-size:13px;box-shadow:none!important}.hd-search-v150616 input::placeholder{color:#8a9296}
.hd-nav-v150616{align-self:start}.hd-nav-v150616>ul{display:flex;justify-content:center;gap:42px;margin:0;padding:0;list-style:none}.hd-nav-item{position:relative;display:flex;align-items:center;white-space:nowrap}.hd-nav-item>a{display:inline-flex;align-items:center;gap:7px;font-size:14px;font-weight:680;text-decoration:none}.hd-nav-item>a:hover{color:var(--hd-petrol)}.hd-nav-world-icon{display:inline-flex;width:22px;height:22px;align-items:center;justify-content:center;color:var(--hd-world-accent)}.hd-nav-world-icon svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.hd-nav-world-label{display:inline-block}.hd-sub-toggle-v150616{width:22px;height:22px;margin-left:2px;padding:0;border:0;background:transparent}.hd-sub-toggle-v150616 span:after{content:"";display:block;width:6px;height:6px;margin:4px auto;border-right:1.5px solid var(--hd-dark2);border-bottom:1.5px solid var(--hd-dark2);transform:rotate(45deg)}.hd-menu-toggle-v150616{display:none;width:42px;height:42px;padding:8px;border:0;background:transparent}.hd-menu-toggle-v150616 span{display:block;width:24px;height:2px;margin:5px auto;background:var(--hd-dark2)}
.hd-mega{position:absolute;z-index:10020;top:100%;left:50%;display:none;width:min(1100px,calc(100vw - 48px));padding:25px;border:1px solid var(--hd-line);border-radius:5px;background:#fff;box-shadow:0 18px 48px rgba(42,55,61,.13);transform:translateX(-50%)}.has-mega{position:relative}.has-mega:after{content:"";position:absolute;left:-8px;right:-8px;top:100%;height:6px;background:transparent;pointer-events:auto}.has-mega:hover>.hd-mega,.has-mega:focus-within>.hd-mega,.has-mega.is-sub-open>.hd-mega{display:block}.hd-mega-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:24px 30px}.hd-mega section{min-width:0}.hd-mega-world{display:block;margin-bottom:8px;color:var(--hd-dark2);font-size:15px;font-weight:800;text-decoration:none}.hd-mega ul{display:grid;gap:5px;margin:0;padding:0;list-style:none}.hd-mega li a{color:#59656a;font-size:12px;line-height:1.35;text-decoration:none}.hd-mega-list{width:330px}.hd-mega-list ul{grid-template-columns:1fr}
.hd-home-v150616-main{width:100%;margin:0 auto;padding:0 0 64px}.hd-home-v150616-main a{text-decoration:none}.hd-hero-v150616{display:grid;width:min(calc(100% - 72px),var(--hd-content));height:310px;margin:0 auto;grid-template-columns:41% 59%;overflow:hidden;border-radius:0 0 2px 2px;background:#f8f4ed}.hd-hero-copy{position:relative;display:flex;padding:30px 34px 28px 42px;flex-direction:column;justify-content:center;background:linear-gradient(90deg,#fbfaf7 0%,#fbfaf7 78%,rgba(251,250,247,.94) 100%)}.hd-hero-copy:before{content:"";position:absolute;left:-22px;bottom:62px;width:98px;height:28px;border-top:8px solid rgba(213,180,133,.8);border-radius:50%;transform:rotate(-13deg)}.hd-hero-copy>span{margin-bottom:11px;color:var(--hd-dark2);font-size:10px;font-weight:800;letter-spacing:.18em;text-transform:uppercase}.hd-hero-copy h1{margin:0;color:#14303d!important;font-size:clamp(46px,4.25vw,66px)!important;font-weight:800!important;letter-spacing:-.045em;line-height:.96}.hd-hero-copy h1 em{color:var(--hd-petrol);font-style:normal}.hd-hero-copy p{max-width:540px;margin:14px 0 16px;color:#31444c;font-size:16px;line-height:1.42}.hd-hero-actions{display:flex;gap:12px;flex-wrap:wrap}.hd-hero-actions a,.hd-editorial-card a{display:inline-flex;min-height:40px;padding:0 21px;align-items:center;justify-content:center;gap:18px;border:1px solid rgba(42,55,61,.14);border-radius:999px;background:#fff;color:#17313c;font-size:13px;font-weight:750}.hd-hero-actions a.is-primary{border-color:var(--hd-petrol);background:var(--hd-petrol);color:#fff}.hd-hero-finder-action{align-items:center!important}.hd-hero-finder-prompt{display:inline-flex;align-items:center;color:#52656d;font-size:12.5px;font-weight:650;line-height:1.3}.hd-hero-image{min-width:0;overflow:hidden}.hd-hero-image img{display:block;width:100%;height:100%;object-fit:cover;object-position:center center}
.hd-section,.hd-editorial-grid,.hd-affiliate-banner,.hd-rental{width:min(calc(100% - 72px),var(--hd-content));margin:19px auto 0}.hd-section-head{display:flex;margin-bottom:10px;align-items:flex-end;justify-content:space-between;gap:20px}.hd-section-head>div{position:relative}.hd-brush-head>div:before{content:"";position:absolute;left:-18px;top:-8px;width:50px;height:14px;border-top:5px solid var(--hd-sand);border-radius:50%;transform:rotate(-8deg);opacity:.95}.hd-section-head h2{position:relative;margin:0;color:#17313c!important;font-size:24px!important;font-weight:800!important;line-height:1.04}.hd-section-head p{margin:3px 0 0;color:#56656b;font-size:12px;line-height:1.35}.hd-section-head>a{padding-bottom:2px;color:var(--hd-petrol-deep);font-size:12px;font-weight:750}
.hd-world-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.hd-world-card{display:block;min-width:0;overflow:hidden;border:1px solid rgba(63,71,75,.12);border-radius:4px;background:#fff;color:#17313c;box-shadow:0 2px 8px rgba(42,55,61,.025);transition:border-color .15s ease,transform .15s ease}.hd-world-card img{display:block;width:100%;height:158px;object-fit:cover}.hd-world-card-meta{display:grid;min-height:58px;padding:9px 12px 10px;grid-template-columns:40px minmax(0,1fr) 22px;gap:10px;align-items:center}.hd-world-icon{display:flex;width:38px;height:38px;align-items:center;justify-content:center;border-radius:50%;background:var(--hd-world-accent);color:#fff}.hd-world-icon svg{width:21px;height:21px;fill:none;stroke:currentColor;stroke-width:1.75;stroke-linecap:round;stroke-linejoin:round}.hd-world-card strong{display:block;font-size:16px;font-weight:820;line-height:1.08}.hd-world-card-meta>b{color:#536167;font-size:18px;font-weight:500;text-align:right}.hd-world-card:hover{border-color:color-mix(in srgb,var(--hd-world-accent) 58%,transparent);transform:translateY(-1px)}
.hd-editorial-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.hd-editorial-card{position:relative;min-height:128px;overflow:hidden;border:1px solid rgba(63,71,75,.1);border-radius:4px;background:#eef8f6}.hd-editorial-card:before{content:"";position:absolute;inset:0;background-image:linear-gradient(90deg,rgba(235,248,246,.98) 0%,rgba(235,248,246,.92) 45%,rgba(235,248,246,.16) 78%,rgba(235,248,246,.02) 100%),var(--hd-card-image);background-position:center,right center;background-size:100% 100%,48% 100%;background-repeat:no-repeat}.hd-editorial-card.is-magazine:before{background-image:linear-gradient(90deg,rgba(255,248,239,.98) 0%,rgba(255,248,239,.92) 48%,rgba(255,248,239,.16) 80%,rgba(255,248,239,.02) 100%),var(--hd-card-image)}.hd-editorial-card.is-guide:before{background-image:linear-gradient(90deg,rgba(248,245,238,.98) 0%,rgba(248,245,238,.93) 48%,rgba(248,245,238,.15) 80%,rgba(248,245,238,.02) 100%),var(--hd-card-image)}.hd-editorial-copy{position:relative;z-index:1;display:flex;min-height:128px;padding:16px 19px;flex-direction:column;align-items:flex-start;justify-content:center}.hd-editorial-copy h2{margin:0 0 4px;color:#17313c!important;font-size:21px!important;font-weight:800!important;line-height:1.05}.hd-editorial-copy p{max-width:62%;margin:0 0 9px;color:#45565d;font-size:11.5px;line-height:1.35}.hd-editorial-card a{min-height:31px;padding:0 14px;font-size:10.5px}
.hd-products{margin-top:17px}.hd-product-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.hd-product-slot{min-width:0;height:92px;overflow:hidden;border:1px solid rgba(63,71,75,.12);border-radius:4px;background:#fff}.hd-product-slot>.ppar-affiliate-slot{display:block!important;width:100%!important;height:100%!important;min-height:0!important;max-height:92px!important;margin:0!important;padding:0!important;border:0!important;background:#fff!important;overflow:hidden!important}.hd-product-slot .ppar-affiliate-disclosure,.hd-product-slot .ppar-affiliate-label{display:none!important}.hd-product-slot .ppar-affiliate-content{width:100%!important;height:100%!important;min-height:0!important;margin:0!important;padding:0!important}.hd-product-slot .ppar-banner-link,.hd-product-slot .ppar-banner-link[data-ppar-category-product-card="1"]{display:grid!important;width:100%!important;height:100%!important;min-height:0!important;grid-template-columns:132px minmax(0,1fr)!important;grid-template-rows:1fr!important;align-items:center!important;gap:0!important;margin:0!important;padding:0!important;border:0!important;background:#fff!important}.hd-product-slot .ppar-banner-image-wrap{display:flex!important;width:132px!important;height:90px!important;min-height:0!important;align-items:center!important;justify-content:center!important;background:#fbfaf7!important}.hd-product-slot img.ppar-banner-image{display:block!important;max-width:118px!important;max-height:78px!important;width:auto!important;height:auto!important;object-fit:contain!important}.hd-product-slot .ppar-banner-text{display:flex!important;min-width:0!important;height:100%!important;padding:9px 13px!important;flex-direction:column!important;align-items:flex-start!important;justify-content:center!important;overflow:hidden!important}.hd-product-slot .ppar-banner-title,.hd-product-slot strong{display:block!important;margin:0 0 3px!important;color:#17313c!important;font-size:12px!important;font-weight:800!important;line-height:1.15!important}.hd-product-slot .ppar-banner-description,.hd-product-slot .ppar-banner-text span{max-height:30px!important;overflow:hidden!important;color:#657177!important;font-size:10px!important;line-height:1.25!important}.hd-product-slot .ppar-banner-button,.hd-product-slot .ppar-banner-cta{margin-top:4px!important;color:var(--hd-petrol)!important;font-size:10px!important;font-weight:750!important}
.hd-affiliate-banner{position:relative;height:78px;overflow:hidden;border-radius:4px;background:#fff}.hd-affiliate-banner>div,.hd-affiliate-banner>div>.ppar-affiliate-slot,.hd-affiliate-banner .ppar-affiliate-content,.hd-affiliate-banner .ppar-banner-link{width:100%!important;height:100%!important;min-height:0!important;max-height:78px!important;margin:0!important;padding:0!important;border:0!important;overflow:hidden!important}.hd-affiliate-banner img{display:block!important;width:100%!important;height:78px!important;max-height:78px!important;object-fit:cover!important}.hd-affiliate-banner .ppar-affiliate-disclosure,.hd-affiliate-banner .ppar-affiliate-label{display:none!important}.hd-ad-label{position:absolute;z-index:4;left:13px;top:9px;padding:3px 7px;border-radius:4px;background:rgba(255,255,255,.92);color:#59656a;font-size:8.5px;font-weight:750;letter-spacing:.06em;text-transform:uppercase}
.hd-topics{margin-top:15px}.hd-topic-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px}.hd-topic-grid article{overflow:hidden;border:1px solid rgba(63,71,75,.11);border-radius:4px;background:#fff}.hd-topic-grid a{display:grid;grid-template-columns:106px minmax(0,1fr);min-height:74px;align-items:center}.hd-topic-grid img{display:block;width:106px;height:74px;object-fit:cover}.hd-topic-grid strong{display:block;padding:8px 10px;color:#17313c;font-size:11px;line-height:1.25}
.hd-rental{margin-top:15px}.hd-rental-link{display:grid;grid-template-columns:minmax(240px,38%) 1fr;min-height:106px;overflow:hidden;border:1px solid var(--hd-line);border-radius:4px;background:#fff}.hd-rental-link>img{width:100%;height:106px;object-fit:cover}.hd-rental-link>span{display:flex;padding:16px 22px;flex-direction:column;justify-content:center}.hd-rental-link small{color:#8c6a40;font-size:9px;font-weight:800;text-transform:uppercase}.hd-rental-link strong{margin:3px 0 7px;font-size:18px}.hd-rental-link b{color:var(--hd-petrol);font-size:11px}
.hd-footer-v150616{margin-top:28px;background:#f5f1e9;color:var(--hd-dark2)}.hd-footer-brand-v150724{display:flex;width:min(calc(100% - 72px),var(--hd-content));min-height:64px;margin:auto;padding:8px 0 6px;align-items:center;border-bottom:1px solid rgba(63,71,75,.10)}.hd-footer-brand-link-v150724{display:inline-flex;flex:0 0 auto;align-items:center;text-decoration:none!important}.hd-footer-logo-crop-v150726{display:block;width:102px;height:auto;overflow:visible}.hd-footer-logo-crop-v150726 img{display:block;width:102px;height:auto;max-width:100%;object-fit:contain}.hd-footer-main-v150707{display:grid;width:min(calc(100% - 72px),var(--hd-content));margin:auto;padding:25px 0 28px;grid-template-columns:repeat(4,minmax(150px,1fr));gap:38px;align-items:start}.hd-footer-v150616 nav{display:block}.hd-footer-v150616 nav h3{margin:0 0 14px;color:var(--hd-dark2);font-size:16.5px;font-weight:750;line-height:1.25}.hd-footer-v150616 nav ul{display:grid;gap:10px;margin:0;padding:0;list-style:none}.hd-footer-v150616 nav li{margin:0;padding:0}.hd-footer-v150616 nav a{color:var(--hd-dark2)!important;font-size:14px;line-height:1.4;text-decoration:none}.hd-footer-v150616 nav a:hover{color:var(--hd-petrol)!important}.hd-footer-copyright-under-v150713{width:100%;margin:0;background:#fff;color:var(--hd-muted);text-align:center;line-height:1.3}.hd-footer-copyright-under-v150713>div{width:min(calc(100% - 72px),var(--hd-content));margin:auto;padding:10px 0 16px}.hd-footer-copyright-under-v150713 small{display:block;margin:0 0 4px;font-size:10.5px;font-weight:500}.hd-footer-credit-v150713{font-size:13px}.hd-footer-credit-v150713 a{color:inherit!important;text-decoration:none}.hd-footer-credit-v150713 a:hover{color:var(--hd-petrol)!important;text-decoration:underline}
/* 1.50.702: genau ein Footer-Eigentuemer. Der Theme-Footer wird im Hobby-Depot-Profil ausgeblendet; der eigene HD-Footer bleibt sichtbar. */
html body footer.site-footer,html body .site-footer,html body .site-footer .footer-widgets,html body .site-footer .footer-navbar,html body .footer-navbar{display:none!important}
.hd-footer-finder-v150703{display:none!important}
body.pftk-design-profile-hobby-depot footer#colophon,body.pftk-design-profile-hobby-depot .site-footer{margin-top:0!important;background:var(--hd-dark)!important;color:#f7f5ef!important;border-top:0!important}body.pftk-design-profile-hobby-depot footer#colophon a,body.pftk-design-profile-hobby-depot .site-footer a{color:#f7f5ef!important}body.pftk-design-profile-hobby-depot footer#colophon .widget-title,body.pftk-design-profile-hobby-depot .site-footer .widget-title{color:#fff!important}
@media(max-width:1180px){.hd-head-v150616{grid-template-columns:260px minmax(0,1fr) 44px;gap:18px}.hd-logo-v150616{width:225px}.hd-logo-v150616 img{width:218px}.hd-nav-v150616>ul{gap:22px}.hd-world-grid{grid-template-columns:repeat(5,minmax(0,1fr))}.hd-world-card img{height:138px}.hd-world-card strong{font-size:15px}.hd-topic-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.hd-mega-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:760px){.hd-topbar-v150616{display:none!important}.hd-head-v150616{grid-template-columns:1fr 42px;width:100%;min-height:128px;padding:7px 12px 9px;gap:4px 8px}.hd-logo-v150616{grid-column:1;width:206px;height:80px}.hd-logo-v150616 img{width:198px;max-height:80px}.hd-head-center-v150616{display:contents}.hd-search-v150616{grid-column:1/-1;grid-row:2;width:100%;height:38px;margin:0}.hd-menu-toggle-v150616{display:block;grid-column:2;grid-row:1;align-self:center}.hd-nav-v150616{display:none;grid-column:1/-1;width:100%;margin:0;padding:3px 0 8px;border-top:1px solid var(--hd-line);background:#f5f1e9}.hd-header-v150616.is-open .hd-nav-v150616{display:block}.hd-nav-v150616>ul{display:block}.hd-nav-item{display:grid;grid-template-columns:1fr 40px;border-bottom:1px solid var(--hd-line)}.hd-nav-item>a{padding:13px 4px;font-size:13px}.hd-nav-world-icon{width:24px;height:24px}.hd-nav-world-icon svg{width:21px;height:21px}.hd-sub-toggle-v150616{width:40px;height:44px;margin:0}.hd-mega{position:static;grid-column:1/-1;width:100%;padding:0 4px 14px;border:0;border-radius:0;box-shadow:none;transform:none}.has-mega:hover>.hd-mega,.has-mega:focus-within>.hd-mega{display:none}.has-mega.is-sub-open>.hd-mega{display:block}.hd-mega-grid{grid-template-columns:1fr;gap:12px}.hd-mega section ul{display:none}.hd-mega-world{padding:6px 0}.hd-mega-list{width:100%}.hd-home-v150616-main{padding-bottom:44px}.hd-hero-v150616{width:100%;height:auto;margin:0;grid-template-columns:1fr}.hd-hero-image{order:1}.hd-hero-image img{height:190px;object-position:center}.hd-hero-copy{order:2;padding:22px 20px 24px}.hd-hero-copy:before{display:none}.hd-hero-copy>span{font-size:8px;margin-bottom:8px}.hd-hero-copy h1{font-size:clamp(34px,10.7vw,46px)!important}.hd-hero-copy p{margin:11px 0 14px;font-size:14px}.hd-hero-actions a{min-height:38px;padding:0 17px;font-size:11.5px}.hd-section,.hd-editorial-grid,.hd-affiliate-banner,.hd-rental{width:calc(100% - 24px);margin-top:18px}.hd-section-head{align-items:flex-start}.hd-section-head h2{font-size:21px!important}.hd-section-head p{font-size:10.5px}.hd-section-head>a{font-size:10px}.hd-world-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.hd-world-card img{height:auto;aspect-ratio:1.55/1}.hd-world-card-meta{min-height:52px;padding:7px 8px;grid-template-columns:34px minmax(0,1fr) 16px;gap:7px}.hd-world-icon{width:33px;height:33px}.hd-world-icon svg{width:18px;height:18px}.hd-world-card strong{font-size:14px}.hd-world-card-meta>b{font-size:15px}.hd-editorial-grid{grid-template-columns:1fr;gap:8px}.hd-editorial-card{min-height:98px}.hd-editorial-copy{min-height:98px;padding:12px 14px}.hd-editorial-copy h2{font-size:17px!important}.hd-editorial-copy p{max-width:66%;font-size:9.5px}.hd-editorial-card a{min-height:28px;font-size:9.5px}.hd-product-grid{grid-template-columns:1fr}.hd-product-slot{height:88px}.hd-affiliate-banner{height:72px}.hd-affiliate-banner>div,.hd-affiliate-banner>div>.ppar-affiliate-slot,.hd-affiliate-banner .ppar-affiliate-content,.hd-affiliate-banner .ppar-banner-link,.hd-affiliate-banner img{height:72px!important;max-height:72px!important}.hd-topic-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.hd-topic-grid a{grid-template-columns:68px minmax(0,1fr);min-height:64px}.hd-topic-grid img{width:68px;height:64px}.hd-topic-grid strong{font-size:9.5px;padding:6px 7px}.hd-rental-link{grid-template-columns:1fr}.hd-rental-link>img{height:135px}.hd-rental-link>span{padding:13px 15px}}
@media(max-width:980px) and (min-width:761px){.hd-footer-main-v150707{grid-template-columns:repeat(2,minmax(0,1fr));gap:30px 42px}}@media(max-width:760px){.hd-footer-brand-v150724{width:calc(100% - 24px);min-height:58px;padding:6px 0 4px}.hd-footer-logo-crop-v150726{width:90px;height:auto}.hd-footer-logo-crop-v150726 img{width:90px;height:auto}.hd-footer-main-v150707{width:calc(100% - 24px);padding:20px 0 20px;grid-template-columns:1fr;gap:23px}.hd-footer-v150616 nav{display:block}.hd-footer-copyright-under-v150713>div{width:calc(100% - 24px);padding:10px 0 14px}.hd-footer-copyright-under-v150713 small{font-size:9.5px}.hd-footer-credit-v150713{font-size:12px}}

/* 1.50.610: approved-detail corrections only; no concept redesign. */
.hd-hero-copy:before,.hd-brush-head>div:before{display:none!important;content:none!important}
.hd-topbar-v150616>div{justify-content:flex-start}
.hd-head-v150616{grid-template-columns:305px minmax(0,1fr) 44px;min-height:140px}
.hd-logo-v150616{width:286px;height:132px}.hd-logo-v150616 img{width:278px;max-height:128px}
.hd-head-center-v150616{grid-template-rows:76px 48px}
.hd-nav-v150616>ul{justify-content:space-between;gap:18px;width:100%}
.hd-nav-item>a{font-size:13px;font-weight:720}
.hd-mega-single{width:230px;padding:14px 17px}.hd-mega-single ul{display:grid;gap:7px;margin:0;padding:0;list-style:none}.hd-mega-single li a{font-size:12px}
.hd-section-head>div:before{display:none!important}
.hd-editorial-grid{grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-top:20px}
.hd-editorial-card{min-height:142px}.hd-editorial-copy{min-height:142px;padding:18px 22px}.hd-editorial-copy h2{font-size:23px!important}
.hd-products{margin-top:22px}.hd-affiliate-banner{margin-top:14px}.hd-topics{margin-top:20px}.hd-rental{margin-top:16px}
@media(max-width:1180px){.hd-head-v150616{grid-template-columns:265px minmax(0,1fr) 44px}.hd-nav-v150616>ul{gap:10px}.hd-nav-item>a{font-size:11.5px}}
@media(max-width:760px){.hd-head-v150616{grid-template-columns:1fr 42px;min-height:134px}.hd-logo-v150616{width:218px;height:88px}.hd-logo-v150616 img{width:210px;max-height:86px}.hd-nav-v150616>ul{display:block}.hd-nav-item>a{font-size:13px}.hd-mega-single{width:100%;padding:0 4px 12px}.hd-mega-single ul{display:grid;gap:3px}.hd-mega-single li a{display:block;padding:7px 8px;font-size:12px}.hd-editorial-grid{grid-template-columns:1fr}.hd-editorial-card{min-height:108px}.hd-editorial-copy{min-height:108px}}
@media(max-width:390px){.hd-logo-v150616{width:202px}.hd-logo-v150616 img{width:196px}}

/* 1.50.610: ListingHive baseline + hero responsive rootfix + sharp image source contract. */
body.pftk-design-profile-hobby-depot.hd-listinghive-v150616>.site-container>.site-header,
body.pftk-design-profile-hobby-depot.hd-listinghive-v150616 .site-container>.site-footer{display:none!important}
body.pftk-design-profile-hobby-depot.hd-listinghive-v150616 .site-container{min-height:0!important}
body.pftk-design-profile-hobby-depot.hd-listinghive-v150616 .site-content{margin:0!important}
.hd-world-image,.hd-topic-image,.hd-hero-img{image-rendering:auto!important;backface-visibility:hidden}
.hd-hero-v150616{height:auto!important;min-height:320px!important;overflow:visible!important;align-items:stretch}
.hd-hero-copy{min-width:0;min-height:320px;overflow:visible!important}
.hd-hero-image{min-height:320px;overflow:hidden!important}
.hd-hero-img{width:100%!important;height:100%!important;min-height:320px;object-fit:cover;object-position:center center}
.hd-hero-actions{position:relative;z-index:3;display:flex!important;flex-wrap:wrap!important;align-items:stretch;gap:10px;max-width:100%;overflow:visible!important}
.hd-hero-actions a{display:inline-flex!important;flex:0 1 auto;max-width:100%;min-width:0;white-space:normal;text-align:center;overflow:visible!important}
@media(max-width:1100px) and (min-width:981px){.hd-hero-v150616{grid-template-columns:minmax(360px,44%) minmax(0,56%)}.hd-hero-copy{padding:26px 28px 26px 32px}.hd-hero-copy h1{font-size:clamp(39px,4.1vw,50px)!important}.hd-hero-copy p{font-size:14px}.hd-hero-actions a{padding:0 16px;font-size:12px}}
@media(max-width:980px){.hd-hero-v150616{grid-template-columns:1fr!important;min-height:0!important}.hd-hero-image{order:1;min-height:0!important}.hd-hero-img{height:clamp(230px,42vw,340px)!important;min-height:0!important;object-position:center 40%}.hd-hero-copy{order:2;min-height:0!important;padding:26px 28px 30px!important}.hd-hero-copy h1{font-size:clamp(38px,7vw,56px)!important}.hd-hero-copy p{max-width:720px}.hd-hero-actions{width:100%}}
@media(max-width:540px){.hd-hero-finder-prompt{width:100%;font-size:11.5px}.hd-hero-copy{padding:22px 18px 24px!important}.hd-hero-img{height:210px!important}.hd-hero-actions{display:grid!important;grid-template-columns:1fr!important;gap:8px!important}.hd-hero-actions a{width:100%!important;min-height:42px!important;margin:0!important;padding:0 14px!important}.hd-hero-copy h1{font-size:clamp(33px,10vw,44px)!important}}

/* 1.50.610: homepage completion, calm per-world mega menus and text hover affordance. */
.hd-nav-item>a{position:relative;transition:color .16s ease}
.hd-nav-world-label{position:relative;padding-bottom:5px;transition:color .16s ease}
.hd-nav-world-label:after{content:"";position:absolute;left:0;right:100%;bottom:0;height:2px;background:var(--hd-petrol);transition:right .18s ease}
.hd-nav-item:hover>a,.hd-nav-item:focus-within>a{color:var(--hd-petrol)!important}
.hd-nav-item:hover .hd-nav-world-label:after,.hd-nav-item:focus-within .hd-nav-world-label:after{right:0}
.hd-nav-item:hover .hd-sub-toggle-v150616 span:after,.hd-nav-item:focus-within .hd-sub-toggle-v150616 span:after{border-color:var(--hd-petrol)}
.hd-mega-single{width:360px!important;padding:17px 18px 14px!important}.hd-mega-single.is-two-col{width:500px!important}
.hd-mega-head{display:flex;align-items:center;gap:9px;padding:0 0 11px;margin-bottom:10px;border-bottom:1px solid var(--hd-line)}
.hd-mega-head-icon{display:grid;width:30px;height:30px;place-items:center;color:var(--hd-petrol)}.hd-mega-head-icon svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.hd-mega-head strong{font-size:15px}
.hd-mega-single ul{grid-template-columns:1fr!important;gap:2px!important}.hd-mega-single.is-two-col ul{grid-template-columns:repeat(2,minmax(0,1fr))!important;column-gap:18px!important}
.hd-mega-single li a{display:block;padding:7px 7px;border-radius:2px;font-size:12px!important;transition:background .15s ease,color .15s ease}.hd-mega-single li a:hover,.hd-mega-single li a:focus-visible{background:#f1f8f7;color:var(--hd-petrol)!important;outline:0}
.hd-mega-all{display:flex;margin-top:11px;padding:11px 7px 2px;border-top:1px solid var(--hd-line);align-items:center;justify-content:space-between;color:var(--hd-petrol)!important;font-size:11px;font-weight:750}
.hd-world-card img{height:auto!important;aspect-ratio:1400/620!important;object-fit:cover!important;image-rendering:auto!important}
.hd-world-card:hover strong,.hd-world-card:focus-visible strong{color:var(--hd-petrol)}
.hd-topic-grid-taxonomy{grid-template-columns:repeat(5,minmax(0,1fr))}.hd-topic-grid-taxonomy a{display:grid!important;grid-template-columns:42px minmax(0,1fr) 18px!important;min-height:68px!important;align-items:center}.hd-topic-icon{display:grid;width:36px;height:36px;margin-left:9px;place-items:center;border-radius:50%;background:#eef7f6;color:var(--hd-petrol)}.hd-topic-icon svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.hd-topic-grid-taxonomy strong{padding:7px 8px!important;font-size:11px!important;line-height:1.18}.hd-topic-grid-taxonomy a>b{color:var(--hd-petrol);font-size:15px}
@media(max-width:1180px){.hd-topic-grid-taxonomy{grid-template-columns:repeat(3,minmax(0,1fr))}.hd-mega-single.is-two-col{width:450px!important}}
/* 1.50.610: tablet header collapses before the eight-world navigation can overflow. */
@media(max-width:1080px) and (min-width:761px){.hd-head-v150616{grid-template-columns:228px minmax(0,1fr) 42px;width:min(calc(100% - 36px),var(--hd-content));min-height:96px;gap:14px}.hd-logo-v150616{width:218px;height:88px}.hd-logo-v150616 img{width:210px;max-height:86px}.hd-head-center-v150616{display:flex;align-items:center}.hd-search-v150616{width:100%;margin:0}.hd-menu-toggle-v150616{display:block}.hd-nav-v150616{position:absolute;z-index:10010;top:100%;left:18px;right:18px;display:none;margin:0;padding:7px 16px 13px;border:1px solid var(--hd-line);border-top:0;background:#fff;box-shadow:0 18px 42px rgba(42,55,61,.12)}.hd-header-v150616.is-open .hd-nav-v150616{display:block}.hd-nav-v150616>ul{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:0 18px}.hd-nav-item{display:grid;grid-template-columns:minmax(0,1fr) 34px;border-bottom:1px solid var(--hd-line)}.hd-nav-item>a{padding:11px 4px;font-size:12.5px}.hd-sub-toggle-v150616{width:34px;height:42px;margin:0}.hd-mega{position:static;grid-column:1/-1;width:100%!important;padding:0 4px 12px!important;border:0;border-radius:0;box-shadow:none;transform:none}.has-mega:hover>.hd-mega,.has-mega:focus-within>.hd-mega{display:none}.has-mega.is-sub-open>.hd-mega{display:block}.hd-mega-single.is-two-col ul{grid-template-columns:repeat(2,minmax(0,1fr))!important}.hd-nav-world-label:after{display:none}}
@media(max-width:760px){.hd-nav-world-label:after{display:none}.hd-mega-single,.hd-mega-single.is-two-col{width:100%!important}.hd-mega-head{padding:8px 8px 9px}.hd-mega-single.is-two-col ul{grid-template-columns:1fr!important}.hd-mega-all{padding:10px 8px 2px}.hd-world-card img{aspect-ratio:1.9/1!important}.hd-topic-grid-taxonomy{grid-template-columns:1fr!important}.hd-topic-grid-taxonomy a{grid-template-columns:42px minmax(0,1fr) 18px!important}}


/* 1.50.610: live-readback completion — stronger navigation, centered topbar, warm header, unique editorial art. */
.hd-topbar-v150616{height:31px;background:#f0ede6!important;border-bottom:1px solid rgba(63,71,75,.10)!important}
.hd-topbar-v150616>div{height:31px!important;justify-content:center!important;text-align:center!important;font-size:13px!important;font-weight:680!important;letter-spacing:.018em;color:#384247!important}
.hd-header-v150616{background:#f8f6f1!important;border-bottom:1px solid rgba(63,71,75,.14)!important;box-shadow:0 5px 16px rgba(42,55,61,.045)!important}
.hd-search-v150616{background:#fff!important}
.hd-mega-single li a{padding:9px 8px!important;font-size:14px!important;font-weight:680!important;line-height:1.25!important;color:#313b40!important}
.hd-mega-head strong{font-size:16px!important;font-weight:760!important}.hd-mega-all{font-size:12.5px!important;font-weight:780!important}
.hd-editorial-card{overflow:hidden;background:#fff!important}.hd-editorial-card:before{display:none!important}.hd-editorial-copy{display:grid!important;grid-template-columns:88px minmax(0,1fr)!important;gap:15px!important;align-items:center!important;background:linear-gradient(105deg,#f3fbfa 0%,#fff 62%)!important}
.hd-editorial-card.is-magazine .hd-editorial-copy{background:linear-gradient(105deg,#fbf6ee 0%,#fff 62%)!important}.hd-editorial-card.is-guide .hd-editorial-copy{background:linear-gradient(105deg,#f6f3eb 0%,#fff 62%)!important}
.hd-editorial-icon{display:grid;width:72px;height:72px;place-items:center;border:1px solid rgba(47,150,157,.20);border-radius:50%;background:#fff;color:var(--hd-petrol)}.hd-editorial-icon svg{width:48px;height:48px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}.hd-editorial-text{min-width:0}.hd-editorial-text h2{margin-top:0!important}
.hd-world-image{filter:contrast(1.035) saturate(1.025)!important}
@media(max-width:760px){.hd-editorial-copy{grid-template-columns:68px minmax(0,1fr)!important;gap:11px!important}.hd-editorial-icon{width:58px;height:58px}.hd-editorial-icon svg{width:38px;height:38px}.hd-mega-single li a{font-size:14px!important;font-weight:680!important;padding:9px 8px!important}}


/* 1.50.610: live-readback fix — clearer header separation, admin affiliate previews,
   exactly one public sellable ad slot, text-free responsive hero. */
:root{--hd-cream:#fcfbf8}
.hd-header-v150616{background:#f3efe7!important;border-bottom:1px solid rgba(63,71,75,.20)!important;box-shadow:0 7px 22px rgba(42,55,61,.075)!important}
.hd-topbar-v150616{background:#e9e2d7!important;border-bottom:1px solid rgba(63,71,75,.13)!important}
.hd-head-v150616{background:#f3efe7!important}
.hd-search-v150616{background:#fff!important;border-color:rgba(63,71,75,.17)!important}
.hd-hero-image{background:#efe9df}.hd-hero-img{object-position:center 43%!important}
.hd-world-image-original{filter:none!important}
.hd-world-image-fallback{filter:contrast(1.02) saturate(1.015)!important}
.hd-admin-preview-note{display:block;margin-top:5px;color:#6d777b;font-size:10px;font-weight:650}
.hd-product-slot.is-preview{height:92px;border:1px dashed rgba(15,143,149,.46);background:#f8fcfb}
.hd-affiliate-preview{display:flex!important;width:100%!important;height:100%!important;min-height:70px!important;padding:10px 14px!important;flex-direction:column!important;align-items:flex-start!important;justify-content:center!important;background:linear-gradient(110deg,#f3fbfa,#fff)!important;color:#34464d!important}
.hd-affiliate-preview small{color:var(--hd-petrol-deep);font-size:9px;font-weight:800;letter-spacing:.05em;text-transform:uppercase}
.hd-affiliate-preview strong{margin:2px 0!important;color:#17313c!important;font-size:13px!important;font-weight:820!important}.hd-affiliate-preview span{font-size:10px!important;color:#6a767b!important}
.hd-affiliate-banner.is-preview{height:78px;border:1px dashed rgba(15,143,149,.46);background:#f8fcfb}.hd-affiliate-banner.is-preview>div{height:100%!important}.hd-affiliate-banner.is-preview .hd-affiliate-preview{padding-left:128px!important}
.hd-rental-link.is-available{display:grid!important;grid-template-columns:150px minmax(0,1fr)!important;min-height:112px!important;border:1px solid rgba(15,143,149,.25)!important;background:linear-gradient(105deg,#eef8f7 0%,#fff 66%)!important;color:#17313c!important}
.hd-rental-mark{display:grid;place-items:center;background:#e1f2f0;color:var(--hd-petrol-deep);font-size:12px;font-weight:850;letter-spacing:.08em;text-transform:uppercase}
.hd-rental-copy{display:flex!important;padding:16px 24px!important;flex-direction:column!important;justify-content:center!important}.hd-rental-copy small{color:#7a6c59!important;font-size:9px!important;font-weight:800!important;letter-spacing:.07em!important;text-transform:uppercase!important}.hd-rental-copy strong{margin:3px 0 4px!important;font-size:20px!important}.hd-rental-copy em{color:#69747a;font-size:11px;font-style:normal}.hd-rental-copy b{margin-top:7px;color:var(--hd-petrol)!important;font-size:11px!important}
@media(max-width:980px){.hd-hero-img{object-position:center 42%!important}}
@media(max-width:760px){.hd-header-v150616{background:#f3efe7!important}.hd-nav-v150616{background:#f8f5ef!important}.hd-affiliate-banner.is-preview .hd-affiliate-preview{padding-left:105px!important}.hd-rental-link.is-available{grid-template-columns:1fr!important}.hd-rental-mark{min-height:40px}.hd-rental-copy{padding:14px 16px!important}}



/* 1.50.610: final homepage live-readback corrections. */
body.pftk-design-profile-hobby-depot{background:#fff!important}
.hd-header-v150616{background:#f5f1e9!important;box-shadow:0 4px 16px rgba(42,55,61,.035)}
.hd-topbar-v150616{background:#eee9df!important}
.hd-topbar-v150616>div{justify-content:center!important}
.hd-home-v150616-main{background:#fff}
.hd-hero-picture{display:block;width:100%;height:100%}
.hd-hero-image{background:#f5f1e9}
.hd-hero-img{object-fit:cover!important;object-position:center center!important}
.hd-world-card{overflow:hidden}
.hd-world-card img{object-fit:cover}
.hd-world-tiere img{object-position:center 70%}
.hd-affiliate-banner{min-height:90px;height:90px;background:#fff}
.hd-affiliate-banner>div,.hd-affiliate-banner>div>.ppar-affiliate-slot,.hd-affiliate-banner .ppar-affiliate-content,.hd-affiliate-banner .ppar-banner-link,.hd-affiliate-banner img{height:90px!important;max-height:90px!important}
.hd-affiliate-banner img{object-fit:cover!important}
.hd-affiliate-preview{display:flex;width:100%;height:100%;min-height:72px;align-items:center;justify-content:center;gap:10px;flex-wrap:wrap;padding:14px 20px;border:1px dashed rgba(15,143,149,.4);background:#f7fbfb;color:#335158;text-align:center}
.hd-affiliate-preview small{width:100%;color:#76858a;font-size:9px;text-transform:uppercase;letter-spacing:.08em}.hd-affiliate-preview strong{font-size:15px}.hd-affiliate-preview span{font-size:12px}
.hd-product-slot.is-preview{min-height:118px;height:auto}
.hd-product-slot.is-preview .hd-affiliate-preview{min-height:118px}
.hd-rental-link.is-available{grid-template-columns:165px minmax(0,1fr);min-height:96px;background:#fbf8f2}
.hd-rental-link.is-available .hd-rental-mark{display:flex;align-items:center;justify-content:center;padding:0 18px;border-right:1px solid var(--hd-line);color:var(--hd-petrol);font-size:13px;font-weight:800;text-transform:uppercase;letter-spacing:.08em}
.hd-rental-link.is-available .hd-rental-copy{padding:14px 22px}.hd-rental-link.is-available em{margin:2px 0 6px;color:#66747a;font-size:11px;font-style:normal}.hd-rental-link.is-available strong{margin:1px 0 2px}
@media(max-width:1100px){.hd-hero-v150616{grid-template-columns:1fr!important;min-height:0!important}.hd-hero-copy{order:1;min-height:0!important;padding:28px 30px 30px!important}.hd-hero-image{order:2;min-height:0!important}.hd-hero-picture{height:auto}.hd-hero-img{display:block;width:100%!important;height:auto!important;min-height:0!important;aspect-ratio:2/1;object-fit:cover!important;object-position:center center!important}}
@media(max-width:760px){.hd-nav-v150616{background:#f5f1e9!important}.hd-hero-v150616{width:calc(100% - 24px)!important;margin:12px auto 0!important}.hd-hero-copy{padding:22px 18px 23px!important}.hd-hero-copy h1{font-size:clamp(34px,10vw,44px)!important}.hd-hero-img{aspect-ratio:2/1!important}.hd-affiliate-banner{height:74px;min-height:74px}.hd-affiliate-banner>div,.hd-affiliate-banner>div>.ppar-affiliate-slot,.hd-affiliate-banner .ppar-affiliate-content,.hd-affiliate-banner .ppar-banner-link,.hd-affiliate-banner img{height:74px!important;max-height:74px!important}.hd-rental-link.is-available{grid-template-columns:1fr;min-height:0}.hd-rental-link.is-available .hd-rental-mark{min-height:38px;border-right:0;border-bottom:1px solid var(--hd-line)}.hd-rental-link.is-available .hd-rental-copy{padding:13px 15px}}


/* 1.50.616: cache-safe final homepage/header polish. */
.hd-head-center-v150616{grid-template-rows:66px 44px}
.hd-nav-v150616{transform:none!important;padding-top:10px!important}
.hd-hero-v150616{margin:24px auto 0!important;border:1px solid rgba(63,71,75,.16)!important;border-radius:4px!important;background:#fff!important}
.hd-hero-copy{background:#fff!important}
.hd-world-image-controlled{filter:none!important}
@media(max-width:1080px){.hd-nav-v150616{padding-top:0!important}}
@media(max-width:760px){.hd-hero-v150616{margin:14px auto 0!important}}


/* 1.50.616: approved homepage polish + reusable portal-level layout. */
.hd-editorial-card,.hd-editorial-copy,.hd-editorial-card.is-magazine .hd-editorial-copy,.hd-editorial-card.is-guide .hd-editorial-copy{background:#f5f1e9!important;background-image:none!important}
.hd-head-center-v150616{grid-template-rows:58px 52px!important}
.hd-nav-v150616{align-self:end!important;padding-top:0!important;transform:translateY(14px)!important}
@media(max-width:1080px){.hd-nav-v150616{transform:none!important}}
.hd-breadcrumb-wrap{width:min(calc(100% - 72px),var(--hd-content));margin:18px auto 0}.hd-breadcrumb{display:flex;flex-wrap:wrap;align-items:center;gap:7px;color:#778085;font-size:12px;line-height:1.4}.hd-breadcrumb a{text-decoration:none!important;color:#667178!important}.hd-breadcrumb a:hover{color:var(--hd-petrol)!important}.hd-breadcrumb b{color:#a0a7aa;font-weight:500}.hd-breadcrumb span[aria-current=page]{color:#39464c;font-weight:650}
.hd-content-v150616{width:100%;padding:0 0 72px;background:#fff}.hd-content-v150616 a{text-decoration:none}.hd-page-intro,.hd-page-hero,.hd-portal-section,.hd-rental{width:min(calc(100% - 72px),var(--hd-content));margin-left:auto;margin-right:auto}.hd-page-intro{margin-top:5px;padding:28px 34px 30px;border:1px solid var(--hd-line);background:#fff}.hd-page-intro-copy{max-width:920px}.hd-page-kicker,.hd-portal-section>header>span{display:block;margin-bottom:8px;color:var(--hd-petrol-deep);font-size:10px;font-weight:820;letter-spacing:.15em;text-transform:uppercase}.hd-page-intro h1,.hd-page-hero h1{display:flex;align-items:center;gap:12px;margin:0;color:#17313c!important;font-size:clamp(38px,4.3vw,60px)!important;font-weight:800!important;letter-spacing:-.035em;line-height:1}.hd-page-title-icon{display:inline-grid;flex:0 0 44px;width:44px;height:44px;place-items:center;border-radius:50%;background:#edf7f6;color:var(--hd-petrol)}.hd-page-title-icon svg{width:25px;height:25px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.hd-page-intro p,.hd-page-hero p{max-width:820px;margin:14px 0 0;color:#4d5b61;font-size:16px;line-height:1.58}
.hd-page-hero{display:grid;grid-template-columns:minmax(0,42%) minmax(0,58%);min-height:320px;margin-top:5px;border:1px solid var(--hd-line);background:#fff;overflow:hidden}.hd-page-hero-copy{display:flex;padding:34px 40px;flex-direction:column;justify-content:center}.hd-page-hero-copy>a{display:inline-flex;align-items:center;align-self:flex-start;min-height:40px;margin-top:18px;padding:0 18px;border-radius:4px;background:var(--hd-petrol);color:#fff!important;font-size:12px;font-weight:800}.hd-page-hero figure{margin:0;min-height:320px}.hd-page-hero figure img{display:block;width:100%;height:100%;min-height:320px;object-fit:cover}
.hd-portal-section{margin-top:30px}.hd-portal-section>header{display:flex;margin-bottom:13px;flex-direction:column}.hd-portal-section>header h2{margin:0;color:#17313c!important;font-size:25px!important;font-weight:800!important;line-height:1.15}.hd-next-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.hd-next-card{display:grid;grid-template-columns:42px minmax(0,1fr) 18px;gap:12px;min-height:108px;padding:16px 16px;align-items:center;border:1px solid var(--hd-line);border-radius:4px;background:#fff}.hd-next-card:hover{border-color:rgba(15,143,149,.35);box-shadow:0 8px 22px rgba(42,55,61,.06)}.hd-next-icon{display:grid;width:40px;height:40px;place-items:center;border-radius:50%;background:#edf7f6;color:var(--hd-petrol)}.hd-next-icon svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.hd-next-card strong{display:block;color:#263b44;font-size:15px}.hd-next-card small{display:block;margin-top:4px;color:#6a7479;font-size:11px;line-height:1.35}.hd-next-card>b{color:var(--hd-petrol);font-size:18px}
.hd-context-banner-inner{position:relative;min-height:90px;border:1px solid var(--hd-line);background:#fff;overflow:hidden}.hd-context-banner-inner>.hd-ad-label{position:absolute;z-index:2;top:5px;left:7px;padding:2px 5px;background:rgba(255,255,255,.9);color:#6b7478;font-size:8px;font-weight:800;letter-spacing:.07em;text-transform:uppercase}.hd-context-banner-inner>.ppar-affiliate-slot,.hd-context-banner-inner img{width:100%;max-height:100px}.hd-context-banner.is-preview .hd-context-banner-inner{border-style:dashed;background:#f7fbfb}
.hd-context-product-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.hd-context-product{min-width:0;border:1px solid var(--hd-line);background:#fff}.hd-context-product .hd-affiliate-preview{min-height:120px}.hd-post-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.hd-post-card{overflow:hidden;border:1px solid var(--hd-line);border-radius:4px;background:#fff}.hd-post-image{display:block;aspect-ratio:16/8.5;overflow:hidden}.hd-post-image img{display:block;width:100%;height:100%;object-fit:cover}.hd-post-card>div{padding:14px 15px 16px}.hd-post-card h3{margin:0 0 7px;color:#213943;font-size:16px;line-height:1.22}.hd-post-card p{margin:0 0 11px;color:#68747a;font-size:12px;line-height:1.45}.hd-post-more{color:var(--hd-petrol)!important;font-size:11px;font-weight:800}.hd-empty-admin{padding:18px;border:1px dashed rgba(15,143,149,.42);background:#f7fbfb;color:#66747a;font-size:12px}
.hd-content-v150616 .hd-rental{margin-top:30px}.hd-content-v150616 .hd-rental-link.is-available{background:#f5f1e9!important}.hd-universal-top-v150616{padding-bottom:12px;background:#fff}.hd-universal-top-v150616+.site-content,.hd-universal-top-v150616+#content{padding-top:0!important}
@media(max-width:1000px){.hd-page-hero{grid-template-columns:1fr}.hd-page-hero figure{min-height:0}.hd-page-hero figure img{min-height:0;aspect-ratio:1400/620}.hd-next-grid,.hd-post-grid,.hd-context-product-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:760px){.hd-breadcrumb-wrap,.hd-page-intro,.hd-page-hero,.hd-portal-section,.hd-rental{width:calc(100% - 24px)}.hd-breadcrumb-wrap{margin-top:12px}.hd-page-intro{padding:22px 18px}.hd-page-hero-copy{padding:24px 18px}.hd-page-intro h1,.hd-page-hero h1{font-size:clamp(34px,10vw,45px)!important}.hd-page-title-icon{width:38px;height:38px;flex-basis:38px}.hd-next-grid,.hd-post-grid,.hd-context-product-grid{grid-template-columns:1fr}.hd-next-card{min-height:92px}.hd-portal-section{margin-top:24px}}

/* 1.50.616: darker service bar, aligned navigation, Pferdeatelier-style editorial text, balanced grids and native monetisation. */
.hd-topbar-v150616{background:var(--hd-dark2)!important;border-bottom-color:rgba(255,255,255,.08)!important;color:#fff!important}.hd-topbar-v150616 span{color:#fff!important;font-weight:650;letter-spacing:.01em}.hd-head-center-v150616{grid-template-rows:56px 64px!important}.hd-nav-v150616{align-self:end!important;transform:translateY(8px)!important}.hd-header-v150616{box-shadow:0 4px 16px rgba(42,55,61,.04)!important}
.hd-category-copy{width:min(calc(100% - 72px),900px);margin:18px auto 0}.hd-category-copy-inner{color:#4d5b61;font-size:15px;line-height:1.72}.hd-category-copy p{margin:0}.hd-category-more{margin:10px 0 13px;padding:0;border:0;text-align:center}.hd-category-more>summary{display:inline-flex;align-items:center;gap:7px;cursor:pointer;list-style:none;color:var(--hd-dark2);font-size:13px;font-weight:800}.hd-category-more>summary::-webkit-details-marker{display:none}.hd-category-more>summary:before{content:"";display:inline-block;width:7px;height:7px;border-right:1.5px solid currentColor;border-bottom:1.5px solid currentColor;transform:rotate(45deg) translateY(-1px);transition:transform .18s ease}.hd-category-more[open]>summary:before{transform:rotate(225deg) translate(-1px,-1px)}.hd-category-more>summary:hover{color:var(--hd-petrol)}.hd-category-more>div{padding-top:10px;text-align:left}.hd-category-find{margin-top:18px;padding:14px 16px;border-left:3px solid var(--hd-petrol);background:rgba(245,241,233,.64)}.hd-category-find strong{display:block;margin-bottom:5px;color:var(--hd-dark2);font-size:13px}.hd-category-find p{font-size:14px;line-height:1.62}
.hd-next-grid{grid-template-columns:repeat(6,minmax(0,1fr))!important}.hd-next-card{grid-column:span 2}.hd-next-grid.hd-next-rem-2>.hd-next-card:nth-last-child(-n+2){grid-column:span 3}.hd-next-grid.hd-next-rem-1>.hd-next-card:last-child{grid-column:1/-1}.hd-next-grid.hd-next-rem-1>.hd-next-card:last-child span:nth-child(2){max-width:760px}.hd-next-grid.hd-next-rem-1>.hd-next-card:last-child small{max-width:760px}
.hd-native-partner{margin-top:22px!important}.hd-native-partner-label{display:inline-block;margin:0 0 7px 2px;color:#8a6a43;font-size:9px;font-weight:800;letter-spacing:.09em;text-transform:uppercase}.hd-context-banner-inner{border:1px solid rgba(63,71,75,.11)!important;border-radius:7px!important;background:#fff!important;box-shadow:0 7px 22px rgba(42,55,61,.045)!important}.hd-context-banner-inner>.hd-ad-label{display:none!important}.hd-context-banner.is-preview .hd-context-banner-inner{border-style:dashed!important;box-shadow:none!important}.hd-native-products{padding:20px 22px 22px;border:1px solid rgba(63,71,75,.10);border-radius:8px;background:#fbfaf7}.hd-native-products>header{margin-bottom:11px!important}.hd-native-products>header>span{color:#8a6a43!important}.hd-context-product{overflow:hidden;border-radius:7px!important;box-shadow:0 7px 22px rgba(42,55,61,.045)}
.hd-content-v150616 .hd-rental{margin-top:24px!important}.hd-rental-link.is-available{display:grid!important;grid-template-columns:minmax(0,46%) minmax(0,54%)!important;min-height:170px!important;border:1px solid rgba(63,71,75,.11)!important;border-radius:8px!important;background:linear-gradient(105deg,#f7ead8 0%,#fff 72%)!important;box-shadow:0 10px 30px rgba(42,55,61,.07)!important}.hd-rental-link.is-available .hd-rental-copy{padding:24px 30px!important;justify-content:center!important}.hd-rental-link.is-available .hd-rental-copy small{color:#8a6a43!important;font-size:9px!important;font-weight:850!important;letter-spacing:.1em!important;text-transform:uppercase!important}.hd-rental-link.is-available .hd-rental-copy strong{margin:6px 0 7px!important;color:#17313c!important;font-size:clamp(24px,2.2vw,34px)!important;line-height:1.05!important}.hd-rental-link.is-available .hd-rental-copy em{max-width:620px;color:#54636a!important;font-size:12.5px!important;line-height:1.5!important}.hd-rental-link.is-available .hd-rental-copy b{display:inline-flex;align-self:flex-start;margin-top:14px;padding:10px 14px;border-radius:5px;background:var(--hd-dark2);color:#fff!important;font-size:11px!important}.hd-rental-visual{display:grid!important;min-width:0;padding:0!important;grid-template-columns:repeat(2,1fr);grid-template-rows:repeat(2,85px);gap:2px;background:#fff;overflow:hidden}.hd-rental-visual img{display:block;width:100%;height:85px;object-fit:cover}.hd-rental-link.is-available:hover{transform:translateY(-1px);box-shadow:0 14px 36px rgba(42,55,61,.10)!important}
@media(max-width:1080px){.hd-nav-v150616{transform:none!important}.hd-head-center-v150616{grid-template-rows:66px 44px!important}.hd-next-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}.hd-next-card,.hd-next-grid.hd-next-rem-2>.hd-next-card:nth-last-child(-n+2),.hd-next-grid.hd-next-rem-1>.hd-next-card:last-child{grid-column:auto!important}.hd-rental-link.is-available{grid-template-columns:1fr!important}.hd-rental-visual{grid-template-columns:repeat(4,1fr);grid-template-rows:94px}.hd-rental-visual img{height:94px}}
@media(max-width:760px){.hd-category-copy{width:calc(100% - 24px);margin-top:14px}.hd-category-copy-inner{font-size:14px}.hd-category-find{padding:12px 13px}.hd-native-products{padding:16px 14px}.hd-rental-link.is-available .hd-rental-copy{padding:20px 18px!important}.hd-rental-visual{grid-template-columns:repeat(2,1fr);grid-template-rows:80px 80px}.hd-rental-visual img{height:80px}}

/* 1.50.616: visual hub thumbnails + fail-safe responsive navigation. */
.hd-next-card.has-photo{grid-template-columns:118px minmax(0,1fr) 22px!important;min-height:108px;padding:0!important;overflow:hidden}.hd-next-photo{display:block;width:118px;height:100%;min-height:108px;overflow:hidden;background:#f5f1e9}.hd-next-photo img{display:block;width:100%;height:100%;min-height:108px;object-fit:cover}.hd-next-card.has-photo .hd-next-copy{display:block;min-width:0;padding:13px 8px 13px 0}.hd-next-card.has-photo>b{margin-right:12px}.hd-next-grid.hd-next-rem-1>.hd-next-card.has-photo:last-child{grid-template-columns:210px minmax(0,1fr) 28px!important}.hd-next-grid.hd-next-rem-1>.hd-next-card.has-photo:last-child .hd-next-photo{width:210px}.hd-next-grid.hd-next-rem-1>.hd-next-card.has-photo:last-child .hd-next-copy{max-width:820px}
@media(max-width:1560px) and (min-width:761px){
  .hd-head-v150616{grid-template-columns:248px minmax(0,1fr) 44px!important;width:min(calc(100% - 36px),var(--hd-content))!important;min-height:102px!important;gap:16px!important}
  .hd-logo-v150616{width:238px!important;height:92px!important}.hd-logo-v150616 img{width:228px!important;max-height:90px!important}
  .hd-head-center-v150616{display:flex!important;align-items:center!important;align-self:stretch!important;grid-template-rows:none!important}
  .hd-search-v150616{width:100%!important;margin:0!important}
  .hd-menu-toggle-v150616{display:block!important;align-self:center!important}
  .hd-nav-v150616{position:absolute!important;z-index:10020!important;top:100%!important;left:18px!important;right:18px!important;display:none!important;width:auto!important;margin:0!important;padding:8px 16px 14px!important;border:1px solid var(--hd-line)!important;border-top:0!important;background:#f5f1e9!important;box-shadow:0 18px 42px rgba(42,55,61,.14)!important;transform:none!important;overflow:visible!important}
  .hd-header-v150616.is-open .hd-nav-v150616{display:block!important}
  .hd-nav-v150616>ul{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:0 18px!important;width:100%!important}
  .hd-nav-item{display:grid!important;grid-template-columns:minmax(0,1fr) 34px!important;border-bottom:1px solid var(--hd-line)!important;white-space:normal!important}
  .hd-nav-item>a{min-width:0!important;padding:11px 4px!important;font-size:12.5px!important}
  .hd-nav-world-label{overflow:visible!important;text-overflow:clip!important;white-space:normal!important}
  .hd-sub-toggle-v150616{width:34px!important;height:42px!important;margin:0!important}
  .hd-mega{position:static!important;grid-column:1/-1!important;width:100%!important;padding:0 4px 12px!important;border:0!important;border-radius:0!important;box-shadow:none!important;transform:none!important}
  .has-mega:hover>.hd-mega,.has-mega:focus-within>.hd-mega{display:none!important}.has-mega.is-sub-open>.hd-mega{display:block!important}
}
@media(max-width:980px) and (min-width:761px){.hd-nav-v150616>ul{grid-template-columns:repeat(2,minmax(0,1fr))!important}.hd-head-v150616{grid-template-columns:220px minmax(0,1fr) 44px!important}.hd-logo-v150616{width:210px!important}.hd-logo-v150616 img{width:202px!important}}
@media(max-width:1000px){.hd-next-card.has-photo{grid-template-columns:104px minmax(0,1fr) 20px!important}.hd-next-photo{width:104px;min-height:100px}.hd-next-photo img{min-height:100px}.hd-next-grid.hd-next-rem-1>.hd-next-card.has-photo:last-child{grid-template-columns:104px minmax(0,1fr) 20px!important}.hd-next-grid.hd-next-rem-1>.hd-next-card.has-photo:last-child .hd-next-photo{width:104px}}
@media(max-width:760px){.hd-next-card.has-photo{grid-template-columns:96px minmax(0,1fr) 18px!important;min-height:92px}.hd-next-photo{width:96px;min-height:92px}.hd-next-photo img{min-height:92px}.hd-next-card.has-photo .hd-next-copy{padding:10px 6px 10px 0}.hd-next-card.has-photo>b{margin-right:8px}}


/* 1.50.616: correction pass after live readback. Typography intentionally unchanged from 1.50.614/615. */
.hd-nav-v150616{transform:translateY(8px)!important}
.hd-hub1-fold{width:min(calc(100% - 72px),900px);margin:12px auto 0}.hd-hub1-fold>details{border:1px solid rgba(63,71,75,.10);border-radius:5px;background:#fbfaf7}.hd-hub1-fold summary{display:flex;min-height:42px;padding:0 15px;align-items:center;justify-content:center;cursor:pointer;list-style:none;color:#263b44;font-size:13px;font-weight:800}.hd-hub1-fold summary::-webkit-details-marker{display:none}.hd-hub1-fold summary:after{content:"";width:7px;height:7px;margin-left:9px;border-right:1.5px solid currentColor;border-bottom:1.5px solid currentColor;transform:rotate(45deg) translateY(-2px);transition:transform .16s ease}.hd-hub1-fold details[open] summary:after{transform:rotate(225deg) translate(-1px,-1px)}.hd-hub1-fold-body{padding:0 18px 18px;color:#4d5b61;font-size:15px;line-height:1.68}.hd-hub1-fold-body>p{margin:0}.hd-hub1-find{margin-top:16px;padding:12px 14px;border-left:3px solid var(--hd-petrol);background:#f5f1e9}.hd-hub1-find strong{display:block;margin-bottom:4px;color:#263b44;font-size:13px}.hd-hub1-find p{margin:0;font-size:14px;line-height:1.55}
.hd-next-card.has-photo{grid-template-columns:128px minmax(0,1fr) 22px!important;min-height:112px}.hd-next-photo{width:128px;min-height:112px}.hd-next-photo img{min-height:112px;object-position:center center!important}
.hd-rental-link.is-available{position:relative!important;display:block!important;min-height:230px!important;overflow:hidden!important;border-radius:8px!important;background:#22343c!important}.hd-rental-link.is-available .hd-rental-visual{position:absolute!important;inset:0!important;display:block!important;width:100%!important;height:100%!important;background-size:cover!important;background-position:center!important;background-repeat:no-repeat!important}.hd-rental-link.is-available .hd-rental-visual:after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,rgba(20,39,48,.18) 0%,rgba(20,39,48,.38) 42%,rgba(20,39,48,.12) 100%)}.hd-rental-link.is-available .hd-rental-visual img{display:block!important;width:100%!important;height:100%!important;object-fit:cover!important}.hd-rental-link.is-available .hd-rental-copy{position:relative!important;z-index:2!important;display:flex!important;min-height:230px!important;padding:28px 38px!important;flex-direction:column!important;align-items:flex-start!important;justify-content:center!important}.hd-rental-link.is-available .hd-rental-copy small{padding:4px 7px;border-radius:3px;background:rgba(255,255,255,.90)!important;color:#6b7478!important}.hd-rental-link.is-available .hd-rental-copy strong{position:relative!important;isolation:isolate;margin:12px 0 8px!important;padding:7px 16px 9px!important;color:#16323e!important;font-size:clamp(28px,3vw,42px)!important;line-height:1.03!important}.hd-rental-link.is-available .hd-rental-copy strong:before{content:"";position:absolute;z-index:-1;inset:-4px -22px -5px -18px;background:rgba(255,250,242,.95);clip-path:polygon(1% 20%,8% 9%,26% 14%,41% 3%,62% 13%,84% 6%,99% 20%,96% 78%,83% 91%,62% 85%,42% 97%,19% 86%,3% 92%);transform:rotate(-1.2deg);filter:drop-shadow(0 2px 1px rgba(0,0,0,.05))}.hd-rental-link.is-available .hd-rental-copy em{max-width:520px;padding:5px 8px;background:rgba(255,255,255,.88);color:#31444c!important;font-size:13px!important;font-style:normal!important}.hd-rental-link.is-available .hd-rental-copy b{margin-top:13px!important;background:#17313c!important}.hd-rental-link.is-available:hover .hd-rental-visual img{transform:scale(1.012);transition:transform .22s ease}
@media(max-width:1560px) and (min-width:761px){.hd-head-v150616{grid-template-columns:248px minmax(0,1fr) 44px!important;width:min(calc(100% - 36px),var(--hd-content))!important;min-height:102px!important;gap:16px!important}.hd-logo-v150616{width:238px!important;height:92px!important}.hd-logo-v150616 img{width:228px!important;max-height:90px!important}.hd-head-center-v150616{display:flex!important;align-items:center!important;align-self:stretch!important;grid-template-rows:none!important}.hd-search-v150616{width:100%!important;margin:0!important}.hd-menu-toggle-v150616{display:block!important;align-self:center!important}.hd-nav-v150616{position:absolute!important;z-index:10020!important;top:100%!important;left:18px!important;right:18px!important;display:none!important;width:auto!important;margin:0!important;padding:8px 16px 14px!important;border:1px solid var(--hd-line)!important;border-top:0!important;background:#f5f1e9!important;box-shadow:0 18px 42px rgba(42,55,61,.14)!important;transform:none!important;overflow:visible!important}.hd-header-v150616.is-open .hd-nav-v150616{display:block!important}.hd-nav-v150616>ul{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:0 18px!important;width:100%!important}.hd-nav-item{display:grid!important;grid-template-columns:minmax(0,1fr) 34px!important;border-bottom:1px solid var(--hd-line)!important;white-space:normal!important}.hd-nav-item>a{min-width:0!important;padding:11px 4px!important;font-size:12.5px!important}.hd-nav-world-label{overflow:visible!important;text-overflow:clip!important;white-space:normal!important}.hd-sub-toggle-v150616{width:34px!important;height:42px!important;margin:0!important}.hd-mega{position:static!important;grid-column:1/-1!important;width:100%!important;padding:0 4px 12px!important;border:0!important;border-radius:0!important;box-shadow:none!important;transform:none!important}.has-mega:hover>.hd-mega,.has-mega:focus-within>.hd-mega{display:none!important}.has-mega.is-sub-open>.hd-mega{display:block!important}}
@media(max-width:980px) and (min-width:761px){.hd-nav-v150616>ul{grid-template-columns:repeat(2,minmax(0,1fr))!important}.hd-head-v150616{grid-template-columns:220px minmax(0,1fr) 44px!important}.hd-logo-v150616{width:210px!important}.hd-logo-v150616 img{width:202px!important}}
@media(max-width:1000px){.hd-next-card.has-photo{grid-template-columns:108px minmax(0,1fr) 20px!important}.hd-next-photo{width:108px;min-height:100px}.hd-next-photo img{min-height:100px}.hd-rental-link.is-available,.hd-rental-link.is-available .hd-rental-copy{min-height:210px!important}.hd-rental-link.is-available .hd-rental-copy{padding:22px 22px!important}}
@media(max-width:760px){.hd-hub1-fold{width:calc(100% - 24px);margin-top:10px}.hd-hub1-fold-body{padding:0 14px 15px;font-size:14px}.hd-next-card.has-photo{grid-template-columns:98px minmax(0,1fr) 18px!important;min-height:94px}.hd-next-photo{width:98px;min-height:94px}.hd-next-photo img{min-height:94px}.hd-rental-link.is-available,.hd-rental-link.is-available .hd-rental-copy{min-height:250px!important}.hd-rental-link.is-available .hd-rental-copy{padding:20px 17px!important}.hd-rental-link.is-available .hd-rental-copy strong{font-size:30px!important;padding:6px 10px!important}.hd-rental-link.is-available .hd-rental-copy em{font-size:12px!important}}



/* 1.50.617: verified hub cleanup – visible nav, readable logo, paragraph rhythm, uniform landscape cards, integrated partner modules. */
@media(min-width:761px){
  .hd-head-v150616{display:grid!important;width:min(calc(100% - 56px),var(--hd-content))!important;min-height:154px!important;grid-template-columns:300px minmax(0,1fr)!important;grid-template-rows:92px auto!important;gap:0 26px!important;align-items:center!important}
  .hd-logo-v150616{grid-column:1!important;grid-row:1!important;width:286px!important;height:104px!important;align-self:center!important;overflow:visible!important}
  .hd-logo-v150616 img{width:278px!important;max-height:102px!important;height:auto!important}
  .hd-head-center-v150616{display:contents!important}
  .hd-search-v150616{grid-column:2!important;grid-row:1!important;width:min(100%,760px)!important;margin:auto!important;align-self:center!important}
  .hd-menu-toggle-v150616{display:none!important}
  .hd-nav-v150616{position:relative!important;z-index:10010!important;top:auto!important;left:auto!important;right:auto!important;grid-column:1/-1!important;grid-row:2!important;display:block!important;width:100%!important;margin:0!important;padding:0 0 12px!important;border:0!important;background:transparent!important;box-shadow:none!important;transform:none!important;overflow:visible!important}
  .hd-nav-v150616>ul{display:grid!important;grid-template-columns:repeat(8,minmax(0,1fr))!important;gap:6px 10px!important;width:100%!important;margin:0!important}
  .hd-nav-item{position:static!important;display:flex!important;min-width:0!important;justify-content:center!important;border:0!important;white-space:nowrap!important}
  .hd-nav-item>a{min-width:0!important;padding:9px 2px!important;font-size:14px!important;justify-content:center!important}
  .hd-nav-world-label{overflow:visible!important;text-overflow:clip!important;white-space:nowrap!important}
  .hd-sub-toggle-v150616{width:20px!important;height:38px!important;margin-left:0!important}
  .hd-mega{top:100%!important;left:0!important;right:0!important;width:100%!important;transform:none!important}
}
@media(max-width:1180px) and (min-width:761px){
  .hd-head-v150616{width:min(calc(100% - 36px),var(--hd-content))!important;min-height:190px!important;grid-template-columns:286px minmax(0,1fr)!important;grid-template-rows:96px auto!important;gap:0 18px!important}
  .hd-logo-v150616{width:278px!important;height:104px!important}.hd-logo-v150616 img{width:270px!important;max-height:102px!important}
  .hd-nav-v150616{padding-bottom:13px!important}
  .hd-nav-v150616>ul{grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:2px 12px!important}
  .hd-nav-item>a{padding:8px 3px!important;font-size:14px!important}
}
@media(max-width:900px) and (min-width:761px){
  .hd-head-v150616{grid-template-columns:260px minmax(0,1fr)!important}.hd-logo-v150616{width:252px!important}.hd-logo-v150616 img{width:246px!important}
}

.hd-hub1-fold,.hd-category-copy{width:min(calc(100% - 72px),var(--hd-content))!important;margin:18px auto 0!important}
.hd-hub1-fold>details,.hd-category-copy-inner{border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important}
.hd-hub1-fold summary,.hd-category-more>summary{display:flex!important;width:100%!important;min-height:42px!important;padding:0!important;align-items:center!important;justify-content:center!important;border-top:1px solid rgba(63,71,75,.10)!important;border-bottom:1px solid rgba(63,71,75,.10)!important;background:transparent!important;color:#263b44!important;font-size:13px!important;font-weight:800!important}
.hd-hub1-fold-body,.hd-category-more>div{max-width:980px!important;margin:0 auto!important;padding:20px 0 2px!important;color:#4d5b61!important;font-size:15px!important;line-height:1.72!important;background:transparent!important}
.hd-hub1-fold-body>p,.hd-category-copy-inner>p,.hd-category-more>div>p{margin:0 0 15px!important}
.hd-hub1-find,.hd-category-find{margin:20px 0 0!important;padding:0!important;border:0!important;background:transparent!important}
.hd-hub1-find strong,.hd-category-find strong{display:block!important;margin:0 0 7px!important;color:#263b44!important;font-size:14px!important}
.hd-hub1-find p,.hd-category-find p{margin:0 0 28px!important;font-size:15px!important;line-height:1.72!important}

.hd-next-grid{display:grid!important;grid-template-columns:repeat(6,minmax(0,1fr))!important;gap:14px!important;align-items:stretch!important}
.hd-next-card{grid-column:span 2!important;min-width:0!important}
.hd-next-card.hd-row-size-3{grid-column:span 2!important}.hd-next-card.hd-row-size-2{grid-column:span 3!important}.hd-next-card.hd-row-size-1{grid-column:1/-1!important}
.hd-next-card.has-photo{display:block!important;min-height:0!important;padding:0!important;overflow:hidden!important;border-radius:6px!important}
.hd-next-photo{display:block!important;width:100%!important;height:auto!important;min-height:0!important;aspect-ratio:600/320!important;overflow:hidden!important;background:#f5f1e9!important}
.hd-next-photo img{display:block!important;width:100%!important;height:100%!important;min-height:0!important;aspect-ratio:600/320!important;object-fit:cover!important;object-position:center!important}
.hd-next-card-body{display:grid!important;min-height:72px!important;padding:12px 13px!important;grid-template-columns:minmax(0,1fr) 22px!important;gap:10px!important;align-items:center!important}
.hd-next-card.has-photo .hd-next-copy{display:block!important;padding:0!important}.hd-next-card.has-photo>b{margin:0!important;align-self:center!important}
.hd-next-card strong{font-size:15px!important}.hd-next-card small{font-size:11px!important;line-height:1.35!important}

.hd-inline-partners{display:grid!important;gap:12px!important;margin-top:16px!important;padding-top:14px!important;border-top:1px solid rgba(63,71,75,.10)!important}
.hd-inline-banner{position:relative!important;min-height:76px!important;overflow:hidden!important;border:1px solid rgba(63,71,75,.10)!important;border-radius:6px!important;background:#fff!important}
.hd-inline-banner>span,.hd-inline-product-wrap>span{display:block!important;padding:7px 10px 0!important;color:#7a6c59!important;font-size:9px!important;font-weight:800!important;letter-spacing:.08em!important;text-transform:uppercase!important}
.hd-inline-banner>div{padding:5px 10px 10px!important}.hd-inline-banner.is-preview{background:#fbfaf7!important}
.hd-inline-product-wrap{padding:0 0 2px!important;background:transparent!important}
.hd-inline-product-grid{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:12px!important;padding:7px 0 0!important}
.hd-inline-product{min-width:0!important;overflow:hidden!important;border:1px solid rgba(63,71,75,.10)!important;border-radius:6px!important;background:#fff!important}
.hd-inline-product .hd-affiliate-preview,.hd-inline-banner .hd-affiliate-preview{min-height:78px!important;border:0!important;background:#fbfaf7!important}

.hd-content-v150616 .hd-rental{margin-top:20px!important}
.hd-rental-link.is-available{min-height:176px!important;border:0!important;border-radius:7px!important;background:#f5f1e9!important;box-shadow:none!important}
.hd-rental-link.is-available .hd-rental-visual:after{background:linear-gradient(90deg,rgba(255,250,242,.46) 0%,rgba(255,250,242,.28) 44%,rgba(255,250,242,.06) 76%,rgba(255,250,242,0) 100%)!important}
.hd-rental-link.is-available .hd-rental-visual{filter:saturate(.88) brightness(1.06)!important}
.hd-rental-link.is-available .hd-rental-copy{min-height:176px!important;padding:22px 30px!important}
.hd-rental-link.is-available .hd-rental-copy small{background:rgba(255,255,255,.86)!important;color:#56656b!important}
.hd-rental-link.is-available .hd-rental-copy strong{max-width:700px!important;margin:9px 0 7px!important;padding:7px 15px 8px!important;color:#17313c!important;font-size:clamp(27px,2.6vw,38px)!important}
.hd-rental-link.is-available .hd-rental-copy strong:before{inset:-3px -18px -4px -15px!important;background:#fff8ec!important;clip-path:polygon(0 22%,8% 10%,24% 16%,42% 4%,61% 13%,80% 7%,100% 20%,96% 80%,79% 91%,60% 85%,40% 97%,18% 87%,2% 94%)!important}
.hd-rental-link.is-available .hd-rental-copy em{max-width:540px!important;padding:0!important;background:transparent!important;color:#31444c!important;font-size:13px!important;font-weight:600!important}
.hd-rental-link.is-available .hd-rental-copy b{margin-top:12px!important;padding:10px 14px!important;border:1px solid rgba(23,49,60,.20)!important;background:#fff!important;color:#17313c!important;box-shadow:0 3px 12px rgba(42,55,61,.10)!important}

@media(max-width:1100px) and (min-width:901px){
 .hd-next-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}.hd-next-card,.hd-next-card.hd-row-size-3,.hd-next-card.hd-row-size-2{grid-column:auto!important}.hd-next-grid.hd-next-odd>.hd-next-card:last-child{grid-column:1/-1!important}
 .hd-inline-product-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}.hd-inline-product-grid>.hd-inline-product:last-child:nth-child(odd){grid-column:1/-1!important}
}
@media(max-width:760px){
 .hd-logo-v150616{width:230px!important;height:92px!important}.hd-logo-v150616 img{width:222px!important;max-height:90px!important}
 .hd-hub1-fold,.hd-category-copy{width:calc(100% - 24px)!important;margin-top:12px!important}.hd-hub1-fold-body,.hd-category-more>div{padding-top:16px!important;font-size:14px!important}.hd-hub1-find p,.hd-category-find p{font-size:14px!important}
 .hd-next-grid{grid-template-columns:1fr!important}.hd-next-card,.hd-next-card.hd-row-size-3,.hd-next-card.hd-row-size-2,.hd-next-card.hd-row-size-1{grid-column:1!important}.hd-next-card-body{min-height:64px!important;padding:10px 11px!important}.hd-next-photo{aspect-ratio:16/8.5!important}.hd-next-photo img{aspect-ratio:16/8.5!important}
 .hd-inline-product-grid{grid-template-columns:1fr!important}.hd-inline-product-grid>.hd-inline-product{grid-column:1!important}
 .hd-rental-link.is-available,.hd-rental-link.is-available .hd-rental-copy{min-height:210px!important}.hd-rental-link.is-available .hd-rental-copy{padding:18px 16px!important}.hd-rental-link.is-available .hd-rental-copy strong{font-size:28px!important}.hd-rental-link.is-available .hd-rental-copy b{background:#fff!important;color:#17313c!important}
}


/* 1.50.618: live screenshot correction – natural logo ratio, lower nav, anchored flyouts, compact landscape cards, native partner integration. */
@media(min-width:761px){
  .hd-head-v150616{display:grid!important;width:min(calc(100% - 72px),var(--hd-content))!important;min-height:206px!important;padding:8px 0 10px!important;grid-template-columns:270px minmax(0,1fr)!important;grid-template-rows:148px 48px!important;gap:0 26px!important;align-items:stretch!important}
  .hd-logo-v150616{grid-column:1!important;grid-row:1!important;width:248px!important;height:auto!important;max-height:none!important;justify-self:start!important;align-self:center!important;margin:0!important;overflow:visible!important}
  .hd-logo-v150616 img{display:block!important;width:248px!important;height:auto!important;max-height:none!important;object-fit:contain!important;object-position:left center!important}
  .hd-head-center-v150616{display:contents!important}
  .hd-search-v150616{grid-column:2!important;grid-row:1!important;width:min(100%,760px)!important;margin:auto!important;align-self:center!important}
  .hd-menu-toggle-v150616{display:none!important}
  .hd-nav-v150616{position:relative!important;z-index:10010!important;grid-column:1/-1!important;grid-row:2!important;display:block!important;width:100%!important;margin:0!important;padding:7px 0 0!important;align-self:end!important;border:0!important;background:transparent!important;box-shadow:none!important;transform:none!important;overflow:visible!important}
  .hd-nav-v150616>ul{display:grid!important;grid-template-columns:repeat(8,minmax(0,1fr))!important;gap:6px 10px!important;width:100%!important;margin:0!important;align-items:end!important}
  .hd-nav-item{position:relative!important;display:flex!important;min-width:0!important;justify-content:flex-start!important;border:0!important;white-space:nowrap!important}
  .hd-nav-item>a{min-width:0!important;padding:9px 2px 8px!important;font-size:14px!important;justify-content:flex-start!important}
  .hd-nav-world-label{overflow:visible!important;text-overflow:clip!important;white-space:nowrap!important}
  .hd-sub-toggle-v150616{width:20px!important;height:38px!important;margin-left:0!important}
  .hd-mega,.hd-mega-single,.hd-mega-single.is-two-col{position:absolute!important;z-index:10030!important;top:calc(100% + 2px)!important;left:50%!important;right:auto!important;width:380px!important;max-width:min(520px,calc(100vw - 48px))!important;padding:17px 18px 14px!important;border:1px solid var(--hd-line)!important;border-radius:5px!important;background:#fff!important;box-shadow:0 18px 48px rgba(42,55,61,.15)!important;transform:translateX(-50%)!important}
  .hd-mega-single.is-two-col{width:500px!important}
  .hd-world-gestalten>.hd-mega,.hd-world-fertigen>.hd-mega{left:0!important;transform:none!important}
  .hd-world-bewegen>.hd-mega,.hd-world-sammeln>.hd-mega{left:auto!important;right:0!important;transform:none!important}
}
@media(max-width:1180px) and (min-width:761px){
  .hd-head-v150616{width:min(calc(100% - 36px),var(--hd-content))!important;min-height:226px!important;grid-template-columns:240px minmax(0,1fr)!important;grid-template-rows:132px 84px!important;gap:0 18px!important}
  .hd-logo-v150616,.hd-logo-v150616 img{width:224px!important;height:auto!important;max-height:none!important}
  .hd-nav-v150616{padding-top:6px!important}
  .hd-nav-v150616>ul{grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:1px 18px!important}
  .hd-nav-item>a{padding:7px 3px!important;font-size:14px!important}
  .hd-mega,.hd-mega-single,.hd-mega-single.is-two-col{width:min(500px,calc(100vw - 54px))!important;left:0!important;right:auto!important;transform:none!important}
  .hd-nav-item:nth-child(4n+3)>.hd-mega,.hd-nav-item:nth-child(4n+4)>.hd-mega{left:auto!important;right:0!important}
}
@media(max-width:900px) and (min-width:761px){
  .hd-head-v150616{grid-template-columns:222px minmax(0,1fr)!important}.hd-logo-v150616,.hd-logo-v150616 img{width:208px!important}
}
@media(max-width:760px){
  .hd-head-v150616{padding:8px 12px 11px!important;align-items:center!important}.hd-logo-v150616{justify-self:start!important;width:196px!important;height:auto!important;max-height:none!important}.hd-logo-v150616 img{display:block!important;width:196px!important;height:auto!important;max-height:none!important;object-fit:contain!important;object-position:left center!important}
}

.hd-hub1-fold{width:min(calc(100% - 72px),var(--hd-content))!important;margin:15px auto 0!important}
.hd-hub1-fold>details{border:0!important;background:transparent!important;box-shadow:none!important}
.hd-hub1-fold summary{min-height:40px!important;border-top:1px solid rgba(63,71,75,.10)!important;border-bottom:1px solid rgba(63,71,75,.10)!important;background:#fff!important}
.hd-hub1-fold-body{max-width:none!important;width:100%!important;padding:22px 0 0!important;background:#fff!important;color:#4d5b61!important;line-height:1.72!important}
.hd-hub1-fold-body>p{max-width:940px!important;margin:0 auto 15px!important}
.hd-hub1-find{max-width:940px!important;margin:23px auto 0!important;padding-top:14px!important;border-top:1px solid rgba(63,71,75,.10)!important;background:transparent!important}

.hd-next-grid{display:grid!important;grid-template-columns:repeat(6,minmax(0,1fr))!important;gap:12px!important;align-items:stretch!important}
.hd-next-card{grid-column:span 2!important;min-width:0!important;min-height:88px!important}
.hd-next-card.hd-row-size-3{grid-column:span 2!important}.hd-next-card.hd-row-size-2{grid-column:span 3!important}.hd-next-card.hd-row-size-1{grid-column:1/-1!important}
.hd-next-card.has-photo{display:grid!important;grid-template-columns:132px minmax(0,1fr)!important;min-height:88px!important;padding:0!important;overflow:hidden!important;border-radius:5px!important;background:#fff!important}
.hd-next-photo{display:block!important;width:132px!important;height:70px!important;min-height:70px!important;margin:9px 0 9px 9px!important;aspect-ratio:600/320!important;overflow:hidden!important;border-radius:3px!important;background:#f5f1e9!important;align-self:center!important}
.hd-next-photo img{display:block!important;width:100%!important;height:100%!important;min-height:0!important;aspect-ratio:600/320!important;object-fit:cover!important;object-position:center!important}
.hd-next-card-body{display:grid!important;min-height:88px!important;padding:10px 11px!important;grid-template-columns:minmax(0,1fr) 18px!important;gap:8px!important;align-items:center!important}
.hd-next-card.has-photo .hd-next-copy{display:block!important;padding:0!important}.hd-next-card.has-photo>b{margin:0!important;align-self:center!important}
.hd-next-card strong{font-size:14px!important}.hd-next-card small{font-size:10px!important;line-height:1.32!important}

.hd-next-partner-banner{position:relative!important;grid-column:1/-1!important;min-height:82px!important;overflow:hidden!important;border:1px solid rgba(63,71,75,.10)!important;border-radius:5px!important;background:#fff!important}
.hd-next-partner-banner>span{position:absolute!important;z-index:4!important;left:11px!important;top:8px!important;padding:3px 7px!important;border-radius:3px!important;background:rgba(255,255,255,.94)!important;color:#7a6c59!important;font-size:8px!important;font-weight:800!important;letter-spacing:.08em!important;text-transform:uppercase!important}
.hd-next-partner-banner>div,.hd-next-partner-banner>div>.ppar-affiliate-slot,.hd-next-partner-banner .ppar-affiliate-content,.hd-next-partner-banner .ppar-banner-link{width:100%!important;height:82px!important;min-height:82px!important;max-height:82px!important;margin:0!important;padding:0!important;border:0!important;overflow:hidden!important;background:#fff!important}
.hd-next-partner-banner img{display:block!important;width:100%!important;height:82px!important;max-height:82px!important;object-fit:cover!important}
.hd-next-partner-banner .ppar-affiliate-disclosure,.hd-next-partner-banner .ppar-affiliate-label{display:none!important}
.hd-next-partner-banner.is-preview>div{padding:0!important}.hd-next-partner-banner .hd-affiliate-preview{display:flex!important;min-height:82px!important;padding:16px 16px 10px!important;border:0!important;background:#fbfaf7!important;align-items:center!important;gap:14px!important;flex-direction:row!important}.hd-next-partner-banner .hd-affiliate-preview small{margin-left:auto!important}

.hd-next-partner-product{position:relative!important;grid-column:span 2!important;min-width:0!important;height:88px!important;overflow:hidden!important;border:1px solid rgba(63,71,75,.10)!important;border-radius:5px!important;background:#fbfaf7!important}
.hd-next-partner-label{position:absolute!important;z-index:5!important;left:8px!important;top:6px!important;padding:2px 5px!important;border-radius:3px!important;background:rgba(255,255,255,.94)!important;color:#8c6a40!important;font-size:7.5px!important;font-weight:800!important;letter-spacing:.07em!important;text-transform:uppercase!important}
.hd-next-partner-content,.hd-next-partner-content>.ppar-affiliate-slot,.hd-next-partner-content .ppar-affiliate-content{width:100%!important;height:100%!important;min-height:0!important;margin:0!important;padding:0!important;border:0!important;background:#fff!important}
.hd-next-partner-product .ppar-affiliate-disclosure,.hd-next-partner-product .ppar-affiliate-label{display:none!important}
.hd-next-partner-product .ppar-banner-link,.hd-next-partner-product .ppar-banner-link[data-ppar-category-product-card="1"]{display:grid!important;width:100%!important;height:88px!important;grid-template-columns:112px minmax(0,1fr)!important;align-items:center!important;margin:0!important;padding:0!important;border:0!important;background:#fff!important}
.hd-next-partner-product .ppar-banner-image-wrap{display:flex!important;width:112px!important;height:88px!important;align-items:center!important;justify-content:center!important;background:#fbfaf7!important}.hd-next-partner-product img.ppar-banner-image{display:block!important;max-width:96px!important;max-height:66px!important;width:auto!important;height:auto!important;object-fit:contain!important}
.hd-next-partner-product .ppar-banner-text{display:flex!important;height:88px!important;padding:15px 10px 8px!important;flex-direction:column!important;justify-content:center!important;overflow:hidden!important}.hd-next-partner-product .ppar-banner-title,.hd-next-partner-product strong{font-size:11px!important;line-height:1.15!important}.hd-next-partner-product .ppar-banner-description,.hd-next-partner-product .ppar-banner-text span{max-height:26px!important;overflow:hidden!important;font-size:9px!important;line-height:1.25!important}.hd-next-partner-product .ppar-banner-button,.hd-next-partner-product .ppar-banner-cta{font-size:9px!important;color:var(--hd-petrol)!important}
.hd-next-partner-product .hd-affiliate-preview{display:grid!important;height:88px!important;min-height:88px!important;padding:24px 11px 8px!important;border:0!important;background:#fbfaf7!important;align-content:center!important}.hd-next-partner-product .hd-affiliate-preview small{font-size:8px!important}.hd-next-partner-product .hd-affiliate-preview strong{font-size:11px!important}.hd-next-partner-product .hd-affiliate-preview span{font-size:9px!important}

.hd-content-v150616 .hd-rental{margin:18px auto 0!important}
.hd-rental-link.is-available{position:relative!important;display:block!important;min-height:188px!important;border:0!important;border-radius:7px!important;background:#17313c!important;box-shadow:0 8px 24px rgba(42,55,61,.11)!important}
.hd-rental-link.is-available .hd-rental-visual{position:absolute!important;inset:0!important;display:block!important;background-position:center 58%!important;background-size:cover!important;filter:saturate(.96) contrast(1.02)!important}
.hd-rental-link.is-available .hd-rental-visual:after{content:""!important;position:absolute!important;inset:0!important;background:linear-gradient(90deg,rgba(15,38,48,.86) 0%,rgba(15,38,48,.68) 42%,rgba(15,38,48,.24) 70%,rgba(15,38,48,.08) 100%)!important}
.hd-rental-link.is-available .hd-rental-copy{position:relative!important;z-index:2!important;display:flex!important;min-height:188px!important;padding:22px 28px!important;flex-direction:column!important;align-items:flex-start!important;justify-content:center!important;color:#fff!important}
.hd-rental-link.is-available .hd-rental-copy small{padding:0!important;background:transparent!important;color:#f3ddad!important;font-size:9px!important;letter-spacing:.11em!important}
.hd-rental-link.is-available .hd-rental-copy strong{position:relative!important;isolation:isolate!important;display:inline-block!important;max-width:720px!important;margin:10px 0 8px!important;padding:4px 8px 6px!important;color:#fff!important;font-size:clamp(26px,2.55vw,38px)!important;line-height:1.04!important}
.hd-rental-link.is-available .hd-rental-copy strong:before{content:""!important;position:absolute!important;z-index:-1!important;left:-10px!important;right:-12px!important;bottom:1px!important;height:18px!important;background:#159da3!important;clip-path:polygon(0 34%,5% 16%,16% 28%,29% 7%,46% 22%,61% 5%,77% 25%,94% 10%,100% 36%,97% 78%,81% 67%,63% 88%,43% 72%,22% 90%,4% 74%)!important;transform:rotate(-1deg)!important;opacity:.95!important}
.hd-rental-link.is-available .hd-rental-copy em{max-width:560px!important;padding:0!important;background:transparent!important;color:rgba(255,255,255,.90)!important;font-size:13px!important;font-style:normal!important;font-weight:600!important}
.hd-rental-link.is-available .hd-rental-copy b{margin-top:13px!important;padding:10px 15px!important;border:0!important;border-radius:4px!important;background:#fff8ec!important;color:#17313c!important;box-shadow:0 3px 12px rgba(0,0,0,.12)!important;font-size:11px!important}

@media(max-width:1000px) and (min-width:761px){
 .hd-next-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}.hd-next-card,.hd-next-card.hd-row-size-3,.hd-next-card.hd-row-size-2,.hd-next-partner-product{grid-column:auto!important}.hd-next-card.hd-row-size-1{grid-column:1/-1!important}.hd-next-grid.hd-next-odd>.hd-next-card:last-of-type{grid-column:auto!important}
 .hd-next-card.has-photo{grid-template-columns:118px minmax(0,1fr)!important}.hd-next-photo{width:118px!important;height:63px!important}
 .hd-next-partner-banner{grid-column:1/-1!important}
}
@media(max-width:760px){
 .hd-hub1-fold{width:calc(100% - 24px)!important}.hd-hub1-fold-body{padding-top:18px!important}.hd-hub1-fold-body>p,.hd-hub1-find{max-width:none!important}
 .hd-next-grid{grid-template-columns:1fr!important}.hd-next-card,.hd-next-card.hd-row-size-3,.hd-next-card.hd-row-size-2,.hd-next-card.hd-row-size-1,.hd-next-partner-product,.hd-next-partner-banner{grid-column:1!important}
 .hd-next-card.has-photo{grid-template-columns:112px minmax(0,1fr)!important;min-height:82px!important}.hd-next-photo{width:112px!important;height:60px!important;margin:11px 0 11px 9px!important}.hd-next-card-body{min-height:82px!important}
 .hd-next-partner-banner,.hd-next-partner-banner>div,.hd-next-partner-banner>div>.ppar-affiliate-slot,.hd-next-partner-banner .ppar-affiliate-content,.hd-next-partner-banner .ppar-banner-link,.hd-next-partner-banner img{height:76px!important;min-height:76px!important;max-height:76px!important}
 .hd-next-partner-product{height:82px!important}.hd-next-partner-product .ppar-banner-link{height:82px!important;grid-template-columns:96px minmax(0,1fr)!important}.hd-next-partner-product .ppar-banner-image-wrap{width:96px!important;height:82px!important}.hd-next-partner-product .ppar-banner-text{height:82px!important}.hd-next-partner-product .hd-affiliate-preview{height:82px!important;min-height:82px!important}
 .hd-rental-link.is-available,.hd-rental-link.is-available .hd-rental-copy{min-height:224px!important}.hd-rental-link.is-available .hd-rental-copy{padding:20px 17px!important}.hd-rental-link.is-available .hd-rental-copy strong{font-size:28px!important}.hd-rental-link.is-available .hd-rental-copy em{font-size:12px!important}.hd-rental-link.is-available .hd-rental-copy b{background:#fff8ec!important;color:#17313c!important}
}



/* 1.50.620: final live corrections – lower navigation, restored flyouts, readable logo spacing, filled landscape thumbnails, concise unique subtitles. */
@media(min-width:761px){
  .hd-head-v150616{min-height:232px!important;grid-template-columns:286px minmax(0,1fr)!important;grid-template-rows:154px 68px!important;gap:0 30px!important;padding:8px 0 10px!important;align-items:stretch!important;overflow:visible!important}
  .hd-logo-v150616{grid-column:1!important;grid-row:1!important;width:264px!important;height:auto!important;max-height:none!important;justify-self:start!important;align-self:center!important;margin:0!important;overflow:visible!important}
  .hd-logo-v150616 img{display:block!important;width:264px!important;height:auto!important;max-height:none!important;object-fit:contain!important;object-position:left center!important}
  .hd-search-v150616{grid-column:2!important;grid-row:1!important;align-self:center!important;width:min(100%,760px)!important;margin:auto!important}
  .hd-nav-v150616{grid-column:1/-1!important;grid-row:2!important;position:relative!important;z-index:10020!important;display:block!important;width:100%!important;margin:0!important;padding:19px 0 9px!important;align-self:end!important;overflow:visible!important;background:transparent!important;border:0!important;box-shadow:none!important;transform:none!important}
  .hd-nav-v150616>ul{display:grid!important;grid-template-columns:repeat(8,minmax(0,1fr))!important;gap:4px 14px!important;width:100%!important;margin:0!important;padding:0!important;overflow:visible!important;align-items:end!important}
  .hd-nav-item{position:relative!important;z-index:10021!important;display:flex!important;min-width:0!important;overflow:visible!important;align-items:center!important;justify-content:flex-start!important;border:0!important;white-space:nowrap!important}
  .hd-nav-item>a{padding:8px 2px 7px!important;font-size:14px!important;line-height:1.1!important}
  .hd-sub-toggle-v150616{display:inline-block!important;width:20px!important;height:34px!important;margin:0!important}
  .has-mega:after{content:""!important;position:absolute!important;z-index:10022!important;left:-8px!important;right:-8px!important;top:100%!important;height:10px!important;background:transparent!important;pointer-events:auto!important}
  .hd-mega,.hd-mega-single,.hd-mega-single.is-two-col{position:absolute!important;z-index:10060!important;top:calc(100% + 7px)!important;display:none!important;width:410px!important;max-width:min(520px,calc(100vw - 48px))!important;padding:18px 19px 15px!important;border:1px solid var(--hd-line)!important;border-radius:5px!important;background:#fff!important;box-shadow:0 18px 48px rgba(42,55,61,.16)!important}
  .hd-mega-single.is-two-col{width:510px!important}
  .has-mega:hover>.hd-mega,.has-mega:focus-within>.hd-mega,.has-mega.is-sub-open>.hd-mega{display:block!important}
  .hd-world-gestalten>.hd-mega,.hd-world-fertigen>.hd-mega{left:0!important;right:auto!important;transform:none!important}
  .hd-world-technik>.hd-mega,.hd-world-forschen>.hd-mega,.hd-world-pflanzen>.hd-mega,.hd-world-tiere>.hd-mega{left:50%!important;right:auto!important;transform:translateX(-50%)!important}
  .hd-world-bewegen>.hd-mega,.hd-world-sammeln>.hd-mega{left:auto!important;right:0!important;transform:none!important}
}
@media(max-width:1000px) and (min-width:761px){
  .hd-head-v150616{min-height:278px!important;grid-template-columns:248px minmax(0,1fr)!important;grid-template-rows:150px 118px!important;gap:0 20px!important}
  .hd-logo-v150616,.hd-logo-v150616 img{width:232px!important}
  .hd-nav-v150616{padding:18px 0 10px!important}
  .hd-nav-v150616>ul{grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:4px 18px!important}
  .hd-nav-item>a{padding:8px 3px!important}
  .hd-nav-item:nth-child(-n+4)>.hd-mega{top:calc(100% + 52px)!important}
  .hd-nav-item:nth-child(4n+1)>.hd-mega,.hd-nav-item:nth-child(4n+2)>.hd-mega{left:0!important;right:auto!important;transform:none!important}
  .hd-nav-item:nth-child(4n+3)>.hd-mega,.hd-nav-item:nth-child(4n+4)>.hd-mega{left:auto!important;right:0!important;transform:none!important}
  .hd-mega,.hd-mega-single,.hd-mega-single.is-two-col{width:min(500px,calc(100vw - 46px))!important}
}

/* Cards: image fills the complete image frame; no inset thumbnail. */
.hd-next-card.has-photo{display:grid!important;grid-template-columns:168px minmax(0,1fr)!important;min-height:90px!important;padding:0!important;overflow:hidden!important;border-radius:5px!important;background:#fff!important}
.hd-next-photo{display:block!important;width:168px!important;height:90px!important;min-height:90px!important;margin:0!important;aspect-ratio:1.8666667/1!important;overflow:hidden!important;border-radius:0!important;background:#f5f1e9!important;align-self:stretch!important}
.hd-next-photo img{display:block!important;width:100%!important;height:100%!important;min-height:90px!important;object-fit:cover!important;object-position:center!important}
.hd-next-card-body{display:grid!important;min-height:90px!important;padding:12px 12px!important;grid-template-columns:minmax(0,1fr) 18px!important;gap:8px!important;align-items:center!important}
.hd-next-card strong{font-size:14px!important;line-height:1.16!important}.hd-next-card small{display:block!important;margin-top:4px!important;color:#6a7479!important;font-size:10.5px!important;line-height:1.25!important}
@media(max-width:1000px) and (min-width:761px){.hd-next-card.has-photo{grid-template-columns:150px minmax(0,1fr)!important}.hd-next-photo{width:150px!important;height:80px!important;min-height:80px!important}.hd-next-photo img{min-height:80px!important}.hd-next-card-body{min-height:80px!important}}
@media(max-width:760px){.hd-next-card.has-photo{grid-template-columns:136px minmax(0,1fr)!important;min-height:76px!important}.hd-next-photo{width:136px!important;height:76px!important;min-height:76px!important;margin:0!important}.hd-next-photo img{min-height:76px!important}.hd-next-card-body{min-height:76px!important;padding:9px 10px!important}}


/* 1.50.620: live micro-finish only – navigation on lower line, less technical section heading, readable card copy. */
@media(min-width:1001px){
  .hd-head-v150616{min-height:252px!important;grid-template-rows:164px 78px!important;padding:10px 0 0!important}
  .hd-logo-v150616{align-self:center!important}
  .hd-search-v150616{align-self:center!important}
  .hd-nav-v150616{align-self:end!important;padding:28px 0 2px!important}
  .hd-nav-item>a{padding:6px 2px 2px!important}
  .hd-sub-toggle-v150616{height:30px!important;align-self:end!important}
}
@media(max-width:1000px) and (min-width:761px){
  .hd-head-v150616{min-height:292px!important;grid-template-rows:158px 124px!important;padding:10px 0 0!important}
  .hd-nav-v150616{align-self:end!important;padding:24px 0 2px!important}
  .hd-nav-item>a{padding:6px 3px 3px!important}
}
.hd-next-level>header>span{display:none!important}
.hd-next-level>header{margin-bottom:12px!important}
.hd-next-level>header h2{margin:0!important;font-size:25px!important;line-height:1.08!important}
.hd-next-card strong{font-size:15px!important;line-height:1.18!important}
.hd-next-card small{margin-top:5px!important;font-size:12px!important;line-height:1.28!important;color:#5f6a6f!important}


/* 1.50.622: agreed two-column header – logo left spanning search+nav, search aligned to HOBBY DEPOT wordmark, nav only in right column. */
.hd-header-v150616 .screen-reader-text{position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important}
.hd-nav-world-icon{display:none!important}
@media(min-width:1001px){
  .hd-head-v150616{display:grid!important;width:min(calc(100% - 72px),var(--hd-content))!important;min-height:156px!important;grid-template-columns:240px minmax(0,1fr) 0!important;grid-template-rows:156px!important;gap:0 28px!important;padding:0!important;align-items:stretch!important}
  .hd-logo-v150616.hd-logo-composed-v150622{grid-column:1!important;grid-row:1!important;width:220px!important;height:146px!important;max-height:none!important;align-self:start!important;justify-self:start!important;margin:0!important;overflow:visible!important}
  .hd-logo-v150616 img.hd-logo-full-v150622{display:none!important}
  .hd-logo-parts-v150622{display:flex!important;width:220px!important;height:146px!important;flex-direction:column!important;align-items:flex-start!important;justify-content:flex-start!important}
  .hd-logo-parts-v150622>span{display:block!important;width:220px!important;flex:0 0 auto!important;background-image:var(--hd-logo-image)!important;background-repeat:no-repeat!important;background-size:220px auto!important}
  .hd-logo-mark-v150622{height:76px!important;background-position:0 0!important}
  .hd-logo-word-v150622{height:29px!important;margin-top:9px!important;background-position:0 -77px!important}
  .hd-logo-claim-v150622{height:20px!important;margin-top:10px!important;background-position:0 -108px!important;transform:scaleX(1.06)!important;transform-origin:left center!important}
  .hd-head-center-v150616{grid-column:2!important;grid-row:1!important;display:grid!important;min-width:0!important;height:156px!important;grid-template-columns:minmax(0,1fr)!important;grid-template-rows:119px 37px!important;align-self:stretch!important;align-content:stretch!important}
  .hd-search-v150616{grid-column:1!important;grid-row:1!important;align-self:end!important;width:min(100%,820px)!important;height:34px!important;margin:0 auto 2px!important;border-radius:7px!important}
  .hd-search-v150616 svg{left:14px!important;width:17px!important;height:17px!important}.hd-search-v150616 input{padding-left:42px!important;font-size:13px!important}
  .hd-nav-v150616{grid-column:1!important;grid-row:2!important;position:relative!important;z-index:10020!important;display:block!important;width:100%!important;height:37px!important;margin:0!important;padding:0 0 1px!important;align-self:end!important;overflow:visible!important;background:transparent!important;border:0!important;box-shadow:none!important;transform:none!important}
  .hd-nav-v150616>ul{display:flex!important;width:100%!important;height:36px!important;margin:0!important;padding:0!important;align-items:flex-end!important;justify-content:space-between!important;gap:12px!important;overflow:visible!important}
  .hd-nav-item{position:relative!important;display:flex!important;height:35px!important;min-width:0!important;align-items:flex-end!important;justify-content:center!important;overflow:visible!important;border:0!important;white-space:nowrap!important}
  .hd-nav-item>a{display:inline-flex!important;height:34px!important;align-items:center!important;padding:0 0 2px!important;font-size:14px!important;font-weight:700!important;line-height:1!important;gap:0!important}
  .hd-sub-toggle-v150616{display:inline-flex!important;width:18px!important;height:34px!important;margin:0 0 0 3px!important;padding:0!important;align-items:center!important;align-self:flex-end!important;justify-content:center!important;transform:none!important}
  .hd-sub-toggle-v150616 span:after{margin:0 auto 5px!important}
  .hd-menu-toggle-v150616{display:none!important}
  .hd-mega{top:calc(100% + 6px)!important}
}
@media(max-width:1000px) and (min-width:761px){
  .hd-head-v150616{display:grid!important;width:min(calc(100% - 36px),var(--hd-content))!important;min-height:170px!important;grid-template-columns:205px minmax(0,1fr) 0!important;grid-template-rows:170px!important;gap:0 16px!important;padding:0!important;align-items:stretch!important}
  .hd-logo-v150616.hd-logo-composed-v150622{grid-column:1!important;grid-row:1!important;width:194px!important;height:132px!important;margin:0!important;align-self:start!important;justify-self:start!important;overflow:visible!important}
  .hd-logo-v150616 img.hd-logo-full-v150622{display:none!important}
  .hd-logo-parts-v150622{display:flex!important;width:194px!important;height:132px!important;flex-direction:column!important;align-items:flex-start!important;justify-content:flex-start!important}
  .hd-logo-parts-v150622>span{display:block!important;width:194px!important;flex:0 0 auto!important;background-image:var(--hd-logo-image)!important;background-repeat:no-repeat!important;background-size:194px auto!important}
  .hd-logo-mark-v150622{height:67px!important;background-position:0 0!important}
  .hd-logo-word-v150622{height:26px!important;margin-top:8px!important;background-position:0 -68px!important}
  .hd-logo-claim-v150622{height:18px!important;margin-top:8px!important;background-position:0 -96px!important;transform:scaleX(1.06)!important;transform-origin:left center!important}
  .hd-head-center-v150616{grid-column:2!important;grid-row:1!important;display:grid!important;min-width:0!important;height:170px!important;grid-template-rows:101px 69px!important;align-self:stretch!important}
  .hd-search-v150616{grid-column:1!important;grid-row:1!important;align-self:end!important;width:100%!important;height:34px!important;margin:0 0 2px!important}
  .hd-nav-v150616{grid-column:1!important;grid-row:2!important;position:relative!important;display:block!important;width:100%!important;height:69px!important;margin:0!important;padding:0 0 1px!important;align-self:end!important;overflow:visible!important;background:transparent!important;border:0!important;box-shadow:none!important}
  .hd-nav-v150616>ul{display:grid!important;width:100%!important;height:68px!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;grid-template-rows:repeat(2,32px)!important;gap:3px 14px!important;margin:0!important;padding:0!important;align-items:end!important;overflow:visible!important}
  .hd-nav-item{position:relative!important;display:flex!important;height:32px!important;min-width:0!important;align-items:flex-end!important;justify-content:flex-start!important;overflow:visible!important;border:0!important}
  .hd-nav-item>a{display:inline-flex!important;height:31px!important;align-items:center!important;padding:0 0 2px!important;font-size:13.5px!important;line-height:1!important}
  .hd-sub-toggle-v150616{display:inline-flex!important;width:18px!important;height:31px!important;margin-left:3px!important;padding:0!important;align-items:center!important;align-self:flex-end!important;justify-content:center!important}
  .hd-menu-toggle-v150616{display:none!important}
  .has-mega:hover>.hd-mega,.has-mega:focus-within>.hd-mega,.has-mega.is-sub-open>.hd-mega{display:block!important}
  .hd-mega{position:absolute!important;top:calc(100% + 6px)!important;z-index:10060!important;width:min(500px,calc(100vw - 46px))!important}
  .hd-nav-item:nth-child(4n+1)>.hd-mega,.hd-nav-item:nth-child(4n+2)>.hd-mega{left:0!important;right:auto!important;transform:none!important}
  .hd-nav-item:nth-child(4n+3)>.hd-mega,.hd-nav-item:nth-child(4n+4)>.hd-mega{left:auto!important;right:0!important;transform:none!important}
}
@media(max-width:760px){
  .hd-logo-parts-v150622{display:none!important}
  .hd-logo-v150616 img.hd-logo-full-v150622{display:block!important;width:196px!important;height:auto!important;max-height:none!important}
  .hd-logo-v150616.hd-logo-composed-v150622{width:196px!important;height:auto!important;overflow:visible!important}
  .hd-nav-world-icon{display:none!important}
}


/* 1.50.624: hard-bottom navigation + banner-only category-grid filler; products outside category rows. */
@media(min-width:1001px){
  .hd-head-center-v150616{position:relative!important;display:block!important;height:156px!important;min-height:156px!important}
  .hd-search-v150616{position:absolute!important;left:0!important;right:0!important;top:55px!important;width:min(100%,820px)!important;height:34px!important;margin:0 auto!important}
  .hd-nav-v150616{position:absolute!important;left:0!important;right:0!important;bottom:0!important;width:100%!important;height:29px!important;margin:0!important;padding:0!important;align-self:auto!important}
  .hd-nav-v150616>ul{height:29px!important;align-items:flex-end!important}
  .hd-nav-item{height:29px!important;align-items:flex-end!important}
  .hd-nav-item>a{height:28px!important;padding:0 0 1px!important;align-items:center!important}
  .hd-sub-toggle-v150616{height:28px!important;align-self:flex-end!important}
  .hd-mega{top:calc(100% + 1px)!important}
}
@media(max-width:1000px) and (min-width:761px){
  .hd-head-center-v150616{position:relative!important;display:block!important;height:170px!important;min-height:170px!important}
  .hd-search-v150616{position:absolute!important;left:0!important;right:0!important;top:48px!important;width:100%!important;height:34px!important;margin:0!important}
  .hd-nav-v150616{position:absolute!important;left:0!important;right:0!important;bottom:0!important;width:100%!important;height:68px!important;margin:0!important;padding:0!important}
  .hd-nav-v150616>ul{height:68px!important}
}
.hd-next-partner-banner.hd-banner-span-1{grid-column:span 2!important}
.hd-next-partner-banner.hd-banner-span-2{grid-column:span 4!important}
.hd-next-partner-banner.hd-banner-span-3{grid-column:1/-1!important}
@media(max-width:1000px) and (min-width:761px){
  .hd-next-partner-banner.hd-banner-span-1,.hd-next-partner-banner.hd-banner-span-2,.hd-next-partner-banner.hd-banner-span-3{grid-column:1/-1!important}
}
@media(max-width:760px){
  .hd-next-partner-banner.hd-banner-span-1,.hd-next-partner-banner.hd-banner-span-2,.hd-next-partner-banner.hd-banner-span-3{grid-column:1!important}
}

/* 1.50.627: final live fixes – one baseline for all 8 nav items, nav visually on the bottom line,
   controlled unique/simple first-level hub imagery. */
@media(min-width:761px){
  .hd-head-center-v150616{position:relative!important;display:block!important}
  .hd-nav-v150616{position:absolute!important;left:0!important;right:0!important;bottom:-1px!important;width:100%!important;height:22px!important;margin:0!important;padding:0!important;overflow:visible!important}
  .hd-nav-v150616>ul{display:flex!important;grid-template-columns:none!important;grid-template-rows:none!important;width:100%!important;height:22px!important;margin:0!important;padding:0!important;gap:6px!important;align-items:flex-end!important;justify-content:space-between!important;flex-wrap:nowrap!important;overflow:visible!important}
  .hd-nav-item{position:relative!important;display:block!important;height:22px!important;min-width:0!important;border:0!important;white-space:nowrap!important;align-items:initial!important;justify-content:initial!important}
  .hd-nav-item>a{display:inline-flex!important;height:22px!important;min-width:0!important;padding:0 17px 1px 0!important;align-items:flex-end!important;font-size:clamp(12px,1.05vw,14px)!important;font-weight:700!important;line-height:20px!important;white-space:nowrap!important;vertical-align:bottom!important}
  .hd-nav-world-label{display:inline-block!important;height:20px!important;line-height:20px!important;white-space:nowrap!important;vertical-align:bottom!important}
  .hd-sub-toggle-v150616{position:absolute!important;right:0!important;bottom:0!important;display:flex!important;width:15px!important;height:22px!important;margin:0!important;padding:0!important;align-items:flex-end!important;justify-content:center!important;transform:none!important}
  .hd-sub-toggle-v150616 span{display:block!important;width:10px!important;height:20px!important;position:relative!important}
  .hd-sub-toggle-v150616 span:after{position:absolute!important;left:2px!important;bottom:7px!important;width:5px!important;height:5px!important;margin:0!important}
  .hd-mega{top:calc(100% + 1px)!important}
}
@media(max-width:1000px) and (min-width:761px){
  .hd-nav-v150616{height:22px!important;bottom:-1px!important}
  .hd-nav-v150616>ul{display:flex!important;height:22px!important;gap:3px!important}
  .hd-nav-item{height:22px!important}
  .hd-nav-item>a{height:22px!important;padding-right:14px!important;font-size:clamp(11.2px,1.22vw,13px)!important;line-height:20px!important}
  .hd-sub-toggle-v150616{width:13px!important;height:22px!important}
  .hd-nav-item:nth-child(-n+4)>.hd-mega,.hd-nav-item:nth-child(n+5)>.hd-mega{top:calc(100% + 1px)!important}
}


/* 1.50.627: hard single-baseline desktop/tablet navigation + natural hub copy + readable end editorial. */
@media(min-width:761px){
  .hd-head-center-v150616{position:relative!important;display:block!important}
  .hd-nav-v150616{position:absolute!important;left:0!important;right:0!important;bottom:-3px!important;width:100%!important;height:26px!important;margin:0!important;padding:0!important;overflow:visible!important}
  .hd-nav-v150616>ul{display:grid!important;grid-template-columns:repeat(8,minmax(0,1fr))!important;grid-template-rows:26px!important;width:100%!important;height:26px!important;margin:0!important;padding:0!important;gap:4px!important;align-items:end!important;overflow:visible!important}
  .hd-nav-item{position:relative!important;display:grid!important;grid-template-columns:minmax(0,max-content) 13px!important;grid-template-rows:26px!important;height:26px!important;min-width:0!important;margin:0!important;padding:0!important;align-items:end!important;justify-content:center!important;overflow:visible!important;white-space:nowrap!important}
  .hd-nav-item>a{display:block!important;height:26px!important;min-width:0!important;margin:0!important;padding:0!important;font-size:clamp(11.2px,1.05vw,14px)!important;font-weight:700!important;line-height:26px!important;white-space:nowrap!important;vertical-align:baseline!important}
  .hd-nav-world-label{display:block!important;height:26px!important;margin:0!important;padding:0!important;line-height:26px!important;white-space:nowrap!important;vertical-align:baseline!important}
  .hd-sub-toggle-v150616{position:static!important;display:block!important;width:13px!important;height:26px!important;margin:0!important;padding:0!important;align-self:end!important;justify-self:end!important;transform:none!important}
  .hd-sub-toggle-v150616 span{display:block!important;width:13px!important;height:26px!important;position:relative!important}
  .hd-sub-toggle-v150616 span:after{position:absolute!important;left:3px!important;bottom:9px!important;width:5px!important;height:5px!important;margin:0!important}
  .hd-mega{top:calc(100% + 3px)!important}
}
@media(max-width:1000px) and (min-width:761px){
  .hd-nav-v150616>ul{grid-template-columns:repeat(8,minmax(0,1fr))!important;grid-template-rows:26px!important;gap:1px!important}
  .hd-nav-item{grid-template-columns:minmax(0,max-content) 11px!important}
  .hd-nav-item>a{font-size:clamp(9.8px,1.1vw,12.4px)!important}
  .hd-sub-toggle-v150616{width:11px!important}
  .hd-sub-toggle-v150616 span{width:11px!important}
}
.hd-hub1-fold{display:none!important}
.hd-hub1-bottom-copy{width:min(calc(100% - 48px),980px);margin:54px auto 0;padding:0 0 22px}
.hd-hub1-bottom-inner{border-top:1px solid var(--hd-line);padding-top:34px}
.hd-hub1-bottom-copy h2{margin:0 0 28px;font-size:30px;line-height:1.15;color:var(--hd-dark)}
.hd-hub1-copy-section{margin:0 0 28px}
.hd-hub1-copy-section h3{margin:0 0 10px;font-size:20px;line-height:1.25;color:var(--hd-dark)}
.hd-hub1-copy-section p{margin:0 0 13px;font-size:16px;line-height:1.72;color:#46555b}
.hd-hub1-copy-section a{color:var(--hd-petrol);font-weight:700;text-decoration:underline;text-decoration-thickness:1px;text-underline-offset:3px}
.hd-hub1-copy-section a:hover{color:var(--hd-dark)}
@media(max-width:760px){
  .hd-hub1-bottom-copy{width:min(calc(100% - 28px),980px);margin-top:38px}
  .hd-hub1-bottom-inner{padding-top:26px}
  .hd-hub1-bottom-copy h2{font-size:25px}
  .hd-hub1-copy-section h3{font-size:19px}
  .hd-hub1-copy-section p{font-size:15.5px;line-height:1.68}
}

/* 1.50.629: first-level hub photos use the wider, simpler controlled motif set; navigation/text/layout unchanged. */
/* 1.50.628: raise the accepted single-line navigation slightly; make hub photos easier to read. */
@media(min-width:761px){
  .hd-nav-v150616{bottom:5px!important}
}
@media(min-width:1001px){
  .hd-next-card.has-photo{grid-template-columns:200px minmax(0,1fr)!important;min-height:108px!important}
  .hd-next-photo{width:200px!important;height:107px!important;min-height:107px!important}
  .hd-next-photo img{min-height:107px!important}
  .hd-next-card-body{min-height:108px!important;padding:12px 13px!important}
}
@media(max-width:1000px) and (min-width:761px){
  .hd-next-card.has-photo{grid-template-columns:165px minmax(0,1fr)!important;min-height:92px!important}
  .hd-next-photo{width:165px!important;height:88px!important;min-height:88px!important}
  .hd-next-photo img{min-height:88px!important}
  .hd-next-card-body{min-height:92px!important}
}
@media(max-width:760px){
  .hd-next-card.has-photo{grid-template-columns:145px minmax(0,1fr)!important;min-height:82px!important}
  .hd-next-photo{width:145px!important;height:78px!important;min-height:78px!important}
  .hd-next-photo img{min-height:78px!important}
}


/* 1.50.631 FINAL: logo/claim/navigation geometry. This is deliberately last in cascade. */
@media(min-width:1001px){
  .hd-logo-v150616.hd-logo-composed-v150622{transform:translateY(7px)!important}
  .hd-logo-claim-v150622{transform:none!important;transform-origin:center center!important}
}
@media(max-width:1000px) and (min-width:761px){
  .hd-logo-v150616.hd-logo-composed-v150622{transform:translateY(38px)!important}
  .hd-logo-claim-v150622{transform:none!important;transform-origin:center center!important}
}

/* 1.50.634 CATEGORY PREVIEW ONLY: image fills its slot; no inset, no passepartout, no preview frame. */
@media(min-width:1001px){
 .hd-next-card.has-photo{display:grid!important;grid-template-columns:200px minmax(0,1fr)!important;min-height:107px!important;padding:0!important;overflow:hidden!important}
 .hd-next-photo{display:block!important;width:200px!important;height:107px!important;min-height:107px!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:transparent!important;overflow:hidden!important;align-self:stretch!important}
 .hd-next-photo img{display:block!important;width:200px!important;height:107px!important;min-height:107px!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;object-fit:cover!important;object-position:center!important}
 .hd-next-card-body{min-height:107px!important}
}
@media(max-width:1000px) and (min-width:761px){
 .hd-next-card.has-photo{display:grid!important;grid-template-columns:165px minmax(0,1fr)!important;min-height:88px!important;padding:0!important;overflow:hidden!important}
 .hd-next-photo{display:block!important;width:165px!important;height:88px!important;min-height:88px!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:transparent!important;overflow:hidden!important;align-self:stretch!important}
 .hd-next-photo img{display:block!important;width:165px!important;height:88px!important;min-height:88px!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;object-fit:cover!important;object-position:center!important}
 .hd-next-card-body{min-height:88px!important}
}
@media(max-width:760px){
 .hd-next-card.has-photo{display:grid!important;grid-template-columns:145px minmax(0,1fr)!important;min-height:78px!important;padding:0!important;overflow:hidden!important}
 .hd-next-photo{display:block!important;width:145px!important;height:78px!important;min-height:78px!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;background:transparent!important;overflow:hidden!important;align-self:stretch!important}
 .hd-next-photo img{display:block!important;width:145px!important;height:78px!important;min-height:78px!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;object-fit:cover!important;object-position:center!important}
 .hd-next-card-body{min-height:78px!important}
}


/* 1.50.635 – Ebene 2: textorientiert, kein Hero-Foto, Monetarisierung tiefer und konkreter. */
.hd-content-v150616 .hd-page-intro + .hd-next-level{margin-top:20px!important}
.hd-hub2-bottom-head{margin-top:30px!important;margin-bottom:-4px!important;padding-top:23px!important;border-top:1px solid rgba(63,71,75,.12)!important}
.hd-hub2-bottom-head>header{margin:0!important}
.hd-hub2-bottom-head>header>span{margin-bottom:6px!important}
.hd-hub2-bottom-head>header>h2{margin:0!important;color:#17313c!important;font-size:25px!important;line-height:1.12!important}
.hd-hub2-bottom-head + .hd-category-copy{margin-top:10px!important}
/* Separate Hub2 banner: no longer used as a filler inside the child-category grid. */
.hd-content-v150616 .hd-context-banner{margin-top:22px!important}
.hd-content-v150616 .hd-context-banner + .hd-post-previews{margin-top:24px!important}
.hd-content-v150616 .hd-post-previews + .hd-context-products{margin-top:24px!important}
.hd-content-v150616 .hd-context-products + .hd-rental{margin-top:24px!important}
@media(max-width:760px){
  .hd-content-v150616 .hd-page-intro + .hd-next-level{margin-top:16px!important}
  .hd-hub2-bottom-head{margin-top:24px!important;padding-top:18px!important}
  .hd-hub2-bottom-head>header>h2{font-size:22px!important}
}



/* 1.50.636 – Hub2 visual refinement only: longer natural top copy, varied topic icons, 4-post preview. */
.hd-content-v150616 .hd-hub2-intro{padding:26px 0 22px!important;border:0!important;border-bottom:1px solid rgba(63,71,75,.12)!important;background:transparent!important}
.hd-content-v150616 .hd-hub2-intro .hd-page-intro-copy{max-width:980px!important}
.hd-content-v150616 .hd-hub2-intro h1{margin-bottom:12px!important}
.hd-content-v150616 .hd-hub2-intro-text{max-width:900px!important;color:#5d686e!important;font-size:15px!important;line-height:1.72!important}
.hd-content-v150616 .hd-hub2-intro-text p{margin:0 0 9px!important}.hd-content-v150616 .hd-hub2-intro-text p:last-child{margin-bottom:0!important}
.hd-content-v150616 .hd-topic-title-icon{background:#eef8f7!important;color:var(--hd-petrol)!important}
.hd-content-v150616 .hd-next-card:not(.has-photo) .hd-next-icon{width:38px!important;height:38px!important;flex:0 0 38px!important;border-radius:50%!important;background:#eef8f7!important;color:var(--hd-petrol)!important}
.hd-content-v150616 .hd-next-card:not(.has-photo) .hd-next-icon svg{width:19px!important;height:19px!important}
.hd-content-v150616 .hd-post-previews-hub2 .hd-post-grid{grid-template-columns:repeat(4,minmax(0,1fr))!important}
.hd-content-v150616 .hd-post-previews-hub2 .hd-post-card h3{font-size:15px!important}.hd-content-v150616 .hd-post-previews-hub2 .hd-post-card p{font-size:12px!important;line-height:1.5!important}
@media(max-width:1100px){.hd-content-v150616 .hd-post-previews-hub2 .hd-post-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}}
@media(max-width:760px){.hd-content-v150616 .hd-hub2-intro{padding:20px 0 18px!important}.hd-content-v150616 .hd-hub2-intro-text{font-size:14px!important;line-height:1.64!important}.hd-content-v150616 .hd-post-previews-hub2 .hd-post-grid{grid-template-columns:1fr!important}}


/* 1.50.637 – nur Hub2: individueller Claim + längerer, mittig aufklappbarer Einstieg */
.hd-hub2-claim{display:block!important;margin:0 0 8px!important;color:#168f93!important;font-size:10px!important;font-weight:800!important;letter-spacing:.13em!important;text-transform:uppercase!important}
.hd-hub2-intro .hd-hub2-intro-text{max-width:900px!important}
.hd-hub2-more{max-width:900px!important;margin:12px 0 0!important;padding:0!important;border:0!important;background:transparent!important}
.hd-hub2-more summary{display:inline-flex!important;align-items:center!important;gap:7px!important;cursor:pointer!important;color:#0f7f84!important;font-size:13px!important;font-weight:750!important;list-style:none!important}
.hd-hub2-more summary::-webkit-details-marker{display:none!important}
.hd-hub2-more summary:after{content:"+"!important;display:inline-flex!important;width:18px!important;height:18px!important;align-items:center!important;justify-content:center!important;border:1px solid rgba(15,127,132,.24)!important;border-radius:50%!important;font-size:14px!important;line-height:1!important}
.hd-hub2-more[open] summary:after{content:"−"!important}
.hd-hub2-more>div{margin-top:10px!important;padding-top:10px!important;border-top:1px solid rgba(31,52,58,.09)!important}
.hd-hub2-more p{max-width:900px!important;margin:0 0 9px!important;color:#56656a!important;font-size:15px!important;line-height:1.58!important}

/* 1.50.641 – PILOT ausschließlich Buch & Papier / Hub2: längerer natürlicher Brush-Stroke, 2px Hero/Card-Radien, Bilder exakt im Kartenrahmen */
.hd-content-v150616 .hd-bp-hero{
  display:grid!important;
  grid-template-columns:minmax(0,52%) minmax(0,48%)!important;
  align-items:start!important;
  gap:0!important;
  width:min(calc(100% - 72px),var(--hd-content))!important;
  margin:5px auto 0!important;
  padding:0!important;
  overflow:visible!important;
  border:0!important;
  background:#fff!important;
  box-sizing:border-box!important
}
.hd-content-v150616 .hd-bp-hero-copy{padding:24px 30px 22px 0!important;min-width:0!important;align-self:start!important}
.hd-content-v150616 .hd-bp-hero-copy h1{margin:11px 0 12px!important}
.hd-content-v150616 .hd-bp-brush-claim{
  position:relative!important;
  display:inline-block!important;
  z-index:0!important;
  margin:0 0 15px!important;
  padding:0 4px 0 1px!important;
  color:#0f858a!important;
  font-family:"Brush Script MT","Segoe Script","Bradley Hand",cursive!important;
  font-size:24px!important;
  font-weight:400!important;
  font-style:normal!important;
  line-height:1!important;
  letter-spacing:.01em!important;
  text-transform:none!important;
  transform:rotate(-1.2deg)!important
}
.hd-content-v150616 .hd-bp-brush-claim:after{
  content:""!important;
  position:absolute!important;
  z-index:-1!important;
  left:4%!important;
  width:92%!important;
  bottom:-22px!important;
  height:12px!important;
  background-image:var(--hd-bp-brush)!important;
  background-repeat:no-repeat!important;
  background-position:left center!important;
  background-size:100% 100%!important;
  transform:rotate(-.8deg)!important;
  transform-origin:left center!important;
  pointer-events:none!important
}
.hd-content-v150616 .hd-bp-hero-media{
  position:relative!important;
  width:100%!important;
  aspect-ratio:600/320!important;
  min-height:0!important;
  height:auto!important;
  align-self:start!important;
  overflow:hidden!important;
  border-radius:0 2px 2px 0!important;
  background:#fff!important
}
.hd-content-v150616 .hd-bp-hero-media img{
  display:block!important;
  width:100%!important;
  height:100%!important;
  min-height:0!important;
  max-height:none!important;
  aspect-ratio:600/320!important;
  object-fit:cover!important;
  object-position:center center!important;
  border-radius:0 2px 2px 0!important;
  -webkit-mask-image:linear-gradient(to right,transparent 0%,rgba(0,0,0,.16) 7%,rgba(0,0,0,.62) 18%,#000 34%,#000 100%)!important;
  mask-image:linear-gradient(to right,transparent 0%,rgba(0,0,0,.16) 7%,rgba(0,0,0,.62) 18%,#000 34%,#000 100%)!important
}
.hd-content-v150616 .hd-bp-hero-media:before{
  content:""!important;
  position:absolute!important;
  z-index:2!important;
  inset:0 auto 0 0!important;
  width:23%!important;
  pointer-events:none!important;
  background:linear-gradient(to right,#fff 0%,rgba(255,255,255,.72) 37%,rgba(255,255,255,0) 100%)!important;
  backdrop-filter:blur(1.5px)!important
}
.hd-content-v150616 .hd-bp-hero .hd-hub2-intro-text,.hd-content-v150616 .hd-bp-hero .hd-hub2-more{max-width:720px!important}
.hd-content-v150616 .hd-bp-hero .hd-hub2-more{align-self:start!important}
.hd-content-v150616 .hd-bp-pilot{margin-top:22px!important}
.hd-content-v150616 .hd-bp-pilot .hd-bp-grid{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:12px!important}
.hd-content-v150616 .hd-bp-card{
  display:grid!important;
  grid-template-columns:200px minmax(0,1fr) 18px!important;
  min-height:107px!important;
  align-items:stretch!important;
  overflow:hidden!important;
  border:1px solid var(--hd-line)!important;
  border-radius:1px!important;
  background:#fff!important;
  transition:border-color .15s ease,box-shadow .15s ease!important
}
.hd-content-v150616 .hd-bp-card:hover{border-color:rgba(15,143,149,.36)!important;box-shadow:0 8px 22px rgba(42,55,61,.055)!important}
.hd-content-v150616 .hd-bp-photo{display:block!important;width:200px!important;height:107px!important;min-height:107px!important;margin:0!important;padding:0!important;align-self:stretch!important;overflow:hidden!important;border:0!important;border-radius:0!important;background:#f5f1e9!important}
.hd-content-v150616 .hd-bp-photo img{display:block!important;width:100%!important;height:100%!important;min-height:0!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;object-fit:cover!important;object-position:center!important}
.hd-content-v150616 .hd-bp-copy{display:flex!important;padding:13px 9px 13px 11px!important;flex-direction:column!important;justify-content:center!important;min-width:0!important}
.hd-content-v150616 .hd-bp-copy strong{display:block!important;color:#243a44!important;font-size:14px!important;line-height:1.16!important}
.hd-content-v150616 .hd-bp-copy small{display:block!important;margin-top:5px!important;color:#68757a!important;font-size:11px!important;line-height:1.34!important}
.hd-content-v150616 .hd-bp-card>b{display:flex!important;padding-right:8px!important;align-items:center!important;justify-content:center!important;color:var(--hd-petrol)!important;font-size:17px!important}
.hd-content-v150616 .hd-post-previews-hub2.hd-bp-posts .hd-post-grid{grid-template-columns:repeat(3,minmax(0,1fr))!important}
.hd-content-v150616 .hd-post-previews-hub2.hd-bp-posts .hd-post-image{aspect-ratio:16/9!important}
@media(max-width:1100px){
  .hd-content-v150616 .hd-bp-hero{grid-template-columns:minmax(0,54%) minmax(0,46%)!important}
  .hd-content-v150616 .hd-bp-hero-copy{padding:22px 24px 20px 0!important}
  .hd-content-v150616 .hd-bp-brush-claim{font-size:22px!important;margin-bottom:27px!important}
  .hd-content-v150616 .hd-bp-pilot .hd-bp-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  .hd-content-v150616 .hd-bp-card{grid-template-columns:165px minmax(0,1fr) 20px!important;min-height:88px!important}
  .hd-content-v150616 .hd-bp-photo,.hd-content-v150616 .hd-bp-photo img{width:165px!important;height:88px!important;min-height:88px!important}
  .hd-content-v150616 .hd-post-previews-hub2.hd-bp-posts .hd-post-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
}
@media(max-width:760px){
  .hd-content-v150616 .hd-bp-hero{grid-template-columns:1fr!important;width:calc(100% - 24px)!important;margin-top:4px!important}
  .hd-content-v150616 .hd-bp-hero-copy{padding:18px 0 18px!important}
  .hd-content-v150616 .hd-bp-brush-claim{font-size:21px!important;margin-bottom:26px!important}
  .hd-content-v150616 .hd-bp-hero-media{aspect-ratio:600/320!important}
  .hd-content-v150616 .hd-bp-hero-media img{aspect-ratio:600/320!important}
  .hd-content-v150616 .hd-bp-hero-media:before{width:18%!important}
  .hd-content-v150616 .hd-bp-pilot .hd-bp-grid{grid-template-columns:1fr!important}
  .hd-content-v150616 .hd-bp-card{grid-template-columns:145px minmax(0,1fr) 18px!important;min-height:78px!important}
  .hd-content-v150616 .hd-bp-photo,.hd-content-v150616 .hd-bp-photo img{width:145px!important;height:78px!important;min-height:78px!important}
  .hd-content-v150616 .hd-bp-copy{padding:11px 9px 11px 11px!important}
  .hd-content-v150616 .hd-post-previews-hub2.hd-bp-posts .hd-post-grid{grid-template-columns:1fr!important}
}


/* 1.50.642 – requested micro-fix only: shorter/thinner brush, square photo fit, stronger header claim. */
@media(min-width:761px){
  .hd-logo-claim-v150622{filter:none!important;position:relative!important;isolation:isolate!important}
  .hd-logo-claim-v150622:after{content:""!important;position:absolute!important;inset:0!important;background-image:var(--hd-logo-image)!important;background-repeat:no-repeat!important;pointer-events:none!important;opacity:.72!important;z-index:1!important}
}
@media(min-width:1001px){
  .hd-logo-claim-v150622:after{background-size:220px auto!important;background-position:0 -108px!important;transform:translate(.22px,.18px)!important}
}
@media(max-width:1000px) and (min-width:761px){
  .hd-logo-claim-v150622:after{background-size:194px auto!important;background-position:0 -96px!important;transform:translate(.22px,.18px)!important}
}
.hd-content-v150616 .hd-bp-card{border-radius:1px!important;overflow:hidden!important}
.hd-content-v150616 .hd-bp-photo,
.hd-content-v150616 .hd-bp-photo img{border-radius:0!important;box-sizing:border-box!important}
.hd-content-v150616 .hd-bp-photo{justify-self:stretch!important;align-self:stretch!important}
.hd-content-v150616 .hd-bp-photo img{object-fit:cover!important;object-position:center!important}

/* 1.50.643 – underline higher, header claim visibly thicker, hub2 cards reuse level-1 image solution exactly. */
.hd-content-v150616 .hd-bp-brush-claim:after{bottom:-14px!important}
.hd-content-v150616 .hd-bp-pilot .hd-bp-grid{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:12px!important}
.hd-content-v150616 .hd-bp-card{
  display:grid!important;
  grid-template-columns:200px minmax(0,1fr)!important;
  min-height:107px!important;
  padding:0!important;
  overflow:hidden!important;
  border:1px solid rgba(63,71,75,.10)!important;
  border-radius:4px!important;
  background:#fff!important;
}
.hd-content-v150616 .hd-bp-card .hd-next-card-body{display:grid!important;grid-template-columns:minmax(0,1fr) 22px!important;gap:10px!important;align-items:center!important;min-width:0!important;padding:12px 12px 12px 11px!important}
.hd-content-v150616 .hd-bp-card .hd-next-copy strong{display:block!important;font-size:14px!important;line-height:1.16!important}
.hd-content-v150616 .hd-bp-card .hd-next-copy small{display:block!important;margin-top:5px!important;color:#68757a!important;font-size:11px!important;line-height:1.34!important}
.hd-content-v150616 .hd-bp-card .hd-next-card-body>b{color:var(--hd-petrol)!important;font-size:17px!important;text-align:right!important;font-weight:500!important}
.hd-content-v150616 .hd-bp-card .hd-next-photo{display:block!important;width:200px!important;height:107px!important;min-height:107px!important;margin:0!important;padding:0!important;border:0!important;overflow:hidden!important;border-radius:0!important;background:transparent!important;align-self:stretch!important;line-height:0!important;font-size:0!important}
.hd-content-v150616 .hd-bp-card .hd-next-photo img{display:block!important;width:200px!important;height:107px!important;min-height:107px!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;object-fit:cover!important;object-position:center!important}
@media(max-width:1100px){
  .hd-content-v150616 .hd-bp-card{grid-template-columns:165px minmax(0,1fr)!important;min-height:88px!important}
  .hd-content-v150616 .hd-bp-card .hd-next-photo,.hd-content-v150616 .hd-bp-card .hd-next-photo img{width:165px!important;height:88px!important;min-height:88px!important}
  .hd-content-v150616 .hd-bp-card .hd-next-card-body{grid-template-columns:minmax(0,1fr) 20px!important}
}
@media(max-width:760px){
  .hd-content-v150616 .hd-bp-card{grid-template-columns:145px minmax(0,1fr)!important;min-height:78px!important;border-radius:4px!important}
  .hd-content-v150616 .hd-bp-card .hd-next-photo,.hd-content-v150616 .hd-bp-card .hd-next-photo img{width:145px!important;height:78px!important;min-height:78px!important}
  .hd-content-v150616 .hd-bp-card .hd-next-card-body{grid-template-columns:minmax(0,1fr) 18px!important;padding:11px 9px 11px 11px!important}
}


/* 1.50.644 – validated delta: pilot cards use the exact level-1 card/image classes; underline slightly higher; logo claim genuinely thickened without resizing. */
.hd-content-v150616 .hd-bp-brush-claim:after{bottom:-9px!important}
@media(min-width:761px){
  .hd-logo-claim-v150622{position:relative!important;overflow:visible!important;isolation:isolate!important;filter:none!important}
  .hd-logo-claim-v150622:before,.hd-logo-claim-v150622:after{content:""!important;position:absolute!important;inset:0!important;background-image:var(--hd-logo-image)!important;background-repeat:no-repeat!important;pointer-events:none!important;opacity:.88!important;z-index:1!important}
}
@media(min-width:1001px){
  .hd-logo-claim-v150622:before,.hd-logo-claim-v150622:after{background-size:220px auto!important;background-position:0 -108px!important}
  .hd-logo-claim-v150622:before{transform:translateX(-.75px)!important}
  .hd-logo-claim-v150622:after{transform:translateX(.75px)!important}
}
@media(max-width:1000px) and (min-width:761px){
  .hd-logo-claim-v150622:before,.hd-logo-claim-v150622:after{background-size:194px auto!important;background-position:0 -96px!important}
  .hd-logo-claim-v150622:before{transform:translateX(-.65px)!important}
  .hd-logo-claim-v150622:after{transform:translateX(.65px)!important}
}

/* 1.50.645 – exact requested correction: underline back one step; real thickened logo-claim asset; pilot cards use untouched Ebene-1 card CSS and banner fills free third slot. */
.hd-content-v150616 .hd-bp-brush-claim:after{bottom:-14px!important}
@media(min-width:761px){
  .hd-logo-claim-v150622{filter:none!important}
  .hd-logo-claim-v150622:before,.hd-logo-claim-v150622:after{content:none!important;display:none!important}
}


/* 1.50.668 FINAL FOUNDATION – H&B 0.1.20 principle: central registry only, stable one-line nav, real mega panel, Hub2 long text below hero. */
@media(min-width:761px){
  .hd-head-v150616{position:relative!important;overflow:visible!important}
  .hd-head-center-v150616{position:relative!important;overflow:visible!important}
  .hd-nav-v150616{display:block!important;position:absolute!important;left:0!important;right:0!important;bottom:0!important;width:100%!important;height:36px!important;margin:0!important;padding:0 0 1px!important;background:transparent!important;border:0!important;box-shadow:none!important;transform:none!important;overflow:visible!important}
  .hd-nav-v150616>ul{display:grid!important;grid-template-columns:repeat(8,minmax(0,1fr))!important;grid-template-rows:36px!important;width:100%!important;height:36px!important;margin:0!important;padding:0!important;gap:0 10px!important;align-items:end!important;overflow:visible!important}
  .hd-nav-item{position:relative!important;display:flex!important;height:35px!important;min-width:0!important;align-items:flex-end!important;justify-content:center!important;border:0!important;white-space:nowrap!important;overflow:visible!important}
  .hd-nav-item>a{display:flex!important;min-width:0!important;height:34px!important;padding:0 0 2px!important;align-items:center!important;justify-content:center!important;font-size:clamp(10.5px,1vw,14px)!important;font-weight:700!important;line-height:1!important;white-space:nowrap!important}
  .hd-nav-world-icon{display:none!important}
  .hd-sub-toggle-v150616{display:inline-flex!important;width:16px!important;height:34px!important;margin:0 0 0 2px!important;padding:0!important;align-items:center!important;justify-content:center!important;align-self:flex-end!important}
  .hd-menu-toggle-v150616{display:none!important}
  .has-mega:hover>.hd-mega,.has-mega:focus-within>.hd-mega,.has-mega.is-sub-open>.hd-mega{display:block!important}

  .hd-mega-reference{position:absolute!important;z-index:10080!important;top:calc(100% + 1px)!important;left:var(--hd-mega-left,0)!important;right:auto!important;width:var(--hd-mega-width,min(1180px,calc(100vw - 32px)))!important;max-width:calc(100vw - 32px)!important;padding:18px 20px 14px!important;border:1px solid var(--hd-line)!important;border-radius:3px!important;background:#fff!important;box-shadow:0 18px 44px rgba(42,55,61,.15)!important;transform:none!important}
  .hd-mega-reference-head{display:flex!important;align-items:center!important;margin:0 0 13px!important;padding:0 0 10px!important;border-bottom:1px solid var(--hd-line)!important}
  .hd-mega-reference-head strong{font-size:15px!important}
  .hd-mega-columns{display:grid!important;grid-template-columns:repeat(5,minmax(0,1fr))!important;gap:18px 24px!important;align-items:start!important}
  .hd-mega-column{display:flex!important;min-width:0!important;flex-direction:column!important}
  .hd-mega-column.is-extra{display:none!important}
  .hd-mega-reference.is-expanded .hd-mega-column.is-extra{display:flex!important}
  .hd-mega-primary{display:block!important;min-height:35px!important;padding:0 0 8px!important;border-bottom:1px solid rgba(63,71,75,.15)!important;color:#263b44!important;font-size:13px!important;font-weight:800!important;line-height:1.25!important;text-decoration:none!important;white-space:normal!important}
  .hd-mega-primary:hover,.hd-mega-primary:focus-visible{color:var(--hd-petrol)!important}
  .hd-mega-secondary{display:block!important;margin:7px 0 0!important;padding:0!important;list-style:none!important}
  .hd-mega-secondary li{margin:0!important;padding:0!important}
  .hd-mega-secondary a{display:block!important;padding:4px 0!important;color:#657176!important;font-size:12.25px!important;font-weight:540!important;line-height:1.36!important;text-decoration:none!important;white-space:normal!important}
  .hd-mega-secondary a:hover,.hd-mega-secondary a:focus-visible{color:var(--hd-petrol)!important;text-decoration:underline!important;text-underline-offset:3px!important}
  .hd-mega-secondary-all a{color:#344f58!important;font-weight:760!important}
  .hd-mega-more-toggle,.hd-mega-all{display:flex!important;width:100%!important;margin:13px 0 0!important;padding:10px 2px 1px!important;align-items:center!important;justify-content:space-between!important;border:0!important;border-top:1px solid var(--hd-line)!important;background:transparent!important;color:var(--hd-petrol)!important;font-size:11px!important;font-weight:800!important;text-align:left!important;cursor:pointer!important}
}
@media(max-width:900px) and (min-width:761px){
  .hd-nav-v150616>ul{gap:0 4px!important}
  .hd-nav-item>a{font-size:10.5px!important}
  .hd-sub-toggle-v150616{width:12px!important;margin-left:1px!important}
  .hd-mega-columns{grid-template-columns:repeat(5,minmax(0,1fr))!important;gap:14px 16px!important}
  .hd-mega-primary{font-size:12px!important}
  .hd-mega-secondary a{font-size:11.5px!important}
}
@media(max-width:760px){
  .hd-nav-v150616{position:static!important;display:none!important;width:100%!important;height:auto!important;margin:0!important;padding:3px 0 8px!important;border-top:1px solid var(--hd-line)!important;background:#f5f1e9!important;box-shadow:none!important;transform:none!important;overflow:visible!important}
  .hd-header-v150616.is-open .hd-nav-v150616{display:block!important}
  .hd-nav-v150616>ul{display:block!important;width:100%!important;height:auto!important}
  .hd-nav-item{display:grid!important;grid-template-columns:1fr 40px!important;height:auto!important;border-bottom:1px solid var(--hd-line)!important;white-space:normal!important}
  .hd-nav-item>a{justify-content:flex-start!important;height:auto!important;padding:13px 4px!important;font-size:13px!important}
  .hd-sub-toggle-v150616{display:flex!important;width:40px!important;height:44px!important;margin:0!important}
  .hd-menu-toggle-v150616{display:block!important}
  .hd-mega-reference{position:static!important;grid-column:1/-1!important;width:100%!important;max-width:none!important;padding:7px 4px 13px!important;border:0!important;border-radius:0!important;box-shadow:none!important;transform:none!important}
  .has-mega:hover>.hd-mega-reference,.has-mega:focus-within>.hd-mega-reference{display:none!important}
  .has-mega.is-sub-open>.hd-mega-reference{display:block!important}
  .hd-mega-columns{display:grid!important;grid-template-columns:1fr!important;gap:0!important}
  .hd-mega-column{padding:8px 8px 9px!important;border-bottom:1px solid rgba(63,71,75,.10)!important}
  .hd-mega-column.is-extra{display:none!important}
  .hd-mega-reference.is-expanded .hd-mega-column.is-extra{display:flex!important}
  .hd-mega-reference .hd-mega-primary{display:block!important;min-height:0!important;padding:0 0 4px!important;border:0!important;color:#263b44!important;font-size:13.5px!important;font-weight:800!important;line-height:1.25!important;text-decoration:none!important}
  .hd-mega-reference .hd-mega-secondary{display:block!important;margin:2px 0 0!important;padding:0!important;list-style:none!important}
  .hd-mega-reference .hd-mega-secondary li{display:block!important;margin:0!important;padding:0!important}
  .hd-mega-reference .hd-mega-secondary a{display:block!important;padding:4px 0!important;color:#657176!important;font-size:12px!important;font-weight:540!important;line-height:1.36!important;text-decoration:none!important}
  .hd-mega-reference .hd-mega-secondary-all a{color:#344f58!important;font-weight:760!important}
  .hd-mega-reference .hd-mega-more-toggle,.hd-mega-reference .hd-mega-all{display:flex!important;box-sizing:border-box!important;width:100%!important;margin:8px 0 0!important;padding:10px 8px 2px!important;align-items:center!important;justify-content:space-between!important;border:0!important;border-top:1px solid var(--hd-line)!important;border-radius:0!important;background:transparent!important;box-shadow:none!important;color:var(--hd-petrol)!important;font:inherit!important;font-size:11px!important;font-weight:800!important;text-decoration:none!important;text-align:left!important;appearance:none!important;-webkit-appearance:none!important;cursor:pointer!important}
}


/* final geometry hardening: historical world-specific flyout offsets must not override viewport-safe positioning. */
@media(min-width:761px){
  .hd-nav-item.has-mega>.hd-mega-reference{
    left:var(--hd-mega-left,0)!important;
    right:auto!important;
    width:var(--hd-mega-width,min(1180px,calc(100vw - 32px)))!important;
    max-width:calc(100vw - 32px)!important;
    box-sizing:border-box!important;
    transform:none!important
  }
}
@media(max-width:760px){
  .hd-header-v150616,.hd-head-v150616,.hd-search-v150616,.hd-search-v150616 input,.hd-menu-toggle-v150616,.hd-nav-v150616,.hd-mega-reference{box-sizing:border-box!important}
  .hd-header-v150616{width:100%!important;margin:0!important;overflow-x:clip!important}
  .hd-head-v150616{width:100%!important;max-width:100%!important;margin:0!important}
  .hd-search-v150616{width:100%!important;max-width:100%!important}
  .hd-search-v150616 input{width:100%!important;max-width:100%!important}
  .hd-mega-reference{width:100%!important;max-width:100%!important}
}

/* Hub2 text contract: short Hero intro only; editorial lead and accordion below a fixed hero. */
.hd-content-v150616 .hd-bp-hero{align-items:stretch!important}
.hd-content-v150616 .hd-hub2-hero-intro{max-width:560px!important;color:#5d686e!important;font-size:15px!important;line-height:1.62!important}
.hd-content-v150616 .hd-hub2-hero-intro p{margin:0!important}
.hd-hub2-longcopy{width:min(calc(100% - 72px),var(--hd-content))!important;margin:8px auto 0!important;padding:10px 0 12px!important;border-bottom:1px solid rgba(63,71,75,.10)!important}
.hd-hub2-longcopy-lead,.hd-hub2-longcopy .hd-hub2-more{width:min(100%,900px)!important;margin-left:auto!important;margin-right:auto!important}
.hd-hub2-longcopy-lead{color:#56656a!important;font-size:15px!important;line-height:1.58!important}
.hd-hub2-longcopy-lead p{margin:0!important}
.hd-content-v150616 .hd-hub2-longcopy-benchmark-v150698 .hd-hub2-longcopy-lead{margin-top:0!important;padding:15px 17px!important;border-radius:9px!important;background:#eef8f7!important;color:#31484e!important;box-shadow:inset 0 0 0 1px rgba(47,150,157,.10)!important;font-size:15px!important;line-height:1.58!important;text-align:left!important}
.hd-content-v150616 .hd-hub2-longcopy-benchmark-v150698 .hd-hub2-more>div>p{margin:0 0 11px!important}
.hd-content-v150616 .hd-hub2-longcopy-benchmark-v150698 .hd-hub2-more>div>p:last-child{margin-bottom:0!important}
.hd-hub2-longcopy .hd-hub2-more{margin-top:4px!important;border-top:0!important}
.hd-hub2-longcopy .hd-hub2-more summary{display:block!important;width:max-content!important;max-width:100%!important;margin:0 auto!important;text-align:center!important}
@media(min-width:1101px){
  .hd-content-v150616 .hd-bp-hero{grid-template-columns:minmax(0,52%) minmax(0,48%)!important;min-height:320px!important}
  .hd-content-v150616 .hd-bp-hero-copy{padding:26px 30px 24px 0!important;justify-content:center!important}
  .hd-content-v150616 .hd-bp-hero-media{min-height:320px!important}
  .hd-content-v150616 .hd-bp-hero-media img{min-height:320px!important;aspect-ratio:600/320!important;object-fit:cover!important}
}
@media(max-width:1100px){
  .hd-content-v150616 .hd-bp-hero{grid-template-columns:1fr!important;min-height:0!important}
  .hd-content-v150616 .hd-bp-hero-copy{order:1!important;padding:20px 0 17px!important}
  .hd-content-v150616 .hd-bp-hero-media{order:2!important;width:min(100%,600px)!important;max-width:600px!important;min-height:0!important;margin:0!important;aspect-ratio:600/320!important}
  .hd-content-v150616 .hd-bp-hero-media img{width:100%!important;height:auto!important;min-height:0!important;aspect-ratio:600/320!important;object-fit:cover!important;-webkit-mask-image:none!important;mask-image:none!important}
  .hd-content-v150616 .hd-bp-hero-media:before{display:none!important}
  .hd-hub2-longcopy{width:min(calc(100% - 44px),var(--hd-content))!important;margin-top:8px!important;padding-top:10px!important;padding-bottom:12px!important}
}
@media(max-width:760px){
  .hd-content-v150616 .hd-bp-hero{width:calc(100% - 24px)!important}
  .hd-content-v150616 .hd-bp-hero-copy{padding:17px 0 15px!important}
  .hd-content-v150616 .hd-hub2-hero-intro{font-size:14px!important;line-height:1.58!important}
  .hd-hub2-longcopy{width:calc(100% - 24px)!important;margin-top:7px!important;padding:9px 0 11px!important}
  .hd-hub2-longcopy-lead,.hd-hub2-longcopy .hd-hub2-more p{font-size:14px!important;line-height:1.55!important}
}

/* 1.50.683 – zentraler Hub2-Hero ohne Zoom/Upscaling.
   Ein einziges Bildformat auf Desktop/Tablet/Mobil: 600:320.
   600px-Quellen werden niemals ueber 600px Breite dargestellt; groessere Master nur heruntergerechnet.
   Das Bild bleibt vollstaendig sichtbar (contain statt cover), der Textschutz bleibt dynamisch. */
.hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed{
  --hd-hub2-fullbleed-bg:#f5f1e9;
  --hd-hub2-fullbleed-pad:clamp(26px,4vw,64px);
  position:relative!important;
  overflow:hidden!important;
  background:var(--hd-hub2-fullbleed-bg)!important;
  border-radius:0 2px 2px 0!important
}
.hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-brush-claim{
  align-self:flex-start!important;
  width:max-content!important;
  max-width:100%!important
}
.hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-brush-claim:after{
  left:1%!important;
  width:98%!important;
  height:10px!important;
  background-size:100% 100%!important
}
@media(min-width:901px){
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed{
    display:grid!important;
    grid-template-columns:minmax(0,1fr) min(52%,600px)!important;
    grid-template-rows:auto!important;
    min-height:0!important;
    align-items:stretch!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-media{
    position:relative!important;
    z-index:1!important;
    grid-column:2!important;
    grid-row:1!important;
    display:block!important;
    justify-self:end!important;
    align-self:stretch!important;
    width:100%!important;
    max-width:600px!important;
    height:auto!important;
    min-height:0!important;
    margin:0!important;
    aspect-ratio:600/320!important;
    overflow:hidden!important;
    background:var(--hd-hub2-fullbleed-bg)!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-media img{
    display:block!important;
    width:100%!important;
    max-width:600px!important;
    height:100%!important;
    min-height:0!important;
    aspect-ratio:600/320!important;
    object-fit:contain!important;
    object-position:center!important;
    border-radius:0 2px 2px 0!important;
    -webkit-mask-image:none!important;
    mask-image:none!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-media:before{
    content:""!important;
    position:absolute!important;
    z-index:2!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    display:block!important;
    width:96px!important;
    pointer-events:none!important;
    background:linear-gradient(90deg,var(--hd-hub2-fullbleed-bg) 0%,rgba(245,241,233,.92) 26%,rgba(245,241,233,.50) 58%,rgba(245,241,233,0) 100%)!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-copy{
    position:absolute!important;
    z-index:3!important;
    left:0!important;
    top:0!important;
    bottom:0!important;
    display:flex!important;
    box-sizing:border-box!important;
    width:max-content!important;
    min-width:35%!important;
    max-width:48%!important;
    min-height:100%!important;
    padding:20px 18px 38px var(--hd-hub2-fullbleed-pad)!important;
    flex-direction:column!important;
    justify-content:center!important;
    background:var(--hd-hub2-fullbleed-bg)!important;
    overflow:visible!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-copy:after{
    content:""!important;
    position:absolute!important;
    z-index:-1!important;
    top:0!important;
    right:-150px!important;
    bottom:0!important;
    width:150px!important;
    display:block!important;
    pointer-events:none!important;
    background:linear-gradient(90deg,rgba(245,241,233,1) 0%,rgba(245,241,233,.96) 20%,rgba(245,241,233,.72) 48%,rgba(245,241,233,.30) 75%,rgba(245,241,233,0) 100%)!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-brush-claim{
    margin:0 0 34px!important;
    padding:0 5px 0 2px!important;
    font-size:clamp(24px,2vw,28px)!important;
    line-height:1!important;
    transform:translateY(-12px) rotate(-1.2deg)!important;
    white-space:nowrap!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-brush-claim:after{bottom:-10px!important}
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-copy h1{
    width:max-content!important;
    max-width:none!important;
    margin:0 0 8px!important;
    overflow:visible!important;
    color:#17313c!important;
    font-size:clamp(40px,4vw,62px)!important;
    line-height:1.02!important;
    white-space:nowrap!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-hub2-hero-intro,
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-hub2-hero-intro p{
    width:max-content!important;
    max-width:none!important;
    margin:0!important;
    color:#31444c!important;
    font-size:clamp(13px,1.05vw,16px)!important;
    line-height:1.48!important;
    letter-spacing:-.08px!important;
    white-space:nowrap!important;
    overflow:visible!important
  }
}
@media(min-width:901px) and (max-width:1180px){
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-copy{
    min-width:42%!important;
    max-width:58%!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-copy:after{
    right:-120px!important;
    width:120px!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-copy h1{
    font-size:clamp(38px,5vw,52px)!important
  }
}
@media(max-width:900px){
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed{
    display:grid!important;
    grid-template-columns:1fr!important;
    grid-template-rows:auto auto!important;
    width:min(calc(100% - 40px),var(--hd-content))!important;
    min-height:0!important;
    margin:4px auto 0!important;
    overflow:hidden!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-copy{
    position:relative!important;
    z-index:2!important;
    order:1!important;
    display:flex!important;
    width:100%!important;
    max-width:none!important;
    min-width:0!important;
    padding:22px 20px 21px!important;
    flex-direction:column!important;
    background:var(--hd-hub2-fullbleed-bg)!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-copy:after{display:none!important;content:none!important}
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-brush-claim{
    margin:0 0 30px!important;
    font-size:23px!important;
    transform:translateY(-6px) rotate(-1.2deg)!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-brush-claim:after{bottom:-10px!important}
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-copy h1{
    width:auto!important;
    max-width:100%!important;
    margin:0 0 8px!important;
    color:#17313c!important;
    font-size:clamp(34px,9vw,48px)!important;
    line-height:1.02!important;
    white-space:normal!important;
    overflow-wrap:normal!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-hub2-hero-intro,
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-hub2-hero-intro p{
    width:max-content!important;
    max-width:100%!important;
    margin:0!important;
    font-size:clamp(11px,2.65vw,14px)!important;
    line-height:1.5!important;
    letter-spacing:-.10px!important;
    white-space:nowrap!important;
    overflow:visible!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-media{
    position:relative!important;
    z-index:1!important;
    order:2!important;
    display:block!important;
    justify-self:center!important;
    width:min(100%,600px)!important;
    max-width:600px!important;
    min-height:0!important;
    height:auto!important;
    margin:0 auto!important;
    aspect-ratio:600/320!important;
    overflow:hidden!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-media img{
    display:block!important;
    width:100%!important;
    max-width:600px!important;
    height:100%!important;
    min-height:0!important;
    aspect-ratio:600/320!important;
    object-fit:contain!important;
    object-position:center!important;
    -webkit-mask-image:none!important;
    mask-image:none!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-media:before{display:none!important;content:none!important}
}
@media(max-width:760px){
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed{width:calc(100% - 24px)!important}
  .hd-content-v150616 .hd-bp-hero.hd-hub2-hero-fullbleed .hd-bp-hero-copy{padding:20px 16px 18px!important}
}

/* 1.50.683 – kompakter Hub2-Kategorietext nach der bewaehrten Pferdeatelier-Logik:
   ein sichtbarer Fliesstextblock um ca. 50–55 Woerter, danach nur der kleine Chevron. */
.hd-hub2-longcopy .hd-hub2-more{margin-top:3px!important;padding:0!important;border:0!important}
.hd-hub2-longcopy .hd-hub2-more summary{
  display:flex!important;align-items:center!important;justify-content:center!important;width:28px!important;height:18px!important;min-width:28px!important;
  margin:0 auto!important;padding:0!important;color:#0f7f84!important;cursor:pointer!important;list-style:none!important;font-size:0!important;line-height:1!important
}
.hd-hub2-longcopy .hd-hub2-more summary::-webkit-details-marker{display:none!important}
.hd-hub2-longcopy .hd-hub2-more summary:after{
  content:""!important;display:block!important;width:7px!important;height:7px!important;margin:-3px 0 0!important;padding:0!important;
  border:0!important;border-right:1.7px solid currentColor!important;border-bottom:1.7px solid currentColor!important;border-radius:0!important;
  background:transparent!important;transform:rotate(45deg)!important;transform-origin:center!important;transition:transform .16s ease!important
}
.hd-hub2-longcopy .hd-hub2-more[open] summary:after{content:""!important;transform:rotate(225deg)!important;margin:3px 0 -3px!important}
.hd-hub2-longcopy .hd-hub2-more>div{margin-top:3px!important;padding-top:5px!important;border-top:0!important}
.hd-hub2-longcopy .hd-hub2-more>div>p{margin:0!important}



/* Metal pilot: visible lead is one true text block, no paragraph gap. */
.hd-hub2-longcopy-lead>p{display:block!important;margin:0!important;padding:0!important;white-space:normal!important}


/* 1.50.685 ALL HUB2 – scene master keeps its full horizontal scene in a wide right-hand field:
   use the best available original/master; keep the horizontal scene; crop only top/bottom.
   The image field stays wide while the copy/fade overlaps only a narrow edge, so the scene remains visibly intact.
   Static natural dimensions cap rendering so nothing is ever enlarged. */
@media(min-width:901px){
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve{
    position:relative!important;
    display:block!important;
    width:min(calc(100% - 40px),var(--hd-content))!important;
    height:min(clamp(220px,22vw,300px),var(--hd-scene-h))!important;
    min-height:min(220px,var(--hd-scene-h))!important;
    margin:4px auto 0!important;
    overflow:hidden!important;
    background:#f5f1e9!important;
    border-radius:0 2px 2px 0!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-media{
    position:absolute!important;
    z-index:1!important;
    right:0!important;
    top:0!important;
    bottom:0!important;
    left:auto!important;
    display:block!important;
    width:min(72%,var(--hd-scene-w))!important;
    max-width:var(--hd-scene-w)!important;
    height:100%!important;
    min-height:0!important;
    margin:0!important;
    aspect-ratio:auto!important;
    overflow:hidden!important;
    background:#f5f1e9!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-media img{
    display:block!important;
    width:100%!important;
    max-width:var(--hd-scene-w)!important;
    height:100%!important;
    min-height:0!important;
    aspect-ratio:auto!important;
    object-fit:cover!important;
    object-position:center center!important;
    border-radius:0 2px 2px 0!important;
    -webkit-mask-image:none!important;
    mask-image:none!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-media:before{display:none!important;content:none!important}
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-copy{
    position:absolute!important;
    z-index:3!important;
    left:0!important;top:0!important;bottom:0!important;
    display:flex!important;
    box-sizing:border-box!important;
    width:max-content!important;
    min-width:35%!important;
    max-width:48%!important;
    min-height:100%!important;
    padding:16px 18px 28px var(--hd-hub2-fullbleed-pad)!important;
    flex-direction:column!important;
    justify-content:center!important;
    background:#f5f1e9!important;
    overflow:visible!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-copy:after{
    content:""!important;
    position:absolute!important;
    z-index:-1!important;
    top:0!important;right:-64px!important;bottom:0!important;
    width:64px!important;
    display:block!important;
    pointer-events:none!important;
    background:linear-gradient(90deg,rgba(245,241,233,1) 0%,rgba(245,241,233,.96) 22%,rgba(245,241,233,.70) 50%,rgba(245,241,233,.28) 76%,rgba(245,241,233,0) 100%)!important
  }
}
@media(min-width:901px) and (max-width:1180px){
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-copy{min-width:42%!important;max-width:58%!important}
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-copy:after{right:-56px!important;width:56px!important}
}
@media(max-width:900px){
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve{
    display:grid!important;
    grid-template-columns:1fr!important;
    grid-template-rows:auto auto!important;
    width:min(calc(100% - 40px),var(--hd-content))!important;
    min-height:0!important;
    margin:4px auto 0!important;
    overflow:hidden!important;
    background:#f5f1e9!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-copy{
    position:relative!important;
    z-index:2!important;
    order:1!important;
    box-sizing:border-box!important;
    width:100%!important;
    max-width:none!important;
    min-width:0!important;
    padding:22px 20px 21px!important;
    background:#f5f1e9!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-copy:after{display:none!important;content:none!important}
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-media{
    position:relative!important;
    z-index:1!important;
    order:2!important;
    width:100%!important;
    max-width:none!important;
    height:auto!important;
    min-height:0!important;
    margin:0!important;
    aspect-ratio:var(--hd-scene-ratio)!important;
    overflow:hidden!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-media img{
    display:block!important;
    width:100%!important;
    max-width:var(--hd-scene-w)!important;
    height:100%!important;
    min-height:0!important;
    aspect-ratio:auto!important;
    object-fit:cover!important;
    object-position:center center!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-media:before{display:none!important;content:none!important}
}
@media(max-width:900px){
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve.hd-hub2-scene-native600 .hd-bp-hero-media{
    width:min(100%,var(--hd-scene-w))!important;max-width:var(--hd-scene-w)!important;justify-self:center!important;aspect-ratio:var(--hd-scene-ratio)!important
  }
}
@media(max-width:760px){
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve{width:calc(100% - 24px)!important}
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve .hd-bp-hero-copy{padding:20px 16px 18px!important}
}

@media(min-width:901px){
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve.hd-hub2-scene-native600{
    height:var(--hd-scene-h)!important;min-height:var(--hd-scene-h)!important
  }
  .hd-content-v150616 .hd-bp-hero.hd-hub2-scene-preserve.hd-hub2-scene-native600 .hd-bp-hero-media{
    width:var(--hd-scene-w)!important;max-width:var(--hd-scene-w)!important;height:var(--hd-scene-h)!important;top:50%!important;bottom:auto!important;transform:translateY(-50%)!important
  }
}


/* 1.50.686 – Kettenhemdflechten pilot for the next category depth. */
.hd-content-v150616 .hd-catlevel-intro{width:min(calc(100% - 72px),var(--hd-content));margin:8px auto 0;padding:20px 0 10px;border-bottom:1px solid rgba(63,71,75,.10);text-align:center}
.hd-content-v150616 .hd-catlevel-intro-inner{width:min(100%,860px);margin:0 auto}
.hd-content-v150616 .hd-catlevel-title-icon{display:grid;width:46px;height:46px;margin:0 auto 9px;place-items:center;border-radius:50%;background:#eef8f7;color:var(--hd-petrol)}
.hd-content-v150616 .hd-catlevel-title-icon svg{width:24px;height:24px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.hd-content-v150616 .hd-catlevel-intro h1{margin:0!important;color:#17313c!important;font-size:clamp(36px,4vw,50px)!important;font-weight:820!important;line-height:1.04!important;text-align:center!important}
.hd-content-v150616 .hd-catlevel-intro h1 .hd-catlevel-title-second{display:inline-block;font-weight:760!important}
.hd-content-v150616 .hd-catlevel-topics>header h2{font-size:22px!important;line-height:1.2!important;margin-bottom:12px!important}
.hd-content-v150616 .hd-catlevel-lead{margin:14px auto 0!important;padding:15px 17px!important;border-radius:9px!important;background:#eef8f7!important;color:#31484e!important;box-shadow:inset 0 0 0 1px rgba(47,150,157,.10)!important;font-size:15px!important;line-height:1.58!important;text-align:left}
.hd-content-v150616 .hd-catlevel-intro-schuhmacherei-v150695 .hd-catlevel-lead{margin-top:14px!important;padding:15px 17px!important;border-radius:9px;background:#eef8f7!important;color:#31484e!important;box-shadow:inset 0 0 0 1px rgba(47,150,157,.10);font-size:15px!important;line-height:1.58!important}
.hd-content-v150616 .hd-catlevel-more{margin:3px auto 0;padding:0;border:0;background:transparent}
.hd-content-v150616 .hd-catlevel-more summary{display:block;width:28px;height:20px;margin:0 auto;cursor:pointer;list-style:none;position:relative}
.hd-content-v150616 .hd-catlevel-more summary::-webkit-details-marker{display:none}
.hd-content-v150616 .hd-catlevel-more summary:after{content:"";position:absolute;left:50%;top:4px;width:7px;height:7px;border-right:2px solid var(--hd-petrol);border-bottom:2px solid var(--hd-petrol);transform:translateX(-50%) rotate(45deg)}
.hd-content-v150616 .hd-catlevel-more[open] summary:after{top:8px;transform:translateX(-50%) rotate(225deg)}
.hd-content-v150616 .hd-catlevel-more>div{margin-top:3px;padding-top:2px}
.hd-content-v150616 .hd-catlevel-more p{margin:0;color:#56656a;font-size:15px;line-height:1.55;text-align:left}
.hd-content-v150616 .hd-catlevel-more p+p{margin-top:12px!important}
.hd-content-v150616 .hd-catlevel-topics{margin-top:18px!important}
.hd-content-v150616 .hd-catlevel-topics-cont{margin-top:12px!important}
.hd-content-v150616 .hd-catlevel-grid{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:10px!important}
.hd-content-v150616 .hd-catlevel-grid .hd-next-card{grid-column:auto!important;min-height:98px!important;padding:14px 13px!important;grid-template-columns:40px minmax(0,1fr) 16px!important;gap:11px!important;border-radius:7px!important;border-color:rgba(47,150,157,.18)!important;background:#fff!important;box-shadow:0 2px 10px rgba(23,49,60,.035)!important}
.hd-content-v150616 .hd-catlevel-grid .hd-next-card:hover{border-color:rgba(47,150,157,.32)!important;box-shadow:0 4px 14px rgba(23,49,60,.055)!important;transform:translateY(-1px)}
.hd-content-v150616 .hd-catlevel-grid .hd-next-icon{width:40px!important;height:40px!important}
.hd-content-v150616 .hd-catlevel-grid .hd-next-icon svg{width:20px!important;height:20px!important}
.hd-content-v150616 .hd-catlevel-grid .hd-next-card strong{font-size:16px!important;line-height:1.16!important;font-weight:790!important;color:#17313c!important}
.hd-content-v150616 .hd-catlevel-grid .hd-next-card small{margin-top:5px!important;font-size:12.5px!important;line-height:1.3!important;color:#647176!important}
.hd-content-v150616 .hd-catlevel-grid .hd-next-card>b{font-size:17px!important}
.hd-content-v150616 .hd-catlevel-products{margin-top:16px!important}
.hd-content-v150616 .hd-catlevel-products>header{margin-bottom:9px!important}
.hd-content-v150616 .hd-catlevel-products>header>span{color:#8b7557;font-size:8px;font-weight:800;letter-spacing:.09em;text-transform:uppercase}
.hd-content-v150616 .hd-catlevel-products>header h2{font-size:20px!important}
.hd-content-v150616 .hd-catlevel-product-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.hd-content-v150616 .hd-catlevel-product-grid .hd-next-partner-product{grid-column:auto!important;height:84px!important}
.hd-content-v150616 .hd-catlevel-banner{margin-top:14px!important}
.hd-content-v150616 .hd-catlevel-banner .hd-next-partner-banner{grid-column:auto!important}
.hd-content-v150616 .hd-catlevel-posts{margin-top:18px!important}
.hd-content-v150616 .hd-catlevel-posts .hd-post-grid{grid-template-columns:repeat(4,minmax(0,1fr))!important}
.hd-content-v150616 .hd-catlevel-posts .hd-post-card>div{padding:11px 12px 13px!important}
.hd-content-v150616 .hd-catlevel-posts .hd-post-card h3{font-size:14px!important;line-height:1.2!important}
.hd-content-v150616 .hd-catlevel-posts .hd-post-card p{font-size:11px!important;line-height:1.42!important}
@media(max-width:1000px){
  .hd-content-v150616 .hd-catlevel-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  .hd-content-v150616 .hd-catlevel-product-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
  .hd-content-v150616 .hd-catlevel-product-grid .hd-next-partner-product:last-child:nth-child(odd){grid-column:1/-1!important}
  .hd-content-v150616 .hd-catlevel-posts .hd-post-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
}
@media(max-width:760px){
  .hd-content-v150616 .hd-catlevel-intro{width:calc(100% - 24px);padding:16px 0 8px}
  .hd-content-v150616 .hd-catlevel-title-icon{width:42px;height:42px;margin-bottom:8px}
  .hd-content-v150616 .hd-catlevel-intro h1{font-size:clamp(34px,9vw,43px)!important}
  .hd-content-v150616 .hd-catlevel-grid .hd-next-card{min-height:92px!important;padding:13px!important}
  .hd-content-v150616 .hd-catlevel-grid .hd-next-card strong{font-size:16px!important}
  .hd-content-v150616 .hd-catlevel-grid .hd-next-card small{font-size:13px!important}
  .hd-content-v150616 .hd-catlevel-lead,.hd-content-v150616 .hd-catlevel-more p{font-size:14px!important;line-height:1.52!important}
  .hd-content-v150616 .hd-catlevel-grid,.hd-content-v150616 .hd-catlevel-product-grid,.hd-content-v150616 .hd-catlevel-posts .hd-post-grid{grid-template-columns:1fr!important}
  .hd-content-v150616 .hd-catlevel-product-grid .hd-next-partner-product:last-child:nth-child(odd){grid-column:auto!important}
}}

/* 1.50.715: ruhige, native FAQ-Akkordeons ohne JavaScript. */
.hd-faq-v150715{width:min(calc(100% - 48px),980px);margin:28px auto 72px;color:#31444c}
.hd-faq-intro-v150715{max-width:760px;margin:0 0 34px!important;color:#56656b;font-size:16px!important;line-height:1.6!important}
.hd-faq-section-v150715{margin:0 0 38px}.hd-faq-section-v150715 h2{margin:0 0 13px!important;color:#17313c!important;font-size:24px!important;font-weight:800!important;line-height:1.2!important}
.hd-faq-list-v150715{border-top:1px solid rgba(63,71,75,.14)}
.hd-faq-item-v150715{margin:0!important;border-bottom:1px solid rgba(63,71,75,.14);background:#fff}
.hd-faq-item-v150715 summary{position:relative;display:flex;min-height:60px;margin:0!important;padding:17px 46px 17px 2px;align-items:center;cursor:pointer;list-style:none;color:#253a43;font-size:15px;font-weight:720;line-height:1.4}
.hd-faq-item-v150715 summary::-webkit-details-marker{display:none}.hd-faq-item-v150715 summary::marker{display:none;content:""}
.hd-faq-item-v150715 summary b{position:absolute;right:8px;top:50%;width:18px;height:18px;transform:translateY(-50%)}
.hd-faq-item-v150715 summary b:before,.hd-faq-item-v150715 summary b:after{content:"";position:absolute;left:2px;top:8px;width:14px;height:2px;border-radius:2px;background:var(--hd-petrol);transition:transform .16s ease}
.hd-faq-item-v150715 summary b:after{transform:rotate(90deg)}.hd-faq-item-v150715[open] summary b:after{transform:rotate(0)}
.hd-faq-item-v150715 summary:hover,.hd-faq-item-v150715 summary:focus-visible{color:var(--hd-petrol-deep);outline:0}
.hd-faq-answer-v150715{padding:0 46px 18px 2px}.hd-faq-answer-v150715 p{max-width:820px;margin:0!important;color:#59686e;font-size:14.5px!important;line-height:1.62!important}
@media(max-width:760px){.hd-faq-v150715{width:calc(100% - 30px);margin-top:20px;margin-bottom:54px}.hd-faq-intro-v150715{margin-bottom:28px!important;font-size:15px!important}.hd-faq-section-v150715{margin-bottom:32px}.hd-faq-section-v150715 h2{font-size:21px!important}.hd-faq-item-v150715 summary{min-height:56px;padding:15px 40px 15px 0;font-size:14.5px}.hd-faq-answer-v150715{padding:0 36px 16px 0}.hd-faq-answer-v150715 p{font-size:14px!important}}

/* 1.50.730: auch native ListingHive/WordPress-Inhaltsseiten auf derselben 1200-px-Aussenachse.
   Die Regel steht bewusst am Ende, damit alte Theme-Shell-Margins sie nicht ueberstimmen. */
body.pftk-design-profile-hobby-depot.hd-listinghive-v150616:not(.hd-home-v150616) .site-content{
  box-sizing:border-box!important;
  width:min(calc(100% - 72px),1200px)!important;
  max-width:1200px!important;
  margin-left:auto!important;
  margin-right:auto!important
}
/* Glossar-Einzelseiten hatten historisch eine feste 1240-px-Achse.
   Diese eine Altbreite wird zentral auf die neue Body-Obergrenze gekappt. */
body.pftk-design-profile-hobby-depot .hdg-single{max-width:1200px!important}
@media(max-width:760px){
  body.pftk-design-profile-hobby-depot.hd-listinghive-v150616:not(.hd-home-v150616) .site-content{
    width:calc(100% - 24px)!important;
    max-width:none!important
  }
}


/* 1.50.735: globale Hobby-Depot-AJAX-Suche mit vier getrennten Ergebniswelten. */
.hd-search-v150616{z-index:10030}
.hd-main-search-results-v150732{position:absolute;z-index:10050;top:calc(100% + 7px);left:0;right:auto;width:min(1180px,calc(100vw - 32px));max-width:none;margin:0;background:#fff;box-shadow:0 16px 38px rgba(31,45,51,.16)}
.hd-main-search-results-v150732:empty{display:none}.hd-main-search-loading-v150732{padding:16px;border:1px solid rgba(63,71,75,.18);background:#fff;color:#647077;font-size:13px;text-align:center}
.hd-main-search-shell-v150732{overflow:hidden;border:1px solid rgba(63,71,75,.18);border-radius:5px;background:#fff}.hd-main-search-grid-v150732{display:grid;grid-template-columns:repeat(4,minmax(0,1fr))}
.hd-main-search-group-v150732{min-width:0;padding:14px 0 10px}.hd-main-search-group-v150732+.hd-main-search-group-v150732{border-left:1px solid rgba(63,71,75,.12)}
.hd-main-search-label-v150732{padding:0 14px 8px;color:var(--hd-petrol-deep);font-size:10px;font-weight:850;letter-spacing:.1em;text-transform:uppercase}.hd-main-search-result-v150732{display:block;padding:8px 14px;color:#34464d!important;font-size:12.5px;font-weight:650;line-height:1.3;text-decoration:none!important}.hd-main-search-result-v150732:hover,.hd-main-search-result-v150732:focus-visible{background:#eef8f7;color:var(--hd-petrol-deep)!important;outline:0}.hd-main-search-empty-v150732{padding:8px 14px;color:#8a9296;font-size:12px}.hd-main-search-all-v150732{grid-column:1/-1;display:block;padding:11px 14px;border-top:1px solid rgba(63,71,75,.13);color:var(--hd-petrol-deep)!important;font-size:11.5px;font-weight:800;text-align:right;text-decoration:none!important}.hd-main-search-all-v150732:hover{text-decoration:underline!important;text-underline-offset:3px}
.hd-search-page-v150732{width:min(calc(100% - 72px),var(--hd-content));margin:24px auto 72px}.hd-search-page-head-v150732{margin:0 0 24px;padding-bottom:16px;border-bottom:1px solid var(--hd-line)}.hd-search-page-head-v150732>span{color:var(--hd-petrol-deep);font-size:10px;font-weight:850;letter-spacing:.12em}.hd-search-page-head-v150732 h1{margin:5px 0 7px;color:#17313c!important;font-size:clamp(30px,3vw,44px)!important}.hd-search-page-head-v150732 p{margin:0;color:#657078;font-size:14px}.hd-search-page-grid-v150732{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.hd-search-page-group-v150732{border:1px solid var(--hd-line);border-radius:5px;background:#fff;padding:18px}.hd-search-page-group-v150732 h2{margin:0 0 11px;color:#17313c!important;font-size:20px!important}.hd-search-page-list-v150732{display:grid}.hd-search-page-list-v150732 a{display:grid;grid-template-columns:minmax(0,1fr) 20px;gap:10px;padding:10px 0;border-top:1px solid rgba(63,71,75,.1);color:#34464d!important;font-size:13.5px;font-weight:650;text-decoration:none!important}.hd-search-page-list-v150732 a:first-child{border-top:0}.hd-search-page-list-v150732 a b{color:var(--hd-petrol);text-align:right}.hd-search-page-list-v150732 a:hover,.hd-search-page-list-v150732 a:focus-visible{color:var(--hd-petrol-deep)!important;outline:0}.hd-search-page-empty-v150732{margin:0;color:#8a9296;font-size:13px}
.hd-hf-banner-v150732{margin-top:18px!important;margin-bottom:6px!important}.hd-hf-banner-v150732 .hd-mag-grid-ad-v150721{padding-top:15px!important}
@media(max-width:900px){.hd-main-search-grid-v150732{grid-template-columns:repeat(2,minmax(0,1fr))}.hd-main-search-group-v150732:nth-child(3){border-left:0;border-top:1px solid rgba(63,71,75,.12)}.hd-main-search-group-v150732:nth-child(4){border-top:1px solid rgba(63,71,75,.12)}}
@media(max-width:760px){.hd-main-search-results-v150732{left:0;right:0;width:100%}.hd-main-search-grid-v150732{grid-template-columns:1fr}.hd-main-search-group-v150732+.hd-main-search-group-v150732{border-left:0;border-top:1px solid rgba(63,71,75,.12)}.hd-search-page-v150732{width:calc(100% - 24px);margin-top:18px}.hd-search-page-grid-v150732{grid-template-columns:1fr}.hd-search-page-group-v150732{padding:15px}}

/* 1.50.788: fifth Fachwissen search group and meaningful result types. */
.hd-search-kind-v150788{display:block;margin-top:3px;font-size:10px;line-height:1.25;font-weight:500;color:#647b79}
@media(min-width:901px){.hd-main-search-grid-v150732{grid-template-columns:repeat(5,minmax(0,1fr))}}
@media(min-width:761px) and (max-width:900px){.hd-main-search-grid-v150732{grid-template-columns:repeat(2,minmax(0,1fr))}.hd-main-search-group-v150732{border-top:1px solid rgba(63,71,75,.12)}.hd-main-search-group-v150732:nth-child(odd){border-left:0!important}}
@media(max-width:760px){.hd-main-search-grid-v150732{grid-template-columns:1fr}.hd-main-search-group-v150732+.hd-main-search-group-v150732{border-top:1px solid rgba(63,71,75,.12);border-left:0}}

/* 1.50.789: compact search result page with progressive reveal, no new search logic. */
.hd-search-page-compact-v150789 .hd-search-page-grid-v150732{align-items:start;grid-auto-flow:row;gap:14px}
.hd-search-page-compact-v150789 .hd-search-page-group-compact-v150789{align-self:start;padding:17px 20px;border-radius:3px}
.hd-search-page-compact-v150789 .hd-search-group-header-v150789{display:flex;align-items:center;justify-content:space-between;gap:15px;margin:0 0 9px}
.hd-search-page-compact-v150789 .hd-search-group-header-v150789 h2{margin:0!important;font-size:21px!important}
.hd-search-page-compact-v150789 .hd-search-total-v150789{flex:none;color:#77868a;font-size:11px;font-weight:650}
.hd-search-page-compact-v150789 .hd-search-page-list-v150732 a{padding:9px 0!important;line-height:1.32}
.hd-search-page-compact-v150789 [hidden]{display:none!important}
.hd-search-page-compact-v150789 .hd-search-more-v150789{display:flex;width:100%;align-items:center;justify-content:center;gap:6px;padding:11px 16px;margin:12px 0 0;border:1px solid #badbd6;border-radius:4px;background:#f0faf7;color:#176f6d;font-size:13px;font-weight:800;line-height:1.35;cursor:pointer}
.hd-search-page-compact-v150789 .hd-search-more-v150789:hover,.hd-search-page-compact-v150789 .hd-search-more-v150789:focus-visible{background:#e2f4ed;border-color:#77b3ac;outline:2px solid transparent}
.hd-search-page-compact-v150789 .hd-search-more-v150789 small{font-size:11px;font-weight:600}
.hd-search-page-limit-v150789{margin:18px 3px 0;font-size:12px;color:#758187}
.hd-search-page-no-results-v150789{padding:18px 20px;border:1px solid var(--hd-line);font-size:15px}
@media(max-width:760px){.hd-search-page-compact-v150789 .hd-search-page-group-compact-v150789{padding:15px!important}}

/* 1.50.741: Service-Seiten bleiben im normalen WordPress-Template. Nur der importierte Inhalt wird statisch normalisiert und als Full-Bleed-Innenachse auf Hero-Breite gesetzt. */
body.hd-service-page-v150735 .entry-header,
body.hd-service-page-v150735 header.entry-header,
body.hd-service-page-v150735 .ast-single-entry-banner,
body.hd-service-page-v150735 .page-header,
body.hd-service-page-v150735 h1.entry-title,
body.hd-service-page-v150735 .wp-block-post-title{display:none!important}
.hd-service-top-v150735{width:100%}.hd-service-top-v150735 .hd-breadcrumb-wrap{margin-bottom:10px}
.hd-service-hero-v150735{display:grid;width:min(calc(100% - 72px),var(--hd-content));min-height:238px;margin:0 auto;grid-template-columns:minmax(0,.88fr) minmax(360px,1.12fr);overflow:hidden;border:0!important;border-radius:0!important;background:#f5f1e9!important;box-shadow:none!important}
.hd-service-hero-copy-v150735{display:flex;min-width:0;padding:34px 38px;align-items:center}.hd-service-hero-copy-v150735 h1{margin:0!important;color:#17313c!important;font-size:clamp(38px,4.3vw,60px)!important;font-weight:800!important;letter-spacing:-.035em!important;line-height:1!important}
.hd-service-hero-media-v150735{height:238px;margin:0;overflow:hidden}.hd-service-hero-media-v150735 img{display:block;width:100%;height:100%;object-fit:cover;object-position:center 52%}
body.hd-service-page-v150735 .site-content .ast-container{padding-top:18px!important}
body.hd-service-page-v150735 .entry-content{padding-top:0!important;color:#34464d;font-size:15.5px;line-height:1.72;overflow:visible!important}
body.hd-service-page-v150735 .hd-service-body-v150741{box-sizing:border-box!important;width:100vw!important;max-width:100vw!important;margin-left:calc(50% - 50vw)!important;margin-right:0!important;padding-left:max(36px,calc((100vw - var(--hd-content))/2))!important;padding-right:max(36px,calc((100vw - var(--hd-content))/2))!important;color:#34464d!important;font-size:inherit!important;line-height:inherit!important}
body.hd-service-page-v150735 .hd-service-body-v150741>*{max-width:none!important}
body.hd-service-page-v150735 .hd-service-body-v150741 p{margin-top:0!important;margin-bottom:18px!important}
body.hd-service-page-v150735 .hd-service-body-v150741 .hd-service-subheading-v150741{display:block!important;box-sizing:border-box!important;width:100%!important;margin:24px 0!important;padding:0!important;color:inherit!important;font-family:inherit!important;font-size:inherit!important;font-weight:400!important;line-height:inherit!important}
body.hd-service-page-v150735 .hd-service-body-v150741 .hd-service-subheading-v150741 strong{font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;font-weight:700!important}
body.hd-service-preise-v150735 .hd-service-body-v150741 figure.wp-block-table,body.hd-service-preise-v150735 .hd-service-body-v150741 .hd-service-price-figure-v150741{display:block!important;box-sizing:border-box!important;width:100%!important;max-width:none!important;margin:0 0 30px!important;padding:0!important;overflow-x:auto!important}
body.hd-service-preise-v150735 .hd-service-body-v150741 table,body.hd-service-preise-v150735 .hd-service-body-v150741 table.hd-service-price-table-v150741{display:table!important;box-sizing:border-box!important;width:100%!important;min-width:100%!important;max-width:none!important;margin:0!important;table-layout:auto!important;border-collapse:collapse!important;background:#fff}
body.hd-service-preise-v150735 .hd-service-body-v150741 th,body.hd-service-preise-v150735 .hd-service-body-v150741 td{padding:12px 14px!important;border:1px solid rgba(63,71,75,.18)!important;vertical-align:top!important;text-align:left!important}
body.hd-service-preise-v150735 .hd-service-body-v150741 tr:first-child td,body.hd-service-preise-v150735 .hd-service-body-v150741 th{background:#eef8f7!important;color:#17313c!important;font-weight:800!important}
body.hd-service-preise-v150735 .hd-service-body-v150741 table td:first-child{width:28%}body.hd-service-preise-v150735 .hd-service-body-v150741 table td:nth-child(2){width:52%}body.hd-service-preise-v150735 .hd-service-body-v150741 table td:last-child{width:20%;white-space:nowrap}
@media(max-width:760px){.hd-service-hero-v150735{width:calc(100% - 24px);min-height:0;grid-template-columns:1fr}.hd-service-hero-copy-v150735{padding:23px 18px}.hd-service-hero-copy-v150735 h1{font-size:clamp(34px,10vw,45px)!important}.hd-service-hero-media-v150735{height:190px}.hd-service-top-v150735 .hd-breadcrumb-wrap{margin-bottom:8px}body.hd-service-page-v150735 .site-content .ast-container{padding-top:16px!important}body.hd-service-page-v150735 .entry-content{font-size:15px}.hd-service-hero-media-v150735 img{object-position:center 52%}body.hd-service-page-v150735 .hd-service-body-v150741{padding-left:12px!important;padding-right:12px!important}body.hd-service-preise-v150735 .hd-service-body-v150741 table{min-width:680px!important}}


/* 1.50.743 – erster Anzeigenmarkt-Entwurf: Bildkacheln oben, Icons darunter. */
.hd-market-shell-v150743{width:min(calc(100% - 72px),var(--hd-content));margin:0 auto 24px;padding-top:10px;color:#17313c}
.hd-market-breadcrumb-v150743{display:flex;gap:7px;align-items:center;margin:0 0 10px;color:#718087;font-size:11px}.hd-market-breadcrumb-v150743 a{text-decoration:none}.hd-market-breadcrumb-v150743 strong{font-weight:700;color:#52646c}
.hd-market-head-v150743{display:flex;align-items:end;justify-content:space-between;gap:24px;padding:22px 26px;border:1px solid rgba(63,71,75,.10);background:#f8f4ed}.hd-market-head-v150743 h1{margin:0!important;color:#17313c!important;font-size:38px!important;font-weight:800!important;letter-spacing:-.035em;line-height:1!important}.hd-market-head-v150743 p{max-width:760px;margin:9px 0 0;color:#5b6970;font-size:14px;line-height:1.45}.hd-market-submit-v150743{display:inline-flex;min-height:40px;padding:0 18px;align-items:center;justify-content:center;border-radius:999px;background:var(--hd-petrol);color:#fff!important;font-size:12px;font-weight:750;text-decoration:none!important;white-space:nowrap}
.hd-market-search-v150743{display:grid;grid-template-columns:minmax(0,1fr) 116px;gap:10px;margin:12px 0 20px;padding:10px;border:1px solid rgba(63,71,75,.11);background:#f5f1e9}.hd-market-search-field-v150743{position:relative;min-width:0}.hd-market-search-field-v150743 svg{position:absolute;left:15px;top:50%;width:18px;height:18px;fill:none;stroke:#17313c;stroke-width:1.8;transform:translateY(-50%)}.hd-market-search-field-v150743 input{width:100%!important;height:44px!important;margin:0!important;padding:0 16px 0 44px!important;border:1px solid rgba(63,71,75,.12)!important;border-radius:4px!important;background:#fff!important;color:#17313c!important;font-size:13px!important;box-shadow:none!important}.hd-market-search-v150743 button{height:44px!important;margin:0!important;padding:0 18px!important;border:0!important;border-radius:4px!important;background:var(--hd-petrol)!important;color:#fff!important;font-size:12px!important;font-weight:800!important;box-shadow:none!important}
.hd-market-entry-v150743{margin-top:2px}.hd-market-entry-v150743>header{display:flex;align-items:end;justify-content:space-between;gap:20px;margin-bottom:10px}.hd-market-entry-v150743 h2{margin:0!important;color:#17313c!important;font-size:24px!important;font-weight:800!important;letter-spacing:-.025em}.hd-market-entry-v150743 header p{margin:3px 0 0;color:#758188;font-size:11px}
.hd-market-photo-grid-v150743{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.hd-market-photo-card-v150743{display:block;overflow:hidden;border:1px solid rgba(63,71,75,.11);border-radius:5px;background:#fff;text-decoration:none!important;box-shadow:0 4px 16px rgba(35,53,60,.035)}.hd-market-photo-card-v150743 img{display:block;width:100%;height:142px;object-fit:cover}.hd-market-photo-card-v150743>span{display:grid;min-height:56px;padding:9px 11px;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:center}.hd-market-photo-card-v150743 strong{color:#17313c;font-size:14px;line-height:1.22}.hd-market-photo-card-v150743 b{color:var(--hd-petrol);font-size:10px;font-weight:750;white-space:nowrap}.hd-market-photo-card-v150743:hover{border-color:rgba(15,143,149,.35);box-shadow:0 8px 24px rgba(35,53,60,.07)}
.hd-market-icon-grid-v150743{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.hd-market-icon-card-v150743{display:grid;min-height:72px;padding:12px 13px;grid-template-columns:42px minmax(0,1fr) 16px;gap:10px;align-items:center;border:1px solid rgba(63,71,75,.11);border-radius:5px;background:#fff;text-decoration:none!important}.hd-market-icon-card-v150743>span{display:flex;width:42px;height:42px;align-items:center;justify-content:center;border-radius:50%;background:#eef7f7;color:var(--hd-petrol)}.hd-market-icon-card-v150743 svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}.hd-market-icon-card-v150743 strong{color:#17313c;font-size:12.5px;line-height:1.25}.hd-market-icon-card-v150743 b{color:#91a0a5;font-size:18px}
.hd-market-banner-v150743{position:relative;margin-top:18px;min-height:78px;overflow:hidden;border:1px solid rgba(63,71,75,.10);background:#fff}.hd-market-banner-v150743>span{position:absolute;z-index:3;left:10px;top:7px;padding:2px 6px;background:rgba(255,255,255,.9);color:#76848a;font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}.hd-market-banner-v150743>div,.hd-market-banner-v150743 .ppar-affiliate-slot,.hd-market-banner-v150743 .ppar-affiliate-content,.hd-market-banner-v150743 .ppar-banner-link{width:100%!important;min-height:78px!important;margin:0!important}.hd-market-banner-v150743 img{display:block!important;width:100%!important;height:78px!important;object-fit:cover!important}

.hd-market-shell-root-v150744 .hd-market-banner-v150743{margin:0 0 18px}
.hd-market-hero-v150744{display:grid;grid-template-columns:minmax(330px,.43fr) minmax(0,.57fr);min-height:238px;overflow:hidden;border:1px solid rgba(63,71,75,.10);background:#f8f4ed}
.hd-market-hero-copy-v150744{display:flex;flex-direction:column;justify-content:center;padding:28px 30px}.hd-market-hero-copy-v150744>span{margin-bottom:8px;color:var(--hd-petrol);font-size:12px;font-weight:800;letter-spacing:.02em}.hd-market-hero-copy-v150744 h1{margin:0!important;color:#17313c!important;font-size:40px!important;font-weight:800!important;line-height:1.02!important;letter-spacing:-.035em}.hd-market-hero-copy-v150744 p{max-width:480px;margin:12px 0 16px;color:#5b6970;font-size:14px;line-height:1.5}.hd-market-hero-copy-v150744 .hd-market-submit-v150743{align-self:flex-start}
.hd-market-hero-image-v150744{min-width:0}.hd-market-hero-image-v150744 img{display:block;width:100%;height:100%;min-height:238px;object-fit:cover;object-position:center center}
.hd-market-native-head-v150744{display:flex;align-items:end;justify-content:space-between;gap:20px;margin:24px 0 8px}.hd-market-native-head-v150744 h2{margin:0!important;color:#17313c!important;font-size:24px!important;font-weight:800!important;letter-spacing:-.025em}.hd-market-native-head-v150744 a{color:var(--hd-petrol)!important;font-size:11px;font-weight:750;text-decoration:none!important}
body.hd-market-root-v150744 .site-content .widget-area,body.hd-market-root-v150744 .site-content #secondary,body.hd-market-root-v150744 .site-content .sidebar-main,body.hd-market-root-v150744 .site-content .site-sidebar{display:none!important}
body.hd-market-root-v150744 .site-content .content-area,body.hd-market-root-v150744 .site-content #primary,body.hd-market-root-v150744 .site-content .site-main{float:none!important;width:100%!important;max-width:1200px!important;margin-left:auto!important;margin-right:auto!important}
body.hd-market-root-v150744 .site-content .widget_archive,body.hd-market-root-v150744 .site-content .widget_categories,body.hd-market-root-v150744 .site-content .hp-form--listing-filter,body.hd-market-root-v150744 .site-content .hp-listing-categories,body.hd-market-root-v150744 .site-content .hp-form--listing-search,body.hd-market-root-v150744 .site-content .hp-page__title{display:none!important}
/* Eigene Einstiegskacheln ersetzen nur die native HivePress-Kategoriekachel-Liste und die doppelte Standardsuche. */
@media(max-width:1000px){.hd-market-photo-grid-v150743,.hd-market-icon-grid-v150743{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:760px){.hd-market-shell-v150743{width:calc(100% - 24px);padding-top:8px}.hd-market-head-v150743{display:block;padding:18px 17px}.hd-market-head-v150743 h1{font-size:30px!important}.hd-market-head-v150743 p{font-size:12.5px}.hd-market-submit-v150743{margin-top:13px}.hd-market-search-v150743{grid-template-columns:1fr;padding:8px}.hd-market-search-v150743 button{width:100%}.hd-market-photo-grid-v150743{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.hd-market-photo-card-v150743 img{height:auto;aspect-ratio:1.5/1}.hd-market-photo-card-v150743>span{display:block;min-height:58px;padding:8px}.hd-market-photo-card-v150743 strong{font-size:12px}.hd-market-photo-card-v150743 b{display:block;margin-top:5px;font-size:9px}.hd-market-icon-grid-v150743{grid-template-columns:1fr;gap:8px}.hd-market-entry-v150743 h2{font-size:20px!important}.hd-market-banner-v150743,.hd-market-banner-v150743>div,.hd-market-banner-v150743 .ppar-affiliate-slot,.hd-market-banner-v150743 .ppar-affiliate-content,.hd-market-banner-v150743 .ppar-banner-link,.hd-market-banner-v150743 img{min-height:70px!important;height:70px!important}}

@media(max-width:760px){.hd-market-hero-v150744{grid-template-columns:1fr;min-height:0}.hd-market-hero-copy-v150744{padding:20px 18px}.hd-market-hero-copy-v150744 h1{font-size:31px!important}.hd-market-hero-image-v150744 img{min-height:150px;height:150px}.hd-market-native-head-v150744{margin-top:20px}.hd-market-native-head-v150744 h2{font-size:20px!important}}


/* 1.50.798: genuine HivePress category archives, every level, same marketplace design. */
body.hd-market-category-v150798 .site-content .widget-area,
body.hd-market-category-v150798 .site-content #secondary,
body.hd-market-category-v150798 .site-content .sidebar-main,
body.hd-market-category-v150798 .site-content .site-sidebar,
body.hd-market-category-v150798 .site-content .widget_archive,
body.hd-market-category-v150798 .site-content .widget_categories{display:none!important}
body.hd-market-category-v150798 .site-content .content-area,
body.hd-market-category-v150798 .site-content #primary,
body.hd-market-category-v150798 .site-content .site-main{
 float:none!important;width:100%!important;max-width:1200px!important;
 margin-left:auto!important;margin-right:auto!important;min-width:0!important
}
body.hd-market-category-v150798 .site-content .hp-page__title,
body.hd-market-category-v150798 .site-content .page-title,
body.hd-market-category-v150798 .site-content .hp-form--listing-search{display:none!important}
body.hd-market-category-v150798 .site-content .hp-listing-category,
body.hd-market-category-v150798 .site-content .hp-listing--view-block{
 border:1px solid rgba(63,71,75,.12)!important;border-radius:5px!important;
 background:#fff!important;box-shadow:0 4px 16px rgba(35,53,60,.035)!important
}
body.hd-market-category-v150798 .site-content .hp-listing-category__name,
body.hd-market-category-v150798 .site-content .hp-listing__title{
 color:#17313c!important;font-weight:800!important
}
body.hd-market-category-v150798 .site-content .hp-listing-categories{width:100%!important;max-width:none!important}
body.hd-market-category-v150798 .site-content .hp-page__content{width:100%!important;max-width:none!important}
.hd-market-category-shell-v150798 .hd-market-native-head-v150744{margin-bottom:18px}
@media(max-width:760px){
 body.hd-market-category-v150798 .site-content .content-area,
 body.hd-market-category-v150798 .site-content #primary,
 body.hd-market-category-v150798 .site-content .site-main{max-width:100%!important}
 .hd-market-category-shell-v150798 .hd-market-breadcrumb-v150743{flex-wrap:wrap}
 .hd-market-category-shell-v150798 .hd-market-native-head-v150744{align-items:start;gap:9px}
}

/* 1.50.746 – Pilot Unterseite: FAQ Kettenhemdflechten.
   Kein Hero-Bild. Reihenfolge: H1+Kurztext -> Banner -> Beitraege -> Anbieterprodukte. */
.hd-content-v150616 .hd-ketten-faq-pilot-v150746{padding-bottom:12px!important}
.hd-content-v150616 .hd-ketten-faq-pilot-v150746 .hd-catlevel-lead{max-width:820px!important;margin-top:13px!important;padding:13px 15px!important;font-size:14.5px!important;line-height:1.52!important}
.hd-content-v150616 .hd-ketten-faq-banner-v150746{margin-top:16px!important}
.hd-content-v150616 .hd-ketten-faq-posts-v150746{margin-top:18px!important}
.hd-content-v150616 .hd-ketten-faq-posts-v150746 .hd-post-grid{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:12px!important}
.hd-content-v150616 .hd-ketten-faq-posts-v150746 .hd-post-card{min-height:154px!important;border:1px solid rgba(47,150,157,.18)!important;border-radius:7px!important;background:#fff!important;box-shadow:0 2px 10px rgba(23,49,60,.035)!important}
.hd-content-v150616 .hd-ketten-faq-posts-v150746 .hd-post-card>div{height:100%!important;padding:15px 16px!important}
.hd-content-v150616 .hd-ketten-faq-posts-v150746 .hd-post-card h3{margin:5px 0 7px!important;color:#17313c!important;font-size:17px!important;line-height:1.2!important}
.hd-content-v150616 .hd-ketten-faq-posts-v150746 .hd-post-card p{margin:0!important;color:#647176!important;font-size:13px!important;line-height:1.48!important}
.hd-demo-post-kicker-v150746{display:block;color:var(--hd-petrol)!important;font-size:9px!important;font-weight:800!important;letter-spacing:.08em!important;text-transform:uppercase}
.hd-demo-post-more-v150746{display:block;margin-top:11px;color:var(--hd-petrol)!important;font-size:11px!important;font-weight:750!important}
.hd-content-v150616 .hd-ketten-faq-products-v150746{margin-top:20px!important}
.hd-content-v150616 .hd-provider-grid-v150746{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.hd-content-v150616 .hd-provider-column-v150746{min-width:0;padding:12px;border:1px solid rgba(63,71,75,.11);border-radius:7px;background:#fbfaf7}
.hd-content-v150616 .hd-provider-column-v150746>h3{margin:0 0 9px!important;color:#17313c!important;font-size:16px!important;font-weight:800!important;line-height:1.2!important}
.hd-content-v150616 .hd-provider-column-v150746 .hd-next-partner-product{height:auto!important;min-height:96px!important;margin:0!important}
@media(max-width:1000px){
 .hd-content-v150616 .hd-ketten-faq-posts-v150746 .hd-post-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
}
@media(max-width:760px){
 .hd-content-v150616 .hd-ketten-faq-posts-v150746 .hd-post-grid,.hd-content-v150616 .hd-provider-grid-v150746{grid-template-columns:1fr!important}
 .hd-content-v150616 .hd-ketten-faq-posts-v150746 .hd-post-card{min-height:0!important}
}

/* 1.50.750: einheitliches Layout NUR fuer exakte HD-001 Leaf-Kategorien. */
.hd-content-v150616 .hd-leaf-posts-v150750{margin-top:18px!important}
.hd-content-v150616 .hd-leaf-posts-v150750 .hd-post-grid{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:12px!important}
.hd-content-v150616 .hd-leaf-posts-v150750 .hd-post-card{min-height:154px!important;border:1px solid rgba(47,150,157,.18)!important;border-radius:7px!important;background:#fff!important;box-shadow:0 2px 10px rgba(23,49,60,.035)!important}
.hd-content-v150616 .hd-leaf-posts-v150750 .hd-post-card>div{height:100%!important;padding:15px 16px!important}
.hd-content-v150616 .hd-leaf-posts-v150750 .hd-post-card h3{margin:5px 0 7px!important;color:#17313c!important;font-size:17px!important;line-height:1.2!important}
.hd-content-v150616 .hd-leaf-posts-v150750 .hd-post-card p{margin:0!important;color:#647176!important;font-size:13px!important;line-height:1.48!important}
.hd-content-v150616 .hd-leaf-products-v150750{margin-top:20px!important}
.hd-content-v150616 .hd-leaf-products-v150750 .hd-provider-grid-v150746{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
@media(max-width:900px){
 .hd-content-v150616 .hd-leaf-posts-v150750 .hd-post-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
}
@media(max-width:760px){
 .hd-content-v150616 .hd-leaf-posts-v150750 .hd-post-grid,.hd-content-v150616 .hd-leaf-products-v150750 .hd-provider-grid-v150746{grid-template-columns:1fr!important}
 .hd-content-v150616 .hd-leaf-posts-v150750 .hd-post-card{min-height:0!important}
}


/* 1.50.775: Fill the original hero frame edge-to-edge, including at compact
   desktop widths. Preserve the words painted on the right of the photo. */
.hd-home-v150616-main .hd-hero-v150616 .hd-hero-image{display:block!important;overflow:hidden!important}
.hd-home-v150616-main .hd-hero-v150616 .hd-hero-picture{display:block!important;width:100%!important;height:100%!important}
.hd-home-v150616-main .hd-hero-v150616 .hd-hero-picture img{display:block!important;width:100%!important;height:100%!important;max-height:none!important;object-fit:cover!important;object-position:right center!important}
/* When the columns stack, use the 2:1 mobile image without blank bands. */
@media(max-width:1100px){
 .hd-home-v150616-main .hd-hero-v150616 .hd-hero-image{min-height:0!important}
 .hd-home-v150616-main .hd-hero-v150616 .hd-hero-picture{height:auto!important}
 .hd-home-v150616-main .hd-hero-v150616 .hd-hero-picture img{height:auto!important;aspect-ratio:2/1!important;min-height:0!important;object-fit:cover!important;object-position:right center!important}
}

/* 1.50.776: Based on the approved 2026-10-21 screenshot, the desktop hero
   must have the NATIVE 1370:620 image ratio, not the earlier 320px minimum.
   Only the two-column home hero is affected. Mobile 2:1 remains unchanged. */
@media(min-width:1101px){
 .hd-home-v150616-main .hd-hero-v150616{height:auto!important;min-height:0!important;max-height:none!important;aspect-ratio:3.7457627/1!important;overflow:hidden!important;align-items:stretch!important}
 .hd-home-v150616-main .hd-hero-v150616 .hd-hero-copy{min-height:0!important;padding:17px 26px 17px 30px!important}
 .hd-home-v150616-main .hd-hero-v150616 .hd-hero-copy h1{font-size:clamp(36px,3.8vw,50px)!important}
 .hd-home-v150616-main .hd-hero-v150616 .hd-hero-copy h1 em{white-space:nowrap!important}
 .hd-home-v150616-main .hd-hero-v150616 .hd-hero-image{min-height:0!important;height:100%!important}
 .hd-home-v150616-main .hd-hero-v150616 .hd-hero-picture{height:100%!important}
 .hd-home-v150616-main .hd-hero-v150616 .hd-hero-picture img{height:100%!important;min-height:0!important;width:100%!important;object-fit:cover!important;object-position:center center!important}
}


/* HD-003 1.50.791 – Freigegebenes Bild als unveränderte Vollansicht.
 * Keine object-fit:cover, kein Hintergrund-Crop, keine automatische Neugestaltung. */
body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-v150791{
 position:relative;display:block;width:100%;height:auto;max-width:100%;
 margin:0;padding:0;overflow:hidden;line-height:0;isolation:isolate;
 border:0;background:transparent;box-shadow:none;
}
body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-art-v150791{
 display:block!important;width:100%!important;max-width:100%!important;
 height:auto!important;min-height:0!important;aspect-ratio:2170/725;
 object-fit:contain!important;object-position:center center!important;
 margin:0!important;padding:0!important;border:0!important;box-shadow:none!important;
}
body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-hotspot-v150791{
 position:absolute;z-index:2;display:block;box-sizing:border-box;
 top:69.65%;height:13.5%;text-decoration:none!important;
 background:transparent!important;border:0!important;border-radius:6px;
 cursor:pointer;
}
body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-hotspot-v150791.is-terms{
 left:4.25%;width:22.75%;
}
body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-hotspot-v150791.is-prices{
 left:28.75%;width:13.25%;
}
body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-hotspot-v150791:focus-visible{
 outline:3px solid #2f969d!important;outline-offset:2px;
}
body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-hotspot-v150791.is-unavailable{
 cursor:not-allowed;
}

/* 1.50.792: ausschließlich die zwei Service-Zielseiten und freies Mietbanner.
   Seiteninhalt, freigegebenes Logo/Fotomotiv, Kundenanzeigen und andere Profile bleiben unberührt. */
/* Preise: unnötigen Weißraum zwischen dem vorhandenen Service-Hero und Inhalt reduzieren. */
body.hd-service-preise-v150735 .site-content{
  margin-top:0!important;padding-top:0!important;
}
body.hd-service-preise-v150735 .site-content .ast-container{
  padding-top:10px!important;margin-top:0!important;
}
body.hd-service-preise-v150735 .site-content .entry-content{
  padding-top:0!important;margin-top:0!important;
}
body.hd-service-preise-v150735 .hd-service-body-v150741{
  padding-top:0!important;margin-top:0!important;
}
/* Werbebedingungen: langen Titel vollständig im linken Teil des Original-Heros anzeigen. */
body.hd-service-werb-anzeigebedingungen-v150735 .hd-service-hero-v150735,
body.hd-service-werbebedingungen-v150735 .hd-service-hero-v150735{
  grid-template-columns:minmax(0,1fr) minmax(0,1fr)!important;
}
body.hd-service-werb-anzeigebedingungen-v150735 .hd-service-hero-copy-v150735,
body.hd-service-werbebedingungen-v150735 .hd-service-hero-copy-v150735{
  padding:22px 24px!important;min-width:0!important;
}
body.hd-service-werb-anzeigebedingungen-v150735 .hd-service-hero-copy-v150735 h1,
body.hd-service-werbebedingungen-v150735 .hd-service-hero-copy-v150735 h1{
  font-size:clamp(22px,2.8vw,36px)!important;line-height:1.14!important;
  letter-spacing:-.035em!important;max-width:100%!important;min-width:0!important;
  white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important;
}
@media(max-width:760px){
 body.hd-service-werb-anzeigebedingungen-v150735 .hd-service-hero-v150735,
 body.hd-service-werbebedingungen-v150735 .hd-service-hero-v150735{
   grid-template-columns:minmax(0,1fr)!important;
 }
 body.hd-service-werb-anzeigebedingungen-v150735 .hd-service-hero-copy-v150735 h1,
 body.hd-service-werbebedingungen-v150735 .hd-service-hero-copy-v150735 h1{
   font-size:clamp(23px,6.5vw,34px)!important;
 }
}
/* Das 1:1 freigegebene Bannerbild nicht schneiden/zoomen/neuzeichnen. Nur
   die eingebrannte Überschrift im Originalbild optisch abdecken und oberhalb
   etwas kleiner als echten Text setzen. */
body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-v150791{
  container-type:inline-size;
}
body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-v150791::before{
  content:'';position:absolute;z-index:1;pointer-events:none;
  left:3.9%;top:50%;width:65.5%;height:16%;
  background:linear-gradient(90deg,#f7eee5 0%,#f6ece3 53%,#e8d6c4 90%,rgba(232,214,196,0) 100%);
  -webkit-mask-image:linear-gradient(to bottom,transparent,black 13%,black 87%,transparent);mask-image:linear-gradient(to bottom,transparent,black 13%,black 87%,transparent);
}
body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-title-v150792{
  position:absolute;z-index:2;pointer-events:none;display:block;
  left:4.25%;top:45.8%;max-width:62%;margin:0;padding:0;
  color:#082d39;font-family:Arial,Helvetica,sans-serif;font-size:2.90cqw;
  font-weight:800;letter-spacing:-.035em;line-height:1.12;white-space:nowrap;
}
/* 1.50.797 – exakt dieselbe original gezeichnete Buttonecke:
   nur echte Pixel der vorhandenen Buttonflächen werden farblich verändert.
   Kein zweiter Radius, kein nachgezeichneter Rahmen, keine Bewegung. */
body.pftk-design-profile-hobby-depot .hd-rental a.hd-own-ad-hotspot-v150791{
  z-index:5; background:transparent!important; border:0!important;
  box-shadow:none!important; transform:none!important; filter:none!important;
  transition:none!important;
}
body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-tint-v150794{
  position:absolute!important; inset:0!important; z-index:4;
  display:block!important; width:100%!important; height:100%!important;
  max-width:100%!important; min-height:0!important;
  aspect-ratio:2170/725!important; object-fit:fill!important;
  margin:0!important; padding:0!important; border:0!important;
  box-shadow:none!important; opacity:0; pointer-events:none!important;
  transition:opacity .15s ease;
}
body.pftk-design-profile-hobby-depot .hd-rental a.hd-own-ad-hotspot-v150791.is-terms:hover ~ .hd-own-ad-tint-v150794.is-terms,
body.pftk-design-profile-hobby-depot .hd-rental a.hd-own-ad-hotspot-v150791.is-terms:focus-visible ~ .hd-own-ad-tint-v150794.is-terms,
body.pftk-design-profile-hobby-depot .hd-rental a.hd-own-ad-hotspot-v150791.is-prices:hover ~ .hd-own-ad-tint-v150794.is-prices,
body.pftk-design-profile-hobby-depot .hd-rental a.hd-own-ad-hotspot-v150791.is-prices:focus-visible ~ .hd-own-ad-tint-v150794.is-prices{
  opacity:1;
}
@media(prefers-reduced-motion:reduce){
 body.pftk-design-profile-hobby-depot .hd-rental .hd-own-ad-tint-v150794{transition:none!important}
}
CSS;
    }

/* 1.50.624: dedicated fallback photos for every first-level world hub child. Header intentionally unchanged from 1.50.622. */

}

