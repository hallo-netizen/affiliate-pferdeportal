<?php
if (!defined('ABSPATH')) { exit; }
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class('hd-owned-content-template-v150709 hd-hobbyregister-owned-shell-v1210'); ?>>
<?php
if (function_exists('wp_body_open')) { wp_body_open(); }
if (class_exists('Hobby_Depot_Profile_V150709')) {
    Hobby_Depot_Profile_V150709::render_header();
} else {
    get_header();
}
?>
<main id="primary" class="site-main hd-content-v150616 hd-hobbyregister-template-v110">
<?php echo HD_Hobbyregister_Frontend_Stable127::render_current(); ?>
</main>
<?php
if (class_exists('Hobby_Depot_Profile_V150709')) {
    Hobby_Depot_Profile_V150709::render_footer();
} else {
    get_footer();
}
wp_footer();
?>
</body>
</html>
