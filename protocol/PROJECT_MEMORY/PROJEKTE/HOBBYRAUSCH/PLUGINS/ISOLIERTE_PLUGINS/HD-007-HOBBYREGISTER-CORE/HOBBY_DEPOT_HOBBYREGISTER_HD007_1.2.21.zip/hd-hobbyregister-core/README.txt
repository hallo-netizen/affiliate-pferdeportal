Hobby Depot – Hobbyregister Core 1.2.17

Read-only Laufzeitprojektion des zentralen Hobbyregisters.

Aktueller Bildstand:
- 862 Hobbys
- 24 verifizierte finale 1500x1000 Masterbilder
- davon 10 neue eindeutige Zuordnungen in Batch 02
- 838 Bildfälle weiter offen
- 79 vorhandene CORE-Motive semantisch passend, aber technisch zu klein
- 295 vorhandene CORE-Motive semantisch unpassend
- 464 offene NO_CORE-Fälle

Neue aktive Master 1.2.14:
Fruchtwein herstellen, Cider herstellen, Met herstellen, Kombucha, Bier brauen, Seifenherstellung, Kerzengießen, Buchbinden, Makramee, Imkerei.

Glossar-Reserve:
Generierte Alternativen und verworfene Varianten bleiben unter assets/glossary-candidates/ erhalten, werden vom Hobbyregister aber nicht verwendet. Zuordnung/Status: data/glossary-image-reserve-v1.json.

Keine WordPress-DB-Writes, keine Cronjobs, keine zweite Hobby-Datenbank.


1.2.16 – Design + Bereichssuche
- Registersuche: Ajax-Vorschau ab 2 Zeichen, max. 8 Treffer, ausschließlich Hobbyregister-Datensätze.
- Banner auf allen Register-Übersichts-/Filter-/Paginierungsseiten zwischen Suche/A-Z und Hobbygruppen.
- Schreibschrift + identischer handgezeichneter Brush im Register-Hero und auf Hobbyprofilen.
- Profil-Herobilder auf dieselbe flache Höhe wie die Register-Startseite vereinheitlicht (Desktop 238 px, mobil 190 px).


1.2.16 – Suchfeld-Breitenfix
- Suchfeld wieder 100 % breit innerhalb der Register-Suchzeile.
- Sichtbare Beschriftung „Hobby suchen“ entfernt.
- Placeholder im Feld: „Hobby suchen …“.
- AJAX-Suche aus 1.2.15 unverändert.


1.2.17 – Sprachkorrektur der 862 Profilüberschriften
- F2 und F3 in allen 862 vorhandenen Registerartikeln grammatisch und thematisch auf die jeweilige Tätigkeit abgestimmt.
- Kanonische Hobbynamen, alle Artikelabsätze, Traits und Bilddateien unverändert.
- Bei fehlendem statischem Text neutrale grammatische Überschriften statt blind eingesetztem Namen.
