<?php
if (!defined('ABSPATH') && PHP_SAPI !== 'cli') { exit; }
final class HD_Hobbyregister_Core_Stable127 {
    const VERSION = '1.2.17';
    const REGISTER_SHA256 = '4deb4be2b235db450d58f02485ec40e780fc2671f9dfc6edf8cbbba0f738af78';
    const RUNTIME_57_SHA256 = 'd0d424485e6dbcf65a8332da732d2e342b279f0a1311919149ba8dfcdb93604a';
    private static $register = null;
    private static $by_id = null;
    private static $by_name = null;
    private static $data_dir = null;
    private static function decode_file($path) {
        if (!is_readable($path)) return null;
        $raw = file_get_contents($path);
        if ($raw === false) return null;
        $data = json_decode($raw, true);
        return is_array($data) ? $data : null;
    }
    private static function complete_data_dir($dir) {
        $dir = rtrim((string)$dir, '/\\');
        if ($dir === '') return false;
        $register = self::decode_file($dir . '/hobby-register.json');
        if (!is_array($register) || !isset($register['records']) || !is_array($register['records']) || count($register['records']) !== 862) return false;
        $first = $register['records'][0] ?? null;
        if (!is_array($first) || !isset($first['traits']) || count($first['traits']) !== 57) return false;
        $articles = self::decode_file($dir . '/hobby-articles-v1.json');
        if (!is_array($articles) || count($articles) !== 862) return false;
        $images = self::decode_file($dir . '/hobby-image-map-v1.json');
        if (!is_array($images) || count($images) !== 862) return false;
        $schema = self::decode_file($dir . '/traits-schema.json');
        if (!is_array($schema)) return false;
        return true;
    }
    private static function data_dir() {
        if (self::$data_dir !== null) return self::$data_dir;
        $current = dirname(__DIR__) . '/data';
        $plugins = dirname(dirname(__DIR__));
        $candidates = array($current, $plugins . '/hd-hobbyregister-core/data');
        foreach ((array)glob($plugins . '/hd-hobbyregister-core*/data') as $candidate) $candidates[] = $candidate;
        $seen = array();
        foreach ($candidates as $candidate) {
            $key = str_replace('\\','/',(string)$candidate);
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            if (self::complete_data_dir($candidate)) {
                self::$data_dir = rtrim($candidate, '/\\');
                return self::$data_dir;
            }
        }
        self::$data_dir = $current;
        return self::$data_dir;
    }
    public static function active_data_dir() { return self::data_dir(); }
    private static function data_path($name) { return self::data_dir() . '/' . $name; }
    private static function read_json($name) { return self::decode_file(self::data_path($name)); }
    public static function register() {
        if (self::$register === null) {
            self::$register = self::read_json('hobby-register.json');
            if (!is_array(self::$register)) self::$register = array('records'=>array());
        }
        return self::$register;
    }
    public static function schema() {
        $data = self::read_json('traits-schema.json');
        return is_array($data) ? $data : array();
    }
    public static function records() {
        $r = self::register();
        return isset($r['records']) && is_array($r['records']) ? $r['records'] : array();
    }
    private static function index() {
        if (self::$by_id !== null) return;
        self::$by_id = array(); self::$by_name = array();
        foreach (self::records() as $row) {
            if (!is_array($row)) continue;
            $id = isset($row['registry_id']) ? (string)$row['registry_id'] : '';
            $name = isset($row['canonical_name']) ? (string)$row['canonical_name'] : '';
            if ($id !== '') self::$by_id[$id] = $row;
            if ($name !== '') self::$by_name[$name] = $row;
        }
    }
    public static function get($registry_id) {
        self::index();
        return isset(self::$by_id[$registry_id]) ? self::$by_id[$registry_id] : null;
    }
    public static function get_by_name($name) {
        self::index();
        return isset(self::$by_name[$name]) ? self::$by_name[$name] : null;
    }
    public static function count() { return count(self::records()); }
    public static function ready() {
        $rows = self::records();
        if (count($rows) !== 862) return false;
        foreach ($rows as $row) {
            if (($row['classification_status'] ?? '') === 'PENDING_REVIEW') return false;
            if (($row['result_profile']['status'] ?? '') !== 'REVIEWED') return false;
            if (!isset($row['traits']) || count($row['traits']) !== 57) return false;
        }
        return true;
    }
    private static $articles = null;
    private static $image_map = null;

    public static function articles() {
        if (self::$articles === null) {
            self::$articles = self::read_json('hobby-articles-v1.json');
            if (!is_array(self::$articles)) self::$articles = array();
        }
        return self::$articles;
    }

    public static function article($registry_id) {
        $all = self::articles();
        return isset($all[$registry_id]) && is_array($all[$registry_id]) ? $all[$registry_id] : null;
    }

    public static function image_map() {
        if (self::$image_map === null) {
            self::$image_map = self::read_json('hobby-image-map-v1.json');
            if (!is_array(self::$image_map)) self::$image_map = array();
        }
        return self::$image_map;
    }

    public static function image_entry($registry_id) {
        $all = self::image_map();
        return isset($all[$registry_id]) && is_array($all[$registry_id]) ? $all[$registry_id] : null;
    }

    public static function finder_rows() {
        $out = array();
        foreach (self::records() as $row) {
            $t = array();
            foreach (($row['traits'] ?? array()) as $id => $assignment) {
                if (is_array($assignment) && array_key_exists('value', $assignment)) $t[$id] = $assignment['value'];
            }
            $p = $row['result_profile'] ?? array();
            $out[] = array(
                'registry_id' => $row['registry_id'] ?? '',
                'name' => $row['canonical_name'] ?? '',
                'world' => $row['source_identity']['natural_world'] ?? '',
                'target_node_id' => $row['source_identity']['target_node_id'] ?? null,
                'traits' => $t,
                'profile' => array(
                    'what_is_it' => $p['what_is_it'] ?? '',
                    'what_do_you_do' => $p['what_do_you_do'] ?? '',
                    'what_do_you_need' => $p['what_do_you_need'] ?? '',
                    'appeal' => $p['appeal'] ?? '',
                ),
            );
        }
        return $out;
    }
}
