<?php
if (!defined('ABSPATH') && PHP_SAPI !== 'cli') { exit; }

final class HD_Hobbyregister_Frontend_Stable127 {
    const VERSION = '1.2.16';
    const BASE_PATH = 'hobbyregister';
    private static $booted = false;
    private static $slug_index = null;
    private static $groups_cache = [];

    public static function boot() {
        if (self::$booted || !function_exists('add_filter')) { return; }
        self::$booted = true;
        add_filter('template_include', [__CLASS__, 'template_include'], 9999);
        add_filter('pre_handle_404', [__CLASS__, 'pre_handle_404'], 9999, 2);
        add_filter('pre_get_document_title', [__CLASS__, 'document_title'], 9999);
        add_filter('body_class', [__CLASS__, 'body_class'], 9999);
        add_action('wp_head', [__CLASS__, 'head_meta'], 4);
        add_action('wp_ajax_hd_hobbyregister_search', [__CLASS__, 'ajax_search']);
        add_action('wp_ajax_nopriv_hd_hobbyregister_search', [__CLASS__, 'ajax_search']);
    }

    private static function request_path() {
        $uri = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '';
        $path = function_exists('wp_parse_url') ? wp_parse_url($uri, PHP_URL_PATH) : parse_url($uri, PHP_URL_PATH);
        return trim(is_string($path) ? $path : '', '/');
    }

    public static function route() {
        $path = self::request_path();
        if ($path === self::BASE_PATH) { return ['type'=>'index','slug'=>'']; }
        if (strpos($path, self::BASE_PATH . '/') === 0) {
            $rest = trim(substr($path, strlen(self::BASE_PATH) + 1), '/');
            if ($rest !== '' && strpos($rest, '/') === false) { return ['type'=>'profile','slug'=>sanitize_title($rest)]; }
        }
        return ['type'=>'','slug'=>''];
    }

    public static function template_include($template) {
        $route = self::route();
        if ($route['type'] === '') { return $template; }
        $own = dirname(__DIR__) . '/templates/hobbyregister.php';
        return is_readable($own) ? $own : $template;
    }

    public static function pre_handle_404($preempt, $wp_query) {
        if (self::route()['type'] === '') { return $preempt; }
        if (is_object($wp_query)) {
            if (property_exists($wp_query,'is_404')) { $wp_query->is_404 = false; }
        }
        if (function_exists('status_header')) { status_header(200); }
        return true;
    }

    public static function document_title($title) {
        $route = self::route();
        if ($route['type'] === 'index') { return 'Hobbyregister | Hobby Depot'; }
        if ($route['type'] === 'profile') {
            $row = self::record_by_slug($route['slug']);
            if ($row) { return (string)$row['canonical_name'] . ' – Hobby-Steckbrief | Hobby Depot'; }
        }
        return $title;
    }

    public static function head_meta() {
        $route = self::route();
        if ($route['type'] === '') { return; }
        // Prototyp: Detailprofile bleiben bis zur verbindlichen CORE/REGISTER-Owner-Matrix noindex.
        if ($route['type'] === 'profile') {
            echo "<meta name=\"robots\" content=\"noindex,follow\">\n";
        }
    }

    private static function base_url() { return home_url('/' . self::BASE_PATH . '/'); }
    private static function profile_url($row) { return self::base_url() . rawurlencode(self::slug_for_record($row)) . '/'; }
    private static function asset_url($name) { return plugins_url('assets/' . ltrim($name,'/'), dirname(__DIR__) . '/hobby-depot-hobbyregister-core.php'); }

    private static function slug_for_record($row) {
        return sanitize_title((string)($row['canonical_name'] ?? ''));
    }

    private static function build_slug_index() {
        if (self::$slug_index !== null) { return; }
        self::$slug_index = [];
        foreach (HD_Hobbyregister_Core_Stable127::records() as $row) {
            if (!is_array($row)) { continue; }
            $slug = self::slug_for_record($row);
            if ($slug !== '' && !isset(self::$slug_index[$slug])) { self::$slug_index[$slug] = $row; }
        }
    }

    private static function record_by_slug($slug) {
        self::build_slug_index();
        return self::$slug_index[$slug] ?? null;
    }

    private static function flatten_traits($row) {
        $out=[];
        foreach (($row['traits'] ?? []) as $id=>$assignment) {
            if (is_array($assignment) && array_key_exists('value',$assignment)) { $out[$id]=$assignment['value']; }
        }
        return $out;
    }

    private static function group_defs() {
        return [
            'gestalten'=>['label'=>'Gestalten','icon'=>'palette','desc'=>'Form, Farbe, Ausdruck und kreative Gestaltung.'],
            'fertigen'=>['label'=>'Fertigen','icon'=>'hammer','desc'=>'Herstellen, bauen, verarbeiten und reparieren.'],
            'technik'=>['label'=>'Technik','icon'=>'chip','desc'=>'Elektronik, Mechanik, Geräte und technische Systeme.'],
            'forschen'=>['label'=>'Forschen','icon'=>'search','desc'=>'Beobachten, messen, dokumentieren und verstehen.'],
            'pflanzen'=>['label'=>'Pflanzen','icon'=>'leaf','desc'=>'Anbauen, pflegen, vermehren und gestalten mit Pflanzen.'],
            'tiere'=>['label'=>'Tiere','icon'=>'paw','desc'=>'Tierbezogene Hobbys, Haltung und Beobachtung.'],
            'bewegen'=>['label'=>'Bewegen','icon'=>'move','desc'=>'Aktive Hobbys, Balance, Ausdauer und Bewegung.'],
            'sammeln'=>['label'=>'Sammeln','icon'=>'grid','desc'=>'Finden, ordnen, bewahren und Sammlungen aufbauen.'],
        ];
    }

    private static function groups_for_record($row) {
        $id=(string)($row['registry_id'] ?? '');
        if (isset(self::$groups_cache[$id])) { return self::$groups_cache[$id]; }
        $valid=array_keys(self::group_defs()); $groups=[];
        $world=sanitize_key((string)($row['source_identity']['natural_world'] ?? ''));
        if (in_array($world,$valid,true)) { $groups[]=$world; }
        $t=self::flatten_traits($row); $modes=(array)($t['activity_modes'] ?? []);
        $has=static function($needles) use ($modes) { return (bool)array_intersect((array)$needles,$modes); };
        if ($has(['gestalten','entwerfen','auffuehren'])) $groups[]='gestalten';
        if ($has(['bauen','reparieren','kochen_fermentieren'])) $groups[]='fertigen';
        if ($has(['forschen','beobachten','fotografieren_dokumentieren','entdecken'])) $groups[]='forschen';
        if ($has(['anbauen'])) $groups[]='pflanzen';
        if ($has(['bewegen','wettkaempfen'])) $groups[]='bewegen';
        if ($has(['sammeln'])) $groups[]='sammeln';
        $groups=array_values(array_unique(array_filter($groups,static fn($x)=>in_array($x,$valid,true))));
        if (!$groups) { $groups=['forschen']; }
        self::$groups_cache[$id]=$groups;
        return $groups;
    }

    private static function primary_group($row) {
        $world=sanitize_key((string)($row['source_identity']['natural_world'] ?? ''));
        if (isset(self::group_defs()[$world])) return $world;
        $g=self::groups_for_record($row); return $g[0] ?? 'forschen';
    }

    private static function icon($kind) {
        $icons=[
            'palette'=>'<path d="M12 3a9 9 0 1 0 0 18c1.4 0 2.1-.8 2.1-1.8 0-.8-.5-1.4-.5-2.1 0-1.1.9-2 2-2h1.8c2 0 3.6-1.6 3.6-3.6C21 6.8 17 3 12 3Z"/><circle cx="7.5" cy="10" r=".8"/><circle cx="10" cy="6.8" r=".8"/><circle cx="14" cy="6.8" r=".8"/><circle cx="17" cy="10" r=".8"/>',
            'hammer'=>'<path d="m14 5 5 5-2 2-2-2-7.5 7.5-3-3L12 7l-2-2 2-2 2 2Z"/>',
            'chip'=>'<rect x="7" y="7" width="10" height="10" rx="1"/><path d="M9 2v3m3-3v3m3-3v3M9 19v3m3-3v3m3-3v3M2 9h3m-3 3h3m-3 3h3m14-6h3m-3 3h3m-3 3h3"/>',
            'search'=>'<circle cx="10.5" cy="10.5" r="6"/><path d="m15 15 5 5"/>',
            'leaf'=>'<path d="M20 4C12 4 6 7 5 14c4 1 8 0 11-3-2 4-5 6-10 7"/><path d="M5 21c0-5 2-9 6-12"/>',
            'paw'=>'<circle cx="8" cy="7" r="2"/><circle cx="16" cy="7" r="2"/><circle cx="5" cy="12" r="1.7"/><circle cx="19" cy="12" r="1.7"/><path d="M12 11c-3 0-5 3-5 5.2C7 18 9 19 12 19s5-1 5-2.8C17 14 15 11 12 11Z"/>',
            'move'=>'<circle cx="12" cy="4" r="2"/><path d="m10 8 4 2 3 4m-7-6-3 5m5-2-2 5-4 4m6-4 4 4"/>',
            'grid'=>'<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
        ];
        return '<svg viewBox="0 0 24 24" aria-hidden="true">'.($icons[$kind] ?? $icons['grid']).'</svg>';
    }

    private static function breadcrumb_markup($name='') {
        $parts=[];
        $parts[]='<a href="'.esc_url(home_url('/')).'">Startseite</a>';
        $parts[]='<a href="'.esc_url(home_url('/magazin/')).'">Magazin</a>';
        if ($name==='') {
            $parts[]='<span aria-current="page">Hobbyregister</span>';
        } else {
            $parts[]='<a href="'.esc_url(self::base_url()).'">Hobbyregister</a>';
            $parts[]='<span aria-current="page">'.esc_html($name).'</span>';
        }
        return '<nav class="hd-breadcrumb hdr-breadcrumb" aria-label="Breadcrumb">'.implode('<b aria-hidden="true">›</b>',$parts).'</nav>';
    }

    private static function breadcrumb($name='') {
        return '<div class="hd-breadcrumb-wrap hdr-breadcrumb-wrap" data-hd-register-breadcrumb="1.2.16">'.self::breadcrumb_markup($name).'</div>';
    }

    public static function body_class($classes) {
        $classes=is_array($classes)?$classes:[];
        if (self::route()['type']!=='') { $classes[]='hd-hobbyregister-route'; }
        return array_values(array_unique($classes));
    }

    public static function render_breadcrumb_server() {
        $route=self::route();
        if ($route['type']==='') { return; }
        $name='';
        if ($route['type']==='profile') {
            $row=self::record_by_slug($route['slug']);
            if ($row) { $name=(string)($row['canonical_name']??''); }
        }
        echo self::breadcrumb($name);
    }

    private static function group_asset($group) {
        $map=[
            'gestalten'=>'groups/gestalten.webp','fertigen'=>'groups/fertigen.webp','technik'=>'groups/technik.webp','forschen'=>'groups/forschen.webp',
            'pflanzen'=>'groups/pflanzen.webp','tiere'=>'groups/tiere.webp','bewegen'=>'groups/bewegen.webp','sammeln'=>'groups/sammeln.webp',
        ];
        return $map[$group] ?? 'register-hero.webp';
    }

    private static function record_image($row) {
        $id=(string)($row['registry_id'] ?? '');
        $entry=HD_Hobbyregister_Core_Stable127::image_entry($id);
        if (is_array($entry)) {
            $path=trim((string)($entry['path'] ?? ''));
            $source=(string)($entry['source'] ?? '');
            if ($path!=='') {
                if ($source==='hd003' && function_exists('plugins_url')) {
                    return plugins_url('affiliate-portal-template-kit/assets/'.ltrim($path,'/'));
                }
                if ($source==='hd007') return self::asset_url($path);
            }
        }
        return self::asset_url(self::group_asset(self::primary_group($row)));
    }

    private static function profile_claim($row) {
        $group=self::primary_group($row);
        $claims=[
            'gestalten'=>'Ideen sichtbar machen.',
            'fertigen'=>'Mit den Händen schaffen.',
            'technik'=>'Tüfteln. Bauen. Verstehen.',
            'forschen'=>'Neugier wird Wissen.',
            'pflanzen'=>'Wachsen lassen.',
            'tiere'=>'Beobachten. Pflegen. Verstehen.',
            'bewegen'=>'Bewegung, die fordert.',
            'sammeln'=>'Finden. Ordnen. Bewahren.',
        ];
        return $claims[$group] ?? 'Entdecken. Verstehen. Ausprobieren.';
    }

    private static function hero($profile=false,$row=null) {
        if ($profile && is_array($row)) {
            $claim=self::profile_claim($row);
            return '<section class="hdr-hero is-profile"><div class="hdr-hero-copy"><span class="hdr-brush-claim" style="--hdr-brush:url('.esc_url(self::asset_url('brush-underline.webp')).')">'.esc_html($claim).'</span><h1>'.esc_html((string)$row['canonical_name']).'</h1></div><figure><img src="'.esc_url(self::record_image($row)).'" alt="'.esc_attr((string)$row['canonical_name']).'" fetchpriority="high" decoding="async"></figure></section>';
        }
        return '<section class="hdr-hero"><div class="hdr-hero-copy"><span class="hdr-brush-claim" style="--hdr-brush:url('.esc_url(self::asset_url('brush-underline.webp')).')">Hobbys von A bis Z</span><h1>Hobbyregister</h1><p>Entdecke neue und ungewöhnliche Hobbys</p></div><figure><img src="'.esc_url(self::asset_url('register-hero.webp')).'" alt="Viele unterschiedliche Hobbys entdecken" fetchpriority="high" decoding="async"></figure></section>';
    }

    private static function lower($value) {
        $value=(string)$value;
        return function_exists('mb_strtolower') ? mb_strtolower($value,'UTF-8') : strtolower($value);
    }

    private static function first_upper($value) {
        $value=(string)$value;
        $first=function_exists('mb_substr') ? mb_substr($value,0,1,'UTF-8') : substr($value,0,1);
        return function_exists('mb_strtoupper') ? mb_strtoupper($first,'UTF-8') : strtoupper($first);
    }

    private static function contains_ci($haystack,$needle) {
        $haystack=self::lower($haystack); $needle=self::lower($needle);
        if ($needle==='') return true;
        return function_exists('mb_strpos') ? mb_strpos($haystack,$needle,0,'UTF-8')!==false : strpos($haystack,$needle)!==false;
    }

    private static function request_filters() {
        $s=isset($_GET['hr_s'])?trim(sanitize_text_field(wp_unslash((string)$_GET['hr_s']))):'';
        $letter=isset($_GET['hr_letter'])?strtoupper(sanitize_text_field(wp_unslash((string)$_GET['hr_letter']))):'';
        $letter=preg_match('/^[A-Z]$/',$letter)?$letter:'';
        $group=isset($_GET['hr_group'])?sanitize_key(wp_unslash((string)$_GET['hr_group'])):'';
        if (!isset(self::group_defs()[$group])) $group='';
        $page=max(1,isset($_GET['hr_page'])?absint($_GET['hr_page']):1);
        return compact('s','letter','group','page');
    }

    private static function filter_records($filters) {
        $rows=[]; $needle=(string)$filters['s'];
        foreach (HD_Hobbyregister_Core_Stable127::records() as $row) {
            if (!is_array($row)) continue;
            $name=(string)($row['canonical_name'] ?? '');
            if ($needle!=='' && !self::contains_ci($name,$needle)) continue;
            if ($filters['letter']!=='') {
                $first=self::first_upper($name);
                if ($first!==$filters['letter']) continue;
            }
            if ($filters['group']!=='' && !in_array($filters['group'],self::groups_for_record($row),true)) continue;
            $rows[]=$row;
        }
        usort($rows,static fn($a,$b)=>strnatcasecmp((string)$a['canonical_name'],(string)$b['canonical_name']));
        return $rows;
    }

    private static function query_url($args=[]) {
        $base=self::base_url();
        $args=array_filter($args,static fn($v)=>$v!=='' && $v!==null && $v!==0);
        return $args?add_query_arg($args,$base):$base;
    }

    private static function render_tools($filters) {
        $az=''; foreach(range('A','Z') as $l){ $az.='<a'.($filters['letter']===$l?' aria-current="page"':'').' href="'.esc_url(self::query_url(['hr_letter'=>$l,'hr_group'=>$filters['group']])).'">'.$l.'</a>'; }
        $all_current = $filters['letter']==='' ? ' aria-current="page"' : '';
        return '<section class="hdr-tools"><form class="hdr-register-search" action="'.esc_url(self::base_url()).'" method="get" data-hdr-ajax-url="'.esc_url(admin_url('admin-ajax.php')).'" data-hdr-nonce="'.esc_attr(wp_create_nonce('hd_hobbyregister_search')).'"><div class="hdr-search-row"><span class="hdr-search-field"><input id="hdr-search" name="hr_s" type="search" value="'.esc_attr($filters['s']).'" placeholder="Hobby suchen …" aria-label="Hobby suchen" autocomplete="off"><span class="hdr-search-suggestions" hidden></span><span class="screen-reader-text" role="status" aria-live="polite"></span></span><button type="submit">Suchen</button></div></form><nav class="hdr-az" aria-label="Hobbys alphabetisch"><a'.$all_current.' href="'.esc_url(self::query_url(['hr_group'=>$filters['group']])).'">Alle</a>'.$az.'</nav></section>';
    }

    private static function search_items($search,$limit=8) {
        $search=trim((string)$search);
        $len=function_exists('mb_strlen')?mb_strlen($search,'UTF-8'):strlen($search);
        if($len<2)return [];
        $items=[];
        foreach(HD_Hobbyregister_Core_Stable127::records() as $row){
            if(!is_array($row))continue;
            $name=trim((string)($row['canonical_name']??''));
            if($name===''||!self::contains_ci($name,$search))continue;
            $items[]=['title'=>$name,'url'=>self::profile_url($row)];
        }
        usort($items,static fn($a,$b)=>strnatcasecmp((string)$a['title'],(string)$b['title']));
        return array_slice($items,0,max(1,(int)$limit));
    }

    public static function ajax_search() {
        if(function_exists('check_ajax_referer'))check_ajax_referer('hd_hobbyregister_search','nonce');
        $search=isset($_REQUEST['q'])?sanitize_text_field(wp_unslash((string)$_REQUEST['q'])):'';
        wp_send_json_success(['items'=>self::search_items($search,8)]);
    }

    private static function search_script() {
        return <<<'HDRSEARCHJS'
<script id="hd-hobbyregister-search-v1216">
(function(){
 var form=document.querySelector('.hdr-register-search'),input=document.getElementById('hdr-search');
 if(!form||!input)return;
 var box=form.querySelector('.hdr-search-suggestions'),status=form.querySelector('[role="status"]'),timer=0,controller=null;
 function clearBox(){box.innerHTML='';box.hidden=true;if(status)status.textContent='';}
 function esc(v){return String(v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c];});}
 function fetchItems(){
   var q=String(input.value||'').replace(/\s+/g,' ').trim(); if(q.length<2){clearBox();return;}
   if(controller)controller.abort(); controller=(typeof AbortController!=='undefined')?new AbortController():null;
   var body=new URLSearchParams({action:'hd_hobbyregister_search',nonce:form.getAttribute('data-hdr-nonce')||'',q:q});
   fetch(form.getAttribute('data-hdr-ajax-url'),{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString(),signal:controller?controller.signal:undefined,credentials:'same-origin'})
   .then(function(r){if(!r.ok)throw new Error('http');return r.json();})
   .then(function(data){
      var items=data&&data.success&&data.data&&Array.isArray(data.data.items)?data.data.items:[];
      if(!items.length){box.innerHTML='<span class="hdr-search-empty">Keine passenden Hobbys gefunden.</span>';box.hidden=false;if(status)status.textContent='Keine Treffer';return;}
      box.innerHTML=items.slice(0,8).map(function(it){return '<a class="hdr-search-suggestion" href="'+esc(it.url)+'">'+esc(it.title)+'</a>';}).join('');
      box.hidden=false;if(status)status.textContent=items.length+' Treffer';
   }).catch(function(e){if(e&&e.name==='AbortError')return;clearBox();});
 }
 input.addEventListener('input',function(){clearTimeout(timer);timer=setTimeout(fetchItems,180);});
 input.addEventListener('focus',function(){if(input.value.trim().length>=2)fetchItems();});
 document.addEventListener('click',function(e){if(!form.contains(e.target))clearBox();});
})();
</script>
HDRSEARCHJS;
    }

    private static function render_groups($filters) {
        $html='<section class="hdr-groups"><header><h2>Hobbygruppen entdecken</h2></header><nav class="hdr-group-grid" aria-label="Hobbygruppen">';
        foreach(self::group_defs() as $key=>$def){
            $url=self::query_url(['hr_group'=>$key]);
            $html.='<a class="hdr-group" href="'.esc_url($url).'"'.($filters['group']===$key?' aria-current="page"':'').'><span class="hdr-group-icon">'.self::icon($def['icon']).'</span><strong>'.esc_html($def['label']).'</strong></a>';
        }
        return $html.'</nav></section>';
    }

    private static function affiliate_banner() {
        $html='';
        if (function_exists('shortcode_exists') && shortcode_exists('pp_affiliate_slot') && function_exists('do_shortcode')) {
            $html=trim((string)do_shortcode('[pp_affiliate_slot type="hub_after_cards" intent="portal_context"]'));
        }
        if ($html==='') {
            if (!function_exists('is_user_logged_in') || !is_user_logged_in()) { return ''; }
            $html='<div class="hdr-banner-preview"><small>NUR EINGELOGGT SICHTBAR</small><strong>Affiliate-Banner</strong><span>Platz aktuell nicht belegt</span></div>';
        }
        return '<section class="hdr-affiliate hdr-affiliate-register" aria-label="Anzeige / Partner"><span class="hdr-ad-label">Anzeige / Partner</span><div class="hdr-affiliate-box">'.$html.'</div></section>';
    }

    private static function pagination($filters,$page,$pages,$position='bottom') {
        if ($pages <= 1) { return ''; }
        $html='<nav class="hdr-pagination is-'.esc_attr($position).'" aria-label="Registerseiten">';
        for($i=1;$i<=$pages;$i++){
            if($i>1 && $i<$pages && abs($i-$page)>2) {
                if($i==2||$i==$pages-1){$html.='<span>…</span>';}
                continue;
            }
            $args=['hr_s'=>$filters['s'],'hr_letter'=>$filters['letter'],'hr_group'=>$filters['group'],'hr_page'=>$i];
            $html.='<a'.($i===$page?' aria-current="page"':'').' href="'.esc_url(self::query_url($args)).'#hobby-liste">'.$i.'</a>';
        }
        return $html.'</nav>';
    }

    private static function render_cards($rows,$filters) {
        $per=16; $total=count($rows); $pages=max(1,(int)ceil($total/$per)); $page=min(max(1,(int)$filters['page']),$pages); $slice=array_slice($rows,($page-1)*$per,$per);
        $heading='Hobbys im Überblick';
        if($filters['group']!=='' && isset(self::group_defs()[$filters['group']])) $heading=self::group_defs()[$filters['group']]['label'].' – Hobbys im Überblick';
        if($filters['letter']!=='') $heading.=' – '.$filters['letter'];
        $filtered = $filters['s']!=='' || $filters['letter']!=='' || $filters['group']!=='';
        $counter = $filtered ? '<span class="hdr-result-count">'.number_format_i18n($total).' Hobbys</span>' : '';
        $html='<section id="hobby-liste" class="hdr-list"><header><div><h2>'.esc_html($heading).'</h2>'.$counter.'</div>';
        if($filtered) $html.='<a href="'.esc_url(self::base_url()).'">Zur Register-Startseite</a>';
        $html.='</header>';
        $html.=self::pagination($filters,$page,$pages,'top');
        $html.='<div class="hdr-card-grid">';
        foreach($slice as $row){
            $p=(array)($row['result_profile']??[]); $excerpt=(string)($p['what_is_it']??''); $name=(string)$row['canonical_name'];
            $sample=in_array(self::slug_for_record($row),['buchbinden','slacklining'],true);
            $html.='<a class="hdr-card'.($sample?' is-sample':'').'" href="'.esc_url(self::profile_url($row)).'"><h3>'.esc_html($name).'</h3><p>'.esc_html($excerpt).'</p>'.($sample?'<em>Textprobe</em>':'').'<span>zum Hobby →</span></a>';
        }
        $html.='</div>';
        $html.=self::pagination($filters,$page,$pages,'bottom');
        return $html.'</section>';
    }

    private static function map_value($key,$v) {
        $maps=[
            'startup_budget'=>['0_bis_25'=>'bis 25 €','25_bis_100'=>'25–100 €','100_bis_300'=>'100–300 €','300_bis_1000'=>'300–1.000 €','1000_plus'=>'über 1.000 €'],
            'session_length'=>['unter_30_min'=>'unter 30 Min.','30_bis_90_min'=>'30–90 Min.','90_bis_240_min'=>'1,5–4 Std.','halber_tag_plus'=>'halber Tag oder länger'],
            'active_space'=>['minimal'=>'sehr wenig','tischbereich'=>'Tischbereich','kleiner_bereich'=>'kleiner Bereich','raum'=>'eigener Raum','grosser_bereich'=>'größerer Bereich','sehr_grosser_bereich'=>'sehr großer Bereich'],
            'learning_curve'=>['leicht'=>'leicht','mittel'=>'mittel','steil'=>'steil'],
            'schedule_flexibility'=>['jederzeit_spontan'=>'sehr spontan','flexibel_planbar'=>'flexibel planbar','feste_zeiten'=>'feste Zeiten','termin_oder_buchung'=>'Termin/Buchung'],
            'surprise_level'=>['klassisch'=>'klassisch','nische'=>'Nische','ungewoehnlich'=>'ungewöhnlich','sehr_schraeg'=>'sehr ungewöhnlich'],
        ];
        if(isset($maps[$key][(string)$v])) return $maps[$key][(string)$v];
        if(is_array($v)) return implode(', ',array_map(static fn($x)=>str_replace('_',' ',(string)$x),$v));
        return str_replace('_',' ',(string)$v);
    }

    private static function fact_icon($kind) {
        $icons=[
            'people'=>'<circle cx="8" cy="9" r="3"/><circle cx="17" cy="8" r="2.4"/><path d="M3 20c.5-4 2.5-6 5-6s4.5 2 5 6M14 14c3 0 5 2 5.5 5"/>',
            'pin'=>'<path d="M12 21s6-5.5 6-11a6 6 0 1 0-12 0c0 5.5 6 11 6 11Z"/><circle cx="12" cy="10" r="2"/>',
            'clock'=>'<circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/>',
            'coin'=>'<circle cx="12" cy="12" r="8"/><path d="M14.5 8.5c-.6-.6-1.4-.9-2.4-.9-1.7 0-3 1-3 2.3 0 1.4 1.1 2 3.1 2.5 2 .5 3 1.1 3 2.5 0 1.4-1.3 2.4-3.1 2.4-1.2 0-2.3-.4-3-1.2M12 6v12"/>',
            'space'=>'<rect x="5" y="5" width="14" height="14" rx="1"/><path d="M8 12h8M12 8v8"/>',
            'activity'=>'<circle cx="12" cy="4" r="2"/><path d="m10 8 4 2 3 4m-7-6-3 5m5-2-2 5-4 4m6-4 4 4"/>',
            'learn'=>'<path d="M4 6.5 12 3l8 3.5-8 3.5-8-3.5Z"/><path d="M7 9v4c0 1.5 2.2 3 5 3s5-1.5 5-3V9M20 7v5"/>',
            'gear'=>'<circle cx="12" cy="12" r="3"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3M4.9 4.9 7 7m10 10 2.1 2.1M19.1 4.9 17 7M7 17l-2.1 2.1"/>',
        ];
        return '<svg viewBox="0 0 24 24" aria-hidden="true">'.($icons[$kind] ?? $icons['gear']).'</svg>';
    }

    private static function level_word($v) {
        $n=(int)$v;
        return [1=>'sehr gering',2=>'gering',3=>'mittel',4=>'hoch',5=>'sehr hoch'][$n] ?? '';
    }

    private static function facts($row) {
        $t=self::flatten_traits($row);
        $social=(array)($t['social_modes']??[]); $social=array_map(static function($x){return ['solo'=>'allein','zu_zweit'=>'zu zweit','kleingruppe'=>'kleine Gruppe','gruppe'=>'Gruppe','community'=>'Community','flexibel'=>'flexibel'][$x]??str_replace('_',' ',$x);},$social);
        $location=(array)($t['location_mode']??[]); $location=array_map(static fn($x)=>$x==='drinnen'?'drinnen':($x==='draussen'?'draußen':str_replace('_',' ',$x)),$location);
        $vals=[
            ['people','Mit wem?',implode(', ',$social)],
            ['pin','Ort',implode(' / ',$location)],
            ['clock','Zeit',self::map_value('session_length',$t['session_length']??'')],
            ['coin','Einstieg',self::map_value('startup_budget',$t['startup_budget']??'')],
            ['space','Platz',self::map_value('active_space',$t['active_space']??'')],
            ['activity','Körperlich',self::level_word($t['physical_intensity']??'')],
            ['learn','Lernkurve',self::map_value('learning_curve',$t['learning_curve']??'')],
        ];
        $out='<section class="hdr-facts"><h2>Auf einen Blick</h2><div class="hdr-fact-list">';
        foreach($vals as [$icon,$k,$v]){
            $out.='<div class="hdr-fact" aria-label="'.esc_attr($k).'"><span class="hdr-fact-icon">'.self::fact_icon($icon).'</span><div><span>'.esc_html($v!==''?$v:'–').'</span></div></div>';
        }
        return $out.'</div></section>';
    }

    private static function sample_articles() {
        return [
'Buchbinden'=>[
['Worum geht es beim Buchbinden?','Buchbinden ist ein ruhiges, analoges Handwerk, bei dem aus einzelnen Papierlagen ein nutzbares Buch, Heft oder Notizbuch entsteht. Du falzt Papier, stellst einen Buchblock zusammen, heftest oder nähst ihn, verleimst bei Bedarf den Rücken und verbindest alles mit einem Einband. Der Reiz liegt weniger in schneller Dekoration als in sauberem Aufbau: Kanten, Falze, Fadenführung und Materialwahl entscheiden darüber, wie gut sich das fertige Buch öffnen, benutzen und aufbewahren lässt. Gleichzeitig bleibt viel Raum für Gestaltung. Papier, Vorsatz, Bezugsmaterial, Format und Bindetechnik können sehr unterschiedlich gewählt werden. Damit verbindet das Hobby präzises Fertigen mit kreativem Gestalten – und am Ende hältst du ein dauerhaft nutzbares Ergebnis in der Hand.'],
['Passt Buchbinden zu dir?','Buchbinden passt besonders gut, wenn du gern konzentriert arbeitest und sichtbaren Fortschritt in kleinen, kontrollierten Schritten magst. Du kannst vollständig allein arbeiten, aber auch zu zweit oder in einer kleinen Gruppe. Wettbewerb spielt praktisch keine Rolle. Das Tempo ist ruhig, die Varianten sind dagegen sehr vielfältig: vom einfachen Heft bis zum aufwendig bezogenen Hardcover. Geduld und Genauigkeit sind wichtiger als Kraft. Wer gern mit den Händen arbeitet, Materialien kombiniert und ein Projekt wirklich fertigstellt, findet hier viel Tiefe. Auch zum Abschalten eignet sich das Hobby gut, weil kein Bildschirm nötig ist und viele Arbeitsschritte wiederkehrend und fokussiert sind.'],
['Wo und wann kannst du Bücher binden?','Du brauchst keinen eigenen Werkraum. Ein stabiler Tisch reicht für viele Projekte aus, deshalb funktioniert Buchbinden gut zu Hause und ganzjährig. Wetter, Tageslicht und Reisen spielen kaum eine Rolle. Für eine typische Einheit solltest du eher mit eineinhalb bis vier Stunden rechnen; größere Projekte verteilen sich auf mehrere Einheiten oder über längere Zeit. Trotzdem bleibt das Hobby flexibel: Du kannst spontan anfangen, jederzeit pausieren und später weiterarbeiten. Kurze Trocknungs- oder Presszeiten gehören je nach Bindung dazu, erzwingen aber keinen festen Wochenrhythmus.'],
['Platz, Alltag und Pflege','Der aktive Platzbedarf bleibt meist auf einen Tisch beschränkt. Papier, Faden, Leim und Werkzeuge lassen sich relativ kompakt lagern, viele Dinge passen in eine Tasche oder kleine Box. Das Hobby ist leise und verursacht normalerweise nur wenig Schmutz. Besondere Anschlüsse oder technische Infrastruktur brauchst du nicht. Vor und nach einer Arbeitseinheit fällt etwas Aufräumen an, vor allem bei Leim, Papierabschnitten und Schneidwerkzeugen. Die Ausrüstung selbst benötigt nur geringe Pflege: Schneidwerkzeuge sollten sauber und scharf bleiben, Pinsel oder Leimwerkzeuge werden nach Gebrauch gereinigt.'],
['Kosten und Ausrüstung','Für den Einstieg genügt eine überschaubare Basisausstattung. Papier, Lineal, Schneidwerkzeug, Falzbein, Faden, Nadel, Leim und ein geeignetes Einbandmaterial reichen für viele erste Projekte. Typisch ist ein Einstiegsbudget von etwa 25 bis 100 Euro. Laufende Kosten bleiben gering, allerdings verbrauchst du regelmäßig Papier, Faden, Leim und je nach Projekt Bezugsmaterial. Leihen oder Mieten spielt kaum eine Rolle, weil die Basisausrüstung klein und vergleichsweise günstig ist. Später kannst du gezielt in bessere Schneidwerkzeuge, Presshilfen oder Spezialmaterialien investieren, ohne dass das für den Einstieg notwendig wäre.'],
['Was musst du können?','Körperlich ist Buchbinden wenig fordernd: Kraft und Ausdauer spielen nur eine kleine Rolle. Entscheidend sind Feinmotorik, Konzentration und Präzision. Saubere Falze, gerade Schnitte, gleichmäßige Lochabstände und eine kontrollierte Fadenspannung machen einen großen Unterschied. Die Koordinationsanforderung ist vorhanden, aber deutlich niedriger als bei einem Balance- oder Bewegungshobby. Die Lernkurve ist mittel: einfache Bindungen sind für Anfänger gut erreichbar, während historische Techniken, komplexe Einbände oder Restaurierungsarbeiten sehr viel Tiefe bieten. Eine gute Anleitung hilft beim Einstieg, zwingend ist ein Kurs aber nicht.'],
['Was entsteht daraus?','Das Ergebnis ist unmittelbar greifbar: ein selbst gebundenes Heft, Skizzenbuch, Tagebuch, Album oder Buch. Neben dem Gegenstand wächst mit jedem Projekt auch die handwerkliche Fähigkeit. Buchbinden bleibt überwiegend analog und kommt ohne Bildschirm aus. Du kannst streng nach einer Technik arbeiten oder Gestaltung und Aufbau frei kombinieren. Genau diese Mischung aus Struktur und kreativen Entscheidungen sorgt dafür, dass das Hobby trotz wiederkehrender Grundschritte nicht schnell eintönig wird.'],
['Grenzen und Sicherheit','Die Sicherheitsrisiken sind niedrig, aber scharfe Messer, Nadeln und einzelne Klebstoffe verlangen einen sorgfältigen Umgang. Besondere Genehmigungen gibt es nicht. Es entstehen keine dauerhaften Pflegepflichten, und ein angefangenes Projekt kann in der Regel problemlos ruhen. Das Hobby lässt sich gut an unterschiedliche Arbeitsweisen anpassen und ist für Jugendliche, Erwachsene und Senioren grundsätzlich zugänglich, sofern Schneidwerkzeuge sicher verwendet werden können.']
],
'Slacklining'=>[
['Worum geht es beim Slacklining?','Beim Slacklining balancierst du auf einem zwischen zwei sicheren Anschlagpunkten gespannten Band. Am Anfang geht es oft nur darum, ruhig zu stehen und wenige kontrollierte Schritte zu schaffen. Mit mehr Übung kommen Wendungen, längere Lines und je nach Ausrichtung Tricks hinzu. Der besondere Reiz ist das direkte Feedback: Schon kleine Veränderungen in Haltung, Blick, Atmung oder Körperspannung entscheiden darüber, ob du auf der Line bleibst. Dadurch fühlt sich Fortschritt sehr unmittelbar an. Slacklining ist ein analoges Bewegungshobby mit starkem Naturbezug und kann von einer einfachen niedrigen Line bis zu technisch und sicherheitsseitig deutlich anspruchsvolleren Varianten reichen.'],
['Passt Slacklining zu dir?','Das Hobby passt gut, wenn du eine körperliche Herausforderung suchst, Geduld mit wiederholten Versuchen hast und Fortschritt gern direkt spürst. Slacklining wird häufig zu zweit, in kleinen Gruppen oder in einer Community ausgeübt. Es ist kein klassisches Mannschaftshobby, aber sichere Anschlagpunkte, Aufbau und gegenseitige Unterstützung machen gemeinsame Sessions sinnvoll. Das Tempo auf der Line ist eher ruhig, die körperliche und mentale Anforderung dagegen hoch. Wettbewerb muss überhaupt keine Rolle spielen. Wer Natur, Balance und konzentrierte Bewegung verbinden möchte, findet hier eine ungewöhnliche, sehr variable Freizeitbeschäftigung.'],
['Wo und wann kannst du slacklinen?','Typisch ist Slacklining draußen an geeigneten Orten mit belastbaren, erlaubten Anschlagpunkten. Du brauchst viel freien Raum und musst Standort, Untergrund und Umgebung prüfen. Deshalb ist das Hobby stärker vom Wetter und vom Tageslicht abhängig als viele Indoor-Hobbys. Häufig planst du eine Session flexibel, aber nicht völlig spontan, weil Anfahrt und Aufbau dazugehören können. Eine Einheit kann leicht einen halben Tag oder länger dauern, besonders wenn du gemeinsam trainierst. Das Hobby ist grundsätzlich ganzjährig möglich, praktisch bestimmen Wetter, Bodenverhältnisse und sichere Bedingungen, wann eine Session sinnvoll ist.'],
['Platz, Alltag und Pflege','Der Platzbedarf ist groß: Nicht die gelagerte Ausrüstung, sondern der freie Bereich um die gespannte Line ist entscheidend. Die Ausrüstung selbst benötigt mittleren Stauraum und wird häufig mit dem Auto transportiert. Der Aufbau ist deutlich aufwendiger als bei einem Tischhobby und sollte nicht nebenbei erfolgen. Slackline, Ratsche oder Spannsystem, Baumschutz und Verbindungsteile müssen regelmäßig kontrolliert werden. Die Pflege der Ausrüstung ist deshalb mittel: Verschleiß, Verschmutzung und Beschädigungen an Band und Metallteilen dürfen nicht ignoriert werden. Lärm und Schmutz bleiben im normalen beziehungsweise geringen Bereich.'],
['Kosten und Ausrüstung','Für einfaches Slacklining reicht eine passende Line mit sicherem Spannsystem und geeignetem Baumschutz. Je nach Ausrichtung kann zusätzliche Sicherungs- und Spezialtechnik hinzukommen. Das zentrale Register ordnet den Einstieg eher in einen höheren Bereich von etwa 300 bis 1.000 Euro ein, wenn die typische umfangreichere Ausrüstung betrachtet wird. Laufende Kosten sind dagegen gering und Verbrauchsmaterial spielt kaum eine Rolle. Teile der Ausrüstung lassen sich vergleichsweise leicht leihen, was zum Ausprobieren sinnvoll sein kann. Entscheidend ist weniger möglichst viel Material als ein technisch passendes, unbeschädigtes und für den Einsatz geeignetes Setup.'],
['Was musst du können?','Slacklining stellt hohe Anforderungen an Balance, Ganzkörperkoordination und Konzentration. Der Koordinationsbedarf liegt am oberen Ende der Skala, die körperliche Intensität ist hoch und auch Ausdauer spielt eine große Rolle. Reine Kraft ist dagegen nur mittel wichtig; entscheidender ist, Bewegungen fein zu kontrollieren und ständig kleine Korrekturen auszuführen. Die Lernkurve ist steil und die Anfängerfreundlichkeit eher niedrig, weil die ersten Versuche oft sehr kurz sind. Eine sachkundige Anleitung ist deshalb sinnvoll beziehungsweise bei anspruchsvolleren Varianten erforderlich. Gleichzeitig ist die Entwicklung nahezu offen: Länge, Spannung, Bewegungsabläufe und Varianten bieten sehr viel Meisterungstiefe.'],
['Was entsteht daraus?','Bei Slacklining entsteht kein Gegenstand, sondern vor allem eine Fähigkeit und ein Erlebnis. Du entwickelst Balance, Körpergefühl, Konzentration und je nach Trainingsumfang Fitness. Fortschritt ist sofort sichtbar: erst ein stabiler Stand, dann einzelne Schritte, längere Strecken und später neue Bewegungen. Das Hobby ist analog; ein Bildschirm ist für die Ausübung nicht nötig. Trotz klarer Sicherheitsregeln bleibt die Praxis sehr variabel, weil Line, Ort, Länge und persönliches Trainingsziel verändert werden können.'],
['Grenzen, Sicherheit und Regeln','Slacklining hat ein reales Sicherheitsrisiko. Anschlagpunkte, Materialzustand, Aufbauhöhe, Untergrund und freie Fallbereiche müssen ernst genommen werden. An manchen Orten gelten Regeln oder Einschränkungen zum Schutz von Bäumen, Flächen oder anderen Nutzern; solche Vorgaben müssen beachtet werden. Es gibt keine Pflegepflicht für Lebewesen und Sessions können grundsätzlich jederzeit pausieren. Die Anpassbarkeit ist dennoch geringer als bei vielen ruhigen Indoor-Hobbys, weil Ort, körperliche Voraussetzungen und sichere Rahmenbedingungen einen großen Einfluss haben.']
]
        ];
    }

    private static function human_list($items) {
        $items=array_values(array_filter(array_map('trim',(array)$items),static fn($x)=>$x!==''));
        $n=count($items); if($n===0)return ''; if($n===1)return $items[0]; if($n===2)return $items[0].' und '.$items[1];
        $last=array_pop($items); return implode(', ',$items).' und '.$last;
    }

    private static function labels($values,$map) {
        $out=[]; foreach((array)$values as $v){$k=(string)$v;$out[]=$map[$k]??str_replace('_',' ',$k);} return $out;
    }

    private static function sentence($text) {
        $text=trim((string)$text); if($text==='')return '';
        return preg_match('/[.!?]$/u',$text)?$text:$text.'.';
    }

    private static function generated_article_sections($row) {
        $name=(string)($row['canonical_name']??'dieses Hobby');
        $p=(array)($row['result_profile']??[]); $t=self::flatten_traits($row);
        $get=static fn($k,$d='')=>array_key_exists($k,$t)?$t[$k]:$d;
        $enum=static function($k,$map,$d='')use($get){$v=$get($k,'');return $map[(string)$v]??$d;};

        $activityMap=['gestalten'=>'Gestalten','bauen'=>'Bauen/Herstellen','reparieren'=>'Reparieren','entwerfen'=>'Entwerfen','beobachten'=>'Beobachten','forschen'=>'Forschen','sammeln'=>'Sammeln','bewegen'=>'Bewegen','anbauen'=>'Anbauen','pflegen'=>'Pflegen','wettkaempfen'=>'Wettkämpfen','spielen'=>'Spielen','auffuehren'=>'Aufführen','entdecken'=>'Entdecken','kochen_fermentieren'=>'Kochen und Fermentieren','fotografieren_dokumentieren'=>'Fotografieren und Dokumentieren'];
        $outcomeMap=['gegenstand'=>'Gegenstände','sammlung'=>'eine Sammlung','wissen'=>'Wissen','faehigkeit'=>'Fähigkeiten','fitness'=>'Fitness','erlebnis'=>'Erlebnisse','medieninhalt'=>'Medieninhalte','lebendes_system'=>'ein lebendes System','soziales_erlebnis'=>'soziale Erlebnisse'];
        $motivationMap=['entspannen_abschalten'=>'Entspannung und Abschalten','kreativ_ausdruecken'=>'kreativen Ausdruck','lernen_verstehen'=>'Lernen und Verstehen','koerperlich_aktiv_sein'=>'körperliche Aktivität','natur_erleben'=>'Naturerleben','bauen_herstellen'=>'Bauen und Herstellen','sammeln_ordnen'=>'Sammeln und Ordnen','entdecken_abenteuer'=>'Entdecken und Abenteuer','herausforderung_meistern'=>'eine Herausforderung','sozialer_kontakt'=>'sozialen Kontakt','wettbewerb'=>'Wettbewerb','pflegen_verantworten'=>'Pflegen und Verantwortung','dokumentieren'=>'Dokumentieren','auffuehren_zeigen'=>'Aufführen und Zeigen'];
        $socialMap=['solo'=>'allein','zu_zweit'=>'zu zweit','kleingruppe'=>'in einer kleinen Gruppe','gruppe'=>'in einer Gruppe','community'=>'in einer Community','flexibel'=>'flexibel'];
        $venueMap=['zuhause'=>'zu Hause','garten'=>'im Garten','oeffentlicher_raum'=>'im öffentlichen Raum','natur'=>'in der Natur','werkstatt'=>'in einer Werkstatt','spezialort'=>'an einem Spezialort','verein_kurs'=>'im Verein oder Kurs','flexibel'=>'an unterschiedlichen Orten','sportanlage_halle'=>'in einer Sportanlage oder Halle','schwimmbad_pool'=>'im Schwimmbad oder Pool','gewaesser'=>'an oder in einem Gewässer'];
        $seasonMap=['ganzjaehrig'=>'ganzjährig','fruehling'=>'im Frühling','sommer'=>'im Sommer','herbst'=>'im Herbst','winter'=>'im Winter'];
        $utilityMap=['keine_besonderen'=>'keine besonderen technischen Voraussetzungen','strom'=>'Strom','wasser'=>'Wasser','internet'=>'Internet','computer_smartphone'=>'Computer oder Smartphone','hitze_feuer'=>'Hitze oder Feuer','fahrzeug'=>'ein Fahrzeug','spezialtechnik'=>'Spezialtechnik'];
        $ageMap=['kinder_mit_begleitung'=>'Kinder mit Begleitung','jugendliche'=>'Jugendliche','erwachsene'=>'Erwachsene','senioren'=>'Senioren','breit_altersunabhaengig'=>'viele Altersgruppen','stark_abhaengig_von_variante'=>'je nach Variante unterschiedliche Altersgruppen'];

        $acts=self::human_list(self::labels($get('activity_modes',[]),$activityMap));
        $outs=self::human_list(self::labels($get('outcome_type',[]),$outcomeMap));
        $mots=self::human_list(self::labels($get('motivation_goals',[]),$motivationMap));
        $social=self::human_list(self::labels($get('social_modes',[]),$socialMap));
        $socialLevel=self::level_word($get('social_contact_level',''));
        $venues=self::human_list(self::labels($get('venue_need',[]),$venueMap));
        $seasons=self::human_list(self::labels($get('seasonality',[]),$seasonMap));
        $utilities=self::human_list(self::labels($get('utility_dependencies',[]),$utilityMap));
        $ages=self::human_list(self::labels($get('age_access',[]),$ageMap));

        $digital=$enum('digital_analog',['analog'=>'überwiegend analog','gemischt'=>'eine Mischung aus analogen und digitalen Anteilen','digital'=>'überwiegend digital']);
        $screen=$enum('screen_exposure',['kein_bildschirm'=>'Ein Bildschirm spielt praktisch keine Rolle','optional'=>'Ein Bildschirm kann helfen, ist aber nicht zwingend','zentral'=>'Digitale Bildschirme gehören zentral zum Hobby']);
        $surprise=$enum('surprise_level',['klassisch'=>'Es gehört eher zu den klassischen Hobbys','nische'=>'Es ist eher eine Nische','ungewoehnlich'=>'Es gehört zu den ungewöhnlicheren Hobbys','sehr_schraeg'=>'Es gehört zu den sehr ungewöhnlichen Hobbys']);
        $dependency=$enum('social_dependency',['unabhaengig'=>'Du bist dabei nicht auf andere Personen angewiesen','optional'=>'Andere Menschen können das Hobby bereichern, sind aber nicht zwingend nötig','partner_oder_gruppe_noetig'=>'Für die typische Ausübung brauchst du mindestens eine weitere Person oder eine Gruppe']);
        $competition=$enum('competition_role',['kein_fokus'=>'Wettbewerb steht nicht im Mittelpunkt','optional'=>'Wettbewerb ist möglich, aber kein Muss','zentral'=>'Wettbewerb gehört wesentlich zur typischen Ausübung']);
        $pace=$enum('pace',['ruhig'=>'Das Tempo ist eher ruhig','ausgeglichen'=>'Das Tempo ist ausgewogen','dynamisch'=>'Das Hobby ist eher dynamisch','actionreich'=>'Das Hobby ist deutlich actionorientiert']);
        $variety=$enum('variety_profile',['eher_wiederholend'=>'Viele Abläufe wiederholen sich','gemischt'=>'Wiederholung und Abwechslung halten sich ungefähr die Waage','sehr_variabel'=>'Die Tätigkeit ist sehr abwechslungsreich']);
        $structure=$enum('structure_style',['frei_improvisierend'=>'Du kannst sehr frei und improvisierend vorgehen','eher_frei'=>'Es gibt viel gestalterischen oder praktischen Freiraum','gemischt'=>'Freie Entscheidungen und feste Regeln wechseln sich ab','eher_regelbasiert'=>'Viele Schritte folgen klaren Regeln oder Techniken','stark_regelbasiert'=>'Das Hobby ist stark regel- oder verfahrensgebunden']);
        $public=$enum('public_exposure',['privat'=>'Du kannst es vollständig privat ausüben','optional_teilbar'=>'Ergebnisse oder Erlebnisse lassen sich teilen, müssen aber nicht öffentlich werden','regelmaessig_oeffentlich'=>'Öffentlichkeit gehört regelmäßig dazu','publikum_zentral'=>'Ein Publikum oder eine öffentliche Präsentation ist zentral']);

        $location=self::human_list(self::labels($get('location_mode',[]),['drinnen'=>'drinnen','draussen'=>'draußen']));
        $travel=$enum('travel_need',['keiner'=>'Anfahrt spielt kaum eine Rolle','lokal'=>'Meist genügt ein Ort in der näheren Umgebung','regional'=>'Für geeignete Orte oder Angebote kann eine regionale Anfahrt nötig sein','regelmaessige_reisen'=>'Regelmäßige Reisen können zur typischen Ausübung gehören']);
        $weather=$enum('weather_dependency',['keine'=>'Das Wetter beeinflusst die Ausübung kaum','teilweise'=>'Wetter kann die Planung beeinflussen','stark'=>'Das Hobby ist deutlich wetterabhängig']);
        $daylight=$enum('daylight_dependency',['keine'=>'Tageslicht ist nicht wichtig','teilweise'=>'Tageslicht kann hilfreich oder teilweise nötig sein','stark'=>'Ausreichendes Tageslicht ist häufig eine wichtige Voraussetzung']);
        $nature=$enum('nature_contact',['keiner'=>'Naturkontakt ist kein notwendiger Bestandteil','optional'=>'Naturkontakt ist möglich, aber nicht zwingend','zentral'=>'Der Kontakt zur Natur gehört wesentlich zum Hobby']);
        $session=self::map_value('session_length',$get('session_length',''));
        $setup=$enum('setup_cleanup',['minimal'=>'Vor- und Nachbereitung sind minimal','gering'=>'Vor- und Nachbereitung bleiben überschaubar','mittel'=>'Für Aufbau und Aufräumen solltest du etwas Zeit einplanen','hoch'=>'Aufbau, Vorbereitung oder Nachbereitung sind ein wesentlicher Teil der Session']);
        $schedule=$enum('schedule_flexibility',['jederzeit_spontan'=>'Du kannst sehr spontan beginnen','flexibel_planbar'=>'Die Termine lassen sich meist flexibel planen','feste_zeiten'=>'Feste Zeiten spielen häufig eine Rolle','termin_oder_buchung'=>'Termine oder Buchungen bestimmen häufig, wann du das Hobby ausüben kannst']);
        $frequency=$enum('frequency_need',['beliebig'=>'Es gibt keinen festen nötigen Rhythmus','woechentlich'=>'Ein ungefähr wöchentlicher Rhythmus ist sinnvoll','mehrmals_woechentlich'=>'Mehrere Einheiten pro Woche sind typisch oder sinnvoll','taeglich'=>'Die Tätigkeit verlangt typischerweise tägliche Aufmerksamkeit']);
        $continuity=$enum('continuity_commitment',['jederzeit_pausierbar'=>'Du kannst längere Pausen einlegen, ohne das Hobby grundsätzlich zu verlieren','regelmaessige_bindung'=>'Regelmäßigkeit ist sinnvoll','saisonale_bindung'=>'Die Bindung ist vor allem saisonal','laufende_pflicht'=>'Es entstehen laufende Pflichten, die sich nicht beliebig pausieren lassen']);
        $hvals=(array)$get('project_horizon',[]); $horizon=self::human_list(self::labels($hvals,['eine_einheit'=>'eine einzelne Einheit','mehrere_einheiten'=>'mehrere Einheiten','wochen_monate'=>'Projekte über Wochen oder Monate','fortlaufend'=>'eine fortlaufende Beschäftigung']));
        $visibility=$enum('result_visibility',['sofort'=>'Ergebnisse oder Fortschritt werden oft sofort sichtbar','kurzfristig'=>'Ergebnisse zeigen sich meist nach kurzer Zeit','langfristig'=>'Ein sichtbares Ergebnis braucht häufig längere Zeit','fortlaufend'=>'Der Fortschritt entwickelt sich fortlaufend']);

        $space=$enum('active_space',['minimal'=>'Du brauchst beim Ausüben nur sehr wenig Platz','tischbereich'=>'Ein Tischbereich reicht häufig aus','kleiner_bereich'=>'Ein kleiner freier Bereich ist sinnvoll','raum'=>'Du brauchst ungefähr einen eigenen Raum oder vergleichbar viel freie Fläche','grosser_bereich'=>'Ein größerer freier Bereich ist nötig','sehr_grosser_bereich'=>'Das Hobby braucht sehr viel freie Fläche']);
        $storage=$enum('storage_space',['keiner'=>'Nennenswerter Lagerplatz ist nicht nötig','klein'=>'Der Lagerbedarf bleibt klein','mittel'=>'Für Material oder Ausrüstung solltest du mittleren Stauraum einplanen','gross'=>'Ausrüstung oder Material brauchen deutlich Lagerplatz']);
        $portable=$enum('portability',['tasche'=>'Die Ausrüstung lässt sich meist in einer Tasche transportieren','koffer'=>'Ein Koffer oder eine größere Box ist realistisch','auto'=>'Für den Transport ist oft ein Auto sinnvoll','stationaer'=>'Die Ausrüstung bleibt eher stationär']);
        $noise=$enum('noise_level',['leise'=>'Das Hobby ist überwiegend leise','normal'=>'Die Lautstärke liegt im normalen Alltagsbereich','laut'=>'Es kann deutlich laut werden']);
        $mess=$enum('mess_level',['sauber'=>'Die Tätigkeit bleibt meist sauber','gering'=>'Es entsteht nur wenig Schmutz oder Unordnung','mittel'=>'Mit etwas Schmutz oder Unordnung solltest du rechnen','hoch'=>'Schmutz, Späne, Wasser, Erde oder andere Rückstände können deutlich anfallen']);
        $odor=$enum('odor_fumes',['keine'=>'Gerüche oder Dämpfe spielen kaum eine Rolle','moeglich'=>'Je nach Material können Gerüche oder Dämpfe entstehen','deutlich'=>'Deutliche Gerüche oder Dämpfe gehören zu manchen Arbeitsschritten']);
        $care=$enum('living_care_obligation',['keine'=>'Es gibt keine dauerhafte Pflegepflicht für lebende Systeme','gelegentlich'=>'Lebende Systeme oder Organismen brauchen gelegentliche Pflege','regelmaessig'=>'Regelmäßige Pflege lebender Systeme gehört dazu','taeglich'=>'Lebende Systeme oder Tiere verlangen tägliche Pflege']);
        $maint=$enum('equipment_maintenance',['keine'=>'Die Ausrüstung braucht praktisch keine besondere Pflege','gering'=>'Die Ausrüstung braucht nur geringe Pflege','mittel'=>'Reinigung, Kontrolle oder Wartung der Ausrüstung fallen regelmäßig an','hoch'=>'Die Ausrüstung verlangt einen spürbaren Wartungs- und Pflegeaufwand']);

        $budget=self::map_value('startup_budget',$get('startup_budget',''));
        $running=$enum('running_cost',['keine_fast_keine'=>'Laufende Kosten sind sehr gering oder fallen kaum an','gering'=>'Die laufenden Kosten bleiben eher gering','mittel'=>'Du solltest mit regelmäßigen mittleren Folgekosten rechnen','hoch'=>'Die laufenden Kosten können hoch sein']);
        $consum=$enum('consumables_need',['keins'=>'Verbrauchsmaterial brauchst du kaum','gelegentlich'=>'Verbrauchsmaterial fällt gelegentlich an','regelmaessig'=>'Verbrauchsmaterial musst du regelmäßig nachkaufen','hoch'=>'Der Verbrauch an Material kann ein wichtiger laufender Kostenpunkt sein']);
        $equip=$enum('equipment_extent',['minimal'=>'Die nötige Ausrüstung ist minimal','basis'=>'Eine überschaubare Basisausrüstung reicht für den Einstieg','mittel'=>'Der Ausrüstungsumfang ist mittel','umfangreich'=>'Für die typische Ausübung kann eine umfangreiche Ausrüstung zusammenkommen']);
        $rental=$enum('rental_borrowing',['leicht'=>'Ein Teil der Ausrüstung lässt sich gut leihen oder mieten','teilweise'=>'Leihen oder Mieten ist teilweise möglich','schwierig'=>'Leihen oder Mieten ist eher schwierig','nicht_relevant'=>'Leihen oder Mieten spielt praktisch keine Rolle']);

        $physical=self::level_word($get('physical_intensity','')); $endurance=self::level_word($get('endurance_need','')); $fine=self::level_word($get('fine_motor_need','')); $focus=self::level_word($get('cognitive_focus','')); $patience=self::level_word($get('patience_precision','')); $strength=self::level_word($get('strength_need','')); $coord=self::level_word($get('coordination_balance_need',''));
        $learning=$enum('learning_curve',['leicht'=>'Der Einstieg ist vergleichsweise leicht','mittel'=>'Die Lernkurve ist mittel','steil'=>'Die Lernkurve ist steil']);
        $mastery=$enum('mastery_depth',['begrenzt'=>'Die technische Tiefe bleibt überschaubar','mittel'=>'Es gibt auch nach dem Einstieg noch genügend Entwicklungsmöglichkeiten','tief'=>'Das Hobby bietet viel langfristige Tiefe','nahezu_endlos'=>'Die Möglichkeiten zur Vertiefung sind nahezu unbegrenzt']);
        $beginner=$enum('beginner_friendliness',['hoch'=>'Anfänger finden in der Regel einen guten Einstieg','mittel'=>'Der Einstieg ist machbar, braucht aber etwas Geduld','niedrig'=>'Für Anfänger ist der Einstieg anspruchsvoll']);
        $instruction=$enum('instruction_need',['nicht_noetig'=>'Eine formale Anleitung ist nicht zwingend nötig','hilfreich'=>'Eine gute Anleitung erleichtert den Start','empfohlen'=>'Ein Kurs oder eine strukturierte Anleitung ist empfehlenswert','erforderlich'=>'Anleitung, Kurs oder Einweisung sind für die typische Ausübung erforderlich']);

        $safety=$enum('safety_risk',['niedrig'=>'Das Sicherheitsrisiko ist niedrig','mittel'=>'Es gibt relevante Sicherheitsaspekte, die du ernst nehmen solltest','hoch'=>'Das Hobby hat ein erhöhtes Sicherheitsrisiko und verlangt besondere Sorgfalt']);
        $legal=$enum('legal_permission',['keine_besonderen'=>'Besondere Genehmigungen sind normalerweise nicht nötig','regelwerk_beachten'=>'Bestimmte Regeln oder örtliche Vorgaben müssen beachtet werden','erlaubnis_noetig'=>'Für manche Formen oder Orte brauchst du eine Erlaubnis','lizenz_zertifikat_noetig'=>'Für die typische Ausübung kann eine Lizenz oder ein Zertifikat nötig sein']);
        $adapt=$enum('adaptability',['hoch'=>'Das Hobby lässt sich gut an unterschiedliche Voraussetzungen anpassen','mittel'=>'Eine Anpassung ist in vielen Fällen möglich','niedrig'=>'Die Anpassbarkeit ist eher begrenzt','stark_varianteabhaengig'=>'Wie gut sich das Hobby anpassen lässt, hängt stark von der gewählten Variante ab']);

        $sec1=[]; $sec1[]=self::sentence($p['what_is_it']??''); $sec1[]=self::sentence($p['what_do_you_do']??''); if($acts!=='')$sec1[]='Typische Tätigkeiten sind '.$acts.'.'; $sec1[]=self::sentence($p['appeal']??''); if($outs!=='')$sec1[]='Als Ergebnis bleiben je nach Ausprägung '.$outs.'.'; if($digital!=='')$sec1[]='In seiner Grundform ist es '.$digital.'.'; if($surprise!=='')$sec1[]=$surprise.'.';

        $sec2=[]; if($mots!=='')$sec2[]='Das Hobby kann besonders passen, wenn du '.$mots.' suchst.'; if($social!=='')$sec2[]='Ausüben kannst du es '.$social.'.'; if($socialLevel!=='')$sec2[]='Der typische Umfang an sozialem Kontakt ist '.$socialLevel.'.'; foreach([$dependency,$competition,$pace,$variety,$structure,$public] as $x){if($x!=='')$sec2[]=$x.'.';}
        if($social!=='' && $dependency!=='')$sec2[]='Damit kannst du gut einschätzen, ob du das Hobby eher eigenständig oder bewusst mit anderen in deinen Alltag einbauen möchtest.';

        $sec3=[]; if($location!=='')$sec3[]='Typischerweise findet das Hobby '.$location.' statt.'; if($venues!=='')$sec3[]='Geeignete Orte sind '.$venues.'.'; foreach([$travel,$weather,$daylight] as $x){if($x!=='')$sec3[]=$x.'.';} if($seasons!=='')$sec3[]=in_array('ganzjaehrig',(array)$get('seasonality',[]),true)?'Das Hobby lässt sich grundsätzlich ganzjährig ausüben.':'Die passende Zeit liegt vor allem '.$seasons.'.'; if($nature!=='')$sec3[]=$nature.'.'; if($session!=='')$sec3[]='Für eine typische Einheit solltest du ungefähr '.$session.' einplanen.'; foreach([$setup,$schedule,$frequency,$continuity] as $x){if($x!=='')$sec3[]=$x.'.';} if($horizon!==''){if(in_array('eine_einheit',$hvals,true)&&in_array('fortlaufend',$hvals,true))$sec3[]='Je nach Variante kann das Hobby nach einer einzelnen Einheit abgeschlossen sein oder als fortlaufende Beschäftigung weitergehen.';elseif(in_array('wochen_monate',$hvals,true)&&in_array('fortlaufend',$hvals,true))$sec3[]='Einzelne Projekte können sich über Wochen oder Monate ziehen; gleichzeitig kann das Hobby dauerhaft fortgeführt werden.';elseif(count($hvals)>1)$sec3[]='Der zeitliche Horizont kann '.$horizon.' umfassen.';elseif(in_array('fortlaufend',$hvals,true))$sec3[]='Das Hobby ist typischerweise als fortlaufende Beschäftigung angelegt.';elseif(in_array('wochen_monate',$hvals,true))$sec3[]='Ein Projekt kann sich über Wochen oder Monate ziehen.';elseif(in_array('mehrere_einheiten',$hvals,true))$sec3[]='Viele Vorhaben verteilen sich auf mehrere Einheiten.';else $sec3[]='Viele Vorhaben lassen sich innerhalb einer Einheit abschließen.';} if($visibility!=='')$sec3[]=$visibility.'.';

        $sec4=[]; foreach([$space,$storage,$portable,$noise,$mess,$odor] as $x){if($x!=='')$sec4[]=$x.'.';} if($utilities!=='')$sec4[]=$utilities==='keine besonderen technischen Voraussetzungen'?'Besondere technische Voraussetzungen brauchst du dafür nicht.':'Praktisch brauchst du dafür vor allem '.$utilities.'.'; if($care!=='')$sec4[]=$care.'.'; if($maint!=='')$sec4[]=$maint.'.';

        $sec5=[]; $sec5[]=self::sentence($p['what_do_you_need']??''); if($budget!==''){$bv=(string)$get('startup_budget','');$bs=['0_bis_25'=>'Für den Einstieg reichen häufig bis zu 25 €.','25_bis_100'=>'Für den Einstieg solltest du etwa 25–100 € einplanen.','100_bis_300'=>'Für den Einstieg solltest du etwa 100–300 € einplanen.','300_bis_1000'=>'Für den Einstieg solltest du etwa 300–1.000 € einplanen.','1000_plus'=>'Der Einstieg kann mehr als 1.000 € kosten.'][$bv]??('Für den Einstieg solltest du ungefähr '.$budget.' einplanen.');$sec5[]=$bs;} foreach([$running,$consum,$equip,$rental] as $x){if($x!=='')$sec5[]=$x.'.';}

        $sec6=[]; if($physical!=='')$sec6[]='Die körperliche Intensität ist '.$physical.'.'; if($strength!=='')$sec6[]='Der Kraftbedarf ist '.$strength.'.'; if($endurance!=='')$sec6[]='Der Ausdauerbedarf ist '.$endurance.'.'; if($coord!=='')$sec6[]='Koordination und Balance sind '.$coord.' gefordert.'; if($fine!=='')$sec6[]='Der Bedarf an Feinmotorik ist '.$fine.'.'; if($focus!=='')$sec6[]='Konzentration und Denken sind '.$focus.' gefordert.'; if($patience!==''){$pd=[1=>'kaum',2=>'eher wenig',3=>'mittel',4=>'stark',5=>'sehr stark'][(int)$get('patience_precision',0)]??$patience;$sec6[]='Geduld und Präzision sind '.$pd.' gefordert.';} foreach([$learning,$mastery,$beginner,$instruction] as $x){if($x!=='')$sec6[]=$x.'.';}

        $sec7=[]; if($acts!=='')$sec7[]='Im Mittelpunkt stehen '.$acts.'.'; if($outs!=='')$sec7[]='Das Hobby kann '.$outs.' hervorbringen oder aufbauen.'; if($digital!=='')$sec7[]='Die Arbeitsweise ist '.$digital.'.'; if($screen!=='')$sec7[]=$screen.'.'; if($visibility!=='')$sec7[]=$visibility.'.'; if($variety!=='')$sec7[]=$variety.'.'; if($structure!=='')$sec7[]=$structure.'.';

        $sec8=[]; foreach([$safety,$legal] as $x){if($x!=='')$sec8[]=$x.'.';} if($ages!=='')$sec8[]='Zugänglich ist das Hobby typischerweise für '.$ages.'.'; if($adapt!=='')$sec8[]=$adapt.'.'; if($care!=='')$sec8[]=$care.'.';

        // Redaktionelle Verdichtung: Die Merkmale werden nicht nur aufgezählt,
        // sondern zu verständlichen Alltagseinschätzungen verbunden.
        if($acts!=='' && $outs!=='')$sec1[]='Der Schwerpunkt liegt damit nicht nur auf dem Tun selbst, sondern auch auf dem sichtbaren oder erlebbaren Ergebnis, das daraus entsteht.';
        if($mots!=='' && $pace!=='')$sec2[]='Für die persönliche Passung zählt deshalb sowohl, was du aus dem Hobby ziehen möchtest, als auch welches Tempo sich für dich angenehm anfühlt.';
        if($session!=='' && $schedule!=='')$sec3[]='Zeitbedarf und Planbarkeit gehören zusammen: Eine einzelne Einheit muss nicht lang sein, kann aber je nach Rahmen trotzdem etwas Vorbereitung oder Terminplanung verlangen.';
        if($space!=='' && $storage!=='')$sec4[]='Für den Alltag solltest du deshalb nicht nur den Platz während der Tätigkeit betrachten, sondern auch daran denken, wo Material und Ausrüstung zwischen den Einheiten bleiben.';
        if($budget!=='' && $running!=='')$sec5[]='Für die Kostenbetrachtung ist der Einstieg nur der erste Teil; entscheidend ist zusätzlich, ob später regelmäßig Material, Wartung oder weitere Ausrüstung anfällt.';
        if($learning!=='' && $mastery!=='')$sec6[]='Ein machbarer Einstieg bedeutet dabei nicht automatisch, dass das Hobby schnell ausgeschöpft ist: Lernkurve und langfristige Vertiefung können deutlich auseinanderliegen.';
        if($outs!=='' && $visibility!=='')$sec7[]='Wie motivierend das wirkt, hängt auch davon ab, ob du schnelle sichtbare Resultate magst oder Freude an einem länger wachsenden Projekt hast.';
        if($safety!=='' && $adapt!=='')$sec8[]='Grenzen sind damit nicht nur eine Frage von Sicherheit oder Regeln, sondern auch davon, wie gut sich Ablauf, Ausrüstung und Anspruch an deine Situation anpassen lassen.';

        return [
            ['Worum geht es bei '.$name.'?',implode(' ',$sec1)],
            ['Passt dieses Hobby zu dir?',implode(' ',$sec2)],
            ['Wo und wann kannst du diesem Hobby nachgehen?',implode(' ',$sec3)],
            ['Platz, Alltag und Pflege',implode(' ',$sec4)],
            ['Kosten und Ausrüstung',implode(' ',$sec5)],
            ['Was musst du können?',implode(' ',$sec6)],
            ['Was entsteht daraus?',implode(' ',$sec7)],
            ['Grenzen, Sicherheit und Regeln',implode(' ',$sec8)],
        ];
    }

    private static function similarity($a,$b) {
        $ta=self::flatten_traits($a); $tb=self::flatten_traits($b);
        $keys=['activity_modes','motivation_goals','location_mode','social_modes','startup_budget','physical_intensity','active_space','pace','outcome_type','surprise_level','learning_curve','nature_contact','digital_analog','structure_style'];
        $score=0.0; $count=0;
        foreach($keys as $k){ if(!array_key_exists($k,$ta)||!array_key_exists($k,$tb)) continue; $count++;
            $va=$ta[$k]; $vb=$tb[$k];
            if(is_array($va)||is_array($vb)){ $aa=(array)$va;$bb=(array)$vb;$u=array_unique(array_merge($aa,$bb));$i=array_intersect($aa,$bb);$score+=count($u)?count($i)/count($u):0; }
            elseif(is_numeric($va)&&is_numeric($vb)){ $score+=max(0,1-abs((float)$va-(float)$vb)/5); }
            else { $score+=(string)$va===(string)$vb?1:0; }
        }
        return $count?$score/$count:0;
    }

    private static function related($row,$same_group=false,$limit=5,$exclude_ids=[],$outside_primary_group=false) {
        $items=[]; $group=self::primary_group($row); $id=(string)$row['registry_id'];
        $exclude=array_fill_keys(array_map('strval',(array)$exclude_ids),true);
        foreach(HD_Hobbyregister_Core_Stable127::records() as $other){
            if(!is_array($other))continue;
            $other_id=(string)($other['registry_id']??'');
            if($other_id===''||$other_id===$id||isset($exclude[$other_id]))continue;
            $other_groups=self::groups_for_record($other);
            $is_same=in_array($group,$other_groups,true);
            if($same_group&&!$is_same)continue;
            if($outside_primary_group&&$is_same)continue;
            $items[]=['r'=>$other,'s'=>self::similarity($row,$other)];
        }
        usort($items,static fn($a,$b)=>$b['s']<=>$a['s']);
        return array_slice($items,0,$limit);
    }

    private static function side_cards($items) {
        $out='<div class="hdr-side-card-list">';
        foreach($items as $x){
            $r=$x['r'];
            $p=(array)($r['result_profile']??[]);
            $excerpt=trim((string)($p['what_is_it']??''));
            $out.='<a class="hdr-side-card" href="'.esc_url(self::profile_url($r)).'"><span class="hdr-side-thumb"><img src="'.esc_url(self::record_image($r)).'" alt="'.esc_attr((string)$r['canonical_name']).'" loading="lazy"></span><span class="hdr-side-copy"><strong>'.esc_html((string)$r['canonical_name']).'</strong>'.($excerpt!==''?'<small>'.esc_html($excerpt).'</small>':'').'<b>ansehen →</b></span></a>';
        }
        return $out.'</div>';
    }

    private static function profile_sidebar($row) {
        $group=self::primary_group($row); $def=self::group_defs()[$group]??null;
        $out=self::facts($row);
        $same_group=[];
        if($def){
            $same_group=self::related($row,true,3);
            $out.='<section class="hdr-sidebox"><header><span>Hobbygruppe</span><h3>Selbe Hobbygruppe</h3></header>'.self::side_cards($same_group).'<a class="hdr-sidebox-button" href="'.esc_url(self::query_url(['hr_group'=>$group])).'">Zur Hobbygruppe →</a></section>';
        }
        $same_ids=[];
        foreach($same_group as $item){ if(isset($item['r']['registry_id']))$same_ids[]=(string)$item['r']['registry_id']; }
        $similar=self::related($row,false,4,$same_ids,true);
        $out.='<section class="hdr-sidebox"><header><span>Vergleichen</span><h3>Ähnliche Hobbys</h3></header>'.self::side_cards($similar).'</section>';
        $out.='<a class="hdr-magazine-button" href="'.esc_url(home_url('/magazin/')).'">Zum Hobbymagazin →</a>';
        return $out;
    }

    private static function full_article($row) {
        $name=(string)$row['canonical_name'];
        $static=HD_Hobbyregister_Core_Stable127::article((string)($row['registry_id'] ?? ''));
        $sections=is_array($static)&&isset($static['sections'])&&is_array($static['sections'])?$static['sections']:[];
        if(!$sections){
            $samples=self::sample_articles();
            $sections=isset($samples[$name])?$samples[$name]:self::generated_article_sections($row);
        }
        $out='<article class="hdr-article">';
        foreach($sections as $section){
            $text=trim((string)($section[1]??'')); if($text==='')continue;
            $out.='<section><h2>'.esc_html((string)$section[0]).'</h2><p>'.esc_html($text).'</p></section>';
        }
        return $out.'</article>';
    }

    public static function render_index() {
        $f=self::request_filters(); $rows=self::filter_records($f);
        return self::breadcrumb().'<div class="hd-portal-section hdr-wrap" data-hd-register="1.2.16">'.self::hero(false).self::render_tools($f).self::affiliate_banner().self::render_groups($f).self::render_cards($rows,$f).'</div>'.self::styles().self::search_script();
    }

    public static function render_profile($slug) {
        $row=self::record_by_slug($slug);
        if(!$row){ if(function_exists('status_header'))status_header(404); return '<div class="hd-portal-section hdr-wrap"><p>Dieses Hobby wurde im Register nicht gefunden.</p></div>'.self::styles(); }
        $name=(string)$row['canonical_name'];
        return self::breadcrumb($name).'<div class="hd-portal-section hdr-wrap" data-hd-register-profile="1.2.16">'.self::hero(true,$row).'<div class="hdr-profile-grid"><aside>'.self::profile_sidebar($row).'</aside><main>'.self::full_article($row).'</main></div><div class="hdr-back"><a href="'.esc_url(self::base_url()).'">← Zur Hobbyregister-Startseite</a></div></div>'.self::styles();
    }

    public static function render_current() {
        $r=self::route();
        if($r['type']==='index')return self::render_index();
        if($r['type']==='profile')return self::render_profile($r['slug']);
        return '';
    }

    private static function styles() {
        return '<style id="hd-hobbyregister-css-v120">'
        .'.hd-hobbyregister-template-v110{box-sizing:border-box!important;width:100%!important;max-width:none!important;margin:0!important;padding:0!important}html body.hd-hobbyregister-route .site-content{padding-top:0!important}.hdr-breadcrumb-wrap{box-sizing:border-box;margin-top:18px;padding:0;font-family:Montserrat,Arial,sans-serif}.hdr-breadcrumb{display:flex;flex-wrap:wrap;align-items:center;gap:7px;margin:0;padding:0;color:#778085;font-size:12px;line-height:1.4}.hdr-breadcrumb a{color:#667178!important;font-weight:400!important;text-decoration:none!important}.hdr-breadcrumb a:hover,.hdr-breadcrumb a:focus-visible{color:#2f969d!important}.hdr-breadcrumb b{color:#a0a7aa;font-weight:500}.hdr-breadcrumb span[aria-current=page]{color:#39464c;font-weight:650}.hdr-wrap{--petrol:#2f969d;--petrol-dark:#207b82;--ink:#17313c;--muted:#68767b;--cream:#f5f1e9;--line:rgba(49,67,73,.16);box-sizing:border-box;margin-top:5px;margin-bottom:58px;padding:0;color:var(--ink);font-family:Montserrat,Arial,sans-serif}.hdr-wrap *{box-sizing:border-box}.hdr-wrap a{text-decoration:none}'
        .'.hdr-hero{position:relative;height:238px;overflow:hidden;border:1px solid var(--line);background:var(--cream)}.hdr-hero-copy{position:absolute;z-index:2;top:0;bottom:0;left:0;display:flex;width:46%;padding:clamp(24px,3.6vw,48px);flex-direction:column;justify-content:center;transform:translateY(-6px)}.hdr-hero-copy>span:not(.hdr-brush-claim){margin:0 0 8px;color:var(--petrol);font-size:10px;font-weight:800;letter-spacing:.16em;text-transform:uppercase}.hdr-brush-claim{position:relative!important;display:inline-block!important;z-index:2!important;width:max-content;max-width:100%;margin:0 0 24px!important;padding:0 4px 0 1px!important;color:#0f858a!important;font-family:"Brush Script MT","Segoe Script","Bradley Hand",cursive!important;font-size:24px!important;font-weight:400!important;font-style:normal!important;letter-spacing:.01em!important;line-height:1!important;text-transform:none!important;transform:rotate(-1.2deg)!important}.hdr-brush-claim:after{content:""!important;position:absolute!important;z-index:-1!important;left:4%!important;width:92%!important;bottom:-13px!important;height:12px!important;background-image:var(--hdr-brush)!important;background-repeat:no-repeat!important;background-position:left center!important;background-size:100% 100%!important;transform:rotate(-.8deg)!important;transform-origin:left center!important;opacity:.9;pointer-events:none}.hdr-hero h1{margin:0 0 10px!important;color:var(--ink)!important;font-size:clamp(38px,4.6vw,56px)!important;font-weight:800!important;line-height:1!important;letter-spacing:-.035em}.hdr-hero p{margin:0!important;color:#53646a;font-size:clamp(14px,1.45vw,17px);font-weight:500;line-height:1.45}.hdr-hero figure{position:absolute;z-index:0;inset:0 0 0 35%;margin:0;overflow:hidden;background:var(--cream)}.hdr-hero figure:before{content:"";position:absolute;z-index:1;inset:0 auto 0 0;width:42%;background:linear-gradient(90deg,var(--cream) 0%,rgba(245,241,233,.97) 10%,rgba(245,241,233,.86) 24%,rgba(245,241,233,.58) 42%,rgba(245,241,233,.24) 62%,rgba(245,241,233,0) 100%)}.hdr-hero img{display:block;width:100%;height:100%;max-width:none;object-fit:cover}.hdr-hero.is-profile{height:238px}.hdr-hero.is-profile figure{left:31%}.hdr-hero.is-profile figure:before{width:49%}.hdr-hero.is-profile .hdr-hero-copy{width:47%;padding:26px 40px;transform:translateY(-6px)}.hdr-hero.is-profile h1{font-size:clamp(38px,4.6vw,54px)!important}'
        .'.hdr-tools{position:relative;margin:18px 0 0;padding:28px 26px 20px;border-top:1px solid rgba(49,67,73,.14);border-bottom:1px solid rgba(49,67,73,.14);background:var(--cream)}.hdr-tools form{display:grid;max-width:100%;margin:0 auto}.hdr-tools form>div{display:grid;grid-template-columns:1fr 118px}.hdr-search-field{position:relative;display:block;min-width:0}.hdr-tools input{box-sizing:border-box;width:100%;min-height:48px;padding:0 15px;border:1px solid #cfc9bc;border-right:0;border-radius:0;background:#fff;font:inherit;font-size:14px}.hdr-tools button{min-height:48px;border:1px solid var(--ink);border-radius:0;background:var(--ink);color:#fff;font-size:11px;font-weight:750;letter-spacing:.04em;text-transform:uppercase}.hdr-search-suggestions{position:absolute;z-index:999;top:100%;left:0;right:0;border:1px solid rgba(49,67,73,.18);border-top:0;background:#fff;box-shadow:0 12px 24px rgba(23,49,60,.15);text-align:left}.hdr-search-suggestions[hidden]{display:none}.hdr-search-suggestion{display:block;padding:12px 14px;border-bottom:1px solid rgba(49,67,73,.12);color:#17313c!important;font-size:14px;font-weight:700;text-decoration:none!important}.hdr-search-suggestion:last-child{border-bottom:0}.hdr-search-suggestion:hover,.hdr-search-suggestion:focus-visible{background:var(--cream);color:var(--petrol)!important}.hdr-search-empty{display:block;padding:12px 14px;color:#68767b;font-size:13px}.hdr-az{display:flex;flex-wrap:wrap;gap:9px;justify-content:space-between;margin-top:16px;padding:0 11px}.hdr-az a{display:grid;min-width:27px;height:28px;padding:0 5px;place-items:center;border-radius:14px;color:#435158!important;font-size:12px;font-weight:650;text-decoration:none!important}.hdr-az a:hover{background:#e8f5f4;color:var(--petrol)!important}.hdr-az a[aria-current=page]{background:var(--petrol);color:#fff!important;font-weight:800;box-shadow:0 0 0 1px var(--petrol)}'
        .'.hdr-groups{margin:38px 0 50px}.hdr-groups>header{display:flex;align-items:center;justify-content:center;gap:22px;margin:0 0 23px}.hdr-groups>header:before,.hdr-groups>header:after{content:"";width:118px;height:1px;background:rgba(47,150,157,.55)}.hdr-groups h2{margin:0!important;color:var(--ink)!important;font-size:32px!important;font-weight:750!important}.hdr-group-grid{display:grid;grid-template-columns:repeat(8,minmax(0,1fr));gap:16px;align-items:start}.hdr-group{display:flex;min-width:0;align-items:center;flex-direction:column;color:var(--ink)!important;text-align:center}.hdr-group[aria-current=page]{color:var(--petrol)!important;font-weight:800}.hdr-group[aria-current=page] .hdr-group-icon{box-shadow:0 0 0 2px rgba(47,150,157,.38)}.hdr-group-icon{display:grid;width:64px;height:64px;margin:0 auto 9px;border-radius:50%;place-items:center;background:var(--cream);color:#36555d;transition:color .15s ease,background-color .15s ease}.hdr-group:hover,.hdr-group:focus-visible,.hdr-group:hover .hdr-group-icon,.hdr-group:focus-visible .hdr-group-icon,.hdr-group[aria-current=page] .hdr-group-icon{color:var(--petrol)!important;outline:none}.hdr-group:hover .hdr-group-icon,.hdr-group:focus-visible .hdr-group-icon,.hdr-group[aria-current=page] .hdr-group-icon{background:#e8f5f4}.hdr-group-icon svg{width:35px;height:35px;fill:none;stroke:currentColor;stroke-width:1.65;stroke-linecap:round;stroke-linejoin:round}.hdr-group strong{display:block;font-size:12px;font-weight:650;line-height:1.35}'
        .'.hdr-list{margin-top:26px}.hdr-list>header{display:flex;margin-bottom:17px;align-items:flex-end;justify-content:space-between;gap:20px}.hdr-list>header>div{display:flex;flex-wrap:wrap;align-items:baseline;gap:10px 14px}.hdr-list h2{margin:0!important;color:var(--ink)!important;font-size:32px!important;font-weight:750!important}.hdr-result-count{color:#718086;font-size:12px;font-weight:650}.hdr-list>header>a{color:var(--petrol)!important;font-size:12px;font-weight:700;text-decoration:underline!important;text-underline-offset:3px}.hdr-card-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px}.hdr-card{position:relative;display:flex;min-height:148px;padding:18px 18px 16px;flex-direction:column;border:1px solid var(--line);border-radius:0;background:#fff;color:inherit!important}.hdr-card:hover{border-color:var(--petrol);box-shadow:none!important;transform:none!important}.hdr-card h3{margin:0 0 7px;color:#263b44!important;font-size:20px!important;font-weight:750!important;line-height:1.08}.hdr-card p{margin:0 0 12px;color:#687068;font-size:13px;line-height:1.45}.hdr-card span{margin-top:auto;color:#36555d!important;font-size:12px;font-weight:650;text-decoration:underline!important;text-underline-offset:3px}.hdr-card:hover h3,.hdr-card:hover span{color:var(--petrol)!important}.hdr-card em{position:absolute;right:10px;top:10px;padding:3px 6px;background:#e8f6f5;color:#217b81;font-size:8px;font-style:normal;font-weight:800;letter-spacing:.06em;text-transform:uppercase}.hdr-pagination{display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:center;margin:28px 0 0}.hdr-pagination.is-top{margin:0 0 18px}.hdr-pagination.is-bottom{margin-top:28px}.hdr-pagination a,.hdr-pagination span{display:grid;min-width:36px;height:36px;padding:0 10px;place-items:center;border:1px solid rgba(49,67,73,.22);background:#fff;color:#435158!important;font-size:12px;font-weight:700}.hdr-pagination a[aria-current=page]{border-color:var(--petrol);background:var(--cream);color:var(--petrol)!important}'
        .'.hdr-profile-grid{display:grid;width:100%;max-width:none;margin:22px 0 0;grid-template-columns:286px minmax(0,1fr);gap:32px;align-items:start}.hdr-profile-grid aside{display:grid;gap:16px;align-content:start}.hdr-facts,.hdr-sidebox{background:var(--cream);border:0;border-top:2px solid var(--petrol);border-radius:0}.hdr-facts{padding:20px 18px}.hdr-facts h2,.hdr-sidebox h3{margin:0!important;color:var(--ink)!important;font-size:23px!important;font-weight:750!important;line-height:1.1}.hdr-facts h2{margin-bottom:17px!important}.hdr-fact-list{display:grid}.hdr-fact{display:grid;padding:11px 0;grid-template-columns:34px minmax(0,1fr);gap:10px;align-items:center;border-top:1px solid rgba(49,67,73,.11)}.hdr-fact:first-child{border-top:0}.hdr-fact-icon{display:grid;width:30px;height:30px;place-items:center;color:var(--petrol)}.hdr-fact-icon svg{width:27px;height:27px;fill:none;stroke:currentColor;stroke-width:1.65;stroke-linecap:round;stroke-linejoin:round}.hdr-fact div>span{display:block;color:#233940;font-size:14.5px;font-weight:700;line-height:1.35}.hdr-sidebox{padding:17px 14px 14px}.hdr-sidebox header>span{display:block;margin-bottom:5px;color:var(--petrol);font-size:9px;font-weight:850;letter-spacing:.12em;text-transform:uppercase}.hdr-sidebox h3{font-size:21px!important;line-height:1.08!important}.hdr-side-card-list{display:grid;gap:0;margin-top:10px}.hdr-side-card{display:grid;padding:10px 0;grid-template-columns:72px minmax(0,1fr);gap:10px;align-items:center;border-top:1px solid rgba(49,67,73,.11);color:#2b4149!important}.hdr-side-thumb{display:block;width:72px;aspect-ratio:4/3;overflow:hidden;background:#e7eceb}.hdr-side-thumb img{display:block;width:100%;height:100%;object-fit:cover}.hdr-side-copy{display:flex;min-width:0;flex-direction:column}.hdr-side-copy strong{color:#263b44;font-size:13px;line-height:1.2}.hdr-side-copy small{display:-webkit-box;margin-top:3px;overflow:hidden;color:#66757a;font-size:10.5px;line-height:1.35;-webkit-box-orient:vertical;-webkit-line-clamp:2}.hdr-side-copy b{margin-top:5px;color:var(--petrol);font-size:10px;font-weight:800}.hdr-sidebox-button,.hdr-magazine-button{display:flex;align-items:center;justify-content:center;width:100%;min-height:40px;margin-top:12px;padding:9px 12px;background:var(--petrol);color:#fff!important;font-size:12px;font-weight:700;transition:background-color .15s ease}.hdr-sidebox-button:hover,.hdr-sidebox-button:focus-visible,.hdr-magazine-button:hover,.hdr-magazine-button:focus-visible{background:var(--petrol-dark);color:#fff!important}.hdr-magazine-button{margin-top:0}'
        .'.hdr-article{display:grid;gap:28px}.hdr-article section{padding-bottom:23px;border-bottom:1px solid #e1e6e6}.hdr-article h2{position:relative;margin:0 0 12px;padding-top:9px;color:var(--ink)!important;font-size:27px!important;font-weight:750!important;line-height:1.15}.hdr-article h2:before{content:"";position:absolute;top:0;left:0;width:46px;height:2px;background:var(--petrol)}.hdr-article p{margin:0;color:#46575d;font-size:15.5px;line-height:1.78}.hdr-affiliate{position:relative;margin:26px 0 34px;padding-top:15px}.hdr-affiliate-register+.hdr-groups{margin-top:0}.hdr-ad-label{position:absolute;top:0;left:0;color:#7b8387;font-size:9px;letter-spacing:.08em;text-transform:uppercase}.hdr-affiliate-box{overflow:hidden;border:1px solid var(--line);background:#fff}.hdr-affiliate-box img{display:block;max-width:100%;height:auto;margin:auto}.hdr-banner-preview{display:flex;min-height:90px;padding:18px 20px;flex-direction:column;justify-content:center;background:#f7fbfb;color:#51656b}.hdr-banner-preview small{font-size:8px;font-weight:800;letter-spacing:.1em}.hdr-banner-preview strong{margin-top:5px;color:var(--ink);font-size:16px}.hdr-banner-preview span{margin-top:3px;font-size:11px}.hdr-back{display:flex;margin-top:28px;justify-content:space-between;gap:12px}.hdr-back a{color:var(--petrol)!important;font-size:12px;font-weight:750}'
        .'@media(max-width:1080px){.hdr-group-grid{grid-template-columns:repeat(4,minmax(0,1fr));row-gap:22px}.hdr-card-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.hdr-profile-grid{grid-template-columns:250px minmax(0,1fr);gap:26px}.hdr-hero-copy{width:50%;padding:clamp(22px,3.2vw,36px)}}'
        .'@media(max-width:820px){.hdr-profile-grid{grid-template-columns:1fr;grid-template-areas:"facts" "copy" "tail";gap:22px}.hdr-profile-grid aside{display:contents}.hdr-facts{grid-area:facts;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 18px}.hdr-facts>h2{grid-column:1/-1}.hdr-fact-list{display:contents}.hdr-sidebox{grid-column:1/-1}.hdr-profile-grid main{grid-area:copy}}'
        .'@media(max-width:760px){.hdr-breadcrumb-wrap{margin-top:12px;padding:0}.hdr-wrap{margin-top:5px;margin-bottom:46px;padding:0}.hdr-hero{height:190px}.hdr-hero-copy{width:58%;padding:18px}.hdr-hero h1{font-size:clamp(31px,8vw,42px)!important}.hdr-hero p{max-width:20ch;font-size:13px}.hdr-hero figure{left:31%}.hdr-hero figure:before{width:50%}.hdr-hero.is-profile{height:190px}.hdr-hero.is-profile figure{left:26%}.hdr-hero.is-profile figure:before{width:65%}.hdr-hero.is-profile .hdr-hero-copy{width:69%;padding:18px}.hdr-hero.is-profile h1{font-size:34px!important}.hdr-brush-claim{font-size:21px!important;margin-bottom:21px!important}.hdr-tools{margin-top:14px;padding:18px 14px 14px}.hdr-tools form>div{grid-template-columns:1fr 94px}.hdr-tools button{padding:0 10px}.hdr-az{justify-content:center;gap:4px;padding:0}.hdr-groups>header{gap:12px}.hdr-groups>header:before,.hdr-groups>header:after{width:42px}.hdr-groups h2{font-size:28px!important}.hdr-group-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:18px 10px}.hdr-card-grid{grid-template-columns:1fr}.hdr-list>header{align-items:flex-start;flex-direction:column}.hdr-facts{grid-template-columns:repeat(2,minmax(0,1fr));gap:0 12px}.hdr-article h2{font-size:24px!important}.hdr-article p{font-size:15px}.hdr-back{flex-direction:column}}'
        .'
/* HD007 1.2.18: index hero only, mobile copy always readable. */
@media(max-width:760px){
 .hdr-hero:not(.is-profile) .hdr-hero-copy{
   width:74%!important;padding:13px 16px!important;transform:none!important;
 }
 .hdr-hero:not(.is-profile) h1{font-size:clamp(27px,7.4vw,36px)!important;line-height:1.08!important;}
 .hdr-hero:not(.is-profile) .hdr-brush-claim{
   font-size:clamp(17px,5vw,21px)!important;margin-bottom:12px!important;
 }
 .hdr-hero:not(.is-profile) p{
   max-width:27ch!important;font-size:clamp(11px,3.1vw,13px)!important;
   line-height:1.34!important;
 }
}
</style>';
    }
}
