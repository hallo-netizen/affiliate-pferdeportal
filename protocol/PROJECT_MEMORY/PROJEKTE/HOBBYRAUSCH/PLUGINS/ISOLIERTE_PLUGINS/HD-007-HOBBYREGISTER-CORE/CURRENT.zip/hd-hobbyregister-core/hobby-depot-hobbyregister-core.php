<?php
/**
 * Plugin Name: Hobby Depot Hobbyregister Core
 * Description: Read-only Laufzeitkern und Frontend-Projektion für das zentrale Hobbyregister von Hobby Depot.
 * Version: 1.2.20
 * Author: Hobby Depot
 */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/includes/class-hd-hobbyregister-core.php';
require_once __DIR__ . '/includes/class-hd-hobbyregister-frontend.php';
HD_Hobbyregister_Frontend_Stable127::boot();
function hd_hobbyregister_127_register_compat_api() {
    if (!function_exists('hd_hobbyregister_records')) { function hd_hobbyregister_records() { return HD_Hobbyregister_Core_Stable127::records(); } }
    if (!function_exists('hd_hobbyregister_get')) { function hd_hobbyregister_get($registry_id) { return HD_Hobbyregister_Core_Stable127::get($registry_id); } }
    if (!function_exists('hd_hobbyregister_get_by_name')) { function hd_hobbyregister_get_by_name($name) { return HD_Hobbyregister_Core_Stable127::get_by_name($name); } }
    if (!function_exists('hd_hobbyregister_finder_rows')) { function hd_hobbyregister_finder_rows() { return HD_Hobbyregister_Core_Stable127::finder_rows(); } }
    if (!function_exists('hd_hobbyregister_ready')) { function hd_hobbyregister_ready() { return HD_Hobbyregister_Core_Stable127::ready(); } }
}
if (function_exists('add_action')) { add_action('plugins_loaded', 'hd_hobbyregister_127_register_compat_api', PHP_INT_MAX); }
else { hd_hobbyregister_127_register_compat_api(); }
