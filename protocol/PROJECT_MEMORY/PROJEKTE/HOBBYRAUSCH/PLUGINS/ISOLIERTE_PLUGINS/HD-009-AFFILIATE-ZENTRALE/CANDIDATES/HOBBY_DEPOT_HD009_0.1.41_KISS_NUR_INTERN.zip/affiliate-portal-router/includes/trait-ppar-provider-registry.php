<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Provider Registry / Provider-Vertrag V2.0.
 *
 * Ziel:
 * - Zugänge und Verbindungsstatus aller Provider zentral verwalten.
 * - Provider-spezifische Betriebslogik in eigenen Fachseiten kapseln.
 * - Partner, Creatives, Ziele, Slots und Ausgaben weiterhin zentral steuern.
 * - Neue Provider registrieren sich über einen einzigen Registry-Filter und
 *   optional Adapter-Hooks, ohne den zentralen Steuervertrag umzubauen.
 */
trait PPAR_Provider_Registry_Trait {
    /**
     * V6.72.148: Provider definitions are immutable during a normal public
     * frontend request. Rebuilding and sanitizing the full registry for every
     * campaign gate caused millions of redundant sanitize_* calls on leaf pages.
     * Keep admin/AJAX/cron/REST/WP-CLI uncached so operational/adaptor tooling
     * retains its existing per-call filter behaviour.
     */
    private $provider_registry_request_cache = null;

    private function provider_registry_request_cache_allowed() {
        if ((function_exists('is_admin') && is_admin())
            || (defined('DOING_CRON') && DOING_CRON)
            || (defined('REST_REQUEST') && REST_REQUEST)
            || (defined('WP_CLI') && WP_CLI)
            || (function_exists('wp_doing_ajax') && wp_doing_ajax())) {
            return false;
        }
        return true;
    }

    private function provider_registry_defaults() {
        return array(
            'awin' => array(
                'label' => 'Awin',
                'state' => 'active',
                'access_owner' => 'core',
                'specialist_menu' => true,
                'specialist_slug' => 'affiliate-portal-provider-awin',
                'capabilities' => array('credentials','connection_test','programmes','partners','offers','product_feeds','synchronization','automation','creatives','outputs','veto'),
            ),
            'adcell' => array(
                'label' => 'ADCELL',
                'state' => 'active',
                'access_owner' => 'core',
                'specialist_menu' => true,
                'specialist_slug' => 'affiliate-portal-provider-adcell',
                'capabilities' => array('credentials','connection_test','programmes','partners','product_feeds','synchronization','automation','creatives','outputs','veto'),
            ),
            'ebay' => array(
                'label' => 'eBay',
                'state' => 'active',
                'access_owner' => 'core',
                'specialist_menu' => true,
                'specialist_slug' => 'affiliate-portal-ebay',
                'capabilities' => array('credentials','connection_test','marketplace','account_deletion_notifications','partners','private_listings','business_products','synchronization','automation','creatives','outputs','veto'),
            ),
            'amazon' => array(
                'label' => 'Amazon',
                'state' => 'active',
                'access_owner' => 'core',
                'specialist_menu' => false,
                'specialist_slug' => 'affiliate-portal-provider-amazon',
                'capabilities' => array('credentials','connection_test','creatives','outputs','veto'),
            ),
            'idealo' => array(
                'label' => 'idealo',
                'state' => 'active',
                'access_owner' => 'adapter',
                'specialist_menu' => true,
                'specialist_slug' => 'affiliate-portal-provider-idealo',
                'capabilities' => array('credentials','connection_test','product_feeds','synchronization','creatives','outputs','veto'),
            ),
            'direct' => array(
                'label' => 'Direktpartner',
                'state' => 'active',
                'access_owner' => 'none',
                'specialist_menu' => false,
                'specialist_slug' => '',
                'capabilities' => array('partners','creatives','outputs','veto'),
            ),
            'manual' => array(
                'label' => 'Manuell',
                'state' => 'active',
                'access_owner' => 'none',
                'specialist_menu' => false,
                'specialist_slug' => '',
                'capabilities' => array('creatives','outputs','veto'),
            ),
        );
    }

    public function provider_registry() {
        $cache_allowed = $this->provider_registry_request_cache_allowed();
        if ($cache_allowed && is_array($this->provider_registry_request_cache)) {
            return $this->provider_registry_request_cache;
        }
        $raw = apply_filters('ppar_affiliate_provider_registry', $this->provider_registry_defaults(), self::PROVIDER_CONTRACT_VERSION);
        $raw = is_array($raw) ? $raw : array();
        $safe = array();
        foreach ($raw as $key => $provider) {
            $key = sanitize_key((string) $key);
            if ($key === '' || !is_array($provider)) { continue; }
            $caps = array_values(array_unique(array_filter(array_map('sanitize_key', (array) ($provider['capabilities'] ?? array())))));
            // Chef-Veto ist Bestandteil des Kernvertrags und darf von keinem Adapter entfernt werden.
            if (!in_array('veto', $caps, true)) { $caps[] = 'veto'; }
            $state = sanitize_key((string) ($provider['state'] ?? 'prepared'));
            if (!in_array($state, array('active','prepared','disabled'), true)) { $state = 'prepared'; }
            $access_owner = sanitize_key((string) ($provider['access_owner'] ?? 'adapter'));
            if (!in_array($access_owner, array('core','adapter','none'), true)) { $access_owner = 'adapter'; }
            $safe[$key] = array(
                'key' => $key,
                'label' => sanitize_text_field((string) ($provider['label'] ?? strtoupper($key))),
                'state' => $state,
                'access_owner' => $access_owner,
                'specialist_menu' => !empty($provider['specialist_menu']),
                'specialist_slug' => sanitize_key((string) ($provider['specialist_slug'] ?? '')),
                'capabilities' => $caps,
            );
        }
        if ($cache_allowed) {
            $this->provider_registry_request_cache = $safe;
        }
        return $safe;
    }

    public function provider_definition($provider) {
        static $definition_cache = array();
        $raw = (string) $provider;
        $cache_allowed = $this->provider_registry_request_cache_allowed();
        if ($cache_allowed && array_key_exists($raw, $definition_cache)) { return $definition_cache[$raw]; }
        $provider = sanitize_key($raw);
        $registry = $this->provider_registry();
        $definition = isset($registry[$provider]) ? $registry[$provider] : null;
        if ($cache_allowed) { $definition_cache[$raw] = $definition; }
        return $definition;
    }

    public function provider_exists($provider) {
        return is_array($this->provider_definition($provider));
    }

    public function provider_supports($provider, $capability) {
        static $capability_cache = array();
        $definition = $this->provider_definition($provider);
        $raw = (string) $capability;
        $cache_allowed = $this->provider_registry_request_cache_allowed();
        if ($cache_allowed && array_key_exists($raw, $capability_cache)) { $capability = $capability_cache[$raw]; }
        else { $capability = sanitize_key($raw); if ($cache_allowed) { $capability_cache[$raw] = $capability; } }
        return is_array($definition) && in_array($capability, (array) $definition['capabilities'], true);
    }

    public function provider_label($provider) {
        $definition = $this->provider_definition($provider);
        return is_array($definition) ? (string) $definition['label'] : strtoupper(sanitize_key((string) $provider));
    }

    private function provider_access_state_all() {
        $state = get_option(self::OPTION_PROVIDER_ACCESS_STATE, array());
        return is_array($state) ? $state : array();
    }

    private function provider_access_state($provider) {
        $provider = sanitize_key((string) $provider);
        $all = $this->provider_access_state_all();
        $stored = isset($all[$provider]) && is_array($all[$provider]) ? $all[$provider] : array();
        return array_merge(array(
            'status' => 'not_configured',
            'last_checked' => 0,
            'message' => '',
            'updated_at' => 0,
        ), $stored);
    }

    private function provider_set_access_state($provider, $status, $message) {
        $provider = sanitize_key((string) $provider);
        $status = sanitize_key((string) $status);
        if (!$this->provider_exists($provider)) { return false; }
        if (!in_array($status, array('not_configured','credentials_saved','connected','failed','prepared'), true)) { $status = 'failed'; }
        $all = $this->provider_access_state_all();
        $all[$provider] = array(
            'status' => $status,
            'last_checked' => time(),
            'message' => sanitize_text_field((string) $message),
            'updated_at' => time(),
        );
        update_option(self::OPTION_PROVIDER_ACCESS_STATE, $all, false);
        return true;
    }

    private function amazon_settings_defaults() {
        return array(
            'enabled' => false,
            'tracking_id' => '',
        );
    }

    private function amazon_tracking_id_valid($tracking_id) {
        $tracking_id = trim((string) $tracking_id);
        return $tracking_id !== '' && preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,62}-21$/', $tracking_id) === 1;
    }

    private function amazon_settings() {
        $stored = get_option('ppar_amazon_search_v1', array());
        $stored = is_array($stored) ? $stored : array();
        $settings = array_merge($this->amazon_settings_defaults(), $stored);
        if (defined('PPAR_AMAZON_TRACKING_ID') && $this->amazon_tracking_id_valid((string) PPAR_AMAZON_TRACKING_ID)) {
            $settings['tracking_id'] = trim((string) PPAR_AMAZON_TRACKING_ID);
        }
        $settings['enabled'] = !empty($settings['enabled']) && $this->amazon_tracking_id_valid((string) ($settings['tracking_id'] ?? ''));
        return $settings;
    }

    private function amazon_update_settings($settings) {
        $settings = array_merge($this->amazon_settings_defaults(), is_array($settings) ? $settings : array());
        $settings['tracking_id'] = trim(sanitize_text_field((string) ($settings['tracking_id'] ?? '')));
        $settings['enabled'] = !empty($settings['enabled']) && $this->amazon_tracking_id_valid($settings['tracking_id']);
        update_option('ppar_amazon_search_v1', $settings, false);
        return $this->amazon_settings();
    }

    public function amazon_bridge_ready() {
        $settings = $this->amazon_settings();
        return !empty($settings['enabled']) && $this->amazon_tracking_id_valid((string) ($settings['tracking_id'] ?? ''));
    }

    private function amazon_campaign_asins($campaign) {
        $out = array();
        foreach ((array) ($campaign['product_asins'] ?? array()) as $asin) {
            $asin = strtoupper(trim((string) $asin));
            if (preg_match('/^[A-Z0-9]{10}$/', $asin)) { $out[$asin] = $asin; }
        }
        return array_values($out);
    }

    public function amazon_product_from_campaign($campaign) {
        if (!$this->amazon_bridge_ready() || !is_array($campaign)) { return null; }
        if (sanitize_key((string) ($campaign['network'] ?? '')) !== 'idealo') { return null; }
        if (sanitize_key((string) ($campaign['creative_type'] ?? '')) !== 'product') { return null; }
        if ((string) ($campaign['source'] ?? '') !== 'idealo_product_feed_v1') { return null; }
        if (sanitize_key((string) ($campaign['product_identity_source'] ?? '')) !== 'gtin') { return null; }
        $asins = $this->amazon_campaign_asins($campaign);
        if (count($asins) !== 1) { return null; }
        $image = esc_url_raw((string) ($campaign['image_url'] ?? ''));
        if ($image === '' || stripos($image, 'https://') !== 0) { return null; }

        $settings = $this->amazon_settings();
        $asin = $asins[0];
        $tracking_id = trim((string) ($settings['tracking_id'] ?? ''));
        if (!$this->amazon_tracking_id_valid($tracking_id)) { return null; }

        $amazon = $campaign;
        $amazon['post_id'] = 0;
        $amazon['id'] = sanitize_key('amazon-' . $asin . '-' . (string) ($campaign['id'] ?? 'product'));
        $amazon['name'] = 'Amazon – ' . (string) ($campaign['title'] ?? $campaign['name'] ?? $asin);
        $amazon['partner'] = 'Amazon';
        $amazon['network'] = 'amazon';
        $amazon['advertiser_id'] = $tracking_id;
        $amazon['programme_name'] = 'Amazon PartnerNet';
        $amazon['programme_status'] = 'active';
        $amazon['programme_status_source'] = 'amazon_tracking_id';
        $amazon['programme_status_checked_at'] = time();
        $amazon['label'] = 'Amazon · Affiliate';
        $amazon['button_text'] = 'Bei Amazon ansehen';
        $amazon['url'] = esc_url_raw('https://www.amazon.de/dp/' . rawurlencode($asin) . '/ref=nosim?tag=' . rawurlencode($tracking_id));
        $amazon['price'] = '';
        $amazon['availability'] = '';
        $amazon['seller_name'] = '';
        $amazon['health_check_enabled'] = false;
        $amazon['source'] = 'amazon_asin_bridge_v1';
        $amazon['external_id'] = $asin;
        $amazon['product_asins'] = array($asin);
        $amazon['product_provider'] = 'amazon';
        unset($amazon['_ppar_norm_network'], $amazon['_ppar_runtime_normalized']);
        return $amazon;
    }

    public function amazon_render_access_card($provider, $definition, $contract_version) {
        if (sanitize_key((string) $provider) !== 'amazon') { return; }
        $settings = $this->amazon_settings();
        $external = defined('PPAR_AMAZON_TRACKING_ID') && $this->amazon_tracking_id_valid((string) PPAR_AMAZON_TRACKING_ID);
        ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="ppar_provider_access_save">
            <input type="hidden" name="provider" value="amazon">
            <?php wp_nonce_field('ppar_provider_access_amazon','ppar_provider_nonce'); ?>
            <p><label><input type="checkbox" name="ppar_provider[amazon][enabled]" value="1" <?php checked(!empty($settings['enabled'])); ?>> Amazon-Direktlinks verwenden</label></p>
            <p><label>Partner-/Tracking-ID <span class="ppar-saved"><?php echo esc_html($external ? 'über wp-config.php' : ($this->amazon_tracking_id_valid((string)$settings['tracking_id']) ? 'gespeichert' : 'nicht gespeichert')); ?></span><br>
            <input type="text" name="ppar_provider[amazon][tracking_id]" value="<?php echo esc_attr($external ? '' : (string)$settings['tracking_id']); ?>" placeholder="<?php echo esc_attr($external ? 'über wp-config.php gesetzt' : 'z. B. hobbydepot-21'); ?>" <?php disabled($external); ?>></label></p>
            <p class="description">Amazon-Produkte können über die vorhandene eindeutige idealo-ASIN-Brücke ergänzt und über die neue eigenständige DataForSEO-Recherche für konkrete Hobbys recherchiert werden. Produktrecherche ausschließlich nach ausdrücklichem Klick im Bereich Amazon + idealo.</p>
            <div class="ppar-v240-actions"><button class="button button-primary" name="ppar_provider_action" value="save">Speichern</button><button class="button" name="ppar_provider_action" value="save_test">Speichern &amp; prüfen</button></div>
        </form>
        <?php
    }

    private function provider_access_snapshot($provider) {
        $provider = sanitize_key((string) $provider);
        $definition = $this->provider_definition($provider);
        if (!$definition) { return array(); }
        $snapshot = array(
            'provider' => $provider,
            'label' => (string) $definition['label'],
            'state' => (string) $definition['state'],
            'configured' => false,
            'enabled' => false,
            'status' => 'not_configured',
            'last_checked' => 0,
            'message' => '',
        );
        if ((string) ($definition['access_owner'] ?? '') === 'none') {
            $snapshot['configured'] = true;
            $snapshot['enabled'] = (string) ($definition['state'] ?? '') === 'active';
            $snapshot['status'] = $snapshot['enabled'] ? 'not_required' : 'prepared';
            $snapshot['message'] = $snapshot['enabled'] ? 'Kein externer API-Zugang erforderlich.' : 'Provider ist noch nicht produktiv aktiviert.';
            return apply_filters('ppar_affiliate_provider_access_snapshot', $snapshot, $provider, $definition, self::PROVIDER_CONTRACT_VERSION);
        }
        if ($provider === 'amazon') {
            $settings = $this->amazon_settings();
            $snapshot['configured'] = $this->amazon_tracking_id_valid((string) ($settings['tracking_id'] ?? ''));
            $snapshot['enabled'] = !empty($settings['enabled']) && $snapshot['configured'];
            $state = $this->provider_access_state('amazon');
            $snapshot['status'] = $snapshot['configured'] ? sanitize_key((string) ($state['status'] ?? 'credentials_saved')) : 'not_configured';
            if ($snapshot['configured'] && in_array($snapshot['status'], array('not_configured','prepared'), true)) { $snapshot['status'] = 'credentials_saved'; }
            $snapshot['last_checked'] = absint($state['last_checked'] ?? 0);
            $snapshot['message'] = sanitize_text_field((string) ($state['message'] ?? ''));
            return apply_filters('ppar_affiliate_provider_access_snapshot', $snapshot, $provider, $definition, self::PROVIDER_CONTRACT_VERSION);
        }
        if ($provider === 'awin') {
            $settings = $this->network_settings('awin');
            $snapshot['configured'] = $this->network_credentials_present('awin', $settings);
            $snapshot['enabled'] = !empty($settings['enabled']);
            $snapshot['status'] = sanitize_key((string) ($settings['last_status'] ?? ($snapshot['configured'] ? 'credentials_saved' : 'not_configured')));
            $snapshot['last_checked'] = absint($settings['last_checked'] ?? 0);
            $snapshot['message'] = sanitize_text_field((string) ($settings['last_message'] ?? ''));
            return apply_filters('ppar_affiliate_provider_access_snapshot', $snapshot, $provider, $definition, self::PROVIDER_CONTRACT_VERSION);
        }
        if ($provider === 'adcell') {
            $settings = $this->network_settings('adcell');
            $snapshot['configured'] = $this->network_credentials_present('adcell', $settings);
            $snapshot['enabled'] = !empty($settings['enabled']);
            $snapshot['status'] = sanitize_key((string) ($settings['last_status'] ?? ($snapshot['configured'] ? 'credentials_saved' : 'not_configured')));
            $snapshot['last_checked'] = absint($settings['last_checked'] ?? 0);
            $snapshot['message'] = sanitize_text_field((string) ($settings['last_message'] ?? ''));
            return apply_filters('ppar_affiliate_provider_access_snapshot', $snapshot, $provider, $definition, self::PROVIDER_CONTRACT_VERSION);
        }
        if ($provider === 'ebay' && method_exists($this, 'ebay_settings')) {
            $settings = $this->ebay_settings();
            $snapshot['configured'] = trim((string) ($settings['client_id'] ?? '')) !== ''
                && trim((string) ($settings['client_secret'] ?? '')) !== ''
                && preg_match('/^\d{10}$/', (string) ($settings['epn_campaign_id'] ?? ''));
            $snapshot['enabled'] = !empty($settings['enabled']);
            $state = $this->provider_access_state('ebay');
            $snapshot['status'] = $snapshot['configured'] ? sanitize_key((string) ($state['status'] ?? 'credentials_saved')) : 'not_configured';
            if ($snapshot['configured'] && $snapshot['status'] === 'not_configured') { $snapshot['status'] = 'credentials_saved'; }
            $snapshot['last_checked'] = absint($state['last_checked'] ?? 0);
            $snapshot['message'] = sanitize_text_field((string) ($state['message'] ?? ''));
            return apply_filters('ppar_affiliate_provider_access_snapshot', $snapshot, $provider, $definition, self::PROVIDER_CONTRACT_VERSION);
        }
        $state = $this->provider_access_state($provider);
        $snapshot['status'] = (string) ($definition['state'] === 'prepared' ? 'prepared' : $state['status']);
        $snapshot['last_checked'] = absint($state['last_checked'] ?? 0);
        $snapshot['message'] = sanitize_text_field((string) ($state['message'] ?? ''));
        return apply_filters('ppar_affiliate_provider_access_snapshot', $snapshot, $provider, $definition, self::PROVIDER_CONTRACT_VERSION);
    }

    public function provider_credentials_preflight() {
        $rows = array();

        $awin = $this->network_settings('awin');
        $rows['awin'] = array(
            'label' => 'Awin',
            'required' => array(
                'Publisher-ID' => preg_replace('/[^0-9]/', '', (string)($awin['publisher_id'] ?? '')) !== '',
                'API-Zugriffstoken' => $this->network_secret('awin', 'access_token', $awin) !== '',
            ),
            'optional' => array(
                'Produktfeed-API-Schlüssel' => $this->network_secret('awin', 'feed_api_key', $awin) !== '',
            ),
        );

        $adcell = $this->network_settings('adcell');
        $rows['adcell'] = array(
            'label' => 'ADCELL',
            'required' => array(
                'API-Benutzername' => $this->network_secret('adcell', 'username', $adcell) !== '',
                'API-Passwort' => $this->network_secret('adcell', 'password', $adcell) !== '',
            ),
            'optional' => array(),
        );

        $ebay = method_exists($this, 'ebay_settings') ? $this->ebay_settings() : array();
        $rows['ebay'] = array(
            'label' => 'eBay',
            'required' => array(
                'Client-ID' => trim((string)($ebay['client_id'] ?? '')) !== '',
                'Client-Secret' => trim((string)($ebay['client_secret'] ?? '')) !== '',
                'EPN-Campaign-ID' => preg_match('/^\d{10}$/', (string)($ebay['epn_campaign_id'] ?? '')) === 1,
            ),
            'optional' => array(),
        );

        $idealo = method_exists($this, 'idealo_settings') ? $this->idealo_settings() : array();
        $rows['idealo'] = array(
            'label' => 'idealo',
            'required' => array(
                'iPN API-Key' => trim((string)($idealo['api_key'] ?? '')) !== '',
                'Adspace-ID' => preg_replace('/\D+/', '', (string)($idealo['adspace_id'] ?? '')) !== '',
                'Feed-ID' => preg_replace('/\D+/', '', (string)($idealo['feed_id'] ?? '')) !== '',
            ),
            'optional' => array(
                'iPN-Feed-URL' => trim((string)($idealo['feed_url'] ?? '')) !== '',
            ),
        );

        $amazon = $this->amazon_settings();
        $rows['amazon'] = array(
            'label' => 'Amazon',
            'required' => array(
                'Partner-/Tracking-ID' => $this->amazon_tracking_id_valid((string) ($amazon['tracking_id'] ?? '')),
            ),
            'optional' => array(),
        );

        $digistore = method_exists($this, 'digistore24_settings') ? $this->digistore24_settings() : array();
        $digistore_key = method_exists($this, 'digistore24_api_key') ? $this->digistore24_api_key($digistore) : '';
        $rows['digistore24'] = array(
            'label' => 'Digistore24',
            'required' => array(
                'Read-only API-Schlüssel' => trim((string)$digistore_key) !== '',
            ),
            'optional' => array(
                'Affiliate-ID (wird durch den Verbindungstest ermittelt)' => trim((string)($digistore['affiliate_id'] ?? '')) !== '',
            ),
        );

        $all_complete = true;
        foreach ($rows as $key => &$row) {
            $missing = array();
            foreach ((array)$row['required'] as $label => $ok) {
                if (!$ok) { $missing[] = (string)$label; }
            }
            $row['missing_required'] = $missing;
            $row['complete'] = !$missing;
            if ($missing) { $all_complete = false; }
        }
        unset($row);

        return array(
            'all_required_complete' => $all_complete,
            'providers' => $rows,
        );
    }

    private function provider_status_badge($snapshot) {
        $status = sanitize_key((string) ($snapshot['status'] ?? 'not_configured'));
        if ($status === 'connected') { return '<span class="ppar-network-status ppar-network-ok">Verbunden</span>'; }
        if ($status === 'credentials_saved' || $status === 'pending') { return '<span class="ppar-network-status ppar-network-saved">Zugangsdaten gespeichert</span>'; }
        if ($status === 'failed') { return '<span class="ppar-network-status ppar-network-failed">Prüfung fehlgeschlagen</span>'; }
        if ($status === 'prepared') { return '<span class="ppar-network-status ppar-network-neutral">Adapter vorbereitet</span>'; }
        if ($status === 'not_required') { return '<span class="ppar-network-status ppar-network-ok">Kein API-Zugang erforderlich</span>'; }
        return '<span class="ppar-network-status ppar-network-neutral">Nicht eingerichtet</span>';
    }

    /**
     * Sichtbarer Chefstatus eines Providers. Ein Veto ist kein Sonderpfad des
     * Providers, sondern ein zentraler Laufzeitblocker und deshalb für jeden
     * registrierten Provider identisch verfügbar.
     */
    private function provider_control_snapshot($provider) {
        $provider = sanitize_key((string) $provider);
        $snapshot = array('portal_key'=>'','status'=>'automatic','reason'=>'','exists'=>false);
        if ($provider === '' || !method_exists($this, 'control_get_decision') || !method_exists($this, 'output_local_portal_key')) {
            return $snapshot;
        }
        $portal_key = sanitize_key((string) $this->output_local_portal_key());
        if ($portal_key === '') { return $snapshot; }
        $decision = $this->control_get_decision($portal_key, 'provider', $provider);
        $snapshot['portal_key'] = $portal_key;
        if (!empty($decision['exists'])) {
            $snapshot['exists'] = true;
            $snapshot['status'] = sanitize_key((string) ($decision['status'] ?? 'automatic'));
            $snapshot['reason'] = sanitize_text_field((string) ($decision['reason'] ?? ''));
        }
        return $snapshot;
    }

    private function provider_control_badge($provider) {
        $control = $this->provider_control_snapshot($provider);
        $status = sanitize_key((string) ($control['status'] ?? 'automatic'));
        if ($status === 'veto') { return '<span class="ppar-network-status ppar-network-failed">Chef-Veto aktiv</span>'; }
        if ($status === 'paused') { return '<span class="ppar-network-status ppar-network-saved">Manuell pausiert</span>'; }
        if ($status === 'approved') { return '<span class="ppar-network-status ppar-network-ok">Manuell freigegeben</span>'; }
        return '<span class="ppar-network-status ppar-network-neutral">Chefsteuerung: Automatik</span>';
    }

    public function provider_control_url($provider) {
        return add_query_arg(array(
            'page' => 'affiliate-portal-control',
            'scope_type' => 'provider',
            'scope_key' => sanitize_key((string) $provider),
        ), admin_url('admin.php'));
    }


    /** Compact provider channel state used by the one-click pause/resume UI. */
    private function provider_channel_state_all() {
        $state = get_option(self::OPTION_PROVIDER_CHANNEL_STATE, array());
        return is_array($state) ? $state : array();
    }

    public function provider_channel_snapshot($provider) {
        $provider = sanitize_key((string) $provider);
        $all = $this->provider_channel_state_all();
        $stored = is_array($all[$provider] ?? null) ? $all[$provider] : array();
        $control = $this->provider_control_snapshot($provider);
        $control_status = sanitize_key((string) ($control['status'] ?? 'automatic'));
        $paused = !empty($stored['paused']);
        $status = $control_status === 'veto' ? 'veto' : ($paused ? 'paused' : $control_status);
        return array(
            'provider'=>$provider,
            'status'=>$status,
            'paused'=>$paused,
            'veto'=>$control_status === 'veto',
            'reason'=>$paused ? sanitize_text_field((string) ($stored['reason'] ?? '')) : sanitize_text_field((string) ($control['reason'] ?? '')),
            'updated_at'=>absint($stored['updated_at'] ?? 0),
        );
    }

    /**
     * One-click channel switch. It stores only a reversible runtime pause flag;
     * credentials, imported data, campaigns, provider settings and existing
     * Chefentscheidungen stay untouched and reappear exactly after resume.
     */
    public function provider_channel_set_paused($provider, $paused, $reason = '') {
        $provider = sanitize_key((string) $provider);
        if (!$this->provider_exists($provider)) {
            return new WP_Error('provider_channel_unknown', 'Unbekannter Affiliate-Kanal.');
        }
        $definition = $this->provider_definition($provider);
        if (!is_array($definition) || sanitize_key((string) ($definition['state'] ?? '')) !== 'active') {
            return new WP_Error('provider_channel_not_active', 'Affiliate-Kanal ist nicht produktiv registriert.');
        }
        $all = $this->provider_channel_state_all();
        $old = is_array($all[$provider] ?? null) ? $all[$provider] : array();
        $paused = (bool) $paused;
        $reason = sanitize_text_field((string) $reason);
        if ($paused && $reason === '') { $reason = 'Kanal per Schnellschalter pausiert.'; }
        if (!$paused && $reason === '') { $reason = 'Kanal per Schnellschalter wieder aktiviert.'; }
        $all[$provider] = array(
            'paused'=>$paused ? 1 : 0,
            'reason'=>$reason,
            'updated_at'=>time(),
            'updated_by'=>function_exists('get_current_user_id') ? absint(get_current_user_id()) : 0,
        );
        update_option(self::OPTION_PROVIDER_CHANNEL_STATE, $all, false);
        if (method_exists($this, 'control_log_event') && method_exists($this, 'output_local_portal_key')) {
            $portal_key = sanitize_key((string) $this->output_local_portal_key());
            $this->control_log_event('provider_channel_toggle', $portal_key, 'provider', $provider, !empty($old['paused']) ? 'paused' : 'automatic', $paused ? 'paused' : 'automatic', $reason, array('provider'=>$provider));
        }
        return true;
    }

    /** Backend/public runtime pause gate independent from credentials/settings. */
    public function provider_channel_pause_gate($provider) {
        $provider = sanitize_key((string) $provider);
        if ($provider === '' || !$this->provider_exists($provider)) {
            return new WP_Error('provider_channel_unknown', 'Unbekannter Affiliate-Kanal.');
        }
        $all = $this->provider_channel_state_all();
        $stored = is_array($all[$provider] ?? null) ? $all[$provider] : array();
        if (!empty($stored['paused'])) {
            return new WP_Error('provider_channel_paused', (string) (($stored['reason'] ?? '') ?: 'Affiliate-Kanal ist pausiert.'));
        }
        // A hard provider veto is stronger than the quick switch and must also
        // keep backend provider work stopped until the veto itself is removed.
        $control = $this->provider_control_snapshot($provider);
        if (sanitize_key((string) ($control['status'] ?? 'automatic')) === 'veto') {
            return new WP_Error('provider_channel_veto', (string) (($control['reason'] ?? '') ?: 'Affiliate-Kanal ist per Chef-Veto gesperrt.'));
        }
        return true;
    }

    /**
     * Zugänge der Kernprovider werden zentral gespeichert; Fachseiten verwalten
     * ausschließlich Betriebslogik. Weitere Provider übernehmen denselben
     * Vertrag über Registry- und Adapter-Hooks, ohne den Steuerkern umzubauen.
     */
    public function handle_provider_access_save() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $provider = sanitize_key((string) ($_POST['provider'] ?? ''));
        if (!$this->provider_exists($provider)) { wp_die('Unbekannter Provider.'); }
        check_admin_referer('ppar_provider_access_' . $provider, 'ppar_provider_nonce');
        $mode = sanitize_key((string) ($_POST['ppar_provider_action'] ?? 'save'));
        $raw = isset($_POST['ppar_provider'][$provider]) && is_array($_POST['ppar_provider'][$provider]) ? wp_unslash($_POST['ppar_provider'][$provider]) : array();
        $result = null;

        if (in_array($provider, array('awin','adcell'), true)) {
            $result = $this->persist_network_settings($provider, $raw);
            if (!is_wp_error($result)) {
                $settings = $this->network_settings($provider);
                $configured = $this->network_credentials_present($provider, $settings);
                $this->provider_set_access_state($provider, $configured ? 'credentials_saved' : 'not_configured', $configured ? $this->provider_label($provider) . '-Zugangsdaten gespeichert; Verbindung noch nicht geprüft.' : $this->provider_label($provider) . '-Zugang noch unvollständig.');
            }
        } elseif ($provider === 'ebay' && method_exists($this, 'ebay_settings')) {
            $previous = $this->ebay_settings();
            $input = $previous;
            $requested_enabled = !empty($raw['enabled']);
            $input['environment'] = in_array((string) ($raw['environment'] ?? ''), array('production','sandbox'), true) ? (string) $raw['environment'] : (string) ($previous['environment'] ?? 'production');
            $input['client_id'] = sanitize_text_field((string) ($raw['client_id'] ?? $previous['client_id'] ?? ''));
            $secret = trim((string) ($raw['client_secret'] ?? ''));
            if ($secret !== '') { $input['client_secret'] = $secret; }
            if (!empty($raw['remove_client_secret'])) { $input['client_secret'] = ''; }
            $input['epn_campaign_id'] = preg_replace('/\D+/', '', (string) ($raw['epn_campaign_id'] ?? $previous['epn_campaign_id'] ?? ''));
            $input['affiliate_reference_prefix'] = sanitize_key((string) ($raw['affiliate_reference_prefix'] ?? $previous['affiliate_reference_prefix'] ?? 'hobby-depot'));
            $credentials_changed = (string) ($input['environment'] ?? '') !== (string) ($previous['environment'] ?? '')
                || (string) ($input['client_id'] ?? '') !== (string) ($previous['client_id'] ?? '')
                || (string) ($input['epn_campaign_id'] ?? '') !== (string) ($previous['epn_campaign_id'] ?? '')
                || $secret !== '' || !empty($raw['remove_client_secret']);
            $access_state_before = $this->provider_access_state('ebay');
            $credential_ready_for_use = trim((string) ($input['client_id'] ?? '')) !== ''
                && trim((string) ($input['client_secret'] ?? '')) !== ''
                && preg_match('/^\d{10}$/', (string) ($input['epn_campaign_id'] ?? ''));
            $compliance_ready = (string) ($input['environment'] ?? 'production') === 'sandbox'
                || (method_exists($this, 'ebay_deletion_compliance_complete') && $this->ebay_deletion_compliance_complete());
            // Production bleibt bei jeder Credential-Aenderung und bis zur vollstaendigen
            // Account-Deletion-Compliance hart deaktiviert. Auch ein erfolgreicher OAuth-Test
            // darf die Nutzung ohne vollstaendige Affiliate-Konfiguration (inkl. 10-stelliger
            // EPN-Campaign-ID) nicht aktivieren. Danach ist ein bewusster Speicherschritt noetig.
            $input['enabled'] = $requested_enabled && $credential_ready_for_use && !$credentials_changed && $compliance_ready
                && (string) ($access_state_before['status'] ?? '') === 'connected';
            $settings = $this->ebay_normalize_settings($input, true);
            update_option(self::OPTION_NETWORK_EBAY, $settings, false);
            if (function_exists('delete_transient')) { delete_transient($this->ebay_token_cache_key($settings)); }
            $this->reschedule_ebay_cron(true);
            $saved = $this->ebay_settings();
            $expected_secret = trim((string) ($settings['client_secret'] ?? ''));
            $roundtrip_ok = (string) ($saved['environment'] ?? '') === (string) ($settings['environment'] ?? '')
                && (string) ($saved['client_id'] ?? '') === (string) ($settings['client_id'] ?? '')
                && (string) ($saved['epn_campaign_id'] ?? '') === (string) ($settings['epn_campaign_id'] ?? '')
                && ($expected_secret === '' || trim((string) ($saved['client_secret'] ?? '')) !== '');
            if (!$roundtrip_ok) {
                $result = new WP_Error('provider_access_roundtrip_failed', 'eBay-Zugangsdaten konnten nicht vollständig zurückgelesen werden.');
            } else {
                $configured = trim((string) ($saved['client_id'] ?? '')) !== '' && trim((string) ($saved['client_secret'] ?? '')) !== '' && preg_match('/^\d{10}$/', (string) ($saved['epn_campaign_id'] ?? ''));
                $production_compliance_missing = $configured
                    && (string) ($saved['environment'] ?? 'production') === 'production'
                    && method_exists($this, 'ebay_deletion_compliance_complete')
                    && !$this->ebay_deletion_compliance_complete();

                // Ein reiner Speichervorgang mit unveränderten Zugangsdaten darf einen
                // bereits real erfolgreich geprüften OAuth-Status niemals vernichten.
                // Genau dieser Statusverlust blockierte in V5.2.0 anschließend das Feld
                // „Verbindung verwenden“, obwohl Challenge, signierte Notification und
                // OAuth bereits erfolgreich waren. Nur echte Credential-/Compliance-
                // Änderungen erzwingen eine erneute Prüfung.
                if (!$configured) {
                    $this->provider_set_access_state('ebay', 'not_configured', 'eBay-Zugang noch unvollständig.');
                } elseif ($production_compliance_missing) {
                    $this->provider_set_access_state('ebay', 'credentials_saved', 'eBay-Zugangsdaten gespeichert; Production bleibt bis zur Account-Deletion-Compliance deaktiviert.');
                } elseif ($credentials_changed) {
                    $this->provider_set_access_state('ebay', 'credentials_saved', 'eBay-Zugangsdaten geändert; erneuter OAuth-Test erforderlich.');
                } elseif ((string) ($access_state_before['status'] ?? '') === 'connected') {
                    // Absichtlich keine Statusmutation: last_checked und die reale
                    // OAuth-Erfolgsmeldung bleiben als Evidenz des letzten Tests erhalten.
                } else {
                    $message = $requested_enabled && empty($saved['enabled'])
                        ? 'eBay-Zugangsdaten gespeichert; Verbindung bleibt bis zum erfolgreichen OAuth-Test bewusst deaktiviert.'
                        : 'eBay-Zugangsdaten gespeichert; Verbindung noch nicht geprüft.';
                    $this->provider_set_access_state('ebay', 'credentials_saved', $message);
                }
                $result = $saved;
            }
        } elseif ($provider === 'amazon') {
            $previous = $this->amazon_settings();
            $settings = $previous;
            $external = defined('PPAR_AMAZON_TRACKING_ID') && $this->amazon_tracking_id_valid((string) PPAR_AMAZON_TRACKING_ID);
            if (!$external && array_key_exists('tracking_id', $raw)) {
                $settings['tracking_id'] = trim(sanitize_text_field((string) ($raw['tracking_id'] ?? '')));
            }
            $settings['enabled'] = !empty($raw['enabled']);
            if ((string) ($settings['tracking_id'] ?? '') !== '' && !$this->amazon_tracking_id_valid((string) $settings['tracking_id'])) {
                $result = new WP_Error('amazon_tracking_id_invalid', 'Amazon Partner-/Tracking-ID ist ungültig. Für Amazon.de wird eine gültige -21-ID benötigt.');
            } else {
                $saved = $this->amazon_update_settings($settings);
                $configured = $this->amazon_tracking_id_valid((string) ($saved['tracking_id'] ?? ''));
                $this->provider_set_access_state('amazon', $configured ? 'credentials_saved' : 'not_configured', $configured ? 'Amazon Tracking-ID gespeichert. ASIN-Direktlinks können nach Aktivierung erzeugt werden.' : 'Amazon Tracking-ID fehlt.');
                $result = $saved;
            }
        } else {
            $handled = apply_filters('ppar_affiliate_provider_access_save', null, $provider, $raw, self::PROVIDER_CONTRACT_VERSION);
            $result = $handled === null ? new WP_Error('provider_access_handler_missing', 'Für diesen Provider ist noch kein Zugangsdaten-Adapter registriert.') : $handled;
        }

        if (!is_wp_error($result) && $mode === 'save_test') {
            $result = $this->provider_test_access($provider);
        }
        $args = array('page'=>'affiliate-portal-networks');
        if (is_wp_error($result)) {
            $args['ppar_provider_error'] = rawurlencode($result->get_error_message());
            $args['ppar_provider'] = $provider;
        } else {
            $args['ppar_provider_saved'] = $provider;
            if ($mode === 'save_test') { $args['ppar_provider_tested'] = $provider; }
        }
        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
        exit;
    }

    private function provider_test_access($provider) {
        $provider = sanitize_key((string) $provider);
        if ($provider === 'awin') {
            $result = $this->test_awin_connection();
            $settings = $this->network_settings('awin');
            $settings['last_status'] = (string)($result['status'] ?? 'failed');
            $settings['last_checked'] = time();
            $settings['last_message'] = sanitize_text_field((string)($result['message'] ?? ''));
            $settings['programme_count'] = absint($result['programme_count'] ?? $settings['programme_count'] ?? 0);
            $settings['feed_status'] = sanitize_key((string)($result['feed_status'] ?? $settings['feed_status'] ?? 'not_configured'));
            $settings['feed_count'] = absint($result['feed_count'] ?? $settings['feed_count'] ?? 0);
            update_option(self::OPTION_NETWORK_AWIN, $settings, false);
            $status = (string)($result['status'] ?? '') === 'connected' ? 'connected' : ((string)($result['status'] ?? '') === 'failed' ? 'failed' : 'credentials_saved');
            $this->provider_set_access_state('awin', $status, (string)($result['message'] ?? 'Awin-Verbindungstest abgeschlossen.'));
            return (string)($result['status'] ?? '') === 'failed' ? new WP_Error('awin_connection_failed', (string)($result['message'] ?? 'Awin-Verbindungstest fehlgeschlagen.')) : $result;
        }
        if ($provider === 'adcell') {
            $result = $this->adcell_api_v2_test_connection();
            $settings = $this->network_settings('adcell');
            $settings['last_status'] = (string)($result['status'] ?? 'failed');
            $settings['last_checked'] = time();
            $settings['last_message'] = sanitize_text_field((string)($result['message'] ?? ''));
            update_option(self::OPTION_NETWORK_ADCELL, $settings, false);
            $status = (string)($result['status'] ?? '') === 'connected' ? 'connected' : ((string)($result['status'] ?? '') === 'failed' ? 'failed' : 'credentials_saved');
            $this->provider_set_access_state('adcell', $status, (string)($result['message'] ?? 'ADCELL-Verbindungstest abgeschlossen.'));
            return (string)($result['status'] ?? '') === 'failed' ? new WP_Error('adcell_connection_failed', (string)($result['message'] ?? 'ADCELL-Verbindungstest fehlgeschlagen.')) : $result;
        }
        if ($provider === 'ebay' && method_exists($this, 'ebay_settings') && method_exists($this, 'ebay_access_token')) {
            $settings = $this->ebay_settings();
            if (trim((string) ($settings['client_id'] ?? '')) === '' || trim((string) ($settings['client_secret'] ?? '')) === '') {
                $this->provider_set_access_state('ebay', 'not_configured', 'Client-ID oder Client-Secret fehlt.');
                return new WP_Error('ebay_credentials_missing', 'Client-ID oder Client-Secret fehlt.');
            }
            if ((string) ($settings['environment'] ?? 'production') === 'production'
                && (!method_exists($this, 'ebay_deletion_challenge_answered') || !$this->ebay_deletion_challenge_answered())) {
                $message = 'eBay Production bleibt gesperrt, bis eBay den Marketplace-Account-Deletion-Endpoint per Challenge aufgerufen hat.';
                $this->provider_set_access_state('ebay', 'credentials_saved', $message);
                return new WP_Error('ebay_deletion_challenge_pending', $message);
            }
            $token = $this->ebay_access_token($settings, true, false);
            if (is_wp_error($token)) {
                $this->provider_set_access_state('ebay', 'failed', $token->get_error_message());
                return $token;
            }
            $this->provider_set_access_state('ebay', 'connected', 'eBay OAuth-Zugang erfolgreich authentifiziert.');
            return array('status'=>'connected');
        }
        if ($provider === 'amazon') {
            $settings = $this->amazon_settings();
            $tracking_id = trim((string) ($settings['tracking_id'] ?? ''));
            if (!$this->amazon_tracking_id_valid($tracking_id)) {
                $this->provider_set_access_state('amazon', 'not_configured', 'Amazon Tracking-ID fehlt oder ist ungültig.');
                return new WP_Error('amazon_tracking_id_missing', 'Amazon Partner-/Tracking-ID fehlt oder ist ungültig.');
            }
            $this->provider_set_access_state('amazon', 'credentials_saved', 'Amazon Tracking-ID geprüft; Direktlinks werden ausschließlich aus eindeutigen ASINs erzeugt.');
            return array('status'=>'credentials_saved','message'=>'Amazon Tracking-ID geprüft.');
        }
        $handled = apply_filters('ppar_affiliate_provider_access_test', null, $provider, self::PROVIDER_CONTRACT_VERSION);
        return $handled === null ? new WP_Error('provider_access_test_missing', 'Für diesen Provider ist noch kein Verbindungstest registriert.') : $handled;
    }

    public function provider_register_admin_menus($parent_slug) {
        foreach ($this->provider_registry() as $key => $provider) {
            if (empty($provider['specialist_menu']) || empty($provider['specialist_slug'])) { continue; }
            add_submenu_page(
                $parent_slug,
                (string) $provider['label'],
                (string) $provider['label'],
                'manage_options',
                (string) $provider['specialist_slug'],
                $key === 'ebay' ? array($this, 'render_ebay_page') : array($this, 'render_provider_specialist_page')
            );
        }
    }

    public function render_provider_specialist_page() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $page = sanitize_key((string) ($_GET['page'] ?? ''));
        $provider = '';
        foreach ($this->provider_registry() as $key => $definition) {
            if ((string) ($definition['specialist_slug'] ?? '') === $page) { $provider = $key; break; }
        }
        if ($provider === '') { wp_die('Unbekannte Provider-Fachseite.'); }
        $definition = $this->provider_definition($provider);
        $snapshot = $this->provider_access_snapshot($provider);
        ?>
        <div class="wrap" style="max-width:1180px">
            <h1><?php echo esc_html((string) $definition['label']); ?></h1>
            <p><strong>Provider-Fachseite.</strong> Zugangsdaten bleiben zentral unter <a href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-networks')); ?>">Netzwerke &amp; API</a>. Hier liegt ausschließlich provider-spezifische Betriebslogik.</p>
            <p><?php echo $this->provider_status_badge($snapshot); ?> <?php echo $this->provider_control_badge($provider); ?> <a class="button button-small" href="<?php echo esc_url($this->provider_control_url($provider)); ?>">Chefsteuerung &amp; Veto</a></p>
            <?php if ($provider === 'awin') : $awin_settings=$this->network_settings('awin'); $awin_programmes=get_option(self::OPTION_NETWORK_AWIN_PROGRAMMES,array()); $awin_programmes=is_array($awin_programmes)?$awin_programmes:array(); ?>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px">
                    <section class="postbox" style="padding:18px"><h2>Programme &amp; Partner</h2><p>Advertiser aufnehmen, Geschäftsbereich bestätigen und Portal-Freigabe steuern.</p><p><strong>Aktuell erkannte verbundene Programme:</strong> <?php echo absint(count($awin_programmes)); ?></p><?php $awin_refresh_state=sanitize_key((string)($_GET['ppar_awin_refresh']??'')); if($awin_refresh_state==='ok'): ?><div class="notice notice-success inline"><p>Awin-Programmliste aktualisiert: <?php echo absint($_GET['ppar_awin_refresh_count']??count($awin_programmes)); ?> verbundene Programme.</p></div><?php elseif(in_array($awin_refresh_state,array('failed','not_ready'),true)): ?><div class="notice notice-error inline"><p><?php echo esc_html((string)($_GET['ppar_awin_refresh_message']??'Awin-Programmliste konnte nicht aktualisiert werden.')); ?></p></div><?php endif; ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;margin-right:8px"><input type="hidden" name="action" value="ppar_refresh_awin_programmes"><?php wp_nonce_field('ppar_refresh_awin_programmes','ppar_awin_refresh_nonce'); ?><button class="button button-primary" type="submit">Programme jetzt aktualisieren</button></form><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-partner-intake&provider=awin')); ?>">Awin-Partner öffnen</a></section>
                    <section class="postbox" style="padding:18px"><h2>Automatisierung</h2><p>Programmdaten, Offers und Produktfeeds in sicheren Arbeitspaketen verarbeiten.</p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-automation&provider=awin')); ?>">Awin-Automatisierung öffnen</a></section>
                    <section class="postbox" style="padding:18px"><h2>Synchronisierung</h2><p>Read-only Netzwerk- und Produktdatenläufe prüfen.</p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-sync')); ?>">Synchronisierung öffnen</a></section>
                </div>
                <section class="postbox" style="padding:18px;margin-top:18px;max-width:900px"><h2>Produktfeed-Betriebsprofil</h2><p>Diese Zuordnung ist Providerlogik und gehört deshalb nicht zu den zentralen Zugangsdaten.</p>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="ppar_save_network"><input type="hidden" name="network" value="awin"><input type="hidden" name="ppar_network_action" value="save"><input type="hidden" name="return_page" value="affiliate-portal-provider-awin"><?php wp_nonce_field('ppar_save_network_awin','ppar_network_nonce'); ?>
                    <p><label>Awin-Produktfeed-Export-URL (optional)<br><input class="large-text" type="url" name="ppar_network[awin][product_feed_url]" value="<?php echo esc_attr((string)($awin_settings['product_feed_url']??'')); ?>"></label></p>
                    <p><label>Advertiser-ID dieses Produktfeeds<br><input type="number" min="1" step="1" name="ppar_network[awin][product_feed_partner_id]" value="<?php echo esc_attr((string)($awin_settings['product_feed_partner_id']??'')); ?>"></label></p>
                    <p><label><input type="checkbox" name="ppar_network[awin][product_feed_scope]" value="portal_filtered" <?php checked((string)($awin_settings['product_feed_scope']??''),'portal_filtered'); ?>> Dieser Export wurde in Awin <strong>Create-a-Feed</strong> auf für das Hobby Depot relevante Kategorien eingegrenzt.</label></p>
                    <p class="description">Für OTTO/Awin 14336 ist ein ungefilterter Vollfeed ab jetzt gesperrt. Die lokale Relevanzprüfung bleibt zusätzlich aktiv und verwirft fachfremde Zeilen vor der Speicherung.</p><?php submit_button('Awin-Betriebsprofil speichern','secondary'); ?></form>
                </section>
                <?php if (method_exists($this,'render_awin_programme_gate_section')) { $this->render_awin_programme_gate_section($awin_programmes); } ?>
            <?php elseif ($provider === 'adcell') : $adcell_catalog=method_exists($this,'adcell_api_v2_programme_catalog')?$this->adcell_api_v2_programme_catalog():array(); $adcell_allowlist=method_exists($this,'adcell_program_id_allowlist')?$this->adcell_program_id_allowlist():array(); ?>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px">
                    <section class="postbox" style="padding:18px"><h2>API-v2 Programme</h2><p><strong>Zuletzt accepted + aktiv:</strong> <?php echo absint(count((array)$adcell_catalog)); ?><br><strong>programId-Allowlist:</strong> <?php echo $adcell_allowlist ? esc_html(implode(', ', $adcell_allowlist)) : 'leer – alles gesperrt'; ?></p><p>Programme und Allowlist werden zentral in der Provider-Synchronisierung geprüft. Es gibt keinen manuellen CSV-Pfad.</p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-sync')); ?>">Programme &amp; Allowlist öffnen</a></section>
                    <section class="postbox" style="padding:18px"><h2>Automatisierung</h2><p>Nur freigegebene accepted+aktive programIds: API v2 → CSV/Banner/Deeplink → zentrale Creative-/Relevanz-/Veto-/Ausgabelogik.</p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-automation&provider=adcell')); ?>">ADCELL-Automatisierung öffnen</a></section>
                </div>
            <?php endif; ?>
            <?php do_action('ppar_affiliate_render_provider_specialist_' . $provider, $provider, $definition, self::PROVIDER_CONTRACT_VERSION); ?>
        </div>
        <?php
    }

    /**
     * Skalierbare Partnerübersicht. Feste WordPress-Menüpunkte pro Advertiser
     * sind ausdrücklich verboten; einzelne Partner bleiben Datensätze.
     */
    public function render_partner_directory_page() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $registry = $this->provider_registry();
        ?>
        <div class="wrap" style="max-width:1180px">
            <h1>Partner</h1>
            <p>Partner/Advertiser sind Datensätze innerhalb ihres Providers – keine festen WordPress-Menüpunkte. Chef-Veto und manuelle Freigaben gelten providerübergreifend.</p>
            <table class="widefat striped"><thead><tr><th>Provider</th><th>Status</th><th>Partnerverwaltung</th><th>Steuerung</th></tr></thead><tbody>
            <?php foreach ($registry as $key => $provider) : if (!in_array('partners', (array) $provider['capabilities'], true)) { continue; } $snapshot=$this->provider_access_snapshot($key); ?>
                <tr><td><strong><?php echo esc_html((string) $provider['label']); ?></strong></td><td><?php echo $this->provider_status_badge($snapshot); ?><br><?php echo $this->provider_control_badge($key); ?></td><td>
                    <?php if ($key === 'awin') : ?><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-partner-intake&provider=awin')); ?>">Awin-Partner verwalten</a>
                    <?php elseif ($key === 'ebay') : ?><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-ebay')); ?>">eBay-Verkäuferlogik öffnen</a>
                    <?php elseif (!empty($provider['specialist_menu']) && !empty($provider['specialist_slug'])) : ?><a class="button" href="<?php echo esc_url(admin_url('admin.php?page='.(string)$provider['specialist_slug'])); ?>">Provider-Fachseite öffnen</a>
                    <?php else : ?><?php do_action('ppar_affiliate_render_partner_directory_action_' . $key, $key, $provider, self::PROVIDER_CONTRACT_VERSION); ?><span class="description">Provideradapter/Import</span><?php endif; ?>
                </td><td><a class="button" href="<?php echo esc_url($this->provider_control_url($key)); ?>">Chefsteuerung &amp; Veto</a></td></tr>
            <?php endforeach; ?>
            </tbody></table>
        </div>
        <?php
    }
}
