<?php
/**
 * Hobby Depot: Amazon + idealo launch / independent DataForSEO Amazon research.
 * Research is admin-triggered, paid and never runs in page requests.
 * Approved products and in-house banners are tied to exact WordPress targets.
 */
if (!defined('ABSPATH')) { exit; }

final class HDAR_Amazon_Start {
    const MODE_OPTION = 'hdar_launch_partners_v1';
    const API_OPTION = 'hdar_amazon_dfs_access_v1';
    const PRODUCTS_OPTION = 'hdar_amazon_approved_v1';
    const PAGE = 'hobby-depot-amazon-start';
    private static $seen_card_ids = array();

    public static function bootstrap() {
        add_action('admin_menu', array(__CLASS__, 'admin_menu'), 50);
        add_action('admin_post_hdar_amazon_save', array(__CLASS__, 'save'));
        add_action('admin_post_hdar_amazon_search', array(__CLASS__, 'search'));
        add_action('admin_post_hdar_amazon_approve', array(__CLASS__, 'approve'));
        add_action('admin_post_hdar_amazon_remove', array(__CLASS__, 'remove'));
        add_action('admin_post_hdar_banner_assign', array(__CLASS__, 'banner_assign'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue'));
        add_action('init', array(__CLASS__, 'suppress_other_network_shortcodes'), 20);
        add_shortcode('hobby_amazon_produkten', array(__CLASS__, 'shortcode_products'));
        add_shortcode('hobby_amazon_banner', array(__CLASS__, 'shortcode_banner'));
    }

    public static function suppress_other_network_shortcodes() {
        if (!self::launch_active()) { return; }
        add_shortcode('affiliate_textlink', array(__CLASS__, 'empty_shortcode'));
        add_shortcode('affiliate_rechner', array(__CLASS__, 'empty_shortcode'));
    }
    public static function empty_shortcode() { return ''; }

    public static function launch_active() {
        return get_option(self::MODE_OPTION, 'off') === 'amazon_idealo';
    }
    public static function only_mode_active() { // legacy test compatibility
        return self::launch_active();
    }
    public static function idealo_product_slot($slot) {
        $slot = sanitize_key((string)$slot);
        return (bool)preg_match('/^(?:category|hub|journal|article|post)_product_[123]$/D', $slot)
            || in_array($slot, array('mid_content','primary_product','bottom_content','article_mid_product','post_bottom_products'), true);
    }

    private static function credentials() {
        $stored = get_option(self::API_OPTION, array());
        if (!is_array($stored)) { $stored = array(); }
        return array(
            'login' => defined('HDAR_DATAFORSEO_LOGIN') ? (string) HDAR_DATAFORSEO_LOGIN : (string) ($stored['login'] ?? ''),
            'password' => defined('HDAR_DATAFORSEO_PASSWORD') ? (string) HDAR_DATAFORSEO_PASSWORD : (string) ($stored['password'] ?? ''),
        );
    }
    private static function tracking_id() {
        $settings = get_option('ppar_amazon_search_v1', array());
        $settings = is_array($settings) ? $settings : array();
        $tag = defined('PPAR_AMAZON_TRACKING_ID') ? (string) PPAR_AMAZON_TRACKING_ID : (string) ($settings['tracking_id'] ?? '');
        if (empty($settings['enabled']) || !preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,62}-21$/D', trim($tag))) { return ''; }
        return trim($tag);
    }
    private static function target($type, $id, $taxonomy = '') {
        $id = absint($id);
        if (!$id) { return null; }
        if ($type === 'post') {
            $p = get_post($id);
            if (!$p || $p->post_status !== 'publish') { return null; }
            return array('key'=>'post:'.$id, 'title'=>get_the_title($id), 'url'=>get_permalink($id));
        }
        if ($type === 'term') {
            $taxonomy = sanitize_key($taxonomy);
            if (!$taxonomy || !taxonomy_exists($taxonomy)) { return null; }
            $term = get_term($id, $taxonomy);
            if (!$term || is_wp_error($term)) { return null; }
            $url = get_term_link($term);
            if (is_wp_error($url)) { return null; }
            return array('key'=>'term:'.$taxonomy.':'.$id, 'title'=>(string) $term->name, 'url'=>$url);
        }
        return null;
    }
    private static function target_from_post() {
        $post_id = absint(get_the_ID());
        return $post_id ? self::target('post',$post_id) : null;
    }
    private static function products() {
        $data = get_option(self::PRODUCTS_OPTION, array());
        return is_array($data) ? $data : array();
    }
    private static function context_target($context, $content_id = '') {
        $stored = self::products();
        $keys = array();
        if (is_string($content_id) && preg_match('/^term_([0-9]+)$/', $content_id, $match)) {
            $term = get_term(absint($match[1]));
            if ($term && !is_wp_error($term)) { $keys[] = 'term:'.sanitize_key($term->taxonomy).':'.absint($term->term_id); }
        }
        $queried = function_exists('get_queried_object') ? get_queried_object() : null;
        if ($queried instanceof WP_Term) { $keys[] = 'term:'.sanitize_key($queried->taxonomy).':'.absint($queried->term_id); }
        $id = absint($context['post_id'] ?? (is_numeric($content_id) ? $content_id : 0));
        if ($id) { $keys[] = 'post:'.$id; }
        // Exact targets only: never infer that a broad parent or unrelated hobby matches.
        foreach (array_unique($keys) as $key) {
            if (isset($stored[$key]) && (!empty($stored[$key]['items']) || !empty($stored[$key]['banner_enabled']))) { return array('key'=>$key, 'data'=>$stored[$key]); }
        }
        return null;
    }
    public static function render_slot($context, $slot_type, $content_id = '') {
        if (!self::only_mode_active()) { return ''; }
        $slot = sanitize_key($slot_type);
        $match = self::context_target(is_array($context) ? $context : array(), $content_id);
        if (!$match) { return ''; }
        if (preg_match('/^(?:category|hub|journal|article|post)_product_([123])$/D', $slot, $pos)) {
            return self::product_card($match, (int)$pos[1], $slot);
        }
        if (in_array($slot, array('mid_content','primary_product','bottom_content','article_mid_product'), true)) {
            return self::product_card($match, 1, $slot);
        }
        $wide = array('start_after_topics','hub_after_cards','product_after_category_tiles','journal_banner','anzeigenmarkt_top_banner','anzeigenmarkt_category_banner','glossary_overview_banner','post_inline_banner');
        $square = array('glossary_single_desktop_banner','glossary_single_mobile_banner','glossary_single_banner','hobbyregister_banner');
        if (in_array($slot,$wide,true)) { return self::house_banner($match, 'wide'); }
        if (in_array($slot,$square,true)) { return self::house_banner($match, 'square'); }
        // Other placements deliberately stay empty in Amazon+idealo launch mode.
        return '';
    }
    public static function shortcode_banner($atts = array()) {
        if (!self::only_mode_active()) { return ''; }
        $atts = shortcode_atts(array('format'=>'square'),(array)$atts,'hobby_amazon_banner');
        $match = self::context_target(array('post_id'=>get_the_ID()), get_the_ID());
        return $match ? self::house_banner($match, sanitize_key($atts['format'])==='wide'?'wide':'square') : '';
    }
    public static function shortcode_products() {
        if (!self::only_mode_active()) { return ''; }
        $match = self::context_target(array('post_id'=>get_the_ID()), get_the_ID());
        if (!$match) { return ''; }
        $html = '';
        foreach (array(1,2,3) as $position) { $html .= self::product_card($match,$position,'category_product_'.$position); }
        return $html;
    }
    private static function product_card($match, $position, $slot = 'category_product_1') {
        $items = array_values((array)($match['data']['items'] ?? array()));
        $item = $items[$position-1] ?? null;
        if (!is_array($item) || !preg_match('/^[A-Z0-9]{10}$/D', (string)($item['asin']??''))) { return ''; }
        $tag = self::tracking_id();
        if ($tag === '') { return ''; }
        $asin = $item['asin'];
        $url = 'https://www.amazon.de/dp/'.rawurlencode($asin).'?tag='.rawurlencode($tag);
        $title = (string)($item['title']??$asin);
        return '<div class="ppar-affiliate-slot hdar-amazon-product" data-ppar-slot="'.esc_attr($slot).'" id="hdar-amazon-product-'.absint($position).'">'
            .'<span class="hdar-amazon-label">Anzeige</span><strong>'.esc_html($title).'</strong>'
            .'<span class="hdar-amazon-note">Ausrüstung für dieses Hobby</span>'
            .'<a class="hdar-amazon-button" href="'.esc_url($url).'" rel="sponsored nofollow noopener" target="_blank">Bei Amazon ansehen</a></div>';
    }
    private static function house_banner($match, $format) {
        $data = $match['data'];
        if (empty($data['banner_enabled'])) { return ''; }
        $theme = sanitize_key((string) ($data['theme']??''));
        $title = trim((string) ($data['label']??''));
        if ($title === '') { return ''; }
        $target = $data['url']??'';
        if ($target === '') { return ''; }
        $cls = $format === 'square' ? 'hdar-house-square' : 'hdar-house-wide';
        $image = $theme === 'modellbau' ? 'assets/hdar-hobby-modellbau-'.($format==='square'?'square':'wide').'.webp' : '';
        $background = $image !== '' ? '<img class="hdar-house-image" src="'.esc_url(plugins_url($image,dirname(__FILE__))).'" alt="" loading="lazy">' : '';
        return '<aside class="ppar-affiliate-slot hdar-house-banner '.esc_attr($cls).'" aria-label="Hobby entdecken">'
            .$background.'<div class="hdar-house-copy"><span class="hdar-house-overline">Hobby Depot · Inspiration</span>'
            .'<strong>'.esc_html($title).' entdecken</strong><a href="'.esc_url($target).'">Zum Hobby</a></div></aside>';
    }
    public static function enqueue() {
        if (self::only_mode_active()) {
            wp_enqueue_style('hdar-amazon-start', plugins_url('assets/hdar-amazon-start.css', dirname(__FILE__)), array(), '0.1.12');
        }
    }
    public static function admin_menu() {
        add_submenu_page('affiliate-portal-zentrale', 'Hobby Depot – Amazon + idealo', 'Amazon + idealo', 'manage_options', self::PAGE, array(__CLASS__,'screen'));
    }
    private static function guard($nonce) {
        if (!current_user_can('manage_options')) { wp_die('Nicht berechtigt.'); }
        check_admin_referer($nonce);
    }
    private static function back($message) {
        wp_safe_redirect(add_query_arg(array('page'=>self::PAGE,'hdar_notice'=>$message),admin_url('admin.php')));
        exit;
    }
    public static function save() {
        self::guard('hdar_amazon_save');
        $enabled = !empty($_POST['hdar_launch']);
        // Activation only when an actual Amazon PartnerNet tag is already valid.
        if ($enabled && self::tracking_id()==='') { self::back('tracking'); }
        update_option(self::MODE_OPTION,$enabled?'amazon_idealo':'off',false);
        $login = isset($_POST['hdar_dfs_login']) ? sanitize_text_field(wp_unslash($_POST['hdar_dfs_login'])) : '';
        $pass = isset($_POST['hdar_dfs_password']) ? (string)wp_unslash($_POST['hdar_dfs_password']) : '';
        if ($login !== '' || $pass !== '') {
            $previous = get_option(self::API_OPTION,array());
            if (!is_array($previous)) { $previous=array(); }
            if ($login !== '') { $previous['login']=$login; }
            if ($pass !== '') { $previous['password']=$pass; }
            update_option(self::API_OPTION,$previous,false);
        }
        self::back('saved');
    }
    private static function parse_results($body) {
        if (!is_array($body) || (int)($body['status_code']??0)!==20000) { return array(); }
        $task = $body['tasks'][0]??array();
        if ((int)($task['status_code']??0)!==20000) { return array(); }
        $items = $task['result'][0]['items']??array();
        $out = array();
        foreach ((array)$items as $row) {
            if (!is_array($row) || ($row['type']??'')!=='amazon_serp') { continue; }
            $asin = strtoupper(trim((string)($row['data_asin']??'')));
            if (!preg_match('/^[A-Z0-9]{10}$/D',$asin)) { continue; }
            $title = trim(sanitize_text_field((string)($row['title']??'')));
            if ($title==='' || isset($out[$asin])) { continue; }
            $out[$asin]=array('asin'=>$asin,'title'=>(function_exists('mb_substr') ? mb_substr($title,0,160) : substr($title,0,160)));
            if (count($out)>=10) {break;}
        }
        return array_values($out);
    }
    public static function search() {
        self::guard('hdar_amazon_search');
        $target = self::target(sanitize_key((string)($_POST['hdar_target_type']??'')),absint($_POST['hdar_target_id']??0),sanitize_key((string)($_POST['hdar_taxonomy']??'')));
        $keyword = sanitize_text_field(wp_unslash((string)($_POST['hdar_keyword']??'')));
        if (!$target || strlen($keyword)<3 || strlen($keyword)>160) { self::back('target'); }
        $creds = self::credentials();
        if ($creds['login']==='' || $creds['password']==='') { self::back('dfs'); }
        // One explicit paid call per administrator search, never frontend/cron.
        $answer = wp_remote_post('https://api.dataforseo.com/v3/merchant/amazon/products/live/advanced',array(
            'timeout'=>45,'headers'=>array('Authorization'=>'Basic '.base64_encode($creds['login'].':'.$creds['password']),'Content-Type'=>'application/json'),
            'body'=>wp_json_encode(array(array('keyword'=>$keyword,'location_name'=>'Germany','language_code'=>'de_DE','se_domain'=>'amazon.de','depth'=>10))),
        ));
        if (is_wp_error($answer) || wp_remote_retrieve_response_code($answer)!==200) { self::back('api'); }
        $items = self::parse_results(json_decode(wp_remote_retrieve_body($answer),true));
        if (!$items) { self::back('empty'); }
        set_transient('hdar_amazon_results_'.get_current_user_id(),array('target'=>$target,'keyword'=>$keyword,'items'=>$items),20*MINUTE_IN_SECONDS);
        self::back('results');
    }
    public static function approve() {
        self::guard('hdar_amazon_approve');
        $asin = strtoupper(sanitize_text_field((string)($_POST['hdar_asin']??'')));
        $saved = get_transient('hdar_amazon_results_'.get_current_user_id());
        if (!is_array($saved) || !preg_match('/^[A-Z0-9]{10}$/D',$asin)) {self::back('expired');}
        $item = null;
        foreach ($saved['items'] as $candidate) { if ($candidate['asin']===$asin) {$item=$candidate;break;} }
        if (!$item) {self::back('expired');}
        $key = (string)$saved['target']['key'];
        $all = self::products();
        $entry = $all[$key]??array('items'=>array());
        $entry['label'] = $saved['target']['title'];
        $entry['url'] = $saved['target']['url'];
        $entry['keyword'] = $saved['keyword'];
        if (!empty($_POST['hdar_banner'])) {
            $entry['theme'] = sanitize_key((string)($_POST['hdar_theme']??''))==='modellbau'?'modellbau':'';
            $entry['banner_enabled'] = true;
        }
        $existing = (array)($entry['items']??array());
        foreach ($existing as $one) { if (($one['asin']??'')===$asin) {self::back('duplicate');} }
        if (count($existing)>=3) {self::back('limit');}
        $existing[]=$item;
        $entry['items']=$existing;
        $all[$key]=$entry;
        update_option(self::PRODUCTS_OPTION,$all,false);
        self::back('approved');
    }
    public static function banner_assign() {
        self::guard('hdar_banner_assign');
        $target = self::target(sanitize_key((string)($_POST['hdar_target_type']??'')),
            absint($_POST['hdar_target_id']??0), sanitize_key((string)($_POST['hdar_taxonomy']??'')));
        if (!$target) { self::back('target'); }
        $all = self::products();
        $entry = $all[$target['key']] ?? array('items'=>array());
        $entry['label'] = (string)$target['title'];
        $entry['url'] = (string)$target['url'];
        $entry['banner_enabled'] = !empty($_POST['hdar_banner']);
        $entry['theme'] = sanitize_key((string)($_POST['hdar_theme']??'')) === 'modellbau' ? 'modellbau' : '';
        if (!empty($entry['banner_enabled']) || !empty($entry['items'])) { $all[$target['key']]=$entry; }
        else { unset($all[$target['key']]); }
        update_option(self::PRODUCTS_OPTION,$all,false);
        self::back('banner');
    }
    public static function remove() {
        self::guard('hdar_amazon_remove');
        $key = sanitize_text_field((string)($_POST['hdar_key']??''));
        $asin = strtoupper(sanitize_text_field((string)($_POST['hdar_asin']??'')));
        $all = self::products();
        if (isset($all[$key]['items'])) {
            $all[$key]['items']=array_values(array_filter($all[$key]['items'],static function($row) use ($asin){return ($row['asin']??'')!==$asin;}));
            if (!$all[$key]['items']) {unset($all[$key]);}
            update_option(self::PRODUCTS_OPTION,$all,false);
        }
        self::back('removed');
    }
    public static function screen() {
        if (!current_user_can('manage_options')) {return;}
        $creds = self::credentials();$ready = self::tracking_id()!=='';
        $saved = get_transient('hdar_amazon_results_'.get_current_user_id());
        $stored = self::products();
        $notice=sanitize_key((string)($_GET['hdar_notice']??''));
        ?>
        <div class="wrap"><h1>Hobby Depot – Amazon + idealo</h1>
        <p>Amazon und idealo können getrennt Produkte liefern. Weitere Partner werden beim Start nicht ausgespielt, ihre Daten bleiben erhalten. DataForSEO-Recherche erfolgt nur nach Klick. Eigene Banner für passende Hobbyseiten sind möglich.</p>
        <?php if ($notice) : ?><div class="notice notice-info"><p><?php echo esc_html(array(
          'saved'=>'Einstellungen gespeichert.','tracking'=>'Zuerst die Amazon-Tracking-ID im bestehenden Amazon-Partner-Menü speichern und aktivieren.',
          'target'=>'Bitte ein gültiges Ziel und konkretes Suchwort wählen.','dfs'=>'DataForSEO-Zugang fehlt.',
          'api'=>'DataForSEO-Abfrage fehlgeschlagen; keine Produkte veröffentlicht.', 'empty'=>'Keine eindeutig belegten Amazon-ASINs gefunden.',
          'results'=>'Ergebnisse gefunden. Bitte passend auswählen.', 'expired'=>'Auswahl abgelaufen. Bitte erneut recherchieren.',
          'approved'=>'Amazon-Produkt für das genaue Hobby-Ziel gespeichert.', 'duplicate'=>'Dieses Produkt ist dort bereits vorhanden.',
          'limit'=>'Maximal drei ausgewählte Produkte pro Hobby-Ziel.', 'removed'=>'Produktzuordnung entfernt.', 'banner'=>'Hobby-Banner für dieses genaue Ziel gespeichert.',
        )[$notice] ?? 'Aktion abgeschlossen.'); ?></p></div><?php endif; ?>
        <h2>1. Amazon und idealo freischalten</h2>
        <p>Amazon-Tracking-ID: <strong><?php echo $ready?'bereits gültig gespeichert':'noch nicht bestätigt'; ?></strong> (im bestehenden Amazon-Partner-Menü).</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="hdar_amazon_save"><?php wp_nonce_field('hdar_amazon_save'); ?>
        <p><label><input type="checkbox" name="hdar_launch" value="1" <?php checked(self::launch_active()); ?>> Amazon und idealo als einzige öffentliche Partner verwenden (andere Partner bleiben gespeichert)</label></p><p>Für idealo öffnen: <a href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-provider-idealo')); ?>">Affiliate-Zentrale → idealo</a>. Dort separat den Hobby-Depot-Feed bestätigen.</p>
        <h2>2. DataForSEO-Zugang</h2>
        <p>Bereits hinterlegt: <strong><?php echo $creds['login']!==''&&$creds['password']!==''?'ja':'nein'; ?></strong>. Bestehende Zugangsdaten bleiben beim leeren Feld erhalten.</p>
        <p><label>DataForSEO API-Login <input type="text" name="hdar_dfs_login" autocomplete="off" value="" size="40"></label></p>
        <p><label>DataForSEO API-Passwort <input type="password" name="hdar_dfs_password" autocomplete="new-password" value="" size="40"></label></p>
        <?php submit_button('Einstellungen speichern'); ?></form>
        <h2>3. Produkte für genau ein Hobby recherchieren</h2>
        <p>Nur nach Klick auf „Recherchieren“ entsteht ein kostenpflichtiger DataForSEO-Aufruf. Keine Preise/Bilder werden übernommen.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="hdar_amazon_search"><?php wp_nonce_field('hdar_amazon_search'); ?>
        <p><label>Zielart <select name="hdar_target_type"><option value="post">Seite / Hobbyregister / Beitrag</option><option value="term">Kategorie / Glossargruppe</option></select></label>
        <label>WordPress-ID <input type="number" min="1" name="hdar_target_id" required></label>
        <label>Taxonomie (nur bei Kategorie) <input type="text" name="hdar_taxonomy" value="category" placeholder="category"></label></p>
        <p><label>Konkrete Ausrüstung suchen <input type="text" name="hdar_keyword" placeholder="z. B. Modellflugzeug Bausatz" size="45" required></label></p>
        <?php submit_button('Bei DataForSEO recherchieren (kostenpflichtig)','secondary'); ?></form>
        <?php if (is_array($saved)&&!empty($saved['items'])): ?>
        <h2>Gefundene ASINs für <?php echo esc_html($saved['target']['title']); ?></h2>
        <?php foreach ($saved['items'] as $one): ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="padding:12px;border-bottom:1px solid #ddd">
          <input type="hidden" name="action" value="hdar_amazon_approve"><input type="hidden" name="hdar_asin" value="<?php echo esc_attr($one['asin']); ?>">
          <?php wp_nonce_field('hdar_amazon_approve'); ?>
          <strong><?php echo esc_html($one['title']); ?></strong> (<?php echo esc_html($one['asin']); ?>)
          <label><input type="checkbox" name="hdar_banner" value="1"> Eigenen Themenbanner für dieses Hobby anzeigen</label>
          <label>Motiv <select name="hdar_theme"><option value="">Nur Typografie</option><option value="modellbau">Modellbau (Originalmotiv)</option></select></label>
          <button class="button button-primary">Für dieses Hobby übernehmen</button>
        </form><?php endforeach; ?><?php endif; ?>
        <h2>4. Eigenbanner unabhängig von Produkten zuordnen</h2>
        <p>Querformat für normale Seiten, Quadratformat für Register und Glossar. Immer nur die gewählte Hobbyseite, keine pauschale Vererbung.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <input type="hidden" name="action" value="hdar_banner_assign"><?php wp_nonce_field('hdar_banner_assign'); ?>
          <p><label>Zielart <select name="hdar_target_type"><option value="post">Seite / Hobbyregister / Beitrag</option><option value="term">Kategorie / Glossargruppe</option></select></label>
          <label>WordPress-ID <input type="number" min="1" name="hdar_target_id" required></label>
          <label>Taxonomie <input name="hdar_taxonomy" value="category"></label></p>
          <p><label><input name="hdar_banner" type="checkbox" value="1" checked> Eigenbanner aktiv</label>
          <label>Motiv <select name="hdar_theme"><option value="">Ruhiger Farb-/Textbanner</option><option value="modellbau">Modellbau – Originalmotiv</option></select></label></p>
          <?php submit_button('Banner für dieses Hobby speichern','secondary'); ?>
        </form>
        <h2>5. Bereits zugeordnete Produkte</h2>
        <?php if (!$stored) echo '<p>Noch keine Freigaben. Bis dahin bleiben die Amazon-Produktflaechen leer.</p>'; ?>
        <?php foreach ($stored as $key=>$entry): ?><h3><?php echo esc_html($entry['label']??$key); ?> (<?php echo esc_html($key); ?>)</h3>
          <?php foreach ((array)($entry['items']??array()) as $item): ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <input type="hidden" name="action" value="hdar_amazon_remove"><input type="hidden" name="hdar_key" value="<?php echo esc_attr($key); ?>"><input type="hidden" name="hdar_asin" value="<?php echo esc_attr($item['asin']); ?>">
          <?php wp_nonce_field('hdar_amazon_remove'); ?><?php echo esc_html($item['title']); ?> (<?php echo esc_html($item['asin']); ?>)
          <button class="button">Entfernen</button></form><?php endforeach; ?><?php endforeach; ?>
        </div>
        <?php
    }
}
