<?php
/**
 * Hobby Depot: Amazon + idealo launch / independent DataForSEO Amazon research.
 * Research is admin-triggered, paid and never runs in page requests.
 * Approved Amazon products use exact WordPress targets. Existing core handles all banners.
 */
if (!defined('ABSPATH')) { exit; }

final class HDAR_Amazon_Start {
    const MODE_OPTION = 'hdar_launch_partners_v1';
    const API_OPTION = 'hdar_amazon_dfs_access_v1';
    const PRODUCTS_OPTION = 'hdar_amazon_approved_v1';
    const PAGE = 'hobby-depot-amazon-start';
    private static $seen_card_ids = array();

    public static function bootstrap() {
        add_action('admin_menu', array(__CLASS__, 'admin_menu'), 50);
        add_action('admin_post_hdar_amazon_save', array(__CLASS__, 'save'));
        add_action('admin_post_hdar_dfs_test', array(__CLASS__, 'test_connection'));
        add_action('admin_post_hdar_amazon_search', array(__CLASS__, 'search'));
        add_action('admin_post_hdar_amazon_approve', array(__CLASS__, 'approve'));
        add_action('admin_post_hdar_amazon_remove', array(__CLASS__, 'remove'));
        add_action('admin_post_hdar_amazon_image', array(__CLASS__, 'save_image'));
        add_filter('the_content', array(__CLASS__, 'render_article_cards'), 1350);
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue'));
        add_action('init', array(__CLASS__, 'suppress_other_network_shortcodes'), 20);
        add_shortcode('hobby_amazon_produkten', array(__CLASS__, 'shortcode_products'));
    }

    public static function suppress_other_network_shortcodes() {
        if (!self::launch_active()) { return; }
        add_shortcode('affiliate_textlink', array(__CLASS__, 'empty_shortcode'));
        add_shortcode('affiliate_rechner', array(__CLASS__, 'empty_shortcode'));
    }
    public static function empty_shortcode() { return ''; }

    public static function launch_active() {
        return get_option(self::MODE_OPTION, 'off') === 'amazon_idealo';
    }
    public static function only_mode_active() { // legacy test compatibility
        return self::launch_active();
    }
    public static function idealo_product_slot($slot) {
        $slot = sanitize_key((string)$slot);
        return (bool)preg_match('/^(?:category|hub|journal|article|post)_product_[123]$/D', $slot)
            || in_array($slot, array('mid_content','primary_product','bottom_content','article_mid_product','post_bottom_products'), true);
    }

    private static function credentials() {
        $stored = get_option(self::API_OPTION, array());
        if (!is_array($stored)) { $stored = array(); }
        return array(
            'login' => defined('HDAR_DATAFORSEO_LOGIN') ? (string) HDAR_DATAFORSEO_LOGIN : (string) ($stored['login'] ?? ''),
            'password' => defined('HDAR_DATAFORSEO_PASSWORD') ? (string) HDAR_DATAFORSEO_PASSWORD : (string) ($stored['password'] ?? ''),
        );
    }
    private static function tracking_id() {
        $settings = get_option('ppar_amazon_search_v1', array());
        $settings = is_array($settings) ? $settings : array();
        $tag = defined('PPAR_AMAZON_TRACKING_ID') ? (string) PPAR_AMAZON_TRACKING_ID : (string) ($settings['tracking_id'] ?? '');
        if (empty($settings['enabled']) || !preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,62}-21$/D', trim($tag))) { return ''; }
        return trim($tag);
    }
    private static function target($type, $id, $taxonomy = '') {
        $id = absint($id);
        if (!$id) { return null; }
        if ($type === 'post') {
            $p = get_post($id);
            if (!$p || $p->post_status !== 'publish') { return null; }
            return array('key'=>'post:'.$id, 'title'=>get_the_title($id), 'url'=>get_permalink($id));
        }
        if ($type === 'term') {
            $taxonomy = sanitize_key($taxonomy);
            if (!$taxonomy || !taxonomy_exists($taxonomy)) { return null; }
            $term = get_term($id, $taxonomy);
            if (!$term || is_wp_error($term)) { return null; }
            $url = get_term_link($term);
            if (is_wp_error($url)) { return null; }
            return array('key'=>'term:'.$taxonomy.':'.$id, 'title'=>(string) $term->name, 'url'=>$url);
        }
        return null;
    }
    private static function target_from_post() {
        $post_id = absint(get_the_ID());
        return $post_id ? self::target('post',$post_id) : null;
    }
    private static function products() {
        $data = get_option(self::PRODUCTS_OPTION, array());
        return is_array($data) ? $data : array();
    }
    private static function context_target($context, $content_id = '') {
        $stored = self::products();
        $keys = array();
        if (is_string($content_id) && preg_match('/^term_([0-9]+)$/', $content_id, $match)) {
            $term = get_term(absint($match[1]));
            if ($term && !is_wp_error($term)) { $keys[] = 'term:'.sanitize_key($term->taxonomy).':'.absint($term->term_id); }
        }
        $queried = function_exists('get_queried_object') ? get_queried_object() : null;
        if ($queried instanceof WP_Term) { $keys[] = 'term:'.sanitize_key($queried->taxonomy).':'.absint($queried->term_id); }
        $id = absint($context['post_id'] ?? (is_numeric($content_id) ? $content_id : 0));
        if ($id) { $keys[] = 'post:'.$id; }
        // Exact targets only: never infer that a broad parent or unrelated hobby matches.
        foreach (array_unique($keys) as $key) {
            if (isset($stored[$key]) && !empty($stored[$key]['items'])) { return array('key'=>$key, 'data'=>$stored[$key]); }
        }
        return null;
    }
    public static function render_slot($context, $slot_type, $content_id = '') {
        if (!self::only_mode_active()) { return ''; }
        $slot = sanitize_key($slot_type);
        $match = self::context_target(is_array($context) ? $context : array(), $content_id);
        if (!$match) { return ''; }
        if (preg_match('/^(?:category|hub|journal|article|post)_product_([123])$/D', $slot, $pos)) {
            return self::product_card($match, (int)$pos[1], $slot);
        }
        if (in_array($slot, array('mid_content','primary_product','bottom_content','article_mid_product'), true)) {
            return self::product_card($match, 1, $slot);
        }
        // Banner slots stay in the existing central Affiliate automation.
        return '';
    }
    public static function shortcode_products() {
        if (!self::only_mode_active()) { return ''; }
        $match = self::context_target(array('post_id'=>get_the_ID()), get_the_ID());
        if (!$match) { return ''; }
        $html = '';
        foreach (array(1,2,3) as $position) { $html .= self::product_card($match,$position,'category_product_'.$position); }
        return $html;
    }

    /** Product photo is an existing WP image with an explicit use-rights
     * confirmation from the portal owner. Never copy DataForSEO/Amazon
     * image URLs or render a text-only substitute. */
    private static function verified_image($item) {
        if (!is_array($item) ||
            (string)($item['image_source'] ?? '') !== 'own_or_licensed') { return ''; }
        $id = absint($item['image_id'] ?? 0);
        if (!$id || !function_exists('wp_attachment_is_image') ||
            !wp_attachment_is_image($id)) { return ''; }
        $src = wp_get_attachment_image_url($id, 'medium_large');
        return is_string($src) && $src !== '' ? $src : '';
    }

    private static function product_card($match, $position, $slot = 'category_product_1') {
        $items = array_values((array)($match['data']['items'] ?? array()));
        $item = $items[$position-1] ?? null;
        if (!is_array($item) ||
            !preg_match('/^[A-Z0-9]{10}$/D',(string)($item['asin'] ?? ''))) { return ''; }
        $img = self::verified_image($item);
        $tag = self::tracking_id();
        if ($tag === '' || $img === '') { return ''; }
        $asin = $item['asin'];
        $url = 'https://www.amazon.de/dp/'.rawurlencode($asin).'?tag='.rawurlencode($tag);
        $title = trim((string)($item['title'] ?? ''));
        if ($title === '') { return ''; }
        return '<article class="ppar-affiliate-slot hdar-amazon-product hdar-amazon-photo-product" data-ppar-slot="'.esc_attr($slot).'">'
            .'<a class="hdar-amazon-photo-link" href="'.esc_url($url).'" rel="sponsored nofollow noopener" target="_blank">'
            .'<img src="'.esc_url($img).'" alt="'.esc_attr($title).'" loading="lazy" decoding="async">'
            .'</a><h3>'.esc_html($title).'</h3>'
            .'<a class="hdar-amazon-button" href="'.esc_url($url).'" rel="sponsored nofollow noopener" target="_blank">'
            .'Bei Amazon ansehen</a></article>';
    }

    /** One article product area, attached to the existing full-article content.
     * Works inside the Hab-inspired right column if it exists. Otherwise
     * it is an ordinary responsive block at the end of a standard article.
     * An existing product section always wins: never duplicate product boxes.
     */
    public static function render_article_cards($content) {
        if (!is_string($content) || !self::launch_active() || is_admin() ||
            is_feed() || !is_singular('post') || !in_the_loop() || !is_main_query()) {
            return $content;
        }
        $id = absint(get_the_ID());
        if (!$id || post_password_required($id) ||
            (string)get_post_status($id) !== 'publish') { return $content; }
        if (strpos($content,'hdar-amazon-article-products') !== false ||
            strpos($content,'ppar-article-products') !== false ||
            strpos($content,'post_bottom_products') !== false) { return $content; }
        $key = 'post:'.$id;
        $stored = self::products();
        if (empty($stored[$key]['items'])) { return $content; }
        $match = array('key'=>$key,'data'=>$stored[$key]);
        $cards = array();
        for ($pos=1; $pos<=3; $pos++) {
            $html = self::product_card($match,$pos,'article_product_'.$pos);
            if ($html !== '') { $cards[]=$html; }
        }
        if (!$cards) { return $content; }
        $section='<section class="hdar-amazon-article-products" aria-label="Passende Amazon-Produkte">'
            .'<span class="hdar-amazon-label">Anzeige</span>'
            .'<h2>Passende Ausrüstung</h2>'
            .'<div class="hdar-amazon-article-grid">'.implode('',$cards).'</div></section>';
        // Do not alter HD003's markup; inject inside the one approved sidebar
        // when it exists, without requiring a change to the design plugin.
        $needle='<aside class="hd-article-sidebar-v150804"';
        $at=strpos($content,$needle);
        if ($at!==false) {
            $close=strpos($content,'>',$at);
            if ($close!==false) {
                return substr($content,0,$close+1).$section.substr($content,$close+1);
            }
        }
        return $content."\n".$section;
    }

    public static function enqueue() {
        if (self::only_mode_active()) {
            wp_enqueue_style('hdar-amazon-start', plugins_url('assets/hdar-amazon-start.css', dirname(__FILE__)), array(), '0.1.29');
        }
    }
    public static function admin_menu() {
        add_submenu_page('affiliate-portal-zentrale', 'Hobby Depot – Amazon + idealo', 'Amazon + idealo', 'manage_options', self::PAGE, array(__CLASS__,'screen'));
    }
    private static function guard($nonce) {
        if (!current_user_can('manage_options')) { wp_die('Nicht berechtigt.'); }
        check_admin_referer($nonce);
    }
    private static function back($message) {
        wp_safe_redirect(add_query_arg(array('page'=>self::PAGE,'hdar_notice'=>$message),admin_url('admin.php')));
        exit;
    }
    public static function save() {
        self::guard('hdar_amazon_save');
        $enabled = !empty($_POST['hdar_launch']);
        // Activation only when an actual Amazon PartnerNet tag is already valid.
        if ($enabled && self::tracking_id()==='') { self::back('tracking'); }
        update_option(self::MODE_OPTION,$enabled?'amazon_idealo':'off',false);
        $login = isset($_POST['hdar_dfs_login']) ? sanitize_text_field(wp_unslash($_POST['hdar_dfs_login'])) : '';
        $pass = isset($_POST['hdar_dfs_password']) ? (string)wp_unslash($_POST['hdar_dfs_password']) : '';
        if ($login !== '' || $pass !== '') {
            $previous = get_option(self::API_OPTION,array());
            if (!is_array($previous)) { $previous=array(); }
            if ($login !== '') { $previous['login']=$login; }
            if ($pass !== '') { $previous['password']=$pass; }
            update_option(self::API_OPTION,$previous,false);
        }
        self::back('saved');
    }
    /** No-cost account/authentication check. Never runs a paid product task. */
    public static function test_connection() {
        self::guard('hdar_dfs_test');
        $creds = self::credentials();
        if ($creds['login'] === '' || $creds['password'] === '') { self::back('dfs'); }
        $answer = wp_remote_get('https://api.dataforseo.com/v3/appendix/user_data', array(
            'timeout' => 15,
            'redirection' => 0,
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode($creds['login'] . ':' . $creds['password']),
                'Accept' => 'application/json',
            ),
        ));
        $status = 'dfs_error';
        if (!is_wp_error($answer)) {
            $http_code = (int) wp_remote_retrieve_response_code($answer);
            $body = json_decode((string) wp_remote_retrieve_body($answer), true);
            if ($http_code === 200 && is_array($body)
                && (int) ($body['status_code'] ?? 0) === 20000
                && (int) ($body['tasks'][0]['status_code'] ?? 0) === 20000) {
                $status = 'dfs_ok';
            } elseif ($http_code === 401 || $http_code === 403) {
                $status = 'dfs_auth';
            } elseif ($http_code === 429) {
                $status = 'dfs_limit';
            }
        }
        // One user-visible status only. Never store a password, response or API login in a test log.
        set_transient('hdar_dfs_check_' . get_current_user_id(),
            array('status' => $status, 'at' => time()), HOUR_IN_SECONDS);
        self::back($status);
    }

    private static function parse_results($body) {
        if (!is_array($body) || (int)($body['status_code']??0)!==20000) { return array(); }
        $task = $body['tasks'][0]??array();
        if ((int)($task['status_code']??0)!==20000) { return array(); }
        $items = $task['result'][0]['items']??array();
        $out = array();
        foreach ((array)$items as $row) {
            if (!is_array($row) || ($row['type']??'')!=='amazon_serp') { continue; }
            $asin = strtoupper(trim((string)($row['data_asin']??'')));
            if (!preg_match('/^[A-Z0-9]{10}$/D',$asin)) { continue; }
            $title = trim(sanitize_text_field((string)($row['title']??'')));
            if ($title==='' || isset($out[$asin])) { continue; }
            $out[$asin]=array('asin'=>$asin,'title'=>(function_exists('mb_substr') ? mb_substr($title,0,160) : substr($title,0,160)));
            if (count($out)>=10) {break;}
        }
        return array_values($out);
    }
    public static function search() {
        self::guard('hdar_amazon_search');
        $target = self::target(sanitize_key((string)($_POST['hdar_target_type']??'')),absint($_POST['hdar_target_id']??0),sanitize_key((string)($_POST['hdar_taxonomy']??'')));
        $keyword = sanitize_text_field(wp_unslash((string)($_POST['hdar_keyword']??'')));
        if (!$target || strlen($keyword)<3 || strlen($keyword)>160) { self::back('target'); }
        $creds = self::credentials();
        if ($creds['login']==='' || $creds['password']==='') { self::back('dfs'); }
        // One explicit paid call per administrator search, never frontend/cron.
        $answer = wp_remote_post('https://api.dataforseo.com/v3/merchant/amazon/products/live/advanced',array(
            'timeout'=>45,'headers'=>array('Authorization'=>'Basic '.base64_encode($creds['login'].':'.$creds['password']),'Content-Type'=>'application/json'),
            'body'=>wp_json_encode(array(array('keyword'=>$keyword,'location_name'=>'Germany','language_code'=>'de_DE','se_domain'=>'amazon.de','depth'=>10))),
        ));
        if (is_wp_error($answer) || wp_remote_retrieve_response_code($answer)!==200) { self::back('api'); }
        $items = self::parse_results(json_decode(wp_remote_retrieve_body($answer),true));
        if (!$items) { self::back('empty'); }
        set_transient('hdar_amazon_results_'.get_current_user_id(),array('target'=>$target,'keyword'=>$keyword,'items'=>$items),20*MINUTE_IN_SECONDS);
        self::back('results');
    }
    public static function approve() {
        self::guard('hdar_amazon_approve');
        $asin = strtoupper(sanitize_text_field((string)($_POST['hdar_asin']??'')));
        $saved = get_transient('hdar_amazon_results_'.get_current_user_id());
        if (!is_array($saved) || !preg_match('/^[A-Z0-9]{10}$/D',$asin)) {self::back('expired');}
        $item = null;
        foreach ($saved['items'] as $candidate) { if ($candidate['asin']===$asin) {$item=$candidate;break;} }
        if (!$item) {self::back('expired');}
        $key = (string)$saved['target']['key'];
        $all = self::products();
        $entry = $all[$key]??array('items'=>array());
        $entry['label'] = $saved['target']['title'];
        $entry['url'] = $saved['target']['url'];
        $entry['keyword'] = $saved['keyword'];
        $existing = (array)($entry['items']??array());
        foreach ($existing as $one) { if (($one['asin']??'')===$asin) {self::back('duplicate');} }
        if (count($existing)>=3) {self::back('limit');}
        $existing[]=$item;
        $entry['items']=$existing;
        $all[$key]=$entry;
        update_option(self::PRODUCTS_OPTION,$all,false);
        self::back('approved');
    }

    /** Only portal-owned or separately licensed photographs from the
     * existing WordPress Media Library can be attached here.
     * There is no automatic approval of rights or product identity. */
    public static function save_image() {
        self::guard('hdar_amazon_image');
        $key=sanitize_text_field(wp_unslash((string)($_POST['hdar_key'] ?? '')));
        $asin=strtoupper(sanitize_text_field(wp_unslash((string)($_POST['hdar_asin'] ?? ''))));
        $id=absint($_POST['hdar_image_id'] ?? 0);
        if (!preg_match('/^(?:post:[0-9]+|term:[a-z0-9_-]+:[0-9]+)$/D',$key) ||
            !preg_match('/^[A-Z0-9]{10}$/D',$asin)) { self::back('target'); }
        $all=self::products();
        if (empty($all[$key]['items']) || !is_array($all[$key]['items'])) {
            self::back('expired');
        }
        $index=null;
        foreach ($all[$key]['items'] as $i=>$item) {
            if (($item['asin'] ?? '')===$asin) { $index=$i; break; }
        }
        if ($index === null) { self::back('expired'); }
        if ($id!==0) {
            if (empty($_POST['hdar_image_rights']) ||
                !current_user_can('edit_post',$id) ||
                !wp_attachment_is_image($id) ||
                !wp_get_attachment_image_url($id,'medium_large')) {
                self::back('image_rights');
            }
            $all[$key]['items'][$index]['image_id']=$id;
            $all[$key]['items'][$index]['image_source']='own_or_licensed';
        } else {
            // Explicit 0 removes the link, so an image can be withdrawn.
            unset($all[$key]['items'][$index]['image_id'],
                  $all[$key]['items'][$index]['image_source']);
        }
        update_option(self::PRODUCTS_OPTION,$all,false);
        self::back($id ? 'image_saved' : 'image_removed');
    }

    public static function remove() {
        self::guard('hdar_amazon_remove');
        $key = sanitize_text_field((string)($_POST['hdar_key']??''));
        $asin = strtoupper(sanitize_text_field((string)($_POST['hdar_asin']??'')));
        $all = self::products();
        if (isset($all[$key]['items'])) {
            $all[$key]['items']=array_values(array_filter($all[$key]['items'],static function($row) use ($asin){return ($row['asin']??'')!==$asin;}));
            if (!$all[$key]['items']) {unset($all[$key]);}
            update_option(self::PRODUCTS_OPTION,$all,false);
        }
        self::back('removed');
    }
    public static function screen() {
        if (!current_user_can('manage_options')) {return;}
        $creds = self::credentials();$ready = self::tracking_id()!=='';
        if (function_exists('wp_enqueue_media')) { wp_enqueue_media(); }
        $saved = get_transient('hdar_amazon_results_'.get_current_user_id());
        $stored = self::products();
        $notice=sanitize_key((string)($_GET['hdar_notice']??''));
        ?>
        <div class="wrap"><h1>Hobby Depot – Amazon + idealo</h1>
        <p>Amazon und idealo können getrennt Produkte liefern. Weitere Partner bleiben gespeichert. DataForSEO-Recherche erfolgt nur nach Klick. Banner und ihre automatische Themen-/Formatzuordnung laufen über die bestehende zentrale Affiliate-Automatik.</p>
        <p><strong>Artikel-Produktboxen:</strong> Ein freigegebenes Produkt erscheint nur, wenn ein eigenes oder ausdrücklich lizenziertes echtes Produktfoto in der WordPress-Mediathek zugeordnet wurde. Keine kopierten Amazon- oder DataForSEO-Produktfotos.</p>
        <?php if ($notice) : ?><div class="notice notice-info"><p><?php echo esc_html(array(
          'saved'=>'Einstellungen gespeichert.','tracking'=>'Zuerst die Amazon-Tracking-ID im bestehenden Amazon-Partner-Menü speichern und aktivieren.',
          'target'=>'Bitte ein gültiges Ziel und konkretes Suchwort wählen.','dfs'=>'DataForSEO-Zugang fehlt.',
          'api'=>'DataForSEO-Abfrage fehlgeschlagen; keine Produkte veröffentlicht.', 'empty'=>'Keine eindeutig belegten Amazon-ASINs gefunden.',
          'results'=>'Ergebnisse gefunden. Bitte passend auswählen.', 'expired'=>'Auswahl abgelaufen. Bitte erneut recherchieren.',
          'approved'=>'Amazon-Produkt für das genaue Hobby-Ziel gespeichert.', 'duplicate'=>'Dieses Produkt ist dort bereits vorhanden.',
          'limit'=>'Maximal drei ausgewählte Produkte pro Hobby-Ziel.', 'removed'=>'Produktzuordnung entfernt.',
          'image_saved'=>'Das freigegebene Produktfoto ist zugeordnet.',
          'image_removed'=>'Produktfoto-Verknüpfung entfernt.',
          'image_rights'=>'Nur ein echtes WordPress-Bild mit bestätigten Nutzungsrechten ist zulässig.',
          'dfs_ok'=>'DataForSEO-Verbindung erfolgreich geprüft (kostenlos).',
          'dfs_auth'=>'DataForSEO-Zugang wurde zurückgewiesen. Bitte API-Zugang prüfen.',
          'dfs_limit'=>'DataForSEO meldet zu viele Anfragen. Bitte später erneut testen.',
          'dfs_error'=>'DataForSEO-Verbindung konnte nicht bestätigt werden. Keine Produktsuche ausgelöst.',
        )[$notice] ?? 'Aktion abgeschlossen.'); ?></p></div><?php endif; ?>
        <h2>1. Amazon und idealo freischalten</h2>
        <p>Amazon-Tracking-ID: <strong><?php echo $ready?'bereits gültig gespeichert':'noch nicht bestätigt'; ?></strong> (im bestehenden Amazon-Partner-Menü).</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="hdar_amazon_save"><?php wp_nonce_field('hdar_amazon_save'); ?>
        <p><label><input type="checkbox" name="hdar_launch" value="1" <?php checked(self::launch_active()); ?>> Amazon und idealo als einzige öffentliche Partner verwenden (andere Partner bleiben gespeichert)</label></p><p>Für idealo öffnen: <a href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-provider-idealo')); ?>">Affiliate-Zentrale → idealo</a>. Dort separat den Hobby-Depot-Feed bestätigen.</p>
        <h2>2. DataForSEO-Zugang</h2>
        <p>Bereits hinterlegt: <strong><?php echo $creds['login']!==''&&$creds['password']!==''?'ja':'nein'; ?></strong>. Bestehende Zugangsdaten bleiben beim leeren Feld erhalten.</p>
        <p><label>DataForSEO API-Login <input type="text" name="hdar_dfs_login" autocomplete="off" value="" size="40"></label></p>
        <p><label>DataForSEO API-Passwort <input type="password" name="hdar_dfs_password" autocomplete="new-password" value="" size="40"></label></p>
        <?php submit_button('Einstellungen speichern'); ?></form>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <input type="hidden" name="action" value="hdar_dfs_test"><?php wp_nonce_field('hdar_dfs_test'); ?>
          <?php submit_button('DataForSEO-Verbindung kostenlos prüfen','secondary','',false); ?>
        </form>
        <?php $dfs_check = get_transient('hdar_dfs_check_' . get_current_user_id());
          if (is_array($dfs_check) && !empty($dfs_check['status'])) : ?>
          <p><strong>Letzte Prüfung:</strong> <?php echo esc_html(($dfs_check['status'] === 'dfs_ok' ? 'erfolgreich' : 'nicht erfolgreich') . ' · ' . wp_date('d.m.Y H:i',absint($dfs_check['at']??0))); ?></p>
        <?php endif; ?>
        <h2>3. Produkte für genau ein Hobby recherchieren</h2>
        <p>Nur nach Klick auf „Recherchieren“ entsteht ein kostenpflichtiger DataForSEO-Aufruf. Keine Preise/Bilder werden übernommen.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="hdar_amazon_search"><?php wp_nonce_field('hdar_amazon_search'); ?>
        <p><label>Zielart <select name="hdar_target_type"><option value="post">Seite / Hobbyregister / Beitrag</option><option value="term">Kategorie / Glossargruppe</option></select></label>
        <label>WordPress-ID <input type="number" min="1" name="hdar_target_id" required></label>
        <label>Taxonomie (nur bei Kategorie) <input type="text" name="hdar_taxonomy" value="category" placeholder="category"></label></p>
        <p><label>Konkrete Ausrüstung suchen <input type="text" name="hdar_keyword" placeholder="z. B. Modellflugzeug Bausatz" size="45" required></label></p>
        <?php submit_button('Bei DataForSEO recherchieren (kostenpflichtig)','secondary'); ?></form>
        <?php if (is_array($saved)&&!empty($saved['items'])): ?>
        <h2>Gefundene ASINs für <?php echo esc_html($saved['target']['title']); ?></h2>
        <?php foreach ($saved['items'] as $one): ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="padding:12px;border-bottom:1px solid #ddd">
          <input type="hidden" name="action" value="hdar_amazon_approve"><input type="hidden" name="hdar_asin" value="<?php echo esc_attr($one['asin']); ?>">
          <?php wp_nonce_field('hdar_amazon_approve'); ?>
          <strong><?php echo esc_html($one['title']); ?></strong> (<?php echo esc_html($one['asin']); ?>)
          <button class="button button-primary">Für dieses Hobby übernehmen</button>
        </form><?php endforeach; ?><?php endif; ?>
        <p><strong>Banner-Zuordnung:</strong> Erfolgt automatisch unter <a href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-zentrale')); ?>">Affiliate-Zentrale</a> über die bestehende Banner- und Werbemittelverwaltung. Keine manuelle Zuordnung nach WordPress-ID auf dieser Seite.</p>
        <h2>4. Bereits zugeordnete Produkte</h2>
        <?php if (!$stored) echo '<p>Noch keine Freigaben. Bis dahin bleiben die Amazon-Produktflaechen leer.</p>'; ?>
        <?php foreach ($stored as $key=>$entry): ?><h3><?php echo esc_html($entry['label']??$key); ?> (<?php echo esc_html($key); ?>)</h3>
          <?php foreach ((array)($entry['items']??array()) as $item): ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
          <input type="hidden" name="action" value="hdar_amazon_remove"><input type="hidden" name="hdar_key" value="<?php echo esc_attr($key); ?>"><input type="hidden" name="hdar_asin" value="<?php echo esc_attr($item['asin']); ?>">
          <?php wp_nonce_field('hdar_amazon_remove'); ?><?php echo esc_html($item['title']); ?> (<?php echo esc_html($item['asin']); ?>)
          <button class="button">Entfernen</button></form>
          <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin:6px 0 18px;padding:10px;border:1px solid #dcdcde">
            <input type="hidden" name="action" value="hdar_amazon_image">
            <input type="hidden" name="hdar_key" value="<?php echo esc_attr($key); ?>">
            <input type="hidden" name="hdar_asin" value="<?php echo esc_attr($item['asin']); ?>">
            <?php wp_nonce_field('hdar_amazon_image'); ?>
            <strong>Artikelbild:</strong> <?php echo !empty($item['image_id']) && self::verified_image($item) !== '' ? 'gültig hinterlegt' : 'fehlt – Produktbox wird nicht ausgegeben'; ?>
            <p><label>Medien-ID <input class="small-text hdar-own-product-photo-id" name="hdar_image_id" type="number" min="0" value="<?php echo esc_attr((string)absint($item['image_id'] ?? 0)); ?>"></label>
            <button type="button" class="button hdar-choose-product-photo">Bild aus Mediathek wählen</button></p>
            <p><label><input type="checkbox" name="hdar_image_rights" value="1">
            Ich bestätige, dass dieses Foto das Produkt korrekt zeigt und ich die Nutzungsrechte für die Werbeverwendung habe. Keine ungeprüft kopierten Amazon- oder DataForSEO-Bilder.</label></p>
            <button class="button button-primary">Produktfoto speichern</button>
            <small>Mit Medien-ID 0 wird eine vorhandene Bildzuordnung entfernt.</small>
          </form><?php endforeach; ?><?php endforeach; ?>
          <script>
          document.addEventListener('click',function(event){
            var button=event.target.closest('.hdar-choose-product-photo');
            if(!button||!window.wp||!wp.media)return;
            event.preventDefault();
            var input=button.closest('form').querySelector('.hdar-own-product-photo-id');
            var frame=wp.media({title:'Eigenes Produktfoto auswählen',button:{text:'Übernehmen'},multiple:false,library:{type:'image'}});
            frame.on('select',function(){
              var selected=frame.state().get('selection').first();
              if(selected)input.value=selected.get('id');
            });
            frame.open();
          });
          </script>
        </div>
        <?php
    }
}
