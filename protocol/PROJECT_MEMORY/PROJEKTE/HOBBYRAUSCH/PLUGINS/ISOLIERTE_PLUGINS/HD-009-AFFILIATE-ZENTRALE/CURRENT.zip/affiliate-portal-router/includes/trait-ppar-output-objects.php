<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * V4.0.0 – verbindendes Datenmodell zwischen Partner, Creative und Ausgabe.
 *
 * Grundregeln:
 * - Ein Output-Objekt gehört immer zu genau einem Creative und einem Portal.
 * - Bannerkampagne und HivePress-Listing sind getrennte Ausgabetypen.
 * - Der originale Creative-Trackinglink wird unverändert verwendet.
 * - Ein manuelles Creative-Veto ist dauerhaft vorrangig.
 * - Andere Portale werden über ein versionsgebundenes Adapterregister angebunden;
 *   unbekannte oder nicht verfügbare Adapter bleiben fail-closed.
 */
trait PPAR_Output_Objects_Trait {
    private $output_creative_row_cache = array();

    private function output_request_local_read_cache_allowed() {
        if ((function_exists('is_admin') && is_admin())
            || (defined('DOING_CRON') && DOING_CRON)
            || (defined('REST_REQUEST') && REST_REQUEST)
            || (defined('WP_CLI') && WP_CLI)
            || (function_exists('wp_doing_ajax') && wp_doing_ajax())) {
            return false;
        }
        return true;
    }

    

    private function output_objects_table() {
        global $wpdb;
        return $wpdb->base_prefix . 'ppar_output_objects';
    }

    private function output_portal_decisions_table() {
        global $wpdb;
        return $wpdb->base_prefix . 'ppar_creative_portal_decisions';
    }

    public function maybe_install_output_objects_schema() {
        $installed = (string) get_option(self::OPTION_OUTPUT_SCHEMA_VERSION, '0');
        if ($installed === self::OUTPUT_SCHEMA_VERSION) {
            return;
        }
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        global $wpdb;
        $table = $this->output_objects_table();
        $decisions_table = $this->output_portal_decisions_table();
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            object_key char(64) NOT NULL,
            portal_key varchar(191) NOT NULL,
            portal_adapter varchar(60) NOT NULL DEFAULT 'wordpress_local',
            creative_identity_hash char(64) NOT NULL,
            provider varchar(60) NOT NULL,
            partner_external_id varchar(191) NOT NULL DEFAULT '',
            output_type varchar(40) NOT NULL,
            target_type varchar(40) NOT NULL DEFAULT '',
            target_key varchar(191) NOT NULL DEFAULT '',
            target_label text NOT NULL,
            slot_id varchar(100) NOT NULL DEFAULT '',
            status varchar(40) NOT NULL DEFAULT 'review',
            confidence int(10) unsigned NOT NULL DEFAULT 0,
            decision_source varchar(60) NOT NULL DEFAULT '',
            decision_reason longtext NULL,
            campaign_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
            listing_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
            tracking_url text NOT NULL,
            image_url text NOT NULL,
            image_width int(10) unsigned NOT NULL DEFAULT 0,
            image_height int(10) unsigned NOT NULL DEFAULT 0,
            image_hash char(64) NOT NULL DEFAULT '',
            source_fingerprint char(64) NOT NULL DEFAULT '',
            payload longtext NULL,
            last_verified bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at bigint(20) unsigned NOT NULL DEFAULT 0,
            updated_at bigint(20) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY object_key (object_key),
            KEY portal_status (portal_key(100), status),
            KEY creative_output (creative_identity_hash, output_type),
            KEY partner_output (provider(20), partner_external_id(100), output_type)
        ) {$charset};");
        dbDelta("CREATE TABLE {$decisions_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            portal_key varchar(191) NOT NULL,
            creative_identity_hash char(64) NOT NULL,
            manual_status varchar(30) NOT NULL DEFAULT 'automatic',
            reason text NOT NULL,
            created_at bigint(20) unsigned NOT NULL DEFAULT 0,
            updated_at bigint(20) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY portal_creative (portal_key(120), creative_identity_hash),
            KEY portal_status (portal_key(120), manual_status)
        ) {$charset};");
        $this->output_migrate_legacy_scope_decisions($installed);
        update_option(self::OPTION_OUTPUT_SCHEMA_VERSION, self::OUTPUT_SCHEMA_VERSION, false);
        $this->output_objects_migrate_legacy_listing_state();
    }

    private function output_migrate_legacy_scope_decisions($previous_version) {
        if (version_compare((string) $previous_version, '1.1', '>=')) {
            return;
        }
        if (!method_exists($this, 'creative_library_table')) {
            return;
        }
        global $wpdb;
        $creative_table = $this->creative_library_table();
        $rows = $wpdb->get_results("SELECT identity_hash, content_scope, review_status FROM {$creative_table} WHERE identity_hash<>'' AND (content_scope<>'' OR review_status IN ('approved','rejected'))", ARRAY_A);
        foreach ((array) $rows as $row) {
            $scope = sanitize_key((string) ($row['content_scope'] ?? ''));
            $review = sanitize_key((string) ($row['review_status'] ?? ''));
            $status = ($scope === 'unclear' && $review !== 'rejected') ? 'review' : 'veto';
            $this->output_set_portal_decision($this->output_local_portal_key(), (string) ($row['identity_hash'] ?? ''), $status, 'Historische projektfremde Bewertung nicht automatisch für Hobby Depot freigegeben.');
        }
    }

    private function output_portal_decision($portal_key, $identity_hash) {
        global $wpdb;
        $portal_key = sanitize_key((string) $portal_key);
        $identity_hash = strtolower(sanitize_text_field((string) $identity_hash));
        if ($portal_key === '' || !preg_match('/^[a-f0-9]{64}$/', $identity_hash)) {
            return array('manual_status'=>'automatic','reason'=>'','payload'=>array(),'user_id'=>0,'updated_at'=>0);
        }
        if (method_exists($this, 'control_get_decision')) {
            $control = $this->control_get_decision($portal_key, 'creative', $identity_hash);
            if (!empty($control['exists'])) {
                return array(
                    'manual_status'=>(string) ($control['status'] ?? 'automatic'),
                    'reason'=>(string) ($control['reason'] ?? ''),
                    'payload'=>is_array($control['payload'] ?? null) ? $control['payload'] : array(),
                    'user_id'=>absint($control['user_id'] ?? 0),
                    'updated_at'=>absint($control['updated_at'] ?? 0),
                );
            }
        }
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->output_portal_decisions_table()} WHERE portal_key=%s AND creative_identity_hash=%s", $portal_key, $identity_hash), ARRAY_A);
        if (!is_array($row)) {
            return array('manual_status'=>'automatic','reason'=>'','payload'=>array(),'user_id'=>0,'updated_at'=>0);
        }
        return array_merge($row, array('payload'=>array(),'user_id'=>0));
    }

    public function output_set_portal_decision($portal_key, $identity_hash, $status, $reason = '', $payload = array()) {
        global $wpdb;
        $portal_key = sanitize_key((string) $portal_key);
        $identity_hash = strtolower(sanitize_text_field((string) $identity_hash));
        $status = sanitize_key((string) $status);
        if ($portal_key === '' || !preg_match('/^[a-f0-9]{64}$/', $identity_hash) || !in_array($status, array('automatic','approved','review','veto'), true)) {
            return new WP_Error('portal_decision_invalid', 'Portalentscheidung ist ungültig.');
        }
        $control_id = 0;
        if (method_exists($this, 'control_set_decision')) {
            $control = $this->control_set_decision($portal_key, 'creative', $identity_hash, $status, (string) $reason, is_array($payload) ? $payload : array(), 'creative_decision');
            if (is_wp_error($control)) {
                return $control;
            }
            $control_id = absint($control);
        }
        // Kompatibilitätskopie für ältere Diagnosen und sichere Rückmigration.
        $table = $this->output_portal_decisions_table();
        $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM {$table} WHERE portal_key=%s AND creative_identity_hash=%s", $portal_key, $identity_hash), ARRAY_A);
        $data = array('portal_key'=>$portal_key,'creative_identity_hash'=>$identity_hash,'manual_status'=>$status,'reason'=>sanitize_text_field((string) $reason),'updated_at'=>time());
        if ($existing) {
            $wpdb->update($table, $data, array('id'=>absint($existing['id'])));
            return $control_id > 0 ? $control_id : absint($existing['id']);
        }
        $data['created_at'] = time();
        $wpdb->insert($table, $data);
        $legacy_id = $wpdb->insert_id ? absint($wpdb->insert_id) : 0;
        return $control_id > 0 ? $control_id : ($legacy_id > 0 ? $legacy_id : new WP_Error('portal_decision_save_failed', 'Portalentscheidung konnte nicht gespeichert werden.'));
    }

    private function output_objects_migrate_legacy_listing_state() {
        if (!function_exists('get_posts') || !function_exists('update_post_meta')) {
            return;
        }
        $legacy = get_posts(array(
            'post_type' => 'hp_listing',
            'post_status' => array('draft','pending','publish','private'),
            'meta_key' => '_ppar_partner_identity',
            'posts_per_page' => 200,
            'fields' => 'ids',
        ));
        foreach ((array) $legacy as $post_id) {
            $post_id = absint($post_id);
            if ($post_id <= 0) {
                continue;
            }
            $creative_hash = (string) get_post_meta($post_id, '_ppar_creative_identity_hash', true);
            if ($creative_hash !== '') {
                continue;
            }
            update_post_meta($post_id, '_ppar_legacy_listing_blocked', 1);
            update_post_meta($post_id, '_ppar_legacy_listing_reason', 'V3.4.0-Listing ohne verknüpftes Creative; nicht automatisch freigeben.');
            $post = get_post($post_id);
            if ($post && (string) $post->post_status === 'publish' && function_exists('wp_update_post')) {
                wp_update_post(array('ID'=>$post_id, 'post_status'=>'draft'));
            }
        }
    }

    private function output_local_portal_key() {
        $host = strtolower((string) wp_parse_url(home_url('/'), PHP_URL_HOST));
        if ($host === '') {
            $host = 'local';
        }
        $blog_id = function_exists('get_current_blog_id') ? absint(get_current_blog_id()) : 1;
        return sanitize_key('wp-' . $blog_id . '-' . str_replace('.', '-', $host));
    }

    /**
     * Adaptervertrag für weitere Portale.
     *
     * Ein Adapterarray muss enthalten:
     * key, label, adapter, enabled und wahlweise blog_id oder callbacks.
     * Externe Adapter werden ausschließlich über den Filter registriert; ohne
     * vollständige callbacks werden sie als BLOCKED geführt und nie beschrieben.
     */
    public function output_portal_registry() {
        $portals = array();
        $local_key = $this->output_local_portal_key();
        $domain_terms = array();
        if (class_exists('HDAR_Hobby_Depot_Source')) {
            $hdar_catalog = HDAR_Hobby_Depot_Source::catalog();
            if (!is_wp_error($hdar_catalog)) {
                foreach ((array)($hdar_catalog['private_bucket_profiles'] ?? array()) as $profile) {
                    $label = sanitize_text_field((string)($profile['label'] ?? ''));
                    if ($label !== '') { $domain_terms[] = $label; }
                }
            }
        }
        $local_profile = array(
            'domain_key' => 'hobby_depot',
            'domain_terms' => array_values(array_unique($domain_terms)),
            'negative_terms' => array(),
            'output_types' => array('portal_banner','product_campaign','hivepress_listing'),
            'listing_target_types' => array('hp_listing_category'),
            'banner_target_types' => array('page','category','hp_listing_category'),
            'product_target_types' => array('page','category'),
        );
        $local_profile = apply_filters('ppar_affiliate_local_portal_profile', $local_profile, $local_key, self::PORTAL_ADAPTER_VERSION);
        $local_profile = is_array($local_profile) ? $local_profile : array();
        $portals[$local_key] = array_merge(array(
            'key' => $local_key,
            'label' => get_bloginfo('name') ?: $local_key,
            'site_url' => home_url('/'),
            'adapter' => 'wordpress_local',
            'adapter_version' => self::PORTAL_ADAPTER_VERSION,
            'enabled' => true,
            'local' => true,
            'blog_id' => function_exists('get_current_blog_id') ? absint(get_current_blog_id()) : 1,
        ), $local_profile);

        if (function_exists('is_multisite') && is_multisite() && function_exists('get_sites')) {
            foreach ((array) get_sites(array('number'=>200, 'deleted'=>0, 'spam'=>0, 'archived'=>0)) as $site) {
                $blog_id = absint($site->blog_id ?? 0);
                if ($blog_id <= 0 || $blog_id === absint($portals[$local_key]['blog_id'])) {
                    continue;
                }
                $key = sanitize_key('wp-' . $blog_id);
                $portals[$key] = array(
                    'key'=>$key,
                    'label'=>'WordPress-Site ' . $blog_id,
                    'site_url'=>function_exists('get_home_url') ? get_home_url($blog_id, '/') : '',
                    'adapter'=>'wordpress_multisite',
                    'adapter_version'=>self::PORTAL_ADAPTER_VERSION,
                    'enabled'=>false,
                    'local'=>false,
                    'blog_id'=>$blog_id,
                );
            }
        }

        $stored = get_option(self::OPTION_PORTAL_REGISTRY, array());
        $stored = is_array($stored) ? $stored : array();
        foreach ($stored as $key => $settings) {
            $key = sanitize_key((string) $key);
            if ($key === '' || !isset($portals[$key]) || !is_array($settings)) {
                continue;
            }
            $portals[$key]['enabled'] = !empty($settings['enabled']);
            foreach (array('domain_key') as $field) {
                if (isset($settings[$field])) {
                    $portals[$key][$field] = sanitize_key((string) $settings[$field]);
                }
            }
            foreach (array('domain_terms','negative_terms','output_types','listing_target_types','banner_target_types','product_target_types') as $field) {
                if (isset($settings[$field]) && is_array($settings[$field])) {
                    $portals[$key][$field] = array_values(array_unique(array_filter(array_map($field === 'domain_terms' || $field === 'negative_terms' ? 'sanitize_text_field' : 'sanitize_key', $settings[$field]))));
                }
            }
        }

        $filtered = apply_filters('ppar_affiliate_portal_registry', $portals, self::PORTAL_ADAPTER_VERSION);
        if (!is_array($filtered)) {
            return $portals;
        }
        $safe = array();
        foreach ($filtered as $key => $portal) {
            if (!is_array($portal)) {
                continue;
            }
            $portal_key = sanitize_key((string) ($portal['key'] ?? $key));
            $adapter = sanitize_key((string) ($portal['adapter'] ?? ''));
            $version = (string) ($portal['adapter_version'] ?? '');
            if ($portal_key === '' || $adapter === '' || $version !== self::PORTAL_ADAPTER_VERSION) {
                continue;
            }
            $portal['key'] = $portal_key;
            $portal['adapter'] = $adapter;
            $portal['label'] = sanitize_text_field((string) ($portal['label'] ?? $portal_key));
            $portal['enabled'] = !empty($portal['enabled']);
            $portal['domain_key'] = sanitize_key((string) ($portal['domain_key'] ?? ''));
            foreach (array('domain_terms','negative_terms') as $field) {
                $portal[$field] = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array) ($portal[$field] ?? array())))));
            }
            foreach (array('output_types','listing_target_types','banner_target_types','product_target_types') as $field) {
                $portal[$field] = array_values(array_unique(array_filter(array_map('sanitize_key', (array) ($portal[$field] ?? array())))));
            }
            $safe[$portal_key] = $portal;
        }
        return $safe;
    }

    private function output_portal_by_key($portal_key, $allow_disabled = false) {
        $portal_key = sanitize_key((string) $portal_key);
        $registry = $this->output_portal_registry();
        if (!is_array($registry[$portal_key] ?? null)) {
            return new WP_Error('portal_not_registered', 'Portaladapter ist nicht registriert.');
        }
        $portal = $registry[$portal_key];
        if (!$allow_disabled && empty($portal['enabled'])) {
            return new WP_Error('portal_disabled', 'Portal ist deaktiviert; keine Vorbereitung oder Freigabe zulässig.');
        }
        return $portal;
    }

    private function output_with_portal($portal, $callback) {
        if (!is_array($portal) || !is_callable($callback)) {
            return new WP_Error('portal_adapter_invalid', 'Portaladapter ist unvollständig.');
        }
        $adapter = sanitize_key((string) ($portal['adapter'] ?? ''));
        if ($adapter === 'wordpress_local') {
            return call_user_func($callback, $portal);
        }
        if ($adapter === 'wordpress_multisite') {
            $blog_id = absint($portal['blog_id'] ?? 0);
            if ($blog_id <= 0 || !function_exists('switch_to_blog') || !function_exists('restore_current_blog')) {
                return new WP_Error('portal_multisite_unavailable', 'Multisite-Portal ist nicht verfügbar.');
            }
            if (function_exists('get_current_blog_id') && absint(get_current_blog_id()) === $blog_id) {
                return call_user_func($callback, $portal);
            }
            switch_to_blog($blog_id);
            try {
                return call_user_func($callback, $portal);
            } finally {
                restore_current_blog();
            }
        }
        $callbacks = is_array($portal['callbacks'] ?? null) ? $portal['callbacks'] : array();
        if (empty($callbacks['run']) || !is_callable($callbacks['run'])) {
            return new WP_Error('portal_remote_adapter_missing', 'Externer Portaladapter ist nicht vollständig registriert.');
        }
        return call_user_func($callbacks['run'], $callback, $portal);
    }
    private function output_validate_portal_profile($portal) {
        if (!is_array($portal) || empty($portal['key']) || empty($portal['adapter']) || (string) ($portal['adapter_version'] ?? '') !== self::PORTAL_ADAPTER_VERSION) {
            return new WP_Error('portal_profile_invalid', 'Portalprofil oder Adapterversion ist ungültig.');
        }
        $domain_terms = array_values(array_filter(array_map('sanitize_text_field', (array) ($portal['domain_terms'] ?? array()))));
        if (!$domain_terms) {
            return new WP_Error('portal_domain_profile_missing', 'Für dieses Portal fehlt ein bestätigtes Fachprofil. Automatische Zuordnung bleibt gesperrt.');
        }
        $output_types = array_values(array_intersect(array_map('sanitize_key', (array) ($portal['output_types'] ?? array())), array('portal_banner','product_campaign','hivepress_listing','portal_listing')));
        if (!$output_types) {
            return new WP_Error('portal_output_types_missing', 'Für dieses Portal ist kein bestätigter Ausgabetyp registriert.');
        }
        return true;
    }
    private function output_term_path($term, $taxonomy, $by_id) {
        $parts = array(sanitize_text_field((string) ($term->name ?? '')));
        $parent = absint($term->parent ?? 0);
        $guard = 0;
        while ($parent > 0 && isset($by_id[$parent]) && $guard < 30) {
            array_unshift($parts, sanitize_text_field((string) ($by_id[$parent]->name ?? '')));
            $parent = absint($by_id[$parent]->parent ?? 0);
            $guard++;
        }
        return implode(' > ', array_filter($parts));
    }


    /**
     * V6.72.179 – eine Zielidentität über alle Schichten.
     *
     * Ausgabeobjekte verwenden historisch type:<ID>, Kampagnen/Automation
     * type:<slug>. Beide Formen bezeichnen dasselbe reale WordPress-Ziel und
     * dürfen an Schichtgrenzen niemals direkt als verschiedene Ziele behandelt
     * werden. Die bestehende Speicherung bleibt kompatibel; aufgelöst wird nur
     * beim Vergleich.
     */
    private function output_target_identity_keys($target) {
        if (!is_array($target)) { return array(); }
        $keys = array();
        $stored = sanitize_text_field((string) ($target['key'] ?? ''));
        if ($stored !== '') { $keys[] = $stored; }
        $canonical = $this->output_campaign_target_key($target);
        if ($canonical !== '') { $keys[] = $canonical; }
        $type = sanitize_key((string) ($target['type'] ?? ''));
        $id = absint($target['id'] ?? 0);
        if ($type !== '' && $id > 0) { $keys[] = $type . ':' . $id; }
        return array_values(array_unique(array_filter(array_map('sanitize_text_field', $keys))));
    }

    private function output_target_key_matches($target, $key) {
        $key = sanitize_text_field((string) $key);
        if ($key === '') { return false; }
        foreach ($this->output_target_identity_keys($target) as $candidate) {
            if (hash_equals((string) $candidate, $key)) { return true; }
        }
        return false;
    }

    /**
     * KISS-Bannerpfad: ein Banner wird auf das tiefste Ziel gemappt.
     * Fuer die Ausspielung wird genau dieses Ziel plus seine echten Eltern
     * desselben Zieltyps gespeichert. Keine Frontend-Baumabfrage.
     */
    private function output_banner_target_path_keys($target,$targets,$portal_key='') {
        if(!is_array($target) || !is_array($targets)){return array();}
        $type=sanitize_key((string)($target['type']??''));
        $label=html_entity_decode((string)($target['label']??''),ENT_QUOTES,'UTF-8');
        $parts=array_values(array_filter(array_map(array($this,'output_text'),preg_split('/\s+>\s+/',$label)),'strlen'));
        $ranked=array();

        foreach($targets as $candidate){
            if(!is_array($candidate) || sanitize_key((string)($candidate['type']??''))!==$type){continue;}
            $key=$this->output_campaign_target_key($candidate);
            if($key===''){continue;}
            if($portal_key!=='' && method_exists($this,'control_target_gate')
                && is_wp_error($this->control_target_gate($portal_key,(string)($candidate['key']??'')))){continue;}

            $candidate_label=html_entity_decode((string)($candidate['label']??''),ENT_QUOTES,'UTF-8');
            $candidate_parts=array_values(array_filter(array_map(array($this,'output_text'),preg_split('/\s+>\s+/',$candidate_label)),'strlen'));
            if(!$parts || !$candidate_parts || count($candidate_parts)>count($parts)){continue;}
            if(array_slice($parts,0,count($candidate_parts))!==$candidate_parts){continue;}
            $ranked[]=array('key'=>$key,'depth'=>absint($candidate['depth']??count($candidate_parts)));
        }

        usort($ranked,static function($a,$b){return (int)$b['depth']<=>(int)$a['depth'];});
        $out=array();
        foreach($ranked as $row){$out[(string)$row['key']]=(string)$row['key'];}
        $direct=$this->output_campaign_target_key($target);
        if($direct!=='' && !isset($out[$direct])){$out=array($direct=>$direct)+$out;}
        return array_values($out);
    }

    /**
     * Resolve a target key only when it maps to exactly one real target.
     * Exact stored keys win. Slug aliases are accepted only when unique across
     * the current real target set, so hierarchical duplicate slugs fail closed.
     */
    private function output_resolve_target_key($targets, $key) {
        $key = sanitize_text_field((string) $key);
        if ($key === '' || !is_array($targets)) { return null; }
        $exact = array();
        $aliases = array();
        foreach ($targets as $target) {
            if (!is_array($target)) { continue; }
            $stored = sanitize_text_field((string) ($target['key'] ?? ''));
            if ($stored !== '' && hash_equals($stored, $key)) {
                $exact[] = $target;
                continue;
            }
            if ($this->output_target_key_matches($target, $key)) {
                $aliases[] = $target;
            }
        }
        if (count($exact) === 1) { return $exact[0]; }
        if (count($exact) > 1) { return null; }
        return count($aliases) === 1 ? $aliases[0] : null;
    }

    /** Echte öffentliche Ziel-URL nur bei Bedarf und request-lokal auflösen. */
    private function output_target_public_url($target) {
        if (!is_array($target)) { return ''; }
        static $cache = array();
        $type = sanitize_key((string) ($target['type'] ?? ''));
        $id = absint($target['id'] ?? 0);
        if ($type === '' || $id <= 0) { return ''; }
        $cache_key = $type . ':' . $id;
        if (array_key_exists($cache_key, $cache)) { return (string) $cache[$cache_key]; }
        $url = '';
        if (in_array($type, array('page','post','uge_term'), true) && function_exists('get_permalink')) {
            $url = (string) get_permalink($id);
        } elseif (in_array($type, array('category','hp_listing_category','uge_group'), true)
            && function_exists('get_term') && function_exists('get_term_link')) {
            $term = get_term($id, $type);
            if ($term && !is_wp_error($term)) {
                $resolved = get_term_link($term, $type);
                if (!is_wp_error($resolved)) { $url = (string) $resolved; }
            }
        }
        $cache[$cache_key] = esc_url_raw($url);
        return (string) $cache[$cache_key];
    }

    private function output_target_public_url_path($target) {
        $url = $this->output_target_public_url($target);
        if ($url === '') { return ''; }
        $path = wp_parse_url($url, PHP_URL_PATH);
        if (!is_string($path) || $path === '') { return ''; }
        $path = rawurldecode($path);
        return '/' . trim(preg_replace('~/+~', '/', $path), '/') . '/';
    }

    private function output_collect_local_targets() {
        $targets = array();
        if (function_exists('get_pages')) {
            foreach ((array) get_pages(array('post_status'=>'publish', 'sort_column'=>'menu_order,post_title')) as $page) {
                $id = absint($page->ID ?? 0);
                if ($id <= 0) { continue; }
                $parts = array(sanitize_text_field((string) ($page->post_title ?? '')));
                $parent = absint($page->post_parent ?? 0);
                $guard = 0;
                while ($parent > 0 && $guard < 30) {
                    $ancestor = get_post($parent);
                    if (!$ancestor) { break; }
                    array_unshift($parts, sanitize_text_field((string) ($ancestor->post_title ?? '')));
                    $parent = absint($ancestor->post_parent ?? 0);
                    $guard++;
                }
                $content = (string) ($page->post_content ?? '');
                $context = '';
                if (function_exists('has_shortcode') && has_shortcode($content, 'affiliate_portal_journal')) {
                    $context = 'journal';
                } elseif ($this->design_bridge_class() !== '') {
                    $context = sanitize_key((string) $this->design_bridge_call('affiliate_page_type', array($id), ''));
                }
                if ($context === '') { $context = 'page_unclassified'; }
                $targets[] = array(
                    'type'=>'page','key'=>'page:' . $id,'id'=>$id,
                    'slug'=>sanitize_key((string) ($page->post_name ?? '')),
                    'label'=>implode(' > ', array_filter($parts)),
                    'description'=>sanitize_text_field(wp_strip_all_tags((string) (($page->post_excerpt ?? '') . ' ' . $content))),
                    'depth'=>count(array_filter($parts)),
                    'context'=>$context,
                );
            }
        }
        foreach (array('post'=>'classic_post','uge_term'=>'glossary_single') as $post_type => $context) {
            if (!function_exists('post_type_exists') || !post_type_exists($post_type) || !function_exists('get_posts')) { continue; }
            $posts = get_posts(array('post_type'=>$post_type,'post_status'=>'publish','posts_per_page'=>-1,'orderby'=>'ID','order'=>'ASC'));
            foreach ((array) $posts as $post) {
                $id = absint($post->ID ?? 0);
                if ($id <= 0) { continue; }
                $targets[] = array(
                    'type'=>$post_type,'key'=>$post_type . ':' . $id,'id'=>$id,
                    'slug'=>sanitize_key((string) ($post->post_name ?? '')),
                    'label'=>sanitize_text_field((string) ($post->post_title ?? '')),
                    'description'=>sanitize_text_field(wp_strip_all_tags((string) (($post->post_excerpt ?? '') . ' ' . ($post->post_content ?? '')))),
                    'depth'=>1,'context'=>$context,
                );
            }
        }
        foreach (array('category','hp_listing_category','uge_group') as $taxonomy) {
            if (!function_exists('taxonomy_exists') || !taxonomy_exists($taxonomy) || !function_exists('get_terms')) { continue; }
            $terms = get_terms(array('taxonomy'=>$taxonomy, 'hide_empty'=>false));
            if (is_wp_error($terms) || !is_array($terms)) { continue; }
            $by_id = array(); $children = array();
            foreach ($terms as $term) {
                if (is_object($term) && !empty($term->term_id)) {
                    $id = absint($term->term_id); $by_id[$id] = $term;
                    $parent = absint($term->parent ?? 0); if ($parent > 0) { $children[$parent] = true; }
                }
            }
            foreach ($by_id as $term) {
                $id = absint($term->term_id ?? 0);
                $path = $this->output_term_path($term, $taxonomy, $by_id);
                if ($taxonomy === 'hp_listing_category') {
                    $context = 'hivepress_category';
                } elseif ($taxonomy === 'uge_group') {
                    $context = 'glossary_overview';
                } elseif ($taxonomy === 'category' && sanitize_key((string)($term->slug ?? '')) === 'glossar') {
                    $context = 'glossary_overview';
                } else {
                    $context = empty($children[$id]) ? 'leaf_category' : 'category_nonleaf';
                }
                $targets[] = array(
                    'type'=>$taxonomy,'key'=>$taxonomy . ':' . $id,'id'=>$id,
                    'slug'=>sanitize_key((string) ($term->slug ?? '')),
                    'label'=>$path,
                    'description'=>sanitize_text_field(wp_strip_all_tags((string) ($term->description ?? ''))),
                    'depth'=>substr_count($path, ' > ') + 1,
                    'context'=>$context,
                );
            }
        }
        return $targets;
    }
    public function output_portal_targets($portal) {
        // V6.72.50 TIMEOUT-Rootfix: Der lokale Zielkatalog ist innerhalb eines
        // Requests unveraenderlich. Vorher wurde er fuer jedes angehakte Creative
        // erneut komplett aus Seiten, Beitraegen, Glossar und Taxonomien
        // aufgebaut. Das vervielfachte die Laufzeit der KISS-Aktion und konnte
        // einen Gateway Timeout ausloesen. Cache gilt bewusst nur pro Request.
        static $local_request_cache = array();
        return $this->output_with_portal($portal, function($active_portal) use (&$local_request_cache) {
            $adapter = sanitize_key((string) ($active_portal['adapter'] ?? ''));
            if (in_array($adapter, array('wordpress_local','wordpress_multisite'), true)) {
                $cache_key = sanitize_key((string) ($active_portal['key'] ?? '')) . ':' . $adapter . ':' . absint($active_portal['blog_id'] ?? 0);
                if (array_key_exists($cache_key, $local_request_cache)) {
                    return $local_request_cache[$cache_key];
                }
                $local_request_cache[$cache_key] = $this->output_collect_local_targets();
                return $local_request_cache[$cache_key];
            }
            $callbacks = is_array($active_portal['callbacks'] ?? null) ? $active_portal['callbacks'] : array();
            if (empty($callbacks['targets']) || !is_callable($callbacks['targets'])) {
                return new WP_Error('portal_targets_missing', 'Portaladapter liefert keinen Zielkatalog.');
            }
            $targets = call_user_func($callbacks['targets'], $active_portal);
            return is_array($targets) ? $targets : new WP_Error('portal_targets_invalid', 'Portaladapter lieferte einen ungültigen Zielkatalog.');
        });
    }

    /**
     * Festgeschriebene aktive Slotmatrix aus dem getrennten Design–Affiliate-
     * Schnittstellenvertrag Hobby Depot / Affiliate-Vertrag 1.0.
     * Das Design wird nicht gelesen oder verändert; Vertragsabweichungen bleiben
     * fail-closed. Andere Portale liefern ihre Matrix über den bestehenden Filter.
     */
    public function output_slot_matrix($portal) {
        $adapter = sanitize_key((string) ($portal['adapter'] ?? ''));
        if (in_array($adapter, array('wordpress_local','wordpress_multisite'), true)) {
            $matrix = $this->output_with_portal($portal, function($active_portal) {
                $candidate = array();
                if ($this->design_bridge_class() !== '') {
                    $contract = (string) $this->design_bridge_call(
                        'affiliate_contract_version',
                        array(),
                        (string) $this->design_bridge_constant('AFFILIATE_CONTRACT', '')
                    );
                    $profile = sanitize_key((string) $this->design_bridge_call('design_profile', array(), ''));
                    $profile_contract = (string) $this->design_bridge_call('design_profile_contract_version', array(), '');
                    if ($contract === self::CONTRACT_VERSION && $profile === 'hobby_depot' && $profile_contract === '1.0') {
                        $candidate = array(
                            'start_after_topics'=>array('creative_type'=>'banner','ratio_min'=>5.00,'ratio_max'=>12.00,'min_width'=>800,'min_height'=>60,'crop'=>'contain','target_types'=>array('page'),'target_contexts'=>array('start'),'upscale_max'=>1.10,'min_fill'=>0.90),
                            'hub_grid_card'=>array('creative_type'=>'banner','ratio_min'=>0.80,'ratio_max'=>2.40,'min_width'=>240,'min_height'=>110,'crop'=>'cover','target_types'=>array('page'),'target_contexts'=>array('hub1','hub2')),
                            'hub_after_cards'=>$this->category_large_banner_rule('hub_after_cards'),
                            'product_after_category_tiles'=>$this->category_large_banner_rule('product_after_category_tiles'),
                            'journal_banner'=>array('creative_type'=>'banner','ratio_min'=>5.00,'ratio_max'=>12.00,'min_width'=>800,'min_height'=>60,'crop'=>'contain','target_types'=>array('page'),'target_contexts'=>array('journal'),'upscale_max'=>1.10,'min_fill'=>0.90),
                            'anzeigenmarkt_top_banner'=>array('creative_type'=>'banner','ratio_min'=>5.00,'ratio_max'=>12.00,'min_width'=>800,'min_height'=>60,'crop'=>'contain','target_types'=>array('page'),'target_contexts'=>array('anzeigenmarkt'),'upscale_max'=>1.10,'min_fill'=>0.90),
                            'anzeigenmarkt_category_banner'=>array('creative_type'=>'banner','ratio_min'=>5.00,'ratio_max'=>12.00,'min_width'=>800,'min_height'=>60,'crop'=>'contain','target_types'=>array('hp_listing_category'),'target_contexts'=>array('hivepress_category'),'upscale_max'=>1.10,'min_fill'=>0.90),
                            // Affiliate-Werbeplatzregister 2026-09-17: dieselben Regeln sind
                            // Quelle fuer automatische Zuordnung UND Backendfilter.
                            'glossary_single_desktop_banner'=>array('creative_type'=>'banner','ratio_min'=>0.50,'ratio_max'=>1.50,'min_width'=>310,'min_height'=>1,'crop'=>'contain','target_types'=>array('page','category','uge_term','uge_group'),'target_contexts'=>array(),'render_context'=>'glossary_single','upscale_max'=>1.10,'min_fill'=>0.60,'device'=>'desktop'),
                            'glossary_single_mobile_banner'=>array('creative_type'=>'banner','ratio_min'=>2.50,'ratio_max'=>12.00,'min_width'=>300,'min_height'=>1,'crop'=>'contain','target_types'=>array('page','category','uge_term','uge_group'),'target_contexts'=>array(),'render_context'=>'glossary_single','upscale_max'=>1.10,'min_fill'=>0.60,'device'=>'mobile'),
                            'post_inline_banner'=>array('creative_type'=>'banner','ratio_min'=>5.00,'ratio_max'=>12.00,'min_width'=>600,'min_height'=>60,'crop'=>'contain','target_types'=>array('post'),'target_contexts'=>array('classic_post'),'upscale_max'=>1.10,'min_fill'=>0.60),
                            'glossary_overview_banner'=>array('creative_type'=>'banner','ratio_min'=>5.00,'ratio_max'=>12.00,'min_width'=>800,'min_height'=>60,'crop'=>'contain','target_types'=>array('category','uge_group','page'),'target_contexts'=>array('glossary_overview'),'upscale_max'=>1.10,'min_fill'=>0.90),
                            'hub_product_1'=>array('creative_type'=>'product','ratio_min'=>0.55,'ratio_max'=>2.00,'min_width'=>180,'min_height'=>180,'crop'=>'contain','target_types'=>array('page'),'target_contexts'=>array('hub1')),
                            'hub_product_2'=>array('creative_type'=>'product','ratio_min'=>0.55,'ratio_max'=>2.00,'min_width'=>180,'min_height'=>180,'crop'=>'contain','target_types'=>array('page'),'target_contexts'=>array('hub1')),
                            'hub_product_3'=>array('creative_type'=>'product','ratio_min'=>0.55,'ratio_max'=>2.00,'min_width'=>180,'min_height'=>180,'crop'=>'contain','target_types'=>array('page'),'target_contexts'=>array('hub1')),
                            'category_product_1'=>array('creative_type'=>'product','ratio_min'=>0.55,'ratio_max'=>2.00,'min_width'=>180,'min_height'=>180,'crop'=>'contain','target_types'=>array('page','category'),'target_contexts'=>array('hub2','category','leaf','leaf_category')),
                            'category_product_2'=>array('creative_type'=>'product','ratio_min'=>0.55,'ratio_max'=>2.00,'min_width'=>180,'min_height'=>180,'crop'=>'contain','target_types'=>array('page','category'),'target_contexts'=>array('hub2','category','leaf','leaf_category')),
                            'category_product_3'=>array('creative_type'=>'product','ratio_min'=>0.55,'ratio_max'=>2.00,'min_width'=>180,'min_height'=>180,'crop'=>'contain','target_types'=>array('page','category'),'target_contexts'=>array('hub2','category','leaf','leaf_category')),
                            'journal_product_1'=>array('creative_type'=>'product','ratio_min'=>0.55,'ratio_max'=>2.00,'min_width'=>180,'min_height'=>180,'crop'=>'contain','target_types'=>array('page'),'target_contexts'=>array('journal')),
                            'journal_product_2'=>array('creative_type'=>'product','ratio_min'=>0.55,'ratio_max'=>2.00,'min_width'=>180,'min_height'=>180,'crop'=>'contain','target_types'=>array('page'),'target_contexts'=>array('journal')),
                            'journal_product_3'=>array('creative_type'=>'product','ratio_min'=>0.55,'ratio_max'=>2.00,'min_width'=>180,'min_height'=>180,'crop'=>'contain','target_types'=>array('page'),'target_contexts'=>array('journal')),
                        );
                    }
                }
                $filtered = apply_filters('ppar_affiliate_slot_matrix', $candidate, $active_portal, self::PORTAL_ADAPTER_VERSION);
                return is_array($filtered) ? $filtered : array();
            });
            return is_wp_error($matrix) || !is_array($matrix) ? array() : $matrix;
        }
        $callbacks = is_array($portal['callbacks'] ?? null) ? $portal['callbacks'] : array();
        if (empty($callbacks['slots']) || !is_callable($callbacks['slots'])) { return array(); }
        $candidate = call_user_func($callbacks['slots'], $portal, self::PORTAL_ADAPTER_VERSION);
        return is_array($candidate) ? $candidate : array();
    }
    /**
     * V6.72.40 – kanonische technische Profile der im Affiliate-Werbeplatzregister
     * festgelegten Backend-Werbeplaetze. Produktive Ausgabe bleibt getrennt aktivierbar;
     * der Backendfilter liest die technischen Regeln jedoch nur von hier und erfindet
     * keine zweite Pixel-/Formatlogik.
     */
    public function output_werbeplatz_filter_profiles($portal) {
        $matrix = $this->output_slot_matrix($portal);
        $binding = array(
            'kategorien'=>array('label'=>'Kategorien','slots'=>array('hub_after_cards','product_after_category_tiles')),
            'glossarartikel'=>array('label'=>'Glossarartikel','slots'=>array('glossary_single_desktop_banner','glossary_single_mobile_banner')),
            'klassische_einzelbeitraege'=>array('label'=>'Klassische Einzelbeiträge','slots'=>array('post_inline_banner')),
            'startseite'=>array('label'=>'Startseite','slots'=>array('start_after_topics')),
            'glossar_uebersichten'=>array('label'=>'Glossar-Übersichten','slots'=>array('glossary_overview_banner')),
        );
        $profiles = array();
        foreach ($binding as $key => $definition) {
            $rules = array();
            foreach ((array) $definition['slots'] as $slot_id) {
                if (!empty($matrix[$slot_id]) && is_array($matrix[$slot_id])) {
                    $rules[$slot_id] = $matrix[$slot_id];
                }
            }
            // Fail closed: ein sichtbarer Werbeplatz existiert nur, wenn seine
            // echte Slotregel in derselben produktiven Matrix vorhanden ist.
            if ($rules) {
                $profiles[$key] = array('label'=>$definition['label'],'rules'=>$rules);
            }
        }
        return $profiles;
    }

    private function output_text($value) {
        $value = remove_accents(strtolower(wp_strip_all_tags((string) $value)));
        $value = str_replace(array('&','+','/'), ' ', $value);
        $value = preg_replace('/[^a-z0-9]+/', ' ', $value);
        return trim(preg_replace('/\s+/', ' ', (string) $value));
    }

    private function output_tokens($value) {
        $stop = array_flip(array('und','oder','mit','fuer','fur','von','der','die','das','ein','eine','im','in','am','auf','de','www','https','http','com','banner','angebot','partner'));
        $out = array();
        foreach (preg_split('/\s+/', $this->output_text($value)) as $token) {
            if (strlen($token) < 3 || isset($stop[$token])) {
                continue;
            }
            $out[$token] = true;
            // Kleine, sprachneutrale Normalisierung plus konservative deutsche
            // Flexionsvarianten. Dadurch werden z. B. "Versicherungen" und
            // "Versicherung" vergleichbar, ohne eine Branchenliste einzubauen.
            foreach (array('ungen','ung','ern','en','er','es','e','n','s') as $suffix) {
                if (strlen($token) >= 7 + strlen($suffix) && substr($token, -strlen($suffix)) === $suffix) {
                    $root = substr($token, 0, -strlen($suffix));
                    if (strlen($root) >= 5 && !isset($stop[$root])) {
                        $out[$root] = true;
                    }
                }
            }
        }
        return array_keys($out);
    }

    private function output_term_present($text, $term) {
        $term = $this->output_text($term);
        if ($term === '') {
            return false;
        }
        $text_tokens = $this->output_tokens($text);
        $term_tokens = $this->output_tokens($term);
        if (!$term_tokens) {
            $term_tokens = array($term);
        }
        foreach ($text_tokens as $text_token) {
            foreach ($term_tokens as $term_token) {
                if ($text_token === $term_token) {
                    return true;
                }
                if (strlen($term_token) >= 4 && strlen($text_token) >= 5 && (strpos($text_token, $term_token) !== false || strpos($term_token, $text_token) !== false)) {
                    return true;
                }
            }
        }
        return false;
    }

    private function output_partner_evidence($row) {
        $provider = sanitize_key((string) ($row['provider'] ?? ''));
        $external_id = preg_replace('/[^0-9A-Za-z._-]/', '', (string) ($row['partner_external_id'] ?? ''));
        $profile = method_exists($this, 'partner_profile_get') ? $this->partner_profile_get($provider, $external_id) : array();
        $profile = is_array($profile) ? $profile : array();
        if (empty($profile['enabled'])) {
            $profile['business_label'] = '';
            $profile['keywords'] = array();
        }
        $snapshots = method_exists($this, 'partner_intake_snapshots') ? $this->partner_intake_snapshots() : array();
        $snapshot = is_array($snapshots[$provider . ':' . $external_id] ?? null) ? $snapshots[$provider . ':' . $external_id] : array();
        $programme = is_array($snapshot['programme'] ?? null) ? $snapshot['programme'] : array();
        return array(
            'profile'=>$profile,
            'business_label'=>sanitize_text_field((string) ($profile['business_label'] ?? '')),
            'keywords'=>array_values(array_filter(array_map('sanitize_text_field', (array) ($profile['keywords'] ?? array())))),
            'primary_sector'=>sanitize_text_field((string) ($programme['primary_sector'] ?? $programme['primarySector'] ?? '')),
            'programme_description'=>sanitize_text_field(wp_strip_all_tags((string) ($programme['description'] ?? ''))),
            'domains'=>array_values(array_filter(array_map('sanitize_text_field', (array) ($programme['valid_domains'] ?? array())))),
        );
    }

    /**
     * V6.72.58 – Glossar-Werbeplatz: auch bei expliziter Chef-Freigabe bleibt
     * die thematische Bedeutung erhalten. Die Freigabe entscheidet, DASS das
     * Werbemittel am Glossar teilnehmen darf; dieser Helper entscheidet nur,
     * WELCHE reale uge_group als semantischer Materialisierungsanker benutzt
     * wird. Damit wird aus „Automatik verwenden“ kein zufaelliger erster
     * Glossar-Themenwelt-Anker.
     */
    private function output_glossary_scope_semantic_target($row, $targets, $specific_evidence = '', $partner = array()) {
        if (!is_array($row)) { return null; }
        $specific = $this->output_text((string) $specific_evidence);
        $partner = is_array($partner) ? $partner : array();
        $partner_text = implode(' ', array_filter(array(
            (string) ($row['partner_name'] ?? ''),
            (string) ($partner['business_label'] ?? ''),
            implode(' ', (array) ($partner['keywords'] ?? array())),
            (string) ($partner['primary_sector'] ?? ''),
            (string) ($partner['programme_description'] ?? ''),
            implode(' ', (array) ($partner['domains'] ?? array())),
        )));
        $evidence = trim($specific . ' ' . $this->output_text($partner_text));
        $evidence_tokens = array_values(array_diff($this->output_tokens($evidence), array('banner','anzeige')));
        if (!$evidence_tokens) { return null; }

        $ranked = array();
        foreach ((array) $targets as $target) {
            if (!is_array($target) || sanitize_key((string) ($target['type'] ?? '')) !== 'uge_group') { continue; }
            if (absint($target['id'] ?? 0) <= 0 || empty($target['key'])) { continue; }
            $target_text = implode(' ', array(
                (string) ($target['label'] ?? ''),
                (string) ($target['slug'] ?? ''),
                (string) ($target['description'] ?? ''),
            ));
            $target_tokens = $this->output_tokens($target_text);
            if (!$target_tokens) { continue; }
            $score = 0;
            $hits = array();
            foreach ($evidence_tokens as $et) {
                foreach ($target_tokens as $tt) {
                    if ($et === $tt) {
                        $score += 40; $hits[$tt] = true; continue;
                    }
                    if (strlen($et) >= 5 && strlen($tt) >= 5
                        && (strpos($et, $tt) !== false || strpos($tt, $et) !== false)) {
                        $score += 28; $hits[$tt] = true; continue;
                    }
                    // Deutscher Wortstamm-/Kompositumvergleich für fachliche Begriffe.
                    $et5 = substr($et, 0, 5); $tt5 = substr($tt, 0, 5);
                    if (($et5 !== '' && strpos($tt, $et5) !== false) || ($tt5 !== '' && strpos($et, $tt5) !== false)) {
                        $score += 18; $hits[$tt] = true;
                    }
                }
            }
            // Partnerprofil ist bewusst staerker als ein zufaelliger Creative-Titel.
            foreach ((array) ($partner['keywords'] ?? array()) as $keyword) {
                $kw = $this->output_text($keyword);
                if ($kw === '') { continue; }
                foreach ($target_tokens as $tt) {
                    if ($this->output_term_present($kw, $tt)) { $score += 35; $hits[$tt] = true; }
                }
            }
            if ($score > 0) {
                $ranked[] = array('target'=>$target,'score'=>$score,'hits'=>count($hits));
            }
        }
        if (!$ranked) { return null; }
        usort($ranked, static function($a,$b){
            $cmp=(int)$b['score']<=>(int)$a['score'];
            if($cmp!==0){return $cmp;}
            $cmp=(int)$b['hits']<=>(int)$a['hits'];
            if($cmp!==0){return $cmp;}
            return strnatcasecmp((string)($a['target']['label']??''),(string)($b['target']['label']??''));
        });
        $best=$ranked[0]; $second=$ranked[1]??null;
        // Breiter Themenbereich darf genutzt werden, aber nicht bei einem praktisch
        // unentschiedenen Treffer. Dann bleibt der allgemeine Fill-Fallback aktiv.
        if ((int)$best['score'] < 18) { return null; }
        if ($second && ((int)$best['score']-(int)$second['score']) < 10 && (int)$best['hits'] <= (int)$second['hits']) { return null; }
        $target=$best['target'];
        $target['_ppar_glossary_semantic_score']=(int)$best['score'];
        return $target;
    }

    /** KISS-Ziel-URL-Evidenz: nur echte/decodierte Zielseiten, nie Tracking-Fallback. */
    private function output_destination_semantic_text($row) {
        if (!is_array($row)) { return ''; }
        $payload=json_decode((string)($row['payload']??''),true);
        $payload=is_array($payload)?$payload:array();
        $destination_source=sanitize_key((string)($payload['_destination_source']??''));
        if (in_array($destination_source, array('tracking_fallback','tracking_checked'), true)) { return ''; }
        $url=trim((string)($row['destination_url']??''));
        if($url==='' && method_exists($this,'creative_library_destination_from_tracking')){
            $url=(string)$this->creative_library_destination_from_tracking((string)($row['tracking_url']??''));
        }
        if($url===''){return '';}
        for($i=0;$i<3;$i++){$d=rawurldecode(html_entity_decode($url,ENT_QUOTES,'UTF-8'));if($d===$url){break;}$url=$d;}
        $p=wp_parse_url($url); if(!is_array($p)){return '';}
        $host=preg_replace('/^www\./i','',(string)($p['host']??''));
        return $this->output_text(str_replace(array('-','_','&','=','.'),' ',trim($host.' '.(string)($p['path']??'').' '.(string)($p['query']??''))));
    }

    private function output_banner_destination_source($row) {
        $payload=json_decode((string)($row['payload']??''),true);
        $payload=is_array($payload)?$payload:array();
        $source=sanitize_key((string)($payload['_destination_source']??''));
        if (in_array($source,array('provider_explicit','decoded_tracking','resolved_redirect','tracking_fallback','tracking_checked','unknown'),true)) { return $source; }
        $destination=esc_url_raw((string)($row['destination_url']??''));
        $tracking=esc_url_raw((string)($row['tracking_url']??''));
        if ($destination!=='' && $destination!==$tracking) { return 'provider_explicit'; }
        return $destination!=='' ? 'tracking_fallback' : 'unknown';
    }

    private function output_banner_library_records($row) {
        $records=json_decode((string)($row['topic_targets']??''),true);
        if (!is_array($records)) { return array(); }
        if (isset($records['portal_key'])) { $records=array($records); }
        return array_values(array_filter($records,'is_array'));
    }

    private function output_banner_stored_destination_classification($row,$portal) {
        if (sanitize_key((string)($row['creative_type']??''))!=='banner') { return null; }
        $portal_key=sanitize_key((string)($portal['key']??''));
        if($portal_key===''){return null;}
        $portal_records=array_values(array_filter($this->output_banner_library_records($row),static function($candidate)use($portal_key){
            return is_array($candidate) && sanitize_key((string)($candidate['portal_key']??''))===$portal_key;
        }));
        if(!$portal_records){return null;}

        $record=$portal_records[0];
        $state=sanitize_key((string)($record['state']??''));
        $target_key=sanitize_text_field((string)($record['target_key']??''));
        if(!in_array($state,array('mapped','general'),true)||$target_key===''){return null;}
        $targets=$this->output_portal_targets($portal);
        if(is_wp_error($targets)){return $targets;}
        $target=$this->output_resolve_target_key($targets,$target_key);
        if(!is_array($target)){return null;}
        if(method_exists($this,'control_target_gate')){
            $gate=$this->control_target_gate($portal_key,(string)($target['key']??''));
            if(is_wp_error($gate)){return null;}
        }

        $stored_campaign_targets=array();
        $record_source=sanitize_key((string)($record['source']??''));
        $multi_source=in_array($record_source,array(
            'tarifcheck_credit_all_cost_categories',
            'tarifcheck_insurance_all_insurance_categories',
            'check24_credit_all_cost_categories',
            'check24_insurance_all_insurance_categories',
        ),true);

        $records_for_path=$multi_source ? $portal_records : array($record);
        foreach($records_for_path as $stored_record){
            if(!is_array($stored_record) || sanitize_key((string)($stored_record['state']??''))!=='mapped'){continue;}
            if($multi_source && sanitize_key((string)($stored_record['source']??''))!==$record_source){continue;}
            $stored_target=$this->output_resolve_target_key($targets,sanitize_text_field((string)($stored_record['target_key']??'')));
            if(!is_array($stored_target)){continue;}
            if(method_exists($this,'control_target_gate')
                && is_wp_error($this->control_target_gate($portal_key,(string)($stored_target['key']??'')))){continue;}

            $path_keys=array_values(array_unique(array_filter(array_map('sanitize_text_field',(array)($stored_record['path_target_keys']??array())))));
            if(!$path_keys){
                $path_keys=$this->output_banner_target_path_keys($stored_target,$targets,$portal_key);
            }
            foreach($path_keys as $campaign_key){
                if($campaign_key!==''){$stored_campaign_targets[$campaign_key]=$campaign_key;}
            }
        }
        if($state==='mapped' && !$stored_campaign_targets){return null;}

        if($state==='general'){$target['_ppar_general_fallback_anchor']=1;}
        $level=sanitize_key((string)($record['level']??($state==='general'?'general':'exact')));
        return array(
            'status'=>'ready',
            'confidence'=>absint($record['confidence']??($state==='general'?1:100)),
            'reason'=>$record_source==='tarifcheck_credit_all_cost_categories'
                ? 'Gespeicherte Tarifcheck-Kredit-Zielkarte für alle Kosten-Kategorien.'
                : ($record_source==='tarifcheck_insurance_all_insurance_categories'
                    ? 'Gespeicherte Tarifcheck-Versicherungs-Zielkarte für alle Versicherungs-Kategorien.'
                    : ($record_source==='check24_credit_all_cost_categories'
                        ? 'Gespeicherte CHECK24-Kredit-Zielkarte für alle Kosten-Kategorien.'
                        : ($record_source==='check24_insurance_all_insurance_categories'
                            ? 'Gespeicherte CHECK24-Versicherungs-Zielkarte für alle Versicherungs-Kategorien.'
                            : ($state==='general'?'Gespeicherter allgemeiner Banner-Fallback aus der Creative-Library.':'Gespeicherte Ziel-URL-Zuordnung aus der Creative-Library.')))),
            'target'=>$target,
            'alternatives'=>array(),
            'source'=>$multi_source?$record_source:($state==='general'?'creative_library_general_fallback':'creative_library_destination_map'),
            '_ppar_destination_level'=>$level,
            '_ppar_banner_target_keys'=>array_values($stored_campaign_targets),
        );
    }

    /**
     * Einziger semantischer Banner-Matcher.
     *
     * Er arbeitet nur mit bereits geladenen Portalzielen und vorhandener Evidenz:
     * keine DB-Abfrage, kein HTTP, kein Frontend-Reclassify.
     * Ein Ziel gilt nur dann als belastbar, wenn seine komplette Blatt-/Slug-
     * Bedeutung in der aktuellen Evidenzstufe enthalten ist. Bei Gleichstand
     * wird nicht geraten.
     */
    private function output_banner_evidence_target_classification($evidence,$portal,$targets,$source,$level,$reason) {
        if(!is_array($portal) || !is_array($targets)){return null;}
        $evidence=$this->output_text((string)$evidence);
        if($evidence===''){return null;}

        $stop=array_flip(array('und','oder','mit','fuer','fur','von','der','die','das','ein','eine','im','in','am','auf'));
        $evidence_words=array_values(array_filter(array_unique(preg_split('/\\s+/', $evidence)),static function($word) use ($stop){
            $word=(string)$word;
            return strlen($word)>=3 && !isset($stop[$word]);
        }));
        if(!$evidence_words){return null;}

        $evidence_terms=array();
        foreach($evidence_words as $word){
            $evidence_terms[]=array(
                'word'=>(string)$word,
                'tokens'=>$this->output_tokens((string)$word),
            );
        }

        $wanted=array_values(array_filter(array_map('sanitize_key',(array)($portal['banner_target_types']??array('page','category')))));
        $portal_key=sanitize_key((string)($portal['key']??''));
        $matches=array();

        $set_supported=function($words) use ($evidence_terms,$stop) {
            $words=array_values(array_filter(array_unique((array)$words),static function($word) use ($stop){
                $word=(string)$word;
                return strlen($word)>=3 && !isset($stop[$word]);
            }));
            if(!$words){return 0;}

            $available=$evidence_terms;
            $exact_matches=0;
            foreach($words as $word){
                $matched_index=null;
                $target_variants=$this->output_tokens((string)$word);

                foreach($available as $index=>$evidence_term){
                    if(array_intersect($target_variants,(array)($evidence_term['tokens']??array()))){
                        $matched_index=$index;
                        $exact_matches++;
                        break;
                    }
                }

                if($matched_index===null && strlen((string)$word)>=6){
                    foreach($available as $index=>$evidence_term){
                        $evidence_word=(string)($evidence_term['word']??'');
                        if(strlen($evidence_word)>=6
                            && strpos($evidence_word,(string)$word)===0){
                            $matched_index=$index;
                            break;
                        }
                    }
                }

                if($matched_index===null){return 0;}
                unset($available[$matched_index]);
            }
            return count($words)*10+$exact_matches;
        };

        foreach($targets as $target){
            if(!is_array($target)){continue;}
            $type=sanitize_key((string)($target['type']??''));
            if(!in_array($type,$wanted,true)){continue;}

            $target_key=sanitize_text_field((string)($target['key']??''));
            if($target_key===''){continue;}
            if(method_exists($this,'control_target_gate')
                && is_wp_error($this->control_target_gate($portal_key,$target_key))){continue;}

            $label_parts=preg_split('/\s+>\s+/',html_entity_decode((string)($target['label']??''),ENT_QUOTES,'UTF-8'));
            $leaf=$this->output_text($label_parts?end($label_parts):(string)($target['label']??''));
            $slug=$this->output_text(str_replace(array('-','_'),' ',(string)($target['slug']??'')));

            $leaf_words=preg_split('/\s+/', $leaf);
            $slug_words=preg_split('/\s+/', $slug);
            $specificity=max($set_supported($leaf_words),$set_supported($slug_words));
            if($specificity<=0){continue;}

            $matches[]=array(
                'target'=>$target,
                'specificity'=>$specificity,
                'depth'=>absint($target['depth']??0),
            );
        }

        if(!$matches){return null;}

        usort($matches,static function($a,$b){
            $c=(int)$b['specificity']<=>(int)$a['specificity'];
            if($c!==0){return $c;}
            return (int)$b['depth']<=>(int)$a['depth'];
        });

        $best=$matches[0];
        $second=$matches[1]??null;
        if($second!==null && (int)$best['specificity']===(int)$second['specificity']){
            return array(
                'status'=>'review',
                'confidence'=>0,
                'reason'=>'Evidenz passt gleich stark zu mehreren Portalzielen; keine automatische Zuordnung.',
                'target'=>null,
                'alternatives'=>array($best['target'],$second['target']),
                'source'=>sanitize_key((string)$source).'_ambiguous',
            );
        }

        $target=$best['target'];
        $target['_ppar_destination_match_level']=sanitize_key((string)$level);
        return array(
            'status'=>'ready',
            'confidence'=>100,
            'reason'=>(string)$reason,
            'target'=>$target,
            'alternatives'=>array(),
            'source'=>sanitize_key((string)$source),
            '_ppar_destination_level'=>sanitize_key((string)$level),
        );
    }

    /**
     * Einziger Import-/Reconcile-Weg fuer normale Banner:
     * Ziel-URL -> Provider-Kategorie -> echter Bannertext.
     * Die erste belastbare oder mehrdeutige Evidenzstufe entscheidet;
     * mehrdeutig bleibt fail-closed.
     */
    private function output_banner_import_classification($row,$portal,$targets) {
        if(!is_array($row) || !is_array($portal) || !is_array($targets)){return null;}

        $payload=json_decode((string)($row['payload']??''),true);
        $payload=is_array($payload)?$payload:array();
        $tiers=array();

        $destination_source=$this->output_banner_destination_source($row);
        $destination=esc_url_raw((string)($row['destination_url']??''));
        if(in_array($destination_source,array('provider_explicit','decoded_tracking','resolved_redirect'),true)
            && $destination!==''){
            $tiers[]=array(
                'evidence'=>$this->output_destination_semantic_text($row),
                'source'=>'import_destination_url',
                'level'=>'exact',
                'reason'=>'Echte Ziel-URL passt eindeutig zum tiefsten belastbaren Portalziel.',
            );
        }

        $topic_name=sanitize_text_field((string)($payload['provider_topic_name']??''));
        $topic_source=sanitize_key((string)($payload['provider_topic_source']??''));
        if($topic_name!=='' && $topic_source!==''){
            $tiers[]=array(
                'evidence'=>$topic_name,
                'source'=>'banner_provider_topic',
                'level'=>'exact',
                'reason'=>'Echte Provider-Kategorie passt eindeutig zum tiefsten belastbaren Portalziel.',
            );
        }

        $title_source=sanitize_key((string)($payload['title_source']??''));
        $real_title=in_array($title_source,array('provider_missing','manual_missing'),true)
            ? '' : (string)($row['title']??'');
        $tiers[]=array(
            'evidence'=>implode(' ',array_filter(array(
                $real_title,
                (string)($row['description']??''),
                (string)($row['tags']??''),
                (string)($payload['information']??''),
                (string)($payload['alt_text']??''),
                (string)($payload['banner_name']??''),
                (string)($payload['name']??''),
            ))),
            'source'=>'banner_content',
            'level'=>'content_exact',
            'reason'=>'Echter Bannername/-text passt eindeutig zum tiefsten belastbaren Portalziel.',
        );

        $best=null;
        $best_path=array();

        foreach($tiers as $tier){
            $classification=$this->output_banner_evidence_target_classification(
                (string)($tier['evidence']??''),
                $portal,
                $targets,
                (string)($tier['source']??''),
                (string)($tier['level']??'exact'),
                (string)($tier['reason']??'')
            );
            if(!is_array($classification)){continue;}

            // Eine mehrdeutige staerkere Evidenz bleibt fail-closed.
            // Eine spaetere, schwaechere Mehrdeutigkeit verwirft dagegen keinen
            // bereits belastbaren Treffer.
            if(sanitize_key((string)($classification['status']??''))!=='ready'
                || !is_array($classification['target']??null)){
                if($best===null){return $classification;}
                continue;
            }

            $target=$classification['target'];
            $parts=preg_split('/\\s+>\\s+/',html_entity_decode((string)($target['label']??''),ENT_QUOTES,'UTF-8'));
            $path=array_values(array_filter(array_map(array($this,'output_text'),(array)$parts),'strlen'));

            if($best===null){
                $best=$classification;
                $best_path=$path;
                continue;
            }

            // Schwaechere Evidenz darf den staerkeren Treffer nur innerhalb
            // desselben Strangs praezisieren. Beispiel:
            // Exakte Kategoriebindung bleibt über Zielslug und Pfad erhalten.
            if($best_path && $path
                && count($path)>count($best_path)
                && array_slice($path,0,count($best_path))===$best_path){
                $best=$classification;
                $best_path=$path;
            }
        }

        return $best;
    }





    private function output_banner_destination_classification($row,$portal) {
        // HARD RULE:
        // Import -> Ziel-URL -> einmalige Zuordnung zu festen Portalzielen -> speichern.
        // Runtime darf weder Ziel-URL noch Provider-Thema neu klassifizieren.
        // Ohne gespeicherte feste Zielzuordnung bleibt der Banner gesperrt.
        $stored=$this->output_banner_stored_destination_classification($row,$portal);
        if(is_wp_error($stored)){return $stored;}
        if(is_array($stored)){return $stored;}
        return array(
            'status'=>'review',
            'confidence'=>0,
            'reason'=>'Keine gespeicherte feste Portalziel-Zuordnung vorhanden.',
            'target'=>null,
            'alternatives'=>array(),
            'source'=>'banner_target_map_missing',
        );
    }

    /**
     * Tarifcheck und CHECK24 sind Direktpartner im bestehenden Importweg, keine
     * neuen Provideradapter. Produktfamilien werden aus echter Ziel-URL oder
     * einer ausdruecklich gesetzten manuellen Familie bestimmt.
     */
    private function output_comparison_banner_partner($row) {
        if (!is_array($row)) { return ''; }
        $partner = $this->output_text((string)($row['partner_name'] ?? ''));
        $destination = esc_url_raw((string)($row['destination_url'] ?? ''));
        $host = strtolower((string)wp_parse_url($destination, PHP_URL_HOST));
        if (strpos($partner, 'tarifcheck') !== false
            || $host === 'tarifcheck.de'
            || substr($host, -14) === '.tarifcheck.de') {
            return 'tarifcheck';
        }
        if (strpos($partner, 'check24') !== false
            || $host === 'check24.de'
            || substr($host, -11) === '.check24.de') {
            return 'check24';
        }
        return '';
    }

    private function output_tarifcheck_banner_family($row) {
        if ($this->output_comparison_banner_partner($row) === '') { return ''; }

        $payload = json_decode((string)($row['payload'] ?? ''), true);
        $payload = is_array($payload) ? $payload : array();
        $title_source = sanitize_key((string)($payload['title_source'] ?? ''));
        $real_title = in_array($title_source, array('provider_missing','manual_missing'), true)
            ? '' : (string)($row['title'] ?? '');

        // Ein einziger automatischer Evidenzweg, genau in Vertragsreihenfolge:
        // 1. echte Ziel-URL, 2. echte Provider-Kategorie, 3. echter Bannertext.
        // Keine manuelle Vergleichsportal-Gruppe und kein Raten bei Widerspruch.
        $tiers = array(
            $this->output_destination_semantic_text($row),
            implode(' ', array_filter(array(
                (string)($payload['provider_topic_name'] ?? ''),
                (string)($payload['promotion_category_name'] ?? ''),
            ))),
            implode(' ', array_filter(array(
                $real_title,
                (string)($row['description'] ?? ''),
                (string)($row['tags'] ?? ''),
                (string)($payload['information'] ?? ''),
                (string)($payload['banner_name'] ?? ''),
                (string)($payload['name'] ?? ''),
            ))),
        );

        foreach ($tiers as $tier) {
            $semantic = $this->output_text((string)$tier);
            if ($semantic === '') { continue; }
            $credit = preg_match('/(^|\\s)(kredit|kredite|kreditvergleich|kreditrechner|kreditkarte|kreditkarten|darlehen|finanzierung|baufinanzierung)(\\s|$)/u', $semantic) === 1;
            $insurance = preg_match('/(^|\\s)(versicherung|versicherungen|versicherungsvergleich|haftpflicht|tierhalterhaftpflicht)(\\s|$)/u', $semantic) === 1;
            if ($credit && !$insurance) { return 'kosten'; }
            if ($insurance && !$credit) { return 'versicherung'; }
            if ($credit && $insurance) { return 'blocked'; }
        }
        return 'blocked';
    }

    private function output_tarifcheck_target_allowed($target, $family) {
        $family = sanitize_key((string)$family);
        if ($family === '') { return true; }
        if ($family === 'blocked' || !is_array($target)) { return false; }
        if (sanitize_key((string)($target['type'] ?? '')) !== 'category') { return false; }

        $decoded_label = html_entity_decode((string)($target['label'] ?? ''), ENT_QUOTES, 'UTF-8');
        $parts = preg_split('/\s+>\s+/', $decoded_label);
        $parts = array_values(array_filter(array_map(array($this,'output_text'), (array)$parts), 'strlen'));
        $leaf = $parts ? (string)end($parts) : '';
        $slug = sanitize_key((string)($target['slug'] ?? ''));

        if ($family === 'kosten') {
            // KISS: "Kosten" ist kein eigener Root-Ast, sondern kommt als
            // verteilte Blattkategorie in verschiedenen Fachstraengen vor.
            // Deshalb reicht genau ein strukturelles Merkmal: echte Blattkategorie
            // + "kosten" im Blatt/Pfad ODER im Slug. Keine Prefix+Suffix-Doppelhuerde.
            if (sanitize_key((string)($target['context'] ?? '')) !== 'leaf_category') {
                return false;
            }
            foreach ($parts as $part) {
                if (preg_match('/(^|\s)kosten(\s|$)/u', $part) === 1) {
                    return true;
                }
            }
            return strpos($slug, 'kosten') !== false;
        }
        if ($family === 'versicherung') {
            // Versicherungsbanner bleiben ausschließlich in echten Blatt-
            // kategorien des Astes "Wissen > Versicherungen & Recht > ...".
            if (sanitize_key((string)($target['context'] ?? '')) !== 'leaf_category') {
                return false;
            }
            foreach ($parts as $part) {
                if ($part === 'versicherungen recht' || $part === 'versicherungen und recht') {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    /**
     * HARD RULE – automatische Banner:
     * Import -> Ziel-URL -> einmalige Zuordnung zu festen Portalzielen -> speichern.
     * Diese Methode darf nur aus Import-/Workerpfaden aufgerufen werden.
     */
    public function output_assign_banner_targets_from_destination_once($row) {
        if (!is_array($row) || sanitize_key((string)($row['creative_type']??'')) !== 'banner') {
            return array('updated'=>0,'mapped'=>0,'reason'=>'not_banner');
        }
        $row_id=absint($row['id']??0);
        if($row_id<=0 || !method_exists($this,'creative_library_table')) {
            return array('updated'=>0,'mapped'=>0,'reason'=>'missing_row');
        }

        global $wpdb;
        $payload=json_decode((string)($row['payload']??''),true);
        $payload=is_array($payload)?$payload:array();

        // Altbestand mit nur geprueftem Trackinglink: im ohnehin laufenden
        // Import/Reconcile genau einmal bis zur echten Landingpage aufloesen.
        // Kein Frontend-HTTP, keine neue Runtime-Abfrage.
        $source=$this->output_banner_destination_source($row);
        if(in_array($source,array('tracking_checked','tracking_fallback'),true)
            && method_exists($this,'creative_library_resolve_tracking_destination_import')){
            $tracking=esc_url_raw((string)($row['tracking_url']??''));
            if($tracking!==''){
                $resolved=$this->creative_library_resolve_tracking_destination_import($tracking);
                $resolved_url=is_array($resolved)?esc_url_raw((string)($resolved['url']??'')):'';
                $resolved_source=is_array($resolved)?sanitize_key((string)($resolved['source']??'')):'';
                if($resolved_url!=='' && $resolved_url!==$tracking
                    && in_array($resolved_source,array('decoded_tracking','resolved_redirect'),true)){
                    $payload['_destination_source']=$resolved_source;
                    $row['destination_url']=$resolved_url;
                    $row['payload']=wp_json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                    $wpdb->update($this->creative_library_table(),array(
                        'destination_url'=>$resolved_url,
                        'payload'=>$row['payload'],
                    ),array('id'=>$row_id));
                    $source=$resolved_source;
                }
            }
        }

        $destination=esc_url_raw((string)($row['destination_url']??''));
        $comparison_partner=$this->output_comparison_banner_partner($row);
        $tarifcheck_family=$this->output_tarifcheck_banner_family($row);
        $portals=$this->output_portal_registry();
        $new_records=array();
        $mapped=0;

        foreach((array)$portals as $portal){
            if(!is_array($portal) || empty($portal['enabled'])){continue;}
            $portal_key=sanitize_key((string)($portal['key']??''));
            if($portal_key===''){continue;}

            $targets=$this->output_portal_targets($portal);
            if(is_wp_error($targets)){continue;}

            // KISS/DB: Banner-Zuordnung prueft viele Ziele, aber die manuellen
            // Zielentscheidungen werden pro Portal genau einmal read-only geladen.
            // Danach liest control_target_gate() nur noch den Request-Cache.
            if(method_exists($this,'control_prime_portal_decision_cache')){
                $this->control_prime_portal_decision_cache($portal_key,true);
            }

            $wanted=array_values(array_filter(array_map('sanitize_key',(array)($portal['banner_target_types']??array('page','category')))));

            // Die zwei vereinbarten Vergleichsfamilien bleiben die einzigen
            // Mehrziel-Faelle: Kredit -> alle Kosten-Blaetter, Versicherung -> alle
            // Versicherungs-Blaetter. Die Familie selbst wird automatisch aus Evidenz bestimmt.
            if(in_array($tarifcheck_family,array('kosten','versicherung'),true)){
                $map_source=$comparison_partner==='check24'
                    ? ($tarifcheck_family==='kosten' ? 'check24_credit_all_cost_categories' : 'check24_insurance_all_insurance_categories')
                    : ($tarifcheck_family==='kosten' ? 'tarifcheck_credit_all_cost_categories' : 'tarifcheck_insurance_all_insurance_categories');
                $map_level=$tarifcheck_family==='kosten'
                    ? 'all_cost_categories'
                    : 'all_insurance_categories';
                foreach((array)$targets as $target){
                    if(!is_array($target)){continue;}
                    $type=sanitize_key((string)($target['type']??''));
                    if(!in_array($type,$wanted,true) || !$this->output_tarifcheck_target_allowed($target,$tarifcheck_family)){continue;}
                    $target_key=sanitize_text_field((string)($target['key']??''));
                    if($target_key===''){continue;}
                    if(method_exists($this,'control_target_gate') && is_wp_error($this->control_target_gate($portal_key,$target_key))){continue;}
                    $new_records[]=array(
                        'portal_key'=>$portal_key,
                        'state'=>'mapped',
                        'level'=>$map_level,
                        'target_key'=>$target_key,
                        'target_label'=>sanitize_text_field((string)($target['label']??'')),
                        'path_target_keys'=>$this->output_banner_target_path_keys($target,$targets,$portal_key),
                        'confidence'=>100,
                        'source'=>$map_source,
                        'destination_source'=>$source,
                        'destination_url'=>$destination,
                        'updated_at'=>time(),
                    );
                    $mapped++;
                }
                continue;
            }
            if($tarifcheck_family==='blocked'){
                continue;
            }

            // KISS-Evidenzreihenfolge:
            // 1. echte Ziel-URL, 2. Provider-Kategorie, 3. Bannername/-text.
            // Jede Stufe liefert genau EIN tiefstes belastbares Ziel.
            $classification=$this->output_banner_import_classification($row,$portal,$targets);

            if(!is_array($classification)
                || sanitize_key((string)($classification['status']??''))!=='ready'
                || !is_array($classification['target']??null)){
                continue;
            }

            $target=$classification['target'];
            $target_key=sanitize_text_field((string)($target['key']??''));
            if($target_key===''){continue;}

            $new_records[]=array(
                'portal_key'=>$portal_key,
                'state'=>'mapped',
                'level'=>sanitize_key((string)($classification['_ppar_destination_level']??'exact')),
                'target_key'=>$target_key,
                'target_label'=>sanitize_text_field((string)($target['label']??'')),
                'path_target_keys'=>$this->output_banner_target_path_keys($target,$targets,$portal_key),
                'confidence'=>absint($classification['confidence']??100),
                'source'=>sanitize_key((string)($classification['source']??'banner_auto_target')),
                'destination_source'=>$source,
                'destination_url'=>$destination,
                'updated_at'=>time(),
            );
            $mapped++;
        }

        global $wpdb;
        $wpdb->update($this->creative_library_table(),array(
            'topic_status'=>$mapped>0?'auto_verified':'no_match',
            'topic_score'=>$mapped>0?100:0,
            'topic_targets'=>wp_json_encode($new_records,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            'classified_at'=>time(),
        ),array('id'=>$row_id));

        return array(
            'updated'=>1,
            'mapped'=>$mapped,
            'reason'=>$mapped>0?'mapped':'no_match',
            'targets'=>$new_records,
        );
    }

    private function output_banner_compatible_slots($row,$portal) {
        $matrix=$this->output_slot_matrix($portal);
        if(is_wp_error($matrix)||!is_array($matrix)){return array();}
        $slots=array();
        foreach($matrix as $slot_id=>$rule){
            if(!is_array($rule)||sanitize_key((string)($rule['creative_type']??''))!=='banner'){continue;}
            if($this->output_row_matches_slot_rule($row,$rule,'banner')){$slots[]=sanitize_key((string)$slot_id);}
        }
        return array_values(array_unique(array_filter($slots)));
    }

    private function output_store_banner_library_assignment($row,$portal,$classification,$compatible_slots) {
        if(!is_array($row)||sanitize_key((string)($row['creative_type']??''))!=='banner'||!method_exists($this,'creative_library_table')){return;}
        $row_id=absint($row['id']??0);if($row_id<=0){return;}
        $portal_key=sanitize_key((string)($portal['key']??''));if($portal_key===''){return;}
        $target=is_array($classification['target']??null)?$classification['target']:array();
        $target_key=sanitize_text_field((string)($target['key']??''));
        if($target_key===''){return;}
        $records=$this->output_banner_library_records($row);
        $records=array_values(array_filter($records,static function($record)use($portal_key){return sanitize_key((string)($record['portal_key']??''))!==$portal_key;}));
        $general=!empty($target['_ppar_general_fallback_anchor'])||sanitize_key((string)($classification['source']??''))==='banner_general_fallback';
        $records[]=array(
            'portal_key'=>$portal_key,
            'state'=>$general?'general':'mapped',
            'level'=>$general?'general':sanitize_key((string)($classification['_ppar_destination_level']??($target['_ppar_destination_match_level']??'exact'))),
            'target_key'=>$target_key,
            'target_label'=>sanitize_text_field((string)($target['label']??'')),
            'confidence'=>absint($classification['confidence']??0),
            'source'=>sanitize_key((string)($classification['source']??'')),
            'destination_source'=>$this->output_banner_destination_source($row),
            'destination_url'=>esc_url_raw((string)($row['destination_url']??'')),
            'compatible_slots'=>array_values(array_unique(array_map('sanitize_key',(array)$compatible_slots))),
            'updated_at'=>time(),
        );
        global $wpdb;
        $wpdb->update($this->creative_library_table(),array(
            'topic_score'=>absint($classification['confidence']??0),
            'topic_targets'=>wp_json_encode($records,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            'classified_at'=>time(),
        ),array('id'=>$row_id));
    }

    private function output_creative_specific_text($row) {
        $payload=json_decode((string)($row['payload']??''),true);
        $payload=is_array($payload)?$payload:array();
        $title_source=sanitize_key((string)($payload['title_source']??''));
        $title_evidence=in_array($title_source,array('provider_missing','manual_missing'),true)
            ? '' : (string)($row['title']??'');
        return implode(' ', array_filter(array(
            $title_evidence,
            (string) ($row['description'] ?? ''),
            (string) ($row['tags'] ?? ''),
            (string) ($row['destination_url'] ?? ''),
            $this->output_destination_semantic_text($row),
        )));
    }

    /**
     * Creative-spezifische Evidenz darf durch einen Portaladapter ergänzt werden,
     * etwa durch eine lokal freigegebene Bildklassifikation. Partnerdaten allein
     * reichen bewusst nicht als Creative-Beweis. Ohne belastbare Creative-Evidenz
     * bleibt die automatische Ausgabe in der Prüfliste.
     */
    private function output_creative_evidence_text($row, $portal, $output_type) {
        $evidence = array($this->output_creative_specific_text($row));
        $adapter = sanitize_key((string) ($portal['adapter'] ?? ''));
        if (!in_array($adapter, array('wordpress_local','wordpress_multisite'), true)) {
            $callbacks = is_array($portal['callbacks'] ?? null) ? $portal['callbacks'] : array();
            if (!empty($callbacks['creative_evidence']) && is_callable($callbacks['creative_evidence'])) {
                $extra = call_user_func($callbacks['creative_evidence'], $row, $portal, sanitize_key((string) $output_type), self::PORTAL_ADAPTER_VERSION);
                if (is_wp_error($extra)) {
                    return $extra;
                }
                $evidence = array_merge($evidence, is_array($extra) ? $extra : array($extra));
            }
        }
        $filtered = apply_filters('ppar_affiliate_creative_evidence', $evidence, $row, $portal, sanitize_key((string) $output_type), self::PORTAL_ADAPTER_VERSION);
        if (is_wp_error($filtered)) {
            return $filtered;
        }
        $filtered = is_array($filtered) ? $filtered : array($filtered);
        return implode(' ', array_filter(array_map('sanitize_text_field', $filtered)));
    }

    private function output_classify_for_portal($row, $portal, $output_type) {
        if (!is_array($row) || empty($row['identity_hash'])) {
            return new WP_Error('output_creative_missing', 'Creative-Datensatz fehlt.');
        }
        $profile_valid = $this->output_validate_portal_profile($portal);
        if (is_wp_error($profile_valid)) { return $profile_valid; }
        $portal_key = sanitize_key((string) ($portal['key'] ?? ''));
        $manual = $this->output_portal_decision($portal_key, (string) ($row['identity_hash'] ?? ''));
        $manual_status = sanitize_key((string) ($manual['manual_status'] ?? 'automatic'));
        $manual_payload = is_array($manual['payload'] ?? null) ? $manual['payload'] : array();

        // Vertragsreihenfolge: erst unverrückbare technische/rechtliche
        // Sicherheitsblocker, danach die Chefentscheidung, erst danach Automatik.
        // Dadurch kann ein Veto zwar immer stoppen, aber niemals einen realen
        // Sicherheitsfehler verdecken oder eine Freigabe ihn überstimmen.
        if (method_exists($this, 'control_creative_safety_check')) {
            $safety = $this->control_creative_safety_check($row, $portal, 'plan');
            if (is_wp_error($safety)) {
                return $safety;
            }
        } elseif ((string) ($row['source_status'] ?? 'active') !== 'active' || (string) ($row['availability_state'] ?? 'active') !== 'active') {
            return array('status'=>'blocked','confidence'=>100,'reason'=>'Creative-Quelle ist nicht aktiv.','target'=>null,'source'=>'source_state');
        }
        if ($manual_status === 'veto') {
            return array('status'=>'blocked','confidence'=>100,'reason'=>(string) ($manual['reason'] ?? 'Manuelles Creative-Veto ist für dieses Portal vorrangig.'),'target'=>null,'source'=>'manual_veto');
        }
        if ($manual_status === 'review') {
            return array('status'=>'review','confidence'=>0,'reason'=>(string) ($manual['reason'] ?? 'Creative wurde für dieses Portal zur Prüfung markiert.'),'target'=>null,'source'=>'manual_review');
        }
        $fixed_target_key = sanitize_text_field((string) ($manual_payload['target_key'] ?? ''));
        if ($manual_status === 'approved' && $fixed_target_key !== '') {
            $targets = $this->output_portal_targets($portal);
            if (is_wp_error($targets)) {
                return $targets;
            }
            $is_listing = in_array($output_type, array('hivepress_listing','portal_listing'), true);
            if ($is_listing) {
                $wanted_types = array_values(array_filter(array_map('sanitize_key', (array) ($portal['listing_target_types'] ?? array('hp_listing_category')))));
            } elseif ($output_type === 'product_campaign') {
                $wanted_types = array_values(array_filter(array_map('sanitize_key', (array) ($portal['product_target_types'] ?? array('page','category')))));
            } else {
                $wanted_types = array_values(array_filter(array_map('sanitize_key', (array) ($portal['banner_target_types'] ?? array('page','category')))));
            }
            $target = $this->output_resolve_target_key($targets, $fixed_target_key);
            if (!is_array($target)) {
                return new WP_Error('control_fixed_target_missing', 'Fest vorgegebenes Portalziel existiert nicht eindeutig oder ist nicht erreichbar.');
            }
            if (!in_array(sanitize_key((string) ($target['type'] ?? '')), $wanted_types, true)) {
                return new WP_Error('control_fixed_target_type_invalid', 'Festes Portalziel ist für diesen Ausgabetyp nicht zulässig.');
            }
            if (method_exists($this, 'control_target_gate')) {
                $target_gate = $this->control_target_gate($portal_key, (string) ($target['key'] ?? ''));
                if (is_wp_error($target_gate)) { return $target_gate; }
            }
            return array(
                'status'=>'ready',
                'confidence'=>100,
                'reason'=>(string) ($manual['reason'] ?? 'Chefentscheidung mit festem Portalziel.'),
                'target'=>$target,
                'alternatives'=>array(),
                'source'=>'manual_fixed_target',
            );
        }

        // Automatische Banner lesen erst NACH Safety/Veto/Review/FIXED nur die
        // gespeicherte Creative-Library-Ziel-/Pfadkarte. Kein Frontend-Reclassify.
        if ($output_type === 'portal_banner' && sanitize_key((string)($row['creative_type']??'')) === 'banner') {
            return $this->output_banner_destination_classification($row,$portal);
        }
        // eBay-BUSINESS ist ein harter eigener Zielvertrag. Nach Veto/Review bzw.
        // einem expliziten Chefziel darf die Automatik NIEMALS in die generische
        // Textklassifikation zurueckfallen. Entweder existiert ein verifiziertes
        // Produkt-/Hub-Konzept oder der Datensatz bleibt targetless auf Review.
        $is_ebay_business_product = $output_type === 'product_campaign'
            && sanitize_key((string)($row['provider'] ?? '')) === 'ebay'
            && sanitize_key((string)($row['source_kind'] ?? '')) === 'ebay_business_item'
            && sanitize_key((string)($row['creative_type'] ?? '')) === 'product';
        if ($is_ebay_business_product) {
            $ebay_payload = json_decode((string)($row['payload'] ?? ''), true);
            $ebay_payload = is_array($ebay_payload) ? $ebay_payload : array();
            $is_ebay_business_product = strtoupper(sanitize_key((string)($ebay_payload['ebay_seller_account_type'] ?? ''))) === 'BUSINESS';
        }
        if ($is_ebay_business_product && method_exists($this, 'ebay_business_exact_product_classification')) {
            $targets = $this->output_portal_targets($portal);
            if (is_wp_error($targets)) { return $targets; }
            $ebay_exact = $this->ebay_business_exact_product_classification($row, $portal, $targets);
            if (is_wp_error($ebay_exact)) { return $ebay_exact; }
            if (is_array($ebay_exact) && !empty($ebay_exact)) { return $ebay_exact; }
            return array(
                'status'=>'review','confidence'=>0,
                'reason'=>'eBay-BUSINESS besitzt keinen aktuell verifizierten Produktvertrag; generische Portalzuordnung ist gesperrt.',
                'target'=>null,'alternatives'=>array(),'source'=>'ebay_business_contract_missing',
            );
        }

        $specific_evidence = $this->output_creative_evidence_text($row, $portal, $output_type);
        if (is_wp_error($specific_evidence)) {
            return $specific_evidence;
        }
        $specific = $this->output_text($specific_evidence);
        $domain_terms = array_values(array_filter(array_map(array($this, 'output_text'), (array) ($portal['domain_terms'] ?? array()))));
        $negative_terms = array_values(array_filter(array_map(array($this, 'output_text'), (array) ($portal['negative_terms'] ?? array()))));
        $specific_has_domain = false;
        foreach ($domain_terms as $term) { if ($term !== '' && $this->output_term_present($specific, $term)) { $specific_has_domain = true; break; } }
        $specific_has_negative = false;
        foreach ($negative_terms as $term) { if ($term !== '' && $this->output_term_present($specific, $term)) { $specific_has_negative = true; break; } }
        if ($specific_has_negative && !$specific_has_domain && $manual_status !== 'approved') {
            return array('status'=>'blocked','confidence'=>100,'reason'=>'Creative-spezifischer fachfremder Inhalt für dieses Portal erkannt.','target'=>null,'source'=>'creative_negative');
        }
        if ($specific_has_negative && $specific_has_domain && $manual_status !== 'approved') {
            return array('status'=>'review','confidence'=>50,'reason'=>'Creative enthält widersprüchliche Fachsignale und benötigt eine Sichtprüfung.','target'=>null,'source'=>'creative_conflict');
        }

        // V6.72.174 AF-077: Ein eindeutiger Treffer auf ein reales, erlaubtes
        // Portalziel ist selbst belastbare Creative-Fachevidenz. Dieser Zusatz
        // greift ausschließlich dort, wo der bisherige generische Domain-Test
        // ohnehin auf REVIEW abbrechen würde. Safety, Negativsignale und Veto
        // wurden oben bereits unverändert geprüft.
        $targets = null;
        $wanted_types = null;
        $real_target_evidence_key = '';
        if (!$specific_has_domain && $manual_status !== 'approved') {
            $targets = $this->output_portal_targets($portal);
            if (is_wp_error($targets)) {
                return $targets;
            }
            $is_listing = in_array($output_type, array('hivepress_listing','portal_listing'), true);
            if ($is_listing) {
                $wanted_types = array_values(array_filter(array_map('sanitize_key', (array) ($portal['listing_target_types'] ?? array('hp_listing_category')))));
            } elseif ($output_type === 'product_campaign') {
                $wanted_types = array_values(array_filter(array_map('sanitize_key', (array) ($portal['product_target_types'] ?? array('page','category')))));
            } else {
                $wanted_types = array_values(array_filter(array_map('sanitize_key', (array) ($portal['banner_target_types'] ?? array('page','category')))));
            }

            $specific_tokens = $this->output_tokens($specific);
            $destination_tokens = $this->output_tokens($this->output_destination_semantic_text($row));
            $strong_target_evidence = array();
            foreach ((array) $targets as $candidate_target) {
                if (!is_array($candidate_target)) { continue; }
                $candidate_type = sanitize_key((string) ($candidate_target['type'] ?? ''));
                if (!in_array($candidate_type, $wanted_types, true)) { continue; }
                $candidate_key = sanitize_text_field((string) ($candidate_target['key'] ?? ''));
                if ($candidate_key === '') { continue; }
                if (method_exists($this, 'control_target_gate')) {
                    $candidate_gate = $this->control_target_gate($portal_key, $candidate_key);
                    if (is_wp_error($candidate_gate)) { continue; }
                }

                $destination_exact = false;
                $leaf_hit = false;
                $slug_norm = $this->output_text(str_replace(array('-','_'),' ',(string)($candidate_target['slug'] ?? '')));
                $slug_tokens = $this->output_tokens($slug_norm);
                $target_url_path = $this->output_target_public_url_path($candidate_target);
                $target_url_tokens = $this->output_tokens(str_replace('/', ' ', $target_url_path));
                $target_url_confirms_slug = $slug_tokens && $target_url_tokens && !array_diff($slug_tokens, $target_url_tokens);
                if ($destination_tokens && $target_url_confirms_slug && !array_diff($slug_tokens, $destination_tokens)) {
                    $destination_exact = true;
                }
                if ($specific_tokens) {
                    $label_parts = preg_split('/\s+>\s+/', (string) ($candidate_target['label'] ?? ''));
                    $leaf_norm = $this->output_text($label_parts ? end($label_parts) : (string) ($candidate_target['label'] ?? ''));
                    $leaf_tokens = $this->output_tokens($leaf_norm);
                    foreach ($specific_tokens as $source_token) {
                        foreach ($leaf_tokens as $target_token) {
                            if (strlen($source_token) >= 7 && strlen($target_token) >= 7
                                && (strpos($source_token, $target_token) !== false || strpos($target_token, $source_token) !== false)) {
                                $leaf_hit = true;
                                break 2;
                            }
                        }
                    }
                }
                if (!$destination_exact && !$leaf_hit) { continue; }
                $evidence_score = ($destination_exact ? 1000 : 0) + ($leaf_hit ? 300 : 0);
                // A canonical product/page edge may beat derivative FAQ/advice
                // targets only when the external destination itself confirms
                // the page slug. Pure word similarity never gets this bonus.
                if ($destination_exact && $candidate_type === 'page') {
                    $evidence_score += 100;
                }
                $strong_target_evidence[$candidate_key] = max(
                    absint($strong_target_evidence[$candidate_key] ?? 0),
                    $evidence_score
                );
            }
            if ($strong_target_evidence) {
                arsort($strong_target_evidence, SORT_NUMERIC);
                $evidence_keys = array_keys($strong_target_evidence);
                $best_key = (string) ($evidence_keys[0] ?? '');
                $best_score = absint($strong_target_evidence[$best_key] ?? 0);
                $second_score = isset($evidence_keys[1]) ? absint($strong_target_evidence[$evidence_keys[1]] ?? 0) : 0;
                // Preserve the 6.72.174 single-real-target behavior. With several
                // related portal targets, require materially stronger exact
                // destination evidence instead of arbitrary first-match choice.
                $unique_single = count($strong_target_evidence) === 1;
                $clear_destination_winner = $best_score >= 1000 && ($best_score - $second_score) >= 400;
                if ($best_key !== '' && ($unique_single || $clear_destination_winner)) {
                    $real_target_evidence_key = $best_key;
                    $specific_has_domain = true;
                }
            }
        }
        if (!$specific_has_domain && $manual_status !== 'approved') {
            return array('status'=>'review','confidence'=>0,'reason'=>'Das Partnerprofil passt, aber das konkrete Creative besitzt noch keinen belastbaren Fachbezug.','target'=>null,'source'=>'creative_domain_signal_missing');
        }
        $partner = $this->output_partner_evidence($row);
        $partner_text = implode(' ', array_filter(array(
            (string) ($row['partner_name'] ?? ''),
            (string) $partner['business_label'],
            implode(' ', (array) $partner['keywords']),
            (string) $partner['primary_sector'],
            (string) $partner['programme_description'],
            implode(' ', (array) $partner['domains']),
        )));
        $combined = trim($specific . ' ' . $this->output_text($partner_text));
        $combined_has_domain = false;
        foreach ($domain_terms as $term) { if ($term !== '' && $this->output_term_present($combined, $term)) { $combined_has_domain = true; break; } }
        if (!$combined_has_domain && $real_target_evidence_key === '' && $manual_status !== 'approved') {
            return array('status'=>'review','confidence'=>0,'reason'=>'Kein belastbarer Bezug zum Fachprofil dieses Portals.','target'=>null,'source'=>'portal_domain_signal_missing');
        }
        $source_tokens = $this->output_tokens($combined);
        if (!$source_tokens) {
            return array('status'=>'review','confidence'=>0,'reason'=>'Keine verwertbaren Klassifikationssignale.','target'=>null,'source'=>'insufficient_data');
        }
        if (!is_array($targets)) {
            $targets = $this->output_portal_targets($portal);
            if (is_wp_error($targets)) {
                return $targets;
            }
        }
        if (!is_array($wanted_types)) {
            $is_listing = in_array($output_type, array('hivepress_listing','portal_listing'), true);
            if ($is_listing) {
                $wanted_types = array_values(array_filter(array_map('sanitize_key', (array) ($portal['listing_target_types'] ?? array('hp_listing_category')))));
            } elseif ($output_type === 'product_campaign') {
                $wanted_types = array_values(array_filter(array_map('sanitize_key', (array) ($portal['product_target_types'] ?? array('page','category')))));
            } else {
                $wanted_types = array_values(array_filter(array_map('sanitize_key', (array) ($portal['banner_target_types'] ?? array('page','category')))));
            }
        }

        // V6.72.48 LIVE-Rootfix: „Automatik verwenden“ aus dem sichtbaren
        // Werbeplatz „Glossarartikel“ darf nicht erneut an einer unsicheren
        // semantischen Zielklassifikation hängen bleiben. Die Chefentscheidung
        // bindet den fachlichen Werbeplatz; ein reales Glossarziel dient nur als
        // kanonischer Materialisierungsanker. Die eigentliche Artikelwahl bleibt
        // zur Laufzeit: exakt -> Themenbereich -> allgemeiner Glossar-Fallback.
        $werbeplatz_scope = sanitize_key((string) ($manual_payload['werbeplatz_scope'] ?? ''));
        if ($manual_status === 'approved' && $output_type === 'portal_banner' && $werbeplatz_scope === 'glossarartikel') {
            // Zuerst echte Partner-/Creative-Semantik auf eine reale Glossar-Themenwelt
            // abbilden. Nur wenn das nicht eindeutig moeglich ist, wird ein neutraler
            // technischer Anker benutzt; der Laufzeit-Fillvertrag bleibt dann bei 50.
            $semantic_target = $this->output_glossary_scope_semantic_target($row, $targets, $specific_evidence, $partner);
            if (is_array($semantic_target)) {
                if (!method_exists($this, 'control_target_gate') || !is_wp_error($this->control_target_gate($portal_key, (string)($semantic_target['key'] ?? '')))) {
                    return array(
                        'status'=>'ready',
                        'confidence'=>100,
                        'reason'=>'Chefentscheidung: Glossar freigegeben; semantischer Themenanker automatisch erkannt: ' . sanitize_text_field((string)($semantic_target['label'] ?? 'Glossar-Themenwelt')) . '.',
                        'target'=>$semantic_target,
                        'alternatives'=>array(),
                        'source'=>'manual_approved_glossary_semantic',
                    );
                }
            }
            $anchor_target = null;
            foreach ((array) $targets as $candidate_target) {
                if (!is_array($candidate_target)) { continue; }
                $candidate_type = sanitize_key((string)($candidate_target['type'] ?? ''));
                if (!in_array($candidate_type, array('uge_group','uge_term'), true)) { continue; }
                if (absint($candidate_target['id'] ?? 0) <= 0 || empty($candidate_target['key'])) { continue; }
                if (method_exists($this, 'control_target_gate')) {
                    $candidate_gate = $this->control_target_gate($portal_key, (string)($candidate_target['key'] ?? ''));
                    if (is_wp_error($candidate_gate)) { continue; }
                }
                if ($anchor_target === null || $candidate_type === 'uge_group') { $anchor_target = $candidate_target; }
                if ($candidate_type === 'uge_group') { break; }
            }
            if (is_array($anchor_target)) {
                $anchor_target['_ppar_glossary_neutral_anchor'] = 1;
                return array(
                    'status'=>'ready',
                    'confidence'=>100,
                    'reason'=>'Chefentscheidung: Werbemittel für Glossar freigegeben; kein eindeutiger Themenanker, daher neutraler Materialisierungsanker und allgemeiner Laufzeit-Fallback.',
                    'target'=>$anchor_target,
                    'alternatives'=>array(),
                    'source'=>'manual_approved_glossary_scope',
                );
            }
            return array('status'=>'review','confidence'=>0,'reason'=>'Glossar-Werbeplatz freigegeben, aber kein reales Glossarziel als Materialisierungsanker vorhanden.','target'=>null,'source'=>'glossary_anchor_missing');
        }
        $ranked = array();
        foreach ((array) $targets as $target) {
            if (!is_array($target)) {
                continue;
            }
            $type = sanitize_key((string) ($target['type'] ?? ''));
            if (!in_array($type, $wanted_types, true)) {
                continue;
            }
            if (method_exists($this, 'control_target_gate')) {
                $target_gate = $this->control_target_gate($portal_key, (string) ($target['key'] ?? ''));
                if (is_wp_error($target_gate)) { continue; }
            }
            $target_text = implode(' ', array((string) ($target['label'] ?? ''), (string) ($target['slug'] ?? ''), (string) ($target['description'] ?? '')));
            $target_tokens = $this->output_tokens($target_text);
            $hits = array_values(array_intersect($source_tokens, $target_tokens));
            foreach ($source_tokens as $source_token) {
                foreach ($target_tokens as $target_token) {
                    if (strlen($source_token) >= 5 && strlen($target_token) >= 5 && (strpos($source_token, $target_token) !== false || strpos($target_token, $source_token) !== false)) {
                        $hits[] = $target_token;
                    }
                }
            }
            $hits = array_values(array_unique($hits));
            $score = min(60, count($hits) * 12);
            if ($real_target_evidence_key !== '' && $real_target_evidence_key === sanitize_text_field((string) ($target['key'] ?? ''))) {
                // Derselbe eindeutige Realziel-Beweis, der den generischen
                // Domain-Frühabbruch ersetzt, muss auch in der bestehenden
                // Rangfolge eindeutig gewinnen. Keine Sonderregel pro Anbieter.
                $score += 260;
            }
            $destination_semantic = $this->output_destination_semantic_text($row);
            $target_slug_norm = $this->output_text(str_replace(array('-','_'),' ',(string)($target['slug']??'')));
            if ($destination_semantic !== '' && $target_slug_norm !== '') {
                $dest_tokens = $this->output_tokens($destination_semantic);
                $slug_tokens = $this->output_tokens($target_slug_norm);
                $target_url_path = $this->output_target_public_url_path($target);
                $target_url_tokens = $this->output_tokens(str_replace('/', ' ', $target_url_path));
                $target_url_confirms_slug = $slug_tokens && $target_url_tokens && !array_diff($slug_tokens, $target_url_tokens);
                $missing = array_diff($slug_tokens, $dest_tokens);
                if ($target_url_confirms_slug && $slug_tokens && !$missing) {
                    // Starker Ziel-URL-Beweis nur, wenn die reale WordPress-URL
                    // den Zielslug selbst bestätigt. Stringtreffer allein reichen nicht.
                    $score += 260;
                } elseif ($slug_tokens) {
                    $score += min(60, count(array_intersect($slug_tokens,$dest_tokens))*30);
                }
            }
            $label_norm = $this->output_text((string) ($target['label'] ?? ''));
            $label_parts = preg_split('/\s+>\s+/', (string) ($target['label'] ?? ''));
            $leaf_norm = $this->output_text($label_parts ? end($label_parts) : $label_norm);
            $business_norm = $this->output_text((string) $partner['business_label']);
            if ($business_norm !== '' && (strpos(' ' . $label_norm . ' ', ' ' . $business_norm . ' ') !== false || strpos($business_norm, $leaf_norm) !== false || strpos($leaf_norm, $business_norm) !== false)) {
                $score += 45;
            }
            // Providerunabhängiger Geschäftsbereichsabgleich: zusammengesetzte
            // Bezeichnungen wie „Tierversicherung“ dürfen ein eindeutiges Ziel
            // „Versicherungen & Recht“ erkennen, ohne eine Branchen-Sonderliste.
            $business_tokens = $this->output_tokens($business_norm);
            $business_hits = array();
            foreach ($business_tokens as $business_token) {
                foreach ($target_tokens as $target_token) {
                    if ($business_token === $target_token || (strlen($business_token) >= 5 && strlen($target_token) >= 5 && (strpos($business_token, $target_token) !== false || strpos($target_token, $business_token) !== false))) {
                        $business_hits[$target_token] = true;
                    }
                }
            }
            if ($business_hits) {
                $score += min(90, count($business_hits) * 60);
            }
            foreach ((array) $partner['keywords'] as $keyword) {
                $keyword = $this->output_text($keyword);
                if ($keyword === '') {
                    continue;
                }
                if ($keyword === $leaf_norm || strpos(' ' . $label_norm . ' ', ' ' . $keyword . ' ') !== false) {
                    $score += 70;
                } elseif (strpos($keyword, $leaf_norm) !== false || strpos($leaf_norm, $keyword) !== false) {
                    $score += 55;
                } else {
                    $keyword_tokens = $this->output_tokens($keyword);
                    $score += min(30, count(array_intersect($keyword_tokens, $target_tokens)) * 15);
                }
            }
            if ($specific !== '') {
                $specific_tokens = $this->output_tokens($specific);
                $specific_hits = array_values(array_intersect($specific_tokens, $target_tokens));
                $score += min(30, count($specific_hits) * 15);
                if ($specific === $leaf_norm || strpos(' ' . $specific . ' ', ' ' . $leaf_norm . ' ') !== false) {
                    $score += 55;
                }
            }
            foreach ($domain_terms as $domain_term) {
                if ($domain_term !== '' && $this->output_term_present($combined, $domain_term) && $this->output_term_present($label_norm, $domain_term)) {
                    $score += $hits ? 35 : 15;
                    break;
                }
            }
            if ($score >= 55) {
                // Für die Rangfolge den Rohwert behalten. Ein frühes Kappen auf
                // 100 würde einen exakten Creative-Treffer und einen nur grob
                // passenden Partnertreffer künstlich gleichsetzen.
                $target['raw_score'] = $score;
                $target['score'] = min(100, $score);
                $target['hits'] = $hits;
                $ranked[] = $target;
            }
        }
        usort($ranked, static function($a, $b) {
            $cmp = (int) ($b['raw_score'] ?? $b['score'] ?? 0) <=> (int) ($a['raw_score'] ?? $a['score'] ?? 0);
            if ($cmp !== 0) {
                return $cmp;
            }
            $depth_cmp = absint($b['depth'] ?? 0) <=> absint($a['depth'] ?? 0);
            if ($depth_cmp !== 0) { return $depth_cmp; }
            return strnatcasecmp((string) ($a['label'] ?? ''), (string) ($b['label'] ?? ''));
        });
        if (!$ranked) {
            return array('status'=>'review','confidence'=>0,'reason'=>'Kein sicherer Zieltreffer im Portal.','target'=>null,'source'=>'automatic');
        }
        $best = $ranked[0];
        $best_raw = absint($best['raw_score'] ?? $best['score'] ?? 0);
        $second_raw = isset($ranked[1]) ? absint($ranked[1]['raw_score'] ?? $ranked[1]['score'] ?? 0) : 0;
        $best_score = min(100, $best_raw);
        $hierarchy_safe = false;
        if (isset($ranked[1]) && ($best_raw - $second_raw) < 15) {
            $best_label = $this->output_text((string) ($best['label'] ?? ''));
            $second_label = $this->output_text((string) ($ranked[1]['label'] ?? ''));
            $hierarchy_safe = absint($best['depth'] ?? 0) > absint($ranked[1]['depth'] ?? 0)
                && strpos($best_label, $second_label) !== false;
        }
        if ($best_raw < 72 || ($second_raw > 0 && ($best_raw - $second_raw) < 15 && !$hierarchy_safe)) {
            return array('status'=>'review','confidence'=>$best_score,'reason'=>'Mehrere oder zu schwache Portalziele.','target'=>$best,'alternatives'=>array_slice($ranked, 0, 5),'source'=>'automatic');
        }
        return array('status'=>'ready','confidence'=>$best_score,'reason'=>'Eindeutiger mehrquelliger Zieltreffer.','target'=>$best,'alternatives'=>array_slice($ranked, 1, 4),'source'=>$manual_status === 'approved' ? 'manual_approved_plus_automatic_target' : 'automatic');
    }

    /**
     * Marketplace product cards use contain rendering and a stable provider image
     * URL. For verified eBay BUSINESS products, remote dimension measurement is a
     * quality/health signal, not a prerequisite for public availability. Banners,
     * manual creatives and every other provider keep the strict dimension gate.
     */
    private function output_allows_provisional_ebay_product_asset($row) {
        if (!is_array($row)
            || sanitize_key((string)($row['provider'] ?? '')) !== 'ebay'
            || sanitize_key((string)($row['source_kind'] ?? '')) !== 'ebay_business_item'
            || sanitize_key((string)($row['creative_type'] ?? '')) !== 'product'
            || sanitize_key((string)($row['source_status'] ?? 'active')) !== 'active'
            || sanitize_key((string)($row['availability_state'] ?? 'active')) !== 'active') { return false; }
        $image_url = esc_url_raw((string)($row['image_url'] ?? ''));
        if ($image_url === '' || stripos($image_url, 'https://') !== 0 || (function_exists('wp_http_validate_url') && !wp_http_validate_url($image_url))) { return false; }
        $payload = json_decode((string)($row['payload'] ?? ''), true);
        $payload = is_array($payload) ? $payload : array();
        if (strtoupper(sanitize_key((string)($payload['ebay_seller_account_type'] ?? ''))) !== 'BUSINESS') { return false; }
        if (sanitize_key((string)($payload['ebay_business_match_contract'] ?? '')) !== 'concept_v3') { return false; }
        if (sanitize_key((string)($payload['ebay_verified_product_concept'] ?? '')) === '') { return false; }
        return true;
    }

    /**
     * V6.72.38 – eine technische Wahrheit fuer Slot-Eignung.
     * Dieselbe Pruefung wird vom produktiven Planer und vom Backend-Werbeplatzfilter
     * verwendet. Der Filter darf keine eigenen Format-/Massregeln nachbauen.
     */
    private function output_row_matches_slot_rule($row, $rule, $creative_type = 'banner') {
        if (!is_array($row) || !is_array($rule)) { return false; }
        $creative_type = sanitize_key((string) $creative_type) === 'product' ? 'product' : 'banner';
        if (sanitize_key((string) ($rule['creative_type'] ?? '')) !== $creative_type) { return false; }
        $width = absint($row['width'] ?? 0);
        $height = absint($row['height'] ?? 0);
        $provisional_ebay_product = $creative_type === 'product' && $this->output_allows_provisional_ebay_product_asset($row) && ($width <= 0 || $height <= 0);
        if (($width <= 0 || $height <= 0) && !$provisional_ebay_product) { return false; }
        if ($provisional_ebay_product) {
            return sanitize_key((string) ($rule['crop'] ?? '')) === 'contain';
        }
        $ratio = $width / $height;
        $upscale_max = max(1.0, min(1.10, (float) ($rule['upscale_max'] ?? 1.0)));
        $required_scale = max(
            1.0,
            absint($rule['min_width'] ?? 0) > 0 ? absint($rule['min_width']) / $width : 1.0,
            absint($rule['min_height'] ?? 0) > 0 ? absint($rule['min_height']) / $height : 1.0
        );
        if ($required_scale > ($upscale_max + 0.00001)) { return false; }
        if ($ratio < (float) ($rule['ratio_min'] ?? 0) || $ratio > (float) ($rule['ratio_max'] ?? 999)) { return false; }
        return true;
    }

    private function output_format_slot($row, $portal, $target, $creative_type = 'banner') {
        $matrix = $this->output_slot_matrix($portal);
        $width = absint($row['width'] ?? 0);
        $height = absint($row['height'] ?? 0);
        $creative_type = sanitize_key((string) $creative_type) === 'product' ? 'product' : 'banner';
        $provisional_ebay_product = $creative_type === 'product' && $this->output_allows_provisional_ebay_product_asset($row) && ($width <= 0 || $height <= 0);
        if (($width <= 0 || $height <= 0) && !$provisional_ebay_product) {
            return new WP_Error('output_dimensions_unverified', 'Reale Bildmaße sind nicht verifiziert.');
        }
        $ratio = ($width > 0 && $height > 0) ? ($width / $height) : 0.0;
        $target_type = sanitize_key((string) ($target['type'] ?? ''));
        $target_context = sanitize_key((string) ($target['context'] ?? ''));
        $matches = array();
        foreach ($matrix as $slot_id => $rule) {
            if (!is_array($rule) || sanitize_key((string) ($rule['creative_type'] ?? '')) !== $creative_type) { continue; }
            if (!in_array($target_type, array_map('sanitize_key', (array) ($rule['target_types'] ?? array())), true)) { continue; }
            $contexts = array_map('sanitize_key', (array) ($rule['target_contexts'] ?? array()));
            // Leere target_contexts bedeuten: semantisches Ziel (z. B. gepflegte
            // Glossar-Hauptseite/-Kategorie) darf unabhängig von dessen Seitentemplate
            // an diesen Render-Slot gebunden werden. Die Renderposition selbst bleibt
            // durch die Slot-ID hart festgelegt.
            if ($contexts && ($target_context === '' || !in_array($target_context, $contexts, true))) { continue; }
            if (!$this->output_row_matches_slot_rule($row, $rule, $creative_type)) { continue; }
            if (method_exists($this, 'control_slot_gate')) {
                $slot_gate = $this->control_slot_gate((string) ($portal['key'] ?? ''), (string) $slot_id);
                if (is_wp_error($slot_gate)) { continue; }
            }
            $matches[$slot_id] = $rule;
        }
        $manual = $this->output_portal_decision((string) ($portal['key'] ?? ''), (string) ($row['identity_hash'] ?? ''));
        $manual_payload = is_array($manual['payload'] ?? null) ? $manual['payload'] : array();
        $fixed_slot_id = sanitize_key((string) ($manual_payload['slot_id'] ?? ''));
        if ((string) ($manual['manual_status'] ?? 'automatic') === 'approved' && $fixed_slot_id !== '') {
            if (method_exists($this, 'control_slot_gate')) {
                $fixed_slot_gate = $this->control_slot_gate((string) ($portal['key'] ?? ''), $fixed_slot_id);
                if (is_wp_error($fixed_slot_gate)) { return $fixed_slot_gate; }
            }
            if (!isset($matches[$fixed_slot_id])) {
                return new WP_Error('control_fixed_slot_invalid', 'Fest vorgegebener Designslot passt nicht zu Zielkontext oder realem Bildformat.');
            }
            return array('slot_id'=>$fixed_slot_id,'rule'=>$matches[$fixed_slot_id]);
        }
        if (!$matches) {
            return new WP_Error('output_no_design_slot', 'Kein realer Designslot passt zu Zielkontext und Bildformat.');
        }
        $priority = $creative_type === 'product'
            ? array('hub_product_1','category_product_1','journal_product_1','hub_product_2','category_product_2','journal_product_2','hub_product_3','category_product_3','journal_product_3')
            : array('start_after_topics','product_after_category_tiles','glossary_single_desktop_banner','glossary_single_mobile_banner','post_inline_banner','glossary_overview_banner','journal_banner','anzeigenmarkt_top_banner','anzeigenmarkt_category_banner','hub_after_cards','hub_grid_card');

        // V6.72.175: Das gewaehlte Portalziel bestimmt zuerst seinen realen
        // Werbeplatzkontext. Ein explizit passender Hub-/Kategorie-/Journal-Slot
        // muss vor einem kontextlosen semantischen Fallback gewinnen. Die
        // bestehende Prioritaet innerhalb derselben Kontextstufe bleibt erhalten.
        if ($target_context !== '') {
            foreach ($priority as $slot_id) {
                if (!isset($matches[$slot_id])) { continue; }
                $contexts = array_map('sanitize_key', (array) ($matches[$slot_id]['target_contexts'] ?? array()));
                if ($contexts && in_array($target_context, $contexts, true)) {
                    return array('slot_id'=>$slot_id,'rule'=>$matches[$slot_id]);
                }
            }
        }
        foreach ($priority as $slot_id) { if (isset($matches[$slot_id])) { return array('slot_id'=>$slot_id,'rule'=>$matches[$slot_id]); } }
        $slot_id = array_key_first($matches);
        return array('slot_id'=>$slot_id,'rule'=>$matches[$slot_id]);
    }
    private function output_source_fingerprint($row, $portal, $output_type, $target, $slot_id = '') {
        $partner = $this->output_partner_evidence($row);
        $profile = is_array($partner['profile'] ?? null) ? $partner['profile'] : array();
        $data = array(
            'creative_source_hash'=>(string) ($row['source_hash'] ?? ''),
            'creative_identity'=>(string) ($row['identity_hash'] ?? ''),
            'creative_type'=>(string) ($row['creative_type'] ?? ''),
            'title'=>(string) ($row['title'] ?? ''),'description'=>(string) ($row['description'] ?? ''),'tags'=>(string) ($row['tags'] ?? ''),
            'destination_url'=>(string) ($row['destination_url'] ?? ''),'tracking_url'=>(string) ($row['tracking_url'] ?? ''),'image_url'=>(string) ($row['image_url'] ?? ''),
            'image_hash'=>$this->output_row_image_hash($row),'width'=>absint($row['width'] ?? 0),'height'=>absint($row['height'] ?? 0),
            'partner_business'=>(string) ($partner['business_label'] ?? ''),'partner_keywords'=>array_values((array) ($partner['keywords'] ?? array())),
            'partner_sector'=>(string) ($partner['primary_sector'] ?? ''),'partner_description'=>(string) ($partner['programme_description'] ?? ''),'partner_domains'=>array_values((array) ($partner['domains'] ?? array())),
            'profile_enabled'=>!empty($profile['enabled']),'profile_updated'=>absint($profile['updated_at'] ?? 0),
            'portal_key'=>(string) ($portal['key'] ?? ''),'adapter'=>(string) ($portal['adapter'] ?? ''),'adapter_version'=>(string) ($portal['adapter_version'] ?? ''),
            'domain_terms'=>array_values((array) ($portal['domain_terms'] ?? array())),'negative_terms'=>array_values((array) ($portal['negative_terms'] ?? array())),
            'output_type'=>sanitize_key((string) $output_type),'target_key'=>(string) ($target['key'] ?? ''),'target_context'=>(string) ($target['context'] ?? ''),'slot_id'=>sanitize_key((string) $slot_id),
        );
        foreach (array('partner_keywords','partner_domains','domain_terms','negative_terms') as $key) { sort($data[$key], SORT_STRING); }
        return hash('sha256', wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public function output_portal_status_summary($identity_hash) {
        global $wpdb;
        $identity_hash = strtolower(sanitize_text_field((string) $identity_hash));
        if (!preg_match('/^[a-f0-9]{64}$/', $identity_hash)) { return 'Noch keine portalbezogene Planung'; }
        $rows = $wpdb->get_results($wpdb->prepare("SELECT portal_key, output_type, target_label, status FROM {$this->output_objects_table()} WHERE creative_identity_hash=%s ORDER BY portal_key, output_type", $identity_hash), ARRAY_A);
        if (!$rows) { return 'Noch keine portalbezogene Planung'; }
        $registry = $this->output_portal_registry(); $parts = array();
        foreach ((array) $rows as $row) {
            $key = sanitize_key((string) ($row['portal_key'] ?? '')); $label = sanitize_text_field((string) ($registry[$key]['label'] ?? $key));
            $parts[] = $label . ': ' . sanitize_text_field((string) ($row['output_type'] ?? '')) . ' · ' . sanitize_text_field((string) ($row['status'] ?? 'review')) . (!empty($row['target_label']) ? ' · ' . sanitize_text_field((string) $row['target_label']) : '');
        }
        return implode(' | ', $parts);
    }
    private function output_object_key($portal_key, $creative_hash, $output_type, $target_key, $slot_id = '') {
        return hash('sha256', implode('|', array($portal_key, $creative_hash, $output_type, $target_key, $slot_id)));
    }

    private function output_deactivate_materialized_object($row, $reason = 'Ausgabe ersetzt oder gesperrt.') {
        if (!is_array($row)) {
            return;
        }
        $portal = $this->output_portal_by_key((string) ($row['portal_key'] ?? ''), true);
        if (is_wp_error($portal)) {
            return;
        }
        $adapter = sanitize_key((string) ($portal['adapter'] ?? ''));
        if (in_array($adapter, array('wordpress_local','wordpress_multisite'), true)) {
            $this->output_with_portal($portal, function() use ($row) {
                $campaign_id = absint($row['campaign_post_id'] ?? 0);
                if ($campaign_id > 0) {
                    $campaign = $this->output_campaign_by_post_id($campaign_id);
                    if (is_array($campaign)) {
                        $campaign['active'] = false;
                        $this->save_campaign_record($campaign, $campaign_id);
                    }
                }
                $listing_id = absint($row['listing_post_id'] ?? 0);
                if ($listing_id > 0 && function_exists('get_post') && function_exists('wp_update_post')) {
                    $listing = get_post($listing_id);
                    if ($listing && (string) $listing->post_status === 'publish') {
                        wp_update_post(array('ID'=>$listing_id,'post_status'=>'draft'));
                    }
                }
                return true;
            });
        } else {
            $callbacks = is_array($portal['callbacks'] ?? null) ? $portal['callbacks'] : array();
            if (!empty($callbacks['deactivate']) && is_callable($callbacks['deactivate'])) {
                call_user_func($callbacks['deactivate'], $row, $portal, $reason);
            }
        }
    }

    private function output_supersede_conflicting_objects($data, $object_key) {
        global $wpdb;
        $table = $this->output_objects_table();
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE portal_key=%s AND creative_identity_hash=%s AND output_type=%s AND object_key<>%s AND status NOT IN ('superseded','blocked_manual')",
            (string) ($data['portal_key'] ?? ''),
            (string) ($data['creative_identity_hash'] ?? ''),
            (string) ($data['output_type'] ?? ''),
            (string) $object_key
        ), ARRAY_A);
        foreach ((array) $rows as $row) {
            $this->output_deactivate_materialized_object($row, 'Durch neu bewertetes Ausgabeobjekt ersetzt.');
            $wpdb->update($table, array(
                'status'=>'superseded',
                'decision_reason'=>'Durch neu bewertetes Ziel, Format oder Creative ersetzt.',
                'updated_at'=>time(),
            ), array('id'=>absint($row['id'])));
        }
    }

    private function output_object_upsert($data) {
        global $wpdb;
        $table = $this->output_objects_table(); $now = time();
        $data = wp_parse_args((array) $data, array(
            'portal_key'=>'','portal_adapter'=>'','creative_identity_hash'=>'','provider'=>'','partner_external_id'=>'','output_type'=>'','target_type'=>'','target_key'=>'','target_label'=>'','slot_id'=>'','status'=>'review','confidence'=>0,'decision_source'=>'','decision_reason'=>'','campaign_post_id'=>0,'listing_post_id'=>0,'tracking_url'=>'','image_url'=>'','image_width'=>0,'image_height'=>0,'image_hash'=>'','source_fingerprint'=>'','payload'=>'','last_verified'=>0,'created_at'=>$now,'updated_at'=>$now,
        ));
        $data['object_key'] = $this->output_object_key($data['portal_key'], $data['creative_identity_hash'], $data['output_type'], $data['target_key'], $data['slot_id']);
        // Atomic replacement: conflicting published output is superseded only
        // AFTER the new object has been materialized successfully.
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE object_key=%s", $data['object_key']), ARRAY_A);
        if ($existing) {
            $data['created_at'] = absint($existing['created_at'] ?? $now);
            $content_changed = (string) ($existing['source_fingerprint'] ?? '') === '' || !hash_equals((string) ($existing['source_fingerprint'] ?? ''), (string) ($data['source_fingerprint'] ?? ''));
            $incoming_status = sanitize_key((string) ($data['status'] ?? 'review'));
            $incoming_blocked = strpos($incoming_status, 'blocked') === 0 || in_array($incoming_status, array('quarantine','stale','ended'), true);
            if (in_array((string) ($existing['status'] ?? ''), array('blocked_manual','paused_manual'), true)) {
                $data['status'] = (string) $existing['status'];
            } elseif ((string) ($existing['status'] ?? '') === 'published' && $incoming_blocked) {
                $this->output_deactivate_materialized_object($existing, (string) ($data['decision_reason'] ?? 'Creative-Quelle wurde gesperrt.'));
                $data['status'] = $incoming_status;
            } elseif ((string) ($existing['status'] ?? '') === 'published' && !$content_changed) {
                $data['status'] = 'published';
            } elseif ((string) ($existing['status'] ?? '') === 'published' && $content_changed) {
                // Keep the currently published campaign live while the same
                // object is updated. The materializer writes the replacement to
                // the same campaign; a failure therefore leaves Last-Known-Good
                // visible instead of creating a frontend outage.
                $data['status'] = 'published';
                $data['decision_reason'] = 'Quelldaten geändert; Last-Known-Good bleibt bis zur erfolgreichen atomaren Aktualisierung veröffentlicht.';
            }
            $data['campaign_post_id'] = absint($existing['campaign_post_id'] ?? ($data['campaign_post_id'] ?? 0));
            $data['listing_post_id'] = absint($existing['listing_post_id'] ?? ($data['listing_post_id'] ?? 0));
            $wpdb->update($table, $data, array('id'=>absint($existing['id'])));
            return absint($existing['id']);
        }
        $wpdb->insert($table, $data);
        return absint($wpdb->insert_id);
    }
    private function output_campaign_by_post_id($post_id) {
        $post_id = absint($post_id);
        if ($post_id <= 0 || !method_exists($this, 'get_campaigns')) {
            return null;
        }
        foreach ((array) $this->get_campaigns() as $campaign) {
            if (is_array($campaign) && absint($campaign['post_id'] ?? 0) === $post_id) {
                return $campaign;
            }
        }
        return null;
    }

    public function output_remove_creative_from_automation($identity_hash, $portal_key = '', $werbeplatz_scope = '') {
        $identity_hash = strtolower(sanitize_text_field((string) $identity_hash));
        $portal_key = sanitize_key((string) ($portal_key !== '' ? $portal_key : $this->output_local_portal_key()));
        $werbeplatz_scope = sanitize_key((string) $werbeplatz_scope);
        if (!preg_match('/^[a-f0-9]{64}$/', $identity_hash) || $portal_key === '') {
            return new WP_Error('remove_automation_invalid', 'Werbemittel oder Portal ist ungültig.');
        }
        $portal = $this->output_portal_by_key($portal_key, true);
        if (is_wp_error($portal)) { return $portal; }

        // V6.72.82: Die Vollautomatik kennt nur ein bewusstes hartes Veto als
        // manuelle Sperre. „Automatik verwenden“ kann dieses Veto spaeter wieder
        // auf automatic setzen; ein fehlender Klick ist niemals Voraussetzung.
        $payload = array('removed_from_automation'=>1);
        if ($werbeplatz_scope !== '') { $payload['werbeplatz_scope'] = $werbeplatz_scope; }
        $decision = $this->output_set_portal_decision(
            $portal_key,
            $identity_hash,
            'veto',
            'Werbemittel ausdrücklich aus der automatischen Portal-Ausspielung entfernt.',
            $payload
        );
        if (is_wp_error($decision)) { return $decision; }

        $allowed_slots = array();
        if ($werbeplatz_scope !== '' && method_exists($this, 'output_werbeplatz_filter_profiles')) {
            $profiles = $this->output_werbeplatz_filter_profiles($portal);
            if (!empty($profiles[$werbeplatz_scope]['rules']) && is_array($profiles[$werbeplatz_scope]['rules'])) {
                $allowed_slots = array_values(array_filter(array_map('sanitize_key', array_keys($profiles[$werbeplatz_scope]['rules']))));
            }
        }
        global $wpdb;
        $table = $this->output_objects_table();
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE portal_key=%s AND creative_identity_hash=%s",
            $portal_key,
            $identity_hash
        ), ARRAY_A);
        $removed = 0;
        foreach ((array) $rows as $row) {
            $slot_id = sanitize_key((string)($row['slot_id'] ?? ''));
            if ($allowed_slots && !in_array($slot_id, $allowed_slots, true)) { continue; }
            $this->output_deactivate_materialized_object($row, 'Werbemittel aus Automatik entfernt.');
            $wpdb->update($table, array(
                'status'=>'removed_manual',
                'decision_source'=>'manual_remove',
                'decision_reason'=>'Werbemittel aus Automatik entfernt.',
                'updated_at'=>time(),
            ), array('id'=>absint($row['id'])));
            $removed++;
        }
        return array('removed'=>$removed,'scope'=>$werbeplatz_scope,'portal_key'=>$portal_key);
    }

    public function output_block_creative($identity_hash, $reason = 'Creative gesperrt.', $portal_key = '') {
        $identity_hash = strtolower(sanitize_text_field((string) $identity_hash));
        $portal_key = sanitize_key((string) ($portal_key !== '' ? $portal_key : $this->output_local_portal_key()));
        if (!preg_match('/^[a-f0-9]{64}$/', $identity_hash) || $portal_key === '') {
            return 0;
        }
        $decision = $this->output_set_portal_decision($portal_key, $identity_hash, 'veto', $reason);
        if (is_wp_error($decision)) {
            return 0;
        }
        global $wpdb;
        $table = $this->output_objects_table();
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE portal_key=%s AND creative_identity_hash=%s", $portal_key, $identity_hash), ARRAY_A);
        foreach ((array) $rows as $row) {
            $this->output_deactivate_materialized_object($row, $reason);
        }
        $wpdb->update($table, array('status'=>'blocked_manual','decision_source'=>'manual_veto','decision_reason'=>sanitize_text_field((string) $reason),'updated_at'=>time()), array('portal_key'=>$portal_key,'creative_identity_hash'=>$identity_hash));
        return count((array) $rows);
    }

    private function output_creative_row($identity_hash) {
        $identity_hash = strtolower(sanitize_text_field((string) $identity_hash));
        $use_cache = $this->output_request_local_read_cache_allowed();
        if ($use_cache && array_key_exists($identity_hash, $this->output_creative_row_cache)) {
            return $this->output_creative_row_cache[$identity_hash];
        }

        // V6.72.169: this is an exact creative-identity lookup. A normal frontend
        // request must never normalize every campaign and preload the complete
        // creative library merely to answer one exact hash. Cache only identities
        // actually requested by the current page.
        global $wpdb;
        $table = $this->creative_library_table();
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE identity_hash=%s", $identity_hash), ARRAY_A);
        if ($use_cache) {
            $this->output_creative_row_cache[$identity_hash] = $row;
        }
        return $row;
    }

    private function output_listing_image_size() {
        if (!function_exists('wp_get_registered_image_subsizes')) {
            return new WP_Error('listing_image_sizes_unavailable', 'WordPress-Bildgrößen sind nicht verfügbar.');
        }
        $sizes = wp_get_registered_image_subsizes();
        foreach (array('hp_landscape_large','hp_landscape_small','hp_listing_image','hp_large') as $name) {
            if (!empty($sizes[$name]['width']) && !empty($sizes[$name]['height'])) {
                return array('name'=>$name,'width'=>absint($sizes[$name]['width']),'height'=>absint($sizes[$name]['height']));
            }
        }
        return new WP_Error('listing_image_size_missing', 'Keine registrierte HivePress-Listingbildgröße gefunden.');
    }
    private function output_listing_asset_compatibility($row, $portal = null) {
        if (is_array($portal)) {
            $adapter = sanitize_key((string) ($portal['adapter'] ?? ''));
            if (!in_array($adapter, array('wordpress_local','wordpress_multisite'), true)) {
                $callbacks = is_array($portal['callbacks'] ?? null) ? $portal['callbacks'] : array();
                if (empty($callbacks['validate_listing_asset']) || !is_callable($callbacks['validate_listing_asset'])) {
                    return new WP_Error('portal_listing_asset_validator_missing', 'Externer Portaladapter besitzt keine bestätigte Listing-Bildprüfung.');
                }
                $checked = call_user_func($callbacks['validate_listing_asset'], $row, $portal, self::PORTAL_ADAPTER_VERSION);
                return is_array($checked) ? $checked : (is_wp_error($checked) ? $checked : new WP_Error('portal_listing_asset_invalid', 'Externe Listing-Bildprüfung lieferte kein belastbares Ergebnis.'));
            }
            $result = $this->output_with_portal($portal, function() use ($row) { return $this->output_listing_asset_compatibility($row, null); });
            return $result;
        }
        $size = $this->output_listing_image_size();
        if (is_wp_error($size)) { return $size; }
        $width = absint($row['width'] ?? 0); $height = absint($row['height'] ?? 0);
        $payload = json_decode((string) ($row['payload'] ?? ''), true); $payload = is_array($payload) ? $payload : array();
        if (!in_array((string) ($payload['_dimension_state'] ?? ''), array('verified','mismatch'), true) || $width <= 0 || $height <= 0 || $this->output_row_image_hash($row) === '') {
            return new WP_Error('listing_image_unverified', 'Listingbild ist nicht real vermessen und verifiziert.');
        }
        $target_width = absint($size['width'] ?? 0); $target_height = absint($size['height'] ?? 0);
        if ($target_width <= 0 || $target_height <= 0) { return new WP_Error('listing_image_size_invalid', 'HivePress-Listingbildgröße ist ungültig.'); }
        $source_ratio = $width / $height; $target_ratio = $target_width / $target_height;
        $ratio_deviation = abs($source_ratio - $target_ratio) / $target_ratio;
        if ($source_ratio < 0.70 || $source_ratio > 2.40 || $ratio_deviation > 0.30) {
            return new WP_Error('listing_image_format_incompatible', 'Creative-Format passt nicht sicher zum registrierten HivePress-Listingbild. Ein passendes Kartenformat ist erforderlich.');
        }
        if ($width < min(300, $target_width) || $height < min(180, $target_height)) {
            return new WP_Error('listing_image_resolution_too_small', 'Creative-Auflösung ist für ein HivePress-Listing zu klein.');
        }
        return array('size'=>$size,'source_width'=>$width,'source_height'=>$height,'ratio_deviation'=>$ratio_deviation);
    }
    private function output_sideload_creative_image($listing_id, $row) {
        $listing_id = absint($listing_id);
        $image_url = esc_url_raw((string) ($row['image_url'] ?? ''));
        if ($listing_id <= 0 || $image_url === '') {
            return new WP_Error('listing_creative_image_missing', 'Creative-Bild fehlt.');
        }
        $compatibility = $this->output_listing_asset_compatibility($row, null);
        if (is_wp_error($compatibility)) {
            return $compatibility;
        }
        $size = $compatibility['size'];
        if (!function_exists('media_sideload_image')) {
            foreach (array('file.php','media.php','image.php') as $file) {
                $path = ABSPATH . 'wp-admin/includes/' . $file;
                if (is_readable($path)) {
                    require_once $path;
                }
            }
        }
        if (!function_exists('media_sideload_image') || !function_exists('set_post_thumbnail')) {
            return new WP_Error('listing_media_api_missing', 'WordPress-Medienfunktionen sind nicht verfügbar.');
        }
        $expected_image_hash = $this->output_row_image_hash($row);
        $thumb = function_exists('get_post_thumbnail_id') ? absint(get_post_thumbnail_id($listing_id)) : 0;
        $old_source = $thumb > 0 ? (string) get_post_meta($thumb, '_ppar_creative_source_url', true) : '';
        $old_image_hash = $thumb > 0 ? (string) get_post_meta($thumb, '_ppar_creative_image_hash', true) : '';
        if ($thumb > 0 && $old_source === $image_url && $expected_image_hash !== '' && hash_equals($expected_image_hash, $old_image_hash)) {
            return array('attachment_id'=>$thumb,'size'=>$size,'reused'=>true);
        }
        $attachment_id = media_sideload_image($image_url, $listing_id, sanitize_text_field((string) ($row['title'] ?? $row['partner_name'] ?? 'Affiliate-Creative')), 'id');
        if (is_wp_error($attachment_id)) {
            return $attachment_id;
        }
        if (!set_post_thumbnail($listing_id, absint($attachment_id))) {
            return new WP_Error('listing_thumbnail_failed', 'Creative-Bild konnte nicht als Listingbild gesetzt werden.');
        }
        update_post_meta(absint($attachment_id), '_ppar_creative_source_url', $image_url);
        update_post_meta(absint($attachment_id), '_ppar_creative_identity_hash', sanitize_text_field((string) ($row['identity_hash'] ?? '')));
        update_post_meta(absint($attachment_id), '_ppar_creative_image_hash', $expected_image_hash);
        return array('attachment_id'=>absint($attachment_id),'size'=>$size);
    }

    private function output_materialize_listing($object_id, $portal, $row, $classification) {
        $target = is_array($classification['target'] ?? null) ? $classification['target'] : array();
        if ((string) ($target['type'] ?? '') !== 'hp_listing_category' || absint($target['id'] ?? 0) <= 0) {
            return new WP_Error('listing_target_invalid', 'Eindeutige HivePress-Kategorie fehlt.');
        }
        if (!function_exists('post_type_exists') || !post_type_exists('hp_listing') || !function_exists('taxonomy_exists') || !taxonomy_exists('hp_listing_category')) {
            return new WP_Error('listing_hivepress_missing', 'HivePress-Listingmodell ist nicht verfügbar.');
        }
        $tracking_url = esc_url_raw((string) ($row['tracking_url'] ?? ''));
        if ($tracking_url === '' || !wp_http_validate_url($tracking_url)) {
            return new WP_Error('listing_tracking_invalid', 'Originaler Creative-Trackinglink fehlt oder ist ungültig.');
        }
        $partner = $this->output_partner_evidence($row);
        $business = sanitize_text_field((string) $partner['business_label']);
        if ($business === '') {
            return new WP_Error('listing_business_missing', 'Bestätigter Geschäftsbereich fehlt.');
        }
        $title = trim(sanitize_text_field((string) ($row['partner_name'] ?? '')) . ' – ' . $business, " –\t\n\r\0\x0B");
        $description = sanitize_textarea_field((string) ($row['description'] ?? ''));
        $content = '<p><strong>Angebot:</strong> ' . esc_html($business) . '</p>';
        if ($description !== '' && $description !== (string) ($row['title'] ?? '')) {
            $content .= '<p>' . esc_html($description) . '</p>';
        }
        $content .= '<p class="ppar-listing-creative"><a href="' . esc_url($tracking_url) . '" rel="sponsored nofollow noopener" target="_blank"><img src="' . esc_url((string) ($row['image_url'] ?? '')) . '" alt="' . esc_attr((string) ($row['title'] ?? $business)) . '" loading="lazy" decoding="async"></a></p>';
        global $wpdb;
        $table = $this->output_objects_table();
        $stored = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", absint($object_id)), ARRAY_A);
        $listing_id = absint($stored['listing_post_id'] ?? 0);
        if ($listing_id <= 0 && function_exists('get_posts')) {
            $ids = get_posts(array('post_type'=>'hp_listing','post_status'=>array('draft','pending','publish','private'),'meta_key'=>'_ppar_output_object_key','meta_value'=>(string) ($stored['object_key'] ?? ''),'posts_per_page'=>1,'fields'=>'ids'));
            $listing_id = $ids ? absint($ids[0]) : 0;
        }
        $post_data = array(
            'post_type'=>'hp_listing',
            'post_title'=>$title,
            'post_content'=>$content,
            'post_excerpt'=>$business,
            'post_status'=>'draft',
        );
        if ($listing_id > 0) {
            $current = get_post($listing_id);
            if ($current && (string) $current->post_status === 'publish' && (string) ($stored['status'] ?? '') === 'published') {
                $post_data['post_status'] = 'publish';
            }
            $post_data['ID'] = $listing_id;
            $result = wp_update_post($post_data, true);
        } else {
            $result = wp_insert_post($post_data, true);
        }
        if (is_wp_error($result) || absint($result) <= 0) {
            return is_wp_error($result) ? $result : new WP_Error('listing_save_failed', 'HivePress-Listing konnte nicht gespeichert werden.');
        }
        $listing_id = absint($result);
        $term_result = wp_set_post_terms($listing_id, array(absint($target['id'])), 'hp_listing_category', false);
        if (is_wp_error($term_result)) {
            return $term_result;
        }
        update_post_meta($listing_id, 'hp_url', $tracking_url);
        $read_back = (string) get_post_meta($listing_id, 'hp_url', true);
        if ($read_back !== $tracking_url) {
            return new WP_Error('listing_tracking_roundtrip', 'Der originale Trackinglink wurde nicht zeichengetreu gespeichert.');
        }
        update_post_meta($listing_id, '_ppar_output_object_key', sanitize_text_field((string) ($stored['object_key'] ?? '')));
        update_post_meta($listing_id, '_ppar_creative_identity_hash', sanitize_text_field((string) ($row['identity_hash'] ?? '')));
        update_post_meta($listing_id, '_ppar_partner_identity', sanitize_key((string) ($row['provider'] ?? '')) . ':' . sanitize_text_field((string) ($row['partner_external_id'] ?? '')));
        update_post_meta($listing_id, '_ppar_tracking_source', 'creative_original');
        $image = $this->output_sideload_creative_image($listing_id, $row);
        if (is_wp_error($image)) {
            return $image;
        }
        $preview = function_exists('get_preview_post_link') ? get_preview_post_link($listing_id) : add_query_arg('preview', 'true', get_permalink($listing_id));
        $wpdb->update($table, array(
            'listing_post_id'=>$listing_id,
            'status'=>get_post_status($listing_id) === 'publish' ? 'published' : 'draft',
            'decision_reason'=>'Listing aus dem verknüpften Creative erzeugt; Original-Trackinglink gespeichert.',
            'payload'=>wp_json_encode(array('preview_url'=>$preview,'image_size'=>$image['size'] ?? array()), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            'last_verified'=>time(),
            'updated_at'=>time(),
        ), array('id'=>absint($object_id)));
        return array('listing_id'=>$listing_id,'preview_url'=>$preview);
    }

    private function output_campaign_target_key($target) {
        $slug = sanitize_key((string) ($target['slug'] ?? ''));
        $type = sanitize_key((string) ($target['type'] ?? ''));
        $context = sanitize_key((string) ($target['context'] ?? ''));
        if ($context === 'journal') { return $slug !== '' ? 'journal:' . $slug : ''; }
        if ($context === 'anzeigenmarkt') { return 'market:anzeigenmarkt'; }
        if ($type === 'category') { return $slug !== '' ? 'category:' . $slug : ''; }
        if ($type === 'page') { return $slug !== '' ? 'page:' . $slug : ''; }
        if ($type === 'hp_listing_category') { return $slug !== '' ? 'market:' . $slug : ''; }
        // V6.72.49: Glossarziele sind echte Materialisierungsziele. 6.72.48
        // klassifizierte den freigegebenen Glossar-Scope auf uge_group, aber
        // output_campaign_target_key() verwarf genau diesen Zieltyp. Dadurch
        // brach output_save_local_campaign() mit campaign_exact_target_missing
        // ab und es konnte trotz READY-Planung keine aktive Kampagne entstehen.
        if ($type === 'uge_group') { return $slug !== '' ? 'uge_group:' . $slug : ''; }
        if ($type === 'uge_term') { return $slug !== '' ? 'uge_term:' . $slug : ''; }
        return '';
    }

    /**
     * OTTO is a logical product source inside the existing Awin transport.
     * No second provider adapter is created: Awin remains responsible for
     * programme status, feed, tracking and synchronization.
     */
    private function output_is_otto_awin_product($row) {
        return is_array($row)
            && sanitize_key((string) ($row['provider'] ?? '')) === 'awin'
            && sanitize_key((string) ($row['source_kind'] ?? '')) === 'product'
            && sanitize_key((string) ($row['creative_type'] ?? '')) === 'product'
            && absint($row['partner_external_id'] ?? 0) === self::OTTO_AWIN_ADVERTISER_ID;
    }

    private function output_otto_seller_name($row) {
        if (!is_array($row)) { return ''; }
        $payload = json_decode((string) ($row['payload'] ?? ''), true);
        $payload = is_array($payload) ? $payload : array();
        return sanitize_text_field((string) ($payload['seller_name'] ?? ''));
    }

    /**
     * Automatic public OTTO product output is allowed only after the existing
     * Awin programme gate, real image verification, tracking validation and
     * unambiguous automatic portal classification have all passed.
     */
    private function output_otto_awin_auto_allowed($row, $classification, $output_type) {
        if ($output_type !== 'product_campaign' || !$this->output_is_otto_awin_product($row)) {
            return false;
        }
        if (sanitize_key((string) ($classification['status'] ?? '')) !== 'ready'
            || sanitize_key((string) ($classification['source'] ?? '')) !== 'automatic') {
            return false;
        }
        if (sanitize_key((string) ($row['source_status'] ?? 'active')) !== 'active'
            || sanitize_key((string) ($row['availability_state'] ?? 'active')) !== 'active') {
            return false;
        }
        if (absint($row['width'] ?? 0) <= 0 || absint($row['height'] ?? 0) <= 0) {
            return false;
        }
        $image_hash = strtolower(trim((string) $this->output_row_image_hash($row)));
        if (!preg_match('/^[a-f0-9]{64}$/', $image_hash)) {
            return false;
        }
        $tracking_url = esc_url_raw((string) ($row['tracking_url'] ?? ''));
        if ($tracking_url === '' || !wp_http_validate_url($tracking_url)) {
            return false;
        }
        // OTTO requires the concrete marketplace seller for every specific
        // product advertisement. Missing seller evidence blocks automatic output.
        if ($this->output_otto_seller_name($row) === '') {
            return false;
        }
        $advertiser_id = absint($row['partner_external_id'] ?? 0);
        if ($advertiser_id <= 0 || !method_exists($this, 'awin_programme_gate_validate')) {
            return false;
        }
        return !is_wp_error($this->awin_programme_gate_validate($advertiser_id));
    }

    /**
     * One verified OTTO product may compete for all equivalent product positions.
     * Runtime ranking selects position 1/2/3, while category target keys also make
     * the same product eligible for matching editorial posts.
     */
    private function output_otto_product_placements($target, $slot_id) {
        $placements = array();
        $slot_id = sanitize_key((string) $slot_id);
        if ($slot_id !== '') { $placements[] = $slot_id; }
        $context = sanitize_key((string) ($target['context'] ?? ''));
        $target_type = sanitize_key((string) ($target['type'] ?? ''));
        if (in_array($context, array('category','leaf','leaf_category','hub2'), true)) {
            $placements[] = 'category_product';
        }
        if ($context === 'hub1') {
            $placements = array_merge($placements, array('hub_product_1','hub_product_2','hub_product_3'));
        }
        if ($context === 'journal') {
            $placements = array_merge($placements, array('journal_product_1','journal_product_2','journal_product_3'));
        }
        // Every verified OTTO product may also satisfy an exact Productwissen
        // request in an editorial article. Generic article delivery still needs
        // the normal target match; exact mode matches the product identifier.
        $placements[] = 'post_bottom_products';
        return array_values(array_unique(array_filter($placements)));
    }

    /**
     * V6.72.37 – automatische Kategorie-Freigabe ist providerneutral und gilt
     * fuer alle bestaetigten Kategorie-Querbannerplaetze. Provider-spezifische
     * Sicherheitsvertraege laufen davor im zentralen Planer weiter fail-closed.
     */
    private function output_auto_category_large_banner_allowed($row, $classification, $slot, $output_type) {
        if ($output_type !== 'portal_banner' || !is_array($row) || !is_array($classification) || !is_array($slot)) {
            return false;
        }
        $slot_id = sanitize_key((string) ($slot['slot_id'] ?? ''));
        $rule = $this->category_large_banner_rule($slot_id);
        if (!$rule
            || sanitize_key((string) ($row['creative_type'] ?? 'banner')) !== 'banner'
            || sanitize_key((string) ($classification['status'] ?? '')) !== 'ready') {
            return false;
        }
        $target = is_array($classification['target'] ?? null) ? $classification['target'] : array();
        $target_type = sanitize_key((string) ($target['type'] ?? ''));
        $target_context = sanitize_key((string) ($target['context'] ?? ''));
        if (!in_array($target_type, array_map('sanitize_key', (array)$rule['target_types']), true)
            || !in_array($target_context, array_map('sanitize_key', (array)$rule['target_contexts']), true)
            || absint($target['id'] ?? 0) <= 0) {
            return false;
        }
        if (sanitize_key((string) ($row['source_status'] ?? 'active')) !== 'active'
            || sanitize_key((string) ($row['availability_state'] ?? 'active')) !== 'active') {
            return false;
        }
        $width = absint($row['width'] ?? 0);
        $height = absint($row['height'] ?? 0);
        if ($width <= 0 || $height <= 0) { return false; }
        $ratio = $width / $height;
        if ($ratio < (float)$rule['ratio_min'] || $ratio > (float)$rule['ratio_max']) { return false; }
        $required_scale = max(
            1.0,
            absint($rule['min_width']) / $width,
            absint($rule['min_height']) / $height
        );
        if ($required_scale > ((float)$rule['upscale_max'] + 0.00001)) { return false; }

        $payload = json_decode((string) ($row['payload'] ?? ''), true);
        $payload = is_array($payload) ? $payload : array();
        if (!in_array((string) ($payload['_dimension_state'] ?? ''), array('verified','mismatch'), true)) {
            return false;
        }
        $image_hash = strtolower(trim((string) $this->output_row_image_hash($row)));
        if (!preg_match('/^[a-f0-9]{64}$/', $image_hash)) { return false; }
        $tracking_url = esc_url_raw((string) ($row['tracking_url'] ?? ''));
        if ($tracking_url === '' || !wp_http_validate_url($tracking_url)) { return false; }
        return true;
    }

    /**
     * Werbeplatzregister 2026-09-17 – providerneutrale automatische Bannerfreigabe.
     * Entscheidend ist ausschliesslich die bereits vom produktiven Planer gewaehlte
     * Slotregel aus output_slot_matrix(). Keine zweite Format- oder Masslogik.
     */
    private function output_auto_contract_banner_allowed($row, $classification, $slot, $output_type) {
        if ($output_type !== 'portal_banner' || !is_array($row) || !is_array($classification) || !is_array($slot)) {
            return false;
        }
        if (sanitize_key((string) ($row['creative_type'] ?? 'banner')) !== 'banner'
            || sanitize_key((string) ($classification['status'] ?? '')) !== 'ready') {
            return false;
        }
        $slot_id = sanitize_key((string) ($slot['slot_id'] ?? ''));
        $rule = is_array($slot['rule'] ?? null) ? $slot['rule'] : array();
        $automatic_slots = array(
            'hub_after_cards','product_after_category_tiles','start_after_topics',
            'glossary_single_desktop_banner','glossary_single_mobile_banner','post_inline_banner',
            'glossary_overview_banner','journal_banner','anzeigenmarkt_top_banner','anzeigenmarkt_category_banner',
        );
        if ($slot_id === '' || !in_array($slot_id, $automatic_slots, true) || !$rule) { return false; }
        $target = is_array($classification['target'] ?? null) ? $classification['target'] : array();
        $target_type = sanitize_key((string) ($target['type'] ?? ''));
        $target_context = sanitize_key((string) ($target['context'] ?? ''));
        $rule_target_types = array_map('sanitize_key', (array) ($rule['target_types'] ?? array()));
        $rule_target_contexts = array_map('sanitize_key', (array) ($rule['target_contexts'] ?? array()));
        if (!in_array($target_type, $rule_target_types, true)
            || ($rule_target_contexts && !in_array($target_context, $rule_target_contexts, true))
            || absint($target['id'] ?? 0) <= 0) {
            return false;
        }
        if (sanitize_key((string) ($row['source_status'] ?? 'active')) !== 'active'
            || sanitize_key((string) ($row['availability_state'] ?? 'active')) !== 'active'
            || !$this->output_row_matches_slot_rule($row, $rule, 'banner')) {
            return false;
        }
        $payload = json_decode((string) ($row['payload'] ?? ''), true);
        $payload = is_array($payload) ? $payload : array();
        if (!in_array((string) ($payload['_dimension_state'] ?? ''), array('verified','mismatch'), true)) { return false; }
        $image_hash = strtolower(trim((string) $this->output_row_image_hash($row)));
        if (!preg_match('/^[a-f0-9]{64}$/', $image_hash)) { return false; }
        $tracking_url = esc_url_raw((string) ($row['tracking_url'] ?? ''));
        return $tracking_url !== '' && wp_http_validate_url($tracking_url);
    }

    private function output_save_local_campaign($object_id, $row, $classification, $slot, $output_type) {
        global $wpdb;
        $object = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->output_objects_table()} WHERE id=%d", absint($object_id)), ARRAY_A);
        if (!is_array($object)) { return new WP_Error('output_object_missing', 'Ausgabeobjekt fehlt.'); }
        $target = is_array($classification['target'] ?? null) ? $classification['target'] : array();
        $target_key = $this->output_campaign_target_key($target);
        $slot_id = sanitize_key((string) ($slot['slot_id'] ?? ''));
        if ($target_key === '' || $slot_id === '') { return new WP_Error('campaign_exact_target_missing', 'Exaktes Portalziel oder Designslot fehlt.'); }
        $tracking_url = esc_url_raw((string) ($row['tracking_url'] ?? ''));
        if ($tracking_url === '' || !wp_http_validate_url($tracking_url)) { return new WP_Error('campaign_tracking_missing', 'Originaler Trackinglink fehlt.'); }
        $campaign_id = absint($object['campaign_post_id'] ?? 0);
        if ($campaign_id <= 0 && function_exists('get_posts')) {
            $ids = get_posts(array('post_type'=>self::CAMPAIGN_POST_TYPE,'post_status'=>array('publish','draft','private'),'meta_key'=>'_ppar_output_object_key','meta_value'=>(string) ($object['object_key'] ?? ''),'posts_per_page'=>1,'fields'=>'ids'));
            $campaign_id = $ids ? absint($ids[0]) : 0;
        }
        $payload = json_decode((string) ($row['payload'] ?? ''), true); $payload = is_array($payload) ? $payload : array();
        $campaign = $this->central_blank_campaign();
        $campaign['id'] = sanitize_key('output-' . substr((string) ($object['object_key'] ?? ''), 0, 24));
        $campaign['name'] = sanitize_text_field(trim((string) ($row['partner_name'] ?? '') . ' – ' . (string) ($row['title'] ?? ''), " –\t\n\r\0\x0B"));
        $campaign['partner'] = sanitize_text_field((string) ($row['partner_name'] ?? ''));
        $campaign['creative_type'] = $output_type === 'product_campaign' ? 'product' : 'banner';
        $campaign['network'] = sanitize_key((string) ($row['provider'] ?? 'manual'));
        $campaign['advertiser_id'] = sanitize_text_field((string) ($row['partner_external_id'] ?? ''));
        $campaign['programme_name'] = sanitize_text_field((string) ($row['partner_name'] ?? ''));
        $campaign['programme_status'] = 'active'; $campaign['programme_status_source'] = 'output_object'; $campaign['programme_status_checked_at'] = time();
        $manual_fixed_banner = $output_type === 'portal_banner'
            && sanitize_key((string)($classification['source'] ?? '')) === 'manual_fixed_target';
        $campaign['quality_manual_status'] = $manual_fixed_banner ? 'fixed' : 'auto_verified';
        $campaign['render_mode'] = 'image_link';
        $campaign['dimensions'] = absint($row['width'] ?? 0) . 'x' . absint($row['height'] ?? 0);
        $is_ebay_campaign = sanitize_key((string) ($row['provider'] ?? '')) === 'ebay';
        $auto_ebay_business = $output_type === 'product_campaign'
            && $is_ebay_campaign
            && sanitize_key((string) ($row['source_kind'] ?? '')) === 'ebay_business_item'
            && in_array(sanitize_key((string) ($classification['source'] ?? '')), array('ebay_verified_product_concept','ebay_verified_product_target'), true)
            && method_exists($this, 'ebay_business_product_contract')
            && !empty($this->ebay_business_product_contract($row));
        $auto_otto_awin_product = $this->output_otto_awin_auto_allowed($row, $classification, $output_type);
        $auto_category_banner = $this->output_auto_category_large_banner_allowed($row, $classification, $slot, $output_type);
        $auto_contract_banner = $this->output_auto_contract_banner_allowed($row, $classification, $slot, $output_type);
        $auto_product = $auto_ebay_business || $auto_otto_awin_product;
        $auto_publish = $manual_fixed_banner || $auto_product || $auto_contract_banner;
        $general_banner_fallback = $output_type === 'portal_banner'
            && (!empty($target['_ppar_general_fallback_anchor'])
                || in_array(sanitize_key((string)($classification['source']??'')),array('banner_general_fallback','creative_library_general_fallback'),true));
        $campaign['active'] = $auto_publish;
        $campaign['assignment_mode'] = $general_banner_fallback ? 'fallback' : 'page_tree';
        $campaign['match_descendants'] = $manual_fixed_banner ? false : ($general_banner_fallback ? false : $auto_category_banner);
        // V6.72.89: page_id ist ausschliesslich fuer echte Seiten. Eine WordPress-
        // Kategorie-ID darf niemals als Seiten-ID gespeichert werden; sonst geht die
        // exakte category:<slug>-Bindung fuer normale Kategorien verloren.
        if ($auto_category_banner && sanitize_key((string)($target['type'] ?? '')) === 'page') {
            $campaign['page_id'] = absint($target['id'] ?? 0);
        }
        $auto_targets = $auto_ebay_business && method_exists($this, 'ebay_business_campaign_target_keys')
            ? $this->ebay_business_campaign_target_keys($row, $target)
            : array();
        if ($auto_ebay_business && method_exists($this, 'ebay_business_campaign_placements')) {
            $auto_placements = $this->ebay_business_campaign_placements($row);
        } elseif ($auto_otto_awin_product) {
            $auto_placements = $this->output_otto_product_placements($target, $slot_id);
        } else {
            $auto_placements = array();
        }
        $stored_banner_targets=array_values(array_unique(array_filter(array_map('sanitize_text_field',(array)($classification['_ppar_banner_target_keys']??array())))));
        $campaign['automation_target_keys'] = $general_banner_fallback
            ? array()
            : ($stored_banner_targets
                ? $stored_banner_targets
                : ($auto_targets ? $auto_targets : (!empty($target['_ppar_glossary_neutral_anchor']) ? array() : array($target_key))));
        $compatible_banner_slots = array_values(array_unique(array_filter(array_map('sanitize_key',(array)($classification['_ppar_banner_compatible_slots']??array())))));
        $campaign['placements'] = ($output_type === 'portal_banner' && $compatible_banner_slots)
            ? $compatible_banner_slots
            : ($auto_placements ? $auto_placements : array($slot_id));
        $campaign['priority'] = $manual_fixed_banner
            ? 100
            : ($auto_ebay_business
                ? absint($payload['ebay_quality_score'] ?? ($classification['confidence'] ?? 0))
                : (($auto_otto_awin_product || $auto_contract_banner) ? absint($classification['confidence'] ?? 0) : absint($campaign['priority'] ?? 0)));
        $campaign['auto_topic_label'] = sanitize_text_field((string) ($target['label'] ?? '')); $campaign['auto_topic_score'] = absint($classification['confidence'] ?? 0); $campaign['auto_topic_reason'] = sanitize_text_field((string) ($classification['reason'] ?? ''));
        $campaign['label'] = $output_type === 'product_campaign'
            ? ($is_ebay_campaign ? 'eBay-Angebot · Affiliate' : ($auto_otto_awin_product ? 'OTTO-Angebot · Affiliate' : 'Produktvorschlag'))
            : ($auto_contract_banner ? 'Anzeige' : 'Ausgewählter Partner');
        $campaign['ebay_content_isolated'] = $is_ebay_campaign && $output_type === 'product_campaign';
        $campaign['title'] = sanitize_text_field((string) ($row['title'] ?? '')); $campaign['description'] = sanitize_textarea_field((string) ($row['description'] ?? ''));
        $campaign['price'] = sanitize_text_field((string) ($payload['price'] ?? '')); $campaign['currency'] = strtoupper(substr(sanitize_text_field((string) ($payload['currency'] ?? 'EUR')), 0, 10)); $campaign['availability'] = sanitize_text_field((string) ($payload['availability'] ?? '')); $campaign['seller_name'] = sanitize_text_field((string) ($payload['seller_name'] ?? ''));
        $campaign['voucher_code'] = sanitize_text_field((string) ($payload['voucher_code'] ?? '')); $campaign['start_date'] = method_exists($this,'automation_normalize_date') ? $this->automation_normalize_date($payload['start_date'] ?? '') : ''; $campaign['end_date'] = method_exists($this,'automation_normalize_date') ? $this->automation_normalize_date($payload['end_date'] ?? '') : '';
        $campaign['image_url'] = esc_url_raw((string) ($row['image_url'] ?? '')); $campaign['url'] = $tracking_url; $campaign['destination_url'] = esc_url_raw((string) ($row['destination_url'] ?? '')); $campaign['subid_param'] = ''; $campaign['target'] = '_blank'; $campaign['required_url_fragment'] = ''; $campaign['health_check_enabled'] = true; $campaign['source'] = 'output_object_v4'; $campaign['last_synced'] = time(); $campaign['external_id'] = sanitize_text_field((string) ($row['external_id'] ?? '')); $campaign['creative_identity_hash'] = strtolower(sanitize_text_field((string) ($row['identity_hash'] ?? '')));

        // Exact commerce identity is separate from product facts.
        // V6.72.170 persists eBay GTINs at normal provider materialization time,
        // so future frontend requests use the same cheap raw exact index as the
        // other providers. Existing campaigns remain compatible via the bounded
        // page/slot source-row fallback until their next regular refresh.
        if ($auto_ebay_business) {
            $ebay_gtins = method_exists($this,'idealo_normalize_gtins_from_values')
                ? $this->idealo_normalize_gtins_from_values((array)($payload['product_gtins']??array()))
                : array_values(array_filter((array)($payload['product_gtins']??array())));
            if ($ebay_gtins) {
                $campaign['product_gtins'] = $ebay_gtins;
                $ebay_identifiers = array();
                foreach ($ebay_gtins as $gtin) { $ebay_identifiers[] = array('type'=>'GTIN','value'=>(string)$gtin); }
                $campaign['product_identifiers'] = $this->affiliate_normalize_product_identifiers($ebay_identifiers);
                $campaign['product_identity_source'] = 'ebay_business_source';
                $campaign['product_provider'] = 'ebay';
            }
        }

        // OTTO may expose GTIN/EAN and an explicit MPN; these are carried forward
        // so Productwissen can request the identical product without Affiliate
        // reading its tables.
        if ($auto_otto_awin_product) {
            $exact_identifiers = array();
            $gtin = preg_replace('/[^0-9]/', '', (string) ($payload['gtin'] ?? ''));
            if (in_array(strlen($gtin), array(8,12,13,14), true)) {
                $campaign['product_gtins'] = array($gtin);
                $exact_identifiers[] = array('type'=>'GTIN', 'value'=>$gtin);
            }
            $exact_mpn = trim(sanitize_text_field((string) ($payload['exact_mpn'] ?? '')));
            if ($exact_mpn !== '') {
                $exact_identifiers[] = array('type'=>'MPN', 'value'=>$exact_mpn);
            }
            $campaign['product_identifiers'] = $this->affiliate_normalize_product_identifiers($exact_identifiers);
            $campaign['product_identity_source'] = $campaign['product_identifiers'] ? 'awin_otto_feed' : '';
            $campaign['product_provider'] = 'otto';
        }
        $saved = $this->save_campaign_record($campaign, $campaign_id);
        if (is_wp_error($saved) || !$saved) { return is_wp_error($saved) ? $saved : new WP_Error('campaign_save_failed', 'Kampagne konnte nicht gespeichert werden.'); }
        $campaign_id = absint($saved);
        update_post_meta($campaign_id, '_ppar_output_object_key', sanitize_text_field((string) ($object['object_key'] ?? '')));
        update_post_meta($campaign_id, 'ppar_output_object_id', absint($object_id));
        update_post_meta($campaign_id, '_ppar_creative_identity_hash', sanitize_text_field((string) ($row['identity_hash'] ?? '')));
        if ($auto_ebay_business) {
            update_post_meta($campaign_id, '_ppar_ebay_business_auto', 1);
            update_post_meta($campaign_id, '_ppar_ebay_product_slug', sanitize_title((string) ($payload['ebay_verified_product_slug'] ?? '')));
            update_post_meta($campaign_id, '_ppar_ebay_business_match_contract', 'concept_v3');
            update_post_meta($campaign_id, '_ppar_ebay_quality_score', absint($payload['ebay_quality_score'] ?? 0));
            update_post_meta($campaign_id, '_ppar_ebay_quality_reason', sanitize_text_field((string) ($payload['ebay_quality_reason'] ?? '')));
            update_post_meta($campaign_id, '_ppar_ebay_seller_username', sanitize_text_field((string) ($payload['ebay_seller_username'] ?? '')));
            update_post_meta($campaign_id, '_ppar_ebay_brand', sanitize_text_field((string) ($payload['ebay_brand'] ?? '')));
        } elseif ($is_ebay_campaign && $output_type === 'product_campaign') {
            delete_post_meta($campaign_id, '_ppar_ebay_business_match_contract');
        }
        if ($auto_otto_awin_product) {
            update_post_meta($campaign_id, '_ppar_otto_awin_auto', 1);
        } else {
            delete_post_meta($campaign_id, '_ppar_otto_awin_auto');
        }
        $published_reason = $manual_fixed_banner
            ? 'Fest zugeordneter Banner fuer das gewaehlte Portalziel aktiviert.'
            : ($auto_ebay_business
            ? 'Verifiziertes eBay-BUSINESS-Produkt automatisch in den freigegebenen Produktslots aktiviert.'
            : ($auto_otto_awin_product
                ? 'Verifiziertes OTTO-Produkt aus dem freigegebenen Awin-Programm automatisch für passende Produktplätze und Beiträge aktiviert.'
                : ($general_banner_fallback
                    ? 'Verifizierter Banner ohne eindeutiges Zielthema automatisch in den allgemeinen technisch gültigen Fallback-Pool aktiviert.'
                    : ($auto_category_banner
                        ? 'Verifizierter grosser Kategorie-Querbanner automatisch fuer den passendsten Themenast aktiviert.'
                        : 'Inaktive Kampagne aus exakt verknüpftem Creative, Ziel und Designslot vorbereitet.'))));
        $decision_source = $manual_fixed_banner
            ? 'manual_fixed_target'
            : ($auto_ebay_business
            ? 'ebay_verified_product_concept'
            : ($auto_otto_awin_product
                ? 'otto_awin_verified_product'
                : ($general_banner_fallback
                    ? 'banner_general_fallback'
                    : ($auto_category_banner ? 'category_large_banner_v1' : (string) ($object['decision_source'] ?? 'automatic')))));
        $wpdb->update($this->output_objects_table(), array(
            'campaign_post_id'=>$campaign_id,
            'status'=>$auto_publish ? 'published' : 'draft',
            'decision_source'=>$decision_source,
            'decision_reason'=>$published_reason,
            'last_verified'=>time(),'updated_at'=>time()
        ), array('id'=>absint($object_id)));
        return array('campaign_id'=>$campaign_id,'active'=>$auto_publish);
    }
    private function output_materialize_banner($object_id, $portal, $row, $classification, $slot) {
        return $this->output_save_local_campaign($object_id, $row, $classification, $slot, 'portal_banner');
    }
    private function output_materialize_product($object_id, $portal, $row, $classification, $slot) {
        return $this->output_save_local_campaign($object_id, $row, $classification, $slot, 'product_campaign');
    }
    private function output_materialize_external($object_id, $portal, $row, $classification, $slot, $output_type) {
        $callbacks = is_array($portal['callbacks'] ?? null) ? $portal['callbacks'] : array();
        $callback_name = $output_type === 'portal_banner' ? 'materialize_banner' : ($output_type === 'product_campaign' ? 'materialize_product' : 'materialize_listing');
        if (empty($callbacks[$callback_name]) || !is_callable($callbacks[$callback_name])) {
            return new WP_Error('portal_materializer_missing', 'Externer Portaladapter besitzt keinen freigegebenen Materialisierer für diesen Ausgabetyp.');
        }
        $result = call_user_func($callbacks[$callback_name], array(
            'object_id'=>absint($object_id),
            'portal'=>$portal,
            'creative'=>$row,
            'classification'=>$classification,
            'slot'=>$slot,
            'tracking_url'=>(string) ($row['tracking_url'] ?? ''),
            'image_url'=>(string) ($row['image_url'] ?? ''),
        ));
        if (is_wp_error($result)) {
            return $result;
        }
        if (!is_array($result) || empty($result['external_reference'])) {
            return new WP_Error('portal_materializer_invalid', 'Externer Portaladapter lieferte keine eindeutige Referenz.');
        }
        global $wpdb;
        $wpdb->update($this->output_objects_table(), array(
            'status'=>'draft',
            'decision_reason'=>'Entwurf über freigegebenen externen Portaladapter vorbereitet.',
            'payload'=>wp_json_encode(array(
                'external_reference'=>sanitize_text_field((string) $result['external_reference']),
                'preview_url'=>esc_url_raw((string) ($result['preview_url'] ?? '')),
                'slot_rule'=>$slot['rule'] ?? array(),
            ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'last_verified'=>time(),
            'updated_at'=>time(),
        ), array('id'=>absint($object_id)));
        return $result;
    }

    public function output_plan_creative($row, $materialize = true, $only_portal_key = '') {
        global $wpdb;
        $this->maybe_install_output_objects_schema();
        $portals = $this->output_portal_registry();
        $result = array('created'=>0,'drafts'=>0,'active'=>0,'blocked'=>0,'review'=>0,'errors'=>array());
        // Digistore24 tracking is credential-bound. Reject a stale, foreign or
        // otherwise invalid vendor link before classification/upsert/materialization
        // so a bad refresh cannot overwrite a Last-Known-Good banner draft/campaign.
        // Other providers do not enter this provider-specific gate.
        if (sanitize_key((string) ($row['provider'] ?? '')) === 'digistore24') {
            if (!method_exists($this, 'digistore24_tracking_url_allowed') || !$this->digistore24_tracking_url_allowed((string) ($row['tracking_url'] ?? ''))) {
                $result['blocked'] = 1;
                $result['errors']['output_digistore24_tracking_invalid'] = 'Digistore24-Ausgabe besitzt keinen aktuell geprüften, provisionssicheren Trackinglink.';
                return $result;
            }
            if (!method_exists($this, 'digistore24_is_https_url') || !$this->digistore24_is_https_url((string) ($row['image_url'] ?? ''))) {
                $result['blocked'] = 1;
                $result['errors']['output_digistore24_image_invalid'] = 'Digistore24-Banner besitzt keine verifizierbare HTTPS-Bildquelle.';
                return $result;
            }
        }
        $only_portal_key = sanitize_key((string) $only_portal_key);
        foreach ($portals as $portal) {
            if (empty($portal['enabled'])) { continue; }
            if ($only_portal_key !== '' && sanitize_key((string) ($portal['key'] ?? '')) !== $only_portal_key) { continue; }
            if (method_exists($this, 'control_partner_gate')) {
                $gate = $this->control_partner_gate($row, $portal);
                if (is_wp_error($gate)) { $result['blocked']++; $result['errors'][$gate->get_error_code()]=$gate->get_error_message(); continue; }
            }
            $valid = $this->output_validate_portal_profile($portal);
            if (is_wp_error($valid)) { $result['blocked']++; $result['errors'][$valid->get_error_code()]=$valid->get_error_message(); continue; }
            $output_types = array_values(array_intersect(array_unique(array_filter(array_map('sanitize_key', (array) ($portal['output_types'] ?? array())))), array('portal_banner','product_campaign','hivepress_listing','portal_listing')));
            $creative_type = sanitize_key((string) ($row['creative_type'] ?? 'banner'));
            if ($creative_type === 'product') {
                $output_types = array_values(array_intersect($output_types, array('product_campaign')));
            } elseif ($creative_type === 'banner') {
                $output_types = array_values(array_intersect($output_types, array('portal_banner','hivepress_listing','portal_listing')));
                // KISS 6.72.197: Eine ausdrueckliche feste Banner-Zielzuordnung
                // bedeutet genau Banner -> genau dieses Portalziel. Sie darf nicht
                // parallel noch Listing-Ausgabetypen pruefen oder Blocker erzeugen.
                $fixed_decision = $this->output_portal_decision((string)($portal['key'] ?? ''),(string)($row['identity_hash'] ?? ''));
                $fixed_payload = is_array($fixed_decision['payload'] ?? null) ? $fixed_decision['payload'] : array();
                if (sanitize_key((string)($fixed_decision['manual_status'] ?? '')) === 'approved'
                    && sanitize_text_field((string)($fixed_payload['target_key'] ?? '')) !== '') {
                    $output_types = in_array('portal_banner',$output_types,true) ? array('portal_banner') : array();
                }
            } else {
                $result['review']++;
                $result['errors']['output_type_unsupported']='Creative-Typ besitzt noch keinen bestätigten Ausgabeweg.';
                continue;
            }
            // Digistore24 is contractually banner-only. This provider-specific
            // hardlock must not alter any output path for other providers.
            if (sanitize_key((string) ($row['provider'] ?? '')) === 'digistore24') {
                $output_types = array_values(array_intersect($output_types, array('portal_banner')));
            }
            foreach ($output_types as $output_type) {
                $classification = $this->output_classify_for_portal($row, $portal, $output_type);
                if (is_wp_error($classification)) { $result['blocked']++; $result['errors'][$classification->get_error_code()]=$classification->get_error_message(); continue; }

                $compatible_banner_slots = $output_type === 'portal_banner'
                    ? $this->output_banner_compatible_slots($row,$portal)
                    : array();

                $target = is_array($classification['target'] ?? null) ? $classification['target'] : array();
                $slot = array('slot_id'=>''); $status = sanitize_key((string) ($classification['status'] ?? 'review'));
                if ($status === 'blocked' && sanitize_key((string) ($classification['source'] ?? '')) === 'source_state') { $status = 'blocked_source'; }

                // Bestehender KISS-Fallback: kein spezifisches Ziel -> allgemeiner
                // technisch gueltiger Pool, ohne erfundene Themenkante.
                if ($output_type === 'portal_banner'
                    && $status === 'review'
                    && sanitize_key((string)($classification['source'] ?? '')) === 'banner_target_map_missing'
                    && $compatible_banner_slots
                    && !(method_exists($this,'output_comparison_banner_partner')
                        && $this->output_comparison_banner_partner($row) !== ''
                        && method_exists($this,'output_tarifcheck_banner_family')
                        && $this->output_tarifcheck_banner_family($row) === 'blocked')) {
                    $targets = $this->output_portal_targets($portal);
                    $matrix = $this->output_slot_matrix($portal);
                    if (!is_wp_error($targets) && !is_wp_error($matrix)) {
                        // KISS 6.72.206: Editorial-Single-Slots muessen bei
                        // allgemeinen Bannern vor hub_grid_card als Aktivierungsanker
                        // gewinnen. hub_grid_card ist bewusst kein Auto-Publish-Slot;
                        // sonst bleibt ein technisch gueltiger Glossarbanner
                        // als ganze Kampagne inaktiv, obwohl seine Placements stimmen.
                        $editorial_single_priority = array(
                            'glossary_single_desktop_banner',
                            'glossary_single_mobile_banner'
                        );
                        $fallback_slot_ids = array_values(array_unique(array_merge(
                            array_values(array_intersect($editorial_single_priority, $compatible_banner_slots)),
                            array_values(array_diff($compatible_banner_slots, $editorial_single_priority))
                        )));
                        foreach ($fallback_slot_ids as $fallback_slot_id) {
                            $fallback_rule = is_array($matrix[$fallback_slot_id] ?? null) ? $matrix[$fallback_slot_id] : array();
                            if (!$fallback_rule) { continue; }
                            $fallback_types = array_map('sanitize_key',(array)($fallback_rule['target_types'] ?? array()));
                            $fallback_contexts = array_map('sanitize_key',(array)($fallback_rule['target_contexts'] ?? array()));
                            foreach ((array)$targets as $fallback_target) {
                                if (!is_array($fallback_target) || absint($fallback_target['id'] ?? 0) <= 0) { continue; }
                                if ($fallback_types && !in_array(sanitize_key((string)($fallback_target['type'] ?? '')),$fallback_types,true)) { continue; }
                                if ($fallback_contexts && !in_array(sanitize_key((string)($fallback_target['context'] ?? '')),$fallback_contexts,true)) { continue; }
                                if (method_exists($this,'control_target_gate')
                                    && is_wp_error($this->control_target_gate((string)($portal['key'] ?? ''),(string)($fallback_target['key'] ?? '')))) { continue; }
                                $fallback_target['_ppar_general_fallback_anchor'] = 1;
                                $target = $fallback_target;
                                $classification = array(
                                    'status'=>'ready','confidence'=>1,
                                    'reason'=>'Kein eindeutiges Zielthema: allgemeiner technisch gültiger Banner-Fallback.',
                                    'target'=>$target,'alternatives'=>array(),
                                    'source'=>'banner_general_fallback',
                                    '_ppar_destination_level'=>'general',
                                );
                                $slot = array('slot_id'=>$fallback_slot_id,'rule'=>$fallback_rule);
                                $status = 'ready';
                                break 2;
                            }
                        }
                    }
                }

                if (in_array($output_type, array('portal_banner','product_campaign'), true) && $status === 'ready' && empty($slot['slot_id'])) {
                    $slot = $this->output_format_slot($row, $portal, $target, $output_type === 'product_campaign' ? 'product' : 'banner');
                    if (is_wp_error($slot)) { $status='blocked_format'; $classification['reason']=$slot->get_error_message(); $slot=array('slot_id'=>''); }
                }

                if ($output_type === 'portal_banner'
                    && $status === 'ready'
                    && sanitize_key((string)($classification['source'] ?? '')) !== 'manual_fixed_target') {
                    $classification['_ppar_banner_compatible_slots']=$compatible_banner_slots;
                    $this->output_store_banner_library_assignment($row,$portal,$classification,$compatible_banner_slots);
                }

                if (in_array($output_type, array('hivepress_listing','portal_listing'), true) && $status === 'ready') {
                    $listing_format = $this->output_listing_asset_compatibility($row, $portal);
                    if (is_wp_error($listing_format)) { $status='blocked_format'; $classification['reason']=$listing_format->get_error_message(); }
                }
                $fingerprint = $this->output_source_fingerprint($row, $portal, $output_type, $target, (string) ($slot['slot_id'] ?? ''));
                $object_data = array(
                    'portal_key'=>(string) ($portal['key'] ?? ''),'portal_adapter'=>(string) ($portal['adapter'] ?? ''),'creative_identity_hash'=>(string) ($row['identity_hash'] ?? ''),'provider'=>(string) ($row['provider'] ?? ''),'partner_external_id'=>(string) ($row['partner_external_id'] ?? ''),'output_type'=>$output_type,'target_type'=>(string) ($target['type'] ?? ''),'target_key'=>(string) ($target['key'] ?? ''),'target_label'=>(string) ($target['label'] ?? ''),'slot_id'=>(string) ($slot['slot_id'] ?? ''),'status'=>$status,'confidence'=>absint($classification['confidence'] ?? 0),'decision_source'=>(string) ($classification['source'] ?? 'automatic'),'decision_reason'=>(string) ($classification['reason'] ?? ''),'tracking_url'=>(string) ($row['tracking_url'] ?? ''),'image_url'=>(string) ($row['image_url'] ?? ''),'image_width'=>absint($row['width'] ?? 0),'image_height'=>absint($row['height'] ?? 0),'image_hash'=>$this->output_row_image_hash($row),'source_fingerprint'=>$fingerprint,'payload'=>wp_json_encode(array('alternatives'=>$classification['alternatives'] ?? array(),'slot_rule'=>$slot['rule'] ?? array(),'target_context'=>$target['context'] ?? ''), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'last_verified'=>time(),
                );
                $object_id = $this->output_object_upsert($object_data);
                $result['created']++;
                if ($status !== 'ready') { if (strpos($status,'blocked')===0) {$result['blocked']++;} else {$result['review']++;} continue; }
                if (!$materialize) { $result['review']++; continue; }
                $adapter = sanitize_key((string) ($portal['adapter'] ?? ''));
                if (in_array($adapter, array('wordpress_local','wordpress_multisite'), true)) {
                    $made = $this->output_with_portal($portal, function() use ($object_id,$portal,$row,$classification,$slot,$output_type) {
                        if ($output_type === 'portal_banner') { return $this->output_materialize_banner($object_id,$portal,$row,$classification,$slot); }
                        if ($output_type === 'product_campaign') { return $this->output_materialize_product($object_id,$portal,$row,$classification,$slot); }
                        if ($output_type !== 'hivepress_listing') { return new WP_Error('local_listing_adapter_unsupported','Lokaler WordPress-Adapter unterstützt nur bestätigte Kampagnen und HivePress-Listings.'); }
                        return $this->output_materialize_listing($object_id,$portal,$row,$classification);
                    });
                } else {
                    $made = $this->output_materialize_external($object_id,$portal,$row,$classification,$slot,$output_type);
                }
                if (is_wp_error($made)) {
                    global $wpdb;
                    $current_object = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->output_objects_table()} WHERE id=%d", absint($object_id)), ARRAY_A);
                    $has_last_good = is_array($current_object) && (string)($current_object['status'] ?? '') === 'published' && absint($current_object['campaign_post_id'] ?? 0) > 0;
                    $wpdb->update($this->output_objects_table(), array(
                        'status'=>$has_last_good ? 'published' : 'blocked_runtime',
                        'decision_reason'=>$has_last_good ? 'Aktualisierung fehlgeschlagen; Last-Known-Good bleibt veröffentlicht: ' . $made->get_error_message() : $made->get_error_message(),
                        'updated_at'=>time(),
                    ), array('id'=>absint($object_id)));
                    $result['blocked']++; $result['errors'][$made->get_error_code()]=$made->get_error_message();
                } else {
                    $result['drafts']++;
                    if (is_array($made) && !empty($made['active'])) { $result['active']++; }
                    // Only now may an older object for another target/slot be
                    // retired. This is the commit point of the atomic swap.
                    $materialized_object = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->output_objects_table()} WHERE id=%d", absint($object_id)), ARRAY_A);
                    if (is_array($materialized_object) && sanitize_key((string) ($materialized_object['provider'] ?? '')) !== 'digistore24') {
                        $this->output_supersede_conflicting_objects($materialized_object, (string)($materialized_object['object_key'] ?? ''));
                    }
                }
            }
        }
        return $result;
    }
    private function output_row_image_hash($row) {
        $payload = json_decode((string) ($row['payload'] ?? ''), true);
        if (is_array($payload) && !empty($payload['_image_sha256'])) {
            return sanitize_text_field((string) $payload['_image_sha256']);
        }
        return '';
    }

    private function output_tracking_health($url, $destination_url = '') {
        $url = esc_url_raw((string) $url);
        if ($url === '' || !wp_http_validate_url($url) || !in_array(strtolower((string) wp_parse_url($url, PHP_URL_SCHEME)), array('http','https'), true)) {
            return new WP_Error('output_tracking_invalid', 'Trackinglink ist ungültig.');
        }
        // Affiliate-Trackinglinks werden niemals automatisiert aufgerufen. HEAD
        // oder GET kann beim Netzwerk als künstlicher Klick gewertet werden.
        // Technisch geprüft wird nur eine separat bekannte Zielseite.
        $destination_url = esc_url_raw((string) $destination_url);
        if ($destination_url === '' || !wp_http_validate_url($destination_url) || $destination_url === $url) {
            return array('mode'=>'tracking_syntax_only','http_code'=>0,'checked_at'=>time());
        }
        $tracking_host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        $destination_host = strtolower((string) wp_parse_url($destination_url, PHP_URL_HOST));
        if ($destination_host === '' || $destination_host === $tracking_host) {
            return array('mode'=>'tracking_syntax_only','http_code'=>0,'checked_at'=>time());
        }
        $args = array('timeout'=>8, 'redirection'=>5, 'limit_response_size'=>2048, 'headers'=>array('Accept'=>'text/html,*/*;q=0.8'));
        $response = function_exists('wp_safe_remote_head') ? wp_safe_remote_head($destination_url, $args) : new WP_Error('head_unavailable', 'HEAD nicht verfügbar.');
        $code = is_wp_error($response) ? 0 : absint(wp_remote_retrieve_response_code($response));
        if (is_wp_error($response) || $code === 405 || $code === 403 || $code === 0) {
            $response = wp_safe_remote_get($destination_url, $args);
            $code = is_wp_error($response) ? 0 : absint(wp_remote_retrieve_response_code($response));
        }
        if (is_wp_error($response)) {
            return $response;
        }
        if ($code < 200 || $code >= 400) {
            return new WP_Error('output_destination_http', 'Zielseite antwortet mit HTTP ' . $code . '.');
        }
        return array('mode'=>'destination_http','http_code'=>$code,'checked_at'=>time());
    }

    private function output_object_health_payload($object) {
        $payload = json_decode((string) ($object['payload'] ?? ''), true);
        return is_array($payload) ? $payload : array();
    }

    public function output_run_health_batch($limit = 10) {
        $this->maybe_install_output_objects_schema();
        if (method_exists($this, 'control_emergency_stop_active') && $this->control_emergency_stop_active()) {
            return array('checked'=>0,'ok'=>0,'warning'=>0,'quarantine'=>0,'skipped'=>1,'reason'=>'Globale Affiliate-Notabschaltung ist aktiv; gespeicherte Ausgabezustände bleiben unverändert.');
        }
        global $wpdb;
        $table = $this->output_objects_table();
        $limit = max(1, min(25, absint($limit)));
        $rows = $wpdb->get_results("SELECT * FROM {$table} WHERE status IN ('draft','published','warning') ORDER BY last_verified ASC, id ASC LIMIT {$limit}", ARRAY_A);
        $summary = array('checked'=>0,'ok'=>0,'warning'=>0,'quarantine'=>0);
        foreach ((array) $rows as $object) {
            $summary['checked']++;
            $payload = $this->output_object_health_payload($object);
            $creative = $this->output_creative_row((string) ($object['creative_identity_hash'] ?? ''));
            $error = null;
            if (!is_array($creative)) {
                $error = new WP_Error('output_creative_missing', 'Verknüpftes Creative fehlt.');
            } else {
                $provisional_product = $this->output_allows_provisional_ebay_product_asset($creative)
                    && (absint($creative['width'] ?? 0) <= 0 || absint($creative['height'] ?? 0) <= 0 || $this->output_row_image_hash($creative) === '');
                $verified = $provisional_product
                    ? $creative
                    : (method_exists($this, 'creative_library_verify_asset_row')
                        ? $this->creative_library_verify_asset_row($creative, true, false)
                        : new WP_Error('asset_verifier_missing', 'Bildprüfung fehlt.'));
                if (is_wp_error($verified)) {
                    $error = $verified;
                } else {
                    $creative = $verified;
                    $link = $this->output_tracking_health((string) ($creative['tracking_url'] ?? ''), (string) ($creative['destination_url'] ?? ''));
                    if (is_wp_error($link)) {
                        $error = $link;
                    } else {
                        $valid = $this->output_object_revalidate($object);
                        if (is_wp_error($valid)) {
                            $error = $valid;
                        }
                    }
                }
            }
            if (!$error) {
                $payload['health_failures'] = 0;
                $payload['last_health_error'] = '';
                $payload['last_health_ok'] = time();
                $restore_status = sanitize_key((string) ($payload['health_previous_status'] ?? ($object['status'] ?? 'draft')));
                if (!in_array($restore_status, array('draft','published'), true)) {
                    $restore_status = 'draft';
                }
                unset($payload['health_previous_status']);
                $wpdb->update($table, array(
                    'status'=>$restore_status,
                    'payload'=>wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'last_verified'=>time(),
                    'updated_at'=>time(),
                ), array('id'=>absint($object['id'])));
                $summary['ok']++;
                continue;
            }
            $code = $error->get_error_code();
            $deterministic = in_array($code, array(
                'output_creative_missing','output_veto_active','output_source_inactive','output_tracking_changed',
                'output_image_changed','output_image_hash_changed','output_dimensions_missing','output_target_changed',
                'output_slot_changed','output_target_no_longer_safe','output_no_design_slot','output_source_fingerprint_changed','portal_domain_profile_missing','portal_listing_asset_validator_missing',
                'awin_partner_id_missing','awin_partner_portal_missing','awin_partner_not_approved','awin_partner_other_portal','awin_partner_test_blocked','awin_partner_excluded','awin_partner_portal_mismatch','awin_partner_not_joined_current'
            ), true);
            $failures = $deterministic ? 3 : absint($payload['health_failures'] ?? 0) + 1;
            if (!isset($payload['health_previous_status']) && in_array((string) ($object['status'] ?? ''), array('draft','published'), true)) {
                $payload['health_previous_status'] = (string) $object['status'];
            }
            $payload['health_failures'] = $failures;
            $payload['last_health_error'] = $error->get_error_message();
            $payload['last_health_error_code'] = $code;
            $payload['last_health_failed_at'] = time();
            if ($failures >= 3) {
                $this->output_deactivate_materialized_object($object, $error->get_error_message());
                $status = 'quarantine';
                $summary['quarantine']++;
            } else {
                $status = 'warning';
                $summary['warning']++;
            }
            $wpdb->update($table, array(
                'status'=>$status,
                'decision_reason'=>'Automatische Gesamtprüfung: ' . $error->get_error_message(),
                'payload'=>wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'last_verified'=>time(),
                'updated_at'=>time(),
            ), array('id'=>absint($object['id'])));
        }
        return $summary;
    }

    private function output_object_by_id($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->output_objects_table()} WHERE id=%d", absint($id)), ARRAY_A);
    }

    /**
     * Resolve the canonical Digistore24 Werbemittel entry from immutable creative
     * bindings. Older live rows may have lost partner_external_id while their
     * generated external_id still contains the exact entry number.
     *
     * Never "strip all digits" from arbitrary strings: Digistore24 itself contains
     * the digits 24 and could silently turn a malformed id into the wrong entry.
     */
    private function output_digistore24_entry_id($row, $object = array()) {
        $candidates = array();
        $sources = array(
            'creative_partner'=>(string) ($row['partner_external_id'] ?? ''),
            'object_partner'=>(string) ($object['partner_external_id'] ?? ''),
        );
        foreach ($sources as $label=>$raw) {
            $raw = trim($raw);
            if ($raw === '') { continue; }
            if (preg_match('/^entry-(\d+)$/', $raw, $m) || preg_match('/^(\d+)$/', $raw, $m)) {
                $candidates[$label] = ltrim($m[1], '0');
                if ($candidates[$label] === '') { $candidates[$label] = '0'; }
            }
        }
        $external_id = trim((string) ($row['external_id'] ?? ''));
        if ($external_id !== '' && preg_match('/^ds24-(\d+)-[a-f0-9]{24}$/i', $external_id, $m)) {
            $candidates['creative_external'] = ltrim($m[1], '0');
            if ($candidates['creative_external'] === '') { $candidates['creative_external'] = '0'; }
        }
        $candidates = array_filter($candidates, static function($value){ return ctype_digit((string)$value) && (int)$value > 0; });
        if (!$candidates) {
            return new WP_Error('output_digistore24_entry_binding_missing', 'Kanonische Digistore24-Werbemittel-ID fehlt am importierten Vendor-Banner.');
        }
        $unique = array_values(array_unique(array_values($candidates)));
        if (count($unique) !== 1) {
            return new WP_Error('output_digistore24_entry_binding_conflict', 'Digistore24-Werbemittelbindung ist widersprüchlich; Ausgabe bleibt gesperrt.');
        }
        return (string) $unique[0];
    }

    private function output_object_revalidate($object) {
        if (!is_array($object)) { return new WP_Error('output_object_missing','Ausgabeobjekt fehlt.'); }
        if (method_exists($this, 'control_get_decision')) {
            $output_decision = $this->control_get_decision((string) ($object['portal_key'] ?? ''), 'output', (string) absint($object['id'] ?? 0));
            if (!empty($output_decision['exists']) && (string) ($output_decision['status'] ?? '') === 'veto') {
                return new WP_Error('output_manual_veto_active', (string) ($output_decision['reason'] ?? 'Ausgabeobjekt ist manuell gesperrt.'));
            }
            if (!empty($output_decision['exists']) && (string) ($output_decision['status'] ?? '') === 'paused') {
                return new WP_Error('output_manual_pause_active', (string) ($output_decision['reason'] ?? 'Ausgabeobjekt ist manuell pausiert.'));
            }
        }
        $row = $this->output_creative_row((string) ($object['creative_identity_hash'] ?? ''));
        if (!is_array($row)) { return new WP_Error('output_creative_missing','Verknüpftes Creative fehlt.'); }
        if (sanitize_key((string) ($object['provider'] ?? '')) === 'digistore24') {
            if (sanitize_key((string) ($row['provider'] ?? '')) !== 'digistore24'
                || sanitize_key((string) ($row['creative_type'] ?? '')) !== 'banner'
                || sanitize_key((string) ($row['source_kind'] ?? '')) !== 'digistore24_vendor_banner'
                || sanitize_key((string) ($object['output_type'] ?? '')) !== 'portal_banner') {
                return new WP_Error('output_digistore24_source_invalid', 'Digistore24-Ausgabe ist nicht vollständig an ein echtes Vendor-Banner gebunden.');
            }
            $entry_id = $this->output_digistore24_entry_id($row, $object);
            if (is_wp_error($entry_id)) { return $entry_id; }
            $tracking_product_id = method_exists($this, 'digistore24_tracking_product_id') ? $this->digistore24_tracking_product_id((string) ($row['tracking_url'] ?? '')) : '';
            $manual_proof = method_exists($this, 'digistore24_manual_csv_affiliation_gate')
                ? $this->digistore24_manual_csv_affiliation_gate($entry_id, $tracking_product_id)
                : new WP_Error('output_digistore24_manual_gate_missing', 'Digistore24-CSV-Schlussprüfung fehlt.');
            $manual_source_bound = method_exists($this, 'digistore24_manual_csv_source_bound') && $this->digistore24_manual_csv_source_bound($entry_id);
            if ($manual_source_bound) {
                // A manual-CSV source must be decided by its bound CSV proof. Never
                // replace that precise result with the generic API affiliation error.
                if (is_wp_error($manual_proof)) { return $manual_proof; }
                $proof = $manual_proof;
            } elseif (!is_wp_error($manual_proof)) {
                $proof = $manual_proof;
            } else {
                // Existing API path stays intact for genuinely API-derived sources.
                $entry = method_exists($this, 'digistore24_marketplace_item') ? $this->digistore24_marketplace_item($entry_id) : array();
                $proof = method_exists($this, 'digistore24_affiliation_gate') ? $this->digistore24_affiliation_gate((string) ($entry['main_product_id'] ?? ''), false) : new WP_Error('output_digistore24_gate_missing', 'Digistore24-Schlussprüfung fehlt.');
                if (is_wp_error($proof) && $tracking_product_id !== '' && method_exists($this, 'digistore24_affiliation_gate')) {
                    $proof = $this->digistore24_affiliation_gate($tracking_product_id, false);
                }
            }
            if (is_wp_error($proof)) { return $proof; }
            $proof_source = sanitize_key((string) ($proof['source'] ?? ''));
            $manual_affiliate = in_array($proof_source, array('manual_csv_inventory','manual_csv_partnership','manual_csv_marketplace'), true) ? (string) ($proof['affiliate_id'] ?? '') : '';
            if (!method_exists($this, 'digistore24_tracking_url_allowed') || !$this->digistore24_tracking_url_allowed((string) ($row['tracking_url'] ?? ''), $manual_affiliate)) { return new WP_Error('output_digistore24_tracking_invalid', 'Digistore24-Trackinglink ist nicht mehr provisionssicher.'); }
        }
        if (method_exists($this, 'control_emergency_stop_active') && $this->control_emergency_stop_active()) {
            return new WP_Error('control_emergency_stop_active', 'Globale Affiliate-Notabschaltung ist aktiv.');
        }
        $portal_for_gate = $this->output_portal_by_key((string) ($object['portal_key'] ?? ''), true);
        if (is_wp_error($portal_for_gate)) { return $portal_for_gate; }
        if (method_exists($this, 'control_provider_gate')) {
            $provider_gate = $this->control_provider_gate(sanitize_key((string) ($row['provider'] ?? $object['provider'] ?? '')), sanitize_key((string) ($portal_for_gate['key'] ?? $object['portal_key'] ?? '')));
            if (is_wp_error($provider_gate)) { return $provider_gate; }
        }
        if (method_exists($this, 'control_partner_gate')) {
            $gate = $this->control_partner_gate($row, $portal_for_gate);
            if (is_wp_error($gate)) { return $gate; }
        }
        $manual = $this->output_portal_decision((string) ($object['portal_key'] ?? ''),(string) ($row['identity_hash'] ?? ''));
        if ((string) ($manual['manual_status'] ?? '') === 'veto') { return new WP_Error('output_veto_active','Manuelles Creative-Veto ist für dieses Portal aktiv.'); }
        if ((string) ($row['source_status'] ?? 'active') !== 'active' || (string) ($row['availability_state'] ?? 'active') !== 'active') { return new WP_Error('output_source_inactive','Creative-Quelle ist nicht mehr aktiv.'); }
        if ((string) ($row['tracking_url'] ?? '') !== (string) ($object['tracking_url'] ?? '')) { return new WP_Error('output_tracking_changed','Trackinglink hat sich seit der Vorbereitung geändert.'); }
        if ((string) ($row['image_url'] ?? '') !== (string) ($object['image_url'] ?? '')) { return new WP_Error('output_image_changed','Bildquelle hat sich seit der Vorbereitung geändert.'); }
        $row_image_hash = $this->output_row_image_hash($row);
        $provisional_product = $this->output_allows_provisional_ebay_product_asset($row)
            && (absint($row['width'] ?? 0) <= 0 || absint($row['height'] ?? 0) <= 0 || $row_image_hash === '');
        if (!$provisional_product && ($row_image_hash === '' || !hash_equals($row_image_hash,(string) ($object['image_hash'] ?? '')))) { return new WP_Error('output_image_hash_changed','Verifiziertes Bannerbild hat sich seit der Vorbereitung geändert.'); }
        $payload=json_decode((string) ($row['payload'] ?? ''),true); $payload=is_array($payload)?$payload:array();
        if (!$provisional_product && (!in_array((string) ($payload['_dimension_state'] ?? ''),array('verified','mismatch'),true) || absint($row['width'] ?? 0)<=0 || absint($row['height'] ?? 0)<=0)) { return new WP_Error('output_dimensions_missing','Reale Bildmaße fehlen.'); }
        $portal=$this->output_portal_by_key((string) ($object['portal_key'] ?? '')); if (is_wp_error($portal)) { return $portal; }
        $valid=$this->output_validate_portal_profile($portal); if (is_wp_error($valid)) { return $valid; }
        $classification=$this->output_classify_for_portal($row,$portal,(string) ($object['output_type'] ?? ''));
        if (is_wp_error($classification) || (string) ($classification['status'] ?? '') !== 'ready') { return is_wp_error($classification)?$classification:new WP_Error('output_target_no_longer_safe','Portalziel ist nicht mehr eindeutig freigabefähig.'); }
        $target=is_array($classification['target'] ?? null)?$classification['target']:array();
        if ((string) ($target['key'] ?? '') !== (string) ($object['target_key'] ?? '')) { return new WP_Error('output_target_changed','Automatisch ermitteltes Portalziel hat sich geändert.'); }
        $slot_id='';
        if (in_array((string) ($object['output_type'] ?? ''),array('portal_banner','product_campaign'),true)) {
            $slot=$this->output_format_slot($row,$portal,$target,(string) ($object['output_type'] ?? '')==='product_campaign'?'product':'banner');
            if (is_wp_error($slot)) { return $slot; }
            $slot_id=(string) ($slot['slot_id'] ?? '');
            if ($slot_id !== (string) ($object['slot_id'] ?? '')) { return new WP_Error('output_slot_changed','Passender Designslot hat sich geändert.'); }
        } else {
            $listing=$this->output_listing_asset_compatibility($row,$portal); if (is_wp_error($listing)) { return $listing; }
        }
        $fingerprint=$this->output_source_fingerprint($row,$portal,(string) ($object['output_type'] ?? ''),$target,$slot_id);
        if ((string) ($object['source_fingerprint'] ?? '') === '' || !hash_equals((string) ($object['source_fingerprint'] ?? ''),$fingerprint)) { return new WP_Error('output_source_fingerprint_changed','Quelldaten, Portalprofil, Ziel oder Adapterstand haben sich seit der Vorbereitung geändert.'); }
        return $row;
    }

    private function output_finalize_digistore24_object($object) {
        if (!is_array($object) || sanitize_key((string) ($object['provider'] ?? '')) !== 'digistore24') { return new WP_Error('output_digistore24_object_invalid', 'Digistore24-Ausgabeobjekt fehlt.'); }
        $row = $this->output_object_revalidate($object);
        if (is_wp_error($row)) { $this->output_deactivate_materialized_object($object, $row->get_error_message()); return $row; }
        $portal = $this->output_portal_by_key((string) ($object['portal_key'] ?? ''));
        if (is_wp_error($portal) || !in_array(sanitize_key((string) ($portal['adapter'] ?? '')), array('wordpress_local','wordpress_multisite'), true)) {
            return is_wp_error($portal) ? $portal : new WP_Error('output_digistore24_local_required', 'Automatische Digistore24-Veröffentlichung erfordert den gebundenen WordPress-Adapter.');
        }
        $campaign_id = absint($object['campaign_post_id'] ?? 0);
        $campaign = $this->output_campaign_by_post_id($campaign_id);
        if (!is_array($campaign)) { return new WP_Error('banner_campaign_missing', 'Digistore24-Bannerkampagne fehlt.'); }
        $campaign['active'] = true;
        if (!$this->save_campaign_record($campaign, $campaign_id)) { $this->output_deactivate_materialized_object($object, 'Digistore24-Aktivierung konnte nicht persistiert werden.'); return new WP_Error('banner_activation_failed', 'Digistore24-Bannerkampagne konnte nicht aktiviert werden.'); }
        global $wpdb; $table = $this->output_objects_table();
        $saved = $wpdb->update($table, array('status'=>'published','updated_at'=>time(),'last_verified'=>time(),'decision_reason'=>'Digistore24-Partnerschaft und vollständige Ausgabeprüfung erfolgreich.'), array('id'=>absint($object['id'] ?? 0)));
        if ($saved === false) {
            $campaign['active'] = false; $this->save_campaign_record($campaign, $campaign_id);
            return new WP_Error('output_digistore24_persistence_failed', 'Ausgabestatus konnte nicht persistiert werden; Last-Known-Good bleibt erhalten.');
        }
        $published = $this->output_object_by_id(absint($object['id'] ?? 0));
        if (!is_array($published) || (string) ($published['status'] ?? '') !== 'published') {
            $campaign['active'] = false; $this->save_campaign_record($campaign, $campaign_id);
            return new WP_Error('output_digistore24_persistence_unconfirmed', 'Persistierter Veröffentlichungsstatus konnte nicht bestätigt werden.');
        }
        $this->output_supersede_conflicting_objects($published, (string) ($published['object_key'] ?? ''));
        return true;
    }
    /**
     * eBay-Produktinhalte dürfen in einer öffentlichen Produktzone nicht mit
     * Nicht-eBay-Produkten vermischt werden. Die Prüfung gilt in beide
     * Richtungen und blockiert die Aktivierung fail-closed.
     */
    private function output_product_provider_isolation($object) {
        if (!is_array($object) || sanitize_key((string) ($object['output_type'] ?? '')) !== 'product_campaign') { return true; }
        // V6.72.115: Die vorhandenen Mehrprovider-Modi separate/combined/automatic
        // erlauben eBay und idealo ausdrücklich gemeinsam. Die alte globale
        // Kohortensperre widersprach diesem Vertrag und konnte nach einer
        // Neuplanung eBay vollständig aus Kategorie-Produktplätzen verdrängen.
        // Provider-eigene eBay-Source/Policy/Public-Gates bleiben unverändert.
        $mode = method_exists($this, 'idealo_output_mode') ? $this->idealo_output_mode() : 'ebay_only';
        if (in_array($mode, array('separate','combined','automatic'), true)) { return true; }
        $provider = sanitize_key((string) ($object['provider'] ?? ''));
        $is_ebay = $provider === 'ebay';
        global $wpdb;
        $table = $this->output_objects_table();
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE portal_key=%s AND target_key=%s AND output_type='product_campaign' AND status='published'",
            (string) ($object['portal_key'] ?? ''),
            (string) ($object['target_key'] ?? '')
        ), ARRAY_A);
        foreach ((array) $rows as $row) {
            if (absint($row['id'] ?? 0) === absint($object['id'] ?? 0)) { continue; }
            $other_is_ebay = sanitize_key((string) ($row['provider'] ?? '')) === 'ebay';
            if ($other_is_ebay !== $is_ebay) {
                return new WP_Error('output_ebay_content_isolation_conflict', 'eBay- und Nicht-eBay-Produkte dürfen am selben Portalziel nicht gemeinsam öffentlich sein.');
            }
        }

        if (!method_exists($this, 'get_campaigns')) { return true; }
        $campaign_id = absint($object['campaign_post_id'] ?? 0);
        $incoming = $campaign_id > 0 ? $this->output_campaign_by_post_id($campaign_id) : null;
        if (!is_array($incoming)) { return new WP_Error('output_campaign_missing', 'Produktkampagne fehlt.'); }
        $incoming_targets = array_values(array_filter(array_map('sanitize_text_field', (array) ($incoming['automation_target_keys'] ?? array()))));
        if (!$incoming_targets) { return new WP_Error('output_campaign_target_missing', 'Produktkampagne besitzt kein exaktes Portalziel.'); }
        foreach ((array) $this->get_campaigns() as $campaign) {
            if (!is_array($campaign) || empty($campaign['active']) || absint($campaign['post_id'] ?? 0) === $campaign_id) { continue; }
            if (sanitize_key((string) ($campaign['creative_type'] ?? '')) !== 'product') { continue; }
            $targets = array_values(array_filter(array_map('sanitize_text_field', (array) ($campaign['automation_target_keys'] ?? array()))));
            if (!$targets || !array_intersect($incoming_targets, $targets)) { continue; }
            $other_is_ebay = sanitize_key((string) ($campaign['network'] ?? '')) === 'ebay';
            if ($other_is_ebay !== $is_ebay) {
                return new WP_Error('output_ebay_content_isolation_conflict', 'Am selben Portalziel ist bereits eine Produktkampagne des anderen Anbieter-Kohorts aktiv.');
            }
        }
        return true;
    }

    public function handle_output_object_action() {
        if (!current_user_can('manage_options')) {
            wp_die('Keine Berechtigung.');
        }
        check_admin_referer('ppar_output_object_action', 'ppar_output_nonce');
        $id = absint($_POST['output_id'] ?? 0);
        $action = sanitize_key((string) ($_POST['output_action'] ?? ''));
        $object = $this->output_object_by_id($id);
        if (!is_array($object)) {
            $this->output_redirect('failed', 'Ausgabeobjekt wurde nicht gefunden.');
        }
        global $wpdb;
        $table = $this->output_objects_table();
        $reason = sanitize_text_field((string) wp_unslash($_POST['output_reason'] ?? ''));
        if ($action === 'veto') { $action = 'veto_output'; }
        if ($action === 'veto_output') {
            if ($reason === '') { $reason = 'Ausgabeobjekt durch Chefentscheidung gesperrt.'; }
            $this->output_deactivate_materialized_object($object, $reason);
            $wpdb->update($table, array('status'=>'blocked_manual','decision_source'=>'manual_output_veto','decision_reason'=>$reason,'updated_at'=>time()), array('id'=>$id));
            if (method_exists($this, 'control_set_decision')) {
                $this->control_set_decision((string) ($object['portal_key'] ?? ''), 'output', (string) $id, 'veto', $reason, array('output_id'=>$id), 'output_veto');
            }
            $this->output_redirect('success', 'Diese Ausgabe wurde gesperrt. Das Creative bleibt für andere Ziele verfügbar.');
        }
        if ($action === 'pause_output') {
            if ($reason === '') { $reason = 'Ausgabeobjekt durch Chefentscheidung pausiert.'; }
            $this->output_deactivate_materialized_object($object, $reason);
            $wpdb->update($table, array('status'=>'paused_manual','decision_source'=>'manual_output_pause','decision_reason'=>$reason,'updated_at'=>time()), array('id'=>$id));
            if (method_exists($this, 'control_set_decision')) {
                $this->control_set_decision((string) ($object['portal_key'] ?? ''), 'output', (string) $id, 'paused', $reason, array('output_id'=>$id), 'output_pause');
            }
            $this->output_redirect('success', 'Diese Ausgabe wurde pausiert.');
        }
        if ($action === 'restore_output') {
            if ($reason === '') { $reason = 'Manuelle Ausgabeentscheidung zurückgenommen; erneute Freigabe erforderlich.'; }
            if (method_exists($this, 'control_reset_decision')) {
                $this->control_reset_decision((string) ($object['portal_key'] ?? ''), 'output', (string) $id, $reason);
            }
            $restored_status = (absint($object['campaign_post_id'] ?? 0) > 0 || absint($object['listing_post_id'] ?? 0) > 0) ? 'draft' : 'ready';
            $wpdb->update($table, array('status'=>$restored_status,'decision_source'=>'manual_output_restore','decision_reason'=>$reason,'updated_at'=>time()), array('id'=>$id));
            $this->output_redirect('success', 'Manuelle Ausgabeentscheidung wurde zurückgenommen.');
        }
        if (method_exists($this, 'control_emergency_stop_active') && $this->control_emergency_stop_active()) {
            $this->output_redirect('failed', 'Globale Affiliate-Notabschaltung ist aktiv.');
        }
        $row = $this->output_object_revalidate($object);
        if (is_wp_error($row)) {
            $wpdb->update($table, array('status'=>'blocked_runtime','decision_reason'=>$row->get_error_message(),'updated_at'=>time()), array('id'=>$id));
            $this->output_redirect('failed', $row->get_error_message());
        }
        $portal = $this->output_portal_by_key((string) ($object['portal_key'] ?? ''));
        if (is_wp_error($portal)) {
            $this->output_redirect('failed', $portal->get_error_message());
        }
        $adapter = sanitize_key((string) ($portal['adapter'] ?? ''));
        if ($action === 'publish_listing' && in_array((string) ($object['output_type'] ?? ''), array('hivepress_listing','portal_listing'), true)) {
            if (in_array($adapter, array('wordpress_local','wordpress_multisite'), true)) {
                $published = $this->output_with_portal($portal, function() use ($object) {
                    $post_id = absint($object['listing_post_id'] ?? 0);
                    if ($post_id <= 0 || !get_post($post_id)) {
                        return new WP_Error('listing_draft_missing', 'Listing-Entwurf fehlt.');
                    }
                    return wp_update_post(array('ID'=>$post_id,'post_status'=>'publish'), true);
                });
            } else {
                $callbacks = is_array($portal['callbacks'] ?? null) ? $portal['callbacks'] : array();
                $published = (!empty($callbacks['publish_listing']) && is_callable($callbacks['publish_listing']))
                    ? call_user_func($callbacks['publish_listing'], $object, $portal)
                    : new WP_Error('portal_publish_missing', 'Externer Portaladapter besitzt keine Listing-Freigabe.');
            }
            if (is_wp_error($published)) {
                $this->output_redirect('failed', $published->get_error_message());
            }
            $wpdb->update($table, array('status'=>'published','updated_at'=>time(),'last_verified'=>time()), array('id'=>$id));
            if (method_exists($this, 'control_set_decision')) {
                $this->control_set_decision((string) ($object['portal_key'] ?? ''), 'output', (string) $id, 'approved', 'HivePress-Listing durch Chefentscheidung veröffentlicht.', array('output_id'=>$id), 'output_publish');
            }
            $this->output_redirect('success', 'HivePress-Listing veröffentlicht.');
        }
        if ($action === 'activate_campaign' && in_array((string) ($object['output_type'] ?? ''), array('portal_banner','product_campaign'), true)) {
            if ((string) ($object['output_type'] ?? '') === 'product_campaign') {
                $isolation = $this->output_product_provider_isolation($object);
                if (is_wp_error($isolation)) {
                    $wpdb->update($table, array('status'=>'blocked_runtime','decision_reason'=>$isolation->get_error_message(),'updated_at'=>time()), array('id'=>$id));
                    $this->output_redirect('failed', $isolation->get_error_message());
                }
            }
            if (in_array($adapter, array('wordpress_local','wordpress_multisite'), true)) {
                $activated = $this->output_with_portal($portal, function() use ($object) {
                    $campaign_id = absint($object['campaign_post_id'] ?? 0);
                    $campaign = $this->output_campaign_by_post_id($campaign_id);
                    if (!is_array($campaign)) {
                        return new WP_Error('banner_campaign_missing', 'Bannerkampagne fehlt.');
                    }
                    $campaign['active'] = true;
                    return $this->save_campaign_record($campaign, $campaign_id) ? true : new WP_Error('banner_activation_failed', 'Bannerkampagne konnte nicht aktiviert werden.');
                });
            } else {
                $callbacks = is_array($portal['callbacks'] ?? null) ? $portal['callbacks'] : array();
                $activated = (!empty($callbacks[(string) ($object['output_type'] ?? '') === 'product_campaign' ? 'activate_product' : 'activate_banner']) && is_callable($callbacks[(string) ($object['output_type'] ?? '') === 'product_campaign' ? 'activate_product' : 'activate_banner']))
                    ? call_user_func($callbacks[(string) ($object['output_type'] ?? '') === 'product_campaign' ? 'activate_product' : 'activate_banner'], $object, $portal)
                    : new WP_Error('portal_activate_missing', 'Externer Portaladapter besitzt keine Kampagnenfreigabe.');
            }
            if (is_wp_error($activated)) {
                $this->output_redirect('failed', $activated->get_error_message());
            }
            $wpdb->update($table, array('status'=>'published','updated_at'=>time(),'last_verified'=>time()), array('id'=>$id));
            if (method_exists($this, 'control_set_decision')) {
                $this->control_set_decision((string) ($object['portal_key'] ?? ''), 'output', (string) $id, 'approved', (string) ($object['output_type'] ?? '') === 'product_campaign' ? 'Produktkampagne durch Chefentscheidung aktiviert.' : 'Bannerkampagne durch Chefentscheidung aktiviert.', array('output_id'=>$id), 'output_publish');
            }
            $this->output_redirect('success', (string) ($object['output_type'] ?? '') === 'product_campaign' ? 'Produktkampagne aktiviert.' : 'Bannerkampagne aktiviert.');
        }
        $this->output_redirect('failed', 'Unzulässige Aktion.');
    }

    private function output_redirect($status, $message) {
        wp_safe_redirect(add_query_arg(array('page'=>'affiliate-portal-outputs','ppar_output'=>$status,'ppar_message'=>rawurlencode((string) $message)), admin_url('admin.php')));
        exit;
    }

    public function render_output_objects_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $this->maybe_install_output_objects_schema();
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$this->output_objects_table()} ORDER BY updated_at DESC, id DESC LIMIT 300", ARRAY_A);
        $notice = sanitize_key((string) ($_GET['ppar_output'] ?? ''));
        $message = rawurldecode((string) ($_GET['ppar_message'] ?? ''));
        ?>
        <div class="wrap">
            <h1>Ausgaben &amp; Freigabe</h1>
            <p>Jede Zeile verbindet genau ein Creative mit einem Portalziel. Bannerkampagne und HivePress-Listing bleiben getrennt. Ohne eindeutigen Treffer oder verifizierte Bildmaße gibt es keine Freigabe.</p>
            <?php if ($notice === 'success') : ?><div class="notice notice-success inline"><p><?php echo esc_html($message); ?></p></div><?php endif; ?>
            <?php if ($notice === 'failed') : ?><div class="notice notice-error inline"><p><?php echo esc_html($message); ?></p></div><?php endif; ?>
            <table class="widefat striped"><thead><tr><th>Partner / Creative</th><th>Portal / Ausgabe</th><th>Ziel</th><th>Status</th><th>Prüfung</th><th>Aktion</th></tr></thead><tbody>
            <?php if (!$rows) : ?><tr><td colspan="6">Noch keine Ausgabeobjekte.</td></tr><?php endif; ?>
            <?php foreach ((array) $rows as $row) :
                $creative = $this->output_creative_row((string) ($row['creative_identity_hash'] ?? ''));
                $payload = json_decode((string) ($row['payload'] ?? ''), true);
                $payload = is_array($payload) ? $payload : array();
                ?>
                <tr>
                    <td><strong><?php echo esc_html((string) ($creative['partner_name'] ?? $row['partner_external_id'])); ?></strong><br><?php echo esc_html((string) ($creative['title'] ?? 'Creative fehlt')); ?><br><small><?php echo esc_html(absint($row['image_width']) . ' × ' . absint($row['image_height'])); ?></small></td>
                    <td><?php echo esc_html((string) $row['portal_key']); ?><br><strong><?php echo esc_html((string) $row['output_type']); ?></strong><?php if (!empty($row['slot_id'])) : ?><br><?php echo esc_html((string) $row['slot_id']); ?><?php endif; ?></td>
                    <td><?php echo esc_html((string) $row['target_label']); ?><br><small><?php echo esc_html((string) $row['target_key']); ?></small></td>
                    <td><strong><?php echo esc_html((string) $row['status']); ?></strong><br><?php echo absint($row['confidence']); ?> %</td>
                    <td><?php echo esc_html((string) $row['decision_reason']); ?><?php if (!empty($payload['preview_url'])) : ?><br><a href="<?php echo esc_url((string) $payload['preview_url']); ?>">Entwurfsvorschau öffnen</a><?php endif; ?></td>
                    <td>
                        <?php $status = (string) $row['status']; ?>
                        <?php if (in_array($status, array('draft','blocked_runtime'), true)) : ?>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:8px">
                            <input type="hidden" name="action" value="ppar_output_object_action"><input type="hidden" name="output_id" value="<?php echo absint($row['id']); ?>">
                            <?php wp_nonce_field('ppar_output_object_action', 'ppar_output_nonce'); ?>
                            <?php if (in_array((string) $row['output_type'], array('hivepress_listing','portal_listing'), true)) : ?><button class="button button-primary" name="output_action" value="publish_listing">Listing veröffentlichen</button><?php endif; ?>
                            <?php if (in_array((string) $row['output_type'], array('portal_banner','product_campaign'), true)) : ?><button class="button button-primary" name="output_action" value="activate_campaign"><?php echo $status === 'blocked_runtime' ? 'Erneut prüfen & aktivieren' : ((string) $row['output_type'] === 'product_campaign' ? 'Produktkampagne aktivieren' : 'Banner aktivieren'); ?></button><?php endif; ?>
                        </form>
                        <?php elseif ($status === 'published') : ?>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:8px"><input type="hidden" name="action" value="ppar_output_object_action"><input type="hidden" name="output_id" value="<?php echo absint($row['id']); ?>"><?php wp_nonce_field('ppar_output_object_action', 'ppar_output_nonce'); ?><input type="text" name="output_reason" required placeholder="Begründung für Pause" style="max-width:210px"> <button class="button" name="output_action" value="pause_output">Ausgabe pausieren</button></form>
                        <?php elseif (in_array($status, array('paused_manual','blocked_manual'), true)) : ?>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:8px"><input type="hidden" name="action" value="ppar_output_object_action"><input type="hidden" name="output_id" value="<?php echo absint($row['id']); ?>"><?php wp_nonce_field('ppar_output_object_action', 'ppar_output_nonce'); ?><input type="text" name="output_reason" required placeholder="Begründung für Rücknahme" style="max-width:210px"> <button class="button" name="output_action" value="restore_output">Zur Automatik zurückkehren</button></form>
                        <?php endif; ?>
                        <?php if (!in_array($status, array('blocked_manual','superseded'), true)) : ?>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="ppar_output_object_action"><input type="hidden" name="output_id" value="<?php echo absint($row['id']); ?>"><?php wp_nonce_field('ppar_output_object_action', 'ppar_output_nonce'); ?><input type="text" name="output_reason" required placeholder="Begründung für Veto" style="max-width:210px"> <button class="button" name="output_action" value="veto_output">Nur diese Ausgabe sperren</button></form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody></table>
        </div>
        <?php
    }
}
