=== Hobby Depot Affiliate-Zentrale ===
Contributors: hobby-depot
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 0.1.13-dev

== Status ==

HD-009 ist eine laufende Portierung der bestehenden Affiliate-Zentrale.
Entwicklungs-/Installationskandidat für den kontrollierten Live-Test.

== Architektur ==

* Zentrale Affiliate-/Provider-Engine bleibt erhalten.
* Hobby-Depot-Ziele kommen read-only aus HD-004 über die zentrale Kategorie-Registry.
* eBay und idealo besitzen reale Adapter. eBay ist in Hobby Depot BUSINESS-only; der frühere PRIVATE/HivePress-Zweig ist deaktiviert.
* Amazon nutzt die geprüfte ASIN-Brücke aus dem idealo-Feed und erzeugt keine eigene Amazon-Produktsuche.
* Provider-Secrets werden ausschließlich über die vorhandenen Laufzeit-/Optionsschnittstellen verwendet und nicht in diese Quelle dokumentiert.
* Projektfremde Portal-, Produkt-, Recovery- und Fachbestände werden nicht übernommen.

== Release-Regel ==

Erst nach vollständiger Bereinigung sowie Positiv-, Negativ- und Regressionstests darf ein Installationskandidat entstehen.

== Gezielte Harmonisierung 0.1.9-dev ==

* Die fünf bereits enthaltenen Zusatzmodule werden einmalig gestartet.
* Vorhandene Amazon-ASIN-/Tracking-Anbindung aus Hobby Depot bleibt aktiv; kein Downgrade zu einem nur vorbereiteten Amazon-Adapter.
* eBay-Löschmeldungen werden bei fehlgeschlagener WordPress-Post-Löschung oder nicht gespeicherter Bestätigung nicht als erfolgreich quittiert.
* HD003/HD004, WordPress-Pluginordner, bestehende Daten und gespeicherte Provider-Einstellungen bleiben erhalten.
* Ein vollständiger Versionsvergleich zur projektfremden neuesten Referenz konnte nicht abgeschlossen werden. Keine Zusage einer vollständigen Gleichheit.
* Vor Produktiveinsatz sind Live-Upgrade- und Provider-Prüfungen erforderlich.

== Harmonisierung 0.1.10-dev (07.11.2026) ==

* eBay-Kontolöschung prüft Quellpayloads in maximal 100er-Paketen, stoppt vor Löschung bei Lesefehlern.
* BUSINESS-Abdeckungsprüfung lädt Produkt- und Kreativdatensätze gebündelt statt Einzelabfragen.
* Doppelprüfung bei der Preis-Neubewertung entfernt, nur Preiswert und Rangfolge werden aktualisiert.
* Bei von Fremdmarktplätzen verdrängten Treffern höchstens eine zusätzliche eBay-Suchergebnisseite.
* Vorhandener Status-Endpunkt führt keine schwere synchrone Arbeit aus; keine zweite Cronlogik eingezogen.
* Pferdespezifische Produktgruppen, Registrierungen und Accounts nicht übernommen.
* Lokaler Installationskandidat; keine produktive WordPress-/Provider-Freigabe ohne Live-Nachweis.

== 0.1.12-dev – Amazon + idealo Pilot ==
* Amazon-Produktsuche: DataForSEO manuell, konkrete Hobbyseite, ASIN-Auswahl.
* Idealo: separate Feed-Recherche, keine vorgegebenen Adspace-/Feed-IDs; explizite Hobby-Depot-Bestätigung notwendig.
* Eigene Quer-/Quadratbanner, einzelne Themenzuordnung, keine Bilder fremder Anbieter kopiert.
* Sichtbare Startanbieter nur Amazon und idealo. Vorhandene andere Partner bleiben gespeichert.
* Backend- und Live-API-Tests sind beim Betreiber erforderlich.

== 0.1.13-dev – Rückkehr zur vorhandenen Banner-Automatik ==
* Manuellen separaten Eigenbanner-Formularweg samt eigenem Banner-Renderer entfernt.
* Vorhandene zentrale Banner- und Kategorie-/Elternpfad-Automatik wieder für Banner-Slots verwendet; öffentlicher Start weiterhin ausschließlich Amazon und idealo.
* Kostenfreien DataForSEO-API-Zugangstest hinzugefügt; keine Produktsuche, kein Verbrauch.
* Bereits gespeicherte Konten, Produkte, Bannerdateien und Zielkategorien unverändert belassen.
