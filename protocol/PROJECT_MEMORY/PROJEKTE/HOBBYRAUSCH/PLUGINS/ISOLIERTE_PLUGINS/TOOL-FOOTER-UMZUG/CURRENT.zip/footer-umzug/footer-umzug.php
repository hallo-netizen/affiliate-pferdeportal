<?php
/**
 * Plugin Name: Footer-Umzug
 * Description: Exportiert und importiert Footer-Menüs samt verlinkten Seiten/Inhalten. Der Import kann Portalname, Links und alte Themenbezüge neutralisieren. Design-/Astra-Einstellungen werden nicht importiert.
 * Version: 1.1.1
 * Author: OpenAI
 * Requires at least: 6.0
 * Requires PHP: 8.1
 */

if (!defined('ABSPATH')) { exit; }

final class PAFU_Footer_Umzug {
    private const FORMAT = 'pafu-footer-v1';
    private const VERSION = 1;
    private const NONCE = 'pafu_footer_umzug_nonce';

    public static function init(): void {
        add_action('admin_menu', [self::class, 'admin_menu']);
        add_action('admin_post_pafu_export', [self::class, 'handle_export']);
        add_action('admin_post_pafu_import', [self::class, 'handle_import']);
    }

    public static function admin_menu(): void {
        add_management_page(
            'Footer-Umzug',
            'Footer-Umzug',
            'manage_options',
            'footer-umzug',
            [self::class, 'render_page']
        );
    }

    public static function render_page(): void {
        if (!current_user_can('manage_options')) { return; }
        $default_name = get_bloginfo('name') ?: 'Hobby Depot';
        $notice = isset($_GET['pafu_notice']) ? sanitize_text_field(wp_unslash($_GET['pafu_notice'])) : '';
        ?>
        <div class="wrap">
            <h1>Footer-Umzug</h1>
            <p><strong>Inhalte, nicht Design:</strong> Übertragen werden Footer-Menüs, Menülinks, die darin verlinkten Seiten samt Inhalt sowie die Zuordnung der Footer-Widgets zu den vorhandenen Footer-Widgetflächen. Astra-Layout, Farben, Spalten und sonstige Design-Einstellungen werden beim Import nicht verändert.</p>

            <?php if ($notice !== ''): ?>
                <div class="notice notice-success is-dismissible"><p><?php echo esc_html($notice); ?></p></div>
            <?php endif; ?>

            <hr>
            <h2>1. Footer exportieren</h2>
            <p>Erstellt eine JSON-Datei mit Footer-Menüs und den verlinkten Seiten. Vorhandene Design-Daten können aus Kompatibilitätsgründen im Export enthalten sein, werden von dieser Version beim Import aber ignoriert.</p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="pafu_export">
                <?php wp_nonce_field(self::NONCE, '_pafu_nonce'); ?>
                <?php submit_button('Footer exportieren', 'secondary'); ?>
            </form>

            <hr>
            <h2>2. Footer importieren</h2>
            <form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="pafu_import">
                <?php wp_nonce_field(self::NONCE, '_pafu_nonce'); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="pafu_file">Exportdatei</label></th>
                        <td><input type="file" id="pafu_file" name="pafu_file" accept="application/json,.json" required></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="target_name">Zielname</label></th>
                        <td>
                            <input type="text" class="regular-text" id="target_name" name="target_name" value="<?php echo esc_attr($default_name); ?>" required>
                            <p class="description">Beispiel: Hobby Depot</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="target_email">Ziel-E-Mail</label></th>
                        <td>
                            <input type="text" class="regular-text" id="target_email" name="target_email" value="">
                            <p class="description">Optional. Leer = alte Portal-Mail wird durch „[E-Mail-Adresse ergänzen]“ ersetzt, nicht geraten.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Portalwechsel</th>
                        <td>
                            <label><input type="checkbox" name="neutralize" value="1" checked> Alte Marken-, Domain- und Themenbezüge neutralisieren</label>
                            <p class="description">Für Pferde Atelier → Hobby Depot sind zusätzliche Themenbereinigungen eingebaut. Allgemeine Inhalte/Rechtstexte bleiben ansonsten erhalten.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Importieren'); ?>
            </form>
        </div>
        <?php
    }

    public static function handle_export(): void {
        self::guard();
        $payload = self::build_export();
        $host = wp_parse_url(home_url('/'), PHP_URL_HOST) ?: 'website';
        $filename = 'footer-umzug-' . sanitize_file_name($host) . '.json';
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    private static function build_export(): array {
        $locations = get_theme_mod('nav_menu_locations', []);
        if (!is_array($locations)) { $locations = []; }
        $footer_locations = [];
        $menu_ids = [];
        foreach ($locations as $location => $menu_id) {
            if (stripos((string)$location, 'footer') !== false && (int)$menu_id > 0) {
                $footer_locations[(string)$location] = (int)$menu_id;
                $menu_ids[(int)$menu_id] = true;
            }
        }

        $sidebars = wp_get_sidebars_widgets();
        if (!is_array($sidebars)) { $sidebars = []; }
        $footer_sidebars = [];
        $widgets = [];
        foreach ($sidebars as $sidebar_id => $widget_ids) {
            if (stripos((string)$sidebar_id, 'footer') === false || !is_array($widget_ids)) { continue; }
            $footer_sidebars[(string)$sidebar_id] = array_values($widget_ids);
            foreach ($widget_ids as $widget_id) {
                $parsed = self::parse_widget_id((string)$widget_id);
                if (!$parsed) { continue; }
                [$base, $number] = $parsed;
                $all = get_option('widget_' . $base, []);
                if (!is_array($all) || !isset($all[$number]) || !is_array($all[$number])) { continue; }
                $settings = $all[$number];
                $widgets[(string)$widget_id] = ['base' => $base, 'settings' => $settings];
                if ($base === 'nav_menu' && !empty($settings['nav_menu'])) {
                    $menu_ids[(int)$settings['nav_menu']] = true;
                }
            }
        }

        $menus = [];
        $pages = [];
        foreach (array_keys($menu_ids) as $menu_id) {
            $menu = wp_get_nav_menu_object($menu_id);
            if (!$menu || is_wp_error($menu)) { continue; }
            $items = wp_get_nav_menu_items($menu_id, ['post_status' => 'any']);
            if (!is_array($items)) { $items = []; }
            $out_items = [];
            foreach ($items as $item) {
                $out_items[] = [
                    'id' => (int)$item->ID,
                    'title' => (string)$item->title,
                    'url' => (string)$item->url,
                    'type' => (string)$item->type,
                    'object' => (string)$item->object,
                    'object_id' => (int)$item->object_id,
                    'parent' => (int)$item->menu_item_parent,
                    'order' => (int)$item->menu_order,
                    'attr_title' => (string)$item->attr_title,
                    'description' => (string)$item->description,
                    'target' => (string)$item->target,
                    'classes' => is_array($item->classes) ? array_values($item->classes) : [],
                    'xfn' => (string)$item->xfn,
                ];
                if ($item->type === 'post_type' && $item->object === 'page' && (int)$item->object_id > 0) {
                    $page = get_post((int)$item->object_id);
                    if ($page && $page->post_type === 'page') {
                        $pages[(string)$page->ID] = self::page_to_array($page);
                    }
                }
            }
            $menus[(string)$menu_id] = [
                'id' => (int)$menu->term_id,
                'name' => (string)$menu->name,
                'slug' => (string)$menu->slug,
                'items' => $out_items,
            ];
        }

        $astra = get_option('astra-settings', []);
        $astra_footer = [];
        if (is_array($astra)) {
            foreach ($astra as $key => $value) {
                if (stripos((string)$key, 'footer') !== false || preg_match('/^(hb|hba|hbb)-/', (string)$key)) {
                    $astra_footer[(string)$key] = $value;
                }
            }
        }

        return [
            'format' => self::FORMAT,
            'version' => self::VERSION,
            'source_url' => home_url('/'),
            'source_name' => get_bloginfo('name'),
            'exported' => gmdate('c'),
            'sidebars' => $footer_sidebars,
            'widgets' => $widgets,
            'menus' => $menus,
            'footer_locations' => $footer_locations,
            'astra_footer' => $astra_footer,
            'pages' => $pages,
            'media' => [],
        ];
    }

    public static function handle_import(): void {
        self::guard();
        if (empty($_FILES['pafu_file']['tmp_name']) || !is_uploaded_file($_FILES['pafu_file']['tmp_name'])) {
            wp_die('Keine gültige Importdatei erhalten.');
        }
        $raw = file_get_contents($_FILES['pafu_file']['tmp_name']);
        if ($raw === false || $raw === '') { wp_die('Importdatei ist leer.'); }
        $data = json_decode($raw, true);
        if (!is_array($data) || ($data['format'] ?? '') !== self::FORMAT || (int)($data['version'] ?? 0) !== self::VERSION) {
            wp_die('Diese Datei ist kein unterstützter Footer-Umzug-Export.');
        }

        $target_name = sanitize_text_field(wp_unslash($_POST['target_name'] ?? ''));
        if ($target_name === '') { $target_name = get_bloginfo('name') ?: 'Hobby Depot'; }
        $target_email = sanitize_text_field(wp_unslash($_POST['target_email'] ?? ''));
        $neutralize = !empty($_POST['neutralize']);

        $ctx = [
            'source_name' => (string)($data['source_name'] ?? ''),
            'source_url' => rtrim((string)($data['source_url'] ?? ''), '/'),
            'target_name' => $target_name,
            'target_email' => $target_email,
            'target_url' => rtrim(home_url('/'), '/'),
            'neutralize' => $neutralize,
            'horse_source' => self::looks_like_horse_source($data),
        ];

        $result = self::import_content($data, $ctx);
        $notice = sprintf(
            'Import abgeschlossen: %d Seiten erstellt, %d aktualisiert, %d Menüs aufgebaut, %d Menüeinträge gesetzt, %d Footer-Widgets in %d Footer-Bereiche gebunden. Design/Astra unverändert.',
            $result['pages_created'],
            $result['pages_updated'],
            $result['menus'],
            $result['items'],
            $result['widgets'],
            $result['widget_areas']
        );
        wp_safe_redirect(add_query_arg(['page' => 'footer-umzug', 'pafu_notice' => $notice], admin_url('tools.php')));
        exit;
    }

    private static function import_content(array $data, array $ctx): array {
        $page_map = [];
        $created = 0;
        $updated = 0;

        $pages = isset($data['pages']) && is_array($data['pages']) ? $data['pages'] : [];
        foreach ($pages as $source_id => $page) {
            if (!is_array($page)) { continue; }
            $original_title = (string)($page['title'] ?? '');
            $original_slug = sanitize_title((string)($page['slug'] ?? $original_title));
            [$title, $slug] = self::transform_page_identity($original_title, $original_slug, $ctx);
            $content = self::transform_text((string)($page['content'] ?? ''), $ctx, 'page:' . $original_slug);
            $excerpt = self::transform_text((string)($page['excerpt'] ?? ''), $ctx, 'excerpt:' . $original_slug);

            $existing = self::find_existing_page($slug, $original_slug, $title, $original_title);
            $postarr = [
                'post_type' => 'page',
                'post_status' => in_array(($page['status'] ?? 'publish'), ['publish','draft','private','pending'], true) ? $page['status'] : 'publish',
                'post_title' => $title,
                'post_name' => $slug,
                'post_content' => $content,
                'post_excerpt' => $excerpt,
                'menu_order' => (int)($page['menu_order'] ?? 0),
                'post_parent' => 0,
            ];
            if ($existing) {
                $postarr['ID'] = $existing;
                $new_id = wp_update_post(wp_slash($postarr), true);
                if (is_wp_error($new_id)) { continue; }
                $updated++;
            } else {
                $new_id = wp_insert_post(wp_slash($postarr), true);
                if (is_wp_error($new_id)) { continue; }
                $created++;
            }
            update_post_meta((int)$new_id, '_pafu_source_page_id', (string)$source_id);
            update_post_meta((int)$new_id, '_pafu_source_slug', $original_slug);
            $page_map[(string)$source_id] = (int)$new_id;
        }

        // Rebind Gutenberg/Kubio data-id attributes to the newly created/updated target page IDs.
        if ($page_map) {
            foreach ($page_map as $source_id => $target_id) {
                $post = get_post((int)$target_id);
                if (!$post || $post->post_type !== 'page') { continue; }
                $content = (string)$post->post_content;
                foreach ($page_map as $old_id => $new_id) {
                    $content = str_replace('data-id="' . (string)$old_id . '"', 'data-id="' . (string)$new_id . '"', $content);
                }
                if ($content !== (string)$post->post_content) {
                    wp_update_post(wp_slash(['ID' => (int)$target_id, 'post_content' => $content]));
                }
            }
        }

        $menu_map = [];
        $menus_count = 0;
        $items_count = 0;
        $menus = isset($data['menus']) && is_array($data['menus']) ? $data['menus'] : [];
        foreach ($menus as $source_menu_id => $menu) {
            if (!is_array($menu)) { continue; }
            $menu_name = self::transform_text((string)($menu['name'] ?? 'Footer'), $ctx, 'menu-name');
            $menu_obj = wp_get_nav_menu_object($menu_name);
            if (!$menu_obj) {
                $maybe = wp_create_nav_menu($menu_name);
                if (is_wp_error($maybe)) { continue; }
                $target_menu_id = (int)$maybe;
            } else {
                $target_menu_id = (int)$menu_obj->term_id;
            }
            $menus_count++;
            $menu_map[(string)$source_menu_id] = $target_menu_id;

            $existing_items = wp_get_nav_menu_items($target_menu_id, ['post_status' => 'any']);
            if (is_array($existing_items)) {
                foreach ($existing_items as $existing_item) {
                    wp_delete_post((int)$existing_item->ID, true);
                }
            }

            $source_to_target_item = [];
            $items = isset($menu['items']) && is_array($menu['items']) ? $menu['items'] : [];
            usort($items, static fn($a,$b) => ((int)($a['order'] ?? 0)) <=> ((int)($b['order'] ?? 0)));
            foreach ($items as $item) {
                if (!is_array($item)) { continue; }
                $source_item_id = (string)($item['id'] ?? '');
                $source_parent = (string)($item['parent'] ?? '0');
                $args = [
                    'menu-item-title' => self::transform_text((string)($item['title'] ?? ''), $ctx, 'menu-title'),
                    'menu-item-status' => 'publish',
                    'menu-item-position' => (int)($item['order'] ?? 0),
                    'menu-item-attr-title' => (string)($item['attr_title'] ?? ''),
                    'menu-item-description' => self::transform_text((string)($item['description'] ?? ''), $ctx, 'menu-description'),
                    'menu-item-target' => (string)($item['target'] ?? ''),
                    'menu-item-xfn' => (string)($item['xfn'] ?? ''),
                    'menu-item-classes' => is_array($item['classes'] ?? null) ? implode(' ', array_map('sanitize_html_class', $item['classes'])) : '',
                ];
                if (($item['type'] ?? '') === 'post_type' && ($item['object'] ?? '') === 'page' && isset($page_map[(string)($item['object_id'] ?? '')])) {
                    $args['menu-item-type'] = 'post_type';
                    $args['menu-item-object'] = 'page';
                    $args['menu-item-object-id'] = $page_map[(string)$item['object_id']];
                } else {
                    $args['menu-item-type'] = 'custom';
                    $args['menu-item-url'] = self::transform_url((string)($item['url'] ?? ''), $ctx);
                }
                if ($source_parent !== '0' && isset($source_to_target_item[$source_parent])) {
                    $args['menu-item-parent-id'] = $source_to_target_item[$source_parent];
                }
                $new_item_id = wp_update_nav_menu_item($target_menu_id, 0, $args);
                if (!is_wp_error($new_item_id)) {
                    $items_count++;
                    if ($source_item_id !== '') { $source_to_target_item[$source_item_id] = (int)$new_item_id; }
                }
            }
        }

        $footer_locations = isset($data['footer_locations']) && is_array($data['footer_locations']) ? $data['footer_locations'] : [];
        if ($footer_locations) {
            $locations = get_theme_mod('nav_menu_locations', []);
            if (!is_array($locations)) { $locations = []; }
            foreach ($footer_locations as $location => $source_menu_id) {
                if (isset($menu_map[(string)$source_menu_id])) {
                    $locations[(string)$location] = $menu_map[(string)$source_menu_id];
                }
            }
            set_theme_mod('nav_menu_locations', $locations);
        }

        // Footer-Inhalt muss nicht nur existieren, sondern auch in den bereits
        // vorhandenen Footer-Widgetflächen hängen. Das ist Inhaltszuordnung,
        // kein Astra-/Designimport.
        $widget_result = self::import_footer_widget_bindings($data, $ctx, $menu_map);

        return [
            'pages_created' => $created,
            'pages_updated' => $updated,
            'menus' => $menus_count,
            'items' => $items_count,
            'widgets' => $widget_result['widgets'],
            'widget_areas' => $widget_result['areas'],
        ];
    }

    private static function import_footer_widget_bindings(array $data, array $ctx, array $menu_map): array {
        $source_sidebars = isset($data['sidebars']) && is_array($data['sidebars']) ? $data['sidebars'] : [];
        $source_widgets = isset($data['widgets']) && is_array($data['widgets']) ? $data['widgets'] : [];
        if (!$source_sidebars || !$source_widgets) { return ['widgets' => 0, 'areas' => 0]; }

        $sidebars = wp_get_sidebars_widgets();
        if (!is_array($sidebars)) { $sidebars = []; }

        $all_maps = get_option('_pafu_footer_widget_map_v1', []);
        if (!is_array($all_maps)) { $all_maps = []; }
        $namespace = md5((string)($data['source_url'] ?? '') . '|' . (string)($data['source_name'] ?? ''));
        if (!isset($all_maps[$namespace]) || !is_array($all_maps[$namespace])) { $all_maps[$namespace] = []; }

        $widgets_count = 0;
        $areas_count = 0;

        foreach ($source_sidebars as $sidebar_id => $source_widget_ids) {
            if (stripos((string)$sidebar_id, 'footer') === false || !is_array($source_widget_ids)) { continue; }

            $target_widget_ids = [];
            foreach ($source_widget_ids as $source_widget_id) {
                $source_widget_id = (string)$source_widget_id;
                if (!isset($source_widgets[$source_widget_id]) || !is_array($source_widgets[$source_widget_id])) { continue; }
                $meta = $source_widgets[$source_widget_id];
                $base = sanitize_key((string)($meta['base'] ?? ''));
                if (!in_array($base, ['nav_menu', 'custom_html', 'text', 'block'], true)) { continue; }
                $settings = isset($meta['settings']) && is_array($meta['settings']) ? $meta['settings'] : [];

                if ($base === 'nav_menu') {
                    $source_menu_id = (string)($settings['nav_menu'] ?? '');
                    if ($source_menu_id === '' || !isset($menu_map[$source_menu_id])) { continue; }
                    $settings['nav_menu'] = (int)$menu_map[$source_menu_id];
                }

                foreach ($settings as $key => $value) {
                    if (is_string($value)) {
                        $settings[$key] = self::transform_text($value, $ctx, 'widget:' . $base . ':' . (string)$key);
                    }
                }

                $number = 0;
                if (isset($all_maps[$namespace][$source_widget_id])) {
                    $mapped = $all_maps[$namespace][$source_widget_id];
                    if (is_array($mapped) && ($mapped['base'] ?? '') === $base) { $number = (int)($mapped['number'] ?? 0); }
                }

                $option_name = 'widget_' . $base;
                $all_settings = get_option($option_name, []);
                if (!is_array($all_settings)) { $all_settings = []; }
                if ($number < 1) {
                    $numeric = array_filter(array_keys($all_settings), static fn($k) => is_int($k) || ctype_digit((string)$k));
                    $numeric = array_map('intval', $numeric);
                    $number = $numeric ? max($numeric) + 1 : 2;
                }

                $all_settings[$number] = $settings;
                if (!isset($all_settings['_multiwidget'])) { $all_settings['_multiwidget'] = 1; }
                update_option($option_name, $all_settings);

                $target_widget_id = $base . '-' . $number;
                $target_widget_ids[] = $target_widget_id;
                $all_maps[$namespace][$source_widget_id] = ['base' => $base, 'number' => $number];
                $widgets_count++;
            }

            // Die exportierte Footer-Fläche wird inhaltlich exakt gebunden.
            // Andere Sidebars/Widgetflächen bleiben unberührt.
            $sidebars[(string)$sidebar_id] = $target_widget_ids;
            $areas_count++;
        }

        update_option('sidebars_widgets', $sidebars);
        update_option('_pafu_footer_widget_map_v1', $all_maps);

        return ['widgets' => $widgets_count, 'areas' => $areas_count];
    }

    private static function transform_page_identity(string $title, string $slug, array $ctx): array {
        if (!empty($ctx['neutralize']) && !empty($ctx['horse_source'])) {
            $map = [
                'Pferde Journal' => ['Magazin', 'journal'],
                'Werbung im Atelier' => ['Werben im ' . $ctx['target_name'], 'werbung'],
            ];
            if (isset($map[$title])) { return $map[$title]; }
            if ($slug === 'werbung-im-atelier') { return ['Werben im ' . $ctx['target_name'], 'werbung']; }
        }
        $new_title = self::transform_text($title, $ctx, 'page-title');
        return [$new_title, $slug];
    }

    private static function find_existing_page(string $slug, string $original_slug, string $title, string $original_title): int {
        foreach (array_unique(array_filter([$slug, $original_slug])) as $candidate_slug) {
            $page = get_page_by_path($candidate_slug, OBJECT, 'page');
            if ($page) { return (int)$page->ID; }
        }
        $q = new WP_Query([
            'post_type' => 'page', 'post_status' => 'any', 'posts_per_page' => 5,
            'meta_query' => [[ 'key' => '_pafu_source_slug', 'value' => $original_slug ]],
            'fields' => 'ids', 'no_found_rows' => true,
        ]);
        if (!empty($q->posts[0])) { return (int)$q->posts[0]; }
        foreach (array_unique(array_filter([$title, $original_title])) as $candidate_title) {
            $page = get_page_by_title($candidate_title, OBJECT, 'page');
            if ($page) { return (int)$page->ID; }
        }
        return 0;
    }

    private static function transform_text(string $text, array $ctx, string $where = ''): string {
        if ($text === '' || empty($ctx['neutralize'])) { return $text; }

        $source_url = (string)$ctx['source_url'];
        $target_url = (string)$ctx['target_url'];
        if ($source_url !== '') {
            $text = str_replace([$source_url, $source_url . '/'], [$target_url, $target_url . '/'], $text);
        }
        // Known source fallback from the real Pferde-Atelier export.
        $text = str_replace(['https://oliver-beil.de', 'http://oliver-beil.de'], $target_url, $text);

        // Replace exact contact/domain values before changing the brand string, so e-mail addresses do not become malformed.
        $email_replacement = trim((string)$ctx['target_email']) !== '' ? (string)$ctx['target_email'] : '[E-Mail-Adresse ergänzen]';
        $text = str_ireplace(['ihr(at)pferde-atelier.de', 'ihr@pferde-atelier.de'], $email_replacement, $text);

        $target_host = wp_parse_url($target_url, PHP_URL_HOST) ?: '';
        if ($target_host !== '') {
            $text = str_ireplace(['www.pferde-atelier.de', 'pferde-atelier.de'], $target_host, $text);
        }

        $source_name = trim((string)$ctx['source_name']);
        $target_name = (string)$ctx['target_name'];
        if ($source_name !== '') { $text = str_ireplace($source_name, $target_name, $text); }
        $text = str_ireplace(['Pferde Atelier', 'Pferde-Atelier', 'Pferdeatelier', 'Pferde Atilers'], $target_name, $text);

        $text = str_replace('[pferde_journal]', '[affiliate_portal_journal]', $text);
        $text = str_replace('[pferde_atelier_footer_logo]', '', $text);

        if (!empty($ctx['horse_source'])) {
            $exact = [
                'Pferde Journal' => 'Magazin',
                'Werbung im Atelier' => 'Werben im ' . $target_name,
                'Diese Allgemeinen Geschäftsbedingungen gelten für die Nutzung dieses Pferde Atilers' => 'Diese Allgemeinen Geschäftsbedingungen gelten für die Nutzung dieses Portals',
                'Das Internet-Angebot des Pferde Ateliers enthält Links zu anderen Websites.' => 'Das Internet-Angebot dieses Portals enthält Links zu anderen Websites.',
                'Beste Informationen, hilfreiche Empfehlungen und ausgewählte Angebote rund um Pferd, Stall und Reiter.' => 'Ideen, hilfreiche Informationen und ausgewählte Angebote rund um Hobbys, Projekte und Freizeit.',
                'Erreichen Sie Menschen, die sich gezielt für Pferde, Reitsport, Pferdehaltung, Ausrüstung, Pflege, Training und Dienstleistungen rund ums Pferd interessieren.' => 'Erreichen Sie Menschen, die sich gezielt für Hobbys, Freizeit, Ausrüstung, Materialien, Kurse, Projekte und passende Dienstleistungen interessieren.',
                'Unsere Werbemöglichkeiten eignen sich besonders für Anbieter aus den Bereichen Pferdezubehör, Stallbedarf, Pferdefutter, Reitbekleidung, Pferdedecken, Sättel, Reitschulen, Trainer, Stallbetreiber, Hufbearbeitung, Pferdegesundheit, Transport, Versicherung und weitere Dienstleistungen rund ums Pferd.' => 'Unsere Werbemöglichkeiten eignen sich besonders für Anbieter aus den Bereichen Hobbyzubehör, Werkzeuge, Materialien, Ausrüstung, Kurse, Workshops, Vereine, Fachgeschäfte und weitere Dienstleistungen rund um Hobbys und Freizeit.',
                'zum Beispiel Pferdedecken, Sattel, Weidezaun, Pferdefutter, Stallbedarf oder Reitschule.' => 'zum Beispiel Ausrüstung, Werkzeuge, Materialien, Kurse, Workshops oder andere klar passende Hobbyangebote.',
                'Jetzt Werbemöglichkeit anfragen und Ihr Angebot rund ums Pferd sichtbar machen.' => 'Jetzt Werbemöglichkeit anfragen und Ihr Angebot rund um Hobbys und Freizeit sichtbar machen.',
                'Banner, Gestaltung und Zielseite müssen thematisch zum Pferdeportal passen.' => 'Banner, Gestaltung und Zielseite müssen thematisch zum Portal passen.',
                'Das Internet-Angebot des Pferde Ateliers enthält Links zu anderen Websites.' => 'Das Internet-Angebot dieses Portals enthält Links zu anderen Websites.',
                'Informationen zu Pferdegesundheit, Fütterung, Pflege, Training, Verhalten, Ausrüstung oder Sicherheit stellen keine Diagnose, Behandlungsempfehlung oder verbindliche Handlungsanweisung dar.' => 'fachliche Informationen zu Gesundheit, Sicherheit, Ausrüstung, Anwendung oder anderen spezialisierten Themen stellen keine individuelle Diagnose, Behandlungsempfehlung oder verbindliche Fachberatung dar.',
                'Pferdehaltung, Reiten, Training und der Umgang mit Pferden sind mit Risiken verbunden.' => 'Praktische Hobbys, Arbeiten mit Werkzeugen, Geräten, Materialien und andere Freizeitaktivitäten können mit Risiken verbunden sein.',
                'Pferdegesundheit, Training und Sicherheit' => 'Gesundheit, Anwendung und Sicherheit',
                'Bei gesundheitlichen Problemen, Lahmheiten, Verletzungen, Verhaltensauffälligkeiten oder Unsicherheiten im Umgang mit Pferden sollte immer eine geeignete Fachperson hinzugezogen werden.' => 'Bei gesundheitlichen Problemen, Verletzungen, Sicherheitsfragen oder fachlichen Unsicherheiten sollte immer eine geeignete Fachperson hinzugezogen werden.',
                'Tierärzte, Hufschmiede, Sattler, Trainer, Rechtsanwälte, Steuerberater oder andere qualifizierte Fachpersonen' => 'qualifizierte Fachpersonen, Trainer, Fachhandwerker, Rechtsanwälte, Steuerberater oder andere geeignete Experten',
            ];
            $text = str_ireplace(array_keys($exact), array_values($exact), $text);

            $generic = [
                'pferdeinteressierte' => 'hobbyinteressierte',
                'pferdebezogene Inhalte' => 'thematisch passende Inhalte',
                'pferdebezogene Angebote' => 'thematisch passende Angebote',
                'nicht pferdebezogenen Angeboten' => 'thematisch unpassenden Angeboten',
                'nicht pferdebezogenen' => 'thematisch unpassenden',
                'Pferdeportal' => 'Portal',
                'Pferdethemen' => 'Hobbythemen',
                'Pferdehaltung' => 'Hobbyausübung',
                'Pferdepflege' => 'Pflege und Wartung',
                'Pferdegesundheit' => 'Gesundheit und Sicherheit',
                'Pferdezubehör' => 'Hobbyzubehör',
                'Pferdefutter' => 'Verbrauchsmaterial',
                'Pferdedecken' => 'Ausrüstung',
                'Reitbekleidung' => 'Schutz- und Freizeitbekleidung',
                'Reitschulen' => 'Kurse und Workshops',
                'Reitschule' => 'Kurs oder Workshop',
                'Reitsport' => 'Freizeitaktivitäten',
                'Stallbetreiber' => 'Anbieter',
                'Stallbedarf' => 'Hobbybedarf',
                'Hufbearbeitung' => 'Fachleistungen',
                'Hufschmiede' => 'Fachhandwerker',
                'Sattler' => 'Fachhandwerker',
                'Sättel' => 'Ausrüstung',
                'Sattel' => 'Ausrüstung',
                'Reiter' => 'Hobbybegeisterte',
                'Reiten' => 'Hobbyausübung',
                'rund ums Pferd' => 'rund um Hobbys und Freizeit',
                'rund um Pferde' => 'rund um Hobbys',
                'Thema Pferd' => 'Thema des Portals',
            ];
            $text = str_ireplace(array_keys($generic), array_values($generic), $text);

            // Last-resort cleanup of standalone horse words only, to avoid residual portal-specific wording.
            $text = preg_replace('/\bPferden\b/ui', 'dem jeweiligen Thema', $text) ?? $text;
            $text = preg_replace('/\bPferde\b/ui', 'Hobbys', $text) ?? $text;
            $text = preg_replace('/\bPferd\b/ui', 'Hobby', $text) ?? $text;
            $text = preg_replace('/\bStall\b/ui', 'Arbeitsbereich', $text) ?? $text;
        }

        return $text;
    }

    private static function transform_url(string $url, array $ctx): string {
        if ($url === '') { return ''; }
        $url = self::transform_text($url, $ctx, 'url');
        $target = rtrim((string)$ctx['target_url'], '/');
        if ($target !== '' && str_starts_with($url, $target . '/')) {
            $path = substr($url, strlen($target));
            return $path !== '' ? $path : '/';
        }
        return $url;
    }

    private static function looks_like_horse_source(array $data): bool {
        $haystack = strtolower((string)($data['source_name'] ?? '') . ' ' . (string)($data['source_url'] ?? ''));
        if (str_contains($haystack, 'pferd')) { return true; }
        $sample = wp_json_encode([$data['menus'] ?? [], $data['pages'] ?? []], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return is_string($sample) && preg_match('/pferde atelier|pferdeatelier|pferde-atelier|pferdeportal|pferd/i', $sample) === 1;
    }

    private static function page_to_array(WP_Post $page): array {
        return [
            'id' => (int)$page->ID,
            'title' => (string)$page->post_title,
            'slug' => (string)$page->post_name,
            'content' => (string)$page->post_content,
            'excerpt' => (string)$page->post_excerpt,
            'parent' => (int)$page->post_parent,
            'status' => (string)$page->post_status,
            'menu_order' => (int)$page->menu_order,
            'permalink' => (string)get_permalink($page),
        ];
    }

    private static function parse_widget_id(string $widget_id): ?array {
        if (!preg_match('/^(.+)-(\d+)$/', $widget_id, $m)) { return null; }
        return [$m[1], (int)$m[2]];
    }

    private static function guard(): void {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer(self::NONCE, '_pafu_nonce');
    }
}

PAFU_Footer_Umzug::init();
