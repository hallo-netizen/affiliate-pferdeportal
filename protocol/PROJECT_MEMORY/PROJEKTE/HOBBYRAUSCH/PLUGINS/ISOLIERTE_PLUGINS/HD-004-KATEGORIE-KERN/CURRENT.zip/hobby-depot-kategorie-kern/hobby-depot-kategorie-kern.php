<?php
/**
 * Plugin Name: Hobby Depot Kategorie-Kern
 * Description: Schlanker read-only Laufzeitkern für das zentrale Hobby-Depot-Kategorieregister. Registriert journal_cat und stellt anderen Plugins die aktive Kategorie-/Taxonomie-/Zuordnungs-Snapshot-API bereit. Keine DataForSEO-, Sync- oder Schreiblogik.
 * Version: 1.0.0
 * Author: Hobby Depot
 * License: GPL-2.0-or-later
 * Requires at least: 6.4
 * Requires PHP: 8.1
 */

if (!defined('ABSPATH')) { exit; }

define('HDKR_VERSION', '1.0.0');
define('HDKR_CONTRACT', 'HOBBY_DEPOT_CATEGORY_REGISTRY_RUNTIME_V1');

final class HD_Category_Registry {
    private const ACTIVE_REV_OPT = 'apkw_target_tree_active_revision_v1';
    private const ACTIVE_SNAPSHOT_OPT = 'apkw_target_tree_active_snapshot_v1';
    public const MAGAZINE_TAXONOMY = 'journal_cat';

    private static ?array $snapshot_cache = null;
    private static ?array $node_index_cache = null;

    public static function init(): void {
        add_action('init', [__CLASS__, 'register_taxonomies'], 5);
        add_action('admin_notices', [__CLASS__, 'admin_health_notice']);
    }

    public static function register_taxonomies(): void {
        if (!function_exists('taxonomy_exists') || !function_exists('register_taxonomy')) { return; }
        if (!taxonomy_exists(self::MAGAZINE_TAXONOMY)) {
            register_taxonomy(self::MAGAZINE_TAXONOMY, ['post'], [
                'labels' => [
                    'name' => 'Magazin',
                    'singular_name' => 'Magazin-Kategorie',
                ],
                'public' => true,
                'show_ui' => true,
                'show_in_rest' => true,
                'hierarchical' => true,
                'rewrite' => ['slug' => 'magazin'],
                'show_admin_column' => true,
            ]);
        }
    }

    public static function contract(): string {
        return HDKR_CONTRACT;
    }

    public static function revision(): string {
        return function_exists('get_option') ? trim((string)get_option(self::ACTIVE_REV_OPT, '')) : '';
    }

    public static function snapshot(bool $fresh = false): array {
        if (!$fresh && self::$snapshot_cache !== null) { return self::$snapshot_cache; }
        $raw = function_exists('get_option') ? get_option(self::ACTIVE_SNAPSHOT_OPT, []) : [];
        self::$snapshot_cache = is_array($raw) ? $raw : [];
        self::$node_index_cache = null;
        return self::$snapshot_cache;
    }

    public static function ready(): bool {
        $revision = self::revision();
        $snapshot = self::snapshot();
        if ($revision === '' || !$snapshot) { return false; }
        if (trim((string)($snapshot['revision'] ?? '')) !== $revision) { return false; }
        return !empty($snapshot['nodes']) && is_array($snapshot['nodes'])
            && !empty($snapshot['mapping']) && is_array($snapshot['mapping']);
    }

    public static function node(string $node_id): ?array {
        $node_id = trim($node_id);
        if ($node_id === '') { return null; }
        $index = self::node_index();
        return isset($index[$node_id]) && is_array($index[$node_id]) ? $index[$node_id] : null;
    }

    public static function children(string $parent_node_id, ?string $pillar = null): array {
        $parent_node_id = trim($parent_node_id);
        $pillar = $pillar !== null ? trim($pillar) : null;
        $out = [];
        foreach ((array)(self::snapshot()['nodes'] ?? []) as $node) {
            if (!is_array($node)) { continue; }
            if ((string)($node['status'] ?? 'active') !== 'active') { continue; }
            if ((string)($node['parent_id'] ?? '') !== $parent_node_id) { continue; }
            if ($pillar !== null && $pillar !== '' && (string)($node['pillar'] ?? '') !== $pillar) { continue; }
            $out[] = $node;
        }
        usort($out, static function(array $a, array $b): int {
            $ao = (int)($a['menu_order'] ?? 0);
            $bo = (int)($b['menu_order'] ?? 0);
            if ($ao !== $bo) { return $ao <=> $bo; }
            return strnatcasecmp((string)($a['display_name'] ?? ''), (string)($b['display_name'] ?? ''));
        });
        return $out;
    }

    public static function mapping(string $node_id): array {
        $node_id = trim($node_id);
        if ($node_id === '') { return []; }
        $mapping = self::snapshot()['mapping'] ?? [];
        return isset($mapping[$node_id]) && is_array($mapping[$node_id]) ? $mapping[$node_id] : [];
    }

    public static function resolve(string $node_id) {
        $map = self::mapping($node_id);
        $object_id = (int)($map['object_id'] ?? 0);
        if ($object_id < 1) { return null; }

        $object_type = (string)($map['object_type'] ?? '');
        if ($object_type === 'page') {
            return function_exists('get_post') ? get_post($object_id) : null;
        }

        $taxonomy = (string)($map['taxonomy'] ?? '');
        if ($taxonomy === '') { $taxonomy = $object_type; }
        return ($taxonomy !== '' && function_exists('get_term')) ? get_term($object_id, $taxonomy) : null;
    }

    public static function find_node_by_object(int $object_id, string $object_type = ''): ?array {
        if ($object_id < 1) { return null; }
        foreach ((array)(self::snapshot()['mapping'] ?? []) as $node_id => $map) {
            if (!is_array($map) || (int)($map['object_id'] ?? 0) !== $object_id) { continue; }
            if ($object_type !== '' && (string)($map['object_type'] ?? '') !== $object_type && (string)($map['taxonomy'] ?? '') !== $object_type) { continue; }
            return self::node((string)$node_id);
        }
        return null;
    }

    public static function taxonomies(): array {
        $names = ['category', self::MAGAZINE_TAXONOMY, 'hp_listing_category'];
        $out = [];
        foreach ($names as $name) {
            $out[$name] = [
                'registered' => function_exists('taxonomy_exists') ? (bool)taxonomy_exists($name) : false,
                'owner' => $name === self::MAGAZINE_TAXONOMY ? 'HD-004-KATEGORIE-KERN' : ($name === 'hp_listing_category' ? 'HivePress' : 'WordPress'),
            ];
        }
        return $out;
    }

    public static function stats(): array {
        $snapshot = self::snapshot();
        $counts = ['nodes' => 0, 'mapped' => 0, 'page' => 0, 'category' => 0, 'journal_cat' => 0, 'hp_listing_category' => 0, 'relation' => 0];
        foreach ((array)($snapshot['nodes'] ?? []) as $node) {
            if (!is_array($node) || (string)($node['status'] ?? 'active') !== 'active') { continue; }
            $counts['nodes']++;
            $type = (string)($node['object_type'] ?? '');
            if (isset($counts[$type])) { $counts[$type]++; }
        }
        $counts['mapped'] = count((array)($snapshot['mapping'] ?? []));
        return $counts;
    }

    public static function admin_health_notice(): void {
        if (!is_admin() || !current_user_can('manage_options') || self::ready()) { return; }
        echo '<div class="notice notice-error"><p><strong>Hobby Depot Kategorie-Kern:</strong> Das aktive Kategorieregister ist nicht vollständig verfügbar. HD-001 nicht löschen, bis ein gültiger aktiver Snapshot vorhanden ist.</p></div>';
    }

    private static function node_index(): array {
        if (self::$node_index_cache !== null) { return self::$node_index_cache; }
        $index = [];
        foreach ((array)(self::snapshot()['nodes'] ?? []) as $node) {
            if (!is_array($node)) { continue; }
            $id = trim((string)($node['node_id'] ?? ''));
            if ($id !== '') { $index[$id] = $node; }
        }
        self::$node_index_cache = $index;
        return $index;
    }
}

// Neutrale API für alle Hobby-Depot-Plugins. Keine direkte APKW-Abhängigkeit nötig.
function hd_category_registry_contract(): string { return HD_Category_Registry::contract(); }
function hd_category_registry_ready(): bool { return HD_Category_Registry::ready(); }
function hd_category_registry_revision(): string { return HD_Category_Registry::revision(); }
function hd_category_registry_snapshot(bool $fresh = false): array { return HD_Category_Registry::snapshot($fresh); }
function hd_category_registry_node(string $node_id): ?array { return HD_Category_Registry::node($node_id); }
function hd_category_registry_children(string $parent_node_id, ?string $pillar = null): array { return HD_Category_Registry::children($parent_node_id, $pillar); }
function hd_category_registry_mapping(string $node_id): array { return HD_Category_Registry::mapping($node_id); }
function hd_category_registry_resolve(string $node_id) { return HD_Category_Registry::resolve($node_id); }
function hd_category_registry_find_node_by_object(int $object_id, string $object_type = ''): ?array { return HD_Category_Registry::find_node_by_object($object_id, $object_type); }
function hd_category_registry_taxonomies(): array { return HD_Category_Registry::taxonomies(); }
function hd_category_registry_stats(): array { return HD_Category_Registry::stats(); }

HD_Category_Registry::init();

register_activation_hook(__FILE__, static function(): void {
    HD_Category_Registry::register_taxonomies();
    if (function_exists('flush_rewrite_rules')) { flush_rewrite_rules(false); }
});

register_deactivation_hook(__FILE__, static function(): void {
    if (function_exists('flush_rewrite_rules')) { flush_rewrite_rules(false); }
});
