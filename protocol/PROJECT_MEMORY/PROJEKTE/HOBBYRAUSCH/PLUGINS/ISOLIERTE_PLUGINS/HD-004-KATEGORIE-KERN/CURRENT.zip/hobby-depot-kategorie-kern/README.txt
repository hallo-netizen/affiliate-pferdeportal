Hobby Depot Kategorie-Kern (HD-004)
====================================

Zweck
-----
Schlanker read-only Laufzeitkern für den bereits produktiv synchronisierten Hobby-Depot-Kategorienbaum.

Der Kern:
- registriert journal_cat;
- liest den aktiven HD-001 Target-Snapshot aus den bestehenden WordPress-Optionen;
- stellt eine neutrale PHP-API für andere Plugins bereit;
- enthält KEINE DataForSEO-Logik;
- enthält KEINE Sync-/Write-/Admin-Workflow-Engine;
- erzeugt, verschiebt oder löscht KEINE Kategorien.

Zentrale API
------------
hd_category_registry_ready()
hd_category_registry_revision()
hd_category_registry_snapshot()
hd_category_registry_node($node_id)
hd_category_registry_children($parent_node_id, $pillar = null)
hd_category_registry_mapping($node_id)
hd_category_registry_resolve($node_id)
hd_category_registry_find_node_by_object($object_id, $object_type = '')
hd_category_registry_taxonomies()
hd_category_registry_stats()

Betrieb
-------
Normalbetrieb: HD-004 aktiv, HD-001 darf nach Live-Smoke-Test deaktiviert werden.
Strukturänderung: HD-001 1.14.8 wieder aktivieren, Delta/Dry-Run/Sync/Readback durchführen, danach wieder deaktivieren. HD-004 liest den neuen aktiven Snapshot automatisch.
