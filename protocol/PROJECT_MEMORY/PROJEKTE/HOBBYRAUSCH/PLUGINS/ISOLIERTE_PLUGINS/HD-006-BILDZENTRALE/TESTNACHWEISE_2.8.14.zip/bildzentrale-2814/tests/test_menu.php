<?php
/* Real class, WordPress API stubs. Tests are synthetic; no live WP changes. */
define('ABSPATH', '/tmp/wordpress/');
$actions=[]; $filters=[]; $menu=[];
function add_action($hook,$cb,$priority=10,$args=1){$GLOBALS['actions'][]=[$hook,$priority,$cb];}
function add_filter($hook,$cb,$priority=10,$args=1){$GLOBALS['filters'][]=[$hook,$priority,$cb];}
function get_option($k,$def=false){if($k==='hdbz_prompt_rules_version')return 'hobby-depot-1.1';if($k==='hdbz_general_schema_version')return '4';return $def;}
function wp_strip_all_tags($s){return strip_tags($s);}
function add_menu_page($title,$label,$cap,$slug,$callback,$icon='',$position=null){
  $GLOBALS['menu'][]=[$label,$cap,$slug,$title,$callback,$position];
  return 'toplevel_page_'.$slug;
}
function check($val,$desc){static $n=0;$n++;echo ($val?'PASS':'FAIL')." [$n] ".$desc."\n";if(!$val)exit(1);}
require dirname(__DIR__).'/src/hobby-depot-bildzentrale/hobby-depot-bildzentrale.php';
check(class_exists('HDBZ_Plugin'),'Real plugin loads successfully');
check(count(array_filter($GLOBALS['actions'], fn($a)=>$a[0]==='admin_menu'))===2,'Creator plus late distinct-name admin_menu hook');
$other=function(){echo 'MAPPING';};
function check_both($menu, $mapping, $test){
  check(count($menu)===2,$test.' both entries remain present');
  $by=[];foreach($menu as $row){$by[$row[2]]=$row;}
  check(count($by)===2,$test.' menu slugs unique');
  check(isset($by['hdbz-bilder-erstellen']),$test.' creator has dedicated URL');
  check(isset($by['hobby-depot-bildzentrale']),$test.' mapping keeps legacy URL');
  check($by['hdbz-bilder-erstellen'][0]==='Bildzentrale',$test.' original creator label');
  check($by['hobby-depot-bildzentrale'][0]==='Bilder zuordnen',$test.' other mapping clearly distinguished');
  check($by['hdbz-bilder-erstellen'][4]===[HDBZ_Plugin::class,'render_page'],$test.' creator callback unchanged');
  check($by['hobby-depot-bildzentrale'][4]===$mapping,$test.' mapping callback untouched');
}
// Both registration orders must work
$menu=[];
add_menu_page('Mapping','Bildzentrale','manage_options','hobby-depot-bildzentrale',$other,'dashicons-images-alt2',57);
HDBZ_Plugin::admin_menu();HDBZ_Plugin::clarify_legacy_assignment_menu();
check_both($menu,$other,'mapping-first');
$menu=[];
HDBZ_Plugin::admin_menu();
add_menu_page('Mapping','Bildzentrale','manage_options','hobby-depot-bildzentrale',$other,'dashicons-images-alt2',57);
HDBZ_Plugin::clarify_legacy_assignment_menu();
check_both($menu,$other,'creator-first');
HDBZ_Plugin::clarify_legacy_assignment_menu();
check($menu[1][0]==='Bilder zuordnen','Late helper is idempotent');
$menu=[];HDBZ_Plugin::admin_menu();HDBZ_Plugin::clarify_legacy_assignment_menu();
check(count($menu)===1 && $menu[0][0]==='Bildzentrale','No mapping plugin: own menu survives and no fake entry');
$menu=[];HDBZ_Plugin::admin_menu();add_menu_page('Other','Bildzentrale','manage_options','unrelated-third-party-menu',$other);
HDBZ_Plugin::clarify_legacy_assignment_menu();
check($menu[1][0]==='Bildzentrale','Unrelated menu completely untouched');
$menu=[];HDBZ_Plugin::admin_menu();add_menu_page('Mapping','Bilder zuordnen','manage_options','hobby-depot-bildzentrale',$other);
HDBZ_Plugin::clarify_legacy_assignment_menu();
check($menu[1][0]==='Bilder zuordnen','Already distinct mapping label is preserved');
$main=file_get_contents(dirname(__DIR__).'/src/hobby-depot-bildzentrale/hobby-depot-bildzentrale.php');
check(!str_contains($main,'page=hobby-depot-bildzentrale'),'No old navigation links left inside creator');
check(str_contains($main,"self::ADMIN_MENU_SLUG, 'hdbz_tab'"),'Tab navigation goes to new creator URL');
check(str_contains($main,"rest_url('hobby-depot-bildzentrale/v1/magnific-webhook')"),'Webhook API intentionally unchanged');
check(str_contains($main,"register_rest_route('hobby-depot-bildzentrale/v1'"),'REST API route intentionally unchanged');
check(substr_count($main,'hobby-depot-bildzentrale/v1')===3,'Existing webhooks unchanged in all 3 uses');
echo "RESULT ALL ASSERTIONS PASSED\n";
