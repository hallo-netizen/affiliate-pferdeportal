from pathlib import Path
import shutil,hashlib,re
base=Path('/mnt/data/hdbz_2813')
root=Path('/mnt/data/hdbz_2814')
if root.exists(): shutil.rmtree(root)
(root/'src').mkdir(parents=True)
shutil.copytree(base/'src'/'hobby-depot-bildzentrale',root/'src'/'hobby-depot-bildzentrale')
shutil.copytree(base/'tests',root/'tests')
for p in (root/'tests'/'uploads').glob('*'):p.unlink()
main=root/'src'/'hobby-depot-bildzentrale'/'hobby-depot-bildzentrale.php'
inc=root/'src'/'hobby-depot-bildzentrale'/'includes'/'class-hdbz-hobbyregister.php'
s=main.read_text();assert s.count('* Version: 2.8.13')==1
main.write_text(s.replace('* Version: 2.8.13','* Version: 2.8.14',1))
s=inc.read_text()
# The global style explicitly calls for natural body crops and close hand shots;
# only the Hobbyregister's shallow-hero mode must not inherit that contradiction.
oldstyle="        $style = trim((string)HDBZ_Plugin::hobby_image_style());"
newstyle="        $style = 'Natural, credible, high-quality editorial realism; accurate materials and safe plausible equipment use, believable activity, good daylight, calm natural colors. Avoid fantasy, advertising glamour and clutter.';"
assert s.count(oldstyle)==1
s=s.replace(oldstyle,newstyle,1)
line=next(l for l in s.splitlines() if 'HERO CROP REQUIREMENT' in l)
assert s.count(line)==1
assert 'medium-wide shot' in line
new="""        $parts[] = 'Natural photorealistic editorial hobby photo, landscape 3:2 at least 1500x1000. HERO CROP REQUIREMENT – OVERRIDING CAMERA RULE: MUCH WIDER LONG SHOT. camera pulled back TWO TO THREE TIMES FARTHER than a typical medium view: show the entire real hobby activity and its surroundings. People (where useful), actual task, tools, device, workpiece and setting together; none dominates the image. The website HERO is a PANORAMIC 4:1 CROP of the CENTER of this 3:2 photo. Place the recognizable hobby action, hands/tools and worked-on object together in the middle 35%-65% of image HEIGHT and right 55%-80% of image WIDTH. Leave the left 35% quiet and low detail for title text. The top and bottom of the original are disposable scenery; keep essentials fully in the safe middle strip. Even the flatter 5:1 hero must show WHAT HOBBY IS HAPPENING clearly. For Arduino and 3D scanning, show person, complete device, workpiece and workspace together rather than face or hands only. HARD NEGATIVES: NO CLOSE-UP, NO HALF-BODY PORTRAIT, NO MACRO, NO TIGHT OR MEDIUM FRAMING, no oversized person, cropped hand/tool, giant foreground device, collage, text, logo or watermark. Not so far away that the actual activity becomes illegibly tiny in the 4:1 hero. This camera rule overrides generic photo styles that recommend close body crops.';"""
assert len(new)<2600
s=s.replace(line,new,1)
inc.write_text(s)
p=root/'tests'/'test_backend.php';t=p.read_text();anchor="eq(strlen($with)<=3000,true,'Explicit hero prompt remains within provider limit');"
assert t.count(anchor)==1
more="""
// VERSION 2.8.14: the earlier 'medium-wide shot' was demonstrably too close.
// Positive AND negative prompt regression: actual generator assembles one authoritative long-shot instruction
// for default and editor-custom inputs, without changing stored images or generating any new paid job.
eq(strpos($arduinoDefault,'MUCH WIDER LONG SHOT')!==false,true,'v2.8.14 requires substantially wider environmental long shot');
eq(strpos($arduinoDefault,'TWO TO THREE TIMES FARTHER')!==false,true,'Default generator requires camera distance multiplier rather than mild zoom-out');
eq(strpos($arduinoDefault,'panoramic 4:1 hero crop')!==false || strpos($arduinoDefault,'PANORAMIC 4:1 CROP')!==false,true,'Default generator explicitly targets the shallow 4-to-1 hero');
eq(strpos($arduinoDefault,'flatter 5:1 hero')!==false,true,'Extra shallow 5-to-1 hero must remain recognizable');
eq(strpos($arduinoDefault,'middle 35%-65% of image HEIGHT')!==false,true,'Decisive hobby action inside middle height-safe slice');
eq(strpos($arduinoDefault,'right 55%-80% of image WIDTH')!==false,true,'Hobby action is in right visual area without title interference');
eq(strpos($arduinoDefault,'left 35% quiet and low detail')!==false,true,'Calm left title overlay area remains available');
eq(strpos($arduinoDefault,'complete device, workpiece and workspace together')!==false,true,'Technical hobbies get person, device, object and workplace in one wide scene');
eq(strpos($arduinoDefault,'NO CLOSE-UP, NO HALF-BODY PORTRAIT, NO MACRO')!==false,true,'NEGATIVE: macro, half-body and tight framing explicitly forbidden');
eq(strpos($arduinoDefault,'Not so far away that the actual activity becomes illegibly tiny')!==false,true,'NEGATIVE: extreme wide invisible hobby is forbidden');
eq(strpos($arduinoDefault,'deliberate environmental medium-wide shot')===false,true,'Old weak medium-wide camera direction is gone');
eq(strpos($with,'MUCH WIDER LONG SHOT')!==false,true,'Custom German scene cannot bypass hero long-shot rule');
eq(strpos($with,'PANORAMIC 4:1 CROP')!==false,true,'Custom scene retains exact crop-safe requirement');
eq(strpos($with,$wish)!==false,true,'Custom scene retained verbatim beside new composition');
eq(strpos($with,'no animal-shaped 3D targets')!==false,true,'Custom exclusion (no animals) remains intact');
eq(strlen($arduinoDefault)<=3000,true,'Full much-wider default prompt not truncated');
eq(strlen($with)<=3000,true,'Full much-wider custom prompt not truncated');
eq(strpos($arduinoDefault,'natural body crops actively using tools')===false,true,'NEGATIVE: conflicting general style encouraging close body crops must not enter Hobbyregister');
eq(strpos($with,'natural body crops actively using tools')===false,true,'NEGATIVE: custom scene cannot inherit generic crop-promoting global style');
"""
t=t.replace(anchor,anchor+'\n'+more,1)
# Update legacy old-camera assertions to reflect stricter rule
assert "'camera pulled back'" in t
t=t.replace("strpos($arduinoDefault,'Camera pulled back')", "strpos($arduinoDefault,'Camera pulled back')")
assert "'No extreme close-up'" in t
t=t.replace("strpos($arduinoDefault,'No extreme close-up')", "strpos($arduinoDefault,'NO CLOSE-UP')")
assert "'illegible tiny distant subject'" in t
t=t.replace("strpos($arduinoDefault,'illegible tiny distant subject')", "strpos($arduinoDefault,'illegibly tiny')")
assert "'CENTER HORIZONTAL BAND (35%-65%'" in t
t=t.replace("strpos($arduinoDefault,'CENTER HORIZONTAL BAND (35%-65%'", "strpos($arduinoDefault,'middle 35%-65%'")
assert "'55%-80% of image width'" in t
t=t.replace("strpos($arduinoDefault,'55%-80% of image width')", "strpos($arduinoDefault,'55%-80% of image WIDTH')")
t=t.replace("strpos($arduinoDefault,'left 35%')", "strpos($arduinoDefault,'left 35%')")
t=t.replace("strpos($with,'55%-80% of image width')", "strpos($with,'55%-80% of image WIDTH')")
# Boundary tests: 400-character editor instructions with animal bans must NOT be clipped
# by provider's 3000-character prompt limit. (Regression caught while constructing 2.8.14.)
anchor="eq(strpos($with,'natural body crops actively using tools')===false,true,'NEGATIVE: custom scene cannot inherit generic crop-promoting global style');"
assert t.count(anchor)==1
boundary="""
$maxLengthWish=mb_substr(str_repeat('No animal, friends with a 3D scanner. ',15),0,400);
$longScene=api('prepare',$arch,['custom'=>$maxLengthWish])['prompt'];
eq(mb_strlen($maxLengthWish),400,'Boundary: editor can provide all 400 characters');
eq(strpos($longScene,$maxLengthWish)!==false,true,'Boundary: full 400-character user wish is included unchanged');
eq(strpos($longScene,'PANORAMIC 4:1 CROP')!==false,true,'Boundary: camera-safe hero crop survives long editor request');
eq(strpos($longScene,'no animal-shaped 3D targets')!==false,true,'Boundary: no-animals exclusion survives long editor request');
eq(strpos($longScene,'FINAL PRIORITY CHECK')!==false,true,'Boundary: final priority check is not cut off by length cap');
eq(strpos($longScene,'must NOT recreate the composition of any previous photo.')!==false,true,'Boundary: prompt ends with mandatory no-reuse restriction');
eq(mb_strlen($longScene)<=3000,true,'Boundary: complete prompt fits within provider 3000-character limit');
"""
t=t.replace(anchor,anchor+'\n'+boundary,1)
p.write_text(t)
print('2.8.14 patched; php bytes',len(inc.read_bytes()),'test bytes',len(t),'new prompt chars',len(new))
