from playwright.sync_api import sync_playwright
from pathlib import Path
import base64,time
html=Path(__file__).with_name('actual_862_hobbies.html').read_text()
photo='data:image/webp;base64,'+base64.b64encode(Path(__file__).with_name('fixture.webp').read_bytes()).decode()
records={
 'hobby:amateurfunk':{'name':'Amateurfunk','status':'pass','has':True,'master':False,'replacement':False,'task':'NO_TASK','images':[]},
 'hobby:airbrush-modellbau':{'name':'Airbrush-Modellbau','status':'pass','has':True,'master':False,'replacement':False,'task':'NO_TASK','images':[]},
 'hobby:airbrush':{'name':'Airbrush','status':'pass','has':True,'master':False,'replacement':False,'task':'NO_TASK','images':[]},
 'hobby:aeroponik':{'name':'Aeroponik','status':'pass','has':True,'master':False,'replacement':False,'task':'NO_TASK','images':[]},
 'hobby:bonsai-landschaften':{'name':'Bonsai-Landschaften','status':'pass','has':True,'master':False,'replacement':False,'task':'NO_TASK','images':[]},
 'hobby:3d-bogenschieen':{'name':'3D-Bogenschießen','status':'pending','has':True,'master':False,'replacement':False,'task':'NO_TASK','images':[]},
 'hobby:batik':{'name':'Batik','status':'pass','has':True,'master':False,'replacement':False,'task':'NO_TASK','images':[]},
 'hobby:keinbild':{'name':'Kein Bild','status':'pending','has':False,'master':False,'replacement':False,'task':'NO_TASK','images':[]},
 'hobby:ameisenfarmen':{'name':'Ameisenfarmen','status':'pending','has':True,'master':False,'replacement':False,'task':'COMPLETED','images':[{'url':photo}]},
}
counts={'generate':0,'apply':0,'replace':0,'check':0};generation_wishes=[]
fail_generate=False

def data(id):
 d=records.setdefault(id,{'name':id,'status':'pending','has':True,'master':False,'replacement':False,'task':'NO_TASK','images':[]})
 return {'id':id,'name':d['name'],'photo_status':d['status'],'has_current_image':d['has'],
         'current_image_url':photo if d['has'] else '', 'master_image_url':photo if d['master'] else '',
         'task_status':d['task'],'images':d['images'],'new_final':d['master'],
         'replacement_allowed':d['replacement'] or not d['has']}

def handler(obj):
 global fail_generate
 op=obj.get('action','').replace('hdbz_hobby_','');id=obj.get('registry_id','')
 d=records.setdefault(id,{'name':id,'status':'pending','has':True,'master':False,'replacement':False,'task':'NO_TASK','images':[]})
 bad=None;out={}
 if op=='prepare':out=data(id)
 elif op=='review':
  decision=obj['decision']
  if decision in ['pending','pass','fail']:
   if decision=='pass' and not d['has']:bad='Kein Foto vorhanden'
   else:d['status']=decision;out={'status':decision}
  elif decision=='replace':
   if obj.get('confirmed')!='yes':bad='Bestätigung fehlt'
   else:d['replacement']=True;counts['replace']+=1;out={'allowed':True}
  elif decision=='cancel':d['replacement']=False;out={'allowed':False}
 elif op=='generate':
  if fail_generate:bad='Magnific nicht erreichbar'
  elif d['has'] and not d['replacement']:bad='Vorhandenes Bild geschützt'
  elif d['task'] not in ['NO_TASK','FAILED','CANCELED','APPLIED','COMPLETED']:bad='Ein Auftrag läuft schon'
  else:counts['generate']+=1;d['task']='CREATED';d['images']=[];generation_wishes.append((id,obj.get('custom','')));out={'status':'CREATED','custom_used':obj.get('custom','')}
 elif op=='check':
  counts['check']+=1
  if d['task']=='CREATED':d['task']='COMPLETED';d['images']=[{'url':photo}]
  out={'status':d['task'],'images':d['images']}
 elif op=='apply':
  if d['task']!='COMPLETED':bad='Entwurf nicht bereit'
  elif d['has'] and obj.get('replace_confirmed')!='yes':bad='Freigabe fehlt'
  elif d['has'] and not d['replacement']:bad='Nicht vorgemerkt'
  else:counts['apply']+=1;d['has']=True;d['master']=True;d['status']='pass';d['task']='APPLIED';d['replacement']=False;d['images']=[];out={'attachment_id':1000+counts['apply'],'url':photo}
 elif op=='discard':d['task']='CANCELED';d['images']=[];out={'message':'Entwurf verworfen'}
 elif op=='undo':d['master']=False;d['status']='pending';d['task']='CANCELED';out={'message':'Wiederhergestellt'}
 else:bad='unbekannter Aufruf '+op
 return {'success':not bool(bad),'data':bad if bad else out}

tests=0
def ok(c,msg):
 global tests
 tests+=1
 if not c:raise AssertionError(f'FAIL [{tests}]: {msg} ({counts})')
 print(f'PASS [{tests}] {msg}',flush=True)

with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':900})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('dialog',lambda d:d.accept())
 page.expose_function('mockApi',handler)
 html=html.replace('<script>', '''<script>window.fetch=async (_url,options)=>{const body=Object.fromEntries(options.body.entries());const data=await window.mockApi(body);return {json:async()=>data};};</script><script>''',1)
 page.set_content(html)
 ok(page.locator('.hb-item').count()==862,'862 hobbies rendered from real PHP')
 ok(page.locator('#hb-generate').count()==0,'No second generation button')
 ok(page.locator('#hb-queue').count()==0,'No staging queue')
 page.locator('#hb-search').fill('Airbrush-Modellbau')
 ok(page.locator('.hb-item:visible').count()==1,'Real HD007 exact master appears once')
 ok(page.locator('.hb-item:visible .hb-state').inner_text()=='Bild passt','Previously verified Airbrush-Modellbau shows image fits')
 page.locator('.hb-item:visible .hb-view').click();page.wait_for_timeout(150)
 ok(page.get_by_label('Bildbewertung Airbrush-Modellbau').input_value()=='pass','Verified original is already selected as fits')
 ok(page.get_by_role('button',name='Bild erstellen',exact=True).is_enabled(),'Verified final remains editable')
 page.locator('#hb-search').fill('Airbrush')
 air=page.locator('.hb-item[data-id="hobby:airbrush"]')
 ok(air.locator('.hb-state').inner_text()=='Bild passt','Airbrush approved category master recognized in 862-record UI')
 air.locator('.hb-view').click();page.wait_for_timeout(150)
 ok(page.get_by_label('Bildbewertung Airbrush').input_value()=='pass','Airbrush approved photo editable and marked fitting')
 page.locator('#hb-search').fill('Aeroponik')
 aero=page.locator('.hb-item[data-id="hobby:aeroponik"]')
 ok(aero.locator('.hb-state').inner_text()=='Bild passt','Aeroponik approved category master recognized in 862-record UI')
 aero.locator('.hb-view').click();page.wait_for_timeout(150)
 ok(page.get_by_label('Bildbewertung Aeroponik').input_value()=='pass','Aeroponik photo editable and marked fitting')
 page.locator('#hb-search').fill('Batik')
 page.locator('#hb-search').fill('Bonsai-Landschaften')
 ok(page.locator('.hb-item:visible').count()==1,'Bonsai-Landschaften located exactly once in real 862-hobby listing')
 ok(page.locator('.hb-item:visible .hb-state').inner_text()=='Bild passt','Bonsai-Landschaften screenshot-reviewed legacy photo is recognized')
 page.locator('.hb-item:visible .hb-view').click();page.wait_for_timeout(120)
 ok(page.get_by_label('Bildbewertung Bonsai-Landschaften').input_value()=='pass','Bonsai-Landschaften accepted in opened editor without photo generation')
 ok(counts['generate']==0,'Legacy photo review does not cause a paid image request')
 page.locator('#hb-search').fill('Batik')
 ok(page.locator('.hb-item:visible .hb-state').inner_text()=='Bild passt','Batik approved original hero recognized')
 page.locator('.hb-item:visible .hb-view').click();page.wait_for_timeout(120)
 ok('Hobbyregister' in page.locator('#hb-workspace .hb-card p').first.inner_text(),'Batik preview source is explicitly the hobbyregister, not category hero')
 page.locator('#hb-search').fill('Amateurfunk')
 ok(page.locator('.hb-item:visible').count()==1,'Search selects exact hobby')
 page.locator('.hb-item:visible .hb-view').click()
 page.locator('#hb-workspace .hb-card h3').wait_for()
 ok(page.locator('#hb-workspace .hb-card h3').inner_text()=='Amateurfunk','Hobby opens with existing photo')
 ok(page.locator('select[aria-label="Bildbewertung Amateurfunk"] option').count()==3,'Three mutually exclusive evaluations')
 page.get_by_label('Bildbewertung Amateurfunk').select_option('fail')
 page.wait_for_timeout(200)
 ok(page.locator('.hb-item:visible .hb-state').inner_text()=='Bild passt nicht','Negative evaluation changes row')
 ok(page.locator('#hb-workspace button:has-text("Bild erstellen")').count()==1,'Only ONE direct create button')
 ok(counts['generate']==0,'Opening/assessment does not produce paid request')
 page.get_by_role('button',name='Bild erstellen',exact=True).click()
 page.wait_for_timeout(550)
 ok(counts['generate']==1,'Create CLICK submits actual paid generation request, not queue')
 ok(counts['replace']==1,'Current image edit explicitly authorized')
 page.locator('.hb-draft-photo').wait_for(timeout=3000)
 ok(page.locator('.hb-draft-photo').count()==1,'Completed generation shows draft image')
 ok(counts['apply']==0,'No automatic image replacement')
 page.get_by_role('button',name='Bild übernehmen').click()
 page.wait_for_timeout(350)
 ok(counts['apply']==1,'Approve explicitly replaces draft only once')
 ok(page.get_by_label('Bildbewertung Amateurfunk').input_value()=='pass','Adopted image becomes "Bild passt"')
 # completed old draft can be replaced by new click
 page.locator('#hb-search').fill('Ameisenfarmen')
 page.locator('.hb-item:visible .hb-view').click();page.wait_for_timeout(350)
 ok(page.locator('.hb-draft-photo').count()==1,'Already completed draft remains reviewable')
 page.get_by_role('button',name='Bild erstellen',exact=True).click();page.wait_for_timeout(550)
 ok(counts['generate']==2,'Completed old draft does not prevent new paid request')
 # The user requirement: editor's German scene must be forwarded by the ONE generation click.
 page.locator('#hb-search').fill('3D-Bogenschießen')
 ok(page.locator('.hb-item:visible').count()==1,'3D archery exists under correct exact id')
 page.locator('.hb-item:visible .hb-view').click();page.wait_for_timeout(250)
 wish='Freunde beim 3D Bogenschiessen. kein tier!'
 page.locator('#hb-workspace textarea').fill(wish)
 page.get_by_role('button',name='Bild erstellen',exact=True).click();page.wait_for_timeout(480)
 ok(( 'hobby:3d-bogenschieen',wish) in generation_wishes,'Editor motif text reaches the actual generation request unchanged')
 ok('mit deinem Motivwunsch' in page.locator('#hb-message').inner_text(),'Browser acknowledges submitted custom scene; not a default prompt')
 ok(counts['generate']==3,'Third separate hobby created paid request exactly once')
 # show actionable error instead of silent failure when provider is down
 fail_generate=True
 page.locator('#hb-search').fill('Kein Bild');page.locator('.hb-item:visible .hb-view').click();page.wait_for_timeout(300)
 ok(page.get_by_label('Bildbewertung Kein Bild').locator('option[value="pass"]').is_disabled(),'Missing photo cannot be approved')
 page.get_by_role('button',name='Bild erstellen',exact=True).click();page.wait_for_timeout(400)
 ok('Magnific nicht erreichbar' in page.locator('#hb-message').inner_text(),'Provider error shown visibly, never silent')
 ok(counts['generate']==3,'Failed request not misreported as started')
 ok(not errors,'No browser JavaScript exceptions: '+repr(errors))
 page.screenshot(path=str(Path(__file__).with_name('browser_final.png')),full_page=True)
 browser.close()
print('ALL',tests,'BROWSER TESTS PASSED')
