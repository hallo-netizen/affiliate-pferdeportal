<?php
/** Hobbyregister workspace inside the existing Hobby Depot Bildzentrale; no changes to HD-007 data. */
if (!defined('ABSPATH')) { exit; }

final class HDBZ_Hobbyregister {
    private const MASTERS = 'hdbz_hobbyregister_masters_v1';
    private const TASKS = 'hdbz_hobbyregister_tasks_v1';
    private const REPLACEMENTS = 'hdbz_hobbyregister_explicit_replacements_v1';
    private const CONFIRMED = 'hdbz_hobbyregister_confirmed_existing_v1';
    private const PHOTO_REVIEW = 'hdbz_hobbyregister_photo_review_v2';
    private static $bridge_ok = null;
    private static $resolving_frontend_photo = false;
    private static $rows_cache = null;
    private static $approved_photo_cache = [];

    public static function init(): void {
        add_filter('hdbz_hobbyregister_image_override', [self::class, 'resolved_image_url'], 10, 2);
        // Existing HD-007 versions resolve their image through plugins_url(). This
        // scoped compatibility adapter avoids editing the separate register plugin.
        add_filter('plugins_url', [self::class, 'register_asset_url'], 20, 3);
        foreach (['prepare','generate','check','apply','undo','discard','review'] as $action) {
            add_action('wp_ajax_hdbz_hobby_'.$action, [self::class, $action]);
        }
    }

    private static function ready(): bool {
        return class_exists('HD_Hobbyregister_Core_Stable127')
            && method_exists('HD_Hobbyregister_Core_Stable127', 'records')
            && method_exists('HD_Hobbyregister_Core_Stable127', 'image_entry')
            && method_exists('HD_Hobbyregister_Core_Stable127', 'article');
    }

    private static function rows(): array {
        if (self::$rows_cache !== null) { return self::$rows_cache; }
        if (!self::ready()) { return []; }
        $rows = HD_Hobbyregister_Core_Stable127::records();
        if (!is_array($rows) || count($rows) !== 862) { return []; }
        $out = [];
        foreach ($rows as $row) {
            $id = (string) ($row['registry_id'] ?? '');
            if ($id === '' || isset($out[$id])) { return []; } // Inconsistent identities: fail closed.
            $out[$id] = $row;
        }
        self::$rows_cache=$out;
        return $out;
    }

    private static function entry(string $id): array {
        $entry = HD_Hobbyregister_Core_Stable127::image_entry($id);
        return is_array($entry) ? $entry : [];
    }

    private static function existing_final(array $entry): bool {
        return ($entry['status'] ?? '') === 'FINAL_MASTER_VERIFIED'
            || ($entry['production_status'] ?? '') === 'DONE';
    }

    private static function masters(): array {
        $stored = get_option(self::MASTERS, []);
        return is_array($stored) ? $stored : [];
    }

    private static function tasks(): array {
        $stored = get_option(self::TASKS, []);
        return is_array($stored) ? $stored : [];
    }

    // Existing assigned pictures are real visible frontend assets, regardless of whether
    // the legacy production metadata calls them final. NEVER auto-queue replacements.
    private static function has_assigned_image(array $entry): bool {
        return trim((string) ($entry['path'] ?? '')) !== '';
    }

    private static function replacements(): array {
        $stored = get_option(self::REPLACEMENTS, []);
        return is_array($stored) ? $stored : [];
    }

    // A real but unverified old asset must not silently count as a completed master.
    // Explicit editorial confirmation is saved separately and tied to that exact asset.
    private static function confirmed(): array {
        $stored = get_option(self::CONFIRMED, []);
        return is_array($stored) ? $stored : [];
    }

    /** Verified screenshot-based editorial evidence is linked to the EXACT old
     * asset. This is NOT a general auto-approval of shared/legacy photographs.
     * Older photos are always retained even if their review is still pending.
     * A user's explicit assessment (including rejection) takes precedence. */
    private static function photographed_editorial_evidence(string $id, array $entry): bool {
        $verified = [
            // 08.11.2026: operator showed Bonsai-Landschaften's existing scene
            // as the fitting bonsai miniature landscape; asset source verified
            // against the complete HD007 1.2.21 map (not merely hobby name).
            'hobby:bonsai-landschaften' => [
                'source' => 'hd003',
                'path' => 'hobby-depot-v150617/hero-masters-v150684/bonsai-miniatur.webp',
            ],
        ];
        $proof = $verified[$id] ?? null;
        return is_array($proof)
            && (string)($entry['source'] ?? '') === $proof['source']
            && (string)($entry['path'] ?? '') === $proof['path'];
    }

    private static function confirmed_existing(string $id, array $entry): bool {
        if (!self::has_assigned_image($entry)) { return false; }
        $decision = self::confirmed()[$id] ?? null;
        return is_array($decision)
            && ($decision['source'] ?? '') === (string) ($entry['source'] ?? '')
            && ($decision['path'] ?? '') === (string) ($entry['path'] ?? '');
    }

    /** Reuse the existing HD003 category photo selection READ-ONLY. This is the
     * same master/WordPress assignment already serving the category frontend;
     * never infer an image merely from a matching filename or parent category.
     * Only an explicit approved source can replace an unapproved HD007 placeholder. */
    private static function approved_category_photo(string $id, array $entry): string {
        if (self::existing_final($entry) && self::has_assigned_image($entry)) { return ''; }
        if (array_key_exists($id,self::$approved_photo_cache)) { return self::$approved_photo_cache[$id]; }
        if (!class_exists('Hobby_Depot_Profile_V150709')
            || !method_exists('Hobby_Depot_Profile_V150709','hobby_image_center_v150769')) { return ''; }
        $slug = strpos($id,'hobby:')===0 ? substr($id,6) : '';
        if ($slug==='' || sanitize_title($slug)!==$slug) { return ''; }
        try {
            $method=new ReflectionMethod('Hobby_Depot_Profile_V150709','hobby_image_center_v150769');
            $photo=$method->invoke(null,$slug,null);
            if (!is_array($photo)) { return ''; }
            if (!in_array(($photo['source']??''),['bildzentrale','hobby-master','hd007-master','batik-master'],true)) { return ''; }
            $url=(string)($photo['url']??'');
            $resolved=preg_match('#^https?://#i',$url) ? esc_url_raw($url) : '';
            self::$approved_photo_cache[$id]=$resolved;
            return $resolved;
        } catch (Throwable $e) { return ''; }
    }

    private static function current_key(string $id, array $entry): string {
        $m = self::masters()[$id] ?? null;
        if (is_array($m) && !empty($m['attachment_id']) && wp_attachment_is_image((int)$m['attachment_id'])) {
            return 'master:'.(int)$m['attachment_id'];
        }
        $approved=self::approved_category_photo($id,$entry);
        if ($approved!=='') { return 'approved-frontend:'.hash('sha256',$approved); }
        if (self::has_assigned_image($entry)) {
            return 'original:'.hash('sha256',(string)($entry['source']??'').'|'.(string)($entry['path']??''));
        }
        return 'missing';
    }

    private static function has_current_image(string $id, array $entry): bool {
        return self::current_key($id,$entry) !== 'missing';
    }

    private static function photo_reviews(): array {
        $v=get_option(self::PHOTO_REVIEW, []);
        return is_array($v) ? $v : [];
    }

    private static function photo_status(string $id, array $entry): string {
        $key=self::current_key($id,$entry);
        $v=self::photo_reviews()[$id] ?? [];
        if (is_array($v) && ($v['image_key']??'') === $key
            && in_array(($v['status']??''),['pass','fail','pending'],true)) { return (string)$v['status']; }
        if (strpos($key,'approved-frontend:')===0) { return 'pass'; }
        if ($key !== 'missing' && strpos($key,'original:')===0) {
            if (self::confirmed_existing($id,$entry)) { return 'pass'; }
            if (self::photographed_editorial_evidence($id,$entry)) { return 'pass'; }
            // HD-007's ORIGINAL current image map is an existing verified editorial
            // decision for the precise asset. Do not discard it on load.
            if (self::existing_final($entry) && self::has_assigned_image($entry)) { return 'pass'; }
        }
        return 'pending';
    }

    private static function replacement_allowed(string $id, array $entry): bool {
        if (!self::has_current_image($id,$entry)) { return true; }
        $decision=self::replacements()[$id]??null;
        if (!is_array($decision)) { return false; }
        if (($decision['image_key']??'')===self::current_key($id,$entry)) { return true; }
        // Existing v1 approvals remain valid only for the same exact old source/path,
        // and only if no newer master has replaced that picture.
        return !isset(self::masters()[$id])
            && ($decision['source']??'')===(string)($entry['source']??'')
            && ($decision['path']??'')===(string)($entry['path']??'');
    }

    private static function is_protected(string $id, array $entry): bool {
        return self::has_current_image($id,$entry) && !self::replacement_allowed($id,$entry);
    }

    /** A review is human judgement, not the internal master/production state. */
    public static function review(): void {
        [$id,$row,$entry]=self::requested();
        $decision=sanitize_key((string)wp_unslash($_POST['decision']??''));
        if (!in_array($decision,['pass','fail','pending','replace','cancel','keep','confirm'],true)) {
            wp_send_json_error('Ungültige Bildbewertung.',400);
        }
        $has=self::has_current_image($id,$entry);
        if ($decision==='replace' && (string)($_POST['confirmed']??'')!=='yes') {
            wp_send_json_error('Bildbearbeitung muss ausdrücklich bestätigt werden.',409);
        }
        if (in_array($decision,['pass','keep','confirm'],true) && !$has) {
            wp_send_json_error('Ohne Bild kann nicht „Bild passt“ ausgewählt werden.',409);
        }
        $repl=self::replacements();$reviews=self::photo_reviews();
        if ($decision==='replace') {
            $repl[$id]=['image_key'=>self::current_key($id,$entry),'approved_at'=>gmdate('c')];
        } elseif ($decision==='cancel') {
            unset($repl[$id]);
        } else {
            $status=in_array($decision,['keep','confirm'],true)?'pass':$decision;
            $reviews[$id]=['image_key'=>self::current_key($id,$entry),'status'=>$status,'reviewed_at'=>gmdate('c')];
            // Rating the picture doesn't change or erase any ongoing draft.
        }
        if ($decision==='cancel') { unset($repl[$id]); }
        update_option(self::REPLACEMENTS,$repl,false);
        update_option(self::PHOTO_REVIEW,$reviews,false);
        if ($decision==='replace' && !self::replacement_allowed($id,$entry)) {
            wp_send_json_error('Bildbearbeitung konnte nicht freigegeben werden.',500);
        }
        if (in_array($decision,['pass','fail','pending','keep','confirm'],true)
            && self::photo_status($id,$entry)!==(in_array($decision,['keep','confirm'],true)?'pass':$decision)) {
            wp_send_json_error('Bildbewertung konnte nicht gespeichert werden.',500);
        }
        wp_send_json_success(['status'=>self::photo_status($id,$entry),
            'allowed'=>self::replacement_allowed($id,$entry),
            'message'=>$decision==='replace'?'Bildbearbeitung vorgemerkt. Bisheriges Bild bleibt erhalten.':'Bewertung gespeichert.']);
    }

    // Called by the TWO-LINE hook in the unchanged remainder of HD-007's record_image().
    // Never override a final original master; never override with a missing/invalid attachment.
    public static function resolved_image_url($url, $registry_id): string {
        $id = (string) $registry_id;
        if ($id === '' || !isset(self::rows()[$id])) { return (string) $url; }
        // Explicit newly approved image takes precedence over all original assets.
        $masters = self::masters();
        $attachment_id = (int) ($masters[$id]['attachment_id'] ?? 0);
        if ($attachment_id && wp_attachment_is_image($attachment_id)) {
            $local = get_attached_file($attachment_id);
            $resolved = $local && is_file($local) ? wp_get_attachment_url($attachment_id) : false;
            if ($resolved) { return esc_url_raw($resolved); }
        }
        // Same approved master as the already-correct category frontend; only
        // for unverified placeholder photos, with no data writes to HD003/HD007.
        $entry=self::entry($id);
        $category=self::approved_category_photo($id,$entry);
        return $category!=='' ? $category : (string)$url;
    }

    public static function register_asset_url($url, $path = '', $plugin = ''): string {
        $url = (string) $url;
        if (self::$resolving_frontend_photo || !self::ready()) { return $url; }
        // Only HD-007's exact image resolver may be changed. No global URL rewrite.
        foreach (debug_backtrace(DEBUG_BACKTRACE_PROVIDE_OBJECT, 12) as $call) {
            if (($call['class'] ?? '') !== 'HD_Hobbyregister_Frontend_Stable127'
                || ($call['function'] ?? '') !== 'record_image') { continue; }
            $row = $call['args'][0] ?? [];
            if (!is_array($row) || empty($row['registry_id'])) { return $url; }
            self::$resolving_frontend_photo=true;
            try { return self::resolved_image_url($url, (string)$row['registry_id']); }
            finally { self::$resolving_frontend_photo=false; }
        }
        return $url;
    }

    private static function access(): void {
        if (!current_user_can('manage_options')) { wp_send_json_error('Nicht erlaubt.', 403); }
        check_ajax_referer('hdbz_ajax', 'nonce');
    }

    private static function requested(): array {
        self::access();
        $id = sanitize_text_field(wp_unslash((string) ($_POST['registry_id'] ?? '')));
        $rows = self::rows();
        if ($id === '' || !isset($rows[$id])) { wp_send_json_error('Hobbyregister-Zuordnung nicht eindeutig.', 400); }
        return [$id, $rows[$id], self::entry($id)];
    }

    private static function bridge_operational(): bool {
        if (self::$bridge_ok !== null) { return self::$bridge_ok; }
        self::$bridge_ok = false;
        if (!self::ready() || !class_exists('HD_Hobbyregister_Frontend_Stable127')
            || !method_exists('HD_Hobbyregister_Frontend_Stable127', 'record_image')) { return false; }
        $candidate = null;
        foreach (self::rows() as $id=>$row) {
            if (!self::existing_final(self::entry($id))) { $candidate = $row; break; }
        }
        if (!$candidate) { return true; } // All 862 are already finalized.
        $found = false;
        $probe = static function($url, $path, $plugin) use (&$found) {
            foreach (debug_backtrace(DEBUG_BACKTRACE_PROVIDE_OBJECT, 12) as $call) {
                if (($call['class'] ?? '') === 'HD_Hobbyregister_Frontend_Stable127'
                    && ($call['function'] ?? '') === 'record_image') { $found = true; break; }
            }
            return $url;
        };
        add_filter('plugins_url', $probe, 1000, 3);
        try {
            $method = new ReflectionMethod('HD_Hobbyregister_Frontend_Stable127', 'record_image');
            $method->invoke(null, $candidate);
            self::$bridge_ok = $found;
        } catch (Throwable $e) {
            self::$bridge_ok = false;
        } finally {
            remove_filter('plugins_url', $probe, 1000);
        }
        return self::$bridge_ok;
    }

    private static function safe_to_produce(string $id, array $entry): void {
        if (!self::bridge_operational()) { wp_send_json_error('Die Bildanzeige des aktiven Hobbyregisters ist nicht bestätigt. Keine Änderung.',409); }
        if (self::has_current_image($id,$entry) && !self::replacement_allowed($id,$entry)) {
            wp_send_json_error('Vorhandenes Bild: „Neues Bild erstellen“ zuerst ausdrücklich wählen.',409);
        }
    }

    // The general Hobby Depot photo policy remains untouched. This composition rule
    // applies exclusively to the Hobbyregister and is shared by single/batch jobs.
    /** Only the current hobby name and the user's own scene instruction define the
     *  subject. Legacy stock-photo metadata must NEVER overrule editorial intent. */
    private static function prompt(string $id, array $row, array $entry, string $custom = ''): string {
        $name = trim(wp_strip_all_tags((string) ($row['canonical_name'] ?? '')));
        $custom = trim(mb_substr(wp_strip_all_tags($custom), 0, 400));
        $style = 'Natural, credible, high-quality editorial realism; accurate materials and safe plausible equipment use, believable activity, good daylight, calm natural colors. Avoid fantasy, advertising glamour and clutter.';
        $parts = [];
        if ($custom !== '') {
            // Priority first: not an addendum after a misleading legacy motif.
            $parts[] = 'MANDATORY SCENE GIVEN BY THE EDITOR, highest priority: "'.$custom.'".';
            $parts[] = 'Make exactly that scene as a fresh realistic photo for the hobby "'.$name.'". Treat all German instructions including negations as binding. If this conflicts with the default expectations associated with the name of the hobby, the EDITOR instruction wins. Do not derive subject matter from a previous photo, old photo brief, category placeholder or stock image.';
            // The model's learned stereotype for 3D archery is animal hunting.
            // Only when the editor explicitly forbids animals should it be banned.
            if (preg_match('/(?:\bkein(?:e[snmr]?)?\s+(?:echte\s+)?tier(?:e|en)?\b|\bohne\s+tiere?\b|\bno\s+animals?\b)/iu', $custom)) {
                $parts[] = 'HARD EXCLUSION: absolutely no living animals, no wild boar, no wildlife, no animal-shaped 3D targets, no hunting, no hunter, no animal figures, no animal silhouettes. Do not use a hunting scenario as a substitute for a sports scene.';
            }
            if (preg_match('/(?:freund(?:e|innen)?|gruppe|gemeinsam|zusammen)/iu', $custom)) {
                $parts[] = 'Show several friends visibly participating together; not a single solitary hunter or isolated person.';
            }
        } else {
            $brief = trim(wp_strip_all_tags((string) ($entry['photo_brief'] ?? '')));
            $article = HD_Hobbyregister_Core_Stable127::article($id);
            $intro = is_array($article) ? (string)($article['sections'][0][1] ?? '') : '';
            $intro = trim(wp_strip_all_tags($intro));
            $context = $brief !== '' ? $brief : $intro;
            $parts[] = 'One new realistic editorial photo for the Hobby Depot hobby "'.$name.'".';
            if ($context !== '') { $parts[] = 'Visual topic: '.mb_substr($context,0,480).'.'; }
        }
        $parts[] = $style;
        $parts[] = 'Natural photorealistic editorial hobby photo, landscape 3:2 at least 1500x1000. HERO CROP REQUIREMENT – OVERRIDING CAMERA RULE: MUCH WIDER LONG SHOT. camera pulled back TWO TO THREE TIMES FARTHER than a typical medium view: show the entire real hobby activity and its surroundings. People (where useful), actual task, tools, device, workpiece and setting together; none dominates the image. The website HERO is a PANORAMIC 4:1 CROP of the CENTER of this 3:2 photo. Place the recognizable hobby action, hands/tools and worked-on object together in the middle 35%-65% of image HEIGHT and right 55%-80% of image WIDTH. Leave the left 35% quiet and low detail for title text. The top and bottom of the original are disposable scenery; keep essentials fully in the safe middle strip. Even the flatter 5:1 hero must show WHAT HOBBY IS HAPPENING clearly. For Arduino and 3D scanning, show person, complete device, workpiece and workspace together rather than face or hands only. HARD NEGATIVES: NO CLOSE-UP, NO HALF-BODY PORTRAIT, NO MACRO, NO TIGHT OR MEDIUM FRAMING, no oversized person, cropped hand/tool, giant foreground device, collage, text, logo or watermark. Not so far away that the actual activity becomes illegibly tiny in the 4:1 hero. This camera rule overrides generic photo styles that recommend close body crops.';
        if ($custom !== '') {
            $parts[] = 'FINAL PRIORITY CHECK: The final image MUST depict the editor scene above, obey every explicitly excluded object, and must NOT recreate the composition of any previous photo.';
        }
        // The artistic style may be long. Never truncate the editor's request or
        // the final hard exclusions, even when the shared global style changes.
        $prompt = trim((string)preg_replace('/\s+/u',' ',implode(' ', $parts)));
        if (mb_strlen($prompt)>3000) {
            $styleIndex=$custom!=='' ? (count($parts)-3) : (count($parts)-2);
            if ($styleIndex>=0) { $parts[$styleIndex]=mb_substr((string)$parts[$styleIndex],0,600); }
            $prompt=trim((string)preg_replace('/\s+/u',' ',implode(' ', $parts)));
        }
        return mb_substr($prompt,0,3000);
    }

    private static function custom_input(): string {
        $custom = sanitize_textarea_field(wp_unslash((string) ($_POST['custom'] ?? '')));
        if (mb_strlen($custom) > 400) {
            wp_send_json_error('Zusatzvorgabe: höchstens 400 Zeichen.', 400);
        }
        return trim($custom);
    }

    private static function current_display_url(array $row): string {
        // Read the very image URL used by the installed register. No stored field is modified.
        if (!class_exists('HD_Hobbyregister_Frontend_Stable127')) { return ''; }
        try {
            $method = new ReflectionMethod('HD_Hobbyregister_Frontend_Stable127', 'record_image');
            return esc_url_raw((string) $method->invoke(null, $row));
        } catch (Throwable $e) {
            return '';
        }
    }

    public static function prepare(): void {
        [$id, $row, $entry] = self::requested();
        $tasks = self::tasks();
        $task = is_array($tasks[$id] ?? null) ? $tasks[$id] : [];
        $custom = self::custom_input();
        $master_id = (int) (self::masters()[$id]['attachment_id'] ?? 0);
        wp_send_json_success([
            'id' => $id,
            'name' => (string) ($row['canonical_name'] ?? ''),
            'source' => (string) ($entry['source'] ?? 'kein Bild'),
            'path' => (string) ($entry['path'] ?? ''),
            'current_image_url' => self::current_display_url($row),
            'original_status' => (string) ($entry['status'] ?? ''),
            'protected' => self::is_protected($id, $entry),
            'original_final' => self::existing_final($entry),
            'existing_assigned' => self::has_assigned_image($entry),
            'existing_confirmed' => self::confirmed_existing($id, $entry),
            'replacement_allowed' => self::replacement_allowed($id, $entry),
            'new_final' => isset(self::masters()[$id]),
            'photo_status' => self::photo_status($id,$entry),
            'has_current_image' => self::has_current_image($id,$entry),
            'prompt' => self::prompt($id, $row, $entry, $custom),
            'master_image_url' => $master_id && wp_attachment_is_image($master_id) ? wp_get_attachment_url($master_id) : '',
            'task_status' => (string) ($task['status'] ?? 'NO_TASK'),
            'images' => array_values((array) ($task['images'] ?? [])),
            'preview_error' => (string)($task['preview_error']??''),
        ]);
    }

    public static function generate(): void {
        [$id, $row, $entry] = self::requested();
        self::safe_to_produce($id, $entry);
        $tasks = self::tasks();
        $old = $tasks[$id] ?? [];
        if (!empty($old['task_id']) && !in_array(($old['status'] ?? ''), ['FAILED','CANCELED','APPLIED','COMPLETED'], true)) {
            wp_send_json_error('Es existiert bereits ein Auftrag für dieses Hobby. Erst Status prüfen.', 409);
        }
        $custom = self::custom_input();
        // Always rebuild from the original hobby record, style and editorial supplement.
        // This prevents the shared rules being omitted in a batch or stale preview.
        $prompt = self::prompt($id, $row, $entry, $custom);
        if (mb_strlen($prompt) < 30 || mb_strlen($prompt) > 3000) {
            wp_send_json_error('Ungültige Bildbeschreibung (30–3000 Zeichen).', 400);
        }
        $response = HDBZ_Plugin::hobby_magnific_request('POST', '/v1/ai/text-to-image/nano-banana-pro-flash', [
            'prompt'=>$prompt, 'aspect_ratio'=>'3:2', 'resolution'=>'2K', 'use_google_search_tool'=>false,
        ]);
        if (is_wp_error($response)) { wp_send_json_error($response->get_error_message(), 502); }
        $data = is_array($response['data'] ?? null) ? $response['data'] : $response;
        $task_id = (string) ($data['task_id'] ?? '');
        if ($task_id === '') { wp_send_json_error('Bildauftrag ohne Kennung – keine Zuordnung möglich.', 502); }
        // The old draft remains untouched until the new job is durably saved.
        $tasks[$id] = ['task_id'=>$task_id,'status'=>strtoupper((string)($data['status'] ?? 'CREATED')),
            'prompt'=>$prompt,'custom'=>$custom,'created_at'=>gmdate('c'),'images'=>[]];
        update_option(self::TASKS, $tasks, false);
        if ((self::tasks()[$id]['task_id'] ?? '') !== $task_id) {
            wp_send_json_error('Bildauftrag gestartet, aber Speicherung der Zuordnung fehlgeschlagen. Nicht erneut erzeugen.', 500);
        }
        // Clean only the old unassigned preview AFTER new job persistence is confirmed.
        self::cleanup_pending_draft($id, is_array($old) ? $old : []);
        wp_send_json_success(['status'=>$tasks[$id]['status'],
            'custom_used'=>$custom, 'message'=>'Auftrag gespeichert.']);
    }


    /** Local pending preview: generated image is stored in WP media but not made visible
     * in the Hobbyregister until the separate explicit "Bild übernehmen" action. */
    private static function localize_pending_draft(string $id, string $name, array $task): array {
        $images=(array)($task['images']??[]);
        if (!$images) { return $task; }
        $image=$images[0];
        if (!is_array($image) || empty($image['url'])) { return $task; }
        $attachment=absint($image['attachment_id']??0);
        if ($attachment>0 && wp_attachment_is_image($attachment)
            && (string)get_post_meta($attachment,'_hdbz_hobbyregister_id',true)===$id) { return $task; }
        $remote=(string)($image['remote_url']??$image['url']);
        $stored=self::import_final($id,$name,$remote);
        if (is_wp_error($stored)) {
            // Never present a broken provider URL as an approved/previewable master.
            $task['preview_error']='Entwurf konnte nicht geladen werden: '.$stored->get_error_message();
            $task['images']=[];
            $task['remote_images']=[$remote];
            return $task;
        }
        $url=(string)wp_get_attachment_url((int)$stored);
        if ($url==='') {
            wp_delete_attachment((int)$stored,true);
            $task['preview_error']='Temporäres Bild hat keine erreichbare Mediathek-Adresse.';
            $task['images']=[];
            $task['remote_images']=[$remote];
            return $task;
        }
        $task['images']=[['url'=>$url,'attachment_id'=>(int)$stored,'remote_url'=>$remote]];
        unset($task['preview_error'],$task['remote_images']);
        return $task;
    }

    private static function cleanup_pending_draft(string $id, array $task): void {
        foreach ((array)($task['images']??[]) as $img) {
            $aid=is_array($img)?absint($img['attachment_id']??0):0;
            if ($aid>0 && wp_attachment_is_image($aid)
                && (string)get_post_meta($aid,'_hdbz_hobbyregister_id',true)===$id
                && (int)(self::masters()[$id]['attachment_id']??0)!==$aid) {
                wp_delete_attachment($aid,true);
            }
        }
    }

    public static function check(): void {
        [$id, $row, $entry] = self::requested();
        $tasks = self::tasks();
        $task = is_array($tasks[$id] ?? null) ? $tasks[$id] : [];
        if (empty($task['task_id'])) { wp_send_json_success(['status'=>'NO_TASK','images'=>[]]); }
        if (($task['status'] ?? '') === 'CANCELED') {
            wp_send_json_success(['status'=>'CANCELED', 'images'=>[]]);
        }
        if (($task['status'] ?? '') === 'COMPLETED' && !empty($task['images'])) {
            // Migrate a completed remote-only draft from an older plugin version.
            $task=self::localize_pending_draft($id,(string)$row['canonical_name'],$task);
            $tasks[$id]=$task;update_option(self::TASKS,$tasks,false);
            wp_send_json_success(['status'=>'COMPLETED','images'=>$task['images'],
                'preview_error'=>(string)($task['preview_error']??'')]);
        }
        $r = HDBZ_Plugin::hobby_magnific_request('GET', '/v1/ai/text-to-image/nano-banana-pro-flash/'.rawurlencode($task['task_id']));
        if (is_wp_error($r)) { wp_send_json_error($r->get_error_message(), 502); }
        $d = is_array($r['data'] ?? null) ? $r['data'] : $r;
        $task['status'] = strtoupper((string) ($d['status'] ?? 'UNKNOWN'));
        if ($task['status'] === 'COMPLETED') {
            $urls = array_values(array_filter((array)($d['generated'] ?? []),
                static fn($u): bool => is_string($u) && (bool)preg_match('#^https://#i', $u)));
            $task['images'] = array_map(static fn($u): array => ['url'=>esc_url_raw($u)], array_slice($urls,0,1));
            if (!empty($task['images'])) {
                $task=self::localize_pending_draft($id,(string)$row['canonical_name'],$task);
            } elseif (!empty($task['remote_images'][0])) {
                // A previously downloaded provider result can be retried without paying again.
                $task['images']=[['url'=>(string)$task['remote_images'][0]]];
                $task=self::localize_pending_draft($id,(string)$row['canonical_name'],$task);
            }
        }
        $tasks[$id] = $task;
        update_option(self::TASKS, $tasks, false);
        wp_send_json_success(['status'=>$task['status'],'images'=>$task['images'] ?? [],
            'preview_error'=>(string)($task['preview_error']??'')]);
    }

    public static function apply(): void {
        [$id, $row, $entry] = self::requested();
        self::safe_to_produce($id, $entry);
        // Explicit approval of a single image; the older file and map stay untouched.
        if (empty($_POST['approved']) || (string) $_POST['approved'] !== 'yes') {
            wp_send_json_error('Ausdrückliche Bildfreigabe erforderlich.', 400);
        }
        // A generated draft must never silently overwrite an existing hero.
        if (self::has_current_image($id,$entry) && (string) ($_POST['replace_confirmed'] ?? '') !== 'yes') {
            wp_send_json_error('Vorhandenes Bild: Ersetzen muss ausdrücklich bestätigt werden.', 409);
        }
        $tasks = self::tasks();
        $task = is_array($tasks[$id] ?? null) ? $tasks[$id] : [];
        $index = absint($_POST['index'] ?? 0);
        $image = $task['images'][$index] ?? null;
        if (($task['status'] ?? '') !== 'COMPLETED' || !is_array($image) || empty($image['url'])) {
            wp_send_json_error('Kein abgeschlossenes, eindeutig zugeordnetes Bild vorhanden.', 409);
        }
        $lock = 'hdbz_hobby_lock_'.md5($id);
        $last_lock = (string) get_option($lock, '');
        if ($last_lock !== '' && strtotime($last_lock) < time()-600) { delete_option($lock); }
        if (!add_option($lock, gmdate('c'), '', false)) {
            wp_send_json_error('Dieses Hobby wird gerade bearbeitet.', 409);
        }
        // wp_send_json_* terminates the PHP request, so unlock BEFORE every response.
        $frontend_issue='';
        $frontend_issue_status=409;
        try {
            if (self::is_protected($id,self::entry($id))) {
                delete_option($lock);
                wp_send_json_error('Bildberechtigung ist nicht mehr aktuell. Keine Änderung.',409);
            }
            $attachment = absint($image['attachment_id']??0);
            if ($attachment>0) {
                if (!wp_attachment_is_image($attachment)
                    || (string)get_post_meta($attachment,'_hdbz_hobbyregister_id',true)!==$id) {
                    delete_option($lock);
                    wp_send_json_error('Entwurf gehört nicht zu diesem Hobby. Keine Übernahme.',409);
                }
            } else {
                // Backward compatible for results from older versions.
                $attachment = self::import_final($id, (string)$row['canonical_name'], (string)$image['url']);
            }
            if (is_wp_error($attachment)) {
                delete_option($lock);
                wp_send_json_error($attachment->get_error_message(), 400);
            }
            $masters = self::masters();
            $previous = is_array($masters[$id] ?? null) ? $masters[$id] : null;
            $oldmasters=$masters;
            $masters[$id] = [
                'attachment_id'=>(int)$attachment,
                'original_source'=>(string)($entry['source'] ?? ''),
                'original_path'=>(string)($entry['path'] ?? ''),
                'previous_master'=>$previous,
                'approved_at'=>gmdate('c'),'task_id'=>(string)$task['task_id'],
            ];
            update_option(self::MASTERS,$masters,false);
            if ((int)(self::masters()[$id]['attachment_id']??0)!==(int)$attachment) {
                update_option(self::MASTERS,$oldmasters,false);
                wp_delete_attachment($attachment,true);
                delete_option($lock);
                wp_send_json_error('Übernahme fehlgeschlagen; altes Bild bleibt erhalten.',500);
            }
            $url = (string)wp_get_attachment_url($attachment);
            // Do not claim success just because a WordPress option was written.
            // Ask the INSTALLED HD-007 frontend's own image resolver whether this
            // exact approved image is actually returned for this registry record.
            // A mismatch means the bridge is broken: undo only our draft master
            // pointer; leave the previously visible picture and draft untouched.
            $frontend_url = self::current_display_url($row);
            if (!$url || !$frontend_url || rawurldecode($frontend_url) !== rawurldecode(esc_url_raw($url))) {
                update_option(self::MASTERS,$oldmasters,false);
                if (self::masters() !== $oldmasters) {
                    $frontend_issue='Frontend-Abgleich fehlgeschlagen. Die alte Bildzuordnung konnte nicht sicher wiederhergestellt werden. Keine weitere Übernahme starten.';
                    $frontend_issue_status=500;
                } else {
                    $frontend_issue='Bild nicht übernommen: Das aktive Hobbyregister zeigt den neuen Entwurf nicht an. Das alte Foto und der fertige Entwurf bleiben erhalten.';
                }
                delete_option($lock);
            } else {
                $reviews=self::photo_reviews();
                $reviews[$id]=['image_key'=>'master:'.(int)$attachment,'status'=>'pass','reviewed_at'=>gmdate('c')];
                update_option(self::PHOTO_REVIEW,$reviews,false);
                $repl=self::replacements();unset($repl[$id]);update_option(self::REPLACEMENTS,$repl,false);
                $tasks=self::tasks();
                $tasks[$id]['status']='APPLIED';$tasks[$id]['images']=[];
                update_option(self::TASKS,$tasks,false);
                delete_option($lock);
                $success=['attachment_id'=>$attachment,'url'=>$url,
                    'message'=>'Übernommen und gegen die tatsächliche Hobbyregister-Bildausgabe geprüft.'];
            }
        } catch (Throwable $e) {
            delete_option($lock);
            wp_send_json_error('Bild konnte nicht übernommen werden. Die alte Zuordnung bleibt erhalten.', 500);
        }
        // Both JSON exits belong outside try/catch: real WP terminates here,
        // and the local mock must observe the same public result.
        if ($frontend_issue!=='') { wp_send_json_error($frontend_issue,$frontend_issue_status); }
        wp_send_json_success($success);
    }

    public static function discard(): void {
        [$id, $row, $entry] = self::requested();
        $tasks = self::tasks();
        if (!isset($tasks[$id]) || !is_array($tasks[$id])) {
            wp_send_json_error('Kein Entwurf für dieses Hobby vorhanden.', 404);
        }
        self::cleanup_pending_draft($id,$tasks[$id]);
        $tasks[$id]['status'] = 'CANCELED';
        $tasks[$id]['images'] = [];
        update_option(self::TASKS, $tasks, false);
        wp_send_json_success(['message'=>'Entwurf verworfen. Bestehende Bilder bleiben unangetastet.']);
    }

    public static function undo(): void {
        [$id,$row,$entry]=self::requested();
        $masters=self::masters();
        if (!isset($masters[$id])) { wp_send_json_error('Keine neue Bildübernahme vorhanden.',409); }
        $old=$masters[$id]['previous_master']??null;
        if (is_array($old) && !empty($old['attachment_id']) && wp_attachment_is_image((int)$old['attachment_id'])) {
            $masters[$id]=$old;
        } else { unset($masters[$id]); }
        update_option(self::MASTERS,$masters,false);
        $repl=self::replacements();unset($repl[$id]);update_option(self::REPLACEMENTS,$repl,false);
        $tasks=self::tasks();
        if (isset($tasks[$id])) {$tasks[$id]['status']='CANCELED';$tasks[$id]['images']=[];update_option(self::TASKS,$tasks,false);}
        $reviews=self::photo_reviews();unset($reviews[$id]);update_option(self::PHOTO_REVIEW,$reviews,false);
        wp_send_json_success(['message'=>'Letzte Übernahme zurückgenommen; vorheriges Bild wieder sichtbar.']);
    }

    private static function import_final(string $id, string $name, string $url) {
        if (!function_exists('wp_http_validate_url') || !wp_http_validate_url($url)) {
            return new WP_Error('hdbz_hobby_bad_url', 'Ungültige Bildadresse.');
        }
        require_once ABSPATH.'wp-admin/includes/file.php';
        require_once ABSPATH.'wp-admin/includes/image.php';
        require_once ABSPATH.'wp-admin/includes/media.php';
        $tmp = download_url($url, 45);
        if (is_wp_error($tmp)) { return $tmp; }
        try {
            $editor = wp_get_image_editor($tmp);
            if (is_wp_error($editor)) { return $editor; }
            $size = $editor->get_size();
            $w = (int) ($size['width'] ?? 0); $h = (int) ($size['height'] ?? 0);
            // No upscaling: 1500x1000 original pixels required for the single master.
            if ($w < 1500 || $h < 1000) {
                return new WP_Error('hdbz_hobby_small', 'Bild zu klein. Mindestens 1500 × 1000 Originalpixel erforderlich.');
            }
            $crop_w = min($w, (int)floor($h * 1.5));
            $crop_h = min($h, (int)floor($w / 1.5));
            $result = $editor->crop((int)floor(($w-$crop_w)/2), (int)floor(($h-$crop_h)/2),
                $crop_w, $crop_h, 1500, 1000, false);
            if (is_wp_error($result)) { return $result; }
            if (method_exists($editor,'set_quality')) { $editor->set_quality(82); }
            $uploads = wp_upload_dir();
            if (!empty($uploads['error'])) { return new WP_Error('hdbz_hobby_upload',$uploads['error']); }
            $basename = 'hobbyregister-'.sanitize_title($name).'-'.substr(sha1($id), 0, 8).'.webp';
            $file = trailingslashit($uploads['path']).wp_unique_filename($uploads['path'], $basename);
            $saved = $editor->save($file, 'image/webp');
            if (is_wp_error($saved) || empty($saved['path'])) { return new WP_Error('hdbz_hobby_save','WebP konnte nicht gespeichert werden.'); }
            $file = $saved['path'];
            $info = @getimagesize($file);
            if (!$info || $info[0] !== 1500 || $info[1] !== 1000 || ($info['mime'] ?? '') !== 'image/webp') {
                @unlink($file);
                return new WP_Error('hdbz_hobby_dimensions','Formatprüfung fehlgeschlagen.');
            }
            $attachment = wp_insert_attachment([
                'post_mime_type'=>'image/webp','post_title'=>$name.' – Hobbyregister',
                'post_content'=>'', 'post_status'=>'inherit',
            ], $file, 0, true);
            if (is_wp_error($attachment)) { @unlink($file); return $attachment; }
            wp_update_attachment_metadata($attachment, wp_generate_attachment_metadata($attachment,$file));
            update_post_meta($attachment,'_wp_attachment_image_alt',$name);
            update_post_meta($attachment,'_hdbz_hobbyregister_id',$id);
            update_post_meta($attachment,'_hdbz_ai_generated',1);
            update_post_meta($attachment,'_hdbz_hobby_master_sha256',hash_file('sha256',$file));
            return (int)$attachment;
        } finally { if (is_string($tmp) && is_file($tmp)) { @unlink($tmp); } }
    }

    public static function render(): void {
        $rows=self::rows();
        if (!$rows) { echo '<h2>Hobbyregister</h2><p>862 Hobbys nicht eindeutig geladen. Keine Änderung.</p>'; return; }
        if (!self::bridge_operational()) { echo '<h2>Hobbyregister</h2><p>Bildanzeige des Hobbyregisters nicht bestätigt. Keine Änderung.</p>'; return; }
        $counts=['pass'=>0,'fail'=>0,'pending'=>0];
        foreach ($rows as $id=>$row) { $counts[self::photo_status($id,self::entry($id))]++; }
        ?>
        <div id="hdbz-hobby-root" style="max-width:1050px">
            <style>
            #hdbz-hobby-root .hb-panel{padding:18px;background:#fff;border:1px solid #dcdcde;border-radius:6px;margin:14px 0}
            #hdbz-hobby-root .hb-list{max-height:360px;overflow-y:auto;border:1px solid #dcdcde;background:#fff}
            #hdbz-hobby-root .hb-item{display:grid;grid-template-columns:minmax(160px,1fr) minmax(120px,155px) minmax(90px,115px) auto;gap:10px;align-items:center;padding:9px 11px;border-bottom:1px solid #eee}
            #hdbz-hobby-root .hb-item[hidden]{display:none!important}
            #hdbz-hobby-root .hb-name{font-weight:500}
            #hdbz-hobby-root .hb-state,#hdbz-hobby-root .hb-presence{font-size:12px}
            #hdbz-hobby-root .hb-presence{color:#646970}
            #hdbz-hobby-root .hb-item[data-active="1"]{background:#eaf3f4}
            #hdbz-hobby-root .hb-card{padding:16px 0;max-width:760px}
            #hdbz-hobby-root .hb-card h3{margin:0 0 8px}
            #hdbz-hobby-root .hb-current-photo,#hdbz-hobby-root .hb-draft-photo{display:block;width:100%;max-width:620px;max-height:370px;object-fit:contain;object-position:left center;background:#f6f7f7;margin:10px 0}
            #hdbz-hobby-root .hb-field{margin:15px 0}
            #hdbz-hobby-root .hb-field label{display:block;font-weight:600;margin-bottom:6px}
            #hdbz-hobby-root .hb-field select{min-width:220px}
            #hdbz-hobby-root .hb-field textarea{display:block;box-sizing:border-box;width:100%;max-width:620px;min-height:75px}
            #hdbz-hobby-root .hb-actions{display:flex;gap:10px;flex-wrap:wrap;margin:14px 0}
            #hdbz-hobby-root .hb-message{padding:10px;border-left:3px solid #2271b1;background:#f6f7f7;margin:12px 0}
            #hdbz-hobby-root .hb-draft{margin-top:18px;border-top:1px solid #dcdcde;padding-top:15px}
            #hdbz-hobby-root .hb-more{margin-top:14px;color:#646970}
            @media(max-width:700px){#hdbz-hobby-root .hb-item{grid-template-columns:1fr auto;gap:4px 8px}#hdbz-hobby-root .hb-state,#hdbz-hobby-root .hb-presence{grid-column:1}#hdbz-hobby-root .hb-view{grid-column:2;grid-row:1/4}}
            </style>
            <h2>Hobbyregister – Bilder prüfen</h2>
            <p><strong><?php echo (int)count($rows); ?> Hobbys:</strong> <span id="hb-total-pass"><?php echo (int)$counts['pass']; ?></span> Bild passt · <span id="hb-total-fail"><?php echo (int)$counts['fail']; ?></span> Bild passt nicht · <span id="hb-total-pending"><?php echo (int)$counts['pending']; ?></span> Noch nicht geprüft.</p>
            <p>Jedes Bild lässt sich bearbeiten – auch ein bereits freigegebenes Masterbild. Bis zur ausdrücklichen Übernahme bleibt das bisherige Foto unverändert. Die Kategorienseiten können eigene, davon unabhängige Herobilder haben.</p>
            <section class="hb-panel">
                <h3>Hobby auswählen</h3>
                <p><input id="hb-search" type="search" class="regular-text" placeholder="Hobby suchen …" aria-label="Hobby suchen" autocomplete="off"></p>
                <div id="hb-list" class="hb-list">
                <?php foreach ($rows as $id=>$row):
                    $entry=self::entry($id);$state=self::photo_status($id,$entry);
                    $has=self::has_current_image($id,$entry);
                    $words=['pass'=>'Bild passt','fail'=>'Bild passt nicht','pending'=>'Noch nicht geprüft'];
                ?>
                    <div class="hb-item" data-id="<?php echo esc_attr($id); ?>" data-name="<?php echo esc_attr((string)($row['canonical_name']??'')); ?>" data-state="<?php echo esc_attr($state); ?>" data-has-image="<?php echo $has?'1':'0'; ?>">
                        <span class="hb-name"><?php echo esc_html((string)($row['canonical_name']??'')); ?></span>
                        <span class="hb-state"><?php echo esc_html($words[$state]); ?></span>
                        <span class="hb-presence"><?php echo $has?'Bild vorhanden':'Kein Bild'; ?></span>
                        <button type="button" class="button button-small hb-view">Öffnen</button>
                    </div>
                <?php endforeach; ?>
                </div>
                <p id="hb-none" hidden>Kein Hobby gefunden.</p>
            </section>
            <section class="hb-panel" id="hb-workspace" hidden>
                <div id="hb-results"></div>
                <p id="hb-message" class="hb-message" role="status" aria-live="polite"></p>
            </section>
        </div>
        <script>
        (function(){
            'use strict';
            const root=document.getElementById('hdbz-hobby-root');if(!root)return;
            const $=id=>document.getElementById(id);
            const items=Array.from(root.querySelectorAll('.hb-item'));
            const byId=new Map(items.map(el=>[el.dataset.id,el]));
            const statuses={pending:'Noch nicht geprüft',pass:'Bild passt',fail:'Bild passt nicht'};
            const ajax=<?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
            const nonce=<?php echo wp_json_encode(wp_create_nonce('hdbz_ajax')); ?>;
            const drafts=new Map(),customInputs=new Map(),polling=new Set();
            let selected=null,busy=false;
            function name(id){return byId.get(id)?.dataset.name||id;}
            function notice(message){$('hb-message').textContent=message;}
            function button(label,primary,action){
                const b=document.createElement('button');b.type='button';b.className='button'+(primary?' button-primary':'');b.textContent=label;
                b.addEventListener('click',async()=>{if(b.disabled)return;b.disabled=true;try{await action();}catch(e){notice(e.message);}finally{b.disabled=false;}});
                return b;
            }
            async function api(action,id,params={}){
                const body=new URLSearchParams(Object.assign({action:'hdbz_hobby_'+action,nonce,registry_id:id},params));
                let response,json;
                try{response=await fetch(ajax,{method:'POST',credentials:'same-origin',body});}
                catch(e){throw new Error('Verbindung zum Server fehlgeschlagen. Bitte erneut versuchen.');}
                try{json=await response.json();}
                catch(e){throw new Error('Der Server hat keine gültige Antwort geliefert. Bildauftrag bitte zuerst erneut öffnen.');}
                if(!json||!json.success)throw new Error(typeof json?.data==='string'?json.data:'Bildauftrag fehlgeschlagen.');
                return json.data;
            }
            function updateState(id,status,has){
                const el=byId.get(id);if(!el)return;
                el.dataset.state=status;el.querySelector('.hb-state').textContent=statuses[status]||statuses.pending;
                if(has!==undefined){el.dataset.hasImage=has?'1':'0';el.querySelector('.hb-presence').textContent=has?'Bild vorhanden':'Kein Bild';}
                const counts={pass:0,fail:0,pending:0};items.forEach(x=>counts[x.dataset.state]++);
                for(const [key,n] of Object.entries(counts))$('hb-total-'+key).textContent=String(n);
            }
            function isActive(status){return status&&!['NO_TASK','COMPLETED','FAILED','CANCELED','APPLIED'].includes(status);}
            function showImage(parent,url,alt,css){
                if(!url)return;
                const img=document.createElement('img');img.className=css;img.src=url;img.alt=alt;parent.append(img);
                const fail=document.createElement('p');fail.textContent='Die Bildvorschau ist nicht erreichbar. Dieses Foto bitte nicht ungeprüft übernehmen.';fail.hidden=true;parent.append(fail);
                img.addEventListener('error',()=>{img.hidden=true;fail.hidden=false;});
                return img;
            }
            function render(id,d){
                drafts.set(id,d);if(selected!==id)return;
                $('hb-workspace').hidden=false;
                const box=$('hb-results');box.replaceChildren();
                const card=document.createElement('div');card.className='hb-card';box.append(card);
                const heading=document.createElement('h3');heading.textContent=name(id);card.append(heading);
                const info=document.createElement('p');info.textContent=d.has_current_image?'Aktuelles Bild im Hobbyregister – bleibt bis zur Übernahme bestehen.':'Noch kein Bild im Hobbyregister vorhanden.';card.append(info);
                showImage(card,d.current_image_url||d.master_image_url||'','Aktuelles Bild für '+name(id),'hb-current-photo');
                const rating=document.createElement('div');rating.className='hb-field';card.append(rating);
                const ratingLabel=document.createElement('label');ratingLabel.textContent='Bildbewertung';rating.append(ratingLabel);
                const select=document.createElement('select');select.setAttribute('aria-label','Bildbewertung '+name(id));rating.append(select);
                for(const [key,label] of Object.entries(statuses)){
                    const opt=document.createElement('option');opt.value=key;opt.textContent=label;
                    if(key==='pass'&&!d.has_current_image)opt.disabled=true;
                    select.append(opt);
                }
                select.value=d.photo_status||'pending';
                select.addEventListener('change',async()=>{
                    const old=d.photo_status||'pending',value=select.value;select.disabled=true;
                    try{await api('review',id,{decision:value});d.photo_status=value;updateState(id,value,!!d.has_current_image);notice('Bewertung „'+statuses[value]+'“ gespeichert.');}
                    catch(e){select.value=old;notice(e.message);}
                    finally{select.disabled=false;}
                });
                updateState(id,d.photo_status||'pending',!!d.has_current_image);
                const field=document.createElement('div');field.className='hb-field';card.append(field);
                const customLabel=document.createElement('label');customLabel.textContent='Motivwunsch (optional)';field.append(customLabel);
                const custom=document.createElement('textarea');custom.placeholder='Was soll auf dem neuen Bild zu sehen sein?';custom.maxLength=400;custom.value=customInputs.get(id)||'';field.append(custom);
                custom.addEventListener('input',()=>customInputs.set(id,custom.value));
                const actions=document.createElement('div');actions.className='hb-actions';card.append(actions);
                const action=button(isActive(d.task_status)?'Bild wird erstellt …':'Bild erstellen',true,async()=>{
                    if(busy)return;
                    if(isActive(d.task_status)){notice('Es läuft bereits ein Bildauftrag für dieses Hobby.');return;}
                    const text=custom.value;
                    const warning='Neues Bild für „'+name(id)+'“ erstellen? Es können Kosten entstehen. Das bisherige Foto bleibt bis zur bestätigten Übernahme erhalten.';
                    if(!confirm(warning))return;
                    busy=true;action.disabled=true;notice('Bildauftrag wird gestartet …');
                    try{
                        if(d.has_current_image){await api('review',id,{decision:'replace',confirmed:'yes'});}
                        // Important: this is the REAL create request, not an invisible staging queue.
                        const job=await api('generate',id,{custom:text});
                        if(text.trim() && job.custom_used!==text.trim()){
                            notice('Der Auftrag wurde gestartet, aber dein Motivwunsch konnte nicht bestätigt werden. Bitte keinen zweiten kostenpflichtigen Auftrag starten.');
                        }else{
                            notice(text.trim()?'Bildauftrag mit deinem Motivwunsch gestartet.':'Bildauftrag gestartet. Der Entwurf wird automatisch geprüft.');
                        }
                        d={...d,task_status:job.status||'CREATED',images:[]};drafts.set(id,d);
                        render(id,d);poll(id);
                    }catch(e){notice('Bild konnte nicht gestartet werden: '+e.message);}
                    finally{busy=false;action.disabled=false;}
                });
                if(isActive(d.task_status))action.disabled=true;
                actions.append(action);
                const imgs=Array.isArray(d.images)?d.images:[];
                if(d.task_status==='COMPLETED'&&imgs.length){
                    const draft=document.createElement('section');draft.className='hb-draft';card.append(draft);
                    const h=document.createElement('h4');h.textContent='Neuer Entwurf – noch nicht übernommen';draft.append(h);
                    imgs.forEach((image,index)=>{
                        const frame=document.createElement('div');draft.append(frame);
                        const preview=showImage(frame,image.url,'Neuer Entwurf für '+name(id),'hb-draft-photo');
                        const buttons=document.createElement('div');buttons.className='hb-actions';frame.append(buttons);
                        const apply=button('Bild übernehmen',true,async()=>{
                            if(!confirm('Diesen Entwurf übernehmen? Das bisherige Bild wird erst jetzt ersetzt.'))return;
                            const has=!!d.has_current_image;
                            const result=await api('apply',id,{index:String(index),approved:'yes',replace_confirmed:has?'yes':'no'});
                            if(!result.attachment_id)throw new Error('Übernahme nicht bestätigt. Bisheriges Foto bleibt erhalten.');
                            const fresh=await api('prepare',id);render(id,fresh);notice('Bild übernommen. Neues Foto ist aktiv.');
                        });
                        // Do not allow approval of an image that the editor cannot actually see.
                        if(preview){apply.disabled=true;preview.addEventListener('load',()=>{apply.disabled=false;});preview.addEventListener('error',()=>{apply.disabled=true;});}
                        buttons.append(apply);
                    });
                    const discard=button('Entwurf verwerfen',false,async()=>{
                        if(!confirm('Entwurf verwerfen? Das bisherige Bild bleibt erhalten.'))return;
                        await api('discard',id);render(id,await api('prepare',id));notice('Entwurf verworfen. Bisheriges Foto bleibt erhalten.');
                    });draft.append(discard);
                }else if(d.task_status==='COMPLETED'){
                    const p=document.createElement('p');p.textContent=d.preview_error||'Kein verwendbares Bild vom Anbieter geliefert. „Bild erstellen“ startet einen neuen Versuch.';card.append(p);
                }else if(isActive(d.task_status)){
                    const p=document.createElement('p');p.textContent='Bildauftrag läuft. Das Ergebnis erscheint hier automatisch.';card.append(p);
                }else if(d.task_status==='FAILED'){
                    const p=document.createElement('p');p.textContent='Der Bildauftrag ist fehlgeschlagen. Du kannst erneut auf „Bild erstellen“ klicken.';card.append(p);
                }
                if(d.new_final){
                    const more=document.createElement('details');more.className='hb-more';card.append(more);
                    const summary=document.createElement('summary');summary.textContent='Letzte Bildübernahme zurücknehmen';more.append(summary);
                    more.append(button('Vorheriges Bild wiederherstellen',false,async()=>{
                        if(!confirm('Letzte Übernahme rückgängig machen?'))return;
                        await api('undo',id);render(id,await api('prepare',id));notice('Vorheriges Foto wiederhergestellt.');
                    }));
                }
            }
            async function poll(id){
                if(polling.has(id))return;polling.add(id);
                try{
                    for(let attempt=0;attempt<40;attempt++){
                        if(attempt)await new Promise(resolve=>setTimeout(resolve,5000));
                        const result=await api('check',id);
                        const d={...(drafts.get(id)||{}),task_status:result.status,images:result.images||[],preview_error:result.preview_error||''};drafts.set(id,d);
                        render(id,d);
                        if(['COMPLETED','FAILED','CANCELED','APPLIED'].includes(result.status)){
                            if(result.status==='COMPLETED')notice(result.images?.length?(customInputs.get(id)?.trim()?'Bild fertig – Auftrag mit deinem Motivwunsch gesendet. Bitte das Ergebnis ansehen und erst danach übernehmen.':'Bild fertig. Bitte Entwurf ansehen und übernehmen.'):'Bild fertig, aber der Anbieter lieferte keine nutzbare Vorschau.');
                            if(result.status==='FAILED')notice('Bildauftrag fehlgeschlagen. Erneut „Bild erstellen“ wählen.');
                            return;
                        }
                    }
                    notice('Der Auftrag läuft länger. Öffne das Hobby später erneut, um den aktuellen Stand zu prüfen.');
                }catch(e){notice('Statusprüfung fehlgeschlagen: '+e.message+'. Öffne dieses Hobby erneut.');}
                finally{polling.delete(id);}
            }
            items.forEach(el=>el.querySelector('.hb-view').addEventListener('click',async()=>{
                const id=el.dataset.id;selected=id;
                items.forEach(it=>{it.dataset.active=it.dataset.id===id?'1':'0';});
                $('hb-workspace').hidden=false;notice('Bild wird geladen …');
                try{const d=await api('prepare',id);render(id,d);notice('Bild geöffnet. Prüfen, bearbeiten oder neu erstellen.');
                    if(isActive(d.task_status) || (d.task_status==='COMPLETED' && (d.preview_error || (d.images?.length && !d.images[0].attachment_id))))poll(id);
                    $('hb-workspace').scrollIntoView({block:'nearest'});
                }catch(e){notice('Bild konnte nicht geöffnet werden: '+e.message);}
            }));
            $('hb-search').addEventListener('input',()=>{
                const q=$('hb-search').value.trim().toLocaleLowerCase('de');let visible=0;
                items.forEach(el=>{el.hidden=!!q&&!el.dataset.name.toLocaleLowerCase('de').includes(q);if(!el.hidden)visible++;});
                $('hb-none').hidden=visible!==0;
            });
        })();
        </script>
        <?php
    }

}
