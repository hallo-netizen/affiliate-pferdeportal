<?php
// Complete local WP-like executable harness. No network calls or live WordPress writes.
define('ABSPATH',__DIR__.'/fake-wp/'); define('HDBZ_BRIDGE_TEST',true);
class ApiSuccess extends Exception{public $value;function __construct($v){parent::__construct('SUCCESS');$this->value=$v;}}
class ApiFailure extends Exception{public $status;function __construct($s,$status){parent::__construct($s);$this->status=$status;}}
class WP_Error {private $msg;function __construct($code,$message){$this->msg=$message;}function get_error_message(){return $this->msg;}}
function is_wp_error($x){return $x instanceof WP_Error;}
$GLOBALS['opts']=[];$GLOBALS['attachments']=[];$GLOBALS['next_attachment']=1000;$GLOBALS['tasks_requests']=0;$GLOBALS['last_request_payload']=[];$GLOBALS['request_history']=[];$GLOBALS['meta']=[];$GLOBALS['fail_preview']=false;
function get_option($k,$default=false){return $GLOBALS['opts'][$k]??$default;}
function update_option($k,$v,$autoload=false){$GLOBALS['opts'][$k]=$v;return true;}
function delete_option($k){unset($GLOBALS['opts'][$k]);return true;}
function add_option($k,$v,$deprecated='',$autoload=false){if(isset($GLOBALS['opts'][$k]))return false;$GLOBALS['opts'][$k]=$v;return true;}
function current_user_can($c){return true;}
function check_ajax_referer($a,$b){return 1;}
function wp_send_json_error($v,$code=400){throw new ApiFailure((string)$v,$code);}
function wp_send_json_success($v){throw new ApiSuccess($v);}
function sanitize_text_field($s){return trim((string)$s);}
function sanitize_textarea_field($s){return trim((string)$s);}
function sanitize_key($s){return preg_replace('/[^a-z0-9_-]/','',strtolower((string)$s));}
function wp_unslash($s){return $s;}
function mb_substr($s,$start,$length=null){return substr($s,$start,$length);}
function mb_strlen($s){return strlen($s);}
function wp_strip_all_tags($s){return strip_tags((string)$s);}
function absint($n){return abs((int)$n);}
function esc_url_raw($s){return $s;}
function esc_html($s){return htmlspecialchars((string)$s,ENT_QUOTES);}
function esc_attr($s){return htmlspecialchars((string)$s,ENT_QUOTES);}
function wp_json_encode($s){return json_encode($s);}
function wp_create_nonce($s){return 'fake-nonce';}
function admin_url($path){return '/wp-admin/'.$path;}
function add_action(...$args){}
$GLOBALS['filter_callbacks']=[];
function add_filter($tag,$cb,$priority=10,$accepted=1){$GLOBALS['filter_callbacks'][$tag][$priority][]=[$cb,$accepted];return true;}
function remove_filter($tag,$cb,$priority=10){foreach($GLOBALS['filter_callbacks'][$tag][$priority]??[] as $key=>$item){if($item[0]===$cb)unset($GLOBALS['filter_callbacks'][$tag][$priority][$key]);}return true;}
function apply_filters($tag,$val,...$arguments){$set=$GLOBALS['filter_callbacks'][$tag]??[];ksort($set);foreach($set as $callbacks){foreach($callbacks as [$cb,$accepted]){$val=$cb(...array_slice(array_merge([$val],$arguments),0,$accepted));}}return $val;}
function plugins_url($path='',$plugin=''){return apply_filters('plugins_url','https://test.invalid/original/'.ltrim($path,'/'),$path,$plugin);}
function wp_attachment_is_image($id){return isset($GLOBALS['attachments'][$id]);}
function wp_get_attachment_url($id){return $GLOBALS['attachments'][$id]['url']??false;}
function get_attached_file($id){return $GLOBALS['attachments'][$id]['path']??false;}
function wp_http_validate_url($url){return strpos($url,'https://')===0;}
function download_url($url,$timeout=45){if($GLOBALS['fail_preview'])return new WP_Error('remote_down','Provider-Bild nicht abrufbar');$tmp=tempnam('/tmp','hdbz_test_');copy(__DIR__.'/fixture.webp',$tmp);return $tmp;}
function wp_get_image_editor($path){return new FakeEditor;}
class FakeEditor{
 function get_size(){return ['width'=>1500,'height'=>1000];}
 function crop($a,$b,$c,$d,$w,$h,$e){return true;}
 function set_quality($n){return true;}
 function save($path,$type){copy(__DIR__.'/fixture.webp',$path);return ['path'=>$path];}
}
function wp_upload_dir(){if(!is_dir(__DIR__.'/uploads'))mkdir(__DIR__.'/uploads',0777,true);return ['error'=>'','path'=>__DIR__.'/uploads'];}
function sanitize_title($name){return preg_replace('/[^a-z0-9-]/','-',strtolower(str_replace(' ','-',$name)));}
function trailingslashit($s){return rtrim($s,'/').'/';}
function wp_unique_filename($path,$file){return uniqid().'-'.$file;}
function wp_insert_attachment($post,$path,$parent,$return_error){$id=++$GLOBALS['next_attachment'];$GLOBALS['attachments'][$id]=['path'=>$path,'url'=>'https://test.invalid/uploads/'.basename($path)];return $id;}
function wp_update_attachment_metadata($id,$metadata){return true;}
function wp_generate_attachment_metadata($id,$file){return [];}
function update_post_meta($id,$k,$v){$GLOBALS['meta'][$id][$k]=$v;return true;}
function get_post_meta($id,$k,$single=true){return $GLOBALS['meta'][$id][$k]??'';}
function wp_delete_attachment($id,$force=true){unset($GLOBALS['attachments'][$id],$GLOBALS['meta'][$id]);return true;}
class HD_Hobbyregister_Core_Stable127{
 static $entries=[];
 static function records(){
  $out=[];
  foreach(['hobby:amateurfunk'=>'Amateurfunk','hobby:ameisenfarmen'=>'Ameisenfarmen','hobby:keinbild'=>'Kein Bild','hobby:batik'=>'Batik','hobby:airbrush-modellbau'=>'Airbrush-Modellbau','hobby:3d-bogenschieen'=>'3D-Bogenschießen','hobby:airbrush'=>'Airbrush','hobby:aeroponik'=>'Aeroponik','hobby:bonsai-landschaften'=>'Bonsai-Landschaften','hobby:arduino'=>'Arduino'] as $id=>$n){$out[]=['registry_id'=>$id,'canonical_name'=>$n];}
  for($i=10;$i<862;$i++)$out[]=['registry_id'=>'hobby:other-'.$i,'canonical_name'=>'Hobby '.$i];
  return $out;
 }
 static function image_entry($id){return self::$entries[$id]??['source'=>'test','path'=>'fallback.webp','status'=>'OLD'];}
 static function article($id){return ['sections'=>[['Einstieg','Eine bekannte Hobbytätigkeit.']]];}
}
HD_Hobbyregister_Core_Stable127::$entries['hobby:amateurfunk']=['source'=>'hd007','path'=>'amateurfunk.webp','status'=>'FINAL_MASTER_VERIFIED','production_status'=>'DONE'];
HD_Hobbyregister_Core_Stable127::$entries['hobby:ameisenfarmen']=['source'=>'hd003','path'=>'ameisen.webp','status'=>'OLD'];
HD_Hobbyregister_Core_Stable127::$entries['hobby:batik']=['source'=>'hd003','path'=>'hobby-depot-v150617/subcategories/gestalten/textilgestaltung-v150616.webp','status'=>'EXACT_CURATED_CORE_CARD','production_status'=>'OPEN_NEW_MASTER_REQUIRED','core_audit_final_verdict'=>'NOT_FINAL'];
HD_Hobbyregister_Core_Stable127::$entries['hobby:airbrush-modellbau']=['source'=>'hd007','path'=>'portraits/final-masters/airbrush-modellbau.webp','status'=>'FINAL_MASTER_VERIFIED','production_status'=>'DONE'];
HD_Hobbyregister_Core_Stable127::$entries['hobby:3d-bogenschieen']=['source'=>'hd003','path'=>'hobby-depot-v150617/subcategories/bewegen/wurf-ziel-v150627.webp','status'=>'EXACT_CURATED_CORE_CARD','production_status'=>'OPEN_NEW_MASTER_REQUIRED'];
HD_Hobbyregister_Core_Stable127::$entries['hobby:keinbild']=['source'=>'none','path'=>'','status'=>'EMPTY'];
HD_Hobbyregister_Core_Stable127::$entries['hobby:airbrush']=['source'=>'hd003','path'=>'hobby-depot-v150617/subcategories/gestalten/malen-zeichnen-v150616.webp','status'=>'EXACT_CURATED_CORE_CARD','production_status'=>'OPEN_NEW_MASTER_REQUIRED'];
HD_Hobbyregister_Core_Stable127::$entries['hobby:aeroponik']=['source'=>'hd003','path'=>'hobby-depot-v150617/subcategories/pflanzen/hydro-indoor-v150623.webp','status'=>'EXACT_CURATED_CORE_CARD','production_status'=>'OPEN_NEW_MASTER_REQUIRED'];
HD_Hobbyregister_Core_Stable127::$entries['hobby:bonsai-landschaften']=['source'=>'hd003','path'=>'hobby-depot-v150617/hero-masters-v150684/bonsai-miniatur.webp','status'=>'SEMANTIC_MASTER_REUSE','basis'=>'semantic_keyword'];
HD_Hobbyregister_Core_Stable127::$entries['hobby:arduino']=['source'=>'hd003','path'=>'hobby-depot-v150617/subcategories/technik/elektronik-v150623.webp','status'=>'EXACT_CURATED_CORE_CARD','production_status'=>'OPEN_NEW_MASTER_REQUIRED'];
class Hobby_Depot_Profile_V150709 {
  private static function hobby_image_center_v150769($slug,$page=null){
    if (in_array($slug,['airbrush','aeroponik'],true)) return ['source'=>'hobby-master','url'=>plugins_url('hobby-masters/'.$slug.'.webp',__FILE__)];
    if ($slug==='batik')return ['source'=>'batik-master','url'=>plugins_url('batik-hero.webp',__FILE__)];
    return [];
  }
}

class HD_Hobbyregister_Frontend_Stable127{ static function record_image($row){$id=$row['registry_id'];$e=HD_Hobbyregister_Core_Stable127::image_entry($id);return plugins_url(!empty($e['path'])?$e['path']:'groups/register-fallback.webp',__FILE__);}}
class HDBZ_Plugin{
 static function hobby_image_style(){return 'Natural photo of hobby action. No text.';}
 static function hobby_magnific_request($method,$path,$data=[]){
  if($method==='POST'){ $GLOBALS['last_request_payload']=$data; $GLOBALS['request_history'][]=$data; $GLOBALS['tasks_requests']++;return ['data'=>['task_id'=>'job-'.$GLOBALS['tasks_requests'],'status'=>'CREATED']];}
  return ['data'=>['status'=>'COMPLETED','generated'=>['https://test.invalid/generated/new.webp']]];
 }
}
require dirname(__DIR__).'/src/hobby-depot-bildzentrale/includes/class-hdbz-hobbyregister.php';
HDBZ_Hobbyregister::init();
$tests=0;
function eq($actual,$expected,$name){global $tests;$tests++;if($actual!==$expected){echo "FAIL [$tests] $name ".json_encode([$actual,$expected])."\n";exit(1);}echo "PASS [$tests] $name\n";}
function api($name,$id,$extra=[]){$_POST=['registry_id'=>$id,'nonce'=>'n']+$extra;try{HDBZ_Hobbyregister::$name();}catch(ApiSuccess $s){return $s->value;}catch(ApiFailure $e){return ['ERROR'=>$e->getMessage(),'HTTP'=>$e->status];}throw new Exception('No Ajax JSON response');}
$final='hobby:amateurfunk';$old='hobby:ameisenfarmen';$empty='hobby:keinbild';

// Real latest HD007 1.2.21 sampled data (read-only GitHub source audit) – do not guess from titles.
$batik='hobby:batik';$air='hobby:airbrush-modellbau';$arch='hobby:3d-bogenschieen';
eq(api('prepare','hobby:airbrush')['photo_status'],'pass','Airbrush takes approved existing category master, no generic painting studio');
eq(api('prepare','hobby:airbrush')['current_image_url'],'https://test.invalid/original/hobby-masters/airbrush.webp','Airbrush backend equals correct preexisting category master URL');
eq(api('prepare','hobby:aeroponik')['photo_status'],'pass','Aeroponik approved category master is recognized');
eq(api('prepare','hobby:aeroponik')['current_image_url'],'https://test.invalid/original/hobby-masters/aeroponik.webp','Aeroponik displays exact approved master instead of Hydro Indoor placeholder');
eq(api('prepare',$batik)['current_image_url'],'https://test.invalid/original/batik-hero.webp','Batik uses the preexisting verified hero instead of textile workshop placeholder');
eq(api('prepare',$batik)['photo_status'],'pass','Batik verified hero is already approved');
// One screenshot-verified reuse is allowed only for its exact original asset;
// unlike automatic batch approvals this neither replaces nor regenerates a photo.
$bonsai='hobby:bonsai-landschaften';
$bonsaiFirst=api('prepare',$bonsai);
eq($bonsaiFirst['photo_status'],'pass','Bonsai-Landschaften visually checked legacy photo is marked fits');
eq($bonsaiFirst['current_image_url'],'https://test.invalid/original/hobby-depot-v150617/hero-masters-v150684/bonsai-miniatur.webp','Bonsai-Landschaften keeps original existing media URL');
eq($bonsaiFirst['new_final'],false,'No generated image / no master is written for approved legacy photo');
HD_Hobbyregister_Core_Stable127::$entries[$bonsai]['path']='different-bonsai-photo.webp';
eq(api('prepare',$bonsai)['photo_status'],'pending','NEGATIVE: image replacement or changed path invalidates visual-review evidence');
HD_Hobbyregister_Core_Stable127::$entries[$bonsai]['path']='hobby-depot-v150617/hero-masters-v150684/bonsai-miniatur.webp';
eq(api('prepare',$bonsai)['photo_status'],'pass','Original screenshot-approved Bonsai-Landschaften photo remains recognized');
eq(api('review',$bonsai,['decision'=>'fail'])['status'],'fail','Editorial rejection takes priority over bundled evidence');
eq(api('prepare',$bonsai)['photo_status'],'fail','Visual evidence never overrides an explicit editorial rejection');
eq(api('review',$bonsai,['decision'=>'pass'])['status'],'pass','Editor can re-approve exactly the original photo without regenerating');

// End-to-end approved category master: current HTML photo, paid draft and takeover all
// converge without writing to the separate HD003 design plugin data/options.
$airbrush='hobby:airbrush';
$approvedBefore=api('prepare',$airbrush)['current_image_url'];
eq(api('prepare',$airbrush)['protected'],true,'Existing Airbrush category master protected until explicit edit');
eq(api('review',$airbrush,['decision'=>'replace','confirmed'=>'yes'])['allowed'],true,'Editor can explicitly request a replacement of an approved category master');
eq(api('generate',$airbrush,['custom'=>'Frau beim Airbrushen einer Modellkarosserie.'])['status'],'CREATED','Airbrush editable without modifying HD003');
eq(api('check',$airbrush)['status'],'COMPLETED','Airbrush draft imported to local WordPress media');
$airApply=api('apply',$airbrush,['approved'=>'yes','replace_confirmed'=>'yes','index'=>0]);
eq(isset($airApply['attachment_id']),true,'APPROVED CATEGORY SOURCE: real frontend hook accepts replacement');
eq(api('prepare',$airbrush)['current_image_url'],$airApply['url'],'New approved Airbrush picture reaches exact register frontend resolver');
eq(api('prepare',$airbrush)['photo_status'],'pass','Applied Airbrush master rated as fits');
eq(api('undo',$airbrush)['message'],'Letzte Übernahme zurückgenommen; vorheriges Bild wieder sichtbar.','Airbrush undo is possible');
eq(api('prepare',$airbrush)['current_image_url'],$approvedBefore,'Airbrush undo restores original approved category master');
eq(api('prepare',$airbrush)['photo_status'],'pass','Verified Airbrush source still accepted after undo');

eq(api('prepare',$air)['photo_status'],'pass','Airbrush-Modellbau original FINAL_MASTER_VERIFIED is already accepted');
eq(api('prepare',$air)['has_current_image'],true,'Airbrush-Modellbau real verified photo is found');


eq(api('prepare',$arch)['photo_status'],'pending','3D archery old Wurf/Ziel stock item is not a verified master');
$wish='Freunde beim 3D Bogenschiessen. kein tier!';
$with=api('prepare',$arch,['custom'=>$wish])['prompt'];
$without=api('prepare',$arch)['prompt'];
eq($with!==$without,true,'Different editor wish changes resolved provider prompt');
eq(strpos($with,$wish)!==false,true,'Exact German editor instruction included');
eq(strpos($with,'MANDATORY SCENE') < strpos($with,'Make exactly that scene'),true,'Editor scene outranks hobby default');
eq(strpos($with,'Correct hobby-specific subject and activity')===false,true,'Outdated stock-photo description does not override editor');
eq(strpos($with,'no animal-shaped 3D targets')!==false,true,'Explicit no animals includes no boar or animal-shaped targets');
eq(strpos($with,'several friends')!==false,true,'Several friends requested, not a solitary hunter');
eq(strlen($with)<=3000,true,'Prompt within actual Magnific limit');
// HERO: the native source is 3:2 but displayed in a shallow wide strip,
// whose left area is covered by text. Test default and custom actual prompts.
$arduino='hobby:arduino';
$arduinoDefault=api('prepare',$arduino)['prompt'];
eq(strpos($arduinoDefault,'HERO CROP REQUIREMENT')!==false,true,'Default hobby prompt contains mandatory hero composition');
eq(strpos($arduinoDefault,'middle 35%-65%')!==false,true,'Hero prompt keeps decisive action in vertically safe middle');
eq(strpos($arduinoDefault,'55%-80% of image WIDTH')!==false,true,'Hero prompt positions focal action to right of title overlay');
eq(strpos($arduinoDefault,'left 35%')!==false,true,'Hero prompt reserves quiet area for title overlay');
eq(strpos($arduinoDefault,'camera pulled back')!==false,true,'Hero prompt explicitly zooms out');
eq(strpos($arduinoDefault,'NO CLOSE-UP')!==false,true,'NEGATIVE: tight close-up is explicitly rejected');
eq(strpos($arduinoDefault,'illegibly tiny')!==false,true,'NEGATIVE: zoom-out must not make hobby unreadably small');
eq(strpos($with,'HERO CROP REQUIREMENT')!==false,true,'Hero crop rule is still present with explicit editor scene');
eq(strpos($with,'55%-80% of image WIDTH')!==false,true,'Editor scene and hero safe region coexist');
eq(strlen($arduinoDefault)<=3000,true,'Default hero prompt remains within provider limit');
eq(strlen($with)<=3000,true,'Explicit hero prompt remains within provider limit');

// VERSION 2.8.14: the earlier 'medium-wide shot' was demonstrably too close.
// Positive AND negative prompt regression: actual generator assembles one authoritative long-shot instruction
// for default and editor-custom inputs, without changing stored images or generating any new paid job.
eq(strpos($arduinoDefault,'MUCH WIDER LONG SHOT')!==false,true,'v2.8.14 requires substantially wider environmental long shot');
eq(strpos($arduinoDefault,'TWO TO THREE TIMES FARTHER')!==false,true,'Default generator requires camera distance multiplier rather than mild zoom-out');
eq(strpos($arduinoDefault,'panoramic 4:1 hero crop')!==false || strpos($arduinoDefault,'PANORAMIC 4:1 CROP')!==false,true,'Default generator explicitly targets the shallow 4-to-1 hero');
eq(strpos($arduinoDefault,'flatter 5:1 hero')!==false,true,'Extra shallow 5-to-1 hero must remain recognizable');
eq(strpos($arduinoDefault,'middle 35%-65% of image HEIGHT')!==false,true,'Decisive hobby action inside middle height-safe slice');
eq(strpos($arduinoDefault,'right 55%-80% of image WIDTH')!==false,true,'Hobby action is in right visual area without title interference');
eq(strpos($arduinoDefault,'left 35% quiet and low detail')!==false,true,'Calm left title overlay area remains available');
eq(strpos($arduinoDefault,'complete device, workpiece and workspace together')!==false,true,'Technical hobbies get person, device, object and workplace in one wide scene');
eq(strpos($arduinoDefault,'NO CLOSE-UP, NO HALF-BODY PORTRAIT, NO MACRO')!==false,true,'NEGATIVE: macro, half-body and tight framing explicitly forbidden');
eq(strpos($arduinoDefault,'Not so far away that the actual activity becomes illegibly tiny')!==false,true,'NEGATIVE: extreme wide invisible hobby is forbidden');
eq(strpos($arduinoDefault,'deliberate environmental medium-wide shot')===false,true,'Old weak medium-wide camera direction is gone');
eq(strpos($with,'MUCH WIDER LONG SHOT')!==false,true,'Custom German scene cannot bypass hero long-shot rule');
eq(strpos($with,'PANORAMIC 4:1 CROP')!==false,true,'Custom scene retains exact crop-safe requirement');
eq(strpos($with,$wish)!==false,true,'Custom scene retained verbatim beside new composition');
eq(strpos($with,'no animal-shaped 3D targets')!==false,true,'Custom exclusion (no animals) remains intact');
eq(strlen($arduinoDefault)<=3000,true,'Full much-wider default prompt not truncated');
eq(strlen($with)<=3000,true,'Full much-wider custom prompt not truncated');
eq(strpos($arduinoDefault,'natural body crops actively using tools')===false,true,'NEGATIVE: conflicting general style encouraging close body crops must not enter Hobbyregister');
eq(strpos($with,'natural body crops actively using tools')===false,true,'NEGATIVE: custom scene cannot inherit generic crop-promoting global style');

$maxLengthWish=mb_substr(str_repeat('No animal, friends with a 3D scanner. ',15),0,400);
$longScene=api('prepare',$arch,['custom'=>$maxLengthWish])['prompt'];
eq(mb_strlen($maxLengthWish),400,'Boundary: editor can provide all 400 characters');
eq(strpos($longScene,$maxLengthWish)!==false,true,'Boundary: full 400-character user wish is included unchanged');
eq(strpos($longScene,'PANORAMIC 4:1 CROP')!==false,true,'Boundary: camera-safe hero crop survives long editor request');
eq(strpos($longScene,'no animal-shaped 3D targets')!==false,true,'Boundary: no-animals exclusion survives long editor request');
eq(strpos($longScene,'FINAL PRIORITY CHECK')!==false,true,'Boundary: final priority check is not cut off by length cap');
eq(strpos($longScene,'must NOT recreate the composition of any previous photo.')!==false,true,'Boundary: prompt ends with mandatory no-reuse restriction');
eq(mb_strlen($longScene)<=3000,true,'Boundary: complete prompt fits within provider 3000-character limit');



eq(api('review',$arch,['decision'=>'replace','confirmed'=>'yes'])['allowed'],true,'Existing incorrect stock photo can be explicitly replaced');
$g=api('generate',$arch,['custom'=>$wish]);
eq($g['custom_used'],$wish,'Exact editor wish echoed by backend after paid provider request');
eq($GLOBALS['last_request_payload']['prompt'],$with,'PROVIDER ACTUAL POST contains identical highest-priority custom prompt');
eq($GLOBALS['last_request_payload']['aspect_ratio'],'3:2','Provider receives correct landscape format');
eq(api('check',$arch)['status'],'COMPLETED','Custom-wish job finishes and returns draft');
$g2=api('generate',$arch,['custom'=>'Drei Freunde beim Bogenschießen auf sportlichen Parcours, keine Tiere.']);
eq($g2['status'],'CREATED','New prompt allowed after completed draft');
eq($GLOBALS['last_request_payload']['prompt']!==$with,true,'Provider receives changed prompt on NEW paid request');
eq(strpos($GLOBALS['last_request_payload']['prompt'],'Drei Freunde')!==false,true,'New explicit group scene transmitted, not reused');
eq($GLOBALS['tasks_requests']>=2,true,'Provider called again with a new task');
eq(api('prepare',$final)['photo_status'],'pass','Existing verified final master is recognized as accepted');
eq(api('prepare',$final)['protected'],true,'Final cannot be replaced without explicit request');
eq(api('prepare',$old)['photo_status'],'pending','Assigned old photo is only NOT CHECKED');
eq(api('prepare',$empty)['photo_status'],'pending','No photo is NOT CHECKED');
eq(api('review',$empty,['decision'=>'pass'])['HTTP'],409,'Cannot mark missing picture as fitting');
eq(api('review',$final,['decision'=>'pass'])['status'],'pass','Can mark FINAL original as fits');
eq(api('review',$final,['decision'=>'fail'])['status'],'fail','Can mark FINAL original as NOT fits');
eq(api('review',$final,['decision'=>'pending'])['status'],'pending','Can reset final original to NOT CHECKED');
eq(api('review',$old,['decision'=>'pass'])['status'],'pass','Can mark assigned photo as fits');
eq(api('review',$old,['decision'=>'fail'])['status'],'fail','Can mark assigned photo as NOT fits');
eq(api('review',$old,['decision'=>'pending'])['status'],'pending','Can reset old photo to NOT CHECKED');
eq(api('generate',$final)['HTTP'],409,'No accidental fee without explicit replace on FINAL');
eq(api('review',$final,['decision'=>'replace'])['HTTP'],409,'Final replacement requires confirmation');
eq(api('review',$final,['decision'=>'replace','confirmed'=>'yes'])['allowed'],true,'FINAL may explicitly be edited');
eq(api('prepare',$final)['protected'],false,'FINAL editing unlocked after explicit user action');
eq(api('generate',$final)['status'],'CREATED','Can generate a draft for FINAL');
eq(api('generate',$final)['HTTP'],409,'In-progress paid request cannot be duplicated');
eq(api('check',$final)['status'],'COMPLETED','Can poll draft for FINAL');
eq((int)(api('prepare',$final)['images'][0]['attachment_id']??0)>0,true,'Provider output imported as locally viewable pending preview');
eq(api('prepare',$final)['has_current_image'],true,'Original remains assigned while draft sits in media');
eq(api('generate',$final)['status'],'CREATED','A COMPLETE draft does not forever block new image creation');
eq(api('check',$final)['status'],'COMPLETED','Can poll replacement of completed draft');
eq((int)(api('prepare',$final)['images'][0]['attachment_id']??0)>0,true,'New draft preview remains a local WordPress photo');
eq(api('apply',$final,['approved'=>'yes','replace_confirmed'=>'no'])['HTTP'],409,'Cannot apply FINAL replacement without explicit confirmation');
// NEGATIVE: deliberately disconnect the real frontend filter during apply.
// This MUST deny a false-success even though a valid pending file exists.
$beforeMaster=api('prepare',$final)['current_image_url'];
remove_filter('plugins_url',[HDBZ_Hobbyregister::class,'register_asset_url'],20);
$broken=api('apply',$final,['approved'=>'yes','replace_confirmed'=>'yes','index'=>0]);
eq($broken['HTTP'],409,'BROKEN frontend bridge blocks false positive image approval');
eq(api('prepare',$final)['current_image_url'],$beforeMaster,'Broken bridge leaves previous frontend image intact');
eq(api('prepare',$final)['task_status'],'COMPLETED','Failed apply retains paid draft for later retry');
add_filter('plugins_url',[HDBZ_Hobbyregister::class,'register_asset_url'],20,3);
$applied=api('apply',$final,['approved'=>'yes','replace_confirmed'=>'yes','index'=>0]);echo 'APPLIED_DEBUG '.json_encode($applied).'\n';
eq(isset($applied['attachment_id']),true,'Can apply draft to FINAL');
$aid=$applied['attachment_id'];
eq(api('prepare',$final)['photo_status'],'pass','Approved new master automatically rated fits');
eq(api('prepare',$final)['new_final'],true,'New master in local map');
eq(HDBZ_Hobbyregister::resolved_image_url('https://test.invalid/original/amateurfunk.webp',$final),$applied['url'],'FINAL override really reaches frontend URL');
eq(api('generate',$final)['HTTP'],409,'New master still needs explicit edit permission');
eq(api('review',$final,['decision'=>'replace','confirmed'=>'yes'])['allowed'],true,'Can edit already newly approved master');
eq(api('generate',$final)['status'],'CREATED','Can create second draft from already approved master');
eq(api('check',$final)['status'],'COMPLETED','Can check second draft from new master');
$second=api('apply',$final,['approved'=>'yes','replace_confirmed'=>'yes','index'=>0]);
eq($second['attachment_id']!==$aid,true,'Second draft replaces first master without deleting it');
eq(api('undo',$final)['message'],'Letzte Übernahme zurückgenommen; vorheriges Bild wieder sichtbar.','Undo second master');
eq(api('prepare',$final)['master_image_url'],$applied['url'],'Undo restores previous master');
eq(api('undo',$final)['message'],'Letzte Übernahme zurückgenommen; vorheriges Bild wieder sichtbar.','Undo first master');
eq(HDBZ_Hobbyregister::resolved_image_url('https://test.invalid/original/amateurfunk.webp',$final),'https://test.invalid/original/amateurfunk.webp','Undo restores original FINAL photo');
eq(api('review',$old,['decision'=>'replace','confirmed'=>'yes'])['allowed'],true,'Old photo can also be edited');
eq(api('review',$old,['decision'=>'cancel'])['allowed'],false,'Cancel revokes editing but keeps photo');
eq(api('prepare',$old)['photo_status'],'pending','Cancel editing does not certify original');
eq(api('review',$empty,['decision'=>'fail'])['status'],'fail','Missing photo can be tagged not suitable');
eq(api('generate',$empty)['status'],'CREATED','Empty photo can be generated immediately');
eq(strpos($GLOBALS['last_request_payload']['prompt'],'HERO CROP REQUIREMENT')!==false,true,'Actual paid provider POST uses the revised wide hero composition even without custom motif');
eq(api('check',$empty)['status'],'COMPLETED','Empty photo task completes');
eq((int)(api('prepare',$empty)['images'][0]['attachment_id']??0)>0,true,'No-image draft gets preview before approval');
$emptyApplied=api('apply',$empty,['approved'=>'yes','replace_confirmed'=>'no','index'=>0]);
eq(isset($emptyApplied['attachment_id']),true,'Empty photo can receive first master');
eq(api('prepare',$empty)['has_current_image'],true,'New master is now counted as existing');
eq(api('prepare',$empty)['photo_status'],'pass','New first master tagged fits');

// Download failure cannot be confused with a finished preview or overwrite an original.
api('review',$old,['decision'=>'replace','confirmed'=>'yes']);
$beforeImg=api('prepare',$old)['current_image_url'];
api('generate',$old);
$GLOBALS['fail_preview']=true;
$failedPreview=api('check',$old);
eq($failedPreview['status'],'COMPLETED','Provider job completed but downloaded preview did not succeed');
eq(count($failedPreview['images']),0,'No unusable/remote broken image is offered as preview');
eq(str_contains($failedPreview['preview_error'],'Provider-Bild nicht abrufbar'),true,'Real provider preview failure is visible');
eq(api('prepare',$old)['current_image_url'],$beforeImg,'Download failure keeps old frontend image');
$GLOBALS['fail_preview']=false;
$retried=api('check',$old);
eq((int)($retried['images'][0]['attachment_id']??0)>0,true,'Re-check imports previous paid draft locally without new paid generation');
$aidDraft=(int)$retried['images'][0]['attachment_id'];
api('discard',$old);
eq(isset($GLOBALS['attachments'][$aidDraft]),false,'Discard deletes only temporary pending media');
eq(api('prepare',$old)['current_image_url'],$beforeImg,'Discard preserves previous frontend photo');
// Invalidate an editorial judgement if underlying original photo silently changes.
api('review',$old,['decision'=>'pass']);HD_Hobbyregister_Core_Stable127::$entries[$old]['path']='different.webp';
eq(api('prepare',$old)['photo_status'],'pending','Changed underlying photo never inherits old positive judgement');
eq(api('prepare',$old)['replacement_allowed'],false,'Old replace permission invalid after path change');
ob_start();HDBZ_Hobbyregister::render();$html=ob_get_clean();
eq(substr_count($html,'class="hb-item"'),862,'Real UI renders exact 862 hobbies');
eq(strpos($html,'Masterbild fertig')===false,true,'Old confusing Masterbild fertig text no longer visible');
eq(strpos($html,'Bild passt nicht')!==false,true,'UI shows explicit rejects');
eq(strpos($html,'Noch nicht geprüft')!==false,true,'UI shows explicit unreviewed');
eq(strpos($html,'Bild erstellen')!==false,true,'UI has one direct create button');
eq(strpos($html,'Neue Bildentwürfe erstellen')===false,true,'No second hidden generation button');
eq(strpos($html,'hb-queue')===false,true,'No old staging queue');
eq(strpos($html,"await api('generate',id,{custom:text})")!==false,true,'Actual create click calls generation directly');
eq(strpos($html,'Bild vorhanden')!==false,true,'UI separately identifies physical image presence');
file_put_contents(__DIR__.'/actual_862_hobbies.html',$html);
echo "ALL $tests BACKEND ASSERTIONS PASSED\n";
