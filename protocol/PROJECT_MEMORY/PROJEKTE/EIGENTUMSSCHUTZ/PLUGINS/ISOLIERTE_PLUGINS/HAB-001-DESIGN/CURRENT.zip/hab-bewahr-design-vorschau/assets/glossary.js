/* Hobby-Depot-style glossary-only AJAX suggestions + filtered page results. */
(function(){
  'use strict';
  function start(){
    const root=document.querySelector('.hbdp-glossary-index');
    if(!root)return;
    const form=root.querySelector('.hbdp-glossary-searchbox');
    const input=form&&form.querySelector('[name="glossar_suche"]');
    const list=form&&form.querySelector('#hbdp-glossary-suggestions');
    const area=root.querySelector('#hbdp-glossary-live');
    if(!form||!input||!list||!area||!window.fetch||!window.AbortController)return;
    const endpoint=form.getAttribute('data-hbdp-ajax');
    if(!endpoint)return;
    const home=new URL(form.action,location.href);
    const isGlossar=url=>url.origin===home.origin&&url.pathname.replace(/\/+$/,'')===home.pathname.replace(/\/+$/,'');
    let suggestionAbort=null,resultsAbort=null,timer=null,sequence=0;
    function closeSuggestions(){list.hidden=true;list.replaceChildren();input.setAttribute('aria-expanded','false');}
    function urlWith(overrides){
      const candidate=new URL(location.href),url=isGlossar(candidate)?candidate:new URL(home);
      Object.entries(overrides).forEach(([k,v])=>v?url.searchParams.set(k,v):url.searchParams.delete(k));
      return url;
    }
    function submitForm(url,replace){
      closeSuggestions();
      if(resultsAbort)resultsAbort.abort(); resultsAbort=new AbortController();const serial=++sequence;
      area.setAttribute('aria-busy','true');
      const body=new URLSearchParams(url.search);body.set('action','hbdp_glossary_search');
      fetch(endpoint,{method:'POST',body,credentials:'same-origin',signal:resultsAbort.signal,headers:{Accept:'application/json'}})
        .then(r=>{if(!r.ok)throw Error('AJAX HTTP');return r.json();})
        .then(payload=>{
          if(serial!==sequence)return;
          if(!payload.success||typeof payload.data?.html!=='string')throw Error('AJAX invalid');
          area.innerHTML=payload.data.html;
          area.setAttribute('aria-busy','false');
          history[replace?'replaceState':'pushState']({},'',url.href);
        }).catch(error=>{
          if(error.name==='AbortError'||serial!==sequence)return;
          area.setAttribute('aria-busy','false');
          location.assign(url.href); // GET fallback is functional without AJAX
        });
    }
    function suggest(){
      const q=input.value.trim();closeSuggestions();
      if(suggestionAbort)suggestionAbort.abort();
      if(Array.from(q).length<2)return;
      suggestionAbort=new AbortController();const controller=suggestionAbort;
      const body=new URLSearchParams({action:'hbdp_glossary_search',mode:'suggest',glossar_suche:q});
      fetch(endpoint,{method:'POST',body,credentials:'same-origin',signal:controller.signal,headers:{Accept:'application/json'}})
        .then(r=>{if(!r.ok)throw Error('AJAX suggestions');return r.json();})
        .then(payload=>{
          if(controller!==suggestionAbort||!payload.success||!Array.isArray(payload.data?.suggestions))return;
          const entries=payload.data.suggestions;
          const fragment=document.createDocumentFragment();
          entries.slice(0,8).forEach(item=>{
            if(!item.title||!item.url)return;
            const a=document.createElement('a');a.href=item.url;a.className='hbdp-glossary-suggestion';
            const title=document.createElement('strong');title.textContent=item.title;
            a.appendChild(title);a.setAttribute('role','option');fragment.appendChild(a);
          });
          list.replaceChildren(fragment);
          list.hidden=!list.childElementCount;
          input.setAttribute('aria-expanded',String(!list.hidden));
        }).catch(error=>{if(error.name!=='AbortError')closeSuggestions();});
    }
    input.setAttribute('aria-controls','hbdp-glossary-suggestions');
    input.setAttribute('aria-expanded','false');
    input.addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(suggest,200);});
    input.addEventListener('keydown',e=>{
      if(e.key==='Escape'){closeSuggestions();return;}
      if(e.key==='ArrowDown'&&!list.hidden){e.preventDefault();list.querySelector('a')?.focus();}
    });
    list.addEventListener('keydown',e=>{
      const active=document.activeElement;
      if(e.key==='Escape'){closeSuggestions();input.focus();return;}
      if(e.key==='ArrowDown'||e.key==='ArrowUp'){
        e.preventDefault();const links=Array.from(list.querySelectorAll('a'));
        const ix=links.indexOf(active),next=e.key==='ArrowDown'?ix+1:ix-1;
        (links[next]||input).focus();
      }
    });
    form.addEventListener('submit',e=>{
      e.preventDefault();clearTimeout(timer);
      submitForm(urlWith({glossar_suche:input.value.trim(),glossar_buchstabe:'',glossar_seite:''}),false);
    });
    area.addEventListener('click',e=>{
      const a=e.target.closest('a');if(!a||e.ctrlKey||e.metaKey||e.shiftKey||e.altKey||e.button!==0)return;
      const url=new URL(a.href,location.href);if(!isGlossar(url))return;
      e.preventDefault();input.value=url.searchParams.get('glossar_suche')||'';
      submitForm(url,false);
    });
    document.addEventListener('click',e=>{if(!form.contains(e.target))closeSuggestions();});
    window.addEventListener('popstate',()=>{
      const url=new URL(location.href);if(!isGlossar(url))return;
      input.value=url.searchParams.get('glossar_suche')||'';
      submitForm(url,true);
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
