<?php
/**
 * Hab & Bewahr – shared footer and scoped service-page compatibility.
 * 0.1.80. Runs in the existing Design plugin. Never changes content on its own.
 */
if (!defined('ABSPATH')) exit;

function hbdp_service_is_supported_slug($slug) {
    return in_array((string)$slug, array('preise','werbung','werbung-2','impressum','agb','agb_trashed',
        'datenschutz','disclaimer','werb-anzeigebedingungen','kontakt','faq','journal','magazin'), true);
}

function hbdp_footer_service_enqueue() {
    if (is_admin() || is_feed() || is_embed()) return;
    wp_enqueue_style('hbdp-footer-service', HBDP_URL.'assets/footer-service.css', array(), '0.1.81');
    if(is_page('preise'))wp_enqueue_style('hbdp-preise-v082',HBDP_URL.'assets/preise-v082.css',array('hbdp-footer-service'),'0.1.120');
    wp_enqueue_script('hbdp-area-shortcuts-clean', HBDP_URL.'assets/area-shortcuts-clean.js', array(), '0.1.80', true);
}

/** Resolve only published pages on this WordPress instance. Never use source-site IDs. */
function hbdp_footer_page_url($slugs) {
    static $cache = array();
    foreach ((array)$slugs as $slug) {
        $slug = trim((string)$slug, '/');
        if ($slug === '') continue;
        if (!array_key_exists($slug, $cache)) {
            $p = get_page_by_path($slug, OBJECT, 'page');
            $cache[$slug] = $p && $p->post_status === 'publish' ? (string)get_permalink($p->ID) : '';
        }
        if ($cache[$slug] !== '') return $cache[$slug];
    }
    return '';
}

/** Always show these two explicitly requested footer links, even before page publication.
 * Existing published pages retain their real permalinks; otherwise link to their
 * canonical WordPress paths. No database writes in the frontend. */
function hbdp_footer_required_page_url_v159($slugs, $fallback_slug) {
    $url = hbdp_footer_page_url($slugs);
    return $url !== '' ? $url : home_url('/'.trim((string)$fallback_slug, '/').'/');
}

function hbdp_footer_listings_url() {
    // Hobby Depot original: use the real HivePress listing root as market landing.
    // Price page, FAQ and footer must all reach the SAME working entrance.
    $landing = function_exists('hbdp_market_landing_url') ? hbdp_market_landing_url() : '';
    if (is_string($landing) && $landing !== '') return $landing;
    // Graceful legacy fallback when no published landing page exists.
    $url = get_post_type_archive_link('hp_listing');
    return is_string($url) ? $url : '';
}

function hbdp_footer_account_url($suffix = '') {
    // /account/ and /account/listings/ are the existing HivePress/ListingHive paths
    // confirmed on Hobby Depot. Keep all links local to this WordPress installation.
    $published = hbdp_footer_page_url(array('account'));
    if ($published !== '' && $suffix === '') return $published;
    if (!function_exists('hivepress') && !post_type_exists('hp_listing')) return '';
    return home_url('/account/'.($suffix !== '' ? trim($suffix,'/').'/' : ''));
}

function hbdp_footer_nav($heading, $links) {
    echo '<nav class="hbdp-footer-nav" aria-label="'.esc_attr($heading).'"><h3>'.esc_html($heading).'</h3><ul>';
    foreach ($links as $link) {
        $label=(string)($link[0] ?? ''); $url=(string)($link[1] ?? '');
        if ($label === '' || $url === '') continue;
        echo '<li><a href="'.esc_url($url).'">'.esc_html($label).'</a></li>';
    }
    echo '</ul></nav>';
}

/** Minimum stable footer geometry. Output exactly with footer markup on both render paths. */
function hbdp_footer_critical_css_v076() {
    return <<<'CSS'
.hbdp-footer-v075.hbdp-footer-v076{display:block!important;width:100%!important;padding:0!important;margin:0!important;background:#f5f1e9!important;color:#29383f!important;border-top:1px solid #dedbd5!important;box-sizing:border-box!important;font:14px/1.5 Arial,Helvetica,sans-serif!important}
.hbdp-footer-v076,.hbdp-footer-v076 *{box-sizing:border-box!important}
.hbdp-footer-v076 .hbdp-frame,.hbdp-footer-copyright-v076 .hbdp-frame{display:block!important;width:min(1180px,calc(100% - 56px))!important;max-width:1180px!important;margin:0 auto!important;padding:0!important}
.hbdp-footer-v076 .hbdp-footer-logo-row{display:flex!important;align-items:center!important;justify-content:flex-start!important;min-height:83px!important;padding:9px 0 11px!important;margin:0!important;border-bottom:1px solid rgba(63,71,75,.13)!important}
.hbdp-footer-v076 .hbdp-footer-logo{display:inline-flex!important;flex-direction:column!important;align-items:flex-start!important;justify-content:flex-start!important;width:170px!important;max-width:170px!important;min-width:0!important;margin:0!important;padding:0!important;text-decoration:none!important;color:#29383f!important}
.hbdp-footer-v076 .hbdp-footer-logo svg.hbdp-footer-arc{display:block!important;flex:0 0 auto!important;width:150px!important;max-width:150px!important;height:42px!important;max-height:42px!important;margin:0!important;padding:0!important;overflow:hidden!important}
.hbdp-footer-v076 .hbdp-footer-logo strong{display:block!important;width:150px!important;max-width:150px!important;text-align:center!important;margin:0!important;padding:0!important;font:600 19px/1.2 Georgia,'Times New Roman',serif!important;white-space:nowrap!important;color:#29383f!important}
.hbdp-footer-v076 .hbdp-footer-logo em{font-style:normal!important;color:#b35c40!important}
.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four{display:grid!important;width:100%!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:38px!important;align-items:start!important;padding:26px 0 29px!important;margin:0!important}
/* Four columns occupy the entire body frame; extreme blocks align with outer edges. */
.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four>.hbdp-footer-nav:nth-child(1){justify-self:start!important}
.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four>.hbdp-footer-nav:nth-child(2),.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four>.hbdp-footer-nav:nth-child(3){justify-self:center!important}
.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four>.hbdp-footer-nav:nth-child(4){justify-self:end!important}
.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four>.hbdp-footer-nav{display:block!important;grid-column:auto!important;grid-row:auto!important;min-width:0!important;max-width:none!important;float:none!important;margin:0!important;padding:0!important;text-align:left!important}
.hbdp-footer-v076 .hbdp-footer-nav h3{display:block!important;margin:0 0 13px!important;padding:0!important;font:700 16px/1.3 Arial,Helvetica,sans-serif!important;letter-spacing:0!important;color:#29383f!important}
.hbdp-footer-v076 .hbdp-footer-nav ul{display:grid!important;gap:9px!important;list-style:none!important;margin:0!important;padding:0!important}
.hbdp-footer-v076 .hbdp-footer-nav li{display:list-item!important;list-style:none!important;margin:0!important;padding:0!important}
.hbdp-footer-v076 .hbdp-footer-nav a{font:400 14px/1.45 Arial,Helvetica,sans-serif!important;color:#29383f!important;text-decoration:none!important;overflow-wrap:break-word!important}
.hbdp-footer-v076 .hbdp-footer-nav a:hover{text-decoration:underline!important;color:#93452e!important}
/* Service content cadence is local to the existing site template, and runs even if a cached
   external stylesheet is stale. Avoid inline-text-only pseudo-spacing. */
body.hbdp-service-route .hbdp-service-body{display:flow-root!important}
body.hbdp-service-route .hbdp-service-body > :is(h2,h3,h4,p,figure,blockquote,ul,ol,div.wp-block-group){display:block!important;margin-block:0 22px!important}
body.hbdp-service-route .hbdp-service-body > :is(h2,h3,h4,p,figure,blockquote,ul,ol,div.wp-block-group) + :is(h2,h3,h4,p,figure,blockquote,ul,ol,div.wp-block-group){margin-block-start:0!important}
body.hbdp-service-route .hbdp-service-body > :is(h2,h3,h4){font-weight:700!important;line-height:1.3!important}
body.hbdp-service-route .hbdp-service-body > :is(h2,h3,h4) + figure.wp-block-table{margin-block-start:22px!important}
body.hbdp-service-route .hbdp-service-body > figure.wp-block-table + :is(h2,h3,h4,p){margin-block-start:22px!important}
body.hbdp-service-route .hbdp-service-body > figure.wp-block-table{margin-block-end:22px!important;overflow-x:auto!important}
body.hbdp-service-route .hbdp-service-body > figure.wp-block-table > table{margin:0!important}
body.hbdp-service-route .hbdp-service-body > p + :is(h2,h3,h4){margin-block-start:22px!important}
body.hbdp-service-route .hbdp-service-body > :is(h2,h3,h4) + p{margin-block-start:22px!important}
.hbdp-footer-copyright-v076{display:block!important;width:100%!important;background:#fff!important;color:#647064!important;font:12px/1.5 Arial,Helvetica,sans-serif!important}
.hbdp-footer-copyright-v076>.hbdp-frame{padding:11px 0 16px!important;text-align:center!important}
.hbdp-footer-copyright-v076 a{color:#516950!important;text-decoration:underline!important;text-decoration-thickness:1px!important;text-underline-offset:3px!important}.hbdp-footer-copyright-v076 a:hover,.hbdp-footer-copyright-v076 a:focus-visible{color:#93452e!important;text-decoration-thickness:2px!important}
.hbdp-service-route .hbdp-footer-v076 .hbdp-frame,.hbdp-service-route .hbdp-footer-copyright-v076 .hbdp-frame{width:min(1180px,74%)!important;max-width:1180px!important}
@media(max-width:980px){.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four{grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:28px 32px!important}
.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four>.hbdp-footer-nav:nth-child(2){justify-self:end!important}
.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four>.hbdp-footer-nav:nth-child(3){justify-self:start!important}}

@media(max-width:760px){.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four>.hbdp-footer-nav{justify-self:start!important}
.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four>.hbdp-footer-nav:nth-child(2),.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four>.hbdp-footer-nav:nth-child(4){justify-self:start!important}
.hbdp-footer-v076 .hbdp-frame,.hbdp-footer-copyright-v076 .hbdp-frame{width:calc(100% - 28px)!important}.hbdp-service-route .hbdp-footer-v076 .hbdp-frame,.hbdp-service-route .hbdp-footer-copyright-v076 .hbdp-frame{width:calc(100% - 30px)!important}.hbdp-footer-v076 .hbdp-footer-logo-row{min-height:76px!important}.hbdp-footer-v076 .hbdp-footer-logo{width:150px!important;max-width:150px!important}.hbdp-footer-v076 .hbdp-footer-logo svg.hbdp-footer-arc{width:133px!important;max-width:133px!important;height:37px!important;max-height:37px!important}.hbdp-footer-v076 .hbdp-footer-logo strong{width:133px!important;max-width:133px!important;text-align:center!important;font-size:17px!important}.hbdp-footer-v076 .hbdp-footer-grid.hbdp-footer-four{grid-template-columns:1fr!important;gap:23px!important;padding:22px 0!important}}
CSS;
}

function hbdp_footer_render() {
    $glossary = function_exists('hbdp_glossary_url') ? (string)hbdp_glossary_url() : '';
    $hub = hbdp_node('core:hub');
    $hub_url = $hub ? hbdp_nav_url($hub) : '';
    $magazine = hbdp_footer_page_url(array('magazin','journal'));
    if ($magazine === '') {
        $node = hbdp_node('editorial:hub');
        if ($node) $magazine = hbdp_nav_url($node);
    }
    $legal = array(
        array('Impressum',hbdp_footer_page_url('impressum')),
        array('Disclaimer',hbdp_footer_page_url('disclaimer')),
        array('Datenschutz',hbdp_footer_page_url('datenschutz')),
        array('AGB',hbdp_footer_required_page_url_v159(array('agb','allgemeine-geschaeftsbedingungen','agb-hab-und-bewahr','agb_trashed'), 'agb'))
    );
    $knowledge = array(
        array('Magazin', $magazine),
        array('Sicherheitsglossar', $glossary),
        array('Schutzkompass', $hub_url)
    );
    $service = array(
        array('Werbebedingungen',hbdp_footer_page_url('werb-anzeigebedingungen')),
        array('Werben bei Hab & Bewahr',hbdp_footer_required_page_url_v159(array('werbung','werbung-2'), 'werbung')),
        array('Preise',hbdp_footer_page_url('preise')),
        array('Kontakt',hbdp_footer_page_url('kontakt')),
        array('FAQ',hbdp_footer_page_url('faq') ?: home_url('/faq/'))
    );
    $listings = array(
        array('Anzeigenmarkt',hbdp_footer_listings_url()),
        array('Meine Anzeigen',hbdp_footer_account_url('listings')),
        array('Mein Konto',hbdp_footer_account_url())
    );
    if (is_user_logged_in()) $listings[] = array('Konto abmelden', wp_logout_url(home_url('/')));
    echo '<style id="hbdp-footer-critical-v076">'.hbdp_footer_critical_css_v076().'</style>';
    echo '<footer class="hbdp-footer hbdp-footer-v075 hbdp-footer-v076" aria-label="Seitenfooter"><div class="hbdp-frame">';
    echo '<div class="hbdp-footer-logo-row"><a class="hbdp-footer-logo" href="'.esc_url(home_url('/')).'" aria-label="Hab & Bewahr – Startseite">';
    // The header uses exactly this protection arch and wordmark; no second logo asset.
    echo '<svg class="hbdp-footer-arc" viewBox="17 24 226 52" role="img" aria-label="Schutzbogen"><path d="M 17 74 C 55 42 92 27 130 27 C 168 27 205 42 243 74 C 203 48 167 34 130 34 C 93 34 57 48 17 74 Z" fill="#B35C40"/></svg>';
    echo '<strong>Hab <em>&amp;</em> Bewahr</strong></a></div>';
    echo '<div class="hbdp-footer-grid hbdp-footer-four">';
    hbdp_footer_nav('Rechtliches',$legal);
    hbdp_footer_nav('Wissen',$knowledge);
    hbdp_footer_nav('Service',$service);
    hbdp_footer_nav('Anzeigenmarkt',$listings);
    echo '</div></div></footer><div class="hbdp-footer-copyright hbdp-footer-copyright-v076"><div class="hbdp-frame">&copy; '.esc_html(wp_date('Y')).' Hab &amp; Bewahr <span aria-hidden="true">|</span> <a href="https://p-b.one/" target="_blank" rel="noopener noreferrer">PB one.</a></div></div>';
}

/** Native ListingHive pages must also receive the same footer exactly once. */
function hbdp_footer_use_native() {
    if (is_admin() || is_feed() || is_embed() || is_robots() || is_404()) return false;
    return hbdp_for_query() === null;
}
add_filter('body_class', function($classes) {
    if (hbdp_footer_use_native()) $classes[] = 'hbdp-native-footer';
    return $classes;
}, 20);
add_action('wp_footer', function() {
    if (hbdp_footer_use_native()) {
        echo '<div class="hbdp hbdp-footer-standalone">';
        hbdp_footer_render();
        echo '</div>';
    }
}, 10);

/**
 * Strip only obsolete Kubio block delimiters in memory: the human content,
 * table rows, prices, legal text, and WordPress shortcodes remain untouched.
 * Use the site's current content, never the archived Hobby Depot export.
 */
function hbdp_service_normalize_blocks($html, $slug = '') {
    $html = (string)$html;
    if (strpos($html, 'wp:kubio/') === false) return $html;
    // Restore on-site CTAs from old Kubio button metadata instead of bare labels.
    $html = preg_replace_callback('~<!--\s*wp:kubio/button\s+(\{[\s\S]*?\})\s*-->([\s\S]*?)<!--\s*/wp:kubio/button\s*-->~u',
        static function($m) {
            $settings = json_decode($m[1], true);
            $url = (string)($settings['link']['value'] ?? $settings['kubio']['link']['value'] ?? '');
            $label = trim(strip_tags($m[2]));
            if ($label === '' || !preg_match('~^/(?!/)[a-zA-Z0-9/_?&=#%.+-]*$~', $url)) return '';
            return '<a class="hbdp-service-action" href="'.esc_url(home_url($url)).'">'.esc_html(ucfirst($label)).'</a>';
        }, $html);
    // Convert only old Kubio text blocks into real headings and paragraphs.
    // Existing WP tables, legal clauses, euro prices and explicit HTML are retained.
    $html = preg_replace_callback('~<!--\s*wp:kubio/text\b[\s\S]*?-->([\s\S]*?)<!--\s*/wp:kubio/text\s*-->~u',
        static function($m) use ($slug) {
            $text = trim($m[1]);
            if ($text === '') return '';
            if (preg_match('~^<(?:p|h[1-6]|div|ul|ol|figure|blockquote)\b~i', $text)) return $text;
            // Headline-only text blocks: never leave successive headings glued to tables.
            if (preg_match('~^<strong>([\s\S]*?)</strong>\s*$~iu', $text, $title)) {
                return $slug === 'preise' ? '<p class="hbdp-preise-title-v120"><strong>'.$title[1].'</strong></p>' : '<h2>'. $title[1] .'</h2>'; 
            }
            $pieces = preg_split('~(?:\s*<br\s*/?>\s*)+~iu', $text);
            $out = array();
            foreach ((array)$pieces as $piece) {
                $piece = trim($piece);
                if ($piece === '') continue;
                if (preg_match('~^<strong>(.*?)</strong>$~isu', $piece, $heading)) {
                    $out[] = $slug === 'preise' ? '<p class="hbdp-preise-title-v120"><strong>'.$heading[1].'</strong></p>' : '<h3>'.$heading[1].'</h3>'; 
                } else {
                    $out[] = '<p>'.$piece.'</p>';
                }
            }
            return implode("\n", $out);
        }, $html);
    // Obsolete Kubio shells were block comments, not a functioning page template.
    return preg_replace('~<!--\s*/?wp:kubio/[\s\S]*?-->\s*~u', '', $html);
}
function hbdp_service_adapt_text($content, $slug) {
    // All pages need the current site's name. Legal meaning, financial terms and
    // actual contact details are never invented or generalized here.
    $content = str_replace(array('Hobby Depot','HOBBY DEPOT','Hobby-Depot','[HOBBY-DEPOT-E-MAIL EINTRAGEN]'),
        array('Hab & Bewahr','HAB & BEWAHR','Hab & Bewahr','[HAB-UND-BEWAHR-E-MAIL EINTRAGEN]'), (string)$content);
    if (in_array($slug,array('preise','werbung','werbung-2'),true)) {
        // These are verified phrases from the 2026-10-20 importer, not a global
        // dictionary. Do not rewrite numerical prices, terms or page links.
        $pairs = array(
          'Hobbyportal'=>'Portal für Eigentumsschutz',
          'Hobbyportals'=>'Portals für Eigentumsschutz',
          'Hobbys, Ausrüstung, Materialien, Projekte, Kurse, Angebote und passende Dienstleistungen'=>'Eigentumsschutz, Sicherheitstechnik, Prävention und passende Dienstleistungen',
          'hobbyinteressierte Zielgruppe'=>'an Eigentumsschutz interessierte Zielgruppe',
          'Hobbybedarf, Werkzeugen, Materialien, Technik, Kreativbedarf, Outdoor- und Sportausrüstung, Pflanzen- und Tierbedarf, Kursen, Workshops, Fachangeboten'=>'Sicherheitstechnik, Einbruchschutz, Brandschutz, Feuchtigkeitsschutz, Gebäudetechnik, Prävention und Fachangeboten',
          'Anbieter, Dienstleister, Händler, Kursveranstalter, Werkstätten, Studios'=>'Fachbetriebe, Dienstleister, Händler, Werkstätten und kleine Anbieter',
          'Produkte rund um Hobbys'=>'Produkte und Leistungen zum Schutz von Eigentum',
          'Hobbythemen'=>'Schutzthemen',
          'Werkzeuge, Materialien, Technik, Kreativbedarf, Outdoor-Ausrüstung, Kurse oder Workshops'=>'Einbruchschutz, Brandschutz, Sicherheitstechnik, Feuchtigkeitsschutz und Gebäudetechnik',
          'Hobby-Umfeld'=>'Umfeld für Eigentumsschutz',
        );
        $content = str_replace(array_keys($pairs),array_values($pairs),$content);
    }
    // Verified obsolete hobby wording also occurs in imported legal/service pages.
    // These substitutions change the displayed subject, not parties, duties,
    // financial conditions or contact details; a legal review is still needed.
    if (in_array($slug,array('agb','disclaimer','werb-anzeigebedingungen'),true)) {
        $legal_phrases = array(
          'dieses Hobbyportals' => 'dieses Portals für Eigentumsschutz',
          'Hobbyportal' => 'Portal für Eigentumsschutz',
          'rund um Hobbys, Ausrüstung, Materialien, Projekte, Kurse, Dienstleistungen und verwandte Themen' => 'rund um Eigentumsschutz, Sicherheitstechnik, Gefahrenprävention und passende Dienstleistungen',
          'hobbybezogene' => 'eigentumsschutzbezogene',
          'wenn ein Hobby besondere' => 'wenn eine Maßnahme besondere',
          'rund um Hobbys, Ausrüstung, Materialien, Technik, Kreatives, Bewegung' => 'rund um Eigentumsschutz, Sicherheitstechnik, Gefahrenprävention und private Nutzung',
          'Viele Hobbys, Werkzeuge, Sport- und Outdoor-Aktivitäten' => 'Viele Schutzmaßnahmen, technische Arbeiten und Anwendungen',
        );
        $content = str_replace(array_keys($legal_phrases),array_values($legal_phrases),$content);
    }
    return $content;
}
function hbdp_service_clean_source($content, $slug) {
    $content = hbdp_service_normalize_blocks($content, $slug);
    return hbdp_service_adapt_text($content, $slug);
}
/**
 * Final HTML of /preise/: make intermediate headings REAL bold paragraphs, not
 * h2/h3 with a decorative CSS override. One formatting decision after Gutenberg.
 * Does not touch headings of other pages, table cells, links or prices.
 */
function hbdp_preise_render_consistent_v120($html) {
    $html = preg_replace_callback('~<h([2-6])\b[^>]*>([\s\S]*?)</h\1>~iu', static function($m) {
        $inner = trim($m[2]);
        if (preg_match('~^<strong\b[^>]*>([\s\S]*?)</strong>$~iu', $inner, $strong)) $inner = $strong[1];
        return '<p class="hbdp-preise-title-v120"><strong>'.$inner.'</strong></p>';
    }, (string)$html);
    // Same result when the WordPress editor already stores a bold-only paragraph.
    $html = preg_replace_callback('~<p\b[^>]*>\s*(<strong\b[^>]*>[\s\S]*?</strong>)\s*</p>~iu', static function($m) {
        return '<p class="hbdp-preise-title-v120">'.$m[1].'</p>';
    }, $html);
    return $html;
}
/** Critical page-scoped rule goes directly into the template HEAD. */
function hbdp_preise_critical_css_v120() {
    return 'body.hbdp-body.hbdp-preise-route .hbdp-service-body p.hbdp-preise-title-v120{' .
        'display:block!important;font-family:Arial,Helvetica,sans-serif!important;' .
        'font-size:15px!important;font-weight:700!important;line-height:1.55!important;' .
        'font-style:normal!important;letter-spacing:normal!important;text-transform:none!important;' .
        'color:#34464d!important;margin:24px 0!important;padding:0!important;}' .
        'body.hbdp-body.hbdp-preise-route .hbdp-service-body .hbdp-preise-page-v082 .hbdp-preise-section-v082{' .
        'display:block!important;gap:0!important;margin:0!important;padding:0!important;}' .
        'body.hbdp-body.hbdp-preise-route .hbdp-service-body p.hbdp-preise-title-v120 :is(strong,b,span,em,a){' .
        'font-family:inherit!important;font-size:inherit!important;line-height:inherit!important;' .
        'font-weight:700!important;letter-spacing:inherit!important;}' .
        'body.hbdp-body.hbdp-preise-route .hbdp-service-body p.hbdp-preise-title-v120 a{' .
        'color:#0e6970!important;text-decoration:underline!important;}';
}
function hbdp_service_display_content($post) {
    if (!$post || !isset($post->post_content)) return '';
    if ((string)$post->post_name === 'preise' && (string)get_post_meta((int)$post->ID,'_hbdp082_preise_disabled',true)!=='1' && hbdp_preise_is_known_legacy_v082((string)$post->post_content)) {
        return hbdp_preise_render_consistent_v120(hbdp_preise_frontend_v082());
    }
    $source = (string)$post->post_content;
    if (strpos($source, 'wp:kubio/') === false && isset($post->ID)) {
        $written = (string)get_post_meta($post->ID, '_hbdp075_cleanup_written_hash', true);
        if ($written !== '' && hash('sha256', $source) === $written) {
            $original = (string)get_post_meta($post->ID, '_hbdp075_cleanup_backup', true);
            if (strpos($original, 'wp:kubio/') !== false) $source = $original;
        }
    }
    $page_slug = (string)$post->post_name;
    $content = hbdp_service_clean_source($source, $page_slug === 'agb_trashed' ? 'agb' : $page_slug);
    $rendered = apply_filters('the_content', $content);
    return (string)$post->post_name === 'preise' ? hbdp_preise_render_consistent_v120($rendered) : $rendered;
}

/** The only permanent DB operation is a nonce-protected owner action. */
function hbdp_service_store_cleanup() {
    $counts=array('updated'=>0,'skipped'=>0,'failed'=>0);
    foreach (array('preise','werbung','werbung-2','impressum','agb','datenschutz','disclaimer','werb-anzeigebedingungen') as $slug) {
        $p=get_page_by_path($slug,OBJECT,'page');
        if (!$p || $p->post_status!=='publish') {++$counts['skipped'];continue;}
        $old=(string)$p->post_content;
        $new=hbdp_service_clean_source($old,$slug);
        if ($new===$old) {++$counts['skipped'];continue;}
        if (get_post_meta($p->ID,'_hbdp075_cleanup_backup',true)!=='') {++$counts['skipped'];continue;}
        // Save before updating, never stomp an existing backup.
        if (!add_post_meta($p->ID,'_hbdp075_cleanup_backup',$old,true)) {++$counts['failed'];continue;}
        $res=wp_update_post(array('ID'=>$p->ID,'post_content'=>wp_slash($new)),true);
        if (is_wp_error($res) || !$res) {delete_post_meta($p->ID,'_hbdp075_cleanup_backup');++$counts['failed'];continue;}
        update_post_meta($p->ID,'_hbdp075_cleanup_written_hash',hash('sha256',$new));
        ++$counts['updated'];
    }
    return $counts;
}
function hbdp_service_undo_cleanup() {
    $counts=array('restored'=>0,'skipped'=>0,'failed'=>0);
    foreach (array('preise','werbung','werbung-2','impressum','agb','datenschutz','disclaimer','werb-anzeigebedingungen') as $slug) {
        $p=get_page_by_path($slug,OBJECT,'page');
        if (!$p) {++$counts['skipped'];continue;}
        $before=get_post_meta($p->ID,'_hbdp075_cleanup_backup',true);
        $expected=get_post_meta($p->ID,'_hbdp075_cleanup_written_hash',true);
        if ($before==='' || $expected==='' || hash('sha256',(string)$p->post_content)!==$expected) {++$counts['skipped'];continue;}
        $res=wp_update_post(array('ID'=>$p->ID,'post_content'=>wp_slash($before)),true);
        if (is_wp_error($res) || !$res) {++$counts['failed'];continue;}
        delete_post_meta($p->ID,'_hbdp075_cleanup_backup');
        delete_post_meta($p->ID,'_hbdp075_cleanup_written_hash');
        ++$counts['restored'];
    }
    return $counts;
}
/** Existing admin page only: concise read-only status, no changes to the database. */
function hbdp_footer_legacy_admin_audit() {
    echo '<hr><h2>Footer &amp; importierte Serviceseiten – Prüfung 0.1.80</h2>';
    echo '<p><strong>Preise 0.1.82:</strong> Der Altimport wird unmittelbar sauber dargestellt und bei Administratoraufruf einmalig mit Sicherung durch native Seiteninhalte ersetzt.</p>';
    echo '<form method="post">'; wp_nonce_field('hbdp_control'); echo '<button class="button" name="hbdp_action" value="price_restore">Gesicherte Preisseite wiederherstellen</button> <button class="button button-primary" name="hbdp_action" value="price_rebuild">Preisseite jetzt sauber aufbauen</button></form>';
    echo '<p>Der Footer besitzt die vier Bereiche Rechtliches, Wissen, Service und Anzeigenmarkt. Seine Links kommen ausschließlich von dieser Website. Die alten Kubio-Blockkommentare werden auf den Serviceseiten nur in der Ausgabe ausgefiltert. Die Datenbank bleibt unverändert.</p>';
    echo '<table class="widefat striped"><thead><tr><th>Seite</th><th>Prüfergebnis</th></tr></thead><tbody>';
    foreach (array('preise','werbung','impressum','agb','datenschutz','disclaimer','werb-anzeigebedingungen','kontakt','faq','journal') as $slug) {
        $p = get_page_by_path($slug, OBJECT, 'page');
        if (!$p) { echo '<tr><td>'.esc_html($slug).'</td><td>Nicht vorhanden – kein Link erfunden</td></tr>';continue; }
        $findings = array();
        $content = (string)$p->post_content;
        if (strpos($content,'<!-- wp:kubio/')!==false) $findings[] = 'Alte Kubio-Blöcke in der Datenbank';
        if (preg_match('~Hobby Depot|Hobbyportal|Pferde.?(atelier|journal)|oliver-beil\.de~iu',$content)) $findings[] = 'Alte Markennamen oder Quellverweise';
        if (preg_match('~\[[^\]]*(?:E-?MAIL|EINTRAGEN|Umsatzsteuer-ID)[^\]]*\]~iu',$content)) $findings[] = 'Offene Pflichtangaben/Platzhalter';
        if (preg_match('~\[wpforms\s+id=["\']?\d+~i',$content)) $findings[] = 'Formular-ID auf Zielseite prüfen';
        echo '<tr><td><a href="'.esc_url(get_edit_post_link($p->ID)).'">'.esc_html(get_the_title($p)).'</a></td><td>'.esc_html($findings ? implode(' · ', $findings) : 'Keine bekannten Altlasten gefunden').'</td></tr>';
    }
    echo '</tbody></table><p><strong>Wichtig:</strong> Rechtstexte, Betreiberangaben, Vertragsbedingungen und manuelle Änderungen werden nicht automatisch überschrieben oder gelöscht.</p>';
    echo '<form method="post">';wp_nonce_field('hbdp_control');echo '<p><button class="button button-secondary" type="submit" name="hbdp_action" value="cleanup">Importierte Service-Seiten dauerhaft bereinigen (mit Sicherung)</button> <button class="button" type="submit" name="hbdp_action" value="cleanup_undo">Diese Bereinigung zurücknehmen</button></p></form>';
}


require_once HBDP_ROOT.'includes/preise-v082.php';


/**
 * 0.1.158 – Publish/create the requested "Werben auf Hab & Bewahr" page once.
 * This runs ONLY in an authenticated WordPress administrator request after update.
 * It never creates or publishes legal texts, nor runs database writes on frontend.
 */
function hbdp_advertise_page_default_html_v158() {
    $prices = hbdp_footer_page_url('preise');
    $terms = hbdp_footer_page_url('werb-anzeigebedingungen');
    $contact = hbdp_footer_page_url('kontakt');
    $out = '<h2>Werbung auf Hab &amp; Bewahr</h2>';
    $out .= '<p>Erreichen Sie Menschen, die sich für den Schutz ihres Eigentums, Sicherheitstechnik und passende Dienstleistungen interessieren.</p>';
    $out .= '<p>Auf Hab &amp; Bewahr gibt es Werbemöglichkeiten für passende Produkte, Fachbetriebe und Dienstleistungen.</p>';
    $out .= '<p>Informationen zu Werbeplätzen, Buchungsbedingungen und Preisen finden Sie auf den folgenden Seiten.</p>';
    $links = array(array('Preise', $prices), array('Werbebedingungen', $terms), array('Kontakt', $contact));
    $links_html = '';
    foreach ($links as $link) {
        if ($link[1] !== '') {
            $links_html .= '<a class="hbdp-service-action" href="'.esc_url($link[1]).'">'.esc_html($link[0]).'</a> ';
        }
    }
    if ($links_html !== '') $out .= '<p>'.$links_html.'</p>';
    return $out;
}

function hbdp_ensure_advertise_page_v158() {
    if (!is_admin() || !current_user_can('manage_options')) return;
    if (get_option('hbdp_advertise_page_0158_done', false) && hbdp_footer_page_url(array('werbung', 'werbung-2')) !== '') return;

    // A published advertising page already exists: leave it fully untouched.
    if (hbdp_footer_page_url(array('werbung', 'werbung-2')) !== '') {
        update_option('hbdp_advertise_page_0158_done', 'already-published', false);
        return;
    }

    // Prefer the existing unpublished page and retain all its editorial content.
    // Never resurrect trashed pages or publish private pages.
    $existing = null;
    foreach (array('werbung', 'werbung-2') as $slug) {
        $candidate = get_page_by_path($slug, OBJECT, 'page');
        if ($candidate && in_array($candidate->post_status, array('draft', 'pending'), true)) {
            $existing = $candidate;
            break;
        }
    }
    if ($existing) {
        $update = array(
            'ID' => (int)$existing->ID,
            'post_status' => 'publish',
            'post_title' => 'Werben auf Hab & Bewahr',
        );
        if (trim((string)$existing->post_content) === '') {
            $update['post_content'] = wp_slash(hbdp_advertise_page_default_html_v158());
        }
        $id = wp_update_post($update, true);
    } else {
        $id = wp_insert_post(array(
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_name' => 'werbung',
            'post_title' => 'Werben auf Hab & Bewahr',
            'post_content' => wp_slash(hbdp_advertise_page_default_html_v158()),
        ), true);
    }

    // Do not mark success on failure, so the next admin request can retry safely.
    if (!is_wp_error($id) && (int)$id > 0 && get_post_status((int)$id) === 'publish') {
        update_option('hbdp_advertise_page_0158_done', (int)$id, false);
    }
}
add_action('admin_init', 'hbdp_ensure_advertise_page_v158', 30);
