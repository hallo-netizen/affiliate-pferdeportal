<?php
/** Migration V1: JSON seed -> existing WordPress Glossar CPT. Never create ordinary posts. */
if (!defined('ABSPATH')) exit;

const HBDP_GLOSS_MIGRATION_OPTION = 'hbdp_glossary_native_migration_089';
const HBDP_GLOSS_MIGRATION_SOURCE = 'hbdp_glossary_seed_088';

function hbdp_glossary_import_seed() {
    $path=HBDP_ROOT.'data/glossary-quickreference.json';
    if (!is_readable($path)) return array('error'=>'Glossar-Ausgangsbestand fehlt');
    $raw=json_decode(file_get_contents($path),true);
    if(!is_array($raw)||($raw['contract_version']??'')!=='HB_GLOSSARY_QUICKREFERENCE_V1'||!is_array($raw['entries']??null))return array('error'=>'Glossar-Ausgangsbestand ungültig');
    $terms=$raw['entries'];$seen_id=array();$seen_slug=array();
    if(count($terms)!==82)return array('error'=>'Unerwartete Anzahl im Ausgangsbestand (erwartet 82)');
    foreach($terms as $i=>$r){
        if(!is_array($r))return array('error'=>'Eintrag '.($i+1).' beschädigt');
        $id=(string)($r['external_id']??'');$slug=(string)($r['slug']??'');
        if(!preg_match('/^term-[a-z0-9-]+$/D',$id)||!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/D',$slug)||isset($seen_id[$id])||isset($seen_slug[$slug]))return array('error'=>'Ungültige/doppelte ID oder Slug: '.($i+1));
        $seen_id[$id]=true;$seen_slug[$slug]=true;
        if(empty($r['begriff'])||empty($r['kurzdefinition'])||!isset(hbdp_glossary_worlds()[$r['themenwelt']??'']))return array('error'=>'Unvollständiger Datensatz: '.$slug);
        if(!is_array($r['fachtext']??null) || count($r['fachtext'])<1)return array('error'=>'Fachtext fehlt: '.$slug);
        foreach($r['fachtext'] as $paragraph)if(!is_string($paragraph) || trim($paragraph)==='')return array('error'=>'Absatz ungültig: '.$slug);
        $text=implode("\n\n",$r['fachtext']);$count=hbdp_glossary_wordcount($text);
        if($count<150||$count>200 || preg_match('~https?://|<\s*a\b|\]\(\s*https?://~i',$text) || hbdp_glossary_repeats_lead($r['kurzdefinition'],$text))return array('error'=>'Textregel verletzt: '.$slug);
    }
    return array('terms'=>$terms,'fingerprint'=>hash('sha256',wp_json_encode($terms,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)));
}
/** Detect title duplicates even where a pre-existing editor used another slug. */
function hbdp_glossary_existing_title_index() {
    static $index=null;
    if($index!==null)return $index;
    $index=array();
    $posts=get_posts(array('post_type'=>'hbdp_glossar_term','post_status'=>'any','numberposts'=>-1,'fields'=>'ids'));
    foreach($posts as $post_id){
        $post=get_post((int)$post_id);if(!$post)continue;
        $name=trim((string)$post->post_title);
        $key=function_exists('mb_strtolower')?mb_strtolower($name,'UTF-8'):strtolower($name);
        if($key!=='')$index[$key][]=(int)$post_id;
    }
    return $index;
}
/** Never adopt arbitrary slug/title collisions: existing posts may contain editorial changes. */
function hbdp_glossary_existing_by_id_or_slug($r) {
    $by_slug=get_page_by_path($r['slug'],OBJECT,'hbdp_glossar_term');
    $by_id=get_posts(array('post_type'=>'hbdp_glossar_term','post_status'=>'any','fields'=>'ids','posts_per_page'=>2,'meta_key'=>'_hbdp_term_id','meta_value'=>$r['external_id']));
    if(count($by_id)>1)return array('error'=>'Mehrfache externe ID: '.$r['external_id']);
    if($by_slug && $by_id && (int)$by_slug->ID!==(int)$by_id[0])return array('error'=>'Kollision ID/Slug: '.$r['slug']);
    $post=$by_slug?:($by_id?get_post((int)$by_id[0]):null);
    $key=trim((string)$r['begriff']);
    $key=function_exists('mb_strtolower')?mb_strtolower($key,'UTF-8'):strtolower($key);
    foreach(hbdp_glossary_existing_title_index()[$key]??array() as $possible_id){
        if(!$post || (int)$post->ID!==(int)$possible_id)return array('error'=>'Glossarbegriff existiert bereits mit anderem Slug: '.$r['begriff']);
    }
    if(!$post)return array('post'=>null);
    if((string)$post->post_title!==(string)$r['begriff'] || (string)$post->post_name!==(string)$r['slug'] ||
       (string)get_post_meta($post->ID,'_hbdp_term_id',true)!==(string)$r['external_id']) {
        return array('error'=>'Bestehender Glossarbeitrag belegt ID/Slug abweichend: '.$r['slug']);
    }
    return array('post'=>$post);
}
function hbdp_glossary_import_pairs($r) {
    $source=$r['quelle']??array();
    $sources=array();
    if(is_array($source)&&!empty($source['url']) && !empty($source['organisation']))$sources[]=array(
        'url'=>(string)$source['url'],'organisation'=>(string)$source['organisation'],
        // No invented citation/excerpt. Human editor must add the exact supporting evidence.
        'beleg'=>(string)($source['beleg']??'')
    );
    $date=(string)($r['source_date_checked']??'');
    $interval=(int)($r['review_interval_months']??12);
    if(!in_array($interval,array(6,12,24),true))$interval=12;
    return array(
        '_hbdp_term_id'=>(string)$r['external_id'],
        '_hbdp_world'=>(string)$r['themenwelt'],
        '_hbdp_short'=>(string)$r['kurzdefinition'],
        '_hbdp_scope'=>(string)($r['abgrenzung']??''),
        '_hbdp_synonyms'=>(array)($r['synonyme']??array()),
        '_hbdp_related'=>(array)($r['verwandte_begriffe']??array()),
        '_hbdp_sources'=>$sources,
        '_hbdp_verified'=>$date,
        '_hbdp_review_months'=>$interval,
        '_hbdp_seo_title'=>(string)($r['seo_title']??''),
        '_hbdp_seo_description'=>(string)($r['seo_description']??''),
        '_hbdp_primary_target'=>array(),
        '_hbdp_research_status'=>'ENTWURF',
        '_hbdp_validated'=>'0',
        '_hbdp_approved'=>'0',
        '_hbdp_import_source'=>HBDP_GLOSS_MIGRATION_SOURCE,
    );
}
/** At most 25 posts per transaction-like batch; rollback newly created posts on any readback failure. */
function hbdp_glossary_import_batch($terms) {
    if(count($terms)<1 || count($terms)>25)return 'Batchgröße außerhalb 1–25';
    // Check the whole batch before writing any rows.
    foreach($terms as $r){$found=hbdp_glossary_existing_by_id_or_slug($r);if(!empty($found['error']))return $found['error'];}
    $created=array();$failure='';
    foreach($terms as $r){
        $existing=hbdp_glossary_existing_by_id_or_slug($r);
        if(!empty($existing['post']))continue; // Idempotent; NEVER overwrite existing editorial changes.
        $content=implode("\n\n",$r['fachtext']);
        $id=wp_insert_post(wp_slash(array('post_type'=>'hbdp_glossar_term','post_status'=>'draft','post_title'=>$r['begriff'],'post_name'=>$r['slug'],'post_content'=>$content)),true);
        if(is_wp_error($id)||!(int)$id){$failure='WordPress-Schreibfehler: '.$r['slug'];break;}
        $created[]=(int)$id;
        foreach(hbdp_glossary_import_pairs($r) as $k=>$value){
            update_post_meta($id,$k,wp_slash($value));
            if(!hbdp_glossary_meta_readback_matches($id,$k,$value)){$failure='Metadaten-Readback: '.$r['slug'].' / '.$k;break;}
        }
        if($failure!=='')break;
        $p=get_post($id);
        if(!$p || $p->post_type!=='hbdp_glossar_term' || $p->post_status!=='draft' || $p->post_title!==$r['begriff'] ||
           $p->post_name!==$r['slug'] || $p->post_content!==$content){$failure='Beitrags-Readback: '.$r['slug'];break;}
    }
    if($failure!==''){
        foreach($created as $id)wp_delete_post($id,true);
        return $failure.' – Batch zurückgesetzt';
    }
    return '';
}
function hbdp_glossary_import_progress($seed) {
    $ok=0;$pending=array();$err='';
    foreach($seed['terms'] as $r){
        $found=hbdp_glossary_existing_by_id_or_slug($r);
        if(!empty($found['error'])){$err=$found['error'];break;}
        if(!empty($found['post']))$ok++;else $pending[]=$r;
    }
    return array('done'=>$ok,'pending'=>$pending,'error'=>$err);
}
/** Runs only on normal admin GET; not AJAX, REST, cron, frontend, or save. Max 25 creations per admin request. */
add_action('admin_init',static function(){
    if(!current_user_can('manage_options')||wp_doing_ajax() || (defined('DOING_CRON')&&DOING_CRON) || (defined('REST_REQUEST')&&REST_REQUEST) || ($_SERVER['REQUEST_METHOD']??'GET')!=='GET')return;
    // Migration is one-time only: no expensive readback on every subsequent admin request.
    $previous=get_option(HBDP_GLOSS_MIGRATION_OPTION,array());
    if(is_array($previous)&&!empty($previous['complete'])&&(int)($previous['done']??0)===82)return;
    $seed=hbdp_glossary_import_seed();if(isset($seed['error'])){update_option(HBDP_GLOSS_MIGRATION_OPTION,array('error'=>$seed['error'],'done'=>0),false);return;}
    // A full, authoritative readback, not a mere done flag, controls completion.
    $status=hbdp_glossary_import_progress($seed);
    if($status['error']!=='') {update_option(HBDP_GLOSS_MIGRATION_OPTION,array('error'=>$status['error'],'done'=>$status['done']),false);return;}
    if(!empty($status['pending'])){
        $err=hbdp_glossary_import_batch(array_slice($status['pending'],0,25));
        if($err!==''){update_option(HBDP_GLOSS_MIGRATION_OPTION,array('error'=>$err,'done'=>$status['done']),false);return;}
        $status=hbdp_glossary_import_progress($seed);
    }
    $complete=($status['error']==='' && count($status['pending'])===0 && $status['done']===count($seed['terms']));
    update_option(HBDP_GLOSS_MIGRATION_OPTION,array('done'=>$status['done'],'total'=>count($seed['terms']),
        'complete'=>$complete,'fingerprint'=>$seed['fingerprint'],'error'=>$status['error']),false);
});
function hbdp_glossary_import_completed() {
    $state=get_option(HBDP_GLOSS_MIGRATION_OPTION,array());
    return is_array($state)&&!empty($state['complete']) && (int)($state['done']??0)===82;
}
add_action('admin_notices',static function(){
    if(!current_user_can('manage_options'))return;
    $state=get_option(HBDP_GLOSS_MIGRATION_OPTION,array());
    if(!is_array($state))return;
    $done=(int)($state['done']??0);
    if(!empty($state['error']))echo '<div class="notice notice-error"><p><strong>Glossar-Übernahme angehalten:</strong> '.esc_html($state['error']).' · '.esc_html((string)$done).'/82 unveröffentlichte Entwürfe vorhanden. Keine Dubletten angelegt.</p></div>';
    elseif($done>0 && (empty($state['complete']) || (string)($_GET['post_type']??'')==='hbdp_glossar_term'))echo '<div class="notice notice-'.(!empty($state['complete'])?'success':'info').'"><p><strong>Glossar-Verwaltung:</strong> '.esc_html((string)$done).'/82 Begriffe übernommen. '.(!empty($state['complete'])?'Vollständig: WordPress ist jetzt die einzige aktive Inhaltsquelle.':'Weitere maximal 25 werden beim nächsten normalen Backend-Seitenaufruf übernommen.').' Alle neuen Einträge sind Entwürfe ohne Fachfreigabe.</p></div>';
});
