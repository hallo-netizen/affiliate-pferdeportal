<?php
/** Hab & Bewahr menu-only labels. Display aliases, NOT changes to WordPress categories.
 * All 31 R3 area and all 93 R3 subarea node IDs, checked against the source readback.
 * New nodes without an alias keep their full correct original name.
 */
if (!defined('ABSPATH')) exit;
function hbdp_menu_label($node) {
    static $labels = array(
        'core:area:19b467511ad1' => 'Freizeit & Fahrzeuge',
        'core:area:1c0afd6fe7ca' => 'Fernüberwachung',
        'core:area:2252b23b56f6' => 'Pumpen & Technik',
        'core:area:236d4048ce84' => 'Camping',
        'core:area:25271bd55031' => 'Betriebe & Vereine',
        'core:area:341ee911ae13' => 'Frost & Schnee',
        'core:area:4611320db640' => 'Gebäude',
        'core:area:5a96d921a2a1' => 'Außenbereich',
        'core:area:6110a347ffcf' => 'Außentechnik',
        'core:area:64303d0ddd32' => 'Strom & Notstrom',
        'core:area:6f5aebe4e92b' => 'Haus & Wohnung',
        'core:area:72f261fdd6ff' => 'Keller & Rückstau',
        'core:area:75a0fdd055d2' => 'Regen & Hochwasser',
        'core:area:7efc2329e1f6' => 'Camping & Freizeit',
        'core:area:9a10ea2cb38a' => 'Sturm & Hagel',
        'core:area:9c3a4ea26d92' => 'Vereine & Betriebe',
        'core:area:a07232a95f20' => 'Blitz & Stromschutz',
        'core:area:a61eee15af3b' => 'Rauch & Brand',
        'core:area:ae6cfd9f4fba' => 'Abwesenheit',
        'core:area:ba7182312835' => 'Garten & Grundstück',
        'core:area:bcad8185d370' => 'Betriebe & Vereine',
        'core:area:c7f34e6a2260' => 'Freizeit & Wetter',
        'core:area:cfb8431a47d0' => 'CO & Gas',
        'core:area:d03822af4a84' => 'Frost & Abwesenheit',
        'core:area:d0e7877ce32c' => 'Lecks & Rohrbruch',
        'core:area:d71aef44a98c' => 'Betriebe & Vereine',
        'core:area:dfec0af81251' => 'Garagen & Räume',
        'core:area:e3d4d2f00002' => 'Akkus & Elektrik',
        'core:area:e6d091a0c088' => 'Alarm & Smart Home',
        'core:area:ee3952240d8b' => 'Freizeit',
        'core:area:f03faeefbce4' => 'Heizung & Klima',
        'core:subarea:1155be4b7a718bc5' => 'Leerstehende Häuser',
        'core:subarea:115822da2ae9fc07' => 'Eingänge & Glas',
        'core:subarea:1262f0d1a16b4a96' => 'Läden & Vereine',
        'core:subarea:260a0920e7b951f2' => 'PV & Kameras',
        'core:subarea:27d113e90d7a2456' => 'Wohnmobile',
        'core:subarea:28d8087df57279b8' => 'Haus & Keller',
        'core:subarea:3e8dfec15ad57d77' => 'Notstrom',
        'core:subarea:4d7782e922837e68' => 'Camping & Boote',
        'core:subarea:4dbf86eb169f98d2' => 'Wärmepumpen',
        'core:subarea:51d4e47d1437c0fb' => 'Außenanlagen',
        'core:subarea:609c5d8889eb07dd' => 'Gas & CO-Warnung',
        'core:subarea:6169882265e80dd2' => 'Mobile Objekte',
        'core:subarea:64c307d994a7cbb0' => 'Pakete & Garten',
        'core:subarea:6a3a7736b46a3483' => 'Brandschutz',
        'core:subarea:6c1e63ba0ebd7f68' => 'Garagen & Keller',
        'core:subarea:731b72fa268b5b5a' => 'Blitzschutz',
        'core:subarea:74e7cdfc2b200d76' => 'Winterschutz',
        'core:subarea:7538e35df7d5fd84' => 'Hobbyräume',
        'core:subarea:7a5778250272c806' => 'Boote & Trailer',
        'core:subarea:88a6c8b04bc14f63' => 'Türen & Fenster',
        'core:subarea:90d80d706e8b027b' => 'Graffiti',
        'core:subarea:927eb3aa17e7e630' => 'Hochwasserfolgen',
        'core:subarea:a2c3f772d07db51e' => 'Alarm & Kameras',
        'core:subarea:a9a810d93cefa16c' => 'Akkus & Werkstatt',
        'core:subarea:b21e2895e32435e4' => 'Camping & Boote',
        'core:subarea:b8556bb0d206e66c' => 'Wasserschäden',
        'core:subarea:b98564156a5f5ebb' => 'Heiz- & Kühlalarm',
        'core:subarea:b9b33c48d54febc4' => 'Gartenhäuser & Tore',
        'core:subarea:b9e996f2919443cc' => 'Feuchte & Trocknung',
        'core:subarea:bf71a9402f21d606' => 'Netzunabhängiger Alarm',
        'core:subarea:c06472ac764f8bb6' => 'Stellplätze & Umbau',
        'core:subarea:c3293597db93160c' => 'Leckwarnung',
        'core:subarea:c794a085651f638b' => 'Brandschutz Camper',
        'core:subarea:c84f412718dd7c5b' => 'Räder & Fahrzeuge',
        'core:subarea:c8a6a3e042c29ffd' => 'Frostschutz',
        'core:subarea:ce03307f435cddb3' => 'Vereine & Plätze',
        'core:subarea:d3370baa6db0770a' => 'Betrieb – Wasserschutz',
        'core:subarea:d60c45cef20293fb' => 'Löschen & Schützen',
        'core:subarea:daae6f0a62d28c07' => 'Betriebe & Ateliers',
        'core:subarea:dbf473379fd87d95' => 'Wertsachen',
        'core:subarea:df9efed49e9ced9b' => 'Haus & Nebenräume',
        'core:subarea:e4277fda69ced0d4' => 'Pumpennotbetrieb',
        'core:subarea:ec729ccf048009bd' => 'Rückstau & Pumpen',
        'core:subarea:f985af1ab7fb3533' => 'Winterlager',
        'core:subarea:fad7c82a242f2c16' => 'Dach, Fenster & PV',
        'core:subarea:r3-01caab8d89fc0742' => 'Wiederanlauf',
        'core:subarea:r3-03280f09e1f4fd70' => 'Spiel & Freizeit',
        'core:subarea:r3-08d1c3f95ff33d00' => 'Camper-Gas',
        'core:subarea:r3-099c5d1ead6cd926' => 'Sanitärkontrollen',
        'core:subarea:r3-0c4c00d85dec246e' => 'Raumlüftung',
        'core:subarea:r3-12d26b40342dabb5' => 'Elektroleitungen',
        'core:subarea:r3-1d04bd715f0b3c23' => 'Gasleitungen',
        'core:subarea:r3-29710c165fdc4fa7' => 'Geparkte Fahrzeuge',
        'core:subarea:r3-29ae9462c0d1f625' => 'Sportanlagen',
        'core:subarea:r3-3305deb0d7ee3356' => 'Hochwasserwarnung',
        'core:subarea:r3-3b506ad506e3bb4d' => 'Kontrollen',
        'core:subarea:r3-3eb2ee24f49daf59' => 'Pumpenwartung',
        'core:subarea:r3-443a53088f3b389c' => 'Tanks & Sanitär',
        'core:subarea:r3-46a6bfb4e6597c79' => 'Vereisung',
        'core:subarea:r3-4bddb6ca3c11ceaf' => 'Zutritt & Abläufe',
        'core:subarea:r3-54c58b2291237b64' => 'Brandlasten',
        'core:subarea:r3-5bf9a9f7ac41fac4' => 'Betriebsfolgen',
        'core:subarea:r3-5c5afe8c38f94e25' => 'Alarmübertragung',
        'core:subarea:r3-5d0377daf4f162ce' => 'Winterwege',
        'core:subarea:r3-60f298fde2616ca0' => 'Sturmvorsorge',
        'core:subarea:r3-63bb9f10fc776e70' => 'Freizeitflächen',
        'core:subarea:r3-6ca418d3ad77c88a' => 'Alarmreaktionen',
        'core:subarea:r3-718d153a810baa16' => 'Pumpen & Sensoren',
        'core:subarea:r3-7dae3268faaeea1c' => 'Ofen & Kamin',
        'core:subarea:r3-7de923d77f534081' => 'Regenabdichtung',
        'core:subarea:r3-8829d3339a14710f' => 'Fassaden',
        'core:subarea:r3-90c643c921595b21' => 'Technikräume',
        'core:subarea:r3-95599f104f34d60d' => 'Betriebliche Flucht',
        'core:subarea:r3-9aa4363688876852' => 'Erdung & Haus',
        'core:subarea:r3-a2a446a27dc09c74' => 'Akkus & Laden',
        'core:subarea:r3-a33a954403335f12' => 'Außenleitungen',
        'core:subarea:r3-a6c3442a20ab2019' => 'Grundwasser',
        'core:subarea:r3-a7e016776e3c7b25' => 'Fahrzeuge & Transport',
        'core:subarea:r3-b48e03ab3db40249' => 'Fluchtwege',
        'core:subarea:r3-bb7c04f0a46544eb' => 'Außeninventar',
        'core:subarea:r3-c35767a9141583bc' => 'Innenräume',
        'core:subarea:r3-c384fde6f5631a95' => 'Zähler & Leitungen',
        'core:subarea:r3-c5e86b44508e3e51' => 'Garten & Möbel',
        'core:subarea:r3-c8c1c680287ebb1f' => 'Fernregelung',
        'core:subarea:r3-c9a85d5a61ec3c38' => 'Rohrwartung',
        'core:subarea:r3-cdaca9db6d34bcab' => 'Carports & Lager',
        'core:subarea:r3-d784b9ff8c308622' => 'Smart-Home-Notbetrieb',
        'core:subarea:r3-da5ffcf93a4c2818' => 'Grenzen & Wege',
        'core:subarea:r3-e0a3a6b4fb701d21' => 'Stromschutz',
        'core:subarea:r3-e221783434b176c2' => 'Antennen & Solar',
        'core:subarea:r3-ef3064f8b715d92e' => 'Brandfall – Fluchtwege',
        'core:subarea:r3-f362477dc05633d6' => 'Temperaturwarnung',
        'core:subarea:r3-f8db3998237d9b30' => 'Sanitär & Räume',
    );
    $id=(string)($node['id'] ?? '');
    return hbdp_category_title_without_dashes($labels[$id] ?? hbdp_display_category_name($node));
}


/**
 * Only one R3 navigation shorthand accidentally matched the NAME of a leaf
 * while linking its parent: 'Türen & Fenster' was linked to 'Mechanik & Zugang'.
 * Resolve that exact target by immutable node ID, with parent+name checks.
 * All other menu items retain their existing URL and navigation hierarchy.
 */
function hbdp_menu_destination($subarea) {
    $alias_id=(string)($subarea['id']??'');
    if($alias_id==='core:subarea:88a6c8b04bc14f63') {
        $leaf=hbdp_node('core:leaf:001');
        if($leaf && ($leaf['parent']??'')===$alias_id
            && ($leaf['name']??'')===hbdp_menu_label($subarea)
            && ($leaf['type']??'')==='category') return $leaf;
    }
    return $subarea;
}

/** Presentation-only ordering: avoid inheriting arbitrary order from WordPress snapshot. */
function hbdp_menu_sort_areas($areas) {
    static $rank = array(
        'core:area:19b467511ad1' => 2,
        'core:area:1c0afd6fe7ca' => 4,
        'core:area:2252b23b56f6' => 2,
        'core:area:236d4048ce84' => 3,
        'core:area:25271bd55031' => 4,
        'core:area:341ee911ae13' => 2,
        'core:area:4611320db640' => 1,
        'core:area:5a96d921a2a1' => 0,
        'core:area:6110a347ffcf' => 2,
        'core:area:64303d0ddd32' => 0,
        'core:area:6f5aebe4e92b' => 0,
        'core:area:72f261fdd6ff' => 1,
        'core:area:75a0fdd055d2' => 1,
        'core:area:7efc2329e1f6' => 3,
        'core:area:9a10ea2cb38a' => 0,
        'core:area:9c3a4ea26d92' => 4,
        'core:area:a07232a95f20' => 3,
        'core:area:a61eee15af3b' => 0,
        'core:area:ae6cfd9f4fba' => 4,
        'core:area:ba7182312835' => 3,
        'core:area:bcad8185d370' => 4,
        'core:area:c7f34e6a2260' => 4,
        'core:area:cfb8431a47d0' => 1,
        'core:area:d03822af4a84' => 2,
        'core:area:d0e7877ce32c' => 0,
        'core:area:d71aef44a98c' => 5,
        'core:area:dfec0af81251' => 1,
        'core:area:e3d4d2f00002' => 2,
        'core:area:e6d091a0c088' => 1,
        'core:area:ee3952240d8b' => 3,
        'core:area:f03faeefbce4' => 3,
    );
    usort($areas, static function($a,$b) use ($rank) {
        $ra=$rank[$a['id']] ?? 99;
        $rb=$rank[$b['id']] ?? 99;
        return ($ra<=>$rb) ?: strcmp($a['name']??'',$b['name']??'');
    });
    return $areas;
}
