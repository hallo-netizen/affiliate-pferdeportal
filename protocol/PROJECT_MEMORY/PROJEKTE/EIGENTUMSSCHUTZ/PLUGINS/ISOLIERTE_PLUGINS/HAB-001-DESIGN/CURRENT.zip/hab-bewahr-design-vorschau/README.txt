Hab & Bewahr – Design 0.1.48 (19.10.2026) – FOTOKORREKTUR, NICHT ENDABGENOMMEN
- Bestehendes Plugin hab-bewahr-design-vorschau, kein zweites Plugin, keine Kategorieänderungen.
- Originalbestand 0.1.44 erhalten; keine pauschale Löschung früher bebilderter Themen.
- 36 Bereichs-Kacheln fest thematisch zugeordnet; ihre Zielseiten-Heros nutzen dasselbe Foto.
- Gleiche reale Bildszenen (auch mit anderem Dateinamen) innerhalb derselben Hubseite unterbinden.
- Kennzeichendiebstahl erhält vorhandenes Einzelbild; Bootsfotos aus zuvor lokal generiertem, scharfem Einzelmotiv ersetzt.
- Drei zusätzliche Themen sachgerecht mit bereits vorhandenen Motiven bebildert.
- Bilder innerhalb der Kachelrahmen vollständig anzeigen, ohne seitliche Objektabschnitte abzuschneiden.
- Unverändert OFFEN: mehrere noch nicht bebilderte Themen; Wärmepumpe/Startseite weiterhin weiches Bild; echte WordPress-Live-Abnahme.
- Noch nicht als fertige Design- und Fotogesamtfreigabe verstehen.

Hab & Bewahr – Design 0.1.19: Die zuvor leere Ausgabefunktion für 409 Kategorietexte ist jetzt an den echten Seitentitel gebunden. Der Menüpunkt Türen & Fenster öffnet die richtige Zielkategorie, nicht Mechanik & Zugang. Veralteter Menücache wird umgangen. Texte, Bilder, Glossar, WordPress-Kategorien unverändert.

Version: 0.1.18
HAB & BEWAHR – DESIGN 0.1.11 / EIN PLUGIN – UPDATE DER VORHANDENEN VERSION
========================================================================
INSTALLATION: WordPress → Plugins → Plugin hinzufügen → Plugin hochladen →
vorhandene Version „Hab & Bewahr – Design“ ERSETZEN. KEIN ZUSATZPLUGIN.
Bestehende Plugin-Identität: hab-bewahr-design-vorschau/hab-bewahr-design-vorschau.php

NEU 0.1.11 / NUR DIE SECHS HAUPTSCHUTZWELTEN
- Ganz unten je umfangreicher sachlicher Infobereich (~560 bis ~750 Wörter),
  für alle realen 31 Hauptunterbereiche jeweils ein eigener Abschnitt.
- 31 Kategorienamen als echte Links IN jeweils passenden Fließtexten,
  dynamisch zum aktiven WordPress-Zielknoten aufgelöst. Keine alte Linkliste.
- Pro Welt zwei flache Panoramabilder (max. 148px hoch), Alt-Texte und Caption.
  Für Einbruch, Vandalismus und Wasser wurden sechs neue, klarere Fotomotive integriert.
  Andere Weltbilder sind noch Bildredaktionsentwürfe und nicht fachlich final.
- Je Welt eine echte Liste mit drei Sicherheitsaspekten, keine FAQ-Module.
- Uniformer horizontaler Satzspiegel: jeder Abschnitt hat identische linke Kante.
- Mobile Logo-Leerfläche URSÄCHLICH behoben: SVG-ViewBox beschnitten und
  Header-Zeilenabstand vermindert; Breadcrumb auf Kategorien/Artikel direkt
  unter die Schutzwelten-Navigation gerückt, statt 66px Seiten-Innenabstand.
- Andere 31+93+285 Kategorie-TEXTE/DESIGNENTSCHEIDUNG unverändert.
- KEINE Kategorie-/Term-Updates, keine Backgroundjobs, kein neues Glossarplugin.
- Texte sind weiterhin WIP/Redaktionsentwürfe: Quellencheck/Live-SEO noch offen.
- WordPress-LIVE-Test steht aus; lokale PHP-/Chromium-/ZIP-Tests bestanden.

HAB & BEWAHR – DESIGN 0.1.8 / SICHERHEITSGLOSSAR
================================================
Dies ist ein IN-PLACE-UPDATE des bestehenden Plugins hab-bewahr-design-vorschau/,
keine zweite Design-Plugin-Installation. Bestehende Kategorie-/Design-/Navigationslogik
bleibt erhalten, die zentrale Kategorienquelle bleibt read-only.

GLOSSAR – VERBINDLICHE TRENNUNG
- Redaktionelles Glossarbüro: Projekt EIGENTUMSSCHUTZ/WISSENSDATENBANK/AKTENSCHRAENKE/GLOSSAR/.
- Glossarbegriffe: native WordPress-Entwürfe des CPT hbdp_glossar_term.
- Webdesign: weiterhin dieses bestehende Designplugin; Inhaltsdaten liegen im WordPress.
- Zielseite: die vorhandene zentral verwaltete WordPress-Seite editorial:glossar (im R3-Readback WP-ID 184).
  Die alte Adresse /glossar/ leitet auf die echte native WordPress-Seite weiter, soweit sie vorhanden ist.
  Weder wird eine zweite Seite erstellt noch wird die bestehende Kategorieverwaltung überschrieben.
- Der bisherige ungeprüfte, 100 Begriffe umfassende JSON-Kurzbestand wurde aus dem
  öffentlichen Designpaket entfernt und als separates 100-KANDIDATEN_WIP-Paket gesichert.
- KEIN AUTOMATISCHER IMPORT ODER PUBLISH. Die Glossarübersicht zeigt nur veröffentlichte,
  geprüfte Begriffe und erklärt den redaktionellen Aufbau, solange noch keiner freigegeben ist.
  Bis dahin noindex via wp_robots bei null veröffentlichen Begriffen.

REDAKTIONELLE PRODUKTION
Glossar → Geprüfte Batches: manuell ein HB_GLOSSARY_BATCH_V1-JSON (max. 25) hochladen,
validieren, separat bestätigen, nur Entwürfe importieren. 150–200 Wörter, eine primäre
Schutzwelt, Quellen, Abgrenzung, verwandte Begriffe, SEO-Metadaten und Prüfdatum sind Pflicht.
Exakte aktuelle WP-Kategorienamen werden blockiert. Beziehungsziele werden vor dem Import
auf Existenz geprüft. Scheitert der Import oder Readback: gesamte neue Batch zurücknehmen.
In der Fachprüfung des Terms Freigabehäkchen getrennt speichern, anschließend manuell
veröffentlichen. Glossar → Prüfbedarf zeigt fällige Kontrolltermine ohne automatische Änderung.

WP-INSTALLATION
WordPress → Plugins → Plugin hinzufügen → ZIP hochladen → bestehende Version ersetzen.
Danach einmal WordPress-Plugins/Glossar-Backend öffnen (Rewrite-Refresh einmalig im Admin).
Sichtprüfung: vorhandene Glossar-Seite öffnen, /glossar/ auf denselben Seiten-Owner prüfen,
mobile Navigation/Startseite/Kategorie prüfen. Bis dahin KEIN WORDPRESS-LIVE-PASS.

LOKALE GATES
PHP-Lint, 17 Validatoren, 4 simulierte Importpfade inkl. Dubletten,
Schreibfehler und Rollback, 20 Browseransichten, ZIP-Integrität bestanden.
Nicht gleichbedeutend mit echter WordPress-Liveinstallation.

0.1.11: Main Schutzwelt headings are clickable real destination URLs, chevrons remain mega toggles. Glossary route /glossar/ resolves without requiring admin permalink flush; legacy /magazin/magazin-glossar-a-z/ redirects to it. Top native category text and long bottom world text follow vetted Pferde Atelier CONTENT RULES only, no design copied. Editorial copy is independently editable in page sidebar/metabox; category tree remains read-only.

0.1.11: NUR 6 Hauptschutzwelten – lange Informationstexte unterhalb der Kategorienkarten, editorial mit 2 lokalen Bildern, Liste und 3 dynamisch verlinkten Bereichskategorien (exakter Name). FAQ-Fragen vorerst vollständig entfernt. Andere Kategorien bleiben vor Designentscheidung unverändert. Kompakterer mobiler Kopf: Schutzbogen/Logo weiter nach oben, weniger Leerraum. Auto-Fallback bleibt redaktioneller WIP, manuelle Texte überschreiben weiterhin.


Version 0.1.13: Ein einziges Designplugin. Sechs Hauptwelt-Langtexte weiter unten, aber Bilder jetzt als maximal 138px hohe eigenständige Panoramastreifen ZWISCHEN den vollständig breiten Textabschnitten; kleine mobile Streifen 114px. Textlinks/Breadcrumbs bewusst unverändert. Mobile Logo-/Schutzbogen-Gruppe nochmals um rund 9px näher an die obere Kante. Keine Änderungen an R3/V8-Kategorien, Glossar, Textdatensätzen oder WP-Inhalten.

0.1.13: Mobile header: restore logo size, remove competing mobile CSS, keep 16px spacing above search, remove orphaned WordPress admin-bar whitespace only if the toolbar is invisible. No world editorial, breadcrumb or category changes.

VERSION 0.1.14 / SICHERHEITSGLOSSAR – SICHTBARER GRUNDBESTAND
===========================================================
- A–Z-Seite /glossar/ zeigt ab Installation 42 quellenbezogene Kurzdefinitionen
  aus allen sechs Schutzwelten – auch wenn noch keine WordPress-Einzelartikel
  freigegeben sind. Sechs Themenfilter, Suche, Buchstabenfilter und
  direkte offizielle Quellen sind enthalten.
- Der sichtbare Kurzbestand ist eine lesbare redaktionelle Erstfassung und
  noch kein fachlich freigegebener 150–200-Wort-Artikelbestand.
- Vorbereitete Kurzbegriffe erzeugen KEINE 42 dünnen Einzelartikel-URLs;
  die Glossarübersicht bleibt NOINDEX, bis die Redaktion ausführliche
  WordPress-Glossarbegriffe ausdrücklich geprüft und freigegeben hat.
- Redaktionsseitig veröffentlichte WordPress-Glossarbegriffe ersetzen eine
  gleichnamige Kurzdefinition automatisch, ohne doppelte A–Z-Einträge.
- Das bestehende Glossar-Import-/Prüfbedarf-Modul bleibt unangetastet.
- Keine automatischen WordPress-Publikationen, keine Kategorieänderungen,
  keine Cronjobs, keine Plugin-Vermehrung. Hauptnavigation, Mobilheader,
  Breadcrumbs, Hauptwelttexte, Bilder und SEO-Kategorieverwaltung unverändert.
- Inhaltliche Kurzdefinitionen in data/glossary-quickreference.json. Eigentliche
  redaktionelle Pflege weiterhin über das zentrale Wissensdatenbank-Glossarbüro.
- WordPress-Liveabnahme (URL /glossar/, Filter, WP-Drafts) noch offen.

0.1.15: Central breadcrumb spacing for hub, article and both glossary views; six world editorial titles and two topical subheads each use natural world keywords; 12 borderless, wider framed source images; other content and mobile logo unchanged. World texts remain editorial WIP pending specialist review.


0.1.16: Glossar A–Z als kompakte Welt-Icon-Karten; quellenbezogene Belegfelder bleiben intern gespeichert, sind nicht mehr im öffentlichen Glossarraster sichtbar. Redundante Texte der Glossarseite entfernt. Eine eigene kanonische Glossarbegriff-Seite erhält einen Kartenlink erst nach unabhängiger Fachprüfung und Veröffentlichung gemäß dem redaktionellen Plan; keine erfundenen oder massenhaft dünnen Seiten. Magazin und Dienstleister sind als zentrale Footerlinks mittig platziert. Die sechs Kategorie-Langtexte, sämtliche Fotos, das Mobil-Logo, die Navigation und die zentrale Breadcrumb-Regel unverändert.
0.1.16 Technik-Bildkorrektur: die beiden vormals unscharfen, viel zu eng beschnittenen Technikfotos ersetzt durch weite, klare Gebäude-/Haustechnik-Szenen. Ruhiges cremefarbenes Hintergrundband für Bild und Bildunterschrift wiederhergestellt, ohne Rahmen. Bestehende Textabschnitte und sämtliche manuellen Welt-Texte unverändert.

0.1.17: Pferde-Atelier knowledge contract reused (no content/design); server-side 9-card pagination; clickable read-only noindex term previews before editorial approval; centered filters and A-Z; removed per-page Magazine/Dienstleister shortcut row. No automated WordPress term creation.

0.1.18: 409 individually authored, node-bound upper category introductions for 31 areas, 93 subareas and 285 CORE leaves, based ONLY on the category text rules audited in Pferde Atelier 1.50.560. Uses current WP category map read-only. Manually written page overrides, page excerpts and term descriptions retain precedence; no WordPress writes, no modified layouts/assets. The six approved world-bottom texts and glossary remain byte-identical.


Version 0.1.21: Navigationspfade aus dem realen HTML-Ausgabeweg des Designplugins 0.1.19 korrigiert: C22-Kindseiten statt R3-Vorwaertslinks in den 36 Bereichen; identische V99/C22-Areas in UI dedupliziert; Mega 5 Areas/4 Themes; Kategorie-Endpunkt zeigt keine Geschwister mehr. Keine WP-DB-Migration, alle historischen URLs erreichbar.

0.1.22: Complete multi-row megamenu; conditional Alle Themen.
0.1.23: Six consistent hero world layouts, dynamic world subcategories and editorial links; independent automated banner tile and sellable sponsor block. Empty slots admin-only. No category writes.
\n0.1.25: Six individual high-resolution panoramic scene images, category-specific direct protective hero text, readable light/dark overlay, different category tile photos, flexible banner gap and genuine magazine-link within editorial section. All existing IDs/URLs/long texts protected.\n
0.1.26 (17.10.2026): Endkontrolle erste Kategorien-Ebene. Pro Welt jeweils eindeutige thematisch zugeordnete Bilder, 2px Ecken, immer echte weiterführende Themenkarten / Magazin plus veröffentlichte Artikel, keine blauen frei schwebenden Magazin/Dienstleister-Links. Leere Werbung ausschließlich Admin. 0.1.26 Cacheversion. Aktivierung publiziert keine Demobeiträge. Keine WP-Kategorie-Schreiboperationen. Lokal geprüft; WP-Live-Abnahme weiterhin offen.

0.1.63: Alle sieben Hauptwelten jetzt heller Hero-Verlauf wie Heizung & Temperatur. R3-Themenseiten – inkl. 265 Schutzthemen/46 Versicherungen – mit originalem 260/230px R2-Panoramaformat und Titel/Claim im Foto; alle Bilder exakt unverändert. Alte Magazin/Dienstleister-Doppelleiste wird auch auf R3 per bestehendem Cleaner entfernt; keine Änderung an Kategorie-IDs, Inhalten oder R2-Vorlagen. QA: echte Rendererprobe R3 Schutz/Versicherung, Headless 390/1024/1440; 0/0 Rand und Bar, Legitimlinks bleiben.
