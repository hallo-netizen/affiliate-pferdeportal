/* Deprecated in 0.1.148. HivePress handles block placement in PHP; no DOM movement. */
