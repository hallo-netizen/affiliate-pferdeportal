<?php
/** Editorial cosmetic permalinks only. Original WP page IDs, term IDs and native slugs remain unchanged. */
if(!defined('ABSPATH'))exit;
function hbdp_mag_clean_alias($node){
 if(!is_array($node)||($node['pillar']??'')!=='editorial'||!in_array(($node['type']??''),array('page','journal_cat'),true)||empty($node['wp_id']))return '';
 if(in_array((string)($node['id']??''),array('editorial:hub','editorial:glossar'),true))return '';
 $original=(string)($node['slug']??'');
 if(strpos($original,'magazin-')===0)$short=substr($original,8);
 elseif(strpos($original,'mag-')===0)$short=substr($original,4);
 else return '';
 if(!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/D',$short))return '';
 if(in_array($short,array('magazin','glossar','schutzbereiche','dienstleister','wp-admin'),true))return '';
 return $short;
}
function hbdp_mag_alias_index(){
 static $map=null;if($map!==null)return $map;
 $map=array();
 foreach(hbdp_all_nodes() as $n){
  $short=hbdp_mag_clean_alias($n);if($short==='')continue;
  if(isset($map[$short])){$map[$short]=false;continue;}
  $map[$short]=$n;
 }
 // Never impersonate a physical non-editorial node's slug.
 foreach(hbdp_all_nodes() as $n){
  if(($n['pillar']??'')==='editorial')continue;
  $slug=(string)($n['slug']??'');if(isset($map[$slug]))$map[$slug]=false;
 }
 return $map;
}
function hbdp_mag_alias_usable($node){
 $alias=hbdp_mag_clean_alias($node);if($alias==='')return '';
 $n=hbdp_mag_alias_index()[$alias]??null;
 if(!is_array($n)||($n['id']??'')!==($node['id']??''))return '';
 // Respect real WP page slugs to avoid hijacking unrelated existing pages.
 if(function_exists('get_page_by_path')){
  $existing=get_page_by_path($alias,OBJECT,'page');
  if($existing && (int)$existing->ID!==(int)$node['wp_id'])return '';
 }
 return $alias;
}
function hbdp_mag_alias_url($node){
 $alias=hbdp_mag_alias_usable($node);return $alias!==''?home_url('/'.$alias.'/'):'';
}
function hbdp_mag_alias_path(){
 $path=trim((string)parse_url((string)($_SERVER['REQUEST_URI']??''),PHP_URL_PATH),'/');
 $base=trim((string)parse_url(home_url('/'),PHP_URL_PATH),'/');
 if($base!==''){
  if(strpos($path,$base.'/')!==0)return '';
  $path=substr($path,strlen($base)+1);
 }
 return $path;
}
function hbdp_mag_alias_request_node(){
 $path=hbdp_mag_alias_path();if($path===''||strpos($path,'/')!==false)return null;
 $node=hbdp_mag_alias_index()[$path]??null;
 return is_array($node)&&hbdp_mag_alias_usable($node)===$path?$node:null;
}
// WordPress core resolves the existing exact page/term object, not a second virtual entity.
add_action('parse_request',static function($wp){
 if(is_admin())return;
 $node=hbdp_mag_alias_request_node();if(!$node)return;
 if(($node['type']??'')==='page')$wp->query_vars=array('page_id'=>(int)$node['wp_id']);
 else $wp->query_vars=array('taxonomy'=>'journal_cat','term'=>(string)$node['slug']);
},1);
add_filter('page_link',static function($link,$post_id){
 foreach(hbdp_all_nodes() as $n)if(($n['pillar']??'')==='editorial'&&($n['type']??'')==='page'&&(int)($n['wp_id']??0)===(int)$post_id){
  $alias=hbdp_mag_alias_url($n);return $alias!==''?$alias:$link;
 }
 return $link;
},15,2);
add_filter('term_link',static function($link,$term,$taxonomy){
 if($taxonomy!=='journal_cat'||!is_object($term))return $link;
 foreach(hbdp_all_nodes() as $n)if(($n['pillar']??'')==='editorial'&&($n['type']??'')==='journal_cat'&&(int)($n['wp_id']??0)===(int)$term->term_id){
  $alias=hbdp_mag_alias_url($n);return $alias!==''?$alias:$link;
 }
 return $link;
},15,3);
// Suppress canonical rewrites only for our explicitly recognized short aliases.
add_filter('redirect_canonical',static function($redirect){return hbdp_mag_alias_request_node()?false:$redirect;},10,1);
// Legacy native addresses continue to resolve, then forward to the same physical object.
add_action('template_redirect',static function(){
 if(is_admin()||is_preview()||is_feed()||!is_main_query())return;
 $section=hbdp_for_query();$node=is_string($section)?hbdp_node($section):null;
 if(!$node||($node['pillar']??'')!=='editorial')return;
 $url=hbdp_mag_alias_url($node);if($url==='')return;
 if(hbdp_mag_alias_path()===hbdp_mag_clean_alias($node))return;
 // Keep query-string routes (admin-preview, search, pagination) unchanged.
 if(!empty($_GET))return;
 wp_safe_redirect($url,302);exit; // reversible until verified on the live host; then 301.
},2);
