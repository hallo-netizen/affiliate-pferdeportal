<?php
/** Read-only editorial hub and term rendering. Uses the one canonical WP tree. */
if(!defined('ABSPATH'))exit;
function hbdp_magazine_specs(){
 static $data=null;
 if($data!==null)return $data;
 $raw=is_readable(HBDP_ROOT.'data/magazine-hubs.json')?json_decode((string)file_get_contents(HBDP_ROOT.'data/magazine-hubs.json'),true):array();
 $data=is_array($raw['entries']??null)?$raw['entries']:array();return $data;
}
function hbdp_magazine_photo($node){
 $spec=hbdp_magazine_specs();$id=(string)($node['id']??'');
 if(isset($spec[$id]['photo']))$img=$spec[$id]['photo'];
 else{
  $name=function_exists('mb_strtolower')?mb_strtolower((string)($node['name']??''),'UTF-8'):strtolower((string)($node['name']??''));
  $map=array(
   '/keller|feucht|rückstau|altbau/iu'=>'scene-basement.webp',
   '/garage|carport|werkstatt|hobbyraum|nebenraum|lager|dachboden/iu'=>'scene-garage.webp',
   '/garten|terrasse|balkon|pool|teich|gewächshaus|schreber|zufahrt|einfahrt/iu'=>'scene-garden.webp',
   '/wohnmobil|camper|wohnwagen|kastenwagen|camping|stellplatz|reise/iu'=>'scene-camper.webp',
   '/boot|trailer|liegeplatz|steg|marina|paddel/iu'=>'scene-boat.webp',
   '/fahrrad|fahrzeug|motorrad|e-bike|auto|anhänger/iu'=>'new-vehicle.webp',
   '/verein|sport|club|platz|gerätehaus|reitanlage/iu'=>'scene-playground.webp',
   '/betrieb|salon|friseur|praxis|atelier|laden|kiosk|gaststätte/iu'=>'scene-shop.webp',
   '/schaden|fall|erfahrung|wasser/iu'=>'magazin-wasser.webp',
   '/saison|frost|winter|wetter|sturm|klima|hitze/iu'=>'scene-weather.webp',
   '/warn|aktuell|meldung|sicherheits/iu'=>'magazin-einbruch.webp',
   '/versicherung|recht|haftung|haftpflicht/iu'=>'insurance-rechtsschutzversicherung.webp',
   '/technik|elekt|strom|sensor|warnsystem|smart/iu'=>'scene-tech.webp',
   '/abwesenheit|leerstand|ferien/iu'=>'scene-winter.webp',
   '/organisation|planung|checkliste|praxis|vorbereitung/iu'=>'scene-garage.webp',
   '/grundlagen|wissen|entscheidung|hintergrund/iu'=>'topic-smart-home-zentrale.webp',
  );
  $img='';foreach($map as $pattern=>$candidate){if(preg_match($pattern,$name)){$img=$candidate;break;}}
  if($img===''){
   $parent=hbdp_node((string)($node['parent']??''));
   $img=$parent?hbdp_magazine_photo($parent):'magazin-hero.webp';
  }
 }
 // Fail closed rather than showing a broken or remote image.
 return is_string($img)&&is_readable(HBDP_ROOT.'assets/'.$img)?$img:'';
}
function hbdp_magazine_photo_html($node,$class,$priority=false){
 $img=hbdp_magazine_photo($node);
 return $img!==''?'<img class="'.esc_attr($class).'" src="'.esc_url(HBDP_URL.'assets/'.$img).'" alt="" decoding="async" '.($priority?'fetchpriority="high"':'loading="lazy"').'>':'';
}
function hbdp_magazine_nodes_for($node){
 $children=hbdp_canonical_children((string)$node['id']);
 $out=array();foreach($children as $child){if(($child['pillar']??'')!=='editorial'||($child['id']??'')==='editorial:glossar')continue;$url=hbdp_nav_url($child);if($url!=='')$out[]=$child;}
 return $out;
}
function hbdp_magazine_card($node,$description=''){
 $link=hbdp_nav_url($node);if($link==='')return;
 echo '<a class="hbdp-magazine-card" href="'.esc_url($link).'">';
 echo hbdp_magazine_photo_html($node,'hbdp-magazine-card-photo');
 echo '<span class="hbdp-magazine-card-body"><strong>'.esc_html((string)$node['name']).'</strong>';
 if($description!=='')echo '<span>'.esc_html($description).'</span>';
 echo '<small>Entdecken <span aria-hidden="true">→</span></small></span></a>';
}
/** Magazine glossary uses the existing public /glossar/ route, no duplicate page. */
function hbdp_magazine_glossary_card(){
 if(!function_exists('hbdp_glossary_url'))return;
 $link=hbdp_glossary_url();if(!is_string($link)||$link==='')return;
 echo '<a class="hbdp-magazine-card hbdp-magazine-glossary-card" href="'.esc_url($link).'">';
 echo '<span class="hbdp-magazine-glossary-picture" aria-hidden="true"><span>A–Z</span><small>Begriffe & Wissen</small></span>';
 echo '<span class="hbdp-magazine-card-body"><strong>Sicherheitsglossar A–Z</strong><span>Begriffe und Fachausdrücke verständlich nachschlagen.</span><small>Entdecken <span aria-hidden="true">→</span></small></span></a>';
}
function hbdp_magazine_intro_for($node){
 $spec=hbdp_magazine_specs()[(string)$node['id']]??null;
 if(is_array($spec))return $spec;
 $parent=hbdp_node((string)($node['parent']??''));
 $parentname=(string)($parent['name']??'Magazin');$title=(string)$node['name'];
 $description='';
 if(($node['type']??'')==='journal_cat' && !empty($node['wp_id'])){
  $term=get_term((int)$node['wp_id'],'journal_cat');
  if($term && !is_wp_error($term))$description=trim(wp_strip_all_tags((string)$term->description));
 }
 return array('title'=>$title,'photo'=>hbdp_magazine_photo($node),'claim'=>'Orientierung und Hintergründe im Magazin',
 'lead'=>$description!==''?$description:'Im Magazinbereich „'.$title.'“ finden Sie die dazugehörigen Themen im Zusammenhang mit „'.$parentname.'“. Hier werden vorhandene Beiträge und weiterführende redaktionelle Inhalte gebündelt, ohne eine zweite Schutzkategorienstruktur zu erzeugen.',
 'more'=>array(
 'Diese Magazinrubrik ordnet Themen nach Alltag, Lebenslage oder Schutzobjekt. Spezielle Produktvergleiche und technische Schutzanleitungen bleiben an den zuständigen Stellen des Portals, um inhaltliche Doppelungen zu vermeiden.',
 'Die Übersicht verlinkt ausschließlich tatsächlich angelegte Unterseiten und veröffentlichte Magazinbeiträge. Weitere Inhalte werden erst gezeigt, wenn sie redaktionell erstellt und geprüft wurden.'));
}
function hbdp_magazine_intro($entry){
 echo '<section class="hbdp-magazine-intro" aria-label="Einführung"><p class="hbdp-magazine-lead">'.esc_html((string)$entry['lead']).'</p>';
 if(!empty($entry['more'])&&is_array($entry['more'])){
  echo '<details><summary><span>Weiterlesen</span><span aria-hidden="true">⌄</span></summary><div class="hbdp-magazine-expansion">';
  foreach($entry['more'] as $paragraph)echo '<p>'.esc_html((string)$paragraph).'</p>';
  echo '</div></details>';
 }
 echo '</section>';
}
function hbdp_magazine_breadcrumb($node){
 if(function_exists('hbdp_breadcrumb'))hbdp_breadcrumb($node);
}
function hbdp_magazine_published_posts($node){
 // Published WordPress posts only. Never synthetic article/FAQ placeholders.
 if(($node['type']??'')!=='journal_cat'||empty($node['wp_id']))return;
 $posts=get_posts(array('post_type'=>'post','post_status'=>'publish','numberposts'=>6,'tax_query'=>array(array('taxonomy'=>'journal_cat','field'=>'term_id','terms'=>array((int)$node['wp_id']),'include_children'=>false)),'suppress_filters'=>false));
 if(!$posts)return;
 echo '<section class="hbdp-magazine-section"><div class="hbdp-magazine-head"><span>REDAKTION</span><h2>Veröffentlichte Beiträge</h2></div><div class="hbdp-magazine-article-grid">';
 foreach($posts as $post){$url=get_permalink($post->ID);if(!$url)continue;echo '<a class="hbdp-magazine-article" href="'.esc_url($url).'"><strong>'.esc_html(get_the_title($post)).'</strong><span>Beitrag lesen →</span></a>';}
 echo '</div></section>';
}
function hbdp_magazine_hero($node,$entry){
 echo '<div class="hbdp-magazine-hero">';
 echo hbdp_magazine_photo_html($node,'hbdp-magazine-hero-photo',true);
 echo '<div class="hbdp-magazine-hero-fade" aria-hidden="true"></div><div class="hbdp-magazine-hero-copy">';
 echo '<span>MAGAZIN · '.(($node['id']??'')==='editorial:hub'?'ÜBERSICHT':'RATGEBER').'</span><h1>'.esc_html((string)$node['name']).'</h1><p>'.esc_html((string)$entry['claim']).'</p></div></div>';
}
function hbdp_render_magazine_hub($node){
 $id=(string)$node['id'];$root=$id==='editorial:hub';$entry=hbdp_magazine_intro_for($node);
 echo '<main class="hbdp-magazine"><div class="hbdp-magazine-frame">';
 hbdp_magazine_breadcrumb($node);hbdp_magazine_hero($node,$entry);hbdp_magazine_intro($entry);
 if($root){
  // Front-end entry: only pre-existing magazine sections. No fake articles or FAQs.
  echo '<section class="hbdp-magazine-section"><div class="hbdp-magazine-head"><span>DER EINSTIEG NACH IHRER SITUATION</span><h2>Der Schutzkompass</h2><p>Haus, Wohnmobil, kleines Geschäft oder die nächste Reise: Wählen Sie Ihren Alltag statt einer abstrakten Gefahrenart.</p></div>';
  $url=hbdp_compass_base_url();
  if($url!=='')echo '<a class="hbdp-magazine-compass" href="'.esc_url($url).'"><img src="'.esc_url(HBDP_URL.'assets/scene-security.webp').'" alt="" loading="lazy"><span><strong>Was möchten Sie schützen?</strong><small>19 Einstiege nach Objekt und Situation mit praktischen Checklisten.</small><b>Schutzkompass öffnen →</b></span></a>';
  echo '</section>';
  $kids=hbdp_magazine_nodes_for($node);
  $curated=array('editorial:hub:schutzobjekte','editorial:hub:situationen','editorial:hub:praxis','editorial:hub:wissen','editorial:category:822a3df341dd','editorial:category:a4316326a8e1','editorial:category:606955b07896','editorial:category:99c3a3d41024','editorial:category:145cd969fcc4');
  $ids=array();foreach($kids as $c)$ids[$c['id']]=$c;
  $ordered=array();foreach($curated as $key)if(isset($ids[$key]))$ordered[]=$ids[$key];
  foreach($kids as $child)if(!in_array($child['id'],$curated,true))$ordered[]=$child;
  echo '<section class="hbdp-magazine-section"><div class="hbdp-magazine-head"><span>RUBRIKEN</span><h2>Magazinbereiche entdecken</h2><p>Hintergründe, Erfahrungen, praktische Hilfen und aktuelle Informationen – ohne Wiederholung der Hauptkategorien.</p></div><div class="hbdp-magazine-grid">';
  foreach($ordered as $i=>$child){
   hbdp_magazine_card($child, (string)(hbdp_magazine_specs()[$child['id']]['claim']??''));
   // Partner creatives use a card-sized grid slot, only when actually configured.
   if($i===2)echo hbdp_editorial_banner_markup('magazin-start-1',$id);
   if($i===6)echo hbdp_editorial_banner_markup('magazin-start-2',$id);
  }
  // The previously text-only glossary link becomes the 10th full-sized card.
  hbdp_magazine_glossary_card();
  echo '</div></section>';
 } else {
  $children=hbdp_magazine_nodes_for($node);
  if($children){
   echo '<section class="hbdp-magazine-section"><div class="hbdp-magazine-head"><span>WEITER ENTDECKEN</span><h2>Passende Unterthemen</h2><p>Wählen Sie Ihre Perspektive. Das jeweilige Vorschaubild wird auch als Hero der Zielseite verwendet.</p></div><div class="hbdp-magazine-grid">';
   foreach($children as $i=>$child){hbdp_magazine_card($child, (string)(hbdp_magazine_specs()[$child['id']]['claim']??''));if($i===2){echo '</div>';echo hbdp_editorial_banner_markup('magazin-detail-1',$id);echo '<div class="hbdp-magazine-grid">';}}
   echo '</div></section>';
   // A 2nd partner placement only when the category has enough navigational content.
   if(count($children)>=6)echo hbdp_editorial_banner_markup('magazin-detail-2',$id);
  }else{
   echo hbdp_editorial_banner_markup('magazin-detail-1',$id);
  }
  hbdp_magazine_published_posts($node);
  if($id==='editorial:hub:schutzobjekte' && function_exists('hbdp_compass_base_url')){
   echo '<p class="hbdp-magazine-footlink"><a href="'.esc_url(hbdp_compass_base_url()).'">Zum interaktiven Schutzkompass →</a></p>';
  }
 }
 echo '</div></main>';
}
