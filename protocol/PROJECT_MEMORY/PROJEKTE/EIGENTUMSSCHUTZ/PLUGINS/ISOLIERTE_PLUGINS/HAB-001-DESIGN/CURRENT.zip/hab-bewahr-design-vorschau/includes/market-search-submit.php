<?php
/** Only the Anzeigenmarkt gets listing-only live search. HivePress owns real submission. */
if (!defined('ABSPATH')) exit;

function hbdp_market_ajax_phrase($raw) {
    if (!is_scalar($raw)) return '';
    $text = trim(sanitize_text_field(wp_unslash((string)$raw)));
    return function_exists('mb_substr') ? mb_substr($text, 0, 80, 'UTF-8') : substr($text, 0, 80);
}
/** Always query published hp_listing only, not categories or general portal content. */
function hbdp_market_ajax_listings($raw, $limit=6) {
    $q=hbdp_market_ajax_phrase($raw);
    $length=function_exists('mb_strlen') ? mb_strlen($q,'UTF-8') : strlen($q);
    if ($length < 2 || !post_type_exists('hp_listing')) return array();
    $limit=max(1,min(6,(int)$limit));
    $found=get_posts(array(
        'post_type'=>'hp_listing', 'post_status'=>'publish', 's'=>$q,
        'numberposts'=>$limit, 'orderby'=>'relevance', 'order'=>'DESC',
        'suppress_filters'=>false, 'no_found_rows'=>true,
    ));
    $rows=array();
    foreach ((array)$found as $post) {
        if (!($post instanceof WP_Post) || $post->post_type !== 'hp_listing' || $post->post_status !== 'publish') continue;
        $url=get_permalink($post->ID);
        if (!is_string($url) || $url === '') continue;
        $rows[]=array('title'=>(string)get_the_title($post->ID),'url'=>$url);
        if (count($rows)>=$limit) break;
    }
    return $rows;
}
/** Public category matches, including currently empty categories. Never invent offers. */
function hbdp_market_category_matches($raw, $limit=12) {
    $q=hbdp_market_ajax_phrase($raw);
    $len=function_exists('mb_strlen') ? mb_strlen($q,'UTF-8') : strlen($q);
    if ($len<2 || !function_exists('taxonomy_exists') || !taxonomy_exists('hp_listing_category')) return array();
    $limit=max(1,min(24,(int)$limit));
    $terms=get_terms(array('taxonomy'=>'hp_listing_category','hide_empty'=>false,'search'=>$q,'number'=>100));
    if (is_wp_error($terms) || !is_array($terms)) return array();
    $results=array();$seen=array();
    foreach ($terms as $term) {
        if (!is_object($term) || empty($term->term_id) || empty($term->name)) continue;
        // Display name can be shortened, but matching uses the authoritative taxonomy name.
        $score=function_exists('hbdp_search_score') ? hbdp_search_score($q,$term->name) : (stripos((string)$term->name,$q)!==false?300:0);
        if ($score<1) continue;
        $url=get_term_link($term,'hp_listing_category');
        if (is_wp_error($url) || !is_string($url) || $url==='') continue;
        if (isset($seen[$url])) continue;
        $seen[$url]=true;
        $label=function_exists('hbdp_category_title_without_dashes') ? hbdp_category_title_without_dashes($term->name) : (string)$term->name;
        $results[]=array('title'=>trim((string)$label),'url'=>$url,'score'=>$score);
    }
    usort($results,static function($a,$b){$c=((int)$b['score'])<=>((int)$a['score']);return $c?:strnatcasecmp($a['title'],$b['title']);});
    return array_slice($results,0,$limit);
}
function hbdp_market_ajax_results_markup($rows,$categories=array()) {
    if (!$rows && !$categories) return '<p class="hbdp-market-suggest-empty">Keine passenden Anzeigen oder Kategorien gefunden.</p>';
    $html='';
    foreach (array('Kategorien'=>$categories,'Anzeigen'=>$rows) as $title=>$list) {
        if (!$list) continue;
        $html.='<h3 class="hbdp-market-suggest-label">'.esc_html($title).'</h3><ul class="hbdp-market-suggest-list">';
        foreach ($list as $row) {
            $html.='<li><a href="'.esc_url($row['url']).'">'.esc_html($row['title']).'<span aria-hidden="true">→</span></a></li>';
        }
        $html.='</ul>';
    }
    return $html.'<p class="hbdp-market-suggest-hint">Enter zeigt alle passenden Kategorien und Anzeigen.</p>';
}
function hbdp_market_ajax_search() {
    if (!check_ajax_referer('hbdp_market_search_v0129','nonce',false)) {
        wp_send_json_error(array('message'=>'Ungültige Anfrage'),403);return;
    }
    $q=hbdp_market_ajax_phrase($_POST['q']??'');
    $rows=hbdp_market_ajax_listings($q,6);
    $categories=hbdp_market_category_matches($q,8);
    wp_send_json_success(array('html'=>hbdp_market_ajax_results_markup($rows,$categories),'count'=>count($rows),'category_count'=>count($categories)));
}
add_action('wp_ajax_hbdp_market_search','hbdp_market_ajax_search');
add_action('wp_ajax_nopriv_hbdp_market_search','hbdp_market_ajax_search');

/** Official submission entry from HivePress, plus the verified live path.
 * The route name can be unavailable at wp_enqueue_scripts time: use the
 * incoming URL first. Never select the listing archive, category, or details.
 */
function hbdp_market_is_submit_route() {
    if (is_admin() || is_feed() || is_embed() || !function_exists('hivepress')) return false;
    $requested=trim(rawurldecode((string)parse_url((string)($_SERVER['REQUEST_URI']??''),PHP_URL_PATH)),'/');
    $submit_url=hbdp_market_hivepress_url('listing_submit_page');
    $base=trim(rawurldecode((string)parse_url($submit_url,PHP_URL_PATH)),'/');
    // '/submit-listing/category/' was verified on the actual Hab & Bewahr site.
    if ($base==='') $base='submit-listing';
    // The real request path is authoritative. A stale/nonmatching HivePress route
    // must never decorate a listings archive or another portal page.
    if ($requested!=='' && $base!=='') return $requested===$base || strpos($requested,$base.'/')===0;
    $route=hbdp_market_hivepress_route_name();
    return in_array($route,array(
        'listing_submit_page','listing_submit_profile_page','listing_submit_category_page',
        'listing_submit_details_page','listing_submit_complete_page',
    ),true);
}

/** The portal's unchanged real header/navigation on HivePress submission routes.
 * The original menu and search functions are called exactly as on templates/site.php.
 * Do not render the hero or banner outside HivePress's content flow.
 */
function hbdp_market_submit_brand_shell() {
    if (!hbdp_market_is_submit_route()) return;
    require_once HBDP_ROOT.'includes/navigation-shared.php';
    $worlds=array_values(array_filter(hbdp_all_nodes(),static function($node){return strpos((string)($node['id']??''),'core:world:')===0;}));
    $order=array_flip(array('core:world:einbruch-und-diebstahl','core:world:vandalismus-und-zerstorung','core:world:wasser-und-feuchtigkeit','core:world:feuer-und-gase','core:world:wetter-und-naturgefahren','core:world:technik-und-ausfalle','core:world:insurance'));
    usort($worlds,static function($a,$b)use($order){return ($order[$a['id']]??99)<=>($order[$b['id']]??99);});
    echo '<div class="hbdp hbdp-market-submit-site-header" id="hbdp-submit-site-header">';
    HB_Design_Startseite_View::header(hbdp_startseite_urls(),false);
    hbdp_main_navigation($worlds,null);
    echo '</div>';
}
add_action('wp_body_open','hbdp_market_submit_brand_shell',20);

/** Exact market hero, inserted in the native HivePress content column. */
function hbdp_market_submit_intro_html() {
    $market=hbdp_market_landing_url();
    $html='<section id="hbdp-submit-intro" class="hbdp hbdp-market-submit-intro-wrap" aria-label="Anzeige aufgeben">';
    $html.='<div class="hbdp-frame hbdp-market"><nav class="hbdp-crumb" aria-label="Brotkrumennavigation">';
    $html.='<a href="'.esc_url(home_url('/')).'">Startseite</a><span aria-hidden="true">/</span>';
    if($market!=='')$html.='<a href="'.esc_url($market).'">Anzeigenmarkt</a><span aria-hidden="true">/</span>';
    $html.='<span aria-current="page">Anzeige aufgeben</span></nav>';
    $html.='<section class="hbdp-market-hero hbdp-market-submit-hero" aria-label="Anzeige aufgeben">';
    $html.='<div class="hbdp-market-hero-copy"><span class="hbdp-eyebrow">DIENSTLEISTER UND ANZEIGEN</span>';
    $html.='<h1>Anzeige aufgeben</h1><p>Wählen Sie den passenden Bereich und erstellen Sie Ihre Anzeige.</p>';
    // Same existing CTA layout as the Anzeigenmarkt start page. Do not change the header or footer.
    $prices=function_exists('hbdp_footer_page_url')?hbdp_footer_page_url('preise'):'';
    $terms=function_exists('hbdp_footer_page_url')?hbdp_footer_page_url('werb-anzeigebedingungen'):'';
    $html.='<div class="hbdp-market-actions">';
    if($prices!=='') $html.='<a class="hbdp-market-primary" href="'.esc_url($prices).'">Preise</a>';
    if($terms!=='') $html.='<a class="hbdp-market-secondary" href="'.esc_url($terms).'">Werbebedingungen</a>';
    $html.='</div></div>';
    $html.='<div class="hbdp-market-hero-photo"><img src="'.esc_url(HBDP_URL.'assets/new-shop.webp').'" width="1619" height="971" alt="Kleiner Betrieb als Beispiel für den Anzeigenmarkt" decoding="async" fetchpriority="high"></div>';
    $html.='</section></div></section>';
    return $html;
}
/** Same OWN advertising banner design as the existing Anzeigenmarkt.
 * Links use the actual published WP pages; never guess their URLs.
 * Existing paid/affiliate creative in the original lower slot is preserved.
 */
function hbdp_market_submit_house_banner_html($position) {
    $lower=($position==='lower');
    $id=$lower?'hbdp-submit-banner':'hbdp-submit-banner-top';
    $class=$lower?'hbdp-market-submit-banner':'hbdp-market-submit-upper-banner';
    // Upper position is a genuine free/assignable banner slot, NOT a house ad.
    // Partners can be assigned using the existing Banner settings/affiliate bridge.
    if (!$lower) {
        $creative=function_exists('hbdp_editorial_banner_markup')
            ? hbdp_editorial_banner_markup('market-submit-1','directory:hub') : '';
        if ($creative!=='' && strpos($creative,'hbdp-editorial-ad-empty')===false) {
            return '<aside id="'.esc_attr($id).'" class="'.esc_attr($class).'" aria-label="Werbung"><div class="hbdp-market-between-banner">'.$creative.'</div></aside>';
        }
        return '<aside id="'.esc_attr($id).'" class="'.esc_attr($class).'" aria-label="Freier Bannerplatz"><div class="hbdp-market-between-banner hbdp-market-empty-submit-slot" aria-hidden="true"></div></aside>';
    }
    if ($lower && function_exists('hbdp_market_real_banner')) {
        $real=hbdp_market_real_banner('market-start-2');
        if ($real!=='' && strpos($real,'hbdp-editorial-ad-empty')===false) {
            return '<aside id="'.esc_attr($id).'" class="'.esc_attr($class).'" aria-label="Werbung">'. $real . '</aside>';
        }
    }
    return '<aside id="'.esc_attr($id).'" class="'.esc_attr($class).'" aria-label="Werbemöglichkeiten">'.hbdp_house_ad_premium_html().'</aside>';
}
function hbdp_market_submit_banner_html() {
    return hbdp_market_submit_house_banner_html('lower');
}
/** Exactly one rendering path. No top-of-body hero, reparenting, or duplicate header.
 * The three blocks live in the same NATIVE HivePress page_content as the form.
 */
add_filter('hivepress/v1/templates/listing_submit_page/blocks', static function($blocks) {
    if (!hbdp_market_is_submit_route() || !is_array($blocks)) return $blocks;
    if (!isset($blocks['page_container']['blocks']['page_content']['blocks']) ||
        !is_array($blocks['page_container']['blocks']['page_content']['blocks'])) return $blocks;
    $content = &$blocks['page_container']['blocks']['page_content']['blocks'];
    $content['hbdp_submit_intro'] = array(
        'type' => 'content', 'content' => hbdp_market_submit_intro_html(), '_order' => -100,
    );
    $content['hbdp_submit_banner_top'] = array(
        'type' => 'content', 'content' => hbdp_market_submit_house_banner_html('upper'), '_order' => -90,
    );
    $content['hbdp_submit_banner'] = array(
        'type' => 'content', 'content' => hbdp_market_submit_house_banner_html('lower'), '_order' => 1000,
    );
    unset($content);
    return $blocks;
}, 1000);

add_filter('body_class',static function($classes) {
    if (hbdp_market_is_submit_route()) { $classes[]='hbdp-market-submit-route'; $classes[]='hbdp-body'; }
    return $classes;
});

add_action('wp_enqueue_scripts',static function() {
    if (function_exists('hbdp_for_query') && in_array(hbdp_for_query(),array('market:root','directory:hub'),true)) {
        wp_enqueue_style('hbdp-market-live-search',HBDP_URL.'assets/market-live.css',array('hbdp-market'),'0.1.132');
        wp_enqueue_script('hbdp-market-live',HBDP_URL.'assets/market-live.js',array(),'0.1.132',true);
        wp_localize_script('hbdp-market-live','hbdpMarketAjax',array(
            'endpoint'=>admin_url('admin-ajax.php'),
            'nonce'=>wp_create_nonce('hbdp_market_search_v0129'),
        ));
    }
},110);


/** Enqueue actual dependencies for native HivePress pages; the main site enqueuer
 * intentionally returns early on these routes. Without hbdp-site the dependent
 * CSS was never printed, producing the giant unstyled protection arc.
 */
add_action('wp_enqueue_scripts',static function() {
    if (!hbdp_market_is_submit_route()) return;
    wp_enqueue_style('hbdp-site',HBDP_URL.'assets/style.css',array(),'0.1.134');
    wp_enqueue_style('hbdp-header',HBDP_URL.'assets/header.css',array('hbdp-site'),'0.1.134');
    wp_enqueue_style('hbdp-market-base-submit',HBDP_URL.'assets/market.css',array('hbdp-header'),'0.1.134');
    wp_enqueue_style('hbdp-market-submit',HBDP_URL.'assets/market-submit.css',array('hbdp-market-base-submit'),'0.1.156');
    wp_enqueue_style('hbdp-main-search',HBDP_URL.'assets/global-search.css',array('hbdp-header'),'0.1.134');
    wp_enqueue_script('hbdp-main-search',HBDP_URL.'assets/global-search.js',array(),'0.1.134',true);
    wp_localize_script('hbdp-main-search','hbdpSearchConfig',array(
        'endpoint'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('hbdp_main_search_v0105'),
    ));
    wp_enqueue_script('hbdp-nav',HBDP_URL.'assets/nav.js',array(),'0.1.134',true);
    wp_enqueue_script('hbdp-submit-clearance',HBDP_URL.'assets/market-submit-clearance.js',array(),'0.1.156',true);
},999);
