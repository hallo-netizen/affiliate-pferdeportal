<?php
/**
 * Hab & Bewahr: ausschliesslich Anzeige-Namen fuer vorhandene Kategorien.
 * KISS: eine zentrale Alias-Liste; niemals WordPress-Namen, IDs, Slugs,
 * Snapshot, Suchindizes, Beitragszuordnungen oder gespeicherte Artikel aendern.
 */
if (!defined('ABSPATH')) exit;
/** Display ONLY: strip dash glyphs from the category label, never from IDs, URLs or stored WordPress names. */
function hbdp_category_title_without_dashes($label) {
    $label = (string)$label;
    $out = preg_replace('/[\x{002D}\x{00AD}\x{2010}-\x{2015}\x{2212}]+/u', ' ', $label);
    if ($out === null) return $label;
    return trim(preg_replace('/\s+/u', ' ', $out));
}
function hbdp_display_category_name($node) {
    if (!is_array($node)) return '';
    $name = (string)($node['name'] ?? '');
    if ($name === '') return '';
    $id = (string)($node['id'] ?? '');
    // Aliases are still looked up using the unchanged canonical WordPress name.
    static $aliases = null;
    if ($aliases === null) {
        $path = HBDP_ROOT . 'data/category-title-aliases.json';
        $json = is_readable($path) ? json_decode(file_get_contents($path), true) : array();
        $aliases = is_array($json) ? $json : array();
    }
    $title = (strpos($id, 'core:') === 0 || strpos($id, 'directory:') === 0)
        ? (string)($aliases[$name] ?? $name)
        : $name;
    // Also catches original names without aliases, C2.2 nodes, and editorial categories.
    return hbdp_category_title_without_dashes($title);
}
