<?php
if(!defined('ABSPATH'))exit;
$section=hbdp_for_query();$n=hbdp_node($section);$all=hbdp_all_nodes();
function hbdp_display_card($node,$photo=''){
    $is_term=(($node['type']??'')==='category');
    $insurance=hbdp_is_insurance_r3($node);
    $img=($is_term ? '' : ($photo ?: ($insurance ? hbdp_insurance_topic_photo($node) : hbdp_pick_photo($node['name']))));
    $url=hbdp_nav_url($node);if($url==='')return;
    echo '<a class="hbdp-tile" href="'.esc_url($url).'">';
    if($is_term){
        // Below the topic-picture level: pictograms, never fake repeated photos.
        echo '<span class="hbdp-tile-img hbdp-tile-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3h7l4 4v14H7z"/><path d="M14 3v5h4M10 12h5M10 16h5"/></svg></span>';
    }else{
        echo '<span class="hbdp-tile-img">';
        if($img!=='')echo '<img alt="" loading="lazy" decoding="async" src="'.esc_url(HBDP_URL.'assets/'.$img).'">';
        echo '</span>';
    }
    echo '<span class="hbdp-tile-body"><strong>'.esc_html(hbdp_compass_display_name($node)).'</strong><span>Bereich ansehen <span aria-hidden="true">→</span></span></span></a>';
}
function hbdp_pick_photo($label){
    $s=strtolower($label);
    if(preg_match('/graffiti|vandal|glas|fassade/iu',$s))return 'graffiti.jpg';
    if(preg_match('/feucht|wasser|keller|rohr|hochwasser|rückstau/iu',$s))return 'wasser.jpg';
    if(preg_match('/akku|strom|feuer|brand|technik|heizung/iu',$s))return 'akku.jpg';
    return 'einbruch.jpg';
}
function hbdp_demo_articles($section_id='home'){
    $shown=0;
    foreach(hbdp_demo_spec() as $s){
        if($section_id!=='home' && $section_id!=='core:hub'){
            $cursor=hbdp_node($s['category']); $found=false; $seen=array();
            while($cursor && !isset($seen[$cursor['id']])){
                $seen[$cursor['id']]=true;
                if($cursor['id']===$section_id){$found=true;break;}
                $cursor=hbdp_node($cursor['parent']);
            }
            if(!$found)continue;
        }
        $shown++;
        $posts=get_posts(array('post_type'=>'post','post_status'=>'publish','meta_key'=>'_hbdp_demo_key','meta_value'=>$s['key'],'posts_per_page'=>1));
        $url=$posts?get_permalink($posts[0]->ID):'';
        echo '<article class="hbdp-story"><div class="hbdp-story-image"><img src="'.esc_url(HBDP_URL.'assets/'.$s['image']).'" alt="Symbolisches Beispielbild" loading="lazy"></div><div class="hbdp-story-content"><span class="hbdp-kicker">TESTARTIKEL · VORSCHAU</span><h3>'.esc_html($s['title']).'</h3><p>'.esc_html($s['intro']).'</p>'.($url?'<a href="'.esc_url($url).'">Artikelansicht ansehen →</a>':'<span>Beispiel der Artikelkarte</span>').'</div></article>';
    }
    return $shown;
}
function hbdp_breadcrumb($node){
    $crumb=array();$seen=array();
    while($node && count($crumb)<8 && !isset($seen[$node['id']])){$seen[$node['id']]=1;array_unshift($crumb,$node);$node=hbdp_node($node['parent']);}
    echo '<div class="hbdp-crumb"><a href="'.esc_url(home_url('/')).'">Startseite</a>';
    // Editorial hierarchy only for Schutzbereiche INDEX, analogous to Glossar.
    // Do not move WP pages, change category parents or rewrite any other breadcrumbs.
    if(count($crumb)===1 && ($crumb[0]['id']??'')==='core:hub'){
        $magazine=function_exists('hbdp_glossary_magazine_url')?hbdp_glossary_magazine_url():'';
        echo '<span aria-hidden="true">/</span>';
        if($magazine!=='')echo '<a href="'.esc_url($magazine).'">Magazin</a>';
        else echo '<span>Magazin</span>';
    }
    foreach($crumb as $i=>$c)echo '<span aria-hidden="true">/</span>'.($i===count($crumb)-1?'<span aria-current="page">'.esc_html(hbdp_compass_display_name($c)).'</span>':'<a href="'.esc_url(hbdp_url($c)).'">'.esc_html(hbdp_compass_display_name($c)).'</a>');
    echo '</div>';
}
require_once HBDP_ROOT.'includes/navigation-shared.php';

$worlds=array_values(array_filter($all,function($x){return strpos($x['id'],'core:world:')===0;}));
// Visual order stays consistent while names, links and parents come from the active central snapshot.
$world_order=array_flip(array('core:world:einbruch-und-diebstahl','core:world:vandalismus-und-zerstorung','core:world:wasser-und-feuchtigkeit','core:world:feuer-und-gase','core:world:wetter-und-naturgefahren','core:world:technik-und-ausfalle','core:world:insurance'));
usort($worlds, static function($a,$b) use ($world_order) {return ($world_order[$a['id']]??99)<=>($world_order[$b['id']]??99);});
?><!DOCTYPE html><html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset');?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php if ($section !== 'article' || !defined('WPSEO_VERSION')): ?><title><?php
  $hbdp_page_title = in_array($section,array('market:root','market:search','directory:hub'),true) ? 'Anzeigenmarkt' : ($section==='service:faq' ? 'Häufige Fragen' : ($section==='search-results' ? 'Suchergebnisse' : ($section==='home' ? 'Hab & Bewahr' : (
      $section==='glossary' ? 'Sicherheitsglossar' : (
      $section==='glossary-preview' ? (string)(hbdp_glossary_preview_record()['begriff']??'Glossarbegriff') : (
      $section==='glossary-term' ? ((string)get_post_meta(get_queried_object_id(),'_hbdp_seo_title',true) ?: get_the_title()) : (
      $section==='article' ? get_the_title() : ($section==='core:hub' ? (hbdp_compass_current_slug()!=='' ? hbdp_compass_catalog()[hbdp_compass_current_slug()]['title'] : 'Schutzkompass') : ($n ? hbdp_compass_display_name($n) : 'Hab & Bewahr'))
  )))))));
  echo esc_html($hbdp_page_title); ?> – Hab & Bewahr</title><?php endif; wp_head(); if($section==='service:preise') echo '<style id="hbdp-preise-critical-v120">'.hbdp_preise_critical_css_v120().'</style>'; ?></head><body class="hbdp-body<?php echo (is_string($section) && strpos($section,'service:')===0) ? ' hbdp-service-route' : ''; echo $section === 'service:preise' ? ' hbdp-preise-route' : ''; ?>"><div class="hbdp">
<?php
$hbdp_destinations = hbdp_startseite_urls();
HB_Design_Startseite_View::header($hbdp_destinations, false);
// Compact full-width mega: 6 worlds, 31 areas, 93 subareas; all leaves via hubs.
hbdp_main_navigation($worlds, $section);
?>
<?php if($section==='search-results'): ?>
<?php hbdp_render_search_results(); ?>
<?php elseif($section==='home'): ?>
<?php echo HB_Design_Startseite_View::render($hbdp_destinations, HBDP_URL.'assets/', false); ?>
<?php elseif($section==='market:search'): ?>
<?php hbdp_market_render_search_results(); ?>
<?php elseif($section==='market:root' || $section==='directory:hub'): ?>
<?php hbdp_market_render_landing(); ?>
<?php elseif($section==='core:hub'): ?>
<?php hbdp_render_schutzkompass(); ?>
<?php elseif($n && ($n['pillar']??'')==='editorial' && $section!=='editorial:glossar' && $section!=='glossary'): ?>
<?php hbdp_render_magazine_hub($n); ?>
<?php elseif($section==='glossary'): ?>
<?php hbdp_render_glossary(); ?>
<?php elseif($section==='glossary-preview'): ?>
<?php hbdp_render_glossary_preview(); ?>
<?php elseif($section==='glossary-term'): ?>
<?php hbdp_render_glossary_term(); ?>
<?php elseif($section==='service:faq'): ?>
<?php hbdp_render_faq_page(); ?>
<?php elseif(strpos((string)$section,'service:')===0): $sp=get_queried_object(); ?>
<main class="hbdp-frame hbdp-section hbdp-service"><nav class="hbdp-crumb" aria-label="Brotkrumennavigation"><a href="<?php echo esc_url(home_url('/'));?>">Startseite</a><span aria-hidden="true">/</span><span><?php echo esc_html(get_the_title($sp)); ?></span></nav><h1><?php echo esc_html(get_the_title($sp)); ?></h1><div class="hbdp-service-body"><?php if($section==='service:preise') echo '<!-- HBDP PREISE 0.1.120 -->'; echo hbdp_service_display_content($sp); ?></div></main>
<?php elseif($section==='article' && get_post_meta(get_queried_object_id(),'_hbdp_demo',true)!=='1'): ?>
<?php hbdp_render_article_page(); ?>
<?php elseif($section==='article'): $post=get_queried_object();$spec=null;foreach(hbdp_demo_spec() as $s)if($s['key']===get_post_meta($post->ID,'_hbdp_demo_key',true))$spec=$s; ?>
<main class="hbdp-frame hbdp-section hbdp-article"><div class="hbdp-crumb"><a href="<?php echo esc_url(home_url('/'));?>">Startseite</a> / <span>Testartikel</span></div><span class="hbdp-kicker">DEMO · NOINDEX · KEIN FACHARTIKEL</span><h1><?php echo esc_html(get_the_title($post));?></h1><p class="hbdp-intro"><?php echo esc_html($post->post_excerpt);?></p><img class="hbdp-article-cover" src="<?php echo esc_url(HBDP_URL.'assets/'.($spec['image']??'einbruch.jpg'));?>" alt="Symbolbild zur Layout-Vorschau"><div class="hbdp-paper"><?php echo apply_filters('the_content',$post->post_content);?><p><a href="<?php echo esc_url(hbdp_url(hbdp_node($spec['category']??'core:leaf:001')));?>">← Zur passenden Beitragskategorie</a></p></div></main>
<?php elseif($n && strpos((string)$n['id'],'core:world:')===0): hbdp_render_world_page($n); ?>
<?php elseif($n && hbdp_area_is_level2($n)): hbdp_render_area_page($n); ?>
<?php elseif($n && ($n['type']??'')==='page' && hbdp_area_is_level2(hbdp_node((string)($n['parent']??'')))): hbdp_render_detail_category_page($n); ?>
<?php elseif($n && ($n['type']??'')==='category'): hbdp_render_detail_category_page($n); ?>
<?php else: $children=$n?hbdp_children($n['id']):array(); $parent=$n?hbdp_node($n['parent']):null;
// No sibling fall-through: an article category has no subcategories, never
// render its parent's other terms as its own child links. ?>
<main class="hbdp-frame hbdp-section hbdp-hub"><?php if($n)hbdp_breadcrumb($n);?><span class="hbdp-eyebrow"><?php echo esc_html($n && $n['type']==='category'?'BEITRAGSKATEGORIE':($n && strpos($n['id'],'core:world:')===0?'THEMENWELT':'THEMENÜBERSICHT'));?></span><h1><?php echo esc_html($n?hbdp_compass_display_name($n):'Schutzbereiche');?></h1><?php $is_r3=$n && ($n['type']??'')==='page' && hbdp_area_is_level2(hbdp_node((string)($n['parent']??''))); $focus_pic=$is_r3?(hbdp_insurance_topic_photo($n) ?: hbdp_area_matching_topic_photo($n)):($n?HB_Design_Startseite_View::focus_image_for_node((string)($n['id']??'')):''); if($focus_pic!==''): ?><figure class="hbdp-focus-destination-photo"><img src="<?php echo esc_url(HBDP_URL.'assets/'.$focus_pic); ?>" alt="<?php echo esc_attr(hbdp_compass_display_name($n)); ?>" decoding="async" fetchpriority="high"></figure><?php endif; ?><?php if($n && strpos($n['id'],'core:world:')===0) hbdp_render_hub_intro($n); elseif($n) hbdp_render_category_top_text($n); ?>
<?php if($n && ($n['id']??'')==='editorial:hub' && hbdp_compass_base_url()!==''): ?>
<a class="hbdp-compass-magazine-entry" href="<?php echo esc_url(hbdp_compass_base_url()); ?>"><img src="<?php echo esc_url(HBDP_URL.'assets/scene-security.webp'); ?>" alt="" loading="lazy"><span><small>NEU IM MAGAZIN</small><strong>Schutzkompass – was möchten Sie schützen?</strong><em>Nach Haus, Garten, Wohnmobil oder Situation einsteigen statt nach Gefahrenart suchen. <b>Schutzkompass öffnen →</b></em></span></a>
<?php endif; ?>
<div class="hbdp-hub-layout"><div class="hbdp-hub-main"><?php if($children):?><h2>Kategorien & Unterbereiche</h2><div class="hbdp-grid"><?php foreach($children as $i=>$c){if($n && $n['id']===$c['id'])continue;hbdp_display_card($c);}?></div><?php else:?><p class="hbdp-endpoint">Hier endet die Kategoriennavigation. Passende Beiträge erscheinen hier, sobald sie veröffentlicht sind.</p><?php endif;?><div class="hbdp-divider"></div><div class="hbdp-section-head"><div><span class="hbdp-eyebrow">BEITRAGSVORSCHAU</span><h2>So sehen Artikelkarten aus</h2><p>Testartikel erscheinen nur dort, wo sie thematisch zugeordnet sind. Sonst bleibt ein Layoutplatzhalter.</p></div></div><div class="hbdp-stories"><?php if(!hbdp_demo_articles($n['id']??'')):?><div class="hbdp-story-placeholder">Hier erscheinen später die passenden Ratgeber zu <strong><?php echo esc_html($n?hbdp_compass_display_name($n):'diesem Bereich');?></strong>. Der Platz ist für die Layoutvorschau reserviert.</div><?php endif;?></div></div><aside class="hbdp-hub-aside"><div class="hbdp-aside-box"><span class="hbdp-eyebrow">ZUM ORIENTIEREN</span><h3>Schutz beginnt mit Wissen.</h3><p>Verständliche Themenübersichten, praktische Hinweise und hilfreiche Vergleiche.</p></div><div class="hbdp-aside-ad"><small>ANZEIGENFLÄCHE · LAYOUTPLATZHALTER</small><strong>Hier könnte deine Werbung stehen.</strong><span>Der Werbeplatz ist noch nicht verkauft und enthält keinen Werbecode.</span></div></aside></div><?php if($n && strpos($n['id'],'core:world:')===0) hbdp_render_world_bottom_text($n); ?></main>
<?php endif; ?>
<?php hbdp_footer_render(); ?></div><?php wp_footer();?></body></html>
