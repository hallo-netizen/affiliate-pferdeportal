/* Hab & Bewahr 0.1.105: one scoped Ajax header search, with native GET fallback. */
(function(){
  'use strict';
  function ready(){
    var form=document.querySelector('form[data-hbdp-global-search]');
    if(!form || !window.hbdpSearchConfig) return;
    var input=form.querySelector('input[name="s"]');
    var panel=form.querySelector('.hbdp-search-preview');
    if(!input || !panel) return;
    var timer=0, controller=null, sequence=0;
    function close(){ panel.hidden=true; input.setAttribute('aria-expanded','false'); }
    function open(){ panel.hidden=false; input.setAttribute('aria-expanded','true'); }
    function search(){
      var q=input.value.trim();
      if(q.length<2){close();return;}
      var request=++sequence;
      if(controller && typeof controller.abort==='function')controller.abort();
      controller=typeof AbortController!=='undefined' ? new AbortController() : null;
      panel.textContent='Suche läuft …';open();
      var body=new URLSearchParams({action:'hbdp_main_search',nonce:hbdpSearchConfig.nonce,q:q});
      var opts={method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()};
      if(controller) opts.signal=controller.signal;
      fetch(hbdpSearchConfig.endpoint,opts).then(function(r){if(!r.ok)throw Error('search');return r.json();}).then(function(result){
        if(request!==sequence || input.value.trim()!==q) return;
        if(!result.success || !result.data || typeof result.data.html!=='string')throw Error('format');
        panel.innerHTML=result.data.html;open();
      }).catch(function(e){
        if(e.name==='AbortError'||request!==sequence)return;
        panel.textContent='Vorschau nicht verfügbar. Mit Enter die Suchergebnisse öffnen.';open();
      });
    }
    input.addEventListener('input',function(){clearTimeout(timer);sequence++;if(controller)controller.abort();if(input.value.trim().length<2){close();return;}timer=setTimeout(search,250);});
    input.addEventListener('focus',function(){if(input.value.trim().length>=2 && panel.innerHTML!=='')open();});
    input.addEventListener('keydown',function(e){if(e.key==='Escape'){close();input.blur();}});
    document.addEventListener('click',function(e){if(!form.contains(e.target))close();});
    form.addEventListener('submit',function(){clearTimeout(timer);if(controller)controller.abort();});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready);else ready();
})();
