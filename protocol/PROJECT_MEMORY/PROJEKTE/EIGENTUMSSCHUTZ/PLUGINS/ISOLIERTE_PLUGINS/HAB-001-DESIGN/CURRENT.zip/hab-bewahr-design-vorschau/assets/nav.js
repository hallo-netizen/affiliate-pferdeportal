/* Only one expanded world. Desktop pointer hover; touch uses explicit hamburger and accordion. */
(function () {
 'use strict';
 function init() {
   // Repair WP's orphaned admin-bar top margin ONLY when the toolbar is
   // genuinely invisible. Never cover or hide a visible admin toolbar.
   function syncMobileAdminGutter() {
     if (!document.body || !document.body.classList.contains('hbdp-body')) return;
     var mobile = window.matchMedia('(max-width: 760px)').matches;
     var bar = document.getElementById('wpadminbar');
     var style = bar && window.getComputedStyle(bar);
     var rect = bar && bar.getBoundingClientRect();
     var missing = !bar || style.display === 'none' || style.visibility === 'hidden' ||
       style.opacity === '0' || !rect || rect.height < 1 || rect.bottom <= 0;
     document.documentElement.classList.toggle('hbdp-no-mobile-adminbar', mobile && missing);
   }
   syncMobileAdminGutter();
   var gutterQuery = window.matchMedia('(max-width: 760px)');
   if (gutterQuery.addEventListener) gutterQuery.addEventListener('change', syncMobileAdminGutter);
   var nav = document.querySelector('.hbdp-mainnav');
   if (!nav) return;
   var wrap = nav.closest('.hbdp-mainnav-wrap');
   var button = wrap && wrap.querySelector('.hbdp-mobile-toggle');
   var state = button && button.querySelector('.hbdp-mobile-toggle-state');
   var worlds = Array.prototype.slice.call(nav.querySelectorAll(':scope > details.hbdp-navworld'));
   var mobile = window.matchMedia('(max-width: 760px)');
   var hover = window.matchMedia('(min-width: 761px) and (hover: hover) and (pointer: fine)');
   function closeWorlds(exception) { worlds.forEach(function (item) { if (item !== exception) item.open = false; }); }
   function setOpen(value) {
     if (!wrap || !button) return;
     wrap.classList.toggle('hbdp-mobile-open', !!value);
     button.setAttribute('aria-expanded', value ? 'true' : 'false');
     button.setAttribute('aria-label', value ? 'Schutzweltenmenü schließen' : 'Schutzweltenmenü öffnen');
     if (state) state.textContent = value ? 'Menü schließen' : 'Menü öffnen';
     if (!value) closeWorlds(null);
   }
   if (wrap && button) {
     wrap.classList.add('hbdp-mobile-ready');
     button.addEventListener('click', function () { setOpen(!wrap.classList.contains('hbdp-mobile-open')); });
     if (mobile.addEventListener) mobile.addEventListener('change', function () { setOpen(false); });
     else if (mobile.addListener) mobile.addListener(function () { setOpen(false); });
   }
   worlds.forEach(function (world) {
     world.addEventListener('toggle', function () { if (world.open) closeWorlds(world); });
     var worldLink = world.querySelector('.hbdp-navworld-link');
     if (worldLink) worldLink.addEventListener('click', function(ev) { ev.stopPropagation(); });
     var summary = world.querySelector('summary');
     if (summary) summary.addEventListener('click', function (ev) {
       if (!hover.matches || ev.detail <= 0) return;
       ev.preventDefault(); closeWorlds(world); world.open = true;
     });
     world.addEventListener('pointerenter', function () { if (hover.matches) { closeWorlds(world); world.open = true; } });
     world.addEventListener('pointerleave', function () { if (hover.matches) world.open = false; });
   });
   document.addEventListener('keydown', function (ev) {
     if (ev.key !== 'Escape') return;
     closeWorlds(null);
     if (mobile.matches && wrap && wrap.classList.contains('hbdp-mobile-open')) {
       setOpen(false); button.focus();
     }
   });
   document.addEventListener('click', function (ev) {
     if (wrap && !wrap.contains(ev.target)) {
       closeWorlds(null);
       if (mobile.matches) setOpen(false);
     }
   });
   // Local A-Z glossary filter; never fetches, writes or indexes categories.
   var search = document.querySelector('[data-hbdp-glossary-search]');
   if (search) {
     var groups = Array.prototype.slice.call(document.querySelectorAll('.hbdp-glossary-letter'));
     var counter = document.querySelector('[data-hbdp-glossary-count]');
     function normalize(v) { return v.toLocaleLowerCase('de').normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
     function filter() {
       var query = normalize(search.value.trim()), count = 0;
       groups.forEach(function (group) {
         var visible = 0;
         Array.prototype.forEach.call(group.querySelectorAll('.hbdp-glossary-entry'), function (entry) {
           var match = !query || normalize(entry.textContent).indexOf(query) !== -1;
           entry.hidden = !match;
           if (match) { visible++; count++; }
         });
         group.hidden = visible === 0;
       });
       if (counter) counter.textContent = count + ' Begriffe gefunden';
     }
     search.addEventListener('input', filter);
   }
 }
 if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
 else init();
})();
