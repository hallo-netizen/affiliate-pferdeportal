<?php
/**
 * Hab & Bewahr: originaler Schutzbogen + Initialen (Favicon-Variante 3).
 * Ein zentraler Frontend-Einstieg; die WordPress-Adminoberfläche bleibt unberührt.
 */
if (!defined('ABSPATH')) { exit; }

add_action('init', static function () {
    if (!is_admin()) {
        // Verhindert konkurrierende Favicons aus der WordPress-Seitenicon-Einstellung.
        remove_action('wp_head', 'wp_site_icon', 99);
    }
}, 20);

add_action('wp_head', static function () {
    if (is_admin()) return;
    $base = HBDP_URL . 'assets/';
    echo '<link rel="icon" type="image/x-icon" href="'.esc_url($base.'favicon-hb-128.ico').'">' . "\n";
    foreach (array(16, 32, 48, 192, 512) as $size) {
        echo '<link rel="icon" type="image/png" sizes="'.$size.'x'.$size.'" href="'.esc_url($base.'favicon-hb-128-'.$size.'.png').'">' . "\n";
    }
    echo '<link rel="apple-touch-icon" sizes="180x180" href="'.esc_url($base.'favicon-hb-128-180.png').'">' . "\n";
}, 100);
