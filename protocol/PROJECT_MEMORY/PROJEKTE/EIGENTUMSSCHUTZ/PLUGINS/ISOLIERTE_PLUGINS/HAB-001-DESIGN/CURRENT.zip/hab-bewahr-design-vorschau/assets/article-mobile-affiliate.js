/* Hab & Bewahr – ein vorhandenes Produkt-/Bannerelement mobil sinnvoll in den Text verschieben.
 * Keine Duplikate, keine zweiten Anfragen, keine Drittanbieter-/Scroll-Abhängigkeit. */
(function(){
  'use strict';
  function prepare(){
    var root=document.querySelector('.hb-article-layout');
    if(!root) return;
    var sidebar=root.querySelector('.hb-article-sidebar');
    if(!sidebar) return;
    var products=sidebar.querySelector('.hb-article-ad--product, .hb-sidebar-demo-products');
    var banner=sidebar.querySelector('.hb-article-ad--banner, .hb-sidebar-demo-banner');
    var moves=[];
    [
      [products,root.querySelector('.hb-mobile-products-target')],
      [banner,root.querySelector('.hb-mobile-banner-target')]
    ].forEach(function(pair){
      var node=pair[0],target=pair[1];
      if(!node||!target||!node.parentNode) return;
      var marker=document.createComment('hbdp original affiliate position');
      node.parentNode.insertBefore(marker,node);
      moves.push({node:node,target:target,marker:marker});
    });
    if(!moves.length) return;
    var media=window.matchMedia('(max-width: 900px)');
    function apply(){
      moves.forEach(function(move){
        if(media.matches) move.target.parentNode.insertBefore(move.node,move.target);
        else move.marker.parentNode.insertBefore(move.node,move.marker.nextSibling);
      });
    }
    apply();
    if(typeof media.addEventListener==='function') media.addEventListener('change',apply);
    else if(typeof media.addListener==='function') media.addListener(apply);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',prepare);
  else prepare();
})();
