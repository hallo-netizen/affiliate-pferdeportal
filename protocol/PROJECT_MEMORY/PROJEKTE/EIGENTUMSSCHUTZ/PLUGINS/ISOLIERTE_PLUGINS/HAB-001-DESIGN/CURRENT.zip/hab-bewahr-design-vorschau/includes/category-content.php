<?php
/**
 * Scoped category CONTENT rules (not design) modeled after the audited Pferde Atelier template:
 * Manual text wins, empty optional fields are omitted, no front-end writes or wholesale auto-overwrite.
 * Safety-site override: six world hubs keep their unchanged bottom article; 409 areas/subareas/leaves get individually authored top intros.
 */
if (!defined('ABSPATH')) exit;

function hbdp_hub_content_kind($node) {
    if (!$node || !isset($node['id']) || strpos($node['id'], 'core:') !== 0) return '';
    return strpos($node['id'], 'core:world:') === 0 ? 'world' : 'category';
}
function hbdp_hub_text_meta($node, $key) {
    if (!$node || (int)($node['wp_id']??0)<1) return '';
    if (($node['type']??'') === 'page') return trim((string)get_post_meta((int)$node['wp_id'], $key, true));
    // NO category term writes and no category name/slug/structure writes in this design plugin.
    return '';
}
/**
 * Compact top copy for each active CORE area/subarea/leaf.
 * Text-only adaptation of the verified Pferde-Atelier intro rules.
 * Never modifies WordPress category terms, pages or existing editorial copy.
 */
function hbdp_category_intro_corpus(){
    static $entries=null;
    if($entries!==null)return $entries;
    $entries=array();
    $file=HBDP_ROOT.'data/category-intros.json';
    if(!is_readable($file))return $entries;
    $decoded=json_decode((string)file_get_contents($file),true);
    if(!is_array($decoded)||($decoded['contract']??'')!=='HBDP_CATEGORY_INTROS_V1'||!isset($decoded['entries'])||!is_array($decoded['entries']))return $entries;
    $entries=$decoded['entries'];
    return $entries;
}
function hbdp_category_intro_draft($node){
    if(!is_array($node)||!isset($node['id'],$node['name'],$node['parent']))return '';
    if(!preg_match('/^core:(?:area|subarea|leaf):/D',(string)$node['id']))return '';
    $entry=hbdp_category_intro_corpus()[$node['id']]??null;
    // Fail closed when the central category office changes the node identity or scope.
    if(!is_array($entry)||($entry['name']??'')!==$node['name']||($entry['parent']??'')!==$node['parent'])return '';
    return trim((string)($entry['text']??''));
}
function hbdp_hub_top_copy($node) {
    if (!$node) return 'Schutz und Sicherheit für dein Eigentum.';
    if (strpos($node['id'],'core:world:')===0) return function_exists('hbdp_world_explanation') ? hbdp_world_explanation($node['id']) : $node['name'];
    $manual = hbdp_hub_text_meta($node, '_hbdp_category_text_top');
    if ($manual !== '') return $manual;
    if (($node['type']??'') === 'category') {
        $term = get_term((int)$node['wp_id'],'category');
        if ($term && !is_wp_error($term) && trim((string)($term->description??''))!=='') return trim(wp_strip_all_tags((string)$term->description));
    }
    if (($node['type']??'') === 'page') {
        $page = get_post((int)$node['wp_id']);
        if ($page && trim((string)($page->post_excerpt??''))!=='') return trim(wp_strip_all_tags((string)$page->post_excerpt));
    }
    // Manual WordPress page copy and existing term descriptions always win.
    // The 409 topic-specific, versioned texts are read-only fallbacks.
    $authored=hbdp_category_intro_draft($node);
    if($authored!=='')return $authored;
    $name=$node['name'];
    if (strpos($node['id'],'core:area:')===0) {
        return 'Im Bereich „'.$name.'“ findest du die zugehörigen Sicherheitsthemen übersichtlich gegliedert. Wähle einen Unterbereich, um Schutzmöglichkeiten, typische Risiken und passende Ratgeber gezielt zu finden.';
    }
    if (strpos($node['id'],'core:subarea:')===0) {
        return 'Hier geht es um „'.$name.'“. Die folgenden Kategorien führen dich zu konkreten Fragen, Schutzmaßnahmen und weiterführenden Beiträgen. Entscheidend ist, die Lösung auf das eigene Objekt und die tatsächlichen Risiken abzustimmen.';
    }
    if (($node['type']??'')==='category') {
        return 'Im Themenbereich „'.$name.'“ findest du praktische Informationen und passende Ratgeber zu Schutz, Vorsorge und möglichen Schäden. Welche Maßnahmen sinnvoll sind, hängt immer von der konkreten Situation ab.';
    }
    return 'Entdecke die wichtigsten Informationen und Ratgeber zu „'.$name.'“.';
}
function hbdp_render_hub_intro($node) {
    $text=hbdp_hub_top_copy($node);
    if ($text === '') return;
    echo '<p class="hbdp-intro">'.esc_html($text).'</p>';
}
// v0.1.11: Six content-rich world pages ONLY. Other category templates stay unchanged.
function hbdp_world_editorial_copy(){
    static $copy = null;
    if ($copy !== null) return $copy;
    $file=HBDP_ROOT.'data/world-editorial.json';
    $copy=is_readable($file)?json_decode(file_get_contents($file),true):array();
    return is_array($copy)?$copy:array();
}
function hbdp_editorial_photo($data){
    if(!is_array($data)||empty($data['file']))return '';
    $file=basename((string)$data['file']);
    if(!preg_match('/^editorial-[a-z0-9-]+\.webp$/',$file)||!is_file(HBDP_ROOT.'assets/'.$file))return '';
    return '<figure class="hbdp-editorial-figure"><img loading="lazy" decoding="async" width="640" height="300" src="'.esc_url(HBDP_URL.'assets/'.$file).'" alt="'.esc_attr($data['alt']??'').'"><figcaption>'.esc_html($data['caption']??'').'</figcaption></figure>';
}
function hbdp_world_bottom_html($node){
    $manual=hbdp_hub_text_meta($node,'_hbdp_world_bottom_text');
    if($manual!=='')return wp_kses_post(wpautop($manual));
    $spec=hbdp_world_editorial_copy()[$node['id']]??null;
    if(!$spec||empty($spec['sections']))return '';
    $out='<div class="hbdp-editorial-heading"><h2>'.esc_html($spec['title']).'</h2><p>'.esc_html($spec['intro']).'</p></div>';
    $seen=0;$n=count($spec['sections']);
    foreach($spec['sections'] as $i=>$section){
        $area=hbdp_node($section['area_id']??'');
        if(!$area||($area['parent']??'')!==$node['id'])continue;
        $url=hbdp_url($area);
        if(!$url||$url===home_url('/'))continue;
        $anchor='<a href="'.esc_url($url).'">'.esc_html(hbdp_compass_display_name($area)).'</a>';
        $out.='<section class="hbdp-editorial-area"><div class="hbdp-editorial-area-body"><span class="hbdp-editorial-num">'.sprintf('%02d',$i+1).'</span><div><h3>'.esc_html(hbdp_category_title_without_dashes($section['display_heading']??hbdp_compass_display_name($area))).'</h3>';
        foreach($section['paragraphs'] as $p){
            // Trusted bundled prose + exact category-name anchor; no invented URLs.
            $out.='<p>'.str_replace('@@CATEGORY_LINK@@',$anchor,esc_html(str_replace('{LINK}','@@CATEGORY_LINK@@',$p))).'</p>';
        }
        $out.='</div></div></section>';
        // Short independent editorial banners between COMPLETE topic paragraphs.
        // Stable category-ID attachment avoids visually unrelated motifs on
        // specific topic sections if the editorial order changes in future.
        foreach(($spec['images']??array()) as $image){
          if(($image['after_area_id']??'')!==($area['id']??''))continue;
          $photo=hbdp_editorial_photo($image);
          if($photo!=='')$out.='<div class="hbdp-editorial-banner">'.$photo.'</div>';
        }
        $seen++;
    }
    if($seen<3)return ''; // fail closed for malformed scope/data
    $out.='<div class="hbdp-editorial-check"><h3>Darauf kommt es an</h3><ul>';
    foreach(($spec['list']??array()) as $line)$out.='<li>'.esc_html($line).'</li>';
    $out.='</ul></div><p class="hbdp-editorial-outro">'.esc_html($spec['closing']).'</p>';
    return $out;
}
function hbdp_render_world_bottom_text($node){
    if(hbdp_hub_content_kind($node)!=='world')return;
    $content=hbdp_world_bottom_html($node);
    if($content!=='')echo '<section class="hbdp-world-knowledge" aria-label="Weitere Informationen zu '.esc_attr(hbdp_compass_display_name($node)).'"><span class="hbdp-knowledge-eyebrow">Hintergrund &amp; Orientierung</span>'.$content.'</section>';
}
function hbdp_render_category_top_text($node) {
    // This is the single, actual display point for the 409 top introductions.
    // Formerly this function was an empty stub: tests of the corpus alone did
    // not exercise this output path. The six worlds still use their own intro.
    if (!is_array($node) || !isset($node['id']) || !preg_match('/^core:(?:area|subarea|leaf):/', (string)$node['id'])) return;
    $text = hbdp_hub_top_copy($node); // manual/term/excerpt > bound draft > neutral fallback
    if ($text === '') return;
    echo '<p class="hbdp-intro hbdp-category-intro" data-hbdp-intro-node="'.esc_attr($node['id']).'">'.esc_html($text).'</p>';
}
// A manual, opt-in copy override only; protects central category tree and never updates page content on frontend.
add_action('add_meta_boxes_page',static function($page){
    foreach(hbdp_all_nodes() as $node){
        if(($node['type']??'')==='page' && (int)$node['wp_id']===(int)$page->ID && hbdp_hub_content_kind($node)!==''){
            add_meta_box('hbdp_hub_copy','Hab & Bewahr – Kategorietext (nur Inhalt)','hbdp_hub_copy_metabox','page','normal','default');break;
        }
    }
});
function hbdp_hub_copy_metabox($page){
    $world=false;foreach(hbdp_all_nodes() as $n)if(($n['type']??'')==='page' && (int)$n['wp_id']===(int)$page->ID){$world=hbdp_hub_content_kind($n)==='world';break;}
    wp_nonce_field('hbdp_copy_save','hbdp_copy_nonce');
    if($world){$field='_hbdp_world_bottom_text';$label='Ausführlicher Informationstext AM SEITENENDE';$help='Optionaler redaktioneller Ersatz für den vorbereiteten Langtext. Individuelle Zwischenüberschriften, integrierte Bilder und mindestens 2 passende Links. Keine FAQ, bis Beiträge dazu geplant sind; Änderungen nicht automatisch überschreiben.';}
    else{$field='_hbdp_category_text_top';$label='Kurze Kategorieeinleitung OBEN';$help='Ein individueller, informativer Text direkt unter dem Seitentitel. Empfohlen 50–90 Wörter. Wenn leer, bleibt die bisherige neutral kurze Einleitung.';}
    $value=(string)get_post_meta($page->ID,$field,true);
    echo '<p><strong>'.esc_html($label).'</strong></p><p class="description">'.esc_html($help).'</p><textarea rows="9" class="widefat" name="hbdp_page_copy">'.esc_textarea($value).'</textarea><p class="description">Nur die Texte dieser Seite, keine Änderung an Kategorienamen, Kategorie-IDs oder Slugs. Keine automatische Textgenerierung.</p>';
}
add_action('save_post_page',static function($id){
    if(!isset($_POST['hbdp_copy_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hbdp_copy_nonce'])),'hbdp_copy_save')||!current_user_can('edit_post',$id)||wp_is_post_revision($id)||defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE)return;
    $node=null;foreach(hbdp_all_nodes() as $n)if(($n['type']??'')==='page' && (int)$n['wp_id']===(int)$id){$node=$n;break;}
    if(hbdp_hub_content_kind($node)==='')return;
    $key=hbdp_hub_content_kind($node)==='world'?'_hbdp_world_bottom_text':'_hbdp_category_text_top';
    $raw=isset($_POST['hbdp_page_copy'])?wp_unslash($_POST['hbdp_page_copy']):'';
    $text=trim(wp_kses_post((string)$raw));
    if($text!=='')update_post_meta($id,$key,$text);else delete_post_meta($id,$key);
},20);
