<?php
/** Hab & Bewahr – FAQ landing in the existing Design plugin (0.1.111).
 * Existing /faq/ page remains unchanged in the database. If the imported
 * service page is absent, the exact path is served as a virtual read-only page.
 * No new WordPress objects, SEO duplicates or extra plugins.
 */
if (!defined('ABSPATH')) exit;

function hbdp_is_faq_path() {
    if (is_admin()) return false;
    $request = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '';
    $path = trim((string)wp_parse_url($request, PHP_URL_PATH), '/');
    $base = trim((string)wp_parse_url(home_url('/'), PHP_URL_PATH), '/');
    if ($base !== '') {
        if ($path === $base) return false;
        if (strpos($path, $base.'/') !== 0) return false;
        $path = substr($path, strlen($base) + 1);
    }
    return $path === 'faq';
}

// WordPress routes the already published FAQ page normally; fallback only
// repairs WordPress's empty 404 case without creating or reparenting a page.
add_action('parse_request', static function($wp) {
    if (!hbdp_is_faq_path()) return;
    if (isset($wp->query_vars['error'])) unset($wp->query_vars['error']);
    $wp->query_vars['hbdp_faq_readonly'] = '1';
}, 2);
add_filter('pre_handle_404', static function($handled) {
    return hbdp_is_faq_path() ? true : $handled;
}, 20);
add_filter('redirect_canonical', static function($redirect) {
    return hbdp_is_faq_path() ? false : $redirect;
}, 20);

function hbdp_faq_content() {
    static $data = null;
    if ($data !== null) return $data;
    $file = HBDP_ROOT.'data/faq-questions.json';
    $read = is_readable($file) ? json_decode((string)file_get_contents($file), true) : array();
    $data = is_array($read) ? $read : array();
    return $data;
}

function hbdp_faq_related_links() {
    $links = array();
    if (function_exists('hbdp_compass_base_url')) {
        $url = hbdp_compass_base_url();
        if (is_string($url) && $url !== '') $links[] = array('Schutzkompass', $url, 'Die eigene Situation durchgehen');
    }
    $mag = hbdp_node('editorial:hub');
    if ($mag) {
        $url = hbdp_nav_url($mag);
        if ($url !== '') $links[] = array('Magazin', $url, 'Praxiswissen und Hintergründe');
    }
    if (function_exists('hbdp_glossary_url')) {
        $url = hbdp_glossary_url();
        if (is_string($url) && $url !== '') $links[] = array('Glossar', $url, 'Fachbegriffe verständlich erklärt');
    }
    return $links;
}

/** Optional portal links, only when the target exists on this installation. */
function hbdp_faq_portal_link_url($target) {
    $allowed = array('impressum', 'kontakt', 'preise', 'anzeigenmarkt', 'werb-anzeigebedingungen');
    if (!is_string($target) || !in_array($target, $allowed, true)) return '';
    if ($target === 'anzeigenmarkt') {
        return function_exists('hbdp_footer_listings_url') ? (string)hbdp_footer_listings_url() : '';
    }
    return function_exists('hbdp_footer_page_url') ? (string)hbdp_footer_page_url(array($target)) : '';
}

function hbdp_render_faq_page() {
    $d = hbdp_faq_content();
    $lead = (string)($d['intro']['lead'] ?? '');
    $more = is_array($d['intro']['more'] ?? null) ? $d['intro']['more'] : array();
    $groups = is_array($d['groups'] ?? null) ? $d['groups'] : array();
    $photo = (string)($d['hero'] ?? '');
    if (!is_readable(HBDP_ROOT.'assets/'.$photo)) $photo = '';
    echo '<main class="hbdp-faq"><div class="hbdp-faq-frame">';
    echo '<nav class="hbdp-crumb" aria-label="Brotkrumennavigation"><a href="'.esc_url(home_url('/')).'">Startseite</a><span aria-hidden="true">/</span><span aria-current="page">FAQ</span></nav>';
    echo '<section class="hbdp-faq-hero">';
    if ($photo !== '') echo '<img class="hbdp-faq-hero-photo" src="'.esc_url(HBDP_URL.'assets/'.$photo).'" alt="" fetchpriority="high" decoding="async">';
    echo '<div class="hbdp-faq-hero-fade" aria-hidden="true"></div><div class="hbdp-faq-hero-copy"><span>HILFE &amp; ORIENTIERUNG</span><h1>Häufige Fragen</h1><p>Fragen zum Eigentumsschutz – klar beantwortet</p></div></section>';
    echo '<section class="hbdp-faq-intro" aria-label="Einführung"><p class="hbdp-faq-lead">'.esc_html($lead).'</p>';
    if ($more) {
        echo '<details class="hbdp-faq-readmore"><summary><span>Weiterlesen</span><span class="hbdp-faq-arrow" aria-hidden="true">⌄</span></summary><div class="hbdp-faq-expansion">';
        foreach ($more as $p) if (is_string($p) && $p !== '') echo '<p>'.esc_html($p).'</p>';
        echo '</div></details>';
    }
    echo '</section>';
    echo '<section class="hbdp-faq-index" aria-label="FAQ Themenübersicht"><div class="hbdp-faq-heading"><span>AUF EINEN BLICK</span><h2>Fragen nach Themen</h2><p>Wählen Sie einen Themenbereich oder öffnen Sie direkt eine Frage.</p></div><div class="hbdp-faq-index-grid">';
    foreach ($groups as $group) {
        if (!is_array($group) || empty($group['id']) || empty($group['title'])) continue;
        $id = sanitize_title((string)$group['id']);
        echo '<a class="hbdp-faq-index-card" href="#hbdp-faq-'.esc_attr($id).'"><strong>'.esc_html((string)$group['title']).'</strong><span>'.esc_html((string)($group['subtitle'] ?? '')).'</span><small>Zu den Fragen <span aria-hidden="true">↓</span></small></a>';
    }
    echo '</div></section>';
    foreach ($groups as $i => $group) {
        if (!is_array($group) || !isset($group['questions']) || !is_array($group['questions'])) continue;
        $id = sanitize_title((string)($group['id'] ?? ''));
        if ($id === '') continue;
        echo '<section class="hbdp-faq-group" id="hbdp-faq-'.esc_attr($id).'" aria-labelledby="hbdp-faq-title-'.esc_attr($id).'">';
        echo '<div class="hbdp-faq-group-head"><span>THEMENBEREICH '.esc_html((string)($i + 1)).'</span><h2 id="hbdp-faq-title-'.esc_attr($id).'">'.esc_html((string)($group['title'] ?? '')).'</h2><p>'.esc_html((string)($group['subtitle'] ?? '')).'</p></div>';
        echo '<div class="hbdp-faq-questions">';
        foreach ($group['questions'] as $entry) {
            if (!is_array($entry)) continue;
            $question = trim((string)($entry['question'] ?? ''));
            $answer = trim((string)($entry['answer'] ?? ''));
            if ($question === '' || $answer === '') continue;
            echo '<details class="hbdp-faq-question"><summary><span>'.esc_html($question).'</span><span class="hbdp-faq-toggle" aria-hidden="true"></span></summary><div class="hbdp-faq-answer"><p>'.esc_html($answer).'</p>';
            $link = hbdp_faq_portal_link_url($entry['link_target'] ?? '');
            if ($link !== '') {
                $label = trim((string)($entry['link_label'] ?? 'Mehr erfahren'));
                echo '<p class="hbdp-faq-inline-link"><a href="'.esc_url($link).'">'.esc_html($label).'<span aria-hidden="true"> →</span></a></p>';
            }
            echo '</div></details>';
        }
        echo '</div></section>';
    }
    $links = hbdp_faq_related_links();
    if ($links) {
        echo '<section class="hbdp-faq-related"><div class="hbdp-faq-heading"><span>WEITERLESEN</span><h2>Weitere Wege zur passenden Hilfe</h2></div><div class="hbdp-faq-related-grid">';
        foreach ($links as $link) echo '<a href="'.esc_url($link[1]).'"><strong>'.esc_html($link[0]).'</strong><span>'.esc_html($link[2]).'</span><small>Öffnen <span aria-hidden="true">→</span></small></a>';
        echo '</div></section>';
    }
    echo '</div></main>';
}
