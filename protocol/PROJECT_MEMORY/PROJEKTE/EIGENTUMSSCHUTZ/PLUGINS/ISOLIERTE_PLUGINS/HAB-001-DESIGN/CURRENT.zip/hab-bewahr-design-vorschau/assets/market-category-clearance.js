/* Original market-submit clearance principle (0.1.155), applied only to
 * HivePress listing categories. Never move the header, navigation or footer. */
(function(){'use strict';
  var pending=false;
  function check(){
    pending=false;
    if(!document.body.classList.contains('hbdp-hobby-market-child') ||
       !document.body.classList.contains('hbdp-market-category-request'))return;
    var nav=document.querySelector('.hbdp-hobby-market-site-header .hbdp-mainnav-wrap');
    var content=document.querySelector('.site-container');
    var intro=document.querySelector('.hbdp-market-child-intro .hbdp-crumb');
    if(!nav||!content||!intro||!content.contains(intro))return;
    content.style.removeProperty('margin-top');
    var below=nav.getBoundingClientRect().bottom+12;
    var actual=intro.getBoundingClientRect().top;
    if(!Number.isFinite(below)||!Number.isFinite(actual))return;
    if(actual<below){
      var current=parseFloat(window.getComputedStyle(content).marginTop)||0;
      content.style.setProperty('margin-top', Math.ceil(current+below-actual)+'px', 'important');
    }
  }
  function schedule(){if(pending)return;pending=true;requestAnimationFrame(check);}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
  window.addEventListener('load',schedule,{once:true});
  window.addEventListener('resize',schedule);
})();
