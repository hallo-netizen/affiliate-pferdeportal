<?php
/** Hab & Bewahr: glossary editorial module; stored in WordPress, never in the navigation/category tree. */
/** WordPress returns un-serialized scalar meta as strings, even when saved as integers. */
function hbdp_glossary_meta_readback_matches($post_id,$key,$expected) {
    if (!metadata_exists('post',(int)$post_id,(string)$key)) return false;
    $actual=get_post_meta((int)$post_id,(string)$key,true);
    if (is_array($expected)) return is_array($actual) && $actual === $expected;
    if (is_string($expected) || is_int($expected) || is_float($expected) || is_bool($expected))
        return !is_array($actual) && !is_object($actual) && (string)$actual === (string)$expected;
    return $actual === $expected;
}

if (!defined('ABSPATH')) exit;

function hbdp_glossary_worlds() {
    return array('einbruch'=>'Einbruch & Diebstahl','vandalismus'=>'Vandalismus & Zerstörung','wasser'=>'Wasser & Feuchtigkeit','feuer'=>'Feuer & Gase','wetter'=>'Wetter & Natur','technik'=>'Technik & Ausfälle','versicherung'=>'Versicherungen');
}
add_action('init', static function () {
    register_post_type('hbdp_glossar_term',array(
        'labels'=>array('name'=>'Sicherheitsglossar','singular_name'=>'Glossarbegriff','add_new_item'=>'Glossarbegriff anlegen','edit_item'=>'Glossarbegriff bearbeiten','menu_name'=>'Glossar'),
        'public'=>true,'show_in_rest'=>true,'show_in_menu'=>true,'menu_icon'=>'dashicons-book-alt','has_archive'=>false,
        'rewrite'=>array('slug'=>'glossar/begriff','with_front'=>false),
        'supports'=>array('title','editor','revisions'),'exclude_from_search'=>false
    ));
});
// Native classic editor keeps the source/approval meta boxes in the same save request.
add_filter('use_block_editor_for_post_type',static function($use,$type){return $type==='hbdp_glossar_term'?false:$use;},10,2);
function hbdp_glossary_wordcount($text) {
    $plain=trim(strip_tags((string)$text));
    if ($plain==='')return 0;
    $n=preg_match_all('/[\p{L}\p{N}]+(?:[\-’][\p{L}\p{N}]+)*/u',$plain,$m);
    return $n===false?0:$n;
}
/** A glossary article must continue the short explanation, not repeat its opening words. */
function hbdp_glossary_repeats_lead($short,$body) {
    $normalize=static function($value) {
        $text=strip_tags((string)$value);
        $text=function_exists('mb_strtolower')?mb_strtolower($text,'UTF-8'):strtolower($text);
        $text=preg_replace('/[^\p{L}\p{N}]+/u',' ',$text);
        return preg_split('/\s+/u',trim((string)$text),-1,PREG_SPLIT_NO_EMPTY);
    };
    $a=$normalize($short);$b=$normalize($body);
    return count($a)>=8 && count($b)>=8 && array_slice($a,0,8)===array_slice($b,0,8);
}
function hbdp_glossary_validate_record($r) {
    if(!is_array($r))return 'Datensatz nicht lesbar';
    foreach(array('external_id','begriff','slug','themenwelt','kurzdefinition','facherklaerung','abgrenzung','seo_title','seo_description','last_verified_at') as $k)
        if(!isset($r[$k]) || !is_string($r[$k]) || trim($r[$k])==='') return 'Pflichtfeld: '.$k;
    if(!preg_match('/^term-[a-z0-9]+(?:-[a-z0-9]+)*$/D',$r['external_id']))return 'Ungültige externe ID';
    if(!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/D',$r['slug']))return 'Ungültiger Slug';
    if(!isset(hbdp_glossary_worlds()[$r['themenwelt']]))return 'Ungültige Schutzwelt';
    if(($r['recherche_status']??'')!=='GEPRUEFT')return 'Recherche nicht freigegeben';
    $w=hbdp_glossary_wordcount($r['facherklaerung']);
    if($w<150 || $w>200)return 'Fachtext muss 150–200 Wörter haben (hat '.$w.')';
    if(hbdp_glossary_repeats_lead($r['kurzdefinition'],$r['facherklaerung']))return 'Fachtext wiederholt die Kurzdefinition am Anfang';
    if(preg_match('~<|>|https?://|\[[^]]+\]\s*\(\s*https?:~i',$r['facherklaerung']))return 'HTML/Bodylink im Fachtext';
    if(!in_array((int)($r['review_interval_months']??0),array(6,12,24),true))return 'Ungültiger Prüfzyklus';
    if(!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$r['last_verified_at']))return 'Ungültiges Prüfdatum';
    $d=explode('-',$r['last_verified_at']); if(!checkdate((int)$d[1],(int)$d[2],(int)$d[0]))return 'Ungültiges Datum';
    if(!is_array($r['quellen']??null)||!count($r['quellen']))return 'Quelle fehlt';
    foreach($r['quellen'] as $s)if(!is_array($s)||empty($s['url'])||!filter_var($s['url'],FILTER_VALIDATE_URL)||!preg_match('~^https?://~i',$s['url'])||empty($s['organisation'])||empty($s['beleg']))return 'Quelle nicht nachprüfbar';
    if(!is_array($r['verwandte_begriffe']??null)||count($r['verwandte_begriffe'])<1)return 'Verwandte Begriffe fehlen';
    if(!is_array($r['synonyme']??null))return 'Synonyme müssen eine Liste sein';
    if(!empty($r['primary_target']) && (!is_array($r['primary_target'])||!in_array($r['primary_target']['type']??'',array('page','category'),true)||empty($r['primary_target']['wp_id'])))return 'Hauptseite ungültig';
    return '';
}
function hbdp_glossary_validate_batch($batch) {
    if(!is_array($batch)||($batch['contract_version']??'')!=='HB_GLOSSARY_BATCH_V1'||!is_array($batch['terms']??null))return array('Batchvertrag ungültig',array());
    $n=count($batch['terms']);if($n<1||$n>25)return array('Nur 1–25 Einträge pro Batch',array());
    $seen_ids=array();$seen_slugs=array();
    foreach($batch['terms'] as $i=>$term){
        $err=hbdp_glossary_validate_record($term); if($err!=='')return array('Datensatz '.($i+1).': '.$err,array());
        if(isset($seen_ids[$term['external_id']])||isset($seen_slugs[$term['slug']]))return array('Dublette im Batch',array());
        $seen_ids[$term['external_id']]=1;$seen_slugs[$term['slug']]=1;
    }
    return array('', $batch['terms']);
}
function hbdp_glossary_live_rule($r) {
    // Only on explicit admin Staging/Confirm: check the REAL current WordPress category inventory.
    foreach(array('category','journal_cat','hp_listing_category') as $taxonomy) {
        if(!taxonomy_exists($taxonomy))continue;
        $term=get_term_by('name',$r['begriff'],$taxonomy);
        if($term && !is_wp_error($term) && $term->name===$r['begriff'])return 'Begriff identisch mit einer bestehenden Kategorie: '.$taxonomy;
    }
    $target=$r['primary_target']??array();
    if(is_array($target)&&!empty($target['wp_id'])){
        $id=(int)$target['wp_id'];
        if(($target['type']??'')==='page'){$p=get_post($id);if(!$p||$p->post_type!=='page'||$p->post_status!=='publish')return 'Ungültige Zielseite';}
        elseif(($target['type']??'')==='category'){$t=get_term($id,'category');if(!$t||is_wp_error($t))return 'Ungültige Zielkategorie';}
    }
    return '';
}
function hbdp_glossary_exists($r) {
    // The operation runs only in WP admin during explicitly requested staging/import.
    $by_name=get_page_by_path($r['slug'],OBJECT,'hbdp_glossar_term');
    if($by_name)return true;
    $ids=get_posts(array('post_type'=>'hbdp_glossar_term','post_status'=>'any','fields'=>'ids','posts_per_page'=>1,'meta_key'=>'_hbdp_term_id','meta_value'=>$r['external_id']));
    return !empty($ids);
}
add_action('add_meta_boxes_hbdp_glossar_term', static function () {
    add_meta_box('hbdp_glossar_editor','Glossar – Fachprüfung', 'hbdp_glossary_metabox','hbdp_glossar_term','normal','high');
});
/** Native WordPress glossary editor. This CPT never mixes with ordinary posts. */
function hbdp_glossary_metabox($post) {
    wp_nonce_field('hbdp_glossar_edit','hbdp_glossar_edit_nonce');
    $get=static function($key)use($post){return (string)get_post_meta($post->ID,$key,true);};
    $world=$get('_hbdp_world');$related=(array)get_post_meta($post->ID,'_hbdp_related',true);
    $synonyms=(array)get_post_meta($post->ID,'_hbdp_synonyms',true);
    $sources=(array)get_post_meta($post->ID,'_hbdp_sources',true);$source=is_array($sources[0]??null)?$sources[0]:array();
    echo '<p><strong>Fachliche Einträge bearbeiten</strong> – normale Beiträge bleiben getrennt. Keine automatische Veröffentlichung.</p>';
    echo '<p><label>Schutzwelt<br><select name="hbdp_editor_world">';
    foreach(hbdp_glossary_worlds() as $key=>$label)echo '<option value="'.esc_attr($key).'" '.selected($world,$key,false).'>'.esc_html($label).'</option>';
    echo '</select></label></p>';
    $fields=array(
      'short'=>array('Kurzdefinition','_hbdp_short',true),
      'scope'=>array('Abgrenzung zu verwandten Begriffen','_hbdp_scope',true),
      'related'=>array('Verwandte Begriffe (kommagetrennt)',null,false),
      'synonyms'=>array('Synonyme/Aliase (kommagetrennt)',null,false),
      'seo_title'=>array('SEO-Titel','_hbdp_seo_title',false),
      'seo_description'=>array('SEO-Beschreibung','_hbdp_seo_description',true),
    );
    foreach($fields as $key=>$spec){$value=$spec[1]!==null?$get($spec[1]):implode(', ',$key==='related'?$related:$synonyms);
        echo '<p><label for="hbdp_editor_'.esc_attr($key).'"><strong>'.esc_html($spec[0]).'</strong></label><br>';
        if($spec[2])echo '<textarea class="large-text" rows="3" id="hbdp_editor_'.esc_attr($key).'" name="hbdp_editor_'.esc_attr($key).'">'.esc_textarea($value).'</textarea>';
        else echo '<input class="large-text" type="text" id="hbdp_editor_'.esc_attr($key).'" name="hbdp_editor_'.esc_attr($key).'" value="'.esc_attr($value).'">';
        echo '</p>';
    }
    $source_fields=array('organisation'=>'Quelle: Organisation','url'=>'Quelle: URL','beleg'=>'Quelle: konkreter Beleg / Fundstelle');
    foreach($source_fields as $key=>$label)echo '<p><label><strong>'.esc_html($label).'</strong><br><input class="large-text" type="text" name="hbdp_editor_source_'.esc_attr($key).'" value="'.esc_attr((string)($source[$key]??'')).'"></label></p>';
    echo '<p><label>Letzter tatsächlicher Quellencheck (JJJJ-MM-TT)<br><input type="date" name="hbdp_editor_verified" value="'.esc_attr($get('_hbdp_verified')).'"></label> &nbsp; <label>Wiedervorlage<br><select name="hbdp_editor_interval">';
    foreach(array(6,12,24) as $months)echo '<option value="'.$months.'" '.selected((int)$get('_hbdp_review_months'),$months,false).'>'.$months.' Monate</option>';
    echo '</select></label></p>';
    $valid=$get('_hbdp_validated')==='1';
    $checked=$get('_hbdp_approved')==='1';
    echo '<p><label><input type="checkbox" name="hbdp_editor_checked" value="1" '.checked($get('_hbdp_research_status'),'GEPRUEFT',false).'> <strong>Quellen und Text persönlich nachgeprüft</strong> (150–200 Wörter, eigenständiger Einstieg, 0 Bodylinks, Abgrenzung, belegte Quelle, SEO-Felder)</label></p>';
    echo '<p><strong>Formale Prüfung:</strong> '.($valid?'Bestanden':'OFFEN').'; <strong>Fachfreigabe:</strong> '.($checked?'Ja':'Nein').'. <strong>Wörter:</strong> '.hbdp_glossary_wordcount($post->post_content).'/150–200.</p>';
    if ($post->ID > 0) {
        $review_url=add_query_arg(array('page'=>'hbdp-glossar-freigabe','term_id'=>(int)$post->ID),admin_url('admin.php'));
        echo '<p><a class="button button-primary" href="'.esc_url($review_url).'">Fachprüfung und Veröffentlichung</a> <small>Zuerst die Änderungen speichern; hier werden Pflichtfelder und Quellen geprüft.</small></p>';
    }
    echo '<p><em>Ein Glossarbegriff wird erst nach individueller Prüfung und ausdrücklicher Freigabe veröffentlicht. Entwürfe sind für Besucher nicht sichtbar.</em></p>';
}
/** Creates a validated record from the actual latest editorial fields, not the archived JSON seed. */
function hbdp_glossary_post_record($post){
    $id=(int)$post->ID;
    return array(
       'external_id'=>(string)get_post_meta($id,'_hbdp_term_id',true),
       'begriff'=>$post->post_title,'slug'=>$post->post_name,
       'themenwelt'=>(string)get_post_meta($id,'_hbdp_world',true),
       'kurzdefinition'=>(string)get_post_meta($id,'_hbdp_short',true),
       'facherklaerung'=>hbdp_glossary_body_plain($post->post_content),
       'abgrenzung'=>(string)get_post_meta($id,'_hbdp_scope',true),
       'synonyme'=>(array)get_post_meta($id,'_hbdp_synonyms',true),
       'verwandte_begriffe'=>(array)get_post_meta($id,'_hbdp_related',true),
       'quellen'=>(array)get_post_meta($id,'_hbdp_sources',true),
       'seo_title'=>(string)get_post_meta($id,'_hbdp_seo_title',true),
       'seo_description'=>(string)get_post_meta($id,'_hbdp_seo_description',true),
       'last_verified_at'=>(string)get_post_meta($id,'_hbdp_verified',true),
       'review_interval_months'=>(int)get_post_meta($id,'_hbdp_review_months',true),
       'primary_target'=>(array)get_post_meta($id,'_hbdp_primary_target',true),
       'recherche_status'=>(string)get_post_meta($id,'_hbdp_research_status',true),
    );
}
function hbdp_glossary_body_plain($content){
    $s=(string)$content;
    $s=preg_replace('~</(?:p|div|h[1-6]|li)>~i',"\n\n",$s);
    $s=preg_replace('~<br\s*/?>~i',"\n",$s);
    $s=wp_strip_all_tags($s);
    $s=preg_replace('/\n{3,}/',"\n\n",$s);
    return trim((string)$s);
}
/** Save editorial fields; never invent approval when fields are missing. */
add_action('save_post_hbdp_glossar_term',static function($id){
    if(!isset($_POST['hbdp_glossar_edit_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['hbdp_glossar_edit_nonce'])),'hbdp_glossar_edit')||!current_user_can('edit_post',$id)||wp_is_post_revision($id)||(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE))return;
    $post=get_post($id);if(!$post||$post->post_type!=='hbdp_glossar_term')return;
    $values=wp_unslash($_POST);
    $world=(string)($values['hbdp_editor_world']??'');
    if(isset(hbdp_glossary_worlds()[$world]))update_post_meta($id,'_hbdp_world',$world);
    foreach(array('short'=>'_hbdp_short','scope'=>'_hbdp_scope','seo_title'=>'_hbdp_seo_title','seo_description'=>'_hbdp_seo_description') as $field=>$key){
      if(isset($values['hbdp_editor_'.$field]))update_post_meta($id,$key,sanitize_textarea_field($values['hbdp_editor_'.$field]));
    }
    foreach(array('related'=>'_hbdp_related','synonyms'=>'_hbdp_synonyms') as $field=>$key){
        if(!isset($values['hbdp_editor_'.$field]))continue;
        $a=array_filter(array_map('trim',explode(',',sanitize_text_field($values['hbdp_editor_'.$field]))),'strlen');
        update_post_meta($id,$key,array_values(array_unique($a)));
    }
    $src=(array)get_post_meta($id,'_hbdp_sources',true);
    $org=sanitize_text_field((string)($values['hbdp_editor_source_organisation']??''));
    $url=esc_url_raw((string)($values['hbdp_editor_source_url']??''));
    $beleg=sanitize_textarea_field((string)($values['hbdp_editor_source_beleg']??''));
    if($org!==''||$url!==''||$beleg!==''){
        $first=array('organisation'=>$org,'url'=>$url,'beleg'=>$beleg);
        if($src){$src[0]=$first;}else{$src=array($first);}
    } else $src=array();
    update_post_meta($id,'_hbdp_sources',array_values($src));
    if(isset($values['hbdp_editor_verified']))update_post_meta($id,'_hbdp_verified',sanitize_text_field($values['hbdp_editor_verified']));
    if(isset($values['hbdp_editor_interval']))update_post_meta($id,'_hbdp_review_months',(int)$values['hbdp_editor_interval']);
    if(!get_post_meta($id,'_hbdp_term_id',true)&&$post->post_name!=='')update_post_meta($id,'_hbdp_term_id','term-'.$post->post_name);
    $checked=!empty($values['hbdp_editor_checked']);
    update_post_meta($id,'_hbdp_research_status',$checked?'GEPRUEFT':'ENTWURF');
    $result=$checked?hbdp_glossary_validate_record(hbdp_glossary_post_record($post)):'Quellen und Text noch nicht nachgeprüft';
    update_post_meta($id,'_hbdp_validated',$result===''?'1':'0');
    // Any explicit redaction of review fields needs a fresh separate publishing approval.
    update_post_meta($id,'_hbdp_approved','0');
    delete_post_meta($id,'_hbdp_approval_hash');
    if($post->post_status==='publish')wp_update_post(array('ID'=>$id,'post_status'=>'draft'));
},8);
/** One authoritative publication guard, including the latest proposed title/body. */
function hbdp_glossary_can_publish($id,$candidate=null) {
    $post=get_post((int)$id);
    if(!$post||$post->post_type!=='hbdp_glossar_term')return 'Ungültiger Glossar-Datensatz';
    $r=hbdp_glossary_post_record($post);
    if(is_array($candidate)){
        if(isset($candidate['post_title']))$r['begriff']=(string)$candidate['post_title'];
        if(isset($candidate['post_name']) && $candidate['post_name']!=='')$r['slug']=(string)$candidate['post_name'];
        if(isset($candidate['post_content']))$r['facherklaerung']=hbdp_glossary_body_plain($candidate['post_content']);
    }
    $reason=hbdp_glossary_validate_record($r);
    if($reason!=='')return $reason;
    if(get_post_meta($id,'_hbdp_validated',true)!=='1'||get_post_meta($id,'_hbdp_research_status',true)!=='GEPRUEFT')return 'Fachprüfung noch nicht gespeichert';
    if(get_post_meta($id,'_hbdp_approved',true)!=='1')return 'Ausdrückliche Freigabe fehlt';
    $hash=(string)get_post_meta($id,'_hbdp_approval_hash',true);
    if($hash==='' || !hash_equals($hash,hash('sha256',$r['facherklaerung'])))return 'Fachtext wurde nach Freigabe verändert';
    return '';
}
add_filter('wp_insert_post_data',static function($data,$postarr){
    if(($data['post_type']??'')==='hbdp_glossar_term' && ($data['post_status']??'')==='publish'){
        $id=(int)($postarr['ID']??0);
        if(!$id || hbdp_glossary_can_publish($id,$data)!=='')$data['post_status']='draft';
    }
    return $data;
},10,2);
/** Title/body/slug edits via Quick Edit or REST always cancel an earlier review. */
add_action('post_updated',static function($id,$after,$before){
    if(!$after || !$before || $after->post_type!=='hbdp_glossar_term')return;
    if($after->post_title===$before->post_title && $after->post_content===$before->post_content && $after->post_name===$before->post_name)return;
    update_post_meta($id,'_hbdp_approved','0');
    update_post_meta($id,'_hbdp_validated','0');
    update_post_meta($id,'_hbdp_research_status','ENTWURF');
    delete_post_meta($id,'_hbdp_approval_hash');
    if($after->post_status==='publish')wp_update_post(array('ID'=>$id,'post_status'=>'draft'));
},10,3);
/** Blocked status never leaks after a bulk or quick edit, or a stale revision. */
add_action('save_post_hbdp_glossar_term',static function($id){
    static $guard=false;
    if($guard || wp_is_post_revision($id))return;
    $p=get_post($id);
    if(!$p||$p->post_status!=='publish'||hbdp_glossary_can_publish($id)==='')return;
    $guard=true;wp_update_post(array('ID'=>$id,'post_status'=>'draft'));$guard=false;
},60);
/** Existing editor screen opens this native review page; no second plugin or nested forms. */
add_action('admin_menu',static function(){
    add_submenu_page(null,'Glossar – Fachfreigabe','Glossar – Fachfreigabe','edit_posts','hbdp-glossar-freigabe','hbdp_glossary_approval_screen');
});
function hbdp_glossary_approval_screen(){
    $id=(int)($_GET['term_id']??0);$post=$id?get_post($id):null;
    if(!$post||$post->post_type!=='hbdp_glossar_term'||!current_user_can('edit_post',$id))wp_die('Keine Berechtigung');
    $reason=hbdp_glossary_validate_record(hbdp_glossary_post_record($post));
    $checked=get_post_meta($id,'_hbdp_research_status',true)==='GEPRUEFT';
    $allowed=$reason==='' && $checked && $post->post_status!=='publish';
    echo '<div class="wrap"><h1>Glossar – '.esc_html($post->post_title).'</h1>';
    echo '<p><a href="'.esc_url(get_edit_post_link($id)).'">← Zur Bearbeitung</a></p>';
    echo '<p>Veröffentlichung ausschließlich nach persönlicher Prüfung von Fachtext, Abgrenzung, Quellenbeleg, Prüfdatum und SEO-Daten.</p>';
    if($post->post_status==='publish')echo '<div class="notice notice-success"><p>Der Beitrag ist veröffentlicht.</p></div>';
    elseif(!$allowed)echo '<div class="notice notice-warning"><p><strong>Freigabe gesperrt:</strong> '.esc_html($reason?:'Bitte im Editor „Quellen und Text persönlich nachgeprüft“ aktivieren und speichern.').'</p></div>';
    else{
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        echo '<input type="hidden" name="action" value="hbdp_glossary_release"><input type="hidden" name="post_id" value="'.(int)$id.'">';
        wp_nonce_field('hbdp_glossary_release_'.$id);
        echo '<p><label><input type="checkbox" name="confirm_review" value="1" required> Ich habe diesen konkreten Fachtext und die angegebenen Quellen persönlich geprüft.</label></p>';
        echo '<p><button type="submit" class="button button-primary">Diesen Glossarbegriff veröffentlichen</button></p></form>';
    }
    echo '</div>';
}
add_action('admin_post_hbdp_glossary_release',static function(){
    $id=absint($_POST['post_id']??0);
    if(!$id || !current_user_can('edit_post',$id) || !current_user_can('publish_posts'))wp_die('Keine Berechtigung');
    check_admin_referer('hbdp_glossary_release_'.$id);
    $post=get_post($id);
    if(!$post||$post->post_type!=='hbdp_glossar_term'||$post->post_status==='publish'||empty($_POST['confirm_review']))wp_die('Freigabe nicht bestätigt');
    $reason=hbdp_glossary_validate_record(hbdp_glossary_post_record($post));
    if($reason==='' && get_post_meta($id,'_hbdp_research_status',true)!=='GEPRUEFT')$reason='Persönliche Prüfung ist noch nicht im Editor gespeichert';
    if($reason===''){
        update_post_meta($id,'_hbdp_validated','1');
        update_post_meta($id,'_hbdp_approved','1');
        update_post_meta($id,'_hbdp_approval_hash',hash('sha256',hbdp_glossary_body_plain($post->post_content)));
        $written=wp_update_post(array('ID'=>$id,'post_status'=>'publish'),true);
        $check=get_post($id);
        if(is_wp_error($written)||!$check||$check->post_status!=='publish'){
            update_post_meta($id,'_hbdp_approved','0');delete_post_meta($id,'_hbdp_approval_hash');
            $reason='WordPress hat die Veröffentlichung nicht bestätigt';
        }
    }
    $url=add_query_arg(array('page'=>'hbdp-glossar-freigabe','term_id'=>$id,'review_result'=>$reason===''?'pass':'blocked'),admin_url('admin.php'));
    if($reason!=='')$url=add_query_arg('reason',$reason,$url);
    wp_safe_redirect($url);exit;
});
/** Native WordPress multi-selection, extended only with safe editorial bulk actions. */
add_filter('bulk_actions-edit-hbdp_glossar_term',static function($actions){
    if(!isset($actions['edit']))$actions=array('edit'=>'Bearbeiten')+$actions;
    foreach(array(6,12,24) as $m)$actions['hbdp_interval_'.$m]='Glossar: Prüfintervall '.$m.' Monate';
    $actions['hbdp_reset_review']='Glossar: erneut zur Fachprüfung';
    foreach(hbdp_glossary_worlds() as $key=>$label)$actions['hbdp_world_'.$key]='Glossarwelt: '.$label;
    return $actions;
});
add_filter('handle_bulk_actions-edit-hbdp_glossar_term',static function($redirect,$action,$post_ids){
    $world='';$months=0;
    if(strpos((string)$action,'hbdp_world_')===0)$world=substr($action,11);
    elseif(strpos((string)$action,'hbdp_interval_')===0)$months=(int)substr($action,14);
    elseif($action!=='hbdp_reset_review')return $redirect;
    if($world!=='' && !isset(hbdp_glossary_worlds()[$world]))return $redirect;
    if($months && !in_array($months,array(6,12,24),true))return $redirect;
    $changed=0;
    foreach(array_unique(array_map('absint',(array)$post_ids)) as $id){
        $post=$id?get_post($id):null;
        if(!$post||$post->post_type!=='hbdp_glossar_term'||!current_user_can('edit_post',$id))continue;
        if($world!=='')update_post_meta($id,'_hbdp_world',$world);
        if($months)update_post_meta($id,'_hbdp_review_months',$months);
        // Changing a field in an approved published record revokes its approval.
        update_post_meta($id,'_hbdp_approved','0');update_post_meta($id,'_hbdp_validated','0');
        update_post_meta($id,'_hbdp_research_status','ENTWURF');delete_post_meta($id,'_hbdp_approval_hash');
        if($post->post_status==='publish')wp_update_post(array('ID'=>$id,'post_status'=>'draft'));
        $changed++;
    }
    return add_query_arg('hbdp_bulk_changed',$changed,$redirect);
},10,3);
add_action('admin_notices',static function(){
    $screen=function_exists('get_current_screen')?get_current_screen():null;
    if(!$screen||$screen->id!=='edit-hbdp_glossar_term'||!isset($_GET['hbdp_bulk_changed']))return;
    echo '<div class="notice notice-success is-dismissible"><p>'.(int)$_GET['hbdp_bulk_changed'].' Glossareinträge redaktionell aktualisiert. Eine eventuell bestehende Fachfreigabe wurde aus Sicherheitsgründen zurückgesetzt.</p></div>';
});
// Admin-only explicit staged import; no background worker or automatic publications.
add_action('admin_menu', static function () {
    add_submenu_page('edit.php?post_type=hbdp_glossar_term','Glossar-Import','Geprüfte Batches','manage_options','hbdp-glossar-import','hbdp_glossary_admin_import');
    add_submenu_page('edit.php?post_type=hbdp_glossar_term','Glossar-Prüfbedarf','Prüfbedarf','manage_options','hbdp-glossar-review','hbdp_glossary_admin_review');
});
function hbdp_glossary_admin_review() {
    if(!current_user_can('manage_options'))return;
    $posts=get_posts(array('post_type'=>'hbdp_glossar_term','post_status'=>array('publish','draft','pending'),'numberposts'=>-1,'orderby'=>'title','order'=>'ASC'));
    $today=new DateTimeImmutable(current_time('Y-m-d'));
    echo '<div class="wrap"><h1>Glossar – Prüfbedarf</h1><p>Nur Wiedervorlage, keine automatische Textänderung und keine Veröffentlichung.</p><table class="widefat striped"><thead><tr><th>Begriff</th><th>Zuletzt geprüft</th><th>Intervall</th><th>Wiedervorlage</th><th>Status</th></tr></thead><tbody>';
    foreach($posts as $post){
      $date=(string)get_post_meta($post->ID,'_hbdp_verified',true);$months=(int)get_post_meta($post->ID,'_hbdp_review_months',true);
      $valid=in_array($months,array(6,12,24),true)&&preg_match('/^\d{4}-\d{2}-\d{2}$/D',$date);
      $due='Unvollständig';$status='PRÜFEN';
      if($valid){try{$dt=new DateTimeImmutable($date);$dt=$dt->modify('+'.$months.' months');$due=$dt->format('Y-m-d');$status=$dt<=$today?'FÄLLIG':'Aktuell';}catch(Exception $e){$status='PRÜFEN';}}
      echo '<tr><td><a href="'.esc_url(get_edit_post_link($post->ID)).'">'.esc_html($post->post_title).'</a></td><td>'.esc_html($date?:'—').'</td><td>'.esc_html((string)$months).' Monate</td><td>'.esc_html($due).'</td><td>'.esc_html($status).'</td></tr>';
    }
    echo '</tbody></table></div>';
}

function hbdp_glossary_admin_import() {
    if(!current_user_can('manage_options'))return;
    $key='hbdp_glstage_'.get_current_user_id();$staged=get_transient($key);
    echo '<div class="wrap"><h1>Hab & Bewahr – Glossarimport</h1><p>Entwurf-Import nach Pferde-Atelier: 150–200 Wörter, Quellen und ein manueller zweiter Freigabeschritt. Maximal 25 geprüfte Begriffe. Keine automatische Veröffentlichung.</p>';
    if(isset($_GET['hb_result']))echo '<div class="notice notice-info"><p>'.esc_html(sanitize_text_field(wp_unslash($_GET['hb_result']))).'</p></div>';
    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" enctype="multipart/form-data"><input type="hidden" name="action" value="hbdp_glossary_stage">';wp_nonce_field('hbdp_glossary_stage');echo '<p><input type="file" name="batch" accept=".json,application/json" required></p><p><button class="button">Batch validieren, noch nicht schreiben</button></p></form>';
    if(is_array($staged) && isset($staged['sha'],$staged['data'])){
        echo '<h2>Staging – '.count($staged['data']['terms']).' geprüfte Datensätze</h2><p>SHA-256: '.esc_html($staged['sha']).'</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="hbdp_glossary_confirm"><input type="hidden" name="hash" value="'.esc_attr($staged['sha']).'">';wp_nonce_field('hbdp_glossary_confirm');echo '<button class="button button-primary">Jetzt als WordPress-Entwürfe importieren</button></form>';
    }
    echo '<p>Ungeprüfte Kurzdefinitionen gehören ins separate Glossarbüro und werden hier nicht automatisch importiert.</p></div>';
}
function hbdp_glossary_redirect_msg($msg) {wp_safe_redirect(add_query_arg('hb_result',rawurlencode($msg),admin_url('edit.php?post_type=hbdp_glossar_term&page=hbdp-glossar-import')));exit;}
add_action('admin_post_hbdp_glossary_stage', static function () {
    if(!current_user_can('manage_options')||!check_admin_referer('hbdp_glossary_stage'))wp_die('Nicht autorisiert');
    if(!isset($_FILES['batch'])||!is_uploaded_file($_FILES['batch']['tmp_name'])||($_FILES['batch']['size']??0)>1000000)hbdp_glossary_redirect_msg('Ungültige Upload-Datei');
    $raw=file_get_contents($_FILES['batch']['tmp_name']);$data=json_decode($raw,true);list($err,$terms)=hbdp_glossary_validate_batch($data);
    if($err!=='')hbdp_glossary_redirect_msg($err);
    foreach($terms as $term){if(hbdp_glossary_exists($term))hbdp_glossary_redirect_msg('Bereits vorhanden: '.$term['begriff']);$live=hbdp_glossary_live_rule($term);if($live!=='')hbdp_glossary_redirect_msg($live);}
    $canonical=wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);$sha=hash('sha256',$canonical);
    set_transient('hbdp_glstage_'.get_current_user_id(),array('sha'=>$sha,'data'=>$data),20*MINUTE_IN_SECONDS);
    hbdp_glossary_redirect_msg('Staging geprüft: '.count($terms).' Begriffe. Bitte Import separat bestätigen.');
});
add_action('admin_post_hbdp_glossary_confirm',static function () {
    if(!current_user_can('manage_options')||!check_admin_referer('hbdp_glossary_confirm'))wp_die('Nicht autorisiert');
    $key='hbdp_glstage_'.get_current_user_id();$staged=get_transient($key);
    if(!is_array($staged)||!isset($staged['sha'],$staged['data'])||!hash_equals($staged['sha'],sanitize_text_field(wp_unslash($_POST['hash']??''))))hbdp_glossary_redirect_msg('Staging ungültig oder abgelaufen');
    if(!hash_equals($staged['sha'],hash('sha256',wp_json_encode($staged['data'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))))hbdp_glossary_redirect_msg('Staging-Hash-Mismatch');
    list($err,$terms)=hbdp_glossary_validate_batch($staged['data']);if($err!=='')hbdp_glossary_redirect_msg($err);
    foreach($terms as $r){if(hbdp_glossary_exists($r))hbdp_glossary_redirect_msg('Schon vorhanden: '.$r['begriff']);$live=hbdp_glossary_live_rule($r);if($live!=='')hbdp_glossary_redirect_msg($live);}
    $created=array();$failure='';
    foreach($terms as $r){
        $id=wp_insert_post(wp_slash(array('post_type'=>'hbdp_glossar_term','post_status'=>'draft','post_title'=>$r['begriff'],'post_name'=>$r['slug'],'post_content'=>$r['facherklaerung'])),true);
        if(is_wp_error($id)||!(int)$id){$failure='WordPress-Schreibfehler';break;}
        $created[]=(int)$id;
        $pairs=array('_hbdp_term_id'=>$r['external_id'],'_hbdp_world'=>$r['themenwelt'],'_hbdp_short'=>$r['kurzdefinition'],'_hbdp_scope'=>$r['abgrenzung'],'_hbdp_synonyms'=>$r['synonyme'],'_hbdp_related'=>$r['verwandte_begriffe'],'_hbdp_sources'=>$r['quellen'],'_hbdp_verified'=>$r['last_verified_at'],'_hbdp_review_months'=>(int)$r['review_interval_months'],'_hbdp_seo_title'=>$r['seo_title'],'_hbdp_seo_description'=>$r['seo_description'],'_hbdp_primary_target'=>$r['primary_target']??array(),'_hbdp_validated'=>'1','_hbdp_approved'=>'0');
        foreach($pairs as $k=>$v){update_post_meta($id,$k,wp_slash($v)); if(!hbdp_glossary_meta_readback_matches($id,$k,$v)){$failure='Metadaten-Readback: '.$k;break;}}
        $post=get_post($id);
        if($failure!==''||!$post||$post->post_status!=='draft'||$post->post_title!==$r['begriff']||$post->post_content!==$r['facherklaerung']){$failure=$failure?:'Draft-Readback-Mismatch';break;}
    }
    if($failure!==''){foreach($created as $id)wp_delete_post($id,true);hbdp_glossary_redirect_msg('ABBRUCH + Rollback: '.$failure);}
    delete_transient($key);hbdp_glossary_redirect_msg('PASS: '.count($created).' neue, nicht veröffentlichte Entwürfe mit vollständigem Readback importiert.');
});
/** A previously approved live term is returned to draft if edits invalidate its review. */
add_action('save_post_hbdp_glossar_term',static function($id){
    static $guard=false;
    if($guard||wp_is_post_revision($id))return;
    $post=get_post($id);
    if(!$post||$post->post_status!=='publish')return;
    $valid=get_post_meta($id,'_hbdp_validated',true)==='1' && get_post_meta($id,'_hbdp_approved',true)==='1'
        && get_post_meta($id,'_hbdp_research_status',true)==='GEPRUEFT'
        && hash_equals((string)get_post_meta($id,'_hbdp_approval_hash',true),hash('sha256',hbdp_glossary_body_plain($post->post_content)))
        && hbdp_glossary_validate_record(hbdp_glossary_post_record($post))==='';
    if(!$valid){$guard=true;wp_update_post(array('ID'=>$id,'post_status'=>'draft'));$guard=false;}
},40);
