<?php
/**
 * Hab & Bewahr – einheitliches Artikelraster (ab 0.1.187).
 * Nur Darstellung normaler WP-Beitraege. Original-Inhalte, Quellen und Kategorien bleiben in WordPress.
 */
if (!defined('ABSPATH')) exit;

function hbdp_article_is_urgent($post) {
    if (!($post instanceof WP_Post)) return false;
    return strpos((string)$post->post_name, 'sturmschaden-am-dach-was-jetzt-tun-muster-') === 0;
}

function hbdp_article_slot_html($kind, $post_id) {
    if (!is_singular('post')) return '';
    $hook = $kind === 'banner' ? 'hbdp_article_auto_banner_html' : 'hbdp_article_product_cards_html';
    $output = apply_filters($hook, '', (int)$post_id, wp_get_post_categories((int)$post_id));
    if (!is_string($output) || trim($output) === '') return '';
    $safe = wp_kses_post($output);
    if (class_exists('WP_HTML_Tag_Processor')) {
        $processor = new WP_HTML_Tag_Processor($safe);
        while ($processor->next_tag('a')) {
            $rel = (string)$processor->get_attribute('rel');
            $processor->set_attribute('rel', trim($rel.' sponsored nofollow'));
        }
        $safe = $processor->get_updated_html();
    }
    if (trim($safe) === '') return '';
    $class = $kind === 'banner' ? 'hb-article-ad--banner' : 'hb-article-ad--product';
    return '<section class="hb-article-ad '.esc_attr($class).'" aria-label="Anzeige"><span class="hb-article-ad-label">Anzeige</span><div class="hb-article-ad-content">'.$safe.'</div></section>';
}

add_shortcode('hb_produkte', static function () {
    return is_singular('post') ? hbdp_article_slot_html('product', get_queried_object_id()) : '';
});
add_shortcode('hb_banner', static function () {
    return is_singular('post') ? hbdp_article_slot_html('banner', get_queried_object_id()) : '';
});

function hbdp_article_clean_content($post, &$toc = array()) {
    $html = apply_filters('the_content', (string)$post->post_content);
    // Die alten Musterplatzhalter erscheinen nie bei Besuchern; der echte Produktplatz ist rechts.
    $html = preg_replace('~<div(?=[^>]*\\bhb-affiliate-platzhalter\\b)[^>]*>.*?</div>~is', '', $html);
    $html = preg_replace('~<p[^>]*class=[^>]*hb-interne-links-redaktionell-offen[^>]*>.*?</p>~is', '', $html);
    // Quellen behalten wir im redaktionellen Ausgangstext, nicht in der oeffentlichen Darstellung.
    $html = preg_replace('~<p[^>]*class=[^>]*hb-quellen[^>]*>.*?</p>~is', '', $html);
    $toc = array();
    $counter = 0;
    $html = preg_replace_callback('~<h2\\b([^>]*)>(.*?)</h2>~is', static function ($m) use (&$counter, &$toc) {
        $counter++;
        $id = 'hb-abschnitt-'.$counter;
        if (preg_match('~\\bid=["\\\']([^"\\\']+)["\\\']~i', $m[1], $existing)) {
            $id = $existing[1];
            $open = '<h2'.$m[1].'>';
        } else {
            $open = '<h2'.$m[1].' id="'.esc_attr($id).'">';
        }
        $label = trim(wp_strip_all_tags($m[2]));
        if ($label !== '') $toc[] = array('id'=>$id,'label'=>$label);
        return $open.$m[2].'</h2>';
    }, $html);
    // Zwei unsichtbare mobile Einfügepunkte, NACH dem ersten inhaltlichen Abschnitt.
    // Banner erst im späteren Text. Keine zusätzlichen Werbungselemente im DOM.
    if (!hbdp_article_is_urgent($post) && get_post_meta($post->ID, '_hbdp_article_no_ads', true) !== '1') {
        $section_count = 0;
        $html = preg_replace_callback('~<h2\b[^>]*>~i', static function ($m) use (&$section_count) {
            $section_count++;
            if ($section_count === 2) return '<span class="hb-mobile-products-target" hidden aria-hidden="true"></span>'.$m[0];
            if ($section_count === 4) return '<span class="hb-mobile-banner-target" hidden aria-hidden="true"></span>'.$m[0];
            return $m[0];
        }, $html);
    }
    return $html;
}

function hbdp_article_demo_photo($post) {
    // Genau die fuenf tatsaechlichen Musterartikel, niemals ein pauschal falsches Fallback.
    $slug = (string)$post->post_name;
    $patterns = array(
        'private-ueberwachungskamera-was-ist-erlaubt-muster-' => array('topic-video-tuersprechanlage.webp', 'Video-Tuersprechanlage an einer Eingangstuer'),
        'wohnmobil-gegen-diebstahl-sichern-stellplatz-muster-' => array('scene-camper.webp', 'Wohnmobil auf einem privaten Stellplatz'),
        'wassermelder-vergleichen-alarm-funk-wasserstopp-muster-' => array('topic-62-wassermelder.webp', 'Wassermelder bei einer undichten Wasserleitung'),
        'rauchmelder-pruefen-sicher-kontrollieren-muster-' => array('photo-rauchmelder.webp', 'Rauchwarnmelder an der Zimmerdecke'),
        'sturmschaden-am-dach-was-jetzt-tun-muster-' => array('focus-wetter-sturm.webp', 'Sturmwolken ueber einem Wohnhaus'),
    );
    foreach ($patterns as $needle=>$photo) {
        if (strpos($slug,$needle) === 0) return $photo;
    }
    return null;
}

function hbdp_article_demo_products($post) {
    $slug = (string)$post->post_name;
    if (strpos($slug,'wohnmobil-gegen-diebstahl-sichern-stellplatz-muster-') === 0) {
        return array(array('lock','Lenkradkralle','Mechanische Wegfahrsicherung'),array('pin','GPS-Tracker','Ortung und Benachrichtigung'),array('bell','Alarmmelder','Warnung bei unbefugtem Zugang'));
    }
    if (strpos($slug,'wassermelder-vergleichen-') === 0) {
        return array(array('drop','Wassermelder','Alarm bei Feuchtigkeit'),array('wifi','Funk-Wassermelder','Warnung bei Abwesenheit'),array('shield','Absperrsystem','Schutz durch Wasserabschaltung'));
    }
    if (strpos($slug,'rauchmelder-pruefen-') === 0) {
        return array(array('bell','Rauchwarnmelder','Warnung bei Rauchentwicklung'),array('wifi','Vernetzter Melder','Gemeinsamer Alarm'),array('shield','Ersatz & Zubehör','Austausch nach Herstellerangabe'));
    }
    if (strpos($slug,'private-ueberwachungskamera-') === 0) {
        return array(array('camera','Sicherheitskamera','Geeigneter Bildausschnitt'),array('shield','Datenschutzfunktionen','Privatzonen und Zugriff'),array('bell','Türklingelkamera','Gezielte Besucherbenachrichtigung'));
    }
    return array(array('shield','Schutzlösungen','Bedarfsgerecht auswählen'),array('bell','Warntechnik','Risiken früh erkennen'),array('lock','Sicherungszubehör','Passend zum Einsatzgebiet'));
}

function hbdp_article_render_preview_products($post) {
    if (!current_user_can('manage_options') || hbdp_article_is_urgent($post)) return;
    $items=hbdp_article_demo_products($post);
    echo '<section class="hb-sidebar-card hb-sidebar-demo-products" aria-label="Affiliate-Designvorschau"><div class="hb-sidebar-heading"><h2>Passende Produkte</h2><span class="hb-demo-label">Designvorschau</span></div><p class="hb-sidebar-subnote">Beispielansicht – noch keine echten Partnerangebote</p>';
    foreach ($items as $p) {
        echo '<div class="hb-sidebar-demo-product"><div class="hb-sidebar-product-icon hb-icon-'.esc_attr($p[0]).'" aria-hidden="true">';
        echo esc_html(array('lock'=>'🔒','pin'=>'⌖','bell'=>'◉','drop'=>'◈','wifi'=>'◌','shield'=>'⬡','camera'=>'▣')[$p[0]] ?? '◉');
        echo '</div><div class="hb-sidebar-product-copy"><strong>'.esc_html($p[1]).'</strong><span>'.esc_html($p[2]).'</span><small>Produktkachel · Vorschau</small></div></div>';
    }
    echo '</section>';
}

function hbdp_article_render_sidebar($post, $toc, $category) {
    echo '<aside class="hb-article-sidebar" aria-label="Inhaltsuebersicht und passende Angebote">';
    // Reale Affiliate-Daten gewinnen: keine erfundenen Preise, Produkte oder Affiliate-Links.
    if (!hbdp_article_is_urgent($post)) {
        $products = hbdp_article_slot_html('product',(int)$post->ID);
        if ($products !== '') echo $products;
        else hbdp_article_render_preview_products($post);
    }
    // Keine redundante Inhaltsliste bei den kurzen Ratgeberartikeln.
    // Stattdessen reale, bereits veröffentlichte Artikel derselben Kategorie.
    if ($category instanceof WP_Term && function_exists('get_posts')) {
        $related = get_posts(array(
            'post_type'=>'post', 'post_status'=>'publish', 'category__in'=>array((int)$category->term_id),
            'post__not_in'=>array((int)$post->ID), 'posts_per_page'=>3, 'orderby'=>'date', 'order'=>'DESC',
            'suppress_filters'=>true
        ));
        $links = array();
        foreach ((array)$related as $related_post) {
            if (!($related_post instanceof WP_Post) || get_post_meta($related_post->ID, '_hbdp_demo', true)==='1') continue;
            $url = get_permalink($related_post->ID);
            $label = get_the_title($related_post->ID);
            if ($url && $label) $links[] = '<li><a href="'.esc_url($url).'">'.esc_html($label).'</a></li>';
        }
        if ($links) echo '<nav class="hb-sidebar-card hb-sidebar-related" aria-label="Weitere passende Ratgeber"><h2>Weiterlesen</h2><ul>'.implode('', $links).'</ul></nav>';
    }
    if ($category instanceof WP_Term) {
        echo '<section class="hb-sidebar-card hb-sidebar-more"><h2>Mehr zum Thema</h2><p>Weitere Informationen aus dem passenden Schutzbereich.</p><a href="'.esc_url(get_category_link($category->term_id)).'">'.esc_html($category->name).' ansehen <span aria-hidden="true">›</span></a></section>';
    }
    if (!hbdp_article_is_urgent($post)) {
        $banner = hbdp_article_slot_html('banner',(int)$post->ID);
        if ($banner !== '') echo $banner;
        elseif (current_user_can('manage_options')) {
            echo '<aside class="hb-sidebar-demo-banner" aria-label="Banner-Designvorschau"><span>DESIGNVORSCHAU · KEINE WERBUNG</span><strong>Mehr Schutz. Mehr Sicherheit.</strong><p>Platz für einen passenden Partnerbanner.</p></aside>';
        }
    }
    echo '</aside>';
}

function hbdp_render_article_page() {
    $post=get_queried_object();
    if (!($post instanceof WP_Post) || $post->post_type !== 'post') return;
    $categories=get_the_category($post->ID);
    $category=is_array($categories) && !empty($categories) ? reset($categories) : null;
    $has_cat=$category instanceof WP_Term;
    $toc=array();
    $content=hbdp_article_clean_content($post,$toc);
    ?>
    <main id="hauptinhalt" class="hbdp-frame hbdp-section hbdp-article hb-article-layout">
      <nav class="hb-article-breadcrumb hbdp-crumb" aria-label="Pfadnavigation">
        <a href="<?php echo esc_url(home_url('/')); ?>">Startseite</a><span aria-hidden="true">/</span>
        <?php if ($has_cat): ?><a href="<?php echo esc_url(get_category_link($category->term_id)); ?>"><?php echo esc_html($category->name); ?></a><span aria-hidden="true">/</span><?php endif; ?>
        <span aria-current="page"><?php echo esc_html(get_the_title($post)); ?></span>
      </nav>
      <div class="hb-article-columns">
        <article class="hb-article-main">
          <header class="hb-article-header">
            <h1><?php echo esc_html(get_the_title($post)); ?></h1>
          </header>
          <?php if (has_post_thumbnail($post->ID)): ?>
            <figure class="hb-article-photo"><?php echo get_the_post_thumbnail($post->ID,'large',array('loading'=>'eager','decoding'=>'async')); ?></figure>
          <?php elseif($demo=hbdp_article_demo_photo($post)): ?>
            <figure class="hb-article-photo"><img src="<?php echo esc_url(HBDP_URL.'assets/'.$demo[0]); ?>" alt="<?php echo esc_attr($demo[1]); ?>" loading="eager" decoding="async"></figure>
          <?php endif; ?>
          <div class="hb-article-reading hab-und-bewahr-beitrag"><?php echo $content; ?></div>
        </article>
        <?php hbdp_article_render_sidebar($post,$toc,$has_cat?$category:null); ?>
      </div>
    </main>
    <?php
}
