<?php
/** Exact read-only third-level page renderer: R2 hero markup reused as-is. */
if (!defined('ABSPATH')) exit;
function hbdp_r3_hero_claim($node){
    // Existing controlled category copy, never invented SEO keywords or an empty claim.
    $text=function_exists('hbdp_hub_top_copy') ? trim((string)hbdp_hub_top_copy($node)) : '';
    if ($text !== '') {
        $sentence=preg_split('/(?<=[.!?])\s+/u',$text,2)[0]??$text;
        $sentence=trim(strip_tags($sentence));
        // 0.1.112: Hero is a SHORT orientation line, not a copy of the long SEO intro.
        // Count Unicode characters rather than bytes; never truncate mid-word.
        if ($sentence!=='' && preg_match_all('/./us', $sentence)<=74) return $sentence;
        
    }
    $name=(string)($node['name']??'');
    return hbdp_is_insurance_r3($node)
        ? 'Versicherungsschutz auf einen Blick.'
        : 'Risiken erkennen und Schutz verbessern.';
}
function hbdp_render_r3_page($node){
    $photo=hbdp_is_insurance_r3($node)?hbdp_insurance_topic_photo($node):hbdp_area_matching_topic_photo($node);
    $photo_ok=($photo!=='' && hbdp_area_photo_ok($photo));
    $children=hbdp_children($node['id']);
    $parent=hbdp_node((string)($node['parent']??''));
    $world=$parent ? hbdp_node((string)($parent['parent']??'')) : null;
    $world_name=$world?hbdp_compass_display_name($world):'Schutz';
    $claim=hbdp_r3_hero_claim($node);
    echo '<main class="hbdp-area-demo hbdp-area-page hbdp-r3-page">';
    echo '<div class="hbdp-frame hbdp-area-demo-breadcrumb-top">';hbdp_breadcrumb($node);echo '</div>';
    if ($photo_ok){
        echo '<div class="hbdp-frame hbdp-area-demo-hero-frame"><header class="hbdp-area-demo-hero">';
        echo '<img src="'.esc_url(HBDP_URL.'assets/'.$photo).'" alt="" fetchpriority="high" decoding="async">';
        echo '<div class="hbdp-area-demo-shade" aria-hidden="true"></div><div class="hbdp-area-demo-hero-text">';
        echo '<span class="hbdp-area-demo-eyebrow">'.esc_html($world_name).' · Schutzthema</span>';
        echo '<h1>'.esc_html(hbdp_compass_display_name($node)).'</h1><p>'.esc_html($claim).'</p>';
        echo '</div></header></div>';
    } else {
        // Unknown future R3: no fake photo and no unrelated-area fallback.
        echo '<div class="hbdp-frame hbdp-r3-unpictured"><span class="hbdp-area-demo-eyebrow">'.esc_html($world_name).' · Schutzthema</span><h1>'.esc_html(hbdp_compass_display_name($node)).'</h1><p>'.esc_html($claim).'</p></div>';
    }
    echo '<div class="hbdp-frame hbdp-area-demo-inner">';
    hbdp_render_category_top_text($node);
    echo '<div class="hbdp-hub-layout"><div class="hbdp-hub-main">';
    if ($children){
        echo '<h2>Kategorien &amp; Unterbereiche</h2><div class="hbdp-grid">';
        foreach($children as $child){if(($child['id']??'')===($node['id']??''))continue;hbdp_display_card($child);}
        echo '</div>';
    }else echo '<p class="hbdp-endpoint">Hier endet die Kategoriennavigation. Passende Beiträge erscheinen nach Veröffentlichung.</p>';
    echo '<div class="hbdp-divider"></div><div class="hbdp-section-head"><div><span class="hbdp-eyebrow">BEITRAGSVORSCHAU</span><h2>So sehen Artikelkarten aus</h2><p>Testartikel erscheinen nur dort, wo sie thematisch zugeordnet sind. Sonst bleibt ein Layoutplatzhalter.</p></div></div>';
    echo '<div class="hbdp-stories">';
    if(!hbdp_demo_articles($node['id']))echo '<div class="hbdp-story-placeholder">Hier erscheinen später die passenden Ratgeber zu <strong>'.esc_html(hbdp_compass_display_name($node)).'</strong>. Der Platz ist für die Layoutvorschau reserviert.</div>';
    echo '</div></div><aside class="hbdp-hub-aside"><div class="hbdp-aside-box"><span class="hbdp-eyebrow">ZUM ORIENTIEREN</span><h3>Schutz beginnt mit Wissen.</h3><p>Verständliche Themenübersichten, praktische Hinweise und hilfreiche Vergleiche.</p></div>';
    echo '<div class="hbdp-aside-ad"><small>ANZEIGENFLÄCHE · LAYOUTPLATZHALTER</small><strong>Hier könnte deine Werbung stehen.</strong><span>Der Werbeplatz ist noch nicht verkauft und enthält keinen Werbecode.</span></div></aside></div></div></main>';
}
