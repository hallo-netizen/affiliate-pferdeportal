<?php
/** Glossar batch 093: add-only draft import, no publication or JSON frontend shadow-copy. */
if (!defined('ABSPATH')) exit;
const HBDP_GLOSS_093_OPTION = 'hbdp_glossar_batch_093';
function hbdp_gloss_093_seed() {
    $file=HBDP_ROOT.'data/glossary-batch-093.json';
    if (!is_readable($file)) return array('error'=>'Glossar-Batch 093 fehlt');
    $raw=json_decode(file_get_contents($file),true);
    if(!is_array($raw)||($raw['contract_version']??'')!=='HB_GLOSSARY_BATCH_V1'||!is_array($raw['terms']??null)||count($raw['terms'])!==25) return array('error'=>'Glossar-Batch 093 ungültig');
    $ids=array();$slugs=array();
    foreach ($raw['terms'] as $i=>$r) {
        if(!is_array($r)||!isset($r['external_id'],$r['slug'],$r['recherche_status']))return array('error'=>'Batch-Datensatz beschädigt: '.($i+1));
        // Editorial drafts must remain drafts, but must still meet every other strict format rule.
        if($r['recherche_status']!=='ENTWURF'||!empty($r['kanonisch_als_einzelseite']))return array('error'=>'Unerlaubter Freigabestatus: '.$r['slug']);
        $formal=$r;
        $formal['recherche_status']='GEPRUEFT';
        $formal['facherklaerung']=implode("\n\n",(array)($r['fachtext']??array()));
        $formal['quellen']=array($r['quelle']??array());
        $formal['last_verified_at']=$r['source_date_checked']??'';
        $formal['primary_target']=array();
        $reason=hbdp_glossary_validate_record($formal);
        if($reason!=='')return array('error'=>'Textvertrag '.$r['slug'].': '.$reason);
        if(isset($ids[$r['external_id']])||isset($slugs[$r['slug']]))return array('error'=>'Doppelte Begriffs-ID im Batch: '.$r['slug']);
        $ids[$r['external_id']]=1;$slugs[$r['slug']]=1;
    }
    return array('terms'=>$raw['terms'],'fingerprint'=>hash('sha256',wp_json_encode($raw['terms'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)));
}
/** Admin GET only, after historical seed migration; one bounded batch. */
add_action('admin_init',static function(){
    if(!current_user_can('manage_options') || wp_doing_ajax() || (defined('DOING_CRON')&&DOING_CRON)
       || (defined('REST_REQUEST')&&REST_REQUEST) || ($_SERVER['REQUEST_METHOD']??'GET')!=='GET'
       || !hbdp_glossary_import_completed() || empty(get_option(HBDP_GLOSS_092_OPTION, array())['complete'])) return;
    $previous=get_option(HBDP_GLOSS_093_OPTION,array());
    if(is_array($previous)&&!empty($previous['complete'])&& (int)($previous['done']??0)===25)return;
    $seed=hbdp_gloss_093_seed();
    if(!empty($seed['error'])){update_option(HBDP_GLOSS_093_OPTION,array('done'=>0,'error'=>$seed['error']),false);return;}
    // Check before writing to prevent category and editorial intent collisions.
    $status=hbdp_glossary_import_progress($seed);
    if($status['error']!=='') {update_option(HBDP_GLOSS_093_OPTION,array('done'=>$status['done'],'error'=>$status['error']),false);return;}
    foreach($status['pending'] as $r) {
        $reason=hbdp_glossary_live_rule(array('begriff'=>$r['begriff'],'primary_target'=>array()));
        if($reason!=='') {update_option(HBDP_GLOSS_093_OPTION,array('done'=>$status['done'],'error'=>$reason.' – Import angehalten, keine neuen Beiträge angelegt'),false);return;}
    }
    if($status['pending']) {
        $err=hbdp_glossary_import_batch($status['pending']);
        if($err!==''){update_option(HBDP_GLOSS_093_OPTION,array('done'=>$status['done'],'error'=>$err),false);return;}
        $status=hbdp_glossary_import_progress($seed);
    }
    $done=$status['done'];$complete=$status['error']==='' && $done===25 && !$status['pending'];
    update_option(HBDP_GLOSS_093_OPTION,array('done'=>$done,'total'=>25,'complete'=>$complete,'error'=>$status['error'],
        'fingerprint'=>$seed['fingerprint'],'status'=>'ENTWURF_NOINDEX'),false);
},25);
add_action('admin_notices',static function(){
    if(!current_user_can('manage_options'))return;
    $s=get_option(HBDP_GLOSS_093_OPTION,array());if(!is_array($s)||!isset($s['done']))return;
    $done=(int)($s['done']??0);$error=(string)($s['error']??'');$all=!empty($s['complete']);
    $screen=function_exists('get_current_screen')?get_current_screen():null;
    if($error===''&&$all&&(!$screen||$screen->id!=='edit-hbdp_glossar_term'))return;
    $cls=$error!==''?'error':($all?'success':'info');
    echo '<div class="notice notice-'.esc_attr($cls).'"><p><strong>Glossar-Batch 0.1.93:</strong> '.esc_html((string)$done).'/25 neue Entwürfe. '.
       ($error!==''?esc_html($error):($all?'Vollständig in WordPress übernommen; keine Veröffentlichung.':'Erneuter normaler Backend-Aufruf setzt fort.')).'</p></div>';
});
