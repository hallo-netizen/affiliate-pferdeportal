<?php
/**
 * In-place footer bridge for the already-installed Hab & Bewahr design plugin.
 * Not a standalone plugin; loaded by the existing design plugin after installation.
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('hbdp_footer_bridge_register_areas')) {
    function hbdp_footer_bridge_register_areas() {
        if (!function_exists('register_sidebar')) {
            return;
        }
        global $wp_registered_sidebars;
        for ($i = 1; $i <= 4; $i++) {
            $id = 'footer-widget-' . $i;
            if (!empty($wp_registered_sidebars[$id])) {
                continue;
            }
            register_sidebar(array(
                'name' => sprintf('Hab & Bewahr – Footer %d', $i),
                'id' => $id,
                'before_widget' => '<section id="%1$s" class="widget %2$s">',
                'after_widget' => '</section>',
                'before_title' => '<h3 class="widget-title">',
                'after_title' => '</h3>',
            ));
        }
    }
}

if (!function_exists('hbdp_footer_bridge_content_is_useful')) {
    function hbdp_footer_bridge_content_is_useful($html) {
        // A mere widget title does not prove that a migrated nav menu has links.
        return is_string($html) && trim($html) !== ''
            && (bool) preg_match('~<(?:a|p|ul|ol|img|figure|address|form|blockquote)\b~i', $html)
            && trim(wp_strip_all_tags($html)) !== '';
    }
}

if (!function_exists('hbdp_footer_bridge_fallback_menu')) {
    function hbdp_footer_bridge_fallback_menu($column) {
        if (!function_exists('wp_get_nav_menus') || !function_exists('wp_nav_menu')) {
            return '';
        }
        $labels = array(
            1 => array('Informationen'),
            2 => array('Rechtliches'),
            3 => array('footer-anzeigen', 'Anzeigenmarkt'),
        );
        if (empty($labels[$column])) {
            return '';
        }
        foreach ((array) wp_get_nav_menus() as $menu) {
            if (!is_object($menu) || empty($menu->term_id) || empty($menu->name)) {
                continue;
            }
            if (!in_array(strtolower((string) $menu->name), array_map('strtolower', $labels[$column]), true)) {
                continue;
            }
            $links = wp_nav_menu(array(
                'menu' => (int) $menu->term_id,
                'container' => false,
                'echo' => false,
                'fallback_cb' => false,
                'depth' => 2,
            ));
            if (hbdp_footer_bridge_content_is_useful($links)) {
                return '<section class="widget widget_nav_menu"><h3 class="widget-title">'
                    . esc_html($column === 3 ? 'Anzeigenmarkt' : $menu->name)
                    . '</h3>' . $links . '</section>';
            }
        }
        return '';
    }
}

if (!function_exists('hbdp_footer_bridge_render')) {
    /** Returns false without output when no migrated content can be rendered. */
    function hbdp_footer_bridge_render() {
        $stored = function_exists('wp_get_sidebars_widgets') ? (array) wp_get_sidebars_widgets() : array();
        $columns = array();
        $have_content = false;
        for ($i = 1; $i <= 4; $i++) {
            $area = 'footer-widget-' . $i;
            $html = '';
            if (!empty($stored[$area]) && is_array($stored[$area]) && function_exists('dynamic_sidebar')) {
                ob_start();
                $rendered = dynamic_sidebar($area);
                $out = (string) ob_get_clean();
                if ($rendered && hbdp_footer_bridge_content_is_useful($out)) {
                    $html = $out;
                }
            }
            if ($html === '') {
                $html = hbdp_footer_bridge_fallback_menu($i);
            }
            $columns[] = $html;
            if ($html !== '') {
                $have_content = true;
            }
        }
        if (!$have_content) {
            return false;
        }
        echo '<footer class="hbdp-footer hbdp-footer--imported" role="contentinfo">';
        echo '<div class="hbdp-frame hbdp-footer-grid hbdp-footer-grid--imported">';
        foreach ($columns as $column) {
            echo '<div class="hbdp-footer-import-column">' . $column . '</div>'; // Trusted WP widget/menu rendering.
        }
        echo '</div></footer>';
        echo '<style id="hbdp-footer-import-layout">'
           . '.hbdp-footer-grid--imported{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:22px 32px;align-items:start}'
           . '.hbdp-footer--imported .hbdp-footer-import-column{min-width:0}'
           . '.hbdp-footer--imported .widget,.hbdp-footer--imported .menu{margin:0}'
           . '.hbdp-footer--imported .widget-title{margin:0 0 13px;font-size:16px;line-height:1.3;font-weight:700}'
           . '.hbdp-footer--imported ul{margin:0;padding:0;list-style:none}'
           . '.hbdp-footer--imported li{margin:0 0 9px;padding:0}'
           . '.hbdp-footer--imported a{display:inline-block;text-decoration:none}'
           . '.hbdp-footer--imported a:hover{text-decoration:underline}'
           . '@media(max-width:900px){.hbdp-footer-grid--imported{grid-template-columns:repeat(2,minmax(0,1fr))}}'
           . '@media(max-width:600px){.hbdp-footer-grid--imported{grid-template-columns:1fr}}'
           . '</style>';
        return true;
    }
}
