<?php
/**
 * Schutzkompass V1: curated editorial navigation, NO new WordPress content owner.
 * Uses the existing core:hub WP page with query-only, noindex detail views.
 * Reads the authoritative category-tree snapshot; no database writes or new SEO taxonomy.
 */
if (!defined('ABSPATH')) exit;

function hbdp_compass_catalog() {
    return array(
      'haus-wohnung'=>array('group'=>'objekt','title'=>'Haus & Wohnung','subtitle'=>'Zuhause rundum schützen','photo'=>'scene-security.webp',
        'intro'=>'Ob Eigentumswohnung, Reihenhaus oder freistehendes Haus: Schutz beginnt nicht bei einer bestimmten Gefahr, sondern bei der eigenen Wohnsituation. Welche Zugänge sind besonders wichtig? Was geschieht bei Wasser, Feuer oder Stromausfall? Wir verbinden die passenden Fachthemen zu einem verständlichen Überblick, ohne separate Kaufberatungen zu wiederholen.',
        'check'=>array('Zugänge, Fenster und Gemeinschaftsbereiche berücksichtigen','Wasserleitungen, Rauchwarnung und elektrische Technik mitdenken','Abwesenheiten und Zuständigkeiten klären'),
        'queries'=>array('haustür','fenster','wohnung','einbruch','rauchwarn','wassermelder','haustechnik','schloss','haustürschloss','starkregen','keller','stromausfall')),
      'mietwohnung'=>array('group'=>'objekt','title'=>'Mietwohnung','subtitle'=>'Sichern ohne große Umbauten','photo'=>'insurance-hausratversicherung.webp',
        'intro'=>'In einer Mietwohnung gibt es andere Handlungsspielräume als im Eigentum. Manche Schutzmaßnahmen lassen sich ohne Bohren oder Austausch von Bauteilen umsetzen, andere benötigen eine Abstimmung mit der Vermietung. Der Einstieg bündelt Einbruchvorsorge, Wasserschäden, Rauchwarnung und praktische Regeln für das Zusammenleben im Haus.',
        'check'=>array('Vor baulichen Änderungen Erlaubnis und Zuständigkeit klären','Nachrüstlösungen ohne Eingriff in die Bausubstanz prüfen','Wasserschäden, Rauchwarnung und Nachbarschaft mitberücksichtigen'),
        'queries'=>array('mietwohnung','ohne bohren','wohnungseingang','fenster','wasserschaden','rauchmelder','schlüssel')),
      'garten-grundstueck'=>array('group'=>'objekt','title'=>'Garten & Grundstück','subtitle'=>'Garten und Grundstück schützen','photo'=>'scene-garden.webp',
        'intro'=>'Im Garten treffen ganz unterschiedliche Risiken aufeinander: unbefugte Zugänge, Diebstahl von Geräten, Schäden an Zäunen, Starkregen und Frost. Statt einzelne Gefahrwelten nacheinander zu durchsuchen, führt dieser Einstieg zu passenden Hinweisen für Gartentor, Laube, Beleuchtung, Technik und offen gelagerte Gegenstände.',
        'check'=>array('Zugänge, Schuppen und bewegliche Gartenwerte erfassen','Wetter, Wasserablauf und Frost nicht vergessen','Außentechnik, Kabel und Beleuchtung schützen'),
        'queries'=>array('garten','gartenhaus','grundstück','zaun','gartentor','schuppen','mähroboter','außentechnik','sturm')),
      'garage-keller'=>array('group'=>'objekt','title'=>'Garage & Keller','subtitle'=>'Sicher lagern und vorbeugen','photo'=>'scene-garage.webp',
        'intro'=>'Garage und Keller sind oft Abstellfläche, Technikraum und Zugang zum Gebäude zugleich. Fahrräder, Werkzeuge, elektrische Geräte und Leitungen stehen dicht beieinander. Der Überblick bündelt geeignete Zugangsmaßnahmen, Rückstau- und Feuchteschutz, Brandschutz sowie sichere Aufbewahrung – mit Links zu den zuständigen Detailthemen.',
        'check'=>array('Türen, Tore und die Lagerung wertvoller Dinge prüfen','Abläufe, Rückstau und Feuchtigkeit berücksichtigen','Elektrik, Akkus und brennbare Gegenstände getrennt bewerten'),
        'queries'=>array('garage','garagentor','keller','rückstau','werkzeug','feuchtigkeit','akku','lager')),
      'ferienhaus-leerstand'=>array('group'=>'objekt','title'=>'Ferienhaus & Leerstand','subtitle'=>'Geschützt auch bei Abwesenheit','photo'=>'scene-winter.webp',
        'intro'=>'Wenn niemand vor Ort ist, werden kleine Störungen leicht zu großen Schäden. Der Einstieg betrachtet Schlüsselübergabe, Kontrolle bei Abwesenheit, Wasserabsperrung, Frost, Einbruch und technische Warnmeldungen gemeinsam. So lässt sich ein praktikabler Plan entwickeln, der zum tatsächlichen Nutzungsrhythmus des Objekts passt.',
        'check'=>array('Schlüssel und regelmäßige Kontrollgänge organisieren','Wasser, Heizung und Frostschutz vor Abreise prüfen','Warnmeldungen und Hilfe vor Ort klären'),
        'queries'=>array('ferienhaus','leerstand','abwesenheit','frost','fernüberwachung','kontrolle','schlüsselübergabe')),
      'camping-wohnmobil'=>array('group'=>'objekt','title'=>'Camping & Wohnmobil','subtitle'=>'Camper sicher abstellen','photo'=>'scene-camper.webp',
        'intro'=>'Ein Wohnmobil ist Fahrzeug und Unterkunft in einem. Auf Reise, Stellplatz oder im Winterlager unterscheiden sich die Risiken deutlich. Wir verbinden sichere Zugänge, Abstellung, Gas und Rauchwarnung, Akkus, Witterung sowie Schutz vor Beschädigung zu einem übersichtlichen Ratgeberweg – ohne dieselben Produktvergleiche ein zweites Mal zu schreiben.',
        'check'=>array('Türen, Fenster und Außenstauraum prüfen','Gas, Rauchwarnung und Akkus sicher betreiben','Schutz bei längerer Abstellung organisieren'),
        'queries'=>array('wohnmobil','wohnwagen','camper','camping','stellplatz','gasflaschen','vorzelt','winterlager')),
      'boote-anhaenger'=>array('group'=>'objekt','title'=>'Boote & Anhänger','subtitle'=>'Boote und Anhänger schützen','photo'=>'scene-boat.webp',
        'intro'=>'Boote und Anhänger wechseln oft zwischen Nutzung, Transport und längerer Abstellung. Sicherung, Wettereinfluss und technische Störungen hängen dabei zusammen. Dieser Einstieg verbindet Trailer-, Außenborder- und Liegeplatzschutz mit Hinweisen zu Feuchtigkeit, Strom, Brandrisiken und Aufbewahrung, je nachdem, was tatsächlich zum Objekt passt.',
        'check'=>array('Trailer, Kupplung, Außenborder und Zubehör sichern','Wetter, Feuchtigkeit und Bordelektrik prüfen','Liegeplatz und Winterlager auf Kontrolle und Zugang abstimmen'),
        'queries'=>array('boot','außenborder','trailer','anhänger','liegeplatz','bootsakku','bordgas','winterlager')),
      'fahrrad-fahrzeuge'=>array('group'=>'objekt','title'=>'Fahrräder & Fahrzeuge','subtitle'=>'Fahrzeuge sicher abstellen','photo'=>'new-vehicle.webp',
        'intro'=>'Fahrrad, E-Bike, Motorrad und Privatwagen sind nicht nur unterwegs gefährdet. Auch Abstellort, Ladetechnik, Vandalismus und längere Standzeiten sind wichtig. Hier werden die passenden Schutzthemen nach typischen Nutzungssituationen zusammengeführt, damit Sie nicht zwischen Diebstahl, Brand und technischen Ausfällen springen müssen.',
        'check'=>array('Abstellort und mechanische Sicherung aufeinander abstimmen','Akkus, Ladevorgänge und Fahrzeugelektrik beachten','Längere Standzeiten und Schadenfälle vorbereiten'),
        'queries'=>array('fahrrad','e-bike','motorrad','oldtimer','privatwagen','fahrzeug','akku','katalysator')),
      'kleine-betriebe'=>array('group'=>'objekt','title'=>'Kleine Betriebe','subtitle'=>'Kleine Betriebe schützen','photo'=>'scene-shop.webp',
        'intro'=>'Persönlich geführte Betriebe brauchen verständliche Lösungen für Kundenflächen, Zutritt, Schaufenster und Betriebstechnik. Bei einem Schaden geht es zugleich um den laufenden Betrieb. Dieser Einstieg verknüpft Sachschutz, Prävention, Notfallorganisation und die Suche nach passenden Fachbetrieben – ohne große Unternehmenssicherheit zu behandeln.',
        'check'=>array('Eingang, Schaufenster und sensible Räume erfassen','Wasser-, Strom- und Brandrisiken im Betrieb mitdenken','Notfallkontakte und Fortführung des Betriebs planen'),
        'queries'=>array('laden','salon','praxis','schaufenster','kleinbetrieb','geschäft','betriebsunterbrechung','werkstatt')),
      'vereine-sportplaetze'=>array('group'=>'objekt','title'=>'Vereine & Sportplätze','subtitle'=>'Vereinsanlagen schützen','photo'=>'scene-playground.webp',
        'intro'=>'Vereinsheim, Sportplatz und Geräteschuppen werden oft von wechselnden Personen genutzt. Zuständigkeiten, Schlüssel, Wetterschäden und Sachbeschädigung sind daher besonders wichtig. Die Seite verbindet die passenden Detailthemen zu einer praktischen Einstiegshilfe für kleine Vereine und persönlich organisierte Anlagen.',
        'check'=>array('Schlüsselvergabe und Verantwortliche festlegen','Inventar, Tore, Zäune und Vereinsräume prüfen','Kontrollen nach Unwetter und bei Nutzungspausen organisieren'),
        'queries'=>array('verein','sportplatz','vereinsheim','clubhaus','sportgerät','zaun','reitanlage')),
      'werkstatt-hobbyraum'=>array('group'=>'objekt','title'=>'Werkstatt & Hobbyraum','subtitle'=>'Werkstatt und Hobbyraum sichern','photo'=>'scene-workshop.webp',
        'intro'=>'In Hobbyraum und kleiner Werkstatt sind wertvolle Gegenstände, elektrische Geräte und manchmal leicht entzündliche Materialien versammelt. Dieser Einstieg hilft, sinnvolle Schutzmaßnahmen übergreifend zu planen: sicherer Zutritt, geordnete Lagerung, Brandvorbeugung und Verhalten bei Störungen oder Schäden.',
        'check'=>array('Türen, Fenster und wertvolles Werkzeug absichern','Elektrik, Akkus und Brandlasten durchsehen','Lagerbereiche gegen Feuchtigkeit und Wasser prüfen'),
        'queries'=>array('werkstatt','hobbyraum','werkzeug','lager','elektro','akkulager','schuppen')),
      'unterwegs-abwesend'=>array('group'=>'situation','title'=>'Urlaub & Abwesenheit','subtitle'=>'Gut vorbereitet verreisen','photo'=>'scene-gate.webp',
        'intro'=>'Kurzurlaub, längere Reise oder selten genutzte Zweitwohnung: Vor jeder Abwesenheit sollten mehrere Risiken zusammen geprüft werden. Eine organisierte Übergabe, geeignete Kontrolle und die richtige Einstellung der Haustechnik verhindern, dass ein kleiner Defekt unbemerkt bleibt. Hier finden Sie die relevanten Fachthemen an einem Ort.',
        'check'=>array('Zugänge, Fenster und Schlüsselübergabe regeln','Wasser, Heizung und Warnmeldungen prüfen','Kontaktperson und Verhalten im Notfall festlegen'),
        'queries'=>array('abwesenheit','leerstand','ferienhaus','frost','schlüssel','fernüberwachung','wassermelder','einbruch')),
      'nach-einem-schaden'=>array('group'=>'situation','title'=>'Nach einem Schaden','subtitle'=>'Richtig handeln und dokumentieren','photo'=>'photo-schaden-dokumentation.webp',
        'intro'=>'Nach Einbruch, Wasserschaden, Brand oder mutwilliger Beschädigung hilft eine klare Reihenfolge. Vorrang haben Gefahrenabwehr und die Sicherung betroffener Personen. Danach folgen Dokumentation, geeignete Fachhilfe und die weitere Schadenbearbeitung. Die Seite verweist auf die jeweils zuständigen fachlichen Anleitungen und Stellen.',
        'check'=>array('Menschen schützen und akute Gefahren beseitigen lassen','Schäden nachvollziehbar dokumentieren','Reparaturen, Versicherungsweg und Fachhilfe koordinieren'),
        'queries'=>array('schaden','vandalismus','wasserschaden','einbruch','brandnotfall','notverschluss','dokumentieren')),
      'vorsorge-planen'=>array('group'=>'situation','title'=>'Schutzmaßnahmen planen','subtitle'=>'Das Wichtigste zuerst','photo'=>'start-hero.webp',
        'intro'=>'Wer sein Eigentum sicherer machen möchte, muss nicht alles auf einmal kaufen. Sinnvoller ist eine Bestandsaufnahme: Welche Werte und Zugänge sind betroffen? Was ist wahrscheinlich und welche Folgen wären besonders belastend? Daraus entsteht eine Prioritätenliste, die bauliche, technische und organisatorische Maßnahmen miteinander verbindet.',
        'check'=>array('Objekte und verwundbare Punkte auflisten','Risiken nach Folgen und Machbarkeit priorisieren','Passende Maßnahmen und Zuständigkeiten festhalten'),
        'queries'=>array('beratung','schutz','nachrüsten','vorsorge','überwachung','sichern','wartung')),
      'wetter-saison'=>array('group'=>'situation','title'=>'Wetter & Saisonwechsel','subtitle'=>'Vorsorge für jede Jahreszeit','photo'=>'scene-weather.webp',
        'intro'=>'Winterfrost, Starkregen, Sturm oder große Sommerhitze betreffen verschiedene Teile eines Objekts. Wer rechtzeitig prüft, kann Schwachstellen entdecken und notwendige Wartung einplanen. Dieser Einstieg kombiniert saisonale Kontrolle, Entwässerung, Frostschutz, Außenanlagen und gegebenenfalls die Vorbereitung von Fahrzeugen und Freizeitobjekten.',
        'check'=>array('Wetterwarnungen und typische Schwachstellen beachten','Entwässerung, Dach und Außenanlagen prüfen','Frostschutz und saisonale Stilllegung organisieren'),
        'queries'=>array('sturm','hagel','starkregen','frost','hitze','winter','regen','dachentwässerung')),
      'umbau-nachruestung'=>array('group'=>'situation','title'=>'Umbau & Nachrüstung','subtitle'=>'Sicher nachrüsten und umbauen','photo'=>'scene-tech.webp',
        'intro'=>'Bei Renovierung oder Modernisierung lassen sich Schutzmaßnahmen häufig mitplanen, ohne später alles erneut öffnen zu müssen. Entscheidend sind passende Anschlüsse, sichere Zugänge, Entwässerung und die Abstimmung mit Fachleuten. Der Kompass führt zu vorhandenen Themen und vermeidet pauschale Produktempfehlungen ohne Kenntnis des Gebäudes.',
        'check'=>array('Bauteile und vorhandene Technik vor Eingriffen prüfen','Rechtliche und bauliche Voraussetzungen klären','Nachrüstung und Wartung gemeinsam betrachten'),
        'queries'=>array('nachrüsten','montage','installation','fenster','tür','einbau','anschluss','abdichtung')),
      'technik-ausfall'=>array('group'=>'situation','title'=>'Technikstörung & Stromausfall','subtitle'=>'Auf Ausfälle vorbereitet sein','photo'=>'scene-electric.webp',
        'intro'=>'Strom, Heizung, Pumpen und vernetzte Warnsysteme können ausfallen. Ob ein Defekt nur unbequem oder ein ernstes Risiko ist, hängt von Nutzung und Objekt ab. Hier finden Sie passende Fachthemen für Warnmeldungen, Notstrom, sichere Wiederinbetriebnahme und die Kontrolle empfindlicher Geräte nach einer Störung.',
        'check'=>array('Kritische Verbraucher und Notfallkontakte bestimmen','Warnmeldungen und sichere Ersatzverfahren organisieren','Wiederanlauf nach Ausfall fachgerecht prüfen'),
        'queries'=>array('stromausfall','notstrom','technik','heizung','pumpe','warnmelder','wiederanlauf')),
      'aeltere-menschen'=>array('group'=>'situation','title'=>'Sicherheit im Alter','subtitle'=>'Risiken im Alltag verringern','photo'=>'new-door.webp',
        'intro'=>'Mit zunehmendem Alter können Bedienbarkeit, erreichbare Hilfe und klare Abläufe wichtiger werden als komplexe Technik. Der Einstieg bündelt passende Aspekte zu Zutritt, Warnsystemen, Schlüsselorganisation und verlässlicher Unterstützung. Welche Maßnahmen sinnvoll sind, hängt immer von Wohnsituation und persönlichen Wünschen ab.',
        'check'=>array('Einfach bedienbare Zugänge und Melder bevorzugen','Notfallkontakte und Schlüsselregelung klären','Privatsphäre und Selbstständigkeit respektieren'),
        'queries'=>array('senior','notruf','hausnotruf','schlüssel','warnmelder','tür','zugang')),
      'unterwegs-stellplatz'=>array('group'=>'situation','title'=>'Stellplatz & Winterlager','subtitle'=>'Sicher parken und überwintern','photo'=>'scene-camping.webp',
        'intro'=>'Längere Abstellzeiten bringen andere Anforderungen als die tägliche Nutzung. Diebstahl, Witterung, Feuchtigkeit und beschädigte Technik können unbemerkt bleiben. Der Kompass hilft, die Vorbereitung von Campern, Booten, Anhängern und privaten Fahrzeugen mit geeigneter Kontrolle und klarer Zuständigkeit zu verbinden.',
        'check'=>array('Zutritt und Sicherung des Abstellplatzes prüfen','Batterien, Feuchtigkeit und Wetter berücksichtigen','Kontrolltermine und Notfallkontakte festlegen'),
        'queries'=>array('stellplatz','winterlager','wohnmobil','boot','anhänger','oldtimer','abstellung')),
    );
}

function hbdp_compass_current_slug() {
    if (hbdp_for_query() !== 'core:hub') return '';
    $slug=isset($_GET['schutzkompass'])?sanitize_key(wp_unslash((string)$_GET['schutzkompass'])):'';
    return $slug!=='' && isset(hbdp_compass_catalog()[$slug]) ? $slug : '';
}
function hbdp_compass_base_url() {
    $hub=hbdp_node('core:hub');
    return $hub ? hbdp_nav_url($hub) : '';
}
function hbdp_compass_item_url($slug) {
    $base=hbdp_compass_base_url();
    return $base!==''?add_query_arg(array('schutzkompass'=>$slug),$base):'';
}
function hbdp_compass_display_name($node){
    if(!is_array($node))return '';
    if(($node['id']??'')==='core:hub')return 'Schutzkompass';
    return hbdp_display_category_name($node);
}
/** Pick only mapped public C2.2 topic pages; no synthetic URLs or new posts. */
function hbdp_compass_matches($item, $max=10) {
    $results=array();
    foreach(hbdp_all_nodes() as $n) {
        if(!is_array($n) || ($n['type']??'')!=='page' || !hbdp_nav_is_c22($n))continue;
        $parent=hbdp_node((string)($n['parent']??''));
        if(!is_array($parent) || !hbdp_area_is_level2($parent))continue;
        $name=function_exists('mb_strtolower')?mb_strtolower((string)($n['name']??''),'UTF-8'):strtolower((string)($n['name']??''));
        $parentname=function_exists('mb_strtolower')?mb_strtolower((string)($parent['name']??''),'UTF-8'):strtolower((string)($parent['name']??''));
        $score=0;
        foreach($item['queries'] as $term){
            $term=function_exists('mb_strtolower')?mb_strtolower((string)$term,'UTF-8'):strtolower((string)$term);
            if($term===''||strlen($term)<4)continue;
            if(strpos($name,$term)!==false)$score+=4;
            elseif(strpos($parentname,$term)!==false)$score+=1;
        }
        if($score<4)continue; // no generic parent-only matches
        $world=hbdp_node((string)($parent['parent']??''));
        $url=hbdp_nav_url($n);
        if($url===''||!is_array($world))continue;
        $results[]=array('node'=>$n,'url'=>$url,'world'=>(string)($world['name']??''),'world_id'=>(string)($world['id']??''),'score'=>$score);
    }
    usort($results,static function($a,$b){return ($b['score']<=>$a['score']) ?: strcmp((string)$a['node']['name'],(string)$b['node']['name']);});
    $selected=array();$by_world=array();$seen_urls=array();
    foreach($results as $r) {
        $w=$r['world_id'];
        if(isset($seen_urls[$r['url']])||($by_world[$w]??0)>=3)continue;
        $selected[]=$r;$seen_urls[$r['url']]=true;$by_world[$w]=($by_world[$w]??0)+1;
        if(count($selected)>=$max)break;
    }
    return $selected;
}

function hbdp_compass_card($slug,$item) {
    $url=hbdp_compass_item_url($slug);
    if($url==='')return;
    $img=HBDP_ROOT.'assets/'.$item['photo'];
    echo '<a class="hbdp-compass-card" href="'.esc_url($url).'">';
    if(is_file($img))echo '<img src="'.esc_url(HBDP_URL.'assets/'.$item['photo']).'" alt="" loading="lazy" decoding="async">';
    echo '<span class="hbdp-compass-card-copy"><strong>'.esc_html($item['title']).'</strong><small>'.esc_html($item['subtitle']).'</small><span>Entdecken <span aria-hidden="true">→</span></span></span></a>';
}
function hbdp_compass_crumb($current='') {
    echo '<nav class="hbdp-crumb hbdp-compass-crumb" aria-label="Brotkrumennavigation"><a href="'.esc_url(home_url('/')).'">Startseite</a><span aria-hidden="true">/</span>';
    $magazine=function_exists('hbdp_glossary_magazine_url')?hbdp_glossary_magazine_url():'';
    if($magazine!=='')echo '<a href="'.esc_url($magazine).'">Magazin</a>';
    else echo '<span>Magazin</span>';
    echo '<span aria-hidden="true">/</span>';
    if($current!=='')echo '<a href="'.esc_url(hbdp_compass_base_url()).'">Schutzkompass</a><span aria-hidden="true">/</span><span aria-current="page">'.esc_html($current).'</span>';
    else echo '<span aria-current="page">Schutzkompass</span>';
    echo '</nav>';
}
function hbdp_compass_hero($title,$kicker,$photo,$desc) {
    echo '<header class="hbdp-compass-hero">';
    if($photo!=='' && is_file(HBDP_ROOT.'assets/'.$photo))echo '<img src="'.esc_url(HBDP_URL.'assets/'.$photo).'" alt="" fetchpriority="high" decoding="async">';
    echo '<div class="hbdp-compass-hero-shade" aria-hidden="true"></div><div class="hbdp-compass-hero-content"><span>'.esc_html($kicker).'</span><h1>'.esc_html($title).'</h1><p>'.esc_html($desc).'</p></div></header>';
}
function hbdp_compass_intro($visible,$paras) {
    echo '<section class="hbdp-compass-intro" aria-label="Einführung"><p class="hbdp-compass-lead">'.esc_html($visible).'</p>';
    echo '<details><summary>Weiterlesen <span aria-hidden="true">⌄</span></summary><div class="hbdp-compass-expanded">';
    foreach($paras as $p)echo '<p>'.esc_html($p).'</p>';
    echo '</div></details></section>';
}
/** Situation-specific editorial guides: no extra categories, posts or WordPress writes. */
function hbdp_compass_guides($slug) {
    static $guides=null;
    if($guides===null){
        $file=HBDP_ROOT.'data/compass-guides.json';
        $json=is_readable($file)?json_decode((string)file_get_contents($file),true):array();
        $guides=is_array($json['choices']??null)?$json['choices']:array();
    }
    return is_array($guides[$slug]??null)?$guides[$slug]:array();
}
function hbdp_compass_render_advice($slug,$item) {
    $choices=hbdp_compass_guides($slug);
    if(!$choices)return;
    $selected=(isset($_GET['lage']) && is_string($_GET['lage']))?sanitize_key(wp_unslash($_GET['lage'])):'';
    $active=null;
    foreach($choices as $choice)if(($choice['key']??'')===$selected){$active=$choice;break;}
    echo '<section class="hbdp-compass-section hbdp-compass-decision" id="hbdp-compass-situationen" aria-label="Individuelle Orientierung">';
    echo '<div class="hbdp-compass-section-head"><span>1 · IHR EINSTIEG</span><h2>Was trifft auf Ihre Situation zu?</h2><p>Wählen Sie Ihre Ausgangslage. Danach erscheint eine passende Schritt-für-Schritt-Hilfe direkt hier auf der Seite.</p></div>';
    echo '<div class="hbdp-compass-choices">';
    foreach($choices as $choice){
        $is_current=$selected!==''&&$selected===($choice['key']??'');
        $url=add_query_arg(array('lage'=>(string)$choice['key']),hbdp_compass_item_url($slug)).'#hbdp-compass-situationen';
        echo '<a class="hbdp-compass-choice'.($is_current?' is-selected':'').'" href="'.esc_url($url).'"'.($is_current?' aria-current="true"':'').'>';
        echo '<span class="hbdp-compass-choice-mark" aria-hidden="true">'.($is_current?'✓':'→').'</span>';
        echo '<strong>'.esc_html((string)$choice['title']).'</strong><small>'.esc_html((string)$choice['teaser']).'</small></a>';
    }
    echo '</div>';
    if(!is_array($active)){
        echo '<div class="hbdp-compass-guidance-prompt"><strong>Ihre praktische Hilfe beginnt hier.</strong><p>Bitte wählen Sie eine der Situationen. Sie erhalten sofort eine konkrete Checkliste, ohne Registrierung oder Produktempfehlungen.</p></div>';
    } else {
        echo '<div class="hbdp-compass-guide" id="hbdp-compass-hilfe" aria-live="polite">';
        echo '<div class="hbdp-compass-section-head"><span>2 · IHRE PRAKTISCHE HILFE</span><h2>'.esc_html((string)$active['title']).'</h2><p>'.esc_html((string)$active['lead']).'</p></div>';
        echo '<h3 class="hbdp-compass-checklist-title">Checkliste: Drei konkrete Schritte</h3>';
        echo '<ol class="hbdp-compass-guide-steps">';
        foreach((array)$active['steps'] as $i=>$step){
            if(!is_array($step))continue;
            $stepid='hbdp-check-'.esc_attr($slug.'-'.$active['key'].'-'.($i+1));
            echo '<li class="hbdp-compass-guide-step"><div class="hbdp-compass-guide-step-top"><span class="hbdp-compass-guide-number" aria-hidden="true">'.(int)($i+1).'</span><strong>'.esc_html((string)$step['title']).'</strong></div><p>'.esc_html((string)$step['detail']).'</p>';
            echo '<label class="hbdp-compass-guide-check"><input type="checkbox" id="'.$stepid.'"><span>Für meine Situation geprüft</span></label></li>';
        }
        echo '</ol><p class="hbdp-compass-guide-note">Die Checkliste ist eine allgemeine Orientierung. Bei akuter Gefahr und Arbeiten an gefährlichen Anlagen hat fachliche Hilfe Vorrang. Häkchen werden nicht gespeichert.</p>';
        echo '</div>';
    }
    echo '</section>';
}

function hbdp_render_schutzkompass() {
    $catalog=hbdp_compass_catalog();$slug=hbdp_compass_current_slug();$item=$slug!==''?$catalog[$slug]:null;
    echo '<main class="hbdp-compass hbdp-compass-page">';
    echo '<div class="hbdp-frame">';hbdp_compass_crumb(is_array($item)?$item['title']:'');echo '</div>';
    echo '<div class="hbdp-frame">';
    if(!$item){
        hbdp_compass_hero('Schutzkompass','MAGAZIN · ORIENTIERUNG','start-hero.webp','Was möchten Sie schützen? Hier finden Sie Orientierung.');
        hbdp_compass_intro('Nicht jeder sucht sofort nach einer bestimmten Gefahr oder einem Produkt. Häufig beginnt die Frage mit dem eigenen Haus, dem Wohnmobil, dem kleinen Geschäft oder einer anstehenden Reise. Der Schutzkompass verbindet deshalb bestehende Ratgeber und Fachthemen über Objekte und Alltagssituationen hinweg. Er ersetzt weder die Schutzwelten noch legt er doppelte Kategorien an.',array(
        'Wählen Sie zuerst das Objekt, das Sie schützen möchten, oder die Situation, in der Sie sich befinden. Auf der nächsten Ansicht finden Sie eine kurze Orientierung, praktische Prüfpunkte und thematisch passende Links aus den vorhandenen Schutzwelten. Ein Haus kann beispielsweise zugleich Fragen zur Zugangssicherung, Rückstauvorsorge und Rauchwarnung auslösen.',
        'Die fachlich ausführlichen Anleitungen, Produktvergleiche und Kaufhilfen bleiben immer an ihren ursprünglichen Stellen. Der Schutzkompass führt zu ihnen, anstatt denselben Inhalt zu kopieren. Für persönliche Betriebe, Vereine, Ferienobjekte, Fahrzeuge und gemeinsam genutzte Räume sind eigene Einstiege vorgesehen, wenn sich daraus ein wirklich anderer Beratungsbedarf ergibt.',
        'Die Navigation wächst nur dort, wo die bestehende Themenstruktur geeignete Inhalte bereitstellt. Nicht zugeordnete oder nicht veröffentlichte Themen werden nicht als vermeintlich fertige Ratgeber erfunden. So bleibt die Übersicht hilfreich und zugleich klar von den Hauptkategorien, dem Sicherheitsglossar und dem Dienstleisterverzeichnis getrennt.'
        ));
        echo '<section class="hbdp-compass-section"><div class="hbdp-compass-section-head"><span>ENTDECKEN NACH OBJEKT</span><h2>Was möchten Sie schützen?</h2><p>Wählen Sie ein Objekt. Die passende Ansicht bündelt mehrere Gefahrenwelten und ihre bestehenden Lösungen.</p></div><div class="hbdp-compass-grid">';
        foreach($catalog as $key=>$entry)if($entry['group']==='objekt')hbdp_compass_card($key,$entry);
        echo '</div></section>';
        echo hbdp_editorial_banner_markup('compass-start-1','core:hub');
        echo '<section class="hbdp-compass-section"><div class="hbdp-compass-section-head"><span>ENTDECKEN NACH SITUATION</span><h2>Was beschäftigt Sie gerade?</h2><p>Praktische Hilfe für konkrete Anlässe – von der Reisevorbereitung bis zum Schadenfall.</p></div><div class="hbdp-compass-grid">';
        foreach($catalog as $key=>$entry)if($entry['group']==='situation')hbdp_compass_card($key,$entry);
        echo '</div></section>';
        echo hbdp_editorial_banner_markup('compass-start-2','core:hub');
        echo '<p class="hbdp-compass-footnote">Alle Einstiege führen zu bereits vorhandenen Fachthemen. Die Schutzwelten und ihre Originaladressen bleiben erhalten.</p>';
    }else{
        hbdp_compass_hero($item['title'],$item['group']==='objekt'?'SCHUTZKOMPASS · OBJEKT':'SCHUTZKOMPASS · SITUATION',$item['photo'],$item['subtitle']);
        hbdp_compass_intro($item['intro'],array(
            'Hier geht es nicht um eine weitere Sammlung von Hauptkategorien. Wir beginnen bei Ihrer konkreten Ausgangslage und verbinden dazu passende Fragen. So können Sie über mehrere Gefahrenarten hinweg planen und bei Bedarf direkt zu den bestehenden Fachseiten wechseln. Die nachfolgenden Hinweise sind Orientierungspunkte und ersetzen keine objektspezifische fachliche Prüfung.',
            'Zuerst empfiehlt sich eine Bestandsaufnahme: Was ist vorhanden, wer nutzt es und wer kann bei Abwesenheit oder Störungen handeln? Danach lassen sich passende Themen auswählen. Die hier verlinkten Ratgeber behalten ihren ursprünglichen Standort und ihre bestehende redaktionelle Verantwortung; Inhalte und Kaufvergleiche werden nicht doppelt angelegt.',
            'Die zusammengestellten Fachthemen richten sich nach dem tatsächlichen Kategorienbestand. Wo noch kein geeigneter Beitrag veröffentlicht wurde, bleibt der Einstieg bei den vorhandenen Kategorien. Der Schutzkompass ist ein Wegweiser und kein eigenständiges zweites Produktsortiment oder eine neue WordPress-Kategorieebene.'
        ));
        // Real situational journey precedes all original-category references.
        hbdp_compass_render_advice($slug,$item);
        echo hbdp_editorial_banner_markup('compass-detail-1','core:hub|'.$slug);
        $matches=hbdp_compass_matches($item,6);
        echo '<section class="hbdp-compass-section"><div class="hbdp-compass-section-head"><span>3 · OPTIONAL VERTIEFEN</span><h2>Fachinformationen zum Weiterlesen</h2><p>Ergänzend zur persönlichen Checkliste: bestehende Detailseiten aus dem Portal, ohne doppelte Ratgeber.</p></div>';
        if($matches){echo '<div class="hbdp-compass-topic-grid">';foreach($matches as $m){$p=$m['node'];echo '<a href="'.esc_url($m['url']).'" class="hbdp-compass-topic"><small>'.esc_html($m['world']).'</small><strong>'.esc_html(hbdp_compass_display_name($p)).'</strong><span>Schutzthema lesen →</span></a>';}echo '</div>';}
        else echo '<p class="hbdp-compass-empty">Für diesen Einstieg sind im aktuellen Kategorienbestand noch keine eindeutig passenden Fachthemen verknüpft. Es werden keine künstlichen Ziele angezeigt.</p>';
        echo '</section><section class="hbdp-compass-section"><div class="hbdp-compass-section-head"><span>WEITERE PERSPEKTIVEN</span><h2>Andere Ausgangslage?</h2></div><div class="hbdp-compass-mini-grid">';
        $count=0;foreach($catalog as $key=>$candidate){if($key===$slug)continue;if($candidate['group']!==$item['group'])continue;hbdp_compass_card($key,$candidate);if(++$count===4)break;}
        echo '</div></section><p class="hbdp-compass-back"><a href="'.esc_url(hbdp_compass_base_url()).'">← Alle Einstiege im Schutzkompass</a></p>';
    }
    echo '</div></main>';
}
// Query-based selection shares the existing core:hub canonical page; no competing SEO URLs.
add_filter('wp_robots',function($robots){if(hbdp_compass_current_slug()!=='')$robots['noindex']=true;return $robots;},60);
