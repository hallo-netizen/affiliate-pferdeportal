<?php
/** Hab & Bewahr 0.1.82: ONE canonical editable price page. */
if (!defined('ABSPATH')) exit;

function hbdp_preise_is_known_legacy_v082($content) {
    // Preserve changed commercial terms: use the canonical source only if all
    // three known tables and material price values still agree.
    if (strpos((string)$content, 'hbdp-preise-page-v082') !== false) return false;
    if (substr_count(strtolower((string)$content), '<table') !== 3) return false;
    $plain = html_entity_decode(wp_strip_all_tags((string)$content), ENT_QUOTES|ENT_HTML5, 'UTF-8');
    $plain = preg_replace('~\\s+~u', ' ', $plain);
    foreach (array('Kostenlose Basisanzeigen','Hervorgehobene Anzeige','Redaktioneller Artikel / Advertorial',
                   'Kategorie-Banner exklusiv','Startseiten-Banner exklusiv',
                   '0 €','149 €','199 €','399 €','999 €','1499 €',
                   'Die kostenlose Basisanzeige umfasst','Exklusive Bannerplätze werden') as $expected) {
        if (strpos($plain, $expected) === false) return false;
    }
    return true;
}

function hbdp_preise_content_v082() {
    $f=HBDP_ROOT.'includes/preise-v082.html';
    if(!is_readable($f))return '';
    $text=(string)file_get_contents($f);
    $urls = array(
        hbdp_footer_listings_url(),
        hbdp_footer_page_url(array('werb-anzeigebedingungen')),
        hbdp_footer_page_url(array('kontakt')),
    );
    foreach($urls as $url)if(!is_string($url)||$url==='')return '';
    return str_replace(array('{{ANZEIGENMARKT}}','{{WERBEBEDINGUNGEN}}','{{KONTAKT}}'),
        array(esc_url($urls[0]),esc_url($urls[1]),esc_url($urls[2])),$text);
}
function hbdp_preise_frontend_v082() {
    $content=hbdp_preise_content_v082();
    if($content==='')return '<p>Die Preisinformationen sind vorübergehend nicht verfügbar.</p>';
    // Render Gutenberg source using the ACTUAL template call, not a fake CSS mock.
    return apply_filters('the_content',$content);
}

/** One guarded WP page replacement, no old v080 failure lock. */
function hbdp_preise_migrate_v082() {
    if(!current_user_can('manage_options'))return 'Keine Berechtigung';
    $p=get_page_by_path('preise',OBJECT,'page');
    if(!$p||$p->post_status!=='publish')return 'Preisseite nicht gefunden';
    $old=(string)$p->post_content;
    if((string)get_post_meta($p->ID,'_hbdp082_preise_disabled',true)==='1')return 'Preisseite bewusst wiederhergestellt; automatische Migration deaktiviert';
    if(strpos($old,'hbdp-preise-page-v082')!==false)return 'Neue Preisseite bereits gespeichert';
    if(!hbdp_preise_is_known_legacy_v082($old))return 'Geänderte Preise oder unbekannte Tabellen: kein Überschreiben';
    $new=hbdp_preise_content_v082();
    if($new==='')return 'Lokale Zielseiten noch nicht vorhanden';
    if(!metadata_exists('post',(int)$p->ID,'_hbdp082_preise_original')) {
        if(!add_post_meta($p->ID,'_hbdp082_preise_original',$old,true))return 'Originalsicherung fehlgeschlagen';
    }
    $res=wp_update_post(array('ID'=>$p->ID,'post_content'=>wp_slash($new)),true);
    if(is_wp_error($res)||!$res)return 'Speichern fehlgeschlagen, wird beim nächsten Aufruf erneut geprüft';
    update_post_meta($p->ID,'_hbdp082_preise_hash',hash('sha256',$new));
    return 'Preisseite aktualisiert; Seiten-ID und URL unverändert';
}
function hbdp_preise_enable_and_migrate_v082(){
    if(!current_user_can('manage_options'))return 'Keine Berechtigung';
    $p=get_page_by_path('preise',OBJECT,'page');
    if($p)delete_post_meta($p->ID,'_hbdp082_preise_disabled');
    return hbdp_preise_migrate_v082();
}
function hbdp_preise_restore_v082() {
    if(!current_user_can('manage_options'))return 'Keine Berechtigung';
    $p=get_page_by_path('preise',OBJECT,'page');
    if(!$p)return 'Preisseite nicht gefunden';
    $before=get_post_meta($p->ID,'_hbdp082_preise_original',true);
    $hash=(string)get_post_meta($p->ID,'_hbdp082_preise_hash',true);
    if(!is_string($before)||$before===''||$hash===''||hash('sha256',(string)$p->post_content)!==$hash)
        return 'Seite zwischenzeitlich bearbeitet – nicht automatisch zurücksetzen';
    $res=wp_update_post(array('ID'=>$p->ID,'post_content'=>wp_slash($before)),true);
    if(is_wp_error($res)||!$res)return 'Rücksetzung fehlgeschlagen';
    delete_post_meta($p->ID,'_hbdp082_preise_original');
    delete_post_meta($p->ID,'_hbdp082_preise_hash');
    update_post_meta($p->ID,'_hbdp082_preise_disabled','1');
    return 'Originalinhalt wiederhergestellt und automatische Migration deaktiviert';
}
// Runs exactly on the real price route while the owner is logged in. No global
// background jobs, no recurring database writes, and no new WordPress plugin.
add_action('template_redirect',function(){
    if(is_page('preise') && current_user_can('manage_options'))hbdp_preise_migrate_v082();
},1);
