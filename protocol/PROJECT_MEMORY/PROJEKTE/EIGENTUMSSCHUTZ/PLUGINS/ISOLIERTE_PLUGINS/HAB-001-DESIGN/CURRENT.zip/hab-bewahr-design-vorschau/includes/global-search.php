<?php
/** Hab & Bewahr 0.1.105: one read-only global search across four existing content areas. */
if (!defined('ABSPATH')) exit;

function hbdp_search_phrase($raw) {
    if (!is_scalar($raw)) return '';
    $term = trim(sanitize_text_field(wp_unslash((string)$raw)));
    return function_exists('mb_substr') ? mb_substr($term, 0, 80, 'UTF-8') : substr($term, 0, 80);
}
function hbdp_search_request() {
    return !is_admin() && isset($_GET['hbdp_header_search']) && is_scalar($_GET['hbdp_header_search']) && (string)wp_unslash($_GET['hbdp_header_search']) === '1'
        && isset($_GET['s']) && hbdp_search_phrase($_GET['s']) !== '';
}
function hbdp_search_normalize($v) {
    $v = remove_accents(wp_strip_all_tags((string)$v));
    $v = function_exists('mb_strtolower') ? mb_strtolower($v, 'UTF-8') : strtolower($v);
    return trim(preg_replace('/\s+/u', ' ', preg_replace('/[^a-z0-9]+/u', ' ', $v)));
}
function hbdp_search_score($needle, $haystack) {
    $q = hbdp_search_normalize($needle); $c = hbdp_search_normalize($haystack);
    if ($q === '' || $c === '') return 0;
    if ($q === $c) return 500;
    if (strpos($c, $q) === 0) return 400;
    if (strpos($c, $q) !== false) return 300;
    foreach (explode(' ', $q) as $part) {
        if (strlen($part) < 2 || strpos($c, $part) === false) return 0;
    }
    return 180;
}
function hbdp_search_sort($items) {
    usort($items, static function($a, $b) {
        $cmp = ((int)$b['score']) <=> ((int)$a['score']);
        return $cmp ?: strnatcasecmp((string)$a['title'], (string)$b['title']);
    });
    return $items;
}
/** Search only the existing authoritative WP node snapshot; no new category tree. */
function hbdp_search_nodes($q, $limit, $area) {
    $candidates = array(); $seen = array();
    foreach (hbdp_all_nodes() as $n) {
        if (!is_array($n) || empty($n['wp_id']) || empty($n['name'])) continue;
        $id = (string)($n['id'] ?? ''); $type = (string)($n['type'] ?? '');
        if ($area === 'schutz') {
            if (strpos($id, 'core:') !== 0 || !in_array($type, array('page','category'), true)) continue;
        } else {
            if (strpos($id, 'editorial:') !== 0 || !in_array($type, array('page','journal_cat'), true)) continue;
        }
        $score = hbdp_search_score($q, $n['name']);
        if ($score < 1) continue;
        $key = $type.':'.(int)$n['wp_id'];
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $candidates[] = array('node'=>$n, 'score'=>$score, 'title'=>hbdp_display_category_name($n));
    }
    $candidates = hbdp_search_sort($candidates);
    $results = array();
    foreach ($candidates as $row) {
        $node = $row['node']; $type = (string)$node['type']; $id = (int)$node['wp_id'];
        if ($type === 'page' && get_post_status($id) !== 'publish') continue;
        $url = hbdp_nav_url($node); // validates actual WP target; never fabricates destinations
        if (!$url) continue;
        $results[] = array('title'=>$row['title'], 'url'=>$url, 'score'=>$row['score']);
        if (count($results) >= $limit) break;
    }
    return $results;
}
function hbdp_search_posts($q, $post_type, $limit) {
    if (!post_type_exists($post_type)) return array();
    $args = array('post_type'=>$post_type, 'post_status'=>'publish', 's'=>$q,
        'numberposts'=>min(max(10, $limit*3), 150), 'suppress_filters'=>false, 'no_found_rows'=>true);
    // WordPress search normally checks article title, excerpt and body together.
    // With many newer matches in the body, its dated, limited result page can
    // omit an older article whose TITLE matches. Query published post titles
    // separately first (supported since WP 6.2), then keep normal text search.
    // This affects ONLY the existing header search, not the market or glossary.
    $title_hits = array();
    if ($post_type === 'post' && version_compare((string)get_bloginfo('version'), '6.2', '>=')) {
        $title_hits = get_posts(array_merge($args, array('search_columns'=>array('post_title'))));
    }
    $posts = get_posts($args);
    $items = array(); $seen = array();
    foreach (array_merge((array)$title_hits, (array)$posts) as $p) {
        if (!($p instanceof WP_Post) || $p->post_status !== 'publish' || $p->post_type !== $post_type) continue;
        if (isset($seen[(int)$p->ID])) continue;
        $seen[(int)$p->ID] = true;
        // The four obsolete layout-demo articles must never be recommended as advice.
        if ($post_type === 'post' && get_post_meta($p->ID, '_hbdp_demo', true) === '1') continue;
        $url = get_permalink($p->ID);
        if (!is_string($url) || $url === '') continue;
        $title = get_the_title($p->ID);
        $items[] = array('title'=>$title, 'url'=>$url, 'score'=>max(100, hbdp_search_score($q, $title)));
    }
    return array_slice(hbdp_search_sort($items), 0, $limit);
}
function hbdp_search_glossary($q, $limit) {
    $items = array();
    foreach (hbdp_glossary_public_index() as $entry) {
        if (empty($entry['reviewed']) || empty($entry['url'])) continue;
        $title=(string)($entry['begriff']??'');
        $score=hbdp_search_score($q, $title.' '.implode(' ', (array)($entry['synonyme']??array())).' '.(string)($entry['kurzdefinition']??''));
        if ($score <= 0) continue;
        $items[] = array('title'=>$title, 'url'=>(string)$entry['url'], 'score'=>$score);
    }
    return array_slice(hbdp_search_sort($items),0,$limit);
}
function hbdp_search_merged($a, $b, $limit) {
    $seen=array(); $items=array();
    foreach (array_merge($a,$b) as $row) {
        $key=(string)$row['url'];
        if ($key === '' || isset($seen[$key])) continue;
        $seen[$key]=true; $items[]=$row;
    }
    return array_slice(hbdp_search_sort($items),0,$limit);
}
function hbdp_search_listing_categories($q, $limit) {
    if (!taxonomy_exists('hp_listing_category')) return array();
    $terms = get_terms(array('taxonomy'=>'hp_listing_category','hide_empty'=>true,'search'=>$q,'number'=>min(50,$limit*3)));
    if (is_wp_error($terms) || !is_array($terms)) return array();
    $items=array();
    foreach ($terms as $t) {
        $score=hbdp_search_score($q,$t->name);
        if ($score<=0) continue;
        $url=get_term_link($t);
        if (is_wp_error($url) || !is_string($url)) continue;
        $items[]=array('title'=>hbdp_category_title_without_dashes($t->name), 'url'=>$url, 'score'=>$score);
    }
    return array_slice(hbdp_search_sort($items),0,$limit);
}
function hbdp_search_four_groups($q, $limit=5) {
    $limit=max(1,min(60,(int)$limit)); $q=hbdp_search_phrase($q);
    $empty=array('schutz'=>array(),'magazin'=>array(),'stichwort'=>array(),'glossar'=>array(),'anzeigen'=>array());
    $len=function_exists('mb_strlen')?mb_strlen($q,'UTF-8'):strlen($q);
    if ($len < 2) return $empty;
    $schutz=hbdp_search_nodes($q,$limit,'schutz');
    $magazin=hbdp_search_nodes($q,$limit,'magazin');
    $stichwort=hbdp_search_posts($q,'post',$limit);
    $glossar=hbdp_search_glossary($q,$limit);
    $anzeigen=hbdp_search_merged(hbdp_search_posts($q,'hp_listing',$limit),hbdp_search_listing_categories($q,$limit),$limit);
    return array('schutz'=>$schutz,'magazin'=>$magazin,'stichwort'=>$stichwort,'glossar'=>$glossar,'anzeigen'=>$anzeigen);
}
function hbdp_search_labels() {
    return array('schutz'=>'SCHUTZBEREICHE','magazin'=>'MAGAZIN','stichwort'=>'STICHWÖRTER','glossar'=>'GLOSSAR','anzeigen'=>'DIENSTLEISTER & ANZEIGEN');
}
function hbdp_search_group_html($items,$key) {
    $labels=hbdp_search_labels();
    $html='<section class="hbdp-search-group hbdp-search-group-'.esc_attr($key).'"><h2>'.esc_html($labels[$key]).'</h2>';
    if (!$items) return $html.'<p class="hbdp-search-empty">Keine Treffer</p></section>';
    $html.='<ul>';
    foreach ($items as $row) {
        $html.='<li><a href="'.esc_url($row['url']).'">'.esc_html($row['title']).'<span aria-hidden="true">→</span></a></li>';
    }
    return $html.'</ul></section>';
}
function hbdp_search_results_url($q) {
    return add_query_arg(array('s'=>$q,'hbdp_header_search'=>'1'),home_url('/'));
}
function hbdp_search_ajax() {
    check_ajax_referer('hbdp_main_search_v0105','nonce');
    $q=hbdp_search_phrase(isset($_POST['q'])?$_POST['q']:'');
    $groups=hbdp_search_four_groups($q,5);
    $html='<div class="hbdp-search-preview-grid">';
    foreach ($groups as $key=>$items) $html.=hbdp_search_group_html($items,$key);
    $html.='</div><div class="hbdp-search-preview-footer"><a href="'.esc_url(hbdp_search_results_url($q)).'">Suchergebnisse anzeigen →</a></div>';
    wp_send_json_success(array('html'=>$html));
}
add_action('wp_ajax_hbdp_main_search', 'hbdp_search_ajax');
add_action('wp_ajax_nopriv_hbdp_main_search', 'hbdp_search_ajax');
function hbdp_render_search_results() {
    $q=hbdp_search_phrase(isset($_GET['s'])?$_GET['s']:'');
    $groups=hbdp_search_four_groups($q,60);
    echo '<main class="hbdp-frame hbdp-search-page"><nav class="hbdp-crumb" aria-label="Brotkrumennavigation"><a href="'.esc_url(home_url('/')).'">Startseite</a><span aria-hidden="true">/</span><span>Suche</span></nav>';
    echo '<div class="hbdp-search-page-head"><span class="hbdp-eyebrow">PORTALSUCHE</span><h1>Suchergebnisse für „'.esc_html($q).'“</h1><p>Treffer nach Themenbereichen und Stichwörtern – getrennt und direkt verlinkt.</p></div>';
    echo '<div class="hbdp-search-page-grid">';
    foreach ($groups as $key=>$items) echo hbdp_search_group_html($items,$key);
    echo '</div></main>';
}
