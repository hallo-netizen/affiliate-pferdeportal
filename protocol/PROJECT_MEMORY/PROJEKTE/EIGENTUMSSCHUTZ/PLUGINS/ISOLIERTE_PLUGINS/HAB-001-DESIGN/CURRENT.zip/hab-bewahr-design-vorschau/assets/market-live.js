/* Anzeigenmarkt only: AJAX preview, never the 4-area portal search. */
(function(){'use strict';
function start(){
  var form=document.querySelector('form[data-hbdp-market-search]');
  if(!form || !window.hbdpMarketAjax) return;
  var field=form.querySelector('input[name="s"]'),panel=form.querySelector('.hbdp-market-suggest');
  if(!field || !panel) return;
  var timer=0, seq=0, controller=null;
  function close(){panel.hidden=true;field.setAttribute('aria-expanded','false');}
  function open(){panel.hidden=false;field.setAttribute('aria-expanded','true');}
  function abort(){if(controller && controller.abort)controller.abort();controller=null;}
  function search(){
    var q=field.value.trim();if(q.length<2){close();return;}
    var num=++seq;abort();controller=typeof AbortController!=='undefined'?new AbortController():null;
    panel.textContent='Anzeigen werden gesucht …';open();
    var body=new URLSearchParams({action:'hbdp_market_search',nonce:hbdpMarketAjax.nonce,q:q});
    var options={method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()};
    if(controller)options.signal=controller.signal;
    fetch(hbdpMarketAjax.endpoint,options).then(function(response){if(!response.ok)throw Error('HTTP');return response.json();}).then(function(result){
      if(num!==seq || field.value.trim()!==q)return;
      if(!result.success || !result.data || typeof result.data.html!=='string')throw Error('response');
      panel.innerHTML=result.data.html;open();
    }).catch(function(err){
      if(num!==seq || (err && err.name==='AbortError'))return;
      panel.textContent='Vorschau nicht erreichbar. Mit Enter normale Anzeigensuche öffnen.';open();
    });
  }
  field.addEventListener('input',function(){clearTimeout(timer);++seq;abort();if(field.value.trim().length<2){close();return;}timer=setTimeout(search,280);});
  field.addEventListener('keydown',function(e){if(e.key==='Escape'){close();field.blur();}});
  document.addEventListener('click',function(e){if(!form.contains(e.target))close();});
  form.addEventListener('submit',function(){clearTimeout(timer);++seq;abort();});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
