<?php
/**
 * Hab & Bewahr — Startseitenbaustein, kein eigenständiges WordPress-Plugin.
 * Vorkonfektioniert für die Integration in den bereits installierten Design-Vorschau-Kern.
 * Keine Hooks/DB-Abfragen/HTTP-Jobs in dieser Datei.
 */
if (!defined('ABSPATH')) { exit; }

final class HB_Design_Startseite_View {
    private const WORLD = [
        ['Einbruch & Diebstahl', 'Zutritt erschweren, Werte schützen und Risiken früh erkennen.', '⌂'],
        ['Vandalismus & Zerstörung', 'Eigentum gegen mutwillige Beschädigung absichern.', '✳'],
        ['Wasser & Feuchtigkeit', 'Leckagen, Rückstau, Hochwasser und Frost begrenzen.', '◊'],
        ['Feuer & Gase', 'Brände, Rauch und gefährliche Gase erkennen.', '♨'],
        ['Wetter & Naturgefahren', 'Sturm, Hagel und Starkregen besser beherrschen.', '☁'],
        ['Technik & Ausfälle', 'Strom, Heizung, Pumpen und Haustechnik überwachen.', '⚙'],
    ];
    private const FOCUS = [
        ['Ferienhaus', 'home-focus-ferienhaus.webp'],
        ['Garage & Werkstatt', 'home-focus-garage.webp'],
        ['Gartenhaus', 'home-focus-gartenhaus.webp'],
        ['Boot', 'home-focus-boot.webp'],
        ['Wärmepumpe & PV', 'home-focus-waermepumpe.webp'],
        ['Wertsachen', 'existing-safe-room.webp'],
    ];

    private const FOCUS_IDS = [
        'core:leaf:015','core:leaf:131','core:leaf:012',
        'core:leaf:010','core:subarea:4dbf86eb169f98d2','core:leaf:004'
    ];
    public static function focus_ids(): array { return self::FOCUS_IDS; }
    public static function focus_image_for_node(string $id): string {
        $index = array_search($id, self::FOCUS_IDS, true);
        return $index === false ? '' : self::FOCUS[$index][1];
    }

    /**
     * $urls is supplied by the existing live category registry/renderer.
     * No DB lookup or guessing of WP links, slugs or node IDs here.
     * $asset_base is calculated from the EXISTING plugin root by its own loader.
     */
    public static function render(array $urls, string $asset_base, bool $show_header = true): string {
        $asset_base = trailingslashit($asset_base);
        ob_start();
        ?>
        <div class="hbd-page">
            <?php if ($show_header) self::header($urls); ?>
            <main class="hbd-main">
                <section class="hbd-hero" aria-label="Hab & Bewahr – Ratgeberportal">
                    <div class="hbd-hero-copy">
                        <span class="hbd-kicker">Wissen, das schützt</span>
                        <h1>Was dir gehört,<br>soll dir bleiben.</h1>
                        <p>Ratgeber, Lösungen und Vergleiche für Einbruch, Wasser, Feuer, Wetter und technische Ausfälle.</p>
                        <?php self::maybe_link($urls['topics'] ?? '', 'Themen entdecken', 'hbd-btn'); ?>
                    </div>
                    <div class="hbd-hero-image">
                        <img src="<?php echo esc_url($asset_base . 'start-hero.webp'); ?>" alt="Geschütztes Wohnhaus in der Abenddämmerung" width="960" height="640" decoding="async" fetchpriority="high">
                    </div>
                </section>

                <section class="hbd-section" aria-label="Schutzwelten">
                    <p class="hbd-kicker">Unsere Themenwelten</p>
                    <h2>Sechs Themenwelten</h2>
                    <div class="hbd-worlds">
                        <?php foreach (self::WORLD as $i => $item): ?>
                        <?php $target = $urls['worlds'][$i] ?? ''; $title = $urls['world_names'][$i] ?? $item[0]; ?>
                        <<?php echo $target ? 'a href="'.esc_url($target).'"' : 'div'; ?> class="hbd-world-card">
                            <span class="hbd-world-symbol" aria-hidden="true"><?php echo esc_html($item[2]); ?></span>
                            <strong><?php echo esc_html($title); ?></strong>
                            <p><?php echo esc_html($item[1]); ?></p>
                            <span class="hbd-world-arrow" aria-hidden="true">→</span>
                        </<?php echo $target ? 'a' : 'div'; ?>>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="hbd-section hbd-focus" aria-label="Beliebte Schutzobjekte">
                    <p class="hbd-kicker">Beliebte Schutzobjekte</p>
                    <h2>Was möchtest du schützen?</h2>
                    <div class="hbd-focus-grid">
                        <?php foreach (self::FOCUS as $i => $item): ?>
                        <?php $target = $urls['focus'][$i] ?? ''; ?>
                        <<?php echo $target ? 'a href="'.esc_url($target).'"' : 'div'; ?> class="hbd-focus-card">
                            <img src="<?php echo esc_url($asset_base . $item[1]); ?>" alt="<?php echo esc_attr($item[0]); ?>" width="480" height="300" loading="lazy" decoding="async">
                            <span><?php echo esc_html($item[0]); ?><b aria-hidden="true">→</b></span>
                        </<?php echo $target ? 'a' : 'div'; ?>>
                        <?php endforeach; ?>
                    </div>
                </section>

                <?php echo hbdp_house_ad_premium_html(); ?>

                
                <?php if (is_user_logged_in()): ?>
                    <div class="hbd-affiliate-preview">Affiliate-Vorschau: nur für angemeldete Redakteure sichtbar.</div>
                <?php endif; ?>
            </main>
        </div>
        <?php
        return (string) ob_get_clean();
    }

    private static function maybe_link(string $href, string $label, string $cls): void {
        if ($href !== '') {
            echo '<a class="'.esc_attr($cls).'" href="'.esc_url($href).'">'.esc_html($label).'</a>';
        } else {
            // Kein Ziel erfinden: im Live-Plugin die zentrale Kategorie-/Link-Bindung verpflichtend anschließen.
            echo '<span class="'.esc_attr($cls).' hbd-not-connected">'.esc_html($label).'</span>';
        }
    }

    public static function header(array $urls, bool $with_navigation = true): void { ?>
        <header class="hbd-header">
            <div class="hbd-descriptor">Dein Ratgeber für Schutz &amp; Sicherheit</div>
            <div class="hbd-head-top">
                <a class="hbd-brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Hab und Bewahr – Startseite">
                    <svg class="hbd-arc" viewBox="0 24 260 52" role="img" aria-label="Schutzbogen">
                        <path d="M 17 74 C 55 42 92 27 130 27 C 168 27 205 42 243 74 C 203 48 167 34 130 34 C 93 34 57 48 17 74 Z" fill="#B35C40"/>
                    </svg>
                    <strong>Hab <em>&amp;</em> Bewahr</strong><span>Schütze dein Eigentum</span>
                </a>
                <form class="hbd-search hbdp-global-search" method="get" action="<?php echo esc_url(home_url('/')); ?>" role="search" data-hbdp-global-search><label class="screen-reader-text" for="hbd-search-box">Suche</label><input id="hbd-search-box" name="s" type="search" placeholder="Was möchtest du schützen?" aria-label="Suche" autocomplete="off" aria-controls="hbdp-search-preview" aria-expanded="false" required><input type="hidden" name="hbdp_header_search" value="1"><button type="submit" aria-label="Suchen">⌕</button><div class="hbdp-search-preview" id="hbdp-search-preview" role="region" aria-label="Suchvorschläge" aria-live="polite" hidden></div></form>
            </div>
            <?php if ($with_navigation): ?><nav class="hbd-navigation" aria-label="Hauptnavigation">
                <?php foreach (['Einbruch', 'Vandalismus', 'Wasser', 'Feuer & Gase', 'Wetter & Natur', 'Technik'] as $i=>$label) self::maybe_link($urls['worlds'][$i] ?? '', $label, 'hbd-nav-link'); ?>
            </nav><?php endif; ?>
        </header>
    <?php }
}
