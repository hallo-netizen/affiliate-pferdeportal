# Hab & Bewahr – verbindliche Text- und Designregeln für die unterste Kategorieebene

Quelle: `protocol/PROJECT_MEMORY/PROJEKTE/HOBBYRAUSCH/DESIGN/TEXTREGELN_PFERDEATELIER_KOPIE_20261012.md` und `ZIELVERTRAG_HOBBY_DEPOT_DESIGN_20261011.md` (Detail-Hubs, bestätigter Pilot „Kettenhemd flechten“ 1.50.689). **Nur Regel- und Layoutprinzip**, keine Hobby-Depot-Styles oder Texte.

1. Sichtbarer Einstieg: 45–60 Wörter, ein zusammenhängender Absatz, sofort erklären, was das Thema ist, wofür es wichtig ist und was fachlich dazugehört.
2. Vertiefung: **weitere 150–200 Wörter zusätzlich** in 1–2 sinnvollen Absätzen in einem Aufklapper. Kein gedoppelter sichtbarer Text.
3. Direkte natürliche Du-Ansprache, nur konkrete und belegbare Sicherheitshinweise; kein Keyword-Stapeln, keine FAQ-Schablone, kein Generator- oder Fülltext, keine generische Schlussformel.
4. Kein künstlicher Aufzählungs- oder Navigationstext zu Kacheln. Keine frei erfundenen Unterkategorien oder technische Normzusicherungen.
5. **Hab & Bewahr behält sein bestehendes R3-Header-Bild wie in 0.1.97**: kompaktes 260-px-Panorama mit H1 und Claim im Bild; **kein Icon im Kopf**. Nur die Unterkategoriekacheln erhalten semantisch einheitliche Icons (gleiche Rollen = gleiche Icons). Danach sichtbarer Lead auf hellem Hab-&-Bewahr-Beige; Aufklapper mit kleinem Chevron.
6. Unterkategorien im geschlossenen 4er-Raster (Tablet 2, Handy 1). Icons nach stabilen semantischen Rollen statt zufälliger Auswahl. Keine nicht vorhandenen Fotos.
7. Reihenfolge: Kopf/Text → vorhandenes Affiliate-Banner → gesamte Unterkategorie-Kachelgruppe → passende Affiliate-Produkte → 3–4 tatsächliche veröffentlichte Ratgeber → vorhandene Werbefläche. **Keine Werbung zwischen Kachelreihen**.
8. Banner und Produkte: getrennte bestehende Schnittstellen des Designplugins (`hbdp_area_auto_banner_html`, `hbdp_area_product_cards_html`) mit der tatsächlichen Node-ID. Keine Demo-Produkte oder erfundenen Kauflinks öffentlich. Leere Werbeblöcke sind für Besucher unsichtbar, nur Administratoren sehen Layout-Hinweise.
9. Für „Haustürschlösser“ ist ein handverfasster Pilot hinterlegt. Alle anderen Kategorien erhalten **keinen automatisch erfundenen 150–200-Wörter-Text**; bisher vorhandene individuelle Einleitungen bleiben als kurze Texte erhalten. Freigabe für die Massentexte erst nach Pilotabnahme.
10. Kategorienamen, Parent-IDs, Beitragszuordnung, SEO-Slugs und Affiliate-Zugangsdaten werden nicht geändert.

Status: lokal korrigiert in Plugin 0.1.100 nach Nutzerhinweis, WordPress-Live-Abnahme offen.
