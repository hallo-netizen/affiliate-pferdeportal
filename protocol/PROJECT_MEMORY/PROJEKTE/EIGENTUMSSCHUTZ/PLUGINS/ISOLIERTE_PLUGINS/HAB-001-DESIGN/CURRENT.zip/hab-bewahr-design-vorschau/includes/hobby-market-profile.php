<?php
/**
 * Hab & Bewahr market design, adapting the verified Hobby Depot HD-003
 * 1.50.787 profile approach (body class + scoped stylesheet + native HivePress).
 * No replacement route, no custom WP archive, no custom header/footer.
 */
if (!defined('ABSPATH')) exit;

final class HBDP_Hobby_Market_Profile {
    /** All official category entry paths use ONE verified WP taxonomy term.
     * HivePress's own listing filter submits a GET to / with _category=term_id
     * and post_type=hp_listing. WordPress does NOT mark that request as is_tax().
     * A category archive URL and its filter URL must therefore share the design.
     * No slug guesses, no database writes, no other WordPress search requests.
     */
    private static function filtered_category_term() {
        if (is_admin() || is_feed() || is_embed() || is_robots() ||
            (function_exists('is_404') && is_404()) ||
            strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'GET' ||
            !isset($_GET['_category']) || !is_scalar($_GET['_category']) ||
            !isset($_GET['post_type']) || !is_scalar($_GET['post_type']) ||
            (string)wp_unslash($_GET['post_type']) !== 'hp_listing' ||
            isset($_GET['hbdp_header_search']) ||
            !function_exists('get_term')) return null;
        $value = trim((string)wp_unslash($_GET['_category']));
        if (!preg_match('/^[1-9][0-9]*$/D', $value)) return null;
        $path = trim(rawurldecode((string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH)), '/');
        $root = function_exists('hbdp_market_listings_url') ?
            trim(rawurldecode((string)parse_url((string)hbdp_market_listings_url(), PHP_URL_PATH)), '/') : 'listing';
        // The root is HivePress's real search/form action. Accept the real
        // listings archive as well, but not arbitrary WordPress pages.
        if ($path !== '' && $path !== $root &&
            ($root === '' || !preg_match('~^'.preg_quote($root, '~').'/page/[1-9][0-9]*/?$~D', $path))) return null;
        $term = get_term((int)$value, 'hp_listing_category');
        if (!is_object($term) || is_wp_error($term) ||
            ($term->taxonomy ?? '') !== 'hp_listing_category' ||
            (int)($term->term_id ?? 0) !== (int)$value) return null;
        return $term;
    }

    private static function current_category_term() {
        if (is_tax('hp_listing_category')) {
            $term = function_exists('get_queried_object') ? get_queried_object() : null;
            return is_object($term) && !is_wp_error($term) &&
                (int)($term->term_id ?? 0) > 0 &&
                ($term->taxonomy ?? '') === 'hp_listing_category' ? $term : null;
        }
        return self::filtered_category_term();
    }

    private static function is_filtered_category() {
        return !is_tax('hp_listing_category') && self::filtered_category_term() !== null;
    }

    public static function is_category_request() {
        if (is_admin() || is_feed() || is_embed() || is_robots()) return false;
        return self::current_category_term() !== null;
    }

    public static function is_child() {
        if (is_admin() || is_feed() || is_embed() || is_robots()) return false;
        return self::is_category_request() || is_singular(array('hp_listing','hp_vendor'));
    }

    public static function body_classes($classes) {
        $classes = is_array($classes) ? $classes : array();
        if (self::is_child()) $classes[] = 'hbdp-hobby-market-child';
        if (self::is_category_request()) $classes[] = 'hbdp-market-category-request';
        if (self::is_filtered_category()) $classes[] = 'hbdp-market-category-query';
        return array_values(array_unique($classes));
    }

    /** The exact wp_body_open placement used by the working Hobby Depot header.
     * The theme header stays as a fallback if this markup cannot be rendered. */
    public static function render_header() {
        if (!self::is_child()) return;
        if (!class_exists('HB_Design_Startseite_View') || !function_exists('hbdp_all_nodes') || !function_exists('hbdp_startseite_urls')) return;
        require_once HBDP_ROOT.'includes/navigation-shared.php';
        if (!function_exists('hbdp_main_navigation')) return;
        $worlds=array_values(array_filter(hbdp_all_nodes(),static function($node) {
            return strpos((string)($node['id'] ?? ''),'core:world:') === 0;
        }));
        $order=array_flip(array('core:world:einbruch-und-diebstahl','core:world:vandalismus-und-zerstorung',
            'core:world:wasser-und-feuchtigkeit','core:world:feuer-und-gase','core:world:wetter-und-naturgefahren',
            'core:world:technik-und-ausfalle','core:world:insurance'));
        usort($worlds,static function($a,$b)use($order){return ($order[$a['id']]??99)<=>($order[$b['id']]??99);});
        ob_start();
        try {
            HB_Design_Startseite_View::header(hbdp_startseite_urls(),false);
            hbdp_main_navigation($worlds,null);
            $html=ob_get_clean();
            if (trim($html)!=='') {
                // Site header contains ONLY the real portal header/navigation.
                // Category intro belongs to the native HivePress page_header
                // on both archive and GET-filter URLs, keeping all blocks in
                // one document flow before filters and footer.
                echo '<div class="hbdp hbdp-hobby-market-site-header">'.$html.'</div>';
            }
        } catch (\Throwable $error) {
            ob_end_clean(); // Never break a HivePress category for a cosmetic header.
        }
    }

    public static function enqueue_styles() {
        if (!self::is_child()) return;
        wp_enqueue_style('hbdp-site', HBDP_URL.'assets/style.css', array(), '0.1.165');
        wp_enqueue_style('hbdp-header', HBDP_URL.'assets/header.css', array('hbdp-site'), '0.1.165');
        wp_enqueue_style('hbdp-main-search',HBDP_URL.'assets/global-search.css',array('hbdp-header'),'0.1.165');
        wp_enqueue_script('hbdp-main-search',HBDP_URL.'assets/global-search.js',array(),'0.1.165',true);
        wp_localize_script('hbdp-main-search','hbdpSearchConfig',array('endpoint'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('hbdp_main_search_v0105')));
        wp_enqueue_script('hbdp-nav',HBDP_URL.'assets/nav.js',array(),'0.1.165',true);

        $profile_deps = array('hbdp-header');
        if (self::is_category_request()) {
            // Reuse the exact market-home hero, search and house-ad styles only
            // on listing-category pages. Listing details/vendors stay unchanged.
            wp_enqueue_style('hbdp-market',HBDP_URL.'assets/market.css',array('hbdp-header'),'0.1.177');
            wp_enqueue_style('hbdp-house-ad-premium',HBDP_URL.'assets/house-ad-premium.css',array('hbdp-market'),'0.1.177');
            wp_enqueue_style('hbdp-market-live-search',HBDP_URL.'assets/market-live.css',array('hbdp-market'),'0.1.177');
            wp_enqueue_script('hbdp-market-live',HBDP_URL.'assets/market-live.js',array(),'0.1.177',true);
            wp_localize_script('hbdp-market-live','hbdpMarketAjax',array(
                'endpoint'=>admin_url('admin-ajax.php'),
                'nonce'=>wp_create_nonce('hbdp_market_search_v0129'),
            ));
            // Identical clearance principle as the established 0.1.155
            // market-submit page; only guards the native category content.
            // Both real routes (taxonomy archive AND /?_category=ID) must
            // receive the same existing clearance. The 0.1.183 is_tax()
            // restriction left HivePress's GET-filter category pages clipped.
            wp_enqueue_script('hbdp-market-category-clearance',
                HBDP_URL.'assets/market-category-clearance.js',array(),'0.1.184',true);
            $profile_deps[] = 'hbdp-house-ad-premium';
            $profile_deps[] = 'hbdp-market-live-search';
        }
        wp_enqueue_style('hbdp-hobby-market-profile',HBDP_URL.'assets/hobby-market-profile.css',$profile_deps,'0.1.184');
    }

    private static function category_label($term) {
        $label = trim((string)($term->name ?? ''));
        if ($label !== '' && function_exists('hbdp_category_title_without_dashes')) {
            $label = trim((string)hbdp_category_title_without_dashes($label));
        }
        return $label;
    }

    /** One truthful breadcrumb: home, market, real taxonomy ancestors, current term. */
    private static function category_breadcrumb_html($term) {
        $html = '<nav class="hbdp-crumb" aria-label="Brotkrumennavigation">';
        $html .= '<a href="'.esc_url(home_url('/')).'">Startseite</a><span aria-hidden="true">/</span>';
        $market_url = function_exists('hbdp_market_landing_url') ? hbdp_market_landing_url() : '';
        if ($market_url !== '') {
            $html .= '<a href="'.esc_url($market_url).'">Anzeigenmarkt</a><span aria-hidden="true">/</span>';
        } else {
            $html .= '<span>Anzeigenmarkt</span><span aria-hidden="true">/</span>';
        }

        $ancestor_ids = function_exists('get_ancestors')
            ? get_ancestors((int)$term->term_id, 'hp_listing_category', 'taxonomy') : array();
        if (!is_array($ancestor_ids)) $ancestor_ids = array();
        foreach (array_reverse($ancestor_ids) as $ancestor_id) {
            $ancestor = function_exists('get_term') ? get_term((int)$ancestor_id, 'hp_listing_category') : null;
            if (!is_object($ancestor) || is_wp_error($ancestor)) continue;
            $label = self::category_label($ancestor);
            if ($label === '') continue;
            $url = function_exists('get_term_link') ? get_term_link($ancestor, 'hp_listing_category') : '';
            if (is_wp_error($url) || !is_string($url) || $url === '') continue;
            $html .= '<a href="'.esc_url($url).'">'.esc_html($label).'</a><span aria-hidden="true">/</span>';
        }

        $current = self::category_label($term);
        if ($current !== '') $html .= '<span aria-current="page">'.esc_html($current).'</span>';
        $html .= '</nav>';
        return $html;
    }

    /**
     * The same top-of-market composition as the working /listing/ landing page.
     * Only the breadcrumb is category-aware; the hero, image, CTAs, search and
     * advertising slot use the existing market functions and exact CSS classes.
     */
    private static function category_intro_html($term) {
        if (!function_exists('hbdp_market_listings_url') ||
            !function_exists('hbdp_market_submit_url') ||
            !function_exists('hbdp_market_banner_between_search_and_cards')) return '';

        $listings_url = hbdp_market_listings_url();
        $submit_url = hbdp_market_submit_url();
        $price_url = function_exists('hbdp_footer_page_url') ? hbdp_footer_page_url(array('preise')) : '';
        $html = '<div class="hbdp-frame hbdp-market hbdp-market-child-intro">';
        $html .= self::category_breadcrumb_html($term);
        $html .= '<section class="hbdp-market-hero" aria-label="Anzeigenmarkt">';
        $html .= '<div class="hbdp-market-hero-copy"><span class="hbdp-eyebrow">DIENSTLEISTER UND ANZEIGEN</span>';
        // h2 keeps the real category page title as its single H1 below the intro.
        $html .= '<h2>Anzeigenmarkt</h2><p>Dienstleister und Schutzangebote finden.</p><div class="hbdp-market-actions">';
        if ($submit_url !== '') $html .= '<a class="hbdp-market-primary" href="'.esc_url($submit_url).'">Anzeige aufgeben</a>';
        if ($price_url !== '') $html .= '<a class="hbdp-market-secondary" href="'.esc_url($price_url).'">Anzeigenpreise</a>';
        $html .= '</div></div><div class="hbdp-market-hero-photo"><img src="'.esc_url(HBDP_URL.'assets/new-shop.webp').'" width="1619" height="971" alt="Kleiner Betrieb als Beispiel für den Anzeigenmarkt" decoding="async" fetchpriority="high"></div></section>';

        if ($listings_url !== '' && function_exists('post_type_exists') && post_type_exists('hp_listing')) {
            $html .= '<form class="hbdp-market-search" data-hbdp-market-search action="'.esc_url($listings_url).'" method="get" role="search">';
            $html .= '<label for="hbdp-market-q">Anzeigen durchsuchen</label><div class="hbdp-market-search-fields">';
            $html .= '<input type="search" id="hbdp-market-q" name="s" placeholder="Dienstleister oder Leistung suchen" autocomplete="off" aria-autocomplete="list" aria-controls="hbdp-market-search-preview" aria-expanded="false" required>';
            $html .= '<input type="hidden" name="post_type" value="hp_listing"><input type="hidden" name="hbdp_market_search" value="1"><button type="submit">Suchen</button></div>';
            $html .= '<div id="hbdp-market-search-preview" class="hbdp-market-suggest" role="region" aria-label="Anzeigen Suchvorschau" aria-live="polite" hidden></div></form>';
        }

        $html .= hbdp_market_banner_between_search_and_cards();
        $html .= '</div>';
        return $html;
    }

    /**
     * Preserve HivePress's real category filters/results. Add the shared market
     * intro in the native full-width page_header, replace the duplicate native
     * keyword form with the market search, and remove only the duplicate narrow
     * breadcrumb plus manually assigned sidebar widgets.
     */
    public static function keep_native_filters($blocks) {
        if (!is_array($blocks) || !self::is_category_request()) return $blocks;
        $term = self::current_category_term();
        if (!$term) return $blocks;

        if (isset($blocks['page_container']['blocks']['page_header']['blocks']) &&
            is_array($blocks['page_container']['blocks']['page_header']['blocks'])) {
            $header_blocks = &$blocks['page_container']['blocks']['page_header']['blocks'];
            // One keyword search (our market search) on either route. The native
            // filter sidebar, listing cards and subcategory grid remain HivePress.
            unset($header_blocks['listing_search_form']);
            // Exactly the same native template position for EVERY category
            // level, regardless of whether WordPress chose a tax archive or
            // HivePress's documented GET _category listing filter route.
            $intro = self::category_intro_html($term);
            if ($intro !== '') $header_blocks['hbdp_market_child_intro'] = array(
                'type'=>'content', 'content'=>$intro, '_order'=>1,
            );
            unset($header_blocks);
        }
        if (isset($blocks['page_container']['blocks']['page_columns']['blocks']['page_content']['blocks']['breadcrumb_menu'])) {
            unset($blocks['page_container']['blocks']['page_columns']['blocks']['page_content']['blocks']['breadcrumb_menu']);
        }
        if (isset($blocks['page_container']['blocks']['page_columns']['blocks']['page_sidebar']['blocks']['page_sidebar_widgets'])) {
            unset($blocks['page_container']['blocks']['page_columns']['blocks']['page_sidebar']['blocks']['page_sidebar_widgets']);
        }
        return $blocks;
    }

    public static function init() {
        add_filter('body_class', array(__CLASS__, 'body_classes'), 20);
        add_action('wp_body_open', array(__CLASS__, 'render_header'), 5);
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_styles'), 20);
        add_filter('hivepress/v1/templates/listings_view_page/blocks', array(__CLASS__, 'keep_native_filters'), 20);
        add_filter('hivepress/v1/templates/listing_categories_view_page/blocks', array(__CLASS__, 'keep_native_filters'), 20);
    }
}
HBDP_Hobby_Market_Profile::init();
