<?php
/**
 * Hab & Bewahr – Anzeigenmarkt-Einstieg nach dem bewährten Hobby-Depot-Aufbau.
 * Ein einziger Anzeigeweg: HivePress ist für Kategorien, Suche, Veröffentlichung
 * und Einreichung zuständig. Kein zweites Kategorien- oder Anbieterregister.
 */
if (!defined('ABSPATH')) exit;

/**
 * Markt-Startseite ist die vorhandene veröffentlichte Dienstleister-Seite.
 * HivePress-Archiv, Suchergebnisse, Filter und Inserate bleiben bei HivePress.
 */
function hbdp_market_landing_url() {
    // The actual public Anzeigenmarkt is /listing/, not a separate page.
    $live_listings = hbdp_market_listings_url();
    if ($live_listings !== '' && trim((string)parse_url($live_listings, PHP_URL_PATH), '/') === 'listing') return $live_listings;
    // Hobby Depot's proven pattern: an EXISTING published WordPress page is the
    // entrance. A native HivePress results page is not a second home page.
    $node = function_exists('hbdp_node') ? hbdp_node('directory:hub') : null;
    if (is_array($node) && ($node['type'] ?? '') === 'page' && (int)($node['wp_id'] ?? 0) > 0) {
        $page = get_post((int)$node['wp_id']);
        if ($page instanceof WP_Post && $page->post_type === 'page' && $page->post_status === 'publish') {
            $url=get_permalink($page->ID);
            if (is_string($url) && $url !== '') return $url;
        }
    }
    // Resilient to a newer central tree without accidentally linking to a
    // hidden archive, source portal or non-published page.
    if (function_exists('hbdp_footer_page_url')) {
        $url=hbdp_footer_page_url(array('dienstleister','anzeigenmarkt'));
        if (is_string($url) && $url !== '') return $url;
    }
    return hbdp_market_listings_url();
}
/** The source Hobby Depot plugin recognizes the ACTUAL HivePress route. */
function hbdp_market_hivepress_route_name() {
    if (!function_exists('hivepress')) return '';
    try {
        $app=hivepress(); $router=is_object($app) ? $app->router : null;
        if (is_object($router) && method_exists($router,'get_current_route_name')) {
            return strtolower(trim((string)$router->get_current_route_name()));
        }
    } catch (Throwable $e) {}
    return '';
}
/** True even for a filtered/archive query: never override HivePress templates. */
function hbdp_market_is_hivepress_route() {
    $route=hbdp_market_hivepress_route_name();
    if ($route==='listings_view_page') return true;
    // Archive fallback only if HivePress did not expose a route name.
    if ($route !== '') return false;
    if (function_exists('is_post_type_archive') && is_post_type_archive('hp_listing')) return true;
    // HivePress may use its configured WordPress page instead of a post archive.
    $page_id=(int)get_option('hp_page_listings',0);
    return $page_id > 0 && function_exists('is_page') && is_page($page_id);
}
/**
 * Site-specific real listings root, demonstrated by the operator screenshot:
 * https://hab-und-bewahr.de/listing/ . The previous code only recognized the
 * slugs 'dienstleister', 'anzeigenmarkt' and 'listings' (plural), so the entire
 * branded template was never selected for this actual public request.
 *
 * Match the EXACT path, not substrings or any listing detail/category URL.
 * Preserve all HivePress search/filter/pagination requests unchanged.
 */
function hbdp_market_is_actual_listing_home() {
    if (is_admin() || is_feed() || is_embed() ||
        (function_exists('is_paged') && is_paged()) ||
        (function_exists('is_tax') && is_tax()) ||
        (function_exists('is_singular') && is_singular('hp_listing')) ||
        !function_exists('post_type_exists') || !post_type_exists('hp_listing')) return false;
    foreach ($_GET as $key => $value) {
        if (strpos((string)$key, 'utm_') === 0) continue;
        return false;
    }
    $requested = (string)($_SERVER['REQUEST_URI'] ?? '');
    if ($requested === '') return false;
    $path = (string)parse_url($requested, PHP_URL_PATH);
    if (trim(rawurldecode($path), '/') !== 'listing') return false;
    // Route-specific protection: never catch a foreign HivePress route.
    $route = hbdp_market_hivepress_route_name();
    if ($route !== '' && $route !== 'listings_view_page') return false;
    return true;
}

function hbdp_market_root_request() {
    // The real public /listing/ must be handled BEFORE the old page-only test.
    if (hbdp_market_is_actual_listing_home()) return true;
    if (is_admin() || is_feed() || is_embed() || !function_exists('is_page') || !is_page()) return false;
    if (function_exists('is_paged') && is_paged()) return false;
    // The native HivePress view must own search, sort, category filters and
    // the explicit 'Alle Anzeigen' link, even if hp_page_listings == page 105.
    foreach ($_GET as $key=>$value) {
        if (strpos((string)$key,'utm_')===0) continue;
        return false;
    }
    $id = (int)get_queried_object_id();
    $node = function_exists('hbdp_node') ? hbdp_node('directory:hub') : null;
    if (is_array($node) && ($node['type'] ?? '') === 'page' && $id > 0
        && (int)($node['wp_id'] ?? 0) === $id) return true;
    // Older installs can have the real landing page without current tree mapping.
    $slug = (string)get_post_field('post_name',$id);
    if (in_array($slug,array('dienstleister','anzeigenmarkt'),true)) return true;
    // Additional existing HivePress listing page slugs ONLY when WordPress
    // explicitly assigned this page to the listings root.
    $hp_id=(int)get_option('hp_page_listings',0);
    return $id > 0 && $hp_id === $id && in_array($slug,array('anzeigen','listings'),true);
}

/** Dedicated listing/category search, never the site's general search. */
function hbdp_market_search_request() {
    if (is_admin() || is_feed() || is_embed() || !function_exists('post_type_exists') || !post_type_exists('hp_listing')) return false;
    if (!isset($_GET['hbdp_market_search']) || !is_scalar($_GET['hbdp_market_search']) || (string)wp_unslash($_GET['hbdp_market_search'])!=='1') return false;
    if (!isset($_GET['s']) || !is_scalar($_GET['s']) || hbdp_market_ajax_phrase($_GET['s'])==='') return false;
    if (isset($_GET['post_type']) && (string)$_GET['post_type']!=='hp_listing') return false;
    foreach (array_keys($_GET) as $key) {
        if (strpos((string)$key,'utm_')===0) continue;
        if (!in_array((string)$key,array('s','post_type','hbdp_market_search'),true)) return false;
    }
    $path=trim(rawurldecode((string)parse_url((string)($_SERVER['REQUEST_URI']??''),PHP_URL_PATH)),'/');
    $root=trim(rawurldecode((string)parse_url(hbdp_market_listings_url(),PHP_URL_PATH)),'/');
    return $root!=='' && $path===$root;
}

/** Use HivePress route authority. Never guess an external or source-portal URL. */
function hbdp_market_hivepress_url($route) {
    if (!function_exists('hivepress')) return '';
    try {
        $app = hivepress();
        $router = is_object($app) ? $app->router : null;
        if (is_object($router) && method_exists($router,'get_url')) {
            $url = trim((string)$router->get_url((string)$route));
            if ($url !== '') return $url;
        }
    } catch (Throwable $e) {}
    return '';
}
function hbdp_market_listings_url() {
    $url = hbdp_market_hivepress_url('listings_view_page');
    if ($url !== '') return $url;
    $page_id = (int)get_option('hp_page_listings',0);
    if ($page_id > 0) {
        $url = get_permalink($page_id);
        if (is_string($url) && $url !== '') return $url;
    }
    if (function_exists('get_post_type_archive_link')) {
        $url = get_post_type_archive_link('hp_listing');
        if (is_string($url) && $url !== '') return $url;
    }
    return ''; // No real HivePress listings page available.
}
function hbdp_market_submit_url() {
    $url = hbdp_market_hivepress_url('listing_submit_page');
    if ($url !== '') return $url;
    // Published local WordPress page only; no fabricated /submit-listing/ fallback.
    return function_exists('hbdp_footer_page_url') ? hbdp_footer_page_url(array('submit-listing')) : '';
}

/** Nine actual top-level HivePress categories, resolved from the active tree. */
function hbdp_market_card_photos() {
    return array(
        'directory:category:0a79e57abd7c' => 'topic-video-tuersprechanlage.webp',
        'directory:category:1c21a8c59a80' => 'photo-rauchmelder.webp',
        'directory:category:1dfc65728cdd' => 'topic-62-private-objektbewachung.webp',
        'directory:category:329daeb90608' => 'new-workshop.webp',
        'directory:category:9beedf679457' => 'new-electric.webp',
        'directory:category:b68360b34fd7' => 'scene-security.webp',
        'directory:category:extension:1' => 'scene-camper.webp',
        'directory:category:extension:2' => 'focus-einfahrt-tor.webp',
        'directory:category:fe1e29ce85fa' => 'new-wet.webp',
    );
}
function hbdp_market_categories() {
    // As in Hobby Depot: resolve the live HivePress taxonomy directly by name.
    // The local snapshot provides only an OPTIONAL legacy ID fallback.
    $names = array(
        'Außenanlagen & Grundstücksschutz' => 'directory:category:extension:2',
        'Brand- & Gefahrenmeldetechnik' => 'directory:category:1c21a8c59a80',
        'Elektro, Notstrom & Überspannung' => 'directory:category:9beedf679457',
        'Gesicherte Stell- & Winterplätze' => 'directory:category:extension:1',
        'Reparatur & Gutachter' => 'directory:category:329daeb90608',
        'Sicherheitsdienste & Wachdienste' => 'directory:category:1dfc65728cdd',
        'Sicherheitstechnik & Errichter' => 'directory:category:b68360b34fd7',
        'Türen, Fenster & Schließtechnik' => 'directory:category:0a79e57abd7c',
        'Wasser & Sanierungsdienste' => 'directory:category:fe1e29ce85fa',
    );
    $out = array(); $photos=hbdp_market_card_photos();
    $nodes=hbdp_all_nodes();
    $has_tax=function_exists('taxonomy_exists') && taxonomy_exists('hp_listing_category');
    foreach ($names as $name=>$id) {
        $node=$nodes[$id]??null; $term=null;
        if ($has_tax && function_exists('get_term_by')) {
            $t=get_term_by('name',$name,'hp_listing_category');
            if (is_object($t) && !is_wp_error($t)) $term=$t;
            if (!$term && is_array($node) && !empty($node['slug'])) {
                $t=get_term_by('slug',(string)$node['slug'],'hp_listing_category');
                if (is_object($t) && !is_wp_error($t)) $term=$t;
            }
        }
        if ($term) {
            $url=get_term_link($term,'hp_listing_category');
            if (is_wp_error($url)|| !is_string($url) || $url==='') continue;
        } elseif (is_array($node) && ($node['type']??'')==='hp_listing_category') {
            $url=hbdp_nav_url($node);
            if ($url==='') continue;
        } else continue; // Never invent an unavailable category or URL.
        $label = function_exists('hbdp_display_category_name')
            ? hbdp_display_category_name(array('id'=>$id,'name'=>$name)) : $name;
        $out[]=array('name'=>trim((string)$label),'url'=>$url,'image'=>$photos[$id]);
    }
    return $out;
}

/** A marked market search must search listings, not the general content index. */
add_action('pre_get_posts',function($query){
    if (is_admin() || !is_object($query) || !method_exists($query,'is_main_query') || !$query->is_main_query()) return;
    $marker=isset($_GET['hbdp_market_search']) ? (string)$_GET['hbdp_market_search'] : '';
    if ($marker !== '1' || !function_exists('post_type_exists') || !post_type_exists('hp_listing')) return;
    $query->set('post_type','hp_listing');
    $query->set('post_status','publish');
});

function hbdp_market_real_listings($q='', $limit=6) {
    if (!function_exists('post_type_exists') || !post_type_exists('hp_listing')) return array();
    $args=array('post_type'=>'hp_listing','post_status'=>'publish','numberposts'=>max(1,min(60,(int)$limit)),'orderby'=>'date','order'=>'DESC','suppress_filters'=>false);
    if (trim((string)$q)!=='') { $args['s']=hbdp_market_ajax_phrase($q); $args['orderby']='relevance'; }
    $items=get_posts($args);
    if (!is_array($items)) return array();
    $out=array();
    foreach ($items as $post) {
        if (!($post instanceof WP_Post) || $post->post_status !== 'publish') continue;
        $url=get_permalink($post->ID);
        if (!is_string($url) || $url === '') continue;
        $image=function_exists('get_the_post_thumbnail_url') ? get_the_post_thumbnail_url($post->ID,'medium_large') : '';
        $out[]=array('title'=>get_the_title($post),'url'=>$url,'image'=>is_string($image)?$image:'');
    }
    return $out;
}
function hbdp_market_real_banner($slot) {
    if (!function_exists('hbdp_editorial_banner_markup')) return '';
    // The newly requested slot between cards and search is visible to admins
    // even when empty. Do not add an extra empty slot above the hero.
    $html=hbdp_editorial_banner_markup($slot,'directory:hub');
    if ($slot==='market-start-1' && strpos($html,'hbdp-editorial-ad-empty')!==false) return '';
    return $html;
}
/** One clearly visible advertising place between search and category cards,
 * following the working Hobby Depot order. Only a real assigned creative is
 * shown as affiliate advertising; otherwise this is our OWN advertising invitation.
 */
function hbdp_market_banner_between_search_and_cards() {
    $html=hbdp_market_real_banner('market-start-2');
    if ($html!=='' && strpos($html,'hbdp-editorial-ad-empty')===false) {
        return '<div class="hbdp-market-between-banner">'.$html.'</div>';
    }
    return '<div class="hbdp-market-between-banner">'.hbdp_house_ad_premium_html().'</div>';
}
function hbdp_market_render_landing($native_archive=false) {
    $categories=hbdp_market_categories();
    $listings=$native_archive ? array() : hbdp_market_real_listings();
    $listings_url=hbdp_market_listings_url();
    $submit_url=hbdp_market_submit_url();
    $price_url=function_exists('hbdp_footer_page_url')?hbdp_footer_page_url(array('preise')):'';
    echo '<div class="hbdp-frame hbdp-market'.($native_archive?' hbdp-market-native':'').'">';
    echo '<nav class="hbdp-crumb" aria-label="Brotkrumennavigation"><a href="'.esc_url(home_url('/')).'">Startseite</a><span>/</span><span>Anzeigenmarkt</span></nav>';
    echo '<section class="hbdp-market-hero"><div class="hbdp-market-hero-copy"><span class="hbdp-eyebrow">DIENSTLEISTER UND ANZEIGEN</span><h1>Anzeigenmarkt</h1><p>Dienstleister und Schutzangebote finden.</p><div class="hbdp-market-actions">';
    // These primary entry points must be visible ABOVE the category tiles.
    // 0.1.131 incorrectly moved submission below all cards and hid the
    // listing-overview link in the (possibly empty) latest-listings section.
    if ($submit_url !== '') echo '<a class="hbdp-market-primary" href="'.esc_url($submit_url).'">Anzeige aufgeben</a>';
    // The listing market is already the listing overview; no redundant link or hbdp_market_all bypass.
    if ($price_url !== '') echo '<a class="hbdp-market-secondary" href="'.esc_url($price_url).'">Anzeigenpreise</a>';
    echo '</div></div><div class="hbdp-market-hero-photo"><img src="'.esc_url(HBDP_URL.'assets/new-shop.webp').'" width="1619" height="971" alt="Kleiner Betrieb als Beispiel für den Anzeigenmarkt" decoding="async" fetchpriority="high"></div></section>';
    if ($listings_url !== '' && function_exists('post_type_exists') && post_type_exists('hp_listing')) {
        echo '<form class="hbdp-market-search" data-hbdp-market-search action="'.esc_url($listings_url).'" method="get" role="search"><label for="hbdp-market-q">Anzeigen durchsuchen</label><div class="hbdp-market-search-fields"><input type="search" id="hbdp-market-q" name="s" placeholder="Dienstleister oder Leistung suchen" autocomplete="off" aria-autocomplete="list" aria-controls="hbdp-market-search-preview" aria-expanded="false" required><input type="hidden" name="post_type" value="hp_listing"><input type="hidden" name="hbdp_market_search" value="1"><button type="submit">Suchen</button></div><div id="hbdp-market-search-preview" class="hbdp-market-suggest" role="region" aria-label="Anzeigen Suchvorschau" aria-live="polite" hidden></div></form>';
    }
    echo hbdp_market_banner_between_search_and_cards();
    echo '<section class="hbdp-market-section" aria-labelledby="hbdp-market-cat-title"><header class="hbdp-market-section-head"><h2 id="hbdp-market-cat-title">Was suchen Sie?</h2><p>Wählen Sie den passenden Dienstleistungsbereich.</p></header>';
    if ($categories) {
        echo '<div class="hbdp-market-categories">';
        foreach ($categories as $c) {
            echo '<a class="hbdp-market-card" href="'.esc_url($c['url']).'"><img src="'.esc_url(HBDP_URL.'assets/'.$c['image']).'" alt="" loading="lazy" decoding="async"><span><strong>'.esc_html($c['name']).'</strong><b aria-hidden="true">→</b></span></a>';
        }
        echo '</div>';
    } else echo '<p class="hbdp-market-empty">Die Dienstleisterkategorien sind derzeit nicht verfügbar.</p>';
    echo '</section>';
    if ($submit_url!=='') echo '<div class="hbdp-market-submit-band"><div><strong>Sie bieten Schutz oder Dienstleistungen an?</strong><p>Erreichen Sie Menschen, die eine passende Lösung suchen.</p></div><a class="hbdp-market-primary" href="'.esc_url($submit_url).'">Anzeige aufgeben</a></div>';

    if ($native_archive) {
        // HivePress itself prints the real published listing cards immediately
        // after wp_body_open; do not duplicate, query or fake these cards.
        echo '<section class="hbdp-market-section hbdp-market-current" aria-label="Aktuelle Anzeigen"><header class="hbdp-market-section-head"><h2>Aktuelle Anzeigen</h2></header></section></div>';
        return;
    }
    echo '<section class="hbdp-market-section hbdp-market-current" aria-labelledby="hbdp-market-current-title"><header class="hbdp-market-section-head"><h2 id="hbdp-market-current-title">Aktuelle Anzeigen</h2>';
    // No second route to the old unstyled HivePress archive.
    echo '</header>';
    if ($listings) {
        echo '<div class="hbdp-market-listings">';
        foreach ($listings as $a) {
            echo '<a class="hbdp-market-listing" href="'.esc_url($a['url']).'">';
            if ($a['image'] !== '') echo '<img src="'.esc_url($a['image']).'" alt="" loading="lazy" decoding="async">';
            echo '<strong>'.esc_html($a['title']).'</strong><span>Anzeige ansehen →</span></a>';
        }
        echo '</div>';
    } else {
        echo '<p class="hbdp-market-empty">Derzeit sind noch keine Anzeigen veröffentlicht.</p>';
    }
    echo '</section></div>';
}

/** Branded results from the same two live sources as the market AJAX suggestions. */
function hbdp_market_render_search_results() {
    $q=hbdp_market_ajax_phrase($_GET['s']??'');
    $categories=hbdp_market_category_matches($q,24);
    $listings=hbdp_market_real_listings($q,40);
    $market=hbdp_market_landing_url();
    echo '<main class="hbdp-frame hbdp-market hbdp-market-results"><nav class="hbdp-crumb" aria-label="Brotkrumennavigation"><a href="'.esc_url(home_url('/')).'">Startseite</a><span>/</span>';
    if ($market!=='') echo '<a href="'.esc_url($market).'">Anzeigenmarkt</a><span>/</span>';
    echo '<span>Suche</span></nav><span class="hbdp-eyebrow">ANZEIGENMARKT</span><h1>Suchergebnisse für „'.esc_html($q).'“</h1><p>Passende Dienstleisterkategorien und veröffentlichte Anzeigen.</p>';
    if ($categories) {
        echo '<section class="hbdp-market-section"><h2>Passende Kategorien</h2><div class="hbdp-market-category-results">';
        foreach ($categories as $row) echo '<a href="'.esc_url($row['url']).'">'.esc_html($row['title']).'<span aria-hidden="true">→</span></a>';
        echo '</div></section>';
    }
    echo '<section class="hbdp-market-section"><h2>Passende Anzeigen</h2>';
    if ($listings) {
        echo '<div class="hbdp-market-listings">';
        foreach($listings as $row){echo '<a class="hbdp-market-listing" href="'.esc_url($row['url']).'">';
            if($row['image']!=='') echo '<img loading="lazy" decoding="async" src="'.esc_url($row['image']).'" alt="">';
            echo '<strong>'.esc_html($row['title']).'</strong><span>Anzeige ansehen →</span></a>';}
        echo '</div>';
    } else echo '<p class="hbdp-market-empty">Keine passenden veröffentlichten Anzeigen gefunden.'.($categories?' Wählen Sie oben eine passende Kategorie.':'').'</p>';
    echo '</section>';
    if(!$categories && !$listings) echo '<p>Versuchen Sie einen anderen Suchbegriff.</p>';
    if($market!=='') echo '<p><a class="hbdp-market-back" href="'.esc_url($market).'">← Zurück zum Anzeigenmarkt</a></p>';
    echo '</main>';
}
