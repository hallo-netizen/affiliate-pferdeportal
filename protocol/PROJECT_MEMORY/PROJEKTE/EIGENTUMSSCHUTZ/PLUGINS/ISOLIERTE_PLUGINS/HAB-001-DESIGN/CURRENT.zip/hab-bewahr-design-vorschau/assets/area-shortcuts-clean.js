(function(){
 'use strict';
 /* 0.1.77: remove ONLY a legacy bar whose sole links are Magazin + Dienstleister,
    including its border/wrapper; never remove real magazine article cards or footer. */
 var excluded='.hbdp-area-demo-magazine,.hbdp-area-demo-reading,.hbdp-world-reading,.hbdp-world-topic-grid,.hbdp-mainnav-wrap,.hbdp-footer,.hbd-header,#wpadminbar,.hbdp-area-demo-topics,.hbdp-world-hero';
 function norm(v){return (v||'').replace(/ /g,' ').replace(/\s+/g,' ').trim();}
 function clean(v){return norm(v).replace(/[\s|·•\/–—:]+/g,'');}
 function safe(el){return !!(el&&el.isConnected&&!el.closest(excluded));}
 function isOnlyStrip(el){
   if(!el||!safe(el)||el.matches('html,body,.hbdp,main,header,footer'))return false;
   var links=Array.prototype.slice.call(el.querySelectorAll('a,button'));
   if(links.length!==2)return false;
   var labels=links.map(function(a){return norm(a.textContent);}).sort();
   if(labels[0]!=='Dienstleister'||labels[1]!=='Magazin')return false;
   return clean(el.textContent)==='MagazinDienstleister'||clean(el.textContent)==='DienstleisterMagazin';
 }
 function emptyBar(el){
   if(!el||!safe(el)||el.matches('html,body,.hbdp,main,header,footer'))return false;
   if(norm(el.textContent)!=='')return false;
   if(el.querySelector('img,iframe,video,svg,canvas,input,form,article,section,main'))return false;
   return true;
 }
 function cleanup(){
   // The obsolete bar also appears on service pages; never gate by page type.
   // Known original obsolete strip incl its border.
   Array.prototype.forEach.call(document.querySelectorAll('.hbdp-footer-shortcuts,#hbdp-footer-shortcuts'),function(el){
      if(safe(el))el.remove();
   });
   var nodes=Array.prototype.filter.call(document.querySelectorAll('a,button'),function(a){
      return safe(a)&&(norm(a.textContent)==='Magazin'||norm(a.textContent)==='Dienstleister');
   });
   nodes.forEach(function(anchor){
      if(!anchor.isConnected)return;
      var selected=null;
      for(var p=anchor.parentElement,depth=0;p && depth<9; p=p.parentElement,depth++){
        if(!safe(p)||p.matches('html,body,.hbdp,main,header,footer'))break;
        if(isOnlyStrip(p))selected=p;
        else if(selected)break;
      }
      if(!selected)return;
      var up=selected.parentElement;
      selected.remove();
      for(var i=0;i<4 && emptyBar(up);i++){
         var prev=up.parentElement;up.remove();up=prev;
      }
   });
 }
 var queued=false;
 function schedule(){if(queued)return;queued=true;Promise.resolve().then(function(){queued=false;cleanup();});}
 cleanup();
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',cleanup,{once:true});
 if(typeof MutationObserver!=='undefined'){
   var o=new MutationObserver(function(records){
     for(var i=0;i<records.length;i++)if(records[i].addedNodes.length){schedule();break;}
   });
   o.observe(document.documentElement,{childList:true,subtree:true});
   window.addEventListener('load',function(){cleanup();setTimeout(function(){o.disconnect();cleanup();},8000);},{once:true});
 }
})();
