<?php
/** Reusable, explicitly mapped partner banner slots. No affiliate program or product data is invented. */
if (!defined('ABSPATH')) exit;
function hbdp_editorial_banner_contexts(){
 return array(
  'compass-start-1'=>'Schutzkompass · Start · Slot 1',
  'compass-start-2'=>'Schutzkompass · Start · Slot 2',
  'compass-detail-1'=>'Schutzkompass · Zielseiten',
  'magazin-start-1'=>'Magazin · Start · Slot 1',
  'magazin-start-2'=>'Magazin · Start · Slot 2',
  'magazin-detail-1'=>'Magazin · Zielseiten · Slot 1',
  'magazin-detail-2'=>'Magazin · Zielseiten · Slot 2',
  'market-start-1'=>'Anzeigenmarkt · Start · Banner 1',
  'market-start-2'=>'Anzeigenmarkt · Start · Banner 2',
  'market-submit-1'=>'Anzeigenmarkt · Anzeige aufgeben · freier Bannerplatz über dem Formular',
 );
}
function hbdp_editorial_banner_validate($raw){
 if(!is_array($raw))return array();
 $safe=array();
 foreach(hbdp_editorial_banner_contexts() as $slot=>$label){
  $candidate=$raw[$slot]??null;
  if(!is_array($candidate))continue;
  $url=trim(esc_url_raw((string)($candidate['url']??'')));
  $image=trim(esc_url_raw((string)($candidate['image']??'')));
  if(stripos($url,'https://')!==0 || stripos($image,'https://')!==0)continue;
  if(!wp_http_validate_url($url)||!wp_http_validate_url($image))continue;
  $safe[$slot]=array('url'=>$url,'image'=>$image,'label'=>sanitize_text_field((string)($candidate['label']??'')),'alt'=>sanitize_text_field((string)($candidate['alt']??'')));
 }
 return $safe;
}
function hbdp_editorial_banner_markup($slot,$node_id=''){
 static $option=null;
 if(!isset(hbdp_editorial_banner_contexts()[$slot]))return '';
 if($option===null){$saved=get_option('hbdp_editorial_banners_v1',array());$option=is_array($saved)?$saved:array();}
 $entry=$option[$slot]??null;
 $html='';
 if(is_array($entry)&&!empty($entry['url'])&&!empty($entry['image'])){
  $label=(string)($entry['label']??'Partnerangebot');
  $alt=(string)($entry['alt']??$label);
  $html='<a class="hbdp-editorial-ad-link" href="'.esc_url($entry['url']).'" target="_blank" rel="sponsored noopener noreferrer"><img loading="lazy" decoding="async" src="'.esc_url($entry['image']).'" alt="'.esc_attr($alt).'"><span>'.esc_html($label).'</span></a>';
 }
 // An existing affiliate provider can supply creatives through the same centralized bridge.
 if($html===''){
  $provided=apply_filters('hbdp_editorial_banner_html','',$slot,$node_id);
  if(is_string($provided))$html=trim(wp_kses_post($provided));
 }
 // Backward compatible existing category banner hook, once per page, never duplicate for slot 2.
 if($html==='' && preg_match('/-1$/',$slot)){
  $provided=apply_filters('hbdp_area_auto_banner_html','',$node_id);
  if(is_string($provided))$html=trim(wp_kses_post($provided));
 }
 if($html===''){
  if(!current_user_can('manage_options'))return '';
  return '<div class="hbdp-editorial-ad hbdp-editorial-ad-empty"><small>Nur Admin · freier Affiliate-Bannerslot</small><p>Kein freigegebenes Werbemittel: '.esc_html(hbdp_editorial_banner_contexts()[$slot]).'. <a href="'.esc_url(admin_url('options-general.php?page=hbdp-editorial-banners')).'">Partnerbanner zuordnen</a></p></div>';
 }
 return '<aside class="hbdp-editorial-ad" aria-label="Werbung"><small>Anzeige · Affiliate</small>'.$html.'</aside>';
}
add_action('admin_menu',static function(){
 add_options_page('Hab & Bewahr Partnerbanner','Hab & Bewahr Banner','manage_options','hbdp-editorial-banners','hbdp_editorial_banner_settings_page');
});
add_action('admin_post_hbdp_editorial_banner_save',static function(){
 if(!current_user_can('manage_options'))wp_die('Nicht berechtigt');
 check_admin_referer('hbdp_editorial_banners_v1');
 $raw=isset($_POST['banners'])?wp_unslash($_POST['banners']):array();
 update_option('hbdp_editorial_banners_v1',hbdp_editorial_banner_validate($raw),false);
 wp_safe_redirect(add_query_arg('saved','1',admin_url('options-general.php?page=hbdp-editorial-banners')));exit;
});
function hbdp_editorial_banner_settings_page(){
 if(!current_user_can('manage_options'))return;
 $data=get_option('hbdp_editorial_banners_v1',array());if(!is_array($data))$data=array();
 echo '<div class="wrap"><h1>Hab & Bewahr – Partnerbanner</h1><p>Werbemittel für den Schutzkompass und die Magazinseiten. Pro Slot einen freigegebenen Partnerlink und die Banner-Bildadresse (beide HTTPS) eintragen. Leere Slots sind öffentlich unsichtbar. Kein zusätzlicher Banner im unteren Kategorie-Raster.</p>';
 if(!empty($_GET['saved']))echo '<div class="notice notice-success"><p>Bannerzuordnung gespeichert.</p></div>';
 echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="hbdp_editorial_banner_save">';wp_nonce_field('hbdp_editorial_banners_v1');
 foreach(hbdp_editorial_banner_contexts() as $slot=>$title){$e=$data[$slot]??array();echo '<fieldset style="background:#fff;border:1px solid #ddd;padding:12px;margin:12px 0;max-width:950px"><legend><strong>'.esc_html($title).'</strong></legend>';
  foreach(array('label'=>'Partnername','url'=>'Affiliate-Ziel-URL (HTTPS)','image'=>'Bannerbild-URL (HTTPS)','alt'=>'Bildbeschreibung') as $key=>$name){
   echo '<p><label>'.esc_html($name).'<br><input type="text" class="large-text" name="banners['.esc_attr($slot).']['.esc_attr($key).']" value="'.esc_attr((string)($e[$key]??'')).'" autocomplete="off"></label></p>';
  }
  echo '</fieldset>';
 }
 submit_button('Banner speichern');echo '</form></div>';
}
