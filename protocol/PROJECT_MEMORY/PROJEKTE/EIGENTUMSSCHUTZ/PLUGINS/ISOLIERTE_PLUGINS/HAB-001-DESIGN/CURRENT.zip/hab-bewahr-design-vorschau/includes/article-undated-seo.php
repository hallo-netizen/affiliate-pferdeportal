<?php
/**
 * Hab & Bewahr: no editorial publication/update dates on single normal posts.
 * Keeps Yoast's other SEO/structured data intact; no database/post/date writes.
 * Google may still independently infer a date from crawls, URLs or other signals.
 */
if (!defined('ABSPATH')) exit;

function hbdp_article_date_suppressed() {
    return !is_admin() && function_exists('is_singular') && is_singular('post');
}

function hbdp_undated_schema_piece($piece) {
    if (!hbdp_article_date_suppressed() || !is_array($piece)) return $piece;
    unset($piece['datePublished'], $piece['dateModified'], $piece['dateCreated']);
    return $piece;
}
add_filter('wpseo_schema_article', 'hbdp_undated_schema_piece', 20, 1);
add_filter('wpseo_schema_webpage', 'hbdp_undated_schema_piece', 20, 1);

// Also covers the complete Yoast graph and additional Article/WebPage graph pieces.
add_filter('wpseo_schema_graph', static function($graph) {
    if (!hbdp_article_date_suppressed() || !is_array($graph)) return $graph;
    foreach ($graph as $index => $piece) {
        if (!is_array($piece)) continue;
        $types = isset($piece['@type']) ? (array)$piece['@type'] : array();
        $types = array_map('strval', $types);
        if (!array_intersect($types, array('WebPage','Article','BlogPosting','NewsArticle','TechArticle','Report','HowTo'))) continue;
        unset($graph[$index]['datePublished'], $graph[$index]['dateModified'], $graph[$index]['dateCreated']);
    }
    return $graph;
}, 100, 1);

// Yoast OG presenters can also give Google a publication or modification date.
function hbdp_undated_is_time_presenter($name) {
    return in_array(ltrim((string)$name, '\\'), array(
        'Yoast\\WP\\SEO\\Presenters\\Open_Graph\\Article_Published_Time_Presenter',
        'Yoast\\WP\\SEO\\Presenters\\Open_Graph\\Article_Modified_Time_Presenter',
    ), true);
}
add_filter('wpseo_frontend_presenter_classes', static function($classes) {
    if (!hbdp_article_date_suppressed() || !is_array($classes)) return $classes;
    return array_values(array_filter($classes, static function($c) {
        return !is_string($c) || !hbdp_undated_is_time_presenter($c);
    }));
}, 100, 1);
add_filter('wpseo_frontend_presenters', static function($presenters) {
    if (!hbdp_article_date_suppressed() || !is_array($presenters)) return $presenters;
    return array_values(array_filter($presenters, static function($presenter) {
        return !is_object($presenter) || !hbdp_undated_is_time_presenter(get_class($presenter));
    }));
}, 100, 1);

// Yoast may show published-time metadata in other integrations; block this on posts.
add_filter('wpseo_opengraph_show_publish_date', static function($show) {
    return hbdp_article_date_suppressed() ? false : $show;
}, 100, 1);
