<?php
if (!defined('ABSPATH')) exit;
/** Existing R2 hierarchy, grouped once in-memory. Never updates WordPress categories. */
function hbdp_nav_children_index(){
    static $by_parent=null;
    if($by_parent!==null)return $by_parent;
    $by_parent=array();
    foreach(hbdp_all_nodes() as $node){
        $parent=$node['parent'] ?? '';
        if($parent!=='')$by_parent[$parent][]=$node;
    }
    return $by_parent;
}
function hbdp_nav_children($id){return hbdp_canonical_children($id);}
function hbdp_nav_active_world($section){
    $node=hbdp_node($section);$seen=array();
    while($node && !isset($seen[$node['id']])){
        $seen[$node['id']]=true;
        if(strpos($node['id'],'core:world:')===0)return $node['id'];
        $node=hbdp_node($node['parent']);
    }
    return '';
}
/** Only 6 worlds, 31 areas and 93 subareas: no 285 leaves in the mega menu. */
function hbdp_world_explanation($world_id){
    $copy=array(
        'core:world:einbruch-und-diebstahl'=>'So schützt du dein Zuhause, deine Fahrzeuge und deine Wertsachen vor Einbruch und Diebstahl.',
        'core:world:vandalismus-und-zerstorung'=>'So schützt du dein Eigentum vor Graffiti, Sachbeschädigung und mutwilliger Zerstörung.',
        'core:world:wasser-und-feuchtigkeit'=>'So schützt du dein Haus und Grundstück vor Wasserschäden, Feuchtigkeit, Rückstau und Frost.',
        'core:world:feuer-und-gase'=>'So schützt du dich und dein Eigentum vor Feuer, Rauch, gefährlichen Gasen und Akkubränden.',
        'core:world:wetter-und-naturgefahren'=>'So schützt du Haus, Garten und Freizeitwerte vor Sturm, Hagel, Starkregen und anderen Naturgefahren.',
        'core:world:technik-und-ausfalle'=>'So schützt du dein Zuhause vor Stromausfällen, technischen Defekten und versagenden Warnsystemen.'
    );
    return $copy[$world_id]??'';
}
/** Visible nav labels are purposefully SHORT. Full titles are retained for flyout headings. */
function hbdp_world_nav_label($world_id){
    $copy=array(
        'core:world:einbruch-und-diebstahl'=>'Einbruch',
        'core:world:vandalismus-und-zerstorung'=>'Vandalismus',
        'core:world:wasser-und-feuchtigkeit'=>'Wasser',
        'core:world:feuer-und-gase'=>'Feuer & Gase',
        'core:world:wetter-und-naturgefahren'=>'Wetter & Natur',
        'core:world:technik-und-ausfalle'=>'Technik',
        'core:world:insurance'=>'Versicherungen'
    );
    return $copy[$world_id]??'';
}
function hbdp_nav_mark_active($markup,$active) {
    if($active==='')return $markup;
    $needle='<details class="hbdp-navworld" data-world="'.esc_attr($active).'"';
    $replace='<details class="hbdp-navworld is-active" data-world="'.esc_attr($active).'"';
    return str_replace($needle,$replace,$markup);
}
function hbdp_main_navigation($worlds,$section){
    $active=hbdp_nav_active_world($section);
    // One cached menu across all design pages. Active-state mark added without rebuilding menu.
    $key='hbdp_nav_'.md5('0.1.117-dashless-category-titles|'.hbdp_active_revision().'|'.home_url('/'));
    if(function_exists('get_transient')) {
        $cached=get_transient($key);
        if(is_string($cached) && $cached!==''){echo hbdp_nav_mark_active($cached,$active);return;}
    }
    ob_start();
    echo '<div class="hbdp-mainnav-wrap"><div class="hbdp-frame"><button type="button" class="hbdp-mobile-toggle" aria-expanded="false" aria-controls="hbdp-world-navigation" aria-label="Schutzweltenmenü öffnen"><span class="hbdp-mobile-toggle-icon" aria-hidden="true">☰</span><span>Schutzwelten</span><span class="hbdp-mobile-toggle-state">Menü öffnen</span></button><nav id="hbdp-world-navigation" class="hbdp-mainnav" aria-label="Schutzwelten">';
    foreach($worlds as $world){
        $areas=hbdp_menu_sort_areas(hbdp_nav_children($world['id']));
        // Five columns per row, never a five-area content ceiling.
        $nav_name=hbdp_world_nav_label($world['id']);
        echo '<details class="hbdp-navworld" data-world="'.esc_attr($world['id']).'"><summary aria-label="'.esc_attr(hbdp_compass_display_name($world)).'"><a class="hbdp-navworld-link" href="'.esc_url(hbdp_url($world)).'" aria-label="'.esc_attr(hbdp_compass_display_name($world)).' – Themenseite öffnen">'.esc_html($nav_name).'</a><span class="hbdp-navchevron" aria-hidden="true">⌄</span></summary>';
        echo '<div class="hbdp-mega"><div class="hbdp-mega-inner">';
        echo '<div class="hbdp-mega-heading"><div class="hbdp-mega-intro"><strong>'.esc_html(hbdp_compass_display_name($world)).'</strong><p>'.esc_html(hbdp_world_explanation($world['id'])).'</p></div></div>';
        echo '<div class="hbdp-megagrid hbdp-megagrid--'.count($areas).'">';
        foreach($areas as $area){
            $area_name=hbdp_menu_label($area);
            $area_url=hbdp_nav_url($area);if($area_url==='')continue;
            echo '<section class="hbdp-mega-area"><a class="hbdp-mega-area-title" title="'.esc_attr(hbdp_compass_display_name($area)).'" aria-label="'.esc_attr(hbdp_compass_display_name($area)).'" href="'.esc_url($area_url).'">'.esc_html($area_name).'</a>';
            echo '<div class="hbdp-mega-subareas">';
            $nlinks=0;$available_links=0;
            foreach(hbdp_nav_children($area['id']) as $subarea){
                $url=hbdp_nav_url($subarea);if($url==='')continue;
                $available_links++;
                if($nlinks>=4)continue;
                $sub_name=hbdp_menu_label($subarea);
                echo '<a class="hbdp-mega-subarea-link" title="'.esc_attr(hbdp_compass_display_name($subarea)).'" aria-label="'.esc_attr(hbdp_compass_display_name($subarea)).'" href="'.esc_url($url).'">'.esc_html($sub_name).'</a>';
                $nlinks++;
            }
            for($i=$nlinks;$i<4;$i++)echo '<span class="hbdp-mega-spacer" aria-hidden="true"></span>';
            echo '</div>';
            if($available_links>$nlinks){
                echo '<a class="hbdp-mega-more" href="'.esc_url($area_url).'" aria-label="Alle Themen in '.esc_attr(hbdp_compass_display_name($area)).'">Alle Themen <span aria-hidden="true">→</span></a>';
            }
            echo '</section>';
        }
        echo '</div></div></div></details>';
    }
    // Magazine and service providers stay accessible via footer, not the main navigation.
    echo '</nav></div></div>';
    $markup=(string)ob_get_clean();
    if(function_exists('set_transient'))set_transient($key,$markup,DAY_IN_SECONDS);
    echo hbdp_nav_mark_active($markup,$active);
}

