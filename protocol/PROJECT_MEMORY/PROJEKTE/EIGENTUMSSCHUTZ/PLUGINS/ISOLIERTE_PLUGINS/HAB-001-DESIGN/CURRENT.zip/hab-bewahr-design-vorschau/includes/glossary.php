<?php
/** Glossary presentation. One public canonical WordPress page (editorial:glossar); all data in native WP drafts/posts. */
if(!defined('ABSPATH'))exit;
/** Canonical public route belongs solely to the glossary view, not an assumed published WP page. */
function hbdp_glossary_url() { return home_url('/glossar/'); }
/** Magazine owns the editorial area; use the same resolved target as the existing footer. */
function hbdp_glossary_magazine_url() {
    if (function_exists('hbdp_footer_page_url')) {
        $url=hbdp_footer_page_url(array('magazin','journal'));
        if(is_string($url) && $url!=='')return $url;
    }
    if (function_exists('hbdp_node') && function_exists('hbdp_nav_url')) {
        $node=hbdp_node('editorial:hub');
        if($node){$url=hbdp_nav_url($node);if(is_string($url)&&$url!=='')return $url;}
    }
    return '';
}
/** Consistent hierarchy for glossary index, drafts and published glossary terms. */
function hbdp_glossary_breadcrumb($name='') {
    echo '<nav class="hbdp-crumb" aria-label="Brotkrumennavigation"><a href="'.esc_url(home_url('/')).'">Startseite</a><span aria-hidden="true">/</span>';
    $magazine=hbdp_glossary_magazine_url();
    if($magazine!=='')echo '<a href="'.esc_url($magazine).'">Magazin</a>';
    else echo '<span>Magazin</span>';
    echo '<span aria-hidden="true">/</span>';
    if($name==='')echo '<span aria-current="page">Glossar</span>';
    else echo '<a href="'.esc_url(hbdp_glossary_url()).'">Glossar</a><span aria-hidden="true">/</span><span aria-current="page">'.esc_html($name).'</span>';
    echo '</nav>';
}
function hbdp_glossary_request_path() {
    $path = trim((string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH), '/');
    $base = trim((string)parse_url(home_url('/'), PHP_URL_PATH), '/');
    if ($base !== '' && strpos($path, $base.'/') === 0) $path = substr($path, strlen($base)+1);
    return $path;
}
function hbdp_is_glossary_path() {return hbdp_glossary_request_path() === 'glossar';}
/** Read-only preview route, never an automatically published WordPress post. */
function hbdp_glossary_preview_slug() {
    $path=hbdp_glossary_request_path();
    return preg_match('~^glossar/([a-z0-9]+(?:-[a-z0-9]+)*)$~D', $path, $m) ? $m[1] : '';
}
/** The migrated WordPress record is authoritative, including non-indexable editorial previews. */
function hbdp_glossary_preview_record($slug='') {
    if($slug==='')$slug=hbdp_glossary_preview_slug();
    if($slug==='')return null;
    $post=get_page_by_path($slug,OBJECT,'hbdp_glossar_term');
    if($post && get_post_meta($post->ID,'_hbdp_import_source',true)===HBDP_GLOSS_MIGRATION_SOURCE && ($post->post_status==='publish' || (in_array($post->post_status,array('draft','pending'),true) && current_user_can('edit_post',$post->ID)))){
        $body=trim((string)$post->post_content);
        return array('begriff'=>$post->post_title,'slug'=>$post->post_name,
            'kurzdefinition'=>(string)get_post_meta($post->ID,'_hbdp_short',true),
            'themenwelt'=>(string)get_post_meta($post->ID,'_hbdp_world',true),
            'verwandte_begriffe'=>(array)get_post_meta($post->ID,'_hbdp_related',true),
            'fachtext'=>$body===''?array():preg_split('/\n\s*\n/u',$body));
    }
    if(!current_user_can('edit_posts') || hbdp_glossary_import_completed())return null;
    foreach(hbdp_glossary_quickreference() as $term) {
        if(is_array($term) && ($term['slug']??'')===$slug && !empty($term['kurzdefinition']))return $term;
    }
    return null;
}
function hbdp_is_glossary_preview_path() {return hbdp_glossary_preview_record()!==null;}
function hbdp_glossary_preview_url($slug) {
    return home_url('/glossar/'.rawurlencode((string)$slug).'/');
}

function hbdp_is_old_glossary_path() {return in_array(hbdp_glossary_request_path(),array('magazin/magazin-glossar-a-z','magazin-glossar-a-z'),true);}
// Route must work on first install even if WP permalinks were not flushed and the old native page is 404.
add_action('parse_request',static function($wp){
    if(hbdp_is_glossary_path()){ $wp->query_vars['hbdp_glossary']='1'; unset($wp->query_vars['error']); }
    if(hbdp_is_glossary_preview_path()){ $wp->query_vars['hbdp_glossary_preview']=hbdp_glossary_preview_slug(); unset($wp->query_vars['error']); }
});
add_action('init',static function(){
    add_rewrite_rule('^glossar/?$', 'index.php?hbdp_glossary=1', 'top');
    add_rewrite_rule('^glossar/([a-z0-9-]+)/?$', 'index.php?hbdp_glossary_preview=$matches[1]', 'top');
});
add_filter('query_vars',static function($vars){$vars[]='hbdp_glossary';$vars[]='hbdp_glossary_preview';return $vars;});
add_filter('pre_handle_404',static function($handled){return (hbdp_is_glossary_path()||hbdp_is_glossary_preview_path())?true:$handled;});
add_filter('redirect_canonical',static function($redirect){return (hbdp_is_glossary_path()||hbdp_is_glossary_preview_path()||hbdp_is_old_glossary_path())?false:$redirect;});
add_action('template_redirect',static function(){
    if(hbdp_is_old_glossary_path()) {wp_safe_redirect(hbdp_glossary_url(),301);exit;}
    if(hbdp_is_glossary_preview_path()) {
        $slug=hbdp_glossary_preview_slug();
        $post=$slug?get_page_by_path($slug,OBJECT,'hbdp_glossar_term'):null;
        if($post && $post->post_status==='publish'){
            wp_safe_redirect(get_permalink($post->ID),301);exit;
        }
    }
    if(hbdp_is_glossary_path() || hbdp_is_glossary_preview_path()) {
        global $wp_query;
        if($wp_query && $wp_query->is_404)$wp_query->is_404=false;
        status_header(200);
        if(hbdp_is_glossary_preview_path() && !headers_sent())header('X-Robots-Tag: noindex, follow',true);
    }
},0);
function hbdp_glossary_letter($term) {
    // Unicode-safe even when mbstring is not installed on a WordPress host.
    $letter=preg_match('/^./u',(string)$term,$match)?$match[0]:'#';
    $letter=strtr($letter,array('Ä'=>'A','Ö'=>'O','Ü'=>'U','ä'=>'A','ö'=>'O','ü'=>'U'));
    $letter=strtoupper($letter);
    return preg_match('/^[A-Z]$/',$letter)?$letter:'#';
}
function hbdp_glossary_public_terms() {
    // Queried solely on a glossary page; 1 query, no WP category writes or front-end cron.
    $items=get_posts(array('post_type'=>'hbdp_glossar_term','post_status'=>'publish','numberposts'=>-1,'orderby'=>'title','order'=>'ASC','suppress_filters'=>false));
    return is_array($items)?$items:array();
}
/** Read-only researched quick-reference register. Native manually published WordPress terms take precedence. */
function hbdp_glossary_quickreference() {
    static $cached=null; if($cached!==null)return $cached;
    // Seed is a migration backup only after the complete 82/82 readback.
    if(hbdp_glossary_import_completed())return $cached=array();
    $file=HBDP_ROOT.'data/glossary-quickreference.json';
    if(!is_readable($file))return $cached=array();
    $raw=json_decode(file_get_contents($file),true);
    if(!is_array($raw)||($raw['contract_version']??'')!=='HB_GLOSSARY_QUICKREFERENCE_V1'||!is_array($raw['entries']??null))return $cached=array();
    return $cached=$raw['entries'];
}
function hbdp_glossary_normalized_name($name) {
    $s=remove_accents((string)$name);
    return function_exists('mb_strtolower')?mb_strtolower(trim($s),'UTF-8'):strtolower(trim($s));
}
function hbdp_glossary_public_index() {
    $entries=array();$native=array();
    // Only real published terms and specifically migrated legacy previews.
    // Newly drafted/edited glossary terms stay private until human approval.
    $published=hbdp_glossary_public_terms();
    $migrated=current_user_can('edit_posts') ? get_posts(array('post_type'=>'hbdp_glossar_term','post_status'=>array('draft','pending'),
        'numberposts'=>-1,'orderby'=>'title','order'=>'ASC')) : array();
    foreach(array_merge($published,is_array($migrated)?$migrated:array()) as $post) {
        if($post->post_status!=='publish' && !current_user_can('edit_post',$post->ID))continue;
        $short=(string)get_post_meta($post->ID,'_hbdp_short',true);
        if(!$short)continue;
        $n=hbdp_glossary_normalized_name($post->post_title);
        if(isset($native[$n]))continue;
        $native[$n]=true;
        $published_post=$post->post_status==='publish';
        $entries[]=array('begriff'=>$post->post_title,'kurzdefinition'=>$short,
            'themenwelt'=>(string)get_post_meta($post->ID,'_hbdp_world',true),
            'synonyme'=>(array)get_post_meta($post->ID,'_hbdp_synonyms',true),
            'url'=>$published_post?get_permalink($post->ID):'',
            'slug'=>$post->post_name,'reviewed'=>$published_post);
    }
    // Seed-only entries are editorial previews, never public articles.
    foreach(current_user_can('edit_posts') ? hbdp_glossary_quickreference() : array() as $term){
        if(!is_array($term)||empty($term['begriff'])||empty($term['kurzdefinition'])||isset($native[hbdp_glossary_normalized_name($term['begriff'])]))continue;
        $entries[]=array('begriff'=>$term['begriff'],'kurzdefinition'=>$term['kurzdefinition'],
            'themenwelt'=>$term['themenwelt']??'','synonyme'=>array(),
            'url'=>'','slug'=>$term['slug']??'','reviewed'=>false);
    }
    usort($entries,static function($a,$b){return strnatcasecmp((string)$a['begriff'],(string)$b['begriff']);});
    return $entries;
}
/** Small inline SVG icons for the six real protection worlds; no external libraries. */
function hbdp_glossary_world_icon($world) {
    $paths=array(
        'einbruch'=>'<path d="M3 10.3 12 3l9 7.3V21h-6v-7H9v7H3z"/>',
        'vandalismus'=>'<path d="M4 20 19 5l2 2L6 22H3z"/><path d="m14 5 5 5M4 15l5 5"/>',
        'wasser'=>'<path d="M12 2C8 8 6 10 6 14a6 6 0 0 0 12 0c0-4-2-6-6-12z"/><path d="M9 16a3 3 0 0 0 3 3"/>',
        'feuer'=>'<path d="M12 22c-4 0-7-3-7-7 0-4 3-6 3-9 3 2 4 4 4 6 2-2 3-5 2-10 5 4 7 9 7 13a9 9 0 0 1-9 7z"/><path d="M12 22c-2 0-3-2-3-4 0-1 2-3 3-5 1 2 3 4 3 5 0 2-1 4-3 4z"/>',
        'wetter'=>'<path d="M4 17a4 4 0 0 1 1-8 7 7 0 0 1 13 1 4 4 0 0 1 1 7"/><path d="m12 13-3 5h4l-1 4 5-7h-4l1-2"/>',
        'technik'=>'<circle cx="12" cy="12" r="3"/><path d="M10 2h4l.7 3 2 1 3-1.3 2 3.4-2.3 2 .1 2 2.3 2-2 3.4-3-1.3-2 1-.7 3h-4l-.7-3-2-1-3 1.3-2-3.4 2.3-2-.1-2-2.3-2 2-3.4 3 1.3 2-1z"/>',
        'versicherung'=>'<path d="M12 2 21 6v6c0 5-3.6 8.2-9 10-5.4-1.8-9-5-9-10V6z"/><path d="m8.4 12 2.4 2.4 4.8-4.9"/>',
    );
    $path=$paths[$world]??$paths['technik'];
    return '<svg class="hbdp-glossary-world-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round">'.$path.'</svg>';
}
/** A-Z: server-side search, world, letter and pagination. No 42-card page load. */
function hbdp_glossary_query() { return hbdp_glossary_query_from($_GET); }
function hbdp_glossary_link($options=array()) {
    $defaults=array('q'=>'','world'=>'all','letter'=>'','page'=>1);
    $q=array_merge($defaults,$options);$args=array();
    if($q['q']!=='')$args['glossar_suche']=$q['q'];
    if($q['world']!=='all')$args['glossar_welt']=$q['world'];
    if($q['letter']!=='')$args['glossar_buchstabe']=$q['letter'];
    if($q['page']>1)$args['glossar_seite']=$q['page'];
    return $args?add_query_arg($args,hbdp_glossary_url()):hbdp_glossary_url();
}
function hbdp_glossary_matches_search($item,$needle) {
    if($needle==='')return true;
    $hay=(string)$item['begriff'].' '.(string)$item['kurzdefinition'].' '.implode(' ',(array)($item['synonyme']??array()));
    if(function_exists('remove_accents')){$hay=remove_accents($hay);$needle=remove_accents($needle);}
    return stripos($hay,$needle)!==false;
}
/** The same 16-card, filtered index is used for normal page requests and AJAX. */
function hbdp_glossary_pager($page,$pages,$query) {
    $page=max(1,min((int)$pages,(int)$page));
    echo '<nav class="hbdp-glossary-pagination" aria-label="Glossarseiten">';
    if ($pages<2) {
        echo '<span class="hbdp-glossary-page-current" aria-current="page">Seite 1 von 1</span>';
    } else {
        if ($page>1) echo '<a rel="prev" href="'.esc_url(hbdp_glossary_link(array_merge($query,array('page'=>$page-1)))).'">← Zurück</a>';
        // Always provide direct access to first and last page, even when the middle window shifts.
        $numbers=array(1,(int)$pages);
        for ($i=max(1,$page-2);$i<=min($pages,$page+2);$i++) $numbers[]=$i;
        $numbers=array_values(array_unique($numbers));
        sort($numbers,SORT_NUMERIC);
        $previous=0;
        foreach ($numbers as $i) {
            if ($previous && $i-$previous>1) {
                if ($i-$previous===2) {
                    $middle=$previous+1;
                    echo '<a href="'.esc_url(hbdp_glossary_link(array_merge($query,array('page'=>$middle)))).'" aria-label="Glossarseite '.(int)$middle.'">'.(int)$middle.'</a>';
                } else {
                    echo '<span class="hbdp-glossary-page-gap" aria-label="Weitere Seiten ausgelassen">…</span>';
                }
            }
            if ($i===$page) echo '<span class="is-current" aria-current="page">'.(int)$i.'</span>';
            else echo '<a href="'.esc_url(hbdp_glossary_link(array_merge($query,array('page'=>$i)))).'" aria-label="Glossarseite '.(int)$i.'">'.(int)$i.'</a>';
            $previous=$i;
        }
        if ($page<$pages) echo '<a rel="next" href="'.esc_url(hbdp_glossary_link(array_merge($query,array('page'=>$page+1)))).'">Weiter →</a>';
    }
    echo '</nav>';
}
function hbdp_glossary_query_from($input) {
    $q=isset($input['glossar_suche'])?sanitize_text_field(wp_unslash($input['glossar_suche'])):'';
    $q=substr(trim((string)$q),0,90);
    $world=isset($input['glossar_welt'])?sanitize_key(wp_unslash($input['glossar_welt'])):'all';
    if ($world!=='all'&&!isset(hbdp_glossary_worlds()[$world]))$world='all';
    $letter=isset($input['glossar_buchstabe'])?strtoupper(sanitize_text_field(wp_unslash($input['glossar_buchstabe']))):'';
    if (!preg_match('/^[A-Z]$/D',$letter))$letter='';
    $page=isset($input['glossar_seite'])?max(1,min(9999,(int)$input['glossar_seite'])):1;
    return array('q'=>$q,'world'=>$world,'letter'=>$letter,'page'=>$page);
}
function hbdp_glossary_render_results($query) {
    $worlds=hbdp_glossary_worlds();$entries=hbdp_glossary_public_index();
    $letters=array();$filtered=array();
    foreach ($entries as $item) {
        if ($query['world']!=='all' && ($item['themenwelt']??'')!==$query['world']) continue;
        if (!hbdp_glossary_matches_search($item,$query['q']))continue;
        $letters[hbdp_glossary_letter($item['begriff'])]=true;
        if ($query['letter']!=='' && hbdp_glossary_letter($item['begriff'])!==$query['letter'])continue;
        $filtered[]=$item;
    }
    $count=count($filtered);$per_page=16;
    $pages=max(1,(int)ceil($count/$per_page));$page=min($pages,$query['page']);
    $shown=array_slice($filtered,($page-1)*$per_page,$per_page);
    echo '<nav class="hbdp-glossary-az" aria-label="Glossar A bis Z">';
    // No redundant 'Alle' filter: the Glossar-Startseite link resets every filter.
    foreach (range('A','Z') as $letter) {
        if (isset($letters[$letter])) echo '<a class="'.($query['letter']===$letter?'is-active':'').'" href="'.esc_url(hbdp_glossary_link(array_merge($query,array('letter'=>$letter,'page'=>1)))).'"'.($query['letter']===$letter?' aria-current="page"':'').'>'.esc_html($letter).'</a>';
        else echo '<span aria-hidden="true">'.esc_html($letter).'</span>';
    }
    echo '</nav><nav class="hbdp-glossary-filters" aria-label="Nach Schutzwelt filtern">';
    foreach ($worlds as $key=>$label) {
        $selected=$query['world']===$key;
        echo '<a class="hbdp-glossary-filter'.($selected?' is-active':'').'" href="'.esc_url(hbdp_glossary_link(array('q'=>$query['q'],'world'=>$key,'letter'=>'','page'=>1))).'"'.($selected?' aria-current="page"':'').'>'.($key!=='all'?hbdp_glossary_world_icon($key):'').'<span>'.esc_html($label).'</span></a>';
    }
    $heading='Alle Glossarbegriffe';
    if($query['q']!=='')$heading='Suchergebnisse';
    elseif($query['letter']!=='')$heading='Begriffe mit '.$query['letter'];
    elseif($query['world']!=='all')$heading='Begriffe: '.($worlds[$query['world']]??'Glossar');
    echo '</nav><div class="hbdp-glossary-results-heading"><h2>'.esc_html($heading).'</h2><a href="'.esc_url(hbdp_glossary_url()).'">Glossar-Startseite</a></div>';
    hbdp_glossary_pager($page,$pages,$query);
    if (!$count) {
        echo '<p class="hbdp-glossary-nohits">Keine passenden Fachbegriffe gefunden. <a href="'.esc_url(hbdp_glossary_url()).'">Alle Begriffe anzeigen</a></p>';
    } else {
        echo '<div class="hbdp-glossary-groups"><div class="hbdp-glossary-cards">';
        foreach ($shown as $item) {
            $name=(string)$item['begriff'];$world=(string)($item['themenwelt']??'');$url=(string)($item['url']??'');
            if ($url==='') $url=hbdp_glossary_preview_url((string)($item['slug']??''));
            echo '<article class="hbdp-glossary-entry"><a class="hbdp-glossary-card-link" href="'.esc_url($url).'">';
            echo '<div class="hbdp-glossary-card-head"><span class="hbdp-glossary-card-icon">'.hbdp_glossary_world_icon($world).'</span><div class="hbdp-glossary-card-title"><h3>'.esc_html($name).'</h3><span>'.esc_html($worlds[$world]??'Sicherheitswissen').'</span></div></div>';
            echo '<p class="hbdp-glossary-card-preview">'.esc_html((string)$item['kurzdefinition']).'</p><span class="hbdp-glossary-card-open">Zum Begriff →</span></a></article>';
        }
        echo '</div></div>';
    }
    hbdp_glossary_pager($page,$pages,$query);
    echo '<div class="hbdp-glossary-bottom-reset"><a href="'.esc_url(hbdp_glossary_url()).'">Zur Glossar-Startseite</a></div>';
}
function hbdp_render_glossary() {
    $query=hbdp_glossary_query_from($_GET);
    echo '<main class="hbdp-frame hbdp-section hbdp-glossary hbdp-glossary-index" id="inhalt">';hbdp_glossary_breadcrumb();
    echo '<section class="hdg-hero"><img src="'.esc_url(HBDP_URL.'assets/hero-einbruch-diebstahl.webp').'" alt="Gesichertes Wohnhaus am Abend" width="1916" height="821" decoding="async" fetchpriority="high"><div class="hdg-hero-copy"><div class="hdg-eyebrow">Wissen &amp; Nachschlagen</div><h1>Sicherheitsglossar A–Z</h1><p>Fachbegriffe rund um den Schutz von Eigentum</p></div></section>';
    echo '<section class="hdg-search-panel hbdp-glossary-search-panel"><form class="hbdp-glossary-searchbox" role="search" method="get" action="'.esc_url(hbdp_glossary_url()).'" data-hbdp-ajax="'.esc_url(admin_url('admin-ajax.php')).'">';
    echo '<div class="hbdp-glossary-search-row"><input id="hbdp-glossary-search" name="glossar_suche" value="'.esc_attr($query['q']).'" type="search" placeholder="Glossar durchsuchen, z. B. RC2, Rückstauklappe …" aria-label="Fachbegriffe im Glossar suchen" autocomplete="off"><button type="submit" aria-label="Glossar durchsuchen">Suchen</button></div>';
    echo '<div class="hbdp-glossary-suggestions" id="hbdp-glossary-suggestions" hidden aria-label="Passende Glossarbegriffe"></div></form></section><div id="hbdp-glossary-live" aria-live="polite" aria-busy="false">';
    hbdp_glossary_render_results($query);
    echo '</div></main>';
}
/** Public read-only endpoint, strictly limited to this glossary, not the WordPress global search. */
function hbdp_glossary_ajax_search() {
    if (($_SERVER['REQUEST_METHOD']??'GET')!=='POST') {status_header(405);wp_send_json_error(array('message'=>'Methode nicht erlaubt'),405);}
    $query=hbdp_glossary_query_from($_POST);
    if(($_POST['mode']??'')==='suggest') {
        $term=trim($query['q']);
        $n=function_exists('mb_strlen')?mb_strlen($term,'UTF-8'):(preg_match_all('/./u',$term,$m)?:0);
        $suggestions=array();
        if($n>=2) {
            foreach(hbdp_glossary_public_index() as $item) {
                // Exact glossary scope. Never search normal WordPress posts/pages.
                $haystack=hbdp_glossary_normalized_name($item['begriff']);
                $needle=hbdp_glossary_normalized_name($term);
                if(strpos($haystack,$needle)===false)continue;
                $url=(string)($item['url']??'');
                if($url==='')$url=hbdp_glossary_preview_url((string)($item['slug']??''));
                $suggestions[]=array('title'=>(string)$item['begriff'],'url'=>$url);
                if(count($suggestions)>=8)break;
            }
        }
        wp_send_json_success(array('suggestions'=>$suggestions));
        return;
    }
    ob_start();hbdp_glossary_render_results($query);$html=ob_get_clean();
    wp_send_json_success(array('html'=>$html));
}
add_action('wp_ajax_hbdp_glossary_search','hbdp_glossary_ajax_search');
add_action('wp_ajax_nopriv_hbdp_glossary_search','hbdp_glossary_ajax_search');
/** Hobby Depot Glossar Core 1.0.13 detail structure – only protection-specific labels and color profile differ. */
function hbdp_glossary_hobby_icon($name) {
    $icons=array(
      'book'=>'<path d="M4 5.5c2.7-.8 5-.2 8 1.5 3-1.7 5.3-2.3 8-1.5v13c-2.7-.8-5-.2-8 1.5-3-1.7-5.3-2.3-8-1.5Z"/><path d="M12 7v13"/>',
      'folder'=>'<path d="M3 6h7l2 2h9v11H3Z"/>',
      'link'=>'<path d="M9.5 14.5 8 16a4 4 0 0 1-5.7-5.7l3-3A4 4 0 0 1 11 7"/><path d="m14.5 9.5 1.5-1.5a4 4 0 0 1 5.7 5.7l-3 3A4 4 0 0 1 13 17"/><path d="m8.5 15.5 7-7"/>',
    );
    return '<svg viewBox="0 0 24 24" aria-hidden="true">'.($icons[$name]??$icons['book']).'</svg>';
}
function hbdp_glossary_hobby_card($heading,$icon,$body){
    if($body==='')return '';
    return '<section class="hdg-aside-card"><h2>'.hbdp_glossary_hobby_icon($icon).esc_html($heading).'</h2>'.$body.'</section>';
}
function hbdp_glossary_related_links($labels,$name) {
    if(!is_array($labels) || !$labels)return '';
    $known=array();foreach(hbdp_glossary_public_index() as $item){
        $url=($item['url']??'')?:hbdp_glossary_preview_url($item['slug']??'');
        if($url)$known[hbdp_glossary_normalized_name($item['begriff'])]=$url;
    }
    $links='';$seen=array();foreach($labels as $label){
        if(!is_string($label)||trim($label)==='')continue;
        $key=hbdp_glossary_normalized_name($label);
        if(isset($seen[$key])||$key===hbdp_glossary_normalized_name($name)||empty($known[$key]))continue;
        $seen[$key]=true;$links.='<a href="'.esc_url($known[$key]).'">'.esc_html($label).'</a>';
    }
    return $links;
}
function hbdp_glossary_sidebar($world,$related,$name,$primary_target=array()) {
    $worlds=hbdp_glossary_worlds();
    $node_ids=array('einbruch'=>'core:world:einbruch-und-diebstahl','vandalismus'=>'core:world:vandalismus-und-zerstorung','wasser'=>'core:world:wasser-und-feuchtigkeit','feuer'=>'core:world:feuer-und-gase','wetter'=>'core:world:wetter-und-naturgefahren','technik'=>'core:world:technik-und-ausfalle','versicherung'=>'core:world:insurance');
    echo '<aside class="hdg-term-aside" aria-label="Weiterführende Informationen">';
    // The glossarial world always links to this world's filtered glossary, not to a general category.
    if(isset($worlds[$world])){
        $filter_url=hbdp_glossary_link(array('world'=>$world));
        echo hbdp_glossary_hobby_card('Glossarwelt','book','<a href="'.esc_url($filter_url).'">'.esc_html($worlds[$world]).' – Begriffe ansehen</a>');
    }
    $node=hbdp_node($node_ids[$world]??'');
    if($node){$u=hbdp_nav_url($node);if($u)echo hbdp_glossary_hobby_card('Schutzwelt','folder','<a href="'.esc_url($u).'">'.esc_html($worlds[$world]??$world).'</a>');}
    // Reserve the ad location also before booking; honor the established markup filter.
    // An empty slot is explicitly labelled as available space, never a fabricated advert.
    $ad=apply_filters('hbdp_glossary_ad_markup','');
    $booked=is_string($ad)&&trim($ad)!=='';
    echo '<section class="hdg-ad hdg-aside-ad'.($booked?' has-content':' is-available').'" aria-label="Anzeigenbereich"><span class="hdg-ad-label">Anzeige</span><div class="hdg-ad-box">'.($booked?wp_kses_post($ad):'<span class="hdg-ad-placeholder">Anzeigenplatz</span>').'</div></section>';
    $links=hbdp_glossary_related_links($related,$name);
    if($links!=='')echo hbdp_glossary_hobby_card('Verwandte Begriffe','link',$links);
    $u='';$label='';
    if(is_array($primary_target)&&!empty($primary_target['wp_id'])){
        $id=(int)$primary_target['wp_id'];
        if(($primary_target['type']??'')==='page'){$post=get_post($id);if($post&&$post->post_status==='publish'){$u=get_permalink($id);$label=get_the_title($id);}}
        elseif(($primary_target['type']??'')==='category'){$term=get_term($id,'category');if($term&&!is_wp_error($term)){$link=get_term_link($term);if(!is_wp_error($link)){$u=$link;$label=$term->name;}}}
    }
    if($u)echo hbdp_glossary_hobby_card('Mehr zum Thema','folder','<a href="'.esc_url($u).'">'.esc_html($label).'</a>');
    echo '</aside>';
}
function hbdp_glossary_detail_navigation($name) {
    $entries=hbdp_glossary_public_index();$index=-1;
    foreach($entries as $k=>$item)if(hbdp_glossary_normalized_name($item['begriff'])===hbdp_glossary_normalized_name($name)){$index=$k;break;}
    echo '<section class="hdg-more-glossary"><div class="hdg-more-head"><strong>Weiterwissen im Glossar</strong><a class="hdg-more-home" href="'.esc_url(hbdp_glossary_url()).'">Zur Glossar-Startseite →</a></div><nav class="hdg-term-nav" aria-label="Weitere Glossarbegriffe"><div>';
    if($index>0){$prev=$entries[$index-1];echo '<a class="prev" rel="prev" href="'.esc_url(($prev['url']??'')?:hbdp_glossary_preview_url($prev['slug']??'')).'"><small>← Vorheriger Begriff</small><strong>'.esc_html($prev['begriff']).'</strong></a>';}
    echo '</div><div>';
    if($index>=0 && $index<count($entries)-1){$next=$entries[$index+1];echo '<a class="next" rel="next" href="'.esc_url(($next['url']??'')?:hbdp_glossary_preview_url($next['slug']??'')).'"><small>Nächster Begriff →</small><strong>'.esc_html($next['begriff']).'</strong></a>';}
    echo '</div></nav></section>';
}
function hbdp_glossary_detail_intro($name,$description){
    echo '<header class="hdg-single-head"><div class="hdg-eyebrow">Wissen</div><h1>'.esc_html($name).'</h1><div class="hdg-single-rule"></div></header><div class="hdg-term-grid"><div>';
    echo '<section class="hdg-definition-box"><div class="hdg-definition-icon">'.hbdp_glossary_hobby_icon('book').'</div><div><span class="hdg-definition-label">Kurz erklärt</span><p>'.esc_html($description).'</p></div></section>';
}
/** Draft glossary references remain 100% non-indexable. They do not masquerade as approved articles. */
function hbdp_render_glossary_preview(){
    $term=hbdp_glossary_preview_record();if(!$term)return;
    $name=(string)$term['begriff'];$world=(string)($term['themenwelt']??'');
    echo '<main class="hbdp-frame hbdp-section hbdp-glossary hbdp-glossary-preview" id="inhalt">';hbdp_glossary_breadcrumb($name);echo '<section class="hdg-single"><article>';
    hbdp_glossary_detail_intro($name,(string)$term['kurzdefinition']);
    if(!empty($term['fachtext']) && is_array($term['fachtext'])) {echo '<div class="hdg-term-text">';foreach($term['fachtext'] as $paragraph)if(is_string($paragraph)&&trim($paragraph)!=='')echo '<p>'.esc_html($paragraph).'</p>';echo '</div>';}
    echo '</div>';
    hbdp_glossary_sidebar($world,$term['verwandte_begriffe']??array(),$name);
    echo '</div>';hbdp_glossary_detail_navigation($name);echo '</article></section></main>';
}
function hbdp_render_glossary_term(){
    $post=get_queried_object();if(!$post||$post->post_type!=='hbdp_glossar_term')return;
    $name=(string)$post->post_title;$id=$post->ID;
    echo '<main class="hbdp-frame hbdp-section hbdp-glossary hbdp-glossary-term" id="inhalt">';hbdp_glossary_breadcrumb($name);echo '<section class="hdg-single"><article>';
    hbdp_glossary_detail_intro($name,(string)get_post_meta($id,'_hbdp_short',true));
    $copy=hbdp_glossary_body_plain($post->post_content);
    if($copy!=='')echo '<div class="hdg-term-text">'.wpautop(esc_html($copy)).'</div>';
    $scope=trim((string)get_post_meta($id,'_hbdp_scope',true));if($scope!=='')echo '<div class="hdg-term-text"><p>'.esc_html($scope).'</p></div>';
    echo '</div>';
    hbdp_glossary_sidebar((string)get_post_meta($id,'_hbdp_world',true),(array)get_post_meta($id,'_hbdp_related',true),$name,(array)get_post_meta($id,'_hbdp_primary_target',true));
    echo '</div>';hbdp_glossary_detail_navigation($name);echo '</article></section></main>';
}
// No thin/empty A–Z page should enter search indexes before the first approved term.
add_filter('wp_robots',static function($robots){
    if(hbdp_is_glossary_preview_path() || (function_exists('hbdp_for_query') && hbdp_for_query()==='glossary' && count(hbdp_glossary_public_terms())===0)){$robots['noindex']=true;$robots['follow']=true;}
    return $robots;
});
// Native metadata fallback for standalone glossary terms; avoid competing with active SEO plugins.
add_action('wp_head',static function(){
    if(!is_singular('hbdp_glossar_term')||defined('WPSEO_VERSION')||defined('RANK_MATH_VERSION'))return;
    $id=get_queried_object_id();$desc=(string)get_post_meta($id,'_hbdp_seo_description',true);
    if($desc!=='')echo '<meta name="description" content="'.esc_attr($desc).'">' . "\n";
},5);
add_shortcode('hab_bewahr_glossar',static function(){ob_start();hbdp_render_glossary();return ob_get_clean();});
