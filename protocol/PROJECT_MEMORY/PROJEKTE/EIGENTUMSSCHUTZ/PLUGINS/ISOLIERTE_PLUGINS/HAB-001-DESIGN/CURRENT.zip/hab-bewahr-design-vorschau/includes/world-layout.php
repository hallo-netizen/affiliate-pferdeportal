<?php
/** Six centrally controlled world pages only. Read-only category/navigation. */
if(!defined('ABSPATH'))exit;
/** A single reviewed image ID is shared by category tile and target hero.
 *  Read one immutable JSON file, no HTTP, no database queries, no fallbacks. */
function hbdp_insurance_photo_profile(){
    static $data=null;
    if($data!==null)return $data;
    $file=HBDP_ROOT.'data/insurance-photo-mapping-v1.json';
    $tmp=is_readable($file)?json_decode((string)file_get_contents($file),true):array();
    $data=(is_array($tmp)&&($tmp['schema']??'')==='HBDP_INSURANCE_46_R3_PHOTO_BINDING_V1')?$tmp:array();
    return $data;
}
function hbdp_insurance_photo_file($record){
    $photo=(string)($record['file']??'');
    return preg_match('/^insurance-[a-z0-9-]+\.webp$/D',$photo) && is_file(HBDP_ROOT.'assets/'.$photo)?$photo:'';
}
function hbdp_is_insurance_r3($node){
    if(!is_array($node)||($node['type']??'')!=='page')return false;
    $p=hbdp_node((string)($node['parent']??''));
    if(!$p || ($p['type']??'')!=='page')return false;
    return (string)($p['parent']??'')==='core:world:insurance';
}
function hbdp_insurance_topic_photo($node){
    if(!hbdp_is_insurance_r3($node))return '';
    $map=hbdp_insurance_photo_profile()['photos']??array();
    return hbdp_insurance_photo_file($map[(string)$node['name']]??array());
}
function hbdp_insurance_area_photo($area){
    if(!is_array($area) || (string)($area['parent']??'')!=='core:world:insurance')return '';
    $map=hbdp_insurance_photo_profile()['areas']??array();
    return hbdp_insurance_photo_file($map[(string)($area['name']??'')]??array());
}
function hbdp_world_hero_file($id){
    $files=array(
      'core:world:einbruch-und-diebstahl'=>'hero-einbruch-diebstahl.webp',
      'core:world:vandalismus-und-zerstorung'=>'hero-vandalismus-zerstoerung.webp',
      'core:world:wasser-und-feuchtigkeit'=>'hero-wasser-feuchtigkeit.webp',
      'core:world:feuer-und-gase'=>'hero-feuer-gase.webp',
      'core:world:wetter-und-naturgefahren'=>'hero-wetter-naturgefahren.webp',
      'core:world:technik-und-ausfalle'=>'hero-technik-ausfaelle.webp',
      'core:world:insurance'=>hbdp_insurance_photo_file(hbdp_insurance_photo_profile()['world']??array())
    );
    return $files[$id]??'';
}
/** Short, legible hero captions only. Long editorial text remains unchanged below. */
function hbdp_world_short_caption($id) {
    $captions=array(
      'core:world:einbruch-und-diebstahl'=>'Schütze dein Zuhause und deine Wertsachen vor Diebstahl.',
      'core:world:vandalismus-und-zerstorung'=>'Schütze dein Eigentum vor mutwilligen Schäden.',
      'core:world:wasser-und-feuchtigkeit'=>'Beuge Wasserschäden vor und erkenne Lecks früh.',
      'core:world:feuer-und-gase'=>'Erkenne Brand- und Gasgefahren rechtzeitig.',
      'core:world:wetter-und-naturgefahren'=>'Bereite dein Eigentum auf Unwetter vor.',
      'core:world:technik-und-ausfalle'=>'Erkenne Ausfälle, bevor Schäden entstehen.'
    );
    return $captions[$id]??hbdp_world_explanation($id);
}
/** Sponsored spaces are independent: paid partner fields versus auto-banner provider. */
function hbdp_world_sponsor_options(){
    $data=get_option('hbdp_world_sponsors_v1',array());
    return is_array($data)?$data:array();
}
function hbdp_world_sponsor_for($id){
    $opts=hbdp_world_sponsor_options();$ad=$opts[$id]??array();
    if(!is_array($ad))return array();
    $title=trim((string)($ad['title']??''));$href=trim((string)($ad['url']??''));
    if($title===''||$href===''||!wp_http_validate_url($href))return array();
    return array('title'=>$title,'url'=>$href,'description'=>(string)($ad['description']??''),'image'=>(string)($ad['image']??''));
}
function hbdp_world_auto_banner($id){
    // Integration point for future automatic affiliate-banner assignment; no HTTP/DB work.
    // A provider must return complete, validated banner markup or an empty string.
    $html=apply_filters('hbdp_world_auto_banner_html','',$id);
    return is_string($html)?trim(wp_kses_post($html)):'';
}
function hbdp_world_admin_slot($kind){
    if(!current_user_can('manage_options'))return;
    echo '<div class="hbdp-w-ad-empty" role="note"><small>Nur für Administratoren · Nicht veröffentlicht</small><strong>'.esc_html($kind).'</strong><span>Noch nicht befüllt. Besucher sehen hier nichts.</span></div>';
}
function hbdp_world_banner_render($html,$tile){
    if($html==='')return;
    echo '<section class="'.($tile?'hbdp-world-ad-tile':'hbdp-world-banner'). '" aria-label="Werbung"><small>Anzeige</small><div class="hbdp-world-ad-media">'.$html.'</div></section>';
}
function hbdp_world_sponsor_render($id){
    $ad=hbdp_world_sponsor_for($id);
    if(!$ad){hbdp_world_admin_slot('Verkaufbare Partnerfläche');return;}
    echo '<section class="hbdp-world-sponsor" aria-label="Bezahlte Werbung"><div class="hbdp-world-sponsor-copy"><small>Anzeige · Werbepartner</small><h2>'.esc_html($ad['title']).'</h2>';
    if($ad['description']!=='')echo '<p>'.esc_html($ad['description']).'</p>';
    echo '<a href="'.esc_url($ad['url']).'" target="_blank" rel="sponsored noopener noreferrer">Angebot ansehen <span aria-hidden="true">→</span></a></div>';
    if($ad['image']!==''&&wp_http_validate_url($ad['image']))echo '<img loading="lazy" decoding="async" alt="" src="'.esc_url($ad['image']).'">';
    echo '</section>';
}
/** One capped WP post query; parent linkage comes only from the central active snapshot. */
function hbdp_world_article_terms($world_id){
    $all=hbdp_all_nodes();$terms=array();
    foreach($all as $node){
        if(($node['type']??'')!=='category'||(int)($node['wp_id']??0)<1)continue;
        $parent=(string)($node['parent']??'');$seen=array();
        for($depth=0;$parent!==''&&$depth<7&&!isset($seen[$parent]);$depth++){
            if($parent===$world_id){$terms[(int)$node['wp_id']]=true;break;}
            $seen[$parent]=true;$parent=(string)($all[$parent]['parent']??'');
        }
    }
    return array_keys($terms);
}
function hbdp_world_article_cards($world_id){
    $terms=hbdp_world_article_terms($world_id);if(!$terms)return 0;
    $posts=get_posts(array('post_type'=>'post','post_status'=>'publish','category__in'=>$terms,
        'posts_per_page'=>10,'orderby'=>'date','order'=>'DESC','ignore_sticky_posts'=>true,
        'no_found_rows'=>true,'suppress_filters'=>true));
    $shown=0;
    foreach($posts as $post){
        if(get_post_meta($post->ID,'_hbdp_demo',true)==='1')continue;
        $link=get_permalink($post->ID);if(!$link)continue;
        $title=get_the_title($post);if(trim($title)==='')continue;
        echo '<article class="hbdp-world-article"><a href="'.esc_url($link).'">';
        if(has_post_thumbnail($post->ID))echo get_the_post_thumbnail($post->ID,'medium_large',array('loading'=>'lazy','decoding'=>'async','alt'=>esc_attr($title)));
        else echo '<span class="hbdp-world-article-fallback" aria-hidden="true"></span>';
        echo '<span class="hbdp-world-article-body"><small>Ratgeber</small><strong>'.esc_html($title).'</strong></span></a></article>';
        if(++$shown>=4)break;
    }
    return $shown;
}
function hbdp_world_hero_tone($id){
    return 'light'; // All seven worlds use the proven bright hero gradient and dark-readable text.
}
/** Photos for subcategory tiles are chosen by topic, not a repeated default house photo. */
function hbdp_world_area_photo($world,$area,$index){
    if($world==='core:world:insurance')return hbdp_insurance_area_photo($area);
    // One precise photo per real section; no keyword-pool fallback.
    // Child category hero always uses the SAME photo as this linking card.
    static $photos = array(
  'core:world:einbruch-und-diebstahl'=>array(
    'Haus & Wohnung'=>'start-hero.webp',
    'Freizeit & Fahrzeuge'=>'fix-einbruch-freizeit-fahrzeuge.webp',
    'Garagen & Nebenräume'=>'fix-einbruch-garagen-nebenraeume.webp',
    'Garten & Grundstück'=>'fix-einbruch-garten-grundstueck.webp',
    'Abwesenheit & Leerstand'=>'fix-einbruch-abwesenheit-leerstand.webp',
    'Kleine Betriebe & Vereine'=>'scene-shop.webp',
  ),
  'core:world:vandalismus-und-zerstorung'=>array(
    'Gebäude & Ausstattung'=>'curated-20261019-16.webp',
    'Fassade & Außenflächen'=>'fix-130-vandal-fassade.webp',
    'Außentechnik'=>'hero-technik-ausfaelle.webp',
    'Vereine & Kleingewerbe'=>'fix-130-vandal-vereine.webp',
    'Freizeit & Vandalismus'=>'focus-vandalismus-freizeit.webp',
  ),
  'core:world:wasser-und-feuchtigkeit'=>array(
    'Leckage & Rohrbruch'=>'curated-20261019-13.webp',
    'Keller & Rückstau'=>'focus-keller-rueckstau.webp',
    'Camping & Freizeitobjekte'=>'focus-camping-regen.webp',
    'Frost & Abwesenheit'=>'focus-frost-schnee.webp',
    'Kleine Betriebe & Vereine'=>'hbfix-22.webp',
    'Dach & Gebäudehülle gegen Feuchtigkeit'=>'fix-einbruch-abwesenheit-leerstand.webp',
  ),
  'core:world:feuer-und-gase'=>array(
    'Rauch & Brand'=>'area-brandschutz-loeschmittel.webp',
    'CO & Gas'=>'focus-gas-heizung.webp',
    'Akku & Elektrik'=>'focus-feuer-elektrik.webp',
    'Camping'=>'fix-feuer-camping.webp',
    'Kleine Betriebe & Vereine'=>'new-workshop.webp',
  ),
  'core:world:wetter-und-naturgefahren'=>array(
    'Sturm & Hagel'=>'focus-wetter-sturm.webp',
    'Starkregen & Hochwasser'=>'hero-wasser-feuchtigkeit.webp',
    'Frost & Schnee'=>'focus-frost-schnee.webp',
    'Blitz & Überspannung'=>'scene-weather.webp',
    'Freizeit & Unwetter'=>'focus-camping-regen.webp',
    'Hitze & Trockenheit'=>'scene-heat.webp',
    'Tier- & Schädlingsschäden'=>'scene-damage.webp',
  ),
  'core:world:technik-und-ausfalle'=>array(
    'Alarm & Smart Home'=>'focus-smart-home.webp',
    'Fernüberwachung'=>'magazin-einbruch.webp',
    'Heizung & Temperatur'=>'fix-technik-heizung-temperatur.webp',
    'Pumpen & Haustechnik'=>'curated-20261019-13.webp',
    'Strom & Notstrom'=>'fix-technik-strom-notstrom.webp',
    'PV, Speicher & private Ladeinfrastruktur'=>'curated-20261019-02.webp',
    'Tore & Zugangstechnik'=>'fix-131-technik-tore-zugang.webp',
  ),
);
    $name=(string)($area['name']??'');
    if(isset($photos[$world][$name]))return $photos[$world][$name];
    if(function_exists('hbdp_area_spec_for')){
        $spec=hbdp_area_spec_for($area);
        if(is_array($spec))return $photos[$world][(string)($spec['name']??'')]??'';
    }
    return '';
}

function hbdp_world_area_unique_photo($world,$area,$index,&$used){
    if($world==='core:world:insurance'){
        $photo=hbdp_insurance_area_photo($area);
        if($photo==='' || isset($used[$photo]))return '';
        $used[$photo]=true;return $photo;
    }
    $primary=hbdp_world_area_photo($world,$area,$index);
    $pools=array(
      'core:world:einbruch-und-diebstahl'=>array('hero-einbruch-diebstahl.webp','focus-ferienhaus.webp','focus-boot.webp','focus-garage.webp','focus-gartenhaus.webp','focus-kleinbetrieb.webp','focus-einfahrt-tor.webp','focus-smart-home.webp','focus-wertsachen.webp','focus-einfahrt-tor.webp','focus-garage.webp'),
      'core:world:vandalismus-und-zerstorung'=>array('hero-vandalismus-zerstoerung.webp','fix-130-vandal-building.webp','focus-vandalismus-fassade.webp','focus-vandalismus-freizeit.webp','focus-vandal-gewerbe.webp','focus-vandalismus-fassade.webp','focus-kleinbetrieb.webp','focus-einfahrt-tor.webp','focus-gartenhaus.webp','focus-garage.webp'),
      'core:world:wasser-und-feuchtigkeit'=>array('hero-wasser-feuchtigkeit.webp','focus-keller-rueckstau.webp','focus-camping-regen.webp','focus-frost-schnee.webp','focus-leckage-haustechnik.webp','focus-kleinbetrieb.webp','focus-gas-heizung.webp','focus-boot.webp','focus-garage.webp'),
      'core:world:feuer-und-gase'=>array('hero-feuer-gase.webp','focus-gas-heizung.webp','focus-notstrom.webp','focus-feuer-kleinbetrieb.webp','focus-feuer-elektrik.webp','focus-camping-regen.webp','focus-kleinbetrieb.webp','focus-garage.webp','focus-smart-home.webp'),
      'core:world:wetter-und-naturgefahren'=>array('hero-wetter-naturgefahren.webp','focus-frost-schnee.webp','focus-camping-regen.webp','hero-wasser-feuchtigkeit.webp','focus-wetter-sturm.webp','focus-wetter-sturm.webp','focus-ferienhaus.webp','focus-gartenhaus.webp','focus-boot.webp'),
      'core:world:technik-und-ausfalle'=>array('hero-technik-ausfaelle.webp','focus-smart-home.webp','focus-einfahrt-tor.webp','focus-waermepumpe.webp','focus-notstrom.webp','focus-gas-heizung.webp','focus-feuer-elektrik.webp','focus-gas-heizung.webp','focus-garage.webp')
    );
    $pool=$pools[$world]??array();
    $choices=array_merge(array($primary),$pool);
    // Same pixels under different filenames must count as ONE used photo.
    // Aliases are computed from the shipped image assets once at build time.
    // No hashing, HTTP or database access is done during frontend rendering.
    $aliases=array(
      'fix-vandalismus-vereine-kleingewerbe-129.webp'=>'hero-vandalismus-zerstoerung.webp',
      'fix-130-vandal-vereine.webp'=>'focus-vandalismus-fassade.webp',
      'focus-vandal-gewerbe.webp'=>'focus-vandalismus-fassade.webp',
      'fix-vandalismus-vereine-kleingewerbe.webp'=>'focus-vandalismus-fassade.webp',
      'fix-vandalismus-vereine-kleingewerbe-2.webp'=>'focus-vandalismus-fassade.webp',
      'fix-technik-tore-zugang.webp'=>'focus-einfahrt-tor.webp',
      'fix-130-technik-tore.webp'=>'hero-technik-ausfaelle.webp',
      'fix-technik-strom-notstrom.webp'=>'focus-notstrom.webp',
      'focus-feuer-elektrik.webp'=>'focus-notstrom.webp',
      'fix-technik-heizung-temperatur.webp'=>'focus-gas-heizung.webp',
      'focus-leckage-haustechnik.webp'=>'focus-gas-heizung.webp'
    );
    foreach($choices as $photo){
        $identity=function_exists('hbdp_area_photo_identity')?hbdp_area_photo_identity($photo):($aliases[$photo]??$photo);
        if(isset($used[$identity]))continue;
        if(!preg_match('/^[a-z0-9-]+\.webp$/',$photo))continue;
        if(!is_file(HBDP_ROOT.'assets/'.$photo))continue;
        $used[$identity]=true;
        return $photo;
    }
    // Missing photo? Fail closed to the canonical hero, never broken HTML src.
    return hbdp_world_hero_file($world);
}

function hbdp_world_magazine_photo($world){
    $files=array(
      'core:world:einbruch-und-diebstahl'=>'magazin-einbruch.webp',
      'core:world:wasser-und-feuchtigkeit'=>'magazin-wasser.webp',
      'core:world:wetter-und-naturgefahren'=>'magazin-wetter.webp',
      'core:world:technik-und-ausfalle'=>'magazin-einbruch.webp'
    );
    return $files[$world]??'';
}

function hbdp_render_world_page($node){
    $id=$node['id'];$hero=hbdp_world_hero_file($id);if($hero==='')return;
    $cards=array();
    foreach(hbdp_children($id) as $child){
        if(($child['id']??'')===$id)continue;
        if(hbdp_nav_url($child)!=='')$cards[]=$child;
    }
    $banner=hbdp_world_auto_banner($id);
    $can_tile=(count($cards)>0 && count($cards)%4!==0);
    $banner_span=$can_tile ? (4-(count($cards)%4)) : 1;
    echo '<main class="hbdp-world-page"><div class="hbdp-frame hbdp-world-breadcrumb-top">';
    hbdp_breadcrumb($node);
    echo '</div><div class="hbdp-frame hbdp-world-hero-frame"><header class="hbdp-world-hero hbdp-world-hero--'.esc_attr(hbdp_world_hero_tone($id)).'">';
    echo '<img class="hbdp-world-hero-image" alt="" src="'.esc_url(HBDP_URL.'assets/'.$hero).'" fetchpriority="high">';
    echo '<div class="hbdp-world-hero-shade" aria-hidden="true"></div><div class="hbdp-world-hero-inner">';
    echo '<span class="hbdp-world-eyebrow">Schutzbereich</span><h1>'.esc_html(hbdp_compass_display_name($node)).'</h1><p>'.esc_html(hbdp_world_short_caption($id)).'</p></div></header></div>';
    echo '<div class="hbdp-frame hbdp-world-page-body">';
    echo '<section class="hbdp-world-topics" aria-label="Unterkategorien"><div class="hbdp-world-section-head"><h2>Unsere Themen</h2><p>Finde den passenden Schutzbereich für dein Anliegen.</p></div><div class="hbdp-world-topic-grid">';
    // Single photo allocation for the whole world: avoid duplicates also when
    // the active C2.2 snapshot uses new area IDs or differently named children.
    $used_photos=array();$card_photos=array();
    foreach($cards as $index=>$card){
        $url=hbdp_nav_url($card);
        $photo=hbdp_world_area_unique_photo($id,$card,$index,$used_photos);
        $card_photos[$card['id']]=$photo;
        echo '<a class="hbdp-world-topic" href="'.esc_url($url).'" aria-label="'.esc_attr(hbdp_compass_display_name($card)).'"><img loading="lazy" decoding="async" src="'.esc_url(HBDP_URL.'assets/'.$photo).'" alt=""><span>'.esc_html(hbdp_compass_display_name($card)).'<b aria-hidden="true">→</b></span></a>';
    }
    if($can_tile && ($banner!=='' || current_user_can('manage_options'))){
        echo '<div class="hbdp-world-free-tile" style="--hbdp-span:'.(int)$banner_span.'">';
        if($banner!=='')hbdp_world_banner_render($banner,true);
        else hbdp_world_admin_slot('Automatischer Bannerplatz · freie Kachel');
        echo '</div>';
    }
    echo '</div></section>';
    // Paid ad appears EARLY between categories and editorial; separate from affiliate banner.
    hbdp_world_sponsor_render($id);
    $dest=hbdp_startseite_urls();$magazine=$dest['magazine']??'';
    ob_start();$shown=hbdp_world_article_cards($id);$article_markup=(string)ob_get_clean();
    // A useful reading section exists even before the first article is published.
    // Real WP posts take priority. Other cards point to genuine child archives.
    // Do not invent article titles, URLs or demo posts to fill the layout.
    $reading_present=$shown>0 || $magazine!=='' || count($cards)>0;
    if($reading_present || current_user_can('manage_options')){
        $has_posts=$shown>0;
        echo '<section class="hbdp-world-reading" aria-label="Ratgeber und weiterführende Themen"><div class="hbdp-world-reading-head"><h2>'.($has_posts?'Ratgeber &amp; Tipps':'Ratgeber &amp; Themen').'</h2><p>'.($has_posts?'Passende veröffentlichte Beiträge aus den zugehörigen Schutzbereichen.':'Entdecke praktische Schutzthemen. Hier erscheinen auch neue Ratgeber, sobald sie veröffentlicht sind.').'</p></div><div class="hbdp-world-article-grid">';
        echo $article_markup;
        if(!$has_posts){
            $count=0;
            foreach($cards as $card){
                if($count>=3)break;
                $url=hbdp_nav_url($card);if($url==='')continue;
                echo '<article class="hbdp-world-article hbdp-world-subject-card"><a href="'.esc_url($url).'">';
                echo '<span class="hbdp-world-article-body"><small>Schutzthema</small><strong>'.esc_html(hbdp_compass_display_name($card)).'</strong><span class="hbdp-world-article-link">Tipps &amp; Lösungen entdecken →</span></span></a></article>';
                $count++;
            }
        }
        if($magazine!==''){
            $mag_photo=hbdp_world_magazine_photo($id);
            echo '<article class="hbdp-world-article hbdp-world-jumpcard"><a href="'.esc_url($magazine).'">';
            if($mag_photo!=='' && is_file(HBDP_ROOT.'assets/'.$mag_photo) && !isset($used_photos[hbdp_area_photo_identity($mag_photo)]) && $mag_photo!==$hero) echo '<img class="hbdp-world-magazine-cover" src="'.esc_url(HBDP_URL.'assets/'.$mag_photo).'" alt="" loading="lazy" decoding="async">';
            else echo '<span class="hbdp-world-magazine-cover hbdp-world-magazine-plain" aria-hidden="true"><span>Wissen, das schützt</span></span>';
            echo '<span class="hbdp-world-article-body"><small>Magazin</small><strong>Weitere Ratgeber und Hintergründe</strong><span class="hbdp-world-article-link">Zum Magazin →</span></span></a></article>';
        }
        if(!$shown && !$cards && $magazine==='' && current_user_can('manage_options'))echo '<p class="hbdp-world-editor-note">Nur für Administratoren: Noch keine passenden Beiträge oder erreichbaren Themen verfügbar.</p>';
        echo '</div></section>';
    }
    if(!$can_tile){
        if($banner!=='')hbdp_world_banner_render($banner,false);
        else hbdp_world_admin_slot('Automatischer Bannerplatz');
    }
    hbdp_render_world_bottom_text($node);
    echo '</div></main>';


}
/** One small admin-only form; no new tables, routes or custom plugin. */
function hbdp_world_sponsor_admin_save(){
    if(!isset($_POST['hbdp_save_world_sponsor']))return;
    if(!current_user_can('manage_options')||!check_admin_referer('hbdp_world_sponsor_save'))wp_die('Keine Berechtigung');
    $worlds=array_keys(array_filter(hbdp_world_hero_file_map(),static function($a){return $a!=='';}));
    $input=isset($_POST['hbdp_sponsors'])&&is_array($_POST['hbdp_sponsors'])?wp_unslash($_POST['hbdp_sponsors']):array();
    $clean=array();
    foreach($worlds as $id){
       $v=$input[$id]??array();if(!is_array($v))continue;
       $title=sanitize_text_field($v['title']??'');$desc=sanitize_textarea_field($v['description']??'');
       $url=esc_url_raw($v['url']??'');$image=esc_url_raw($v['image']??'');
       if($title!==''&&$url!==''&&wp_http_validate_url($url))$clean[$id]=array('title'=>$title,'description'=>$desc,'url'=>$url,'image'=>($image!==''&&wp_http_validate_url($image))?$image:'');
    }
    update_option('hbdp_world_sponsors_v1',$clean,false);
    echo '<div class="notice notice-success"><p>Partnerflächen gespeichert.</p></div>';
}
function hbdp_world_hero_file_map(){
    return array('core:world:einbruch-und-diebstahl'=>'Einbruch & Diebstahl','core:world:vandalismus-und-zerstorung'=>'Vandalismus & Zerstörung','core:world:wasser-und-feuchtigkeit'=>'Wasser & Feuchtigkeit','core:world:feuer-und-gase'=>'Feuer & Gase','core:world:wetter-und-naturgefahren'=>'Wetter & Naturgefahren','core:world:technik-und-ausfalle'=>'Technik & Ausfälle');
}
function hbdp_world_sponsor_admin_form(){
    if(!current_user_can('manage_options'))return;
    $saved=hbdp_world_sponsor_options();
    echo '<div class="wrap"><h2>Verkaufbare Werbeflächen – sechs Hauptkategorien</h2><p>Nur ausgefüllte und gültig verlinkte Partnerflächen erscheinen öffentlich. Automatische Banner werden getrennt über den Filter <code>hbdp_world_auto_banner_html</code> geliefert.</p><form method="post">';
    wp_nonce_field('hbdp_world_sponsor_save');
    foreach(hbdp_world_hero_file_map() as $id=>$label){
        $v=$saved[$id]??array();echo '<fieldset style="max-width:760px;border:1px solid #ccc;padding:12px;margin:12px 0"><legend><strong>'.esc_html($label).'</strong></legend>';
        foreach(array('title'=>'Überschrift','description'=>'Kurztext','url'=>'Ziel-URL','image'=>'Bild-URL (optional)') as $key=>$desc){
          echo '<p><label>'.esc_html($desc).'<br><input type="text" style="width:100%" name="hbdp_sponsors['.esc_attr($id).']['.esc_attr($key).']" value="'.esc_attr((string)($v[$key]??'')).'"></label></p>';
        }echo '</fieldset>';
    }
    echo '<p><button type="submit" class="button button-primary" name="hbdp_save_world_sponsor" value="1">Werbeflächen speichern</button></p></form></div>';
}
