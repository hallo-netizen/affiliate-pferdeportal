/* One guarded content-flow correction. This moves ONLY the theme's content
 * container, NEVER the portal header, its navigation, or the footer. */
(function(){'use strict';
  var pending=false;
  function check(){
    pending=false;
    if(!document.body.classList.contains('hbdp-market-submit-route')) return;
    var nav=document.querySelector('#hbdp-submit-site-header .hbdp-mainnav-wrap');
    var content=document.querySelector('.site-container');
    var intro=document.getElementById('hbdp-submit-intro');
    if(!nav||!content||!intro||!content.contains(intro))return;
    content.style.removeProperty('margin-top');
    var below=nav.getBoundingClientRect().bottom+12;
    var actual=intro.getBoundingClientRect().top;
    if(!Number.isFinite(below)||!Number.isFinite(actual))return;
    if(actual<below){content.style.setProperty('margin-top',Math.ceil(below-actual)+'px','important');}
  }
  function schedule(){if(pending)return;pending=true;requestAnimationFrame(check);}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',schedule,{once:true});else schedule();
  window.addEventListener('load',schedule,{once:true});
  window.addEventListener('resize',schedule);
})();
