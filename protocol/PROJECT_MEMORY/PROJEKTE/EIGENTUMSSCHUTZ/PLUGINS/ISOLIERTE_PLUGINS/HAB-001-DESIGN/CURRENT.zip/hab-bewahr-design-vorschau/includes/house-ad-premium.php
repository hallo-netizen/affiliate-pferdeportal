<?php
/** Site-owned House ad placeholder: use EXACT header logo graphic/text, no derived image. */
if (!defined('ABSPATH')) { exit; }
function hbdp_house_ad_premium_html() {
    $prices = function_exists('hbdp_footer_page_url') ? hbdp_footer_page_url('preise') : '';
    $terms = function_exists('hbdp_footer_page_url') ? hbdp_footer_page_url('werb-anzeigebedingungen') : '';
    $brand = '<span class="hbdp-premium-original-brand hbd-brand"><svg class="hbd-arc" viewBox="0 24 260 52" role="img" aria-label="Schutzbogen">                        <path d="M 17 74 C 55 42 92 27 130 27 C 168 27 205 42 243 74 C 203 48 167 34 130 34 C 93 34 57 48 17 74 Z" fill="#B35C40"/>                    </svg><strong>Hab <em>&amp;</em> Bewahr</strong></span>';
    $links = '<span class="hbdp-premium-links">';
    if ($terms !== '') $links .= '<a class="hbdp-premium-terms" href="'.esc_url($terms).'">Werbebedingungen</a>';
    if ($prices !== '') $links .= '<a class="hbdp-premium-prices" href="'.esc_url($prices).'">Preise</a>';
    $links .= '</span>';
    return '<section class="hbdp-house-premium" aria-label="Werbefläche auf Hab und Bewahr">'
        .'<div class="hbdp-premium-content">'.$brand
        .'<h2>Hier könnte Ihre Werbung stehen!</h2>'
        .$links.'</div>'
        .'<div class="hbdp-premium-photo"><img src="'.esc_url(HBDP_URL.'assets/house-ad-entrance-first.webp').'" alt="Geschützter Hauseingang mit Sicherheitstür, Paketbox und Kamera" loading="lazy" decoding="async" width="1112" height="724"></div>'
        .'</section>';
}
