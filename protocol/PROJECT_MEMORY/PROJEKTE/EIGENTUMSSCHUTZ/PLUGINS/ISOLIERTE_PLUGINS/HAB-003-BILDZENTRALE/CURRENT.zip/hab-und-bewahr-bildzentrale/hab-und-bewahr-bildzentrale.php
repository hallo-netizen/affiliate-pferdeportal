<?php
/**
 * Plugin Name: Hab & Bewahr Bildzentrale
 * Description: Hab-&-Bewahr-Bildzentrale für Beiträge, WordPress-Taxonomien, Custom-Post-Type-Heros und optionale HivePress-Taxonomien mit Pixabay, Pexels und Magnific, sicheren Profilen, Export/Import und Readback-Fallback.
 * Version: 1.0.0
 * Author: OpenAI
 * Requires at least: 6.5
 * Requires PHP: 8.1
 */

if (!defined('ABSPATH')) {
    exit;
}

final class HBBZ_Plugin {
    private const OPTION_PIXABAY = 'hbbz_pixabay_api_key';
    private const OPTION_PEXELS  = 'hbbz_pexels_api_key';
    private const OPTION_MAGNIFIC_API_KEY = 'hbbz_magnific_api_key';
    private const OPTION_MAGNIFIC_WEBHOOK_SECRET = 'hbbz_magnific_webhook_secret';
    private const OPTION_MAGNIFIC_STYLE = 'hbbz_magnific_style_guide';
    private const OPTION_MAGNIFIC_TASK_MAP = 'hbbz_magnific_task_map';
    private const OPTION_MAGNIFIC_TASK_REGISTRY = 'hbbz_magnific_task_registry_v2';
    private const OPTION_PROMPT_RULES_VERSION = 'hbbz_prompt_rules_version';
    private const OPTION_VARIATION_HISTORY = 'hbbz_magnific_variation_history_v1';
    private const OPTION_EXCLUSIONS = 'hbbz_exclusion_terms';
    private const OPTION_GENERAL_PROFILES = 'hbbz_general_image_profiles_v1';
    private const OPTION_LAST_PROFILE_SAVE_RECEIPT = 'hbbz_last_profile_save_receipt_v1';
    private const OPTION_TAXONOMY_CONFIG = 'hbbz_taxonomy_image_config_v1'; // Own taxonomy image config; no foreign-portal dependency
    private const OPTION_GENERAL_SCHEMA = 'hbbz_general_schema_version';
    private const OPTION_PRE_GENERAL_BACKUP = 'hbbz_pre_generalization_backup_v1';
    private const OPTION_TERM_TASK_MAP = 'hbbz_magnific_term_task_map_v1';
    private const NONCE_ACTION   = 'hbbz_save_settings';
    private const DEFAULT_TEST_POST_ID = 0;
    private const OPTION_TARGET_POST = 'hbbz_target_post_id';
    private const OPTION_SELECTION = 'hbbz_selected_image_hab_und_bewahr_v1';
    private const MAX_BASE_PROMPT_CHARS = 100000;
    private const MAX_BASE_PROMPT_BYTES = 400000;
    private const MAX_GENERATED_PROMPT_CHARS = 3000;
    private const GENERATED_PROMPT_SAFETY_TAIL = ' No text, logo or watermark.';


    private static function utf8_len(string $value): int {
        if (function_exists('mb_strlen')) return mb_strlen($value, 'UTF-8');
        if (function_exists('iconv_strlen')) return (int) iconv_strlen($value, 'UTF-8');
        $n = preg_match_all('/./us', $value, $m);
        return $n === false ? strlen($value) : (int)$n;
    }
    private static function utf8_substr(string $value, int $start, ?int $length = null): string {
        if (function_exists('mb_substr')) return $length === null ? mb_substr($value, $start, null, 'UTF-8') : mb_substr($value, $start, $length, 'UTF-8');
        if (function_exists('iconv_substr')) return (string)($length === null ? iconv_substr($value, $start, iconv_strlen($value, 'UTF-8'), 'UTF-8') : iconv_substr($value, $start, $length, 'UTF-8'));
        $parts = preg_split('//u', $value, -1, PREG_SPLIT_NO_EMPTY);
        if (!is_array($parts)) return substr($value, $start, $length);
        return implode('', array_slice($parts, $start, $length));
    }
    private static function utf8_lower(string $value): string {
        if (function_exists('mb_strtolower')) return mb_strtolower($value, 'UTF-8');
        return strtr(strtolower($value), ['Ä'=>'ä','Ö'=>'ö','Ü'=>'ü','ẞ'=>'ß']);
    }

    public static function init(): void {
        self::maybe_upgrade_prompt_rules();
        self::maybe_upgrade_generalization();
        add_action('admin_menu', [self::class, 'admin_menu']);
        add_action('admin_post_hbbz_save_settings', [self::class, 'save_settings']);
        add_action('admin_post_hbbz_save_general_profiles', [self::class, 'save_general_profiles']);
        add_action('admin_post_hbbz_export_settings', [self::class, 'export_settings']);
        add_action('admin_post_hbbz_import_settings', [self::class, 'import_settings']);
        add_action('admin_post_hbbz_save_target_post', [self::class, 'save_target_post']);
        add_action('admin_post_hbbz_choose_queue_post', [self::class, 'choose_queue_post']);
        add_action('admin_post_hbbz_edit_processed_post', [self::class, 'edit_processed_post']);
        add_action('admin_post_hbbz_remove_featured_post', [self::class, 'remove_featured_post']);
        add_action('admin_post_hbbz_remove_content_image_post', [self::class, 'remove_content_image_post']);
        add_action('wp_ajax_hbbz_test_provider', [self::class, 'test_provider']);
        add_action('wp_ajax_hbbz_search_images', [self::class, 'search_images']);
        add_action('wp_ajax_hbbz_batch_preview', [self::class, 'batch_preview']);
        add_action('wp_ajax_hbbz_batch_apply', [self::class, 'batch_apply']);
        add_action('wp_ajax_hbbz_select_image', [self::class, 'select_image']);
        add_action('wp_ajax_hbbz_download_selected', [self::class, 'download_selected']);
        add_action('wp_ajax_hbbz_assign_featured', [self::class, 'assign_featured']);
        add_action('wp_ajax_hbbz_undo_featured', [self::class, 'undo_featured']);
        add_action('wp_ajax_hbbz_insert_content_image', [self::class, 'insert_content_image']);
        add_action('wp_ajax_hbbz_undo_content_image', [self::class, 'undo_content_image']);
        add_action('wp_ajax_hbbz_magnific_generate', [self::class, 'magnific_generate']);
        add_action('wp_ajax_hbbz_magnific_check', [self::class, 'magnific_check']);
        add_action('wp_ajax_hbbz_magnific_recover', [self::class, 'magnific_recover']);
        add_action('wp_ajax_hbbz_magnific_import', [self::class, 'magnific_import']);
        add_action('wp_ajax_hbbz_magnific_apply', [self::class, 'magnific_apply']);
        add_action('wp_ajax_hbbz_magnific_batch_generate', [self::class, 'magnific_batch_generate']);
        add_action('wp_ajax_hbbz_magnific_single_generate', [self::class, 'magnific_single_generate']);
        add_action('wp_ajax_hbbz_magnific_batch_status', [self::class, 'magnific_batch_status']);
        add_action('wp_ajax_hbbz_magnific_batch_import', [self::class, 'magnific_batch_import']);
        add_action('wp_ajax_hbbz_magnific_batch_apply', [self::class, 'magnific_batch_apply']);
        add_action('wp_ajax_hbbz_magnific_rebuild_prompt', [self::class, 'magnific_rebuild_prompt']);
        add_action('wp_ajax_hbbz_term_prompt', [self::class, 'term_prompt']);
        add_action('wp_ajax_hbbz_term_generate', [self::class, 'term_generate']);
        add_action('wp_ajax_hbbz_term_check', [self::class, 'term_check']);
        add_action('wp_ajax_hbbz_term_import', [self::class, 'term_import']);
        add_action('wp_ajax_hbbz_term_apply', [self::class, 'term_apply']);
        add_action('wp_ajax_hbbz_term_search', [self::class, 'term_search']);
        add_action('wp_ajax_hbbz_term_normalize_current', [self::class, 'term_normalize_current']);
        add_action('wp_ajax_hbbz_term_normalize_batch', [self::class, 'term_normalize_batch']);
        add_action('rest_api_init', [self::class, 'register_rest_routes']);
        add_filter('the_content', [self::class, 'append_frontend_credits'], 30);
    }

    public static function admin_menu(): void {
        add_menu_page(
            'Hab & Bewahr Bildzentrale',
            'Bildzentrale',
            'manage_options',
            'hab-und-bewahr-bildzentrale',
            [self::class, 'render_page'],
            'dashicons-format-image',
            58
        );
    }

    
public static function render_page(): void {
    if (!current_user_can('manage_options')) {
        return;
    }

    $pixabay = (string) get_option(self::OPTION_PIXABAY, '');
    $pexels  = (string) get_option(self::OPTION_PEXELS, '');
    $magnific_api_key = (string) get_option(self::OPTION_MAGNIFIC_API_KEY, '');
    $magnific_webhook_secret = (string) get_option(self::OPTION_MAGNIFIC_WEBHOOK_SECRET, '');
    $target_post_id = self::get_target_post_id();
    $post    = get_post($target_post_id);
    $prompt_analysis = self::analyze_article_for_image($post);
    $variation_plan = self::build_variation_plan($post);
    $motif_clusters = self::available_motif_clusters();
    $selection = get_option(self::OPTION_SELECTION, []);
    $batch_overview = self::get_magnific_batch_overview();
    $magnific_credit_stats = self::local_magnific_credit_stats();
    $allowed_tabs = ['posts', 'wp', 'cpt', 'hp', 'admin'];
    $requested_tab = isset($_GET['hbbz_tab']) ? sanitize_key((string) wp_unslash($_GET['hbbz_tab'])) : 'posts';
    $active_tab = in_array($requested_tab, $allowed_tabs, true) ? $requested_tab : 'posts';
    ?>
    <div class="wrap">
        <h1>Hab & Bewahr Bildzentrale</h1>
        <p class="description">Eigenständige Bildzentrale für Hab &amp; Bewahr. Neue Bilder werden erst nach bewusster Prüfung/Zuordnung übernommen. Verbindungen und Profile gelten nur für diese WordPress-Installation.</p>
        <p><strong>Gebündelter HivePress-Erkennungsstand 2.5.3</strong></p>
        <p><strong>Ziel dieses Stands:</strong> Inhalte klar trennen. Beiträge, WordPress-Kategorien und HivePress-Kategorien haben jeweils ihre eigenen Prompt- und Stilbereiche. Verbindungen, Sicherung und Verwaltung bleiben zentral an einem Ort.</p>

        <?php if (isset($_GET['updated'])) : ?>
            <div class="notice notice-success is-dismissible"><p>Einstellungen gespeichert.</p></div>
        <?php endif; ?>

        <nav class="hbbz-tabs" aria-label="Bildzentrale Bereiche">
            <button type="button" class="hbbz-tab-button<?php echo $active_tab === 'posts' ? ' is-active' : ''; ?>" data-hbbz-target="posts">Beiträge</button>
            <button type="button" class="hbbz-tab-button<?php echo $active_tab === 'wp' ? ' is-active' : ''; ?>" data-hbbz-target="wp">WordPress-Kategorien</button>
            <button type="button" class="hbbz-tab-button<?php echo $active_tab === 'cpt' ? ' is-active' : ''; ?>" data-hbbz-target="cpt">Post-Type-Hero</button>
            <button type="button" class="hbbz-tab-button<?php echo $active_tab === 'hp' ? ' is-active' : ''; ?>" data-hbbz-target="hp">HivePress-Kategorien</button>
            <button type="button" class="hbbz-tab-button<?php echo $active_tab === 'admin' ? ' is-active' : ''; ?>" data-hbbz-target="admin">Verbindungen &amp; Sicherung</button>
        </nav>

        <div id="hbbz-panel-posts" class="hbbz-tab-panel<?php echo $active_tab === 'posts' ? ' is-active' : ''; ?>">
            <?php self::render_dashboard_summary(); ?>
            <?php self::render_article_profile_panel(); ?>
        <h2>Magnific KI-Bildproduktion</h2>
        <table class="widefat striped" style="max-width:980px">
            <tbody>
                <tr><td style="width:240px"><strong>Konfigurationsstatus</strong></td><td><?php echo ($magnific_api_key !== '' && $magnific_webhook_secret !== '') ? '<span style="color:#008a20">API-Key und Webhook-Geheimnis vorhanden</span>' : '<span style="color:#b32d2e">Konfiguration unvollständig</span>'; ?></td></tr>
                <tr><td><strong>Modell</strong></td><td><code>nano-banana-pro-flash</code></td></tr>
                <tr><td><strong>Ausgabe</strong></td><td>3:2 · 1K · anschließend WebP 1500 × 1000</td></tr>
                <tr><td><strong>Lokal erfasster Creditverbrauch</strong></td><td><?php echo esc_html((string) $magnific_credit_stats['credits']); ?> Credits aus <?php echo esc_html((string) $magnific_credit_stats['tasks']); ?> gespeicherten KI-Aufträgen <span class="description">(75 Credits je Auftrag; nur lokal erfasste Plugin-Aufträge)</span></td></tr>
                <tr><td><strong>Exakter Magnific-Creditstand</strong></td><td>Im Magnific-Konto prüfen – für Premium ist kein exakter Guthaben-Endpunkt öffentlich dokumentiert.</td></tr>
                <tr><td><strong>Webhook-Adresse</strong></td><td><code><?php echo esc_html(rest_url('hab-und-bewahr-bildzentrale/v1/magnific-webhook')); ?></code></td></tr>
            </tbody>
        </table>
        <?php if ($post instanceof WP_Post) : ?>
            <p class="hbbz-current-prompt-post"><strong>Aktueller Beitrag:</strong> #<?php echo esc_html((string) $post->ID); ?> – <?php echo esc_html(get_the_title($post)); ?></p>
        <?php else : ?>
            <p class="hbbz-current-prompt-post"><strong>Aktueller Beitrag:</strong> nicht gefunden</p>
        <?php endif; ?>
        <p><label for="hbbz-magnific-custom-motif"><strong>Eigenes Motiv (Deutsch, passend zum Eigentumsschutz):</strong></label><br>
            <input type="text" class="large-text" id="hbbz-magnific-custom-motif" maxlength="240" placeholder="z. B. Fenstersicherung am Wohnhaus, reale Montagesituation ohne Markenlogos">
            <button type="button" class="button" id="hbbz-magnific-rebuild-prompt">Motiv übersetzen und Prompt neu erstellen</button>
        </p>
        <p class="description">Freie deutsche Motivbeschreibung. Sie wird als höchste inhaltliche Priorität ins Englische übertragen. Der verbindliche Grundprompt bleibt unverändert.</p>
        <p><strong>Übersetztes Motiv:</strong> <span id="hbbz-analysis-translated-motif">–</span></p>
        <p><strong>Automatisch erzeugter Prompt:</strong></p>
        <textarea class="large-text code" rows="12" id="hbbz-magnific-prompt"><?php echo esc_textarea(self::suggest_magnific_prompt($post)); ?></textarea>
        <p class="description" id="hbbz-magnific-prompt-length">Prompt-Länge wird geprüft.</p>
        <table class="widefat striped" style="max-width:980px;margin-top:10px">
            <tbody>
                <tr><td style="width:240px"><strong>Erkanntes Hauptmotiv</strong></td><td id="hbbz-analysis-scene"><?php echo esc_html((string) ($prompt_analysis['scene'] ?? '')); ?></td></tr>
                <tr><td><strong>Erkannte Umgebung</strong></td><td id="hbbz-analysis-background"><?php echo esc_html((string) ($prompt_analysis['background'] ?? '')); ?></td></tr>
                <tr><td><strong>Wetterregel</strong></td><td id="hbbz-analysis-weather"><?php echo esc_html((string) ($prompt_analysis['weather'] ?? '')); ?></td></tr>
                <tr><td><strong>Menschenregel</strong></td><td id="hbbz-analysis-people"><?php echo esc_html((string) ($prompt_analysis['people'] ?? '')); ?></td></tr>
                <tr><td><strong>Motivcluster</strong></td><td id="hbbz-analysis-cluster"><?php echo esc_html((string) ($variation_plan['cluster_label'] ?? '')); ?></td></tr>
                <tr><td><strong>Geplante Variation</strong></td><td id="hbbz-analysis-variation"><?php echo esc_html(self::summarize_variation_plan($variation_plan)); ?></td></tr>
            </tbody>
        </table>
        <p>
            <label><strong>Varianten:</strong>
                <select id="hbbz-magnific-variants"><option value="1">1</option><option value="2" selected>2</option><option value="3">3</option></select>
            </label>
            <button type="button" class="button button-primary" id="hbbz-magnific-generate">KI-Varianten erzeugen</button>
            <button type="button" class="button" id="hbbz-magnific-check">Status jetzt prüfen</button>
        </p>
        <p class="description">Magnific meldet fertige Ergebnisse automatisch per signiertem Webhook. Die Statusprüfung bleibt als Fallback vorhanden. Das bestehende Beitragsbild wird erst nach bewusster Auswahl ersetzt.</p>
        <div id="hbbz-magnific-status" aria-live="polite"></div>
        <div id="hbbz-magnific-results"><?php self::render_magnific_results($post); ?></div>

        <hr>
        <h2>Arbeitsbeitrag</h2>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="hbbz_save_target_post">
            <?php wp_nonce_field('hbbz_save_target_post'); ?>
            <label for="hbbz_target_post_id"><strong>Beitrags-ID:</strong></label>
            <input type="number" min="1" id="hbbz_target_post_id" name="hbbz_target_post_id" value="<?php echo esc_attr((string) $target_post_id); ?>">
            <?php submit_button('Arbeitsbeitrag übernehmen', 'secondary', 'submit', false); ?>
        </form>

        <h2>Bildsuche und Zuordnung</h2>
        <?php if ($post instanceof WP_Post) : ?>
            <p><strong>Beitrag <?php echo esc_html((string) $target_post_id); ?>:</strong> <?php echo esc_html(get_the_title($post)); ?></p>
        <?php else : ?>
            <div class="notice notice-error inline"><p>Der gewählte Beitrag wurde nicht gefunden.</p></div>
        <?php endif; ?>

        <p>
            <label for="hbbz-search-direction"><strong>Suchrichtung:</strong></label><br>
            <input type="text" class="regular-text" id="hbbz-search-direction" maxlength="100" value="<?php echo esc_attr(self::suggest_query_for_post($post)); ?>">
            <p class="description">Suchbegriff kann geändert werden. Empfehlung: kurze englische Motivbeschreibung.</p>
            <button type="button" class="button button-primary" id="hbbz-search">Vorschläge anzeigen</button>
        </p>
        <p><em>Pflichtprüfung durch dich: keine Personen, Kinder, Logos, Marken oder Schrift im Bild.</em></p>
        <div id="hbbz-stock-assignment-status" class="notice inline" style="display:none" aria-live="polite"><p></p></div>
        <div id="hbbz-selection" class="hbbz-selection">
            <?php if (is_array($selection) && !empty($selection['page_url'])) : ?>
                <strong>Aktuell ausgewählt:</strong> <?php echo esc_html(($selection['provider'] ?? '') . ' – ' . ($selection['photographer'] ?? '')); ?>
                · <a href="<?php echo esc_url((string) $selection['page_url']); ?>" target="_blank" rel="noopener noreferrer">Quellseite öffnen</a>
                <?php if (($selection['status'] ?? '') === 'selected_only_not_downloaded') : ?>
                    <br><button type="button" class="button button-primary" id="hbbz-download-selected">Ausgewähltes Bild in die Mediathek laden</button>
                <?php elseif (in_array(($selection['status'] ?? ''), ['downloaded_to_media_library', 'featured_image_set'], true)) : ?>
                    <br><strong>In Mediathek gespeichert.</strong> Medien-ID: <?php echo esc_html((string) ($selection['attachment_id'] ?? '')); ?>
                    <?php if (($selection['status'] ?? '') === 'featured_image_set') : ?>
                        <br><strong>Als Beitragsbild gesetzt.</strong>
                        <br><button type="button" class="button" id="hbbz-undo-featured">Beitragsbild-Zuordnung zurücknehmen</button>
                        <?php self::render_heading_selector($post); ?>
                        <button type="button" class="button button-primary" id="hbbz-insert-content-image">Als Inhaltsbild an gewählter Stelle einsetzen</button>
                    <?php else : ?>
                        <br><button type="button" class="button button-primary" id="hbbz-assign-featured">Lizenzdaten prüfen und als Beitragsbild setzen</button>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if (($selection['content_image_status'] ?? '') === 'inserted') : ?>
                    <br><strong>Als Inhaltsbild eingesetzt.</strong>
                    <br><button type="button" class="button" id="hbbz-undo-content-image">Inhaltsbild wieder entfernen</button>
                <?php endif; ?>
            <?php else : ?>
                <strong>Noch kein Bild ausgewählt.</strong>
            <?php endif; ?>
        </div>
        <div id="hbbz-search-status" aria-live="polite"></div>
        <div id="hbbz-search-results"></div>

        <hr>
        <h2>Automatisierungsübersicht</h2>
        <p>Vorschau der nächsten Beiträge ohne Beitragsbild. Für den KI-Sammellauf können bis zu fünfzig Beiträge markiert werden.</p>
        <?php self::render_automation_preview(); ?>

        <div class="hbbz-batch-panel hbbz-batch-panel-ai">
            <h3>Magnific KI-Sammellauf</h3>
            <p><button type="button" class="button" id="hbbz-batch-select-visible">Sichtbare auswählen</button> <button type="button" class="button" id="hbbz-batch-clear-visible">Auswahl leeren</button></p>
            <p><label for="hbbz-batch-concurrency"><strong>Parallele KI-Aufträge:</strong></label> <select id="hbbz-batch-concurrency"><option value="2">2</option><option value="3" selected>3</option><option value="4">4</option><option value="5">5</option></select> <button type="button" class="button button-primary" id="hbbz-magnific-batch-generate">Je Beitrag 1 KI-Bild erzeugen</button></p>
            <div id="hbbz-ai-batch-status" class="hbbz-status-box" aria-live="polite">Noch kein KI-Sammellauf gestartet.</div>
            <div id="hbbz-ai-batch-results"></div>
        </div>

        <div class="hbbz-batch-panel hbbz-batch-panel-stock">
            <h3>Stockbilder von Pixabay/Pexels</h3>
            <p><button type="button" class="button button-primary" id="hbbz-batch-preview">Stock-Vorschläge vorbereiten</button></p>
            <div id="hbbz-stock-batch-status" class="hbbz-status-box" aria-live="polite">Noch keine Stock-Vorschläge vorbereitet.</div>
            <div id="hbbz-stock-batch-results"></div>
            <p><button type="button" class="button button-primary" id="hbbz-batch-apply" style="display:none">Ausgewählte Beitragsbilder gesammelt übernehmen</button></p>
        </div>

        <hr>
        <h2>Bereits bearbeitete Beiträge</h2>
        <p>Jeder bereits bearbeitete Beitrag kann erneut geöffnet, sein Bild ersetzt oder entfernt werden.</p>
        <?php self::render_processed_posts(); ?>

        <hr>
        <h2>Änderungshistorie des Arbeitsbeitrags</h2>
        <?php self::render_post_history($target_post_id); ?>

        <hr>
        <h2>Qualitätsprüfung</h2>
        <?php self::render_quality_audit(); ?>

        <hr>
        <h2>Lizenzregister</h2>
        <?php self::render_license_register(); ?>

        </div>

        <?php self::render_generalization_panel('wp'); ?>
        <?php self::render_generalization_panel('cpt'); ?>
        <?php self::render_generalization_panel('hp'); ?>

        <div id="hbbz-panel-admin" class="hbbz-tab-panel<?php echo $active_tab === 'admin' ? ' is-active' : ''; ?>">
            <div class="hbbz-admin-box">
        <h2>API-Zugänge</h2>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="hbbz_save_settings">
            <input type="hidden" name="hbbz_return_tab" value="admin">
            <?php wp_nonce_field(self::NONCE_ACTION); ?>

            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="hbbz_pixabay_api_key">Pixabay API-Key</label></th>
                    <td>
                        <input type="password" class="regular-text" id="hbbz_pixabay_api_key" name="hbbz_pixabay_api_key" value="<?php echo esc_attr($pixabay); ?>" autocomplete="off">
                        <button type="button" class="button hbbz-test" data-provider="pixabay">Verbindung testen</button>
                        <span class="hbbz-result" id="hbbz-result-pixabay"></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="hbbz_pexels_api_key">Pexels API-Key</label></th>
                    <td>
                        <input type="password" class="regular-text" id="hbbz_pexels_api_key" name="hbbz_pexels_api_key" value="<?php echo esc_attr($pexels); ?>" autocomplete="off">
                        <button type="button" class="button hbbz-test" data-provider="pexels">Verbindung testen</button>
                        <span class="hbbz-result" id="hbbz-result-pexels"></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="hbbz_magnific_api_key">Magnific API-Key</label></th>
                    <td>
                        <input type="password" class="regular-text" id="hbbz_magnific_api_key" name="hbbz_magnific_api_key" value="<?php echo esc_attr($magnific_api_key); ?>" autocomplete="off">
                        <button type="button" class="button hbbz-test" data-provider="magnific">Verbindung testen</button>
                        <span class="hbbz-result" id="hbbz-result-magnific"></span>
                        <p class="description">Der Verbindungstest prüft nur den API-Schlüssel über Magnific-Ressourcen. Vor einer KI-Erzeugung prüft das Plugin zusätzlich den KI-Endpunkt. Es wird dabei kein Credit verbraucht.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="hbbz_magnific_webhook_secret">Magnific Webhook-Geheimnis</label></th>
                    <td>
                        <input type="password" class="regular-text" id="hbbz_magnific_webhook_secret" name="hbbz_magnific_webhook_secret" value="<?php echo esc_attr($magnific_webhook_secret); ?>" autocomplete="off">
                        <p class="description">Wird später zur Prüfung eingehender Magnific-Webhooks verwendet.</p>
                    </td>
                </tr>
            </table>

            <?php submit_button('API-Schlüssel speichern'); ?>
        </form>
            </div>
            <?php self::render_generalization_panel('admin'); ?>
        </div>

    </div>
        <style>
            .hbbz-tabs { display:flex; gap:8px; flex-wrap:wrap; margin:18px 0 20px; }
            .hbbz-tab-button { border:1px solid #c3c4c7; background:#fff; padding:8px 14px; cursor:pointer; border-radius:4px; font-weight:600; }
            .hbbz-tab-button.is-active { background:#2271b1; color:#fff; border-color:#2271b1; }
            .hbbz-tab-panel { display:none; }
            .hbbz-tab-panel.is-active { display:block; }
            .hbbz-admin-box { max-width:1180px; margin:18px 0; padding:16px; background:#fff; border:1px solid #c3c4c7; scroll-margin-top:32px; }
            .hbbz-term-search-results { max-width:760px; display:flex; flex-direction:column; gap:6px; margin:8px 0; }
            .hbbz-term-search-choice { text-align:left; height:auto; white-space:normal; padding:7px 10px; }
            .hbbz-provider-title { margin-top: 24px; }
            .hbbz-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 16px; max-width: 1100px; }
            .hbbz-card { background: #fff; border: 1px solid #c3c4c7; padding: 12px; }
            .hbbz-card img { display: block; width: 100%; height: 170px; object-fit: cover; background: #f0f0f1; }
            .hbbz-card p { margin: 8px 0 0; }
            .hbbz-card .hbbz-select { margin-top: 10px; width: 100%; }
            .hbbz-selection { background: #fff; border-left: 4px solid #2271b1; padding: 10px 12px; margin: 12px 0; max-width: 1080px; }
            .hbbz-current-prompt-post { max-width: 980px; padding: 10px 12px; margin: 14px 0 8px; background: #fff; border-left: 4px solid #2271b1; font-size: 14px; }
            .hbbz-batch-panel { max-width: 1180px; margin: 18px 0; padding: 16px; background: #fff; border: 1px solid #c3c4c7; }
            .hbbz-batch-panel-ai { border-left: 5px solid #6a7f4a; }
            .hbbz-batch-panel-stock { border-left: 5px solid #2271b1; }
            .hbbz-status-box { padding: 10px 12px; margin: 10px 0; background: #f6f7f7; border: 1px solid #dcdcde; font-weight: 600; }
            .hbbz-batch-thumb { width: 220px; max-width: 100%; height: 145px; object-fit: cover; display: block; margin-bottom: 8px; background: #f0f0f1; }
            .hbbz-batch-actions .button { margin: 0 6px 6px 0; }
        </style>

        <script>
        document.addEventListener('DOMContentLoaded', function () {
            const ajaxNonce = '<?php echo esc_js(wp_create_nonce('hbbz_ajax')); ?>';
            const magnificPostId = '<?php echo esc_js((string) $target_post_id); ?>';
            const existingMagnificBatch = <?php echo wp_json_encode($batch_overview, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;

            const hbbzTabButtons = Array.from(document.querySelectorAll('.hbbz-tab-button'));
            const hbbzTabPanels = {
                posts: document.getElementById('hbbz-panel-posts'),
                wp: document.getElementById('hbbz-panel-wp'),
                cpt: document.getElementById('hbbz-panel-cpt'),
                hp: document.getElementById('hbbz-panel-hp'),
                admin: document.getElementById('hbbz-panel-admin')
            };
            function activateHbbzTab(key, updateUrl = true) {
                if (!hbbzTabPanels[key]) return;
                hbbzTabButtons.forEach(function (button) {
                    button.classList.toggle('is-active', button.dataset.hbbzTarget === key);
                });
                Object.keys(hbbzTabPanels).forEach(function (name) {
                    if (hbbzTabPanels[name]) hbbzTabPanels[name].classList.toggle('is-active', name === key);
                });
                if (updateUrl) {
                    const url = new URL(window.location.href);
                    url.searchParams.set('hbbz_tab', key);
                    url.hash = 'hbbz-' + key;
                    history.replaceState(null, '', url.toString());
                }
            }
            hbbzTabButtons.forEach(function (button) {
                button.addEventListener('click', function () { activateHbbzTab(button.dataset.hbbzTarget); });
            });
            const requestedHbbzTabFromQuery = new URLSearchParams(window.location.search).get('hbbz_tab') || '';
            const requestedHbbzTabFromHash = (window.location.hash || '').replace('#hbbz-', '');
            const requestedHbbzTab = hbbzTabPanels[requestedHbbzTabFromQuery] ? requestedHbbzTabFromQuery : requestedHbbzTabFromHash;
            if (requestedHbbzTab && hbbzTabPanels[requestedHbbzTab]) activateHbbzTab(requestedHbbzTab, false);

            async function parseJsonResponse(response) {
                const raw = await response.text();
                let data;
                try {
                    data = JSON.parse(raw);
                } catch (error) {
                    const compact = raw.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 300);
                    throw new Error('Server lieferte keine gültige JSON-Antwort. HTTP ' + response.status + (compact ? ': ' + compact : '.'));
                }
                const extractErrorMessage = function (payload) {
                    if (!payload) return '';
                    if (typeof payload === 'string') return payload;
                    if (typeof payload.message === 'string' && payload.message.trim() !== '') return payload.message;
                    if (typeof payload.error === 'string' && payload.error.trim() !== '') return payload.error;
                    try { return JSON.stringify(payload); } catch (error) { return String(payload); }
                };
                if (!response.ok || (data && data.success === false)) {
                    const message = extractErrorMessage(data ? data.data : null) || ('HTTP ' + response.status);
                    throw new Error(message);
                }
                return data;
            }


            function renderMagnificResults(items) {
                const container = document.getElementById('hbbz-magnific-results');
                if (!container) return;
                container.innerHTML = '';
                if (!Array.isArray(items) || !items.length) {
                    container.innerHTML = '<p>Noch keine fertigen KI-Bilder vorhanden.</p>';
                    return;
                }
                const grid = document.createElement('div');
                grid.className = 'hbbz-grid';
                items.forEach(function (item, index) {
                    const card = document.createElement('div');
                    card.className = 'hbbz-card';
                    const img = document.createElement('img');
                    img.src = item.url;
                    img.alt = item.label || ('KI-Bild ' + (index + 1));
                    card.appendChild(img);
                    const p = document.createElement('p');
                    p.textContent = item.label || ('KI-Bild ' + (index + 1));
                    card.appendChild(p);
                    const btn = document.createElement('button');
                    btn.type = 'button';
                    btn.className = 'button button-primary';
                    btn.textContent = 'In Mediathek laden';
                    btn.dataset.index = String(index);
                    btn.id = 'hbbz-magnific-import-' + index;
                    card.appendChild(btn);
                    const apply = document.createElement('button');
                    apply.type = 'button';
                    apply.className = 'button';
                    apply.style.marginTop = '8px';
                    apply.textContent = 'Direkt als Beitragsbild übernehmen';
                    apply.dataset.index = String(index);
                    apply.id = 'hbbz-magnific-apply-' + index;
                    card.appendChild(apply);
                    grid.appendChild(card);
                });
                container.appendChild(grid);
            }

            function renderMagnificRecoveryCandidates(items) {
                const container = document.getElementById('hbbz-magnific-results');
                if (!container) return;
                container.innerHTML = '<p><strong>Verwaiste Magnific-Aufträge:</strong> Nur das eindeutig passende Bild zuordnen.</p>';
                const grid = document.createElement('div'); grid.className='hbbz-grid';
                (items || []).forEach(function(item){
                    const card=document.createElement('div'); card.className='hbbz-card';
                    if(Array.isArray(item.images)&&item.images[0]){const img=document.createElement('img');img.src=item.images[0];img.alt='Magnific-Auftrag '+item.task_id;card.appendChild(img);}
                    const p=document.createElement('p');p.textContent='Status: '+(item.status||'UNKNOWN')+' · Task '+item.task_id;card.appendChild(p);
                    const b=document.createElement('button');b.type='button';b.className='button button-primary hbbz-magnific-recover';b.dataset.taskId=item.task_id;b.textContent='Diesem Beitrag zuordnen';card.appendChild(b);
                    grid.appendChild(card);
                });
                container.appendChild(grid);
            }

            function updateMagnificPromptLength() {
                const promptField = document.getElementById('hbbz-magnific-prompt');
                const lengthField = document.getElementById('hbbz-magnific-prompt-length');
                const generateButton = document.getElementById('hbbz-magnific-generate');
                if (!promptField || !lengthField) return;
                const length = (promptField.value || '').length;
                lengthField.textContent = 'Prompt-Länge: ' + length + ' / 3000 Zeichen.';
                lengthField.style.color = length > 3000 ? '#b32d2e' : '';
                if (generateButton) generateButton.disabled = length < 2 || length > 3000;
            }
            const promptFieldForLength = document.getElementById('hbbz-magnific-prompt');
            if (promptFieldForLength) {
                promptFieldForLength.addEventListener('input', updateMagnificPromptLength);
                updateMagnificPromptLength();
            }

            const rebuildPromptButton = document.getElementById('hbbz-magnific-rebuild-prompt');
            if (rebuildPromptButton) {
                rebuildPromptButton.addEventListener('click', function () {
                    const status = document.getElementById('hbbz-magnific-status');
                    const customMotif = (document.getElementById('hbbz-magnific-custom-motif') || {}).value || '';
                    if (!customMotif.trim()) { status.textContent = 'Bitte ein eigenes Motiv auf Deutsch eingeben.'; return; }
                    rebuildPromptButton.disabled = true;
                    status.textContent = 'Motiv wird übersetzt und der Prompt neu erstellt …';
                    const body = new URLSearchParams({action:'hbbz_magnific_rebuild_prompt', nonce:ajaxNonce, post_id:magnificPostId, custom_motif:customMotif});
                    fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()})
                        .then(parseJsonResponse)
                        .then(data => {
                            const payload = data.data || {};
                            document.getElementById('hbbz-magnific-prompt').value = payload.prompt || '';
                            updateMagnificPromptLength();
                            const mapping = {scene:'hbbz-analysis-scene',background:'hbbz-analysis-background',weather:'hbbz-analysis-weather',people:'hbbz-analysis-people',cluster_label:'hbbz-analysis-cluster',variation_summary:'hbbz-analysis-variation',translated_motif:'hbbz-analysis-translated-motif'};
                            Object.keys(mapping).forEach(function(key){ const el=document.getElementById(mapping[key]); if(el) el.textContent=payload[key]||''; });
                            status.textContent = 'Prompt wurde neu erstellt. Noch kein KI-Auftrag gestartet.';
                        })
                        .catch(error => { status.textContent='Fehler: '+error.message; })
                        .finally(() => { rebuildPromptButton.disabled=false; });
                });
            }

            const magnificGenerateButton = document.getElementById('hbbz-magnific-generate');
            if (magnificGenerateButton) {
                magnificGenerateButton.addEventListener('click', function () {
                    const status = document.getElementById('hbbz-magnific-status');
                    const prompt = document.getElementById('hbbz-magnific-prompt').value || '';
                    status.textContent = 'Magnific-Auftrag wird erstellt …';
                    magnificGenerateButton.disabled = true;
                    const variants = document.getElementById('hbbz-magnific-variants').value || '2';
                    const customMotif = (document.getElementById('hbbz-magnific-custom-motif') || {}).value || '';
                    const body = new URLSearchParams({action: 'hbbz_magnific_generate', nonce: ajaxNonce, post_id: magnificPostId, prompt: prompt, variants: variants, custom_motif: customMotif});
                    fetch(ajaxurl, {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}, body: body.toString()})
                        .then(parseJsonResponse)
                        .then(data => {
                            status.textContent = (data.data.count || 1) + ' KI-Auftrag/Aufträge gestartet. Fertige Ergebnisse erscheinen automatisch oder über die Statusprüfung.';
                        })
                        .catch(error => { status.textContent = 'Fehler: ' + error.message; })
                        .finally(() => { magnificGenerateButton.disabled = false; });
                });
            }

            const magnificCheckButton = document.getElementById('hbbz-magnific-check');
            if (magnificCheckButton) {
                magnificCheckButton.addEventListener('click', function () {
                    const status = document.getElementById('hbbz-magnific-status');
                    status.textContent = 'Magnific-Status wird geprüft …';
                    const body = new URLSearchParams({action: 'hbbz_magnific_check', nonce: ajaxNonce, post_id: magnificPostId});
                    fetch(ajaxurl, {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}, body: body.toString()})
                        .then(parseJsonResponse)
                        .then(data => {
                            const payload = data.data || {};
                            const notes = Array.isArray(payload.messages) && payload.messages.length ? ' – ' + payload.messages.join(' ') : '';
                            status.textContent = 'Status: ' + (payload.status || 'unbekannt') + notes;
                            if (Array.isArray(payload.recovery_candidates) && payload.recovery_candidates.length) {
                                renderMagnificRecoveryCandidates(payload.recovery_candidates);
                            } else if (Array.isArray(payload.images)) {
                                renderMagnificResults(payload.images);
                            }
                        })
                        .catch(error => { status.textContent = 'Fehler: ' + error.message; });
                });
            }

            document.addEventListener('click', function(event){
                const button=event.target.closest('.hbbz-magnific-recover'); if(!button)return;
                const status=document.getElementById('hbbz-magnific-status'); button.disabled=true; button.textContent='Zuordnung wird geprüft …';
                const body=new URLSearchParams({action:'hbbz_magnific_recover',nonce:ajaxNonce,post_id:magnificPostId,task_id:button.dataset.taskId||''});
                fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()})
                  .then(parseJsonResponse).then(data=>{status.textContent='Magnific-Auftrag wurde Beitrag #'+magnificPostId+' zugeordnet. Status: '+(data.data.status||'UNKNOWN'); if(Array.isArray(data.data.images))renderMagnificResults(data.data.images);})
                  .catch(error=>{status.textContent='Fehler: '+error.message;button.disabled=false;button.textContent='Diesem Beitrag zuordnen';});
            });

            document.addEventListener('click', function (event) {
                const importButton = event.target.closest('[id^="hbbz-magnific-import-"]');
                if (!importButton) {
                    return;
                }
                const index = importButton.dataset.index || '0';
                const status = document.getElementById('hbbz-magnific-status');
                importButton.disabled = true;
                importButton.textContent = 'Lade in Mediathek …';
                const body = new URLSearchParams({action: 'hbbz_magnific_import', nonce: ajaxNonce, index: index});
                fetch(ajaxurl, {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}, body: body.toString()})
                    .then(parseJsonResponse)
                    .then(data => {
                        const payload = data.data || {};
                        if (payload.already_existing) {
                            status.textContent = 'Bild bereits in der Mediathek vorhanden. Vorhandene Medien-ID #' + payload.attachment_id + ' wurde verwendet.';
                            importButton.disabled = false;
                            importButton.textContent = 'In Mediathek laden';
                            return;
                        }
                        status.textContent = 'KI-Bild wurde in die Mediathek geladen. Medien-ID #' + payload.attachment_id + '.';
                        window.location.reload();
                    })
                    .catch(error => {
                        status.textContent = 'Fehler: ' + error.message;
                        importButton.disabled = false;
                        importButton.textContent = 'In Mediathek laden';
                    });
            });


            document.addEventListener('click', function (event) {
                const applyButton = event.target.closest('[id^="hbbz-magnific-apply-"]');
                if (!applyButton) return;
                const index = applyButton.dataset.index || '0';
                const status = document.getElementById('hbbz-magnific-status');
                applyButton.disabled = true;
                applyButton.textContent = 'Import und Austausch laufen …';
                const body = new URLSearchParams({action: 'hbbz_magnific_apply', nonce: ajaxNonce, index: index});
                fetch(ajaxurl, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}, body:body.toString()})
                    .then(parseJsonResponse)
                    .then(data => { status.textContent = 'KI-Bild wurde importiert und als Beitragsbild gesetzt. Das vorherige Bild bleibt in der Mediathek und ist über die Historie nachvollziehbar.'; window.location.reload(); })
                    .catch(error => { status.textContent = 'Fehler: ' + error.message; applyButton.disabled=false; applyButton.textContent='Direkt als Beitragsbild übernehmen'; });
            });

            function escapeHtml(value) {
                return String(value == null ? '' : value).replace(/[&<>'"]/g, function (char) {
                    return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char];
                });
            }

            function renderBatchRows(items) {
                const container = document.getElementById('hbbz-ai-batch-results');
                if (!container) return;
                const rows = items.map(item => '<tr data-post-id="' + escapeHtml(item.id) + '"><td>' + escapeHtml(item.id) + '</td><td>' + escapeHtml(item.title) + '</td><td class="hbbz-batch-state">Wartet</td><td class="hbbz-batch-note">Noch nicht gestartet</td><td class="hbbz-batch-result">–</td></tr>').join('');
                container.innerHTML = '<table class="widefat striped"><thead><tr><th>ID</th><th>Beitrag</th><th>Status</th><th>Hinweis</th><th>Ergebnis / Auswahl</th></tr></thead><tbody>' + rows + '</tbody></table>';
            }

            function getBatchRow(id) {
                return document.querySelector('#hbbz-ai-batch-results tr[data-post-id="' + String(id) + '"]');
            }

            function updateBatchRow(id, state, note) {
                const row = getBatchRow(id);
                if (!row) return;
                const stateCell = row.querySelector('.hbbz-batch-state');
                const noteCell = row.querySelector('.hbbz-batch-note');
                if (stateCell) stateCell.textContent = state;
                if (noteCell) noteCell.textContent = note || '–';
            }

            function renderBatchImage(id, image, index) {
                const row = getBatchRow(id);
                if (!row) return;
                const cell = row.querySelector('.hbbz-batch-result');
                if (!cell) return;
                cell.innerHTML = '';
                const img = document.createElement('img');
                img.className = 'hbbz-batch-thumb';
                img.src = image.display_url || image.url || '';
                img.alt = image.label || ('KI-Bild für Beitrag ' + id);
                cell.appendChild(img);
                const actions = document.createElement('div');
                actions.className = 'hbbz-batch-actions';
                const importButton = document.createElement('button');
                importButton.type = 'button';
                importButton.className = 'button hbbz-batch-image-import';
                importButton.dataset.postId = String(id);
                importButton.dataset.index = String(index || 0);
                importButton.textContent = 'In Mediathek laden';
                actions.appendChild(importButton);
                const applyButton = document.createElement('button');
                applyButton.type = 'button';
                applyButton.className = 'button button-primary hbbz-batch-image-apply';
                applyButton.dataset.postId = String(id);
                applyButton.dataset.index = String(index || 0);
                applyButton.textContent = 'Als Beitragsbild übernehmen';
                actions.appendChild(applyButton);
                cell.appendChild(actions);
            }

            async function checkBatchPost(postId, attempt) {
                const maxAttempts = 120;
                const body = new URLSearchParams({action:'hbbz_magnific_batch_status', nonce:ajaxNonce, post_id:String(postId)});
                try {
                    const data = await fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()}).then(parseJsonResponse);
                    const payload = data.data || {};
                    const statusValue = String(payload.status || 'UNKNOWN').toUpperCase();
                    if (Array.isArray(payload.images) && payload.images.length) {
                        updateBatchRow(postId, 'Bild fertig', 'Ergebnis ist sichtbar und kann ausgewählt werden.');
                        renderBatchImage(postId, payload.images[0], 0);
                        return 'completed';
                    }
                    if (['FAILED','ERROR','REMOTE_CHECK_FAILED','CANCELLED'].includes(statusValue)) {
                        updateBatchRow(postId, 'Fehler', payload.message || statusValue);
                        return 'failed';
                    }
                    updateBatchRow(postId, 'Wird erzeugt …', 'Magnific-Status: ' + statusValue + ' · Prüfung ' + (attempt + 1));
                    if (attempt + 1 >= maxAttempts) {
                        updateBatchRow(postId, 'Weiter in Bearbeitung', 'Automatische Prüfung beendet. Später erneut öffnen oder Status prüfen.');
                        return 'timeout';
                    }
                    await new Promise(resolve => setTimeout(resolve, 5000));
                    return checkBatchPost(postId, attempt + 1);
                } catch (error) {
                    updateBatchRow(postId, 'Prüffehler', error.message || 'Status konnte nicht gelesen werden. Neuer Versuch folgt.');
                    if (attempt + 1 >= maxAttempts) return 'failed';
                    await new Promise(resolve => setTimeout(resolve, 5000));
                    return checkBatchPost(postId, attempt + 1);
                }
            }

            document.addEventListener('click', function (event) {
                const button = event.target.closest('.hbbz-batch-image-import, .hbbz-batch-image-apply');
                if (!button) return;
                const postId = button.dataset.postId || '';
                const index = button.dataset.index || '0';
                const apply = button.classList.contains('hbbz-batch-image-apply');
                button.disabled = true;
                button.textContent = apply ? 'Wird übernommen …' : 'Wird importiert …';
                const body = new URLSearchParams({action: apply ? 'hbbz_magnific_batch_apply' : 'hbbz_magnific_batch_import', nonce:ajaxNonce, post_id:postId, index:index});
                fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()})
                    .then(parseJsonResponse)
                    .then(data => {
                        const payload = data.data || {};
                        updateBatchRow(postId, apply ? 'Als Beitragsbild gesetzt' : 'In Mediathek', payload.message || ('Medien-ID #' + (payload.attachment_id || '')));
                        button.textContent = apply ? 'Als Beitragsbild gesetzt' : 'In Mediathek vorhanden';
                    })
                    .catch(error => {
                        updateBatchRow(postId, 'Fehler', error.message);
                        button.disabled = false;
                        button.textContent = apply ? 'Als Beitragsbild übernehmen' : 'In Mediathek laden';
                    });
            });

            if (Array.isArray(existingMagnificBatch) && existingMagnificBatch.length) {
                renderBatchRows(existingMagnificBatch.map(function(item){ return {id:item.post_id, title:item.title}; }));
                const existingStatus = document.getElementById('hbbz-ai-batch-status');
                if (existingStatus) existingStatus.textContent = existingMagnificBatch.length + ' vorhandene KI-Aufträge/Ergebnisse werden angezeigt und automatisch geprüft.';
                existingMagnificBatch.forEach(function(item) {
                    if (Array.isArray(item.images) && item.images.length) {
                        updateBatchRow(item.post_id, 'Bild fertig', 'Ergebnis ist sichtbar und kann ausgewählt werden.');
                        renderBatchImage(item.post_id, item.images[0], 0);
                    } else {
                        updateBatchRow(item.post_id, 'Wird geprüft …', 'Vorhandener Auftrag wird automatisch nachverfolgt.');
                        checkBatchPost(item.post_id, 0);
                    }
                });
            }

            const selectVisibleButton = document.getElementById('hbbz-batch-select-visible');
            if (selectVisibleButton) {
                selectVisibleButton.addEventListener('click', function () {
                    document.querySelectorAll('.hbbz-queue-check').forEach(function (el) { el.checked = true; });
                });
            }
            const clearVisibleButton = document.getElementById('hbbz-batch-clear-visible');
            if (clearVisibleButton) {
                clearVisibleButton.addEventListener('click', function () {
                    document.querySelectorAll('.hbbz-queue-check').forEach(function (el) { el.checked = false; });
                });
            }

            const magnificBatchButton = document.getElementById('hbbz-magnific-batch-generate');
            if (magnificBatchButton) {
                magnificBatchButton.addEventListener('click', async function () {
                    const checkedBoxes = Array.from(document.querySelectorAll('.hbbz-queue-check:checked'));
                    const checked = checkedBoxes.map(el => el.value);
                    const status = document.getElementById('hbbz-ai-batch-status');
                    const parallel = Math.max(2, Math.min(5, parseInt((document.getElementById('hbbz-batch-concurrency') || {}).value || '3', 10) || 3));
                    if (!checked.length) { status.textContent = 'Bitte 1 bis 50 Beiträge markieren.'; return; }
                    if (checked.length > 50) { status.textContent = 'Bitte höchstens 50 Beiträge pro Sammellauf markieren.'; return; }
                    if (!window.confirm('Für ' + checked.length + ' Beiträge jeweils 1 KI-Bild erzeugen? Dies verbraucht Magnific-Credits. Der Sammellauf arbeitet parallel mit ' + parallel + ' Aufträgen.')) return;
                    const items = checkedBoxes.map(el => ({id: el.value, title: (el.closest('tr') && el.closest('tr').children[3]) ? el.closest('tr').children[3].textContent.trim() : ('Beitrag ' + el.value)}));
                    renderBatchRows(items);
                    magnificBatchButton.disabled = true;
                    let started = 0;
                    let failed = 0;
                    let finished = 0;
                    status.textContent = 'KI-Sammellauf startet … 0/' + checked.length;

                    async function runSingle(postId) {
                        updateBatchRow(postId, 'Startet …', 'KI-Auftrag wird angelegt');
                        const body = new URLSearchParams({action:'hbbz_magnific_single_generate', nonce:ajaxNonce, post_id: String(postId)});
                        try {
                            const data = await fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()}).then(parseJsonResponse);
                            const payload = data.data || {};
                            started++;
                            updateBatchRow(postId, 'Auftrag gestartet', 'Task ' + (payload.task_id || 'unbekannt') + ' · Ergebnis wird automatisch geprüft.');
                            checkBatchPost(postId, 0);
                        } catch (error) {
                            failed++;
                            updateBatchRow(postId, 'Fehler', error.message || 'Unbekannter Fehler');
                        } finally {
                            finished++;
                            status.textContent = 'KI-Sammellauf läuft … ' + finished + '/' + checked.length + ' abgeschlossen · ' + started + ' gestartet · ' + failed + ' Fehler';
                        }
                    }

                    const queue = checked.slice();
                    async function worker() {
                        while (queue.length) {
                            const next = queue.shift();
                            if (!next) break;
                            await runSingle(next);
                        }
                    }

                    const workerCount = Math.min(parallel, queue.length || 1);
                    await Promise.all(Array.from({length: workerCount}, () => worker()));
                    status.textContent = 'Alle Startaufträge wurden verarbeitet: ' + started + ' gestartet, ' + failed + ' Fehler. Die Bilder werden jetzt automatisch weiter geprüft und erscheinen direkt in der jeweiligen Zeile.';
                    magnificBatchButton.disabled = false;
                });
            }

            document.querySelectorAll('.hbbz-test').forEach(function (button) {
                button.addEventListener('click', function () {
                    const provider = button.dataset.provider;
                    const result = document.getElementById('hbbz-result-' + provider);
                    result.textContent = ' Prüfe …';
                    const body = new URLSearchParams({
                        action: 'hbbz_test_provider',
                        provider: provider,
                        nonce: ajaxNonce
                    });
                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                        body: body.toString()
                    })
                    .then(parseJsonResponse)
                    .then(data => {
                        result.textContent = data.success ? ' Verbindung erfolgreich.' : ' Fehler: ' + (data.data || 'Unbekannter Fehler');
                    })
                    .catch(() => { result.textContent = ' Fehler bei der Verbindung.'; });
                });
            });

            document.addEventListener('click', function (event) {
                const downloadButton = event.target.closest('#hbbz-download-selected');
                if (!downloadButton) {
                    return;
                }

                downloadButton.disabled = true;
                downloadButton.textContent = 'Download und Optimierung laufen …';
                const body = new URLSearchParams({
                    action: 'hbbz_download_selected',
                    nonce: ajaxNonce
                });
                fetch(ajaxurl, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                    body: body.toString()
                })
                .then(parseJsonResponse)
                .then(data => {
                    if (!data.success) {
                        throw new Error(data.data || 'Download fehlgeschlagen');
                    }
                    document.getElementById('hbbz-selection').innerHTML = '<strong>In Mediathek gespeichert.</strong> Medien-ID: ' + data.data.attachment_id + '.<br><button type="button" class="button button-primary" id="hbbz-assign-featured">Lizenzdaten prüfen und als Beitragsbild setzen</button>';
                })
                .catch(error => {
                    alert('Fehler: ' + error.message);
                    downloadButton.disabled = false;
                    downloadButton.textContent = 'Ausgewähltes Bild in die Mediathek laden';
                });
            });


            function showStockAssignmentStatus(ok, message) {
                const box = document.getElementById('hbbz-stock-assignment-status');
                if (!box) return;
                box.className = 'notice inline ' + (ok ? 'notice-success' : 'notice-error');
                box.style.display = 'block';
                const paragraph = box.querySelector('p');
                if (paragraph) paragraph.textContent = message;
            }

            document.addEventListener('click', function (event) {
                const assignButton = event.target.closest('#hbbz-assign-featured');
                if (!assignButton) return;
                assignButton.disabled = true;
                assignButton.textContent = 'Zuordnung läuft …';
                showStockAssignmentStatus(true, 'Zuordnung wird geprüft …');
                const body = new URLSearchParams({action: 'hbbz_assign_featured', nonce: ajaxNonce});
                fetch(ajaxurl, {method: 'POST', headers: {'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}, body:body.toString()})
                    .then(parseJsonResponse)
                    .then(data => {
                        const payload = data.data || {};
                        const already = Boolean(payload.already_assigned);
                        const message = already
                            ? 'Bereits zugeordnet: Medien-ID #' + payload.attachment_id + ' ist schon das Beitragsbild von Entwurf #' + payload.post_id + ' – ' + (payload.post_title || '') + '.'
                            : 'Geklappt: Medien-ID #' + payload.attachment_id + ' wurde als Beitragsbild dem Entwurf #' + payload.post_id + ' – ' + (payload.post_title || '') + ' zugeordnet.';
                        showStockAssignmentStatus(true, message);
                        document.getElementById('hbbz-selection').innerHTML = '<strong>Als Beitragsbild gesetzt.</strong> Medien-ID: ' + payload.attachment_id + '.<br><button type="button" class="button" id="hbbz-undo-featured">Beitragsbild-Zuordnung zurücknehmen</button>';
                    })
                    .catch(error => {
                        showStockAssignmentStatus(false, 'Nicht geklappt: ' + error.message);
                        assignButton.disabled = false;
                        assignButton.textContent = 'Lizenzdaten prüfen und als Beitragsbild setzen';
                    });
            });

            document.addEventListener('click', function (event) {
                const undoButton = event.target.closest('#hbbz-undo-featured');
                if (!undoButton) return;
                undoButton.disabled = true;
                undoButton.textContent = 'Rücknahme läuft …';
                const body = new URLSearchParams({action: 'hbbz_undo_featured', nonce: ajaxNonce});
                fetch(ajaxurl, {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}, body: body.toString()})
                    .then(parseJsonResponse)
                    .then(data => {
                        if (!data.success) throw new Error(data.data || 'Rücknahme fehlgeschlagen');
                        document.getElementById('hbbz-selection').innerHTML = '<strong>Beitragsbild-Zuordnung zurückgenommen.</strong> Das Bild bleibt in der Mediathek.<br><button type="button" class="button button-primary" id="hbbz-assign-featured">Erneut als Beitragsbild setzen</button>';
                    })
                    .catch(error => { alert('Fehler: ' + error.message); undoButton.disabled = false; undoButton.textContent = 'Beitragsbild-Zuordnung zurücknehmen'; });
            });

            document.addEventListener('click', function (event) {
                const button = event.target.closest('#hbbz-insert-content-image');
                if (!button) return;
                button.disabled = true;
                button.textContent = 'Inhaltsbild wird eingesetzt …';
                const headingSelect = document.getElementById('hbbz-content-heading-index');
                const headingIndex = headingSelect ? headingSelect.value : '0';
                const body = new URLSearchParams({action: 'hbbz_insert_content_image', nonce: ajaxNonce, heading_index: headingIndex});
                fetch(ajaxurl, {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}, body: body.toString()})
                    .then(parseJsonResponse)
                    .then(data => { if (!data.success) throw new Error(data.data || 'Einsetzen fehlgeschlagen'); location.reload(); })
                    .catch(error => { alert('Fehler: ' + error.message); button.disabled = false; button.textContent = 'Als Inhaltsbild an gewählter Stelle einsetzen'; });
            });

            document.addEventListener('click', function (event) {
                const button = event.target.closest('#hbbz-undo-content-image');
                if (!button) return;
                button.disabled = true;
                button.textContent = 'Inhaltsbild wird entfernt …';
                const body = new URLSearchParams({action: 'hbbz_undo_content_image', nonce: ajaxNonce});
                fetch(ajaxurl, {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}, body: body.toString()})
                    .then(parseJsonResponse)
                    .then(data => { if (!data.success) throw new Error(data.data || 'Entfernen fehlgeschlagen'); location.reload(); })
                    .catch(error => { alert('Fehler: ' + error.message); button.disabled = false; button.textContent = 'Inhaltsbild wieder entfernen'; });
            });

            const batchButton = document.getElementById('hbbz-batch-preview');
            if (batchButton) {
                batchButton.addEventListener('click', function () {
                    const checked = Array.from(document.querySelectorAll('.hbbz-queue-check:checked')).map(el => el.value);
                    const status = document.getElementById('hbbz-stock-batch-status');
                    const results = document.getElementById('hbbz-stock-batch-results');
                    if (checked.length < 1 || checked.length > 10) {
                        status.textContent = 'Bitte 1 bis 10 Beiträge markieren.';
                        return;
                    }
                    batchButton.disabled = true;
                    status.textContent = 'Sammelvorschau wird vorbereitet …';
                    results.innerHTML = '';
                    const body = new URLSearchParams({action: 'hbbz_batch_preview', nonce: ajaxNonce});
                    checked.forEach(id => body.append('post_ids[]', id));
                    fetch(ajaxurl, {method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}, body: body.toString()})
                        .then(parseJsonResponse)
                        .then(data => {
                            if (!data.success) throw new Error(data.data || 'Sammelvorschau fehlgeschlagen');
                            status.textContent = 'Sammelvorschau geladen. Noch nichts wurde heruntergeladen.';
                            const table = document.createElement('table');
                            table.className = 'widefat striped';
                            table.innerHTML = '<thead><tr><th>Beitrag</th><th>Suchbegriff</th><th>Pixabay</th><th>Pexels</th></tr></thead><tbody></tbody>';
                            const tbody = table.querySelector('tbody');
                            data.data.items.forEach(item => {
                                const tr = document.createElement('tr');
                                const previewCell = (list, provider) => list.length ? list.slice(0,2).map((img, idx) => {
                                    const payload = encodeURIComponent(JSON.stringify({post_id:item.post_id,provider:provider,image_id:String(img.image_id||''),preview_url:img.preview_url,page_url:img.page_url,photographer:img.photographer,photographer_url:img.photographer_url,width:Number(img.width||0),height:Number(img.height||0)}));
                                    return '<label style="display:inline-block;margin-right:8px;text-align:center"><img src="'+img.preview_url+'" alt="" style="width:120px;height:70px;object-fit:cover;display:block"><input type="radio" name="hbbz_batch_'+item.post_id+'" class="hbbz-batch-choice" value="'+payload+'"> auswählen</label>';
                                }).join('') : 'Keine Treffer';
                                tr.innerHTML = '<td>#'+item.post_id+' – '+item.title+'</td><td>'+item.query+'</td><td>'+previewCell(item.pixabay,'pixabay')+'</td><td>'+previewCell(item.pexels,'pexels')+'</td>';
                                tbody.appendChild(tr);
                            });
                            results.appendChild(table);
                            const applyButton = document.getElementById('hbbz-batch-apply');
                            if (applyButton) applyButton.style.display = '';
                        })
                        .catch(error => { status.textContent = 'Fehler: ' + error.message; })
                        .finally(() => { batchButton.disabled = false; });
                });
            }


            const batchApplyButton = document.getElementById('hbbz-batch-apply');
            if (batchApplyButton) {
                batchApplyButton.addEventListener('click', function () {
                    const status = document.getElementById('hbbz-stock-batch-status');
                    const selected = Array.from(document.querySelectorAll('.hbbz-batch-choice:checked')).map(el => JSON.parse(decodeURIComponent(el.value)));
                    if (selected.length < 1 || selected.length > 10) {
                        status.textContent = 'Bitte für 1 bis 10 Beiträge jeweils genau ein Bild auswählen.';
                        return;
                    }
                    batchApplyButton.disabled = true;
                    status.textContent = 'Download, Optimierung, Lizenzspeicherung und Zuordnung laufen …';
                    const body = new URLSearchParams({action:'hbbz_batch_apply', nonce:ajaxNonce, selections:JSON.stringify(selected)});
                    fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()})
                        .then(parseJsonResponse)
                        .then(data => {
                            if (!data.success) throw new Error(data.data || 'Sammelübernahme fehlgeschlagen');
                            status.textContent = data.data.success_count + ' Beitragsbilder erfolgreich übernommen.' + (data.data.errors.length ? ' Fehler: ' + data.data.errors.join(' | ') : '');
                        })
                        .catch(error => { status.textContent = 'Fehler: ' + error.message; })
                        .finally(() => { batchApplyButton.disabled = false; });
                });
            }

            const searchButton = document.getElementById('hbbz-search');
            if (searchButton) {
                searchButton.addEventListener('click', function () {
                    const status = document.getElementById('hbbz-search-status');
                    const results = document.getElementById('hbbz-search-results');
                    const query = document.getElementById('hbbz-search-direction').value;
                    status.textContent = 'Suche läuft …';
                    results.innerHTML = '';
                    searchButton.disabled = true;

                    const body = new URLSearchParams({
                        action: 'hbbz_search_images',
                        query: query,
                        nonce: ajaxNonce
                    });

                    fetch(ajaxurl, {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                        body: body.toString()
                    })
                    .then(parseJsonResponse)
                    .then(data => {
                        if (!data.success) {
                            throw new Error(data.data || 'Unbekannter Fehler');
                        }
                        status.textContent = 'Vorschläge geladen. Noch nichts wurde heruntergeladen.';
                        renderProvider(results, 'Pixabay', 'pixabay', data.data.pixabay || []);
                        renderProvider(results, 'Pexels', 'pexels', data.data.pexels || []);
                    })
                    .catch(error => {
                        status.textContent = 'Fehler: ' + error.message;
                    })
                    .finally(() => {
                        searchButton.disabled = false;
                    });
                });
            }

            function renderProvider(container, title, provider, items) {
                const heading = document.createElement('h3');
                heading.className = 'hbbz-provider-title';
                heading.textContent = title + ' – ' + items.length + ' Vorschläge';
                container.appendChild(heading);

                const grid = document.createElement('div');
                grid.className = 'hbbz-grid';

                if (!items.length) {
                    const empty = document.createElement('p');
                    empty.textContent = 'Keine Vorschläge gefunden.';
                    grid.appendChild(empty);
                }

                items.forEach(function (item) {
                    const card = document.createElement('div');
                    card.className = 'hbbz-card';

                    const imageLink = document.createElement('a');
                    imageLink.href = item.page_url;
                    imageLink.target = '_blank';
                    imageLink.rel = 'noopener noreferrer';

                    const image = document.createElement('img');
                    image.src = item.preview_url;
                    image.alt = '';
                    image.loading = 'lazy';
                    imageLink.appendChild(image);
                    card.appendChild(imageLink);

                    const meta = document.createElement('p');
                    meta.textContent = item.width + ' × ' + item.height;
                    card.appendChild(meta);

                    const quality = document.createElement('p');
                    const accepted = Boolean(item.quality && item.quality.accepted);
                    quality.innerHTML = '<strong>' + (accepted ? 'Geeignet' : 'Nicht empfohlen') + '</strong>' +
                        (item.quality && item.quality.reason ? '<br><small>' + item.quality.reason + '</small>' : '');
                    card.appendChild(quality);

                    const credit = document.createElement('p');
                    credit.appendChild(document.createTextNode('Foto: '));
                    const creditLink = document.createElement('a');
                    creditLink.href = item.photographer_url;
                    creditLink.target = '_blank';
                    creditLink.rel = 'noopener noreferrer';
                    creditLink.textContent = item.photographer;
                    credit.appendChild(creditLink);
                    card.appendChild(credit);

                    const source = document.createElement('p');
                    const sourceLink = document.createElement('a');
                    sourceLink.href = item.page_url;
                    sourceLink.target = '_blank';
                    sourceLink.rel = 'noopener noreferrer';
                    sourceLink.textContent = 'Quelle bei ' + title + ' öffnen';
                    source.appendChild(sourceLink);
                    card.appendChild(source);

                    const selectButton = document.createElement('button');
                    selectButton.type = 'button';
                    selectButton.className = 'button button-primary hbbz-select';
                    selectButton.textContent = (item.quality && item.quality.accepted) ? 'Dieses Bild auswählen' : 'Nicht auswählbar';
                    selectButton.disabled = !(item.quality && item.quality.accepted);
                    selectButton.addEventListener('click', function () {
                        selectButton.disabled = true;
                        const body = new URLSearchParams({
                            action: 'hbbz_select_image',
                            nonce: ajaxNonce,
                            provider: provider,
                            image_id: String(item.image_id || ''),
                            preview_url: item.preview_url,
                            page_url: item.page_url,
                            photographer: item.photographer,
                            photographer_url: item.photographer_url,
                            width: String(item.width || 0),
                            height: String(item.height || 0)
                        });
                        fetch(ajaxurl, {
                            method: 'POST',
                            headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                            body: body.toString()
                        })
                        .then(parseJsonResponse)
                        .then(data => {
                            if (!data.success) {
                                throw new Error(data.data || 'Auswahl fehlgeschlagen');
                            }
                            document.getElementById('hbbz-selection').innerHTML = '<strong>Ausgewählt:</strong> ' + title + ' – ' + item.photographer + '. Noch nicht heruntergeladen.<br><button type="button" class="button button-primary" id="hbbz-download-selected">Ausgewähltes Bild in die Mediathek laden</button>';
                        })
                        .catch(error => {
                            alert('Fehler: ' + error.message);
                        })
                        .finally(() => {
                            selectButton.disabled = false;
                        });
                    });
                    card.appendChild(selectButton);

                    grid.appendChild(card);
                });

                container.appendChild(grid);
            }
        });
        </script>
        <?php
    }

    private static function redirect_to_tab(array $args, string $default_tab = 'posts'): void {
        $requested = isset($_POST['hbbz_return_tab']) ? sanitize_key((string) wp_unslash($_POST['hbbz_return_tab'])) : $default_tab;
        $allowed = ['posts', 'wp', 'hp', 'admin'];
        $tab = in_array($requested, $allowed, true) ? $requested : $default_tab;
        $profile_key = isset($args['prompt_profile']) ? sanitize_key((string) $args['prompt_profile']) : '';
        $anchor = in_array($profile_key, ['article', 'category', 'hivepress'], true) ? 'hbbz-profile-' . $profile_key : 'hbbz-' . $tab;
        $url = add_query_arg(array_merge(['page' => 'hab-und-bewahr-bildzentrale', 'hbbz_tab' => $tab], $args), admin_url('admin.php'));
        wp_safe_redirect($url . '#' . $anchor);
        exit;
    }

    public static function save_settings(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Nicht erlaubt.');
        }
        check_admin_referer(self::NONCE_ACTION);

        $pixabay = isset($_POST['hbbz_pixabay_api_key']) ? sanitize_text_field(wp_unslash($_POST['hbbz_pixabay_api_key'])) : '';
        $pexels  = isset($_POST['hbbz_pexels_api_key']) ? sanitize_text_field(wp_unslash($_POST['hbbz_pexels_api_key'])) : '';
        $magnific_api_key = isset($_POST['hbbz_magnific_api_key']) ? sanitize_text_field(wp_unslash($_POST['hbbz_magnific_api_key'])) : '';
        $magnific_webhook_secret = isset($_POST['hbbz_magnific_webhook_secret']) ? sanitize_text_field(wp_unslash($_POST['hbbz_magnific_webhook_secret'])) : '';
        $magnific_style = isset($_POST['hbbz_magnific_style_guide']) ? sanitize_textarea_field(wp_unslash($_POST['hbbz_magnific_style_guide'])) : (string) get_option(self::OPTION_MAGNIFIC_STYLE, self::default_magnific_style());
        $exclusions = isset($_POST['hbbz_exclusion_terms']) ? sanitize_textarea_field(wp_unslash($_POST['hbbz_exclusion_terms'])) : (string) get_option(self::OPTION_EXCLUSIONS, 'logo, brand, text, watermark, collage, split image, duplicate objects, malformed hands, deformed anatomy, misleading equipment, unsafe depiction, abstract symbol, fantasy creature');

        update_option(self::OPTION_PIXABAY, $pixabay, false);
        update_option(self::OPTION_PEXELS, $pexels, false);
        update_option(self::OPTION_MAGNIFIC_API_KEY, $magnific_api_key, false);
        update_option(self::OPTION_MAGNIFIC_WEBHOOK_SECRET, $magnific_webhook_secret, false);
        update_option(self::OPTION_MAGNIFIC_STYLE, $magnific_style, false);
        update_option(self::OPTION_EXCLUSIONS, $exclusions, false);
        $profiles = self::general_profiles();
        $profiles['article']['base_prompt'] = $magnific_style;
        $profiles['article']['negative_prompt'] = $exclusions;
        update_option(self::OPTION_GENERAL_PROFILES, $profiles, false);

        self::redirect_to_tab(['updated' => '1'], 'admin');
    }
    private static function default_general_profiles(): array {
        $article_style = (string) get_option(self::OPTION_MAGNIFIC_STYLE, self::default_magnific_style());
        $exclusions = (string) get_option(self::OPTION_EXCLUSIONS, 'logo, brand, text, watermark, collage, split image, duplicate objects, malformed hands, deformed anatomy, misleading equipment, unsafe depiction, abstract symbol, fantasy creature');
        return [
            'article' => [
                'label' => 'Beitragsbilder',
                'base_prompt' => $article_style,
                'negative_prompt' => $exclusions,
                'color_direction' => 'Natural sage-grey and neutral colors, realistic materials, restrained editorial light, no artificial security imagery.',
                'subject_rule' => 'Read the complete title and the actual article. Show the specific protected object and credible preventative measure or described damage; if a human action is necessary show one relevant adult at work, otherwise show no person. Never replace the subject with a generic alarm, shield or padlock icon.',
                'ratio' => '3:2', 'output_width' => 1500, 'output_height' => 1000, 'webp_quality' => 82, 'target_kb' => 350,
            ],
            'category' => [
                'label' => 'WordPress-Kategorien',
                'base_prompt' => 'Photorealistic editorial image of exactly the named property protection category. Show the real object, installation or location in a credible safe scene. One clear motif readable at thumbnail scale, crop-safe center, no signs, brands, collage, or writing.',
                'negative_prompt' => $exclusions,
                'color_direction' => 'Balanced natural colors with a calm, coherent and slightly more iconic category appearance than article photography.',
                'subject_rule' => 'Use the complete full category path and its hazard/object context, not a single generic risk word. Show one specific private-property scene, no visual imitation of safety certification.',
                'ratio' => '3:1', 'output_width' => 1200, 'output_height' => 400, 'webp_quality' => 76, 'target_kb' => 120,
            ],
            'post_type_hero' => [
                'label' => 'Post-Type-Hero',
                'base_prompt' => 'Photorealistic editorial hero for the specified home, property or security scenario. Use the complete real subject and credible installation or setting. Wide crop-safe framing, generous safe space at both sides, calm neutral light, no staged danger, collage, lettering or logo.',
                'negative_prompt' => $exclusions . ', cropped main subject, cut off essential parts, subject touching frame edge, extreme close-up, headshot-only framing, extreme perspective',
                'color_direction' => 'Calm sage-grey and neutral editorial photography consistent with Hab & Bewahr.',
                'subject_rule' => 'Show the exact protected object, location and relevant security scenario from this page, not a decorative substitute. Maintain visual consistency between the category tile and hero.',
                'ratio' => '21:9', 'output_width' => 1260, 'output_height' => 540, 'webp_quality' => 78, 'target_kb' => 180,
            ],
            'hivepress' => [
                'label' => 'HivePress-Kategorien',
                'base_prompt' => 'Photorealistic trustworthy service photograph for a small-scale property protection provider such as a locksmith, glass repair firm, storm damage service or security technician. One credible specialist at work if relevant, no brands, logo, staged crime, collage or lettering. Crop-safe composition.',
                'negative_prompt' => $exclusions,
                'color_direction' => 'Visibly distinct from editorial article images: slightly cooler, clearer and more structured color rendering while remaining natural and consistent across all marketplace categories.',
                'subject_rule' => 'Show the precise actual security or maintenance service in an authentic small private or owner-managed business context, not an unrelated commercial motif.',
                'ratio' => '3:1', 'output_width' => 1200, 'output_height' => 400, 'webp_quality' => 76, 'target_kb' => 120,
            ],
        ];
    }

    private static function maybe_upgrade_generalization(): void {
        $version = (string) get_option(self::OPTION_GENERAL_SCHEMA, '');
        if ($version === '4') return;
        if (get_option(self::OPTION_PRE_GENERAL_BACKUP, null) === null) {
            update_option(self::OPTION_PRE_GENERAL_BACKUP, self::settings_export_payload(), false);
        }
        if (get_option(self::OPTION_GENERAL_PROFILES, null) === null) {
            update_option(self::OPTION_GENERAL_PROFILES, self::default_general_profiles(), false);
        }
        $profiles = get_option(self::OPTION_GENERAL_PROFILES, []);
        if (!is_array($profiles)) { $profiles = []; }
        $defaults = self::default_general_profiles();
        $profiles['post_type_hero'] = $defaults['post_type_hero'];
        update_option(self::OPTION_GENERAL_PROFILES, $profiles, false);
        if (get_option(self::OPTION_TAXONOMY_CONFIG, null) === null) {
            update_option(self::OPTION_TAXONOMY_CONFIG, [
                'wordpress_taxonomy' => 'category',
                'wordpress_image_meta_key' => 'thumbnail_id',
                'hero_post_type' => '',
                'hivepress_taxonomy' => 'hp_listing_category',
                'hivepress_image_meta_key' => 'thumbnail_id',
            ], false);
        }
        update_option(self::OPTION_GENERAL_SCHEMA, '4', false);
    }

    private static function general_profiles(): array {
        $defaults = self::default_general_profiles();
        $stored = get_option(self::OPTION_GENERAL_PROFILES, []);
        if (!is_array($stored)) return $defaults;
        foreach ($defaults as $key => $profile) {
            $stored[$key] = array_merge($profile, is_array($stored[$key] ?? null) ? $stored[$key] : []);
        }
        return $stored;
    }

    private static function settings_export_payload(): array {
        return [
            'format' => 'hbbz-settings-export-v1',
            'exported_at_utc' => gmdate('c'),
            'site_url' => function_exists('home_url') ? home_url('/') : '',
            'plugin_version' => '1.0.0',
            'connections' => [
                'pixabay_api_key' => (string) get_option(self::OPTION_PIXABAY, ''),
                'pexels_api_key' => (string) get_option(self::OPTION_PEXELS, ''),
                'magnific_api_key' => (string) get_option(self::OPTION_MAGNIFIC_API_KEY, ''),
                'magnific_webhook_secret' => (string) get_option(self::OPTION_MAGNIFIC_WEBHOOK_SECRET, ''),
            ],
            'legacy_article_settings' => [
                'magnific_style_guide' => (string) get_option(self::OPTION_MAGNIFIC_STYLE, self::default_magnific_style()),
                'exclusion_terms' => (string) get_option(self::OPTION_EXCLUSIONS, ''),
                'prompt_rules_version' => (string) get_option(self::OPTION_PROMPT_RULES_VERSION, ''),
            ],
            'profiles' => self::general_profiles(),
            'taxonomy_config' => self::sanitize_taxonomy_config((array)get_option(self::OPTION_TAXONOMY_CONFIG, [])),
        ];
    }

    public static function export_settings(): void {
        if (!current_user_can('manage_options')) wp_die('Nicht erlaubt.');
        check_admin_referer('hbbz_export_settings');
        $json = wp_json_encode(self::settings_export_payload(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="bildzentrale-einstellungen-' . gmdate('Y-m-d-His') . '.json"');
        echo $json;
        exit;
    }

    public static function import_settings(): void {
        if (!current_user_can('manage_options')) wp_die('Nicht erlaubt.');
        check_admin_referer('hbbz_import_settings');
        if (empty($_FILES['hbbz_settings_file']['tmp_name']) || !is_uploaded_file($_FILES['hbbz_settings_file']['tmp_name'])) wp_die('Keine Importdatei empfangen.');
        $raw = file_get_contents($_FILES['hbbz_settings_file']['tmp_name']);
        $data = json_decode((string) $raw, true);
        if (!is_array($data) || ($data['format'] ?? '') !== 'hbbz-settings-export-v1') wp_die('Ungültiges Einstellungsformat.');
        update_option('hbbz_before_import_backup_' . gmdate('Ymd_His'), self::settings_export_payload(), false);
        $replace = !empty($_POST['replace_existing']);
        $write = static function(string $option, $value) use ($replace): void {
            $current = get_option($option, null);
            if ($replace || $current === null || $current === '' || $current === []) update_option($option, $value, false);
        };
        $connections = is_array($data['connections'] ?? null) ? $data['connections'] : [];
        $write(self::OPTION_PIXABAY, sanitize_text_field((string)($connections['pixabay_api_key'] ?? '')));
        $write(self::OPTION_PEXELS, sanitize_text_field((string)($connections['pexels_api_key'] ?? '')));
        $write(self::OPTION_MAGNIFIC_API_KEY, sanitize_text_field((string)($connections['magnific_api_key'] ?? '')));
        $write(self::OPTION_MAGNIFIC_WEBHOOK_SECRET, sanitize_text_field((string)($connections['magnific_webhook_secret'] ?? '')));
        $legacy = is_array($data['legacy_article_settings'] ?? null) ? $data['legacy_article_settings'] : [];
        $write(self::OPTION_MAGNIFIC_STYLE, sanitize_textarea_field((string)($legacy['magnific_style_guide'] ?? '')));
        $write(self::OPTION_EXCLUSIONS, sanitize_textarea_field((string)($legacy['exclusion_terms'] ?? '')));
        if (is_array($data['profiles'] ?? null)) $write(self::OPTION_GENERAL_PROFILES, self::sanitize_profiles($data['profiles']));
        if (is_array($data['taxonomy_config'] ?? null)) $write(self::OPTION_TAXONOMY_CONFIG, self::sanitize_taxonomy_config($data['taxonomy_config']));
        self::redirect_to_tab(['imported' => '1'], 'admin');
    }

    private static function image_format_presets(): array {
        return [
            '3:2' => ['label'=>'3:2 – Beitragsbild','width'=>1500,'height'=>1000],
            '16:9' => ['label'=>'16:9 – breites Standardbild','width'=>1280,'height'=>720],
            '21:9' => ['label'=>'21:9 – ultrabreites Hero ohne Nachschnitt','width'=>1260,'height'=>540],
            '3:1' => ['label'=>'3:1 – sehr breites Kategorie-/Seitenbild','width'=>1200,'height'=>400],
            '1:1' => ['label'=>'1:1 – quadratisch','width'=>1000,'height'=>1000],
            '4:3' => ['label'=>'4:3 – klassisch','width'=>1200,'height'=>900],
        ];
    }

    private static function infer_format_preset(array $profile): string {
        $ratio=(string)($profile['ratio']??'');$width=absint($profile['output_width']??0);$height=absint($profile['output_height']??0);$stored=(string)($profile['format_preset']??'');
        $presets=self::image_format_presets();
        // Reale Pixelmaße sind die stärkste Quelle. Damit wird ein historisch
        // widersprüchlicher Stand wie 3:2 + 1200x400 korrekt als 3:1 erkannt.
        foreach($presets as $key=>$preset){if($width===(int)$preset['width'] && $height===(int)$preset['height'])return $key;}
        if(isset($presets[$stored]))return $stored;
        if(isset($presets[$ratio]))return $ratio;
        return '3:1';
    }

    private static function sanitize_base_prompt(string $prompt): string {
        $prompt = str_replace(["\r\n", "\r"], "\n", $prompt);
        $prompt = wp_check_invalid_utf8($prompt);
        if ($prompt === '') return '';
        $prompt = wp_kses_no_null($prompt);
        return trim($prompt);
    }

    private static function prompt_character_length(string $prompt): int {
        if (function_exists('mb_strlen')) return (int) self::utf8_len($prompt, 'UTF-8');
        $count = preg_match_all('/./us', $prompt, $matches);
        return $count === false ? strlen($prompt) : (int) $count;
    }

    private static function prompt_fingerprint(string $prompt): array {
        return [
            'characters' => self::prompt_character_length($prompt),
            'bytes' => strlen($prompt),
            'sha256' => hash('sha256', $prompt),
        ];
    }

    private static function prompt_fingerprints_match(string $expected, string $actual): bool {
        return self::prompt_fingerprint($expected) === self::prompt_fingerprint($actual);
    }

    private static function flush_option_read_cache(array $option_names): void {
        if (!function_exists('wp_cache_delete')) return;
        foreach ($option_names as $option_name) {
            wp_cache_delete((string)$option_name, 'options');
        }
        wp_cache_delete('alloptions', 'options');
        wp_cache_delete('notoptions', 'options');
    }

    private static function create_profile_save_receipt(string $profile_key, string $prompt): array {
        return [
            'token' => wp_generate_password(32, false, false),
            'profile' => sanitize_key($profile_key),
            'fingerprint' => self::prompt_fingerprint($prompt),
            'saved_at_utc' => gmdate('c'),
        ];
    }

    private static function profile_save_receipt_matches(array $expected, $actual): bool {
        if (!is_array($actual)) return false;
        return hash_equals((string)($expected['token'] ?? ''), (string)($actual['token'] ?? ''))
            && (string)($expected['profile'] ?? '') === (string)($actual['profile'] ?? '')
            && (array)($expected['fingerprint'] ?? []) === (array)($actual['fingerprint'] ?? []);
    }

    private static function verify_profile_save_receipt_from_request(): array {
        $token = isset($_GET['save_token']) ? sanitize_text_field((string) wp_unslash($_GET['save_token'])) : '';
        $profile_key = isset($_GET['prompt_profile']) ? sanitize_key((string) wp_unslash($_GET['prompt_profile'])) : '';
        self::flush_option_read_cache([self::OPTION_LAST_PROFILE_SAVE_RECEIPT, self::OPTION_GENERAL_PROFILES]);
        $receipt = get_option(self::OPTION_LAST_PROFILE_SAVE_RECEIPT, null);
        if ($token === '' || $profile_key === '' || !is_array($receipt)) {
            return ['ok'=>false, 'code'=>'receipt_missing', 'characters'=>0, 'sha256'=>''];
        }
        if (!hash_equals((string)($receipt['token'] ?? ''), $token) || (string)($receipt['profile'] ?? '') !== $profile_key) {
            return ['ok'=>false, 'code'=>'receipt_mismatch', 'characters'=>0, 'sha256'=>''];
        }
        $stored_profiles = get_option(self::OPTION_GENERAL_PROFILES, null);
        $stored_prompt = is_array($stored_profiles) ? (string)($stored_profiles[$profile_key]['base_prompt'] ?? '') : '';
        $actual = self::prompt_fingerprint($stored_prompt);
        $expected = (array)($receipt['fingerprint'] ?? []);
        $query_characters = isset($_GET['prompt_chars']) ? absint($_GET['prompt_chars']) : 0;
        $ok = $stored_prompt !== '' && $expected === $actual && $query_characters === (int)($actual['characters'] ?? -1);
        return [
            'ok'=>$ok,
            'code'=>$ok ? 'ok' : 'fresh_readback_failed',
            'characters'=>(int)($actual['characters'] ?? 0),
            'sha256'=>(string)($actual['sha256'] ?? ''),
        ];
    }

    private static function sanitize_profiles(array $profiles): array {
        $defaults = self::default_general_profiles();
        $clean = [];
        foreach ($defaults as $key => $default) {
            $input = is_array($profiles[$key] ?? null) ? $profiles[$key] : [];
            $presets=self::image_format_presets();
            $preset_key=(string)($input['format_preset']??self::infer_format_preset(array_merge($default,$input)));
            if(!isset($presets[$preset_key]))$preset_key=self::infer_format_preset($default);
            $preset=$presets[$preset_key];
            $clean[$key] = [
                'label' => sanitize_text_field((string)($input['label'] ?? $default['label'])),
                'base_prompt' => self::sanitize_base_prompt((string)($input['base_prompt'] ?? $default['base_prompt'])),
                'negative_prompt' => sanitize_textarea_field((string)($input['negative_prompt'] ?? $default['negative_prompt'])),
                'color_direction' => sanitize_textarea_field((string)($input['color_direction'] ?? $default['color_direction'])),
                'subject_rule' => sanitize_textarea_field((string)($input['subject_rule'] ?? $default['subject_rule'])),
                'format_preset' => $preset_key,
                'ratio' => $preset_key,
                'output_width' => (int)$preset['width'],
                'output_height' => (int)$preset['height'],
                'webp_quality' => max(50, min(90, absint($input['webp_quality'] ?? $default['webp_quality']))),
                'target_kb' => max(40, min(500, absint($input['target_kb'] ?? $default['target_kb']))),
            ];
        }
        return $clean;
    }

    private static function sanitize_taxonomy_config(array $config): array {
        return [
            'wordpress_taxonomy' => sanitize_key((string)($config['wordpress_taxonomy'] ?? 'category')),
            'wordpress_image_meta_key' => sanitize_key((string)($config['wordpress_image_meta_key'] ?? 'thumbnail_id')),
            'hero_post_type' => sanitize_key((string)($config['hero_post_type'] ?? '')),
            'hivepress_taxonomy' => sanitize_key((string)($config['hivepress_taxonomy'] ?? '')),
            'hivepress_image_meta_key' => sanitize_key((string)($config['hivepress_image_meta_key'] ?? '')),
        ];
    }

    
public static function save_general_profiles(): void {
        if (!current_user_can('manage_options')) wp_die('Nicht erlaubt.');
        check_admin_referer('hbbz_save_general_profiles');
        $return_tab = sanitize_key((string)($_POST['hbbz_return_tab'] ?? 'posts'));
        if (!in_array($return_tab, ['posts','wp','cpt','hp','admin'], true)) $return_tab = 'posts';

        $incoming_profiles = isset($_POST['profiles']) && is_array($_POST['profiles']) ? wp_unslash($_POST['profiles']) : [];
        $incoming_config = isset($_POST['taxonomy_config']) && is_array($_POST['taxonomy_config']) ? wp_unslash($_POST['taxonomy_config']) : [];
        $defaults = self::default_general_profiles();
        $submitted_profile_keys = [];

        foreach ($incoming_profiles as $profile_key => $profile_input) {
            if (!isset($defaults[$profile_key]) || !is_array($profile_input)) {
                self::redirect_to_tab(['profiles_error' => 'invalid_profile'], $return_tab);
            }
            if (!array_key_exists('base_prompt', $profile_input)) {
                self::redirect_to_tab(['profiles_error' => 'missing_prompt', 'prompt_profile' => sanitize_key((string)$profile_key)], $return_tab);
            }
            if (!is_string($profile_input['base_prompt'])) {
                self::redirect_to_tab(['profiles_error' => 'invalid_prompt', 'prompt_profile' => sanitize_key((string)$profile_key)], $return_tab);
            }
            $base_prompt = self::sanitize_base_prompt($profile_input['base_prompt']);
            if ($base_prompt === '') {
                self::redirect_to_tab(['profiles_error' => 'empty_prompt', 'prompt_profile' => sanitize_key((string)$profile_key)], $return_tab);
            }
            $fingerprint = self::prompt_fingerprint($base_prompt);
            if ($fingerprint['characters'] > self::MAX_BASE_PROMPT_CHARS || $fingerprint['bytes'] > self::MAX_BASE_PROMPT_BYTES) {
                self::redirect_to_tab(['profiles_error' => 'prompt_too_long', 'prompt_profile' => sanitize_key((string)$profile_key)], $return_tab);
            }
            $incoming_profiles[$profile_key]['base_prompt'] = $base_prompt;
            $submitted_profile_keys[] = (string)$profile_key;
        }

        if ($submitted_profile_keys === []) {
            self::redirect_to_tab(['profiles_error' => 'missing_prompt'], $return_tab);
        }

        $current_profiles = (array) get_option(self::OPTION_GENERAL_PROFILES, $defaults);
        $current_config = (array) get_option(self::OPTION_TAXONOMY_CONFIG, self::sanitize_taxonomy_config([]));
        $current_style = (string) get_option(self::OPTION_MAGNIFIC_STYLE, self::default_magnific_style());
        $current_exclusions = (string) get_option(self::OPTION_EXCLUSIONS, '');
        $current_receipt = get_option(self::OPTION_LAST_PROFILE_SAVE_RECEIPT, null);
        $backup_key = 'hbbz_before_profile_save_backup_' . gmdate('Ymd_His') . '_' . wp_generate_password(6, false, false);
        update_option($backup_key, self::settings_export_payload(), false);

        $merged_profiles = array_replace_recursive($defaults, $current_profiles, $incoming_profiles);
        $merged_config = array_merge(self::sanitize_taxonomy_config([]), $current_config, $incoming_config);
        $clean_profiles = self::sanitize_profiles($merged_profiles);
        $clean_config = self::sanitize_taxonomy_config($merged_config);
        $clean_style = (string)$clean_profiles['article']['base_prompt'];
        $clean_exclusions = (string)$clean_profiles['article']['negative_prompt'];

        foreach ($submitted_profile_keys as $profile_key) {
            $expected_prompt = (string)$incoming_profiles[$profile_key]['base_prompt'];
            $clean_prompt = (string)($clean_profiles[$profile_key]['base_prompt'] ?? '');
            if ($clean_prompt === '' || !self::prompt_fingerprints_match($expected_prompt, $clean_prompt)) {
                self::redirect_to_tab(['profiles_error' => 'prompt_validation_failed', 'prompt_profile' => sanitize_key($profile_key)], $return_tab);
            }
        }

        update_option(self::OPTION_GENERAL_PROFILES, $clean_profiles, false);
        update_option(self::OPTION_TAXONOMY_CONFIG, $clean_config, false);
        // Keep the proven article workflow synchronized with the article profile.
        update_option(self::OPTION_MAGNIFIC_STYLE, $clean_style, false);
        update_option(self::OPTION_EXCLUSIONS, $clean_exclusions, false);

        self::flush_option_read_cache([
            self::OPTION_GENERAL_PROFILES,
            self::OPTION_TAXONOMY_CONFIG,
            self::OPTION_MAGNIFIC_STYLE,
            self::OPTION_EXCLUSIONS,
        ]);
        $stored_profiles = get_option(self::OPTION_GENERAL_PROFILES, null);
        $stored_config = get_option(self::OPTION_TAXONOMY_CONFIG, null);
        $stored_style = (string) get_option(self::OPTION_MAGNIFIC_STYLE, '');
        $stored_exclusions = (string) get_option(self::OPTION_EXCLUSIONS, '');
        $readback_ok = is_array($stored_profiles)
            && is_array($stored_config)
            && self::sanitize_taxonomy_config($stored_config) === $clean_config
            && self::prompt_fingerprints_match($clean_style, $stored_style)
            && $clean_exclusions === $stored_exclusions;

        if ($readback_ok) {
            foreach ($submitted_profile_keys as $profile_key) {
                $expected_prompt = (string)$clean_profiles[$profile_key]['base_prompt'];
                $actual_prompt = (string)($stored_profiles[$profile_key]['base_prompt'] ?? '');
                if ($actual_prompt === '' || !self::prompt_fingerprints_match($expected_prompt, $actual_prompt)) {
                    $readback_ok = false;
                    break;
                }
            }
        }

        $rollback = static function() use ($current_profiles, $current_config, $current_style, $current_exclusions, $current_receipt): void {
            update_option(self::OPTION_GENERAL_PROFILES, $current_profiles, false);
            update_option(self::OPTION_TAXONOMY_CONFIG, $current_config, false);
            update_option(self::OPTION_MAGNIFIC_STYLE, $current_style, false);
            update_option(self::OPTION_EXCLUSIONS, $current_exclusions, false);
            if ($current_receipt === null) {
                delete_option(self::OPTION_LAST_PROFILE_SAVE_RECEIPT);
            } else {
                update_option(self::OPTION_LAST_PROFILE_SAVE_RECEIPT, $current_receipt, false);
            }
        };

        if (!$readback_ok) {
            $rollback();
            self::flush_option_read_cache([self::OPTION_GENERAL_PROFILES]);
            $rolled_back_profiles = get_option(self::OPTION_GENERAL_PROFILES, null);
            $rollback_ok = is_array($rolled_back_profiles);
            if ($rollback_ok) {
                foreach ($submitted_profile_keys as $profile_key) {
                    $before_prompt = (string)($current_profiles[$profile_key]['base_prompt'] ?? '');
                    $after_prompt = (string)($rolled_back_profiles[$profile_key]['base_prompt'] ?? '');
                    if (!self::prompt_fingerprints_match($before_prompt, $after_prompt)) {
                        $rollback_ok = false;
                        break;
                    }
                }
            }
            if (!$rollback_ok) {
                wp_die('Kritischer Speicherfehler: Readback fehlgeschlagen und der vorherige Profilstand konnte nicht sicher zurückgelesen werden. Automatische Sicherung: ' . esc_html($backup_key));
            }
            self::redirect_to_tab(['profiles_error' => 'readback_failed', 'prompt_profile' => sanitize_key($submitted_profile_keys[0])], $return_tab);
        }

        $saved_profile_key = $submitted_profile_keys[0];
        $saved_prompt = (string)$clean_profiles[$saved_profile_key]['base_prompt'];
        $receipt = self::create_profile_save_receipt($saved_profile_key, $saved_prompt);
        update_option(self::OPTION_LAST_PROFILE_SAVE_RECEIPT, $receipt, false);
        self::flush_option_read_cache([self::OPTION_LAST_PROFILE_SAVE_RECEIPT]);
        $stored_receipt = get_option(self::OPTION_LAST_PROFILE_SAVE_RECEIPT, null);
        if (!self::profile_save_receipt_matches($receipt, $stored_receipt)) {
            $rollback();
            self::redirect_to_tab(['profiles_error' => 'receipt_failed', 'prompt_profile' => sanitize_key($saved_profile_key)], $return_tab);
        }

        self::redirect_to_tab([
            'profiles_saved' => '1',
            'prompt_profile' => sanitize_key($saved_profile_key),
            'prompt_chars' => (string)self::prompt_character_length($saved_prompt),
            'save_token' => (string)$receipt['token'],
        ], $return_tab);
    }


private static function candidate_taxonomies(): array {
    // Read-only discovery across all registered taxonomies. Hidden HivePress taxonomies
    // must not disappear merely because show_ui is false.
    $objects = get_taxonomies([], 'objects');
    $result = [];
    foreach ($objects as $name => $object) {
        if (!$object instanceof WP_Taxonomy) continue;
        $object_types = array_values(array_filter(array_map('strval', (array) $object->object_type)));
        $haystack = strtolower($name . ' ' . implode(' ', $object_types) . ' ' . (string) ($object->labels->name ?? ''));
        $score = 0;
        if (str_starts_with($name, 'hp_')) $score += 8;
        if (str_contains($name, 'listing')) $score += 6;
        if (array_filter($object_types, static fn($type) => str_starts_with($type, 'hp_') || str_contains($type, 'listing'))) $score += 8;
        if (str_contains($haystack, 'hivepress')) $score += 8;
        if ((bool) $object->hierarchical) $score += 1;
        $result[$name] = [
            'label' => (string) ($object->labels->name ?? $name),
            'hierarchical' => (bool) $object->hierarchical,
            'object_types' => $object_types,
            'show_ui' => (bool) $object->show_ui,
            'hivepress_score' => $score,
            'hivepress_candidate' => $score >= 6,
        ];
    }
    uasort($result, static function(array $a, array $b): int {
        return ($b['hivepress_score'] <=> $a['hivepress_score']) ?: strcmp($a['label'], $b['label']);
    });
    return $result;
}

private static function candidate_post_types(): array {
    $objects = get_post_types(['show_ui'=>true], 'objects');
    $result = [];
    $blocked = ['post','page','attachment','revision','nav_menu_item','custom_css','customize_changeset','oembed_cache','user_request','wp_block','wp_template','wp_template_part','wp_global_styles','wp_navigation','wp_font_family','wp_font_face'];
    foreach ((array)$objects as $name => $object) {
        $name = sanitize_key((string)$name);
        if ($name === '' || in_array($name, $blocked, true) || !$object instanceof WP_Post_Type) continue;
        if (!(bool)($object->public ?? false) && !(bool)($object->publicly_queryable ?? false)) continue;
        if (function_exists('post_type_supports') && !post_type_supports($name, 'thumbnail')) continue;
        $result[$name] = [
            'label'=>(string)($object->labels->name ?? $object->label ?? $name),
            'singular'=>(string)($object->labels->singular_name ?? $name),
            'hierarchical'=>(bool)($object->hierarchical ?? false),
        ];
    }
    uasort($result, static fn(array $a,array $b):int => strcasecmp((string)$a['label'],(string)$b['label']));
    return $result;
}

private static function image_reference_kind($value): string {
    $value = maybe_unserialize($value);
    if (is_numeric($value)) {
        $id = absint($value);
        if ($id > 0 && get_post_type($id) === 'attachment' && wp_attachment_is_image($id)) return 'attachment_id';
    }
    if (is_string($value)) {
        $trim = trim($value);
        if ($trim !== '' && preg_match('#^https?://#i', $trim)) return 'image_url';
        return '';
    }
    if (is_array($value) || is_object($value)) {
        foreach ((array) $value as $child) {
            $kind = self::image_reference_kind($child);
            if ($kind !== '') return 'nested_' . $kind;
        }
    }
    return '';
}

private static function detected_term_image_meta_candidates(string $taxonomy): array {
    if ($taxonomy === '' || !taxonomy_exists($taxonomy)) return [];
    $terms = get_terms(['taxonomy'=>$taxonomy,'hide_empty'=>false,'number'=>200,'fields'=>'ids']);
    if (is_wp_error($terms)) return [];
    $candidates = [];
    foreach ($terms as $term_id) {
        foreach (get_term_meta((int)$term_id) as $key => $values) {
            $key_score = preg_match('/(?:image|img|photo|picture|thumbnail|thumb|icon|cover|logo)/i', (string)$key) ? 4 : 0;
            foreach ((array)$values as $value) {
                $kind = self::image_reference_kind($value);
                if ($kind === '' && $key_score === 0) continue;
                if (!isset($candidates[$key])) {
                    $candidates[$key] = ['key'=>(string)$key,'matches'=>0,'kind'=>'','score'=>$key_score,'sample_term_id'=>(int)$term_id];
                }
                if ($kind !== '') {
                    $candidates[$key]['matches']++;
                    $candidates[$key]['kind'] = $kind;
                    $candidates[$key]['score'] += 10;
                }
            }
        }
    }
    uasort($candidates, static function(array $a, array $b): int {
        return ($b['score'] <=> $a['score']) ?: ($b['matches'] <=> $a['matches']) ?: strcmp($a['key'], $b['key']);
    });
    return $candidates;
}

private static function detected_term_image_meta_keys(string $taxonomy): array {
    return array_keys(self::detected_term_image_meta_candidates($taxonomy));
}

    
private static function render_profile_save_notice(): void {
    if (isset($_GET['profiles_saved'])) {
        $verification = self::verify_profile_save_receipt_from_request();
        if (empty($verification['ok'])) {
            echo '<div class="notice notice-error inline"><p><strong>Speicherbestätigung verworfen:</strong> Der Grundprompt konnte in einem neuen Seitenaufruf nicht mit dem gespeicherten Beleg abgeglichen werden. Es wird ausdrücklich kein erfolgreicher Speicherstand behauptet.</p></div>';
            return;
        }
        $characters = (int)$verification['characters'];
        $count = function_exists('number_format_i18n') ? number_format_i18n($characters) : number_format($characters, 0, ',', '.');
        echo '<div class="notice notice-success inline"><p><strong>Grundprompt dauerhaft bestätigt: ' . esc_html((string)$count) . ' Zeichen.</strong> Neuer Seitenaufruf, Zeichenlänge und SHA-256 stimmen mit dem Speicherbeleg überein.</p></div>';
        return;
    }
    if (!isset($_GET['profiles_error'])) return;
    $code = sanitize_key((string) wp_unslash($_GET['profiles_error']));
    $messages = [
        'invalid_profile' => 'Speichern abgebrochen: Das übermittelte Profil ist ungültig. Der vorherige Stand blieb unverändert.',
        'missing_prompt' => 'Speichern abgebrochen: Der Grundprompt wurde nicht vollständig an WordPress übermittelt. Der vorherige Grundprompt blieb unverändert.',
        'invalid_prompt' => 'Speichern abgebrochen: Der Grundprompt wurde nicht als vollständiger Textwert übermittelt. Der vorherige Grundprompt blieb unverändert.',
        'empty_prompt' => 'Speichern abgebrochen: Ein leerer Grundprompt ist nicht zulässig. Der vorherige Grundprompt blieb unverändert.',
        'prompt_too_long' => 'Speichern abgebrochen: Der Grundprompt überschreitet die sichere Grenze von 100.000 Zeichen beziehungsweise 400.000 Bytes. Der vorherige Grundprompt blieb unverändert.',
        'prompt_validation_failed' => 'Speichern abgebrochen: Der empfangene Grundprompt konnte vor dem Schreiben nicht verlustfrei validiert werden. Der vorherige Grundprompt blieb unverändert.',
        'readback_failed' => 'Speichern abgebrochen: Readback, Zeichenlänge oder SHA-256 wich nach dem Schreiben ab. Der vorherige Stand wurde automatisch wiederhergestellt.',
        'receipt_failed' => 'Speichern abgebrochen: Der zusätzliche Speicherbeleg für den neuen Seitenaufruf konnte nicht sicher geschrieben werden. Der vorherige Stand wurde wiederhergestellt.',
    ];
    $message = $messages[$code] ?? 'Speichern abgebrochen. Der vorherige Grundprompt blieb unverändert.';
    echo '<div class="notice notice-error inline"><p><strong>' . esc_html($message) . '</strong></p></div>';
}

private static function render_article_profile_panel(): void {
    $profiles = self::general_profiles();
    $profile = $profiles['article'];
    ?>
    <div class="hbbz-admin-box" id="hbbz-profile-article">
        <h2>Beitragsprofil und Promptregeln</h2>
        <p>Alle Regeln für Beitragsbilder bleiben direkt im Beitragsbereich. API-Zugänge und Sicherung sind getrennt im Reiter „Verbindungen &amp; Sicherung“.</p>
        <?php self::render_profile_save_notice(); ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="hbbz_save_general_profiles"><?php wp_nonce_field('hbbz_save_general_profiles'); ?><input type="hidden" name="hbbz_return_tab" value="posts">
            <fieldset style="border:1px solid #ccd0d4;padding:14px;background:#fff;margin:0 0 16px">
                <legend><strong><?php echo esc_html($profile['label']); ?></strong></legend>
                <p><label><strong>Gespeicherter Profil-Grundprompt</strong><br><textarea id="hbbz-profile-article-base-prompt" name="profiles[article][base_prompt]" class="large-text" rows="8"><?php echo esc_textarea($profile['base_prompt']); ?></textarea></label></p><?php $loaded_prompt_fingerprint=self::prompt_fingerprint((string)$profile['base_prompt']); ?><p class="description"><strong>Aktuell aus WordPress geladen:</strong> <?php echo (int)$loaded_prompt_fingerprint['characters']; ?> Zeichen · SHA-256 <code><?php echo esc_html((string)$loaded_prompt_fingerprint['sha256']); ?></code></p><p class="description">Leere oder unvollständig übermittelte Grundprompts werden strikt abgelehnt. Nach dem Speichern prüft das Plugin den neuen Seitenaufruf erneut.</p>
                <p><label>Ausschlüsse / Negativregeln<br><textarea name="profiles[article][negative_prompt]" class="large-text" rows="3"><?php echo esc_textarea($profile['negative_prompt']); ?></textarea></label></p>
                <p><label>Farb- und Ausstrahlungsregel<br><textarea name="profiles[article][color_direction]" class="large-text" rows="2"><?php echo esc_textarea($profile['color_direction']); ?></textarea></label></p>
                <p><label>Motivregel<br><textarea name="profiles[article][subject_rule]" class="large-text" rows="2"><?php echo esc_textarea($profile['subject_rule']); ?></textarea></label></p>
                <?php $format_presets=self::image_format_presets();$selected_format=self::infer_format_preset($profile); ?>
                <p><label>Bildformat <select name="profiles[article][format_preset]"><?php foreach($format_presets as $format_key=>$format): ?><option value="<?php echo esc_attr($format_key); ?>" <?php selected($selected_format,$format_key); ?>><?php echo esc_html($format['label'].' – '.$format['width'].' × '.$format['height'].' px'); ?></option><?php endforeach; ?></select></label></p>
                <p class="description">Eine Auswahl steuert gleichzeitig Magnific-Seitenverhältnis und gespeicherte WebP-Ausgabegröße. Widersprüchliche Angaben sind ausgeschlossen.</p>
                <input type="hidden" name="profiles[article][label]" value="<?php echo esc_attr($profile['label']); ?>">
            </fieldset>
            <?php submit_button('Beitragsprofil speichern'); ?>
        </form>
    </div>
    <?php
}


private static function hivepress_category_overview(string $taxonomy, string $meta_key): array {
    if ($taxonomy === '' || $meta_key === '' || !taxonomy_exists($taxonomy)) {
        return ['open'=>[], 'done'=>[], 'total'=>0];
    }
    $terms = get_terms(['taxonomy'=>$taxonomy, 'hide_empty'=>false, 'number'=>0]);
    if (is_wp_error($terms)) return ['open'=>[], 'done'=>[], 'total'=>0];
    $open=[]; $done=[];
    foreach ($terms as $term) {
        if (!$term instanceof WP_Term) continue;
        $attachment_id = absint(get_term_meta($term->term_id, $meta_key, true));
        $is_plugin_image = $attachment_id > 0
            && get_post_type($attachment_id) === 'attachment'
            && wp_attachment_is_image($attachment_id)
            && get_post_meta($attachment_id, '_hbbz_image_profile', true) === 'hivepress'
            && absint(get_post_meta($attachment_id, '_hbbz_target_term_id', true)) === (int)$term->term_id;
        $row = [
            'term_id'=>(int)$term->term_id,
            'name'=>(string)$term->name,
            'parent'=>(int)$term->parent,
            'attachment_id'=>$attachment_id,
            'image_url'=>$attachment_id > 0 ? (wp_get_attachment_image_url($attachment_id,'thumbnail') ?: wp_get_attachment_url($attachment_id)) : '',
            'status'=>$is_plugin_image ? 'done' : 'open',
        ];
        if ($is_plugin_image) $done[]=$row; else $open[]=$row;
    }
    usort($open, static fn($a,$b)=>strnatcasecmp($a['name'],$b['name']));
    usort($done, static fn($a,$b)=>strnatcasecmp($a['name'],$b['name']));
    return ['open'=>$open,'done'=>$done,'total'=>count($open)+count($done)];
}

private static function render_hivepress_category_overview(string $taxonomy, string $meta_key): void {
    $overview = self::hivepress_category_overview($taxonomy, $meta_key);
    ?>
    <div class="hbbz-admin-box">
        <h2>HivePress-Bildübersicht</h2>
        <?php if ($taxonomy === '' || $meta_key === ''): ?>
            <p>Die Übersicht wird angezeigt, sobald Taxonomie und Bild-Metafeld bestätigt sind.</p>
        <?php else: ?>
            <p><strong><?php echo (int)count($overview['open']); ?> offen</strong> · <strong><?php echo (int)count($overview['done']); ?> erledigt</strong> · <?php echo (int)$overview['total']; ?> Kategorien insgesamt.</p>
            <p class="description">„Erledigt“ bedeutet: Das aktuell zugeordnete Bild wurde von dieser Bildzentrale speziell für genau diese HivePress-Kategorie importiert. Vorhandene Platzhalter oder frühere Bilder bleiben als „offen“ sichtbar, bis sie bewusst ersetzt werden.</p>
            <div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:18px;align-items:start">
                <div><h3>Offen</h3>
                    <table class="widefat striped"><thead><tr><th>Kategorie</th><th>Aktuelles Bild</th><th>Status</th></tr></thead><tbody>
                    <?php if (!$overview['open']): ?><tr><td colspan="3">Keine offenen Kategorien.</td></tr><?php endif; ?>
                    <?php foreach($overview['open'] as $row): ?><tr><td><?php echo esc_html($row['name']); ?> <code>#<?php echo (int)$row['term_id']; ?></code><br><button type="button" class="button hbbz-hp-open-category" data-term-id="<?php echo (int)$row['term_id']; ?>">Bild erstellen</button></td><td><?php if($row['image_url']): ?><img src="<?php echo esc_url($row['image_url']); ?>" alt="" style="width:72px;height:48px;object-fit:cover"><?php else: ?>kein Bild<?php endif; ?></td><td><?php echo $row['attachment_id'] ? 'Vorhandenes Bild/Platzhalter' : 'Kein Bild'; ?></td></tr><?php endforeach; ?>
                    </tbody></table>
                </div>
                <div><h3>Erledigt</h3>
                    <table class="widefat striped"><thead><tr><th>Kategorie</th><th>Bild</th><th>Status</th></tr></thead><tbody>
                    <?php if (!$overview['done']): ?><tr><td colspan="3">Noch keine Kategorie mit einem Bild aus der Bildzentrale abgeschlossen.</td></tr><?php endif; ?>
                    <?php foreach($overview['done'] as $row): ?><tr><td><?php echo esc_html($row['name']); ?> <code>#<?php echo (int)$row['term_id']; ?></code><br><button type="button" class="button hbbz-hp-open-category" data-term-id="<?php echo (int)$row['term_id']; ?>">Bild ändern</button></td><td><?php if($row['image_url']): ?><img src="<?php echo esc_url($row['image_url']); ?>" alt="" style="width:72px;height:48px;object-fit:cover"><?php endif; ?></td><td>Bildzentrale-Bild aktiv</td></tr><?php endforeach; ?>
                    </tbody></table>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <script>
    (function(){
        const buttons = document.querySelectorAll('.hbbz-hp-open-category');
        const select = document.getElementById('hbbz-term-hp-term');
        const workflow = select ? select.closest('.hbbz-admin-box') : null;
        buttons.forEach(function(button){
            button.addEventListener('click', function(){
                if (!select) return;
                const termId = String(button.getAttribute('data-term-id') || '');
                const option = Array.from(select.options).find(function(item){ return item.value === termId; });
                if (!option) return;
                select.value = termId;
                select.dispatchEvent(new Event('change', {bubbles:true}));
                const status = document.getElementById('hbbz-term-hp-status');
                if (status) status.innerHTML = '<strong>Status:</strong> Kategorie geladen. Prompt kann erstellt oder ein neues Bild erzeugt werden.';
                if (workflow) workflow.scrollIntoView({behavior:'smooth', block:'start'});
            });
        });
    })();
    </script>
    <?php
}

private static function render_generalization_panel(string $section = 'admin'): void {
    $profiles = self::general_profiles();
    $config = self::sanitize_taxonomy_config((array)get_option(self::OPTION_TAXONOMY_CONFIG, []));
    $taxonomies = self::candidate_taxonomies();
    $post_types = self::candidate_post_types();
    $hp_candidates = array_filter($taxonomies, static fn($item) => !empty($item['hivepress_candidate']));
    $hp_meta_candidates = self::detected_term_image_meta_candidates($config['hivepress_taxonomy']);
    if ($section === 'admin') {
        ?>
        <div class="hbbz-admin-box">
            <?php self::render_profile_save_notice(); ?>
            <?php if (isset($_GET['imported'])): ?><div class="notice notice-success inline"><p>Einstellungen importiert. Vorheriger Stand wurde automatisch als WordPress-Option gesichert.</p></div><?php endif; ?>
            <h2>Sicherung, Import und Verwaltung</h2>
            <div style="display:grid;grid-template-columns:minmax(280px,1fr) minmax(280px,1fr) minmax(280px,1fr);gap:16px;align-items:start">
                <div style="border:1px solid #ccd0d4;padding:14px;background:#fff">
                    <h3>Hab-&-Bewahr-/Komplettsicherung</h3>
                    <p>Exportiert alle gespeicherten Prompts, Ausschlüsse, Profile, Taxonomie-Konfigurationen sowie Pixabay-, Pexels-, Magnific- und Webhook-Zugangsdaten.</p>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="hbbz_export_settings"><?php wp_nonce_field('hbbz_export_settings'); ?><button class="button button-primary">Vollständige Einstellungen exportieren</button></form>
                </div>
                <div style="border:1px solid #ccd0d4;padding:14px;background:#fff">
                    <h3>Einstellungen importieren</h3>
                    <form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="hbbz_import_settings"><?php wp_nonce_field('hbbz_import_settings'); ?><input type="hidden" name="hbbz_return_tab" value="admin"><input type="file" name="hbbz_settings_file" accept="application/json" required><p><label><input type="checkbox" name="replace_existing" value="1"> vorhandene Werte ausdrücklich ersetzen</label></p><button class="button">Importieren</button></form>
                </div>
                <div style="border:1px solid #ccd0d4;padding:14px;background:#fff">
                    <h3>Erkannte Metafeld-Kandidaten</h3>
                    <p><strong>WordPress:</strong> <?php echo esc_html(implode(', ', self::detected_term_image_meta_keys($config['wordpress_taxonomy'])) ?: 'keine vorhandenen Bildwerte erkannt'); ?></p>
                    <p><strong>HivePress:</strong> <?php echo esc_html(implode(', ', self::detected_term_image_meta_keys($config['hivepress_taxonomy'])) ?: 'keine vorhandenen Bildwerte erkannt'); ?></p>
                </div>
            </div>
        </div>
        <?php
        return;
    }

    $is_wp = $section === 'wp';
    $is_cpt = $section === 'cpt';
    $profile_key = $is_wp ? 'category' : ($is_cpt ? 'post_type_hero' : 'hivepress');
    $profile = $profiles[$profile_key];
    $taxonomy_value = $is_wp ? $config['wordpress_taxonomy'] : ($is_cpt ? $config['hero_post_type'] : $config['hivepress_taxonomy']);
    $meta_key_value = $is_wp ? $config['wordpress_image_meta_key'] : ($is_cpt ? '_thumbnail_id' : $config['hivepress_image_meta_key']);
    $terms = (!$is_wp && !$is_cpt && $taxonomy_value !== '' && taxonomy_exists($taxonomy_value)) ? get_terms(['taxonomy'=>$taxonomy_value,'hide_empty'=>false,'number'=>0]) : [];
    $prefix = $is_wp ? 'wp' : ($is_cpt ? 'cpt' : 'hp');
    $panel_title = $is_wp ? 'WordPress-Kategorien' : ($is_cpt ? 'Post-Type-Hero' : 'HivePress-Kategorien');
    $workflow_label = $is_wp ? 'WordPress-Kategorie' : ($is_cpt ? 'Inhalt' : 'HivePress-Kategorie');
    ?>
    <div id="hbbz-panel-<?php echo esc_attr($prefix); ?>" class="hbbz-tab-panel<?php echo (isset($_GET['hbbz_tab']) && sanitize_key((string) wp_unslash($_GET['hbbz_tab'])) === $prefix) ? ' is-active' : ''; ?>">
        <?php if ($is_cpt && $config['hero_post_type'] === ''): ?>
            <div class="notice notice-warning inline"><p>Post-Type-Hero bleibt fail-closed gesperrt, bis ein konkreter Custom Post Type mit Beitragsbild-Unterstützung gespeichert ist.</p></div>
        <?php elseif (!$is_wp && !$is_cpt && $config['hivepress_taxonomy'] === ''): ?>
            <div class="notice notice-warning inline"><p>HivePress bleibt fail-closed gesperrt, bis reale Taxonomie und reales Bild-Metafeld bestätigt und gespeichert sind.</p></div>
        <?php endif; ?>
        <?php self::render_profile_save_notice(); ?>
        <div class="hbbz-admin-box" id="hbbz-profile-<?php echo esc_attr($profile_key); ?>">
            <h2><?php echo esc_html($panel_title); ?> – Prompt, Stil und Zuordnung</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="hbbz_save_general_profiles"><?php wp_nonce_field('hbbz_save_general_profiles'); ?><input type="hidden" name="hbbz_return_tab" value="<?php echo esc_attr($prefix); ?>">
                <fieldset style="border:1px solid #ccd0d4;padding:14px;background:#fff;margin:0 0 16px">
                    <legend><strong><?php echo esc_html($profile['label']); ?></strong></legend>
                    <p><label><strong>Gespeicherter Profil-Grundprompt</strong><br><textarea id="hbbz-profile-<?php echo esc_attr($profile_key); ?>-base-prompt" name="profiles[<?php echo esc_attr($profile_key); ?>][base_prompt]" class="large-text" rows="8"><?php echo esc_textarea($profile['base_prompt']); ?></textarea></label></p><?php $loaded_prompt_fingerprint=self::prompt_fingerprint((string)$profile['base_prompt']); ?><p class="description"><strong>Aktuell aus WordPress geladen:</strong> <?php echo (int)$loaded_prompt_fingerprint['characters']; ?> Zeichen · SHA-256 <code><?php echo esc_html((string)$loaded_prompt_fingerprint['sha256']); ?></code></p><p class="description">Leere oder unvollständig übermittelte Grundprompts werden strikt abgelehnt. Nach dem Speichern prüft das Plugin den neuen Seitenaufruf erneut.</p>
                    <p><label>Ausschlüsse / Negativregeln<br><textarea name="profiles[<?php echo esc_attr($profile_key); ?>][negative_prompt]" class="large-text" rows="3"><?php echo esc_textarea($profile['negative_prompt']); ?></textarea></label></p>
                    <p><label>Farb- und Ausstrahlungsregel<br><textarea name="profiles[<?php echo esc_attr($profile_key); ?>][color_direction]" class="large-text" rows="2"><?php echo esc_textarea($profile['color_direction']); ?></textarea></label></p>
                    <p><label>Motivregel<br><textarea name="profiles[<?php echo esc_attr($profile_key); ?>][subject_rule]" class="large-text" rows="2"><?php echo esc_textarea($profile['subject_rule']); ?></textarea></label></p>
                    <?php $format_presets=self::image_format_presets();$selected_format=self::infer_format_preset($profile); ?>
                    <p><label>Bildformat <select name="profiles[<?php echo esc_attr($profile_key); ?>][format_preset]"><?php foreach($format_presets as $format_key=>$format): ?><option value="<?php echo esc_attr($format_key); ?>" <?php selected($selected_format,$format_key); ?>><?php echo esc_html($format['label'].' – '.$format['width'].' × '.$format['height'].' px'); ?></option><?php endforeach; ?></select></label></p>
                    <p class="description">Eine Auswahl steuert das gewünschte Endformat. Kategorie-/Seitenbilder bleiben bei 3:1 / 1200 × 400. Für Post-Type-Hero ist 21:9 / 1260 × 540 vorgesehen, damit das vollständige Magnific-Bild ohne nachträglichen 3:1-Zuschnitt gespeichert wird.</p>
                    <p><label>WebP-Qualität <input type="number" min="50" max="90" name="profiles[<?php echo esc_attr($profile_key); ?>][webp_quality]" value="<?php echo (int)$profile['webp_quality']; ?>" style="width:80px"></label> &nbsp; <label>Zielgröße höchstens ca. <input type="number" min="40" max="500" name="profiles[<?php echo esc_attr($profile_key); ?>][target_kb]" value="<?php echo (int)$profile['target_kb']; ?>" style="width:80px"> KB</label></p>
                    <input type="hidden" name="profiles[<?php echo esc_attr($profile_key); ?>][label]" value="<?php echo esc_attr($profile['label']); ?>">
                </fieldset>
                <fieldset style="border:1px solid #ccd0d4;padding:14px;background:#fff;margin:0 0 16px">
                    <legend><strong><?php echo $is_cpt ? 'Post-Type-Zuordnung' : 'Taxonomie-Zuordnung'; ?></strong></legend>
                    <table class="form-table" role="presentation">
                        <?php if ($is_wp): ?>
                            <tr><th>WordPress-Taxonomie</th><td><select name="taxonomy_config[wordpress_taxonomy]"><?php foreach($taxonomies as $name=>$item): ?><option value="<?php echo esc_attr($name); ?>" <?php selected($config['wordpress_taxonomy'],$name); ?>><?php echo esc_html($item['label'].' ('.$name.')'); ?></option><?php endforeach; ?></select></td></tr>
                            <tr><th>WordPress-Bild-Metafeld</th><td><input class="regular-text" name="taxonomy_config[wordpress_image_meta_key]" value="<?php echo esc_attr($config['wordpress_image_meta_key']); ?>"><p class="description">Standard für WordPress-Kategorien: thumbnail_id. Vorhandene Werte werden nie automatisch überschrieben.</p></td></tr>
                        <?php elseif ($is_cpt): ?>
                            <tr><th>Custom Post Type</th><td><select name="taxonomy_config[hero_post_type]"><option value="">Nicht aktiviert</option><?php foreach($post_types as $name=>$item): ?><option value="<?php echo esc_attr($name); ?>" <?php selected($config['hero_post_type'],$name); ?>><?php echo esc_html($item['label'].' ('.$name.')'); ?></option><?php endforeach; ?></select><p class="description">Nur öffentliche Custom Post Types mit Beitragsbild-Unterstützung werden angeboten. Das Hero wird als WordPress-Featured-Image gesetzt; ohne gespeicherten Post Type bleibt der Weg fail-closed.</p></td></tr>
                        <?php else: ?>
                            <tr><th>HivePress-Taxonomie</th><td><select name="taxonomy_config[hivepress_taxonomy]"><option value="">Nicht aktiviert</option><?php foreach($hp_candidates as $name=>$item): ?><option value="<?php echo esc_attr($name); ?>" <?php selected($config['hivepress_taxonomy'],$name); ?>><?php echo esc_html($item['label'].' ('.$name.') · Objekttypen: '.implode(', ', $item['object_types'])); ?></option><?php endforeach; ?></select><?php if(!$hp_candidates): ?><p class="description">Keine eindeutige HivePress-Taxonomie erkannt. Es wird nichts automatisch aktiviert oder überschrieben.</p><?php else: ?><p class="description">Nur erkannte Kandidaten werden angeboten. Auswahl und Speicherung erfolgen bewusst.</p><?php endif; ?></td></tr>
                            <tr><th>HivePress-Bild-Metafeld</th><td><input class="regular-text" list="hbbz-hp-meta-candidates" name="taxonomy_config[hivepress_image_meta_key]" value="<?php echo esc_attr($config['hivepress_image_meta_key']); ?>"><datalist id="hbbz-hp-meta-candidates"><?php foreach($hp_meta_candidates as $candidate): ?><option value="<?php echo esc_attr($candidate['key']); ?>"><?php endforeach; ?></datalist><p class="description">Muss anhand vorhandener Platzhalterwerte bestätigt werden. Ohne gespeicherten Schlüssel bleibt die Zuordnung fail-closed gesperrt.</p></td></tr>
                        <?php endif; ?>
                    </table>
                </fieldset>
                <?php if (!$is_wp && !$is_cpt): ?>
                    <fieldset style="border:1px solid #ccd0d4;padding:14px;background:#fff;margin:0 0 16px">
                        <legend><strong>Sichere HivePress-Erkennung – nur lesend</strong></legend>
                        <p><strong>Registrierte Kandidaten:</strong></p>
                        <?php if ($hp_candidates): ?>
                            <table class="widefat striped"><thead><tr><th>Taxonomie</th><th>Bezeichnung</th><th>Objekttypen</th><th>UI</th><th>Erkennungspunktzahl</th></tr></thead><tbody>
                            <?php foreach($hp_candidates as $name=>$item): ?><tr><td><code><?php echo esc_html($name); ?></code></td><td><?php echo esc_html($item['label']); ?></td><td><?php echo esc_html(implode(', ', $item['object_types'])); ?></td><td><?php echo $item['show_ui'] ? 'sichtbar' : 'intern/verborgen'; ?></td><td><?php echo (int)$item['hivepress_score']; ?></td></tr><?php endforeach; ?>
                            </tbody></table>
                        <?php else: ?><p>Keine eindeutigen Kandidaten gefunden. Keine automatische Aktivierung.</p><?php endif; ?>
                        <p><strong>Bild-Metafeld-Kandidaten der aktuell gespeicherten Taxonomie:</strong></p>
                        <?php if ($hp_meta_candidates): ?>
                            <table class="widefat striped"><thead><tr><th>Metafeld</th><th>Gefundene Bildwerte</th><th>Werttyp</th><th>Beispiel-Term</th></tr></thead><tbody>
                            <?php foreach($hp_meta_candidates as $candidate): ?><tr><td><code><?php echo esc_html($candidate['key']); ?></code></td><td><?php echo (int)$candidate['matches']; ?></td><td><?php echo esc_html($candidate['kind'] ?: 'nur namensbasierter Kandidat'); ?></td><td>#<?php echo (int)$candidate['sample_term_id']; ?></td></tr><?php endforeach; ?>
                            </tbody></table>
                        <?php else: ?><p>Noch keine Bild-Metafelder für die aktuell gespeicherte Taxonomie erkannt. Zuerst Taxonomie auswählen und speichern; danach wird ausschließlich lesend erneut geprüft.</p><?php endif; ?>
                        <p class="description">Diese Erkennung schreibt keine Term-Metadaten und verändert keine Platzhalterbilder.</p>
                    </fieldset>
                <?php endif; ?>
                <?php submit_button($is_wp ? 'WordPress-Kategorieprofil speichern' : ($is_cpt ? 'Post-Type-Hero-Profil speichern' : 'HivePress-Profil speichern')); ?>
            </form>
        </div>
        <div class="hbbz-admin-box">
            <h2><?php echo esc_html($panel_title); ?> – Bild erzeugen und zuordnen</h2>
                <?php if ($is_wp || $is_cpt): ?>
                    <p><label><strong><?php echo $is_cpt ? 'Post-Type-Inhalt suchen' : 'WordPress-Kategorie oder Seite suchen'; ?></strong><br><input type="search" id="hbbz-term-<?php echo esc_attr($prefix); ?>-search" class="regular-text" autocomplete="off" placeholder="mindestens 2 Zeichen eingeben" <?php disabled($is_cpt && $taxonomy_value === ''); ?>></label></p>
                    <input type="hidden" id="hbbz-term-<?php echo esc_attr($prefix); ?>-term" value="">
                    <input type="hidden" id="hbbz-term-<?php echo esc_attr($prefix); ?>-entity" value="<?php echo $is_cpt ? 'post' : 'term'; ?>">
                    <div id="hbbz-term-<?php echo esc_attr($prefix); ?>-search-results" class="hbbz-term-search-results" aria-live="polite"></div>
                    <p id="hbbz-term-<?php echo esc_attr($prefix); ?>-selected"><strong>Ausgewähltes Ziel:</strong> noch keines</p>
                <?php else: ?>
                    <p><label><?php echo esc_html($workflow_label); ?> <select id="hbbz-term-<?php echo esc_attr($prefix); ?>-term" <?php disabled($taxonomy_value === ''); ?>><option value="">Bitte wählen</option><?php if(!is_wp_error($terms))foreach($terms as $term): ?><option value="<?php echo (int)$term->term_id; ?>"><?php echo esc_html($term->name.' (#'.$term->term_id.')'); ?></option><?php endforeach; ?></select></label></p>
                <?php endif; ?>
            <p><label>Zusätzliche individuelle Motivvorgabe (optional)<br><textarea id="hbbz-term-<?php echo esc_attr($prefix); ?>-custom" class="large-text" rows="2"></textarea></label></p>
            <p><button type="button" class="button" id="hbbz-term-<?php echo esc_attr($prefix); ?>-preview">Prompt erstellen</button> <button type="button" class="button button-primary" id="hbbz-term-<?php echo esc_attr($prefix); ?>-generate">1 KI-Bild erzeugen</button> <button type="button" class="button" id="hbbz-term-<?php echo esc_attr($prefix); ?>-check">Status prüfen</button></p>
                <p><button type="button" class="button" id="hbbz-term-<?php echo esc_attr($prefix); ?>-normalize-current">Aktuelles Bild normalisieren</button> <button type="button" class="button" id="hbbz-term-<?php echo esc_attr($prefix); ?>-normalize-batch">Nächste 10 bestehende Bilder normalisieren</button></p>
                <p class="description">Das Original bleibt in der Mediathek erhalten. Erst nach erfolgreicher WebP-Erzeugung und Readback wird die Zuordnung auf die optimierte Version umgestellt.</p>
            <p id="hbbz-term-<?php echo esc_attr($prefix); ?>-status"><strong>Status:</strong> Noch kein Vorgang.</p>
            <p><label><strong>Erzeugter Bildprompt – nicht das gespeicherte Profilfeld</strong><br><textarea id="hbbz-term-<?php echo esc_attr($prefix); ?>-prompt" class="large-text" rows="9" placeholder="Dieses Feld bleibt leer, bis „Prompt erstellen“ angeklickt wurde."></textarea></label></p><p class="description">Dieses Arbeitsfeld wird aus Kategorie, Hierarchie und dem oben gespeicherten Profil-Grundprompt erzeugt. Es ist nach dem Speichern des Profils absichtlich leer.</p>
            <div id="hbbz-term-<?php echo esc_attr($prefix); ?>-results" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px"></div>
        </div>

        <script>
        (function(){
            const nonce = <?php echo wp_json_encode(wp_create_nonce('hbbz_ajax')); ?>;
            const profile = <?php echo wp_json_encode($profile_key); ?>;
            const taxonomy = <?php echo wp_json_encode($taxonomy_value); ?>;
            const prefix = <?php echo wp_json_encode($prefix); ?>;
            const status = document.getElementById('hbbz-term-' + prefix + '-status');
            const results = document.getElementById('hbbz-term-' + prefix + '-results');
            function termId(){const el=document.getElementById('hbbz-term-' + prefix + '-term'); return el ? el.value : '';}
            function entityType(){ if(prefix === 'cpt') return 'post'; if(prefix !== 'wp') return 'term'; const el=document.getElementById('hbbz-term-wp-entity'); return el && el.value ? el.value : 'term'; }
            function targetLabel(){ return entityType() === 'page' ? 'Seite' : (entityType() === 'post' ? 'Post-Type-Hero' : 'Kategorie'); }
            function custom(){const el=document.getElementById('hbbz-term-' + prefix + '-custom'); return el ? el.value : '';}
            function currentPrompt(){const el=document.getElementById('hbbz-term-' + prefix + '-prompt'); return el ? el.value : '';}
            async function call(action, extra={}) {
                const body = new URLSearchParams(Object.assign({action, nonce, profile, taxonomy, term_id: termId(), entity_type: entityType(), custom: custom()}, extra));
                const response = await fetch(ajaxurl, {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'}, body: body.toString()});
                const json = await response.json();
                if (!json.success) throw new Error(typeof json.data === 'string' ? json.data : 'Vorgang fehlgeschlagen');
                return json.data || {};
            }
            function showImages(data) {
                results.innerHTML = '';
                (data.images || []).forEach((img, index) => {
                    const card = document.createElement('div');
                    card.style.border = '1px solid #ccd0d4';
                    card.style.padding = '10px';
                    card.style.background = '#fff';
                    const im = document.createElement('img');
                    im.src = img.local_url || img.url;
                    im.style.width = '100%';
                    im.style.height = '180px';
                    im.style.objectFit = 'cover';
                    card.appendChild(im);
                    const p = document.createElement('p');
                    p.textContent = 'KI-Ergebnis ' + (index + 1);
                    card.appendChild(p);
                    const b1 = document.createElement('button');
                    b1.type = 'button';
                    b1.className = 'button';
                    b1.textContent = img.attachment_id ? 'Bereits in Mediathek' : 'In Mediathek laden';
                    b1.onclick = async (event) => { event.preventDefault(); event.stopPropagation(); b1.disabled = true; try { const d = await call('hbbz_term_import', {index:String(index)}); status.className='notice notice-success inline'; status.innerHTML = '<strong>Status:</strong> ' + d.message; showImages(d);} catch(e) { status.className='notice notice-error inline'; status.innerHTML = '<strong>Fehler:</strong> ' + e.message; b1.disabled=false; } };
                    card.appendChild(b1);
                    const b2 = document.createElement('button');
                    b2.type = 'button';
                    b2.className = 'button button-primary';
                    b2.style.marginLeft = '6px';
                    b2.textContent = img.is_assigned ? (entityType()==='page' ? 'Bereits als Seitenbild aktiv' : (entityType()==='post' ? 'Bereits als Hero aktiv' : 'Bereits als Kategoriebild aktiv')) : (entityType()==='page' ? 'Als Seitenbild übernehmen' : (entityType()==='post' ? 'Als Hero übernehmen' : 'Als Kategoriebild übernehmen'));
                    b2.onclick = async (event) => { event.preventDefault(); event.stopPropagation(); if(!confirm('Vorhandenes Bild jetzt bewusst ersetzen? Der bisherige Wert wird gesichert und nach dem Speichern technisch zurückgelesen.')) return; b2.disabled=true; try { const d = await call('hbbz_term_apply', {index:String(index)}); status.className='notice notice-success inline'; status.innerHTML = '<strong>Status:</strong> ' + d.message; showImages(d);} catch(e) { status.className='notice notice-error inline'; status.innerHTML = '<strong>Fehler:</strong> ' + e.message; b2.disabled=false; } };
                    card.appendChild(b2);
                    results.appendChild(card);
                });
            }
            if (prefix === 'wp' || prefix === 'cpt') {
                const search = document.getElementById('hbbz-term-' + prefix + '-search');
                const searchResults = document.getElementById('hbbz-term-' + prefix + '-search-results');
                const selected = document.getElementById('hbbz-term-' + prefix + '-selected');
                let timer = null;
                if (search) search.addEventListener('input', function(){
                    clearTimeout(timer); const query = search.value.trim();
                    if (query.length < 2) { searchResults.innerHTML = ''; return; }
                    timer = setTimeout(async function(){
                        searchResults.innerHTML = '<p>Suche läuft …</p>';
                        try {
                            const body = new URLSearchParams({action:'hbbz_term_search',nonce:nonce,profile:profile,taxonomy:taxonomy,entity_type:entityType(),query:query});
                            const response = await fetch(ajaxurl,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()});
                            const json = await response.json(); if(!json.success) throw new Error(typeof json.data==='string'?json.data:'Suche fehlgeschlagen');
                            searchResults.innerHTML = '';
                            (json.data.items || []).forEach(function(item){
                                const button=document.createElement('button');button.type='button';button.className='button hbbz-term-search-choice';button.textContent=(item.label||'Eintrag')+': '+item.path+' (#'+item.item_id+')';
                                button.addEventListener('click',function(){document.getElementById('hbbz-term-' + prefix + '-term').value=String(item.item_id);const entity=document.getElementById('hbbz-term-' + prefix + '-entity');if(entity)entity.value=String(item.entity_type||entityType());selected.innerHTML='<strong>Ausgewähltes Ziel:</strong> '+(item.label||'Eintrag')+': '+item.path+' <code>#'+item.item_id+'</code>';searchResults.innerHTML='';search.value=item.name;});
                                searchResults.appendChild(button);
                            });
                            if(!(json.data.items||[]).length) searchResults.innerHTML='<p>Kein passendes Ziel gefunden.</p>'; 
                        } catch(e) { searchResults.innerHTML='<p><strong>Fehler:</strong> '+e.message+'</p>'; }
                    },250);
                });
            }
            const normalizeCurrent = document.getElementById('hbbz-term-' + prefix + '-normalize-current');
            const normalizeBatch = document.getElementById('hbbz-term-' + prefix + '-normalize-batch');
            if (normalizeCurrent) normalizeCurrent.onclick = async () => { try { if(!termId()) throw new Error('Bitte zuerst ein Ziel auswählen.'); if(!confirm('Aktuelles Bild optimieren und danach auf die optimierte Version umstellen? Das Original bleibt erhalten.')) return; status.innerHTML='<strong>Status:</strong> Normalisierung läuft …'; const d=await call('hbbz_term_normalize_current'); status.innerHTML='<strong>Status:</strong> '+d.message; } catch(e){status.innerHTML='<strong>Fehler:</strong> '+e.message;} };
            if (normalizeBatch) normalizeBatch.onclick = async () => { try { const question=entityType()==='page' ? 'Bis zu 10 bestehende WordPress-Seitenbilder normalisieren? Originale bleiben erhalten.' : (entityType()==='post' ? 'Bis zu 10 bestehende Hero-Bilder des konfigurierten Post Types normalisieren? Originale bleiben erhalten.' : 'Bis zu 10 bestehende Kategoriebilder dieses Bereichs normalisieren? Originale bleiben erhalten.'); if(!confirm(question)) return; status.innerHTML='<strong>Status:</strong> Stapel-Normalisierung läuft …'; const d=await call('hbbz_term_normalize_batch'); status.innerHTML='<strong>Status:</strong> '+d.message; } catch(e){status.innerHTML='<strong>Fehler:</strong> '+e.message;} };

            const preview = document.getElementById('hbbz-term-' + prefix + '-preview');
            const generate = document.getElementById('hbbz-term-' + prefix + '-generate');
            const check = document.getElementById('hbbz-term-' + prefix + '-check');
            if (preview) preview.onclick = async () => { try { status.innerHTML = '<strong>Status:</strong> Prompt wird erstellt …'; const d = await call('hbbz_term_prompt'); document.getElementById('hbbz-term-' + prefix + '-prompt').value = d.prompt || ''; status.innerHTML = '<strong>Status:</strong> Prompt bereit · ' + (d.length || 0) + '/3000 Zeichen'; } catch(e) { status.innerHTML = '<strong>Fehler:</strong> ' + e.message; } };
            if (generate) generate.onclick = async () => { try { if (!confirm('1 Magnific-KI-Bild erzeugen? Dies verbraucht Credits.')) return; status.innerHTML = '<strong>Status:</strong> Auftrag wird gestartet …'; const d = await call('hbbz_term_generate', {prompt: currentPrompt()}); status.innerHTML = '<strong>Status:</strong> Auftrag gestartet · Task ' + d.task_id; } catch(e) { status.innerHTML = '<strong>Fehler:</strong> ' + e.message; } };
            if (check) check.onclick = async () => { try { status.innerHTML = '<strong>Status:</strong> Wird geprüft …'; const d = await call('hbbz_term_check'); status.innerHTML = '<strong>Status:</strong> ' + (d.message || d.status); showImages(d); } catch(e) { status.innerHTML = '<strong>Fehler:</strong> ' + e.message; } };

        })();
        </script>
        <?php if (!$is_wp && !$is_cpt): self::render_hivepress_category_overview($taxonomy_value, $meta_key_value); endif; ?>
    </div>
    <?php
}

private static function term_context(string $taxonomy, int $term_id, string $entity_type='term') {
        if ($entity_type === 'page' || $entity_type === 'post') {
            $post = get_post($term_id);
            $expected_type = $entity_type === 'page' ? 'page' : sanitize_key($taxonomy);
            if ($expected_type === '' || !$post instanceof WP_Post || $post->post_type !== $expected_type) {
                return new WP_Error($entity_type === 'page' ? 'hbbz_page_missing' : 'hbbz_post_missing', $entity_type === 'page' ? 'Seite wurde nicht gefunden.' : 'Inhalt des konfigurierten Post Types wurde nicht gefunden.');
            }
            return ['term'=>$post,'path'=>self::post_path($post,$expected_type),'description'=>wp_strip_all_tags((string)$post->post_excerpt.' '.$post->post_content),'entity_type'=>$entity_type,'name'=>(string)$post->post_title];
        }
        if ($taxonomy === '' || !taxonomy_exists($taxonomy)) return new WP_Error('hbbz_taxonomy_missing','Taxonomie ist nicht verfügbar.');
        $term = get_term($term_id, $taxonomy);
        if (!$term instanceof WP_Term) return new WP_Error('hbbz_term_missing','Kategorie wurde nicht gefunden.');
        $names = [$term->name]; $parent = (int)$term->parent; $guard=0;
        while($parent>0 && $guard++<20){$ancestor=get_term($parent,$taxonomy);if(!$ancestor instanceof WP_Term)break;array_unshift($names,$ancestor->name);$parent=(int)$ancestor->parent;}
        return ['term'=>$term,'path'=>implode(' > ',$names),'description'=>wp_strip_all_tags((string)$term->description),'entity_type'=>'term','name'=>(string)$term->name];
    }

    private static function term_profile_and_config(string $profile_key): array {
        $profiles=self::general_profiles(); $config=self::sanitize_taxonomy_config((array)get_option(self::OPTION_TAXONOMY_CONFIG,[]));
        if(!isset($profiles[$profile_key]) || !in_array($profile_key,['category','post_type_hero','hivepress'],true)) return [];
        if($profile_key==='post_type_hero') return ['profile'=>$profiles[$profile_key],'taxonomy'=>$config['hero_post_type'],'meta_key'=>'_thumbnail_id','entity_type'=>'post'];
        if($profile_key==='hivepress') return ['profile'=>$profiles[$profile_key],'taxonomy'=>$config['hivepress_taxonomy'],'meta_key'=>$config['hivepress_image_meta_key'],'entity_type'=>'term'];
        return ['profile'=>$profiles[$profile_key],'taxonomy'=>$config['wordpress_taxonomy'],'meta_key'=>$config['wordpress_image_meta_key'],'entity_type'=>'term','page_meta_key'=>'_thumbnail_id'];
    }

    private static function profile_scope_matches(array $pc,string $taxonomy,string $entity_type): bool {
        if(!$pc)return false;
        if($entity_type==='page')return isset($pc['profile']) && (string)($pc['entity_type']??'term')==='term';
        if($entity_type==='post')return (string)($pc['entity_type']??'')==='post' && $taxonomy!=='' && (string)($pc['taxonomy']??'')===$taxonomy && post_type_exists($taxonomy);
        return (string)($pc['entity_type']??'term')==='term' && $taxonomy!=='' && (string)($pc['taxonomy']??'')===$taxonomy && taxonomy_exists($taxonomy);
    }

    private static function build_term_prompt(string $profile_key,string $taxonomy,int $term_id,string $custom='',string $entity_type='term') {
        $pc=self::term_profile_and_config($profile_key); if(!$pc)return new WP_Error('hbbz_profile','Ungültiges Bildprofil.');
        if(!self::profile_scope_matches($pc,$taxonomy,$entity_type))return new WP_Error('hbbz_scope_mismatch','Zieltyp passt nicht zum gespeicherten Bildprofil.');
        $ctx=self::term_context($taxonomy,$term_id,$entity_type); if(is_wp_error($ctx))return $ctx; $p=$pc['profile'];
        $is_page=$entity_type==='page';$is_post=$entity_type==='post';$runtime_output=self::term_output_profile($profile_key);
        $hierarchy_label=$is_page?'Page hierarchy: ':($is_post?'Content path: ':'Category hierarchy: ');
        $name_label=$is_page?'Page title: ':($is_post?'Content title: ':'Category name: ');
        $context_label=$is_page?'Page context: ':($is_post?'Content context: ':'Category description: ');
        $parts=[self::default_visual_policy(),trim($p['base_prompt']),trim($p['color_direction']),trim($p['subject_rule']),$hierarchy_label.'"'.$ctx['path'].'".',$name_label.'"'.$ctx['name'].'".'];
        if((string)$runtime_output['ratio']==='3:1')$parts[]='Final output is an exact 3:1 banner at 1200 by 400 pixels. Keep every essential subject safely inside the central horizontal band and away from the upper and lower edges so the final 3:1 crop removes no important content.';
        if((string)$runtime_output['ratio']==='21:9')$parts[]='Final output remains in the native 21:9 hero ratio. Preserve the complete generated composition; no secondary 3:1 crop is permitted.';
        if($ctx['description']!=='')$parts[]=$context_label.'"'.self::utf8_substr($ctx['description'],0,700).'".';
        if(trim($custom)!=='')$parts[]='Highest-priority editor instruction: "'.self::utf8_substr(trim($custom),0,500).'". The instruction may be written in German; interpret its meaning accurately, but never render written words in the image. This instruction overrides incidental wording but must remain compatible with the selected target.';
        $parts[]='Negative rules: '.trim($p['negative_prompt']).'.'; $parts[]='Landscape composition, '.$runtime_output['ratio'].'. No written words.';
        $prompt=preg_replace('/\s+/u',' ',implode(' ',$parts));
        return self::limit_generated_prompt((string)$prompt);
    }

    private static function limit_generated_prompt(string $prompt): string {
        $prompt = preg_replace('/\s+/u', ' ', trim($prompt)) ?: trim($prompt);
        if (self::utf8_len($prompt) <= self::MAX_GENERATED_PROMPT_CHARS) {
            return $prompt;
        }

        $tail = self::GENERATED_PROMPT_SAFETY_TAIL;
        $tail_length = self::utf8_len($tail);
        $prefix_length = max(0, self::MAX_GENERATED_PROMPT_CHARS - $tail_length);
        $prefix = rtrim(self::utf8_substr($prompt, 0, $prefix_length));
        $limited = $prefix . $tail;

        // Defensive final clamp: even a future tail change must never produce
        // a prompt above the provider and validation limit.
        if (self::utf8_len($limited) > self::MAX_GENERATED_PROMPT_CHARS) {
            $limited = self::utf8_substr($limited, 0, self::MAX_GENERATED_PROMPT_CHARS);
        }
        return trim($limited);
    }

    private static function term_ajax_input(): array {
        $profile=sanitize_key((string)($_POST['profile']??''));$taxonomy=sanitize_key((string)($_POST['taxonomy']??''));$term_id=absint($_POST['term_id']??0);$entity_type=sanitize_key((string)($_POST['entity_type']??'term'));if(!in_array($entity_type,['term','page','post'],true))$entity_type='term';$custom=sanitize_textarea_field(wp_unslash((string)($_POST['custom']??'')));
        return compact('profile','taxonomy','term_id','custom','entity_type');
    }

    public static function term_prompt(): void { self::assert_ajax_access();$i=self::term_ajax_input();$prompt=self::build_term_prompt($i['profile'],$i['taxonomy'],$i['term_id'],$i['custom'],$i['entity_type']);if(is_wp_error($prompt))wp_send_json_error($prompt->get_error_message());wp_send_json_success(['prompt'=>$prompt,'length'=>self::utf8_len($prompt)]); }

    public static function term_generate(): void {
        self::assert_ajax_access();$i=self::term_ajax_input();$prompt=sanitize_textarea_field(wp_unslash((string)($_POST['prompt']??'')));if($prompt===''){$prompt=self::build_term_prompt($i['profile'],$i['taxonomy'],$i['term_id'],$i['custom'],$i['entity_type']);}
        if(is_wp_error($prompt))wp_send_json_error($prompt->get_error_message());$len=self::utf8_len($prompt);if($len<2||$len>self::MAX_GENERATED_PROMPT_CHARS)wp_send_json_error('Der Prompt muss 2 bis '.self::MAX_GENERATED_PROMPT_CHARS.' Zeichen lang sein.');
        // Neue Bildaufträge werden wie im Beitragsweg direkt per POST gestartet.
        // Ein separater GET-Tasklisten-Preflight darf eine gültige Erzeugung nicht blockieren.
        $pc=self::term_profile_and_config($i['profile']);if(!$pc||!self::profile_scope_matches($pc,$i['taxonomy'],$i['entity_type']))wp_send_json_error('Profil oder Zieltyp ist ungültig.');$ctx=self::term_context($i['taxonomy'],$i['term_id'],$i['entity_type']);if(is_wp_error($ctx))wp_send_json_error($ctx->get_error_message());$runtime_output=self::term_output_profile($i['profile']);$ratio=(string)$runtime_output['ratio'];$magnific_ratio=$ratio==='3:1'?'21:9':$ratio;$allowed_magnific_ratios=['1:1','2:3','3:2','4:3','3:4','5:4','4:5','16:9','9:16','21:9'];if(!in_array($magnific_ratio,$allowed_magnific_ratios,true))$magnific_ratio='16:9';$payload=['prompt'=>$prompt,'aspect_ratio'=>$magnific_ratio,'resolution'=>'1K','use_google_search_tool'=>false];$response=self::magnific_request('POST','/v1/ai/text-to-image/nano-banana-pro-flash',$payload);if(is_wp_error($response))wp_send_json_error($response->get_error_message());$data=self::magnific_response_data($response);$task_id=(string)($data['task_id']??'');if($task_id==='')wp_send_json_error('Magnific lieferte keine Task-ID.');
        $task=['task_id'=>$task_id,'status'=>strtoupper((string)($data['status']??'CREATED')),'prompt'=>$prompt,'created_at_utc'=>gmdate('c'),'profile'=>$i['profile'],'taxonomy'=>$i['taxonomy'],'term_id'=>$i['term_id'],'entity_type'=>$i['entity_type']];
        $previous_results=self::term_results($i['taxonomy'],$i['term_id'],$i['entity_type']);
        if(!empty($previous_results['images'])){
            $history=self::get_context_meta($i['entity_type'],$i['term_id'],'_hbbz_magnific_results_history',true);if(!is_array($history))$history=[];
            $history[]=['archived_at_utc'=>gmdate('c'),'results'=>$previous_results];
            if(count($history)>20)$history=array_slice($history,-20);
            self::update_context_meta($i['entity_type'],$i['term_id'],'_hbbz_magnific_results_history',$history);
        }
        self::delete_context_meta($i['entity_type'],$i['term_id'],'_hbbz_magnific_results');
        self::update_context_meta($i['entity_type'],$i['term_id'],'_hbbz_magnific_tasks',[$task]);
        $map=get_option(self::OPTION_TERM_TASK_MAP,[]);if(!is_array($map))$map=[];$map[$task_id]=['taxonomy'=>$i['taxonomy'],'term_id'=>$i['term_id'],'profile'=>$i['profile'],'entity_type'=>$i['entity_type']];update_option(self::OPTION_TERM_TASK_MAP,$map,false);
        wp_send_json_success(['task_id'=>$task_id,'status'=>$task['status'],'message'=>'Neuer KI-Auftrag gestartet. Ein vorheriges Ergebnis wird nicht mehr als aktuelles Ergebnis angezeigt.']);
    }

    private static function term_results(string $taxonomy,int $term_id,string $entity_type='term'): array {$v=self::get_context_meta($entity_type,$term_id,'_hbbz_magnific_results',true);return is_array($v)?$v:[];}
    public static function term_check(): void {
        self::assert_ajax_access();$i=self::term_ajax_input();$ctx=self::term_context($i['taxonomy'],$i['term_id'],$i['entity_type']);if(is_wp_error($ctx))wp_send_json_error($ctx->get_error_message());
        $tasks=self::get_context_meta($i['entity_type'],$i['term_id'],'_hbbz_magnific_tasks',true);if(!is_array($tasks)||empty($tasks[0]['task_id']))wp_send_json_success(['status'=>'NO_TASK','message'=>$i['entity_type']==='page'?'Für diese Seite ist kein Auftrag gespeichert.':($i['entity_type']==='post'?'Für diesen Inhalt ist kein Hero-Auftrag gespeichert.':'Für diese Kategorie ist kein Auftrag gespeichert.'),'images'=>[]]);
        $task=$tasks[0];$active_task_id=(string)$task['task_id'];
        $existing=self::term_results($i['taxonomy'],$i['term_id'],$i['entity_type']);
        $existing_images=is_array($existing['images']??null)?$existing['images']:[];
        $matching_images=array_values(array_filter($existing_images,static fn($image):bool=>is_array($image)&&((string)($image['task_id']??''))===$active_task_id));
        if($matching_images)wp_send_json_success(['status'=>'COMPLETED','message'=>'Bild des aktuellen Auftrags ist fertig und auswählbar.','images'=>$matching_images]);
        $detail=self::magnific_request('GET','/v1/ai/text-to-image/nano-banana-pro-flash/'.rawurlencode($active_task_id));if(is_wp_error($detail))wp_send_json_error($detail->get_error_message());$d=self::magnific_response_data($detail);$status=strtoupper((string)($d['status']??'UNKNOWN'));$task['status']=$status;$task['checked_at_utc']=gmdate('c');self::update_context_meta($i['entity_type'],$i['term_id'],'_hbbz_magnific_tasks',[$task]);$images=[];if($status==='COMPLETED')foreach((array)($d['generated']??[]) as $url)if(is_string($url)&&preg_match('#^https?://#i',$url))$images[]=['url'=>$url,'task_id'=>$active_task_id,'label'=>$i['entity_type']==='post'?'KI-Hero':'KI-Kategoriebild'];if($images){$stored=['status'=>'COMPLETED','prompt'=>(string)$task['prompt'],'task_id'=>$active_task_id,'images'=>$images,'updated_at_utc'=>gmdate('c')];self::update_context_meta($i['entity_type'],$i['term_id'],'_hbbz_magnific_results',$stored);wp_send_json_success(['status'=>'COMPLETED','message'=>'Bild des aktuellen Auftrags ist fertig und auswählbar.','images'=>$images]);}wp_send_json_success(['status'=>$status,'message'=>'Neuer Auftrag läuft. Magnific-Status: '.$status,'images'=>[]]);
    }


    private static function term_output_profile(string $profile_key): array {
        $profiles=self::general_profiles();$profile=is_array($profiles[$profile_key]??null)?$profiles[$profile_key]:[];
        $preset_key=self::infer_format_preset($profile);$presets=self::image_format_presets();$preset=$presets[$preset_key]??$presets['3:1'];
        return ['ratio'=>$preset_key,'width'=>(int)$preset['width'],'height'=>(int)$preset['height'],'quality'=>max(50,min(90,absint($profile['webp_quality']??76))),'target_bytes'=>max(40,absint($profile['target_kb']??120))*1024];
    }

    private static function prepare_term_editor($editor,array $output,string $profile_key='') {
        $size=$editor->get_size();if(!is_array($size)||empty($size['width'])||empty($size['height']))return new WP_Error('hbbz_image_size','Bildgröße konnte nicht gelesen werden.');
        if($profile_key==='post_type_hero' && (string)($output['ratio']??'')==='21:9'){
            $full=$editor->crop(0,0,(int)$size['width'],(int)$size['height'],(int)$output['width'],(int)$output['height'],false);
            if(is_wp_error($full))return $full;return true;
        }
        $geometry=self::calculate_crop_geometry((int)$size['width'],(int)$size['height'],(int)$output['width'],(int)$output['height']);if(is_wp_error($geometry))return $geometry;
        $crop=$editor->crop($geometry['src_x'],$geometry['src_y'],$geometry['crop_width'],$geometry['crop_height'],(int)$output['width'],(int)$output['height'],false);if(is_wp_error($crop))return $crop;return true;
    }

    private static function save_term_webp($editor,string $dest,array $output) {
        $quality=(int)$output['quality'];$saved=null;$qualities=array_values(array_unique([$quality,max(50,$quality-6),max(50,$quality-12),max(50,$quality-18)]));
        foreach($qualities as $q){if(method_exists($editor,'set_quality'))$editor->set_quality($q);$saved=$editor->save($dest,'image/webp');if(is_wp_error($saved))return $saved;if(is_file($dest)&&filesize($dest)<=(int)$output['target_bytes'])break;}return $saved;
    }


    private static function validate_physical_output(string $path,array $output) {
        if($path===''||!is_file($path))return new WP_Error('hbbz_output_missing','Die erzeugte Bilddatei wurde nicht gefunden.');
        $size=@getimagesize($path);if(!is_array($size)||empty($size[0])||empty($size[1]))return new WP_Error('hbbz_output_unreadable','Die realen Bildmaße konnten nicht gelesen werden.');
        $width=(int)$size[0];$height=(int)$size[1];$mime=(string)($size['mime']??'');
        if($width!==(int)$output['width']||$height!==(int)$output['height'])return new WP_Error('hbbz_output_dimensions','Reale Datei ist '.$width.' × '.$height.' statt gefordert '.(int)$output['width'].' × '.(int)$output['height'].'. Es wurde nichts zugeordnet.');
        if($mime!==''&&$mime!=='image/webp')return new WP_Error('hbbz_output_mime','Reale Datei ist '.$mime.' statt image/webp. Es wurde nichts zugeordnet.');
        $bytes=(int)@filesize($path);if($bytes<1)return new WP_Error('hbbz_output_empty','Die erzeugte Bilddatei ist leer. Es wurde nichts zugeordnet.');
        return ['width'=>$width,'height'=>$height,'mime'=>$mime!==''?$mime:'image/webp','bytes'=>$bytes,'path'=>$path];
    }

    private static function validate_attachment_output(int $attachment_id,array $output) {
        if($attachment_id<=0||get_post_type($attachment_id)!=='attachment'||!wp_attachment_is_image($attachment_id))return new WP_Error('hbbz_attachment_invalid','Die Medien-ID ist kein gültiges Bild-Attachment.');
        $path=get_attached_file($attachment_id);if(!is_string($path)||$path==='')return new WP_Error('hbbz_attachment_file_missing','Zur Medien-ID wurde keine reale Datei gefunden.');
        $physical=self::validate_physical_output($path,$output);if(is_wp_error($physical))return $physical;
        $meta=wp_get_attachment_metadata($attachment_id);if(!is_array($meta))return new WP_Error('hbbz_attachment_meta_missing','WordPress-Attachment-Metadaten fehlen. Es wurde nichts zugeordnet.');
        $meta_width=(int)($meta['width']??0);$meta_height=(int)($meta['height']??0);
        if($meta_width!==(int)$output['width']||$meta_height!==(int)$output['height'])return new WP_Error('hbbz_attachment_meta_dimensions','WordPress-Metadaten melden '.$meta_width.' × '.$meta_height.' statt gefordert '.(int)$output['width'].' × '.(int)$output['height'].'. Es wurde nichts zugeordnet.');
        return array_merge($physical,['attachment_id'=>$attachment_id,'meta_width'=>$meta_width,'meta_height'=>$meta_height]);
    }

    private static function find_valid_existing_asset(string $asset,array $output): int {
        $ids=get_posts(['post_type'=>'attachment','post_status'=>'inherit','posts_per_page'=>-1,'fields'=>'ids','meta_key'=>'_hbbz_asset_id','meta_value'=>$asset]);
        foreach((array)$ids as $candidate){$id=(int)$candidate;$valid=self::validate_attachment_output($id,$output);if(!is_wp_error($valid))return $id;}
        return 0;
    }

    private static function term_path(WP_Term $term,string $taxonomy): string {
        $names=[$term->name];$parent=(int)$term->parent;$guard=0;while($parent>0&&$guard++<30){$ancestor=get_term($parent,$taxonomy);if(!$ancestor instanceof WP_Term)break;array_unshift($names,$ancestor->name);$parent=(int)$ancestor->parent;}return implode(' › ',$names);
    }


    private static function post_path(WP_Post $post,string $expected_type=''): string {
        $type=$expected_type!==''?sanitize_key($expected_type):(string)$post->post_type;
        $names=[$post->post_title];$parent=(int)$post->post_parent;$guard=0;
        while($parent>0&&$guard++<30){$ancestor=get_post($parent);if(!$ancestor instanceof WP_Post||($type!==''&&$ancestor->post_type!==$type))break;array_unshift($names,$ancestor->post_title);$parent=(int)$ancestor->post_parent;}
        return implode(' › ',$names);
    }

    private static function page_path(WP_Post $post): string {
        return self::post_path($post,'page');
    }

    private static function is_post_entity(string $entity_type): bool {
        return in_array($entity_type,['page','post'],true);
    }

    private static function get_context_meta(string $entity_type,int $object_id,string $meta_key,bool $single=true) {
        return self::is_post_entity($entity_type) ? get_post_meta($object_id,$meta_key,$single) : get_term_meta($object_id,$meta_key,$single);
    }

    private static function update_context_meta(string $entity_type,int $object_id,string $meta_key,$value): bool {
        return self::is_post_entity($entity_type) ? (bool)update_post_meta($object_id,$meta_key,$value) : (bool)update_term_meta($object_id,$meta_key,$value);
    }

    private static function delete_context_meta(string $entity_type,int $object_id,string $meta_key): bool {
        return self::is_post_entity($entity_type) ? (bool)delete_post_meta($object_id,$meta_key) : (bool)delete_term_meta($object_id,$meta_key);
    }

    private static function context_attachment_id(string $entity_type,int $object_id,string $meta_key): int {
        if(self::is_post_entity($entity_type)){return (int)get_post_thumbnail_id($object_id);}return absint(get_term_meta($object_id,$meta_key,true));
    }

    private static function set_context_attachment_id(string $entity_type,int $object_id,string $meta_key,int $attachment_id): bool {
        if(self::is_post_entity($entity_type)){return set_post_thumbnail($object_id,$attachment_id);}return (bool)update_term_meta($object_id,$meta_key,$attachment_id);
    }

    private static function clear_context_attachment_id(string $entity_type,int $object_id,string $meta_key): void {
        if(self::is_post_entity($entity_type)){delete_post_thumbnail($object_id);} else {delete_term_meta($object_id,$meta_key);}    
    }

    public static function term_search(): void {
        self::assert_ajax_access();
        $profile=sanitize_key((string)($_POST['profile']??'category'));
        $taxonomy=sanitize_key((string)($_POST['taxonomy']??''));
        $entity_type=sanitize_key((string)($_POST['entity_type']??'term'));
        $query=sanitize_text_field(wp_unslash((string)($_POST['query']??'')));
        if(self::utf8_len(trim($query))<2)wp_send_json_success(['items'=>[]]);
        $pc=self::term_profile_and_config($profile);
        if($entity_type==='post'){
            if(!$pc||!self::profile_scope_matches($pc,$taxonomy,'post'))wp_send_json_error('Nur der gespeicherte Post Type darf durchsucht werden.');
            $object=get_post_type_object($taxonomy);$label=(string)($object->labels->singular_name??$object->label??'Inhalt');$items=[];
            $posts=get_posts(['post_type'=>$taxonomy,'post_status'=>['publish','draft','private'],'posts_per_page'=>30,'s'=>$query,'orderby'=>'title','order'=>'ASC']);
            foreach($posts as $post){if(!$post instanceof WP_Post||$post->post_type!==$taxonomy)continue;$items[]=['item_id'=>(int)$post->ID,'entity_type'=>'post','label'=>$label,'name'=>(string)$post->post_title,'path'=>self::post_path($post,$taxonomy)];}
            wp_send_json_success(['items'=>$items]);
        }
        $config=self::sanitize_taxonomy_config((array)get_option(self::OPTION_TAXONOMY_CONFIG,[]));
        if($taxonomy===''||$taxonomy!==$config['wordpress_taxonomy']||!taxonomy_exists($taxonomy))wp_send_json_error('Nur die gespeicherte WordPress-Taxonomie darf durchsucht werden.');
        $items=[];$terms=get_terms(['taxonomy'=>$taxonomy,'hide_empty'=>false,'number'=>20,'search'=>$query]);if(is_wp_error($terms))wp_send_json_error($terms->get_error_message());foreach($terms as $term){if(!$term instanceof WP_Term)continue;$items[]=['item_id'=>(int)$term->term_id,'entity_type'=>'term','label'=>'Kategorie','name'=>(string)$term->name,'path'=>self::term_path($term,$taxonomy)];}
        $pages=get_posts(['post_type'=>'page','post_status'=>['publish','draft','private'],'posts_per_page'=>20,'s'=>$query,'orderby'=>'title','order'=>'ASC']);foreach($pages as $page){if(!$page instanceof WP_Post)continue;$items[]=['item_id'=>(int)$page->ID,'entity_type'=>'page','label'=>'Seite','name'=>(string)$page->post_title,'path'=>self::page_path($page)];}
        usort($items,static function($a,$b){return strcasecmp((string)$a['path'],(string)$b['path']);});wp_send_json_success(['items'=>array_slice($items,0,30)]);
    }

    private static function normalize_term_attachment(string $profile,string $taxonomy,int $term_id,int $source_id,string $entity_type='term') {
        if($source_id<=0||get_post_type($source_id)!=='attachment'||!wp_attachment_is_image($source_id))return new WP_Error('hbbz_source_image','Das aktuelle Termbild ist keine gültige Bild-Attachment-ID.');
        $ctx=self::term_context($taxonomy,$term_id,$entity_type);if(is_wp_error($ctx))return $ctx;$output=self::term_output_profile($profile);$format_key='fmt'.$output['width'].'x'.$output['height'].'-'.sanitize_key(str_replace(':','x',(string)$output['ratio'])).'-v270';$entity_key=$entity_type==='page'?'page':($entity_type==='post'?'post':'term');$asset=$entity_key.'-normalized-'.sanitize_key($taxonomy).'-'.$term_id.'-'.$source_id.'-'.$format_key;
        $existing_id=self::find_valid_existing_asset($asset,$output);if($existing_id>0)return ['attachment_id'=>$existing_id,'already_existing'=>true,'verified'=>self::validate_attachment_output($existing_id,$output)];
        $source=get_attached_file($source_id);if(!is_string($source)||!is_file($source))return new WP_Error('hbbz_source_file','Originaldatei des Termbilds wurde nicht gefunden.');require_once ABSPATH.'wp-admin/includes/image.php';$editor=wp_get_image_editor($source);if(is_wp_error($editor))return $editor;$prepared=self::prepare_term_editor($editor,$output,$profile);if(is_wp_error($prepared))return $prepared;
        $upload=wp_upload_dir();if(!empty($upload['error']))return new WP_Error('hbbz_upload',$upload['error']);$filename=wp_unique_filename($upload['path'],sanitize_title($ctx['name']).'-optimiert-'.$output['width'].'x'.$output['height'].'.webp');$dest=trailingslashit($upload['path']).$filename;$saved=self::save_term_webp($editor,$dest,$output);if(is_wp_error($saved)||empty($saved['path']))return is_wp_error($saved)?$saved:new WP_Error('hbbz_save','Optimierte WebP-Datei konnte nicht gespeichert werden.');$physical=self::validate_physical_output($dest,$output);if(is_wp_error($physical)){if(is_file($dest))@unlink($dest);return $physical;}
        $title=$ctx['name'].' – optimiertes Bild';$id=wp_insert_attachment(['post_mime_type'=>'image/webp','post_title'=>$title,'post_status'=>'inherit'],$dest,0,true);if(is_wp_error($id))return $id;$meta=wp_generate_attachment_metadata($id,$dest);wp_update_attachment_metadata($id,is_array($meta)?$meta:[]);update_post_meta($id,'_wp_attachment_image_alt',$ctx['name']);update_post_meta($id,'_hbbz_asset_id',$asset);update_post_meta($id,'_hbbz_provider','local-normalization');update_post_meta($id,'_hbbz_source_attachment_id',$source_id);update_post_meta($id,'_hbbz_target_taxonomy',$entity_type==='term'?$taxonomy:'');if($entity_type==='page'){update_post_meta($id,'_hbbz_target_page_id',$term_id);} elseif($entity_type==='post'){update_post_meta($id,'_hbbz_target_post_id',$term_id);update_post_meta($id,'_hbbz_target_post_type',$taxonomy);} else {update_post_meta($id,'_hbbz_target_term_id',$term_id);}update_post_meta($id,'_hbbz_image_profile',$profile);update_post_meta($id,'_hbbz_output_width',(int)$output['width']);update_post_meta($id,'_hbbz_output_height',(int)$output['height']);update_post_meta($id,'_hbbz_output_ratio',(string)$output['ratio']);update_post_meta($id,'_hbbz_format_key',$format_key);update_post_meta($id,'_hbbz_output_bytes',(int)$physical['bytes']);$verified=self::validate_attachment_output((int)$id,$output);if(is_wp_error($verified)){wp_delete_attachment((int)$id,true);return $verified;}return ['attachment_id'=>(int)$id,'already_existing'=>false,'verified'=>$verified];
    }

    private static function apply_normalized_term_image(string $profile,string $taxonomy,int $term_id,string $meta_key,string $entity_type='term') {
        $old=self::context_attachment_id($entity_type,$term_id,$meta_key);$normalized=self::normalize_term_attachment($profile,$taxonomy,$term_id,$old,$entity_type);if(is_wp_error($normalized))return $normalized;$new=(int)$normalized['attachment_id'];if($new===$old)return ['attachment_id'=>$new,'already_existing'=>true,'unchanged'=>true];
        self::update_context_meta($entity_type,$term_id,'_hbbz_previous_image_'.sanitize_key($meta_key),$old);if(!self::set_context_attachment_id($entity_type,$term_id,$meta_key,$new))return new WP_Error('hbbz_normalize_apply','Das optimierte Bild konnte nicht übernommen werden.');$read=self::context_attachment_id($entity_type,$term_id,$meta_key);if($read!==$new){if($old>0)self::set_context_attachment_id($entity_type,$term_id,$meta_key,$old);else self::clear_context_attachment_id($entity_type,$term_id,$meta_key);return new WP_Error('hbbz_normalize_readback','Readback fehlgeschlagen. Das bisherige Bild wurde wiederhergestellt.');}return ['attachment_id'=>$new,'source_attachment_id'=>$old,'already_existing'=>!empty($normalized['already_existing']),'unchanged'=>false];
    }

    public static function term_normalize_current(): void {
        self::assert_ajax_access();$i=self::term_ajax_input();$pc=self::term_profile_and_config($i['profile']);if(!$pc||!self::profile_scope_matches($pc,$i['taxonomy'],$i['entity_type']))wp_send_json_error('Profil oder Zieltyp ist ungültig.');$key=(string)$pc['meta_key'];if($key==='')wp_send_json_error('Kein bestätigtes Bild-Metafeld gespeichert.');$result=self::apply_normalized_term_image($i['profile'],$i['taxonomy'],$i['term_id'],$key,$i['entity_type']);if(is_wp_error($result))wp_send_json_error($result->get_error_message());$output=self::term_output_profile($i['profile']);$verified=self::validate_attachment_output((int)$result['attachment_id'],$output);if(is_wp_error($verified))wp_send_json_error($verified->get_error_message());wp_send_json_success(['message'=>($i['entity_type']==='page'?'Geklappt: Seitenbild wurde real auf ':($i['entity_type']==='post'?'Geklappt: Hero-Bild wurde real auf ':'Geklappt: Kategoriebild wurde real auf ')).(int)$verified['width'].' × '.(int)$verified['height'].' '.(string)$verified['mime'].' normalisiert. Das Original bleibt in der Mediathek. Neue Medien-ID #'.(int)$result['attachment_id'].'.']);
    }

    public static function term_normalize_batch(): void {
        self::assert_ajax_access();$i=self::term_ajax_input();$pc=self::term_profile_and_config($i['profile']);if(!$pc||!self::profile_scope_matches($pc,$i['taxonomy'],$i['entity_type']))wp_send_json_error('Profil oder Zieltyp ist ungültig.');$key=(string)$pc['meta_key'];if($key==='')wp_send_json_error('Kein bestätigtes Bild-Metafeld gespeichert.');if($i['entity_type']==='page'||$i['entity_type']==='post'){ $target_post_type=$i['entity_type']==='page'?'page':$i['taxonomy'];$items=get_posts(['post_type'=>$target_post_type,'post_status'=>['publish','draft','private'],'posts_per_page'=>50,'meta_query'=>[['key'=>'_thumbnail_id','compare'=>'EXISTS']],'orderby'=>'ID','order'=>'ASC']); } else { $items=get_terms(['taxonomy'=>$i['taxonomy'],'hide_empty'=>false,'number'=>0,'fields'=>'ids']); if(is_wp_error($items))wp_send_json_error($items->get_error_message()); } $done=0;$skipped=0;$errors=[];
        foreach($items as $raw_item){if($done>=10)break;$object_id=self::is_post_entity($i['entity_type'])?(int)($raw_item instanceof WP_Post ? $raw_item->ID : 0):(int)$raw_item;if($object_id<=0){$skipped++;continue;}$current=self::context_attachment_id($i['entity_type'],$object_id,$key);if($current<=0){$skipped++;continue;}$profile_marker=(string)get_post_meta($current,'_hbbz_image_profile',true);$source_marker=absint(get_post_meta($current,'_hbbz_source_attachment_id',true));if($profile_marker===$i['profile']&&$source_marker>0){$current_valid=self::validate_attachment_output($current,self::term_output_profile($i['profile']));if(!is_wp_error($current_valid)){$skipped++;continue;}}$result=self::apply_normalized_term_image($i['profile'],$i['taxonomy'],$object_id,$key,$i['entity_type']);if(is_wp_error($result)){$errors[]='#'.$object_id.': '.$result->get_error_message();continue;}$done++;}
        $message=$done.($i['entity_type']==='page'?' bestehende Seitenbilder normalisiert; ':($i['entity_type']==='post'?' bestehende Hero-Bilder normalisiert; ':' bestehende Kategoriebilder normalisiert; ')).$skipped.' übersprungen.';if($errors)$message.=' Fehler: '.implode(' | ',array_slice($errors,0,3));wp_send_json_success(['message'=>$message,'done'=>$done,'skipped'=>$skipped,'errors'=>$errors]);
    }

    private static function import_term_image(string $profile,string $taxonomy,int $term_id,int $index,string $entity_type='term') {
        $ctx=self::term_context($taxonomy,$term_id,$entity_type);if(is_wp_error($ctx))return $ctx;
        $results=self::term_results($taxonomy,$term_id,$entity_type);$image=$results['images'][$index]??null;
        if(!is_array($image)||empty($image['url']))return new WP_Error('hbbz_term_image_missing','Gewähltes Kategoriebild ist nicht verfügbar.');
        $output=self::term_output_profile($profile);$format_key='fmt'.$output['width'].'x'.$output['height'].'-'.sanitize_key(str_replace(':','x',(string)$output['ratio'])).'-v270';$entity_key=$entity_type==='page'?'page':($entity_type==='post'?'post':'term');$asset=$entity_key.'-'.sanitize_key($taxonomy).'-'.$term_id.'-'.sanitize_key((string)($image['task_id']??'magnific')).'-'.$index.'-'.$format_key;
        $existing_id=self::find_valid_existing_asset($asset,$output);
        if($existing_id>0){
            $id=$existing_id;
            $results['images'][$index]['attachment_id']=$id;
            $results['images'][$index]['local_url']=wp_get_attachment_image_url($id,'medium_large')?:wp_get_attachment_url($id);
            self::update_context_meta($entity_type,$term_id,'_hbbz_magnific_results',$results);
            return ['attachment_id'=>$id,'already_existing'=>true,'verified'=>self::validate_attachment_output($id,$output)];
        }
        require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/image.php';
        $tmp=download_url((string)$image['url'],45);if(is_wp_error($tmp))return $tmp;
        try{
            $editor=wp_get_image_editor($tmp);if(is_wp_error($editor))return $editor;
            $prepared=self::prepare_term_editor($editor,$output,$profile);if(is_wp_error($prepared))return $prepared;
            $upload=wp_upload_dir();if(!empty($upload['error']))return new WP_Error('hbbz_upload',$upload['error']);
            $filename=wp_unique_filename($upload['path'],sanitize_title($ctx['name']).'-bild-'.$term_id.'.webp');$dest=trailingslashit($upload['path']).$filename;
            $saved=self::save_term_webp($editor,$dest,$output);if(is_wp_error($saved)||empty($saved['path']))return is_wp_error($saved)?$saved:new WP_Error('hbbz_save','WebP konnte nicht gespeichert werden.');$physical=self::validate_physical_output($dest,$output);if(is_wp_error($physical)){if(is_file($dest))@unlink($dest);return $physical;}
            $title=$ctx['name'].($entity_type==='page'?' – Seitenbild':($entity_type==='post'?' – Hero-Bild':' – Kategoriebild'));$id=wp_insert_attachment(['post_mime_type'=>'image/webp','post_title'=>$title,'post_status'=>'inherit'],$dest,0,true);if(is_wp_error($id))return $id;
            $meta=wp_generate_attachment_metadata($id,$dest);wp_update_attachment_metadata($id,is_array($meta)?$meta:[]);
            update_post_meta($id,'_wp_attachment_image_alt',$ctx['name']);update_post_meta($id,'_hbbz_asset_id',$asset);update_post_meta($id,'_hbbz_provider','magnific');update_post_meta($id,'_hbbz_target_taxonomy',$entity_type==='term'?$taxonomy:'');if($entity_type==='page'){update_post_meta($id,'_hbbz_target_page_id',$term_id);} elseif($entity_type==='post'){update_post_meta($id,'_hbbz_target_post_id',$term_id);update_post_meta($id,'_hbbz_target_post_type',$taxonomy);} else {update_post_meta($id,'_hbbz_target_term_id',$term_id);}update_post_meta($id,'_hbbz_image_profile',$profile);update_post_meta($id,'_hbbz_output_width',(int)$output['width']);update_post_meta($id,'_hbbz_output_height',(int)$output['height']);update_post_meta($id,'_hbbz_output_ratio',(string)$output['ratio']);update_post_meta($id,'_hbbz_format_key',$format_key);update_post_meta($id,'_hbbz_output_bytes',(int)$physical['bytes']);$verified=self::validate_attachment_output((int)$id,$output);if(is_wp_error($verified)){wp_delete_attachment((int)$id,true);return $verified;}
            $results['images'][$index]['attachment_id']=(int)$id;$results['images'][$index]['local_url']=wp_get_attachment_image_url((int)$id,'medium_large')?:wp_get_attachment_url((int)$id);self::update_context_meta($entity_type,$term_id,'_hbbz_magnific_results',$results);
            return ['attachment_id'=>(int)$id,'already_existing'=>false,'verified'=>$verified];
        }finally{if(is_string($tmp)&&is_file($tmp))@unlink($tmp);}
    }

    public static function term_import(): void {self::term_import_or_apply(false);} public static function term_apply(): void {self::term_import_or_apply(true);}
    private static function term_import_or_apply(bool $apply): void {
        self::assert_ajax_access();$i=self::term_ajax_input();$index=absint($_POST['index']??0);$pc=self::term_profile_and_config($i['profile']);
        if(!$pc||!self::profile_scope_matches($pc,$i['taxonomy'],$i['entity_type']))wp_send_json_error('Profil oder Zieltyp ist ungültig.');
        $import=self::import_term_image($i['profile'],$i['taxonomy'],$i['term_id'],$index,$i['entity_type']);if(is_wp_error($import))wp_send_json_error($import->get_error_message());
        $id=(int)$import['attachment_id'];$already_existing=!empty($import['already_existing']);$output=self::term_output_profile($i['profile']);$verified=self::validate_attachment_output($id,$output);if(is_wp_error($verified))wp_send_json_error($verified->get_error_message());$dimension_text=(int)$verified['width'].' × '.(int)$verified['height'].' '.(string)$verified['mime'];
        $message=$already_existing ? 'Bereits vorhanden und real geprüft: Medien-ID #'.$id.' · '.$dimension_text.'. Es wurde kein Duplikat angelegt.' : 'Geklappt und real geprüft: Medien-ID #'.$id.' · '.$dimension_text.' wurde neu in die Mediathek geladen.';
        if($apply){
            $key=(string)$pc['meta_key'];if($key==='')wp_send_json_error('Kein bestätigtes Bild-Metafeld gespeichert. Zuordnung bleibt fail-closed gesperrt.');
            $old=self::context_attachment_id($i['entity_type'],$i['term_id'],$key);
            if((int)$old===$id){
                $message=$i['entity_type']==='page' ? 'Bereits zugeordnet: Medien-ID #'.$id.' ist schon das aktive Seitenbild. Es wurde nichts verändert.' : ($i['entity_type']==='post' ? 'Bereits zugeordnet: Medien-ID #'.$id.' ist schon das aktive Hero-Bild. Es wurde nichts verändert.' : 'Bereits zugeordnet: Medien-ID #'.$id.' ist schon das aktive Kategoriebild. Es wurde nichts verändert.');
            } else {
                self::update_context_meta($i['entity_type'],$i['term_id'],'_hbbz_previous_image_'.sanitize_key($key),$old);
                if(!self::set_context_attachment_id($i['entity_type'],$i['term_id'],$key,$id))wp_send_json_error('Nicht geklappt: Bild konnte nicht übernommen werden.');$read=self::context_attachment_id($i['entity_type'],$i['term_id'],$key);
                if((int)$read!==$id){if($old>0)self::set_context_attachment_id($i['entity_type'],$i['term_id'],$key,(int)$old);else self::clear_context_attachment_id($i['entity_type'],$i['term_id'],$key);wp_send_json_error('Nicht geklappt: WordPress-Readback weicht ab. Vorheriger Wert wurde wiederhergestellt.');}$read_verified=self::validate_attachment_output((int)$read,$output);if(is_wp_error($read_verified)){if($old>0)self::set_context_attachment_id($i['entity_type'],$i['term_id'],$key,(int)$old);else self::clear_context_attachment_id($i['entity_type'],$i['term_id'],$key);wp_send_json_error('Nicht geklappt: Die real zurückgelesene Datei erfüllt das Format nicht. Vorheriger Wert wurde wiederhergestellt. '.$read_verified->get_error_message());}
                $message=$i['entity_type']==='page' ? 'Geklappt: Medien-ID #'.$id.' wurde als Seitenbild übernommen und real als '.$dimension_text.' geprüft.' : ($i['entity_type']==='post' ? 'Geklappt: Medien-ID #'.$id.' wurde als Hero-Bild übernommen und real als '.$dimension_text.' geprüft.' : 'Geklappt: Medien-ID #'.$id.' wurde als Kategoriebild übernommen und real als '.$dimension_text.' geprüft.');
            }
        }
        $results=self::term_results($i['taxonomy'],$i['term_id'],$i['entity_type']);
        foreach((array)($results['images']??[]) as $n=>$image){$attachment_id=absint($image['attachment_id']??0);$results['images'][$n]['is_assigned']=$attachment_id>0 && self::context_attachment_id($i['entity_type'],$i['term_id'],(string)$pc['meta_key'])===$attachment_id;}
        wp_send_json_success(['attachment_id'=>$id,'already_existing'=>$already_existing,'message'=>$message,'images'=>(array)($results['images']??[])]);
    }


    public static function register_rest_routes(): void {
        register_rest_route('hab-und-bewahr-bildzentrale/v1', '/magnific-webhook', [
            'methods' => 'POST',
            'callback' => [self::class, 'magnific_webhook'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function magnific_rebuild_prompt(): void {
        self::assert_ajax_access();
        $post = get_post(self::get_ajax_target_post_id());
        if (!$post instanceof WP_Post || $post->post_type !== 'post') {
            wp_send_json_error('Der gewählte Beitrag wurde nicht gefunden.');
        }
        $custom_motif = isset($_POST['custom_motif']) ? sanitize_text_field(wp_unslash($_POST['custom_motif'])) : '';
        $custom_motif = trim(self::utf8_substr($custom_motif, 0, 240));
        if ($custom_motif === '') {
            wp_send_json_error('Bitte eine freie Motivbeschreibung eingeben.');
        }
        $analysis = self::analyze_article_for_image($post, 'auto', $custom_motif);
        $variation = self::build_variation_plan($post, 'auto', $custom_motif);
        wp_send_json_success([
            'prompt' => self::suggest_magnific_prompt($post, 'auto', $custom_motif),
            'scene' => (string) ($analysis['scene'] ?? ''),
            'background' => (string) ($analysis['background'] ?? ''),
            'weather' => (string) ($analysis['weather'] ?? ''),
            'people' => (string) ($analysis['people'] ?? ''),
            'cluster_label' => (string) ($variation['cluster_label'] ?? ''),
            'variation_summary' => self::summarize_variation_plan($variation),
            'translated_motif' => (string) ($analysis['translated_motif'] ?? ''),
            'prompt_length' => self::utf8_len(self::suggest_magnific_prompt($post, 'auto', $custom_motif)),
        ]);
    }

    public static function magnific_generate(): void {
        self::assert_ajax_access();
        $post = get_post(self::get_ajax_target_post_id());
        if (!$post instanceof WP_Post || $post->post_type !== 'post') {
            wp_send_json_error('Der gewählte Beitrag wurde nicht gefunden.');
        }
        $prompt = isset($_POST['prompt']) ? sanitize_textarea_field(wp_unslash($_POST['prompt'])) : self::suggest_magnific_prompt($post);
        $variants = isset($_POST['variants']) ? max(1, min(3, absint($_POST['variants']))) : 2;
        $custom_motif = isset($_POST['custom_motif']) ? sanitize_text_field(wp_unslash($_POST['custom_motif'])) : '';
        $custom_motif = trim(self::utf8_substr($custom_motif, 0, 240));
        if (self::utf8_len($prompt) < 2 || self::utf8_len($prompt) > 3000) {
            wp_send_json_error('Der Prompt muss 2 bis 3000 Zeichen lang sein.');
        }

        // Kein GET-"Preflight" auf dem Tasklisten-Endpunkt: Laut Magnific ist
        // ausschließlich POST der Erzeugungsaufruf. Ein leerer oder fehlerhafter
        // Tasklisten-Abruf darf eine gültige Erzeugung nicht blockieren.
        $tasks = [];
        for ($i = 0; $i < $variants; $i++) {
            $task = self::start_magnific_task($post->ID, $prompt, self::build_variation_plan($post, 'auto', $custom_motif));
            if (is_wp_error($task)) {
                if ($tasks) {
                    $persisted = self::persist_magnific_tasks($post->ID, $tasks);
                    if (is_wp_error($persisted)) {
                        wp_send_json_error($persisted->get_error_message());
                    }
                    wp_send_json_error('Magnific hat ' . count($tasks) . ' Auftrag/Aufträge gestartet; der nächste Auftrag schlug fehl: ' . $task->get_error_message());
                }
                wp_send_json_error($task->get_error_message());
            }
            $tasks[] = $task;
            $persisted = self::persist_magnific_tasks($post->ID, $tasks);
            if (is_wp_error($persisted)) {
                wp_send_json_error($persisted->get_error_message());
            }
        }
        delete_post_meta($post->ID, '_hbbz_magnific_results');
        wp_send_json_success(['count' => count($tasks), 'tasks' => $tasks, 'post_id' => $post->ID, 'persistence' => 'VERIFIED']);
    }

    public static function magnific_single_generate(): void {
        self::assert_ajax_access();
        $post = get_post(self::get_ajax_target_post_id());
        if (!$post instanceof WP_Post || $post->post_type !== 'post') {
            wp_send_json_error('Beitrag nicht gefunden');
        }
        $task = self::start_magnific_task((int) $post->ID, self::suggest_magnific_prompt($post), self::build_variation_plan($post));
        if (is_wp_error($task)) {
            wp_send_json_error($task->get_error_message());
        }
        $persisted = self::persist_magnific_tasks((int) $post->ID, [$task]);
        if (is_wp_error($persisted)) {
            wp_send_json_error($persisted->get_error_message());
        }
        delete_post_meta((int) $post->ID, '_hbbz_magnific_results');
        wp_send_json_success(['post_id' => (int) $post->ID, 'task_id' => (string) ($task['task_id'] ?? ''), 'status' => (string) ($task['status'] ?? 'CREATED')]);
    }

    public static function magnific_batch_status(): void {
        self::assert_ajax_access();
        $post = get_post(self::get_ajax_target_post_id());
        if (!$post instanceof WP_Post || $post->post_type !== 'post') {
            wp_send_json_error('Beitrag nicht gefunden.');
        }
        $results = get_post_meta((int) $post->ID, '_hbbz_magnific_results', true);
        if (is_array($results) && !empty($results['images']) && is_array($results['images'])) {
            wp_send_json_success(['post_id'=>(int)$post->ID,'status'=>'COMPLETED','images'=>array_values($results['images'])]);
        }
        $tasks = self::load_magnific_tasks((int) $post->ID);
        if (!$tasks) {
            wp_send_json_success(['post_id'=>(int)$post->ID,'status'=>'NO_TASK','images'=>[],'message'=>'Kein gespeicherter KI-Auftrag gefunden.']);
        }
        $updated=[]; $images=[]; $statuses=[]; $messages=[];
        foreach ($tasks as $task) {
            if (!is_array($task) || empty($task['task_id'])) continue;
            $task_id=(string)$task['task_id'];
            $detail=self::magnific_request('GET','/v1/ai/text-to-image/nano-banana-pro-flash/'.rawurlencode($task_id));
            if (is_wp_error($detail)) {
                $task['status']='REMOTE_CHECK_FAILED';
                $task['last_error']=self::magnific_contextual_error($detail,'batch_status');
                $updated[]=$task; $statuses[]='REMOTE_CHECK_FAILED'; $messages[]=$task['last_error'];
                continue;
            }
            $data=self::magnific_response_data($detail);
            $status=strtoupper((string)($data['status']??'UNKNOWN'));
            $task['status']=$status; $task['checked_at_utc']=gmdate('c'); unset($task['last_error']);
            $updated[]=$task; $statuses[]=$status;
            if ($status==='COMPLETED') {
                foreach ((array)($data['generated']??[]) as $url) {
                    if (is_string($url)&&preg_match('#^https?://#i',$url)) $images[]=['url'=>$url,'label'=>'KI-Bild für Beitrag #'.$post->ID,'task_id'=>$task_id];
                }
            }
        }
        self::persist_magnific_tasks((int)$post->ID,$updated);
        if ($images) {
            self::store_magnific_results((int)$post->ID,$images,$updated);
            wp_send_json_success(['post_id'=>(int)$post->ID,'status'=>'COMPLETED','images'=>$images]);
        }
        wp_send_json_success(['post_id'=>(int)$post->ID,'status'=>$statuses?implode(', ',array_values(array_unique($statuses))):'UNKNOWN','images'=>[],'message'=>$messages?implode(' ',$messages):'Bild wird noch erzeugt.']);
    }

    public static function magnific_batch_import(): void { self::magnific_batch_import_or_apply(false); }
    public static function magnific_batch_apply(): void { self::magnific_batch_import_or_apply(true); }

    private static function magnific_batch_import_or_apply(bool $apply): void {
        self::assert_ajax_access();
        $post=get_post(self::get_ajax_target_post_id());
        if(!$post instanceof WP_Post||$post->post_type!=='post') wp_send_json_error('Beitrag nicht gefunden.');
        $index=isset($_POST['index'])?absint($_POST['index']):0;
        $result=self::import_magnific_image($post,$index);
        if(is_wp_error($result)) wp_send_json_error($result->get_error_message());
        $attachment_id=(int)$result;
        $already=(bool)get_post_meta($attachment_id,'_hbbz_imported_before_batch',true);
        update_post_meta($attachment_id,'_hbbz_imported_before_batch',1);
        if($apply){
            $old=(int)get_post_thumbnail_id((int)$post->ID);
            set_post_thumbnail((int)$post->ID,$attachment_id);
            $readback=(int)get_post_thumbnail_id((int)$post->ID);
            if($readback!==$attachment_id) wp_send_json_error('Beitragsbild-Zuordnung konnte nicht bestätigt werden.');
            self::add_history((int)$post->ID,'magnific_batch_featured_replaced',$old,$attachment_id);
            update_post_meta($attachment_id,'_hbbz_use_status','featured_image_post_'.$post->ID);
            wp_send_json_success(['post_id'=>(int)$post->ID,'attachment_id'=>$attachment_id,'applied'=>true,'message'=>'Geklappt: Medien-ID #'.$attachment_id.' wurde als Beitragsbild gesetzt.']);
        }
        wp_send_json_success(['post_id'=>(int)$post->ID,'attachment_id'=>$attachment_id,'applied'=>false,'already_existing'=>$already,'message'=>$already?'Bild war bereits in der Mediathek. Medien-ID #'.$attachment_id.' wurde verwendet.':'Geklappt: Bild wurde als Medien-ID #'.$attachment_id.' in die Mediathek geladen.']);
    }

    public static function magnific_batch_generate(): void {
        self::assert_ajax_access();
        $ids = isset($_POST['post_ids']) && is_array($_POST['post_ids']) ? array_values(array_unique(array_map('absint', wp_unslash($_POST['post_ids'])))) : [];
        $ids = array_values(array_filter($ids));
        if (!$ids || count($ids) > 10) {
            wp_send_json_error('Es müssen 1 bis 10 Beiträge markiert sein.');
        }

        // Kein Tasklisten-Preflight. Jeder POST wird einzeln ausgewertet und
        // eine bestätigte Task-ID sofort gespeichert.
        $started = 0;
        $errors = [];
        foreach ($ids as $id) {
            $post = get_post($id);
            if (!$post instanceof WP_Post || $post->post_type !== 'post') {
                $errors[$id] = 'Beitrag nicht gefunden';
                continue;
            }
            $task = self::start_magnific_task($id, self::suggest_magnific_prompt($post), self::build_variation_plan($post));
            if (is_wp_error($task)) {
                $errors[$id] = $task->get_error_message();
                continue;
            }
            $persisted = self::persist_magnific_tasks($id, [$task]);
            if (is_wp_error($persisted)) {
                $errors[$id] = $persisted->get_error_message();
                continue;
            }
            delete_post_meta($id, '_hbbz_magnific_results');
            $started++;
        }
        wp_send_json_success(['started' => $started, 'errors' => $errors]);
    }

    private static function start_magnific_task(int $post_id,string $prompt,array $variation_plan=[]) {
        $payload=[
            'prompt'=>$prompt,
            'webhook_url'=>rest_url('hab-und-bewahr-bildzentrale/v1/magnific-webhook'),
            'aspect_ratio'=>'3:2',
            'resolution'=>'1K',
            'use_google_search_tool'=>false,
        ];
        $response=self::magnific_request('POST','/v1/ai/text-to-image/nano-banana-pro-flash',$payload);
        if (is_wp_error($response)) return $response;
        $data=is_array($response['data']??null)?$response['data']:$response;
        $task_id=(string)($data['task_id']??'');
        if ($task_id==='') return new WP_Error('hbbz_missing_task','Magnific lieferte keine Task-ID zurück.');
        $task=['task_id'=>$task_id,'status'=>strtoupper((string)($data['status']??'CREATED')),'prompt'=>$prompt,'model'=>'nano-banana-pro-flash','created_at_utc'=>gmdate('c'),'variation_plan'=>$variation_plan];
        $map=get_option(self::OPTION_MAGNIFIC_TASK_MAP,[]); if(!is_array($map))$map=[]; $map[$task_id]=$post_id; update_option(self::OPTION_MAGNIFIC_TASK_MAP,$map,false);
        return $task;
    }

    public static function magnific_check(): void {
        self::assert_ajax_access();
        $post = get_post(self::get_ajax_target_post_id());
        if (!$post instanceof WP_Post || $post->post_type !== 'post') {
            wp_send_json_error('Der gewählte Beitrag wurde nicht gefunden.');
        }

        $results = get_post_meta($post->ID, '_hbbz_magnific_results', true);
        if (is_array($results) && !empty($results['images']) && is_array($results['images'])) {
            wp_send_json_success(['status' => 'COMPLETED', 'images' => array_values($results['images'])]);
        }

        $saved_tasks = self::load_magnific_tasks($post->ID);
        if (!is_array($saved_tasks) || !$saved_tasks) {
            wp_send_json_success([
                'status' => 'NO_TASK',
                'images' => [],
                'message' => 'Für diesen Beitrag ist aktuell kein lokaler Magnific-Auftrag gespeichert. Die globale Verwaisten-Rettung wurde hier bewusst deaktiviert, damit keine fremden Bilder automatisch angezeigt oder falsch zugeordnet werden.',
            ]);
        }

        $updated_tasks = [];
        $images = [];
        $statuses = [];
        $messages = [];

        foreach ($saved_tasks as $saved_task) {
            if (!is_array($saved_task) || empty($saved_task['task_id'])) {
                $messages[] = 'Ungültiger lokaler Task-Eintrag wurde ignoriert.';
                continue;
            }

            $task_id = (string) $saved_task['task_id'];
            $detail = self::magnific_request('GET', '/v1/ai/text-to-image/nano-banana-pro-flash/' . rawurlencode($task_id));
            if (is_wp_error($detail)) {
                $saved_task['status'] = 'REMOTE_CHECK_FAILED';
                $saved_task['checked_at_utc'] = gmdate('c');
                $saved_task['last_error'] = self::magnific_contextual_error($detail, 'detail_direct');
                $updated_tasks[] = $saved_task;
                $statuses[] = 'REMOTE_CHECK_FAILED';
                $messages[] = 'Task ' . $task_id . ': ' . $saved_task['last_error'];
                continue;
            }

            $detail_data = self::magnific_response_data($detail);
            $status = strtoupper((string) ($detail_data['status'] ?? 'UNKNOWN'));
            $saved_task['status'] = $status;
            $saved_task['checked_at_utc'] = gmdate('c');
            unset($saved_task['last_error']);
            $updated_tasks[] = $saved_task;
            $statuses[] = $status;

            if ($status === 'COMPLETED') {
                foreach ((array) ($detail_data['generated'] ?? []) as $url) {
                    if (is_string($url) && preg_match('#^https?://#i', $url)) {
                        $images[] = ['url' => $url, 'label' => 'KI-Variante', 'task_id' => $task_id];
                    }
                }
            }
        }

        $persisted = self::persist_magnific_tasks($post->ID, $updated_tasks);
        if (is_wp_error($persisted)) {
            wp_send_json_error($persisted->get_error_message());
        }
        if ($images) {
            self::store_magnific_results($post->ID, $images, $updated_tasks);
            $stored = get_post_meta($post->ID, '_hbbz_magnific_results', true);
            wp_send_json_success(['status' => 'COMPLETED', 'images' => array_values((array) ($stored['images'] ?? []))]);
        }

        $status = $statuses ? implode(', ', array_values(array_unique($statuses))) : 'NO_VALID_TASK';
        wp_send_json_success(['status' => $status, 'images' => [], 'message' => 'Noch kein fertiges Bild vorhanden.', 'messages' => $messages, 'post_id' => $post->ID]);
    }


    private static function discover_orphan_magnific_tasks() {
        $list = self::magnific_request('GET', '/v1/ai/text-to-image/nano-banana-pro-flash');
        if (is_wp_error($list)) {
            return new WP_Error('hbbz_orphan_list_failed', self::magnific_contextual_error($list, 'orphan_list'));
        }
        $tasks = self::magnific_task_list($list);
        $candidates = [];
        foreach (array_slice($tasks, 0, 30) as $task) {
            if (!is_array($task) || empty($task['task_id'])) continue;
            $task_id = (string) $task['task_id'];
            $status = strtoupper((string) ($task['status'] ?? 'UNKNOWN'));
            $candidate = ['task_id' => $task_id, 'status' => $status, 'images' => []];
            if ($status === 'COMPLETED') {
                $detail = self::magnific_request('GET', '/v1/ai/text-to-image/nano-banana-pro-flash/' . rawurlencode($task_id));
                if (!is_wp_error($detail)) {
                    $detail_data = self::magnific_response_data($detail);
                    foreach ((array) ($detail_data['generated'] ?? []) as $url) {
                        if (is_string($url) && preg_match('#^https?://#i', $url)) $candidate['images'][] = $url;
                    }
                }
            }
            $candidates[] = $candidate;
        }
        return $candidates;
    }

    public static function magnific_recover(): void {
        self::assert_ajax_access();
        $post = get_post(self::get_ajax_target_post_id());
        if (!$post instanceof WP_Post || $post->post_type !== 'post') wp_send_json_error('Der gewählte Beitrag wurde nicht gefunden.');
        $task_id = isset($_POST['task_id']) ? sanitize_text_field(wp_unslash($_POST['task_id'])) : '';
        if ($task_id === '' || !preg_match('/^[A-Za-z0-9_-]{8,128}$/', $task_id)) wp_send_json_error('Ungültige Magnific-Task-ID.');
        $detail = self::magnific_request('GET', '/v1/ai/text-to-image/nano-banana-pro-flash/' . rawurlencode($task_id));
        if (is_wp_error($detail)) wp_send_json_error(self::magnific_contextual_error($detail, 'recover_detail'));
        $data = self::magnific_response_data($detail);
        $status = strtoupper((string) ($data['status'] ?? 'UNKNOWN'));
        $task = ['task_id'=>$task_id,'status'=>$status,'prompt'=>'','model'=>'nano-banana-pro-flash','created_at_utc'=>'','recovered_at_utc'=>gmdate('c')];
        $persisted = self::persist_magnific_tasks($post->ID, [$task]);
        if (is_wp_error($persisted)) wp_send_json_error($persisted->get_error_message());
        $images=[];
        foreach ((array)($data['generated']??[]) as $url) if(is_string($url)&&preg_match('#^https?://#i',$url)) $images[]=['url'=>$url,'label'=>'Wiederhergestellte KI-Variante','task_id'=>$task_id];
        if ($images) self::store_magnific_results($post->ID,$images,[$task]);
        wp_send_json_success(['status'=>$status,'images'=>$images,'task_id'=>$task_id,'post_id'=>$post->ID]);
    }

    private static function get_ajax_target_post_id(): int {
        $requested = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
        if ($requested > 0) {
            return $requested;
        }
        return self::get_target_post_id();
    }

    private static function persist_magnific_tasks(int $post_id, array $tasks) {
        $tasks = array_values(array_filter($tasks, static function ($task): bool {
            return is_array($task) && !empty($task['task_id']);
        }));

        update_post_meta($post_id, '_hbbz_magnific_tasks', $tasks);

        $registry = get_option(self::OPTION_MAGNIFIC_TASK_REGISTRY, []);
        if (!is_array($registry)) {
            $registry = [];
        }
        $registry[(string) $post_id] = $tasks;
        update_option(self::OPTION_MAGNIFIC_TASK_REGISTRY, $registry, false);

        $meta_readback = get_post_meta($post_id, '_hbbz_magnific_tasks', true);
        $registry_readback = get_option(self::OPTION_MAGNIFIC_TASK_REGISTRY, []);
        $registry_tasks = is_array($registry_readback) ? ($registry_readback[(string) $post_id] ?? null) : null;

        if ($meta_readback !== $tasks && $registry_tasks !== $tasks) {
            return new WP_Error(
                'hbbz_task_persistence_failed',
                'Magnific-Auftrag wurde erstellt, aber die Task-ID konnte nicht dauerhaft gespeichert werden. Kein weiterer Auftrag wurde gestartet. Beitrag #' . $post_id . '.'
            );
        }
        return true;
    }

    private static function load_magnific_tasks(int $post_id): array {
        $tasks = get_post_meta($post_id, '_hbbz_magnific_tasks', true);
        if (is_array($tasks) && $tasks) {
            return array_values($tasks);
        }

        $registry = get_option(self::OPTION_MAGNIFIC_TASK_REGISTRY, []);
        $fallback = is_array($registry) ? ($registry[(string) $post_id] ?? []) : [];
        if (is_array($fallback) && $fallback) {
            update_post_meta($post_id, '_hbbz_magnific_tasks', array_values($fallback));
            return array_values($fallback);
        }

        // Reparaturpfad für Aufträge aus 2.1.1: start_magnific_task() hat die
        // Task-ID bereits global dem Beitrag zugeordnet, bevor Postmeta geschrieben wurde.
        $legacy_map = get_option(self::OPTION_MAGNIFIC_TASK_MAP, []);
        $recovered = [];
        if (is_array($legacy_map)) {
            foreach ($legacy_map as $task_id => $mapped_post_id) {
                if (absint($mapped_post_id) === $post_id && is_string($task_id) && $task_id !== '') {
                    $recovered[] = [
                        'task_id' => $task_id,
                        'status' => 'RECOVERED_FROM_2_1_1',
                        'prompt' => '',
                        'model' => 'nano-banana-pro-flash',
                        'created_at_utc' => '',
                        'recovered_at_utc' => gmdate('c'),
                    ];
                }
            }
        }
        if ($recovered) {
            self::persist_magnific_tasks($post_id, $recovered);
            return $recovered;
        }
        return [];
    }

    private static function remove_magnific_task_mapping(string $task_id): void {
        $map = get_option(self::OPTION_MAGNIFIC_TASK_MAP, []);
        if (!is_array($map) || !array_key_exists($task_id, $map)) {
            return;
        }
        unset($map[$task_id]);
        update_option(self::OPTION_MAGNIFIC_TASK_MAP, $map, false);
    }

    public static function magnific_webhook(WP_REST_Request $request) {
        $secret=(string)get_option(self::OPTION_MAGNIFIC_WEBHOOK_SECRET,'');
        if($secret==='') return new WP_REST_Response(['error'=>'Webhook secret missing'],403);
        $id=(string)$request->get_header('webhook-id'); $timestamp=(string)$request->get_header('webhook-timestamp'); $header=(string)$request->get_header('webhook-signature'); $body=$request->get_body();
        if($id===''||$timestamp===''||$header==='') return new WP_REST_Response(['error'=>'Missing signature headers'],401);
        if(ctype_digit($timestamp)&&abs(time()-(int)$timestamp)>600) return new WP_REST_Response(['error'=>'Stale webhook'],401);
        $decoded=base64_decode($secret,true); $key=$decoded!==false?$decoded:$secret;
        $generated=base64_encode(hash_hmac('sha256',$id.'.'.$timestamp.'.'.$body,$key,true));
        $valid=false; foreach(preg_split('/\s+/',trim($header)) as $part){$bits=explode(',',$part,2); if(count($bits)===2&&hash_equals($generated,$bits[1])){$valid=true;break;}}
        if(!$valid) return new WP_REST_Response(['error'=>'Invalid signature'],401);
        $payload=json_decode($body,true); if(!is_array($payload)) return new WP_REST_Response(['error'=>'Invalid JSON'],400);
        $data=is_array($payload['data']??null)?$payload['data']:$payload;
        $task_id=(string)($data['task_id']??''); if($task_id==='') return new WP_REST_Response(['error'=>'Missing task_id'],400);
        $map=get_option(self::OPTION_MAGNIFIC_TASK_MAP,[]); $post_id=is_array($map)?absint($map[$task_id]??0):0;
        if($post_id<1) {
            $term_map=get_option(self::OPTION_TERM_TASK_MAP,[]); $target=is_array($term_map)?($term_map[$task_id]??null):null;
            if(is_array($target)&&!empty($target['term_id'])&&!empty($target['taxonomy'])){
                $term_id=absint($target['term_id']);$entity_type=in_array((string)($target['entity_type']??'term'),['term','page','post'],true)?(string)$target['entity_type']:'term';$images=[];foreach((array)($data['generated']??[]) as $url){if(is_string($url)&&preg_match('#^https?://#i',$url))$images[]=['url'=>$url,'label'=>$entity_type==='post'?'KI-Hero':'KI-Kategoriebild','task_id'=>$task_id];}
                $tasks=self::get_context_meta($entity_type,$term_id,'_hbbz_magnific_tasks',true);if(!is_array($tasks))$tasks=[];foreach($tasks as &$task){if(($task['task_id']??'')===$task_id){$task['status']=strtoupper((string)($data['status']??'UNKNOWN'));$task['webhook_at_utc']=gmdate('c');}}unset($task);self::update_context_meta($entity_type,$term_id,'_hbbz_magnific_tasks',$tasks);if($images)self::update_context_meta($entity_type,$term_id,'_hbbz_magnific_results',['status'=>'COMPLETED','prompt'=>(string)($tasks[0]['prompt']??''),'updated_at_utc'=>gmdate('c'),'images'=>$images]);return new WP_REST_Response(['ok'=>true,'term_id'=>$term_id,'entity_type'=>$entity_type],200);
            }
            return new WP_REST_Response(['ok'=>true,'ignored'=>'unknown task'],200);
        }
        $images=[]; foreach((array)($data['generated']??[]) as $url){if(is_string($url)&&preg_match('#^https?://#i',$url))$images[]=['url'=>$url,'label'=>'KI-Variante','task_id'=>$task_id];}
        $tasks=get_post_meta($post_id,'_hbbz_magnific_tasks',true); if(!is_array($tasks))$tasks=[];
        foreach($tasks as &$task){if(($task['task_id']??'')===$task_id){$task['status']=strtoupper((string)($data['status']??'UNKNOWN'));$task['webhook_at_utc']=gmdate('c');}} unset($task);
        update_post_meta($post_id,'_hbbz_magnific_tasks',$tasks);
        if($images) self::store_magnific_results($post_id,$images,$tasks);
        return new WP_REST_Response(['ok'=>true],200);
    }

    private static function store_magnific_results(int $post_id,array $images,array $tasks): void {
        $existing=get_post_meta($post_id,'_hbbz_magnific_results',true); $all=is_array($existing['images']??null)?$existing['images']:[];
        $seen=[]; foreach(array_merge($all,$images) as $image){$url=(string)($image['url']??''); if($url!==''&&!isset($seen[$url])){$seen[$url]=true;$all[]=$image;}}
        $unique=[];$seen=[];foreach($all as $image){$url=(string)($image['url']??'');if($url!==''&&!isset($seen[$url])){$seen[$url]=true;$image['label']='KI-Variante '.(count($unique)+1);$unique[]=$image;}}
        $prompt=(string)($tasks[0]['prompt']??'');
        update_post_meta($post_id,'_hbbz_magnific_results',['status'=>'COMPLETED','prompt'=>$prompt,'updated_at_utc'=>gmdate('c'),'images'=>$unique]);
    }

    public static function magnific_import(): void { self::magnific_import_or_apply(false); }
    public static function magnific_apply(): void { self::magnific_import_or_apply(true); }

    private static function magnific_import_or_apply(bool $apply): void {
        self::assert_ajax_access(); $post=get_post(self::get_target_post_id()); if(!$post instanceof WP_Post)wp_send_json_error('Arbeitsbeitrag nicht gefunden.');
        $index=isset($_POST['index'])?absint($_POST['index']):0;
        $results=get_post_meta($post->ID,'_hbbz_magnific_results',true);
        $image=is_array($results)?($results['images'][$index]??null):null;
        $task_id=is_array($image)?(string)($image['task_id']??'magnific'):'magnific';
        $asset_key=$task_id.'-'.$index;
        $existing_ids=get_posts(['post_type'=>'attachment','post_status'=>'inherit','posts_per_page'=>1,'fields'=>'ids','meta_key'=>'_hbbz_asset_id','meta_value'=>$asset_key]);
        $already_existing=!empty($existing_ids[0]);
        $result=self::import_magnific_image($post,$index); if(is_wp_error($result))wp_send_json_error($result->get_error_message());
        $attachment_id=(int)$result;
        if($apply){$old=(int)get_post_thumbnail_id($post->ID); if(!set_post_thumbnail($post->ID,$attachment_id))wp_send_json_error('Beitragsbild konnte nicht gesetzt werden.'); self::add_history($post->ID,'magnific_featured_replaced',$old,$attachment_id); update_post_meta($attachment_id,'_hbbz_use_status','featured_image_post_'.$post->ID);}
        wp_send_json_success(['attachment_id'=>$attachment_id,'applied'=>$apply,'already_existing'=>$already_existing]);
    }

    private static function import_magnific_image(WP_Post $post,int $index) {
        $results=get_post_meta($post->ID,'_hbbz_magnific_results',true); $image=$results['images'][$index]??null; if(!is_array($image)||empty($image['url']))return new WP_Error('hbbz_missing_image','Gewähltes KI-Bild nicht verfügbar.');
        require_once ABSPATH.'wp-admin/includes/file.php'; require_once ABSPATH.'wp-admin/includes/image.php'; require_once ABSPATH.'wp-admin/includes/media.php';
        $tmp=download_url((string)$image['url'],45); if(is_wp_error($tmp))return $tmp;
        try{
            $task_id=(string)($image['task_id']??'magnific');
            $asset_key=$task_id.'-'.$index;
            $existing_ids=get_posts(['post_type'=>'attachment','post_status'=>'inherit','posts_per_page'=>1,'fields'=>'ids','meta_key'=>'_hbbz_asset_id','meta_value'=>$asset_key]);
            if (!empty($existing_ids[0])) {
                $attachment_id=(int)$existing_ids[0];
                update_option(self::OPTION_SELECTION,['provider'=>'magnific','image_id'=>$asset_key,'page_url'=>'https://www.magnific.com/','photographer'=>'KI-generiert via Magnific','photographer_url'=>'https://www.magnific.com/','status'=>'downloaded_to_media_library','attachment_id'=>$attachment_id,'downloaded_at_utc'=>gmdate('c'),'selected_at_utc'=>gmdate('c'),'ai_generated'=>1],false);
                return $attachment_id;
            }
            $editor=wp_get_image_editor($tmp); if(is_wp_error($editor))return $editor; $size=$editor->get_size(); if(empty($size['width'])||empty($size['height']))return new WP_Error('hbbz_size','Bildmaße fehlen.');
            $geometry=self::calculate_crop_geometry((int)$size['width'],(int)$size['height'],3,2); if(is_wp_error($geometry))return $geometry;
            $crop=$editor->crop($geometry['src_x'],$geometry['src_y'],$geometry['crop_width'],$geometry['crop_height'],1500,1000,false); if(is_wp_error($crop))return $crop; if(method_exists($editor,'set_quality'))$editor->set_quality(82);
            $upload=wp_upload_dir(); if(!empty($upload['error']))return new WP_Error('hbbz_upload',$upload['error']);
            $filename=wp_unique_filename($upload['path'],self::build_filename_base($post->ID,'magnific',$asset_key).'.webp'); $destination=trailingslashit($upload['path']).$filename;
            $saved=$editor->save($destination,'image/webp'); if(is_wp_error($saved)||empty($saved['path']))return new WP_Error('hbbz_save','WebP konnte nicht gespeichert werden.'); $destination=(string)$saved['path'];
            $attachment_id=wp_insert_attachment(['post_mime_type'=>'image/webp','post_title'=>self::build_media_title($post->ID),'post_content'=>'','post_status'=>'inherit'],$destination,$post->ID,true); if(is_wp_error($attachment_id))return $attachment_id;
            $meta=wp_generate_attachment_metadata($attachment_id,$destination); wp_update_attachment_metadata($attachment_id,is_array($meta)?$meta:[]);
            $variation_plan=[]; foreach (self::load_magnific_tasks($post->ID) as $task_entry) { if (($task_entry['task_id'] ?? '') === $task_id) { $variation_plan = is_array($task_entry['variation_plan'] ?? null) ? $task_entry['variation_plan'] : []; break; } }
            $fields=['_wp_attachment_image_alt'=>self::build_alt_text($post->ID),'_hbbz_provider'=>'magnific','_hbbz_asset_id'=>$asset_key,'_hbbz_source_page'=>'https://www.magnific.com/','_hbbz_photographer'=>'KI-generiert via Magnific','_hbbz_photographer_url'=>'https://www.magnific.com/','_hbbz_downloaded_at_utc'=>gmdate('c'),'_hbbz_use_status'=>'workflow_test_not_published','_hbbz_license_name'=>'AI-generated via Magnific','_hbbz_license_url'=>'https://www.magnific.com/legal/terms-of-use','_hbbz_import_method'=>'magnific_api_manual_editor_approval','_hbbz_target_post_id'=>$post->ID,'_hbbz_file_sha256'=>hash_file('sha256',$destination)?:'','_hbbz_output_width'=>1500,'_hbbz_output_height'=>1000,'_hbbz_output_bytes'=>(int)filesize($destination),'_hbbz_quality_gate'=>'passed','_hbbz_is_ai_generated'=>1,'_hbbz_ai_prompt'=>(string)($results['prompt']??''),'_hbbz_variation_plan'=>wp_json_encode($variation_plan, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)]; foreach($fields as $k=>$v)update_post_meta($attachment_id,$k,$v);
            self::record_variation_history($post->ID, $asset_key, $variation_plan);
            update_option(self::OPTION_SELECTION,['provider'=>'magnific','image_id'=>$asset_key,'page_url'=>'https://www.magnific.com/','photographer'=>'KI-generiert via Magnific','photographer_url'=>'https://www.magnific.com/','status'=>'downloaded_to_media_library','attachment_id'=>(int)$attachment_id,'downloaded_at_utc'=>gmdate('c'),'selected_at_utc'=>gmdate('c'),'ai_generated'=>1],false);
            return (int)$attachment_id;
        }finally{if(is_string($tmp)&&is_file($tmp))@unlink($tmp);}
    }

    private static function magnific_response_data(array $response): array {
        return isset($response['data']) && is_array($response['data']) ? $response['data'] : $response;
    }

    private static function magnific_task_list(array $response): array {
        $data = self::magnific_response_data($response);
        if (array_is_list($data)) {
            return array_values(array_filter($data, 'is_array'));
        }
        if (isset($data['tasks']) && is_array($data['tasks'])) {
            return array_values(array_filter($data['tasks'], 'is_array'));
        }
        return [];
    }

    private static function magnific_contextual_error(WP_Error $error, string $context): string {
        $message = $error->get_error_message();
        if (stripos($message, 'HTTP 404') !== false || stripos($message, 'Task not found') !== false) {
            if ($context === 'detail_confirmed') {
                return 'Magnific listet die Task-ID als vorhanden, liefert beim Abruf derselben Task aber HTTP 404. Das ist eine widersprüchliche Antwort der Magnific-API; der Auftrag wurde nicht verändert.';
            }
        }
        return $message;
    }

    private static function magnific_request(string $method, string $path, ?array $payload = null) {
        $key = (string) get_option(self::OPTION_MAGNIFIC_API_KEY, '');
        if ($key === '') {
            return new WP_Error('hbbz_key', 'Magnific API-Key fehlt.');
        }
        $args = [
            'method' => strtoupper($method),
            'timeout' => 60,
            'headers' => [
                'x-magnific-api-key' => $key,
                'Accept' => 'application/json',
            ],
        ];
        if ($payload !== null) {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = wp_json_encode($payload);
        }
        $response = wp_remote_request('https://api.magnific.com' . $path, $args);
        if (is_wp_error($response)) {
            return $response;
        }
        $code = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if ($code < 200 || $code >= 300) {
            $message = is_array($data) ? (string) ($data['message'] ?? $data['error'] ?? wp_json_encode($data)) : trim($body);
            return new WP_Error('hbbz_http_' . $code, 'Magnific API antwortet mit HTTP ' . $code . ($message !== '' ? ': ' . $message : ''));
        }
        if (!is_array($data)) {
            return new WP_Error('hbbz_invalid_json', 'Magnific lieferte keine gültige JSON-Antwort.');
        }
        return $data;
    }
    public static function test_provider(): void {
        self::assert_ajax_access();
        $provider=isset($_POST['provider'])?sanitize_key(wp_unslash($_POST['provider'])):'';
        if($provider==='pixabay')$response=self::pixabay_request('creative home security safeguards',3);
        elseif($provider==='pexels')$response=self::pexels_request('creative home security safeguards',1);
        elseif($provider==='magnific')$response=self::magnific_connection_test();
        else wp_send_json_error('Unbekannter Anbieter.');
        if(is_wp_error($response))wp_send_json_error($response->get_error_message());wp_send_json_success(true);
    }

    private static function magnific_connection_test() {
        $key = (string) get_option(self::OPTION_MAGNIFIC_API_KEY, '');
        if ($key === '') {
            return new WP_Error('hbbz_magnific_key_missing', 'Magnific API-Key fehlt.');
        }

        $response = wp_remote_get(
            'https://api.magnific.com/v1/resources',
            [
                'timeout' => 25,
                'redirection' => 2,
                'headers' => [
                    'Accept' => 'application/json',
                    'x-magnific-api-key' => $key,
                ],
            ]
        );

        if (is_wp_error($response)) {
            return new WP_Error('hbbz_magnific_transport', 'Magnific-Verbindung fehlgeschlagen: ' . $response->get_error_message());
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $body = (string) wp_remote_retrieve_body($response);
        $decoded = json_decode($body, true);

        if ($status < 200 || $status >= 300) {
            $message = '';
            if (is_array($decoded)) {
                $message = (string) ($decoded['message'] ?? $decoded['error'] ?? $decoded['detail'] ?? '');
            }
            if ($message === '') {
                $message = trim(wp_strip_all_tags($body));
            }
            if ($message === '') {
                $message = 'HTTP ' . $status;
            }
            return new WP_Error('hbbz_magnific_http', 'Magnific API antwortet mit HTTP ' . $status . ': ' . $message);
        }

        if (!is_array($decoded)) {
            return new WP_Error('hbbz_magnific_json', 'Magnific lieferte keine gültige JSON-Antwort.');
        }

        return $decoded;
    }

    public static function search_images(): void {
        self::assert_ajax_access();
        $query = isset($_POST['query']) ? sanitize_text_field(wp_unslash($_POST['query'])) : '';
        if ($query === '' || strlen($query) > 100) {
            wp_send_json_error('Suchbegriff fehlt oder ist zu lang.');
        }

        $pixabay_response = self::pixabay_request($query, 6);
        $pexels_response  = self::pexels_request($query, 6);

        if (is_wp_error($pixabay_response)) {
            wp_send_json_error('Pixabay: ' . $pixabay_response->get_error_message());
        }
        if (is_wp_error($pexels_response)) {
            wp_send_json_error('Pexels: ' . $pexels_response->get_error_message());
        }

        wp_send_json_success([
            'pixabay' => self::filter_excluded_assets(self::filter_used_assets(self::normalize_pixabay($pixabay_response), 'pixabay')),
            'pexels'  => self::filter_excluded_assets(self::filter_used_assets(self::normalize_pexels($pexels_response), 'pexels')),
        ]);
    }

    public static function batch_preview(): void {
        self::assert_ajax_access();
        $post_ids = isset($_POST['post_ids']) && is_array($_POST['post_ids']) ? array_values(array_unique(array_map('absint', wp_unslash($_POST['post_ids'])))) : [];
        $post_ids = array_values(array_filter($post_ids));
        if (count($post_ids) < 1 || count($post_ids) > 10) {
            wp_send_json_error('Es müssen 1 bis 10 gültige Beiträge gewählt werden.');
        }
        $items = [];
        foreach ($post_ids as $post_id) {
            $post = get_post($post_id);
            if (!$post instanceof WP_Post || $post->post_type !== 'post') {
                continue;
            }
            $query = self::suggest_query_for_post($post);
            $pixabay_response = self::pixabay_request($query, 4);
            $pexels_response = self::pexels_request($query, 4);
            $items[] = [
                'post_id' => $post_id,
                'title' => get_the_title($post),
                'query' => $query,
                'pixabay' => is_wp_error($pixabay_response) ? [] : array_slice(self::filter_excluded_assets(self::filter_used_assets(self::normalize_pixabay($pixabay_response), 'pixabay')), 0, 2),
                'pexels' => is_wp_error($pexels_response) ? [] : array_slice(self::filter_excluded_assets(self::filter_used_assets(self::normalize_pexels($pexels_response), 'pexels')), 0, 2),
            ];
        }
        wp_send_json_success(['items' => $items]);
    }


    public static function batch_apply(): void {
        self::assert_ajax_access();
        $raw = isset($_POST['selections']) ? wp_unslash($_POST['selections']) : '';
        $items = json_decode((string) $raw, true);
        if (!is_array($items) || count($items) < 1 || count($items) > 10) {
            wp_send_json_error('Es müssen 1 bis 10 gültige Bildzuordnungen übergeben werden.');
        }
        $old_selection = get_option(self::OPTION_SELECTION, []);
        $success_count = 0;
        $errors = [];
        foreach ($items as $item) {
            $post_id = absint($item['post_id'] ?? 0);
            $post = get_post($post_id);
            $provider = sanitize_key((string) ($item['provider'] ?? ''));
            $preview_url = esc_url_raw((string) ($item['preview_url'] ?? ''));
            $page_url = esc_url_raw((string) ($item['page_url'] ?? ''));
            if (!$post instanceof WP_Post || $post->post_type !== 'post') {
                $errors[] = '#' . $post_id . ': Beitrag ungültig';
                continue;
            }
            if (has_post_thumbnail($post_id)) {
                $errors[] = '#' . $post_id . ': Beitragsbild bereits vorhanden';
                continue;
            }
            if (!in_array($provider, ['pixabay','pexels'], true) || !self::url_matches_provider($preview_url, $provider, true) || !self::url_matches_provider($page_url, $provider, false)) {
                $errors[] = '#' . $post_id . ': Bildquelle ungültig';
                continue;
            }
            $selection = [
                'post_id' => $post_id,
                'provider' => $provider,
                'image_id' => sanitize_text_field((string) ($item['image_id'] ?? '')),
                'preview_url' => $preview_url,
                'page_url' => $page_url,
                'photographer' => sanitize_text_field((string) ($item['photographer'] ?? '')),
                'photographer_url' => esc_url_raw((string) ($item['photographer_url'] ?? '')),
                'width' => absint($item['width'] ?? 0),
                'height' => absint($item['height'] ?? 0),
                'selected_at_utc' => gmdate('c'),
                'status' => 'selected_only_not_downloaded',
            ];
            update_option(self::OPTION_SELECTION, $selection, false);
            try {
                $download = self::perform_download_selected();
                $attachment_id = absint($download['attachment_id'] ?? 0);
                if (!$attachment_id || !set_post_thumbnail($post_id, $attachment_id)) {
                    throw new RuntimeException('Beitragsbild konnte nicht gesetzt werden.');
                }
                update_post_meta($attachment_id, '_hbbz_assigned_post_id', $post_id);
                update_post_meta($attachment_id, '_hbbz_assigned_as', 'featured_image');
                update_post_meta($attachment_id, '_hbbz_assigned_at_utc', gmdate('c'));
                $success_count++;
            } catch (Throwable $e) {
                $errors[] = '#' . $post_id . ': ' . $e->getMessage();
            }
        }
        update_option(self::OPTION_SELECTION, $old_selection, false);
        wp_send_json_success(['success_count'=>$success_count,'errors'=>$errors]);
    }

    public static function select_image(): void {
        self::assert_ajax_access();

        $provider = isset($_POST['provider']) ? sanitize_key(wp_unslash($_POST['provider'])) : '';
        if (!in_array($provider, ['pixabay', 'pexels'], true)) {
            wp_send_json_error('Unzulässiger Anbieter.');
        }

        $preview_url = isset($_POST['preview_url']) ? esc_url_raw(wp_unslash($_POST['preview_url'])) : '';
        $page_url = isset($_POST['page_url']) ? esc_url_raw(wp_unslash($_POST['page_url'])) : '';
        $photographer_url = isset($_POST['photographer_url']) ? esc_url_raw(wp_unslash($_POST['photographer_url'])) : '';

        if (!self::url_matches_provider($preview_url, $provider, true) || !self::url_matches_provider($page_url, $provider, false)) {
            wp_send_json_error('Bildquelle konnte nicht bestätigt werden.');
        }

        $selection = [
            'post_id'          => self::get_target_post_id(),
            'provider'         => $provider,
            'image_id'         => isset($_POST['image_id']) ? sanitize_text_field(wp_unslash($_POST['image_id'])) : '',
            'preview_url'      => $preview_url,
            'page_url'         => $page_url,
            'photographer'     => isset($_POST['photographer']) ? sanitize_text_field(wp_unslash($_POST['photographer'])) : '',
            'photographer_url' => $photographer_url,
            'width'            => isset($_POST['width']) ? absint($_POST['width']) : 0,
            'height'           => isset($_POST['height']) ? absint($_POST['height']) : 0,
            'selected_at_utc'  => gmdate('c'),
            'status'           => 'selected_only_not_downloaded',
        ];

        update_option(self::OPTION_SELECTION, $selection, false);
        wp_send_json_success(['status' => 'selected_only_not_downloaded']);
    }

    public static function download_selected(): void {
        self::assert_ajax_access();

        // Verhindert, dass PHP-Warnungen/Notices die JSON-Antwort zerstören.
        $buffer_level = ob_get_level();
        ob_start();

        try {
            $result = self::perform_download_selected();
            while (ob_get_level() > $buffer_level) {
                ob_end_clean();
            }
            wp_send_json_success($result);
        } catch (Throwable $error) {
            while (ob_get_level() > $buffer_level) {
                ob_end_clean();
            }
            error_log('[HBBZ 1.6.0] Downloadfehler: ' . $error->getMessage());
            wp_send_json_error('Interner Bildfehler: ' . $error->getMessage(), 500);
        }
    }

    private static function perform_download_selected(): array {
        $selection = get_option(self::OPTION_SELECTION, []);
        if (!is_array($selection) || empty($selection['provider']) || empty($selection['image_id'])) {
            throw new RuntimeException('Es ist kein gültiges Bild ausgewählt.');
        }
        if (($selection['status'] ?? '') === 'downloaded_to_media_library' && !empty($selection['attachment_id'])) {
            return ['attachment_id' => (int) $selection['attachment_id']];
        }

        $provider = (string) $selection['provider'];
        $image_id = (string) $selection['image_id'];
        $source = self::fetch_download_source($provider, $image_id);
        if (is_wp_error($source)) {
            throw new RuntimeException($source->get_error_message());
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        $tmp = download_url((string) $source['url'], 30);
        if (is_wp_error($tmp)) {
            throw new RuntimeException('Bilddownload fehlgeschlagen: ' . $tmp->get_error_message());
        }

        try {
            $image_info = @getimagesize($tmp);
            if (!is_array($image_info) || empty($image_info[0]) || empty($image_info[1]) || empty($image_info['mime'])) {
                throw new RuntimeException('Die heruntergeladene Datei ist kein gültiges Bild.');
            }
            if (!in_array((string) $image_info['mime'], ['image/jpeg', 'image/png', 'image/webp'], true)) {
                throw new RuntimeException('Nicht unterstütztes Bildformat: ' . (string) $image_info['mime']);
            }

            $editor = wp_get_image_editor($tmp);
            if (is_wp_error($editor)) {
                throw new RuntimeException('Bild konnte nicht verarbeitet werden: ' . $editor->get_error_message());
            }

            $size = $editor->get_size();
            if (!is_array($size) || empty($size['width']) || empty($size['height'])) {
                throw new RuntimeException('Bildabmessungen konnten nicht gelesen werden.');
            }

            $geometry = self::calculate_crop_geometry((int) $size['width'], (int) $size['height']);
            if (is_wp_error($geometry)) {
                throw new RuntimeException($geometry->get_error_message());
            }

            $crop = $editor->crop(
                $geometry['src_x'],
                $geometry['src_y'],
                $geometry['crop_width'],
                $geometry['crop_height'],
                $geometry['destination_width'],
                $geometry['destination_height'],
                false
            );
            if (is_wp_error($crop)) {
                throw new RuntimeException('Zuschnitt fehlgeschlagen: ' . $crop->get_error_message());
            }

            if (method_exists($editor, 'set_quality')) {
                $quality = $editor->set_quality(82);
                if (is_wp_error($quality)) {
                    throw new RuntimeException('Bildqualität konnte nicht gesetzt werden: ' . $quality->get_error_message());
                }
            }

            $upload_dir = wp_upload_dir();
            if (!empty($upload_dir['error'])) {
                throw new RuntimeException('Upload-Verzeichnis nicht verfügbar: ' . $upload_dir['error']);
            }

            $target_post_id = self::get_target_post_id();
            $base_name = self::build_filename_base($target_post_id, $provider, $image_id);
            $filename = wp_unique_filename($upload_dir['path'], $base_name . '.webp');
            $destination = trailingslashit($upload_dir['path']) . $filename;
            $saved = $editor->save($destination, 'image/webp');
            if (is_wp_error($saved)) {
                throw new RuntimeException('WebP-Speicherung fehlgeschlagen: ' . $saved->get_error_message());
            }
            if (!is_array($saved) || empty($saved['path']) || !is_file($saved['path'])) {
                throw new RuntimeException('Die optimierte Bilddatei wurde nicht angelegt.');
            }
            $destination = (string) $saved['path'];

            $attachment = [
                'post_mime_type' => 'image/webp',
                'post_title'     => self::build_media_title($target_post_id),
                'post_content'   => '',
                'post_status'    => 'inherit',
            ];
            $attachment_id = wp_insert_attachment($attachment, $destination, $target_post_id, true);
            if (is_wp_error($attachment_id)) {
                @unlink($destination);
                throw new RuntimeException('Mediathek-Eintrag fehlgeschlagen: ' . $attachment_id->get_error_message());
            }

            $metadata = wp_generate_attachment_metadata($attachment_id, $destination);
            if (is_wp_error($metadata)) {
                wp_delete_attachment($attachment_id, true);
                throw new RuntimeException('Mediendateien konnten nicht erzeugt werden: ' . $metadata->get_error_message());
            }
            wp_update_attachment_metadata($attachment_id, is_array($metadata) ? $metadata : []);
            update_post_meta($attachment_id, '_wp_attachment_image_alt', self::build_alt_text($target_post_id));
            update_post_meta($attachment_id, '_hbbz_provider', $provider);
            update_post_meta($attachment_id, '_hbbz_asset_id', $image_id);
            update_post_meta($attachment_id, '_hbbz_source_page', (string) ($selection['page_url'] ?? ''));
            update_post_meta($attachment_id, '_hbbz_photographer', (string) ($selection['photographer'] ?? ''));
            update_post_meta($attachment_id, '_hbbz_photographer_url', (string) ($selection['photographer_url'] ?? ''));
            update_post_meta($attachment_id, '_hbbz_selected_at_utc', (string) ($selection['selected_at_utc'] ?? ''));
            update_post_meta($attachment_id, '_hbbz_downloaded_at_utc', gmdate('c'));
            update_post_meta($attachment_id, '_hbbz_use_status', 'workflow_test_not_published');
            update_post_meta($attachment_id, '_hbbz_license_name', $provider === 'pixabay' ? 'Pixabay Content License' : 'Pexels License');
            update_post_meta($attachment_id, '_hbbz_license_url', $provider === 'pixabay' ? 'https://pixabay.com/service/license-summary/' : 'https://www.pexels.com/license/');
            update_post_meta($attachment_id, '_hbbz_import_method', 'official_api_manual_editor_approval');
            update_post_meta($attachment_id, '_hbbz_target_post_id', $target_post_id);
            update_post_meta($attachment_id, '_hbbz_file_sha256', hash_file('sha256', $destination) ?: '');
            update_post_meta($attachment_id, '_hbbz_output_width', (int) $geometry['destination_width']);
            update_post_meta($attachment_id, '_hbbz_output_height', (int) $geometry['destination_height']);
            update_post_meta($attachment_id, '_hbbz_output_bytes', (int) filesize($destination));
            update_post_meta($attachment_id, '_hbbz_quality_gate', 'passed');

            $selection['status'] = 'downloaded_to_media_library';
            $selection['attachment_id'] = (int) $attachment_id;
            $selection['downloaded_at_utc'] = gmdate('c');
            $selection['optimized_format'] = 'webp';
            $selection['optimized_width'] = (int) $geometry['destination_width'];
            $selection['optimized_height'] = (int) $geometry['destination_height'];
            update_option(self::OPTION_SELECTION, $selection, false);

            return ['attachment_id' => (int) $attachment_id];
        } finally {
            if (is_string($tmp) && is_file($tmp)) {
                @unlink($tmp);
            }
        }
    }

    public static function assign_featured(): void {
        self::assert_ajax_access();
        $selection = get_option(self::OPTION_SELECTION, []);
        if (!is_array($selection) || empty($selection['attachment_id'])) {
            wp_send_json_error('Kein Bild aus der Mediathek ausgewählt.');
        }
        $attachment_id = absint($selection['attachment_id']);
        if ($attachment_id < 1 || get_post_type($attachment_id) !== 'attachment' || !wp_attachment_is_image($attachment_id)) {
            wp_send_json_error('Der gespeicherte Mediathek-Eintrag ist kein gültiges Bild.');
        }
        $selection_post_id = absint($selection['post_id'] ?? 0);
        $target_post_id = $selection_post_id > 0 ? $selection_post_id : self::get_target_post_id();
        $post = get_post($target_post_id);
        if (!$post instanceof WP_Post || $post->post_type !== 'post') {
            wp_send_json_error('Der gewählte Beitrag wurde nicht gefunden.');
        }
        if (!in_array($post->post_status, ['draft', 'publish', 'pending', 'future', 'private'], true)) {
            wp_send_json_error('Der Beitrag hat einen nicht unterstützten Status: ' . (string) $post->post_status);
        }

        self::backfill_license_metadata($attachment_id, $selection);

        $required_meta = ['_hbbz_provider', '_hbbz_asset_id', '_hbbz_source_page', '_hbbz_license_name', '_hbbz_license_url', '_hbbz_downloaded_at_utc'];
        foreach ($required_meta as $meta_key) {
            if ((string) get_post_meta($attachment_id, $meta_key, true) === '') {
                wp_send_json_error('Lizenzdokumentation unvollständig: ' . $meta_key);
            }
        }

        $current_thumbnail = (int) get_post_thumbnail_id($target_post_id);
        if (!array_key_exists('previous_thumbnail_id', $selection)) {
            $selection['previous_thumbnail_id'] = $current_thumbnail;
        }
        $already_assigned = ($current_thumbnail === $attachment_id);
        if (!$already_assigned) {
            set_post_thumbnail($target_post_id, $attachment_id);
        }
        $readback_thumbnail = (int) get_post_thumbnail_id($target_post_id);
        if ($readback_thumbnail !== $attachment_id) {
            wp_send_json_error('Nicht geklappt: WordPress-Readback meldet nach der Zuordnung Medien-ID #' . $readback_thumbnail . ' statt #' . $attachment_id . '.');
        }
        if (!$already_assigned) {
            self::add_history($target_post_id, 'featured_set_or_replaced', $current_thumbnail, $attachment_id);
        }
        update_post_meta($attachment_id, '_hbbz_use_status', 'featured_image_post_' . $target_post_id);
        update_post_meta($attachment_id, '_hbbz_assigned_post_id', $target_post_id);
        update_post_meta($attachment_id, '_hbbz_assigned_as', 'featured_image');
        update_post_meta($attachment_id, '_hbbz_assigned_at_utc', gmdate('c'));
        $selection['post_id'] = $target_post_id;
        $selection['status'] = 'featured_image_set';
        $selection['assigned_at_utc'] = gmdate('c');
        update_option(self::OPTION_SELECTION, $selection, false);
        wp_send_json_success([
            'attachment_id' => $attachment_id,
            'post_id' => $target_post_id,
            'post_title' => wp_strip_all_tags(get_the_title($target_post_id)),
            'post_status' => (string) $post->post_status,
            'already_assigned' => $already_assigned,
            'readback_verified' => true,
        ]);
    }

    private static function backfill_license_metadata(int $attachment_id, array $selection): void {
        $provider = (string) ($selection['provider'] ?? get_post_meta($attachment_id, '_hbbz_provider', true));
        $asset_id = (string) ($selection['image_id'] ?? get_post_meta($attachment_id, '_hbbz_asset_id', true));
        $source_page = (string) ($selection['page_url'] ?? get_post_meta($attachment_id, '_hbbz_source_page', true));
        $photographer = (string) ($selection['photographer'] ?? get_post_meta($attachment_id, '_hbbz_photographer', true));
        $photographer_url = (string) ($selection['photographer_url'] ?? get_post_meta($attachment_id, '_hbbz_photographer_url', true));
        $downloaded_at = (string) ($selection['downloaded_at_utc'] ?? get_post_meta($attachment_id, '_hbbz_downloaded_at_utc', true));

        if ($provider !== '') update_post_meta($attachment_id, '_hbbz_provider', $provider);
        if ($asset_id !== '') update_post_meta($attachment_id, '_hbbz_asset_id', $asset_id);
        if ($source_page !== '') update_post_meta($attachment_id, '_hbbz_source_page', $source_page);
        if ($photographer !== '') update_post_meta($attachment_id, '_hbbz_photographer', $photographer);
        if ($photographer_url !== '') update_post_meta($attachment_id, '_hbbz_photographer_url', $photographer_url);
        if ($downloaded_at !== '') update_post_meta($attachment_id, '_hbbz_downloaded_at_utc', $downloaded_at);
        if ($provider === 'pixabay') {
            update_post_meta($attachment_id, '_hbbz_license_name', 'Pixabay Content License');
            update_post_meta($attachment_id, '_hbbz_license_url', 'https://pixabay.com/service/license-summary/');
        } elseif ($provider === 'pexels') {
            update_post_meta($attachment_id, '_hbbz_license_name', 'Pexels License');
            update_post_meta($attachment_id, '_hbbz_license_url', 'https://www.pexels.com/license/');
        } elseif ($provider === 'magnific') {
            update_post_meta($attachment_id, '_hbbz_license_name', 'AI-generated via Magnific');
            update_post_meta($attachment_id, '_hbbz_license_url', 'https://docs.magnific.com/');
        }
        update_post_meta($attachment_id, '_hbbz_import_method', 'official_api_manual_editor_approval');
        update_post_meta($attachment_id, '_hbbz_target_post_id', self::get_target_post_id());
    }

    public static function undo_featured(): void {
        self::assert_ajax_access();
        $selection = get_option(self::OPTION_SELECTION, []);
        if (!is_array($selection) || empty($selection['attachment_id'])) {
            wp_send_json_error('Keine Zuordnung zum Zurücknehmen vorhanden.');
        }
        $attachment_id = absint($selection['attachment_id']);
        $target_post_id = self::get_target_post_id();
        $current_thumbnail = (int) get_post_thumbnail_id($target_post_id);
        if ($current_thumbnail !== $attachment_id) {
            wp_send_json_error('Das aktuelle Beitragsbild wurde inzwischen außerhalb der Bildzentrale geändert. Rücknahme abgebrochen.');
        }

        $previous = absint($selection['previous_thumbnail_id'] ?? 0);
        if ($previous > 0 && get_post_type($previous) === 'attachment' && wp_attachment_is_image($previous)) {
            if (!set_post_thumbnail($target_post_id, $previous)) {
                wp_send_json_error('Das vorherige Beitragsbild konnte nicht wiederhergestellt werden.');
            }
        } else {
            delete_post_thumbnail($target_post_id);
        }
        self::add_history($target_post_id, 'featured_undo', $attachment_id, $previous);
        update_post_meta($attachment_id, '_hbbz_use_status', 'workflow_test_unassigned_kept_in_media_library');
        update_post_meta($attachment_id, '_hbbz_unassigned_at_utc', gmdate('c'));
        $selection['status'] = 'downloaded_to_media_library';
        $selection['unassigned_at_utc'] = gmdate('c');
        update_option(self::OPTION_SELECTION, $selection, false);
        wp_send_json_success(['attachment_id' => $attachment_id, 'post_id' => $target_post_id]);
    }


    private static function add_history(int $post_id, string $action, int $old_attachment_id = 0, int $new_attachment_id = 0): void {
        $history = get_post_meta($post_id, '_hbbz_change_history', true);
        if (!is_array($history)) {
            $history = [];
        }
        $history[] = [
            'time_utc' => gmdate('c'),
            'action' => sanitize_key($action),
            'old_attachment_id' => $old_attachment_id,
            'new_attachment_id' => $new_attachment_id,
            'user_id' => get_current_user_id(),
        ];
        if (count($history) > 100) {
            $history = array_slice($history, -100);
        }
        update_post_meta($post_id, '_hbbz_change_history', $history);
    }

    public static function edit_processed_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Nicht erlaubt.');
        }
        $post_id = isset($_GET['post_id']) ? absint($_GET['post_id']) : 0;
        check_admin_referer('hbbz_edit_processed_post_' . $post_id);
        $post = get_post($post_id);
        if (!$post instanceof WP_Post || $post->post_type !== 'post') {
            wp_die('Beitrag ungültig.');
        }
        update_option(self::OPTION_TARGET_POST, $post_id, false);
        $attachment_id = (int) get_post_thumbnail_id($post_id);
        if ($attachment_id > 0 && get_post_meta($attachment_id, '_hbbz_provider', true) !== '') {
            update_option(self::OPTION_SELECTION, [
                'post_id' => $post_id,
                'provider' => (string) get_post_meta($attachment_id, '_hbbz_provider', true),
                'image_id' => (string) get_post_meta($attachment_id, '_hbbz_asset_id', true),
                'page_url' => (string) get_post_meta($attachment_id, '_hbbz_source_page', true),
                'photographer' => (string) get_post_meta($attachment_id, '_hbbz_photographer', true),
                'photographer_url' => (string) get_post_meta($attachment_id, '_hbbz_photographer_url', true),
                'attachment_id' => $attachment_id,
                'status' => 'featured_image_set',
            ], false);
        } else {
            delete_option(self::OPTION_SELECTION);
        }
        wp_safe_redirect(admin_url('admin.php?page=hab-und-bewahr-bildzentrale&edit_post=' . $post_id));
        exit;
    }

    public static function remove_featured_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Nicht erlaubt.');
        }
        $post_id = isset($_GET['post_id']) ? absint($_GET['post_id']) : 0;
        check_admin_referer('hbbz_remove_featured_post_' . $post_id);
        $attachment_id = (int) get_post_thumbnail_id($post_id);
        if ($attachment_id > 0) {
            delete_post_thumbnail($post_id);
            update_post_meta($attachment_id, '_hbbz_use_status', 'unassigned_kept_in_media_library');
            update_post_meta($attachment_id, '_hbbz_unassigned_at_utc', gmdate('c'));
            self::add_history($post_id, 'featured_removed', $attachment_id, 0);
        }
        if (self::get_target_post_id() === $post_id) {
            delete_option(self::OPTION_SELECTION);
        }
        wp_safe_redirect(admin_url('admin.php?page=hab-und-bewahr-bildzentrale&removed=1'));
        exit;
    }

    public static function remove_content_image_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Nicht erlaubt.');
        }
        $post_id = isset($_GET['post_id']) ? absint($_GET['post_id']) : 0;
        $attachment_id = isset($_GET['attachment_id']) ? absint($_GET['attachment_id']) : 0;
        check_admin_referer('hbbz_remove_content_image_' . $post_id . '_' . $attachment_id);
        $backup_key = '_hbbz_content_backup_' . $attachment_id;
        $backup = get_post_meta($post_id, $backup_key, true);
        if (metadata_exists('post', $post_id, $backup_key) && is_string($backup)) {
            wp_update_post(['ID' => $post_id, 'post_content' => $backup]);
            delete_post_meta($post_id, $backup_key);
        } else {
            $post = get_post($post_id);
            if ($post instanceof WP_Post) {
                $pattern = '/<!-- wp:image[^>]*"id":' . preg_quote((string) $attachment_id, '/') . '[^>]*-->.*?<!-- \/wp:image -->/s';
                $clean = preg_replace($pattern, '', $post->post_content, 1);
                if (is_string($clean) && $clean !== $post->post_content) {
                    wp_update_post(['ID' => $post_id, 'post_content' => $clean]);
                }
            }
        }
        delete_post_meta($attachment_id, '_hbbz_content_image_post_id');
        update_post_meta($attachment_id, '_hbbz_use_status', 'unassigned_kept_in_media_library');
        self::add_history($post_id, 'content_image_removed', $attachment_id, 0);
        wp_safe_redirect(admin_url('admin.php?page=hab-und-bewahr-bildzentrale&content_removed=1'));
        exit;
    }

    private static function render_processed_posts(): void {
        $posts = get_posts([
            'post_type' => 'post',
            'post_status' => ['publish', 'draft'],
            'posts_per_page' => 100,
            'orderby' => 'modified',
            'order' => 'DESC',
            'meta_query' => [[
                'key' => '_thumbnail_id',
                'compare' => 'EXISTS',
            ]],
        ]);
        $rows = [];
        foreach ($posts as $post) {
            $thumb_id = (int) get_post_thumbnail_id($post->ID);
            $content_images = get_posts([
                'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 20,
                'fields' => 'ids', 'meta_key' => '_hbbz_content_image_post_id', 'meta_value' => $post->ID,
            ]);
            $is_hbbz_thumb = $thumb_id > 0 && get_post_meta($thumb_id, '_hbbz_provider', true) !== '';
            if ($is_hbbz_thumb || $content_images) {
                $rows[] = [$post, $thumb_id, $content_images];
            }
        }
        if (!$rows) {
            echo '<p>Noch keine durch die Bildzentrale bearbeiteten Beiträge.</p>';
            return;
        }
        echo '<table class="widefat striped"><thead><tr><th>Beitrag</th><th>Aktuelles Beitragsbild</th><th>Inhaltsbilder</th><th>Aktionen</th></tr></thead><tbody>';
        foreach ($rows as [$post, $thumb_id, $content_images]) {
            $edit_url = wp_nonce_url(add_query_arg(['action'=>'hbbz_edit_processed_post','post_id'=>$post->ID], admin_url('admin-post.php')), 'hbbz_edit_processed_post_' . $post->ID);
            $remove_url = wp_nonce_url(add_query_arg(['action'=>'hbbz_remove_featured_post','post_id'=>$post->ID], admin_url('admin-post.php')), 'hbbz_remove_featured_post_' . $post->ID);
            echo '<tr><td>#' . esc_html((string)$post->ID) . ' – ' . esc_html(get_the_title($post)) . '</td><td>';
            if ($thumb_id > 0) {
                echo wp_get_attachment_image($thumb_id, [120,68], false, ['style'=>'width:120px;height:68px;object-fit:cover']);
                echo '<br>#' . esc_html((string)$thumb_id);
            } else { echo '–'; }
            echo '</td><td>';
            if ($content_images) {
                foreach ($content_images as $content_id) {
                    $content_remove_url = wp_nonce_url(add_query_arg(['action'=>'hbbz_remove_content_image_post','post_id'=>$post->ID,'attachment_id'=>$content_id], admin_url('admin-post.php')), 'hbbz_remove_content_image_' . $post->ID . '_' . $content_id);
                    echo '<div style="margin-bottom:8px">#' . esc_html((string)$content_id) . ' <a class="button button-small" href="' . esc_url($content_remove_url) . '" onclick="return confirm(\'Inhaltsbild wirklich entfernen?\')">entfernen</a></div>';
                }
            } else { echo '–'; }
            echo '</td><td><a class="button button-primary" href="' . esc_url($edit_url) . '">Bilder bearbeiten / ersetzen</a> ';
            if ($thumb_id > 0) {
                echo '<a class="button" href="' . esc_url($remove_url) . '" onclick="return confirm(\'Beitragsbild wirklich entfernen?\')">Beitragsbild entfernen</a>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table>';
    }

    private static function render_post_history(int $post_id): void {
        $history = get_post_meta($post_id, '_hbbz_change_history', true);
        if (!is_array($history) || !$history) {
            echo '<p>Noch keine protokollierten Änderungen.</p>';
            return;
        }
        echo '<table class="widefat striped"><thead><tr><th>Zeit (UTC)</th><th>Aktion</th><th>Alt</th><th>Neu</th></tr></thead><tbody>';
        foreach (array_reverse($history) as $entry) {
            echo '<tr><td>' . esc_html((string)($entry['time_utc'] ?? '')) . '</td><td>' . esc_html((string)($entry['action'] ?? '')) . '</td><td>#' . esc_html((string)($entry['old_attachment_id'] ?? 0)) . '</td><td>#' . esc_html((string)($entry['new_attachment_id'] ?? 0)) . '</td></tr>';
        }
        echo '</tbody></table>';
    }


    public static function choose_queue_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Nicht erlaubt.');
        }
        $post_id = isset($_GET['post_id']) ? absint($_GET['post_id']) : 0;
        check_admin_referer('hbbz_choose_queue_post_' . $post_id);
        $post = get_post($post_id);
        if (!$post instanceof WP_Post || $post->post_type !== 'post') {
            wp_die('Ungültiger Beitrag.');
        }
        update_option(self::OPTION_TARGET_POST, $post_id, false);
        wp_safe_redirect(add_query_arg([
            'page' => 'hab-und-bewahr-bildzentrale',
            'hbbz_queue_selected' => $post_id,
        ], admin_url('admin.php')));
        exit;
    }

    public static function save_target_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die('Nicht erlaubt.');
        }
        check_admin_referer('hbbz_save_target_post');
        $post_id = isset($_POST['hbbz_target_post_id']) ? absint($_POST['hbbz_target_post_id']) : 0;
        $post = get_post($post_id);
        if (!$post instanceof WP_Post || $post->post_type !== 'post') {
            wp_die('Ungültige Beitrags-ID.');
        }
        update_option(self::OPTION_TARGET_POST, $post_id, false);
        wp_safe_redirect(add_query_arg(['page' => 'hab-und-bewahr-bildzentrale'], admin_url('admin.php')));
        exit;
    }
    private static function get_target_post_id(): int {
        $post_id=absint(get_option(self::OPTION_TARGET_POST,0));
        return $post_id>0?$post_id:0;
    }

    private static function render_magnific_results($post): void {
        if (!$post instanceof WP_Post) {
            echo '<p>Kein gültiger Arbeitsbeitrag gewählt.</p>';
            return;
        }
        $results = get_post_meta($post->ID, '_hbbz_magnific_results', true);
        if (!is_array($results) || empty($results['images']) || !is_array($results['images'])) {
            echo '<p>Noch keine fertigen KI-Bilder vorhanden.</p>';
            return;
        }
        echo '<div class="hbbz-grid">';
        foreach ($results['images'] as $index => $image) {
            $url = esc_url((string) ($image['url'] ?? ''));
            if ($url === '') { continue; }
            $label = esc_html((string) ($image['label'] ?? ('KI-Bild ' . ((int) $index + 1))));
            echo '<div class="hbbz-card">';
            echo '<img src="' . $url . '" alt="' . $label . '" loading="lazy">';
            echo '<p>' . $label . '</p>';
            echo '<button type="button" class="button button-primary" id="hbbz-magnific-import-' . (int) $index . '" data-index="' . (int) $index . '">In Mediathek laden</button> ';
            echo '<button type="button" class="button" id="hbbz-magnific-apply-' . (int) $index . '" data-index="' . (int) $index . '">Direkt als Beitragsbild übernehmen</button>';
            echo '</div>';
        }
        echo '</div>';
    }
    private static function default_visual_policy(): string {
        return 'Photorealistic premium editorial photography for Hab & Bewahr, a German portal about protecting private property, homes, flats, gardens, garages, vehicles, boats, campsites, small owner-run businesses and clubs. Derive the exact protection scenario from the real page title and its content, not only from a generic risk word. Show ONE specific credible scene illustrating the stated risk, preventative measure or resulting condition; real installations, plausible material details and appropriate surroundings. Select the real location and object that the topic names: e.g. protected entrance door for a lock topic, window glass for vandalism, cellar drain for backflow, roof for storm, camper storage for absence. If an activity is important, one adult technician or homeowner may use equipment naturally; otherwise omit people. No staged burglary, weapons, violent acts, injuries, fearmongering, hazard reenactments, or apparent endorsement. Keep the image technically plausible, clearly readable at thumbnail size, with a single dominant motif, authentic perspective and natural daylight. Calm trustworthy colors matching sage-grey and warm neutral design. One individual photograph only; no collages, multi-panel layouts, illustrative composites, symbols, padlock clipart, text, captions, logos, product brand names, ads, watermarks, borders or embedded graphics. Never invent a safety certification, protective rating or product-specific claim. Keep the subject inside a wide crop-safe area so the same original scene can be used consistently as category tile and page hero when the website layout permits. Use visible variety of objects and situations across pages, but not unrelated decorative motifs.';
    }
    private static function default_magnific_style(): string {
        return self::default_visual_policy() . ' Keep essential content safely inside the crop-safe area. Master composition ratio 3:2.';
    }
    private static function maybe_upgrade_prompt_rules(): void {
        $version = (string) get_option(self::OPTION_PROMPT_RULES_VERSION, '');
        if ($version === 'hab-und-bewahr-1.0') { return; }
        $style = self::default_magnific_style();
        $exclusions = 'logo, brand, text, watermark, collage, split image, multiple unrelated scenes, duplicate objects, malformed hands, fake technical installations, misleading equipment, implausible handling, staged crimes, weapons, injuries, unsafe depiction, abstract padlock icon, fantasy scene, cluttered background, decorative people';
        update_option(self::OPTION_MAGNIFIC_STYLE, $style, false);
        update_option(self::OPTION_EXCLUSIONS, $exclusions, false);
        $profiles = get_option(self::OPTION_GENERAL_PROFILES, []);
        if (is_array($profiles) && isset($profiles['article']) && is_array($profiles['article'])) {
            $profiles['article']['base_prompt'] = $style;
            $profiles['article']['negative_prompt'] = $exclusions;
            $profiles['article']['subject_rule'] = 'Derive the topic from the article title, excerpt and first 120 words. Show a single technically credible property protection situation with the named object; no generic danger or security icon. People only when demonstrating a relevant realistic action.';
            update_option(self::OPTION_GENERAL_PROFILES, $profiles, false);
        }
        update_option(self::OPTION_PROMPT_RULES_VERSION, 'hab-und-bewahr-1.0', false);
    }
    private static function available_motif_clusters(): array {
        return [
            'einbruch' => 'Einbruch und Diebstahl', 'vandalismus' => 'Vandalismus und Beschädigung',
            'wasser' => 'Wasser und Feuchtigkeit', 'feuer' => 'Feuer und Gase',
            'wetter' => 'Wetter und Naturgefahren', 'technik' => 'Technik und Ausfälle',
            'camping' => 'Camping, Fahrzeuge und Boote', 'versicherung' => 'Versicherung und Schadenfall',
            'general' => 'Eigentumsschutz allgemein',
        ];
    }
    private static function forced_cluster_profile(string $cluster): array {
        $labels = self::available_motif_clusters();
        if (!isset($labels[$cluster])) { return []; }
        $label = $labels[$cluster];
        $scene = 'one specific, authentic property protection scenario matching the selected risk area ' . $label . ' and directly illustrates the article topic';
        return [
            'scene' => $scene,
            'background' => 'the specific private property or small owner-managed premises named in the topic',
            'weather' => 'natural light appropriate to the scene',
            'people' => 'when an activity can be shown, prefer natural human involvement that explains it clearly; hands, arms or a person actively using the relevant tools or materials are especially suitable; never use decorative people without a relevant action',
            'cluster' => $cluster,
            'cluster_label' => $label,
            'motif_variants' => [
                'authentic overview of the protected object and exact safety situation',
                'credible installation or inspection of the concrete protection measure',
                'specific real construction detail explaining the risk or preventative step',
                'realistic completed protective measure, not a generic symbol',
            ],
            'background_pool' => ['private home','garden or garage','small local business','relevant outdoor property'],
            'object_pool' => ['protected object','realistic security hardware','relevant building detail','credible safety measure'],
            'weather_mode' => 'credible',
            'people_mode' => 'relevant_only',
        ];
    }
    private static function translate_custom_motif(string $custom_motif): string {
        return trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($custom_motif)) ?: $custom_motif);
    }
    private static function custom_motif_profile(string $custom_motif): array {
        $motif = self::translate_custom_motif($custom_motif);
        $lower = self::utf8_lower($motif);
        $no_people = preg_match('/\b(ohne|kein|keine|keinen)\s+(mensch|menschen|person|personen)\b/u', $lower) === 1;
        return [
            'scene' => 'a realistic scene centered specifically and unambiguously on ' . $motif . '; the editor-defined action and all named objects must be clearly visible',
            'background' => 'a clean, attractive and contextually appropriate real-world environment that supports the editor-defined motif without distracting from it',
            'weather' => 'natural light appropriate to the requested scene unless the motif itself requires a specific condition',
            'people' => $no_people ? 'no people visible anywhere in the image' : 'when the motif contains an activity, show natural human involvement that makes the action immediately understandable; hands, arms or a person actively performing the task are preferred; never use decorative people',
            'cluster' => 'custom_' . substr(md5($custom_motif), 0, 10),
            'cluster_label' => 'Eigene Schutzszene: ' . $custom_motif,
            'motif_variants' => [$motif, 'a practical scene showing ' . $motif, 'a clear editorial scene focused on ' . $motif],
            'background_pool' => ['clean work or activity area','contextually suitable indoor setting','contextually suitable outdoor setting'],
            'object_pool' => [$motif],
            'weather_mode' => 'credible',
            'people_mode' => $no_people ? 'none' : 'relevant_only',
            'translated_motif' => $motif,
        ];
    }
    private static function analyze_article_for_image($post, string $forced_cluster = 'auto', string $custom_motif = ''): array {
        $fallback = [
            'context' => 'A practical guide to protecting private property.',
            'scene' => 'one real and specific property-protection situation derived from the article',
            'background' => 'the relevant property, building or outdoor location actually mentioned by the title',
            'weather' => 'pleasant natural light appropriate to the scene',
            'people' => 'show an adult only when demonstrably inspecting or installing a protection measure; omit unrelated people',
            'cluster' => 'general', 'cluster_label' => 'Allgemeines Schutzthema',
            'motif_variants' => ['authentic overview of the protected object and exact safety situation','credible installation or inspection of the concrete protection measure','authentic detail explaining the topic','finished result or typical use'],
            'background_pool' => ['private home','garden or garage','small local business','relevant outdoor property'],
            'object_pool' => ['protected object','realistic security hardware','relevant building detail','credible safety measure'],
            'weather_mode' => 'credible', 'people_mode' => 'relevant_only',
        ];
        if (!$post instanceof WP_Post) { return $fallback; }
        $custom_motif = trim($custom_motif);
        if ($custom_motif !== '') {
            $custom = self::custom_motif_profile($custom_motif);
            $custom['context'] = 'Highest-priority editor-defined motif: ' . (string)($custom['translated_motif'] ?? $custom_motif) . '.';
            return array_merge($fallback, $custom);
        }
        $title = trim(wp_strip_all_tags(get_the_title($post)));
        $excerpt = trim(wp_strip_all_tags((string)$post->post_excerpt));
        $content = trim(wp_strip_all_tags(strip_shortcodes((string)$post->post_content)));
        $content_context = trim(wp_trim_words($content, 120, ''));
        $context_parts = [];
        if ($title !== '') { $context_parts[] = 'Article title: ' . $title . '.'; }
        if ($excerpt !== '') { $context_parts[] = 'Article summary: ' . wp_trim_words($excerpt, 45, '') . '.'; }
        if ($content_context !== '') { $context_parts[] = 'Article content: ' . $content_context . '.'; }
        $context = trim(implode(' ', $context_parts));
        if ($context === '') { $context = $fallback['context']; }
        $analysis = $fallback; $analysis['context'] = $context;
        if ($forced_cluster === 'auto') {
            $subject = self::utf8_lower($title . ' ' . $excerpt . ' ' . $content_context);
            $patterns = [
                'einbruch' => '/einbruch|diebstahl|schloss|schließ|alarm|tresor|zutritt|abschließ|sicherungsfolie/u',
                'vandalismus' => '/vandal|sachbeschäd|graffiti|zerstör|schmiererei|sabotage/u',
                'wasser' => '/wasser|rückstau|überflut|feuchte|leck|rohrbruch|hochwasser|kellerablauf/u',
                'feuer' => '/brand|feuer|rauch|kohlenmonoxid|co.melder|lösch|gasleck/u',
                'wetter' => '/sturm|hagel|blitz|frost|schnee|hitze|unwetter|naturgefahr/u',
                'technik' => '/strom|ausfall|überspann|pv.anlage|wallbox|akku|notstrom|überwach/u',
                'camping' => '/camping|wohnmobil|wohnwagen|boot|trailer|stellplatz|motorrad/u',
                'versicherung' => '/versicher|schadenmeldung|regulier|leistungsfall/u',
            ];
            foreach ($patterns as $key => $pattern) {
                if (preg_match($pattern, $subject) === 1) {
                    $analysis = array_merge($analysis, self::forced_cluster_profile($key));
                    break;
                }
            }
        }
        if ($forced_cluster !== 'auto') {
            $forced = self::forced_cluster_profile($forced_cluster);
            if ($forced) { $analysis = array_merge($analysis, $forced); }
        }
        return $analysis;
    }

    private static function get_variation_history(): array {
        $history = get_option(self::OPTION_VARIATION_HISTORY, []);
        return is_array($history) ? array_values($history) : [];
    }

    private static function pick_variation_value(string $field, array $candidates, array $recent_global, array $recent_cluster, string $seed): string {
        $candidates = array_values(array_unique(array_filter(array_map('strval', $candidates))));
        if (!$candidates) {
            return '';
        }
        $scored = [];
        foreach ($candidates as $candidate) {
            $score = 0;
            foreach ($recent_global as $offset => $entry) {
                if (($entry[$field] ?? '') === $candidate) {
                    $score += 3 + max(0, 8 - $offset);
                }
            }
            foreach ($recent_cluster as $offset => $entry) {
                if (($entry[$field] ?? '') === $candidate) {
                    $score += 6 + max(0, 10 - $offset);
                }
            }
            $score += abs(crc32($seed . '|' . $field . '|' . $candidate)) % 7 / 100;
            $scored[] = ['value' => $candidate, 'score' => $score];
        }
        usort($scored, static function (array $a, array $b): int {
            return $a['score'] <=> $b['score'];
        });
        return (string) $scored[0]['value'];
    }
    private static function build_variation_plan($post, string $forced_cluster = 'auto', string $custom_motif = ''): array {
        $analysis = self::analyze_article_for_image($post, $forced_cluster, $custom_motif);
        $post_id = $post instanceof WP_Post ? (int)$post->ID : 0;
        $seed = $post_id > 0 ? $post_id : crc32((string)($analysis['context'] ?? 'property protection topic'));
        $history = self::get_variation_history();
        $cluster = (string)($analysis['cluster'] ?? 'general');
        $recent_global = array_slice($history, -20);
        $recent_cluster = array_values(array_filter($recent_global, static fn($entry): bool => is_array($entry) && (string)($entry['cluster'] ?? '') === $cluster));
        $people_pool = ($analysis['people_mode'] ?? 'relevant_only') === 'none' ? ['no people shown'] : ['no people unless necessary','adult technician inspecting the actual object','hands operating the relevant safety device','adult homeowner checking the relevant area'];
        $light_pool = ['soft natural daylight','bright neutral daylight','warm natural daylight','diffuse natural light'];
        $perspectives = ['three-quarter perspective','slightly angled side view','eye-level perspective','slightly elevated perspective'];
        $shot_types = ['medium-wide shot','context-rich wide shot','practical detail shot','balanced overview shot'];
        $compositions = ['subject centered with safe space','subject slightly off-center with balanced negative space','foreground-led composition with clear depth','clean layered composition'];
        $plan = [
            'cluster' => $cluster,
            'cluster_label' => (string)($analysis['cluster_label'] ?? 'Allgemeines Schutzthema'),
            'motif_variant' => self::pick_variation_value('motif_variant',(array)($analysis['motif_variants'] ?? ['specific property protection scene']),$recent_global,$recent_cluster,$seed),
            'people_mode' => self::pick_variation_value('people_mode',$people_pool,$recent_global,$recent_cluster,$seed),
            'background_type' => self::pick_variation_value('background_type',(array)($analysis['background_pool'] ?? ['clean context-appropriate background']),$recent_global,$recent_cluster,$seed),
            'light_detail' => self::pick_variation_value('light_detail',$light_pool,$recent_global,$recent_cluster,$seed),
            'perspective' => self::pick_variation_value('perspective',$perspectives,$recent_global,$recent_cluster,$seed),
            'shot_type' => self::pick_variation_value('shot_type',$shot_types,$recent_global,$recent_cluster,$seed),
            'composition' => self::pick_variation_value('composition',$compositions,$recent_global,$recent_cluster,$seed),
            'object_focus' => self::pick_variation_value('object_focus',(array)($analysis['object_pool'] ?? ['main practical topic detail']),$recent_global,$recent_cluster,$seed),
        ];
        $avoid_values=[];
        foreach(['background_type','perspective','people_mode','object_focus'] as $field){
            foreach($recent_cluster as $entry){$value=(string)($entry[$field]??'');if($value!==''&&!in_array($value,$avoid_values,true))$avoid_values[]=$value;if(count($avoid_values)>=5)break 2;}
        }
        $plan['avoid_values']=$avoid_values;
        $plan['prompt_block']='Variation: '.$plan['motif_variant'].'; '.$plan['background_type'].'; '.$plan['light_detail'].'; '.$plan['perspective'].'; '.$plan['shot_type'].'; focus on '.$plan['object_focus'].'; people: '.$plan['people_mode'].'.';
        return $plan;
    }
    private static function summarize_variation_plan(array $plan): string {
        if (!$plan) { return ''; }
        $parts=[];
        foreach(['motif_variant','people_mode','background_type','light_detail','perspective','object_focus'] as $field){$value=trim((string)($plan[$field]??''));if($value!=='')$parts[]=$value;}
        return implode(' · ',$parts);
    }
    private static function record_variation_history(int $post_id, string $asset_key, array $plan): void {
        if ($asset_key === '' || !$plan) { return; }
        $history=self::get_variation_history();
        foreach($history as $entry){if((string)($entry['asset_key']??'')===$asset_key)return;}
        $entry=[
            'timestamp_utc'=>gmdate('c'),'post_id'=>$post_id,'asset_key'=>$asset_key,
            'cluster'=>(string)($plan['cluster']??''),'motif_variant'=>(string)($plan['motif_variant']??''),
            'people_mode'=>(string)($plan['people_mode']??''),'background_type'=>(string)($plan['background_type']??''),
            'light_detail'=>(string)($plan['light_detail']??''),'perspective'=>(string)($plan['perspective']??''),
            'shot_type'=>(string)($plan['shot_type']??''),'composition'=>(string)($plan['composition']??''),'object_focus'=>(string)($plan['object_focus']??''),
        ];
        $history[]=$entry;if(count($history)>500)$history=array_slice($history,-500);update_option(self::OPTION_VARIATION_HISTORY,array_values($history),false);
    }
    private static function suggest_magnific_prompt($post, string $forced_cluster = 'auto', string $custom_motif = ''): string {
        $style=trim((string)get_option(self::OPTION_MAGNIFIC_STYLE,self::default_magnific_style()));
        $analysis=self::analyze_article_for_image($post,$forced_cluster,$custom_motif);
        $variation=self::build_variation_plan($post,$forced_cluster,$custom_motif);
        $title=$post instanceof WP_Post?trim(wp_strip_all_tags(get_the_title($post))):'Property protection article';
        $prompt=$style
            .' Create one clear scene that directly illustrates this topic: "'.$title.'".'
            .' Context: '.$analysis['context']
            .' Main scene: '.$analysis['scene'].'.'
            .' Background: '.$analysis['background'].'.'
            .' Light: '.$analysis['weather'].'.'
            .' People: '.$analysis['people'].'.'
            .' '.$variation['prompt_block']
            .' Keep the image authentic, useful and visually clear. No visible brands. No written words. Landscape composition, 3:2.';
        $prompt=preg_replace('/\s+/u',' ',trim($prompt))?:trim($prompt);
        if(self::utf8_len($prompt)>3000)$prompt=self::utf8_substr($prompt,0,2997).'...';
        return $prompt;
    }

    private static function local_magnific_credit_stats(): array {
        $ids = [];
        $map = get_option(self::OPTION_MAGNIFIC_TASK_MAP, []);
        if (is_array($map)) {
            foreach (array_keys($map) as $task_id) {
                if (is_string($task_id) && $task_id !== '') { $ids[$task_id] = true; }
            }
        }
        $registry = get_option(self::OPTION_MAGNIFIC_TASK_REGISTRY, []);
        if (is_array($registry)) {
            foreach ($registry as $tasks) {
                if (!is_array($tasks)) { continue; }
                foreach ($tasks as $task) {
                    $task_id = is_array($task) ? (string) ($task['task_id'] ?? '') : '';
                    if ($task_id !== '') { $ids[$task_id] = true; }
                }
            }
        }
        $count = count($ids);
        return ['tasks' => $count, 'credits' => $count * 75];
    }
    private static function suggest_query_for_post($post): string {
        if (!$post instanceof WP_Post) { return 'home security safeguards'; }
        $title=self::utf8_lower(wp_strip_all_tags(get_the_title($post)));
        $clean=preg_replace('/[^a-z0-9äöüß ]/u',' ',$title);
        $clean=trim((string)preg_replace('/\s+/',' ',(string)$clean));
        return self::utf8_substr($clean!==''?$clean:'home security safeguards',0,100);
    }

    public static function insert_content_image(): void {
        self::assert_ajax_access();
        $selection = get_option(self::OPTION_SELECTION, []);
        if (!is_array($selection) || empty($selection['attachment_id'])) {
            wp_send_json_error('Kein Mediathek-Bild ausgewählt.');
        }
        $target_post_id = self::get_target_post_id();
        $post = get_post($target_post_id);
        if (!$post instanceof WP_Post || $post->post_type !== 'post') {
            wp_send_json_error('Der gewählte Beitrag wurde nicht gefunden.');
        }
        $attachment_id = absint($selection['attachment_id']);
        $url = wp_get_attachment_image_url($attachment_id, 'large');
        if (!$url) {
            wp_send_json_error('Bild-URL konnte nicht ermittelt werden.');
        }
        $marker_start = '<!-- HBBZ-CONTENT-IMAGE-START:' . $attachment_id . ' -->';
        $marker_end = '<!-- HBBZ-CONTENT-IMAGE-END:' . $attachment_id . ' -->';
        if (str_contains($post->post_content, $marker_start)) {
            wp_send_json_error('Dieses Inhaltsbild ist bereits eingesetzt.');
        }

        $heading_index = isset($_POST['heading_index']) ? absint($_POST['heading_index']) : 0;
        $headings = self::extract_heading_blocks($post->post_content);
        if (!$headings) {
            wp_send_json_error('Der Beitrag enthält keine Gutenberg-Zwischenüberschrift.');
        }
        if (!isset($headings[$heading_index])) {
            wp_send_json_error('Die gewählte Zwischenüberschrift wurde nicht gefunden.');
        }

        $alt = (string) get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
        $caption = self::build_credit_text($attachment_id, false);
        $caption_html = $caption !== '' ? '<figcaption class="wp-element-caption">' . wp_kses_post($caption) . '</figcaption>' : '';
        $block = "\n" . $marker_start . "\n<!-- wp:image {\"id\":" . $attachment_id . ",\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"" . esc_url($url) . "\" alt=\"" . esc_attr($alt) . "\" class=\"wp-image-" . $attachment_id . "\"/>" . $caption_html . "</figure>\n<!-- /wp:image -->\n" . $marker_end . "\n";
        $selected_heading = $headings[$heading_index];
        $pos = $selected_heading['offset'] + strlen($selected_heading['block']);
        $content = $post->post_content;
        $new_content = substr($content, 0, $pos) . $block . substr($content, $pos);

        update_post_meta($target_post_id, '_hbbz_content_backup_' . $attachment_id, $content);
        $updated = wp_update_post(['ID' => $target_post_id, 'post_content' => $new_content], true);
        if (is_wp_error($updated)) {
            wp_send_json_error('Inhaltsbild konnte nicht eingesetzt werden: ' . $updated->get_error_message());
        }
        $selection['content_image_status'] = 'inserted';
        $selection['content_image_heading_index'] = $heading_index;
        $selection['content_image_inserted_at_utc'] = gmdate('c');
        update_option(self::OPTION_SELECTION, $selection, false);
        update_post_meta($attachment_id, '_hbbz_content_image_post_id', $target_post_id);
        update_post_meta($attachment_id, '_hbbz_content_heading_index', $heading_index);
        update_post_meta($attachment_id, '_hbbz_use_status', 'content_image_post_' . $target_post_id);
        self::add_history($target_post_id, 'content_image_inserted', 0, $attachment_id);
        wp_send_json_success(['post_id' => $target_post_id, 'attachment_id' => $attachment_id, 'heading_index' => $heading_index]);
    }

    public static function undo_content_image(): void {
        self::assert_ajax_access();
        $selection = get_option(self::OPTION_SELECTION, []);
        if (!is_array($selection) || empty($selection['attachment_id'])) {
            wp_send_json_error('Keine Inhaltsbild-Zuordnung vorhanden.');
        }
        $target_post_id = self::get_target_post_id();
        $attachment_id = absint($selection['attachment_id']);
        $backup_key = '_hbbz_content_backup_' . $attachment_id;
        $backup = get_post_meta($target_post_id, $backup_key, true);
        if (!metadata_exists('post', $target_post_id, $backup_key) || !is_string($backup)) {
            wp_send_json_error('Sicherungsstand des Beitrags fehlt.');
        }
        $updated = wp_update_post(['ID' => $target_post_id, 'post_content' => $backup], true);
        if (is_wp_error($updated)) {
            wp_send_json_error('Sicherungsstand konnte nicht wiederhergestellt werden: ' . $updated->get_error_message());
        }
        delete_post_meta($target_post_id, $backup_key);
        delete_post_meta($attachment_id, '_hbbz_content_image_post_id');
        self::add_history($target_post_id, 'content_image_removed', $attachment_id, 0);
        $selection['content_image_status'] = 'not_inserted';
        $selection['content_image_removed_at_utc'] = gmdate('c');
        update_option(self::OPTION_SELECTION, $selection, false);
        wp_send_json_success(['post_id' => $target_post_id, 'attachment_id' => $attachment_id]);
    }

    private static function extract_heading_blocks(string $content): array {
        $matches = [];
        preg_match_all('/<!-- wp:heading[^>]*-->.*?<!-- \/wp:heading -->/s', $content, $matches, PREG_OFFSET_CAPTURE);
        $headings = [];
        foreach ($matches[0] ?? [] as $index => $match) {
            $block = (string) ($match[0] ?? '');
            $offset = (int) ($match[1] ?? 0);
            $label = trim(wp_strip_all_tags(preg_replace('/<!--.*?-->/s', '', $block)));
            if ($label === '') {
                $label = 'Zwischenüberschrift ' . ($index + 1);
            }
            $headings[] = ['block' => $block, 'offset' => $offset, 'label' => $label];
        }
        return $headings;
    }

    private static function render_heading_selector($post): void {
        if (!$post instanceof WP_Post) {
            return;
        }
        $headings = self::extract_heading_blocks($post->post_content);
        if (!$headings) {
            echo '<p><em>Keine Gutenberg-Zwischenüberschrift gefunden.</em></p>';
            return;
        }
        echo '<p><label for="hbbz-content-heading-index"><strong>Inhaltsbild einfügen nach:</strong></label><br>';
        echo '<select id="hbbz-content-heading-index">';
        foreach ($headings as $index => $heading) {
            echo '<option value="' . esc_attr((string) $index) . '">' . esc_html(($index + 1) . '. ' . $heading['label']) . '</option>';
        }
        echo '</select></p>';
    }

    private static function build_credit_text(int $attachment_id, bool $linked = true): string {
        $provider = strtolower((string) get_post_meta($attachment_id, '_hbbz_provider', true));
        $photographer = trim((string) get_post_meta($attachment_id, '_hbbz_photographer', true));
        $photographer_url = (string) get_post_meta($attachment_id, '_hbbz_photographer_url', true);
        $source_url = (string) get_post_meta($attachment_id, '_hbbz_source_page', true);
        if (!in_array($provider, ['pixabay', 'pexels'], true)) {
            return '';
        }
        $provider_name = $provider === 'pexels' ? 'Pexels' : 'Pixabay';
        if (!$linked) {
            $parts = [];
            if ($photographer !== '') {
                $parts[] = 'Foto: ' . esc_html($photographer);
            }
            $parts[] = esc_html($provider_name);
            return implode(' · ', $parts);
        }
        $parts = [];
        if ($photographer !== '') {
            $name = esc_html($photographer);
            if ($photographer_url !== '') {
                $name = '<a href="' . esc_url($photographer_url) . '" target="_blank" rel="noopener noreferrer nofollow">' . $name . '</a>';
            }
            $parts[] = 'Foto: ' . $name;
        }
        $provider_html = esc_html($provider_name);
        if ($source_url !== '') {
            $provider_html = '<a href="' . esc_url($source_url) . '" target="_blank" rel="noopener noreferrer nofollow">' . $provider_html . '</a>';
        }
        $parts[] = $provider_html;
        return implode(' · ', $parts);
    }

    public static function append_frontend_credits(string $content): string {
        if (is_admin() || !is_singular('post') || !in_the_loop() || !is_main_query()) {
            return $content;
        }

        $post_id = get_the_ID();
        if (!$post_id) {
            return $content;
        }

        $featured_id = (int) get_post_thumbnail_id($post_id);
        if ($featured_id <= 0 || (string) get_post_meta($featured_id, '_hbbz_provider', true) === '') {
            return $content;
        }

        // Doppelanzeige verhindern, wenn das Bild bereits bewusst im Artikelinhalt steckt.
        $attachment_url = (string) wp_get_attachment_url($featured_id);
        $attachment_basename = $attachment_url !== '' ? wp_basename(parse_url($attachment_url, PHP_URL_PATH) ?: '') : '';
        if (
            str_contains($content, 'wp-image-' . $featured_id) ||
            str_contains($content, 'HBBZ-FEATURED-IMAGE:' . $featured_id) ||
            ($attachment_basename !== '' && str_contains($content, $attachment_basename))
        ) {
            return $content;
        }

        $alt = trim((string) get_post_meta($featured_id, '_wp_attachment_image_alt', true));
        if ($alt === '') {
            $alt = get_the_title($post_id);
        }

        $image = wp_get_attachment_image(
            $featured_id,
            'full',
            false,
            [
                'class' => 'hbbz-article-featured-image',
                'alt' => $alt,
                'loading' => 'eager',
                'fetchpriority' => 'high',
                'decoding' => 'async',
            ]
        );
        if ($image === '') {
            return $content;
        }

        $credit = self::build_credit_text($featured_id, true);
        $caption = $credit !== ''
            ? '<figcaption class="hbbz-featured-credit">' . wp_kses_post($credit) . '</figcaption>'
            : '';

        $figure = '<!-- HBBZ-FEATURED-IMAGE:' . $featured_id . ' -->'
            . '<figure class="hbbz-article-featured">'
            . $image
            . $caption
            . '</figure>';

        $style = '<style id="hbbz-frontend-image-style">'
            . '.hbbz-article-featured,.hbbz-content-image{margin:0 0 2rem!important;padding:0!important;background:none!important;border:0!important;border-radius:0!important;box-shadow:none!important;filter:none!important;transform:none!important;overflow:hidden;}'
            . '.hbbz-article-featured img,.hbbz-content-image img{display:block!important;width:100%!important;height:auto!important;object-fit:contain!important;object-position:center!important;margin:0!important;padding:0!important;border:0!important;border-radius:0!important;box-shadow:none!important;filter:none!important;transform:none!important;transition:none!important;}'
            . '.hbbz-article-featured:hover,.hbbz-content-image:hover,.hbbz-article-featured img:hover,.hbbz-content-image img:hover{border:0!important;border-radius:0!important;box-shadow:none!important;filter:none!important;transform:none!important;opacity:1!important;}'
            . '.hbbz-featured-credit,.hbbz-content-image figcaption{margin:.45rem 0 0!important;font-size:.78em;line-height:1.4;opacity:.78;text-align:left;}'
            . '.hbbz-featured-credit a,.hbbz-content-image figcaption a{color:inherit;text-decoration:underline;}'
            . '</style>';

        return $style . $figure . $content;
    }
    private static function build_alt_text(int $post_id): string {
        $title=trim(wp_strip_all_tags(get_the_title($post_id)));
        $alt=preg_replace('/^(wann|warum|wie|welche|welcher|welches)\s+/iu','',$title);
        $alt=trim((string)preg_replace('/\s+/',' ',(string)$alt));
        return self::utf8_substr($alt!==''?$alt:'Schutzmotiv',0,125);
    }
    private static function build_media_title(int $post_id): string {
        $title=trim(wp_strip_all_tags(get_the_title($post_id)));
        return self::utf8_substr(($title!==''?$title:'Hab & Bewahr Bild'),0,150);
    }
    private static function build_filename_base(int $post_id, string $provider, string $image_id): string {
        $slug=sanitize_title(get_the_title($post_id));if($slug==='')$slug='hab-und-bewahr-bild';
        return sanitize_file_name(substr($slug,0,70).'-'.$provider.'-'.$image_id);
    }

    private static function quality_for_dimensions(int $width, int $height): array {
        if ($width < 1200 || $height < 800) {
            return ['accepted' => false, 'reason' => 'Zu geringe Auflösung'];
        }
        $source_ratio = $width / $height;
        $target_ratio = 3 / 2;
        $retained = $source_ratio > $target_ratio ? $target_ratio / $source_ratio : $source_ratio / $target_ratio;
        if ($retained < 0.70) {
            return ['accepted' => false, 'reason' => 'Zu starker Zuschnitt nötig'];
        }
        return ['accepted' => true, 'reason' => $retained < 0.85 ? 'Geeignet, merklicher Zuschnitt' : 'Sehr gut für 3:2'];
    }

    private static function add_quality_data(array $items): array {
        foreach ($items as &$item) {
            $item['quality'] = self::quality_for_dimensions((int) ($item['width'] ?? 0), (int) ($item['height'] ?? 0));
        }
        unset($item);
        return $items;
    }

    private static function render_quality_audit(): void {
        $ids = get_posts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => [[
                'key' => '_hbbz_provider',
                'compare' => 'EXISTS',
            ]],
        ]);
        $totals = ['all' => 0, 'ok' => 0, 'format' => 0, 'ratio' => 0, 'size' => 0, 'alt' => 0, 'license' => 0];
        foreach ($ids as $attachment_id) {
            $totals['all']++;
            $meta = wp_get_attachment_metadata((int) $attachment_id);
            $width = (int) ($meta['width'] ?? 0);
            $height = (int) ($meta['height'] ?? 0);
            $file = get_attached_file((int) $attachment_id);
            $mime = get_post_mime_type((int) $attachment_id);
            $bad = false;
            if ($mime !== 'image/webp') { $totals['format']++; $bad = true; }
            if ($width < 1 || $height < 1 || abs(($width / max(1, $height)) - (3 / 2)) > 0.02) { $totals['ratio']++; $bad = true; }
            if (is_string($file) && is_file($file) && filesize($file) > 350 * 1024) { $totals['size']++; $bad = true; }
            if (trim((string) get_post_meta((int) $attachment_id, '_wp_attachment_image_alt', true)) === '') { $totals['alt']++; $bad = true; }
            if (trim((string) get_post_meta((int) $attachment_id, '_hbbz_license_name', true)) === '' || trim((string) get_post_meta((int) $attachment_id, '_hbbz_source_page', true)) === '') { $totals['license']++; $bad = true; }
            if (!$bad) { $totals['ok']++; }
        }
        echo '<p><strong>Geprüfte Bildzentrale-Dateien:</strong> ' . esc_html((string) $totals['all']) . '</p>';
        echo '<ul>';
        echo '<li>Vollständig in Ordnung: <strong>' . esc_html((string) $totals['ok']) . '</strong></li>';
        echo '<li>Falsches Dateiformat: ' . esc_html((string) $totals['format']) . '</li>';
        echo '<li>Nicht 3:2: ' . esc_html((string) $totals['ratio']) . '</li>';
        echo '<li>Größer als 350 KB: ' . esc_html((string) $totals['size']) . '</li>';
        echo '<li>Alt-Text fehlt: ' . esc_html((string) $totals['alt']) . '</li>';
        echo '<li>Lizenzangaben unvollständig: ' . esc_html((string) $totals['license']) . '</li>';
        echo '</ul>';
        echo '<p class="description">Die Prüfung verändert keine Dateien. Sie zeigt nur Abweichungen.</p>';
    }

    private static function render_license_register(): void {
        $attachments = get_posts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => 20,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => [[
                'key' => '_hbbz_provider',
                'compare' => 'EXISTS',
            ]],
        ]);
        if (!$attachments) {
            echo '<p>Noch keine Bilder im Lizenzregister.</p>';
            return;
        }
        echo '<table class="widefat striped"><thead><tr><th>Bild</th><th>Anbieter</th><th>Asset-ID</th><th>Fotograf</th><th>Nutzung</th><th>Quelle</th></tr></thead><tbody>';
        foreach ($attachments as $attachment) {
            $id = (int) $attachment->ID;
            $source = (string) get_post_meta($id, '_hbbz_source_page', true);
            echo '<tr>';
            echo '<td>' . esc_html(get_the_title($attachment)) . ' (#' . esc_html((string) $id) . ')</td>';
            echo '<td>' . esc_html((string) get_post_meta($id, '_hbbz_provider', true)) . '</td>';
            echo '<td>' . esc_html((string) get_post_meta($id, '_hbbz_asset_id', true)) . '</td>';
            echo '<td>' . esc_html((string) get_post_meta($id, '_hbbz_photographer', true)) . '</td>';
            echo '<td>' . esc_html((string) get_post_meta($id, '_hbbz_use_status', true)) . '</td>';
            echo '<td>' . ($source !== '' ? '<a href="' . esc_url($source) . '" target="_blank" rel="noopener noreferrer">öffnen</a>' : '–') . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    private static function render_dashboard_summary(): void {
        $without_featured = self::count_posts_without_featured();
        $licensed_images = (int) (new WP_Query([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_query' => [[
                'key' => '_hbbz_provider',
                'compare' => 'EXISTS',
            ]],
        ]))->found_posts;
        echo '<div style="display:flex;gap:12px;flex-wrap:wrap;margin:16px 0">';
        echo '<div class="card" style="min-width:210px"><h2 style="margin-top:0">Arbeitsbeitrag</h2><p><strong>#' . esc_html((string) self::get_target_post_id()) . '</strong></p></div>';
        echo '<div class="card" style="min-width:210px"><h2 style="margin-top:0">Ohne Beitragsbild</h2><p><strong>' . esc_html((string) $without_featured) . '</strong></p></div>';
        echo '<div class="card" style="min-width:210px"><h2 style="margin-top:0">Lizenzierte Bilder</h2><p><strong>' . esc_html((string) $licensed_images) . '</strong></p></div>';
        echo '</div>';
    }

    private static function count_posts_without_featured(): int {
        $query = new WP_Query([
            'post_type' => 'post',
            'post_status' => ['publish', 'draft'],
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_query' => [[
                'key' => '_thumbnail_id',
                'compare' => 'NOT EXISTS',
            ]],
        ]);
        return (int) $query->found_posts;
    }

    private static function get_magnific_batch_overview(): array {
        $posts = get_posts([
            'post_type' => 'post',
            'post_status' => ['publish','draft','pending','private','future'],
            'posts_per_page' => 50,
            'orderby' => 'modified',
            'order' => 'DESC',
            'meta_query' => [
                'relation' => 'OR',
                ['key' => '_hbbz_magnific_tasks', 'compare' => 'EXISTS'],
                ['key' => '_hbbz_magnific_results', 'compare' => 'EXISTS'],
            ],
        ]);
        $items=[];
        foreach($posts as $post){
            if(!$post instanceof WP_Post) continue;
            $tasks=self::load_magnific_tasks((int)$post->ID);
            $results=get_post_meta((int)$post->ID,'_hbbz_magnific_results',true);
            $images=is_array($results)&&is_array($results['images']??null)?array_values($results['images']):[];
            if ($images) {
                foreach ($images as $image_index => &$image) {
                    if (!is_array($image)) { continue; }
                    $task_id = (string) ($image['task_id'] ?? 'magnific');
                    $asset_key = $task_id . '-' . (int) $image_index;
                    $existing_ids = get_posts([
                        'post_type' => 'attachment',
                        'post_status' => 'inherit',
                        'posts_per_page' => 1,
                        'fields' => 'ids',
                        'meta_key' => '_hbbz_asset_id',
                        'meta_value' => $asset_key,
                    ]);
                    $attachment_id = !empty($existing_ids[0]) ? (int) $existing_ids[0] : 0;
                    if ($attachment_id > 0) {
                        $local_url = wp_get_attachment_image_url($attachment_id, 'medium_large');
                        if (!$local_url) { $local_url = wp_get_attachment_url($attachment_id); }
                        if (is_string($local_url) && $local_url !== '') {
                            $image['display_url'] = $local_url;
                            $image['attachment_id'] = $attachment_id;
                            $image['stored_locally'] = true;
                        }
                    }
                }
                unset($image);
            }
            if(!$tasks&&!$images) continue;
            $items[]=['post_id'=>(int)$post->ID,'title'=>get_the_title($post),'images'=>$images];
        }
        return $items;
    }

    private static function render_automation_preview(): void {
        $posts = get_posts([
            'post_type' => 'post',
            'post_status' => ['publish', 'draft'],
            'posts_per_page' => 50,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => [[
                'key' => '_thumbnail_id',
                'compare' => 'NOT EXISTS',
            ]],
        ]);
        if (!$posts) {
            echo '<p>Keine Beiträge ohne Beitragsbild gefunden.</p>';
            return;
        }
        echo '<p><strong>' . esc_html((string) self::count_posts_without_featured()) . ' Beiträge</strong> ohne Beitragsbild. Die Liste zeigt maximal 50 Einträge.</p>';
        echo '<table class="widefat striped"><thead><tr><th>Auswahl</th><th>ID</th><th>Status</th><th>Beitrag</th><th>Suchvorschlag</th><th>Aktion</th></tr></thead><tbody>';
        foreach ($posts as $post) {
            $url = wp_nonce_url(add_query_arg([
                'action' => 'hbbz_choose_queue_post',
                'post_id' => $post->ID,
            ], admin_url('admin-post.php')), 'hbbz_choose_queue_post_' . $post->ID);
            echo '<tr>';
            echo '<td><input type="checkbox" class="hbbz-queue-check" value="' . esc_attr((string) $post->ID) . '"></td>';
            echo '<td>' . esc_html((string) $post->ID) . '</td>';
            echo '<td>' . esc_html($post->post_status === 'publish' ? 'Veröffentlicht' : 'Entwurf') . '</td>';
            echo '<td>' . esc_html(get_the_title($post)) . '</td>';
            echo '<td>' . esc_html(self::suggest_query_for_post($post)) . '</td>';
            echo '<td><a class="button" href="' . esc_url($url) . '">Als Arbeitsbeitrag öffnen</a></td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    private static function filter_used_assets(array $items, string $provider): array {
        if (!$items) {
            return [];
        }
        $asset_ids = array_values(array_filter(array_map(static fn(array $item): string => (string) ($item['image_id'] ?? ''), $items)));
        if (!$asset_ids) {
            return $items;
        }
        $used = get_posts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key' => '_hbbz_provider',
                    'value' => $provider,
                    'compare' => '=',
                ],
                [
                    'key' => '_hbbz_asset_id',
                    'value' => $asset_ids,
                    'compare' => 'IN',
                ],
            ],
        ]);
        $used_map = [];
        foreach ($used as $attachment_id) {
            $used_map[(string) get_post_meta((int) $attachment_id, '_hbbz_asset_id', true)] = true;
        }
        return array_values(array_filter($items, static fn(array $item): bool => empty($used_map[(string) ($item['image_id'] ?? '')])));
    }
    private static function filter_excluded_assets(array $items): array {
        $raw=(string)get_option(self::OPTION_EXCLUSIONS,'logo, brand, text, watermark, collage, split image, duplicate objects, malformed hands, deformed anatomy, misleading equipment, unsafe depiction, abstract symbol, fantasy creature');
        $terms=array_values(array_filter(array_map(static fn(string $term):string=>trim(self::utf8_lower($term)),preg_split('/[,\n]+/u',$raw)?:[])));
        if(!$terms)return $items;
        return array_values(array_filter($items,static function(array $item)use($terms):bool{$haystack=self::utf8_lower(trim((string)($item['search_text']??'')));if($haystack==='')return true;foreach($terms as $term){if($term!==''&&preg_match('/(^|[^\pL\pN])'.preg_quote($term,'/').'([^\pL\pN]|$)/u',$haystack))return false;}return true;}));
    }

    private static function calculate_crop_geometry(int $source_width, int $source_height, int $ratio_width = 16, int $ratio_height = 9) {
        if ($source_width < 1 || $source_height < 1) {
            return new WP_Error('hbbz_invalid_dimensions', 'Ungültige Ausgangsmaße.');
        }

        if ($ratio_width < 1 || $ratio_height < 1) {
            return new WP_Error('hbbz_invalid_ratio', 'Ungültiges Zielseitenverhältnis.');
        }
        $target_ratio = $ratio_width / $ratio_height;
        $source_ratio = $source_width / $source_height;

        if ($source_ratio > $target_ratio) {
            $crop_height = $source_height;
            $crop_width = max(1, (int) floor($crop_height * $target_ratio));
            $src_x = max(0, (int) floor(($source_width - $crop_width) / 2));
            $src_y = 0;
        } else {
            $crop_width = $source_width;
            $crop_height = max(1, (int) floor($crop_width / $target_ratio));
            $src_x = 0;
            $src_y = max(0, (int) floor(($source_height - $crop_height) / 2));
        }

        $destination_width = min(1600, $crop_width);
        $destination_height = max(1, (int) floor($destination_width * $ratio_height / $ratio_width));

        if ($destination_height > $crop_height) {
            $destination_height = $crop_height;
            $destination_width = max(1, (int) floor($destination_height * $ratio_width / $ratio_height));
        }

        if ($src_x + $crop_width > $source_width || $src_y + $crop_height > $source_height) {
            return new WP_Error('hbbz_crop_outside_source', 'Berechneter Zuschnitt liegt außerhalb des Bildes.');
        }

        return [
            'src_x' => $src_x,
            'src_y' => $src_y,
            'crop_width' => $crop_width,
            'crop_height' => $crop_height,
            'destination_width' => $destination_width,
            'destination_height' => $destination_height,
        ];
    }

    private static function fetch_download_source(string $provider, string $image_id) {
        if ($provider === 'pixabay') {
            $key = (string) get_option(self::OPTION_PIXABAY, '');
            $response = self::remote_json(add_query_arg(['key' => $key, 'id' => $image_id], 'https://pixabay.com/api/'), []);
            if (is_wp_error($response)) {
                return $response;
            }
            $hit = $response['hits'][0] ?? null;
            $url = is_array($hit) ? (string) ($hit['largeImageURL'] ?? $hit['webformatURL'] ?? '') : '';
            if ($url === '' || !self::url_matches_provider($url, 'pixabay', true)) {
                return new WP_Error('hbbz_source_missing', 'Pixabay-Downloadquelle fehlt.');
            }
            return ['url' => $url];
        }

        if ($provider === 'pexels') {
            $key = (string) get_option(self::OPTION_PEXELS, '');
            $response = self::remote_json('https://api.pexels.com/v1/photos/' . rawurlencode($image_id), ['Authorization' => $key]);
            if (is_wp_error($response)) {
                return $response;
            }
            $url = (string) ($response['src']['large2x'] ?? $response['src']['large'] ?? $response['src']['original'] ?? '');
            if ($url === '' || !self::url_matches_provider($url, 'pexels', true)) {
                return new WP_Error('hbbz_source_missing', 'Pexels-Downloadquelle fehlt.');
            }
            return ['url' => $url];
        }

        return new WP_Error('hbbz_provider_invalid', 'Unzulässiger Anbieter.');
    }

    private static function url_matches_provider(string $url, string $provider, bool $is_preview): bool {
        if ($url === '') {
            return false;
        }
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        if ($provider === 'pixabay') {
            $allowed = $is_preview ? ['pixabay.com', 'cdn.pixabay.com'] : ['pixabay.com', 'www.pixabay.com'];
        } else {
            $allowed = $is_preview ? ['images.pexels.com'] : ['pexels.com', 'www.pexels.com'];
        }
        foreach ($allowed as $allowed_host) {
            if ($host === $allowed_host || str_ends_with($host, '.' . $allowed_host)) {
                return true;
            }
        }
        return false;
    }

    private static function assert_ajax_access(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Nicht erlaubt.');
        }
        check_ajax_referer('hbbz_ajax', 'nonce');
    }

    private static function pixabay_request(string $query, int $per_page) {
        $key = (string) get_option(self::OPTION_PIXABAY, '');
        if ($key === '') {
            return new WP_Error('hbbz_pixabay_key_missing', 'Pixabay-Schlüssel fehlt.');
        }

        $url = add_query_arg([
            'key'          => $key,
            'q'            => $query,
            'lang'         => 'en',
            'image_type'   => 'photo',
            'orientation'  => 'horizontal',
            'min_width'    => 1200,
            'min_height'   => 675,
            'safesearch'   => 'true',
            'order'        => 'popular',
            'per_page'     => max(3, min(20, $per_page)),
        ], 'https://pixabay.com/api/');

        return self::remote_json($url, []);
    }

    private static function pexels_request(string $query, int $per_page) {
        $key = (string) get_option(self::OPTION_PEXELS, '');
        if ($key === '') {
            return new WP_Error('hbbz_pexels_key_missing', 'Pexels-Schlüssel fehlt.');
        }

        $url = add_query_arg([
            'query'       => $query,
            'orientation' => 'landscape',
            'size'        => 'large',
            'per_page'    => max(1, min(20, $per_page)),
        ], 'https://api.pexels.com/v1/search');

        return self::remote_json($url, ['Authorization' => $key]);
    }

    private static function remote_json(string $url, array $headers) {
        $response = wp_remote_get($url, [
            'timeout' => 20,
            'headers' => $headers,
        ]);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code < 200 || $code >= 300) {
            return new WP_Error('hbbz_http_error', 'API antwortet mit HTTP ' . $code . '.');
        }

        $body = json_decode((string) wp_remote_retrieve_body($response), true);
        if (!is_array($body)) {
            return new WP_Error('hbbz_invalid_json', 'Ungültige API-Antwort.');
        }

        return $body;
    }

    private static function normalize_pixabay(array $response): array {
        $items = [];
        foreach (($response['hits'] ?? []) as $hit) {
            if (!is_array($hit)) {
                continue;
            }
            $user = isset($hit['user']) ? (string) $hit['user'] : 'Unbekannt';
            $user_id = isset($hit['user_id']) ? (int) $hit['user_id'] : 0;
            $items[] = [
                'image_id'         => (string) ((int) ($hit['id'] ?? 0)),
                'preview_url'      => esc_url_raw((string) ($hit['webformatURL'] ?? '')),
                'page_url'         => esc_url_raw((string) ($hit['pageURL'] ?? '')),
                'width'            => (int) ($hit['imageWidth'] ?? $hit['webformatWidth'] ?? 0),
                'height'           => (int) ($hit['imageHeight'] ?? $hit['webformatHeight'] ?? 0),
                'photographer'     => $user,
                'photographer_url' => esc_url_raw('https://pixabay.com/users/' . rawurlencode($user) . '-' . $user_id . '/'),
                'search_text'      => sanitize_text_field((string) ($hit['tags'] ?? '')),
            ];
        }
        return self::add_quality_data(array_values(array_filter($items, static fn(array $item): bool => $item['preview_url'] !== '' && $item['page_url'] !== '')));
    }

    private static function normalize_pexels(array $response): array {
        $items = [];
        foreach (($response['photos'] ?? []) as $photo) {
            if (!is_array($photo)) {
                continue;
            }
            $items[] = [
                'image_id'         => (string) ((int) ($photo['id'] ?? 0)),
                'preview_url'      => esc_url_raw((string) ($photo['src']['medium'] ?? '')),
                'page_url'         => esc_url_raw((string) ($photo['url'] ?? '')),
                'width'            => (int) ($photo['width'] ?? 0),
                'height'           => (int) ($photo['height'] ?? 0),
                'photographer'     => sanitize_text_field((string) ($photo['photographer'] ?? 'Unbekannt')),
                'photographer_url' => esc_url_raw((string) ($photo['photographer_url'] ?? 'https://www.pexels.com/')),
                'search_text'      => sanitize_text_field((string) ($photo['alt'] ?? '')),
            ];
        }
        return self::add_quality_data(array_values(array_filter($items, static fn(array $item): bool => $item['preview_url'] !== '' && $item['page_url'] !== '')));
    }
}

HBBZ_Plugin::init();
