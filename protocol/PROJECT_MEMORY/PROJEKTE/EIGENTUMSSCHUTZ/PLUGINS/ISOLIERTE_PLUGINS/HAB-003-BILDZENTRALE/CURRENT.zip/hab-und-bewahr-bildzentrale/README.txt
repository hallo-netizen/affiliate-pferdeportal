=== Hab & Bewahr Bildzentrale ===
Version: 1.0.0
Requires at least: 6.5
Requires PHP: 8.1

Eigenständige Bildzentrale für Hab & Bewahr. Deaktiviert und verändert keine anderen Plugins.
Verwaltet Bildsuche, KI-Prompts, manuelle Bildzuordnung, Bildprofile und Sicherung.
Neue Provider-Schlüssel müssen separat eingerichtet werden; keine historischen Portaldaten werden kopiert.

INSTALLATION
- WordPress: Plugins > Installieren > Plugin hochladen > ZIP wählen > Aktivieren.
- Alternativ Cyberduck: ZIP auf dem Mac entpacken und Ordner
  hab-und-bewahr-bildzentrale nach wp-content/plugins/ hochladen;
  dann im WordPress-Backend aktivieren.
- Danach WordPress-Adminmenü 'Bildzentrale' öffnen.

BILDAUSWAHL
- Beitragsbilder: Themenanalyse und Bildsuche, Auswahl, Import, Zuordnung, Rücknahme.
- WordPress-Kategorien: Bildprofile und Term-Zuordnung.
- Seiten-Heros: WordPress Featured Images, eigener Post-Type nur bei Freigabe.
- HivePress: optionales Kategorienbild mit eigener Zielkonfiguration.
- Provider: Pixabay, Pexels und Magnific. KI-Generierung kann externe Kosten verursachen.
- Master-Bildregel und fertig formulierte Vorgabe: BILDPROMPT.md.

SICHERHEIT
- Kein automatischer Austausch des Hab-&-Bewahr-Designplugins.
- Keine Kategorie-Synchronisierung, keine Migration, keine fremden Optionen.
- Bildgenerator-API und Webhook nur nach eigener Einrichtung.
- Vor Massenaktionen immer Vorschau und vorhandene Bilder sichern.
- Exportierte Einstellungen enthalten gegebenenfalls Zugangsdaten und dürfen nicht öffentlich abgelegt werden.

PRÜFGRENZE
Lokale WordPress-Mocks und Code-/ZIP-Prüfung wurden ausgeführt, kein Live-Test in einer
originalen WordPress-Installation mit echten Providern oder dem Designplugin.
