=== Hab & Bewahr – Affiliate-Zentrale ===
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 0.1.19-rc22

Complete independent installable candidate built from the 26-file neutral
affiliate source, preserving every existing source function. Adds local
WordPress category + Hab & Bewahr design adapters; does not copy data,
tokens, images, schedules or settings from other installations.

Activation: OFF by default. The product catalog requires a current
revision-bound category-workflow snapshot and at least three published
specific product pages. No fallback to the bundled historical category
tree. Provider connections must be configured again on the Hab & Bewahr
WordPress site. No live integration or 6.72.306 parity claim.

RC10: Kostenfreier GET-Abruf fuer bereits bezahlte offene DataForSEO-Auftraege direkt beim Adminseitenaufruf (maximal alle 120 Sekunden); separater absolut kostenfreier Abfrageknopf; sichtbarer letzter automatischer Lauf, letzter Ergebnisabruf und ueberfaelliger WordPress-Cron-Termin. Kein automatisches Bezahlen auf einem Seitenaufruf. Bestehende Werbe- und Kategorienlogik unveraendert.
