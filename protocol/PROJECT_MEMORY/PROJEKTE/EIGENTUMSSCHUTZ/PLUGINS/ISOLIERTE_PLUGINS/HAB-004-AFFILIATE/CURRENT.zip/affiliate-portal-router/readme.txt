=== Hab & Bewahr – Affiliate-Zentrale ===
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 0.1.6-rc9

Complete independent installable candidate built from the 26-file neutral
affiliate source, preserving every existing source function. Adds local
WordPress category + Hab & Bewahr design adapters; does not copy data,
tokens, images, schedules or settings from other installations.

Activation: OFF by default. The product catalog requires a current
revision-bound category-workflow snapshot and at least three published
specific product pages. No fallback to the bundled historical category
tree. Provider connections must be configured again on the Hab & Bewahr
WordPress site. No live integration or 6.72.306 parity claim.

RC8: sichtbarster Suchlaufstatus; eindeutige Katalog-/API-Fehler, echte WordPress-Kategorie-Ausspielung über vorhandenen Kategorie-Hook, keine neuen Plugins oder Tabellen.
