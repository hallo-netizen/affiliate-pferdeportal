<?php
/**
 * Hab & Bewahr Amazon bridge for the EXISTING affiliate product pipeline.
 * Uses feed ASINs or narrowly verified DataForSEO matches. Never imports
 * Amazon images, prices, reviews, ratings, availability or sales assertions.
 * No parallel campaigns, no separate frontend/DB engine, no affiliate redirects.
 */
if (!defined('ABSPATH')) { exit; }
trait PPAR_HB_Amazon_Trait {
    const HB_AMAZON_OPTION = 'ppar_hab_amazon_settings_v1';
    const HB_AMAZON_CONTROL = 'ppar_hab_amazon_dfs_control_v1';
    const HB_AMAZON_CRON = 'ppar_hab_amazon_dfs_tick_v1';

    public function hb_amazon_register_hooks() {
        add_action('admin_menu', array($this, 'hb_amazon_admin_menu'), 60);
        add_action('admin_post_ppar_hb_amazon_save', array($this, 'hb_amazon_save'));
        add_action('admin_post_ppar_hb_amazon_run', array($this, 'hb_amazon_run_now'));
        add_action('admin_post_ppar_hb_amazon_poll', array($this, 'hb_amazon_poll_now'));
        add_action('init', array($this, 'hb_amazon_ensure_cron'), 40);
        add_action(self::HB_AMAZON_CRON, array($this, 'hb_amazon_dfs_tick'));
    }

    private function hb_amazon_settings() {
        $stored = get_option(self::HB_AMAZON_OPTION, array());
        if (!is_array($stored)) { $stored = array(); }
        return array_merge(array('enabled'=>false, 'tag'=>'', 'dfs_enabled'=>false,
            'login'=>'', 'password'=>'', 'last_save'=>0), $stored);
    }

    private function hb_amazon_tag($s = null) {
        $s = is_array($s) ? $s : $this->hb_amazon_settings();
        $tag = trim((string)($s['tag'] ?? ''));
        // Only the exact, user-confirmed Hab & Bewahr tag may be used.
        return $tag === 'habundbewahr-21' ? $tag : '';
    }

    private function hb_amazon_ready($s = null) {
        $s = is_array($s) ? $s : $this->hb_amazon_settings();
        return !empty($s['enabled']) && $this->hb_amazon_tag($s) !== '';
    }

    private function hb_amazon_dfs_ready($s = null) {
        $s = is_array($s) ? $s : $this->hb_amazon_settings();
        $login = defined('PPAR_HAB_DATAFORSEO_LOGIN') ? (string)PPAR_HAB_DATAFORSEO_LOGIN : (string)$s['login'];
        $password = defined('PPAR_HAB_DATAFORSEO_PASSWORD') ? (string)PPAR_HAB_DATAFORSEO_PASSWORD : (string)$s['password'];
        return $this->hb_amazon_ready($s) && !empty($s['dfs_enabled']) && trim($login) !== '' && trim($password) !== '';
    }

    private function hb_amazon_direct_url($asin, $settings = null) {
        $asin = strtoupper(trim((string)$asin));
        $settings = is_array($settings) ? $settings : $this->hb_amazon_settings();
        if (!$this->hb_amazon_ready($settings) || !preg_match('/^[A-Z0-9]{10}$/D', $asin)) { return ''; }
        return 'https://www.amazon.de/dp/' . rawurlencode($asin) . '?tag=' . rawurlencode($this->hb_amazon_tag($settings));
    }

    private function hb_amazon_campaign_verified_asin($campaign) {
        if (!is_array($campaign) || empty($campaign['active'])
            || sanitize_key((string)($campaign['creative_type'] ?? '')) !== 'product') { return ''; }
        $network = sanitize_key((string)($campaign['network'] ?? ''));
        $source = sanitize_key((string)($campaign['source'] ?? ''));
        $asins = array_values(array_unique(array_filter(array_map('strtoupper', (array)($campaign['product_asins'] ?? array())),
            static function($a){ return is_string($a) && preg_match('/^[A-Z0-9]{10}$/D', $a); })));
        if (count($asins) !== 1) { return ''; }
        $asin = $asins[0];
        if ($network === 'idealo' && $source === 'idealo_product_feed_v1'
            && sanitize_key((string)($campaign['product_identity_source'] ?? '')) === 'gtin'
            && !empty($campaign['product_gtins'])) { return $asin; }
        // Only a current verified result for exactly this source title is reusable.
        $id = absint($campaign['post_id'] ?? 0);
        if (!$id || !in_array($network, array('ebay','idealo'), true)) { return ''; }
        $m = get_post_meta($id, '_ppar_hb_amazon_exact_match_v1', true);
        $title = (string)($campaign['title'] ?? '');
        if (is_array($m) && $asin === (string)($m['asin'] ?? '')
            && hash_equals((string)($m['title_hash'] ?? ''), hash('sha256', $this->hb_amazon_normalize_title($title)))
            && absint($m['verified_at'] ?? 0) > time() - 30 * DAY_IN_SECONDS) { return $asin; }
        return '';
    }

    /** Add only an additional Amazon CTA to an already valid existing product card. */
    private function hb_amazon_add_offer($offers, $campaign, $context, $slot_type) {
        $offers = array_values((array)$offers);
        if (!$this->hb_amazon_ready() || !is_array($campaign) || !$offers) { return $offers; }
        foreach ($offers as $offer) { if (sanitize_key((string)($offer['network'] ?? '')) === 'amazon') { return $offers; } }
        $asin = $this->hb_amazon_campaign_verified_asin($campaign);
        if ($asin === '') { return $offers; }
        $url = $this->hb_amazon_direct_url($asin);
        if ($url !== '') { $offers[] = array('network'=>'amazon','url'=>$url,'label'=>'Bei Amazon ansehen'); }
        return $offers;
    }

    /** Reuse the existing category and page placements. No second ad system. */
    /** Use only saved verified ASIN/title. The original campaign renderer remains in charge. */
    private function hb_amazon_product_family_markup($slug, $name, $slot_type, $offer_index = null) {
        if (!$this->hb_amazon_ready()) { return ''; }
        $slug = sanitize_key((string)$slug);
        $name = sanitize_text_field((string)$name);
        $slot_type = sanitize_key((string)$slot_type);
        $product_card = preg_match('/^category_product_([123])$/D', $slot_type, $match);
        if ($name === '' || strlen($name)>150
            || (!$product_card && !in_array($slot_type,
                array('product_after_category_tiles','category_recommendation'), true))) { return ''; }
        $url = 'https://www.amazon.de/s?k='.rawurlencode($name).'&tag='.rawurlencode($this->hb_amazon_tag());
        $c = get_option(self::HB_AMAZON_CONTROL,array());
        $saved = (array)($c['category_products'] ?? array());
        $listing = (array)($saved[$slug] ?? array());
        $verified = array();
        if (absint($listing['at'] ?? 0)>time()-14*DAY_IN_SECONDS) {
            foreach ((array)($listing['items'] ?? array()) as $item) {
                $asin = strtoupper((string)($item['asin'] ?? ''));
                $title = sanitize_text_field((string)($item['title'] ?? ''));
                if (!preg_match('/^[A-Z0-9]{10}$/D',$asin) || $title === '') { continue; }
                $direct = $this->hb_amazon_direct_url($asin);
                if ($direct !== '') { $verified[]=array('url'=>$direct,'title'=>$title); }
            }
        }
        if ($product_card) {
            $index = ($offer_index === null) ? ((int)$match[1]-1) : absint($offer_index);
            if (!isset($verified[$index])) { return ''; }
            $item=$verified[$index];
            $banner=array('mode'=>'image_link','creative_type'=>'product','network'=>'amazon',
                'url'=>$item['url'],'title'=>$item['title'],'button_text'=>'Bei Amazon ansehen',
                'image_url'=>'','price'=>'','availability'=>'');
            $context=array('primary_slug'=>$slug,'primary_name'=>$name,'post_type'=>'category_archive',
                'post_id'=>0,'slugs'=>array($slug),'names'=>array($name));
            $creative=$this->render_banner($banner,0,$context,array('id'=>'hab-amazon-verified'),$slot_type);
            if (trim((string)$creative) === '') { return ''; }
            return '<div class="ppar-affiliate-slot ppar-slot-'.$slot_type.' ppar-hab-amazon-verified" data-ppar-slot="'.$slot_type.'">'
                .'<div class="ppar-affiliate-label">Anzeige</div>'
                .'<div class="ppar-affiliate-content">'.$creative.'</div></div>';
        }
        $parts=array();
        foreach ($verified as $item) {
            $parts[]='<a href="'.esc_url($item['url']).'" target="_blank" rel="sponsored nofollow noopener noreferrer">'.esc_html($item['title']).'</a>';
        }
        $body=$parts ? implode(' · ',$parts)
            : '<a href="'.esc_url($url).'" target="_blank" rel="sponsored nofollow noopener noreferrer">Passende Angebote bei Amazon suchen</a>';
        return '<div class="ppar-affiliate-slot ppar-slot-'.$slot_type.' ppar-hab-amazon-search" data-ppar-slot="'.$slot_type.'">'
            .'<div class="ppar-affiliate-label">Anzeige</div>'
            .'<div class="ppar-affiliate-content">'.$body.'</div></div>';
    }

    /** Genuine WordPress category archive with an existing authorized Hab family. */
    private function hb_amazon_category_search_fallback($context, $slot_type) {
        $slot_type=sanitize_key((string)$slot_type);
        if (!$this->hb_amazon_ready() || !is_array($context)
            || (!in_array($slot_type,array('product_after_category_tiles','category_recommendation'),true)
                && !preg_match('/^category_product_[123]$/D',$slot_type))
            || ($context['post_type'] ?? '') !== 'category_archive'
            || sanitize_key((string)($context['product_family_slug'] ?? '')) === '') { return ''; }
        return $this->hb_amazon_product_family_markup($context['primary_slug'] ?? '',
            $context['primary_name'] ?? '',$slot_type);
    }

    /** Existing Hab product page hook works even when article categories are empty. */
    private function hb_amazon_area_product_fallback($page_id) {
        if (!$this->hb_amazon_ready() || !class_exists('PPAR_HB_Integration')
            || !class_exists('PPAR_Portal_Source')) { return ''; }
        $node=PPAR_HB_Integration::page_for_id(absint($page_id));
        if (!is_array($node) || ($node['type'] ?? '') !== 'page') { return ''; }
        $catalog=PPAR_Portal_Source::catalog();
        if (is_wp_error($catalog) || !is_array($catalog)) { return ''; }
        $parts=array();$seen=array();
        foreach ((array)($catalog['product_targets'] ?? array()) as $row) {
            if (!is_array($row) || (string)($row['node_id'] ?? '') !== (string)($node['id'] ?? '')) { continue; }
            $slug=sanitize_key((string)($row['category_slug'] ?? ''));
            if ($slug === '' || isset($seen[$slug])) { continue; }
            $seen[$slug]=true;
            for ($j=0; $j<3 && count($parts)<3; $j++) {
                $slot='category_product_'.(count($parts)+1);
                $html=$this->hb_amazon_product_family_markup($slug,$row['title'] ?? '',$slot,$j);
                if ($html !== '') { $parts[]=$html; }
            }
            if (count($parts)>=3) { break; }
        }
        return implode('',$parts);
    }

    public function hb_amazon_admin_menu() {
        if (function_exists('add_submenu_page')) {
            add_submenu_page('affiliate-portal-zentrale', 'Amazon-Automatik', 'Amazon-Automatik',
                'manage_options', 'affiliate-portal-hab-amazon', array($this, 'hb_amazon_render_settings'));
        }
    }

    public function hb_amazon_render_settings() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $s = $this->hb_amazon_settings();
        $c = get_option(self::HB_AMAZON_CONTROL, array()); if (!is_array($c)) { $c = array(); }
        // Reliable no-cost on-screen fallback: check ONLY an already paid open task.
        // A blocked WP-Cron must not leave the admin page forever on 'planned'.
        // Never create a new paid task on a normal page view.
        if ($this->hb_amazon_dfs_ready($s) && !empty($c['pending_id'])
            && time() - absint($c['last_poll_at'] ?? 0) >= 120) {
            $this->hb_amazon_dfs_tick('admin_safe_check', true);
            $c = get_option(self::HB_AMAZON_CONTROL, array());
            if (!is_array($c)) { $c = array(); }
        }
        $status = $this->hb_amazon_ready($s) ? 'Amazon-Links eingeschaltet' : 'Noch nicht eingeschaltet';
        if ($this->hb_amazon_dfs_ready($s)) { $status .= ' · DataForSEO-Automatik eingeschaltet'; }
        $day = gmdate('Y-m-d');
        $count = ($c['day'] ?? '') === $day ? min(5, absint($c['count'] ?? 0)) : 0;
        $catalog = class_exists('PPAR_Portal_Source') ? PPAR_Portal_Source::catalog() : new WP_Error('hb_catalog_missing','Hab-Zielquelle ist nicht geladen.');
        $catalog_ok = is_array($catalog) && !empty($catalog['product_targets']);
        $catalog_count = $catalog_ok ? count((array)$catalog['product_targets']) : 0;
        $catalog_error = is_wp_error($catalog) ? $catalog->get_error_message() : ($catalog_ok ? '' : 'Keine freigegebenen Produktkategorien verfügbar.');
        $last = (string)($c['message'] ?? 'Noch kein Suchlauf');
        $stage = (string)($c['status'] ?? 'idle');
        if ($catalog_error !== '') { $stage='error'; }
        $notice_class = $stage==='error' ? 'notice-error' : ($stage==='success' ? 'notice-success' : 'notice-info');
        $notice_text = $catalog_error !== '' ? 'BLOCKIERT: '.$catalog_error : $last;
        $run_label = !empty($c['last_tick_at']) ? wp_date('d.m.Y H:i:s',absint($c['last_tick_at'])) : 'noch kein Lauf';
        echo '<div class="wrap"><h1>Hab &amp; Bewahr – Amazon-Automatik</h1>';
        echo '<div class="notice '.esc_attr($notice_class).' inline" style="padding:12px;margin:14px 0">';
        echo '<p><strong>Suchlauf-Status:</strong> '.esc_html($notice_text).'</p>';
        echo '<p><strong>Letzter Lauf:</strong> '.esc_html($run_label).' · <strong>Freigegebene Hab-Produktkategorien:</strong> '.esc_html((string)$catalog_count).' · <strong>Bezahlte Aufträge heute:</strong> '.esc_html((string)$count).' von 5 · <strong>Offener Auftrag:</strong> '.(!empty($c['pending_id'])?'ja':'nein').'</p>';
        if ($catalog_error !== '') {
            $active_revision=(string)get_option('apkw_target_tree_active_revision_v1','');
            $snapshot=get_option('apkw_target_tree_active_snapshot_v1',array());
            $snapshot=is_array($snapshot)?$snapshot:array();
            $source_problem=$active_revision==='' ? 'Keine aktive Kategorie-Version gespeichert'
                : (empty($snapshot['nodes']) || empty($snapshot['mapping']) ? 'Aktiver Kategorie-Snapshot fehlt oder ist leer'
                : ((string)($snapshot['revision']??'')!==$active_revision ? 'Aktive Kategorie-Version und gespeicherter Snapshot stimmen nicht überein'
                : 'Aktive Struktur vorhanden, aber die vorhandenen Produkt-Zuordnungsregeln liefern keinen freigegebenen Zielkatalog'));
            echo '<p><strong>Kategorie-Workflow:</strong> '.esc_html($source_problem).' · '.esc_html((string)count((array)($snapshot['nodes']??array()))).' Knoten, '.esc_html((string)count((array)($snapshot['mapping']??array()))).' Zuordnungen.</p>';
            echo '<p><strong>Folge:</strong> Kein kostenpflichtiger DataForSEO-Auftrag und keine erfundenen Angebote.</p>';
        }
        elseif (!empty($c['pending_id'])) { echo '<p><strong>Weiter:</strong> Ergebnis wird beim nächsten automatischen Lauf abgefragt. Kein weiterer Klick notwendig.</p>'; }
        else { echo '<p><strong>Weiter:</strong> Die Automatik prüft neue geeignete Produktkategorien und Beiträge beim nächsten Lauf.</p>'; }
        if (get_option('ppar_enabled','0')!=='1') { echo '<p><strong>Ausgabe blockiert:</strong> Die vorhandene Affiliate-Zentrale ist insgesamt ausgeschaltet.</p>'; }
        echo '</div>';
        echo '<p>Vorhandene Produkt- und Kategorienzuordnung wird weiterverwendet. Keine manuelle Einzel-Linkanlage.</p>';
        echo '<p><strong>Status:</strong> '.esc_html($status).'</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field('ppar_hb_amazon_save','ppar_hb_amazon_nonce');
        echo '<input type="hidden" name="action" value="ppar_hb_amazon_save">';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th>Amazon-Tracking-ID</th><td><input type="text" class="regular-text" name="amazon_tag" value="'.esc_attr($s['tag']).'" placeholder="habundbewahr-21"><p class="description">Nur die eigene Hab-&amp;-Bewahr-Tracking-ID wird akzeptiert.</p></td></tr>';
        echo '<tr><th>Amazon-Produktbuttons</th><td><label><input type="checkbox" name="amazon_enabled" value="1" '.checked(!empty($s['enabled']),true,false).'> Automatisch bei eindeutig geprüfter ASIN anzeigen</label></td></tr>';
        $external = defined('PPAR_HAB_DATAFORSEO_LOGIN') && defined('PPAR_HAB_DATAFORSEO_PASSWORD');
        echo '<tr><th>DataForSEO</th><td><label><input type="checkbox" name="dfs_enabled" value="1" '.checked(!empty($s['dfs_enabled']),true,false).'> Automatische ASIN-Recherche aktivieren (kostenpflichtig, max. 5 neue Suchaufträge pro UTC-Tag)</label></td></tr>';
        echo '<tr><th>DataForSEO API-Login</th><td><input type="text" name="dfs_login" autocomplete="off" value="'.esc_attr($external ? '' : $s['login']).'" placeholder="'.($external?'über wp-config.php':'API-Login').'"></td></tr>';
        echo '<tr><th>DataForSEO API-Passwort</th><td><input type="password" name="dfs_password" autocomplete="new-password" value="" placeholder="'.($external?'über wp-config.php':($s['password']!==''?'bereits gespeichert':'API-Passwort')).'"><p class="description">Leer lassen = gespeichertes Passwort beibehalten.</p></td></tr>';
        echo '</table><p><button type="submit" class="button button-primary">Speichern</button></p></form>';
        echo '<h2>Automatischer Ablauf</h2><p>Automatische ASIN-Recherche für bestehende Produktkarten, passende veröffentlichte Beiträge und konkret zugeordnete Produktkategorien aus dem aktiven Hab-&amp;-Bewahr-Katalog. Neue Beiträge werden ohne eigenen kostenpflichtigen Speichervorgang beim nächsten Suchlauf berücksichtigt. Keine Amazon-Bilder, Preise oder Bewertungen aus DataForSEO.</p>';
        if ($this->hb_amazon_dfs_ready($s)) {
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
            if (!empty($c['pending_id'])) {
                wp_nonce_field('ppar_hb_amazon_poll','ppar_hb_amazon_poll_nonce');
                echo '<input type="hidden" name="action" value="ppar_hb_amazon_poll">';
                echo '<p><button type="submit" class="button button-secondary">Offenen Auftrag jetzt prüfen (keine neue Suche)</button></p>';
                echo '<p class="description">Fragt nur den bereits angelegten DataForSEO-Auftrag kostenlos ab. Startet unter keinen Umstaenden einen neuen kostenpflichtigen Suchauftrag.</p></form>';
            } else {
                wp_nonce_field('ppar_hb_amazon_run','ppar_hb_amazon_run_nonce');
                echo '<input type="hidden" name="action" value="ppar_hb_amazon_run">';
                echo '<p><button type="submit" class="button button-secondary">Neue Suche starten (kostenpflichtig)</button></p>';
                echo '<p class="description">Nur dieser Knopf kann einen weiteren DataForSEO-Suchauftrag ausloesen, maximal 5 am UTC-Tag.</p></form>';
            }
        }
        echo '<p><strong>Letzter tatsächlicher Lauf:</strong> '.(!empty($c['last_tick_at']) ? esc_html(wp_date('d.m.Y H:i',absint($c['last_tick_at']))) : 'noch keiner').'</p>';
        echo '<p><strong>Bezahlte Suchaufträge heute:</strong> '.esc_html((string)$count).' von 5</p>';
        echo '<p><strong>Offener Auftrag:</strong> '.(!empty($c['pending_id'])?'ja':'nein').'</p>';
        echo '<p><strong>Letzte Meldung:</strong> '.esc_html((string)($c['message'] ?? 'Noch keine Recherche')).'</p>';
        echo '<p><strong>Letzte eindeutige ASIN:</strong> '.(!empty($c['last_match_at'])?esc_html(wp_date('d.m.Y H:i',absint($c['last_match_at']))):'noch keine').'</p>';
        echo '<p><strong>Automatisch geprüfte Hab-Produktkategorien:</strong> '.esc_html((string)count((array)($c['category_checked'] ?? array()))).'</p>';
        echo '<p><strong>Automatisch geprüfte Beiträge:</strong> '.esc_html((string)count((array)($c['article_checked'] ?? array()))).'</p>';
        $found=0; foreach ((array)($c['category_products'] ?? array()) as $row) { $found+=count((array)($row['items'] ?? array())); }
        echo '<p><strong>Gespeicherte Amazon-Einzelproduktlinks:</strong> '.esc_html((string)$found).'</p>';
        $next = $this->hb_amazon_dfs_ready($s) ? absint(wp_next_scheduled(self::HB_AMAZON_CRON)) : 0;
        echo '<p><strong>Letzter automatischer Lauf:</strong> '.(!empty($c['last_cron_at']) ? esc_html(wp_date('d.m.Y H:i:s',absint($c['last_cron_at']))) : 'noch keiner nachweisbar').'</p>';
        echo '<p><strong>Letzter DataForSEO-Ergebnisabruf:</strong> '.(!empty($c['last_poll_at']) ? esc_html(wp_date('d.m.Y H:i:s',absint($c['last_poll_at']))) : 'noch keiner').' · <strong>Antwort:</strong> '.esc_html((string)($c['last_poll_status']??'noch keine')).'</p>';
        echo '<p><strong>Geplanter automatischer Lauf:</strong> '.($next ? esc_html(wp_date('d.m.Y H:i:s',$next)) : 'nicht geplant').($next && $next+120<time()?' · ÜBERFÄLLIG – WordPress hat den geplanten Lauf nicht ausgeführt':'').'</p>';
        echo '<p class="description">Ein Zeitplan ist kein Nachweis eines tatsächlichen Laufs. Bei offenem Auftrag wird die kostenlose Ergebnisabfrage auch beim Aufruf dieser Seite geprüft (höchstens alle 2 Minuten). Dazu muss keine neue Suche gestartet werden.</p>';
        echo '<p class="description">Idealo ist ein getrenntes Netzwerk. Es muss mit eigenen Hab-&amp;-Bewahr-Zugangsdaten aktiviert werden.</p></div>';
    }

    public function hb_amazon_save() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_hb_amazon_save', 'ppar_hb_amazon_nonce');
        $s = $this->hb_amazon_settings();
        $tag = sanitize_text_field(wp_unslash((string)($_POST['amazon_tag'] ?? '')));
        $s['tag'] = ($tag === 'habundbewahr-21') ? $tag : '';
        $s['enabled'] = !empty($_POST['amazon_enabled']) && $s['tag'] !== '';
        $s['dfs_enabled'] = !empty($_POST['dfs_enabled']);
        if (!defined('PPAR_HAB_DATAFORSEO_LOGIN')) {
            $login = trim(sanitize_text_field(wp_unslash((string)($_POST['dfs_login'] ?? ''))));
            if ($login !== '') { $s['login'] = $login; }
        }
        if (!defined('PPAR_HAB_DATAFORSEO_PASSWORD')) {
            $password = wp_unslash((string)($_POST['dfs_password'] ?? ''));
            if ($password !== '') { $s['password'] = $password; }
        }
        $s['last_save'] = time();
        update_option(self::HB_AMAZON_OPTION, $s, false);
        $this->hb_amazon_ensure_cron();
        wp_safe_redirect(admin_url('admin.php?page=affiliate-portal-hab-amazon'));
        exit;
    }

    /** Safe explicit first run; same worker, same lock and daily cost ceiling. */
    public function hb_amazon_run_now() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_hb_amazon_run', 'ppar_hb_amazon_run_nonce');
        if ($this->hb_amazon_dfs_ready()) { $this->hb_amazon_dfs_tick('manual_search'); }
        wp_safe_redirect(admin_url('admin.php?page=affiliate-portal-hab-amazon&hb_amazon_ran=1'));
        exit;
    }

    /** Free, poll-only action. Even if cron finished just now, this CANNOT post a new paid task. */
    public function hb_amazon_poll_now() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_hb_amazon_poll', 'ppar_hb_amazon_poll_nonce');
        if ($this->hb_amazon_dfs_ready()) { $this->hb_amazon_dfs_tick('manual_poll', true); }
        wp_safe_redirect(admin_url('admin.php?page=affiliate-portal-hab-amazon&hb_amazon_checked=1'));
        exit;
    }

    public function hb_amazon_ensure_cron() {
        if (!function_exists('wp_next_scheduled') || !function_exists('wp_schedule_event')) { return; }
        $next = wp_next_scheduled(self::HB_AMAZON_CRON);
        if (!$this->hb_amazon_dfs_ready()) {
            if ($next && function_exists('wp_clear_scheduled_hook')) { wp_clear_scheduled_hook(self::HB_AMAZON_CRON); }
            return;
        }
        if (!$next) { wp_schedule_event(time()+300,'hourly',self::HB_AMAZON_CRON); }
    }

    private function hb_amazon_dfs_api($method, $url, $payload = null, $s = null) {
        $s = is_array($s) ? $s : $this->hb_amazon_settings();
        if (!$this->hb_amazon_dfs_ready($s)) { return new WP_Error('hb_amazon_not_ready', 'Amazon/DataForSEO noch nicht vollständig freigegeben.'); }
        $login = defined('PPAR_HAB_DATAFORSEO_LOGIN') ? (string)PPAR_HAB_DATAFORSEO_LOGIN : (string)$s['login'];
        $pass = defined('PPAR_HAB_DATAFORSEO_PASSWORD') ? (string)PPAR_HAB_DATAFORSEO_PASSWORD : (string)$s['password'];
        // Fixed HTTPS allowlist: no user-provided URL or redirect, no credentials leak.
        if (!preg_match('#^https://api\.dataforseo\.com/v3/merchant/amazon/products/(?:task_post|task_get/advanced/[0-9a-f-]{36})$#D', $url)) {
            return new WP_Error('hb_amazon_endpoint', 'Unerwarteter DataForSEO-Endpunkt.');
        }
        $args = array('method'=>$method,'timeout'=>25,'redirection'=>0,
            'headers'=>array('Authorization'=>'Basic '.base64_encode($login.':'.$pass),'Content-Type'=>'application/json'));
        if ($payload !== null) { $args['body'] = wp_json_encode($payload); }
        $response = wp_remote_request($url, $args);
        if (is_wp_error($response)) { return $response; }
        if ((int)wp_remote_retrieve_response_code($response) !== 200) {
            return new WP_Error('hb_amazon_http', 'DataForSEO HTTP '.(int)wp_remote_retrieve_response_code($response));
        }
        $data = json_decode((string)wp_remote_retrieve_body($response), true);
        if (!is_array($data) || (int)($data['status_code'] ?? 0) !== 20000 || empty($data['tasks']) || !is_array($data['tasks'])) {
            return new WP_Error('hb_amazon_api', 'Ungültige oder fehlerhafte DataForSEO-Antwort.');
        }
        return $data;
    }

    private function hb_amazon_normalize_title($title) {
        $title = strtolower(str_replace(array('Ä','Ö','Ü'), array('ä','ö','ü'), trim((string)$title)));
        $title = str_replace(array('ä','ö','ü','ß'),array('ae','oe','ue','ss'),$title);
        $title = preg_replace('/[^a-z0-9]+/',' ',$title);
        $terms = array_values(array_filter(explode(' ',trim($title)),static function($s){ return strlen($s) > 1; }));
        sort($terms, SORT_STRING);
        return implode(' ', $terms);
    }

    /** Conservative identity: identical complete title token multiset, not fuzzy resemblance. */
    private function hb_amazon_exact_match_asin($title, $items) {
        $needle = $this->hb_amazon_normalize_title($title);
        if ($needle === '' || count(explode(' ', $needle)) < 2) { return ''; }
        $matched = array();
        foreach ((array)$items as $item) {
            if (!is_array($item)) { continue; }
            $type = (string)($item['type'] ?? '');
            if (!in_array($type,array('amazon_serp','amazon_serp_element'),true)) { continue; }
            $url = (string)($item['url'] ?? '');
            $host = strtolower((string)wp_parse_url($url, PHP_URL_HOST));
            if (!in_array($host,array('amazon.de','www.amazon.de'),true)) { continue; }
            if ($this->hb_amazon_normalize_title((string)($item['title'] ?? '')) !== $needle) { continue; }
            // DataForSEO Merchant Amazon Products uses data_asin (not asin).
            $asin = strtoupper(trim((string)($item['data_asin'] ?? $item['asin'] ?? '')));
            if (!preg_match('/^[A-Z0-9]{10}$/D',$asin)) {
                $asin = preg_match('#/(?:dp|gp/product)/([A-Z0-9]{10})(?:[/?]|$)#i',$url,$m) ? strtoupper($m[1]) : '';
            }
            if ($asin !== '' && preg_match('/^[A-Z0-9]{10}$/D',$asin)) { $matched[$asin] = true; }
        }
        return count($matched) === 1 ? (string)array_keys($matched)[0] : '';
    }

    private function hb_amazon_dfs_candidate(&$control) {
        $offset = max(0,absint($control['scan_offset'] ?? 0));
        $posts = get_posts(array('post_type'=>self::CAMPAIGN_POST_TYPE,'post_status'=>'publish',
            'posts_per_page'=>100, 'offset'=>$offset, 'orderby'=>'ID','order'=>'ASC','suppress_filters'=>true));
        if (!$posts && $offset>0) {
            $offset=0;
            $posts=get_posts(array('post_type'=>self::CAMPAIGN_POST_TYPE,'post_status'=>'publish',
                'posts_per_page'=>100,'offset'=>0,'orderby'=>'ID','order'=>'ASC','suppress_filters'=>true));
        }
        // Resume scanning after this bounded page if no match is found.
        $control['scan_offset']=$offset+(count((array)$posts)<100?0:100);
        if (count((array)$posts)<100) { $control['scan_offset']=0; }
        $checked = (array)($control['checked'] ?? array());
        foreach ((array)$posts as $post) {
            $campaign = $this->campaign_from_post($post);
            if (!is_array($campaign) || empty($campaign['active']) ||
                sanitize_key((string)($campaign['creative_type'] ?? ''))!=='product') { continue; }
            $net = sanitize_key((string)($campaign['network'] ?? ''));
            $source = sanitize_key((string)($campaign['source'] ?? ''));
            if (!(($net==='idealo' && $source==='idealo_product_feed_v1' && !empty($campaign['product_gtins'])) ||
                  ($net==='ebay' && $source==='output_object_v4' && !empty($campaign['product_gtins'])))) { continue; }
            if ($this->hb_amazon_campaign_verified_asin($campaign) !== '') { continue; }
            $title = trim((string)($campaign['title'] ?? ''));
            if (strlen($title) < 8 || !preg_match('/[a-zA-Z]{3}/',$title)) { continue; }
            $id = absint($post->ID);
            $fingerprint = hash('sha256',$this->hb_amazon_normalize_title($title));
            if (isset($checked[$id]) && ($checked[$id]['hash'] ?? '') === $fingerprint &&
                absint($checked[$id]['at'] ?? 0) > time()-7*DAY_IN_SECONDS) { continue; }
            return array('id'=>$id,'title'=>$title,'hash'=>$fingerprint);
        }
        return null;
    }

    /** The existing portal-source catalog is the only authority for product families. */
    private function hb_amazon_category_candidate(&$control) {
        if (!class_exists('PPAR_Portal_Source') || !method_exists('PPAR_Portal_Source','catalog')) { return null; }
        $catalog=PPAR_Portal_Source::catalog();
        if (is_wp_error($catalog) || !is_array($catalog)) { return null; }
        $checked=(array)($control['category_checked'] ?? array());
        $saved=(array)($control['category_products'] ?? array());
        foreach ((array)($catalog['product_targets'] ?? array()) as $row) {
            if (!is_array($row)) { continue; }
            $slug=sanitize_key((string)($row['category_slug'] ?? ''));
            $family=sanitize_text_field((string)($row['title'] ?? ''));
            if ($slug==='' || $family==='' || strlen($family)>90) { continue; }
            if (!empty($saved[$slug]['items']) && absint($saved[$slug]['at'] ?? 0)>time()-14*DAY_IN_SECONDS) { continue; }
            if (absint($checked[$slug]['at'] ?? 0)>time()-7*DAY_IN_SECONDS) { continue; }
            return array('id'=>0,'title'=>$family,'hash'=>hash('sha256',$this->hb_amazon_normalize_title($family)),
                'category_slug'=>$slug,'source'=>'hab_category');
        }
        return null;
    }


    /** Published posts re-use the same Hab category catalog and DataForSEO worker.
     * The article itself supplies extra query specificity, never a new product catalog.
     * Return null for general advice, wrong categories or non-commercial content.
     */
    private function hb_amazon_article_topic($post) {
        if (!is_object($post) || empty($post->ID)) { return null; }
        $id=absint($post->ID);
        if (!function_exists('get_post_status') || !function_exists('get_post_type') ||
            get_post_status($id)!=='publish' || get_post_type($id)!=='post') { return null; }
        if ((string)get_post_meta($id,'_hbdp_article_no_ads',true)==='1' ||
            (function_exists('hbdp_article_is_urgent') && hbdp_article_is_urgent($post))) { return null; }
        if (!class_exists('PPAR_Portal_Source') || !method_exists('PPAR_Portal_Source','catalog')) { return null; }
        $catalog=PPAR_Portal_Source::catalog();
        if (is_wp_error($catalog) || !is_array($catalog)) { return null; }
        $products=array();
        foreach ((array)($catalog['product_targets'] ?? array()) as $row) {
            $slug=sanitize_key((string)($row['category_slug'] ?? ''));
            $family=sanitize_text_field((string)($row['title'] ?? ''));
            if ($slug!=='' && $family!=='' && strlen($family)<=90) { $products[$slug]=$family; }
        }
        // Only a direct WordPress category that exists as a product target in
        // the SAME revision-bound Hab portal catalog can authorize this search.
        $terms=get_the_terms($id,'category');
        if (is_wp_error($terms) || !is_array($terms)) { return null; }
        $title=sanitize_text_field((string)($post->post_title ?? ''));
        $title=trim(preg_replace('/\s+/u',' ',$title));
        if (strlen($title)<8 || strlen($title)>180) { return null; }
        $title_terms=explode(' ',$this->hb_amazon_normalize_title($title));
        foreach ($terms as $term) {
            $slug=sanitize_key((string)($term->slug ?? ''));
            $family=(string)($products[$slug] ?? '');
            if ($family==='') { continue; }
            $matched=true;
            foreach (explode(' ',$this->hb_amazon_normalize_title($family)) as $needle) {
                if ($needle==='') { continue; }
                $found=false;
                foreach ($title_terms as $word) {
                    if (in_array($word,array($needle,$needle.'n',$needle.'en',$needle.'s'),true)) { $found=true; break; }
                }
                if (!$found) { $matched=false; break; }
            }
            if (!$matched) { continue; }
            // Do not submit entire prose passages as shopping searches.
            $query=strlen($title)<=110 ? $title : $family;
            $hash=hash('sha256',$this->hb_amazon_normalize_title($query).'|'.$slug);
            return array('id'=>$id,'title'=>$query,'family'=>$family,
                'category_slug'=>$slug,'source'=>'hab_article','hash'=>$hash);
        }
        return null;
    }

    /** Bounded scan; new published posts or changed titles/categories are
     * discovered at later scheduled runs. Saving a post itself causes NO API call.
     */
    private function hb_amazon_article_candidate(&$control) {
        $offset=max(0,absint($control['article_scan_offset'] ?? 0));
        $posts=get_posts(array('post_type'=>'post','post_status'=>'publish',
            'posts_per_page'=>100,'offset'=>$offset,'orderby'=>'ID','order'=>'ASC','suppress_filters'=>true));
        if (!$posts && $offset>0) {
            $offset=0;
            $posts=get_posts(array('post_type'=>'post','post_status'=>'publish',
                'posts_per_page'=>100,'offset'=>0,'orderby'=>'ID','order'=>'ASC','suppress_filters'=>true));
        }
        $control['article_scan_offset']=count((array)$posts)<100?0:$offset+100;
        $checked=(array)($control['article_checked'] ?? array());
        $saved=(array)($control['article_products'] ?? array());
        foreach ((array)$posts as $post) {
            $candidate=$this->hb_amazon_article_topic($post);
            if (!$candidate) { continue; }
            $id=$candidate['id'];$hash=$candidate['hash'];
            if (($saved[$id]['hash'] ?? '')===$hash &&
                !empty($saved[$id]['items']) && absint($saved[$id]['at'] ?? 0)>time()-14*DAY_IN_SECONDS) { continue; }
            if (($checked[$id]['hash'] ?? '')===$hash &&
                absint($checked[$id]['at'] ?? 0)>time()-7*DAY_IN_SECONDS) { continue; }
            return $candidate;
        }
        return null;
    }

    /** Article results never promise a feature (e.g. without WLAN) unless the
     * product title actually states it; generic titles still require the family.
     */
    private function hb_amazon_article_results($topic,$items) {
        $found=$this->hb_amazon_category_results((string)$topic['family'],$items);
        $article_title=$this->hb_amazon_normalize_title((string)$topic['title']);
        // The normalized title is sorted, so check individual terms rather than a phrase.
        $words=explode(' ',$article_title);
        $family_words=explode(' ',$this->hb_amazon_normalize_title((string)$topic['family']));
        $stop=array('welche','welcher','welches','wie','was','wer','wann','warum','sind','ist',
            'eine','einen','einem','einer','oder','aber','welchen','gibt','es','den','das','die',
            'der','mit','ohne','fuer','bei','von','auf','im','am','in','und','als','zum','zur',
            'richtig','gut','beste','besten','kaufen','vergleich','test','ratgeber','tipps',
            'im','haus','wohnung','garten','keller','sichern','schuetzen','installieren');
        $modifiers=array_values(array_filter($words,static function($w) use ($family_words,$stop) {
            return strlen($w)>=3 && !in_array($w,$family_words,true) && !in_array($w,$stop,true);
        }));
        $has_without=in_array('ohne',$words,true);
        $negative_terms=array_values(array_intersect($modifiers,array('wlan','bohren','kabel','akku','strom','internet','abo')));
        if ($has_without && !$negative_terms) { return array(); }
        return array_values(array_filter($found,function($item) use ($modifiers,$has_without,$negative_terms) {
            $title=' '.$this->hb_amazon_normalize_title((string)($item['title'] ?? '')).' ';
            if ($has_without) {
                if (strpos($title,' ohne ')===false) { return false; }
                foreach ($negative_terms as $term) { if (strpos($title,' '.$term.' ')===false) { return false; } }
            }
            if (!$modifiers) { return true; }
            $one=false;
            foreach ($modifiers as $term) {
                $present=strpos($title,' '.$term.' ')!==false;
                // Numbers and pack sizes must always agree, not just one other word.
                if (preg_match('/^[0-9]/',$term) && !$present) { return false; }
                if ($present) { $one=true; }
            }
            return $one;
        }));
    }

    /** Only render where the EXISTING Hab article product slot has no valid
     * provider campaign; do not override the original article plan or adverts.
     */
    private function hb_amazon_article_fallback($post_id) {
        if (!$this->hb_amazon_ready() || !function_exists('get_post')) { return ''; }
        $topic=$this->hb_amazon_article_topic(get_post(absint($post_id)));
        if (!$topic) { return ''; }
        $c=get_option(self::HB_AMAZON_CONTROL,array());
        $article_products=(array)($c['article_products'] ?? array());
        $saved=(array)($article_products[$topic['id']] ?? array());
        $items=(($saved['hash'] ?? '')===$topic['hash'] &&
            absint($saved['at'] ?? 0)>time()-14*DAY_IN_SECONDS)
            ? (array)($saved['items'] ?? array()) : array();
        $parts=array();
        foreach ($items as $item) {
            $asin=strtoupper(trim((string)($item['asin'] ?? '')));
            $url=$this->hb_amazon_direct_url($asin);
            $title=sanitize_text_field((string)($item['title'] ?? ''));
            if ($url!=='' && $title!=='') {
                $parts[]='<a href="'.esc_url($url).'" target="_blank" rel="sponsored nofollow noopener noreferrer">'.esc_html($title).'</a>';
            }
        }
        // No invented product if no API result is available yet.
        if (!$parts) {
            $url='https://www.amazon.de/s?k='.rawurlencode($topic['title']).'&tag='.rawurlencode($this->hb_amazon_tag());
            $parts[]='<a href="'.esc_url($url).'" target="_blank" rel="sponsored nofollow noopener noreferrer">Passende Angebote bei Amazon suchen</a>';
        }
        return '<div class="ppar-affiliate-slot ppar-hab-amazon-article" data-ppar-slot="post_bottom_products">'
            . '<div class="ppar-affiliate-label">Anzeige</div>'
            . '<div class="ppar-affiliate-content">'.implode(' · ',$parts).'</div></div>';
    }

    /** Select only genuine amazon.de organic listings that explicitly name the product family. */
    private function hb_amazon_category_results($family,$items) {
        $family_terms=array_values(array_filter(explode(' ',$this->hb_amazon_normalize_title($family))));
        if (!$family_terms) { return array(); }
        $result=array();
        foreach ((array)$items as $item) {
            if (!is_array($item) || (string)($item['type'] ?? '')!=='amazon_serp') { continue; }
            $title=sanitize_text_field((string)($item['title'] ?? ''));
            $url=(string)($item['url'] ?? '');
            if ($title==='' || strlen($title)>350) { continue; }
            $host=strtolower((string)wp_parse_url($url, PHP_URL_HOST));
            if (!in_array($host,array('amazon.de','www.amazon.de'),true)) { continue; }
            $words=' '.$this->hb_amazon_normalize_title($title).' ';
            $eligible=true;
            foreach ($family_terms as $term) { if (strpos($words,' '.$term.' ')===false) { $eligible=false; break; } }
            if (!$eligible) { continue; }
            $asin=strtoupper(trim((string)($item['data_asin'] ?? '')));
            if (!preg_match('/^[A-Z0-9]{10}$/D',$asin)) { continue; }
            if (isset($result[$asin])) { continue; }
            // Do not store provider images, prices, ratings or stock claims.
            $result[$asin]=array('asin'=>$asin,'title'=>function_exists('mb_substr') ? mb_substr($title,0,180) : substr($title,0,180));
            if (count($result)>=3) { break; }
        }
        return array_values($result);
    }

    public function hb_amazon_dfs_tick($source = 'cron', $poll_only = false) {
        $s = $this->hb_amazon_settings();
        if (!$this->hb_amazon_dfs_ready($s)) { return; }
        $lock = 'ppar_hb_amazon_dfs_worker_lock';
        if (get_transient($lock)) {
            $c=get_option(self::HB_AMAZON_CONTROL,array());$c=is_array($c)?$c:array();
            $c['status']='busy';
            $c['message']='Ein Suchlauf ist bereits aktiv; kein zweiter Auftrag gestartet';
            update_option(self::HB_AMAZON_CONTROL,$c,false);
            return;
        }
        set_transient($lock,1,180);
        try { $this->hb_amazon_dfs_do_tick($s, $source, $poll_only); }
        finally { delete_transient($lock); }
    }

    private function hb_amazon_dfs_do_tick($s, $source = 'cron', $poll_only = false) {
        $control = get_option(self::HB_AMAZON_CONTROL, array());
        if (!is_array($control)) { $control = array(); }
        $day = gmdate('Y-m-d');
        if (($control['day'] ?? '') !== $day) { $control['day'] = $day; $control['count'] = 0; }
        $control['last_tick_at']=time();
        $control['last_run_source']=sanitize_key($source);
        if ($source === 'cron') { $control['last_cron_at']=time(); }
        $control['status']='running';
        $control['message']='Suchlauf gestartet: vorhandene Produkte, Beiträge und Kategorien werden geprüft';
        update_option(self::HB_AMAZON_CONTROL,$control,false);
        $pending = (string)($control['pending_id'] ?? '');
        if ($pending !== '') {
            // Never pay again while a GET result for a prior paid task is pending.
            if (!preg_match('/^[0-9a-f-]{36}$/D',$pending)) {
                unset($control['pending_id']); $control['status']='error'; $control['message']='Ungültige offene DataForSEO-Auftrag-ID';
                update_option(self::HB_AMAZON_CONTROL,$control,false); return; // never silently start another paid task
            }
            elseif (absint($control['pending_at'] ?? 0) < time()-48*HOUR_IN_SECONDS) {
                unset($control['pending_id']); $control['status']='error'; $control['message']='Alter DataForSEO-Auftrag ohne Ergebnis abgelaufen';
                update_option(self::HB_AMAZON_CONTROL,$control,false); return; // no new paid task on error
            } else {
                $control['last_poll_at']=time();
                $control['last_poll_status']='angefragt';
                update_option(self::HB_AMAZON_CONTROL,$control,false);
                $response = $this->hb_amazon_dfs_api('GET', 'https://api.dataforseo.com/v3/merchant/amazon/products/task_get/advanced/'.$pending, null, $s);
                if (is_wp_error($response)) { $control['last_poll_status']='Fehler'; $control['status']='error'; $control['message']='Ergebnisabruf fehlgeschlagen: '.$response->get_error_message(); update_option(self::HB_AMAZON_CONTROL,$control,false); return; }
                $task = (array)($response['tasks'][0] ?? array());
                $task_status = (int)($task['status_code'] ?? 0);
                if ($task_status>=40000 || ($task_status!==20000 && $task_status!==20100)) {
                    $control['last_poll_status']='Fehlercode '.$task_status;
                    $control['status']='error';
                    $control['message']='DataForSEO-Auftrag fehlgeschlagen (Code '.$task_status.'): '.sanitize_text_field((string)($task['status_message'] ?? 'Keine weitere Beschreibung'));
                    unset($control['pending_id'],$control['pending_at'],$control['pending_post_id'],$control['pending_hash'],$control['pending_source'],$control['pending_category_slug'],$control['pending_title']);
                    update_option(self::HB_AMAZON_CONTROL,$control,false); return;
                }
                $result = (array)($task['result'] ?? array());
                if (!$result) { $control['last_poll_status']='Auftrag noch in Bearbeitung'; $control['status']='pending'; $control['message']='DataForSEO-Auftrag noch in Bearbeitung'; update_option(self::HB_AMAZON_CONTROL,$control,false); return; }
                $control['last_poll_status']='Antwort erhalten, Ergebnis geprüft';
                $items = (array)($result[0]['items'] ?? array());
                $expected = (string)($control['pending_hash'] ?? '');
                $pending_source=(string)($control['pending_source'] ?? '');
                $is_category=$pending_source==='hab_category';
                $is_article=$pending_source==='hab_article';
                $cid=absint($control['pending_post_id'] ?? 0);
                $topic=($is_article && $cid>0) ? $this->hb_amazon_article_topic(get_post($cid)) : null;
                $source=($is_category || $is_article) ? null : $this->campaign_from_post(get_post($cid));
                $title=($is_category || $is_article) ? (string)($control['pending_title'] ?? '') :
                    (is_array($source) ? (string)($source['title'] ?? '') : '');
                $hash_ok=$title!=='' && hash_equals($expected,
                    $is_article ? (string)($topic['hash'] ?? '') : hash('sha256',$this->hb_amazon_normalize_title($title)));
                $asin=(!$is_category && !$is_article && $hash_ok) ? $this->hb_amazon_exact_match_asin($title,$items) : '';
                if ($is_category) {
                    $slug=sanitize_key((string)($control['pending_category_slug'] ?? ''));
                    $found=$hash_ok ? $this->hb_amazon_category_results($title,$items) : array();
                    if ($slug!=='') {
                        $checked=(array)($control['category_checked'] ?? array());
                        $checked[$slug]=array('at'=>time(),'hash'=>$expected);
                        $control['category_checked']=array_slice($checked,-50,null,true);
                        if ($found) {
                            $saved=(array)($control['category_products'] ?? array());
                            $saved[$slug]=array('at'=>time(),'items'=>$found);
                            $control['category_products']=array_slice($saved,-50,null,true);
                        }
                    }
                    $control['status']=$found?'success':'empty';
                    $control['message']=$found ? count($found).' echte Amazon-Produktlinks für Hab-Kategorie gefunden' : 'Keine eindeutigen Amazon-Produktlinks für diese Hab-Kategorie';
                    if ($found) { $control['last_match_at']=time(); }
                } elseif ($is_article) {
                    if ($hash_ok && is_array($topic)) {
                        $found=$this->hb_amazon_article_results($topic,$items);
                        $checked=(array)($control['article_checked'] ?? array());
                        $checked[$cid]=array('hash'=>$expected,'at'=>time());
                        $control['article_checked']=array_slice($checked,-500,null,true);
                        $saved=(array)($control['article_products'] ?? array());
                        // Invalidate any previous article search result on failed recheck.
                        if ($found) { $saved[$cid]=array('at'=>time(),'hash'=>$expected,'items'=>$found); }
                        else { unset($saved[$cid]); }
                        $control['article_products']=array_slice($saved,-250,null,true);
                        if ($found) { $control['last_match_at']=time(); }
                        $control['status']=$found?'success':'empty';
                        $control['message']=$found ? count($found).' passende Amazon-Links für Beitrag geprüft'
                            : 'Keine eindeutig passenden Amazon-Produkte für Beitrag';
                    } else { $control['status']='empty'; $control['message']='Beitrag inzwischen geändert oder nicht mehr freigegeben; veraltetes Ergebnis verworfen'; }
                } elseif ($asin!=='' && $cid>0 && is_array($source) && !empty($source['active'])) {
                    $source['product_asins'] = array($asin);
                    $saved=$this->save_campaign_record($source,$cid);
                    if (!is_wp_error($saved) && $saved) {
                        update_post_meta($cid, '_ppar_hb_amazon_exact_match_v1', array('asin'=>$asin,'title_hash'=>$expected,'verified_at'=>time()));
                        $control['last_match_at']=time();
                        $control['status']='success'; $control['message']='Eindeutige ASIN zugeordnet';
                    } else { $control['status']='error'; $control['message']='ASIN-Speicherung fehlgeschlagen; keine Freigabe'; }
                } elseif (!$is_category) { $control['status']='empty'; $control['message']='Kein eindeutiges identisches Amazon-Produkt gefunden'; }
                $checked=(array)($control['checked'] ?? array());
                if ($cid>0) { $checked[$cid]=array('hash'=>$expected,'at'=>time()); }
                $control['checked']=array_slice($checked,-200,null,true);
                unset($control['pending_id'],$control['pending_post_id'],$control['pending_hash'],$control['pending_at'],
                    $control['pending_source'],$control['pending_category_slug'],$control['pending_title']);
                update_option(self::HB_AMAZON_CONTROL,$control,false);
                return;
            }
        }
        if ($poll_only) {
            $control['status']='idle';
            $control['message']='Kein offener Auftrag vorhanden – keine neue kostenpflichtige Suche gestartet';
            update_option(self::HB_AMAZON_CONTROL,$control,false);
            return;
        }
        if (absint($control['count'] ?? 0)>=5) { $control['status']='limit'; $control['message']='Tagesgrenze: 5 bezahlte Suchaufträge erreicht'; update_option(self::HB_AMAZON_CONTROL,$control,false); return; }
        $candidate = $this->hb_amazon_dfs_candidate($control);
        if (!$candidate) { $candidate=$this->hb_amazon_article_candidate($control); }
        if (!$candidate) { $candidate=$this->hb_amazon_category_candidate($control); }
        if (!$candidate) {
            // Show the real cause. The old implementation hid an invalid Hab catalog
            // behind the misleading success-like message 'no matching products'.
            $catalog = class_exists('PPAR_Portal_Source') ? PPAR_Portal_Source::catalog()
                : new WP_Error('hb_catalog_missing','Hab-Zielquelle ist nicht geladen.');
            if (is_wp_error($catalog)) {
                $control['status']='error';
                $control['message']='BLOCKIERT: '.$catalog->get_error_message();
            } elseif (!is_array($catalog) || empty($catalog['product_targets'])) {
                $control['status']='error';
                $control['message']='BLOCKIERT: Keine freigegebenen Hab-Produktkategorien im bestehenden Zielkatalog';
            } else {
                $control['status']='idle';
                $control['message']='Geprüft, keine neue Suche nötig: '.count((array)$catalog['product_targets']).' freigegebene Produktkategorien; '.count((array)($control['category_checked'] ?? array())).' bereits recherchiert';
            }
            update_option(self::HB_AMAZON_CONTROL,$control,false); return;
        }
        // The counter is reserved BEFORE the paid POST; a timeout can still be billable.
        $control['count']=absint($control['count'] ?? 0)+1;
        $control['last_attempt_at']=time();
        $control['status']='running';
        $control['message']='Bezahlte Suche gestartet: '.$candidate['title'];
        update_option(self::HB_AMAZON_CONTROL,$control,false);
        $payload = array(array('keyword'=>$candidate['title'], 'location_name'=>'Germany',
            'language_code'=>'de_DE', 'se_domain'=>'amazon.de', 'depth'=>20));
        $response = $this->hb_amazon_dfs_api('POST','https://api.dataforseo.com/v3/merchant/amazon/products/task_post',$payload,$s);
        if (is_wp_error($response)) { $control['status']='error'; $control['message']='Suchauftrag fehlgeschlagen (Tagesbudget reserviert): '.$response->get_error_message(); update_option(self::HB_AMAZON_CONTROL,$control,false); return; }
        $task = (array)($response['tasks'][0] ?? array());
        $id = (string)($task['id'] ?? '');
        if ((int)($task['status_code'] ?? 0)!==20100 && (int)($task['status_code'] ?? 0)!==20000) { $id=''; }
        if (!preg_match('/^[0-9a-f-]{36}$/D',$id)) {
            $control['status']='error';
            $control['message']='DataForSEO-Suchauftrag abgelehnt (Code '.(int)($task['status_code'] ?? 0).'): '.sanitize_text_field((string)($task['status_message'] ?? 'Keine gültige Auftrag-ID'));  update_option(self::HB_AMAZON_CONTROL,$control,false); return;
        }
        $control['pending_id']=$id; $control['pending_post_id']=$candidate['id'];
        $control['pending_hash']=$candidate['hash']; $control['pending_at']=time();
        $control['pending_source']=(string)($candidate['source'] ?? 'existing_campaign');
        $control['pending_category_slug']=(string)($candidate['category_slug'] ?? '');
        $control['pending_title']=$candidate['title'];
        $control['status']='pending';
        $control['message']='DataForSEO-Suchauftrag angelegt für: '.$candidate['title'].'; Ergebnis wird automatisch abgefragt';
        update_option(self::HB_AMAZON_CONTROL,$control,false);
    }
}
