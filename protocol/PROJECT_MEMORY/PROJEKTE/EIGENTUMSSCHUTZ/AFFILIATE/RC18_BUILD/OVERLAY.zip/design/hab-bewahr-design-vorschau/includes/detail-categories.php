<?php
/** Hab & Bewahr detail-category layout. One existing Design plugin; no tax/DB writes. */
if (!defined('ABSPATH')) exit;

function hbdp_detail_pilot_text($node) {
    static $rows=null;
    if($rows===null){
        $file=HBDP_ROOT.'data/detail-category-pilot.json';
        $data=is_readable($file)?json_decode((string)file_get_contents($file),true):array();
        $rows=(($data['contract']??'')==='HBDP_DETAIL_CATEGORIES_V1' && is_array($data['texts']??null))?$data['texts']:array();
    }
    $name=trim((string)($node['name']??''));
    $slug=(string)($node['slug']??'');
    foreach($rows as $r){
        if(!is_array($r))continue;
        $title=(string)($r['match_title']??'');
        if($title!==$name && !empty($r['match_area']))continue;
        if(!empty($r['match_area'])){
            // Strict scoped mapping by the actual current category ancestors;
            // the same label in another area must never borrow this essay.
            $ancestor=(string)($node['parent']??'');$names=array();$seen=array();
            for($depth=0;$depth<5 && $ancestor!=='' && !isset($seen[$ancestor]);$depth++){
                $seen[$ancestor]=true;$parent=function_exists('hbdp_node')?hbdp_node($ancestor):null;
                if(!is_array($parent))break;
                $names[]=(string)($parent['name']??'');
                $ancestor=(string)($parent['parent']??'');
            }
            if(!in_array((string)$r['match_area'],$names,true) || !in_array((string)$r['match_world'],$names,true))continue;
        } elseif($title!==$name && !in_array($slug,(array)($r['match_slugs']??array()),true))continue;
        $lead=trim((string)($r['lead']??''));$paras=$r['expanded_paragraphs']??array();
        if(!is_array($paras)||count($paras)<1 || $lead==='')continue;
        // Format gate: Hobby Depot detail lead 45-60 + 150-200 ADDITIONAL words.
        $words=static function($text){return count(preg_split('/\s+/u',trim($text),-1,PREG_SPLIT_NO_EMPTY));};
        if($words($lead)<45||$words($lead)>60||$words(implode(' ',$paras))<150||$words(implode(' ',$paras))>200)continue;
        return array('lead'=>$lead,'paras'=>$paras);
    }
    return null;
}
/** Semantic roles are determined centrally and consistently, never by randomness. */
function hbdp_detail_icon_role($name) {
    $s=function_exists('mb_strtolower')?mb_strtolower((string)$name,'UTF-8'):strtolower((string)$name);
    if(preg_match('/faq|fragen|antworten/u',$s))return 'help';
    if(preg_match('/vergleich|kaufberatung|auswahl|kauf/u',$s))return 'compare';
    if(preg_match('/pflege|wartung|instand|reinigung/u',$s))return 'tool';
    if(preg_match('/einbau|montage|nachrüst|befestigung/u',$s))return 'wrench';
    if(preg_match('/schloss|schlös|schließ|zylinder|riegel|schlüssel|zutritt/u',$s))return 'lock';
    if(preg_match('/glas|fenster|scheibe/u',$s))return 'window';
    if(preg_match('/melder|kamera|alarm|sensor/u',$s))return 'alarm';
    if(preg_match('/wasser|rückstau|feuchtigkeit|leck/u',$s))return 'droplet';
    if(preg_match('/brand|feuer|rauch/u',$s))return 'flame';
    if(preg_match('/strom|akku|elektro|notstrom/u',$s))return 'zap';
    if(preg_match('/grundlag|einstieg|wissen/u',$s))return 'book';
    return 'shield';
}
function hbdp_detail_icon($title) {
    $paths=array(
      'help'=>'<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.7 2.7 0 1 1 4.6 2c-1 1-2.1 1.5-2.1 3"/><path d="M12 17h.01"/>',
      'compare'=>'<rect x="3" y="4" width="7" height="16" rx="2"/><rect x="14" y="4" width="7" height="16" rx="2"/><path d="M5.5 9h2M16.5 9h2M5.5 13h2M16.5 13h2"/>',
      'tool'=>'<path d="M19 7a6 6 0 0 1-8 8l-6 6-3-3 6-6a6 6 0 0 1 8-8l-3 3 4 4z"/>',
      'wrench'=>'<path d="M17 6a5 5 0 0 0-6 6L3 20l2 2 8-8a5 5 0 0 0 6-6l-3 3-3-3z"/>',
      'lock'=>'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/>',
      'window'=>'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M12 3v18M3 12h18"/>',
      'alarm'=>'<path d="M6 17h12l-2-3V9a4 4 0 0 0-8 0v5zM10 20h4M4 8l-2 2M20 8l2 2"/>',
      'droplet'=>'<path d="M12 2S5 10 5 15a7 7 0 0 0 14 0c0-5-7-13-7-13z"/>',
      'flame'=>'<path d="M12 22c-4 0-7-3-7-7 0-3 2-6 6-11 0 4 2 5 2 8 2-1 3-3 3-5 3 4 4 6 4 9 0 3-3 6-8 6z"/>',
      'zap'=>'<path d="M13 2 4 13h7l-1 9 10-12h-7z"/>',
      'book'=>'<path d="M12 6c-3-2-6-2-9-1v14c3-1 6-1 9 1 3-2 6-2 9-1V5c-3-1-6-1-9 1zM12 6v14"/>',
      'shield'=>'<path d="M12 2 4 5v6c0 5 3 8 8 11 5-3 8-6 8-11V5z"/><path d="m9 12 2 2 4-4"/>'
    );
    $role=hbdp_detail_icon_role($title);
    return '<svg viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'.$paths[$role].'</svg>';
}
function hbdp_detail_category_posts($node) {
    $cats=array();
    if(($node['type']??'')==='category')$cats=array((int)$node['wp_id']);
    elseif(function_exists('hbdp_area_article_term_ids'))$cats=hbdp_area_article_term_ids((string)$node['id']);
    $cats=array_values(array_filter(array_unique(array_map('intval',$cats))));
    if(!$cats)return array();
    return get_posts(array('post_type'=>'post','post_status'=>'publish','category__in'=>$cats,'posts_per_page'=>4,'orderby'=>'date','order'=>'DESC','ignore_sticky_posts'=>true,'no_found_rows'=>true));
}

/** One tightly scoped visual pilot; no change to the shared category tree. */
function hbdp_detail_inline_pilot_node($node){
    if(!is_array($node) || ($node['type']??'')!=='page')return false;
    // Only the exact C2.2 Schaufenster detail page, never similarly named archives.
    $name=trim((string)($node['name']??''));
    $id=(string)($node['id']??'');
    return $name==='Schaufenster vor Sachbeschädigung' && strpos($id,'core:c22:')===0;
}
/** Read up to three distinct, approved offers from the existing integration filters.
 * One legacy item remains accepted. No new provider, persistent store or HTTP call.
 * Missing offers have admin-only previews: never fabricate merchant or price. */
function hbdp_detail_inline_pilot_products($node){
    if(!hbdp_detail_inline_pilot_node($node))return array();
    $items=apply_filters('hbdp_detail_inline_products_v2',array(),(string)$node['id']);
    if(!is_array($items))$items=array();
    $legacy=apply_filters('hbdp_detail_inline_product_v1',array(),(string)$node['id']);
    if(is_array($legacy)&&isset($legacy['title']))array_unshift($items,$legacy);
    $out=array();$seen=array();
    foreach($items as $item){
        if(!is_array($item))continue;
        $title=trim(sanitize_text_field((string)($item['title']??'')));
        $merchant=trim(sanitize_text_field((string)($item['merchant']??'')));
        $url=trim((string)($item['url']??''));
        if($title===''||$merchant===''||stripos($url,'https://')!==0||!wp_http_validate_url($url))continue;
        $key=function_exists('mb_strtolower')?mb_strtolower($merchant.'|'.$title,'UTF-8'):strtolower($merchant.'|'.$title);
        if(isset($seen[$key])||isset($seen[$url]))continue;
        $seen[$key]=true;$seen[$url]=true;
        $price=trim(sanitize_text_field((string)($item['price']??'')));
        $image=trim((string)($item['image']??''));
        if($image!==''&&(!wp_http_validate_url($image)||stripos($image,'https://')!==0))$image='';
        $out[]=array('title'=>$title,'merchant'=>$merchant,'url'=>$url,'price'=>$price,'image'=>$image);
        if(count($out)>=3)break;
    }
    return $out;
}
function hbdp_detail_inline_pilot_tile($product,$admin,$slot=1){
    if(!is_array($product)&&!$admin)return '';
    $real=is_array($product);
    $label=$real?'Anzeige · Affiliate':'Nur Admin · Produktvorschau '.$slot;
    $title=$real?$product['title']:'Produktkachel '.$slot.' (Vorschau)';
    $info=$real?($product['merchant'].($product['price']!==''?' · '.$product['price']:'')):'Hier fehlt noch ein geprüftes Angebot';
    $outer=$real?'<a class="hbdp-detail-tile hbdp-detail-inline-product" href="'.esc_url($product['url']).'" target="_blank" rel="sponsored noopener noreferrer" aria-label="'.esc_attr($title.' – Anzeige'). '">':'<div class="hbdp-detail-tile hbdp-detail-inline-product hbdp-detail-inline-demo" aria-label="Nur Administrator: Produktvorschau '.$slot.'">';
    $icon=($real && $product['image']!=='')?'<img class="hbdp-detail-inline-image" src="'.esc_url($product['image']).'" alt="" loading="lazy" decoding="async">':hbdp_detail_icon('Schutz');
    return $outer.'<span class="hbdp-detail-inline-heading">'.esc_html($label).'</span><span class="hbdp-detail-tile-icon">'.$icon.'</span><strong>'.esc_html($title).'</strong><span class="hbdp-detail-inline-meta">'.esc_html($info).'</span>'.($real?'<span class="hbdp-detail-tile-arrow" aria-hidden="true">→</span>':'').($real?'</a>':'</div>');
}

function hbdp_render_detail_category_page($node){
    $children=array_values(array_filter(hbdp_children($node['id']),static function($c) {return hbdp_nav_url($c)!=='';}));
    $pilot=hbdp_detail_pilot_text($node);
    $fallback=trim((string)hbdp_hub_top_copy($node));
    $products=hbdp_area_product_markup($node);$banner=hbdp_area_banner_markup($node);
    $pilot_page=hbdp_detail_inline_pilot_node($node);
    $inline_products=$pilot_page?hbdp_detail_inline_pilot_products($node):array();
    $posts=hbdp_detail_category_posts($node);
    $sponsor=hbdp_area_sponsor_for($node);$admin=current_user_can('manage_options');
    $inline_tiles=array();
    if($pilot_page)for($i=0;$i<3;$i++)$inline_tiles[]=hbdp_detail_inline_pilot_tile($inline_products[$i]??null,$admin,$i+1);
    $inline_tiles=array_values(array_filter($inline_tiles));
    $inline_has_real=count($inline_products)>0;
    // Preserve the exact accepted R3 hero from 0.1.97 (same image as parent R2 card).
    // The 0.1.98/0.1.99 large standalone photo and duplicate icon/H1 were regressions.
    $parent=hbdp_node((string)($node['parent']??''));
    $is_r3=(($node['type']??'')==='page' && $parent && hbdp_area_is_level2($parent));
    if($is_r3){
        $photo=hbdp_is_insurance_r3($node)?hbdp_insurance_topic_photo($node):hbdp_area_matching_topic_photo($node);
        $photo_ok=($photo!=='' && hbdp_area_photo_ok($photo));
        $world=hbdp_node((string)($parent['parent']??''));
        $world_name=(string)($world['name']??'Schutz');
        $claim=hbdp_r3_hero_claim($node);
        echo '<main class="hbdp-area-demo hbdp-area-page hbdp-r3-page" data-hbdp-detail-node="'.esc_attr($node['id']).'">';
        echo '<div class="hbdp-frame hbdp-area-demo-breadcrumb-top">';hbdp_breadcrumb($node);echo '</div>';
        if($photo_ok){
            echo '<div class="hbdp-frame hbdp-area-demo-hero-frame"><header class="hbdp-area-demo-hero">';
            echo '<img src="'.esc_url(HBDP_URL.'assets/'.$photo).'" alt="" fetchpriority="high" decoding="async">';
            echo '<div class="hbdp-area-demo-shade" aria-hidden="true"></div><div class="hbdp-area-demo-hero-text">';
            echo '<span class="hbdp-area-demo-eyebrow">'.esc_html($world_name).' · Schutzthema</span>';
            echo '<h1>'.esc_html(hbdp_compass_display_name($node)).'</h1><p>'.esc_html($claim).'</p>';
            echo '</div></header></div>';
        } else {
            echo '<div class="hbdp-frame hbdp-r3-unpictured"><span class="hbdp-area-demo-eyebrow">'.esc_html($world_name).' · Schutzthema</span><h1>'.esc_html(hbdp_compass_display_name($node)).'</h1><p>'.esc_html($claim).'</p></div>';
        }
        echo '<div class="hbdp-frame hbdp-area-demo-inner hbdp-detail-category">';
    }else{
        echo '<main class="hbdp-frame hbdp-detail-category" data-hbdp-detail-node="'.esc_attr($node['id']).'">';
        hbdp_breadcrumb($node);
        echo '<header class="hbdp-detail-heading"><div><span class="hbdp-detail-kicker">Schutz &amp; Sicherheit</span><h1>'.esc_html(hbdp_compass_display_name($node)).'</h1></div></header>';
    }
    if($pilot){
        echo '<section class="hbdp-detail-intro" aria-label="Einführung">';
        echo '<p class="hbdp-detail-lead">'.esc_html($pilot['lead']).'</p>';
        echo '<details class="hbdp-detail-accordion"><summary><span>Weiterlesen</span><span class="hbdp-detail-chevron" aria-hidden="true"></span></summary><div class="hbdp-detail-expansion">';
        foreach($pilot['paras'] as $p)echo '<p>'.esc_html($p).'</p>';
        echo '</div></details></section>';
    }elseif($fallback!==''){
        // Preserve existing topical/WordPress content, but don't fake 150-200 more words.
        echo '<section class="hbdp-detail-intro hbdp-detail-short"><p class="hbdp-detail-lead">'.esc_html($fallback).'</p></section>';
    }
    // Reuse the already installed affiliate hooks. No fabricated banners or products.
    // With topic cards, the SAME original campaign goes inside the grid below.
    // On a leaf without a card grid, keep the original standalone banner slot.
    if(!$children && ($banner!=='' || $admin)){
        echo '<section class="hbdp-detail-banner" aria-label="Affiliate-Banner">';
        if($banner!=='')echo '<small>ANZEIGE · AFFILIATE</small>'.$banner;
        else echo '<small>Nur Admin · bestehender Affiliate-Bannerslot</small><p>Kein passendes Werbemittel geliefert – öffentlich ausgeblendet.</p>';
        echo '</section>';
    }
    if($children){
        echo '<section class="hbdp-detail-section hbdp-detail-categories" aria-label="Unterkategorien"><h2>Weitere Themen rund um '.esc_html(hbdp_compass_display_name($node)).'</h2><div class="hbdp-detail-grid'.($inline_tiles?' hbdp-detail-grid-product-pilot':'').'">';
        $hbdp_topic_position=0;$hbdp_product_pos=0;
        foreach($children as $c){
            echo '<a class="hbdp-detail-tile" href="'.esc_url(hbdp_nav_url($c)).'"><span class="hbdp-detail-tile-icon">'.hbdp_detail_icon($c['name']).'</span><strong>'.esc_html(hbdp_compass_display_name($c)).'</strong><span class="hbdp-detail-tile-arrow" aria-hidden="true">→</span></a>';
            $hbdp_topic_position++;
            // One compact product per desktop 3-column row, at most 3, pilot only.
            if($hbdp_topic_position%2===0 && $hbdp_product_pos<count($inline_tiles)){
                echo $inline_tiles[$hbdp_product_pos++];
            }
        }
        // No ad-only trailing row: for short categories don't append empty tiles.
        // RC18: visible on all deeper page/category levels, not just R2/world.
        // Preserve original product tiles and booked campaign priority.
        if($banner!==''){
            $columns=$inline_tiles?3:4;
            $existing=count($children)+min(count($inline_tiles),intdiv(count($children),2));
            $rest=$existing%$columns;
            $span=$rest===0?$columns:($columns-$rest);
            $tablet_span=$existing%2===0?2:1;
            echo '<div class="hbdp-detail-inline-ad-tile hbdp-detail-inline-span-'.(int)$span.' hbdp-detail-inline-tablet-'.(int)$tablet_span.'" aria-label="Amazon-Themenempfehlung">'.$banner.'</div>';
        }
        echo '</div></section>';
    }
    if(!$pilot_page && ($products!=='' || $admin)){
        echo '<section class="hbdp-detail-section hbdp-detail-products" aria-label="Affiliate-Produkte"><h2>Empfehlungen</h2>';
        if($products!=='')echo '<div class="hbdp-detail-products-feed">'.$products.'</div>';
        else echo '<p class="hbdp-detail-admin-placeholder">Nur Admin · vorhandener Produktslot; noch keine fachlich passenden Affiliate-Produkte geliefert.</p>';
        echo '</section>';
    }
    if($posts){
        echo '<section class="hbdp-detail-section hbdp-detail-guides"><h2>Ratgeber zum Thema</h2><div class="hbdp-detail-guides-grid">';
        foreach($posts as $post){
            if(get_post_meta($post->ID,'_hbdp_demo',true)==='1')continue;
            $title=get_the_title($post->ID);if(trim((string)$title)==='')continue;
            echo '<a class="hbdp-detail-guide" href="'.esc_url(get_permalink($post->ID)).'">';
            if(has_post_thumbnail($post->ID))echo get_the_post_thumbnail($post->ID,'medium_large',array('loading'=>'lazy','decoding'=>'async'));
            echo '<span><small>Ratgeber</small><strong>'.esc_html($title).'</strong><em>Artikel lesen →</em></span></a>';
        }
        echo '</div></section>';
    }
    if($sponsor||$admin){
        echo '<section class="hbdp-detail-sponsor" aria-label="Werbeplatz">';
        if($sponsor){echo '<small>ANZEIGE · WERBEPARTNER</small><strong>'.esc_html($sponsor['title']).'</strong><a rel="sponsored noopener noreferrer" target="_blank" href="'.esc_url($sponsor['url']).'">Zum Angebot →</a>';}
        else echo '<small>Nur Admin · bestehender Direktwerbeplatz</small><span>Kein Inserat gebucht – öffentlich ausgeblendet.</span>';
        echo '</section>';
    }
    echo $is_r3?'</div></main>':'</main>';
}
