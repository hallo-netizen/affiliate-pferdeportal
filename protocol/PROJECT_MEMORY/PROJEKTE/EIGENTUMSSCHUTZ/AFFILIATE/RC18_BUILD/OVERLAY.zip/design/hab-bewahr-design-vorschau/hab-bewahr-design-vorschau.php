<?php
/**
 * Plugin Name: Hab & Bewahr – Design
 * Description: Ein einziges leichtgewichtiges Designplugin für Startseite, Schutzwelten, Kategorien, Magazin, Dienstleister und Beiträge. Kein Kategorie-Sync.
 * Version: 0.1.191
 * Author: Hab & Bewahr
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) { exit; }
define('HBDP_ROOT', plugin_dir_path(__FILE__));
define('HBDP_URL', plugin_dir_url(__FILE__));
require_once HBDP_ROOT.'includes/favicon.php';

/**
 * One central WordPress category snapshot is authoritative. It is written by the
 * already installed category workflow. This DESIGN plugin only reads it.
 * nodes.json holds the verified R3 readback as a last-resort preview fallback.
 */
function hbdp_all_nodes() {
    static $nodes = null;
    if ($nodes !== null) return $nodes;
    $nodes = array();
    $revision = (string)get_option('apkw_target_tree_active_revision_v1', '');
    $snapshot = get_option('apkw_target_tree_active_snapshot_v1', array());
    if (is_array($snapshot) && $revision !== ''
        && (string)($snapshot['revision'] ?? '') === $revision
        && is_array($snapshot['nodes'] ?? null) && is_array($snapshot['mapping'] ?? null)) {
        foreach ($snapshot['nodes'] as $raw) {
            if (!is_array($raw)) continue;
            $id = (string)($raw['node_id'] ?? '');
            if ($id === '') continue;
            $ref = $snapshot['mapping'][$id] ?? null;
            if (!is_array($ref)) continue;
            $type = (string)($ref['object_type'] ?? $raw['object_type'] ?? '');
            $wp_id = (int)($ref['object_id'] ?? 0);
            if ($wp_id < 1 || !in_array($type, array('page','category','journal_cat','hp_listing_category'), true)) continue;
            $nodes[$id] = array('id'=>$id,'name'=>trim((string)($raw['display_name'] ?? $raw['name'] ?? '')),
                'type'=>$type,'pillar'=>(string)($raw['pillar'] ?? ''),
                'parent'=>(string)($raw['parent_id'] ?? ''),'wp_id'=>$wp_id,
                'slug'=>(string)($raw['slug'] ?? ''));
        }
        if (isset($nodes['core:hub']) && count($nodes) >= 6) return $nodes;
        $nodes = array();
    }
    // Once WordPress has an active central tree revision, never silently serve
    // the old bundled R3 snapshot as a second navigation authority. Fail closed.
    if ($revision !== '') return $nodes;
    // Fallback solely for a standalone preview with no registered live tree.
    $path = HBDP_ROOT.'nodes.json';
    $data = is_readable($path) ? json_decode(file_get_contents($path), true) : array();
    foreach (($data['nodes'] ?? array()) as $n) if (is_array($n) && isset($n['id'])) $nodes[$n['id']] = $n;
    return $nodes;
}
function hbdp_active_revision() {
    $revision=(string)get_option('apkw_target_tree_active_revision_v1','');
    if ($revision !== '') return $revision;
    $file=HBDP_ROOT.'nodes.json';
    $data=is_readable($file)?json_decode(file_get_contents($file),true):array();
    return (string)($data['profile_revision']??'fallback');
}
function hbdp_node($id) { $all=hbdp_all_nodes();return $all[$id]??null; }
/**
 * The authoritative snapshot retains older page3 leaves and V99 pages for URL
 * compatibility. Only C2.2 pages are forward navigation when C2.2 exists.
 * Never delete, reparent or redirect any protected WordPress object here.
 */
function hbdp_nav_is_c22($n) { return strpos((string)($n['id'] ?? ''), 'core:c22:') === 0; }
function hbdp_canonical_children($id, $source = null) {
    $parent_nodes = is_array($source) ? $source : hbdp_all_nodes();
    $parent = $parent_nodes[$id] ?? null;
    if (!$parent && $id !== 'core:hub') return array();
    $raw = array();
    foreach ($parent_nodes as $n) {
        if (!is_array($n) || ($n['type'] ?? '') === 'relation') continue;
        if (($n['parent'] ?? '') === $id || ($id === 'core:hub' && strpos((string)($n['id'] ?? ''), 'core:world:') === 0)) $raw[]=$n;
    }
    if (!$raw) return array();
    // Flat article archives contain posts, never sibling categories as children.
    if (($parent['type'] ?? '') === 'category') return array();
    // New C2.2 topics complement, but do not automatically replace, older
    // independent R3 topics. 17 areas have fewer than three new topics.
    // Preserve a minimum three meaningful topic links under every area.
    $is_area = strpos($id, 'core:area:') === 0 || strpos($id, 'core:c22:area:') === 0;
    if ($is_area) {
        $filtered=array();$names=array();
        $parentLabel=(string)($parent['name'] ?? '');
        $parentKey=trim(function_exists('mb_strtolower')?mb_strtolower($parentLabel,'UTF-8'):strtolower($parentLabel));
        foreach ($raw as $n) {
            // The historical broad page repeats its parent in the observed
            // Frost/Leerstand path; its public URL remains fully accessible.
            if ($id==='core:area:d03822af4a84' && ($n['id'] ?? '')==='core:subarea:c8a6a3e042c29ffd')continue;
            $key=trim(function_exists('mb_strtolower')?mb_strtolower(html_entity_decode((string)($n['name'] ?? ''),ENT_QUOTES,'UTF-8'),'UTF-8'):strtolower(html_entity_decode((string)($n['name'] ?? ''),ENT_QUOTES,'UTF-8')));
            if ($key!=='' && $key===$parentKey)continue; // no child repeating its own parent
            if (!isset($names[$key])){$filtered[]=$n;$names[$key]=count($filtered)-1;}
            elseif (hbdp_nav_is_c22($n) && !hbdp_nav_is_c22($filtered[$names[$key]]))$filtered[$names[$key]]=$n;
        }
        // New concrete C2.2 topics first; older legitimate topics follow.
        usort($filtered,static function($a,$b){return (int)hbdp_nav_is_c22($b)<=>(int)hbdp_nav_is_c22($a);});
        return $filtered;
    }
    // Duplicate v99/c22 world-area pages with the same name were exposed
    // together. Prefer C2.2 in navigation, keeping old public URLs intact.
    if (strpos($id,'core:world:') === 0) {
        $selected=array();$order=array();
        foreach ($raw as $n) {
            $label=html_entity_decode((string)($n['name'] ?? ''),ENT_QUOTES,'UTF-8');
            $key=trim(function_exists('mb_strtolower')?mb_strtolower($label,'UTF-8'):strtolower($label));
            if ($key==='') $key='id:'.(string)$n['id'];
            if (!isset($selected[$key])) {$selected[$key]=$n;$order[]=$key;}
            elseif (hbdp_nav_is_c22($n) && !hbdp_nav_is_c22($selected[$key])) $selected[$key]=$n;
        }
        return array_map(static function($key) use ($selected) {return $selected[$key];},$order);
    }
    return $raw;
}
function hbdp_children($id) {return hbdp_canonical_children($id);}
/** A missing physical URL must never silently become the home page. */
function hbdp_nav_url($node) {
    if (!is_array($node) || empty($node['wp_id']))return '';
    // The Anzeigenmarkt IS the HivePress listing archive, exactly as in Hobby Depot.
    // Route all navigation sources through this one existing destination.
    if (($node['id'] ?? '')==='directory:hub' && function_exists('hbdp_market_landing_url')) {
        $market_url=hbdp_market_landing_url(); if ($market_url !== '') return $market_url;
    }
    if (($node['type']??'')==='page'){
        $parent=hbdp_node((string)($node['parent']??''));
        if ($parent && ($parent['type']??'')==='page' && (int)$parent['wp_id']===(int)$node['wp_id'])return '';
        $u=get_permalink((int)$node['wp_id']);
        if (!is_string($u) || $u==='')return '';
        if ($parent && ($parent['type']??'')==='page'){
            $pu=get_permalink((int)$parent['wp_id']);
            if (is_string($pu) && $pu===$u)return ''; // never link to own parent
        }
        $visited=[];$cursor=$node;
        while ($cursor && ($pid=(string)($cursor['parent']??''))!==''){
            if(isset($visited[$pid]) || $pid===$node['id'])return '';
            $visited[$pid]=true;$cursor=hbdp_node($pid);
        }
        return $u;
    }
    $tax=($node['type']??'')==='category'?'category':($node['type']??'');
    $t=get_term((int)$node['wp_id'],$tax);
    if (!$t || is_wp_error($t))return '';
    $u=get_term_link($t,$tax);
    return is_wp_error($u)||!is_string($u)||$u===''?'':$u;
}
function hbdp_url($n) {
    if (!$n) return home_url('/');
    if (($n['id'] ?? '')==='directory:hub' && function_exists('hbdp_market_landing_url')) {
        $market_url=hbdp_market_landing_url(); if ($market_url !== '') return $market_url;
    }
    if ($n['type']==='page') return get_permalink((int)$n['wp_id']) ?: home_url('/');
    $tax=$n['type']==='category' ? 'category' : $n['type'];
    $term=get_term((int)$n['wp_id'],$tax);
    if ($term && !is_wp_error($term)) { $u=get_term_link($term,$tax); if(!is_wp_error($u))return $u; }
    return home_url('/');
}
require_once HBDP_ROOT.'includes/footer-service.php';
require_once HBDP_ROOT.'includes/faq-page.php';
/**
 * AGB is an existing published WordPress page, and the observed public URL is
 * /agb_trashed/. The previous release unnecessarily required an identical
 * post_name; if WordPress resolves that URL to a differently named page, it
 * skipped the design entirely. Match the exact public path and the resolved
 * real published page, without making the internal slug a second decision.
 * No DB writes, redirects, WP theme changes, or duplicated page markup.
 */
function hbdp_agb_request_v162() {
    if (is_admin() || is_feed() || is_embed() || is_robots()) return false;
    $path = (string)wp_parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
    $path = trim(rawurldecode($path), '/');
    $base = trim(rawurldecode((string)wp_parse_url(home_url('/'), PHP_URL_PATH)), '/');
    if ($base !== '') {
        if (strpos($path, $base.'/') !== 0) return false;
        $path = substr($path, strlen($base)+1);
    }
    if ($path !== 'agb_trashed') return false;
    $page = get_queried_object();
    return $page instanceof WP_Post && $page->post_type === 'page'
        && $page->post_status === 'publish';
}

function hbdp_for_query(){
    if (hbdp_agb_request_v162()) return 'service:agb_trashed';
    // The existing published Anzeigenmarkt/Dienstleister PAGE owns the landing,
    // even when HivePress also uses this very WP page as hp_page_listings.
    // The previous reverse order made the landing unreachable on that setup.
    // Search/filter/pagination still belong exclusively to HivePress.
    if (function_exists('hbdp_market_search_request') && hbdp_market_search_request()) return 'market:search';
    if (function_exists('hbdp_market_root_request') && hbdp_market_root_request()) return 'market:root';
    if (function_exists('hbdp_market_is_hivepress_route') && hbdp_market_is_hivepress_route()) return null;
    if (function_exists('hbdp_is_faq_path') && hbdp_is_faq_path()) return 'service:faq';
    if (function_exists('hbdp_search_request') && hbdp_search_request()) return 'search-results';
    if (function_exists('hbdp_is_glossary_preview_path') && hbdp_is_glossary_preview_path()) return 'glossary-preview';
    if (function_exists('hbdp_is_glossary_path') && hbdp_is_glossary_path()) return 'glossary';
    if (function_exists('get_query_var') && get_query_var('hbdp_glossary')) return 'glossary';

    if(is_front_page() || is_home()) return 'home';
    if(is_singular('hbdp_glossar_term')) return 'glossary-term';
    if(is_singular('post')) return 'article';
    // The old editorial glossary page is not guaranteed to be part of the CURRENT
    // category-tree snapshot. Match its verified WordPress slug independently.
    if(is_page()) {
        $glossary_slug=(string)get_post_field('post_name',get_queried_object_id());
        if(in_array($glossary_slug,array('magazin-glossar-a-z','glossar'),true)) return 'glossary';
    }
    if(is_page()) {$id=get_queried_object_id();foreach(hbdp_all_nodes() as $n) if($n['type']==='page' && (int)$n['wp_id']===$id) return $n['id']==='editorial:glossar'?'glossary':$n['id'];}
    if(is_page()) { $slug=(string)get_post_field('post_name',get_queried_object_id()); if(hbdp_service_is_supported_slug($slug))return 'service:'.$slug; }
    if(is_category() || is_tax(array('journal_cat','hp_listing_category'))) {
        $term=get_queried_object();if(!$term || is_wp_error($term))return null;
        foreach(hbdp_all_nodes() as $n) if($n['type']===($term->taxonomy==='category'?'category':$term->taxonomy) && (int)$n['wp_id']===(int)$term->term_id)return $n['id'];
    }
    return null;
}
function hbdp_preview_template($template){
    if(is_admin() || is_feed() || is_robots() || is_embed())return $template;
    $section=hbdp_for_query();
    // HivePress installs its own template_include filter at priority 10000.
    // On its listings root, that callback prints the original view and exits,
    // even after this design template was selected at priority 99.
    // Disable that one later callback ONLY on our verified market landing.
    // HivePress search, filters, categories, detail pages remain untouched.
    if (in_array($section,array('market:root','market:search'),true) && function_exists('hivepress') && function_exists('remove_filter')) {
        try {
            $app=hivepress();
            $router=is_object($app) ? ($app->router ?? null) : null;
            if (is_object($router) && method_exists($router,'set_page_template')) {
                remove_filter('template_include',array($router,'set_page_template'),10000);
            }
        } catch (Throwable $error) {
            // A nonstandard HivePress installation must not break the site.
        }
    }
    return $section !== null ? HBDP_ROOT.'templates/site.php' : $template;
}
require_once HBDP_ROOT.'includes/article-page.php';
require_once HBDP_ROOT.'includes/article-undated-seo.php';
add_filter('template_include','hbdp_preview_template',99);
add_action('wp_enqueue_scripts', static function () {
    if (!is_singular('post') || get_post_meta(get_queried_object_id(),'_hbdp_demo',true)==='1') return;
    wp_enqueue_style('hbdp-article-design', HBDP_URL.'assets/article-design.css', array('hbdp-site'), '0.1.189');
    wp_enqueue_script('hbdp-mobile-affiliate', HBDP_URL.'assets/article-mobile-affiliate.js', array(), '0.1.188', true);
}, 100);
/**
 * WordPress has resolved the page by the `wp` event. Render through exactly
 * the same templates/site.php that already handles Impressum and Datenschutz.
 * This single page-specific route runs BEFORE unrelated late template filters,
 * which repeatedly left the AGB page in the default WordPress theme.
 */
add_action('wp', static function() {
    if (!hbdp_agb_request_v162()) return;
    require HBDP_ROOT.'templates/site.php';
    exit;
}, 999);

add_action('wp_enqueue_scripts', 'hbdp_footer_service_enqueue', 80);
// Only load design assets when our template or explicit shortcode is used. No site-wide navigation JS.
add_action('wp_enqueue_scripts', function () {
    if (hbdp_for_query() === null && !hbdp_has_start_shortcode()) return;
    wp_enqueue_style('hbdp-site', HBDP_URL.'assets/style.css', array(), '0.1.191');
    $design_node=hbdp_node(hbdp_for_query());
    $design_is_r3=is_array($design_node) && ($design_node['type']??'')==='page' && hbdp_area_is_level2(hbdp_node((string)($design_node['parent']??'')));
    if (hbdp_area_is_level2($design_node) || $design_is_r3) {
        wp_enqueue_style('hbdp-area-prototype', HBDP_URL.'assets/area-prototype.css', array('hbdp-site'), '0.1.191');
    }
    if ($design_is_r3 || (is_array($design_node) && ($design_node['type']??'')==='category')) {
        wp_enqueue_style('hbdp-detail-category', HBDP_URL.'assets/detail-categories.css', array('hbdp-site'), '0.1.191');
        // Inline the same R3 design-only override so stale browser/CDN CSS cannot mask this change.
        // Existing CSS, text rendering and all category mappings remain as before.
        if ($design_is_r3) {
            $hbdp_css_file = HBDP_ROOT.'assets/detail-categories.css';
            if (is_readable($hbdp_css_file)) {
                $hbdp_css_body = (string)file_get_contents($hbdp_css_file);
                $hbdp_css_offset = strpos($hbdp_css_body, '/* HBDP R3 DESIGN FIX 0.1.104');
                if ($hbdp_css_offset !== false) {
                    wp_add_inline_style('hbdp-detail-category', substr($hbdp_css_body, $hbdp_css_offset));
                }
            }
        }
    }
    $hbdp_section=hbdp_for_query();
    if ($hbdp_section==='service:faq') {
        wp_enqueue_style('hbdp-faq', HBDP_URL.'assets/faq.css', array('hbdp-site'), '0.1.113');
    }
    if (in_array($hbdp_section, array('market:root','market:search','directory:hub'), true)) {
        wp_enqueue_style('hbdp-market', HBDP_URL.'assets/market.css', array('hbdp-site'), '0.1.132');
    }
    if ($hbdp_section==='core:hub') {
        wp_enqueue_style('hbdp-schutzkompass', HBDP_URL.'assets/schutzkompass.css', array('hbdp-site'), '0.1.112');
    }
    $hbdp_mag_node=hbdp_node($hbdp_section);
    if($hbdp_section==='core:hub' || ($hbdp_mag_node && ($hbdp_mag_node['pillar']??'')==='editorial'
        && $hbdp_section!=='editorial:glossar')) {
        wp_enqueue_style('hbdp-magazine-hubs', HBDP_URL.'assets/magazine-hubs.css', array('hbdp-site'), '0.1.112');
    }
    // Legacy shortcuts cleaner is loaded exactly once via the shared frontend enqueuer.
    wp_enqueue_style('hbdp-house-ad-premium', HBDP_URL.'assets/house-ad-premium.css', array(), '0.1.165');
    wp_enqueue_style('hbdp-header', HBDP_URL.'assets/header.css', array('hbdp-site'), '0.1.79');
    if (hbdp_for_query() === 'home' || hbdp_has_start_shortcode()) {
        wp_enqueue_style('hbdp-startseite', HBDP_URL.'assets/startseite.css', array('hbdp-header'), '0.1.114');
    }
    if (in_array(hbdp_for_query(),array('glossary','glossary-term','glossary-preview'),true)) {
        // Like Hobby Depot: one self-contained, cache-independent inline glossary stylesheet.
        // Prevent external stylesheet caches from undoing the AJAX overlay and detail columns.
        wp_register_style('hbdp-glossary', false, array('hbdp-header'), '0.1.89');
        wp_enqueue_style('hbdp-glossary');
        $glossary_css=HBDP_ROOT.'assets/glossary.css';
        if(is_readable($glossary_css))wp_add_inline_style('hbdp-glossary',file_get_contents($glossary_css));
    }
    if (hbdp_for_query()==='glossary') wp_enqueue_script('hbdp-glossary', HBDP_URL.'assets/glossary.js', array(), '0.1.89', true);
    wp_enqueue_style('hbdp-main-search', HBDP_URL.'assets/global-search.css', array('hbdp-header'), '0.1.132');
    wp_enqueue_script('hbdp-main-search', HBDP_URL.'assets/global-search.js', array(), '0.1.105', true);
    wp_localize_script('hbdp-main-search', 'hbdpSearchConfig', array(
        'endpoint'=>admin_url('admin-ajax.php'), 'nonce'=>wp_create_nonce('hbdp_main_search_v0105')
    ));
    wp_enqueue_script('hbdp-nav', HBDP_URL.'assets/nav.js', array(), '0.1.26', true);
}, 99);
/** One source for breadcrumb top position on all portal-rendered content pages.
 * Do not enqueue on native HivePress routes (especially /submit-listing/):
 * their header/form layout is already accepted and remains untouched.
 */
add_action('wp_enqueue_scripts', static function () {
    if (is_admin() || hbdp_for_query() === null) return;
    wp_enqueue_style(
        'hbdp-breadcrumb-position',
        HBDP_URL . 'assets/breadcrumb-position.css',
        array('hbdp-site', 'hbdp-footer-service'),
        '0.1.157'
    );
}, 1000);
function hbdp_has_start_shortcode() {
    if (!is_singular()) return false;
    $post = get_post(get_queried_object_id());
    return $post && has_shortcode((string)$post->post_content, 'habundbewahr_startseite');
}
require_once HBDP_ROOT.'includes/global-search.php';
require_once HBDP_ROOT.'includes/house-ad-premium.php';
require_once HBDP_ROOT.'includes/class-hb-design-startseite-view.php';
require_once HBDP_ROOT.'includes/category-name-labels.php';
require_once HBDP_ROOT.'includes/menu-labels.php';
require_once HBDP_ROOT.'includes/glossary-manager.php';
require_once HBDP_ROOT.'includes/glossary.php';
require_once HBDP_ROOT.'includes/glossary-migration.php';
require_once HBDP_ROOT.'includes/glossary-production-092.php';
require_once HBDP_ROOT.'includes/glossary-production-093.php';
require_once HBDP_ROOT.'includes/glossary-production-094.php';
require_once HBDP_ROOT.'includes/glossary-production-095.php';
require_once HBDP_ROOT.'includes/category-content.php';
require_once HBDP_ROOT.'includes/world-layout.php';
require_once HBDP_ROOT.'includes/area-design-prototype.php';
require_once HBDP_ROOT.'includes/r3-topic-hero.php';
require_once HBDP_ROOT.'includes/detail-categories.php';
require_once HBDP_ROOT.'includes/schutzkompass.php';
require_once HBDP_ROOT.'includes/editorial-banners.php';
require_once HBDP_ROOT.'includes/market.php';
require_once HBDP_ROOT.'includes/market-search-submit.php';
require_once HBDP_ROOT.'includes/hobby-market-profile.php';
require_once HBDP_ROOT.'includes/magazine-hubs.php';
require_once HBDP_ROOT.'includes/magazine-clean-links.php';
// Compatibility with the separate 0.1.0 plugin; the canonical front page is rendered only once.
add_shortcode('habundbewahr_startseite', function () {
    return HB_Design_Startseite_View::render(hbdp_startseite_urls(), HBDP_URL.'assets/', true);
});
// Compute front-page destinations using the central active node references.
function hbdp_startseite_urls() {
    $urls = array('worlds'=>array(), 'focus'=>array());
    $world_ids = array(
        'core:world:einbruch-und-diebstahl',
        'core:world:vandalismus-und-zerstorung',
        'core:world:wasser-und-feuchtigkeit',
        'core:world:feuer-und-gase',
        'core:world:wetter-und-naturgefahren',
        'core:world:technik-und-ausfalle'
    );
    foreach ($world_ids as $i=>$id) {
        $node=hbdp_node($id);
        if ($node) {
            $urls['worlds'][$i]=hbdp_url($node);
            $urls['world_names'][$i]=hbdp_display_category_name($node);
        }
    }
    foreach (HB_Design_Startseite_View::focus_ids() as $i=>$id) {
        $node=hbdp_node($id);
        if ($node) $urls['focus'][$i]=hbdp_url($node);
    }
    foreach (array('topics'=>'core:hub','magazine'=>'editorial:hub','providers'=>'directory:hub') as $key=>$id) {
        $node=hbdp_node($id);
        if ($node) $urls[$key]=hbdp_url($node);
    }
    // No invented advertising destination: text remains visible; CTA appears when configured later.
    return $urls;
}

function hbdp_demo_spec(){return array(
 array('key'=>'einbruch','title'=>'DEMO – Haustür gegen Einbruch sichern','category'=>'core:leaf:001','image'=>'einbruch.jpg','intro'=>'So könnte ein praxisnaher Ratgeber zur Sicherung von Türen und Fenstern aussehen.'),
 array('key'=>'graffiti','title'=>'DEMO – Graffiti an der Fassade entfernen','category'=>'core:leaf:024','image'=>'graffiti.jpg','intro'=>'Beispieltext zu Reinigung, Schutz der Oberfläche und hilfreichen ersten Schritten.'),
 array('key'=>'wasser','title'=>'DEMO – Feuchtigkeit im Keller erkennen','category'=>'core:leaf:045','image'=>'wasser.jpg','intro'=>'Beispiel für einen Ratgeber zu Ursachen, Messung und Trocknung.'),
 array('key'=>'akku','title'=>'DEMO – E-Bike-Akkus sicher lagern','category'=>'core:leaf:059','image'=>'akku.jpg','intro'=>'Beispiel für einen übersichtlichen Brandschutzbeitrag zur Akkulagerung.')
);}
function hbdp_create_demo_posts(){
    foreach(hbdp_demo_spec() as $s){
        $existing=get_posts(array('post_type'=>'post','post_status'=>'any','meta_key'=>'_hbdp_demo_key','meta_value'=>$s['key'],'fields'=>'ids','numberposts'=>1));
        if($existing){ if(get_post_status($existing[0])==='draft')wp_update_post(array('ID'=>$existing[0],'post_status'=>'publish')); continue; }
        $node=hbdp_node($s['category']);if(!$node || $node['type']!=='category')continue;
        $content='<p><strong>DEMO / BLINDTEXT – kein redaktionell geprüfter Fachartikel.</strong></p><p>'.esc_html($s['intro']).'</p><h2>Ein Beispielabschnitt</h2><p>Hier steht später ein ausführlicher, fachlich geprüfter Ratgeber. Dieser Platzhalter dient ausschließlich dazu, Seitenaufbau, Überschriften und Bildpositionen zu beurteilen.</p><h2>Was später ergänzt wird</h2><p>Schritt-für-Schritt-Anleitungen, passende Lösungen, weitere Bilder, interne Verweise und ein nachvollziehbarer Vergleich.</p>';
        $id=wp_insert_post(array('post_type'=>'post','post_status'=>'publish','post_title'=>$s['title'],'post_content'=>$content,'post_excerpt'=>$s['intro'],'post_author'=>get_current_user_id() ?: 1,'post_category'=>array((int)$node['wp_id'])),true);
        if(!is_wp_error($id) && $id){update_post_meta($id,'_hbdp_demo','1');update_post_meta($id,'_hbdp_demo_key',$s['key']);}
    }
}
// Testartikel ausschließlich auf ausdrückliche Admin-Aktion, nie automatisch beim Plugin-Update veröffentlichen.
// Revert only our published demo posts to drafts when the preview is disabled.
register_deactivation_hook(__FILE__,function(){
    foreach(get_posts(array('post_type'=>'post','post_status'=>'publish','meta_key'=>'_hbdp_demo','meta_value'=>'1','numberposts'=>20)) as $post)
        wp_update_post(array('ID'=>$post->ID,'post_status'=>'draft'));
});
add_filter('wp_robots',function($robots){
    if(is_singular('post') && get_post_meta(get_queried_object_id(),'_hbdp_demo',true)==='1'){$robots['noindex']=true;$robots['nofollow']=true;}
    return $robots;
},99);
add_action('admin_menu',function(){add_management_page('Hab & Bewahr – Design','Hab & Bewahr Design','manage_options','hbdp-preview','hbdp_admin');});
function hbdp_admin(){if(!current_user_can('manage_options'))wp_die('Keine Berechtigung');
    hbdp_world_sponsor_admin_save();
    hbdp_area_sponsor_admin_save();
    if(isset($_POST['hbdp_action'])){
        check_admin_referer('hbdp_control');
        if($_POST['hbdp_action']==='price_restore') $hbdp_price_result=hbdp_preise_restore_v082();
        if($_POST['hbdp_action']==='price_rebuild') $hbdp_price_result=hbdp_preise_enable_and_migrate_v082();
        if($_POST['hbdp_action']==='cleanup') $hbdp_cleanup_result=hbdp_service_store_cleanup();
        if($_POST['hbdp_action']==='cleanup_undo') $hbdp_cleanup_result=hbdp_service_undo_cleanup();
        if($_POST['hbdp_action']==='create') hbdp_create_demo_posts();
        if($_POST['hbdp_action']==='draft') {
            foreach(get_posts(array('post_type'=>'post','post_status'=>'any','meta_key'=>'_hbdp_demo','meta_value'=>'1','numberposts'=>20)) as $post) wp_update_post(array('ID'=>$post->ID,'post_status'=>'draft'));
        }
        echo '<div class="notice notice-success"><p>Aktion durchgeführt.</p></div>';
    }
    if(isset($hbdp_price_result))echo '<div class="notice notice-info"><p>Preise: '.esc_html($hbdp_price_result).'</p></div>';
    if(isset($hbdp_cleanup_result))echo '<div class="notice notice-info"><p>Serviceseiten-Bereinigung: '.esc_html(wp_json_encode($hbdp_cleanup_result)).'</p></div>';
    echo '<div class="wrap"><h1>Hab &amp; Bewahr – Design</h1><p>Gestaltungsentwurf, keine Änderung an Kategorie-IDs, Slugs oder Struktur. Die vier Testbeiträge sind mit DEMO gekennzeichnet und werden auf noindex gesetzt.</p><p><a class="button button-primary" href="'.esc_url(home_url('/')).'">Startseite ansehen</a></p><form method="post">';wp_nonce_field('hbdp_control');echo '<p><button class="button" name="hbdp_action" value="create">Fehlende vier Demoartikel erstellen</button> <button class="button" name="hbdp_action" value="draft">Demoartikel als Entwurf zurückziehen</button></p></form><p>Plugin deaktivieren: ursprüngliches Theme und bisherige Anzeige erscheinen wieder. Testbeiträge können über die Schaltfläche zurückgezogen werden.</p></div>';
    hbdp_world_sponsor_admin_form();
    hbdp_area_sponsor_admin_form();
    hbdp_footer_legacy_admin_audit();
}
