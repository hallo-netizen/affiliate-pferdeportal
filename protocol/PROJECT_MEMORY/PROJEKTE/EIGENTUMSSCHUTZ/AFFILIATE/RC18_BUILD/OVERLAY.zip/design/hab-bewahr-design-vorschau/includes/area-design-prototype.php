<?php
/**
 * Hab & Bewahr: shared read-only design for the 36 second-level area pages.
 * All titles and links come from the active central WordPress navigation snapshot.
 * No WordPress post/category writes and no demo posts are created here.
 */
if (!defined('ABSPATH')) exit;

function hbdp_area_is_level2($node){
    return is_array($node) && ($node['type']??'')==='page'
        && strpos((string)($node['parent']??''),'core:world:')===0;
}
/** Kept as a compatibility alias for the existing template and plugin hooks. */
function hbdp_area_demo_is_target($node){return hbdp_area_is_level2($node);}
function hbdp_area_text_norm($s){
    $s=trim(html_entity_decode((string)$s,ENT_QUOTES,'UTF-8'));
    return function_exists('mb_strtolower')?mb_strtolower($s,'UTF-8'):strtolower($s);
}
function hbdp_area_world_content(){
    static $data=null;
    if($data!==null)return $data;
    $data=array();$file=HBDP_ROOT.'data/area-editorial-v1.json';
    if(!is_readable($file))return $data;
    $decoded=json_decode((string)file_get_contents($file),true);
    if(!is_array($decoded)||($decoded['contract']??'')!=='HBDP_AREA_EDITORIAL_V1'||count($decoded['areas']??array())!==36)return $data;
    foreach($decoded['areas'] as $row){
        if(!is_array($row)||empty($row['world'])||empty($row['name'])||empty($row['sections']))continue;
        $data[hbdp_area_text_norm($row['world']).'::'.hbdp_area_text_norm($row['name'])]=$row;
    }
    return $data;
}
function hbdp_area_spec_for($node){
    if(!hbdp_area_is_level2($node))return null;
    $parent=hbdp_node((string)$node['parent']);
    if(!$parent)return null;
    $map=hbdp_area_world_content();
    $key=hbdp_area_text_norm($parent['name']).'::'.hbdp_area_text_norm($node['name']);
    if(isset($map[$key]))return $map[$key];
    // Exact parent-scoped aliases for the actual C2.2 page titles. Fail closed
    // if unrelated new names appear; never borrow an area from another world.
    $aliases=array(
      'hitze & trockenheit'=>array('hitze','trockenheit','dürre'),
      'tier- & schädlingsschäden'=>array('tier-','schädling'),
      'pv, speicher & private ladeinfrastruktur'=>array('pv, speicher','pv und speicher'),
      'dach & gebäudehülle gegen feuchtigkeit'=>array('dach & gebäudehülle','dach und gebäudehülle'),
      'tore & zugangstechnik'=>array('tore & zugangstechnik','tore und zugangstechnik')
    );
    $world=hbdp_area_text_norm($parent['name']);$name=hbdp_area_text_norm($node['name']);
    foreach($map as $k=>$v){
        if(hbdp_area_text_norm($v['world'])!==$world)continue;
        $canonical=hbdp_area_text_norm($v['name']);
        foreach($aliases[$canonical]??array() as $alias){
            if($name===$alias)return $v;
        }
    }
    return null; // No generic, misleading editorial content for unknown nodes.
}
/** Same source and same allocation order as the card linking to this area. */
function hbdp_area_matching_world_photo($node){
    $parent=(string)($node['parent']??'');$used=array();$i=0;
    foreach(hbdp_children($parent) as $candidate){
        if(hbdp_nav_url($candidate)==='')continue;
        $photo=hbdp_world_area_unique_photo($parent,$candidate,$i++,$used);
        if(($candidate['id']??'')===($node['id']??''))return $photo;
    }
    return '';
}
function hbdp_area_photo_ok($file){
    return is_string($file) && preg_match('/^[a-z0-9-]+\.webp$/D',$file)
        && is_file(HBDP_ROOT.'assets/'.$file);
}
/** Image equivalence was checked OFFLINE; one tiny local JSON, zero image reads on frontend. */
function hbdp_area_photo_identity($file){
    static $aliases=null;
    if($aliases===null){
        $path=HBDP_ROOT.'data/area-photo-identities.json';
        $aliases=is_readable($path)?json_decode((string)file_get_contents($path),true):array();
        if(!is_array($aliases))$aliases=array();
    }
    return $aliases[$file]??$file;
}
/** All 265 documented topics plus expressly verified live-label variants, matched by exact world, area, and child label.
 *  If no reviewed subject photo exists: render a clean, honest image-free tile.
 *  No name-based keyword carousel and no unrelated last-resort area photo.
 */
function hbdp_area_topic_images(){
    static $map=null;
    if($map!==null)return $map;
    $map=array();
    $file=HBDP_ROOT.'data/area-image-mapping-v1.json';
    $data=is_readable($file)?json_decode((string)file_get_contents($file),true):array();
    if(($data['contract']??'')!=='HBDP_C23_265_TOPIC_IMAGE_AUDIT_V1' || count($data['topics']??array())!==265)return $map;
    // User-visible exact additional labels from the active category snapshot are
    // valid photo keys too. No regex, word matching or unreviewed fallback.
    $rows=array_merge($data['topics'],is_array($data['additional_exact_live_labels']??null)?$data['additional_exact_live_labels']:array());
    foreach($rows as $row){
        if(empty($row['topic'])||empty($row['world'])||empty($row['area']))continue;
        $key=hbdp_area_text_norm($row['world']).'::'.hbdp_area_text_norm($row['area']).'::'.hbdp_area_text_norm($row['topic']);
        $map[$key]=(string)($row['photo']??'');
    }
    return $map;
}
/** Targeted correction for user-reported missing/wrong images only.
 * No changes to other image choices or to the central navigation tree. */
function hbdp_named_fault_photo($spec,$topic){
    static $map=null;
    if($map===null){
        $map=array();
        $f=HBDP_ROOT.'data/hbdp-bildfehler-nur-gemeldete-themen.json';
        $d=is_readable($f)?json_decode((string)file_get_contents($f),true):array();
        if(($d['contract']??'')==='HBDP_NUR_GEMELDETE_BILDFEHLER_20261025'){
            foreach(($d['entries']??array()) as $r){
                if(!is_array($r))continue;
                $world=hbdp_area_text_norm($r['world']??'');
                $area=hbdp_area_text_norm($r['area']??'');
                $photo=(string)($r['photo']??'');
                if(!hbdp_area_photo_ok($photo))continue;
                $labels=array_merge(array((string)($r['topic']??'')),(array)($r['aliases']??array()));
                foreach($labels as $name){
                    $key=$world.'::'.$area.'::'.hbdp_fault_title_norm($name);
                    if($name!=='' && !isset($map[$key]))$map[$key]=$photo;
                }
            }
        }
    }
    $world=hbdp_area_text_norm($spec['world']??'');
    $label=hbdp_fault_title_norm($topic);
    $key=$world.'::'.hbdp_area_text_norm($spec['name']??'').'::'.$label;
    if(isset($map[$key]))return $map[$key];
    // Only exact entries of the small user-reported correction list can match an
    // alternate live area name. Never match across worlds or by loose keywords.
    $photo=null;
    foreach($map as $scoped=>$candidate){
        $parts=explode('::',$scoped,3);
        if(count($parts)!==3 || $parts[0]!==$world || $parts[2]!==$label)continue;
        if($photo!==null && $photo!==$candidate)return null; // ambiguous -> no guess
        $photo=$candidate;
    }
    return $photo;
}
function hbdp_fault_title_norm($name){
    $s=hbdp_area_text_norm($name);
    $s=str_replace(array('&','–','—','/','-'),array(' und ',' ',' ',' ',' '),$s);
    $s=preg_replace('/\s+/u',' ',trim($s));
    return $s;
}
function hbdp_area_child_photo($child,$spec,$hero,&$used){
    if(!$spec)return '';
    $key=hbdp_area_text_norm($spec['world']).'::'.hbdp_area_text_norm($spec['name']).'::'.hbdp_area_text_norm($child['name']??'');
    $map=hbdp_area_topic_images();
    // Only explicitly user-reported topics override the existing exact mapping.
    $target=hbdp_named_fault_photo($spec,$child['name']??'');
    if($target===null && !array_key_exists($key,$map))return '';
    $photo=$target!==null?$target:$map[$key];
    if(!hbdp_area_photo_ok($photo))return '';
    $identity=hbdp_area_photo_identity($photo);
    if(isset($used[$identity]))return '';
    $used[$identity]=true;
    return $photo;
}
/** Reuse exactly the R3 photograph from the real R2 card, including its
 *  parent-local no-duplicate selection. Never invent a different hero. */
function hbdp_area_matching_topic_photo($node){
    if(!is_array($node) || ($node['type']??'')!=='page')return '';
    $area=hbdp_node((string)($node['parent']??''));
    if(!hbdp_area_is_level2($area))return '';
    $spec=hbdp_area_spec_for($area);
    if(!$spec)return '';
    $used=array();
    foreach(hbdp_children($area['id']) as $child){
        if(hbdp_nav_url($child)==='')continue;
        $photo=hbdp_area_child_photo($child,$spec,'',$used);
        if(($child['id']??'')===($node['id']??''))return $photo;
    }
    return '';
}
function hbdp_area_article_term_ids($area_id){
    $all=hbdp_all_nodes();$found=array();
    foreach($all as $node){
        if(($node['type']??'')!=='category'||(int)($node['wp_id']??0)<1)continue;
        $parent=(string)($node['parent']??'');$seen=array();
        for($i=0;$i<8 && $parent!==''&&!isset($seen[$parent]);$i++){
            if($parent===$area_id){$found[(int)$node['wp_id']]=true;break;}
            $seen[$parent]=true;$parent=(string)($all[$parent]['parent']??'');
        }
    }
    return array_keys($found);
}
function hbdp_area_published_posts($area_id){
    $terms=hbdp_area_article_term_ids($area_id);if(!$terms)return array();
    return get_posts(array('post_type'=>'post','post_status'=>'publish','category__in'=>$terms,'posts_per_page'=>8,
        'orderby'=>'date','order'=>'DESC','ignore_sticky_posts'=>true,'no_found_rows'=>true,'suppress_filters'=>true));
}
function hbdp_area_article_picture($spec,$index,$tile_photos){
    $photos=array_merge(array_values($tile_photos),$spec['photos']);
    foreach($photos as $i=>$photo){if($i>=$index&&hbdp_area_photo_ok($photo))return $photo;}
    return $spec['photos'][$index%count($spec['photos'])];
}
/** Four different admin-only sample images, checked by actual image identity. */
function hbdp_area_preview_photos($spec,$tile_photos,$hero){
    $used=array(hbdp_area_photo_identity($hero)=>true);
    foreach($tile_photos as $pic){if(hbdp_area_photo_ok($pic))$used[hbdp_area_photo_identity($pic)]=true;}
    // The first two independent approved editorial pictures are already on this page.
    $count=0;
    foreach(array_merge($spec['editorial_photos']??array(),$spec['photos']??array()) as $pic){
        if(!hbdp_area_photo_ok($pic))continue;
        $identity=hbdp_area_photo_identity($pic);
        if(isset($used[$identity]))continue;
        $used[$identity]=true;
        if(++$count>=2)break;
    }
    $out=array();
    foreach($spec['photos']??array() as $pic){
        if(!hbdp_area_photo_ok($pic))continue;
        $identity=hbdp_area_photo_identity($pic);
        if(isset($used[$identity]))continue;
        $used[$identity]=true;$out[]=$pic;
        if(count($out)>=4)break;
    }
    return $out;
}
/** Existing automatic partner supply may use filters; no DB or network call. */
function hbdp_area_product_markup($node){
    $raw=apply_filters('hbdp_area_product_cards_html','',$node['id']);
    return is_string($raw)?trim(wp_kses_post($raw)):'';
}
function hbdp_area_banner_markup($node){
    $raw=apply_filters('hbdp_area_auto_banner_html','',$node['id']);
    return is_string($raw)?trim(wp_kses_post($raw)):'';
}
function hbdp_area_sponsor_for($node){
    $opts=get_option('hbdp_area_sponsors_v1',array());
    if(!is_array($opts))return array();
    $raw=$opts[$node['id']]??array();if(!is_array($raw))return array();
    $title=trim((string)($raw['title']??''));$url=trim((string)($raw['url']??''));
    if($title===''||$url===''||!wp_http_validate_url($url))return array();
    return array('title'=>$title,'url'=>$url,'description'=>trim((string)($raw['description']??'')));
}
function hbdp_area_editorial($node,$spec,$children,$used_photos,$hero){
    $manual=hbdp_hub_text_meta($node,'_hbdp_area_bottom_text');
    if($manual!==''){
        echo '<section class="hbdp-world-knowledge hbdp-area-demo-knowledge"><span class="hbdp-knowledge-eyebrow">Hintergrund &amp; Orientierung</span>'.wp_kses_post(wpautop($manual)).'</section>';
        return;
    }
    // Editorial photos belong to the same visible category page: avoid duplicates
    // with the hero AND all topic tiles; never silently use an unrelated fallback.
    $approved=array();$seen_photos=$used_photos;
    $seen_photos[hbdp_area_photo_identity($hero)]=true;
    foreach(array_merge($spec['editorial_photos']??array(),$spec['photos']??array()) as $pic){
        if(!hbdp_area_photo_ok($pic))continue;
        $identity=hbdp_area_photo_identity($pic);
        if(isset($seen_photos[$identity]))continue;
        $seen_photos[$identity]=true;$approved[]=$pic;
        if(count($approved)>=2)break;
    }
    $links=array();
    foreach($children as $child){
        $url=hbdp_nav_url($child);
        if($url!=='')$links[]=array('url'=>$url,'name'=>$child['name']);
    }
    echo '<section class="hbdp-world-knowledge hbdp-area-demo-knowledge" aria-label="Ausführliche Informationen"><span class="hbdp-knowledge-eyebrow">Hintergrund &amp; Orientierung</span>';
    echo '<div class="hbdp-editorial-heading"><h2>'.esc_html(hbdp_compass_display_name($node)).': Gefahren erkennen und passend vorsorgen</h2><p>'.esc_html($spec['intro']).'</p></div>';
    foreach($spec['sections'] as $i=>$part){
        echo '<section class="hbdp-editorial-area"><div class="hbdp-editorial-area-body"><span class="hbdp-editorial-num">'.esc_html(sprintf('%02d',$i+1)).'</span><div><h3>'.esc_html($part['title']).'</h3><p>'.esc_html($part['text']).'</p>';
        if(!empty($part['detail']))echo '<p>'.esc_html($part['detail']).'</p>';
        // Actual, currently published navigation targets only; never guess slugs.
        if($i<3 && isset($links[$i]))echo '<p class="hbdp-area-editorial-link">Vertiefung: <a href="'.esc_url($links[$i]['url']).'">'.esc_html(hbdp_category_title_without_dashes($links[$i]['name'])).' →</a></p>';
        echo '</div></div></section>';
        if(($i===1||$i===2) && isset($approved[$i-1])){
            $pic=$approved[$i-1];
            $caption=$spec['editorial_photo_titles'][$i-1]??($spec['sections'][$i]['title']??$node['name']);
            $description=$spec['editorial_captions'][$i-1]??($spec['sections'][$i]['detail']??'');
            echo '<div class="hbdp-editorial-banner hbdp-area-editorial-photo"><figure class="hbdp-editorial-figure"><img loading="lazy" decoding="async" src="'.esc_url(HBDP_URL.'assets/'.$pic).'" alt="'.esc_attr($caption).'"><figcaption><strong>'.esc_html($caption).'</strong>';
            if($description!=='')echo '<span>'.esc_html($description).'</span>';
            echo '</figcaption></figure></div>';
        }
    }
    echo '<div class="hbdp-editorial-check"><h3>Prüfpunkte für '.esc_html(hbdp_compass_display_name($node)).'</h3><ul>';
    foreach(array('Konkrete Schwachstellen am eigenen Objekt erfassen.','Ausstattung passend zur Nutzung und zu örtlichen Regeln auswählen.','Kontrolltermine, Verantwortliche und Notfallkontakte festhalten.') as $item)echo '<li>'.esc_html($item).'</li>';
    echo '</ul></div><p class="hbdp-editorial-outro">Weitere Einzelthemen und konkrete Lösungen findest du in den oben verlinkten Unterkategorien. Entscheidend ist immer der tatsächliche Zustand deines Objekts.</p></section>';
}
/** Insurance R2 areas use the SAME framed panoramic hero and picture cards as
 *  the other six worlds. No duplicate hierarchy, fake articles or new endpoints.
 *  All pages, labels and links originate from the one active central tree. */
function hbdp_render_insurance_area_page($node){
    if(!hbdp_area_is_level2($node) || (string)($node['parent']??'')!=='core:world:insurance')return;
    $hero=hbdp_insurance_area_photo($node);
    if(!hbdp_area_photo_ok($hero)){hbdp_render_area_fallback($node);return;}
    $claims=array(
        'Hausrat & Gebäude'=>'Schutz für Hausrat, Wohngebäude und Bauvorhaben.',
        'Fahrzeuge & Reisen'=>'Versicherungsschutz für Mobilität, Reisen und Freizeit.',
        'Haftpflicht & Rechtsschutz'=>'Schutz bei Haftungsfragen und Rechtsstreitigkeiten.',
        'Krankenversicherung & Vorsorge'=>'Gesundheit, Arbeitskraft und Altersvorsorge absichern.',
        'Gewerbeversicherungen & Finanzen'=>'Versicherungen für kleine Betriebe und finanzielle Risiken.'
    );
    $claim=$claims[(string)$node['name']]??'Versicherungen, Leistungen und Schutz im Überblick.';
    $children=array();
    foreach(hbdp_children($node['id']) as $child){
        if(($child['type']??'')==='page' && hbdp_nav_url($child)!=='')$children[]=$child;
    }
    $used=array(hbdp_area_photo_identity($hero)=>true);
    echo '<main class="hbdp-area-demo hbdp-area-page hbdp-insurance-area-page">';
    echo '<div class="hbdp-frame hbdp-area-demo-breadcrumb-top">';hbdp_breadcrumb($node);echo '</div>';
    echo '<div class="hbdp-frame hbdp-area-demo-hero-frame"><header class="hbdp-area-demo-hero">';
    echo '<img src="'.esc_url(HBDP_URL.'assets/'.$hero).'" alt="" decoding="async" fetchpriority="high">';
    echo '<div class="hbdp-area-demo-shade" aria-hidden="true"></div><div class="hbdp-area-demo-hero-text">';
    echo '<span class="hbdp-area-demo-eyebrow">Versicherungen · Schutzbereich</span>';
    echo '<h1>'.esc_html(hbdp_compass_display_name($node)).'</h1><p>'.esc_html($claim).'</p>';
    echo '</div></header></div>';
    echo '<div class="hbdp-frame hbdp-area-demo-inner"><section class="hbdp-area-demo-section" aria-label="Versicherungsthemen">';
    echo '<div class="hbdp-area-demo-heading"><h2>Versicherungsthemen entdecken</h2><p>'.esc_html($claim).'</p></div>';
    $banner=hbdp_area_banner_markup($node);
    $insurance_count=count($children);
    $insurance_span=$insurance_count%3===0?3:3-($insurance_count%3);
    echo '<div class="hbdp-area-demo-topics">';
    foreach($children as $child){
        $pic=hbdp_insurance_topic_photo($child);
        if($pic!=='' && isset($used[hbdp_area_photo_identity($pic)]))$pic='';
        if($pic!=='')$used[hbdp_area_photo_identity($pic)]=true;
        echo '<a class="hbdp-area-demo-topic'.($pic===''?' hbdp-area-topic-noimage':'').'" href="'.esc_url(hbdp_nav_url($child)).'">';
        if($pic!=='')echo '<img src="'.esc_url(HBDP_URL.'assets/'.$pic).'" alt="" loading="lazy" decoding="async">';
        echo '<span class="hbdp-area-demo-topic-label"><strong>'.esc_html(hbdp_compass_display_name($child)).'</strong><span class="hbdp-area-demo-topic-go" aria-hidden="true">→</span></span></a>';
    }
    if($banner!=='' && $insurance_count>0){
        echo '<div class="hbdp-area-inline-ad-tile hbdp-area-inline-desktop-'.(int)$insurance_span.' hbdp-area-inline-tablet-'.($insurance_count%2===0?2:1).'" aria-label="Amazon-Themenempfehlung">'.$banner.'</div>';
    }
    echo '</div></section>';
    $product=hbdp_area_product_markup($node);
    if($product!=='')echo '<section class="hbdp-area-demo-section" aria-label="Passende Schutzprodukte"><div class="hbdp-area-demo-heading"><h2>Passende Schutzprodukte</h2></div><div class="hbdp-area-demo-live-products">'.$product.'</div></section>';
    if($banner!=='' && $insurance_count===0)echo '<section class="hbdp-area-demo-ad" aria-label="Affiliate-Bannerplatz">'.$banner.'</section>';
    // Neither a blue external Magazin/Dienstleister shortcut row nor invented article previews.
    echo '</div></main>';
}

function hbdp_render_area_page($node){
    if(!hbdp_area_is_level2($node))return;
    if((string)($node['parent']??'')==='core:world:insurance'){hbdp_render_insurance_area_page($node);return;}
    $spec=hbdp_area_spec_for($node);
    if(!$spec){
        // Unknown future area: keep normal hub so public never gets the wrong editorial.
        hbdp_render_area_fallback($node);return;
    }
    $hero=hbdp_area_matching_world_photo($node);
    if(!hbdp_area_photo_ok($hero)){hbdp_render_area_fallback($node);return;}
    $world=hbdp_node($node['parent']);
    $children=array();foreach(hbdp_children($node['id']) as $child){
        if(($child['id']??'')!==$node['id']&&hbdp_nav_url($child)!=='')$children[]=$child;
    }
    // The hero is visible on this SAME page and therefore reserves its photo identity.
    $tile_photos=array();$used=array(hbdp_area_photo_identity($hero)=>true);
    // Only the two explicitly reported subjects receive first claim on their own
    // distinct photo. This protects the affected tiles from sibling allocation order.
    $priority_names=array(
        'Insekten im Haus', 'Insekten im Haus & Garten',
        'Regenabdichtung am Freizeitfahrzeug'
    );
    foreach($children as $child){
        if(!in_array((string)($child['name']??''),$priority_names,true))continue;
        $pic=hbdp_named_fault_photo($spec,$child['name']);
        if(!hbdp_area_photo_ok($pic))continue;
        $identity=hbdp_area_photo_identity($pic);
        if(isset($used[$identity]))continue; // Never show the same image twice.
        $tile_photos[$child['id']]=$pic;$used[$identity]=true;
    }
    foreach($children as $child){
        if(isset($tile_photos[$child['id']]))continue;
        $tile_photos[$child['id']]=hbdp_area_child_photo($child,$spec,$hero,$used);
    }
    $magazine=hbdp_startseite_urls()['magazine']??'';
    $product_markup=hbdp_area_product_markup($node);
    $banner=hbdp_area_banner_markup($node);
    $sponsor=hbdp_area_sponsor_for($node);
    $admin=current_user_can('manage_options');
    // Only the ALREADY EXISTING area banner may fill an incomplete topic grid.
    // Number of real cards controls the last free space at each breakpoint.
    $topic_count=count($children);
    // RC18: existing topic banner is available even for full rows (3, 6, 9 ...).
    $inline_banner=($banner!=='' && $topic_count>0);
    $remainder=$topic_count%3;
    $inline_desktop_span=$remainder===0?3:3-$remainder;
    $inline_tablet_span=$topic_count%2===0?2:1;
    // Place after a complete row when possible, even at the tablet breakpoint.
    $inline_position=$remainder===0?min($topic_count,($topic_count%2===0 && $topic_count>=6?6:3))
        :min($topic_count,3+$remainder);
    ?>
    <main class="hbdp-area-demo hbdp-area-page">
      <div class="hbdp-frame hbdp-area-demo-breadcrumb-top"><?php hbdp_breadcrumb($node); ?></div>
      <div class="hbdp-frame hbdp-area-demo-hero-frame">
        <header class="hbdp-area-demo-hero">
          <img src="<?php echo esc_url(HBDP_URL.'assets/'.$hero); ?>" alt="" fetchpriority="high" decoding="async">
          <div class="hbdp-area-demo-shade" aria-hidden="true"></div>
          <div class="hbdp-area-demo-hero-text">
            <span class="hbdp-area-demo-eyebrow"><?php echo esc_html(hbdp_compass_display_name($world)); ?> · Schutzbereich</span>
            <h1><?php echo esc_html(hbdp_compass_display_name($node)); ?></h1>
            <p><?php echo esc_html($spec['claim']); ?></p>
          </div>
        </header>
      </div>
      <div class="hbdp-frame hbdp-area-demo-inner">
        <section class="hbdp-area-demo-section" aria-label="Unterkategorien">
          <div class="hbdp-area-demo-heading"><h2>Schutzthemen entdecken</h2><p><?php echo esc_html($spec['claim']); ?></p></div>
          <div class="hbdp-area-demo-topics">
          <?php $tile_position=0; foreach($children as $child): $pic=$tile_photos[$child['id']]??''; ?>
            <a class="hbdp-area-demo-topic<?php echo !$pic?' hbdp-area-topic-noimage':''; ?>" href="<?php echo esc_url(hbdp_nav_url($child)); ?>">
              <?php if($pic): ?><img src="<?php echo esc_url(HBDP_URL.'assets/'.$pic); ?>" alt="" loading="lazy" decoding="async"><?php endif; ?>
              <span class="hbdp-area-demo-topic-label"><strong><?php echo esc_html(hbdp_compass_display_name($child)); ?></strong><span class="hbdp-area-demo-topic-go" aria-hidden="true">→</span></span>
            </a>
          <?php $tile_position++; if($inline_banner && $tile_position===$inline_position): ?>
            <div class="hbdp-area-inline-ad-tile hbdp-area-inline-desktop-<?php echo (int)$inline_desktop_span; ?> hbdp-area-inline-tablet-<?php echo (int)$inline_tablet_span; ?>" aria-label="Amazon-Themenempfehlung">
              <?php echo $banner; ?>
            </div>
          <?php endif; endforeach; ?>
          </div>
        </section>
        <?php if($product_markup!=='' || $admin): ?>
        <section class="hbdp-area-demo-section" aria-label="Passende Schutzprodukte">
          <div class="hbdp-area-demo-heading"><h2>Passende Schutzprodukte</h2></div>
          <?php if($product_markup!==''): ?><div class="hbdp-area-demo-live-products"><?php echo $product_markup; ?></div>
          <?php else: ?><div class="hbdp-area-demo-products">
            <?php foreach($spec['products'] as $label): ?><div class="hbdp-area-demo-product"><span class="hbdp-area-demo-product-symbol" aria-hidden="true">◇</span><strong><?php echo esc_html($label); ?></strong><small>Nur Admin · Layoutplatz</small></div><?php endforeach; ?>
          </div><?php endif; ?>
        </section>
        <?php endif; ?>
        <?php if((!$inline_banner && $banner!=='') || ($admin && !$inline_banner)): ?>
        <section class="hbdp-area-demo-ad" aria-label="Affiliate-Bannerplatz">
          <?php if($banner!=='')echo '<small>ANZEIGE · AFFILIATE</small>'. $banner;
          else echo '<small>Nur Admin · automatischer Affiliate-Banner</small><span>Leer – öffentlich nicht sichtbar.</span>'; ?>
        </section><?php endif; ?>
        <?php
          $posts=hbdp_area_published_posts($node['id']);$articles=array();
          foreach($posts as $post){
              if(get_post_meta($post->ID,'_hbdp_demo',true)==='1')continue;
              if(!trim((string)get_the_title($post)))continue;
              $articles[]=$post;if(count($articles)>=4)break;
          }
          // Visitor: real published posts only; no fake article links or placeholders.
          // Admin: four read-only visual test cards if no real posts yet.
          if($articles || $admin):
        ?>
        <section class="hbdp-area-demo-reading hbdp-area-demo-section" aria-label="Ratgeber">
          <div class="hbdp-area-demo-heading"><h2>Ratgeber &amp; Tipps</h2></div>
          <div class="hbdp-area-demo-article-grid">
          <?php $preview_photos=$admin ? hbdp_area_preview_photos($spec,$tile_photos,$hero):array(); ?>
          <?php if($articles):foreach($articles as $i=>$post): ?>
            <article class="hbdp-area-demo-article"><a class="hbdp-area-article-real-link" href="<?php echo esc_url(get_permalink($post->ID)); ?>">
              <?php if(has_post_thumbnail($post->ID)) echo get_the_post_thumbnail($post->ID,'medium_large',array('loading'=>'lazy','decoding'=>'async'));
              else echo '<img src="'.esc_url(HBDP_URL.'assets/'.hbdp_area_article_picture($spec,$i,$tile_photos)).'" alt="" loading="lazy">'; ?>
              <div class="hbdp-area-demo-article-body"><small>Ratgeber</small><strong><?php echo esc_html(get_the_title($post)); ?></strong><span>Beitrag lesen →</span></div></a></article>
          <?php endforeach;elseif($admin):for($i=0;$i<4;$i++):
            $label=$spec['products'][$i];$pic=$preview_photos[$i]??'';
            $tag=isset($children[$i%max(1,count($children))])?$children[$i%count($children)]['name']:$node['name'];
            $demo_titles=array('Worauf du bei '.$label.' achten solltest','Welche Lösung eignet sich für '.$tag.'?','Häufige Fehler bei '.$node['name'].' vermeiden','Checkliste für '. $node['name']);
          ?>
            <article class="hbdp-area-demo-article"><?php if($pic): ?><img src="<?php echo esc_url(HBDP_URL.'assets/'.$pic); ?>" alt="" loading="lazy" decoding="async"><?php endif; ?>
              <div class="hbdp-area-demo-article-body"><small><?php echo esc_html($tag); ?></small><strong><?php echo esc_html($demo_titles[$i]); ?></strong><p>Beispielartikel zur optischen Vorschau.</p><span>DEMO · Kein Beitrag</span></div></article>
          <?php endfor;endif; ?>
          </div>
        </section>
        <?php endif; ?>
        <?php if($magazine!==''): ?>
          <a class="hbdp-area-demo-magazine" href="<?php echo esc_url($magazine); ?>"><strong>Mehr Wissen im Magazin</strong><span>Weitere Ratgeber &amp; Hintergründe →</span></a>
        <?php endif; ?>
        <?php if($sponsor||$admin): ?>
          <section class="hbdp-area-demo-sponsor" aria-label="Vermietbare Werbefläche">
            <?php if($sponsor): ?><small>ANZEIGE · WERBEPARTNER</small><strong><?php echo esc_html($sponsor['title']); ?></strong>
              <?php if($sponsor['description']!=='')echo '<span>'.esc_html($sponsor['description']).'</span>'; ?>
              <a href="<?php echo esc_url($sponsor['url']); ?>" target="_blank" rel="sponsored noopener noreferrer">Angebot ansehen →</a>
            <?php else: ?><small>Nur Admin · vermietbare Werbefläche</small><span>Noch nicht gebucht. Öffentlich verborgen.</span><?php endif; ?>
          </section>
        <?php endif; ?>
        <?php hbdp_area_editorial($node,$spec,$children,$used,$hero); ?>
      </div>
    </main>
    <?php
}
/** Exact old page renderer for unknown future areas; preserve editorial instead of wrong copy. */
function hbdp_render_area_fallback($node){
    echo '<main class="hbdp-frame hbdp-section hbdp-hub">';
    hbdp_breadcrumb($node);
    echo '<h1>'.esc_html(hbdp_compass_display_name($node)).'</h1>';
    // The R2 hub shows exactly the image used on its parent-world category tile.
    $insurance_area=hbdp_insurance_area_photo($node);
    if($insurance_area!=='')echo '<figure class="hbdp-focus-destination-photo"><img src="'.esc_url(HBDP_URL.'assets/'.$insurance_area).'" alt="'.esc_attr(hbdp_compass_display_name($node)).'" fetchpriority="high" decoding="async"></figure>';
    hbdp_render_category_top_text($node);
    echo '<div class="hbdp-grid">';
    foreach(hbdp_children($node['id']) as $child)if(hbdp_nav_url($child)!=='')hbdp_display_card($child);
    echo '</div></main>';
}
/** Native settings for paid per-area slots; one option, no new database table. */
function hbdp_area_sponsor_admin_save(){
    if(!isset($_POST['hbdp_save_area_sponsors']))return;
    if(!current_user_can('manage_options')||!check_admin_referer('hbdp_area_sponsors_save'))wp_die('Keine Berechtigung');
    $input=is_array($_POST['hbdp_area_sponsors']??null)?wp_unslash($_POST['hbdp_area_sponsors']):array();
    $clean=array();
    foreach(hbdp_all_nodes() as $node){
        if(!hbdp_area_is_level2($node))continue;
        $raw=$input[$node['id']]??array();if(!is_array($raw))continue;
        $title=sanitize_text_field($raw['title']??'');$url=esc_url_raw($raw['url']??'');
        $desc=sanitize_textarea_field($raw['description']??'');
        if($title!==''&&$url!==''&&wp_http_validate_url($url))$clean[$node['id']]=array('title'=>$title,'description'=>$desc,'url'=>$url);
    }
    update_option('hbdp_area_sponsors_v1',$clean,false);
    echo '<div class="notice notice-success"><p>Bereichs-Werbeflächen gespeichert.</p></div>';
}
function hbdp_area_sponsor_admin_form(){
    if(!current_user_can('manage_options'))return;
    $saved=get_option('hbdp_area_sponsors_v1',array());if(!is_array($saved))$saved=array();
    echo '<details class="wrap" style="margin:22px 0"><summary><strong>Vermietbare Werbeflächen · 36 Bereiche</strong></summary><form method="post">';
    wp_nonce_field('hbdp_area_sponsors_save');
    foreach(hbdp_all_nodes() as $node){
        if(!hbdp_area_is_level2($node))continue;
        $v=$saved[$node['id']]??array();$id=esc_attr($node['id']);
        echo '<fieldset style="max-width:680px;padding:10px;margin:12px 0;border:1px solid #ddd"><legend>'.esc_html(hbdp_compass_display_name($node)).'</legend>';
        foreach(array('title'=>'Überschrift','description'=>'Kurztext','url'=>'Ziel-URL') as $key=>$label)
            echo '<p><label>'.esc_html($label).'<br><input style="width:100%" name="hbdp_area_sponsors['.$id.']['.$key.']" value="'.esc_attr((string)($v[$key]??'')).'"></label></p>';
        echo '</fieldset>';
    }
    echo '<button type="submit" class="button button-primary" name="hbdp_save_area_sponsors" value="1">Bereichsflächen speichern</button></form></details>';
}
