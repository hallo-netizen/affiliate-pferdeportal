<?php
/* Full-source Hab adapter + Amazon worker simulated WordPress integration. No network/costs. */
error_reporting(E_ALL);
ini_set('display_errors','1');
define('ABSPATH','/'); define('DAY_IN_SECONDS',86400);define('HOUR_IN_SECONDS',3600);
$GLOBALS['opts']=[]; $GLOBALS['filters']=[]; $GLOBALS['actions']=[]; $GLOBALS['remote']=[]; $GLOBALS['posts']=[]; $GLOBALS['termmap']=[]; $GLOBALS['post_meta']=[]; $GLOBALS['transients']=[]; $GLOBALS['clock']=['cron'=>null];$GLOBALS['scenario']=$argv[1] ?? 'valid';$GLOBALS['assertions']=0;
function pass($bool,$label){$GLOBALS['assertions']++;if(!$bool){fwrite(STDERR,'FAIL '.$label."\n");exit(2);}echo 'PASS '.$label."\n";}
function get_option($key,$default=false){return array_key_exists($key,$GLOBALS['opts'])?$GLOBALS['opts'][$key]:$default;}
function update_option($key,$v,$autoload=false){$GLOBALS['opts'][$key]=$v;return true;}
function absint($x){return abs((int)$x);}function sanitize_key($v){return strtolower(preg_replace('/[^a-z0-9_\-]/','',(string)$v));}
function sanitize_text_field($v){return strip_tags((string)$v);}function remove_accents($s){return strtr($s,['ä'=>'a','ö'=>'o','ü'=>'u','ß'=>'ss','Ä'=>'A','Ö'=>'O','Ü'=>'U']);}
function sanitize_title($s){$s=strtolower(remove_accents((string)$s));return trim(preg_replace('/[^a-z0-9]+/','-',$s),'-');}
function wp_json_encode($v){return json_encode($v,JSON_UNESCAPED_UNICODE);}function is_wp_error($v){return $v instanceof WP_Error;}
function get_post($id){return $GLOBALS['posts'][$id]??null;}
function get_post_status($id){$p=get_post((int)$id);return is_object($p)?$p->post_status:'';}
function get_post_type($id){$p=get_post((int)$id);return is_object($p)?$p->post_type:'';}
function get_post_meta($id,$key,$single=true){return $GLOBALS['post_meta'][$id][$key]??null;}
function get_the_terms($id,$taxonomy){return array_map(static fn($slug)=>(object)['slug'=>$slug],$GLOBALS['termmap'][$id]??[]);}
function get_posts($args){$all=array_values(array_filter($GLOBALS['posts'],static fn($p)=>$p->post_type===($args['post_type']??'post') && $p->post_status===($args['post_status']??'publish')));usort($all,static fn($a,$b)=>$a->ID<=>$b->ID);return array_slice($all,(int)($args['offset']??0),(int)($args['posts_per_page']??100));}
function add_filter($hook,$cb,$priority=10,$accepted_args=1){$GLOBALS['filters'][$hook][]=$cb;}
function apply_filters($hook,$value,...$more){foreach($GLOBALS['filters'][$hook]??[] as $cb){$value=call_user_func($cb,$value,...$more);}return $value;}
function add_action($hook,$cb,$priority=10,$accepted_args=1){$GLOBALS['actions'][$hook][]=$cb;}
function get_transient($k){return $GLOBALS['transients'][$k]??false;}function set_transient($k,$v,$ttl){$GLOBALS['transients'][$k]=$v;}function delete_transient($k){unset($GLOBALS['transients'][$k]);}
function wp_next_scheduled($hook){return $GLOBALS['clock']['cron'];}function wp_schedule_event($start,$period,$hook){$GLOBALS['clock']['cron']=$start;return true;}function wp_clear_scheduled_hook($hook){$GLOBALS['clock']['cron']=null;}
function wp_remote_request($url,$args){$GLOBALS['remote'][]=['url'=>$url,'args'=>$args];
 if(str_contains($url,'task_post')){
  if($GLOBALS['scenario']==='api_403')return ['code'=>403,'body'=>'Forbidden'];
  if($GLOBALS['scenario']==='task_error')return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>40501,'status_message'=>'Unknown merchant location','id'=>null]]])];
  return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>20100,'id'=>'12345678-1234-1234-1234-123456789abc']]])];
 }
 if($GLOBALS['scenario']==='get_pending' && count(array_filter($GLOBALS['remote'],static fn($e)=>str_contains($e['url'],'task_get')))<2){return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>20100,'result'=>null]]])];}
 if($GLOBALS['scenario']==='get_error'){return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>40501,'status_message'=>'DataForSEO task failed','result'=>null]]])];}
 return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>20000,'result'=>[['items'=>[
   ['type'=>'amazon_serp','url'=>'https://www.amazon.de/dp/B011111111','title'=>'Wassermelder Smart Funk Sensor','data_asin'=>'B011111111','price_from'=>24.99],
   ['type'=>'amazon_paid','url'=>'https://www.amazon.de/dp/B088888888','title'=>'Wassermelder Anzeige','data_asin'=>'B088888888'],
   ['type'=>'amazon_serp','url'=>'https://www.amazon.com/dp/B033333333','title'=>'Wassermelder fremd','data_asin'=>'B033333333'],
   ['type'=>'amazon_serp','url'=>'https://www.amazon.de/dp/B022222222','title'=>'Wassermelder Kabel Alarm','data_asin'=>'B022222222'],
   ['type'=>'amazon_serp','url'=>'https://www.amazon.de/dp/B044444444','title'=>'Rauchmelder Smart','data_asin'=>'B044444444']
 ]]]]]])];
}
function wp_remote_retrieve_response_code($r){return $r['code'];}function wp_remote_retrieve_body($r){return $r['body'];}
function wp_parse_url($v,$part){return parse_url($v,$part);}function esc_url($v){return htmlspecialchars($v,ENT_QUOTES);}function esc_html($v){return htmlspecialchars($v,ENT_QUOTES);}
function esc_attr($v){return htmlspecialchars($v,ENT_QUOTES);}function checked($a,$b=true,$echo=true){$v=($a==$b)?'checked="checked"':'';if($echo)echo $v;return $v;}
function wp_date($format,$time){return date($format,$time);}function current_user_can($cap){return true;}
function wp_nonce_field($action,$name){echo '<input name="'.$name.'" value="test_nonce">';}function admin_url($s){return 'https://example.test/wp-admin/'.$s;}
class WP_Error{private $code,$message;function __construct($code,$message){$this->code=$code;$this->message=$message;}function get_error_message(){return $this->message;}function get_error_code(){return $this->code;}}
function build_snapshot($case){$nodes=[];$mapping=[];$push=function($key,$type,$id,$name,$parent,$pillar='core') use (&$nodes,&$mapping){$slug=sanitize_title($name);$nodes[]=['node_id'=>$key,'parent_id'=>$parent,'object_type'=>$type,'pillar'=>$pillar,'name'=>$name,'slug'=>$slug];$mapping[$key]=['object_type'=>$type,'object_id'=>$id];if($type==='page')$GLOBALS['posts'][$id]=(object)['ID'=>$id,'post_type'=>'page','post_status'=>'publish','post_title'=>$name];};
 $push('core:hub','page',1,'Hab und Bewahr','','core');
 $world_count=$case==='six_worlds'?6:($case==='eight_worlds'?8:7);
 for($i=1;$i<=$world_count;$i++){
  $key=$i===7?'core:world:insurance':($i===8?'core:world:future':'core:world:'.$i);
  $name=$i===7?'Versicherungen':($i===8?'Weitere Schutzwelt':'Welt '.$i);
  $push($key,'page',10+$i,$name,'core:hub');
 }
 for($i=1;$i<=40;$i++){
  $world='core:world:'.((($i-1)%6)+1);$area='core:area:'.$i;$push($area,'page',100+$i,'Bereich '.$i,$world);
  $topic='core:c22:topic:'.$i;
  $topic_name=$i===1?'Leckwarnung & Absperrung':($i===2?'Brandschutz & Löschmittel':($i===3?'Wertsachen & Schadenfall':'Sicherheitsfragen '.$i));
  $push($topic,'page',500+$i,$topic_name,$area);
  $label=($i===1?'Wassermelder':($i===2?'Rauchmelder / Vernetzung':($i===3?'Tresor & Versicherungsschutz':'Allgemeine Beratung '.$i)));
  if($case==='no_products')$label='Allgemeine Beratung '.$i;
  $push('core:category:'.$i,'category',200+$i,$label,$topic);
 }
 // Real-world scale from the admin evidence: 2,720 source nodes, of which
 // 2,714 are mapped. The six unmapped categories must not veto valid worlds.
 $next=1000;
 while(count($nodes)<2720){$idx=count($nodes);$push('core:c23:category:'.$idx,'category',$next++,'Beratung & Grundlagen '.$idx,'core:c22:topic:'.(($idx%40)+1));}
 if($case==='unmapped_insurance')unset($mapping['core:world:insurance']);
 $missing=$case==='unmapped_insurance'?5:6;
 for($i=0;$i<$missing;$i++){ $key=$nodes[count($nodes)-1-$i]['node_id'];unset($mapping[$key]); }
 if($case==='too_few'){$nodes=array_slice($nodes,0,20);$mapping=array_intersect_key($mapping,array_flip(array_column($nodes,'node_id')));}
 $rev='2026-11-07-hb';return ['revision'=>$rev,'nodes'=>$nodes,'mapping'=>$mapping];
}

function register_activation_hook($f,$cb){} function register_deactivation_hook($f,$cb){}
function post_type_exists($t){return true;} function add_shortcode($name,$cb){} function is_admin(){return $GLOBALS['is_admin']??true;} function is_feed(){return false;} function is_preview(){return false;} function is_category(){return true;} function get_queried_object(){return (object)['term_id'=>201,'slug'=>'wassermelder','name'=>'Wassermelder','description'=>''];} class WP_Query{public function is_main_query(){return true;}} function get_ancestors($id,$taxonomy){return [];} function get_the_title($id){return get_post($id)->post_title??'';} function get_post_field($key,$id){$p=get_post($id);return $key==='post_name'?sanitize_title($p->post_title??''):'';} function get_post_ancestors($id){return [];} function wp_strip_all_tags($v){return strip_tags($v);}
$scenario=$GLOBALS['scenario'];
if($scenario!=='missing_snapshot'){$snapshot=build_snapshot($scenario);$GLOBALS['opts']['apkw_target_tree_active_snapshot_v1']=$snapshot;$GLOBALS['opts']['apkw_target_tree_active_revision_v1']=$scenario==='wrong_revision'?'other':$snapshot['revision'];}
$GLOBALS['opts']['ppar_enabled']='1';
$GLOBALS['opts']['ppar_hab_amazon_settings_v1']=['enabled'=>true,'tag'=>'habundbewahr-21','dfs_enabled'=>true,'login'=>'api-test','password'=>'fake'];
require dirname(__DIR__).'/../hab_affiliate_rc8/affiliate-portal-router/affiliate-portal-router.php';
$app=Portal_Affiliate_Router::instance();
pass(in_array('admin_post_ppar_hb_amazon_run',array_keys($GLOBALS['actions']),true),'real full plugin registers manual run');
$cat=PPAR_Portal_Source::catalog();
if(is_wp_error($cat)){echo 'RC8_ORIGINAL_BLOCKER '.$cat->get_error_code().' '. $cat->get_error_message().PHP_EOL;exit(0);}

if(!in_array($scenario,['missing_snapshot','wrong_revision','no_products','too_few'],true)){
 $snap=get_option('apkw_target_tree_active_snapshot_v1',[]);pass(count($snap['nodes'])===2720,'real-scale 2720 snapshot nodes');
 pass(count($snap['mapping'])===2714,'real-scale 2714 mapped nodes');
}

if(in_array($scenario,['missing_snapshot','wrong_revision','no_products','too_few'],true)){
 pass(is_wp_error($cat),'real source adapter rejects invalid active tree');
 $app->hb_amazon_dfs_tick();
 $c=get_option('ppar_hab_amazon_dfs_control_v1',[]);
 pass(count($GLOBALS['remote'])===0,'No paid DataForSEO traffic on invalid catalog');
 pass(str_contains($c['message'],'BLOCKIERT:'),'Root cause visible in status instead of no matching products');
 ob_start();$app->hb_amazon_render_settings();$html=ob_get_clean();
 pass(str_contains($html,'Suchlauf-Status:')&&str_contains($html,'BLOCKIERT'),'Blocker prominent at top of actual admin screen');
 echo 'REAL_BLOCKER '.($c['message'])."\n";
 exit;
}
pass(is_array($cat)&&count((array)($cat['product_targets']??[]))===3,'real whole plugin produces Hab target families');
pass(($cat['counts']['worlds']??0)===($scenario==='six_worlds'?6:($scenario==='eight_worlds'?8:($scenario==='unmapped_insurance'?6:7))),'world count follows active mapped structure, not hard-coded six');
pass(($cat['counts']['main_hubs']??0)===($cat['counts']['worlds']??0),'main hub count matches actual worlds');
pass(($cat['counts']['article_categories']??0)>=2000,'all mapped core article categories stay available');
$app->hb_amazon_dfs_tick();
$c=get_option('ppar_hab_amazon_dfs_control_v1',[]);
pass(count($GLOBALS['remote'])===1,'full plugin first worker posts provider task');
$app->hb_amazon_dfs_tick();
$c=get_option('ppar_hab_amazon_dfs_control_v1',[]);
pass(count((array)($c['category_products']['wassermelder']['items']??[]))===2,'full plugin stores matched category ASINs');
ob_start();$app->hb_amazon_render_settings();$html=ob_get_clean();
pass(str_contains($html,'Jetzt einen Suchlauf starten'),'actual admin page includes start button');
pass(str_contains($html,'Gespeicherte Amazon-Einzelproduktlinks'),'actual admin page exposes found count');
pass(str_contains($html,'von 5'),'actual admin page exposes budget');
$r=new ReflectionClass($app);$m=$r->getMethod('get_category_archive_context');$m->setAccessible(true);
$context=$m->invoke($app,(object)['term_id'=>201,'slug'=>'wassermelder','name'=>'Wassermelder','description'=>'']);
pass(($context['post_type']??'')==='category_archive','real WP category context shape recognized');
$m=$r->getMethod('get_category_slots');$m->setAccessible(true);
pass($m->invoke($app)===[],'real admin category slots default are empty');
$GLOBALS['is_admin']=false;ob_start();$app->auto_inject_category_archive_slots(new WP_Query());$category_html=ob_get_clean();
pass(str_contains($category_html,'/dp/B011111111?tag=habundbewahr-21'),'real WP category loop_end emits tracked Amazon ASIN');
pass(str_contains($category_html,'data-ppar-slot="category_recommendation"'),'renders via existing category_recommendation slot');
pass(substr_count($category_html,'ppar-hab-amazon-search')===1,'no duplicate category ad');
$area = $r->getMethod('hb_amazon_area_product_fallback');$area->setAccessible(true);
$area_html=$area->invoke($app,501);
pass(str_contains($area_html,'/dp/B011111111?tag=habundbewahr-21'),'actual project page mapping finds product category even without any articles');
pass(str_contains($area_html,'data-ppar-slot="category_product_1"'),'area category product uses original page product slot');
$real_area=$app->hab_bw_area_slot(501,'products');
pass(str_contains($real_area,'/dp/B011111111?tag=habundbewahr-21'),'real R3 topic page design bridge renders Amazon category product');
$design=apply_filters('hbdp_area_product_cards_html','','core:c22:topic:1');
pass(str_contains($design,'/dp/B011111111?tag=habundbewahr-21'),'actual original design filter emits approved Amazon product');
pass(apply_filters('hbdp_area_product_cards_html','<div>Bestehende Werbung</div>','core:c22:topic:1')==='<div>Bestehende Werbung</div>','existing design/affiliate content has priority');
$GLOBALS['opts']['ppar_enabled']='0';
pass(apply_filters('hbdp_area_product_cards_html','','core:c22:topic:1')==='','central affiliate off prevents ad output');
$GLOBALS['opts']['ppar_enabled']='1';
$GLOBALS['is_admin']=true;
pass($app->hab_bw_article_slot(552,'products')==='','draft article not advertised');
echo 'FULL_PLUGIN_ASSERTIONS '.$GLOBALS['assertions']."\n";
