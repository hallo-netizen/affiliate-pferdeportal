<?php
/* Full-source Hab adapter + Amazon worker simulated WordPress integration. No network/costs. */
error_reporting(E_ALL);
ini_set('display_errors','1');
define('ABSPATH','/'); define('DAY_IN_SECONDS',86400);define('HOUR_IN_SECONDS',3600);
$GLOBALS['opts']=[]; $GLOBALS['filters']=[]; $GLOBALS['actions']=[]; $GLOBALS['remote']=[]; $GLOBALS['posts']=[]; $GLOBALS['termmap']=[]; $GLOBALS['post_meta']=[]; $GLOBALS['transients']=[]; $GLOBALS['clock']=['cron'=>null];$GLOBALS['scenario']=$argv[1] ?? 'valid';$GLOBALS['assertions']=0;
function pass($bool,$label){$GLOBALS['assertions']++;if(!$bool){fwrite(STDERR,'FAIL '.$label."\n");exit(2);}echo 'PASS '.$label."\n";}
function get_option($key,$default=false){return array_key_exists($key,$GLOBALS['opts'])?$GLOBALS['opts'][$key]:$default;}
function update_option($key,$v,$autoload=false){$GLOBALS['opts'][$key]=$v;return true;}
function absint($x){return abs((int)$x);}function sanitize_key($v){return strtolower(preg_replace('/[^a-z0-9_\-]/','',(string)$v));}
function sanitize_text_field($v){return strip_tags((string)$v);}function remove_accents($s){return strtr($s,['ä'=>'a','ö'=>'o','ü'=>'u','ß'=>'ss','Ä'=>'A','Ö'=>'O','Ü'=>'U']);}
function sanitize_title($s){$s=strtolower(remove_accents((string)$s));return trim(preg_replace('/[^a-z0-9]+/','-',$s),'-');}
function wp_json_encode($v){return json_encode($v,JSON_UNESCAPED_UNICODE);}function is_wp_error($v){return $v instanceof WP_Error;}
function get_post($id){return $GLOBALS['posts'][$id]??null;}
function get_post_status($id){$p=get_post((int)$id);return is_object($p)?$p->post_status:'';}
function get_post_type($id){$p=get_post((int)$id);return is_object($p)?$p->post_type:'';}
function get_post_meta($id,$key,$single=true){return $GLOBALS['post_meta'][$id][$key]??null;}
function get_the_terms($id,$taxonomy){return array_map(static fn($slug)=>(object)['slug'=>$slug],$GLOBALS['termmap'][$id]??[]);}
function get_posts($args){$all=array_values(array_filter($GLOBALS['posts'],static fn($p)=>$p->post_type===($args['post_type']??'post') && $p->post_status===($args['post_status']??'publish')));usort($all,static fn($a,$b)=>$a->ID<=>$b->ID);return array_slice($all,(int)($args['offset']??0),(int)($args['posts_per_page']??100));}
function add_filter($hook,$cb,$priority=10,$accepted_args=1){$GLOBALS['filters'][$hook][]=$cb;}
function apply_filters($hook,$value,...$more){foreach($GLOBALS['filters'][$hook]??[] as $cb){$value=call_user_func($cb,$value,...$more);}return $value;}
function add_action($hook,$cb,$priority=10,$accepted_args=1){$GLOBALS['actions'][$hook][]=$cb;}
function get_transient($k){return $GLOBALS['transients'][$k]??false;}function set_transient($k,$v,$ttl){$GLOBALS['transients'][$k]=$v;}function delete_transient($k){unset($GLOBALS['transients'][$k]);}
function wp_next_scheduled($hook){return $GLOBALS['clock']['cron'];}function wp_schedule_event($start,$period,$hook){$GLOBALS['clock']['cron']=$start;return true;}function wp_clear_scheduled_hook($hook){$GLOBALS['clock']['cron']=null;}
function wp_remote_request($url,$args){$GLOBALS['remote'][]=['url'=>$url,'args'=>$args];
 if(str_contains($url,'task_post')){
  if($GLOBALS['scenario']==='api_403')return ['code'=>403,'body'=>'Forbidden'];
  if($GLOBALS['scenario']==='task_error')return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>40501,'status_message'=>'Unknown merchant location','id'=>null]]])];
  return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>20100,'id'=>'12345678-1234-1234-1234-123456789abc']]])];
 }
 if($GLOBALS['scenario']==='get_pending' && count(array_filter($GLOBALS['remote'],static fn($e)=>str_contains($e['url'],'task_get')))<2){return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>20100,'result'=>null]]])];}
 if($GLOBALS['scenario']==='get_error'){return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>40501,'status_message'=>'DataForSEO task failed','result'=>null]]])];}
 return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>20000,'result'=>[['items'=>[
   ['type'=>'amazon_serp','url'=>'https://www.amazon.de/dp/B011111111','title'=>'Wassermelder Smart Funk Sensor','data_asin'=>'B011111111','price_from'=>24.99],
   ['type'=>'amazon_paid','url'=>'https://www.amazon.de/dp/B088888888','title'=>'Wassermelder Anzeige','data_asin'=>'B088888888'],
   ['type'=>'amazon_serp','url'=>'https://www.amazon.com/dp/B033333333','title'=>'Wassermelder fremd','data_asin'=>'B033333333'],
   ['type'=>'amazon_serp','url'=>'https://www.amazon.de/dp/B022222222','title'=>'Wassermelder Kabel Alarm','data_asin'=>'B022222222'],
   ['type'=>'amazon_serp','url'=>'https://www.amazon.de/dp/B044444444','title'=>'Rauchmelder Smart','data_asin'=>'B044444444']
 ]]]]]])];
}
function wp_remote_retrieve_response_code($r){return $r['code'];}function wp_remote_retrieve_body($r){return $r['body'];}
function wp_parse_url($v,$part){return parse_url($v,$part);}function esc_url($v){return htmlspecialchars($v,ENT_QUOTES);}function esc_html($v){return htmlspecialchars($v,ENT_QUOTES);}
function esc_attr($v){return htmlspecialchars($v,ENT_QUOTES);}function checked($a,$b=true,$echo=true){$v=($a==$b)?'checked="checked"':'';if($echo)echo $v;return $v;}
function wp_date($format,$time){return date($format,$time);}function current_user_can($cap){return true;}
function wp_nonce_field($action,$name){echo '<input name="'.$name.'" value="test_nonce">';}function admin_url($s){return 'https://example.test/wp-admin/'.$s;}
class WP_Error{private $code,$message;function __construct($code,$message){$this->code=$code;$this->message=$message;}function get_error_message(){return $this->message;}function get_error_code(){return $this->code;}}
function build_snapshot($case){$nodes=[];$mapping=[];$push=function($key,$type,$id,$name,$parent,$pillar='core') use (&$nodes,&$mapping){$slug=sanitize_title($name);$nodes[]=['node_id'=>$key,'parent_id'=>$parent,'object_type'=>$type,'pillar'=>$pillar,'name'=>$name,'slug'=>$slug];$mapping[$key]=['object_type'=>$type,'object_id'=>$id];if($type==='page')$GLOBALS['posts'][$id]=(object)['ID'=>$id,'post_type'=>'page','post_status'=>'publish','post_title'=>$name];};
 $push('core:hub','page',1,'Hab und Bewahr','','core');
 $world_count=$case==='six_worlds'?6:($case==='eight_worlds'?8:7);
 for($i=1;$i<=$world_count;$i++){
  $key=$i===7?'core:world:insurance':($i===8?'core:world:future':'core:world:'.$i);
  $name=$i===7?'Versicherungen':($i===8?'Weitere Schutzwelt':'Welt '.$i);
  $push($key,'page',10+$i,$name,'core:hub');
 }
 for($i=1;$i<=40;$i++){
  $world='core:world:'.((($i-1)%6)+1);$area='core:area:'.$i;$push($area,'page',100+$i,'Bereich '.$i,$world);
  $topic='core:c22:topic:'.$i;
  $topic_name=$i===1?'Leckwarnung & Absperrung':($i===2?'Brandschutz & Löschmittel':($i===3?'Wertsachen & Schadenfall':'Sicherheitsfragen '.$i));
  $push($topic,'page',500+$i,$topic_name,$area);
  $label=($i===1?'Wassermelder':($i===2?'Rauchmelder / Vernetzung':($i===3?'Tresor & Versicherungsschutz':'Allgemeine Beratung '.$i)));
  if($case==='no_products')$label='Allgemeine Beratung '.$i;
  $push('core:category:'.$i,'category',200+$i,$label,$topic);
 }
 // Real-world scale from the admin evidence: 2,720 source nodes, of which
 // 2,714 are mapped. The six unmapped categories must not veto valid worlds.
 $next=1000;
 while(count($nodes)<2720){$idx=count($nodes);$push('core:c23:category:'.$idx,'category',$next++,'Beratung & Grundlagen '.$idx,'core:c22:topic:'.(($idx%40)+1));}
 if($case==='unmapped_insurance')unset($mapping['core:world:insurance']);
 $missing=$case==='unmapped_insurance'?5:6;
 for($i=0;$i<$missing;$i++){ $key=$nodes[count($nodes)-1-$i]['node_id'];unset($mapping[$key]); }
 if($case==='too_few'){$nodes=array_slice($nodes,0,20);$mapping=array_intersect_key($mapping,array_flip(array_column($nodes,'node_id')));}
 $rev='2026-11-07-hb';return ['revision'=>$rev,'nodes'=>$nodes,'mapping'=>$mapping];
}

function register_activation_hook($f,$cb){} function register_deactivation_hook($f,$cb){}
function post_type_exists($t){return true;} function add_shortcode($name,$cb){} function is_admin(){return $GLOBALS['is_admin']??true;} function is_feed(){return false;} function is_preview(){return false;} function is_category(){return true;} function get_queried_object(){return (object)['term_id'=>201,'slug'=>'wassermelder','name'=>'Wassermelder','description'=>''];} class WP_Query{public function is_main_query(){return true;}} function get_ancestors($id,$taxonomy){return [];} function get_the_title($id){return get_post($id)->post_title??'';} function get_post_field($key,$id){$p=get_post($id);return $key==='post_name'?sanitize_title($p->post_title??''):'';} function get_post_ancestors($id){return [];} function wp_strip_all_tags($v){return strip_tags($v);}
$scenario=$GLOBALS['scenario'];
$case=in_array($scenario,['get_pending','get_error'],true)?$scenario:'valid';
$snapshot=build_snapshot('valid');
$GLOBALS['opts']['apkw_target_tree_active_snapshot_v1']=$snapshot;
$GLOBALS['opts']['apkw_target_tree_active_revision_v1']=$snapshot['revision'];
$GLOBALS['opts']['ppar_enabled']='1';
$GLOBALS['opts']['ppar_hab_amazon_settings_v1']=['enabled'=>true,'tag'=>'habundbewahr-21','dfs_enabled'=>true,'login'=>'api-test','password'=>'fake'];
require dirname(__DIR__).'/affiliate-portal-router/affiliate-portal-router.php';
$app=Portal_Affiliate_Router::instance();
$C='ppar_hab_amazon_dfs_control_v1';
$H='ppar_hab_amazon_dfs_tick_v1';
pass(isset($GLOBALS['actions']['admin_post_ppar_hb_amazon_run']),'Paid-task admin action registered');
pass(isset($GLOBALS['actions']['admin_post_ppar_hb_amazon_poll']),'Poll-only admin action registered');
pass(isset($GLOBALS['actions'][$H]),'Original scheduled worker callback registered');
$app->hb_amazon_ensure_cron();
pass(absint($GLOBALS['clock']['cron'])>0,'Existing hourly WP-Cron schedule registered');
pass(count(PPAR_Portal_Source::catalog()['product_targets'])===3,'Real 2720/2714 catalog with selected product families');
$app->hb_amazon_dfs_tick('manual_search');
$c=get_option($C,[]);
pass(count($GLOBALS['remote'])===1 && str_contains($GLOBALS['remote'][0]['url'],'task_post'),'Exactly one paid POST requested from actual worker');
pass(!empty($c['pending_id']) && (int)$c['count']===1,'Task is pending and daily budget reserved once');
pass(empty($c['last_poll_at']) && empty($c['last_cron_at']),'No GET or automatic cron-run faked');
// Simulate the user's ACTUAL problem: WP-Cron event remains scheduled but no cron callback ran.
$GLOBALS['clock']['cron']=time()-3700;
$show=function()use($app){ob_start();$app->hb_amazon_render_settings();return ob_get_clean();};
if ($scenario==='invalid_pending' || $scenario==='expired_pending') {
  $c=get_option($C,[]);
  if($scenario==='invalid_pending') $c['pending_id']='INVALID';
  else $c['pending_at']=time()-49*HOUR_IN_SECONDS;
  update_option($C,$c,false);
  // Poll-only action must not pay even with broken task data.
  $app->hb_amazon_dfs_tick('manual_poll',true);
  $c=get_option($C,[]);
  pass(count($GLOBALS['remote'])===1,'Invalid/stale task does NOT start new paid search');
  pass(empty($c['pending_id']) && ($c['status']??'')==='error','Clear blocking error and pending removed');
  pass((int)$c['count']===1,'Original paid task count preserved');
  $app->hb_amazon_dfs_tick('manual_poll',true);
  pass(count($GLOBALS['remote'])===1,'A delayed poll click after task cleared is safe');
  $html=$show();
  pass(str_contains($html,'Geplanter automatischer Lauf:') && str_contains($html,'ÜBERFÄLLIG'),'Overdue WP-Cron warning visible');
  echo 'END_RC10 '.$scenario.' '.($GLOBALS['assertions'])." assertions\n";exit;
}
if($scenario==='manual_poll_only'){
  // Never allow a poll-only request to buy another task, even if cron consumed it meanwhile.
  $app->hb_amazon_dfs_tick('manual_poll',true);
  $c=get_option($C,[]);
  pass(count($GLOBALS['remote'])===2 && !empty($c['last_poll_at']),'Explicit poll-only action GETs open task');
  $app->hb_amazon_dfs_tick('manual_poll',true);
  $c=get_option($C,[]);
  pass(count($GLOBALS['remote'])===2 && (int)$c['count']===1,'Second poll after completion NEVER sends new paid POST');
  pass(str_contains($c['message'],'keine neue kostenpflichtige Suche'),'Clear no-cost status after race');
  echo 'END_RC10 '.$scenario.' '.($GLOBALS['assertions'])." assertions\n";exit;
}
if($scenario==='cron_works'){
  foreach($GLOBALS['actions'][$H] as $callback) call_user_func($callback);
  $c=get_option($C,[]);
  pass(!empty($c['last_cron_at']),'Real registered scheduled callback records actual cron execution');
  pass(count($GLOBALS['remote'])===2 && (int)$c['count']===1,'Scheduled callback GETs existing task without second paid POST');
  echo 'END_RC10 '.$scenario.' '.($GLOBALS['assertions'])." assertions\n";exit;
}
$html=$show();
$c=get_option($C,[]);
pass(count($GLOBALS['remote'])===2,'Admin page GET-only fallback polls the paid task despite stuck WP-Cron');
pass((int)$c['count']===1,'No additional paid task from page fallback');
pass(!empty($c['last_poll_at']) && $c['last_run_source']==='admin_safe_check','Real on-page GET attempt recorded and labelled correctly');
pass(empty($c['last_cron_at']),'Never call a missed cron event a successful automatic run');
pass(str_contains($html,'Geplanter automatischer Lauf:') && str_contains($html,'ÜBERFÄLLIG'),'Overdue schedule clearly visible with true time');
pass(str_contains($html,'Letzter automatischer Lauf:') && str_contains($html,'noch keiner nachweisbar'),'Show actual scheduler execution separately from schedule');
pass(str_contains($html,'Letzter DataForSEO-Ergebnisabruf:') && !str_contains($html,'Antwort:</strong> noch keine'),'Last paid-task GET and response shown in the admin screen');
if($scenario==='get_pending'){
  pass(($c['status']??'')==='pending' && !empty($c['pending_id']),'Provider pending response remains pending');
  pass(str_contains($html,'Offenen Auftrag jetzt prüfen (keine neue Suche)'),'Only free, safe poll button shown while task is open');
  pass(!str_contains($html,'Neue Suche starten (kostenpflichtig)'),'Paid button NOT available for pending task');
  $html=$show();
  pass(count($GLOBALS['remote'])===2,'Sub-2-minute page refresh cannot hammer provider');
  $c=get_option($C,[]);$c['last_poll_at']=time()-121;update_option($C,$c,false);
  $html=$show();$c=get_option($C,[]);
  pass(count($GLOBALS['remote'])===3 && empty($c['pending_id']),'Next eligible screen polls and completes pending task');
  pass(count((array)($c['category_products']['wassermelder']['items']??[]))===2,'Matching ASIN links stored after delayed provider completion');
}elseif($scenario==='get_error'){
  pass(($c['status']??'')==='error','Actual provider error is visible and not disguised as pending');
  pass(empty($c['pending_id']),'Rejected task is closed rather than silently posted again');
  pass(str_contains($html,'Fehlercode') || str_contains($html,'DataForSEO-Auftrag fehlgeschlagen'),'Actual response code shown');
  $before=count($GLOBALS['remote']);$app->hb_amazon_dfs_tick('manual_poll',true);
  pass(count($GLOBALS['remote'])===$before,'Poll after rejected task cannot create new paid POST');
}else{
  pass(empty($c['pending_id']),'Finished task cleared from open state');
  pass(count((array)($c['category_products']['wassermelder']['items']??[]))===2,'Amazon products matched and saved by actual plugin');
  pass(str_contains($html,'Neue Suche starten (kostenpflichtig)'),'After completion only new paid task button is visible');
  $count=count($GLOBALS['remote']);
  $app->hb_amazon_dfs_tick('manual_poll',true);
  pass(count($GLOBALS['remote'])===$count,'Expired poll-only click cannot create another search');
  $r=new ReflectionClass($app);
  $method=$r->getMethod('hb_amazon_area_product_fallback');$method->setAccessible(true);
  $ads=$method->invoke($app,501);
  pass(str_contains($ads,'/dp/B011111111?tag=habundbewahr-21'),'Stored actual Amazon links reach existing Hab page placement');
  pass(!str_contains($ads,'price'),'No price invented in ad');
}
echo 'END_RC10 '.$scenario.' '.($GLOBALS['assertions'])." assertions\n";
