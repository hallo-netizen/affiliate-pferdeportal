# Hab & Bewahr – HAB-004 RC10: vollständiger lokaler Ablaufnachweis

**Stand:** 07.11.2026. **Gegenstand:** vorhandenes HAB-004, kein neues Plugin/keine zweite Automatik. Geprüft: 400 bestandene explizite Funktionsprüfungen in 52 Testläufen, 25/25 PHP-Syntaxprüfungen, 28/28 ZIP-Dateien CRC, unverändert 25 von 28 Plugin-Dateien. Verändert: affiliate-portal-router.php, includes/trait-ppar-hb-amazon.php, readme.txt.

## Gemeldeter Produktionsfehler
Screenshot von 15:10 Uhr: DataForSEO-POST für Wassermelder um 13:51 Uhr angelegt, 1 von 5 bezahlten Tagesaufträgen, `pending_id` vorhanden, aber seitdem kein erneuter Worker-Lauf. Der Status `geplant` in RC9 prüfte nur, ob eine WordPress-Cron-Zeit gespeichert ist, **nicht**, ob dieser Cron tatsächlich ausgeführt wird. Warum der Server kein WP-Cron ausgeführt hat, kann ohne Serverzugriff nicht abschließend bewiesen werden.

## Behobene Ursachen
1. Die vorhandene WordPress-Cron-Planung bleibt. Ein ausgebliebener Lauf wird **als überfällig angezeigt**, mit geplantem Zeitpunkt und getrenntem Zeitpunkt des zuletzt **tatsächlich** vom Plugin ausgeführten Cron-Workers.
2. Ist ein bereits bezahlter DataForSEO-Auftrag offen, fragt dieselbe Amazon-Adminseite sein Ergebnis beim Aufruf **kostenlos** ab (maximal alle 120 Sekunden). Kein neuer Suchauftrag, keine neue bezahlte POST-Anfrage, keine neue Datenbank oder ständiges Browser-Offenhalten.
3. Solange ein Auftrag offen ist, zeigt das Plugin ausschließlich den Button **„Offenen Auftrag jetzt prüfen (keine neue Suche)“** mit eigener gesicherter Funktion. Selbst wenn der offene Auftrag zeitgleich verschwindet, kann dieser Button **nie** einen neuen Suchauftrag absenden.
4. Ein neuer kostenpflichtiger Auftrag kann nur mit dem ausdrücklich gekennzeichneten Button **„Neue Suche starten (kostenpflichtig)“** gestartet werden; Tagesgrenze maximal fünf bleibt.
5. Unter **„Automatischer Ablauf“** erscheinen jetzt letzter tatsächlicher Cron-Lauf, letzter Ergebnisabruf, API-Antwort und geplanter/überfälliger nächster Termin.
6. Bei ungültiger oder abgelaufener offener Auftrags-ID wird die genaue Fehlermeldung angezeigt, ohne im gleichen Lauf still einen neuen bezahlten Auftrag zu starten.

## Simulierter End-to-End-Ablauf – **ganze bestehende Plugin-Dateien geladen**
- Echte Hab-WP-Struktur als Testdatensatz mit 2.720 Knoten, 2.714 Zuordnungen und sieben Hauptwelten; Kategorien, Produktfamilien, bereits aktiver Werbeplatz.
- Vollständiger Worker-Start → genau **ein kostenpflichtiger POST** → bestätigte `pending_id` und Kosten-Zähler 1/5 → WP-Cron bewusst **nicht ausgelöst** → Aufruf der bestehenden Adminseite führt **kostenlosen GET-Abruf** aus → DataForSEO-Antwort wird geprüft → geprüfte Amazon-ASINs gespeichert → über den vorhandenen Hab-Design-Hook angezeigt.
- DataForSEO meldet erst `pending`, danach `completed`: Bei erneutem Seitenaufruf unter 120 Sekunden erfolgt kein überflüssiger weiterer GET; später wird dasselbe Ergebnis wieder kostenlos abgefragt.
- Fehlerhaftes DataForSEO-Ergebnis, ungültige/abgelaufene ID, zu später Doppelklick, WP-Cron tatsächlich ausgeführt, sechs/sieben/acht Welten, fehlender/ungültiger Kategorienbestand, Fehler bei Provider, deaktivierte Werbeausgabe: alle vorgesehenen sicheren Reaktionen separat getestet.
- **Keine** realen DataForSEO-Kundenzugangsdaten oder kostenpflichtigen API-Calls genutzt. Providerantworten sind bewusst nachgestellt. Ein tatsächlich funktionierender Server-Cron und erfolgreiche Produktivabfrage müssen nach der Installation noch über die **nun sichtbar angezeigten Zeiten und Antworten** nachgewiesen werden.

## Nachweise
- `tests/full_workflow_rc10.php` (neue Ausfall-/Polling-Szenarien am vollständigen Plugin)
- `tests/full_plugin_harness_rc9.php`, `tests/workflow_harness_rc9.php` plus vier bisherige Regressionstests
- `tests/RC10_AUDIT_RESULTS.json` (jede Einzelprüfung und Ergebnis)
- `tests/RC9_TO_RC10.patch` (nur Änderungen am bestehenden Plugin)
- ZIP SHA-256 `f3b6b0ac4fd05310fa32ce68e2715b29d022003ac68f32ceb051443832364ced`, 623469 Bytes

## Konkrete WordPress-Kontrolle
Nach Installation öffnet man **Affiliate-Zentrale → Amazon-Automatik**. Bereits das Öffnen ruft, falls ein Auftrag offen und seit mindestens 120 Sekunden nicht abgefragt ist, dessen Ergebnis kostenlos ab. Der Status steht sofort oben; unten sind **„Letzter automatischer Lauf“**, **„Letzter DataForSEO-Ergebnisabruf“**, **„Antwort“** und **„Geplanter automatischer Lauf“** sichtbar. Solange ein Auftrag offen ist, gibt es ausschließlich den ausdrücklich kostenfreien Prüfknopf. **Keine neue bezahlte Suche starten.**
