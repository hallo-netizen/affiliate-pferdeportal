<?php
/* Full-source Hab adapter + Amazon worker simulated WordPress integration. No network/costs. */
error_reporting(E_ALL);
ini_set('display_errors','1');
define('ABSPATH','/'); define('DAY_IN_SECONDS',86400);define('HOUR_IN_SECONDS',3600);
$GLOBALS['opts']=[]; $GLOBALS['filters']=[]; $GLOBALS['actions']=[]; $GLOBALS['remote']=[]; $GLOBALS['posts']=[]; $GLOBALS['termmap']=[]; $GLOBALS['post_meta']=[]; $GLOBALS['transients']=[]; $GLOBALS['clock']=['cron'=>null];$GLOBALS['scenario']=$argv[1] ?? 'valid';$GLOBALS['assertions']=0;
function pass($bool,$label){$GLOBALS['assertions']++;if(!$bool){fwrite(STDERR,'FAIL '.$label."\n");exit(2);}echo 'PASS '.$label."\n";}
function get_option($key,$default=false){return array_key_exists($key,$GLOBALS['opts'])?$GLOBALS['opts'][$key]:$default;}
function update_option($key,$v,$autoload=false){$GLOBALS['opts'][$key]=$v;return true;}
function absint($x){return abs((int)$x);}function sanitize_key($v){return strtolower(preg_replace('/[^a-z0-9_\-]/','',(string)$v));}
function sanitize_text_field($v){return strip_tags((string)$v);}function remove_accents($s){return strtr($s,['ä'=>'a','ö'=>'o','ü'=>'u','ß'=>'ss','Ä'=>'A','Ö'=>'O','Ü'=>'U']);}
function sanitize_title($s){$s=strtolower(remove_accents((string)$s));return trim(preg_replace('/[^a-z0-9]+/','-',$s),'-');}
function wp_json_encode($v){return json_encode($v,JSON_UNESCAPED_UNICODE);}function is_wp_error($v){return $v instanceof WP_Error;}
function get_post($id){return $GLOBALS['posts'][$id]??null;}
function get_post_status($id){$p=get_post((int)$id);return is_object($p)?$p->post_status:'';}
function get_post_type($id){$p=get_post((int)$id);return is_object($p)?$p->post_type:'';}
function get_post_meta($id,$key,$single=true){return $GLOBALS['post_meta'][$id][$key]??null;}
function get_the_terms($id,$taxonomy){return array_map(static fn($slug)=>(object)['slug'=>$slug],$GLOBALS['termmap'][$id]??[]);}
function get_posts($args){$all=array_values(array_filter($GLOBALS['posts'],static fn($p)=>$p->post_type===($args['post_type']??'post') && $p->post_status===($args['post_status']??'publish')));usort($all,static fn($a,$b)=>$a->ID<=>$b->ID);return array_slice($all,(int)($args['offset']??0),(int)($args['posts_per_page']??100));}
function add_filter($hook,$cb,$priority=10,$accepted_args=1){$GLOBALS['filters'][$hook][]=$cb;}
function apply_filters($hook,$value,...$more){foreach($GLOBALS['filters'][$hook]??[] as $cb){$value=call_user_func($cb,$value,...$more);}return $value;}
function add_action($hook,$cb,$priority=10,$accepted_args=1){$GLOBALS['actions'][$hook][]=$cb;}
function get_transient($k){return $GLOBALS['transients'][$k]??false;}function set_transient($k,$v,$ttl){$GLOBALS['transients'][$k]=$v;}function delete_transient($k){unset($GLOBALS['transients'][$k]);}
function wp_next_scheduled($hook){return $GLOBALS['clock']['cron'];}function wp_schedule_event($start,$period,$hook){$GLOBALS['clock']['cron']=$start;return true;}function wp_clear_scheduled_hook($hook){$GLOBALS['clock']['cron']=null;}
function wp_remote_request($url,$args){$GLOBALS['remote'][]=['url'=>$url,'args'=>$args];
 if(str_contains($url,'task_post')){
  if($GLOBALS['scenario']==='api_403')return ['code'=>403,'body'=>'Forbidden'];
  if($GLOBALS['scenario']==='task_error')return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>40501,'status_message'=>'Unknown merchant location','id'=>null]]])];
  return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>20100,'id'=>'12345678-1234-1234-1234-123456789abc']]])];
 }
 if($GLOBALS['scenario']==='get_pending' && count(array_filter($GLOBALS['remote'],static fn($e)=>str_contains($e['url'],'task_get')))<2){return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>20100,'result'=>null]]])];}
 if($GLOBALS['scenario']==='get_error'){return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>40501,'status_message'=>'DataForSEO task failed','result'=>null]]])];}
 return ['code'=>200,'body'=>json_encode(['status_code'=>20000,'tasks'=>[['status_code'=>20000,'result'=>[['items'=>[
   ['type'=>'amazon_serp','url'=>'https://www.amazon.de/dp/B011111111','title'=>'Wassermelder Smart Funk Sensor','data_asin'=>'B011111111','price_from'=>24.99],
   ['type'=>'amazon_paid','url'=>'https://www.amazon.de/dp/B088888888','title'=>'Wassermelder Anzeige','data_asin'=>'B088888888'],
   ['type'=>'amazon_serp','url'=>'https://www.amazon.com/dp/B033333333','title'=>'Wassermelder fremd','data_asin'=>'B033333333'],
   ['type'=>'amazon_serp','url'=>'https://www.amazon.de/dp/B022222222','title'=>'Wassermelder Kabel Alarm','data_asin'=>'B022222222'],
   ['type'=>'amazon_serp','url'=>'https://www.amazon.de/dp/B044444444','title'=>'Rauchmelder Smart','data_asin'=>'B044444444']
 ]]]]]])];
}
function wp_remote_retrieve_response_code($r){return $r['code'];}function wp_remote_retrieve_body($r){return $r['body'];}
function wp_parse_url($v,$part){return parse_url($v,$part);}function esc_url($v){return htmlspecialchars($v,ENT_QUOTES);}function esc_html($v){return htmlspecialchars($v,ENT_QUOTES);}
function esc_attr($v){return htmlspecialchars($v,ENT_QUOTES);}function checked($a,$b=true,$echo=true){$v=($a==$b)?'checked="checked"':'';if($echo)echo $v;return $v;}
function wp_date($format,$time){return date($format,$time);}function current_user_can($cap){return true;}
function wp_nonce_field($action,$name){echo '<input name="'.$name.'" value="test_nonce">';}function admin_url($s){return 'https://example.test/wp-admin/'.$s;}
class WP_Error{private $code,$message;function __construct($code,$message){$this->code=$code;$this->message=$message;}function get_error_message(){return $this->message;}function get_error_code(){return $this->code;}}
function build_snapshot($case){$nodes=[];$mapping=[];$push=function($key,$type,$id,$name,$parent,$pillar='core') use (&$nodes,&$mapping){$slug=sanitize_title($name);$nodes[]=['node_id'=>$key,'parent_id'=>$parent,'object_type'=>$type,'pillar'=>$pillar,'name'=>$name,'slug'=>$slug];$mapping[$key]=['object_type'=>$type,'object_id'=>$id];if($type==='page')$GLOBALS['posts'][$id]=(object)['ID'=>$id,'post_type'=>'page','post_status'=>'publish','post_title'=>$name];};
 $push('core:hub','page',1,'Hab und Bewahr','','core');
 for($i=1;$i<=6;$i++){$push('core:world:'.$i,'page',10+$i,'Welt '.$i,'core:hub');}
 $push('core:world:insurance','page',17,'Versicherungen','core:hub');
 for($i=1;$i<=40;$i++){
  $world='core:world:'.((($i-1)%6)+1);$area='core:area:'.$i;$push($area,'page',100+$i,'Bereich '.$i,$world);
  $label=($i===1?'Wassermelder':($i===2?'Rauchmelder':($i===3?'Tresor':'Allgemeine Beratung '.$i)));
  if($case==='no_products')$label='Allgemeine Beratung '.$i;
  $push('core:category:'.$i,'category',200+$i,$label,$area);
 }
 if($case==='too_few'){$nodes=array_slice($nodes,0,20);$mapping=array_intersect_key($mapping,array_flip(array_column($nodes,'node_id')));}
 $rev='2026-11-07-hb';return ['revision'=>$rev,'nodes'=>$nodes,'mapping'=>$mapping];
}
$scenario=$GLOBALS['scenario'];
if($scenario!=='missing_snapshot'){$snapshot=build_snapshot($scenario);$GLOBALS['opts']['apkw_target_tree_active_snapshot_v1']=$snapshot;$GLOBALS['opts']['apkw_target_tree_active_revision_v1']=($scenario==='wrong_revision'?'other':$snapshot['revision']);}
$GLOBALS['opts']['ppar_hab_amazon_settings_v1']=['enabled'=>true,'tag'=>'habundbewahr-21','dfs_enabled'=>true,'login'=>'api-test','password'=>'fake'];
require dirname(__DIR__).'/affiliate-portal-router/includes/class-ppar-portal-source.php';
require dirname(__DIR__).'/affiliate-portal-router/includes/class-ppar-hab-bewahr-bridge.php';
require dirname(__DIR__).'/affiliate-portal-router/includes/trait-ppar-hb-amazon.php';
PPAR_HB_Integration::bootstrap();
class RealHabAffiliateFixture {use PPAR_HB_Amazon_Trait;const CAMPAIGN_POST_TYPE='ap_campaign';function campaign_from_post($p){return null;}
 function run(){return $this->hb_amazon_dfs_tick();}function fallback($context,$slot){return $this->hb_amazon_category_search_fallback($context,$slot);}function article($id){return $this->hb_amazon_article_fallback($id);} }
$app=new RealHabAffiliateFixture();$app->hb_amazon_register_hooks();$app->hb_amazon_ensure_cron();
pass(in_array('admin_post_ppar_hb_amazon_run',array_keys($GLOBALS['actions']),true),'Manual run action wired');
pass(!empty($GLOBALS['clock']['cron']),'Hourly cron scheduled');
$catalog=PPAR_Portal_Source::catalog();
if(in_array($scenario,['missing_snapshot','wrong_revision','no_products','too_few'],true)){
 pass(is_wp_error($catalog),'Catalog returns explicit WP_Error on invalid source');
 echo 'CATALOG_ERROR '.$catalog->get_error_code().' '.$catalog->get_error_message()."\n";
 $app->run();$c=get_option(RealHabAffiliateFixture::HB_AMAZON_CONTROL,[]);
 pass(count($GLOBALS['remote'])===0,'No paid provider request on invalid catalog');
 pass(($c['count']??0)===0,'Zero billable tasks');
 echo 'ACTUAL_ADMIN_MESSAGE '.($c['message']??'<none>')."\n";
 pass(str_contains($c['message'],'BLOCKIERT:'),'Underlying source error is no longer masked');
 exit(0);
}
pass(is_array($catalog) && count($catalog['article_targets'])===40,'40 real snapshot categories loaded through original bridge');
pass(count($catalog['product_targets'])===3,'3 concrete product targets produced by original recognizer');
if($scenario==='article'){
 $GLOBALS['posts'][551]=(object)['ID'=>551,'post_type'=>'post','post_status'=>'publish','post_title'=>'Wassermelder Smart im Keller','post_content'=>'Wasserschutz','post_name'=>'wassermelder-smart'];$GLOBALS['termmap'][551]=['wassermelder'];
 $GLOBALS['posts'][552]=(object)['ID'=>552,'post_type'=>'post','post_status'=>'draft','post_title'=>'Wassermelder im Keller'];$GLOBALS['termmap'][552]=['wassermelder'];
}
$app->run();$c=get_option(RealHabAffiliateFixture::HB_AMAZON_CONTROL,[]);
if($scenario==='api_403'||$scenario==='task_error'){
 pass(count($GLOBALS['remote'])===1,'Exactly one failed POST attempt logged');
 pass(($c['count']??0)===1,'Budget reserved safely before request');
 pass(empty($c['pending_id']),'No bogus pending provider task');
 echo 'ACTUAL_ADMIN_MESSAGE '.($c['message']??'<none>')."\n";
 exit(0);
}
pass(count($GLOBALS['remote'])===1,'Exactly one API POST after click');
pass(!empty($c['pending_id']),'Valid provider task saved');
pass(($c['count']??0)===1,'One paid request, not duplicated');
pass(($c['pending_source']??'')===($scenario==='article'?'hab_article':'hab_category'),'Appropriate article/category source');
$payload=json_decode($GLOBALS['remote'][0]['args']['body'],true);
pass(($payload[0]['keyword']??'')===($scenario==='article'?'Wassermelder Smart im Keller':'Wassermelder'),'Search grounded in catalog/article');
$app->run();$c=get_option(RealHabAffiliateFixture::HB_AMAZON_CONTROL,[]);
if($scenario==='get_pending'||$scenario==='get_error'){
 pass(count($GLOBALS['remote'])===2,'One GET, zero extra POST');
 echo 'ACTUAL_ADMIN_MESSAGE '.($c['message']??'<none>')."\n";
 if($scenario==='get_pending'){$app->run();$c=get_option(RealHabAffiliateFixture::HB_AMAZON_CONTROL,[]);pass(empty($c['pending_id']),'Later GET completes pending task');}
 else { pass(empty($c['pending_id']),'Failed provider task is removed instead of pending forever');pass(str_contains($c['message'],'fehlgeschlagen'),'Provider task failure visible as failure');exit(0); }
}
pass(empty($c['pending_id']),'GET finishes and clears pending task');
pass(($c['count']??0)===1,'GET does not bill new search');
if($scenario==='article'){
 pass(count($c['article_products'][551]['items']??[])===1,'Approved article products filtered by smart variant');
 $html=$app->article(551);pass(str_contains($html,'/dp/B011111111?tag=habundbewahr-21'),'Affiliate card link for published article');
 pass($app->article(552)==='','Draft article never displays');
}else{
 pass(count($c['category_products']['wassermelder']['items']??[])===2,'Two organic, relevant ASIN stored in correct category');
 $html=$app->fallback(['post_type'=>'category_archive','primary_slug'=>'wassermelder','primary_name'=>'Wassermelder','product_family_slug'=>'wasserschutz'],'product_after_category_tiles');
 pass(str_contains($html,'/dp/B011111111?tag=habundbewahr-21'),'Affiliate URL rendered inside original category placement');
}
pass(str_contains($html,'Anzeige')&&!str_contains($html,'price_from')&&!str_contains($html,'B088888888'),'Disclosure, no pricing/payed ads');
pass(!str_contains($html,'B033333333')&&!str_contains($html,'B044444444'),'Wrong country and wrong product family excluded');
$app->run();$d=get_option(RealHabAffiliateFixture::HB_AMAZON_CONTROL,[]);
pass(($d['count']??0)===2,'Next distinct search only after previous GET');
pass(count($GLOBALS['remote'])===($scenario==='get_pending'?4:3),'GET polling without duplicate POST');
echo 'ACTUAL_ADMIN_MESSAGE '.($d['message']??'<none>')."\n";
echo 'TOTAL_ASSERTIONS '.$GLOBALS['assertions']."\n";
