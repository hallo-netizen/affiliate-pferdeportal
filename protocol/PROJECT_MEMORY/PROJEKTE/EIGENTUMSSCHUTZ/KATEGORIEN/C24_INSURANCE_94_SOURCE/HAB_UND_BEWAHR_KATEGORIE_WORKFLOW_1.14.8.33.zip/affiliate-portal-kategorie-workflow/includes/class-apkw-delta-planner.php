<?php
if (!defined('ABSPATH')) { exit; }

/** Read-only baseline/delta planner plus sparse incremental-extension merger. No WordPress writes. */
final class APKW_DeltaPlanner {
    public const CONTRACT='MASTER016_R8_DYNAMIC_BASELINE_DELTA_V1';
    public const EXTENSION_CONTRACT='APKW_INCREMENTAL_CATEGORY_EXTENSION_V1';
    public const EXTENSION_FORMAT='affiliate-portal-category-extension';

    public static function plan(array $baseline,array $candidate):array{
        $base=self::index($baseline);$next=self::index($candidate);$changes=[];$research_required=[];
        foreach($next as $id=>$node){
            if(!isset($base[$id])){
                $changes[]=['concept_id'=>$id,'change'=>'ADDED','research_required'=>true,'reason'=>'NEW_CONCEPT_ID'];$research_required[]=$id;continue;
            }
            $old=$base[$id];$fields=[];
            foreach(['name','slug','parent_concept_id','level','primary_keyword','research_cluster_id','search_intent','status','affiliate_fit','affiliate_path','affiliate_fit_justification'] as $f){if(self::norm($old[$f]??null)!==self::norm($node[$f]??null))$fields[]=$f;}
            if(!$fields){$changes[]=['concept_id'=>$id,'change'=>'UNCHANGED','research_required'=>false,'changed_fields'=>[]];continue;}
            $identity_changed=in_array('research_cluster_id',$fields,true);
            $changes[]=['concept_id'=>$id,'change'=>'UPDATED','research_required'=>$identity_changed,'changed_fields'=>$fields,'reason'=>$identity_changed?'RESEARCH_IDENTITY_CHANGED':'SAME_RESEARCH_IDENTITY_DELTA_REUSES_BOUND_EVIDENCE'];
            if($identity_changed)$research_required[]=$id;
        }
        foreach($base as $id=>$node)if(!isset($next[$id]))$changes[]=['concept_id'=>$id,'change'=>'RETIRED_REVIEW_REQUIRED','research_required'=>false,'automatic_delete'=>false,'reason'=>'MISSING_FROM_NEW_CONCEPT_VERSION_NEVER_AUTO_DELETE'];
        usort($changes,static fn($a,$b)=>strcmp((string)$a['concept_id'],(string)$b['concept_id']));
        return [
            'contract'=>self::CONTRACT,
            'baseline_review_scope_sha256'=>APKW_Validator::review_scope_hash($baseline),
            'candidate_review_scope_sha256'=>APKW_Validator::review_scope_hash($candidate),
            'change_count'=>count(array_filter($changes,static fn($r)=>($r['change']??'')!=='UNCHANGED')),
            'research_required_concept_ids'=>array_values(array_unique($research_required)),
            'full_workflow_regression_required'=>true,
            'automatic_delete'=>false,
            'stable_identity'=>'concept_id',
            'changes'=>$changes,
        ];
    }

    /**
     * Merge a sparse extension into the current full baseline.
     * Missing baseline nodes are preserved, never interpreted as deletion.
     * The returned package is a normal full RESEARCH_DRAFT and therefore reuses all existing validators.
     */
    public static function merge_extension(array $baseline,array $extension):array{
        $errors=[];$warnings=[];
        if(($extension['format']??'')!==self::EXTENSION_FORMAT)$errors[]=self::issue('EXTENSION_FORMAT_INVALID','format','Erweiterung benötigt '.self::EXTENSION_FORMAT.'.');
        if((string)($extension['schema_version']??'')!=='1.0')$errors[]=self::issue('EXTENSION_SCHEMA_INVALID','schema_version','Erweiterung benötigt schema_version 1.0.');
        if((string)($extension['master_contract_id']??'')!==APKW_MASTER_CONTRACT_ID)$errors[]=self::issue('EXTENSION_MASTER_CONTRACT_MISMATCH','master_contract_id','Erweiterung gehört nicht zum gebundenen Kategorie-Master.');
        if((string)($extension['mode']??'')!=='RESEARCH_DRAFT')$errors[]=self::issue('EXTENSION_MODE_INVALID','mode','Erweiterung muss RESEARCH_DRAFT sein.');
        foreach(['retire_concept_ids','delete_concept_ids','automatic_delete'] as $field){
            if(!empty($extension[$field]))$errors[]=self::issue('EXTENSION_DELETE_FORBIDDEN',$field,'Inkrementelle Erweiterung darf keine bestehenden Knoten löschen oder stilllegen.');
        }
        $baseline_validation=APKW_Validator::validate($baseline);
        if(empty($baseline_validation['valid']))$errors[]=self::issue('EXTENSION_BASELINE_INVALID','baseline','Aktuelle Baseline ist nicht validatorfähig.');
        $base_project=(string)($baseline['project']['project_id']??'');$ext_project=(string)($extension['project_id']??($extension['project']['project_id']??''));
        if($base_project===''||$ext_project===''||$base_project!==$ext_project)$errors[]=self::issue('EXTENSION_PROJECT_MISMATCH','project_id','Erweiterung und Baseline müssen dieselbe project_id besitzen.');
        $baseline_hash=APKW_Validator::review_scope_hash($baseline);$declared=trim((string)($extension['base_review_scope_sha256']??''));
        if($declared!==''&&!hash_equals($baseline_hash,$declared))$errors[]=self::issue('EXTENSION_BASELINE_HASH_MISMATCH','base_review_scope_sha256','Erweiterung wurde für einen anderen Baseline-Stand erzeugt.');
        $incoming_nodes=is_array($extension['nodes']??null)?array_values($extension['nodes']):[];
        if(!$incoming_nodes)$errors[]=self::issue('EXTENSION_NODES_EMPTY','nodes','Erweiterung enthält keine neuen oder geänderten Knoten.');
        $incoming_ids=[];$affected_clusters=[];
        foreach($incoming_nodes as $i=>$node){
            if(!is_array($node)){$errors[]=self::issue('EXTENSION_NODE_INVALID','nodes.'.$i,'Erweiterungsknoten muss ein Objekt sein.');continue;}
            $id=trim((string)($node['concept_id']??''));
            if($id===''){$errors[]=self::issue('EXTENSION_CONCEPT_ID_MISSING','nodes.'.$i.'.concept_id','Jeder Erweiterungsknoten benötigt eine stabile concept_id.');continue;}
            if(isset($incoming_ids[$id])){$errors[]=self::issue('EXTENSION_CONCEPT_ID_DUPLICATE','nodes.'.$i.'.concept_id','concept_id kommt innerhalb der Erweiterung mehrfach vor: '.$id);continue;}
            $incoming_ids[$id]=true;$cid=trim((string)($node['research_cluster_id']??''));if($cid!=='')$affected_clusters[$cid]=true;
        }
        if($errors)return ['valid'=>false,'errors'=>$errors,'warnings'=>$warnings,'package'=>null,'delta'=>null];

        $candidate=$baseline;
        foreach(['human_sight_review','deployment_binding','research_binding','initial_human_sight_review','global_gap_human_review','global_coverage_binding'] as $field)unset($candidate[$field]);
        $candidate['mode']='RESEARCH_DRAFT';
        $candidate['package_id']=trim((string)($extension['extension_id']??''))!==''?'extension-'.sanitize_key((string)$extension['extension_id']):'extension-'.substr(hash('sha256',$base_project.'|'.wp_json_encode($extension,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),0,24);
        $candidate['package_version']=max(1,(int)($baseline['package_version']??1)+1);

        $node_map=self::index($baseline);
        foreach($incoming_nodes as $node)$node_map[(string)$node['concept_id']]=$node;
        $candidate['nodes']=array_values($node_map);
        usort($candidate['nodes'],static fn($a,$b)=>((int)($a['level']??0)<=> (int)($b['level']??0))?:strcmp((string)($a['concept_id']??''),(string)($b['concept_id']??'')));

        $cluster_map=[];
        foreach(is_array($baseline['research_clusters']??null)?$baseline['research_clusters']:[] as $cluster){if(is_array($cluster)&&trim((string)($cluster['cluster_id']??''))!=='')$cluster_map[(string)$cluster['cluster_id']]=$cluster;}
        foreach(is_array($extension['research_clusters']??null)?$extension['research_clusters']:[] as $cluster){if(!is_array($cluster))continue;$id=trim((string)($cluster['cluster_id']??''));if($id===''){$errors[]=self::issue('EXTENSION_CLUSTER_ID_MISSING','research_clusters','Erweiterungscluster benötigt cluster_id.');continue;}$cluster_map[$id]=$cluster;$affected_clusters[$id]=true;}
        $candidate['research_clusters']=array_values($cluster_map);
        usort($candidate['research_clusters'],static fn($a,$b)=>strcmp((string)($a['cluster_id']??''),(string)($b['cluster_id']??'')));

        $all_ids=array_fill_keys(array_keys(self::index($candidate)),true);
        foreach($incoming_nodes as $i=>$node){$parent=trim((string)($node['parent_concept_id']??''));if($parent!==''&&!isset($all_ids[$parent]))$errors[]=self::issue('EXTENSION_PARENT_UNKNOWN','nodes.'.$i.'.parent_concept_id','Parent der Erweiterung existiert weder in Baseline noch Erweiterung: '.$parent);}
        if($errors)return ['valid'=>false,'errors'=>$errors,'warnings'=>$warnings,'package'=>null,'delta'=>null];

        $candidate['incremental_extension']=[
            'contract'=>self::EXTENSION_CONTRACT,
            'base_review_scope_sha256'=>$baseline_hash,
            'affected_concept_ids'=>array_values(array_keys($incoming_ids)),
            'affected_cluster_ids'=>array_values(array_keys($affected_clusters)),
            'preserve_missing_baseline_nodes'=>true,
            'automatic_delete'=>false,
            'merged_at_utc'=>gmdate('c'),
        ];
        $candidate['source']=[
            'site'=>rtrim((string)home_url('/'),'/'),
            'type'=>'incremental_category_extension',
            'contract'=>self::EXTENSION_CONTRACT,
            'built_at_utc'=>gmdate('c'),
        ];

        $validation=APKW_Validator::validate($candidate);
        if(empty($validation['valid']))foreach($validation['errors']??[] as $e)$errors[]=self::issue('EXTENSION_MERGED_PACKAGE_INVALID','candidate.'.(string)($e['path']??''),(string)($e['code']??'INVALID').': '.(string)($e['message']??''));
        $delta=self::plan($baseline,$candidate);
        foreach($delta['changes']??[] as $row)if(($row['change']??'')==='RETIRED_REVIEW_REQUIRED')$errors[]=self::issue('EXTENSION_WOULD_RETIRE_BASELINE','delta:'.(string)($row['concept_id']??''),'Sparse Erweiterung darf keinen Baseline-Knoten verlieren.');
        return ['valid'=>count($errors)===0,'errors'=>$errors,'warnings'=>$warnings,'package'=>$candidate,'delta'=>$delta];
    }

    private static function index(array $package):array{$out=[];foreach(is_array($package['nodes']??null)?$package['nodes']:[] as $n){if(!is_array($n))continue;$id=trim((string)($n['concept_id']??''));if($id!=='')$out[$id]=$n;}return $out;}
    private static function norm($v):string{if($v===null)return '';if(is_bool($v))return $v?'1':'0';return trim((string)$v);}
    private static function issue(string $code,string $path,string $message):array{return ['code'=>$code,'path'=>$path,'message'=>$message];}
}
