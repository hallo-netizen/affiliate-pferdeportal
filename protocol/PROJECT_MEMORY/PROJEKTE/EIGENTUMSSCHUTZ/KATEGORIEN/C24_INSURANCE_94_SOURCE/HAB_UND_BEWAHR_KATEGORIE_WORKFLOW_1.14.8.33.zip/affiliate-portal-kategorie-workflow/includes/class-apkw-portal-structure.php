<?php
if (!defined('ABSPATH')) { exit; }
final class APKW_PortalStructure {
    public const CONTRACT='APKW_PROFILE_STRUCTURE_V1';
    private static function p():array{
        if(class_exists('APKW_TargetTreeSync')){
            $s=APKW_TargetTreeSync::active_snapshot();if($s)return $s;
        }
        return APKW_TargetTree::profile()??[];
    }
    public static function hub_specs():array{
        $p=self::p();$out=[];
        foreach(['core'=>'content','editorial'=>'magazine','directory'=>'marketplace'] as $pillar=>$block){
            $hub=(array)($p['pillars'][$pillar]['hub']??[]);
            if(!empty($hub['slug']))$out[$block]=['slug'=>(string)$hub['slug'],'title'=>(string)($hub['title']??$pillar),'front'=>true,'footer'=>$pillar!=='core','taxonomy'=>$pillar==='editorial'?'journal_cat':($pillar==='directory'?'hp_listing_category':null)];
        }
        return $out;
    }
    public static function magazine_menu_groups():array{
        $g=self::p()['pillars']['editorial']['menu_groups']??[];return is_array($g)?$g:[];
    }
    public static function front_blocks():array{return array_keys(array_filter(self::hub_specs(),static fn($s)=>!empty($s['front'])));}
    public static function footer_blocks():array{return array_keys(array_filter(self::hub_specs(),static fn($s)=>!empty($s['footer'])));}
}