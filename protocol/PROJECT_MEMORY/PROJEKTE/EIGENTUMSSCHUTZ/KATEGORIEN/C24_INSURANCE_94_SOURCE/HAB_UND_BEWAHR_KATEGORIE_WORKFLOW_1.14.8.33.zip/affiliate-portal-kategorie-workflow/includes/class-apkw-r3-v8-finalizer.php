<?php
if (!defined('ABSPATH')) { exit; }
/**
 * Hab & Bewahr R3/V8 – fail-closed structural profile composer.
 * No SEO/network charges, no category/article writes, no automatic sync.
 * The old LIVE R2 target and its object IDs are the only permitted baseline.
 */
final class APKW_R3_V8_Finalizer {
    private const PAGE='apkw-r3-v8-finalizer';
    private const BASE_REV='HB-SECURITY-CATEGORY-OWNER-CORRECTIONS-20261012-R2';
    private const PROFILE_OPT='apkw_target_tree_profile_v1';
    private const BACKUP_OPT='apkw_r3_v8_original_r2_backup_v1';
    private const SOURCE_GIT_BLOB_SHA1='49a940e0cc0c4482b1b5832a6ee987e45e6ef122';
    private const SOURCE_URL='https://raw.githubusercontent.com/hallo-netizen/affiliate-pferdeportal/3ca003beefbc51fa92118a6faa707e42a7cfbd32/protocol/PROJECT_MEMORY/PROJEKTE/EIGENTUMSSCHUTZ/KONZEPT/R3_V8_DATAFORSEO_BESTANDSNUTZUNG_144_READONLY_20261013.json';
    private const MOVES=[
      ['Leerstehendes Wohnhaus','Post & Zustellung bei Leerstand','Briefkasten und Postzustellung bei privatem Hausleerstand regeln'],
      ['Leerstehendes Wohnhaus','Private Objektkontrollen','Kontrollgänge in einem zeitweilig unbewohnten Haus organisieren'],
      ['Kellerabdichtung & Ursachen','Feuchte Bodenplatten','Feuchte Kellerbodenplatte fachlich beurteilen lassen'],
      ['Vorzelt & Dichtheitsprobleme','Dachluken & Feuchteeintritt','Wassereintritt an Wohnmobil-Dachluke früh erkennen'],
      ['Außenanlagen bei Sturm','Sicherung ausfahrbarer Markisen','Markise vor Sturm schützen'],
      ['Pumpensumpf & Kellerschutz','Wartung von Sumpfpumpen','Pumpensumpf nach Starkregen sicher reinigen lassen'],
      ['Kameras & Licht vor Sabotage','Außenbeleuchtung schützen','Außenbeleuchtung gegen Vandalismus sichern'],
      ['Außentechnik vor Vandalismus','Wärmepumpe vor Sabotage','Wärmepumpe vor Beschädigung schützen'],
      ['Außentechnik vor Vandalismus','Wärmepumpe vor Sabotage','Beschädigung an einer Wärmepumpe nach Vandalismus dokumentieren'],
      ['Wasserstopp & Geräteschutz','Haushaltsgeräte & Wasserschutz','Aquastop an einer Waschmaschine richtig nachrüsten'],
      ['Wasserstopp & Geräteschutz','Haushaltsgeräte & Wasserschutz','Spülmaschine gegen unbemerkte Leckagen sichern'],
      ['Pumpen-Störmeldungen','Sumpfpumpen-Ausfallalarme','Sumpfpumpe mit geeignetem Alarm überwachen'],
      ['Alarmanlage bei Stromausfall','Offline-Sicherheitssysteme','Alarmübertragung ohne laufenden Router absichern'],
      ['Alarmanlage bei Stromausfall','Offline-Sicherheitssysteme','Bei Internetausfall die Alarmübertragung mit Ersatzweg sicherstellen'],
      ['Küchen- & Fettbrand','Elektrische Küchenbrandgefahren','Küchengeräte und Steckdosen auf Brandrisiken prüfen'],
      ['Elektrische Küchenbrandgefahren','Steckdosen & Mehrfachverteiler','Schmorende Steckdose im Privathaushalt frühzeitig erkennen'],
      ['Elektrische Küchenbrandgefahren','Kabelbrände im Wohnbereich','Was tun nach einem Kabelbrand am Haushaltsgerät?'],
      ['Überspannung im Haus','Überspannung im Zählerschrank','Elektroverteiler im Privathaus auf Überspannungsableiter prüfen lassen'],
      ['Überspannung im Haus','Datenleitungen & Überspannung','Überspannungsschutz für Router und Heimnetz auswählen']
    ];
    public static function init():void {
        if(!function_exists('add_action'))return;
        add_action('admin_menu',[__CLASS__,'menu'],42);
        add_action('admin_post_apkw_r3_v8_preview',[__CLASS__,'preview']);
        add_action('admin_post_apkw_r3_v8_export',[__CLASS__,'export']);
        add_action('admin_post_apkw_r3_v8_prepare',[__CLASS__,'prepare']);
        add_action('admin_post_apkw_r3_v8_restore',[__CLASS__,'restore']);
    }
    public static function menu():void {
        add_submenu_page(APKW_FinalTargetAdmin::PAGE_SLUG,'R3/V8 – sichere Umsetzung','R3/V8 Zielprofil','manage_options',self::PAGE,[__CLASS__,'render']);
    }
    private static function admin():void {
        if(!function_exists('current_user_can')||!current_user_can('manage_options'))throw new RuntimeException('Nur Administratoren.');
    }
    private static function assert_source_hash(string $raw):void {
        $gitObjectSha=sha1('blob '.strlen($raw)."\0".$raw);
        if(!hash_equals(self::SOURCE_GIT_BLOB_SHA1,$gitObjectSha))
            throw new RuntimeException('R3-Quelle stimmt nicht mit dem festgeschriebenen, geprüften Projektstand überein. Keine WordPress-Änderung.');
    }
    private static function source(array $provided=[]):array {
        if($provided)return $provided;
        if(!function_exists('wp_remote_get'))throw new RuntimeException('WordPress-HTTPS für den öffentlichen, festen R3-Quellenstand nicht verfügbar.');
        $r=wp_remote_get(self::SOURCE_URL,['timeout'=>20,'redirection'=>0,'limit_response_size'=>1500000,'headers'=>['Accept'=>'application/json']]);
        if(function_exists('is_wp_error')&&is_wp_error($r))throw new RuntimeException('R3-Quellabruf blockiert: '.$r->get_error_message());
        if(!is_array($r)||!function_exists('wp_remote_retrieve_response_code')||wp_remote_retrieve_response_code($r)!==200)throw new RuntimeException('R3-Quellabruf nicht HTTP 200. Keine Veränderung vorgenommen.');
        $body=wp_remote_retrieve_body($r);
        self::assert_source_hash((string)$body);
        $v=json_decode((string)$body,true);
        if(!is_array($v))throw new RuntimeException('R3-Quell-JSON ungültig.');
        return $v;
    }
    private static function uploaded_manifest():array {
        $file=(array)($_FILES['apkw_r3_v8_source']??[]);
        if(($file['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)return [];
        if((int)($file['error']??99)!==UPLOAD_ERR_OK||(int)($file['size']??0)>1500000||(int)($file['size']??0)<2)
            throw new RuntimeException('R3-Quellupload ungültig oder größer als 1,5 MB.');
        $raw=file_get_contents((string)($file['tmp_name']??''));self::assert_source_hash((string)$raw);$x=json_decode((string)$raw,true);
        if(!is_array($x))throw new RuntimeException('R3-Quellupload ist kein gültiges JSON.');
        return $x;
    }
    private static function baseline(bool $liveCheck=false):array {
        $p=function_exists('get_option')?get_option(self::PROFILE_OPT,null):null;
        if(!is_array($p))throw new RuntimeException('Das LIVE gebundene R2-Profil fehlt. Niemals altes gebündeltes R1-Profil verwenden.');
        if((string)($p['project']['project_id']??'')!=='hab-und-bewahr'||(string)($p['project']['revision']??'')!==self::BASE_REV)
            throw new RuntimeException('Live-R2-Revision nicht bestätigt: '.(string)($p['project']['revision']??'FEHLT'));
        if(class_exists('APKW_TargetTree')&&empty(APKW_TargetTree::validate($p)['valid']))throw new RuntimeException('LIVE R2-Profil ist nicht gültig.');
        $state=class_exists('APKW_TargetTreeSync')?APKW_TargetTreeSync::state():null;
        if(!is_array($state)||($state['status']??'')!=='COMPLETE')throw new RuntimeException('WordPress-R2-Synchronisierung nicht COMPLETE.');
        $snap=APKW_TargetTreeSync::active_snapshot();
        if(!is_array($snap)||empty($snap['mapping'])||empty($snap['nodes']))throw new RuntimeException('WordPress-R2-Readback fehlt.');
        $active=APKW_TargetTreeSync::active_revision();
        if($active===''||!str_starts_with($active,self::BASE_REV.'+'))throw new RuntimeException('Aktive WordPress-R2-Revision weicht vom R2-Profil ab.');
        self::baseline_invariants($p,$snap);
        if($liveCheck)self::assert_live_objects($p,$snap);
        return $p;
    }
    public static function baseline_invariants(array $p,array $snap):array {
        $counts=['world'=>0,'area'=>0,'subarea'=>0,'leaf'=>0];$ideas=0;$old=[];$live=[];
        foreach((array)($snap['nodes']??[]) as $n)if(is_array($n))$live[(string)($n['node_id']??'')]=$n;
        foreach((array)($p['nodes']??[]) as $n){
            if(!is_array($n))continue;$id=(string)($n['node_id']??'');
            if($id===''||isset($old[$id]))throw new RuntimeException('Doppelte/fehlende R2-ID.');$old[$id]=$n;
            foreach($counts as $level=>$count)if(str_starts_with($id,'core:'.$level.':')){
                $counts[$level]++;
                if(!isset($live[$id])||!isset($snap['mapping'][$id]))throw new RuntimeException('R2-ID nicht in aktivem Live-Readback: '.$id);
                foreach(['node_id','display_name','slug','parent_id','object_type'] as $k)if((string)($n[$k]??'')!==(string)($live[$id][$k]??''))throw new RuntimeException('R2-Feld weicht von aktivem Readback ab: '.$id.' / '.$k);
                if($level==='leaf'){
                    if(($n['supporting_intents']??null)!==($live[$id]['supporting_intents']??null))throw new RuntimeException('R2-Artikelideen gegenüber Live-Snapshot geändert: '.$id);
                    $ideas+=count((array)($n['supporting_intents']??[]));
                }
                break;
            }
        }
        if($counts!==['world'=>6,'area'=>31,'subarea'=>45,'leaf'=>141]||$ideas!==704)
            throw new RuntimeException('Falscher R2-Bestand: '.json_encode($counts).' Ideen='.$ideas.'; erwartet 6/31/45/141 und 704.');
        return ['counts'=>$counts,'ideas'=>$ideas,'old_core_nodes'=>223];
    }
    /** Read-only: verify actual WP objects, IDs, slugs, parents against frozen R2 snapshot. */
    public static function assert_live_objects(array $p,array $snap):int {
        if(!function_exists('get_post')||!function_exists('get_term'))throw new RuntimeException('WordPress-Live-Readback-Funktionen fehlen.');
        $read=0;
        foreach((array)($p['nodes']??[]) as $n){
            if(!is_array($n)||($n['status']??'active')!=='active'||($n['object_type']??'')==='relation')continue;
            $id=(string)$n['node_id'];$type=(string)$n['object_type'];$map=(array)($snap['mapping'][$id]??[]);$oid=(int)($map['object_id']??0);
            if($oid<=0)throw new RuntimeException('R2-Live-ID fehlt: '.$id);
            if($type==='page'){$obj=get_post($oid);$name=(string)($obj->post_title??'');$slug=(string)($obj->post_name??'');$parent=(int)($obj->post_parent??-1);$status=(string)($obj->post_status??'');if($status!=='publish')throw new RuntimeException('R2-Live-Seite ist nicht veröffentlicht: '.$id);}
            else{$obj=get_term($oid,$type);if(function_exists('is_wp_error')&&is_wp_error($obj))throw new RuntimeException('R2-Live-Term ungültig: '.$id);$name=(string)($obj->name??'');$slug=(string)($obj->slug??'');$parent=(int)($obj->parent??-1);}
            if(!$obj)throw new RuntimeException('R2-Live-Objekt nicht gefunden: '.$id);
            $name=html_entity_decode($name,ENT_QUOTES|ENT_HTML5,'UTF-8');
            $expectedParent=0;$pid=(string)($n['parent_id']??'');
            if($pid!==''){
                $parents=$snap['mapping'][$pid]??null;
                if($type==='page'&&is_array($parents)&&($parents['object_type']??'')==='page')$expectedParent=(int)$parents['object_id'];
                if($type!=='page'&&is_array($parents)&&($parents['object_type']??'')===$type)$expectedParent=(int)$parents['object_id'];
            }
            if($name!==(string)$n['display_name']||$slug!==(string)$n['slug']||$parent!==$expectedParent)
                throw new RuntimeException('R2-Live-Drift bei '.$id.' (Name/Slug/Elternteil): Import BLOCKED.');
            $read++;
        }
        return $read;
    }
    private static function slug(string $title):string {
        if(function_exists('sanitize_title'))return (string)sanitize_title($title);
        $ascii=iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$title);
        return trim((string)preg_replace('/-+/','-',(string)preg_replace('/[^a-z0-9]+/','-',strtolower($ascii!==false?$ascii:$title))),'-');
    }
    private static function digest(string $s,int $n=14):string{return substr(hash('sha256',$s),0,$n);}
    private static function node_name_ok(string $s):bool{return trim($s)!==''&&(function_exists('mb_strlen')?mb_strlen($s,'UTF-8'):(function_exists('iconv_strlen')?iconv_strlen($s,'UTF-8'):strlen($s)))<=36;}
    public static function compose(array $r2,array $manifest):array {
        self::source_invariants($manifest);
        $nodes=(array)($r2['nodes']??[]);$idx=[];$areas=[];$worlds=[];$leaves=[];$currentSlugs=[];
        foreach($nodes as $i=>$n){if(!is_array($n))throw new RuntimeException('R2-Knoten ungültig.');$id=(string)($n['node_id']??'');if($id===''||isset($idx[$id]))throw new RuntimeException('R2-Knoten-ID nicht eindeutig.');$idx[$id]=$i;
            if(str_starts_with($id,'core:world:'))$worlds[$n['display_name']]=$id;
            if(str_starts_with($id,'core:area:'))$areas[$n['parent_id'].'|'.$n['display_name']]=$id;
            if(str_starts_with($id,'core:leaf:'))$leaves[$n['display_name']]=$id;
            $type=$n['object_type']??'';$slug=$n['slug']??'';if($slug!=='')$currentSlugs[$type.'|'.$slug]=true;
        }
        $newSub=[];$newLeaves=[];$newNodes=[];
        foreach($manifest['candidates'] as $c){
            $world=(string)($c['world']??'');$area=(string)($c['area']??'');$sub=(string)($c['subarea']??'');$name=(string)($c['new_category']??'');
            if(!self::node_name_ok($sub)||!self::node_name_ok($name))throw new RuntimeException('Neuer Name zu lang/leer: '.$sub.' / '.$name);
            $wid=$worlds[$world]??'';$areaId=$areas[$wid.'|'.$area]??'';
            if($wid===''||$areaId==='')throw new RuntimeException('R3-Gebiet im echten R2-Baum nicht gefunden: '.$world.' / '.$area);
            $key=$wid.'|'.$areaId.'|'.$sub;
            if(!isset($newSub[$key])){
                $hash=self::digest('subarea|'.$key,16);$id='core:subarea:r3-'.$hash;
                $slug='r3-'.substr(self::slug($sub),0,48).'-'.substr($hash,0,8);
                $newSub[$key]=$id;
                $newNodes[]=['node_id'=>$id,'pillar'=>'core','object_type'=>'page','display_name'=>$sub,'slug'=>$slug,'parent_id'=>$areaId,'status'=>'active','seo_owner'=>true,'seo_seed'=>$sub,'primary_keyword'=>'','intent_key'=>'core-r3-subarea-'.$hash,'nav_order'=>90,'page_level'=>3,'content_role'=>'fachlicher-unterhub'];
            }
            if(isset($newLeaves[$name])||isset($leaves[$name]))throw new RuntimeException('R3-Kategorie-Doppelname: '.$name);
            $ideas=array_values(array_map('strval',(array)($c['other_article_ideas']??[])));
            if(count($ideas)!==3||count(array_unique($ideas))!==3||in_array('',array_map('trim',$ideas),true))throw new RuntimeException('R3-Artikelideen fehlen/doppeln bei '.$name);
            $hash=self::digest('leaf|'.$key.'|'.$name,16);$id='core:leaf:r3-'.$hash;
            $slug='r3-'.substr(self::slug($name),0,48).'-'.substr($hash,0,8);
            $newLeaves[$name]=$id;
            $newNodes[]=['node_id'=>$id,'pillar'=>'core','object_type'=>'category','display_name'=>$name,'slug'=>$slug,'parent_id'=>$newSub[$key],'status'=>'active','seo_owner'=>true,'seo_seed'=>$name,'primary_keyword'=>'','intent_key'=>'core-r3-leaf-'.$hash,'supporting_intents'=>$ideas,'intent_count'=>3,'content_status'=>'REDAKTIONELLER_FACHPLAN_SERP_OPTIONAL','article_intents_source'=>'Hab_und_Bewahr_R3_V8_20261013','page_level_owner'=>3];
        }
        if(count($newSub)!==48||count($newLeaves)!==144||count($newNodes)!==192)throw new RuntimeException('R3-Soll 48 Unterbereiche + 144 Kategorien nicht erreicht.');
        foreach($newNodes as $n){$id=$n['node_id'];$scope=$n['object_type'].'|'.$n['slug'];if(isset($idx[$id])||isset($currentSlugs[$scope]))throw new RuntimeException('R3-ID/Slug-Kollision '.$id);$currentSlugs[$scope]=true;$idx[$id]=count($nodes);$nodes[]=$n;}
        $nameToId=$leaves+$newLeaves;$moves=0;
        foreach(self::MOVES as [$from,$to,$title]){
            $fromId=$nameToId[$from]??'';$toId=$nameToId[$to]??'';
            if($fromId===''||$toId===''||$fromId===$toId)throw new RuntimeException('R3-Move Quell-/Ziel-Owner fehlt: '.$from.' → '.$to);
            $fromIndex=$idx[$fromId];$toIndex=$idx[$toId];$src=(array)$nodes[$fromIndex]['supporting_intents'];$dest=(array)$nodes[$toIndex]['supporting_intents'];
            $matches=array_keys($src,$title,true);
            if(count($matches)!==1||in_array($title,$dest,true))throw new RuntimeException('R3-Move Titel fehlt/ist schon am Ziel: '.$title);
            unset($src[$matches[0]]);$src=array_values($src);$dest[]=$title;
            if(count($src)<3)throw new RuntimeException('R2-Move hinterlässt weniger als 3 Ideen in '.$from);
            $nodes[$fromIndex]['supporting_intents']=$src;$nodes[$fromIndex]['intent_count']=count($src);
            $nodes[$toIndex]['supporting_intents']=$dest;$nodes[$toIndex]['intent_count']=count($dest);$moves++;
        }
        $r3=$r2;$r3['nodes']=$nodes;$r3['settings']['require_direct_child_3_to_10']=true;$r3['settings']['require_three_page_levels']=true;$r3['settings']['min_categories_per_third_page']=3;
        $r3['settings']['min_article_intents']=3;
        $r3['project']['revision']='HB-R3-V8-20261013-'.self::digest(json_encode($manifest['candidates'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),16);
        $r3['project']['profile_type']='R3_V8_EDITORIALLY_VALIDATED_NO_GOOGLE_VOLUME_REQUIRED_MANUAL_SYNC';
        $r3['editorial_evidence']['article_title_count']=1136;
        $r3['editorial_evidence']['r2_old_ideas_preserved']=704;
        $r3['editorial_evidence']['r3_added_ideas']=432;
        $r3['editorial_evidence']['r3_old_idea_moves']=19;
        $r3['editorial_evidence']['organic_serp_independence']='OPTIONAL_QUALITY_SIGNAL_NOT_CATEGORY_APPROVAL_GATE';
        $r3['r3_v8_source']=['baseline_revision'=>self::BASE_REV,'new_subareas'=>48,'new_categories'=>144,'new_ideas'=>432,'moved_old_ideas'=>$moves,'provider_calls'=>0,'requires_manual_final_dry_run'=>true,'merged_nodes_sha256'=>hash('sha256',json_encode($nodes,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))];
        self::tree_gate($r3);
        if(class_exists('APKW_TargetTree')){$v=APKW_TargetTree::validate($r3);if(empty($v['valid']))throw new RuntimeException('WordPress-Zielprofil-Validator BLOCKED: '.implode(', ',array_slice((array)$v['errors'],0,12)));}
        return $r3;
    }
    public static function source_invariants(array $manifest):void {
        if((int)($manifest['counts']['new_candidate_categories']??0)!==144||!isset($manifest['candidates'])||!is_array($manifest['candidates'])||count($manifest['candidates'])!==144)throw new RuntimeException('R3-Originalmatrix nicht 144.');
        $names=[];$groups=[];
        foreach($manifest['candidates'] as $x){if(!is_array($x))throw new RuntimeException('R3-Zeile ungültig.');$n=(string)($x['new_category']??'');$k=(string)($x['world']??'').'|'.(string)($x['area']??'').'|'.(string)($x['subarea']??'');if($n===''||isset($names[$n]))throw new RuntimeException('R3-Name doppelt/leer: '.$n);$names[$n]=true;$groups[$k]=($groups[$k]??0)+1;}
        if(count($groups)!==48||count(array_filter($groups,static fn($n)=>$n!==3)))throw new RuntimeException('R3-Grundstruktur ist nicht 48×3.');
    }
    public static function tree_gate(array $p):array {
        $core=[];$children=[];$counts=['world'=>0,'area'=>0,'subarea'=>0,'leaf'=>0];$ideas=0;
        foreach((array)($p['nodes']??[]) as $n){if(!is_array($n))continue;$id=(string)($n['node_id']??'');$parent=(string)($n['parent_id']??'');if($parent!=='')$children[$parent]=($children[$parent]??0)+1;foreach($counts as $k=>$_)if(str_starts_with($id,'core:'.$k.':')){$counts[$k]++;$core[$id]=$k;if($k==='leaf')$ideas+=count((array)($n['supporting_intents']??[]));break;}}
        if($counts!==['world'=>6,'area'=>31,'subarea'=>93,'leaf'=>285]||$ideas!==1136)throw new RuntimeException('R3-Zielbaum-Mengen nicht 6/31/93/285 + 1136 Artikelideen: '.json_encode($counts).'/'.$ideas);
        foreach($core as $id=>$kind)if($kind!=='leaf'){$number=$children[$id]??0;if($number<3||$number>10)throw new RuntimeException('3–10-Hard-Gate gescheitert: '.$id.' hat '.$number.' direkte Kinder.');}
        return ['counts'=>$counts,'article_ideas'=>$ideas,'all_direct_children_between_3_and_10'=>true];
    }
    /** Called again by BOTH existing WordPress dry-run and writer before any R3 write. */
    public static function guard_final_target(array $profile):void {
        if (isset($profile['v9_9_add_only'])) {
            if (!class_exists('APKW_V99_AddOnly') || !APKW_V99_AddOnly::guarded_r3($profile))
                throw new RuntimeException('V9.9 ADD-Schutz ungültig.');
            return;
        }
        if(!isset($profile['r3_v8_source'])) {
            $rev=(string)($profile['project']['base_revision']??$profile['project']['revision']??'');
            if(str_starts_with($rev,'HB-R3-V8-'))throw new RuntimeException('R3-Schreibschutz: Herkunftssignatur fehlt.');
            return;
        }
        if(!class_exists('APKW_TargetTreeRunner')||!APKW_TargetTreeRunner::manual_only())
            throw new RuntimeException('R3-Schreibschutz: automatischer Target-Tree-Lauf ist untersagt.');
        if((string)($profile['r3_v8_source']['baseline_revision']??'')!==self::BASE_REV)
            throw new RuntimeException('R3-Schreibschutz: falscher Original-R2-Revisionsvertrag.');
        $actualNodes=hash('sha256',json_encode((array)($profile['nodes']??[]),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        if(!hash_equals((string)($profile['r3_v8_source']['merged_nodes_sha256']??''),$actualNodes))
            throw new RuntimeException('R3-Schreibschutz: Zielbaum wurde nach Prüfung verändert.');
        self::tree_gate($profile);
        $backup=function_exists('get_option')?get_option(self::BACKUP_OPT,null):null;
        if(!is_array($backup)||!is_array($backup['profile']??null))throw new RuntimeException('R3-Schreibschutz: R2-Sicherungsprofil fehlt.');
        $old=$backup['profile'];
        $sha=hash('sha256',wp_json_encode($old,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        if(!hash_equals((string)($backup['sha256']??''),$sha)||($old['project']['revision']??'')!==self::BASE_REV)
            throw new RuntimeException('R3-Schreibschutz: Original-R2-Backup stimmt nicht.');
        $index=[];foreach((array)($profile['nodes']??[]) as $n)if(is_array($n))$index[(string)($n['node_id']??'')]=$n;
        foreach((array)($old['nodes']??[]) as $n){
            if(!is_array($n))continue;$id=(string)($n['node_id']??'');
            if(!isset($index[$id]))throw new RuntimeException('R3-Schreibschutz: alte R2-ID entfernt '.$id);
            foreach(['node_id','pillar','object_type','display_name','slug','parent_id','status'] as $k)
                if(($index[$id][$k]??null)!==($n[$k]??null))throw new RuntimeException('R3-Schreibschutz: R2-URL/Eltern/Name verändert '.$id.' / '.$k);
        }
        $active=APKW_TargetTreeSync::active_revision();$state=APKW_TargetTreeSync::state();$snap=APKW_TargetTreeSync::active_snapshot();
        if(!is_array($state)||($state['status']??'')!=='COMPLETE')throw new RuntimeException('R3-Schreibschutz: kein COMPLETE Live-Zielbaum.');
        if(str_starts_with($active,self::BASE_REV.'+')){
            self::baseline_invariants($old,$snap);
            self::assert_live_objects($old,$snap);
        }elseif(str_starts_with($active,(string)($profile['project']['base_revision']??$profile['project']['revision']??'').'+' )){
            self::assert_live_objects($profile,$snap);
        }else throw new RuntimeException('R3-Schreibschutz: WordPress-Live-Revision unbekannt: '.$active);
    }
    private static function generated(array $provided=[],?array $knownBaseline=null):array {
        $p=$knownBaseline??self::baseline(true);$manifest=self::source($provided);$merged=self::compose($p,$manifest);
        // Exact old tree nodes (names, parent, slug, IDs) MUST be unchanged; only article-intent moves authorized.
        $lookup=[];foreach($merged['nodes'] as $n)if(is_array($n))$lookup[$n['node_id']]=$n;
        foreach($p['nodes'] as $old){if(!is_array($old))continue;$id=(string)$old['node_id'];if(!isset($lookup[$id]))throw new RuntimeException('R2-Knoten ging verloren: '.$id);foreach(['node_id','pillar','object_type','display_name','slug','parent_id','status'] as $k)if(($old[$k]??null)!==($lookup[$id][$k]??null))throw new RuntimeException('R2-Knoten wurde unzulässig verändert: '.$id.' / '.$k);}
        return $merged;
    }
    public static function render():void {
        try{self::admin();$base=self::baseline();$nodes=count((array)$base['nodes']);$stat='R2-Profil/Snapshot OK, '.$nodes.' Knoten (vollständiger Live-Readback beim Prüfknopf)';$safe=true;}catch(Throwable $e){$stat=$e->getMessage();$safe=false;}
        echo '<div class="wrap"><h1>Hab &amp; Bewahr – R3/V8 Zielprofil</h1>';
        echo '<p><strong>Keine SEO-Abfragen und keine Artikel- oder Kategorieänderung durch die Prüfung.</strong> Die 141 alten Kategorien bleiben mit IDs, Slugs und Eltern erhalten. Der Plan ergänzt 48 Unterbereiche, 144 Kategorien, 432 neue Artikelideen und berücksichtigt 19 redaktionelle Artikelideen-Verschiebungen.</p>';
        echo '<p><strong>R2-Grundlage:</strong> '.esc_html($stat).'</p>';
        $u=self::SOURCE_URL;
        echo '<p>Das 144er-Konzept wird kostenfrei aus dem <a href="'.esc_url($u).'" target="_blank" rel="noopener">festen öffentlichen Projektstand</a> gelesen. Falls WordPress den Abruf blockiert, kann die Datei stattdessen im Formular ausgewählt werden.</p>';
        if($safe){
            foreach([['apkw_r3_v8_preview','Kostenlos prüfen – alle Originaldaten und 3–10-Regel','secondary'],['apkw_r3_v8_prepare','Geprüftes R3-Profil für bestehenden finalen Dry-Run bereitstellen','primary'],['apkw_r3_v8_export','Optional: vollständiges geprüftes Profil als JSON herunterladen','secondary']] as [$action,$label,$style]){
                echo '<form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="'.esc_attr($action).'">';wp_nonce_field($action);
                echo '<p><label>Optionaler Datei-Ersatz bei Verbindungsfehler: <input type="file" name="apkw_r3_v8_source" accept=".json,application/json"></label></p>';
                if($action==='apkw_r3_v8_prepare')echo '<p><label><input type="checkbox" name="apkw_r3_prepare_confirm" value="1" required> Ich möchte das geprüfte Zielprofil für den späteren MANUELLEN Dry-Run binden. Jetzt werden noch KEINE WordPress-Kategorien oder Beiträge verändert.</label></p>';
                submit_button($label,$style);echo '</form>';
            }
            echo '<p>Nach dem Bereitstellen folgt unter <strong>Portal-Kategorien → Finaler Zielbaum</strong> der bestehende read-only Live-Dry-Run. Nur dessen eigenes Bestätigungsformular kann den tatsächlichen Sync auslösen.</p>';
        }elseif(function_exists('get_option')&&is_array(get_option(self::BACKUP_OPT,null))&&
            str_starts_with(APKW_TargetTreeSync::active_revision(),self::BASE_REV.'+')){
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_r3_v8_restore">';wp_nonce_field('apkw_r3_v8_restore');submit_button('Gesichertes R2-Profil wiederherstellen (nur wenn noch kein R3-Sync lief)','secondary');echo '</form>';
        }
        echo '</div>';
    }
    private static function wp_error(Throwable $e):void {wp_die(esc_html($e->getMessage()),'R3/V8 BLOCKED',['response'=>409]);}
    public static function preview():void {
        try{self::admin();check_admin_referer('apkw_r3_v8_preview');$p=self::generated(self::uploaded_manifest());$g=self::tree_gate($p);
            wp_die('<p>PASS: <strong>6 Welten / 31 Bereiche / 93 Unterbereiche / 285 Kategorien / 1136 Artikelideen</strong>.</p><p>19 Artikelideen exakt einmal verschoben, R2-Knoten, Live-IDs, Slugs und Eltern überprüft.</p><p>Keine WordPress-Daten geschrieben. Zum R3/V8-Menü zurückkehren und „Geprüftes R3-Profil bereitstellen“ wählen.</p>','R3/V8 Prüfung PASS',['response'=>200]);
        }catch(Throwable $e){self::wp_error($e);}
    }
    public static function prepare():void {
        try{
            self::admin();check_admin_referer('apkw_r3_v8_prepare');if(empty($_POST['apkw_r3_prepare_confirm']))throw new RuntimeException('Ausdrückliche Zustimmung fehlt.');
            if(!class_exists('APKW_TargetTreeRunner')||!APKW_TargetTreeRunner::manual_only())throw new RuntimeException('Manueller Modus muss aktiv sein. Automatischer Sync verboten.');
            $old=self::baseline(true);$target=self::generated(self::uploaded_manifest(),$old);
            $sha=hash('sha256',wp_json_encode($old,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            $existing=get_option(self::BACKUP_OPT,null);
            if(is_array($existing) && (string)($existing['sha256']??'')!==$sha)throw new RuntimeException('R2-Backup existiert mit anderer Prüfsumme. Keine Überschreibung.');
            if(!is_array($existing)&&!add_option(self::BACKUP_OPT,['sha256'=>$sha,'revision'=>self::BASE_REV,'profile'=>$old],'','no'))throw new RuntimeException('R2-Backup konnte nicht unveränderbar angelegt werden.');
            if(!update_option(self::PROFILE_OPT,$target,false)){
                $fresh=get_option(self::PROFILE_OPT,null);
                if($fresh!==$target)throw new RuntimeException('R3-Profil konnte nicht bereitgestellt werden; R2-Backup bleibt erhalten.');
            }
            APKW_TargetTree::reset_cache();
            if(function_exists('delete_option'))delete_option('apkw_final_target_plan_v1');
            $url=admin_url('admin.php?page='.APKW_FinalTargetAdmin::PAGE_SLUG.'&apkw_final=profile-imported');
        }catch(Throwable $e){self::wp_error($e);}
        wp_safe_redirect($url);exit;
    }
    public static function restore():void {
        try{
            self::admin();check_admin_referer('apkw_r3_v8_restore');
            $backup=get_option(self::BACKUP_OPT,null);if(!is_array($backup)||!is_array($backup['profile']??null))throw new RuntimeException('R2-Backup fehlt.');
            $liveRev=APKW_TargetTreeSync::active_revision();if(!str_starts_with($liveRev,self::BASE_REV.'+'))throw new RuntimeException('Aktive R2-Revision fehlt, Rückkehr gesperrt.');
            $state=APKW_TargetTreeSync::state();if(!is_array($state)||($state['status']??'')!=='COMPLETE'||!str_starts_with((string)($state['revision']??''),self::BASE_REV.'+'))throw new RuntimeException('Nach R3-Sync kein automatisches R2-Restore.');
            $r2=$backup['profile'];$sha=hash('sha256',wp_json_encode($r2,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));if(!hash_equals((string)$backup['sha256'],$sha))throw new RuntimeException('Backup-Prüfsumme stimmt nicht.');
            if(!update_option(self::PROFILE_OPT,$r2,false)&&get_option(self::PROFILE_OPT,null)!==$r2)throw new RuntimeException('R2-Restore fehlgeschlagen.');
            APKW_TargetTree::reset_cache();if(function_exists('delete_option'))delete_option('apkw_final_target_plan_v1');
            $url=admin_url('admin.php?page='.APKW_FinalTargetAdmin::PAGE_SLUG);
        }catch(Throwable $e){self::wp_error($e);}
        wp_safe_redirect($url);exit;
    }
    public static function export():void {
        try{self::admin();check_admin_referer('apkw_r3_v8_export');$p=self::generated(self::uploaded_manifest());$json=wp_json_encode($p,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if(!is_string($json))throw new RuntimeException('Zielprofil nicht serialisierbar.');
            if(function_exists('nocache_headers'))nocache_headers();header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="hab-und-bewahr-r3-v8-ZIELPROFIL-20261013.json"');echo $json;exit;
        }catch(Throwable $e){self::wp_error($e);}
    }
}
