<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Human-readable, privacy-safe run log for the Portalbetrieb.
 * Stores only bounded summaries; credentials/auth/transient tokens are stripped recursively.
 */
final class APKW_RunLog {
    private const OPT='apkw_run_log_v1';
    private const MAX_ENTRIES=250;

    public static function record(string $stage,string $status,string $message,array $details=[]):array{
        $entries=self::all();
        $entry=[
            'id'=>self::id(),
            'at_utc'=>gmdate('c'),
            'stage'=>self::clean_text($stage,80),
            'status'=>self::clean_text($status,40),
            'message'=>self::clean_text($message,500),
            'user_id'=>function_exists('get_current_user_id')?(int)get_current_user_id():0,
            'details'=>self::sanitize($details),
        ];
        $entries[]=$entry;
        if(count($entries)>self::MAX_ENTRIES)$entries=array_slice($entries,-self::MAX_ENTRIES);
        update_option(self::OPT,$entries,false);
        return $entry;
    }

    public static function all():array{
        $value=get_option(self::OPT,[]);
        return is_array($value)?array_values(array_filter($value,'is_array')):[];
    }

    public static function latest(int $limit=100):array{
        $limit=max(1,min(self::MAX_ENTRIES,$limit));
        return array_reverse(array_slice(self::all(),-$limit));
    }

    public static function clear():void{update_option(self::OPT,[],false);}

    public static function total_recorded_cost_usd():float{
        $sum=0.0;
        foreach(self::all() as $entry){
            $d=is_array($entry['details']??null)?$entry['details']:[];
            if(isset($d['event_cost_usd'])&&is_numeric($d['event_cost_usd']))$sum+=(float)$d['event_cost_usd'];
        }
        return $sum;
    }

    private static function sanitize($value,$key=''){
        if(self::sensitive_key((string)$key))return '[REDACTED]';
        if(is_array($value)){
            $out=[];$count=0;
            foreach($value as $k=>$v){
                if($count>=100){$out['_truncated']='Weitere Details gekürzt.';break;}
                if(self::sensitive_key((string)$k)){$out[$k]='[REDACTED]';$count++;continue;}
                $out[$k]=self::sanitize($v,(string)$k);$count++;
            }
            return $out;
        }
        if(is_object($value))return '[OBJECT]';
        if(is_bool($value)||is_int($value)||is_float($value)||$value===null)return $value;
        return self::clean_text((string)$value,2000);
    }

    private static function sensitive_key(string $key):bool{
        $key=strtolower($key);
        foreach(['password','passwd','login','authorization','credential','secret','api_key','apikey','access_token','refresh_token','nonce','transient_token'] as $needle){
            if(str_contains($key,$needle))return true;
        }
        return false;
    }

    private static function clean_text(string $value,int $max):string{
        $value=trim(preg_replace('/\\s+/u',' ',$value));
        if(function_exists('mb_substr'))return mb_substr($value,0,$max,'UTF-8');
        return substr($value,0,$max);
    }

    private static function id():string{
        if(function_exists('wp_generate_uuid4'))return (string)wp_generate_uuid4();
        try{return substr(hash('sha256',microtime(true).'|'.random_bytes(16)),0,24);}catch(Throwable $e){return substr(hash('sha256',microtime(true).'|'.mt_rand()),0,24);}
    }
}
