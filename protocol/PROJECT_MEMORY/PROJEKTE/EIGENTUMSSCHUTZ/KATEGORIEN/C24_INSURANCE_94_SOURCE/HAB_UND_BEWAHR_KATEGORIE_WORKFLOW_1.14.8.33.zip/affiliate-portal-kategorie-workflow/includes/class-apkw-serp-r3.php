<?php
if (!defined('ABSPATH')) { exit; }
/** Isolated, profile-independent R3 SERP research. The legacy 20-pair reviewer is NOT modified. */
final class APKW_R3_SERP_Review {
    private const PAGE='apkw-hab-r3-serp-review';
    private const PLAN='apkw_hab_r3_serp_preflight_v1';
    private const INDEX='apkw_hab_r3_serp_index_v1';
    private const MUTEX='apkw_hab_r3_serp_paid_mutex_v1';
    private const MAX_PAIRS=40;
    public static function init(): void {
        if (!function_exists('add_action'))return;
        add_action('admin_menu',[__CLASS__,'menu'],41);
        add_action('admin_post_apkw_r3_serp_preflight',[__CLASS__,'preflight']);
        add_action('admin_post_apkw_r3_serp_start',[__CLASS__,'start']);
        add_action('wp_ajax_apkw_r3_serp_advance',[__CLASS__,'advance']);
        add_action('admin_post_apkw_r3_serp_skip',[__CLASS__,'skip']);
        add_action('admin_post_apkw_r3_serp_export',[__CLASS__,'export']);
    }
    public static function menu(): void {
        add_submenu_page(APKW_FinalTargetAdmin::PAGE_SLUG,'R3 – organischer SERP-Abgleich','R3 SERP-Abgleich',
            'manage_options',self::PAGE,[__CLASS__,'render']);
    }
    private static function cap():void {
        if (!current_user_can('manage_options'))wp_die('Nur Administratoren.','Nicht autorisiert',['response'=>403]);
    }
    private static function key(string $s):string {
        $s=trim(preg_replace('/\s+/u',' ',$s)??'');
        return function_exists('mb_strtolower')?mb_strtolower($s,'UTF-8'):strtolower($s);
    }
    private static function clean(string $s,int $limit=200):string {
        if(preg_match('/[\x00-\x1F\x7F]/',$s)) throw new RuntimeException('Steuerzeichen in Suchbegriff oder Bezeichner.');
        $s=trim(preg_replace('/\s+/u',' ',$s)??'');
        $n=function_exists('mb_strlen')?mb_strlen($s,'UTF-8'):strlen($s);
        if($n<3 || $n>$limit) throw new RuntimeException('Ungültiger Suchbegriff oder Bezeichner.');
        return $s;
    }
    /** PURE validator; no provider calls, no WP writes. */
    public static function validate(array $doc):array {
        if(($doc['contract']??null)!=='HB_R3_SERP_UPLOAD_V1')throw new RuntimeException('Falscher R3-SERP-Dateivertrag.');
        if(($doc['location_name']??null)!=='Germany'||($doc['language_code']??null)!=='de')
            throw new RuntimeException('Nur Germany/de ist für den R3-Plan freigegeben.');
        $pairs=$doc['pairs']??null;
        if(!is_array($pairs)||array_keys($pairs)!==range(0,count($pairs)-1)||count($pairs)<1||count($pairs)>self::MAX_PAIRS)
            throw new RuntimeException('Prüfplan benötigt 1 bis 40 Suchpaare.');
        $clean=[];$keywords=[];$names=[];
        foreach($pairs as $p){
            if(!is_array($p)||!is_string($p['candidate_category']??null)||!is_string($p['comparison_label']??null))
                throw new RuntimeException('Suchpaar ohne eindeutige Fachzuordnung.');
            $name=self::clean($p['candidate_category']);$comparison=self::clean($p['comparison_label']);
            $kw=$p['keywords']??null;
            if(!is_array($kw)||count($kw)!==2||array_keys($kw)!==[0,1])throw new RuntimeException('Jedes R3-Feld benötigt genau zwei Keywords.');
            $pair=[];
            foreach($kw as $term){
                if(!is_string($term))throw new RuntimeException('SERP-Keyword ist kein Text.');
                $term=self::clean($term);
                if(preg_match('/(?:^|\s)(?:allinanchor|allintext|allintitle|allinurl|cache|define|filetype|id|inanchor|info|intext|intitle|inurl|link|related|site):/i',$term))
                    throw new RuntimeException('Suchoperator in bezahlter Anfrage gesperrt.');
                $k=self::key($term);if(isset($keywords[$k]))throw new RuntimeException('Doppeltes SERP-Keyword: '.$term);
                $keywords[$k]=true;$pair[]=$term;
            }
            if(isset($names[self::key($name)]))throw new RuntimeException('Doppelte Kandidatenkategorie.');
            $names[self::key($name)]=true;
            $clean[]=['candidate_category'=>$name,'comparison_label'=>$comparison,'keywords'=>$pair];
        }
        $settings=APKW_Settings::defaults();
        if((string)($settings['location_name']??'')!=='Germany'||(string)($settings['language_code']??'')!=='de')
            throw new RuntimeException('WordPress-DataForSEO-Einstellungen stimmen nicht mit Germany/de überein.');
        $canonical=['contract'=>'HB_R3_SERP_UPLOAD_V1','location_name'=>'Germany','language_code'=>'de','pairs'=>$clean];
        $body=wp_json_encode($canonical,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if(!is_string($body))throw new RuntimeException('R3-Prüfplan kann nicht kodiert werden.');
        $canonical['sha256']=hash('sha256',$body);
        $canonical['keywords_flat']=array_merge(...array_map(static fn($p)=>$p['keywords'],$clean));
        return $canonical;
    }
    private static function run_key(string $hash):string{return 'apkw_hab_r3_serp_run_'.substr($hash,0,40);}
    private static function active():array {
        $plan=get_option(self::PLAN,false);
        if(!is_array($plan)||!preg_match('/^[a-f0-9]{64}$/',(string)($plan['sha256']??'')))return [false,false];
        return [$plan,get_option(self::run_key($plan['sha256']),false)];
    }
    private static function redirect():void {wp_safe_redirect(admin_url('admin.php?page='.self::PAGE));exit;}
    public static function preflight():void {
        self::cap();check_admin_referer('apkw_r3_serp_preflight');
        try{
            [$old,$s]=self::active();
            if(is_array($s)&&!in_array((string)($s['status']??''),['COMPLETE'],true))
                throw new RuntimeException('Ein R3-Lauf ist aktiv oder gesperrt. Erst archivieren/prüfen, keinen neuen Plan darüberlegen.');
            $f=(array)($_FILES['apkw_r3_serp_file']??[]);
            if((int)($f['error']??99)!==UPLOAD_ERR_OK||(int)($f['size']??0)<2||(int)($f['size']??0)>102400)
                throw new RuntimeException('R3-JSON fehlt oder ist größer als 100 KB.');
            $raw=file_get_contents((string)($f['tmp_name']??''));
            if(!is_string($raw)||strlen($raw)>102400)throw new RuntimeException('JSON nicht lesbar.');
            $j=json_decode($raw,true,512,JSON_THROW_ON_ERROR);
            if(!is_array($j))throw new RuntimeException('JSON-Objekt fehlt.');
            $plan=self::validate($j);
            // Never erase previous evidence: one immutable state per canonical plan hash.
            update_option(self::PLAN,$plan,false);
        }catch(Throwable $e){wp_die(esc_html($e->getMessage()),'R3-SERP Vorprüfung BLOCKED',['response'=>400]);}
        self::redirect();
    }
    public static function start():void {
        self::cap();check_admin_referer('apkw_r3_serp_start');
        if((string)($_POST['apkw_r3_serp_consent']??'')!=='1')wp_die('Ausdrückliche einmalige Kostenfreigabe fehlt.');
        [$plan,$old]=self::active();
        if(!is_array($plan))wp_die('Kein kostenlos geprüfter R3-Prüfplan.');
        try{
            $checked=self::validate($plan);
            if(!hash_equals((string)($plan['sha256']??''),$checked['sha256']))throw new RuntimeException('R3-Dateibindung geändert.');
            $creds=APKW_Settings::credentials();
            if(empty($creds['login'])||empty($creds['password']))throw new RuntimeException('WordPress-DataForSEO-Zugang fehlt.');
            $record=['contract'=>'HB_R3_SERP_PAID_ONCE_RESULT_V1','status'=>'RUNNING',
                'plan_hash'=>$checked['sha256'],'created_utc'=>gmdate('c'),
                'market'=>['location_name'=>'Germany','language_code'=>'de'],
                'pairs'=>$checked['pairs'],'keywords'=>$checked['keywords_flat'],'index'=>0,
                'results'=>[],'errors'=>[],'skipped_keywords'=>[],'known_cost_usd'=>0,
                'writes_to_categories'=>0,'writes_to_articles'=>0];
            if(!add_option(self::run_key($checked['sha256']),$record,'',false))throw new RuntimeException('Dieser Prüfplan wurde bereits begonnen. Keine Doppelabrechnung.');
            $index=(array)get_option(self::INDEX,[]);
            if(!in_array($checked['sha256'],$index,true)){$index[]=$checked['sha256'];update_option(self::INDEX,$index,false);}
        }catch(Throwable $e){wp_die(esc_html($e->getMessage()),'R3-SERP Start BLOCKED',['response'=>400]);}
        self::redirect();
    }
    private static function eligible_cache(string $keyword,array $s):?array {
        $legacy=get_option('apkw_hab_serp_20_audit_v1',false);
        $sources=[];
        if(is_array($legacy))$sources[]=['run'=>$legacy,'ref'=>'R2_20_SERP'];
        foreach((array)get_option(self::INDEX,[]) as $hash){
            if(!is_string($hash)||!preg_match('/^[0-9a-f]{64}$/',$hash)||$hash===$s['plan_hash'])continue;
            $old=get_option(self::run_key($hash),false);
            if(is_array($old))$sources[]=['run'=>$old,'ref'=>'R3_PREVIOUS'];
        }
        foreach($sources as $source){
            $run=$source['run'];
            foreach((array)($run['results']??[])as $row){
                if(!is_array($row)||self::key((string)($row['keyword']??''))!==self::key($keyword))continue;
                if((int)($row['task_status_code']??0)!==20000||!is_array($row['organic_top10']??null))continue;
                return [
                    'keyword'=>$keyword,'task_id'=>(string)($row['task_id']??''),
                    'task_status_code'=>20000,'cost_usd'=>0,'organic_top10'=>$row['organic_top10'],
                    'organic_returned'=>count($row['organic_top10']),
                    'checked_utc'=>(string)($row['checked_utc']??''),
                    'status'=>'REUSED_PREVIOUS_PAID_RESULT','source'=>$source['ref'],
                    'original_cost_not_billed_again'=>$row['cost_usd']??null,
                ];
            }
        }
        return null;
    }
    private static function progress(array $s):array {
        return ['status'=>(string)($s['status']??''),'index'=>(int)($s['index']??0),
            'total'=>count((array)($s['keywords']??[])),
            'known_cost_usd'=>(float)($s['known_cost_usd']??0),
            'terminal'=>(string)($s['status']??'')==='COMPLETE'];
    }
    public static function advance():void {
        self::cap();
        if(!check_ajax_referer('apkw_r3_serp_advance','_ajax_nonce',false))wp_send_json_error(['message'=>'Sicherheitsfreigabe abgelaufen.'],403);
        [$plan,$s]=self::active();
        if(!is_array($plan)||!is_array($s))wp_send_json_error(['message'=>'Kein freigegebener R3-Lauf.'],400);
        if(($s['status']??'')==='COMPLETE')wp_send_json_success(self::progress($s));
        if(($s['status']??'')!=='RUNNING')wp_send_json_error(['message'=>'R3-Lauf gesperrt, kein automatischer Retry.'],409);
        try{
            $checked=self::validate($plan);
            if(!hash_equals((string)$s['plan_hash'],$checked['sha256'])||($s['keywords']??[])!==$checked['keywords_flat'])
                throw new RuntimeException('R3-Prüfplan geändert.');
        }catch(Throwable $e){
            $s['status']='BLOCKED_PLAN_CHANGED';update_option(self::run_key((string)$s['plan_hash']),$s,false);
            wp_send_json_error(['message'=>'Prüfplan geändert, gesperrt.'],409);
        }
        $i=(int)$s['index'];$total=count($s['keywords']);
        if($i>=$total){$s['status']='COMPLETE';$s['finished_utc']=gmdate('c');update_option(self::run_key($s['plan_hash']),$s,false);wp_send_json_success(self::progress($s));}
        if(!add_option(self::MUTEX,gmdate('c'),'',false))wp_send_json_error(['message'=>'Bereits reservierte R3-Anfrage.'],409);
        $fresh=get_option(self::run_key($s['plan_hash']),false);
        if(!is_array($fresh)||($fresh['status']??'')!=='RUNNING'||(int)($fresh['index']??-1)!==$i){delete_option(self::MUTEX);wp_send_json_error(['message'=>'R3-Zustand geändert.'],409);}
        $s=$fresh;$word=(string)$s['keywords'][$i];
        // Reservation persisted BEFORE checking cache or issuing a billable call.
        $s['status']='IN_FLIGHT';$s['in_flight_keyword']=$word;$s['in_flight_since_utc']=gmdate('c');
        update_option(self::run_key($s['plan_hash']),$s,false);
        try{
            $cached=self::eligible_cache($word,$s);
            if(is_array($cached)){$r=$cached;}
            else {$r=APKW_DataForSEO::organic_serp_top10($word,'Germany','de','hb-r3-serp-'.substr($s['plan_hash'],0,15).'-'.$i);}
            $s['results'][]=$r;
            if(!isset($r['source']) && is_numeric($r['cost_usd']??null))$s['known_cost_usd']+=(float)$r['cost_usd'];
            $s['index']=$i+1;unset($s['in_flight_keyword'],$s['in_flight_since_utc']);
            $s['status']=$s['index']===$total?'COMPLETE':'RUNNING';
            if($s['status']==='COMPLETE')$s['finished_utc']=gmdate('c');
            update_option(self::run_key($s['plan_hash']),$s,false);
        }catch(APKW_SERP_ProviderTaskError $e){
            $ev=$e->evidence();
            $s['errors'][]=['keyword'=>$word,'message'=>$e->getMessage(),'provider'=>$ev,'utc'=>gmdate('c')];
            if(is_numeric($ev['cost_usd']??null))$s['known_cost_usd']+=(float)$ev['cost_usd'];
            $confirmedTask=(string)($ev['evidence_scope']??'')==='provider_task'&&
                (string)($ev['task_id']??'')!==''&&is_numeric($ev['cost_usd']??null);
            $confirmedEnvelope=(string)($ev['evidence_scope']??'')==='provider_response'&&
                (int)($ev['http_code']??0)===200;
            if((int)($ev['task_status_code']??0)===40101 &&(string)($ev['keyword']??'')===$word&&($confirmedTask||$confirmedEnvelope)){
                $s['results'][]=['keyword'=>$word,'task_id'=>(string)($ev['task_id']??''),
                    'task_status_code'=>40101,'cost_usd'=>$ev['cost_usd']??null,
                    'organic_top10'=>[],'organic_returned'=>0,'status'=>'PROVIDER_ERROR_SKIPPED',
                    'note'=>'Bestaetigter 40101: nicht erneut angefragt.'];
                $s['skipped_keywords'][]=$word;$s['index']=$i+1;
                unset($s['in_flight_keyword'],$s['in_flight_since_utc']);
                $s['status']=$s['index']===$total?'COMPLETE':'RUNNING';
                if($s['status']==='COMPLETE')$s['finished_utc']=gmdate('c');
            }else{$s['status']='BLOCKED_PROVIDER_TASK';$s['failed_task']=$ev;}
            update_option(self::run_key($s['plan_hash']),$s,false);
        }catch(Throwable $e){
            $s['status']='BLOCKED_INDETERMINATE_BILLING';
            $s['errors'][]=['keyword'=>$word,'message'=>$e->getMessage(),'utc'=>gmdate('c')];
            update_option(self::run_key($s['plan_hash']),$s,false);
        }
        delete_option(self::MUTEX);
        if(in_array($s['status'],['BLOCKED_PROVIDER_TASK','BLOCKED_INDETERMINATE_BILLING'],true))
            wp_send_json_error(['message'=>'R3-Anfrage gestoppt; Kostenstatus prüfen. Kein automatischer Retry.'],409);
        wp_send_json_success(self::progress($s));
    }
    public static function skip():void {
        self::cap();check_admin_referer('apkw_r3_serp_skip');
        if((string)($_POST['apkw_r3_serp_consent']??'')!=='1')wp_die('Freigabe weiterer kostenpflichtiger SERP-Abfragen fehlt.');
        [$plan,$s]=self::active();
        if(!is_array($plan)||!is_array($s)||!in_array((string)($s['status']??''),['BLOCKED_PROVIDER_TASK','BLOCKED_INDETERMINATE_BILLING'],true))
            wp_die('Kein überspringbarer gesperrter R3-Lauf.');
        $i=(int)($s['index']??-1);
        if($i<0||$i>=count($s['keywords'])||count((array)$s['results'])!==$i||
            (string)($s['in_flight_keyword']??'')!==(string)$s['keywords'][$i]||
            empty($s['in_flight_since_utc']))wp_die('Kein eindeutiger fehlgeschlagener SERP-Slot.');
        try{$checked=self::validate($plan);if(!hash_equals($checked['sha256'],$s['plan_hash']))throw new RuntimeException('Plan geändert.');}
        catch(Throwable $e){wp_die('Prüfplan hat sich geändert.');}
        if(!add_option(self::MUTEX,gmdate('c'),'',false))wp_die('R3-Kostenaktion bereits reserviert.');
        $fresh=get_option(self::run_key($s['plan_hash']),false);
        if(!is_array($fresh)||($fresh['status']??'')!==$s['status']||(int)($fresh['index']??-1)!==$i){
            delete_option(self::MUTEX);wp_die('R3-Zustand hat sich geändert.');
        }
        $s=$fresh;$word=$s['keywords'][$i];$err=(array)($s['errors']??[]);$last=$err?end($err):[];
        if((string)($last['keyword']??'')!==$word){delete_option(self::MUTEX);wp_die('Fehlerbeleg stimmt nicht zum Wort.');}
        $s['results'][]=['keyword'=>$word,'task_id'=>'','task_status_code'=>null,
            'cost_usd'=>null,'organic_top10'=>[],'organic_returned'=>0,
            'status'=>'UNVERIFIED_ERROR_SKIPPED','note'=>'Einmalig manuell uebersprungen, keine Wiederholung. Kosten/Task unklar.'];
        $s['skipped_keywords'][]=$word;$s['index']=$i+1;
        unset($s['in_flight_keyword'],$s['in_flight_since_utc'],$s['failed_task']);
        $s['status']=$s['index']===count($s['keywords'])?'COMPLETE':'RUNNING';
        if($s['status']==='COMPLETE')$s['finished_utc']=gmdate('c');
        update_option(self::run_key($s['plan_hash']),$s,false);delete_option(self::MUTEX);self::redirect();
    }
    private static function url_key(string $url):string {
        $p=parse_url($url);if(!is_array($p)||empty($p['host']))return '';
        $host=preg_replace('/^www\./i','',strtolower((string)$p['host']));
        $path=rawurldecode((string)($p['path']??'/'));return $host.'/'.trim($path,'/');
    }
    public static function overlaps(array $s):array {
        $out=[];$results=(array)($s['results']??[]);
        foreach((array)($s['pairs']??[])as $i=>$p){
            $a=$results[2*$i]??null;$b=$results[2*$i+1]??null;
            $xs=[];$ys=[];
            $ok=static function($r){return is_array($r)&&in_array((int)($r['task_status_code']??0),[20000],true)&&is_array($r['organic_top10']??null);};
            if(!$ok($a)||!$ok($b)){
                $out[]=['candidate_category'=>$p['candidate_category'],'comparison_label'=>$p['comparison_label'],
                    'keywords'=>$p['keywords'],'status'=>'NOT_MEASURED','overlap_top10_count'=>null,'common_urls'=>[]];continue;
            }
            foreach($a['organic_top10'] as $r){$u=self::url_key((string)($r['url']??''));if($u!=='')$xs[$u]=true;}
            foreach($b['organic_top10'] as $r){$u=self::url_key((string)($r['url']??''));if($u!=='')$ys[$u]=true;}
            $common=array_keys(array_intersect_key($xs,$ys));
            $out[]=['candidate_category'=>$p['candidate_category'],'comparison_label'=>$p['comparison_label'],
                'keywords'=>$p['keywords'],'status'=>count($xs)>=3&&count($ys)>=3?'MEASURED_REVIEW_REQUIRED':'INSUFFICIENT_ORGANIC_RESULTS',
                'overlap_top10_count'=>count($common),'common_urls'=>$common,
                'warning'=>'Overlap ist nur Indiz; keine automatische SEO-Owner-Freigabe'];
        }return $out;
    }
    public static function export():void {
        self::cap();check_admin_referer('apkw_r3_serp_export');[$plan,$s]=self::active();
        $asked=(string)($_POST['apkw_r3_serp_export_hash']??'');
        if($asked!==''){
            $allowed=(array)get_option(self::INDEX,[]);
            if(!preg_match('/^[a-f0-9]{64}$/',$asked)||!in_array($asked,$allowed,true))wp_die('Unbekannter R3-Prueflauf.');
            $s=get_option(self::run_key($asked),false);
        }
        if(!is_array($s))wp_die('Kein R3-SERP-Export vorhanden.');
        $s['overlap_analysis']=self::overlaps($s);
        $json=wp_json_encode($s,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if(!is_string($json))wp_die('SERP-Ergebnis kann nicht kodiert werden.');
        nocache_headers();header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="hab-bewahr-r3-serp-'.gmdate('Ymd-His').'-utc.json"');
        echo $json;exit;
    }
    public static function render():void {
        self::cap();[$plan,$s]=self::active();
        echo '<div class="wrap"><h1>Hab &amp; Bewahr – R3 SERP-Abgleich</h1>';
        echo '<p>Nur neue R3-SEO-Vergleichssuchen. Alte 20 R2-Paare, deren Speicher und alte Menüfunktion bleiben unverändert. KEINE Kategorie-, Profil- oder Artikel-Schreibvorgänge.</p>';
        echo '<p>Google Organic Live Top 10, Germany/de, je Keyword ein einzelner potenziell kostenpflichtiger Aufruf. Anbieterpreis nicht vorhersagbar; explizite Kostenfreigabe erforderlich. Prüfdaten sind keine automatische SEO-Freigabe.</p>';
        if(!is_array($s)||($s['status']??'')==='COMPLETE'){
            echo '<h2>1. R3-Suchpaare kostenlos prüfen</h2><form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_r3_serp_preflight">';
            wp_nonce_field('apkw_r3_serp_preflight');
            echo '<input type="file" name="apkw_r3_serp_file" accept=".json,application/json" required>';
            submit_button('R3-Prüfplan kostenlos prüfen','secondary');echo '</form>';
        }
        if(is_array($plan)){
            $n=count($plan['keywords_flat']);
            echo '<h2>2. Kostenpflichtige Suchpaare ausdrücklich freigeben</h2><p>'.count($plan['pairs']).' Suchpaare · '.(int)$n.' Suchbegriffe · Plan SHA-256: <code>'.esc_html($plan['sha256']).'</code></p>';
            if(!is_array($s)){
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_r3_serp_start">';
                wp_nonce_field('apkw_r3_serp_start');
                echo '<p><label><input type="checkbox" required name="apkw_r3_serp_consent" value="1"> Ich gebe diese einmalige kostenpflichtige R3-SERP-Prüfung ausdrücklich frei.</label></p>';
                submit_button('R3-SERP-Prüfung einmal starten');echo '</form>';
            }
            echo '<h3>Geplante Paare</h3><ol>';
            foreach($plan['pairs'] as $p)echo '<li><strong>'.esc_html($p['candidate_category']).'</strong> – '.esc_html($p['comparison_label']).': '.esc_html(implode(' | ',$p['keywords'])).'</li>';
            echo '</ol>';
        }
        if(is_array($s)){
            echo '<h2>Status: '.esc_html($s['status']).'</h2><p>'.(int)$s['index'].' / '.count($s['keywords']).' · Gemeldete Kosten $'.esc_html((string)round((float)$s['known_cost_usd'],5)).'</p>';
            if($s['status']==='RUNNING'){
                echo '<div id="apkw-r3-serp-progress">Lauf setzt mit dem naechsten, noch nicht reservierten Keyword fort.</div>';
                echo '<script>(function(){var nonce='.wp_json_encode(wp_create_nonce('apkw_r3_serp_advance')).';var active=true;function step(){if(!active)return;var b=new URLSearchParams({action:"apkw_r3_serp_advance",_ajax_nonce:nonce});fetch(ajaxurl,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"},body:b.toString()}).then(function(r){return r.text().then(function(t){var j;try{j=JSON.parse(t);}catch(e){throw new Error("Ungueltige Antwort; kein automatischer Retry.");}if(!j.success)throw new Error(j.data&&j.data.message||"R3 gesperrt");return j.data;});}).then(function(d){document.getElementById("apkw-r3-serp-progress").textContent="R3-SERPs: "+d.index+" / "+d.total+" · Kosten: $"+d.known_cost_usd;if(d.terminal){active=false;location.reload();return;}setTimeout(step,350);}).catch(function(e){active=false;document.getElementById("apkw-r3-serp-progress").textContent="STOP: "+e.message+". Keine automatische Wiederholung!";});}setTimeout(step,200);})();</script>';
            } elseif($s['status']==='COMPLETE'){
                echo '<p><strong>Prüflauf abgeschlossen – noch keine SEO-Owner-Freigabe.</strong></p>';
                foreach(self::overlaps($s) as $r){echo '<p>'.esc_html($r['candidate_category']).': '.esc_html((string)($r['overlap_top10_count']??'—')).' gemeinsame URLs · '.esc_html($r['status']).'</p>';}
            } else {
                echo '<p><strong>STOP – keine automatische Wiederholung und kein Kostenaufruf nach Fehler.</strong></p>';
                if(in_array($s['status'],['BLOCKED_PROVIDER_TASK','BLOCKED_INDETERMINATE_BILLING'],true)){
                    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_r3_serp_skip">';wp_nonce_field('apkw_r3_serp_skip');
                    echo '<p><label><input type="checkbox" name="apkw_r3_serp_consent" value="1" required> Fehlerhafte Einzelanfrage NICHT wiederholen. Ihre Kosten können unbekannt sein. Ich bestätige das Überspringen und die kostenpflichtigen restlichen Suchanfragen.</label></p>';
                    submit_button('R3-Fehler überspringen und Rest fortsetzen','secondary');echo '</form>';
                }
            }
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_r3_serp_export">';wp_nonce_field('apkw_r3_serp_export');submit_button('R3-SERP-Ergebnisse als JSON herunterladen','secondary');echo '</form>';
        }
        $index=(array)get_option(self::INDEX,[]);
        if($index){
            echo '<h2>Gespeicherte R3-Läufe</h2>';
            foreach($index as $hash){
                if(!is_string($hash)||!preg_match('/^[0-9a-f]{64}$/',$hash))continue;
                $previous=get_option(self::run_key($hash),false);
                if(!is_array($previous))continue;
                echo '<p>'.esc_html(substr($hash,0,16)).' – '.esc_html((string)($previous['status']??'')).' – '.(int)($previous['index']??0).'/'.count((array)($previous['keywords']??[]));
                echo '<form method="post" style="display:inline;margin-left:1em" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_r3_serp_export"><input type="hidden" name="apkw_r3_serp_export_hash" value="'.esc_attr($hash).'">';
                wp_nonce_field('apkw_r3_serp_export');submit_button('Gespeicherten R3-Lauf als JSON herunterladen','secondary');echo '</form></p>';
            }
        }
        echo '</div>';
    }
}
