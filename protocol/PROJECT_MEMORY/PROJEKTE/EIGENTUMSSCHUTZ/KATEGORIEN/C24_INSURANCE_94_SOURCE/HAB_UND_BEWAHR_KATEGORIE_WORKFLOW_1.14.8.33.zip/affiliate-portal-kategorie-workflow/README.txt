1.14.8.30 – UNABHÄNGIGE NAVIGATIONS-INTEGRITÄT (keine DB-Migration)
Readback prüft unabhängig von der HTML-Ausgabe jede sichtbare Menüquelle und alle 172 C2.2-Themenseiten anhand realer WP-Objekt-IDs, Meta-Bindungen und verfügbarer Permalinks. Fehlender Link, wiederverwendete Eltern-ID, falsche Elternbindung oder verwaistes Thema => BLOCKED. Der öffentliche Linkrenderer lehnt C2.2-Themen mit falscher WP-Bindung ab. Terminale Artikelkategorien müssen eine reale Archiv-URL besitzen. Kein erneuter Import, keine Artikel, keine DataForSEO-Anfrage. Die lokalen Tests nutzen WordPress-Mocks; Live-Theme/Browserprüfung ist davon getrennt.

1.14.8.29 – NAVIGATIONSPFAD-KORREKTUR (keine DB-Migration)

Befund am Live-C2.2-Baum: originaler Schutzbereich Wasser & Feuchtigkeit → Frost & Abwesenheit enthält bereits die historische R3-Sammelseite "Frost & Leerstand". Deren WordPress-Kategorien "Wasserleitungen gegen Frost", "Ferienhaus & Wasserschäden" usw. sind flache Endkategorien und bilden keine weitere Themenhierarchie. Neben diesem Altbestand existieren seit C2.2 konkrete Themenseiten; die bisherige Darstellung vermischte beides und erzeugte scheinbare Navigationsschleifen.

Korrektur nur an der Lesedarstellung:
- Schutzbereich → neue konkrete C2.2-Themenseiten → flache Artikelkategorien (Ende). Alte Sammelseiten erscheinen nicht mehr als Vorwärtskategorie, bleiben aber unter dem geschlossenen Block "Bisherige Sammelseiten (Archiv)" erreichbar.
- Megamenü einheitlich: maximal fünf direkte Schutzbereiche je Welt, vier konkrete Themen je Schutzbereich, immer ein eindeutig beschrifteter Übersichtslink; fehlende Zeilen sind leere optische Abstandshalter, keine künstlichen Inhalte.
- Schutzbereichs-Hubs zeigen sämtliche aktiven C2.2-Themenseiten (keine Abschneidung auf vier). Alte WP-Seiten und -Kategorie-URLs bleiben vollständig erhalten.
- Auf alten und neuen Seite-3-Themenseiten steht "Artikelkategorien – letzte Kategorieebene". Nur für aktive CORE-WordPress-Kategoriearchive wird in der vorhandenen Archivbeschreibung das Ende der Kategoriennavigation markiert, wenn die Vorlage diese Beschreibung zeigt.
- Bestehender TargetWriter, V99, DataForSEO, HivePress, Magazin, Artikelzuordnungen, SEO-URLs und C2.2-Inhaltsplan unverändert. Keine automatische Erstellung, Änderung oder Löschung von Seiten, Kategorien oder Artikeln. Erfolgreiche frühere C2.2-Übernahme NICHT wiederholen.

Prüfung: 36/36 echte C2.2-Areahubs, Frost-Klickpfad/alte URL-Erhaltung, 743/743 C2.2-Jobdefs, 93/285/4 Bestands-Schutz, echte Archivterminal-Fälle, Nav-Readback, alte Tests, ZIP- und PHP-Integrität. WordPress-Live-Update nicht selbst ausgeführt.

HAB & BEWAHR – KATEGORIE-WORKFLOW 1.14.8.27
=====================================================

VOLLES WORDPRESS-PLUGIN-UPDATE der aktiven 1.14.8.26.
Das Plugin bleibt dasselbe: affiliate-portal-kategorie-workflow.
Alle bestehenden DataForSEO-, SERP-, V99-, HivePress-, Magazin-,
Kategorie- und WordPress-Funktionen bleiben vorhanden.

C2.2 – EINE BESTÄTIGTE REINE ERGÄNZUNG
------------------------------------
Die vom Nutzer am 16.10.2026 um 14:29:37 UTC aus 1.14.8.26
exportierte Datei meldete 0 Issues und bestätigte:
  - 6 bestehende Gefahrenwelten
  - 93 geschützte Themenseiten (WordPress pages)
  - 285 geschützte WordPress-Artikelkategorien (Terms)
  - 4 bestehende Post-Term-Zuordnungen
  - geschützte aktive Revision HB-V99-ADD-20261015-81-364+98872304205d57c7
  - gebundenen SHA256-Fingerprint der IDs, Slugs, URLs und Beziehungen.

Die neue C2.2-Erweiterung enthält:
  - 5 NEUE Schutzbereiche als Seiten 2
  - 172 NEUE konkrete Themenseiten als Seiten 3
  - 566 NEUE WordPress-Kategorien als eine flache Beitragsebene
  - 11 fachlich enger zugeschnittene Grenzfallkategorien
    mit 3 sachlichen Perspektiven, KEINE fertigen Artikeltitel.

Alle alten Objekte bleiben unverändert. Keine alten Seiten oder
Kategorien werden umbenannt, verschoben, gelöscht, neu geschrieben,
veröffentlicht oder auf andere Term-IDs umgehängt.
Keine Beiträge oder Redaktionspläne werden angelegt.
Keine neuen Datenbanktabellen, kein zweites Plugin, kein externer SEO-Aufruf.

INSTALLATION (ALTER CODE, KEINE AUTOMATISCHE SYNCHRONISIERUNG)
-------------------------------------------------------------
WordPress -> Plugins -> Plugin hinzufügen -> ZIP hochladen ->
vorhandenes Plugin ersetzen. Die Installation selbst legt keine
neuen WordPress-Seiten oder -Kategorien an.

NUR WENN DIE ERGÄNZUNG TATSÄCHLICH ANGELEGT WERDEN SOLL:
  1. Bestehendes WordPress-Backup bereithalten.
  2. WordPress -> Portal-Kategorien -> C2.2 Kategorien öffnen.
  3. Die eindeutige Checkbox bestätigen.
  4. "C2.2 Kategorien kontrolliert übernehmen" anklicken.
  5. Browserseite während der Übernahme offen lassen. Die ca. 920
     Datensätze (743 Anlege- plus 177 Publish-Arbeitsschritte)
     werden automatisch in Blöcken von maximal 20 je Request abgearbeitet.
     Ein erneutes Öffnen des Menüs setzt einen unterbrochenen Vorgang fort.

VOR JEDEM START:
  - Echtzeit-Lesestand wird gegen alten bestätigten Live-Export
    einschließlich Revision, 93/285 IDs, URL-Bindungen und vier
    bestehenden Beitragszuordnungen verglichen.
  - Fremde Slugs / bereits existierende C2.2-IDs führen zu BLOCKED.
  - Ein laufender fremder TargetTree-Sync führt zu BLOCKED.

WÄHREND UND NACH DER AUSFÜHRUNG:
  - Nur der bisherige APKW_TargetWriter schreibt WordPress-Objekte.
  - Neue Inhalte werden als leere Struktur-Seiten angelegt, zunächst
    als Entwurf. Veröffentlichung und finale Menüaktivierung folgen
    erst nach vollständiger Anlage.
  - Neue WordPress-Beitragskategorien bleiben in der nativen Taxonomie
    flach. Der semantische Parent ist die konkrete Themenseite.
  - Der bereits vorhandene SEO-Robotsschutz setzt leere Seiten/Terms
    auf noindex bis echte spätere Inhalte vorhanden sind.
  - Alte URLs, Kategorien und Artikelzuordnungen werden gegen den
    Export erneut kontrolliert; alle 743 neuen Objekte und Links
    werden einzeln aus WordPress zurückgelesen.
  - Vollständige Frontend-, Menü- und Kategorie-Prüfung im bestehenden
    Plugin vor Freigabe des neuen aktiven Navigationsbaums.
  - Fehler lösen den rücknehmbaren Löschvorgang ausschließlich für
    neu erstellte C2.2-Seiten und Kategorien aus. Der originale
    Snapshot bleibt als gesonderte Backup-Option erhalten.
  - Das ursprüngliche alte TargetTree-Komplett-Sync ist blockiert,
    solange diese geschützte C2.2-Ergänzung aktiv ist, um unbeabsichtigte
    Archivierung der neuen Knoten zu verhindern.

TESTS
-----
Lokale 1:1-ähnliche PHP-Runtime-Tests gegen die echte Nutzer-Exportdatei
und das unveränderte Originalplugin:
  - Positive 743-Neuanlage/177-Seitenveröffentlichung/Navigation
  - Alte 93/285/4 und ihre IDs unverändert
  - Falsche Revision/alte URLs, Parent-Owner und Slugkonflikte BLOCKED
  - Bewusster Fehler beim Schreiben -> vollständiger Rückbau
  - Bewusster Fehler bei finalem Readback -> vollständiger Rückbau
  - Menüfälle 0/1/2/3/4/11/50 mit maximal 3 direkten Links + Weiter
  - 30+ PHP-Dateien lint ohne Syntaxfehler; ZIP-Integrität.

Diese lokalen Tests sind keine Behauptung eines realen Live-Syncs auf
hab-und-bewahr.de. Die Live-Änderung wird nur nach ausdrücklicher
Administratorbestätigung innerhalb des installierten Plugins ausgeführt.


1.14.8.29 – Abschlussstatus und dauerhafte Bestandskontrolle
----------------------------------------------------------
Kategorientree 1.14.8.27 wurde in WordPress bereits erfolgreich uebernommen.
Dieses Code-Update wiederholt die 743 WordPress-Anlagen NICHT.

C2.2-Finalstatus basiert ab jetzt auf der aktiven Revision und einem
vollstaendigen Quervergleich der 743 neuen Manifestknoten samt IDs,
Parent-Knoten, Slugs und dem originalen Backup aller frueheren Nodes.
Die beim Schreibabschluss durchgefuehrte reale WordPress-Pruefung bleibt
als Beleg gespeichert. Aktuelle physische URL-/Artikel-Drift ist durch den
weiterhin vorhandenen expliziten Nur-Lese-Export abfragbar.

Alte 93 Seiten und 285 Kategorien koexistieren mit den 172 neuen Themen
als URL-/Artikel-Bestandsschutz. Die vier gleichen Themenbezeichnungen
sind weder Slug- noch ID-Kollisionen. Kein automatischer Redirect,
keine stillschweigende Term->Page-Konversion und keine neue Artikelarbeit.
Die Kategorien-Tragfaehigkeit ist nur grob plausibilisiert; keine
konkreten Artikel werden vorgegeben. Nach erfolgreichem ADD werden
keine konstanten falschen 'Migration erforderlich'-Warnungen mehr angezeigt.

Keine DB-Tabelle, kein weiterer Writer, keine neuen DataForSEO-Aufrufe.


Version 1.14.8.31 – C2.2 zweite additive Kategorie-Ergänzungswelle
- Erweitert das EXISTIERENDE Kategorieplugin um 472 NUR NEUE native flache WP-Artikelkategorien (172 FAQ, 172 Vergleich, 102 weitere, 26 zusätzlich begründete Vertiefungen).
- Importiert NICHT die früheren 743 Objekte erneut; verändert KEINE vorhandenen Seiten, Kategorien, IDs, Slugs, Artikelbindungen oder Provider.
- Echte C2.2-Plugin-Kennungen, präzise Zuordnung zu 172 bestehenden Themenseiten; kein neues WordPress CMS, kein anderer Writer.
- Adminformular unter Portal-Kategorien > C2.2 Kategorien, Live-Freigabe nur nach erfolgreichem Read-only-Preflight und separatem Einverständnis; 20 Term-Anlagen pro AJAX-Paket.
- Fehlgeschlagene Teilimporte werden rückgebaut (nur eigene neue und unbenutzte Terms). Keine automatische Wiederholung.
- Keine Artikel, keine SEO-Beschaffung, kein eigenständiger Seitenimport.
- Teststand: PHPUnit-ähnlicher Standalone PHP Mock positiver kompletter 472-Term-Run, gezielter Fehler nach 30 Terms mit vollständigem Rollback, fehlender Parent blockiert; alle PHP Dateien php -l.

WARNUNG: Diese Fassung ist technisch lokal simuliert, noch nicht in WordPress installiert. Vor WordPress-Liveschreibfreigabe separate Freigabe erforderlich.


Version 1.14.8.32 – C2.3 all 265 topics: 471 additional flat article categories, physical R3 owner-id checks, separate rollback and completion gate; prior 743+472 retained, no automatic write.
