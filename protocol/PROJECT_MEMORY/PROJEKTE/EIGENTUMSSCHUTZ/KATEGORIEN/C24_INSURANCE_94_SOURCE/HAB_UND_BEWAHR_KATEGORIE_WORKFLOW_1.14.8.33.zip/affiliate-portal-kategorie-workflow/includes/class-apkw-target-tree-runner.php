<?php
if (!defined('ABSPATH')) { exit; }

/** Request-bounded runner for deterministic target-tree sync. */
final class APKW_TargetTreeRunner {
    public const CONTRACT='APKW_TARGET_TREE_RUNNER_V1';
    private const HOOK='apkw_target_tree_tick';
    private const STATUS_OPT='apkw_target_tree_runner_status_v1';
    private const LOCK_OPT='apkw_target_tree_runner_lock_v1';
    private const REFRESH_OPT='apkw_target_tree_refresh_requested_v1';
    private const MAX_LOCK_AGE=300;

    public static function enabled():bool{return !defined('APKW_TARGET_TREE_SYNC_ENABLED')||APKW_TARGET_TREE_SYNC_ENABLED===true;}
    public static function init():void{if(!self::enabled()||!function_exists('add_action'))return;add_action('init',[__CLASS__,'bootstrap'],25);add_action(self::HOOK,[__CLASS__,'tick']);}
    public static function owns_runtime():bool{return class_exists('APKW_TargetTree')&&APKW_TargetTree::owns_runtime();}
    public static function manual_only():bool{return defined('APKW_TARGET_TREE_MANUAL_ONLY')&&APKW_TARGET_TREE_MANUAL_ONLY===true;}

    public static function bootstrap():void{
        if(!self::enabled()||!self::owns_runtime())return;
        // C2.2 already owns the append-only extension; never auto-retire its nodes
        // through an older profile merely because the plugin code was updated.
        if(class_exists('APKW_C22_AddOnly') && APKW_C22_AddOnly::owns_runtime())return;$can=function_exists('current_user_can')&&current_user_can('manage_options');$uid=function_exists('get_current_user_id')?(int)get_current_user_id():0;if(!$can||$uid<1)return;
        try{
            $state=APKW_TargetTreeSync::state();
            if(is_array($state)&&in_array((string)($state['status']??''),['WRITING','READBACK','ROLLBACK_PENDING'],true)){self::record('RUNNING','EXISTING_TARGET_TREE_RESUME',$state);self::schedule();return;}
            if(self::manual_only())return;

            $base=APKW_TargetTree::profile();if(!is_array($base))return;
            $baseRevision=APKW_TargetTree::revision($base);
            $active=APKW_TargetTreeSync::active_revision();
            $snapshot=APKW_TargetTreeSync::active_snapshot();
            $activeBase=(string)($snapshot['project']['base_revision']??'');
            if($activeBase===''&&$baseRevision!==''&&str_starts_with($active,$baseRevision.'+'))$activeBase=$baseRevision;
            $refresh=function_exists('get_option')?(bool)get_option(self::REFRESH_OPT,false):false;
            $runner=self::status();
            $codeChanged=(string)($runner['plugin_version']??'')!==APKW_VERSION;

            // Stable same-version COMPLETE is intentionally zero-work. A plugin update,
            // explicit refresh or changed bundled profile is revalidated once through
            // the exact frozen-master dry-run + full writer/frontend readback path.
            if(!$refresh&&!$codeChanged&&$active!==''&&$baseRevision!==''&&$activeBase===$baseRevision&&is_array($state)&&($state['status']??'')==='COMPLETE')return;

            if(!class_exists('APKW_TargetTreeDryRun'))throw new RuntimeException('Automatischer Final-Dry-Run fehlt.');
            $plan=APKW_TargetTreeDryRun::build();
            if(function_exists('update_option'))update_option('apkw_final_target_plan_v1',$plan,false);
            if(empty($plan['valid'])){self::record('BLOCKED','TARGET_TREE_AUTOMATIC_DRYRUN_BLOCKED',$state,implode(', ',(array)($plan['errors']??[])));return;}
            $profile=(array)($plan['profile']??[]);
            if(!$profile)throw new RuntimeException('Automatischer Final-Dry-Run enthält kein Zielprofil.');
            $desired=(string)($plan['profile_revision']??APKW_TargetTree::revision($profile));

            // If an explicit refresh was requested, consume it only after the new
            // plan has passed. The same checked profile is then synchronized.
            if($refresh&&function_exists('delete_option'))delete_option(self::REFRESH_OPT);
            $state=APKW_TargetTreeSync::start($uid,$profile);
            self::record('RUNNING',$codeChanged?'TARGET_TREE_CODE_UPDATE_REVALIDATION_START':'TARGET_TREE_AUTOMATIC_DRYRUN_PASS_AND_START',$state);
            self::schedule();
        }catch(Throwable $e){self::record('BLOCKED','TARGET_TREE_BOOTSTRAP_EXCEPTION',null,$e->getMessage());}
    }

    public static function start_manual(int $user_id,array $profile):array{
        if(!self::enabled())throw new RuntimeException('Target-Tree-Sync ist deaktiviert.');
        if(!self::manual_only())throw new RuntimeException('Manueller Final-Sync verlangt APKW_TARGET_TREE_MANUAL_ONLY.');
        $state=APKW_TargetTreeSync::state();
        if(is_array($state)&&in_array((string)($state['status']??''),['WRITING','READBACK','ROLLBACK_PENDING'],true))throw new RuntimeException('Ein Target-Tree-Sync läuft bereits.');
        $state=APKW_TargetTreeSync::start($user_id,$profile);
        self::record('RUNNING','TARGET_TREE_MANUAL_FINAL_START',$state);self::schedule();return $state;
    }

    public static function tick():void{
        if(!self::enabled()||!self::owns_runtime()||!self::lock())return;$state=null;
        try{$state=APKW_TargetTreeSync::state();if(!is_array($state)){self::record('BLOCKED','TARGET_TREE_STATE_MISSING',null);return;}$status=(string)($state['status']??'');if($status==='WRITING')$state=APKW_TargetTreeSync::advance($state,80);elseif($status==='READBACK')$state=APKW_TargetTreeSync::advance_readback($state,160);elseif($status==='ROLLBACK_PENDING')$state=APKW_TargetTreeSync::advance_rollback($state,80);$status=(string)($state['status']??'');if($status==='COMPLETE')self::record('COMPLETE','TARGET_TREE_SYNC_AND_READBACK_PASS',$state);elseif(in_array($status,['ROLLED_BACK','ROLLBACK_FAILED'],true))self::record('BLOCKED','TARGET_TREE_ROLLBACK_END',$state,(string)($state['error']??''));else self::record('RUNNING','TARGET_TREE_BOUNDED_STEP_PASS',$state);}catch(Throwable $e){self::record('BLOCKED','TARGET_TREE_TICK_EXCEPTION',$state,$e->getMessage());}finally{self::unlock();}
        if(is_array($state)&&in_array((string)($state['status']??''),['WRITING','READBACK','ROLLBACK_PENDING'],true))self::schedule();
    }
    public static function status():array{$x=function_exists('get_option')?get_option(self::STATUS_OPT,[]):[];return is_array($x)?$x:[];}
    public static function request_refresh():void{if(!self::enabled())throw new RuntimeException('Target-Tree-Sync ist im Portalprofil deaktiviert.');if(function_exists('update_option'))update_option(self::REFRESH_OPT,1,false);}
    private static function schedule():void{if(!function_exists('wp_schedule_single_event'))return;if(function_exists('wp_next_scheduled')&&wp_next_scheduled(self::HOOK)!==false)return;wp_schedule_single_event(time()+1,self::HOOK);if(function_exists('spawn_cron'))spawn_cron(time());}
    private static function lock():bool{if(!function_exists('get_option')||!function_exists('add_option'))return true;$now=time();$old=(int)get_option(self::LOCK_OPT,0);if($old>0&&($now-$old)<self::MAX_LOCK_AGE)return false;if($old>0&&function_exists('delete_option'))delete_option(self::LOCK_OPT);return add_option(self::LOCK_OPT,$now,'','no');}
    private static function unlock():void{if(function_exists('delete_option'))delete_option(self::LOCK_OPT);}
    private static function record(string $status,string $reason,?array $state=null,string $error=''):void{if(!function_exists('update_option'))return;$payload=['contract'=>self::CONTRACT,'plugin_version'=>APKW_VERSION,'status'=>$status,'reason'=>$reason,'sync_status'=>(string)($state['status']??''),'revision'=>(string)($state['revision']??''),'summary'=>is_array($state['summary']??null)?$state['summary']:[],'error'=>substr($error!==''?$error:(string)($state['error']??''),0,2000),'updated_at_utc'=>gmdate('c')];update_option(self::STATUS_OPT,$payload,false);if(class_exists('APKW_RunLog')&&in_array($reason,['TARGET_TREE_REVISION_START','TARGET_TREE_AUTOMATIC_DRYRUN_PASS_AND_START','TARGET_TREE_CODE_UPDATE_REVALIDATION_START','TARGET_TREE_AUTOMATIC_DRYRUN_BLOCKED','TARGET_TREE_SYNC_AND_READBACK_PASS','TARGET_TREE_ROLLBACK_END','TARGET_TREE_BOOTSTRAP_EXCEPTION','TARGET_TREE_TICK_EXCEPTION'],true))APKW_RunLog::record('Target Tree',$status,$reason,$payload);}
}
