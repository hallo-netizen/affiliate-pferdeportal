<?php
if (!defined('ABSPATH')) { exit; }

/**
 * General concept -> SEO-backed RESEARCH_DRAFT builder.
 *
 * It deliberately does not publish anything. It converts a bounded project concept
 * into a first three-pillar structure proposal that must still pass the existing
 * human review + research + final gates before any deployment can occur.
 */
final class APKW_ConceptBuilder {
    public const CONTRACT='APKW_CONCEPT_TO_INITIAL_TREE_V1';
    private const MAX_TOPIC_SEEDS=25;
    private const MAX_DISCOVERY_SEEDS=50;
    private const MAX_MARKETPLACE_PATTERNS=8;
    private const MAX_CONTENT_CHILDREN_PER_TOPIC=4;

    public static function preflight(array $concept):array{
        $errors=[];$warnings=[];
        $normalized=self::normalize_concept($concept,$errors,$warnings);
        if($errors)return ['valid'=>false,'errors'=>$errors,'warnings'=>$warnings,'normalized_concept'=>$normalized,'planned_paid_calls'=>['total'=>0]];
        $topic_count=count($normalized['topic_seeds']);
        $overview_count=count(self::overview_keywords($normalized));
        return [
            'contract'=>self::CONTRACT,
            'valid'=>true,
            'errors'=>[],
            'warnings'=>$warnings,
            'normalized_concept'=>$normalized,
            'planned_paid_calls'=>[
                'keyword_overview'=>1,
                'topic_keyword_suggestions'=>$topic_count,
                'total'=>1+$topic_count,
                'overview_keyword_count'=>$overview_count,
            ],
            'write_capability'=>false,
        ];
    }

    public static function build(array $concept,string $location_name,string $language_code,int $suggestion_limit=50,array $resume_evidence=[],?callable $progress_callback=null):array{
        $pf=self::preflight($concept);
        if(empty($pf['valid']))throw new RuntimeException('Konzept-Vorprüfung BLOCKED: '.implode(', ',array_column($pf['errors'],'code')));
        $c=$pf['normalized_concept'];
        $location_name=trim($location_name);$language_code=trim($language_code);
        if($location_name===''||$language_code==='')throw new RuntimeException('Zielmarkt/Sprache fehlen.');
        if($location_name!==(string)$c['project']['target_market']||$language_code!==(string)$c['project']['language_code'])throw new RuntimeException('Laufzeit-Markt/Sprache stimmen nicht mit dem Konzeptvertrag überein.');

        $overview_keywords=self::overview_keywords($c);
        $overview=is_array($resume_evidence['overview']??null)?$resume_evidence['overview']:APKW_DataForSEO::keyword_overview($overview_keywords,$location_name,$language_code,false,'apkw-concept-overview-'.substr(hash('sha256',(string)$c['project']['project_id'].'|'.implode('|',$c['topic_seeds'])),0,20));
        if(!isset($resume_evidence['overview'])&&is_callable($progress_callback))$progress_callback('overview','',$overview);
        $overview_by_key=[];
        foreach($overview['normalized_items']??[] as $item){if(!is_array($item))continue;$k=self::key((string)($item['keyword']??''));if($k!=='')$overview_by_key[$k]=$item;}

        $topic_suggestions=[];
        $resume_topics=is_array($resume_evidence['topic_suggestions']??null)?$resume_evidence['topic_suggestions']:[];
        foreach($c['topic_seeds'] as $seed){
            if(is_array($resume_topics[$seed]??null))$topic_suggestions[$seed]=$resume_topics[$seed];
            else{
                $topic_suggestions[$seed]=APKW_DataForSEO::keyword_suggestions($seed,$location_name,$language_code,$suggestion_limit,false,'apkw-concept-topic-'.substr(hash('sha256',$seed),0,20));
                if(is_callable($progress_callback))$progress_callback('topic_suggestion',$seed,$topic_suggestions[$seed]);
            }
        }

        $nodes=[];$clusters=[];$used_keyword=[];$used_slug=[];$structural_pages=[];$sequence=1;$unresolved_world_routes=[];$world_route_decisions=[];$candidate_scope_decisions=[];
        $project_exclusions=$c['project']['exclusions'];
        $mag_cluster_id='magazine-discovery';$mag_seeds=[];

        foreach($c['topic_seeds'] as $seed){
            $seed_key=self::key($seed);$exact=$overview_by_key[$seed_key]??null;
            if(!is_array($exact)||self::volume($exact)<=0)continue;
            $cluster_id='topic-'.substr(hash('sha256',$seed_key),0,12);
            $cluster_keywords=[$seed];
            $parent_id=null;$level=1;$middle_candidates=[];
            $full=!empty($c['full_hierarchy']['enabled']);

            // Konzeptgrenze V1.10.3: Erst nach realer DataForSEO-Tiefenpruefung entscheiden,
            // ob ein Thema einen eigenen dauerhaften Hauptportal-Strukturraum traegt.
            // Die Rohliste selbst ist keine Taxonomie. Ein Spezial-/Nischenthema ohne
            // belegten Content-Unterbau wird als Magazin-Kategorie gefuehrt und deshalb
            // NICHT zwanghaft einer der acht Hauptwelten zugeordnet.
            $scope=$full?self::classify_topic_scope($seed,$exact,(array)($topic_suggestions[$seed]['normalized_items']??[]),$c):[
                'seed'=>$seed,'decision'=>'MAIN_PORTAL','reason'=>'GENERIC_CONCEPT_LEGACY_PATH','exact_search_volume'=>self::volume($exact),
                'qualifying_leaf_groups'=>[],'leaf_group_evidence'=>[],'fixed_search_volume_threshold_used'=>false,'raw_list_taxonomy_used'=>false,
            ];
            $candidate_scope_decisions[]=$scope;
            if(($scope['decision']??'')==='MAGAZINE_CATEGORY'){
                $id='j-'.substr(hash('sha256','niche-magazine|'.$seed_key),0,16);
                $node=self::node($id,'magazine',self::display_name($seed),$seed,$exact['main_intent']??'informational',null,1,true,$mag_cluster_id,['adapter'=>'wordpress_taxonomy','taxonomy'=>(string)$c['magazine_taxonomy']],$project_exclusions);
                $node['scope']='DataForSEO-belegtes Spezial-/Nischenthema ohne ausreichend belegten eigenstaendigen Hauptportal-Unterbau; redaktionell im Magazin gefuehrt.';
                $node['category_boundary_decision']='MAGAZINE_CATEGORY';
                $node['magazine_source_type']='scope_boundary';
                $nodes[]=$node;$used_keyword[$seed_key]=true;$mag_seeds[]=$seed;
                continue;
            }

            if($full){
                $path_rows=(array)($c['full_hierarchy']['content_parent_paths'][$seed_key]??[]);
                if(!$path_rows&&!empty($c['full_hierarchy']['auto_world_routing']['enabled'])){
                    $ctx=is_array($c['candidate_context'][$seed_key]??null)?$c['candidate_context'][$seed_key]:[];
                    $route=self::resolve_world_route($seed,(array)($topic_suggestions[$seed]['normalized_items']??[]),(array)$c['full_hierarchy']['auto_world_routing'],$ctx);
                    $world_route_decisions[]=['seed'=>$seed,'resolved'=>!empty($route['resolved']),'reason'=>(string)($route['reason']??''),'world'=>(string)($route['world']['name']??''),'source_section'=>(string)($route['source_section']??''),'scores'=>$route['scores']??[],'raw_list_taxonomy_used'=>false];
                    if(empty($route['resolved'])){
                        $unresolved_world_routes[]=['seed'=>$seed,'reason'=>(string)($route['reason']??'WORLD_ROUTE_UNRESOLVED'),'scores'=>$route['scores']??[],'source_section'=>(string)($route['source_section']??'')];
                        continue;
                    }
                    $path_rows=[['name'=>(string)$route['world']['name'],'primary_keyword'=>(string)$route['world']['primary_keyword']]];
                    // Visible middle levels must never come from raw-list section headings.
                    // Keep only a DataForSEO/world-rule candidate here; the portal-wide
                    // merge promotes it only when multiple independent hobbies support it.
                    $middle_candidates=self::resolve_semantic_middle_candidates($seed,(array)($topic_suggestions[$seed]['normalized_items']??[]),$route,$c);
                }
                foreach($path_rows as $row){
                    $name=(string)$row['name'];$kw=(string)$row['primary_keyword'];
                    $slug=sanitize_title($name);$struct_key=(string)($parent_id??'ROOT').'|'.$slug;
                    if(isset($structural_pages[$struct_key])){$parent_id=$structural_pages[$struct_key];$level++;continue;}
                    $id='p-'.substr(hash('sha256','content-page|'.$struct_key),0,16);
                    $node=self::node($id,'content',$name,$kw,'informational',$parent_id,$level,false,$cluster_id,['adapter'=>'wordpress_page','taxonomy'=>null],$project_exclusions);
                    $node['keyword_owner']=false;$node['scope']='Strukturelle Portalebene für '.$seed.'; fachlich durch Konzept gebunden.';$node['single_child_justification']='Bewusste Navigationskette des verbindlichen Portalmodells; die Ebene bündelt den darunterliegenden Suchraum.';
                    $nodes[]=$node;$used_slug['wordpress_page||'.($parent_id??'ROOT').'|'.$node['slug']]=true;$structural_pages[$struct_key]=$id;$parent_id=$id;$level++;
                }
            }
            $root_id='c-'.substr(hash('sha256','content|'.$seed_key),0,16);
            $root=self::node($root_id,'content',self::display_name($seed),$seed,$exact['main_intent']??'informational',$parent_id,$level,false,$cluster_id,['adapter'=>'wordpress_page','taxonomy'=>null],$project_exclusions);
            $root['single_child_justification']='Themenseite ist bewusster Übergang von der Seitenhierarchie in die belegten Intent-Kategorien.';
            if($middle_candidates)$root['portal_middle_group_candidates']=$middle_candidates;
            $nodes[]=$root;$used_keyword[$seed_key]=true;$used_slug['wordpress_page||'.($parent_id??'ROOT').'|'.$root['slug']]=true;$level++;

            $middle_parent_keys=[];
            foreach($middle_candidates as $mc){
                if(!is_array($mc))continue;
                foreach([(string)($mc['primary_keyword']??''),(string)($mc['name']??'')] as $mv){$mk=self::key($mv);if($mk!=='')$middle_parent_keys[$mk]=true;}
            }
            $candidates=[];
            foreach($topic_suggestions[$seed]['normalized_items']??[] as $item){
                if(!is_array($item)||self::volume($item)<=0)continue;
                $kw=trim((string)($item['keyword']??''));$k=self::key($kw);if($k===''||isset($used_keyword[$k])||$k===$seed_key)continue;
                $core_key=self::key((string)($item['core_keyword']??''));
                // Parent evidence and leaf evidence are mutually exclusive. The same
                // intent may never own both a middle page and a leaf category.
                if(isset($middle_parent_keys[$k])||($core_key!==''&&isset($middle_parent_keys[$core_key])))continue;
                $intent=self::key((string)($item['main_intent']??''));
                if(in_array($intent,['navigational'],true))continue;
                if(self::looks_marketplace($kw,$c['marketplace_patterns']))continue;
                $candidates[]=$item;
            }
            usort($candidates,static fn($a,$b)=>((int)($b['search_volume']??0)<=> (int)($a['search_volume']??0)) ?: strcmp((string)($a['keyword']??''),(string)($b['keyword']??'')));
            if($full){
                foreach($c['full_hierarchy']['content_leaf_groups'] as $group){
                    $matched_items=[];
                    foreach($candidates as $item){
                        $kw=(string)$item['keyword'];$kk=self::key($kw);$matched=false;
                        foreach($group['match_terms'] as $term){if(str_contains($kk,self::key((string)$term))){$matched=true;break;}}
                        if($matched)$matched_items[]=$item;
                    }
                    if(!$matched_items)continue;
                    $distinct=[];foreach($matched_items as $item){$ik=self::key((string)$item['keyword']);if($ik!=='')$distinct[$ik]=true;}
                    $min_support=max(1,(int)($group['min_support']??1));
                    if(count($distinct)<$min_support)continue;
                    usort($matched_items,static fn($a,$b)=>(self::volume($b)<=>self::volume($a)) ?: strcmp((string)($a['keyword']??''),(string)($b['keyword']??'')));
                    $best=$matched_items[0];
                    $kw=(string)$best['keyword'];$k=self::key($kw);if(isset($used_keyword[$k]))continue;
                    $name=(string)$group['name'];$slug=sanitize_title($seed.' '.$name);$id='c-'.substr(hash('sha256','content-leaf|'.$seed_key.'|'.self::key($name)),0,16);
                    $node=self::node($id,'content',$name,$kw,$best['main_intent']??'informational',$root_id,$level,true,$cluster_id,['adapter'=>'wordpress_taxonomy','taxonomy'=>'category'],$project_exclusions);
                    $node['slug']=$slug;$node['category_name_justification']='Kurze Navigationsbezeichnung des belegten DataForSEO-Intentclusters '.$kw.'.';
                    $node['leaf_support_count']=count($distinct);
                    $node['leaf_support_keywords']=array_values(array_slice(array_map(static fn($i)=>(string)$i['keyword'],$matched_items),0,20));
                    $nodes[]=$node;$used_keyword[$k]=true;$used_slug['wordpress_taxonomy|category|'.$root_id.'|'.$slug]=true;$cluster_keywords[]=$kw;
                }
            }else{
                $children=array_slice($candidates,0,self::MAX_CONTENT_CHILDREN_PER_TOPIC);
                foreach($children as $item){
                    $kw=(string)$item['keyword'];$k=self::key($kw);$slug=sanitize_title($kw);if($slug===''||isset($used_slug['wordpress_taxonomy|category|ROOT|'.$slug]))continue;
                    $id='c-'.substr(hash('sha256','content-child|'.$seed_key.'|'.$k),0,16);
                    $nodes[]=self::node($id,'content',self::display_name($kw),$kw,$item['main_intent']??'informational',$root_id,$level,true,$cluster_id,['adapter'=>'wordpress_taxonomy','taxonomy'=>'category'],$project_exclusions);
                    $used_keyword[$k]=true;$used_slug['wordpress_taxonomy|category|ROOT|'.$slug]=true;$cluster_keywords[]=$kw;
                }
            }
            $clusters[]=['cluster_id'=>$cluster_id,'name'=>self::display_name($seed),'scope'=>'SEO-Strukturraum für '.$seed,'exclusions'=>$project_exclusions,'seed_keywords'=>array_values(array_unique($cluster_keywords))];
            $sequence++;
        }

        // Marketplace candidates are generated from concept patterns, but only survive with positive DataForSEO evidence.
        foreach($c['topic_seeds'] as $seed){
            $best=null;
            foreach($c['marketplace_patterns'] as $pattern){
                $kw=self::apply_pattern($pattern,$seed);$item=$overview_by_key[self::key($kw)]??null;
                if(!is_array($item)||self::volume($item)<=0)continue;
                $intent=self::key((string)($item['main_intent']??''));
                if(!in_array($intent,['commercial','transactional','navigational'],true))continue;
                if($best===null||self::volume($item)>self::volume($best))$best=$item;
            }
            if(!is_array($best))continue;
            $kw=(string)$best['keyword'];$k=self::key($kw);if(isset($used_keyword[$k]))continue;
            $id='m-'.substr(hash('sha256','marketplace|'.$k),0,16);
            $nodes[]=self::node($id,'marketplace',self::display_name($kw),$kw,$best['main_intent']??'transactional',null,1,true,self::topic_cluster_id($seed),['adapter'=>'wordpress_taxonomy','taxonomy'=>'hp_listing_category'],$project_exclusions);
            $used_keyword[$k]=true;
        }

        // Full-hierarchy topic magazine candidates may come from the same DataForSEO suggestion set,
        // but remain a separate taxonomy and never become content children.
        if(!empty($c['full_hierarchy']['enabled'])&&!empty($c['full_hierarchy']['topic_magazine_patterns'])){
            foreach($c['topic_seeds'] as $seed){
                $best=null;
                foreach($topic_suggestions[$seed]['normalized_items']??[] as $item){if(!is_array($item)||self::volume($item)<=0)continue;$kw=(string)($item['keyword']??'');$kk=self::key($kw);$matched=false;foreach($c['full_hierarchy']['topic_magazine_patterns'] as $pat){if(str_contains($kk,self::key($pat))){$matched=true;break;}}if(!$matched)continue;if($best===null||self::volume($item)>self::volume($best))$best=$item;}
                if(!is_array($best))continue;$kw=(string)$best['keyword'];$k=self::key($kw);if(isset($used_keyword[$k]))continue;$id='j-'.substr(hash('sha256','topic-magazine|'.$k),0,16);
                $node=self::node($id,'magazine',self::display_name($kw),$kw,$best['main_intent']??'informational',null,1,true,$mag_cluster_id,['adapter'=>'wordpress_taxonomy','taxonomy'=>(string)$c['magazine_taxonomy']],$project_exclusions);$node['magazine_source_type']='topic_pattern';$nodes[]=$node;$used_keyword[$k]=true;$mag_seeds[]=$kw;
            }
        }
        // Magazine roots come from the concept's discovery needs; again only positive SEO evidence is accepted.
        foreach($c['magazine_seed_keywords'] as $seed){
            $item=$overview_by_key[self::key($seed)]??null;if(!is_array($item)||self::volume($item)<=0)continue;
            $k=self::key($seed);if(isset($used_keyword[$k]))continue;
            $id='j-'.substr(hash('sha256','magazine|'.$k),0,16);
            $node=self::node($id,'magazine',self::display_name($seed),$seed,$item['main_intent']??'informational',null,1,true,$mag_cluster_id,['adapter'=>'wordpress_taxonomy','taxonomy'=>(string)$c['magazine_taxonomy']],$project_exclusions);$node['magazine_source_type']='discovery_seed';$nodes[]=$node;
            $used_keyword[$k]=true;$mag_seeds[]=$seed;
        }
        if($mag_seeds)$clusters[]=['cluster_id'=>$mag_cluster_id,'name'=>'Magazin / Inspiration','scope'=>'SEO-Einstiege für Inspiration, Entdecken und Informationsbedürfnisse','exclusions'=>$project_exclusions,'seed_keywords'=>array_values(array_unique($mag_seeds))];

        // Generated graph must describe its actual hierarchy and every generated core node
        // must carry a real research cluster. This is especially relevant for real portal
        // batches where a thema root can legitimately have no supported child category,
        // or only a marketplace keyword has positive demand.
        self::finalize_generated_graph($nodes,$clusters,$project_exclusions);

        $package=[
            'format'=>'affiliate-portal-category-package','schema_version'=>APKW_CATEGORY_SCHEMA_VERSION,'master_contract_id'=>APKW_MASTER_CONTRACT_ID,
            'package_id'=>'concept-draft-'.self::uuid(),'package_version'=>1,'mode'=>'RESEARCH_DRAFT',
            'project'=>$c['project']+['discovery_seed_keywords'=>$c['magazine_seed_keywords'],'affiliate_model'=>$c['affiliate_model']],
            'research_clusters'=>$clusters,
            'default_targets'=>[
                'content'=>['adapter'=>'wordpress_taxonomy','taxonomy'=>'category'],
                'marketplace'=>['adapter'=>'wordpress_taxonomy','taxonomy'=>'hp_listing_category'],
                'magazine'=>['adapter'=>'wordpress_taxonomy','taxonomy'=>(string)$c['magazine_taxonomy'],
            ]],
            'nodes'=>$nodes,
            'source'=>['site'=>rtrim((string)home_url('/'),'/'),'type'=>'concept_builder','contract'=>self::CONTRACT,'built_at_utc'=>gmdate('c')],
            'concept_builder'=>[
                'contract'=>self::CONTRACT,
                'concept_sha256'=>hash('sha256',(string)wp_json_encode($c,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),
                'overview'=>self::evidence_summary($overview),
                'topic_suggestions'=>array_map([__CLASS__,'evidence_summary'],$topic_suggestions),
                'unresolved_world_routes'=>$unresolved_world_routes,
                'world_route_decisions'=>$world_route_decisions,
                'candidate_scope_decisions'=>$candidate_scope_decisions,
                'portal_discovery_binding'=>$c['portal_discovery_binding']??null,
                'policy'=>[
                    'positive_search_demand_required'=>true,
                    'no_keyword_duplicate_across_pillars'=>true,
                    'content_root_target'=>'wordpress_page',
                    'content_child_target'=>'wordpress_category',
                    'marketplace_target'=>'hp_listing_category',
                    'magazine_target'=>(string)$c['magazine_taxonomy'],
                    'no_publish_or_write'=>true,
                ],
            ],
        ];
        $validation=APKW_Validator::validate($package);
        return ['valid'=>!empty($validation['valid']),'package'=>$package,'validation'=>$validation,'planned_paid_calls'=>$pf['planned_paid_calls']];
    }

    private static function finalize_generated_graph(array &$nodes,array &$clusters,array $project_exclusions):void{
        $cluster_index=[];
        foreach($clusters as $i=>$cluster){
            if(!is_array($cluster))continue;
            $cid=trim((string)($cluster['cluster_id']??''));
            if($cid!=='')$cluster_index[$cid]=$i;
        }

        // A generated marketplace node may be valid even when the corresponding thema
        // seed itself had no positive exact-match demand or its content world is unresolved.
        // Bind that generated node to its own explicit evidence cluster instead of emitting
        // a dangling research_cluster_id. The validator remains fail-closed for external
        // packages; this only completes the builder's own generated evidence graph.
        foreach($nodes as $node){
            if(!is_array($node)||!in_array((string)($node['block']??''),['content','marketplace','magazine'],true))continue;
            $cid=trim((string)($node['research_cluster_id']??''));
            if($cid===''||isset($cluster_index[$cid]))continue;
            $kw=trim((string)($node['primary_keyword']??''));
            $clusters[]=[
                'cluster_id'=>$cid,
                'name'=>$kw!==''?self::display_name($kw):'Portal-Evidenz',
                'scope'=>$kw!==''?'SEO-Strukturraum für '.$kw:'Gebundene SEO-Evidenz des generierten Portal-Knotens.',
                'exclusions'=>$project_exclusions,
                'seed_keywords'=>$kw!==''?[$kw]:[],
            ];
            $cluster_index[$cid]=count($clusters)-1;
        }

        // is_leaf is a statement about the real generated graph, not a template guess.
        // Recalculate it once after all content nodes are present.
        $children=[];
        foreach($nodes as $node){
            if(!is_array($node))continue;
            $parent=trim((string)($node['parent_concept_id']??''));
            if($parent!=='')$children[$parent]=true;
        }
        foreach($nodes as &$node){
            if(!is_array($node)||($node['block']??'')!=='content')continue;
            $id=trim((string)($node['concept_id']??''));
            if($id!=='')$node['is_leaf']=!isset($children[$id]);
        }
        unset($node);
    }

    private static function normalize_concept(array $concept,array &$errors,array &$warnings):array{
        $project=is_array($concept['project']??null)?$concept['project']:[];
        foreach(['project_id','name','scope','target_market','language_code'] as $f)if(trim((string)($project[$f]??''))==='')$errors[]=self::issue('CONCEPT_PROJECT_FIELD_MISSING','project.'.$f,$f.' fehlt.');
        $project['exclusions']=self::clean_list($project['exclusions']??[]);
        $topics=self::clean_list($concept['topic_seeds']??[]);
        if(!$topics)$errors[]=self::issue('CONCEPT_TOPIC_SEEDS_MISSING','topic_seeds','Mindestens ein Themen-Seed ist erforderlich.');
        if(count($topics)>self::MAX_TOPIC_SEEDS)$errors[]=self::issue('CONCEPT_TOPIC_SEEDS_TOO_MANY','topic_seeds','Pilotlauf: maximal '.self::MAX_TOPIC_SEEDS.' Themen-Seeds pro Entwurf.');
        $mag=self::clean_list($concept['magazine_seed_keywords']??($project['discovery_seed_keywords']??[]));
        if(!$mag)$errors[]=self::issue('CONCEPT_MAGAZINE_SEEDS_MISSING','magazine_seed_keywords','Mindestens ein Inspirations-/Magazin-Seed ist erforderlich.');
        if(count($mag)>self::MAX_DISCOVERY_SEEDS)$errors[]=self::issue('CONCEPT_MAGAZINE_SEEDS_TOO_MANY','magazine_seed_keywords','Maximal '.self::MAX_DISCOVERY_SEEDS.' Magazin-/Discovery-Seeds.');
        $patterns=self::clean_list($concept['marketplace_patterns']??['%s ausrüstung','%s zubehör','%s set','%s kurs','%s gebraucht','%s anbieter','%s kaufen']);
        $patterns=array_values(array_filter($patterns,static fn($p)=>str_contains($p,'%s')));
        if(!$patterns)$errors[]=self::issue('CONCEPT_MARKETPLACE_PATTERNS_MISSING','marketplace_patterns','Mindestens ein Marketplace-Muster mit %s ist erforderlich.');
        if(count($patterns)>self::MAX_MARKETPLACE_PATTERNS)$errors[]=self::issue('CONCEPT_MARKETPLACE_PATTERNS_TOO_MANY','marketplace_patterns','Maximal '.self::MAX_MARKETPLACE_PATTERNS.' Marketplace-Muster.');
        $affiliate=is_array($concept['affiliate_model']??($project['affiliate_model']??null))?$concept['affiliate_model']??$project['affiliate_model']:[];
        $affiliate=$affiliate+['portal_type'=>'affiliate_portal','allowed_fits'=>['DIRECT','ASSISTED'],'monetization_paths'=>['products','providers','services','courses']];
        $mag_tax=trim((string)($concept['magazine_taxonomy']??'category'));if($mag_tax==='')$mag_tax='category';
        $full=is_array($concept['full_hierarchy']??null)?$concept['full_hierarchy']:[];
        $full_enabled=!empty($full['enabled']);
        $parent_paths=[];
        foreach((array)($full['content_parent_paths']??[]) as $seed=>$rows){
            $sk=self::key((string)$seed);if($sk==='')continue;$clean=[];
            foreach((array)$rows as $row){if(!is_array($row))continue;$name=trim((string)($row['name']??''));$kw=trim((string)($row['primary_keyword']??$name));if($name===''||$kw==='')continue;$clean[]=['name'=>$name,'primary_keyword'=>$kw];}
            if($clean)$parent_paths[$sk]=$clean;
        }
        $leaf_groups=[];
        foreach((array)($full['content_leaf_groups']??[]) as $row){
            if(!is_array($row))continue;$name=trim((string)($row['name']??''));$match=self::clean_list($row['match_terms']??[]);if($name===''||!$match)continue;$leaf_groups[]=['name'=>$name,'match_terms'=>$match,'min_support'=>max(1,(int)($row['min_support']??1))];
        }
        $topic_mag_patterns=self::clean_list($full['topic_magazine_patterns']??[]);
        $auto_world=is_array($full['auto_world_routing']??null)?$full['auto_world_routing']:[];
        $auto_world_enabled=!empty($auto_world['enabled']);$worlds=[];
        if($auto_world_enabled){
            foreach((array)($auto_world['worlds']??[]) as $row){if(!is_array($row))continue;$name=trim((string)($row['name']??''));$wk=self::key((string)($row['key']??$name));$pk=trim((string)($row['primary_keyword']??$name));$match=self::clean_list($row['match_terms']??[]);$exclude=self::clean_list($row['exclude_terms']??[]);if($name!==''&&$wk!==''&&$pk!==''&&$match)$worlds[]=['key'=>$wk,'name'=>$name,'primary_keyword'=>$pk,'match_terms'=>$match,'exclude_terms'=>$exclude];}
            if(!$worlds)$errors[]=self::issue('CONCEPT_AUTO_WORLD_ROUTING_EMPTY','full_hierarchy.auto_world_routing','Auto-World-Routing benötigt Weltregeln.');
        }
        $candidate_context=[];foreach((array)($concept['candidate_context']??[]) as $seed=>$row){if(!is_array($row))continue;$sk=self::key((string)$seed);if($sk==='')$sk=self::key((string)($row['candidate']??''));if($sk==='')continue;$candidate_context[$sk]=['candidate'=>trim((string)($row['candidate']??$seed)),'primary_source_section'=>trim((string)($row['primary_source_section']??'')),'source_sections'=>self::clean_list($row['source_sections']??[]),'first_raw_index'=>(int)($row['first_raw_index']??0)];}
        $section_hints=[];foreach((array)($auto_world['source_section_world_hints']??[]) as $section=>$keys){$sk=self::key((string)$section);if($sk==='')continue;$clean=[];foreach((array)$keys as $k){$wk=self::key((string)$k);if($wk!=='')$clean[$wk]=$wk;}$section_hints[$sk]=array_values($clean);}
        if($full_enabled&&(!$leaf_groups||(!$parent_paths&&!$auto_world_enabled)))$errors[]=self::issue('CONCEPT_FULL_HIERARCHY_INCOMPLETE','full_hierarchy','Full-Hierarchy benötigt Leaf-Gruppen und entweder Parent-Pfade oder Auto-World-Routing.');
        return ['project'=>$project,'topic_seeds'=>$topics,'candidate_context'=>$candidate_context,'magazine_seed_keywords'=>$mag,'marketplace_patterns'=>$patterns,'affiliate_model'=>$affiliate,'magazine_taxonomy'=>$mag_tax,'portal_discovery_binding'=>is_array($concept['portal_discovery_binding']??null)?$concept['portal_discovery_binding']:null,'full_hierarchy'=>['enabled'=>$full_enabled,'content_parent_paths'=>$parent_paths,'content_leaf_groups'=>$leaf_groups,'topic_magazine_patterns'=>$topic_mag_patterns,'auto_world_routing'=>['enabled'=>$auto_world_enabled,'worlds'=>$worlds,'source_section_world_hints'=>$section_hints,'source_sections_are_taxonomy'=>false,'fail_closed'=>array_key_exists('fail_closed',$auto_world)?(bool)$auto_world['fail_closed']:true]]];
    }


    /**
     * DataForSEO-backed boundary between durable main-portal structure and
     * smaller/specialized magazine space. No fixed search-volume gate is used.
     * The decision reuses the already bound hierarchy lenses: a seed belongs in
     * the main portal only when the same paid suggestion set proves at least one
     * independently supportable content subcluster. Explicit concept parent paths
     * also bind a seed to the main portal. Otherwise the positively evidenced seed
     * remains visible as a magazine category instead of being lost or force-routed.
     */
    private static function classify_topic_scope(string $seed,array $exact,array $suggestions,array $c):array{
        $seed_key=self::key($seed);
        $explicit_path=(array)($c['full_hierarchy']['content_parent_paths'][$seed_key]??[]);
        $groups=[];$qualifying=[];
        foreach((array)($c['full_hierarchy']['content_leaf_groups']??[]) as $group){
            if(!is_array($group))continue;
            $name=trim((string)($group['name']??''));if($name==='')continue;
            $hits=[];
            foreach($suggestions as $item){
                if(!is_array($item)||self::volume($item)<=0)continue;
                $kw=trim((string)($item['keyword']??''));$kk=self::key($kw);
                if($kk===''||$kk===$seed_key)continue;
                $intent=self::key((string)($item['main_intent']??''));
                if($intent==='navigational'||self::looks_marketplace($kw,(array)$c['marketplace_patterns']))continue;
                foreach((array)($group['match_terms']??[]) as $term){
                    $tk=self::key((string)$term);if($tk!==''&&str_contains($kk,$tk)){$hits[$kk]=$kw;break;}
                }
            }
            $support=count($hits);$min=max(1,(int)($group['min_support']??1));
            $groups[]=['name'=>$name,'support_count'=>$support,'required_support'=>$min,'keywords'=>array_values(array_slice($hits,0,20))];
            if($support>=$min)$qualifying[]=$name;
        }
        $main=!empty($explicit_path)||!empty($qualifying);
        return [
            'seed'=>$seed,
            'decision'=>$main?'MAIN_PORTAL':'MAGAZINE_CATEGORY',
            'reason'=>!empty($explicit_path)?'EXPLICIT_CONCEPT_PARENT_PATH':($main?'DATAFORSEO_SUPPORTED_CONTENT_SUBCLUSTER':'NO_DATAFORSEO_SUPPORTED_DURABLE_CONTENT_SUBCLUSTER'),
            'exact_search_volume'=>self::volume($exact),
            'qualifying_leaf_groups'=>$qualifying,
            'leaf_group_evidence'=>$groups,
            'fixed_search_volume_threshold_used'=>false,
            'raw_list_taxonomy_used'=>false,
        ];
    }

    private static function overview_keywords(array $c):array{
        $out=$c['topic_seeds'];
        foreach($c['topic_seeds'] as $seed)foreach($c['marketplace_patterns'] as $p)$out[]=self::apply_pattern($p,$seed);
        foreach($c['magazine_seed_keywords'] as $seed)$out[]=$seed;
        return self::clean_list($out);
    }
    private static function node(string $id,string $block,string $name,string $keyword,string $intent,?string $parent,int $level,bool $leaf,string $cluster,array $target,array $exclusions):array{
        $roles=['content'=>'CONTENT_EVERGREEN','marketplace'=>'MARKETPLACE_TRANSACTIONAL','magazine'=>'JOURNAL_EDITORIAL'];
        $node=['concept_id'=>$id,'block'=>$block,'pillar_role'=>$roles[$block],'research_cluster_id'=>$cluster,'level'=>$level,'name'=>$name,'slug'=>sanitize_title($name),'parent_concept_id'=>$parent,'status'=>'PROPOSED','primary_keyword'=>$keyword,'search_intent'=>self::normalize_intent($intent,$block),'intent_key'=>$block.'-'.substr(hash('sha256',self::key($keyword)),0,16),'keyword_owner'=>true,'scope'=>'SEO-/Nutzerintention für '.$keyword,'exclusions'=>$exclusions,'longtail_potential'=>[],'is_leaf'=>$leaf,'target'=>$target];
        $len=function_exists('mb_strlen')?mb_strlen($name,'UTF-8'):strlen($name);
        if(($level===1&&$len>24)||($level>1&&$len>40))$node['title_length_justification']='DataForSEO-belegte eindeutige Suchintention; eine kürzere sichtbare Bezeichnung würde den Themen-/Bedarfskontext verlieren.';
        return $node;
    }
    private static function normalize_intent($intent,string $block):string{$i=self::key((string)$intent);if(in_array($i,['informational','commercial','transactional','navigational'],true))return $i;return $block==='marketplace'?'transactional':'informational';}
    private static function display_name(string $v):string{$v=preg_replace('/\s+/u',' ',trim($v));if(function_exists('mb_convert_case'))return mb_convert_case($v,MB_CASE_TITLE,'UTF-8');return ucwords($v);}
    private static function apply_pattern(string $pattern,string $seed):string{return preg_replace('/\s+/u',' ',trim(str_replace('%s',$seed,$pattern)));}
    private static function looks_marketplace(string $kw,array $patterns):bool{$k=self::key($kw);foreach($patterns as $p){$suffix=self::key(str_replace('%s','',$p));if($suffix!==''&&str_contains($k,$suffix))return true;}return false;}
    private static function topic_cluster_id(string $seed):string{return 'topic-'.substr(hash('sha256',self::key($seed)),0,12);}
    private static function volume(array $item):int{return isset($item['search_volume'])&&is_numeric($item['search_volume'])?(int)$item['search_volume']:0;}

    private static function resolve_world_route(string $seed,array $suggestions,array $cfg,array $candidate_context=[]):array{
        $worlds=(array)($cfg['worlds']??[]);if(!$worlds)return ['resolved'=>false,'reason'=>'WORLD_RULES_MISSING','scores'=>[]];
        $texts=[];$seed_key=self::key($seed);if($seed_key!=='')$texts[]=['text'=>$seed_key,'weight'=>1000];
        foreach($suggestions as $item){if(!is_array($item)||self::volume($item)<=0)continue;$k=self::key((string)($item['keyword']??''));if($k==='')continue;$weight=max(1,min(100,(int)round(log10(max(1,self::volume($item))+1)*20)));$texts[]=['text'=>$k,'weight'=>$weight];}
        $scores=[];
        foreach($worlds as $idx=>$world){
            $name=(string)($world['name']??'');$score=0;$hits=[];$term_scores=[];$excluded=false;
            foreach($texts as $row){
                foreach((array)($world['exclude_terms']??[]) as $term){$tk=self::key((string)$term);if($tk!==''&&self::contains_term($row['text'],$tk)){$excluded=true;break 2;}}
                foreach((array)($world['match_terms']??[]) as $term){
                    $raw_term=trim((string)$term);$tk=self::key($raw_term);
                    if($tk!==''&&self::contains_term($row['text'],$tk)){
                        $w=(int)$row['weight'];$score+=$w;$hits[$tk]=true;
                        if(!isset($term_scores[$tk]))$term_scores[$tk]=['term'=>$raw_term,'score'=>0,'hits'=>[]];
                        $term_scores[$tk]['score']+=$w;$term_scores[$tk]['hits'][$row['text']]=true;
                    }
                }
            }
            if($excluded){$score=0;$term_scores=[];}
            foreach($term_scores as &$ts)$ts['hits']=array_keys($ts['hits']);unset($ts);
            $scores[]=['index'=>$idx,'key'=>(string)($world['key']??self::key($name)),'name'=>$name,'score'=>$score,'hits'=>array_keys($hits),'term_scores'=>array_values($term_scores)];
        }
        usort($scores,static fn($a,$b)=>(int)$b['score']<=>(int)$a['score']);
        $top=$scores[0]??null;$second=$scores[1]??['score'=>0];
        if(is_array($top)&&(int)$top['score']>0&&((int)$second['score']<=0||(int)$top['score']>=(int)ceil((int)$second['score']*1.35))){
            $world=$worlds[(int)$top['index']]??null;if(is_array($world))return ['resolved'=>true,'reason'=>'DATAFORSEO_WORLD_EVIDENCE','world'=>$world,'scores'=>$scores,'source_section'=>(string)($candidate_context['primary_source_section']??'')];
        }

        // Raw-list section headings are only provenance. They must not resolve an
        // otherwise ambiguous world assignment. World promotion is fail-closed unless
        // the thema name + positive DataForSEO suggestion evidence identify one world.
        $section=trim((string)($candidate_context['primary_source_section']??''));
        $reason=(!is_array($top)||(int)($top['score']??0)<=0)?'WORLD_ROUTE_NO_EVIDENCE':'WORLD_ROUTE_AMBIGUOUS';
        return ['resolved'=>false,'reason'=>$reason,'scores'=>$scores,'source_section'=>$section,'raw_list_taxonomy_used'=>false];
    }
    private static function resolve_semantic_middle_candidates(string $seed,array $suggestions,array $route,array $c):array{
        if(empty($route['resolved'])||!is_array($route['world']??null))return [];
        $seed_key=self::key($seed);if($seed_key==='')return [];

        // World-routing vocabulary decides only the top world. It must never be
        // promoted by itself into a visible middle page (e.g. "binden", "sport").
        $blocked=[];
        $world=(array)$route['world'];
        foreach(array_merge((array)($world['match_terms']??[]),(array)($world['exclude_terms']??[]),[(string)($world['name']??''),(string)($world['primary_keyword']??'')]) as $v){
            $k=self::key((string)$v);if($k!=='')$blocked[$k]=true;
        }
        foreach((array)($c['full_hierarchy']['content_leaf_groups']??[]) as $group){
            if(!is_array($group))continue;
            $k=self::key((string)($group['name']??''));if($k!=='')$blocked[$k]=true;
            foreach((array)($group['match_terms']??[]) as $v){$k=self::key((string)$v);if($k!=='')$blocked[$k]=true;}
        }
        foreach(['anfänger','anfaenger','start','tipps','ideen','online','kaufen','kurs','set','zubehör','zubehoer','ausrüstung','ausruestung','material','faq','fragen','probleme','anleitung','technik','praxis'] as $v){$blocked[self::key($v)]=true;}

        $candidates=[];
        foreach($suggestions as $item){
            if(!is_array($item)||self::volume($item)<=0)continue;
            $intent=self::key((string)($item['main_intent']??''));
            if($intent!==''&&!in_array($intent,['informational'],true))continue;
            $keyword=trim((string)($item['keyword']??''));
            $core=trim((string)($item['core_keyword']??''));
            $values=[];
            if($core!=='')$values[]=['value'=>$core,'source'=>'core_keyword','bonus'=>20];
            // A recurring shorter/equal suggestion can be a true broader parent.
            // Longer long-tails are child/leaf evidence and therefore excluded here.
            if($keyword!==''){
                $seed_tokens=preg_split('/[^\pL\pN]+/u',$seed_key,-1,PREG_SPLIT_NO_EMPTY)?:[];
                $kw_key=self::key($keyword);$kw_tokens=preg_split('/[^\pL\pN]+/u',$kw_key,-1,PREG_SPLIT_NO_EMPTY)?:[];
                if($kw_key!==''&&count($kw_tokens)<=max(1,count($seed_tokens)))$values[]=['value'=>$keyword,'source'=>'suggestion_keyword','bonus'=>0];
            }
            foreach($values as $row){
                $name=trim((string)$row['value']);$key=self::key($name);
                if($name===''||$key===''||$key===$seed_key||isset($blocked[$key]))continue;
                if(self::looks_marketplace($name,(array)($c['marketplace_patterns']??[])))continue;
                // Do not promote a phrase that simply contains the full thema seed;
                // that is a child/long-tail, not a parent.
                if(str_contains($key,$seed_key))continue;
                $score=max(1,min(100,(int)round(log10(max(1,self::volume($item))+1)*20)))+(int)$row['bonus'];
                if(!isset($candidates[$key]))$candidates[$key]=[
                    'key'=>$key,'name'=>self::display_name($name),'primary_keyword'=>$name,
                    'evidence_score'=>0,'evidence_hits'=>[],'sources'=>[],
                    'structural_source'=>'DATAFORSEO_RECURRING_PARENT_EVIDENCE','raw_list_taxonomy_used'=>false,
                ];
                $candidates[$key]['evidence_score']+=$score;
                $candidates[$key]['evidence_hits'][$keyword!==''?$keyword:$name]=true;
                $candidates[$key]['sources'][(string)$row['source']]=true;
            }
        }
        $out=array_values($candidates);
        foreach($out as &$row){$row['evidence_hits']=array_keys((array)$row['evidence_hits']);$row['sources']=array_keys((array)$row['sources']);}unset($row);
        usort($out,static fn($a,$b)=>((int)($b['evidence_score']??0)<=>(int)($a['evidence_score']??0)) ?: strcmp(self::key((string)($a['name']??'')),self::key((string)($b['name']??''))));
        return array_slice($out,0,5);
    }

    private static function contains_term(string $text,string $term):bool{
        if($term==='')return false;
        if(str_contains($term,' '))return str_contains($text,$term);
        return (bool)preg_match('/(?:^|[^\pL\pN])'.preg_quote($term,'/').'(?:$|[^\pL\pN])/u',$text);
    }

    private static function evidence_summary(array $r):array{return ['endpoint'=>$r['endpoint']??null,'request'=>$r['request']??null,'request_sha256'=>$r['request_sha256']??null,'cost_usd'=>$r['cost_usd']??0,'task_id'=>$r['task_id']??null,'returned_count'=>$r['returned_count']??0,'normalized_items'=>$r['normalized_items']??[],'raw_response_sha256'=>$r['raw_response_sha256']??null];}
    private static function clean_list($values):array{if(!is_array($values))return [];$out=[];foreach($values as $v){$v=preg_replace('/\s+/u',' ',trim((string)$v));if($v==='')continue;$out[self::key($v)]=$v;}return array_values($out);}
    private static function key(string $v):string{$v=html_entity_decode($v,ENT_QUOTES|ENT_HTML5,'UTF-8');$v=preg_replace('/\s+/u',' ',trim($v));return function_exists('mb_strtolower')?mb_strtolower((string)$v,'UTF-8'):strtolower((string)$v);}
    private static function uuid():string{return function_exists('wp_generate_uuid4')?(string)wp_generate_uuid4():substr(hash('sha256',microtime(true).'|'.random_bytes(16)),0,32);}
    private static function issue(string $code,string $path,string $message):array{return ['code'=>$code,'path'=>$path,'message'=>$message];}
}
