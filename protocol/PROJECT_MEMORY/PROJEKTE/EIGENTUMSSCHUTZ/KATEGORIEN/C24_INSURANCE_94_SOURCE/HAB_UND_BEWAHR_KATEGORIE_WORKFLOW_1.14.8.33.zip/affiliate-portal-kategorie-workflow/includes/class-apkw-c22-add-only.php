<?php
if (!defined('ABSPATH')) exit;
/**
 * C2.2: one administrator-confirmed ADD ONLY pass through the existing APKW
 * TargetWriter. No edits to protected pages, category terms or post relations.
 * 20 ops/request, resumable, compensating rollback of ONLY newly created IDs.
 */
final class APKW_C22_AddOnly {
    private const STATE='apkw_c22_add_only_state_v1';
    private const LOCK='apkw_c22_add_only_request_lock_v1';
    private const BACKUP='apkw_c22_base_snapshot_backup_v1';
    private const SNAP='apkw_target_tree_active_snapshot_v1';
    private const REV='apkw_target_tree_active_revision_v1';
    private const LIMIT=20;
    private static ?array $jobs=null;
    public static function init():void {
        add_action('admin_post_apkw_c22_add_start',[__CLASS__,'start']);
        add_action('admin_post_apkw_c22_add_retry',[__CLASS__,'retry']);
        add_action('wp_ajax_apkw_c22_add_tick',[__CLASS__,'tick']);
    }
    private static function admin():void {
        if (!current_user_can('manage_options')) throw new RuntimeException('C2.2: Administrator erforderlich.');
    }
    public static function state():array {
        $x=get_option(self::STATE,[]);
        return is_array($x)?$x:[];
    }
    public static function owns_runtime():bool {
        $s=self::state();
        return in_array((string)($s['status']??''),['WRITING','PUBLISH','VERIFY','ROLLBACK','ROLLBACK_FAILED','COMPLETE'],true);
    }
    /**
     * Lightweight, read-only, repeatable post-sync consistency test.
     * Checks every NEW mapping and all original identities against the
     * backed-up canonical snapshot; no 743 WordPress DB requests on load.
     * Physical WP and post-term readbacks were performed by finish().
     * If actual database drift must be checked again, live_inventory() is
     * the explicit, separate verification path.
     */
    public static function completion_audit():array {
        $state=self::state();
        if(($state['status']??'')!=='COMPLETE')
            return ['complete'=>false,'valid'=>false,'errors'=>['C22_NOT_COMPLETE']];
        $errors=[];
        $base=get_option(self::BACKUP,null);
        $snapshot=APKW_TargetTreeSync::active_snapshot();
        $rev=(string)APKW_TargetTreeSync::active_revision();
        $start=(string)($state['base_revision']??'');
        if(!is_array($base)||!is_array($snapshot)||$start===''||($base['revision']??'')!==$start)
            $errors[]='C22_BACKUP_MISSING_OR_WRONG';
        if(is_array($base)&&!hash_equals((string)($state['base_snapshot_sha256']??''),hash('sha256',serialize($base))))
            $errors[]='C22_BASE_SNAPSHOT_CHANGED';
        $expected=self::target_revision($start);
        $revised=$expected;
        if(class_exists('APKW_C22_472_AddOnly') &&
           (APKW_C22_472_AddOnly::state()['status']??'')==='COMPLETE') {
            // Newer revision is checked independently against all 472 new categories.
            $extra=APKW_C22_472_AddOnly::completion_audit();
            if(empty($extra['valid']))$errors[]='C22_SECOND_WAVE_INVALID';
            $revised=(string)($extra['revision']??'');
        }
        if($rev!==$revised || (string)($snapshot['revision']??'')!==$revised)
            $errors[]='C22_REVISION_MISMATCH';
        if(!hash_equals((string)($state['base_digest']??''),(string)(self::plan()['live_binding']['site_mapping_sha256']??'')))
            $errors[]='C22_BASE_FINGERPRINT_MISMATCH';
        $idx=[];foreach((array)($snapshot['nodes']??[]) as $n)if(is_array($n)&&isset($n['node_id']))$idx[(string)$n['node_id']]=$n;
        $newMap=(array)($snapshot['mapping']??[]);
        $baseNodes=[];if(is_array($base))foreach((array)($base['nodes']??[]) as $n)if(is_array($n)&&isset($n['node_id']))$baseNodes[(string)$n['node_id']]=$n;
        $oldMap=is_array($base)?(array)($base['mapping']??[]):[];
        $oldPages=0;$oldTerms=0;
        foreach($baseNodes as $id=>$original){
            if(str_starts_with($id,'core:subarea:'))$oldPages++;
            if(str_starts_with($id,'core:leaf:'))$oldTerms++;
            if(!isset($idx[$id])||$idx[$id]!==$original ||($newMap[$id]??null)!==($oldMap[$id]??null)){
                $errors[]='C22_PROTECTED_NODE_CHANGED:'.$id;
                if(count($errors)>10)break;
            }
        }
        if($oldPages!==93||$oldTerms!==285)$errors[]='C22_PROTECTED_COUNT_MISMATCH';
        $ids=[];$found=0;$pages=0;$terms=0;
        foreach(self::jobs() as $job){
            $id=(string)$job['node_id'];$mapped=$newMap[$id]??null;$node=$idx[$id]??null;$physical=(int)($mapped['object_id']??0);
            if(!is_array($node)||!is_array($mapped)||$physical<1||
               ($node['display_name']??null)!==$job['name']||
               ($node['slug']??null)!==$job['slug']||
               ($node['parent_id']??null)!==$job['parent_id']||
               ($node['object_type']??null)!==$job['type']||
               ($mapped['object_type']??null)!==$job['type']){
                $errors[]='C22_ADDED_NODE_NOT_BOUND:'.$id;
                if(count($errors)>10)break;
            } else {$found++;if($job['type']==='page')$pages++;else $terms++;}
            $physicalKey=$job['type'].'|'.$physical;
            if(isset($ids[$physicalKey]))$errors[]='C22_DUPLICATE_PHYSICAL_ID';
            $ids[$physicalKey]=true;
        }
        if($found!==743||$pages!==177||$terms!==566)$errors[]='C22_ADDED_OBJECT_COUNT_MISMATCH';
        if((string)($state['result']['readback']??'')!=='PASS'||
           (int)($state['result']['old_post_term_links_unchanged']??-1)!==4)
            $errors[]='C22_FINAL_PHYSICAL_READBACK_NOT_CONFIRMED';
        return ['complete'=>true,'valid'=>empty($errors),'errors'=>array_values(array_unique($errors)),
            'protected_pages'=>$oldPages,'protected_categories'=>$oldTerms,
            'new_areas'=>5,'new_topic_pages'=>172,'new_categories'=>566,
            'new_objects_verified_in_snapshot'=>$found,'physical_readback_at_sync'=>'PASS'];
    }

    private static function save(array $s):void {update_option(self::STATE,$s,false);}
    private static function key(string $s):string {return substr(hash('sha256',$s),0,20);}
    private static function new_node(string $kind,string $full):string {return 'core:c22:'.$kind.':'.self::key($full);}
    private static function slug(string $label,string $key):string {
        $txt=function_exists('sanitize_title')?(string)sanitize_title($label):strtolower(preg_replace('/[^a-z0-9]+/i','-',$label));
        if($txt==='')$txt='thema';
        return 'c22-'.trim(substr($txt,0,55),'-').'-'.substr(hash('sha256',$key),0,10);
    }
    private static function plan():array {
        $p=APKW_C22_Fachpruefung::plan();
        if(!is_array($p))throw new RuntimeException('C2.2 Konzeptdatei fehlt.');
        $qa=APKW_C22_Fachpruefung::audit($p,['available'=>true,'revision'=>'BOUND']);
        if(empty($qa['valid'])||($qa['counts']['topic_pages']??0)!==172||($qa['counts']['article_categories']??0)!==566)
            throw new RuntimeException('C2.2 Fachplan/Manifest ungültig: '.implode(', ',$qa['errors']??[]));
        return $p;
    }
    /** Explicit world/area/node bindings are fixed with the signed legacy source. */
    public static function jobs():array {
        if(self::$jobs!==null)return self::$jobs;
        $p=self::plan();$jobs=[];$taken=[];
        foreach($p['worlds'] as $world){
            $w=(string)$world['name'];$worldId=(string)($world['existing_world_node_id']??'');
            if(!str_starts_with($worldId,'core:world:'))throw new RuntimeException('C2.2 Weltbindung fehlt: '.$w);
            foreach($world['areas'] as $area){
                $a=(string)$area['name'];$path=$w.'|'.$a;
                if(($area['role']??'')==='PROTECTED_AREA'){
                    $areaId=(string)($area['existing_area_node_id']??'');
                    if(!str_starts_with($areaId,'core:area:'))throw new RuntimeException('C2.2 Alte Bereichsbindung fehlt: '.$path);
                } elseif(($area['role']??'')==='PROPOSED_AREA'){
                    $areaId=self::new_node('area',$path);
                    $jobs[]=['node_id'=>$areaId,'parent_id'=>$worldId,'type'=>'page','name'=>$a,'slug'=>self::slug($a,$path)];
                } else throw new RuntimeException('Unbekannte Bereichsrolle: '.$path);
                foreach($area['topics'] as $topic){
                    $name=(string)$topic['name'];$topicKey=$path.'|'.$name;$topicId=self::new_node('topic',$topicKey);
                    $jobs[]=['node_id'=>$topicId,'parent_id'=>$areaId,'type'=>'page','name'=>$name,'slug'=>self::slug($name,$topicKey)];
                    foreach($topic['categories'] as $cat){
                        $label=(string)$cat['name'];$key=$topicKey.'|'.$label;$catId=self::new_node('category',$key);
                        $jobs[]=['node_id'=>$catId,'parent_id'=>$topicId,'type'=>'category','name'=>$label,'slug'=>self::slug($label,$key)];
                    }
                }
            }
        }
        foreach($jobs as $j){
            $id=$j['node_id'];if(isset($taken[$id]))throw new RuntimeException('C2.2 doppelte Knoten-ID: '.$id);
            $taken[$id]=true;
        }
        if(count($jobs)!==743)throw new RuntimeException('C2.2 Delta-Zahl unplausibel: '.count($jobs));
        return self::$jobs=$jobs;
    }
    private static function preflight(bool $boundHash=true):array {
        $p=self::plan();$live=APKW_C22_Fachpruefung::live_inventory();$binding=(array)$p['live_binding'];
        if(($live['status']??'')!=='LIVE_READBACK_COMPLETE__NO_SYNC_APPROVAL'||!empty($live['issues'])||!empty($live['truncated']))
            throw new RuntimeException('C2.2 aktueller WordPress-Lesestand ist nicht vollständig und fehlerfrei.');
        if(($live['project_id']??'')!=='hab-und-bewahr'||(int)($live['worlds']??0)!==6)
            throw new RuntimeException('C2.2 falsche Projektbindung.');
        if(count($live['protected_page3']??[])!==93||count($live['protected_terms']??[])!==285)
            throw new RuntimeException('C2.2 geschützte 93/285 Objekte nicht vollständig.');
        if(($live['revision']??'')!==($binding['revision']??''))
            throw new RuntimeException('C2.2 aktive Revision seit Export verändert: keine automatische Übernahme.');
        if($boundHash&&!hash_equals((string)($binding['site_mapping_sha256']??''),(string)($live['site_mapping_sha256']??'')))
            throw new RuntimeException('C2.2 alte IDs, URLs oder Beitragszuordnungen seit dem Export verändert.');
        if(($live['permalink_structure']??'')!==($binding['expected_permalink_structure']??''))
            throw new RuntimeException('C2.2 Permalinkstruktur verändert.');
        $s=APKW_TargetTreeSync::active_snapshot();
        if(($s['revision']??'')!==$live['revision'])throw new RuntimeException('C2.2 aktiver WordPress-Snapshot inkonsistent.');
        $by=[];foreach((array)($s['nodes']??[]) as $n)if(is_array($n)&&isset($n['node_id']))$by[(string)$n['node_id']]=$n;
        $map=(array)($s['mapping']??[]);
        foreach($p['worlds'] as $w){
            $wid=(string)$w['existing_world_node_id'];
            if(($by[$wid]['display_name']??'')!==$w['name']||($by[$wid]['object_type']??'')!=='page'||empty($map[$wid]['object_id']))throw new RuntimeException('C2.2 Welt-Knoten nicht aktiv: '.$w['name']);
            foreach($w['areas'] as $a)if(($a['role']??'')==='PROTECTED_AREA'){
                $aid=(string)$a['existing_area_node_id'];
                if(($by[$aid]['display_name']??'')!==$a['name']||($by[$aid]['parent_id']??'')!==$wid||empty($map[$aid]['object_id']))throw new RuntimeException('C2.2 alte Schutzbereich-ID falsch: '.$a['name']);
            }
        }
        $pageSlugs=[];$termSlugs=[];
        foreach(self::jobs() as $j){
            if(isset($by[$j['node_id']])||isset($map[$j['node_id']]))throw new RuntimeException('C2.2 neuer ID-Bereich bereits aktiv: '.$j['node_id']);
            if($j['type']==='page')$pageSlugs[]=$j['slug'];else $termSlugs[]=$j['slug'];
        }
        // Two bounded queries instead of 743 per-node database lookups.
        $pageCollision=get_posts(['post_type'=>'page','post_status'=>'any','posts_per_page'=>1,
            'post_name__in'=>$pageSlugs,'fields'=>'ids','no_found_rows'=>true,'suppress_filters'=>true]);
        if($pageCollision)throw new RuntimeException('C2.2 neuer Seiten-Slug bereits belegt; keine Veränderung.');
        $termCollision=get_terms(['taxonomy'=>'category','hide_empty'=>false,'slug'=>$termSlugs,'number'=>1]);
        if(is_wp_error($termCollision)||!empty($termCollision))throw new RuntimeException('C2.2 neuer Kategorie-Slug bereits belegt; keine Veränderung.');
        $other=APKW_TargetTreeSync::state();
        if(in_array((string)($other['status']??''),['WRITING','READBACK','ROLLBACK_PENDING'],true))throw new RuntimeException('C2.2 anderer Kategorie-Sync läuft.');
        return ['revision'=>$live['revision'],'digest'=>$live['site_mapping_sha256'],'snapshot'=>$s];
    }
    public static function start():void {
        try {
            self::admin();check_admin_referer('apkw_c22_add_start');
            if(empty($_POST['apkw_c22_explicit_approve']))throw new RuntimeException('C2.2 Übernahme nicht bestätigt.');
            if(!self::lock())throw new RuntimeException('C2.2 anderer Vorgang aktiv.');
            try {
                $state=self::state();if(!empty($state))throw new RuntimeException('C2.2 wurde bereits begonnen; vorhandenen Status benutzen.');
                $base=self::preflight();$jobs=self::jobs();
                if(get_option(self::BACKUP,null)!==null)throw new RuntimeException('C2.2 altes Sicherheitsabbild existiert bereits. Kein erneuter Lauf.');
                update_option(self::BACKUP,$base['snapshot'],false);
                $s=['contract'=>'HB_C22_ADD_ONLY_EXECUTION_V1','status'=>'WRITING','base_revision'=>$base['revision'],
                    'base_digest'=>$base['digest'],'base_snapshot_sha256'=>hash('sha256',serialize($base['snapshot'])),
                    'created'=>[],'mapping'=>[],'write_index'=>0,'publish_index'=>0,'rollback_index'=>0,
                    'error'=>'','started_at_utc'=>gmdate('c'),'user_id'=>get_current_user_id(),'total'=>count($jobs)];
                self::save($s);
            } finally {self::unlock();}
            wp_safe_redirect(admin_url('admin.php?page=apkw-c22-kategorien&c22_add=started'));exit;
        } catch(Throwable $e){wp_die(esc_html($e->getMessage()),'C2.2 BLOCKED',['response'=>409]);}
    }
    public static function retry():void {
        try {
            self::admin();check_admin_referer('apkw_c22_add_retry');
            if(!self::lock())throw new RuntimeException('C2.2 anderer Vorgang aktiv.');
            try {
                $s=self::state();
                if(($s['status']??'')!=='ROLLED_BACK'||!empty($s['created']))
                    throw new RuntimeException('C2.2 kein vollständig zurückgerollter Fehlversuch.');
                $backup=get_option(self::BACKUP,null);
                if(!is_array($backup)||($backup['revision']??'')!==($s['base_revision']??'')||
                   !hash_equals((string)($s['base_snapshot_sha256']??''),hash('sha256',serialize($backup)))||
                   APKW_TargetTreeSync::active_revision()!==($s['base_revision']??''))
                    throw new RuntimeException('C2.2 Snapshot/Revisionsstand vor Wiederholung nicht eindeutig.');
                // Do not reset if the current live owner/URL/post bindings have drifted.
                self::preflight();
                delete_option(self::STATE);delete_option(self::BACKUP);
            } finally {self::unlock();}
            wp_safe_redirect(admin_url('admin.php?page=apkw-c22-kategorien&c22_add=retry_ready'));exit;
        } catch(Throwable $e){wp_die(esc_html($e->getMessage()),'C2.2 BLOCKED',['response'=>409]);}
    }
    private static function lock():bool {
        $now=time();$x=(int)get_option(self::LOCK,0);if($x&&$now-$x<180)return false;
        if($x)delete_option(self::LOCK);
        return add_option(self::LOCK,$now,'','no');
    }
    private static function unlock():void {delete_option(self::LOCK);}
    private static function guard_revision(array $s):void {
        if((string)APKW_TargetTreeSync::active_revision()!==(string)$s['base_revision'])throw new RuntimeException('C2.2 aktive Revision hat sich verändert.');
        $snap=APKW_TargetTreeSync::active_snapshot();
        if(($snap['revision']??'')!==$s['base_revision'])throw new RuntimeException('C2.2 alte Struktur nicht mehr konsistent.');
    }
    private static function new_object(array $job,array $s):array {
        $type=$job['type'];$parent=$job['parent_id'];$id=(int)($s['mapping'][$parent]['object_id']??0);
        if(!$id){$active=APKW_TargetTreeSync::active_snapshot();$id=(int)($active['mapping'][$parent]['object_id']??0);}
        if(!$id)throw new RuntimeException('C2.2 Elternobjekt fehlt: '.$parent);
        if($type==='page') {
            $post=get_post($id);
            if(!$post||$post->post_type!=='page')throw new RuntimeException('C2.2 Eltern-WordPress-Seite falsch: '.$parent);
            $oid=APKW_TargetWriter::target_tree_insert_page(['post_title'=>$job['name'],'post_name'=>$job['slug'],
                'post_parent'=>$id,'post_status'=>'draft','post_content'=>'']);
            return ['kind'=>'page','id'=>$oid,'type'=>'page','node_id'=>$job['node_id']];
        }
        // Native WordPress categories remain a SINGLE FLAT taxonomy level.
        $oid=APKW_TargetWriter::target_tree_insert_term('category',['name'=>$job['name'],'slug'=>$job['slug'],'parent'=>0]);
        return ['kind'=>'term','id'=>$oid,'taxonomy'=>'category','type'=>'category','node_id'=>$job['node_id']];
    }
    private static function meta(array $ref,array $job,string $rev):void {
        $refType=$job['type'];$pairs=[
            '_apkw_target_node_id'=>$job['node_id'],'_apkw_concept_id'=>$job['node_id'],
            '_apkw_parent_concept_id'=>$job['parent_id'],'_apkw_target_pillar'=>'core',
            '_apkw_portal_block'=>'content','_apkw_portal_root'=>'0','_apkw_target_active'=>'1',
            '_apkw_target_revision'=>$rev,'_apkw_seo_index_approved'=>'0',
        ];
        foreach($pairs as $name=>$value)APKW_TargetWriter::target_tree_set_meta($ref,$refType,$name,(string)$value);
    }
    private static function target_revision(string $baseRevision):string {
        $p=self::plan();
        return $baseRevision.'+C22-'.substr((string)$p['integrity']['manifest_sha256_utf8'],0,16);
    }
    private static function make_snapshot(array $s):array {
        $base=APKW_TargetTreeSync::active_snapshot();$plan=self::plan();$jobs=self::jobs();
        $idx=[];foreach((array)($base['nodes']??[]) as $n)if(is_array($n))$idx[(string)($n['node_id']??'')]=true;
        foreach($jobs as $job){
            if(isset($idx[$job['node_id']]))throw new RuntimeException('C2.2 doppelte Ziel-ID');
            $idx[$job['node_id']]=true;
            $base['nodes'][]=['node_id'=>$job['node_id'],'pillar'=>'core','object_type'=>$job['type'],
                'parent_id'=>$job['parent_id'],'display_name'=>$job['name'],'slug'=>$job['slug'],
                'status'=>'active','seo_owner'=>false,'seo_seed'=>'','intent_key'=>'','primary_keyword'=>'',
                'c22_category_only'=>true];
            $ref=$s['mapping'][$job['node_id']]??null;if(!$ref||empty($ref['object_id']))throw new RuntimeException('C2.2 neue Zuordnung fehlt.');
            $base['mapping'][$job['node_id']]=$ref;
        }
        $rev=self::target_revision((string)$s['base_revision']);
        $base['revision']=$rev;$base['project']['c22_add_only_base_revision']=$s['base_revision'];
        $base['project']['c22_add_only_applied_at_utc']=gmdate('c');
        $base['completed_at_utc']=gmdate('c');
        return $base;
    }
    private static function verify_new_objects(array $s):void {
        $existing=APKW_TargetTreeSync::active_snapshot();
        $allMapping=array_merge((array)($existing['mapping']??[]),(array)$s['mapping']);
        foreach(self::jobs() as $job){
            $node=$job['node_id'];$type=$job['type'];
            $id=(int)($s['mapping'][$node]['object_id']??0);
            $parentId=(int)($allMapping[$job['parent_id']]['object_id']??0);
            if($id<1||$parentId<1)throw new RuntimeException('C2.2 neue WordPress-ID/Eltern-ID fehlt: '.$node);
            if($type==='page'){
                $item=get_post($id);
                if(!is_object($item)||($item->post_type??'')!=='page'||($item->post_status??'')!=='publish'||
                   (string)($item->post_name??'')!==$job['slug']||(int)($item->post_parent??0)!==$parentId)
                    throw new RuntimeException('C2.2 neuer Themenhub falsch angelegt: '.$node);
                $actualName=(string)($item->post_title??'');
                $link=get_permalink($id);
                $owner=(string)get_post_meta($id,'_apkw_parent_concept_id',true);
                $binding=(string)get_post_meta($id,'_apkw_target_node_id',true);
            } else {
                $item=get_term($id,'category');
                if(!is_object($item)||is_wp_error($item)||($item->taxonomy??'')!=='category'||
                   (string)($item->slug??'')!==$job['slug']||(int)($item->parent??-1)!==0)
                    throw new RuntimeException('C2.2 neuer flacher Artikel-Term falsch: '.$node);
                $actualName=(string)($item->name??'');
                $link=get_term_link($id,'category');
                $owner=(string)get_term_meta($id,'_apkw_parent_concept_id',true);
                $binding=(string)get_term_meta($id,'_apkw_target_node_id',true);
            }
            $actualName=function_exists('wp_specialchars_decode')?wp_specialchars_decode($actualName,ENT_QUOTES):html_entity_decode($actualName,ENT_QUOTES|ENT_HTML5,'UTF-8');
            if($actualName!==$job['name']||$owner!==$job['parent_id']||$binding!==$node||
               is_wp_error($link)||!is_string($link)||!str_starts_with($link,'https://'))
                throw new RuntimeException('C2.2 Name, Kategorie-Bindung oder URL nicht bestätigt: '.$node);
        }
    }
    private static function finish(array &$s):void {
        // Re-read the full protected object and every old article relationship,
        // before exposing any newly created pages in the canonical menu.
        $live=APKW_C22_Fachpruefung::live_inventory();
        if(($live['revision']??'')!==$s['base_revision']||!empty($live['issues'])||
            !hash_equals((string)$s['base_digest'],(string)($live['site_mapping_sha256']??'')))
            throw new RuntimeException('C2.2 alte WordPress-Seiten/Terms/Artikel nicht unverändert: Rollback.');
        self::verify_new_objects($s);
        $candidate=self::make_snapshot($s);
        // Full true WordPress page/term/menu readback, using existing frontend validator.
        $frontend=APKW_FinalTargetAdmin::frontend_readback($candidate);
        if(empty($frontend['valid']))throw new RuntimeException('C2.2 Navigations-/Kategorie-Readback fehlgeschlagen: '.implode(',',(array)$frontend['errors']));
        update_option(self::SNAP,$candidate,false);
        update_option(self::REV,(string)$candidate['revision'],false);
        if((string)APKW_TargetTreeSync::active_revision()!==(string)$candidate['revision'])throw new RuntimeException('C2.2 aktive Zielrevision nicht lesbar.');
        $after=APKW_FinalTargetAdmin::frontend_readback();
        if(empty($after['valid']))throw new RuntimeException('C2.2 finale Frontend-Validierung fehlgeschlagen.');
        if(class_exists('APKW_FrontendStructure'))APKW_FrontendStructure::invalidate_cache();
        $s['status']='COMPLETE';$s['completed_at_utc']=gmdate('c');$s['result']=['new_areas'=>5,'new_topic_pages'=>172,'new_article_categories'=>566,'old_page3_unchanged'=>93,'old_categories_unchanged'=>285,'old_post_term_links_unchanged'=>4,'readback'=>'PASS'];
        self::save($s);
    }
    private static function rollback(array &$s):void {
        // Restore ORIGINAL authoritative snapshot before removing new nodes.
        $origRevision=(string)$s['base_revision'];$cur=(string)APKW_TargetTreeSync::active_revision();
        $currentSnapshot=APKW_TargetTreeSync::active_snapshot();
        // If interrupted between the two WordPress option updates, the old
        // revision may still be current while the new snapshot was written.
        if(($cur===$origRevision||str_starts_with($cur,$origRevision.'+C22-')) &&
           str_starts_with((string)($currentSnapshot['revision']??''),$origRevision.'+C22-')) {
            // Exact saved old snapshot: never attempt approximate re-composition.
            $backup=get_option(self::BACKUP,null);
            if(!is_array($backup)||($backup['revision']??'')!==$origRevision||
               !hash_equals((string)($s['base_snapshot_sha256']??''),hash('sha256',serialize($backup))))
                throw new RuntimeException('C2.2 originaler Snapshot-Backup fehlt/abweichend; kein automatischer Rückbau.');
            update_option(self::SNAP,$backup,false);update_option(self::REV,$origRevision,false);
        }
        $left=0;
        while($left<self::LIMIT && !empty($s['created'])) {
            $ref=end($s['created']);
            // Fail closed if someone has linked a post to a newly created category.
            if($ref['kind']==='term'){
                $term=get_term((int)$ref['id'],'category');
                if(!is_object($term)||is_wp_error($term)||(int)$term->count!==0)
                    throw new RuntimeException('C2.2 neuer Term kann nicht sicher gelöscht werden (fehlend/belegt).');
            }
            APKW_TargetWriter::target_tree_delete_object($ref);
            array_pop($s['created']);$left++;self::save($s);
        }
        if(!$s['created']){$s['status']='ROLLED_BACK';$s['completed_at_utc']=gmdate('c');self::save($s);}
    }
    private static function run():array {
        $s=self::state();if(!in_array((string)($s['status']??''),['WRITING','PUBLISH','VERIFY','ROLLBACK'],true))return $s;
        if(!self::lock())return $s;
        try {
            $s=self::state();if(($s['status']??'')==='ROLLBACK'){
                try{self::rollback($s);}catch(Throwable $e){$s['status']='ROLLBACK_FAILED';$s['error'].=' | Rückbau: '.$e->getMessage();self::save($s);}
                return $s;
            }
            try {
                self::guard_revision($s);$jobs=self::jobs();
                if($s['status']==='WRITING'){
                    $done=0;
                    while($done<self::LIMIT && $s['write_index']<count($jobs)){
                        $job=$jobs[$s['write_index']];$ref=self::new_object($job,$s);
                        $s['created'][]=$ref;
                        $s['mapping'][$job['node_id']]=['object_id'=>$ref['id'],'object_type'=>$job['type'],
                            'adapter'=>$job['type']==='page'?'wordpress_page':'wordpress_taxonomy',
                            'taxonomy'=>$job['type']==='page'?null:'category'];
                        // Persist new physical object ID before any metadata write.
                        self::save($s);self::meta($ref,$job,self::target_revision((string)$s['base_revision']));
                        $s['write_index']++;self::save($s);$done++;
                    }
                    if($s['write_index']>=count($jobs)){$s['status']='PUBLISH';self::save($s);}
                } elseif($s['status']==='PUBLISH') {
                    $pages=array_values(array_filter($s['created'],static fn($x)=>$x['kind']==='page'));
                    $n=0;while($n<self::LIMIT && $s['publish_index']<count($pages)){
                        $ref=$pages[$s['publish_index']];
                        APKW_TargetWriter::target_tree_update_page((int)$ref['id'],['post_status'=>'publish']);
                        $s['publish_index']++;self::save($s);$n++;
                    }
                    if($s['publish_index']>=count($pages)){$s['status']='VERIFY';self::save($s);}
                } elseif($s['status']==='VERIFY')self::finish($s);
            } catch(Throwable $e){
                $s['status']='ROLLBACK';$s['error']=$e->getMessage();self::save($s);
            }
        } finally {self::unlock();}
        return $s;
    }
    public static function tick():void {
        try{
            self::admin();check_ajax_referer('apkw_c22_add_tick','nonce');
            $s=self::run();
            wp_send_json_success(['status'=>$s['status']??'NOT_STARTED','written'=>(int)($s['write_index']??0),
                'total'=>(int)($s['total']??743),'published'=>(int)($s['publish_index']??0),
                'error'=>(string)($s['error']??''),'result'=>$s['result']??null]);
        } catch(Throwable $e){wp_send_json_error(['error'=>$e->getMessage()],409);}
    }
    public static function render_controls():void {
        $state=self::state();$status=(string)($state['status']??'');
        echo '<hr><h2>C2.2 – geprüfte Ergänzungen in WordPress übernehmen</h2>';
        echo '<p><strong>ADD ONLY:</strong> fünf Bereiche, 172 Themenseiten, 566 flache Artikelkategorien. Vorhandene 93 Seiten, 285 Kategorien und Beitragszuordnungen bleiben unangetastet. Keine Artikel, keine DataForSEO-Abfrage.</p>';
        if($status==='COMPLETE'){
            $check=self::completion_audit();
            if(!empty($check['valid'])){
                echo '<div class="notice notice-success inline"><p><strong>C2.2 fertig:</strong> 5 Schutzbereiche, 172 neue Themenseiten, 566 neue Artikelkategorien. Alle 743 neuen Zielbaum-IDs sowie die erhaltenen 93 alten Themenseiten und 285 Kategorien überprüft. Die tatsächliche WordPress-Anlage wurde beim Abschluss kontrolliert; keine weiteren Importe erforderlich. Alte URLs und Artikel bleiben bestehen. Artikel werden ausschließlich später durch die Text-Engine erstellt.</p></div>';
            }else{
                echo '<div class="notice notice-error inline"><p><strong>C2.2-Abweichung erkannt:</strong> '.esc_html(implode(' | ',(array)($check['errors']??[]))).'. Keine automatische Änderung.</p></div>';
            }
            return;
        }
        if($status==='ROLLED_BACK'||$status==='ROLLBACK_FAILED'){
            echo '<div class="notice notice-error inline"><p>C2.2 abgebrochen. '.esc_html((string)($state['error']??'')).' · Status: '.esc_html($status).'</p></div>';
            if($status==='ROLLED_BACK'){
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_c22_add_retry">';
                wp_nonce_field('apkw_c22_add_retry');submit_button('Gesicherten Wiederholversuch vorbereiten','secondary');echo '</form>';
            }
            return;
        }
        if(in_array($status,['WRITING','PUBLISH','VERIFY','ROLLBACK'],true)){
            echo '<div class="notice notice-info inline"><p>Kontrollierte Ergänzung läuft. Browserseite offen lassen; bei Unterbrechung hier fortsetzen. Stand: '.esc_html((string)($state['write_index']??0)).' / 743.</p></div>';
            self::progress_script();return;
        }
        echo '<p>Der hochgeladene Live-Bestand ist im Plugin gebunden. Vor Start werden Revision, tatsächliche WordPress-IDs/URLs und Beitragszuordnungen erneut verglichen. Bei Unstimmigkeiten erfolgt <strong>keine Änderung</strong>.</p>';
        echo '<form action="'.esc_url(admin_url('admin-post.php')).'" method="post"><input type="hidden" name="action" value="apkw_c22_add_start">';
        wp_nonce_field('apkw_c22_add_start');
        echo '<p><label><input type="checkbox" name="apkw_c22_explicit_approve" value="1" required> Ich bestätige die reine zusätzliche Anlage der C2.2-Struktur (keine alten WordPress-Objekte ändern).</label></p>';
        submit_button('C2.2 Kategorien kontrolliert übernehmen','primary');echo '</form>';
    }
    private static function progress_script():void {
        $ajax=esc_url(admin_url('admin-ajax.php'));$nonce=wp_create_nonce('apkw_c22_add_tick');
        echo '<div id="apkw-c22-progress" role="status">Wird ausgeführt…</div>';
        echo '<script>(function(){const u='.json_encode($ajax).',n='.json_encode($nonce).';let active=true;async function go(){if(!active)return;try{const p=new URLSearchParams({action:"apkw_c22_add_tick",nonce:n});const r=await fetch(u,{method:"POST",credentials:"same-origin",body:p});const o=await r.json();if(!r.ok||!o.success)throw new Error(o.data?.error||"Serverfehler");const d=o.data;document.getElementById("apkw-c22-progress").textContent=d.status+" · "+d.written+" / "+d.total+(d.error?" · "+d.error:"");if(["COMPLETE","ROLLED_BACK","ROLLBACK_FAILED"].includes(d.status)){active=false;location.reload();return;}setTimeout(go,500);}catch(e){document.getElementById("apkw-c22-progress").textContent="Übernahme angehalten: "+e.message+". Zum Fortsetzen Seite neu laden.";active=false;}}go();})();</script>';
    }
}
