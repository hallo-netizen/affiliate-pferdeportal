<?php
if (!defined('ABSPATH')) { exit; }
/**
 * C2.2 Kategoriensystem: fachlicher Sollbaum + sichere Live-Readback-Vorpruefung.
 * Fachprüfung und Live-Readback bleiben read-only. Separater bestätigter
 * ADD-only-Sync über denselben APKW_TargetWriter, keine Nebenwriter.
 * Die bestehende APKW-Kategorienverwaltung bleibt der einzige Writer.
 */
final class APKW_C22_Fachpruefung {
    private const FILE = 'profiles/hab-und-bewahr-c22-plan.json';
    private const ROUTE = 'apkw-c22-kategorien';
    private static ?array $cache = null;

    public static function init(): void {
        if (function_exists('add_action')) {
            // Parent APKW_FinalTargetAdmin::menu() is registered at admin_menu priority 30.
            // C2.2 must be registered AFTER the parent, otherwise WordPress can
            // reject admin.php?page=apkw-c22-kategorien as an unregistered page.
            add_action('admin_menu', [__CLASS__, 'register_menu'], 46);
            add_action('admin_post_apkw_c22_export', [__CLASS__, 'export']);
            add_action('admin_post_apkw_c22_live_export', [__CLASS__, 'export_live']);
        }
    }
    public static function register_menu(): void {
        if (!function_exists('add_submenu_page')) return;
        add_submenu_page('apkw-final-target-tree', 'C2.2 Kategorien – Fachprüfung', 'C2.2 Kategorien',
            'manage_options', self::ROUTE, [__CLASS__, 'render']);
    }
    public static function plan(): ?array {
        if (self::$cache !== null) return self::$cache;
        $f = APKW_DIR . self::FILE;
        if (!is_readable($f)) return null;
        $decoded = json_decode((string)file_get_contents($f), true);
        if (!is_array($decoded)) return null;
        self::$cache = $decoded;
        return self::$cache;
    }
    public static function readback(): array {
        $result = ['available'=>false,'revision'=>null,'pages'=>0,'core_categories'=>0,
            'category_ids'=>[],'issues'=>[]];
        if (!class_exists('APKW_TargetTreeSync') ||
            !method_exists('APKW_TargetTreeSync', 'active_snapshot') ||
            !method_exists('APKW_TargetTreeSync', 'active_revision')) {
            $result['issues'][]='NO_EXISTING_WORKFLOW_READBACK'; return $result;
        }
        try {
            $snapshot = APKW_TargetTreeSync::active_snapshot();
            $revision = (string)APKW_TargetTreeSync::active_revision();
        } catch (Throwable $e) { $result['issues'][]='READBACK_EXCEPTION'; return $result; }
        if (!is_array($snapshot) || $revision==='' || (string)($snapshot['revision']??'')!==$revision) {
            $result['issues'][]='NO_CONSISTENT_ACTIVE_REVISION'; return $result;
        }
        $result['available']=true;$result['revision']=$revision;
        foreach ((array)($snapshot['nodes']??[]) as $node) {
            if (!is_array($node) || (string)($node['status']??'active')!=='active' ||
                (string)($node['pillar']??'')!=='core') continue;
            if (($node['object_type']??'')==='page') $result['pages']++;
            if (($node['object_type']??'')==='category') {
                $result['core_categories']++;
                $id=(string)($node['node_id']??'');
                $map=(array)($snapshot['mapping']??[]);
                if ($id!=='' && !empty($map[$id]['object_id'])) $result['category_ids'][$id]=(int)$map[$id]['object_id'];
            }
        }
        return $result;
    }
    /**
     * Check concept structure, not editorial article production or provider SERPs.
     * Three short indicators are *not* proof of three completed article ideas.
     */
    public static function audit(?array $plan=null, ?array $readback=null): array {
        $plan = $plan ?? self::plan();
        $readback = $readback ?? self::readback();
        $errors=[];$warnings=[];$stats=['worlds'=>0,'areas'=>0,'topic_pages'=>0,'article_categories'=>0,
            'topic_categories'=>[],'plausible_provisional'=>0,'needs_review'=>0];
        if (!is_array($plan) || ($plan['contract']??'')!=='HB_C22_CATEGORY_ONLY_V1') {
            return ['valid'=>false,'eligible_for_live_sync'=>false,'errors'=>['C22_PLAN_MISSING_OR_INVALID'],
                'warnings'=>[],'counts'=>$stats,'readback'=>$readback];
        }
        $seenCats=[];$seenTopic=[];$seenAreas=[];
        foreach ((array)($plan['worlds']??[]) as $w) {
            if (!is_array($w)) {$errors[]='C22_WORLD_INVALID';continue;}
            $world=trim((string)($w['name']??''));if($world==='') {$errors[]='C22_WORLD_EMPTY';continue;}
            $stats['worlds']++;
            foreach ((array)($w['areas']??[]) as $a) {
                if(!is_array($a)){$errors[]='C22_AREA_INVALID';continue;}
                $area=trim((string)($a['name']??''));$scope=$world.'|'.$area;
                if($area==='' || isset($seenAreas[$scope])) $errors[]='C22_AREA_EMPTY_OR_DUPLICATE:'.$scope;
                $seenAreas[$scope]=true;$stats['areas']++;
                foreach ((array)($a['topics']??[]) as $t) {
                    if(!is_array($t)){$errors[]='C22_TOPIC_INVALID';continue;}
                    $name=trim((string)($t['name']??''));$tid=$scope.'|'.$name;
                    if($name===''||isset($seenTopic[$tid]))$errors[]='C22_TOPIC_EMPTY_OR_DUPLICATE:'.$tid;
                    $seenTopic[$tid]=true;$stats['topic_pages']++;
                    $categories=(array)($t['categories']??[]);
                    $stats['topic_categories'][$tid]=count($categories);
                    if(count($categories)<3)$errors[]='C22_TOPIC_TOO_FEW_INTENT_CATEGORIES:'.$tid;
                    foreach ($categories as $c) {
                        if(!is_array($c)){$errors[]='C22_INTENT_CATEGORY_INVALID:'.$tid;continue;}
                        $label=trim((string)($c['name']??''));$lc=function_exists('mb_strtolower')?mb_strtolower($label,'UTF-8'):strtolower($label);
                        if($label===''||isset($seenCats[$lc]))$errors[]='C22_INTENT_CATEGORY_DUPLICATE_OR_EMPTY:'.$label;
                        $seenCats[$lc]=true;$stats['article_categories']++;
                        $check=(string)($c['capacity_status']??'');
                        if ($check==='PLAUSIBLE_PROVISIONAL') $stats['plausible_provisional']++;
                        elseif ($check==='OPEN_REVIEW') {
                            $stats['needs_review']++;
                            $warnings[]='C22_KATEGORIE_GROBPRUEFUNG_OFFEN:'.$tid.'|'.$label;
                        } else $errors[]='C22_CATEGORY_CAPACITY_STATE_INVALID:'.$label;
                        $range=(array)($c['potential_range']??[]);
                        if ($range!==[3,5]) $errors[]='C22_MINIMUM_CAPACITY_RANGE_INVALID:'.$label;
                        if(!empty($c['article_titles'])||!empty($c['article_content']))$errors[]='C22_ARTICLE_CREATION_OUT_OF_SCOPE:'.$label;
                    }
                }
            }
        }
        if($stats['worlds']!==6)$errors[]='C22_WORLD_COUNT_INVALID';
        if($stats['areas']!==36)$errors[]='C22_AREA_COUNT_INVALID';
        // Counts are checksums for THIS snapshot, not a permanent content cap.
        $manifest=[];
        foreach ((array)($plan['worlds']??[]) as $w)
            foreach ((array)($w['areas']??[]) as $a)
                foreach ((array)($a['topics']??[]) as $t)
                    foreach ((array)($t['categories']??[]) as $c)
                        $manifest[]=($w['name']??'').'|'.($a['name']??'').'|'.($t['name']??'').'|'.($c['name']??'');
        sort($manifest,SORT_STRING);
        $fingerprint=hash('sha256',implode("\n",$manifest));
        if (!hash_equals((string)($plan['integrity']['manifest_sha256_utf8']??''),$fingerprint))
            $errors[]='C22_MANIFEST_CHECKSUM_MISMATCH';

        $expected=(array)($plan['integrity']??[]);
        if(!empty($expected['topics'])&&(int)$expected['topics']!==$stats['topic_pages'])$errors[]='C22_TOPIC_MANIFEST_MISMATCH';
        if(!empty($expected['categories'])&&(int)$expected['categories']!==$stats['article_categories'])$errors[]='C22_CATEGORY_MANIFEST_MISMATCH';
        if(empty($readback['available']))$warnings[]='LIVE_READBACK_MISSING_OR_UNVERIFIED';
        // The user requested ONLY rough plausibility of 3-5 future articles;
        // 566/566 category labels were checked for that limited scope.
        // Protected historic URLs and four coincident label names are legacy
        // compatibility, NOT an instruction to delete or migrate WordPress IDs.
        // Never generate permanent yellow warnings for a successful ADD pass.
        // No completed articles or exact SEO query coverage are asserted.
        $complete=class_exists('APKW_C22_AddOnly')&&
            (string)(APKW_C22_AddOnly::state()['status']??'')==='COMPLETE';
        return ['valid'=>empty($errors),'eligible_for_live_sync'=>false,
            'category_scope'=>'GROB_3_BIS_5_PLAUSIBEL_KEINE_ARTIKEL',
            'legacy_mode'=>'GESCHUETZT_BEHALTEN_KEINE_STILLE_URL_AENDERUNG',
            'c22_add_completed'=>$complete,
            'errors'=>array_values(array_unique($errors)),'warnings'=>array_values(array_unique($warnings)),
            'counts'=>$stats,'readback'=>$readback,'checked_at_utc'=>gmdate('c')];
    }
    public static function export(): void {
        if(!function_exists('current_user_can')||!current_user_can('manage_options'))wp_die('Keine Berechtigung');
        if(function_exists('check_admin_referer'))check_admin_referer('apkw_c22_export');
        $out=['contract'=>'HB_C22_CATEGORY_ONLY_READBACK','category_plan'=>self::plan(),'audit'=>self::audit()];
        if(function_exists('nocache_headers'))nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="hab-und-bewahr-c22-kategorien-pruefung.json"');
        echo function_exists('wp_json_encode')?wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        exit;
    }
    /**
     * Explicit administrator-only readback. One bounded SQL read of existing
     * post/category relationships, without writes or network/provider calls.
     * This is a data proof, NOT authorization to convert old WP term IDs.
     */
    public static function live_inventory(): array {
        $result = [
            'contract'=>'HB_C22_LIVE_ID_URL_AND_POST_TERM_READBACK_V1',
            'generated_at_utc'=>gmdate('c'), 'plugin_version'=>defined('APKW_VERSION')?APKW_VERSION:'',
            'safe_read_only'=>true, 'synced_categories'=>false,
            'status'=>'BLOCKED', 'issues'=>[], 'worlds'=>0,
            'protected_page3'=>[], 'protected_terms'=>[], 'post_term_links'=>[],
            'permalink_structure'=>function_exists('get_option')?(string)get_option('permalink_structure',''):'',
            'revision'=>null, 'truncated'=>false,
        ];
        $rb = self::readback();
        if (empty($rb['available'])) {
            $result['issues'][]='NO_CONSISTENT_ACTIVE_SNAPSHOT';
            return $result;
        }
        $snapshot=APKW_TargetTreeSync::active_snapshot();
        $map=(array)($snapshot['mapping']??[]);
        $nodes=(array)($snapshot['nodes']??[]);
        $nodeMap=[];
        foreach ($nodes as $n) if(is_array($n)&&!empty($n['node_id'])) {
            $nodeMap[(string)$n['node_id']]=$n;
        }
        $result['revision']=$rb['revision'];
        $result['active_snapshot_utc']=(string)($snapshot['completed_at_utc']??'');
        $result['project_id']=(string)($snapshot['project']['project_id']??'');
        $result['worlds']=count(array_filter($nodes,static fn($n)=>is_array($n)&&($n['pillar']??'')==='core'&&($n['object_type']??'')==='page'&&str_starts_with((string)($n['node_id']??''),'core:world:')));
        foreach ($nodes as $n) {
            if(!is_array($n)||($n['pillar']??'')!=='core'||($n['status']??'active')!=='active')continue;
            $type=(string)($n['object_type']??'');
            if($type!=='category'&&$type!=='page')continue;
            $id=(string)($n['node_id']??'');
            // Existing R3 Page3/leaf IDs are protected even when C2.2 adds
            // additional nodes with a different prefix in the future.
            $oldPage=$type==='page'&&str_starts_with($id,'core:subarea:');
            $oldTerm=$type==='category'&&str_starts_with($id,'core:leaf:');
            if(!$oldPage&&!$oldTerm)continue;
            $wpId=(int)($map[$id]['object_id']??0);
            $parentId=(string)($n['parent_id']??'');
            $record=[
                'node_id'=>$id, 'name_expected'=>(string)($n['display_name']??''),
                'slug_expected'=>(string)($n['slug']??''), 'parent_node_id'=>$parentId,
                'wp_id'=>$wpId, 'name_actual'=>null, 'slug_actual'=>null,
                'link'=>null, 'parent_wp_id'=>0, 'conceptual_parent_node_id'=>null,
                'object_exists'=>false, 'identity_matches'=>false,
            ];
            if ($wpId<=0){$result['issues'][]='WP_ID_MISSING:'.$id;}
            elseif ($oldPage && function_exists('get_post')) {
                $post=get_post($wpId);
                if($post && ($post->post_type??'')==='page'){
                    $record['object_exists']=true;
                    $record['name_actual']=function_exists('wp_specialchars_decode')?wp_specialchars_decode((string)$post->post_title, ENT_QUOTES):(string)$post->post_title;
                    $record['slug_actual']=(string)$post->post_name;
                    $record['parent_wp_id']=(int)$post->post_parent;
                    $record['link']=function_exists('get_permalink')?(string)get_permalink($wpId):null;
                    $record['conceptual_parent_node_id']=function_exists('get_post_meta')?(string)get_post_meta($wpId,'_apkw_parent_concept_id',true):null;
                    $record['identity_matches']=$record['name_actual']===$record['name_expected']&&$record['slug_actual']===$record['slug_expected']&&$record['conceptual_parent_node_id']===$parentId;
                    if($parentId!=='' && isset($map[$parentId]['object_id']) && $record['parent_wp_id']!==(int)$map[$parentId]['object_id'])$record['identity_matches']=false;
                }
            } elseif($oldTerm && function_exists('get_term')) {
                $term=get_term($wpId,'category');
                if($term && !(function_exists('is_wp_error')&&is_wp_error($term)) && ($term->taxonomy??'')==='category'){
                    $record['object_exists']=true;
                    // WP get_term() may return names HTML-encoded, e.g. &amp;
                    // while our signed active profile carries the display string with &.
                    // Normalize only for identity readback. Never modify the term,
                    // category slug, URL, parent, or stored WordPress object.
                    $actualName=(string)$term->name;
                    $record['name_actual']=function_exists('wp_specialchars_decode')
                        ? wp_specialchars_decode($actualName, ENT_QUOTES)
                        : html_entity_decode($actualName, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    $record['slug_actual']=(string)$term->slug;
                    $record['parent_wp_id']=(int)$term->parent;
                    $url=function_exists('get_term_link')?get_term_link($term):null;
                    $record['link']=(!is_object($url))?(string)$url:null;
                    $record['conceptual_parent_node_id']=function_exists('get_term_meta')?(string)get_term_meta($wpId,'_apkw_parent_concept_id',true):null;
                    $record['identity_matches']=$record['name_actual']===$record['name_expected']&&$record['slug_actual']===$record['slug_expected']&&$record['conceptual_parent_node_id']===$parentId&&$record['parent_wp_id']===0;
                }
            }
            if($record['object_exists'] && !$record['link'])$result['issues'][]='WP_PERMALINK_MISSING:'.$id;
            if(!$record['object_exists'])$result['issues'][]='WP_OBJECT_MISSING_OR_TYPE_MISMATCH:'.$id;
            elseif(!$record['identity_matches'])$result['issues'][]='LIVE_ID_SLUG_PARENT_MISMATCH:'.$id;
            if($oldPage)$result['protected_page3'][]=$record;
            else $result['protected_terms'][]=$record;
        }
        if(count($result['protected_page3'])!==93)$result['issues'][]='HISTORIC_93_PAGES_NOT_COMPLETE:'.count($result['protected_page3']);
        if(count($result['protected_terms'])!==285)$result['issues'][]='HISTORIC_285_TERMS_NOT_COMPLETE:'.count($result['protected_terms']);
        if($result['worlds']!==6)$result['issues'][]='HISTORIC_SIX_WORLDS_NOT_PRESENT';
        $termIds=array_values(array_unique(array_filter(array_map(static fn($x)=>(int)$x['wp_id'],$result['protected_terms']))));
        sort($termIds,SORT_NUMERIC);
        // O(1) indexed relationship query, not 285 repeated WordPress queries.
        global $wpdb;
        if(!$termIds || !isset($wpdb) || !method_exists($wpdb,'prepare')||!method_exists($wpdb,'get_results')){
            $result['issues'][]='POST_TERM_LINK_READBACK_UNAVAILABLE';
        }else{
            $placeholders=implode(',',array_fill(0,count($termIds),'%d'));
            $sql="SELECT tr.object_id AS post_id,tt.term_id AS term_id,p.post_status AS status
                  FROM {$wpdb->term_relationships} tr
                  INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id
                  INNER JOIN {$wpdb->posts} p ON p.ID=tr.object_id
                  WHERE tt.taxonomy='category' AND tt.term_id IN ($placeholders)
                    AND p.post_type='post' AND p.post_status<>'auto-draft'
                  ORDER BY tr.object_id, tt.term_id LIMIT 10001";
            $query=$wpdb->prepare($sql,...$termIds);
            $rows=$wpdb->get_results($query,ARRAY_A);
            if(!is_array($rows))$result['issues'][]='POST_TERM_LINK_SQL_FAILED';
            else{
                if(count($rows)>10000){$result['truncated']=true;$result['issues'][]='POST_TERM_LINK_EXPORT_OVER_10000';$rows=array_slice($rows,0,10000);}
                $urls=[];
                foreach($rows as $row){
                    $postId=(int)($row['post_id']??0);$termId=(int)($row['term_id']??0);
                    if($postId<1||$termId<1)continue;
                    if(!array_key_exists($postId,$urls))$urls[$postId]=function_exists('get_permalink')?(string)get_permalink($postId):'';
                    $result['post_term_links'][]=['post_id'=>$postId,'category_term_id'=>$termId,
                        'post_status'=>(string)($row['status']??''),'post_permalink'=>$urls[$postId]];
                }
            }
        }
        $result['summary']=[
            'protected_pages'=>count($result['protected_page3']),
            'protected_categories'=>count($result['protected_terms']),
            'relations'=>count($result['post_term_links']),
            'unique_posts'=>count(array_unique(array_column($result['post_term_links'],'post_id'))),
        ];
        $fingerprint=[];
        foreach(array_merge($result['protected_page3'],$result['protected_terms']) as $n)
            $fingerprint[]=implode('|',[(string)$n['node_id'],(string)$n['wp_id'],(string)$n['slug_actual'],(string)$n['parent_wp_id'],(string)$n['link']]);
        foreach($result['post_term_links'] as $link)$fingerprint[]=$link['post_id'].'|'.$link['category_term_id'].'|'.$link['post_permalink'];
        sort($fingerprint,SORT_STRING);
        $result['site_mapping_sha256']=hash('sha256',implode("\n",$fingerprint));
        $endingRevision=(string)APKW_TargetTreeSync::active_revision();
        if($endingRevision!==$result['revision'])$result['issues'][]='ACTIVE_REVISION_CHANGED_DURING_READBACK';
        $result['issues']=array_values(array_unique($result['issues']));
        // A completed ADD-only job must not be exported as "unsynced".
        // Check the real active node/mapping set and the saved physical
        // verification from the original write, not just the 93/285 archive.
        if(class_exists('APKW_C22_AddOnly') &&
           (string)(APKW_C22_AddOnly::state()['status']??'')==='COMPLETE'){
            $sync=APKW_C22_AddOnly::completion_audit();
            $result['c22_completion']=$sync;
            $result['synced_categories']=!empty($sync['valid']);
            if(empty($sync['valid']))
                $result['issues']=array_merge($result['issues'],(array)($sync['errors']??['C22_UNVERIFIED']));
        }
        $result['issues']=array_values(array_unique($result['issues']));
        $result['status']=$result['issues']?'BLOCKED':
            ($result['synced_categories']?'LIVE_READBACK_COMPLETE__C22_ADDED_AND_VERIFIED':'LIVE_READBACK_COMPLETE__NO_SYNC_APPROVAL');
        return $result;
    }
    public static function export_live(): void {
        if(!function_exists('current_user_can')||!current_user_can('manage_options')){
            if(function_exists('wp_die'))wp_die('Keine Berechtigung');return;
        }
        if(function_exists('check_admin_referer'))check_admin_referer('apkw_c22_live_export');
        $result=self::live_inventory();
        if(function_exists('nocache_headers'))nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="hab-und-bewahr-c22-live-bestand.json"');
        echo function_exists('wp_json_encode')?wp_json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function render(): void {
        if(!function_exists('current_user_can')||!current_user_can('manage_options'))wp_die('Keine Berechtigung');
        $a=self::audit();$stats=$a['counts'];
        echo '<div class="wrap"><h1>Hab &amp; Bewahr: C2.2 Kategorien</h1>';
        echo '<p>Nur Kategorienplanung: Welt → Schutzbereich → konkrete Themenseite → eine flache Artikelkategorie-Ebene. Keine Artikeltitel und keine automatischen WordPress-Änderungen.</p>';
        echo '<p><strong>Fachkonzept:</strong> '.esc_html((string)$stats['worlds']).' Welten, '.esc_html((string)$stats['areas']).' Bereiche, '.esc_html((string)$stats['topic_pages']).' zusätzliche konkrete Themen, '.esc_html((string)$stats['article_categories']).' vorgesehene Artikelkategorien. Offene Grenzfaelle: '.esc_html((string)$stats['needs_review']).'.</p>';
        echo '<p><strong>Prüfung:</strong> '.($a['valid']?'STRUKTUR GÜLTIG':'BLOCKIERT').
             ' · <strong>Bestands-Sync:</strong> NICHT automatisch. Ergänzungen ausschließlich nach Live-Preflight und ausdrücklicher Bestätigung unten.</p>';
        $rb=$a['readback'];echo '<p><strong>Aktive Kategorie-Revision:</strong> '.esc_html((string)($rb['revision']??'nicht verifiziert')).'</p>';
        if(!empty($a['errors']))echo '<div class="notice notice-error"><p>'.esc_html(implode(' | ',$a['errors'])).'</p></div>';
        if(!empty($a['warnings']))echo '<div class="notice notice-warning"><p>'.esc_html(implode(' | ',$a['warnings'])).'</p></div>';
        $plan=self::plan();
        echo '<h2>Vorgeschlagene Themen und unterste Artikelkategorien</h2>';
        echo '<p>Nur die fachliche Kategorienordnung. Weitere Kategorien sind in der Seitennavigation unbegrenzt möglich. Die Artikel-Engine bearbeitet spätere konkrete Beiträge getrennt.</p>';
        foreach ((array)($plan['worlds']??[]) as $world) {
            echo '<details><summary><strong>'.esc_html((string)($world['name']??'')).'</strong></summary>';
            foreach ((array)($world['areas']??[]) as $area) {
                echo '<details style="margin:12px 24px"><summary>'.esc_html((string)($area['name']??'')).' — '.count((array)($area['topics']??[])).' neue Themen</summary>';
                foreach ((array)($area['topics']??[]) as $topic) {
                    echo '<div style="margin:12px 22px;padding:8px;border-left:2px solid #ddd"><strong>'.esc_html((string)($topic['name']??'')).'</strong><ul>';
                    foreach ((array)($topic['categories']??[]) as $cat) {
                        $held=($cat['capacity_status']??'')==='OPEN_REVIEW';
                        echo '<li>'.esc_html((string)($cat['name']??'')).($held?' — <em>Tragfähigkeit offen</em>':'').'</li>';
                    }
                    echo '</ul></div>';
                }
                echo '</details>';
            }
            echo '</details>';
        }
        echo '<form action="'.esc_url(admin_url('admin-post.php')).'" method="post"><input type="hidden" name="action" value="apkw_c22_export">';
        if(function_exists('wp_nonce_field'))wp_nonce_field('apkw_c22_export');
        if(function_exists('submit_button'))submit_button('Fachprüfung und Live-Readback exportieren','secondary');
        echo '</form>';
        echo '<form action="'.esc_url(admin_url('admin-post.php')).'" method="post"><input type="hidden" name="action" value="apkw_c22_live_export">';
        if(function_exists('wp_nonce_field'))wp_nonce_field('apkw_c22_live_export');
        if(function_exists('submit_button'))submit_button('Aktuellen WordPress-Bestand inklusive Artikelzuordnungen prüfen','secondary');
        echo '<p>Einmaliger Nur-Lese-Export des aktiven Stands: geschützte IDs, Slugs, Links und vorhandene Artikel-/Kategoriezuordnungen. Keine Datenbankänderung, keine kostenpflichtige SEO-Abfrage.</p></form>';
        if (class_exists('APKW_C22_AddOnly')) APKW_C22_AddOnly::render_controls();
        if (class_exists('APKW_C22_472_AddOnly')) APKW_C22_472_AddOnly::render_controls();
        if (class_exists('APKW_C23_471_AddOnly')) APKW_C23_471_AddOnly::render_controls();
        echo '</div>';
    }
}
