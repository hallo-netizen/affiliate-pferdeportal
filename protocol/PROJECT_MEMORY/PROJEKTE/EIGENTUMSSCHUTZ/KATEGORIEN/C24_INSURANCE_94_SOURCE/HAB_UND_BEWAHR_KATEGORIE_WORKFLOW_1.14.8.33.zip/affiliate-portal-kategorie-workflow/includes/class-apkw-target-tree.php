<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Generic project-profile driven three-pillar target tree.
 *
 * The target profile is the information-architecture authority. SEO providers
 * may enrich already defined nodes, but must never create, move or remove them.
 */
final class APKW_TargetTree {
    public const CONTRACT='APKW_TARGET_TREE_V1';
    public const FORMAT='apkw-target-tree-profile';
    public const SCHEMA_VERSION='1.0';
    private static ?array $profile_cache=null;

    public static function profile():?array{
        if(self::$profile_cache!==null)return self::$profile_cache;
        // Virgin installation: NO bundled or site-name-dependent profile is selected.
        $p=function_exists('get_option')?get_option('apkw_target_tree_profile_v1',null):null;
        if(!is_array($p)&&function_exists('apply_filters')){
            $path=trim((string)apply_filters('apkw_target_tree_profile_path',''));
            if($path!==''&&is_readable($path))$p=json_decode((string)file_get_contents($path),true);
        }
        if(!is_array($p))return null;
        if(empty(self::validate($p)['valid']))return null;
        self::$profile_cache=$p;return $p;
    }

    public static function reset_cache():void{self::$profile_cache=null;}
    public static function owns_runtime():bool{return self::profile()!==null;}
    public static function revision(?array $profile=null):string{$p=$profile??self::profile();return is_array($p)?(string)($p['project']['revision']??''):'';}

    public static function validate(array $p):array{
        $errors=[];$warnings=[];
        if((string)($p['format']??'')!==self::FORMAT)$errors[]='FORMAT_INVALID';
        if((string)($p['schema_version']??'')!==self::SCHEMA_VERSION)$errors[]='SCHEMA_VERSION_INVALID';
        $project=is_array($p['project']??null)?$p['project']:[];
        foreach(['project_id','name','revision'] as $f)if(trim((string)($project[$f]??''))==='')$errors[]='PROJECT_'.strtoupper($f).'_MISSING';
        $settings=is_array($p['settings']??null)?$p['settings']:[];
        $maxName=max(8,(int)($settings['max_display_name_chars']??36));$maxDepth=max(1,(int)($settings['max_depth']??4));
        $pillars=is_array($p['pillars']??null)?$p['pillars']:[];
        foreach(['core','editorial','directory'] as $k)if(!is_array($pillars[$k]??null))$errors[]='PILLAR_'.strtoupper($k).'_MISSING';

        $nodes=is_array($p['nodes']??null)?array_values($p['nodes']):[];$idx=[];$slugScope=[];
        foreach($nodes as $i=>$n){
            if(!is_array($n)){$errors[]='NODE_INVALID:'.$i;continue;}
            $id=trim((string)($n['node_id']??''));$pillar=(string)($n['pillar']??'');$name=trim((string)($n['display_name']??''));$slug=trim((string)($n['slug']??''));$obj=(string)($n['object_type']??'');
            if($id==='')$errors[]='NODE_ID_MISSING:'.$i;elseif(isset($idx[$id]))$errors[]='NODE_ID_DUPLICATE:'.$id;else $idx[$id]=$n;
            if(!isset($pillars[$pillar]))$errors[]='NODE_PILLAR_INVALID:'.$id;
            if($name==='')$errors[]='NODE_NAME_MISSING:'.$id;elseif(self::strlen($name)>$maxName)$errors[]='NODE_NAME_TOO_LONG:'.$id.':'.$name;
            if($slug==='')$errors[]='NODE_SLUG_MISSING:'.$id;
            // WordPress canonicalizes every page and taxonomy slug on write.
            // A noncanonical target would make readback fail after all writes,
            // triggering a costly full rollback. BLOCK it before any write.
            if($obj!=='relation' && $slug!=='' &&
               (!preg_match('/^[a-z0-9_]+(?:-[a-z0-9_]+)*$/D', $slug) ||
                (function_exists('sanitize_title') && (string)sanitize_title($slug)!==$slug)))
                $errors[]='NODE_SLUG_NONCANONICAL:'.$id;
            if(!in_array($obj,['page','category','journal_cat','hp_listing_category','relation'],true))$errors[]='NODE_OBJECT_TYPE_INVALID:'.$id;
            if($obj==='relation'&&trim((string)($n['target_node_id']??''))==='')$errors[]='NODE_RELATION_TARGET_MISSING:'.$id;
            $status=(string)($n['status']??'active');if(!in_array($status,['active','archived'],true))$errors[]='NODE_STATUS_INVALID:'.$id;
            if($obj!=='relation'&&$slug!==''){$scope=$obj.'|'.$slug;if(isset($slugScope[$scope]))$errors[]='NODE_SLUG_DUPLICATE:'.$id.':'.$slug;else $slugScope[$scope]=$id;}
        }
        foreach($idx as $id=>$n){
            $parent=(string)($n['parent_id']??'');if($parent!==''){
                if(!isset($idx[$parent]))$errors[]='NODE_PARENT_MISSING:'.$id.':'.$parent;
                else{
                    if((string)($idx[$parent]['pillar']??'')!==(string)($n['pillar']??''))$errors[]='NODE_CROSS_PILLAR_PARENT:'.$id;
                    // CORE article categories are terminal. Editorial tiles remain flat;
                    // HivePress's REAL provider taxonomy may have subcategories.
                    $childType=(string)($n['object_type']??'');
                    $parentType=(string)($idx[$parent]['object_type']??'');
                    if(($childType==='category'&&$parentType==='category')||($childType==='journal_cat'&&$parentType==='journal_cat'))$errors[]='NODE_CATEGORY_UNDER_CATEGORY:'.$id;
                    if($childType==='hp_listing_category'&&$parentType!=='hp_listing_category'&&$parentType!=='page')$errors[]='DIRECTORY_PARENT_TYPE_INVALID:'.$id;
                }
            }
            if((string)($n['object_type']??'')==='relation'){$target=(string)($n['target_node_id']??'');if($target!==''&&!isset($idx[$target]))$errors[]='NODE_RELATION_TARGET_UNKNOWN:'.$id.':'.$target;}
            $seen=[];$cur=$id;$depth=0;while($cur!==''&&isset($idx[$cur])){if(isset($seen[$cur])){$errors[]='NODE_PARENT_CYCLE:'.$id;break;}$seen[$cur]=1;$depth++;$cur=(string)($idx[$cur]['parent_id']??'');if($depth>$maxDepth+1){$errors[]='NODE_DEPTH_EXCEEDED:'.$id;break;}}
        }

        $entities=is_array($p['entities']??null)?array_values($p['entities']):[];$eidx=[];$aliasOwner=[];
        foreach($entities as $i=>$e){
            if(!is_array($e)){$errors[]='ENTITY_INVALID:'.$i;continue;}
            $id=trim((string)($e['entity_id']??''));$label=trim((string)($e['label']??''));$fit=strtoupper((string)($e['monetization_fit']??'UNKNOWN'));$pls=is_array($e['placements']??null)?$e['placements']:[];
            if($id==='')$errors[]='ENTITY_ID_MISSING:'.$i;elseif(isset($eidx[$id]))$errors[]='ENTITY_ID_DUPLICATE:'.$id;else $eidx[$id]=$e;
            if($label==='')$errors[]='ENTITY_LABEL_MISSING:'.$id;
            if(!in_array($fit,['DIRECT','ASSISTED','NONE','UNKNOWN'],true))$errors[]='ENTITY_MONETIZATION_INVALID:'.$id;
            foreach(array_merge([$label],(array)($e['aliases']??[])) as $alias){$k=self::key((string)$alias);if($k==='')continue;if(isset($aliasOwner[$k])&&$aliasOwner[$k]!==$id)$errors[]='ENTITY_ALIAS_DUPLICATE:'.$id.':'.$alias;else $aliasOwner[$k]=$id;}
            $hasCore=false;$hasEditorial=false;
            foreach($pls as $pl){if(!is_array($pl))continue;$pillar=(string)($pl['pillar']??'');$node=(string)($pl['node_id']??'');if(!isset($pillars[$pillar]))$errors[]='ENTITY_PLACEMENT_PILLAR_INVALID:'.$id;if($node!==''&&!isset($idx[$node]))$errors[]='ENTITY_PLACEMENT_NODE_UNKNOWN:'.$id.':'.$node;if($pillar==='core')$hasCore=true;if($pillar==='editorial')$hasEditorial=true;}
            if($hasCore&&in_array($fit,['DIRECT','ASSISTED'],true)&&empty($e['monetization_paths']))$errors[]='ENTITY_CLAIMED_MONETIZATION_WITHOUT_PATH:'.$id;
            if(in_array($fit,['NONE','UNKNOWN'],true)&&!$hasEditorial)$errors[]='ENTITY_NONMONETIZABLE_NOT_RETAINED_EDITORIAL:'.$id;
        }

        // Global keyword + intent ownership across all pillars. Empty primary keyword falls back to seo_seed.
        $owners=[];$intentOwners=[];
        $claim=function(string $owner,string $pillar,string $kw,string $intent)use(&$owners,&$intentOwners,&$errors){
            $kw=self::key($kw);$intent=self::key($intent);if($kw!==''){if(isset($owners[$kw])&&$owners[$kw]['owner']!==$owner)$errors[]='PRIMARY_KEYWORD_CANNIBALIZATION:'.$kw.':'.$owners[$kw]['owner'].':'.$owner;else $owners[$kw]=['owner'=>$owner,'pillar'=>$pillar];}
            if($intent!==''){if(isset($intentOwners[$intent])&&$intentOwners[$intent]['owner']!==$owner)$errors[]='INTENT_CANNIBALIZATION:'.$intent.':'.$intentOwners[$intent]['owner'].':'.$owner;else $intentOwners[$intent]=['owner'=>$owner,'pillar'=>$pillar];}
        };
        foreach($idx as $id=>$n)if((string)($n['status']??'active')==='active'&&!empty($n['seo_owner']))$claim('node:'.$id,(string)$n['pillar'],(string)($n['primary_keyword']??$n['seo_seed']??''),(string)($n['intent_key']??''));
        foreach($eidx as $id=>$e)foreach((array)($e['placements']??[]) as $pl)if(is_array($pl)&&!empty($pl['seo_owner']))$claim('entity:'.$id.':'.(string)($pl['pillar']??''),(string)($pl['pillar']??''),(string)($pl['primary_keyword']??''),(string)($pl['intent_key']??''));

        // Every active CORE WordPress article category must be editorially viable.
        // Merely setting intent_count=5 must never pass with blank, repeated or
        // inherited/generic placeholder article topics. No provider lookups here.
        if (!empty($settings['require_three_page_levels'])) {
            $minArticleIntents=max(3,(int)($settings['min_article_intents']??3));
            $globalArticleTitles=[];
            foreach ($idx as $id=>$n) {
                if ((string)($n['status']??'active')!=='active' ||
                    (string)($n['pillar']??'')!=='core' ||
                    (string)($n['object_type']??'')!=='category') continue;
                $ideas=(array)($n['supporting_intents']??[]);
                $distinct=[];
                foreach ($ideas as $idea) {
                    if (!is_string($idea) || trim($idea)==='') {
                        $errors[]='CORE_LEAF_EMPTY_ARTICLE_INTENT:'.$id;
                        continue;
                    }
                    $normalized=self::key($idea);
                    if ($normalized==='') {
                        $errors[]='CORE_LEAF_EMPTY_ARTICLE_INTENT:'.$id;
                        continue;
                    }
                    if (isset($distinct[$normalized])) $errors[]='CORE_LEAF_DUPLICATE_ARTICLE_INTENT:'.$id;
                    if (isset($globalArticleTitles[$normalized]) && $globalArticleTitles[$normalized]!==$id)
                        $errors[]='CORE_LEAF_ARTICLE_INTENT_OWNED_TWICE:'.$globalArticleTitles[$normalized].':'.$id;
                    $globalArticleTitles[$normalized]=$id;
                    $distinct[$normalized]=1;
                }
                if (count($distinct)<$minArticleIntents) $errors[]='CORE_LEAF_ARTICLE_CAPACITY:'.$id;
                if ((int)($n['intent_count']??-1)!==count($ideas)) $errors[]='CORE_LEAF_INTENT_COUNT_MISMATCH:'.$id;
            }
        }

        // Optional portal-specific hard gate: a CORE content category must sit
        // below EXACTLY three page levels (World > Area > Subarea). This prevents
        // a technically passing Dry-Run for a fachlich flattened target profile.
        if (!empty($settings['require_three_page_levels'])) {
            $thirdPages=[];$thirdLeafCounts=[];
            foreach ($idx as $id=>$n) {
                if ((string)($n['status']??'active')!=='active' || (string)($n['pillar']??'')!=='core') continue;
                $type=(string)($n['object_type']??'');$par=(string)($n['parent_id']??'');
                if ($type==='page' && $id!=='core:hub' && !str_starts_with($id,'core:world:')) {
                    $parent=$idx[$par]??[];$parentId=(string)($parent['parent_id']??'');
                    $grandparent=$idx[$parentId]??[];
                    $isSecondLevel=str_starts_with($par,'core:world:') && (string)($parent['object_type']??'')==='page';
                    $isThirdLevel=str_starts_with($parentId,'core:world:') &&
                        (string)($parent['object_type']??'')==='page' &&
                        (string)($grandparent['object_type']??'')==='page' &&
                        (string)($grandparent['parent_id']??'')==='';
                    if (!$isSecondLevel && !$isThirdLevel) $errors[]='CORE_PAGE_LEVEL_INVALID:'.$id;
                    if ($isThirdLevel) $thirdPages[$id]=true;
                }
                if ($type==='category') {
                    $p3=$idx[$par]??[];$p2id=(string)($p3['parent_id']??'');
                    $p2=$idx[$p2id]??[];$p1id=(string)($p2['parent_id']??'');
                    $p1=$idx[$p1id]??[];
                    $validDepth=(string)($p3['object_type']??'')==='page' &&
                        (string)($p2['object_type']??'')==='page' &&
                        str_starts_with($p1id,'core:world:') &&
                        (string)($p1['object_type']??'')==='page' &&
                        (string)($p1['parent_id']??'')==='';
                    if (!$validDepth) $errors[]='CORE_LEAF_REQUIRES_THREE_PAGE_LEVELS:'.$id;
                    else $thirdLeafCounts[$par]=($thirdLeafCounts[$par]??0)+1;
                }
            }
            if (!$thirdPages) $errors[]='CORE_LEVEL_THREE_MISSING';
            $minCats=max(1,(int)($settings['min_categories_per_third_page']??1));
            foreach ($thirdPages as $id=>$_) {
                if (($thirdLeafCounts[$id]??0)<$minCats) $errors[]='CORE_LEVEL_THREE_CATEGORY_CAPACITY:'.$id;
            }
        }
        // All NEW category proposals use only the MINIMUM of three meaningful
        // direct child categories. There is no upper bound; menu presentation
        // limits are separate and must never constrain the actual taxonomy.
        if (!empty($settings['require_min_direct_children_no_max'])) {
            $direct=[];
            foreach ($idx as $id=>$n) {
                if (($n['pillar']??'')!=='core'||($n['status']??'active')!=='active')continue;
                $parent=(string)($n['parent_id']??'');
                if($parent!=='')$direct[$parent]=($direct[$parent]??0)+1;
            }
            foreach ($idx as $id=>$n) {
                if (($n['pillar']??'')!=='core'||($n['status']??'active')!=='active')continue;
                if (str_starts_with($id,'core:world:')||str_starts_with($id,'core:area:')||str_starts_with($id,'core:subarea:')||str_starts_with($id,'core:v99:')&&($n['object_type']??'')==='page') {
                    if (($direct[$id]??0)<3)$errors[]='CORE_MINIMUM_THREE_CHILDREN:'.$id;
                }
            }
        }
        // R3/V8-only hard gate. Legacy R2 remains byte-for-byte governed by its
        // previous rules; an R3 profile can never bypass the 3–10 child limit,
        // including a later manual re-import through the existing admin UI.
        if (!empty($settings['require_direct_child_3_to_10'])) {
            $direct=[];$numbers=['world'=>0,'area'=>0,'subarea'=>0,'leaf'=>0];
            foreach ($idx as $id=>$n) {
                if (($n['pillar']??'')!=='core'||($n['status']??'active')!=='active')continue;
                $par=(string)($n['parent_id']??'');if($par!=='')$direct[$par]=($direct[$par]??0)+1;
                foreach ($numbers as $kind=>$unused)if(str_starts_with($id,'core:'.$kind.':')){$numbers[$kind]++;break;}
            }
            if ($numbers!==['world'=>6,'area'=>31,'subarea'=>93,'leaf'=>285])$errors[]='R3_V8_CORE_COUNTS_INVALID';
            foreach ($idx as $id=>$n) {
                if (($n['pillar']??'')!=='core'||($n['status']??'active')!=='active')continue;
                if (str_starts_with($id,'core:world:')||str_starts_with($id,'core:area:')||str_starts_with($id,'core:subarea:')) {
                    $count=$direct[$id]??0;
                    if($count<3||$count>10)$errors[]='R3_V8_DIRECT_CHILDREN_INVALID:'.$id.':'.$count;
                }
            }
        }
        return ['valid'=>!$errors,'errors'=>array_values(array_unique($errors)),'warnings'=>array_values(array_unique($warnings)),'node_count'=>count($idx),'entity_count'=>count($eidx),'keyword_owner_count'=>count($owners),'intent_owner_count'=>count($intentOwners)];
    }

    /** Resolve project inventory into stable entities. Structure stays profile-owned. */
    public static function resolve_for_sync(?callable $inventory_fetcher=null):array{
        $base=self::profile();if(!is_array($base))throw new RuntimeException('Kein Target-Tree-Profil gebunden.');
        $inventory=is_array($base['inventory']??null)?$base['inventory']:[];$adapter=(string)($inventory['adapter']??'');$candidates=[];$binding=[];
        if($adapter!==''){
            if(function_exists('apply_filters')){$rows=apply_filters('apkw_target_tree_inventory_rows',null,$adapter,$base);if(is_array($rows))$candidates=array_values(array_map('strval',$rows));}
            if(!$candidates)throw new RuntimeException('Kein Inventar für Adapter '.$adapter.' geliefert.');
        }
        if($adapter===''&&!empty($inventory['additional_candidates']))throw new RuntimeException('Zusätzliche Inventarkandidaten benötigen einen expliziten Adapter.');
        $additional=array_values(array_filter(array_map('strval',(array)($inventory['additional_candidates']??[])),static fn($v)=>trim($v)!==''));
        if($additional){
            $seen=[];$merged=[];
            foreach(array_merge($candidates,$additional) as $candidate){
                $candidate=trim((string)$candidate);$k=self::key($candidate);
                if($candidate===''||$k===''||isset($seen[$k]))continue;
                $seen[$k]=1;$merged[]=$candidate;
            }
            $candidates=$merged;
            $binding['additional_candidate_count']=count($additional);
            $binding['resolved_candidate_count']=count($candidates);
        }
        if(!$candidates){self::apply_resolved_revision($base);return $base;}
        $fallback=(string)($inventory['editorial_fallback_node_id']??'');if($fallback==='')throw new RuntimeException('Editorialer Fallback für Inventar fehlt.');
        $idx=self::node_index($base);if(!isset($idx[$fallback])||(string)($idx[$fallback]['pillar']??'')!=='editorial')throw new RuntimeException('Editorialer Fallback-Knoten ungültig: '.$fallback);

        $aliasToCanonical=[];$canonicalLabel=[];
        foreach((array)($base['alias_groups']??[]) as $g){if(!is_array($g))continue;$label=trim((string)($g['canonical_label']??''));if($label==='')continue;$eid='entity:'.substr(hash('sha256',self::key($label)),0,20);$canonicalLabel[$eid]=$label;foreach(array_merge([$label],(array)($g['aliases']??[])) as $a)$aliasToCanonical[self::key((string)$a)]=$eid;}
        $entities=[];
        foreach($candidates as $candidate){$candidate=trim($candidate);if($candidate==='')continue;$key=self::key($candidate);if($key==='')continue;$eid=$aliasToCanonical[$key]??('entity:'.substr(hash('sha256',$key),0,20));if(!isset($entities[$eid]))$entities[$eid]=['entity_id'=>$eid,'label'=>$canonicalLabel[$eid]??$candidate,'aliases'=>[],'monetization_fit'=>'UNKNOWN','monetization_paths'=>[],'placements'=>[['pillar'=>'editorial','node_id'=>$fallback,'seo_owner'=>true,'primary_keyword'=>'','intent_key'=>'editorial-'.substr(hash('sha256',$eid),0,16)]]];if(self::key((string)$entities[$eid]['label'])!==$key&&!in_array($candidate,$entities[$eid]['aliases'],true))$entities[$eid]['aliases'][]=$candidate;}

        foreach((array)($base['entity_overrides']??[]) as $ov){
            if(!is_array($ov))continue;$names=array_values(array_filter(array_map('strval',(array)($ov['match_names']??[])),static fn($v)=>trim($v)!==''));if(!$names)continue;$matched=[];
            foreach($entities as $eid=>$e){$keys=array_map([__CLASS__,'key'],array_merge([(string)$e['label']],(array)$e['aliases']));foreach($names as $n)if(in_array(self::key($n),$keys,true)){$matched[]=$eid;break;}}
            if(!$matched)continue;$winner=$matched[0];for($i=1;$i<count($matched);$i++){$loser=$matched[$i];foreach(array_merge([(string)$entities[$loser]['label']],(array)$entities[$loser]['aliases']) as $a)if(self::key($a)!==self::key((string)$entities[$winner]['label'])&&!in_array($a,$entities[$winner]['aliases'],true))$entities[$winner]['aliases'][]=$a;unset($entities[$loser]);}
            $e=&$entities[$winner];if(trim((string)($ov['canonical_label']??''))!=='')$e['label']=trim((string)$ov['canonical_label']);$e['monetization_fit']=strtoupper((string)($ov['monetization_fit']??$e['monetization_fit']));$e['monetization_paths']=array_values(array_unique(array_filter(array_map('strval',(array)($ov['monetization_paths']??$e['monetization_paths'])),static fn($v)=>trim($v)!=='')));if(isset($ov['placements'])&&is_array($ov['placements']))$e['placements']=$ov['placements'];unset($e);
        }
        $base['entities']=array_values($entities);$base['inventory_binding']=$binding;

        // Deterministic WordPress page nodes are created only for explicitly approved CORE placements.
        $existing=self::node_index($base);$extra=[];
        // Bind approved CORE entities to one physical SEO-owning page. Entity placements are
        // relations only; they never become a second SEO owner beside the physical target.
        foreach($base['entities'] as &$e){
            if(!isset($e['placements'])||!is_array($e['placements']))$e['placements']=[];
            foreach($e['placements'] as &$pl){
                if(!is_array($pl)||(string)($pl['pillar']??'')!=='core'||empty($pl['create_node']))continue;
                $parent=(string)($pl['node_id']??'');if(!isset($existing[$parent]))throw new RuntimeException('Core-Placement-Parent fehlt: '.$parent);
                $desiredName=(string)$e['label'];$desiredSlug=self::slug($desiredName);$nid=(string)($pl['target_node_id']??'');
                // A profile may already model the canonical entity as its placement parent.
                // Reuse the stable node instead of creating
                // a duplicate child with the same visible identity.
                if($nid===''&&isset($existing[$parent])&&self::key((string)($existing[$parent]['display_name']??''))===self::key($desiredName))$nid=$parent;
                if($nid===''){
                    foreach($existing as $existingId=>$existingNode){
                        if((string)($existingNode['pillar']??'')!=='core'||(string)($existingNode['object_type']??'')!=='page')continue;
                        if((string)($existingNode['parent_id']??'')!==$parent)continue;
                        if(self::key((string)($existingNode['display_name']??''))===self::key($desiredName)&&(string)($existingNode['slug']??'')===$desiredSlug){$nid=(string)$existingId;break;}
                    }
                }
                if($nid==='')$nid='core:entity:'.substr(hash('sha256',(string)$e['entity_id']),0,20);
                $pl['target_node_id']=$nid;
                if(!isset($existing[$nid])){$node=['node_id'=>$nid,'pillar'=>'core','object_type'=>'page','display_name'=>$desiredName,'slug'=>$desiredSlug,'parent_id'=>$parent,'status'=>'active','seo_owner'=>true,'seo_seed'=>$desiredName,'primary_keyword'=>(string)($pl['primary_keyword']??''),'intent_key'=>(string)($pl['intent_key']??('core-'.substr(hash('sha256',(string)$e['entity_id']),0,16))),'entity_id'=>(string)$e['entity_id']];$extra[]=$node;$existing[$nid]=$node;}
                elseif((string)($existing[$nid]['pillar']??'')!=='core'||(string)($existing[$nid]['object_type']??'')!=='page')throw new RuntimeException('Core-Placement-Ziel ist kein Core-Page-Knoten: '.$nid);
                // Entity is a relation to the physical page. The physical node owns SEO.
                $pl['seo_owner']=false;
            }
            unset($pl);
        }
        unset($e);
        if($extra)$base['nodes']=array_merge((array)$base['nodes'],$extra);
        self::apply_resolved_revision($base);$v=self::validate($base);if(empty($v['valid']))throw new RuntimeException('Aufgelöster Target-Tree BLOCKED: '.implode(', ',$v['errors']??[]));return $base;
    }

    private static function apply_resolved_revision(array &$p):void{
        $base=(string)($p['project']['revision']??'');if($base==='')return;$fingerprint=$p;$fingerprint['project']['revision']=$base;unset($fingerprint['project']['resolved_revision']);if(isset($fingerprint['inventory_binding'])&&is_array($fingerprint['inventory_binding']))unset($fingerprint['inventory_binding']['bound_at_utc']);$json=function_exists('wp_json_encode')?wp_json_encode($fingerprint,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):json_encode($fingerprint,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);if(!is_string($json))throw new RuntimeException('Target-Tree-Revision konnte nicht berechnet werden.');$resolved=$base.'+'.substr(hash('sha256',$json),0,16);$p['project']['base_revision']=$base;$p['project']['revision']=$resolved;$p['project']['resolved_revision']=$resolved;
    }

    public static function active_nodes(?array $profile=null):array{$p=$profile??self::profile();if(!is_array($p))return [];return array_values(array_filter((array)($p['nodes']??[]),static fn($n)=>is_array($n)&&(string)($n['status']??'active')==='active'));}
    public static function sync_nodes(?array $profile=null):array{return array_values(array_filter(self::active_nodes($profile),static fn($n)=>(string)($n['object_type']??'')!=='relation'));}
    public static function node_index(?array $profile=null):array{$o=[];foreach(self::active_nodes($profile) as $n)$o[(string)$n['node_id']]=$n;return $o;}
    public static function pillar(string $key,?array $profile=null):array{$p=$profile??self::profile();$x=is_array($p)?($p['pillars'][$key]??[]):[];return is_array($x)?$x:[];}
    public static function managed_block(string $pillar):string{return ['core'=>'content','editorial'=>'magazine','directory'=>'marketplace'][$pillar]??'';}
    public static function taxonomy_for_object(string $object_type):string{return in_array($object_type,['category','journal_cat','hp_listing_category'],true)?$object_type:'';}
    public static function hub_specs(?array $profile=null):array{$p=$profile??self::profile();if(!is_array($p))return [];$out=[];foreach(['core','editorial','directory'] as $pillar){$spec=self::pillar($pillar,$p);$hub=is_array($spec['hub']??null)?$spec['hub']:[];if($hub)$out[$pillar]=['slug'=>(string)($hub['slug']??''),'title'=>(string)($hub['title']??ucfirst($pillar))];}return $out;}
    public static function editorial_groups(?array $profile=null):array{$p=$profile??self::profile();$x=is_array($p)?($p['pillars']['editorial']['menu_groups']??[]):[];return is_array($x)?$x:[];}
    public static function footer_pillars(?array $profile=null):array{$p=$profile??self::profile();$x=is_array($p)?($p['project']['footer_pillars']??[]):[];return array_values(array_filter(array_map('strval',is_array($x)?$x:[])));}
    public static function front_pillars(?array $profile=null):array{$p=$profile??self::profile();$x=is_array($p)?($p['project']['front_pillars']??[]):[];return array_values(array_filter(array_map('strval',is_array($x)?$x:[])));}

    private static function key(string $s):string{$s=trim($s);if($s==='')return '';if(function_exists('remove_accents'))$s=remove_accents($s);$s=strtolower($s);$s=preg_replace('/[^a-z0-9]+/u',' ',$s);return trim((string)$s);}
    private static function slug(string $s):string{if(function_exists('sanitize_title'))return (string)sanitize_title($s);return str_replace(' ','-',self::key($s));}
    private static function strlen(string $s):int{return function_exists('mb_strlen')?mb_strlen($s,'UTF-8'):(function_exists('iconv_strlen')?iconv_strlen($s,'UTF-8'):strlen($s));}
}
