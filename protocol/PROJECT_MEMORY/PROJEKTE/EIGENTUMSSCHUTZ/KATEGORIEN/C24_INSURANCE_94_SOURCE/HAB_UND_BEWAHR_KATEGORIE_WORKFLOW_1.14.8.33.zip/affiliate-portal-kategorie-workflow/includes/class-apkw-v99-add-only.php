<?php
if (!defined('ABSPATH')) { exit; }
/** One admin-only, fail-closed ADD delta for Hab & Bewahr. No frontend HTTP or sync. */
final class APKW_V99_AddOnly {
    private const PAGE='apkw-v99-add-only';
    private const ORIGINAL='HB-R3-V8-20261013-039c80c8c16d9b4f';
    private const SOURCE='https://raw.githubusercontent.com/hallo-netizen/affiliate-pferdeportal/7795fb379c6fb1463ede620965f93bac272f9c6c/protocol/PROJECT_MEMORY/PROJEKTE/EIGENTUMSSCHUTZ/KATEGORIEN/V9_9_ZENTRALES_ADD_DELTA_107_KNOTEN_81_KATEGORIEN_364_IDEEN_NICHT_IMPORTIEREN_20261015.json';
    private const SOURCE_GIT_SHA='99161d82c2acbfe679e754951755f0a8f003fad0';
    private const OPT='apkw_target_tree_profile_v1';
    private const BACKUP='apkw_v99_original_profile_backup';
    public static function init():void{
        add_action('admin_menu',[__CLASS__,'menu'],44);
        add_action('admin_post_apkw_v99_preview',[__CLASS__,'preview']);
        add_action('admin_post_apkw_v99_stage',[__CLASS__,'stage']);
        add_action('admin_post_apkw_v99_unstage',[__CLASS__,'unstage']);
    }
    public static function menu():void{ add_submenu_page(APKW_FinalTargetAdmin::PAGE_SLUG,'V9.9 Ergänzungen','V9.9 Ergänzungen','manage_options',self::PAGE,[__CLASS__,'render']); }
    private static function admin():void{if(!current_user_can('manage_options'))throw new RuntimeException('Administrator erforderlich.');}
    private static function data():array{
        $r=wp_remote_get(self::SOURCE,['timeout'=>25,'redirection'=>0,'limit_response_size'=>180000,'headers'=>['Accept'=>'application/json']]);
        if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)throw new RuntimeException('Festgeschriebene Konzeptquelle derzeit nicht erreichbar. Keine Änderung.');
        $s=(string)wp_remote_retrieve_body($r);
        if(!hash_equals(self::SOURCE_GIT_SHA,sha1('blob '.strlen($s)."\0".$s)))throw new RuntimeException('Konzeptquelle weicht vom freigegebenen Git-Blob ab. Keine Änderung.');
        $data=json_decode($s,true);
        if(!is_array($data)||($data['schema']??'')!=='HB-CENTRAL-81-364-ADD-ONLY-STAGED-DELTAS-V1'||($data['status']??'')!=='NOT_IMPORTABLE_NO_PLUGIN_RELEASE')throw new RuntimeException('Konzeptquelle unerwartet.');
        if(count((array)($data['new_areas']??[]))!==4||count((array)($data['new_subareas']??[]))!==22||count((array)($data['new_leaf_categories']??[]))!==81)throw new RuntimeException('107er-Zielstruktur fehlt.');
        return $data;
    }
    private static function baseline():array{
        self::admin();$active=(string)APKW_TargetTreeSync::active_revision();$state=APKW_TargetTreeSync::state();
        if(!str_starts_with($active,self::ORIGINAL.'+')||!is_array($state)||($state['status']??'')!=='COMPLETE')throw new RuntimeException('WordPress R3/V8 ist nicht der bestätigte 1.14.8.19-Stand. Keine Änderung.');
        $p=get_option(self::OPT,null);
        if(!is_array($p)||($p['project']['project_id']??'')!=='hab-und-bewahr'||!isset($p['r3_v8_source']))throw new RuntimeException('Aktives Original-R3/V8-Profil fehlt. Keine Annahmen aus älteren Profilen.');
        if(!str_starts_with((string)($p['project']['revision']??''),self::ORIGINAL))throw new RuntimeException('Originalprofil weicht von R3/V8 ab.');
        APKW_R3_V8_Finalizer::guard_final_target($p);
        $core=array_filter((array)$p['nodes'],static fn($x)=>is_array($x)&&($x['pillar']??'')==='core'&&($x['object_type']??'')==='category');
        if(count($core)!==285||count($p['nodes'])!==552)throw new RuntimeException('Originalumfang weicht von 552 logischen Knoten / 285 Blattkategorien ab.');
        return $p;
    }
    private static function title(string $s):string{
        $s=trim($s);if($s===''||(function_exists('mb_strlen')?mb_strlen($s,'UTF-8'):strlen($s))>85)throw new RuntimeException('Ungültiger neuer Name.');return $s;
    }
    private static function slug(string $s):string{
        $s=remove_accents($s);$v=sanitize_title($s);return 'hab-v99-'.substr($v,0,55);
    }
    private static function compose(array $base,array $d):array{
        $raw=array_merge((array)$d['new_areas'],(array)$d['new_subareas'],(array)$d['new_leaf_categories']);
        $refs=[];$oldId=[];$oldSlug=[];$oldNames=[];$oldTitles=[];
        foreach($base['nodes'] as $n){$oldId[(string)$n['node_id']]=true;$oldSlug[($n['object_type']??'').'|'.($n['slug']??'')]=true;$oldNames[(function_exists('mb_strtolower')?mb_strtolower((string)($n['display_name']??''),'UTF-8'):strtolower((string)($n['display_name']??'')))]=true;foreach((array)($n['supporting_intents']??[]) as $i)$oldTitles[mb_strtolower(trim((string)$i),'UTF-8')]=true;}
        $new=[];$newSlug=[];$newTitles=[];
        foreach($raw as $x){
            if(!is_array($x)||($x['action']??'')!=='ADD')throw new RuntimeException('Nicht-ADD-Operation blockiert.');
            $ref=(string)($x['proposal_ref']??'');$parent=(string)($x['parent_ref']??'');$name=self::title((string)($x['name']??''));
            if(!str_starts_with($ref,'proposal:')||isset($refs[$ref]))throw new RuntimeException('Doppelte/neue ID ungültig.');
            if(isset($oldNames[(function_exists('mb_strtolower')?mb_strtolower($name,'UTF-8'):strtolower($name))]))throw new RuntimeException('Bestehende Kategorie kollidiert: '.$name);
            $refs[$ref]='core:v99:'.substr(hash('sha256',$ref),0,24);
            $obj=(string)($x['object_type']??'');if(!in_array($obj,['page','category'],true))throw new RuntimeException('Objekttyp ungültig.');
            $slug=self::slug($name);$key=$obj.'|'.$slug;
            if(isset($oldSlug[$key])||isset($newSlug[$key]))throw new RuntimeException('Slug doppelt: '.$slug);
            $newSlug[$key]=true;
            $ideas=(array)($x['article_ideas']??[]);
            if($obj==='category'&&count($ideas)<3)throw new RuntimeException('Unter drei Artikeln: '.$name);
            foreach($ideas as $idea){if(!is_string($idea)||trim($idea)==='')throw new RuntimeException('Leerer Artikel.');$t=(function_exists('mb_strtolower')?mb_strtolower(trim($idea),'UTF-8'):strtolower(trim($idea)));if(isset($oldTitles[$t])||isset($newTitles[$t]))throw new RuntimeException('Artikeltitel doppelt: '.$idea);$newTitles[$t]=true;}
            $new[]=[$x,$ref,$parent,$name,$slug,$obj,$ideas];
        }
        $idx=[];foreach($new as $row){[$x,$ref,$parent,$name,$slug,$obj,$ideas]=$row;if(!isset($refs[$parent])&&!isset($oldId[$parent]))throw new RuntimeException('Elternknoten fehlt: '.$parent);
            $node=['node_id'=>$refs[$ref],'pillar'=>'core','object_type'=>$obj,'display_name'=>$name,'slug'=>$slug,'parent_id'=>$refs[$parent]??$parent,'status'=>'active','seo_owner'=>false,'seo_seed'=>$name,'primary_keyword'=>'','intent_key'=>'v99-'.substr(hash('sha256',$ref),0,20)];
            if($obj==='category'){$node['supporting_intents']=array_values($ideas);$node['intent_count']=count($ideas);}
            $idx[]=$node;
        }
        $out=$base;
        $out['project']['revision']='HB-V99-ADD-20261015-81-364';
        $out['project']['profile_type']='V99_ADD_ONLY_MANUAL_SYNC';
        $out['settings']['max_display_name_chars']=85;
        $out['settings']['require_direct_child_3_to_10']=false; // Historical max=10 is not a future category limit.
        $out['settings']['require_min_direct_children_no_max']=true;
        $out['nodes']=array_merge($base['nodes'],$idx);
        $out['v9_9_add_only']=['base_revision'=>(string)$base['project']['revision'],'base_count'=>count($base['nodes']),'baseline_nodes_sha256'=>hash('sha256',json_encode($base['nodes'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),'source_git_sha'=>self::SOURCE_GIT_SHA,'new_nodes'=>107,'new_categories'=>81,'new_ideas'=>364];
        $test=APKW_TargetTree::validate($out);
        if(empty($test['valid']))throw new RuntimeException('V9.9 Zielbaum BLOCKED: '.implode(', ',array_slice((array)$test['errors'],0,8)));
        return $out;
    }
    public static function guarded_r3(array $profile):bool{
        $m=$profile['v9_9_add_only']??null;if(!is_array($m))return false;
        if(($m['source_git_sha']??'')!==self::SOURCE_GIT_SHA||($m['new_nodes']??0)!==107||($m['new_categories']??0)!==81||($m['new_ideas']??0)!==364)throw new RuntimeException('V9.9 Signatur unvollständig.');
        $n=(int)($m['base_count']??0);$all=(array)($profile['nodes']??[]);if($n!==552||count($all)!==659)throw new RuntimeException('V9.9 Knotenzahl falsch.');
        $old=array_slice($all,0,$n);$encoded=json_encode($old,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if(!hash_equals((string)$m['baseline_nodes_sha256'],hash('sha256',$encoded)))throw new RuntimeException('V9.9 Bestand wurde verändert.');
        $base=$profile;$base['nodes']=$old;unset($base['v9_9_add_only']);$base['project']['revision']=$m['base_revision'];$base['project']['base_revision']=$m['base_revision'];unset($base['project']['resolved_revision']);$base['settings']['require_direct_child_3_to_10']=true;$base['settings']['max_display_name_chars']=36;
        APKW_R3_V8_Finalizer::guard_final_target($base);
        $older=array_column($old,'node_id');$known=array_fill_keys($older,true);$extra=array_slice($all,$n);$cats=0;$total=0;
        foreach($extra as $x){$id=(string)($x['node_id']??'');if(!str_starts_with($id,'core:v99:')||isset($known[$id]))throw new RuntimeException('Ungültiger V9.9 ADD-Knoten.');$known[$id]=true;if(($x['object_type']??'')==='category'){$cats++;$total+=count((array)($x['supporting_intents']??[]));}}
        if($cats!==81||$total!==364)throw new RuntimeException('81/364 V9.9 Zusatzumfang falsch.');
        return true;
    }
    public static function preview():void{
        try{self::admin();check_admin_referer('apkw_v99_preview');$p=self::compose(self::baseline(),self::data());self::guarded_r3($p);set_transient('apkw_v99_pass_'.get_current_user_id(),hash('sha256',json_encode($p,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),900);self::redirect('pass');}
        catch(Throwable $e){self::fail($e);}
    }
    public static function stage():void{
        try{self::admin();check_admin_referer('apkw_v99_stage');$p=self::compose(self::baseline(),self::data());self::guarded_r3($p);
            $fp=hash('sha256',json_encode($p,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));$pass=get_transient('apkw_v99_pass_'.get_current_user_id());if(!is_string($pass)||!hash_equals($pass,$fp))throw new RuntimeException('Prüfung abgelaufen oder Bestand verändert. Erneut prüfen.');
            if((string)($_POST['confirm']??'')!=='1')throw new RuntimeException('Ausdrückliche Bestätigung fehlt.');
            if(get_option(self::BACKUP,false)!==false)throw new RuntimeException('Eine V9.9-Backupvorlage existiert bereits. Kein zweiter Import.');
            $base=self::baseline();if(!add_option(self::BACKUP,$base,'',false))throw new RuntimeException('Originalbackup konnte nicht gesichert werden.');
            if(!update_option(self::OPT,$p,false)){delete_option(self::BACKUP);throw new RuntimeException('Zielprofil konnte nicht abgelegt werden.');}
            APKW_TargetTree::reset_cache();delete_option('apkw_final_target_plan_v1');delete_transient('apkw_v99_pass_'.get_current_user_id());self::redirect('staged');
        }catch(Throwable $e){self::fail($e);}
    }
    public static function unstage():void{
        try{self::admin();check_admin_referer('apkw_v99_unstage');$state=APKW_TargetTreeSync::state();
            if(!is_array($state)||($state['status']??'')!=='COMPLETE'||!str_starts_with((string)APKW_TargetTreeSync::active_revision(),self::ORIGINAL.'+'))throw new RuntimeException('Sync oder Revision verändert: kein automatischer Profilrückbau.');
            $backup=get_option(self::BACKUP,false);$now=get_option(self::OPT,false);
            if(!is_array($backup)||!is_array($now)||!isset($now['v9_9_add_only']))throw new RuntimeException('Kein gültiges ungenutztes Profilbackup.');
            update_option(self::OPT,$backup,false);delete_option(self::BACKUP);delete_option('apkw_final_target_plan_v1');APKW_TargetTree::reset_cache();self::redirect('restored');
        }catch(Throwable $e){self::fail($e);}
    }
    private static function fail(Throwable $e):void{wp_die(esc_html($e->getMessage()),'V9.9 sicher blockiert',['response'=>400]);}
    private static function redirect(string $flag):void{wp_safe_redirect(admin_url('admin.php?page='.self::PAGE.'&v99='.$flag));exit;}
    public static function render():void{
        self::admin();echo '<div class="wrap"><h1>Hab &amp; Bewahr – V9.9 neue Kategorien</h1><p>107 reine Ergänzungen: 4 Bereiche, 22 Unterbereiche, 81 Endkategorien, 364 Beitragsideen. Vorhandene Kategorien bleiben namentlich und strukturell unverändert. Nur manuelle Freigabe.</p>';
        $state=(string)($_GET['v99']??'');if($state==='pass')echo '<div class="notice notice-success"><p>Vorprüfung PASS – unveränderte 552 Altknoten überprüft.</p></div>';
        if($state==='staged')echo '<div class="notice notice-success"><p>Nur das erweiterte Zielprofil vorbereitet. <strong>Noch keine Kategorien übertragen.</strong> Jetzt unter „Finaler Zielbaum“ den vorhandenen Dry-Run und danach den ausdrücklich freigegebenen Sync durchführen.</p></div>';
        if($state==='restored')echo '<div class="notice notice-success"><p>Nur das ungenutzte Originalprofil wiederhergestellt.</p></div>';
        $backup=get_option(self::BACKUP,false);
        if(is_array($backup)){
            echo '<p><strong>V9.9 vorbereitet.</strong> Synchronisierung ausschließlich im vorhandenen Zielbaum-Büro durchführen.</p>';
            echo '<p><a class="button button-primary" href="'.esc_url(admin_url('admin.php?page='.APKW_FinalTargetAdmin::PAGE_SLUG)).'">Zum finalen Dry-Run</a></p>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_v99_unstage">';wp_nonce_field('apkw_v99_unstage');submit_button('Nur ungenutztes Zielprofil zurücknehmen','secondary');echo '</form>';
        } else {
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_v99_preview">';wp_nonce_field('apkw_v99_preview');submit_button('107 Ergänzungen risikofrei prüfen','secondary');echo '</form>';
            if(get_transient('apkw_v99_pass_'.get_current_user_id())){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_v99_stage">';wp_nonce_field('apkw_v99_stage');echo '<p><label><input type="checkbox" name="confirm" value="1" required> Ich möchte das geprüfte ADD-only-Profil vorbereiten (ohne WordPress-Sync).</label></p>';submit_button('Geprüftes Zielprofil vorbereiten','primary');echo '</form>';}
        }
        echo '<p>Das Programm prüft eine unveränderliche GitHub-Quelle ausschließlich nach Klick im WordPress-Backend. Keine zusätzlichen Frontend-Abfragen und keine automatische Übernahme.</p></div>';
    }
}
