<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Read-only, profile-driven final target-tree delta planner.
 * No provider calls and no WordPress writes happen in this class.
 */
final class APKW_TargetTreeDryRun {
    public const CONTRACT='APKW_FINAL_TARGET_DRY_RUN_V1';
    private const META_NODE='_apkw_target_node_id';
    private const META_REV='_apkw_target_revision';
    private const META_PILLAR='_apkw_target_pillar';
    private const META_ACTIVE='_apkw_target_active';

    public static function resolved_profile():array{
        APKW_TargetTree::reset_cache();
        // Preserve precise fail-closed diagnostics for malformed uploaded profiles.
        $candidate=function_exists('get_option')?get_option('apkw_target_tree_profile_v1',null):null;
        if(is_array($candidate)){
            $check=APKW_TargetTree::validate($candidate);
            if(empty($check['valid']))throw new RuntimeException('Target-Profil BLOCKED: '.implode(', ',$check['errors']??[]));
        }
        $profile=APKW_TargetTree::resolve_for_sync();
        $v=APKW_TargetTree::validate($profile);
        if(empty($v['valid']))throw new RuntimeException('Target-Profil BLOCKED: '.implode(', ',(array)($v['errors']??[])));
        return $profile;
    }

    public static function build():array{
        $profile=self::resolved_profile();
        if(class_exists('APKW_R3_V8_Finalizer'))APKW_R3_V8_Finalizer::guard_final_target($profile);
        $errors=[];
        foreach(['category','journal_cat','hp_listing_category'] as $tax){if(function_exists('taxonomy_exists')&&!taxonomy_exists($tax))$errors[]='TARGET_TAXONOMY_MISSING:'.$tax;}
        $nodes=APKW_TargetTree::sync_nodes($profile);
        usort($nodes,static fn($a,$b)=>self::depth($a,$profile)<=>self::depth($b,$profile)?:strcmp((string)($a['node_id']??''),(string)($b['node_id']??'')));
        $live=self::load_live_candidates($nodes);
        $mapping=[];$actions=[];$desiredIds=[];$claimedObjects=[];
        foreach($nodes as $n){
            $id=(string)($n['node_id']??'');$desiredIds[$id]=true;
            try{$match=self::find_existing($n,$live);}catch(Throwable $e){$errors[]='LIVE_COLLISION:'.$id.':'.$e->getMessage();continue;}
            if(!$match){$actions[]=['action'=>'CREATE','node_id'=>$id,'object_type'=>(string)$n['object_type'],'name'=>(string)$n['display_name'],'slug'=>(string)$n['slug'],'parent_id'=>(string)($n['parent_id']??''),'object_id'=>0,'mismatches'=>['missing']];continue;}
            $type=(string)$n['object_type'];$oid=self::object_id($match,$type);$mapping[$id]=$oid;$claimedObjects[$type.'|'.$oid]=true;$ref=self::object_ref($match,$type);
            $mismatches=[];
            if(self::object_name($match,$type)!==(string)$n['display_name'])$mismatches[]='name';
            if(self::object_slug($match,$type)!==(string)$n['slug'])$mismatches[]='slug';
            if($type==='page'&&self::object_status($match)!=='publish')$mismatches[]='status';
            $desiredParent=(string)($n['parent_id']??'');$parentMeta=self::meta_for($ref,$type,'_apkw_parent_concept_id');
            if($parentMeta!==''){
                if($parentMeta!==$desiredParent)$mismatches[]='parent';
            }else{
                $expected=self::expected_native_parent($desiredParent,$type,$profile,$mapping,$live);
                if($expected!==null&&self::object_parent($match,$type)!==$expected)$mismatches[]='parent';
                elseif($expected===null&&$desiredParent!=='')$mismatches[]='parent';
            }
            if(self::meta_for($ref,$type,self::META_NODE)!==$id)$mismatches[]='binding';
            if(self::meta_for($ref,$type,self::META_REV)!==APKW_TargetTree::revision($profile))$mismatches[]='revision';
            if(self::meta_for($ref,$type,self::META_PILLAR)!==(string)$n['pillar'])$mismatches[]='pillar';
            if(self::meta_for($ref,$type,self::META_ACTIVE)!=='1')$mismatches[]='active';
            if(self::meta_for($ref,$type,'_apkw_primary_keyword')!==(string)($n['primary_keyword']??''))$mismatches[]='primary_keyword';
            if(self::meta_for($ref,$type,'_apkw_intent_key')!==(string)($n['intent_key']??''))$mismatches[]='intent_key';
            $mismatches=array_values(array_unique($mismatches));
            $bound=self::meta_for($ref,$type,self::META_NODE);
            $action=$mismatches?($bound===''?'ADOPT':'UPDATE'):'UNCHANGED';
            $actions[]=['action'=>$action,'node_id'=>$id,'object_type'=>$type,'name'=>(string)$n['display_name'],'slug'=>(string)$n['slug'],'parent_id'=>$desiredParent,'object_id'=>$oid,'mismatches'=>$mismatches];
        }
        // Retirement is deliberately scoped ONLY to objects already bound by the target-tree engine.
        // This neutral profile may retire only objects explicitly bound to its own active target.
        foreach($live['target_bound'] as $row){$nid=(string)($row['node_id']??'');if($nid===''||isset($desiredIds[$nid]))continue;$type=(string)($row['object_type']??'');$oid=(int)($row['object_id']??0);if(isset($claimedObjects[$type.'|'.$oid]))continue;$alreadyRetired=(string)($row['active']??'')==='0'&&($type!=='page'||(string)($row['status']??'')==='draft');if($alreadyRetired)continue;$actions[]=['action'=>'ARCHIVE','node_id'=>$nid,'object_type'=>$type,'name'=>(string)$row['name'],'slug'=>(string)$row['slug'],'parent_id'=>'','object_id'=>(int)$row['object_id'],'mismatches'=>['not_in_final_target']];}
        $summary=['CREATE'=>0,'ADOPT'=>0,'UPDATE'=>0,'UNCHANGED'=>0,'ARCHIVE'=>0];foreach($actions as $a){$k=(string)$a['action'];if(isset($summary[$k]))$summary[$k]++;}
        // Project-defined limits; nothing from another portal is assumed.
        $settings=(array)($profile['settings']??[]);
        $expectedWorldCount=(int)($settings['expected_world_count']??0);
        $minArticles=(int)($settings['min_article_intents']??0);
        $maxMenu=(int)($settings['max_megamenu_children']??0);
        if($expectedWorldCount<1)$errors[]='EXPECTED_WORLD_COUNT_MISSING';
        if($minArticles<3)$errors[]='MIN_ARTICLE_INTENTS_BELOW_3';
        if($maxMenu<1||$maxMenu>10)$errors[]='MEGAMENU_LIMIT_INVALID';
        $worlds=[];$directChildren=[];$leafCount=0;$corePages=[];$contentChildren=[];$articleOwners=[];
        foreach((array)($profile['nodes']??[]) as $n){
            if(!is_array($n)||(string)($n['status']??'active')!=='active')continue;
            $id=(string)($n['node_id']??'');$pillar=(string)($n['pillar']??'');
            $par=(string)($n['parent_id']??'');$kind=(string)($n['object_type']??'');
            if($pillar==='core'&&$kind==='page')$corePages[$id]=$n;
            if(str_starts_with($id,'core:world:')){
                $worlds[$id]=true;
                if($par!=='')$errors[]='WORLD_NOT_ROOT:'.$id;
            }
            if($pillar==='core'&&$kind==='page'&&str_starts_with($par,'core:world:'))$directChildren[$par][]=$id;
            if($pillar==='core'&&$kind==='category'){
                $leafCount++;
                if($par==='')$errors[]='LEAF_WITHOUT_PARENT:'.$id;
                $contentChildren[$par][]=$id;
                $intents=array_values(array_filter(array_map('strval',(array)($n['supporting_intents']??[])),static fn($v)=>trim($v)!==''));
                $uniq=[];foreach($intents as $intent){$key=function_exists('mb_strtolower')?mb_strtolower(trim($intent),'UTF-8'):strtolower(trim($intent));if(isset($uniq[$key]))$errors[]='DUPLICATE_LEAF_INTENT:'.$id; if(isset($articleOwners[$key])&&$articleOwners[$key]!==$id)$errors[]='ARTICLE_INTENT_CANNIBALIZATION:'.$id.':'.$articleOwners[$key];$articleOwners[$key]=$id;$uniq[$key]=1;}
                if(count($uniq)<$minArticles)$errors[]='LEAF_INTENTS_BELOW_MIN:'.$id;
            }
        }
        if(count($worlds)!==$expectedWorldCount)$errors[]='WORLD_COUNT_MISMATCH:'.count($worlds).':'.$expectedWorldCount;
        foreach($worlds as $wid=>$_){
            $count=count((array)($directChildren[$wid]??[]));
            if($count<1)$errors[]='WORLD_WITHOUT_MENU_CHILDREN:'.$wid;
            if($maxMenu>0&&$count>$maxMenu)$errors[]='MEGAMENU_TOO_WIDE:'.$wid.':'.$count;
        }
        // Terminal CORE pages MUST lead to a real content category. Not every
        // page needs three separate categories: three distinct ARTICLES per leaf.
        $pageChildren=[];foreach($corePages as $id=>$n){$par=(string)($n['parent_id']??'');if(isset($corePages[$par]))$pageChildren[$par][]= $id;}
        foreach($corePages as $id=>$n){
            if(str_starts_with($id,'core:world:')||in_array($id,['core:hub'],true))continue;
            if(empty($pageChildren[$id])&&empty($contentChildren[$id]))$errors[]='EMPTY_TERMINAL_CORE_PAGE:'.$id;
        }
        $entityCount=count((array)($profile['entities']??[]));$coreCount=0;
        foreach((array)($profile['entities']??[]) as $e){foreach((array)($e['placements']??[]) as $pl)if(is_array($pl)&&(string)($pl['pillar']??'')==='core'){$coreCount++;break;}}
        $liveFingerprint=self::fingerprint($live['fingerprint_rows']);
        $actionFingerprint=self::fingerprint($actions);
        $profileFingerprint=self::profile_fingerprint($profile);
        $planFingerprint=hash('sha256',$profileFingerprint.'|'.$liveFingerprint.'|'.$actionFingerprint);
        return [
            'contract'=>self::CONTRACT,'plugin_version'=>APKW_VERSION,'status'=>$errors?'BLOCKED':'PASS','valid'=>!$errors,
            'generated_at_utc'=>gmdate('c'),'profile_revision'=>APKW_TargetTree::revision($profile),'profile_sha256'=>$profileFingerprint,
            'inventory'=>['canonical_entities'=>$entityCount,'core_entities'=>$coreCount,'non_core_entities'=>$entityCount-$coreCount],
            'structure'=>['logical_nodes'=>count((array)($profile['nodes']??[])),'physical_target_objects'=>count($nodes),'worlds_core_level_1'=>count($worlds)===$expectedWorldCount,'world_count'=>count($worlds),'core_content_categories'=>$leafCount],
            'summary'=>$summary,'action_count'=>count($actions),'actions'=>$actions,'errors'=>array_values(array_unique($errors)),
            'live_fingerprint'=>$liveFingerprint,'action_fingerprint'=>$actionFingerprint,'plan_fingerprint'=>$planFingerprint,
            'provider_calls'=>0,'provider_cost_usd'=>0,'wordpress_structure_writes'=>0,
            'profile'=>$profile
        ];
    }

    public static function public_report(array $plan):array{$x=$plan;unset($x['profile']);return $x;}

    private static function load_live_candidates(array $nodes):array{
        $byType=['page'=>[],'category'=>[],'journal_cat'=>[],'hp_listing_category'=>[]];
        $desiredSlugs=[];foreach($nodes as $n){$type=(string)($n['object_type']??'');$slug=(string)($n['slug']??'');if(isset($byType[$type])&&$slug!=='')$desiredSlugs[$type][$slug]=true;}
        $add=function($obj,string $type)use(&$byType){$id=self::object_id($obj,$type);if($id<1)return;$byType[$type][$id]=$obj;};
        if(function_exists('get_posts')){
            $slugs=array_keys($desiredSlugs['page']);if($slugs){$rows=get_posts(['post_type'=>'page','post_status'=>['publish','draft','private','pending'],'posts_per_page'=>-1,'no_found_rows'=>true,'suppress_filters'=>true,'post_name__in'=>$slugs]);foreach((array)$rows as $o)if(is_object($o))$add($o,'page');}
            $rows=get_posts(['post_type'=>'page','post_status'=>['publish','draft','private','pending'],'posts_per_page'=>-1,'no_found_rows'=>true,'suppress_filters'=>true,'meta_query'=>['relation'=>'OR',['key'=>self::META_NODE,'compare'=>'EXISTS'],['key'=>'_apkw_concept_id','compare'=>'EXISTS'],['key'=>'_apkw_portal_block','compare'=>'EXISTS'],['key'=>'_apkw_portal_hub','compare'=>'EXISTS']]]);foreach((array)$rows as $o)if(is_object($o))$add($o,'page');
        }
        if(function_exists('get_terms'))foreach(['category','journal_cat','hp_listing_category'] as $tax){
            $slugs=array_keys($desiredSlugs[$tax]);if($slugs){$rows=get_terms(['taxonomy'=>$tax,'hide_empty'=>false,'number'=>0,'slug'=>$slugs]);if(!(function_exists('is_wp_error')&&is_wp_error($rows)))foreach((array)$rows as $o)if(is_object($o))$add($o,$tax);}
            $rows=get_terms(['taxonomy'=>$tax,'hide_empty'=>false,'number'=>0,'meta_query'=>['relation'=>'OR',['key'=>self::META_NODE,'compare'=>'EXISTS'],['key'=>'_apkw_concept_id','compare'=>'EXISTS'],['key'=>'_apkw_portal_block','compare'=>'EXISTS']]]);if(!(function_exists('is_wp_error')&&is_wp_error($rows)))foreach((array)$rows as $o)if(is_object($o))$add($o,$tax);
        }
        $target=[];$finger=[];
        foreach($byType as $type=>$objects)foreach($objects as $o){$ref=self::object_ref($o,$type);$nid=self::meta_for($ref,$type,self::META_NODE);$finger[]=['object_type'=>$type,'object_id'=>self::object_id($o,$type),'name'=>self::object_name($o,$type),'slug'=>self::object_slug($o,$type),'parent'=>self::object_parent($o,$type),'status'=>$type==='page'?self::object_status($o):'','target_node_id'=>$nid,'concept_id'=>self::meta_for($ref,$type,'_apkw_concept_id'),'parent_concept_id'=>self::meta_for($ref,$type,'_apkw_parent_concept_id'),'pillar'=>self::meta_for($ref,$type,self::META_PILLAR),'active'=>self::meta_for($ref,$type,self::META_ACTIVE),'block'=>self::meta_for($ref,$type,'_apkw_portal_block')];if($nid!=='')$target[]=['node_id'=>$nid,'object_type'=>$type,'object_id'=>self::object_id($o,$type),'name'=>self::object_name($o,$type),'slug'=>self::object_slug($o,$type),'active'=>self::meta_for($ref,$type,self::META_ACTIVE),'status'=>$type==='page'?self::object_status($o):''];}
        usort($finger,static fn($a,$b)=>strcmp($a['object_type'].'|'.$a['object_id'],$b['object_type'].'|'.$b['object_id']));
        return ['objects'=>$byType,'target_bound'=>$target,'fingerprint_rows'=>$finger];
    }

    private static function find_existing(array $n,array $live){
        $id=(string)$n['node_id'];$type=(string)$n['object_type'];$expectedBlock=APKW_TargetTree::managed_block((string)$n['pillar']);$objects=$live['objects'][$type]??[];$byTarget=[];$byConcept=[];$bySlug=[];
        foreach($objects as $o){$ref=self::object_ref($o,$type);$nid=self::meta_for($ref,$type,self::META_NODE);$cid=self::meta_for($ref,$type,'_apkw_concept_id');$slug=self::object_slug($o,$type);if($nid!=='')$byTarget[$nid][]=$o;if($cid!=='')$byConcept[$cid][]=$o;if($slug!=='')$bySlug[$slug][]=$o;}
        if(!empty($byTarget[$id])){if(count($byTarget[$id])>1)throw new RuntimeException('Mehrdeutige Target-Bindung');return $byTarget[$id][0];}
        foreach(array_merge([$id],(array)($n['legacy_ids']??[])) as $legacy){if(empty($byConcept[$legacy]))continue;if(count($byConcept[$legacy])>1)throw new RuntimeException('Mehrdeutige Legacy-Bindung');return $byConcept[$legacy][0];}
        $slug=(string)$n['slug'];if(empty($bySlug[$slug]))return null;if(count($bySlug[$slug])>1)throw new RuntimeException('Mehrdeutiger Slug '.$type.'/'.$slug);$o=$bySlug[$slug][0];$ref=self::object_ref($o,$type);$bound=self::meta_for($ref,$type,self::META_NODE);if($bound!==''&&$bound!==$id)throw new RuntimeException('Slug anderweitig gebunden '.$type.'/'.$slug);if(self::norm(self::object_name($o,$type))!==self::norm((string)$n['display_name']))throw new RuntimeException('Ungebundener Slug kollidiert '.$type.'/'.$slug);$block=self::meta_for($ref,$type,'_apkw_portal_block');if($block!==''&&$block!==$expectedBlock)throw new RuntimeException('Slug gehört zu anderer Säule '.$type.'/'.$slug);return $o;
    }

    private static function expected_native_parent(string $parentId,string $type,array $profile,array $mapping,array $live):?int{
        if($parentId==='')return 0;$idx=APKW_TargetTree::node_index($profile);if(!isset($idx[$parentId]))return null;$pt=(string)($idx[$parentId]['object_type']??'');if($type==='page'&&$pt!=='page')return 0;if($type!=='page'&&$pt!==$type)return 0;if(isset($mapping[$parentId]))return (int)$mapping[$parentId];
        $parent=$idx[$parentId];try{$o=self::find_existing($parent,$live);}catch(Throwable $e){return null;}return $o?self::object_id($o,$pt):null;
    }
    private static function depth(array $n,array $p):int{$idx=[];foreach((array)($p['nodes']??[]) as $x)if(is_array($x))$idx[(string)($x['node_id']??'')]=$x;$d=0;$id=(string)($n['node_id']??'');$seen=[];while($id!==''&&isset($idx[$id])&&!isset($seen[$id])){$seen[$id]=1;$d++;$id=(string)($idx[$id]['parent_id']??'');}return $d;}
    private static function object_ref($x,string $type):array{return $type==='page'?['kind'=>'page','id'=>(int)($x->ID??0)]:['kind'=>'term','id'=>(int)($x->term_id??0),'taxonomy'=>$type];}
    private static function object_id($x,string $type):int{return $type==='page'?(int)($x->ID??0):(int)($x->term_id??0);}
    private static function object_name($x,string $type):string{$v=(string)($type==='page'?($x->post_title??''):($x->name??''));$v=function_exists('wp_specialchars_decode')?wp_specialchars_decode($v,ENT_QUOTES):html_entity_decode($v,ENT_QUOTES|ENT_HTML5,'UTF-8');return trim($v);}
    private static function object_slug($x,string $type):string{return (string)($type==='page'?($x->post_name??''):($x->slug??''));}
    private static function object_parent($x,string $type):int{return (int)($type==='page'?($x->post_parent??0):($x->parent??0));}
    private static function object_status($x):string{return (string)($x->post_status??'');}
    private static function meta_for(array $ref,string $type,string $key):string{if(($ref['kind']??'')==='page')return function_exists('get_post_meta')?(string)get_post_meta((int)$ref['id'],$key,true):'';return function_exists('get_term_meta')?(string)get_term_meta((int)$ref['id'],$key,true):'';}
    private static function norm(string $v):string{$v=html_entity_decode($v,ENT_QUOTES|ENT_HTML5,'UTF-8');$v=preg_replace('/\s+/u',' ',trim($v));return function_exists('mb_strtolower')?mb_strtolower((string)$v,'UTF-8'):strtolower((string)$v);}
    private static function profile_fingerprint(array $profile):string{if(isset($profile['inventory_binding'])&&is_array($profile['inventory_binding']))unset($profile['inventory_binding']['bound_at_utc']);return self::fingerprint($profile);}
    private static function fingerprint($value):string{$json=function_exists('wp_json_encode')?wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);return hash('sha256',(string)$json);}
}
