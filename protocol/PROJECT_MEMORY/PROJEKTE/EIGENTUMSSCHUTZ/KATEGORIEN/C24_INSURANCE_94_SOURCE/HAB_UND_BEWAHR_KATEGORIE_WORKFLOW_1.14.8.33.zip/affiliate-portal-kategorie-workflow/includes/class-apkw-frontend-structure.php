<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Frontend projection for page/taxonomy structure.
 *
 * Performance rule: never full-scan all pages/terms on a normal frontend request.
 * Queries are narrowly bound by parent/meta and cached per structural generation.
 * The structure is read-only on public requests. This class renders the stored
 * page/taxonomy projection and the canonical automatic footer navigation.
 */
final class APKW_FrontendStructure {
    public const CONTRACT='APKW_FRONTEND_STRUCTURE_V2';
    private const CACHE_GROUP='apkw-structure-v2';
    private const GENERATION_OPTION='apkw_frontend_structure_generation';
    private static ?int $generation=null;
    private static bool $auto_footer_printed=false;
    private static ?array $target_snapshot_override=null;

    public static function init():void{
        if(function_exists('add_filter')){
            add_filter('the_content',[__CLASS__,'append_current_page_structure'],25);
            add_filter('wp_robots',[__CLASS__,'noindex_empty_new_structure'],20);
            add_filter('render_block_core/page-list',[__CLASS__,'filter_page_list_block'],20,2);
            add_filter('get_the_archive_description',[__CLASS__,'describe_terminal_category_archive'],20,1);
        }
        if(function_exists('add_shortcode')) add_shortcode('apkw_footer_entries',[__CLASS__,'footer_shortcode']);
        if(function_exists('add_action')){
            add_action('wp_footer',[__CLASS__,'output_auto_footer'],50);
            add_action('wp_head',[__CLASS__,'output_c22_navigation_css'],90);
        }
    }

    /**
     * Fail-closed SEO hygiene on target-bound structural shells: empty targets
     * cannot become indexable just because a WP term/page was synchronized.
     * Editorial object/topic and new provider taxonomy shells require explicit
     * editorial release even if an unrelated article/listing is later assigned.
     * Does not modify any posts, terms, plugin/SEO data or WordPress options.
     */
    public static function noindex_empty_new_structure(array $robots):array{
        if (!function_exists('get_queried_object')) return $robots;
        $o=get_queried_object();
        if (!is_object($o)) return $robots;
        $id='';$empty=false;$approval=false;$kind='';
        if (isset($o->term_id) && function_exists('get_term_meta')) {
            $tax=(string)($o->taxonomy??'');
            if (!in_array($tax,['category','journal_cat','hp_listing_category'],true)) return $robots;
            $tid=(int)$o->term_id;
            $id=(string)get_term_meta($tid,'_apkw_target_node_id',true);
            if ($id==='') return $robots;
            $empty=((int)($o->count??0)===0);
            $approval=(string)get_term_meta($tid,'_apkw_seo_index_approved',true)==='1';
            $kind='term';
        } elseif (isset($o->ID) && (string)($o->post_type??'')==='page' && function_exists('get_post_meta')) {
            $pid=(int)$o->ID;
            $id=(string)get_post_meta($pid,'_apkw_target_node_id',true);
            if ($id==='') return $robots;
            $empty=(trim((string)($o->post_content??''))==='');
            $approval=(string)get_post_meta($pid,'_apkw_seo_index_approved',true)==='1';
            $kind='page';
        } else return $robots;
        // Do not change SEO rules for unrelated or third-party objects even if
        // another extension accidentally attached a foreign target-node marker.
        if (!str_starts_with($id,'core:') &&
            !str_starts_with($id,'editorial:') &&
            !str_starts_with($id,'directory:')) return $robots;
        // The portal's expandable editorial and provider shells have NO SEO
        // owner yet. A term count greater than zero is not editorial approval.
        $unapprovedShell=(str_starts_with($id,'editorial:hub:') ||
            str_starts_with($id,'editorial:group:') ||
            str_starts_with($id,'editorial:object:') ||
            str_starts_with($id,'editorial:cluster:') ||
            $id==='editorial:glossar' ||
            str_starts_with($id,'directory:category:extension:') ||
            preg_match('/^directory:service:h0(?:8[4-9]|9[0-5])$/D',$id)===1);
        // Empty originals are also noindex; once real content appears the
        // content SEO owner can decide indexation independently. New editorial
        // navigation needs deliberate approval after useful content is added.
        if ($empty || ($unapprovedShell && !$approval)) {
            unset($robots['index']);$robots['noindex']=true;
        }
        return $robots;
    }

    /**
     * WordPress article-category archives are TERMINAL, not another
     * page/category stage. Clarify this without altering archive queries,
     * widgets, SEO permalinks, taxonomy parents or existing article records.
     */
    public static function describe_terminal_category_archive(string $description):string{
        if(!function_exists('is_category')||!is_category()||!function_exists('get_queried_object')||!function_exists('get_term_meta'))return $description;
        $term=get_queried_object();if(!is_object($term)||empty($term->term_id)||($term->taxonomy??'')!=='category')return $description;
        $node=(string)get_term_meta((int)$term->term_id,'_apkw_target_node_id',true);
        if(!str_starts_with($node,'core:leaf:')&&!str_starts_with($node,'core:c22:category:'))return $description;
        $notice='<p class="apkw-final-article-category">Artikelkategorie – letzte Ebene. Hier erscheinen die zugehörigen Beiträge, keine weiteren Unterkategorien.</p>';
        return $description.$notice;
    }

    public static function output_c22_navigation_css():void{
        if(!self::target_active()||!self::has_c22_in_snapshot())return;
        echo '<style id="apkw-c22-clean-navigation">.apkw-target-header-nav .apkw-mega-spacer{height:2.1em;min-height:2.1em;visibility:hidden;pointer-events:none;list-style:none}.apkw-structure-nav h2{font-size:1.1em;margin:1em 0 .6em}.apkw-legacy-archive{margin:1em 0;padding:.7em 1em;border:1px solid #ddd}.apkw-legacy-archive summary{cursor:pointer;font-size:.9em}.apkw-legacy-archive ul{margin-top:.6em}</style>';
    }

    public static function output_auto_footer():void{
        if(self::$auto_footer_printed||!self::target_active())return;
        if(self::target_sync_in_progress()&&!self::target_active())return;
        if(function_exists('is_admin')&&is_admin())return;
        $enabled=function_exists('apply_filters')?(bool)apply_filters('apkw_auto_footer_enabled',true):true;if(!$enabled)return;
        $html=self::render_footer_entries();if($html==='')return;self::$auto_footer_printed=true;
        echo '<div class="apkw-auto-footer" data-apkw-version="'.self::esc_attr(APKW_VERSION).'">'.$html.'</div>';
        echo '<style id="apkw-auto-footer-css">.apkw-auto-footer{border-top:1px solid rgba(0,0,0,.12);padding:18px 24px;margin-top:28px;background:#fff}.apkw-auto-footer .apkw-footer-entries ul{display:flex;flex-wrap:wrap;justify-content:center;gap:10px 24px;list-style:none;margin:0;padding:0}.apkw-auto-footer .apkw-footer-entries a{text-decoration:none;font-size:14px}.apkw-auto-footer .apkw-footer-entries a:hover{text-decoration:underline}</style>';
    }

    /**
     * Replace the block-theme Page List fallback with the canonical active
     * target navigation. This is intentionally activated only after a fully
     * read-back target snapshot became active, so legacy/unmanaged pages can
     * never leak into the canonical header after activation.
     */
    public static function filter_page_list_block(string $content,array $block=[]):string{
        if(function_exists('is_admin')&&is_admin())return $content;
        return self::canonical_page_list_replacement($content);
    }

    private static function canonical_page_list_replacement(string $content):string{
        // An active target snapshot is itself the authoritative site binding.
        // Do not add a second branding/domain heuristic that can disable the
        // canonical header after a successful target activation.
        if(!self::target_active())return $content;
        $html=self::render_header_navigation();
        return $html!==''?$html:$content;
    }

    public static function render_header_navigation():string{
        if(!self::target_active())return '';
        $spec=self::header_navigation_spec();
        if(empty($spec['enabled'])||!is_array($spec['roots']??null)||!$spec['roots'])return '';
        $out='<ul class="wp-block-page-list apkw-target-header-nav" data-apkw-contract="'.self::esc_attr(self::CONTRACT).'" data-apkw-nav-source="active-target-snapshot">';
        $rendered=0;
        foreach($spec['roots'] as $root){
            if(!is_array($root))continue;
            $nid=trim((string)($root['node_id']??''));if($nid==='')continue;
            $html=self::render_target_nav_branch($nid,max(0,(int)($root['child_depth']??0)));
            if($html==='')continue;$out.=$html;$rendered++;
        }
        return $rendered>0?$out.'</ul>':'';
    }

    public static function readback_header_navigation():array{
        if(!self::target_active())return ['valid'=>false,'errors'=>['NO_ACTIVE_TARGET']];
        $spec=self::header_navigation_spec();$expected=[];
        foreach((array)($spec['roots']??[]) as $root){
            if(!is_array($root))continue;$nid=trim((string)($root['node_id']??''));if($nid==='')continue;
            self::collect_target_nav_expected($nid,max(0,(int)($root['child_depth']??0)),$expected);
        }
        $html=self::render_header_navigation();$errors=[];
        // Independent source-to-WordPress integrity checks. The renderer is NOT
        // an oracle: a missing or wrongly-bound URL must not silently disappear
        // from both the expected list and the rendered list.
        $errors=array_merge($errors,self::readback_navigation_source_integrity($spec));
        if($html==='')$errors[]='HEADER_NAV_EMPTY';
        foreach($expected as $item){
            $label=self::esc_html((string)$item['label']);$url=self::esc_url((string)$item['url']);
            if(strpos($html,'>'.$label.'</span></a>')===false||strpos($html,'href="'.$url.'"')===false)$errors[]='HEADER_ITEM_MISSING:'.(string)$item['node_id'];
        }
        // Exercise the exact block filter path used by Twenty Twenty-Five's
        // Page List fallback. A legacy marker must be replaced completely.
        $filtered=self::canonical_page_list_replacement('__APKW_LEGACY_PAGE_LIST__');
        if($filtered!==$html)$errors[]='HEADER_BLOCK_FILTER_NOT_CANONICAL';
        if(strpos($filtered,'__APKW_LEGACY_PAGE_LIST__')!==false)$errors[]='HEADER_LEGACY_LEAK';
        return ['valid'=>!$errors,'expected_count'=>count($expected),'errors'=>$errors,'html'=>$html];
    }


    /**
     * Readback-only integrity gate, never run on ordinary frontend requests.
     * Independent of target_nav_item_for_node()/render_header_navigation():
     * it inspects declared active nodes even if their links went missing.
     * The WordPress post/term binding is an independent identity source.
     * In particular: a topic mapped to its own area page and a topic with a
     * missing permalink MUST invalidate the whole C2.2 navigation readback.
     */
    private static function readback_navigation_source_integrity(array $spec):array{
        $s=self::target_snapshot();$nodes=[];$errors=[];$map=(array)($s['mapping']??[]);
        foreach((array)($s['nodes']??[]) as $n){
            if(!is_array($n)||(string)($n['status']??'active')!=='active')continue;
            $nid=(string)($n['node_id']??'');if($nid==='')continue;
            if(isset($nodes[$nid]))$errors[]='SOURCE_DUPLICATE_NODE:'.$nid;
            $nodes[$nid]=$n;
        }
        $check=[];
        $walk=function(string $nid,int $remaining)use(&$walk,&$check,&$errors,$nodes,$spec):void{
            if(!isset($nodes[$nid])){$errors[]='HEADER_SOURCE_NODE_MISSING:'.$nid;return;}
            if(isset($check[$nid]))return;
            $check[$nid]=true;
            if($remaining<=0)return;
            $kids=[];$isC22Area=self::c22_topic_area($nid,array_values($nodes));
            foreach($nodes as $k=>$n){
                if((string)($n['parent_id']??'')!==$nid)continue;
                if($isC22Area&&!str_starts_with($k,'core:c22:topic:'))continue;
                if(array_key_exists('include_entity_pages',$spec)&&!$spec['include_entity_pages']&&trim((string)($n['entity_id']??''))!=='')continue;
                $kids[]=$n;
            }
            usort($kids,static fn($a,$b)=>((int)($a['nav_order']??9999)<=>(int)($b['nav_order']??9999))?:strcmp((string)($a['node_id']??''),(string)($b['node_id']??'')));
            $core=(string)($nodes[$nid]['pillar']??'')==='core';
            $world=str_starts_with($nid,'core:world:');$area=str_starts_with($nid,'core:area:')||str_starts_with($nid,'core:c22:area:');
            $max=$core&&self::has_c22_in_snapshot()&&$world?5:($core&&self::has_c22_in_snapshot()&&$area?4:3);
            foreach(($core?array_slice($kids,0,$max):$kids) as $k)$walk((string)$k['node_id'],$remaining-1);
        };
        foreach((array)($spec['roots']??[]) as $root){
            if(!is_array($root))continue;
            $nid=trim((string)($root['node_id']??''));if($nid==='')continue;
            $walk($nid,max(0,(int)($root['child_depth']??0)));
        }
        // ALL current CORE worlds, areas and concrete topics must be checked,
        // including 6th areas and 5th topics hidden behind the teaser limit.
        // This coverage is derived from the source nodes, not the renderer.
        if(self::has_c22_in_snapshot()){
            foreach($nodes as $nid=>$n){
                $world=str_starts_with($nid,'core:world:');
                $area=str_starts_with($nid,'core:area:')||str_starts_with($nid,'core:c22:area:');
                $topic=str_starts_with($nid,'core:c22:topic:');
                if(!$world&&!$area&&!$topic)continue;
                $check[$nid]=true;
                $parent=(string)($n['parent_id']??'');
                if($area&&(!isset($nodes[$parent])||!str_starts_with($parent,'core:world:')))
                    $errors[]='C22_AREA_PARENT_MISSING:'.$nid;
                if($topic&&(!isset($nodes[$parent])||
                   (!str_starts_with($parent,'core:area:')&&!str_starts_with($parent,'core:c22:area:'))))
                    $errors[]='C22_TOPIC_PARENT_MISSING:'.$nid;
            }
        }
        // Compare the entire C2.2 physical graph with the importer's canonical
        // ADD-only manifest, independently of the stored active snapshot.
        // A topic moved to a DIFFERENT valid area (not just an orphan) and a
        // terminal term moved to the wrong topic are real hierarchy defects.
        if(self::has_c22_in_snapshot() && class_exists('APKW_C22_AddOnly')){
            foreach(APKW_C22_AddOnly::jobs() as $job){
                $nid=(string)$job['node_id'];$n=$nodes[$nid]??null;
                if(!is_array($n)||
                   (string)($n['parent_id']??'')!==(string)$job['parent_id']||
                   (string)($n['object_type']??'')!==(string)$job['type']||
                   (string)($n['display_name']??'')!==(string)$job['name']||
                   (string)($n['slug']??'')!==(string)$job['slug'])
                    $errors[]='C22_SOURCE_MANIFEST_MISMATCH:'.$nid;
            }
        }
        $physicalIds=[];
        foreach(array_keys($check) as $nid){
            $n=$nodes[$nid];$type=(string)($n['object_type']??'');
            // Relation nodes are logical edges and intentionally have no WP ID.
            if($type==='relation'){
                $target=(string)($n['target_node_id']??'');
                if(!isset($nodes[$target])||empty($map[$target]['object_id']))$errors[]='NAV_RELATION_TARGET_MISSING:'.$nid;
                continue;
            }
            $m=$map[$nid]??null;$id=is_array($m)?(int)($m['object_id']??0):0;
            if($id<1){$errors[]='NAV_TARGET_MAPPING_MISSING:'.$nid;continue;}
            if($type!==(string)($m['object_type']??'')){$errors[]='NAV_TARGET_TYPE_MISMATCH:'.$nid;continue;}
            $pk=$type.':'.$id;
            if(isset($physicalIds[$pk])&&$physicalIds[$pk]!==$nid)$errors[]='NAV_PHYSICAL_ID_REUSED:'.$nid.':'.$physicalIds[$pk];
            $physicalIds[$pk]=$nid;
            $par=(string)($n['parent_id']??'');
            if(isset($map[$par])&&$type==='page'&&$id===(int)($map[$par]['object_id']??0))
                $errors[]='NAV_TARGET_EQUALS_PARENT:'.$nid;
            if($type==='page'){
                $post=function_exists('get_post')?get_post($id):null;
                if(!is_object($post)||(int)($post->ID??0)!==$id||(string)($post->post_type??'')!=='page'||(string)($post->post_status??'')!=='publish'){
                    $errors[]='NAV_PAGE_UNPUBLISHED_OR_MISSING:'.$nid;continue;
                }
                if(function_exists('get_post_meta')&&(string)get_post_meta($id,'_apkw_target_node_id',true)!==$nid)
                    $errors[]='NAV_PAGE_IDENTITY_MISMATCH:'.$nid;
                if(isset($post->post_parent)&&isset($map[$par])&&(int)$post->post_parent!==(int)($map[$par]['object_id']??0))
                    $errors[]='NAV_PAGE_PARENT_MISMATCH:'.$nid;
                $url=function_exists('get_permalink')?get_permalink($id):'';
            }elseif($type==='category'){
                $url=function_exists('get_term_link')?get_term_link($id,'category'):'';
            }else{continue;}
            if((function_exists('is_wp_error')&&is_wp_error($url))||!is_string($url)||trim($url)==='')
                $errors[]='NAV_TARGET_URL_MISSING:'.$nid;
        }
        return array_values(array_unique($errors));
    }

    /** Every terminal CORE page must render at least one real content category. */
    public static function readback_terminal_core_categories():array{
        if(!self::target_active())return ['valid'=>false,'checked'=>0,'failure_count'=>1,'failures'=>[['reason'=>'NO_ACTIVE_TARGET']]];
        $snap=self::target_snapshot();$nodes=(array)($snap['nodes']??[]);$map=(array)($snap['mapping']??[]);
        $pages=[];$children=[];$categories=[];
        foreach($nodes as $n){
            if(!is_array($n)||(string)($n['status']??'active')!=='active'||(string)($n['pillar']??'')!=='core')continue;
            $nid=(string)($n['node_id']??'');$par=(string)($n['parent_id']??'');$type=(string)($n['object_type']??'');
            if($type==='page'){$pages[$nid]=$n;if($par!=='')$children[$par][]=$nid;}
            if($type==='category')$categories[$par][]=$n;
        }
        $failures=[];$checked=0;
        foreach($pages as $id=>$p){
            if(str_starts_with($id,'core:world:')||$id==='core:hub'||!empty($children[$id]))continue;
            $checked++;$cats=(array)($categories[$id]??[]);
            if(!$cats){$failures[]=['node_id'=>$id,'reason'=>'EMPTY_TERMINAL_CORE_PAGE'];continue;}
            $pid=(int)($map[$id]['object_id']??0);
            if($pid<1){$failures[]=['node_id'=>$id,'reason'=>'PAGE_MAPPING_MISSING'];continue;}
            $page=function_exists('get_post')?get_post($pid):null;
            if(!is_object($page)||($page->post_status??'')!=='publish'){$failures[]=['node_id'=>$id,'reason'=>'PAGE_NOT_PUBLISHED'];continue;}
            foreach($cats as $n){
                $nid=(string)($n['node_id']??'');$tid=(int)($map[$nid]['object_id']??0);
                if($tid<1){$failures[]=['node_id'=>$nid,'reason'=>'LEAF_MAPPING_MISSING'];continue;}
                $term=function_exists('get_term')?get_term($tid,'category'):null;
                if(!is_object($term)|| (int)($term->term_id??0)!==$tid){$failures[]=['node_id'=>$nid,'reason'=>'LEAF_TERM_MISSING'];continue;}
                if(function_exists('get_term_meta')&&(string)get_term_meta($tid,'_apkw_target_node_id',true)!==$nid)$failures[]=['node_id'=>$nid,'reason'=>'LEAF_BINDING_MISMATCH'];
                // An existing terminal category without a working archive URL
                // is a dead end even if its term ID and meta remain intact.
                $archive=function_exists('get_term_link')?get_term_link($tid,'category'):'';
                if((function_exists('is_wp_error')&&is_wp_error($archive))||!is_string($archive)||trim($archive)==='')
                    $failures[]=['node_id'=>$nid,'reason'=>'LEAF_ARCHIVE_URL_MISSING'];
            }
        }
        return ['valid'=>!$failures,'checked'=>$checked,'expected_hubs'=>$checked,'failure_count'=>count($failures),'failures'=>$failures];
    }

    public static function readback_content_filter_registration():array{
        if(!function_exists('has_filter'))return ['valid'=>false,'priority'=>false,'reason'=>'HAS_FILTER_MISSING'];
        $priority=has_filter('the_content',[__CLASS__,'append_current_page_structure']);
        return ['valid'=>$priority!==false,'priority'=>$priority,'reason'=>$priority===false?'THE_CONTENT_FILTER_MISSING':''];
    }

    public static function readback_header_filter_registration():array{
        if(!function_exists('has_filter'))return ['valid'=>false,'priority'=>false,'reason'=>'HAS_FILTER_MISSING'];
        $priority=has_filter('render_block_core/page-list',[__CLASS__,'filter_page_list_block']);
        return ['valid'=>$priority!==false,'priority'=>$priority,'reason'=>$priority===false?'PAGE_LIST_FILTER_MISSING':''];
    }

    /**
     * Admin/readback-only live coverage gate. It finds published page roots that
     * hang directly below canonical CORE pages but have no active target mapping.
     * Such a page can remain reachable even though it received no Rule16 leaves.
     */
    public static function readback_unbound_core_page_roots():array{
        if(!self::target_active())return ['valid'=>false,'count'=>0,'leaks'=>[],'error'=>'NO_ACTIVE_TARGET'];
        if(!function_exists('get_posts'))return ['valid'=>false,'count'=>0,'leaks'=>[],'error'=>'GET_POSTS_MISSING'];
        $s=self::target_snapshot();$nodes=(array)($s['nodes']??[]);$map=(array)($s['mapping']??[]);$targetIds=[];$parentNodeByObject=[];
        foreach($nodes as $n){
            if(!is_array($n)||(string)($n['status']??'active')!=='active'||(string)($n['pillar']??'')!=='core'||(string)($n['object_type']??'')!=='page')continue;
            $nid=(string)($n['node_id']??'');$oid=(int)($map[$nid]['object_id']??0);if($oid<1)continue;$targetIds[$oid]=true;$parentNodeByObject[$oid]=$nid;
        }
        $parentIds=array_keys($targetIds);if(!$parentIds)return ['valid'=>false,'count'=>0,'leaks'=>[],'error'=>'NO_CORE_PAGE_MAPPINGS'];
        $rows=get_posts(['post_type'=>'page','post_status'=>['publish'],'posts_per_page'=>2001,'no_found_rows'=>true,'orderby'=>'ID','order'=>'ASC','suppress_filters'=>true,'update_post_meta_cache'=>false,'update_post_term_cache'=>false,'post_parent__in'=>$parentIds]);
        $rows=(array)$rows;$truncated=count($rows)>2000;if($truncated)$rows=array_slice($rows,0,2000);$leaks=[];
        foreach($rows as $p){
            if(!is_object($p)||empty($p->ID))continue;$id=(int)$p->ID;if(isset($targetIds[$id]))continue;
            $bound=function_exists('get_post_meta')?(string)get_post_meta($id,'_apkw_target_node_id',true):'';if($bound!==''&&isset($map[$bound]))continue;
            $parent=(int)($p->post_parent??0);$leaks[]=['page_id'=>$id,'title'=>trim((string)($p->post_title??'')),'slug'=>(string)($p->post_name??''),'parent_page_id'=>$parent,'parent_node_id'=>(string)($parentNodeByObject[$parent]??''),'target_node_id'=>$bound];
        }
        return ['valid'=>!$leaks&&!$truncated,'count'=>count($leaks),'truncated'=>$truncated,'leaks'=>$leaks];
    }

    private static function header_navigation_spec():array{
        $s=self::target_snapshot();$x=$s['project']['header_navigation']??[];return is_array($x)?$x:[];
    }

    private static function target_node_index_snapshot():array{
        $s=self::target_snapshot();$out=[];foreach((array)($s['nodes']??[]) as $n)if(is_array($n)&&(string)($n['status']??'active')==='active')$out[(string)($n['node_id']??'')]=$n;return $out;
    }

    /**
     * C2.2 front-end contract: once true concrete topic pages are attached to
     * a protected area, its earlier R3/legacy page-3 aggregators are NOT
     * another step in the canonical browsing path. Those historical pages
     * remain intact, addressable by their own SEO URLs, and are provided in a
     * clearly separated optional archive on the area landing page.
     * Pure projection: no updates, redirects or taxonomy mutations.
     */
    private static function c22_topic_area(string $parent,array $nodes):bool{
        if(!str_starts_with($parent,'core:area:') && !str_starts_with($parent,'core:c22:area:'))return false;
        foreach($nodes as $n){
            if(!is_array($n)||(string)($n['status']??'active')!=='active')continue;
            if((string)($n['parent_id']??'')===$parent && str_starts_with((string)($n['node_id']??''),'core:c22:topic:'))return true;
        }
        return false;
    }
    private static function c22_primary_rows(string $parent,array $nodes,bool $includeLegacy=false):array{
        $isC22Area=self::c22_topic_area($parent,$nodes);
        $out=[];
        foreach($nodes as $n){
            if(!is_array($n)||(string)($n['status']??'active')!=='active'||(string)($n['parent_id']??'')!==$parent)continue;
            if($isC22Area && !$includeLegacy && !str_starts_with((string)($n['node_id']??''),'core:c22:topic:'))continue;
            $out[]=$n;
        }
        return $out;
    }

    private static function target_nav_children_nodes(string $parent):array{
        $s=self::target_snapshot();$rows=[];$seq=0;
        $spec=self::header_navigation_spec();$includeEntityPages=!array_key_exists('include_entity_pages',$spec)||(bool)$spec['include_entity_pages'];
        foreach(self::c22_primary_rows($parent,(array)($s['nodes']??[])) as $n){
            if(!$includeEntityPages&&trim((string)($n['entity_id']??''))!=='')continue;
            $n['_apkw_seq']=$seq++;$rows[]=$n;
        }
        usort($rows,static function($a,$b){
            $ao=array_key_exists('nav_order',$a)?(int)$a['nav_order']:9999;$bo=array_key_exists('nav_order',$b)?(int)$b['nav_order']:9999;
            return ($ao<=>$bo) ?: ((int)($a['_apkw_seq']??0)<=> (int)($b['_apkw_seq']??0));
        });
        return $rows;
    }

    private static function target_nav_item_for_node(array $n):?array{
        $s=self::target_snapshot();$map=(array)($s['mapping']??[]);$type=(string)($n['object_type']??'');
        if($type==='relation'){
            $target=(string)($n['target_node_id']??'');$m=$map[$target]??null;if(!is_array($m))return null;
            $item=self::target_item_from_mapping($n,$m);if(!$item)return null;$item['node_id']=(string)($n['node_id']??'');$item['child_parent_id']='';return $item;
        }
        $nid=(string)($n['node_id']??'');$m=$map[$nid]??null;if(!is_array($m))return null;
        $parent=(string)($n['parent_id']??'');
        if((string)($n['object_type']??'')==='page' && isset($map[$parent]) && (int)($m['object_id']??0)===(int)($map[$parent]['object_id']??-1))return null;
        $item=self::target_item_from_mapping($n,$m);if(!$item)return null;$item['node_id']=$nid;$item['child_parent_id']=$nid;return $item;
    }

    private static function render_target_nav_branch(string $node_id,int $remaining):string{
        $idx=self::target_node_index_snapshot();$n=$idx[$node_id]??null;if(!is_array($n))return '';
        $item=self::target_nav_item_for_node($n);if(!$item)return '';
        $children=[];if($remaining>0&&$item['child_parent_id']!=='')$children=self::target_nav_children_nodes((string)$item['child_parent_id']);
        $hasChildren=$remaining>0&&!empty($children);
        $cls='wp-block-pages-list__item wp-block-navigation-item'.($hasChildren?' has-child open-on-hover-click':'');
        $out='<li class="'.self::esc_attr($cls).'" data-apkw-node-id="'.self::esc_attr((string)$item['node_id']).'">';
        $out.='<a class="wp-block-pages-list__item__link wp-block-navigation-item__content" href="'.self::esc_url((string)$item['url']).'"><span class="wp-block-navigation-item__label">'.self::esc_html((string)$item['label']).'</span></a>';
        if($hasChildren){
            $out.='<ul class="wp-block-navigation__submenu-container wp-block-page-list__submenu-container">';
            $isCore=(string)($n['pillar']??'')==='core';
            $isC22=self::has_c22_in_snapshot();
            $isWorld=str_starts_with($node_id,'core:world:');
            $isArea=str_starts_with($node_id,'core:area:')||str_starts_with($node_id,'core:c22:area:');
            // After C2.2: five direct area links per world; four concrete
            // topics per area. No fake topic is added just to fill a column.
            $max=$isCore&&$isC22&&$isWorld?5:($isCore&&$isC22&&$isArea?4:3);
            $visible=$isCore?array_slice($children,0,$max):$children;
            foreach($visible as $child){$cid=(string)($child['node_id']??'');if($cid!=='')$out.=self::render_target_nav_branch($cid,$remaining-1);}
            if($isCore&&$isC22&&($isWorld||$isArea)){
                for($i=count($visible);$i<$max;$i++)$out.='<li class="apkw-mega-spacer" aria-hidden="true"></li>';
                $out.='<li class="wp-block-pages-list__item wp-block-navigation-item apkw-target-more">';
                $out.='<a class="wp-block-navigation-item__content" href="'.self::esc_url((string)$item['url']).'"><span class="wp-block-navigation-item__label">'.($isWorld?'Alle Schutzbereiche':'Alle Themen').'</span></a></li>';
            }elseif($isCore&&count($children)>3){
                $out.='<li class="wp-block-pages-list__item wp-block-navigation-item apkw-target-more">';
                $out.='<a class="wp-block-navigation-item__content" href="'.self::esc_url((string)$item['url']).'"><span class="wp-block-navigation-item__label">Weitere Kategorien</span></a></li>';
            }
            $out.='</ul>';
        }
        return $out.'</li>';
    }

    private static function has_c22_in_snapshot():bool{
        $s=self::target_snapshot();return !empty($s['project']['c22_add_only_base_revision']);
    }

    private static function collect_target_nav_expected(string $node_id,int $remaining,array &$out):void{
        $idx=self::target_node_index_snapshot();$n=$idx[$node_id]??null;if(!is_array($n))return;
        $item=self::target_nav_item_for_node($n);if(!$item)return;$out[]=$item;
        if($remaining<=0||$item['child_parent_id']==='')return;
        $children=self::target_nav_children_nodes((string)$item['child_parent_id']);
        $isCore=(string)($n['pillar']??'')==='core';
        $isC22=self::has_c22_in_snapshot();
        $isWorld=str_starts_with($node_id,'core:world:');
        $isArea=str_starts_with($node_id,'core:area:')||str_starts_with($node_id,'core:c22:area:');
        $max=$isCore&&$isC22&&$isWorld?5:($isCore&&$isC22&&$isArea?4:3);
        foreach(($isCore?array_slice($children,0,$max):$children) as $child){$cid=(string)($child['node_id']??'');if($cid!=='')self::collect_target_nav_expected($cid,$remaining-1,$out);}
    }

    public static function invalidate_cache():void{
        $old=function_exists('get_option')?(int)get_option(self::GENERATION_OPTION,1):1;$next=max(1,$old+1);
        if(function_exists('get_option')&&function_exists('add_option')&&get_option(self::GENERATION_OPTION,null)===null)add_option(self::GENERATION_OPTION,$next,'','no');
        elseif(function_exists('update_option'))update_option(self::GENERATION_OPTION,$next,false);
        self::$generation=$next;
    }

    public static function append_current_page_structure(string $content):string{
        if(function_exists('is_admin')&&is_admin())return $content;
        if(self::target_sync_in_progress()&&!self::target_active())return $content;
        if(function_exists('is_singular')&&!is_singular('page'))return $content;
        $page_id=function_exists('get_queried_object_id')?(int)get_queried_object_id():(function_exists('get_the_ID')?(int)get_the_ID():0);
        if($page_id<1)return $content;
        $html='';$hub=function_exists('get_post_meta')?(string)get_post_meta($page_id,'_apkw_portal_hub',true):'';
        if(in_array($hub,['content','magazine','marketplace'],true))$html.=self::render_portal_hub($page_id,$hub);
        else $html.=self::render_page_structure($page_id);
        if(function_exists('is_front_page')&&is_front_page())$html.=self::render_front_hub_links();
        return $html===''?$content:$content.$html;
    }

    public static function render_page_structure(int $page_id):string{
        if(self::target_sync_in_progress()&&!self::target_active())return '';
        if($page_id<1||!function_exists('get_post'))return '';$page=get_post($page_id);
        if(!$page||(string)($page->post_type??'')!=='page'||(string)($page->post_status??'')!=='publish')return '';
        $node='';$idx=[];
        if(self::target_active()){
            $node=function_exists('get_post_meta')?(string)get_post_meta($page_id,'_apkw_target_node_id',true):'';
            $items=$node!==''?self::target_children_items($node):[];
            $idx=self::target_node_index_snapshot();
        }else{
            $items=self::page_items($page_id);foreach(self::taxonomy_items_for_page($page_id) as $item)$items[]=$item;
        }
        $seen=[];$clean=[];foreach($items as $item){$url=(string)($item['url']??'');$label=trim((string)($item['label']??''));
            if($url===''||$label===''||isset($seen[$url]))continue;
            if(($item['type']??'')==='page'&&(int)($item['object_id']??0)===$page_id)continue;
            $seen[$url]=true;$clean[]=$item;
        }
        $n=$idx[$node]??[];$core=(string)($n['pillar']??'')==='core';
        $isArea=$core&&(str_starts_with($node,'core:area:')||str_starts_with($node,'core:c22:area:'));
        $hasTopics=$isArea&&self::c22_topic_area($node,(array)(self::target_snapshot()['nodes']??[]));
        $isTerminal=$core&&(str_starts_with($node,'core:subarea:')||str_starts_with($node,'core:c22:topic:'));
        $label=$isTerminal?'Artikelkategorien – letzte Kategorieebene':($isArea?'Konkrete Themen':'Schutzbereiche');
        $out='';
        if($clean){$out='<nav class="apkw-structure-nav" data-apkw-contract="'.self::esc_attr(self::CONTRACT).'" aria-label="'.self::esc_attr($label).'"><h2>'.self::esc_html($label).'</h2><ul>';
            foreach($clean as $item)$out.='<li class="apkw-structure-item apkw-structure-'.self::esc_attr((string)$item['type']).'"><a href="'.self::esc_url((string)$item['url']).'">'.self::esc_html((string)$item['label']).'</a></li>';
            $out.='</ul></nav>';
        }
        if($hasTopics){
            // Preserve every old page and permalink, but stop presenting a
            // legacy aggregation as an additional canonical level.
            $old=[];
            $snapshot=self::target_snapshot();$map=(array)($snapshot['mapping']??[]);
            foreach(self::c22_primary_rows($node,(array)($snapshot['nodes']??[]),true) as $legacy){
                $lid=(string)($legacy['node_id']??'');if(!str_starts_with($lid,'core:subarea:'))continue;
                $m=$map[$lid]??null;if(!is_array($m))continue;
                $item=self::target_item_from_mapping($legacy,$m);
                if(!$item||(int)$item['object_id']===$page_id)continue;
                $old[]=$item;
            }
            if($old){$out.='<details class="apkw-legacy-archive"><summary>Bisherige Sammelseiten (Archiv)</summary><ul>';
                foreach($old as $item)$out.='<li><a href="'.self::esc_url((string)$item['url']).'">'.self::esc_html((string)$item['label']).'</a></li>';
                $out.='</ul></details>';
            }
        }
        return $out;
    }

    public static function readback_page(int $page_id):array{
        $errors=[];
        if(self::target_active()){
            $s=self::target_snapshot();$map=(array)($s['mapping']??[]);
            $node=function_exists('get_post_meta')?(string)get_post_meta($page_id,'_apkw_target_node_id',true):'';
            if($node==='')$errors[]='PAGE_TARGET_BINDING_MISSING';
            elseif((int)($map[$node]['object_id']??0)!==$page_id)$errors[]='PAGE_TARGET_MAPPING_MISMATCH';
        }
        $html=self::render_page_structure($page_id);$expected=self::expected_items($page_id);$missing=[];
        foreach($expected as $item){$label=self::esc_html((string)$item['label']);$url=self::esc_url((string)$item['url']);if(strpos($html,'>'.$label.'</a>')===false||strpos($html,'href="'.$url.'"')===false)$missing[]=$item;}
        return ['valid'=>!$errors&&!$missing,'page_id'=>$page_id,'expected'=>$expected,'missing'=>$missing,'errors'=>$errors,'html'=>$html];
    }

    public static function render_portal_hub(int $page_id,string $block):string{
        if(self::target_sync_in_progress()&&!self::target_active())return '';
        if($page_id<1||!in_array($block,['content','magazine','marketplace'],true))return '';$items=self::portal_hub_items($block);if(!$items)return '';
        $title=self::portal_block_label($block);$out='<nav class="apkw-portal-hub apkw-portal-hub-'.self::esc_attr($block).'" data-apkw-contract="'.self::esc_attr(self::CONTRACT).'" aria-label="'.self::esc_attr($title).'">';
        if($block==='magazine'){
            $groups=self::magazine_groups();uasort($groups,static fn($a,$b)=>((int)($a['order']??0)<=> (int)($b['order']??0)) ?: strcmp((string)($a['label']??''),(string)($b['label']??'')));
            foreach($groups as $key=>$spec){
                $subset=array_values(array_filter($items,static fn($i)=>(string)($i['menu_group']??'')===(string)$key));if(!$subset)continue;
                $out.='<section class="apkw-magazine-menu-group apkw-magazine-menu-'.self::esc_attr((string)$key).'" data-apkw-magazine-menu-group="'.self::esc_attr((string)$key).'"><h2>'.self::esc_html((string)($spec['label']??$key)).'</h2><ul>';
                foreach($subset as $item)$out.='<li><a href="'.self::esc_url((string)$item['url']).'">'.self::esc_html((string)$item['label']).'</a></li>';
                $out.='</ul></section>';
            }
            return $out.'</nav>';
        }
        $out.='<ul>';foreach($items as $item)$out.='<li><a href="'.self::esc_url((string)$item['url']).'">'.self::esc_html((string)$item['label']).'</a></li>';
        return $out.'</ul></nav>';
    }

    public static function readback_portal_hub(int $page_id,string $block):array{
        $items=self::portal_hub_items($block);$html=self::render_portal_hub($page_id,$block);$missing=[];
        foreach($items as $item){$label=self::esc_html((string)$item['label']);$url=self::esc_url((string)$item['url']);if(strpos($html,'>'.$label.'</a>')===false||strpos($html,'href="'.$url.'"')===false)$missing[]=$item;}
        $valid=!$missing&&count($items)>0;$menu=null;if($block==='magazine'){$menu=self::readback_magazine_menu($page_id);$valid=$valid&&!empty($menu['valid']);}
        return ['valid'=>$valid,'page_id'=>$page_id,'block'=>$block,'expected_count'=>count($items),'missing'=>$missing,'magazine_menu'=>$menu,'html'=>$html];
    }

    public static function readback_magazine_menu(int $page_id):array{
        $items=self::portal_hub_items('magazine');$html=self::render_portal_hub($page_id,'magazine');$defs=self::magazine_groups();$present=[];$ungrouped=[];$missing_groups=[];
        foreach($items as $item){$key=(string)($item['menu_group']??'');if($key===''||!isset($defs[$key])){$ungrouped[]=$item;continue;}$present[$key]=1+(int)($present[$key]??0);}
        foreach($present as $key=>$count){$label=self::esc_html((string)($defs[$key]['label']??$key));if(strpos($html,'data-apkw-magazine-menu-group="'.self::esc_attr((string)$key).'"')===false||strpos($html,'<h2>'.$label.'</h2>')===false)$missing_groups[]=$key;}
        return ['valid'=>count($items)>0&&!$ungrouped&&!$missing_groups,'page_id'=>$page_id,'present_groups'=>$present,'ungrouped'=>$ungrouped,'missing_groups'=>$missing_groups,'html'=>$html];
    }

    public static function readback_auxiliary_hub(int $page_id,string $block):array{
        $spec=null;
        if(self::target_active()){
            $role=$block;$s=self::target_snapshot();foreach((array)($s['nodes']??[]) as $n){if(!is_array($n)||(string)($n['object_type']??'')!=='page'||(string)($n['hub_role']??'')!==$role)continue;$spec=['slug'=>(string)($n['slug']??''),'title'=>(string)($n['display_name']??'')];break;}
        }else $spec=APKW_PortalStructure::hub_specs()[$block]??null;
        if(!is_array($spec)||$page_id<1||!function_exists('get_post'))return ['valid'=>false,'block'=>$block,'page_id'=>$page_id];
        $p=get_post($page_id);$valid=is_object($p)&&(string)($p->post_type??'')==='page'&&(string)($p->post_status??'')==='publish'&&(string)($p->post_name??'')===(string)$spec['slug'];
        if($valid&&function_exists('get_post_meta'))$valid=(string)get_post_meta($page_id,'_apkw_portal_hub',true)===$block;
        return ['valid'=>$valid,'block'=>$block,'page_id'=>$page_id,'slug'=>$spec['slug']];
    }

    public static function render_front_hub_links():string{
        if(self::target_sync_in_progress()&&!self::target_active())return '';
        $items=self::front_hub_items();if(!$items)return '';$out='<nav class="apkw-portal-entry" data-apkw-contract="'.self::esc_attr(self::CONTRACT).'" aria-label="Portal-Bereiche"><ul>';
        foreach($items as $item)$out.='<li><a href="'.self::esc_url((string)$item['url']).'">'.self::esc_html((string)$item['label']).'</a></li>';
        return $out.'</ul></nav>';
    }

    public static function readback_front_hub_links():array{
        $items=self::front_hub_items();$html=self::render_front_hub_links();$missing=[];
        foreach($items as $item){$label=self::esc_html((string)$item['label']);$url=self::esc_url((string)$item['url']);if(strpos($html,'>'.$label.'</a>')===false||strpos($html,'href="'.$url.'"')===false)$missing[]=$item;}
        $expected=self::front_blocks();$present=array_values(array_unique(array_map(static fn($i)=>(string)$i['block'],$items)));
        return ['valid'=>!$missing&&!array_diff($expected,$present),'expected_blocks'=>$expected,'present_blocks'=>$present,'missing'=>$missing,'html'=>$html];
    }

    public static function footer_entries():array{
        $all=[];foreach(self::all_hub_items() as $item)$all[(string)$item['block']]=$item;$out=[];
        foreach(self::footer_blocks() as $block)if(isset($all[$block]))$out[]=$all[$block];
        if(function_exists('apply_filters'))$out=(array)apply_filters('apkw_footer_entries',$out);
        return $out;
    }

    public static function render_footer_entries():string{
        if(self::target_sync_in_progress()&&!self::target_active())return '';
        $items=self::footer_entries();if(!$items)return '';$out='<nav class="apkw-footer-entries" data-apkw-contract="'.self::esc_attr(self::target_active()?APKW_TargetTree::CONTRACT:APKW_PortalStructure::CONTRACT).'" aria-label="Weitere Bereiche"><ul>';
        foreach($items as $item)$out.='<li class="apkw-footer-entry apkw-footer-entry-'.self::esc_attr((string)$item['block']).'"><a href="'.self::esc_url((string)$item['url']).'">'.self::esc_html((string)$item['label']).'</a></li>';
        return $out.'</ul></nav>';
    }

    public static function footer_shortcode($atts=[]):string{return self::render_footer_entries();}

    public static function readback_footer_entries():array{
        $items=self::footer_entries();$html=self::render_footer_entries();$present=array_values(array_unique(array_map(static fn($i)=>(string)$i['block'],$items)));$expected=self::footer_blocks();$missing=[];
        foreach($items as $item){$label=self::esc_html((string)$item['label']);$url=self::esc_url((string)$item['url']);if(strpos($html,'>'.$label.'</a>')===false||strpos($html,'href="'.$url.'"')===false)$missing[]=$item;}
        return ['valid'=>!$missing&&!array_diff($expected,$present),'expected_blocks'=>$expected,'present_blocks'=>$present,'missing'=>$missing,'html'=>$html];
    }

    private static function portal_hub_items(string $block):array{
        if(self::target_active())return self::target_portal_hub_items($block);
        return self::remember('portal-hub-'.$block,static function()use($block):array{
            $out=[];
            if($block==='content'){
                if(!function_exists('get_posts'))return [];
                $rows=get_posts(['post_type'=>'page','post_status'=>['publish'],'posts_per_page'=>16,'no_found_rows'=>true,'orderby'=>'title','order'=>'ASC','suppress_filters'=>true,'update_post_term_cache'=>false,'meta_query'=>[['key'=>'_apkw_portal_block','value'=>'content'],['key'=>'_apkw_portal_root','value'=>'1']]]);
                foreach((array)$rows as $p){if(!is_object($p)||empty($p->ID))continue;$url=function_exists('get_permalink')?(string)get_permalink($p):'';$label=trim((string)($p->post_title??''));if($url!==''&&$label!=='')$out[]=['block'=>$block,'type'=>'page','object_id'=>(int)$p->ID,'label'=>$label,'url'=>$url];}
            }else{
                if(!function_exists('get_terms'))return [];$tax=$block==='magazine'?'journal_cat':'hp_listing_category';
                $terms=get_terms(['taxonomy'=>$tax,'hide_empty'=>false,'parent'=>0,'number'=>500,'orderby'=>'name','order'=>'ASC','meta_query'=>[['key'=>'_apkw_portal_block','value'=>$block],['key'=>'_apkw_portal_root','value'=>'1']]]);if(function_exists('is_wp_error')&&is_wp_error($terms))return [];
                foreach((array)$terms as $t){if(!is_object($t)||empty($t->term_id))continue;$url=function_exists('get_term_link')?get_term_link((int)$t->term_id,$tax):'';if(function_exists('is_wp_error')&&is_wp_error($url))continue;$label=self::term_name($t);if((string)$url===''||$label==='')continue;$item=['block'=>$block,'type'=>'taxonomy','taxonomy'=>$tax,'object_id'=>(int)$t->term_id,'label'=>$label,'url'=>(string)$url];if($block==='magazine'&&function_exists('get_term_meta')){$item['menu_group']=(string)get_term_meta((int)$t->term_id,'_apkw_magazine_menu_group',true);$item['menu_group_label']=(string)get_term_meta((int)$t->term_id,'_apkw_magazine_menu_label',true);$item['menu_group_order']=(int)get_term_meta((int)$t->term_id,'_apkw_magazine_menu_order',true);} $out[]=$item;}
                if($block==='magazine')usort($out,static fn($a,$b)=>((int)($a['menu_group_order']??999)<=> (int)($b['menu_group_order']??999)) ?: strcmp((string)($a['label']??''),(string)($b['label']??'')));
            }
            return $out;
        });
    }

    private static function all_hub_items():array{
        if(self::target_active())return self::target_all_hub_items();
        return self::remember('all-hubs',static function():array{
            if(!function_exists('get_posts'))return [];$specs=APKW_PortalStructure::hub_specs();$blocks=array_keys($specs);
            $rows=get_posts(['post_type'=>'page','post_status'=>['publish'],'posts_per_page'=>count($blocks)+4,'no_found_rows'=>true,'suppress_filters'=>true,'update_post_term_cache'=>false,'meta_query'=>[['key'=>'_apkw_portal_hub','value'=>$blocks,'compare'=>'IN']]]);$out=[];
            foreach((array)$rows as $p){if(!is_object($p)||empty($p->ID))continue;$block=function_exists('get_post_meta')?(string)get_post_meta((int)$p->ID,'_apkw_portal_hub',true):'';if(!isset($specs[$block]))continue;$url=function_exists('get_permalink')?(string)get_permalink($p):'';if($url!=='')$out[]=['block'=>$block,'object_id'=>(int)$p->ID,'label'=>(string)$specs[$block]['title'],'url'=>$url];}
            return $out;
        });
    }

    private static function front_hub_items():array{
        $allowed=array_flip(self::front_blocks());$out=[];foreach(self::all_hub_items() as $item)if(isset($allowed[(string)$item['block']]))$out[]=$item;
        usort($out,static fn($a,$b)=>strcmp((string)$a['block'],(string)$b['block']));return $out;
    }

    private static function expected_items(int $page_id):array{if(self::target_active()){$node=function_exists('get_post_meta')?(string)get_post_meta($page_id,'_apkw_target_node_id',true):'';return $node!==''?self::target_children_items($node):[];}$items=self::page_items($page_id);foreach(self::taxonomy_items_for_page($page_id) as $item)$items[]=$item;return $items;}

    private static function page_items(int $page_id):array{
        return self::remember('page-children-'.$page_id,static function()use($page_id):array{
            if(!function_exists('get_posts'))return [];$rows=get_posts(['post_type'=>'page','post_parent'=>$page_id,'post_status'=>['publish'],'posts_per_page'=>500,'no_found_rows'=>true,'orderby'=>'title','order'=>'ASC','suppress_filters'=>true,'update_post_meta_cache'=>false,'update_post_term_cache'=>false]);$out=[];
            foreach((array)$rows as $p){if(!is_object($p)||empty($p->ID))continue;$url=function_exists('get_permalink')?(string)get_permalink($p):'';$label=trim((string)($p->post_title??''));if($url!==''&&$label!=='')$out[]=['type'=>'page','object_id'=>(int)$p->ID,'label'=>$label,'url'=>$url];}
            return $out;
        });
    }

    private static function taxonomy_items_for_page(int $page_id):array{
        if(!function_exists('get_post_meta')||!function_exists('get_terms'))return [];
        $concept=(string)get_post_meta($page_id,'_apkw_concept_id',true);if($concept==='')return [];
        return self::remember('page-tax-'.$page_id.'-'.substr(hash('sha256',$concept),0,16),static function()use($page_id,$concept):array{
            $page=function_exists('get_post')?get_post($page_id):null;$page_title=is_object($page)?trim((string)($page->post_title??'')):'';
            $terms=get_terms(['taxonomy'=>'category','hide_empty'=>false,'parent'=>0,'number'=>500,'orderby'=>'name','order'=>'ASC','meta_query'=>[['key'=>'_apkw_parent_concept_id','value'=>$concept],['key'=>'_apkw_portal_block','value'=>'content']]]);if(function_exists('is_wp_error')&&is_wp_error($terms))return [];$out=[];
            foreach((array)$terms as $term){
                if(!is_object($term)||empty($term->term_id))continue;
                $tid=(int)$term->term_id;
                // Keep an explicit fail-safe beside the DB meta_query. This prevents
                // foreign/filter-altered root terms from leaking into another category page.
                if(function_exists('get_term_meta')){
                    if((string)get_term_meta($tid,'_apkw_parent_concept_id',true)!==$concept)continue;
                    $block=(string)get_term_meta($tid,'_apkw_portal_block',true);if($block!==''&&$block!=='content')continue;
                }
                $url=function_exists('get_term_link')?get_term_link($tid,'category'):'';if(function_exists('is_wp_error')&&is_wp_error($url))continue;
                $label=self::display_term_name($term,$page_title);if($label!==''&&(string)$url!=='')$out[]=['type'=>'taxonomy','taxonomy'=>'category','object_id'=>$tid,'label'=>$label,'url'=>(string)$url];
            }
            return $out;
        });
    }

    public static function with_target_snapshot(array $snapshot,callable $callback){
        $previous=self::$target_snapshot_override;self::$target_snapshot_override=$snapshot;
        try{return $callback();}finally{self::$target_snapshot_override=$previous;}
    }

    private static function target_active():bool{
        if(is_array(self::$target_snapshot_override))return !empty(self::$target_snapshot_override['revision'])&&!empty(self::$target_snapshot_override['nodes'])&&!empty(self::$target_snapshot_override['mapping']);
        if(!class_exists('APKW_TargetTreeSync'))return false;$rev=APKW_TargetTreeSync::active_revision();if($rev==='')return false;$s=APKW_TargetTreeSync::active_snapshot();return is_array($s)&&($s['revision']??'')===$rev&&!empty($s['nodes'])&&!empty($s['mapping']);
    }
    private static function target_sync_in_progress():bool{
        if(!class_exists('APKW_TargetTreeSync'))return false;$s=APKW_TargetTreeSync::state();return is_array($s)&&in_array((string)($s['status']??''),['WRITING','READBACK','ROLLBACK_PENDING'],true);
    }
    private static function target_snapshot():array{if(is_array(self::$target_snapshot_override))return self::$target_snapshot_override;return self::target_active()?APKW_TargetTreeSync::active_snapshot():[];}
    private static function target_children_items(string $parent):array{
        $s=self::target_snapshot();$nodes=(array)($s['nodes']??[]);$map=(array)($s['mapping']??[]);$out=[];
        foreach(self::c22_primary_rows($parent,$nodes) as $n){
            $type=(string)($n['object_type']??'');
            if($type==='relation'){$target=(string)($n['target_node_id']??'');$tm=$map[$target]??null;if(!is_array($tm))continue;$item=self::target_item_from_mapping($n,$tm);if($item)$out[]=$item;continue;}
            $m=$map[(string)($n['node_id']??'')]??null;if(!is_array($m))continue;$item=self::target_item_from_mapping($n,$m);if($item)$out[]=$item;
        }
        usort($out,static fn($a,$b)=>((int)($a['order']??999)<=> (int)($b['order']??999))?:strcmp((string)$a['label'],(string)$b['label']));return $out;
    }
    private static function target_item_from_mapping(array $n,array $m):?array{
        $type=(string)($m['object_type']??$n['object_type']??'');$id=(int)($m['object_id']??0);if($id<1)return null;$label=(string)($n['display_name']??'');$url='';$item=['block'=>APKW_TargetTree::managed_block((string)($n['pillar']??'')),'type'=>$type==='page'?'page':'taxonomy','object_id'=>$id,'label'=>$label,'order'=>(int)($n['menu_group_order']??999)];
        if($type==='page' && str_starts_with((string)($n['node_id']??''),'core:c22:topic:') && function_exists('get_post_meta')
            && (string)get_post_meta($id,'_apkw_target_node_id',true)!==(string)$n['node_id'])return null;
        if($type==='page')$url=function_exists('get_permalink')?(string)get_permalink($id):'';else{$item['taxonomy']=$type;$u=function_exists('get_term_link')?get_term_link($id,$type):'';if(function_exists('is_wp_error')&&is_wp_error($u))$u='';$url=(string)$u;}$item['url']=$url;if($url==='')return null;if((string)($n['pillar']??'')==='editorial'){
            $group=(string)($n['menu_group']??'');
            // Direct magazine tiles are canonical members of the single start group
            // even when the profile keeps them as pages without redundant group meta.
            if($group===''&&(string)($n['parent_id']??'')==='editorial:hub')$group='main';
            $defs=self::magazine_groups();$def=is_array($defs[$group]??null)?$defs[$group]:[];
            $item['menu_group']=$group;$item['menu_group_label']=(string)($n['menu_group_label']??$def['label']??'');$item['menu_group_order']=(int)($n['menu_group_order']??$def['order']??0);
        }return $item;
    }
    private static function target_portal_hub_items(string $block):array{
        $s=self::target_snapshot();$nodes=(array)($s['nodes']??[]);$hub='';$role=['content'=>'content','magazine'=>'magazine','marketplace'=>'marketplace'][$block]??'';foreach($nodes as $n)if(is_array($n)&&(string)($n['hub_role']??'')===$role){$hub=(string)$n['node_id'];break;}return $hub!==''?self::target_children_items($hub):[];
    }
    private static function portal_block_label(string $block):string{
        if(self::target_active()){$s=self::target_snapshot();$pillar=['content'=>'core','magazine'=>'editorial','marketplace'=>'directory'][$block]??'';$label=$pillar!==''?(string)($s['pillars'][$pillar]['label']??''):'';if($label!=='')return $label;}
        return $block==='content'?'Themenübersicht':($block==='magazine'?'Magazin':($block==='marketplace'?'Anbieter':ucfirst($block)));
    }
    private static function target_all_hub_items():array{
        $s=self::target_snapshot();$map=(array)($s['mapping']??[]);$out=[];foreach((array)($s['nodes']??[]) as $n){if(!is_array($n)||empty($n['hub_role'])||(string)($n['object_type']??'')!=='page')continue;$id=(string)($n['node_id']??'');$m=$map[$id]??null;if(!is_array($m))continue;$item=self::target_item_from_mapping($n,$m);if(!$item)continue;$item['block']=APKW_TargetTree::managed_block((string)$n['pillar']);$out[]=$item;}return $out;
    }
    private static function magazine_groups():array{if(self::target_active()){$s=self::target_snapshot();$g=$s['pillars']['editorial']['menu_groups']??[];return is_array($g)?$g:[];}return APKW_PortalStructure::magazine_menu_groups();}
    private static function footer_blocks():array{if(self::target_active()){$s=self::target_snapshot();$p=(array)($s['project']['footer_pillars']??[]);$map=['core'=>'content','editorial'=>'magazine','directory'=>'marketplace'];return array_values(array_filter(array_map(static fn($x)=>$map[(string)$x]??'', $p)));}return APKW_PortalStructure::footer_blocks();}
    private static function front_blocks():array{if(self::target_active()){$s=self::target_snapshot();$p=(array)($s['project']['front_pillars']??[]);$map=['core'=>'content','editorial'=>'magazine','directory'=>'marketplace'];return array_values(array_filter(array_map(static fn($x)=>$map[(string)$x]??'', $p)));}return APKW_PortalStructure::front_blocks();}

    private static function remember(string $scope,callable $builder):array{
        $snapshot=self::$target_snapshot_override;$salt=is_array($snapshot)?substr(hash('sha256',(string)($snapshot['revision']??'').'|'.count((array)($snapshot['mapping']??[]))),0,12):'active';
        $key='g'.self::generation().'-'.$salt.'-'.substr(hash('sha256',$scope),0,24);$found=false;$cached=false;
        if(function_exists('wp_cache_get'))$cached=wp_cache_get($key,self::CACHE_GROUP,false,$found);
        if($found&&is_array($cached))return $cached;$value=(array)$builder();if(function_exists('wp_cache_set'))wp_cache_set($key,$value,self::CACHE_GROUP,300);return $value;
    }

    private static function generation():int{
        if(self::$generation!==null)return self::$generation;$g=function_exists('get_option')?(int)get_option(self::GENERATION_OPTION,1):1;self::$generation=max(1,$g);return self::$generation;
    }

    private static function display_term_name($term,string $page_title):string{$name=self::term_name($term);if($name===''||$page_title==='')return $name;$suffix=' '.$page_title;if(strlen($name)>strlen($suffix)&&substr($name,-strlen($suffix))===$suffix)return trim(substr($name,0,-strlen($suffix)));return $name;}
    private static function term_name($term):string{$name=(string)($term->name??'');return function_exists('wp_specialchars_decode')?wp_specialchars_decode($name,ENT_NOQUOTES):html_entity_decode($name,ENT_NOQUOTES|ENT_HTML5,'UTF-8');}
    private static function esc_html(string $s):string{return function_exists('esc_html')?esc_html($s):htmlspecialchars($s,ENT_QUOTES|ENT_HTML5,'UTF-8');}
    private static function esc_attr(string $s):string{return function_exists('esc_attr')?esc_attr($s):htmlspecialchars($s,ENT_QUOTES|ENT_HTML5,'UTF-8');}
    private static function esc_url(string $s):string{return function_exists('esc_url')?esc_url($s):htmlspecialchars($s,ENT_QUOTES|ENT_HTML5,'UTF-8');}
}
