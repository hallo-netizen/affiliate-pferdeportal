<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Persistent single-workspace store for the guided category workflow.
 * Keeps the current working packages server-side so the user does not have
 * to download and re-upload the same file between every internal stage.
 * Stored options are non-autoloaded and compressed; credentials are never stored here.
 */
final class APKW_Workspace {
    private const OPT_META = 'apkw_workspace_meta_v1';
    private const OPT_CONNECTION = 'apkw_connection_state_v1';
    private const PKG_PREFIX = 'apkw_workspace_pkg_v1_';
    private const MAX_COMPRESSED_BYTES = 33554432; // 32 MB per saved package, fail closed.
    private const SLOTS = ['portal_profile','portal_discovery','concept','draft','global','research','structure','final','deploy_plan'];

    public static function meta(): array {
        $v = get_option(self::OPT_META, []);
        return is_array($v) ? $v : [];
    }

    public static function stage(): string {
        return (string) (self::meta()['stage'] ?? 'EMPTY');
    }

    public static function set_stage(string $stage, array $extra = []): void {
        $meta = self::meta();
        $meta['stage'] = sanitize_key($stage);
        $meta['updated_at_utc'] = gmdate('c');
        foreach ($extra as $k => $v) {
            $meta[sanitize_key((string)$k)] = is_scalar($v) || $v === null ? $v : $v;
        }
        update_option(self::OPT_META, $meta, false);
    }

    public static function save_package(string $slot, array $package): array {
        self::assert_slot($slot);
        $json = wp_json_encode($package, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) throw new RuntimeException('Arbeitsstand konnte nicht serialisiert werden.');
        if (!function_exists('gzencode')) throw new RuntimeException('PHP-Zlib fehlt: Arbeitsstand kann nicht gespeichert werden.');
        $gz = gzencode($json, 6);
        if (!is_string($gz)) throw new RuntimeException('Arbeitsstand konnte nicht komprimiert werden.');
        if (strlen($gz) > self::MAX_COMPRESSED_BYTES) throw new RuntimeException('Arbeitsstand ist für die serverseitige Zwischenspeicherung zu groß.');
        $record = [
            'encoding' => 'gzip+base64',
            'payload' => base64_encode($gz),
            'sha256' => hash('sha256', $json),
            'raw_bytes' => strlen($json),
            'compressed_bytes' => strlen($gz),
            'package_id' => (string)($package['package_id'] ?? ''),
            'mode' => (string)($package['mode'] ?? ''),
            'stored_at_utc' => gmdate('c'),
        ];
        update_option(self::PKG_PREFIX . $slot, $record, false);
        $meta = self::meta();
        $meta['slots'] = is_array($meta['slots'] ?? null) ? $meta['slots'] : [];
        $meta['slots'][$slot] = [
            'sha256' => $record['sha256'],
            'package_id' => $record['package_id'],
            'mode' => $record['mode'],
            'stored_at_utc' => $record['stored_at_utc'],
        ];
        if (is_array($package['project'] ?? null)) {
            $meta['project_name'] = (string)($package['project']['name'] ?? ($meta['project_name'] ?? ''));
            $meta['project_id'] = (string)($package['project']['project_id'] ?? ($meta['project_id'] ?? ''));
        }
        $meta['updated_at_utc'] = gmdate('c');
        update_option(self::OPT_META, $meta, false);
        return $record;
    }

    public static function load_package(string $slot): ?array {
        self::assert_slot($slot);
        $record = get_option(self::PKG_PREFIX . $slot, null);
        if (!is_array($record) || ($record['encoding'] ?? '') !== 'gzip+base64') return null;
        $payload = base64_decode((string)($record['payload'] ?? ''), true);
        if (!is_string($payload) || $payload === '') throw new RuntimeException('Gespeicherter Arbeitsstand ist beschädigt.');
        if (!function_exists('gzdecode')) throw new RuntimeException('PHP-Zlib fehlt: Arbeitsstand kann nicht gelesen werden.');
        $json = gzdecode($payload);
        if (!is_string($json)) throw new RuntimeException('Gespeicherter Arbeitsstand konnte nicht dekomprimiert werden.');
        if (!hash_equals((string)($record['sha256'] ?? ''), hash('sha256', $json))) throw new RuntimeException('Gespeicherter Arbeitsstand hat die Integritätsprüfung nicht bestanden.');
        $data = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($data)) throw new RuntimeException('Gespeicherter Arbeitsstand ist kein gültiges JSON-Objekt.');
        return $data;
    }

    public static function has_package(string $slot): bool {
        self::assert_slot($slot);
        return is_array(get_option(self::PKG_PREFIX . $slot, null));
    }

    public static function delete_package(string $slot): void {
        self::assert_slot($slot);
        delete_option(self::PKG_PREFIX . $slot);
        $meta = self::meta();
        if (isset($meta['slots'][$slot])) unset($meta['slots'][$slot]);
        $meta['updated_at_utc'] = gmdate('c');
        update_option(self::OPT_META, $meta, false);
    }

    public static function clear(): void {
        foreach (self::SLOTS as $slot) delete_option(self::PKG_PREFIX . $slot);
        delete_option(self::OPT_META);
    }

    public static function mark_connection_pass(float $cost_usd = 0.0): void {
        update_option(self::OPT_CONNECTION, [
            'status' => 'PASS',
            'fingerprint' => self::connection_fingerprint(),
            'checked_at_utc' => gmdate('c'),
            'cost_usd' => $cost_usd,
        ], false);
    }

    public static function invalidate_connection(): void {
        delete_option(self::OPT_CONNECTION);
    }

    public static function connection_status(): array {
        $record = get_option(self::OPT_CONNECTION, null);
        if (!is_array($record) || ($record['status'] ?? '') !== 'PASS') return ['valid' => false, 'status' => 'NOT_TESTED'];
        $fingerprint = (string)($record['fingerprint'] ?? '');
        if ($fingerprint === '' || !hash_equals($fingerprint, self::connection_fingerprint())) return ['valid' => false, 'status' => 'SETTINGS_CHANGED'];
        return ['valid' => true, 'status' => 'PASS', 'checked_at_utc' => (string)($record['checked_at_utc'] ?? ''), 'cost_usd' => (float)($record['cost_usd'] ?? 0.0)];
    }


    public static function assert_stage($allowed): void {
        $allowed = is_array($allowed) ? array_values(array_map('strval', $allowed)) : [(string)$allowed];
        $current = self::stage();
        if (!in_array($current, $allowed, true)) {
            throw new RuntimeException('Dieser Schritt gehört nicht zum aktuellen Arbeitsstand. Erwartet: ' . implode(' oder ', $allowed) . '; aktuell: ' . $current . '.');
        }
    }

    public static function assert_upstream_replace_allowed(): void {
        if (self::stage() === 'deployed') {
            throw new RuntimeException('Aktiver Deployment-Run vorhanden. Vor einem neuen oder korrigierten Arbeitsstand muss dieser Run zuerst vollständig zurückgerollt werden.');
        }
    }

    public static function invalidate_downstream(string $slot): void {
        $order = ['concept','draft','global','research','structure','final','deploy_plan'];
        $idx = array_search($slot, $order, true);
        if ($idx === false) throw new InvalidArgumentException('Unbekannter Workspace-Slot: ' . $slot);
        for ($i = $idx + 1; $i < count($order); $i++) self::delete_package($order[$i]);
        $meta = self::meta();
        unset($meta['deploy_run_id'], $meta['baseline_version']);
        $meta['updated_at_utc'] = gmdate('c');
        update_option(self::OPT_META, $meta, false);
    }
    public static function connection_fingerprint(): string {
        $c = APKW_Settings::credentials();
        $d = APKW_Settings::defaults();
        return hash('sha256', implode("\0", [
            (string)($c['login'] ?? ''),
            (string)($c['password'] ?? ''),
            (string)($d['location_name'] ?? ''),
            (string)($d['language_code'] ?? ''),
        ]));
    }

    private static function assert_slot(string $slot): void {
        if (!in_array($slot, self::SLOTS, true)) throw new InvalidArgumentException('Unbekannter Workspace-Slot: ' . $slot);
    }
}
