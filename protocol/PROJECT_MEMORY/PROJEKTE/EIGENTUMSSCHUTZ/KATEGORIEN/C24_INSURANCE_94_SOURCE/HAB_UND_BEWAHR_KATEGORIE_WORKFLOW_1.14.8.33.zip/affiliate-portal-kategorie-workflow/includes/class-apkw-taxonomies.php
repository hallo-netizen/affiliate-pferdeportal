<?php
if (!defined('ABSPATH')) { exit; }

final class APKW_Taxonomies {
    public const MAGAZINE_TAXONOMY='journal_cat';
    public static function init():void{
        if(function_exists('add_action')) add_action('init',[__CLASS__,'register'],5);
    }
    public static function register():void{
        if(!function_exists('taxonomy_exists')||!function_exists('register_taxonomy'))return;
        if(!taxonomy_exists(self::MAGAZINE_TAXONOMY)){
            register_taxonomy(self::MAGAZINE_TAXONOMY,['post'],[
                'labels'=>['name'=>'Magazin','singular_name'=>'Magazin-Kategorie'],
                'public'=>true,'show_ui'=>true,'show_in_rest'=>true,'hierarchical'=>true,
                'rewrite'=>['slug'=>'magazin'],'show_admin_column'=>true,
            ]);
        }
    }
}
