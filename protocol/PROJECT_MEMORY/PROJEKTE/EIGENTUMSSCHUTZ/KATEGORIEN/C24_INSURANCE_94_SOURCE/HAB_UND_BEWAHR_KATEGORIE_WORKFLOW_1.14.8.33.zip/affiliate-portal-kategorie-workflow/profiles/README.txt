Leere Auslieferung: Keine Portalprofile. Nach Freigabe der Kategorie-/Magazin-/HivePress-Taxonomie das JSON über Portal-Kategorien importieren.
