<?php
if (!defined('ABSPATH')) { exit; }

/** One administrative paid SERP run, stored read-only as evidence. No structural writes. */
final class APKW_SERP_Review {
    private const OPT = 'apkw_hab_serp_20_audit_v1';
    private const LOCK = 'apkw_hab_serp_paid_call_mutex_v1';
    private const PAGE = 'apkw-hab-serp-review';

    public static function init(): void {
        if (!function_exists('add_action')) return;
        add_action('admin_menu', [__CLASS__, 'menu'], 40);
        add_action('admin_post_apkw_hab_serp_start', [__CLASS__, 'start']);
        add_action('wp_ajax_apkw_hab_serp_advance', [__CLASS__, 'advance']);
        add_action('admin_post_apkw_hab_serp_export', [__CLASS__, 'export']);
        add_action('admin_post_apkw_hab_serp_skip_failed', [__CLASS__, 'skip_failed']);
        add_action('admin_post_apkw_hab_serp_recheck_one', [__CLASS__, 'recheck_one']);
    }
    private static function plan(): array {
        $f = APKW_DIR . 'profiles/hab-und-bewahr-serp-review.json';
        $raw = file_get_contents($f);
        $doc = json_decode((string)$raw, true);
        if (!is_array($doc) || (string)($doc['contract']??'')!=='HB_SERP_REVIEW_20_CONFLICTS_V1') {
            throw new RuntimeException('Gebundener SERP-Prüfplan fehlt.');
        }
        $pairs = (array) ($doc['pairs']??[]);
        if (count($pairs)!==20) throw new RuntimeException('Nur der geprüfte 20-Felder-Plan darf ausgeführt werden.');
        $seen=[]; $list=[];
        foreach ($pairs as $i=>$pair) {
            if (!is_array($pair) || count((array)($pair['keywords']??[]))!==2 || trim((string)($pair['conflict_field']??''))==='') {
                throw new RuntimeException('Ungültiger SERP-Prüfplan bei Feld '.($i+1));
            }
            foreach ($pair['keywords'] as $keyword) {
                if (!is_string($keyword) || (function_exists('mb_strlen') ? mb_strlen($keyword,'UTF-8') : strlen($keyword))<3 || (function_exists('mb_strlen') ? mb_strlen($keyword,'UTF-8') : strlen($keyword))>200) {
                    throw new RuntimeException('Ungültiges Prüfkeyword.');
                }
                $key=(function_exists('mb_strtolower') ? mb_strtolower(trim($keyword),'UTF-8') : strtolower(trim($keyword)));
                if (isset($seen[$key])) throw new RuntimeException('Doppeltes Prüfkeyword.');
                $seen[$key]=true; $list[]=$keyword;
            }
        }
        $doc['keywords_flat']=$list;
        $doc['plan_sha256']=hash('sha256', (string)$raw);
        return $doc;
    }
    private static function cap(): void {
        if (!current_user_can('manage_options')) wp_die('Nur Administratoren.','Nicht autorisiert',['response'=>403]);
    }
    public static function menu(): void {
        add_submenu_page(APKW_FinalTargetAdmin::PAGE_SLUG,'DataForSEO SERP-Abgleich','SERP-Abgleich',
            'manage_options', self::PAGE, [__CLASS__,'render']);
    }
    public static function start(): void {
        self::cap(); check_admin_referer('apkw_hab_serp_start');
        if ((string)($_POST['apkw_hab_serp_paid_consent']??'')!=='1') wp_die('Ausdrückliche Kostenfreigabe fehlt.');
        $old=get_option(self::OPT, false);
        if ($old!==false) wp_die('Für diesen Prüfplan ist bereits ein Lauf gespeichert. Keine doppelte kostenpflichtige Abfrage.');
        try {
            $plan=self::plan(); $defaults=APKW_Settings::defaults();
            $credentials=APKW_Settings::credentials();
            if (empty($credentials['login']) || empty($credentials['password'])) throw new RuntimeException('WordPress-DataForSEO-Zugang fehlt.');
            if ((string)$defaults['location_name']!==(string)$plan['location_name'] || (string)$defaults['language_code']!==(string)$plan['language_code']) {
                throw new RuntimeException('DataForSEO-Zielmarkt/Sprache passt nicht zum Profil.');
            }
            $record=[
                'contract'=>'HB_SERP_REVIEW_WP_PAID_ONCE_V1',
                'status'=>'RUNNING', 'created_utc'=>gmdate('c'),
                'plan_hash'=>$plan['plan_sha256'],
                'market'=>$defaults, 'depth'=>10,
                'keywords'=>$plan['keywords_flat'],
                'pairs'=>$plan['pairs'], 'index'=>0,
                'results'=>[], 'known_cost_usd'=>0,
                'errors'=>[], 'profile_revision_at_start'=>self::revision(),
                'writes_to_categories'=>0,
            ];
            if (!add_option(self::OPT,$record,'',false)) throw new RuntimeException('Lauf wurde bereits angelegt.');
            wp_safe_redirect(admin_url('admin.php?page='.self::PAGE)); exit;
        } catch (Throwable $e) { wp_die(esc_html($e->getMessage()),'SERP-Prüfung BLOCKED',['response'=>400]); }
    }
    private static function revision(): string {
        if (!class_exists('APKW_TargetTree')) return '';
        $f=APKW_DIR.'profiles/hab-und-bewahr-target.json';
        $j=json_decode((string)file_get_contents($f),true);
        return (string)($j['project']['revision']??'');
    }
    public static function advance(): void {
        self::cap();
        if (!check_ajax_referer('apkw_hab_serp_advance','_ajax_nonce',false)) {
            wp_send_json_error(['message'=>'Sicherheitsfreigabe abgelaufen.'],403);
        }
        $s=get_option(self::OPT, false);
        if (!is_array($s)) wp_send_json_error(['message'=>'Kein freigegebener Lauf.'],400);
        if ((string)($s['status']??'')==='COMPLETE') wp_send_json_success(self::progress($s));
        if ((string)($s['status']??'')!=='RUNNING') wp_send_json_error(['message'=>'Lauf gestoppt. Kostenstatus prüfen; keine automatische Wiederholung.'],409);
        $plan=self::plan();
        if (!hash_equals((string)$s['plan_hash'], $plan['plan_sha256'])) {
            $s['status']='BLOCKED_PLAN_CHANGED';update_option(self::OPT,$s,false);
            wp_send_json_error(['message'=>'Prüfplan wurde geändert.'],409);
        }
        $i=(int)($s['index']??0);
        if ($i>=count($s['keywords'])) {
            $s['status']='COMPLETE';$s['finished_utc']=gmdate('c');update_option(self::OPT,$s,false);
            wp_send_json_success(self::progress($s));
        }
        // Atomic WordPress option guards against TWO admin tabs charging the same task.
        // On a process crash the lock and IN_FLIGHT intentionally stay fail-closed.
        if (!add_option(self::LOCK, gmdate('c'), '', false)) {
            wp_send_json_error(['message'=>'Eine SERP-Abfrage ist bereits reserviert. Kein zweiter Kostenaufruf.'],409);
        }
        $s=get_option(self::OPT,false); // Re-read inside the mutex; never trust earlier RUNNING snapshot.
        if (!is_array($s)||(string)($s['status']??'')!=='RUNNING'||(int)($s['index']??-1)!==$i) {
            delete_option(self::LOCK);
            wp_send_json_error(['message'=>'SERP-Zustand hat sich geändert. Keine Doppelabrechnung.'],409);
        }
        // Persist reservation BEFORE any chargeable provider call. A timeout is never retried automatically.
        $s['status']='IN_FLIGHT';$s['in_flight_keyword']=$s['keywords'][$i];
        $s['in_flight_since_utc']=gmdate('c');
        update_option(self::OPT,$s,false);
        try {
            $r=APKW_DataForSEO::organic_serp_top10((string)$s['keywords'][$i],
                (string)$s['market']['location_name'],(string)$s['market']['language_code'],
                'hb-serp20-'.substr((string)$s['plan_hash'],0,15).'-'.$i);
            $s['results'][]=$r;
            if (is_numeric($r['cost_usd']??null)) $s['known_cost_usd']+=(float)$r['cost_usd'];
            $s['index']=$i+1;
            unset($s['in_flight_keyword'],$s['in_flight_since_utc']);
            $s['status']=($i+1===count($s['keywords']))?'COMPLETE':'RUNNING';
            if ($s['status']==='COMPLETE')$s['finished_utc']=gmdate('c');
            update_option(self::OPT,$s,false);
        } catch (APKW_SERP_ProviderTaskError $e) {
            // A definitive 40101 has already been processed by the provider (and can be billable).
            // Within the ONE approved 40-keyword plan, save an unmeasured slot and move forward.
            // Never retry the keyword, silently create a replacement paid call, or hide its cost.
            $ev=$e->evidence();
            $s['errors'][]=['keyword'=>$s['keywords'][$i],'error'=>$e->getMessage(),'utc'=>gmdate('c'),'provider'=>$ev];
            if (is_numeric($ev['cost_usd']??null)) $s['known_cost_usd']+=(float)$ev['cost_usd'];
            $confirmedTask = (string)($ev['evidence_scope']??'')==='provider_task' &&
                (string)($ev['task_id']??'')!=='' && is_numeric($ev['cost_usd']??null);
            $confirmedEnvelope = (string)($ev['evidence_scope']??'')==='provider_response' &&
                (int)($ev['http_code']??0)===200;
            if ((int)($ev['task_status_code']??0)===40101 &&
                (string)($ev['keyword']??'')===(string)$s['keywords'][$i] &&
                ($confirmedTask || $confirmedEnvelope)) {
                $s['results'][]=[
                    'keyword'=>(string)$s['keywords'][$i],
                    'task_id'=>(string)$ev['task_id'],
                    'task_status_code'=>40101,
                    'cost_usd'=>is_numeric($ev['cost_usd']??null) ? (float)$ev['cost_usd'] : null,
                    'checked_utc'=>(string)($ev['checked_utc']??gmdate('c')),
                    'organic_top10'=>[], 'organic_returned'=>0,
                    'status'=>'PROVIDER_ERROR_SKIPPED',
                    'note'=>$confirmedTask ? '40101 mit Task-ID und Kosten dokumentiert. Nicht erneut angefragt.' :
                        '40101 auf Provider-Antwortebene (HTTP 200). Task-ID/Kosten ggf. unbekannt; keine automatische Wiederholung.',
                ];
                $s['skipped_keywords'][]=(string)$s['keywords'][$i];
                $s['index']=$i+1;
                unset($s['failed_task'],$s['in_flight_keyword'],$s['in_flight_since_utc']);
                $s['status']=$s['index']===count($s['keywords'])?'COMPLETE':'RUNNING';
                if($s['status']==='COMPLETE')$s['finished_utc']=gmdate('c');
                update_option(self::OPT,$s,false);
            } else {
                // All other provider errors (or incomplete evidence) still stop fail-closed.
                $s['status']='BLOCKED_PROVIDER_TASK';
                $s['failed_task']=$ev;
                update_option(self::OPT,$s,false);
                delete_option(self::LOCK);
                wp_send_json_error(['message'=>'Anbieterfehler dokumentiert; Kostenstatus gespeichert. Keine automatische Wiederholung.'],409);
            }
        } catch (Throwable $e) {
            // Transport/timeout/bad JSON: cost/processing uncertain; never retry automatically.
            $s['status']='BLOCKED_INDETERMINATE_BILLING';
            $s['errors'][]=['keyword'=>$s['keywords'][$i],'error'=>$e->getMessage(),'utc'=>gmdate('c')];
            update_option(self::OPT,$s,false);
            delete_option(self::LOCK);
            wp_send_json_error(['message'=>'Anfrage gesperrt. Kein automatischer neuer Kostenaufruf: '.$e->getMessage()],409);
        }
        delete_option(self::LOCK);
        wp_send_json_success(self::progress($s));
    }
    /** Unknown or failed provider calls may ONLY be skipped manually, with a new explicit consent.
     *  The skipped keyword is NEVER sent to DataForSEO again by this action.
     *  Unknown billing stays unknown and is not counted as a known provider error.
     */
    private static function skippable(array $s): bool {
        $plan=self::plan();
        $i=(int)($s['index']??-1);
        if ($i<0||$i>=count($plan['keywords_flat'])) return false;
        if (!hash_equals((string)($s['plan_hash']??''),$plan['plan_sha256']))return false;
        if (($s['keywords']??[])!==$plan['keywords_flat'])return false;
        if (count((array)($s['results']??[]))!==$i)return false;
        if ((string)($s['in_flight_keyword']??'')!==(string)$s['keywords'][$i])return false;
        $status=(string)($s['status']??'');
        if ($status==='BLOCKED_PROVIDER_TASK') {
            return (int)($s['failed_task']['task_status_code']??0)===40101 &&
                   (string)($s['failed_task']['keyword']??'')===(string)$s['keywords'][$i];
        }
        // 1.14.8.16 wrongly excluded the actually observed
        // "DataForSEO-Fehler: Internal Server Error." at index 34.
        // An unknown failure may be skipped ONLY by an administrator, NEVER
        // retried automatically; require an exact persisted in-flight reservation.
        if ($status==='BLOCKED_INDETERMINATE_BILLING') {
            $errors=(array)($s['errors']??[]);
            $e=$errors ? end($errors) : null;
            return is_array($e) &&
                (string)($e['keyword']??'')===(string)$s['keywords'][$i] &&
                trim((string)($e['error']??''))!=='' &&
                (string)($s['in_flight_since_utc']??'')!=='';
        }
        return false;
    }
    private static function missing_result(array $item): bool {
        return in_array((string)($item['status']??''),
            ['PROVIDER_ERROR_SKIPPED','UNVERIFIED_ERROR_SKIPPED'],true);
    }
    /** Explicit operator consent preserves prior evidence and advances WITHOUT rerunning the failed keyword. */
    public static function skip_failed(): void {
        self::cap(); check_admin_referer('apkw_hab_serp_skip_failed');
        if ((string)($_POST['apkw_hab_serp_paid_consent']??'')!=='1')wp_die('Kostenfreigabe für weitere Suchanfragen fehlt.');
        // Serialize the state change with the paid-call mutex. No provider call here.
        if (!add_option(self::LOCK,gmdate('c'),'',false)) wp_die('SERP-Aktion bereits reserviert. Bitte Seite neu laden.');
        $s=get_option(self::OPT,false);
        if (!is_array($s)||!self::skippable($s)) {
            delete_option(self::LOCK);
            wp_die('Der gesperrte Lauf hat sich geändert. Keine Anfrage erneut ausgeführt.');
        }
        $i=(int)$s['index'];$keyword=(string)$s['keywords'][$i];
        $ev=is_array($s['failed_task']??null)?$s['failed_task']:[];
        $unknown=(string)($s['status']??'')==='BLOCKED_INDETERMINATE_BILLING';
        $lastError=end($s['errors']);
        $s['results'][]=[
            'keyword'=>$keyword,'task_id'=>$unknown?'':(string)($ev['task_id']??''),
            'task_status_code'=>$unknown?null:(isset($ev['task_status_code'])?(int)$ev['task_status_code']:null),
            'cost_usd'=>$unknown?null:($ev['cost_usd']??null),
            'checked_utc'=>$unknown?(string)($lastError['utc']??''):(string)($ev['checked_utc']??''),
            'organic_top10'=>[],'organic_returned'=>0,
            'status'=>$unknown?'UNVERIFIED_ERROR_SKIPPED':'PROVIDER_ERROR_SKIPPED',
            'note'=>$unknown
                ?'Ausdrücklich übersprungen; Anfrage NICHT wiederholt. Ursache/Task-ID/Abrechnung unbekannt; möglicherweise berechnet.'
                :'Anbieterfehler 40101 dokumentiert. Anfrage NICHT wiederholt.',
        ];
        $s['index']=$i+1;
        $s['status']=$s['index']===count($s['keywords'])?'COMPLETE':'RUNNING';
        $s['skipped_keywords'][]=$keyword;
        unset($s['failed_task'],$s['in_flight_keyword'],$s['in_flight_since_utc']);
        update_option(self::OPT,$s,false);
        delete_option(self::LOCK);
        wp_safe_redirect(admin_url('admin.php?page='.self::PAGE));exit;
    }
    /** Optional single manual retry AFTER the remaining run completed, with new explicit billing consent. */
    public static function recheck_one(): void {
        self::cap(); check_admin_referer('apkw_hab_serp_recheck_one');
        if ((string)($_POST['apkw_hab_serp_paid_consent']??'')!=='1')wp_die('Erneute kostenpflichtige Abfrage nicht bestätigt.');
        $s=get_option(self::OPT,false);$plan=self::plan();
        if (!is_array($s)||(string)($s['status']??'')!=='COMPLETE'||
            !hash_equals((string)($s['plan_hash']??''),$plan['plan_sha256'])||
            ($s['keywords']??[])!==$plan['keywords_flat']||
            (int)($s['index']??0)!==count($plan['keywords_flat'])||
            count((array)($s['results']??[]))!==count($plan['keywords_flat']))
            wp_die('Nachholung nur nach abgeschlossenem, unverändertem 40er-Lauf.');
        $slots=[];
        foreach($s['results'] as $i=>$row){if(self::missing_result($row))$slots[]=$i;}
        if (!$slots)wp_die('Keine ausgefallene Anbieterabfrage vorhanden.');
        if (!add_option(self::LOCK,gmdate('c'),'',false))wp_die('Kostenanfrage bereits reserviert. Keine Doppelabrechnung.');
        $fresh=get_option(self::OPT,false);
        if (!is_array($fresh) || (string)($fresh['status']??'')!=='COMPLETE' ||
            (int)($fresh['index']??-1)!==count($plan['keywords_flat']) ||
            !self::missing_result($fresh['results'][$slots[0]])){
            delete_option(self::LOCK);wp_die('SERP-Status geändert. Keine zweite kostenpflichtige Abfrage.');
        }
        $s=$fresh;
        $i=$slots[0];$keyword=$s['keywords'][$i];
        $s['status']='RECHECK_IN_FLIGHT';$s['recheck_index']=$i;$s['recheck_started_utc']=gmdate('c');
        update_option(self::OPT,$s,false); // Persist BEFORE provider call. Never auto-repeat.
        try {
            $r=APKW_DataForSEO::organic_serp_top10($keyword,
                (string)$s['market']['location_name'],(string)$s['market']['language_code'],
                'hb-serp20-manual-'.substr($plan['plan_sha256'],0,15).'-'.$i);
            $s['results'][$i]=$r;
            if(is_numeric($r['cost_usd']??null))$s['known_cost_usd']+=(float)$r['cost_usd'];
            $s['status']='COMPLETE';$s['recheck_finished_utc']=gmdate('c');
            $s['manual_rechecks']=((int)($s['manual_rechecks']??0))+1;
            update_option(self::OPT,$s,false);
            delete_option(self::LOCK);
        } catch (APKW_SERP_ProviderTaskError $e) {
            $ev=$e->evidence();
            if(is_numeric($ev['cost_usd']??null))$s['known_cost_usd']+=(float)$ev['cost_usd'];
            $s['status']='BLOCKED_RECHECK_PROVIDER';$s['recheck_failed_task']=$ev;
            $s['errors'][]=['keyword'=>$keyword,'error'=>$e->getMessage(),'utc'=>gmdate('c'),'provider'=>$ev];
            update_option(self::OPT,$s,false);
            delete_option(self::LOCK);
            wp_die('Erneute Anbieterantwort fehlgeschlagen. Keine weitere automatische Abfrage.');
        } catch(Throwable $e) {
            $s['status']='BLOCKED_RECHECK_UNCERTAIN';
            $s['errors'][]=['keyword'=>$keyword,'error'=>$e->getMessage(),'utc'=>gmdate('c')];
            update_option(self::OPT,$s,false);
            delete_option(self::LOCK);
            wp_die('Nachholung fehlgeschlagen. Abrechnung unklar; nicht erneut auslösen.');
        }
        wp_safe_redirect(admin_url('admin.php?page='.self::PAGE));exit;
    }
    private static function progress(array $s): array {
        return ['status'=>$s['status'],'index'=>(int)($s['index']??0),'total'=>count((array)($s['keywords']??[])),
            'known_cost_usd'=>$s['known_cost_usd']??null,'terminal'=>($s['status']==='COMPLETE')];
    }
    private static function url_key(string $url): string {
        $p=parse_url($url); if (!is_array($p)||empty($p['host']))return '';
        $host=preg_replace('/^www\\./i','',strtolower($p['host']));
        $path=rawurldecode((string)($p['path']??'/'));
        return $host.'/'.trim($path,'/');
    }
    private static function overlaps(array $s): array {
        $r=(array)($s['results']??[]);$out=[];
        foreach ((array)($s['pairs']??[]) as $i=>$p) {
            $a=$r[2*$i]??null;$b=$r[2*$i+1]??null;
            if (!$a||!$b||self::missing_result($a)||self::missing_result($b)){
                $out[]=['conflict_field'=>$p['conflict_field'],'status'=>'NOT_MEASURED','common_urls'=>[]];continue;
            }
            $xs=[];$ys=[];
            foreach ($a['organic_top10']??[] as $row){$u=self::url_key((string)($row['url']??''));if($u!=='')$xs[$u]=true;}
            foreach ($b['organic_top10']??[] as $row){$u=self::url_key((string)($row['url']??''));if($u!=='')$ys[$u]=true;}
            $common=array_keys(array_intersect_key($xs,$ys));
            $out[]=['conflict_field'=>$p['conflict_field'],
                'status'=>count($xs)>=3&&count($ys)>=3?'MEASURED_REVIEW_REQUIRED':'INSUFFICIENT_ORGANIC_RESULTS',
                'overlap_top10_count'=>count($common), 'common_urls'=>$common,
                'keywords'=>$p['keywords'],
                'warning'=>'URL overlap indicator only; no automatic SERP ownership or structural approval'];
        }
        return $out;
    }
    public static function export(): void {
        self::cap();check_admin_referer('apkw_hab_serp_export');
        $s=get_option(self::OPT,false);
        if(!is_array($s))wp_die('Kein SERP-Datensatz.');
        $s['overlap_analysis']=self::overlaps($s);
        $json=wp_json_encode($s,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if(!is_string($json))wp_die('Export fehlgeschlagen.');
        nocache_headers();header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="hab-bewahr-dataforseo-serp-20felder-'.gmdate('Ymd-His').'-utc.json"');
        echo $json;exit;
    }
    public static function render(): void {
        self::cap();$s=get_option(self::OPT,false);$plan=self::plan();$n=count($plan['keywords_flat']);
        echo '<div class="wrap"><h1>Hab &amp; Bewahr – DataForSEO: organische SERP-Prüfung</h1>';
        echo '<p><strong>20 dokumentierte Konfliktfelder, '.$n.' Google-Suchanfragen, DE/de, jeweils Top 10.</strong> Bestehende WordPress-Zugangsdaten. Keine Änderungen an Kategorien, Artikeln oder der Navigation.</p>';
        echo '<p>Eindeutig gemeldete Anbieterfehler 40101 (Task- oder Antwortebene, HTTP 200) werden protokolliert und ohne Wiederholung übersprungen. Fehlen Kostenangaben, bleibt der Betrag ausdrücklich unbekannt. Netzwerkfehler und unklare Antworten stoppen weiterhin.</p>';
        echo '<p>Jede Anfrage kostet Geld. Der Endpreis wird vom Anbieter berechnet; kein garantierter Betrag vor dem Aufruf. Trefferüberschneidungen sind Prüfhinweise, kein automatischer SEO-PASS.</p>';
        if ($s===false) {
            echo '<h2>Einmaligen SERP-Abgleich freigeben</h2>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_hab_serp_start">';
            wp_nonce_field('apkw_hab_serp_start');
            echo '<p><label><input type="checkbox" required name="apkw_hab_serp_paid_consent" value="1"> Ich bestätige die kostenpflichtigen '.$n.' einzelnen Google-SERP-Abfragen über den bestehenden DataForSEO-Zugang.</label></p>';
            submit_button('SERP-Prüfung einmal starten');echo '</form>';
        } else {
            echo '<h2>Status: '.esc_html((string)($s['status']??'' )).'</h2>';
            echo '<p>Erledigt: <strong>'.esc_html((string)($s['index']??0)).' / '.esc_html((string)count($s['keywords'])).'</strong> · Gemeldete Kosten bisher: $'.esc_html((string)round((float)($s['known_cost_usd']??0),5)).'.</p>';
            if(($s['status']??'')==='RUNNING') {
                echo '<div id="apkw-serp-progress">Der gebündelte SERP-Abgleich läuft nach Laden dieser Seite weiter.</div>';
                echo '<script>(function(){var nonce='.wp_json_encode(wp_create_nonce('apkw_hab_serp_advance')).';var active=true;function step(){if(!active)return;var b=new URLSearchParams({action:"apkw_hab_serp_advance",_ajax_nonce:nonce});fetch(ajaxurl,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"},body:b.toString()}).then(function(r){return r.text().then(function(t){var j;try{j=JSON.parse(t);}catch(e){throw new Error("Ungültige Serverantwort – kein automatischer Retry.");}if(!j.success)throw new Error(j.data&&j.data.message||"SERP-Aufruf gesperrt.");return j.data;});}).then(function(d){document.getElementById("apkw-serp-progress").textContent="SERP-Ergebnisse: "+d.index+" / "+d.total+" · Kosten: $"+d.known_cost_usd;if(d.terminal){active=false;location.reload();return;}setTimeout(step,300);}).catch(function(e){active=false;document.getElementById("apkw-serp-progress").textContent="STOP: "+e.message+". Die Statusüberschrift zeigt den Zustand VOR dem Abbruch. Seite neu laden; keine automatische Doppelabrechnung.";});}setTimeout(step,200);})();</script>';
            } else if ($s['status']==='COMPLETE') {
                echo '<p><strong>Prüflauf abgeschlossen. Fehlerhafte Einzelabfragen werden als NICHT GEMESSEN markiert.</strong></p>';
                foreach(self::overlaps($s) as $row)echo '<p>'.esc_html($row['conflict_field']).': '.esc_html((string)($row['overlap_top10_count']??'—')).' gemeinsame Top-10-URLs · '.esc_html($row['status']).'</p>';
                $miss=0;foreach((array)($s['results']??[])as $item){if(self::missing_result($item))$miss++;}
                if($miss>=1){
                    echo '<h2>Noch fehlende Anbieteranfragen: '.(int)$miss.'</h2><p>Nur nach Prüfung der bisherigen Abrechnung und wenn der Anbieter wieder funktioniert. Erneuter kostenpflichtiger Abruf ist eine NEUE Anfrage; nicht automatisch.</p>';
                    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_hab_serp_recheck_one">';wp_nonce_field('apkw_hab_serp_recheck_one');
                    echo '<p><label><input type="checkbox" required name="apkw_hab_serp_paid_consent" value="1"> Ich bestätige die zusätzliche kostenpflichtige Einzelabfrage nach Klärung der früheren Kosten.</label></p>';
                    submit_button('Nächsten fehlenden SERP separat nachholen','secondary');echo '</form>';
                }
            } else {
                echo '<p><strong>Kein automatischer neuer Kostenlauf!</strong> Anbieterantwort und Abrechnung prüfen; Download erhält Teilresultate.</p>';
                if(self::skippable($s)){
                    $remaining=count((array)$s['keywords'])-(int)$s['index']-1;
                    echo '<p>Die letzte fehlgeschlagene Anfrage wird <strong>nicht wiederholt</strong>. Ihr tatsächlicher Abrechnungsstatus kann unbekannt sein. Die übrigen '.$remaining.' Abfragen sind neue kostenpflichtige Anfragen und erfordern eine einmalige ausdrückliche Freigabe.</p>';
                    echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_hab_serp_skip_failed">';wp_nonce_field('apkw_hab_serp_skip_failed');
                    echo '<p><label><input type="checkbox" required name="apkw_hab_serp_paid_consent" value="1"> Mir ist bewusst, dass die vorherige Anfrage trotz Fehler berechnet worden sein kann. Ich bestätige das Überspringen ohne Wiederholung und die weiteren '.$remaining.' kostenpflichtigen Abfragen.</label></p>';
                    submit_button('Fehlerhafte Anfrage überspringen und übrige Prüfungen fortsetzen','secondary');echo '</form>';
                }
            }
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_hab_serp_export">';
            wp_nonce_field('apkw_hab_serp_export');submit_button('SERP-Ergebnisse als JSON herunterladen','secondary');echo '</form>';
        }
        echo '<h2>Geprüfte Suchpaare</h2><ol>';
        foreach ($plan['pairs'] as $p)echo '<li><strong>'.esc_html($p['conflict_field']).'</strong>: '.esc_html(implode(' | ',$p['keywords'])).'</li>';
        echo '</ol></div>';
    }
}
