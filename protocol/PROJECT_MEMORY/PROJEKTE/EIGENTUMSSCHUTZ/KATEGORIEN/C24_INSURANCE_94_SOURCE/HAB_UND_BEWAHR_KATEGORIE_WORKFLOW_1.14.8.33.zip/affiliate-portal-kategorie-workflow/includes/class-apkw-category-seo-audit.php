<?php
if (!defined('ABSPATH')) { exit; }
/** Read-only name/intent measurement using existing DataForSEO credentials.
 * No category writes, no automatic paid requests and no fabricated SEO score.
 */
final class APKW_Category_SEO_Audit {
    private const PAGE='apkw-category-name-seo';
    private const OPT='apkw_category_name_seo_audit_v1';
    private const LOCK='apkw_category_name_seo_cost_lock_v1';
    // Only editorial ALTERNATIVES: no existing WordPress object is renamed here.
    private const ALTERNATIVES=[
        'Sanitärräume & Nebenanlagen'=>['Sanitärräume schützen','Vandalismus Toiletten','Sachbeschädigung WC'],
        'Nebenraum-Inventar'=>['Gemeinschaftsraum Vandalismus','Inventar vor Vandalismus schützen'],
        'Innenbeleuchtung & Leitsysteme'=>['Treppenhausbeleuchtung Vandalismus','Beleuchtung gegen Vandalismus'],
        'Schließfächer & Aufbewahrung'=>['Schließfächer Vandalismus','Spinde vor Vandalismus schützen'],
        'Gebäude & Ausstattung'=>['Vandalismus Gebäude','Sachbeschädigung Haus'],
        'Dachflächen & Dachaufbauten'=>['Dach undicht','Dachschaden Regen'],
        'Fassade, Fenster & Öffnungen'=>['Fassade undicht','Fenster undicht'],
        'Regenwasserführung am Gebäude'=>['Dachrinne verstopft','Fallrohr undicht'],
        'Sommerlicher Hitzeschutz am Gebäude'=>['Hitzeschutz Haus','Dachgeschoss Hitzeschutz'],
        'Trockenschäden an Grundstück & Garten'=>['Trockenheit Garten','Bodenrisse Trockenheit'],
        'Freizeitobjekte bei Hitzewellen'=>['Wohnmobil Hitzeschutz','Gartenhaus Hitzeschutz'],
        'Photovoltaik & Wechselrichter'=>['Photovoltaik Störung','Wechselrichter defekt'],
        'Batteriespeicher & Ersatzstrom'=>['Stromspeicher defekt','Notstrom Speicher'],
        'Wallbox & Heimladen'=>['Wallbox defekt','Wallbox Ladefehler'],
        'Freizeitboote & Nässe'=>['Boot Wassereintritt','Schimmel Boot'],
        'Baulicher Brandschutz im Wohnbestand'=>['Baulicher Brandschutz Haus','Brandschutz Wand'],
        'Hanggrundstücke & Erosion'=>['Hangrutsch Garten','Erosion Grundstück'],
        'Heimnetz & lokale Kommunikation'=>['WLAN Ausfall','Heimnetzwerk Störung'],
        'Brände an Privatfahrzeugen & Freizeitbooten'=>['Autobrand','Bootsbrand'],
        'Brandschäden & Wiederherstellung'=>['Brandschaden Haus','Brandschaden Sanierung'],
        'Gartenpools & Teichanlagen'=>['Pool undicht','Teichfolie undicht'],
        'Fahrzeugteile & Zubehördiebstahl'=>['Katalysator Diebstahl','Felgen Diebstahl'],
        'Geparkte Fahrzeuge bei Unwetter'=>['Hagelschaden Auto','Wasserschaden Auto'],
        'Äußere Brandeinwirkung auf Privatobjekte'=>['Waldbrand Haus schützen','Funkenflug Brandschutz','Brand Nachbarhaus'],
    ];
    public static function init():void {
        add_action('admin_menu',[__CLASS__,'menu'],45);
        add_action('admin_post_apkw_category_seo_run',[__CLASS__,'run']);
        add_action('admin_post_apkw_category_seo_export',[__CLASS__,'export']);
    }
    public static function menu():void {
        add_submenu_page(APKW_FinalTargetAdmin::PAGE_SLUG,'SEO-Namen prüfen','SEO-Namen prüfen','manage_options',self::PAGE,[__CLASS__,'render']);
    }
    private static function admin():void {
        if(!current_user_can('manage_options'))throw new RuntimeException('Administrator erforderlich.');
    }
    private static function key(string $s):string {
        $s=trim(preg_replace('/\s+/u',' ',$s)??$s);
        return function_exists('mb_strtolower')?mb_strtolower($s,'UTF-8'):strtolower($s);
    }
    private static function profile():array {
        $p=APKW_TargetTree::profile();
        if(!is_array($p)||($p['project']['project_id']??'')!=='hab-und-bewahr')
            throw new RuntimeException('Aktives Hab-&-Bewahr-Profil fehlt.');
        return $p;
    }
    public static function plan(array $p):array {
        $names=[];$nodes=[];$seen=[];
        foreach((array)($p['nodes']??[]) as $n){
            if(!is_array($n)||($n['pillar']??'')!=='core'||($n['status']??'active')!=='active'||!in_array(($n['object_type']??''),['page','category'],true))continue;
            $id=(string)($n['node_id']??'');$name=trim((string)($n['display_name']??''));
            if($id===''||$name===''||$id==='core:hub')continue;
            $nodes[$id]=$name;$key=self::key($name);
            if(!isset($seen[$key])){$names[]=$name;$seen[$key]=true;}
        }
        foreach(self::ALTERNATIVES as $old=>$alternatives)forEach($alternatives as $a) {
            $key=self::key($a);if(!isset($seen[$key])){$names[]=$a;$seen[$key]=true;}
        }
        if(!$nodes||count($names)>700)throw new RuntimeException('SEO-Prüfplan über 700 eindeutige Begriffe: gebündelte Folgeprüfung nötig, keine unbemerkten Anbieteraufrufe.');
        $rev=APKW_TargetTree::revision($p);
        return ['revision'=>$rev,'nodes'=>$nodes,'keywords'=>$names,'sha256'=>hash('sha256',wp_json_encode([$rev,$nodes,$names],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))];
    }
    /** Does not mean SEO approved: only a real provider response with the same plan exists. */
    public static function measured_plan(array $p):bool {
        $a=get_option(self::OPT,null);
        if(!is_array($a)||($a['status']??'')!=='COMPLETE'||!is_array($a['results']??null))return false;
        try{$plan=self::plan($p);}catch(Throwable $e){return false;}
        return hash_equals((string)($a['plan_sha256']??''),$plan['sha256'])&&
            ($a['market']??'')==='Germany/de'&&
            is_string($a['provider_task_id']??null)&&($a['provider_task_id']??'')!=='';
    }
    /** Refuse to confuse a display name with a DataForSEO keyword result or human approval. */
    public static function require_editorial_approval(array $p):void {
        if(!self::measured_plan($p))throw new RuntimeException('DataForSEO-Namensabgleich nicht mit echtem Ergebnis nachgewiesen. Keine Profilfreigabe.');
        $a=get_option(self::OPT,null);
        if(($a['editorial_approved_sha256']??'')!==($a['plan_sha256']??''))throw new RuntimeException('Keywords wurden gemessen, aber redaktionelle SEO-Freigabe fehlt. Keine automatische Namensfreigabe.');
    }
    public static function run():void {
        try {
            self::admin();check_admin_referer('apkw_category_seo_run');
            if(($_POST['apkw_paid_permission']??'')!=='1')throw new RuntimeException('Ausdrückliche Kostenfreigabe fehlt.');
            $p=self::profile();$plan=self::plan($p);
            $credentials=APKW_Settings::credentials();$market=APKW_Settings::defaults();
            if($credentials['login']===''||$credentials['password']==='')throw new RuntimeException('DataForSEO ist im Plugin nicht verbunden.');
            if($market['location_name']!=='Germany'||$market['language_code']!=='de')throw new RuntimeException('DataForSEO muss Germany/de verwenden.');
            $existing=get_option(self::OPT,null);
            if(is_array($existing) && ($existing['status']??'')==='IN_FLIGHT')throw new RuntimeException('Kostenpflichtiger Aufruf möglicherweise in Bearbeitung. Kein automatischer zweiter Aufruf.');
            if(is_array($existing)&&($existing['plan_sha256']??'')===$plan['sha256']&&($existing['status']??'')==='COMPLETE')throw new RuntimeException('Für dieses Profil liegt bereits ein Anbieter-Ergebnis vor. Keine doppelte Abrechnung.');
            if(!add_option(self::LOCK,['sha256'=>$plan['sha256'],'started_utc'=>gmdate('c')],'',false))throw new RuntimeException('Kosten-Sperre aktiv. Kein doppelter Anbieteraufruf.');
            // Save IN_FLIGHT before the only potentially chargeable request. Never auto-retry after a timeout.
            update_option(self::OPT,['status'=>'IN_FLIGHT','plan_sha256'=>$plan['sha256'],'started_utc'=>gmdate('c'),'profile_revision'=>$plan['revision']],false);
            try {
                $result=APKW_DataForSEO::keyword_overview($plan['keywords'],'Germany','de',true,'hb-category-audit-'.substr($plan['sha256'],0,24));
                if(($result['task_id']??'')===''||($result['http_code']??0)!==200)throw new RuntimeException('Kein bestätigter Anbieter-Task.');
                $matches=[];
                foreach((array)($result['normalized_items']??[]) as $row)if(is_array($row)&&isset($row['keyword']))$matches[self::key((string)$row['keyword'])]=[
                    'keyword'=>(string)$row['keyword'],
                    'search_volume'=>$row['search_volume']??null,'main_intent'=>$row['main_intent']??null,
                    'keyword_difficulty'=>$row['keyword_difficulty']??null,'source_last_updated'=>$row['source_last_updated']??null
                ];
                $out=['status'=>'COMPLETE','market'=>'Germany/de','plan_sha256'=>$plan['sha256'],
                    'profile_revision'=>$plan['revision'],'checked_utc'=>gmdate('c'),
                    'provider_task_id'=>$result['task_id'],'provider_response_sha256'=>$result['raw_response_sha256']??'',
                    'provider_cost_usd'=>$result['cost_usd']??null,'searched_names'=>$plan['keywords'],
                    'nodes'=>$plan['nodes'],'results'=>$matches,'returned_keywords'=>count($matches),
                    'editorial_approved_sha256'=>null,'writes_to_categories'=>0];
                update_option(self::OPT,$out,false);
                delete_option(self::LOCK);
                wp_safe_redirect(admin_url('admin.php?page='.self::PAGE.'&audit=complete'));exit;
            } catch(Throwable $e){
                update_option(self::OPT,['status'=>'UNCERTAIN_COST_NO_AUTORETRY','error'=>$e->getMessage(),
                    'plan_sha256'=>$plan['sha256'],'recorded_utc'=>gmdate('c')],false);
                // Deliberately retain cost lock after transport errors to prevent another charged request.
                throw $e;
            }
        } catch(Throwable $e){wp_die(esc_html($e->getMessage()),'SEO-Namenprüfung BLOCKED',['response'=>409]);}
    }
    public static function export():void {
        self::admin();check_admin_referer('apkw_category_seo_export');$a=get_option(self::OPT,null);
        if(!is_array($a)||($a['status']??'')!=='COMPLETE')wp_die('Keine echten SEO-Ergebnisse.');
        nocache_headers();header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="hab-und-bewahr-dataforseo-kategorienamen.json"');
        echo wp_json_encode($a,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
    }
    public static function render():void {
        self::admin();echo '<div class="wrap"><h1>Kategorienamen &amp; DataForSEO</h1>';
        try{$plan=self::plan(self::profile());}catch(Throwable $e){echo '<p>'.esc_html($e->getMessage()).'</p></div>';return;}
        $a=get_option(self::OPT,null);$matched=is_array($a)&&($a['status']??'')==='COMPLETE'&&($a['plan_sha256']??'')===$plan['sha256'];
        echo '<p>Aktuelles Profil: <code>'.esc_html($plan['revision']).'</code>. '.count($plan['nodes']).' Kategorieknoten; '.count($plan['keywords']).' eindeutige Keywords einschließlich Alternativen.</p>';
        echo '<p><strong>Keine Obergrenze für Unterkategorien.</strong> DataForSEO kann Suchvolumen und Suchintention liefern; ohne Anbieterantwort und redaktionelle Bewertung ist kein Name als SEO-geprüft freigegeben. Keine Kategorienänderung durch diese Seite.</p>';
        if($matched){
            echo '<p><strong>Anbieter-Ergebnis vorhanden.</strong> Task '.esc_html($a['provider_task_id']).', Kosten USD '.esc_html((string)$a['provider_cost_usd']).'. Noch keine automatische redaktionelle Freigabe.</p>';
            echo '<h2>Beanstandete Namen: exakte Begriffe und mögliche Alternativen</h2>';
            echo '<table class="widefat striped"><thead><tr><th>Prüfbegriff</th><th>Volumen</th><th>Intent</th></tr></thead><tbody>';
            foreach (self::ALTERNATIVES as $bad=>$alternatives) {
                foreach (array_merge([$bad],$alternatives) as $i=>$keyword) {
                    $row=$a['results'][self::key($keyword)]??null;
                    echo '<tr><td>'.($i===0?'<strong>Original: </strong>':'Alternative: ').esc_html($keyword).'</td><td>'.esc_html(isset($row['search_volume'])?(string)$row['search_volume']:'—').'</td><td>'.esc_html((string)($row['main_intent']??'—')).'</td></tr>';
                }
            }
            echo '</tbody></table><h2>Bestandsnamen</h2>';
            echo '<table class="widefat striped"><thead><tr><th>Kategoriename</th><th>Suchvolumen</th><th>Intent</th><th>Status</th></tr></thead><tbody>';
            $i=0;foreach($plan['nodes'] as $id=>$name){$v=$a['results'][self::key($name)]??null;
                echo '<tr><td>'.esc_html($name).'</td><td>'.esc_html(isset($v['search_volume'])?(string)$v['search_volume']:'—').'</td><td>'.esc_html((string)($v['main_intent']??'—')).'</td><td>'.($v?'Gemessen – redaktionell prüfen':'Ohne Anbieter-Treffer – prüfen').'</td></tr>';
                if(++$i>=200)break;
            }
            echo '</tbody></table><p>Erste 200 Treffer sichtbar; vollständiges Ergebnis enthält alle Knoten und Anbieter-Alternativen.</p>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_category_seo_export">';wp_nonce_field('apkw_category_seo_export');submit_button('Prüfergebnisse als JSON herunterladen','secondary');echo '</form>';
        } elseif(is_array($a)&&in_array((string)($a['status']??''),['IN_FLIGHT','UNCERTAIN_COST_NO_AUTORETRY'],true)){
            echo '<p><strong>Provider-Aufruf unklar / gesperrt.</strong> Kein automatischer kostenpflichtiger Neustart. '.esc_html((string)($a['error']??'')).'</p>';
        } else {
            echo '<p>Der einmalige DataForSEO-Keyword-Overview-Aufruf kann kostenpflichtig sein. Er prüft die Namen im aktuellen Kategorienprofil, ändert aber keine Namen/URLs und ersetzt keine SERP-Einzelfallprüfung.</p>';
            echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="apkw_category_seo_run">';wp_nonce_field('apkw_category_seo_run');
            echo '<p><label><input type="checkbox" name="apkw_paid_permission" value="1" required> Ich genehmige genau diesen einmaligen kostenpflichtigen DataForSEO-Namensabgleich für Germany/de.</label></p>';submit_button('Kategorienamen mit DataForSEO abgleichen');echo '</form>';
        }
        echo '</div>';
    }
}
