1. Lies `CODEX_AUFTRAG_PHP_REALPATH_PROOF_AND_BUILD_20260820.md` vollständig.
2. Verwende `class-pste-repository.php` als aktuellen Patchkandidaten.
3. Nutze die bereits im Repository vorhandenen Masterdateien, vollständigen PSTE/PSERC/PPM-Sources und den echten 562er Liveexport als Autorität/Eingang.
4. Kein Installer, bis der echte PHP-Produktionspfad + Gesamtworkflow + Fresh-Unpack PASS sind.
