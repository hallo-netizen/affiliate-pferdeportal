# CODEX-AUFTRAG – PHP-REALPFAD BEWEIS + NUR BEI PASS BUILD

## Autorität
Master/Workflow aus dem bisherigen Journal-Rootfix bleiben unverändert verbindlich. Keine neue Architektur, keine neue Text-/Titel-/Kategorie-/Prompt-/Publishlogik.

## Ausgangspunkt
Der beigefügte `class-pste-repository.php` ist der von Codex zuletzt vorgeschlagene PSTE-Produktionspatch.
Die bereits ermittelte Root Cause lautet: persistiertes `automatic_pool_status=AUTO_RESOLVED` wurde im Read-Model als Release-Autorität behandelt. Der Patch führt vor der Statusmaterialisierung eine Extension-Revalidierung durch.

## EINZIGER OFFENER PFLICHTBEWEIS
Der bisherige Python-562-Test modelliert die gewünschte Transformation selbst. Das genügt NICHT als Beweis für den Produktions-PHP-Pfad.

Erzeuge deshalb einen echten PHP-/WordPress-Test, der den GEÄNDERTEN PRODUKTIONSCODE ausführt – keine Python-Nachbildung und keine zweite Implementierung der Regeln.

### Pflicht: tatsächlicher PHP-Pfad
Der Test muss über den echten produktiven Read-Model-Pfad laufen, bevorzugt über die öffentliche Compiler-Schnittstelle `PSTE_Repository::compilerTopicPage()` bzw. die reale WordPress-Testinstanz. Dadurch muss intern tatsächlich `applyPoolRowWithRelations()` und `revalidatePersistedExtensionState()` ausgeführt werden.

Verwende den bereits vorhandenen echten Live-562-Export als Eingangsbeleg. Öffne/dumpe die 37-MB-Datei NICHT vollständig in den Chat; verarbeite sie stream-/scriptbasiert. Falls zum Aufbau einer DB-Fixture nötig, generiere sie programmgesteuert.

## Harte Assertions
1. 562 Kandidaten werden über den echten PHP-Produktionspfad verarbeitet.
2. Die 55 alten Journal-Zustände mit `PSTE_JOURNAL_ROUTER_V1` / `FALLBACK_ONLY_AFTER_EXISTING_PRODUCT_FAMILY_MISS` werden reproduziert und tatsächlich vom PHP-Patch revalidiert.
3. Exakt die zwei signierten Goldpiloten bleiben/werden Journal-PASS:
   - `Wie alt werden Pferde?`
   - `Können Pferde schwimmen?`
4. Die übrigen 53 alten Journal-PASS werden durch den echten PHP-Pfad fail-closed und sind NICHT Journal-PASS / NICHT AUTO_RESOLVED.
5. Die 507 Nicht-Journal-Kandidaten bleiben fachlich und entscheidungsseitig unverändert; keine Extension-Revalidierung darf sie verändern.
6. Ein alter persistierter `AUTO_RESOLVED`-Wert darf ohne aktuellen signierten Extension-Proof keinen PASS erzeugen.
7. `manual_status=APPROVED` oder andere manuelle Statuswerte dürfen einen ungültigen aktuellen Extension-Vertrag nicht umgehen.
8. Keine DB-, Kategorie-, Artikel-, Text-, Design- oder Publish-Schreibwege als Nebenwirkung des Read-Tests.

## Danach vollständiger Workflow – nicht stoppen
Wenn und NUR wenn der PHP-Realpfad vollständig PASS ist:

1. Patch in den vollständigen PSTE-Source einbauen.
2. Alle bestehenden PSTE/Pserc relevanten Tests ausführen.
3. PSERC gegen den korrigierten 562er Read-Model-Bestand laufen lassen.
   Erwartung:
   - die zwei Goldpiloten können über den NORMALEN Redaktionsplan bis zum Metadaten-Handoff gelangen;
   - die 53 falschen Journal-Kandidaten erscheinen nicht mehr als Journal-READY;
   - die 12 bestehenden Beratung/Pflege-Holds bleiben getrennt und unverändert, sofern sie pre-Journal bereits so waren.
4. PPM vollständige bestehende Suite in der vorgesehenen Suite-Umgebung ausführen. Nicht einzelne historische Entry-Points isoliert als Ersatz bewerten.
5. Source → Installer → Fresh-Unpack.
6. Dieselben PHP-Realpfad-/562er-/PSERC-/PPM-Tests erneut auf Fresh-Unpack.
7. Hashparität, PHP-Lint, JSON-Parse, Signaturen und verbotene Write-Callsites prüfen.

## Build-Sperre
- Bei irgendeinem FAIL/UNKNOWN: **BLOCKED, KEIN INSTALLER**.
- Nur bei vollständigem PASS: genau **einen neuen PSTE-Installer** erzeugen. PSERC 0.27.0 und PPM 6.7.9 nur dann ändern, wenn ein reproduzierbarer Test beweist, dass deren Source zwingend geändert werden muss. Keine prophylaktische Änderung.

## Lieferung bei PASS
1. Root-Cause-/Beweisbericht mit dem echten PHP-Realpfad-Test.
2. Exakte Liste geänderter Produktionsdateien.
3. Alle Testbefehle + kompakte PASS-Zahlen.
4. Neuer PSTE-Installer.
5. Aktualisierter kompletter Master/Übergabestand mit Hashmanifest.
6. Klare Installationsanweisung: welche Datei installieren, welche nicht.

## Verboten
- Kein Python-Test als Ersatz für den PHP-Produktionspfad.
- Keine Nachimplementierung der Produktionsentscheidung im Test.
- Kein Journal-Sonder-PASS.
- Kein Abschwächen von PSERC-Gates.
- Kein globaler Rebuild/Löschen des Topic-Pools.
- Keine Änderung der Textmaschine oder fertigen Textregeln.
- Keine neue Beitragsart-Architektur.
- Keine Zwischenlösung.

Arbeite vollständig durch. Nicht nach dem ersten grünen Teiltest stoppen.
