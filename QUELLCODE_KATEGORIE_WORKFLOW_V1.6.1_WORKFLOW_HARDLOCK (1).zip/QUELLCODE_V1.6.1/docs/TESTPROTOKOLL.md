# Testprotokoll V1.6.1

Source-Testbestand: 116/116 PASS.
Enthält positive und negative Gates für drei Säulen, 3-Longtail-Contentregel, FAQ/Tipps/Beratung/Ausrüstung als mögliche Kategorien, sichtbare Reviews, Scope-Invalidierung, Serversignatur/Injection, Master-Contract, Zielmarkt/Sprache, Global-Gaps, DEFERRED, Kostenpfade, Paketbindungen, Evidenz und verbotene Content-Writes sowie den separat isolierten Global-Gap-Signer, korrigierte Global-Gap-Bäume ohne zweiten Global-Call und serverseitig exakt `1` verlangte Bestätigungen.

Fresh-Unpack-Prüfung: 116/116 PASS mit derselben Suite; PHP-Lint PASS; SHA-256-Manifest PASS.
