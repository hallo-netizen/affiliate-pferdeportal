# Changelog

## 1.6.1
- HARDLOCK Rootfix: manuelle Review-Status/Hash-Injektion durch serverseitig HMAC-signierte Review-Quittungen blockiert.
- Signierung zusätzlich an exakten sichtbaren Review-Scope-SHA-256 gebunden.
- Zielmarkt/Sprache vollständig in Projekt-, Research-, Review- und Paketbindung aufgenommen.
- Rehash-Tampering von Global-/Research-Paketen mit falschem Markt/Sprache blockiert.
- Master-Contract-ID in Category-, Global- und Research-Paketen fest gebunden.
- Unabhängiger Finalaudit-Rootfix: Global-Gap-Signer prüft jetzt seinen eigenen exakten sichtbaren Scope-Hash.
- Korrigierte Global-Gap-Bäume werden gegen die im Global-Paket gebundene ursprüngliche Initialfreigabe geprüft; eine zulässige Korrektur erzwingt keinen zweiten Global-Call.
- Sicht- und Paid-Bestätigungen akzeptieren serverseitig nur noch exakt den Wert `1`; bloße POST-Feldpräsenz reicht nicht.
- 116 Positiv-/Negativtests im Source-Stand.

## 1.6.0
- Drei sichtbare hashgebundene Freigabestufen; Global-Ähnlichkeit darf keine fachliche Entscheidung ersetzen; DEFERRED blockiert.

## 1.5.0
- Contentkategorie-Rootfix: tragfähige Beitragsrichtungen können echte Content-Kategorien sein.
