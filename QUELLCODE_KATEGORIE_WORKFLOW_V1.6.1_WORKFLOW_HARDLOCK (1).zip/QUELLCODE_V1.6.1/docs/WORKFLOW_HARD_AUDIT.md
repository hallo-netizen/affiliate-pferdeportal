# Workflow-Hard-Audit V1.6.1

## Kritische Befunde aus Master 015 / Plugin 1.5.0
1. Kostenpflichtige Global-Coverage war technisch vor der vereinbarten Erst-Sichtprüfung möglich.
2. Nach Global-Coverage konnten Chat/Master Hauptthemen korrigieren und direkt Detailresearch starten, ohne dass der korrigierte Baum sichtbar freigegeben war.
3. `DEFERRED` wurde als "entschieden" behandelt und konnte dadurch Detail-/Finalgates schließen.
4. Masterdokumente enthielten unterschiedliche Reihenfolgen für die Erst-Sichtprüfung.
5. Der Nutzer konnte daher formal nicht sicher sein, dass genau der sichtbare Entwurf die kostenpflichtige Recherche auslöste.

## Rootfix
- Erst-Sichtprüfung ist jetzt hashgebundenes technisches Gate vor jedem Paid Global-Call.
- Zweite sichtbare Global-Gap-Freigabe ist hashgebundenes technisches Gate vor jedem Paid Detailresearch.
- Finale Sichtprüfung bleibt drittes hashgebundenes Gate vor FINAL.
- `DEFERRED` bleibt als Arbeitsstatus zulässig, blockiert aber Detailresearch bzw. READY/FINAL.
- Jede Änderung nach einem Review ändert den Scope-Hash und erzwingt den jeweiligen Review erneut.
- Keine neuen Content-Write-Pfade.

## HARDLOCK-Befunde 2026-08-20

- `project.target_market` und `project.language_code` sind Pflichtfelder des PROJECT CONTRACT und Bestandteil sämtlicher Review- und Research-Scope-Hashes. Abweichende Laufzeitparameter blockieren vor dem ersten externen Request.
- Keyword-/Core-Ähnlichkeit ist nur ein automatischer Zuordnungshinweis. Jeder relevante Global-Coverage-Fund benötigt eine explizite Entscheidung (`MAIN_TOPIC`, `SUBTOPIC`, `ARTICLE_ONLY` oder `OUT_OF_SCOPE`); ohne Entscheidung bleibt das Gate `BLOCKED`, `DEFERRED` bleibt ebenfalls blockierend.


## Unabhängiger Finalaudit-Rootfix 2026-08-20

Reproduzierbare Befunde des vorherigen Finalkandidaten:

1. `APKW_Admin::sign_global_gap_review()` verlangte zwar im Formular den sichtbaren Review-Scope-SHA-256, prüfte ihn serverseitig jedoch nicht. Initial- und Finalsignierung prüften den Hash; nur der Global-Gap-Signer hatte den Aufruf nicht.
2. Derselbe Handler validierte die alte Initialfreigabe fälschlich gegen den nach Global-Coverage fachlich korrigierten Baum. Da der Initial-Review-Hash absichtlich Knoten und Research-Cluster bindet, blockierte damit jede echte zulässige Korrektur die Stufe 8. Korrekt ist die Prüfung der Initialfreigabe gegen den unveränderten `source_draft.package` des gebundenen Global-Pakets; der korrigierte Baum bleibt separat über Projekt-/Global-Bindung und Global-Gap-Sichtfreigabe gebunden.
3. Sicht- und Paid-Bestätigungen wurden serverseitig nur auf Feldpräsenz geprüft. Ein manueller POST-Wert `0` genügte formal. Jetzt ist exakt `1` erforderlich.

Positiv-/Negativnachweis:
- Vor Rootfix mit erweiterter 116er-Suite: `113 PASS / 3 FAIL`.
- Nach Rootfix: `116 PASS / 0 FAIL`.
- Die Korrektur verändert weder Plugin-Linie noch Version noch Content-/Design-/Textlogik und fügt keine Content-Write-API hinzu.
