V6.61.11 CATEGORY-ROW ROOTFIX: Nur Kategorie-Produktkarten strecken sich in der normal auto-grossen Designraster-Zeile. Die kreisfoermige Kombination aus grid-auto-rows:1fr und verschachtelten height:100%-Regeln wurde entfernt; dadurch bleibt der normale Abschnittsabstand erhalten, waehrend drei Desktop-Karten, 150x150-contain-Bilder und Buttons providerneutral ausgerichtet sind. Provider-, Feed-, Ranking- und Designplugin-Logik unveraendert.

V6.61.10 STRUCTURAL EQUAL-ROW ROOTFIX: Kategorie-Produktkarten nutzen keine festen 416/360px-Aussenhoehen mehr. Das reale Produktraster setzt alle impliziten Zeilen mit grid-auto-rows:1fr gleich hoch; jeder Slot, Content-Wrapper und Kartenlink fuellt seine Grid-Zelle zu 100%. Bildflaechen bleiben 150x150 contain. Provider-, Feed-, Ranking- und Designplugin-Logik unveraendert.

Affiliate-Zentrale 6.61.5 – IDEALO STANDARDFEED 2901 + HYBRID-AUSGABE
Stable tag: 6.61.7

V6.61.7 LAST-MILE EQUAL-HEIGHT INVARIANT: Die drei sichtbaren Kategorie-Produktkacheln werden nach dem finalen DOM/CSS-Layout providerneutral auf exakt dieselbe gemessene Außenhöhe gesetzt. Der Ausgleich greift ausschließlich bei Designkarten, die direkt category_product_1/2/3 enthalten; Feed-, Ranking-, Provider-, Bild- und Designplugin-Logik bleiben unverändert.

V6.61.5 – IDEALO STANDARDFEED 2901 + HYBRID-AUSGABE
- idealo verwendet ausschließlich den Standardfeed 2901; Feed 2747 ist eine vollständige Teilmenge und nicht mehr nötig.
- Der Stream-Import prüft den vollständigen gebundenen 311er-Produktvertrag / 59 Hub-Familien und speichert nur konservativ zuordenbare GTIN-Produkte.
V6.61.6 PROVIDER-NEUTRAL CARD GEOMETRY ROOTFIX: Die feste Geometrie der drei Kategorie-Produktplaetze wird ausschliesslich durch den Slotvertrag category_product_1/2/3 aktiviert und nicht mehr zusaetzlich durch creative_type=product. Damit erhalten idealo, eBay und jeder weitere Provider in diesen drei Produktplaetzen exakt denselben Karten-/Bildvertrag. Provider-, Ranking-, Feed-, Bild- und Designplugin-Logik bleiben unveraendert.
- Keine manuelle Unterkategorienliste; große Feeds werden serverseitig in eine Temp-Datei gestreamt und unveränderte Feed-Hashes nicht erneut verarbeitet.
- Auto-Refresh bewusst nur alle zwölf Stunden; die offizielle Feed-URL wird maskiert gespeichert und nicht im Backend ausgegeben.
- Neue idealo-Linkstrategie mit drei Optionen: Hybrid (empfohlen), konkrete idealo-Produkte oder nur Preisvergleichs-/Suchlinks.
- Hybrid bedeutet: idealo steht eigenständig als Produktfamilien-/Preisvergleich. Ein konkretes idealo-Angebot erscheint nur als zusätzlicher Button auf einer bereits konkreten Produktkarte und ausschließlich bei exakter gemeinsamer GTIN.
- So werden breite Kategorien und allgemeine Ratgeber nicht künstlich mit einzelnen Modellen versehen; konkrete Produkte bleiben für echte Produktkontexte weiterhin möglich.
- eBay-Providerkern, eBay-Run, Heartbeat/Safe-Gap, Katalog und Network-Sync bleiben unverändert. V6.61.4 ändert ausschließlich den gemeinsamen Produktkarten-Bild-/Wrappervertrag in Hauptdatei, idealo-Adapter und frontend.css. Fehlende Provider erzeugen weiterhin keinen leeren Button.

V6.61.1 HOTFIX: idealo-Vollfeed-Synchronisation wird durch den Admin-Button nur noch eingereiht und im WordPress-Cron-Hintergrund verarbeitet. Kein lang laufender Admin-HTTP-Request; parallele idealo-Vollfeed-Laeufe werden per Lock verhindert.

V6.61.2 ROOTFIX: Der manuelle idealo-Hintergrundlauf hängt nicht mehr vom WordPress-Cron-Spawn ab. Der Start erfolgt primär über einen signierten, nicht blockierenden Loopback-Worker; WP-Cron bleibt nur Fallback. Bereits in V6.61.1 auf queued hängende Läufe werden beim ersten Request selbstheilend neu angestoßen. Einmal-Token, Lock, Retry-Abstand und stale-running-Recovery verhindern Parallel- und Endlosschleifen.

V6.61.4 PRODUCT-CARD/BILD-ROOTFIX: category_product_1/2/3 bleiben drei eigenstaendige Positionen und werden aus der final gerankten Liste nur mit bildfaehigen Kandidaten befuellt; ein defekter Kandidat wird uebersprungen und der naechste rueckt nach. Der V6.18-Vertrag fuer vorlaeufig materialisierte eBay-BUSINESS-Bilder bleibt erhalten. Fuer die oeffentliche Karte ist der aktive aktuelle eBay-Quelldatensatz kanonisch; sein aktuelles Remote-Bild wird HTTP-/Bild-dekodiert geprueft und lokal gecacht, statt an einem historischen Bildhash oder einer alten CDN-URL zu haengen. idealo-iPN-Bildwrapper werden auf die echte cdn.idealo.com-Bildquelle aufgeloest und nur bildfaehige Feedzeilen materialisiert. Alle drei Karten nutzen denselben 360px-Kartenvertrag mit 150x150-contain-Bildflaeche; kein cover und kein Designplugin-Eingriff.

V6.61.5 LIVE-ROOTFIX: Der Frontend-Renderer fuehrt keine Provider-Bilddownloads mehr aus. V6.61.4 konnte dadurch bei serverseitig nicht erreichbaren eBay-CDN-Bildern komplette eBay-Kandidaten aus der Rangliste entfernen; genau das erklaert den Live-Verlust der eBay-Angebote. eBay rendert jetzt aus der aktuellen aktiven BUSINESS-Quell-URL (Fallback nur auf validierte Kampagnen-URL), idealo direkt aus dem bereits normalisierten cdn.idealo.com-Ziel. Drei Slots bleiben unabhaengig; Geometrie/CSS V6.61.4 bleibt unveraendert.
