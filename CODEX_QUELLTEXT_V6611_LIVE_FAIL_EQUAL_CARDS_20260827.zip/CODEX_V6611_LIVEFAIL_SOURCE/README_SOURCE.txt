V6.61.11 live-fail source package.
Contains:
- exact reconstructed V6.61.11 plugin source currently installed/tested by user
- current live screenshot proving unequal visible card heights
- relevant READ-ONLY design-plugin context (do not modify)

Do not change provider/feed/ranking/runtime logic. Layout root-cause only.
