<?php
require __DIR__.'/fixture-builder.php';

nd_reset();
// Deliberately inject a bad live term without touching the bound Journal contract.
PPM679_WP::seed_test_term(array(
    'term_id'=>1481,'name'=>'FALSCHER LIVE-NAME','slug'=>'pferde-verstehen','taxonomy'=>'category','parent'=>0,
    'parent_chain_slugs'=>array(),'parent_chain_names'=>array(),'taxonomy_depth'=>1,
    'hierarchy_path'=>'Pferde verstehen','fixture_class'=>'REAL_SNAPSHOT_DERIVED'
));
PPM679_WP::seed_test_term(array(
    'term_id'=>1482,'name'=>'Pferderassen &amp; Pferdetypen','slug'=>'pferderassen-pferdetypen','taxonomy'=>'category','parent'=>0,
    'parent_chain_slugs'=>array(),'parent_chain_names'=>array(),'taxonomy_depth'=>1,
    'hierarchy_path'=>'Pferderassen &amp; Pferdetypen','fixture_class'=>'REAL_SNAPSHOT_DERIVED'
));

$journal=PPM679_Journal_Content_Block_Validator::read_only_live_snapshot();
ppm_test_assert($journal['ok']===false,'Journal mismatch remains fail closed in the Journal validator');
ppm_test_assert($journal['status']==='BLOCKED_JOURNAL_TERM_MISMATCH','Journal mismatch retains exact blocker');

$slot=PPM679_Editorial_Plan_Registry::find_slot(array(
    'title'=>'Wann ist Winterdecken sinnvoll und wann eher nicht?',
    'article_type'=>'FAQ',
    'category_slug'=>'pferdedecken-winterdecken-faq',
));
ppm_test_assert(is_array($slot),'Winterdecken FAQ slot resolves');
$candidate=array(array(
    'canonical_article_id'=>(string)$slot['canonical_article_id'],
    'plan_item_key'=>(string)($slot['source_plan_item_keys'][0]??''),
    'title'=>(string)$slot['working_title'],
    'article_type'=>(string)$slot['article_type'],
    'category_slug'=>(string)$slot['category_slug'],
));
$normal=PPM679_Editorial_Plan_Runtime_Gate::preflight($candidate,'normal_plan_preflight','production');
ppm_test_assert($normal['ok']===true,'Unrelated FAQ normal production is not blocked by Journal display/slug drift');
ppm_test_assert(($normal['report']['journal_live_verification_required']??null)===false,'Normal affiliate wave records Journal live check as not required');
ppm_test_assert(($normal['report']['journal_snapshot']??null)===null,'Normal affiliate wave does not misrepresent a Journal snapshot as passed');

$wissen=array(array(
    'canonical_article_id'=>'journal:pferde-verstehen:wissen:grundlagen',
    'title'=>'Pferdeverhalten verstehen: Grundlagen',
    'article_type'=>'Wissen',
    'category_slug'=>'pferde-verstehen',
));
$journal_run=PPM679_Editorial_Plan_Runtime_Gate::preflight($wissen,'journal-scope-negative','technical_evidence');
ppm_test_assert($journal_run['ok']===false,'Journal/Wissen candidate still requires live Journal verification');
ppm_test_assert($journal_run['status']==='BLOCKED_JOURNAL_TERM_MISMATCH','Journal/Wissen candidate is blocked by the live mismatch');

echo json_encode(array(
    'status'=>'PASS_NORMAL_DRAFT_JOURNAL_SCOPE_ISOLATION',
    'normal_affiliate_wave_not_globally_blocked'=>true,
    'journal_wissen_still_fail_closed'=>true,
    'journal_validator_fail_closed'=>true,
    'article_quality_rules_changed'=>false,
),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n";
