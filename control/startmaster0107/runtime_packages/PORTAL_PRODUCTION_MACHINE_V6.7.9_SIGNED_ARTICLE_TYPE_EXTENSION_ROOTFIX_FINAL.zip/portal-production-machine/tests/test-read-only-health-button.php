<?php
declare(strict_types=1);
ob_start();
require __DIR__ . '/bootstrap-test.php';
$load_output=ob_get_clean();

function ppm_health_private_state($class,$property) {
    $reflection=new ReflectionClass($class);
    $prop=$reflection->getProperty($property);
    return $prop->getValue();
}

function ppm_health_snapshot() {
    return array(
        'options'=>ppm_health_private_state('PPM679_WP','test_options'),
        'posts'=>ppm_health_private_state('PPM679_WP','test_posts'),
        'redirects'=>$GLOBALS['ppm_test_redirects'],
    );
}

function ppm_health_assert_unchanged($before,$message) {
    $after=ppm_health_snapshot();
    ppm_test_assert($after===$before,$message);
}

function ppm_health_reset() {
    PPM679_WP::reset_test_state();
    PPM679_Storage::reset_test_state();
    $GLOBALS['ppm_test_redirects']=array();
    $_POST=array();
    $_FILES=array();
    $_SERVER['REQUEST_METHOD']='POST';
}

ppm_test_assert($load_output==='','Plugin load must remain silent.');

$admin_source=(string)file_get_contents(dirname(__DIR__).'/includes/admin.php');

$health_fn_start=strpos($admin_source,'public static function health()');
$health_fn_end=strpos($admin_source,'private static function h(',$health_fn_start);
ppm_test_assert($health_fn_start!==false && $health_fn_end!==false,'Health function source block must exist.');
$health_fn_source=substr($admin_source,$health_fn_start,$health_fn_end-$health_fn_start);
ppm_test_assert(strpos($health_fn_source,'PPM679_Build_Integrity::verify')!==false,'Read-only health must verify the signed active build.');
ppm_test_assert(strpos($health_fn_source,'PPM679_Journal_Content_Block_Validator::read_only_live_snapshot')!==false,'Read-only health must expose the live journal snapshot without writes.');
$handler_start=strpos($admin_source,'public static function handle_health_check()');
$handler_end=strpos($admin_source,'public static function handle_run()',$handler_start);
ppm_test_assert($handler_start!==false && $handler_end!==false,'Health handler source block must exist.');
$handler_source=substr($admin_source,$handler_start,$handler_end-$handler_start);
ppm_test_assert(
    strpos($handler_source,"PPM679_WP::get_option('ppm_server_instance_id','')")!==false,
    'Precheck must call get_option directly.'
);
ppm_test_assert(
    strpos($handler_source,'PPM679_WP::server_instance_id(')===false,
    'Precheck must never call server_instance_id.'
);
foreach (array(
    'PPM679_Pipeline::',
    'generate_all(',
    'check_all(',
    'create_drafts(',
    'insert_draft(',
    'update_option(',
    'delete_option(',
    'wp_remote_',
    'curl_',
    'file_put_contents('
) as $forbidden) {
    ppm_test_assert(strpos($handler_source,$forbidden)===false,'Health handler must exclude write/pipeline token: '.$forbidden);
}

ppm_health_reset();
PPM679_WP::set_test_can_manage(false);
$_POST=array('_wpnonce'=>'test-nonce');
$before=ppm_health_snapshot();
$result=PPM679_Admin::handle_health_check();
ppm_test_assert(($result['status']??'')==='BLOCKED_HEALTH_CHECK_CAPABILITY','Capability denial must block.');
ppm_health_assert_unchanged($before,'Capability denial must perform zero writes.');

ppm_health_reset();
$_POST=array();
$before=ppm_health_snapshot();
$result=PPM679_Admin::handle_health_check();
ppm_test_assert(($result['status']??'')==='BLOCKED_HEALTH_CHECK_NONCE','Missing nonce must block.');
ppm_test_assert(($result['reason']??'')==='HEALTH_CHECK_NONCE_MISSING','Missing nonce reason must be exact.');
ppm_health_assert_unchanged($before,'Missing nonce must perform zero writes.');

ppm_health_reset();
$_POST=array('_wpnonce'=>'invalid');
$before=ppm_health_snapshot();
$result=PPM679_Admin::handle_health_check();
ppm_test_assert(($result['status']??'')==='BLOCKED_HEALTH_CHECK_NONCE','Invalid nonce must block.');
ppm_test_assert(($result['reason']??'')==='HEALTH_CHECK_NONCE_INVALID','Invalid nonce reason must be exact.');
ppm_health_assert_unchanged($before,'Invalid nonce must perform zero writes.');

ppm_health_reset();
$_POST=array('_wpnonce'=>'test-nonce');
$before=ppm_health_snapshot();
$result=PPM679_Admin::handle_health_check();
ppm_test_assert(($result['status']??'')==='BLOCKED_HEALTH_STATE_NOT_INITIALIZED','Missing server ID must block.');
ppm_test_assert(PPM679_WP::get_option('ppm_server_instance_id','')==='','Missing server ID must not be generated.');
ppm_health_assert_unchanged($before,'Missing server ID must perform zero writes.');

ppm_health_reset();
PPM679_WP::update_option('ppm_server_instance_id','ppm-5e2ef7a9-5a11-4682-85f7-cf94d86a59ee');
PPM679_WP::update_option('ppm679_schema_version','6.7.9');
PPM679_WP::update_option('ppm_publish_enabled','0');
$_POST=array('_wpnonce'=>'test-nonce');
$before=ppm_health_snapshot();
$result=PPM679_Admin::handle_health_check();
ppm_test_assert(($result['contract']??'')==='ppm_health_v1','Health contract must be exact.');
ppm_test_assert(($result['status']??'')==='STRUCTURAL_CHECK_OK','Health status must be exact.');
ppm_test_assert((($result['build_integrity']['status']??'')==='PASS'),'Health must report signed build-integrity PASS.');
ppm_test_assert((int)($result['build_integrity']['error_count']??-1)===0,'Health build-integrity error count must be zero.');
ppm_test_assert((bool)preg_match('/^[a-f0-9]{64}$/',(string)($result['build_integrity']['manifest_sha256']??'')),'Health must expose the active build-manifest SHA-256.');
ppm_test_assert(array_key_exists('journal_runtime',$result),'Health must expose the read-only journal runtime snapshot.');
ppm_test_assert(array_key_exists('editorial_plan',$result),'Health must expose the read-only editorial-plan summary.');
ppm_test_assert(($result['publish_allowed']??null)===false,'Publish must remain false.');
ppm_test_assert(($result['rest_write_route_registered']??null)===false,'REST write route must remain false.');
ppm_test_assert(($result['server_instance_id']??'')==='ppm-5e2ef7a9-5a11-4682-85f7-cf94d86a59ee','Existing server ID must be returned unchanged.');
ppm_health_assert_unchanged($before,'Successful health handler must perform zero writes.');

ppm_health_reset();
PPM679_WP::update_option('ppm_server_instance_id','ppm-5e2ef7a9-5a11-4682-85f7-cf94d86a59ee');
PPM679_WP::update_option('ppm679_schema_version','6.7.9');
PPM679_WP::update_option('ppm_publish_enabled','0');
PPM679_WP::update_option('ppm679_last_error',array(
    'status'=>'BLOCKED_EXISTING_TEST_ERROR',
    'errors'=>array(array('reason'=>'Existing diagnostic must not be deleted by health POST.'))
));
$_POST=array(
    'ppm679_health_check'=>'1',
    '_wpnonce'=>'test-nonce'
);
$before=ppm_health_snapshot();
ob_start();
PPM679_Admin::page();
$page=ob_get_clean();
ppm_test_assert(strpos($page,'Schreibfreien Health-Check ausführen')!==false,'Separate health button must render.');
ppm_test_assert(strpos($page,'STRUCTURAL_CHECK_OK')!==false,'Health JSON must render on same page.');
ppm_test_assert(strpos($page,'Vier-Typ-Test bis Draft-Readback ausführen')!==false,'Existing Draft-Readback button must remain visible.');
ppm_test_assert(PPM679_WP::get_option('ppm679_last_error',null)!==null,'Health POST must not delete existing diagnostic.');
ppm_health_assert_unchanged($before,'Full health page POST must perform zero writes.');


// Negative proof: a broken detached signature must be surfaced by the read-only health check and must perform zero WordPress writes.
ppm_health_reset();
$sig_path=dirname(__DIR__).'/certification/build-manifest-v1.sig';
$original_sig=(string)file_get_contents($sig_path);
$before=ppm_health_snapshot();
try {
    file_put_contents($sig_path,base64_encode(str_repeat("\0",64))."\n");
    $broken_sig=PPM679_Admin::health();
} finally {
    file_put_contents($sig_path,$original_sig);
}
ppm_test_assert(($broken_sig['status']??'')==='BLOCKED_BUILD_SIGNATURE_INVALID','Invalid Ed25519 signature must block read-only health.');
ppm_test_assert((($broken_sig['build_integrity']['status']??'')==='BLOCKED'),'Invalid signature must be reported as blocked build-integrity.');
ppm_health_assert_unchanged($before,'Signature-negative health proof must perform zero WordPress writes.');

// Negative proof: a signed-scope active file hash drift must also be surfaced without writes.
ppm_health_reset();
$fixture_path=dirname(__DIR__).'/fixtures/editorial-plan/journal-runtime-snapshot-user-declared-v1.json';
$original_fixture=(string)file_get_contents($fixture_path);
$before=ppm_health_snapshot();
try {
    file_put_contents($fixture_path,$original_fixture."\n");
    $broken_hash=PPM679_Admin::health();
} finally {
    file_put_contents($fixture_path,$original_fixture);
}
ppm_test_assert(($broken_hash['status']??'')==='BLOCKED_ACTIVE_COMPONENT_HASH_MISMATCH','Signed-scope file hash drift must block read-only health.');
ppm_test_assert((($broken_hash['build_integrity']['status']??'')==='BLOCKED'),'File hash drift must be reported as blocked build-integrity.');
ppm_health_assert_unchanged($before,'Hash-negative health proof must perform zero WordPress writes.');

$report=array(
    'contract'=>'ppm679_read_only_health_button_test_v1',
    'status'=>'PASS',
    'cases'=>array(
        'capability_denied_zero_write'=>'PASS',
        'nonce_missing_zero_write'=>'PASS',
        'nonce_invalid_zero_write'=>'PASS',
        'server_id_missing_zero_write'=>'PASS',
        'valid_health_zero_write'=>'PASS',
        'page_render_zero_write'=>'PASS',
        'precheck_uses_get_option'=>'PASS',
        'precheck_excludes_server_instance_id'=>'PASS',
        'four_type_ui_unchanged'=>'PASS',
        'signed_build_integrity_positive'=>'PASS',
        'invalid_signature_blocked_zero_write'=>'PASS',
        'active_file_hash_drift_blocked_zero_write'=>'PASS',
        'journal_runtime_exposed_read_only'=>'PASS'
    ),
    'write_counters'=>array(
        'database_write_count'=>0,
        'option_write_count'=>0,
        'network_write_count'=>0,
        'transient_write_count'=>0,
        'file_write_count'=>0,
        'post_write_count'=>0,
        'wordpress_draft_count'=>0,
        'publish_count'=>0
    )
);
echo json_encode($report,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n";
