<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Live_State_Gate {
    const VERSION = '6.7.9';
    const TABLE_PLUGIN = 'canonical-table-contract-v1/canonical-table-contract-v1.php';
    const TABLE_PLUGIN_VERSION = '1.1.0';

    public static function state($context) {
        $registry = PPM679_Storage::registry_state();
        $contract_files = array(
            'article_type' => 'contracts/article-type-templates.json',
            'gold_core' => 'contracts/gold-core-binding-v1.json',
            'content_vault' => 'contracts/content-vault-manifest-v1.json',
            'table' => 'contracts/table-contract-v1.json',
            'diagnostic' => 'contracts/diagnostic-contract-v3.json',
            'live_gate' => 'contracts/live-state-gate-v1.json',
            'plan' => 'contracts/production-plan-v4.json',
            'general' => 'contracts/general-production-contract-v679.json',
        );
        $hashes = array();
        foreach ($contract_files as $key=>$relative) {
            $file = PPM679_PLUGIN_DIR . $relative;
            $hashes[$key] = is_file($file) ? hash_file('sha256',$file) : null;
        }
        $active = PPM679_WP::active_plugins();
        $state = array(
            'plugin_version' => defined('PPM679_VERSION') ? PPM679_VERSION : null,
            'runtime_version' => self::VERSION,
            'schema_version' => (string) PPM679_WP::get_option('ppm679_schema_version',''),
            'server_instance_id' => PPM679_WP::server_instance_id(),
            'publish_enabled' => (string) PPM679_WP::get_option('ppm_publish_enabled','0'),
            'active_plugins' => $active,
            'table_plugin_active' => in_array(self::TABLE_PLUGIN,$active,true),
            'table_plugin_version' => PPM679_WP::plugin_version(self::TABLE_PLUGIN),
            'contract_hashes' => $hashes,
            'registry' => $registry,
        );
        $state['server_state_hash'] = PPM679_Diagnostic::stable_hash($state);
        $state['context'] = (string)$context;
        $state['generated_at'] = gmdate('c');
        return $state;
    }

    public static function verify_live_state_or_abort($action_context, $artifact_hash = '', $expected_stage = null, $run = null, $requirements = array()) {
        $state = self::state($action_context);
        $hash = $state['server_state_hash'];
        $errors = array();

        if ((string)$state['plugin_version'] !== self::VERSION) {
            $errors[] = self::err('BLOCKED_PLUGIN_VERSION_MISMATCH','ACTIVE_PLUGIN_VERSION_MUST_EQUAL_RUNTIME_VERSION','state.plugin_version',self::VERSION,$state['plugin_version'],'Geladene Plugin- und Runtimeversion stimmen nicht überein.',$action_context,$hash);
        }
        if ((string)$state['runtime_version'] !== self::VERSION) {
            $errors[] = self::err('BLOCKED_RUNTIME_VERSION_MISMATCH','RUNTIME_VERSION_MUST_EQUAL_RELEASE_VERSION','state.runtime_version',self::VERSION,$state['runtime_version'],'Die aktive Runtime besitzt nicht die freigegebene Version.',$action_context,$hash);
        }
        if ((string)$state['schema_version'] !== self::VERSION) {
            $errors[] = self::err('BLOCKED_SCHEMA_VERSION_MISMATCH','SCHEMA_VERSION_MUST_EQUAL_RELEASE_VERSION','state.schema_version',self::VERSION,$state['schema_version'],'Das explizit aufgebaute Produktionsschema ist nicht auf dem aktiven Stand.',$action_context,$hash);
        }
        if ((string)$state['publish_enabled'] !== '0') {
            $errors[] = self::err('BLOCKED_PUBLISH_MODE_ENABLED','PUBLISH_MUST_REMAIN_DISABLED','state.publish_enabled','0',$state['publish_enabled'],'Veröffentlichung ist während des Vier-Typ-Tests zwingend deaktiviert.',$action_context,$hash);
        }
        if (!$state['table_plugin_active']) {
            $errors[] = self::err('BLOCKED_CANONICAL_TABLE_PLUGIN_INACTIVE','CANONICAL_TABLE_PLUGIN_MUST_BE_ACTIVE','state.table_plugin_active',true,false,'Der freigegebene Tabellenvertrag ist auf dem Zielsystem nicht aktiv.',$action_context,$hash);
        }
        if ((string)$state['table_plugin_version'] !== self::TABLE_PLUGIN_VERSION) {
            $errors[] = self::err('BLOCKED_CANONICAL_TABLE_PLUGIN_VERSION','CANONICAL_TABLE_PLUGIN_VERSION_MUST_MATCH','state.table_plugin_version',self::TABLE_PLUGIN_VERSION,$state['table_plugin_version'],'Die aktive Tabellenvertragsversion weicht von der gebundenen Version ab.',$action_context,$hash);
        }
        if (!is_string($artifact_hash) || !preg_match('/^[a-f0-9]{64}$/',$artifact_hash)) {
            $errors[] = self::err('BLOCKED_ARTIFACT_HASH_INVALID','ACTION_ARTIFACT_HASH_MUST_BE_SHA256','action.artifact_hash','64 lowercase hexadecimal characters',$artifact_hash,'Die Aktion ist nicht an einen eindeutigen Artefakthash gebunden.',$action_context,$hash);
        }

        foreach ($state['contract_hashes'] as $name=>$contract_hash) {
            if (!is_string($contract_hash) || !preg_match('/^[a-f0-9]{64}$/',$contract_hash)) {
                $errors[] = self::err('BLOCKED_ACTIVE_CONTRACT_MISSING','EVERY_ACTIVE_CONTRACT_MUST_EXIST_AND_BE_HASHED','state.contract_hashes.'.$name,'sha256',$contract_hash,'Ein aktiver Vertrag fehlt oder ist nicht hashbar.',$action_context,$hash);
            }
        }

        $expected_contracts=array(
            'contracts/article-type-templates.json'=>array('contract'=>'article_type_templates_v2','version'=>'2.0.0'),
            'contracts/diagnostic-contract-v3.json'=>array('contract'=>'ppm_diagnostic_contract_v3','version'=>'6.7.9'),
            'contracts/general-production-contract-v679.json'=>array('contract'=>'general_production_machine_v679','version'=>'6.7.9'),
            'contracts/live-state-gate-v1.json'=>array('contract'=>'ppm_live_state_pre_commit_gate_v1','version'=>'6.7.9'),
            'contracts/production-plan-v4.json'=>array('contract'=>'production_plan_v4','version'=>'4.0.0'),
            'contracts/table-contract-v1.json'=>array('contract'=>'canonical_table_contract_v1','version'=>'1.1.0'),
        );
        foreach ($expected_contracts as $relative=>$expected_contract) {
            $file=PPM679_PLUGIN_DIR.$relative;
            $decoded=is_file($file)?json_decode((string)file_get_contents($file),true):null;
            $actual_contract=is_array($decoded)?(string)($decoded['contract']??''):'';
            $actual_version=is_array($decoded)?(string)($decoded['version']??''):'';
            if ($actual_contract!==$expected_contract['contract'] || $actual_version!==$expected_contract['version']) {
                $errors[] = self::err(
                    'BLOCKED_ACTIVE_CONTRACT_VERSION_MISMATCH',
                    'EVERY_ACTIVE_CONTRACT_NAME_AND_VERSION_MUST_MATCH_RELEASE_MANIFEST',
                    $relative,
                    $expected_contract,
                    array('contract'=>$actual_contract,'version'=>$actual_version),
                    'Mindestens ein aktiver Vertrag besitzt einen veralteten oder gemischten Versionsstand.',
                    $action_context,
                    $hash
                );
            }
        }

        $errors = array_merge($errors, PPM679_Build_Integrity::verify($action_context,$hash));
        $errors = array_merge($errors, PPM679_Article_Type_Extension_Registry::validate_manifest($action_context,$hash));
        $article_type_release_scope=isset($requirements['article_type_release_scope'])?$requirements['article_type_release_scope']:null;
        if ($article_type_release_scope!==null) {
            $scope_contract=is_array($article_type_release_scope)?(string)($article_type_release_scope['contract']??''):'';
            if ($scope_contract===PPM679_G9_FAQ_Test_Release_Validator::CONTRACT) {
                $errors = array_merge($errors, PPM679_G9_FAQ_Test_Release_Validator::validate($action_context,$hash,$article_type_release_scope));
            } elseif (class_exists('PPM679_Three_Type_Live_Test_Release_Validator') && $scope_contract===PPM679_Three_Type_Live_Test_Release_Validator::CONTRACT) {
                $errors = array_merge($errors, PPM679_Three_Type_Live_Test_Release_Validator::validate($action_context,$hash,$article_type_release_scope));
            } elseif (class_exists('PPM679_Normal_Draft_Release_Validator') && $scope_contract===PPM679_Normal_Draft_Release_Validator::CONTRACT) {
                $errors = array_merge($errors, PPM679_Normal_Draft_Release_Validator::validate($action_context,$hash,$article_type_release_scope));
            } else {
                $errors[] = self::err('BLOCKED_UNKNOWN_ARTICLE_TYPE_RELEASE_SCOPE','ARTICLE_TYPE_RELEASE_SCOPE_MUST_BE_EXPLICITLY_SUPPORTED','requirements.article_type_release_scope.contract','known exact scope',$scope_contract,'Ein unbekannter Release-Scope wird fail-closed blockiert.',$action_context,$hash);
            }
        } else {
            $errors = array_merge($errors, PPM679_Article_Type_Validator::validate($action_context,$hash));
        }

        $registry_integrity=PPM679_Storage::registry_integrity();
        if (empty($registry_integrity['ok'])) {
            $errors[] = self::err(
                'BLOCKED_REGISTRY_INTEGRITY',
                'REGISTRY_LIFECYCLE_AND_IDENTIFIER_TOMBSTONES_MUST_BE_COMPLETE',
                'state.registry.integrity',
                array('invalid_lifecycle_count'=>0,'missing_tombstone_count'=>0),
                $registry_integrity,
                'Das operative Register enthält einen ungültigen Lifecycle-Zustand oder einen Identifier ohne permanenten Tombstone.',
                $action_context,
                $hash
            );
        }

        $gold_file=PPM679_PLUGIN_DIR.'contracts/gold-core-binding-v1.json';
        $gold=is_file($gold_file)?json_decode((string)file_get_contents($gold_file),true):null;
        if (!is_array($gold) || (string)($gold['four_type_gold_core_sha256']??'') !== (string)PPM679_GOLD_CORE_SHA256) {
            $errors[] = self::err('BLOCKED_GOLD_CORE_HASH_MISMATCH','GOLD_CORE_HASH_MUST_MATCH_IMMUTABLE_BINDING','contracts.gold_core.four_type_gold_core_sha256',PPM679_GOLD_CORE_SHA256,is_array($gold)?($gold['four_type_gold_core_sha256']??null):null,'Der aktive Vier-Typ-Goldkern ist nicht an den unveränderlichen Referenzhash gebunden.',$action_context,$hash);
        }

        $vault_file=PPM679_PLUGIN_DIR.'contracts/content-vault-manifest-v1.json';
        $vault=is_file($vault_file)?json_decode((string)file_get_contents($vault_file),true):null;
        if (!is_array($vault) || (string)($vault['vault_total_hash']??'') !== (string)PPM679_CONTENT_VAULT_SHA256) {
            $errors[] = self::err('BLOCKED_CONTENT_VAULT_HASH_MISMATCH','CONTENT_VAULT_MANIFEST_MUST_MATCH_IMMUTABLE_BASELINE','contracts.content_vault.vault_total_hash',PPM679_CONTENT_VAULT_SHA256,is_array($vault)?($vault['vault_total_hash']??null):null,'Der freigegebene Content-Vault weicht von der Build-Baseline ab.',$action_context,$hash);
        }

        if ($expected_stage !== null) {
            $actual_stage = is_array($run) ? (string)($run['stage']??'') : '';
            if ($actual_stage !== (string)$expected_stage) {
                $errors[] = self::err('BLOCKED_NEXT_STEP_STATE_MISMATCH','ACTION_MUST_MATCH_EXACT_CURRENT_RUN_STAGE','run.stage',(string)$expected_stage,$actual_stage,'Die angeforderte Aktion ist für den aktuellen Laufzustand nicht zulässig.',$action_context,$hash);
            }
        }

        if (!empty($requirements['server_instance_id']) && (string)$requirements['server_instance_id'] !== (string)$state['server_instance_id']) {
            $errors[] = self::err('BLOCKED_SERVER_INSTANCE_MISMATCH','SERVER_INSTANCE_MUST_MATCH_BOUND_BASELINE','state.server_instance_id',(string)$requirements['server_instance_id'],$state['server_instance_id'],'Die Aktion ist an eine andere Serverinstanz gebunden.',$action_context,$hash);
        }

        if (!empty($requirements['required_user_status'])) {
            $bound_hash = isset($requirements['content_hash']) ? (string)$requirements['content_hash'] : '';
            $acceptances = PPM679_WP::get_option('ppm679_user_acceptances',array());
            $actual_status = is_array($acceptances) && isset($acceptances[$bound_hash]) ? (string)$acceptances[$bound_hash] : '';
            if ($actual_status !== (string)$requirements['required_user_status']) {
                $errors[] = self::err('BLOCKED_USER_ACCEPTANCE_MISSING','IRREVERSIBLE_ACTION_REQUIRES_USER_ACCEPTED_FOR_EXACT_CONTENT_HASH','user_acceptance.'.$bound_hash,(string)$requirements['required_user_status'],$actual_status,'Für den exakten Inhalts-Hash liegt keine ausdrückliche Nutzerfreigabe vor.',$action_context,$hash);
            }
        }

        if ($errors) {
            return array(
                'ok'=>false,
                'state'=>$state,
                'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,$action_context,$hash)
            );
        }

        return array(
            'ok'=>true,
            'state'=>$state,
            'report'=>PPM679_Diagnostic::ok('LIVE_STATE_MATCH_OK',$action_context,$hash,array(
                'artifact_hash'=>$artifact_hash,
                'registry_hash'=>$state['registry']['registry_hash']
            ))
        );
    }

    private static function err($code,$rule,$path,$expected,$actual,$reason,$context,$hash) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$context,$hash,__CLASS__,null,array('contracts/live-state-gate-v1.json'));
    }
}
