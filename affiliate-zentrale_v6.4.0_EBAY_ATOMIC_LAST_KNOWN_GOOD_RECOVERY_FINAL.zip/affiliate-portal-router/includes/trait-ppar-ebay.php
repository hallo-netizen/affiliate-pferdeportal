<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * V5.6.0 – eBay Browse API / EPN: resumierbarer Hintergrundabruf, Pagination, Prüfbestand, Listing-Lifecycle und Backend-Filter.
 *
 * Harte Routingregeln:
 * - INDIVIDUAL wird ausschließlich als hp_listing unter der konfigurierten
 *   HivePress-Wurzel "Private Anzeigen" materialisiert.
 * - BUSINESS wird ausschließlich als reales Produkt-Creative in die bestehende
 *   Werbemittelbibliothek übernommen und danach über das zentrale Output-Modell
 *   gegen echte Portalziele und Designslots geplant.
 * - CLASSIFIED_AD, fehlende Affiliate-URLs, abgelaufene Angebote, abweichende
 *   Verkäuferkontotypen und andere Marktplätze werden fail-closed blockiert.
 */
trait PPAR_Ebay_Trait {

    /** V4.2.0 – vollständiger, fest mitgelieferter Pferde-Atelier-Zielkatalog. */
    private function ebay_portal_catalog() {
        static $catalog = null;
        if (is_array($catalog)) { return $catalog; }
        $asset_dir = dirname(__DIR__) . '/assets/';
        $path = $asset_dir . 'ebay-portal-catalog-v2.json';
        $source_path = $asset_dir . 'portal-structure-v279.json';
        if (!is_readable($path) || !is_readable($source_path)) {
            return new WP_Error('ebay_portal_catalog_missing', 'Pferde-Atelier-eBay-Zielkatalog oder Portalquelle fehlt.');
        }
        $decoded = json_decode((string) file_get_contents($path), true);
        if (!is_array($decoded) || (string) ($decoded['schema'] ?? '') !== '2.0') {
            return new WP_Error('ebay_portal_catalog_invalid', 'Pferde-Atelier-eBay-Zielkatalog ist ungültig.');
        }
        $expected_source_hash = strtolower(sanitize_text_field((string) ($decoded['source_sha256'] ?? '')));
        $actual_source_hash = hash_file('sha256', $source_path);
        if (!preg_match('/^[a-f0-9]{64}$/', $expected_source_hash) || !is_string($actual_source_hash) || !hash_equals($expected_source_hash, strtolower($actual_source_hash))) {
            return new WP_Error('ebay_portal_catalog_source_mismatch', 'Pferde-Atelier-eBay-Zielkatalog stimmt nicht mit der mitgelieferten Portalstruktur überein.');
        }
        $counts = is_array($decoded['counts'] ?? null) ? $decoded['counts'] : array();
        $required_counts = array('main_hubs'=>8, 'hub_pages'=>59, 'product_pages'=>329, 'article_categories'=>1124);
        foreach ($required_counts as $key=>$expected) {
            if (absint($counts[$key] ?? 0) !== $expected) {
                return new WP_Error('ebay_portal_catalog_incomplete', 'Pferde-Atelier-eBay-Zielkatalog ist unvollständig: ' . sanitize_key($key));
            }
        }
        $products = array_values((array) ($decoded['product_targets'] ?? array()));
        $articles = array_values((array) ($decoded['article_targets'] ?? array()));
        $rules = array_values((array) ($decoded['search_rules'] ?? array()));
        if (count($products) !== 329 || count($articles) !== 1124 || count($rules) !== 8) {
            return new WP_Error('ebay_portal_catalog_count_mismatch', 'Pferde-Atelier-eBay-Zielkatalog stimmt nicht mit den Sollzahlen überein.');
        }
        $allowed_buckets = array('pferde-ponys','sattel-zaumzeug','decken-schutz','stall-weide-haltung','fuetterung-pflege','anhaenger-transport','reitbekleidung-zubehoer','sonstiges');
        $product_slugs = array();
        foreach ($products as $target) {
            if (!is_array($target)) { return new WP_Error('ebay_portal_product_invalid', 'Ungültiges Produktziel im Pferde-Atelier-Katalog.'); }
            $slug = sanitize_title((string) ($target['slug'] ?? ''));
            $bucket = sanitize_title((string) ($target['private_bucket_slug'] ?? ''));
            if ($slug === '' || empty($target['title']) || empty($target['hub']) || empty($target['main_hub']) || !in_array($bucket, $allowed_buckets, true) || isset($product_slugs[$slug])) {
                return new WP_Error('ebay_portal_product_invalid', 'Unvollständiges, doppeltes oder ungültig geroutetes Produktziel: ' . $slug);
            }
            $product_slugs[$slug] = true;
        }
        $article_slugs = array();
        foreach ($articles as $target) {
            if (!is_array($target)) { return new WP_Error('ebay_portal_article_invalid', 'Ungültiges WordPress-Kategorieziel im Pferde-Atelier-Katalog.'); }
            $slug = sanitize_title((string) ($target['category_slug'] ?? ''));
            $product_slug = sanitize_title((string) ($target['product_slug'] ?? ''));
            if ($slug === '' || empty($target['category_name']) || !isset($product_slugs[$product_slug]) || isset($article_slugs[$slug])) {
                return new WP_Error('ebay_portal_article_invalid', 'Unvollständige, doppelte oder verwaiste WordPress-Kategorie: ' . $slug);
            }
            $article_slugs[$slug] = true;
        }
        $rule_ids = array();
        foreach ($rules as $rule) {
            $id = sanitize_key((string) ($rule['id'] ?? ''));
            $bucket = sanitize_title((string) ($rule['target_term_slug'] ?? ''));
            if ($id === '' || empty($rule['query']) || !in_array($bucket, $allowed_buckets, true) || isset($rule_ids[$id])) {
                return new WP_Error('ebay_portal_rule_invalid', 'Ungültiges automatisches eBay-Abrufprofil: ' . $id);
            }
            $rule_ids[$id] = true;
        }
        if (count(array_values(array_filter((array) ($decoded['strong_horse_markers'] ?? array())))) < 10 || empty($decoded['hard_negative_markers'])) {
            return new WP_Error('ebay_portal_markers_incomplete', 'Fach- oder Ausschlussmarker des eBay-Zielkatalogs fehlen.');
        }
        if (count((array) ($decoded['private_bucket_profiles'] ?? array())) !== 8 || count((array) ($decoded['business_concepts'] ?? array())) < 300 || empty($decoded['content_policy']['version'])) {
            return new WP_Error('ebay_portal_workflow_contract_incomplete', 'eBay-Workflow-V2-Vertrag im Zielkatalog ist unvollständig.');
        }
        $catalog = $decoded;
        return $catalog;
    }

    private function ebay_catalog_rules() {
        $catalog = $this->ebay_portal_catalog();
        if (is_wp_error($catalog)) { return array(); }
        return $this->ebay_normalize_rules((array) ($catalog['search_rules'] ?? array()));
    }

    private function ebay_catalog_integrity() {
        $catalog = $this->ebay_portal_catalog();
        if (is_wp_error($catalog)) { return $catalog; }
        return array(
            'main_hubs'=>absint($catalog['counts']['main_hubs'] ?? 0),
            'hub_pages'=>absint($catalog['counts']['hub_pages'] ?? 0),
            'product_pages'=>absint($catalog['counts']['product_pages'] ?? 0),
            'article_categories'=>absint($catalog['counts']['article_categories'] ?? 0),
            'source_sha256'=>sanitize_text_field((string) ($catalog['source_sha256'] ?? '')),
        );
    }

    private function ebay_topic_text($value) {
        $value = wp_strip_all_tags((string) $value);
        if (function_exists('remove_accents')) { $value = remove_accents($value); }
        $value = strtolower($value);
        $value = str_replace('&', ' und ', $value);
        $value = preg_replace('/[^a-z0-9]+/', ' ', $value);
        return trim(preg_replace('/\s+/', ' ', (string) $value));
    }

    private function ebay_topic_tokens($value) {
        $stop = array_flip(array('und','oder','der','die','das','den','dem','des','ein','eine','einer','eines','fuer','mit','von','im','in','am','an','zu','zur','zum','bei','auf','aus','neu','gebraucht','set','paar','stueck','original'));
        $tokens = array();
        foreach (preg_split('/\s+/', $this->ebay_topic_text($value)) as $token) {
            if ($token === '' || strlen($token) < 3 || isset($stop[$token])) { continue; }
            $tokens[$token] = $token;
        }
        return array_values($tokens);
    }

    private function ebay_topic_stem($token) {
        $token = $this->ebay_topic_text($token);
        if (strlen($token) < 6) { return $token; }
        foreach (array('ern','em','en','er','es','e','n','s') as $suffix) {
            if (substr($token, -strlen($suffix)) === $suffix && strlen($token) - strlen($suffix) >= 5) {
                return substr($token, 0, -strlen($suffix));
            }
        }
        return $token;
    }

    private function ebay_topic_term_present($text, $term) {
        $text = $this->ebay_topic_text($text);
        $term = $this->ebay_topic_text($term);
        if ($text === '' || $term === '') { return false; }
        if (strpos(' ' . $text . ' ', ' ' . $term . ' ') !== false) { return true; }
        $text_tokens = $this->ebay_topic_tokens($text);
        foreach ($this->ebay_topic_tokens($term) as $term_token) {
            foreach ($text_tokens as $text_token) {
                if ($term_token === $text_token) { return true; }
                if (strlen($term_token) >= 5 && strlen($text_token) >= 5 && (strpos($term_token, $text_token) !== false || strpos($text_token, $term_token) !== false)) { return true; }
            }
        }
        return false;
    }

    /** Ausschlussmarker dürfen nur vom Angebotstoken getragen werden, nie umgekehrt. */
    private function ebay_topic_negative_present($text, $marker) {
        $text = $this->ebay_topic_text($text);
        $marker = $this->ebay_topic_text($marker);
        if ($text === '' || $marker === '') { return false; }
        if (strpos(' ' . $text . ' ', ' ' . $marker . ' ') !== false) { return true; }
        $marker_tokens = $this->ebay_topic_tokens($marker);
        if (count($marker_tokens) !== 1) { return false; }
        $needle = (string) $marker_tokens[0];
        if (strlen($needle) < 4) { return false; }
        foreach ($this->ebay_topic_tokens($text) as $token) {
            if ($token === $needle || strpos($token, $needle) !== false) { return true; }
        }
        return false;
    }

    private function ebay_item_topic_evidence($item) {
        $raw = is_array($item['raw'] ?? null) ? $item['raw'] : array();
        $category_names = array();
        foreach ((array) ($raw['categories'] ?? array()) as $category) {
            if (is_array($category) && !empty($category['categoryName'])) { $category_names[] = sanitize_text_field((string) $category['categoryName']); }
        }
        $aspects = array();
        foreach ((array) ($raw['localizedAspects'] ?? array()) as $aspect) {
            if (!is_array($aspect)) { continue; }
            $aspects[] = sanitize_text_field((string) ($aspect['name'] ?? ''));
            $aspects[] = sanitize_text_field((string) ($aspect['value'] ?? ''));
        }
        return trim(implode(' ', array_filter(array(
            (string) ($item['title'] ?? ''),
            (string) ($item['short_description'] ?? ''),
            implode(' ', $category_names),
            implode(' ', $aspects),
        ))));
    }

    /** Content-policy brands are exact tokens/phrases, never fuzzy substrings. */
    private function ebay_content_policy_exact_term_present($text, $term) {
        $text = $this->ebay_topic_text((string) $text);
        $term = $this->ebay_topic_text((string) $term);
        if ($text === '' || $term === '') { return false; }
        if (strpos(' ' . $text . ' ', ' ' . $term . ' ') !== false) { return true; }
        $term_tokens = $this->ebay_topic_tokens($term);
        if (count($term_tokens) !== 1) { return false; }
        $needle = (string) $term_tokens[0];
        foreach ($this->ebay_topic_tokens($text) as $token) {
            if ($token === $needle) { return true; }
        }
        return false;
    }

    /**
     * V5.26 – providernahe Hard-Safety gegen Spielzeug/Modellware.
     * Diese Sperre liegt absichtlich VOR der fachlichen Zielklassifikation und
     * gilt identisch fuer INDIVIDUAL und BUSINESS. Damit kann ein Titel wie
     * "Playmobil Pferd mit Sattel" nicht allein wegen Pferd/Sattel durchrutschen.
     * Generische Woerter wie "Figur" werden nicht alleine gesperrt; ausschlaggebend
     * sind eindeutige Marken, Produktphrasen oder reale eBay-Spielzeugkategorien.
     */
    /**
     * Workflow V2 content policy. Policy data lives in the catalog, not in
     * version-specific PHP patches. Category/aspect evidence wins over title
     * heuristics; known toy/model signatures remain a secondary hard block.
     */
    private function ebay_content_policy_reason($item) {
        $catalog = $this->ebay_portal_catalog();
        if (is_wp_error($catalog)) { return 'Content-Policy-Katalog fehlt.'; }
        $policy = is_array($catalog['content_policy'] ?? null) ? $catalog['content_policy'] : array();
        $item = is_array($item) ? $item : array();
        $raw = is_array($item['raw'] ?? null) ? $item['raw'] : $item;
        $title = $this->ebay_topic_text((string) ($raw['title'] ?? ($item['title'] ?? '')));
        $description = $this->ebay_topic_text((string) ($raw['shortDescription'] ?? ($item['short_description'] ?? '')));
        $category_parts = array();
        foreach ((array) ($raw['categories'] ?? array()) as $category) {
            if (is_array($category)) { $category_parts[] = (string) ($category['categoryName'] ?? ''); }
        }
        foreach ((array) ($item['category_names'] ?? array()) as $category_name) { $category_parts[] = (string) $category_name; }
        $aspect_parts = array();
        foreach ((array) ($raw['localizedAspects'] ?? array()) as $aspect) {
            if (!is_array($aspect)) { continue; }
            $aspect_parts[] = (string) ($aspect['name'] ?? '');
            $aspect_parts[] = (string) ($aspect['value'] ?? '');
        }
        $category_text = $this->ebay_topic_text(implode(' ', $category_parts));
        $aspect_text = $this->ebay_topic_text(implode(' ', $aspect_parts));
        $all = trim(implode(' ', array_filter(array($title, $description, $category_text, $aspect_text))));
        if ($all === '') { return ''; }

        foreach ((array) ($policy['blocked_category_phrases'] ?? array()) as $marker) {
            $needle = $this->ebay_topic_text($marker);
            if ($needle !== '' && (
                strpos(' ' . $category_text . ' ', ' ' . $needle . ' ') !== false
                || strpos(' ' . $aspect_text . ' ', ' ' . $needle . ' ') !== false
            )) { return 'eBay-Kategorie/Merkmal ist fachfremde Spielzeug-/Modellware: ' . sanitize_text_field((string) $marker); }
        }
        foreach ((array) ($policy['blocked_brand_phrases'] ?? array()) as $marker) {
            if ($this->ebay_content_policy_exact_term_present($all, $marker)) { return 'Spielzeug-/Modellmarke erkannt: ' . sanitize_text_field((string) $marker); }
        }
        foreach ((array) ($policy['blocked_title_phrases'] ?? array()) as $marker) {
            $needle = $this->ebay_topic_text($marker);
            if ($needle !== '' && strpos(' ' . $all . ' ', ' ' . $needle . ' ') !== false) { return 'Spielzeug-/Modellprodukt erkannt: ' . sanitize_text_field((string) $marker); }
        }
        return '';
    }

    /** Compatibility wrapper for historical callers/tests. */
    private function ebay_toy_filter_reason($item) {
        return $this->ebay_content_policy_reason($item);
    }

    /**
     * Public-output safety net: re-evaluate the central policy from the stored
     * original eBay payload. This is deliberately read-only and independent of
     * maintenance/classifier cursors, so a legacy/current-contract row can never
     * stay public merely because an older pass stamped an allowed state.
     */
    private function ebay_public_content_policy_reason_from_source_row($row, $fallback_title = '') {
        $row = is_array($row) ? $row : array();
        $payload = json_decode((string)($row['source_payload'] ?? ''), true);
        $payload = is_array($payload) ? $payload : array();
        $raw = is_array($payload['raw'] ?? null) ? $payload['raw'] : array();
        if ($raw) {
            return $this->ebay_content_policy_reason(array(
                'raw'=>$raw,
                'title'=>(string)($row['title'] ?? $fallback_title),
                'short_description'=>(string)($row['short_description'] ?? ''),
            ));
        }
        return $this->ebay_content_policy_reason(array('title'=>(string)($row['title'] ?? $fallback_title)));
    }

    /** One bounded query for the PRIVATE public loop; no per-card source SQL. */
    private function ebay_public_source_rows_by_item_ids($item_ids, $seller_type = '') {
        $item_ids = array_values(array_unique(array_filter(array_map('sanitize_text_field', (array)$item_ids))));
        if (!$item_ids) { return array(); }
        global $wpdb;
        if (!is_object($wpdb) || !method_exists($wpdb, 'prepare') || !method_exists($wpdb, 'get_results')) { return array(); }
        $table = $this->ebay_items_table();
        if ($table === '') { return array(); }
        $placeholders = implode(',', array_fill(0, count($item_ids), '%s'));
        $args = $item_ids;
        $seller_type = strtoupper(sanitize_key((string)$seller_type));
        $where_seller = '';
        if (in_array($seller_type, array('INDIVIDUAL','BUSINESS'), true)) {
            $where_seller = ' AND seller_account_type=%s';
            $args[] = $seller_type;
        }
        $sql = $wpdb->prepare(
            "SELECT * FROM {$table} WHERE item_id IN ({$placeholders}){$where_seller} ORDER BY id DESC",
            $args
        );
        $rows = (array)$wpdb->get_results($sql, ARRAY_A);
        $out = array();
        foreach ($rows as $row) {
            if (!is_array($row)) { continue; }
            $item_id = sanitize_text_field((string)($row['item_id'] ?? ''));
            if ($item_id !== '' && !isset($out[$item_id])) { $out[$item_id] = $row; }
        }
        return $out;
    }

    private function ebay_quarantine_filtered_row($row, $reason) {
        $row = is_array($row) ? $row : array();
        $id = absint($row['id'] ?? 0);
        if ($id <= 0) { return false; }
        $reason = sanitize_text_field((string) $reason);
        if ($reason === '') { $reason = 'Spielzeug-/Modellware ist im Pferde-Atelier nicht freigegeben.'; }
        global $wpdb;
        $quarantine_update = array(
            'status'=>'blocked_content','source_state'=>'available','policy_state'=>'blocked','route_state'=>'blocked','output_state'=>'blocked',
            'policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,'rejection_reason'=>'[ebay_content_policy_blocked] ' . $reason,
            'fresh_until'=>0,'updated_at'=>time(),
        );
        $wpdb->update($this->ebay_items_table(), $quarantine_update, array('id'=>$id), $this->ebay_db_formats($quarantine_update), array('%d'));

        $seller_type = strtoupper(sanitize_key((string) ($row['seller_account_type'] ?? '')));
        if ($seller_type === 'INDIVIDUAL') {
            $listing_id = absint($row['listing_post_id'] ?? 0);
            if ($listing_id > 0) {
                if (function_exists('get_post_status') && get_post_status($listing_id) === 'publish' && function_exists('wp_update_post')) {
                    wp_update_post(array('ID'=>$listing_id,'post_status'=>'draft'));
                }
                if (function_exists('update_post_meta')) {
                    update_post_meta($listing_id, '_ppar_ebay_lifecycle_state', 'blocked_content');
                    update_post_meta($listing_id, '_ppar_ebay_block_reason', $reason);
                }
            }
        } elseif ($seller_type === 'BUSINESS') {
            $hash = strtolower(sanitize_text_field((string) ($row['creative_identity_hash'] ?? '')));
            $creative_table = method_exists($this, 'creative_library_table') ? $this->creative_library_table() : '';
            if (!preg_match('/^[a-f0-9]{64}$/', $hash) && $creative_table !== '') {
                $fallback = $wpdb->get_row($wpdb->prepare(
                    "SELECT identity_hash FROM {$creative_table} WHERE provider='ebay' AND source_kind='ebay_business_item' AND external_id=%s ORDER BY id DESC LIMIT 1",
                    (string) ($row['item_id'] ?? '')
                ), ARRAY_A);
                $fallback_hash = strtolower(sanitize_text_field((string) ($fallback['identity_hash'] ?? '')));
                if (preg_match('/^[a-f0-9]{64}$/', $fallback_hash)) { $hash = $fallback_hash; }
            }
            if (preg_match('/^[a-f0-9]{64}$/', $hash) && $creative_table !== '') {
                $creative = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$creative_table} WHERE identity_hash=%s", $hash), ARRAY_A);
                if (is_array($creative)) {
                    $payload = json_decode((string) ($creative['payload'] ?? ''), true);
                    $payload = is_array($payload) ? $payload : array();
                    $payload['_content_filter_state'] = 'blocked_toy_model';
                    $payload['_content_filter_reason'] = $reason;
                    $payload['_content_filter_at'] = time();
                    $wpdb->update($creative_table, array(
                        'source_status'=>'blocked',
                        'availability_state'=>'blocked_content',
                        'review_status'=>'rejected',
                        'selected'=>0,
                        'content_scope'=>'other',
                        'scope_source'=>'ebay_content_filter',
                        'topic_status'=>'blocked',
                        'topic_score'=>0,
                        'payload'=>wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    ), array('id'=>absint($creative['id'] ?? 0)));
                }
                if (method_exists($this, 'output_objects_table')) {
                    $output_table = $this->output_objects_table();
                    $objects = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$output_table} WHERE creative_identity_hash=%s", $hash), ARRAY_A);
                    foreach ((array) $objects as $object) {
                        if (method_exists($this, 'output_deactivate_materialized_object')) {
                            $this->output_deactivate_materialized_object($object, $reason);
                        }
                    }
                    $wpdb->update($output_table, array(
                        'status'=>'blocked_source',
                        'decision_source'=>'ebay_content_filter',
                        'decision_reason'=>$reason,
                        'updated_at'=>time(),
                    ), array('creative_identity_hash'=>$hash));
                }
            }
        }
        return true;
    }

    /**
     * Bestehende Altimporte werden lokal und ohne eBay-Request nachgeprueft.
     * Der Cursor macht die Migration wiederaufnehmbar; kein Listing/Creative wird
     * geloescht. Nur eindeutig erkannte Spielzeug-/Modellware wird deaktiviert.
     */
    public function maybe_run_ebay_content_filter_upgrade() {
        // Workflow V2 compatibility only. Historical admin-page rescans were a
        // root cause of hidden mutations. The authoritative maintenance state is
        // now produced exclusively by run_ebay_maintenance_v2().
        $state = get_option(self::OPTION_EBAY_MAINTENANCE_STATE, array());
        return is_array($state) ? $state : array();
    }

    /** Normalisierte Evidenzfelder fuer PRIVATE/BUSINESS-Klassifikation. */
    private function ebay_workflow_evidence_sections($item) {
        $item = is_array($item) ? $item : array();
        $raw = is_array($item['raw'] ?? null) ? $item['raw'] : array();
        $categories = array();
        foreach ((array) ($raw['categories'] ?? array()) as $category) {
            if (is_array($category) && !empty($category['categoryName'])) { $categories[] = (string) $category['categoryName']; }
        }
        foreach ((array) ($item['category_names'] ?? array()) as $category) { $categories[] = (string) $category; }
        $aspects = array();
        foreach ((array) ($raw['localizedAspects'] ?? array()) as $aspect) {
            if (!is_array($aspect)) { continue; }
            $aspects[] = (string) ($aspect['name'] ?? '');
            $aspects[] = (string) ($aspect['value'] ?? '');
        }
        return array(
            'title'=>$this->ebay_topic_text((string) ($item['title'] ?? ($raw['title'] ?? ''))),
            'category'=>$this->ebay_topic_text(implode(' ', array_filter($categories))),
            'aspects'=>$this->ebay_topic_text(implode(' ', array_filter($aspects))),
            'description'=>$this->ebay_topic_text((string) ($item['short_description'] ?? ($raw['shortDescription'] ?? ''))),
        );
    }

    private function ebay_private_phrase_present($text, $phrase) {
        $text = $this->ebay_topic_text((string) $text);
        $phrase = $this->ebay_topic_text((string) $phrase);
        if ($text === '' || $phrase === '') { return false; }
        if (strpos(' ' . $text . ' ', ' ' . $phrase . ' ') !== false) { return true; }
        $needle_tokens = $this->ebay_topic_tokens($phrase);
        if (count($needle_tokens) !== 1) { return false; }
        $needle = (string) $needle_tokens[0];
        if (strlen($needle) < 5) { return false; }
        $stem = $this->ebay_topic_stem($needle);
        foreach ($this->ebay_topic_tokens($text) as $token) {
            if (strlen($token) >= 5 && $this->ebay_topic_stem($token) === $stem) { return true; }
        }
        return false;
    }

    /**
     * Workflow V2 PRIVATE routing. PRIVATE has exactly eight coarse HivePress
     * destinations. It must never be classified through the 329 product pages.
     * Search profiles are only a weak prior; real title/category/aspect evidence
     * is mandatory for an automatic route.
     */
    public function ebay_classify_portal_item($item, $rule) {
        $catalog = $this->ebay_portal_catalog();
        if (is_wp_error($catalog)) { return $catalog; }
        $item = is_array($item) ? $item : array();
        $rule = is_array($rule) ? $rule : array();
        $policy_reason = $this->ebay_content_policy_reason($item);
        if ($policy_reason !== '') { return new WP_Error('ebay_content_policy_blocked', $policy_reason); }

        $evidence = $this->ebay_item_topic_evidence($item);
        $normalized = $this->ebay_topic_text($evidence);
        if ($normalized === '') { return new WP_Error('ebay_topic_evidence_missing', 'eBay-Angebot enthaelt keine verwertbare Fachinformation.'); }
        $strong_horse_hits = array();
        foreach ((array) ($catalog['strong_horse_markers'] ?? array()) as $marker) {
            if ($this->ebay_topic_term_present($normalized, $marker)) { $strong_horse_hits[] = sanitize_text_field((string) $marker); }
        }
        if (!$strong_horse_hits) { return new WP_Error('ebay_portal_topic_missing', 'Kein expliziter Pferde-/Reitsportbezug im realen eBay-Angebot.'); }
        foreach ((array) ($catalog['hard_negative_markers'] ?? array()) as $marker) {
            if ($this->ebay_topic_negative_present($normalized, $marker)) {
                return new WP_Error('ebay_portal_topic_negative', 'Fachfremdes Ausschlusssignal im eBay-Angebot: ' . sanitize_text_field((string) $marker));
            }
        }

        // Workflow V2 root rule: if the real eBay facts identify one canonical
        // product concept unambiguously, PRIVATE uses that concept only to pick
        // one of the eight coarse HivePress buckets. It never routes through a
        // WordPress product page. Generic/unclear items fall back to the coarse
        // bucket vocabulary below.
        $concept_match = $this->ebay_business_classify_portal_item_strict($item, $rule);
        if (!is_wp_error($concept_match) && !empty($concept_match['product_concept_id'])) {
            $concept_id = sanitize_key((string) $concept_match['product_concept_id']);
            foreach ((array) ($catalog['business_concepts'] ?? array()) as $concept) {
                if (!is_array($concept) || sanitize_key((string) ($concept['id'] ?? '')) !== $concept_id) { continue; }
                $concept_bucket = sanitize_title((string) ($concept['private_bucket_slug'] ?? ''));
                if ($concept_bucket !== '' && isset($catalog['private_bucket_profiles'][$concept_bucket])) {
                    $label = sanitize_text_field((string) ($catalog['private_bucket_profiles'][$concept_bucket]['label'] ?? $concept_bucket));
                    return array(
                        'status'=>'ready','score'=>min(100, max(1, absint($concept_match['score'] ?? 100))),
                        'product_slug'=>'','product_title'=>'','hub'=>'Private Anzeigen','main_hub'=>'Anzeigenmarkt',
                        'path'=>'Private Anzeigen > ' . $label,'private_bucket_slug'=>$concept_bucket,
                        'strong_horse_hits'=>$strong_horse_hits,'hits'=>(array) ($concept_match['hits'] ?? array()),
                        'evidence_hash'=>hash('sha256', $normalized . '|private-concept-v2|' . $concept_id),
                        'private_match_contract'=>'bucket_v2','private_match_source'=>'canonical_product_concept',
                    );
                }
                break;
            }
        }

        $sections = $this->ebay_workflow_evidence_sections($item);
        $profiles = is_array($catalog['private_bucket_profiles'] ?? null) ? $catalog['private_bucket_profiles'] : array();
        $rule_bucket = sanitize_title((string) ($rule['target_term_slug'] ?? $rule['id'] ?? ''));
        $ranked = array();
        foreach ($profiles as $bucket=>$profile) {
            if (!is_array($profile)) { continue; }
            $bucket = sanitize_title((string) $bucket);
            $score = 0; $hits = array(); $real_hits = 0;
            $phrases = array_values(array_unique(array_filter(array_merge((array) ($profile['strong_phrases'] ?? array()), (array) ($profile['phrases'] ?? array())))));
            $strong_map = array();
            foreach ((array) ($profile['strong_phrases'] ?? array()) as $p) { $strong_map[$this->ebay_topic_text($p)] = true; }
            foreach ($phrases as $phrase) {
                $norm_phrase = $this->ebay_topic_text($phrase);
                if ($norm_phrase === '') { continue; }
                $strong = isset($strong_map[$norm_phrase]);
                $sources = array();
                if ($this->ebay_private_phrase_present($sections['title'], $phrase)) { $score += $strong ? 60 : 35; $sources[]='title'; }
                if ($this->ebay_private_phrase_present($sections['category'], $phrase)) { $score += $strong ? 45 : 28; $sources[]='category'; }
                if ($this->ebay_private_phrase_present($sections['aspects'], $phrase)) { $score += $strong ? 35 : 22; $sources[]='aspect'; }
                if (!$sources && $this->ebay_private_phrase_present($sections['description'], $phrase)) { $score += $strong ? 8 : 4; $sources[]='description'; }
                if ($sources) { $hits[$norm_phrase] = implode('+', $sources); $real_hits++; }
            }

            if ($bucket === 'pferde-ponys') {
                $title_animal = false; $category_animal = false;
                foreach ((array) ($profile['phrases'] ?? array()) as $phrase) {
                    if ($this->ebay_private_phrase_present($sections['title'], $phrase)) { $title_animal = true; }
                    if ($this->ebay_private_phrase_present($sections['category'], $phrase)) { $category_animal = true; }
                }
                if (!$title_animal || !$category_animal) { $score = 0; $real_hits = 0; }
                else { $score += 80; }
            }

            // Search rule is deliberately not evidence; it may only break a close tie.
            if ($real_hits > 0 && $bucket === $rule_bucket) { $score += 8; }
            if ($real_hits <= 0) { continue; }
            $ranked[] = array(
                'bucket'=>$bucket,
                'label'=>sanitize_text_field((string) ($profile['label'] ?? $bucket)),
                'score'=>$score,
                'min_score'=>max(1, absint($profile['min_score'] ?? 55)),
                'min_margin'=>max(0, absint($profile['min_margin'] ?? 12)),
                'hits'=>$hits,
            );
        }
        usort($ranked, static function($a,$b){ return ((int)$b['score'] <=> (int)$a['score']) ?: strcmp((string)$a['bucket'],(string)$b['bucket']); });
        if (!$ranked) { return new WP_Error('ebay_private_bucket_missing', 'Kein belastbarer Private-Anzeigen-Fachbereich aus realen Angebotsdaten erkannt.'); }
        $best = $ranked[0]; $second = $ranked[1] ?? null;
        if ((int) $best['score'] < (int) $best['min_score']) {
            return new WP_Error('ebay_private_bucket_low_confidence', 'Private-Anzeigen-Fachbereich ist nicht belastbar genug.');
        }
        if (is_array($second) && ((int)$best['score'] - (int)$second['score']) < (int)$best['min_margin']) {
            return new WP_Error('ebay_private_bucket_ambiguous', 'Private-Anzeigen-Fachbereich ist nicht eindeutig genug: ' . sanitize_key((string)$best['bucket']) . ' / ' . sanitize_key((string)$second['bucket']) . '.');
        }
        return array(
            'status'=>'ready',
            'score'=>min(100, max(1, (int) $best['score'])),
            'product_slug'=>'',
            'product_title'=>'',
            'hub'=>'Private Anzeigen',
            'main_hub'=>'Anzeigenmarkt',
            'path'=>'Private Anzeigen > ' . (string) $best['label'],
            'private_bucket_slug'=>(string) $best['bucket'],
            'strong_horse_hits'=>$strong_horse_hits,
            'hits'=>(array) $best['hits'],
            'evidence_hash'=>hash('sha256', $normalized . '|private-v2|' . (string)$best['bucket']),
            'private_match_contract'=>'bucket_v2',
        );
    }

    /**
     * V5.28 – fail-closed BUSINESS-Zielklassifikation.
     *
     * Die allgemeine Portal-Klassifikation bleibt fuer PRIVATE unveraendert.
     * BUSINESS darf dagegen nur dann automatisch einen Produktslot gewinnen,
     * wenn der konkrete Produktbegriff im realen Angebotstitel getragen wird
     * und die uebrigen eBay-Fakten diesen Treffer nicht widersprechen.
     * Generische Pferde-/Reitsportbegriffe, Farben, "Zubehoer" oder reine
     * Beschreibungstreffer duerfen kein Produktziel mehr erzeugen.
     */
    private function ebay_business_match_stop_tokens() {
        return array_flip(array(
            'pferd','pferde','pony','ponys','fohlen','reiter','reiten','reit','reitsport','equestrian',
            'zubehor','zubehoer','artikel','angebot','angebote','produkt','produkte','set','sets','original','universal',
            'neu','gebraucht','damen','herren','kinder','schwarz','braun','blau','rot','grun','gruen','weiss','weis','beige',
            'grosse','groesse','size','cm','mm','kg','stuck','stueck','paar','fur','fuer','mit','ohne'
        ));
    }

    private function ebay_business_distinctive_tokens($text) {
        $stop = $this->ebay_business_match_stop_tokens();
        $tokens = array();
        foreach ($this->ebay_topic_tokens((string) $text) as $token) {
            $token = $this->ebay_topic_text($token);
            if ($token === '' || strlen($token) < 3 || isset($stop[$token])) { continue; }
            $tokens[$token] = $token;
        }
        return array_values($tokens);
    }

    /** Strikter Tokenvergleich: nur identisch oder derselbe Wortstamm, niemals Teilstring. */
    private function ebay_business_strict_token_present($text, $needle) {
        $needle = $this->ebay_topic_text((string) $needle);
        if ($needle === '') { return false; }
        $needle_stem = $this->ebay_topic_stem($needle);
        foreach ($this->ebay_topic_tokens((string) $text) as $token) {
            $token = $this->ebay_topic_text($token);
            if ($token === $needle) { return true; }
            if (strlen($needle) >= 5 && strlen($token) >= 5 && $this->ebay_topic_stem($token) === $needle_stem) { return true; }
        }
        return false;
    }

    /**
     * German eBay categories often carry the product family as a compound
     * (e.g. "Pferdedecken", "Sattelzubehör"). For corroboration only, a
     * sufficiently long hub token may therefore occur at the beginning/end of
     * a category/aspect token. This is never used as the primary product match.
     */
    private function ebay_business_context_token_present($text, $needle) {
        if ($this->ebay_business_strict_token_present($text, $needle)) { return true; }
        $needle = $this->ebay_topic_text((string) $needle);
        if (strlen($needle) < 5) { return false; }
        foreach ($this->ebay_topic_tokens((string) $text) as $token) {
            $token = $this->ebay_topic_text($token);
            if (strlen($token) <= strlen($needle)) { continue; }
            if (strpos($token, $needle) === 0 || substr($token, -strlen($needle)) === $needle) { return true; }
        }
        return false;
    }

    /**
     * Hub-Fallback fuer konkrete Produktfamilien, die im Portal selbst auf Ebene 2
     * routbar sind (z.B. ein normaler Sattel), aber keinen eigenen Leaf-Eintrag
     * besitzen. Der Titel muss den Hub als eigenes Wort oder als deutsches
     * Produktkompositum mit Hub-Suffix tragen; Kategorie/Aspekte muessen denselben
     * Fachbegriff unabhaengig bestaetigen. Reine Praefix-Nennungen wie
     * "Sattelgurt" gelten deshalb NICHT als "Sattel".
     */
    private function ebay_business_hub_title_token_present($text, $needle) {
        if ($this->ebay_business_strict_token_present($text, $needle)) { return true; }
        $needle = $this->ebay_topic_text((string) $needle);
        if (strlen($needle) < 5) { return false; }
        foreach ($this->ebay_topic_tokens((string) $text) as $token) {
            $token = $this->ebay_topic_text($token);
            if (strlen($token) <= strlen($needle) + 2) { continue; }
            if (substr($token, -strlen($needle)) === $needle) { return true; }
        }
        return false;
    }

    private function ebay_business_hub_concept_candidates($catalog, $sections) {
        $ranked = array();
        foreach ((array) ($catalog['business_hub_concepts'] ?? array()) as $concept) {
            if (!is_array($concept)) { continue; }
            $tokens = $this->ebay_business_distinctive_tokens((string) ($concept['title'] ?? ''));
            if (!$tokens) { continue; }
            $title_hits = 0; $context_hits = 0; $hits = array();
            foreach ($tokens as $token) {
                if ($this->ebay_business_hub_title_token_present($sections['title'], $token)) {
                    $title_hits++;
                    $hits[$token] = 'title';
                }
                if ($this->ebay_business_context_token_present($sections['category'] . ' ' . $sections['aspects'], $token)) {
                    $context_hits++;
                    $hits[$token] = isset($hits[$token]) ? $hits[$token] . '+context' : 'context';
                }
            }
            // Hub-Routing ist bewusst strenger als Leaf-Routing: alle Hub-Tokens
            // muessen vom Titel getragen werden und mindestens eines davon muss
            // durch reale eBay-Kategorie/Aspekte bestaetigt sein.
            if ($title_hits !== count($tokens) || $context_hits < 1) { continue; }

            if (!empty($concept['requires_main_context'])) {
                $main_hits = 0;
                $primary = is_array($concept['target_pages'][0] ?? null) ? $concept['target_pages'][0] : array();
                foreach ($this->ebay_business_distinctive_tokens((string) ($primary['main_hub'] ?? '')) as $main_token) {
                    if ($this->ebay_business_context_token_present(
                        $sections['title'] . ' ' . $sections['category'] . ' ' . $sections['aspects'],
                        $main_token
                    )) { $main_hits++; }
                }
                if ($main_hits < 1) { continue; }
            }

            $phrase = $this->ebay_topic_text((string) ($concept['title'] ?? ''));
            $phrase_title = $phrase !== '' && strpos(' ' . $sections['title'] . ' ', ' ' . $phrase . ' ') !== false;
            $concept['raw_score'] = 180 + ($title_hits * 45) + ($context_hits * 25) + ($phrase_title ? 40 : 0);
            $concept['confidence'] = min(100, 82 + ($context_hits * 8) + ($phrase_title ? 10 : 0));
            $concept['hits'] = array_keys($hits);
            $concept['hit_sources'] = $hits;
            $ranked[] = $concept;
        }
        usort($ranked, static function($a, $b) {
            $cmp = absint($b['raw_score'] ?? 0) <=> absint($a['raw_score'] ?? 0);
            if ($cmp !== 0) { return $cmp; }
            return strnatcasecmp((string) ($a['id'] ?? ''), (string) ($b['id'] ?? ''));
        });
        return $ranked;
    }

    private function ebay_business_evidence_sections($item) {
        return $this->ebay_workflow_evidence_sections($item);
    }

    /**
     * BUSINESS-spezifische Produktklassifikation gegen den vollstaendigen
     * Portal-Zielkatalog. Sie ist absichtlich konservativ: lieber Review als
     * eine fachlich falsche Produktkarte auf einer redaktionellen Seite.
     */
    private function ebay_business_classify_portal_item_strict($item, $rule) {
        $catalog = $this->ebay_portal_catalog();
        if (is_wp_error($catalog)) { return $catalog; }
        $item = is_array($item) ? $item : array();
        $rule = is_array($rule) ? $rule : array();
        $policy_reason = $this->ebay_content_policy_reason($item);
        if ($policy_reason !== '') { return new WP_Error('ebay_content_policy_blocked', $policy_reason); }

        $evidence = $this->ebay_item_topic_evidence($item);
        $normalized = $this->ebay_topic_text($evidence);
        if ($normalized === '') { return new WP_Error('ebay_topic_evidence_missing', 'eBay-Angebot enthaelt keine verwertbare Fachinformation.'); }
        $strong_horse_hits = array();
        foreach ((array) ($catalog['strong_horse_markers'] ?? array()) as $marker) {
            if ($this->ebay_topic_term_present($normalized, $marker)) { $strong_horse_hits[] = sanitize_text_field((string) $marker); }
        }
        if (!$strong_horse_hits) { return new WP_Error('ebay_portal_topic_missing', 'Kein expliziter Pferde-/Reitsportbezug im realen eBay-Angebot.'); }
        foreach ((array) ($catalog['hard_negative_markers'] ?? array()) as $marker) {
            if ($this->ebay_topic_negative_present($normalized, $marker)) {
                return new WP_Error('ebay_portal_topic_negative', 'Fachfremdes Ausschlusssignal im eBay-Angebot: ' . sanitize_text_field((string) $marker));
            }
        }

        $sections = $this->ebay_business_evidence_sections($item);
        if ($sections['title'] === '') { return new WP_Error('ebay_business_title_missing', 'BUSINESS-Angebot besitzt keinen verwertbaren Produkttitel.'); }
        $ranked = array();
        foreach ((array) ($catalog['business_concepts'] ?? array()) as $concept) {
            if (!is_array($concept)) { continue; }
            $tokens = $this->ebay_business_distinctive_tokens((string) ($concept['title'] ?? ''));
            if (!$tokens) { continue; }
            $title_hits = $category_hits = $aspect_hits = $description_hits = 0;
            $covered = array(); $hit_tokens = array();
            foreach ($tokens as $token) {
                $sources = array();
                if ($this->ebay_business_strict_token_present($sections['title'], $token)) { $title_hits++; $covered[$token]=true; $sources[]='title'; }
                if ($this->ebay_business_strict_token_present($sections['category'], $token)) { $category_hits++; $covered[$token]=true; $sources[]='category'; }
                if ($this->ebay_business_strict_token_present($sections['aspects'], $token)) { $aspect_hits++; $covered[$token]=true; $sources[]='aspect'; }
                if ($this->ebay_business_strict_token_present($sections['description'], $token)) { $description_hits++; $sources[]='description'; }
                if ($sources) { $hit_tokens[$token]=implode('+',$sources); }
            }
            $token_count = count($tokens);
            $core_coverage = count($covered);
            $required_coverage = $token_count <= 1 ? 1 : (int) ceil($token_count * 0.67);
            $concept_phrase = $this->ebay_topic_text((string) ($concept['title'] ?? ''));
            $phrase_title = $concept_phrase !== '' && strpos(' ' . $sections['title'] . ' ', ' ' . $concept_phrase . ' ') !== false;
            $hub_hits = 0;
            foreach ((array) ($concept['target_pages'] ?? array()) as $page) {
                foreach (array((string) ($page['hub'] ?? ''), (string) ($page['main_hub'] ?? '')) as $context_label) {
                    foreach ($this->ebay_business_distinctive_tokens($context_label) as $hub_token) {
                        if ($this->ebay_business_context_token_present($sections['category'] . ' ' . $sections['aspects'], $hub_token)) { $hub_hits++; }
                    }
                }
            }
            if ($title_hits < 1 || $core_coverage < $required_coverage) { continue; }
            // Workflow V2 root rule: a one-token concept is too easy to mention as
            // accessory/context (e.g. "Panik-Haken ... Zubehör Führstrick").
            // Therefore a one-token title hit needs independent category/aspect or
            // target-hub corroboration. Missing corroboration goes to Review rather
            // than placing the wrong product card. Multi-token concepts keep the
            // stricter coverage requirement above.
            if ($token_count === 1 && ($category_hits + $aspect_hits + $hub_hits) < 1) { continue; }
            $raw_score = ($phrase_title ? 120 : 0)
                + ($title_hits * 42) + ($category_hits * 18) + ($aspect_hits * 14) + ($description_hits * 3)
                + ($core_coverage === $token_count ? 24 : 0) + min(24, $hub_hits * 8);
            $confidence = 55 + min(30, $title_hits * 15) + min(10, ($category_hits + $aspect_hits) * 5)
                + ($phrase_title ? 10 : 0) + ($core_coverage === $token_count ? 10 : 0);
            $confidence = min(100, $confidence);
            if ($confidence < 80) { continue; }
            $concept['raw_score']=$raw_score; $concept['confidence']=$confidence;
            $concept['hits']=array_keys($hit_tokens); $concept['hit_sources']=$hit_tokens;
            $ranked[]=$concept;
        }
        usort($ranked, static function($a,$b){
            $cmp=absint($b['raw_score']??0)<=>absint($a['raw_score']??0);
            if($cmp!==0){return $cmp;}
            $cmp=absint($b['confidence']??0)<=>absint($a['confidence']??0);
            return $cmp!==0?$cmp:strnatcasecmp((string)($a['id']??''),(string)($b['id']??''));
        });
        // Leaf-Produkte haben immer Vorrang. Nur wenn dort KEIN belastbarer
        // Kandidat existiert, darf ein expliziter, streng bestaetigter Hub als
        // eigenstaendige Produktfamilie einspringen.
        if (!$ranked) { $ranked = $this->ebay_business_hub_concept_candidates($catalog, $sections); }
        if (!$ranked) { return new WP_Error('ebay_business_concept_missing', 'Kein belastbarer konkreter Produktbegriff oder routbares Produktfamilien-Ziel im eBay-BUSINESS-Titel gefunden.'); }
        $best=$ranked[0]; $second=$ranked[1]??null;
        if (is_array($second)) {
            $margin=absint($best['raw_score']??0)-absint($second['raw_score']??0);
            if ($margin < 25) {
                return new WP_Error('ebay_business_concept_ambiguous', 'BUSINESS-Produktkonzept ist nicht eindeutig genug: ' . sanitize_key((string)($best['id']??'')) . ' / ' . sanitize_key((string)($second['id']??'')) . '.');
            }
        }
        $pages=array_values(array_filter((array)($best['target_pages']??array()),'is_array'));
        if (!$pages) { return new WP_Error('ebay_business_concept_target_missing', 'Produktkonzept besitzt kein Portalziel.'); }
        $primary=$pages[0];
        $target_slugs=array_values(array_unique(array_filter(array_map(static function($p){return sanitize_title((string)($p['slug']??''));},$pages))));
        $path=implode(' > ',array_filter(array((string)($primary['main_hub']??''),(string)($primary['hub']??''),(string)($best['title']??''))));
        return array(
            'status'=>'ready','score'=>absint($best['confidence']??0),
            'product_concept_id'=>sanitize_key((string)($best['id']??'')),
            'concept_kind'=>sanitize_key((string)($best['concept_kind']??'product')),
            'product_slug'=>sanitize_title((string)($primary['slug']??'')),
            'product_target_slugs'=>$target_slugs,
            'product_title'=>sanitize_text_field((string)($best['title']??'')),
            'hub'=>sanitize_text_field((string)($primary['hub']??'')),
            'main_hub'=>sanitize_text_field((string)($primary['main_hub']??'')),
            'path'=>$path,
            'private_bucket_slug'=>sanitize_title((string)($best['private_bucket_slug']??($primary['private_bucket_slug']??''))),
            'strong_horse_hits'=>$strong_horse_hits,'hits'=>(array)($best['hits']??array()),'hit_sources'=>(array)($best['hit_sources']??array()),
            'evidence_hash'=>hash('sha256',$normalized.'|business-concept-v3|'.sanitize_key((string)($best['id']??''))),
            'business_match_contract'=>'concept_v3',
        );
    }

    private function ebay_items_table() {
        global $wpdb;
        return $wpdb->prefix . 'ppar_ebay_items';
    }

    public function ebay_settings_defaults() {
        return array(
            'schema' => '1.2',
            'enabled' => false,
            'environment' => 'production',
            'client_id' => '',
            'client_secret' => '',
            'epn_campaign_id' => '',
            'affiliate_reference_prefix' => 'pferde-atelier',
            'marketplace_id' => 'EBAY_DE',
            'delivery_country' => 'DE',
            'delivery_postal_code' => '',
            'private_enabled' => true,
            'business_enabled' => true,
            'private_parent_term_id' => 0,
            'private_root_term_id' => 0,
            'private_post_status' => 'draft',
            'private_auto_publish' => false,
            'private_target_per_category' => 24,
            'private_max_per_category' => 30,
            'private_listing_author_id' => 0,
            'api_terms_confirmed' => false,
            'privacy_policy_confirmed' => false,
            'stale_hours' => 6,
            'sync_interval_hours' => 3,
            'inventory_refresh_enabled' => true,
            'inventory_refresh_max_per_run' => 1200,
            'max_per_rule' => 50,
            'max_pages_per_profile' => 4,
            'max_requests_per_run' => 40,
            'run_time_budget_seconds' => 20,
            'rules' => $this->ebay_catalog_rules(),
            'catalog_verified_sha256' => '',
            'catalog_verified_at' => 0,
            'last_test' => array(),
            'last_sync' => array(),
            'last_refresh' => array(),
        );
    }

    public function ebay_default_rules() {
        return $this->ebay_catalog_rules();
    }

    private function ebay_settings() {
        $stored = get_option(self::OPTION_NETWORK_EBAY, array());
        $stored = is_array($stored) ? $stored : array();
        $settings = $this->ebay_normalize_settings(array_merge($this->ebay_settings_defaults(), $stored), true);
        // Zugangsdaten können sicherer außerhalb der Datenbank in wp-config.php
        // hinterlegt werden. Definierte Konstanten haben immer Vorrang.
        if (defined('PPAR_EBAY_CLIENT_ID') && trim((string) PPAR_EBAY_CLIENT_ID) !== '') {
            $settings['client_id'] = substr(sanitize_text_field((string) PPAR_EBAY_CLIENT_ID), 0, 255);
        }
        if (defined('PPAR_EBAY_CLIENT_SECRET') && trim((string) PPAR_EBAY_CLIENT_SECRET) !== '') {
            $settings['client_secret'] = substr(trim((string) PPAR_EBAY_CLIENT_SECRET), 0, 255);
        }
        if (defined('PPAR_EBAY_EPN_CAMPAIGN_ID')) {
            $campaign = preg_replace('/\D+/', '', (string) PPAR_EBAY_EPN_CAMPAIGN_ID);
            if (strlen($campaign) === 10) { $settings['epn_campaign_id'] = $campaign; }
        }
        return $settings;
    }

    public function ebay_normalize_settings($settings, $preserve_secret = true) {
        $defaults = $this->ebay_settings_defaults();
        $settings = is_array($settings) ? $settings : array();
        $out = $defaults;
        $out['enabled'] = !empty($settings['enabled']);
        $out['environment'] = in_array((string) ($settings['environment'] ?? ''), array('production','sandbox'), true) ? (string) $settings['environment'] : 'production';
        $out['client_id'] = substr(sanitize_text_field((string) ($settings['client_id'] ?? '')), 0, 255);
        $out['client_secret'] = $preserve_secret ? substr(trim((string) ($settings['client_secret'] ?? '')), 0, 255) : '';
        $campaign = preg_replace('/\D+/', '', (string) ($settings['epn_campaign_id'] ?? ''));
        $out['epn_campaign_id'] = strlen($campaign) === 10 ? $campaign : '';
        $prefix = sanitize_key((string) ($settings['affiliate_reference_prefix'] ?? 'pferde-atelier'));
        $out['affiliate_reference_prefix'] = $prefix !== '' ? substr($prefix, 0, 60) : 'pferde-atelier';
        $out['marketplace_id'] = 'EBAY_DE';
        $out['delivery_country'] = 'DE';
        $out['delivery_postal_code'] = substr(preg_replace('/[^0-9A-Za-z -]/', '', (string) ($settings['delivery_postal_code'] ?? '')), 0, 12);
        $out['private_enabled'] = !empty($settings['private_enabled']);
        $out['business_enabled'] = !empty($settings['business_enabled']);
        $out['private_parent_term_id'] = absint($settings['private_parent_term_id'] ?? 0);
        $out['private_root_term_id'] = absint($settings['private_root_term_id'] ?? 0);
        $out['private_post_status'] = 'draft';
        $out['private_auto_publish'] = !empty($settings['private_auto_publish']);
        $out['private_max_per_category'] = max(1, min(100, absint($settings['private_max_per_category'] ?? 30)));
        $out['private_target_per_category'] = max(1, min($out['private_max_per_category'], absint($settings['private_target_per_category'] ?? 24)));
        $out['private_listing_author_id'] = absint($settings['private_listing_author_id'] ?? 0);
        $out['api_terms_confirmed'] = !empty($settings['api_terms_confirmed']);
        $out['privacy_policy_confirmed'] = !empty($settings['privacy_policy_confirmed']);
        $out['stale_hours'] = 6;
        $out['sync_interval_hours'] = 3;
        $out['inventory_refresh_enabled'] = array_key_exists('inventory_refresh_enabled', $settings) ? !empty($settings['inventory_refresh_enabled']) : true;
        $out['inventory_refresh_max_per_run'] = max(1200, min(2000, absint($settings['inventory_refresh_max_per_run'] ?? 1200)));
        $out['max_per_rule'] = max(1, min(50, absint($settings['max_per_rule'] ?? 50)));
        $out['max_pages_per_profile'] = max(1, min(20, absint($settings['max_pages_per_profile'] ?? 4)));
        $out['max_requests_per_run'] = max(1, min(40, absint($settings['max_requests_per_run'] ?? 40)));
        $out['run_time_budget_seconds'] = max(10, min(30, absint($settings['run_time_budget_seconds'] ?? 20)));
        $out['rules'] = $this->ebay_catalog_rules();
        $verified_hash = strtolower(sanitize_text_field((string) ($settings['catalog_verified_sha256'] ?? '')));
        $out['catalog_verified_sha256'] = preg_match('/^[a-f0-9]{64}$/', $verified_hash) ? $verified_hash : '';
        $out['catalog_verified_at'] = absint($settings['catalog_verified_at'] ?? 0);
        $out['last_test'] = is_array($settings['last_test'] ?? null) ? $settings['last_test'] : array();
        $out['last_sync'] = is_array($settings['last_sync'] ?? null) ? $settings['last_sync'] : array();
        $out['last_refresh'] = is_array($settings['last_refresh'] ?? null) ? $settings['last_refresh'] : array();
        return $out;
    }

    public function ebay_normalize_rules($rules) {
        if (is_string($rules)) {
            $decoded = json_decode($rules, true);
            $rules = is_array($decoded) ? $decoded : array();
        }
        $safe = array();
        foreach ((array) $rules as $index => $rule) {
            if (!is_array($rule)) { continue; }
            $id = sanitize_key((string) ($rule['id'] ?? ''));
            $query = sanitize_text_field((string) ($rule['query'] ?? ''));
            $target = sanitize_title((string) ($rule['target_term_slug'] ?? ''));
            if ($id === '' || $query === '' || $target === '') { continue; }
            $categories = array();
            foreach ((array) ($rule['category_ids'] ?? array()) as $category_id) {
                $category_id = preg_replace('/\D+/', '', (string) $category_id);
                if ($category_id !== '') { $categories[$category_id] = $category_id; }
            }
            $safe[$id] = array(
                'id' => substr($id, 0, 80),
                'label' => substr(sanitize_text_field((string) ($rule['label'] ?? $id)), 0, 120),
                'query' => substr($query, 0, 100),
                'target_term_slug' => substr($target, 0, 120),
                'category_ids' => array_values(array_slice($categories, 0, 5)),
                'active' => !empty($rule['active']),
                'private' => !empty($rule['private']),
                'business' => !empty($rule['business']),
            );
            if (count($safe) >= 50) { break; }
        }
        return array_values($safe);
    }

    private function ebay_configuration_errors($settings = null) {
        $settings = is_array($settings) ? $settings : $this->ebay_settings();
        $errors = array();
        if (empty($settings['client_id'])) { $errors[] = 'eBay Client-ID fehlt.'; }
        if (empty($settings['client_secret'])) { $errors[] = 'eBay Client-Secret fehlt.'; }
        if (!preg_match('/^\d{10}$/', (string) ($settings['epn_campaign_id'] ?? ''))) { $errors[] = 'EPN-Campaign-ID muss exakt 10 Ziffern haben.'; }
        if ((string) ($settings['marketplace_id'] ?? '') !== 'EBAY_DE') { $errors[] = 'Das aktuelle eBay-Modul unterstützt ausschließlich EBAY_DE.'; }
        if (empty($settings['rules'])) { $errors[] = 'Mindestens eine gültige eBay-Regel fehlt.'; }
        $catalog = $this->ebay_catalog_integrity();
        if (is_wp_error($catalog)) { $errors[] = $catalog->get_error_message(); }
        elseif (empty($settings['catalog_verified_at']) || !hash_equals((string) ($catalog['source_sha256'] ?? ''), (string) ($settings['catalog_verified_sha256'] ?? ''))) {
            $errors[] = 'Portal- und Themenabgleich wurde für den aktuellen Katalog noch nicht bestätigt.';
        }
        if (empty($settings['private_enabled']) && empty($settings['business_enabled'])) { $errors[] = 'Mindestens eine Verkäuferroute muss aktiviert sein.'; }
        if (empty($settings['api_terms_confirmed'])) { $errors[] = 'Bestätigung der eBay-API-/EPN-Verträge fehlt.'; }
        if (empty($settings['privacy_policy_confirmed'])) { $errors[] = 'Bestätigung der Datenschutz-/Affiliate-Hinweise fehlt.'; }
        if ((string) ($settings['environment'] ?? 'production') === 'production') {
            if (!method_exists($this, 'ebay_deletion_compliance_snapshot')) {
                $errors[] = 'eBay Marketplace Account Deletion/Closure Compliance-Modul fehlt.';
            } else {
                $compliance = $this->ebay_deletion_compliance_snapshot();
                if (empty($compliance['https'])) { $errors[] = 'eBay Notification Endpoint ist nicht per HTTPS erreichbar konfiguriert.'; }
                if (empty($compliance['challenge_answered'])) { $errors[] = 'eBay Marketplace Account Deletion/Closure Challenge wurde noch nicht beantwortet.'; }
                if (empty($compliance['signed_notification_verified'])) { $errors[] = 'Noch keine signierte eBay Marketplace Account Deletion/Closure Testbenachrichtigung erfolgreich verifiziert.'; }
            }
        }
        if (!empty($settings['private_enabled']) && absint($settings['private_root_term_id'] ?? 0) <= 0) { $errors[] = 'HivePress-Bereich „Private Anzeigen“ ist nicht eingerichtet.'; }
        return $errors;
    }

    public function maybe_install_ebay_schema() {
        $installed = (string) get_option(self::OPTION_EBAY_SCHEMA_VERSION, '0');
        if ($installed === self::EBAY_SCHEMA_VERSION) { return; }
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        global $wpdb;
        $table = $this->ebay_items_table();
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            portal_key varchar(191) NOT NULL,
            item_id varchar(191) NOT NULL,
            legacy_item_id varchar(80) NOT NULL DEFAULT '',
            seller_account_type varchar(20) NOT NULL,
            seller_username varchar(191) NOT NULL DEFAULT '',
            route_mode varchar(40) NOT NULL,
            rule_id varchar(80) NOT NULL,
            target_term_id bigint(20) unsigned NOT NULL DEFAULT 0,
            listing_post_id bigint(20) unsigned NOT NULL DEFAULT 0,
            creative_identity_hash char(64) NOT NULL DEFAULT '',
            title text NOT NULL,
            short_description longtext NULL,
            condition_text text NOT NULL,
            price_value varchar(60) NOT NULL DEFAULT '',
            currency varchar(10) NOT NULL DEFAULT '',
            shipping_value varchar(60) NOT NULL DEFAULT '',
            location_text text NOT NULL,
            affiliate_url text NOT NULL,
            item_web_url text NOT NULL,
            image_url text NOT NULL,
            item_end_at bigint(20) unsigned NOT NULL DEFAULT 0,
            source_hash char(64) NOT NULL,
            source_payload longtext NULL,
            status varchar(30) NOT NULL DEFAULT 'active',
            source_state varchar(24) NOT NULL DEFAULT 'available',
            policy_state varchar(24) NOT NULL DEFAULT 'pending',
            route_state varchar(24) NOT NULL DEFAULT 'pending',
            output_state varchar(24) NOT NULL DEFAULT 'none',
            policy_version varchar(32) NOT NULL DEFAULT '',
            classifier_version varchar(32) NOT NULL DEFAULT '',
            source_checked_at bigint(20) unsigned NOT NULL DEFAULT 0,
            rejection_reason text NOT NULL,
            last_seen bigint(20) unsigned NOT NULL DEFAULT 0,
            fresh_until bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at bigint(20) unsigned NOT NULL DEFAULT 0,
            updated_at bigint(20) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY portal_item (portal_key(100), item_id(100)),
            KEY seller_status (seller_account_type, status),
            KEY route_status (route_mode, status),
            KEY workflow_source (source_state, source_checked_at),
            KEY workflow_policy (policy_state, policy_version),
            KEY workflow_route (route_state, classifier_version),
            KEY fresh_until (fresh_until),
            KEY listing_post_id (listing_post_id),
            KEY creative_hash (creative_identity_hash)
        ) {$charset};");
        update_option(self::OPTION_EBAY_SCHEMA_VERSION, self::EBAY_SCHEMA_VERSION, false);
    }

    public function ebay_cron_schedules($schedules) {
        if (!isset($schedules['ppar_three_hours'])) {
            $schedules['ppar_three_hours'] = array('interval'=>3 * HOUR_IN_SECONDS, 'display'=>'Alle drei Stunden');
        }
        return $schedules;
    }

    public function ensure_ebay_schedule() {
        if (!function_exists('wp_next_scheduled') || !function_exists('wp_schedule_event')) { return; }
        $settings = $this->ebay_settings();
        $scheduled = wp_next_scheduled(self::EBAY_CRON_HOOK);
        if (!empty($settings['enabled'])) {
            if (!$scheduled) { wp_schedule_event(time() + 300, 'ppar_three_hours', self::EBAY_CRON_HOOK); }
        } elseif ($scheduled && function_exists('wp_clear_scheduled_hook')) {
            wp_clear_scheduled_hook(self::EBAY_CRON_HOOK);
        }
    }

    public function reschedule_ebay_cron($force = false) {
        if ($force && function_exists('wp_clear_scheduled_hook')) { wp_clear_scheduled_hook(self::EBAY_CRON_HOOK); }
        $this->ensure_ebay_schedule();
    }

    public function ensure_ebay_refresh_schedule() {
        if (!function_exists('wp_next_scheduled') || !function_exists('wp_schedule_event')) { return; }
        $settings = $this->ebay_settings();
        $scheduled = wp_next_scheduled(self::EBAY_REFRESH_CRON_HOOK);
        $schedule_name = function_exists('wp_get_schedule') && $scheduled ? (string) wp_get_schedule(self::EBAY_REFRESH_CRON_HOOK) : '';
        if (!empty($settings['enabled']) && !empty($settings['inventory_refresh_enabled'])) {
            // V5.24: Discovery bleibt 3-stündlich. Der Frischeabgleich muss bei realen
            // Beständen von mehreren hundert Listings häufiger laufen, damit die harte
            // eBay-6h-Frist nicht durch eine zu kleine Queue gerissen wird.
            if (!$scheduled || $schedule_name !== 'hourly') {
                if ($scheduled && function_exists('wp_clear_scheduled_hook')) { wp_clear_scheduled_hook(self::EBAY_REFRESH_CRON_HOOK); }
                wp_schedule_event(time() + 60, 'hourly', self::EBAY_REFRESH_CRON_HOOK);
            }
        } elseif ($scheduled && function_exists('wp_clear_scheduled_hook')) {
            wp_clear_scheduled_hook(self::EBAY_REFRESH_CRON_HOOK);
        }
    }

    public function reschedule_ebay_refresh_cron($force = false) {
        if ($force && function_exists('wp_clear_scheduled_hook')) { wp_clear_scheduled_hook(self::EBAY_REFRESH_CRON_HOOK); }
        $this->ensure_ebay_refresh_schedule();
    }

    public function ensure_ebay_maintenance_schedule() {
        if (!function_exists('wp_next_scheduled') || !function_exists('wp_schedule_event')) { return; }
        $settings=$this->ebay_settings();
        $scheduled=wp_next_scheduled(self::EBAY_MAINTENANCE_CRON_HOOK);
        if(!empty($settings['enabled'])){
            if(!$scheduled){wp_schedule_event(time()+15,'hourly',self::EBAY_MAINTENANCE_CRON_HOOK);}
        } elseif($scheduled && function_exists('wp_clear_scheduled_hook')) { wp_clear_scheduled_hook(self::EBAY_MAINTENANCE_CRON_HOOK); }
    }

    public function reschedule_ebay_maintenance_cron($force = false) {
        if ($force && function_exists('wp_clear_scheduled_hook')) { wp_clear_scheduled_hook(self::EBAY_MAINTENANCE_CRON_HOOK); }
        $this->ensure_ebay_maintenance_schedule();
    }

    private function ebay_maintenance_state_is_current($state = null) {
        if (!is_array($state)) {
            $state = get_option(self::OPTION_EBAY_MAINTENANCE_STATE, array());
        }
        $state = is_array($state) ? $state : array();
        return absint($state['completed_at'] ?? 0) > 0
            && (string) ($state['policy_version'] ?? '') === self::EBAY_CONTENT_POLICY_VERSION
            && (string) ($state['private_classifier_version'] ?? '') === self::EBAY_PRIVATE_CLASSIFIER_VERSION
            && (string) ($state['business_classifier_version'] ?? '') === self::EBAY_BUSINESS_CLASSIFIER_VERSION;
    }

    private function ebay_maintenance_classifier_version($seller_type) {
        return strtoupper(sanitize_key((string)$seller_type))==='INDIVIDUAL' ? self::EBAY_PRIVATE_CLASSIFIER_VERSION : self::EBAY_BUSINESS_CLASSIFIER_VERSION;
    }

    /** Keep PRIVATE route state independent from WordPress post_status. */
    private function ebay_private_listing_route_meta($row, $state, $reason = '') {
        $row = is_array($row) ? $row : array();
        $listing_id = absint($row['listing_post_id'] ?? 0);
        if ($listing_id <= 0 || !function_exists('update_post_meta')) { return; }
        $state = sanitize_key((string) $state);
        if ($state === '') { $state = 'review'; }
        update_post_meta($listing_id, '_ppar_ebay_lifecycle_state', $state);
        if ($reason !== '') { update_post_meta($listing_id, '_ppar_ebay_route_reason', sanitize_text_field((string) $reason)); }
        elseif (function_exists('delete_post_meta')) { delete_post_meta($listing_id, '_ppar_ebay_route_reason'); }
        if ($state === 'active' && function_exists('delete_post_meta')) {
            delete_post_meta($listing_id, '_ppar_ebay_route_review');
        }
    }

    /**
     * Eine lokale Klassifikator-Aenderung oder ein ueberfaelliger Refresh darf
     * einen bereits veroeffentlichten PRIVATE-Last-Known-Good-Bestand nicht allein
     * aus dem Frontend entfernen. Das letzte gueltige Ziel bleibt sichtbar,
     * waehrend die neue Route separat auf Review markiert wird. Harte Policy-,
     * Veto- oder eBay-Endsignale laufen NICHT durch diesen Pfad.
     */
    private function ebay_private_can_preserve_last_good_route($row) {
        $row = is_array($row) ? $row : array();
        $listing_id = absint($row['listing_post_id'] ?? 0);
        $target_term_id = absint($row['target_term_id'] ?? 0);
        if ($listing_id <= 0 || $target_term_id <= 0) { return false; }
        if (sanitize_key((string)($row['source_state'] ?? 'available')) === 'ended') { return false; }
        // Frische steuert ausschliesslich den naechsten getItem-Refresh. Ein
        // ueberfaelliger Refresh ist KEIN Endsignal und darf Last-Known-Good
        // nicht ausblenden.
        $end_at = absint($row['item_end_at'] ?? 0);
        if ($end_at > 0 && $end_at <= time()) { return false; }
        if (!function_exists('get_post_status') || (string)get_post_status($listing_id) !== 'publish') { return false; }
        return true;
    }

    private function ebay_private_preserve_last_good_route_on_soft_review($row, $error) {
        if (!$this->ebay_private_can_preserve_last_good_route($row)) { return false; }
        global $wpdb;
        $code=is_wp_error($error)?sanitize_key((string)$error->get_error_code()):'ebay_private_route_review';
        $message=is_wp_error($error)?sanitize_text_field($error->get_error_message()):sanitize_text_field((string)$error);
        $wpdb->update($this->ebay_items_table(),array(
            'policy_state'=>'allowed','route_state'=>'review_last_good','policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,
            'classifier_version'=>self::EBAY_PRIVATE_CLASSIFIER_VERSION,
            'rejection_reason'=>'['.$code.'] '.$message,'updated_at'=>time(),
        ),array('id'=>absint($row['id']??0)));
        $listing_id=absint($row['listing_post_id']??0);
        if ($listing_id>0 && function_exists('update_post_meta')) {
            update_post_meta($listing_id,'_ppar_ebay_lifecycle_state','active');
            update_post_meta($listing_id,'_ppar_ebay_route_review',1);
            update_post_meta($listing_id,'_ppar_ebay_route_reason',$message);
        }
        return true;
    }

    /** BUSINESS Last-Known-Good may survive only soft routing uncertainty. */
    private function ebay_business_can_preserve_last_good_output($row) {
        $row = is_array($row) ? $row : array();
        $hash = strtolower(sanitize_text_field((string)($row['creative_identity_hash'] ?? '')));
        if (!preg_match('/^[a-f0-9]{64}$/', $hash)) { return false; }
        if (sanitize_key((string)($row['source_state'] ?? 'available')) === 'ended') { return false; }
        if (sanitize_key((string)($row['policy_state'] ?? 'allowed')) === 'blocked') { return false; }
        if ($this->ebay_public_content_policy_reason_from_source_row($row, (string)($row['title'] ?? '')) !== '') { return false; }
        $end_at = absint($row['item_end_at'] ?? 0);
        if ($end_at > 0 && $end_at <= time()) { return false; }
        if (!method_exists($this, 'get_campaigns')) { return false; }
        foreach ((array)$this->get_campaigns() as $campaign) {
            if (!is_array($campaign) || sanitize_key((string)($campaign['network'] ?? '')) !== 'ebay' || sanitize_key((string)($campaign['creative_type'] ?? '')) !== 'product') { continue; }
            $post_id = absint($campaign['post_id'] ?? 0);
            if ($post_id <= 0 || !function_exists('get_post_meta')) { continue; }
            if (absint(get_post_meta($post_id, '_ppar_ebay_business_auto', true)) !== 1) { continue; }
            $campaign_hash = strtolower(sanitize_text_field((string)get_post_meta($post_id, '_ppar_creative_identity_hash', true)));
            if ($campaign_hash === $hash) { return true; }
        }
        return false;
    }

    private function ebay_business_preserve_last_good_on_soft_review($row, $error) {
        if (!$this->ebay_business_can_preserve_last_good_output($row)) { return false; }
        global $wpdb;
        $code=is_wp_error($error)?sanitize_key((string)$error->get_error_code()):'ebay_business_route_review';
        $message=is_wp_error($error)?sanitize_text_field($error->get_error_message()):sanitize_text_field((string)$error);
        $wpdb->update($this->ebay_items_table(),array(
            'policy_state'=>'allowed','route_state'=>'review_last_good','policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,
            'rejection_reason'=>'['.$code.'] '.$message,'updated_at'=>time(),
        ),array('id'=>absint($row['id']??0)));
        return true;
    }

    private function ebay_maintenance_set_review_state($row, $seller_type, $error) {
        global $wpdb;
        $code=is_wp_error($error)?sanitize_key((string)$error->get_error_code()):'ebay_route_review';
        $message=is_wp_error($error)?sanitize_text_field($error->get_error_message()):sanitize_text_field((string)$error);
        $wpdb->update($this->ebay_items_table(),array(
            'policy_state'=>'allowed','route_state'=>'review','policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,
            'classifier_version'=>$this->ebay_maintenance_classifier_version($seller_type),
            'rejection_reason'=>'['.$code.'] '.$message,'updated_at'=>time(),
        ),array('id'=>absint($row['id']??0)));
        if (strtoupper(sanitize_key((string)$seller_type)) === 'INDIVIDUAL') {
            $this->ebay_private_listing_route_meta($row, 'review', $message);
        }
    }

    /**
     * Workflow-V2 maintenance is scheduled work, never an admin-page side effect.
     * It re-evaluates only rows whose independent policy/classifier contract is stale.
     * Local reclassification never refreshes source freshness timestamps.
     */
    public function run_ebay_maintenance_v2($limit = 1200, $force_business_reconcile = false) {
        $this->maybe_install_ebay_schema();
        global $wpdb;
        $table=$this->ebay_items_table();
        $limit=max(1,min(2000,absint($limit)));
        $state=get_option(self::OPTION_EBAY_MAINTENANCE_STATE,array());
        $state=is_array($state)?$state:array();
        // A contract change invalidates every previous maintenance cursor. Otherwise
        // a half-finished old contract could skip low IDs under the new classifier.
        $contract_changed = (string)($state['policy_version']??'') !== self::EBAY_CONTENT_POLICY_VERSION
            || (string)($state['private_classifier_version']??'') !== self::EBAY_PRIVATE_CLASSIFIER_VERSION
            || (string)($state['business_classifier_version']??'') !== self::EBAY_BUSINESS_CLASSIFIER_VERSION;
        if ($contract_changed) {
            $state['cursor']=0;
            $state['completed_at']=0;
            $state['cycle_stats']=array('scanned'=>0,'ready_private'=>0,'ready_business'=>0,'review'=>0,'blocked'=>0,'errors'=>0);
        }
        $cursor=absint($state['cursor']??0);
        $business_force_sql = $force_business_reconcile ? " OR seller_account_type='BUSINESS'" : " OR (seller_account_type='BUSINESS' AND (COALESCE(route_state,'')<>'ready' OR COALESCE(output_state,'') IN ('','repair_pending')))";
        $sql=$wpdb->prepare(
            "SELECT * FROM {$table} WHERE id>%d AND COALESCE(source_state,'available')<>'ended' AND (COALESCE(policy_version,'')<>%s OR (seller_account_type='INDIVIDUAL' AND COALESCE(classifier_version,'')<>%s) OR (seller_account_type='BUSINESS' AND COALESCE(classifier_version,'')<>%s)" . $business_force_sql . ") ORDER BY id ASC LIMIT %d",
            $cursor,self::EBAY_CONTENT_POLICY_VERSION,self::EBAY_PRIVATE_CLASSIFIER_VERSION,self::EBAY_BUSINESS_CLASSIFIER_VERSION,$limit
        );
        $rows=(array)$wpdb->get_results($sql,ARRAY_A);
        $stats=array('scanned'=>0,'ready_private'=>0,'ready_business'=>0,'review'=>0,'blocked'=>0,'errors'=>0);
        $settings=$this->ebay_settings();
        foreach($rows as $row){
            $state['cursor']=max(absint($state['cursor']??0),absint($row['id']??0));
            $stats['scanned']++;
            $payload=json_decode((string)($row['source_payload']??''),true); $payload=is_array($payload)?$payload:array();
            $raw=is_array($payload['raw']??null)?$payload['raw']:array();
            $seller_type=strtoupper(sanitize_key((string)($row['seller_account_type']??'')));
            if(!$raw){$this->ebay_maintenance_set_review_state($row,$seller_type,new WP_Error('ebay_maintenance_source_missing','Gespeicherter Originalpayload fehlt.'));$stats['review']++;continue;}
            $policy_reason=$this->ebay_content_policy_reason(array('raw'=>$raw,'title'=>(string)($row['title']??'')));
            if($policy_reason!==''){$this->ebay_quarantine_filtered_row($row,$policy_reason);$stats['blocked']++;continue;}
            $item=$this->ebay_accept_item($raw,$seller_type,$settings);
            if(is_wp_error($item)){
                if(in_array((string)$item->get_error_code(),array('ebay_toy_item_blocked','ebay_content_policy_blocked'),true)){$this->ebay_quarantine_filtered_row($row,$item->get_error_message());$stats['blocked']++;continue;}
                if((string)$item->get_error_code()==='ebay_item_ended'){$this->ebay_refresh_mark_ended($row,'Gespeichertes eBay-Enddatum ist erreicht.');continue;}
                $this->ebay_maintenance_set_review_state($row,$seller_type,$item);$stats['review']++;continue;
            }
            $rule=$this->ebay_rule_by_id((string)($row['rule_id']??''),$settings);
            $manual_term_id=0;
            if($seller_type==='INDIVIDUAL'){
                $manual_decision=$this->ebay_candidate_manual_decision((string)($row['item_id']??''));
                $manual_status=sanitize_key((string)($manual_decision['status']??'automatic'));
                if(in_array($manual_status,array('veto','paused'),true)){
                    $message=sanitize_text_field((string)($manual_decision['reason']??'Manuelles Chef-Veto ist aktiv.'));
                    $manual_update=array('status'=>'blocked_manual','policy_state'=>'allowed','route_state'=>'blocked','output_state'=>'none','policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,'classifier_version'=>self::EBAY_PRIVATE_CLASSIFIER_VERSION,'rejection_reason'=>'[ebay_manual_veto] '.$message,'updated_at'=>time());
                    $wpdb->update($table,$manual_update,array('id'=>absint($row['id']??0)),$this->ebay_db_formats($manual_update),array('%d'));
                    $this->ebay_private_listing_route_meta($row,'review',$message);$stats['blocked']++;continue;
                }
                if($manual_status==='approved'){
                    $term=$this->ebay_target_from_candidate_decision($manual_decision,$settings);
                    if(is_wp_error($term)){$this->ebay_maintenance_set_review_state($row,$seller_type,$term);$stats['review']++;continue;}
                    $classification=$this->ebay_manual_classification($term,$item,(string)($manual_decision['reason']??'Manuell freigegeben.'));
                    $manual_term_id=absint($term->term_id??0);
                } else {
                    $classification=$this->ebay_classify_portal_item($item,$rule);
                }
            } else {
                $classification=$this->ebay_business_classify_portal_item_strict($item,$rule);
            }
            if(is_wp_error($classification)){
                if($seller_type==='INDIVIDUAL' && $this->ebay_private_preserve_last_good_route_on_soft_review($row,$classification)){
                    $stats['review']++;continue;
                }
                if($seller_type==='BUSINESS' && $this->ebay_business_preserve_last_good_on_soft_review($row,$classification)){
                    $stats['review']++;continue;
                }
                $this->ebay_maintenance_set_review_state($row,$seller_type,$classification);$stats['review']++;continue;
            }
            $item['portal_classification']=$classification;
            $payload['portal_classification']=$classification;
            $updates=array(
                'policy_state'=>'allowed','route_state'=>'ready','policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,
                'classifier_version'=>$this->ebay_maintenance_classifier_version($seller_type),
                'source_payload'=>wp_json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'rejection_reason'=>'','updated_at'=>time(),
            );
            if($seller_type==='INDIVIDUAL'){
                $target_rule=$rule; $target_rule['target_term_slug']=sanitize_title((string)($classification['private_bucket_slug']??''));
                $term_id=$manual_term_id>0?$manual_term_id:$this->ebay_rule_target_term($target_rule,$settings);
                if(is_wp_error($term_id)||absint($term_id)<=0){$this->ebay_maintenance_set_review_state($row,$seller_type,is_wp_error($term_id)?$term_id:new WP_Error('ebay_private_target_missing','Zielkategorie fehlt.'));$stats['review']++;continue;}
                $updates['target_term_id']=absint($term_id);
                $listing_id=absint($row['listing_post_id']??0);
                if($listing_id>0){
                    if(function_exists('wp_set_post_terms')){wp_set_post_terms($listing_id,array(absint($term_id)),'hp_listing_category',false);}
                    if(function_exists('update_post_meta')){update_post_meta($listing_id,'_ppar_ebay_target_term_id',absint($term_id));}
                    $this->ebay_private_listing_route_meta($row, 'active');
                }
                $stats['ready_private']++;
            } else {
                // Last-Known-Good-Vertrag: lokale Policy/Klassifikation und
                // Rematerialisierung laufen immer aus dem gespeicherten
                // Originalpayload. fresh_until entscheidet nur, ob danach ein
                // realer getItem-Refresh faellig ist; fehlende Frische ist kein
                // Deaktivierungsgrund.
                $routed=$this->ebay_route_business($row,$item,$rule,'maintenance-v2-'.time(),$classification);
                if(is_wp_error($routed)){$this->ebay_maintenance_set_review_state($row,$seller_type,$routed);$stats['errors']++;continue;}
                if(is_array($routed) && !empty($routed['last_good_preserved'])){
                    // ebay_route_business already persisted review_last_good.
                    // Do not overwrite it with the generic ready update below.
                    $stats['review']++;continue;
                }
                $updates['output_state']='creative_ready';
                $stats['ready_business']++;
            }
            $wpdb->update($table,$updates,array('id'=>absint($row['id']??0)),$this->ebay_db_formats($updates),array('%d'));
        }
        $cycle=is_array($state['cycle_stats']??null)?$state['cycle_stats']:array();
        foreach(array('scanned','ready_private','ready_business','review','blocked','errors') as $key){
            $cycle[$key]=absint($cycle[$key]??0)+absint($stats[$key]??0);
        }
        if(count($rows)<$limit){
            // A full pass is complete. Reset cursor so future policy/classifier
            // contract changes can start deterministically from row 1.
            $state['completed_at']=time(); $state['cursor']=0;
            $state['last_stats']=$cycle;
            $state['cycle_stats']=array();
        } else {
            $state['completed_at']=0;
            $state['last_stats']=$cycle;
            $state['cycle_stats']=$cycle;
        }
        $state['policy_version']=self::EBAY_CONTENT_POLICY_VERSION;
        $state['private_classifier_version']=self::EBAY_PRIVATE_CLASSIFIER_VERSION;
        $state['business_classifier_version']=self::EBAY_BUSINESS_CLASSIFIER_VERSION;
        $state['last_run_at']=time();
        update_option(self::OPTION_EBAY_MAINTENANCE_STATE,$state,false);
        return $stats;
    }

    private function ebay_api_base($settings) {
        return (string) ($settings['environment'] ?? '') === 'sandbox' ? 'https://api.sandbox.ebay.com' : 'https://api.ebay.com';
    }

    private function ebay_token_cache_key($settings) {
        return 'ppar_ebay_token_' . substr(hash('sha256', (string) ($settings['environment'] ?? '') . '|' . (string) ($settings['client_id'] ?? '')), 0, 24);
    }

    private function ebay_access_token($settings, $force = false) {
        $cache_key = $this->ebay_token_cache_key($settings);
        if (!$force && function_exists('get_transient')) {
            $cached = get_transient($cache_key);
            if (is_string($cached) && $cached !== '') { return $cached; }
        }
        $client_id = (string) ($settings['client_id'] ?? '');
        $client_secret = (string) ($settings['client_secret'] ?? '');
        if ($client_id === '' || $client_secret === '') { return new WP_Error('ebay_credentials_missing', 'eBay-Zugangsdaten fehlen.'); }
        $response = wp_remote_post($this->ebay_api_base($settings) . '/identity/v1/oauth2/token', array(
            'timeout' => 25,
            'redirection' => 2,
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode($client_id . ':' . $client_secret),
                'Content-Type' => 'application/x-www-form-urlencoded',
                'Accept' => 'application/json',
            ),
            'body' => 'grant_type=client_credentials&scope=' . rawurlencode('https://api.ebay.com/oauth/api_scope'),
        ));
        if (is_wp_error($response)) { return $response; }
        $code = absint(wp_remote_retrieve_response_code($response));
        $body = json_decode((string) wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || !is_array($body) || empty($body['access_token'])) {
            return new WP_Error('ebay_oauth_failed', 'eBay OAuth fehlgeschlagen (HTTP ' . $code . ').');
        }
        $token = (string) $body['access_token'];
        $ttl = max(300, absint($body['expires_in'] ?? 7200) - 300);
        if (function_exists('set_transient')) { set_transient($cache_key, $token, $ttl); }
        return $token;
    }

    private function ebay_reference_id($settings, $rule, $seller_type) {
        $portal = method_exists($this, 'output_local_portal_key') ? $this->output_local_portal_key() : 'local';
        $parts = array(
            sanitize_key((string) ($settings['affiliate_reference_prefix'] ?? 'portal')),
            sanitize_key((string) $portal),
            sanitize_key((string) ($rule['id'] ?? 'rule')),
            strtolower(sanitize_key((string) $seller_type)),
        );
        return substr(implode('-', array_filter($parts)), 0, 240);
    }

    /**
     * V5.4.0: Die acht privaten Bereiche werden nicht mehr nur über je eine
     * Sammelphrase abgefragt. Kleine, fachlich kontrollierte Varianten erhöhen
     * die reale Abdeckung, während die nachgelagerte Fachklassifikation weiter
     * allein über die tatsächlichen Angebotsdaten entscheidet.
     */
    private function ebay_private_query_variants($rule) {
        $rule = is_array($rule) ? $rule : array();
        $id = sanitize_key((string) ($rule['id'] ?? ''));
        $map = array(
            'pferde-ponys'=>array('Pferd','Pony'),
            'sattel-zaumzeug'=>array('Pferdesattel','Zaumzeug Pferd','Trense Pferd'),
            'decken-schutz'=>array('Pferdedecke','Gamaschen Pferd','Fliegendecke Pferd'),
            'stall-weide-haltung'=>array('Pferdestall','Weidezaun Pferd','Heunetz Pferd'),
            'fuetterung-pflege'=>array('Pferdefutter','Pferdepflege','Putzzeug Pferd'),
            'anhaenger-transport'=>array('Pferdeanhänger','Pferdetransport','Transportgamaschen Pferd'),
            'reitbekleidung-zubehoer'=>array('Reitbekleidung','Reithelm','Reitstiefel'),
            'sonstiges'=>array('Pferdezubehör','Reitsport Zubehör'),
        );
        $queries = isset($map[$id]) ? $map[$id] : array((string) ($rule['query'] ?? ''));
        $safe = array();
        foreach ($queries as $query) {
            $query = substr(sanitize_text_field((string) $query), 0, 100);
            if ($query !== '') { $safe[$query] = $query; }
        }
        if (!$safe && !empty($rule['query'])) { $safe[(string) $rule['query']] = substr(sanitize_text_field((string) $rule['query']), 0, 100); }
        return array_values($safe);
    }

    public function ebay_build_search_request($rule, $seller_type, $settings = null, $token = 'TEST_TOKEN', $offset = 0) {
        $settings = is_array($settings) ? $this->ebay_normalize_settings($settings, true) : $this->ebay_settings();
        $rule = is_array($rule) ? $rule : array();
        $seller_type = strtoupper(sanitize_key((string) $seller_type));
        if (!in_array($seller_type, array('INDIVIDUAL','BUSINESS'), true)) {
            return new WP_Error('ebay_seller_type_invalid', 'Ungültiger Verkäuferkontotyp.');
        }
        $query = sanitize_text_field((string) ($rule['query'] ?? ''));
        if ($query === '') { return new WP_Error('ebay_query_missing', 'eBay-Suchbegriff fehlt.'); }
        $limit = max(1, min(50, absint($settings['max_per_rule'] ?? 20)));
        $filters = array('sellerAccountTypes:{' . $seller_type . '}', 'deliveryCountry:DE');
        $args = array(
            'q' => $query,
            'limit' => $limit,
            'offset' => max(0, absint($offset)),
            'fieldgroups' => 'EXTENDED',
            'filter' => implode(',', $filters),
        );
        $category_ids = array_values(array_filter(array_map('strval', (array) ($rule['category_ids'] ?? array()))));
        if ($category_ids) { $args['category_ids'] = implode(',', $category_ids); }
        $reference = $this->ebay_reference_id($settings, $rule, $seller_type);
        $enduser = 'affiliateCampaignId=' . (string) ($settings['epn_campaign_id'] ?? '') . ',affiliateReferenceId=' . $reference;
        $postal = trim((string) ($settings['delivery_postal_code'] ?? ''));
        if ($postal !== '') {
            $enduser .= ',contextualLocation=' . rawurlencode('country=DE,zip=' . $postal);
        }
        return array(
            'url' => add_query_arg($args, $this->ebay_api_base($settings) . '/buy/browse/v1/item_summary/search'),
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Accept' => 'application/json',
                'Accept-Language' => 'de-DE',
                'X-EBAY-C-MARKETPLACE-ID' => 'EBAY_DE',
                'X-EBAY-C-ENDUSERCTX' => $enduser,
            ),
            'timeout' => 20,
            'redirection' => 2,
        );
    }

    private function ebay_search($rule, $seller_type, $settings) {
        $token = $this->ebay_access_token($settings);
        if (is_wp_error($token)) { return $token; }
        $page = $this->ebay_search_page($rule, $seller_type, $settings, $token, '');
        if (is_wp_error($page)) { return $page; }
        return (array) ($page['items'] ?? array());
    }

    /**
     * V5.4.0 – exakt eine Browse-Seite. Folgeseiten werden ausschließlich über
     * eBays `next`-URL geladen; `total` wird niemals als Pagination-Steuerung benutzt.
     */
    private function ebay_search_page($rule, $seller_type, $settings, $token, $next_url = '') {
        $request = $this->ebay_build_search_request($rule, $seller_type, $settings, $token, 0);
        if (is_wp_error($request)) { return $request; }
        $url = trim((string) $next_url);
        if ($url !== '') {
            $url = $this->ebay_validate_next_url($url, $settings);
            if (is_wp_error($url)) { return $url; }
        } else {
            $url = (string) $request['url'];
        }
        $response = wp_remote_get($url, array(
            'timeout'=>$request['timeout'],
            'redirection'=>$request['redirection'],
            'headers'=>$request['headers'],
        ));
        if (is_wp_error($response)) { return $response; }
        $code = absint(wp_remote_retrieve_response_code($response));
        $body = json_decode((string) wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || !is_array($body)) {
            return new WP_Error('ebay_search_failed', 'eBay Browse API fehlgeschlagen (HTTP ' . $code . ').');
        }
        $next = trim((string) ($body['next'] ?? ''));
        if ($next !== '') {
            $validated = $this->ebay_validate_next_url($next, $settings);
            if (is_wp_error($validated)) { return $validated; }
            $next = $validated;
        }
        return array(
            'items'=>is_array($body['itemSummaries'] ?? null) ? array_values($body['itemSummaries']) : array(),
            'next'=>$next,
            'href'=>esc_url_raw((string) ($body['href'] ?? $url)),
            'offset'=>absint($body['offset'] ?? 0),
            'limit'=>absint($body['limit'] ?? ($settings['max_per_rule'] ?? 50)),
            'total'=>absint($body['total'] ?? 0),
        );
    }

    /** `next` darf nie als beliebige Remote-URL missbraucht werden. */
    private function ebay_validate_next_url($url, $settings) {
        $url = esc_url_raw((string) $url);
        if ($url === '' || !wp_http_validate_url($url)) {
            return new WP_Error('ebay_next_url_invalid', 'Ungültige eBay-Pagination-URL.');
        }
        $base = $this->ebay_api_base($settings);
        $base_parts = wp_parse_url($base);
        $parts = wp_parse_url($url);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));
        $host = strtolower((string) ($parts['host'] ?? ''));
        $base_host = strtolower((string) ($base_parts['host'] ?? ''));
        $path = (string) ($parts['path'] ?? '');
        if ($scheme !== 'https' || $host === '' || $host !== $base_host || $path !== '/buy/browse/v1/item_summary/search') {
            return new WP_Error('ebay_next_url_untrusted', 'eBay-Pagination verweist auf eine nicht freigegebene URL.');
        }
        return $url;
    }

    /** Vollständiger getItem-Request für die gezielte Bestandsnachprüfung. */
    private function ebay_build_item_refresh_request($row, $settings, $token) {
        $row = is_array($row) ? $row : array();
        $item_id = substr(sanitize_text_field((string) ($row['item_id'] ?? '')), 0, 191);
        if ($item_id === '') { return new WP_Error('ebay_refresh_item_id_missing', 'eBay-Item-ID für Bestandsabgleich fehlt.'); }
        $seller_type = strtoupper(sanitize_key((string) ($row['seller_account_type'] ?? '')));
        $rule = $this->ebay_rule_by_id((string) ($row['rule_id'] ?? ''));
        $reference = $this->ebay_reference_id($settings, $rule, in_array($seller_type, array('INDIVIDUAL','BUSINESS'), true) ? $seller_type : 'INDIVIDUAL');
        $enduser = 'affiliateCampaignId=' . (string) ($settings['epn_campaign_id'] ?? '') . ',affiliateReferenceId=' . $reference;
        $postal = trim((string) ($settings['delivery_postal_code'] ?? ''));
        if ($postal !== '') { $enduser .= ',contextualLocation=' . rawurlencode('country=DE,zip=' . $postal); }
        return array(
            'url'=>$this->ebay_api_base($settings) . '/buy/browse/v1/item/' . rawurlencode($item_id),
            'headers'=>array(
                'Authorization'=>'Bearer ' . (string) $token,
                'Accept'=>'application/json',
                'Accept-Language'=>'de-DE',
                'X-EBAY-C-MARKETPLACE-ID'=>'EBAY_DE',
                'X-EBAY-C-ENDUSERCTX'=>$enduser,
            ),
            // V5.24: Einzelchecks duerfen die Refresh-Queue nicht minutenlang
            // blockieren. Transiente Timeouts deaktivieren ein Listing nicht; sie
            // werden beim naechsten stündlichen Lauf erneut versucht.
            'timeout'=>8,
            'redirection'=>2,
        );
    }

    /**
     * Liefert state=active|ended. Netzwerk-/Rate-Limit-/Serverfehler bleiben
     * WP_Error und führen ausdrücklich nicht zu einem destruktiven Statuswechsel.
     */
    private function ebay_fetch_item_for_refresh($row, $settings, $token) {
        $request = $this->ebay_build_item_refresh_request($row, $settings, $token);
        if (is_wp_error($request)) { return $request; }
        $response = wp_remote_get((string) $request['url'], array(
            'timeout'=>$request['timeout'],
            'redirection'=>$request['redirection'],
            'headers'=>$request['headers'],
        ));
        if (is_wp_error($response)) { return new WP_Error('ebay_refresh_transport', $response->get_error_message()); }
        $code = absint(wp_remote_retrieve_response_code($response));
        if (in_array($code, array(404,410), true)) {
            return array('state'=>'ended','reason'=>'not_found','http_code'=>$code,'raw'=>array());
        }
        if ($code === 429 || $code >= 500) {
            return new WP_Error('ebay_refresh_transient_http', 'eBay-Bestandsabgleich vorübergehend nicht verfügbar (HTTP ' . $code . ').');
        }
        $body = json_decode((string) wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || !is_array($body)) {
            return new WP_Error('ebay_refresh_http', 'eBay-Bestandsabgleich fehlgeschlagen (HTTP ' . $code . ').');
        }
        $end_at = 0;
        if (!empty($body['itemEndDate'])) {
            $parsed = strtotime((string) $body['itemEndDate']);
            $end_at = $parsed ? absint($parsed) : 0;
        }
        if ($end_at > 0 && $end_at <= time()) {
            return array('state'=>'ended','reason'=>'item_end_date','http_code'=>$code,'raw'=>$body);
        }
        foreach ((array) ($body['estimatedAvailabilities'] ?? array()) as $availability) {
            $status = strtoupper(sanitize_key((string) (is_array($availability) ? ($availability['estimatedAvailabilityStatus'] ?? '') : '')));
            if ($status === 'OUT_OF_STOCK') {
                return array('state'=>'ended','reason'=>'out_of_stock','http_code'=>$code,'raw'=>$body);
            }
        }
        return array('state'=>'active','reason'=>'available','http_code'=>$code,'raw'=>$body);
    }

    private function ebay_valid_http_url($value) {
        $value = esc_url_raw((string) $value);
        return $value !== '' && wp_http_validate_url($value) ? $value : '';
    }

    /** Anbieter-Kohorte für öffentlich dargestellte Produktkampagnen. */
    private function ebay_product_campaign_cohort($campaign) {
        if (!is_array($campaign) || sanitize_key((string) ($campaign['creative_type'] ?? '')) !== 'product') { return ''; }
        return sanitize_key((string) ($campaign['network'] ?? '')) === 'ebay' ? 'ebay' : 'non_ebay';
    }

    /** Eine öffentliche Produktgruppe darf ausschließlich eine Anbieter-Kohorte enthalten. */
    private function ebay_product_campaigns_share_provider_cohort($campaigns) {
        $cohort = '';
        foreach ((array) $campaigns as $campaign) {
            $current = $this->ebay_product_campaign_cohort($campaign);
            if ($current === '') { continue; }
            if ($cohort === '') { $cohort = $current; continue; }
            if ($current !== $cohort) { return false; }
        }
        return true;
    }

    /**
     * Laufzeit-Sicherheitsnetz: automatische Produktpositionen folgen der
     * Kohorte der höchstrangigen Kampagne. Damit kann auch eine später manuell
     * aktivierte Altkampagne keine eBay-/Nicht-eBay-Mischung erzeugen.
     */
    private function ebay_business_campaign_source_row($campaign) {
        if (!is_array($campaign) || sanitize_key((string) ($campaign['network'] ?? '')) !== 'ebay') { return array(); }
        $post_id = absint($campaign['post_id'] ?? 0);
        if ($post_id <= 0 || !function_exists('get_post_meta')) { return array(); }
        if (absint(get_post_meta($post_id, '_ppar_ebay_business_auto', true)) !== 1) { return array(); }
        $hash = strtolower(sanitize_text_field((string) get_post_meta($post_id, '_ppar_creative_identity_hash', true)));
        if (!preg_match('/^[a-f0-9]{64}$/', $hash)) { return array(); }
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->ebay_items_table()} WHERE creative_identity_hash=%s AND seller_account_type='BUSINESS' ORDER BY id DESC LIMIT 1",
            $hash
        ), ARRAY_A);
        return is_array($row) ? $row : array();
    }

    /**
     * Public BUSINESS delivery is fail-closed from independent source/policy/
     * route state. A missed refresh never mutates or destroys the campaign, but
     * stale source data cannot win a public product slot.
     */
    private function ebay_business_campaign_source_allows_delivery($campaign) {
        if (!is_array($campaign) || sanitize_key((string) ($campaign['network'] ?? '')) !== 'ebay') { return true; }
        $post_id = absint($campaign['post_id'] ?? 0);
        if ($post_id <= 0 || !function_exists('get_post_meta')) { return false; }

        // Public eBay PRODUCT slots are a provider-managed contract. A legacy or
        // orphan eBay product without the source marker must never bypass the
        // source/policy gates. Non-product/manual eBay creatives remain outside
        // this BUSINESS-product contract.
        $is_product = sanitize_key((string)($campaign['creative_type'] ?? '')) === 'product';
        if (absint(get_post_meta($post_id, '_ppar_ebay_business_auto', true)) !== 1) { return !$is_product; }
        // A published campaign is the Last-Known-Good delivery contract. A
        // classifier/policy migration must never globally blank the frontend
        // before a replacement has been materialized successfully. Legacy
        // strict_v1 and current concept_v3 contracts may remain visible while a
        // soft reclassification is pending; hard source/policy/end signals still
        // block immediately.
        $contract = sanitize_key((string) get_post_meta($post_id, '_ppar_ebay_business_match_contract', true));
        if (!in_array($contract, array('strict_v1','concept_v3'), true)) { return false; }
        $row = $this->ebay_business_campaign_source_row($campaign);
        if (!$row) { return false; }
        if (sanitize_key((string) ($row['source_state'] ?? '')) !== 'available') { return false; }
        if (sanitize_key((string) ($row['policy_state'] ?? 'allowed')) === 'blocked') { return false; }
        if ($this->ebay_public_content_policy_reason_from_source_row($row, (string)($campaign['title'] ?? '')) !== '') { return false; }
        $end_at = absint($row['item_end_at'] ?? 0);
        if ($end_at > 0 && $end_at <= time()) { return false; }
        $route_state = sanitize_key((string)($row['route_state'] ?? ''));
        if ($route_state === 'review_last_good') { return true; }
        if ($route_state !== 'ready') { return false; }
        if ($contract === 'concept_v3' && (string)($row['classifier_version'] ?? '') !== self::EBAY_BUSINESS_CLASSIFIER_VERSION) { return false; }
        return true;
    }

    /**
     * Laufzeit-Sicherheitsnetz: automatische Produktpositionen folgen der
     * Kohorte der höchstrangigen Kampagne. Zusätzlich darf ein automatisches
     * eBay-BUSINESS-Produkt nur mit aktivem, erlaubtem Workflow-V2-Quellstatus
     * an der öffentlichen Auswahl teilnehmen.
     */
    private function ebay_filter_ranked_product_candidates_provider_cohort($candidates) {
        $candidates = array_values((array) $candidates);
        if (!$candidates) { return array(); }
        $candidates = array_values(array_filter($candidates, function($candidate) {
            $campaign = is_array($candidate) ? ($candidate['campaign'] ?? null) : null;
            if (!is_array($campaign) || sanitize_key((string) ($campaign['network'] ?? '')) !== 'ebay') { return true; }
            return $this->ebay_business_campaign_source_allows_delivery($campaign);
        }));
        if (!$candidates) { return array(); }
        $first = is_array($candidates[0] ?? null) ? ($candidates[0]['campaign'] ?? null) : null;
        $cohort = $this->ebay_product_campaign_cohort($first);
        if ($cohort === '') { return $candidates; }
        return array_values(array_filter($candidates, function($candidate) use ($cohort) {
            $campaign = is_array($candidate) ? ($candidate['campaign'] ?? null) : null;
            return $this->ebay_product_campaign_cohort($campaign) === $cohort;
        }));
    }

    public function ebay_accept_item($item, $seller_type, $settings = null) {
        $settings = is_array($settings) ? $this->ebay_normalize_settings($settings, true) : $this->ebay_settings();
        $item = is_array($item) ? $item : array();
        $seller_type = strtoupper(sanitize_key((string) $seller_type));
        $actual_type = strtoupper(sanitize_key((string) ($item['seller']['sellerAccountType'] ?? '')));
        if (!in_array($seller_type, array('INDIVIDUAL','BUSINESS'), true) || $actual_type !== $seller_type) {
            return new WP_Error('ebay_seller_type_mismatch', 'Verkäuferkontotyp stimmt nicht mit der Eingangsweiche überein.');
        }
        if ((string) ($item['listingMarketplaceId'] ?? '') !== 'EBAY_DE') {
            return new WP_Error('ebay_marketplace_mismatch', 'Angebot stammt nicht aus EBAY_DE.');
        }
        if (!empty($item['adultOnly'])) {
            return new WP_Error('ebay_adult_item_blocked', 'Erwachsenenangebot ist nicht freigegeben.');
        }
        $toy_reason = $this->ebay_toy_filter_reason($item);
        if ($toy_reason !== '') { return new WP_Error('ebay_toy_item_blocked', $toy_reason); }
        $buying_options = array_values(array_unique(array_map('strtoupper', array_map('sanitize_key', (array) ($item['buyingOptions'] ?? array())))));
        if (in_array('CLASSIFIED_AD', $buying_options, true)) {
            return new WP_Error('ebay_classified_ad_blocked', 'CLASSIFIED_AD ist nicht freigegeben.');
        }
        $affiliate_url = $this->ebay_valid_http_url($item['itemAffiliateWebUrl'] ?? '');
        if ($affiliate_url === '') {
            return new WP_Error('ebay_affiliate_url_missing', 'itemAffiliateWebUrl fehlt; Ausgabe wird blockiert.');
        }
        $item_web_url = $this->ebay_valid_http_url($item['itemWebUrl'] ?? '');
        $image_url = $this->ebay_valid_http_url($item['image']['imageUrl'] ?? '');
        if ($image_url === '') { return new WP_Error('ebay_image_missing', 'eBay-Hauptbild fehlt.'); }
        $item_id = substr(sanitize_text_field((string) ($item['itemId'] ?? '')), 0, 191);
        $title = substr(sanitize_text_field((string) ($item['title'] ?? '')), 0, 180);
        if ($item_id === '' || $title === '') { return new WP_Error('ebay_identity_missing', 'eBay-ID oder Titel fehlt.'); }
        $price_value = sanitize_text_field((string) ($item['price']['value'] ?? ''));
        $currency = strtoupper(sanitize_key((string) ($item['price']['currency'] ?? '')));
        if ($price_value === '' || !is_numeric($price_value) || (float) $price_value < 0 || $currency !== 'EUR') {
            return new WP_Error('ebay_price_invalid', 'Vollständiger EUR-Preis fehlt.');
        }
        $end_at = 0;
        if (!empty($item['itemEndDate'])) {
            $end_at = strtotime((string) $item['itemEndDate']);
            $end_at = $end_at ? absint($end_at) : 0;
            if ($end_at > 0 && $end_at <= time()) { return new WP_Error('ebay_item_ended', 'eBay-Angebot ist bereits beendet.'); }
        }
        $seller_username = substr(sanitize_text_field((string) ($item['seller']['username'] ?? '')), 0, 191);
        if ($seller_username === '') { return new WP_Error('ebay_seller_username_missing', 'eBay-Verkäufername fehlt.'); }
        $shipping_value = '';
        if (!empty($item['shippingOptions'][0]['shippingCost']['value'])) {
            $shipping_value = sanitize_text_field((string) $item['shippingOptions'][0]['shippingCost']['value']);
        }
        $location = array_filter(array(
            sanitize_text_field((string) ($item['itemLocation']['city'] ?? '')),
            sanitize_text_field((string) ($item['itemLocation']['country'] ?? '')),
        ));
        $normalized = array(
            'item_id' => $item_id,
            'legacy_item_id' => substr(sanitize_text_field((string) ($item['legacyItemId'] ?? '')), 0, 80),
            'seller_account_type' => $seller_type,
            'seller_username' => $seller_username,
            'title' => $title,
            'short_description' => sanitize_textarea_field((string) ($item['shortDescription'] ?? '')),
            'condition_text' => sanitize_text_field((string) ($item['condition'] ?? '')),
            'price_value' => $price_value,
            'currency' => $currency,
            'shipping_value' => $shipping_value,
            'location_text' => implode(', ', $location),
            'affiliate_url' => $affiliate_url,
            'item_web_url' => $item_web_url,
            'image_url' => $image_url,
            'item_end_at' => $end_at,
            'buying_options' => $buying_options,
            'category_ids' => array_values(array_filter(array_map('sanitize_text_field', array_map(static function($category){ return is_array($category) ? (string) ($category['categoryId'] ?? '') : ''; }, (array) ($item['categories'] ?? array()))))),
            'category_names' => array_values(array_filter(array_map('sanitize_text_field', array_map(static function($category){ return is_array($category) ? (string) ($category['categoryName'] ?? '') : ''; }, (array) ($item['categories'] ?? array()))))),
            'raw' => $item,
        );
        $fingerprint = $normalized;
        unset($fingerprint['raw']);
        $normalized['source_hash'] = hash('sha256', wp_json_encode($fingerprint, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return $normalized;
    }

    private function ebay_rule_target_term($rule, $settings) {
        if (!function_exists('taxonomy_exists') || !taxonomy_exists('hp_listing_category') || !function_exists('get_term_by')) {
            return new WP_Error('ebay_hivepress_missing', 'HivePress-Kategorietaxonomie fehlt.');
        }
        $root_id = absint($settings['private_root_term_id'] ?? 0);
        $root = $root_id > 0 ? get_term($root_id, 'hp_listing_category') : null;
        if (!$root || is_wp_error($root)) { return new WP_Error('ebay_private_root_missing', 'Wurzel „Private Anzeigen“ fehlt.'); }
        $slug = sanitize_title((string) ($rule['target_term_slug'] ?? ''));
        $term = $slug !== '' ? get_term_by('slug', $slug, 'hp_listing_category') : false;
        if (!$term || is_wp_error($term)) { return new WP_Error('ebay_private_target_missing', 'HivePress-Zielkategorie fehlt: ' . $slug); }
        $term_id = absint($term->term_id ?? 0);
        $validated = $this->ebay_validate_private_target_term_id($term_id, $settings);
        if (is_wp_error($validated)) { return $validated; }
        return absint($validated->term_id ?? 0);
    }

    private function ebay_db_formats($data) {
        $integer_fields = array_flip(array('target_term_id','listing_post_id','item_end_at','source_checked_at','last_seen','fresh_until','created_at','updated_at'));
        $formats = array();
        foreach (array_keys((array) $data) as $field) { $formats[] = isset($integer_fields[$field]) ? '%d' : '%s'; }
        return $formats;
    }

    private function ebay_upsert_item($item, $rule, $route_mode, $target_term_id, $settings) {
        global $wpdb;
        $table = $this->ebay_items_table();
        $portal_key = method_exists($this, 'output_local_portal_key') ? $this->output_local_portal_key() : 'local';
        $now = time();
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE portal_key=%s AND item_id=%s", $portal_key, (string) $item['item_id']), ARRAY_A);
        $data = array(
            'portal_key'=>$portal_key,
            'item_id'=>(string) $item['item_id'],
            'legacy_item_id'=>(string) $item['legacy_item_id'],
            'seller_account_type'=>(string) $item['seller_account_type'],
            'seller_username'=>(string) $item['seller_username'],
            'route_mode'=>sanitize_key((string) $route_mode),
            'rule_id'=>sanitize_key((string) ($rule['id'] ?? '')),
            'target_term_id'=>absint($target_term_id),
            'title'=>(string) $item['title'],
            'short_description'=>(string) $item['short_description'],
            'condition_text'=>(string) $item['condition_text'],
            'price_value'=>(string) $item['price_value'],
            'currency'=>(string) $item['currency'],
            'shipping_value'=>(string) $item['shipping_value'],
            'location_text'=>(string) $item['location_text'],
            'affiliate_url'=>(string) $item['affiliate_url'],
            'item_web_url'=>(string) $item['item_web_url'],
            'image_url'=>(string) $item['image_url'],
            'item_end_at'=>absint($item['item_end_at']),
            'source_hash'=>(string) $item['source_hash'],
            'source_payload'=>wp_json_encode(array('raw'=>$item['raw'],'portal_classification'=>(array) ($item['portal_classification'] ?? array())), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'status'=>'active',
            'source_state'=>'available',
            'policy_state'=>'allowed',
            'route_state'=>'ready',
            'output_state'=>(strtoupper(sanitize_key((string) ($item['seller_account_type'] ?? ''))) === 'INDIVIDUAL' ? 'listing_pending' : 'creative_pending'),
            'policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,
            'classifier_version'=>(strtoupper(sanitize_key((string) ($item['seller_account_type'] ?? ''))) === 'INDIVIDUAL' ? self::EBAY_PRIVATE_CLASSIFIER_VERSION : self::EBAY_BUSINESS_CLASSIFIER_VERSION),
            'source_checked_at'=>$now,
            'rejection_reason'=>'',
            'last_seen'=>$now,
            'fresh_until'=>$now + 6 * HOUR_IN_SECONDS,
            'updated_at'=>$now,
        );
        if ($existing) {
            $data['listing_post_id'] = absint($existing['listing_post_id'] ?? 0);
            $data['creative_identity_hash'] = sanitize_text_field((string) ($existing['creative_identity_hash'] ?? ''));
            $wpdb->update($table, $data, array('id'=>absint($existing['id'])), $this->ebay_db_formats($data), array('%d'));
            return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", absint($existing['id'])), ARRAY_A);
        }
        $data['listing_post_id'] = 0;
        $data['creative_identity_hash'] = '';
        $data['created_at'] = $now;
        $wpdb->insert($table, $data, $this->ebay_db_formats($data));
        if (!$wpdb->insert_id) { return new WP_Error('ebay_item_save_failed', 'eBay-Datensatz konnte nicht gespeichert werden.'); }
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id=%d", absint($wpdb->insert_id)), ARRAY_A);
    }

    private function ebay_listing_content($item) {
        $price = trim((string) $item['price_value'] . ' ' . (string) $item['currency']);
        $rows = array();
        if ($price !== '') { $rows[] = '<li><strong>Preis:</strong> ' . esc_html($price) . '</li>'; }
        if (!empty($item['condition_text'])) { $rows[] = '<li><strong>Zustand:</strong> ' . esc_html((string) $item['condition_text']) . '</li>'; }
        if ($item['shipping_value'] !== '') { $rows[] = '<li><strong>Versand:</strong> ' . esc_html((string) $item['shipping_value'] . ' ' . (string) $item['currency']) . '</li>'; }
        if (!empty($item['location_text'])) { $rows[] = '<li><strong>Artikelstandort:</strong> ' . esc_html((string) $item['location_text']) . '</li>'; }
        if (!empty($item['seller_username'])) { $rows[] = '<li><strong>eBay-Verkäufer:</strong> ' . esc_html((string) $item['seller_username']) . '</li>'; }
        if (!empty($item['item_end_at'])) { $rows[] = '<li><strong>Angebotsende:</strong> ' . esc_html(wp_date('d.m.Y H:i', absint($item['item_end_at']))) . '</li>'; }
        $description = trim((string) $item['short_description']);
        $out = '<p><strong>Privates eBay-Angebot</strong></p><p><small><strong>Affiliate-Anzeige:</strong> Bei einem Kauf über den Link kann das Portal eine Provision erhalten. Für Käufer entstehen keine Mehrkosten.</small></p>';
        if ($description !== '') { $out .= '<p>' . esc_html($description) . '</p>'; }
        if ($rows) { $out .= '<ul>' . implode('', $rows) . '</ul>'; }
        $out .= '<p><a href="' . esc_url((string) $item['affiliate_url']) . '" rel="sponsored nofollow noopener" target="_blank">Angebot bei eBay ansehen</a></p>';
        $out .= '<p><small>Beim Klick wechselst du zu eBay. Maßgeblich sind Preis, Verfügbarkeit und Angaben im eBay-Angebot.</small></p>';
        return $out;
    }

    private function ebay_sideload_listing_image($listing_id, $item) {
        $listing_id = absint($listing_id);
        $image_url = esc_url_raw((string) ($item['image_url'] ?? ''));
        if ($listing_id <= 0 || $image_url === '') { return new WP_Error('ebay_listing_image_missing', 'eBay-Listingbild fehlt.'); }
        $thumb = function_exists('get_post_thumbnail_id') ? absint(get_post_thumbnail_id($listing_id)) : 0;
        if ($thumb > 0 && (string) get_post_meta($thumb, '_ppar_ebay_source_url', true) === $image_url) { return $thumb; }
        if (!function_exists('download_url') || !function_exists('media_handle_sideload')) {
            foreach (array('file.php','media.php','image.php') as $file) {
                $path = ABSPATH . 'wp-admin/includes/' . $file;
                if (is_readable($path)) { require_once $path; }
            }
        }
        if (!function_exists('download_url') || !function_exists('media_handle_sideload') || !function_exists('set_post_thumbnail')) {
            return new WP_Error('ebay_media_api_missing', 'WordPress-Medienfunktionen fehlen.');
        }
        // V5.21: media_sideload_image() nutzt intern download_url() ohne eigenen
        // Timeoutparameter; WordPress verwendet dort standardmaessig bis zu 300 s.
        // Ein einziges langsames eBay-Bild konnte damit den gesamten Worker weit
        // jenseits seines 20-s-Zeitbudgets blockieren. Deshalb explizit begrenzt.
        $path_part = (string) parse_url($image_url, PHP_URL_PATH);
        $filename = $path_part !== '' ? basename($path_part) : '';
        if ($filename === '' || !preg_match('/\.(jpe?g|png|gif|webp)$/i', $filename)) {
            return new WP_Error('ebay_listing_image_extension', 'eBay-Listingbild hat keine freigegebene Bilddateiendung.');
        }
        $tmp = download_url($image_url, 15);
        if (is_wp_error($tmp)) { return $tmp; }
        $file_array = array('name'=>sanitize_file_name($filename), 'tmp_name'=>$tmp);
        $attachment_id = media_handle_sideload($file_array, $listing_id, sanitize_text_field((string) ($item['title'] ?? 'eBay-Angebot')));
        if (is_wp_error($attachment_id)) {
            if (is_string($tmp) && file_exists($tmp)) { @unlink($tmp); }
            return $attachment_id;
        }
        if (!set_post_thumbnail($listing_id, absint($attachment_id))) { return new WP_Error('ebay_thumbnail_failed', 'eBay-Bild konnte nicht als Listingbild gesetzt werden.'); }
        if ($thumb > 0 && $thumb !== absint($attachment_id) && (string) get_post_meta($thumb, '_ppar_ebay_item_id', true) === (string) ($item['item_id'] ?? '') && function_exists('wp_delete_attachment')) {
            wp_delete_attachment($thumb, true);
        }
        update_post_meta(absint($attachment_id), '_ppar_ebay_source_url', $image_url);
        update_post_meta(absint($attachment_id), '_ppar_ebay_item_id', sanitize_text_field((string) ($item['item_id'] ?? '')));
        return absint($attachment_id);
    }

    private function ebay_private_control_gate($seller_username, $target_term_id = 0, $listing_id = 0) {
        if (!method_exists($this, 'output_local_portal_key')) { return true; }
        $portal_key = sanitize_key((string) $this->output_local_portal_key());
        if ($portal_key === '') { return new WP_Error('ebay_control_portal_missing', 'Portalkontext für Chefsteuerung fehlt.'); }
        if (method_exists($this, 'control_emergency_stop_active') && $this->control_emergency_stop_active()) {
            return new WP_Error('ebay_control_emergency_stop', 'Globale Affiliate-Notabschaltung ist aktiv.');
        }
        $seller = preg_replace('/[^0-9A-Za-z._-]/', '', (string) $seller_username);
        if ($seller === '') { return new WP_Error('ebay_control_seller_missing', 'eBay-Verkäuferidentität für Chefsteuerung fehlt.'); }
        if (method_exists($this, 'control_partner_gate')) {
            $partner_gate = $this->control_partner_gate(
                array('provider'=>'ebay','partner_external_id'=>$seller),
                array('key'=>$portal_key)
            );
            if (is_wp_error($partner_gate)) { return $partner_gate; }
        }
        if (absint($target_term_id) > 0 && method_exists($this, 'control_target_gate')) {
            $target_gate = $this->control_target_gate($portal_key, 'hp_listing_category:' . absint($target_term_id));
            if (is_wp_error($target_gate)) { return $target_gate; }
        }
        if (absint($listing_id) > 0 && method_exists($this, 'control_output_gate')) {
            $output_gate = $this->control_output_gate($portal_key, 'ebay-listing:' . absint($listing_id));
            if (is_wp_error($output_gate)) { return $output_gate; }
        }
        return true;
    }

    /**
     * HivePress requires listing.user (post_author). Background workers have no
     * logged-in user, so eBay listings need a persistent technical owner.
     */
    private function ebay_listing_author_id($settings = array()) {
        $settings = is_array($settings) ? $settings : $this->ebay_settings();
        $candidates = array(absint($settings['private_listing_author_id'] ?? 0));
        if (function_exists('get_current_user_id')) { $candidates[] = absint(get_current_user_id()); }
        foreach ($candidates as $candidate) {
            if ($candidate <= 0) { continue; }
            if (function_exists('get_userdata')) {
                $user = get_userdata($candidate);
                if (!$user) { continue; }
            }
            if (function_exists('user_can') && !user_can($candidate, 'edit_posts')) { continue; }
            return $candidate;
        }
        if (function_exists('get_users')) {
            $ids = get_users(array('role__in'=>array('administrator','editor'),'number'=>1,'fields'=>'ids','orderby'=>'ID','order'=>'ASC'));
            foreach ((array) $ids as $candidate) {
                $candidate = absint($candidate);
                if ($candidate > 0) { return $candidate; }
            }
        }
        return 0;
    }

    private function ebay_persist_listing_author_id(&$settings) {
        $author_id = $this->ebay_listing_author_id($settings);
        if ($author_id <= 0) { return new WP_Error('ebay_hivepress_owner_missing', 'Für eBay-HivePress-Listings konnte kein gültiger technischer WordPress-Besitzer ermittelt werden.'); }
        if (absint($settings['private_listing_author_id'] ?? 0) !== $author_id) {
            $settings['private_listing_author_id'] = $author_id;
            update_option(self::OPTION_NETWORK_EBAY, $settings, false);
        }
        return $author_id;
    }

    private function ebay_secure_preview_url($post_id) {
        $post_id = absint($post_id);
        if ($post_id <= 0 || !function_exists('home_url') || !function_exists('add_query_arg') || !function_exists('wp_nonce_url')) { return ''; }
        $url = add_query_arg(array('ppar_ebay_listing_preview'=>$post_id), home_url('/'));
        return wp_nonce_url($url, 'ppar_ebay_listing_preview_' . $post_id, '_ppar_ebay_preview_nonce');
    }

    private function ebay_admin_preview_url($post_id, $base_preview_link = '') {
        return $this->ebay_secure_preview_url($post_id);
    }

    /**
     * WordPress' standard draft preview is not a supported HivePress listing route.
     * For eBay listings we therefore replace only the preview URL with a secure
     * plugin endpoint that renders HivePress' real listing_view_page template.
     */
    public function ebay_filter_preview_post_link($preview_link, $post) {
        if (!is_object($post) || (string) ($post->post_type ?? '') !== 'hp_listing') { return $preview_link; }
        $post_id = absint($post->ID ?? 0);
        if ($post_id <= 0 || (string) get_post_meta($post_id, '_ppar_ebay_item_id', true) === '') { return $preview_link; }
        if (!function_exists('current_user_can') || !current_user_can('edit_post', $post_id)) { return $preview_link; }
        $url = $this->ebay_secure_preview_url($post_id);
        return $url !== '' ? $url : $preview_link;
    }

    /**
     * Resolve an eBay listing for an authenticated admin preview. Public eBay
     * freshness is deliberately not a prerequisite here: a stale/ended tombstone
     * may still be inspected by a user who can edit that post, but it remains
     * unavailable to anonymous visitors and is clearly marked in the preview.
     */
    private function ebay_admin_preview_listing_post($post_id) {
        $post_id = absint($post_id);
        if ($post_id <= 0 || !function_exists('get_post')) { return null; }
        $post = get_post($post_id);
        if (!is_object($post) || (string) ($post->post_type ?? '') !== 'hp_listing') { return null; }
        if ((string) get_post_meta($post_id, '_ppar_ebay_item_id', true) === '') { return null; }
        if (!in_array((string) ($post->post_status ?? ''), array('draft','pending','publish','private'), true)) { return null; }
        return $post;
    }

    /**
     * Resolve a publicly renderable eBay listing. This is the hard public gate:
     * only published, active, not-ended and control-approved items pass. Source
     * freshness schedules verification but never hides Last-Known-Good inventory.
     */
    private function ebay_public_listing_post($post_id) {
        $post = $this->ebay_admin_preview_listing_post($post_id);
        if (!$post || (string) ($post->post_status ?? '') !== 'publish') { return null; }
        $post_id = absint($post->ID ?? 0);

        $lifecycle = sanitize_key((string) get_post_meta($post_id, '_ppar_ebay_lifecycle_state', true));
        if ($lifecycle !== 'active') { return null; }
        $now = time();
        $end_at = absint(get_post_meta($post_id, '_ppar_ebay_item_end_at', true));
        if ($end_at > 0 && $end_at <= $now) { return null; }

        $seller = (string) get_post_meta($post_id, '_ppar_ebay_seller_username', true);
        $target_term_id = absint(get_post_meta($post_id, '_ppar_ebay_target_term_id', true));
        $control_gate = $this->ebay_private_control_gate($seller, $target_term_id, $post_id);
        if (is_wp_error($control_gate)) { return null; }
        return $post;
    }

    /** Backward-compatible internal alias for the previous public gate name. */
    private function ebay_previewable_listing_post($post_id) {
        return $this->ebay_public_listing_post($post_id);
    }

    /**
     * Render a private eBay draft with HivePress' own listing_view_page template.
     * This endpoint never changes post_status and never makes the draft public.
     */
    /**
     * Render an eBay listing with HivePress' own listing_view_page template.
     * This is used for the protected draft preview and only as a scoped 404
     * rescue for a canonical, already published eBay listing.
     */
    private function ebay_render_hivepress_listing_page($post, $preview = false) {
        if (!is_object($post) || (string) ($post->post_type ?? '') !== 'hp_listing') {
            if (function_exists('wp_die')) { wp_die('Ungültiger HivePress-Listingdatensatz.', 'eBay-Listing', array('response'=>500)); }
            exit;
        }
        $post_id = absint($post->ID ?? 0);
        if ($post_id <= 0 || !function_exists('hivepress') || !class_exists('\\HivePress\\Models\\Listing') || !class_exists('\\HivePress\\Blocks\\Template')) {
            if (function_exists('wp_die')) { wp_die('HivePress ist für diese eBay-Anzeige nicht verfügbar.', 'eBay-Listing', array('response'=>500)); }
            exit;
        }

        $listing = \HivePress\Models\Listing::query()->get_by_id($post_id);
        if (!$listing) {
            if (function_exists('wp_die')) { wp_die('Der HivePress-Datensatz für diese eBay-Anzeige konnte nicht geladen werden.', 'eBay-Listing', array('response'=>500)); }
            exit;
        }
        // Mirrors HivePress Controller_Listing::redirect_listing_view_page().
        if (method_exists($listing, 'get_images__id')) { $listing->get_images__id(); }
        $vendor = method_exists($listing, 'get_vendor') ? $listing->get_vendor() : null;
        $hp = hivepress();
        if (is_object($hp) && isset($hp->request) && is_object($hp->request) && method_exists($hp->request, 'set_context')) {
            $hp->request->set_context('listing', $listing);
            $hp->request->set_context('vendor', $vendor);
        }

        $GLOBALS['post'] = $post;
        if (function_exists('setup_postdata')) { setup_postdata($post); }
        foreach (array('wp_query','wp_the_query') as $global_name) {
            if (!isset($GLOBALS[$global_name]) || !is_object($GLOBALS[$global_name])) { continue; }
            $query = $GLOBALS[$global_name];
            $query->posts = array($post);
            $query->post = $post;
            $query->post_count = 1;
            $query->found_posts = 1;
            $query->max_num_pages = 1;
            $query->queried_object = $post;
            $query->queried_object_id = $post_id;
            foreach (array(
                'is_single'=>true,
                'is_singular'=>true,
                'is_preview'=>(bool) $preview,
                'is_404'=>false,
                'is_home'=>false,
                'is_archive'=>false,
                'is_post_type_archive'=>false,
                'is_tax'=>false,
                'is_page'=>false,
            ) as $property=>$value) {
                if (property_exists($query, $property)) { $query->{$property} = $value; }
            }
        }

        if (function_exists('status_header')) { status_header(200); }
        if ($preview && function_exists('nocache_headers')) { nocache_headers(); }
        if (function_exists('get_header')) { get_header(); }
        if ($preview) {
            $state = sanitize_key((string) get_post_meta($post_id, '_ppar_ebay_lifecycle_state', true));
            $end_at = absint(get_post_meta($post_id, '_ppar_ebay_item_end_at', true));
            $public_ok = ($state === 'active' && ($end_at <= 0 || $end_at > time()));
            $status_text = $public_ok ? 'oeffentliche Last-Known-Good-Ausgabe aktiv' : 'nur Verwaltungsansicht – Angebot nicht oeffentlich aktiv';
            echo '<div class="ppar-ebay-preview-notice" style="max-width:1200px;margin:18px auto;padding:10px 16px;border:1px solid #c3c4c7;background:#fff"><strong>eBay-Vorschau:</strong> Nur für berechtigte Administratoren sichtbar. Der Datensatz bleibt unveröffentlicht. <small>' . esc_html($status_text) . '</small></div>';
        }
        echo (new \HivePress\Blocks\Template(array(
            'template'=>'listing_view_page',
            'context'=>array('listing'=>$listing,'vendor'=>$vendor),
        )))->render();
        if (function_exists('get_footer')) { get_footer(); }
        if (function_exists('wp_reset_postdata')) { wp_reset_postdata(); }
        exit;
    }

    /**
     * Protected eBay draft preview. It accepts both the plugin-owned nonce URL
     * and WordPress' actual backend preview query-string. Neither path changes
     * the post status or exposes a draft to anonymous visitors.
     */
    public function ebay_handle_secure_listing_preview() {
        if (function_exists('is_admin') && is_admin()) { return; }

        $secure_post_id = isset($_GET['ppar_ebay_listing_preview']) ? absint($_GET['ppar_ebay_listing_preview']) : 0;
        $native_post_id = 0;
        $preview_flag = isset($_GET['preview']) ? strtolower((string) wp_unslash($_GET['preview'])) : '';
        $requested_type = isset($_GET['post_type']) ? sanitize_key((string) wp_unslash($_GET['post_type'])) : '';
        if ($secure_post_id <= 0 && in_array($preview_flag, array('1','true'), true)) {
            $candidate_id = isset($_GET['p']) ? absint($_GET['p']) : 0;
            if ($candidate_id <= 0 && isset($_GET['preview_id'])) { $candidate_id = absint($_GET['preview_id']); }
            if ($candidate_id > 0) {
                $candidate = function_exists('get_post') ? get_post($candidate_id) : null;
                if (is_object($candidate) && (string) ($candidate->post_type ?? '') === 'hp_listing' && ($requested_type === '' || $requested_type === 'hp_listing')) {
                    $native_post_id = $candidate_id;
                }
            }
        }
        $post_id = $secure_post_id > 0 ? $secure_post_id : $native_post_id;
        if ($post_id <= 0) { return; }

        // Only our eBay listings may be intercepted. Native previews of ordinary
        // HivePress listings remain entirely owned by WordPress/HivePress.
        if ((string) get_post_meta($post_id, '_ppar_ebay_item_id', true) === '') { return; }

        if (!function_exists('is_user_logged_in') || !is_user_logged_in() || !function_exists('current_user_can') || !current_user_can('edit_post', $post_id)) {
            if (function_exists('wp_die')) { wp_die('Keine Berechtigung für diese eBay-Vorschau.', 'eBay-Vorschau', array('response'=>403)); }
            exit;
        }
        if ($secure_post_id > 0) {
            $nonce = isset($_GET['_ppar_ebay_preview_nonce']) ? (string) wp_unslash($_GET['_ppar_ebay_preview_nonce']) : '';
            if ($nonce === '' || !function_exists('wp_verify_nonce') || !wp_verify_nonce($nonce, 'ppar_ebay_listing_preview_' . $post_id)) {
                if (function_exists('wp_die')) { wp_die('Ungültiger oder abgelaufener Vorschau-Link.', 'eBay-Vorschau', array('response'=>403)); }
                exit;
            }
        }

        $preview_post = $this->ebay_admin_preview_listing_post($post_id);
        if (!$preview_post) {
            if (function_exists('wp_die')) { wp_die('Dieser eBay-HivePress-Datensatz ist nicht mehr vorhanden oder nicht vorschaufähig.', 'eBay-Vorschau', array('response'=>410)); }
            exit;
        }
        $this->ebay_render_hivepress_listing_page($preview_post, true);
    }

    /** Normalize a request/permalink path without changing its URL semantics. */
    private function ebay_normalize_request_path($path) {
        $path = rawurldecode((string) $path);
        $path = '/' . ltrim($path, '/');
        if (function_exists('untrailingslashit')) { $path = untrailingslashit($path); }
        else { $path = rtrim($path, '/'); }
        return $path === '' ? '/' : $path;
    }

    /**
     * Render the exact canonical URL of a published eBay listing directly with
     * HivePress' listing template. This intentionally does not depend on the
     * current rewrite cache or on WordPress/HivePress having recognised the
     * singular query first. It is scoped to canonical eBay listing URLs only;
     * ordinary HivePress listings are never intercepted.
     */
    public function ebay_rescue_published_listing_route() {
        if (function_exists('is_admin') && is_admin()) { return; }
        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        if (!in_array($method, array('GET','HEAD'), true)) { return; }
        if (!function_exists('get_page_by_path') || !function_exists('get_permalink')) { return; }

        $request_uri = (string) ($_SERVER['REQUEST_URI'] ?? '');
        $request_path = function_exists('wp_parse_url') ? wp_parse_url($request_uri, PHP_URL_PATH) : parse_url($request_uri, PHP_URL_PATH);
        $request_path = $this->ebay_normalize_request_path((string) $request_path);
        if ($request_path === '/') { return; }

        $parts = array_values(array_filter(explode('/', trim($request_path, '/')), 'strlen'));
        $slug = $parts ? sanitize_title(rawurldecode((string) end($parts))) : '';
        if ($slug === '') { return; }

        $post = get_page_by_path($slug, defined('OBJECT') ? OBJECT : 'OBJECT', 'hp_listing');
        if (!is_object($post) || (string) ($post->post_type ?? '') !== 'hp_listing' || (string) ($post->post_status ?? '') !== 'publish') { return; }
        $post_id = absint($post->ID ?? 0);
        if ($post_id <= 0 || (string) get_post_meta($post_id, '_ppar_ebay_item_id', true) === '') { return; }

        // Exact canonical-path equality is the hard scope boundary. A coincidental
        // slug on any other path must never be intercepted.
        $canonical = (string) get_permalink($post_id);
        $canonical_path = function_exists('wp_parse_url') ? wp_parse_url($canonical, PHP_URL_PATH) : parse_url($canonical, PHP_URL_PATH);
        if ($this->ebay_normalize_request_path((string) $canonical_path) !== $request_path) { return; }

        $public_post = $this->ebay_public_listing_post($post_id);
        if (!$public_post) { return; }
        $this->ebay_render_hivepress_listing_page($public_post, false);
    }

    /**
     * Validate the WordPress object immediately after materialization against
     * the minimum HivePress Listing model contract. A malformed object must
     * never be treated as a successfully routed eBay listing.
     */
    private function ebay_validate_hivepress_listing_state($listing_id, $target_term_id, $author_id) {
        $listing_id = absint($listing_id);
        $target_term_id = absint($target_term_id);
        $author_id = absint($author_id);
        if ($listing_id <= 0) { return new WP_Error('ebay_hivepress_listing_missing', 'HivePress-Listing-ID fehlt nach dem Speichern.'); }
        if (function_exists('get_post_type') && (string) get_post_type($listing_id) !== 'hp_listing') {
            return new WP_Error('ebay_hivepress_post_type_invalid', 'Gespeicherter eBay-Datensatz ist kein HivePress-Listing.');
        }
        if (function_exists('get_post_status') && !in_array((string) get_post_status($listing_id), array('draft','pending','publish','private'), true)) {
            return new WP_Error('ebay_hivepress_status_invalid', 'Gespeichertes eBay-HivePress-Listing hat einen unzulässigen Status.');
        }
        if (function_exists('get_post_field') && absint(get_post_field('post_author', $listing_id)) !== $author_id) {
            return new WP_Error('ebay_hivepress_owner_roundtrip', 'HivePress-Listing-Besitzer wurde nicht korrekt gespeichert.');
        }
        if (function_exists('get_post_field')) {
            if (trim((string) get_post_field('post_title', $listing_id)) === '' || trim((string) get_post_field('post_content', $listing_id)) === '') {
                return new WP_Error('ebay_hivepress_required_content_missing', 'HivePress-Pflichtfelder Titel/Beschreibung fehlen nach dem Speichern.');
            }
        }
        if ($target_term_id <= 0) { return new WP_Error('ebay_hivepress_target_missing', 'HivePress-Zielkategorie fehlt nach dem Speichern.'); }
        if (function_exists('wp_get_post_terms')) {
            $term_ids = wp_get_post_terms($listing_id, 'hp_listing_category', array('fields'=>'ids'));
            if (is_wp_error($term_ids)) { return $term_ids; }
            $term_ids = array_map('absint', (array) $term_ids);
            if (!in_array($target_term_id, $term_ids, true)) {
                return new WP_Error('ebay_hivepress_target_roundtrip', 'HivePress-Zielkategorie wurde nicht korrekt gespeichert.');
            }
        }
        return true;
    }

    private function ebay_materialize_private_listing($stored, $item, $target_term_id, $settings) {
        if (!function_exists('post_type_exists') || !post_type_exists('hp_listing') || !function_exists('taxonomy_exists') || !taxonomy_exists('hp_listing_category')) {
            return new WP_Error('ebay_hivepress_missing', 'HivePress-Listingmodell ist nicht verfügbar.');
        }
        $listing_id = absint($stored['listing_post_id'] ?? 0);
        if ($listing_id <= 0 && function_exists('get_posts')) {
            $ids = get_posts(array('post_type'=>'hp_listing','post_status'=>array('draft','pending','publish','private'),'meta_key'=>'_ppar_ebay_item_id','meta_value'=>(string) $item['item_id'],'posts_per_page'=>1,'fields'=>'ids'));
            $listing_id = $ids ? absint($ids[0]) : 0;
        }
        $control_gate = $this->ebay_private_control_gate((string)($item['seller_username'] ?? ''), absint($target_term_id), $listing_id);
        if (is_wp_error($control_gate)) { return $control_gate; }
        $author_id = $this->ebay_listing_author_id($settings);
        if ($author_id <= 0) { return new WP_Error('ebay_hivepress_owner_missing', 'HivePress verlangt einen gültigen Listing-Besitzer; der technische Besitzer fehlt.'); }
        $existing_status = $listing_id > 0 && function_exists('get_post_status') ? (string) get_post_status($listing_id) : '';
        $existing_lifecycle = $listing_id > 0 ? sanitize_key((string) get_post_meta($listing_id, '_ppar_ebay_lifecycle_state', true)) : '';
        $stored_publish_intent = $listing_id > 0 ? sanitize_key((string) get_post_meta($listing_id, '_ppar_ebay_publish_intent', true)) : '';
        // V5.5.0: Ein durch die 6-Stunden-Sicherung auf Entwurf gesetztes Listing
        // merkt sich seinen vorherigen Veröffentlichungswunsch. Nach einem
        // erfolgreichen frischen Abgleich wird ein zuvor manuell veröffentlichtes
        // Listing wieder veröffentlicht. Ein normal manuell auf Entwurf gesetztes
        // aktives Listing wird dagegen nicht ungefragt reaktiviert.
        $was_published_before_stale = in_array($existing_lifecycle, array('stale','ended'), true) && $stored_publish_intent === 'publish';
        $keep_current_publish = !in_array($existing_lifecycle, array('stale','ended'), true) && $existing_status === 'publish';
        $capacity_publish = $this->ebay_private_auto_publish_allowed($target_term_id, $listing_id, $settings);
        $post_status = ($capacity_publish || $was_published_before_stale || $keep_current_publish) ? 'publish' : 'draft';
        $post_data = array(
            'post_type'=>'hp_listing',
            'post_title'=>sanitize_text_field((string) $item['title']),
            'post_content'=>$this->ebay_listing_content($item),
            'post_excerpt'=>sanitize_text_field(trim((string) $item['price_value'] . ' ' . (string) $item['currency'] . (!empty($item['condition_text']) ? ' · ' . (string) $item['condition_text'] : ''))),
            'post_status'=>$post_status,
            'post_author'=>$author_id,
        );
        if ($listing_id > 0) { $post_data['ID'] = $listing_id; $result = wp_update_post($post_data, true); }
        else { $result = wp_insert_post($post_data, true); }
        if (is_wp_error($result) || absint($result) <= 0) { return is_wp_error($result) ? $result : new WP_Error('ebay_listing_save_failed', 'HivePress-Listing konnte nicht gespeichert werden.'); }
        $listing_id = absint($result);
        $terms = wp_set_post_terms($listing_id, array(absint($target_term_id)), 'hp_listing_category', false);
        if (is_wp_error($terms)) { return $terms; }
        $state_check = $this->ebay_validate_hivepress_listing_state($listing_id, $target_term_id, $author_id);
        if (is_wp_error($state_check)) {
            if (function_exists('get_post_status') && get_post_status($listing_id) === 'publish' && function_exists('wp_update_post')) {
                wp_update_post(array('ID'=>$listing_id,'post_status'=>'draft'));
            }
            return $state_check;
        }
        update_post_meta($listing_id, 'hp_url', (string) $item['affiliate_url']);
        if ((string) get_post_meta($listing_id, 'hp_url', true) !== (string) $item['affiliate_url']) {
            return new WP_Error('ebay_listing_url_roundtrip', 'Affiliate-Link wurde nicht zeichengetreu gespeichert.');
        }
        update_post_meta($listing_id, '_ppar_ebay_item_id', (string) $item['item_id']);
        update_post_meta($listing_id, '_ppar_ebay_seller_type', 'INDIVIDUAL');
        update_post_meta($listing_id, '_ppar_ebay_lifecycle_state', 'active');
        update_post_meta($listing_id, '_ppar_ebay_publish_intent', $post_status === 'publish' ? 'publish' : 'draft');
        if ($post_status !== 'publish' && !empty($settings['private_auto_publish']) && !$was_published_before_stale && !$keep_current_publish) {
            update_post_meta($listing_id, '_ppar_ebay_reserve_state', 'capacity');
        } elseif (function_exists('delete_post_meta')) {
            delete_post_meta($listing_id, '_ppar_ebay_reserve_state');
        }
        update_post_meta($listing_id, '_ppar_ebay_last_seen_at', time());
        if (function_exists('delete_post_meta')) { delete_post_meta($listing_id, '_ppar_ebay_stale_since'); }
        update_post_meta($listing_id, '_ppar_ebay_seller_username', preg_replace('/[^0-9A-Za-z._-]/', '', (string)($item['seller_username'] ?? '')));
        update_post_meta($listing_id, '_ppar_ebay_target_term_id', absint($target_term_id));
        update_post_meta($listing_id, '_ppar_ebay_fresh_until', absint($stored['fresh_until'] ?? 0));
        update_post_meta($listing_id, '_ppar_ebay_source_hash', (string) $item['source_hash']);
        update_post_meta($listing_id, '_ppar_ebay_price_value', (string) $item['price_value']);
        update_post_meta($listing_id, '_ppar_ebay_currency', (string) $item['currency']);
        update_post_meta($listing_id, '_ppar_ebay_item_end_at', absint($item['item_end_at']));
        update_post_meta($listing_id, '_ppar_ebay_affiliate_url', (string) $item['affiliate_url']);
        $classification = is_array($item['portal_classification'] ?? null) ? $item['portal_classification'] : array();
        update_post_meta($listing_id, '_ppar_ebay_product_slug', sanitize_title((string) ($classification['product_slug'] ?? '')));
        update_post_meta($listing_id, '_ppar_ebay_portal_path', sanitize_text_field((string) ($classification['path'] ?? '')));
        update_post_meta($listing_id, '_ppar_ebay_topic_score', absint($classification['score'] ?? 0));
        update_post_meta($listing_id, '_ppar_ebay_evidence_hash', sanitize_text_field((string) ($classification['evidence_hash'] ?? '')));
        $image = $this->ebay_sideload_listing_image($listing_id, $item);
        if (is_wp_error($image)) {
            if (get_post_status($listing_id) === 'publish') { wp_update_post(array('ID'=>$listing_id,'post_status'=>'draft')); }
            return $image;
        }
        global $wpdb;
        $wpdb->update($this->ebay_items_table(), array(
            'listing_post_id'=>$listing_id,'status'=>'active','source_state'=>'available','policy_state'=>'allowed','route_state'=>'ready',
            'output_state'=>$post_status === 'publish' ? 'listing_published' : 'listing_draft',
            'policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,'classifier_version'=>self::EBAY_PRIVATE_CLASSIFIER_VERSION,
            'rejection_reason'=>'','updated_at'=>time()
        ), array('id'=>absint($stored['id'])), $this->ebay_db_formats(array(
            'listing_post_id'=>$listing_id,'status'=>'active','source_state'=>'available','policy_state'=>'allowed','route_state'=>'ready',
            'output_state'=>$post_status === 'publish' ? 'listing_published' : 'listing_draft',
            'policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,'classifier_version'=>self::EBAY_PRIVATE_CLASSIFIER_VERSION,
            'rejection_reason'=>'','updated_at'=>time()
        )), array('%d'));
        return array('listing_id'=>$listing_id,'attachment_id'=>absint($image));
    }

    private function ebay_business_creative($item, $rule, $run_uuid, $classification = array()) {
        $seller = preg_replace('/[^0-9A-Za-z._-]/', '', (string) ($item['seller_username'] ?? ''));
        if ($seller === '') { $seller = 'ebay-business'; }
        $partner_name = !empty($item['seller_username']) ? 'eBay: ' . (string) $item['seller_username'] : 'eBay Business';
        $classification = is_array($classification) ? $classification : array();
        $tags = implode(', ', array_filter(array_merge(
            array('eBay', sanitize_text_field((string) ($classification['product_title'] ?? '')), sanitize_text_field((string) ($classification['hub'] ?? '')), sanitize_text_field((string) ($classification['main_hub'] ?? ''))),
            array_values(array_filter(array_map('sanitize_text_field', (array) ($item['category_names'] ?? array())))),
            array(sanitize_text_field((string) ($item['condition_text'] ?? '')))
        )));
        $description_parts = array_filter(array(
            (string) ($item['short_description'] ?? ''),
            trim((string) ($item['price_value'] ?? '') . ' ' . (string) ($item['currency'] ?? '')),
            !empty($item['condition_text']) ? 'Zustand: ' . (string) $item['condition_text'] : '',
        ));
        $payload = array(
            '_declared_width'=>0,'_declared_height'=>0,'_dimension_state'=>'pending','_dimension_error'=>'','_image_sha256'=>'','_image_mime'=>'','_image_bytes'=>0,'_measured_at'=>0,
            '_preverify_topic_status'=>'portal_pending','_preverify_topic_score'=>0,'_preverify_topic_targets'=>array(),
            'ebay_seller_account_type'=>'BUSINESS','ebay_seller_username'=>(string) $item['seller_username'],'ebay_item_id'=>(string) $item['item_id'],
            'ebay_item_end_at'=>absint($item['item_end_at']),'ebay_buying_options'=>(array) $item['buying_options'],'ebay_rule_id'=>sanitize_key((string) ($rule['id'] ?? '')),
            'ebay_verified_product_slug'=>sanitize_title((string) ($classification['product_slug'] ?? '')),'ebay_verified_product_concept'=>sanitize_key((string) ($classification['product_concept_id'] ?? '')),'ebay_verified_concept_kind'=>sanitize_key((string) ($classification['concept_kind'] ?? 'product')),'ebay_verified_product_targets'=>array_values((array) ($classification['product_target_slugs'] ?? array())),'ebay_verified_path'=>sanitize_text_field((string) ($classification['path'] ?? '')),'ebay_verified_score'=>absint($classification['score'] ?? 0),'ebay_evidence_hash'=>sanitize_text_field((string) ($classification['evidence_hash'] ?? '')),'ebay_business_match_contract'=>sanitize_key((string) ($classification['business_match_contract'] ?? '')),
            'price'=>sanitize_text_field((string) ($item['price_value'] ?? '')),'currency'=>strtoupper(substr(sanitize_text_field((string) ($item['currency'] ?? 'EUR')),0,10)),'availability'=>'available',
        );
        $external_id = substr(preg_replace('/[^0-9A-Za-z._-]/', '-', (string) $item['item_id']), 0, 191);
        $destination_url = !empty($item['item_web_url']) ? (string) $item['item_web_url'] : (string) $item['affiliate_url'];
        $identity = hash('sha256', 'ebay|' . $seller . '|' . $external_id);
        $source = array(
            'provider'=>'ebay','partner_external_id'=>$seller,'external_id'=>$external_id,'title'=>(string) $item['title'],'description'=>implode(' · ', $description_parts),
            'tags'=>$tags,'image_url'=>(string) $item['image_url'],'destination_url'=>$destination_url,'tracking_url'=>(string) $item['affiliate_url'],
            'source_status'=>'active','source_kind'=>'ebay_business_item','item_end_at'=>absint($item['item_end_at']),
            'price'=>sanitize_text_field((string) ($item['price_value'] ?? '')),'currency'=>strtoupper(substr(sanitize_text_field((string) ($item['currency'] ?? 'EUR')),0,10)),'availability'=>'available',
        );
        return array(
            'provider'=>'ebay','partner_external_id'=>$seller,'partner_name'=>$partner_name,'external_id'=>$external_id,'identity_hash'=>$identity,
            'creative_type'=>'product','title'=>(string) $item['title'],'description'=>implode(' · ', $description_parts),'tags'=>$tags,
            'image_url'=>(string) $item['image_url'],'destination_url'=>$destination_url,'tracking_url'=>(string) $item['affiliate_url'],
            'width'=>0,'height'=>0,'source_status'=>'active','source_kind'=>'ebay_business_item','availability_state'=>'active','missing_count'=>0,
            'last_complete_run'=>substr((string) $run_uuid, 0, 36),'review_status'=>'review','selected'=>0,'content_scope'=>'unclassified','scope_source'=>'','classified_at'=>0,
            'topic_status'=>'format_pending','topic_score'=>0,'topic_targets'=>'[]','source_hash'=>hash('sha256', wp_json_encode($source, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)),
            'payload'=>wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        );
    }

    /**
     * V5.18 – harter Vertrag fuer automatisch ausspielbare eBay-BUSINESS-Produkte.
     * Nur ein bereits durch ebay_classify_portal_item() eindeutig verifiziertes
     * Produktziel darf den manuellen Review-Pfad verlassen. Private Zielbuckets,
     * unklare Scores oder fremde Provider fallen fail-closed heraus.
     */
    private function ebay_business_product_contract($row) {
        if (!is_array($row)
            || sanitize_key((string) ($row['provider'] ?? '')) !== 'ebay'
            || sanitize_key((string) ($row['source_kind'] ?? '')) !== 'ebay_business_item'
            || sanitize_key((string) ($row['creative_type'] ?? '')) !== 'product'
            || sanitize_key((string) ($row['source_status'] ?? 'active')) !== 'active'
            || sanitize_key((string) ($row['availability_state'] ?? 'active')) !== 'active') { return array(); }
        $payload=json_decode((string)($row['payload']??''),true); $payload=is_array($payload)?$payload:array();
        if (strtoupper(sanitize_key((string)($payload['ebay_seller_account_type']??''))) !== 'BUSINESS') { return array(); }
        $score=absint($payload['ebay_verified_score']??0);
        $evidence_hash=strtolower(sanitize_text_field((string)($payload['ebay_evidence_hash']??'')));
        $match_contract=sanitize_key((string)($payload['ebay_business_match_contract']??''));
        $concept_id=sanitize_key((string)($payload['ebay_verified_product_concept']??''));
        $target_slugs=array_values(array_unique(array_filter(array_map('sanitize_title',(array)($payload['ebay_verified_product_targets']??array())))));
        if ($score<80 || $match_contract!=='concept_v3' || $concept_id==='' || !preg_match('/^[a-f0-9]{64}$/',$evidence_hash) || !$target_slugs) { return array(); }
        $catalog=$this->ebay_portal_catalog(); if(is_wp_error($catalog)){return array();}
        $collections=array(
            'product'=>(array)($catalog['business_concepts']??array()),
            'hub'=>(array)($catalog['business_hub_concepts']??array()),
        );
        foreach($collections as $concept_kind=>$concepts){
            foreach($concepts as $concept){
                if(!is_array($concept)||sanitize_key((string)($concept['id']??''))!==$concept_id){continue;}
                $pages=array_values(array_filter((array)($concept['target_pages']??array()),'is_array'));
                $allowed=array_values(array_unique(array_filter(array_map(static function($p){return sanitize_title((string)($p['slug']??''));},$pages))));
                $target_slugs=array_values(array_intersect($target_slugs,$allowed));
                if(!$target_slugs){return array();}
                $primary=null;
                foreach($pages as $page){ if(sanitize_title((string)($page['slug']??''))===$target_slugs[0]){$primary=$page;break;} }
                if(!is_array($primary)){$primary=$pages[0]??array();}
                return array(
                    'product_concept_id'=>$concept_id,
                    'concept_kind'=>$concept_kind,
                    'product_slug'=>sanitize_title((string)($primary['slug']??'')),
                    'product_target_slugs'=>$target_slugs,
                    'product_title'=>sanitize_text_field((string)($concept['title']??'')),
                    'hub_slug'=>sanitize_title((string)($primary['hub_slug']??'')),
                    'hub'=>sanitize_text_field((string)($primary['hub']??'')),
                    'main_slug'=>sanitize_title((string)($primary['main_slug']??'')),
                    'main_hub'=>sanitize_text_field((string)($primary['main_hub']??'')),
                    'target_pages'=>$pages,'score'=>$score,'evidence_hash'=>$evidence_hash,
                );
            }
        }
        return array();
    }

    /**
     * Verwendet fuer eBay-BUSINESS ausschliesslich den verifizierten Produkt-Slug
     * als Primaerziel. Die generische Textklassifikation darf diesen harten
     * Katalogtreffer nicht auf eine benachbarte Seite umbiegen.
     */
    private function ebay_business_exact_product_classification($row, $portal, $targets) {
        $contract=$this->ebay_business_product_contract($row); if(!$contract){return array();}
        $wanted=array_flip((array)($contract['product_target_slugs']??array()));
        $matches=array();
        foreach((array)$targets as $target){
            if(!is_array($target)||sanitize_key((string)($target['type']??''))!=='page'){continue;}
            $slug=sanitize_title((string)($target['slug']??''));
            if($slug!==''&&isset($wanted[$slug])){$matches[$slug]=$target;}
        }
        if(!$matches){
            return array('status'=>'review','confidence'=>absint($contract['score']??0),'reason'=>'Kein verifiziertes Produktziel ist als veröffentlichte Portalseite vorhanden.','target'=>null,'alternatives'=>array(),'source'=>'ebay_verified_product_target_missing');
        }
        $primary=null;
        foreach((array)$contract['product_target_slugs'] as $slug){ if(isset($matches[$slug])){$primary=$matches[$slug];break;} }
        if(!is_array($primary)){$primary=reset($matches);}
        if(method_exists($this,'control_target_gate')){ $gate=$this->control_target_gate((string)($portal['key']??''),(string)($primary['key']??'')); if(is_wp_error($gate)){return $gate;} }
        return array('status'=>'ready','confidence'=>absint($contract['score']??0),'reason'=>'Verifiziertes eBay-BUSINESS-Produktkonzept stimmt mit mindestens einer echten Portalseite überein.','target'=>$primary,'alternatives'=>array_values($matches),'source'=>'ebay_verified_product_concept');
    }

    /**
     * Ein verifiziertes Produkt darf auf seiner Produktseite, dem zugehoerigen
     * Hub-2, dem Haupt-Hub und den redaktionellen Unterkategorien erscheinen.
     * Journal wird bewusst nicht global befuellt; ohne konkrete Themenkante
     * bleibt ein BUSINESS-Produkt dort fail-closed.
     */
    private function ebay_business_campaign_target_keys($row, $target = array()) {
        $contract=$this->ebay_business_product_contract($row); if(!$contract){return array();}
        $keys=array(); $product_slugs=(array)($contract['product_target_slugs']??array());
        // Hub-Konzepte sind bereits ein eigenstaendiges, exaktes Ziel. Sie duerfen
        // nicht pauschal auf Haupt-Hub oder Nachbarseiten aufgeweitet werden.
        if (sanitize_key((string)($contract['concept_kind']??'product')) === 'hub') {
            $slug=sanitize_title((string)($contract['product_slug']??''));
            return $slug!=='' ? array('page:'.$slug) : array();
        }
        $catalog=$this->ebay_portal_catalog();
        if(!is_wp_error($catalog)){
            foreach((array)($catalog['product_targets']??array()) as $page){
                if(!is_array($page)||!in_array(sanitize_title((string)($page['slug']??'')),$product_slugs,true)){continue;}
                foreach(array('slug','hub_slug','main_slug') as $field){$slug=sanitize_title((string)($page[$field]??'')); if($slug!==''){$keys[]='page:'.$slug;}}
            }
            foreach((array)($catalog['article_targets']??array()) as $article){
                if(!is_array($article)||!in_array(sanitize_title((string)($article['product_slug']??'')),$product_slugs,true)){continue;}
                $slug=sanitize_title((string)($article['category_slug']??'')); if($slug!==''){$keys[]='category:'.$slug;}
            }
        }
        return array_values(array_unique(array_filter($keys)));
    }

    private function ebay_business_campaign_placements($row) {
        return $this->ebay_business_product_contract($row) ? array(
            'hub_product_1','hub_product_2','hub_product_3',
            'category_product_1','category_product_2','category_product_3',
            'journal_product_1','journal_product_2','journal_product_3',
        ) : array();
    }

    /**
     * V5.18 – Preis-/Textupdates eines bereits verifizierten BUSINESS-Produkts
     * dürfen nicht unnötig den Bildstatus auf pending zurücksetzen. Solange die
     * Bild-URL bytegleich bleibt, werden ausschließlich die bereits belegten
     * Asset-Evidenzen übernommen; ändert sich das Bild, läuft die normale harte
     * Bildprüfung erneut.
     */
    private function ebay_business_reuse_verified_asset($creative) {
        if (!is_array($creative)
            || empty($creative['identity_hash'])
            || empty($creative['image_url'])
            || !method_exists($this, 'creative_library_table')) {
            return $creative;
        }
        global $wpdb;
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT width, height, image_url, payload, topic_status, topic_score, topic_targets FROM {$this->creative_library_table()} WHERE identity_hash=%s",
            (string) $creative['identity_hash']
        ), ARRAY_A);
        if (!is_array($existing)
            || (string) ($existing['image_url'] ?? '') !== (string) ($creative['image_url'] ?? '')
            || absint($existing['width'] ?? 0) <= 0
            || absint($existing['height'] ?? 0) <= 0) {
            return $creative;
        }
        $old_payload = json_decode((string) ($existing['payload'] ?? ''), true);
        $new_payload = json_decode((string) ($creative['payload'] ?? ''), true);
        $old_payload = is_array($old_payload) ? $old_payload : array();
        $new_payload = is_array($new_payload) ? $new_payload : array();
        if (!in_array((string) ($old_payload['_dimension_state'] ?? ''), array('verified','mismatch'), true)
            || empty($old_payload['_image_sha256'])) {
            return $creative;
        }
        foreach (array('_dimension_state','_dimension_error','_image_sha256','_image_mime','_image_bytes','_measured_at') as $key) {
            if (array_key_exists($key, $old_payload)) { $new_payload[$key] = $old_payload[$key]; }
        }
        $creative['width'] = absint($existing['width']);
        $creative['height'] = absint($existing['height']);
        $creative['topic_status'] = sanitize_key((string) ($existing['topic_status'] ?? 'auto_verified'));
        $creative['topic_score'] = absint($existing['topic_score'] ?? 0);
        $creative['topic_targets'] = (string) ($existing['topic_targets'] ?? '[]');
        $creative['payload'] = wp_json_encode($new_payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return $creative;
    }

    private function ebay_business_pending_asset_count() {
        if (!method_exists($this, 'creative_library_table')) { return 0; }
        global $wpdb;
        $table = $this->creative_library_table();
        return absint($wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE provider='ebay' AND source_kind='ebay_business_item' AND creative_type='product' AND image_url<>'' AND source_status='active' AND availability_state='active' AND (payload LIKE '%\"_dimension_state\":\"pending\"%' OR ((width=0 OR height=0) AND payload NOT LIKE '%\"_dimension_state\":\"failed\"%' AND payload NOT LIKE '%\"_dimension_state\":\"verified\"%' AND payload NOT LIKE '%\"_dimension_state\":\"mismatch\"%'))"));
    }

    /**
     * Deterministische, begrenzte BUSINESS-Bildpruefung. Sie wird vom
     * Bestandsabgleich als eigene Phase ausgefuehrt; die Diagnose bleibt read-only.
     * Der normale Creative-Cron bleibt paralleler Fallback.
     */
    private function ebay_business_verify_asset_batch($limit = 1) {
        if (!method_exists($this, 'creative_library_table') || !method_exists($this, 'creative_library_verify_asset_row')) {
            return array('processed'=>0,'remaining'=>0,'verified'=>0,'blocked'=>0);
        }
        $limit = max(1, min(2, absint($limit)));
        global $wpdb;
        $table = $this->creative_library_table();
        $rows = (array) $wpdb->get_results("SELECT * FROM {$table} WHERE provider='ebay' AND source_kind='ebay_business_item' AND creative_type='product' AND image_url<>'' AND source_status='active' AND availability_state='active' AND (payload LIKE '%\"_dimension_state\":\"pending\"%' OR ((width=0 OR height=0) AND payload NOT LIKE '%\"_dimension_state\":\"failed\"%' AND payload NOT LIKE '%\"_dimension_state\":\"verified\"%' AND payload NOT LIKE '%\"_dimension_state\":\"mismatch\"%')) ORDER BY id ASC LIMIT " . absint($limit), ARRAY_A);
        $verified = 0; $blocked = 0;
        foreach ($rows as $row) {
            $result = $this->creative_library_verify_asset_row($row, false, true);
            if (is_wp_error($result)) { $blocked++; } else { $verified++; }
        }
        return array(
            'processed'=>count($rows),
            'remaining'=>$this->ebay_business_pending_asset_count(),
            'verified'=>$verified,
            'blocked'=>$blocked,
        );
    }

    public function handle_ebay_business_asset_pump() {
        wp_send_json_error(array('message'=>'Workflow V2: Diagnose ist read-only; Bildprüfung läuft ausschließlich über die reguläre Hintergrundverarbeitung.'), 410);
    }


    private function ebay_business_deactivate_existing_output($row, $reason) {
        $row = is_array($row) ? $row : array();
        $reason = sanitize_text_field((string) $reason);
        if ($reason === '') { $reason = 'BUSINESS-Produktmatch ist nicht eindeutig; Ausgabe bleibt auf Review.'; }
        global $wpdb;
        $hash = strtolower(sanitize_text_field((string) ($row['creative_identity_hash'] ?? '')));
        $creative_table = method_exists($this, 'creative_library_table') ? $this->creative_library_table() : '';
        if (!preg_match('/^[a-f0-9]{64}$/', $hash) && $creative_table !== '') {
            $found = $wpdb->get_var($wpdb->prepare("SELECT identity_hash FROM {$creative_table} WHERE provider='ebay' AND source_kind='ebay_business_item' AND external_id=%s ORDER BY id DESC LIMIT 1", (string) ($row['item_id'] ?? '')));
            $candidate = strtolower(sanitize_text_field((string) $found));
            if (preg_match('/^[a-f0-9]{64}$/', $candidate)) { $hash = $candidate; }
        }
        if (!preg_match('/^[a-f0-9]{64}$/', $hash)) { return false; }
        if ($creative_table !== '') {
            $creative = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$creative_table} WHERE identity_hash=%s", $hash), ARRAY_A);
            if (is_array($creative)) {
                $payload = json_decode((string) ($creative['payload'] ?? ''), true);
                $payload = is_array($payload) ? $payload : array();
                foreach (array('ebay_verified_product_slug','ebay_verified_path','ebay_evidence_hash','ebay_business_match_contract','ebay_verified_product_concept') as $key) { $payload[$key] = ''; }
                $payload['ebay_verified_product_targets'] = array();
                $payload['ebay_verified_score'] = 0;
                $payload['_business_match_state'] = 'review';
                $payload['_business_match_reason'] = $reason;
                $payload['_business_match_at'] = time();
                $wpdb->update($creative_table, array(
                    'review_status'=>'review','selected'=>0,'content_scope'=>'unclassified','scope_source'=>'ebay_business_strict_match',
                    'topic_status'=>'review','topic_score'=>0,'topic_targets'=>'[]',
                    'payload'=>wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                ), array('id'=>absint($creative['id'] ?? 0)));
            }
        }
        if (method_exists($this, 'output_objects_table')) {
            $output_table = $this->output_objects_table();
            $objects = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$output_table} WHERE creative_identity_hash=%s AND output_type='product_campaign'", $hash), ARRAY_A);
            foreach ((array) $objects as $object) {
                if (method_exists($this, 'output_deactivate_materialized_object')) { $this->output_deactivate_materialized_object($object, $reason); }
            }
            $wpdb->update($output_table, array(
                'target_type'=>'','target_key'=>'','target_label'=>'','slot_id'=>'',
                'status'=>'review','decision_source'=>'ebay_business_strict_match','decision_reason'=>$reason,'last_verified'=>time(),'updated_at'=>time(),
            ), array('creative_identity_hash'=>$hash,'output_type'=>'product_campaign'));
        }
        return true;
    }

    /** BUSINESS-Review ersetzt eine eventuell alte Auto-Ausgabe sofort fail-closed. */
    private function ebay_business_hold_for_review($row, $item, $rule, $error, $settings = null) {
        $settings = is_array($settings) ? $settings : $this->ebay_settings();
        $item = is_array($item) ? $item : array();
        $rule = is_array($rule) ? $rule : array();
        $preserved_last_good = $this->ebay_business_preserve_last_good_on_soft_review($row, $error);
        $stored = $this->ebay_store_review_candidate($item, $rule, 'BUSINESS', $error, $settings);
        if (is_wp_error($stored)) { return $stored; }
        if (!method_exists($this, 'creative_library_upsert')) { return $stored; }
        // Leere Klassifikation ist absichtlich: Der generische Ausgabeplan darf
        // hoechstens einen inaktiven Review-Entwurf erzeugen und superseded damit
        // eine eventuell alte, falsch aktive BUSINESS-Kampagne.
        $creative = $this->ebay_business_creative($item, $rule, 'business-review-' . time(), array());
        $creative = $this->ebay_business_reuse_verified_asset($creative);
        $state = $this->creative_library_upsert($creative);
        if ($state !== 'failed' && $state !== 'blocked') {
            global $wpdb;
            $wpdb->update($this->ebay_items_table(), array('creative_identity_hash'=>(string) $creative['identity_hash'],'updated_at'=>time()), array('id'=>absint($stored['id'] ?? 0)), array('%s','%d'), array('%d'));
            // If a Last-Known-Good campaign exists, a review candidate is stored
            // diagnostically but must not supersede/deactivate that public output.
            if (!$preserved_last_good && method_exists($this, 'output_plan_creative') && method_exists($this, 'creative_library_table')) {
                $persisted = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->creative_library_table()} WHERE identity_hash=%s", (string) $creative['identity_hash']), ARRAY_A);
                if (is_array($persisted)) { $this->output_plan_creative($persisted, true); }
            }
        }
        return $stored;
    }

    private function ebay_business_restore_local_reclass_freshness($row) {
        $row = is_array($row) ? $row : array();
        $id = absint($row['id'] ?? 0);
        if ($id <= 0) { return; }
        global $wpdb;
        $wpdb->update($this->ebay_items_table(), array(
            'last_seen'=>absint($row['last_seen'] ?? 0),
            'fresh_until'=>absint($row['fresh_until'] ?? 0),
        ), array('id'=>$id), array('%d','%d'), array('%d'));
    }

    /**
     * Einmalige lokale V5.28-Neubewertung des vorhandenen BUSINESS-Bestands.
     * Kein eBay-Request: verwendet ausschliesslich die bereits gespeicherten
     * Originalpayloads. Dadurch werden alte Fehlzuordnungen entfernt und klare
     * Treffer auf demselben Creative/Kampagnenpfad neu geplant.
     */
    public function maybe_run_ebay_business_match_upgrade($limit = 25) {
        // Deprecated read-only adapter. Opening a diagnostic/admin page must not
        // change classification, campaigns, assets or output state.
        $state = get_option(self::OPTION_EBAY_MAINTENANCE_STATE, array());
        $state = is_array($state) ? $state : array();
        $stats = is_array($state['last_stats'] ?? null) ? $state['last_stats'] : array();
        return array(
            'completed_at'=>absint($state['completed_at'] ?? 0),
            'scanned'=>absint($stats['scanned'] ?? 0),
            'ready'=>absint($stats['ready_business'] ?? 0),
            'review'=>absint($stats['review'] ?? 0),
            'blocked'=>absint($stats['blocked'] ?? 0),
        );
    }

    public function handle_ebay_business_match_pump() {
        wp_send_json_error(array('message'=>'Workflow V2: Diagnose ist read-only; BUSINESS-Klassifikation läuft ausschließlich im geplanten Maintenance-Job.'), 410);
    }

    private function ebay_route_business($stored, $item, $rule, $run_uuid, $classification = array()) {
        if (!method_exists($this, 'creative_library_upsert')) { return new WP_Error('ebay_creative_library_missing', 'Werbemittelbibliothek fehlt.'); }
        $classification = is_array($classification) ? $classification : array();
        if (sanitize_key((string) ($classification['business_match_contract'] ?? '')) !== 'concept_v3') {
            $classification = $this->ebay_business_classify_portal_item_strict($item, $rule);
            if (is_wp_error($classification)) { return $classification; }
            $item['portal_classification'] = $classification;
        }
        $creative = $this->ebay_business_creative($item, $rule, $run_uuid, $classification);
        $creative = $this->ebay_business_reuse_verified_asset($creative);
        $state = $this->creative_library_upsert($creative);
        if ($state === 'failed' || $state === 'blocked') { return new WP_Error('ebay_business_import_failed', 'eBay-Business-Creative wurde blockiert.'); }
        global $wpdb;
        $plan = array('created'=>0,'active'=>0,'blocked'=>0,'review'=>0,'errors'=>array());
        if (method_exists($this, 'output_plan_creative') && method_exists($this, 'creative_library_table')) {
            $persisted = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->creative_library_table()} WHERE identity_hash=%s", (string) $creative['identity_hash']), ARRAY_A);
            if (is_array($persisted)) { $plan = $this->output_plan_creative($persisted, true); }
        }
        $plan = is_array($plan) ? $plan : array();
        if (absint($plan['active'] ?? 0) < 1) {
            $error = new WP_Error('ebay_business_materialization_not_active','BUSINESS-Ersatzroute wurde nicht aktiv materialisiert; Last-Known-Good bleibt unverändert.');
            if ($this->ebay_business_preserve_last_good_on_soft_review($stored, $error)) {
                // Structured success-with-review: callers must not run their
                // generic route-error handlers afterwards, otherwise the freshly
                // persisted review_last_good state would be overwritten again.
                return array(
                    'creative_identity_hash'=>(string) $creative['identity_hash'],
                    'state'=>'last_good_preserved','last_good_preserved'=>1,
                    'review_code'=>$error->get_error_code(),'review_reason'=>$error->get_error_message(),'plan'=>$plan,
                );
            }
            $repair = array('route_state'=>'review','output_state'=>'repair_pending','rejection_reason'=>$error->get_error_message(),'updated_at'=>time());
            $wpdb->update($this->ebay_items_table(), $repair, array('id'=>absint($stored['id'])), $this->ebay_db_formats($repair), array('%d'));
            return $error;
        }
        $route_update = array(
            'creative_identity_hash'=>(string) $creative['identity_hash'],'status'=>'active','source_state'=>'available','policy_state'=>'allowed','route_state'=>'ready',
            'output_state'=>'creative_ready','policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,'classifier_version'=>self::EBAY_BUSINESS_CLASSIFIER_VERSION,
            'rejection_reason'=>'','updated_at'=>time()
        );
        $wpdb->update($this->ebay_items_table(), $route_update, array('id'=>absint($stored['id'])), $this->ebay_db_formats($route_update), array('%d'));
        if (method_exists($this, 'creative_library_schedule_asset_verification')) { $this->creative_library_schedule_asset_verification(10); }
        return array('creative_identity_hash'=>$creative['identity_hash'],'state'=>$state,'plan'=>$plan);
    }

    private function ebay_mark_route_error($stored, $error) {
        if (!is_array($stored) || empty($stored['id'])) { return; }
        global $wpdb;
        $message = is_wp_error($error) ? $error->get_error_message() : sanitize_text_field((string) $error);
        $route_update = array('status'=>'review','route_state'=>'review','output_state'=>'none','rejection_reason'=>$message,'updated_at'=>time());
        $wpdb->update($this->ebay_items_table(), $route_update, array('id'=>absint($stored['id'])), $this->ebay_db_formats($route_update), array('%d'));
    }

    /** Fach-/Zielunsicherheit ist gemäß Chef-Veto-Vertrag übersteuerbar. */
    private function ebay_is_soft_classification_error($error) {
        if (!is_wp_error($error)) { return false; }
        return in_array((string) $error->get_error_code(), array(
            'ebay_topic_evidence_missing',
            'ebay_portal_topic_missing',
            'ebay_portal_topic_negative',
            'ebay_portal_target_missing',
            'ebay_portal_target_ambiguous',
            'ebay_business_title_missing',
            'ebay_business_target_missing',
            'ebay_business_target_ambiguous',
            'ebay_business_concept_missing',
            'ebay_business_concept_ambiguous',
            'ebay_business_concept_target_missing',
            'ebay_private_bucket_missing',
            'ebay_private_bucket_low_confidence',
            'ebay_private_bucket_ambiguous',
        ), true);
    }

    private function ebay_error_code($error, $fallback = 'unknown') {
        $code = is_wp_error($error) ? sanitize_key((string) $error->get_error_code()) : sanitize_key((string) $error);
        return $code !== '' ? $code : sanitize_key((string) $fallback);
    }

    private function ebay_summary_reason_add(&$summary, $kind, $error, $rule_id, $seller_type, $profile_key = '') {
        $kind = sanitize_key((string) $kind);
        $code = $this->ebay_error_code($error, $kind . '_unknown');
        $bucket = $kind . '_reasons';
        if (!isset($summary[$bucket]) || !is_array($summary[$bucket])) { $summary[$bucket] = array(); }
        $summary[$bucket][$code] = absint($summary[$bucket][$code] ?? 0) + 1;
        $profile_key = (string) $profile_key;
        if ($profile_key === '') { $profile_key = sanitize_key((string) $rule_id) . '|' . strtoupper(sanitize_key((string) $seller_type)); }
        if (isset($summary['profile_stats'][$profile_key])) {
            if (!isset($summary['profile_stats'][$profile_key][$bucket]) || !is_array($summary['profile_stats'][$profile_key][$bucket])) {
                $summary['profile_stats'][$profile_key][$bucket] = array();
            }
            $summary['profile_stats'][$profile_key][$bucket][$code] = absint($summary['profile_stats'][$profile_key][$bucket][$code] ?? 0) + 1;
        }
        return $code;
    }

    private function ebay_candidate_scope_key($item_id) {
        return 'ebay-candidate:' . substr(sanitize_text_field((string) $item_id), 0, 191);
    }

    private function ebay_candidate_manual_decision($item_id) {
        if (!method_exists($this, 'control_get_decision') || !method_exists($this, 'output_local_portal_key')) {
            return array('exists'=>false,'status'=>'automatic','reason'=>'','payload'=>array());
        }
        $portal_key = sanitize_key((string) $this->output_local_portal_key());
        if ($portal_key === '') { return array('exists'=>false,'status'=>'automatic','reason'=>'','payload'=>array()); }
        return $this->control_get_decision($portal_key, 'output', $this->ebay_candidate_scope_key($item_id));
    }

    private function ebay_private_bucket_definitions() {
        return array(
            'pferde-ponys'=>'Pferde & Ponys',
            'sattel-zaumzeug'=>'Sattel & Zaumzeug',
            'decken-schutz'=>'Decken & Schutz',
            'stall-weide-haltung'=>'Stall, Weide & Haltung',
            'fuetterung-pflege'=>'Fütterung & Pflege',
            'anhaenger-transport'=>'Anhänger & Transport',
            'reitbekleidung-zubehoer'=>'Reitbekleidung & Zubehör',
            'sonstiges'=>'Sonstiges',
        );
    }

    /**
     * Recover a missing private target from durable evidence. This is used by the
     * stündlichen getItem refresh so older rows with target_term_id=0 are repaired
     * instead of failing their HivePress round-trip.
     */
    private function ebay_recover_private_target_term_id($row, $settings) {
        $row = is_array($row) ? $row : array();
        $settings = is_array($settings) ? $settings : $this->ebay_settings();
        $candidates = array();
        $row_target = absint($row['target_term_id'] ?? 0);
        if ($row_target > 0) { $candidates[] = $row_target; }

        $listing_id = absint($row['listing_post_id'] ?? 0);
        if ($listing_id > 0 && function_exists('get_post_meta')) {
            $meta_target = absint(get_post_meta($listing_id, '_ppar_ebay_target_term_id', true));
            if ($meta_target > 0) { $candidates[] = $meta_target; }
        }
        if ($listing_id > 0 && function_exists('wp_get_post_terms')) {
            $term_ids = wp_get_post_terms($listing_id, 'hp_listing_category', array('fields'=>'ids'));
            if (!is_wp_error($term_ids)) {
                foreach ((array) $term_ids as $term_id) { $candidates[] = absint($term_id); }
            }
        }

        $payload = json_decode((string) ($row['source_payload'] ?? ''), true);
        $classification = is_array($payload) && is_array($payload['portal_classification'] ?? null) ? $payload['portal_classification'] : array();
        $bucket_slug = sanitize_title((string) ($classification['private_bucket_slug'] ?? ''));
        if ($bucket_slug !== '' && function_exists('get_term_by')) {
            $term = get_term_by('slug', $bucket_slug, 'hp_listing_category');
            if (is_object($term)) { $candidates[] = absint($term->term_id ?? 0); }
        }

        $rule = $this->ebay_rule_by_id((string) ($row['rule_id'] ?? ''), $settings);
        $rule_slug = sanitize_title((string) ($rule['target_term_slug'] ?? ''));
        if ($rule_slug !== '' && function_exists('get_term_by')) {
            $term = get_term_by('slug', $rule_slug, 'hp_listing_category');
            if (is_object($term)) { $candidates[] = absint($term->term_id ?? 0); }
        }

        foreach (array_values(array_unique(array_filter(array_map('absint', $candidates)))) as $candidate) {
            $valid = $this->ebay_validate_private_target_term_id($candidate, $settings);
            if (!is_wp_error($valid)) { return absint($valid->term_id ?? 0); }
        }
        return 0;
    }

    private function ebay_persist_recovered_private_target($row, $term_id) {
        $row = is_array($row) ? $row : array();
        $term_id = absint($term_id);
        if ($term_id <= 0) { return false; }
        global $wpdb;
        $row_id = absint($row['id'] ?? 0);
        if ($row_id > 0 && is_object($wpdb)) {
            $wpdb->update($this->ebay_items_table(), array('target_term_id'=>$term_id,'updated_at'=>time()), array('id'=>$row_id), array('%d','%d'), array('%d'));
        }
        $listing_id = absint($row['listing_post_id'] ?? 0);
        if ($listing_id > 0 && function_exists('update_post_meta')) {
            update_post_meta($listing_id, '_ppar_ebay_target_term_id', $term_id);
        }
        return true;
    }

    private function ebay_private_published_count($term_id, $exclude_listing_id = 0) {
        $term_id = absint($term_id);
        if ($term_id <= 0 || !class_exists('WP_Query')) { return 0; }
        $args = array(
            'post_type'=>'hp_listing',
            'post_status'=>'publish',
            'posts_per_page'=>1,
            'paged'=>1,
            'fields'=>'ids',
            'no_found_rows'=>false,
            'ignore_sticky_posts'=>true,
            'tax_query'=>array(array('taxonomy'=>'hp_listing_category','field'=>'term_id','terms'=>array($term_id),'operator'=>'IN','include_children'=>false)),
            'meta_query'=>array(array('key'=>'_ppar_ebay_item_id','compare'=>'EXISTS')),
        );
        $exclude_listing_id = absint($exclude_listing_id);
        if ($exclude_listing_id > 0) { $args['post__not_in'] = array($exclude_listing_id); }
        $query = new WP_Query($args);
        return max(0, absint($query->found_posts ?? 0));
    }

    private function ebay_private_auto_publish_allowed($target_term_id, $listing_id, $settings) {
        if (empty($settings['private_auto_publish'])) { return false; }
        $max = max(1, absint($settings['private_max_per_category'] ?? 30));
        $target = max(1, min($max, absint($settings['private_target_per_category'] ?? 24)));
        $count = $this->ebay_private_published_count($target_term_id, $listing_id);
        if ($count >= $max) { return false; }
        return $count < $target;
    }

    private function ebay_validate_private_target_term_id($term_id, $settings) {
        $term_id = absint($term_id);
        $root_id = absint($settings['private_root_term_id'] ?? 0);
        if ($term_id <= 0 || $root_id <= 0 || !function_exists('get_term')) {
            return new WP_Error('ebay_review_target_missing', 'Gültige eBay-HivePress-Zielkategorie fehlt.');
        }
        $term = get_term($term_id, 'hp_listing_category');
        if (!$term || is_wp_error($term)) { return new WP_Error('ebay_review_target_missing', 'Gewählte HivePress-Zielkategorie existiert nicht.'); }
        if (sanitize_title((string) ($term->slug ?? '')) === 'ebay-privatanzeigen') {
            return new WP_Error('ebay_review_target_legacy_provider', 'Die frühere Provider-Kategorie „eBay-Privatanzeigen“ ist kein gültiges Ziel mehr.');
        }
        $parent = absint($term->parent ?? 0);
        if ($parent !== $root_id) {
            return new WP_Error('ebay_review_target_outside_root', 'Manuelles Ziel muss eine direkte Unterkategorie von „Private Anzeigen“ sein.');
        }
        return $term;
    }

    private function ebay_target_from_candidate_decision($decision, $settings) {
        $decision = is_array($decision) ? $decision : array();
        if (sanitize_key((string) ($decision['status'] ?? 'automatic')) !== 'approved') {
            return new WP_Error('ebay_review_decision_not_approved', 'Keine manuelle Freigabe vorhanden.');
        }
        $payload = is_array($decision['payload'] ?? null) ? $decision['payload'] : array();
        $target_key = sanitize_text_field((string) ($payload['target_key'] ?? ''));
        if (!preg_match('/^hp_listing_category:(\d+)$/', $target_key, $m)) {
            return new WP_Error('ebay_review_target_payload_invalid', 'Manuelle Freigabe enthält kein gültiges HivePress-Ziel.');
        }
        return $this->ebay_validate_private_target_term_id(absint($m[1]), $settings);
    }

    private function ebay_manual_classification($term, $item, $reason = '') {
        $term_id = absint(is_object($term) ? ($term->term_id ?? 0) : 0);
        $slug = sanitize_title(is_object($term) ? (string) ($term->slug ?? '') : '');
        $label = sanitize_text_field(is_object($term) ? (string) ($term->name ?? '') : '');
        return array(
            'status'=>'ready',
            'score'=>100,
            'product_slug'=>$slug,
            'product_title'=>$label,
            'hub'=>'Private Anzeigen',
            'main_hub'=>'Anzeigenmarkt',
            'path'=>'Private Anzeigen > ' . $label,
            'private_bucket_slug'=>$slug,
            'horse_hits'=>array(),
            'strong_horse_hits'=>array(),
            'hits'=>array(),
            'evidence_hash'=>hash('sha256', (string) ($item['source_hash'] ?? '') . '|manual|' . $term_id),
            'manual_override'=>true,
            'manual_reason'=>sanitize_text_field((string) $reason),
        );
    }

    private function ebay_store_review_candidate($item, $rule, $seller_type, $error, $settings) {
        $item = is_array($item) ? $item : array();
        $rule = is_array($rule) ? $rule : array();
        $seller_type = strtoupper(sanitize_key((string) $seller_type));
        $code = $this->ebay_error_code($error, 'ebay_review_required');
        $message = is_wp_error($error) ? (string) $error->get_error_message() : sanitize_text_field((string) $error);
        $item['portal_classification'] = array(
            'status'=>'review',
            'reason_code'=>$code,
            'reason'=>$message,
            'evidence_hash'=>hash('sha256', (string) ($item['source_hash'] ?? '') . '|review|' . $code),
        );
        $route = $seller_type === 'INDIVIDUAL' ? 'private_review' : 'business_review';
        $stored = $this->ebay_upsert_item($item, $rule, $route, 0, $settings);
        if (is_wp_error($stored)) { return $stored; }
        global $wpdb;
        $wpdb->update($this->ebay_items_table(), array(
            'status'=>'review',
            'source_state'=>'available',
            'policy_state'=>'allowed',
            'route_state'=>'review',
            'output_state'=>'none',
            'policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,
            'classifier_version'=>$seller_type === 'INDIVIDUAL' ? self::EBAY_PRIVATE_CLASSIFIER_VERSION : self::EBAY_BUSINESS_CLASSIFIER_VERSION,
            'rejection_reason'=>'[' . $code . '] ' . $message,
            'updated_at'=>time(),
        ), array('id'=>absint($stored['id'])));
        $stored['status'] = 'review';
        $stored['rejection_reason'] = '[' . $code . '] ' . $message;
        if ($seller_type === 'INDIVIDUAL') {
            $this->ebay_private_listing_route_meta($stored, 'review', $message);
        }
        return $stored;
    }

    private function ebay_review_candidates($limit = 100) {
        global $wpdb;
        $limit = max(1, min(250, absint($limit)));
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->ebay_items_table()} WHERE status='review' ORDER BY updated_at DESC, id DESC LIMIT %d",
            $limit
        ), ARRAY_A);
    }

    private function ebay_private_review_targets($settings = null) {
        $settings = is_array($settings) ? $settings : $this->ebay_settings();
        $root_id = absint($settings['private_root_term_id'] ?? 0);
        if ($root_id <= 0 || !function_exists('get_terms')) { return array(); }
        $terms = get_terms(array(
            'taxonomy'=>'hp_listing_category',
            'parent'=>$root_id,
            'hide_empty'=>false,
            'orderby'=>'name',
            'order'=>'ASC',
        ));
        return is_wp_error($terms) ? array() : array_values(array_filter((array) $terms, 'is_object'));
    }

    private function ebay_rule_by_id($rule_id, $settings = null) {
        $settings = is_array($settings) ? $settings : $this->ebay_settings();
        $rule_id = sanitize_key((string) $rule_id);
        foreach ((array) ($settings['rules'] ?? array()) as $rule) {
            if (sanitize_key((string) ($rule['id'] ?? '')) === $rule_id) { return is_array($rule) ? $rule : array(); }
        }
        return array();
    }

    public function handle_ebay_review_decision() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_ebay_review_decision', 'ppar_ebay_nonce');
        $row_id = absint($_POST['row_id'] ?? 0);
        $decision = sanitize_key((string) ($_POST['review_decision'] ?? ''));
        $reason = sanitize_text_field(wp_unslash((string) ($_POST['reason'] ?? '')));
        $target_term_id = absint($_POST['target_term_id'] ?? 0);
        $result = null;

        if ($row_id <= 0 || !in_array($decision, array('approve','veto'), true)) {
            $result = new WP_Error('ebay_review_request_invalid', 'Prüfentscheidung ist unvollständig.');
        }
        if (!is_wp_error($result) && $reason === '') {
            $result = new WP_Error('ebay_review_reason_missing', 'Für eine Chefentscheidung ist eine Begründung erforderlich.');
        }

        global $wpdb;
        $row = !is_wp_error($result) ? $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->ebay_items_table()} WHERE id=%d", $row_id), ARRAY_A) : null;
        if (!is_wp_error($result) && (!is_array($row) || (string) ($row['status'] ?? '') !== 'review')) {
            $result = new WP_Error('ebay_review_candidate_missing', 'Prüfkandidat ist nicht mehr offen.');
        }

        $settings = $this->ebay_settings();
        if (!is_wp_error($result) && absint($row['fresh_until'] ?? 0) < time()) {
            $result = new WP_Error('ebay_review_candidate_stale', 'Prüfkandidat ist älter als sechs Stunden und darf nicht freigegeben werden. Bitte zuerst neu abrufen.');
        }
        $seller_type = !is_wp_error($result) ? strtoupper(sanitize_key((string) ($row['seller_account_type'] ?? ''))) : '';
        if (!is_wp_error($result) && $seller_type !== 'INDIVIDUAL') {
            $result = new WP_Error('ebay_review_private_only', 'Diese Prüfentscheidung ist ausschließlich für private eBay-Listings vorgesehen.');
        }

        $payload = !is_wp_error($result) ? json_decode((string) ($row['source_payload'] ?? ''), true) : array();
        $raw = is_array($payload) && is_array($payload['raw'] ?? null) ? $payload['raw'] : array();
        $item = !is_wp_error($result) ? $this->ebay_accept_item($raw, 'INDIVIDUAL', $settings) : $result;
        if (!is_wp_error($result) && is_wp_error($item)) { $result = $item; }

        $portal_key = method_exists($this, 'output_local_portal_key') ? sanitize_key((string) $this->output_local_portal_key()) : '';
        if (!is_wp_error($result) && $portal_key === '') {
            $result = new WP_Error('ebay_review_portal_missing', 'Portalkontext für Chefentscheidung fehlt.');
        }

        if (!is_wp_error($result) && $decision === 'veto') {
            $saved = $this->control_set_decision(
                $portal_key,
                'output',
                $this->ebay_candidate_scope_key((string) $item['item_id']),
                'veto',
                $reason,
                array('provider'=>'ebay'),
                'ebay_candidate_veto'
            );
            if (is_wp_error($saved)) { $result = $saved; }
            else {
                $wpdb->update($this->ebay_items_table(), array(
                    'status'=>'blocked_manual',
                    'rejection_reason'=>'[ebay_manual_veto] ' . $reason,
                    'updated_at'=>time(),
                ), array('id'=>$row_id), array('%s','%s','%d'), array('%d'));
                $result = array('status'=>'vetoed','item_id'=>(string) $item['item_id']);
            }
        }

        if (!is_wp_error($result) && $decision === 'approve') {
            $term = $this->ebay_validate_private_target_term_id($target_term_id, $settings);
            if (is_wp_error($term)) { $result = $term; }
            else {
                $target_key = 'hp_listing_category:' . absint($term->term_id ?? 0);
                $saved = $this->control_set_decision(
                    $portal_key,
                    'output',
                    $this->ebay_candidate_scope_key((string) $item['item_id']),
                    'approved',
                    $reason,
                    array(
                        'provider'=>'ebay',
                        'target_type'=>'hp_listing_category',
                        'target_key'=>$target_key,
                        'target_label'=>sanitize_text_field((string) ($term->name ?? '')),
                        'target_context'=>'ebay_private_review',
                    ),
                    'ebay_candidate_approval'
                );
                if (is_wp_error($saved)) { $result = $saved; }
                else {
                    $classification = $this->ebay_manual_classification($term, $item, $reason);
                    $item['portal_classification'] = $classification;
                    $rule = $this->ebay_rule_by_id((string) ($row['rule_id'] ?? ''), $settings);
                    if (!$rule) {
                        // Das manuelle Ziel ist maßgeblich; ein alter Regelbezug darf die
                        // Freigabe nicht verlieren. Für Audit bleibt die alte ID erhalten.
                        $rule = array('id'=>sanitize_key((string) ($row['rule_id'] ?? 'manual_review')));
                    }
                    $stored = $this->ebay_upsert_item($item, $rule, 'private', absint($term->term_id ?? 0), $settings);
                    if (is_wp_error($stored)) { $result = $stored; }
                    else {
                        $listing = $this->ebay_materialize_private_listing($stored, $item, absint($term->term_id ?? 0), $settings);
                        if (is_wp_error($listing)) { $result = $listing; }
                        else { $result = array('status'=>'approved','item_id'=>(string) $item['item_id'],'listing_post_id'=>absint($listing['listing_id'] ?? 0)); }
                    }
                }
            }
        }

        $ok = !is_wp_error($result);
        $message = $ok
            ? ($decision === 'approve' ? 'Prüfkandidat freigegeben und als HivePress-Listing übernommen.' : 'Prüfkandidat per Chef-Veto gesperrt.')
            : $result->get_error_message();
        wp_safe_redirect(add_query_arg(array(
            'page'=>'affiliate-portal-ebay',
            'ppar_ebay'=>$ok ? 'review_saved' : 'review_failed',
            'message'=>rawurlencode($message),
        ), admin_url('admin.php')));
        exit;
    }

    private function ebay_sync_job_load() {
        $job = get_option(self::OPTION_EBAY_SYNC_JOB, array());
        return is_array($job) ? $job : array();
    }

    private function ebay_sync_job_save($job) {
        $job = is_array($job) ? $job : array();
        $job['updated_at'] = time();
        update_option(self::OPTION_EBAY_SYNC_JOB, $job, false);
        return $job;
    }

    private function ebay_sync_job_runtime_compatible($job) {
        if (!is_array($job)) { return false; }
        $build = (string) ($job['build'] ?? '');
        $schema = (string) ($job['schema'] ?? '');
        $engine = (string) ($job['engine'] ?? '');
        return $build !== ''
            && hash_equals((string) self::EBAY_RUNTIME_BUILD, $build)
            && $schema === '2.0'
            && $engine === 'resumable-background';
    }

    private function ebay_sync_job_is_open($job) {
        return $this->ebay_sync_job_runtime_compatible($job)
            && in_array(sanitize_key((string) ($job['status'] ?? '')), array('queued','running'), true);
    }

    /**
     * Runtime-stamp an open job so an older resumable queue can be resumed safely
     * after updating the current build. This prevents a mixed-version run from being reported
     * as an unidentifiable legacy sync and carries the required HivePress owner.
     */
    private function ebay_sync_job_stamp_runtime(&$job, $author_id = 0) {
        if (!is_array($job)) { $job = array(); }
        $job['schema'] = '2.0';
        $job['engine'] = 'resumable-background';
        $job['build'] = self::EBAY_RUNTIME_BUILD;
        if (absint($author_id) > 0) { $job['listing_author_id'] = absint($author_id); }
        if (!isset($job['summary']) || !is_array($job['summary'])) { $job['summary'] = array(); }
        $job['summary']['schema'] = '2.0';
        $job['summary']['engine'] = 'resumable-background';
        $job['summary']['build'] = self::EBAY_RUNTIME_BUILD;
        return $job;
    }

    private function ebay_sync_profiles($settings) {
        $profiles = array();
        foreach ((array) ($settings['rules'] ?? array()) as $rule) {
            if (empty($rule['active'])) { continue; }
            foreach (array('INDIVIDUAL','BUSINESS') as $seller_type) {
                $allowed = $seller_type === 'INDIVIDUAL'
                    ? (!empty($settings['private_enabled']) && !empty($rule['private']))
                    : (!empty($settings['business_enabled']) && !empty($rule['business']));
                if (!$allowed) { continue; }
                $queries = $seller_type === 'INDIVIDUAL' ? $this->ebay_private_query_variants($rule) : array((string) ($rule['query'] ?? ''));
                foreach ($queries as $query_index => $query_text) {
                    $profile_rule = $rule;
                    $profile_rule['query'] = $query_text;
                    $key = sanitize_key((string) ($rule['id'] ?? '')) . '|' . $seller_type . '|q' . ($query_index + 1);
                    $profiles[$key] = array(
                        'key'=>$key,
                        'rule'=>$profile_rule,
                        'seller_type'=>$seller_type,
                        'next'=>'',
                        'active'=>true,
                        'pages'=>0,
                    );
                }
            }
        }
        return $profiles;
    }

    private function ebay_sync_summary_new($settings, $run_uuid, $profiles) {
        $max_pages = max(1, absint($settings['max_pages_per_profile'] ?? 4));
        $max_requests = max(1, absint($settings['max_requests_per_run'] ?? 40));
        $profile_stats = array();
        foreach ((array) $profiles as $key => $profile) {
            $profile_stats[$key] = array(
                'rule'=>sanitize_key((string) ($profile['rule']['id'] ?? '')),
                'query'=>sanitize_text_field((string) ($profile['rule']['query'] ?? '')),
                'seller_type'=>(string) ($profile['seller_type'] ?? ''),
                'requests'=>0,'pages'=>0,'received'=>0,'accepted'=>0,'review_pending'=>0,
                'hard_blocked'=>0,'technical_blocked'=>0,'manual_vetoed'=>0,'duplicates_skipped'=>0,
                'hard_reasons'=>array(),'review_reasons'=>array(),'technical_reasons'=>array(),'manual_veto_reasons'=>array(),
                'complete'=>false,'stopped_reason'=>'',
            );
        }
        return array(
            'schema'=>'2.0','engine'=>'resumable-background','build'=>self::EBAY_RUNTIME_BUILD,
            'status'=>'running','run_uuid'=>$run_uuid,'profiles'=>count($profiles),'requests'=>0,'pages'=>0,'received'=>0,'received_unique'=>0,
            'technically_valid'=>0,'accepted'=>0,'duplicates_skipped'=>0,'private_listings'=>0,'business_creatives'=>0,
            'review_pending'=>0,'hard_blocked'=>0,'technical_blocked'=>0,'manual_vetoed'=>0,'blocked'=>0,
            'hard_reasons'=>array(),'review_reasons'=>array(),'technical_reasons'=>array(),'manual_veto_reasons'=>array(),
            'errors'=>array(),'profile_stats'=>$profile_stats,
            'budget'=>array(
                'page_size'=>absint($settings['max_per_rule'] ?? 50),
                'max_pages_per_profile'=>$max_pages,
                'max_requests_per_run'=>$max_requests,
                'worker_time_budget_seconds'=>max(10, min(30, absint($settings['run_time_budget_seconds'] ?? 20))),
                'segment_limit_seconds'=>600,
                'stopped_reason'=>'',
            ),
            'started_at'=>time(),'segments'=>1,
        );
    }

    private function ebay_schedule_worker_fallback($delay = 12) {
        if (!function_exists('wp_next_scheduled') || !function_exists('wp_schedule_single_event')) { return; }
        if (!wp_next_scheduled(self::EBAY_WORKER_HOOK)) {
            wp_schedule_single_event(time() + max(10, absint($delay)), self::EBAY_WORKER_HOOK);
        }
    }

    private function ebay_dispatch_worker($job = null) {
        $job = is_array($job) ? $job : $this->ebay_sync_job_load();
        if (!$this->ebay_sync_job_is_open($job)) { return false; }
        $this->ebay_schedule_worker_fallback(12);
        $token = (string) ($job['worker_token'] ?? '');
        if ($token === '' || !function_exists('wp_remote_post')) { return false; }
        $response = wp_remote_post(admin_url('admin-post.php'), array(
            'timeout'=>0.01,
            'blocking'=>false,
            'redirection'=>0,
            'sslverify'=>apply_filters('https_local_ssl_verify', false),
            'body'=>array('action'=>'ppar_ebay_worker_tick','token'=>$token),
        ));
        return !is_wp_error($response);
    }

    /**
     * V5.21 – harte Segmentgrenze fuer Discovery. Ein einzelner manueller oder
     * Cron-getriebener Lauf darf die Admin-Oberflaeche nicht stundenlang binden.
     * Bereits verarbeitete Ergebnisse bleiben idempotent gespeichert; ein wegen
     * Zeitbudget partieller Job kann beim naechsten Abruf exakt fortgesetzt werden.
     */
    private function ebay_sync_segment_limit_seconds($job = array()) {
        return 600; // 10 Minuten harte Obergrenze je Segment.
    }

    private function ebay_sync_segment_expired($job) {
        if (!$this->ebay_sync_job_is_open($job)) { return false; }
        $started = absint($job['segment_started_at'] ?? ($job['created_at'] ?? 0));
        return $started > 0 && (time() - $started) >= $this->ebay_sync_segment_limit_seconds($job);
    }

    private function ebay_sync_job_is_resumable_partial($job) {
        if (!$this->ebay_sync_job_runtime_compatible($job) || sanitize_key((string) ($job['status'] ?? '')) !== 'partial') { return false; }
        $reason = sanitize_key((string) (($job['summary']['budget']['stopped_reason'] ?? '')));
        if ($reason !== 'segment_time_budget') { return false; }
        if (!empty($job['current_page']) && is_array($job['current_page'])) { return true; }
        return $this->ebay_sync_active_profile_key($job) !== '';
    }

    private function ebay_sync_resume_partial_job($job, $author_id) {
        $job = is_array($job) ? $job : array();
        if (!$this->ebay_sync_job_is_resumable_partial($job)) { return array(); }
        $job['status'] = 'queued';
        $job['worker_phase'] = 'queued';
        $job['finished_at'] = 0;
        $job['created_at'] = time();
        $job['segment_started_at'] = time();
        $job['last_worker_at'] = 0;
        $job['last_progress_at'] = time();
        $this->ebay_sync_job_stamp_runtime($job, $author_id);
        if (!isset($job['summary']) || !is_array($job['summary'])) { $job['summary'] = array(); }
        $job['summary']['status'] = 'running';
        $job['summary']['finished_at'] = 0;
        if (!isset($job['summary']['budget']) || !is_array($job['summary']['budget'])) { $job['summary']['budget'] = array(); }
        $job['summary']['budget']['stopped_reason'] = '';
        $job['summary']['budget']['segment_limit_seconds'] = $this->ebay_sync_segment_limit_seconds($job);
        $job['summary']['segments'] = absint($job['summary']['segments'] ?? 1) + 1;
        $this->ebay_sync_job_save($job);
        return $job;
    }

    private function ebay_start_sync_job($manual = false) {
        $settings = $this->ebay_settings();
        if (empty($settings['enabled']) && !$manual) { return array('status'=>'disabled'); }
        $errors = $this->ebay_configuration_errors($settings);
        if ($errors) { return new WP_Error('ebay_configuration_invalid', implode(' ', $errors)); }
        $this->maybe_install_ebay_schema();
        $author_id = $this->ebay_persist_listing_author_id($settings);
        if (is_wp_error($author_id)) { return $author_id; }

        $refresh_job = $this->ebay_refresh_job_load();
        if ($this->ebay_refresh_job_is_open($refresh_job)) {
            return $manual
                ? new WP_Error('ebay_sync_refresh_running', 'Der eBay-Bestandsabgleich läuft bereits. Discovery startet erst danach.')
                : array('status'=>'deferred_refresh_running');
        }

        $existing = $this->ebay_sync_job_load();
        if ($this->ebay_sync_job_is_open($existing)) {
            $this->ebay_sync_job_stamp_runtime($existing, $author_id);
            $this->ebay_sync_job_save($existing);
            $this->ebay_dispatch_worker($existing);
            return array('status'=>'already_running','run_uuid'=>(string) ($existing['run_uuid'] ?? ''),'summary'=>(array) ($existing['summary'] ?? array()));
        }
        if ($this->ebay_sync_job_is_resumable_partial($existing)) {
            $resumed = $this->ebay_sync_resume_partial_job($existing, $author_id);
            if ($resumed) {
                $this->ebay_dispatch_worker($resumed);
                return array('status'=>'resumed','run_uuid'=>(string) ($resumed['run_uuid'] ?? ''),'summary'=>(array) ($resumed['summary'] ?? array()));
            }
        }

        $profiles = $this->ebay_sync_profiles($settings);
        if (!$profiles) { return new WP_Error('ebay_profiles_empty', 'Keine aktiven eBay-Abrufprofile vorhanden.'); }
        $run_uuid = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : substr(hash('sha256', microtime(true) . '|' . mt_rand()), 0, 36);
        $worker_token = function_exists('wp_generate_password') ? wp_generate_password(48, false, false) : hash('sha256', $run_uuid . '|' . microtime(true) . '|' . mt_rand());
        $job = array(
            'schema'=>'2.0','engine'=>'resumable-background','build'=>self::EBAY_RUNTIME_BUILD,'status'=>'queued','run_uuid'=>$run_uuid,'worker_token'=>$worker_token,'manual'=>!empty($manual),'listing_author_id'=>absint($author_id),
            'created_at'=>time(),'segment_started_at'=>time(),'updated_at'=>time(),'finished_at'=>0,'worker_phase'=>'queued','last_worker_at'=>0,
            'profiles'=>$profiles,'profile_order'=>array_keys($profiles),'profile_cursor'=>0,'current_page'=>array(),
            'summary'=>$this->ebay_sync_summary_new($settings, $run_uuid, $profiles),
            'routed_items'=>array(),'soft_pending'=>array(),'hard_seen'=>array(),'technical_valid'=>array(),'unique_received'=>array(),'manual_veto_seen'=>array(),
        );
        $this->ebay_sync_job_save($job);
        $this->ebay_dispatch_worker($job);
        return array('status'=>'queued','run_uuid'=>$run_uuid,'summary'=>$job['summary']);
    }

    /**
     * V5.6.0 – Der öffentliche Einstieg startet nur noch einen fortsetzbaren
     * Hintergrundjob. Weder Admin-Request noch regulärer 3h-Cron führen den
     * kompletten paginierten Abruf synchron aus.
     */
    public function run_ebay_sync($manual = false) {
        return $this->ebay_start_sync_job($manual);
    }

    private function ebay_sync_active_profile_key($job) {
        $order = array_values((array) ($job['profile_order'] ?? array()));
        $profiles = (array) ($job['profiles'] ?? array());
        $count = count($order);
        if ($count <= 0) { return ''; }
        $start = absint($job['profile_cursor'] ?? 0) % $count;
        for ($offset = 0; $offset < $count; $offset++) {
            $idx = ($start + $offset) % $count;
            $key = (string) ($order[$idx] ?? '');
            if ($key !== '' && !empty($profiles[$key]['active'])) { return $key; }
        }
        return '';
    }

    private function ebay_sync_advance_cursor(&$job, $profile_key) {
        $order = array_values((array) ($job['profile_order'] ?? array()));
        $idx = array_search((string) $profile_key, $order, true);
        $job['profile_cursor'] = $idx === false || !$order ? 0 : (($idx + 1) % count($order));
    }

    private function ebay_sync_rebuild_review_summary(&$job) {
        $summary = (array) ($job['summary'] ?? array());
        $summary['review_pending'] = 0;
        $summary['review_reasons'] = array();
        foreach ((array) ($summary['profile_stats'] ?? array()) as $key => $stat) {
            $summary['profile_stats'][$key]['review_pending'] = 0;
            $summary['profile_stats'][$key]['review_reasons'] = array();
        }
        foreach ((array) ($job['soft_pending'] ?? array()) as $item_id => $pending) {
            if (isset($job['routed_items'][$item_id])) { continue; }
            $code = sanitize_key((string) ($pending['code'] ?? 'ebay_review_required'));
            if ($code === '') { $code = 'ebay_review_required'; }
            $profile_key = (string) ($pending['profile_key'] ?? '');
            $summary['review_pending']++;
            $summary['review_reasons'][$code] = absint($summary['review_reasons'][$code] ?? 0) + 1;
            if (isset($summary['profile_stats'][$profile_key])) {
                $summary['profile_stats'][$profile_key]['review_pending']++;
                $summary['profile_stats'][$profile_key]['review_reasons'][$code] = absint($summary['profile_stats'][$profile_key]['review_reasons'][$code] ?? 0) + 1;
            }
        }
        $job['summary'] = $summary;
    }

    private function ebay_sync_process_item(&$job, $raw, $profile_key, $settings) {
        if (!isset($job['profiles'][$profile_key])) { return; }
        $profile = $job['profiles'][$profile_key];
        $summary =& $job['summary'];
        $summary['profile_stats'][$profile_key] = isset($summary['profile_stats'][$profile_key]) ? $summary['profile_stats'][$profile_key] : array();
        $raw = is_array($raw) ? $raw : array();
        $raw_item_id = substr(sanitize_text_field((string) ($raw['itemId'] ?? '')), 0, 191);

        if ($raw_item_id !== '' && isset($job['routed_items'][$raw_item_id])) {
            $summary['duplicates_skipped']++;
            $summary['profile_stats'][$profile_key]['duplicates_skipped']++;
            return;
        }

        $item = $this->ebay_accept_item($raw, $profile['seller_type'], $settings);
        if (is_wp_error($item)) {
            $seen_key = $profile['seller_type'] . '|' . ($raw_item_id !== '' ? $raw_item_id : hash('sha256', wp_json_encode($raw)));
            if (!isset($job['hard_seen'][$seen_key])) {
                $job['hard_seen'][$seen_key] = true;
                $summary['hard_blocked']++;
                $summary['profile_stats'][$profile_key]['hard_blocked']++;
                $this->ebay_summary_reason_add($summary, 'hard', $item, (string) $profile['rule']['id'], $profile['seller_type'], $profile_key);
            } else {
                $summary['duplicates_skipped']++;
                $summary['profile_stats'][$profile_key]['duplicates_skipped']++;
            }
            return;
        }

        $item_id = (string) $item['item_id'];
        $job['technical_valid'][$item_id] = true;
        if (isset($job['routed_items'][$item_id])) {
            $summary['duplicates_skipped']++;
            $summary['profile_stats'][$profile_key]['duplicates_skipped']++;
            return;
        }

        $classification = null;
        if ($profile['seller_type'] === 'INDIVIDUAL') {
            $manual_decision = $this->ebay_candidate_manual_decision($item_id);
            $manual_status = sanitize_key((string) ($manual_decision['status'] ?? 'automatic'));
            if (in_array($manual_status, array('veto','paused'), true)) {
                if (!isset($job['manual_veto_seen'][$item_id])) {
                    $job['manual_veto_seen'][$item_id] = true;
                    $summary['manual_vetoed']++;
                    $summary['profile_stats'][$profile_key]['manual_vetoed']++;
                    $manual_error = new WP_Error('ebay_manual_veto', (string) ($manual_decision['reason'] ?? 'Manuelles Chef-Veto ist aktiv.'));
                    $this->ebay_summary_reason_add($summary, 'manual_veto', $manual_error, (string) $profile['rule']['id'], $profile['seller_type'], $profile_key);
                    $stored_veto = $this->ebay_store_review_candidate($item, $profile['rule'], $profile['seller_type'], $manual_error, $settings);
                    if (!is_wp_error($stored_veto)) {
                        global $wpdb;
                        $wpdb->update($this->ebay_items_table(), array('status'=>'blocked_manual','rejection_reason'=>'[ebay_manual_veto] ' . sanitize_text_field((string) ($manual_decision['reason'] ?? 'Manuelles Chef-Veto ist aktiv.')),'updated_at'=>time()), array('id'=>absint($stored_veto['id'])), array('%s','%s','%d'), array('%d'));
                    }
                }
                $job['routed_items'][$item_id] = 'manual_veto';
                unset($job['soft_pending'][$item_id]);
                return;
            }
            if ($manual_status === 'approved') {
                $term = $this->ebay_target_from_candidate_decision($manual_decision, $settings);
                if (is_wp_error($term)) {
                    $summary['technical_blocked']++;
                    $summary['profile_stats'][$profile_key]['technical_blocked']++;
                    $this->ebay_summary_reason_add($summary, 'technical', $term, (string) $profile['rule']['id'], $profile['seller_type'], $profile_key);
                    return;
                }
                $classification = $this->ebay_manual_classification($term, $item, (string) ($manual_decision['reason'] ?? 'Manuell freigegeben.'));
            }
        }

        if (!is_array($classification)) {
            $classification = $profile['seller_type'] === 'BUSINESS'
                ? $this->ebay_business_classify_portal_item_strict($item, $profile['rule'])
                : $this->ebay_classify_portal_item($item, $profile['rule']);
        }
        if (is_wp_error($classification)) {
            if ($this->ebay_is_soft_classification_error($classification)) {
                if (!isset($job['soft_pending'][$item_id])) {
                    $stored_review = $this->ebay_store_review_candidate($item, $profile['rule'], $profile['seller_type'], $classification, $settings);
                    if (is_wp_error($stored_review)) {
                        $summary['technical_blocked']++;
                        $summary['profile_stats'][$profile_key]['technical_blocked']++;
                        $this->ebay_summary_reason_add($summary, 'technical', $stored_review, (string) $profile['rule']['id'], $profile['seller_type'], $profile_key);
                        return;
                    }
                    $job['soft_pending'][$item_id] = array(
                        'code'=>$this->ebay_error_code($classification, 'ebay_review_required'),
                        'rule_id'=>(string) ($profile['rule']['id'] ?? ''),
                        'seller_type'=>$profile['seller_type'],
                        'profile_key'=>$profile_key,
                    );
                } else {
                    $summary['duplicates_skipped']++;
                    $summary['profile_stats'][$profile_key]['duplicates_skipped']++;
                }
                return;
            }
            $summary['technical_blocked']++;
            $summary['profile_stats'][$profile_key]['technical_blocked']++;
            $this->ebay_summary_reason_add($summary, 'technical', $classification, (string) $profile['rule']['id'], $profile['seller_type'], $profile_key);
            return;
        }

        $item['portal_classification'] = $classification;
        unset($job['soft_pending'][$item_id]);
        $target_term_id = 0;
        if ($profile['seller_type'] === 'INDIVIDUAL') {
            if (!empty($classification['manual_override'])) {
                $manual_decision = $this->ebay_candidate_manual_decision($item_id);
                $term = $this->ebay_target_from_candidate_decision($manual_decision, $settings);
                $target_term_id = is_wp_error($term) ? 0 : absint($term->term_id ?? 0);
            } else {
                $target_rule = $profile['rule'];
                $target_rule['target_term_slug'] = sanitize_title((string) ($classification['private_bucket_slug'] ?? ''));
                $target_term_id = $this->ebay_rule_target_term($target_rule, $settings);
                if (is_wp_error($target_term_id)) {
                    $summary['technical_blocked']++;
                    $summary['profile_stats'][$profile_key]['technical_blocked']++;
                    $this->ebay_summary_reason_add($summary, 'technical', $target_term_id, (string) $profile['rule']['id'], $profile['seller_type'], $profile_key);
                    $summary['errors'][] = array('rule'=>(string) $profile['rule']['id'],'seller_type'=>$profile['seller_type'],'item_id'=>$item_id,'error'=>$target_term_id->get_error_message(),'code'=>$target_term_id->get_error_code());
                    return;
                }
            }
            if ($target_term_id <= 0) {
                $target_error = new WP_Error('ebay_private_target_missing', 'HivePress-Zielkategorie fehlt.');
                $summary['technical_blocked']++;
                $summary['profile_stats'][$profile_key]['technical_blocked']++;
                $this->ebay_summary_reason_add($summary, 'technical', $target_error, (string) $profile['rule']['id'], $profile['seller_type'], $profile_key);
                return;
            }
        }

        $route = $profile['seller_type'] === 'INDIVIDUAL' ? 'private_hivepress' : 'business_affiliate';
        $stored = $this->ebay_upsert_item($item, $profile['rule'], $route, $target_term_id, $settings);
        if (is_wp_error($stored)) {
            $summary['technical_blocked']++;
            $summary['profile_stats'][$profile_key]['technical_blocked']++;
            $this->ebay_summary_reason_add($summary, 'technical', $stored, (string) $profile['rule']['id'], $profile['seller_type'], $profile_key);
            $summary['errors'][] = array('rule'=>(string) $profile['rule']['id'],'seller_type'=>$profile['seller_type'],'item_id'=>$item_id,'error'=>$stored->get_error_message(),'code'=>$stored->get_error_code());
            return;
        }
        $result = $profile['seller_type'] === 'INDIVIDUAL'
            ? $this->ebay_materialize_private_listing($stored, $item, $target_term_id, $settings)
            : $this->ebay_route_business($stored, $item, $profile['rule'], (string) $job['run_uuid'], $classification);
        if (is_wp_error($result)) {
            $this->ebay_mark_route_error($stored, $result);
            $summary['technical_blocked']++;
            $summary['profile_stats'][$profile_key]['technical_blocked']++;
            $this->ebay_summary_reason_add($summary, 'technical', $result, (string) $profile['rule']['id'], $profile['seller_type'], $profile_key);
            $summary['errors'][] = array('rule'=>(string) $profile['rule']['id'],'seller_type'=>$profile['seller_type'],'item_id'=>$item_id,'error'=>$result->get_error_message(),'code'=>$result->get_error_code());
            $job['routed_items'][$item_id] = 'route_error';
            return;
        }
        if (is_array($result) && !empty($result['last_good_preserved'])) {
            // Existing public BUSINESS output remains valid; Discovery records
            // the new candidate as review instead of clobbering that contract.
            $job['soft_pending'][$item_id] = array(
                'code'=>sanitize_key((string)($result['review_code'] ?? 'ebay_business_materialization_not_active')),
                'rule_id'=>(string)($profile['rule']['id'] ?? ''),'seller_type'=>$profile['seller_type'],'profile_key'=>$profile_key,
            );
            $job['routed_items'][$item_id] = 'business_last_good_preserved';
            return;
        }
        $job['routed_items'][$item_id] = $route;
        $summary['accepted']++;
        $summary['profile_stats'][$profile_key]['accepted']++;
        if ($profile['seller_type'] === 'INDIVIDUAL') { $summary['private_listings']++; }
        else { $summary['business_creatives']++; }
    }

    /** V5.20: echter Fortschritt statt bloßem Worker-Heartbeat. */
    private function ebay_sync_touch_progress(&$job, $phase = '') {
        $job['progress_seq'] = absint($job['progress_seq'] ?? 0) + 1;
        $job['last_progress_at'] = time();
        if ($phase !== '') { $job['worker_phase'] = sanitize_key((string) $phase); }
    }

    private function ebay_sync_completion_state($job) {
        $stats = (array) (($job['summary']['profile_stats'] ?? array()));
        $partial_reasons = array();
        foreach ($stats as $stat) {
            $reason = sanitize_key((string) ($stat['stopped_reason'] ?? ''));
            $complete = !empty($stat['complete']);
            if (!$complete) {
                if ($reason === '') { $reason = 'profile_incomplete'; }
                $partial_reasons[$reason] = true;
            }
        }
        if ($partial_reasons) {
            $reasons = array_keys($partial_reasons);
            return array('status'=>'partial','reason'=>count($reasons) === 1 ? $reasons[0] : 'profile_incomplete');
        }
        return array('status'=>'completed','reason'=>'');
    }

    private function ebay_sync_finalize(&$job, $settings, $status = 'completed', $stopped_reason = '') {
        $this->ebay_sync_rebuild_review_summary($job);
        $summary =& $job['summary'];
        $summary['received_unique'] = count((array) ($job['unique_received'] ?? array()));
        $summary['technically_valid'] = count((array) ($job['technical_valid'] ?? array()));
        $summary['profiles_complete'] = 0;
        $summary['profiles_partial'] = 0;
        foreach ((array) ($summary['profile_stats'] ?? array()) as $profile_stat) {
            if (!empty($profile_stat['complete'])) { $summary['profiles_complete']++; }
            else { $summary['profiles_partial']++; }
        }
        $summary['blocked'] = absint($summary['hard_blocked'] ?? 0) + absint($summary['technical_blocked'] ?? 0) + absint($summary['manual_vetoed'] ?? 0);
        $summary['status'] = sanitize_key((string) $status);
        if ($stopped_reason !== '') { $summary['budget']['stopped_reason'] = sanitize_key((string) $stopped_reason); }
        // V5.17: Erst gezielt getItem nachprüfen, danach stale/ended fail-closed schalten.
        // Suchranking oder Pagination allein dürfen ein noch verfügbares Angebot nie beenden.
        // V5.21: Discovery und Bestandsabgleich sind echte getrennte Jobs.
        // Ein manueller Vollabruf darf nicht nach seinem Abschluss unbemerkt noch
        // bis zu 150 einzelne getItem-Requests anhängen und dadurch den Eindruck
        // eines endlosen eBay-Laufs erzeugen. Der Bestandsabgleich besitzt seinen
        // eigenen stündlichen Refresh-Cron und kann zusätzlich manuell gestartet werden.
        $summary['inventory_refresh'] = array('status'=>'separate_schedule');
        $summary['expired'] = array('status'=>'handled_by_separate_inventory_refresh');
        $summary['finished_at'] = time();
        $summary['duration_seconds'] = max(0, absint($summary['finished_at']) - absint($summary['started_at'] ?? $summary['finished_at']));
        $settings['last_sync'] = $summary;
        update_option(self::OPTION_NETWORK_EBAY, $settings, false);
        $job['status'] = in_array($status, array('failed','partial'), true) ? $status : 'completed';
        $job['worker_phase'] = 'finished';
        $job['finished_at'] = time();
        $this->ebay_sync_job_save($job);
        if (function_exists('wp_clear_scheduled_hook')) { wp_clear_scheduled_hook(self::EBAY_WORKER_HOOK); }
        return $summary;
    }

    private function ebay_sync_fail(&$job, $settings, $error) {
        $error = is_wp_error($error) ? $error : new WP_Error('ebay_worker_failed', sanitize_text_field((string) $error));
        $job['summary']['errors'][] = array('error'=>$error->get_error_message(),'code'=>$error->get_error_code());
        $job['summary']['technical_blocked'] = absint($job['summary']['technical_blocked'] ?? 0) + 1;
        $this->ebay_summary_reason_add($job['summary'], 'technical', $error, 'worker', 'SYSTEM', '');
        return $this->ebay_sync_finalize($job, $settings, 'failed', 'worker_error');
    }

    /**
     * V5.6.0 – Ein Worker bearbeitet höchstens eine Browse-Seite ODER ein
     * kleines Itempaket. Der Zustand wird vor/zwischen den Netzwerk- und
     * Materialisierungsschritten gespeichert. Wiederholungen sind über itemId
     * und die bestehenden Upserts idempotent.
     */
    public function run_ebay_sync_worker($manual_or_external = false) {
        $lock_key = 'ppar_ebay_sync_worker_lock_v1';
        if (function_exists('get_transient') && get_transient($lock_key)) { return false; }
        if (function_exists('set_transient')) { set_transient($lock_key, 1, 45); }
        $reschedule = false;
        $job = array();
        try {
            $job = $this->ebay_sync_job_load();
            if (!$this->ebay_sync_job_is_open($job)) { return false; }
            $settings = $this->ebay_settings();
            $errors = $this->ebay_configuration_errors($settings);
            if ($errors) { return $this->ebay_sync_fail($job, $settings, new WP_Error('ebay_configuration_invalid', implode(' ', $errors))); }
            $author_id = $this->ebay_persist_listing_author_id($settings);
            if (is_wp_error($author_id)) { return $this->ebay_sync_fail($job, $settings, $author_id); }
            $this->ebay_sync_job_stamp_runtime($job, $author_id);
            $job['status'] = 'running';
            $job['last_worker_at'] = time();
            if (empty($job['last_progress_at'])) { $job['last_progress_at'] = absint($job['updated_at'] ?? time()); }
            $this->ebay_sync_job_save($job);
            if ($this->ebay_sync_segment_expired($job)) {
                return $this->ebay_sync_finalize($job, $settings, 'partial', 'segment_time_budget');
            }

            $summary =& $job['summary'];
            $max_requests = max(1, absint($settings['max_requests_per_run'] ?? 40));
            $max_pages = max(1, absint($settings['max_pages_per_profile'] ?? 4));
            $worker_budget = max(10, min(30, absint($settings['run_time_budget_seconds'] ?? 20)));
            // Kleine Sicherheitsreserve, damit WordPress die Antwort noch sauber senden kann.
            $deadline = microtime(true) + max(8, $worker_budget - 2);
            $operations = 0;

            // V5.20: Das Zeitbudget wird vollständig genutzt. V5.18/5.19 kehrten
            // nach jedem Itempaket bzw. jedem Browse-Request zurück und erzeugten
            // dadurch hunderte voneinander abhängige HTTP-Ticks.
            while (microtime(true) < $deadline && $operations < 500) {
                $operations++;
                if ($this->ebay_sync_segment_expired($job)) {
                    return $this->ebay_sync_finalize($job, $settings, 'partial', 'segment_time_budget');
                }

                if (!empty($job['current_page']) && is_array($job['current_page'])) {
                    $page =& $job['current_page'];
                    $profile_key = (string) ($page['profile_key'] ?? '');
                    $items = array_values((array) ($page['items'] ?? array()));
                    $index = absint($page['index'] ?? 0);
                    $since_save = 0;
                    $job['worker_phase'] = 'items';

                    while ($index < count($items) && microtime(true) < $deadline) {
                        $this->ebay_sync_process_item($job, $items[$index], $profile_key, $settings);
                        $index++;
                        $since_save++;
                        $job['current_page']['index'] = $index;
                        $this->ebay_sync_touch_progress($job, 'items');
                        if ($since_save >= 5) {
                            $this->ebay_sync_rebuild_review_summary($job);
                            $this->ebay_sync_job_save($job);
                            $since_save = 0;
                        }
                    }
                    $this->ebay_sync_rebuild_review_summary($job);
                    $this->ebay_sync_job_save($job);

                    if ($index < count($items)) {
                        $reschedule = true;
                        return true;
                    }

                    $page_next = trim((string) ($page['next'] ?? ''));
                    if (isset($job['profiles'][$profile_key])) {
                        if ($page_next === '' || absint($job['profiles'][$profile_key]['pages'] ?? 0) >= $max_pages) {
                            $job['profiles'][$profile_key]['active'] = false;
                            $summary['profile_stats'][$profile_key]['complete'] = ($page_next === '');
                            if ($page_next !== '' && absint($job['profiles'][$profile_key]['pages'] ?? 0) >= $max_pages) {
                                $summary['profile_stats'][$profile_key]['stopped_reason'] = 'profile_page_limit';
                            }
                        } else {
                            $job['profiles'][$profile_key]['next'] = $page_next;
                            $job['profiles'][$profile_key]['active'] = true;
                        }
                    }
                    $job['current_page'] = array();
                    $this->ebay_sync_advance_cursor($job, $profile_key);
                    $this->ebay_sync_touch_progress($job, 'page_done');
                    $this->ebay_sync_job_save($job);
                    unset($page);
                    continue;
                }

                // Erst pruefen, ob fachlich ueberhaupt noch ein Profil offen ist.
                // Sonst wuerde ein exakt mit dem letzten erlaubten Request fertig
                // gewordenes Profil faelschlich als PARTIAL/request_budget enden.
                $profile_key = $this->ebay_sync_active_profile_key($job);
                if ($profile_key === '') {
                    $completion = $this->ebay_sync_completion_state($job);
                    return $this->ebay_sync_finalize($job, $settings, $completion['status'], $completion['reason']);
                }
                if (absint($summary['requests'] ?? 0) >= $max_requests) {
                    foreach ((array) $job['profiles'] as $budget_profile_key => $budget_profile) {
                        if (!empty($budget_profile['active']) && empty($summary['profile_stats'][$budget_profile_key]['stopped_reason'])) {
                            $summary['profile_stats'][$budget_profile_key]['stopped_reason'] = 'request_budget';
                        }
                    }
                    return $this->ebay_sync_finalize($job, $settings, 'partial', 'request_budget');
                }
                $profile =& $job['profiles'][$profile_key];
                $token = $this->ebay_access_token($settings);
                if (is_wp_error($token)) { return $this->ebay_sync_fail($job, $settings, $token); }

                $summary['requests']++;
                $summary['profile_stats'][$profile_key]['requests']++;
                $job['worker_phase'] = 'fetch_inflight';
                $job['inflight_profile'] = $profile_key;
                $this->ebay_sync_job_save($job);

                $page_data = $this->ebay_search_page($profile['rule'], $profile['seller_type'], $settings, $token, (string) ($profile['next'] ?? ''));
                if (is_wp_error($page_data)) {
                    $summary['technical_blocked']++;
                    $summary['profile_stats'][$profile_key]['technical_blocked']++;
                    $this->ebay_summary_reason_add($summary, 'technical', $page_data, (string) $profile['rule']['id'], $profile['seller_type'], $profile_key);
                    $summary['errors'][] = array('rule'=>(string) $profile['rule']['id'],'seller_type'=>$profile['seller_type'],'error'=>$page_data->get_error_message(),'code'=>$page_data->get_error_code());
                    $summary['profile_stats'][$profile_key]['stopped_reason'] = 'request_error';
                    $profile['active'] = false;
                    unset($job['inflight_profile']);
                    $this->ebay_sync_advance_cursor($job, $profile_key);
                    $this->ebay_sync_touch_progress($job, 'request_error');
                    $this->ebay_sync_job_save($job);
                    unset($profile);
                    continue;
                }

                $items = array_values((array) ($page_data['items'] ?? array()));
                $summary['pages']++;
                $profile['pages'] = absint($profile['pages'] ?? 0) + 1;
                $summary['profile_stats'][$profile_key]['pages']++;
                $summary['received'] += count($items);
                $summary['profile_stats'][$profile_key]['received'] += count($items);
                foreach ($items as $raw) {
                    $id = substr(sanitize_text_field((string) (is_array($raw) ? ($raw['itemId'] ?? '') : '')), 0, 191);
                    if ($id !== '') { $job['unique_received'][$id] = true; }
                }
                $summary['received_unique'] = count($job['unique_received']);
                $job['current_page'] = array(
                    'profile_key'=>$profile_key,
                    'items'=>$items,
                    'index'=>0,
                    'next'=>trim((string) ($page_data['next'] ?? '')),
                    'loaded_at'=>time(),
                );
                unset($job['inflight_profile']);
                $this->ebay_sync_touch_progress($job, 'page_loaded');
                $this->ebay_sync_job_save($job);
                unset($profile);
                // Nicht zurückkehren: dieselbe Worker-Anfrage verarbeitet die eben
                // geladene Seite sofort weiter, solange Zeitbudget übrig ist.
                continue;
            }

            $reschedule = true;
            $this->ebay_sync_job_save($job);
            return true;
        } catch (Throwable $error) {
            $settings = $this->ebay_settings();
            if ($this->ebay_sync_job_is_open($job)) {
                return $this->ebay_sync_fail($job, $settings, new WP_Error('ebay_worker_runtime_error', $error->getMessage()));
            }
            return new WP_Error('ebay_worker_runtime_error', $error->getMessage());
        } finally {
            if (function_exists('delete_transient')) { delete_transient($lock_key); }
            if ($reschedule) {
                $fresh = $this->ebay_sync_job_load();
                if ($this->ebay_sync_job_is_open($fresh)) { $this->ebay_dispatch_worker($fresh); }
            }
        }
    }

    private function ebay_refresh_job_load() {
        $job = get_option(self::OPTION_EBAY_REFRESH_JOB, array());
        return is_array($job) ? $job : array();
    }

    private function ebay_refresh_job_save($job) {
        $job = is_array($job) ? $job : array();
        $job['updated_at'] = time();
        update_option(self::OPTION_EBAY_REFRESH_JOB, $job, false);
        return $job;
    }

    private function ebay_refresh_job_runtime_compatible($job) {
        if (!is_array($job)) { return false; }
        $build = (string) ($job['build'] ?? '');
        $schema = (string) ($job['schema'] ?? '');
        $engine = (string) ($job['engine'] ?? '');
        return $build !== ''
            && hash_equals((string) self::EBAY_RUNTIME_BUILD, $build)
            && $schema === '1.0'
            && $engine === 'targeted-getitem-refresh';
    }

    private function ebay_refresh_job_is_open($job) {
        return $this->ebay_refresh_job_runtime_compatible($job)
            && in_array(sanitize_key((string) ($job['status'] ?? '')), array('queued','running'), true);
    }

    private function ebay_refresh_schedule_worker_fallback($delay = 12) {
        if (!function_exists('wp_next_scheduled') || !function_exists('wp_schedule_single_event')) { return; }
        if (!wp_next_scheduled(self::EBAY_REFRESH_WORKER_HOOK)) {
            wp_schedule_single_event(time() + max(10, absint($delay)), self::EBAY_REFRESH_WORKER_HOOK);
        }
    }

    private function ebay_refresh_dispatch_worker($job = null) {
        $job = is_array($job) ? $job : $this->ebay_refresh_job_load();
        if (!$this->ebay_refresh_job_is_open($job)) { return false; }
        $this->ebay_refresh_schedule_worker_fallback(12);
        $token = (string) ($job['worker_token'] ?? '');
        if ($token === '' || !function_exists('wp_remote_post')) { return false; }
        $response = wp_remote_post(admin_url('admin-post.php'), array(
            'timeout'=>0.01,'blocking'=>false,'redirection'=>0,
            'sslverify'=>apply_filters('https_local_ssl_verify', false),
            'body'=>array('action'=>'ppar_ebay_refresh_worker_tick','token'=>$token),
        ));
        return !is_wp_error($response);
    }

    /** V5.21 – auch der getrennte getItem-Bestandsjob darf nie endlos offen bleiben. */
    private function ebay_refresh_segment_limit_seconds($job = array()) {
        // 45 Minuten harte Zyklusgrenze. Worker selbst bleiben weiterhin kurz
        // getaktet; ein Refresh kann dadurch einen grossen Bestand abarbeiten,
        // ohne einen einzelnen PHP-Request entsprechend lange offen zu halten.
        return 2700;
    }

    private function ebay_refresh_segment_expired($job) {
        if (!$this->ebay_refresh_job_is_open($job)) { return false; }
        $started = absint($job['segment_started_at'] ?? ($job['created_at'] ?? 0));
        return $started > 0 && (time() - $started) >= $this->ebay_refresh_segment_limit_seconds($job);
    }

    private function ebay_start_inventory_refresh_job($manual = false) {
        $settings = $this->ebay_settings();
        if (empty($settings['enabled']) && !$manual) { return array('status'=>'disabled'); }
        if (empty($settings['inventory_refresh_enabled']) && !$manual) { return array('status'=>'disabled'); }
        $errors = $this->ebay_configuration_errors($settings);
        if ($errors) { return new WP_Error('ebay_refresh_configuration_invalid', implode(' ', $errors)); }

        $sync_job = $this->ebay_sync_job_load();
        if ($this->ebay_sync_job_is_open($sync_job)) {
            return $manual
                ? new WP_Error('ebay_refresh_discovery_running', 'Der eBay-Discovery-Abruf läuft bereits. Der Bestandsabgleich startet erst danach.')
                : array('status'=>'deferred_discovery_running');
        }
        $existing = $this->ebay_refresh_job_load();
        if ($this->ebay_refresh_job_is_open($existing)) {
            $this->ebay_refresh_dispatch_worker($existing);
            return array('status'=>'already_running','run_uuid'=>(string) ($existing['run_uuid'] ?? ''),'summary'=>(array) ($existing['summary'] ?? array()));
        }
        $run_uuid = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : substr(hash('sha256', microtime(true) . '|refresh|' . mt_rand()), 0, 36);
        $worker_token = function_exists('wp_generate_password') ? wp_generate_password(48, false, false) : hash('sha256', $run_uuid . '|refresh|' . microtime(true) . '|' . mt_rand());
        $now = time();
        // Every explicit inventory reconciliation is a complete BUSINESS repair
        // pass, not only a contract-version migration. This recovers campaigns
        // that earlier V6 runs deactivated while the source row still looked
        // current.
        $maintenance_state = get_option(self::OPTION_EBAY_MAINTENANCE_STATE, array());
        $maintenance_state = is_array($maintenance_state) ? $maintenance_state : array();
        $maintenance_state['cursor'] = 0;
        $maintenance_state['completed_at'] = 0;
        $maintenance_state['cycle_stats'] = array('scanned'=>0,'ready_private'=>0,'ready_business'=>0,'review'=>0,'blocked'=>0,'errors'=>0);
        update_option(self::OPTION_EBAY_MAINTENANCE_STATE, $maintenance_state, false);
        $job = array(
            'schema'=>'1.0','engine'=>'targeted-getitem-refresh','build'=>self::EBAY_RUNTIME_BUILD,
            'status'=>'queued','run_uuid'=>$run_uuid,'worker_token'=>$worker_token,'manual'=>!empty($manual),
            'created_at'=>$now,'segment_started_at'=>$now,'updated_at'=>$now,'finished_at'=>0,'last_worker_at'=>0,'last_id'=>0,
            // Alles, was innerhalb der nächsten 30 Minuten aus der 6h-Frische fallen würde, wird jetzt direkt geprüft.
            'due_before'=>$now + 30 * MINUTE_IN_SECONDS,
            'summary'=>array(
                'status'=>'queued','phase'=>'local_reconciliation','reconcile_contracts'=>1,'force_business_reconcile'=>1,'started_at'=>$now,'finished_at'=>0,'checked'=>0,'requests'=>0,'available'=>0,
                'updated'=>0,'revived'=>0,'ended'=>0,'excluded'=>0,'reviewed'=>0,'transient_errors'=>0,'technical_errors'=>0,'errors'=>array(),
                'maintenance'=>array('scanned'=>0,'ready_private'=>0,'ready_business'=>0,'review'=>0,'blocked'=>0,'errors'=>0,'completed'=>0),
                'asset_verification'=>array('processed'=>0,'verified'=>0,'blocked'=>0,'remaining'=>0,'completed'=>0),
                'max_checks'=>max(1200, min(2000, absint($settings['inventory_refresh_max_per_run'] ?? 1200))),
                'segment_limit_seconds'=>2700,'stopped_reason'=>'',
            ),
        );
        $this->ebay_refresh_job_save($job);
        $this->ebay_refresh_dispatch_worker($job);
        return array('status'=>'queued','run_uuid'=>$run_uuid,'summary'=>$job['summary']);
    }

    public function run_ebay_inventory_refresh($manual = false) {
        return $this->ebay_start_inventory_refresh_job($manual);
    }

    private function ebay_refresh_due_rows($job, $limit = 10) {
        global $wpdb;
        $table = $this->ebay_items_table();
        $posts_table = isset($wpdb->posts) ? $wpdb->posts : $wpdb->prefix . 'posts';
        $last_id = absint($job['last_id'] ?? 0);
        $due_before = absint($job['due_before'] ?? time());
        $now = time();
        $retry_before = $now - 15 * MINUTE_IN_SECONDS;
        $limit = max(1, min(20, absint($limit)));
        return (array) $wpdb->get_results($wpdb->prepare(
            "SELECT e.* FROM {$table} e LEFT JOIN {$posts_table} p ON p.ID=e.listing_post_id WHERE e.id>%d AND e.seller_account_type IN ('INDIVIDUAL','BUSINESS') AND COALESCE(e.source_state,'available')<>'ended' AND COALESCE(e.policy_state,'allowed')<>'blocked' AND COALESCE(e.status,'active') NOT IN ('blocked_manual','blocked_content') AND ((e.seller_account_type='INDIVIDUAL' AND p.post_status='publish') OR (e.seller_account_type='BUSINESS' AND COALESCE(e.output_state,'') IN ('creative_ready','stale_wait_refresh'))) AND ((e.item_end_at>0 AND e.item_end_at<=%d) OR ((e.fresh_until=0 OR e.fresh_until<=%d) AND (COALESCE(e.source_checked_at,0)=0 OR e.source_checked_at<=%d))) ORDER BY e.id ASC LIMIT %d",
            $last_id, $now, $due_before, $retry_before, $limit
        ), ARRAY_A);
    }

    private function ebay_refresh_has_more($job) {
        global $wpdb;
        $table = $this->ebay_items_table();
        $posts_table = isset($wpdb->posts) ? $wpdb->posts : $wpdb->prefix . 'posts';
        $last_id = absint($job['last_id'] ?? 0);
        $due_before = absint($job['due_before'] ?? time());
        $now = time();
        $retry_before = $now - 15 * MINUTE_IN_SECONDS;
        $id = $wpdb->get_var($wpdb->prepare(
            "SELECT e.id FROM {$table} e LEFT JOIN {$posts_table} p ON p.ID=e.listing_post_id WHERE e.id>%d AND e.seller_account_type IN ('INDIVIDUAL','BUSINESS') AND COALESCE(e.source_state,'available')<>'ended' AND COALESCE(e.policy_state,'allowed')<>'blocked' AND COALESCE(e.status,'active') NOT IN ('blocked_manual','blocked_content') AND ((e.seller_account_type='INDIVIDUAL' AND p.post_status='publish') OR (e.seller_account_type='BUSINESS' AND COALESCE(e.output_state,'') IN ('creative_ready','stale_wait_refresh'))) AND ((e.item_end_at>0 AND e.item_end_at<=%d) OR ((e.fresh_until=0 OR e.fresh_until<=%d) AND (COALESCE(e.source_checked_at,0)=0 OR e.source_checked_at<=%d))) ORDER BY e.id ASC LIMIT 1",
            $last_id, $now, $due_before, $retry_before
        ));
        return absint($id) > 0;
    }

    private function ebay_refresh_reuse_classification($row, &$item) {
        $payload = json_decode((string) ($row['source_payload'] ?? ''), true);
        $classification = is_array($payload) && is_array($payload['portal_classification'] ?? null) ? $payload['portal_classification'] : array();
        if ($classification) { $item['portal_classification'] = $classification; }
        return $classification;
    }

    private function ebay_refresh_mark_ended($row, $reason) {
        $reason = sanitize_text_field((string) $reason);
        if ($reason === '') { $reason = 'eBay-Angebot ist nicht mehr verfügbar.'; }
        return $this->ebay_purge_item_content($row, 'purged_ended', $reason);
    }

    private function ebay_refresh_process_row(&$job, $row, $settings, $token) {
        $summary =& $job['summary'];
        $row = is_array($row) ? $row : array();
        $summary['checked']++;
        $job['last_id'] = max(absint($job['last_id'] ?? 0), absint($row['id'] ?? 0));
        $now = time();
        if (absint($row['item_end_at'] ?? 0) > 0 && absint($row['item_end_at']) <= $now) {
            $this->ebay_refresh_mark_ended($row, 'eBay-Angebotsende erreicht; öffentliche Ausgabe deaktiviert.');
            $summary['ended']++;
            return;
        }
        $summary['requests']++;
        $fresh = $this->ebay_fetch_item_for_refresh($row, $settings, $token);
        if (is_wp_error($fresh)) {
            $code = sanitize_key((string) $fresh->get_error_code());
            if ($code === 'ebay_refresh_transient_http' || $code === 'ebay_refresh_transport') { $summary['transient_errors']++; }
            else { $summary['technical_errors']++; }
            // A failed source attempt must not deactivate or extend freshness, but
            // it is timestamped so the next scheduled segment can move on to the
            // remaining inventory instead of hammering/starving on the same rows.
            global $wpdb;
            $attempt = array('source_checked_at'=>$now,'updated_at'=>$now);
            $wpdb->update($this->ebay_items_table(), $attempt, array('id'=>absint($row['id'] ?? 0)), $this->ebay_db_formats($attempt), array('%d'));
            if (count($summary['errors']) < 30) { $summary['errors'][] = array('item_id'=>(string)($row['item_id'] ?? ''),'code'=>$code,'error'=>$fresh->get_error_message()); }
            return;
        }
        if ((string) ($fresh['state'] ?? '') === 'ended') {
            $reason_code = sanitize_key((string) ($fresh['reason'] ?? 'unavailable'));
            $reason = $reason_code === 'out_of_stock' ? 'eBay meldet OUT_OF_STOCK; öffentliche Ausgabe deaktiviert.' : ($reason_code === 'item_end_date' ? 'eBay meldet ein abgelaufenes Angebotsende; öffentliche Ausgabe deaktiviert.' : 'eBay-Angebot über getItem nicht mehr verfügbar; öffentliche Ausgabe deaktiviert.');
            $this->ebay_refresh_mark_ended($row, $reason);
            $summary['ended']++;
            return;
        }
        $raw = is_array($fresh['raw'] ?? null) ? $fresh['raw'] : array();
        $seller_type = strtoupper(sanitize_key((string) ($row['seller_account_type'] ?? '')));
        $item = $this->ebay_accept_item($raw, $seller_type, $settings);
        if (is_wp_error($item)) {
            $code = sanitize_key((string) $item->get_error_code());
            if ($code === 'ebay_toy_item_blocked') {
                $this->ebay_quarantine_filtered_row($row, $item->get_error_message());
                $summary['excluded'] = absint($summary['excluded'] ?? 0) + 1;
                return;
            }
            $summary['technical_errors']++;
            if (count($summary['errors']) < 30) { $summary['errors'][] = array('item_id'=>(string)($row['item_id'] ?? ''),'code'=>$item->get_error_code(),'error'=>$item->get_error_message()); }
            return;
        }
        $rule = $this->ebay_rule_by_id((string) ($row['rule_id'] ?? ''), $settings);
        $target_term_id = 0;
        if ($seller_type === 'BUSINESS') {
            // Every successful real getItem refresh reclassifies BUSINESS from the
            // current source facts. Historical target assignments are never trusted.
            $classification = $this->ebay_business_classify_portal_item_strict($item, $rule);
            if (is_wp_error($classification)) {
                $this->ebay_business_hold_for_review($row, $item, $rule, $classification, $settings);
                $summary['excluded'] = absint($summary['excluded'] ?? 0) + 1;
                $summary['reviewed'] = absint($summary['reviewed'] ?? 0) + 1;
                return;
            }
            $item['portal_classification'] = $classification;
        } else {
            // PRIVATE is reclassified from the same fresh getItem facts. Manual
            // Chef decisions remain above automation and are never overwritten.
            $manual_decision = $this->ebay_candidate_manual_decision((string)($item['item_id'] ?? $row['item_id'] ?? ''));
            $manual_status = sanitize_key((string)($manual_decision['status'] ?? 'automatic'));
            if (in_array($manual_status, array('veto','paused'), true)) {
                $manual_error = new WP_Error('ebay_manual_veto', (string)($manual_decision['reason'] ?? 'Manuelles Chef-Veto ist aktiv.'));
                $stored_block = $this->ebay_store_review_candidate($item, $rule, 'INDIVIDUAL', $manual_error, $settings);
                if (is_wp_error($stored_block)) {
                    $summary['technical_errors']++;
                    return;
                }
                global $wpdb;
                $blocked_update = array('status'=>'blocked_manual','route_state'=>'blocked','output_state'=>'none','rejection_reason'=>'[ebay_manual_veto] '.sanitize_text_field((string)($manual_decision['reason'] ?? 'Manuelles Chef-Veto ist aktiv.')),'updated_at'=>time());
                $wpdb->update($this->ebay_items_table(), $blocked_update, array('id'=>absint($stored_block['id'] ?? 0)), $this->ebay_db_formats($blocked_update), array('%d'));
                $this->ebay_private_listing_route_meta($stored_block, 'review', (string)($manual_decision['reason'] ?? 'Manuelles Chef-Veto ist aktiv.'));
                $summary['excluded'] = absint($summary['excluded'] ?? 0) + 1;
                return;
            }
            if ($manual_status === 'approved') {
                $term = $this->ebay_target_from_candidate_decision($manual_decision, $settings);
                if (is_wp_error($term)) {
                    $summary['technical_errors']++;
                    if (count($summary['errors']) < 30) { $summary['errors'][] = array('item_id'=>(string)($row['item_id'] ?? ''),'code'=>$term->get_error_code(),'error'=>$term->get_error_message()); }
                    return;
                }
                $classification = $this->ebay_manual_classification($term, $item, (string)($manual_decision['reason'] ?? 'Manuell freigegeben.'));
                $target_term_id = absint($term->term_id ?? 0);
            } else {
                $classification = $this->ebay_classify_portal_item($item, $rule);
            }
            if (is_wp_error($classification)) {
                $stored_review = $this->ebay_store_review_candidate($item, $rule, 'INDIVIDUAL', $classification, $settings);
                if (is_wp_error($stored_review)) {
                    $summary['technical_errors']++;
                    if (count($summary['errors']) < 30) { $summary['errors'][] = array('item_id'=>(string)($row['item_id'] ?? ''),'code'=>$stored_review->get_error_code(),'error'=>$stored_review->get_error_message()); }
                    return;
                }
                $summary['excluded'] = absint($summary['excluded'] ?? 0) + 1;
                $summary['reviewed'] = absint($summary['reviewed'] ?? 0) + 1;
                return;
            }
            $item['portal_classification'] = $classification;
            if ($target_term_id <= 0) {
                $target_rule = $rule;
                $target_rule['target_term_slug'] = sanitize_title((string)($classification['private_bucket_slug'] ?? ''));
                $resolved = $this->ebay_rule_target_term($target_rule, $settings);
                if (is_wp_error($resolved) || absint($resolved) <= 0) {
                    $summary['technical_errors']++;
                    $error = is_wp_error($resolved) ? $resolved : new WP_Error('ebay_private_target_missing','HivePress-Zielkategorie fehlt.');
                    if (count($summary['errors']) < 30) { $summary['errors'][] = array('item_id'=>(string)($row['item_id'] ?? ''),'code'=>$error->get_error_code(),'error'=>$error->get_error_message()); }
                    return;
                }
                $target_term_id = absint($resolved);
            }
        }
        $stored = $this->ebay_upsert_item($item, $rule, (string) ($row['route_mode'] ?? ''), $target_term_id, $settings);
        if (is_wp_error($stored)) {
            $summary['technical_errors']++;
            if (count($summary['errors']) < 30) { $summary['errors'][] = array('item_id'=>(string)($row['item_id'] ?? ''),'code'=>$stored->get_error_code(),'error'=>$stored->get_error_message()); }
            return;
        }
        $result = $seller_type === 'INDIVIDUAL'
            ? $this->ebay_materialize_private_listing($stored, $item, $target_term_id, $settings)
            : $this->ebay_route_business($stored, $item, $rule, (string) ($job['run_uuid'] ?? ''), (array) ($item['portal_classification'] ?? array()));
        if (is_wp_error($result)) {
            $summary['technical_errors']++;
            if (count($summary['errors']) < 30) { $summary['errors'][] = array('item_id'=>(string)($row['item_id'] ?? ''),'code'=>$result->get_error_code(),'error'=>$result->get_error_message()); }
            return;
        }
        if (is_array($result) && !empty($result['last_good_preserved'])) {
            $summary['reviewed'] = absint($summary['reviewed'] ?? 0) + 1;
            return;
        }
        $summary['available']++;
        $summary['updated']++;
        if (sanitize_key((string) ($row['output_state'] ?? '')) === 'inactive' || sanitize_key((string) ($row['status'] ?? '')) === 'purged_stale') { $summary['revived']++; }
    }

    private function ebay_refresh_finalize(&$job, $settings, $status = 'completed') {
        $summary =& $job['summary'];
        $summary['status'] = sanitize_key((string) $status);
        // V5.24: Ein verpasster/verspaeteter Refresh darf niemals selbst den
        // WordPress-Status massenhaft auf Draft umschalten. Ueberfaellige Daten
        // bleiben im Frontend weiterhin fail-closed unsichtbar; nur ein explizites
        // eBay-Endsignal (404/410, Enddatum, OUT_OF_STOCK) tombstoned das Listing.
        $summary['expired'] = array(
            'status'=>'visibility_only',
            'reason'=>'stale_items_are_hidden_but_not_tombstoned',
            'checked'=>0,
            'purged'=>0,
        );
        $summary['finished_at'] = time();
        $summary['duration_seconds'] = max(0, absint($summary['finished_at']) - absint($summary['started_at'] ?? $summary['finished_at']));
        $settings['last_refresh'] = $summary;
        update_option(self::OPTION_NETWORK_EBAY, $settings, false);
        $job['status'] = sanitize_key((string) $status);
        $job['finished_at'] = time();
        $this->ebay_refresh_job_save($job);
        if (function_exists('wp_clear_scheduled_hook')) { wp_clear_scheduled_hook(self::EBAY_REFRESH_WORKER_HOOK); }
        return $summary;
    }

    /** Fortsetzbarer gezielter Bestandsabgleich. Maximal fünf getItem-Fälle pro Worker-Tick, weiterhin durch das harte Laufmaximum begrenzt. */
    public function run_ebay_inventory_refresh_worker($manual_or_external = false) {
        $lock_key = 'ppar_ebay_refresh_worker_lock_v1';
        if (function_exists('get_transient') && get_transient($lock_key)) { return false; }
        if (function_exists('set_transient')) { set_transient($lock_key, 1, 45); }
        $reschedule = false;
        $job = array();
        try {
            $job = $this->ebay_refresh_job_load();
            if (!$this->ebay_refresh_job_is_open($job)) { return false; }
            $settings = $this->ebay_settings();
            $errors = $this->ebay_configuration_errors($settings);
            if ($errors) { return $this->ebay_refresh_finalize($job, $settings, 'failed'); }
            $job['status'] = 'running';
            $job['last_worker_at'] = time();
            $job['summary']['status'] = 'running';
            if (empty($job['last_progress_at'])) { $job['last_progress_at'] = absint($job['updated_at'] ?? time()); }
            $this->ebay_refresh_job_save($job);
            if ($this->ebay_refresh_segment_expired($job)) {
                $job['summary']['stopped_reason'] = 'segment_time_budget';
                return $this->ebay_refresh_finalize($job, $settings, 'partial');
            }

            // Ein Bestandsabgleich ist ein vollstaendiger, deterministischer
            // Reconcile-Orchestrator: 1) lokale Policy/Klassifikation,
            // 2) BUSINESS-Bildpruefung/Replanung, 3) nur faellige eBay-getItem-
            // Quellen. Diagnose-Seiten bleiben dabei strikt read-only.
            $phase = sanitize_key((string)($job['summary']['phase'] ?? 'local_reconciliation'));
            if (!empty($job['summary']['reconcile_contracts']) && $phase === 'local_reconciliation') {
                $maintenance = $this->run_ebay_maintenance_v2(500, !empty($job['summary']['force_business_reconcile']));
                if (!isset($job['summary']['maintenance']) || !is_array($job['summary']['maintenance'])) {
                    $job['summary']['maintenance'] = array('scanned'=>0,'ready_private'=>0,'ready_business'=>0,'review'=>0,'blocked'=>0,'errors'=>0,'completed'=>0);
                }
                foreach (array('scanned','ready_private','ready_business','review','blocked','errors') as $key) {
                    $job['summary']['maintenance'][$key] = absint($job['summary']['maintenance'][$key] ?? 0) + absint($maintenance[$key] ?? 0);
                }
                $maintenance_state = get_option(self::OPTION_EBAY_MAINTENANCE_STATE, array());
                if (!$this->ebay_maintenance_state_is_current($maintenance_state)) {
                    $job['progress_seq'] = absint($job['progress_seq'] ?? 0) + 1;
                    $job['last_progress_at'] = time();
                    $this->ebay_refresh_job_save($job);
                    $reschedule = true;
                    return true;
                }
                $job['summary']['maintenance']['completed'] = 1;
                $job['summary']['phase'] = 'asset_verification';
                $phase = 'asset_verification';
                $job['progress_seq'] = absint($job['progress_seq'] ?? 0) + 1;
                $job['last_progress_at'] = time();
                $this->ebay_refresh_job_save($job);
            }

            if (!empty($job['summary']['reconcile_contracts']) && $phase === 'asset_verification') {
                if (!isset($job['summary']['asset_verification']) || !is_array($job['summary']['asset_verification'])) {
                    $job['summary']['asset_verification'] = array('processed'=>0,'verified'=>0,'blocked'=>0,'remaining'=>0,'completed'=>0);
                }
                $assets = $this->ebay_business_verify_asset_batch(2);
                foreach (array('processed','verified','blocked') as $key) {
                    $job['summary']['asset_verification'][$key] = absint($job['summary']['asset_verification'][$key] ?? 0) + absint($assets[$key] ?? 0);
                }
                $job['summary']['asset_verification']['remaining'] = absint($assets['remaining'] ?? 0);
                $job['progress_seq'] = absint($job['progress_seq'] ?? 0) + 1;
                $job['last_progress_at'] = time();
                if (absint($assets['remaining'] ?? 0) > 0) {
                    $this->ebay_refresh_job_save($job);
                    $reschedule = true;
                    return true;
                }
                $job['summary']['asset_verification']['completed'] = 1;
                $job['summary']['phase'] = 'source_refresh';
                $phase = 'source_refresh';
                $this->ebay_refresh_job_save($job);
            }

            $max_checks = max(1200, min(2000, absint($job['summary']['max_checks'] ?? $settings['inventory_refresh_max_per_run'] ?? 1200)));
            if (absint($job['summary']['checked'] ?? 0) >= $max_checks) { return $this->ebay_refresh_finalize($job, $settings, 'partial'); }
            if (!$this->ebay_refresh_has_more($job)) { return $this->ebay_refresh_finalize($job, $settings, 'completed'); }
            $token = $this->ebay_access_token($settings);
            if (is_wp_error($token)) {
                $job['summary']['technical_errors']++;
                if (count($job['summary']['errors']) < 30) { $job['summary']['errors'][] = array('item_id'=>'','code'=>$token->get_error_code(),'error'=>$token->get_error_message()); }
                return $this->ebay_refresh_finalize($job, $settings, 'failed');
            }

            $worker_budget = max(10, min(30, absint($settings['run_time_budget_seconds'] ?? 20)));
            $deadline = microtime(true) + max(8, $worker_budget - 2);
            $operations = 0;
            while (microtime(true) < $deadline && $operations < 100) {
                $operations++;
                if ($this->ebay_refresh_segment_expired($job)) {
                    $job['summary']['stopped_reason'] = 'segment_time_budget';
                    return $this->ebay_refresh_finalize($job, $settings, 'partial');
                }
                $checked = absint($job['summary']['checked'] ?? 0);
                if ($checked >= $max_checks) {
                    return $this->ebay_refresh_has_more($job)
                        ? $this->ebay_refresh_finalize($job, $settings, 'partial')
                        : $this->ebay_refresh_finalize($job, $settings, 'completed');
                }
                $rows = $this->ebay_refresh_due_rows($job, min(10, $max_checks - $checked));
                if (!$rows) { return $this->ebay_refresh_finalize($job, $settings, 'completed'); }
                foreach ($rows as $row) {
                    if (microtime(true) >= $deadline) { break; }
                    $this->ebay_refresh_process_row($job, $row, $settings, $token);
                    $job['progress_seq'] = absint($job['progress_seq'] ?? 0) + 1;
                    $job['last_progress_at'] = time();
                    $this->ebay_refresh_job_save($job);
                    if (absint($job['summary']['checked'] ?? 0) >= $max_checks) { break; }
                }
                if (absint($job['summary']['checked'] ?? 0) >= $max_checks) {
                    return $this->ebay_refresh_has_more($job)
                        ? $this->ebay_refresh_finalize($job, $settings, 'partial')
                        : $this->ebay_refresh_finalize($job, $settings, 'completed');
                }
                if (!$this->ebay_refresh_has_more($job)) { return $this->ebay_refresh_finalize($job, $settings, 'completed'); }
            }
            $reschedule = true;
            $this->ebay_refresh_job_save($job);
            return true;
        } catch (Throwable $error) {
            $settings = $this->ebay_settings();
            if ($this->ebay_refresh_job_is_open($job)) {
                $job['summary']['technical_errors'] = absint($job['summary']['technical_errors'] ?? 0) + 1;
                if (count((array)($job['summary']['errors'] ?? array())) < 30) { $job['summary']['errors'][] = array('item_id'=>'','code'=>'ebay_refresh_runtime_error','error'=>$error->getMessage()); }
                return $this->ebay_refresh_finalize($job, $settings, 'failed');
            }
            return new WP_Error('ebay_refresh_runtime_error', $error->getMessage());
        } finally {
            if (function_exists('delete_transient')) { delete_transient($lock_key); }
            if ($reschedule) {
                $fresh = $this->ebay_refresh_job_load();
                if ($this->ebay_refresh_job_is_open($fresh)) { $this->ebay_refresh_dispatch_worker($fresh); }
            }
        }
    }

    public function handle_ebay_refresh_worker_tick() {
        $job = $this->ebay_refresh_job_load();
        $provided = isset($_POST['token']) ? (string) wp_unslash($_POST['token']) : '';
        $expected = (string) ($job['worker_token'] ?? '');
        if (!$this->ebay_refresh_job_is_open($job) || $provided === '' || $expected === '' || !hash_equals($expected, $provided)) {
            status_header(403); exit;
        }
        if (function_exists('ignore_user_abort')) { ignore_user_abort(true); }
        if (function_exists('set_time_limit')) { @set_time_limit(45); }
        $this->run_ebay_inventory_refresh_worker(true);
        status_header(204); exit;
    }

    public function handle_ebay_worker_tick() {
        $job = $this->ebay_sync_job_load();
        $provided = isset($_POST['token']) ? (string) wp_unslash($_POST['token']) : '';
        $expected = (string) ($job['worker_token'] ?? '');
        if (!$this->ebay_sync_job_is_open($job) || $provided === '' || $expected === '' || !hash_equals($expected, $provided)) {
            status_header(403);
            exit;
        }
        if (function_exists('ignore_user_abort')) { ignore_user_abort(true); }
        if (function_exists('set_time_limit')) { @set_time_limit(45); }
        $this->run_ebay_sync_worker(true);
        status_header(204);
        exit;
    }

    /**
     * V5.5.0 – eBay-Inhalte nach Ablauf der Frischegrenze sicher deaktivieren.
     *
     * eBay verlangt, dass ANGEZEIGTE Listingdaten höchstens sechs Stunden alt
     * sind. Deshalb werden stale/ended Inhalte aus Frontend und Adminanzeige
     * entfernt. Der portalinterne HivePress-Datensatz bleibt jedoch als
     * Tombstone erhalten, damit Quelle, Workflow und erneute Synchronisierung
     * nachvollziehbar bleiben. Alte eBay-Titel, Preis, Verkäufer, Bild und URLs
     * werden dabei ausdrücklich nicht weiter angezeigt.
     */
    private function ebay_purge_item_content($row, $purge_status, $reason) {
        if (!is_array($row) || empty($row['id'])) { return array('listing_deleted'=>0,'listing_tombstoned'=>0,'creative_disabled'=>0); }
        global $wpdb;
        $listing_tombstoned = 0;
        $creative_disabled = 0;
        $listing_id = absint($row['listing_post_id'] ?? 0);
        $state = strpos((string) $purge_status, 'ended') !== false ? 'ended' : 'stale';

        if ($listing_id > 0) {
            $current_status = function_exists('get_post_status') ? (string) get_post_status($listing_id) : '';
            $publish_intent = $current_status === 'publish' ? 'publish' : sanitize_key((string) get_post_meta($listing_id, '_ppar_ebay_publish_intent', true));
            if (!in_array($publish_intent, array('publish','draft'), true)) { $publish_intent = 'draft'; }
            // V5.14: fail-closed means public output OFF, not source destruction.
            // Keep title/content/image and source metadata internally so an admin
            // preview and a later fresh sync can reuse the same HivePress object.
            if ($current_status === 'publish' && function_exists('wp_update_post')) {
                wp_update_post(array('ID'=>$listing_id, 'post_status'=>'draft'));
                $listing_tombstoned = 1;
            }
            update_post_meta($listing_id, '_ppar_ebay_lifecycle_state', $state);
            update_post_meta($listing_id, '_ppar_ebay_publish_intent', $publish_intent);
            update_post_meta($listing_id, '_ppar_ebay_last_seen_at', absint($row['last_seen'] ?? 0));
            update_post_meta($listing_id, '_ppar_ebay_stale_since', time());
            update_post_meta($listing_id, '_ppar_ebay_source_label', 'eBay privat');
            update_post_meta($listing_id, '_ppar_ebay_item_id', sanitize_text_field((string) ($row['item_id'] ?? '')));
            update_post_meta($listing_id, '_ppar_ebay_seller_type', 'INDIVIDUAL');
            update_post_meta($listing_id, '_ppar_ebay_target_term_id', absint($row['target_term_id'] ?? 0));
            update_post_meta($listing_id, '_ppar_ebay_fresh_until', 0);
        }

        $identity = sanitize_text_field((string) ($row['creative_identity_hash'] ?? ''));
        if ($identity !== '' && method_exists($this, 'creative_library_table')) {
            if (method_exists($this, 'output_objects_table')) {
                $output_table = $this->output_objects_table();
                $objects = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$output_table} WHERE creative_identity_hash=%s", $identity), ARRAY_A);
                foreach ((array) $objects as $object) {
                    if (method_exists($this, 'output_deactivate_materialized_object')) {
                        $this->output_deactivate_materialized_object($object, $reason);
                    }
                    $campaign_id = absint($object['campaign_post_id'] ?? 0);
                    if ($campaign_id > 0 && method_exists($this, 'output_campaign_by_post_id') && method_exists($this, 'save_campaign_record')) {
                        $campaign = $this->output_campaign_by_post_id($campaign_id);
                        if (is_array($campaign)) {
                            // V5.18: Ausgabe deaktivieren, aber Produktidentitaet,
                            // Titel, Bild, Preis und URLs intern erhalten. Ein
                            // spaeter wieder verfuegbares Item kann dadurch
                            // deterministisch denselben Datensatz reaktivieren.
                            $campaign['active'] = false;
                            $campaign['availability'] = 'inactive';
                            $campaign['programme_status'] = 'inactive';
                            $campaign['programme_status_checked_at'] = time();
                            $this->save_campaign_record($campaign, $campaign_id);
                        }
                    }
                    $wpdb->update($output_table, array(
                        'status'=>'blocked_source',
                        'decision_reason'=>sanitize_text_field((string) $reason),
                        'last_verified'=>time(),
                        'updated_at'=>time(),
                    ), array('id'=>absint($object['id'])));
                }
            }
            $creative_table = $this->creative_library_table();
            $creative_row = $wpdb->get_row($wpdb->prepare("SELECT payload FROM {$creative_table} WHERE identity_hash=%s", $identity), ARRAY_A);
            $creative_payload = is_array($creative_row) ? json_decode((string) ($creative_row['payload'] ?? ''), true) : array();
            $creative_payload = is_array($creative_payload) ? $creative_payload : array();
            $creative_payload['_ebay_lifecycle_state'] = $state;
            $creative_payload['_ebay_inactive_at'] = time();
            $creative_payload['_ebay_inactive_reason'] = sanitize_text_field((string) $reason);
            $wpdb->update($creative_table, array(
                'source_status'=>'inactive',
                'availability_state'=>'inactive',
                'selected'=>0,
                'payload'=>wp_json_encode($creative_payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            ), array('identity_hash'=>$identity));
            $creative_disabled = 1;
        }

        // V5.14: interne Quelldaten bleiben erhalten. Die öffentliche Ausgabe
        // ist durch Status + Lifecycle + Draft/freshness gate fail-closed. So wird
        // ein verpasster Sync nicht mehr zu irreversiblem Datenverlust.
        $wpdb->update($this->ebay_items_table(), array(
            'status'=>sanitize_key((string) $purge_status),
            'source_state'=>$state === 'ended' ? 'ended' : 'available',
            'output_state'=>'inactive',
            'rejection_reason'=>sanitize_text_field((string) $reason),
            'updated_at'=>time(),
        ), array('id'=>absint($row['id'])));
        return array('listing_deleted'=>0,'listing_tombstoned'=>$listing_tombstoned,'creative_disabled'=>$creative_disabled);
    }

    public function ebay_expire_stale_items() {
        $this->maybe_install_ebay_schema();
        global $wpdb;
        $table = $this->ebay_items_table();
        $now = time();
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$table} WHERE status IN ('active','review','purged_stale') AND ((fresh_until>0 AND fresh_until<%d) OR (item_end_at>0 AND item_end_at<=%d))", $now, $now), ARRAY_A);
        $summary = array('checked'=>count((array) $rows),'stale_visibility_only'=>0,'deleted_listings'=>0,'tombstoned_listings'=>0,'disabled_creatives'=>0,'purged'=>0);
        foreach ((array) $rows as $row) {
            $ended = absint($row['item_end_at'] ?? 0) > 0 && absint($row['item_end_at']) <= $now;
            if (!$ended) {
                // Last-Known-Good-Grundgesetz: fehlende Frische markiert nur
                // einen faelligen Refresh. Ohne eindeutiges Endsignal bleibt der
                // bestehende oeffentliche Bestand sichtbar und unveraendert.
                $summary['stale_visibility_only']++; // Legacy-KPI-Name bleibt kompatibel.
                continue;
            }
            $purged = $this->ebay_purge_item_content($row, 'purged_ended', 'eBay-Angebot beendet; öffentliche eBay-Inhalte deaktiviert.');
            $summary['deleted_listings'] += absint($purged['listing_deleted'] ?? 0);
            $summary['tombstoned_listings'] += absint($purged['listing_tombstoned'] ?? 0);
            $summary['disabled_creatives'] += absint($purged['creative_disabled'] ?? 0);
            $summary['purged']++;
        }
        return $summary;
    }

    /**
     * V5.14 compatibility stub. Frontend requests are read-only with respect to
     * eBay lifecycle state. Stale data remains Last-Known-Good visible; refresh/end-state enforcement is handled by the scheduled source jobs.
     */
    public function ebay_runtime_stale_guard() {
        return;
    }

    /** True only for a real wp-admin screen, never for public AJAX requests. */
    private function ebay_is_backend_admin_screen_request() {
        if (!function_exists('is_admin') || !is_admin()) { return false; }
        if (function_exists('wp_doing_ajax') && wp_doing_ajax()) { return false; }
        if (defined('DOING_AJAX') && DOING_AJAX) { return false; }
        return true;
    }

    /** Permanent canonical redirect for the removed visible provider category. */
    public function ebay_redirect_legacy_private_category() {
        if ($this->ebay_is_backend_admin_screen_request()) { return; }
        $slug = '';
        if (function_exists('get_query_var')) { $slug = sanitize_title((string) get_query_var('hp_listing_category')); }
        if ($slug !== 'ebay-privatanzeigen') {
            $request_uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';
            $path = (string) parse_url($request_uri, PHP_URL_PATH);
            if (!preg_match('~(?:^|/)ebay-privatanzeigen/?$~i', $path)) { return; }
        }
        $parent = $this->ebay_private_parent_term();
        if (!is_object($parent) || !function_exists('get_term_link')) { return; }
        $url = get_term_link($parent, 'hp_listing_category');
        if (is_wp_error($url) || trim((string) $url) === '') { return; }
        if (function_exists('wp_safe_redirect')) { wp_safe_redirect($url, 301, 'Affiliate-Zentrale'); exit; }
    }

    /**
     * Frontend-Sicherheitsfilter für eBay-Lifecycle, Chef-Control und die harte
     * Sichtbarkeitsdecke. Private eBay-Listings dürfen ausschließlich auf ihrer
     * eigenen Single-Seite sowie innerhalb des Taxonomie-Teilbaums ab
     * `private-anzeigen` erscheinen. Der allgemeine Anzeigenmarkt und alle
     * anderen HivePress-Kategorien bleiben frei von diesen eBay-Privatanzeigen.
     */
    public function ebay_filter_stale_posts($posts, $query = null) {
        if ($this->ebay_is_backend_admin_screen_request() || !$posts) { return $posts; }
        $now = time();
        $safe = array();
        $private_context = $this->ebay_query_allows_private_ebay($query);

        // Resolve all source rows once. The public layer then re-checks the SAME
        // central policy used by Discovery/Maintenance, so stale DB flags or a
        // missed migration cannot leak toy/model inventory into HivePress.
        $post_item_ids = array();
        $source_item_ids = array();
        foreach ((array)$posts as $post) {
            if (!is_object($post) || (string)($post->post_type ?? '') !== 'hp_listing') { continue; }
            $post_id = absint($post->ID ?? 0);
            $item_id = sanitize_text_field((string)get_post_meta($post_id, '_ppar_ebay_item_id', true));
            if ($item_id === '') { continue; }
            $post_item_ids[$post_id] = $item_id;
            $source_item_ids[] = $item_id;
        }
        $source_rows = $this->ebay_public_source_rows_by_item_ids($source_item_ids, 'INDIVIDUAL');

        foreach ((array) $posts as $post) {
            if (!is_object($post) || (string) ($post->post_type ?? '') !== 'hp_listing') { $safe[] = $post; continue; }
            $post_id = absint($post->ID ?? 0);
            $item_id = (string)($post_item_ids[$post_id] ?? '');
            if ($item_id === '') { $safe[] = $post; continue; }
            if (!$private_context) { continue; }

            $source_row = is_array($source_rows[$item_id] ?? null) ? $source_rows[$item_id] : array();
            if ($source_row) {
                if (sanitize_key((string)($source_row['source_state'] ?? 'available')) === 'ended') { continue; }
                if (sanitize_key((string)($source_row['policy_state'] ?? 'allowed')) === 'blocked') { continue; }
                if ($this->ebay_public_content_policy_reason_from_source_row($source_row, (string)($post->post_title ?? '')) !== '') { continue; }
            } elseif ($this->ebay_content_policy_reason(array('title'=>(string)($post->post_title ?? ''))) !== '') {
                // Legacy row not resolvable: title-only hard signatures still fail
                // closed; clean legacy listings keep their previous visibility.
                continue;
            }

            $lifecycle = sanitize_key((string) get_post_meta($post_id, '_ppar_ebay_lifecycle_state', true));
            if ($lifecycle !== '' && $lifecycle !== 'active') { continue; }
            $seller = (string) get_post_meta($post_id, '_ppar_ebay_seller_username', true);
            $target_term_id = absint(get_post_meta($post_id, '_ppar_ebay_target_term_id', true));
            $control_gate = $this->ebay_private_control_gate($seller, $target_term_id, $post_id);
            if (is_wp_error($control_gate)) { continue; }
            // Last-Known-Good bleibt sichtbar, auch wenn der naechste
            // Quellenrefresh bereits faellig ist. Nur ein belastbares Endsignal
            // darf den Datensatz an dieser Grenze entfernen.
            $end_at = $source_row ? absint($source_row['item_end_at'] ?? 0) : absint(get_post_meta($post_id, '_ppar_ebay_item_end_at', true));
            if ($end_at <= 0 || $end_at > $now) { $safe[] = $post; }
        }
        // V5.23: HivePress can still render its configured archive amount even when
        // posts_per_page was tightened by a late query hook (for example via an
        // already prepared/cached listing query). On the exact parent overview
        // `Private Anzeigen`, the UI contract is therefore enforced at the final
        // post-array boundary as well: never more than nine cards. Descendant
        // categories and singular listings are untouched.
        $parent = $this->ebay_private_parent_term();
        $parent_id = is_object($parent) ? absint($parent->term_id ?? 0) : 0;
        if ($parent_id > 0 && $this->ebay_query_targets_private_parent($query, $parent_id) && count($safe) > 9) {
            $safe = array_slice($safe, 0, 9);
        }
        return $safe;
    }

    /**
     * HivePress setzt die Taxonomieabfrage selbst. Auf der übergeordneten Kategorie
     * "Private Anzeigen" werden deshalb die komplette eBay-Wurzel und alle tieferen
     * Nachfahren explizit in dieselbe Taxonomie-Klausel aufgenommen. Andere
     * HivePress-Kategorien und normale Listings bleiben vollständig unangetastet.
     */
    /** Resolve the exact HivePress parent term without relying on global query state. */
    private function ebay_private_parent_term() {
        if (!function_exists('get_term_by')) { return null; }
        $term = get_term_by('slug', 'private-anzeigen', 'hp_listing_category');
        return is_object($term) ? $term : null;
    }

    /** Check whether the passed WP_Query actually targets Private Anzeigen. */
    private function ebay_query_targets_private_parent($query, $parent_id) {
        if (!is_object($query) || !method_exists($query, 'get')) { return false; }
        $parent_id = absint($parent_id);

        // Instance conditional is safe inside pre_get_posts; global is_tax() is not.
        if (method_exists($query, 'is_tax') && $query->is_tax('hp_listing_category', 'private-anzeigen')) { return true; }

        $direct = $query->get('hp_listing_category');
        foreach ((array) $direct as $value) {
            if (sanitize_title((string) $value) === 'private-anzeigen') { return true; }
        }
        if ((string) $query->get('taxonomy') === 'hp_listing_category') {
            $term_value = (string) $query->get('term');
            if (sanitize_title($term_value) === 'private-anzeigen') { return true; }
            if ($parent_id > 0 && absint($query->get('term_id')) === $parent_id) { return true; }
        }

        $contains_parent = function($clause) use (&$contains_parent, $parent_id) {
            if (!is_array($clause)) { return false; }
            if (isset($clause['taxonomy']) && (string) $clause['taxonomy'] === 'hp_listing_category') {
                $field = sanitize_key((string) ($clause['field'] ?? 'term_id'));
                foreach ((array) ($clause['terms'] ?? array()) as $term_value) {
                    if ($field === 'slug' || $field === 'name') {
                        if (sanitize_title((string) $term_value) === 'private-anzeigen') { return true; }
                    } elseif ($parent_id > 0 && absint($term_value) === $parent_id) {
                        return true;
                    }
                }
            }
            foreach ($clause as $value) {
                if (is_array($value) && $contains_parent($value)) { return true; }
            }
            return false;
        };
        return $contains_parent((array) $query->get('tax_query'));
    }

    /**
     * HivePress deliberately maintains category counts across descendants, while
     * its listing loop may still query only the selected term. On the exact
     * parent "Private Anzeigen" we therefore expand the tax clause to all
     * descendants. Detection uses only the passed WP_Query, never global tags.
     */
    public function ebay_expand_private_parent_listing_query($query) {
        if ($this->ebay_is_backend_admin_screen_request()) { return; }
        if (!is_object($query) || !method_exists($query, 'get') || !method_exists($query, 'set')) { return; }

        $parent = $this->ebay_private_parent_term();
        $parent_id = is_object($parent) ? absint($parent->term_id ?? 0) : 0;
        if ($parent_id <= 0 || !$this->ebay_query_targets_private_parent($query, $parent_id)) { return; }
        if (!function_exists('get_term_children')) { return; }
        $children = get_term_children($parent_id, 'hp_listing_category');
        if (is_wp_error($children)) { return; }
        $term_ids = array_values(array_unique(array_filter(array_merge(array($parent_id), array_map('absint', (array) $children)))));
        if (count($term_ids) < 2) { return; }

        $existing_tax_query = $query->get('tax_query');
        $tax_query = is_array($existing_tax_query) ? $existing_tax_query : array();
        $matched = false;
        $rewrite_clause = function($clause) use (&$rewrite_clause, &$matched, $parent_id, $term_ids) {
            if (!is_array($clause)) { return $clause; }
            if (isset($clause['taxonomy']) && (string) $clause['taxonomy'] === 'hp_listing_category') {
                $field = sanitize_key((string) ($clause['field'] ?? 'term_id'));
                $is_parent = false;
                foreach ((array) ($clause['terms'] ?? array()) as $term_value) {
                    if (($field === 'slug' || $field === 'name') && sanitize_title((string) $term_value) === 'private-anzeigen') { $is_parent = true; break; }
                    if (!in_array($field, array('slug','name'), true) && absint($term_value) === $parent_id) { $is_parent = true; break; }
                }
                if ($is_parent) {
                    $clause['field'] = 'term_id';
                    $clause['terms'] = $term_ids;
                    $clause['operator'] = 'IN';
                    // Already expanded explicitly, so never rely on another plugin's child policy.
                    $clause['include_children'] = false;
                    $matched = true;
                }
                return $clause;
            }
            foreach ($clause as $key=>$value) {
                if (is_array($value)) { $clause[$key] = $rewrite_clause($value); }
            }
            return $clause;
        };
        $tax_query = $rewrite_clause($tax_query);
        if (!$matched) {
            $tax_query[] = array(
                'taxonomy'=>'hp_listing_category',
                'field'=>'term_id',
                'terms'=>$term_ids,
                'operator'=>'IN',
                'include_children'=>false,
            );
        }
        $query->set('tax_query', $tax_query);

        // Prevent the original taxonomy query var from re-adding a second,
        // parent-only clause when WP_Query parses tax vars after pre_get_posts.
        $direct_category = $query->get('hp_listing_category');
        $clear_direct_category = false;
        foreach ((array) $direct_category as $direct_value) {
            if (sanitize_title((string) $direct_value) === 'private-anzeigen') {
                $clear_direct_category = true;
                break;
            }
        }
        if ($clear_direct_category) {
            $query->set('hp_listing_category', '');
        }
        if ((string) $query->get('taxonomy') === 'hp_listing_category') {
            $query->set('taxonomy', '');
            $query->set('term', '');
            $query->set('term_id', 0);
        }

        // Private Anzeigen is a 3x3 teaser overview, not a second full archive.
        // IMPORTANT: public visibility is filtered later at `the_posts` because
        // freshness, end state and Chef-Control cannot all be expressed safely in
        // one generic HivePress SQL meta query. Fetch a bounded refill window here
        // and cut to exactly nine only AFTER those gates. Otherwise two blocked or
        // stale rows inside the first SQL page turn a healthy 3x3 pool into 7 cards.
        $candidate_limit = 45;
        $query->set('posts_per_page', $candidate_limit);
        $query->set('posts_per_archive_page', $candidate_limit);
        $query->set('_ppar_ebay_private_public_limit', 9);
        $query->set('paged', 1);
        $query->set('no_found_rows', true);
    }


    /** Ist die konkrete WP_Query eine einzelne HivePress-Anzeige? */
    private function ebay_query_is_listing_singular($query) {
        if (!is_object($query)) { return false; }
        if (method_exists($query, 'is_singular') && $query->is_singular('hp_listing')) { return true; }
        if (!method_exists($query, 'get')) { return false; }
        $post_type = $query->get('post_type');
        $is_listing_type = $post_type === 'hp_listing' || (is_array($post_type) && in_array('hp_listing', $post_type, true));
        if (!$is_listing_type) { return false; }
        return absint($query->get('p')) > 0 || trim((string) $query->get('name')) !== '' || trim((string) $query->get('pagename')) !== '';
    }

    /** Alle explizit in der Query angesprochenen hp_listing_category-Term-IDs. */
    private function ebay_query_listing_category_term_ids($query) {
        if (!is_object($query)) { return array(); }
        $ids = array();
        $resolve = function($value, $field = 'slug') use (&$ids) {
            if ($field === 'term_id' || $field === 'id') {
                $id = absint($value);
                if ($id > 0) { $ids[$id] = $id; }
                return;
            }
            if (!function_exists('get_term_by')) { return; }
            $lookup = $field === 'name' ? 'name' : 'slug';
            $term = get_term_by($lookup, (string) $value, 'hp_listing_category');
            if (is_object($term) && absint($term->term_id ?? 0) > 0) { $ids[absint($term->term_id)] = absint($term->term_id); }
        };

        if (method_exists($query, 'get_queried_object')) {
            $queried = $query->get_queried_object();
            if (is_object($queried) && (string) ($queried->taxonomy ?? '') === 'hp_listing_category' && absint($queried->term_id ?? 0) > 0) {
                $ids[absint($queried->term_id)] = absint($queried->term_id);
            }
        }
        if (!method_exists($query, 'get')) { return array_values($ids); }

        foreach ((array) $query->get('hp_listing_category') as $value) {
            if (trim((string) $value) !== '') { $resolve($value, 'slug'); }
        }
        if ((string) $query->get('taxonomy') === 'hp_listing_category') {
            if (absint($query->get('term_id')) > 0) { $resolve($query->get('term_id'), 'term_id'); }
            elseif (trim((string) $query->get('term')) !== '') { $resolve($query->get('term'), 'slug'); }
        }
        $walk = function($node) use (&$walk, $resolve) {
            if (!is_array($node)) { return; }
            if (isset($node['taxonomy']) && (string) $node['taxonomy'] === 'hp_listing_category') {
                $field = sanitize_key((string) ($node['field'] ?? 'term_id'));
                foreach ((array) ($node['terms'] ?? array()) as $value) { $resolve($value, $field); }
            }
            foreach ($node as $value) { if (is_array($value)) { $walk($value); } }
        };
        $walk((array) $query->get('tax_query'));
        return array_values($ids);
    }

    /** Exakte Sichtbarkeitsregel: Single oder Taxonomie-Teilbaum ab Private Anzeigen. */
    private function ebay_query_allows_private_ebay($query) {
        if ($this->ebay_query_is_listing_singular($query)) { return true; }
        $parent = $this->ebay_private_parent_term();
        $parent_id = is_object($parent) ? absint($parent->term_id ?? 0) : 0;
        if ($parent_id <= 0) { return false; }
        $ids = $this->ebay_query_listing_category_term_ids($query);
        if (!$ids) { return false; }
        foreach ($ids as $term_id) {
            if ($term_id === $parent_id) { return true; }
            $ancestors = function_exists('get_ancestors') ? array_map('absint', (array) get_ancestors($term_id, 'hp_listing_category', 'taxonomy')) : array();
            if (in_array($parent_id, $ancestors, true)) { return true; }
        }
        return false;
    }

    /**
     * Query-seitige Decke, damit Pagination/Counts nicht erst nach `the_posts`
     * korrigiert werden müssen. Außerhalb des erlaubten Teilbaums werden nur
     * Posts mit unserem eBay-Item-Metafeld ausgeschlossen; native HivePress-
     * Anzeigen bleiben vollständig erhalten.
     */
    public function ebay_enforce_private_visibility_ceiling($query) {
        if ($this->ebay_is_backend_admin_screen_request()) { return; }
        if (!is_object($query) || !method_exists($query, 'get') || !method_exists($query, 'set')) { return; }
        if ($this->ebay_query_is_listing_singular($query) || $this->ebay_query_allows_private_ebay($query)) { return; }
        if ($query->get('_ppar_ebay_visibility_ceiling')) { return; }

        $post_type = $query->get('post_type');
        $listing_query = $post_type === 'hp_listing' || (is_array($post_type) && in_array('hp_listing', $post_type, true));
        if (!$listing_query) {
            $listing_query = (string) $query->get('taxonomy') === 'hp_listing_category' || !empty($query->get('hp_listing_category')) || !empty($this->ebay_query_listing_category_term_ids($query));
        }
        if (!$listing_query) { return; }

        $existing_meta_query = $query->get('meta_query');
        $meta_query = is_array($existing_meta_query) ? $existing_meta_query : array();
        $meta_query[] = array('key'=>'_ppar_ebay_item_id','compare'=>'NOT EXISTS');
        $query->set('meta_query', $meta_query);
        $query->set('_ppar_ebay_visibility_ceiling', 1);
    }


    /** Admin: Quelle und eBay-Lifecycle direkt in HivePress > Listings sichtbar. */
    public function ebay_admin_listing_columns($columns) {
        if (!is_array($columns)) { return $columns; }
        $columns['ppar_source'] = 'Quelle';
        $columns['ppar_ebay_state'] = 'eBay-Status';
        return $columns;
    }

    public function ebay_admin_listing_column_content($column, $post_id) {
        $post_id = absint($post_id);
        if ($column === 'ppar_source') {
            if ((string) get_post_meta($post_id, '_ppar_ebay_item_id', true) !== '') {
                echo '<strong>eBay privat</strong>';
            } else {
                echo 'HivePress / intern';
            }
            return;
        }
        if ($column !== 'ppar_ebay_state') { return; }
        if ((string) get_post_meta($post_id, '_ppar_ebay_item_id', true) === '') { echo '—'; return; }
        $state = sanitize_key((string) get_post_meta($post_id, '_ppar_ebay_lifecycle_state', true));
        $labels = array('active'=>'Aktiv / frisch','stale'=>'Veraltet – Frontend aus','ended'=>'Beendet – Frontend aus');
        echo esc_html($labels[$state] ?? 'eBay – Status unbekannt');
        $last_seen = absint(get_post_meta($post_id, '_ppar_ebay_last_seen_at', true));
        if ($last_seen > 0) { echo '<br><small>Letzter Abgleich: ' . esc_html(wp_date('d.m.Y H:i', $last_seen)) . '</small>'; }
        $status = function_exists('get_post_status') ? (string) get_post_status($post_id) : '';
        if ($state === 'active') {
            if ($status === 'publish' && function_exists('get_permalink')) {
                echo '<br><a href="' . esc_url(get_permalink($post_id)) . '" target="_blank" rel="noopener">Öffnen</a>';
            } elseif (in_array($status, array('draft','pending','private'), true)) {
                // Do not fall back to WordPress' native hp_listing draft URL.
                // HivePress does not provide a reliable public draft single route;
                // always use the dedicated secure renderer for eBay drafts.
                $preview_url = $this->ebay_admin_preview_url($post_id);
                if ($preview_url !== '') { echo '<br><a href="' . esc_url($preview_url) . '" target="_blank" rel="noopener">Vorschau</a>'; }
            }
        }
    }

    public function ebay_admin_listing_row_actions($actions, $post) {
        if (!is_array($actions) || !is_object($post) || (string) ($post->post_type ?? '') !== 'hp_listing') { return $actions; }
        $post_id = absint($post->ID ?? 0);
        if ($post_id <= 0 || (string) get_post_meta($post_id, '_ppar_ebay_item_id', true) === '') { return $actions; }
        if (!function_exists('current_user_can') || !current_user_can('edit_post', $post_id)) { return $actions; }
        $url = $this->ebay_secure_preview_url($post_id);
        if ($url !== '') {
            $actions['view'] = '<a href="' . esc_url($url) . '" target="_blank" rel="noopener">Vorschau</a>';
        }
        return $actions;
    }

    public function ebay_admin_listing_filters($post_type = '') {
        if ((string) $post_type !== 'hp_listing') { return; }
        $source = isset($_GET['ppar_listing_source']) ? sanitize_key(wp_unslash((string) $_GET['ppar_listing_source'])) : '';
        $state = isset($_GET['ppar_ebay_state']) ? sanitize_key(wp_unslash((string) $_GET['ppar_ebay_state'])) : '';
        echo '<select name="ppar_listing_source">';
        echo '<option value="">Alle Quellen</option>';
        echo '<option value="ebay"' . selected($source, 'ebay', false) . '>eBay privat</option>';
        echo '<option value="normal"' . selected($source, 'normal', false) . '>Normale HivePress-Listings</option>';
        echo '</select>';
        echo '<select name="ppar_ebay_state">';
        echo '<option value="">Alle eBay-Status</option>';
        echo '<option value="active"' . selected($state, 'active', false) . '>Aktiv / frisch</option>';
        echo '<option value="stale"' . selected($state, 'stale', false) . '>Veraltet</option>';
        echo '<option value="ended"' . selected($state, 'ended', false) . '>Beendet</option>';
        echo '</select>';
    }

    public function ebay_admin_filter_listing_query($query) {
        if (!is_admin() || !is_object($query) || (method_exists($query, 'is_main_query') && !$query->is_main_query())) { return; }
        $post_type = method_exists($query, 'get') ? $query->get('post_type') : '';
        if (is_array($post_type)) { $is_listing = in_array('hp_listing', $post_type, true); }
        else { $is_listing = (string) $post_type === 'hp_listing'; }
        if (!$is_listing || !method_exists($query, 'set')) { return; }
        $source = isset($_GET['ppar_listing_source']) ? sanitize_key(wp_unslash((string) $_GET['ppar_listing_source'])) : '';
        $state = isset($_GET['ppar_ebay_state']) ? sanitize_key(wp_unslash((string) $_GET['ppar_ebay_state'])) : '';
        $meta_query = method_exists($query, 'get') ? $query->get('meta_query') : array();
        $meta_query = is_array($meta_query) ? $meta_query : array();
        if ($source === 'ebay') { $meta_query[] = array('key'=>'_ppar_ebay_item_id','compare'=>'EXISTS'); }
        elseif ($source === 'normal') { $meta_query[] = array('key'=>'_ppar_ebay_item_id','compare'=>'NOT EXISTS'); }
        if (in_array($state, array('active','stale','ended'), true)) {
            $meta_query[] = array('key'=>'_ppar_ebay_lifecycle_state','value'=>$state,'compare'=>'=');
            // Ein eBay-Statusfilter impliziert eBay-Quelle.
            if ($source === '') { $meta_query[] = array('key'=>'_ppar_ebay_item_id','compare'=>'EXISTS'); }
        }
        if ($meta_query) { $query->set('meta_query', $meta_query); }
    }

    /**
     * Vor Anzeige der Backend-Liste stale Daten sicher deaktivieren und alte
     * V5.4.0-Frischdatensätze einmalig mit Lifecycle-Metadaten ergänzen.
     */
    public function ebay_admin_prepare_listing_lifecycle() {
        if (!function_exists('post_type_exists') || !post_type_exists('hp_listing')) { return; }
        // Versionierter Schlüssel: Nach dem V5.8-Update läuft die Bestandsprüfung
        // sofort und wird nicht durch einen Transient eines älteren Builds übersprungen.
        $key = 'ppar_ebay_admin_lifecycle_v580';
        if (function_exists('get_transient') && get_transient($key)) { return; }
        if (function_exists('set_transient')) { set_transient($key, 1, 60); }
        // V5.24: Backend-Aufrufe sind strikt read-only fuer den eBay-Lifecycle.
        // Stale Listings werden nicht mehr allein durch das Oeffnen der Adminliste
        // auf Draft gesetzt. Der gezielte Refresh entscheidet ausschliesslich bei
        // einem bestaetigten Endsignal ueber die Deaktivierung.
        if (!function_exists('get_posts')) { return; }
        $ids = get_posts(array(
            'post_type'=>'hp_listing',
            'post_status'=>array('draft','pending','publish','private'),
            'meta_key'=>'_ppar_ebay_item_id',
            'meta_compare'=>'EXISTS',
            'posts_per_page'=>-1,
            'fields'=>'ids',
            'suppress_filters'=>true,
        ));
        $now = time();
        $settings = $this->ebay_settings();
        // Den technischen HivePress-Besitzer nicht nur für diesen Request
        // auflösen, sondern dauerhaft speichern. Hintergrundworker und spätere
        // Reparaturen verwenden dadurch dieselbe gültige WordPress-Identität.
        $author_result = $this->ebay_persist_listing_author_id($settings);
        $author_id = is_wp_error($author_result) ? 0 : absint($author_result);
        foreach ((array) $ids as $listing_id) {
            $listing_id = absint($listing_id);
            if ($listing_id <= 0) { continue; }
            if ($author_id > 0 && function_exists('get_post_field') && absint(get_post_field('post_author', $listing_id)) <= 0 && function_exists('wp_update_post')) {
                wp_update_post(array('ID'=>$listing_id,'post_author'=>$author_id));
            }
            if ((string) get_post_meta($listing_id, '_ppar_ebay_lifecycle_state', true) !== '') { continue; }
            $fresh_until = absint(get_post_meta($listing_id, '_ppar_ebay_fresh_until', true));
            $end_at = absint(get_post_meta($listing_id, '_ppar_ebay_item_end_at', true));
            // Migration darf aus einem bloss ueberfaelligen Refresh niemals einen
            // versteckten Lifecycle-Zustand erzeugen. Nur Endsignale deaktivieren.
            $state = ($end_at > 0 && $end_at <= $now) ? 'ended' : 'active';
            update_post_meta($listing_id, '_ppar_ebay_lifecycle_state', $state);
            update_post_meta($listing_id, '_ppar_ebay_publish_intent', function_exists('get_post_status') && get_post_status($listing_id) === 'publish' ? 'publish' : 'draft');
            update_post_meta($listing_id, '_ppar_ebay_last_seen_at', max(0, $fresh_until - 6 * HOUR_IN_SECONDS));
        }
    }

    public function ebay_setup_private_categories() {
        if (!function_exists('taxonomy_exists') || !taxonomy_exists('hp_listing_category') || !function_exists('wp_insert_term') || !function_exists('wp_update_term')) {
            return new WP_Error('ebay_hivepress_missing', 'HivePress-Kategorietaxonomie fehlt.');
        }
        $parent_exists = term_exists('private-anzeigen', 'hp_listing_category');
        if (is_array($parent_exists)) { $parent_id = absint($parent_exists['term_id'] ?? 0); }
        elseif (is_numeric($parent_exists) && absint($parent_exists) > 0) { $parent_id = absint($parent_exists); }
        else {
            $created = wp_insert_term('Private Anzeigen', 'hp_listing_category', array('slug'=>'private-anzeigen','description'=>'Private Anzeigen im Anzeigenmarkt.'));
            if (is_wp_error($created)) { return $created; }
            $parent_id = absint($created['term_id'] ?? 0);
        }
        if ($parent_id <= 0) { return new WP_Error('ebay_private_parent_create_failed', 'Private-Anzeigen-Wurzel konnte nicht erstellt werden.'); }
        $parent_term = get_term($parent_id, 'hp_listing_category');
        if (!$parent_term || is_wp_error($parent_term) || absint($parent_term->parent ?? 0) !== 0) {
            return new WP_Error('ebay_private_parent_conflict', 'Der Slug private-anzeigen ist bereits außerhalb der Taxonomie-Wurzel belegt.');
        }

        $legacy_exists = term_exists('ebay-privatanzeigen', 'hp_listing_category');
        $legacy_id = is_array($legacy_exists) ? absint($legacy_exists['term_id'] ?? 0) : (is_numeric($legacy_exists) ? absint($legacy_exists) : 0);
        if ($legacy_id > 0) {
            $legacy = get_term($legacy_id, 'hp_listing_category');
            if (!$legacy || is_wp_error($legacy) || absint($legacy->parent ?? 0) !== $parent_id) {
                return new WP_Error('ebay_private_legacy_conflict', 'Die frühere Kategorie „eBay-Privatanzeigen“ liegt nicht unter „Private Anzeigen“ und wird deshalb nicht automatisch verändert.');
            }
        }

        $children = $this->ebay_private_bucket_definitions();
        $created_count = 0;
        $moved_count = 0;
        $child_ids = array();
        foreach ($children as $slug=>$label) {
            $existing = term_exists($slug, 'hp_listing_category');
            if ($existing) {
                $term_id = is_array($existing) ? absint($existing['term_id'] ?? 0) : absint($existing);
                $term = $term_id > 0 ? get_term($term_id, 'hp_listing_category') : null;
                if (!$term || is_wp_error($term)) { return new WP_Error('ebay_private_child_missing', 'HivePress-Kategorie konnte nicht gelesen werden: ' . $slug); }
                $current_parent = absint($term->parent ?? 0);
                if ($current_parent === $legacy_id && $legacy_id > 0) {
                    $updated = wp_update_term($term_id, 'hp_listing_category', array('parent'=>$parent_id));
                    if (is_wp_error($updated)) { return $updated; }
                    $moved_count++;
                } elseif ($current_parent !== $parent_id) {
                    return new WP_Error('ebay_private_child_conflict', 'Der HivePress-Slug ' . $slug . ' ist bereits außerhalb von „Private Anzeigen“ belegt.');
                }
                $child_ids[$slug] = $term_id;
                continue;
            }
            $result = wp_insert_term($label, 'hp_listing_category', array('slug'=>$slug,'parent'=>$parent_id));
            if (is_wp_error($result)) { return $result; }
            $child_ids[$slug] = absint($result['term_id'] ?? 0);
            $created_count++;
        }

        // Persist the flat structure before repairing any legacy object/root assignments.
        $settings = $this->ebay_settings();
        $settings['private_parent_term_id'] = $parent_id;
        $settings['private_root_term_id'] = $parent_id;
        update_option(self::OPTION_NETWORK_EBAY, $settings, false);

        $legacy_reassigned = 0;
        if ($legacy_id > 0 && function_exists('get_objects_in_term')) {
            $objects = get_objects_in_term($legacy_id, 'hp_listing_category');
            if (!is_wp_error($objects)) {
                foreach ((array) $objects as $object_id) {
                    $object_id = absint($object_id);
                    if ($object_id <= 0) { continue; }
                    $assigned = function_exists('wp_get_post_terms') ? wp_get_post_terms($object_id, 'hp_listing_category', array('fields'=>'ids')) : array();
                    $assigned = is_wp_error($assigned) ? array() : array_map('absint', (array) $assigned);
                    $target = 0;
                    foreach ($child_ids as $child_id) {
                        if (in_array(absint($child_id), $assigned, true)) { $target = absint($child_id); break; }
                    }
                    if ($target <= 0 && function_exists('get_post_meta')) {
                        $meta_target = absint(get_post_meta($object_id, '_ppar_ebay_target_term_id', true));
                        if (in_array($meta_target, array_map('absint', array_values($child_ids)), true)) { $target = $meta_target; }
                    }
                    if ($target <= 0) { $target = absint($child_ids['sonstiges'] ?? 0); }
                    if ($target > 0 && function_exists('wp_set_post_terms')) {
                        // Append the recovered target and remove only the obsolete provider term.
                        // Never wipe unrelated manual HivePress categories from an existing listing.
                        $set = wp_set_post_terms($object_id, array($target), 'hp_listing_category', true);
                        if (is_wp_error($set)) { return $set; }
                        if (function_exists('wp_remove_object_terms')) {
                            $removed = wp_remove_object_terms($object_id, $legacy_id, 'hp_listing_category');
                            if (is_wp_error($removed)) { return $removed; }
                        }
                        if (function_exists('update_post_meta')) { update_post_meta($object_id, '_ppar_ebay_target_term_id', $target); }
                        $legacy_reassigned++;
                    }
                }
            }
        }

        // Repair database rows that still pointed at the obsolete provider root.
        // Prefer durable listing/classification/rule evidence; use Sonstiges only as the final safe bucket.
        if ($legacy_id > 0) {
            global $wpdb;
            if (is_object($wpdb)) {
                $rows = (array) $wpdb->get_results($wpdb->prepare("SELECT * FROM {$this->ebay_items_table()} WHERE target_term_id=%d AND seller_account_type='INDIVIDUAL'", $legacy_id), ARRAY_A);
                foreach ($rows as $row) {
                    $target = $this->ebay_recover_private_target_term_id($row, $settings);
                    if ($target <= 0) { $target = absint($child_ids['sonstiges'] ?? 0); }
                    if ($target > 0) { $this->ebay_persist_recovered_private_target($row, $target); }
                }
            }
        }

        $legacy_deleted = 0;
        if ($legacy_id > 0 && function_exists('wp_delete_term')) {
            $remaining_children = function_exists('get_term_children') ? get_term_children($legacy_id, 'hp_listing_category') : array();
            $remaining_objects = function_exists('get_objects_in_term') ? get_objects_in_term($legacy_id, 'hp_listing_category') : array();
            if (!is_wp_error($remaining_children) && !is_wp_error($remaining_objects) && empty($remaining_children) && empty($remaining_objects)) {
                $deleted = wp_delete_term($legacy_id, 'hp_listing_category');
                if (is_wp_error($deleted)) { return $deleted; }
                $legacy_deleted = $deleted ? 1 : 0;
            }
        }

        if ($legacy_id > 0 && function_exists('term_exists') && term_exists('ebay-privatanzeigen', 'hp_listing_category')) {
            return new WP_Error('ebay_private_legacy_not_empty', 'Die frühere Kategorie „eBay-Privatanzeigen“ konnte noch nicht sicher entfernt werden; die Migration wird beim nächsten Lauf erneut versucht.');
        }
        update_option(self::OPTION_EBAY_PRIVATE_STRUCTURE_VERSION, '2.0', false);
        return array(
            'parent_term_id'=>$parent_id,
            'root_term_id'=>$parent_id,
            'created_children'=>$created_count,
            'moved_children'=>$moved_count,
            'legacy_reassigned'=>$legacy_reassigned,
            'legacy_deleted'=>$legacy_deleted,
        );
    }

    public function maybe_migrate_ebay_private_flat_structure() {
        if ((string) get_option(self::OPTION_EBAY_PRIVATE_STRUCTURE_VERSION, '') === '2.0') { return; }
        if (!function_exists('taxonomy_exists') || !taxonomy_exists('hp_listing_category') || !function_exists('term_exists')) { return; }
        $settings = $this->ebay_settings();
        $legacy = term_exists('ebay-privatanzeigen', 'hp_listing_category');
        // Fresh installations must not silently create a portal taxonomy. The automatic
        // migration is only for an already configured/legacy private eBay structure.
        if (!$legacy && absint($settings['private_root_term_id'] ?? 0) <= 0 && absint($settings['private_parent_term_id'] ?? 0) <= 0) { return; }
        $result = $this->ebay_setup_private_categories();
        if (is_wp_error($result)) { return; }
        update_option(self::OPTION_EBAY_PRIVATE_STRUCTURE_VERSION, '2.0', false);
    }

    public function handle_ebay_save_settings() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_ebay_save_settings', 'ppar_ebay_nonce');
        $previous = $this->ebay_settings();
        $input = is_array($_POST['ppar_ebay'] ?? null) ? wp_unslash($_POST['ppar_ebay']) : array();
        $input['enabled'] = array_key_exists('enabled', $input) ? !empty($input['enabled']) : !empty($previous['enabled']);
        $input['private_enabled'] = !empty($input['private_enabled']);
        $input['private_auto_publish'] = !empty($input['private_auto_publish']);
        $input['inventory_refresh_enabled'] = !empty($input['inventory_refresh_enabled']);
        $input['business_enabled'] = !empty($input['business_enabled']);
        $input['api_terms_confirmed'] = !empty($input['api_terms_confirmed']);
        $input['privacy_policy_confirmed'] = !empty($input['privacy_policy_confirmed']);
        $secret = trim((string) ($input['client_secret'] ?? ''));
        $input['client_secret'] = $secret !== '' ? $secret : (string) ($previous['client_secret'] ?? '');
        $input['rules'] = $this->ebay_catalog_rules();
        $settings = $this->ebay_normalize_settings(array_merge($previous, $input), true);
        update_option(self::OPTION_NETWORK_EBAY, $settings, false);
        if (function_exists('delete_transient')) { delete_transient($this->ebay_token_cache_key($settings)); }
        $this->reschedule_ebay_cron(true);
        $this->reschedule_ebay_refresh_cron(true);
        wp_safe_redirect(add_query_arg(array('page'=>'affiliate-portal-ebay','ppar_ebay'=>'saved'), admin_url('admin.php')));
        exit;
    }

    public function handle_ebay_setup_categories() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_ebay_setup_categories', 'ppar_ebay_nonce');
        $result = $this->ebay_setup_private_categories();
        $args = array('page'=>'affiliate-portal-ebay','ppar_ebay'=>is_wp_error($result)?'error':'categories');
        if (is_wp_error($result)) { $args['message'] = rawurlencode($result->get_error_message()); }
        wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
        exit;
    }


    public function handle_ebay_verify_catalog() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_ebay_verify_catalog', 'ppar_ebay_nonce');
        $result = $this->ebay_catalog_integrity();
        $ok = !is_wp_error($result);
        $settings = $this->ebay_settings();
        if ($ok) {
            $settings['catalog_verified_sha256'] = sanitize_text_field((string) ($result['source_sha256'] ?? ''));
            $settings['catalog_verified_at'] = time();
        } else {
            $settings['catalog_verified_sha256'] = '';
            $settings['catalog_verified_at'] = 0;
        }
        update_option(self::OPTION_NETWORK_EBAY, $settings, false);
        $message = $ok
            ? sprintf('Portalabgleich PASS: %d Hauptbereiche, %d Bereichsseiten, %d Produktseiten und %d WordPress-Kategorien.', absint($result['main_hubs']), absint($result['hub_pages']), absint($result['product_pages']), absint($result['article_categories']))
            : $result->get_error_message();
        wp_safe_redirect(add_query_arg(array('page'=>'affiliate-portal-ebay','ppar_ebay'=>$ok?'catalog_passed':'error','message'=>rawurlencode($message)), admin_url('admin.php')));
        exit;
    }

    public function handle_ebay_test_connection() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_ebay_test_connection', 'ppar_ebay_nonce');
        $settings = $this->ebay_settings();
        $errors = $this->ebay_configuration_errors($settings);
        if ($errors) { $result = new WP_Error('ebay_configuration_invalid', implode(' ', $errors)); }
        else {
            $result = array('tested_at'=>time(),'private'=>'disabled','business'=>'disabled');
            $seller_types = array();
            if (!empty($settings['private_enabled'])) { $seller_types[] = 'INDIVIDUAL'; }
            if (!empty($settings['business_enabled'])) { $seller_types[] = 'BUSINESS'; }
            foreach ($seller_types as $seller_type) {
                $accepted = null;
                $route_key = $seller_type === 'INDIVIDUAL' ? 'private' : 'business';
                foreach ((array) $settings['rules'] as $rule) {
                    if (empty($rule['active']) || empty($rule[$route_key])) { continue; }
                    $items = $this->ebay_search($rule, $seller_type, $settings);
                    if (is_wp_error($items)) { $result = $items; break 2; }
                    foreach ((array) $items as $raw) {
                        $candidate = $this->ebay_accept_item($raw, $seller_type, $settings);
                        if (is_wp_error($candidate)) { continue; }
                        $classification = $seller_type === 'BUSINESS'
                            ? $this->ebay_business_classify_portal_item_strict($candidate, $rule)
                            : $this->ebay_classify_portal_item($candidate, $rule);
                        if (!is_wp_error($classification)) { $accepted = array('item'=>$candidate,'classification'=>$classification,'rule'=>$rule); break 2; }
                    }
                }
                if (!$accepted) { $result = new WP_Error('ebay_no_accepted_item', 'Für ' . $seller_type . ' wurde in den automatischen Pferde-Atelier-Abrufprofilen kein fachlich eindeutig freigegebenes Angebot gefunden.'); break; }
                $result[strtolower($seller_type)] = 'pass';
            }
        }
        $settings['last_test'] = is_wp_error($result) ? array('status'=>'failed','tested_at'=>time(),'message'=>$result->get_error_message()) : array_merge(array('status'=>'pass'), $result);
        update_option(self::OPTION_NETWORK_EBAY, $settings, false);
        wp_safe_redirect(add_query_arg(array('page'=>'affiliate-portal-ebay','ppar_ebay'=>is_wp_error($result)?'test_failed':'test_passed','message'=>rawurlencode(is_wp_error($result)?$result->get_error_message():'Verbindung, Verkäuferweiche und automatischer Pferde-Atelier-Themenfilter geprüft.')), admin_url('admin.php')));
        exit;
    }

    public function handle_ebay_run_sync() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_ebay_run_sync', 'ppar_ebay_nonce');
        $result = $this->run_ebay_sync(true);
        if (is_wp_error($result)) {
            $notice = 'sync_failed';
            $message = $result->get_error_message();
        } else {
            $already = sanitize_key((string) ($result['status'] ?? '')) === 'already_running';
            $notice = 'sync_started';
            $message = $already
                ? 'Ein eBay-Hintergrundabruf läuft bereits; es wurde kein zweiter Lauf gestartet.'
                : 'eBay-Hintergrundabruf gestartet. Der Lauf wird in fortsetzbaren Arbeitspaketen verarbeitet.';
        }
        wp_safe_redirect(add_query_arg(array('page'=>'affiliate-portal-ebay','ppar_ebay'=>$notice,'message'=>rawurlencode($message)), admin_url('admin.php')));
        exit;
    }

    public function handle_ebay_worker_now() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_ebay_worker_now', 'ppar_ebay_nonce');
        $result = $this->run_ebay_sync_worker(true);
        $message = is_wp_error($result) ? $result->get_error_message() : 'Ein eBay-Arbeitspaket wurde verarbeitet bzw. angestoßen.';
        wp_safe_redirect(add_query_arg(array('page'=>'affiliate-portal-ebay','ppar_ebay'=>is_wp_error($result)?'sync_failed':'sync_started','message'=>rawurlencode($message)), admin_url('admin.php')));
        exit;
    }

    public function handle_ebay_run_refresh() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_ebay_run_refresh', 'ppar_ebay_nonce');
        $result = $this->run_ebay_inventory_refresh(true);
        if (is_wp_error($result)) {
            $notice = 'refresh_failed';
            $message = $result->get_error_message();
        } else {
            $status = sanitize_key((string) ($result['status'] ?? ''));
            $notice = 'refresh_started';
            $message = $status === 'already_running'
                ? 'Ein eBay-Bestandsabgleich läuft bereits; es wurde kein zweiter Lauf gestartet.'
                : 'Vollständiger Bestandsabgleich gestartet: zuerst lokaler Workflow-Reconcile, danach nur fällige eBay-Angebote per getItem. Discovery bleibt aus; temporäre API-Fehler deaktivieren nichts dauerhaft.';
        }
        wp_safe_redirect(add_query_arg(array('page'=>'affiliate-portal-ebay','ppar_ebay'=>$notice,'message'=>rawurlencode($message)), admin_url('admin.php')));
        exit;
    }

    /**
     * V5.20 – deterministischer Browser-Pump für die geöffnete eBay-Adminseite.
     * Der Browser wartet auf genau einen echten Worker-Durchlauf und lädt danach
     * den Status neu. Damit ist ein manueller Lauf nicht mehr auf Loopback oder
     * WP-Cron als primären Transport angewiesen.
     */
    public function handle_ebay_admin_pump() {
        if (!current_user_can('manage_options')) { wp_send_json_error(array('message'=>'Keine Berechtigung.'), 403); }
        check_ajax_referer('ppar_ebay_admin_pump', 'nonce');
        $job = $this->ebay_sync_job_load();
        $refresh_job = $this->ebay_refresh_job_load();
        $result = false;
        $kind = 'idle';
        if ($this->ebay_sync_job_is_open($job)) {
            $kind = 'discovery';
            $result = $this->run_ebay_sync_worker(true);
        } elseif ($this->ebay_refresh_job_is_open($refresh_job)) {
            $kind = 'inventory_refresh';
            $result = $this->run_ebay_inventory_refresh_worker(true);
        }
        $job = $this->ebay_sync_job_load();
        $refresh_job = $this->ebay_refresh_job_load();
        wp_send_json_success(array(
            'kind'=>$kind,
            'worker_result'=>is_wp_error($result) ? 'error' : ($result === false ? 'locked_or_idle' : 'progressed'),
            'discovery_open'=>$this->ebay_sync_job_is_open($job),
            'refresh_open'=>$this->ebay_refresh_job_is_open($refresh_job),
            'discovery_progress'=>absint($job['progress_seq'] ?? 0),
            'refresh_progress'=>absint($refresh_job['progress_seq'] ?? 0),
        ));
    }

    /**
     * V5.20 – Fallback-Nudge für offene Hintergrundjobs außerhalb des Browser-Pumps. Die Seite darf
     * einen offenen Job nur dann sanft erneut anstoßen, wenn seit dem letzten
     * Worker deutlich länger als ein normales Paket vergangen ist. Der
     * Transient verhindert Anstoß-Spam durch den 8s-Reload.
     */
    private function ebay_admin_nudge_open_jobs(&$job, &$refresh_job) {
        $now = time();
        $nudge_key = 'ppar_ebay_admin_nudge_v519';
        if (function_exists('get_transient') && get_transient($nudge_key)) { return; }
        $did_nudge = false;
        if ($this->ebay_sync_job_is_open($job)) {
            $last = absint($job['last_worker_at'] ?? 0);
            $updated = absint($job['updated_at'] ?? 0);
            $age = $now - max($last, $updated);
            if ($age >= 20) {
                $this->ebay_dispatch_worker($job);
                $did_nudge = true;
            }
        } elseif ($this->ebay_refresh_job_is_open($refresh_job)) {
            $last = absint($refresh_job['last_worker_at'] ?? 0);
            $updated = absint($refresh_job['updated_at'] ?? 0);
            $age = $now - max($last, $updated);
            if ($age >= 20) {
                $this->ebay_refresh_dispatch_worker($refresh_job);
                $did_nudge = true;
            }
        }
        if ($did_nudge && function_exists('set_transient')) { set_transient($nudge_key, 1, 15); }
    }

    /**
     * V5.21 – Live-Recovery fuer bereits offene V5.18–V5.20-Jobs.
     * Ein alter offener Zustand wird beim Aufruf der eBay-Adminseite terminal
     * als PARTIAL geschlossen. Bereits gespeicherte Items/Listings/Creatives
     * bleiben erhalten; es wird nichts geloescht und kein neuer Abruf gestartet.
     */
    private function ebay_admin_bound_stale_jobs(&$job, &$refresh_job, $settings) {
        if ($this->ebay_sync_job_is_open($job) && $this->ebay_sync_segment_expired($job)) {
            $this->ebay_sync_finalize($job, $settings, 'partial', 'segment_time_budget');
            $job = $this->ebay_sync_job_load();
        }
        if ($this->ebay_refresh_job_is_open($refresh_job) && $this->ebay_refresh_segment_expired($refresh_job)) {
            if (!isset($refresh_job['summary']) || !is_array($refresh_job['summary'])) { $refresh_job['summary'] = array(); }
            $refresh_job['summary']['stopped_reason'] = 'segment_time_budget';
            $this->ebay_refresh_finalize($refresh_job, $settings, 'partial');
            $refresh_job = $this->ebay_refresh_job_load();
        }
    }

    public function render_ebay_page() {
        if (!current_user_can('manage_options')) { return; }
        $settings = $this->ebay_settings();
        $notice = sanitize_key((string) ($_GET['ppar_ebay'] ?? ''));
        $message = sanitize_text_field(rawurldecode((string) ($_GET['message'] ?? '')));
        $rules_json = wp_json_encode($settings['rules'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $test = is_array($settings['last_test'] ?? null) ? $settings['last_test'] : array();
        $sync = is_array($settings['last_sync'] ?? null) ? $settings['last_sync'] : array();
        $refresh = is_array($settings['last_refresh'] ?? null) ? $settings['last_refresh'] : array();
        $job = $this->ebay_sync_job_load();
        $refresh_job = $this->ebay_refresh_job_load();
        // Workflow V2: rendering the eBay admin page is read-only. Workers own
        // terminal state transitions; incompatible legacy jobs fail closed here.
        $job_open = $this->ebay_sync_job_is_open($job);
        $job_resumable = $this->ebay_sync_job_is_resumable_partial($job);
        $job_summary = is_array($job['summary'] ?? null) ? $job['summary'] : array();
        $refresh_open = $this->ebay_refresh_job_is_open($refresh_job);
        $refresh_summary = is_array($refresh_job['summary'] ?? null) ? $refresh_job['summary'] : array();
        $overall_running = $job_open || $refresh_open;
        // Automatische Bestandslaeufe sind bewusst vom manuellen Discovery-UI entkoppelt.
        // Nur Discovery oder ein explizit manuell gestarteter Refresh treiben den Browser-Pump.
        $pump_running = $job_open || ($refresh_open && !empty($refresh_job['manual']));
        ?>
        <div class="wrap ppar-ebay">
            <h1>eBay</h1>
            <p><strong>Runtime:</strong> <code><?php echo esc_html(self::VERSION); ?></code> · Build <code><?php echo esc_html(self::EBAY_RUNTIME_BUILD); ?></code></p>
            <p><strong>Provider-Fachseite.</strong> Zugangsdaten und OAuth-Test liegen zentral unter <a href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-networks')); ?>">Netzwerke &amp; API</a>. <?php echo $this->provider_control_badge('ebay'); ?> <a class="button button-small" href="<?php echo esc_url($this->provider_control_url('ebay')); ?>">Chefsteuerung &amp; Veto</a></p>
            <p><strong>Eingangsweiche:</strong> INDIVIDUAL → fachliche HivePress-Unterkategorien direkt unter „Private Anzeigen“ · BUSINESS → Werbemittelbibliothek und ausschließlich providerreine Produktzonen.</p>
            <?php if ($notice === 'saved') : ?><div class="notice notice-success inline"><p>Einstellungen gespeichert.</p></div><?php endif; ?>
            <?php if (in_array($notice, array('error','test_failed','sync_failed','refresh_failed','review_failed'), true)) : ?><div class="notice notice-error inline"><p><?php echo esc_html($message ?: 'Vorgang fehlgeschlagen.'); ?></p></div><?php endif; ?>
            <?php if (in_array($notice, array('sync_started','refresh_started'), true)) : ?><div class="notice notice-info inline"><p><?php echo esc_html($message ?: 'Hintergrundvorgang gestartet.'); ?></p></div><?php endif; ?>
            <?php if (in_array($notice, array('categories','catalog_passed','test_passed','sync_passed','review_saved'), true)) : ?><div class="notice notice-success inline"><p><?php echo esc_html($message ?: 'Vorgang abgeschlossen.'); ?></p></div><?php endif; ?>

            <section class="postbox" style="padding:18px;max-width:1180px">
                <h2>1. HivePress-Bereich einrichten</h2>
                <p>Erstellt beziehungsweise prüft <strong>Private Anzeigen</strong> und darunter direkt die acht fachlichen Unterkategorien. Die frühere sichtbare Provider-Ebene „eBay-Privatanzeigen“ wird automatisch und ohne Verlust der Listing-Zuordnungen entfernt.</p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="ppar_ebay_setup_categories">
                    <?php wp_nonce_field('ppar_ebay_setup_categories', 'ppar_ebay_nonce'); ?>
                    <button class="button button-secondary">Private-Anzeigen-Kategorien anlegen/prüfen</button>
                    <?php if (!empty($settings['private_root_term_id'])) : ?><span style="margin-left:10px">Private-Anzeigen-ID: <?php echo absint($settings['private_root_term_id']); ?></span><?php endif; ?>
                </form>
            </section>

            <section class="postbox" style="padding:18px;max-width:1180px">
                <h2>2. Portal- und Themenabgleich prüfen</h2>
                <p>Prüft den fest mitgelieferten vollständigen Pferde-Atelier-Zielkatalog: 8 Hauptbereiche, 59 Bereichsseiten, 329 Produktseiten und 1.124 WordPress-Kategorien. Ohne positiven Abgleich bleiben Provider-Fachtest und Abruf fail-closed.</p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="ppar_ebay_verify_catalog">
                    <?php wp_nonce_field('ppar_ebay_verify_catalog', 'ppar_ebay_nonce'); ?>
                    <button class="button button-secondary">Portal- und Themenabgleich prüfen</button>
                    <?php if (!empty($settings['catalog_verified_at'])) : ?><span style="margin-left:10px">Status: geprüft am <?php echo esc_html(wp_date('d.m.Y H:i', absint($settings['catalog_verified_at']))); ?></span><?php endif; ?>
                </form>
            </section>

            <section class="postbox" style="padding:18px;max-width:1180px">
                <h2>3. Betriebsprofil und automatische Abrufprofile</h2>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="ppar_ebay_save_settings">
                    <?php wp_nonce_field('ppar_ebay_save_settings', 'ppar_ebay_nonce'); ?>
                    <table class="form-table" role="presentation"><tbody>
                        <tr><th>Zentraler Zugang</th><td><?php echo !empty($settings['enabled']) ? '<strong>aktiviert</strong>' : '<strong>deaktiviert</strong>'; ?> · Umgebung: <strong><?php echo esc_html((string)$settings['environment']); ?></strong><p class="description">Client-ID, Client-Secret, EPN-Campaign-ID, Aktivierung und OAuth-Test werden ausschließlich unter <a href="<?php echo esc_url(admin_url('admin.php?page=affiliate-portal-networks')); ?>">Netzwerke &amp; API</a> verwaltet.</p></td></tr>
                        <tr><th>Liefer-PLZ</th><td><input class="small-text" name="ppar_ebay[delivery_postal_code]" value="<?php echo esc_attr((string) $settings['delivery_postal_code']); ?>"><p class="description">Optional für präzisere Versandinformationen.</p></td></tr>
                        <tr><th>Private Verkäufer</th><td><label><input type="checkbox" name="ppar_ebay[private_enabled]" value="1" <?php checked(!empty($settings['private_enabled'])); ?>> INDIVIDUAL abrufen</label><p class="description">Fachlich eindeutige Angebote werden als HivePress-Listings angelegt; weiche Unsicherheiten landen im Prüfbestand statt verworfen zu werden.</p></td></tr>
                        <tr><th>Automatische Veröffentlichung</th><td><label><input type="checkbox" name="ppar_ebay[private_auto_publish]" value="1" <?php checked(!empty($settings['private_auto_publish'])); ?>> Fachlich sichere INDIVIDUAL-Angebote direkt veröffentlichen</label><p class="description"><strong>Standard nach Update: aus.</strong> Bereits manuell veröffentlichte eBay-Listings bleiben bei späteren Abrufen veröffentlicht. Prüfbestand wird niemals automatisch veröffentlicht.</p></td></tr>
                        <tr><th>Zielbestand je Privatkategorie</th><td><input class="small-text" type="number" min="1" max="100" name="ppar_ebay[private_target_per_category]" value="<?php echo absint($settings['private_target_per_category']); ?>"> <span class="description">Standard 24. Automatisch veröffentlichte Neufunde füllen nur bis zu diesem Zielbestand auf.</span></td></tr>
                        <tr><th>Harte Obergrenze je Privatkategorie</th><td><input class="small-text" type="number" min="1" max="100" name="ppar_ebay[private_max_per_category]" value="<?php echo absint($settings['private_max_per_category']); ?>"> <span class="description">Standard 30. Bereits manuell veröffentlichte Altbestände werden durch das Update nicht rückwirkend deaktiviert; neue automatische Veröffentlichungen überschreiten die Grenze nie.</span></td></tr>
                        <tr><th>Bestandsabgleich</th><td><label><input type="checkbox" name="ppar_ebay[inventory_refresh_enabled]" value="1" <?php checked(!empty($settings['inventory_refresh_enabled'])); ?>> Vor Ablauf der 6-Stunden-Frist vorhandene eBay-Angebote gezielt per Browse <code>getItem</code> nachprüfen</label><p class="description">Unauffindbar/verkauft/beendet → Frontend aus. Temporärer API-Fehler → keine Löschung; der Datensatz bleibt intern erhalten und wird später erneut geprüft.</p></td></tr>
                        <tr><th>Bestandschecks je Lauf</th><td><input class="small-text" type="number" min="1200" max="2000" name="ppar_ebay[inventory_refresh_max_per_run]" value="<?php echo absint($settings['inventory_refresh_max_per_run']); ?>"><p class="description">Automatisch mindestens 1.200 Checks; der Bestandsabgleich läuft stündlich, Discovery weiterhin alle drei Stunden. Keine Änderung erforderlich.</p></td></tr>
                        <tr><th>Gewerbliche Verkäufer</th><td><label><input type="checkbox" name="ppar_ebay[business_enabled]" value="1" <?php checked(!empty($settings['business_enabled'])); ?>> BUSINESS als Produkt-Creatives übernehmen</label></td></tr>
                        <tr><th>Vertragsbestätigung</th><td><label><input type="checkbox" name="ppar_ebay[api_terms_confirmed]" value="1" <?php checked(!empty($settings['api_terms_confirmed'])); ?>> Aktuelle eBay-API-, Buy-API- und EPN-Verträge sind akzeptiert und das Portal ist als Anwendung/Media Property angegeben.</label></td></tr>
                        <tr><th>Datenschutz und Kennzeichnung</th><td><label><input type="checkbox" name="ppar_ebay[privacy_policy_confirmed]" value="1" <?php checked(!empty($settings['privacy_policy_confirmed'])); ?>> Datenschutzerklärung, Affiliate-Kennzeichnung und Löschpflichten sind umgesetzt.</label></td></tr>
                        <tr><th>Aktualitätsgrenze</th><td><strong>6 Stunden</strong><input type="hidden" name="ppar_ebay[stale_hours]" value="6"><p class="description">Fest erzwungen: öffentlich angezeigte eBay-Angebotsdaten dürfen höchstens sechs Stunden alt sein. Danach wird nur die öffentliche Ausgabe fail-closed ausgeblendet; der HivePress-Status bleibt unverändert. Erst ein bestätigtes eBay-Endsignal deaktiviert das Listing.</p></td></tr>
                        <tr><th>Treffer pro Seite</th><td><input class="small-text" type="number" min="1" max="50" name="ppar_ebay[max_per_rule]" value="<?php echo absint($settings['max_per_rule']); ?>"><p class="description">eBay Browse API: maximal 50 Treffer je Seite.</p></td></tr>
                        <tr><th>Max. Seiten je Abrufprofil</th><td><input class="small-text" type="number" min="1" max="20" name="ppar_ebay[max_pages_per_profile]" value="<?php echo absint($settings['max_pages_per_profile']); ?>"></td></tr>
                        <tr><th>Max. Requests je Lauf</th><td><input class="small-text" type="number" min="1" max="40" name="ppar_ebay[max_requests_per_run]" value="<?php echo absint($settings['max_requests_per_run']); ?>"><p class="description">Harte Discovery-Grenze. Maximal 40 Browse-Requests je Lauf; Bestandsprüfung läuft getrennt und priorisiert nur öffentlich relevante Ausgaben.</p></td></tr>
                        <tr><th>Zeitbudget je Hintergrundpaket</th><td><input class="small-text" type="number" min="10" max="30" name="ppar_ebay[run_time_budget_seconds]" value="<?php echo absint($settings['run_time_budget_seconds']); ?>"> Sekunden<p class="description">Der Gesamtlauf hat kein synchrones Browser-Zeitlimit mehr. Dieses Budget begrenzt nur ein einzelnes fortsetzbares Arbeitspaket.</p></td></tr>
                        <tr><th>Automatische Abrufprofile</th><td><textarea rows="28" class="large-text code" readonly><?php echo esc_textarea((string) $rules_json); ?></textarea><p class="description">Nur lesbar. Die fachliche Annahme und Zielzuordnung erfolgt automatisch gegen den vollständigen Pferde-Atelier-Zielkatalog; Suchbegriffe allein reichen niemals zur Freigabe.</p></td></tr>
                    </tbody></table>
                    <?php submit_button('eBay-Betriebsprofil speichern'); ?>
                </form>
            </section>

            <section class="postbox" style="padding:18px;max-width:1180px">
                <h2>4. Provider-Fachtest und Abruf</h2>
                <p>Der reine OAuth-Zugangstest liegt zentral unter „Netzwerke &amp; API“. Dieser Fachtest prüft zusätzlich EBAY_DE, itemAffiliateWebUrl, die Verkäuferkontotypen INDIVIDUAL/BUSINESS und den Portalfilter. Der vollständige Abruf folgt eBays Pagination über <code>next</code> und läuft seit V5.6.0 ausschließlich als fortsetzbarer Hintergrundjob; der Admin-Klick wartet nicht mehr auf den Gesamtlauf.</p>
                <div style="display:flex;gap:10px;flex-wrap:wrap">
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="ppar_ebay_test_connection"><?php wp_nonce_field('ppar_ebay_test_connection', 'ppar_ebay_nonce'); ?><button class="button button-secondary">Provider-Fachtest starten</button></form>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="ppar_ebay_run_sync"><?php wp_nonce_field('ppar_ebay_run_sync', 'ppar_ebay_nonce'); ?><button class="button button-primary" <?php disabled($job_open || $refresh_open); ?>><?php echo $job_open ? 'eBay-Abruf läuft …' : ($refresh_open ? 'Bestandsabgleich läuft …' : ($job_resumable ? 'eBay-Abruf fortsetzen' : 'Vollständigen eBay-Abruf starten')); ?></button></form>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="ppar_ebay_run_refresh"><?php wp_nonce_field('ppar_ebay_run_refresh', 'ppar_ebay_nonce'); ?><button class="button button-secondary" <?php disabled($refresh_open || $job_open || empty($settings['inventory_refresh_enabled'])); ?>><?php echo $refresh_open ? 'Bestandsabgleich läuft …' : 'Bestand jetzt abgleichen'; ?></button></form>
                    <?php if ($job_open) : ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="ppar_ebay_worker_now"><?php wp_nonce_field('ppar_ebay_worker_now', 'ppar_ebay_nonce'); ?><button class="button button-secondary">Arbeitspaket jetzt anstoßen</button></form><?php endif; ?>
                </div>
                <p class="description"><strong>Bestand jetzt abgleichen</strong> ist ein kompletter Reconcile-Lauf: zuerst lokale Policy/Klassifikation und bestehende PRIVATE/BUSINESS-Ausgaben auf den aktuellen Workflow-Vertrag bringen, danach ausschließlich fällige eBay-Angebote per <code>getItem</code> prüfen. <strong>Discovery wird dabei nicht gestartet.</strong></p>
                <?php if ($job_resumable && !$job_open && !$refresh_open) : ?>
                    <p><strong>Discovery:</strong> Zeitsegment sauber beendet. Alle bereits verarbeiteten Ergebnisse sind gespeichert. Mit <em>eBay-Abruf fortsetzen</em> wird exakt am gespeicherten Cursor weitergearbeitet.</p>
                <?php endif; ?>
                <?php if ($job_open) : ?>
                    <p><strong>Gesamtvorgang:</strong> Discovery läuft. Die Seite aktualisiert nur den Status; sie startet keinen zweiten Abruf.</p>
                <?php elseif ($refresh_open) : ?>
                    <p><strong>Discovery:</strong> beendet. <strong>Separater Bestandsabgleich:</strong> läuft unabhängig im Hintergrund.</p>
                <?php elseif ($sync || $refresh) : ?>
                    <p><strong>Gesamtvorgang:</strong> abgeschlossen. Es ist kein eBay-Hintergrundjob mehr offen.</p>
                <?php endif; ?>
                <?php if ($job_open) : ?>
                    <p><strong>Hintergrundlauf:</strong> läuft · Phase <code><?php echo esc_html((string)($job['worker_phase'] ?? '')); ?></code> · Requests <?php echo absint($job_summary['requests'] ?? 0); ?>/<?php echo absint($settings['max_requests_per_run']); ?> · Seiten <?php echo absint($job_summary['pages'] ?? 0); ?> · gefunden <?php echo absint($job_summary['received'] ?? 0); ?> · fachlich sicher <?php echo absint($job_summary['accepted'] ?? 0); ?> · Prüfbestand <?php echo absint($job_summary['review_pending'] ?? 0); ?>. <span class="description">Letztes Arbeitspaket: <?php echo !empty($job['last_worker_at']) ? esc_html(wp_date('d.m.Y H:i:s', absint($job['last_worker_at']))) : 'noch nicht gestartet'; ?></span></p>
                <?php endif; ?>
                <?php if ($refresh_open) : $refresh_maint = is_array($refresh_summary['maintenance'] ?? null) ? $refresh_summary['maintenance'] : array(); $refresh_phase = sanitize_key((string)($refresh_summary['phase'] ?? 'source_refresh')); ?>
                    <p><strong>Bestandsabgleich:</strong> läuft · Phase <strong><?php echo $refresh_phase === 'local_reconciliation' ? 'lokaler Workflow-Abgleich' : 'eBay-Bestandsprüfung'; ?></strong> · lokal <?php echo absint($refresh_maint['scanned'] ?? 0); ?> geprüft / <?php echo absint($refresh_maint['ready_private'] ?? 0); ?> PRIVATE / <?php echo absint($refresh_maint['ready_business'] ?? 0); ?> BUSINESS · eBay <?php echo absint($refresh_summary['checked'] ?? 0); ?> geprüft / <?php echo absint($refresh_summary['available'] ?? 0); ?> aktiv / <?php echo absint($refresh_summary['ended'] ?? 0); ?> beendet · technische Fehler <?php echo absint($refresh_summary['technical_errors'] ?? 0); ?>. <span class="description">Letztes Arbeitspaket: <?php echo !empty($refresh_job['last_worker_at']) ? esc_html(wp_date('d.m.Y H:i:s', absint($refresh_job['last_worker_at']))) : 'noch nicht gestartet'; ?></span></p>
                <?php endif; ?>
                <?php if ($pump_running) : ?>
                    <p class="description"><strong>Aktiver Lauf:</strong> Diese Seite treibt den offenen manuellen Job direkt weiter; automatische Bestandslaeufe bleiben davon getrennt.</p>
                    <script>
                    (function(){
                        var body = new URLSearchParams();
                        body.append('action','ppar_ebay_admin_pump');
                        body.append('nonce','<?php echo esc_js(wp_create_nonce('ppar_ebay_admin_pump')); ?>');
                        window.setTimeout(function(){
                            fetch(ajaxurl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:body.toString()})
                                .catch(function(){ return null; })
                                .finally(function(){ window.setTimeout(function(){ window.location.reload(); }, 750); });
                        }, 350);
                    })();
                    </script>
                <?php endif; ?>
                <?php if ($refresh) : $last_maint = is_array($refresh['maintenance'] ?? null) ? $refresh['maintenance'] : array(); ?>
                    <p><strong>Letzter Bestandsabgleich:</strong> <?php echo esc_html((string)($refresh['status'] ?? 'unbekannt')); ?> · lokaler Workflow <?php echo absint($last_maint['scanned'] ?? 0); ?> geprüft / <?php echo absint($last_maint['ready_private'] ?? 0); ?> PRIVATE bereit / <?php echo absint($last_maint['ready_business'] ?? 0); ?> BUSINESS bereit / <?php echo absint($last_maint['review'] ?? 0); ?> Review / <?php echo absint($last_maint['blocked'] ?? 0); ?> blockiert · eBay <?php echo absint($refresh['checked'] ?? 0); ?> geprüft / <?php echo absint($refresh['available'] ?? 0); ?> aktiv / <?php echo absint($refresh['ended'] ?? 0); ?> beendet / <?php echo absint($refresh['technical_errors'] ?? 0); ?> technische Fehler.</p>
                    <details><summary>Technische Details zum Bestandsabgleich</summary><pre style="white-space:pre-wrap"><?php echo esc_html(wp_json_encode($refresh, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?></pre></details>
                <?php else : ?><p><strong>Letzter Bestandsabgleich:</strong> noch nicht durchgeführt.</p><?php endif; ?>
                <p><strong>Letzter Provider-Fachtest:</strong> <?php echo $test ? esc_html((string)($test['status'] ?? 'unbekannt') . (!empty($test['tested_at']) ? ' · ' . wp_date('d.m.Y H:i:s', absint($test['tested_at'])) : '')) : 'noch nicht durchgeführt'; ?></p>
                <?php if ($test) : ?><details><summary>Technische Details zum Provider-Fachtest</summary><pre style="white-space:pre-wrap"><?php echo esc_html(wp_json_encode($test, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?></pre></details><?php endif; ?>
                <?php $sync_is_legacy = $sync && ((string)($sync['engine'] ?? '') !== 'resumable-background' || (string)($sync['build'] ?? '') === ''); ?>
                <?php if ($sync_is_legacy) : ?><div class="notice notice-warning inline"><p><strong>Historischer Legacy-Abruf.</strong> Diese Laufbilanz stammt nicht aus der fortsetzbaren Hintergrundengine dieses Builds und darf nicht als vollständiger aktueller Hintergrundabruf gewertet werden.</p></div><?php endif; ?>
                <p><strong>Letzter Abruf:</strong> <?php echo $sync ? esc_html((string)($sync['status'] ?? 'unbekannt') . ' · gefunden ' . absint($sync['received'] ?? 0) . ' · fachlich sicher ' . absint($sync['accepted'] ?? 0) . ' · Review ' . absint($sync['review_pending'] ?? 0) . ' · blockiert ' . (absint($sync['hard_blocked'] ?? 0) + absint($sync['technical_blocked'] ?? 0))) : 'noch nicht durchgeführt'; ?></p>
                <?php if ($sync) : ?><details><summary>Technische Details zum eBay-Abruf</summary><pre style="white-space:pre-wrap"><?php echo esc_html(wp_json_encode($sync, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?></pre></details><?php endif; ?>
                <?php if ($sync) : ?>
                    <p><strong>Lesbare Laufbilanz:</strong>
                        gefunden <?php echo absint($sync['received'] ?? 0); ?>
                        (<?php echo absint($sync['received_unique'] ?? 0); ?> eindeutig)
                        → technisch gültig <?php echo absint($sync['technically_valid'] ?? 0); ?>
                        → fachlich sicher <?php echo absint($sync['accepted'] ?? 0); ?>
                        → Prüfbestand <?php echo absint($sync['review_pending'] ?? 0); ?>
                        → hart blockiert <?php echo absint($sync['hard_blocked'] ?? 0); ?>
                        → technisch blockiert <?php echo absint($sync['technical_blocked'] ?? 0); ?>
                        → manuell gesperrt <?php echo absint($sync['manual_vetoed'] ?? 0); ?>.
                    </p>
                    <details><summary>Block- und Prüfgründe</summary><pre style="white-space:pre-wrap"><?php echo esc_html(wp_json_encode(array(
                        'hard'=>(array)($sync['hard_reasons'] ?? array()),
                        'review'=>(array)($sync['review_reasons'] ?? array()),
                        'technical'=>(array)($sync['technical_reasons'] ?? array()),
                        'manual_veto'=>(array)($sync['manual_veto_reasons'] ?? array()),
                    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); ?></pre></details>
                <?php endif; ?>
            </section>

            <?php $review_candidates = $this->ebay_review_candidates(100); $review_targets = $this->ebay_private_review_targets($settings); ?>
            <section class="postbox" style="padding:18px;max-width:1180px">
                <h2>5. eBay-Prüfbestand / Chef-Veto</h2>
                <p>Nur <strong>weiche fachliche Unsicherheiten</strong> erscheinen hier. Hard-Safety-, Provider-, Affiliate-, Ablauf- und technische Sperren bleiben nicht übersteuerbar. Ein Kandidat muss innerhalb der Sechs-Stunden-Frist entschieden werden.</p>
                <?php if (!$review_candidates) : ?>
                    <p><em>Kein offener Prüfkandidat.</em></p>
                <?php else : ?>
                    <table class="widefat striped"><thead><tr><th>Angebot</th><th>Typ</th><th>Prüfgrund</th><th>Chefentscheidung</th></tr></thead><tbody>
                    <?php foreach ($review_candidates as $candidate) : ?>
                        <tr>
                            <td><strong><?php echo esc_html((string)($candidate['title'] ?? '')); ?></strong><br><small>Item-ID <?php echo esc_html((string)($candidate['item_id'] ?? '')); ?> · <?php echo esc_html((string)($candidate['seller_username'] ?? '')); ?></small></td>
                            <td><?php echo esc_html((string)($candidate['seller_account_type'] ?? '')); ?></td>
                            <td><?php echo esc_html((string)($candidate['rejection_reason'] ?? '')); ?></td>
                            <td>
                            <?php if (strtoupper((string)($candidate['seller_account_type'] ?? '')) === 'INDIVIDUAL') : ?>
                                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:grid;gap:6px;min-width:320px">
                                    <input type="hidden" name="action" value="ppar_ebay_review_decision">
                                    <input type="hidden" name="row_id" value="<?php echo absint($candidate['id'] ?? 0); ?>">
                                    <?php wp_nonce_field('ppar_ebay_review_decision', 'ppar_ebay_nonce'); ?>
                                    <select name="target_term_id" required>
                                        <option value="">HivePress-Ziel wählen</option>
                                        <?php foreach ($review_targets as $target) : ?><option value="<?php echo absint($target->term_id ?? 0); ?>"><?php echo esc_html((string)($target->name ?? '')); ?></option><?php endforeach; ?>
                                    </select>
                                    <input type="text" name="reason" required maxlength="240" placeholder="Begründung der Chefentscheidung">
                                    <div style="display:flex;gap:6px;flex-wrap:wrap">
                                        <button class="button button-primary" name="review_decision" value="approve">Freigeben</button>
                                        <button class="button" name="review_decision" value="veto" formnovalidate onclick="this.form.querySelector('select[name=target_term_id]').removeAttribute('required');">Veto</button>
                                    </div>
                                </form>
                            <?php else : ?>
                                <em>BUSINESS-Prüfkandidat bleibt fail-closed; Freigabe über die Werbemittel-/Chefsteuerung wird nicht automatisch vorweggenommen.</em>
                            <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody></table>
                <?php endif; ?>
            </section>
        </div>
        <?php
    }
}
