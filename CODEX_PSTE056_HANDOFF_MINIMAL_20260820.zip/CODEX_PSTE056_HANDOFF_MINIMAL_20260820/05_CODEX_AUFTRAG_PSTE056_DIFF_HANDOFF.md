# CODEX-AUFTRAG – PSTE PERSISTED EXTENSION ROOTFIX / KLEINE TEXTÜBERGABE

## Ziel
Den bereits identifizierten Persistenzfehler sauber bis zu einem belastbaren lokalen PSTE-Stand reparieren und beweisen. Keine neue Architektur, keine Nebenbaustellen, keine Textmaschinenänderung.

## Verbindliche Inputs
- `01_BASELINE/portal-seo-topic-engine_0.55.0_SIGNED_ADDITIVE_ARTICLE_TYPE_ROOTFIX_FINAL.zip` = unveränderter Ausgangsstand.
- `02_CANDIDATE/class-pste-repository.php` = bereits von Codex erarbeiteter Kandidat für den Persistenz-Rootfix; nicht blind übernehmen, sondern gegen Baseline, Master und Realbestand prüfen.
- `03_LIVE_EVIDENCE/pste-global-seo-topic-map-20260820-115025-utc.json` = echter 562er Liveexport.
- `03_LIVE_EVIDENCE/seo-redaktionsplan-metadaten-snapshot-4eb300f7c33acf0279b94d992db4413b48cb60effe5c6531fd848b4202effd06.json` = echter PSERC-Livebefund.
- `04_MASTER_BINDING/*` = bindend.

## Bekannte Root Cause, die zu beweisen ist
Der Read-Model-Pfad `applyPoolRowWithRelations()` darf persistierte `AUTO_RESOLVED`-/`planning_suitability=YES`-Spalten nicht als Release-Autorität behandeln, wenn der aktuelle signierte Extension-Vertrag nicht mehr gültig ist.
Legacy `PSTE_JOURNAL_ROUTER_V1` bzw. `FALLBACK_ONLY_AFTER_EXISTING_PRODUCT_FAMILY_MISS` dürfen unter dem aktuellen Generic-Extension-Vertrag niemals erneut PASS/READY autorisieren.

## Zulässiger Produktions-Scope
So klein wie möglich. Erwarteter Scope ist ausschließlich PSTE.
Wenn möglich nur:
1. `includes/class-pste-repository.php`
2. `includes/class-pste-editorializer.php` nur für den notwendigen Ruleset-/Revalidation-Fingerprint
3. `portal-seo-topic-engine.php` nur für den Versionssprung

PSERC 0.27.0 und PPM 6.7.9 dürfen nicht geändert werden.
Weitere Produktionsdateien nur, wenn technisch zwingend bewiesen; dann NICHT improvisieren, sondern `BLOCKED_EXTRA_FILE_REQUIRED:<pfad>:<grund>` ausgeben.

## Pflichtprüfung
1. Baseline 0.55.0 frisch entpacken.
2. Kandidatenpatch forensisch gegen Baseline diffen.
3. Den echten PHP-Pfad testen, nicht die gewünschte Transformation in Python nachbauen. Der Test muss den produktiven `applyPoolRowWithRelations()`/`revalidatePersistedExtensionState()`-Pfad tatsächlich ausführen. Reflection/Stubs für WordPress-Laufzeit sind erlaubt; die Produktionsfunktion selbst darf nicht nachimplementiert werden.
4. Echter 562er Bestand:
   - 562 total
   - 55 Legacy-Journalzustände reproduzierbar
   - exakt 2 signierte Goldfälle bleiben nach echter PHP-Revalidierung Journal-PASS
   - 53 alte Journalfälle fail-closed
   - Nicht-Journal-Kandidaten dürfen durch den Patch keine fachliche Änderung erhalten
5. Manual-/persistierter PASS darf ungültigen Extension-Vertrag nicht umgehen.
6. Der V13-Altbestand muss durch einen eng begrenzten neuen Ruleset-/Revalidation-Fingerprint zuverlässig als revalidierungsbedürftig erkannt werden; vorhandene bounded/resumable Migration verwenden, keinen globalen neuen Rebuild erfinden.
7. PHP-Lint aller PSTE-Dateien.
8. JSON-Parse aller PSTE-JSONs.
9. Source -> Build -> Fresh-Unpack byteidentisch.
10. Keine neuen verbotenen WordPress-Write-Callsites.
11. Keine Änderungen an Text, Titeln, Kategorien, Core-Typentscheidungen, Prompts, Design, Publishlogik.

## Entscheidende Ausgaberegel – KEINE DATEI ZUM DOWNLOAD
Am Ende keine ZIP, keinen Artifact-Link und keine Liste von hunderten Dateien erzeugen.
Stattdessen ausschließlich EINEN kompakten Textblock ausgeben, der direkt in einen anderen Chat kopiert werden kann:

### A) STATUS
`PASS` oder `BLOCKED:<exakter Grund>`

### B) CHANGED_PRODUCTION_FILES
Exakte Liste der geänderten Produktionsdateien. Erwartet maximal 3.

### C) UNIFIED_DIFF
Ein vollständiger `diff -u` / git-unified-diff gegen die unveränderte 0.55.0-Baseline, aber NUR für die tatsächlich geänderten Produktionsdateien. Keine unveränderten Dateien. Kein Binary-Dump.

### D) TEST_RESULTS
Nur die kompakten Ergebniszeilen der Pflichtprüfungen, insbesondere echter PHP-562er-Lauf mit Zählwerten.

### E) EXPECTED_BUILD
Gewünschter finaler Plugin-Ordnername, Version und SHA-256 eines lokal von Codex gebauten Testinstallers, falls PASS. Der Installer selbst muss NICHT übertragen werden.

Der UNIFIED_DIFF ist die Übergabe. Er muss vollständig genug sein, damit ein anderer Chat aus der vorhandenen 0.55.0-Baseline exakt denselben Stand rekonstruieren kann.

Keine Zwischenmeldung. Keine zusätzlichen Erklärtexte. Kein neuer Lösungsweg.
