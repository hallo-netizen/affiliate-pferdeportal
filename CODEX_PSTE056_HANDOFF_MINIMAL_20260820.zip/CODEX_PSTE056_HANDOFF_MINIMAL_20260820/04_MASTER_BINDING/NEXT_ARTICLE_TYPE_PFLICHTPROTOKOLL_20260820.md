# NEXT ARTICLE TYPE – VERBINDLICHES PFLICHTPROTOKOLL

Dieses Protokoll ist vor jeder neuen Beitragsart abzuarbeiten. Kein Schritt ist optional.

## A. Vor dem ersten Code

1. Aktuellen Master vollständig lesen.
2. Master-Soll-/Ist-Matrix für die neue Beitragsart erstellen.
3. Prüfen, ob die neue Beitragsart ausschließlich über `ARTICLE_TYPE_EXTENSION_MANIFEST_V1` + bereits vorhandene Capabilities integrierbar ist.
4. Prüfen, dass kein bestehender Core-Typ, keine bestehende Kategorieentscheidung, kein bestehender Titelpfad und kein bestehender Fallback verändert werden muss.
5. Prüfen, dass kein Family-/Type-/Category-Miss als positive Evidenz benutzt wird.
6. Prüfen, dass Evidence Producer, Verifier und Release Authority getrennt bleiben.
7. Wenn einer dieser Punkte nicht eindeutig PASS ist: **BLOCKED vor Code**.

## B. Zulässige Implementierung

Die neue Beitragsart besteht technisch nur aus:

1. deklarativem Extension-Manifest-Eintrag,
2. Signatur mit bestehendem autorisierten Trust Root,
3. Bindung an bestehende Capabilities,
4. typbezogenen Positiv-/Negativfixtures,
5. optionalen Extension-only Validatoren, wenn der Master sie ausdrücklich verlangt und bestehende Core-Pfade dadurch nachweislich unverändert bleiben.

Verboten:

- neue Typnamen-Switches in mehreren Kernen,
- Änderung bestehender Core-Fallbacks,
- eigener paralleler Textmaschinenpfad,
- selbst erzeugter Intent als eigener Beweis,
- manueller PASS/Override,
- globale Registry-/Sandbox-/Context-Invalidierung durch `+1` Extension.

## C. Pflicht-Tests vor Build

1. Positivfälle der neuen Beitragsart.
2. False-Positive-Negativfälle aus realen Rohqueries.
3. fehlender Scope.
4. fehlender Intent.
5. widersprüchlicher Scope/Intent.
6. self-authority evidence -> BLOCK.
7. Titelregel-Negativfälle.
8. Phrasenwiederholungs-Negativfall, falls Capability aktiv.
9. bestehende Core-Typen Golden-Master/Output-Parität.
10. synthetischer `+1 Extension`-Test: Legacy Article-Type-Registry unverändert; Family-Identity unverändert; nur Extension-Fingerprint darf ändern.
11. PPM vollständige aktive Testsuite.
12. PSERC Paket-/Produktionsreader-Integrität.
13. verbotene Write-Callsite-Diffprüfung.
14. realer Vollbestand.

## D. Build-Sperre

Kein Installer, solange Source nicht vollständig PASS ist.

## E. Fresh-Unpack

1. Installer bauen.
2. ZIP-Test.
3. frisch entpacken.
4. Source-vs-Fresh Hashparität.
5. PHP-Lint + JSON-Parse erneut.
6. alle typbezogenen Positiv-/Negativtests erneut.
7. synthetischer `+1`-Test erneut.
8. vollständige PPM-Suite erneut.
9. PSERC/PSTE relevante Regression erneut.
10. Signaturen erneut verifizieren.

Erst danach: `LOCAL PASS`.

## F. Live

1. Nur die final geprüften Installer installieren.
2. Keine parallelen manuellen Workflow-Umgehungen.
3. Redaktionsplan/Read-only-Schritte entsprechend bestehendem Workflow.
4. Erster Live-E2E nur mit bereits gebundenen Gold-/Pilotfällen.
5. Exact Five -> Supervisor -> PPM -> WordPress Draft -> Readback.
6. Erst nach Readback: `LIVE E2E PASS`.

## G. Dokumentationspflicht

Jede neue Beitragsart ergänzt im Master:

- Soll-/Ist-Matrix vor Code,
- geänderte Dateien,
- Positiv-/Negativmatrix,
- `+1`-Isolationstest,
- Source-QA,
- Fresh-Unpack-QA,
- Signatur-/Hashmanifest,
- Live-E2E-Evidenz,
- Fehlerkatalog, falls ein Gate blockiert oder ein Fehlversuch auftritt.
