# LÜCKENLOSE FEHLERKETTE – JOURNAL / NEUE BEITRAGSART / REDAKTIONSPLAN

Stand: 2026-08-20  
Status nach Reparaturblock: **LOCAL SOURCE + FRESH-UNPACK PASS; LIVE E2E NOCH AUSSTEHEND**

## Zweck

Dieses Dokument ist die verbindliche Fehler- und Ursachenbasis für jede künftige neue Beitragsart. Es dokumentiert nicht nur einzelne Symptome, sondern die komplette Kette von der ersten Architekturverletzung bis zum falschen READY/PASS im Redaktionsplan.

## Nullpunkt vor Journal

Vor der Journal-Erweiterung arbeiteten die bestehenden Beitragsarten und der normale Produktionsworkflow stabil. Die bestehenden fachlichen Entscheidungen für FAQ, Beratung, Vergleich, Pflege und weitere Core-Typen waren fest verdrahtet, getestet und Bestandteil des geschützten Textmaschinen-/Workflowstands. Die Masterregeln verlangten bereits, neue Beitragsarten **additiv, zentral, signiert und ohne Veränderung bestehender Entscheidungswege** anzubinden.

## Fehler 1 – Masterregel wurde vor der Implementierung nicht als Build-Sperre behandelt

Die Masterdatei enthielt bereits die Zielarchitektur einer zentralen, signierten, versionierten Beitragsart-Schnittstelle. Trotzdem wurde Journal zunächst an mehreren Stellen direkt in PSTE, PSERC und PPM integriert.

**Ursache:** Die Masterdatei wurde als Referenz benutzt, aber nicht als Pre-Code-Compliance-Gate. Es fehlte der zwingende Schritt: `Master-Soll -> geplanter Code -> Widerspruch? -> BLOCKED vor erster Änderung`.

**Folge:** Eine Architektur, die laut Master nicht hätte gebaut werden dürfen, konnte überhaupt entstehen.

## Fehler 2 – Journal wurde cross-core hart verdrahtet

Journal erhielt Sonderpfade in mehreren Kernkomponenten statt einer einzigen deklarativen Erweiterungsregistrierung. Dadurch mussten PSTE, PSERC und PPM denselben Typ mehrfach kennen und teilweise eigene Journal-Sonderlogik halten.

**Folge:** Jede Änderung am neuen Typ berührte mehrere Verträge, Registries, Hashes und Planungs-/Produktionspfade. Der neue Typ war nicht sauber gekapselt.

## Fehler 3 – Family-Miss wurde zum Einstieg in Journal

Der Journal-Router wurde nach einem normalen Family-Miss aufgerufen. Ein fehlender Core-Familientreffer konnte damit praktisch zum Startsignal für die neue Beitragsart werden.

**Vertragsverletzung:** Eine neue Beitragsart darf niemals dadurch aktiviert werden, dass eine bestehende Zuordnung fehlschlägt.

**Folge:** Allgemeine Pferdebegriffe, Hauptcontent-Themen und fachlich ungeeignete Suchphrasen konnten in den Journal-Pfad geraten.

## Fehler 4 – Router erzeugte seine eigene Journal-Evidenz

Der Router konnte nach seiner eigenen Journal-Entscheidung ein Journal-Intent-Signal wie `journal_explanatory` erzeugen und dieses downstream als Beleg weiterreichen.

**Ursache:** Evidence Producer und Evidence Verifier waren nicht sauber getrennt.

**Folge:** Die Regel `EXPLICIT_JOURNAL_SCOPE_AND_INTENT_ONLY` war formal vorhanden, technisch aber zirkulär beweisbar.

## Fehler 5 – Parallele Prüfungen waren nicht wirklich unabhängig

Technische und redaktionelle Prüfstränge waren vorhanden. Beide konnten jedoch dieselbe falsche upstream erzeugte Journal-Annahme übernehmen.

**Ursache:** Parallele Ausführung wurde mit unabhängiger Evidenz verwechselt.

**Folge:** Zwei Prüfstränge konnten denselben falschen Grundzustand bestätigen. Dadurch entstand ein falscher Gesamt-PASS, obwohl kein unabhängiger Journal-Scope/-Intent bewiesen war.

## Fehler 6 – Journal umging die normale Titelkomposition

Im Journal-Zweig konnte eine Suchphrase bzw. Keywordoberfläche direkt in eine Titeloberfläche überführt werden. Der normale redaktionelle Titelpfad wurde damit abgeschwächt bzw. umgangen.

**Sichtbare Folgen:**

- `Tierarzt praxis eckard bauer fahrpraxis Pferde großtiere`
- `Fahrbare weidehütte für Pferde`
- weitere rohe Suchphrasen konnten zu weit gelangen.

**Ursache:** Journal wurde als Sonderfall statt als Verbraucher bestehender Titelqualitätsregeln implementiert.

## Fehler 7 – Journal-spezifische Ausnahmen schwächten Titelprüfungen

Einige bestehende Keyword-/Stakkato-Prüfungen waren auf Journal nicht gleich wirksam. Gleichzeitig bestand keine zusätzliche harte Sperre gegen mehrgliedrige rohe Keywordketten ohne natürliche deutsche Satzoberfläche.

**Folge:** Ein Titel konnte technisch kompatibel wirken, obwohl er redaktionell offensichtlich unbrauchbar war.

## Fehler 8 – Phrasenwiederholung wurde für Journal nicht hart gegen den Planbestand geprüft

Die bestehende Regel gegen wiederkehrende Titelschablonen war im neuen Journal-Pfad nicht als eigener fail-closed Planbestands-Veto umgesetzt.

**Folge:** Eine neue Beitragsart hätte serielle Titelmuster erzeugen können, obwohl genau diese Wiederholung bereits als unerwünscht definiert war.

## Fehler 9 – Journal wurde zum Auffangbecken für Themen des Hauptcontents

Weil der Journal-Pfad an einen Core-Miss gekoppelt war und selbst Intent erzeugen konnte, wurde die bereits definierte Trennung `Journal` versus `großer regulärer Contentbereich` technisch unterlaufen.

**Folge:** Themen, die fachlich in den Hauptcontent gehören, konnten als Journal erscheinen.

## Fehler 10 – Off-topic-/Marken-/Freizeitphrasen hatten kein eigenständiges hartes Zulassungsveto vor Journal

Beispiele wie `Bibi und Tina Pferde` oder `Ausmalbilder kostenlos Pferde` enthielten das Familienwort Pferde und konnten dadurch zu weit in die Verarbeitung gelangen.

**Wichtig:** Die neue Architektur löst dies nicht durch frei erfundene Markenlisten. Sie löst die eigentliche Ursache: Ohne **positiv und unabhängig bewiesenen** Extension-Scope + Extension-Intent ist Journal `NOT_APPLICABLE`. Damit werden solche Begriffe nicht allein wegen `Pferde` Journal.

## Fehler 11 – Beitragsart-Hashing und fachlich unabhängige Bestände waren zu stark gekoppelt

Änderungen an Beitragsart-/Registry-Strukturen beeinflussten gemeinsame Prüfsummen und Abhängigkeiten. Dadurch konnten fachlich unabhängige Context-/Sandbox-/Planbestände als veraltet erscheinen.

**Folge:** Eine kleine neue Beitragsart löste unnötige breite Neuberechnungen aus.

## Fehler 12 – Sandbox-/Context-Neuberechnungen trafen große reale Bestände

Durch die globale Kopplung wurden hunderte reale Records erneut geprüft. Der relevante Livebestand lag bei 562 Themen und 549 Sandbox-Records.

**Folge:** Die neue Beitragsart verursachte nicht nur fachliche Fehlentscheidungen, sondern eskalierte auch die technische Last.

## Fehler 13 – Redaktionsplan kompilierte große Bestände ursprünglich synchron

Der Redaktionsplan führte zu viel Arbeit innerhalb eines einzelnen Requests aus. Nach den globalen Invalidierungen mussten große Mengen synchron gelesen, geprüft, zugeordnet und materialisiert werden.

**Folge:** HTTP-500-/Gateway-/Invalid-JSON-Fehler und wiederholte Timeouts, insbesondere bei Sandbox-/Binding-Phasen.

## Fehler 14 – erste Reparaturen behandelten Symptome statt Gesamtursache

Mehrere Zwischenstände reduzierten Batchgrößen, einzelne Requests oder sichtbare Fehler. Die Grundkopplung aus Beitragsart-Hartverdrahtung, falscher Journal-Autorität, globalen Hash-Abhängigkeiten und synchronem Planaufbau blieb zeitweise bestehen.

**Folge:** Ein Symptom verschwand, anschließend trat derselbe Fehler an einer anderen Stelle wieder auf.

## Fehler 15 – Infrastruktur-Rootfix schützte fehlerhafte Fachlogik mit

PSTE 0.54.0 / PSERC 0.26.0 reparierten den request-bounded/resumable Redaktionsplan und wurden bewusst so gebaut, dass geschützte Titel-/Routing-/Produktionslogik unverändert blieb.

**Problem:** `unverändert` wurde faktisch als ausreichender Beweis für `korrekt` behandelt. Die bereits falsche Journal-Fachlogik wurde gegen Änderung abgesichert, statt zuerst gegen den Mastervertrag geprüft zu werden.

**Folge:** Umfangreiche technische PASS-Berichte konnten korrekt sein, während die fachliche Journal-Zulassung weiterhin falsch war.

## Fehler 16 – Negativmatrix traf die später sichtbaren Fehlklassen nicht vollständig

Frühere Negativtests prüften unter anderem andere Tierarten, Kaufen/Vergleichen/Pflegen-Signale und bekannte Pilotfälle. Es fehlten aber harte Realfälle wie:

- `Ausmalbilder kostenlos Pferde`
- `Bibi und Tina Pferde`
- Firmen-/Personen-/Praxisphrasen
- `Tierarzt praxis eckard bauer fahrpraxis Pferde großtiere`
- regulärer Hauptcontent gegen Journal
- Weide-/Haltungsthemen gegen Journal
- rohe Keyword-Stakkato-Titel
- wiederholte Titelphrasenfamilien.

**Folge:** Die Tests konnten die implementierte Logik bestätigen, ohne die entscheidenden False-Positive-Klassen abzudecken.

## Fehler 17 – Live-Redaktionsplan machte den fachlichen Defekt sichtbar

Nach dem Infrastruktur-Rootfix lief der Redaktionsplan wieder bis zur fertigen Vorschau. Dort wurden falsche Kategorien/Artikeltypen und unbrauchbare Titel sichtbar. Unter anderem erschienen `Ausmalbilder kostenlos Pferde`, `Bibi und Tina Pferde`, `Fahrbare weidehütte für Pferde` und eine Praxis-/Tierarzt-Rohphrase in einem Bereich, der zur Produktion vorbereitet war.

**Bedeutung:** Der technische Rootfix funktionierte; gleichzeitig bewies der erfolgreiche Lauf, dass die fachlichen Journal-Gates falsch waren.

## Fehler 18 – bestehender signierter Journal-Goldslot wurde durch falschen aktuellen Planinhalt verdrängt

Der bereits signierte Pilot `Können Pferde schwimmen?` hatte einen festen gebundenen Planplatz. Im fehlerhaften aktuellen Redaktionsplan wurde derselbe relevante Planplatz mit einem anderen falschen Thema belegt.

**Folge:** Die alten signierten Produktionsartefakte durften nicht blind erneut verwendet werden. Exact Five und Planplatzbindung wären nicht mehr konsistent gewesen.

## Fehler 19 – Empfehlung zur manuellen Veröffentlichung wäre Workflowbruch gewesen

Zwischenzeitlich wurde vorgeschlagen, die zwei Goldartikel manuell als WordPress-Beiträge anzulegen.

**Warum falsch:** Der verbindliche Workflow verlangt Redaktionsplan -> Exact Five -> Supervisor -> PPM -> WordPress Draft -> Readback. Ein manueller Beitrag hätte die gebundene Traceability und den normalen Produktionsweg umgangen und den Systemzustand zusätzlich auseinandergezogen.

**Dauerregel:** Kein Artikel darf als „schneller Weg“ am Redaktionsplan/Supervisor/PPM vorbeigeschrieben werden.

## Fehler 20 – Zwischenstände wurden wiederholt als Status gemeldet, obwohl der Auftrag keine Zwischenmeldungen erlaubte

Dies war ein Prozessfehler der Arbeitsausführung. `Noch nicht fertig` ist kein objektiver externer BLOCKED-Zustand.

**Dauerregel:** Bei einem Auftrag `ohne Zwischenmeldungen` wird nur bei fertigem Gesamt-PASS oder bei einem echten, extern nicht auflösbaren BLOCKED-Zustand gemeldet.

---

# Ursachenbündel

Die gesamte Fehlerkette lässt sich auf vier Primärursachen reduzieren:

1. **Master-Compliance war kein Pre-Code-Gate.**
2. **Neue Beitragsart war nicht sauber als additive Extension gekapselt.**
3. **Entscheidung, Evidenz und Freigabe waren nicht streng genug getrennt.**
4. **Technische Abhängigkeiten/Invalidierung waren zu global gekoppelt.**

Alles Weitere – falsche Journalzuordnung, schlechte Titel, falscher PASS, breite Sandbox-Neuberechnung und Redaktionsplan-Timeouts – war eine Folge oder Verstärkung dieser vier Ursachen.

---

# Reparierter Architekturstand

## Zentrale signierte Extension-Registry

PSTE, PSERC und PPM konsumieren jetzt byteidentisch dieselbe signierte `ARTICLE_TYPE_EXTENSION_MANIFEST_V1`.

Manifest-SHA-256:

`755b709ebfea6e6279cad1e064ae896a68246147c09c523e1747fbf7e81e62c4`

Die Registry ist deklarativ. Sie enthält keine frei neu erfundene redaktionelle Entscheidungslogik.

## Core bleibt Core

Der bestehende Nicht-Extension-Pfad bleibt fachlich eingefroren. Eine Extension wird erst nach einem Core-Miss geprüft, aber der Core-Miss selbst ist ausdrücklich **kein Beweis** für die Extension.

## Positive unabhängige Zulassung

Eine Extension benötigt positiv bewiesene, unabhängige Scope-/Intent-Evidenz. Selbst erzeugte Router-Evidenz wird verworfen.

## Kein Journal-Fallback

`fallback_activation_allowed=false` und die Journal-Aktivierung ist an `EXPLICIT_JOURNAL_SCOPE_AND_INTENT_ONLY` gebunden.

## Titel

Journal erzeugt nicht mehr automatisch aus einer Rohsuchphrase einen fertigen Titel. Ein separat gebundener Journal-Titel durchläuft den bestehenden Titelpfad. Zusätzlich verhindern Journal-only harte Veto-Prüfungen rohe Keywordketten. Der bestehende Nicht-Journal-Titelpfad wird dadurch nicht verändert.

## Phrasenwiederholung

Die Extension-Registry kann `phrase_family_repetition_forbidden=true` verlangen. PSERC prüft dann die Titeloberfläche gegen bereits vorbereitete Titel derselben Extension und setzt bei Wiederholung `REVIEW_REQUIRED`. Für bestehende Core-Typen ist dieser neue Gate-Pfad nicht aktiv.

## Release-Autorität

Ein einzelnes Modul kann keinen finalen READY erzeugen. Der Release-Aggregator verlangt technische, redaktionelle und E2E-Evidenz. REVIEW/UNKNOWN/FAIL sind kein PASS. Manueller Override ist nicht vorgesehen.

## Invalidierung

Legacy Article-Type-Registry und Family-Identity behalten ihren eigenen Fingerprint. Die Extension-Registry besitzt einen separaten Fingerprint. Der synthetische `+1`-Test beweist: Eine zusätzliche signierte Extension verändert den Extension-Fingerprint, aber nicht Legacy-Registry oder Family-Identity.

## Request-Bounding bleibt erhalten

Die bereits reparierten bounded/resumable Mechanismen aus PSTE 0.54.0 / PSERC 0.26.0 bleiben erhalten: Cursor, Generation, Lease/Fencing, atomare Snapshot-Aktivierung und request-begrenzte Reader werden nicht zurückgebaut.

---

# Nachweise dieses Reparaturblocks

- Realbestand: **562 Themen**.
- Journal positiv ohne manuelle Freigabe: **exakt 2 signierte Goldbindungen**.
- Nicht automatisch Journal: **560/562**.
- Negativ geblockt: Ausmalbilder, Bibi und Tina, fahrbare Weidehütte, Tierarzt-Praxis-Rohphrase.
- Beide Journal-Goldtitel: PASS.
- Tierarzt-Praxis-Rohtitel: BLOCK/REVIEW durch harte Titelgates.
- Rohaufbau `Bibi und Tina Pferde` erzeugt keinen Journal-Produktionstitel.
- Selbstautorisiertes Router-Evidence: BLOCK.
- Journal-Phrasenwiederholung: BLOCK/REVIEW.
- Nicht-Journal-Titelregression: byteidentisch auf allen im realen 562er-Datensatz vorhandenen vollständig auswertbaren Core-Kandidaten (18 Vergleichsfälle).
- Synthetischer `+1 Article Type`-Test: PASS in PSTE, PSERC und PPM; Legacy-/Family-Hashes unverändert.
- PPM aktive Testsuite: **136/136 PASS** auf Source und erneut auf Fresh-Unpack.
- PSERC-Paketintegrität: PASS auf Fresh-Unpack.
- Gemeinsames Extension-Manifest in PSTE/PSERC/PPM: byteidentisch.
- PPM Build-Signatur und Extension-Signatur: PASS.
- Neue verbotene WordPress-Write-Callsites im PPM-Diff: **0**.
- Source -> Installer -> Fresh-Unpack: byteidentisch.
- PHP-Lint/JSON-Parse: PASS auf allen drei Fresh-Unpack-Plugins.

---

# Bekannter, bewusst NICHT mitveränderter Altpunkt

Im bestehenden Beratungspfad existieren bereits vor diesem Reparaturblock Titelvarianten mit wiederkehrendem `... auswählen`. Der aktuelle Auftrag verbietet Änderungen an bestehenden Nicht-Journal-Entscheidungs-/Titelpfaden. Deshalb wurde dieser Altpunkt **nicht nebenbei repariert**. Der neue Journal-Phrasen-Diversity-Gate ist ausdrücklich Extension-only. Eine spätere Änderung an Beratung benötigt einen eigenen autorisierten Arbeitsauftrag und vollständige Golden-Master-/Workflowprüfung.

---

# Verbindliche Lehre für jede nächste Beitragsart

Eine weitere Beitragsart darf **nicht** durch Kopieren des Journal-Codes oder Hinzufügen neuer `if ($type === '...')`-Sonderpfade implementiert werden. Sie wird nur über die zentrale signierte Extension-Registry und vorhandene deklarierte Capabilities angebunden. Benötigt sie eine Capability, die die Registry nicht abbilden kann, ist der Vorgang **BLOCKED** und muss gegen den Master entschieden werden – nicht durch spontane Core-Änderung.
