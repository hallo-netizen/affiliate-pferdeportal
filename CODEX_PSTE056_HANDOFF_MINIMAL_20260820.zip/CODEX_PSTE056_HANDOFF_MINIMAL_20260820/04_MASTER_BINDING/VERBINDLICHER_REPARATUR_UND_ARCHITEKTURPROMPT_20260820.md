# VERBINDLICHER REPARATUR- UND ARCHITEKTURPROMPT

Arbeite diesen Auftrag **vollständig in einem einzigen zusammenhängenden Arbeitsblock bis zum belastbaren Endergebnis** ab.

**Keine Zwischenmeldungen. Keine Mini-Fixes. Keine Plugin-Serie. Keine symptomatischen Reparaturen. Keine eigenen fachlichen Entscheidungen. Keine stillschweigenden Annahmen.**

Unterbreche die Arbeit nur, wenn ein objektiv nicht auflösbarer Zustand vorliegt, für den zwingend externe Informationen oder eine Benutzerhandlung fehlen. In diesem Fall lautet das Ergebnis ausschließlich **BLOCKED** mit exakt belegter Ursache.

---

# 1. OBERSTE AUTORITÄT

Maßgeblich sind ausschließlich:

1. die aktuelle Masterdatei,
2. die darin enthaltenen verbindlichen Regeln und Verträge,
3. die vollständigen Übergabeprotokolle,
4. die vollständigen Fehlerkataloge,
5. die vorhandenen Prüfberichte,
6. die vorhandenen Codex-Root-Cause-/Architekturberichte,
7. die vorhandenen Quellstände und Golden Masters,
8. dieser Auftrag.

**Nicht aus Erinnerung ergänzen. Nicht raten. Nicht aufgrund technischer Bequemlichkeit entscheiden. Nicht aufgrund vermeintlicher Plausibilität neue Regeln erzeugen.**

Bei einem Widerspruch zwischen Quellen:

- Widerspruch vollständig rekonstruieren,
- Autorität und zeitliche Reihenfolge bestimmen,
- keine eigene fachliche Lösung erfinden,
- bei nicht eindeutig auflösbarem Widerspruch: **BLOCKED**.

---

# 2. ABSOLUTE REGEL 1 – TEXTMASCHINE UND BESTEHENDE ERGEBNISSE SIND UNANTASTBAR

Keine Änderung darf direkt oder indirekt Einfluss haben auf bestehende:

- Artikelinhalte,
- Wortlaut,
- Fakten,
- Überschriften,
- HTML,
- Struktur,
- Formatierung,
- Tabellen,
- Listen,
- Links,
- Design,
- CSS,
- Bilder,
- Prompts,
- Promptlogik,
- Recherchelogik,
- Produktionslogik,
- WordPress-Ausgabe,
- Publish-Logik,
- vorhandene Qualitätsregeln,
- bestehende Artikeltypentscheidungen,
- bestehende Kategorieentscheidungen,
- bestehende Titelentscheidungen,
- bestehende Planplatzentscheidungen,
- bestehende Exact-Five-Entscheidungen.

**Die bestehende Textmaschine ist read-only und unveränderliche Autorität.**

Keine neue Beitragsart darf Änderungen an der Textmaschine erforderlich machen.

Keine neue Beitragsart darf eine bestehende fachliche Entscheidungsinstanz verändern.

Keine technische Refaktorierung darf das Ergebnis der bestehenden Textmaschine verändern.

Kann diese Neutralität nicht vollständig bewiesen werden:

**BLOCKED.**

---

# 3. BESTEHENDE BEITRAGSARTEN SIND EINGEFROREN

Alle bereits bestehenden Beitragsarten und ihre vollständigen Entscheidungswege sind fachlich eingefroren.

Insbesondere bestehende:

- FAQ-Regeln,
- Beratungsregeln,
- Vergleichsregeln,
- Pflegeregeln,
- weitere bereits vorhandene Artikeltypen,
- Kategoriezuordnungen,
- Titelregeln,
- Intent-Regeln,
- Slot-Regeln,
- Exact-Five-Regeln

dürfen nicht angepasst, vereinheitlicht, „verbessert“, vereinfacht oder neu interpretiert werden.

Für jeden bestehenden Artikeltyp muss vor und nach dem Umbau nachgewiesen werden:

- identischer fachlicher Input,
- identische Artikeltypentscheidung,
- identische Kategorieentscheidung,
- identische Titelentscheidung,
- identischer Planplatz,
- identischer Exact-Five-Handoff,
- identischer PSERC-Release,
- identischer PPM-Input,
- identischer Draft,
- identischer Readback,
- identische geschützte Artikelbytes bzw. bestehende Golden-Master-Identität.

Bereits **eine einzige unbeabsichtigte Abweichung** bedeutet:

**BLOCKED.**

---

# 4. NEUE BEITRAGSARTEN DÜRFEN KEINE BESTEHENDE ENTSCHEIDUNGSART ANTASTEN

Eine neue Beitragsart ist ausschließlich eine **additive Erweiterung**.

Sie darf niemals:

- bestehende Artikeltypen neu klassifizieren,
- bestehende Intent-Regeln verändern,
- bestehende Fallbacks verändern,
- bestehende Kategorien neu bewerten,
- bestehende Slots verändern,
- bestehende Titelregeln verändern,
- bestehende Prioritäten verändern,
- bestehende Produktionsentscheidungen verändern,
- bestehende Sandbox-Records global invalidieren,
- bestehende Context-/Inventory-/Plan-Bestände global neu bewerten.

Insbesondere gilt zwingend:

**Eine neue Beitragsart darf nicht dadurch aktiviert werden, dass eine bestehende Zuordnung fehlschlägt.**

Ein `Family Miss`, `Type Miss`, `Category Miss`, fehlendes Produktthema oder irgendein anderer bestehender Negativzustand darf **niemals automatisch Beweis für eine neue Beitragsart sein**.

Eine neue Beitragsart muss ihre eigene bereits definierte Zulassung **positiv und unabhängig** beweisen.

Fehlt dieser positive Beweis:

**BLOCKED / NICHT DIESE BEITRAGSART.**

Keine künstliche Erzeugung des anschließend benötigten Intent-Signals durch denselben Router.

---

# 5. ZENTRALE ARCHITEKTUR FÜR ALLE ZUKÜNFTIGEN BEITRAGSARTEN

Das System ist jetzt so umzubauen, dass zukünftige Beitragsarten **nicht mehr durch Hartverdrahtung in mehreren Kernsystemen integriert werden müssen**.

Verbindliches Ziel ist eine:

**zentrale, signierte, versionierte Beitragsart-Registry /** **`ARTICLE_TYPE_EXTENSION_MANIFEST_V1`**

oder die exakt gleichwertige bereits im Master vorgesehene Architektur.

Dieses Manifest darf ausschließlich deklarative, bereits fachlich definierte Eigenschaften enthalten, zum Beispiel:

- technische ID der Beitragsart,
- sichtbarer Name,
- Version,
- erlaubte bestehende Capabilities,
- erlaubter Titelmodus,
- bestehende Kategorie-Capability,
- bestehendes Exact-Five-Handoff-Schema,
- bestehende Validator-Capabilities,
- benötigte bestehende Slot-Capabilities,
- Signatur,
- Versionsbindung.

Das Manifest darf **keine neue fachliche Entscheidungslogik enthalten**.

PSTE, PSERC und PPM müssen dieselbe kanonische Registrierung konsumieren.

Keine Typnamen-Switches oder erneute individuelle Hartverdrahtung einer neuen Beitragsart in zahlreichen Dateien.

Zukünftig muss eine neue Beitragsart technisch im Wesentlichen bestehen aus:

1. einem zentralen deklarativen Manifest-Eintrag,
2. der Bindung an bereits vorhandene erlaubte Capabilities,
3. den typbezogenen Positiv-/Negativtests,
4. signierter Freigabe.

Nicht aus neuen Eingriffen in alle drei Kernsysteme.

---

# 6. ISOLIERTE INVALIDIERUNG

Eine Änderung an einer Beitragsart darf ausschließlich Daten invalidieren, die tatsächlich von dieser Beitragsart oder der konkret veränderten Komponente abhängen.

Zwingende Negativtests:

- `+1` neue Beitragsart darf bestehende Artikeltypen nicht invalidieren.
- `+1` neue Beitragsart darf unabhängige Sandbox-Records nicht invalidieren.
- `+1` unabhängiger Draft darf nicht den gesamten Sandboxbestand invalidieren.
- `+1` veröffentlichter unabhängiger Artikel darf nicht den gesamten Sandboxbestand invalidieren.
- Änderung eines Article-Type-Manifests darf nicht Inventory, Context und Sandbox global neu aufbauen.
- Registry-Fingerprint muss von fachlich unabhängigen Fingerprints getrennt sein.

Globale Bestandsprüfsummen dürfen nicht erneut fachlich unabhängige Bereiche miteinander koppeln.

---

# 7. NIEMAND UND KEINE KOMPONENTE DARF SICH SELBST EINEN RELEASE-PASS GEBEN

Ein einzelnes Modul, ein einzelner Router, ein einzelner Validator, ein einzelner Test oder ein einzelner Codepfad darf niemals allein einen finalen PASS bzw. READY-Zustand erzeugen.

Es gilt zwingend das Prinzip:

**Evidence Producer ≠ Evidence Verifier ≠ Release Authority**

Eine Komponente, die eine fachliche oder technische Entscheidung erzeugt, darf diese Entscheidung nicht selbst abschließend freigeben.

Für jede freigaberelevante Entscheidung müssen die bereits vorgesehenen unabhängigen Prüfroutinen verwendet werden.

Mindestens erforderlich:

- unabhängige technische Prüfung,
- unabhängige redaktionelle/fachliche Prüfung,
- unabhängige E2E-Prüfung,
- zentraler reiner Release-Aggregator.

Der Release-Aggregator:

- darf selbst keine fachliche Entscheidung erzeugen,
- darf keine Regex- oder Domainlogik enthalten,
- darf keine Prüfdaten verändern,
- darf keinen Fehler überschreiben,
- darf keine Mehrheitsentscheidung treffen,
- darf keinen REVIEW-Zustand in PASS umwandeln,
- darf keinen unbekannten Zustand als PASS behandeln.

Final READY ausschließlich bei:

`TECHNICAL = PASS`
**UND**
`EDITORIAL = PASS`
**UND**
`E2E = PASS`

Jeder andere Zustand:

**NICHT READY.**

Jeder FAIL:

**BLOCKED.**

Jeder unbekannte Zustand:

**BLOCKED.**

Jeder REVIEW-Zustand:

**NICHT READY.**

Kein Score, keine Mehrheitsentscheidung und kein manueller Override darf diese Sperre umgehen.

---

# 8. KEIN SELBSTBESTÄTIGENDER ROUTER

Insbesondere bei Journal gilt:

Der Router darf nicht:

1. selbst Journal auswählen,
2. anschließend selbst ein Journal-Intent-Signal erzeugen,
3. dieses selbst erzeugte Signal anschließend als Beweis für seine ursprüngliche Entscheidung verwenden.

Scope und Intent müssen aus den bereits verbindlich definierten Quellen **unabhängig belegt sein**, bevor Journal als Beitragsart zugelassen werden kann.

Die bestehende Regel:

`EXPLICIT_JOURNAL_SCOPE_AND_INTENT_ONLY`

ist technisch exakt durchzusetzen.

Sie darf nicht durch einen Family-Miss, allgemeine Pferdebegriffe, fehlende kommerzielle Signale oder andere Fallbackzustände ersetzt werden.

Die bereits festgelegte fachliche Trennung zwischen:

- Journal
- und großem regulären Contentbereich

ist unverändert aus der maßgeblichen Masterdefinition zu übernehmen.

**Keine neue Definition erfinden.**

Themen, die nach der bestehenden Definition in den großen Contentbereich gehören, dürfen nicht deshalb ins Journal gelangen, weil eine andere Zuordnung nicht gefunden wurde.

---

# 9. JOURNAL DARF NUR BESTEHENDE REGELN ERBEN – KEINE SONDERLOGIK ERFINDEN

Journal ist eine neue Beitragsart, aber **kein neuer paralleler Qualitätsstandard**.

Für Journal gelten vollständig die bereits bestehenden einschlägigen Regeln für:

- SEO-Intent,
- natürliche deutsche Titel,
- Titelqualität,
- Keyword-Stakkato,
- künstliche Generatorformulierungen,
- Template-Spam,
- semantische Passung,
- Kategoriepassung,
- Sprache,
- Fakten,
- Struktur,
- Links,
- Qualitätsprüfung,
- Exact Five,
- Supervisor,
- PPM,
- WordPress Draft,
- Readback.

Bestehende Regeln werden dabei **nicht verändert**, sondern ausschließlich auf Journal ausgedehnt, soweit Journal dieselbe Capability nutzt.

Keine Journal-Sonderausnahme darf einen bestehenden Qualitäts-Gate abschwächen.

---

# 10. TITELREGELN SIND FÜR JOURNAL HART

Journal-Titel dürfen nicht einfach aus rohen Suchphrasen übernommen werden.

Jeder Journal-Titel muss dieselben bestehenden verbindlichen Titelqualitätsprüfungen durchlaufen.

Insbesondere:

- natürliches Deutsch,
- redaktionell sinnvoller Titel,
- kein Keyword-Stakkato,
- keine Suchmaschinen-Rohphrase als Titel,
- keine künstliche Generatorformulierung,
- kein Template-Spam,
- kein Bedeutungswechsel zur kosmetischen Verbesserung,
- Intent und Titel müssen zueinander passen,
- bestehende Sonderzeichenregeln beachten,
- bestehende Frage-/Aussagetitel-Regel für Journal beachten.

Beispiele wie:

`Tierarzt praxis eckard bauer fahrpraxis Pferde großtiere`

dürfen niemals einen finalen Titel-PASS erhalten.

---

# 11. KEINE STÄNDIGEN PHRASENWIEDERHOLUNGEN IN TITELN

Die bestehende Regel gegen stereotype, wiederkehrende Titelschemata ist verbindlich zu beachten.

Sie gilt auch für Journal.

Keine Beitragsart darf durch mechanische Wiederholung immer derselben Formulierung oder derselben kleinen Phrasenfamilie künstlich variiert werden.

Insbesondere dürfen keine Serien entstehen wie sinngemäß:

- „richtig auswählen“
- „passend auswählen“
- „gezielt auswählen“
- „nach wichtigen Kriterien auswählen“
- oder vergleichbare wiederkehrende Generator-Schablonen.

Wichtig:

Dies ist **keine Erlaubnis**, bestehende Beratungsregeln neu zu schreiben.

Bestehende Nicht-Journal-Logik bleibt eingefroren.

Die vorhandene Phrasen-/Titelregel wird für Journal lediglich ebenfalls verbindlich angewandt.

Für die Reparatur der bereits separat dokumentierten Beratungs-Titelwiederholungen gilt:

**Nicht mit diesem Architekturumbau vermischen, sofern die Masterdatei diesen Punkt als separaten Arbeitsblock definiert.**

Keine Änderung bestehender Beratungstitel als Nebenwirkung dieses Auftrags.

---

# 12. JOURNAL-UMFANG NICHT NEU DEFINIEREN

Der Umfang, die zulässigen Journal-Kategorien und die fachliche Abgrenzung des Journals sind bereits definiert.

Sie dürfen nicht neu erfunden oder erweitert werden.

Keine eigene Entscheidung darüber:

- was „interessant“ für Journal wäre,
- was „gut passen könnte“,
- welche neuen Kategorien sinnvoll wären,
- welche Themen zusätzlich ins Journal könnten.

Ausschließlich die vorhandene verbindliche Definition verwenden.

Unklare Zuordnung:

**BLOCKED / REVIEW – niemals automatische Journal-Zuordnung.**

---

# 13. DIE ZWEI BEREITS FERTIGEN JOURNAL-ARTIKEL SIND UNVERÄNDERLICHE GOLDSTANDARDS

Die bereits erfolgreich erzeugten Journalartikel:

- „Wie alt werden Pferde?“
- „Können Pferde schwimmen?“

sind unveränderliche Golden Masters.

Keine Neuerstellung als Ersatzbeweis.

Keine Textänderung.

Keine Titeländerung.

Keine Kategorieänderung.

Keine Artikeltypänderung.

Keine Planplatzänderung.

Keine Neuschreibung.

Der reparierte Stack muss für dieselben autorisierten Inputs wieder exakt die bereits signierten/gebundenen Ergebnisse erzeugen.

Diese zwei Artikel sind zugleich das **erste operative Freigabeziel**, damit anschließend möglichst schnell wieder regulär veröffentlicht werden kann.

Sie dürfen aber **nicht am vorgeschriebenen Workflow vorbei** erzeugt oder veröffentlicht werden.

---

# 14. DER WORKFLOW IST UNANTASTBAR

Es gilt exakt der bestehende Workflow:

`Workflow Supervisor`
→ `Start Gate`
→ `Topic / Category / Article-Type / Plan-Slot Binding`
→ `Title Authority`
→ `Exact Five`
→ `Research`
→ `Provenance`
→ `Language / Structure / Facts / Links / Quality`
→ `Signed Workflow Release`
→ `Signed PPM Release`
→ `PPM`
→ `WordPress Draft`
→ `Readback Hash`

Kein Schritt darf:

- übersprungen,
- umgangen,
- vorgezogen,
- nach hinten verschoben,
- durch einen manuellen Ersatz ersetzt,
- als bereits bestanden angenommen

werden.

Kein Artikel darf am Redaktionsplan oder Supervisor vorbei veröffentlicht werden.

Keine direkte WordPress-Erstellung als Ersatz für den Workflow.

---

# 15. MANIPULATION MUSS FAIL-CLOSED BLEIBEN

Für sämtliche Beitragsarten einschließlich Journal muss Manipulation von:

- Titel,
- Target Keyword,
- Kategorie,
- Artikeltyp,
- Planplatz,
- Exact Five,
- Payload,
- Signatur,
- Handoff,
- Status,
- Release,
- Hash

am jeweils zuständigen Gate zwingend zu:

**BLOCKED**

führen.

Publish-Eskalation muss weiterhin hart abgewiesen werden.

---

# 16. PARALLELE UND UNABHÄNGIGE PRÜFROUTINEN MÜSSEN REAL UNABHÄNGIG SEIN

Zwei Prüfungen gelten nicht als unabhängig, wenn beide lediglich dieselbe zuvor erzeugte falsche Entscheidung übernehmen.

Deshalb muss für jede parallele Prüfroutine dokumentiert werden:

- welche Rohdaten sie erhält,
- welche Entscheidungen sie selbst lesen darf,
- welche Entscheidungen sie unabhängig neu verifiziert,
- welche gemeinsamen Vorbedingungen bestehen,
- ob eine falsche Upstream-Annahme beide Prüfungen gleichzeitig verfälschen könnte.

Insbesondere Journal-Scope, Journal-Intent, Artikeltyp und Kategorie dürfen nicht dadurch von zwei Prüfern scheinbar bestätigt werden, dass beide dieselbe selbst erzeugte Routermarkierung übernehmen.

Für kritische Entscheidungen muss mindestens eine Prüfroutine auf einer **unabhängigen Evidenzbasis** arbeiten.

Kann echte Unabhängigkeit nicht bewiesen werden:

**BLOCKED.**

---

# 17. KEIN FALSCHER PASS DURCH TESTDESIGN

Tests dürfen nicht nur bekannte Positivfälle prüfen.

Die Negativmatrix muss ausdrücklich Fälle enthalten, die die bisherigen Fehlannahmen treffen.

Mindestens testen:

### Journal falsch positiv

- allgemeines Pferdekeyword ohne Journalbeweis,
- reguläres Hauptcontent-Thema,
- Haltungs-/Produkt-/Ratgeberthema für den Hauptcontent,
- „Ausmalbilder kostenlos Pferde“,
- „Bibi und Tina Pferde“,
- fremde Marken-/Medienphrasen,
- Firmen-/Personen-/Praxis-Suchphrasen,
- „Tierarzt praxis eckard bauer fahrpraxis Pferde großtiere“,
- fahrbare Weidehütte,
- rohe Suchphrasen,
- Keyword-Stakkato,
- Titel mit unnatürlicher deutscher Oberfläche,
- fehlender Journal-Scope,
- fehlender Journal-Intent,
- widersprüchlicher Scope/Intent.

### Journal positiv

- beide bestehenden Journal-Golden-Master-Fälle,
- weitere ausschließlich aus der bereits verbindlichen Journaldefinition ableitbare Testfixtures.

### Bestehende Typen

Für FAQ, Beratung, Vergleich, Pflege und sämtliche weiteren bestehenden Typen:

- Positivtests,
- Negativtests,
- Konflikttests,
- Golden-Master-Vergleich.

### Architektur

- neue leere/additive Test-Beitragsart registrieren,
- bestehende Typen unverändert,
- bestehender Redaktionsplan unverändert,
- bestehende Sandbox unabhängig,
- keine globale Invalidierung,
- Entfernen der Test-Beitragsart stellt exakt Ausgangszustand wieder her.

---

# 18. JEDER EINZELNE SCHRITT MUSS GEGEN DEN GESAMTEN WORKFLOW GETESTET WERDEN

Nach **jeder Codeänderung** zwingend:

1. betroffener Unit-/Contract-Test,
2. Positivtest,
3. Negativtest,
4. Golden-Master-Diff,
5. Regel-1-Diff,
6. Keyword-/Relations-Unversehrtheit,
7. bestehende Beitragsarten,
8. Journal,
9. vollständiger Workflow-Regressionslauf.

Kein:

„Diese Datei betrifft nur X, daher teste ich Y später.“

Keine Teilfreigabe.

Keine Annahme, eine Änderung sei „offensichtlich neutral“.

---

# 19. TEST AUF REALISTISCHEM VOLLBESTAND

Nicht nur kleine Fixtures.

Zusätzlich zwingend gegen den vorhandenen realen Bestand prüfen:

- kompletter Themenbestand,
- kompletter Keywordbestand,
- Longtails,
- Relationsdaten,
- reale Sandbox-Größe,
- Redaktionsplan,
- bestehende Inhalte,
- vorhandene Planplätze,
- bestehende Golden Masters.

Der neue Architekturpfad muss außerdem beweisen:

**Eine neue Beitragsart verändert keine fachlich unabhängigen bestehenden Records.**

---

# 20. REQUEST-BOUNDING UND TECHNISCHE ROOTFIXES BLEIBEN ERHALTEN

Die inzwischen reparierte technische Architektur darf durch die fachliche Journal-Reparatur nicht wieder zurückgebaut werden.

Insbesondere erhalten bleiben:

- request-begrenzter Redaktionsplan,
- resumable Jobs,
- Cursor,
- Generationen,
- Lease/Fencing,
- atomare Snapshot-Aktivierung,
- bounded Reader,
- Readback-Verifikation,
- getrennte Invalidierungsfingerprints.

Kein Rückfall zu monolithischen Vollbestandsrequests.

Kein globaler Rebuild aufgrund einer einzelnen Beitragsart.

---

# 21. KEIN KOMPLETTER SYSTEMROLLBACK, WENN NICHT BEWIESEN NOTWENDIG

Nicht pauschal auf einen alten Stand zurückrollen.

Stattdessen:

- technische Rootfixes erhalten,
- fehlerhafte Journal-Hartverdrahtung gezielt entfernen,
- bestehende fachliche Nicht-Journal-Pfade gegen Pre-Journal einfrieren,
- zentrale Extension-Architektur implementieren.

Ein vollständiger Rollback ist ausschließlich zulässig, wenn durch reproduzierbare Prüfung bewiesen wird, dass die sichere Reparatur auf der aktuellen technischen Basis unmöglich ist.

Keine eigene Präferenzentscheidung.

---

# 22. KEINE INSTALLATIONSDATEI VOR VOLLSTÄNDIGEM PASS

Es gilt die bestehende harte Build-Sperre.

Keine neue installierbare ZIP-Datei ausgeben, solange nicht:

- Source vollständig geprüft,
- alle Positivtests PASS,
- alle Negativtests PASS,
- alle Golden Masters PASS,
- Regel 1 PASS,
- vollständiger Workflow PASS,
- Fresh-Unpack erneut vollständig geprüft,
- Installer gegen Source hash-/inhaltlich verifiziert

wurden.

Teil-PASS ist kein Release.

„Funktioniert wahrscheinlich“ ist kein Release.

Unbekannt ist:

**BLOCKED.**

---

# 23. FRESH-UNPACK MUSS ERNEUT DEN GESAMTEN TEST DURCHLAUFEN

Nach erfolgreicher Source-Prüfung:

1. Installer bauen,
2. in frisches Verzeichnis entpacken,
3. Dateiintegrität prüfen,
4. sämtliche relevanten Tests erneut ausführen,
5. vollständigen Workflow erneut positiv und negativ prüfen,
6. Golden Masters erneut prüfen,
7. Regel-1-Diff erneut prüfen.

Erst danach darf eine Installationsdatei bereitgestellt werden.

---

# 24. ERSTES LIVE-ZIEL NACH DER REPARATUR

Nach vollständigem lokalem PASS ist der erste Live-E2E-Zweck:

die beiden bestehenden Journal-Goldartikel wieder **durch den normalen unveränderten Workflow** bis zu echten WordPress-Drafts zu bringen.

Nicht über einen Sonderweg.

Nicht manuell.

Nicht am Redaktionsplan vorbei.

Nicht mit neu erzeugten Ersatzartikeln.

Erst wenn:

- Redaktionsplan korrekt,
- Exact Five korrekt,
- Signaturen korrekt,
- Supervisor PASS,
- PPM PASS,
- Draft erstellt,
- Readback PASS

sind, ist der Journal-Produktionspfad live bestätigt.

Lokaler PASS darf nicht als Live-PASS bezeichnet werden.

---

# 25. KEINE EIGENEN VERBESSERUNGEN

Während dieses Auftrags ausdrücklich verboten:

- „wenn wir schon dabei sind“-Änderungen,
- Refactoring außerhalb des notwendigen Architekturblocks,
- neue SEO-Regeln,
- neue Titelregeln,
- neue Kategorien,
- neue Journalthemen,
- neue Artikeltypen,
- Promptverbesserungen,
- Inhaltsverbesserungen,
- Designverbesserungen,
- Workflowvereinfachungen,
- zusätzliche automatische Entscheidungen.

Auch eine vermeintlich bessere Lösung ist verboten, wenn sie nicht durch Master und Auftrag autorisiert ist.

---

# 26. ABSCHLUSKRITERIUM

Der Auftrag ist erst abgeschlossen, wenn gleichzeitig bewiesen ist:

**Technik**

- request-bounded,
- resumable,
- keine Vollbestandskopplung,
- keine globale Beitragsart-Invalidierung.

**Beitragsart-Architektur**

- zentrale signierte Registry/Manifest,
- keine Cross-Core-Hartverdrahtung neuer Beitragsarten,
- neue Beitragsart rein additiv.

**Entscheidungen**

- bestehende Entscheidungswege unverändert,
- keine Selbstbestätigung,
- unabhängige Prüfroutinen,
- kein einzelnes Modul kann READY erzeugen.

**Journal**

- ausschließlich bestehender definierter Scope,
- ausschließlich positiver unabhängiger Scope+Intent-Beweis,
- kein Fallback-Journal,
- bestehende Titelregeln vollständig aktiv,
- natürliche Titel,
- keine Suchphrasen-Titel,
- keine stereotypen Phrasenwiederholungen.

**Textmaschine**

- keinerlei direkte oder indirekte Änderung des Ergebnisses.

**Workflow**

- unverändert vollständig.

**Regression**

- alle bestehenden Artikeltypen identisch,
- alle Golden Masters identisch,
- beide Journal-Golden-Masters identisch.

**QA**

- komplette Positiv-/Negativmatrix PASS,
- Source PASS,
- Fresh-Unpack PASS,
- Regel 1 PASS.

Wenn auch nur ein Punkt nicht vollständig bewiesen ist:

**BLOCKED – KEIN BUILD – KEINE INSTALLATION – KEINE FREIGABE.**

---

# 27. ARBEITSWEISE

Arbeite jetzt ohne Zwischenmeldung vollständig durch:

**Forensik → Baseline → Architektur → Implementierung → Positivtests → Negativtests → Gesamtworkflow → Golden-Master-Vergleich → Regel-1-Prüfung → Fresh-Unpack → erneuter Gesamtworkflow → Installer → vollständige Übergabe.**

Keine Zwischenversionen zum Installieren.

Keine Kleinstplugins.

Keine symptomatischen Patches.

Erst melden, wenn der gesamte zusammenhängende Block vollständig abgeschlossen ist oder ein objektiver harter BLOCKED-Zustand nachgewiesen wurde.