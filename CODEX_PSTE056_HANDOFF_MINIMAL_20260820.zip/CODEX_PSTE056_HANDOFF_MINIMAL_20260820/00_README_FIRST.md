# START HIER

Arbeite ausschließlich nach `05_CODEX_AUFTRAG_PSTE056_DIFF_HANDOFF.md`.
Die Dateien unter `04_MASTER_BINDING/` sind verbindlich.
Wichtig: Am Ende KEINE Download-Datei erzeugen und KEINE Dateiliste mit hunderten Dateien ausgeben. Das Ergebnis muss als kleiner Text-Diff zurückgegeben werden, damit es direkt in ChatGPT eingefügt werden kann.
