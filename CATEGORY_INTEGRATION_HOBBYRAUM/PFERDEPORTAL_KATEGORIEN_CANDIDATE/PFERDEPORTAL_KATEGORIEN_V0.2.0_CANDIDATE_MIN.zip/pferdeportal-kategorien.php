<?php
/**
 * Plugin Name: Pferde Atelier – Pferdeportal Kategorien
 * Description: Zentrale, manuell gepflegte Struktur-Autorität ausschließlich für das Pferdeportal. Kein Bezug zum separaten Kategorie-Workflow-Plugin.
 * Version: 0.2.0
 */
if (!defined('ABSPATH')) { exit; }

final class PA_Pferdeportal_Kategorien {
    const VERSION='0.2.0';
    const REGISTRY_OPTION='pa_pk_registry_v2';
    const AUDIT_OPTION='pa_pk_audit_v2';
    const SNAPSHOT_OPTION='pa_pk_snapshots_v2';
    const ERROR_OPTION='pa_pk_last_error_v2';
    const BASELINE_FINGERPRINT='562a3f7e6ef89a60b52f8d680cea8c392724b5be3003b05cb23bfb396b49084e';

    private static $bootstrap_roots=array('ausruestung','stall','weide','fuetterung','gesundheit','training','transport','wissen');
    private static $themes=array(
      'faq'=>'FAQ','beratung'=>'Beratung','vergleich'=>'Vergleich','pflege'=>'Pflege','sicherheit'=>'Sicherheit',
      'anwendung'=>'Anwendung','kosten'=>'Kosten','installation'=>'Installation','lagerung'=>'Lagerung','uebungen'=>'Uebungen'
    );

    public static function init(){
      add_action('admin_menu',array(__CLASS__,'admin_menu'));
      add_action('admin_post_pa_pk_scan',array(__CLASS__,'handle_scan'));
      add_action('admin_post_pa_pk_add_category',array(__CLASS__,'handle_add_category'));
      add_action('admin_post_pa_pk_retire_category',array(__CLASS__,'handle_retire_category'));
      add_action('admin_post_pa_pk_delete_category',array(__CLASS__,'handle_delete_category'));
      add_action('admin_post_pa_pk_add_page_node',array(__CLASS__,'handle_add_page_node'));
      add_action('admin_post_pa_pk_retire_page_node',array(__CLASS__,'handle_retire_page_node'));
      add_action('admin_post_pa_pk_delete_page_node',array(__CLASS__,'handle_delete_page_node'));
    }

    private static function active_root_slugs(){
      $r=self::get_registry(); $out=array();
      if($r && !empty($r['main_hubs'])) foreach($r['main_hubs'] as $n) if(!empty($n['active'])) $out[]=$n['slug'];
      return $out ? $out : self::$bootstrap_roots;
    }

    public static function activate(){
      $existing=self::get_registry();
      $scan=self::scan_live();
      if(is_wp_error($scan)){ update_option(self::ERROR_OPTION,$scan->get_error_message(),false); return; }
      if($existing){
        $cmp=self::compare_live();
        if(is_wp_error($cmp) || !empty($cmp['hard_drift'])){
          update_option(self::ERROR_OPTION,is_wp_error($cmp)?$cmp->get_error_message():'REGISTRY_LIVE_DRIFT',false); return;
        }
        delete_option(self::ERROR_OPTION); return;
      }
      if($scan['fingerprint_sha256']!==self::BASELINE_FINGERPRINT){ update_option(self::ERROR_OPTION,'BASELINE_FINGERPRINT_MISMATCH',false); return; }
      $registry=array(
        'schema'=>'PA_PFERDEPORTAL_KATEGORIEN_REGISTRY_V2','registry_version'=>1,'created_at_gmt'=>gmdate('c'),'updated_at_gmt'=>gmdate('c'),
        'source'=>'VERIFIED_LIVE_BOOTSTRAP','main_hubs'=>$scan['main_hubs'],'section_hubs'=>$scan['section_hubs'],'product_pages'=>$scan['product_pages'],
        'production_categories'=>$scan['production_categories'],'nonproduction_categories'=>$scan['nonproduction_categories']
      );
      $registry['registry_hash']=self::registry_hash($registry);
      update_option(self::REGISTRY_OPTION,$registry,false);
      self::append_audit('BOOTSTRAP','registry',0,null,self::summary($registry));
      delete_option(self::ERROR_OPTION);
    }

    public static function get_registry(){ $r=get_option(self::REGISTRY_OPTION); return is_array($r)?$r:null; }
    public static function get_version(){ $r=self::get_registry(); return $r?intval($r['registry_version']):0; }
    public static function get_hash(){ $r=self::get_registry(); return $r?(string)$r['registry_hash']:''; }
    public static function themes(){ return self::$themes; }

    private static function node_base($p){ return array('post_id'=>intval($p->ID),'slug'=>(string)$p->post_name,'title'=>(string)$p->post_title,'parent_id'=>intval($p->post_parent),'status'=>(string)$p->post_status,'active'=>true); }

    public static function scan_live(){
      $pages=get_pages(array('post_status'=>array('publish','draft','private'),'sort_column'=>'ID'));
      $terms=get_categories(array('hide_empty'=>false,'taxonomy'=>'category'));
      $by_id=array(); $by_slug=array();
      foreach($pages as $p){ $x=self::node_base($p); if(isset($by_slug[$x['slug']])) return new WP_Error('pa_pk_duplicate_page_slug','DUPLICATE_PAGE_SLUG:'.$x['slug']); $by_id[$x['post_id']]=$x; $by_slug[$x['slug']]=$x; }
      $levels=array();
      foreach(self::active_root_slugs() as $slug){ if(!isset($by_slug[$slug])) return new WP_Error('pa_pk_root_missing','PORTAL_ROOT_MISSING:'.$slug); $levels[$by_slug[$slug]['post_id']]=1; }
      for($pass=0;$pass<4;$pass++) foreach($by_id as $id=>$p) if(!isset($levels[$id]) && isset($levels[$p['parent_id']]) && $levels[$p['parent_id']]<3) $levels[$id]=$levels[$p['parent_id']]+1;
      $main=array();$sections=array();$products=array();$products_by_slug=array();
      foreach($levels as $id=>$level){
        $p=$by_id[$id];
        if($level===1){ $main[]=$p; }
        elseif($level===2){ $parent=$by_id[$p['parent_id']]; $p['main_slug']=$parent['slug'];$p['main_page_id']=$parent['post_id'];$p['portal_path']=$parent['title'].' > '.$p['title'];$sections[]=$p; }
        elseif($level===3){ $section=$by_id[$p['parent_id']];$root=$by_id[$section['parent_id']];$p['section_slug']=$section['slug'];$p['section_page_id']=$section['post_id'];$p['main_slug']=$root['slug'];$p['main_page_id']=$root['post_id'];$p['portal_path']=$root['title'].' > '.$section['title'].' > '.$p['title'];$products[]=$p;$products_by_slug[$p['slug']]=$p; }
      }
      foreach(array(&$main,&$sections,&$products) as &$arr) usort($arr,function($a,$b){return strcmp($a['slug'],$b['slug']);}); unset($arr);
      $production=array();$other=array();$seen=array();
      foreach($terms as $t){
        $slug=(string)$t->slug; if(isset($seen[$slug])) return new WP_Error('pa_pk_duplicate_slug','DUPLICATE_CATEGORY_SLUG:'.$slug); $seen[$slug]=true; $match=null;
        foreach(self::$themes as $theme_slug=>$theme_name){ $suffix='-'.$theme_slug; if(substr($slug,-strlen($suffix))===$suffix){$product_slug=substr($slug,0,-strlen($suffix));if(isset($products_by_slug[$product_slug])){$match=array($product_slug,$theme_slug,$theme_name);break;}} }
        $base=array('term_id'=>intval($t->term_id),'slug'=>$slug,'name'=>(string)$t->name,'wp_parent'=>intval($t->parent),'count'=>intval($t->count),'active'=>true);
        if(!$match){unset($base['active']);$other[]=$base;continue;}
        list($product_slug,$theme_slug,$theme)=$match;$product=$products_by_slug[$product_slug];$section=$by_id[$product['parent_id']];$root=$by_id[$section['parent_id']];
        $base+=array('theme_slug'=>$theme_slug,'theme'=>$theme,'product_slug'=>$product_slug,'product_page_id'=>$product['post_id'],'product'=>$product['title'],'section_slug'=>$section['slug'],'section_page_id'=>$section['post_id'],'section'=>$section['title'],'main_slug'=>$root['slug'],'main_page_id'=>$root['post_id'],'main'=>$root['title'],'portal_path'=>$root['title'].' > '.$section['title'].' > '.$product['title'].' > '.(string)$t->name);
        if($base['wp_parent']!==0) return new WP_Error('pa_pk_nonflat_term','PRODUCTION_CATEGORY_PARENT_NOT_ZERO:'.$slug); $production[]=$base;
      }
      usort($production,function($a,$b){return strcmp($a['slug'],$b['slug']);});usort($other,function($a,$b){return strcmp($a['slug'],$b['slug']);});
      $fingerprint=self::structure_fingerprint(array('main_hubs'=>$main,'section_hubs'=>$sections,'product_pages'=>$products,'production_categories'=>$production,'nonproduction_categories'=>$other));
      return array('counts'=>array('main_hubs'=>count($main),'section_hubs'=>count($sections),'product_pages'=>count($products),'production_categories'=>count($production),'nonproduction_categories'=>count($other)),'main_hubs'=>$main,'section_hubs'=>$sections,'product_pages'=>$products,'production_categories'=>$production,'nonproduction_categories'=>$other,'fingerprint_sha256'=>$fingerprint);
    }

    private static function strip_dynamic($rows,$kind){ $out=array(); foreach($rows as $x){unset($x['active']); if($kind==='category') unset($x['count']); $out[]=$x;} return $out; }
    private static function structure_fingerprint($s){
      $p=array('main_hubs'=>self::strip_dynamic($s['main_hubs'],'page'),'section_hubs'=>self::strip_dynamic($s['section_hubs'],'page'),'product_pages'=>self::strip_dynamic($s['product_pages'],'page'),'production_categories'=>self::strip_dynamic($s['production_categories'],'category'),'nonproduction_categories'=>self::strip_dynamic($s['nonproduction_categories'],'category'));
      return hash('sha256',wp_json_encode($p,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    }

    private static function active_map($rows,$key='slug'){ $m=array();foreach((array)$rows as $x)if(!empty($x['active']))$m[$x[$key]]=$x;return $m; }
    private static function live_map($rows,$key='slug'){ $m=array();foreach((array)$rows as $x)$m[$x[$key]]=$x;return $m; }
    public static function compare_live(){
      $r=self::get_registry();if(!$r)return new WP_Error('pa_pk_registry_missing','REGISTRY_MISSING');$scan=self::scan_live();if(is_wp_error($scan))return $scan;
      $hard=array();$retired=array();
      foreach(array('main_hubs','section_hubs','product_pages','production_categories') as $kind){
        $live=self::live_map($scan[$kind]);$active=self::active_map($r[$kind]);$all=self::live_map($r[$kind]);
        $missing=array_values(array_diff(array_keys($active),array_keys($live)));$unexpected=array_values(array_diff(array_keys($live),array_keys($all)));$ret=array();
        foreach($all as $slug=>$row)if(empty($row['active'])&&isset($live[$slug]))$ret[]=$slug;
        if($missing||$unexpected)$hard[$kind]=array('missing_in_live'=>$missing,'unexpected_in_live'=>$unexpected); if($ret)$retired[$kind]=$ret;
      }
      return array('registry_version'=>intval($r['registry_version']),'registry_hash'=>$r['registry_hash'],'hard_drift'=>$hard,'retired_still_present'=>$retired);
    }

    private static function find_registry_node(&$r,$kind,$slug){foreach($r[$kind] as $i=>$x)if($x['slug']===$slug)return $i;return null;}
    private static function rollback_term($id){$r=wp_delete_term($id,'category');return !is_wp_error($r)&&$r;}
    private static function rollback_page($id){$r=wp_delete_post($id,true);return (bool)$r;}

    public static function add_category($product_slug,$theme_slug){
      $r=self::get_registry();if(!$r)return new WP_Error('pa_pk_registry_missing','REGISTRY_MISSING');if(!isset(self::$themes[$theme_slug]))return new WP_Error('pa_pk_theme_invalid','THEME_INVALID');
      $products=self::active_map($r['product_pages']);if(!isset($products[$product_slug]))return new WP_Error('pa_pk_product_missing','PRODUCT_PAGE_MISSING_OR_INACTIVE');$product=$products[$product_slug];
      $slug=$product_slug.'-'.$theme_slug;foreach($r['production_categories'] as $c)if($c['slug']===$slug)return new WP_Error('pa_pk_registry_exists','CATEGORY_ALREADY_REGISTERED');if(term_exists($slug,'category'))return new WP_Error('pa_pk_term_exists','WORDPRESS_TERM_ALREADY_EXISTS');
      self::snapshot('BEFORE_ADD_CATEGORY:'.$slug);$name=self::$themes[$theme_slug].' '.$product['title'];$ins=wp_insert_term($name,'category',array('slug'=>$slug,'parent'=>0));if(is_wp_error($ins))return $ins;$id=intval($ins['term_id']);
      $scan=self::scan_live();if(is_wp_error($scan)){self::rollback_term($id);return new WP_Error('pa_pk_add_readback','ADD_READBACK_FAILED_ROLLBACK_ATTEMPTED:'.$scan->get_error_message());}
      $new=null;foreach($scan['production_categories'] as $c)if($c['slug']===$slug){$new=$c;break;}if(!$new){self::rollback_term($id);return new WP_Error('pa_pk_add_readback','ADD_READBACK_MISSING_ROLLBACK_ATTEMPTED');}
      $before=self::summary($r);$r['production_categories'][]=$new;usort($r['production_categories'],function($a,$b){return strcmp($a['slug'],$b['slug']);});self::bump_registry($r);self::append_audit('ADD_CATEGORY','category',$id,$before,self::summary($r));return $new;
    }

    public static function retire_category($slug){$r=self::get_registry();if(!$r)return new WP_Error('pa_pk_registry_missing','REGISTRY_MISSING');$i=self::find_registry_node($r,'production_categories',$slug);if($i===null||empty($r['production_categories'][$i]['active']))return new WP_Error('pa_pk_not_active','CATEGORY_NOT_ACTIVE');self::snapshot('BEFORE_RETIRE_CATEGORY:'.$slug);$before=self::summary($r);$r['production_categories'][$i]['active']=false;$r['production_categories'][$i]['retired_at_gmt']=gmdate('c');self::bump_registry($r);self::append_audit('RETIRE_CATEGORY','category',intval($r['production_categories'][$i]['term_id']),$before,self::summary($r));return true;}

    public static function delete_retired_category($slug){
      $r=self::get_registry();if(!$r)return new WP_Error('pa_pk_registry_missing','REGISTRY_MISSING');$i=self::find_registry_node($r,'production_categories',$slug);if($i===null)return new WP_Error('pa_pk_not_found','CATEGORY_NOT_FOUND');$c=$r['production_categories'][$i];if(!empty($c['active']))return new WP_Error('pa_pk_not_retired','CATEGORY_NOT_RETIRED');$term=get_term(intval($c['term_id']),'category');if(is_wp_error($term)||!$term)return new WP_Error('pa_pk_term_missing','WORDPRESS_TERM_MISSING');if(intval($term->count)!==0)return new WP_Error('pa_pk_term_in_use','CATEGORY_HAS_POSTS');
      self::snapshot('BEFORE_DELETE_CATEGORY:'.$slug);$before=self::summary($r);$res=wp_delete_term(intval($c['term_id']),'category');if(is_wp_error($res)||!$res)return new WP_Error('pa_pk_delete_failed','WORDPRESS_DELETE_FAILED');if(term_exists($slug,'category'))return new WP_Error('pa_pk_delete_readback','WORDPRESS_DELETE_READBACK_FAILED');array_splice($r['production_categories'],$i,1);self::bump_registry($r);self::append_audit('DELETE_CATEGORY','category',intval($c['term_id']),$before,self::summary($r));return true;
    }

    public static function add_page_node($level,$title,$slug,$parent_slug=''){
      $r=self::get_registry();if(!$r)return new WP_Error('pa_pk_registry_missing','REGISTRY_MISSING');$map=array('main_hub'=>'main_hubs','section_hub'=>'section_hubs','product_page'=>'product_pages');if(!isset($map[$level]))return new WP_Error('pa_pk_level_invalid','PAGE_LEVEL_INVALID');$kind=$map[$level];$slug=sanitize_title($slug);$title=trim((string)$title);if($slug===''||$title==='')return new WP_Error('pa_pk_page_invalid','PAGE_TITLE_OR_SLUG_EMPTY');
      foreach(array('main_hubs','section_hubs','product_pages') as $k)foreach($r[$k] as $n)if($n['slug']===$slug)return new WP_Error('pa_pk_page_registered','PAGE_SLUG_ALREADY_REGISTERED');$parent_id=0;
      if($level==='section_hub'){$m=self::active_map($r['main_hubs']);if(!isset($m[$parent_slug]))return new WP_Error('pa_pk_parent_invalid','MAIN_PARENT_MISSING_OR_INACTIVE');$parent_id=intval($m[$parent_slug]['post_id']);}
      if($level==='product_page'){$m=self::active_map($r['section_hubs']);if(!isset($m[$parent_slug]))return new WP_Error('pa_pk_parent_invalid','SECTION_PARENT_MISSING_OR_INACTIVE');$parent_id=intval($m[$parent_slug]['post_id']);}
      self::snapshot('BEFORE_ADD_PAGE:'.$slug);$id=wp_insert_post(array('post_type'=>'page','post_status'=>'draft','post_title'=>$title,'post_name'=>$slug,'post_parent'=>$parent_id,'menu_order'=>999),true);if(is_wp_error($id))return $id;$id=intval($id);$post=get_post($id);if(!$post||(string)$post->post_name!==$slug||intval($post->post_parent)!==$parent_id){self::rollback_page($id);return new WP_Error('pa_pk_page_readback','PAGE_ADD_READBACK_FAILED_ROLLBACK_ATTEMPTED');}
      if($level==='main_hub'){$new=self::node_base($post);}else{$scan=self::scan_live();if(is_wp_error($scan)){self::rollback_page($id);return new WP_Error('pa_pk_page_scan','PAGE_ADD_SCAN_FAILED_ROLLBACK_ATTEMPTED:'.$scan->get_error_message());}$new=null;foreach($scan[$kind] as $n)if($n['slug']===$slug){$new=$n;break;}if(!$new){self::rollback_page($id);return new WP_Error('pa_pk_page_readback','PAGE_ADD_READBACK_MISSING_ROLLBACK_ATTEMPTED');}}
      $before=self::summary($r);$r[$kind][]=$new;usort($r[$kind],function($a,$b){return strcmp($a['slug'],$b['slug']);});self::bump_registry($r);self::append_audit('ADD_'.strtoupper($level),'page',$id,$before,self::summary($r));return $new;
    }

    public static function retire_page_node($level,$slug){
      $r=self::get_registry();if(!$r)return new WP_Error('pa_pk_registry_missing','REGISTRY_MISSING');$map=array('main_hub'=>'main_hubs','section_hub'=>'section_hubs','product_page'=>'product_pages');if(!isset($map[$level]))return new WP_Error('pa_pk_level_invalid','PAGE_LEVEL_INVALID');$kind=$map[$level];$i=self::find_registry_node($r,$kind,$slug);if($i===null||empty($r[$kind][$i]['active']))return new WP_Error('pa_pk_page_not_active','PAGE_NOT_ACTIVE');
      if($level==='main_hub')foreach($r['section_hubs'] as $n)if(!empty($n['active'])&&$n['main_slug']===$slug)return new WP_Error('pa_pk_children_active','ACTIVE_CHILD_SECTIONS_EXIST');
      if($level==='section_hub')foreach($r['product_pages'] as $n)if(!empty($n['active'])&&$n['section_slug']===$slug)return new WP_Error('pa_pk_children_active','ACTIVE_CHILD_PRODUCTS_EXIST');
      if($level==='product_page')foreach($r['production_categories'] as $c)if(!empty($c['active'])&&$c['product_slug']===$slug)return new WP_Error('pa_pk_children_active','ACTIVE_CHILD_CATEGORIES_EXIST');
      self::snapshot('BEFORE_RETIRE_PAGE:'.$slug);$before=self::summary($r);$r[$kind][$i]['active']=false;$r[$kind][$i]['retired_at_gmt']=gmdate('c');self::bump_registry($r);self::append_audit('RETIRE_'.strtoupper($level),'page',intval($r[$kind][$i]['post_id']),$before,self::summary($r));return true;
    }

    public static function delete_retired_page_node($level,$slug){
      $r=self::get_registry();if(!$r)return new WP_Error('pa_pk_registry_missing','REGISTRY_MISSING');$map=array('main_hub'=>'main_hubs','section_hub'=>'section_hubs','product_page'=>'product_pages');if(!isset($map[$level]))return new WP_Error('pa_pk_level_invalid','PAGE_LEVEL_INVALID');$kind=$map[$level];$i=self::find_registry_node($r,$kind,$slug);if($i===null)return new WP_Error('pa_pk_page_missing','PAGE_NOT_FOUND');$n=$r[$kind][$i];if(!empty($n['active']))return new WP_Error('pa_pk_page_not_retired','PAGE_NOT_RETIRED');
      if($level==='main_hub')foreach($r['section_hubs'] as $x)if($x['main_slug']===$slug)return new WP_Error('pa_pk_children_exist','CHILD_SECTIONS_STILL_REGISTERED');
      if($level==='section_hub')foreach($r['product_pages'] as $x)if($x['section_slug']===$slug)return new WP_Error('pa_pk_children_exist','CHILD_PRODUCTS_STILL_REGISTERED');
      if($level==='product_page')foreach($r['production_categories'] as $x)if($x['product_slug']===$slug)return new WP_Error('pa_pk_children_exist','CHILD_CATEGORIES_STILL_REGISTERED');
      $id=intval($n['post_id']);foreach(get_pages(array('post_status'=>array('publish','draft','private','trash'))) as $p)if(intval($p->post_parent)===$id)return new WP_Error('pa_pk_live_children','WORDPRESS_CHILD_PAGES_EXIST');
      self::snapshot('BEFORE_DELETE_PAGE:'.$slug);$before=self::summary($r);$res=wp_delete_post($id,true);if(!$res)return new WP_Error('pa_pk_page_delete_failed','WORDPRESS_PAGE_DELETE_FAILED');if(get_post($id))return new WP_Error('pa_pk_page_delete_readback','WORDPRESS_PAGE_DELETE_READBACK_FAILED');array_splice($r[$kind],$i,1);self::bump_registry($r);self::append_audit('DELETE_'.strtoupper($level),'page',$id,$before,self::summary($r));return true;
    }

    private static function bump_registry(&$r){$r['registry_version']=intval($r['registry_version'])+1;$r['updated_at_gmt']=gmdate('c');$r['registry_hash']=self::registry_hash($r);update_option(self::REGISTRY_OPTION,$r,false);}
    private static function registry_hash($r){$x=$r;unset($x['registry_hash']);return hash('sha256',wp_json_encode($x,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));}
    private static function summary($r){$s=array('version'=>intval($r['registry_version']),'hash'=>isset($r['registry_hash'])?$r['registry_hash']:'');foreach(array('main_hubs','section_hubs','product_pages','production_categories') as $k){$a=0;foreach((array)$r[$k] as $x)if(!empty($x['active']))$a++;$s[$k.'_active']=$a;$s[$k.'_total']=count((array)$r[$k]);}$s['nonproduction_categories']=count((array)$r['nonproduction_categories']);return $s;}
    private static function snapshot($reason){$r=self::get_registry();if(!$r)return;$all=get_option(self::SNAPSHOT_OPTION,array());$all[]=array('at_gmt'=>gmdate('c'),'reason'=>$reason,'registry'=>$r);update_option(self::SNAPSHOT_OPTION,$all,false);}
    private static function append_audit($action,$object_type,$object_id,$before,$after){$log=get_option(self::AUDIT_OPTION,array());$log[]=array('at_gmt'=>gmdate('c'),'user_id'=>function_exists('get_current_user_id')?intval(get_current_user_id()):0,'action'=>$action,'object_type'=>$object_type,'object_id'=>intval($object_id),'before'=>$before,'after'=>$after);update_option(self::AUDIT_OPTION,$log,false);}

    public static function admin_menu(){add_menu_page('Pferdeportal Kategorien','Pferdeportal Kategorien','manage_options','pa-pferdeportal-kategorien',array(__CLASS__,'render_admin'),'dashicons-category',58);}
    private static function nonce(){wp_nonce_field('pa_pk_action');}
    public static function render_admin(){
      if(!current_user_can('manage_options'))return;$r=self::get_registry();echo '<div class="wrap"><h1>Pferdeportal Kategorien</h1>';
      $err=get_option(self::ERROR_OPTION);if($err)echo '<div class="notice notice-error"><p><strong>'.esc_html($err).'</strong></p></div>';
      if(!$r){echo '<p><strong>Kein gültiges Register initialisiert.</strong></p></div>';return;}$s=self::summary($r);$cmp=self::compare_live();
      echo '<p>Register-Version <strong>'.esc_html($s['version']).'</strong> · Hash <code>'.esc_html($s['hash']).'</code></p>';
      echo '<p>Hauptbereiche '.esc_html($s['main_hubs_active']).' · Unterbereiche '.esc_html($s['section_hubs_active']).' · Produktseiten '.esc_html($s['product_pages_active']).' · Produktionskategorien '.esc_html($s['production_categories_active']).' · sonstige Kategorien '.esc_html($s['nonproduction_categories']).'</p>';
      if(is_wp_error($cmp))echo '<p><strong>Prüfung fehlgeschlagen:</strong> '.esc_html($cmp->get_error_message()).'</p>';else echo '<p>Harte Live-Abweichungen: <strong>'.esc_html(count($cmp['hard_drift'])).'</strong> · absichtlich stillgelegt und noch vorhanden: <strong>'.esc_html(array_sum(array_map('count',$cmp['retired_still_present']))).'</strong></p>';
      echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="pa_pk_scan">';self::nonce();submit_button('Jetzt prüfen','secondary','submit',false);echo '</form><hr>';
      echo '<h2>Portal-Seite hinzufügen</h2><p>Neue Seiten werden zunächst als <strong>Entwurf</strong> angelegt.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="pa_pk_add_page_node">';self::nonce();
      echo '<select name="level"><option value="main_hub">Hauptbereich</option><option value="section_hub">Unterbereich</option><option value="product_page" selected>Produktseite</option></select> <input name="parent_slug" placeholder="Parent-Slug (bei Hauptbereich leer)"> <input name="title" required placeholder="Titel"> <input name="slug" required placeholder="Slug"> ';submit_button('Seite anlegen','primary','submit',false);echo '</form>';
      echo '<h2>Artikelkategorie hinzufügen</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="pa_pk_add_category">';self::nonce();echo '<select name="product_slug">';foreach($r['product_pages'] as $n)if(!empty($n['active']))echo '<option value="'.esc_attr($n['slug']).'">'.esc_html($n['portal_path']).'</option>';echo '</select> <select name="theme_slug">';foreach(self::$themes as $slug=>$name)echo '<option value="'.esc_attr($slug).'">'.esc_html($name).'</option>';echo '</select> ';submit_button('Kategorie anlegen','primary','submit',false);echo '</form><hr>';
      echo '<h2>Artikelkategorie stilllegen / löschen</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="pa_pk_retire_category">';self::nonce();echo '<select name="slug">';foreach($r['production_categories'] as $c)if(!empty($c['active']))echo '<option value="'.esc_attr($c['slug']).'">'.esc_html($c['portal_path']).'</option>';echo '</select> ';submit_button('Stilllegen','secondary','submit',false);echo '</form>';
      echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="pa_pk_delete_category">';self::nonce();echo '<select name="slug">';foreach($r['production_categories'] as $c)if(empty($c['active']))echo '<option value="'.esc_attr($c['slug']).'">'.esc_html($c['slug']).'</option>';echo '</select> ';submit_button('Stillgelegte Kategorie endgültig löschen','delete','submit',false);echo '</form><hr>';
      echo '<h2>Portal-Seite stilllegen / löschen</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="pa_pk_retire_page_node">';self::nonce();echo '<select name="level"><option value="product_page">Produktseite</option><option value="section_hub">Unterbereich</option><option value="main_hub">Hauptbereich</option></select> <input name="slug" required placeholder="Slug"> ';submit_button('Seite stilllegen','secondary','submit',false);echo '</form>';
      echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="pa_pk_delete_page_node">';self::nonce();echo '<select name="level"><option value="product_page">Produktseite</option><option value="section_hub">Unterbereich</option><option value="main_hub">Hauptbereich</option></select> <input name="slug" required placeholder="Slug"> ';submit_button('Stillgelegte Seite endgültig löschen','delete','submit',false);echo '</form>';
      $log=get_option(self::AUDIT_OPTION,array());echo '<hr><h2>Änderungsprotokoll</h2><p>Einträge: '.esc_html(count($log)).' · Fallback-Snapshots: '.esc_html(count(get_option(self::SNAPSHOT_OPTION,array()))).'</p><table class="widefat striped"><thead><tr><th>Zeit</th><th>Aktion</th><th>ID</th></tr></thead><tbody>';foreach(array_slice(array_reverse($log),0,50) as $e)echo '<tr><td>'.esc_html($e['at_gmt']).'</td><td>'.esc_html($e['action']).'</td><td>'.esc_html($e['object_id']).'</td></tr>';echo '</tbody></table></div>';
    }

    private static function guard_admin_post(){if(!current_user_can('manage_options'))wp_die('FORBIDDEN');check_admin_referer('pa_pk_action');}
    private static function redirect_result($res){if(is_wp_error($res))update_option(self::ERROR_OPTION,$res->get_error_message(),false);else delete_option(self::ERROR_OPTION);wp_safe_redirect(admin_url('admin.php?page=pa-pferdeportal-kategorien'));exit;}
    public static function handle_scan(){self::guard_admin_post();self::redirect_result(self::compare_live());}
    public static function handle_add_category(){self::guard_admin_post();self::redirect_result(self::add_category(sanitize_title(wp_unslash($_POST['product_slug']??'')),sanitize_title(wp_unslash($_POST['theme_slug']??''))));}
    public static function handle_retire_category(){self::guard_admin_post();self::redirect_result(self::retire_category(sanitize_title(wp_unslash($_POST['slug']??''))));}
    public static function handle_delete_category(){self::guard_admin_post();self::redirect_result(self::delete_retired_category(sanitize_title(wp_unslash($_POST['slug']??''))));}
    public static function handle_add_page_node(){self::guard_admin_post();self::redirect_result(self::add_page_node(sanitize_title(wp_unslash($_POST['level']??'')),sanitize_text_field(wp_unslash($_POST['title']??'')),sanitize_title(wp_unslash($_POST['slug']??'')),sanitize_title(wp_unslash($_POST['parent_slug']??''))));}
    public static function handle_retire_page_node(){self::guard_admin_post();self::redirect_result(self::retire_page_node(sanitize_title(wp_unslash($_POST['level']??'')),sanitize_title(wp_unslash($_POST['slug']??''))));}
    public static function handle_delete_page_node(){self::guard_admin_post();self::redirect_result(self::delete_retired_page_node(sanitize_title(wp_unslash($_POST['level']??'')),sanitize_title(wp_unslash($_POST['slug']??''))));}
}
register_activation_hook(__FILE__,array('PA_Pferdeportal_Kategorien','activate'));add_action('plugins_loaded',array('PA_Pferdeportal_Kategorien','init'));
function pa_pferdeportal_kategorien_registry(){return PA_Pferdeportal_Kategorien::get_registry();}
function pa_pferdeportal_kategorien_version(){return PA_Pferdeportal_Kategorien::get_version();}
function pa_pferdeportal_kategorien_hash(){return PA_Pferdeportal_Kategorien::get_hash();}
