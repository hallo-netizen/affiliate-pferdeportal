# Consumer-/Fallback-Matrix

## Zentralplugin
- Kandidat 0.2.0 ersetzt noch keine Produktionsquelle.
- Vor jeder eigenen Mutation: kompletter Registry-Snapshot.
- Externe Drift: nur melden, niemals still übernehmen.

## PPA-001 Affiliate-Zentrale
- Arbeitsbasis für Kategorieintegration: exakt gebundener 6.72.145-Vollbaum.
- unveränderlicher Rollbackanker: 6.72.142 GOLDMASTER.
- 6.72.105 darf nicht als Ersatz für den aktuellen Live-/Performance-Stand benutzt werden.

## PPA-013 Design
- vor jeder Änderung den real aktuellen vollständigen Pluginstand neu binden.
- letzter exakt hashgebundener Apply 1.50.558 ist Evidenz, keine Annahme über den heutigen Live-Stand.

## PSERC
- Paket SHA256 `77a14aca97f46d60bc9001d66327abb68dd9cac9ad111f8ecefa1a8afd345314`.
- dynamische neue Kategorien bereits positiv/negativ bewiesen; keine unnötige Quelländerung.

## PSTE
- liest WordPress-Struktur dynamisch/read-only; keine Quelländerung ohne neuen Nachweis, dass sie nötig ist.

## PPM 6.7.9 / System4
- unveränderlicher Fallback: Paket SHA256 `acbda93bd1c4292de7aaf88db2195631103991ff508b36c88cb694714818abd1`.
- kompletter Build ist Ed25519-signiert.
- direkte Änderung ohne autorisierten Signierweg ist verboten und würde die Integritätsprüfung brechen.
- für 25 Kategorien + 125 Slots wird ein autorisiert neu signierter Build oder ein autorisiert signierter externer Registry-/Plan-Weg benötigt.
