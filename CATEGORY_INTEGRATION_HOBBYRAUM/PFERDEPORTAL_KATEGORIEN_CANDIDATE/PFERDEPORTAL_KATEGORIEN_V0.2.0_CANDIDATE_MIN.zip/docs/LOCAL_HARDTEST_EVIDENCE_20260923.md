# Lokaler Hardtest 2026-09-23

Basis: WordPress-Export `pferdeatelier.WordPress.2026-09-23.xml` und bereits hart geprüfte Portalstruktur.

1:1-Ausgangsbestand:
- 8 Hauptbereiche
- 59 Unterbereiche
- 334 Produktseiten
- 1149 Produktionskategorien
- 11 sonstige WordPress-Kategorien
- 1124/1124 bisherige PPM-Kategorien mit identischen Term-IDs

Positiv/Negativ/Regression getestet:
- vollständiger Scan + Baseline-Fingerprint;
- Registry-Bootstrap;
- Kategorie ADD / Doppelanlage / ungültiges Thema / unbekannte Produktseite;
- RETIRE / DELETE / belegte Kategorie blockiert DELETE;
- Produktseite ADD als Draft / Child-Gate / RETIRE / DELETE;
- Hauptbereich + Unterbereich ADD / Child-Gates / RETIRE / DELETE;
- Reaktivierung nach legitimen Änderungen ohne Rückfall auf alte Bootstrap-Baseline;
- externe Drift wird erkannt und nicht übernommen;
- fehlerhafter Kategorie-Readback rollt ADD zurück;
- veränderter Seiten-Slug rollt ADD zurück;
- Produktionskategorie mit WordPress-Parent != 0 fail-closed;
- Änderungsprotokoll und Fallback-Snapshots bleiben erhalten.

Marker: `PFERDEPORTAL_KATEGORIEN_V020_LOCAL_1TO1_HARDTEST_PASS`
