# Pferde Atelier – Pferdeportal Kategorien 0.2.0

Dieses Plugin ist ausschließlich die zentrale Struktur-Autorität für das Pferdeportal. Es hat keinen Bezug zum separaten allgemeinen Kategorie-Workflow.

Grundregeln:
- keine Hintergrund-Automatik;
- Änderungen nur manuell im Backend;
- vollständige Portalstruktur: Hauptbereiche, Unterbereiche, Produktseiten und Produktionskategorien;
- Produktseiten werden beim Anlegen zunächst als Entwurf erzeugt;
- Artikelkategorien bleiben in WordPress flach (`parent=0`); die Portalzuordnung liegt im zentralen Register;
- Löschen immer zweistufig: zuerst stilllegen, dann erst endgültig löschen;
- aktive Kinder blockieren das Stilllegen einer Elternstruktur;
- belegte Artikelkategorien blockieren das endgültige Löschen;
- vor jeder Mutation wird ein vollständiger Registry-Snapshot gespeichert;
- jede Mutation wird protokolliert;
- externe Änderungen werden als Drift gemeldet und niemals still übernommen;
- Readback-Fehler nach einem ADD lösen sofort einen Rollback-Versuch aus.

Der Kandidat ist bis zur kontrollierten WordPress-Dry-Run-/Apply-Freigabe keine Produktionsautorität.
