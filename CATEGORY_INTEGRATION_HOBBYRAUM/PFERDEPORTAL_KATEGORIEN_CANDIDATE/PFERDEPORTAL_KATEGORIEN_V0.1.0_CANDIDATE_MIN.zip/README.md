# Pferde Atelier – Pferdeportal Kategorien (Kandidat 0.1.0)

Dieses Plugin ist ausschließlich für die **Pferdeportal-Kategorien** bestimmt. Es hat keinen Bezug zum separaten allgemeinen Kategorie-Workflow-Plugin.

## Zweck

Eine zentrale, manuell gepflegte Kategorien-Autorität für das Pferdeportal. Keine Hintergrundautomatik. Keine stillen Änderungen.

## Regeln

- Aktiver Bestand wird aus der echten WordPress-Seitenstruktur und den flachen WordPress-Kategorien gelesen.
- Produktionskategorien werden nur erkannt, wenn ihr Slug exakt aus einer realen Level-3-Produktseite plus einem erlaubten Themen-Suffix besteht.
- WordPress-Parent einer Produktionskategorie muss `0` sein.
- Änderung erhöht immer die Registry-Version und erzeugt vorher einen Fallback-Snapshot.
- Hinzufügen ist manuell.
- Löschen ist zweistufig: `RETIRE` -> später `DELETE`.
- Endgültiges Löschen ist blockiert, solange Beiträge der Kategorie zugeordnet sind.
- Externe Änderungen werden nur als Drift gemeldet und niemals automatisch übernommen.

## Öffentliche Schnittstelle für Verbraucher

- `pa_pferdeportal_kategorien_registry()`
- `pa_pferdeportal_kategorien_version()`
- `pa_pferdeportal_kategorien_hash()`

Verbraucher dürfen daraus lesen. Sie dürfen die zentrale Registry nicht schreiben.
