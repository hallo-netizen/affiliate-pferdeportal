# Lokaler 1:1-Hardtest – 2026-09-23

Eingang: WordPress-WXR-Export `pferdeatelier.WordPress.2026-09-23.xml` vom selben Tag.

Geprüfter Ist-Stand:
- 8 Main-Hubs
- 59 Bereichs-Hubs
- 334 Level-3-Produktseiten
- 1149 Produktionskategorien
- 11 sonstige WordPress-Kategorien
- 0 fehlende Produktionskategorien gegenüber dem hardgetesteten Portalstruktur-Kandidaten
- 0 doppelte Produktions-Slugs
- 1124/1124 alte PPM-Term-IDs stimmen mit dem aktuellen WordPress-Export überein
- neue Term-IDs 1577..1601 vollständig vorhanden

Lokale Tests mit dem echten heutigen Bestand:
- Scan positiv
- Baseline-Fingerprint positiv
- Bootstrap positiv
- manuelles ADD positiv
- Registry-Version nach ADD erhöht
- Doppelanlage negativ / fail-closed
- unbekanntes Thema negativ / fail-closed
- unbekannte Produktseite negativ / fail-closed
- RETIRE positiv
- DELETE nach RETIRE positiv
- DELETE bei belegter Kategorie negativ / fail-closed
- Produktionskategorie mit WordPress-Parent != 0 negativ / fail-closed
- Audit-Historie vorhanden
- Fallback-Snapshots vorhanden

Abschlussmarker:
`PFERDEPORTAL_KATEGORIEN_LOCAL_HARDTEST_PASS`

Kein WordPress-Write wurde im echten Portal durchgeführt. Sämtliche Mutationen liefen ausschließlich im lokalen 1:1-Testmodell.
