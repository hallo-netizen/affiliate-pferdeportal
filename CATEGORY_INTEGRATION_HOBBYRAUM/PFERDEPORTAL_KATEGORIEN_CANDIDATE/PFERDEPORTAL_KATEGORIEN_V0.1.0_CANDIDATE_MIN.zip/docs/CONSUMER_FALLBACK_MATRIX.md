# Fallback-Matrix vor Verbraucher-Anpassungen

Diese Matrix muss vor jeder Verbraucher-Änderung erneut gegen den aktuellen echten Source-Stand geprüft werden.

| Verbraucher | Änderung jetzt? | Sicherer Ausgang/Fallback |
|---|---|---|
| Pferdeportal Kategorien | Kandidat neu | Vor jeder eigenen Mutation Registry-Snapshot; vor Live-Einsatz keine bestehende Quelle ersetzen |
| PPA-001 Affiliate-Zentrale | später | 6.72.142 GOLDMASTER bleibt unveränderlicher Rollbackanker; Arbeitsbasis für Kategorieintegration ist der exakt gebundene 6.72.145-Vollbaum |
| PPA-013 Design | später | Vor Änderung echte aktuelle Live-Vollquelle neu binden; letzter exakt hashgebundener Apply 1.50.558 ist Evidence, aber nicht als aktuelle Live-Quelle raten |
| PSERC | voraussichtlich keine Quelländerung | exaktes Paket SHA256 `77a14aca97f46d60bc9001d66327abb68dd9cac9ad111f8ecefa1a8afd345314`; dynamische Kategorien bereits PASS |
| PPM 6.7.9 / System4 | ja | exaktes Originalpaket SHA256 `acbda93bd1c4292de7aaf88db2195631103991ff508b36c88cb694714818abd1` unverändert als Rollbackanker |
| PSTE | voraussichtlich keine Quelländerung | bestehender read-only WordPress-Strukturpfad bleibt unverändert; vor einer echten Quelländerung muss zuerst der aktuelle exakte Paketstand gebunden werden |

Regel: Kein Verbraucher wird geändert, solange sein sicherer Ausgang nicht eindeutig gebunden ist.
