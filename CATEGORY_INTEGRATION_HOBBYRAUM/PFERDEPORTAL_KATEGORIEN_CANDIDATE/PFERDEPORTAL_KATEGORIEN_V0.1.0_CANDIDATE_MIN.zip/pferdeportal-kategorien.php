<?php
/**
 * Plugin Name: Pferde Atelier – Pferdeportal Kategorien
 * Description: Zentrale, manuell gepflegte Kategorien-Autorität für das Pferdeportal. Kein Bezug zum separaten Kategorie-Workflow-Plugin.
 * Version: 0.1.0
 */

if (!defined('ABSPATH')) { exit; }

final class PA_Pferdeportal_Kategorien {
    const VERSION = '0.1.0';
    const REGISTRY_OPTION = 'pa_pk_registry_v1';
    const AUDIT_OPTION = 'pa_pk_audit_v1';
    const SNAPSHOT_OPTION = 'pa_pk_snapshots_v1';
    const BASELINE_FINGERPRINT = 'a6396b4eab4d8519f8ea1cc4862efbd03beb68d8543df4d27f16d3cfe0488837';

    private static $roots = array(
        'ausruestung' => 'Ausrüstung',
        'stall' => 'Stall',
        'weide' => 'Weide',
        'fuetterung' => 'Fütterung',
        'gesundheit' => 'Gesundheit',
        'training' => 'Training',
        'transport' => 'Transport',
        'wissen' => 'Wissen',
    );

    private static $themes = array(
        'faq' => 'FAQ',
        'beratung' => 'Beratung',
        'vergleich' => 'Vergleich',
        'pflege' => 'Pflege',
        'sicherheit' => 'Sicherheit',
        'anwendung' => 'Anwendung',
        'kosten' => 'Kosten',
        'installation' => 'Installation',
        'lagerung' => 'Lagerung',
        'uebungen' => 'Uebungen',
    );

    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_post_pa_pk_scan', array(__CLASS__, 'handle_scan'));
        add_action('admin_post_pa_pk_add_category', array(__CLASS__, 'handle_add_category'));
        add_action('admin_post_pa_pk_retire_category', array(__CLASS__, 'handle_retire_category'));
        add_action('admin_post_pa_pk_delete_category', array(__CLASS__, 'handle_delete_category'));
    }

    public static function activate() {
        $scan = self::scan_live();
        if (is_wp_error($scan)) {
            update_option('pa_pk_activation_error', $scan->get_error_message(), false);
            return;
        }
        if ($scan['fingerprint_sha256'] !== self::BASELINE_FINGERPRINT) {
            update_option('pa_pk_activation_error', 'BASELINE_FINGERPRINT_MISMATCH', false);
            return;
        }
        if (!get_option(self::REGISTRY_OPTION)) {
            $registry = array(
                'schema' => 'PA_PFERDEPORTAL_KATEGORIEN_REGISTRY_V1',
                'registry_version' => 1,
                'created_at_gmt' => gmdate('c'),
                'updated_at_gmt' => gmdate('c'),
                'source' => 'VERIFIED_LIVE_BOOTSTRAP',
                'production_categories' => $scan['production_categories'],
                'nonproduction_categories' => $scan['nonproduction_categories'],
            );
            $registry['registry_hash'] = self::registry_hash($registry);
            update_option(self::REGISTRY_OPTION, $registry, false);
            self::append_audit('BOOTSTRAP', 'registry', 0, null, self::summary($registry));
        }
    }

    public static function get_registry() {
        $r = get_option(self::REGISTRY_OPTION);
        return is_array($r) ? $r : null;
    }

    public static function get_version() {
        $r = self::get_registry();
        return $r ? intval($r['registry_version']) : 0;
    }

    public static function get_hash() {
        $r = self::get_registry();
        return $r ? (string)$r['registry_hash'] : '';
    }

    public static function scan_live() {
        $pages = get_pages(array('post_status' => array('publish','draft','private'), 'sort_column' => 'ID'));
        $terms = get_categories(array('hide_empty' => false, 'taxonomy' => 'category'));
        $by_id = array(); $by_slug = array();
        foreach ($pages as $p) {
            $rec = array('post_id'=>intval($p->ID),'slug'=>(string)$p->post_name,'title'=>(string)$p->post_title,'parent_id'=>intval($p->post_parent),'status'=>(string)$p->post_status);
            $by_id[$rec['post_id']] = $rec; $by_slug[$rec['slug']] = $rec;
        }
        $levels = array();
        foreach (self::$roots as $slug => $title) {
            if (!isset($by_slug[$slug])) return new WP_Error('pa_pk_root_missing', 'PORTAL_ROOT_MISSING:' . $slug);
            $levels[$by_slug[$slug]['post_id']] = 1;
        }
        for ($pass=0; $pass<4; $pass++) {
            foreach ($by_id as $id => $p) {
                if (isset($levels[$id])) continue;
                if (isset($levels[$p['parent_id']]) && $levels[$p['parent_id']] < 3) $levels[$id] = $levels[$p['parent_id']] + 1;
            }
        }
        $products = array();
        foreach ($levels as $id => $level) if ($level === 3) $products[$by_id[$id]['slug']] = $by_id[$id];

        $production = array(); $other = array(); $seen = array();
        foreach ($terms as $t) {
            $slug = (string)$t->slug;
            if (isset($seen[$slug])) return new WP_Error('pa_pk_duplicate_slug', 'DUPLICATE_CATEGORY_SLUG:' . $slug);
            $seen[$slug] = true;
            $match = null;
            foreach (self::$themes as $theme_slug => $theme_name) {
                $suffix = '-' . $theme_slug;
                if (substr($slug, -strlen($suffix)) === $suffix) {
                    $product_slug = substr($slug, 0, -strlen($suffix));
                    if (isset($products[$product_slug])) { $match = array($product_slug, $theme_name); break; }
                }
            }
            $base = array('term_id'=>intval($t->term_id),'slug'=>$slug,'name'=>(string)$t->name,'wp_parent'=>intval($t->parent),'count'=>intval($t->count));
            if (!$match) { $other[] = $base; continue; }
            list($product_slug, $theme) = $match;
            $product = $products[$product_slug];
            if (!isset($by_id[$product['parent_id']])) return new WP_Error('pa_pk_section_missing','SECTION_PARENT_MISSING:' . $product_slug);
            $section = $by_id[$product['parent_id']];
            if (!isset($by_id[$section['parent_id']])) return new WP_Error('pa_pk_main_missing','MAIN_PARENT_MISSING:' . $product_slug);
            $main = $by_id[$section['parent_id']];
            $base += array(
                'theme'=>$theme,
                'product_slug'=>$product_slug,'product_page_id'=>$product['post_id'],'product'=>$product['title'],
                'section_slug'=>$section['slug'],'section_page_id'=>$section['post_id'],'section'=>$section['title'],
                'main_slug'=>$main['slug'],'main_page_id'=>$main['post_id'],'main'=>$main['title'],
                'portal_path'=>$main['title'].' > '.$section['title'].' > '.$product['title'].' > '.(string)$t->name,
                'active'=>true,
            );
            if ($base['wp_parent'] !== 0) return new WP_Error('pa_pk_nonflat_term','PRODUCTION_CATEGORY_PARENT_NOT_ZERO:' . $slug);
            $production[] = $base;
        }
        usort($production, function($a,$b){ return strcmp($a['slug'],$b['slug']); });
        usort($other, function($a,$b){ return strcmp($a['slug'],$b['slug']); });
        $fingerprint_production = array();
        foreach ($production as $c) {
            $x = $c; unset($x['count'], $x['active']); $fingerprint_production[] = $x;
        }
        $fingerprint_other = array();
        foreach ($other as $c) {
            $x = $c; unset($x['count']); $fingerprint_other[] = $x;
        }
        $fingerprint_payload = array('production_categories'=>$fingerprint_production,'nonproduction_categories'=>$fingerprint_other);
        $fingerprint = hash('sha256', wp_json_encode($fingerprint_payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        return array(
            'counts'=>array('main_hubs'=>8,'section_hubs'=>count(array_filter($levels,function($x){return $x===2;})),'product_pages'=>count($products),'production_categories'=>count($production),'nonproduction_categories'=>count($other)),
            'production_categories'=>$production,
            'nonproduction_categories'=>$other,
            'fingerprint_sha256'=>$fingerprint,
        );
    }

    public static function compare_live() {
        $registry = self::get_registry();
        if (!$registry) return new WP_Error('pa_pk_registry_missing','REGISTRY_MISSING');
        $scan = self::scan_live(); if (is_wp_error($scan)) return $scan;
        $live_active = array(); foreach ($scan['production_categories'] as $c) $live_active[$c['slug']] = $c;
        $reg_active = array(); foreach ($registry['production_categories'] as $c) if (!empty($c['active'])) $reg_active[$c['slug']] = $c;
        return array(
            'missing_in_live'=>array_values(array_diff(array_keys($reg_active),array_keys($live_active))),
            'unexpected_in_live'=>array_values(array_diff(array_keys($live_active),array_keys($reg_active))),
            'registry_version'=>intval($registry['registry_version']),
            'registry_hash'=>(string)$registry['registry_hash'],
        );
    }

    public static function add_category($product_slug, $theme_slug) {
        $registry = self::get_registry(); if (!$registry) return new WP_Error('pa_pk_registry_missing','REGISTRY_MISSING');
        if (!isset(self::$themes[$theme_slug])) return new WP_Error('pa_pk_theme_invalid','THEME_INVALID');
        $pages = get_pages(array('post_status'=>array('publish','draft','private'))); $product = null;
        foreach ($pages as $p) if ((string)$p->post_name === $product_slug) { $product=$p; break; }
        if (!$product) return new WP_Error('pa_pk_product_missing','PRODUCT_PAGE_MISSING');
        $slug = $product_slug . '-' . $theme_slug;
        foreach ($registry['production_categories'] as $c) if ($c['slug'] === $slug && !empty($c['active'])) return new WP_Error('pa_pk_duplicate','CATEGORY_ALREADY_ACTIVE');
        if (term_exists($slug, 'category')) return new WP_Error('pa_pk_term_exists','WORDPRESS_TERM_ALREADY_EXISTS');
        $theme = self::$themes[$theme_slug]; $name = $theme . ' ' . (string)$product->post_title;
        self::snapshot('BEFORE_ADD:' . $slug);
        $insert = wp_insert_term($name, 'category', array('slug'=>$slug,'parent'=>0));
        if (is_wp_error($insert)) return $insert;
        $scan = self::scan_live(); if (is_wp_error($scan)) return $scan;
        $new = null; foreach ($scan['production_categories'] as $c) if ($c['slug'] === $slug) { $new=$c; break; }
        if (!$new) return new WP_Error('pa_pk_add_readback','ADD_READBACK_MISSING');
        $before = self::summary($registry);
        $registry['production_categories'][] = $new;
        usort($registry['production_categories'],function($a,$b){return strcmp($a['slug'],$b['slug']);});
        self::bump_registry($registry);
        self::append_audit('ADD','category',intval($new['term_id']),$before,self::summary($registry));
        return $new;
    }

    public static function retire_category($slug) {
        $registry = self::get_registry(); if (!$registry) return new WP_Error('pa_pk_registry_missing','REGISTRY_MISSING');
        $found=false; $before=self::summary($registry); self::snapshot('BEFORE_RETIRE:' . $slug);
        foreach ($registry['production_categories'] as &$c) if ($c['slug']===$slug && !empty($c['active'])) { $c['active']=false; $c['retired_at_gmt']=gmdate('c'); $found=true; break; }
        unset($c);
        if (!$found) return new WP_Error('pa_pk_not_active','CATEGORY_NOT_ACTIVE');
        self::bump_registry($registry);
        self::append_audit('RETIRE','category',0,$before,self::summary($registry));
        return true;
    }

    public static function delete_retired_category($slug) {
        $registry = self::get_registry(); if (!$registry) return new WP_Error('pa_pk_registry_missing','REGISTRY_MISSING');
        $idx=null; $term_id=0;
        foreach ($registry['production_categories'] as $i=>$c) if ($c['slug']===$slug) { $idx=$i; $term_id=intval($c['term_id']); if (!empty($c['active'])) return new WP_Error('pa_pk_not_retired','CATEGORY_NOT_RETIRED'); break; }
        if ($idx===null) return new WP_Error('pa_pk_not_found','CATEGORY_NOT_FOUND');
        $term=get_term($term_id,'category'); if (is_wp_error($term) || !$term) return new WP_Error('pa_pk_term_missing','WORDPRESS_TERM_MISSING');
        if (intval($term->count)!==0) return new WP_Error('pa_pk_term_in_use','CATEGORY_HAS_POSTS');
        self::snapshot('BEFORE_DELETE:' . $slug); $before=self::summary($registry);
        $res=wp_delete_term($term_id,'category'); if (is_wp_error($res) || !$res) return new WP_Error('pa_pk_delete_failed','WORDPRESS_DELETE_FAILED');
        array_splice($registry['production_categories'],$idx,1);
        self::bump_registry($registry);
        self::append_audit('DELETE','category',$term_id,$before,self::summary($registry));
        return true;
    }

    private static function bump_registry(&$registry) {
        $registry['registry_version'] = intval($registry['registry_version']) + 1;
        $registry['updated_at_gmt'] = gmdate('c');
        $registry['registry_hash'] = self::registry_hash($registry);
        update_option(self::REGISTRY_OPTION, $registry, false);
    }

    private static function registry_hash($registry) {
        $copy=$registry; unset($copy['registry_hash']);
        return hash('sha256', wp_json_encode($copy, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    }

    private static function summary($r) {
        $active=0; foreach ((array)$r['production_categories'] as $c) if (!empty($c['active'])) $active++;
        return array('version'=>intval($r['registry_version']),'active_production_categories'=>$active,'total_registry_categories'=>count((array)$r['production_categories']),'nonproduction_categories'=>count((array)$r['nonproduction_categories']),'hash'=>isset($r['registry_hash'])?$r['registry_hash']:'');
    }

    private static function snapshot($reason) {
        $r=self::get_registry(); if (!$r) return;
        $all=get_option(self::SNAPSHOT_OPTION,array());
        $all[] = array('at_gmt'=>gmdate('c'),'reason'=>$reason,'registry'=>$r);
        update_option(self::SNAPSHOT_OPTION,$all,false);
    }

    private static function append_audit($action,$object_type,$object_id,$before,$after) {
        $log=get_option(self::AUDIT_OPTION,array());
        $log[] = array('at_gmt'=>gmdate('c'),'user_id'=>function_exists('get_current_user_id')?intval(get_current_user_id()):0,'action'=>$action,'object_type'=>$object_type,'object_id'=>intval($object_id),'before'=>$before,'after'=>$after);
        update_option(self::AUDIT_OPTION,$log,false);
    }

    public static function admin_menu() {
        add_menu_page('Pferdeportal Kategorien','Pferdeportal Kategorien','manage_options','pa-pferdeportal-kategorien',array(__CLASS__,'render_admin'),'dashicons-category',58);
    }

    public static function render_admin() {
        if (!current_user_can('manage_options')) return;
        $r=self::get_registry(); $cmp=$r?self::compare_live():null;
        echo '<div class="wrap"><h1>Pferdeportal Kategorien</h1>';
        if (!$r) { echo '<p><strong>Kein gültiges Register initialisiert.</strong></p></div>'; return; }
        $s=self::summary($r);
        echo '<p>Version: <strong>'.esc_html($s['version']).'</strong> · aktiv: <strong>'.esc_html($s['active_production_categories']).'</strong> · Hash: <code>'.esc_html($s['hash']).'</code></p>';
        if (is_wp_error($cmp)) echo '<p><strong>Prüfung fehlgeschlagen:</strong> '.esc_html($cmp->get_error_message()).'</p>';
        else echo '<p>Live-Abweichungen: fehlend '.count($cmp['missing_in_live']).' · unerwartet '.count($cmp['unexpected_in_live']).'</p>';
        echo '<p>Änderungen werden ausschließlich manuell ausgelöst. Vor jeder Änderung wird automatisch ein Fallback-Snapshot gespeichert.</p></div>';
    }

    private static function guard_admin_post() { if (!current_user_can('manage_options')) wp_die('FORBIDDEN'); check_admin_referer('pa_pk_action'); }
    public static function handle_scan() { self::guard_admin_post(); $c=self::compare_live(); wp_safe_redirect(admin_url('admin.php?page=pa-pferdeportal-kategorien')); exit; }
    public static function handle_add_category() { self::guard_admin_post(); self::add_category(sanitize_title(wp_unslash($_POST['product_slug']??'')),sanitize_title(wp_unslash($_POST['theme_slug']??''))); wp_safe_redirect(admin_url('admin.php?page=pa-pferdeportal-kategorien')); exit; }
    public static function handle_retire_category() { self::guard_admin_post(); self::retire_category(sanitize_title(wp_unslash($_POST['slug']??''))); wp_safe_redirect(admin_url('admin.php?page=pa-pferdeportal-kategorien')); exit; }
    public static function handle_delete_category() { self::guard_admin_post(); self::delete_retired_category(sanitize_title(wp_unslash($_POST['slug']??''))); wp_safe_redirect(admin_url('admin.php?page=pa-pferdeportal-kategorien')); exit; }
}

register_activation_hook(__FILE__, array('PA_Pferdeportal_Kategorien','activate'));
add_action('plugins_loaded', array('PA_Pferdeportal_Kategorien','init'));

function pa_pferdeportal_kategorien_registry() { return PA_Pferdeportal_Kategorien::get_registry(); }
function pa_pferdeportal_kategorien_version() { return PA_Pferdeportal_Kategorien::get_version(); }
function pa_pferdeportal_kategorien_hash() { return PA_Pferdeportal_Kategorien::get_hash(); }
