# VERBINDLICHE STEUERDATEI – ALLGEMEINGÜLTIGER KATEGORIE-MASTER 016

## Master Lock
Einzige aktive Vertrags-ID: `ALLGEMEINGUELTIGER_KATEGORIE_MASTER_016_WORKFLOW_HARDLOCK`. Verbindliche Quellen stehen ausschließlich in `15_WORKFLOW_HARDLOCK/MASTER_LOCK.json`. Widerspruch zwischen aktiven Quellen = `MASTER_CONTRACT_CONFLICT / BLOCKED`; niemals selbst auflösen oder raten.

## Zwingender Ablauf
Es gilt ohne Abweichung `15_WORKFLOW_HARDLOCK/VERBINDLICHER_WORKFLOW_14_STUFEN.md`: MASTER LOCK → PROJECT CONTRACT → INITIAL TREE → INITIAL VISIBLE REVIEW → FREE PREFLIGHT → GLOBAL COVERAGE → GLOBAL GAP DECISION → GLOBAL GAP VISIBLE REVIEW → DETAIL PREFLIGHT → DETAIL RESEARCH → DATA-INFORMED CORRECTION → READ-ONLY TOTAL AUDIT → FINAL VISIBLE REVIEW → FINAL VALIDATION.

## Harte Grenzen
- Drei Säulen: Content, HivePress/Marketplace, Journal.
- Content darf fachlich tief sein. Letzte verbindliche Content-Ebene ist eine beitragstragende WP-Kategorie/Taxonomie.
- Tragfähige Content-Kategorie: mindestens 3 wichtige eigenständige node-gebundene DataForSEO-Longtails. FAQ/Tipps/Beratung/Vergleich/Ausrüstung usw. dürfen bei gleicher Mindestsubstanz Kategorien sein.
- DataForSEO = Evidenz/Gate, niemals Architektur-Owner.
- Identischer sichtbarer Kategoriename portalweit = BLOCK.
- Journal bleibt flach und wird nicht als Content-Hierarchie gespiegelt.
- Review-Status/Hash ohne gültige Serversignatur = BLOCK.
- Fehlender Beleg = BLOCKED/REVIEW, niemals geraten.
- Keine WordPress-/HivePress-Content-Writes.
