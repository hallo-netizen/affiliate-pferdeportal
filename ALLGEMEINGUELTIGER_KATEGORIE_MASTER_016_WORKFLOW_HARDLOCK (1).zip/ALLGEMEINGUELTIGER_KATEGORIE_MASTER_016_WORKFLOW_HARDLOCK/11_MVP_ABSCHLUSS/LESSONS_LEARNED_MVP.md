# Lessons Learned des MVP-Projekts

1. Objektive harte Regeln müssen vor Pilotbeginn feststehen.
2. Qualitative Scores brauchen feste Anker, Belege und Begründungen.
3. Generische Textbausteine erfüllen keine Mindestsubstanz.
4. Technische Korrektheit und inhaltliche Qualität müssen getrennt geprüft werden.
5. Maximal zwei Korrekturrunden verhindern Endlosschleifen.
6. Statusdateien müssen in jedem Paket vollständig synchronisiert werden.
7. Prüfdateien müssen dieselben Referenzwerte wie die aktiven Ergebnisdateien verwenden.
8. Virtuelle Pilotportale reichen für die Architekturprüfung aus.
9. Schreibfunktionen benötigen zwingend reale Testumgebung und unabhängige menschliche Prüfung.
10. Das Pferde Atelier darf ohne ausdrückliche Freigabe nicht verändert werden.
