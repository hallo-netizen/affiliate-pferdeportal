# Technische Übergabe

## Einstieg

1. `KATEGORIE_MVP_MASTER_008.md`
2. `11_MVP_ABSCHLUSS/FINALER_MVP_FUNKTIONSUMFANG.md`
3. `02_REGELWERK/REGELWERK_AKTIV.md`
4. `05_PRUEFSYSTEM/MVP_PRUEFSYSTEM.md`
5. `04_DATENMODELL/VIRTUELLES_PORTALMODELL.json`
6. `09_PILOTPORTALE/`
7. `10_BEWERTUNG/`
8. `11_MVP_ABSCHLUSS/FINAL_DECISION.json`

## Aktiver Produktkern

- rein lesende Recherche- und Strukturierungslogik
- virtuelle Modellierung
- Konfliktprüfung
- harte Regeln
- qualitative Rubrik
- Exporte

## Archiv

Historische Schreibkerne und alte Masterstände befinden sich ausschließlich unter `90_ARCHIV`.

## Verbot

Historische Plugins nicht installieren und nicht als aktiven MVP behandeln.
