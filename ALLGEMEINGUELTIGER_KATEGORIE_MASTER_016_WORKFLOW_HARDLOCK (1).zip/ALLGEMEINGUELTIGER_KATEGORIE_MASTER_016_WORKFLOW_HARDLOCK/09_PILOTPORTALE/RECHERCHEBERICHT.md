# Recherchebericht zu den virtuellen Piloten

## Vorgehen

Für jedes Thema wurden aktuelle öffentlich zugängliche Fach- und Marktquellen
verwendet. Die Quellen dienen zur Ermittlung realer Themenfelder, Anbieterarten,
Pflege- und Planungsfragen. Sie ersetzen keine kostenpflichtige Keyworddatenbank.

## Pilot A – Wohnmobile

Die Struktur berücksichtigt Fahrzeugtypen, Kauf, Miete, laufende Kosten,
Versicherung, Technik, Stell- und Campingplätze sowie Reisevorbereitung.

## Pilot B – Hochzeitsdienstleister

Die Struktur bildet eine echte Dienstleistungs- und Vermittlungslogik ab:
Locations, Foto/Video, Musik, Trauung, Planung, Catering, Floristik, Styling,
Papeterie und Transport. Content und Magazin bleiben von Anbieterprofilen getrennt.

## Pilot C – Zimmerpflanzen für dunkle Räume

Die Struktur bleibt bewusst schmal. Sie konzentriert sich auf geeignete Arten,
Standort, Licht, Pflege, typische Probleme, Pflanzenlampen und begrenzte
Transaktionsangebote. Ein Glossar wurde nicht künstlich erzwungen.

## Grenze

Die endgültige fachliche, SEO-bezogene und qualitative Bewertung erfolgt in
Schritt 4 anhand des festgelegten 100-Punkte-Prüfsystems.
