# Virtuelles Pilotportal – Hochzeitsdienstleister

Strukturtyp: **Dienstleistungs-/Expertenvermittlung**

Status: `ERZEUGT – CLAUDE-CHECK SCHRITT 3 AUSSTEHEND`

Keine Website, keine Installation und keine Schreibzugriffe wurden verwendet.

## Content

- **Hochzeit planen** — `hochzeit-planen`
  - **Budget planen** — `budget-planen`
  - **Zeitplan** — `zeitplan`
  - **Gästeliste** — `gaesteliste`
  - **Dienstleister koordinieren** — `dienstleister-koordinieren`
- **Dienstleister wählen** — `dienstleister-waehlen`
  - **Angebote vergleichen** — `angebote-vergleichen`
  - **Referenzen prüfen** — `referenzen-pruefen`
  - **Kennenlerngespräch** — `kennenlerngespraech`
  - **Buchungszeitpunkt** — `buchungszeitpunkt`
- **Verträge & Kosten** — `vertraege-und-kosten`
  - **Leistungsumfang** — `leistungsumfang`
  - **Zahlungsplan** — `zahlungsplan`
  - **Stornierung** — `stornierung`
  - **Ausfallregelung** — `ausfallregelung`
- **Hochzeitskonzept** — `hochzeitskonzept`
  - **Stil & Farben** — `stil-und-farben`
  - **Tagesablauf** — `tagesablauf`
  - **Trauung** — `trauung`
  - **Feier** — `feier`
- **Regionale Suche** — `regionale-suche`
  - **Dienstleister in der Nähe** — `dienstleister-in-der-naehe`
  - **Anfahrtskosten** — `anfahrtskosten`
  - **Verfügbarkeit** — `verfuegbarkeit`
  - **Vor-Ort-Termine** — `vor-ort-termine`

## Marketplace

- **Locations** — `locations`
  - **Schlösser & Gutshöfe** — `schloesser-und-gutshoefe`
  - **Hotels & Restaurants** — `hotels-und-restaurants`
  - **Scheunen & Höfe** — `scheunen-und-hoefe`
  - **Freie Locations** — `freie-locations`
- **Foto & Video** — `foto-und-video`
  - **Hochzeitsfotografen** — `hochzeitsfotografen`
  - **Videografen** — `videografen`
  - **Fotoboxen** — `fotoboxen`
- **Musik & Unterhaltung** — `musik-und-unterhaltung`
  - **Hochzeits-DJs** — `hochzeits-djs`
  - **Livebands** — `livebands`
  - **Solomusiker** — `solomusiker`
  - **Kinderbetreuung** — `kinderbetreuung`
- **Trauung & Planung** — `trauung-und-planung`
  - **Trauredner** — `trauredner`
  - **Hochzeitsplaner** — `hochzeitsplaner`
  - **Zeremonienmeister** — `zeremonienmeister`
- **Essen & Trinken** — `essen-und-trinken`
  - **Catering** — `catering`
  - **Hochzeitstorten** — `hochzeitstorten`
  - **Mobile Bars** — `mobile-bars`
- **Floristik & Dekoration** — `floristik-und-dekoration`
  - **Floristen** — `floristen`
  - **Dekoverleih** — `dekoverleih`
  - **Eventdesign** — `eventdesign`
  - **Lichttechnik** — `lichttechnik`
- **Styling & Mode** — `styling-und-mode`
  - **Brautstyling** — `brautstyling`
  - **Make-up & Haare** — `make-up-und-haare`
  - **Brautmode** — `brautmode`
  - **Herrenausstattung** — `herrenausstattung`
- **Papeterie & Details** — `papeterie-und-details`
  - **Einladungen** — `einladungen`
  - **Beschilderung** — `beschilderung`
  - **Gastgeschenke** — `gastgeschenke`
  - **Trauringe** — `trauringe`
- **Fahrzeuge** — `fahrzeuge`
  - **Hochzeitsautos** — `hochzeitsautos`
  - **Shuttleservice** — `shuttleservice`
  - **Kutschen** — `kutschen`

## Magazine

- **Planungswissen** — `planungswissen`
  - **Budget** — `budget`
  - **Zeitplanung** — `zeitplanung`
  - **Checklisten** — `checklisten`
  - **Dienstleisterbriefing** — `dienstleisterbriefing`
- **Trauung** — `trauung`
  - **Standesamt** — `standesamt`
  - **Freie Trauung** — `freie-trauung`
  - **Kirchliche Trauung** — `kirchliche-trauung`
  - **Rituale** — `rituale`
- **Feier** — `feier`
  - **Ablauf** — `ablauf`
  - **Musik** — `musik`
  - **Essen & Getränke** — `essen-und-getraenke`
  - **Gästeunterhaltung** — `gaesteunterhaltung`
- **Stilwelten** — `stilwelten`
  - **Klassisch** — `klassisch`
  - **Modern** — `modern`
  - **Boho** — `boho`
  - **Urban** — `urban`
- **Erfahrungen** — `erfahrungen`
  - **Echte Hochzeiten** — `echte-hochzeiten`
  - **Dienstleisterinterviews** — `dienstleisterinterviews`
  - **Planungspannen** — `planungspannen`
  - **Nach der Hochzeit** — `nach-der-hochzeit`

## Glossary

- **Planungsbegriffe** — `planungsbegriffe`
  - **Save the Date** — `save-the-date`
  - **First Look** — `first-look`
  - **Getting Ready** — `getting-ready`
  - **Wedding Planner** — `wedding-planner`
- **Vertragsbegriffe** — `vertragsbegriffe`
  - **Anzahlung** — `anzahlung`
  - **Ausfallhonorar** — `ausfallhonorar`
  - **Nutzungsrechte** — `nutzungsrechte`
  - **Exklusivbindung** — `exklusivbindung`

## Annahmen und Grenzen

- Keine kostenpflichtigen Keyword-Volumendaten in Schritt 3.
- Die formale Qualitätsbewertung erfolgt erst in Schritt 4.
- Artikelideen sind Potenzialnachweise, keine verbindlichen Redaktionsaufträge.
