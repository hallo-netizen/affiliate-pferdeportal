# Virtuelles Pilotportal – Zimmerpflanzen für dunkle Räume

Strukturtyp: **schmales Nischenthema**

Status: `ERZEUGT – CLAUDE-CHECK SCHRITT 3 AUSSTEHEND`

Keine Website, keine Installation und keine Schreibzugriffe wurden verwendet.

## Content

- **Pflanzen auswählen** — `pflanzen-auswaehlen`
  - **Sehr wenig Licht** — `sehr-wenig-licht`
  - **Nordfenster** — `nordfenster`
  - **Flur & Treppenhaus** — `flur-und-treppenhaus`
  - **Bad ohne Sonne** — `bad-ohne-sonne`
- **Geeignete Pflanzen** — `geeignete-pflanzen`
  - **Bogenhanf** — `bogenhanf`
  - **Schusterpalme** — `schusterpalme`
  - **Einblatt** — `einblatt`
  - **Efeutute** — `efeutute`
  - **Zamioculcas** — `zamioculcas`
- **Pflege bei wenig Licht** — `pflege-bei-wenig-licht`
  - **Richtig gießen** — `richtig-giessen`
  - **Düngen** — `duengen`
  - **Umtopfen** — `umtopfen`
  - **Blätter pflegen** — `blaetter-pflegen`
- **Licht verbessern** — `licht-verbessern`
  - **Pflanzenlampen** — `pflanzenlampen`
  - **Standort optimieren** — `standort-optimieren`
  - **Licht messen** — `licht-messen`
  - **Winterstandort** — `winterstandort`
- **Probleme erkennen** — `probleme-erkennen`
  - **Gelbe Blätter** — `gelbe-blaetter`
  - **Lange Triebe** — `lange-triebe`
  - **Wurzelfäule** — `wurzelfaeule`
  - **Schädlinge** — `schaedlinge`

## Marketplace

- **Schattenpflanzen** — `schattenpflanzen`
  - **Kleine Pflanzen** — `kleine-pflanzen`
  - **Große Pflanzen** — `grosse-pflanzen`
  - **Hängepflanzen** — `haengepflanzen`
- **Pflanzenlampen** — `pflanzenlampen`
  - **LED-Pflanzenlampen** — `led-pflanzenlampen`
  - **Klemmleuchten** — `klemmleuchten`
  - **Zeitschaltlösungen** — `zeitschaltloesungen`
- **Pflegezubehör** — `pflegezubehoer`
  - **Feuchtigkeitsmesser** — `feuchtigkeitsmesser`
  - **Übertöpfe** — `uebertoepfe`
  - **Substrate** — `substrate`
- **Pflanzenberatung** — `pflanzenberatung`
  - **Online-Beratung** — `online-beratung`
  - **Vor-Ort-Beratung** — `vor-ort-beratung`

## Magazine

- **Pflanzenporträts** — `pflanzenportraets`
  - **Bogenhanf** — `bogenhanf`
  - **Schusterpalme** — `schusterpalme`
  - **Einblatt** — `einblatt`
  - **Efeutute** — `efeutute`
- **Lichtwissen** — `lichtwissen`
  - **Was wenig Licht bedeutet** — `was-wenig-licht-bedeutet`
  - **Lichtstärke verstehen** — `lichtstaerke-verstehen`
  - **Kunstlicht** — `kunstlicht`
  - **Jahreszeiten** — `jahreszeiten`
- **Pflegewissen** — `pflegewissen`
  - **Gießen im Schatten** — `giessen-im-schatten`
  - **Düngen bei wenig Wachstum** — `duengen-bei-wenig-wachstum`
  - **Luftfeuchtigkeit** — `luftfeuchtigkeit`
  - **Winterpflege** — `winterpflege`
- **Raumideen** — `raumideen`
  - **Dunkler Flur** — `dunkler-flur`
  - **Schlafzimmer** — `schlafzimmer`
  - **Badezimmer** — `badezimmer`
  - **Büro** — `buero`
- **Pflanzenprobleme** — `pflanzenprobleme`
  - **Lichtmangel** — `lichtmangel`
  - **Staunässe** — `staunaesse`
  - **Schädlinge** — `schaedlinge`
  - **Wachstumsstopp** — `wachstumsstopp`

## Annahmen und Grenzen

- Keine kostenpflichtigen Keyword-Volumendaten in Schritt 3.
- Die formale Qualitätsbewertung erfolgt erst in Schritt 4.
- Artikelideen sind Potenzialnachweise, keine verbindlichen Redaktionsaufträge.
