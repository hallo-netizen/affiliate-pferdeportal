# Virtuelles Pilotportal – Wohnmobile

Strukturtyp: **breites Produkt-/Konsumthema**

Status: `ERZEUGT – CLAUDE-CHECK SCHRITT 3 AUSSTEHEND`

Keine Website, keine Installation und keine Schreibzugriffe wurden verwendet.

## Content

- **Fahrzeugwahl** — `fahrzeugwahl`
  - **Campervans** — `campervans`
  - **Kastenwagen** — `kastenwagen`
  - **Teilintegrierte** — `teilintegrierte`
  - **Vollintegrierte** — `vollintegrierte`
  - **Alkoven** — `alkoven`
- **Wohnmobil kaufen** — `wohnmobil-kaufen`
  - **Neuwagen** — `neuwagen`
  - **Gebrauchtwagen** — `gebrauchtwagen`
  - **Finanzierung** — `finanzierung`
  - **Kaufprüfung** — `kaufpruefung`
- **Wohnmobil mieten** — `wohnmobil-mieten`
  - **Mietmodelle** — `mietmodelle`
  - **Mietvertrag** — `mietvertrag`
  - **Versicherung bei Miete** — `versicherung-bei-miete`
  - **Übergabe & Rückgabe** — `uebergabe-und-rueckgabe`
- **Technik** — `technik`
  - **Stromversorgung** — `stromversorgung`
  - **Wasser & Sanitär** — `wasser-und-sanitaer`
  - **Heizung & Klima** — `heizung-und-klima`
  - **Gasversorgung** — `gasversorgung`
  - **Fahrwerk & Reifen** — `fahrwerk-und-reifen`
- **Ausstattung** — `ausstattung`
  - **Küche** — `kueche`
  - **Schlafen** — `schlafen`
  - **Sicherheit** — `sicherheit`
  - **Internet unterwegs** — `internet-unterwegs`
  - **Campingmöbel** — `campingmoebel`
- **Reisen** — `reisen`
  - **Stellplätze** — `stellplaetze`
  - **Campingplätze** — `campingplaetze`
  - **Routenplanung** — `routenplanung`
  - **Reisen mit Kindern** — `reisen-mit-kindern`
  - **Reisen mit Hund** — `reisen-mit-hund`

## Marketplace

- **Wohnmobile** — `wohnmobile`
  - **Wohnmobile kaufen** — `wohnmobile-kaufen`
  - **Wohnmobile mieten** — `wohnmobile-mieten`
- **Stellplätze** — `stellplaetze`
  - **Stellplätze privat** — `stellplaetze-privat`
  - **Stellplätze gewerblich** — `stellplaetze-gewerblich`
- **Werkstätten** — `werkstaetten`
  - **Wohnmobilwerkstätten** — `wohnmobilwerkstaetten`
  - **Dichtigkeitsprüfung** — `dichtigkeitspruefung`
  - **Aufbau & Umbau** — `aufbau-und-umbau`
- **Vermietung & Service** — `vermietung-und-service`
  - **Vermietstationen** — `vermietstationen`
  - **Einlagerung** — `einlagerung`
  - **Reinigung & Pflege** — `reinigung-und-pflege`
- **Zubehöranbieter** — `zubehoeranbieter`
  - **Technikzubehör** — `technikzubehoer`
  - **Innenausstattung** — `innenausstattung`
  - **Outdoor-Zubehör** — `outdoor-zubehoer`

## Magazine

- **Camper-Einstieg** — `camper-einstieg`
  - **Erste Reise** — `erste-reise`
  - **Fahrzeugtypen erklärt** — `fahrzeugtypen-erklaert`
  - **Packlisten** — `packlisten`
  - **Anfängerfehler** — `anfaengerfehler`
- **Reiseziele** — `reiseziele`
  - **Deutschland** — `deutschland`
  - **Europa** — `europa`
  - **Städtereisen** — `staedtereisen`
  - **Wintercamping** — `wintercamping`
- **Recht & Kosten** — `recht-und-kosten`
  - **Verkehrsregeln** — `verkehrsregeln`
  - **Übernachten & Parken** — `uebernachten-und-parken`
  - **Versicherung** — `versicherung`
  - **Reisekosten** — `reisekosten`
- **Werkstattwissen** — `werkstattwissen`
  - **Wartung** — `wartung`
  - **Feuchtigkeit** — `feuchtigkeit`
  - **Winterfest machen** — `winterfest-machen`
  - **Pannenhilfe** — `pannenhilfe`
- **Camperleben** — `camperleben`
  - **Kochen unterwegs** — `kochen-unterwegs`
  - **Ordnung & Stauraum** — `ordnung-und-stauraum`
  - **Familie** — `familie`
  - **Haustiere** — `haustiere`

## Glossary

- **Fahrzeugbegriffe** — `fahrzeugbegriffe`
  - **Zuladung** — `zuladung`
  - **Masse in fahrbereitem Zustand** — `masse-in-fahrbereitem-zustand`
  - **Dichtigkeitsprüfung** — `dichtigkeitspruefung`
  - **Autarkie** — `autarkie`
- **Campingbegriffe** — `campingbegriffe`
  - **Stellplatz** — `stellplatz`
  - **Campingplatz** — `campingplatz`
  - **Grauwasser** — `grauwasser`
  - **Landstrom** — `landstrom`

## Annahmen und Grenzen

- Keine kostenpflichtigen Keyword-Volumendaten in Schritt 3.
- Die formale Qualitätsbewertung erfolgt erst in Schritt 4.
- Artikelideen sind Potenzialnachweise, keine verbindlichen Redaktionsaufträge.
