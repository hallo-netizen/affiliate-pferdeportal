> **HISTORISCH / NICHT NORMATIV IN MASTER 016.** Diese Datei dokumentiert einen früheren Stand. Aktive Regeln und Workflow stehen ausschließlich in `15_WORKFLOW_HARDLOCK/MASTER_LOCK.json`; historische 4-Longtail-Anforderungen sind Übererfüllung, aktiv gilt 3.

# Vollständiger Fehler-/Ursachenkatalog des DataForSEO-Integrationsblocks

## E-001 – Zu offene Funktion „Thema recherchieren“
**Problem:** Ein breiter Begriff wie „Essen“ kann fachlich völlig verschiedene Räume öffnen.
**Ursache:** Discovery wurde zu nah an einer Einzelphrase statt an einem abgegrenzten Projektkonzept gedacht.
**Korrektur:** Projektkonzept + Scope + Ausschlüsse + konzeptbasierte Discovery-Seeds. Projektname wird nicht autonomer Seed.

## E-002 – DataForSEO drohte zum Architektur-Owner zu werden
**Problem:** API-Daten könnten fälschlich selbst Kategorien erzeugen/umbauen.
**Korrektur:** DataForSEO ist ausschließlich Research-/Evidenzgate. Architekturentscheidungen bleiben Chat/Master.

## E-003 – Komplett vergessenes Hauptthema blieb unsichtbar
**Problem:** Nur clusterweise Detailrecherche kann nur das finden, wofür bereits Cluster existieren.
**Korrektur:** vorgelagertes projektweites Global-Coverage-Gate.

## E-004 – Global-Coverage hätte unnötig mehrfach bezahlt werden können
**Korrektur:** Global-Scope bindet Projekt-ID, Scope, Ausschlüsse und Discovery-Seeds. Kategorie-/Clusterkorrekturen dürfen dieselbe Global-Coverage wiederverwenden, solange dieser Projektscope unverändert bleibt.

## E-005 – Nur Suchvolumen als Coverage-Signal wäre zu eng
**Korrektur:** Provider-Relevanz + Suchvolumen werden gemeinsam genutzt. Kein starrer Mindestwert entscheidet allein.

## E-006 – Starke Kategorienamen/bessere Alternativen mussten explizit Gate werden
**Korrektur:** sichtbarer Name und Primärkeyword werden belegt; stärkere intentkompatible Kandidaten erzeugen Korrektur-/Begründungspflicht.

## E-007 – Wichtige unbesetzte Keywordgruppen
**Korrektur:** relevante Core-Gruppen müssen einen Owner oder eine dokumentierte Nicht-Kategorieentscheidung besitzen.

## E-008 – Longtails durften nicht nur dekorative KI-Vorschläge sein
**Korrektur:** Content-Blätter benötigen mindestens vier reale, providerbelegte, node-gebundene Longtails; doppelte Ownership/Primary-Kollision blockiert.

## E-009 – Semantische Ähnlichkeit wurde zeitweise zu hart als Dublette gedacht
**Nutzerentscheidung:** Inhaltlich ähnliche Kategorien dürfen über Content, Journal und Anzeigen sinnvoll sein.
**Korrektur:** Nur identischer sichtbarer Kategoriename ist portalweit hart BLOCK. Ähnliche anders benannte Säulen sind mit funktionaler Trennung zulässig.

## E-010 – Technischer PASS hätte als FINAL missverstanden werden können
**Korrektur:** `READY_FOR_VISIBLE_SIGHT_REVIEW` ist eigener Status; ohne sichtbare Gesamtbaumprüfung kein FINAL.

## E-011 – Strukturänderung nach Sichtfreigabe
**Risiko:** Nutzer prüft Baum A, final wird unbemerkt Baum B.
**Korrektur:** `review_scope_sha256`; jede inhaltliche Änderung invalidiert die Sichtfreigabe.

## E-012 – FINAL_APPROVED-Modus konnte beim ersten Einbau theoretisch schwächere Evidenzgates erhalten
**Befund im harten lokalen Audit:** `ResearchEvidence` prüfte final relevante Fehler zunächst nur bei `READ_ONLY_PREVIEW`.
**Korrektur:** sämtliche DataForSEO-, Longtail-, Hierarchie-, Gap- und Cannibalization-Gates gelten identisch für `READ_ONLY_PREVIEW` und `FINAL_APPROVED`. Expliziter Negativtest verhindert Regression.

## E-013 – Parallelplugin-/Neusystem-Risiko
**Korrektur:** V1.4 ist Update derselben V1.3-Pluginlinie mit identischem Namen/Slug. Basiskomponenten Settings, Inventory und Comparator sind gegenüber V1.3 byteidentisch; kein Parallelplugin.

## E-014 – Portal-Schreibpfade im Research-Gate wären unzulässig
**Korrektur/Nachweis:** `APKW_CONTENT_WRITE_CAPABILITY=false`; statischer Scan der Produktionsdateien findet keine WordPress-/Taxonomie-/Menü-Content-Schreib-APIs.
