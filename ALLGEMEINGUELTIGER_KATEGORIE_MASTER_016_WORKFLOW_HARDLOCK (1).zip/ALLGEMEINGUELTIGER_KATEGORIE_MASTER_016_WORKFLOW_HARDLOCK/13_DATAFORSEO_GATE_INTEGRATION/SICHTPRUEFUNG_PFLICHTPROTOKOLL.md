# Pflichtprotokoll – sichtbare gemeinsame Prüfung vor FINAL

## Zweck
Die API kann Suchdaten liefern, aber keine vollständige menschliche Portalplausibilität garantieren. Deshalb ist die Sichtprüfung kein optionaler Komfortschritt, sondern ein hartes Final-Gate.

## Eingabe
- korrigiertes `READ_ONLY_PREVIEW`-Strukturpaket,
- gebundenes Research-Paket,
- Pluginstatus `READY_FOR_VISIBLE_SIGHT_REVIEW`,
- vom Plugin berechneter `review_scope_sha256`.

## Im Chat sichtbar zeigen
Der Baum muss vollständig nach Säulen und Hierarchie lesbar dargestellt werden:
1. Content,
2. Marketplace/HivePress,
3. Journal.

Nicht nur Fehlerlisten oder Statistik.

## Gemeinsam prüfen
- Fehlt ein Hauptthema?
- Fehlt eine sinnvolle Unterkategorie?
- Ist etwas zu dünn, zu breit oder unnötig tief?
- Sind Kategorien verständlich benannt?
- Sind ähnliche Bereiche wirklich unterschiedlich genug?
- Sind die drei Säulen funktional klar getrennt?
- Gibt es sinnvolle Ergänzungen/Querverbindungen, die DataForSEO nicht allein entscheiden kann?
- Sind bewusste Ausschlüsse weiterhin richtig?

## Ergebnis
### Änderungen nötig
Struktur korrigieren → erneut read-only prüfen → neue Sichtprüfung des geänderten Review-Scope.

### Sichtfreigabe
Nur nach ausdrücklicher Nutzerfreigabe wird `human_sight_review` ergänzt:
- `status = APPROVED_AFTER_VISIBLE_REVIEW`
- `review_scope_sha256 = exakt der geprüfte Hash`
- `approved_at_utc`
- `review_summary`

## Harte Sperre
Eine Freigabe darf niemals DataForSEO-Evidenzmängel, fehlende Longtails, ungeklärte Keywordgruppen oder Kannibalisierungsfehler überstimmen.
