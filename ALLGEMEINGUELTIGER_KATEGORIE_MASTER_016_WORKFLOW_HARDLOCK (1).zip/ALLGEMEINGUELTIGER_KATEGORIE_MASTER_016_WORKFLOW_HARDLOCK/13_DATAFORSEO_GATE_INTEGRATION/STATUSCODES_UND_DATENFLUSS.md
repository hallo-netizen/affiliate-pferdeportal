# Statuscodes und Datenfluss

## Strukturpaket-Modi
- `RESEARCH_DRAFT` – fachlicher Erst-/Korrekturentwurf vor finaler Research-Bindung.
- `READ_ONLY_PREVIEW` – korrigierter Stand mit Research-Bindung; vollständig technisch/DataForSEO geprüft, aber noch nicht menschlich final freigegeben.
- `FINAL_APPROVED` – exakt sichtgeprüfter, hashgebundener Strukturstand.

## Plugin-Endstatus
- `BLOCKED` – mindestens ein hartes Gate verletzt.
- `READY_FOR_VISIBLE_SIGHT_REVIEW` – technische/DataForSEO-/Bestandsprüfung PASS; menschliche Gesamtbaumprüfung fehlt noch.
- `PASS_FINAL_APPROVED` – alle Gates PASS und Sichtfreigabe passt zum unveränderten Review-Scope.

## Research-Stufen
1. `RESEARCH_DRAFT` + project.discovery_seed_keywords
2. `GLOBAL_COVERAGE_PACKAGE`
3. korrigierter `RESEARCH_DRAFT` + global_coverage_decisions
4. `RESEARCH_PACKAGE` mit Global-Coverage + Keyword Overview + Cluster Keyword Ideas
5. `READ_ONLY_PREVIEW`
6. sichtbare Chat-Prüfung
7. `FINAL_APPROVED`
