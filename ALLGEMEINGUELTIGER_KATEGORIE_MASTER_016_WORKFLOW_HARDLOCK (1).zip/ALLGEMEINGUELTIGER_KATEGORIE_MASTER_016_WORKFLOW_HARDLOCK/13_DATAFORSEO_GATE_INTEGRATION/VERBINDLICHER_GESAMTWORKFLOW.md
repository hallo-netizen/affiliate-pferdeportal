> **HISTORISCH / NICHT NORMATIV IN MASTER 016.** Diese Datei dokumentiert einen früheren Stand. Aktive Regeln und Workflow stehen ausschließlich in `15_WORKFLOW_HARDLOCK/MASTER_LOCK.json`; historische 4-Longtail-Anforderungen sind Übererfüllung, aktiv gilt 3.

# Verbindlicher Gesamtworkflow – DataForSEO-Gate im bestehenden Kategoriesystem

## Kurzform

**Projektkonzept → eigener 3-Säulen-Entwurf → Global-Coverage → Hauptthemen-Korrektur → Detailresearch → Keyword-/Hierarchie-/Longtail-/Kannibalisierungskorrektur → read-only Gesamtprüfung → sichtbare gemeinsame Baumprüfung → hashgebundene FINAL-Freigabe.**

## 1. Projektkonzept
Der Nutzer liefert ein fachlich abgegrenztes Konzept, keine bloße beliebig breite Einzelphrase. Chat/Master definieren Scope, Ausschlüsse und mehrere fachlich sinnvolle Discovery-Seeds. Ein Projektname wird nicht automatisch als Seed benutzt.

## 2. Eigenständiger Drei-Säulen-Erstentwurf
Chat/Master bauen bereits vor DataForSEO mit fachlichem Urteilsvermögen:
- Content,
- Marketplace/HivePress,
- Journal,
- Hauptthemen, Unterthemen, Hierarchie, Primärkeywords, Intents und Research-Cluster.

DataForSEO ersetzt diesen Architekturentwurf nicht.

## 3. Kostenfreier lokaler Preflight
0 externe Requests. Geprüft werden Schema, drei Pflichtsäulen, IDs, Hierarchie, Seeds, sichtbare Namensdubletten, Keyword-Ownership und technische Zielkollisionen.

## 4. Global-Coverage
Genau 1 ausdrücklich bestätigter Keyword-Ideas-Call mit den deklarierten projektweiten Discovery-Seeds. Zweck: komplett übersehene große Themenfelder finden. Relevante unentschiedene Global-Gaps blockieren Detailresearch.

## 5. Hauptthemen-Korrektur
Chat/Master entscheiden jeden relevanten globalen Befund: einarbeiten als Haupt-/Unterthema, als Artikel führen, außerhalb Scope setzen oder bewusst deferieren. DataForSEO fügt nichts autonom ein.

## 6. Detailresearch
Nach kostenfreiem Preflight und ausdrücklicher Kostenbestätigung:
- Keyword Overview für sichtbare Kategorienamen/Primärkeywords,
- 1 Keyword-Ideas-Call je deklariertem Research-Cluster,
- Wiederverwendung der Global-Coverage ohne erneuten Global-Call.

## 7. Korrektur anhand DataForSEO
Geprüft und fachlich entschieden werden:
- ist der Kategoriename ein starkes/passendes Keyword?
- gibt es eine bessere, stärkere intentkompatible Bezeichnung?
- fehlen wichtige Keywordgruppen/Unterthemen?
- stimmt Parent → Child?
- stimmt Search Intent?
- besitzt jedes Content-Blatt mindestens vier reale node-gebundene Longtails?
- entsteht unbeabsichtigte Kannibalisierung?

## 8. Dubletten-/Overlap-Regel
- identischer sichtbarer Kategoriename portalweit = BLOCK;
- ähnliche Inhalte mit unterschiedlichen sichtbaren Namen = erlaubt, wenn fachlich/funktional sinnvoll;
- gleiche Primärkeyword-Ownership innerhalb derselben Säule = BLOCK;
- säulenübergreifende ähnliche Core-Themen = REVIEW + Trennbegründung, kein automatischer Merge.

## 9. Read-only Gesamtprüfung
Plugin prüft Struktur + Research-Evidenz + aktuellen WordPress-Bestand. 0 DataForSEO-Requests, 0 Portal-Content-Writes. Ein PASS ist nur `READY_FOR_VISIBLE_SIGHT_REVIEW`.

## 10. Sichtbare gemeinsame Konzeptprüfung
Der gesamte Content-/Marketplace-/Journal-Baum wird im Chat sichtbar dargestellt. Gemeinsam werden fehlende Haupt-/Unterthemen, zu breite/zu dünne Knoten, menschlich unklare Namen, Säulenlogik, Querverbindungen und zusätzliche Komponenten geprüft.

## 11. Finale Freigabe
Erst nach ausdrücklicher sichtbarer Freigabe darf `FINAL_APPROVED` gesetzt werden. `review_scope_sha256` bindet die Freigabe an den exakt gesehenen Strukturstand. Jede inhaltliche Änderung danach => BLOCK + neue Sichtprüfung.

## 12. FINAL
Nur wenn alle bisherigen DataForSEO-/Workflowgates weiterhin PASS sind und die Sichtfreigabe zum unveränderten Review-Scope passt, lautet der Endstatus `PASS_FINAL_APPROVED`.
