> **HISTORISCH / NICHT NORMATIV IN MASTER 016.** Diese Datei dokumentiert einen früheren Stand. Aktive Regeln und Workflow stehen ausschließlich in `15_WORKFLOW_HARDLOCK/MASTER_LOCK.json`; historische 4-Longtail-Anforderungen sind Übererfüllung, aktiv gilt 3.

# Entscheidungsregister – DataForSEO-Gate

| ID | Verbindliche Entscheidung | Grund |
|---|---|---|
| D-001 | Bestehende V1.3-Pluginlinie erweitern, kein Parallelplugin | Nutzer verlangt bestehendes Plugin als Grundlage |
| D-002 | Drei Pflichtsäulen Content + Marketplace/HivePress + Journal | Kernziel des Kategoriesystems |
| D-003 | DataForSEO ist Gate/Evidenz, nicht autonomer Architekt | fachliche Kontrolle bleibt Chat/Master |
| D-004 | Projektkonzept statt beliebiger Einzelphrase als Startpunkt | vermeidet chaotische Breitrecherche |
| D-005 | Projektweite Global-Coverage vor Detailresearch | schützt gegen komplett vergessene Hauptthemen |
| D-006 | Global-Coverage genau 1 Paid Call pro unverändertem Projektscope | Kostenkontrolle |
| D-007 | Kategoriename selbst gegen starke/bessere Keywords prüfen | sichtbare SEO-Struktur muss belegt sein |
| D-008 | relevante fehlende Keywordgruppen aktiv suchen | Coverage statt bloßer Bestätigung des Entwurfs |
| D-009 | Content-Blätter mindestens 4 reale node-gebundene Longtails | tragfähige unterste Kategorieebene |
| D-010 | identischer sichtbarer Name portalweit BLOCK | Nutzerentscheidung; klare sichtbare Differenzierung |
| D-011 | semantisch ähnliche, anders benannte Säulen erlaubt | unterschiedliche Intention/Funktion kann sinnvoll sein |
| D-012 | technischer PASS ist nicht FINAL | zwingende menschliche Konzeptprüfung |
| D-013 | kompletter Baum vor FINAL sichtbar im Chat | gemeinsame Ergänzungs-/Plausibilitätsprüfung |
| D-014 | Sichtfreigabe per Review-Scope-Hash binden | keine stille Änderung nach Freigabe |
| D-015 | kein Portal-Content-Write im DataForSEO-Gate | Research-/Prüfmodul bleibt read-only |
