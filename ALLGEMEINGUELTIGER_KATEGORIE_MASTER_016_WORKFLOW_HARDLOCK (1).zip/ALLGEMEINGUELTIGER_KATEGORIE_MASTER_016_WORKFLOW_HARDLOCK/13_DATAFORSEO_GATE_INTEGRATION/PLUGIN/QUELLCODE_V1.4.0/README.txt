=== Affiliate-Portal Kategorie-Workflow ===
Version: 1.4.0
Status: TESTKANDIDAT
Plugin-Slug: affiliate-portal-kategorie-workflow

GRUNDLAGE
---------
V1.4.0 ist ein Update derselben bestehenden Plugin-Linie V1.3.0. Kein Parallelplugin, kein zweites Kategoriesystem, keine autonome Portalmaschine.

Der fachliche Kategorieentwurf entsteht weiterhin im Chat mit der verbindlichen Masterdatei. Das Plugin integriert DataForSEO als Research-/Prüf-Gate in diesen bestehenden Workflow.

ZIEL
----
Aus einem fachlich abgegrenzten Projektkonzept entsteht eine starke Portal-Kategoriestruktur mit drei verpflichtenden Säulen:
1. Content
2. Marketplace / HivePress
3. Journal / Magazin

DataForSEO unterstützt und kontrolliert dabei insbesondere:
- Vollständigkeit großer Themenfelder vor der Tiefenrecherche,
- Stärke und Eignung sichtbarer Kategorienamen,
- bessere Keywordalternativen,
- vergessene relevante Keywordgruppen,
- Parent -> Child Keywordhierarchie,
- Search Intent,
- reale Longtails für Content-Blätter,
- Kannibalisierungsrisiken.

VERBINDLICHER ABLAUF
--------------------
1. Nutzer liefert Projektidee/Konzept, Scope und Ausschlüsse.
2. Chat + Master bauen mit fachlicher Eigenprüfung den ersten vollständigen 3-Säulen-RESEARCH_DRAFT.
3. Plugin prüft den Draft lokal und kostenfrei.
4. Global-Coverage-Gate: genau 1 ausdrücklich bestätigter DataForSEO Keyword-Ideas-Aufruf mit ausschließlich deklarierten projektweiten Discovery-Seeds.
5. Chat + Master prüfen globale Lücken. Fehlende Haupt-/Unterthemen werden eingearbeitet oder fachlich dokumentiert. Erst danach darf Detailresearch starten.
6. Detailresearch: Keyword Overview für geplante Kategorienamen/Primärkeywords plus genau 1 Keyword-Ideas-Aufruf je deklariertem Research-Cluster.
7. Chat + Master korrigieren Namen, Keywordzuordnung, Hierarchie, fehlende Gruppen, Longtails und Kannibalisierung.
8. Plugin führt eine harte read-only Prüfung gegen Research-Evidenz und aktuellen WordPress-Bestand aus. Bei PASS lautet der Status zunächst READY_FOR_VISIBLE_SIGHT_REVIEW.
9. Der komplette Baum wird hier im Chat sichtbar gemeinsam geprüft: fehlende Haupt-/Unterthemen, unnötige Tiefe, Säulenlogik, Namen, menschliche Plausibilität und Ergänzungen.
10. Erst nach ausdrücklicher sichtbarer Freigabe wird exakt derselbe Review-Scope als FINAL_APPROVED markiert. Jede nachträgliche Strukturänderung invalidiert die Freigabe und erzwingt eine neue Sichtprüfung.
11. Die finale Freigabeprüfung macht 0 DataForSEO-Abfragen und 0 Portal-Content-Writes.

DUBLETTEN / KANNIBALISIERUNG
----------------------------
- Identischer sichtbarer Kategoriename portalweit: BLOCK.
- Ähnliche Themen mit unterschiedlichen sichtbaren Namen: erlaubt, wenn fachlich/funktional sinnvoll.
- Gleiches Primärkeyword innerhalb derselben Säule: BLOCK.
- Gleiches Primärkeyword säulenübergreifend + gleiche deklarierte Suchintention: BLOCK.
- Gleicher/ähnlicher DataForSEO-Core über Säulen: REVIEW, nicht automatisch MERGE; final ist eine belastbare Trennbegründung nötig.

DATAFORSEO IST EIN GATE, NICHT DER ARCHITEKT
-------------------------------------------
Das Plugin erzeugt, löscht, verschiebt oder benennt Kategorien nicht automatisch um. DataForSEO liefert Evidenz und Lücken-/Konfliktsignale. Architekturentscheidungen bleiben Chat/Master-Aufgabe.

KOSTENKONTROLLE
---------------
- Verbindungstest über /v3/appendix/user_data: eigener kostenfreier Test; unerwartete Providerkosten => BLOCKED.
- Alle Preflights: 0 externe Requests.
- Global-Coverage: genau 1 Paid Call nach ausdrücklicher Bestätigung.
- Detailresearch: geplante Anzahl Paid Calls wird vorher angezeigt; Start nur nach ausdrücklicher Bestätigung.
- Bereits bezahlte Global-Coverage wird im Detailresearch wiederverwendet.
- Finalprüfung: 0 DataForSEO-Requests.

SICHERHEIT
----------
- APKW_CONTENT_WRITE_CAPABILITY=false.
- Keine WordPress-/HivePress-Portal-Content-Writes.
- Keine Kategorien, Seiten, Beiträge oder Menüs werden angelegt/geändert/gelöscht.
- Einstellungen und kurzlebige Preflight-Transients sind technische Konfiguration, keine Portal-Inhalte.
- DataForSEO-Zugangsdaten werden nicht exportiert.

LOKALE PRÜFUNG
--------------
89/89 automatisierte Positiv-/Negativtests PASS.
PHP-Lint, JSON-Parse, Write-API-Scan und externe Endpoint-Prüfung müssen für den auszuliefernden ZIP-Stand PASS sein. Die Fresh-Unpack-Prüfung wird nach dem finalen ZIP-Build separat im Release-Audit des Masters dokumentiert.

SICHTPRUEFUNG
-------------
Ein technischer/DataForSEO-PASS ist niemals automatisch FINAL. Vor FINAL ist die sichtbare gemeinsame Prüfung des Gesamtbaums Pflicht. Die Freigabe wird per Review-Scope-SHA-256 an genau diesen Strukturstand gebunden.

LIVE-STATUS
-----------
Die DataForSEO-Verbindung wurde vom Nutzer mit dem vorherigen V1.3-Stand als hergestellt gemeldet. V1.4.0 selbst wurde noch nicht auf der echten WordPress-Installation installiert und durch den realen Global-/Detailworkflow geführt. Deshalb TESTKANDIDAT, kein Live-PASS.

VERBINDLICHE MASTERDATEI
------------------------
ALLGEMEINGUELTIGER_KATEGORIE_MASTER_014_DATAFORSEO_GATE_INTEGRIERT.zip
