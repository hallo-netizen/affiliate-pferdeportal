# DataForSEO-Gate-Vertrag V1.4

## Rolle
DataForSEO ist Evidenz- und Kontrollinstanz im bestehenden Kategorie-Workflow. Es ist nicht Architektur-Owner und verändert keine Kategorien autonom.

## Verwendete Endpoints
- kostenloser Verbindungstest: `/v3/appendix/user_data`
- Global-/Cluster-Discovery: `/v3/dataforseo_labs/google/keyword_ideas/live`
- exakte Kategorienamen/Primärkeywords: `/v3/dataforseo_labs/google/keyword_overview/live`

## Request-Grenzen im Plugin
- Keyword Ideas: max. 200 eindeutige Seeds je Request.
- Keyword Ideas Result Limit: 10–1000; Global-Coverage wird intern auf 50–1000 begrenzt.
- Keyword Overview: max. 700 Keywords je Request; größere Mengen werden gechunked.
- Keyword Ideas Sortierung: Provider-Relevanz absteigend, danach Suchvolumen absteigend.
- Synonyme bleiben sichtbar (`ignore_synonyms=false`), um bessere Bezeichnungsvarianten finden zu können.

## Kosten-Gates
1. `user_data`-Verbindungstest separat; Providerkosten != 0 => BLOCKED.
2. lokaler Global-Preflight: 0 Provider-Requests.
3. Global-Coverage: genau 1 Paid Call nach expliziter Bestätigung.
4. lokaler Detail-Preflight: 0 Provider-Requests und blockiert ungeklärte Global-Gaps.
5. Detailresearch: Call-Anzahl vor Start sichtbar; explizite Bestätigung erforderlich.
6. Read-only Gesamtprüfung: 0 Provider-Requests.
7. Sichtprüfung/FINAL_APPROVED: 0 Provider-Requests; menschliche Freigabe kann fehlende DataForSEO-Evidenz niemals überstimmen.

## Evidenzregeln
- Sichtbarer Kategoriename wird selbst geprüft, nicht nur ein unsichtbares Primärkeyword.
- Stärkere Alternative ist ein Review-Signal; keine automatische Umbenennung nur wegen Volumen.
- Search Intent ist Evidenz; begründete fachliche Abweichung kann zulässig sein.
- Global- und Cluster-Coverage kombinieren Provider-Relevanz und Suchvolumen.
- Longtails müssen als reale, gebundene DataForSEO-Keywords vorliegen und zum konkreten Content-Knoten passen.
- Datenmanipulation wird über Paket-/Scope-Hashes erkannt.

## Scope-Schutz
- Global-Coverage verwendet ausschließlich deklarierte projektweite Discovery-Seeds.
- Projektname wird nie automatisch als Seed ergänzt.
- Projekt-ID, Projekt-Scope, Ausschlüsse und Discovery-Seeds sind an die Global-Coverage gebunden.
- Cluster-/Kategoriestruktur darf nach Global-Coverage fachlich korrigiert werden, ohne die Global-Abfrage erneut zu bezahlen, solange der Projektscope unverändert bleibt.
