# Workflow-Hard-Audit V1.4

Prüfprinzip: Jede Änderung wurde nicht nur isoliert, sondern gegen den vollständigen Workflow bewertet: Projektkonzept -> Chat/Master-Architektur -> 3 Säulen -> kostenloser Preflight -> Global-Coverage -> Hauptthemenkorrektur -> kostenloser Detail-Preflight -> Detailresearch -> Chat/Master-Korrektur -> finale Research-/Bestandsprüfung -> READY_FOR_VISIBLE_SIGHT_REVIEW -> sichtbare gemeinsame Chat-Prüfung -> hashgebundene FINAL_APPROVED-Freigabe.

## Kritische Befunde im Integrationsblock und Korrekturen
1. **Parallel-/Neusystem-Risiko**: Ein experimenteller Nebenstand war konzeptionell zu weit gegangen. Korrektur: V1.4 wurde aus der echten V1.3-Codebasis kopiert; Plugin-Name/Slug bleiben identisch. Unveränderte Basisklassen Settings/Inventory/Comparator sind byteidentisch zu V1.3.
2. **Globales Hauptthema konnte vollständig fehlen**: reiner Cluster-Check findet nur innerhalb vorgegebener Cluster. Korrektur: vorgelagertes projektweites Global-Coverage-Gate.
3. **Breiter Projektname als Seed wäre chaotisch**: Korrektur: API erhält ausschließlich deklarierte `discovery_seed_keywords`; Projektname bleibt nur Kontext.
4. **Willkürliche Mindestzahl an Discovery-Seeds**: experimentell waren 3 Seeds hart gefordert. Korrektur: mindestens 1 fachlich sinnvoller Seed; weniger als 3 nur Review-Hinweis, kein starres Mengen-Gate.
5. **Detail-Preflight konnte Global-Gap übersehen**: Ursache war eine fehlerhafte Array-Union, durch die neue Fehler den alten `valid/errors`-Wert nicht überschrieben. Korrektur: explizite Zuweisung; ungeklärtes Global-Gap blockiert vor jedem Paid Detailrequest.
6. **Admin verwendete unvollständigen Detail-Preflight**: Korrektur: Admin ruft direkt `preflight_detail()` inkl. Global-Gate auf.
7. **Global-Coverage nur nach Suchvolumen** wäre zu eng: Korrektur: Union aus Provider-Relevanz und Suchvolumen; kein fixer Mindestvolumenwert.
8. **Cluster-Coverage nur nach Suchvolumen** war ebenfalls zu eng: gleiche Relevanz+Volumen-Union im Detailgate.
9. **Leere Provider-Coverage** durfte nicht als „nichts zu tun“ passieren: Korrektur fail-closed BLOCKED.
10. **Unnötiges neues Pflichtfeld `functional_intent`** hätte V1.3-Vertrag gebrochen. Korrektur: entfernt; funktionale Trennung bleibt über bestehende Säulenrolle, Search Intent, Scope und Overlap-Begründung.
11. **Global-Entscheidungen zu grob**: erweitert auf MAIN_TOPIC, SUBTOPIC, ARTICLE_ONLY, OUT_OF_SCOPE, DEFERRED mit Ziel-/Owner-Validierung.
12. **Hauptthemenkorrektur durfte nicht automatisch erneute Global-Kosten erzeugen**: Global-Scope-Hash bindet Projekt-ID/Scope/Ausschlüsse/Discovery-Seeds, nicht die korrigierbare Kategorie-/Clusterarchitektur.
13. **Provider-Reihenfolge ging in Normalisierung verloren**: `provider_rank` wird erhalten und ist als Relevanzsignal auswertbar.
14. **Dublettenregel**: identischer sichtbarer Name bleibt global BLOCK; semantisch ähnliche, anders benannte und sauber getrennte Säulen werden nicht pauschal geblockt.
15. **Keine Portal-Writes**: Produktionscode enthält keine verbotenen WordPress-/Taxonomie-/HivePress-Content-Schreibaufrufe.


16. **Technischer PASS konnte fälschlich als Endfreigabe missverstanden werden**: Korrektur: `READ_ONLY_PREVIEW` endet nur in `READY_FOR_VISIBLE_SIGHT_REVIEW`. `FINAL_APPROVED` benötigt einen dokumentierten Sichtprüfungsbeleg.
17. **Struktur konnte theoretisch nach menschlicher Sichtprüfung noch verändert werden**: Korrektur: Review-Scope-SHA-256 bindet Projekt, Cluster, Coverage-Entscheidungen, Knoten, Targets und Research-Bindung. Jede inhaltliche Änderung invalidiert die Freigabe.
18. **FINAL_APPROVED hätte bei bloßer Moduserweiterung DataForSEO-Gates umgehen können**: Korrektur: alle finalen Evidenz-, Longtail-, Hierarchie- und Overlap-Gates gelten identisch für READ_ONLY_PREVIEW und FINAL_APPROVED. Positiv-/Negativtests decken den Bypass explizit ab.
19. **Reine Array-Reihenfolge sollte keine erneute Sichtprüfung erzwingen**: Review-Hash wird normalisiert und ist reihenfolgeunempfindlich, aber inhaltssensitiv.

## Bereits aus V1.3 fortgeführte harte Sicherungen
- 3-Wege-Primary-Kollision gegen alle bisherigen Owner.
- Node-gebundene reale Longtails.
- Research-Scope-Hash gegen stille Cluster-/Seed-Drift nach Detailresearch.
- korrigiertes Primärkeyword darf aus exaktem gebundenem Keyword-Ideas-Treffer stammen.
- Taxonomie-Slug-Kollisionen taxonomy-weit.
- sichere JSON-Einbettung im Adminreport.
- Provider-/JSON-/Task-Fehler fail-closed.
- unerwartete Kosten im Free-Test fail-closed.
- Finalprüfung 0 Providerrequests.

## Lokales Ergebnis
89/89 automatisierte Positiv-/Negativtests PASS. Finaler Installer wird zusätzlich frisch entpackt und vollständig erneut geprüft. Live-WordPress-Status bleibt bis zum echten V1.4-Lauf TESTKANDIDAT.
