# Schnittstellenvertrag V1.4

## A. Chat/Master -> Plugin: RESEARCH_DRAFT
Format: `affiliate-portal-category-package`
Schema: `1.4`
Modus: `RESEARCH_DRAFT`

Neu für das DataForSEO-Gate:
- `project.discovery_seed_keywords`: mindestens 1, maximal 200; fachlich aus Projektkonzept/Scope abgeleitet.
- optional `global_coverage_decisions` nach Global-Coverage.

Bestehender V1.3-Knotenvertrag bleibt im Kern erhalten; es wurde kein zusätzliches Pflichtfeld für eine künstliche „functional_intent“-Ebene eingeführt. Die funktionale Säulentrennung erfolgt über `block`, `pillar_role`, `search_intent`, Scope und ggf. `overlap_justification`.

## B. Plugin -> Chat/Master: Global-Coverage-Paket
Format: `affiliate-portal-global-coverage-package`
Schema: `1.0`

Enthält:
- unveränderten Source-Draft + Hash,
- Projekt-Discovery-Scope-Hash,
- deklarierte Seeds,
- normalisierte DataForSEO-Evidenz inkl. Provider-Rang,
- rohe Providerantwort + Hash,
- Providerkosten/Task-ID,
- keine Zugangsdaten.

## C. Chat/Master -> Plugin: korrigierter RESEARCH_DRAFT
Darf Haupt-/Unterthemen, Research-Cluster und Knoten auf Basis der Global-Coverage korrigieren.

Global-Coverage-Entscheidungen:
- `MAIN_TOPIC`: target_cluster_id + aktiver Root-owner_concept_id,
- `SUBTOPIC`: target_cluster_id + aktiver owner_concept_id,
- `ARTICLE_ONLY`: target_cluster_id,
- `OUT_OF_SCOPE`,
- `DEFERRED`.

Unveränderte Projekt-Discovery-Bindung ist Pflicht.

## D. Plugin -> Chat/Master: Research-Paket
Format: `affiliate-portal-research-package`
Schema: `1.4`

Enthält:
- gebundenes Global-Coverage-Paket,
- Source-Draft + Research-Scope-Hash,
- WordPress Read-only-Inventar,
- Keyword Overview,
- Cluster Keyword Ideas,
- normalisierte + rohe Provider-Evidenz,
- Kosten-/Task-/Hash-Protokoll,
- keine Zugangsdaten.

## E. Chat/Master -> Plugin: finaler Strukturentwurf
Format: `affiliate-portal-category-package`
Schema: `1.4`
Modus: `READ_ONLY_PREVIEW`

Zusätzlich:
- `research_binding.package_id`
- `research_binding.content_sha256`
- identische Projekt-ID und identischer Research-Scope-Hash.

## F. Plugin -> Chat/Master: sichtbarer Review-Stand
Bei vollständig bestandener read-only Prüfung lautet der Status `READY_FOR_VISIBLE_SIGHT_REVIEW`.

Der Report enthält `review_scope_sha256`. Der komplette Baum dieses exakten Scopes wird im Chat sichtbar geprüft. Ein bloßer technischer PASS ist keine Endfreigabe.

## G. Chat/Master -> Plugin: FINAL_APPROVED
Nach ausdrücklicher sichtbarer Freigabe:
- Modus: `FINAL_APPROVED`
- `human_sight_review.status = APPROVED_AFTER_VISIBLE_REVIEW`
- `human_sight_review.review_scope_sha256` muss dem Plugin-berechneten Scope entsprechen
- `approved_at_utc`
- `review_summary`

Jede Strukturänderung verändert den Scope-Hash und erzwingt eine neue Sichtprüfung.

## H. Finaler Plugin-Report
Status:
- `READY_FOR_VISIBLE_SIGHT_REVIEW`
- `PASS_FINAL_APPROVED`
- `BLOCKED`

Kein WordPress/HivePress-Content-Write und kein DataForSEO-Request im finalen Pfad.
