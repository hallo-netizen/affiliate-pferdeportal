# Bekannte Grenzen / offene Realprüfung V1.4

Status: TESTKANDIDAT.

## Bewusste Grenzen
- DataForSEO kann die fachliche Vollständigkeit unterstützen, aber keine absolute „alle denkbaren Themen der Welt“-Garantie geben. Deshalb bleibt die erste Architekturprüfung durch Chat/Master Pflicht.
- Global-Coverage ist ein zweites Sicherheitsnetz gegen vergessene große Themenfelder; Qualität hängt auch von sinnvollen, konzeptbasierten Discovery-Seeds ab.
- Suchvolumen ist kein automatischer Kategorie-Richter.
- Semantische Überlappung wird nicht blind zusammengeführt.
- Kein automatisches WordPress/HivePress-Import-/Schreibmodul ist Teil dieses Plugins.

## Noch nicht real mit V1.4 ausgeführt
- Installation/Update V1.4 auf der echten WordPress-Installation,
- kostenloser V1.4-Verbindungstest dort,
- echter Global-Coverage-Call,
- echter Hauptthemen-Korrekturlauf,
- echter Detailresearch,
- finaler Realprojekt-READ_ONLY_PREVIEW,
- sichtbare gemeinsame Prüfung eines realen vollständigen 3-Säulen-Baums,
- reale FINAL_APPROVED-Freigabe desselben Review-Scope.

Der Nutzer hat die DataForSEO-Verbindung zuvor mit V1.3 als hergestellt gemeldet. Das ersetzt keinen vollständigen V1.4-Liveworkflow.
