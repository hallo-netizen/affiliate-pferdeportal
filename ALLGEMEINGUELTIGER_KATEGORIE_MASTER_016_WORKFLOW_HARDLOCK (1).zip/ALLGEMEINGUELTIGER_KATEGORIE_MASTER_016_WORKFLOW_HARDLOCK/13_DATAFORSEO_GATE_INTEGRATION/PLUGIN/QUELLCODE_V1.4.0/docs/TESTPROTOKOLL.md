# Testprotokoll V1.4.0

Status: TESTKANDIDAT – lokaler Integrationsblock vollständig geprüft; echter V1.4-WordPress/DataForSEO-Gesamtlauf noch ausstehend.

## Automatisierte Positiv-/Negativprüfung
89/89 PASS. Exakte Testnamen stehen in `TEST_RESULTS.txt`, Testcode in `tests/run-tests.php`.

Abgedeckt sind insbesondere:
- kostenloser Verbindungstest + Auth-/Kosten-/Providerfehler,
- drei Pflichtsäulen,
- V1.3-Knotenvertrags-Kompatibilität,
- Projekt-/Cluster-Seeds und Limits,
- Projektname niemals autonomer Seed,
- 0 Providerrequests in Preflights,
- genau 1 Global-Paid-Call,
- Global-Scope-/Hash-Bindung,
- Global-Gaps und fail-closed leere Coverage,
- MAIN_TOPIC/SUBTOPIC/ARTICLE_ONLY/OUT_OF_SCOPE/DEFERRED-Entscheidungen,
- ungültige Owner-/Clusterbindungen,
- Blockierung ungeklärter Global-Gaps vor Paid Detailresearch,
- Wiederverwendung der Global-Coverage ohne zweite Zahlung,
- Provider-Relevanz + Suchvolumen im Global- und Clustergate,
- Keyword Overview + ein Keyword-Ideas-Call je Cluster,
- keine Credentials im Export,
- Hash-/Tampering-Erkennung,
- identische sichtbare Namensdubletten global,
- ähnliche Namen säulenübergreifend zulässig,
- Primary-Ownership/Kollisionen inkl. 3-Wege-Fall,
- stärkere/bessere Keywordalternativen,
- Intent-Abweichungen,
- fehlende relevante Core-Gruppen,
- Parent/Child-Core-Prüfung,
- clusterübergreifende Core-Overlaps,
- mindestens 4 Content-Leaf-Longtails,
- exakter Providerbeleg + node-spezifische Longtail-Bindung,
- Longtail-Doppelownership/Primary-Kollision,
- WordPress-Taxonomie-Slug-Namespace,
- finaler End-to-End-Mock-PASS,
- FINAL_APPROVED ohne Sichtprüfung BLOCKED,
- gültige hashgebundene Sichtfreigabe PASS,
- Strukturänderung nach Sichtfreigabe BLOCKED,
- FINAL_APPROVED kann DataForSEO-Evidenz nicht umgehen,
- Review-Hash reihenfolgeunempfindlich, aber inhaltssensitiv,
- 0 DataForSEO-Requests im finalen read-only Pfad,
- 0 verbotene Portal-Write-APIs im Produktionscode,
- Capability-/Nonce-/JSON-Ausgabe-Härtung.

## Statische Prüfungen für Releasepaket
Werden nach finaler Dateierzeugung erneut ausgeführt und in separaten Dateien dokumentiert:
- PHP-Lint aller PHP-Dateien,
- JSON-Parse aller Schemas/Reports,
- Portal-Write-API-Scan,
- externe Endpoint-Allowlist,
- Versions-/Slug-Konsistenz,
- Source-vs-Fresh-Unpack-Hashvergleich,
- 89/89 Tests aus frisch entpacktem Installer.
