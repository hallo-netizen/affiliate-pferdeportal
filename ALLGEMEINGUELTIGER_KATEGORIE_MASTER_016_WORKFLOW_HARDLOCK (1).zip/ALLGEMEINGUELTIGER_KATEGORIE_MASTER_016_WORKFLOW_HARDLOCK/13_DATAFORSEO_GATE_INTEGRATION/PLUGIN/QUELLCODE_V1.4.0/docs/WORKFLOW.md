# Verbindlicher Gesamtworkflow V1.4

## 1. Architekturverantwortung
Der Nutzer liefert ein fachlich abgegrenztes Projektkonzept. Chat + verbindlicher Master bauen daraus die dreisäulige Portalarchitektur. DataForSEO ist Evidenz-/Kontroll-Gate und darf die Architektur nicht autonom verändern.

Pflichtsäulen:
- Content: systematischer Evergreen-/Ratgeberbereich.
- Marketplace/HivePress: Anbieter-, Leistungs- und Angebotsintention.
- Journal/Magazin: redaktionelle, aktuelle, inspirierende oder erzählerische Aufgabe; kein Restebecken für Content.

## 2. Erster RESEARCH_DRAFT
Chat/Master müssen bereits vor DataForSEO fachlich prüfen:
- relevante Hauptthemen,
- sinnvolle Hierarchie,
- Trennung der drei Säulen,
- Scope/Ausschlüsse,
- erste Primärkeywords,
- begrenzte Research-Cluster,
- projektweite Discovery-Seeds für den Vollständigkeitscheck.

Ein breiter Projektname wie „Essen“ wird niemals automatisch als DataForSEO-Seed verwendet.

## 3. Kostenfreier Preflight
Das Plugin prüft lokal u. a.:
- Schema und IDs,
- drei Pflichtsäulen,
- Hierarchie,
- Research-Cluster und Seeds,
- identische sichtbare Namen portalweit,
- Keyword-Ownership,
- technische Zielkollisionen,
- geplante API-Call-Anzahl.

Externe Requests: 0.

## 4. Global-Coverage-Gate
Genau ein ausdrücklich bestätigter Keyword-Ideas-Aufruf nutzt nur `project.discovery_seed_keywords`.

Zweck: große projektweite Keywordfelder finden, die der erste fachliche Entwurf übersehen haben könnte.

Review-Menge ist die Vereinigung aus:
- Core-Gruppen mit hoher DataForSEO-Provider-Relevanz,
- Core-Gruppen mit hohem Suchvolumen.

Es gibt keinen starren Mindest-Suchvolumenwert. Suchvolumen ist ein Signal, nicht der alleinige Richter.

Vor Detailresearch muss jede relevante Review-Gruppe entweder:
- bereits im korrigierten Draft abgedeckt sein, oder
- explizit als `MAIN_TOPIC`, `SUBTOPIC`, `ARTICLE_ONLY`, `OUT_OF_SCOPE` oder `DEFERRED` fachlich entschieden sein.

Leere/unauswertbare Global-Coverage => fail-closed BLOCKED.

## 5. Hauptthemen-Korrektur
Chat/Master prüfen das Global-Coverage-Paket. Architektur wird nur dort verändert, wo das fachlich sinnvoll ist. DataForSEO fügt selbst nichts hinzu.

Unverändert bleiben müssen Projekt-ID, Projektscope, Ausschlüsse und Global-Discovery-Seeds; eine echte Änderung daran erfordert neue Global-Coverage. Haupt-/Unterkategorien und Research-Cluster dürfen dagegen auf Basis des globalen Befunds korrigiert werden.

## 6. Kostenfreier Detail-Preflight
Vor Paid Detailresearch prüft das Plugin:
- Global-Paketintegrität,
- Bindung an dasselbe Projekt/Discovery-Scope,
- Global-Coverage-Gate vollständig entschieden/abgedeckt,
- korrigierten 3-Säulen-Draft.

Ist ein globales Themenfeld ungeklärt, wird vor jedem Paid-Detailrequest BLOCKED.

## 7. Detailresearch
Nach ausdrücklicher Kostenbestätigung:
- Keyword Overview für geplante sichtbare Kategorienamen und Primärkeywords,
- genau ein Keyword-Ideas-Aufruf je deklariertem Research-Cluster,
- bereits bezahlte Global-Coverage wird wiederverwendet.

Geprüft werden:
- Ist der Kategoriename selbst belegt/stark?
- Ist ein stärkeres, intentkompatibles Keyword im selben DataForSEO-Core vorhanden?
- Fehlen wichtige Core-Gruppen im Cluster?
- Stimmt Parent -> Child fachlich/keywordseitig?
- Stimmen deklarierte und gemessene Intents ausreichend überein?
- Gibt es reale Longtails?
- Gibt es Same-Pillar-/Cross-Pillar-Overlap?

Auch die Cluster-Coverage nutzt Provider-Relevanz plus Suchvolumen; nicht nur Volumen.

## 8. Korrekturlauf Chat/Master
DataForSEO-Signale werden fachlich bewertet, nicht blind umgesetzt.

Mögliche Maßnahmen:
- Kategorie umbenennen,
- Primärkeyword ändern,
- Kategorie/Unterkategorie ergänzen,
- Hierarchie korrigieren,
- Thema als Artikel statt Kategorie führen,
- Thema bewusst ausschließen/deferieren,
- Longtails ersetzen,
- Overlap bewusst trennen und begründen.

## 9. Read-only Gesamtprüfung vor Sichtprüfung
Der korrigierte Strukturentwurf wird gegen das gebundene Research-Paket und den aktuellen WordPress-Bestand geprüft. Ein technischer PASS ergibt ausdrücklich nur `READY_FOR_VISIBLE_SIGHT_REVIEW`, niemals automatisch FINAL.

Harte Kernregeln:
- identischer sichtbarer Kategoriename portalweit => BLOCK,
- gleiche Primärkeyword-Ownership innerhalb einer Säule => BLOCK,
- exaktes Primärkeyword + gleiche deklarierte Suchintention über Säulen => BLOCK,
- semantisch ähnlicher Core über Säulen => erlaubt mit unterschiedlicher Säulenaufgabe und finaler Begründung,
- starke/relevante unbesetzte Keywordgruppe => Owner oder explizite Entscheidung,
- Content-Blatt => mindestens 4 reale, in der gebundenen Evidenz vorhandene und dem Knoten zuordenbare Longtails,
- Research-Scope-Tampering => BLOCK,
- Portal-Content-Writes => technisch nicht vorhanden.

Diese Prüfung macht 0 DataForSEO-Requests.

## 10. Verbindliche sichtbare gemeinsame Konzeptprüfung
Der komplette 3-Säulen-Baum wird im Chat sichtbar dargestellt und gemeinsam geprüft. Pflichtfragen:
- Fehlt ein relevantes Hauptthema trotz Global-Coverage?
- Fehlt eine sinnvolle Unterkategorie oder ist eine Kategorie zu dünn?
- Ist eine Ebene unnötig oder zu breit?
- Sind Content, Marketplace/HivePress und Journal als unterschiedliche Funktionen verständlich?
- Sind Namen menschlich klar, auch wenn DataForSEO sie statistisch stützt?
- Gibt es sinnvolle Ergänzungen, Querverbindungen oder Ausschlüsse, die eine API nicht selbst entscheiden kann?

Die Sichtprüfung darf DataForSEO-Evidenz nicht überstimmen. Sie ergänzt die maschinelle Prüfung um fachliche und menschliche Gesamtplausibilität.

## 11. Finale Freigabe
Nach ausdrücklicher sichtbarer Freigabe wird der unveränderte Review-Scope mit `FINAL_APPROVED` und `human_sight_review` dokumentiert. Der Review-Scope-SHA-256 umfasst Projekt, Research-Cluster, Coverage-Entscheidungen, Knoten, Zieladapter und Research-Bindung.

- fehlende Sichtfreigabe => BLOCKED,
- geänderter Strukturstand nach Sichtfreigabe => BLOCKED und erneute Sichtprüfung,
- passende Sichtfreigabe + alle bisherigen Gates PASS => `PASS_FINAL_APPROVED`.

Die finale Freigabeprüfung macht 0 DataForSEO-Requests und 0 Portal-Content-Writes.
