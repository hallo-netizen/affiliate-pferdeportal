# Release-Audit – Master 014 / Plugin V1.4.0

## Verbindliche Baseline
- Master 011 SHA-256: `947d39548847863a0cfc3107b2664d7a482a427a7bb2227c51946b018f4d41e6`
- MVP 009 SHA-256: `9f30dba88a88cfceab18969f93f8ffc760fc700dfe827361f454b27f312da59b`
- beide Original-ZIPs unverändert im Master archiviert.

## Pluginidentität
- Slug: `affiliate-portal-kategorie-workflow`
- Version: `1.4.0`
- kein Parallelplugin.
- eingebetteter Installer SHA-256: `ced0f7437b68dd9d5aa0b9c837b1e4feea1f37d79fca7f139850da21f2733f2c`
- externer Installationskandidat ist byteidentisch zum eingebetteten Installer.
- eingebetteter Quellcode entspricht dem final geprüften Sourcebaum über 33 Dateien byteidentisch.

## Lokale Prüfungen
- automatisierte Positiv-/Negativtests: **89/89 PASS**
- PHP-Lint: PASS
- JSON-Parse: PASS
- Portal-Content-Write-API-Scan: PASS
- externe Endpoint-Allowlist: PASS
- V1.3-Baseline-Nachweis: PASS
- Source ↔ Plugin-Fresh-Unpack: PASS
- Plugin-SHA-Manifest im Fresh-Unpack: PASS

## Speziell gegen Gesamtworkflow geprüft
- Global-Coverage vor Detailresearch;
- keine autonome Architekturmutation durch DataForSEO;
- starke/bessere Kategorienamen;
- fehlende Haupt-/Unterthemen und Keywordgruppen;
- Parent→Child-Hierarchie;
- Intent;
- reale node-gebundene Longtails;
- Same-Pillar-/Cross-Pillar-Kannibalisierung;
- identische sichtbare Namen global BLOCK;
- ähnliche anders benannte Säulen zulässig mit Trennbegründung;
- sichtbare Gesamtbaumprüfung zwingend vor FINAL;
- Review-Scope-Hash blockiert stille Änderungen;
- FINAL_APPROVED kann DataForSEO-Evidenz nicht umgehen;
- finale Prüfung 0 externe Requests / 0 Portal-Content-Writes.

## Ehrliche Grenze
Der reale V1.4-End-to-End-Lauf auf der Nutzerinstallation steht noch aus. Der Nutzer hat nur die DataForSEO-Verbindung des vorherigen V1.3-Standes bestätigt. Deshalb bleibt der Pluginstatus bis zum Realworkflow **TESTKANDIDAT**.
