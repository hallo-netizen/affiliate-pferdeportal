# CODEX-AUFTRAG – Unabhängiges Hard-Audit V1.4.0

Prüfe den vollständigen beigefügten Quellcode unabhängig. Keine kosmetischen Umbauten und keine Änderung ohne reproduzierbaren Befund.

## Ausgangslage
V1.4.0 ist ausdrücklich ein Update derselben bestehenden Plugin-Linie V1.3.0. DataForSEO wird als Gate integriert; kein Parallelplugin und keine autonome Kategoriearchitektur.

## Verbindlicher Workflow
Projektkonzept -> Chat/Master erstellt fachlich den ersten vollständigen Content+Marketplace/HivePress+Journal-Draft -> kostenloser lokaler Preflight -> genau 1 bestätigter Global-Coverage-Call -> Chat/Master korrigiert/entscheidet Hauptthemen -> kostenloser Detail-Preflight muss Global-Gate schließen -> bestätigter Detailresearch -> Chat/Master korrigiert -> read-only Pluginprüfung -> READY_FOR_VISIBLE_SIGHT_REVIEW -> sichtbare gemeinsame Chat-Prüfung -> hashgebundene FINAL_APPROVED-Freigabe.

## Zwingend prüfen
1. gleicher Plugin-Name/Slug; keine parallele Architektur.
2. DataForSEO verändert keine Kategorien autonom.
3. Projektname wird nie automatisch Seed; nur deklarierte Discovery-/Cluster-Seeds.
4. drei Pflichtsäulen bleiben zwingend.
5. Global-Coverage findet projektweite Lücken über Provider-Relevanz + Suchvolumen.
6. ungeklärte Global-Gaps blockieren vor jedem Paid Detailrequest.
7. leere Global-Coverage blockiert fail-closed.
8. Haupt-/Unterthemenkorrektur darf Global-Paket bei unverändertem Projektscope wiederverwenden.
9. echte Projekt-Scope-/Discovery-Seed-Änderung verlangt neue Global-Coverage.
10. Kategoriename selbst wird geprüft; stärkere intentkompatible Alternative wird erkannt.
11. wichtige vergessene Cluster-Core-Gruppen werden erkannt.
12. Parent/Child-Hierarchie, Search Intent und Cannibalization werden geprüft.
13. identischer sichtbarer Kategoriename portalweit BLOCK.
14. semantisch ähnlicher Core über verschiedene Säulen darf bei unterschiedlichen Namen/Aufgaben und Begründung bestehen bleiben.
15. Content-Leaf-Longtails real, providerbelegt, node-gebunden, mindestens 4, eindeutiger Owner.
16. keine Portal-Content-Writes.
17. Verbindungstest kostenfrei; Kostenanomalie BLOCK.
18. Paid Calls nur nach Preflight + sichtbarer Callzahl + ausdrücklicher Bestätigung.
19. Finalprüfung 0 DataForSEO-Requests.
20. Credentials nicht in Exporten.
21. Hash-/Binding-/Tampering-Schutz korrekt.
22. Admin Capability/Nonce/Upload/JSON sicher.
23. Schema-/Runtime-Versionen konsistent.
24. bestehender V1.3-Knotenvertrag wird nicht unnötig durch neue Pflichtfelder gebrochen.
25. technischer/DataForSEO-PASS darf ohne sichtbare gemeinsame Baumprüfung nicht FINAL werden.
26. FINAL_APPROVED ohne gültigen human_sight_review-Beleg muss BLOCKED sein.
27. jede inhaltliche Strukturänderung nach Sichtfreigabe muss den Review-Scope-Hash invalidieren.
28. FINAL_APPROVED muss dieselben DataForSEO-/Longtail-/Cannibalization-Gates wie READ_ONLY_PREVIEW durchlaufen und darf sie nicht umgehen.
29. finale Freigabeprüfung erzeugt 0 Providerrequests und 0 Portal-Content-Writes.

## Testauftrag
- vorhandene Tests ausführen,
- bei echter Lücke gezielt adversarialen Positiv-/Negativtest ergänzen,
- besonders preflight_detail, global_coverage_gate, Scope-Binding, globale Entscheidungen, Provider-Relevanz-vs-Volumen, Longtail-Ownership und Cross-Pillar-Overlap prüfen.

## Ausgabe
Nur:
- `PASS` + ausgeführte Prüfungen, oder
- `BLOCKED` + Datei/Funktion/Zeile, reproduzierbarer Fehler, verletzte Workflowregel und minimaler Korrekturvorschlag.

Code nicht eigenmächtig umschreiben; Befunde zuerst.
