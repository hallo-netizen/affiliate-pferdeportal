# Verbindliches allgemeines Regelwerk

Status: AKTIV

Aus der vollständigen Masterhistorie extrahierte, konsolidierte und durch den Contentkategorie-Rootfix korrigierte explizite Regeln.

## R-001 – Themenunabhängigkeit

Jede Regel muss ohne themenspezifische Sonderannahmen auf andere Portale übertragbar sein. Thematische Beispiele dienen nur der Prüfung.

## R-002 – Eindeutige Keyword-Eigentümerschaft

Jeder semantische Suchcluster erhält genau eine primäre indexierbare Zielseite. Andere Seiten dürfen das Thema unterstützend erwähnen und auf die Eigentümerseite verlinken, dürfen aber nicht dieselbe Suchintention vollständig erneut bedienen.

## R-003 – Suchintention vor Wortgleichheit

Gleiche Wörter bedeuten nicht automatisch Kannibalisierung. Entscheidend ist, ob Nutzer mit den Suchanfragen dieselbe Aufgabe lösen wollen. Umgekehrt können unterschiedliche Formulierungen dieselbe Suchintention besitzen und deshalb konkurrieren.

## R-004 – Strikte Blockzuordnung

Jeder Zielseitencluster wird primär genau einem Block zugewiesen: Content, HivePress, Magazin oder Glossar. Die Zuweisung muss maschinenlesbar begründet werden.

## R-005 – Hierarchie von breit nach konkret

Mit jeder tieferen Ebene muss der Themenumfang enger und die Suchabsicht konkreter werden. Ein Kindknoten darf nicht breiter, gleichbedeutend oder nur sprachlich anders formuliert sein als sein Elternknoten.

## R-006 – Keyword-Vererbung

Ein Kindthema übernimmt den sachlichen Kern seines Elternclusters und ergänzt ein unterscheidendes Merkmal. Es darf den Elternbegriff nicht lediglich wiederholen.

## R-007 – Geschwister müssen trennscharf sein

Geschwisterknoten benötigen eigenständige Suchintentionen oder klar unterscheidbare Gegenstände. Synonyme, Singular/Plural, Schreibvarianten und nahezu identische Nutzungszwecke dürfen nicht als getrennte Geschwister angelegt werden.

## R-008 – Kurze und prägnante Navigationsbezeichnungen

Navigationsnamen müssen verständlich, keywordbezogen, visuell kompakt und ohne unnötige Füllwörter formuliert sein. Jeder Navigationsname bezeichnet möglichst genau ein Thema.

Die zulässige sichtbare Länge wird als konfigurierbarer Designparameter geführt und nicht als sprachunabhängige starre Zeichenzahl festgeschrieben.

## R-009 – Navigationsname und SEO-Titel getrennt

Der kurze Navigationsname, der vollständige Seitentitel, der SEO-Titel, die H1 und der URL-Slug werden als getrennte Felder verwaltet. Sie müssen semantisch zusammenpassen, dürfen aber unterschiedlich lang formuliert sein.

## R-010 – Keine erzwungene Symmetrie

Nicht jedes Hauptthema benötigt gleich viele Unterkategorien. Nicht jedes konkrete Thema benötigt dieselben Beitragsarten. Die Struktur folgt nachgewiesener Nachfrage und Suchintention, nicht einem optisch gleichmäßigen Raster.

## R-011 – Mindestsubstanz für Kategorien

Eine Content-Kategorie wird freigegeben, wenn sie einen eigenständigen, klar abgegrenzten Suchraum trägt und daraus mindestens drei wichtige, eigenständige Longtail-Beiträge belastbar planbar beziehungsweise in der Research-Evidenz belegt sind. Der typische Prüfbereich liegt bei drei bis fünf tragfähigen Beiträgen; mehr sind zulässig. Für reine Hubknoten gilt weiterhin R-012. Für Marketplace/HivePress und Journal wird die Tragfähigkeit blockbezogen nach deren eigener Funktionslogik bewertet. Die bloße Erzeugung ähnlicher Titel erfüllt diese Regel nicht.

## R-012 – Mindestsubstanz für Elternknoten

Ein reiner Navigations- oder Hubknoten benötigt grundsätzlich mindestens zwei trennscharfe, sinnvolle Kinder oder einen nachgewiesenen eigenständigen Such- und Nutzerwert. Die Zahl zwei ist keine frei gewählte Mengenvorgabe, sondern die logische Mindestbedingung für einen reinen Bündelungsknoten. Ein Ein-Kind-Knoten wird zusammengeführt oder ausdrücklich als begründeter Sonderfall dokumentiert.

## R-013 – Beitragsarten können tragfähige Content-Kategorien bilden

FAQ, Tipps, Beratung, Vergleich, Ausrüstung/Werkzeug, Pflege, Kosten, Anwendung, Installation, Lagerung, Sicherheit sowie weitere fachlich sinnvolle Beitragsrichtungen werden unter einem konkreten Fachthema als eigene Content-Kategorie angelegt, wenn sie nach R-011 mindestens drei wichtige, eigenständige und trennscharfe Longtail-Beiträge tragen. Erreichen sie diese Tragfähigkeit nicht, werden sie nicht künstlich als Kategorie erzeugt. Die Liste ist offen und nicht abschließend.

## R-014 – Keine leeren Kategorien

Leere Kategorien dürfen nicht veröffentlicht oder indexiert werden. Vorbereitete Kategorien bleiben Entwurf, bis ihre Mindestsubstanz erreicht ist.

## R-015 – Keine unspezifischen Sammelbecken

Bezeichnungen wie „Sonstiges“, „Weitere Themen“ oder „Allgemein“ sind grundsätzlich unzulässig. Eine Ausnahme erfordert eine konkrete, dokumentierte fachliche Abgrenzung.

## R-016 – Vollständige Erreichbarkeit

Jede freigegebene Kategorie muss über normale HTML-Links erreichbar sein. Begrenzungen des Megamenüs dürfen keine Kategorie dauerhaft unerreichbar machen. Alle nicht im Menü sichtbaren Kinder müssen über eine geeignete Hub-, Listen- oder sonstige vom Designsystem bereitgestellte Struktur vollständig erreichbar sein. Diese Erreichbarkeitsgarantie ist eine verbindliche Schnittstellenanforderung an das Designsystem; die konkrete sichtbare Ausgestaltung bleibt dessen Zuständigkeit.

## R-017 – Navigation und Taxonomie getrennt modellieren

Die sichtbare Navigation ist nicht automatisch die technische Taxonomie. Das System speichert fachliche Eltern-Kind-Beziehungen unabhängig von Menüeinträgen und erzeugt beide kontrolliert.

## R-018 – Stabile URL-Struktur

Slugs müssen kurz, eindeutig, dauerhaft und aus dem primären Thema ableitbar sein. Schreibvarianten, Trackingbegriffe, Jahreszahlen ohne dauerhaften Zweck und unnötige Hierarchiewiederholungen sind zu vermeiden.

## R-019 – Keine URL-Kollision

Vor dem Import werden vorhandene Seiten, Beiträge, Kategorien, HivePress-Taxonomien und Weiterleitungen auf Slug- und Zielkonflikte geprüft.

## R-020 – Existierender Bestand vor Neuanlage

Vor jeder Neuanlage ist der relevante Bestand zu inventarisieren. Die technische Erkennungs- und Konfliktlogik richtet sich verbindlich nach R-058. Bestehende Inhalte werden nicht stillschweigend dupliziert.

## R-021 – Synonym- und Entitätsprüfung

Jedes Cluster erhält Hauptbegriff, Synonyme, Oberbegriffe, Unterbegriffe und mögliche Mehrdeutigkeiten. Marken, Produkttypen, Tätigkeiten, Probleme und Anbieterarten werden als unterschiedliche Entitätsrollen behandelt.

## R-022 – Blockübergreifende Kannibalisierungsprüfung

Die Prüfung umfasst mindestens:

- identische und ähnliche Hauptkeywords
- Synonyme und Schreibvarianten
- gleiche Suchintention
- gleiche SERP-Aufgabe
- konkurrierende Titel und H1
- konkurrierende Slugs
- inhaltlich weitgehend gleiche geplante Abdeckung
- doppelte lokale oder Anbieterintentionen

## R-023 – Unterstützende Verlinkung statt Konkurrenz

Inhaltlich verwandte Seiten verschiedener Blöcke werden durch klare Rollen und interne Links verbunden. Eine Contentseite kann beispielsweise einen passenden Anbieterbereich verlinken, ohne selbst ein Anbieterverzeichnis zu werden.

## R-024 – Magazin nicht als Resteverwertung

Das Magazin erhält nur eigenständige redaktionelle Themen. Ein Keyword darf nicht allein deshalb ins Magazin verschoben werden, weil es im Contentbaum keinen Platz gefunden hat.

## R-025 – HivePress-Kategorien nach Anbieterintention

HivePress-Kategorien werden nach dem gesucht oder angebotenen Anbieter-, Dienstleistungs- oder Angebotstyp gebildet. Reine Informationsfragen und bloße Produktmerkmale sind keine HivePress-Kategorien.

## R-026 – Filter statt Kategorienexplosion

Standort, Preisbereich, Zielgruppe, Material, Größe, Verfügbarkeit und vergleichbare Merkmale werden bevorzugt als Filter oder Attribute geführt, sofern sie keine eigenständige navigationswürdige Suchintention besitzen.

## R-027 – Datenbelegte Recherche

Kategorien dürfen nicht allein aus Modellwissen oder Vermutungen erzeugt werden. Die Recherchegrundlage, verwendeten Quellen, Suchfragen, Keywordvarianten und entscheidenden Belege werden protokolliert.

## R-028 – Aktualität und Quellenqualität

Zeitabhängige Informationen werden mit aktuellen Quellen geprüft. Für technische, rechtliche, medizinische oder finanzielle Themen sind vorrangig belastbare Primär- oder Fachquellen zu verwenden.

## R-029 – Kein automatischer Import bei Unsicherheit

Unklare Zuordnungen, ungelöste Dubletten, nicht belegte Kategorien oder Kannibalisierungsrisiken führen zu `BLOCKED`. Das System darf nicht raten.

## R-030 – Vorschau vor Schreibzugriff

Vor jedem Import wird eine vollständige Vorschau mit Hierarchie, Namen, Zieltypen, Slugs, Keyword-Eigentümern, Konflikten und geplanten Änderungen ausgegeben. Der Import erfolgt erst nach ausdrücklicher Freigabe.

## R-031 – Idempotenter Import

Jeder Import muss idempotent sein. Die vollständige technische Anforderung und Wiederholbarkeitsprüfung richtet sich verbindlich nach R-057.

## R-032 – Keine stillen Änderungen

Bestehende URLs, Namen, Elternbeziehungen oder Veröffentlichungszustände dürfen nicht ohne Vorschau und Freigabe geändert werden.

## R-033 – Rückverfolgbarkeit

Jedes importierte Objekt erhält eine stabile interne Konzept-ID und eine Verbindung zur freigegebenen Konzeptversion.

## R-034 – Positiv- und Negativprüfungen

Vor einer Pluginfreigabe müssen Positivtests korrekte Strukturen importieren und Negativtests mindestens Dubletten, falsche Hierarchien, Blockkonflikte, leere Kategorien und wiederholte Imports zuverlässig blockieren.

## R-035 – Trennung der Systeme

Das Kategorieplugin erzeugt und verwaltet Struktur und Metadaten. Text- und Designsysteme konsumieren diese Daten über definierte Schnittstellen. Keine feste Pferde-, Kategorie-, Text- oder Designlogik wird hart im Plugin eingebaut.

## R-036 – Verbindliche Zuständigkeit bis zur untersten Kategorieebene

Das Kategoriesystem entwickelt, prüft und verwaltet die Struktur verbindlich bis einschließlich der jeweils untersten freigegebenen Kategorieebene. Diese Grenze gilt für Content, HivePress sowie Magazin/Journal. Konkrete Beiträge, Anzeigen oder redaktionelle Einzelinhalte gehören nicht mehr zur verbindlichen Strukturplanung dieses Systems.

## R-037 – Vorschläge unterhalb der letzten tragfähigen Kategorie

Unterhalb der letzten tragfähigen und freigegebenen Content-Kategorie darf das System konkrete Beitrags-, Fragestellungs- und Longtail-Richtungen vorschlagen. Eine Beitragsrichtung, die selbst die Kategorie-Tragfähigkeit nach R-011 erreicht, darf nicht nur als unverbindlicher Beitragsvorschlag behandelt werden, sondern muss als möglicher Kategorie-Knoten geprüft werden. Konkrete Einzelbeiträge bleiben außerhalb der verbindlichen Strukturplanung.

## R-038 – Verbindlichkeit nur durch ausdrücklichen Statuswechsel

Ein unverbindlicher Vorschlag kann abhängig vom späteren Plugin- und Workflowmodell in einen verbindlichen Planungsgegenstand überführt werden. Dies ist nur durch einen eindeutig protokollierten Freigabe- oder Statuswechsel zulässig. Ein automatischer Wechsel in einen verbindlichen Zustand ist verboten.

## R-039 – Primärfunktion je Inhaltsblock

Jeder Inhaltsblock besitzt eine eigene Hauptaufgabe: Content bildet dauerhafte Informations- und Themenstrukturen ab, HivePress konkrete Markt-, Anbieter- und Angebotsintentionen, Magazin/Journal eigenständige redaktionelle Inhalte. Kein Objekt darf in mehreren Blöcken dieselbe primäre Funktion erfüllen.

## R-040 – Suchintention entscheidet über den Block

Die Blockzuordnung richtet sich nach der konkreten Nutzeraufgabe und nicht allein nach dem verwendeten Begriff. Dasselbe Thema oder Wort darf in mehreren Blöcken vorkommen, wenn die primären Suchintentionen nachweisbar verschieden sind.

## R-041 – Eigene Seitentypen je Block

Content, HivePress und Magazin/Journal verwenden getrennte Objekt- und Seitentypen. Contentseiten, Hubs und Kategorien dürfen nicht als Anzeigenkategorien behandelt werden; Anzeigenkategorien und Anzeigen dürfen nicht als redaktionelle Inhalte modelliert werden; Magazinrubriken und Beiträge dürfen keine zweite Contentnavigation bilden.

## R-042 – Content und Magazin klar trennen

Content bildet den dauerhaften strukturierten Einstieg in ein Themenfeld. Magazin/Journal behandelt einzelne redaktionelle Fragen, Entwicklungen, Erfahrungen, Hintergründe oder Einordnungen. Ein Magazinbeitrag darf nicht dieselbe dauerhafte Hauptaufgabe wie eine Content-Zielseite übernehmen.

## R-043 – HivePress nicht als zweite Contenthierarchie

Die HivePress-Struktur folgt der realen Angebots-, Anbieter- und Marktsuche. Sie muss die Contenthierarchie weder spiegeln noch vollständig übernehmen. Fachliche Informationstiefe gehört in den Contentblock; Marktauffindbarkeit, Angebotstypen und geeignete Filterlogik gehören in HivePress.

## R-044 – Verknüpfung ohne Vermischung

Die Blöcke dürfen und sollen sich gegenseitig über klare interne Links unterstützen. Die Verlinkung ändert jedoch weder den Primärblock noch die Eigentümerschaft des verlinkenden oder verlinkten Objekts.

## R-045 – Definierte Zuständigkeit jeder Kategorie

Für jede verbindliche Kategorie werden mindestens Primärblock, Hauptaufgabe, Suchintention, inhaltlicher Umfang, Ausschlüsse, Abgrenzung zu ähnlichen Kategorien und zulässige Kindobjekte dokumentiert. Ohne diese Zuständigkeitsdefinition bleibt die Kategorie blockiert.

## R-046 – Identische sichtbare Kategorienamen portalweit verboten

Identische sichtbare Kategorienamen sind portalweit unzulässig, auch wenn Content, Marketplace/HivePress und Journal unterschiedliche Suchintentionen haben. Inhaltlich ähnliche Themen dürfen säulenübergreifend bestehen bleiben, wenn sie unterschiedlich benannt sind und eine klar unterschiedliche Funktion, Suchaufgabe und Eigentümerschaft dokumentiert ist. Semantische Ähnlichkeit allein ist kein automatischer Merge-Grund.

## R-047 – Magazinrubriken kopieren nicht pauschal den Contentbaum

Magazin- und Journalrubriken werden nach redaktioneller Nutzerlogik und dauerhaftem Themenpotenzial gebildet. Eine automatische Spiegelung der Contentkategorien ist unzulässig, weil dadurch zwei konkurrierende Navigations- und Themenstrukturen entstehen können.

## R-048 – Blockbezogene Mindestsubstanz

Die Mindestsubstanz wird je Block getrennt geprüft: Content benötigt tragfähige Unterthemen oder Zielseiten, HivePress realistisches Anbieter- oder Anzeigenpotenzial, Magazin/Journal mehrere eigenständige redaktionelle Inhalte. Ein bloßes gemeinsames Schlagwort genügt nicht.

## R-049 – Unterschiedliche Hierarchietiefen sind zulässig

Die Inhaltsblöcke müssen nicht dieselbe Anzahl an Ebenen besitzen. Die Tiefe richtet sich je Block nach Nutzerlogik, Umfang, Auffindbarkeit und technischer Zweckmäßigkeit. Künstliche Symmetrie zwischen Content, HivePress und Magazin/Journal ist unzulässig.

## R-050 – Genau ein Primärblock je Objekt

Jedes Objekt besitzt technisch und fachlich genau einen Primärblock. Unterstützende Elemente anderer Blöcke, etwa Anzeigen auf Contentseiten oder redaktionelle Verweise in HivePress, ändern diese Zuordnung nicht.

## R-051 – Ein-Klick-Import als verbindliches Bedienziel

Das spätere Plugin muss eine vollständig freigegebene Struktur mit einem zentralen Importvorgang an den korrekten technischen Zielstellen anlegen können. Der Bedienkomfort „ein Klick“ bedeutet jedoch nicht „ungeprüft schreiben“: Vorschau, Validierung, Sicherung und Freigabe sind zwingende Bestandteile desselben kontrollierten Workflows.

## R-052 – Einheitliches maschinenlesbares Importmodell

Jedes zu importierende Objekt benötigt mindestens eine stabile Konzept-ID, Primärblock, Objektart, sichtbaren Namen, Slug, Ebenennummer, Eltern-Konzept-ID, Eigentümercluster, Suchintention, Verbindlichkeitsstatus, Konzeptversion und Zieladapter. Namen oder Slugs allein dürfen nicht als Identität verwendet werden.

## R-053 – Getrennte Importadapter je Inhaltsblock

Der zentrale Importer steuert getrennte technische Adapter für Content, HivePress und Magazin/Journal. Jeder Adapter darf nur die für seinen Block freigegebenen WordPress-Objekte, Taxonomien und Metadaten verändern. Eine pauschale Gleichbehandlung aller Blöcke ist unzulässig.

## R-054 – Hierarchische Zielzuordnung vor Schreibzugriff

Vor dem Import muss für jedes Objekt eindeutig feststehen:

- technischer Zieltyp;
- fachliche Ebene;
- direkte Eltern-Konzept-ID;
- technisches Elternobjekt;
- Primärblock;
- Sichtbarkeit in Navigation oder Hub;
- Veröffentlichungsstatus.

Fehlt eine dieser entscheidenden Zuordnungen, wird das Objekt nicht importiert.

## R-055 – Vollständige Importvorschau

Vor jedem Schreibzugriff zeigt das Plugin mindestens Neuanlagen, Aktualisierungen, unveränderte Objekte, Konflikte, fehlende Eltern, Ebenenfehler, Slugkollisionen, blockierte Objekte und Auswirkungen auf Navigation oder Hubs. Der Nutzer gibt ausschließlich diesen konkreten Importplan frei.

## R-056 – Harte Importvalidierung

Der Import wird vollständig blockiert, wenn mindestens einer der folgenden Fälle vorliegt:

- doppelte Konzept-ID;
- fehlende oder unbekannte Eltern-Konzept-ID;
- zyklische Eltern-Kind-Beziehung;
- Selbstzuordnung als Elternobjekt;
- unzulässiger Ebenensprung;
- Überschreitung der blockbezogen erlaubten Tiefe;
- fehlender Primärblock oder Zieladapter;
- ungeklärte Keyword-Eigentümerschaft;
- ungeklärte Slug- oder Bestandskollision;
- Verbindlichkeitsstatus nicht `APPROVED`;
- erforderliche Sicherung nicht erfolgreich erstellt.

Das Plugin darf in diesen Fällen weder ergänzen noch raten.

## R-057 – Idempotenz und Wiederholbarkeit

Derselbe freigegebene Import muss beliebig oft ausgeführt werden können, ohne Dubletten, zusätzliche Menüeinträge oder veränderte Elternbeziehungen zu erzeugen. Importierte Objekte werden primär über stabile Konzept-IDs und gespeicherte Zuordnungsmetadaten erkannt.

## R-058 – Bestandsabgleich vor Neuanlage

Vor einer Neuanlage prüft das Plugin bestehende WordPress- und HivePress-Objekte anhand stabiler Zuordnungen sowie ergänzend anhand von Slug, Name, Elternbeziehung und Objektart. Ein unsicherer Treffer wird als Konflikt angezeigt und nicht automatisch übernommen oder dupliziert.

## R-059 – Keine automatische Löschung

Objekte, die in einer späteren Konzeptversion fehlen, werden niemals automatisch gelöscht. Sie werden als nicht mehr im aktuellen Konzept enthalten markiert. Löschen, Zusammenführen, Umleiten oder Archivieren benötigt einen eigenen sichtbaren Änderungsplan und eine separate Freigabe.

## R-060 – Sicherung, Protokoll und Rollback

Vor jedem schreibenden Import wird der relevante Ausgangszustand gesichert. Jeder Importlauf erhält eine eindeutige Lauf-ID, Konzeptversion, Zeitstempel, Objektliste, Vorher-/Nachher-Zuordnung und Ergebnisstatus. Mindestens der zuletzt vollständig ausgeführte Import muss kontrolliert zurückgesetzt werden können.

## R-061 – Kategoriehierarchie und sichtbare Navigation bleiben getrennt

Der Import der fachlichen Struktur erfolgt unabhängig von der sichtbaren Navigation. Erst nach erfolgreicher Anlage der Kategorien und Zielobjekte wird anhand eigener Navigationsregeln entschieden, welche Ebenen im Menü, auf Hubseiten, im Footer oder ausschließlich über interne Links erscheinen.

## R-062 – Unverbindliche Vorschläge werden nicht automatisch importiert

Beitragsarten-, Themen- und Longtail-Vorschläge mit unverbindlichem Status dürfen weder als Beitrag, Kategorie noch Keyword-Eigentümer angelegt werden. Ein Import ist erst nach dem bereits festgelegten ausdrücklichen Statuswechsel in einen verbindlichen Planungsgegenstand zulässig.

## R-063 – Testinstanz vor Produktivfreigabe

Alle schreibenden Importfunktionen werden zunächst ausschließlich auf einer WordPress-Testinstanz geprüft. Eine Produktivfreigabe ist erst zulässig, wenn Positivtests, Negativtests, Wiederholungsimport, Bestandsabgleich, Rollback und Ergebnisverifikation nachweislich bestanden sind.

## R-064 – Testdaten müssen allgemeingültige Grenzfälle enthalten

Die Testinstanz darf nicht nur mit einem projektspezifischen Bestand geprüft werden. Der Testsatz muss zusätzlich themenneutrale künstliche Positiv- und Negativfälle enthalten, darunter unterschiedliche Hierarchietiefen, identische sichtbare Namen in verschiedenen Blöcken als BLOCK-Fall, ähnlich benannte aber funktional getrennte Säulen als PASS/REVIEW-Fall, fehlende Eltern, Slugkollisionen, Synonyme, Ein-Kind-Hubs, leere Kategorien und bereits vorhandene Zielobjekte.

## R-065 – Schreibmodus bleibt bis zur Freigabe deaktiviert

Die erste technische Pluginstufe arbeitet ausschließlich als Parser, Validator und Importvorschau. Schreibzugriffe werden erst aktiviert, wenn Datenmodell, Zieladapter und Negativtests vollständig geprüft und ausdrücklich freigegeben wurden.

---

## R-066 – Allgemeingültigkeit hat Vorrang vor Beispielen

Jede Regel wird zuerst abstrakt und themenunabhängig formuliert. Beispiele dürfen keine feste Anzahl von Ebenen, keine themenspezifischen Namen, keine Portalbesonderheiten und keine installationsabhängigen WordPress- oder HivePress-Bezeichner zu allgemeinen Standards erheben.

## R-067 – Kürzester eindeutiger Kategoriename

Für den sichtbaren Kategorienamen wird immer der kürzeste fachlich korrekte, eindeutige und gebräuchliche Begriff verwendet. Eine längere Bezeichnung ist nur zulässig, wenn der kürzere Begriff mehrdeutig, fachlich ungenau oder außerhalb seines Elternkontexts missverständlich wäre. Erweiterte SEO-Formulierungen gehören in getrennte Felder wie H1, SEO-Titel, Beschreibung oder Metadaten.

## R-068 – Eindeutige Eltern-Kind-Zuordnung

Jede verbindliche Kategorie besitzt genau einen primären Elternknoten innerhalb desselben Blocks. Das Kind muss fachlich vollständig unter den Elternbegriff passen. Mehrere gleichwertige Eltern, bloße Ähnlichkeit, Keywordnähe oder technisch bequeme Zuordnung genügen nicht.

## R-069 – Einheitliches Ordnungskriterium je Geschwistergruppe

Geschwisterkategorien unter demselben Elternknoten werden grundsätzlich nach demselben fachlichen Hauptkriterium gebildet. Eine Mischung etwa aus Produkttyp, Zielgruppe, Problem, Material und Einsatzgebiet ist nur als dokumentierter Sonderfall zulässig, wenn keine verständlichere einheitliche Struktur möglich ist und keine Überschneidung entsteht.

## R-070 – Kategorien nur bei eigenständigem Themenkern

Eine neue Kategorie ist nur zulässig, wenn sie einen eigenständigen Themenkern, eine klare Suchintention, eine eindeutige Abgrenzung, eine logische Hierarchieposition und ausreichendes blockbezogenes Entwicklungspotenzial besitzt. Ein einzelnes Keyword oder eine SEO-Variante begründet keine Kategorie.

## R-071 – Keine Ein-Inhalt-Kategorie

Eine Kategorie wird grundsätzlich nicht für nur einen Beitrag, eine Anzeige oder ein Einzelobjekt angelegt. Abweichungen sind ausschließlich bei rechtlicher, zwingender technischer oder ausdrücklich freigegebener strategischer Notwendigkeit zulässig und müssen begründet gekennzeichnet werden.

## R-072 – Keine leeren oder künstlichen Zwischenebenen

Eine Zwischenebene muss eine echte Bündelungs-, Navigations-, Hub-, Such- oder Filterfunktion besitzen. Sie darf nicht nur angelegt werden, um eine gewünschte Tiefe oder optische Gleichmäßigkeit zu erzeugen.

## R-073 – Lückenlose Ebenenfolge

Die Ebene eines Kindes entspricht immer der berechneten Ebene seines Elternknotens plus eins. Ebenen dürfen nicht übersprungen werden. Die tatsächliche Ebene wird aus der Elternkette berechnet und mit der deklarierten Ebene verglichen. Abweichungen führen zu `BLOCKED`.

## R-074 – Blockbezogene Hierarchielogik

Content, HivePress, Magazin/Journal und Glossar besitzen eigene, funktionsgerechte Hierarchielogiken. Eine Struktur darf nicht nur deshalb in einen anderen Block kopiert werden, weil dort ähnliche Begriffe vorkommen.

## R-075 – Contenttiefe nach fachlichem Bedarf

Der Contentblock darf die größte fachliche Tiefe besitzen. Zusätzliche Ebenen sind zulässig und erforderlich, wenn sie mehrere eigenständige Kinder bündeln oder wenn unter einem konkreten Fachthema tragfähige Beitragsrichtungs-Kategorien nach R-013 entstehen. Jede zusätzliche Ebene muss für Nutzer verständlich, SEO-fachlich trennscharf und durch echte Inhalte beziehungsweise Longtails begründet sein. Künstliche Tiefe ohne eigenständige Kinder ist unzulässig.

## R-076 – Unterste Contentebene zwingend beitragstragende Kategorie

Auf WordPress-Basis ist die unterste verbindliche Contentebene zwingend eine WordPress-Kategorie oder eine geeignete hierarchische Taxonomie. Sie kann eine fachliche Themenkategorie oder eine tragfähige Beitragsrichtungs-Kategorie nach R-013 sein. Unter ihr werden die konkreten Longtail-Beiträge zugeordnet. Eine normale WordPress-Seite darf diese beitragstragende Endebene nicht ersetzen.

## R-077 – Seiten nur als übergeordnete Darstellungseinheiten

Normale WordPress-Seiten können als Start-, Hub-, Einstiegs-, Übersichts- oder Darstellungsseiten dienen. Sobald unter einem Strukturpunkt Beiträge systematisch gesammelt werden sollen, muss zusätzlich oder stattdessen ein geeignetes Kategorie- beziehungsweise Taxonomieobjekt vorhanden sein.

## R-078 – HivePress möglichst flach und marktorientiert

HivePress wird nur so tief strukturiert, wie Suchende und Inserierende die Ebenen tatsächlich zur Auffindbarkeit und eindeutigen Zuordnung benötigen. Größen, Farben, Zustände, Preise, Orte, Materialien und vergleichbare Merkmale werden grundsätzlich als Attribute oder Filter geprüft, bevor daraus Kategorien entstehen.

## R-079 – Magazin redaktionell flach und tragfähig

Magazin- und Journalrubriken bleiben übersichtlich, breit und dauerhaft tragfähig. Einzelne Fragen, Longtails und Beitragsarten wie Ratgeber, Vergleich, FAQ oder Anleitung sind grundsätzlich keine Rubriken, sondern Beitragsmetadaten beziehungsweise konkrete Beiträge.

## R-080 – Glossar grundsätzlich flach

Glossarbegriffe sind einzelne Definitionsobjekte. Eine tiefe Glossarhierarchie ist nur bei zwingendem fachlichem Bedarf zulässig. Ein Glossarbegriff darf nicht automatisch als Kategorie oder umfassender Ratgeber interpretiert werden.

## R-081 – Themenunabhängige Konzept-ID

Die dauerhafte Identität jedes verbindlichen Objekts wird durch eine systemweit eindeutige, themen-, sprach-, namens-, slug-, struktur- und installationsunabhängige Konzept-ID bestimmt. Sprechende IDs mit Portal-, Kategorie- oder Ebenennamen sind unzulässig.

## R-082 – Trennung interner und externer IDs

WordPress-Term-IDs, Seiten-IDs, HivePress-IDs, Menü-IDs und andere Zielsystemkennungen entstehen erst durch das Environment-Mapping oder den Import. Sie sind installationsabhängig und dürfen niemals die führende Identität des Konzeptobjekts darstellen.

## R-083 – Elternbeziehungen nur über Konzept-IDs

`parent_concept_id` verweist ausschließlich auf die stabile Konzept-ID des Elternobjekts. Namen, Slugs, Listenpositionen und externe Ziel-IDs dürfen nicht als primäre Elternreferenz verwendet werden.

## R-084 – IDs bleiben bei Umbenennung und Verschiebung erhalten

Eine Umbenennung, Slugänderung, Sortieränderung oder geprüfte Verschiebung erzeugt keine neue Konzept-ID. Bei fachlicher Aufspaltung entstehen neue IDs. Bei Zusammenführung bleiben alte IDs historisch als `REPLACED` oder `DEPRECATED` erhalten und werden niemals wiederverwendet.

## R-085 – Vorschlags-ID getrennt von Konzept-ID

Unverbindliche Kategorie- oder Beitragsvorschläge erhalten ausschließlich eigene Vorschlags-IDs. Eine verbindliche Konzept-ID entsteht erst nach ausdrücklicher Freigabe eines neuen Kategorieobjekts. Beitragsvorschläge bleiben bis zur Übergabe und Freigabe im Textsystem unverbindlich.

## R-086 – Keine ID-Wiederverwendung

Eine einmal vergebene Konzept-ID darf auch nach Löschung, Ersetzung, Zusammenführung oder Veraltung keinem anderen Objekt zugewiesen werden. Die historische Nachvollziehbarkeit bleibt dauerhaft erhalten.

## R-087 – Kategoriesystem als Konzeptquelle der Wahrheit

Die verbindliche Struktur wird im Kategoriesystem geführt. WordPress und HivePress sind Zielsysteme. Direkte Änderungen im Zielsystem dürfen die Konzeptstruktur nicht automatisch überschreiben, sondern erzeugen einen erkennbaren Synchronisationszustand oder Konflikt.

## R-088 – Drei-Wege-Synchronisationsprüfung

Bei Änderungen werden der verbindliche Konzeptstand, der zuletzt importierte Stand und der aktuelle Zielsystemstand verglichen. Wurde dasselbe Feld auf beiden Seiten unterschiedlich geändert, lautet das Ergebnis `CONFLICT`; ein blindes Überschreiben ist verboten.

## R-089 – Feldweise Änderungsklassifikation

Beschreibungen, SEO-Felder und Sortierung können als weniger kritisch klassifiziert werden. Primärblock, Objektart, Elternknoten, Ebene, Hauptkeyword, Suchintention und veröffentlichte Slugs gelten als kritisch und benötigen eine gesonderte Vorschau und Freigabe.

## R-090 – Fehlend ist nicht gleich leer

Das Importmodell unterscheidet technisch zwischen nicht geliefertem Feld, ausdrücklich zu leerendem Feld und unverändert zu lassendem Feld. Teilimporte dürfen bestehende Werte nicht unbeabsichtigt löschen.

## R-091 – Versions- und Paketidentität

Jedes Importpaket enthält mindestens `schema_version`, `package_version`, `package_id` und `created_at`. Diese Werte beschreiben Datenformat und Strukturstand, nicht die Identität einzelner Kategorien.

## R-092 – Vorschläge nur bei echter Strukturlücke

Eine neue Kategorie darf nur vorgeschlagen werden, wenn kein bestehender Kategorienraum ausreicht und Eigenständigkeit, Potenzial, Abgrenzung und Position plausibel sind. Synonyme führen nicht zu einem neuen Kategorienvorschlag, sondern zu einer Zuordnung zum bestehenden Objekt.

## R-093 – Automatische Zuordnung bleibt Empfehlung

Das System darf Block, Elternknoten, Ebene, Kurzname, Keywordrichtung und Suchintention empfehlen. Eine automatische Empfehlung wird niemals allein durch einen Vertrauenswert verbindlich. Bei mehreren gleichwertigen Möglichkeiten gilt `UNRESOLVED` oder `BLOCKED`.

## R-094 – Vorschläge müssen begründet und begrenzt sein

Jeder Vorschlag enthält Nutzen, Abgrenzung, empfohlene Zuordnung, Unsicherheiten und erkennbare Alternativen. Die Anzahl wird konfigurierbar begrenzt; bloße Titelvarianten und massenhafte Vorschlagsproduktion sind unzulässig.

## R-095 – Beitragsrichtungen zuerst auf Kategorie-Tragfähigkeit prüfen

Unter einem freigegebenen Fachthema werden FAQ, Tipps, Beratung, Vergleich, Ausrüstung/Werkzeug, Pflege, Kosten, Anwendung, Installation, Lagerung, Sicherheit und weitere Beitragsrichtungen zuerst darauf geprüft, ob sie nach R-011 eine eigene beitragstragende Kategorie bilden. Bei mindestens drei wichtigen, eigenständigen Longtails entsteht ein Kategorie-Kandidat. Erst unter der letzten freigegebenen Kategorie werden konkrete Beitragsthemen vorgeschlagen. Beitragsrichtung und konkretes Thema werden getrennt gespeichert.

## R-096 – Fachstruktur und Navigation getrennt

Die importierte Kategoriehierarchie bestimmt die fachliche Position. Die Navigation bestimmt Sichtbarkeit, Menüplatz und Darstellungsform. Eine nicht im Hauptmenü sichtbare Kategorie bleibt fachlich aktiv und muss über Hubseiten oder normale HTML-Links erreichbar sein.

## R-097 – Designseitige Umsetzung der Erreichbarkeitsgarantie

R-016 ist die kanonische fachliche Erreichbarkeitsregel. Das Designsystem muss für alle nicht im sichtbaren Menü ausgegebenen aktiven Kinder eine vollständige Erreichbarkeit über normale HTML-Links bereitstellen. Ob dies als Hubseite, Liste, Kachelstruktur oder andere geeignete Darstellung erfolgt, entscheidet ausschließlich das Designsystem.

## R-098 – Eigene Navigation je Block

Content, HivePress und Magazin/Journal erhalten getrennte Navigations- und Sichtbarkeitslogiken. HivePress- und Magazinstrukturen werden nicht automatisch als Content-Hauptnavigation ausgegeben.

## R-099 – Strukturelle Relationen statt Textlinks

Das Kategoriesystem speichert nur fachliche Beziehungen zwischen Content, HivePress, Magazin und Glossar. Es erzeugt keine kontextbezogenen Fließtextlinks oder Ankertexte. Diese entstehen im Textsystem; strukturierte Hubausgaben entstehen im Template- oder Designsystem.

## R-100 – Pflichtdaten einer verbindlichen Kategorie

Eine verbindliche Kategorie benötigt mindestens Konzept-ID, Block, Objektart, kurzen Namen, Slug, Eltern-Konzept-ID, berechnete und deklarierte Ebene, Sortierung, Hauptkeyword, primäre Suchintention, positive Zuständigkeitsdefinition, Ausschlussdefinition und Status. Ohne diese Daten ist sie nicht importierbar.

## R-101 – Kein vollständiger Import bei BLOCKED

Fachliche und technische Prüfung werden getrennt durchgeführt. Ein Gesamtlauf mit mindestens einem `BLOCKED`-Datensatz darf nicht schreibend ausgeführt werden. Ein Teillauf ist nur als ausdrücklich ausgewählter, vollständiger und abhängigkeitssicherer Teilbaum zulässig.

## R-102 – Eltern zuerst, Reihenfolge wird berechnet

Importreihenfolgen werden aus der Elternkette berechnet und nicht aus der Dateireihenfolge übernommen. Ein Kind wird nur verarbeitet, wenn sein Elternobjekt bereits existiert oder im selben Lauf vorher eindeutig angelegt wird.

## R-103 – Rein lesende erste Pluginstufe

Die erste technische Stufe liest Importpaket und WordPress-/HivePress-Bestand, validiert Schema, IDs, Hierarchie und Mapping und erzeugt eine vollständige Vorschau beziehungsweise einen Prüfbericht. Sie darf noch keine Kategorien, Seiten, Menüs oder Taxonomien anlegen oder verändern.

## R-104 – Testpaket bleibt allgemeingültig

Das erste Testpaket enthält einen kleinen, künstlichen, themenneutral interpretierbaren Positiv- und Negativbestand. Konkrete Beispielbegriffe dienen nur der Lesbarkeit. Schema, Prüfregeln, IDs, Zielrollen und erwartete Ergebnisse dürfen keinerlei Bindung an das Pferdethema enthalten.

## R-105 – Testinstanz als kontrollierte Ausführungsumgebung

Die WordPress-Testinstanz dient der Environment-Inventur, Trockenläufen, Positivtests, Negativtests, Wiederholungsprüfungen und späteren Rollbacktests. Technische Zielnamen und HivePress-Taxonomien werden aus dieser Instanz ausgelesen und niemals geraten.

## R-106 – Mehrsprachige Eigentümerschaft

Keyword- und Suchintentionseigentümerschaft wird je Sprach- und Zielmarktvariante geführt. Sprachlich unterschiedliche Seiten dürfen nur dann parallele Eigentümer desselben fachlichen Konzepts sein, wenn sie ausdrücklich als lokalisierte Varianten miteinander verknüpft sind. Übersetzungen erhalten keine unabhängige fachliche Eigentümerschaft allein aufgrund anderer Schreibweise. Regionale oder rechtliche Abweichungen dürfen getrennte Eigentümer begründen, müssen aber als eigenständige Zielmarktintention dokumentiert werden.

## R-107 – Sperre paralleler Importläufe

Pro Zielinstallation und betroffenem Strukturraum darf höchstens ein schreibender Import-, Rollback- oder Wiederherstellungslauf gleichzeitig aktiv sein. Weitere schreibende Läufe werden bis zum eindeutigen Abschluss oder kontrollierten Abbruch des laufenden Vorgangs blockiert. Lesende Inventur- und Vorschauprozesse dürfen nur dann parallel laufen, wenn sie den gesicherten Vergleichsstand eindeutig referenzieren und keine widersprüchliche Freigabe erzeugen.

## R-108 – Glossarinhalte bleiben Folgesystemaufgabe

Das Kategoriesystem definiert ausschließlich Glossarstruktur, Begriffseigentümerschaft, Abgrenzung und Relationen. Die Erstellung, Prüfung, Aktualisierung und Veröffentlichung einzelner Glossardefinitionen gehört zum dafür freigegebenen Text- oder Contentproduktionssystem. Solange kein solches System ausdrücklich zugeordnet ist, werden Glossarbegriffe nur als unverbindliche Vorschläge behandelt und nicht automatisch veröffentlicht.

## R-109 – Bewusst begrenzte Rollback-Reichweite

Verbindlich garantiert wird mindestens die vollständige Rücksetzung des zuletzt erfolgreich abgeschlossenen schreibenden Importlaufs. Eine weitergehende Historie mehrerer Importstände ist eine optionale Ausbauleistung. Diese Grenze muss vor jedem schreibenden Import sichtbar dokumentiert werden und darf nicht den Eindruck einer unbegrenzten Versionswiederherstellung erwecken.

## R-110 – DataForSEO ist Prüf- und Recherchegate, nicht Architektur-Owner

Die fachliche Drei-Säulen-Architektur wird aus dem abgegrenzten Projektkonzept durch Chat/Master entworfen. DataForSEO recherchiert und belegt Keywords, Suchintentionen, Keywordgruppen, Hierarchie- und Longtail-Signale und deckt Lücken auf, darf aber Kategorien nicht autonom anlegen, löschen, verschieben, zusammenführen oder umbenennen.

## R-111 – Projektweite Global-Coverage vor Detailresearch

Vor der kostenpflichtigen Detailrecherche eines neuen Projekts wird ein projektweiter Global-Coverage-Lauf mit ausdrücklich deklarierten, konzeptbasierten Discovery-Seeds durchgeführt. Ziel ist die Erkennung vollständig übersehener Hauptthemen. Ungeklärte relevante Global-Gaps blockieren jeden Detailresearch.

## R-112 – Kategorienamen müssen gegen starke Keywords geprüft werden

Für jeden sichtbaren Kategorienamen und jedes Primärkeyword wird geprüft, ob DataForSEO den Begriff belegt, ob innerhalb desselben fachlichen Cores eine stärkere oder passendere intentkompatible Bezeichnung existiert und ob die finale Wahl fachlich begründet ist. Suchvolumen allein entscheidet nicht.

## R-113 – Fehlende Keywordgruppen und Longtails müssen aktiv gesucht werden

Jeder Research-Cluster wird auf relevante unbesetzte Keywordgruppen geprüft. Unterste Content-Kategorien benötigen mindestens drei reale, in der gebundenen Research-Evidenz vorhandene und dem konkreten Knoten zuordenbare Longtails; der typische Zielbereich für die Freigabe liegt bei drei bis fünf oder mehr tragfähigen Beiträgen. Relevante unbesetzte Gruppen benötigen einen Owner oder eine dokumentierte ARTICLE_ONLY-, EXCLUDED- oder DEFERRED-Entscheidung. Die Detailrecherche muss die Primärkeywords der geplanten Content-Blätter zusätzlich als kontrollierte Seeds berücksichtigen, damit tiefe Beitragsrichtungs-Kategorien nicht durch zu breite Cluster-Seeds unsichtbar bleiben.

## R-114 – Sichtprüfung des vollständigen Drei-Säulen-Baums vor FINAL

Ein technischer oder DataForSEO-PASS ist keine Endfreigabe. Vor FINAL wird der komplette korrigierte Content-, Marketplace/HivePress- und Journal-Baum im Chat sichtbar dargestellt und gemeinsam auf Vollständigkeit, Hierarchie, Bezeichnungen, Säulenlogik, menschliche Plausibilität und fehlende Komponenten geprüft. Erst nach ausdrücklicher sichtbarer Freigabe ist FINAL zulässig.

## R-115 – Sichtfreigabe ist an den unveränderten Review-Scope gebunden

Die sichtbare Freigabe wird per SHA-256 an den exakt geprüften Struktur-Scope gebunden. Jede inhaltliche Änderung an Projekt, Research-Clustern, Coverage-Entscheidungen, Knoten, Zieladaptern oder Research-Bindung nach der Sichtprüfung invalidiert die Freigabe und erzwingt eine erneute Sichtprüfung. Reine Array-Reihenfolge gilt nicht als inhaltliche Änderung.

## R-116 – Fachthema vor Beitragsrichtungs-Kategorie

Eine Beitragsrichtungs-Kategorie wird immer unter einem fachlich konkreten Themenknoten angeordnet. Beispielstruktur abstrakt: Fachbereich → Teilthema → konkretes Thema → tragfähige Beitragsrichtung → einzelne Longtail-Beiträge. Beitragsrichtungen dürfen nicht als Ersatz für die fachliche Hierarchie an die Portalwurzel oder an eine sachlich unpassende Ebene gesetzt werden.

## R-117 – Fachthema kann Parent oder selbst Endkategorie sein

Besitzt ein konkretes Fachthema mehrere tragfähige Beitragsrichtungs-Kategorien, ist es deren Parent und selbst kein Content-Blatt. Gibt es keine sinnvolle weitere Gruppierung, kann das Fachthema selbst die unterste beitragstragende Kategorie sein, sofern es R-011 erfüllt. Die Hierarchie wird nicht künstlich verlängert.

## R-118 – Kontextuelle Namen für wiederkehrende Beitragsrichtungen

R-046 bleibt unverändert: identische sichtbare Kategorienamen sind portalweit verboten. Wiederkehrende Beitragsrichtungen werden deshalb bei Bedarf kontextuell eindeutig benannt, zum Beispiel „FAQ zu <Thema>“, „Tipps zu <Thema>“ oder „Ausrüstung für <Thema>“. Navigationsname, H1, SEO-Titel und Slug bleiben nach R-009 getrennte Felder und können für Lesbarkeit optimiert werden.

## R-119 – Keine starre Beitragsarten-Schablone

Nicht jedes Fachthema erhält dieselben Beitragsrichtungs-Kategorien. Das System prüft offen alle fachlich sinnvollen Richtungen und legt nur solche an, die eigenständige Suchintentionen und die Tragfähigkeit nach R-011 besitzen. Fehlende oder schwache Richtungen werden nicht zur optischen Symmetrie erzeugt.

## R-120 – Master-Contract-Hardlock

Jeder neue Lauf, jedes Kategoriepaket, jedes Global-Coverage-Paket und jedes Research-Paket muss exakt an `ALLGEMEINGUELTIGER_KATEGORIE_MASTER_016_WORKFLOW_HARDLOCK` gebunden sein. Eine fehlende oder andere Master-Contract-ID ist BLOCKED. Widersprüche zwischen aktiven normativen Masterdateien werden nicht durch Priorisierung oder Interpretation aufgelöst, sondern als `MASTER_CONTRACT_CONFLICT` blockiert.

## R-121 – Drei sichtbare Nutzerfreigaben sind technische Gates

Initialer Gesamtbaum, korrigierter Global-Gap-Gesamtbaum und finaler Gesamtbaum benötigen jeweils eine ausdrückliche sichtbare Nutzerfreigabe des exakt dargestellten Review-Scopes. Status und SHA-256 allein reichen nicht. Jede Freigabe benötigt eine serverseitig signierte Review-Quittung und den exakten sichtbaren Review-Scope-SHA-256. Ohne gültige Signatur oder bei Scopeabweichung ist der nächste Workflowabschnitt BLOCKED.

## R-122 – Zielmarkt und Sprache sind unveränderlicher Projektvertrag

Zielmarkt und Sprache werden im PROJECT CONTRACT festgelegt und sind Bestandteil aller Discovery-, Research- und Review-Scope-Hashes. DataForSEO-Laufzeitparameter sowie Global- und Research-Pakete müssen exakt dazu passen. Eine Änderung invalidiert die betreffende Freigabe und erfordert den vorgesehenen Workflow erneut; ein neu berechneter Außenhash darf diese Abweichung nicht legitimieren.

## R-123 – Global-Coverage benötigt explizite fachliche Einzelentscheidungen

Jeder relevante Global-Coverage-Core benötigt vor Detailresearch eine explizite Entscheidung `MAIN_TOPIC`, `SUBTOPIC`, `ARTICLE_ONLY` oder `OUT_OF_SCOPE`. Semantische oder Keyword-Ähnlichkeit ist nur ein Hinweis und niemals ein automatischer Coverage-PASS. `DEFERRED`, fehlende oder unbekannte Entscheidungen blockieren Detailresearch und FINAL.

## R-124 – Workflowreihenfolge ist nicht disponibel

Die 14 Stufen aus `15_WORKFLOW_HARDLOCK/VERBINDLICHER_WORKFLOW_14_STUFEN.md` sind exakt in dieser Reihenfolge auszuführen. Kein Schritt darf übersprungen, zusammengelegt, nachträglich simuliert, durch vorhandene ältere Evidenz ersetzt oder von Chat, Plugin oder Nutzer selbst als erledigt markiert werden. Fehlende Voraussetzung bedeutet BLOCKED.
