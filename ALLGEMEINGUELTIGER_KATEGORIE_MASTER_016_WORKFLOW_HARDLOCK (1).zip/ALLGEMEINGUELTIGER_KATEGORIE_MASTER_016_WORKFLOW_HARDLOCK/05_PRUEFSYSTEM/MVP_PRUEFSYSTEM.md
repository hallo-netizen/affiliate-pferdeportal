> **HISTORISCH / NICHT NORMATIV IN MASTER 016.** Diese Datei dokumentiert einen früheren Stand. Aktive Regeln und Workflow stehen ausschließlich in `15_WORKFLOW_HARDLOCK/MASTER_LOCK.json`; historische 4-Longtail-Anforderungen sind Übererfüllung, aktiv gilt 3.

# Messbares MVP-Prüfsystem

Status: `FESTGELEGT – CLAUDE-CHECK AUSSTEHEND`

## Harte Regeln

### H-001

Jeder Knoten besitzt genau einen Block.

- Prüfmethode: Automatisch
- Verstoß: FAIL

### H-002

Jeder Nicht-Wurzelknoten besitzt genau einen gültigen Elternknoten.

- Prüfmethode: Automatisch
- Verstoß: FAIL

### H-003

Keine Zyklen in der Hierarchie.

- Prüfmethode: Automatisch
- Verstoß: FAIL

### H-004

Keine verwaisten Knoten.

- Prüfmethode: Automatisch
- Verstoß: FAIL

### H-005

Jede concept_id ist portalweit eindeutig, stabil und nicht sprechend.

- Prüfmethode: Automatisch
- Verstoß: FAIL

### H-006

Jeder Slug ist innerhalb seines Blocks eindeutig.

- Prüfmethode: Automatisch
- Verstoß: FAIL

### H-007

Jeder Knoten enthält alle Pflichtfelder.

- Prüfmethode: Automatisch
- Verstoß: FAIL

### H-008

Jede konkrete Suchintention besitzt genau einen primären Keyword-Eigentümer.

- Prüfmethode: Hybrid
- Verstoß: FAIL

### H-009

Doppelte Begriffe über Blöcke sind nur bei dokumentiert unterschiedlicher Suchintention zulässig.

- Prüfmethode: Hybrid
- Verstoß: FAIL

### H-010

Jeder unterste Content-Knoten besitzt mindestens vier plausible eigenständige Longtail-Themen.

- Prüfmethode: Hybrid
- Verstoß: FAIL

### H-011

Keine Kategorie ist ein bedeutungsloser Sammelbegriff ohne klaren Scope.

- Prüfmethode: Qualitativ mit Anker
- Verstoß: FAIL

### H-012

Keine unnötige Ein-Kind-Hierarchie ohne dokumentierte Begründung.

- Prüfmethode: Hybrid
- Verstoß: FAIL

### H-013

Hauptnavigationstitel höchstens 24 Zeichen; Ausnahmen nur begründet.

- Prüfmethode: Automatisch
- Verstoß: FAIL

### H-014

Untere Kategorien höchstens 40 Zeichen; Ausnahmen nur begründet.

- Prüfmethode: Automatisch
- Verstoß: FAIL

### H-015

Content, Marktplatz und Magazin sind funktional getrennt.

- Prüfmethode: Hybrid
- Verstoß: FAIL

### H-016

Kategoriehierarchie endet vor individuellen Artikel-Longtails.

- Prüfmethode: Hybrid
- Verstoß: FAIL

### H-017

Keine automatische Schreib- oder Live-Importfunktion im MVP.

- Prüfmethode: Automatisch
- Verstoß: FAIL

### H-018

Keine Änderung am Pferde Atelier.

- Prüfmethode: Dokumentarisch
- Verstoß: FAIL

## Qualitative 100-Punkte-Rubrik

### Q1 – Fachliche Struktur und Vollständigkeit (20 Punkte)

#### Q1.1 – Hauptthemen fachlich vollständig abgedeckt (8 Punkte)

- **8 Punkte:** vollständig und ausgewogen
- **6 Punkte:** kleine Lücke
- **3 Punkte:** mehrere relevante Lücken
- **0 Punkte:** Kernbereiche fehlen

#### Q1.2 – Sinnvolle Stopptiefe ohne künstliche Aufblähung (6 Punkte)

- **6 Punkte:** fachlich sauber
- **4 Punkte:** einzelne fragliche Ebenen
- **2 Punkte:** deutlich zu tief/zu flach
- **0 Punkte:** unbrauchbar

#### Q1.3 – Fachliche Abgrenzung der Knoten (6 Punkte)

- **6 Punkte:** trennscharf
- **4 Punkte:** kleine Überlappungen
- **2 Punkte:** mehrere unklare Grenzen
- **0 Punkte:** breite Überschneidungen

### Q2 – Suchintention und Keyword-Eigentümerschaft (20 Punkte)

#### Q2.1 – Suchintention je Knoten klar und realistisch (8 Punkte)

- **8 Punkte:** alle klar differenziert
- **6 Punkte:** wenige Unschärfen
- **3 Punkte:** mehrere vermischte Intentionen
- **0 Punkte:** fehlt/überwiegend falsch

#### Q2.2 – Keyword-Eigentümerschaft eindeutig (7 Punkte)

- **7 Punkte:** keine Doppelzuständigkeit
- **5 Punkte:** eine geringe Unschärfe
- **2 Punkte:** mehrere unklare Eigentümer
- **0 Punkte:** systematische Doppelzuständigkeit

#### Q2.3 – Blockübergreifende Begriffsverwendung begründet (5 Punkte)

- **5 Punkte:** jede Wiederholung gerechtfertigt
- **3 Punkte:** einzelne schwache Begründungen
- **1 Punkte:** mehrere unbegründete Wiederholungen
- **0 Punkte:** keine Trennung

### Q3 – SEO-Hierarchie und Kannibalisierungsfreiheit (15 Punkte)

#### Q3.1 – Breit-zu-spezifisch-Hierarchie (6 Punkte)

- **6 Punkte:** durchgehend logisch
- **4 Punkte:** wenige lokale Brüche
- **2 Punkte:** mehrere Hierarchiesprünge
- **0 Punkte:** keine Logik

#### Q3.2 – Kannibalisierungsrisiko (6 Punkte)

- **6 Punkte:** keine ungeklärten Konflikte
- **4 Punkte:** kleine dokumentierte Restrisiken
- **2 Punkte:** mehrere Überschneidungen
- **0 Punkte:** starke Kannibalisierung

#### Q3.3 – SEO-Themenbreite je Ebene (3 Punkte)

- **3 Punkte:** angemessen verteilt
- **2 Punkte:** leichte Unwucht
- **1 Punkte:** deutliche Unwucht
- **0 Punkte:** unbrauchbar

### Q4 – Kategorienamen und Slugs (10 Punkte)

#### Q4.1 – Kategorienamen kurz, klar, gebräuchlich (6 Punkte)

- **6 Punkte:** nahezu durchgehend prägnant
- **4 Punkte:** wenige schwache Namen
- **2 Punkte:** mehrere sperrige Namen
- **0 Punkte:** überwiegend ungeeignet

#### Q4.2 – Slugs konsistent, verständlich, eindeutig (4 Punkte)

- **4 Punkte:** vollständig konsistent
- **3 Punkte:** kleine Inkonsistenzen
- **1 Punkte:** mehrere Probleme
- **0 Punkte:** unbrauchbar

### Q5 – Blocktrennung (10 Punkte)

#### Q5.1 – Content-/Affiliateblock funktional passend (4 Punkte)

- **4 Punkte:** durchgehend passend
- **3 Punkte:** kleine Fehlzuordnung
- **1 Punkte:** mehrere Fehlzuordnungen
- **0 Punkte:** verfehlt

#### Q5.2 – Marktplatz-/Dienstleistungsblock passend (3 Punkte)

- **3 Punkte:** durchgehend passend
- **2 Punkte:** kleine Fehlzuordnung
- **1 Punkte:** mehrere Fehlzuordnungen
- **0 Punkte:** verfehlt

#### Q5.3 – Magazin-/Wissensblock redaktionell eigenständig (3 Punkte)

- **3 Punkte:** klar eigenständig
- **2 Punkte:** kleine Überschneidungen
- **1 Punkte:** starke Überschneidungen
- **0 Punkte:** keine Eigenständigkeit

### Q6 – Longtail- und Beitragspotenzial (10 Punkte)

#### Q6.1 – Mindestens vier eigenständige Longtails je Blatt (6 Punkte)

- **6 Punkte:** alle Blätter erfüllen
- **4 Punkte:** wenige Grenzfälle
- **2 Punkte:** mehrere schwache Blätter
- **0 Punkte:** überwiegend verfehlt

#### Q6.2 – Longtails nicht nur Umformulierungen (4 Punkte)

- **4 Punkte:** klar eigenständig
- **3 Punkte:** wenige ähnliche Paare
- **1 Punkte:** mehrere Paraphrasen
- **0 Punkte:** keine Eigenständigkeit

### Q7 – Technische Konsistenz (10 Punkte)

#### Q7.1 – Schema- und Pflichtfeldkonformität (4 Punkte)

- **4 Punkte:** vollständig valide
- **3 Punkte:** kleine Mängel
- **1 Punkte:** mehrere Schemafehler
- **0 Punkte:** nicht maschinenlesbar

#### Q7.2 – IDs, Eltern, Level und Reihenfolge konsistent (4 Punkte)

- **4 Punkte:** vollständig konsistent
- **3 Punkte:** eine kleine Abweichung
- **1 Punkte:** mehrere Inkonsistenzen
- **0 Punkte:** strukturell fehlerhaft

#### Q7.3 – Lesbarer und maschinenlesbarer Export identisch (2 Punkte)

- **2 Punkte:** vollständig identisch
- **1 Punkte:** kleine Darstellungsabweichung
- **0 Punkte:** inhaltlicher Widerspruch

### Q8 – Verständlichkeit und praktische Nutzbarkeit (5 Punkte)

#### Q8.1 – Für technisch versierte Außenstehende nachvollziehbar (3 Punkte)

- **3 Punkte:** ohne Zusatzwissen klar
- **2 Punkte:** kleine Erklärlücken
- **1 Punkte:** mehrere Rückfragen
- **0 Punkte:** nicht nachvollziehbar

#### Q8.2 – Konflikte, Annahmen und Grenzen transparent (2 Punkte)

- **2 Punkte:** vollständig transparent
- **1 Punkte:** teilweise transparent
- **0 Punkte:** wesentliche Unsicherheiten verschwiegen

## Entscheidungslogik

| Harte Regeln | Score | Runde | Entscheidung |
|---|---:|---:|---|
| mindestens ein FAIL | beliebig | 0 oder 1 | `KORREKTUR_ERFORDERLICH` |
| mindestens ein FAIL | beliebig | 2 | `BLOCKED` |
| alle PASS | 85–100 | beliebig | `PASS` |
| alle PASS | 75–84 | 0 oder 1 | `KORREKTUR_ERFORDERLICH` |
| alle PASS | 0–74 | 0 oder 1 | `FAIL_KORREKTUR_ERFORDERLICH` |
| alle PASS | 0–84 | 2 | `BLOCKED` |

## Bewertungsregeln

- Nur explizit definierte Ankerwerte sind zulässig.
- Zwischenwerte sind verboten.
- Jede Punktzahl braucht Begründung und konkreten Beleg.
- Bei Unsicherheit gilt der niedrigere passende Anker.
- Harte Verstöße können nicht durch Punkte ausgeglichen werden.