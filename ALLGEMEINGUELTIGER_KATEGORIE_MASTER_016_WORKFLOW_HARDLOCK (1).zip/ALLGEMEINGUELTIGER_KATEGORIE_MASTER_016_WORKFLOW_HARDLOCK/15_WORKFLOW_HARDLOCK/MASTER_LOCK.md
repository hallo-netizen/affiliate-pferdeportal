# MASTER LOCK – ALLGEMEINGUELTIGER_KATEGORIE_MASTER_016_WORKFLOW_HARDLOCK

**Einzige aktive Vertrags-ID:** `ALLGEMEINGUELTIGER_KATEGORIE_MASTER_016_WORKFLOW_HARDLOCK`.

Nur die in `MASTER_LOCK.json` explizit gelisteten `active_normative_files` dürfen Regeln oder Workflow bestimmen. Alle anderen Dateien sind Dokumentation, Historie, Prüfbeleg oder Referenz und dürfen keine aktive Regel ersetzen.

**Konfliktregel:** Widersprechen sich zwei aktive normative Dateien, ist der gesamte Lauf `MASTER_CONTRACT_CONFLICT / BLOCKED`. Es ist ausdrücklich verboten, selbst eine Priorität zu wählen, eine ältere Regel zu bevorzugen oder eine plausible Lösung zu erraten. Zuerst muss Master 016 korrigiert und neu manifestiert werden.

**Content-Mindestsubstanz:** 3 wichtige eigenständige node-gebundene DataForSEO-Longtails. Historische 4er-Pilotregeln sind reine Übererfüllung und nicht normativ.

**Plugin:** ausschließlich dieselbe Linie `affiliate-portal-kategorie-workflow` V1.6.1. Kein Parallelplugin.
