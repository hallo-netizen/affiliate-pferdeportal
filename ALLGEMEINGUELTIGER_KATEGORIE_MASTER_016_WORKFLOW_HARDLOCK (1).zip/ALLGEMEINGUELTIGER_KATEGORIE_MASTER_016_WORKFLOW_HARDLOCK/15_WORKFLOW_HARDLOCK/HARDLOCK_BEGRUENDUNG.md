# HARDLOCK – Ursachen und Rootfixes

Bestätigte Ursachen vor Master 016:
1. Master 015 enthielt parallel alte 4-Longtail-Prüfbelege und neue aktive 3-Longtail-Regeln ohne ausreichend harte Quellenklassifizierung.
2. Ältere DataForSEO-Workflowdokumente beschrieben eine andere Review-Reihenfolge.
3. V1.6.0 konnte technisch korrekt wirkende Review-Status/Hashes nicht von manuell injizierten Quittungen unterscheiden.
4. Global-/Research-Pakete konnten nach Markt-/Sprachmanipulation mit neu berechnetem Außenhash nicht vollständig fail-closed gebunden werden.

Rootfix Master 016 / Plugin V1.6.1:
- expliziter MASTER LOCK mit aktiver Whitelist und Konflikt=BLOCKED;
- exakt 14 Workflowstufen;
- drei sichtbare Reviews jeweils mit exaktem sichtbaren Scope-Hash und serverseitiger HMAC-Signatur;
- Master-Contract-ID in Category-, Global- und Research-Paketen;
- Markt/Sprache end-to-end gebunden;
- Global-Ähnlichkeit nie fachliche Entscheidung; DEFERRED blockiert;
- keine Content-Writes.
