# Independent HARDLOCK Re-Audit – Master 016 / Plugin V1.6.1

Auditdatum: 2026-08-20 UTC

## Eingaben jetzt vollständig
- Master: `ALLGEMEINGUELTIGER_KATEGORIE_MASTER_016_WORKFLOW_HARDLOCK`
- eingebettete Source: `15_WORKFLOW_HARDLOCK/PLUGIN/QUELLCODE_V1.6.1`
- Source-ZIP: `QUELLCODE_KATEGORIE_WORKFLOW_V1.6.1_WORKFLOW_HARDLOCK.zip`
- Installer: `AFFILIATE_PORTAL_KATEGORIE_WORKFLOW_V1.6.1_WORKFLOW_HARDLOCK_FINALKANDIDAT.zip`

Der frühere externe Codex-Befund `BLOCKED` wegen fehlendem Master/Installer war ein Eingabe-Blocker und kann mit diesen gleichzeitig vorhandenen Dateien reproduzierbar aufgelöst werden. Er war kein Code-PASS.

## Beim erneuten Gesamtworkflow-Audit reproduzierte Codebefunde des vorherigen Finalkandidaten

### F-001 – Global-Gap-Signer prüfte den sichtbaren Scope-Hash nicht
Datei: `includes/class-apkw-admin.php`
Funktion: `APKW_Admin::sign_global_gap_review()`

Initial- und Finalsignierung riefen `require_visible_scope_match(...)` auf. Der Global-Gap-Signer erzeugte dagegen die HMAC-Quittung, ohne den im Formular verlangten sichtbaren Scope-Hash serverseitig zu vergleichen. Damit war Stufe 8 nicht entsprechend Master 016 fail-closed.

### F-002 – Zulässige Global-Korrektur wurde gegen die alte Initialfreigabe geprüft
Datei: `includes/class-apkw-admin.php`
Funktion: `APKW_Admin::sign_global_gap_review()`

Der korrigierte Baum wurde mit `validate_initial_review_gate($draft)` geprüft. Der Initial-Review-Scope bindet jedoch absichtlich Knoten und Research-Cluster. Jede echte fachliche Korrektur nach Global Coverage invalidiert deshalb den alten Initialhash. Richtig ist die Prüfung der ursprünglichen Initialfreigabe gegen `global_package.source_draft.package`; der korrigierte Baum bleibt separat über unveränderten Project-Discovery-Scope, Global-Bindung, vollständige Global-Gap-Entscheidungen und die neue sichtbare Global-Gap-Freigabe gebunden.

### F-003 – Explizite Bestätigung war serverseitig nur Presence-Check
Datei: `includes/class-apkw-admin.php`
Funktionen: `require_review_actor()`, `run_global_coverage()`, `run_detail_research()`

Ein manuell gesendeter POST-Wert `0` erfüllte `isset(...)`. Jetzt muss serverseitig exakt `1` vorliegen.

## Minimaler Rootfix ohne Architektur-/Versionswechsel
- Global-Gap-Signer prüft exakt `APKW_Validator::global_gap_review_scope_hash($draft)`.
- Initiale Kette wird dort gegen den unveränderten, hashgebundenen Source-Draft des verifizierten Global-Pakets geprüft.
- Review-/Paid-Bestätigungen akzeptieren nur exakt `1`.
- Keine Änderung an Plugin-Slug, Version 1.6.1, Paket-/Schema-Versionen, Contentlogik, Design, WordPress-/HivePress-Ausgabe oder DataForSEO-Entscheidungslogik.

## Reproduzierbarer Regressionstest
Erweiterte Testsuite gegen den **alten** Finalkandidaten:
- `113 PASS / 3 FAIL`
- FAIL: eigener Global-Gap-Scope-Hash im Signer fehlt
- FAIL: ursprünglicher signierter Initial-Draft wird im Global-Gap-Signer nicht verwendet
- FAIL: serverseitige Bestätigungen sind Presence-Checks

Dieselbe Suite gegen den Rootfix:
- `116 PASS / 0 FAIL`

## Gesamtworkflow-Nachweise nach Rootfix
- Master-Contract-ID exakt Master 016.
- Aktive Quellen ausschließlich nach `MASTER_LOCK.json`; 10 aktive Dateien; Konfliktaudit ohne Finding.
- exakt 14 Stufen.
- drei sichtbare Reviews: `manage_options`, Nonce, explizit `1`, jeweils eigener exakter sichtbarer Scope-Hash, serverseitige HMAC-Quittung.
- Markt/Sprache end-to-end gebunden; Rehash-Tamper-Negativtests PASS.
- Global-Core ohne explizite MAIN_TOPIC/SUBTOPIC/ARTICLE_ONLY/OUT_OF_SCOPE-Entscheidung BLOCKED; DEFERRED BLOCKED; Ähnlichkeit kein Auto-PASS.
- Content-Blatt-Regel >=3 reale node-gebundene DataForSEO-Longtails positiv/negativ getestet.
- Global: ein Call je freigegebenem Global-Lauf; Global-Gap-Korrektur + Detail-Preflight erzeugen 0 weitere Global-Calls. Detail verwendet deklarierte Cluster + erforderliche Overview-Batches.
- Preflight/Finalaudit: 0 externe Requests in den Negativ-/Positivtests.
- 0 WordPress-/HivePress-Content-Write-APIs in 9 Produktions-PHP-Dateien.
- Source, Source-ZIP-Fresh, Installer-Fresh und Standalone-Installer-Fresh: jeweils `116/116 PASS`.
- PHP-Lint: 10/10 PASS.
- JSON-Parse: 12/12 PASS.
- Source-Manifest: 34/34 verifiziert.
- Source↔Installer: 35/35 Dateien byteidentisch, 0 Unterschiede.

## Abgrenzung
Lokale Tests beweisen keinen echten WordPress-/DataForSEO-Live-Run. Ein externer Codex-Schlussaudit ist nach diesem Rootfix erneut auszuführen; der frühere Codex-BLOCKED-Bericht prüfte diese korrigierte Paketfassung nicht.
