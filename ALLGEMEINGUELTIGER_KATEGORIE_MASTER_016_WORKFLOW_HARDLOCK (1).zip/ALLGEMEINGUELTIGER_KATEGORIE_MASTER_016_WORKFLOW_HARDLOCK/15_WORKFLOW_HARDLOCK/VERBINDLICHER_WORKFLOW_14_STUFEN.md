# VERBINDLICHER 14-STUFEN-WORKFLOW – MASTER 016

Es gibt **keine alternative Reihenfolge, keinen Skip, keinen Self-PASS und keine Ersatzfreigabe**. Fehlt eine Voraussetzung, lautet das Ergebnis `BLOCKED`.

1. **MASTER LOCK** – exakt eine aktive Regelquelle: Master 016. Jede Vertragsabweichung = BLOCKED.
2. **PROJECT CONTRACT** – Projektkonzept, Scope, Ausschlüsse, Zielmarkt, Sprache und Discovery-Seeds vollständig festlegen. Diese Felder sind hashgebunden.
3. **INITIAL TREE** – Chat/Master erstellt den vollständigen Drei-Säulen-Erstentwurf Content + HivePress/Marketplace + Journal nach dem aktiven Regelwerk.
4. **INITIAL VISIBLE REVIEW** – kompletter Erstbaum wird sichtbar im Chat gezeigt. Nutzer prüft/korrigiert. Danach muss exakt der sichtbare Review-Scope-SHA-256 über den kontrollierten WordPress-Adminpfad serverseitig signiert werden. Status/Hash ohne Serversignatur = BLOCKED.
5. **FREE PREFLIGHT** – 0 externe Requests. Nur gültige signierte Initialfreigabe mit unverändertem Scope darf PASS erhalten.
6. **GLOBAL COVERAGE** – exakt 1 ausdrücklich kostenbestätigter projektweiter DataForSEO Keyword-Ideas-Call. Kein zweiter Global-Call im selben HARDLOCK-Lauf. Vor-HARDLOCK-Evidenz darf gelesen, aber nicht als Gate-Abschluss übernommen werden.
7. **GLOBAL GAP DECISION** – jeder relevante Global-Core benötigt explizit `MAIN_TOPIC`, `SUBTOPIC`, `ARTICLE_ONLY` oder `OUT_OF_SCOPE`. `DEFERRED`, fehlende Entscheidung und bloße Keyword-/Core-Ähnlichkeit schließen niemals das Gate.
8. **GLOBAL GAP VISIBLE REVIEW** – korrigierter Gesamtbaum plus sämtliche Global-Entscheidungen sichtbar im Chat. Danach exakt dieser Scope-Hash serverseitig signieren. Änderung = neue Sichtprüfung.
9. **DETAIL PREFLIGHT** – 0 externe Requests. Ungültige/stale/fremde Global-Bindung oder fehlende signierte Global-Gap-Freigabe = BLOCKED.
10. **DETAIL RESEARCH** – exakt 1 Keyword-Ideas-Call je freigegebenem Research-Cluster plus nur erforderliche Keyword-Overview-Batches. Global-Coverage wird wiederverwendet; kein zweiter Global-Call. Content-Blatt-Primärkeywords laufen als kontrollierte Tiefen-Seeds im bestehenden Cluster-Call mit.
11. **DATA-INFORMED CORRECTION** – Chat/Master verbindet Projektkonzept, aktuellen Baum und DataForSEO-Evidenz. DataForSEO darf keine Kategorie autonom anlegen, löschen, verschieben, zusammenführen, umbenennen oder freigeben.
12. **READ-ONLY TOTAL AUDIT** – Schema, Masterbindung, Hierarchie, Pillar-Trennung, DataForSEO-Evidenz, Longtails, Keyword-Ownership, Kannibalisierung und Live-Bestandsvorschau. 0 externe Requests; 0 WordPress-/HivePress-Content-Writes. PASS bedeutet nur `READY_FOR_VISIBLE_SIGHT_REVIEW`.
13. **FINAL VISIBLE REVIEW** – kompletter finaler Drei-Säulen-Baum sichtbar im Chat. Nutzer prüft/korrigiert. Exakt derselbe sichtbare Scope-Hash muss serverseitig signiert werden.
14. **FINAL VALIDATION** – jede Scopeänderung invalidiert die Freigabe. Nur identischer Master-Contract + identischer Scope + gültige Serversignatur + alle Gates PASS => `PASS_FINAL_APPROVED`.

## Unverrückbare Content-Regel
Eine Content-Kategorie ist nur tragfähig, wenn mindestens **3 wichtige, eigenständige, node-gebundene DataForSEO-Longtails** belegt sind. FAQ, Tipps, Beratung, Vergleich, Ausrüstung/Werkzeug usw. dürfen selbst Kategorien sein, wenn sie dieses Gate erfüllen. Einzelbeiträge liegen unter der letzten freigegebenen Kategorie. Keine starre Beitragsrichtungs-Schablone.

## Kostenregel
Preflights und Finalaudit: 0 externe Requests. Global: exakt 1 Paid Call. Detail: deklarierte Cluster + erforderliche Overview-Batches. Jeder Paid-Schritt benötigt vorherige gültige Reviewkette und ausdrückliche Kostenbestätigung.
