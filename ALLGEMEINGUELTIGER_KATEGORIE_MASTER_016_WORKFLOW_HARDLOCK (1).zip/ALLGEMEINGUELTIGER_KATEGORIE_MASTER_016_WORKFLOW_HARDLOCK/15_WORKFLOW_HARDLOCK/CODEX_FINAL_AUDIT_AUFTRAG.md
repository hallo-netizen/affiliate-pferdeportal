# CODEX FINAL AUDIT – MASTER 016 / PLUGIN V1.6.1

Verbindliche Eingaben gleichzeitig:
1. `ALLGEMEINGUELTIGER_KATEGORIE_MASTER_016_WORKFLOW_HARDLOCK.zip`
2. `QUELLCODE_KATEGORIE_WORKFLOW_V1.6.1_WORKFLOW_HARDLOCK.zip`

Keine Architekturänderung. Keine neue Plugin-Linie. Keine Versionsänderung. Nur unabhängig prüfen; Änderung ausschließlich bei reproduzierbarem Befund.

Zwingend prüfen:
- Master-Contract-ID exakt Master 016; aktive Quellen ausschließlich nach `15_WORKFLOW_HARDLOCK/MASTER_LOCK.json`; Konflikt aktiver Quellen => BLOCKED.
- exakt 14 Workflowstufen und keine Bypass-/Self-PASS-Pfade.
- Initial-, Global-Gap- und Finalfreigabe: `manage_options`, Nonce, ausdrückliche Bestätigung, exakter sichtbarer Scope-Hash, serverseitige HMAC-Quittung. Roh injizierter Status/Hash oder gefälschte Signatur => BLOCKED.
- Zielmarkt/Sprache nach jeder Sichtfreigabe unveränderlich; manipuliertes Global-/Research-Paket bleibt auch nach neu berechnetem Außenhash BLOCKED.
- Global-Core ohne explizite MAIN_TOPIC/SUBTOPIC/ARTICLE_ONLY/OUT_OF_SCOPE-Entscheidung => BLOCKED; DEFERRED => BLOCKED; Keyword-Ähnlichkeit niemals Auto-PASS.
- Content-Blatt und tragfähige FAQ/Tipps/Beratung/Vergleich/Ausrüstung-Kategorie: >=3 reale node-gebundene DataForSEO-Longtails; <3 BLOCKED.
- Global genau 1 Paid Call; Detail genau deklarierte Cluster + notwendige Overview-Batches; Preflight/Finalaudit 0 externe Calls.
- keine WordPress-/HivePress-Content-Writes.
- Source-Tests, Fresh-Unpack-Tests, PHP-Lint, JSON-Parse, SHA-Manifest, Source↔Installer-Bytevergleich.

Gesamturteil nur `PASS` oder `BLOCKED` mit reproduzierbarem Befund, Datei/Funktion, Root Cause und Testnachweis.
