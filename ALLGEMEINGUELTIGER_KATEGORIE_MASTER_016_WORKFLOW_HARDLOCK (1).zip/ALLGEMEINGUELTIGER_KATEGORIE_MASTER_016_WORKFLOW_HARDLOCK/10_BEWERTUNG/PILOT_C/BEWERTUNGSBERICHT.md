# Bewertungsbericht – Zimmerpflanzen für dunkle Räume

- Harte Regeln: **18/18 PASS**
- Qualitätsscore: **96/100**
- Entscheidung: **PASS**

## Nachweisqualität

- 21/21 pilotspezifische Belege
- 21/21 pilotspezifische Begründungen
- 18/18 konkrete harte Regelbelege
- 0 Platzhaltertexte
