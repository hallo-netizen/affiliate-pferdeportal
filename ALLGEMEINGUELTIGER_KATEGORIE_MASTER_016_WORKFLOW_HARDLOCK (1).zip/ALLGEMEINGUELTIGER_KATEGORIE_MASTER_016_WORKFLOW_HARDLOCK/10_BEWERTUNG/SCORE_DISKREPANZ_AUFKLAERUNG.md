# Aufklärung der Score-Diskrepanz

Die Einzelanker ergeben reproduzierbar 98/100, 98/100 und 96/100.

Die Werte 96/96/94 waren vorläufige Textwerte während der Erstellung von MASTER 006. Nach vollständiger Berechnung der 21 Einzelwerte wurden die aktiven Ergebnis- und Statusdateien auf 98/98/96 korrigiert. Die Claude-Prüfdatei enthielt versehentlich noch die alte Kontrollfrage. Das war ein Synchronisierungsfehler der Prüfdatei, keine Änderung des Prüfsystems, der Pilotmodelle oder der Einzelpunktwerte.

Verbindlich sind ausschließlich 98/98/96.
