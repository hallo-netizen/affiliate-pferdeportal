# Kritische Auswertung des Wassertechnik-Testlaufs

## Bestätigt und in die Erweiterung übernommen

- Der einheitliche Kategorie-Intent ist für eine grobe Blockzuordnung zulässig,
  reicht aber nicht als Query-/Seitenintent für die Produktion.
- Keyword- und SERP-Validierung wird für dichte und zentrale Cluster zum Gate.
- Monetarisierbarkeit wird je Hauptast geprüft und als eigene Rolle dokumentiert.
- Rechtlich und gesundheitlich sensible Themen erhalten ein Publikationsgate.
- Bewusste Ausschlüsse erhalten ein dauerhaftes Register.

## Präzisierung gegenüber dem Review

- Die Wassertechnik-Struktur selbst ist nicht fehlerhaft. Der Befund betrifft
  die Produktionsreife. Daher lautet der korrekte Status nicht „Struktur
  verwerfen“, sondern `STRUCTURE_APPROVED / PRODUCTION_VALIDATION_REQUIRED`.
- Die Scope-Texte sind interne Steuerungsmetadaten. Ein Google-Duplicate-Content-
  Risiko entsteht nur, wenn sie fälschlich veröffentlicht werden. Deshalb wird
  ihre Sichtbarkeit verbindlich auf `INTERNAL_ONLY` gesetzt.
- Fehlende klassische Affiliateprogramme machen einen fachlich wichtigen Ast
  nicht automatisch unzulässig. Er kann Leadgen-, Marketplace- oder
  Editorial-Support-Funktion besitzen; die Rolle muss jedoch vor Priorisierung
  belegt werden.
