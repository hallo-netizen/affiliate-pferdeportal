# KATEGORIEKONZEPT-MASTER NEU 028

**Projekt:** Allgemeingültige Kategoriesystem-Maschine für WordPress-Affiliateportale  
**Stand:** 26.07.2026  
**Status:** Grundkonzeption abgeschlossen; rein lesende technische Inventur und Bestandsprüfung des Pferdeportals erfolgreich abgeschlossen  
**Referenzobjekt:** Pferde Atelier  

---

## 1. Funktion dieser Masterdatei

Diese Datei ist die vollständige und chatübergreifend nutzbare Arbeitsgrundlage für die Entwicklung des allgemeingültigen Kategoriekonzepts und des späteren WordPress-Importplugins.

Sie muss nach jedem abgeschlossenen größeren Arbeitspaket vollständig aktualisiert werden. Neue Fassungen werden fortlaufend nummeriert und im Dateinamen eindeutig mit `NEU` gekennzeichnet. Eine neue Fassung ersetzt die vorherige als aktuelle Arbeitsgrundlage, bleibt aber ein vollständiger Gesamtstand und kein bloßes Änderungsprotokoll.

Jede künftige Fassung enthält mindestens:

- Endziel und Projektgrenzen
- verbindliche Regeln
- bestätigte Entscheidungen
- geprüfte Erkenntnisse
- erledigte Arbeitsschritte
- offene Arbeitsschritte
- Plugin-Zielbild und technischer Stand
- erkannte Risiken und Blocker
- genau den nächsten zulässigen Arbeitsschritt
- Versions- und Änderungshistorie

Das Pferde-Atelier ist ausschließlich Referenz-, Test- und Härtungsobjekt. Pferdespezifische Begriffe oder zufällige Eigenschaften des bestehenden Portals dürfen nicht ungeprüft zu allgemeinen Regeln werden.

**Oberste Leitregel:** Jede fachliche, technische und organisatorische Festlegung muss zuerst themen-, sprach-, portal- und installationsunabhängig formuliert werden. Konkrete Beispiele, insbesondere aus dem Pferde-Atelier, dienen ausschließlich der Veranschaulichung und Prüfung. Sie dürfen niemals den allgemeinen Regelkern bestimmen oder einschränken.

**Zweite gleichrangige Leitregel:** Das System wird auf größtmögliche Automatisierung ausgelegt. Im optimalen Standardfall gibt der Nutzer ausschließlich das Hauptthema vor. Recherche, Strukturentwurf, Blockbildung, Hierarchie, Selbstprüfung, Korrektur, Auswahl des besten Entwurfs, Importvorbereitung und technische Vorprüfung erfolgen automatisch. Nutzerentscheidungen werden nur bei echten, nicht regelbasiert lösbaren Grundsatzkonflikten verlangt.

**Kommunikationsregel:** Technische Datenmodelle, Feldlisten, Fehlercodes, Schemas und Implementierungsdetails werden vollständig in dieser Masterdatei dokumentiert. Im normalen Entwicklungsdialog werden nur verständliche konzeptionelle Entscheidungen, kritische Prüfungen, Ergebnisse und nächste Schritte knapp dargestellt.

---

## 2. Endziel

Entwickelt wird ein allgemeingültiger Workflow, der zu einem beliebigen Thema ein vollständiges, recherchiertes und SEO-logisch abgestimmtes Kategoriekonzept für drei getrennte Portalhauptblöcke sowie eine eigenständige Glossarfunktion erstellt:

1. **Content-/Affiliate-Bereich**
2. **HivePress-Anzeigenmarkt**
3. **Journal-/Magazinbereich**
4. **Glossar als eigenständiger Funktionsblock beziehungsweise klar getrennte Querfunktion**

Der optimale Standardablauf beginnt mit genau einer Pflichtangabe: dem Hauptthema. Weitere Angaben dürfen nur verlangt werden, wenn sie für eine fachlich eindeutige Struktur tatsächlich unverzichtbar sind und nicht automatisch ermittelt oder sinnvoll vorbelegt werden können.

Der Workflow muss:

- relevante Keywords, Suchfragen, Themen, Produkte, Probleme, Anbieterarten und redaktionelle Themen recherchieren;
- Suchintentionen erkennen;
- Themen hierarchisch ordnen;
- jedem Keywordcluster genau eine primäre Zielseite zuweisen;
- Keyword-Kannibalisierung innerhalb eines Blocks und zwischen allen Funktionsblöcken verhindern;
- Seiten, Kategorien, Beitragsbereiche, Navigation, URLs und interne Verlinkungen planen;
- ungeeignete, doppelte oder zu schwache Strukturen blockieren;
- einen vollständig prüfbaren Konzeptentwurf ausgeben;
- erst nach ausdrücklicher Freigabe in WordPress und HivePress importieren.

Das spätere Plugin importiert die freigegebene Struktur. Die Texterstellung und das Design bleiben eigenständige Systeme und übernehmen anschließend die erzeugte Struktur.

---

## 3. Unveränderliche Projektgrenzen

### 3.1 Im Umfang

- Kategorierecherche und Themenrecherche
- Keyword- und Suchintentionsmodell
- Hierarchiebildung
- Blockzuordnung
- Anti-Kannibalisierungslogik
- Navigationsplanung
- URL- und Slugplanung
- Zuordnung möglicher Beitragsarten
- interne Verlinkungsplanung
- Prüf- und Freigabelogik
- WordPress-/HivePress-Importplugin

### 3.2 Nicht Bestandteil dieses Projekts

- eigentliche Artikelerstellung
- Artikelvalidierung der Textproduktionsmaschine
- Seitendesign und visuelle Templates
- automatische Bildauswahl oder Bilderstellung
- Änderungen an der gesperrten Navigation oder am gesperrten Design des Pferde-Ateliers

Schnittstellen zu diesen Systemen werden definiert, ihre interne Arbeitsweise wird hier nicht neu entwickelt.

---

## 4. Allgemeingültiges Vier-Funktionsblock-Modell

### 4.1 Content-/Affiliate-Bereich

**Aufgabe:** Dauerhafte Informations-, Problemlösungs-, Auswahl-, Vergleichs-, Anwendungs- und Kaufintentionen abdecken.

**Grundhierarchie:**

- Ebene 1: breites Hauptthema
- Ebene 2: klar abgegrenzte Themen- oder Produktfamilie
- Ebene 3: konkretes Thema, Produkt, Problem oder Lösungsfeld
- Ebene 4: geeignete Beitragsbereiche beziehungsweise WordPress-Kategorien
- darunter: einzelne Longtail-Beiträge

Im Hauptmenü werden nur die dafür freigegebenen Ebenen dargestellt. Tiefer liegende Beitragsbereiche werden vollständig über die zugehörigen Hubseiten erreichbar gemacht.

### 4.2 HivePress-Anzeigenmarkt

**Aufgabe:** Anbieter-, Händler-, Dienstleister-, Shop-, Hersteller-, Angebots- und gegebenenfalls private Angebotsintentionen abdecken.

**Grundhierarchie:**

- Anbieter-Hauptbereich
- konkreter Anbieter- oder Angebotstyp
- einzelne Anzeigen

Region, Preis, Leistungsmerkmale und ähnliche Filtermerkmale sollen grundsätzlich als Attribute oder Filter behandelt werden und nicht ungeprüft zu einer massenhaften Kategorievervielfachung führen.

### 4.3 Journal-/Magazinbereich

**Aufgabe:** Redaktionelle, gesellschaftliche, kulturelle, aktuelle, persönliche, wissenschaftliche oder übergreifend erklärende Themen abdecken, die nicht dieselbe Suchaufgabe wie eine Content-Zielseite erfüllen.

**Grundhierarchie:**

- wenige breite, dauerhaft tragfähige Rubriken
- einzelne Magazin- oder Journalbeiträge

Ein Beitrag erhält genau eine primäre Magazinrubrik. Querverbindungen werden nicht durch Mehrfachzuordnung konkurrierender Hauptkategorien erzeugt.

### 4.4 Glossar

**Aufgabe:** Einen Begriff eindeutig, knapp und fachlich korrekt erklären.

Das Glossar darf keine zweite ausführliche Ratgeberseite zu einem bereits vergebenen Suchcluster erzeugen. Umfangreiche Fragen, Kaufentscheidungen und Problemlösungen gehören in den Contentbereich. Glossareinträge verlinken auf die zuständige Vertiefungsseite.

---

## 5. Verbindliche allgemeine Regeln

### R-001 Themenunabhängigkeit

Jede Regel muss ohne themenspezifische Sonderannahmen auf andere Portale übertragbar sein. Thematische Beispiele dienen nur der Prüfung.

### R-002 Eindeutige Keyword-Eigentümerschaft

Jeder semantische Suchcluster erhält genau eine primäre indexierbare Zielseite. Andere Seiten dürfen das Thema unterstützend erwähnen und auf die Eigentümerseite verlinken, dürfen aber nicht dieselbe Suchintention vollständig erneut bedienen.

### R-003 Suchintention vor Wortgleichheit

Gleiche Wörter bedeuten nicht automatisch Kannibalisierung. Entscheidend ist, ob Nutzer mit den Suchanfragen dieselbe Aufgabe lösen wollen. Umgekehrt können unterschiedliche Formulierungen dieselbe Suchintention besitzen und deshalb konkurrieren.

### R-004 Strikte Blockzuordnung

Jeder Zielseitencluster wird primär genau einem Block zugewiesen: Content, HivePress, Magazin oder Glossar. Die Zuweisung muss maschinenlesbar begründet werden.

### R-005 Hierarchie von breit nach konkret

Mit jeder tieferen Ebene muss der Themenumfang enger und die Suchabsicht konkreter werden. Ein Kindknoten darf nicht breiter, gleichbedeutend oder nur sprachlich anders formuliert sein als sein Elternknoten.

### R-006 Keyword-Vererbung

Ein Kindthema übernimmt den sachlichen Kern seines Elternclusters und ergänzt ein unterscheidendes Merkmal. Es darf den Elternbegriff nicht lediglich wiederholen.

### R-007 Geschwister müssen trennscharf sein

Geschwisterknoten benötigen eigenständige Suchintentionen oder klar unterscheidbare Gegenstände. Synonyme, Singular/Plural, Schreibvarianten und nahezu identische Nutzungszwecke dürfen nicht als getrennte Geschwister angelegt werden.

### R-008 Kurze und prägnante Navigationsbezeichnungen

Navigationsnamen müssen verständlich, keywordbezogen, visuell kompakt und ohne unnötige Füllwörter formuliert sein. Jeder Navigationsname bezeichnet möglichst genau ein Thema.

Die zulässige sichtbare Länge wird als konfigurierbarer Designparameter geführt und nicht als sprachunabhängige starre Zeichenzahl festgeschrieben.

### R-009 Navigationsname und SEO-Titel getrennt

Der kurze Navigationsname, der vollständige Seitentitel, der SEO-Titel, die H1 und der URL-Slug werden als getrennte Felder verwaltet. Sie müssen semantisch zusammenpassen, dürfen aber unterschiedlich lang formuliert sein.

### R-010 Keine erzwungene Symmetrie

Nicht jedes Hauptthema benötigt gleich viele Unterkategorien. Nicht jedes konkrete Thema benötigt dieselben Beitragsarten. Die Struktur folgt nachgewiesener Nachfrage und Suchintention, nicht einem optisch gleichmäßigen Raster.

### R-011 Mindestsubstanz für Kategorien

Eine Kategorie wird nur freigegeben, wenn ausreichend eigenständige Inhalte, Unterthemen oder Angebote vorhanden beziehungsweise belastbar planbar sind. Es gilt keine themenunabhängig starre Mindestzahl. Die Tragfähigkeit wird blockbezogen und anhand eigenständiger Suchintentionen bewertet. Konfigurierbare Orientierungswerte dürfen die Prüfung unterstützen, aber keine fachlich unpassende Kategorie erzwingen oder eine fachlich notwendige Kategorie allein wegen einer Zahl ausschließen. Die bloße Erzeugung ähnlicher Titel erfüllt diese Regel nicht.

### R-012 Mindestsubstanz für Elternknoten

Ein reiner Navigations- oder Hubknoten benötigt grundsätzlich mindestens zwei trennscharfe, sinnvolle Kinder oder einen nachgewiesenen eigenständigen Such- und Nutzerwert. Die Zahl zwei ist keine frei gewählte Mengenvorgabe, sondern die logische Mindestbedingung für einen reinen Bündelungsknoten. Ein Ein-Kind-Knoten wird zusammengeführt oder ausdrücklich als begründeter Sonderfall dokumentiert.

### R-013 Beitragsarten nach Eignung

FAQ, Beratung, Vergleich, Pflege sowie spätere Typen wie Kosten, Anwendung, Installation oder Sicherheit werden nur erzeugt, wenn eine eigenständige Suchintention und genügend unterscheidbarer Inhalt nachweisbar sind.

### R-014 Keine leeren Kategorien

Leere Kategorien dürfen nicht veröffentlicht oder indexiert werden. Vorbereitete Kategorien bleiben Entwurf, bis ihre Mindestsubstanz erreicht ist.

### R-015 Keine unspezifischen Sammelbecken

Bezeichnungen wie „Sonstiges“, „Weitere Themen“ oder „Allgemein“ sind grundsätzlich unzulässig. Eine Ausnahme erfordert eine konkrete, dokumentierte fachliche Abgrenzung.

### R-016 Vollständige Erreichbarkeit

Jede freigegebene Kategorie muss über normale HTML-Links erreichbar sein. Begrenzungen des Megamenüs dürfen keine Kategorie dauerhaft unerreichbar machen. Alle nicht im Menü sichtbaren Kinder müssen über eine geeignete Hub-, Listen- oder sonstige vom Designsystem bereitgestellte Struktur vollständig erreichbar sein. Diese Erreichbarkeitsgarantie ist eine verbindliche Schnittstellenanforderung an das Designsystem; die konkrete sichtbare Ausgestaltung bleibt dessen Zuständigkeit.

### R-017 Navigation und Taxonomie getrennt modellieren

Die sichtbare Navigation ist nicht automatisch die technische Taxonomie. Das System speichert fachliche Eltern-Kind-Beziehungen unabhängig von Menüeinträgen und erzeugt beide kontrolliert.

### R-018 Stabile URL-Struktur

Slugs müssen kurz, eindeutig, dauerhaft und aus dem primären Thema ableitbar sein. Schreibvarianten, Trackingbegriffe, Jahreszahlen ohne dauerhaften Zweck und unnötige Hierarchiewiederholungen sind zu vermeiden.

### R-019 Keine URL-Kollision

Vor dem Import werden vorhandene Seiten, Beiträge, Kategorien, HivePress-Taxonomien und Weiterleitungen auf Slug- und Zielkonflikte geprüft.

### R-020 Existierender Bestand vor Neuanlage

Vor jeder Neuanlage ist der relevante Bestand zu inventarisieren. Die technische Erkennungs- und Konfliktlogik richtet sich verbindlich nach R-058. Bestehende Inhalte werden nicht stillschweigend dupliziert.

### R-021 Synonym- und Entitätsprüfung

Jedes Cluster erhält Hauptbegriff, Synonyme, Oberbegriffe, Unterbegriffe und mögliche Mehrdeutigkeiten. Marken, Produkttypen, Tätigkeiten, Probleme und Anbieterarten werden als unterschiedliche Entitätsrollen behandelt.

### R-022 Blockübergreifende Kannibalisierungsprüfung

Die Prüfung umfasst mindestens:

- identische und ähnliche Hauptkeywords
- Synonyme und Schreibvarianten
- gleiche Suchintention
- gleiche SERP-Aufgabe
- konkurrierende Titel und H1
- konkurrierende Slugs
- inhaltlich weitgehend gleiche geplante Abdeckung
- doppelte lokale oder Anbieterintentionen

### R-023 Unterstützende Verlinkung statt Konkurrenz

Inhaltlich verwandte Seiten verschiedener Blöcke werden durch klare Rollen und interne Links verbunden. Eine Contentseite kann beispielsweise einen passenden Anbieterbereich verlinken, ohne selbst ein Anbieterverzeichnis zu werden.

### R-024 Magazin nicht als Resteverwertung

Das Magazin erhält nur eigenständige redaktionelle Themen. Ein Keyword darf nicht allein deshalb ins Magazin verschoben werden, weil es im Contentbaum keinen Platz gefunden hat.

### R-025 HivePress-Kategorien nach Anbieterintention

HivePress-Kategorien werden nach dem gesucht oder angebotenen Anbieter-, Dienstleistungs- oder Angebotstyp gebildet. Reine Informationsfragen und bloße Produktmerkmale sind keine HivePress-Kategorien.

### R-026 Filter statt Kategorienexplosion

Standort, Preisbereich, Zielgruppe, Material, Größe, Verfügbarkeit und vergleichbare Merkmale werden bevorzugt als Filter oder Attribute geführt, sofern sie keine eigenständige navigationswürdige Suchintention besitzen.

### R-027 Datenbelegte Recherche

Kategorien dürfen nicht allein aus Modellwissen oder Vermutungen erzeugt werden. Die Recherchegrundlage, verwendeten Quellen, Suchfragen, Keywordvarianten und entscheidenden Belege werden protokolliert.

### R-028 Aktualität und Quellenqualität

Zeitabhängige Informationen werden mit aktuellen Quellen geprüft. Für technische, rechtliche, medizinische oder finanzielle Themen sind vorrangig belastbare Primär- oder Fachquellen zu verwenden.

### R-029 Kein automatischer Import bei Unsicherheit

Unklare Zuordnungen, ungelöste Dubletten, nicht belegte Kategorien oder Kannibalisierungsrisiken führen zu `BLOCKED`. Das System darf nicht raten.

### R-030 Vorschau vor Schreibzugriff

Vor jedem Import wird eine vollständige Vorschau mit Hierarchie, Namen, Zieltypen, Slugs, Keyword-Eigentümern, Konflikten und geplanten Änderungen ausgegeben. Der Import erfolgt erst nach ausdrücklicher Freigabe.

### R-031 Idempotenter Import

Jeder Import muss idempotent sein. Die vollständige technische Anforderung und Wiederholbarkeitsprüfung richtet sich verbindlich nach R-057.

### R-032 Keine stillen Änderungen

Bestehende URLs, Namen, Elternbeziehungen oder Veröffentlichungszustände dürfen nicht ohne Vorschau und Freigabe geändert werden.

### R-033 Rückverfolgbarkeit

Jedes importierte Objekt erhält eine stabile interne Konzept-ID und eine Verbindung zur freigegebenen Konzeptversion.

### R-034 Positiv- und Negativprüfungen

Vor einer Pluginfreigabe müssen Positivtests korrekte Strukturen importieren und Negativtests mindestens Dubletten, falsche Hierarchien, Blockkonflikte, leere Kategorien und wiederholte Imports zuverlässig blockieren.

### R-035 Trennung der Systeme

Das Kategorieplugin erzeugt und verwaltet Struktur und Metadaten. Text- und Designsysteme konsumieren diese Daten über definierte Schnittstellen. Keine feste Pferde-, Kategorie-, Text- oder Designlogik wird hart im Plugin eingebaut.

### R-036 Verbindliche Zuständigkeit bis zur untersten Kategorieebene

Das Kategoriesystem entwickelt, prüft und verwaltet die Struktur verbindlich bis einschließlich der jeweils untersten freigegebenen Kategorieebene. Diese Grenze gilt für Content, HivePress sowie Magazin/Journal. Konkrete Beiträge, Anzeigen oder redaktionelle Einzelinhalte gehören nicht mehr zur verbindlichen Strukturplanung dieses Systems.

### R-037 Unverbindliche Vorschläge unterhalb der Kategorieebene

Unterhalb der verbindlichen Kategorieebene darf das System geeignete Beitragsarten, Themenrichtungen, Fragestellungen oder Longtail-Richtungen vorschlagen. Jeder Vorschlag ist ausdrücklich als unverbindlich zu kennzeichnen und erzeugt weder Keyword-Eigentümerschaft noch eine Reservierung im verbindlichen Redaktionsplan.

### R-038 Verbindlichkeit nur durch ausdrücklichen Statuswechsel

Ein unverbindlicher Vorschlag kann abhängig vom späteren Plugin- und Workflowmodell in einen verbindlichen Planungsgegenstand überführt werden. Dies ist nur durch einen eindeutig protokollierten Freigabe- oder Statuswechsel zulässig. Ein automatischer Wechsel in einen verbindlichen Zustand ist verboten.

### R-039 Primärfunktion je Inhaltsblock

Jeder Inhaltsblock besitzt eine eigene Hauptaufgabe: Content bildet dauerhafte Informations- und Themenstrukturen ab, HivePress konkrete Markt-, Anbieter- und Angebotsintentionen, Magazin/Journal eigenständige redaktionelle Inhalte. Kein Objekt darf in mehreren Blöcken dieselbe primäre Funktion erfüllen.

### R-040 Suchintention entscheidet über den Block

Die Blockzuordnung richtet sich nach der konkreten Nutzeraufgabe und nicht allein nach dem verwendeten Begriff. Dasselbe Thema oder Wort darf in mehreren Blöcken vorkommen, wenn die primären Suchintentionen nachweisbar verschieden sind.

### R-041 Eigene Seitentypen je Block

Content, HivePress und Magazin/Journal verwenden getrennte Objekt- und Seitentypen. Contentseiten, Hubs und Kategorien dürfen nicht als Anzeigenkategorien behandelt werden; Anzeigenkategorien und Anzeigen dürfen nicht als redaktionelle Inhalte modelliert werden; Magazinrubriken und Beiträge dürfen keine zweite Contentnavigation bilden.

### R-042 Content und Magazin klar trennen

Content bildet den dauerhaften strukturierten Einstieg in ein Themenfeld. Magazin/Journal behandelt einzelne redaktionelle Fragen, Entwicklungen, Erfahrungen, Hintergründe oder Einordnungen. Ein Magazinbeitrag darf nicht dieselbe dauerhafte Hauptaufgabe wie eine Content-Zielseite übernehmen.

### R-043 HivePress nicht als zweite Contenthierarchie

Die HivePress-Struktur folgt der realen Angebots-, Anbieter- und Marktsuche. Sie muss die Contenthierarchie weder spiegeln noch vollständig übernehmen. Fachliche Informationstiefe gehört in den Contentblock; Marktauffindbarkeit, Angebotstypen und geeignete Filterlogik gehören in HivePress.

### R-044 Verknüpfung ohne Vermischung

Die Blöcke dürfen und sollen sich gegenseitig über klare interne Links unterstützen. Die Verlinkung ändert jedoch weder den Primärblock noch die Eigentümerschaft des verlinkenden oder verlinkten Objekts.

### R-045 Definierte Zuständigkeit jeder Kategorie

Für jede verbindliche Kategorie werden mindestens Primärblock, Hauptaufgabe, Suchintention, inhaltlicher Umfang, Ausschlüsse, Abgrenzung zu ähnlichen Kategorien und zulässige Kindobjekte dokumentiert. Ohne diese Zuständigkeitsdefinition bleibt die Kategorie blockiert.

### R-046 Gleiche sichtbare Begriffe nur mit eindeutiger interner Blockkennung

Ein sichtbarer Begriff darf in mehreren Blöcken verwendet werden, wenn die Suchintentionen verschieden sind. Intern müssen Block, Objektart, Konzept-ID und Eigentümerrolle eindeutig unterscheidbar sein. Identische Namen dürfen keine unklare oder konkurrierende Hauptaufgabe verdecken.

### R-047 Magazinrubriken kopieren nicht pauschal den Contentbaum

Magazin- und Journalrubriken werden nach redaktioneller Nutzerlogik und dauerhaftem Themenpotenzial gebildet. Eine automatische Spiegelung der Contentkategorien ist unzulässig, weil dadurch zwei konkurrierende Navigations- und Themenstrukturen entstehen können.

### R-048 Blockbezogene Mindestsubstanz

Die Mindestsubstanz wird je Block getrennt geprüft: Content benötigt tragfähige Unterthemen oder Zielseiten, HivePress realistisches Anbieter- oder Anzeigenpotenzial, Magazin/Journal mehrere eigenständige redaktionelle Inhalte. Ein bloßes gemeinsames Schlagwort genügt nicht.

### R-049 Unterschiedliche Hierarchietiefen sind zulässig

Die Inhaltsblöcke müssen nicht dieselbe Anzahl an Ebenen besitzen. Die Tiefe richtet sich je Block nach Nutzerlogik, Umfang, Auffindbarkeit und technischer Zweckmäßigkeit. Künstliche Symmetrie zwischen Content, HivePress und Magazin/Journal ist unzulässig.

### R-050 Genau ein Primärblock je Objekt

Jedes Objekt besitzt technisch und fachlich genau einen Primärblock. Unterstützende Elemente anderer Blöcke, etwa Anzeigen auf Contentseiten oder redaktionelle Verweise in HivePress, ändern diese Zuordnung nicht.


### R-051 Ein-Klick-Import als verbindliches Bedienziel

Das spätere Plugin muss eine vollständig freigegebene Struktur mit einem zentralen Importvorgang an den korrekten technischen Zielstellen anlegen können. Der Bedienkomfort „ein Klick“ bedeutet jedoch nicht „ungeprüft schreiben“: Vorschau, Validierung, Sicherung und Freigabe sind zwingende Bestandteile desselben kontrollierten Workflows.

### R-052 Einheitliches maschinenlesbares Importmodell

Jedes zu importierende Objekt benötigt mindestens eine stabile Konzept-ID, Primärblock, Objektart, sichtbaren Namen, Slug, Ebenennummer, Eltern-Konzept-ID, Eigentümercluster, Suchintention, Verbindlichkeitsstatus, Konzeptversion und Zieladapter. Namen oder Slugs allein dürfen nicht als Identität verwendet werden.

### R-053 Getrennte Importadapter je Inhaltsblock

Der zentrale Importer steuert getrennte technische Adapter für Content, HivePress und Magazin/Journal. Jeder Adapter darf nur die für seinen Block freigegebenen WordPress-Objekte, Taxonomien und Metadaten verändern. Eine pauschale Gleichbehandlung aller Blöcke ist unzulässig.

### R-054 Hierarchische Zielzuordnung vor Schreibzugriff

Vor dem Import muss für jedes Objekt eindeutig feststehen:

- technischer Zieltyp;
- fachliche Ebene;
- direkte Eltern-Konzept-ID;
- technisches Elternobjekt;
- Primärblock;
- Sichtbarkeit in Navigation oder Hub;
- Veröffentlichungsstatus.

Fehlt eine dieser entscheidenden Zuordnungen, wird das Objekt nicht importiert.

### R-055 Vollständige Importvorschau

Vor jedem Schreibzugriff zeigt das Plugin mindestens Neuanlagen, Aktualisierungen, unveränderte Objekte, Konflikte, fehlende Eltern, Ebenenfehler, Slugkollisionen, blockierte Objekte und Auswirkungen auf Navigation oder Hubs. Der Nutzer gibt ausschließlich diesen konkreten Importplan frei.

### R-056 Harte Importvalidierung

Der Import wird vollständig blockiert, wenn mindestens einer der folgenden Fälle vorliegt:

- doppelte Konzept-ID;
- fehlende oder unbekannte Eltern-Konzept-ID;
- zyklische Eltern-Kind-Beziehung;
- Selbstzuordnung als Elternobjekt;
- unzulässiger Ebenensprung;
- Überschreitung der blockbezogen erlaubten Tiefe;
- fehlender Primärblock oder Zieladapter;
- ungeklärte Keyword-Eigentümerschaft;
- ungeklärte Slug- oder Bestandskollision;
- Verbindlichkeitsstatus nicht `APPROVED`;
- erforderliche Sicherung nicht erfolgreich erstellt.

Das Plugin darf in diesen Fällen weder ergänzen noch raten.

### R-057 Idempotenz und Wiederholbarkeit

Derselbe freigegebene Import muss beliebig oft ausgeführt werden können, ohne Dubletten, zusätzliche Menüeinträge oder veränderte Elternbeziehungen zu erzeugen. Importierte Objekte werden primär über stabile Konzept-IDs und gespeicherte Zuordnungsmetadaten erkannt.

### R-058 Bestandsabgleich vor Neuanlage

Vor einer Neuanlage prüft das Plugin bestehende WordPress- und HivePress-Objekte anhand stabiler Zuordnungen sowie ergänzend anhand von Slug, Name, Elternbeziehung und Objektart. Ein unsicherer Treffer wird als Konflikt angezeigt und nicht automatisch übernommen oder dupliziert.

### R-059 Keine automatische Löschung

Objekte, die in einer späteren Konzeptversion fehlen, werden niemals automatisch gelöscht. Sie werden als nicht mehr im aktuellen Konzept enthalten markiert. Löschen, Zusammenführen, Umleiten oder Archivieren benötigt einen eigenen sichtbaren Änderungsplan und eine separate Freigabe.

### R-060 Sicherung, Protokoll und Rollback

Vor jedem schreibenden Import wird der relevante Ausgangszustand gesichert. Jeder Importlauf erhält eine eindeutige Lauf-ID, Konzeptversion, Zeitstempel, Objektliste, Vorher-/Nachher-Zuordnung und Ergebnisstatus. Mindestens der zuletzt vollständig ausgeführte Import muss kontrolliert zurückgesetzt werden können.

### R-061 Kategoriehierarchie und sichtbare Navigation bleiben getrennt

Der Import der fachlichen Struktur erfolgt unabhängig von der sichtbaren Navigation. Erst nach erfolgreicher Anlage der Kategorien und Zielobjekte wird anhand eigener Navigationsregeln entschieden, welche Ebenen im Menü, auf Hubseiten, im Footer oder ausschließlich über interne Links erscheinen.

### R-062 Unverbindliche Vorschläge werden nicht automatisch importiert

Beitragsarten-, Themen- und Longtail-Vorschläge mit unverbindlichem Status dürfen weder als Beitrag, Kategorie noch Keyword-Eigentümer angelegt werden. Ein Import ist erst nach dem bereits festgelegten ausdrücklichen Statuswechsel in einen verbindlichen Planungsgegenstand zulässig.

### R-063 Testinstanz vor Produktivfreigabe

Alle schreibenden Importfunktionen werden zunächst ausschließlich auf einer WordPress-Testinstanz geprüft. Eine Produktivfreigabe ist erst zulässig, wenn Positivtests, Negativtests, Wiederholungsimport, Bestandsabgleich, Rollback und Ergebnisverifikation nachweislich bestanden sind.

### R-064 Testdaten müssen allgemeingültige Grenzfälle enthalten

Die Testinstanz darf nicht nur mit dem Pferde-Atelier-Bestand geprüft werden. Der Testsatz muss zusätzlich themenneutrale künstliche Fälle enthalten, darunter unterschiedliche Hierarchietiefen, gleiche sichtbare Namen in verschiedenen Blöcken, fehlende Eltern, Slugkollisionen, Synonyme, Ein-Kind-Hubs, leere Kategorien und bereits vorhandene Zielobjekte.

### R-065 Schreibmodus bleibt bis zur Freigabe deaktiviert

Die erste technische Pluginstufe arbeitet ausschließlich als Parser, Validator und Importvorschau. Schreibzugriffe werden erst aktiviert, wenn Datenmodell, Zieladapter und Negativtests vollständig geprüft und ausdrücklich freigegeben wurden.

---


### R-066 Allgemeingültigkeit hat Vorrang vor Beispielen

Jede Regel wird zuerst abstrakt und themenunabhängig formuliert. Beispiele dürfen keine feste Anzahl von Ebenen, keine themenspezifischen Namen, keine Portalbesonderheiten und keine installationsabhängigen WordPress- oder HivePress-Bezeichner zu allgemeinen Standards erheben.

### R-067 Kürzester eindeutiger Kategoriename

Für den sichtbaren Kategorienamen wird immer der kürzeste fachlich korrekte, eindeutige und gebräuchliche Begriff verwendet. Eine längere Bezeichnung ist nur zulässig, wenn der kürzere Begriff mehrdeutig, fachlich ungenau oder außerhalb seines Elternkontexts missverständlich wäre. Erweiterte SEO-Formulierungen gehören in getrennte Felder wie H1, SEO-Titel, Beschreibung oder Metadaten.

### R-068 Eindeutige Eltern-Kind-Zuordnung

Jede verbindliche Kategorie besitzt genau einen primären Elternknoten innerhalb desselben Blocks. Das Kind muss fachlich vollständig unter den Elternbegriff passen. Mehrere gleichwertige Eltern, bloße Ähnlichkeit, Keywordnähe oder technisch bequeme Zuordnung genügen nicht.

### R-069 Einheitliches Ordnungskriterium je Geschwistergruppe

Geschwisterkategorien unter demselben Elternknoten werden grundsätzlich nach demselben fachlichen Hauptkriterium gebildet. Eine Mischung etwa aus Produkttyp, Zielgruppe, Problem, Material und Einsatzgebiet ist nur als dokumentierter Sonderfall zulässig, wenn keine verständlichere einheitliche Struktur möglich ist und keine Überschneidung entsteht.

### R-070 Kategorien nur bei eigenständigem Themenkern

Eine neue Kategorie ist nur zulässig, wenn sie einen eigenständigen Themenkern, eine klare Suchintention, eine eindeutige Abgrenzung, eine logische Hierarchieposition und ausreichendes blockbezogenes Entwicklungspotenzial besitzt. Ein einzelnes Keyword oder eine SEO-Variante begründet keine Kategorie.

### R-071 Keine Ein-Inhalt-Kategorie

Eine Kategorie wird grundsätzlich nicht für nur einen Beitrag, eine Anzeige oder ein Einzelobjekt angelegt. Abweichungen sind ausschließlich bei rechtlicher, zwingender technischer oder ausdrücklich freigegebener strategischer Notwendigkeit zulässig und müssen begründet gekennzeichnet werden.

### R-072 Keine leeren oder künstlichen Zwischenebenen

Eine Zwischenebene muss eine echte Bündelungs-, Navigations-, Hub-, Such- oder Filterfunktion besitzen. Sie darf nicht nur angelegt werden, um eine gewünschte Tiefe oder optische Gleichmäßigkeit zu erzeugen.

### R-073 Lückenlose Ebenenfolge

Die Ebene eines Kindes entspricht immer der berechneten Ebene seines Elternknotens plus eins. Ebenen dürfen nicht übersprungen werden. Die tatsächliche Ebene wird aus der Elternkette berechnet und mit der deklarierten Ebene verglichen. Abweichungen führen zu `BLOCKED`.

### R-074 Blockbezogene Hierarchielogik

Content, HivePress, Magazin/Journal und Glossar besitzen eigene, funktionsgerechte Hierarchielogiken. Eine Struktur darf nicht nur deshalb in einen anderen Block kopiert werden, weil dort ähnliche Begriffe vorkommen.

### R-075 Contenttiefe nach fachlichem Bedarf

Der Contentblock darf die größte fachliche Tiefe besitzen. Eine zusätzliche Ebene ist nur zulässig, wenn mehrere eigenständige Kinder bestehen, der Elternraum sonst zu breit wäre und die Teilung für Nutzer verständlich sowie SEO-fachlich trennscharf ist.

### R-076 Unterste Contentebene zwingend beitragstragende Kategorie

Auf WordPress-Basis ist die unterste verbindliche Contentebene zwingend eine WordPress-Kategorie oder eine geeignete hierarchische Taxonomie. Unter ihr werden die Longtail-Beiträge zugeordnet. Eine normale WordPress-Seite darf diese beitragstragende Endebene nicht ersetzen. Eine zusätzliche Hubseite oder Templateausgabe ist möglich, ersetzt aber niemals die Kategorie.

### R-077 Seiten nur als übergeordnete Darstellungseinheiten

Normale WordPress-Seiten können als Start-, Hub-, Einstiegs-, Übersichts- oder Darstellungsseiten dienen. Sobald unter einem Strukturpunkt Beiträge systematisch gesammelt werden sollen, muss zusätzlich oder stattdessen ein geeignetes Kategorie- beziehungsweise Taxonomieobjekt vorhanden sein.

### R-078 HivePress möglichst flach und marktorientiert

HivePress wird nur so tief strukturiert, wie Suchende und Inserierende die Ebenen tatsächlich zur Auffindbarkeit und eindeutigen Zuordnung benötigen. Größen, Farben, Zustände, Preise, Orte, Materialien und vergleichbare Merkmale werden grundsätzlich als Attribute oder Filter geprüft, bevor daraus Kategorien entstehen.

### R-079 Magazin redaktionell flach und tragfähig

Magazin- und Journalrubriken bleiben übersichtlich, breit und dauerhaft tragfähig. Einzelne Fragen, Longtails und Beitragsarten wie Ratgeber, Vergleich, FAQ oder Anleitung sind grundsätzlich keine Rubriken, sondern Beitragsmetadaten beziehungsweise konkrete Beiträge.

### R-080 Glossar grundsätzlich flach

Glossarbegriffe sind einzelne Definitionsobjekte. Eine tiefe Glossarhierarchie ist nur bei zwingendem fachlichem Bedarf zulässig. Ein Glossarbegriff darf nicht automatisch als Kategorie oder umfassender Ratgeber interpretiert werden.

### R-081 Themenunabhängige Konzept-ID

Die dauerhafte Identität jedes verbindlichen Objekts wird durch eine systemweit eindeutige, themen-, sprach-, namens-, slug-, struktur- und installationsunabhängige Konzept-ID bestimmt. Sprechende IDs mit Portal-, Kategorie- oder Ebenennamen sind unzulässig.

### R-082 Trennung interner und externer IDs

WordPress-Term-IDs, Seiten-IDs, HivePress-IDs, Menü-IDs und andere Zielsystemkennungen entstehen erst durch das Environment-Mapping oder den Import. Sie sind installationsabhängig und dürfen niemals die führende Identität des Konzeptobjekts darstellen.

### R-083 Elternbeziehungen nur über Konzept-IDs

`parent_concept_id` verweist ausschließlich auf die stabile Konzept-ID des Elternobjekts. Namen, Slugs, Listenpositionen und externe Ziel-IDs dürfen nicht als primäre Elternreferenz verwendet werden.

### R-084 IDs bleiben bei Umbenennung und Verschiebung erhalten

Eine Umbenennung, Slugänderung, Sortieränderung oder geprüfte Verschiebung erzeugt keine neue Konzept-ID. Bei fachlicher Aufspaltung entstehen neue IDs. Bei Zusammenführung bleiben alte IDs historisch als `REPLACED` oder `DEPRECATED` erhalten und werden niemals wiederverwendet.

### R-085 Vorschlags-ID getrennt von Konzept-ID

Unverbindliche Kategorie- oder Beitragsvorschläge erhalten ausschließlich eigene Vorschlags-IDs. Eine verbindliche Konzept-ID entsteht erst nach ausdrücklicher Freigabe eines neuen Kategorieobjekts. Beitragsvorschläge bleiben bis zur Übergabe und Freigabe im Textsystem unverbindlich.

### R-086 Keine ID-Wiederverwendung

Eine einmal vergebene Konzept-ID darf auch nach Löschung, Ersetzung, Zusammenführung oder Veraltung keinem anderen Objekt zugewiesen werden. Die historische Nachvollziehbarkeit bleibt dauerhaft erhalten.

### R-087 Kategoriesystem als Konzeptquelle der Wahrheit

Die verbindliche Struktur wird im Kategoriesystem geführt. WordPress und HivePress sind Zielsysteme. Direkte Änderungen im Zielsystem dürfen die Konzeptstruktur nicht automatisch überschreiben, sondern erzeugen einen erkennbaren Synchronisationszustand oder Konflikt.

### R-088 Drei-Wege-Synchronisationsprüfung

Bei Änderungen werden der verbindliche Konzeptstand, der zuletzt importierte Stand und der aktuelle Zielsystemstand verglichen. Wurde dasselbe Feld auf beiden Seiten unterschiedlich geändert, lautet das Ergebnis `CONFLICT`; ein blindes Überschreiben ist verboten.

### R-089 Feldweise Änderungsklassifikation

Beschreibungen, SEO-Felder und Sortierung können als weniger kritisch klassifiziert werden. Primärblock, Objektart, Elternknoten, Ebene, Hauptkeyword, Suchintention und veröffentlichte Slugs gelten als kritisch und benötigen eine gesonderte Vorschau und Freigabe.

### R-090 Fehlend ist nicht gleich leer

Das Importmodell unterscheidet technisch zwischen nicht geliefertem Feld, ausdrücklich zu leerendem Feld und unverändert zu lassendem Feld. Teilimporte dürfen bestehende Werte nicht unbeabsichtigt löschen.

### R-091 Versions- und Paketidentität

Jedes Importpaket enthält mindestens `schema_version`, `package_version`, `package_id` und `created_at`. Diese Werte beschreiben Datenformat und Strukturstand, nicht die Identität einzelner Kategorien.

### R-092 Vorschläge nur bei echter Strukturlücke

Eine neue Kategorie darf nur vorgeschlagen werden, wenn kein bestehender Kategorienraum ausreicht und Eigenständigkeit, Potenzial, Abgrenzung und Position plausibel sind. Synonyme führen nicht zu einem neuen Kategorienvorschlag, sondern zu einer Zuordnung zum bestehenden Objekt.

### R-093 Automatische Zuordnung bleibt Empfehlung

Das System darf Block, Elternknoten, Ebene, Kurzname, Keywordrichtung und Suchintention empfehlen. Eine automatische Empfehlung wird niemals allein durch einen Vertrauenswert verbindlich. Bei mehreren gleichwertigen Möglichkeiten gilt `UNRESOLVED` oder `BLOCKED`.

### R-094 Vorschläge müssen begründet und begrenzt sein

Jeder Vorschlag enthält Nutzen, Abgrenzung, empfohlene Zuordnung, Unsicherheiten und erkennbare Alternativen. Die Anzahl wird konfigurierbar begrenzt; bloße Titelvarianten und massenhafte Vorschlagsproduktion sind unzulässig.

### R-095 Beitragsvorschläge nur unter freigegebenen Endkategorien

Beitragsarten und Beitragsthemen werden ausschließlich unter einer freigegebenen untersten Kategorie vorgeschlagen. Beitragsart und konkretes Thema werden getrennt gespeichert. Vorschläge dürfen durch das Textsystem übernommen, verändert, zusammengeführt, abgelehnt oder ersetzt werden.

### R-096 Fachstruktur und Navigation getrennt

Die importierte Kategoriehierarchie bestimmt die fachliche Position. Die Navigation bestimmt Sichtbarkeit, Menüplatz und Darstellungsform. Eine nicht im Hauptmenü sichtbare Kategorie bleibt fachlich aktiv und muss über Hubseiten oder normale HTML-Links erreichbar sein.

### R-097 Designseitige Umsetzung der Erreichbarkeitsgarantie

R-016 ist die kanonische fachliche Erreichbarkeitsregel. Das Designsystem muss für alle nicht im sichtbaren Menü ausgegebenen aktiven Kinder eine vollständige Erreichbarkeit über normale HTML-Links bereitstellen. Ob dies als Hubseite, Liste, Kachelstruktur oder andere geeignete Darstellung erfolgt, entscheidet ausschließlich das Designsystem.

### R-098 Eigene Navigation je Block

Content, HivePress und Magazin/Journal erhalten getrennte Navigations- und Sichtbarkeitslogiken. HivePress- und Magazinstrukturen werden nicht automatisch als Content-Hauptnavigation ausgegeben.

### R-099 Strukturelle Relationen statt Textlinks

Das Kategoriesystem speichert nur fachliche Beziehungen zwischen Content, HivePress, Magazin und Glossar. Es erzeugt keine kontextbezogenen Fließtextlinks oder Ankertexte. Diese entstehen im Textsystem; strukturierte Hubausgaben entstehen im Template- oder Designsystem.

### R-100 Pflichtdaten einer verbindlichen Kategorie

Eine verbindliche Kategorie benötigt mindestens Konzept-ID, Block, Objektart, kurzen Namen, Slug, Eltern-Konzept-ID, berechnete und deklarierte Ebene, Sortierung, Hauptkeyword, primäre Suchintention, positive Zuständigkeitsdefinition, Ausschlussdefinition und Status. Ohne diese Daten ist sie nicht importierbar.

### R-101 Kein vollständiger Import bei BLOCKED

Fachliche und technische Prüfung werden getrennt durchgeführt. Ein Gesamtlauf mit mindestens einem `BLOCKED`-Datensatz darf nicht schreibend ausgeführt werden. Ein Teillauf ist nur als ausdrücklich ausgewählter, vollständiger und abhängigkeitssicherer Teilbaum zulässig.

### R-102 Eltern zuerst, Reihenfolge wird berechnet

Importreihenfolgen werden aus der Elternkette berechnet und nicht aus der Dateireihenfolge übernommen. Ein Kind wird nur verarbeitet, wenn sein Elternobjekt bereits existiert oder im selben Lauf vorher eindeutig angelegt wird.

### R-103 Rein lesende erste Pluginstufe

Die erste technische Stufe liest Importpaket und WordPress-/HivePress-Bestand, validiert Schema, IDs, Hierarchie und Mapping und erzeugt eine vollständige Vorschau beziehungsweise einen Prüfbericht. Sie darf noch keine Kategorien, Seiten, Menüs oder Taxonomien anlegen oder verändern.

### R-104 Testpaket bleibt allgemeingültig

Das erste Testpaket enthält einen kleinen, künstlichen, themenneutral interpretierbaren Positiv- und Negativbestand. Konkrete Beispielbegriffe dienen nur der Lesbarkeit. Schema, Prüfregeln, IDs, Zielrollen und erwartete Ergebnisse dürfen keinerlei Bindung an das Pferdethema enthalten.

### R-105 Testinstanz als kontrollierte Ausführungsumgebung

Die WordPress-Testinstanz dient der Environment-Inventur, Trockenläufen, Positivtests, Negativtests, Wiederholungsprüfungen und späteren Rollbacktests. Technische Zielnamen und HivePress-Taxonomien werden aus dieser Instanz ausgelesen und niemals geraten.

### R-106 Mehrsprachige Eigentümerschaft

Keyword- und Suchintentionseigentümerschaft wird je Sprach- und Zielmarktvariante geführt. Sprachlich unterschiedliche Seiten dürfen nur dann parallele Eigentümer desselben fachlichen Konzepts sein, wenn sie ausdrücklich als lokalisierte Varianten miteinander verknüpft sind. Übersetzungen erhalten keine unabhängige fachliche Eigentümerschaft allein aufgrund anderer Schreibweise. Regionale oder rechtliche Abweichungen dürfen getrennte Eigentümer begründen, müssen aber als eigenständige Zielmarktintention dokumentiert werden.

### R-107 Sperre paralleler Importläufe

Pro Zielinstallation und betroffenem Strukturraum darf höchstens ein schreibender Import-, Rollback- oder Wiederherstellungslauf gleichzeitig aktiv sein. Weitere schreibende Läufe werden bis zum eindeutigen Abschluss oder kontrollierten Abbruch des laufenden Vorgangs blockiert. Lesende Inventur- und Vorschauprozesse dürfen nur dann parallel laufen, wenn sie den gesicherten Vergleichsstand eindeutig referenzieren und keine widersprüchliche Freigabe erzeugen.

### R-108 Glossarinhalte bleiben Folgesystemaufgabe

Das Kategoriesystem definiert ausschließlich Glossarstruktur, Begriffseigentümerschaft, Abgrenzung und Relationen. Die Erstellung, Prüfung, Aktualisierung und Veröffentlichung einzelner Glossardefinitionen gehört zum dafür freigegebenen Text- oder Contentproduktionssystem. Solange kein solches System ausdrücklich zugeordnet ist, werden Glossarbegriffe nur als unverbindliche Vorschläge behandelt und nicht automatisch veröffentlicht.

### R-109 Bewusst begrenzte Rollback-Reichweite

Verbindlich garantiert wird mindestens die vollständige Rücksetzung des zuletzt erfolgreich abgeschlossenen schreibenden Importlaufs. Eine weitergehende Historie mehrerer Importstände ist eine optionale Ausbauleistung. Diese Grenze muss vor jedem schreibenden Import sichtbar dokumentiert werden und darf nicht den Eindruck einer unbegrenzten Versionswiederherstellung erwecken.

## 6. REGELBLOCK 1: Blockzuordnung und Keyword-Eigentümerschaft

### 6.1 Ziel und Geltungsbereich

Dieser Regelblock entscheidet für jeden bereits recherchierten und normalisierten Suchcluster:

1. welche konkrete Suchaufgabe der Cluster erfüllt;
2. welcher Portalblock diese Suchaufgabe primär bedienen darf;
3. welches einzelne indexierbare Objekt Eigentümer des Clusters wird;
4. welche anderen Objekte das Thema nur unterstützend behandeln dürfen;
5. wann eine Zuordnung wegen fehlender Belege oder eines Konflikts blockiert wird.

Der Regelblock erzeugt noch keine Hierarchie, keine neuen Keywords und keine WordPress-Objekte. Er verarbeitet ausschließlich belegte Cluster aus einer vorgelagerten Recherche.

### 6.2 Verbindliche Begriffe

**Suchcluster:** Gruppe semantisch und nach Suchaufgabe zusammengehöriger Suchanfragen.

**Suchaufgabe:** Das konkrete Ergebnis, das ein Nutzer mit der Suche erreichen will.

**Primärer Block:** Genau einer der Werte `CONTENT`, `HIVEPRESS`, `MAGAZIN` oder `GLOSSAR`.

**Keyword-Eigentümer:** Genau ein indexierbares Zielobjekt, das die primäre Suchaufgabe vollständig abdecken darf.

**Unterstützendes Objekt:** Ein anderes Objekt, das Teilaspekte erwähnt, Kontext liefert oder zum Eigentümer verlinkt, aber nicht dieselbe Suchaufgabe vollständig beantwortet.

**Konflikt:** Zwei oder mehr geplante oder bestehende Objekte beanspruchen dieselbe primäre Suchaufgabe.

**BLOCKED:** Es fehlen entscheidende Belege, die Suchaufgabe ist mehrdeutig oder ein Eigentümerkonflikt ist ungelöst. In diesem Status darf keine automatische Strukturentscheidung erfolgen.

### 6.3 Pflichtdaten vor jeder Entscheidung

Eine automatische oder halbautomatische Blockzuordnung ist nur zulässig, wenn mindestens folgende Daten vorliegen:

- normalisierter Hauptbegriff;
- belegte Suchanfragen und Varianten;
- dokumentierte Suchaufgabe;
- Entitätsrolle;
- gewünschtes Ergebnis des Nutzers;
- ausreichende Recherchebelege;
- bekannte bestehende Zielseiten und Taxonomien;
- mögliche konkurrierende Cluster;
- Aktualitätsdatum der Belege;
- geplante inhaltliche Abdeckung.

Fehlt eines der entscheidungsrelevanten Felder, lautet der Status `BLOCKED_MISSING_EVIDENCE`.

### 6.4 Verbindliche Reihenfolge der Zuordnungsentscheidung

Die Entscheidung erfolgt immer in dieser Reihenfolge:

1. Suchaufgabe bestimmen.
2. Entitätsrolle bestimmen.
3. bestehende Eigentümer prüfen.
4. Glossar-Eignung prüfen.
5. HivePress-Eignung prüfen.
6. Magazin-Eignung prüfen.
7. Content-Eignung prüfen.
8. Mischintention und Konflikte prüfen.
9. genau einen primären Block festlegen oder blockieren.
10. genau einen Keyword-Eigentümer festlegen oder blockieren.

Die Reihenfolge ist kein pauschaler Vorrang der Blöcke. Sie verhindert lediglich, dass eine enge Definitions-, Anbieter- oder redaktionelle Suchaufgabe vorschnell als allgemeine Contentseite eingeordnet wird.

### 6.5 Entscheidungsregeln für `GLOSSAR`

Ein Cluster wird dem Glossar zugewiesen, wenn alle folgenden Bedingungen erfüllt sind:

- die primäre Suchaufgabe ist die knappe Erklärung eines Begriffs, Kürzels, Fachworts oder eindeutig abgrenzbaren Konzepts;
- der Nutzer benötigt keine umfassende Problemlösung, Kaufentscheidung, Auswahlhilfe, Anleitung, Anbieterübersicht oder aktuelle redaktionelle Einordnung;
- die sachgerechte Kernantwort ist kurz und definitorisch möglich;
- ein ausführlicher Eigentümercluster wird nicht vollständig dupliziert;
- der Begriff besitzt genügend eigenständige Relevanz für einen indexierbaren Eintrag.

Ein Glossareintrag darf enthalten:

- Definition;
- gebräuchliche Synonyme;
- knappe Abgrenzung zu ähnlichen Begriffen;
- einen kurzen Anwendungskontext;
- Links auf zuständige Vertiefungsseiten.

Ein Cluster ist **nicht** Glossar, wenn die Suchaufgabe mindestens eines der folgenden Ergebnisse verlangt:

- umfassende Erklärung eines Themenfelds;
- konkrete Handlungsanleitung;
- Beratung oder Entscheidungshilfe;
- Vergleich;
- Fehlerdiagnose oder Problemlösung;
- Kosten-, Rechts-, Sicherheits- oder Gesundheitsbewertung;
- Suche nach Anbietern oder Angeboten;
- aktuelle, gesellschaftliche oder erzählerische Einordnung.

Bestehen sowohl Definitions- als auch Vertiefungsbedarf, werden zwei getrennte Cluster nur dann zugelassen, wenn die Suchaufgaben belegbar verschieden sind. Der Glossareintrag erklärt den Begriff knapp; die Contentseite besitzt die Vertiefungsintention. Ohne diese Trennbarkeit wird nur der umfassendere Eigentümer freigegeben und die Definition dort integriert.

### 6.6 Entscheidungsregeln für `HIVEPRESS`

Ein Cluster wird HivePress zugewiesen, wenn die primäre Suchaufgabe darin besteht, konkrete Marktteilnehmer oder konkrete Angebote zu finden, auszuwählen, zu kontaktieren, anzufragen, zu buchen, zu kaufen, zu verkaufen, zu mieten oder anzubieten.

Zulässige primäre Entitätsrollen sind insbesondere:

- Dienstleister;
- Händler;
- Hersteller;
- Shop;
- Betrieb;
- Einrichtung;
- Vermieter;
- Verkäufer;
- Käufergesuch;
- konkrete Leistung;
- konkretes Inserat oder Angebot.

Für eine HivePress-Kategorie müssen alle folgenden Bedingungen erfüllt sein:

- mehrere potenzielle Anzeigen oder Anbieter sind fachlich plausibel und recherchierbar;
- der Kategoriebegriff beschreibt den angebotenen oder gesuchten Typ und nicht nur ein Merkmal;
- Nutzer erwarten eine Ergebnisliste, Auswahl oder Kontaktmöglichkeit;
- reine Informationsinhalte reichen zur Erfüllung der Suchaufgabe nicht aus;
- der Begriff ist nicht bloß Standort, Preis, Material, Größe, Zielgruppe oder sonstiges Filtermerkmal.

Folgende Fälle werden grundsätzlich als Attribute oder Filter und nicht als eigene HivePress-Kategorie behandelt:

- Ort und Entfernung;
- Preisbereich;
- Verfügbarkeit;
- Größe oder Kapazität;
- Material;
- Zielgruppe;
- Bewertungswert;
- Lieferart;
- einzelne Ausstattungsmerkmale.

Eine Ausnahme ist nur zulässig, wenn für die Merkmalskombination eine eigenständige, navigationswürdige Anbieterintention belegt ist und sie nicht sinnvoll allein über Filter abgebildet werden kann.

Informationscluster über die Auswahl, Bewertung, Kosten oder Nutzung eines Anbietertyps gehören grundsätzlich zu Content. Die zugehörige Anbieter- oder Angebotsliste gehört zu HivePress. Beide dürfen koexistieren, wenn ihre Suchaufgaben klar getrennt sind und gegenseitig verlinkt werden.

### 6.7 Entscheidungsregeln für `MAGAZIN`

Ein Cluster wird dem Magazin zugewiesen, wenn seine primäre Suchaufgabe redaktionell, aktuell, gesellschaftlich, kulturell, persönlich, meinungsbezogen, wissenschaftlich einordnend oder erzählerisch ist und nicht primär eine dauerhafte Handlungs-, Kauf-, Anbieter- oder Definitionsaufgabe erfüllt.

Geeignete Magazinrollen sind insbesondere:

- Nachricht oder aktuelle Entwicklung;
- Reportage;
- Interview;
- Porträt;
- persönliche Erfahrung;
- Debatte oder Perspektivenvergleich;
- gesellschaftliche oder kulturelle Einordnung;
- Trendbeobachtung;
- Forschungseinordnung mit erkennbarem Neuigkeits- oder Diskussionsbezug;
- Community- oder Szenethema.

Ein Cluster ist **nicht** Magazin, wenn die primäre Suchaufgabe dauerhaft und systematisch durch eine Ratgeber-, Vergleichs-, Auswahl-, Problemlösungs-, Anbieter- oder Definitionsseite erfüllt werden kann.

Zeitbezug allein macht ein Thema nicht zum Magazin. Eine jährlich aktualisierte Preis-, Rechts- oder Produktinformation bleibt Content, wenn die Nutzeraufgabe dauerhaft dieselbe ist. Umgekehrt darf ein aktuelles Ereignis mit eigenständigem Nachrichten- oder Einordnungswert im Magazin erscheinen, auch wenn es auf eine dauerhafte Contentseite verweist.

Das Magazin darf niemals als Ausweichblock für unklare, schwache oder im Contentbaum schwer einzuordnende Cluster verwendet werden.

### 6.8 Entscheidungsregeln für `CONTENT`

Ein Cluster wird Content zugewiesen, wenn die primäre Suchaufgabe dauerhaft mindestens eines der folgenden Ergebnisse verlangt:

- ein Thema umfassend verstehen;
- ein Problem lösen;
- eine Entscheidung treffen;
- ein Produkt, Verfahren oder eine Lösung auswählen;
- Möglichkeiten vergleichen;
- eine Tätigkeit durchführen;
- Fehler vermeiden;
- Pflege, Wartung oder Anwendung verstehen;
- Kosten, Voraussetzungen, Risiken oder Regeln verstehen;
- Eignung oder Nutzen bewerten;
- eine strukturierte Wissens- oder Kaufvorbereitung durchführen.

Content ist der Standardblock für dauerhafte Informations- und Entscheidungsaufgaben, aber kein Auffangblock. Die Zuordnung ist nur zulässig, wenn die Suchaufgabe hinreichend klar, substanziell und gegenüber Glossar, HivePress und Magazin abgegrenzt ist.

Ein Contentcluster darf Anbieterarten, Angebote oder aktuelle Ereignisse erwähnen, aber nicht deren primäre Ergebnisliste oder redaktionelle Hauptaufgabe übernehmen.

### 6.9 Mischintentionen

Ein Suchbegriff kann mehrere Suchaufgaben enthalten. Eine Mischintention wird nicht anhand des Wortes, sondern anhand belegter Nutzererwartungen und Ergebnisarten getrennt.

Zulässige Aufspaltung in mehrere Eigentümercluster besteht nur, wenn:

- die Suchaufgaben klar unterschiedlich sind;
- jede Suchaufgabe eine eigenständige Zielseite rechtfertigt;
- Titel, H1, Abdeckung und interne Links trennscharf geplant werden können;
- keine Seite die Aufgabe der anderen vollständig miterfüllt;
- die Trennung durch Recherche oder Bestandsdaten belegt ist.

Beispielmuster ohne Themenbindung:

- „Was ist X?“ → Glossar, sofern reine Definition;
- „X richtig auswählen“ → Content;
- „X-Anbieter finden“ → HivePress;
- „Neue Entwicklung bei X“ → Magazin.

Kann die Suchintention nicht belastbar getrennt werden, wird nicht mehrfach zugewiesen. Der Fall erhält `BLOCKED_AMBIGUOUS_INTENT`.

### 6.10 Regeln der Keyword-Eigentümerschaft

Für jeden freigegebenen Suchcluster gilt:

1. Es existiert genau eine `owner_object_id`.
2. Der Eigentümer besitzt genau einen primären Block.
3. Der Eigentümer deckt die dokumentierte Hauptsuchaufgabe vollständig ab.
4. Andere Objekte erhalten eine ausdrücklich begrenzte Unterstützerrolle.
5. Synonyme, Schreibvarianten, Singular/Plural und eng gleichbedeutende Formulierungen gehören grundsätzlich demselben Eigentümer.
6. Ein Eigentümerwechsel ist nur nach vollständiger Konfliktprüfung, Weiterleitungsplanung und Freigabe zulässig.
7. Bestehende indexierbare Seiten werden vor Neuanlage als mögliche Eigentümer geprüft.
8. Ein Taxonomiearchiv, eine Hubseite und ein Einzelbeitrag dürfen nicht gleichzeitig dieselbe Suchaufgabe beanspruchen.
9. Die Eigentümerschaft wird auf Clusterebene und nicht nur auf Einzelkeywordebene geführt.
10. Jede Eigentümerentscheidung benötigt eine maschinenlesbare Begründung und Belege.

### 6.11 Unterstützerrollen

Ein Nicht-Eigentümer darf das Cluster nur verwenden, wenn mindestens eine dieser Rollen dokumentiert ist:

- `CONTEXT_LINK`: kurzer Kontext mit Link zum Eigentümer;
- `DEFINITION_SNIPPET`: knappe Definition mit Link zur Vertiefung;
- `MARKET_LINK`: Content verweist auf passende HivePress-Ergebnisse;
- `GUIDE_LINK`: HivePress verweist auf erklärenden Content;
- `EDITORIAL_LINK`: Magazinbeitrag verweist auf dauerhaften Grundlagencontent;
- `GLOSSARY_LINK`: Vertiefungsseite verweist auf definitorischen Eintrag oder umgekehrt;
- `RELATED_TOPIC`: klar abgegrenztes Nachbarthema.

Nicht zulässig sind Unterstützerrollen, die denselben Umfang, dieselbe H1-Logik und dieselbe Nutzeraufgabe wie der Eigentümer erhalten.

### 6.12 Konfliktmatrix

| Konflikt | Eigentümerentscheidung | Pflichtmaßnahme |
|---|---|---|
| Glossar gegen Content | Glossar nur für Definition, Content für Vertiefung | Abdeckung schriftlich trennen; sonst zusammenführen |
| Content gegen HivePress | Content für Information/Entscheidung, HivePress für Markt-/Anbieterliste | gegenseitige Links; keine Anbieterlisten als Content-Hauptzweck |
| Content gegen Magazin | Content für dauerhafte Suchaufgabe, Magazin für aktuelles/redaktionelles Ereignis | Grundlagen- und Ereignisintention trennen |
| HivePress gegen Magazin | HivePress für Angebots-/Anbietersuche, Magazin für redaktionelle Berichterstattung | Magazin darf kein dauerhaftes Verzeichnis nachbilden |
| zwei Contentobjekte | genau ein Eigentümer | zusammenführen, umgrenzen oder eines nicht indexieren |
| zwei HivePress-Kategorien | genau eine fachliche Kategorie | Synonyme zusammenführen; Merkmale als Filter prüfen |
| zwei Magazinrubriken oder Beiträge | ein primärer Beitragseigentümer je Suchaufgabe | primäre Rubrik festlegen; Mehrfach-Hauptzuordnung verhindern |
| bestehendes gegen geplantes Objekt | Bestand zuerst prüfen | übernehmen, aktualisieren, zusammenführen oder Konflikt blockieren |
| Hubseite gegen Kindseite | Suchumfang und Aufgabe müssen verschieden sein | Hub besitzt Überblick; Kind besitzt konkrete Teilaufgabe |
| Taxonomiearchiv gegen redaktionelle Seite | nur ein indexierbarer Eigentümer derselben Aufgabe | Archiv oder Seite abgrenzen, kanonisieren oder nicht indexieren |

### 6.13 Harte Blockierungsregeln

Eine Zuordnung erhält zwingend `BLOCKED`, wenn mindestens einer der folgenden Fälle vorliegt:

- Suchaufgabe nicht eindeutig bestimmt;
- Recherchebelege fehlen oder widersprechen sich wesentlich;
- zwei Blöcke würden dieselbe Hauptaufgabe vollständig bedienen;
- zwei bestehende oder geplante Objekte beanspruchen denselben Cluster;
- eine Glossarseite würde faktisch einen vollständigen Ratgeber duplizieren;
- eine HivePress-Kategorie ist nur ein Filtermerkmal ohne belegte eigenständige Anbieterintention;
- ein Magazincluster ist lediglich ein Restethema ohne redaktionelle Eigenständigkeit;
- eine Contentseite soll zugleich dauerhaftes Anbieterverzeichnis sein;
- bestehende URLs, Archive oder Weiterleitungen sind nicht geprüft;
- der Eigentümer ist technisch nicht eindeutig identifizierbar;
- die geplante Abgrenzung kann nicht in Titel, H1, Inhalt und interner Verlinkung umgesetzt werden;
- eine Entscheidung wäre nur durch Vermutung möglich.

### 6.14 Zulässige Entscheidungsstatus

- `PROPOSED`: Zuordnung ist erstellt, aber noch nicht vollständig geprüft.
- `EVIDENCE_COMPLETE`: Pflichtbelege liegen vor.
- `OWNER_CHECKED`: Bestands- und Eigentümerprüfung abgeschlossen.
- `CONFLICT_FREE`: keine ungeklärte Konkurrenz gefunden.
- `READY_FOR_REVIEW`: fachlich prüfbare Entscheidung liegt vor.
- `APPROVED`: ausdrücklich freigegeben.
- `BLOCKED_MISSING_EVIDENCE`: entscheidende Daten fehlen.
- `BLOCKED_AMBIGUOUS_INTENT`: Suchaufgabe ist nicht trennscharf.
- `BLOCKED_OWNER_CONFLICT`: mehrere Eigentümer beanspruchen denselben Cluster.
- `BLOCKED_BLOCK_CONFLICT`: mehrere Blöcke beanspruchen dieselbe Hauptaufgabe.
- `BLOCKED_EXISTING_STRUCTURE`: Bestand verhindert eine sichere Neuzuordnung.

Nur `APPROVED` darf in spätere Hierarchie- und Importplanung übernommen werden.

### 6.15 Maschinenlesbare Entscheidungsfelder

Jeder Cluster benötigt für diesen Regelblock mindestens:

- `cluster_id`
- `normalized_topic`
- `query_variants`
- `primary_user_task`
- `secondary_user_tasks`
- `entity_role`
- `evidence_refs`
- `existing_object_refs`
- `candidate_blocks`
- `assigned_primary_block`
- `block_decision_reason`
- `owner_object_id`
- `owner_object_type`
- `owner_scope`
- `supporting_object_ids`
- `supporting_roles`
- `excluded_scopes`
- `conflict_ids`
- `decision_status`
- `review_note`
- `approved_by`
- `approved_at`

### 6.16 Prüfalgorithmus für Regelblock 1

Für jeden Cluster wird verbindlich geprüft:

1. Sind alle Pflichtdaten vorhanden? Falls nein: blockieren.
2. Ist bereits ein passender Eigentümer im Bestand vorhanden? Falls ja: diesen als Kandidaten priorisieren, aber nicht ungeprüft übernehmen.
3. Handelt es sich ausschließlich um eine Definitionsaufgabe? Falls ja: Glossar-Kandidat prüfen.
4. Handelt es sich primär um eine Anbieter-, Angebots- oder Transaktionssuche? Falls ja: HivePress-Kandidat prüfen.
5. Handelt es sich primär um eine redaktionelle, aktuelle oder erzählerische Aufgabe? Falls ja: Magazin-Kandidat prüfen.
6. Handelt es sich primär um dauerhafte Information, Auswahl, Anwendung oder Problemlösung? Falls ja: Content-Kandidat prüfen.
7. Liegen mehrere plausible Kandidaten vor? Suchaufgaben trennen oder blockieren.
8. Gibt es einen bestehenden oder geplanten Eigentümerkonflikt? Zusammenführen, umgrenzen oder blockieren.
9. Sind Unterstützerrollen und ausgeschlossene Abdeckungen definiert? Falls nein: nicht freigeben.
10. Ist genau ein Block und genau ein Eigentümer übrig? Status `READY_FOR_REVIEW`; andernfalls `BLOCKED`.

### 6.17 Positivfälle für spätere Tests

Regelblock 1 muss später mindestens folgende allgemeine Positivmuster korrekt behandeln:

- reine Begriffsdefinition → Glossar;
- dauerhafte Auswahlhilfe → Content;
- konkrete Anbietersuche → HivePress;
- aktuelles Interview oder Ereignis → Magazin;
- Definition plus ausführlicher Ratgeber → zwei trennbare Eigentümer mit klarer Linkbeziehung;
- Ratgeber plus Anbieterübersicht → Content und HivePress mit getrennten Aufgaben;
- aktueller Magazinbeitrag plus dauerhafte Grundlagenseite → Magazin und Content ohne Konkurrenz;
- bestehende geeignete Seite → Übernahme als Eigentümerkandidat statt Neuanlage.

### 6.18 Negativfälle für spätere Tests

Regelblock 1 muss später mindestens folgende Fälle blockieren:

- dasselbe Cluster gleichzeitig als Glossar und Content ohne Umfangstrennung;
- dieselbe Anbieterintention gleichzeitig als Contentseite und HivePress-Kategorie;
- eine HivePress-Kategorie nur für ein Preis-, Orts- oder Materialmerkmal;
- ein Magazinartikel als dauerhafte zweite Ratgeberseite;
- zwei Contentseiten für Synonyme derselben Suchaufgabe;
- ein neues Objekt trotz bereits vorhandenem geeigneten Eigentümer;
- eine Zuordnung ohne dokumentierte Suchaufgabe;
- eine Zuordnung ausschließlich auf Basis eines Modellvorschlags ohne Recherchebeleg;
- eine automatische Entscheidung bei widersprüchlichen Belegen;
- eine Mehrfachzuordnung, weil ein einzelner Begriff mehrere mögliche Bedeutungen besitzt.

### 6.19 Abnahmekriterien für Regelblock 1

Regelblock 1 gilt fachlich als abgeschlossen, wenn:

- jeder Cluster genau einen primären Block oder einen eindeutigen BLOCKED-Status erhält;
- jeder freigegebene Cluster genau einen Eigentümer besitzt;
- alle Nebenrollen ausdrücklich begrenzt sind;
- Mischintentionen entweder belegbar getrennt oder blockiert werden;
- bestehende Objekte vor Neuanlagen geprüft werden;
- Glossar, Content, HivePress und Magazin keine identische Hauptaufgabe teilen;
- Positiv- und Negativfälle aus 6.17 und 6.18 später reproduzierbar geprüft werden können;
- keine Entscheidung auf bloßer Vermutung beruht.

---

## 7. REGELBLOCK 2A: Verbindliches Importdatenmodell und technische Zielabbildung

### 7.1 Ziel und Grenze

Regelblock 2A definiert den vollständigen maschinenlesbaren Importplan für alle verbindlichen Strukturobjekte. Er legt fest, welche Daten vorliegen müssen, wie Identitäten und Elternbeziehungen abgebildet werden und welcher technische Adapter ein Objekt verarbeitet.

Dieser Regelblock legt noch keine konkrete WordPress- oder HivePress-Datenbank-ID fest. Laufzeitabhängige IDs und installationsspezifische Taxonomiebezeichnungen werden ausschließlich durch eine Inventur der jeweiligen Zielinstanz ermittelt. Fehlende technische Zuordnungen führen zu `BLOCKED_ENVIRONMENT_MAPPING`; sie dürfen nicht geraten oder hart codiert werden.

### 7.2 Importpaket

Ein Importpaket besteht mindestens aus:

- genau einer Manifestdatei;
- genau einer Liste verbindlicher Strukturobjekte;
- optional einer getrennten Liste unverbindlicher Vorschläge;
- optional dokumentierten Recherche- und Prüfbelegen;
- einer eindeutigen Prüfsumme für jede Datei.

Das Paket darf keine ausführbare PHP-Datei, keine fremden Binärdateien und keine unkontrollierten WordPress-Schreibanweisungen enthalten. Die erste Pluginstufe liest ausschließlich Daten, validiert sie und erzeugt eine Vorschau.

### 7.3 Manifest-Pflichtfelder

| Feld | Datentyp | Pflicht | Regel |
|---|---|---:|---|
| `schema_name` | String | ja | fester Wert `affiliate-category-import` |
| `schema_version` | String | ja | semantische Version, beispielsweise `1.0.0` |
| `project_id` | String | ja | dauerhaft stabile Projektkennung |
| `concept_version` | String | ja | eindeutige Version des freigegebenen Konzepts |
| `package_id` | UUID | ja | eindeutige Kennung dieses Importpakets |
| `created_at` | ISO-8601 | ja | Erstellungszeitpunkt mit Zeitzone |
| `created_by` | String | ja | Ersteller oder erzeugendes System |
| `environment_target` | Enum | ja | `TEST`, `STAGING` oder `PRODUCTION` |
| `default_language` | BCP-47-String | ja | beispielsweise `de-DE` |
| `object_count` | Integer | ja | Anzahl verbindlicher Objekte |
| `suggestion_count` | Integer | ja | Anzahl unverbindlicher Vorschläge |
| `content_hash` | String | ja | Prüfsumme der fachlichen Nutzdaten |
| `approval_status` | Enum | ja | für Import ausschließlich `APPROVED` |
| `approved_by` | String | ja bei `APPROVED` | dokumentierte Freigabeinstanz |
| `approved_at` | ISO-8601 | ja bei `APPROVED` | Zeitpunkt der Freigabe |

Unbekannte Schema-Hauptversionen werden nicht verarbeitet. Unterschiede in einer kompatiblen Nebenversion dürfen nur verarbeitet werden, wenn sämtliche unbekannten Felder gefahrlos ignoriert werden können.

### 7.4 Stabile Identitäten

Jedes verbindliche Strukturobjekt besitzt eine `concept_id`. Sie ist:

- projektweit eindeutig;
- unabhängig von Name, Slug und WordPress-ID;
- nach dem ersten freigegebenen Import unveränderlich;
- nicht aus einer laufzeitabhängigen Datenbank-ID abgeleitet;
- bei Umbenennung oder Umhängung weiterhin identisch.

Empfohlenes Format:

`<project_id>:<block>:<object_kind>:<opakes_token>`

`project_id`, `block` und `object_kind` dürfen ausschließlich als technische Namensraum-Präfixe verwendet werden. Das identitätsstiftende Token muss opak sein und darf keinen Kategorienamen, kein Keyword, keine Sprache, keine Ebene und keine Elternposition codieren.

Eine neue `concept_id` ist nur zulässig, wenn fachlich ein neues Objekt entsteht. Umbenennung, Slugänderung, Statusänderung oder Elternwechsel erzeugen keine neue Identität.

### 7.5 Pflichtfelder jedes verbindlichen Strukturobjekts

| Feld | Datentyp | Pflicht | Bedeutung |
|---|---|---:|---|
| `concept_id` | String | ja | stabile fachliche Identität |
| `project_id` | String | ja | Bindung an das Projekt |
| `concept_version` | String | ja | Herkunftsversion |
| `primary_block` | Enum | ja | `CONTENT`, `HIVEPRESS`, `MAGAZIN` oder `GLOSSAR` |
| `object_kind` | Enum | ja | fachlicher Objekttyp gemäß 7.8 |
| `target_adapter` | Enum | ja | technischer Adapter gemäß 7.9 |
| `level` | Integer | ja | fachliche Ebene, beginnend bei `1` |
| `parent_concept_id` | String oder `null` | ja | direkte fachliche Eltern-ID |
| `name` | String | ja | sichtbarer kurzer Name |
| `slug` | String | ja | geplanter dauerhafter Slug |
| `page_title` | String | ja, wenn Zielseite | vollständiger Seitentitel |
| `h1` | String | ja, wenn indexierbar | Hauptüberschrift |
| `seo_title` | String | optional | geplanter SEO-Titel |
| `owner_cluster_id` | String | ja | zugewiesener Keyword-/Suchcluster |
| `primary_keyword` | String | ja | Hauptbegriff des Eigentümerclusters |
| `search_intent` | Enum | ja | normalisierte Hauptsuchintention |
| `scope_includes` | Array[String] | ja | verbindlich enthaltene Themen |
| `scope_excludes` | Array[String] | ja | ausdrücklich ausgeschlossene Themen |
| `allowed_child_kinds` | Array[Enum] | ja | zulässige direkte Kindobjekte |
| `binding_status` | Enum | ja | für Strukturimport ausschließlich `APPROVED` |
| `publication_intent` | Enum | ja | `DRAFT`, `PUBLISH` oder `KEEP_EXISTING` |
| `indexing_intent` | Enum | ja | `INDEX`, `NOINDEX` oder `KEEP_EXISTING` |
| `navigation_role` | Enum | ja | nur Planungswert gemäß 7.11 |
| `evidence_refs` | Array[String] | ja | Referenzen auf Belege oder Prüfungen |
| `validation_status` | Enum | ja | für Freigabe `VALIDATED` |
| `record_hash` | String | ja | Prüfsumme des normalisierten Datensatzes |

Leere Arrays sind nur zulässig, wenn die jeweilige fachliche Aussage tatsächlich leer sein darf. Insbesondere darf `scope_excludes` nicht aus Bequemlichkeit fehlen; die Abgrenzung ist Teil der verbindlichen Kategorieverantwortung.

### 7.6 Optionale, aber standardisierte Felder

- `synonyms`
- `entity_roles`
- `description`
- `meta_description`
- `minimum_substance_evidence`
- `related_concept_ids`
- `supporting_link_targets`
- `display_order`
- `menu_label`
- `hub_label`
- `legacy_object_refs`
- `migration_note`
- `review_note`
- `custom_metadata`

`custom_metadata` darf nur namespaced Schlüssel enthalten. Es darf keine Pflichtregel ersetzen und keine ungeprüfte technische Schreibanweisung transportieren.

### 7.7 Verbindliche Statuswerte

**Strukturstatus:**

- `PROPOSED`
- `IN_REVIEW`
- `BLOCKED`
- `APPROVED`
- `RETIRED`

Nur `APPROVED` darf in einen Importplan aufgenommen werden. `RETIRED` bedeutet nicht automatische Löschung.

**Validierungsstatus:**

- `NOT_VALIDATED`
- `VALIDATED`
- `VALIDATION_FAILED`

**Laufzeitstatus der Vorschau:**

- `CREATE`
- `UPDATE`
- `UNCHANGED`
- `ADOPT_CANDIDATE`
- `CONFLICT`
- `BLOCKED`
- `MISSING_ENVIRONMENT_MAPPING`

Der Laufzeitstatus wird vom Plugin ermittelt und ist nicht vom Importpaket als verbindliche Aktion vorzugeben.

### 7.8 Fachliche Objekttypen

Zulässige `object_kind`-Werte:

**Content:**

- `CONTENT_ROOT`
- `CONTENT_HUB`
- `CONTENT_TOPIC`
- `CONTENT_CATEGORY`

**HivePress:**

- `MARKET_ROOT`
- `MARKET_CATEGORY`

**Magazin/Journal:**

- `MAGAZINE_ROOT`
- `MAGAZINE_CATEGORY`

**Glossar:**

- `GLOSSARY_ROOT`
- `GLOSSARY_CATEGORY`

Einzelbeiträge, einzelne Anzeigen und Glossareinträge sind keine verbindlichen Importobjekte dieses Regelblocks. Sie werden von nachgelagerten Systemen erzeugt oder verwaltet.

### 7.9 Technische Zieladapter

Zulässige `target_adapter`-Werte:

- `WP_PAGE`
- `WP_POST_CATEGORY`
- `HIVEPRESS_LISTING_CATEGORY`
- `WP_CUSTOM_TAXONOMY`
- `VIRTUAL_STRUCTURE_ONLY`

Die abstrakten Adapter werden je Zielinstanz über ein gesondertes Environment-Mapping an reale WordPress-Post-Types und Taxonomien gebunden.

Verbindliche Grundzuordnung:

| Primärblock / Objekttyp | Standardadapter | Kritische Regel |
|---|---|---|
| Content-Root, Content-Hub, Content-Topic | `WP_PAGE` | Elternbeziehung über Seitenhierarchie, sofern Projektprofil nichts anderes freigibt |
| Content-Category | `WP_POST_CATEGORY` oder freigegebene Custom-Taxonomie | Ziel muss vor Projektfreigabe eindeutig festgelegt sein |
| Market-Root, Market-Category | `HIVEPRESS_LISTING_CATEGORY` | reale Taxonomie wird aus installierter HivePress-Umgebung ermittelt |
| Magazine-Root | `WP_PAGE` oder `VIRTUAL_STRUCTURE_ONLY` | projektbezogen festlegen; keine automatische Annahme |
| Magazine-Category | `WP_POST_CATEGORY` oder freigegebene Custom-Taxonomie | darf nicht mit Content-Category kollidieren |
| Glossary-Root | `WP_PAGE` oder `VIRTUAL_STRUCTURE_ONLY` | projektbezogen festlegen |
| Glossary-Category | `WP_POST_CATEGORY` oder freigegebene Custom-Taxonomie | nur bei eigenständiger Glossartaxonomie |

Ist in einem Projekt nicht eindeutig festgelegt, ob normale WordPress-Kategorien gemeinsam oder getrennt verwendet werden, lautet der Status `BLOCKED_TARGET_AMBIGUOUS`.

### 7.10 Environment-Mapping der Zielinstanz

Das Plugin erzeugt vor jeder Vorschau ein schreibgeschütztes Environment-Profil mit mindestens:

- WordPress-Version;
- aktiver Theme-Kennung;
- aktiven relevanten Plugins und Versionen;
- verfügbaren Post-Types;
- verfügbaren Taxonomien;
- Hierarchiefähigkeit jeder Taxonomie;
- realer HivePress-Listing-Post-Type;
- realer HivePress-Kategorietaxonomie;
- vorhandenen Menüpositionen;
- vorhandenen Objektzahlen;
- unterstützten Statuswerten;
- Sicherungs- und Rollbackfähigkeit.

Das Environment-Profil erhält eine eigene Prüfsumme. Ändert sich die relevante Umgebung nach Freigabe der Vorschau, verfällt die Freigabe und die Vorschau muss neu erzeugt werden.

### 7.11 Navigation und Hubdarstellung im Importmodell

`navigation_role` darf nur folgende Planungswerte besitzen:

- `PRIMARY_MENU`
- `SECONDARY_MENU`
- `HUB_ONLY`
- `FOOTER_ONLY`
- `INTERNAL_LINK_ONLY`
- `NOT_VISIBLE`
- `KEEP_EXISTING`

Dieser Wert beschreibt die gewünschte Sichtbarkeit, erzeugt in Regelblock 2A aber noch keinen Menüeintrag. Die konkrete Menü- und Hublogik wird in einem eigenen Regelblock festgelegt und getestet.

### 7.12 Eltern-, Ebenen- und Adapterkonsistenz

Für jedes Objekt gelten bereits vor den detaillierten Hierarchieregeln folgende harte Mindestbedingungen:

1. Ein Objekt der Ebene 1 besitzt `parent_concept_id = null`.
2. Ein Objekt ab Ebene 2 besitzt genau eine bekannte direkte Eltern-ID.
3. Eltern- und Kindobjekt gehören grundsätzlich demselben Primärblock.
4. Blockübergreifende Beziehungen werden als Links und nicht als Elternschaft modelliert.
5. Die Kindebene ist exakt Elternebene plus 1.
6. Der Objekttyp des Kindes muss in `allowed_child_kinds` des Elternobjekts enthalten sein.
7. Eltern- und Kindadapter müssen eine technisch darstellbare Beziehung unterstützen oder über eine ausdrücklich freigegebene Mapping-Tabelle verbunden sein.
8. Ein Objekt darf nicht eigener Vorfahr oder Nachfahr sein.
9. Ein `WP_POST_CATEGORY`-Kind darf nicht ungeprüft einer `WP_PAGE` als technische Taxonomie-Elternbeziehung zugewiesen werden. Die fachliche Zuordnung wird in diesem Fall über Konzept-IDs und Hublogik abgebildet.
10. Jede Abweichung führt zu `BLOCKED_HIERARCHY_MAPPING`.

### 7.13 Suchintentionen im Importmodell

Zulässige normalisierte Hauptwerte:

- `INFORMATIONAL`
- `PROBLEM_SOLVING`
- `COMPARISON`
- `SELECTION`
- `TRANSACTIONAL`
- `PROVIDER_SEARCH`
- `LOCAL_PROVIDER_SEARCH`
- `DEFINITIONAL`
- `EDITORIAL_CURRENT`
- `EDITORIAL_EVERGREEN`

Zusätzliche Untertypen dürfen später ergänzt werden. Eine Erweiterung darf bestehende Werte nicht rückwirkend umdeuten.

### 7.14 Unverbindliche Vorschläge als getrennte Datenklasse

Unverbindliche Vorschläge werden niemals in der Liste der Strukturobjekte geführt. Sie besitzen mindestens:

- `suggestion_id`
- `parent_category_concept_id`
- `suggestion_kind`
- `topic_direction`
- `possible_article_type`
- `possible_search_intent`
- `reason`
- `binding_status = NON_BINDING`
- `generated_at`
- `source_refs`

Sie dürfen keine `owner_cluster_id`, keine Zieladapteraktion und keine Veröffentlichungsanweisung besitzen. Bei späterer Freigabe entsteht ein neuer verbindlicher Planungsdatensatz; der ursprüngliche Vorschlag bleibt als Herkunftsnachweis erhalten.

### 7.15 Beispiel eines gültigen Strukturobjekts

```json
{
  "concept_id": "demo:content:content_hub:01K2M8X7P4F6T9",
  "project_id": "demo",
  "concept_version": "005",
  "primary_block": "CONTENT",
  "object_kind": "CONTENT_HUB",
  "target_adapter": "WP_PAGE",
  "level": 1,
  "parent_concept_id": null,
  "name": "Ausrüstung",
  "slug": "ausruestung",
  "page_title": "Ausrüstung",
  "h1": "Ausrüstung",
  "owner_cluster_id": "cluster-01K2M8Y3C7N4Q2",
  "primary_keyword": "Ausrüstung",
  "search_intent": "INFORMATIONAL",
  "scope_includes": ["zugehörige Produkt- und Themenfamilien"],
  "scope_excludes": ["konkrete Anbieterlisten", "einzelne Magazinereignisse"],
  "allowed_child_kinds": ["CONTENT_HUB", "CONTENT_TOPIC"],
  "binding_status": "APPROVED",
  "publication_intent": "DRAFT",
  "indexing_intent": "INDEX",
  "navigation_role": "PRIMARY_MENU",
  "evidence_refs": ["evidence:example-001"],
  "validation_status": "VALIDATED",
  "record_hash": "sha256:..."
}
```

Das Beispiel belegt nur die Datenform. Es legt weder das Thema noch den konkreten Zielbaum eines späteren Projekts fest.

### 7.16 Vorschauaktionen und Entscheidungslogik

Der Parser erzeugt aus Importdaten und Environment-Profil je Objekt genau eine Vorschauaktion:

- `CREATE`, wenn kein sicher zugeordnetes Zielobjekt besteht;
- `UPDATE`, wenn eine stabile Zuordnung besteht und freigabepflichtige Felder abweichen;
- `UNCHANGED`, wenn fachlicher Datensatz und relevante Zielwerte übereinstimmen;
- `ADOPT_CANDIDATE`, wenn ein wahrscheinlich passendes Bestandsobjekt ohne Konzept-ID existiert;
- `CONFLICT`, wenn mehrere oder widersprüchliche Kandidaten bestehen;
- `BLOCKED`, wenn Daten- oder Regelverletzungen bestehen;
- `MISSING_ENVIRONMENT_MAPPING`, wenn der technische Zieltyp nicht sicher aufgelöst werden kann.

`ADOPT_CANDIDATE` darf niemals automatisch übernommen werden. Es benötigt eine gesonderte sichtbare Zuordnungsfreigabe.

### 7.17 Abnahmekriterien für Regelblock 2A

Regelblock 2A ist bestanden, wenn:

- jedes verbindliche Objekt durch stabile IDs eindeutig identifiziert wird;
- Manifest und Objektdaten vollständig typisiert sind;
- Elternbeziehungen ohne WordPress-ID beschrieben werden können;
- jeder Block einen eindeutigen Zieladapter besitzt oder sichtbar blockiert wird;
- installationsabhängige HivePress- und WordPress-Ziele nicht geraten werden;
- unverbindliche Vorschläge technisch getrennt bleiben;
- eine nicht schreibende Vorschau alle vorgesehenen Laufzeitstatus erzeugen kann;
- eine geänderte Zielumgebung eine alte Vorschaufreigabe ungültig macht;
- der gleiche Datensatz durch Prüfsummen reproduzierbar erkannt wird.

---


## 7B. REGELBLOCK 2B: Hierarchie, Identität, Synchronisation und Sichtbarkeit

### 7B.1 Oberste Anforderung: Allgemeingültigkeit

Regelblock 2B gilt unabhängig von Branche, Sprache, Portalgröße, Design, konkretem Kategorienamen und installierter WordPress- oder HivePress-Version. Beispiele haben ausschließlich erläuternde Funktion. Fachliche Regeln werden nicht aus Eigenschaften des Pferde-Ateliers abgeleitet.

### 7B.2 Allgemeine Hierarchielogik

Die Hierarchie entwickelt sich von breiten Themen zu immer engeren, eigenständigen Teilräumen. Jede zusätzliche Ebene muss einen nachweisbaren fachlichen und nutzerbezogenen Mehrwert besitzen. Kinder sind enger als ihre Eltern; Geschwister sind trennscharf und nach einem gemeinsamen Hauptkriterium gebildet.

Jede Kategorie besitzt genau einen primären Elternknoten im selben Block. Die tatsächliche Ebene wird aus der vollständigen Elternkette berechnet. Fehlende Eltern, Ebenensprünge, Selbstbezüge, Kreisbeziehungen und blockübergreifende Elternbindungen führen zu `BLOCKED`.

### 7B.3 Zulässigkeit einer neuen Kategorie

Eine neue Kategorie wird nur zugelassen, wenn alle folgenden Bedingungen erfüllt sind:

- eigenständiger fachlicher Themenkern;
- eindeutige primäre Suchintention;
- klare positive Zuständigkeit;
- klare Ausschluss- und Geschwisterabgrenzung;
- logische Elternzuordnung;
- ausreichende blockbezogene Mindestsubstanz;
- kürzester fachlich korrekter, eindeutiger und gebräuchlicher Name;
- keine Synonym-, Slug-, Intentions- oder Eigentümerdublette;
- keine künstliche Zwischenebene;
- technisch abbildbarer Zieltyp.

Ein einzelnes Keyword, eine minimale Sprachvariante oder der Wunsch nach symmetrischer Navigation reicht nicht aus.

### 7B.4 Blockbezogene Tiefe

**Content:** darf tief sein, sofern jede Ebene fachlich notwendig ist. Die unterste verbindliche Ebene muss auf WordPress-Basis zwingend eine Kategorie oder hierarchische Taxonomie sein, damit Longtail-Beiträge dort zugeordnet werden können. Eine normale Seite darf diese Endebene nicht ersetzen.

**HivePress:** bleibt möglichst flach und folgt realer Markt-, Angebots- und Anbieterlogik. Eigenschaften werden zunächst als Filter oder Attribute geprüft.

**Magazin/Journal:** bleibt redaktionell übersichtlich. Rubriken sind breite dauerhafte Themenräume; Beitragsarten und einzelne Longtails werden nicht als Rubriken angelegt.

**Glossar:** bleibt grundsätzlich flach und begriffsbezogen.

Die fachlich erforderliche Tiefe, die im Konzept zugelassene Tiefe, die technisch mögliche Tiefe und die sichtbare Menütiefe werden getrennt gespeichert.

### 7B.5 WordPress-Objektfolge im Contentblock

Höhere Strukturebenen können je nach freigegebenem Modell durch Kategorien, Hubseiten oder Kategorien mit ergänzender Hubdarstellung repräsentiert werden. Verbindlich ist jedoch:

- die beitragstragende unterste Contentebene ist eine Kategorie beziehungsweise hierarchische Taxonomie;
- darunter liegen die konkreten Longtail-Beiträge;
- eine optionale Hubseite ersetzt die Kategorie nicht;
- der Importadapter darf den vorgesehenen Objekttyp nicht eigenmächtig ändern.

### 7B.6 Allgemeingültiges Identitätsmodell

Es werden getrennt geführt:

1. `concept_id`: dauerhafte, nicht sprechende, systemweit eindeutige Identität des verbindlichen Konzeptobjekts;
2. `suggestion_id`: temporäre Identität eines unverbindlichen Vorschlags;
3. externe Ziel-ID: installationsabhängige WordPress-, HivePress-, Menü- oder Taxonomie-ID;
4. `parent_concept_id`: stabile Elternreferenz innerhalb des Konzeptmodells.

Namen, Slugs, Ebenen, Elternpositionen und externe IDs sind veränderliche Eigenschaften und keine Identität. IDs werden nie wiederverwendet.

### 7B.7 Änderungs- und Synchronisationsmodell

Das Kategoriesystem ist die fachliche Konzeptquelle der Wahrheit. Für jeden Import werden Konzeptstand, letzter Importstand und aktueller Zielsystemstand verglichen.

Mögliche Ergebnisse:

- `CREATE`
- `UPDATE`
- `UNCHANGED`
- `ADOPT_CANDIDATE`
- `CONFLICT`
- `BLOCKED`
- `MISSING_ENVIRONMENT_MAPPING`

Umbenennungen und geprüfte Verschiebungen behalten die Konzept-ID. Aufspaltungen erzeugen neue IDs. Zusammenführungen werden niemals automatisch ausgeführt. Fehlende Objekte werden nicht automatisch gelöscht. Direkte Änderungen im Zielsystem erzeugen erkennbare Abweichungen.

### 7B.8 Automatische Vorschläge

Das System darf unverbindlich neue Kategorien, Elternzuordnungen, Suchintentionen, Beitragsarten und Beitragsthemen vorschlagen. Jeder Vorschlag muss begründet, abgegrenzt, begrenzt und klar als nicht verbindlich gekennzeichnet sein.

Beitragsvorschläge entstehen erst unter einer freigegebenen untersten Kategorie. Sie reservieren keine Keywords und können vom Textsystem frei geprüft, angepasst oder abgelehnt werden. Ein Statuswechsel in einen verbindlichen Zustand erfolgt nur ausdrücklich und protokolliert.

### 7B.9 Navigation und Hubausgabe

Fachhierarchie und sichtbare Navigation werden getrennt modelliert. Sichtbarkeitsfelder können beispielsweise Hauptmenü, Sekundärmenü, Footer, Hub oder verborgen steuern. `HIDDEN` bedeutet nur nicht im Menü, nicht inaktiv oder unerreichbar.

Alle aktiven Kategorien müssen über normale HTML-Links erreichbar sein. Werden Kinder aus Platzgründen nicht im Menü gezeigt, müssen sie vollständig auf der zuständigen Hubseite oder Hubdarstellung erscheinen.

Das Kategoriesystem definiert Relationen und Sichtbarkeitsvorgaben, aber keine redaktionellen Ankertexte. Textlinks werden durch das Textsystem, Kacheln und strukturierte Verweise durch das Template-/Designsystem erzeugt.

### 7B.10 Fachliche und technische Prüflogik

Jeder Datensatz erhält genau einen Gesamtstatus:

- `PASS`
- `WARNING`
- `CONFLICT`
- `BLOCKED`

Kritische Struktur-, Identitäts-, Eigentümer-, Zieltyp- oder Datenverlustfragen dürfen niemals nur als Warnung behandelt werden.

Vor dem Import werden mindestens geprüft:

- Pflichtfelder und Datentypen;
- Konzept- und Vorschlags-IDs;
- Elternkette und berechnete Ebene;
- Block- und Objektartkonsistenz;
- kürzester eindeutiger Name;
- Keyword- und Intentionsabgrenzung;
- WordPress-Endkategorie im Content;
- Slug- und Bestandskonflikte;
- Environment-Mapping;
- Navigation und Erreichbarkeit;
- Wiederholbarkeit und erwartete Aktionen.

### 7B.11 Erste Teststufe

Die erste Pluginstufe bleibt vollständig lesend. Sie:

1. liest ZIP/JSON und Manifest;
2. prüft Schema und Prüfsummen;
3. validiert IDs, Felder und Status;
4. berechnet Hierarchie und Importreihenfolge;
5. inventarisiert WordPress, HivePress, Taxonomien und Menüs;
6. löst abstrakte Zielrollen über das Environment-Mapping auf;
7. vergleicht Bestand und Konzept;
8. zeigt alle Importaktionen, Konflikte und Blocker;
9. exportiert einen vollständigen Prüfbericht.

Sie erzeugt, ändert, verschiebt oder löscht noch keine Objekte.

### 7B.12 Testpaket

Das erste Testpaket ist klein, aber deckt alle wesentlichen Objektarten und Prüfpfade ab. Es enthält:

- einen gültigen Contentbaum mit beitragstragender Endkategorie;
- eine getrennte HivePress-Struktur;
- eine flache Magazinstruktur;
- optional Glossarbegriffe;
- getrennte unverbindliche Beitragsvorschläge;
- absichtlich fehlerhafte Negativdatensätze.

Pflicht-Negativfälle sind mindestens doppelte Konzept-ID, fehlender Elternknoten, falsche Ebene, Kreisbezug, blockübergreifender Elternknoten, ungeklärtes Zielmapping, Dublette, Slugkonflikt und normale Seite als beitragstragende unterste Contentebene.

### 7B.13 Abnahmekriterien

Regelblock 2B gilt als fachlich abgeschlossen, wenn:

- alle Blöcke allgemeingültig und funktionsgerecht behandelt werden;
- Content-Endkategorien eindeutig als Kategorien/Taxonomien vorgeschrieben sind;
- Identität unabhängig von Thema und Zielsystem funktioniert;
- Vorschläge und verbindliche Objekte technisch getrennt sind;
- Navigation und Fachstruktur getrennt bleiben;
- Synchronisations- und Änderungskonflikte erkannt werden;
- ein nicht schreibender Testlauf vollständig spezifiziert ist;
- kein installationsabhängiger Wert geraten werden muss.

## 7C. REGELBLOCK 2C: Vollautomatische Erzeugung, interne Selbstprüfung und Freigabereife

### 7C.1 Zwei oberste Systemprinzipien

Alle nachfolgenden Regeln sind diesen beiden gleichrangigen Prinzipien untergeordnet:

1. **Allgemeingültigkeit:** Keine Regel, Datenstruktur oder Entscheidungslogik darf von einem konkreten Thema, einer Branche, einer Sprache, einem Portalnamen oder einer einzelnen WordPress-Installation abhängen.
2. **Größtmögliche Automatisierung:** Der Nutzer soll im optimalen Standardfall nur ein Hauptthema vorgeben. Alles regelbasiert Ableitbare wird automatisch recherchiert, erzeugt, geprüft, korrigiert und vorbereitet.

Konkrete Themenbeispiele dürfen ausschließlich Testdaten sein. Sie dürfen keine allgemeine Regel begründen, begrenzen oder technisch fest verdrahten.

### 7C.2 Automatisches Zielbild ab einer Themenvorgabe

Nach Eingabe eines Hauptthemas soll das System automatisch:

1. das Thema und seine möglichen Bedeutungen analysieren;
2. relevante Hauptbereiche, Unterbereiche, Produkte, Probleme, Anbieterarten und redaktionelle Themen ermitteln;
3. Content, Marketplace, Magazin/Journal und Glossar funktional trennen;
4. eine Keywordhierarchie von breiten Hauptbegriffen bis zu den beitragstragenden Endkategorien erzeugen;
5. für sichtbare Kategorien stets den kürzesten fachlich korrekten, eindeutigen und gebräuchlichen Begriff wählen;
6. die Eltern-Kind-Struktur und die blockbezogene Tiefe bestimmen;
7. Synonyme, Doppelungen, künstliche Ebenen und konkurrierende Suchintentionen bereinigen;
8. die untersten Contentknoten zwingend als beitragstragende WordPress-Kategorien beziehungsweise hierarchische Taxonomie planen;
9. darunter ausschließlich unverbindliche Beitragsarten und Themenrichtungen vorschlagen;
10. mehrere mögliche Gesamtmodelle intern erzeugen und bewerten;
11. den bestbewerteten regelkonformen Entwurf auswählen;
12. diesen vor der Nutzerausgabe intern prüfen und erkannte Fehler automatisch korrigieren;
13. nach fachlicher Freigabe einen technisch prüfbaren Ein-Klick-Import vorbereiten.

### 7C.3 Interne Konzept-Testinstanz vor jeder sichtbaren Empfehlung

Ein erster Entwurf darf nicht unmittelbar als Vorschlag ausgegeben werden. Vor jeder sichtbaren Empfehlung muss eine interne, nicht schreibende Konzeptprüfung erfolgen.

Sie prüft mindestens:

- Themen- und Branchenunabhängigkeit der angewendeten Regeln;
- Vollständigkeit der fachlichen Kernstruktur;
- klare Blockzuordnung und Blocktrennung;
- logische Keywordhierarchie von breit nach konkret;
- eindeutige Eltern-Kind-Beziehungen;
- trennscharfe Geschwisterkategorien;
- kürzeste eindeutige Benennung;
- Synonyme, Dubletten und Suchintentionsüberschneidungen;
- ausreichende Substanz jedes Kategorieobjekts;
- Vermeidung künstlicher Tiefe;
- korrekte beitragstragende Endkategorien;
- langfristige Erweiterbarkeit und Stabilität.

Besteht ein Entwurf die Prüfung nicht, muss er intern korrigiert und erneut geprüft werden. Ein fehlerhafter oder ungeprüfter Rohentwurf darf nicht als regulärer Vorschlag ausgegeben werden.

### 7C.4 Interne Variantenbildung und Auswahl des besten Entwurfs

Das System darf intern mehrere Strukturmodelle erzeugen. Diese werden nach einem einheitlichen Qualitätsmodell bewertet. Maßgebliche Kriterien sind mindestens:

- Allgemeingültigkeit;
- fachliche Abdeckung der Kernbereiche;
- Nutzerverständlichkeit;
- kurze und eindeutige Bezeichnungen;
- logische Keywordhierarchie;
- geringe Überschneidung;
- klare Blocktrennung;
- angemessene, nicht künstliche Tiefe;
- ausreichendes Entwicklungspotenzial;
- Erweiterbarkeit;
- technische Abbildbarkeit und sichere Importierbarkeit.

Standardmäßig wird nur der bestbewertete bestandene Gesamtvorschlag vorgelegt. Mehrere Varianten werden nur gezeigt, wenn trotz vollständiger Prüfung mehrere grundlegend unterschiedliche Portalmodelle fachlich gleichwertig bleiben.

### 7C.5 Keine starre Mengen- oder Tiefenvorgabe

Es gibt keine allgemeine Vorgabe wie:

- immer eine feste Zahl von Hauptkategorien;
- immer dieselbe Zahl von Unterkategorien;
- immer dieselbe Hierarchietiefe;
- immer dieselben Beitragsarten.

Anzahl und Tiefe ergeben sich aus Thema, Suchintention, Nutzerlogik und blockbezogener Funktion. Technische und sichtbare Navigationsgrenzen bleiben davon getrennt.

### 7C.6 Automatische Bereinigung vor der Ausgabe

Das System muss vor der Ausgabe automatisch prüfen und soweit eindeutig möglich korrigieren:

- Synonyme und sprachliche Varianten zusammenführen;
- überlange Kategorienamen auf den kürzesten eindeutigen Begriff reduzieren;
- doppelte Suchintentionen einem einzigen Eigentümer zuweisen;
- schwache Einzelkategorien sinnvoll zusammenführen;
- künstliche Zwischenebenen entfernen;
- falsch eingeordnete Themen verschieben;
- Beitragsfragen und Longtails aus der Kategoriehierarchie entfernen;
- reine Merkmale aus Marketplace-Kategorien in Attribute oder Filter überführen;
- fehlende Kernbereiche ergänzen, ohne die Struktur mit Randthemen aufzublähen.

Eine automatische Korrektur ist nur zulässig, wenn die Regelentscheidung eindeutig ist. Bei mehreren gleichwertigen Lösungen bleibt der Punkt ungelöst und wird als Grundsatzentscheidung vorgelegt.

### 7C.7 Vollständigkeit und Freigabereife

Eine Kategoriehierarchie gilt als fachlich vollständig, wenn:

- alle für das geplante Portal notwendigen Hauptbereiche abgedeckt sind;
- jeder Knoten genau einem Primärblock angehört;
- jede Nicht-Wurzelkategorie genau einen eindeutigen Primärelternknoten besitzt;
- die Keywordhierarchie durchgängig von breit nach konkret verläuft;
- Geschwister klar getrennt sind;
- keine Synonyme als getrennte Kategorien bestehen;
- der kürzeste eindeutige und gebräuchliche Begriff verwendet wird;
- jede Endkategorie fachlich tragfähig ist;
- jede unterste Contentebene beitragstragend als Kategorie oder hierarchische Taxonomie angelegt werden kann;
- Content, Marketplace, Magazin/Journal und Glossar keine identische Hauptfunktion doppelt abbilden;
- keine bekannten fachlichen Blocker mehr bestehen.

Vollständigkeit bedeutet nicht, jedes theoretisch mögliche Randthema aufzunehmen. Sie bedeutet eine logisch geschlossene, erweiterbare und konfliktfreie Kernstruktur.

### 7C.8 Automatische Vorschläge und manuelle Entscheidungen

Automatisch vorgeschlagen werden dürfen insbesondere:

- fehlende Haupt- oder Unterkategorien;
- mögliche Elternzuordnungen;
- kürzere Kategorienamen;
- Synonymzuordnungen;
- Struktur- und Themenlücken;
- unverbindliche Beitragsarten und Themenrichtungen unter Endkategorien.

Eine manuelle Grundsatzentscheidung ist nur erforderlich, wenn:

- das Hauptthema tatsächlich mehrdeutig ist;
- mehrere fachlich gleichwertige Portalmodelle bestehen;
- mehrere gleichwertige Elternzuordnungen nicht regelbasiert auflösbar sind;
- Zielregion, Rechtssystem oder Marktmodell die Struktur grundlegend verändern;
- eine fachliche Abgrenzung nicht aus verfügbaren Informationen ermittelbar ist.

Normale Strukturarbeit darf nicht unnötig an den Nutzer zurückgegeben werden. Rückfragen werden auf die kleinstmögliche Zahl echter Grundsatzentscheidungen begrenzt.

### 7C.9 Zwei getrennte Testebenen

**Interne Konzeptprüfung:** erfolgt automatisch vor jeder sichtbaren Empfehlung und prüft fachliche Logik, Allgemeingültigkeit und Regelkonformität.

**Externe WordPress-Testinstanz:** erfolgt nach fachlicher Freigabe und vor Importfreigabe. Sie prüft ausschließlich die konkrete technische Abbildung, korrekte Tiefe, Zielzuordnung, Wiederholbarkeit, Dublettenfreiheit, Navigation, Endkategorien und Rücksetzbarkeit.

Die externe Testinstanz ersetzt nicht die interne Konzeptprüfung. Beide Prüfungen sind zwingend und haben unterschiedliche Aufgaben.

### 7C.10 Freigabestufen

Der verbindliche Lebenszyklus eines Gesamtentwurfs lautet:

1. `INTERNAL_DRAFT` – intern erzeugt, nicht sichtbar;
2. `INTERNAL_TESTED` – interne Konzeptprüfung bestanden;
3. `PROPOSED` – sichtbar, noch unverbindlich;
4. `FACHLICH_FREIGEGEBEN` – Struktur fachlich verbindlich;
5. `TECHNISCH_GETESTET` – Testinstanz vollständig bestanden;
6. `IMPORTFREIGEGEBEN` – Ein-Klick-Import zulässig;
7. `IMPORTED` – kontrolliert importiert und protokolliert.

Ein Status darf nicht übersprungen werden. Ein unverbindlicher Vorschlag darf niemals automatisch importiert werden.

### 7C.11 Ein-Klick-Import als automatisiertes Endergebnis

Der Ein-Klick-Import ist nicht bloß das Anlegen von Kategorien. Er muss nach bestandener Freigabe automatisch und reproduzierbar:

- jeden Block dem korrekten Zielsystem zuordnen;
- alle Kategorien in richtiger Tiefe und Reihenfolge anlegen oder eindeutig aktualisieren;
- stabile Konzept-IDs mit installationsabhängigen Zielobjekten verbinden;
- die untersten Contentebenen zwingend als beitragstragende Kategorien oder hierarchische Taxonomien anlegen;
- sichtbare Navigation und fachliche Hierarchie getrennt behandeln;
- bestehende Zielobjekte erkennen und Dubletten verhindern;
- keine ungeprüften Löschungen, Verschiebungen oder Zusammenführungen durchführen;
- einen vollständigen Prüf- und Importbericht erzeugen;
- einen sicheren Rücksetzweg bereitstellen.

### 7C.12 Kritische Automatisierungsgrenze

Größtmögliche Automatisierung bedeutet nicht, Unsicherheiten zu verdecken oder zu raten. Das System muss selbstständig entscheiden, wo Regeln eine eindeutige Lösung erlauben. Wo keine eindeutige Lösung besteht, muss es den Konflikt klar benennen, statt eine zufällige Wahrscheinlichkeit als Wahrheit zu behandeln.

**Verbindliche Gesamtregel:** Das System übernimmt so viel Analyse, Entwicklung, Selbstprüfung, Korrektur, Auswahl und Importvorbereitung wie technisch und fachlich zuverlässig möglich. Der Nutzer wird nur bei echten Grundsatzkonflikten und für die endgültigen Freigaben benötigt.

---

## 8. Verbindliche Prüf-Gates

### Gate 1: Recherche vollständig

Keywords, Fragen, Themen, Anbieterarten und redaktionelle Themen wurden mit dokumentierten Quellen recherchiert.

### Gate 2: Cluster trennscharf

Synonyme und gleichartige Suchintentionen sind zusammengeführt; Mehrdeutigkeiten sind geklärt.

### Gate 3: Blockzuordnung eindeutig

Jedes Cluster besitzt genau einen primären Block und eine begründete Rolle.

### Gate 4: Hierarchie korrekt

Jeder Kindknoten ist enger als sein Elternknoten; Geschwister sind trennscharf; Ein-Kind- und Leerstrukturen sind beseitigt oder begründet.

### Gate 5: Navigation geeignet

Navigationsnamen sind kurz, verständlich und keywordbezogen. Vollständige Erreichbarkeit ist gesichert.

### Gate 6: Keine Kannibalisierung

Innerhalb und zwischen allen Funktionsblöcken existiert kein ungeklärter Eigentümer- oder Suchintentionskonflikt.

### Gate 7: Importvorschau bestätigt

Alle Neuanlagen und Änderungen sind vollständig sichtbar und ausdrücklich freigegeben.

### Gate 8: Technische Prüfungen bestanden

Positivtests, Negativtests, Wiederholungstest und Bestandsabgleich sind erfolgreich.

Erst nach Gate 8 ist ein produktiver Import zulässig.

---

## 9. Geplanter allgemeingültiger Workflow

1. Projektprofil und Zielmarkt erfassen.
2. Bestehenden WordPress-/HivePress-Bestand inventarisieren.
3. Themen-, Keyword-, Fragen- und Anbieterrecherche durchführen.
4. Begriffe normalisieren und Entitäten bestimmen.
5. Suchintentionen klassifizieren.
6. semantische Cluster bilden.
7. Keyword-Eigentümer festlegen.
8. Cluster den Funktionsblöcken zuweisen.
9. Contenthierarchie erzeugen.
10. HivePress-Hierarchie erzeugen.
11. Magazin- und Glossarstruktur erzeugen.
12. je unterster Kategorie unverbindliche Beitragsarten, Themenrichtungen und Longtail-Richtungen vorschlagen.
13. Navigationsnamen, Seitentitel und Slugs getrennt erzeugen.
14. interne Verlinkungsbeziehungen planen.
15. vollständige Anti-Kannibalisierungsprüfung ausführen.
16. menschlich prüfbare Gesamtvorschau erstellen.
17. Nutzerfreigabe einholen.
18. Importplan erzeugen.
19. technischen Trockenlauf durchführen.
20. Positiv-, Negativ- und Wiederholungstests ausführen.
21. freigegebene Struktur importieren.
22. Ergebnis gegen den Importplan verifizieren.
23. freigegebene Kategorien sowie klar gekennzeichnete unverbindliche Vorschläge an Text- und Designsystem übergeben.

---

## 10. Geplantes Plugin-Zielbild

**Arbeitsname:** Affiliate-Kategoriesystem

Geplante Module:

1. Projektprofil
2. Bestandsimport und Inventur
3. Rechercheimport
4. Themen- und Keywordregister
5. Block- und Eigentümerzuordnung
6. Hierarchieplaner
7. Kannibalisierungsvalidator
8. Navigations- und Slugplaner
9. unverbindlicher Beitragsarten- und Themenvorschlag
10. Vorschau, Statuswechsel und Freigabe
11. WordPress-Seiten-/Kategorieimport
12. HivePress-Taxonomieimport
13. Änderungs- und Wiederholungsschutz
14. Export für Text- und Designsystem
15. Prüfprotokoll

Es ist noch kein schreibendes Plugin freigegeben oder erstellt. Aufgrund der verfügbaren WordPress-Testinstanz darf nach Festlegung des Importdatenmodells eine erste nicht schreibende technische Stufe als Parser, Validator und Importvorschau entwickelt werden. Schreibzugriffe bleiben bis zum bestandenen Test-Gate deaktiviert.

---

## 11. Geprüfter Referenzstand Pferde-Atelier

Quelle: vollständiger WordPress-Export `pferdeatelier.WordPress.2026-07-26.xml`

### 11.1 Rekonstruierter Bestand

- 412 WordPress-Seiten insgesamt
- 410 veröffentlichte Seiten
- 8 Hauptseiten des Contentbaums
- 59 Themenhubs
- 329 konkrete Unterseiten
- 1.133 normale WordPress-Kategorien
- davon 1.124 beitragstypbezogene Kategorien in der Produktnavigation
- 8 Magazinrubriken
- 1 Standardkategorie
- 95 HivePress-Kategorien
- davon 10 Hauptkategorien und 85 Unterkategorien
- 35 Beiträge, davon 12 veröffentlicht und 23 im Papierkorb

### 11.2 Relevante Struktur

Der Contentbaum verwendet:

- Ebene 1: WordPress-Seite
- Ebene 2: WordPress-Seite
- Ebene 3: WordPress-Seite
- Ebene 4: normale WordPress-Kategorie
- darunter: einzelne Beiträge

HivePress verwendet eine eigene Taxonomie mit zwei Kategorieebenen.

Das Magazin verwendet acht separate normale WordPress-Kategorien.

### 11.3 Erkannte Risiken

- 13 konkrete Seitentitel kommen mehrfach vor.
- `Weidezaungeräte` ist zweimal im selben Elternbereich vorhanden.
- 45 sichtbare Namen normaler WordPress-Kategorien kommen mehrfach vor.
- 78 konkrete Contentseiten besitzen keine untergeordneten Beitragskategorien.
- Die normalen WordPress-Kategorien sind technisch flach; ihre fachliche Zuordnung wird im Export über die Navigation abgebildet.
- Beitragsarten sind uneinheitlich verteilt und dürfen deshalb nicht ungeprüft pauschal erzeugt werden.

Diese Befunde sind noch keine Reparaturfreigabe. Sie dienen der Entwicklung und späteren Prüfung des allgemeingültigen Regelwerks.

---

## 12. Bestätigte Entscheidungen

1. Das System muss von Beginn an allgemeingültig sein.
2. Das Pferde-Atelier ist nur Blaupause und Testobjekt.
3. Content, HivePress und Magazin/Journal bleiben inhaltlich strikt getrennt.
4. Keyword-Hierarchie muss von breit nach konkret über die gesamte Kategorietiefe eingehalten werden.
5. Kategorienamen in der Hauptnavigation müssen kurz, prägnant und keywordbezogen sein.
6. Keyword-Kannibalisierung ist innerhalb und zwischen allen Funktionsblöcken unzulässig.
7. Unklare Fälle werden blockiert und nicht geraten.
8. Vor einem Import ist eine vollständige Vorschau mit Nutzerfreigabe Pflicht.
9. Das spätere Ergebnis wird über ein WordPress-Plugin importierbar.
10. Die Arbeit wird in einer vollständigen, fortlaufend aktualisierten Masterdatei dokumentiert.
11. Das Kategoriesystem arbeitet verbindlich bis einschließlich der untersten Kategorieebene.
12. Unterhalb der Kategorieebene werden Beitragsarten, Themenrichtungen und Longtail-Richtungen nur unverbindlich vorgeschlagen.
13. Unverbindliche Vorschläge erzeugen keine Keyword-Eigentümerschaft und keine Reservierung im Redaktionsplan.
14. Eine spätere Verbindlichkeit ist ausschließlich durch einen klar protokollierten Freigabe- oder Statuswechsel zulässig.
15. Content, HivePress und Magazin/Journal besitzen jeweils eigene Hauptaufgaben, Seitentypen und Hierarchielogiken.
16. Überschneidungen des Themas sind erlaubt; Überschneidungen derselben primären Funktion oder Suchintention sind unzulässig.
17. Die drei Inhaltsblöcke dürfen unterschiedlich tief aufgebaut sein und müssen nicht symmetrisch sein.
18. Das Bedienziel ist ein zentraler kontrollierter Ein-Klick-Import der vollständig freigegebenen Struktur.
19. Vorschau, harte Validierung, Sicherung, Idempotenz, Protokoll und Rollback sind unverzichtbare Bestandteile des Ein-Klick-Workflows.
20. Content, HivePress und Magazin/Journal werden über getrennte Importadapter verarbeitet.
21. Unverbindliche Beitragsvorschläge werden nicht importiert, solange kein ausdrücklicher Statuswechsel erfolgt ist.
22. Die vorhandene WordPress-Testinstanz wird vor jeder Produktivfreigabe für Positiv-, Negativ-, Wiederholungs- und Rollbacktests verwendet.
23. Allgemeingültigkeit ist die oberste Leitregel; konkrete Beispiele sind niemals normgebend.
24. Für sichtbare Kategorienamen ist immer der kürzeste eindeutige, fachlich korrekte und gebräuchliche Begriff zu verwenden.
25. Die unterste Contentebene ist auf WordPress-Basis zwingend eine beitragstragende Kategorie beziehungsweise hierarchische Taxonomie.
26. Konzept-IDs sind nicht sprechend und unabhängig von Thema, Sprache, Name, Slug, Ebene, Elternposition und Installation.
27. Vorschlags-IDs, Konzept-IDs und externe WordPress-/HivePress-IDs bleiben strikt getrennt.
28. Fachhierarchie, Navigation und sichtbare Hubdarstellung werden getrennt modelliert.
29. Das Kategoriesystem speichert blockübergreifende Relationen, erstellt aber keine kontextbezogenen Textlinks.
30. Die erste Pluginstufe bleibt vollständig lesend und wird erst nach bestandener Vorschauprüfung erweitert.
31. Masterdateien werden nicht nach jedem kleinen Schritt, sondern nach größeren logisch abgeschlossenen Arbeitsblöcken vollständig aktualisiert.
32. Allgemeingültigkeit und größtmögliche Automatisierung sind die beiden gleichrangigen obersten Systemprinzipien.
33. Im optimalen Standardfall gibt der Nutzer ausschließlich das Hauptthema vor.
34. Vor jeder sichtbaren Empfehlung erfolgt eine interne, nicht schreibende Konzeptprüfung mit automatischer Korrekturschleife.
35. Das System darf intern mehrere Gesamtmodelle erzeugen, legt aber standardmäßig nur den bestbewerteten bestandenen Entwurf vor.
36. Starre Zahlen für Kategorien, Unterkategorien, Ebenen oder Beitragsarten sind unzulässig.
37. Nutzerfragen werden auf echte, nicht regelbasiert lösbare Grundsatzentscheidungen begrenzt.
38. Die interne Konzeptprüfung und die externe WordPress-Testinstanz sind getrennte, jeweils zwingende Prüfebenen.
39. Ein Entwurf durchläuft die Freigabestufen von internem Entwurf bis zum protokollierten Import ohne Statussprung.
40. Technische Details werden vollständig in der Masterdatei dokumentiert und im Chat nur knapp konzeptionell zusammengefasst.

---

## 13. Erledigte Arbeitsschritte

1. Projektziel sowie Drei-Portalhauptblöcke mit eigenständiger Glossarfunktion aufgenommen.
2. vollständigen Pferde-Atelier-Export technisch inventarisiert.
3. Content-, HivePress- und Magazinstruktur rekonstruiert.
4. erste Dubletten, Leerstellen und Hierarchierisiken festgestellt.
5. allgemeine Grundregeln R-001 bis R-035 formuliert.
6. Prüf-Gates und Gesamtworkflow als erster verbindlicher Entwurf erstellt.
7. Plugin-Zielbild auf Modulebene dokumentiert.
8. Regelblock 1 für Blockzuordnung und Keyword-Eigentümerschaft vollständig spezifiziert.
9. Positivfälle, Negativfälle, Konfliktmatrix, BLOCKED-Status und Abnahmekriterien für Regelblock 1 festgelegt.
10. Zuständigkeitsgrenze des Kategoriesystems bis einschließlich der untersten Kategorieebene festgelegt.
11. unverbindliche Vorschlagslogik unterhalb der Kategorieebene einschließlich möglichem späterem Freigabewechsel festgelegt.
12. blockbezogene Grundregeln für Content, HivePress und Magazin/Journal als R-036 bis R-050 ergänzt.
13. kontrollierten Ein-Klick-Import als verbindliches Bedienziel festgelegt.
14. Importdaten, Blockadapter, Vorschau, harte Validierung, Idempotenz, Bestandsabgleich, Löschschutz, Sicherung, Protokoll und Rollback als R-051 bis R-065 festgeschrieben.
15. WordPress-Testinstanz als zwingendes Freigabe-Gate vor Produktiveinsatz aufgenommen.
16. Regelblock 2A mit Manifest, Pflichtfeldern, Datentypen, stabilen IDs, Statuswerten, Objektarten, Zieladaptern und Environment-Mapping vollständig spezifiziert.
17. unverbindliche Vorschläge als technisch getrennte Datenklasse festgelegt.
18. Vorschauaktionen und Abnahmekriterien für die nicht schreibende Pluginstufe festgelegt.
19. Regelblock 2B mit Hierarchie-, Eltern-Kind-, Kategorie-Zulässigkeits- und blockbezogenen Tiefenregeln ausgearbeitet.
20. den kürzesten eindeutigen Kategorienamen als verbindlichen Standard festgelegt.
21. die unterste WordPress-Contentebene zwingend als beitragstragende Kategorie beziehungsweise Taxonomie festgelegt.
22. allgemeingültiges, nicht sprechendes Konzept-ID-Modell einschließlich Vorschlags- und externer Ziel-IDs festgelegt.
23. Änderungs-, Versions- und Drei-Wege-Synchronisationslogik spezifiziert.
24. Regeln für automatische, unverbindliche und begrenzte Kategorie- und Beitragsvorschläge festgelegt.
25. Fachstruktur, Navigation, Hubdarstellung und blockübergreifende Relationen getrennt.
26. fachliche und technische Prüfstatus sowie rein lesende erste Teststufe spezifiziert.
27. Anforderungen an das allgemeingültige erste Positiv-/Negativ-Testpaket festgelegt.
28. Allgemeingültigkeit und größtmögliche Automatisierung als gleichrangige oberste Leitregeln festgelegt.
29. optimalen Ein-Thema-Start als verbindliches Zielbild aufgenommen.
30. interne Konzept-Testinstanz und automatische Korrekturschleife vor jeder sichtbaren Empfehlung festgelegt.
31. interne Variantenbildung, Qualitätsbewertung und Auswahl des besten Gesamtentwurfs geregelt.
32. Vollständigkeits- und Freigabekriterien für eine Kategoriehierarchie festgelegt.
33. interne Konzeptprüfung und externe WordPress-Testinstanz als zwei getrennte Pflichtprüfungen definiert.
34. mehrstufigen Freigabeprozess bis zum Ein-Klick-Import festgeschrieben.
35. technische Detailkommunikation auf die Masterdatei begrenzt.

---

## 14. Offene Arbeitsschritte

1. minimale zwingende Eingaben außer dem Hauptthema bestimmen und alle übrigen Angaben als automatisch ermittelbar, optional oder konfigurierbar klassifizieren.
2. allgemeingültige automatische Themenanalyse und Recherchestrategie konzeptionell festlegen.
3. Qualitätsgewichtung für die interne Auswahl des besten Strukturmodells finalisieren.
4. technische Regeln aus den Regelblöcken 2A bis 2C zu einem ausführbaren Schema konsolidieren.
5. WordPress-Testinstanz technisch inventarisieren und Environment-Mapping erzeugen.
6. allgemeingültiges künstliches Testpaket mit Positiv- und Negativfällen erstellen.
7. erste nicht schreibende Pluginstufe als Parser, Validator, Bestandsleser und Vorschau entwickeln.
8. Testpaket auf der Testinstanz ausführen und Ergebnisse fachlich prüfen.
9. erst nach bestandenem Trockenlauf den schreibenden Importadapter entwickeln und testen.
10. Schnittstelle zum Textsystem für verbindliche Endkategorien und unverbindliche Beitragsvorschläge abschließen.

---

## 15. Aktuelle Blocker

Für einen schreibenden Import fehlen weiterhin:

- die technische Inventur und das Environment-Mapping der konkreten Testinstanz;
- ein ausführbares, validiertes JSON-Schema;
- das allgemeingültige Testpaket;
- eine bestandene nicht schreibende Vorschau mit Negativtests;
- geprüfte Sicherungs- und Rücksetzmechanismen.

Kein Blocker besteht für die Entwicklung der rein lesenden Parser-, Validator-, Bestands- und Vorschauversion.

Installationsabhängige WordPress-, HivePress-, Taxonomie-, Post-Type- und Menübezeichner dürfen weiterhin nicht geraten werden.

---

## 16. Minimaler Nutzereinstieg, Ergebnisgrenzen und Schnittstelle zu Design- und Textsystem

### 16.1 Minimaler Standardstart

Im optimalen Standardfall gibt der Nutzer ausschließlich das Hauptthema des Portals vor. Sprache wird grundsätzlich aus der Eingabe abgeleitet. Weitere Angaben dürfen nur abgefragt werden, wenn ohne sie mehrere grundlegend unterschiedliche Portalmodelle fachlich gleichwertig bleiben und die Entscheidung nicht regelbasiert, durch Recherche oder durch eine sichere Standardannahme gelöst werden kann.

Mögliche zusätzliche Grundsatzangaben sind nur bei echtem Bedarf:

- Zielmarkt oder Region;
- wesentlich abweichende Hauptzielgruppe;
- grundlegende Art des Marktplatzes;
- ausdrücklich gewünschte thematische Ausschlüsse oder Grenzen.

Nicht vom Nutzer abzufragen sind normale Strukturentscheidungen wie Anzahl der Kategorien, Hierarchietiefe, Kategorienamen, Keywordzuordnung, Reihenfolge, Magazinstruktur oder mögliche Beitragsarten. Diese Entscheidungen trifft das System automatisch nach den verbindlichen Regeln.

### 16.2 Automatisch erzeugtes fachliches Ergebnis

Nach Eingabe des Hauptthemas entwickelt das System intern mehrere mögliche Gesamtstrukturen, prüft, bereinigt und bewertet sie und legt grundsätzlich nur den besten bestandenen Gesamtvorschlag vor.

Das verbindliche fachliche Ergebnis umfasst:

- Content-Hierarchie;
- Marketplace-/Anzeigenmarkt-Hierarchie;
- Magazin-/Journal-Struktur;
- fachliche Blockzuordnung;
- Keywordhierarchie und Keyword-Eigentümerschaft bis zur untersten Kategorieebene;
- eindeutige Eltern-Kind-Zuordnung;
- kurze, eindeutige Kategorienamen;
- Kennzeichnung der beitragstragenden Endkategorien;
- fachliche Ein- und Ausschlüsse je Kategorie;
- Import- und Freigabestatus.

Das sichtbare Ergebnis ist kein ungeprüfter Rohentwurf, sondern ein intern geprüfter, verständlich dargestellter und bearbeitbarer Gesamtvorschlag. Nach Nutzeränderungen wird die Gesamtstruktur erneut automatisch geprüft.

### 16.3 Abgrenzung zum Designplugin

Das Kategoriesystem definiert keine verbindliche sichtbare Gestaltung. Menüdarstellung, Kachelform, Hubseitenlayout, visuelle Reihenfolge, Hervorhebungen und sonstige Designentscheidungen liegen beim separaten Designplugin.

Das Kategoriesystem darf hierfür ausschließlich unverbindliche Vorschläge und geeignete Metadaten liefern. Verbindlich bleiben nur:

- fachliche Hierarchie;
- Blockzuordnung;
- Keywordhierarchie und Keyword-Eigentümerschaft;
- Eltern-Kind-Beziehungen;
- beitragstragende Endkategorien;
- technische Importzuordnung;
- die in R-016 und R-097 definierte vollständige Erreichbarkeit aller aktiven Kategorien als Schnittstellenanforderung.

Die konkrete visuelle und navigative Umsetzung dieser Erreichbarkeit bleibt vollständig beim Designplugin.

### 16.4 Allgemeingültiges Beitragsartenmodell

Beitragsarten sind keine Kategorien und kein Bestandteil der verbindlichen Kategoriehierarchie. Sie beschreiben den Zweck und die Grundfunktion möglicher Beiträge.

Als derzeit bekannte allgemeingültige Grundtypen gelten insbesondere:

- FAQ;
- Beratung;
- Vergleich;
- Anleitung;
- Pflege und Wartung;
- Problemlösung;
- Hintergrund;
- Checkliste.

Diese Liste ist ausdrücklich offen und nicht abschließend. Weitere Beitragsarten dürfen automatisch erkannt und unverbindlich vorgeschlagen werden, wenn sie:

- themenübergreifend sinnvoll definierbar sind;
- eine eigene Such- und Nutzerintention besitzen;
- von bestehenden Beitragsarten klar abgrenzbar sind;
- nicht nur eine sprachliche Variante eines bestehenden Typs darstellen;
- ausreichend eigenständiges Themenpotenzial besitzen.

Jeder konkrete Beitrag besitzt später genau einen Haupttyp. Ergänzende Elemente anderer Typen sind zulässig, begründen aber keinen zweiten Beitrag und keine doppelte Planung.

### 16.5 Tragfähigkeitsregel für Beitragsarten

Eine Beitragsart wird für eine unterste Kategorie nur vorgeschlagen, wenn sich daraus ausreichend viele eigenständige, nicht doppelte Beiträge ableiten lassen. Als konfigurierbare Standard-Mindestorientierung gelten vier tragfähige Beiträge je Beitragsart und Endkategorie.

Dabei gilt:

- keine bloßen Titelvarianten;
- keine identische Suchintention in mehreren Beitragsarten;
- keine künstliche Aufspaltung eines zusammengehörigen Themas;
- keine Pflichtbesetzung jeder Endkategorie mit denselben Beitragsarten;
- keine Beitragsart nur zur optischen oder zahlenmäßigen Vollständigkeit.

Erreicht eine Beitragsart das notwendige Potenzial nicht, wird sie für diese Kategorie nicht vorgeschlagen. Dies ist keine dauerhafte Sperre; sie darf bei verändertem Themenstand später erneut geprüft werden.

Der Standardwert vier darf projektbezogen begründet angepasst werden. Eine Abweichung muss dokumentiert werden. Die fachliche Eigenständigkeit und Überschneidungsfreiheit haben immer Vorrang; der Wert darf weder künstliche Beiträge erzeugen noch tragfähige Sonderfälle automatisch ausschließen.

### 16.6 Zeitpunkt der Beitragsartenvorschläge

Beitragsarten dürfen erst geprüft und vorgeschlagen werden, wenn:

- die verbindliche Kategoriehierarchie vollständig ist;
- die untersten beitragstragenden Kategorien eindeutig feststehen;
- Blockzuordnung und Keyword-Eigentümerschaft geklärt sind;
- keine offenen Strukturkonflikte bestehen.

Dadurch dürfen Beitragsideen die fachliche Kategoriehierarchie nicht rückwirkend künstlich formen oder aufblähen.

### 16.7 Verbindliche Zuständigkeitsgrenze zum Textplugin

Das Kategoriesystem ist verbindlich zuständig für:

- Kategorien und Hierarchie;
- Blockzuordnung;
- Keyword-Eigentümerschaft auf Kategorieebene;
- Themenrahmen sowie Ein- und Ausschlüsse der Endkategorien;
- unverbindliche Vorschläge fachlich geeigneter Beitragsarten;
- sichere, maschinenlesbare Übergabe an das Textplugin.

Das Textplugin ist allein zuständig für:

- konkrete Beitragsideen und Longtail-Keywords;
- endgültige Beitragstitel;
- Redaktions- und Produktionsplanung;
- Prüfung des vorhandenen Beitragsbestands;
- Dubletten- und Kannibalisierungsprüfung auf Beitragsebene;
- endgültige Auswahl der Beitragsart;
- Inhaltserstellung, Validierung, Speicherung und Veröffentlichung.

Das Kategoriesystem darf keine konkrete Artikelplanung und keine Produktionslogik des Textplugins nachbauen. Seine Prüfung beschränkt sich auf das abstrakte Potenzial einer Beitragsart innerhalb des verbindlichen Kategorienrahmens.

### 16.8 Erkenntnisse aus TEXTMASTER 0185

Der geprüfte Zwischenstand `TEXTMASTER_0185_NEU_TEIL_B_AKTUELLER_PROJEKTKERN` bestätigt für die aktuelle Schnittstelle:

- Das Textplugin besitzt bereits eigene Artikeltypen-, Suchintentions-, Struktur-, Qualitäts- und Validierungslogik.
- Aktuell technisch und qualitativ abgesichert sind FAQ, Beratung, Vergleich und Pflege.
- Diese vier Typen sind der derzeit unterstützte technische Bestand, aber keine abschließende allgemeingültige Typenliste.
- Weitere fachlich sinnvolle Beitragsarten dürfen im Kategoriesystem erkannt und vorgeschlagen werden, auch wenn das Textplugin sie noch nicht unterstützt.
- Eine nicht unterstützte Beitragsart darf nicht künstlich in FAQ, Beratung, Vergleich oder Pflege umgewandelt werden.

Für jede vorgeschlagene Beitragsart sind daher zwei getrennte Bewertungen erforderlich:

1. fachlich geeignet oder nicht geeignet;
2. vom aktuellen Textplugin unterstützt oder noch nicht unterstützt.

Eine fachlich geeignete, technisch noch nicht unterstützte Beitragsart bleibt als Zukunftsvorschlag erhalten, löst aber keinen Produktionsauftrag aus.

### 16.9 Unverbindlichkeit und späterer Statuswechsel

Beitragsartenvorschläge bleiben im Kategoriesystem unverbindlich. Sie:

- reservieren keine Longtail-Keywords;
- erzeugen keine konkreten Beiträge;
- gehören noch nicht zum verbindlichen Redaktionsplan;
- dürfen vom Textplugin übernommen, verändert, zusammengeführt, abgelehnt oder zurückgestellt werden.

Ein Vorschlag kann abhängig vom späteren Pluginmodell nur durch einen klar definierten, protokollierten Freigabe- oder Statuswechsel verbindlich werden. Ein automatischer Wechsel in einen verbindlichen Produktionsauftrag ist unzulässig.

### 16.10 Rückmeldung des Textplugins

Die spätere Schnittstelle soll Rückmeldungen des Textplugins ermöglichen, insbesondere:

- Beitragsart übernommen;
- Beitragsart verworfen;
- zu wenig eigenständiges Potenzial;
- Themen bereits ausreichend abgedeckt;
- neue Beitragsart erkannt;
- Beitragsart technisch noch nicht unterstützt.

Diese Rückmeldung darf die verbindliche Kategoriehierarchie nicht automatisch verändern. Sie dient der Verbesserung künftiger Vorschläge und kann eine erneute fachliche Prüfung auslösen.

### 16.11 Verbindliche Gesamtaussage

Das Kategoriesystem schafft den verbindlichen strukturellen Arbeitsraum bis einschließlich der untersten beitragstragenden Kategorie. Darunter liefert es ausschließlich unverbindliche, fachlich geprüfte Beitragsartenvorschläge. Das Textplugin besitzt die vollständige Hoheit über konkrete Longtails, Beiträge, Redaktionsplanung, Bestandsprüfung und Produktion. Fachliche Eignung und aktuelle technische Unterstützung einer Beitragsart werden strikt getrennt bewertet.

---

## 17. AUTOMATISCHE THEMENANALYSE UND STRUKTURERZEUGUNG

### 17.1 Minimaler Standardstart

Im optimalen Standardfall gibt der Nutzer ausschließlich das Hauptthema vor. Sprache wird aus der Eingabe übernommen. Weitere Angaben dürfen nur verlangt werden, wenn ohne sie mehrere grundlegend verschiedene Portalmodelle gleichwertig möglich wären.

Nicht standardmäßig abzufragen sind insbesondere Anzahl der Hauptkategorien, Ebenentiefe, Kategorienamen, Sortierung, Magazinrubriken, Filter, Beitragsarten oder Navigationsumfang. Diese Entscheidungen trifft das System eigenständig nach dem Regelwerk.

### 17.2 Themenraum vor Kategorien

Das System erzeugt nicht sofort Kategorien aus einzelnen Keywords. Es erschließt zuerst den Themenraum anhand von:

- Fachlogik;
- Nutzerbedürfnissen;
- Informations-, Entscheidungs- und Marktintentionen;
- Produkten, Leistungen und Anbieterarten, sofern das Thema sie tatsächlich trägt;
- Synonymen, Ober- und Unterbegriffen;
- dauerhaftem redaktionellem Potenzial;
- natürlichen fachlichen Abgrenzungen.

Es darf keine universellen Inhaltsbereiche voraussetzen. Nicht jedes Thema benötigt Produkte, Dienstleistungen, Recht, Gesundheit, Kaufberatung oder einen Marktplatz.

### 17.3 Quellenbasierte Absicherung

Die Themenanalyse darf nicht allein auf Modellwissen beruhen. Mehrere geeignete, möglichst unabhängige Quellen und Perspektiven werden zur fachlichen Absicherung genutzt. Externe Strukturen dienen ausschließlich als Hinweise und dürfen nicht kopiert oder als alleinige Systematik übernommen werden.

Fachlogik, Nutzerlogik, Suchintention, redaktionelles Potenzial und gegebenenfalls Marktlogik werden getrennt bewertet. Suchvolumen darf priorisieren, aber weder Kategorieexistenz noch Hierarchie allein bestimmen.

### 17.4 Interne Variantenbildung

Das System entwickelt intern mehrere mögliche Gesamtmodelle, ohne dem Nutzer Rohvarianten aufzubürden. Jeder Entwurf wird automatisch bereinigt, insbesondere hinsichtlich:

- Synonymen und Dubletten;
- unnötig langen Kategorienamen;
- künstlichen Zwischenebenen;
- vermischten Ordnungskriterien;
- fälschlich als Kategorie behandelten Beitragsideen;
- fehlenden Kernbereichen;
- unklarer Blocktrennung;
- zu schwachen oder überladenen Kategorien.

Standardmäßig wird nur der bestbewertete bestandene Gesamtvorschlag ausgegeben. Alternativen werden nur bei echten gleichwertigen Grundsatzmodellen gezeigt.

### 17.5 Qualitätsauswahl

Die interne Auswahl bewertet mindestens:

- Allgemeingültigkeit;
- fachliche Vollständigkeit der Kernstruktur;
- Keywordhierarchie;
- klare Blocktrennung;
- trennscharfe Eltern-Kind- und Geschwisterbeziehungen;
- Kürze und Eindeutigkeit der Kategorienamen;
- ausreichende Tragfähigkeit;
- sinnvolle, nicht künstliche Tiefe;
- Erweiterbarkeit;
- technische Importierbarkeit;
- geringe Überschneidung und geringe spätere Umbauanfälligkeit.

Eine Struktur gilt nicht deshalb als vollständig, weil jedes denkbare Randthema aufgenommen wurde. Vollständig ist eine logisch geschlossene, tragfähige Kernstruktur mit vorbereiteten Erweiterungsmöglichkeiten.

### 17.6 Priorisierung

Kategorien werden als Kernbereich, wichtiger Ergänzungsbereich, späterer Ausbau oder Randthema bewertet. Der erste freigabefähige Stand enthält alle unverzichtbaren Hauptbereiche und vollständige Elternketten, aber keine unnötige Randthemen-Aufblähung.

Priorisierung erfolgt je Block nach dessen Funktion und nie ausschließlich nach Suchvolumen.

### 17.7 Sichtbares Nutzerergebnis

Der Nutzer erhält einen intern geprüften, verständlich dargestellten und bearbeitbaren Gesamtvorschlag mit:

- verbindlich vorgeschlagener Content-Hierarchie;
- verbindlich vorgeschlagener Marktplatz-Hierarchie;
- verbindlich vorgeschlagener Magazin-/Journal-Struktur;
- Keyword- und Blockzuordnung;
- Kennzeichnung der untersten beitragstragenden Contentkategorien;
- unverbindlichen Vorschlägen zu Beitragsarten;
- echten offenen Grundsatzfragen und Konflikten;
- Freigabestatus.

Darstellungs-, Menü-, Kachel- und Hubdesign bleiben unverbindliche Vorschläge und fallen in die Zuständigkeit des Designplugins.

### 17.8 Änderungen durch den Nutzer

Nach Nutzeränderungen wird nicht nur der geänderte Knoten, sondern die gesamte betroffene Struktur erneut geprüft. Automatische Korrekturen sind bis zur fachlichen Freigabe zulässig. Nach der Freigabe werden nur noch Änderungsvorschläge erzeugt.

---

## 18. PRÜF-, GEGENPRÜF- UND RÜCKKOPPLUNGSINSTANZEN

### 18.1 Erzeugungsinstanz

Erstellt aus dem Hauptthema mehrere vollständige Strukturentwürfe für alle Portalblöcke und wendet die festgelegten Regeln an.

### 18.2 Interne Prüfinstanz

Prüft jeden Entwurf automatisiert auf Vollständigkeit, Allgemeingültigkeit, Hierarchie, Kürze, Dubletten, Blocktrennung, Tragfähigkeit, Beitragsartengrenzen und Importierbarkeit.

Ein nicht bestandener Entwurf darf dem Nutzer nicht als Hauptvorschlag gezeigt werden.

### 18.3 Unabhängige Gegenprüfinstanz

Eine logisch getrennte Prüfinstanz sucht gezielt nach:

- fehlenden Kernbereichen;
- verdeckten Überschneidungen;
- falschen Keyword-Eigentümern;
- unnötigen Kategorien oder Ebenen;
- falscher Blockzuordnung;
- themenspezifischen Annahmen im allgemeinen Regelkern;
- unerwünschter Aufgabenüberschneidung mit Text- oder Designplugin;
- Risiken des späteren Imports.

Sie darf den Entwurf nicht stillschweigend umschreiben, sondern liefert prüfbare Befunde an die Korrekturschleife.

### 18.4 Begrenzte Korrekturschleife

Erkannte Pflichtfehler werden automatisch korrigiert und erneut geprüft. Die Schleife endet, sobald:

- alle Pflichtprüfungen bestanden sind;
- kein `BLOCKED`-Befund verbleibt;
- die Gegenprüfinstanz keine wesentlichen Fehler mehr findet;
- verbleibende Hinweise nur optionale Optimierungen betreffen.

Es gibt keine endlose Optimierung. Optionale Verbesserungen verhindern die Ausgabe nicht.

Die Zahl automatischer Korrekturdurchläufe ist konfigurierbar und besitzt einen verbindlichen Standardgrenzwert. Wird innerhalb dieser Grenze kein konvergenter, regelkonformer Stand erreicht oder wiederholen sich dieselben Konflikte zyklisch, endet der Lauf mit `BLOCKED_NO_CONVERGENCE`. Die verbliebenen Konflikte, die letzten Änderungen und die betroffenen Regeln werden nachvollziehbar ausgegeben. Eine weitere automatische Schleife ist ohne neue Eingabe oder ausdrückliche Freigabe unzulässig.

### 18.5 WordPress-Testinstanz

Vor einer Importfreigabe wird die freigegebene Struktur auf einer separaten WordPress-Testinstanz geprüft. Sie dient mindestens:

- Environment-Inventur;
- rein lesender Importvorschau;
- Positiv- und Negativtests;
- korrekter Block-, Ziel-, Ebenen- und Elternzuordnung;
- Prüfung der beitragstragenden Endkategorien;
- Wiederholungsimport ohne Dubletten;
- Konflikt-, Sicherungs- und Rollbacktests.

Die Testinstanz ist ein zwingendes Freigabe-Gate. Ein bestandener interner Konzepttest ersetzt den technischen Test nicht.

### 18.6 Rückkopplungsinstanz im laufenden Betrieb

Nach der Umsetzung können Textplugin, Marktplatz, Designplugin sowie Nutzungs- und Suchdaten strukturierte Rückmeldungen liefern.

Beispiele:

- zu wenig eigenständiges Beitragspotenzial;
- häufige Anzeigen-Fehlzuordnungen;
- wachsende neue Themenräume;
- dauerhaft leere Kategorien;
- unübersichtliche sichtbare Navigation;
- neue fachlich geeignete Beitragsarten.

Diese Rückmeldungen erzeugen ausschließlich begründete Verbesserungsvorschläge. Nach Freigabe darf keine Instanz selbstständig Kategorien anlegen, verschieben, zusammenführen, löschen oder Keyword-Eigentümerschaften ändern.

### 18.7 Konfliktpriorität

Bei widersprüchlichen Anforderungen gilt grundsätzlich:

1. fachliche Richtigkeit;
2. eindeutige Nutzer- und Suchintention;
3. Keyword-Eigentümerschaft und Blocktrennung;
4. technische Funktionsfähigkeit und Datensicherheit;
5. größtmögliche Automatisierung;
6. sichtbare Darstellung und Design.

Ein Designproblem darf die fachliche Struktur nicht automatisch verändern. Es löst zunächst einen Darstellungs- oder Navigationsvorschlag aus.

---

## 19. ABSCHLIESSENDER GESAMTWORKFLOW

### Phase 1 – Minimale Eingabe

Der Nutzer gibt standardmäßig nur das Hauptthema vor. Nur echte Grundsatzmehrdeutigkeiten lösen höchstens eine gebündelte Rückfrage aus.

### Phase 2 – Recherche und Themenraummodell

Das System recherchiert, normalisiert Begriffe, trennt Suchintentionen und erstellt einen allgemeinen Themenraum ohne bereits voreilig Kategorien festzulegen.

### Phase 3 – Interne Strukturmodelle

Mehrere mögliche Modelle für Content, Marktplatz, Magazin/Journal und Glossar werden erzeugt. Mögliche Beitragsarten werden davon getrennt betrachtet.

### Phase 4 – Selbstprüfung, Gegenprüfung und Korrektur

Alle Pflichtregeln werden automatisiert geprüft. Fehler werden korrigiert. Nur der beste bestandene Entwurf gelangt zur Nutzerprüfung.

### Phase 5 – Fachlicher Gesamtvorschlag

Der Nutzer erhält die vollständige fachliche Struktur mit kurzen Kategorienamen, Keyword-Eigentümerschaft, Blockzuordnung, Endkategorien und unverbindlichen Beitragsartenvorschlägen.

### Phase 6 – Fachliche Freigabe

Nach Nutzeränderungen erfolgt eine erneute Gesamtprüfung. Die Freigabe macht die Kategorienstruktur verbindlich, nicht jedoch Beitragsvorschläge oder Designvorschläge.

### Phase 7 – Technische Inventur und Trockenlauf

Die Testinstanz wird ausgelesen. Zieltypen, vorhandene Strukturen und Konflikte werden geprüft. Die erste Pluginstufe bleibt rein lesend.

### Phase 8 – Technischer Testimport

Nach bestandener Vorschau wird auf der Testinstanz kontrolliert geschrieben. Positiv-, Negativ-, Wiederholungs-, Sicherungs- und Rollbacktests müssen bestehen.

### Phase 9 – Importfreigabe

Erst nach bestandenem Test wird das konkrete Importpaket freigegeben. Der spätere Ein-Klick-Import bleibt ein kontrollierter Ablauf mit Vorschau, Sicherung und Protokoll.

### Phase 10 – Übergabe an Folgesysteme

- Das Textplugin erhält Endkategorien, Themenrahmen, Keywordgrenzen und unverbindliche Beitragsartenvorschläge.
- Das Designplugin erhält Struktur- und Sichtbarkeitsmetadaten sowie unverbindliche Darstellungsvorschläge.
- HivePress erhält ausschließlich freigegebene Marktplatzkategorien und geeignete Zuordnungen.

### Phase 11 – Laufende Rückkopplung

Folgesysteme liefern Befunde. Das Kategoriesystem bewertet sie und erzeugt gegebenenfalls Änderungsvorschläge. Verbindliche Strukturänderungen erfordern erneut Prüfung, Test und Freigabe.

---

## 20. ABSCHLUSS DER GRUNDKONZEPTION

Die Grundkonzeption bleibt abgeschlossen. Weitere theoretische Regelblöcke werden nicht ohne konkreten Prüf- oder Testbefund eröffnet.

Abgeschlossen sind insbesondere:

- oberste Grundregeln Allgemeingültigkeit und größtmögliche Automatisierung;
- Zuständigkeit und Trennung der Portalblöcke;
- Keyword-, Hierarchie-, ID-, Import-, Synchronisations- und Freigabelogik;
- zwingende beitragstragende WordPress-Endkategorie;
- Abgrenzung zu Text- und Designplugin;
- offenes Beitragsartenmodell;
- interne Prüf-, Gegenprüf- und Korrekturlogik;
- WordPress-Testinstanz und Rückkopplungsmodell;
- abschließender Gesamtworkflow;
- unabhängige Claude-Gesamtprüfung und deren bestätigte Korrekturen.

---

## 21. ABGESCHLOSSENE REIN LESENDE TESTPHASE

Das Pferde-Atelier wurde ausschließlich als reales Referenz- und Härtungsobjekt verwendet. Sämtliche eingesetzten Prüfplugins waren rein lesend. Es wurden weder Kategorien noch Beiträge, Seiten, Menüs, Elternbeziehungen, Slugs, Taxonomien oder HivePress-Daten angelegt, verändert, verschoben oder gelöscht.

### 21.1 Technisch bestätigter Bestand

Die Gesamtinventur hat folgenden Ist-Zustand bestätigt:

- WordPress-Taxonomie `category`: 1.133 Kategorien;
- sämtliche 1.133 WordPress-Kategorien liegen aktuell auf der Wurzelebene;
- maximale WordPress-Kategorietiefe: 1;
- 931 Kategorien wurden anhand ihrer Bezeichnung als Beitragsart-Kategorien erkannt;
- 45 mögliche normalisierte Namensdubletten;
- keine doppelten Slugs;
- keine verwaisten Elternbezüge;
- HivePress-Taxonomie `hp_listing_category`: 95 Kategorien;
- davon 10 Wurzelkategorien;
- maximale HivePress-Tiefe: 2;
- HivePress-Zieltypen und Taxonomien wurden eindeutig erkannt.

### 21.2 Konzeptioneller Hauptbefund

Der vorhandene WordPress-Bestand bildet überwiegend die bisherige Beitragsartenlogik des Textsystems ab und noch keine fachliche, mehrstufige Content-Hierarchie.

Dieser Befund bestätigt die Projektabgrenzung:

- Das Kategoriesystem entwickelt die verbindliche fachliche Struktur bis zur untersten beitragstragenden Kategorie.
- Das Textplugin bleibt für konkrete Longtail-Beiträge, Titel, Redaktionsplanung, Dublettenprüfung und Inhaltserstellung zuständig.
- Bestehende Beitragsart-Kategorien dürfen nicht ungeprüft als fachliche Endkategorien übernommen werden.
- Der reale Bestand darf bis zu einer ausdrücklich freigegebenen späteren Testimportphase nicht verändert werden.

### 21.3 Geprüfte Vorschaufälle

Die rein lesenden Vorschautests haben korrekt erkannt:

- fehlende geplante Elternknoten;
- bestehende Kindkategorien auf abweichender Ebene;
- bestehende HivePress-Kategorien mit abweichender Elternzuordnung;
- vorhandene und nicht vorhandene Zielobjekte;
- blockbezogene Zielzuordnung zu WordPress und HivePress;
- Konflikte ohne jeglichen Schreibzugriff.

### 21.4 Sicherheitsstatus

Alle erzeugten Berichte bestätigen:

- `writes_performed = false`
- `database_schema_changed = false`
- `terms_changed = false`
- `menus_changed = false`
- `content_changed = false`
- `external_requests = false`

---

## 22. PLUGINBESTAND UND STATUS

Alle bisher erzeugten Prüfplugins sind in dieser Master-ZIP enthalten.

### 22.1 `KATEGORIE_INVENTUR_LESEND_V0.1.0.zip`

**Zweck:** Erste rein lesende technische Inventur von WordPress, Plugins, Post-Types, Taxonomien, Menüs und HivePress-Signalen.

**Status:** erfolgreich eingesetzt; funktional erfüllt; durch den Gesamtprüfer für weitere Standardtests abgelöst.

### 22.2 `KATEGORIE_STRUKTUR_VORSCHAU_LESEND_V0.2.0.zip`

**Zweck:** Erste allgemeingültige Strukturpaket-Vorschau mit Block- und Zielzuordnung.

**Status:** historischer Entwicklungsstand; nicht mehr für neue Tests verwenden.

### 22.3 `KATEGORIE_STRUKTUR_VORSCHAU_LESEND_V0.3.0.zip`

**Zweck:** Erweiterung um Elternvergleich.

**Status:** historischer Entwicklungsstand; enthielt eine unvollständige Bewertung bei noch nicht existierendem geplantem Elternknoten; nicht mehr verwenden.

### 22.4 `KATEGORIE_STRUKTUR_VORSCHAU_LESEND_V0.4.0.zip`

**Zweck:** Korrigierte rein lesende Eltern- und Konfliktprüfung.

**Status:** erfolgreich eingesetzt; für den konkreten Vorschautest korrekt; durch den gebündelten Gesamtprüfer abgelöst.

### 22.5 `KATEGORIE_GESAMTPRUEFER_LESEND_V1.0.0.zip`

**Zweck:** Gebündelte rein lesende Prüfung des realen Bestands, einschließlich Hierarchietiefe, Beitragsart-Erkennung, möglicher Namensdubletten, Slugkonflikte und Elternbezüge.

**Status:** aktuell maßgeblicher rein lesender Prüfstand; Test erfolgreich abgeschlossen. Vorläufig keine weitere Installation erforderlich.

### 22.6 Verbindliche Nutzungsregel

Historische Pluginversionen bleiben ausschließlich als Entwicklungs- und Evidenzbestand erhalten. Sie dürfen nicht erneut installiert werden, sofern ein späterer ausdrücklich freigegebener Testschritt dies nicht zwingend verlangt.

---

## 23. GEBÜNDELTER NÄCHSTER ARBEITSBLOCK

Der nächste Arbeitsblock findet zunächst vollständig außerhalb des produktiven Pferdeportals statt.

Er umfasst gebündelt:

1. fachliche Auswertung des realen Bestands;
2. Trennung von Beitragsart-Kategorien und echten Fachkategorien;
3. Entwicklung eines allgemeinen Sollstruktur-Modells;
4. Erzeugung einer reinen Konflikt- und Migrationsvorschau;
5. Prüfung der Schnittstelle zum Textplugin;
6. Vorbereitung eines späteren, weiterhin kontrollierten Testplans.

Es wird nicht nach jedem kleinen technischen Befund eine neue Pluginversion ausgegeben. Mehrere zusammengehörige Korrekturen und Prüfungen werden intern gebündelt.

---

## 24. NÄCHSTER ZULÄSSIGER SCHRITT

**Erstellung einer rein externen Sollstruktur- und Konfliktanalyse auf Basis des ausgelesenen Pferdeportal-Bestands, ohne Installation eines weiteren Plugins und ohne Veränderung des bestehenden Portals.**

Erst wenn dieser größere Analyseblock vollständig abgeschlossen und fachlich geprüft ist, darf entschieden werden, ob ein weiterer gebündelter rein lesender Testlauf notwendig ist.

Schreibende Pluginfunktionen, Testimporte oder Änderungen am Pferdeportal sind weiterhin ausdrücklich nicht freigegeben.

---

## 25. Änderungshistorie

### NEU 011 – 26.07.2026

- rein lesende technische Inventur des Pferdeportals abgeschlossen;
- WordPress-, HivePress-, Taxonomie-, Hierarchie- und Beitragsartenbestand dokumentiert;
- 1.133 flache WordPress-Kategorien, 931 erkannte Beitragsart-Kategorien und 95 HivePress-Kategorien als realen Ist-Stand festgehalten;
- Sicherheitsnachweis aller Testläufe dokumentiert;
- sämtliche bisher erzeugten Prüfplugins vollständig in die Master-ZIP aufgenommen;
- Pluginstatus und Ablösungskette verbindlich dokumentiert;
- historische Pluginversionen ausdrücklich von erneuter Verwendung ausgeschlossen;
- reale Vorschau- und Konfliktberichte als Evidenzbestand aufgenommen;
- kleinteilige Plugin-Installationsfolge beendet;
- nächsten zulässigen Schritt auf externe Sollstruktur- und Konfliktanalyse ohne Portaländerung gesetzt.

### NEU 010 – 26.07.2026

- unabhängige Claude-Gesamtprüfung kritisch gegengeprüft und berechtigte Befunde übernommen
- widersprüchliches sprechendes ID-Beispiel durch opakes Identitätstoken ersetzt
- klare Konvergenzgrenze mit `BLOCKED_NO_CONVERGENCE` ergänzt
- Modellbezeichnung auf drei Portalhauptblöcke plus eigenständige Glossarfunktion beziehungsweise Vier-Funktionsblock-Modell vereinheitlicht
- vollständige Erreichbarkeit als verbindliche Schnittstellenanforderung an das Designplugin präzisiert
- starre und konfigurierbare Schwellenwerte klar getrennt
- doppelte Regeln zu Idempotenz, Bestandsabgleich und Erreichbarkeit auf kanonische Regeln zurückgeführt
- mehrsprachige Keyword- und Suchintentionseigentümerschaft geregelt
- Sperre paralleler schreibender Import- und Rollbackläufe ergänzt
- Zuständigkeit für einzelne Glossardefinitionen dem nachgelagerten Text-/Contentsystem zugewiesen
- bewusst begrenzte Rollback-Reichweite ausdrücklich dokumentiert
- nächsten zulässigen Schritt auf technische Inventur der WordPress-Testinstanz gesetzt

### Vorherige Fassungen

Die vollständige Historie der Fassungen NEU 001 bis NEU 009 ist in den Vorgängerfassungen dokumentiert und bleibt durch den vollständigen Regelbestand dieser Datei sachlich erhalten.

---

## 26. EXTERNE SOLLSTRUKTUR- UND KONFLIKTANALYSE

Die externe Auswertung des vollständigen WordPress-Kategoriebestands ist abgeschlossen.

### 26.1 Quantitativer Befund

- 1.133 WordPress-Kategorien insgesamt;
- 1.124 davon sind Beitragsart-Kategorien;
- zehn erkannte Beitragsarten;
- 240 daraus extrahierte Fachthemenkandidaten;
- acht eigenständige Magazin-Hauptkategorien;
- 45 normalisierte Namensdubletten-Gruppen;
- 95 separat zu behandelnde HivePress-Kategorien.

### 26.2 Verbindliche Bewertung

Die bestehende flache Beitragsartenstruktur ist keine zulässige fachliche Sollhierarchie.

FAQ, Beratung, Vergleich, Pflege, Sicherheit, Anwendung, Kosten, Installation, Lagerung und Übungen sind redaktionelle beziehungsweise funktionale Beitragsarten. Sie werden künftig nicht als Ersatz für Fachkategorien behandelt.

Die 240 extrahierten Fachthemen sind ausschließlich Kandidaten. Ihre endgültige Einordnung muss gegen die verbindliche Backend-Navigationsquelle geprüft werden.

### 26.3 Sicherheitsstatus

Für diesen Arbeitsschritt:

- kein Plugin installiert;
- kein Plugin ausgeführt;
- keine Verbindung zum Portal;
- keine Kategorien verändert;
- keine Inhalte verändert;
- keine Menüs verändert;
- keine HivePress-Daten verändert.

### 26.4 Neue Analysedateien

Die vollständige Master-ZIP enthält zusätzlich:

- `ANALYSE/SOLLSTRUKTUR_UND_KONFLIKTANALYSE_001.md`
- `ANALYSE/FACHTHEMENKANDIDATEN_240.csv`
- `ANALYSE/SOLLSTRUKTUR_ANALYSE_001.json`

---

## 27. NÄCHSTER ZULÄSSIGER SCHRITT

Erstellung einer externen Fachthemen-Zuordnungsmatrix für alle 240 Kandidaten.

Jeder Kandidat erhält:

- vorhandene Beitragsarten;
- vorhandene Beitragsanzahl;
- möglichen Navigationspfad;
- Konflikt- und Dublettenstatus;
- Entscheidung, ob er Fachkategorie, redaktionelles Thema oder nicht zuordenbar ist.

Die bestehende Backend-Navigationskonfiguration bleibt die verbindliche Quelle. Ohne deren vollständigen maschinenlesbaren Export darf keine endgültige Hierarchie festgelegt und kein Schreibimport vorbereitet werden.

---

## 28. Änderungshistorie

### NEU 012 – 26.07.2026

- vollständigen WordPress-Kategoriebestand extern ausgewertet;
- 1.124 Beitragsart-Kategorien identifiziert;
- zehn Beitragsarten getrennt erfasst;
- 240 Fachthemenkandidaten extrahiert;
- acht Magazin-Hauptkategorien separat erkannt;
- 45 Dublettengruppen in die Konfliktanalyse übernommen;
- Sollstruktur- und Konfliktanalyse erstellt;
- maschinenlesbare Analyse und vollständige Kandidatenliste ergänzt;
- bestätigt, dass für diesen Schritt kein weiteres Plugin und keine Portaländerung erforderlich war;
- nächsten zulässigen Schritt auf externe Fachthemen-Zuordnungsmatrix gesetzt.

---

## 29. VERBINDLICHE DATEIAUSGABE-REGEL

Ab dieser Fassung gilt verbindlich:

- Ausgegeben wird nur die Datei, die der Nutzer tatsächlich weiterverarbeiten, hochladen oder als aktuellen Übergabestand sichern muss.
- Analysen, Sollstrukturen, Konfliktlisten, Prüfergebnisse und Zwischenstände werden vollständig in die aktuelle Master-ZIP integriert.
- Keine zusätzlichen Nebenpakete oder separaten Analyse-ZIPs, wenn sie nicht unmittelbar benötigt werden.
- Die aktuelle Master-ZIP bleibt der einzige verbindliche Übergabestand.

Die Sollstruktur- und Konfliktanalyse ist vollständig innerhalb dieser Master-ZIP unter `ANALYSE/` enthalten.

---

## 30. Änderungshistorie

### NEU 013 – 26.07.2026

- verbindliche Dateiausgabe-Regel ergänzt;
- separate Bereitstellung der Sollstruktur-Analyse aufgehoben;
- Sollstruktur, Konfliktanalyse und Fachthemenkandidaten ausschließlich in die Master-ZIP integriert;
- Master-ZIP als einzigen verbindlichen Übergabestand festgelegt.

---

## 31. FACHTHEMEN-ZUORDNUNGSMATRIX ABGESCHLOSSEN

Alle 240 aus dem realen WordPress-Bestand extrahierten Fachthemenkandidaten wurden vollständig in einer externen Zuordnungsmatrix erfasst.

Für jeden Kandidaten enthält die Matrix:

- vorhandene Beitragsarten;
- Anzahl der Beitragsart-Kategorien;
- Anzahl bereits vorhandener Beiträge;
- Dublettenhinweise;
- möglichen Navigationspfad;
- Zielrolle;
- Freigabestatus.

### 31.1 Statusverteilung

- `OFFEN_NAVIGATION`: 222
- `KONFLIKT`: 7
- `DUBLETTE`: 11

### 31.2 Verbindliche Bewertung

Die fachliche Kandidatenmenge ist vollständig aufbereitet.

Eine endgültige Zuordnung in die Portalhierarchie ist nicht zulässig, solange die im Backend des Designplugins verwaltete Navigationskonfiguration nicht vollständig maschinenlesbar vorliegt.

Die Navigation bleibt die verbindliche Quelle. Es wurde keine Kategorie, kein Beitrag, kein Menü und keine HivePress-Struktur verändert.

### 31.3 Integrierte Dateien

- `ANALYSE/FACHTHEMEN_ZUORDNUNGSMATRIX_240.md`
- `ANALYSE/FACHTHEMEN_ZUORDNUNGSMATRIX_240.csv`
- `ANALYSE/FACHTHEMEN_ZUORDNUNGSMATRIX_240.json`

---

## 32. NÄCHSTER ZULÄSSIGER SCHRITT

Beschaffung beziehungsweise Erstellung eines vollständigen maschinenlesbaren Exports der verbindlichen Backend-Navigationskonfiguration des Designplugins.

Dieser Schritt muss zunächst rein lesend erfolgen.

Erst danach dürfen die 240 Fachthemenkandidaten automatisch gegen reale Navigationspfade geprüft und mit `PASS`, `KONFLIKT`, `DUBLETTE` oder `NICHT ZUORDENBAR` endgültig bewertet werden.

Bis dahin bleiben sämtliche Kandidaten nicht freigegeben.

---

## 33. Änderungshistorie

### NEU 014 – 26.07.2026

- vollständige Fachthemen-Zuordnungsmatrix für alle 240 Kandidaten erstellt;
- vorhandene Beitragsarten und Beitragszahlen je Fachthema erfasst;
- Dubletten- und Konfliktstatus berechnet;
- endgültige Navigationszuordnung mangels verbindlichem Backend-Export bewusst blockiert;
- Matrix als Markdown, CSV und JSON vollständig in die Master-ZIP integriert;
- keine zusätzliche Datei separat bereitgestellt;
- nächsten zulässigen Schritt auf rein lesenden Navigationskonfigurations-Export gesetzt.

---

## 34. HARTE ABSCHLUSSPRÜFUNG DER NAVIGATIONSQUELLEN

Der vollständige Zuordnungsblock wurde bis zur belastbaren Entscheidungsgrenze geprüft.

### 34.1 Festgestellte Quellen

Es liegen mindestens zwei voneinander abweichende Hierarchiestände vor:

1. `01_v8_hierarchie_exakt.csv`
   - sechs Hauptbereiche;
   - 36 Hubbereiche;
   - Ebene 3 als Keyword-Kategorie;
   - Ebene 4 als Intent-Kategorie.

2. `01_finale_seiten_hierarchie_ebene_1_3.csv`
   - acht Haupt-Hubs;
   - 396 Seiten, Hubs und Produktseiten;
   - 329 Produktseiten;
   - separate frühere Ebene-4-Datei mit 1.124 Kategorien;
   - 78 Produktseiten ohne Themenebene;
   - bekannte semantische Dublette bei `Weidezaungeräte`.

Diese Quellen sind nicht identisch und dürfen nicht vermischt werden.

### 34.2 Verbindliche Bewertung

Die bisherige Annahme, eine der vorhandenen Strukturdateien könne ohne weitere Quellenklärung als aktuelle verbindliche Backend-Navigation verwendet werden, ist verworfen.

Die im Backend des Designplugins gespeicherte aktuelle Navigation bleibt die einzige verbindliche Quelle.

Solange deren vollständiger aktueller Export nicht vorliegt, gilt:

- keine automatische endgültige Zuordnung der 240 Fachthemenkandidaten;
- keine Freigabe einer Sollhierarchie;
- keine Migrationsplanung;
- keine Importvorbereitung;
- keine Änderungen am Pferdeportal.

### 34.3 Harte Ergebnisstatus

- Fachthemenextraktion: `PASS`
- Trennung Fachthema / Beitragsart: `PASS`
- Magazinabgrenzung: `PASS`
- HivePress-Abgrenzung: `PASS`
- historische Quellenprüfung: `PASS`
- aktuelle verbindliche Navigationsquelle: `BLOCKED_SOURCE_MISSING`
- endgültige 240er-Zuordnung: `BLOCKED_SOURCE_CONFLICT`
- Schreibimport: `NOT_AUTHORIZED`

### 34.4 Warum kein Raten zulässig ist

Eine Zuordnung nach bloßer Namensähnlichkeit wäre fachlich unsicher, weil:

- Hauptbereiche zwischen den Quellen unterschiedlich sind;
- Hubbezeichnungen und Slugs abweichen;
- einzelne Fachthemen mehrfach unter verschiedenen Pfaden vorkommen;
- bekannte semantische Dubletten existieren;
- einige Produktseiten ausdrücklich keine zusätzliche Themenebene erhalten sollen;
- die aktuelle Designplugin-Backendkonfiguration laut Projektregel Vorrang hat.

### 34.5 Abgeschlossener Arbeitsblock

Der Analyseblock ist damit vollständig abgeschlossen.

Es gibt keinen weiteren zulässigen fachlichen oder technischen Schritt ohne eine aktuelle, maschinenlesbare Ausgabe der verbindlichen Designplugin-Navigationskonfiguration.

---

## 35. NÄCHSTER ZULÄSSIGER GESAMTSCHRITT

Benötigt wird ausschließlich ein aktueller rein lesender Export der im Designplugin-Backend gespeicherten Navigation mit mindestens:

- eindeutiger Objekt-ID;
- Titel;
- Slug;
- Elternobjekt;
- Ebene;
- Status aktiv/inaktiv;
- Blockzuordnung;
- Sortierung.

Nach Eingang dieser Quelle kann der nächste größere Arbeitsblock vollständig gebündelt ausgeführt werden:

1. Quellvalidierung;
2. Abgleich aller 240 Fachthemen;
3. Dubletten- und Konfliktprüfung;
4. endgültige Zuordnungsmatrix;
5. Sollstruktur;
6. Migrationsvorschau;
7. unabhängige Gegenprüfung;
8. neue vollständige Master-ZIP.

Bis dahin ist keine neue Plugininstallation und keine Portaländerung zulässig.

---

## 36. Änderungshistorie

### NEU 015 – 26.07.2026

- vollständige harte Gegenprüfung der verfügbaren Navigationsquellen abgeschlossen;
- Konflikt zwischen `01_v8_hierarchie_exakt.csv` und `01_finale_seiten_hierarchie_ebene_1_3.csv` festgestellt;
- frühere Annahme einer direkt nutzbaren verbindlichen Strukturquelle verworfen;
- endgültige 240er-Zuordnung fail-closed blockiert;
- aktuellen Designplugin-Backendexport als einzig zulässige fehlende Quelle definiert;
- keine Zuordnungen geraten oder aus bloßer Namensähnlichkeit abgeleitet;
- Schreibimport weiterhin nicht autorisiert;
- Arbeitsblock abgeschlossen und Master aktualisiert.

---

## 37. AKTUELLE VERBINDLICHE NAVIGATIONSQUELLE ERFOLGREICH AUSGELESEN

Der allgemeingültige rein lesende Navigations-Exporter hat den aktuellen realen Navigationsbestand vollständig erfasst.

Bestätigt wurden:

- 412 Seiten insgesamt;
- 410 veröffentlichte Seiten;
- 8 aktive Hubseiten Ebene 1;
- 57 aktive Hubseiten Ebene 2;
- 329 aktive Kategorie-Seiten Ebene 3;
- maximale Seitentiefe 3;
- keine Zyklen;
- keine fehlenden Elternseiten;
- ein vorhandenes kompatibles Designplugin-Signal.

Die Quelle ist themenunabhängig auswertbar. Pferdespezifische Bezeichnungen sind ausschließlich die Inhalte des Testportals, nicht Bestandteil der allgemeinen Systemlogik.

## 38. ENDGÜLTIGER EXAKTABGLEICH DER 240 FACHTHEMENKANDIDATEN

Der Abgleich wurde ausschließlich nach folgenden harten Regeln durchgeführt:

- exakter normalisierter Titel;
- exakter normalisierter Slug;
- keine Fuzzy-Suche;
- keine semantische Vermutung;
- keine manuelle Pfadannahme.

Ergebnis:

- `PASS_EXAKT`: 229
- `NICHT_ZUORDENBAR`: 0
- `KONFLIKT_MEHRFACH`: 11

Nicht exakt belegbare Kandidaten bleiben blockiert und werden nicht geraten.

## 39. ALLGEMEINGÜLTIGE ABLEITUNG

Für jedes beliebige Affiliateportal gilt künftig:

1. Die aktuelle reale Seiten-/Navigationsquelle wird rein lesend exportiert.
2. Fachthemen werden aus bestehendem Contentbestand extrahiert.
3. Fachthemen und Beitragsarten werden getrennt.
4. Eine automatische Zuordnung ist nur bei eindeutigem exaktem Objekt- oder Pfadtreffer zulässig.
5. Unsichere Ähnlichkeit darf höchstens als nicht bindender Prüfhinweis erscheinen.
6. Ohne eindeutige Quelle bleibt der Datensatz blockiert.
7. Das Thema des Portals beeinflusst Inhalte, niemals Prüf-, ID-, Freigabe- oder Importlogik.

## 40. SICHERHEITSSTATUS

- keine Kategorien verändert;
- keine Seiten verändert;
- keine Menüs verändert;
- keine Inhalte verschoben;
- keine HivePress-Strukturen verändert;
- keine schreibende Importfunktion ausgeführt;
- bestehendes Pferdeportal unverändert.

## 41. NÄCHSTER GROSSER ARBEITSBLOCK

Auf Basis der exakt verifizierten Treffer wird außerhalb des Portals ein allgemeingültiges Sollstrukturpaket entwickelt.

Es umfasst gebündelt:

1. freigegebene exakte Fachkategorien;
2. blockierte nicht zuordenbare Kandidaten;
3. separate Beitragsartenklassifikation;
4. Magazin- und Marktplatztrennung;
5. maschinenlesbares allgemeines Importschema;
6. Vorschau-, Konflikt- und Rollbackregeln;
7. unabhängige Gegenprüfung.

Eine schreibende Funktion bleibt bis zur ausdrücklichen späteren Freigabe ausgeschlossen.

## 42. Änderungshistorie

### NEU 016 – 26.07.2026

- aktuellen realen Navigationsbestand mit allgemeingültigem rein lesendem Exporter vollständig ausgelesen;
- Designplugin-, Seitenhierarchie- und Menüsicht als aktuelle Quelle erfasst;
- 240 Fachthemenkandidaten ausschließlich per Exakttreffer abgeglichen;
- alle unsicheren Fälle ohne Raten blockiert;
- Rohbericht, CSV- und JSON-Abgleich vollständig integriert;
- allgemeinen, themenunabhängigen Navigations-Exporter in den Pluginbestand aufgenommen;
- allgemeingültige Quellen- und Matchingregeln verbindlich festgelegt;
- keine Veränderung am Pferdeportal durchgeführt.


---

## 43. VOLLSTÄNDIG ABGESCHLOSSENER IMPORT-/SYNCHRONISATIONSVORSCHAUBLOCK

Der gebündelte Entwicklungs-, Härtungs- und Prüfblock wurde vollständig
abgeschlossen. Er ersetzt die vorzeitig ausgegebenen und zurückgezogenen
Zwischenstände NEU 017 und NEU 018.

### 43.1 Allgemeingültiges Strukturpaket

Das allgemeine Strukturpaket ist themenunabhängig. Fachbegriffe eines konkreten
Portals sind ausschließlich Daten. Prüf-, ID-, Status-, Adapter-, Konflikt- und
Freigabelogik gelten unverändert für beliebige Themen und Branchen.

Das Paket trennt verbindlich:

- `content` für fachliche Contenthierarchien;
- `marketplace` für transaktionsorientierte Marktplatzstrukturen;
- `magazine` für redaktionelle Magazinstrukturen;
- Beitragsarten als separate Klassifikation außerhalb der fachlichen Hierarchie.

### 43.2 Rein lesende Synchronisationsvorschau V1.1.0

Die aktuelle Version prüft:

- Paketformat, Schemaversion und Lesemodus;
- eindeutige Concept-IDs;
- gültige Blockzuordnung;
- Eltern-, Ebenen- und Zyklusregeln;
- kanonische Slugs;
- Name-, Slug- und Zielobjektkollisionen;
- exakte deklarierte Pfade;
- Bindung eines Navigationsexports an die richtige Website;
- WordPress-Seiten und hierarchische Taxonomien;
- unveränderte, hypothetisch neue, abweichende, konfliktbehaftete und blockierte Ziele;
- nicht aktionsfähige Statuswerte;
- SHA-256-Prüfsumme des geprüften Pakets.

### 43.3 Sicherheitsstatus

Die aktuelle Vorschauversion enthält technisch keine Schreibfähigkeit.

Nicht enthalten sind insbesondere:

- Anlegen, Bearbeiten oder Löschen von Seiten;
- Anlegen, Bearbeiten oder Löschen von Taxonomiebegriffen;
- Änderung von Menüs;
- Änderung von Optionen oder Metadaten;
- Transients oder sonstige persistente Plugin-Speicherung;
- externe Netzwerkanfragen;
- Import-, Migrations- oder Rollbackausführung.

`CREATE_PREVIEW` und `UPDATE_PREVIEW` sind ausschließlich Berichtswerte und
führen keine Änderung aus.

### 43.4 Interne Härtungsprüfung

- PHP-Syntax: PASS;
- automatisierte Tests: 10/10 PASS;
- falsche Quellwebsite: blockiert;
- doppelte Concept-ID: blockiert;
- Hierarchiezyklus: blockiert;
- blockübergreifende Elternbeziehung: blockiert;
- doppelte Geschwisternamen: blockiert;
- falscher deklarierter Pfad: blockiert;
- mehrfach verwendetes Zielobjekt: blockiert;
- gesperrte Statuswerte: ohne Aktionsvorschlag;
- fehlende Zieltaxonomie: blockiert;
- Suche nach WordPress-Schreib-APIs: PASS, keine gefunden.

### 43.5 Versionsstatus

- `AFFILIATE_PORTAL_STRUKTUR_SYNC_VORSCHAU_V1.0.0.zip`:
  zurückgezogener Zwischenstand, nicht verwenden.
- `AFFILIATE_PORTAL_STRUKTUR_SYNC_VORSCHAU_V1.1.0.zip`:
  aktueller intern geprüfter rein lesender Entwicklungsstand.
- Eine Installation auf dem bestehenden Pferdeportal ist derzeit nicht
  erforderlich und nicht freigegeben.

### 43.6 Vollständigkeit der Masterdatei

Diese Master-ZIP ist eine vollständige, konsolidierte Gesamtdatei. Sie ist kein
Delta und kein Updatepaket. Sie enthält eigenständig den vollständigen aktuellen
Regel-, Analyse-, Plugin-, Prüf- und Quellenstand.

Die zurückgezogenen Masterstände NEU 017 und NEU 018 sind keine gültigen
Übergabestände. NEU 019 setzt vollständig auf dem letzten gültigen Gesamtstand
NEU 016 auf und integriert den danach vollständig abgeschlossenen Großblock.

---

## 44. NÄCHSTER ZULÄSSIGER GROSSER ARBEITSBLOCK

Als nächster größerer Block ist die Entwicklung der kontrollierten
Schreibarchitektur zulässig, jedoch noch nicht ihre Aktivierung oder Ausführung.

Der Block muss vollständig gebündelt mindestens enthalten:

1. strikt getrennten Schreibadapter;
2. explizite Freigabeschranke;
3. Testinstanzpflicht;
4. Vorher-Backup und unveränderliche Lauf-ID;
5. Idempotenz und Wiederholbarkeit;
6. atomare Teiloperationen und Abbruchregeln;
7. Sperre paralleler Läufe;
8. keine automatische Löschung;
9. vollständigen Rollbackplan;
10. automatisierte Positiv- und Negativtests;
11. unabhängige Gegenprüfung;
12. keine Auslieferung oder Installation vor Abschluss des Gesamtblocks.

Bis zum vollständigen Abschluss dieses Großblocks bleiben Schreibimport und
Änderungen am Pferdeportal ausdrücklich nicht freigegeben.

---

## 45. Änderungshistorie

### NEU 019 – 26.07.2026

- vollständigen Import-/Synchronisationsvorschau-Großblock abgeschlossen;
- allgemeines Importschema und Sollstrukturpaket vollständig integriert;
- rein lesende Vorschau auf Version 1.1.0 gehärtet;
- Quellwebsite-, Pfad-, Namens-, Slug- und Zielobjektprüfung ergänzt;
- Statussperren und Paket-SHA-256 ergänzt;
- zehn automatisierte Tests vollständig bestanden;
- statischen Schreib-API-Scan bestanden;
- Version 1.0.0 und Masterstände NEU 017/018 als zurückgezogen dokumentiert;
- vollständige konsolidierte Master-ZIP auf Basis des letzten gültigen Standes NEU 016 erstellt;
- keine Installation und keine Änderung am Pferdeportal vorgenommen.

---

## 46. KONTROLLIERTE SCHREIBARCHITEKTUR – GROSSBLOCK ABGESCHLOSSEN

Der vollständige Entwicklungs-, Härtungs- und Prüfblock für die kontrollierte
Schreibarchitektur wurde abgeschlossen.

### 46.1 Allgemeingültigkeit

Die Architektur ist vollständig themen- und branchenunabhängig. Fachbegriffe
eines Portals sind ausschließlich Paketdaten. Sicherheits-, Prüf-, Freigabe-,
Backup-, Idempotenz-, Sperr- und Rollbacklogik gelten unverändert für beliebige
Affiliateportale.

### 46.2 Fail-closed Freigabeschranken

Ein Schreiblauf wird nur zugelassen, wenn gleichzeitig alle Bedingungen erfüllt sind:

- technische Schreibkonstante bewusst außerhalb des Plugins geöffnet;
- Umgebung `local`, `development` oder `staging`;
- Paketmodus `CONTROLLED_WRITE`;
- ausdrückliche Paketfreigabe;
- exakte Bindung an die geprüfte Paket-SHA-256;
- exakte menschliche Freigabephrase;
- gültige unveränderliche Lauf-ID;
- bestätigtes Vorher-Backup;
- bestandener rein lesender Vorschauprüfbericht;
- bestandene unabhängige Gegenprüfung.

Fehlt eine einzige Bedingung, bleibt der Lauf blockiert.

### 46.3 Unterstützte Operationen

Zulässig in der Architektur:

- `CREATE`
- `UPDATE`

Grundsätzlich unzulässig:

- `DELETE`
- automatische Löschung neu erzeugter Objekte;
- Menüänderungen;
- Beitragsverschiebungen;
- Designplugin-Optionen;
- HivePress-Sonderdaten außerhalb normaler hierarchischer Taxonomien.

### 46.4 Transaktions- und Wiederholbarkeitsschutz

Implementiert sind:

- globale Sperre paralleler Schreibläufe;
- unveränderliche Lauf-ID;
- deterministische Operations-IDs;
- Operations-Fingerprints;
- Zielzustands-Fingerprint als Vorbedingung;
- idempotentes Laufjournal;
- Vorher-Backupmanifest mit SHA-256;
- Rückwärts-Rollback;
- Sperrfreigabe auch bei Fehlern.

### 46.5 Bewusste Rollback-Grenzen

Vollautomatische Löschung bleibt ausgeschlossen.

- Neu erzeugte WordPress-Seiten dürfen im Fehlerfall höchstens fail-safe als
  Entwurf verbleiben.
- Neu erzeugte Taxonomiebegriffe werden nicht automatisch gelöscht.
- Eine endgültige Löschung wäre ein separater manueller Freigabeprozess
  außerhalb der automatischen Architektur.

### 46.6 Interne Prüfungen

- PHP-Syntax aller Dateien: PASS;
- automatisierte Positiv- und Negativtests: 13/13 PASS;
- Produktionsumgebung wird blockiert;
- falsche Paket-SHA-256 wird blockiert;
- falsche Freigabephrase wird blockiert;
- fehlende unabhängige Gegenprüfung wird blockiert;
- DELETE wird blockiert;
- nicht freigegebene Knoten werden blockiert;
- parallele Läufe werden blockiert;
- Wiederholung derselben Operation wird idempotent übersprungen;
- erzwungener Fehler löst Rückwärts-Rollback aus;
- manipuliertes Backup wird erkannt;
- Sperre wird auch nach einem Fehler gelöst;
- keine WordPress-Lösch-API enthalten;
- keine Backend-Ausführungsroute enthalten.

### 46.7 Freigabestatus

`AFFILIATE_PORTAL_STRUKTUR_SYNC_KONTROLLIERT_V2.0.0_DEV.zip` ist ausschließlich
ein integrierter interner Entwicklungs- und Evidenzstand.

Es gilt:

- nicht installieren;
- nicht auf dem bestehenden Pferdeportal ausführen;
- keine Freigabe für eine Testinstanz;
- keine Freigabe für Produktivbetrieb;
- technische Schreibschranke standardmäßig geschlossen.

Das bestehende Pferdeportal wurde nicht verändert.

---

## 47. NÄCHSTER ZULÄSSIGER GROSSBLOCK

Vor einer möglichen späteren Testinstanz-Freigabe ist ein vollständiger
Zertifizierungsblock erforderlich.

Dieser muss gebündelt enthalten:

1. unabhängige Code-Gegenprüfung;
2. Prüfung der WordPress-Adapter gegen eine isolierte Testinstallation;
3. echte Backup-/Rollback-Tests auf künstlichen Testobjekten;
4. Prüfung der Ziel-Fingerprints bei konkurrierenden Änderungen;
5. Prüfung von Abbruch, Wiederaufnahme und Idempotenz;
6. Prüfung großer Strukturpakete;
7. Datenschutz- und Berechtigungsprüfung;
8. dokumentierte Freigabe- oder Blockierentscheidung.

Bis zum Abschluss dieses Gesamtblocks bleibt jede Installation und Ausführung
der Schreibarchitektur verboten.

---

## 48. Änderungshistorie

### NEU 020 – 26.07.2026

- vollständige kontrollierte Schreibarchitektur entwickelt;
- allgemeingültige Fail-closed Freigabeschranken implementiert;
- Paket-SHA-256, Freigabephrase, Lauf-ID, Testumgebung, Backup, Vorschau und
  unabhängige Gegenprüfung als kumulative Pflichtbedingungen umgesetzt;
- globale Importsperre und idempotentes Laufjournal ergänzt;
- Zielzustands-Fingerprints und deterministische Operations-IDs umgesetzt;
- automatisches Löschen vollständig ausgeschlossen;
- Backupmanifest und Rückwärts-Rollback umgesetzt;
- Rollback-Grenzen für neu erzeugte Objekte ausdrücklich festgelegt;
- 13 automatisierte Positiv- und Negativtests bestanden;
- keine Backend-Ausführungsroute bereitgestellt;
- Entwicklungsplugin ausschließlich als nicht freigegebener interner
  Evidenzstand in die vollständige Master-ZIP integriert;
- keine Installation und keine Veränderung am Pferdeportal vorgenommen.


---

## 49. HARTE ZERTIFIZIERUNG DER SCHREIBARCHITEKTUR

Die unabhängige Gegenprüfung der Entwicklungsfassung 2.0.0-dev ist abgeschlossen.

**Entscheidung:** `BLOCKED_CRITICAL_DEFECTS`

Festgestellt wurden:

- vier kritische Befunde;
- vier hohe Befunde;
- zwei mittlere Befunde.

Die wichtigsten Blockierer sind:

1. CREATE-Rollback besitzt die neu erzeugte WordPress-Objekt-ID nicht zuverlässig;
2. Taxonomie-CREATE ist zugelassen, obwohl kein zulässiger automatischer Rollback besteht;
3. das Laufjournal bleibt nach einem Rollback fälschlich auf `COMPLETED`;
4. Backup und Laufzustand sind bei Prozessabbruch nicht persistent;
5. Hierarchieoperationen werden nicht topologisch sortiert;
6. Eltern-Concept-IDs werden nicht sicher in reale Ziel-IDs aufgelöst.

Damit sind die bisherigen 13 Unit-Tests ausdrücklich **keine Zertifizierung** für reale WordPress-Schreibläufe. Die Fake-Adapter haben wesentliche reale Grenzen verdeckt.

Die Entwicklungsfassung bleibt vollständig blockiert. Sie darf weder installiert noch getestet noch ausgeführt werden. Das Pferdeportal blieb unverändert.

## 50. ALLGEMEINGÜLTIGE LEHRE

Für beliebige Affiliateportale gilt verbindlich:

- Unit-Tests mit Fake-Adaptern ersetzen niemals eine reale Adapterzertifizierung;
- ein Rollback darf nur zugesichert werden, wenn jede Operation eine nachweisbar wirksame Kompensation besitzt;
- Laufjournal, Backup und Wiederaufnahme müssen vor dem ersten Schreibzugriff persistent sein;
- Hierarchien müssen topologisch verarbeitet werden;
- interne Concept-IDs müssen kontrolliert in reale Ziel-IDs aufgelöst werden;
- nicht rückrollbare Operationen bleiben fail-closed blockiert.

## 51. NÄCHSTER ZULÄSSIGER GROSSBLOCK

Komplette Neufassung der Transaktionsarchitektur mit:

1. persistentem Run-State und Backupmanifest vor dem ersten Schreiben;
2. Zuständen `PLANNED`, `APPLIED`, `ROLLED_BACK`, `COMMITTED`, `FAILED`;
3. korrekter Ledger-Rücksetzung nach Rollback;
4. topologischer Hierarchiesortierung;
5. Laufzeitauflösung von Concept-ID zu WordPress-Objekt-ID;
6. Blockierung nicht kompensierbarer CREATE-Aktionen;
7. überprüften Rollback-Rückgabewerten;
8. Crash- und Resume-Tests;
9. erneuter unabhängiger Gegenprüfung.

Bis zum Abschluss dieses Gesamtblocks bleibt jede Schreibfunktion verboten.

## 52. Änderungshistorie

### NEU 021 – 26.07.2026

- kontrollierte Schreibarchitektur unabhängig und hart gegengeprüft;
- vier kritische, vier hohe und zwei mittlere Defekte festgestellt;
- frühere Testaussage auf Unit-Test-Nachweis begrenzt;
- Installations-, Test- und Schreibfreigabe vollständig blockiert;
- allgemeingültige Zertifizierungsregeln verschärft;
- vollständigen Zertifizierungsbericht als Markdown und JSON integriert;
- nächsten Großblock auf vollständige Transaktionsneufassung gesetzt;
- keine Änderung am Pferdeportal vorgenommen.

---

## 49. NEUFASSUNG DES TRANSAKTIONSKERNS ABGESCHLOSSEN

Der vollständige Großblock zur Korrektur der blockierten Schreibarchitektur
wurde abgeschlossen.

### 49.1 Behobene kritische Befunde

- CREATE-Ergebnis-IDs werden persistent an die jeweilige Operation gebunden.
- Taxonomie-CREATE ist vollständig blockiert.
- Das fehlerhafte COMPLETED-Ledger wurde durch eine formale Zustandsmaschine ersetzt.
- Laufzustand, Operationen und Backupmanifest werden vor dem ersten Schreibzugriff persistent angelegt.
- Eltern werden vor Kindern topologisch verarbeitet.
- Concept-IDs werden laufintern zu realen Objekt-IDs aufgelöst.
- Jeder Kompensationsschritt muss einen geprüften Erfolg liefern.
- Fehlerhafte Kompensation führt zwingend zu `ROLLBACK_INCOMPLETE`.
- Zielzustände werden unmittelbar erneut geprüft.
- Optimistische Revisionen schützen persistente Lauf- und Operationszustände.

### 49.2 Weitere Härtung

- Externer Backupnachweis umfasst Backup-ID, Zeitpunkt, SHA-256,
  Zielinstanz-Fingerprint und bestandenen Restore-Test.
- Große Pakete werden in Chunks verarbeitet.
- Unterbrochene Läufe besitzen einen persistenten Resume-Pfad.
- Globale Sperren besitzen Eigentümertoken und Ablaufzeit.
- Automatische Löschung bleibt ausgeschlossen.
- Menüs, Beiträge, Designplugin-Optionen und Taxonomie-CREATE bleiben blockiert.

### 49.3 Interne Prüfung

- PHP-Syntax: PASS
- 20/20 Positiv- und Negativtests: PASS
- topologische Sortierung: PASS
- Zyklusblockierung: PASS
- persistentes Prepare vor Apply: PASS
- CREATE-ID-Persistenz: PASS
- Elternauflösung: PASS
- Chunking/Resume: PASS
- konkurrierende Zieländerung blockiert: PASS
- Rollback nach Apply-Fehler: PASS
- Rollbackfehler korrekt als unvollständig: PASS
- Backupmanipulation blockiert: PASS
- optimistische Revisionskonflikte erkannt: PASS
- Parallellauf blockiert: PASS
- ungültige Zustandswechsel blockiert: PASS

### 49.4 Harte Freigabeentscheidung

`INTERNAL_ARCHITECTURE_PASS / REAL_WORDPRESS_CERTIFICATION_REQUIRED`

Die Architekturfehler aus NEU 021 sind intern korrigiert. Dennoch bleibt die
Fassung ausdrücklich nicht zur Installation oder Ausführung freigegeben.

Grund:

- keine echte isolierte WordPress-Testinstallation;
- keine echte MySQL-/InnoDB-Crashsimulation;
- keine reale WordPress-API-Zertifizierung;
- keine realen Last- und Timeouttests.

Das bestehende Pferdeportal wurde nicht verändert.

---

## 50. NÄCHSTER ZULÄSSIGER GROSSBLOCK

Erforderlich ist eine echte isolierte WordPress-Testinstanz, die ausdrücklich
für künstliche Schreib-, Abbruch-, Resume- und Rollbacktests freigegeben ist.

Der spätere Zertifizierungsblock muss vollständig enthalten:

1. Installation ausschließlich auf der isolierten Testinstanz;
2. künstliche Seiten- und Taxonomieobjekte;
3. reale Datenbankpersistenz;
4. Prozessabbruch zwischen einzelnen Zuständen;
5. Resume nach Abbruch;
6. reale WordPress-API-Fehler;
7. konkurrierende Änderungen;
8. große Paket- und Ressourcenprüfungen;
9. Backup-Restore-Test;
10. unabhängige Gegenprüfung;
11. endgültige PASS- oder BLOCKED-Entscheidung.

Bis dahin bleibt jede Installation und jeder Schreibtest verboten.

---

## 51. Änderungshistorie

### NEU 022 – 26.07.2026

- Transaktionskern vollständig neu gefasst;
- alle zehn Befunde aus der blockierten Zertifizierung NEU 021 adressiert;
- persistente Lauf-, Operations-, Backup- und Sperrstruktur entwickelt;
- formale Zustandsmaschine eingeführt;
- topologische Hierarchieverarbeitung umgesetzt;
- Concept-ID-zu-Objekt-ID-Auflösung umgesetzt;
- Taxonomie-CREATE blockiert;
- Chunking und Resume ergänzt;
- Rollbackfehler hart ausgewertet;
- 20/20 interne Tests bestanden;
- keine Installation und keine Änderung am Pferdeportal;
- echte WordPress-Zertifizierung weiterhin zwingend vorgeschrieben.

---

## 52. ZWEITE HARTE GEGENPRÜFUNG DES TRANSAKTIONSKERNS

Der intern korrigierte Transaktionskern 2.2.0-dev wurde erneut ohne Schonung geprüft.

### 52.1 Zusätzlich gefundene Fehler

1. Zwei gleichzeitige Resume-Aufrufe desselben Laufs konnten wegen eines identischen Lauf-Eigentümertokens parallel eintreten.
2. Ein Prozessabbruch nach persistentem Status `APPLYING`, aber vor gespeichertem Ergebnis, war nicht sicher wiederaufnehmbar.
3. Ein Absturz nach tatsächlich erfolgreichem CREATE konnte bei Wiederaufnahme ein zweites Objekt erzeugen.
4. Ein Teilabbruch während PREPARE konnte einen unklaren teilweise vorbereiteten Lauf hinterlassen.
5. Unterbrechungen während COMMITTING oder ROLLING_BACK waren nicht vollständig rekonstruierbar.

Diese Fehler sind vollständig in der Masterdatei dokumentiert und nicht verschwiegen.

### 52.2 Korrekturen in 2.3.0-dev

- einzigartiges Sperrtoken pro Ausführungsversuch;
- jeder zweite gleichzeitige Resume-Aufruf wird unabhängig vom Lauf blockiert;
- neue Zustände `PREPARING`, `PREPARE_FAILED`, `UNCERTAIN` und `RECOVERING`;
- deterministischer externer Schlüssel für WordPress-Seiten-CREATE;
- Reconciliation nach unklarem Prozessabbruch;
- kein doppeltes CREATE nach Absturz;
- wiederaufnehmbare COMMITTING- und ROLLING_BACK-Pfade;
- unbekannte Zwischenzustände führen fail-closed zum Rollback;
- Taxonomie-CREATE bleibt blockiert;
- automatische Löschung bleibt ausgeschlossen.

### 52.3 Prüfung

- PHP-Syntax: PASS;
- 9/9 neue gezielte Parallelitäts-, Crash- und Recoverytests: PASS;
- gleichzeitiger Resume desselben Laufs blockiert: PASS;
- Teilfehler in PREPARE eindeutig als `PREPARE_FAILED`: PASS;
- Absturz nach CREATE ohne Duplikat wiederaufgenommen: PASS;
- unklarer APPLYING-Zustand rekonstruiert: PASS;
- unbekannter Zustand führt zum Rollback: PASS;
- unterbrochener Commit wird fortgesetzt: PASS;
- Kompensationsfehler bleibt `ROLLBACK_INCOMPLETE`: PASS;
- externe CREATE-Schlüssel deterministisch: PASS;
- Eltern-vor-Kind-Sortierung weiterhin PASS.

### 52.4 Freigabeentscheidung

`INTERNAL_CRASH_RECOVERY_PASS / REAL_WORDPRESS_CERTIFICATION_REQUIRED`

Die interne Architektur ist weiter gehärtet. Eine Freigabe bleibt dennoch verboten,
weil keine echte isolierte WordPress-/MySQL-Testumgebung verfügbar ist.

Am bestehenden Pferdeportal wurde nichts verändert.

---

## 53. NÄCHSTER ZULÄSSIGER GROSSBLOCK

Echte isolierte WordPress-Zertifizierung mit Prozessabbruch, realen Datenbankzuständen,
WordPress-APIs, großen Paketen und geprüftem Backup-Restore.

Bis dahin:
- Plugin nicht installieren;
- keine Schreibtests;
- keine Änderung am Pferdeportal;
- keine Produktivfreigabe.

---

## 54. Änderungshistorie

### NEU 023 – 26.07.2026

- Transaktionskern 2.2.0-dev erneut hart gegengeprüft;
- fünf zusätzliche Parallelitäts- und Recoveryfehler gefunden;
- alle Fehler samt Ursache und Korrektur dokumentiert;
- crash-sicheren Transaktionskern 2.3.0-dev entwickelt;
- deterministische CREATE-Reconciliation ergänzt;
- PREPARE-, APPLY-, COMMIT- und ROLLBACK-Recovery erweitert;
- 9/9 neue gezielte Tests bestanden;
- keine Installation und keine Portaländerung;
- echte WordPress-Zertifizierung bleibt zwingend.


---

## 55. DRITTE HARTE GEGENPRÜFUNG – ERGEBNIS BLOCKED

Der crash-sichere Transaktionskern 2.3.0-dev wurde erneut vollständig gegen
Prozessabbruch, Wiederaufnahme, konkurrierende Änderungen und Kompensation
geprüft.

### 55.1 Neue Fehler

- `K-01`: RECOVERING nach erneutem Absturz nicht wiederaufnehmbar;
- `K-02`: COMPENSATING wird mit falscher Reconciliation bewertet;
- `K-03`: UPDATE kann eigene und fremde Änderungen nicht sicher unterscheiden;
- `K-04`: CREATE-Marker ist nicht atomar mit der Seitenerstellung;
- `H-01`: mehrdeutige externe Schlüssel werden nicht hart blockiert;
- `H-02`: keine echte Fencing-Sicherheit bei abgelaufener Sperre;
- `H-03`: harter Abbruch in PREPARING besitzt keinen Recoverypfad;
- `M-01`: Seiten-CREATE wird nur quarantänisiert, nicht vollständig entfernt.

Alle Fehler, Ursachen und Konsequenzen sind im vollständigen Prüfbericht erhalten.

### 55.2 Harte Entscheidung

`BLOCKED`

Version 2.3.0-dev darf nicht installiert oder ausgeführt werden. Die bisherigen
internen Tests bleiben als Evidenz erhalten, stellen jedoch keine reale
WordPress-Zertifizierung dar.

### 55.3 Vollständige Realtest-Matrix

Eine allgemeingültige Zertifizierungsmatrix für eine isolierte WordPress-/MySQL-
Testinstanz wurde erstellt. Sie umfasst:

- harte Prozessabbrüche in allen Phasen;
- Apply- und Compensation-Reconciliation;
- konkurrierende Fremdänderungen;
- Lock-Fencing;
- große Strukturpakete;
- Hierarchiefehler;
- vollständige Backup-Restore-Prüfung.

Die Matrix ist als `NOT_EXECUTED` gekennzeichnet. Es wurde kein Test vorgetäuscht.
Am Pferdeportal wurde nichts verändert.

---

## 56. NÄCHSTER ZULÄSSIGER GROSSBLOCK

Neuaufbau des Transaktionsmodells auf Basis der Befunde K-01 bis M-01. Erst
danach folgt die reale Zertifizierung auf einer isolierten Testinstanz.

Bis dahin bleiben alle Schreibfunktionen gesperrt.

---

## 57. Änderungshistorie

### NEU 024 – 26.07.2026

- dritte harte Gegenprüfung durchgeführt;
- acht weitere Fehler vollständig dokumentiert;
- Transaktionskern 2.3.0-dev auf BLOCKED gesetzt;
- vollständige Real-WordPress-Zertifizierungsmatrix erstellt;
- reproduzierbarer isolierter Testumgebungsentwurf integriert;
- keine Tests als real ausgeführt ausgegeben;
- keine Installation und keine Änderung am Pferdeportal.


---

## 58. TRANSAKTIONSMODELL AUF BASIS K-01 BIS M-01 NEU AUFGEBAUT

Der vollständige Korrekturblock wurde abgeschlossen. Dabei wurde nicht versucht, unsicheres CREATE weiter zu reparieren oder schönzureden. Der zulässige Funktionsumfang wurde hart reduziert.

### 58.1 Verbindliche Funktionsgrenzen

- `CREATE`: vollständig blockiert;
- `DELETE`: vollständig blockiert;
- `UPDATE`: ausschließlich intern vorbereitet und nur für ausdrücklich definierte `owned_fields`;
- keine Menüs, Beiträge, HivePress-Sonderdaten oder Designplugin-Optionen;
- keine Backend-Ausführungsroute.

### 58.2 Behebung der acht Befunde

- `K-01`: Recoverypfad für jeden nichtterminalen Laufzustand definiert;
- `K-02`: Apply- und Compensation-Reconciliation vollständig getrennt;
- `K-03`: Drei-Wege-Projektion aus Vorher-, Soll- und Istzustand, ausschließlich auf besessenen Feldern;
- `K-04`: CREATE vollständig blockiert; damit keine unbewiesene atomare Identität;
- `H-01`: mehrdeutige CREATE-Schlüssel entfallen aus dem zulässigen Umfang;
- `H-02`: monotones Fence-Token muss bei jedem persistenten Zustandswechsel geprüft werden;
- `H-03`: Abbruch in `PREPARING` endet fail-closed als `PREPARE_FAILED`; vor `PREPARED` sind Portalwrites verboten;
- `M-01`: keine falsche Vollrollback-Behauptung und keine Quarantänelogik mehr, da CREATE nicht zulässig ist.

### 58.3 Interne Prüfung

- PHP-Syntax: PASS;
- 11/11 Kern-, Negativ-, Recovery- und Fencingtests: PASS;
- CREATE blockiert: PASS;
- DELETE blockiert: PASS;
- owned_fields verpflichtend: PASS;
- Drei-Wege-Projektion: PASS;
- veralteter Fence-Schreiber blockiert: PASS;
- kontrolliertes UPDATE: PASS;
- Fremdänderung vor Apply blockiert: PASS;
- unklarer Apply-Zustand rekonstruiert: PASS;
- PREPARING-Abbruch fail-closed: PASS;
- getrennte Reconciliation: PASS;
- alle nichtterminalen Laufzustände erfasst: PASS.

### 58.4 Harte Bewertung

`INTERNAL_UPDATE_CORE_PASS / REAL_WORDPRESS_CERTIFICATION_REQUIRED`

Es gibt weiterhin keine Installations- oder Schreibfreigabe. Der Kern ist nur intern geprüft. Eine reale isolierte WordPress-/MySQL-Zertifizierung wurde nicht ausgeführt und wird ausdrücklich nicht behauptet.

Am Pferdeportal wurde nichts verändert.

---

## 59. NÄCHSTER ZULÄSSIGER GROSSBLOCK

Entwicklung einer rein lesenden Zertifizierungs- und Testinstanz-Vorbereitung für den eingeschränkten UPDATE-Kern. Erst danach kann auf einer ausdrücklich isolierten WordPress-Testinstanz ein realer Testblock erfolgen.

Bis dahin bleiben Installation und Schreibfunktion gesperrt.

---

## 60. Änderungshistorie

### NEU 025 – 26.07.2026

- Transaktionsmodell vollständig neu aufgebaut;
- alle Befunde K-01 bis M-01 berücksichtigt;
- CREATE und DELETE hart aus dem zulässigen Umfang entfernt;
- sichere UPDATE-Projektionen und getrennte Reconciliation definiert;
- monotones Fencing als Pflichtvertrag eingeführt;
- vollständige Recoverymatrix für nichtterminale Zustände erstellt;
- 11/11 interne Tests bestanden;
- Fehlerhistorie vollständig erhalten;
- keine Installation und keine Portaländerung.


---

## 61. REIN LESENDE ZERTIFIZIERUNGSVORBEREITUNG ABGESCHLOSSEN

Der komplette Vorbereitungsblock für die spätere reale Zertifizierung des eingeschränkten UPDATE-Kerns wurde abgeschlossen.

### 61.1 Erstellte Zertifizierungsgrundlage

- verbindlicher Gesamtplan mit harten Abbruchregeln;
- vollständige Isolations- und Testinstanzanforderungen;
- WordPress-, PHP-, MySQL- und MariaDB-Kompatibilitätsmatrix;
- reproduzierbares künstliches Testdatenmodell;
- 25 konkrete Positiv-, Negativ-, Konflikt-, Fencing-, Recovery-, Rollback-, Backup-, Berechtigungs- und Lasttests;
- 10 exakt definierte Prozessabbruchpunkte;
- formaler Drei-Wege-Projektionsnachweis;
- formaler Vertrag für monotones Fencing;
- vollständige Backup- und Restoreanforderungen;
- maschinenlesbares Evidenzschema;
- unabhängiger Gegenprüfungsauftrag;
- verbindliche Einzelschritt-Ausführungsreihenfolge.

### 61.2 Harte Grenzen

- keine reale Testinstanz vorhanden;
- keine realen WordPress-/MySQL-Schreibtests ausgeführt;
- kein Plugin installiert;
- keine Schreibfunktion freigegeben;
- kein Ergebnis als reale Zertifizierung dargestellt;
- keine Änderung am Pferdeportal.

### 61.3 Status

`PREPARATION_COMPLETE / REAL_TESTS_NOT_EXECUTED / INSTALLATION_BLOCKED`

Der UPDATE-Kern 2.4.0-dev bleibt bis zur vollständigen realen Zertifizierung blockiert.

---

## 62. NÄCHSTER ZULÄSSIGER GROSSBLOCK

Der nächste Großblock kann erst auf einer ausdrücklich isolierten WordPress-/MySQL-Testinstanz stattfinden. Benötigt werden ein geprüfter Instanz-Fingerprint, ein real wiederhergestelltes Backup und künstliche Testobjekte.

Ohne diese Voraussetzungen sind keine weiteren Schreibentwicklungen oder angeblichen Realtests zulässig.

---

## 63. Änderungshistorie

### NEU 026 – 26.07.2026

- vollständige rein lesende Zertifizierungsvorbereitung erstellt;
- 25 reale Testfälle und 10 Abbruchfälle spezifiziert;
- Kompatibilitäts-, Fencing-, Drei-Wege-, Backup- und Evidenzanforderungen festgelegt;
- unabhängigen Gegenprüfungsauftrag integriert;
- keine Testausführung behauptet;
- kein neues Einzelplugin ausgegeben;
- keine Installation und keine Portaländerung;
- vollständige Fehlerhistorie und alle bisherigen Stände erhalten.

---

## 64. ISOLIERTE WORDPRESS-TESTINSTANZ ALS REPRODUZIERBARES LABOR VORBEREITET

Der vollständige technische Vorbereitungsblock für eine isolierte lokale
WordPress-/MariaDB-Zertifizierungsumgebung wurde abgeschlossen.

### 64.1 Enthaltene Laborumgebung

- WordPress mit PHP 8.3;
- separate MariaDB-Testdatenbank;
- separate MariaDB-Restore-Datenbank;
- WP-CLI-Container;
- internes Docker-Netzwerk;
- ausschließlich lokale Bindung an `127.0.0.1:18080`;
- getrennte persistente Volumes;
- künstliches Testdatenmodell;
- Instanz-Fingerprint;
- Datenbankbackup mit SHA-256;
- Wiederherstellung in einer zweiten Datenbank;
- maschinenlesbarer Vorbedingungsnachweis;
- vollständiger Zerstörungsablauf.

### 64.2 Sicherheitsgrenzen

- die technische Schreibschranke bleibt geschlossen;
- keine Produktivdaten;
- keine Produktivzugangsdaten;
- keine Verbindung zum Pferdeportal;
- kein automatischer Plugin-Test;
- keine reale Zertifizierung behauptet;
- keine Änderung am Pferdeportal.

### 64.3 Interne Prüfung des Laborpakets

- Shell-Syntax aller Abläufe: PASS;
- ausschließlich lokale Portbindung: PASS;
- internes Netzwerk: PASS;
- separate Restore-Datenbank: PASS;
- Backup-SHA-256 vorgesehen: PASS;
- Produktivdomain und Produktivzugriffe nicht enthalten: PASS;
- vollständiger Zerstörungsablauf: PASS.

### 64.4 Status

`LAB_PACKAGE_READY_NOT_EXECUTED`

Die Laborumgebung ist reproduzierbar vorbereitet, wurde in dieser Laufzeit aber
nicht gestartet. Daher wurden weiterhin keine realen WordPress-/MySQL-Schreibtests
ausgeführt.

---

## 65. NÄCHSTER ZULÄSSIGER GROSSBLOCK

Ausführung des vollständigen Laboraufbaus auf einem ausdrücklich freigegebenen
lokalen Docker-System und Rückgabe des maschinenlesbaren Evidenzordners.

Erst nach bestandenem Instanz-, Backup- und Restore-Nachweis dürfen die bereits
spezifizierten UPDATE-, Konflikt-, Fencing-, Recovery- und Abbruchtests ausgeführt
werden.

---

## 66. Änderungshistorie

### NEU 027 – 26.07.2026

- vollständige isolierte Docker-Testumgebung erstellt;
- WordPress-, MariaDB-, Restore-Datenbank- und WP-CLI-Komponenten definiert;
- künstliche Testdaten und feste Ausführungsreihenfolge integriert;
- Instanz-Fingerprint, Backup, SHA-256 und Restoreprüfung vorbereitet;
- statische Sicherheitsprüfung bestanden;
- Labor nicht ausgeführt;
- keine reale Zertifizierung behauptet;
- keine Installation und keine Änderung am Pferdeportal;
- vollständige Fehlerhistorie und alle bisherigen Stände erhalten.

---

## 67. VERBINDLICHER KONSERVATIVER ABSCHLUSS

Der verbleibende Realtest- und Abschlussblock wurde zu einer einzigen
Endentscheidung zusammengeführt.

### 67.1 Endstatus der Schreibfunktionen

`BLOCKED`

Es besteht keine Freigabe für automatische Schreibzugriffe.

Blockiert bleiben:

- Seiten erstellen oder ändern;
- Kategorien oder Taxonomien erstellen oder ändern;
- Hierarchien verschieben;
- Kategorien zusammenführen;
- Kategorien löschen;
- Navigation oder Menüs ändern;
- Beiträge verschieben oder neu zuordnen;
- Designplugin-Einstellungen schreiben;
- HivePress-Strukturen verändern;
- produktive WordPress-Daten verändern.

### 67.2 Zulässiger Funktionsumfang

Zulässig bleiben ausschließlich rein lesende Funktionen:

- Bestandsaufnahme;
- Strukturprüfung;
- Validierung;
- Export;
- Vergleich;
- Vorschau;
- Konflikterkennung;
- Berichterstellung.

### 67.3 Grund der Blockierung

Eine echte isolierte WordPress-/MySQL-Zertifizierung wurde nicht durchgeführt.

Daher wird:

- kein Realtest-PASS behauptet;
- keine unsichere Schreibfreigabe erteilt;
- keine Installation verlangt;
- keine technische Umgehung empfohlen.

### 67.4 Auswirkungen auf das Pferdeportal

Das Pferdeportal wurde nicht verändert.

Es erfolgten insbesondere keine Änderungen an:

- Seiten;
- Kategorien;
- Navigation;
- Menüs;
- Designplugin;
- HivePress;
- Beiträgen;
- produktiven Daten.

### 67.5 Nutzeraufwand

Der Nutzer muss aktuell nichts tun.

Insbesondere nicht:

- Docker installieren;
- lokale Testumgebung starten;
- Befehle ausführen;
- Plugins installieren;
- Dateien hochladen;
- Zugangsdaten bereitstellen.

### 67.6 Claude-Prüfung

Claude-Prüfungen sind vorerst ausgesetzt.

Eine erneute Claude-Prüfung darf nur nach ausdrücklicher neuer Freigabe des
Nutzers erfolgen.

---

## 68. ABSCHLUSSENTSCHEIDUNG

`CONSERVATIVE_CLOSURE`

Der Arbeitsstrang ist auf dem aktuellen sicheren Stand abgeschlossen.

Der vollständige aktuelle Stand bleibt in dieser Masterdatei erhalten,
einschließlich:

- aller Regeln;
- aller Entscheidungen;
- aller Plugins;
- aller Prüfberichte;
- aller Fehler;
- aller Korrekturen;
- aller blockierten Funktionen;
- aller historischen Stände;
- des finalen Sicherheitsstatus.

---

## 69. Änderungshistorie

### NEU 028 – 26.07.2026

- Realtest- und Abschlussblock zu einem einzigen Endblock zusammengeführt;
- Docker- und Nutzer-Testpflicht aufgehoben;
- Schreibfunktionen endgültig als BLOCKED eingestuft;
- rein lesende Funktionen ausdrücklich freigegeben;
- technische Schreibschranken verbindlich geschlossen;
- keine Installation oder Änderung am Pferdeportal;
- Claude-Prüfungen bis auf ausdrückliche neue Freigabe pausiert;
- vollständigen konservativen Abschluss dokumentiert;
- vollständige konsolidierte Gesamtdatei erstellt.
