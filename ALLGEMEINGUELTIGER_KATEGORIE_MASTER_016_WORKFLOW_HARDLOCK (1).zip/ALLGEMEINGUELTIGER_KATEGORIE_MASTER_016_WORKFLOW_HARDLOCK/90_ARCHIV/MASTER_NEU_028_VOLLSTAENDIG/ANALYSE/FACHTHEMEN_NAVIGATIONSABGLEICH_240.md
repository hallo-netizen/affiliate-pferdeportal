# ABSCHLUSSABGLEICH FACHTHEMEN GEGEN AKTUELLE NAVIGATION

**Quelle:** aktueller rein lesender Export vom 26.07.2026  
**Matching:** ausschließlich exakter normalisierter Titel oder exakter normalisierter Slug  
**Raten/Ähnlichkeitszuordnung:** ausgeschlossen

## Verifizierte Navigationsquelle

- Seiten insgesamt: 412
- veröffentlicht: 410
- aktive Hubseiten Ebene 1: 8
- aktive Hubseiten Ebene 2: 57
- aktive Kategorie-Seiten Ebene 3: 329
- maximale Seitentiefe: 3
- Zyklen: 0
- fehlende Elternseiten: 0
- Designplugin-Signal vorhanden: ja

## Ergebnis für 240 Fachthemenkandidaten

- exakt zugeordnet: 229
- nicht exakt zuordenbar: 0
- exakte Mehrfachkonflikte: 11

## Harte Bewertung

`PASS_EXAKT` bedeutet: Der Kandidat ist durch einen eindeutigen exakten Treffer in der aktuellen aktiven Kategorie-Seitenhierarchie belegt.

`NICHT_ZUORDENBAR` bedeutet: Es gibt keinen exakten Titel- oder Slugtreffer. Es wurde bewusst keine unsichere semantische oder ähnliche Zuordnung vorgenommen.

`KONFLIKT_MEHRFACH` bedeutet: Mehrere aktuelle aktive Kategorie-Seiten treffen exakt zu; automatische Zuordnung ist blockiert.

Die bestehende Navigation wurde nicht verändert.
