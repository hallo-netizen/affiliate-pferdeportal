# HARTE ABSCHLUSSPRÜFUNG

## Ergebnis

BLOCKED_SOURCE_CONFLICT

Die 240 Fachthemenkandidaten können ohne aktuellen Export der verbindlichen
Designplugin-Backendnavigation nicht endgültig zugeordnet werden.

## Bestätigt

- Fachthemen und Beitragsarten sind getrennt.
- Die bestehenden 1.124 Beitragsart-Kategorien bilden keine zulässige Fachhierarchie.
- Historische Hierarchiequellen widersprechen sich.
- Keine Portaländerung wurde durchgeführt.
- Kein Schreibimport ist freigegeben.

## Fehlende verbindliche Quelle

Aktueller rein lesender Export der Designplugin-Backendnavigation.

## Verboten bis zur Quellenklärung

- Kategorien anlegen, verschieben, umbenennen oder löschen
- Beiträge neu zuordnen
- Menüs ändern
- HivePress-Strukturen ändern
- Migrations- oder Importläufe vorbereiten oder ausführen
