# SOLLSTRUKTUR- UND KONFLIKTANALYSE 001

**Datum:** 26.07.2026  
**Arbeitsweise:** vollständig extern und rein lesend  
**Portaländerungen:** keine

## 1. Eindeutiger Ist-Befund

Der WordPress-Bestand enthält **1133 Kategorien**.

Davon sind:

- **1124 Beitragsart-Kategorien**
- verteilt auf nur **240 Fachthemen**
- **8 erkennbare Magazin-Hauptkategorien**
- zusätzlich die ungenutzte Standardkategorie `Uncategorized`

Damit bilden rund **99 %** des WordPress-Kategoriebestands nicht die fachliche Portalhierarchie ab, sondern Varianten wie FAQ, Beratung, Vergleich, Pflege, Sicherheit, Anwendung, Kosten, Installation, Lagerung und Übungen.

## 2. Beitragsartenbestand

| Beitragsart | Kategorien |
|---|---:|
| FAQ | 251 |
| Beratung | 251 |
| Vergleich | 175 |
| Pflege | 102 |
| Sicherheit | 90 |
| Anwendung | 80 |
| Kosten | 62 |
| Installation | 45 |
| Lagerung | 38 |
| Übungen | 30 |

## 3. Verbindliche Schlussfolgerung

Die Beitragsarten dürfen nicht als eigenständige Hauptstruktur des Contentbereichs fortgeführt werden.

Die künftige Solltrennung lautet:

1. **Fachkategorie:** beschreibt das eigentliche Thema, beispielsweise `Regendecken`.
2. **Beitragsart:** beschreibt nur die redaktionelle Form, beispielsweise FAQ oder Vergleich.
3. **Konkreter Beitrag:** wird vom Textplugin geplant und erzeugt.

Die Beitragsart gehört damit in die Zuständigkeit des Textplugins beziehungsweise in eine separate technische Klassifikation. Sie darf die fachliche Keyword-Hierarchie nicht ersetzen.

## 4. Vorläufiges Sollmodell

### Content

- fachliche Hierarchie aus der verbindlichen Portal-Navigation beziehungsweise ihrer Backend-Quelle;
- unterste Fachkategorie ist beitragstragend;
- die erkannten 240 Fachthemen sind **Kandidaten**, keine automatisch freigegebene Endstruktur;
- ein Fachthema wird nur übernommen, wenn es in die verbindliche Keyword- und Navigationshierarchie passt;
- FAQ, Beratung, Vergleich, Pflege und weitere Beitragsarten werden darunter nicht als sichtbare Fachkategorien dupliziert.

### Magazin

Die folgenden bestehenden Magazin-Kategorien wurden separat erkannt:

- `Pferde verstehen`
- `Pferderassen & Pferdetypen`
- `Recht, Finanzen & Organisation`
- `Reiterleben & Miteinander`
- `Pferdehaltung & Stallaltag`
- `Pferdegesundheit verstehen`
- `Pferdeernährung verstehen`
- `Ausbildung & Reitweisen`

Sie bleiben ein eigenständiger redaktioneller Block und dürfen nicht automatisch mit Content-Fachkategorien vermischt werden.

Auffälligkeit:

- `Pferdehaltung & Stallaltag` enthält wahrscheinlich einen Schreibfehler (`Stallaltag` statt `Stallalltag`). Dies ist nur ein Prüfhinweis. Es wurde nichts geändert.

### Marktplatz

Der HivePress-Bestand besitzt bereits eine zweistufige Struktur mit 95 Kategorien und 10 Wurzelkategorien. Er muss getrennt und transaktionsorientiert behandelt werden. Eine automatische Übernahme der Contentstruktur ist ausgeschlossen.

## 5. Konfliktklassen

### K01 – Flache Beitragsartenstruktur

Alle 1.124 Beitragsart-Kategorien liegen aktuell auf der Wurzelebene. Sie bilden keine fachliche Hierarchie.

### K02 – Mehrfachanlage gleicher Beitragsart

Es existieren **{len(duplicate_groups)} normalisierte Namensdubletten-Gruppen**. Diese müssen vor jeder späteren Migration einzeln auf gleiche oder unterschiedliche fachliche Herkunft geprüft werden.

### K03 – Vermischungsgefahr Content und Textplugin

Eine direkte Umwandlung aller Beitragsart-Kategorien in neue Fachkategorien wäre falsch. Zuerst muss das Fachthema extrahiert und gegen die verbindliche Navigationsquelle geprüft werden.

### K04 – Magazin separat

Die acht Magazin-Hauptkategorien dürfen nicht als Content-Unterkategorien interpretiert werden.

### K05 – Bestand mit Beiträgen

Kategorien mit bereits zugewiesenen Beiträgen dürfen später nur über eine ausdrücklich freigegebene Zuordnungsmatrix behandelt werden. Keine automatische Verschiebung oder Löschung.

## 6. Automatisierbare Migrationslogik – nur Konzept

Für eine spätere Testumgebung kann die Maschine:

1. Beitragsart-Präfix erkennen;
2. Fachthema extrahieren;
3. Fachthema gegen die verbindliche Navigationshierarchie prüfen;
4. Beitragsart separat speichern;
5. bestehende Beiträge einer Fachkategorie zuordnen;
6. Konflikte und Dubletten blockieren;
7. ausschließlich eine Vorschau erzeugen;
8. erst nach ausdrücklicher Freigabe in einer Testinstanz schreiben.

Für das bestehende Pferdeportal ist derzeit **kein Schreibschritt freigegeben**.

## 7. Ergebnis

Die fachliche Ausgangsmenge wurde erfolgreich von 1.133 flachen WordPress-Kategorien auf folgende logisch getrennte Bestände reduziert:

- **240 Content-Fachthemenkandidaten**
- **10 erkannte Beitragsarten**
- **8 Magazin-Hauptkategorien**
- **95 separat zu behandelnde HivePress-Kategorien**

Dies ist noch keine endgültig freigegebene Portalstruktur. Die verbindliche fachliche Hierarchie muss im nächsten Block gegen die bestehende Backend-Navigationsquelle geprüft werden.

## 8. Nächster zulässiger Schritt

Erstellung einer **Fachthemen-Zuordnungsmatrix**:

- jeder der 240 Fachthemenkandidaten;
- zugehörige vorhandene Beitragsarten;
- bestehende Beitragsanzahl;
- möglicher Navigationspfad;
- Status `PASS`, `KONFLIKT`, `DUBLETTE` oder `NICHT ZUORDENBAR`.

Dieser Schritt erfolgt weiterhin extern und ohne Plugininstallation.
