# UPDATE-Transaktionskern 2.4.0-dev

## Grundentscheidung

Unsicheres CREATE wird nicht weiter kaschiert, sondern vollständig blockiert. Dadurch entfallen K-04, H-01 und M-01 innerhalb des freigegebenen Funktionsumfangs. DELETE bleibt ebenfalls blockiert.

## Behebung K-01 bis M-01

- K-01: Recoverymatrix für jeden nichtterminalen Laufzustand.
- K-02: getrennte Methoden für Apply- und Compensation-Reconciliation.
- K-03: sichere Drei-Wege-Projektion ausschließlich auf owned_fields.
- K-04: CREATE vollständig blockiert.
- H-01: keine CREATE-Schlüsselauflösung mehr erforderlich; CREATE blockiert.
- H-02: monotones Fence-Token; jeder persistente Zustandswechsel prüft das aktuelle Fence.
- H-03: PREPARING-Abbruch endet fail-closed als PREPARE_FAILED; vor PREPARED erfolgen keine Portalwrites.
- M-01: keine Quarantänebehauptung mehr, weil CREATE nicht zulässig ist.

## Freigabegrenze

Interne Kernprüfung bestanden. Reale WordPress-/MySQL-Zertifizierung weiterhin erforderlich.
