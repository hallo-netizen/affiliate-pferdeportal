# Crash-sicherer Transaktionskern 2.3.0-dev

## Zusätzliche Fehler aus der harten Gegenprüfung von 2.2.0-dev

1. Gleichzeitige Resume-Aufrufe desselben Laufs konnten wegen identischem Eigentümertoken parallel eintreten.
2. Absturz nach `APPLYING`, aber vor gespeichertem Ergebnis, war nicht sicher wiederaufnehmbar.
3. Absturz nach erfolgreichem CREATE konnte beim Resume ein Duplikat erzeugen.
4. Teilabbruch während PREPARE hinterließ keinen eindeutigen Endstatus.
5. COMMITTING und COMPENSATING waren nicht zuverlässig wiederaufnehmbar.

## Korrektur

- einzigartiges Sperrtoken pro Ausführungsversuch;
- PREPARING/PREPARE_FAILED;
- APPLYING/UNCERTAIN-Reconciliation;
- deterministischer externer CREATE-Schlüssel;
- persistenter Abgleich nach unklarem Prozessabbruch;
- wiederaufnehmbare Commit- und Rollbackpfade;
- unbekannte Zustände werden fail-closed zurückgerollt.

## Freigabe

Interne Architekturprüfung PASS. Reale WordPress-Zertifizierung weiterhin ausstehend.
