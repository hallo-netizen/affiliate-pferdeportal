# ZERTIFIZIERUNG DER KONTROLLIERTEN SCHREIBARCHITEKTUR

**Entscheidung: `BLOCKED_CRITICAL_DEFECTS`**

Die Architektur 2.0.0-dev ist **nicht** für Installation, Testschreiben oder Produktivbetrieb freigegeben.

## Befunde
### CERT-001 – CRITICAL – CREATE-Rollback kennt neu erzeugte Objekt-ID nicht

**Nachweis:** Das Backup wird vor dem Schreiben erzeugt. CREATE liefert die neue ID erst danach; sie wird nicht in das Backupmanifest zurückgeschrieben. restore() erhält daher für neue Seiten object_id=0.

**Auswirkung:** Nach einem späteren Fehler kann eine zuvor neu erzeugte Seite nicht zuverlässig markiert oder zurückgeführt werden.

**Pflichtkorrektur:** Ergebnis-ID atomar im persistenten Laufjournal und Backupmanifest binden; Rollback auf genau diese ID testen.

### CERT-002 – CRITICAL – Taxonomie-CREATE ist nicht rückrollbar, aber freigegeben

**Nachweis:** Der Plan erlaubt CREATE für wordpress_taxonomy. restore() löscht neu erzeugte Begriffe bewusst nicht und besitzt keinen alternativen neutralen Zustand.

**Auswirkung:** Ein fehlgeschlagener Lauf kann neue Taxonomiebegriffe dauerhaft zurücklassen.

**Pflichtkorrektur:** Taxonomie-CREATE bis zu einem ausdrücklich freigegebenen Kompensationskonzept blockieren.

### CERT-003 – CRITICAL – Ledger bleibt nach Rollback auf COMPLETED

**Nachweis:** record_completed() wird direkt nach jeder Operation aufgerufen. Bei einem späteren Fehler wird das Ledger weder zurückgesetzt noch als ROLLED_BACK markiert.

**Auswirkung:** Ein Wiederholungslauf kann eine zurückgerollte Operation fälschlich als erledigt überspringen.

**Pflichtkorrektur:** Transaktionale Zustände PENDING/APPLIED/ROLLED_BACK/COMMITTED einführen und Wiederaufnahme daran binden.

### CERT-004 – CRITICAL – Backup und Laufzustand sind nicht absturzfest

**Nachweis:** Backupmanifest und Ergebnisliste existieren nur im Arbeitsspeicher und werden erst als Rückgabewert ausgegeben.

**Auswirkung:** Bei PHP-Abbruch, Serverfehler oder Prozessverlust fehlen belastbare Wiederaufnahme- und Rollbackdaten.

**Pflichtkorrektur:** Backupmanifest und Journal vor dem ersten Schreibzugriff persistent und prüfbar speichern.

### CERT-005 – HIGH – Hierarchieoperationen werden nicht topologisch sortiert

**Nachweis:** APSSW_Plan sortiert ausschließlich alphabetisch nach concept_id.

**Auswirkung:** Kindobjekte können vor ihren Eltern verarbeitet werden.

**Pflichtkorrektur:** Abhängigkeitsgraph validieren, Zyklen blockieren und Eltern vor Kindern topologisch sortieren.

### CERT-006 – HIGH – parent_concept_id wird nicht sicher in Ziel-ID aufgelöst

**Nachweis:** Operationen enthalten parent_concept_id, der Repository-Adapter verwendet jedoch target.parent_object_id direkt.

**Auswirkung:** Neu erzeugte Eltern können nicht sicher und allgemeingültig mit ihren Kindern verbunden werden.

**Pflichtkorrektur:** Laufinterne Concept-ID-zu-Objekt-ID-Abbildung als verbindliche Quelle verwenden.

### CERT-007 – HIGH – Rollback-Ergebnisse der WordPress-API werden nicht geprüft

**Nachweis:** restore() ruft wp_update_post/wp_update_term auf, wertet WP_Error jedoch nicht aus.

**Auswirkung:** Der Engine-Status kann einen erfolgreichen Rollback melden, obwohl einzelne Rücksetzungen scheiterten.

**Pflichtkorrektur:** Jeden Kompensationsschritt prüfen, protokollieren und bei Fehler FAILED_ROLLBACK_INCOMPLETE setzen.

### CERT-008 – HIGH – Ziel-Fingerprint schützt nicht vor externem Race zwischen Prüfung und Schreiben

**Nachweis:** Fingerprint wird vor dem API-Aufruf geprüft; externe Änderungen sind nicht durch die plugininterne Sperre ausgeschlossen.

**Auswirkung:** Eine konkurrierende externe Änderung kann zwischen Prüfung und Schreibzugriff liegen.

**Pflichtkorrektur:** Unmittelbare Revalidierung, Versionsmarker und adapterabhängige atomare Vorbedingungen entwickeln.

### CERT-009 – MEDIUM – Bestätigtes Vorher-Backup ist nur ein Request-Boolean

**Nachweis:** backup_confirmed wird als boolescher Eingabewert akzeptiert, ohne einen externen Backupnachweis zu identifizieren.

**Auswirkung:** Die Freigabebedingung beweist kein wiederherstellbares Systembackup.

**Pflichtkorrektur:** Backup-ID, Zeit, Hash, Zielinstanz und Restore-Test als prüfbaren Nachweis verlangen.

### CERT-010 – MEDIUM – Großpakete und Ressourcenlimits nicht zertifiziert

**Nachweis:** Keine belastbaren Lasttests gegen reale WordPress-APIs und keine Chunk-/Resume-Strategie vorhanden.

**Auswirkung:** Große Strukturen können Timeouts oder Teilzustände verursachen.

**Pflichtkorrektur:** Chunking, persistente Checkpoints und Lasttests auf isolierter WordPress-Instanz.

## Harte Schlussfolgerung

Die bisherigen 13 Unit-Tests waren nicht ausreichend, weil die Fake-Repository-Logik reale WordPress-Grenzen verdeckte. Besonders CREATE-Rollback, persistente Crash-Wiederaufnahme und Hierarchieabhängigkeiten wurden dadurch nicht realistisch geprüft.

Die Entwicklungsfassung bleibt ausschließlich Evidenzbestand. Kein Plugin muss installiert werden. Am Pferdeportal wurde nichts verändert.

## Nächster zulässiger Großblock

Vollständige Neufassung der Transaktions- und Wiederaufnahmearchitektur, danach erneute interne Gegenprüfung. Eine reale Testinstanz-Zertifizierung bleibt anschließend zwingend.
