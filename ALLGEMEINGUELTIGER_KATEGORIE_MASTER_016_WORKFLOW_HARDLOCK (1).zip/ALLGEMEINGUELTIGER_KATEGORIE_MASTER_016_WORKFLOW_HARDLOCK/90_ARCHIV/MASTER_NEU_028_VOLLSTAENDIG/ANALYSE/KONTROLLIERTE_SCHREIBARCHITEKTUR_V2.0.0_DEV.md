# KONTROLLIERTE SCHREIBARCHITEKTUR 2.0.0-dev

## Status

Interne Entwicklung und Härtung abgeschlossen. Nicht zur Installation freigegeben.

## Sicherheitsmodell

1. Fail-closed technische Hauptschranke.
2. Nur Testumgebungen (`local`, `development`, `staging`).
3. Exakte Bindung an Paket-SHA-256.
4. Exakte menschliche Freigabephrase.
5. Unveränderliche Lauf-ID.
6. Bestätigtes Vorher-Backup.
7. Bestandene rein lesende Vorschau.
8. Unabhängige Gegenprüfung.
9. Globale Importsperre.
10. Zielzustands-Fingerprint vor jeder Operation.
11. Idempotentes Laufjournal.
12. Kein automatisches Löschen.
13. Rückwärts ausgeführter Rollback.
14. Sperrfreigabe auch bei Fehlern.

## Unterstützte Aktionen

- `CREATE`
- `UPDATE`

`DELETE` ist nicht zulässig.

## Unterstützte Adapter

- WordPress-Seiten
- hierarchische WordPress-Taxonomien

Menüs, Beiträge, HivePress-Sonderdaten und Designplugin-Optionen sind nicht Teil
dieses Schreibadapters und bleiben blockiert.

## Allgemeingültigkeit

Themenbegriffe und Brancheninhalte werden ausschließlich über Strukturpakete
geliefert. Die Architektur enthält keine pferdespezifische Entscheidungslogik.
