# FACHTHEMEN-ZUORDNUNGSMATRIX 240

**Datum:** 26.07.2026  
**Arbeitsweise:** vollständig extern und rein lesend  
**Portaländerungen:** keine

## Ergebnis

Alle **240 Fachthemenkandidaten** wurden mit ihren vorhandenen Beitragsarten und Beitragszahlen erfasst.

### Statusverteilung

- `OFFEN_NAVIGATION`: 222
- `KONFLIKT`: 7
- `DUBLETTE`: 11

## Bedeutung

### OFFEN_NAVIGATION

Das Fachthema ist technisch erkennbar, kann aber ohne die verbindliche Backend-Navigationsquelle keinem endgültigen Pfad zugeordnet werden.

### KONFLIKT

Es existieren bereits Beiträge. Eine spätere Neuordnung darf deshalb nicht automatisch erfolgen.

### DUBLETTE

Es bestehen Mehrfachanlagen oder normalisierte Themenüberschneidungen. Diese Fälle müssen vor jeder späteren Zuordnung einzeln geprüft werden.

## Verbindlicher Befund

Die Fachthemenmatrix ist vollständig erstellt. Eine endgültige Sollhierarchie ist weiterhin nicht möglich, solange kein vollständiger maschinenlesbarer Export der verbindlichen Backend-Navigationskonfiguration vorliegt.

Es wurde nichts am Pferdeportal verändert.
