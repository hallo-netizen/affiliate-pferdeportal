# TRANSaktionskern 2.2.0-dev

## Harte Korrekturen

Alle zehn Befunde aus der blockierten Zertifizierung 2.0.0-dev wurden
architektonisch adressiert:

1. CREATE-ID wird im persistenten Operationsjournal gespeichert.
2. Taxonomie-CREATE bleibt blockiert.
3. Zustände PENDING/APPLYING/APPLIED/COMMITTED/COMPENSATING/ROLLED_BACK ersetzen das fehlerhafte Completed-Ledger.
4. Lauf, Operationen und Backupmanifest werden vor Schreibzugriff persistent gespeichert.
5. Hierarchie wird topologisch sortiert.
6. Concept-ID wird laufintern zur erzeugten Objekt-ID aufgelöst.
7. Kompensationsergebnisse werden zwingend geprüft.
8. Zielzustand wird unmittelbar doppelt revalidiert; optimistische Revisionen schützen Journalzustände.
9. Externer Backupnachweis benötigt ID, Zeitpunkt, Hash, Ziel-Fingerprint und bestandenen Restore-Test.
10. Chunking und Resume sind integriert.

## Weiterhin blockiert

- Installation
- Backend-Ausführung
- Produktivbetrieb
- Testschreiben auf dem Pferdeportal
- Taxonomie-CREATE
- automatische Löschung
- Menüs, Beiträge und Designplugin-Optionen

## Offene Zertifizierung

Nur eine isolierte echte WordPress-Testinstallation kann Datenbanktransaktionen,
Prozessabbruch, reale WordPress-API-Fehler und Lastverhalten belastbar zertifizieren.
