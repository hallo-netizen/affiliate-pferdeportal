# DRITTE HARTE GEGENPRÜFUNG – TRANSAKTIONSKERN 2.3.0-dev

## Gesamturteil

**BLOCKED. Keine Installations- oder Schreibfreigabe.**

Die erneute Gegenprüfung hat weitere sicherheitsrelevante Lücken ergeben. Die
vorherigen 9/9 Tests belegen nur die dort modellierten Fälle. Sie sind keine
WordPress-, Datenbank- oder Crash-Zertifizierung.

## Neue Befunde

### K-01 – Recovery-Zustand selbst nicht wiederaufnehmbar (kritisch)

Stürzt der Prozess im Zustand `RECOVERING` ab, akzeptiert der Resume-Pfad diesen
Zustand nicht erneut. Der Lauf kann dauerhaft festhängen.

### K-02 – Unterbrochene Kompensation wird falsch abgeglichen (kritisch)

Für `COMPENSATING` wird derselbe Abgleich wie für eine unklare Apply-Operation
verwendet. Ein Objekt kann bereits kompensiert sein, aber noch als angewendet
erkannt werden. Dadurch kann der Lauf fälschlich als vollständig zurückgerollt
enden.

### K-03 – UPDATE-Reconciliation unterscheidet Fremdänderung nicht sicher (kritisch)

Bei UPDATE wird jede Abweichung vom Vorherzustand als möglicherweise erfolgreich
angewendete eigene Änderung behandelt. Eine konkurrierende Fremdänderung kann
so fälschlich übernommen oder beim Rollback überschrieben werden.

### K-04 – CREATE-Marker nicht atomar mit Seitenerstellung (kritisch)

Der externe Schlüssel wird erst nach `wp_insert_post()` als Post-Meta gesetzt.
Ein Absturz zwischen Seitenerstellung und Meta-Speicherung lässt ein erzeugtes
Objekt ohne Marker zurück. Der Resume-Lauf kann dann ein Duplikat erzeugen.

### H-01 – Mehrdeutige externe Schlüssel werden nicht hart blockiert (hoch)

Findet die Suche mehr als ein Objekt mit demselben Schlüssel, liefert sie `0`.
Dadurch könnte statt einer Blockierung ein weiteres Objekt erzeugt werden.

### H-02 – Abgelaufene Sperre kann während noch laufender Operation übernommen werden (hoch)

Die Sperre besitzt keinen echten Fencing-Mechanismus. Dauert eine WordPress-
Operation länger als die Lease, kann ein zweiter Lauf nach Ablauf eintreten,
obwohl der erste Prozess noch arbeitet.

### H-03 – PREPARING nach hartem Prozessabbruch bleibt dauerhaft offen (hoch)

Die Fehlerbehandlung greift nur bei fangbaren Exceptions. Ein harter
Prozessabbruch kann den Lauf in `PREPARING` zurücklassen. Dafür existiert kein
sicherer Recovery- oder Abbruchpfad.

### M-01 – Seiten-CREATE wird nicht vollständig zurückgerollt (mittel)

Neu erzeugte Seiten werden nur als Entwurf quarantänisiert. Das ist bewusst
fail-safe, aber kein vollständiger transaktionaler Rollback. Der Begriff
„vollständig zurückgerollt“ darf dafür nicht verwendet werden.

## Verbindliche Konsequenz

- Version 2.3.0-dev bleibt historischer, blockierter Entwicklungsstand.
- Keine Installation auf einer Test- oder Produktivseite.
- Keine Ausgabe als eigenständig zu verwendendes Plugin.
- Keine Freigabe durch interne Fake-Tests.
- Vor einem neuen Implementierungsstand ist das Transaktionsmodell neu zu
  schneiden: getrennte Apply-/Compensation-Reconciliation, atomare oder
  eindeutig rekonstruierbare CREATE-Markierung, sichere UPDATE-Projektionen,
  Fencing und Recovery für jeden nichtterminalen Zustand.
