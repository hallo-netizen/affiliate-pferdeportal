# Isoliertes Zertifizierungspaket

Dieses Paket definiert den vollständigen späteren Realtest. Es wurde **nicht**
ausgeführt, weil in der aktuellen Umgebung keine isolierte WordPress-/MySQL-
Instanz verfügbar ist.

## Verbot

- nicht auf dem Pferdeportal ausführen
- keine Produktivdaten verwenden
- keinen Schreibschalter öffnen

## Freigabekriterium

Erst wenn sämtliche Pflichtfälle der Matrix auf einer wegwerfbaren Testinstanz
bestanden sind und eine unabhängige Gegenprüfung PASS meldet, darf über eine
begrenzte Testfreigabe entschieden werden.
