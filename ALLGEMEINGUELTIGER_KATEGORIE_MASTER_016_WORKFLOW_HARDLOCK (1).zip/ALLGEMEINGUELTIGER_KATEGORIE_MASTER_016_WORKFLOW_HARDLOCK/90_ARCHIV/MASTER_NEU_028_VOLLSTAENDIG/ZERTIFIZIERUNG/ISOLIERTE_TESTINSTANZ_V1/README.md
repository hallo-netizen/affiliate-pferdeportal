# HISTORISCHER, NICHT AUSZUFÜHRENDER TESTENTWURF

Dieser Ordner bleibt nur zur vollständigen Projektdokumentation erhalten.

**Nicht ausführen.** Der konservative Abschluss in `ABSCHLUSS/FINAL_DECISION.json`
hat Vorrang. Der Nutzer muss keine Docker-Umgebung installieren oder starten.

---

# Isolierte WordPress-Zertifizierungsinstanz V1

## Zweck

Dieses Paket stellt ausschließlich eine lokal gebundene, isolierte WordPress-/MariaDB-Testumgebung bereit.

Es ist nicht für das Pferdeportal bestimmt und verändert keine produktive Website.

## Harte Sicherheitsregeln

- Netzwerk ist intern.
- WordPress ist nur an `127.0.0.1:18080` gebunden.
- Es werden ausschließlich künstliche Testdaten verwendet.
- `APSTX_ENABLE_WRITE` bleibt standardmäßig `false`.
- Das Produktivportal darf weder URL, Zugangsdaten, Datenbankexport noch Dateien liefern.
- Vor jedem Schreibtest muss ein Instanz-Fingerprint erzeugt werden.
- Vor jedem Schreibtest muss ein Backup erstellt und auf der zweiten Datenbank wiederhergestellt werden.
- Ohne PASS aller Vorbedingungen bleibt der Schreibtest blockiert.

## Enthaltene Abläufe

1. Umgebung starten.
2. WordPress automatisch installieren.
3. künstliche Seiten und Kategorien anlegen.
4. Instanz-Fingerprint erzeugen.
5. Backup erstellen.
6. Backup in separater Datenbank wiederherstellen.
7. Restore-Hash prüfen.
8. Vorbedingungen als Evidenzdatei ausgeben.
9. Erst danach kann ein später freigegebener Zertifizierungslauf beginnen.

## Status

Die Umgebung wurde in dieser Chat-Laufzeit nicht gestartet. Es werden keine Realtests behauptet.
