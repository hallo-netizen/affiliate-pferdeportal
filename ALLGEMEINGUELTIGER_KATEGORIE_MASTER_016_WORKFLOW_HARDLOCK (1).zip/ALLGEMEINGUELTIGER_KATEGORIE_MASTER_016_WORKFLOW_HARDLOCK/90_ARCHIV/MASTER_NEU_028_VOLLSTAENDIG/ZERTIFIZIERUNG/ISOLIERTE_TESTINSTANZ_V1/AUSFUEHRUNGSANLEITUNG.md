# Verbindliche Ausführungsreihenfolge

Die folgenden Befehle dürfen ausschließlich auf einem lokalen Rechner mit Docker ausgeführt werden:

```bash
cp .env.example .env
./scripts/00_preflight.sh
./scripts/01_start.sh
./scripts/02_seed.sh
./scripts/03_fingerprint.sh
./scripts/04_backup_restore.sh
./scripts/05_certify_preconditions.sh
```

Danach muss `evidence/05_preconditions.json` geprüft werden.

Nur wenn dort `status = PASS`, `production_data_used = false` und `write_gate_enabled = false` stehen, ist die reine Testinstanz-Vorbereitung bestanden.

Der UPDATE-Kern darf dadurch noch nicht automatisch freigegeben werden. Dafür ist ein separater realer Zertifizierungslauf mit ausdrücklicher Freigabe notwendig.

Nach Abschluss:

```bash
./scripts/06_stop_and_destroy.sh
```
