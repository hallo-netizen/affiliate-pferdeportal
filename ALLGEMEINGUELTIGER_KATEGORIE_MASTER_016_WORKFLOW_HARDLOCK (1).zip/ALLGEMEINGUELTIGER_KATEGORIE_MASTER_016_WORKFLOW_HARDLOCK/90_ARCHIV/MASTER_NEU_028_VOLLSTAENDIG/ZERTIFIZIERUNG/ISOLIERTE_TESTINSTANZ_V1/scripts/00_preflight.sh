#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v docker >/dev/null
docker compose version >/dev/null
test -f docker-compose.yml
test -f fixtures/testdata.json
mkdir -p evidence artifacts
printf '{"status":"PASS","check":"local_preflight"}\n' > evidence/00_preflight.json
