#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose up -d db wordpress wpcli restore-db
docker compose exec -T wpcli sh -lc '
until wp core is-installed --path=/var/www/html >/dev/null 2>&1; do
  if ! wp core install --path=/var/www/html --url=http://127.0.0.1:18080 --title="Isolierte Zertifizierung" --admin_user=certadmin --admin_password="Local-Test-Only-Change-Me" --admin_email=cert@example.invalid --skip-email >/dev/null 2>&1; then
    sleep 3
  fi
done
wp option update blog_public 0 --path=/var/www/html
wp option update permalink_structure "/%postname%/" --path=/var/www/html
'
printf '{"status":"PASS","check":"environment_started"}\n' > evidence/01_start.json
