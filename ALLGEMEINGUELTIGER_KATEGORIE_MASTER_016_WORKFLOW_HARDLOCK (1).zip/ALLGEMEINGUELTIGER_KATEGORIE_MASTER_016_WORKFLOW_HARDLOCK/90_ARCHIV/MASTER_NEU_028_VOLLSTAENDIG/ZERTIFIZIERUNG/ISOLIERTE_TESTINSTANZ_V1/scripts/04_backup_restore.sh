#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose exec -T wpcli wp db export - --path=/var/www/html > evidence/04_wordpress.sql
sha256sum evidence/04_wordpress.sql | awk '{print $1}' > evidence/04_wordpress.sql.sha256
docker compose exec -T restore-db sh -lc 'mariadb -uroot -proot_test_only -e "DROP DATABASE IF EXISTS wordpress_restore; CREATE DATABASE wordpress_restore;"'
docker compose exec -T restore-db sh -lc 'mariadb -uroot -proot_test_only wordpress_restore' < evidence/04_wordpress.sql
docker compose exec -T restore-db sh -lc 'mariadb -uroot -proot_test_only wordpress_restore -N -e "SELECT ID,post_parent,post_status,post_name,post_title FROM wp_posts WHERE post_type='\''page'\'' ORDER BY ID; SELECT t.term_id,t.slug,t.name,tt.taxonomy,tt.parent FROM wp_terms t JOIN wp_term_taxonomy tt ON tt.term_id=t.term_id ORDER BY tt.taxonomy,t.term_id;"' > evidence/04_restore_fingerprint_source.txt
sha256sum evidence/04_restore_fingerprint_source.txt | awk '{print $1}' > evidence/04_restore_fingerprint.sha256
printf '{"status":"PASS","check":"backup_created_and_restored"}\n' > evidence/04_backup_restore.json
