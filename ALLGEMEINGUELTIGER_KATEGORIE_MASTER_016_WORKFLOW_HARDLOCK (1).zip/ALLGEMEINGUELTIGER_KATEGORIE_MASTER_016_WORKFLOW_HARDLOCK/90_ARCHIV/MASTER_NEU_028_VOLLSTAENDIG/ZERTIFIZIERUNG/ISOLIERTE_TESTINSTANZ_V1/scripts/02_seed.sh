#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose exec -T wpcli sh -lc '
set -eu
ROOT_A=$(wp post create --post_type=page --post_status=publish --post_title="Testbereich A" --post_name="testbereich-a" --porcelain)
wp post meta update "$ROOT_A" _cert_fixture_key root-a
A1=$(wp post create --post_type=page --post_status=publish --post_title="Testkategorie A1" --post_name="testkategorie-a1" --post_parent="$ROOT_A" --porcelain)
wp post meta update "$A1" _cert_fixture_key child-a1
A2=$(wp post create --post_type=page --post_status=publish --post_title="Testkategorie A2" --post_name="testkategorie-a2" --post_parent="$ROOT_A" --porcelain)
wp post meta update "$A2" _cert_fixture_key child-a2
ROOT_B=$(wp post create --post_type=page --post_status=publish --post_title="Testbereich B" --post_name="testbereich-b" --porcelain)
wp post meta update "$ROOT_B" _cert_fixture_key root-b
wp term create category "Testthema A" --slug=testthema-a >/dev/null
wp term create category "Testthema B" --slug=testthema-b >/dev/null
'
printf '{"status":"PASS","check":"fixtures_seeded"}\n' > evidence/02_seed.json
