#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose exec -T wpcli sh -lc '
wp core version --path=/var/www/html
wp option get siteurl --path=/var/www/html
wp db query "SELECT ID,post_parent,post_status,post_name,post_title FROM wp_posts WHERE post_type='\''page'\'' ORDER BY ID" --skip-column-names
wp db query "SELECT t.term_id,t.slug,t.name,tt.taxonomy,tt.parent FROM wp_terms t JOIN wp_term_taxonomy tt ON tt.term_id=t.term_id ORDER BY tt.taxonomy,t.term_id" --skip-column-names
' > evidence/03_fingerprint_source.txt
sha256sum evidence/03_fingerprint_source.txt | awk '{print $1}' > evidence/03_instance_fingerprint.sha256
printf '{"status":"PASS","check":"instance_fingerprint_created"}\n' > evidence/03_fingerprint.json
