#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
for f in evidence/00_preflight.json evidence/01_start.json evidence/02_seed.json evidence/03_instance_fingerprint.sha256 evidence/04_wordpress.sql.sha256 evidence/04_restore_fingerprint.sha256; do
  test -s "$f"
done
INSTANCE=$(cat evidence/03_instance_fingerprint.sha256)
BACKUP=$(cat evidence/04_wordpress.sql.sha256)
RESTORE=$(cat evidence/04_restore_fingerprint.sha256)
cat > evidence/05_preconditions.json <<JSON
{
  "status": "PASS",
  "environment": "isolated-local",
  "production_data_used": false,
  "instance_fingerprint_sha256": "$INSTANCE",
  "backup_sha256": "$BACKUP",
  "restore_fingerprint_sha256": "$RESTORE",
  "write_gate_enabled": false,
  "real_update_tests_executed": false
}
JSON
