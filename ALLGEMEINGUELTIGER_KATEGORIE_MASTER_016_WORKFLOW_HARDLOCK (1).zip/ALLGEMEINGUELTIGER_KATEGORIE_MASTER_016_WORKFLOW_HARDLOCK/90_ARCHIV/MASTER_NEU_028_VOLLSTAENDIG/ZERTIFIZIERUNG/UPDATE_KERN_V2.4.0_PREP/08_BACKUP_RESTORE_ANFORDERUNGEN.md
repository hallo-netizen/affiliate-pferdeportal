# Backup- und Restore-Anforderungen

## Vor jedem Schreibblock

- vollständiger Datenbankdump
- vollständige relevante WordPress-Dateien
- SHA-256 beider Artefakte
- Instanz-Fingerprint
- Zeitpunkt in UTC
- eindeutige Backup-ID

## Restore-Nachweis

Das Backup muss auf einer zweiten leeren Testinstanz wiederhergestellt werden. Danach sind mindestens zu vergleichen:

- Tabellenanzahl
- Zeilenanzahlen der betroffenen Tabellen
- Hash der Testobjekte
- WordPress-Site-URL und Home-URL
- Pluginbestand
- Testobjekt-Hierarchie

Nur `RESTORE_TEST_STATUS=PASS` öffnet die Schreibschranke. Eine bloße Aussage „Backup vorhanden“ reicht nicht.
