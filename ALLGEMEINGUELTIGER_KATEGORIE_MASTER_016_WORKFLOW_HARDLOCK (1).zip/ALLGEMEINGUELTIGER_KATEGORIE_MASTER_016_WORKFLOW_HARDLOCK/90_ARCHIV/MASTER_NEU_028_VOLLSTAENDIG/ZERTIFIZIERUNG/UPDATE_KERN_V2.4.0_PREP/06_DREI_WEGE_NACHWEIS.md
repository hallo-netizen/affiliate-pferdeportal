# Drei-Wege-Projektionsnachweis

Für jedes `owned_field` gelten drei Werte:

- `before`: bei bestandener Vorschau gelesener Zustand
- `target`: ausdrücklich freigegebener Sollzustand
- `current`: unmittelbar vor dem Schreiben erneut gelesener Zustand

## Zulässige Entscheidungen

| Bedingung | Entscheidung |
|---|---|
| `current == before` | Änderung auf `target` zulässig |
| `current == target` | idempotent überspringen |
| `current != before` und `current != target` | Konflikt, keine Änderung |

Nicht besessene Felder dürfen weder Teil des Sollzustands noch Teil des Rollback-Schreibsatzes sein. Ihre Werte müssen vor, während und nach dem Lauf unverändert bleiben oder externe Änderungen vollständig behalten.

## Rollback

Rollback darf ein `owned_field` nur dann auf `before` zurücksetzen, wenn der aktuelle Wert noch exakt dem von diesem Lauf geschriebenen `target` entspricht. Andernfalls ist der Rollback für dieses Feld zu blockieren und der Lauf als `ROLLBACK_INCOMPLETE` zu markieren.
