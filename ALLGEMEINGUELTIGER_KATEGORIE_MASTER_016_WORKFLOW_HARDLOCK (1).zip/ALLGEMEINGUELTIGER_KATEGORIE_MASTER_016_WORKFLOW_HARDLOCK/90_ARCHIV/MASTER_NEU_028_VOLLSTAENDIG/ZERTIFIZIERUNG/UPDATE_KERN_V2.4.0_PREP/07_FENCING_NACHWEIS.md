# Fencing-Nachweis

Ein bloßes Ablaufdatum einer Sperre genügt nicht. Jeder Schreibversuch benötigt ein streng monoton steigendes Fence-Token.

## Pflichtvertrag

1. Sperrübernahme erzeugt ein neues, größeres Fence-Token.
2. Jeder persistente Journalwechsel enthält dieses Token.
3. Jeder Adapteraufruf erhält dieses Token.
4. Unmittelbar vor dem WordPress-Schreiben wird geprüft, dass das Token noch aktuell ist.
5. Ein älterer Schreiber darf nach Ablauf seiner Sperre keinen Zustand mehr ändern.
6. Datenbankupdate und Fence-Prüfung müssen im selben atomaren Schutzbereich erfolgen oder durch eine gleichwertige Bedingung abgesichert sein.

## Zertifizierungskriterium

Bei zwei konkurrierenden Schreibern darf ausschließlich der Schreiber mit dem höchsten gültigen Fence-Token eine Zustands- oder Portaländerung durchführen.
