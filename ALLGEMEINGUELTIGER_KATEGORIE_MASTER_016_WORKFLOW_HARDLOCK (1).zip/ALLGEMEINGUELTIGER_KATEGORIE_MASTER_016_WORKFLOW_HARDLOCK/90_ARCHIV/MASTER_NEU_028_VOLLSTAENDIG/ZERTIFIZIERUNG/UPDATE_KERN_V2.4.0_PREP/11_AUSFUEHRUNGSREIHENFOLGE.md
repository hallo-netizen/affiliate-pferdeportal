# Verbindliche Ausführungsreihenfolge

1. Isolation nachweisen.
2. Ausgangsbackup erzeugen und auf zweiter Instanz wiederherstellen.
3. Testobjekte erzeugen.
4. Ausgangszustände und Hashes sichern.
5. rein lesende Vorschau ausführen.
6. Vorschauergebnis unabhängig gegenprüfen.
7. Schreibschranke ausschließlich für den einzelnen Testlauf öffnen.
8. genau einen Testfall ausführen.
9. Schreibschranke sofort wieder schließen.
10. Datenbank, Objektzustände und Protokolle sichern.
11. Testfall bewerten.
12. Bei kritischem oder hohem Fehler gesamte Zertifizierung abbrechen.
13. Vor dem nächsten Schreibtest Ausgangsbackup wiederherstellen.

Kein Sammellauf mehrerer unbewerteter Schreibtests auf demselben veränderten Datenbestand.
