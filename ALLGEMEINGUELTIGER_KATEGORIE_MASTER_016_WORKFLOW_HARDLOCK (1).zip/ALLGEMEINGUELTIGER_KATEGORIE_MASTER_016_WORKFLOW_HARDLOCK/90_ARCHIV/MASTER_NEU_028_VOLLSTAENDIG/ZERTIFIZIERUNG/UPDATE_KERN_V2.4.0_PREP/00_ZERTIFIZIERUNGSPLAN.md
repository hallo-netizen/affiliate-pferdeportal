# Zertifizierungsplan – eingeschränkter UPDATE-Kern 2.4.0-dev

## Ziel

Reale Zertifizierung ausschließlich auf einer isolierten WordPress-/MySQL-Testinstanz. Der bestehende Livebestand darf weder verbunden noch verändert werden.

## Zulässiger Funktionsumfang

- ausschließlich `UPDATE`
- ausschließlich ausdrücklich deklarierte `owned_fields`
- keine Anlage neuer Seiten oder Taxonomiebegriffe
- keine Löschung
- keine Menüs
- keine Beiträge
- keine HivePress-Sonderdaten
- keine Designplugin-Optionen

## Zertifizierungsphasen

1. Umgebungsnachweis und Isolation
2. reproduzierbarer Ausgangsdatenbestand
3. rein lesender Vorschaulauf
4. kontrollierte Positivläufe
5. konkurrierende Fremdänderungen
6. Abbruch- und Wiederaufnahmetests
7. Rollback- und Restoretests
8. Last- und Ressourcenprüfung
9. unabhängige Gegenprüfung
10. endgültige Entscheidung `REAL_WORDPRESS_PASS` oder `BLOCKED`

## Harte Abbruchregel

Ein einzelner kritischer oder hoher Fehler beendet die Zertifizierung mit `BLOCKED`. Weitere Schreibtests sind dann unzulässig, bis eine korrigierte Version vorliegt.
