# Testinstanz-Voraussetzungen

## Pflichtbedingungen

- separate Domain oder lokale Adresse ohne öffentliche Erreichbarkeit
- eigenständige Datenbank
- eigenständiges Dateisystem
- keine Verbindung zur Live-Datenbank
- keine gemeinsam genutzten Upload-, Cache- oder Object-Cache-Verzeichnisse
- ausgehende E-Mails deaktiviert oder umgeleitet
- Suchmaschinenindexierung blockiert
- WordPress-Umgebungstyp `staging`, `development` oder `local`
- vollständiges Datenbank- und Dateibackup vor jedem Schreibblock
- geprüfter Restore auf eine zweite leere Testinstanz
- eindeutiger Instanz-Fingerprint
- PHP-Fehlerprotokollierung aktiviert
- MySQL/MariaDB-Binlog oder gleichwertiger Änderungsnachweis empfohlen

## Mindestkompatibilität

| Komponente | Mindeststand | Prüfstatus |
|---|---:|---|
| WordPress | 6.4 | OFFEN |
| PHP | 8.1 | OFFEN |
| MySQL | 8.0 | OFFEN |
| MariaDB | 10.6 | OFFEN |
| InnoDB | erforderlich | OFFEN |
| WP-CLI | 2.10 | OFFEN |

WordPress 7.0.2 ist als aktueller Zielstand des Testobjekts gesondert zu prüfen. Es wird keine Kompatibilität behauptet, bevor reale Tests vorliegen.
