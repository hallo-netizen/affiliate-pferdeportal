# Lessons Learned aus dem eingefrorenen Schreibkern

- Schreibzugriffe müssen fail-closed sein.
- Vorschau und Zielzustand müssen exakt gebunden sein.
- Idempotenz benötigt persistente Operationsidentitäten.
- Hierarchische Importe benötigen Eltern-vor-Kind-Verarbeitung.
- Rollback ist bei CREATE und Taxonomien besonders schwierig.
- Prozessabbruch, Resume, Fencing und konkurrierende Änderungen müssen real getestet werden.
- Unit-Tests ersetzen keine echte WordPress-/Datenbankzertifizierung.
- Entwicklung und Freigabe dürfen nicht durch dieselbe Instanz allein erfolgen.
- Ein nicht ausgeführtes Testlabor ist keine Zertifizierung.
- Endlose Selbstprüfungszyklen benötigen eine feste Abbruchgrenze.

## Konsequenz

Der Schreibkern ist eingefroren und gehört nicht zum aktiven MVP. Eine spätere Wiederaufnahme ist nur als separates Projekt mit echter Testinstanz und unabhängiger menschlicher WordPress-Prüfung zulässig.
