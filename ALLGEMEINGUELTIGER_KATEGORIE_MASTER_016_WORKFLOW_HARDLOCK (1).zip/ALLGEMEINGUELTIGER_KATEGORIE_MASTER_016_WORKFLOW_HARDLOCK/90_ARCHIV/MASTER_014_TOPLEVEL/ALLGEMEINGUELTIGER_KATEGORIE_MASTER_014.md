# ALLGEMEINGÜLTIGER KATEGORIE-MASTER 014 – DATAFORSEO-GATE IN BESTEHENDEN WORKFLOW INTEGRIERT

## Zweck

Diese Masterdatei ist die vollständige, themenunabhängige Fortschreibung von Master 011. Sie ersetzt weder das bestehende Kategorie-MVP noch eröffnet sie ein neues System. Sie integriert DataForSEO als kontrolliertes Gate in den bestehenden Drei-Säulen-Kategorieprozess.

## Zielbild

Aus einem fachlich recherchierten Projektkonzept entsteht durch Chat/Master eine starke Struktur aus:

- **Content** – systematische Evergreen-/Ratgeberhierarchie;
- **Marketplace/HivePress** – Angebots-, Anbieter-, Leistungs- und Transaktionsintention;
- **Journal** – redaktionelle, aktuelle, inspirierende oder erzählerische Aufgabe.

DataForSEO dient danach und während des Korrekturlaufs als Evidenz für starke Kategorienamen, bessere Keywordalternativen, fehlende Keywordgruppen, Keywordhierarchie, Suchintention, Longtails und Kannibalisierung.

## Entscheidende Sicherheitsnetze

1. Chat/Master müssen bereits vor DataForSEO fachlich breit und plausibel entwerfen.
2. Global-Coverage sucht projektweit nach vollständig vergessenen Hauptthemen.
3. Detailresearch sucht innerhalb der Hauptthemen nach besseren Kategorienamen, Unterthemen, Longtails und Overlap.
4. Kein API-Signal verändert die Architektur automatisch.
5. Ein technischer PASS ist nur `READY_FOR_VISIBLE_SIGHT_REVIEW`.
6. Der komplette Baum wird vor FINAL gemeinsam sichtbar geprüft.
7. Die finale Freigabe ist an den unveränderten Review-Scope gebunden.

## Dublettenregel

- identischer sichtbarer Kategoriename portalweit: **BLOCK**;
- ähnliche Inhalte mit unterschiedlichen sichtbaren Namen: **zulässig**, wenn fachlich/funktional sinnvoll;
- gleiche Primärkeyword-Ownership in derselben Säule: **BLOCK**;
- säulenübergreifender semantischer Overlap: Review + klare Trennbegründung, nicht automatisch Merge.

## Sicherheitsstatus

Das DataForSEO-Gate ist read-only gegenüber Portal-Inhalten. Es enthält keine WordPress-/HivePress-Schreibfunktion für Kategorien, Seiten, Beiträge oder Menüs.

## Vollständige neue Dokumentation

Siehe `13_DATAFORSEO_GATE_INTEGRATION/`. Dort liegen Workflow, Fehlerkatalog, Entscheidungsregister, lückenloses Arbeitsprotokoll, Testmatrix, Sichtprüfungsprotokoll, Plugin, Quellcode und Release-Audit.
