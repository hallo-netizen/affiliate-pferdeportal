=== Affiliate-Portal Kategorie-Workflow ===
Version: 1.5.0
Status: TESTKANDIDAT
Plugin-Slug: affiliate-portal-kategorie-workflow

GRUNDLAGE
---------
V1.5.0 ist ein ursachenbezogenes Update derselben bestehenden Plugin-Linie V1.4.0. Kein Parallelplugin und kein neues Kategoriesystem. Die DataForSEO-Verbindung bleibt Gate/Evidenz innerhalb des bestehenden Workflows.

ROOTFIX
-------
Master 014 modellierte tragfähige Beitragsrichtungen fälschlich nur unterhalb der verbindlichen Kategoriegrenze. V1.5.0 unterstützt die korrigierte Master-015-Logik:
- konkrete Fachthemen dürfen weitere echte Content-Kategorien wie FAQ, Tipps, Beratung, Vergleich, Ausrüstung/Werkzeug usw. erhalten,
- aber nur wenn diese Richtung mindestens 3 wichtige eigenständige Longtails trägt,
- typischer Zielbereich: 3–5 oder mehr tragfähige Beiträge,
- keine starre Pflichtliste,
- konkrete Beiträge liegen erst unter dem letzten freigegebenen Content-Blatt.

DATAFORSEO-TIEFENGATE
---------------------
Detailresearch nutzt weiterhin genau 1 Keyword-Ideas-Call je Research-Cluster. Zusätzlich zu den deklarierten Cluster-Seeds werden die Primärkeywords der aktiven Content-Blätter kontrolliert in denselben Call aufgenommen. Dadurch bleiben tiefe FAQ-/Tipps-/Beratungs-/Ausrüstungs-Kategorien recherchierbar, ohne zusätzliche Paid Calls.

Bei mehr als 200 effektiven Seeds wird BLOCKED statt stiller Kürzung ausgelöst.

DUBLETTEN
---------
R-046 bleibt unverändert:
- identischer sichtbarer Kategoriename portalweit: BLOCK,
- wiederkehrende Richtungen deshalb kontextuell benennen, z. B. „FAQ zu Sauerteig“ statt mehrfach nur „FAQ“.

SICHERHEIT
----------
- APKW_CONTENT_WRITE_CAPABILITY=false.
- Keine WordPress-/HivePress-Portal-Content-Writes.
- Keine Kategorien, Seiten, Beiträge oder Menüs werden angelegt/geändert/gelöscht.
- Finalprüfung: 0 DataForSEO-Requests.

WORKFLOW
--------
Projektkonzept → vollständiger Drei-Säulen-Erstentwurf → sichtbare Erstprüfung → Global-Coverage/Entscheidung → Detailresearch → Master-Korrektur → read-only Gesamtprüfung → erneute sichtbare Gesamtbaumprüfung → hashgebundene FINAL-Freigabe.

PRÜFUNG
-------
93/93 automatisierte Positiv-/Negativtests PASS im Source-Stand. Finaler Installer wird frisch entpackt und mit derselben Testsuite erneut geprüft.

VERBINDLICHE MASTERDATEI
------------------------
ALLGEMEINGUELTIGER_KATEGORIE_MASTER_015_CONTENTKATEGORIE_ROOTFIX.zip
