# Workflow V1.5.0

1. Projektkonzept und Scope.
2. Vollständiger Drei-Säulen-Erstentwurf im Chat/Master.
3. Content bis zur realen beitragstragenden Endkategorie planen. Unter konkreten Fachthemen mögliche Richtungs-Kategorien offen prüfen.
4. Sichtprüfung des Erstentwurfs im Chat.
5. Kostenfreier Preflight.
6. Global-Coverage und vollständige Gap-Entscheidung.
7. Detailresearch: Overview + ein Keyword-Ideas-Call je Research-Cluster. Deklarierte Cluster-Seeds plus Primärkeywords aktiver Content-Blätter im selben Call.
8. Master-Korrektur von Namen, Hierarchie, fehlenden Gruppen, Intent, Longtails und Kannibalisierung.
9. Content-Blatt benötigt mindestens 3 reale node-gebundene DataForSEO-Longtails; 2 oder weniger = BLOCK.
10. Read-only Gesamtprüfung.
11. Vollständiger korrigierter Baum sichtbar im Chat.
12. Hashgebundene FINAL-Freigabe.

Keine Beitragsarten-Schablone. FAQ, Tipps, Beratung, Vergleich, Ausrüstung/Werkzeug usw. werden nur bei echter Tragfähigkeit zu Kategorien.
