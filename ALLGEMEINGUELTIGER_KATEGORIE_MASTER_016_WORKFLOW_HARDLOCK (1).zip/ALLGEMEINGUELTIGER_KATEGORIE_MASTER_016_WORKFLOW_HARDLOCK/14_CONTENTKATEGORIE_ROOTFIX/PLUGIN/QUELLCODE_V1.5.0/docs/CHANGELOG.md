# Changelog

## 1.5.0 – Contentkategorie-Hierarchie Rootfix
- Content-Blatt-Mindestmenge 4 → 3 reale node-gebundene Longtails; 3–5+ regulärer Zielbereich.
- Tragfähige Beitragsrichtungen als echte Content-Endkategorien unterstützt.
- Primärkeywords aktiver Content-Blätter werden in denselben Cluster-Keyword-Ideas-Call aufgenommen.
- Effektive Cluster-Seeds >200 => BLOCKED, keine stille Kürzung.
- R-046 unverändert: wiederkehrende sichtbare Richtungsnamen müssen kontextuell eindeutig sein.
- Neue Positiv-/Negativtests für FAQ-Endkategorie, 3/2-Longtail-Grenze, Tiefenseeds und Namensdubletten.
- Keine Portal-Schreibfunktion ergänzt.

# Changelog

## 1.4.0 – DataForSEO-Gate integriert in bestehende Plugin-Linie
- Kein Parallelplugin: gleicher Plugin-Name und gleicher Slug wie V1.3.0.
- Grundlage bleibt der bestehende 3-Säulen-Kategorie-Workflow.
- Global-Coverage-Gate ergänzt: genau 1 Paid Keyword-Ideas-Call vor Detailresearch.
- Projektweite Discovery-Seeds explizit gebunden; Projektname wird nicht autonom als Seed genutzt.
- Provider-Relevanz + Suchvolumen gemeinsam für Global-/Cluster-Coverage verwendet.
- Global-Gaps müssen vor Paid Detailresearch abgedeckt oder fachlich entschieden sein.
- Leere/unauswertbare Global-Coverage blockiert fail-closed.
- Haupt-/Unterkategorien und Research-Cluster dürfen nach Global-Coverage korrigiert werden, ohne Global erneut zu bezahlen, solange Projektscope/Seeds unverändert bleiben.
- Kategorienamen-/Primärkeywordprüfung, stärkere Alternativen, Intentprüfung, Hierarchie, Longtails und Kannibalisierung aus V1.3 erhalten und erweitert.
- Identische sichtbare Kategorienamen bleiben portalweit hart blockiert.
- Semantisch ähnliche, unterschiedlich benannte Kategorien über Content/Marketplace/Journal bleiben mit sauberer Trennung zulässig.
- V1.3-Knotenvertrag nicht unnötig um ein neues Pflicht-Funktionsfeld erweitert.
- Schema Category/Research auf 1.3 angehoben; Global-Coverage-Paket Schema 1.0 ergänzt.
- Kostenfreie Detail-Vorprüfung führt jetzt das vollständige Global-Coverage-Gate aus.
- Verbindliche sichtbare Gesamtbaumprüfung vor FINAL ergänzt.
- `READY_FOR_VISIBLE_SIGHT_REVIEW` strikt von `PASS_FINAL_APPROVED` getrennt.
- Review-Scope-SHA-256 verhindert Strukturänderungen nach Sichtfreigabe.
- FINAL_APPROVED durchläuft dieselben DataForSEO-/Longtail-/Kannibalisierungsgates wie READ_ONLY_PREVIEW.
- Schema Category/Research final auf 1.4 angehoben.
- 89 lokale Positiv-/Negativtests.

## 1.3.0
- Drei verpflichtende Säulen Content + Marketplace/HivePress + Journal.
- DataForSEO Keyword Overview + begrenzte Cluster Keyword Ideas.
- starke Kategorienamen/bessere Keywords, Cluster-Gaps, Hierarchie, Intents, Longtails, Kannibalisierung.
- Scope-/Hash-Bindung und read-only Finalprüfung.

## 1.2.0
- erster DataForSEO-Testkandidat der bestehenden Plugin-Linie.
