# Schnittstellenvertrag V1.5.0

## Schema
Kategoriepaket und Research-Paket bleiben schema-kompatibel zu `1.4`; der Rootfix benötigt kein neues Pflichtfeld und bricht keine V1.4-Pakete.

## RESEARCH_DRAFT
- Format `affiliate-portal-category-package`, Schema `1.4`, Modus `RESEARCH_DRAFT`.
- Projekt-Scope + Discovery-Seeds.
- Research-Cluster.
- vollständige Content-/Marketplace-/Journal-Knoten.
- Content darf bis zu tragfähigen Beitragsrichtungs-Kategorien reichen; kein separates Pflichtfeld `functional_intent`.

## Global-Coverage
Unverändert: genau ein projektweiter kontrollierter Call nach Bestätigung. Architektur wird nicht autonom verändert.

## Detailresearch
- Keyword Overview für geplante sichtbare Namen + Primärkeywords.
- genau ein Keyword-Ideas-Call je Research-Cluster.
- effektive Cluster-Seeds = deklarierte Cluster-Seeds + Primärkeywords aktiver Content-Blätter dieses Clusters.
- max. 200 effektive Seeds; Überschreitung => BLOCKED, kein stilles Abschneiden.
- keine zusätzlichen Calls durch Content-Blatt-Tiefenseeds.

## Finaler Strukturentwurf
Modus `READ_ONLY_PREVIEW`, mit gebundener Research-ID/Hash. Content-Blätter benötigen mindestens 3 reale node-gebundene Longtails. Danach `READY_FOR_VISIBLE_SIGHT_REVIEW`.

## FINAL_APPROVED
Nur nach sichtbarer Gesamtbaumprüfung und passendem `review_scope_sha256`. Jede Strukturänderung invalidiert die Freigabe.

## Sicherheit
Kein WordPress-/HivePress-Content-Write. Finaler Prüfpfad ohne DataForSEO-Request.
