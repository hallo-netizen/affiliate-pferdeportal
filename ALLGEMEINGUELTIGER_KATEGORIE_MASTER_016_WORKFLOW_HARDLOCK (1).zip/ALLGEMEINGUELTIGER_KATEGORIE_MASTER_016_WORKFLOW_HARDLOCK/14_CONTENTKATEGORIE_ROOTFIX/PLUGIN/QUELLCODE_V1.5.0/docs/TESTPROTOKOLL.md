# Testprotokoll V1.5.0

Status: LOCAL_RELEASE_CANDIDATE_PASS / LIVE_RUN_PENDING

## Source
- 93/93 automatisierte Positiv-/Negativtests PASS.
- PHP-Lint 10/10 PASS.
- JSON-Parse PASS.
- Portal-Content-Write-API-Scan PASS.
- externe Endpoint-Allowlist PASS.

## Rootfix-Pflichtfälle
- 3 Longtails => Mengenregel PASS.
- 2 Longtails => BLOCK.
- Fachthema → tragfähige FAQ-Kategorie → 3 providerbelegte Longtails => PASS.
- tiefe Content-Blatt-Primärkeywords werden im selben Research-Cluster-Call mitgeführt.
- dadurch 0 zusätzliche Paid Calls.
- >200 effektive Cluster-Seeds => BLOCK statt stillem Verlust.
- mehrfach sichtbarer Name `FAQ` => weiterhin global BLOCK; Kontextname erforderlich.

## Regression
Bestehende V1.4-Gates vollständig erneut geprüft: drei Säulen, Global-Coverage, Scope-/Hashbindung, Naming, Intent, Hierarchie, Keyword-Ownership, Longtail-Bindung, Kannibalisierung, Sichtreview, FINAL_APPROVED, 0 externe Requests im Finalpfad, 0 Portal-Content-Writes.

## Installer/Fresh-Unpack
Der aus diesem Source-Stand gebaute Installer wird im Master-Release-Audit frisch entpackt und vollständig erneut geprüft. Master-Freigabe ist nur bei 93/93 PASS, PHP/JSON PASS und byteidentischem Source↔Fresh-Unpack zulässig.
