# Workflow-Hard-Audit V1.5.0

## Root-Cause
Die frühere Regelmodellierung ließ FAQ/Beratung/Vergleich/Pflege usw. nur unterhalb der Kategoriegrenze zu. Dadurch endete die Content-Hierarchie fachlich zu früh.

## Korrektur
- gleiche Plugin-Linie, kein Parallelplugin;
- Content-Blatt-Minimum 3 reale Longtails;
- tragfähige Beitragsrichtungen können echte Content-Blätter sein;
- tiefste Blatt-Primärkeywords werden in denselben Cluster-Research-Call aufgenommen;
- >200 effektive Seeds blockieren;
- R-046-Namensdubletten bleiben hart;
- Journal-Flachlogik bleibt unberührt;
- keine Portal-Content-Writes.

## Regression
Unveränderte Produktionsklassen: Settings, DataForSEO-Adapter, Inventory, Comparator, Admin. Geändert wurden nur Hauptversion, Research-Orchestrierung, Research-Evidenz und Validator sowie Tests/Dokumentation.

## Prüfumfang
93 automatisierte Positiv-/Negativtests im Source-Stand; darunter neue Rootfix-Fälle. Zusätzlich PHP-Lint, JSON-Parse, Write-API-Scan, Endpoint-Allowlist und Fresh-Unpack-Prüfung.
