# CODEX-AUFTRAG – Unabhängiges Hard-Audit V1.5.0

Prüfe ausschließlich den gelieferten V1.5.0-Quellcode. Keine Architektur neu erfinden.

Pflichtprüfungen:
1. Bestehende Plugin-Linie, kein Parallelplugin.
2. Content-Blatt: 3 Longtails PASS, 2 BLOCK.
3. Fachthema → funktionale Content-Endkategorie (z. B. FAQ) → Longtail-Beiträge technisch möglich.
4. Content-Blatt-Primärkeywords werden in denselben Research-Cluster-Call aufgenommen; keine zusätzlichen Calls.
5. >200 effektive Cluster-Seeds blockieren statt stillem Verlust.
6. R-046-Dublettenblock bleibt wirksam.
7. DataForSEO-Evidenzbindung, Ownership, Hierarchie, Kannibalisierung unverändert hart.
8. 0 Portal-Content-Writes.
9. Finalprüfung 0 externe Requests.
10. Bestehende Testsuite vollständig ausführen und neue Negativfälle ergänzen, falls konkrete Lücke gefunden wird.

Nur konkrete Findings melden. Keine Änderung ohne belegten Fehler.
