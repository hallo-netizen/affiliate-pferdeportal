# DataForSEO-Gate-Vertrag V1.5.0

## Rolle
DataForSEO liefert Evidenz und Lückensignale. Chat/Master bleiben Architektur-Owner.

## Endpoints
- `/v3/appendix/user_data` – Verbindungstest.
- `/v3/dataforseo_labs/google/keyword_ideas/live` – Global-/Cluster-Discovery.
- `/v3/dataforseo_labs/google/keyword_overview/live` – exakte Namen/Primärkeywords.

## Kostenkontrolle
- Preflights 0 externe Requests.
- Global-Coverage genau 1 bestätigter Paid Call.
- Detailresearch genau 1 Keyword-Ideas-Call je Cluster plus notwendige Overview-Batches.
- Content-Blatt-Tiefenseeds werden in bestehende Cluster-Calls integriert; keine Zusatzcalls.
- Finalprüfung 0 Provider-Requests.

## Seed-Vertrag
- projektweite Global-Seeds bleiben ausschließlich deklarierte Discovery-Seeds.
- Clusterresearch verwendet deklarierte Cluster-Seeds plus Primärkeywords aktiver Content-Blätter desselben Clusters.
- max. 200 effektive Seeds; Überschreitung blockiert.

## Evidenzregeln
- sichtbarer Kategoriename und Primärkeyword werden geprüft.
- stärkere Alternative => Review/Begründung, keine autonome Umbenennung.
- Search Intent => Evidenz, fachlich begründbare Abweichung möglich.
- relevante unbesetzte Core-Gruppen benötigen Owner oder dokumentierte Entscheidung.
- finales Content-Blatt: mindestens 3 reale node-gebundene Longtails; 2 oder weniger = BLOCK.
- gleiche Longtail-Ownership an mehreren Content-Blättern = BLOCK.
- Paket-/Scope-Hashes schützen Bindung und Manipulationsfreiheit.
