# Known limitations V1.5.0

- Plugin entscheidet nicht autonom, welche Beitragsrichtung fachlich sinnvoll ist; Architektur bleibt Chat/Master-Aufgabe.
- DataForSEO belegt Suchdaten, ersetzt keine menschliche Sichtprüfung.
- Wiederkehrende Kategorienamen müssen wegen R-046 kontextuell eindeutig sein.
- V1.5.0 ist bis zum echten WordPress-/DataForSEO-Lauf TESTKANDIDAT; lokale Tests sind kein Live-PASS.
