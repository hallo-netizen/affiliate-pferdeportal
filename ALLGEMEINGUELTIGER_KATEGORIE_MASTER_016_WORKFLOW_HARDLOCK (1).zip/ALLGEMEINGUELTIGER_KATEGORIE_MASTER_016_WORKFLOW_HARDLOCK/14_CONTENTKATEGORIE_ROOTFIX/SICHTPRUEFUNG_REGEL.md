# Sichtprüfungsregel Content-Rootfix – Master 016

Die gesamte Content-Hierarchie muss in allen drei sichtbaren Pflichtreviews vollständig bis zur letzten geplanten Kategorie erkennbar sein. Unter jeder letzten Kategorie werden die vorgesehenen Einzelbeiträge/Longtails als nicht-bindende Ausarbeitung sichtbar gemacht, soweit sie für die fachliche Prüfung benötigt werden.

Eine Sichtfreigabe ist nur gültig, wenn der exakte dargestellte Review-Scope-SHA-256 über den kontrollierten WordPress-Adminpfad serverseitig signiert wurde. Strukturänderung danach = Freigabe ungültig.
