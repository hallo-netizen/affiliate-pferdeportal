# Verbindlicher Contentkategorie-Rootfix – Master 016

1. Fachthemen von breit nach konkret gliedern; keine erzwungene Symmetrie.
2. Für konkrete Fachthemen sinnvolle Richtungen wie FAQ, Tipps, Beratung, Vergleich, Ausrüstung/Werkzeug usw. prüfen.
3. Eine Richtung wird nur dann eigene Content-Kategorie, wenn mindestens 3 wichtige, eigenständige, node-gebundene DataForSEO-Longtails belegt sind.
4. Einzelbeiträge liegen erst unter der letzten freigegebenen Kategorie.
5. Gibt es keine tragfähige Richtungsunterteilung, darf das konkrete Fachthema selbst Blatt sein.
6. Wiederholte Richtungen brauchen kontextuell eindeutige sichtbare Namen.
7. Detailresearch nimmt aktive Content-Blatt-Primärkeywords als kontrollierte Tiefen-Seeds im selben Cluster-Call mit; kein Zusatzcall allein wegen des Rootfixes.
8. Dieser Rootfix gilt für Content. Journal bleibt flach; Marketplace bleibt markt-/angebotsorientiert.
9. Der Rootfix wird ausschließlich innerhalb des 14-Stufen-HARDLOCK-Workflows angewandt.
