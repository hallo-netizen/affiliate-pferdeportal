# Fehlerkatalog – Contentkategorie-Rootfix

## C-001 – Beitragsrichtungen fälschlich außerhalb der Kategoriehierarchie
**Befund:** R-013/R-037/R-095 in Master 014 behandelten FAQ, Beratung, Vergleich, Pflege usw. nur als Vorschläge unter Endkategorien.
**Auswirkung:** Fachthemen wurden zu früh zu Blättern; notwendige WordPress-Kategorien für tragfähige Beitragscluster fehlten.
**Rootfix:** R-011, R-013, R-037, R-075, R-076, R-095 und R-113 korrigiert; R-116 bis R-119 ergänzt.

## C-002 – Vierer-Mindestmenge zu starr
**Befund:** Plugin blockierte Content-Blätter mit 3 tragfähigen Longtails.
**Rootfix:** Minimum 3, typischer Zielbereich 3–5 oder mehr. 2 => BLOCK.

## C-003 – Tiefe Blätter konnten im breiten Clusterresearch untergehen
**Befund:** Detailresearch nutzte nur Research-Cluster-Seeds. Ein tiefer FAQ-/Tipps-/Beratungs-Core konnte bei breiten Clustern fehlen.
**Rootfix:** Primärkeywords aktiver Content-Blätter werden zusätzlich in denselben Cluster-Call aufgenommen. Keine Extra-Calls.

## C-004 – Wiederkehrende Namen kollidieren mit R-046
**Befund:** Mehrfach nur `FAQ` wäre portalweit unzulässig.
**Rootfix:** Kontextuelle sichtbare Namen wie `FAQ zu <Thema>`; R-046 bleibt unverändert hart.

## C-005 – Risiko einer starren Beitragsarten-Schablone
**Rootfix:** offene, nicht abschließende Richtungsprüfung; nur Richtungen mit echter Suchintention und Mindestsubstanz werden Kategorien.
