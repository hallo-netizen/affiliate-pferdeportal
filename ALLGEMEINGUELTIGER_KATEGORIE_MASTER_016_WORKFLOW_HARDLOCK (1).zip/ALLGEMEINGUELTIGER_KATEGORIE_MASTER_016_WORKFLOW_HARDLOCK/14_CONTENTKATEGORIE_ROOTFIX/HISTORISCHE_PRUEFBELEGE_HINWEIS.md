# Historische Prüfbelege – NICHT NORMATIV IN MASTER 016

Der gesamte Ordner `14_CONTENTKATEGORIE_ROOTFIX` dokumentiert die Entstehung des Content-Rootfixes. Normativ bleiben nur die in `15_WORKFLOW_HARDLOCK/MASTER_LOCK.json` ausdrücklich gelisteten Dateien `VERBINDLICHER_ROOTFIX_WORKFLOW.md` und `SICHTPRUEFUNG_REGEL.md`.

Eingebettete ältere Pluginstände V1.5.0 sind **inaktiv/historisch**. Aktive Plugin-Linie in Master 016 ist ausschließlich V1.6.1 unter `15_WORKFLOW_HARDLOCK/PLUGIN/`.
