# Plugin-Integrationsnachweis V1.5.0

- bestehender Plugin-Slug unverändert: `affiliate-portal-kategorie-workflow`
- kein Parallelplugin
- Installer SHA-256: `a6d9b22b81504261a1342a8806644f406a59a2f8329f600841eeee16e6bee28e`
- Source-ZIP SHA-256: `206bc40622cf56f485a0d9b49ad60adab9368fdcc8da7d37b71463e8e43bbe64`
- Source-Dateien: 34 inklusive internem SHA256SUMS
- Produktionsänderungen gegenüber V1.4: Hauptversion + Research-Orchestrierung + Research-Evidenz + Validator; übrige Produktionsklassen unverändert
- Source-Tests: 93/93 PASS
- Fresh-Unpack-Tests: 93/93 PASS
- PHP-Lint Fresh-Unpack: PASS
- JSON-Parse Fresh-Unpack: PASS
- Source ↔ Fresh-Unpack: 34/34 byteidentisch
- interner Source-Manifestcheck: PASS
- Installer ZIP-Test: PASS
- Portal-Content-Write-Scan: PASS
- Endpoint-Allowlist: PASS
- Live-Status: TESTKANDIDAT; echter neuer WordPress/DataForSEO-Detail-/Final-Lauf ausstehend
