# Arbeitsprotokoll – Contentkategorie-Rootfix

1. Master 014 vollständig entpackt und aktives Regelwerk gelesen.
2. Widerspruch bestätigt: R-013/R-037/R-095 schoben Beitragsrichtungen unter die Kategoriegrenze; R-113 verlangte 4 Longtails.
3. Historische Vollmaster-Fassung geprüft: dieselbe alte Modellierung war dort ausdrücklich enthalten; Ursache ist damit Regelmodell, nicht nur Darstellung.
4. Aktives Regelwerk korrigiert; historische Archive unverändert gelassen.
5. R-116 bis R-119 ergänzt: Fachthema → tragfähige Beitragsrichtungs-Kategorie → Einzelbeiträge; Kontextnamen; keine Schablone.
6. Plugin V1.4-Codebasis unverändert als Grundlage kopiert und nur ursachenbezogen fortgeschrieben.
7. Validator-Mindestmenge 4 → 3 geändert.
8. Research-Evidence-Mindestmenge 4 → 3 geändert.
9. Detailresearch erweitert: aktive Content-Blatt-Primärkeywords werden in denselben Research-Cluster-Call aufgenommen; >200 Seeds blockiert statt still gekürzt.
10. Positiv-/Negativtests ergänzt: 3 PASS, 2 BLOCK, echte FAQ-Endkategorie PASS, tiefer Blattseed im bestehenden Cluster-Call, wiederholtes nacktes `FAQ` bleibt BLOCK.
11. Gesamte bestehende Testsuite erneut ausgeführt.
12. Danach PHP-Lint, JSON-Parse, Write-API-Scan, Endpoint-Allowlist, Source-/Fresh-Unpack-Tests, Hashvergleiche und Mastermanifest erneut ausführen.
13. Finaler Plugin-Source-Stand: 93/93 PASS, PHP-Lint 10/10 PASS, JSON-Parse PASS, Write-API-Scan PASS, Endpoint-Allowlist PASS.
14. Installer aus exakt diesem Source-Stand gebaut und frisch entpackt: 93/93 PASS; 34/34 Source↔Fresh-Unpack byteidentisch; internes SHA256SUMS PASS; ZIP-Test PASS.
15. Nur eine neue Pluginversion in derselben Linie erzeugt: V1.5.0. Kein Zwischeninstaller ausgeliefert.
