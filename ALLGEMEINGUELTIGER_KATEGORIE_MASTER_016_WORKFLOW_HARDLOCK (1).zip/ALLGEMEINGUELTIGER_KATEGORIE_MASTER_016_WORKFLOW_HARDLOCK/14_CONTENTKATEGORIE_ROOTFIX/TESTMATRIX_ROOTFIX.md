# Testmatrix – Rootfix

| Fall | Erwartung | Ergebnis |
|---|---|---|
| Content-Blatt mit 3 Longtails | PASS Mengenregel | PASS |
| Content-Blatt mit 2 Longtails | BLOCK | PASS |
| Fachthema → FAQ-Endkategorie → 3 belegte Longtails | PASS | PASS |
| Blatt-Primärkeyword im Cluster-Call | vorhanden | PASS |
| zusätzlicher Paid Call durch Tiefenseed | keiner | PASS |
| >200 effektive Seeds | BLOCK | PASS |
| zweimal sichtbarer Name FAQ | global BLOCK | PASS |
| R-046 kontextueller Name | zulässig | PASS |
| Finalprüfung externe Requests | 0 | PASS |
| Portal-Content-Write-APIs | 0 | PASS |
| gesamte Regression | 93/93 | PASS |
| Fresh-Unpack gesamte Regression | 93/93 | PASS |
