# Entscheidungsregister – Contentkategorie-Rootfix

| ID | Entscheidung | Status |
|---|---|---|
| C-D01 | Bestehende Plugin-Linie fortführen, kein Parallelplugin | VERBINDLICH |
| C-D02 | Tragfähige Beitragsrichtung ist echte Content-Kategorie | VERBINDLICH |
| C-D03 | Content-Kategorie Minimum 3 wichtige eigenständige Longtails; typischer Zielbereich 3–5+ | VERBINDLICH |
| C-D04 | Keine starre Beitragsartenliste oder Pflichtbesetzung | VERBINDLICH |
| C-D05 | Wiederkehrende Richtungsnamen kontextuell eindeutig; R-046 bleibt | VERBINDLICH |
| C-D06 | Content-Blatt-Primärkeywords erweitern denselben Cluster-Research-Call, keine Zusatzcalls | VERBINDLICH |
| C-D07 | Journal-Rubriken bleiben flach; Rootfix gilt nicht als Journal-Rubriken-Schablone | VERBINDLICH |
| C-D08 | Vor Paid-Detailresearch sichtbare Erstentwurfsprüfung; vor FINAL erneute Sichtprüfung | VERBINDLICH |
