#!/usr/bin/env python3
"""Merge a Google Keyword Planner CSV export into the validation template.
Read-only with respect to portal systems. It writes a new CSV only.
"""
from __future__ import annotations
import argparse, csv, re
from pathlib import Path

ALIASES = {
    "keyword": ["keyword", "keywords", "suchbegriff"],
    "avg_monthly_searches": ["avg. monthly searches", "average monthly searches", "durchschn. suchanfragen pro monat", "durchschnittliche suchanfragen pro monat"],
    "competition": ["competition", "wettbewerb"],
    "competition_index": ["competition (indexed value)", "wettbewerb (indexierter wert)"],
    "low_top_of_page_bid": ["top of page bid (low range)", "gebot für obere positionen (unterer bereich)"],
    "high_top_of_page_bid": ["top of page bid (high range)", "gebot für obere positionen (oberer bereich)"],
}

def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip().lower())

def resolve(headers, names):
    mapping={norm(h):h for h in headers}
    for n in names:
        if norm(n) in mapping: return mapping[norm(n)]
    return None

def read_rows(path):
    for enc in ("utf-8-sig","utf-16","cp1252"):
        try:
            with path.open(encoding=enc,newline="") as f:
                sample=f.read(4096); f.seek(0)
                dialect=csv.Sniffer().sniff(sample, delimiters=",;\t")
                return list(csv.DictReader(f,dialect=dialect))
        except Exception:
            continue
    raise ValueError(f"CSV nicht lesbar: {path}")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("template",type=Path)
    ap.add_argument("planner_export",type=Path)
    ap.add_argument("output",type=Path)
    args=ap.parse_args()
    template=read_rows(args.template); raw=read_rows(args.planner_export)
    if not raw: raise ValueError("Keyword-Planner-Export ist leer")
    headers=list(raw[0])
    cols={k:resolve(headers,v) for k,v in ALIASES.items()}
    if not cols["keyword"]: raise ValueError("Keyword-Spalte nicht erkannt")
    index={norm(r.get(cols["keyword"],"")):r for r in raw}
    fields=list(template[0]) if template else list(csv.DictReader(args.template.open(encoding="utf-8-sig")).fieldnames or [])
    out=[]
    for row in template:
        hit=index.get(norm(row.get("seed_keyword","")))
        if hit:
            for target in ("avg_monthly_searches","competition","competition_index","low_top_of_page_bid","high_top_of_page_bid"):
                col=cols.get(target)
                if col: row[target]=hit.get(col,"")
            row["status"]="METRICS_IMPORTED_SERP_REVIEW_PENDING"
        else:
            row["status"]="NO_EXACT_MATCH"
        out.append(row)
    with args.output.open("w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(out)

if __name__=="__main__": main()
