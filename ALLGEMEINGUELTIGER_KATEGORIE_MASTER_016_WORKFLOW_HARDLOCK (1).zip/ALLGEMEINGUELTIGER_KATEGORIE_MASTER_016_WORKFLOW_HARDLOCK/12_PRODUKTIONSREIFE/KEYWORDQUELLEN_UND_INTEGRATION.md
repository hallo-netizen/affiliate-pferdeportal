# Kostenlose Keywordquellen und Integration

Stand: 30.07.2026

## Primärquelle: Google Ads Keyword Planner

Der Keyword Planner ist die bevorzugte kostenlose Primärquelle. Er liefert
Keywordideen, historische durchschnittliche Suchanfragen, Wettbewerb und
Gebotsspannen. Für den Zugriff ist ein eingerichtetes Google-Ads-Konto nötig;
Google verlangt für Grundfunktionen die abgeschlossene Kontoeinrichtung mit
Rechnungsdaten. Werte können gerundet oder als Bandbreite vorliegen.

### Praktischer MVP-Weg ohne API

1. `VALIDIERUNGSVORLAGE_KEYWORDS.csv` mit Seed-Keywords füllen.
2. Im Keyword Planner Deutschland, Deutsch und Google als Suchnetz festlegen.
3. Seed-Liste hochladen beziehungsweise „Suchvolumen und Prognosen abrufen“.
4. Originalexport unverändert unter `ROHDATEN/` speichern.
5. Felder Durchschnittssuchen, Wettbewerb, Gebotsspannen und Monatswerte in
   eine Auswertungsdatei übernehmen.
6. Für jeden Cluster zusätzlich die sichtbare SERP-Aufgabe manuell prüfen.
7. Entscheidung: `KEEP_CATEGORY`, `MERGE`, `ARTICLE_ONLY`, `DEFER` oder `BLOCK`.

### Automatisierung über Google Ads API

Die API stellt `KeywordPlanIdeaService.GenerateKeywordIdeas` und
`GenerateKeywordHistoricalMetrics` bereit. Erforderlich sind Google-Ads-Konto,
OAuth, Customer-ID und ein genehmigter Developer-Token. Keyword-Planning-Dienste
sind beim Explorer-Zugang eingeschränkt; praktisch ist Basic oder Standard
Access erforderlich. Ergebnisse werden monatlich gecacht, nicht bei jedem Lauf
neu abgefragt.

## Ergänzung: Google Trends

Google Trends misst relative Suchpopularität, Region und Saisonalität, aber kein
absolutes Suchvolumen. Niedrige Suchbegriffe können als 0 erscheinen. Die
offizielle Trends API befindet sich derzeit in einer Alpha mit Bewerbungsverfahren;
bis zum Zugang wird die Weboberfläche beziehungsweise ein manueller Export genutzt.

## Nach dem Start: Google Search Console

Search Console liefert für die eigene Website reale Impressionen, Klicks,
Positionen und Queries. Sie ist keine Vorabquelle für ein neues Portal, sondern
die verbindliche Feedbackschleife nach Indexierung.

## Nicht als alleinige Freigabequelle

Autocomplete-/Suggest-Scraper und kostenlose Drittanbieter-Schätzwerte dürfen
Ideen liefern, aber ohne Herkunfts- und Qualitätsnachweis kein Produktionsgate
allein bestehen lassen.

## Offizielle Dokumentation

- Google Ads Keyword Planner: https://support.google.com/google-ads/answer/7337243
- Keyword Ideas API: https://developers.google.com/google-ads/api/docs/keyword-planning/generate-keyword-ideas
- Historical Metrics API: https://developers.google.com/google-ads/api/docs/keyword-planning/generate-historical-metrics
- API Access Levels: https://developers.google.com/google-ads/api/docs/api-policy/access-levels
- Google Trends API Alpha: https://developers.google.com/search/apis/trends
- Google Trends Datenerklärung: https://support.google.com/trends/answer/4365533
- Search Console Performance: https://support.google.com/webmasters/answer/7576553
