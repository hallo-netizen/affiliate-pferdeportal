# Verbindliche Produktionsreife-Regeln

## PR-001 – Struktur-PASS und Produktions-PASS trennen

Ein strukturell bestandenes Portalmodell bleibt bis zum Bestehen aller einschlägigen Produktionsgates auf PRODUCTION_VALIDATION_REQUIRED.

## PR-002 – Intent auf zwei Ebenen führen

Der Kategorie-Knoten erhält eine dominante Kategorieintention. Longtail- oder Seitenkandidaten erhalten zusätzlich eine eigene Query-/Seitenintention. Ein pauschaler Kategorie-Intent darf nicht als Einzelquery-Analyse ausgegeben werden.

## PR-003 – Externe Keyword- und SERP-Validierung

Dichte, mehrdeutige, strategisch zentrale oder kannibalisierungsgefährdete Cluster müssen vor Produktionsfreigabe mit aktuellen Keyworddaten und einer SERP-Aufgabenprüfung validiert werden.

## PR-004 – Scope bleibt internes Steuerungsfeld

scope, exclusions, quality_notes und vergleichbare Steuerungsmetadaten sind INTERNAL_ONLY. Sie dürfen weder unverändert noch automatisiert als Onpage-Text publiziert werden.

## PR-005 – Monetarisierungsrolle je Hauptast

Jeder Hauptast erhält eine belegte Rolle: DIRECT_AFFILIATE, LEADGEN_MARKETPLACE, EDITORIAL_SUPPORT, DEFERRED oder BLOCKED. Fehlende klassische Affiliateprogramme erzwingen nicht automatisch die Löschung eines fachlich strategischen Astes, müssen aber die Produktionspriorität beeinflussen.

## PR-006 – Risiko- und Publikationsgate

Rechtliche, gesundheitliche, medizinische, bauliche, sicherheits- oder genehmigungsrelevante Themen erhalten eine Risikoklasse und ein verbindliches Publikationsgate. Bei EXPERT_REVIEW_REQUIRED ist Veröffentlichung bis zur dokumentierten Fachprüfung blockiert.

## PR-007 – Ausschlüsse dauerhaft dokumentieren

Bewusst ausgeschlossene Themen werden mit Grund, Entscheidungstyp, Datum und Wiedervorlage-Trigger in einem Ausschlussregister geführt.

## PR-008 – Quellenhierarchie für Keyworddaten

Google Ads Keyword Planner/API dient als primäre kostenlose Nachfragequelle. Google Trends ergänzt relative Entwicklung und Saisonalität. Google Search Console dient nach Veröffentlichung als reale Feedbackquelle. Unoffizielle Suggest-Scraper dürfen nur als Ideenquelle, nicht als alleiniger Freigabebeleg verwendet werden.

## PR-009 – Rohdaten unverändert archivieren

Jeder Keyword-, Trends-, Search-Console- oder Partnerprogramm-Export wird unverändert mit Quelle, Zielmarkt, Sprache, Zeitraum und Abrufdatum archiviert. Entscheidungen werden davon getrennt dokumentiert.

## PR-010 – Keine starre Volumenschwelle

Suchvolumen ist ein Signal, kein alleiniger Freigabeschalter. Entscheidungskriterien sind mindestens Nachfrage, Intent-Trennschärfe, SERP-Überlappung, fachliche Substanz, Monetarisierungsrolle und Risiko.

# Regeln für externe Prüfstellen

## PR-011 – Doppeltes externes Urteil

Externe Prüfstellen müssen Strukturfreigabe und Produktionsfreigabe getrennt ausweisen. Ein Struktur-PASS darf niemals stillschweigend als Produktions-PASS ausgegeben werden.

## PR-012 – Unabhängige Nachrechnung

Externe Reviewer dürfen interne PASS-Dateien nicht ungeprüft übernehmen. Automatisch prüfbare Regeln, Summen, IDs, Elternbeziehungen, Zyklen, Slugs, Longtail-Mindestmengen und Statuswerte sind unabhängig nachzurechnen.

## PR-013 – Nachweis statt Behauptung

Jedes externe Urteil muss auf konkreten Dateien, Rohdaten, Zählwerten, Quellen-IDs und Abrufdaten beruhen. Platzhalterbelege oder pauschale Formeln sind unzulässig.

## PR-014 – Produktionsdaten mit Aktualitätsangabe

Keyword-, SERP-, Partnerprogramm- und Risikonachweise müssen Zielmarkt, Sprache, Quelle, Abrufdatum und Prüfzeitraum enthalten. Ohne Aktualitätsangabe bleibt das betroffene Gate offen.

## PR-015 – Prioritätscluster vollständig prüfen

Alle als HIGH oder CRITICAL eingestuften, wirtschaftlich zentralen, mehrdeutigen oder kannibalisierungsgefährdeten Cluster sind vollständig zu validieren. Eine Stichprobe genügt dort nicht.

## PR-016 – Monetarisierung real verifizieren

Eine Monetarisierungsrolle gilt erst als VALIDATED, wenn mindestens ein real zugänglicher Erlösweg mit Region, Programmanbieter, Zielgruppe, Zugangsbedingungen und Abrufdatum belegt ist. Vermutete Programme gelten als PENDING.

## PR-017 – Expertengate nicht durch KI ersetzbar

Bei EXPERT_REVIEW_REQUIRED darf eine KI oder rein redaktionelle Prüfstelle das Publikationsgate nicht freigeben. Erforderlich ist eine dokumentierte Prüfung durch eine fachlich geeignete natürliche Person oder Institution.

## PR-018 – Interne Metadaten extern kontrollieren

Externe Reviewer prüfen ausdrücklich, dass scope, exclusions, quality_notes, Risikobegründungen und interne Prüffelder nicht als veröffentlichungsfertige Onpage-Texte gekennzeichnet oder exportiert werden.

## PR-019 – Ausschlüsse und Verschiebungen prüfen

Bewusste Ausschlüsse, DEFERRED-Entscheidungen und BLOCKED-Bereiche müssen auf Vollständigkeit, Begründung und Wiedervorlage-Trigger geprüft werden. Fehlende Dokumentation ist ein Korrekturgrund, nicht automatisch ein Strukturfehler.

## PR-020 – Begrenzte externe Korrekturrunden

Für einen externen Prüfauftrag gelten maximal zwei Korrekturrunden. Danach wird das ungeklärte Gate BLOCKED und an eine menschliche Fachprüfung übergeben; keine Endlosschleife.

