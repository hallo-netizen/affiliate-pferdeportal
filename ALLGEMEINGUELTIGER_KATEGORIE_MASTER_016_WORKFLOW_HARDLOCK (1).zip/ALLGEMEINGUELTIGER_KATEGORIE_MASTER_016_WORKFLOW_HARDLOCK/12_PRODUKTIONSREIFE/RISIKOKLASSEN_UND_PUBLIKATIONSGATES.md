# Risikoklassen und Publikationsgates

| Klasse | Bedeutung | Mindestgate |
|---|---|---|
| NORMAL | allgemeine Auswahl- und Orientierungsthemen | OPEN |
| TECHNICAL_SAFETY | Fehlanwendung kann Sach- oder Sicherheitsrisiken erzeugen | CURRENT_PRIMARY_SOURCE_REQUIRED |
| HEALTH_DRINKING_WATER | Trinkwasser, Hygiene oder gesundheitliche Wirkung | EXPERT_REVIEW_REQUIRED |
| LEGAL_REGIONAL | Rechtslage kann nach Land, Bundesland oder Kommune variieren | EXPERT_REVIEW_REQUIRED |
| REGULATED_TECHNICAL | genehmigungs-, norm- oder anlagenrelevante Technik | EXPERT_REVIEW_REQUIRED |

Das Gate gilt für die Veröffentlichung, nicht zwingend für die Existenz einer
internen Kategorie. Eine Kategorie darf strukturell bestehen und zugleich
`PRODUCTION_BLOCKED` sein.
