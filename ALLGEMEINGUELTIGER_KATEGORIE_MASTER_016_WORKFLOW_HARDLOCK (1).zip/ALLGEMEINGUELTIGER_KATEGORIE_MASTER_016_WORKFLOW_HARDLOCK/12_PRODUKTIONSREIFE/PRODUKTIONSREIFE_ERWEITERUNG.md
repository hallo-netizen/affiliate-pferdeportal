# Post-MVP-Erweiterung: Produktionsreife

## Einordnung

Der vollständig geprüfte Fünf-Schritte-MVP `KATEGORIE_MVP_MASTER_009_FINAL`
bleibt unverändert gültig. Diese Erweiterung ist **kein Schritt 6** und öffnet
keine neue Endlosschleife. Sie ergänzt eine optionale zweite Freigabeebene für
den Fall, dass ein strukturell bestandenes Konzept tatsächlich redaktionell
und kommerziell produziert werden soll.

Basis-Master SHA-256: `9f30dba88a88cfceab18969f93f8ffc760fc700dfe827361f454b27f312da59b`

## Zwei strikt getrennte Freigaben

1. **Strukturfreigabe**  
   Kategoriebaum, Blöcke, Eigentümerschaft, IDs, Slugs, Hierarchie und
   Mindestsubstanz sind geprüft.
2. **Produktionsfreigabe**  
   Nachfrage, Suchintention, Monetarisierbarkeit und Risiko sind mit aktuellen
   externen Daten ausreichend bestätigt.

Ein Struktur-PASS ist künftig niemals automatisch ein Produktions-PASS.

## Verbindliche neue Gates

- Keyword- und Suchintentionsgate für dichte, mehrdeutige oder wirtschaftlich
  zentrale Cluster
- Monetarisierungsgate je Hauptast
- Publikationsgate für rechtlich, gesundheitlich oder sicherheitlich sensible
  Bereiche
- Ausschlussregister mit Begründung und Wiedervorlage
- Scope-Texte und sonstige Steuerungsmetadaten bleiben intern und dürfen nicht
  ungeprüft als Onpage-Inhalt veröffentlicht werden

## Statuswerte

- `STRUCTURE_PROPOSED`
- `STRUCTURE_APPROVED`
- `PRODUCTION_VALIDATION_REQUIRED`
- `PRODUCTION_READY`
- `PRODUCTION_BLOCKED`

## Sicherheitsgrenze

Diese Erweiterung erzeugt weiterhin keine WordPress- oder HivePress-Schreibrechte.

## Externe Prüfstellen

Das interne Prüfsystem bleibt bestehen. Für externe Stellen gilt zusätzlich das
vollständige Protokoll `EXTERNES_PRUEFPROTOKOLL_PRODUKTIONSREIFE.md`.

Wesentliche Änderung: Externe Reviewer geben immer ein getrenntes Struktur- und
Produktionsurteil aus, rechnen prüfbare Fakten unabhängig nach und akzeptieren
keine undatierten oder pauschalen Produktionsbelege.

