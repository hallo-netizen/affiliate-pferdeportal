# Startanweisung neuer Themenlauf – Master 016

Vor jedem neuen Themenlauf zuerst `15_WORKFLOW_HARDLOCK/MASTER_LOCK.json` prüfen. Zulässig ist nur Vertrags-ID `ALLGEMEINGUELTIGER_KATEGORIE_MASTER_016_WORKFLOW_HARDLOCK`. Danach exakt die 14 Schritte aus `15_WORKFLOW_HARDLOCK/VERBINDLICHER_WORKFLOW_14_STUFEN.md` ausführen. Kein Schritt darf übersprungen, zusammengelegt, nachträglich simuliert oder durch Annahmen ersetzt werden.

Für Content gilt die aktive Mindestsubstanz von 3 wichtigen eigenständigen node-gebundenen DataForSEO-Longtails je letzter Kategorie. Tragfähige FAQ-/Tipps-/Beratungs-/Vergleichs-/Ausrüstungsrichtungen können selbst Kategorien sein.

Vor-HARDLOCK-Global-Evidenz ist nur Informationsquelle und darf keinen Gate-Abschluss ersetzen.
