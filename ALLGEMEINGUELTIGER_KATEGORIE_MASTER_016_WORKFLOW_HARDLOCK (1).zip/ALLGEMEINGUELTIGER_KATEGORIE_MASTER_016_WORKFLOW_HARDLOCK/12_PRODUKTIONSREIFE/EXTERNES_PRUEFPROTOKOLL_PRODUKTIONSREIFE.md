> **HISTORISCH / NICHT NORMATIV IN MASTER 016.** Diese Datei dokumentiert einen früheren Stand. Aktive Regeln und Workflow stehen ausschließlich in `15_WORKFLOW_HARDLOCK/MASTER_LOCK.json`; historische 4-Longtail-Anforderungen sind Übererfüllung, aktiv gilt 3.

> **Historischer Prüfhinweis:** Dieses Protokoll dokumentiert den strengeren damaligen 4-Longtail-Prüfstand. Master 015 setzt für neue Content-Kategorien verbindlich mindestens 3 wichtige eigenständige Longtails an; die historischen PASS-Belege bleiben unverändert gültig, weil sie die neue Mindestsubstanz übererfüllen.

# Externes Prüfprotokoll für Themenläufe

## Zweck

Dieses Protokoll wird verwendet, wenn ein mit dieser allgemeingültigen Masterdatei
erzeugtes Themenkonzept von Claude, ChatGPT, einer Agentur, einem SEO-Prüfer oder
einer fachlichen Stelle unabhängig geprüft wird.

Es ersetzt nicht das interne Prüfsystem. Es ergänzt es durch eine unabhängige
Nachrechnung und eine zweite, strikt getrennte Produktionsreifeprüfung.

## Zwingend getrennte Urteile

Jeder externe Bericht muss zwei Urteile ausgeben:

1. **STRUKTURURTEIL**
   - `STRUCTURE_PASS`
   - `STRUCTURE_CORRECTION_REQUIRED`
   - `STRUCTURE_BLOCKED`

2. **PRODUKTIONSURTEIL**
   - `PRODUCTION_READY`
   - `PRODUCTION_VALIDATION_REQUIRED`
   - `PRODUCTION_BLOCKED`

Ein bestandener Kategoriebaum kann somit korrekt das kombinierte Ergebnis
`STRUCTURE_PASS + PRODUCTION_VALIDATION_REQUIRED` erhalten.

## Phase A – Paket und Integrität

Der Reviewer prüft unabhängig:

- ZIP lesbar und vollständig;
- SHA-256-Liste gegen alle Dateien;
- Mastertyp `complete_consolidated_master=true` und `delta=false`;
- Thema, Zielmarkt, Sprache und Erstellungsdatum vorhanden;
- Prüfumfang und nicht geprüfte Bereiche ausdrücklich benannt.

## Phase B – Strukturprüfung

Die 18 harten Regeln und die 100-Punkte-Rubrik werden unabhängig geprüft.
Interne Vorchecks und PASS-Dateien sind nur Hinweise, keine Beweise.

Mindestens selbst nachzurechnen:

- Knoten- und Blockzahlen;
- concept_id-Eindeutigkeit;
- Elternverweise, Waisen und Zyklen;
- Slug-Eindeutigkeit je Block;
- Titelgrenzen;
- Pflichtfelder;
- Ein-Kind-Hierarchien;
- mindestens vier eigenständige Longtails je unterstem Content-Knoten;
- Trennung der Blockintentionen;
- Summen der 21 Qualitätskriterien.

## Phase C – Keyword- und Intentgate

Vollständig zu prüfen sind alle Cluster mit Priorität HIGH oder CRITICAL sowie
alle wirtschaftlich zentralen, mehrdeutigen oder kannibalisierungsgefährdeten
Cluster. Dort genügt keine Stichprobe.

Je geprüftem Cluster müssen vorliegen:

- Seed- und Zielkeywords;
- Zielmarkt und Sprache;
- unveränderter Rohdatenexport;
- Quelle und Abrufdatum;
- Nachfragewerte oder ausdrücklich dokumentierte Nichtverfügbarkeit;
- Query-/Seitenintention;
- manuelle SERP-Aufgabe;
- Überschneidung mit benachbarten Kategorien;
- Entscheidung `KEEP_CATEGORY`, `MERGE`, `ARTICLE_ONLY`, `DEFER` oder `BLOCK`.

Eine starre Suchvolumengrenze ist unzulässig. Die Entscheidung muss Nachfrage,
Intent, SERP-Überlappung, fachliche Substanz, Monetarisierung und Risiko gemeinsam
berücksichtigen.

## Phase D – Monetarisierungsgate

Jeder Hauptast benötigt eine belegte Rolle:

- `DIRECT_AFFILIATE`
- `LEADGEN_MARKETPLACE`
- `EDITORIAL_SUPPORT`
- `DEFERRED`
- `BLOCKED`

Für `DIRECT_AFFILIATE` oder `LEADGEN_MARKETPLACE` müssen mindestens dokumentiert sein:

- konkreter Anbieter oder Netzwerk;
- Region und Zielgruppe;
- Zugänglichkeit beziehungsweise Zulassungsvoraussetzungen;
- passende Produkt- oder Dienstleistungskategorien;
- Abrufdatum;
- Quelle oder unveränderter Nachweis.

Eine bloße Vermutung, dass es „sicher ein Partnerprogramm gibt“, ist kein Nachweis.
Ein fachlich wichtiger Ast darf als `EDITORIAL_SUPPORT` bestehen bleiben, muss dann
aber ausdrücklich als nicht unmittelbar monetarisierend markiert werden.

## Phase E – Risiko- und Publikationsgate

Der Reviewer identifiziert rechtliche, gesundheitliche, medizinische, bauliche,
sicherheits-, genehmigungs- oder normrelevante Bereiche.

- `OPEN`: normale Redaktion möglich;
- `CURRENT_PRIMARY_SOURCE_REQUIRED`: aktuelle Primärquelle vor Veröffentlichung;
- `EXPERT_REVIEW_REQUIRED`: Veröffentlichung bis menschliche Fachprüfung blockiert;
- `BLOCKED`: keine Veröffentlichung im aktuellen Projektstand.

Eine KI darf Risiken erkennen und dokumentieren, aber ein
`EXPERT_REVIEW_REQUIRED`-Gate nicht selbst schließen.

## Phase F – Veröffentlichungs- und Metadatenkontrolle

Der Reviewer prüft, dass interne Felder nicht als Onpage-Inhalte verwendet werden:

- `scope`
- `exclusions`
- `quality_notes`
- Risikobegründungen
- Prüferkommentare
- Rohdatenkommentare

Diese Felder müssen `INTERNAL_ONLY` bleiben.

## Phase G – Ausschlussregister

Ausgeschlossene, verschobene oder blockierte Themen werden geprüft auf:

- eindeutigen Gegenstand;
- Entscheidungsgrund;
- Entscheidungstyp;
- Datum;
- Wiedervorlage-Trigger;
- verantwortliche Rolle.

Ein bewusst ausgeschlossener Bereich ist kein Fehler, wenn die Entscheidung
vollständig dokumentiert und strategisch nachvollziehbar ist.

## Evidenzstandard

Jeder Befund enthält:

- Regel- oder Gate-ID;
- konkrete Datei und Feldbezeichnung;
- selbst ermittelten Zähl- oder Prüfwert;
- Quelle und Abrufdatum bei externen Daten;
- Begründung;
- Schweregrad;
- erforderliche Korrektur;
- Status nach maximal zwei Korrekturrunden.

## Abschlusscodes

Der externe Reviewer gibt genau einen kombinierten Endcode aus:

- `PASS_STRUCTURE_AND_PRODUCTION_READY`
- `PASS_STRUCTURE_PRODUCTION_VALIDATION_REQUIRED`
- `CORRECTION_STRUCTURE_REQUIRED`
- `CORRECTION_PRODUCTION_EVIDENCE_REQUIRED`
- `BLOCKED_EXPERT_REVIEW_REQUIRED`
- `BLOCKED_EXTERNAL_REVIEW`

## Keine Endlosschleife

Maximal zwei externe Korrekturrunden. Danach wird das offene Gate dokumentiert
blockiert und an eine geeignete menschliche Fachstelle übergeben.
