# MVP-Funktionsumfang

## Eingabe

Primäre Pflichtangabe: ein Hauptthema.

## Ausgabe je Thema

- Content-/Affiliatebaum
- Marktplatz-/HivePressbaum
- Magazin-/Wissensbaum
- optionales Glossar
- Knoten-IDs und Eltern-Kind-Beziehungen
- Kategorienamen und Slugs
- Keywords und Suchintentionen
- Keyword-Eigentümer
- Abgrenzungen und Ausschlüsse
- Longtail-Potenziale
- Konfliktbericht
- Prüfbericht
- lesbare Darstellung
- JSON- und CSV-Ausgabe

## Nicht enthalten

- WordPress-Schreiben
- HivePress-Schreiben
- Navigation live verändern
- Kategorien live anlegen
- Inhalte live verschieben
- automatische Löschung
