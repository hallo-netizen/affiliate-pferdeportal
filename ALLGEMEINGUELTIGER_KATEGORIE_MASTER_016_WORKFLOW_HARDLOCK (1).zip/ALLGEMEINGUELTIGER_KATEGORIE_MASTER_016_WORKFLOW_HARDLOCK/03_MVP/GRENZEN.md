# Verbindliche Grenzen

1. Das aktive MVP ist rein lesend.
2. Virtuelle Piloten benötigen keine Website.
3. Das Pferde Atelier bleibt unverändert.
4. Ein späteres Schreibmodul ist ein separates Zukunftsprojekt.
5. Alte Schreibkerne sind historische Lernstände, keine aktiven Plugins.
6. Claude prüft nach jedem großen Schritt anhand vorab definierter Kriterien.
7. Je Schritt sind höchstens zwei Korrekturrunden zulässig.
8. Nach zwei erfolglosen Runden wird der Schritt BLOCKED.
9. Danach ist eine unabhängige menschliche Fachprüfung erforderlich.
10. Der nächste Schritt beginnt erst nach dokumentiertem Claude-Ergebnis.
