# Verbindlicher Schrittplan

## Schritt 1 – Master, Regelwerk und Archiv konsolidieren

**Status:** `PASS`

**Ziel:** Klare vollständige Arbeitsbasis ohne Verlust alter Regeln oder Erkenntnisse.

## Schritt 2 – Messbares MVP-Prüfsystem festlegen

**Status:** `PASS`

**Ziel:** Harte Kriterien und vollständig gewichtete 100-Punkte-Rubrik vor den Piloten fixieren.

## Schritt 3 – Drei strukturell unterschiedliche virtuelle Pilotportale erzeugen

**Status:** `PASS`

**Ziel:** Themenunabhängigkeit an drei deutlich verschiedenen virtuellen Portalen prüfen.

## Schritt 4 – Piloten prüfen und begrenzt korrigieren

**Status:** `PASS`

**Ziel:** Piloten gegen feste Kriterien prüfen und höchstens zweimal nachbessern.

## Schritt 5 – Lesendes MVP abschließen

**Status:** `PASS`

**Ziel:** Geprüften lesenden Generator als klare, dokumentierte Produktbasis abschließen.

## Projektstatus

`FINAL_RELEASED`

Keine weiteren Schritte innerhalb dieses MVP.
