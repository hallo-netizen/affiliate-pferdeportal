# ÜBERGABE – JOURNAL REQUEST-BUDGET ROOTFIX – SCHRITT 12 – 13.08.2026

## Bindend
Aktueller Master ist alleinige Autorität. Workflow unverändert und zwingend. Keine eigenen Themen-/Kategorie-/Titel-/Artikeltyp-/Planplatz-/Publish-Entscheidungen. Unbekannter Livezustand = BLOCKED.

## Warum Schritt 12 nötig wurde
Nach Schritt 11 zeigten sich live zwei systemische technische Fehler: `PSTE_CONTEXT_AJAX_INVALID_JSON` beim Portalabgleich und Timeout beim Öffnen des SEO-Redaktionsplans. Die Ursachen wurden nicht als Einzelfehler, sondern über den gesamten PSTE→PSERC→PPM-Workflow untersucht.

## Root-Cause-Fix
**PSTE 0.48.0** ersetzt 0.47.0.

Behoben wurden gebündelt:
1. ungebundene Arbeiten innerhalb des angeblich request-begrenzten Context-AJAX;
2. 1125-Query-N+1-Lesepfad des 562er Bestands beim Redaktionsplan;
3. wiederholte Sandbox-Vollstore-Prüfung/-Writes;
4. ungebundener 562-facher Fail-Closed-JSON-Rewrite;
5. unzureichende AJAX-Diagnostik.

Fachliche Journal-, Titel-, Kategorie-, Artikeltyp-, Exact-Five- und Produktionsregeln wurden nicht verändert.

## Versionen / Installation
- **PSTE 0.48.0:** NEU – Installation erforderlich.
  - Installer: `portal-seo-topic-engine_0.48.0_REQUEST_BUDGET_ROOTFIX_FINAL.zip`
  - SHA-256: `eb4d654abbb608b1fb603cf743b31545e77b761ba1ab3c788f9617b6a9a44b56`
- **PSERC 0.25.2:** unverändert gegenüber Schritt 11. Wenn bereits installiert: **keine Neuinstallation**.
- **PPM 6.7.9:** unverändert. **Keine Neuinstallation**.
- PSTE 0.47.0 ist durch 0.48.0 ersetzt und nicht mehr der aktuelle Kandidat.

## Harte lokale Endprüfung
- PSTE Source→Fresh-Unpack 190/190 PASS.
- PSTE PHP 67/67, JSON 51/51 PASS.
- Realer 562er Kandidatenbestand: 1125 → 3 Queries, Ergebnis byte-semantisch identisch.
- Context-V4-Budget/Manipulations-/Stale-/Legacy-Negativtests PASS.
- Sandbox-No-op/Cache PASS; globaler Fail-Closed-Pfad konstant 1 Write.
- Entscheidung/Routing/Titelklassen gegenüber 0.47.0 byte-identisch; 562er semantische Step11-Prüfung trägt unverändert fort.
- PSERC 0.25.2: 90/90 identisch; 31/31 PHP; 13/13 JSON; Package-Integrity PASS.
- PPM 6.7.9: 136/136 aktive Tests; 219/219 PHP; 104/104 JSON; Build-Integrity PASS.
- Gesamtworkflow lokal 27/27 PASS, inklusive 2 Exact-Five-Positionen, signierter Supervisorfreigabe, unveränderten Artikelhashes, 2 Draft-Simulationen, Readback PASS, Publish=false.

## Zwingender Liveweg ab hier
1. Nur PSTE 0.48.0 installieren.
2. `SEO Themenengine → Übersicht → Gesamtbestand neu abgleichen` genau einmal starten.
3. Seite offen lassen, bis der vorhandene Context-/Sandbox-Job **COMPLETE** ist. Bei BLOCKED nicht weitergehen; 0.48.0 liefert dafür den konkreteren Fehlerbeleg.
4. Erst bei COMPLETE `SEO Redaktionsplan` öffnen. Er muss ohne N+1-Timeout laden und beide Piloten als READY / Exact Five liefern.
5. Ausschließlich das bestehende signierte Produktionsset aus Schritt 11/Block 37 verwenden.
6. Erwartung live: exakt 2 WordPress-Drafts, kein Publish.
7. Echter WordPress-Readback + Hash für beide Drafts muss PASS sein.
8. Die getrennte Nutzerentscheidung zur Veröffentlichung liegt bereits vor; erst nach Readback-PASS manuell veröffentlichen. Automatisches Publish bleibt deaktiviert.

## Live-Grenze
Schritt 12 ist lokal Release-PASS. **Kein Live-E2E-PASS wird behauptet**, solange PSTE 0.48.0 nicht installiert und der reale COMPLETE→Exact-Five→Draft→Readback-Weg belegt wurde.

## Master-Paket-Sicherheit
Beim vollständigen Master-Audit wurde in einem geerbten historischen Unterordner eine private Workflow-Signatur-Schlüsseldatei gefunden. Sie wird im Schritt-12-Master **bewusst nicht mehr mitgeliefert**. Der Schlüsselinhalt wurde weder kopiert noch offengelegt. Alle übrigen 7.655 geerbten Dateien bleiben byte-identisch. Secret-Scan des Schritt-12-Masters: PASS, 0 private Signing-Material-Treffer.
