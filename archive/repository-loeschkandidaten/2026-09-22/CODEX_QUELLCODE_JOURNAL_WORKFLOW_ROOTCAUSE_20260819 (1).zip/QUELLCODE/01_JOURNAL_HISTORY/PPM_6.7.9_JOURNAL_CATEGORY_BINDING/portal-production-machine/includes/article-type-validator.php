<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Article_Type_Validator {
    const VERSION = '6.7.9';
    const CONTRACT_FILE = 'contracts/article-type-templates.json';
    const JOURNAL_CONTRACT_FILE = 'contracts/journal-article-type-release-v1.json';
    const GOLD_BINDING = 'FOUR_TYPE_APPROVED_GOLD_CORE_V1';
    const REQUIRED_TYPES = array('FAQ','Beratung','Vergleich','Pflege');
    const EVIDENCE_FIELDS = array('contract','version','article_type','definition_hash','positive_status','negative_status','gold_core_binding','evidence_hash');

    public static function load_contract() {
        $file = PPM679_PLUGIN_DIR . self::CONTRACT_FILE;
        if (!is_file($file)) { return null; }
        $decoded = json_decode((string) file_get_contents($file), true);
        return is_array($decoded) ? $decoded : null;
    }

    public static function validate($context, $server_state_hash = '') {
        $contract = self::load_contract();
        if (!is_array($contract)) {
            return array(PPM679_Diagnostic::error(
                'BLOCKED_ARTICLE_TYPE_CONTRACT_MISSING',
                'ARTICLE_TYPE_CONTRACT_MUST_EXIST_AND_BE_VALID_JSON',
                self::CONTRACT_FILE,
                'valid article_type_templates_v2 JSON',
                $contract,
                'Der aktive Beitragstypvertrag fehlt oder ist nicht lesbar.',
                $context,
                $server_state_hash,
                __CLASS__,
                null,
                array(self::CONTRACT_FILE)
            ));
        }

        $errors = array();
        $types = isset($contract['types']) && is_array($contract['types']) ? $contract['types'] : array();
        foreach (self::REQUIRED_TYPES as $index => $type) {
            if (!isset($types[$type]) || !is_array($types[$type])) {
                $errors[] = PPM679_Diagnostic::error(
                    'BLOCKED_ARTICLE_TYPE_DEFINITION_MISSING',
                    'ALL_FOUR_GOLD_CORE_TYPES_MUST_HAVE_ACTIVE_DEFINITIONS',
                    'types.' . $type,
                    'active definition',
                    isset($types[$type]) ? $types[$type] : null,
                    'Der fertige Beitragstyp ist im aktiven Vertrag nicht vollständig definiert.',
                    $context,
                    $server_state_hash,
                    __CLASS__,
                    $index,
                    array(self::CONTRACT_FILE)
                );
                continue;
            }
            $spec = $types[$type];
            if (empty($spec['production_allowed'])) {
                $errors[] = PPM679_Diagnostic::error(
                    'BLOCKED_ARTICLE_TYPE_NOT_PRODUCTION_ALLOWED',
                    'GOLD_CORE_TYPE_MUST_BE_DECLARED_PRODUCTION_ALLOWED',
                    'types.' . $type . '.production_allowed',
                    true,
                    isset($spec['production_allowed']) ? $spec['production_allowed'] : null,
                    'Der freigegebene Beitragstyp ist im aktiven Vertrag nicht für die Produktion freigeschaltet.',
                    $context,
                    $server_state_hash,
                    __CLASS__,
                    $index,
                    array(self::CONTRACT_FILE)
                );
            }
            $evidence = isset($spec['certification_evidence']) && is_array($spec['certification_evidence']) ? $spec['certification_evidence'] : array();
            foreach (self::EVIDENCE_FIELDS as $field) {
                if (!array_key_exists($field, $evidence) || $evidence[$field] === '') {
                    $errors[] = PPM679_Diagnostic::error(
                        'BLOCKED_ARTICLE_TYPE_EVIDENCE_FIELD_MISSING',
                        'ARTICLE_TYPE_EVIDENCE_MUST_MATCH_SCHEMA_V2',
                        'types.' . $type . '.certification_evidence.' . $field,
                        'non-empty field',
                        array_key_exists($field, $evidence) ? $evidence[$field] : null,
                        'Der Zertifizierungsbeleg enthält nicht das vom aktiven Validator erwartete Feld.',
                        $context,
                        $server_state_hash,
                        __CLASS__,
                        $index,
                        array(self::CONTRACT_FILE)
                    );
                }
            }
            if (isset($evidence['article_type']) && (string) $evidence['article_type'] !== $type) {
                $errors[] = PPM679_Diagnostic::error(
                    'BLOCKED_ARTICLE_TYPE_EVIDENCE_TYPE_MISMATCH',
                    'EVIDENCE_ARTICLE_TYPE_MUST_EQUAL_REGISTRY_KEY',
                    'types.' . $type . '.certification_evidence.article_type',
                    $type,
                    $evidence['article_type'],
                    'Der Zertifizierungsbeleg ist an einen anderen Beitragstyp gebunden.',
                    $context,
                    $server_state_hash,
                    __CLASS__,
                    $index,
                    array(self::CONTRACT_FILE)
                );
            }
            if (isset($evidence['gold_core_binding']) && (string) $evidence['gold_core_binding'] !== self::GOLD_BINDING) {
                $errors[] = PPM679_Diagnostic::error(
                    'BLOCKED_GOLD_CORE_BINDING_MISMATCH',
                    'EVIDENCE_MUST_BIND_TO_FOUR_TYPE_GOLD_CORE',
                    'types.' . $type . '.certification_evidence.gold_core_binding',
                    self::GOLD_BINDING,
                    $evidence['gold_core_binding'],
                    'Der Beitragstypbeleg ist nicht an den unveränderten Vier-Typ-Goldkern gebunden.',
                    $context,
                    $server_state_hash,
                    __CLASS__,
                    $index,
                    array(self::CONTRACT_FILE,'contracts/gold-core-binding-v1.json')
                );
            }
            if (isset($evidence['positive_status']) && (string) $evidence['positive_status'] !== 'STRUCTURAL_CHECK_OK') {
                $errors[] = PPM679_Diagnostic::error(
                    'BLOCKED_ARTICLE_TYPE_POSITIVE_EVIDENCE_STATUS',
                    'POSITIVE_EVIDENCE_MUST_BE_STRUCTURAL_CHECK_OK',
                    'types.' . $type . '.certification_evidence.positive_status',
                    'STRUCTURAL_CHECK_OK',
                    $evidence['positive_status'],
                    'Der positive Typbeleg verwendet einen unzulässigen oder veralteten Status.',
                    $context,
                    $server_state_hash,
                    __CLASS__,
                    $index,
                    array(self::CONTRACT_FILE)
                );
            }
            if (isset($evidence['negative_status']) && (string) $evidence['negative_status'] !== 'MUTATION_BLOCK_CHECK_OK') {
                $errors[] = PPM679_Diagnostic::error(
                    'BLOCKED_ARTICLE_TYPE_NEGATIVE_EVIDENCE_STATUS',
                    'NEGATIVE_EVIDENCE_MUST_BE_MUTATION_BLOCK_CHECK_OK',
                    'types.' . $type . '.certification_evidence.negative_status',
                    'MUTATION_BLOCK_CHECK_OK',
                    $evidence['negative_status'],
                    'Der negative Typbeleg verwendet einen unzulässigen oder veralteten Status.',
                    $context,
                    $server_state_hash,
                    __CLASS__,
                    $index,
                    array(self::CONTRACT_FILE)
                );
            }
        }
        $journal = self::load_journal_contract();
        if (!is_array($journal) || (string)($journal['contract']??'')!=='PPM679_JOURNAL_ARTICLE_TYPE_RELEASE_V1') {
            $errors[] = PPM679_Diagnostic::error('BLOCKED_JOURNAL_ARTICLE_TYPE_CONTRACT_MISSING','JOURNAL_SIGNED_ARTICLE_TYPE_CONTRACT_MUST_EXIST','journal_type_contract','valid signed Journal contract',$journal,'Der signierte Journal-Beitragstypvertrag fehlt.',$context,$server_state_hash,__CLASS__,null,array(self::JOURNAL_CONTRACT_FILE));
        } else {
            $claimed=(string)($journal['contract_self_sha256']??'');$copy=$journal;unset($copy['contract_self_sha256']);$actual=PPM679_Diagnostic::stable_hash($copy);
            $definition=(array)($journal['type_definition']??array());$evidence=(array)($definition['certification_evidence']??array());
            $defcopy=$definition;unset($defcopy['certification_evidence']);$definition_hash=PPM679_Diagnostic::stable_hash($defcopy);
            $evcopy=$evidence;unset($evcopy['evidence_hash']);$evidence_hash=PPM679_Diagnostic::stable_hash($evcopy);
            if($claimed===''||!hash_equals($claimed,$actual)||($definition['article_type']??'')!=='Journal'||($definition['production_allowed']??null)!==true||($definition['publish_allowed']??null)!==false||($definition['validation_contract_required']??'')!=='SECTION_REQUIREMENTS_V1'||($evidence['definition_hash']??'')!==$definition_hash||($evidence['evidence_hash']??'')!==$evidence_hash){
                $errors[] = PPM679_Diagnostic::error('BLOCKED_JOURNAL_ARTICLE_TYPE_CONTRACT_INVALID','JOURNAL_SIGNED_ARTICLE_TYPE_CONTRACT_MUST_MATCH_EXACT_RELEASE_RULES','journal_type_contract','hash-bound Journal draft-only definition',$journal,'Der Journal-Beitragstypvertrag ist nicht vollständig oder nicht selbstkonsistent.',$context,$server_state_hash,__CLASS__,null,array(self::JOURNAL_CONTRACT_FILE));
            }
        }
        return $errors;
    }

    public static function load_journal_contract() {
        $file=PPM679_PLUGIN_DIR.self::JOURNAL_CONTRACT_FILE;
        if(!is_file($file)){return null;}
        $decoded=json_decode((string)file_get_contents($file),true);return is_array($decoded)?$decoded:null;
    }

    public static function type_definition($type) {
        if ((string)$type==='Journal') { $journal=self::load_journal_contract(); return is_array($journal)&&is_array($journal['type_definition']??null)?$journal['type_definition']:null; }
        $contract = self::load_contract();
        if (!is_array($contract) || empty($contract['types'][$type]) || !is_array($contract['types'][$type])) { return null; }
        return $contract['types'][$type];
    }
}
