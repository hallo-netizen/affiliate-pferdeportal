<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Plan_Validator {
    const VERSION='6.7.9';
    const CONTRACT='production_plan_v4';
    const CONTRACT_VERSION='4.0.0';
    const CONTRACT_V5='production_plan_v5';
    const CONTRACT_VERSION_V5='5.1.0';
    const VALIDATION_CONTRACT_V5='SECTION_REQUIREMENTS_V1';
    const GOLD_BINDING='FOUR_TYPE_APPROVED_GOLD_CORE_V1';
    const REQUIRED_TYPES=array('FAQ','Beratung','Vergleich','Pflege','Journal');
    const FORBIDDEN_OPERATIONAL_FIELDS=array('batch_id','batch_article_id','fact_pack_id','skeleton_id','reservation_id','workspace_id','skeleton_token');

    public static function validate($plan,$context='plan_validation',$server_state_hash='') {
        $errors=array();
        if (!is_array($plan)) {
            $errors[]=self::err('BLOCKED_PLAN_NOT_OBJECT','PLAN_MUST_BE_JSON_OBJECT','plan','object',$plan,'Der Produktionsplan ist kein JSON-Objekt.',$context,$server_state_hash);
            return array('ok'=>false,'errors'=>$errors);
        }

        $plan_contract=(string)($plan['contract']??'');
        $is_v4=$plan_contract===self::CONTRACT;
        $is_v5=$plan_contract===self::CONTRACT_V5;
        if (!$is_v4 && !$is_v5) {
            $errors[]=self::err('BLOCKED_PLAN_CONTRACT_MISMATCH','PLAN_CONTRACT_MUST_BE_EXPLICITLY_SUPPORTED','plan.contract',array(self::CONTRACT,self::CONTRACT_V5),$plan_contract,'Der Planvertrag fehlt oder ist unbekannt; ein Fallback ist unzulässig.',$context,$server_state_hash);
        }

        $required=array('contract','plan_contract_version','required_plugin_version','plan_id','gold_core_binding','contract_hashes','items');
        if ($is_v5) { $required[]='validation_contract_version'; }
        foreach ($required as $field) {
            if (!array_key_exists($field,$plan)) {
                $errors[]=self::err('BLOCKED_PLAN_REQUIRED_FIELD_MISSING','PLAN_V4_REQUIRES_ALL_TOP_LEVEL_FIELDS','plan.'.$field,'present',null,'Ein Pflichtfeld des logischen Produktionsplans fehlt.',$context,$server_state_hash);
            }
        }
        if ($is_v4 && (string)($plan['plan_contract_version']??'')!==self::CONTRACT_VERSION) {
            $errors[]=self::err('BLOCKED_PLAN_CONTRACT_VERSION_MISMATCH','PLAN_CONTRACT_VERSION_MUST_MATCH','plan.plan_contract_version',self::CONTRACT_VERSION,$plan['plan_contract_version']??null,'Die Planvertragsversion stimmt nicht überein.',$context,$server_state_hash);
        }
        if ($is_v5 && (string)($plan['plan_contract_version']??'')!==self::CONTRACT_VERSION_V5) {
            $errors[]=self::err('BLOCKED_PLAN_CONTRACT_VERSION_MISMATCH','PLAN_V5_CONTRACT_VERSION_MUST_MATCH','plan.plan_contract_version',self::CONTRACT_VERSION_V5,$plan['plan_contract_version']??null,'Die Planvertragsversion des neuen Validierungspfads stimmt nicht überein.',$context,$server_state_hash);
        }
        if ($is_v5 && (string)($plan['validation_contract_version']??'')!==self::VALIDATION_CONTRACT_V5) {
            $errors[]=self::err('BLOCKED_VALIDATION_CONTRACT_VERSION_MISSING','PLAN_V5_REQUIRES_SECTION_REQUIREMENTS_V1','plan.validation_contract_version',self::VALIDATION_CONTRACT_V5,$plan['validation_contract_version']??null,'Der neue Plan ist nicht explizit an den bestätigten Validierungsvertrag gebunden.',$context,$server_state_hash);
        }
        if ((string)($plan['required_plugin_version']??'')!==self::VERSION) {
            $errors[]=self::err('BLOCKED_PLAN_PLUGIN_VERSION_MISMATCH','PLAN_REQUIRED_PLUGIN_VERSION_MUST_MATCH_RUNTIME','plan.required_plugin_version',self::VERSION,$plan['required_plugin_version']??null,'Der Plan ist für eine andere Pluginversion gebaut.',$context,$server_state_hash);
        }
        if ((string)($plan['gold_core_binding']??'')!==self::GOLD_BINDING) {
            $errors[]=self::err('BLOCKED_PLAN_GOLD_CORE_BINDING','PLAN_MUST_BIND_TO_FOUR_TYPE_GOLD_CORE','plan.gold_core_binding',self::GOLD_BINDING,$plan['gold_core_binding']??null,'Der Plan ist nicht an den unveränderten Vier-Typ-Goldkern gebunden.',$context,$server_state_hash);
        }

        self::scan_forbidden($plan,'plan',$errors,$context,$server_state_hash);

        $items=isset($plan['items'])&&is_array($plan['items'])?$plan['items']:array();
        if (count($items)<1 || count($items)>4) {
            $errors[]=self::err('BLOCKED_PLAN_ITEM_COUNT','PRODUCTION_PLAN_MUST_CONTAIN_BETWEEN_ONE_AND_FOUR_ITEMS','plan.items','1..4',count($items),'Ein Produktionslauf muss mindestens einen und darf höchstens vier Aufträge enthalten.',$context,$server_state_hash);
        }

        $seen_types=array(); $seen_keys=array();
        $item_required=array('plan_item_key','article_type','source_order_id','source_snapshot_id','topic','search_intent','target_keyword','source_hashes','contract_hashes','gold_core_binding','runtime_order','canonical_article');
        if ($is_v5) {
            $item_required[]='validation_contract_version';
            $item_required[]='section_requirements';
            $item_required[]='section_requirements_hash';
            $item_required[]='category_binding';
            $item_required[]='category_binding_hash';
        }
        foreach ($items as $index=>$item) {
            if (!is_array($item)) {
                $errors[]=self::err('BLOCKED_PLAN_ITEM_INVALID','EACH_PLAN_ITEM_MUST_BE_OBJECT','plan.items['.$index.']','object',$item,'Ein Planeintrag ist kein Objekt.',$context,$server_state_hash,$index);
                continue;
            }
            foreach ($item_required as $field) {
                if (!array_key_exists($field,$item) || $item[$field]==='' || $item[$field]===array()) {
                    $errors[]=self::err('BLOCKED_PLAN_ITEM_FIELD_MISSING','PLAN_ITEM_REQUIRES_ALL_LOGICAL_FIELDS','plan.items['.$index.'].'.$field,'present non-empty value',$item[$field]??null,'Ein logisches Pflichtfeld des Planeintrags fehlt.',$context,$server_state_hash,$index);
                }
            }
            $type=(string)($item['article_type']??'');
            if (!in_array($type,self::REQUIRED_TYPES,true)) {
                $errors[]=self::err('BLOCKED_PLAN_ARTICLE_TYPE','PLAN_ITEM_ARTICLE_TYPE_MUST_BE_SIGNED_RELEASE_TYPE','plan.items['.$index.'].article_type',self::REQUIRED_TYPES,$type,'Der Planeintrag verwendet keinen freigegebenen Beitragstyp.',$context,$server_state_hash,$index);
            } elseif ($type==='Journal' && !$is_v5) {
                $errors[]=self::err('BLOCKED_JOURNAL_REQUIRES_V5','JOURNAL_MUST_USE_SECTION_REQUIREMENTS_V1','plan.items['.$index.'].validation_contract_version',self::VALIDATION_CONTRACT_V5,$item['validation_contract_version']??null,'Journal darf nicht in den Legacy-V4-Prüfpfad fallen.',$context,$server_state_hash,$index);
            } elseif (isset($seen_types[$type])) {
                $errors[]=self::err('BLOCKED_PLAN_DUPLICATE_ARTICLE_TYPE','FOUR_TYPE_TEST_REQUIRES_EACH_TYPE_EXACTLY_ONCE','plan.items['.$index.'].article_type','unique article type',$type,'Ein Beitragstyp wurde im Testplan mehrfach verwendet.',$context,$server_state_hash,$index);
            } else { $seen_types[$type]=true; }

            $key=(string)($item['plan_item_key']??'');
            if ($key!=='' && isset($seen_keys[$key])) {
                $errors[]=self::err('BLOCKED_PLAN_DUPLICATE_ITEM_KEY','PLAN_ITEM_KEY_MUST_BE_UNIQUE','plan.items['.$index.'].plan_item_key','unique key',$key,'Der logische Planeintragsschlüssel ist nicht eindeutig.',$context,$server_state_hash,$index);
            } elseif ($key!=='') { $seen_keys[$key]=true; }

            if ((string)($item['gold_core_binding']??'')!==self::GOLD_BINDING) {
                $errors[]=self::err('BLOCKED_PLAN_ITEM_GOLD_CORE_BINDING','EVERY_ITEM_MUST_BIND_TO_FOUR_TYPE_GOLD_CORE','plan.items['.$index.'].gold_core_binding',self::GOLD_BINDING,$item['gold_core_binding']??null,'Der einzelne Auftrag ist nicht korrekt an den Goldkern gebunden.',$context,$server_state_hash,$index);
            }

            self::validate_runtime_payload($item,$index,$errors,$context,$server_state_hash,$is_v5);
            if ($is_v5) {
                self::validate_v5_contract_payload($item,$index,$errors,$context,$server_state_hash);
                self::validate_v5_category_binding($item,$index,$errors,$context,$server_state_hash);
            }
            elseif (array_key_exists('validation_contract_version',$item) || array_key_exists('section_requirements',$item) || array_key_exists('section_requirements_hash',$item)) {
                $errors[]=self::err('BLOCKED_VALIDATION_CONTRACT_VERSION_UNKNOWN','PLAN_V4_MUST_NOT_ENTER_V5_VALIDATION_PATH','plan.items['.$index.'].validation_contract_version','field absent',$item['validation_contract_version']??null,'Ein Legacy-Plan darf den neuen Validierungspfad nicht deklarieren.',$context,$server_state_hash,$index);
            }

            $pack=PPM679_Storage::load_fact_pack((string)($item['source_snapshot_id']??''));
            if (!is_array($pack)) {
                $errors[]=self::err('BLOCKED_FACT_PACK_NOT_FOUND','SOURCE_SNAPSHOT_MUST_RESOLVE_TO_FACT_PACK','plan.items['.$index.'].source_snapshot_id','resolvable fact pack',$item['source_snapshot_id']??null,'Zum Quellensnapshot ist kein Fact-Pack vorhanden.',$context,$server_state_hash,$index);
            } else {
                if ((string)($pack['article_type']??'')!==$type) {
                    $errors[]=self::err('BLOCKED_FACT_PACK_ARTICLE_TYPE_MISMATCH','FACT_PACK_TYPE_MUST_EQUAL_PLAN_ITEM_TYPE','fact_pack.article_type',$type,$pack['article_type']??null,'Fact-Pack und Planeintrag sind unterschiedlichen Beitragstypen zugeordnet.',$context,$server_state_hash,$index);
                }
                $source_hashes=isset($item['source_hashes'])&&is_array($item['source_hashes'])?$item['source_hashes']:array();
                self::validate_production_fact_pack($pack,$item,$index,$errors,$context,$server_state_hash);
                $actual_hash=PPM679_Storage::fact_pack_hash((string)($item['source_snapshot_id']??''),$pack);
                if ($actual_hash==='' || !in_array($actual_hash,$source_hashes,true)) {
                    $errors[]=self::err('BLOCKED_FACT_PACK_HASH_MISMATCH','PLAN_SOURCE_HASHES_MUST_INCLUDE_STORED_FACT_PACK_HASH','plan.items['.$index.'].source_hashes',$actual_hash!==''?$actual_hash:'stored fact-pack hash',$source_hashes,'Der Plan ist nicht an den tatsächlich in der Registry gespeicherten Fact-Pack-Hash gebunden.',$context,$server_state_hash,$index);
                }
            }
        }

        // Teilwellen mit 1 bis 4 unterschiedlichen freigegebenen Beitragstypen sind erlaubt.
        // Die Sperre gegen doppelte Beitragstypen bleibt unverändert oberhalb aktiv.
        // Alle vier Typdefinitionen und alle Inhalts-, Qualitäts-, Quellen-, Link-, Hash- und Readback-Prüfungen bleiben unverändert.
        // Fehlende Typen innerhalb einer Teilwelle erzeugen daher keinen eigenen Blocker.
        // Ende der ausschließlich cardinalitätsbezogenen Freigabe.

        $actual_contracts=self::active_contract_hashes($plan_contract);
        $bound=isset($plan['contract_hashes'])&&is_array($plan['contract_hashes'])?$plan['contract_hashes']:array();
        foreach ($actual_contracts as $key=>$hash) {
            if (!isset($bound[$key]) || !is_string($bound[$key]) || !hash_equals($hash,$bound[$key])) {
                $errors[]=self::err('BLOCKED_PLAN_CONTRACT_HASH_MISMATCH','PLAN_MUST_BIND_TO_ACTIVE_CONTRACT_HASHES','plan.contract_hashes.'.$key,$hash,$bound[$key]??null,'Der Plan wurde nicht gegen den aktiven Vertragsstand gebaut.',$context,$server_state_hash);
            }
        }

        return array(
            'ok'=>!$errors,
            'errors'=>$errors,
            'plan'=>$plan,
            'plan_hash'=>PPM679_Diagnostic::stable_hash($plan)
        );
    }

    public static function active_contract_hashes($plan_contract=self::CONTRACT) {
        $map=array(
            'article_type_templates'=>'contracts/article-type-templates.json',
            'gold_core_binding'=>'contracts/gold-core-binding-v1.json',
            'content_vault_manifest'=>'contracts/content-vault-manifest-v1.json',
            'table_contract'=>'contracts/table-contract-v1.json',
            'diagnostic_contract'=>'contracts/diagnostic-contract-v3.json',
            'live_state_gate'=>'contracts/live-state-gate-v1.json',
            'known_error_gate'=>'contracts/known-error-gate-v1.json',
            'content_structure_language_gate'=>'contracts/content-structure-language-gate-v2.json',
            'production_plan'=>$plan_contract===self::CONTRACT_V5?'contracts/production-plan-v5.json':'contracts/production-plan-v4.json',
        );
        if ($plan_contract===self::CONTRACT_V5) {
            $map['content_validation_contract']='contracts/content-validation-contract-v2.json';
            $map['portal_structure_contract']='contracts/portal-structure-contract-v1.json';
            $map['wordpress_taxonomy_contract']='contracts/wordpress-taxonomy-contract-v1.json';
            $map['wordpress_taxonomy_snapshot']='contracts/wordpress-taxonomy-snapshot-v1.json';
            $map['portal_wp_architecture_review']='contracts/portal-wp-taxonomy-architecture-review-v1-1.json';
        }
        $out=array();
        foreach ($map as $key=>$relative) {
            $out[$key]=hash_file('sha256',PPM679_PLUGIN_DIR.$relative);
        }
        return $out;
    }

    private static function validate_runtime_payload($item,$index,&$errors,$context,$server_state_hash,$is_v5=false) {
        $type=(string)($item['article_type']??'');
        $topic=(string)($item['topic']??'');
        $snapshot_id=(string)($item['source_snapshot_id']??'');
        $order=isset($item['runtime_order'])&&is_array($item['runtime_order'])?$item['runtime_order']:array();
        $article=isset($item['canonical_article'])&&is_array($item['canonical_article'])?$item['canonical_article']:array();
        $quality_binding=isset($item['quality_binding'])&&is_array($item['quality_binding'])?$item['quality_binding']:array();
        $quality_binding_hash=strtolower(trim((string)($item['quality_binding_hash']??'')));
        if ((string)($quality_binding['contract']??'')!=='content_structure_language_binding_v2') {
            $errors[]=self::err('BLOCKED_WAVE2_QUALITY_BINDING_MISSING','PLAN_ITEM_REQUIRES_WAVE2_QUALITY_BINDING','plan.items['.$index.'].quality_binding.contract','content_structure_language_binding_v2',$quality_binding['contract']??null,'Der Planeintrag besitzt keine vollständige Wave-2-Qualitätsbindung.',$context,$server_state_hash,$index);
        }
        $actual_quality_binding_hash=PPM679_Diagnostic::stable_hash($quality_binding);
        if (!preg_match('/^[0-9a-f]{64}$/',$quality_binding_hash) || !hash_equals($actual_quality_binding_hash,$quality_binding_hash)) {
            $errors[]=self::err('BLOCKED_WAVE2_QUALITY_BINDING_HASH','PLAN_ITEM_QUALITY_BINDING_HASH_MUST_MATCH','plan.items['.$index.'].quality_binding_hash',$actual_quality_binding_hash,$quality_binding_hash,'Die Wave-2-Qualitätsbindung ist nicht exakt an ihren Hash gebunden.',$context,$server_state_hash,$index);
        }
        $required_order=array('order_id','article_type','title','slug','subject_scope','subject_label','lead','conclusion','links','allowed_fact_ids');
        foreach ($required_order as $field) {
            if (!array_key_exists($field,$order) || $order[$field]==='' || $order[$field]===array()) {
                $errors[]=self::err('BLOCKED_CANONICAL_RUNTIME_ORDER_INCOMPLETE','RUNTIME_ORDER_REQUIRES_CROSS_DOMAIN_FIELDS','plan.items['.$index.'].runtime_order.'.$field,'present non-empty value',$order[$field]??null,'Der eingebundene Cross-Domain-Auftrag ist unvollständig.',$context,$server_state_hash,$index);
            }
        }
        if ((string)($order['article_type']??'')!==$type || (string)($order['title']??'')!==$topic) {
            $errors[]=self::err('BLOCKED_CANONICAL_RUNTIME_ORDER_BINDING','RUNTIME_ORDER_TYPE_AND_TITLE_MUST_MATCH_PLAN_ITEM','plan.items['.$index.'].runtime_order',array('article_type'=>$type,'title'=>$topic),array('article_type'=>$order['article_type']??null,'title'=>$order['title']??null),'Der Cross-Domain-Auftrag ist nicht exakt an den Planeintrag gebunden.',$context,$server_state_hash,$index);
        }
        $links=isset($order['links'])&&is_array($order['links'])?$order['links']:array();
        if (count($links)!==3) {
            $errors[]=self::err('BLOCKED_CANONICAL_RUNTIME_LINK_PLAN','RUNTIME_ORDER_REQUIRES_EXACTLY_THREE_SEMANTIC_LINKS','plan.items['.$index.'].runtime_order.links',3,count($links),'Der Cross-Domain-Auftrag besitzt nicht genau drei inhaltlich gebundene Links.',$context,$server_state_hash,$index);
        }
        foreach ($links as $link_index=>$link) {
            foreach (array('role','href','anchor','reason','section_id') as $field) {
                if (!is_array($link) || trim((string)($link[$field]??''))==='') {
                    $errors[]=self::err('BLOCKED_CANONICAL_RUNTIME_LINK_FIELD','RUNTIME_LINK_REQUIRES_HREF_ANCHOR_AND_REASON','plan.items['.$index.'].runtime_order.links['.$link_index.'].'.$field,'non-empty',$link[$field]??null,'Ein semantischer Link ist nicht vollständig beschrieben.',$context,$server_state_hash,$index);
                }
            }
        }
        $required_roles=array('parent_category','semantic_related','further_information');
        $actual_roles=array();
        foreach ($links as $link) { if (is_array($link)) { $actual_roles[]=(string)($link['role']??''); } }
        sort($actual_roles,SORT_STRING);
        $expected_roles=$required_roles; sort($expected_roles,SORT_STRING);
        if ($actual_roles!==$expected_roles) {
            $errors[]=self::err('BLOCKED_WAVE2_RUNTIME_LINK_ROLES','RUNTIME_ORDER_REQUIRES_EXACTLY_THE_THREE_APPROVED_LINK_ROLES','plan.items['.$index.'].runtime_order.links.roles',$expected_roles,$actual_roles,'Die drei internen Linkrollen fehlen, sind doppelt oder wurden ersetzt.',$context,$server_state_hash,$index);
        }
        $required_article=array('order_id','article_type','title','slug','body_html','body_text','body_html_sha256','content_plan_hash');
        if ($is_v5) {
            $required_article[]='validation_contract_version';
            $required_article[]='section_requirements_hash';
            $required_article[]='category_binding_hash';
        }
        foreach ($required_article as $field) {
            if (!array_key_exists($field,$article) || $article[$field]==='') {
                $errors[]=self::err('BLOCKED_CANONICAL_ARTICLE_PAYLOAD_INCOMPLETE','CANONICAL_ARTICLE_REQUIRES_BOUND_RENDER_FIELDS','plan.items['.$index.'].canonical_article.'.$field,'present non-empty value',$article[$field]??null,'Der vom bestehenden Cross-Domain-Builder erzeugte Artikelpayload ist unvollständig.',$context,$server_state_hash,$index);
            }
        }
        if ((string)($article['order_id']??'')!==(string)($order['order_id']??'') || (string)($article['article_type']??'')!==$type || (string)($article['title']??'')!==$topic || (string)($article['slug']??'')!==(string)($order['slug']??'')) {
            $errors[]=self::err('BLOCKED_CANONICAL_ARTICLE_BINDING','CANONICAL_ARTICLE_MUST_MATCH_RUNTIME_ORDER_AND_PLAN','plan.items['.$index.'].canonical_article','matching order, type, title and slug',$article,'Der kanonische Artikelpayload ist nicht exakt an Plan und Cross-Domain-Auftrag gebunden.',$context,$server_state_hash,$index);
        }
        $html=(string)($article['body_html']??'');
        $actual_hash=hash('sha256',$html);
        if (!hash_equals($actual_hash,(string)($article['body_html_sha256']??''))) {
            $errors[]=self::err('BLOCKED_CANONICAL_ARTICLE_HASH','CANONICAL_ARTICLE_HTML_HASH_MUST_MATCH','plan.items['.$index.'].canonical_article.body_html_sha256',$actual_hash,$article['body_html_sha256']??null,'Der gerenderte Artikel wurde nach dem Cross-Domain-Build verändert.',$context,$server_state_hash,$index);
        }
        $plain=html_entity_decode($html,ENT_QUOTES|ENT_HTML5,'UTF-8');
        $plain=(string)preg_replace('/<[^>]+>/u',' ',$plain);
        $plain=trim((string)preg_replace('/\s+/u',' ',$plain));
        if ($plain!==(string)($article['body_text']??'')) {
            $errors[]=self::err('BLOCKED_CANONICAL_ARTICLE_TEXT','CANONICAL_ARTICLE_TEXT_MUST_MATCH_RENDERED_HTML','plan.items['.$index.'].canonical_article.body_text',$plain,$article['body_text']??null,'Klartext und kanonisches HTML sind nicht identisch gebunden.',$context,$server_state_hash,$index);
        }
        if ($snapshot_id==='') {
            $errors[]=self::err('BLOCKED_CANONICAL_FACT_PACK_REFERENCE','SOURCE_SNAPSHOT_ID_MUST_REFERENCE_CANONICAL_FACT_PACK','plan.items['.$index.'].source_snapshot_id','canonical fact_pack_id',$snapshot_id,'Der Planeintrag besitzt keine kanonische Fact-Pack-Referenz.',$context,$server_state_hash,$index);
        }
    }


    private static function validate_v5_contract_payload($item,$index,&$errors,$context,$server_state_hash) {
        $version=(string)($item['validation_contract_version']??'');
        $requirements=isset($item['section_requirements'])&&is_array($item['section_requirements'])?$item['section_requirements']:null;
        $declared_hash=strtolower(trim((string)($item['section_requirements_hash']??'')));
        $article=isset($item['canonical_article'])&&is_array($item['canonical_article'])?$item['canonical_article']:array();
        if ($version!==self::VALIDATION_CONTRACT_V5) {
            $errors[]=self::err('BLOCKED_VALIDATION_CONTRACT_VERSION_UNKNOWN','PLAN_V5_ITEM_REQUIRES_SECTION_REQUIREMENTS_V1','plan.items['.$index.'].validation_contract_version',self::VALIDATION_CONTRACT_V5,$version,'Der Planeintrag verwendet einen fehlenden oder unbekannten Validierungsvertrag.',$context,$server_state_hash,$index);
        }
        if (!is_array($requirements) || (string)($requirements['contract']??'')!==self::VALIDATION_CONTRACT_V5 || !isset($requirements['sections']) || !is_array($requirements['sections']) || !$requirements['sections']) {
            $errors[]=self::err('BLOCKED_VALIDATION_CONTRACT_VERSION_MISSING','PLAN_V5_ITEM_REQUIRES_COMPLETE_SECTION_REQUIREMENTS','plan.items['.$index.'].section_requirements','complete SECTION_REQUIREMENTS_V1 object',$requirements,'Die Abschnittsanforderungen fehlen oder sind unvollständig.',$context,$server_state_hash,$index);
            return;
        }
        $actual_hash=PPM679_Diagnostic::stable_hash($requirements);
        if (!self::valid_non_repetitive_sha256($declared_hash) || !hash_equals($actual_hash,$declared_hash)) {
            $errors[]=self::err('BLOCKED_SECTION_REQUIREMENTS_HASH_MISMATCH','SECTION_REQUIREMENTS_HASH_MUST_MATCH_CANONICAL_JSON','plan.items['.$index.'].section_requirements_hash',$actual_hash,$declared_hash,'Die Abschnittsanforderungen sind nicht exakt an ihren kanonischen Hash gebunden.',$context,$server_state_hash,$index);
        }
        if ((string)($article['validation_contract_version']??'')!==self::VALIDATION_CONTRACT_V5) {
            $errors[]=self::err('BLOCKED_VALIDATION_CONTRACT_VERSION_UNKNOWN','CANONICAL_ARTICLE_MUST_MATCH_V5_VALIDATION_CONTRACT','plan.items['.$index.'].canonical_article.validation_contract_version',self::VALIDATION_CONTRACT_V5,$article['validation_contract_version']??null,'Der kanonische Artikel ist nicht an denselben Validierungspfad gebunden.',$context,$server_state_hash,$index);
        }
        if (!hash_equals($declared_hash,strtolower(trim((string)($article['section_requirements_hash']??''))))) {
            $errors[]=self::err('BLOCKED_SECTION_REQUIREMENTS_HASH_MISMATCH','CANONICAL_ARTICLE_SECTION_REQUIREMENTS_HASH_MUST_MATCH_ITEM','plan.items['.$index.'].canonical_article.section_requirements_hash',$declared_hash,$article['section_requirements_hash']??null,'Planeintrag und kanonischer Artikel verwenden unterschiedliche Abschnittsanforderungen.',$context,$server_state_hash,$index);
        }
        $actual_contracts=self::active_contract_hashes(self::CONTRACT_V5);
        $bound=isset($item['contract_hashes'])&&is_array($item['contract_hashes'])?$item['contract_hashes']:array();
        foreach ($actual_contracts as $key=>$hash) {
            if (!isset($bound[$key]) || !is_string($bound[$key]) || !hash_equals($hash,$bound[$key])) {
                $errors[]=self::err('BLOCKED_PLAN_CONTRACT_HASH_MISMATCH','PLAN_V5_ITEM_MUST_BIND_TO_ACTIVE_CONTRACT_HASHES','plan.items['.$index.'].contract_hashes.'.$key,$hash,$bound[$key]??null,'Der neue Planeintrag ist nicht an den aktiven Vertragsstand gebunden.',$context,$server_state_hash,$index);
            }
        }
    }


    private static function validate_v5_category_binding($item,$index,&$errors,$context,$server_state_hash) {
        $binding=isset($item['category_binding'])&&is_array($item['category_binding'])?$item['category_binding']:null;
        $declared_hash=strtolower(trim((string)($item['category_binding_hash']??'')));
        $article=isset($item['canonical_article'])&&is_array($item['canonical_article'])?$item['canonical_article']:array();
        $path='plan.items['.$index.'].category_binding';
        $required=array('name','slug','hierarchy_path','portal_path','portal_level','portal_node_types','taxonomy','article_type','category_source_snapshot_hash','portal_structure_snapshot_hash','wp_taxonomy_contract_hash','wp_taxonomy_snapshot_hash','wp_parent_chain_required','expected_wp_parent_slugs','expected_wp_taxonomy_depth');
        if (!is_array($binding)) {
            $errors[]=self::err('BLOCKED_PLAN_CATEGORY_UNBOUND','PLAN_V5_ITEM_REQUIRES_CATEGORY_BINDING',$path,'complete category binding object',$binding,'Der V5-Planeintrag besitzt keine semantisch gebundene Zielkategorie.',$context,$server_state_hash,$index);
            return;
        }
        foreach ($required as $field) {
            $missing=!array_key_exists($field,$binding);
            if(!$missing && is_string($binding[$field])){$missing=trim($binding[$field])==='';}
            if(!$missing && $field==='portal_node_types'){$missing=!is_array($binding[$field])||!$binding[$field];}
            if(!$missing && $field==='expected_wp_parent_slugs'){$missing=!is_array($binding[$field]);}
            if(!$missing && $field==='wp_parent_chain_required'){$missing=!is_bool($binding[$field]);}
            if(!$missing && in_array($field,array('portal_level','expected_wp_taxonomy_depth'),true)){$missing=!is_int($binding[$field])||$binding[$field]<1;}
            if ($missing) {
                $errors[]=self::err('BLOCKED_PLAN_CATEGORY_UNBOUND','PLAN_V5_CATEGORY_BINDING_REQUIRES_ALL_FIELDS',$path.'.'.$field,'present valid value',$binding[$field]??null,'Die Kategorienbindung des V5-Planeintrags ist unvollständig.',$context,$server_state_hash,$index);
            }
        }
        foreach (array('term_id','live_term_id','resolved_term_id','fallback_term_id','expected_term_id') as $forbidden) {
            if (array_key_exists($forbidden,$binding)) {
                $errors[]=self::err('BLOCKED_PLAN_CATEGORY_FIXED_TERM_ID','PLAN_CATEGORY_BINDING_MUST_NOT_CONTAIN_PORTAL_SPECIFIC_TERM_ID',$path.'.'.$forbidden,'field absent',$binding[$forbidden],'Eine portalabhängige Term-ID darf nicht im allgemeinen Redaktionsplan festgeschrieben werden.',$context,$server_state_hash,$index);
            }
        }
        $slug=strtolower(trim((string)($binding['slug']??'')));
        $name=trim((string)($binding['name']??''));
        $hierarchy=trim((string)($binding['hierarchy_path']??''));
        $taxonomy=trim((string)($binding['taxonomy']??''));
        $article_type=trim((string)($binding['article_type']??''));
        $snapshot_hash=strtolower(trim((string)($binding['category_source_snapshot_hash']??'')));
        if ($slug==='uncategorized' || strcasecmp($name,'Uncategorized')===0 || preg_match('/(?:^|>\s*)(?:uncategorized|allgemein|standard)(?:\s*>|$)/iu',$hierarchy)) {
            $errors[]=self::err('BLOCKED_PLAN_CATEGORY_FALLBACK','PLAN_CATEGORY_BINDING_MUST_NOT_USE_FALLBACK_CATEGORY',$path,'specific assignable semantic category',$binding,'Fallback-, Standard- oder Uncategorized-Kategorien sind im Redaktionsplan unzulässig.',$context,$server_state_hash,$index);
        }
        if ($taxonomy!=='category') {
            $errors[]=self::err('BLOCKED_PLAN_CATEGORY_TAXONOMY','PLAN_CATEGORY_BINDING_REQUIRES_WORDPRESS_CATEGORY_TAXONOMY',$path.'.taxonomy','category',$taxonomy,'Der Planeintrag ist nicht an die freigegebene WordPress-Kategorietaxonomie gebunden.',$context,$server_state_hash,$index);
        }
        if ($article_type!==(string)($item['article_type']??'')) {
            $errors[]=self::err('BLOCKED_PLAN_CATEGORY_ARTICLE_TYPE_MISMATCH','PLAN_CATEGORY_ARTICLE_TYPE_MUST_MATCH_ITEM',$path.'.article_type',$item['article_type']??null,$article_type,'Artikeltyp und Kategorienbindung des Planeintrags stimmen nicht überein.',$context,$server_state_hash,$index);
        }
        if ($article_type==='Journal') {
            self::validate_v5_journal_category_binding($item,$binding,$declared_hash,$index,$errors,$context,$server_state_hash);
            return;
        }
        foreach(PPM679_Portal_WP_Structure_Validator::validate_editorial_binding($binding) as $arch_error){$arch_error['item_index']=$index;$errors[]=$arch_error;}
        if((string)($binding['portal_path']??'')!==$hierarchy){$errors[]=self::err('BLOCKED_PLAN_PORTAL_PATH_MISMATCH','PLAN_LEGACY_HIERARCHY_PATH_MUST_EQUAL_PORTAL_PATH',$path.'.portal_path',$hierarchy,$binding['portal_path']??null,'Portalpfad und Legacy-Hierarchiefeld weichen ab.',$context,$server_state_hash,$index);}
        if (!preg_match('/^[0-9a-f]{64}$/',$snapshot_hash)) {
            $errors[]=self::err('BLOCKED_PLAN_CATEGORY_SNAPSHOT_UNBOUND','PLAN_CATEGORY_BINDING_REQUIRES_REAL_SNAPSHOT_HASH',$path.'.category_source_snapshot_hash','64 hexadecimal SHA-256',$snapshot_hash,'Die Kategorienbindung ist nicht an einen prüfbaren Kategorien-Snapshot gebunden.',$context,$server_state_hash,$index);
        }
        $snapshot=PPM679_Category_Hierarchy_Validator::load();
        $snapshot_errors=PPM679_Category_Hierarchy_Validator::validate($snapshot);
        if ($snapshot_errors) {
            $errors[]=self::err('BLOCKED_PLAN_CATEGORY_SOURCE_INVALID','PLAN_CATEGORY_BINDING_REQUIRES_VALID_ACTIVE_CATEGORY_SOURCE',$path.'.category_source_snapshot_hash','valid active category snapshot',$snapshot_errors,'Die aktive Kategorienquelle ist ungültig oder nicht prüfbar.',$context,$server_state_hash,$index);
        } else {
            $active_snapshot_hash=(string)($snapshot['snapshot_sha256']??'');
            if ($snapshot_hash==='' || !hash_equals($active_snapshot_hash,$snapshot_hash)) {
                $errors[]=self::err('BLOCKED_PLAN_CATEGORY_SNAPSHOT_STALE','PLAN_CATEGORY_BINDING_MUST_MATCH_ACTIVE_CATEGORY_SNAPSHOT',$path.'.category_source_snapshot_hash',$active_snapshot_hash,$snapshot_hash,'Der Planeintrag verwendet einen veralteten oder fremden Kategorien-Snapshot.',$context,$server_state_hash,$index);
            }
            $matches=array_values(array_filter((array)($snapshot['categories']??array()),static function($category) use($slug,$taxonomy){
                return is_array($category) && (string)($category['slug']??'')===$slug && (string)($category['taxonomy']??'')===$taxonomy;
            }));
            if (count($matches)!==1) {
                $errors[]=self::err('BLOCKED_PLAN_CATEGORY_RESOLUTION','PLAN_CATEGORY_BINDING_MUST_RESOLVE_UNIQUELY_IN_ACTIVE_SNAPSHOT',$path,array('unique_slug'=>$slug,'taxonomy'=>$taxonomy),count($matches),'Die semantische Plankategorie fehlt im aktiven Kategorienbaum oder ist mehrdeutig.',$context,$server_state_hash,$index);
            } else {
                $matched=$matches[0];
                $expected=array(
                    'name'=>(string)($matched['name']??''),
                    'slug'=>(string)($matched['slug']??''),
                    'hierarchy_path'=>(string)($matched['portal_path']??$matched['hierarchy_path']??''),
                    'portal_path'=>(string)($matched['portal_path']??$matched['hierarchy_path']??''),
                    'portal_level'=>(int)($matched['portal_level']??$matched['level']??0),
                    'portal_node_types'=>array_values((array)($matched['portal_node_types']??array())),
                    'taxonomy'=>(string)($matched['taxonomy']??''),
                    'article_type'=>$article_type,
                    'category_source_snapshot_hash'=>$active_snapshot_hash,
                    'portal_structure_snapshot_hash'=>(string)($matched['portal_structure_snapshot_hash']??$binding['portal_structure_snapshot_hash']??''),
                    'wp_taxonomy_contract_hash'=>(string)($matched['wp_taxonomy_contract_hash']??$binding['wp_taxonomy_contract_hash']??''),
                    'wp_taxonomy_snapshot_hash'=>(string)($matched['wp_taxonomy_snapshot_hash']??$binding['wp_taxonomy_snapshot_hash']??''),
                    'wp_parent_chain_required'=>(bool)($matched['wp_parent_chain_required']??false),
                    'expected_wp_parent_slugs'=>array_values((array)($matched['expected_wp_parent_slugs']??array())),
                    'expected_wp_taxonomy_depth'=>(int)($matched['expected_wp_taxonomy_depth']??0)
                );
                $actual=array(
                    'name'=>$name,
                    'slug'=>$slug,
                    'hierarchy_path'=>$hierarchy,
                    'portal_path'=>(string)($binding['portal_path']??''),
                    'portal_level'=>(int)($binding['portal_level']??0),
                    'portal_node_types'=>array_values((array)($binding['portal_node_types']??array())),
                    'taxonomy'=>$taxonomy,
                    'article_type'=>$article_type,
                    'category_source_snapshot_hash'=>$snapshot_hash,
                    'portal_structure_snapshot_hash'=>(string)($binding['portal_structure_snapshot_hash']??''),
                    'wp_taxonomy_contract_hash'=>(string)($binding['wp_taxonomy_contract_hash']??''),
                    'wp_taxonomy_snapshot_hash'=>(string)($binding['wp_taxonomy_snapshot_hash']??''),
                    'wp_parent_chain_required'=>(bool)($binding['wp_parent_chain_required']??false),
                    'expected_wp_parent_slugs'=>array_values((array)($binding['expected_wp_parent_slugs']??array())),
                    'expected_wp_taxonomy_depth'=>(int)($binding['expected_wp_taxonomy_depth']??0)
                );
                if ($actual!==$expected || empty($matched['assignable']) || !in_array($article_type,(array)($matched['allowed_article_types']??array()),true)) {
                    $errors[]=self::err('BLOCKED_PLAN_CATEGORY_HIERARCHY_MISMATCH','PLAN_CATEGORY_BINDING_MUST_MATCH_ASSIGNABLE_ACTIVE_HIERARCHY',$path,$expected,$actual,'Name, Slug, Hierarchie, Ebene oder zulässiger Artikeltyp der Plankategorie stimmen nicht mit der aktiven Kategorienquelle überein.',$context,$server_state_hash,$index);
                }
            }
        }
        $actual_hash=PPM679_Diagnostic::stable_hash($binding);
        if (!preg_match('/^[0-9a-f]{64}$/',$declared_hash) || !hash_equals($actual_hash,$declared_hash)) {
            $errors[]=self::err('BLOCKED_PLAN_CATEGORY_BINDING_HASH','PLAN_CATEGORY_BINDING_HASH_MUST_MATCH_CANONICAL_JSON','plan.items['.$index.'].category_binding_hash',$actual_hash,$declared_hash,'Die Kategorienbindung ist nicht exakt an ihren kanonischen Hash gebunden.',$context,$server_state_hash,$index);
        }
        $article_hash=strtolower(trim((string)($article['category_binding_hash']??'')));
        if ($declared_hash==='' || !hash_equals($declared_hash,$article_hash)) {
            $errors[]=self::err('BLOCKED_PLAN_CATEGORY_ARTICLE_BINDING','CANONICAL_ARTICLE_CATEGORY_BINDING_HASH_MUST_MATCH_ITEM','plan.items['.$index.'].canonical_article.category_binding_hash',$declared_hash,$article_hash,'Planeintrag und kanonischer Artikel verwenden unterschiedliche Kategorienbindungen.',$context,$server_state_hash,$index);
        }
    }

    private static function validate_v5_journal_category_binding($item,$binding,$declared_hash,$index,&$errors,$context,$server_state_hash) {
        $path='plan.items['.$index.'].category_binding';$journal=PPM679_Editorial_Plan_Registry::journal();$slug=(string)($binding['slug']??'');$matches=array_values(array_filter((array)($journal['categories']??array()),static function($c) use($slug){return is_array($c)&&(string)($c['slug']??'')===$slug;}));
        if(count($matches)!==1){$errors[]=self::err('BLOCKED_JOURNAL_CATEGORY_RESOLUTION','JOURNAL_CATEGORY_BINDING_MUST_RESOLVE_UNIQUELY_IN_SIGNED_REGISTRY',$path.'.slug','one signed Journal category',$slug,'Die Journal-Kategorie fehlt im signierten Register oder ist mehrdeutig.',$context,$server_state_hash,$index);return;}
        $c=$matches[0];$journal_self=(string)($journal['contract_self_sha256']??'');$journal_file=PPM679_PLUGIN_DIR.PPM679_Editorial_Plan_Registry::JOURNAL;$journal_file_hash=is_file($journal_file)?hash_file('sha256',$journal_file):'';
        $expected=array('name'=>(string)$c['name'],'slug'=>(string)$c['slug'],'hierarchy_path'=>(string)$c['portal_path'],'portal_path'=>(string)$c['portal_path'],'portal_level'=>2,'portal_node_types'=>array('page','wordpress_category'),'taxonomy'=>'category','article_type'=>'Journal','category_source_snapshot_hash'=>$journal_self,'portal_structure_snapshot_hash'=>$journal_self,'wp_taxonomy_contract_hash'=>$journal_file_hash,'wp_taxonomy_snapshot_hash'=>$journal_self,'wp_parent_chain_required'=>false,'expected_wp_parent_slugs'=>array(),'expected_wp_taxonomy_depth'=>1);
        $actual=array();foreach(array_keys($expected) as $k){$actual[$k]=$binding[$k]??null;}if($actual!==$expected){$errors[]=self::err('BLOCKED_JOURNAL_CATEGORY_BINDING_MISMATCH','JOURNAL_CATEGORY_BINDING_MUST_MATCH_SIGNED_REGISTRY_AND_FLAT_RUNTIME_TAXONOMY',$path,$expected,$actual,'Die Journal-Kategorienbindung weicht vom signierten Register oder der ausdrücklich flachen WordPress-Laufzeitbindung ab.',$context,$server_state_hash,$index);}
        foreach(array('term_id','live_term_id','resolved_term_id','fallback_term_id','expected_term_id') as $forbidden){if(array_key_exists($forbidden,$binding)){$errors[]=self::err('BLOCKED_PLAN_CATEGORY_FIXED_TERM_ID','JOURNAL_RUNTIME_TERM_ID_MUST_NOT_BE_HARDCODED',$path.'.'.$forbidden,'field absent',$binding[$forbidden],'Eine Journal-Term-ID darf nicht festgeschrieben werden.',$context,$server_state_hash,$index);}}
        $actual_hash=PPM679_Diagnostic::stable_hash($binding);if(!preg_match('/^[0-9a-f]{64}$/',$declared_hash)||!hash_equals($actual_hash,$declared_hash)){$errors[]=self::err('BLOCKED_PLAN_CATEGORY_BINDING_HASH','PLAN_CATEGORY_BINDING_HASH_MUST_MATCH_CANONICAL_JSON','plan.items['.$index.'].category_binding_hash',$actual_hash,$declared_hash,'Die Journal-Kategorienbindung ist nicht exakt hashgebunden.',$context,$server_state_hash,$index);}
        $article=(array)($item['canonical_article']??array());$article_hash=strtolower(trim((string)($article['category_binding_hash']??'')));if($declared_hash===''||!hash_equals($declared_hash,$article_hash)){$errors[]=self::err('BLOCKED_PLAN_CATEGORY_ARTICLE_BINDING','CANONICAL_ARTICLE_CATEGORY_BINDING_HASH_MUST_MATCH_ITEM','plan.items['.$index.'].canonical_article.category_binding_hash',$declared_hash,$article_hash,'Planeintrag und kanonischer Journal-Artikel verwenden unterschiedliche Kategorienbindungen.',$context,$server_state_hash,$index);}
    }

    private static function validate_production_fact_pack($pack,$item,$index,&$errors,$context,$server_state_hash) {
        $contract=(string)($pack['contract']??'');
        if ($contract!=='' && (strcasecmp($contract,'test_fact_pack_v1')===0 || preg_match('/\b(test|dummy|fixture|placeholder)\b/i',$contract))) {
            $errors[]=self::err('BLOCKED_PRODUCTION_TEST_FACT_PACK','PRODUCTION_MUST_NOT_USE_TEST_FACT_PACK_CONTRACT','fact_pack.contract','non-test production fact-pack contract',$contract,'Ein Test- oder Fixture-Vertrag darf nicht als Faktenbasis verwendet werden.',$context,$server_state_hash,$index);
        }
        if ((string)($pack['fact_pack_id']??'')!==(string)($item['source_snapshot_id']??'')) {
            $errors[]=self::err('BLOCKED_CANONICAL_FACT_PACK_ID_MISMATCH','SOURCE_SNAPSHOT_ID_MUST_EQUAL_CANONICAL_FACT_PACK_ID','fact_pack.fact_pack_id',$item['source_snapshot_id']??null,$pack['fact_pack_id']??null,'Der Plan verweist nicht auf die Identität des gespeicherten kanonischen Fact-Packs.',$context,$server_state_hash,$index);
        }
        if ((string)($pack['status']??'')!=='SOURCE_VERIFIED_PRODUCTION_READY' || (string)($pack['production_readiness_status']??'')!=='SOURCE_VERIFIED_PRODUCTION_READY') {
            $errors[]=self::err('BLOCKED_CANONICAL_FACT_PACK_NOT_READY','CANONICAL_FACT_PACK_MUST_BE_SOURCE_VERIFIED_PRODUCTION_READY','fact_pack.status','SOURCE_VERIFIED_PRODUCTION_READY',array('status'=>$pack['status']??null,'production_readiness_status'=>$pack['production_readiness_status']??null),'Das kanonische Fact-Pack ist nicht vollständig produktionsbereit.',$context,$server_state_hash,$index);
        }
        $source_hashes=isset($item['source_hashes'])&&is_array($item['source_hashes'])?$item['source_hashes']:array();
        foreach ($source_hashes as $hash_index=>$hash) {
            if (!self::valid_non_repetitive_sha256($hash)) {
                $errors[]=self::err('BLOCKED_PLAN_DUMMY_SOURCE_HASH','PRODUCTION_PLAN_SOURCE_HASH_MUST_BE_REAL_SHA256','plan.items['.$index.'].source_hashes['.$hash_index.']','64 hexadecimal non-repetitive SHA-256',$hash,'Der Produktionsplan enthält einen ungültigen, repetitiven oder erkennbaren Dummy-Hash.',$context,$server_state_hash,$index);
            }
        }
        if (!PPM679_WP::is_test_mode()) {
            $fixture_file=PPM679_PLUGIN_DIR.'fixtures/fact-packs/'.basename((string)($item['source_snapshot_id']??'')).'.json';
            if (is_file($fixture_file)) {
                $fixture_hash=hash_file('sha256',$fixture_file);
                if (in_array($fixture_hash,$source_hashes,true)) {
                    $errors[]=self::err('BLOCKED_PRODUCTION_FIXTURE_FILE_BINDING','PRODUCTION_PLAN_MUST_NOT_BIND_TO_LOCAL_FIXTURE_FILE','plan.items['.$index.'].source_hashes','stored production fact-pack hash',$fixture_hash,'Der Produktionsplan ist unmittelbar an den Hash einer lokalen Test-Fixture-Datei gebunden.',$context,$server_state_hash,$index);
                }
            }
        }
        $claims=isset($pack['claims'])&&is_array($pack['claims'])?$pack['claims']:array();
        if (count($claims)<3) {
            $errors[]=self::err('BLOCKED_CANONICAL_FACT_PACK_CLAIM_COUNT','CANONICAL_FACT_PACK_REQUIRES_AT_LEAST_THREE_CLAIMS','fact_pack.claims','at least 3',count($claims),'Das kanonische Fact-Pack enthält zu wenige gebundene Aussagen.',$context,$server_state_hash,$index);
        }
        $claim_ids=array();
        foreach ($claims as $claim_index=>$claim) {
            if (!is_array($claim)) { continue; }
            $claim_ids[]=(string)($claim['fact_id']??'');
            $source_id=(string)($claim['source_id']??'');
            if ($source_id==='' || self::blocked_placeholder_text($source_id)) {
                $errors[]=self::err('BLOCKED_PRODUCTION_PLACEHOLDER_SOURCE_TITLE','PRODUCTION_SOURCE_ID_MUST_BE_REAL_AND_NON_PLACEHOLDER','fact_pack.claims['.$claim_index.'].source_id','real source id',$source_id,'Die kanonische Quellenidentität ist leer oder als Platzhalter erkennbar.',$context,$server_state_hash,$index);
            }
            $source_hash=(string)($claim['evidence_text_sha256']??'');
            if (!self::valid_non_repetitive_sha256($source_hash)) {
                $errors[]=self::err('BLOCKED_PRODUCTION_DUMMY_SOURCE_HASH','PRODUCTION_CLAIM_EVIDENCE_HASH_MUST_BE_REAL_SHA256','fact_pack.claims['.$claim_index.'].evidence_text_sha256','64 hexadecimal non-repetitive SHA-256',$source_hash,'Die kanonische Faktenspur enthält keinen plausiblen realen SHA-256-Beleghash.',$context,$server_state_hash,$index);
            }
            if ((string)($claim['claim_status']??'')!=='FULLY_SUPPORTED') {
                $errors[]=self::err('BLOCKED_CANONICAL_CLAIM_NOT_SUPPORTED','EVERY_CANONICAL_CLAIM_MUST_BE_FULLY_SUPPORTED','fact_pack.claims['.$claim_index.'].claim_status','FULLY_SUPPORTED',$claim['claim_status']??null,'Eine kanonische Aussage ist nicht vollständig belegt.',$context,$server_state_hash,$index);
            }
        }
        $order=isset($item['runtime_order'])&&is_array($item['runtime_order'])?$item['runtime_order']:array();
        $allowed=isset($order['allowed_fact_ids'])&&is_array($order['allowed_fact_ids'])?$order['allowed_fact_ids']:array();
        foreach ($allowed as $fact_id) {
            if (!in_array((string)$fact_id,$claim_ids,true)) {
                $errors[]=self::err('BLOCKED_CANONICAL_ORDER_UNKNOWN_FACT','RUNTIME_ORDER_MAY_ONLY_REFERENCE_CLAIMS_FROM_BOUND_FACT_PACK','runtime_order.allowed_fact_ids','known fact id',$fact_id,'Der Cross-Domain-Auftrag referenziert eine Aussage außerhalb des gebundenen Fact-Packs.',$context,$server_state_hash,$index);
            }
        }
    }

    private static function blocked_placeholder_text($value) {
        return (bool)preg_match('/(?:^|[^\p{L}])(test(?:quelle)?|dummy|platzhalter|beispiel|lorem|fixture)(?:$|[^\p{L}])/iu',(string)$value);
    }

    private static function valid_non_repetitive_sha256($value) {
        $value=strtolower(trim((string)$value));
        if (!preg_match('/^[0-9a-f]{64}$/',$value)) { return false; }
        return !preg_match('/^([0-9a-f])\1{63}$/',$value);
    }

    private static function scan_forbidden($value,$path,&$errors,$context,$hash) {
        if (!is_array($value)) { return; }
        foreach ($value as $key=>$child) {
            $child_path=$path.'.'.$key;
            if (in_array((string)$key,self::FORBIDDEN_OPERATIONAL_FIELDS,true)) {
                $errors[]=self::err('BLOCKED_CLIENT_SUPPLIED_OPERATIONAL_IDENTIFIER','CLIENT_MUST_NOT_SUPPLY_OPERATIONAL_IDENTIFIERS',$child_path,'field absent',$child,'Operative Identifier dürfen ausschließlich serverseitig frisch erzeugt werden.',$context,$hash);
            }
            self::scan_forbidden($child,$child_path,$errors,$context,$hash);
        }
    }

    private static function err($code,$rule,$path,$expected,$actual,$reason,$context,$hash,$index=null) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$context,$hash,__CLASS__,$index,array('contracts/production-plan-v4.json','contracts/production-plan-v5.json','contracts/category-hierarchy-snapshot-v1.json'));
    }
}
