<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_WP {
    private static $test_options = array();
    private static $test_posts = array();
    private static $test_post_seq = 10000;
    private static $test_terms = array();
    private static $test_can_manage = true;
    private static $last_write_block = null;
    private static $test_plugin_versions = array(
        'portal-production-machine/portal-production-machine.php' => '6.7.9',
        'canonical-table-contract-v1/canonical-table-contract-v1.php' => '1.1.0'
    );
    private static $test_active_plugins = array(
        'portal-production-machine/portal-production-machine.php',
        'canonical-table-contract-v1/canonical-table-contract-v1.php'
    );

    public static function is_test_mode() {
        return defined('PPM679_TEST_MODE') && PPM679_TEST_MODE;
    }

    public static function get_option($name, $default = null) {
        if (self::is_test_mode()) {
            return array_key_exists($name, self::$test_options) ? self::$test_options[$name] : $default;
        }
        return function_exists('get_option') ? get_option($name, $default) : $default;
    }

    public static function update_option($name, $value) {
        if (self::is_test_mode()) {
            self::$test_options[$name] = $value;
            return true;
        }
        return function_exists('update_option') ? update_option($name, $value, false) : false;
    }

    public static function delete_option($name) {
        if (self::is_test_mode()) {
            unset(self::$test_options[$name]);
            return true;
        }
        return function_exists('delete_option') ? delete_option($name) : false;
    }

    public static function server_instance_id() {
        $id = (string) self::get_option('ppm_server_instance_id', '');
        if ($id !== '') { return $id; }
        if (self::is_test_mode()) {
            $id = 'ppm-test-instance-679';
        } else {
            try {
                $raw = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : bin2hex(random_bytes(16));
            } catch (Throwable $e) {
                $raw = hash('sha256', microtime(true) . '|' . mt_rand());
            }
            $id = 'ppm-' . $raw;
        }
        self::update_option('ppm_server_instance_id', $id);
        return $id;
    }

    public static function active_plugins() {
        if (self::is_test_mode()) { return self::$test_active_plugins; }
        return array_values((array) self::get_option('active_plugins', array()));
    }

    public static function set_test_active_plugins($plugins) {
        if (self::is_test_mode()) { self::$test_active_plugins = array_values((array) $plugins); }
    }

    public static function plugin_version($plugin_path) {
        if (self::is_test_mode()) {
            return isset(self::$test_plugin_versions[$plugin_path]) ? (string) self::$test_plugin_versions[$plugin_path] : '';
        }
        if (!function_exists('get_plugin_data')) {
            $file = defined('WP_PLUGIN_DIR') ? trailingslashit(WP_PLUGIN_DIR) . $plugin_path : '';
            if ($file && is_file($file) && defined('ABSPATH')) {
                $plugin_include = ABSPATH . 'wp-admin/includes/plugin.php';
                if (is_file($plugin_include)) { require_once $plugin_include; }
            }
        }
        if (!function_exists('get_plugin_data') || !defined('WP_PLUGIN_DIR')) { return ''; }
        $file = trailingslashit(WP_PLUGIN_DIR) . $plugin_path;
        if (!is_file($file)) { return ''; }
        $data = get_plugin_data($file, false, false);
        return isset($data['Version']) ? (string) $data['Version'] : '';
    }

    public static function current_user_can_manage() {
        if (self::is_test_mode()) { return self::$test_can_manage; }
        return function_exists('current_user_can') && current_user_can('manage_options');
    }

    public static function current_user_id() {
        if (self::is_test_mode()) { return 1; }
        return function_exists('get_current_user_id') ? (int) get_current_user_id() : 0;
    }



    public static function set_test_plugin_version($plugin_path, $version) {
        if (self::is_test_mode()) { self::$test_plugin_versions[(string)$plugin_path] = (string)$version; }
    }

    public static function set_test_can_manage($value) {
        if (self::is_test_mode()) { self::$test_can_manage = (bool) $value; }
    }

    public static function verify_nonce($nonce, $action) {
        if (self::is_test_mode()) { return $nonce === 'test-nonce'; }
        return function_exists('wp_verify_nonce') && wp_verify_nonce($nonce, $action);
    }

    public static function sanitize_title($title) {
        if (function_exists('sanitize_title')) { return sanitize_title($title); }
        $title = strtolower((string) $title);
        $title = preg_replace('/[^a-z0-9äöüß]+/u', '-', $title);
        return trim((string) $title, '-');
    }

    public static function kses_post($html) {
        return function_exists('wp_kses_post') ? wp_kses_post($html) : (string) $html;
    }

    public static function insert_draft($title, $content, $slug, $meta = array(), $categories = array(), $write_authorization = null) {
        $payload=array('title'=>(string)$title,'content'=>(string)$content,'slug'=>(string)$slug,'meta'=>(array)$meta,'categories'=>(array)$categories);
        $qf03_ok=class_exists('PPM679_WP_Draft_Adapter') && PPM679_WP_Draft_Adapter::verify_write_authorization($write_authorization,$payload,true);
        $three_type_ok=class_exists('PPM679_Three_Type_Live_Test_Draft_Adapter') && PPM679_Three_Type_Live_Test_Draft_Adapter::verify_write_authorization($write_authorization,$payload,true);
        $normal_ok=class_exists('PPM679_Normal_Draft_Adapter') && PPM679_Normal_Draft_Adapter::verify_write_authorization($write_authorization,$payload,true);
        if (!$qf03_ok && !$three_type_ok && !$normal_ok) {
            self::$last_write_block=array('status'=>'BLOCKED_QF03_WRITE_AUTHORIZATION_REQUIRED','reason'=>'wp_insert_post requires one-use payload-bound authorization from an explicitly supported draft adapter','payload_hash'=>class_exists('PPM679_Diagnostic')?PPM679_Diagnostic::stable_hash($payload):hash('sha256',json_encode($payload)));
            return 0;
        }
        self::$last_write_block=null;
        if (self::is_test_mode()) {
            $id = ++self::$test_post_seq;
            self::$test_posts[$id] = array(
                'ID' => $id,
                'post_title' => (string) $title,
                'post_content' => (string) $content,
                'post_name' => (string) $slug,
                'post_status' => 'draft',
                'post_type' => 'post',
                'meta' => (array) $meta,
                'category_ids' => array_values(array_filter(array_map('intval',(array)$categories),function($id){ return $id>0; })),
            );
            return $id;
        }
        if (!function_exists('wp_insert_post')) { return 0; }
        $post_id = wp_insert_post(array(
            'post_title' => (string) $title,
            'post_content' => self::kses_post($content),
            'post_name' => (string) $slug,
            'post_status' => 'draft',
            'post_type' => 'post',
            'meta_input' => (array) $meta,
            'post_category' => array_values(array_filter(array_map('intval',(array)$categories),function($id){ return $id>0; })),
        ), true);
        if (is_wp_error($post_id)) { return $post_id; }
        return (int) $post_id;
    }

    public static function get_post_snapshot($post_id) {
        if (self::is_test_mode()) {
            return isset(self::$test_posts[$post_id]) ? self::$test_posts[$post_id] : null;
        }
        if (!function_exists('get_post')) { return null; }
        $post = get_post((int) $post_id, ARRAY_A);
        if (!is_array($post)) { return null; }
        $post['meta'] = function_exists('get_post_meta') ? (array) get_post_meta((int)$post_id) : array();
        $post['category_ids'] = function_exists('wp_get_post_categories') ? array_values(array_map('intval',(array)wp_get_post_categories((int)$post_id))) : array();
        return $post;
    }

    public static function find_posts_by_meta_marker($marker, $meta_key = '_ppm679_test_marker') {
        $posts=self::find_posts_by_meta_value((string)$meta_key,(string)$marker);
        $ids=array();
        foreach($posts as $post){$id=(int)($post['ID']??0);if($id>0){$ids[]=$id;}}
        return $ids;
    }


    public static function scalar_meta($meta, $key) {
        $value=is_array($meta)&&array_key_exists($key,$meta)?$meta[$key]:null;
        if (is_array($value)) { $value=reset($value); }
        return $value;
    }

    public static function seed_test_post($snapshot) {
        if (!self::is_test_mode() || !is_array($snapshot)) { return false; }
        $id=(int)($snapshot['ID']??0);
        if ($id<=0) { $id=++self::$test_post_seq; }
        $snapshot['ID']=$id;
        $snapshot['post_title']=(string)($snapshot['post_title']??'');
        $snapshot['post_content']=(string)($snapshot['post_content']??'');
        $snapshot['post_name']=(string)($snapshot['post_name']??'');
        $snapshot['post_status']=(string)($snapshot['post_status']??'draft');
        $snapshot['post_type']=(string)($snapshot['post_type']??'post');
        $snapshot['meta']=is_array($snapshot['meta']??null)?$snapshot['meta']:array();
        $snapshot['category_ids']=array_values(array_map('intval',(array)($snapshot['category_ids']??array())));
        self::$test_posts[$id]=$snapshot;
        if ($id>self::$test_post_seq) { self::$test_post_seq=$id; }
        return $id;
    }

    public static function find_posts_by_meta_value($meta_key, $value) {
        $meta_key=(string)$meta_key; $value=(string)$value;
        if ($meta_key==='' || $value==='') { return array(); }
        if (self::is_test_mode()) {
            $out=array();
            foreach(self::$test_posts as $post) {
                if ((string)self::scalar_meta($post['meta']??array(),$meta_key)===$value) { $out[]=$post; }
            }
            return $out;
        }
        if (!class_exists('WP_Query')) { return array(); }
        $query=new WP_Query(array(
            'post_type'=>'any',
            'post_status'=>array('draft','publish','private','trash','pending','future'),
            'posts_per_page'=>-1,
            'meta_key'=>$meta_key,
            'meta_value'=>$value,
            'no_found_rows'=>true,
        ));
        $out=array();
        foreach((array)$query->posts as $post) {
            $id=is_object($post)?(int)$post->ID:(int)$post;
            $snapshot=self::get_post_snapshot($id);
            if (is_array($snapshot)) { $out[]=$snapshot; }
        }
        return $out;
    }

    public static function find_posts_by_slug($slug) {
        $slug=trim((string)$slug);
        if ($slug==='') { return array(); }
        if (self::is_test_mode()) {
            $out=array();
            foreach(self::$test_posts as $post) {
                if ((string)($post['post_name']??'')===$slug) { $out[]=$post; }
            }
            return $out;
        }
        if (!class_exists('WP_Query')) { return array(); }
        $query=new WP_Query(array(
            'name'=>$slug,
            'post_type'=>'any',
            'post_status'=>array('draft','publish','private','trash','pending','future'),
            'posts_per_page'=>-1,
            'no_found_rows'=>true,
        ));
        $out=array();
        foreach((array)$query->posts as $post) {
            $id=is_object($post)?(int)$post->ID:(int)$post;
            $snapshot=self::get_post_snapshot($id);
            if (is_array($snapshot)) { $out[]=$snapshot; }
        }
        return $out;
    }

    public static function seed_test_term($term) {
        if(!self::is_test_mode()||!is_array($term)){return false;}
        $id=(int)($term['term_id']??0);if($id<=0){return false;}
        $parents=array_values((array)($term['parent_chain_slugs']??array()));$parent_names=array_values((array)($term['parent_chain_names']??array()));
        $depth=(int)($term['taxonomy_depth']??$term['level']??(count($parents)+1));
        self::$test_terms[$id]=array(
            'term_id'=>$id,'name'=>(string)($term['name']??''),'slug'=>(string)($term['slug']??''),
            'taxonomy'=>(string)($term['taxonomy']??'category'),'parent'=>(int)($term['parent']??0),
            'parent_chain_slugs'=>$parents,'parent_chain_names'=>$parent_names,'taxonomy_depth'=>$depth,
            'hierarchy_path'=>(string)($term['hierarchy_path']??implode(' > ',array_merge($parent_names,array((string)($term['name']??''))))),
            'level'=>$depth,'fixture_class'=>(string)($term['fixture_class']??'SYNTHETIC_GENERAL_MODEL')
        );return $id;
    }
    private static function seed_default_test_terms(){
        $file=PPM679_PLUGIN_DIR.'contracts/wordpress-taxonomy-snapshot-v1.json';$d=is_file($file)?json_decode((string)file_get_contents($file),true):null;
        if(is_array($d)&&($d['fixture_class']??'')==='REAL_SNAPSHOT_DERIVED'){foreach((array)($d['terms']??array()) as $t){$t['fixture_class']='REAL_SNAPSHOT_DERIVED';self::seed_test_term($t);}return;}
    }
    public static function find_category_terms_by_slug($slug,$taxonomy='category') {
        $slug=trim((string)$slug);$taxonomy=trim((string)$taxonomy);$matches=array();if($slug===''||$taxonomy===''){return $matches;}
        if(self::is_test_mode()){foreach(self::$test_terms as $term){if((string)($term['slug']??'')===$slug&&(string)($term['taxonomy']??'')===$taxonomy){$matches[]=$term;}}return $matches;}
        if(!function_exists('get_terms')){return array();}$terms=get_terms(array('taxonomy'=>$taxonomy,'hide_empty'=>false,'slug'=>$slug));if(is_wp_error($terms)){return array();}foreach((array)$terms as $term){$snap=self::category_term_snapshot((int)$term->term_id,$taxonomy);if(is_array($snap)){$matches[]=$snap;}}return $matches;
    }

    public static function category_term_snapshot($term_id,$taxonomy='category'){
        $term_id=(int)$term_id;$taxonomy=(string)$taxonomy;
        if(self::is_test_mode()){return isset(self::$test_terms[$term_id])&&self::$test_terms[$term_id]['taxonomy']===$taxonomy?self::$test_terms[$term_id]:null;}
        if(!function_exists('get_term')){return null;}$term=get_term($term_id,$taxonomy);if(!$term||is_wp_error($term)){return null;}
        $parent_slugs=array();$parent_names=array();$parent=(int)$term->parent;$guard=0;
        while($parent>0&&$guard++<32){$p=get_term($parent,$taxonomy);if(!$p||is_wp_error($p)){return null;}array_unshift($parent_slugs,(string)$p->slug);array_unshift($parent_names,(string)$p->name);$parent=(int)$p->parent;}
        $depth=count($parent_slugs)+1;
        return array('term_id'=>(int)$term->term_id,'name'=>(string)$term->name,'slug'=>(string)$term->slug,'taxonomy'=>$taxonomy,'parent'=>(int)$term->parent,'parent_chain_slugs'=>$parent_slugs,'parent_chain_names'=>$parent_names,'taxonomy_depth'=>$depth,'hierarchy_path'=>implode(' > ',array_merge($parent_names,array((string)$term->name))),'level'=>$depth,'fixture_class'=>'REAL_SNAPSHOT_DERIVED');
    }
    public static function resolve_category_binding($binding){
        $binding=is_array($binding)?$binding:array();$slug=(string)($binding['slug']??'');$taxonomy=(string)($binding['taxonomy']??'category');$matches=array();
        if(self::is_test_mode()){foreach(self::$test_terms as $t){if($t['slug']===$slug&&$t['taxonomy']===$taxonomy){$matches[]=$t;}}}
        elseif(function_exists('get_terms')){$terms=get_terms(array('taxonomy'=>$taxonomy,'hide_empty'=>false,'slug'=>$slug));if(!is_wp_error($terms)){foreach((array)$terms as $term){$snap=self::category_term_snapshot((int)$term->term_id,$taxonomy);if(is_array($snap)){$matches[]=$snap;}}}}
        if(count($matches)!==1){$code=count($matches)>1?'BLOCKED_CATEGORY_LIVE_RESOLUTION_AMBIGUOUS':'BLOCKED_CATEGORY_LIVE_RESOLUTION_MISSING';$e=PPM679_Diagnostic::error($code,'CATEGORY_BINDING_MUST_RESOLVE_TO_EXACTLY_ONE_LIVE_TERM','category_resolution.matches',1,count($matches),'Die semantisch gebundene Kategorie kann nicht eindeutig live aufgelöst werden.','category_live_resolution','',__CLASS__,null,array('contracts/category-hierarchy-snapshot-v1.json','contracts/wordpress-taxonomy-contract-v1.json'));return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($code,array($e),'category_live_resolution'));}
        $term=$matches[0];$errors=PPM679_Portal_WP_Structure_Validator::validate_live_term($term,$binding);
        if(in_array((string)($term['slug']??''),array('uncategorized','allgemein'),true)){$errors[]=PPM679_Diagnostic::error('BLOCKED_CATEGORY_FALLBACK_USED','DEFAULT_OR_FALLBACK_CATEGORY_IS_FORBIDDEN','category_resolution.slug','non-fallback',$term['slug']??null,'Eine Standard- oder Fallback-Kategorie ist unzulässig.','category_live_resolution','',__CLASS__);}
        if($errors){return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'category_live_resolution'));}
        return array('ok'=>true,'term'=>$term,'runtime_taxonomy_snapshot'=>PPM679_Portal_WP_Structure_Validator::runtime_snapshot($term));
    }

    public static function get_page_snapshot($post_id) {
        $snapshot=self::get_post_snapshot((int)$post_id);
        if(self::is_test_mode()&&!is_array($snapshot)&&(int)$post_id===9886){$snapshot=array('ID'=>9886,'post_title'=>'Pferde Journal','post_name'=>'journal','post_status'=>'publish','post_type'=>'page','route'=>'/journal/','meta'=>array(),'category_ids'=>array());}
        if(!is_array($snapshot)){return null;}
        if(self::is_test_mode()){
            $snapshot['route']=(string)($snapshot['route']??('/'.trim((string)($snapshot['post_name']??''),'/').'/'));
            return $snapshot;
        }
        $url=function_exists('get_permalink')?get_permalink((int)$post_id):'';
        $path=is_string($url)?(string)parse_url($url,PHP_URL_PATH):'';
        $snapshot['route']=$path!==''?rtrim($path,'/').'/':'';
        return $snapshot;
    }

    public static function get_all_post_inventory($statuses=array('publish','draft','trash')) {
        $statuses=array_values(array_map('strval',(array)$statuses));
        $out=array();
        if(self::is_test_mode()){
            foreach(self::$test_posts as $post){
                if((string)($post['post_type']??'post')!=='post'||!in_array((string)($post['post_status']??''),$statuses,true)){continue;}
                $category_ids=array_values(array_map('intval',(array)($post['category_ids']??array())));
                $category_name='';$category_slug='';
                if($category_ids){$term=self::category_term_snapshot($category_ids[0],'category');if(is_array($term)){$category_name=(string)$term['name'];$category_slug=(string)$term['slug'];}}
                $out[]=array('post_id'=>(int)$post['ID'],'title'=>(string)($post['post_title']??''),'status'=>(string)($post['post_status']??''),'category_ids'=>$category_ids,'category_name'=>$category_name,'category_slug'=>$category_slug,'meta'=>(array)($post['meta']??array()),'canonical_article_id'=>(string)self::scalar_meta((array)($post['meta']??array()),'_ppm679_canonical_article_id'),'test_marker'=>(string)self::scalar_meta((array)($post['meta']??array()),'_ppm679_test_marker'));
            }
            return $out;
        }
        if(!class_exists('WP_Query')){return array();}
        $query=new WP_Query(array('post_type'=>'post','post_status'=>$statuses,'posts_per_page'=>-1,'orderby'=>'ID','order'=>'ASC','no_found_rows'=>true));
        foreach((array)$query->posts as $post){
            $id=is_object($post)?(int)$post->ID:(int)$post;$snap=self::get_post_snapshot($id);if(!is_array($snap)){continue;}
            $category_ids=array_values(array_map('intval',(array)($snap['category_ids']??array())));$category_name='';$category_slug='';
            if($category_ids){$term=self::category_term_snapshot($category_ids[0],'category');if(is_array($term)){$category_name=(string)$term['name'];$category_slug=(string)$term['slug'];}}
            $meta=(array)($snap['meta']??array());
            $out[]=array('post_id'=>$id,'title'=>(string)($snap['post_title']??''),'status'=>(string)($snap['post_status']??''),'category_ids'=>$category_ids,'category_name'=>$category_name,'category_slug'=>$category_slug,'meta'=>$meta,'canonical_article_id'=>(string)self::scalar_meta($meta,'_ppm679_canonical_article_id'),'test_marker'=>(string)self::scalar_meta($meta,'_ppm679_test_marker'));
        }
        return $out;
    }

    public static function delete_post($post_id) {
        if (self::is_test_mode()) {
            unset(self::$test_posts[$post_id]);
            return true;
        }
        return function_exists('wp_delete_post') ? (bool) wp_delete_post((int) $post_id, true) : false;
    }

    public static function reset_test_state() {
        if (!self::is_test_mode()) { return; }
        self::$test_options = array();
        self::$test_posts = array();
        self::$test_post_seq = 10000;
        self::$test_terms = array();
        self::$test_can_manage = true;
        self::$last_write_block = null;
        self::seed_default_test_terms();
        $journal_file=PPM679_PLUGIN_DIR.'contracts/journal-content-block-v1.json';
        $journal=is_file($journal_file)?json_decode((string)file_get_contents($journal_file),true):null;
        if(is_array($journal)){$journal_test_id=51000;foreach((array)($journal['categories']??array()) as $term){$test_id=(int)($term['wp_term_id']??0);if($test_id<=0){$test_id=$journal_test_id++;}$runtime_name=(string)($term['runtime_name']??($term['name']??''));$runtime_slug=(string)($term['runtime_slug']??($term['slug']??''));self::seed_test_term(array('term_id'=>$test_id,'name'=>$runtime_name,'slug'=>$runtime_slug,'taxonomy'=>'category','parent'=>0,'parent_chain_slugs'=>array(),'parent_chain_names'=>array(),'taxonomy_depth'=>1,'hierarchy_path'=>$runtime_name,'fixture_class'=>'TEST_ONLY_RUNTIME_ID_FOR_READ_ONLY_SLUG_RESOLUTION'));}}
        if (class_exists('PPM679_Category_Assignment_Validator')) { PPM679_Category_Assignment_Validator::reset_test_state(); }
        if (class_exists('PPM679_WP_Draft_Adapter')) { PPM679_WP_Draft_Adapter::reset_test_state(); }
        if (class_exists('PPM679_Stateful_Write_Gate')) { PPM679_Stateful_Write_Gate::reset_test_state(); }
        if (class_exists('PPM679_Three_Type_Live_Test_Draft_Adapter')) { PPM679_Three_Type_Live_Test_Draft_Adapter::reset_test_state(); }
        if (class_exists('PPM679_Three_Type_Live_Test_Write_Gate')) { PPM679_Three_Type_Live_Test_Write_Gate::reset_test_state(); }
        if (class_exists('PPM679_Normal_Draft_Adapter')) { PPM679_Normal_Draft_Adapter::reset_test_state(); }
        self::$test_plugin_versions = array(
            'portal-production-machine/portal-production-machine.php' => '6.7.9',
            'canonical-table-contract-v1/canonical-table-contract-v1.php' => '1.1.0'
        );
        self::$test_active_plugins = array(
            'portal-production-machine/portal-production-machine.php',
            'canonical-table-contract-v1/canonical-table-contract-v1.php'
        );
    }

    public static function test_posts() {
        return self::$test_posts;
    }

    public static function last_write_block() { return self::$last_write_block; }
}
