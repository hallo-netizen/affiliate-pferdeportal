<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Admin {
    const ACTION='ppm679_run_v4';
    const NONCE_ACTION='ppm679_run_v4_nonce';
    const NORMAL_ACTION='ppm679_run_normal_draft';
    const NORMAL_NONCE_ACTION='ppm679_run_normal_draft_nonce';
    const HEALTH_NONCE_ACTION='ppm679_health_check_nonce';
    const HEALTH_POST_FIELD='ppm679_health_check';
    const SLUG='portal-production-machine-679';

    public static function init() {
        if (function_exists('add_action')) {
            add_action('admin_menu',array(__CLASS__,'menu'));
            add_action('admin_post_'.self::ACTION,array(__CLASS__,'handle_run'));
            add_action('admin_post_'.self::NORMAL_ACTION,array(__CLASS__,'handle_normal_run'));
            add_action('rest_api_init',array(__CLASS__,'rest'));
        }
    }

    public static function menu() {
        if (!function_exists('add_menu_page')) { return; }
        add_menu_page(
            'Produktionsmaschine 6.7.9',
            'Produktionsmaschine',
            'manage_options',
            self::SLUG,
            array(__CLASS__,'page'),
            'dashicons-admin-tools',
            80
        );
    }

    public static function page() {
        if (!PPM679_WP::current_user_can_manage()) { return; }
        $is_health_request=isset($_POST[self::HEALTH_POST_FIELD]);
        $health_result=$is_health_request?self::handle_health_check():null;
        $last=PPM679_WP::get_option('ppm679_last_error',null);
        echo '<div class="wrap"><h1>Portal Production Machine 6.7.9</h1>';
        echo '<p>Ein zusammenhängender Vier-Typ-Test: Planprüfung, Bootstrap, CHECK_ONLY, Entwürfe und Readback. Veröffentlichung ist nicht registriert.</p>';
        if (is_array($last)) {
            echo '<div class="notice notice-error"><p><strong>'.self::h((string)($last['status']??'BLOCKED')).'</strong></p>';
            if (!empty($last['errors'][0]['reason'])) { echo '<p>'.self::h((string)$last['errors'][0]['reason']).'</p>'; }
            echo '</div>';
            if (!$is_health_request) { PPM679_WP::delete_option('ppm679_last_error'); }
        }
        if (is_array($health_result)) {
            $health_status=(string)($health_result['status']??'BLOCKED_HEALTH_CHECK_RESULT_INVALID');
            $health_class=strpos($health_status,'BLOCKED_')===0?'notice notice-error':'notice notice-success';
            $health_json=function_exists('wp_json_encode')
                ?wp_json_encode($health_result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)
                :json_encode($health_result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
            echo '<div class="'.self::h($health_class).'"><p><strong>Schreibfreier Health-Check</strong></p>';
            echo '<pre style="white-space:pre-wrap">'.self::h((string)$health_json).'</pre></div>';
        }
        $action=function_exists('admin_url')?admin_url('admin-post.php'):'admin-post.php';
        echo '<form method="post" enctype="multipart/form-data" action="'.self::h($action).'">';
        echo '<input type="hidden" name="action" value="'.self::ACTION.'">';
        if (function_exists('wp_nonce_field')) { wp_nonce_field(self::NONCE_ACTION); }
        echo '<p><label for="ppm679_fact_packs"><strong>Kanonisches Fact-Pack-Bundle</strong></label><br>';
        echo '<input type="file" id="ppm679_fact_packs" name="ppm679_fact_packs" accept="application/json,.json" required></p>';
        echo '<p><label for="ppm679_plan"><strong>Produktionsplan V4 mit Cross-Domain-Bindung</strong></label><br>';
        echo '<input type="file" id="ppm679_plan" name="ppm679_plan" accept="application/json,.json" required></p>';
        if (function_exists('submit_button')) { submit_button('Vier-Typ-Test bis Draft-Readback ausführen'); }
        else { echo '<button type="submit">Vier-Typ-Test bis Draft-Readback ausführen</button>'; }
        echo '</form>';
        echo '<hr><h2>Normaler Produktionslauf für 1 bis 4 Entwürfe</h2>';
        echo '<p>Nur für vollständig recherchierte und kanonisch gebundene Artikelpakete. Wissen und Veröffentlichung bleiben gesperrt.</p>';
        echo '<form method="post" enctype="multipart/form-data" action="'.self::h($action).'">';
        echo '<input type="hidden" name="action" value="'.self::NORMAL_ACTION.'">';
        if (function_exists('wp_nonce_field')) { wp_nonce_field(self::NORMAL_NONCE_ACTION); }
        echo '<p><label for="ppm679_normal_fact_packs"><strong>Kanonisches Fact-Pack-Bundle für 1 bis 4 Artikel</strong></label><br>';
        echo '<input type="file" id="ppm679_normal_fact_packs" name="ppm679_fact_packs" accept="application/json,.json" required></p>';
        echo '<p><label for="ppm679_normal_plan"><strong>Produktionsplan V4 für 1 bis 4 Artikel</strong></label><br>';
        echo '<input type="file" id="ppm679_normal_plan" name="ppm679_plan" accept="application/json,.json" required></p>';
        if (function_exists('submit_button')) { submit_button('Normalen Draft-Lauf bis Readback ausführen'); }
        else { echo '<button type="submit">Normalen Draft-Lauf bis Readback ausführen</button>'; }
        echo '</form>';
        $health_action=function_exists('admin_url')?admin_url('admin.php?page='.self::SLUG):'admin.php?page='.self::SLUG;
        echo '<hr><h2>Schreibfreier Health-Check</h2>';
        echo '<p>Prüft ausschließlich den bestehenden Serverzustand. Es werden keine Dateien benötigt und keine Artikel oder Entwürfe erzeugt.</p>';
        echo '<form method="post" action="'.self::h($health_action).'">';
        if (function_exists('wp_nonce_field')) { wp_nonce_field(self::HEALTH_NONCE_ACTION); }
        echo '<button type="submit" class="button button-secondary" name="'.self::HEALTH_POST_FIELD.'" value="1">Schreibfreien Health-Check ausführen</button>';
        echo '</form><p><strong>Kein Publish:</strong> Das Plugin registriert keinen Veröffentlichungsweg.</p></div>';
    }

    public static function handle_health_check() {
        if (!PPM679_WP::current_user_can_manage()) {
            return self::health_blocker(
                'BLOCKED_HEALTH_CHECK_CAPABILITY',
                'CURRENT_USER_MUST_HAVE_MANAGE_OPTIONS'
            );
        }
        $nonce=isset($_POST['_wpnonce'])?(string)$_POST['_wpnonce']:'';
        if (!PPM679_WP::verify_nonce($nonce,self::HEALTH_NONCE_ACTION)) {
            return self::health_blocker(
                'BLOCKED_HEALTH_CHECK_NONCE',
                $nonce===''?'HEALTH_CHECK_NONCE_MISSING':'HEALTH_CHECK_NONCE_INVALID'
            );
        }
        $server_instance_id=trim((string)PPM679_WP::get_option('ppm_server_instance_id',''));
        if ($server_instance_id==='') {
            return self::health_blocker(
                'BLOCKED_HEALTH_STATE_NOT_INITIALIZED',
                'SERVER_INSTANCE_ID_MUST_ALREADY_EXIST_FOR_STRICT_READ_ONLY_CHECK'
            );
        }
        $health=self::health();
        if (is_object($health) && method_exists($health,'get_data')) {
            $health=$health->get_data();
        }
        if (!is_array($health)) {
            return self::health_blocker(
                'BLOCKED_HEALTH_CHECK_RESULT_INVALID',
                'EXISTING_HEALTH_METHOD_MUST_RETURN_ARRAY_DATA'
            );
        }
        return $health;
    }

    private static function health_blocker($status,$reason) {
        return array(
            'contract'=>'ppm_health_button_result_v1',
            'version'=>defined('PPM679_VERSION')?PPM679_VERSION:'6.7.9',
            'build_id'=>defined('PPM679_BUILD_ID')?PPM679_BUILD_ID:'UNKNOWN_BUILD',
            'status'=>(string)$status,
            'reason'=>(string)$reason,
            'publish_allowed'=>false,
            'rest_write_route_registered'=>false
        );
    }

    public static function handle_run() {
        try {
            if (!PPM679_WP::current_user_can_manage()) {
                return self::store_and_redirect(self::simple_blocker(
                    'BLOCKED_ADMIN_CAPABILITY',
                    'CURRENT_USER_MUST_HAVE_MANAGE_OPTIONS',
                    'request.current_user',
                    'manage_options',
                    false,
                    'Nur Administratoren dürfen den Vier-Typ-Test starten.',
                    'admin_authorization'
                ));
            }
            $nonce=isset($_POST['_wpnonce'])?(string)$_POST['_wpnonce']:'';
            if (!PPM679_WP::verify_nonce($nonce,self::NONCE_ACTION)) {
                return self::store_and_redirect(self::simple_blocker(
                    'BLOCKED_ADMIN_NONCE',
                    'ADMIN_ACTION_NONCE_MUST_VERIFY',
                    'request._wpnonce',
                    'valid nonce',
                    $nonce===''?'missing':'invalid',
                    'Die Testanforderung besitzt keine gültige Request-Bindung.',
                    'admin_authorization'
                ));
            }
            $bundle_file=isset($_FILES['ppm679_fact_packs'])&&is_array($_FILES['ppm679_fact_packs'])?$_FILES['ppm679_fact_packs']:array();
            $bundle=self::decode_uploaded_json($bundle_file,'ppm679_fact_packs','BLOCKED_FACT_PACK_BUNDLE_UPLOAD_INVALID');
            if (!is_array($bundle)) { return null; }
            $import=self::import_fact_pack_bundle($bundle);
            if (empty($import['ok'])) { return self::emit_pipeline_result(array('artifact'=>$import['artifact'],'gate'=>$import['gate'],'filename'=>'ppm-fact-pack-import-blocked.json')); }

            $file=isset($_FILES['ppm679_plan'])&&is_array($_FILES['ppm679_plan'])?$_FILES['ppm679_plan']:array();
            $tmp=isset($file['tmp_name'])?(string)$file['tmp_name']:'';
            $size=isset($file['size'])?(int)$file['size']:0;
            if ($tmp==='' || !is_file($tmp) || $size<=0 || $size>2097152) {
                return self::emit_pipeline_result(self::blocked_for_input(
                    'BLOCKED_PLAN_UPLOAD_INVALID',
                    'PLAN_UPLOAD_MUST_BE_PRESENT_JSON_FILE_WITHIN_SIZE_LIMIT',
                    'request.files.ppm679_plan',
                    'existing JSON file between 1 byte and 2 MiB',
                    array('tmp_exists'=>$tmp!==''&&is_file($tmp),'size'=>$size),
                    'Die hochgeladene Plan-Datei fehlt, ist leer oder überschreitet die Größenbegrenzung.'
                ));
            }
            $bytes=(string)file_get_contents($tmp);
            $plan=json_decode($bytes,true);
            if (!is_array($plan)) {
                return self::emit_pipeline_result(self::blocked_for_input(
                    'BLOCKED_PLAN_JSON_INVALID',
                    'PLAN_UPLOAD_MUST_DECODE_TO_JSON_OBJECT',
                    'request.files.ppm679_plan',
                    'valid JSON object',
                    json_last_error_msg(),
                    'Die hochgeladene Datei ist kein gültiger Produktionsplan.'
                ));
            }
            return self::emit_pipeline_result(PPM679_Pipeline::execute_plan($plan));
        } catch (Throwable $e) {
            $artifact=self::simple_blocker(
                'BLOCKED_ADMIN_RUNTIME_EXCEPTION',
                'ADMIN_PIPELINE_REQUEST_MUST_NOT_CRASH_WORDPRESS',
                'admin.runtime',
                'no uncaught exception',
                get_class($e).': '.$e->getMessage(),
                'Die interne Ausnahme wurde abgefangen. WordPress bleibt erreichbar; es wurde nichts veröffentlicht.',
                'admin_runtime'
            );
            $schema=PPM679_Storage::ensure_schema();
            $hash=PPM679_Diagnostic::stable_hash($artifact);
            $gate=PPM679_Live_State_Gate::verify_live_state_or_abort('admin_runtime_exception',$hash);
            return self::emit_pipeline_result(array('artifact'=>$artifact,'gate'=>$gate,'filename'=>'ppm-four-type-blocked.json'));
        }
    }


    public static function handle_normal_run() {
        try {
            if (!PPM679_WP::current_user_can_manage()) {
                return self::store_and_redirect(self::simple_blocker('BLOCKED_ADMIN_CAPABILITY','CURRENT_USER_MUST_HAVE_MANAGE_OPTIONS','request.current_user','manage_options',false,'Nur Administratoren dürfen den normalen Draft-Lauf starten.','normal_admin_authorization'));
            }
            $nonce=isset($_POST['_wpnonce'])?(string)$_POST['_wpnonce']:'';
            if (!PPM679_WP::verify_nonce($nonce,self::NORMAL_NONCE_ACTION)) {
                return self::store_and_redirect(self::simple_blocker('BLOCKED_ADMIN_NONCE','ADMIN_ACTION_NONCE_MUST_VERIFY','request._wpnonce','valid nonce',$nonce===''?'missing':'invalid','Die Produktionsanforderung besitzt keine gültige Request-Bindung.','normal_admin_authorization'));
            }
            $bundle_file=isset($_FILES['ppm679_fact_packs'])&&is_array($_FILES['ppm679_fact_packs'])?$_FILES['ppm679_fact_packs']:array();
            $bundle=self::decode_uploaded_json($bundle_file,'ppm679_fact_packs','BLOCKED_FACT_PACK_BUNDLE_UPLOAD_INVALID');
            if (!is_array($bundle)) { return null; }
            $import=self::import_fact_pack_bundle($bundle);
            if (empty($import['ok'])) { return self::emit_pipeline_result(array('artifact'=>$import['artifact'],'gate'=>$import['gate'],'filename'=>'ppm-normal-fact-pack-import-blocked.json'),'admin_normal_draft_production'); }
            $file=isset($_FILES['ppm679_plan'])&&is_array($_FILES['ppm679_plan'])?$_FILES['ppm679_plan']:array();
            $tmp=isset($file['tmp_name'])?(string)$file['tmp_name']:'';$size=isset($file['size'])?(int)$file['size']:0;
            if ($tmp==='' || !is_file($tmp) || $size<=0 || $size>2097152) {
                return self::emit_pipeline_result(self::blocked_for_input('BLOCKED_PLAN_UPLOAD_INVALID','PLAN_UPLOAD_MUST_BE_PRESENT_JSON_FILE_WITHIN_SIZE_LIMIT','request.files.ppm679_plan','existing JSON file between 1 byte and 2 MiB',array('tmp_exists'=>$tmp!==''&&is_file($tmp),'size'=>$size),'Die hochgeladene Plan-Datei fehlt, ist leer oder überschreitet die Größenbegrenzung.'),'admin_normal_draft_production');
            }
            $plan=json_decode((string)file_get_contents($tmp),true);
            if (!is_array($plan)) {
                return self::emit_pipeline_result(self::blocked_for_input('BLOCKED_PLAN_JSON_INVALID','PLAN_UPLOAD_MUST_DECODE_TO_JSON_OBJECT','request.files.ppm679_plan','valid JSON object',json_last_error_msg(),'Die hochgeladene Datei ist kein gültiger Produktionsplan.'),'admin_normal_draft_production');
            }
            $plan_hash=PPM679_Diagnostic::stable_hash($plan);$server_instance_id=PPM679_WP::server_instance_id();$user_id=PPM679_WP::current_user_id();
            $build_manifest_file=PPM679_PLUGIN_DIR.'certification/build-manifest-v1.json';$build_manifest_sha256=is_file($build_manifest_file)?hash_file('sha256',$build_manifest_file):'';
            $request_id='normal-request-'.substr(hash('sha256',$server_instance_id.'|'.$user_id.'|'.$nonce.'|'.$plan_hash.'|'.$build_manifest_sha256),0,40);
            $runtime_context=array('user_triggered'=>true,'nonce_verified'=>true,'user_id'=>$user_id,'server_instance_id'=>$server_instance_id,'request_id'=>$request_id,'build_manifest_sha256'=>$build_manifest_sha256,'evidence_class'=>'SERVER_USER_TRIGGERED_NORMAL_DRAFT_PRODUCTION','publish_allowed'=>false);
            return self::emit_pipeline_result(PPM679_Normal_Draft_Pipeline::execute_plan($plan,$runtime_context),'admin_normal_draft_production');
        } catch (Throwable $e) {
            $artifact=self::simple_blocker('BLOCKED_NORMAL_ADMIN_RUNTIME_EXCEPTION','NORMAL_ADMIN_PIPELINE_REQUEST_MUST_NOT_CRASH_WORDPRESS','normal_admin.runtime','no uncaught exception',get_class($e).': '.$e->getMessage(),'Die interne Ausnahme wurde abgefangen. WordPress bleibt erreichbar; es wurde nichts veröffentlicht.','normal_admin_runtime');
            $hash=PPM679_Diagnostic::stable_hash($artifact);$scope=null;$gate=PPM679_Live_State_Gate::verify_live_state_or_abort('normal_admin_runtime_exception',$hash,null,null,array('article_type_release_scope'=>$scope));
            return self::emit_pipeline_result(array('artifact'=>$artifact,'gate'=>$gate,'filename'=>'ppm-normal-draft-blocked.json'),'admin_normal_draft_production');
        }
    }


    public static function import_fact_pack_bundle($bundle) {
        if (!is_array($bundle) || (string)($bundle['contract']??'')!=='canonical_fact_pack_import_v1') {
            $blocked=self::blocked_for_input(
                'BLOCKED_FACT_PACK_BUNDLE_CONTRACT',
                'FACT_PACK_BUNDLE_MUST_USE_CANONICAL_IMPORT_CONTRACT',
                'fact_pack_bundle.contract',
                'canonical_fact_pack_import_v1',
                is_array($bundle)?($bundle['contract']??null):gettype($bundle),
                'Das hochgeladene Fact-Pack-Bundle verwendet nicht den kanonischen Importvertrag.'
            );
            return array('ok'=>false,'artifact'=>$blocked['artifact'],'gate'=>$blocked['gate']);
        }
        $packs=isset($bundle['fact_packs'])&&is_array($bundle['fact_packs'])?$bundle['fact_packs']:array();
        if (!$packs) {
            $blocked=self::blocked_for_input(
                'BLOCKED_FACT_PACK_BUNDLE_EMPTY',
                'FACT_PACK_BUNDLE_MUST_CONTAIN_AT_LEAST_ONE_PACK',
                'fact_pack_bundle.fact_packs',
                'non-empty list',
                count($packs),
                'Das kanonische Importbundle enthält keine Fact-Packs.'
            );
            return array('ok'=>false,'artifact'=>$blocked['artifact'],'gate'=>$blocked['gate']);
        }
        $imported=array();
        foreach ($packs as $index=>$pack) {
            $id=is_array($pack)?trim((string)($pack['fact_pack_id']??'')):'';
            if ($id==='' || !is_array($pack) || (string)($pack['status']??'')!=='SOURCE_VERIFIED_PRODUCTION_READY' || !isset($pack['claims']) || !is_array($pack['claims'])) {
                $blocked=self::blocked_for_input(
                    'BLOCKED_FACT_PACK_IMPORT_ITEM_INVALID',
                    'EVERY_IMPORTED_FACT_PACK_MUST_BE_CANONICAL_AND_PRODUCTION_READY',
                    'fact_pack_bundle.fact_packs['.$index.']',
                    'canonical source-verified fact pack',
                    $pack,
                    'Mindestens ein Fact-Pack ist unvollständig oder nicht produktionsbereit.'
                );
                return array('ok'=>false,'artifact'=>$blocked['artifact'],'gate'=>$blocked['gate']);
            }
            if (!PPM679_Storage::save_fact_pack($id,$pack)) {
                $blocked=self::blocked_for_input(
                    'BLOCKED_FACT_PACK_IMPORT_WRITE',
                    'CANONICAL_FACT_PACK_MUST_BE_IMMUTABLY_STORED',
                    'fact_pack_bundle.fact_packs['.$index.'].fact_pack_id',
                    'stored immutable fact pack',
                    $id,
                    'Das kanonische Fact-Pack konnte nicht unveränderlich in der Registry gespeichert werden.'
                );
                return array('ok'=>false,'artifact'=>$blocked['artifact'],'gate'=>$blocked['gate']);
            }
            $imported[]=$id;
        }
        return array('ok'=>true,'imported'=>$imported);
    }

    private static function decode_uploaded_json($file,$field,$code) {
        $tmp=isset($file['tmp_name'])?(string)$file['tmp_name']:'';
        $size=isset($file['size'])?(int)$file['size']:0;
        if ($tmp==='' || !is_file($tmp) || $size<=0 || $size>8388608) {
            self::emit_pipeline_result(self::blocked_for_input(
                $code,
                'UPLOADED_JSON_FILE_MUST_EXIST_WITHIN_SIZE_LIMIT',
                'request.files.'.$field,
                'existing JSON file between 1 byte and 8 MiB',
                array('tmp_exists'=>$tmp!==''&&is_file($tmp),'size'=>$size),
                'Die erforderliche JSON-Datei fehlt, ist leer oder überschreitet die Größenbegrenzung.'
            ));
            return null;
        }
        $decoded=json_decode((string)file_get_contents($tmp),true);
        if (!is_array($decoded)) {
            self::emit_pipeline_result(self::blocked_for_input(
                $code,
                'UPLOADED_JSON_MUST_DECODE_TO_OBJECT',
                'request.files.'.$field,
                'valid JSON object',
                json_last_error_msg(),
                'Die hochgeladene Datei ist kein gültiges JSON-Objekt.'
            ));
            return null;
        }
        return $decoded;
    }

    private static function blocked_for_input($code,$rule,$path,$expected,$actual,$reason) {
        $schema=PPM679_Storage::ensure_schema();
        $seed=array('code'=>$code,'path'=>$path,'actual'=>$actual);
        $hash=PPM679_Diagnostic::stable_hash($seed);
        $gate=PPM679_Live_State_Gate::verify_live_state_or_abort('plan_upload_input',$hash);
        $state_hash=isset($gate['state']['server_state_hash'])?$gate['state']['server_state_hash']:'';
        $error=PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'plan_upload_input',$state_hash,__CLASS__,null,array('includes/admin.php'));
        $artifact=PPM679_Diagnostic::blocked($code,array($error),'plan_upload_input',$state_hash);
        return array('artifact'=>$artifact,'gate'=>$gate,'filename'=>'ppm-four-type-blocked.json');
    }

    private static function simple_blocker($code,$rule,$path,$expected,$actual,$reason,$context) {
        $error=PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$context,'',__CLASS__,null,array('includes/admin.php'));
        return PPM679_Diagnostic::blocked($code,array($error),$context,'');
    }

    private static function emit_pipeline_result($result,$purpose='admin_four_type_test') {
        $artifact=is_array($result)&&isset($result['artifact'])?$result['artifact']:self::simple_blocker('BLOCKED_PIPELINE_RESULT_INVALID','PIPELINE_MUST_RETURN_ARTIFACT','pipeline.result','artifact',$result,'Die Pipeline lieferte kein gültiges Ergebnis.','pipeline_result');
        $gate=is_array($result)&&isset($result['gate'])?$result['gate']:array();
        $filename=is_array($result)&&isset($result['filename'])?$result['filename']:'ppm-four-type-result.json';
        $permit=PPM679_Handoff_Permit::issue($purpose,'json_report',$artifact,$gate);
        if ($permit===null) {
            PPM679_WP::update_option('ppm679_last_error',$artifact);
            return self::safe_redirect();
        }
        PPM679_Handoff_Writer::emit_json($permit,$artifact,$filename);
        return null;
    }

    private static function store_and_redirect($artifact) {
        PPM679_WP::update_option('ppm679_last_error',$artifact);
        return self::safe_redirect();
    }

    private static function safe_redirect() {
        if (!PPM679_WP::is_test_mode() && function_exists('wp_safe_redirect') && function_exists('admin_url')) {
            wp_safe_redirect(admin_url('admin.php?page='.self::SLUG));
            return;
        }
        return;
    }

    public static function rest() {
        if (!function_exists('register_rest_route')) { return; }
        register_rest_route('ppm/v679','/health',array(
            'methods'=>'GET',
            'callback'=>array(__CLASS__,'health'),
            'permission_callback'=>function(){ return PPM679_WP::current_user_can_manage(); }
        ));
    }

    public static function health() {
        $manifest_file=PPM679_PLUGIN_DIR.'certification/build-manifest-v1.json';
        $manifest_sha256=is_file($manifest_file)?hash_file('sha256',$manifest_file):'';
        $build_errors=PPM679_Build_Integrity::verify('health_read_only','');
        if ($build_errors) {
            $status=(string)($build_errors[0]['error_code']??'BLOCKED_BUILD_INTEGRITY');
            $data=array(
                'contract'=>'ppm_health_v1',
                'version'=>PPM679_VERSION,
                'build_id'=>defined('PPM679_BUILD_ID')?PPM679_BUILD_ID:'UNKNOWN_BUILD',
                'status'=>$status,
                'build_integrity'=>array(
                    'status'=>'BLOCKED',
                    'manifest_sha256'=>$manifest_sha256,
                    'error_count'=>count($build_errors),
                    'errors'=>$build_errors
                ),
                'publish_allowed'=>false,
                'production_action_registered'=>true,
                'rest_write_route_registered'=>false,
                'write_attempted'=>false
            );
            return function_exists('rest_ensure_response')?rest_ensure_response($data):$data;
        }
        $state=PPM679_Live_State_Gate::state('health_read');
        $journal=class_exists('PPM679_Journal_Content_Block_Validator')?PPM679_Journal_Content_Block_Validator::read_only_live_snapshot():array('ok'=>false,'status'=>'BLOCKED_JOURNAL_VALIDATOR_NOT_LOADED','write_attempted'=>false);
        $plan=class_exists('PPM679_Editorial_Plan_Registry')?PPM679_Editorial_Plan_Registry::summary():array('status'=>'BLOCKED_EDITORIAL_PLAN_REGISTRY_NOT_LOADED');
        $data=array(
            'contract'=>'ppm_health_v1',
            'version'=>PPM679_VERSION,
            'build_id'=>defined('PPM679_BUILD_ID')?PPM679_BUILD_ID:'UNKNOWN_BUILD',
            'status'=>'STRUCTURAL_CHECK_OK',
            'server_instance_id'=>$state['server_instance_id'],
            'schema_version'=>$state['schema_version'],
            'build_integrity'=>array(
                'status'=>'PASS',
                'manifest_sha256'=>$manifest_sha256,
                'error_count'=>0
            ),
            'companion_versions'=>array(
                'pste'=>defined('PSTE_VERSION')?(string)PSTE_VERSION:'NOT_LOADED',
                'pserc'=>defined('PSERC_VERSION')?(string)PSERC_VERSION:'NOT_LOADED'
            ),
            'editorial_plan'=>$plan,
            'journal_runtime'=>$journal,
            'publish_allowed'=>false,
            'production_action_registered'=>true,
            'rest_write_route_registered'=>false,
            'server_state_hash'=>$state['server_state_hash'],
            'write_attempted'=>false
        );
        return function_exists('rest_ensure_response')?rest_ensure_response($data):$data;
    }

    private static function h($value) {
        return htmlspecialchars((string)$value,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
    }
}
