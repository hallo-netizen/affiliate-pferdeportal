<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Production_Wave_Governor {
    public static function validate($candidates){
        $errors=array();$items=array_values((array)$candidates);if(count($items)>4){$errors[]=self::err('BLOCKED_INITIAL_WAVE_TOO_LARGE','INITIAL_REGULAR_PRODUCTION_WAVE_MAY_CREATE_AT_MOST_FOUR_DRAFTS','wave.item_count','<=4',count($items),'Die erste reguläre Produktionswelle ist zu groß.');}
        $counts=array();$allowed=array('faq','beratung','vergleich','pflege','journal');
        foreach($items as $i=>$c){$type=strtolower(trim((string)($c['article_type']??'')));$counts[$type]=($counts[$type]??0)+1;if(!in_array($type,$allowed,true)){$errors[]=self::err('BLOCKED_INITIAL_WAVE_ARTICLE_TYPE','NORMAL_DRAFT_WAVE_ACCEPTS_SIGNED_RELEASE_TYPES','wave.items['.$i.'].article_type',$allowed,$type,'Ein nicht freigegebener Beitragstyp wurde in die Startwelle aufgenommen.');}if($counts[$type]>1){$errors[]=self::err('BLOCKED_INITIAL_WAVE_TYPE_DUPLICATE','INITIAL_WAVE_MAY_CONTAIN_AT_MOST_ONE_DRAFT_PER_ARTICLE_TYPE','wave.article_types.'.$type,1,$counts[$type],'Die Startwelle enthält denselben Beitragstyp mehrfach.');}}
        return $errors;
    }
    private static function err($code,$rule,$path,$expected,$actual,$reason){return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'production_wave_governor','',__CLASS__,null,array(PPM679_Editorial_Plan_Registry::GOVERNANCE));}
}
