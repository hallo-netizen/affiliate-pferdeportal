<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

$contract=PPM679_Article_Type_Validator::load_contract();
ppm_test_assert(is_array($contract),'article type contract must load');
$types=array('FAQ','Beratung','Vergleich','Pflege');
$expectedRoles=array('further_information','parent_category','semantic_related');
$summary=array();
foreach ($types as $type) {
    $spec=$contract['types'][$type]??null;
    ppm_test_assert(is_array($spec),$type.' definition must exist');
    ppm_test_assert(($spec['production_allowed']??null)===false,$type.' must remain production-blocked in Wave-2 quarantine');
    ppm_test_assert((int)($contract['global']['visible_links_exact']??0)===3,$type.' must inherit exactly three visible internal links');
    $roles=$spec['required_link_roles']??array(); sort($roles,SORT_STRING);
    ppm_test_assert($roles===$expectedRoles,$type.' must use the three approved link roles');
    ppm_test_assert(!empty($spec['required_blocks']) && is_array($spec['required_blocks']),$type.' required blocks must exist');
    $summary[$type]=array(
        'production_allowed'=>$spec['production_allowed'],
        'visible_link_count'=>$contract['global']['visible_links_exact'],
        'required_link_roles'=>$roles,
        'required_blocks'=>$spec['required_blocks'],
    );
}
$errors=PPM679_Article_Type_Validator::validate('wave2_quarantine_type_safety','local-wave2-server-state');
$codes=array_map(static fn($e)=>(string)($e['error_code']??''),$errors);
ppm_test_assert(count(array_filter($codes,static fn($c)=>$c==='BLOCKED_ARTICLE_TYPE_NOT_PRODUCTION_ALLOWED'))===4,'all four types must deliberately block production until recertification');

$report=array(
    'contract'=>'wave2_article_type_quarantine_safety_report_v1',
    'status'=>'PASS',
    'contract_status'=>$contract['status']??null,
    'types'=>$summary,
    'validator_error_codes'=>$codes,
    'production_release_expected'=>'BLOCKED_PENDING_RECERTIFICATION',
    'publish_allowed'=>false,
);
echo json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
