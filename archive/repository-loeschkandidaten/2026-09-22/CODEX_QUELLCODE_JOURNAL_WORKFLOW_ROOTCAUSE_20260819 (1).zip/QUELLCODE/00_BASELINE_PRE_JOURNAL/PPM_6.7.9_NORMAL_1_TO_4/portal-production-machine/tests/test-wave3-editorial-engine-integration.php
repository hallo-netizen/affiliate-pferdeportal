<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';
require __DIR__.'/wave3-fixture-builder.php';

$fixture=ppm_wave3_positive_fixture();
$current=ppm_wave3_current_bindings($fixture);
$raw=tempnam(sys_get_temp_dir(),'ppm-wave3-engine-');
file_put_contents($raw,"independent fixture raw evidence inspected\n");
$local=ppm_wave3_evidence('WAVE3-ENGINE-LOCAL-001','LOCAL_EXECUTED_TEST',$current,$raw,false);
$model=ppm_wave3_evidence('WAVE3-ENGINE-INDEPENDENT-001','STATIC_CODE_INSPECTION',$current,$raw,true);
$statuses=array_fill_keys(PPM679_Status_Gate::STATUS_NAMES,'UNGEKLÄRT');
$statuses['EDITORIAL_REVIEW_STATUS']='PASS';
$statuses['GOLD_CORE_REVIEW_GATE']='PASS';
$input=array(
    'current_bindings'=>$current,
    'evidence_set'=>array($local,$model),
    'statuses'=>$statuses,
    'evidence_ids_by_status'=>array(
        'EDITORIAL_REVIEW_STATUS'=>array($local['evidence_id'],$model['evidence_id']),
        'GOLD_CORE_REVIEW_GATE'=>array($local['evidence_id'],$model['evidence_id']),
    ),
    'review'=>$fixture['review'],'document'=>$fixture['document'],'gold_reference'=>$fixture['gold_reference'],
    'prior_machine_statuses'=>array(
        'EDITORIAL_MACHINE_STATUS'=>'PASS','KNOWN_ERROR_GATE_V1'=>'PASS','GOLD_CORE_NUMERIC_GATE'=>'PASS'
    )
);
$result=PPM679_Editorial_Review_Engine::evaluate($input,'wave3_engine_positive','wave3-local-state');
if(empty($result['ok'])){fwrite(STDERR,json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");}
ppm_test_assert(!empty($result['ok']),'valid independent evidence plus matrix must pass Wave-3 engine fixture');
ppm_test_assert(($result['editorial_review_status']??'')==='PASS','editorial review status must pass only with independent evidence');
ppm_test_assert(empty($result['draft_create_allowed']),'Wave-3 engine must never authorize draft');
ppm_test_assert(empty($result['production_allowed']),'Wave-3 engine must remain quarantine-only');

$negative=$input;
$negative['evidence_set']=array($local);
$negative['evidence_ids_by_status']['EDITORIAL_REVIEW_STATUS']=array($local['evidence_id']);
$negative['evidence_ids_by_status']['GOLD_CORE_REVIEW_GATE']=array($local['evidence_id']);
$blocked=PPM679_Editorial_Review_Engine::evaluate($negative,'wave3_engine_machine_pass_not_inherited','wave3-local-state');
ppm_test_assert(empty($blocked['ok']),'prior machine PASS without independent review must be blocked');
ppm_test_assert(($blocked['editorial_review_status']??'')!=='PASS','machine PASS must not become editorial PASS');
$codes=array(); foreach((array)$blocked['errors'] as $e){$codes[]=$e['error_code']??'';}
ppm_test_assert(in_array('STATUS_INDEPENDENT_REVIEW_MISSING',$codes,true),'missing independent evidence must be explicit');

unlink($raw);
echo json_encode(array(
    'contract'=>'wave3_editorial_engine_integration_report_v1','status'=>'PASS',
    'positive_fixture'=>array('editorial_engine_status'=>$result['editorial_engine_status'],'editorial_review_status'=>$result['editorial_review_status'],'gold_core_review_gate'=>$result['gold_core_review_gate']),
    'machine_pass_without_independent_review'=>array('status'=>'BLOCKED','actual_editorial_review_status'=>$blocked['editorial_review_status'],'error_codes'=>array_values(array_unique($codes))),
    'draft_create_allowed'=>false,'production_allowed'=>false,
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
