<?php
require_once __DIR__.'/fixture-builder.php';
$c=json_decode(file_get_contents(dirname(__DIR__,2).'/contracts/system-inventory-v3-1.json'),true);
$allowed=$c['allowed_status_statement'];
foreach($c['forbidden_absolute_claims'] as $bad){ppm_test_assert(stripos($allowed,$bad)===false,'absolute claim forbidden '.$bad);}
ppm_test_assert(strpos($allowed,'keine weitere nicht zugeordnete Lücke gefunden')!==false,'honest limited wording');
ppm_test_assert(!empty($c['search_methods'])&&!empty($c['known_limits'])&&!empty($c['examined_source_tree_sha256']),'scope and limits disclosed');
echo json_encode(array('status'=>'PASS_V31_STATUS_WORDING','statement'=>$allowed,'absolute_completeness_claimed'=>false),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
