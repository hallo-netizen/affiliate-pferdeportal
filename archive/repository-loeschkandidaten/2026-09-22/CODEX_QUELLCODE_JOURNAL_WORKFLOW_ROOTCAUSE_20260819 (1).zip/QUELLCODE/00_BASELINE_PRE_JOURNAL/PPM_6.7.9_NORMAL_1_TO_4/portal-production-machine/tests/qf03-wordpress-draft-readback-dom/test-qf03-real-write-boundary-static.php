<?php
require_once dirname(__DIR__).'/bootstrap-test.php';
$root=dirname(__DIR__,2);
$wp=(string)file_get_contents($root.'/includes/wp-adapter.php');
$all=''; foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root.'/includes')) as $file){ if($file->isFile() && substr($file->getFilename(),-4)==='.php'){$all.="\n".$file->getPathname()."\n".file_get_contents($file->getPathname());} }
$verifyPos=strpos($wp,'PPM679_WP_Draft_Adapter::verify_write_authorization');
$insertPos=strpos($wp,'wp_insert_post(');
ppm_test_assert($verifyPos!==false && $insertPos!==false && $verifyPos<$insertPos,'QF03 authorization verification must execute before wp_insert_post');
ppm_test_assert(substr_count($all,'wp_insert_post(')===1,'Only the guarded WP adapter may contain wp_insert_post');
ppm_test_assert(strpos($wp,"'post_status' => 'draft'")!==false,'Guarded write must hardcode draft status');
ppm_test_assert(strpos($wp,"'post_type' => 'post'")!==false,'Guarded write must hardcode post type');
ppm_test_assert(!method_exists('PPM679_WP','publish_post'),'No publish method may exist');
echo json_encode(array('contract'=>'qf03_real_write_boundary_static_test_v1','status'=>'PASS','authorization_before_wp_insert_post'=>true,'wp_insert_post_occurrences'=>1,'post_status_hardcoded'=>'draft','publish_method_present'=>false),JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
