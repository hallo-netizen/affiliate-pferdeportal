<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

$index=json_decode((string)file_get_contents(__DIR__.'/fixtures/wave2/mutations-index.json'),true);
ppm_test_assert(is_array($index) && (int)($index['count']??0)>0,'mutation index must exist');
$results=array();
foreach ($index['items'] as $entry) {
    $id=(string)$entry['mutation_id'];
    $dir=__DIR__.'/fixtures/wave2/mutations/'.$id;
    $meta=json_decode((string)file_get_contents($dir.'/metadata.json'),true);
    $html=(string)file_get_contents($dir.'/article.html');
    ppm_test_assert(hash('sha256',$html)===(string)$meta['body_html_sha256'],$id.' HTML hash must match');
    if ($id!=='M21_BINDING_HASH') {
        ppm_test_assert(PPM679_Diagnostic::stable_hash($meta['quality_binding'])===(string)$meta['quality_binding_hash'],$id.' quality binding hash must match');
    }
    $generated=array(
        'article_type'=>$meta['article_type'],
        'title'=>$meta['title'],
        'content_html'=>$html,
        'content_hash'=>hash('sha256',$html),
    );
    $item=array(
        'article_type'=>$meta['article_type'],
        'quality_binding'=>$meta['quality_binding'],
        'quality_binding_hash'=>$meta['quality_binding_hash'],
        'runtime_order'=>$meta['runtime_order'],
    );
    $result=PPM679_Content_Structure_Language_Gate::evaluate($generated,$item,'wave2_mutation_'.$id,'local-wave2-state');
    ppm_test_assert(empty($result['ok']),$id.' must be BLOCKED');
    ppm_test_assert(($result['content_structure_language_gate_status']??'')==='BLOCKED',$id.' gate status must be BLOCKED');
    $codes=array_values(array_unique(array_map(static fn($e)=>(string)($e['error_code']??''),(array)($result['errors']??array()))));
    $expected=(string)$entry['expected_error_code'];
    ppm_test_assert(in_array($expected,$codes,true),$id.' must expose '.$expected.' actual='.json_encode($codes));
    $base=array(
        'ok'=>true,
        'technical_status'=>'TECHNICAL_CHECK_OK',
        'content_quality_status'=>'CONTENT_QUALITY_CHECK_OK',
        'errors'=>array(),
        'technical_errors'=>array(),
        'content_quality_errors'=>array(),
        'checks'=>array(),
    );
    $known=array(
        'ok'=>true,
        'known_error_gate_status'=>'PASS',
        'errors'=>array(),
        'checks'=>array(),
    );
    $merged=PPM679_Fail_Closed_Aggregator::merge_content_validation_with_structure($base,$known,$result,'wave2_mutation_fail_closed_'.$id);
    ppm_test_assert(empty($merged['ok']),$id.' must remain BLOCKED after fail-closed merge');
    ppm_test_assert(($merged['content_quality_status']??'')==='BLOCKED_CONTENT_QUALITY_CHECK',$id.' merged quality status must block');
    $results[$id]=array(
        'expected_error_code'=>$expected,
        'actual_error_codes'=>$codes,
        'language_raw_finding_count'=>$meta['quality_binding']['language_evidence']['raw_finding_count']??null,
        'fail_closed_status'=>$merged['checks']['fail_closed_aggregate_status']??null,
    );
}

echo json_encode(array(
    'contract'=>'wave2_content_mutation_report_v1',
    'status'=>'PASS',
    'mutation_count'=>count($results),
    'items'=>$results,
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
