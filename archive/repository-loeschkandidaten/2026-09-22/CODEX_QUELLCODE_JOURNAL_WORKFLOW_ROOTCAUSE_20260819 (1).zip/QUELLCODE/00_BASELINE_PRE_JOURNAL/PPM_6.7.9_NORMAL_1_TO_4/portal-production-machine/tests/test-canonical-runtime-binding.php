<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';
PPM679_WP::reset_test_state();
PPM679_Storage::reset_test_state();

$input=json_decode((string)file_get_contents(__DIR__.'/canonical-runtime-input.json'),true);
ppm_test_assert(is_array($input),'Canonical runtime input must decode');
$import=PPM679_Admin::import_fact_pack_bundle($input['fact_pack_bundle']);
ppm_test_assert(!empty($import['ok']),'Canonical fact-pack import must pass');

$contract_hashes=PPM679_Plan_Validator::active_contract_hashes();
$items=$input['items'];
foreach ($items as &$item) {
    $stored=PPM679_Storage::fact_pack_hash($item['source_snapshot_id']);
    ppm_test_assert((bool)preg_match('/^[0-9a-f]{64}$/',$stored),'Stored fact-pack hash must be SHA-256');
    $item['source_hashes']=array($stored);
    $item['contract_hashes']=$contract_hashes;
}
unset($item);
$plan=array(
    'contract'=>'production_plan_v4',
    'plan_contract_version'=>'4.0.0',
    'required_plugin_version'=>'6.7.9',
    'plan_id'=>'canonical-runtime-local-four-type-v1',
    'created_at'=>gmdate('c'),
    'gold_core_binding'=>'FOUR_TYPE_APPROVED_GOLD_CORE_V1',
    'contract_hashes'=>$contract_hashes,
    'items'=>$items,
);
$validated=PPM679_Plan_Validator::validate($plan,'canonical_runtime_local','local-state-hash');
if (empty($validated['ok'])) {
    fwrite(STDERR,json_encode($validated,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n");
}
ppm_test_assert(!empty($validated['ok']),'Canonical runtime plan must validate');

$results=array();
$canonical_cases=array();
foreach ($plan['items'] as $item) {
    $pack=PPM679_Storage::load_fact_pack($item['source_snapshot_id']);
    $generated=PPM679_Content_Generator::generate($item,$pack);
    ppm_test_assert(!empty($generated['ok']),'Canonical article must bind into PHP runtime for '.$item['article_type']);
    ppm_test_assert(hash_equals($item['canonical_article']['body_html_sha256'],$generated['content_hash']),'PHP runtime must preserve canonical Cross-Domain HTML hash');
    $check=PPM679_Content_Validator::check($generated,$item,'canonical_runtime_local','local-state-hash');
    if (empty($check['ok'])) {
        fwrite(STDERR,json_encode($check,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n");
    }
    ppm_test_assert(!empty($check['ok']),'Dual technical/content gate must pass for '.$item['article_type']);
    ppm_test_assert(($check['technical_status']??'')==='TECHNICAL_CHECK_OK','Technical check must pass');
    ppm_test_assert(($check['content_quality_status']??'')==='CONTENT_QUALITY_CHECK_OK','Content quality check must pass');
    $canonical_cases[$item['article_type']]=array('item'=>$item,'generated'=>$generated,'pack'=>$pack);
    $results[$item['article_type']]=array(
        'status'=>'PASS',
        'content_hash'=>$generated['content_hash'],
        'word_count'=>$check['checks']['word_count'],
        'paragraph_count'=>$check['checks']['paragraph_count'],
        'h2_count'=>$check['checks']['h2_count'],
        'table_body_row_count'=>$check['checks']['table_body_row_count'],
        'source_trace_count'=>$check['checks']['source_trace_count'],
    );
}


function ppm_validator_error_codes($result) {
    $codes=array();
    foreach (($result['errors']??array()) as $error) {
        $code=(string)($error['error_code']??'');
        if ($code!=='') { $codes[$code]=true; }
    }
    return array_keys($codes);
}

function ppm_validator_mutation($base_generated,$item,$mutator,$expected_code,$label) {
    $candidate=$base_generated;
    $candidate['content_html']=$mutator((string)$base_generated['content_html']);
    $candidate['content_hash']=hash('sha256',$candidate['content_html']);
    $check=PPM679_Content_Validator::check($candidate,$item,'deterministic_negative_'.$label,'local-state-hash');
    $codes=ppm_validator_error_codes($check);
    ppm_test_assert(empty($check['ok']),$label.' must be blocked');
    ppm_test_assert(in_array($expected_code,$codes,true),$label.' must emit '.$expected_code.'; got '.implode(',',$codes));
    return array('label'=>$label,'expected_code'=>$expected_code,'codes'=>$codes,'status'=>'BLOCKED_AS_EXPECTED');
}

$faq_case=$canonical_cases['FAQ'];
$faq_item=$faq_case['item'];
$faq_generated=$faq_case['generated'];
$faq_pack=$faq_case['pack'];
$first_fact_id=(string)$faq_pack['claims'][0]['fact_id'];
$negative_results=array();

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) {
    return (string)preg_replace('/href="[^"]+"/u','href="https://external.invalid/"',$html,1);
},'BLOCKED_CONTENT_INTERNAL_LINK_ROLE','internal_link_role');

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) {
    return (string)preg_replace('/\sdata-fact-ids="[^"]+"/u','',$html,1);
},'BLOCKED_CONTENT_FACT_REFS_MISSING','factual_unit_reference');

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) {
    return (string)preg_replace('/data-fact-ids="[^"]+"/u','data-fact-ids="unknown-fact-id"',$html,1);
},'BLOCKED_CONTENT_FACT_REF_UNKNOWN','unknown_fact_reference');

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) {
    return (string)preg_replace('/(<p\b[^>]*data-fact-ids="[^"]+"[^>]*>.*?)(<\/p>)/isu','$1 Die nicht belegte Zahl lautet 999999.$2',$html,1);
},'BLOCKED_CONTENT_NUMERIC_CLAIM_UNSUPPORTED','numeric_claim_support');

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) use ($first_fact_id) {
    return (string)preg_replace('/data-fact-ids="[^"]+"/u','data-fact-ids="'.$first_fact_id.'"',$html);
},'BLOCKED_CONTENT_FACT_PACK_COVERAGE','fact_pack_coverage');

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) {
    return (string)preg_replace_callback(
        '/(<p\b[^>]*data-fact-ids="[^"]+"[^>]*>)(.*?)(<span\b[^>]*class="ppm-source-trace"[^>]*>.*?<\/span>)(.*?<\/p>)/isu',
        function($match) { return $match[1].'Xylophon Quasar Nebel Vulkan Marmor Zirkus Phantom. '.$match[3].$match[4]; },
        $html
    );
},'BLOCKED_CONTENT_TRACE_LEXICAL_SUPPORT','trace_lexical_support');

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) use ($first_fact_id) {
    $sentence='Dieser vollständig identische Satz wird absichtlich immer wieder ohne neuen Informationswert wiederholt.';
    $repeat='<p data-fact-ids="'.$first_fact_id.'">'.implode(' ',array_fill(0,40,$sentence)).'</p>';
    return (string)preg_replace('/(<section\b[^>]*data-block="intro"[^>]*>)/iu','$1'.$repeat,$html,1);
},'BLOCKED_CONTENT_DUPLICATE_SENTENCE_RATIO','duplicate_sentence_ratio');

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) {
    if (!preg_match('/<section\b[^>]*data-block="intro"[^>]*>.*?(<p\b[^>]*>.*?<\/p>)/isu',$html,$match)) { return $html; }
    return (string)preg_replace('/(<section\b[^>]*data-block="intro"[^>]*>)/iu','$1'.$match[1],$html,1);
},'BLOCKED_CONTENT_INTRO_PAIR_SIMILARITY','intro_pair_similarity');

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) {
    return (string)preg_replace('/data-source-hash="[0-9a-f]{64}"/u','data-source-hash="abcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcdefabcd"',$html,1);
},'BLOCKED_CONTENT_TRACE_CLAIM_MISMATCH','trace_claim_binding');

$short_words=ppm_validator_mutation($faq_generated,$faq_item,function($html) {
    return (string)preg_replace_callback('/<p\b([^>]*)>.*?<\/p>/isu',function($match) {
        if (strpos($match[1],'pm-ai-disclosure')!==false) { return $match[0]; }
        return '<p'.$match[1].'>Kurz.</p>';
    },$html);
},'BLOCKED_CONTENT_WORD_FLOOR','word_floor');
$negative_results[]=$short_words;

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) {
    $seen=0;
    return (string)preg_replace_callback('/<p\b[^>]*>.*?<\/p>/isu',function($match) use (&$seen) {
        $seen++; return $seen<=10?$match[0]:'';
    },$html);
},'BLOCKED_CONTENT_PARAGRAPH_FLOOR','paragraph_floor');

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) {
    $seen=0;
    return (string)preg_replace_callback('/<h2\b([^>]*)>(.*?)<\/h2>/isu',function($match) use (&$seen) {
        $seen++; return $seen<=3?$match[0]:'<h3'.$match[1].'>'.$match[2].'</h3>';
    },$html);
},'BLOCKED_CONTENT_H2_FLOOR','h2_floor');

$negative_results[]=ppm_validator_mutation($faq_generated,$faq_item,function($html) {
    if (!preg_match('/<tbody\b[^>]*>(.*?)<\/tbody>/isu',$html,$tbody)) { return $html; }
    preg_match_all('/<tr\b[^>]*>.*?<\/tr>/isu',$tbody[1],$rows);
    $replacement='<tbody>'.implode('',array_slice($rows[0],0,3)).'</tbody>';
    return str_replace($tbody[0],$replacement,$html);
},'BLOCKED_CONTENT_TABLE_ROW_FLOOR','table_row_floor');

$bad_pack=$faq_pack;
$bad_pack['claims'][0]['claim_status']='REJECTED';
PPM679_Storage::save_fact_pack($faq_item['source_snapshot_id'],$bad_pack);
$status_check=PPM679_Content_Validator::check($faq_generated,$faq_item,'deterministic_negative_fact_status','local-state-hash');
$status_codes=ppm_validator_error_codes($status_check);
ppm_test_assert(in_array('BLOCKED_CONTENT_FACT_REF_NOT_VERIFIED',$status_codes,true),'Fact status mutation must be blocked');
$negative_results[]=array('label'=>'fact_status','expected_code'=>'BLOCKED_CONTENT_FACT_REF_NOT_VERIFIED','codes'=>$status_codes,'status'=>'BLOCKED_AS_EXPECTED');
PPM679_Storage::save_fact_pack($faq_item['source_snapshot_id'],$faq_pack);

$bad_pack=$faq_pack;
$bad_pack['claims'][0]['article_types']=array('Pflege');
PPM679_Storage::save_fact_pack($faq_item['source_snapshot_id'],$bad_pack);
$type_check=PPM679_Content_Validator::check($faq_generated,$faq_item,'deterministic_negative_fact_type','local-state-hash');
$type_codes=ppm_validator_error_codes($type_check);
ppm_test_assert(in_array('BLOCKED_CONTENT_FACT_REF_TYPE_MISMATCH',$type_codes,true),'Fact type mutation must be blocked');
$negative_results[]=array('label'=>'fact_type','expected_code'=>'BLOCKED_CONTENT_FACT_REF_TYPE_MISMATCH','codes'=>$type_codes,'status'=>'BLOCKED_AS_EXPECTED');
PPM679_Storage::save_fact_pack($faq_item['source_snapshot_id'],$faq_pack);

$repetitive_generated=$faq_generated;
$repetitive_sentence='Dieser sachfremde Standardsatz zur Lebensmittellagerung wird ohne neue Information erneut wiederholt.';
$repetitive_html=(string)preg_replace('/(<section\b[^>]*data-block="intro"[^>]*>)/iu','$1<p data-fact-ids="'.$first_fact_id.'">'.implode(' ',array_fill(0,45,$repetitive_sentence)).'</p>',$repetitive_generated['content_html'],1);
$repetitive_generated['content_html']=$repetitive_html;
$repetitive_generated['content_hash']=hash('sha256',$repetitive_html);
$repetitive_check=PPM679_Content_Validator::check($repetitive_generated,$faq_item,'deterministic_negative_original_runtime_defect','local-state-hash');
$repetitive_codes=ppm_validator_error_codes($repetitive_check);
ppm_test_assert(in_array('BLOCKED_CONTENT_DUPLICATE_SENTENCE_RATIO',$repetitive_codes,true),'Previously passing repetitive cross-topic article must now be blocked');
$negative_results[]=array('label'=>'previously_passing_repetitive_cross_topic','expected_code'=>'BLOCKED_CONTENT_DUPLICATE_SENTENCE_RATIO','codes'=>$repetitive_codes,'status'=>'BLOCKED_AS_EXPECTED');

ppm_test_assert(count(PPM679_WP::test_posts())===0,'No WordPress drafts may be created in local binding test');

echo json_encode(array(
    'status'=>'PASS',
    'contract'=>'canonical_runtime_binding_local_test_v1',
    'fact_pack_imported'=>count($import['imported']),
    'articles'=>$results,
    'negative_tests'=>$negative_results,
    'negative_tests_total'=>count($negative_results),
    'draft_count'=>count(PPM679_WP::test_posts()),
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
