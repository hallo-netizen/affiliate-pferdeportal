<?php
require_once __DIR__.'/fixture-builder.php';
$errors=PPM679_State_Transition_Validator::validate();
ppm_test_assert($errors===array(),'all 13 persistent transition scenarios mapped');
$c=json_decode(file_get_contents(dirname(__DIR__,2).'/contracts/state-transition-matrix-v3-1.json'),true);
ppm_test_assert(count($c['scenarios'])===13,'13 scenarios including 4a and 4b');
echo json_encode(array('status'=>'PASS_V31_STATE_TRANSITION_MATRIX','scenario_count'=>13,'persistent_fixture_required'=>true),JSON_UNESCAPED_SLASHES)."\n";
