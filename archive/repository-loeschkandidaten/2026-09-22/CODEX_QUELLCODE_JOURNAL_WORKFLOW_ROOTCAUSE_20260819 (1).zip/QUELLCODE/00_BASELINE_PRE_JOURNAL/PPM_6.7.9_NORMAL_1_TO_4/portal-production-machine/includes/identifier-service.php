<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Identifier_Service {
    const VERSION='6.7.9';
    const MAX_ATTEMPTS=20;

    public static function create_bundle($run_id,$plan_item_key,$context,$server_state_hash='') {
        $types=array(
            'batch_article_id'=>'article',
            'fact_pack_id'=>'fact',
            'skeleton_id'=>'skeleton',
            'reservation_id'=>'reservation',
            'skeleton_token'=>'token',
        );
        $bundle=array();
        foreach ($types as $field=>$prefix) {
            $result=self::fresh($field,$prefix,$run_id,$context,$server_state_hash);
            if (!$result['ok']) { return $result; }
            $bundle[$field]=$result['value'];
        }
        return array('ok'=>true,'bundle'=>$bundle);
    }


    public static function validate_unused($type,$value,$context,$server_state_hash='') {
        if (PPM679_Storage::identifier_exists((string)$type,(string)$value)) {
            $error=PPM679_Diagnostic::error(
                'BLOCKED_IDENTIFIER_HISTORY_COLLISION',
                'OPERATIONAL_IDENTIFIER_MUST_NEVER_EXIST_IN_TOMBSTONE_HISTORY',
                'identifiers.'.(string)$type,
                'identifier absent from permanent tombstones',
                (string)$value,
                'Der Identifier wurde bereits reserviert, konsumiert oder abgebrochen und darf niemals wiederverwendet werden.',
                $context,
                $server_state_hash,
                __CLASS__,
                null,
                array('includes/identifier-service.php')
            );
            return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),$context,$server_state_hash));
        }
        return array('ok'=>true);
    }

    public static function fresh($type,$prefix,$run_id,$context,$server_state_hash='') {
        for ($attempt=0;$attempt<self::MAX_ATTEMPTS;$attempt++) {
            try { $random=bin2hex(random_bytes(18)); }
            catch (Throwable $e) { $random=hash('sha256',microtime(true).'|'.mt_rand().'|'.$attempt.'|'.$run_id); }
            $value=$prefix.'-'.substr($random,0,32);
            if (PPM679_Storage::identifier_exists($type,$value)) { continue; }
            if (PPM679_Storage::tombstone($type,$value,$run_id,'RESERVED')) {
                return array('ok'=>true,'value'=>$value);
            }
        }
        $error=PPM679_Diagnostic::error(
            'BLOCKED_IDENTIFIER_RESERVATION_EXHAUSTED',
            'SERVER_MUST_CREATE_AND_TOMBSTONE_FRESH_OPERATIONAL_IDENTIFIER',
            'identifiers.'.$type,
            'fresh server-generated identifier',
            'collision after '.self::MAX_ATTEMPTS.' attempts',
            'Der Server konnte keinen neuen, dauerhaft tombstonierten Identifier atomar reservieren.',
            $context,
            $server_state_hash,
            __CLASS__,
            null,
            array('includes/identifier-service.php')
        );
        return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),$context,$server_state_hash));
    }
}
