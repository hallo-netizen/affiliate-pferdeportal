<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Content_Inventory_Reconciler {
    public static function runtime_inventory(){
        $items=PPM679_WP::get_all_post_inventory(array('publish','draft','trash'));
        $out=array();foreach((array)$items as $item){$out[]=self::classify($item);}
        usort($out,function($a,$b){return ((int)$a['post_id'])<=>((int)$b['post_id']);});
        $snapshot=array('contract'=>'PPM679_RUNTIME_WORDPRESS_CONTENT_INVENTORY_V1','captured_at'=>gmdate('c'),'capture_mode'=>'READ_ONLY_RUNTIME','items'=>$out,'counts'=>array('total'=>count($out),'publish'=>count(array_filter($out,function($x){return $x['status']==='publish';})),'draft'=>count(array_filter($out,function($x){return $x['status']==='draft';})),'trash'=>count(array_filter($out,function($x){return $x['status']==='trash';}))),'wordpress_write_performed'=>false);
        $snapshot['snapshot_sha256']=PPM679_Diagnostic::stable_hash($snapshot);return $snapshot;
    }
    public static function reconcile($runtime=null){
        $runtime=is_array($runtime)?$runtime:self::runtime_inventory();$items=(array)($runtime['items']??array());$groups=array();
        foreach($items as $item){$n=PPM679_Editorial_Plan_Registry::normalize_title((string)($item['title']??''));if(!isset($groups[$n])){$groups[$n]=array('normalized_title'=>$n,'post_ids'=>array(),'items'=>array());}$groups[$n]['post_ids'][]=(int)$item['post_id'];$groups[$n]['items'][]=$item;}
        foreach($groups as $n=>&$g){$g['canonical_group_id']=self::canonical_group_id($g);$g['member_count']=count($g['post_ids']);$g['requires_duplicate_resolution']=$g['member_count']>1;$g['production_coverage_count']=count(array_filter($g['items'],function($x){return !empty($x['counts_as_production_coverage']);}));}unset($g);
        ksort($groups,SORT_STRING);
        return array('ok'=>true,'status'=>'CONTENT_INVENTORY_RECONCILED_READ_ONLY','runtime_snapshot'=>$runtime,'canonical_groups'=>array_values($groups),'canonical_group_count'=>count($groups),'write_attempted'=>false,'publish_allowed'=>false);
    }
    public static function classify($item){
        $id=(int)($item['post_id']??$item['ID']??0);$title=(string)($item['title']??$item['post_title']??'');$status=(string)($item['status']??$item['post_status']??'');$meta=(array)($item['meta']??array());
        $marker=(string)($item['test_marker']??$meta['_ppm679_test_marker']??$meta['_ppm679_run_marker']??'');$canonical=(string)($item['canonical_article_id']??$meta['_ppm679_canonical_article_id']??'');
        $known_technical=in_array($id,array(10362,10324,10277,10205,9848,9776,10206,9849,9777,10207,9850,9778,10208,9851,9779),true)||preg_match('/^\s*\[LT/u',$title)||$marker!=='';
        if($id===10362){$role='TECHNICAL_EVIDENCE_SUCCESS';}
        elseif(in_array($id,array(10324,10277),true)){$role='TECHNICAL_EVIDENCE_FAILED';}
        elseif($known_technical){$role='TECHNICAL_TEST_ARTIFACT';}
        elseif($status==='publish'){$role='PUBLISHED_REGULAR_CONTENT';}
        elseif($status==='draft'){$role='REGULAR_DRAFT_REVIEW_REQUIRED';}
        elseif($status==='trash'){$role='TRASH_CONTENT_DUPLICATE_REVIEW_REQUIRED';}
        else{$role='UNKNOWN_BLOCKING';}
        return array('post_id'=>$id,'title'=>$title,'normalized_title'=>PPM679_Editorial_Plan_Registry::normalize_title($title),'status'=>$status,'category_name'=>(string)($item['category_name']??$item['category']??''),'category_slug'=>(string)($item['category_slug']??''),'canonical_article_id'=>$canonical,'test_marker'=>$marker,'inventory_role'=>$role,'counts_as_production_coverage'=>$role==='PUBLISHED_REGULAR_CONTENT','may_block_duplicate'=>!in_array($role,array('TECHNICAL_EVIDENCE_FAILED','TECHNICAL_TEST_ARTIFACT'),true));
    }
    private static function canonical_group_id($g){foreach((array)$g['items'] as $x){if(!empty($x['canonical_article_id'])){return (string)$x['canonical_article_id'];}}return 'inventory-group:'.substr(hash('sha256',(string)$g['normalized_title']),0,20);}
}
