<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

PPM679_WP::reset_test_state();
PPM679_Storage::reset_test_state();

$input=json_decode((string)file_get_contents(__DIR__.'/canonical-runtime-input.json'),true);
ppm_test_assert(is_array($input),'canonical runtime input must decode');
$faqItems=array_values(array_filter((array)($input['items']??array()),static fn($item)=>is_array($item)&&($item['article_type']??'')==='FAQ'));
ppm_test_assert(count($faqItems)===1,'exactly one canonical FAQ must exist');
$item=$faqItems[0];
ppm_test_assert(isset($item['quality_binding'])&&is_array($item['quality_binding']),'FAQ must include Wave-2 quality binding');
ppm_test_assert(PPM679_Diagnostic::stable_hash($item['quality_binding'])===(string)($item['quality_binding_hash']??''),'FAQ quality binding hash must match');

$packs=array_values(array_filter((array)($input['fact_pack_bundle']['fact_packs']??array()),static fn($pack)=>is_array($pack)&&($pack['fact_pack_id']??'')===($item['source_snapshot_id']??'')));
ppm_test_assert(count($packs)===1,'exactly one bound FAQ fact pack must exist');
$import=PPM679_Admin::import_fact_pack_bundle(array('contract'=>'canonical_fact_pack_import_v1','fact_packs'=>$packs));
ppm_test_assert(!empty($import['ok']),'FAQ fact pack import must pass');
$item['source_hashes']=array(PPM679_Storage::fact_pack_hash((string)$item['source_snapshot_id']));
$item['contract_hashes']=PPM679_Plan_Validator::active_contract_hashes();

$runtimeMethod=new ReflectionMethod(PPM679_Plan_Validator::class,'validate_runtime_payload');
$runtimeMethod->setAccessible(true);
$runtimeErrors=array();
$args=array($item,0,&$runtimeErrors,'g8_targeted_repair_faq_runtime','local-g8-repair-state',false);
$runtimeMethod->invokeArgs(null,$args);
ppm_test_assert($runtimeErrors===array(),'complete FAQ runtime payload must pass exact Wave-2 binding checks');

$pack=PPM679_Storage::load_fact_pack((string)$item['source_snapshot_id']);
$generated=PPM679_Content_Generator::generate($item,$pack);
ppm_test_assert(!empty($generated['ok']),'repaired canonical FAQ must generate');
ppm_test_assert(hash_equals((string)$item['canonical_article']['body_html_sha256'],(string)$generated['content_hash']),'generated content hash must match repaired canonical binding');
$check=PPM679_Content_Validator::check($generated,$item,'g8_targeted_repair_faq','local-g8-repair-state');
if (empty($check['ok'])) {
    fwrite(STDERR,json_encode($check,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");
}
ppm_test_assert(!empty($check['ok']),'repaired canonical FAQ must pass all active Wave-1 and Wave-2 gates');
ppm_test_assert(($check['technical_status']??'')==='TECHNICAL_CHECK_OK','technical status must pass');
ppm_test_assert(($check['content_quality_status']??'')==='CONTENT_QUALITY_CHECK_OK','content quality status must pass');
ppm_test_assert(($check['checks']['known_error_gate_status']??'')==='PASS','known-error gate must pass');
ppm_test_assert(($check['checks']['content_structure_language_gate_status']??'')==='PASS','Wave-2 structure/language gate must pass');
ppm_test_assert(($check['checks']['fail_closed_aggregate_status']??'')==='PASS','fail-closed aggregate must pass');

$html=(string)$generated['content_html'];
ppm_test_assert(preg_match('/<h1\b/iu',$html)!==1,'body H1 must be absent');
ppm_test_assert(substr_count($html,'<a href=')===3,'exactly three visible links must exist');
ppm_test_assert(preg_match_all('/<li\b[^>]*>/iu',$html,$unused)>=4,'at least four real list items must exist');
foreach (array('intro','answer','details','checklist','table','conclusion','further_information') as $block) {
    ppm_test_assert(strpos($html,'data-block="'.$block.'"')!==false,'required FAQ block must exist: '.$block);
}
$marker=(string)$item['quality_binding']['internal_test_marker'];
ppm_test_assert($marker!=='' && strpos($html,$marker)===false,'internal test marker must be bound but invisible');
ppm_test_assert((int)$item['quality_binding']['wordpress_category']['id']>0,'real WordPress category must be bound');
ppm_test_assert(($check['checks']['content_structure_language_gate_checks']['language_evidence_valid']??false)===true,'LanguageTool 43 evidence must be exact and valid');
ppm_test_assert(count(PPM679_WP::test_posts())===0,'local repair test must create no test post or draft');

echo json_encode(array(
    'contract'=>'g8_targeted_repair_faq_chain_report_v1',
    'status'=>'PASS',
    'plan_item_key'=>$item['plan_item_key'],
    'content_hash'=>$generated['content_hash'],
    'quality_binding_hash'=>$item['quality_binding_hash'],
    'machine_statuses'=>array(
        'technical'=>$check['technical_status'],
        'content_quality'=>$check['content_quality_status'],
        'known_error_gate'=>$check['checks']['known_error_gate_status']??null,
        'wave2_gate'=>$check['checks']['content_structure_language_gate_status']??null,
        'fail_closed'=>$check['checks']['fail_closed_aggregate_status']??null,
    ),
    'metrics'=>array(
        'word_count'=>$check['checks']['word_count']??null,
        'paragraph_count'=>$check['checks']['paragraph_count']??null,
        'h2_count'=>$check['checks']['h2_count']??null,
        'table_body_row_count'=>$check['checks']['table_body_row_count']??null,
        'source_trace_count'=>$check['checks']['source_trace_count']??null,
        'visible_link_count'=>$check['checks']['visible_link_count']??null,
        'fact_pack_coverage_ratio'=>$check['checks']['fact_pack_coverage_ratio']??null,
        'trace_lexical_support_ratio'=>$check['checks']['trace_lexical_support_ratio']??null,
    ),
    'wordpress_accessed'=>false,
    'drafts_created'=>0,
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
