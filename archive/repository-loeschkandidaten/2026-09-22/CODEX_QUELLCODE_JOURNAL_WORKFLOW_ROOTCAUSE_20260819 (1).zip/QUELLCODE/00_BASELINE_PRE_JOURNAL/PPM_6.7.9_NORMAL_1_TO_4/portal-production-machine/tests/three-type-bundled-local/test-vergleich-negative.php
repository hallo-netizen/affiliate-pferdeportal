<?php
require __DIR__.'/bootstrap-three-type.php';
[$item,$pack,$g]=ppm_three_generated('Vergleich');ppm_test_assert(!empty($g['ok']),'valid Vergleich generation');
$g['content_html']=preg_replace('/data-block="comparison"/','data-block="comparison-mutated"',$g['content_html'],1);$g['content_hash']=hash('sha256',$g['content_html']);
$r=PPM679_Three_Type_Bundled_Local_Preflight::validate_generated_mutation($g,$item,$pack,'vergleich_required_comparison');$codes=ppm_three_codes($r['errors']);
ppm_test_assert(empty($r['ok']),'mutated Vergleich must block');ppm_test_assert(in_array('BLOCKED_CONTENT_REQUIRED_BLOCK_MISSING',$codes,true),'Vergleich missing comparison code');
echo json_encode(['status'=>'PASS_VERGLEICH_NEGATIVE_MUTATION_BLOCKED','expected_code'=>'BLOCKED_CONTENT_REQUIRED_BLOCK_MISSING','codes'=>$codes],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
