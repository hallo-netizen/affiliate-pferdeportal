<?php
declare(strict_types=1);
require_once __DIR__.'/fixture-builder.php';

$snapshot=v34_snapshot();
$binding=v36_valid_binding();
$item=array(
    'article_type'=>'FAQ',
    'category_binding'=>$binding,
    'category_binding_hash'=>PPM679_Diagnostic::stable_hash($binding),
    'canonical_article'=>array('category_binding_hash'=>PPM679_Diagnostic::stable_hash($binding)),
);
$method=new ReflectionMethod(PPM679_Plan_Validator::class,'validate_v5_category_binding');
$method->setAccessible(true);
function v34_plan_category_errors(ReflectionMethod $method,array $item): array {
    $errors=array();
    $args=array($item,0,&$errors,'v34_plan_category_binding','local-v34-state');
    $method->invokeArgs(null,$args);
    return $errors;
}
$positive=v34_plan_category_errors($method,$item);
ppm_test_assert($positive===array(),'complete V5 category binding must pass');

$missing=$item; unset($missing['category_binding']);
ppm_test_assert(v34_plan_category_errors($method,$missing)!==array(),'missing V5 category binding must block');

$fixed=$item; $fixed['category_binding']['term_id']=1048; $fixed['category_binding_hash']=PPM679_Diagnostic::stable_hash($fixed['category_binding']); $fixed['canonical_article']['category_binding_hash']=$fixed['category_binding_hash'];
$fixed_errors=v34_plan_category_errors($method,$fixed);
ppm_test_assert(in_array('BLOCKED_PLAN_CATEGORY_FIXED_TERM_ID',array_column($fixed_errors,'error_code'),true),'fixed term id must block');

$fallback=$item; $fallback['category_binding']['name']='Uncategorized'; $fallback['category_binding']['slug']='uncategorized'; $fallback['category_binding']['hierarchy_path']='Uncategorized'; $fallback['category_binding']['portal_path']='Uncategorized'; $fallback['category_binding']['portal_level']=1; $fallback['category_binding']['portal_node_types']=array('wordpress_category'); $fallback['category_binding_hash']=PPM679_Diagnostic::stable_hash($fallback['category_binding']); $fallback['canonical_article']['category_binding_hash']=$fallback['category_binding_hash'];
$fallback_errors=v34_plan_category_errors($method,$fallback);
ppm_test_assert(in_array('BLOCKED_PLAN_CATEGORY_FALLBACK',array_column($fallback_errors,'error_code'),true),'fallback category must block');

$stale=$item; $stale['category_binding']['category_source_snapshot_hash']=str_repeat('0',64); $stale['category_binding_hash']=PPM679_Diagnostic::stable_hash($stale['category_binding']); $stale['canonical_article']['category_binding_hash']=$stale['category_binding_hash'];
$stale_errors=v34_plan_category_errors($method,$stale);
ppm_test_assert(in_array('BLOCKED_PLAN_CATEGORY_SNAPSHOT_STALE',array_column($stale_errors,'error_code'),true),'stale category snapshot must block');

echo "PASS_V34_PRODUCTION_PLAN_V5_CATEGORY_BINDING\n";
