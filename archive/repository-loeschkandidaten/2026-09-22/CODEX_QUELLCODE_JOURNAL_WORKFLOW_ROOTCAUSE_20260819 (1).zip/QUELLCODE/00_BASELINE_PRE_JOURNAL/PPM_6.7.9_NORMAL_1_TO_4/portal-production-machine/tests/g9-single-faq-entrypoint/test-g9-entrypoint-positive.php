<?php
require_once dirname(__DIR__).'/bootstrap-test.php';
PPM679_WP::reset_test_state(); PPM679_Storage::reset_test_state();
$r=PPM679_G9_Single_FAQ_Entrypoint::execute(array('user_triggered'=>true,'nonce_verified'=>true,'current_user_can_manage'=>true,'declared_contract'=>PPM679_G9_Single_FAQ_Entrypoint::CONTRACT,'declared_plan_item_key'=>PPM679_G9_Single_FAQ_Entrypoint::PLAN_ITEM_KEY,'simulation_only'=>true,'evidence_class'=>'LOCAL_EXECUTED_TEST'));
ppm_test_assert($r['ok']===true,'separate G9 entrypoint must pass exact local simulation');
ppm_test_assert($r['status']==='PASS_G9_SINGLE_FAQ_LOCAL_SIMULATION_NOT_SERVER_PASS','local result must not claim server PASS');
ppm_test_assert(count(PPM679_WP::test_posts())===1,'exactly one in-memory FAQ draft must exist');
ppm_test_assert($r['four_type_path_used']===false,'four-type path must not be used');
echo json_encode(array('status'=>'PASS','entrypoint_status'=>$r['status'],'post_id'=>$r['post_id'],'article_sha256'=>$r['article_sha256'],'four_type_path_used'=>$r['four_type_path_used'],'server_pass_claimed'=>false),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
