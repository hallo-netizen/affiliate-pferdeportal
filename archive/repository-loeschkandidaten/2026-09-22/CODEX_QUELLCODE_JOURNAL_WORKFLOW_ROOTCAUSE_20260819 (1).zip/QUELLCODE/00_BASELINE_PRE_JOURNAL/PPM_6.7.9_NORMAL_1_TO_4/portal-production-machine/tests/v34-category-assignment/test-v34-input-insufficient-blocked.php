<?php
require_once __DIR__.'/fixture-builder.php';
$s=v34_semantic();$s['title']='';$s['topic']='';$s['outline']='';$s['keywords']=array();
$r=PPM679_Category_Assignment_Validator::derive_independent($s,v34_snapshot());
ppm_test_assert(empty($r['ok']),'insufficient input must block');
ppm_test_assert(strpos((string)($r['report']['status']??''),'BLOCKED_CATEGORY_INPUT_INSUFFICIENT')===0,'input diagnosis');
echo "PASS_V34_INPUT_INSUFFICIENT_BLOCKED\n";
