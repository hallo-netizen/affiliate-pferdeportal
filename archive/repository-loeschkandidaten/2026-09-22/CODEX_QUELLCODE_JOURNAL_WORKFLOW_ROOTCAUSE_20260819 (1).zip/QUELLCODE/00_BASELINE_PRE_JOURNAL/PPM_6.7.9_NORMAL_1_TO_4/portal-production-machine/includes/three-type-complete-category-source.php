<?php
if (!defined('ABSPATH')) { return; }

/** Local-only complete semantic category source for the bundled three-type block. */
final class PPM679_Three_Type_Complete_Category_Source {
    const VERSION='6.7.9';
    const SNAPSHOT_FILE='contracts/three-type-complete-category-hierarchy-snapshot-v2.json';
    const SOURCE_FILE='contracts/complete-portal-category-source-v1.json';
    const EXPECTED_SOURCE_COUNT=1124;
    const EXPECTED_ASSIGNABLE_COUNT=779;

    public static function load($override=null) {
        if ($override!==null) { return is_array($override)?$override:null; }
        return self::load_file(self::SNAPSHOT_FILE);
    }

    public static function validate($snapshot=null) {
        $snapshot=$snapshot===null?self::load():$snapshot;
        $errors=PPM679_Category_Hierarchy_Validator::validate($snapshot);
        if (!is_array($snapshot)) { return $errors; }
        $counts=(array)($snapshot['counts']??array());
        $source_hash=(string)($snapshot['complete_portal_source_file_sha256']??'');
        $actual_source_hash=self::file_hash(self::SOURCE_FILE);
        if ($source_hash==='' || !hash_equals($actual_source_hash,$source_hash)) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_CATEGORY_SOURCE_HASH','THREE_TYPE_COMPLETE_CATEGORY_SNAPSHOT_MUST_BIND_EXACT_COMPLETE_SOURCE','category_source.complete_portal_source_file_sha256',$actual_source_hash,$source_hash,'Der vollständige lokale Kategorien-Snapshot bindet nicht die exakte 1.124er-Quelle.');
        }
        if ((int)($counts['source_categories']??0)!==self::EXPECTED_SOURCE_COUNT || (int)($counts['semantic_categories']??0)!==self::EXPECTED_SOURCE_COUNT) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_CATEGORY_SOURCE_COUNT','THREE_TYPE_COMPLETE_CATEGORY_SOURCE_MUST_PROJECT_ALL_1124_CATEGORIES','category_source.counts',array('source_categories'=>self::EXPECTED_SOURCE_COUNT,'semantic_categories'=>self::EXPECTED_SOURCE_COUNT),$counts,'Die vollständige Kategorienquelle wurde nicht vollständig projiziert.');
        }
        if ((int)($counts['assignable_four_type_categories']??0)!==self::EXPECTED_ASSIGNABLE_COUNT) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_CATEGORY_ASSIGNABLE_COUNT','THREE_TYPE_CATEGORY_SOURCE_ASSIGNABLE_COUNT_MUST_MATCH_DERIVATION','category_source.counts.assignable_four_type_categories',self::EXPECTED_ASSIGNABLE_COUNT,$counts['assignable_four_type_categories']??null,'Die aus den vier registrierten Beitragstypen abgeleiteten Zielkategorien stimmen nicht.');
        }
        $required=array(
            'checklisten-fuer-pferdeanhaenger-beratung'=>'Beratung',
            'checklisten-fuer-pferdeanhaenger-vergleich'=>'Vergleich',
            'gebisse-pflege'=>'Pflege',
        );
        foreach ($required as $slug=>$type) {
            $matches=PPM679_Category_Hierarchy_Validator::find_by_slug($snapshot,$slug,'category');
            if (count($matches)!==1 || ($matches[0]['assignable']??false)!==true || !in_array($type,(array)($matches[0]['allowed_article_types']??array()),true)) {
                $errors[]=self::err('BLOCKED_THREE_TYPE_CATEGORY_TARGET_MISSING','EACH_APPROVED_THREE_TYPE_TARGET_MUST_EXIST_ONCE_AND_MATCH_TYPE','category_source.targets.'.$slug,array('count'=>1,'assignable'=>true,'article_type'=>$type),$matches,'Eine Zielkategorie des Drei-Typ-Blocks fehlt oder ist nicht eindeutig typgebunden.');
            }
        }
        return $errors;
    }

    private static function load_file($relative) {
        $file=PPM679_PLUGIN_DIR.$relative;
        $decoded=is_file($file)?json_decode((string)file_get_contents($file),true):null;
        return is_array($decoded)?$decoded:null;
    }
    private static function file_hash($relative) {
        $file=PPM679_PLUGIN_DIR.$relative;
        return is_file($file)?hash_file('sha256',$file):'';
    }
    private static function err($code,$rule,$path,$expected,$actual,$reason) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'three_type_complete_category_source','',__CLASS__,null,array(self::SNAPSHOT_FILE,self::SOURCE_FILE));
    }
}
