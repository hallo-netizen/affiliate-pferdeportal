<?php
require_once __DIR__.'/fixture-builder.php';
PPM679_WP::reset_test_state();
$id=PPM679_WP::insert_draft('Bypass','<p>Bypass</p>','bypass',array('_ppm679_publish_blocked'=>'1'),array(27));
ppm_test_assert((int)$id===0,'direct write without one-use authorization blocked');
ppm_test_assert(count(PPM679_WP::test_posts())===0,'no post');
ppm_test_assert((PPM679_WP::last_write_block()['status']??'')==='BLOCKED_QF03_WRITE_AUTHORIZATION_REQUIRED','chokepoint status');
echo json_encode(array('status'=>'PASS_V31_SINGLE_WRITE_CHOKEPOINT','direct_bypass_blocked'=>true),JSON_UNESCAPED_SLASHES)."\n";
