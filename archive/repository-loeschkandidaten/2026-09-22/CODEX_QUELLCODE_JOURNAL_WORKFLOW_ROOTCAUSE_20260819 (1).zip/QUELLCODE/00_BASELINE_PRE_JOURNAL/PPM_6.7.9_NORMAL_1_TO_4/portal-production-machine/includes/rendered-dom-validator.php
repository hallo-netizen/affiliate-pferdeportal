<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Rendered_DOM_Validator {
    const VERSION='6.7.9';

    private static function error($code,$rule,$path,$expected,$actual,$reason) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'qf03_rendered_dom','',__CLASS__,null,array('contracts/qf03-wordpress-draft-readback-dom-v1.json'));
    }
    private static function normalize_text($html) {
        $text=html_entity_decode(strip_tags((string)$html),ENT_QUOTES|ENT_HTML5,'UTF-8');
        $text=preg_replace('/\s+/u',' ',trim((string)$text));
        return function_exists('mb_strtolower')?mb_strtolower($text,'UTF-8'):strtolower($text);
    }
    private static function visible_html($html) {
        $html=preg_replace('~<!--.*?-->~s','',(string)$html);
        $html=preg_replace('~<(script|style|noscript|template)\b[^>]*>.*?</\1>~is','',$html);
        for ($i=0;$i<5;$i++) {
            $next=preg_replace('~<([a-z0-9]+)\b[^>]*(?:\shidden(?:\s|=|>)|aria-hidden\s*=\s*["\']?true|style\s*=\s*["\'][^"\']*(?:display\s*:\s*none|visibility\s*:\s*hidden))[^>]*>.*?</\1>~is','',$html);
            if ($next===$html) { break; } $html=$next;
        }
        return $html;
    }
    private static function analyze_html($html) {
        $html=self::visible_html($html); $headings=array();
        if (preg_match_all('~<h([1-6])\b[^>]*>(.*?)</h\1>~is',$html,$matches,PREG_OFFSET_CAPTURE)) {
            foreach ($matches[0] as $i=>$full) {
                $headings[]=array('level'=>(int)$matches[1][$i][0],'text'=>self::normalize_text($matches[2][$i][0]),'start'=>(int)$full[1],'end'=>(int)$full[1]+strlen($full[0]));
            }
        }
        $h1=array_values(array_filter($headings,function($h){return $h['level']===1;}));
        $seen=array(); $duplicates=array();
        foreach ($headings as $h) {
            if ($h['level']===1 || $h['text']==='') { continue; }
            if (isset($seen[$h['text']])) { $duplicates[]=$h['text']; } else { $seen[$h['text']]=true; }
        }
        $adjacent=array();
        for ($i=0;$i<count($headings)-1;$i++) {
            $between=substr($html,$headings[$i]['end'],$headings[$i+1]['start']-$headings[$i]['end']);
            $text=self::normalize_text($between);
            $meaningful_tag=(bool)preg_match('~<(p|ul|ol|table|figure|img|blockquote|details|dl)\b~i',$between);
            if ($text==='' && !$meaningful_tag) { $adjacent[]=array($headings[$i]['text'],$headings[$i+1]['text']); }
        }
        return array('visible_html_hash'=>hash('sha256',$html),'headings'=>$headings,'visible_h1_count'=>count($h1),'visible_h1_texts'=>array_values(array_map(function($h){return $h['text'];},$h1)),'duplicate_headings'=>array_values(array_unique($duplicates)),'adjacent_headings_without_content'=>$adjacent,'heading_signature'=>array_values(array_map(function($h){return $h['level'].':'.$h['text'];},$headings)));
    }
    private static function validate_capture($capture,$kind,$expected) {
        $capture=is_array($capture)?$capture:array(); $expected=is_array($expected)?$expected:array(); $errors=array();
        $width=(int)($capture['viewport']['width']??0); $height=(int)($capture['viewport']['height']??0);
        if ($kind==='desktop' && $width<1024) { $errors[]=self::error('BLOCKED_QF03_DESKTOP_VIEWPORT','DESKTOP_CAPTURE_WIDTH_MUST_BE_AT_LEAST_1024','rendered_dom.desktop.viewport.width','>=1024',$width,'Die Desktop-Erfassung besitzt keine Desktop-Breite.'); }
        if ($kind==='mobile' && ($width<=0 || $width>767)) { $errors[]=self::error('BLOCKED_QF03_MOBILE_VIEWPORT','MOBILE_CAPTURE_WIDTH_MUST_BE_AT_MOST_767','rendered_dom.mobile.viewport.width','1..767',$width,'Die Mobil-Erfassung besitzt keine Mobilbreite.'); }
        if ($height<=0 || trim((string)($capture['user_agent']??''))==='' || trim((string)($capture['capture_url']??''))==='') { $errors[]=self::error('BLOCKED_QF03_CAPTURE_CONTEXT_INCOMPLETE','RENDERED_CAPTURE_REQUIRES_VIEWPORT_USER_AGENT_AND_URL','rendered_dom.'.$kind.'.context','complete',array('width'=>$width,'height'=>$height,'user_agent'=>$capture['user_agent']??null,'capture_url'=>$capture['capture_url']??null),'Der Erfassungskontext ist unvollständig.'); }
        if (trim((string)($capture['server_instance_id']??''))==='' || trim((string)($capture['request_id']??''))==='' || trim((string)($capture['artifact_id']??''))==='' || trim((string)($capture['captured_at']??''))==='') { $errors[]=self::error('BLOCKED_QF03_RENDERED_PROVENANCE_INCOMPLETE','RENDERED_CAPTURE_REQUIRES_INSTANCE_REQUEST_ARTIFACT_AND_TIMESTAMP','rendered_dom.'.$kind.'.provenance','complete',array('server_instance_id'=>$capture['server_instance_id']??null,'request_id'=>$capture['request_id']??null,'artifact_id'=>$capture['artifact_id']??null,'captured_at'=>$capture['captured_at']??null),'Die Render-Erfassung besitzt keine vollständige Herkunftsbindung.'); }
        if (($capture['evidence_class']??'')!=='SERVER_USER_TRIGGERED_TEST' || ($capture['capture_source']??'')!=='HTTP_RESPONSE_AFTER_WORDPRESS_RENDER') { $errors[]=self::error('BLOCKED_QF03_RENDERED_EVIDENCE_CLASS','RENDERED_DOM_PASS_REQUIRES_REAL_SERVER_RENDER_EVIDENCE','rendered_dom.'.$kind.'.evidence',array('evidence_class'=>'SERVER_USER_TRIGGERED_TEST','capture_source'=>'HTTP_RESPONSE_AFTER_WORDPRESS_RENDER'),array('evidence_class'=>$capture['evidence_class']??null,'capture_source'=>$capture['capture_source']??null),'Ein lokaler Body-Check darf keinen gerenderten WordPress-DOM-PASS ersetzen.'); }
        $html=(string)($capture['html']??''); $analysis=self::analyze_html($html); $provided_hash=(string)($capture['html_sha256']??'');
        if ($html==='' || $provided_hash==='' || !hash_equals(hash('sha256',$html),$provided_hash)) { $errors[]=self::error('BLOCKED_QF03_RENDERED_HTML_HASH','RENDERED_HTML_HASH_MUST_MATCH_RAW_CAPTURE','rendered_dom.'.$kind.'.html_sha256',hash('sha256',$html),$provided_hash,'Die rohe DOM-Erfassung ist nicht hashgebunden.'); }
        if ($analysis['visible_h1_count']!==1) { $errors[]=self::error('BLOCKED_QF03_RENDERED_H1_COUNT','RENDERED_VISIBLE_H1_COUNT_MUST_EQUAL_ONE','rendered_dom.'.$kind.'.visible_h1_count',1,$analysis['visible_h1_count'],'Theme und Inhalt ergeben nicht exakt eine sichtbare H1.'); }
        $expected_title=self::normalize_text((string)($expected['title']??''));
        if ($expected_title==='' || $analysis['visible_h1_texts']!==array($expected_title)) { $errors[]=self::error('BLOCKED_QF03_RENDERED_TITLE_BINDING','THEME_H1_MUST_EQUAL_WORDPRESS_TITLE_EXACTLY','rendered_dom.'.$kind.'.visible_h1_texts',array($expected_title),$analysis['visible_h1_texts'],'Die sichtbare Theme-H1 entspricht nicht exakt dem WordPress-Titel.'); }
        $title_occurrences=0; foreach($analysis['headings'] as $heading){ if(($heading['text']??'')===$expected_title){$title_occurrences++;} }
        if ($expected_title!=='' && $title_occurrences!==1) { $errors[]=self::error('BLOCKED_QF03_RENDERED_THEME_CONTENT_TITLE_DUPLICATION','WORDPRESS_TITLE_MUST_APPEAR_ONCE_AS_THEME_H1_ONLY','rendered_dom.'.$kind.'.title_heading_occurrences',1,$title_occurrences,'Der WordPress-Titel erscheint zusätzlich als Inhaltsüberschrift oder fehlt.'); }
        if (count($analysis['duplicate_headings'])!==0) { $errors[]=self::error('BLOCKED_QF03_RENDERED_DUPLICATE_HEADINGS','RENDERED_DUPLICATE_HEADINGS_MUST_EQUAL_ZERO','rendered_dom.'.$kind.'.duplicate_headings',array(),$analysis['duplicate_headings'],'Im gerenderten DOM erscheinen doppelte Zwischenüberschriften.'); }
        if (count($analysis['adjacent_headings_without_content'])!==0) { $errors[]=self::error('BLOCKED_QF03_RENDERED_ADJACENT_HEADINGS','RENDERED_ADJACENT_HEADINGS_WITHOUT_CONTENT_MUST_EQUAL_ZERO','rendered_dom.'.$kind.'.adjacent_headings_without_content',array(),$analysis['adjacent_headings_without_content'],'Im gerenderten DOM stehen Überschriften ohne sinnvollen Inhalt direkt aufeinander.'); }
        if ((int)($capture['post_id']??0)!==(int)($expected['post_id']??0) || (string)($capture['stored_content_hash']??'')!== (string)($expected['readback_content_hash']??'')) { $errors[]=self::error('BLOCKED_QF03_RENDERED_READBACK_BINDING','RENDERED_CAPTURE_MUST_BIND_TO_EXACT_POST_AND_READBACK_HASH','rendered_dom.'.$kind.'.binding',array('post_id'=>$expected['post_id']??null,'stored_content_hash'=>$expected['readback_content_hash']??null),array('post_id'=>$capture['post_id']??null,'stored_content_hash'=>$capture['stored_content_hash']??null),'Die DOM-Erfassung ist nicht an den exakt zurückgelesenen Draft gebunden.'); }
        if (array_key_exists('table_style_evidence',$capture) || (($expected['table_hard_rule_evidence_required']??false)===true)) { $errors=array_merge($errors,PPM679_Table_Hard_Rule_Validator::validate_computed_evidence($capture['table_style_evidence']??null,'qf03_rendered_table_'.$kind)); }
        return array('ok'=>!$errors,'errors'=>$errors,'analysis'=>$analysis,'capture_evidence'=>array('kind'=>$kind,'post_id'=>(int)($capture['post_id']??0),'viewport'=>array('width'=>$width,'height'=>$height),'user_agent'=>(string)($capture['user_agent']??''),'capture_url'=>(string)($capture['capture_url']??''),'captured_at'=>(string)($capture['captured_at']??''),'server_instance_id'=>(string)($capture['server_instance_id']??''),'request_id'=>(string)($capture['request_id']??''),'artifact_id'=>(string)($capture['artifact_id']??''),'raw_html_sha256'=>hash('sha256',$html),'provided_html_sha256'=>$provided_hash,'evidence_class'=>$capture['evidence_class']??null,'capture_source'=>$capture['capture_source']??null));
    }
    public static function validate_pair($desktop,$mobile,$expected) {
        $d=self::validate_capture($desktop,'desktop',$expected); $m=self::validate_capture($mobile,'mobile',$expected); $errors=array_merge($d['errors'],$m['errors']);
        if ($d['analysis']['heading_signature']!==$m['analysis']['heading_signature']) { $errors[]=self::error('BLOCKED_QF03_DESKTOP_MOBILE_STRUCTURE_MISMATCH','DESKTOP_AND_MOBILE_VISIBLE_HEADING_STRUCTURE_MUST_MATCH','rendered_dom.heading_signatures',$d['analysis']['heading_signature'],$m['analysis']['heading_signature'],'Desktop und Mobil zeigen unterschiedliche sichtbare Überschriftenstrukturen.'); }
        $extra=array('desktop'=>$d['capture_evidence'],'mobile'=>$m['capture_evidence'],'desktop_analysis'=>$d['analysis'],'mobile_analysis'=>$m['analysis'],'RENDERED_VISIBLE_H1_COUNT'=>array('desktop'=>$d['analysis']['visible_h1_count'],'mobile'=>$m['analysis']['visible_h1_count']),'RENDERED_DUPLICATE_HEADINGS'=>array('desktop'=>count($d['analysis']['duplicate_headings']),'mobile'=>count($m['analysis']['duplicate_headings'])),'RENDERED_ADJACENT_HEADINGS_WITHOUT_CONTENT'=>array('desktop'=>count($d['analysis']['adjacent_headings_without_content']),'mobile'=>count($m['analysis']['adjacent_headings_without_content'])),'user_visual_inspection_status'=>'REQUIRED_NOT_YET_COMPLETED','publish_allowed'=>false);
        if ($errors) { return array('ok'=>false,'RENDERED_DOM_STATUS'=>'BLOCKED','report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'qf03_rendered_dom','',$extra)); }
        return array('ok'=>true,'RENDERED_DOM_STATUS'=>'PASS','report'=>PPM679_Diagnostic::ok('QF03_RENDERED_DESKTOP_MOBILE_DOM_PASS','qf03_rendered_dom','',array_merge($extra,array('RENDERED_DOM_STATUS'=>'PASS','evidence_class'=>'SERVER_USER_TRIGGERED_TEST','final_user_acceptance_claimed'=>false))));
    }

    public static function build_capture_request_set($post_id,$capture_url,$readback_content_hash) {
        $post_id=(int)$post_id; $capture_url=trim((string)$capture_url); $readback_content_hash=trim((string)$readback_content_hash);
        if($post_id<=0 || $capture_url==='' || !preg_match('/^[a-f0-9]{64}$/',$readback_content_hash)){
            $error=self::error('BLOCKED_QF03_CAPTURE_REQUEST_INPUT','CAPTURE_REQUEST_REQUIRES_POST_URL_AND_READBACK_HASH','rendered_dom.capture_request',array('post_id'=>'>0','capture_url'=>'non-empty','readback_content_hash'=>'sha256'),array('post_id'=>$post_id,'capture_url'=>$capture_url,'readback_content_hash'=>$readback_content_hash),'Der spätere Render-Auftrag ist nicht vollständig an Draft und Readback gebunden.');
            return array('ok'=>false,'capture_executed'=>false,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'qf03_capture_request'));
        }
        $common=array('post_id'=>$post_id,'capture_url'=>$capture_url,'stored_content_hash'=>$readback_content_hash,'required_evidence_class'=>'SERVER_USER_TRIGGERED_TEST','required_capture_source'=>'HTTP_RESPONSE_AFTER_WORDPRESS_RENDER','capture_executed'=>false);
        return array('ok'=>true,'capture_executed'=>false,'status'=>'CAPTURE_REQUESTS_PREPARED_NOT_EXECUTED','desktop'=>array_merge($common,array('viewport'=>array('width'=>1440,'height'=>1200),'user_agent_profile'=>'QF03_DESKTOP_CHROMIUM')),'mobile'=>array_merge($common,array('viewport'=>array('width'=>390,'height'=>844),'user_agent_profile'=>'QF03_MOBILE_CHROMIUM')),'user_visual_inspection_required_after_machine_dom'=>true,'publish_allowed'=>false);
    }

}
