<?php
require_once __DIR__.'/fixture-builder.php';require_once dirname(__DIR__).'/v3-stateful-e2e/fixture-builder.php';
PPM679_WP::reset_test_state();PPM679_Storage::reset_test_state();$c=v31_contract()['candidate'];unset($c['category_assignment']);
$id=PPM679_Stateful_Write_Gate::build_identity('canonical-faq-001','ppm-test-instance-679',v31_build_hash(),'g9-request-v34-write-unbound');
$g=v31_gate(hash('sha256',$c['content_html']),$id['identity']['request_id']);
$r=PPM679_Stateful_Write_Gate::prepare_single_faq_plan($c,$g,$id['identity'],v31_quality_hash());
ppm_test_assert(empty($r['ok']),'write without category assignment must block');
echo "PASS_V34_WRITE_UNBOUND_BLOCKED\n";
