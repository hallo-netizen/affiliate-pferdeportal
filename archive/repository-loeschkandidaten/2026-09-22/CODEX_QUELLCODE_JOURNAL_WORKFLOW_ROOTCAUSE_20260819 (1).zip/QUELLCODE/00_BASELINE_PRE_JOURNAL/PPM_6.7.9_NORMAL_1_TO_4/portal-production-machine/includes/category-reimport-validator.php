<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Category_Reimport_Validator {
    public static function compare($old,$new){
        $old=self::index($old);$new=self::index($new);$errors=array();$changes=array();
        $slug_owner=array();foreach($new as $id=>$c){$slug=(string)($c['category_slug']??$c['slug']??'');if($slug===''||isset($slug_owner[$slug])){$errors[]=self::err('BLOCKED_CATEGORY_REIMPORT_SLUG_COLLISION','NEW_CATEGORY_SNAPSHOT_MUST_HAVE_UNIQUE_SLUGS','new.'.$id.'.slug','unique non-empty slug',$slug,'Der Kategorien-Nachimport enthält eine Slug-Kollision.');}$slug_owner[$slug]=$id;}
        foreach($new as $id=>$c){if(!isset($old[$id])){$changes[]=array('change_type'=>'ADD','stable_category_id'=>$id,'new'=>$c,'status'=>'REGISTERED_PENDING_RESEARCH_AND_OWNERSHIP_REVIEW');continue;}$before=$old[$id];$fields=array('category_name','name','category_slug','slug','portal_path','content_block','allowed_article_types','active');$diff=array();foreach($fields as $f){if(array_key_exists($f,$before)||array_key_exists($f,$c)){if(($before[$f]??null)!==($c[$f]??null)){$diff[$f]=array('old'=>$before[$f]??null,'new'=>$c[$f]??null);}}}if($diff){$type=(isset($diff['category_name'])||isset($diff['name'])||isset($diff['category_slug'])||isset($diff['slug']))?'RENAME_PROPOSAL':((isset($diff['portal_path'])||isset($diff['content_block']))?'MOVE_PROPOSAL':'DEACTIVATE_PROPOSAL');$changes[]=array('change_type'=>$type,'stable_category_id'=>$id,'diff'=>$diff,'status'=>'BLOCKED_PENDING_EXPLICIT_APPROVAL');}}
        foreach($old as $id=>$c){if(!isset($new[$id])){$changes[]=array('change_type'=>'DEACTIVATE_PROPOSAL','stable_category_id'=>$id,'old'=>$c,'status'=>'BLOCKED_PENDING_EXPLICIT_APPROVAL');}}
        if($errors){return array('ok'=>false,'status'=>$errors[0]['error_code'],'errors'=>$errors,'changes'=>$changes,'wordpress_write_performed'=>false);}
        return array('ok'=>true,'status'=>'CATEGORY_REIMPORT_DIFF_GENERATED_NO_WRITE','errors'=>array(),'changes'=>$changes,'automatic_applied_changes'=>array(),'wordpress_write_performed'=>false);
    }
    private static function index($list){$out=array();foreach((array)$list as $c){$id=(string)($c['stable_category_id']??$c['stable_category_key']??'');if($id!==''){$out[$id]=$c;}}return $out;}
    private static function err($code,$rule,$path,$expected,$actual,$reason){return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'category_reimport','',__CLASS__,null,array(PPM679_Editorial_Plan_Registry::REIMPORT));}
}
