<?php
require_once __DIR__.'/fixture-builder.php';
PPM679_WP::reset_test_state();PPM679_Storage::reset_test_state();v31_seed_old_10277();
$a=v31_execute_g9('g9-request-v31-new-run-a-0006');ppm_test_assert($a['ok']===true,'run a');
PPM679_Stateful_Write_Gate::reset_test_state();
$b=v31_execute_g9('g9-request-v31-new-run-b-0006');ppm_test_assert($b['ok']===true,'run b');
ppm_test_assert($a['run_identity']['run_marker']!==$b['run_identity']['run_marker'],'run markers differ');
ppm_test_assert($a['run_identity']['canonical_article_id']===$b['run_identity']['canonical_article_id'],'canonical identity stable');
ppm_test_assert($a['post_id']!==$b['post_id'],'persistence identity differs');
echo json_encode(array('status'=>'PASS_V31_S06_NEW_AUTHORIZED_RUN','markers'=>array($a['run_identity']['run_marker'],$b['run_identity']['run_marker']),'post_ids'=>array($a['post_id'],$b['post_id'])),JSON_UNESCAPED_SLASHES)."\n";
