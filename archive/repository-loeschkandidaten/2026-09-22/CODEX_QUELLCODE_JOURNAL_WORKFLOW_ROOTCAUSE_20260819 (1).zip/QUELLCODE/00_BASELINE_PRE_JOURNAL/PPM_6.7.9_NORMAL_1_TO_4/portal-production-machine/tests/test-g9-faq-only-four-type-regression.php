<?php
require_once __DIR__.'/bootstrap-test.php';
$root=dirname(__DIR__);
$article=file_get_contents($root.'/includes/article-type-validator.php');
$plan=file_get_contents($root.'/includes/plan-validator.php');
$pipeline=file_get_contents($root.'/includes/pipeline.php');
$g9=file_get_contents($root.'/includes/g9-single-faq-entrypoint.php');
$live=file_get_contents($root.'/includes/live-state-gate.php');
ppm_test_assert(substr_count($article,'foreach (self::REQUIRED_TYPES')===1,'global validator four-type loop must remain');
ppm_test_assert(strpos($plan,'count($items)<1 || count($items)>4')!==false,'production plan count rule must remain 1..4');
ppm_test_assert(strpos($g9,"'article_type_release_scope'=>PPM679_G9_FAQ_Test_Release_Validator::expected_scope()")!==false,'G9 must request explicit FAQ scope');
ppm_test_assert(strpos($live,'PPM679_Article_Type_Validator::validate($action_context,$hash)')!==false,'default live-state branch must retain global validator');
ppm_test_assert(strpos($live,"PPM679_G9_FAQ_Test_Release_Validator::validate")!==false,'explicit G9 branch must use targeted validator');
ppm_test_assert(strpos($pipeline,'PPM679_Plan_Validator::validate')!==false,'four-type production pipeline must retain plan validator');
echo json_encode(array(
 'status'=>'PASS_G9_FAQ_ONLY_FOUR_TYPE_REGRESSION',
 'production_plan_cardinality'=>'1..4',
 'global_article_type_validator_modified_or_weakened'=>false,
 'content_quality_pipeline_modified'=>false,
 'g9_scope_explicit'=>true,
 'publish_allowed'=>false
),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n";
