<?php
require_once dirname(__DIR__).'/bootstrap-test.php';
function tt_release(){return PPM679_Three_Type_Live_Test_Release_Validator::load();}
function tt_inventory(){return PPM679_Three_Type_Live_Test_Release_Validator::load(PPM679_Three_Type_Live_Test_Release_Validator::INVENTORY_FILE);}
function tt_seed_current_state(){
 PPM679_WP::reset_test_state(); PPM679_Storage::reset_test_state();
 $inv=tt_inventory();$terms=array();$next=3000;
 foreach((array)$inv['items'] as $row){$name=(string)$row['category'];if(!isset($terms[$name])){$slug=PPM679_WP::sanitize_title($name);$id=++$next;$terms[$name]=$id;PPM679_WP::seed_test_term(array('term_id'=>$id,'name'=>$name,'slug'=>$slug,'taxonomy'=>'category','parent'=>0,'parent_chain_slugs'=>array(),'parent_chain_names'=>array(),'taxonomy_depth'=>1,'hierarchy_path'=>$name,'fixture_class'=>'USER_SUPPLIED_ROLLBACK_INVENTORY'));}}
 foreach((array)$inv['items'] as $row){PPM679_WP::seed_test_post(array('ID'=>(int)$row['post_id'],'post_title'=>(string)$row['title'],'post_content'=>'historical','post_name'=>'historical-'.(int)$row['post_id'],'post_status'=>(string)$row['status'],'post_type'=>'post','meta'=>array(),'category_ids'=>array($terms[(string)$row['category']])));}
 $targets=array(array(4101,'Beratung Checklisten für Pferdeanhänger','checklisten-fuer-pferdeanhaenger-beratung'),array(4102,'Vergleich Checklisten für Pferdeanhänger','checklisten-fuer-pferdeanhaenger-vergleich'),array(4103,'Pflege Gebisse','gebisse-pflege'));
 foreach($targets as $x){PPM679_WP::seed_test_term(array('term_id'=>$x[0],'name'=>$x[1],'slug'=>$x[2],'taxonomy'=>'category','parent'=>0,'parent_chain_slugs'=>array(),'parent_chain_names'=>array(),'taxonomy_depth'=>1,'hierarchy_path'=>$x[1],'fixture_class'=>'READ_ONLY_RUNTIME_SIMULATION'));}
}
function tt_context(){return array('user_triggered'=>true,'nonce_verified'=>true,'current_user_can_manage'=>true,'simulation_only'=>true,'evidence_class'=>'LOCAL_EXECUTED_TEST');}
function tt_codes($errors){return array_values(array_unique(array_map(fn($e)=>(string)($e['error_code']??''),(array)$errors)));}
