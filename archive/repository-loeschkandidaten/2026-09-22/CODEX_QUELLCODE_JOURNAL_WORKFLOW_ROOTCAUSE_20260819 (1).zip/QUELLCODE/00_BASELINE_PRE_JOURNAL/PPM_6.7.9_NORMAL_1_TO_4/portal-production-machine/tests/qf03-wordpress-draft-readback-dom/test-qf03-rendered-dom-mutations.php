<?php
require_once dirname(__DIR__).'/bootstrap-test.php'; require_once __DIR__.'/fixture-builder.php';
$hash=hash('sha256',qf03_article_html()); $e=array('title'=>'Was muss vor einer Fahrt geprüft werden?','post_id'=>101,'readback_content_hash'=>$hash); $d=qf03_capture_fixture('desktop',101,$hash); $m=qf03_capture_fixture('mobile',101,$hash);
$cases=array();
$x=$d; $x['html']=str_replace('<h1>Was muss vor einer Fahrt geprüft werden?</h1>','',$x['html']); $x['html_sha256']=hash('sha256',$x['html']); $cases['zero_h1']=array($x,$m);
$x=$d; $x['html']=str_replace('</h1>','</h1><h1>Was muss vor einer Fahrt geprüft werden?</h1>',$x['html']); $x['html_sha256']=hash('sha256',$x['html']); $cases['two_h1']=array($x,$m);
$x=$d; $x['html']=str_replace('</article>','<h2>Gewichte und Fahrzeuggrenzen prüfen</h2><p>Wiederholt.</p></article>',$x['html']); $x['html_sha256']=hash('sha256',$x['html']); $cases['duplicate_heading']=array($x,$m);
$x=$d; $x['html']=str_replace('</article>','<h2>Was muss vor einer Fahrt geprüft werden?</h2><p>Wiederholter Titel.</p></article>',$x['html']); $x['html_sha256']=hash('sha256',$x['html']); $cases['theme_content_title_duplicate']=array($x,$m);
$x=$d; $x['html']=str_replace('</h1><p>','</h1><h2>Leere Überschrift</h2><h2>Zweite Überschrift</h2><p>',$x['html']); $x['html_sha256']=hash('sha256',$x['html']); $cases['adjacent_headings']=array($x,$m);
$x=$m; $x['viewport']['width']=1024; $cases['wrong_mobile_viewport']=array($d,$x);
$x=$d; $x['evidence_class']='LOCAL_EXECUTED_TEST'; $cases['local_evidence']=array($x,$m);
$x=$d; $x['stored_content_hash']=str_repeat('b',64); $cases['readback_binding']=array($x,$m);
$out=array(); foreach($cases as $name=>$pair){ $r=PPM679_Rendered_DOM_Validator::validate_pair($pair[0],$pair[1],$e); ppm_test_assert($r['ok']===false,$name.' must block'); $out[$name]=$r['report']['status']; }
echo json_encode(array('status'=>'PASS','blocked_mutations'=>$out),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
