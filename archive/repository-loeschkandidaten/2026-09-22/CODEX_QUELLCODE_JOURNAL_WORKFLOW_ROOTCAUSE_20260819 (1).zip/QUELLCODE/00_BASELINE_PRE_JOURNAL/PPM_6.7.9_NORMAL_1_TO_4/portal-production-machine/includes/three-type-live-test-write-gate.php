<?php
if (!defined('ABSPATH')) { return; }
final class PPM679_Three_Type_Live_Test_Write_Gate {
 const VERSION='6.7.9';
 private static $requests=array(); private static $markers=array();
 private static function norm($v){$v=function_exists('mb_strtolower')?mb_strtolower((string)$v,'UTF-8'):strtolower((string)$v);$v=strtr($v,array('ä'=>'a','ö'=>'o','ü'=>'u','ß'=>'ss'));$v=preg_replace('/[^a-z0-9]+/u',' ',strip_tags($v));return trim((string)preg_replace('/\s+/',' ',$v));}
 private static function err($code,$path,$expected,$actual,$reason){return PPM679_Diagnostic::error($code,'THREE_TYPE_LIVE_TEST_WRITE_GATE_MUST_FAIL_CLOSED',$path,$expected,$actual,$reason,'three_type_live_test_write_gate','',__CLASS__);}
 public static function verify_inventory($actual,$contract){
  $e=array();$want=(array)($contract['items']??array());$map=function($rows){$o=array();foreach((array)$rows as $r){$o[(int)($r['post_id']??0)]=array('post_id'=>(int)($r['post_id']??0),'title'=>(string)($r['title']??''),'status'=>(string)($r['status']??''),'category'=>(string)($r['category']??$r['category_name']??''));}ksort($o,SORT_NUMERIC);return $o;};$w=$map($want);$a=$map($actual);
  if(PPM679_Diagnostic::stable_hash($w)!==PPM679_Diagnostic::stable_hash($a))$e[]=self::err('BLOCKED_THREE_TYPE_LIVE_INVENTORY_MISMATCH','wordpress_inventory',$w,$a,'Der reale WordPress-Bestand weicht vom bestätigten 32-Objekte-Istbestand ab.');
  return $e;
 }
 public static function resolve_category($binding){
  $matches=PPM679_WP::find_category_terms_by_slug((string)($binding['slug']??''),(string)($binding['taxonomy']??'category'));
  if(count($matches)!==1){$code=count($matches)>1?'BLOCKED_THREE_TYPE_CATEGORY_AMBIGUOUS':'BLOCKED_THREE_TYPE_CATEGORY_MISSING';return array('ok'=>false,'errors'=>array(self::err($code,'category.matches',1,count($matches),'Die Zielkategorie ist live nicht eindeutig auflösbar.')));}
  $t=$matches[0];$e=array();foreach(array('name','slug','taxonomy') as $f){if((string)($t[$f]??'')!==(string)($binding[$f]??''))$e[]=self::err('BLOCKED_THREE_TYPE_CATEGORY_IDENTITY','category.'.$f,$binding[$f]??null,$t[$f]??null,'Die Kategorieidentität weicht ab.');}
  $parents=array_values((array)($t['parent_chain_slugs']??array()));if($parents!==array_values((array)($binding['expected_wp_parent_slugs']??array())))$e[]=self::err('BLOCKED_THREE_TYPE_CATEGORY_PARENT','category.parent_chain_slugs',$binding['expected_wp_parent_slugs']??array(),$parents,'Die WordPress-Elternkette weicht ab.');
  if((int)($t['taxonomy_depth']??0)!==(int)($binding['expected_wp_taxonomy_depth']??0))$e[]=self::err('BLOCKED_THREE_TYPE_CATEGORY_DEPTH','category.taxonomy_depth',$binding['expected_wp_taxonomy_depth']??null,$t['taxonomy_depth']??null,'Die WordPress-Taxonomietiefe weicht ab.');
  return $e?array('ok'=>false,'errors'=>$e):array('ok'=>true,'term'=>$t);
 }
 public static function build_identity($plan_key,$server,$manifest,$batch){
  $request='tt-request-'.substr(hash('sha256',$plan_key.'|'.$server.'|'.$manifest.'|'.$batch),0,24);$marker='TT-LIVE-'.strtoupper(substr(hash('sha256',$request.'|marker'),0,12));
  if(isset(self::$requests[$request])||isset(self::$markers[$marker]))return array('ok'=>false,'errors'=>array(self::err('BLOCKED_THREE_TYPE_IDENTITY_COLLISION','identity','unique',array($request,$marker),'Eine Laufidentität kollidiert.')));
  self::$requests[$request]=true;self::$markers[$marker]=true;return array('ok'=>true,'identity'=>array('canonical_article_id'=>$plan_key,'request_id'=>$request,'run_marker'=>$marker,'server_instance_id'=>$server,'build_manifest_sha256'=>$manifest,'batch_id'=>$batch));
 }
 public static function prepare_plan($candidate,$category,$identity,$batch){
  $e=array();$allowed=array_values(array_map('intval',(array)($candidate['allowed_historical_technical_trash_ids']??array())));$same=array();foreach(PPM679_WP::get_all_post_inventory(array('publish','draft','trash')) as $p){if(self::norm($p['title']??'')===self::norm($candidate['title']??''))$same[]=$p;}
  foreach($same as $p){if(($p['status']??'')!=='trash'||!in_array((int)$p['post_id'],$allowed,true))$e[]=self::err('BLOCKED_THREE_TYPE_FOREIGN_TITLE_COLLISION','collision.title','only bound technical trash IDs',$p,'Ein fremder Titelkonflikt blockiert den gesamten Drei-Typ-Lauf.');}
  $slug=(string)$candidate['base_slug'].'-lt-'.strtolower((string)$candidate['article_type']).'-'.substr(hash('sha256',$batch.'|'.$identity['request_id']),0,8);
  if(PPM679_WP::find_posts_by_slug($slug))$e[]=self::err('BLOCKED_THREE_TYPE_SLUG_COLLISION','collision.slug','unused',$slug,'Der abgeleitete Testslug ist bereits belegt.');
  $bundle=PPM679_Three_Type_Live_Test_Release_Validator::load(PPM679_Three_Type_Live_Test_Release_Validator::CANDIDATE_FILE);$source=null;foreach((array)($bundle['items']??array()) as $i){if(($i['article_type']??'')===($candidate['article_type']??'')){$source=$i;break;}}
  if(!is_array($source))$e[]=self::err('BLOCKED_THREE_TYPE_CANDIDATE_MISSING','candidate','exact approved item',$candidate['article_type']??null,'Der bestätigte Kandidat fehlt.');
  $body=(string)($source['canonical_article']['body_html']??'');if(hash('sha256',$body)!==(string)($candidate['body_html_sha256']??''))$e[]=self::err('BLOCKED_THREE_TYPE_BODY_HASH','candidate.body_html_sha256',$candidate['body_html_sha256']??null,hash('sha256',$body),'Der Artikeltext ist nicht byteidentisch.');
  $meta=array('_ppm679_three_type_live_test'=>'1','_ppm679_article_type'=>(string)$candidate['article_type'],'_ppm679_canonical_article_id'=>(string)$candidate['plan_item_key'],'_ppm679_request_id'=>(string)$identity['request_id'],'_ppm679_run_id'=>(string)$identity['request_id'],'_ppm679_test_marker'=>(string)$identity['run_marker'],'_ppm679_batch_id'=>(string)$batch,'_ppm679_body_sha256'=>(string)$candidate['body_html_sha256'],'_ppm679_quality_binding_sha256'=>(string)$candidate['quality_binding_sha256'],'_ppm679_publish_allowed'=>'0','_ppm679_counts_as_production_coverage'=>'0','_ppm679_dom_evidence_status'=>'PENDING_DESKTOP_MOBILE_CAPTURE');
  $payload=array('title'=>(string)$candidate['title'],'content'=>$body,'slug'=>$slug,'meta'=>$meta,'categories'=>array((int)$category['term_id']));$fingerprint=PPM679_Diagnostic::stable_hash(array('payload'=>$payload,'identity'=>$identity,'batch'=>$batch));$payload['meta']['_ppm679_planned_write_fingerprint']=$fingerprint;
  return $e?array('ok'=>false,'errors'=>$e):array('ok'=>true,'article_type'=>$candidate['article_type'],'identity'=>$identity,'payload'=>$payload,'planned_write_fingerprint'=>$fingerprint,'category'=>$category,'dry_run_complete'=>true);
 }
 public static function validate_plan($plan){if(empty($plan['ok'])||empty($plan['dry_run_complete']))return array(self::err('BLOCKED_THREE_TYPE_PLAN_INCOMPLETE','plan','complete',$plan,'Der Schreibplan ist unvollständig.'));$p=$plan['payload'];$claimed=(string)($p['meta']['_ppm679_planned_write_fingerprint']??'');unset($p['meta']['_ppm679_planned_write_fingerprint']);$actual=PPM679_Diagnostic::stable_hash(array('payload'=>$p,'identity'=>(array)($plan['identity']??array()),'batch'=>(string)($plan['identity']['batch_id']??'')));return $claimed===(string)$plan['planned_write_fingerprint']&&hash_equals($claimed,$actual)?array():array(self::err('BLOCKED_THREE_TYPE_PLAN_FINGERPRINT','plan.fingerprint',$actual,array('meta'=>$claimed,'plan'=>$plan['planned_write_fingerprint']??null),'Der Schreibfingerprint weicht ab.'));}
 public static function reset_test_state(){self::$requests=array();self::$markers=array();}
}
