<?php
if (!defined('ABSPATH')) { return; }

/**
 * Code-structure gate for the category semantic deriver.
 * Uses token_get_all plus Reflection and a complete include-tree callsite scan.
 */
final class PPM679_Category_Structure_Inspector {
    const VERSION='6.7.9';
    const DERIVER_FILE='includes/independent-semantic-category-deriver.php';
    const ORCHESTRATOR_FILE='includes/g9-single-faq-entrypoint.php';

    public static function inspect($deriver_override=null,$callsite_overrides=null,$orchestrator_override=null){
        $errors=array();
        $allow_override=PPM679_WP::is_test_mode();
        if(($deriver_override!==null||$callsite_overrides!==null||$orchestrator_override!==null)&&!$allow_override){
            return array('errors'=>array(self::err('BLOCKED_CATEGORY_SEMANTIC_CALLSITE_UNVERIFIED','STRUCTURE_SOURCE_OVERRIDE_ALLOWED_ONLY_IN_LOCAL_TEST_MODE','category_structure.override','none','provided','Ein Strukturquellen-Override ist außerhalb lokaler Tests verboten.')),'evidence'=>array());
        }
        $deriver=$deriver_override!==null?(string)$deriver_override:self::read(self::DERIVER_FILE);
        $orchestrator=$orchestrator_override!==null?(string)$orchestrator_override:self::read(self::ORCHESTRATOR_FILE);
        if($deriver===''){$errors[]=self::err('BLOCKED_CATEGORY_SEMANTIC_CALLSITE_UNVERIFIED','INDEPENDENT_DERIVER_SOURCE_MUST_EXIST','category_structure.deriver_file',self::DERIVER_FILE,null,'Das unabhängige Ableitungsmodul fehlt.');}

        $signature=array();
        if($deriver_override===null){
            try{$m=new ReflectionMethod('PPM679_Independent_Semantic_Category_Deriver','derive');$signature=array_map(function($p){return $p->getName();},$m->getParameters());}catch(Throwable $e){$signature=array();}
        }else{$signature=self::sourceSignature($deriver);}
        if($signature!==array('semantic_article_input','category_hierarchy_snapshot')){$errors[]=self::err('BLOCKED_CATEGORY_SEMANTIC_INTERFACE_CONTAMINATED','DERIVER_INTERFACE_MUST_ACCEPT_ONLY_SEMANTIC_INPUT_AND_HIERARCHY_SNAPSHOT','category_structure.signature',array('semantic_article_input','category_hierarchy_snapshot'),$signature,'Die Schnittstelle des unabhängigen Ableitungsmoduls ist kontaminiert.');}

        $token_report=self::tokenReport($deriver);
        foreach($token_report['forbidden_hits'] as $hit){$errors[]=self::err('BLOCKED_CATEGORY_SEMANTIC_DEPENDENCY_VIOLATION','DERIVER_MUST_NOT_ACCESS_PLAN_LIVE_WRITE_READBACK_OR_EXTERNAL_STATE','category_structure.forbidden_token','absent',$hit,'Das unabhängige Ableitungsmodul enthält einen verbotenen Zugriff.');}
        foreach($token_report['unapproved_static_dependencies'] as $hit){$errors[]=self::err('BLOCKED_CATEGORY_SEMANTIC_DEPENDENCY_VIOLATION','DERIVER_STATIC_DEPENDENCIES_MUST_BE_SELF_ONLY','category_structure.static_dependency','self only',$hit,'Das Ableitungsmodul besitzt eine nicht zugelassene Klassenabhängigkeit.');}
        foreach($token_report['unapproved_function_calls'] as $hit){$errors[]=self::err('BLOCKED_CATEGORY_SEMANTIC_DEPENDENCY_VIOLATION','DERIVER_FUNCTION_CALLS_MUST_BE_PURE_ALLOWLIST','category_structure.function_call','pure allowlist',$hit,'Das Ableitungsmodul ruft eine nicht zugelassene Funktion auf.');}

        $calls=$callsite_overrides!==null?self::overrideCallsites((array)$callsite_overrides):self::realCallsites();
        if($calls!==array('includes/category-assignment-validator.php')){$errors[]=self::err('BLOCKED_CATEGORY_SEMANTIC_CALLGRAPH_CONTAMINATED','DERIVER_MAY_HAVE_EXACTLY_ONE_INVENTORIED_CALLSITE','category_structure.callsites',array('includes/category-assignment-validator.php'),$calls,'Das Ableitungsmodul besitzt eine nicht inventarisierte Aufrufstelle.');}

        $derive_pos=strpos($orchestrator,'derive_independent(');
        $plan_pos=strpos($orchestrator,"['category_binding']");
        if($derive_pos===false||$plan_pos===false||$derive_pos>$plan_pos){$errors[]=self::err('BLOCKED_CATEGORY_SEMANTIC_DECISION_ORDER_VIOLATION','INDEPENDENT_DECISION_MUST_BE_BOUND_BEFORE_PLAN_CATEGORY_IS_LOADED','category_structure.g9_order','derive before category_binding load',array('derive_pos'=>$derive_pos,'plan_pos'=>$plan_pos),'Die Plan-Kategorie wird vor der unabhängigen Entscheidung geladen.');}

        $evidence=array(
            'contract'=>'CATEGORY_SEMANTIC_CODE_STRUCTURE_EVIDENCE_V1',
            'inspector_version'=>self::VERSION,
            'deriver_file'=>self::DERIVER_FILE,
            'deriver_sha256'=>hash('sha256',$deriver),
            'derive_parameters'=>$signature,
            'token_report'=>$token_report,
            'inventoried_callsites'=>$calls,
            'callsite_sha256'=>self::hashMap($calls),
            'orchestrator_file'=>self::ORCHESTRATOR_FILE,
            'orchestrator_sha256'=>hash('sha256',$orchestrator),
            'derive_position'=>$derive_pos,
            'plan_category_load_position'=>$plan_pos,
            'structural_separation_ok'=>!$errors,
            'absolute_completeness_claimed'=>false
        );
        $evidence['evidence_sha256']=PPM679_Diagnostic::stable_hash($evidence);
        return array('errors'=>$errors,'evidence'=>$evidence);
    }

    private static function tokenReport($source){
        $tokens=token_get_all((string)$source);$forbidden=array();$static=array();$functions=array();
        $superglobals=array('$_GET','$_POST','$_REQUEST','$_SESSION','$_COOKIE','$_SERVER','$_ENV','$GLOBALS');
        $forbidden_fragments=array('plan_category','plan_slug','plan_path','plan_term','editorial_category','live_term','resolved_term','readback_category','write_payload_category','expected_fixture_category','service_locator');
        $control=array('if','else','elseif','for','foreach','while','switch','catch','isset','empty','array','list','echo','print','include','include_once','require','require_once','eval','exit','die','return','function');
        $allowed_functions=array('defined','is_array','strtoupper','trim','implode','array_map','array_values','array_intersect','array_keys','count','min','array_unique','usort','strcmp','preg_match','strpos','in_array','sort','strtolower','strtr','preg_replace','explode','strlen','hash','json_encode','range','ksort','array_diff','array_merge');
        $n=count($tokens);
        for($i=0;$i<$n;$i++){
            $t=$tokens[$i];
            if(is_array($t)&&$t[0]===T_VARIABLE){
                if(in_array($t[1],$superglobals,true)){$forbidden[]=$t[1];}
                $lower=strtolower(ltrim($t[1],'$'));foreach($forbidden_fragments as $fragment){if(strpos($lower,$fragment)!==false){$forbidden[]=$t[1];}}
            }
            if(is_array($t)&&$t[0]===T_CONSTANT_ENCAPSED_STRING){
                $lower=strtolower(trim($t[1],"'\""));foreach($forbidden_fragments as $fragment){if(strpos($lower,$fragment)!==false){$forbidden[]=$lower;}}
            }
            if(is_array($t)&&in_array($t[0],array(T_INCLUDE,T_INCLUDE_ONCE,T_REQUIRE,T_REQUIRE_ONCE,T_EVAL,T_NEW,T_GLOBAL),true)){$forbidden[]=token_name($t[0]);}
            if(is_array($t)&&$t[0]===T_OBJECT_OPERATOR){$forbidden[]='T_OBJECT_OPERATOR';}
            if(is_array($t)&&$t[0]===T_STRING){
                $next=self::nextMeaningful($tokens,$i+1);
                if($next!==null&&self::tokenIs($tokens[$next],T_DOUBLE_COLON)){
                    $class=strtolower((string)$t[1]);if(!in_array($class,array('self','static'),true)){$static[]=$t[1];}
                }elseif($next!==null&&$tokens[$next]==='('){
                    $name=strtolower((string)$t[1]);$prev=self::prevMeaningful($tokens,$i-1);
                    $is_method=$prev!==null&&(self::tokenIs($tokens[$prev],T_OBJECT_OPERATOR)||self::tokenIs($tokens[$prev],T_DOUBLE_COLON));
                    $is_declaration=$prev!==null&&self::tokenIs($tokens[$prev],T_FUNCTION);
                    if(!$is_method&&!$is_declaration&&!in_array($name,$control,true)&&!in_array($name,$allowed_functions,true)){$functions[]=$name;}
                }
            }
        }
        sort($forbidden,SORT_STRING);sort($static,SORT_STRING);sort($functions,SORT_STRING);
        return array(
            'forbidden_hits'=>array_values(array_unique($forbidden)),
            'unapproved_static_dependencies'=>array_values(array_unique($static)),
            'unapproved_function_calls'=>array_values(array_unique($functions)),
            'token_count'=>$n,
            'method_source_scope'=>'entire deriver class including private transitive helpers'
        );
    }
    private static function sourceSignature($source){
        if(!preg_match('/public\s+static\s+function\s+derive\s*\(([^)]*)\)/i',(string)$source,$m)){return array();}
        $out=array();foreach(explode(',',$m[1]) as $param){if(preg_match('/\$([a-zA-Z_][a-zA-Z0-9_]*)/',$param,$x)){$out[]=$x[1];}}return $out;
    }
    private static function realCallsites(){
        $calls=array();$dir=PPM679_PLUGIN_DIR.'includes';
        foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS)) as $f){if($f->getExtension()!=='php'){continue;}$relative=str_replace(PPM679_PLUGIN_DIR,'',$f->getPathname());if($relative===self::DERIVER_FILE||$relative==='includes/category-structure-inspector.php'){continue;}$s=(string)file_get_contents($f->getPathname());if(strpos($s,'PPM679_Independent_Semantic_Category_Deriver::derive(')!==false){$calls[]=$relative;}}
        sort($calls,SORT_STRING);return array_values(array_unique($calls));
    }
    private static function overrideCallsites($sources){$calls=array();foreach($sources as $path=>$source){if(strpos((string)$source,'PPM679_Independent_Semantic_Category_Deriver::derive(')!==false){$calls[]=(string)$path;}}sort($calls,SORT_STRING);return array_values(array_unique($calls));}
    private static function hashMap($paths){$out=array();foreach($paths as $path){$file=PPM679_PLUGIN_DIR.$path;$out[$path]=is_file($file)?hash_file('sha256',$file):null;}return $out;}
    private static function read($relative){$file=PPM679_PLUGIN_DIR.$relative;return is_file($file)?(string)file_get_contents($file):'';}
    private static function tokenIs($token,$id){return is_array($token)&&$token[0]===$id;}
    private static function nextMeaningful($tokens,$i){for($n=count($tokens);$i<$n;$i++){if(is_array($tokens[$i])&&in_array($tokens[$i][0],array(T_WHITESPACE,T_COMMENT,T_DOC_COMMENT),true)){continue;}return $i;}return null;}
    private static function prevMeaningful($tokens,$i){for(;$i>=0;$i--){if(is_array($tokens[$i])&&in_array($tokens[$i][0],array(T_WHITESPACE,T_COMMENT,T_DOC_COMMENT),true)){continue;}return $i;}return null;}
    private static function err($code,$rule,$path,$expected,$actual,$reason){return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'category_structure','',__CLASS__,null,array(self::DERIVER_FILE,self::ORCHESTRATOR_FILE));}
}
