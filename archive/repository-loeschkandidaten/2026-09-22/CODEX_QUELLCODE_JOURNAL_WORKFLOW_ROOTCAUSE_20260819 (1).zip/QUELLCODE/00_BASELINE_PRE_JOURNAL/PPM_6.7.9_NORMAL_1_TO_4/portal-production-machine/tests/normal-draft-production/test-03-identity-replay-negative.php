<?php
require __DIR__.'/fixture-builder.php';
$cases=[];
foreach(['nonce','user','server'] as $kind){
 nd_reset();$p=nd_build_plan(1,'identity-'.$kind);$rt=nd_runtime($p,'identity-'.$kind);
 if($kind==='nonce')$rt['nonce_verified']=false;
 if($kind==='user')$rt['user_id']=0;
 if($kind==='server')$rt['server_instance_id']='wrong-server';
 $r=PPM679_Normal_Draft_Pipeline::execute_plan($p,$rt);ppm_test_assert(strpos(($r['artifact']['status']??''),'BLOCKED_')===0,$kind.' identity must block.');ppm_test_assert(count(PPM679_WP::test_posts())===0,$kind.' identity creates no posts.');$cases[$kind]=$r['artifact']['status'];
}
nd_reset();$p=nd_build_plan(1,'replay');$rt=nd_runtime($p,'same-replay-request');$first=PPM679_Normal_Draft_Pipeline::execute_plan($p,$rt);ppm_test_assert(strpos(($first['artifact']['status']??''),'NORMAL_DRAFT_END_TO_END')===0,'First replay fixture run must pass.');foreach(array_keys(PPM679_WP::test_posts()) as $id)PPM679_WP::delete_post($id);$second=PPM679_Normal_Draft_Pipeline::execute_plan($p,$rt);ppm_test_assert(($second['artifact']['status']??'')==='BLOCKED_NORMAL_REQUEST_REPLAY','Reused request id must block.');ppm_test_assert(count(PPM679_WP::test_posts())===0,'Replay creates no new post.');$cases['replay']=$second['artifact']['status'];
echo json_encode(['status'=>'PASS_NORMAL_DRAFT_IDENTITY_REPLAY_NEGATIVE','cases'=>$cases],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
