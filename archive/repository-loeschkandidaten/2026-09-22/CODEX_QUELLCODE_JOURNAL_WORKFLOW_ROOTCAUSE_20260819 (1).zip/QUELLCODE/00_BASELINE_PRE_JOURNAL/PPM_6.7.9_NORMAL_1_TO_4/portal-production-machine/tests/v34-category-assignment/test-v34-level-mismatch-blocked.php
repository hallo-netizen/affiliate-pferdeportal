<?php
require_once __DIR__.'/fixture-builder.php';
$s=v34_semantic();$s['target_level']=3;
$r=PPM679_Category_Assignment_Validator::derive_independent($s,v34_snapshot());
ppm_test_assert(empty($r['ok']),'wrong target level must block');
echo "PASS_V34_LEVEL_MISMATCH_BLOCKED\n";
