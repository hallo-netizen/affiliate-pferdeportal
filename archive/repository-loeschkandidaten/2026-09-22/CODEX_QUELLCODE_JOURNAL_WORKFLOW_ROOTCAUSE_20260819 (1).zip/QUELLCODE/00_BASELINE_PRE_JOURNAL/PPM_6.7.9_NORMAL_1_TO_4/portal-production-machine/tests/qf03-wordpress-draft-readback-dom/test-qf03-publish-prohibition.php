<?php
require_once dirname(__DIR__).'/bootstrap-test.php'; require_once __DIR__.'/fixture-builder.php';
$hash=hash('sha256',qf03_article_html()); $base=array('DRAFT_CREATE_ALLOWED'=>true,'SERVER_CHECK_STATUS'=>'PASS','READBACK_STATUS'=>'PASS','RENDERED_DOM_STATUS'=>'PASS','DRAFT_CONTENT_HASH'=>$hash,'READBACK_CONTENT_HASH'=>$hash,'EDITORIALLY_REVIEWED_CONTENT_HASH'=>$hash,'separate_user_publish_approval'=>false);
$r=PPM679_WP_Draft_Adapter::evaluate_publish_gate($base); ppm_test_assert($r['ok']===false && $r['PUBLISH_ALLOWED']===false,'No separate approval means no publish');
$base['separate_user_publish_approval']=true; $r=PPM679_WP_Draft_Adapter::evaluate_publish_gate($base); ppm_test_assert($r['ok']===true && $r['executor_registered']===false,'Even satisfied preconditions must not register publish executor');
ppm_test_assert(!method_exists('PPM679_WP','publish_post'),'WP adapter must expose no publish method');
echo json_encode(array('status'=>'PASS','without_user_approval'=>'BLOCKED','with_preconditions'=>'NO_EXECUTOR_REGISTERED','publish_method_present'=>false),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
