<?php
require __DIR__.'/bootstrap-three-type.php';
$scope=ppm_three_scope();$cases=[];
$bad=$scope;$bad['requested_article_types']=['Beratung','Vergleich','Pflege','Wissen'];$cases['wissen_scope']=PPM679_Three_Type_Bundled_Release_Validator::validate(PPM679_Three_Type_Bundled_Release_Validator::ACTION_CONTEXT,$bad);
$bad=$scope;$bad['draft_allowed']=true;$cases['draft_opened']=PPM679_Three_Type_Bundled_Release_Validator::validate(PPM679_Three_Type_Bundled_Release_Validator::ACTION_CONTEXT,$bad);
$bad=$scope;$bad['signing_performed']=false;$cases['unsigned_scope']=PPM679_Three_Type_Bundled_Release_Validator::validate(PPM679_Three_Type_Bundled_Release_Validator::ACTION_CONTEXT,$bad);
$contract=PPM679_Three_Type_Bundled_Release_Validator::load(PPM679_Three_Type_Bundled_Release_Validator::CONTRACT_FILE);$contract['publish_allowed']=true;$cases['tampered_contract']=PPM679_Three_Type_Bundled_Release_Validator::validate(PPM679_Three_Type_Bundled_Release_Validator::ACTION_CONTEXT,$scope,$contract,null);
$bundle=ppm_three_bundle();$bundle['article_types'][]='Wissen';$cases['tampered_bundle']=PPM679_Three_Type_Bundled_Release_Validator::validate(PPM679_Three_Type_Bundled_Release_Validator::ACTION_CONTEXT,$scope,null,$bundle);
$out=[];foreach($cases as $name=>$errors){ppm_test_assert(count($errors)>0,$name.' must block');$out[$name]=ppm_three_codes($errors);}
foreach(['wissen_scope','draft_opened','unsigned_scope'] as $name){ppm_test_assert(in_array('BLOCKED_THREE_TYPE_SCOPE_MISMATCH',$out[$name],true),$name.' must mismatch');}
ppm_test_assert(in_array('BLOCKED_THREE_TYPE_RELEASE_SELF_HASH',$out['tampered_contract'],true),'contract tamper must fail self hash');
ppm_test_assert(in_array('BLOCKED_THREE_TYPE_BUNDLE_SELF_HASH',$out['tampered_bundle'],true),'bundle tamper must fail self hash');
echo json_encode(['status'=>'PASS_THREE_TYPE_SIGNED_QUARANTINE_RELEASE_GATE_NEGATIVE','cases'=>$out],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
