<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Review_Matrix_Validator {
    const VERSION='6.7.9-wave3-quarantine';

    public static function validate($review,$document,$gold_reference=array(),$options=array(),$context='wave3_review_matrix',$server_state_hash='') {
        $review=is_array($review)?$review:array();
        $document=is_array($document)?$document:array();
        $gold_reference=is_array($gold_reference)?$gold_reference:array();
        $options=is_array($options)?$options:array();
        $matrix_contract=self::load_json('contracts/review-matrix-schema-v1.json');
        $evidence_contract=self::load_json('contracts/review-evidence-schema-v1.json');
        $reuse_contract=self::load_json('contracts/quote-reuse-policy-v1.json');
        $errors=array();
        $checks=array();

        $matrix_schema=(array)($matrix_contract['schema']??array());
        $evidence_schema=(array)($evidence_contract['schema']??array());
        $reuse_policy=(array)($reuse_contract['policy']??array());
        $current_matrix_hash=PPM679_Diagnostic::stable_hash($matrix_schema);
        $current_evidence_hash=PPM679_Diagnostic::stable_hash($evidence_schema);
        $current_reuse_hash=PPM679_Diagnostic::stable_hash($reuse_policy);

        if (!hash_equals((string)($matrix_contract['review_matrix_schema_hash']??''),$current_matrix_hash)) {
            $errors[]=self::err('REVIEW_MATRIX_SCHEMA_REFERENCE_INVALID','MATRIX_SCHEMA_REFERENCE_FILE_MUST_MATCH_ITS_CANONICAL_HASH','contracts.review_matrix_schema_hash',$current_matrix_hash,$matrix_contract['review_matrix_schema_hash']??null,'Die versionierte Matrixreferenz ist intern nicht hashkonsistent.',$context,$server_state_hash);
        }
        if (!hash_equals((string)($evidence_contract['review_evidence_schema_hash']??''),$current_evidence_hash)) {
            $errors[]=self::err('REVIEW_EVIDENCE_SCHEMA_REFERENCE_INVALID','EVIDENCE_SCHEMA_REFERENCE_FILE_MUST_MATCH_ITS_CANONICAL_HASH','contracts.review_evidence_schema_hash',$current_evidence_hash,$evidence_contract['review_evidence_schema_hash']??null,'Die versionierte Belegreferenz ist intern nicht hashkonsistent.',$context,$server_state_hash);
        }
        if (!hash_equals((string)($reuse_contract['quote_reuse_policy_hash']??''),$current_reuse_hash)) {
            $errors[]=self::err('QUOTE_REUSE_POLICY_REFERENCE_INVALID','QUOTE_REUSE_POLICY_FILE_MUST_MATCH_ITS_CANONICAL_HASH','contracts.quote_reuse_policy_hash',$current_reuse_hash,$reuse_contract['quote_reuse_policy_hash']??null,'Die Quote-Reuse-Referenz ist intern nicht hashkonsistent.',$context,$server_state_hash);
        }

        $review_matrix_hash=(string)($review['review_matrix_schema_hash']??'');
        $review_evidence_hash=(string)($review['review_evidence_schema_hash']??'');
        $review_reuse_hash=(string)($review['quote_reuse_policy_hash']??'');
        if (!hash_equals($current_matrix_hash,$review_matrix_hash)) {
            $errors[]=self::err('EVIDENCE_STALE','CURRENT_REVIEW_MATRIX_SCHEMA_HASH_MUST_MATCH_REVIEW_BINDING','review.review_matrix_schema_hash',$current_matrix_hash,$review_matrix_hash,'Ein Review mit veraltetem Matrixschema ist ungültig.',$context,$server_state_hash);
        }
        if (!hash_equals($current_evidence_hash,$review_evidence_hash)) {
            $errors[]=self::err('EVIDENCE_STALE','CURRENT_REVIEW_EVIDENCE_SCHEMA_HASH_MUST_MATCH_REVIEW_BINDING','review.review_evidence_schema_hash',$current_evidence_hash,$review_evidence_hash,'Ein Review mit veraltetem Belegschema ist ungültig.',$context,$server_state_hash);
        }
        if (!hash_equals($current_reuse_hash,$review_reuse_hash)) {
            $errors[]=self::err('EVIDENCE_STALE','CURRENT_QUOTE_REUSE_POLICY_HASH_MUST_MATCH_REVIEW_BINDING','review.quote_reuse_policy_hash',$current_reuse_hash,$review_reuse_hash,'Ein Review mit veralteten Wiederverwendungsregeln ist ungültig.',$context,$server_state_hash);
        }

        $content_hash=(string)($review['content_hash']??'');
        if (!hash_equals((string)($document['content_hash']??''),$content_hash)) {
            $errors[]=self::err('REVIEW_CONTENT_HASH_MISMATCH','REVIEW_MUST_BIND_EXACT_DOCUMENT_CONTENT_HASH','review.content_hash',$document['content_hash']??null,$content_hash,'Die Reviewmatrix gehört nicht zum geprüften Dokument.',$context,$server_state_hash);
        }
        if ((string)($review['article_type']??'')!==(string)($document['article_type']??'')) {
            $errors[]=self::err('REVIEW_ARTICLE_TYPE_MISMATCH','REVIEW_AND_DOCUMENT_ARTICLE_TYPE_MUST_MATCH','review.article_type',$document['article_type']??null,$review['article_type']??null,'Die Matrix bindet eine andere Beitragsart.',$context,$server_state_hash);
        }

        $section_criteria=array_values((array)($matrix_schema['required_section_criteria']??array()));
        $article_criteria=array_values((array)($matrix_schema['required_article_wide_criteria']??array()));
        $known_criteria=array_fill_keys(array_merge($section_criteria,$article_criteria),true);
        $allowed_types=(array)($evidence_schema['required_evidence_type_by_criterion']??array());
        $min_units=(array)($evidence_schema['minimum_evidence_units_by_criterion']??array());
        $cells=array_values((array)($review['cells']??array()));
        $review_sections=array_values((array)($review['review_sections']??array()));
        $document_sections=self::section_map((array)($document['sections']??array()));
        $required_keys=array();
        $required_gold_keys=array();
        foreach ($review_sections as $section_id) {
            $section_id=(string)$section_id;
            foreach ($section_criteria as $criterion) {
                $required_key=self::cell_key((string)($review['article_id']??''),$content_hash,'SECTION',$section_id,$criterion);
                $required_keys[$required_key]=true;
                if ($criterion==='SECTION_QUALITY_RELATIVE_TO_GOLD_REFERENCE') { $required_gold_keys[$required_key]=true; }
            }
        }
        foreach ($article_criteria as $criterion) {
            $required_key=self::cell_key((string)($review['article_id']??''),$content_hash,'ARTICLE_WIDE','ARTICLE_WIDE',$criterion);
            $required_keys[$required_key]=true;
            if ($criterion==='GOLD_CORE_ALIGNMENT') { $required_gold_keys[$required_key]=true; }
        }
        $found_keys=array();
        $quote_occurrences=array();
        $cell_summaries=array();
        $gold_all_verified=true;
        $found_gold_keys=array();
        $structural_all_verified=true;
        $link_all_verified=true;
        $table_all_verified=true;
        $review_quotes_all_verified=true;

        foreach ($cells as $index=>$cell) {
            $cell=is_array($cell)?$cell:array();
            $cell_errors_start=count($errors);
            $path='review.cells.'.$index;
            foreach ((array)($matrix_schema['required_cell_fields']??array()) as $field) {
                $value=$cell[$field]??null;
                if ($value===null || (is_string($value)&&trim($value)==='')) {
                    $errors[]=self::err('REVIEW_MATRIX_CELL_INCOMPLETE','EVERY_REVIEW_CELL_REQUIRES_ALL_CORE_FIELDS',$path.'.'.$field,'present non-empty field',$value,'Eine Pflichtzelle ohne Urteil, Begründung, Belegart oder Bindung ist ungültig.',$context,$server_state_hash);
                }
            }
            $criterion=(string)($cell['criterion_id']??'');
            $scope=(string)($cell['scope']??'');
            $section_id=$scope==='ARTICLE_WIDE'?'ARTICLE_WIDE':(string)($cell['section_id']??'');
            $key=self::cell_key((string)($cell['article_id']??''),(string)($cell['content_hash']??''),$scope,$section_id,$criterion);
            if (isset($found_keys[$key])) {
                $errors[]=self::err('REVIEW_MATRIX_DUPLICATE_CELL','REVIEW_MATRIX_CELL_KEY_MUST_BE_UNIQUE',$path,$key,$key,'Ein Pflichtkriterium wurde doppelt geliefert.',$context,$server_state_hash);
            }
            $found_keys[$key]=true;
            if (!isset($known_criteria[$criterion])) {
                $errors[]=self::err('REVIEW_MATRIX_UNKNOWN_CRITERION','CRITERION_ID_MUST_EXIST_IN_CURRENT_MATRIX_SCHEMA',$path.'.criterion_id',array_keys($known_criteria),$criterion,'Eine unbekannte criterion_id ist unzulässig.',$context,$server_state_hash);
            }
            if (!in_array((string)($cell['verdict']??''),(array)($matrix_schema['allowed_verdicts']??array()),true)) {
                $errors[]=self::err('REVIEW_MATRIX_VERDICT_INVALID','VERDICT_MUST_USE_EXACT_ALLOWED_VALUE',$path.'.verdict',$matrix_schema['allowed_verdicts']??array(),$cell['verdict']??null,'Das Matrixurteil verwendet keinen exakten Statuswert.',$context,$server_state_hash);
            }
            if ((string)($cell['article_id']??'')!==(string)($review['article_id']??'') || (string)($cell['content_hash']??'')!==$content_hash) {
                $errors[]=self::err('REVIEW_MATRIX_CELL_BINDING_MISMATCH','CELL_MUST_BIND_SAME_ARTICLE_AND_CONTENT_HASH_AS_MATRIX',$path,array('article_id'=>$review['article_id']??null,'content_hash'=>$content_hash),array('article_id'=>$cell['article_id']??null,'content_hash'=>$cell['content_hash']??null),'Die Matrixzelle ist nicht an denselben Artikelinhalt gebunden.',$context,$server_state_hash);
            }
            if ($scope==='SECTION') {
                if (!isset($document_sections[$section_id]) || !in_array($section_id,$review_sections,true)) {
                    $errors[]=self::err('REVIEW_EVIDENCE_ZONE_INVALID','SECTION_CELL_MUST_REFERENCE_REVIEWED_DOCUMENT_SECTION',$path.'.section_id',$review_sections,$section_id,'Die Abschnittszelle verweist nicht auf einen geprüften Abschnitt.',$context,$server_state_hash);
                }
            } elseif ($scope!=='ARTICLE_WIDE') {
                $errors[]=self::err('REVIEW_MATRIX_SCOPE_INVALID','CELL_SCOPE_MUST_BE_SECTION_OR_ARTICLE_WIDE',$path.'.scope',array('SECTION','ARTICLE_WIDE'),$scope,'Der Zellenschlüssel besitzt keinen zulässigen Scope.',$context,$server_state_hash);
            }
            $evidence_type=(string)($cell['evidence_type']??'');
            if (!in_array($evidence_type,(array)($allowed_types[$criterion]??array()),true)) {
                $errors[]=self::err('REVIEW_EVIDENCE_TYPE_INVALID','CRITERION_REQUIRES_CRITERION_SPECIFIC_EVIDENCE_TYPE',$path.'.evidence_type',$allowed_types[$criterion]??array(),$evidence_type,'Nicht jedes Kriterium darf mit demselben allgemeinen Textzitat belegt werden.',$context,$server_state_hash);
            }

            $cell_errors_before=count($errors);
            $units=self::evidence_units($cell);
            $minimum=(int)($min_units[$criterion]??0);
            if (self::is_text_type($evidence_type) && count($units)<$minimum) {
                $errors[]=self::err('REVIEW_EVIDENCE_UNITS_INSUFFICIENT','CRITERION_REQUIRES_MINIMUM_NUMBER_OF_EVIDENCE_UNITS',$path.'.evidence_units',$minimum,count($units),'Die kriterienspezifische Mindestzahl an Belegeinheiten fehlt.',$context,$server_state_hash);
            }
            $has_additional_non_text=!empty($cell['candidate_structure_evidence']) || !empty($cell['structural_evidence']) || !empty($cell['link_evidence']) || !empty($cell['table_evidence']);
            if (in_array($criterion,(array)($reuse_policy['single_quote_forbidden_criteria']??array()),true) && self::is_text_type($evidence_type) && count($units)<=1 && !$has_additional_non_text) {
                $errors[]=self::err('SINGLE_QUOTE_INSUFFICIENT_FOR_CRITERION','ARTICLE_WIDE_OR_REPETITION_CRITERION_REQUIRES_MORE_THAN_ONE_TEXT_UNIT_OR_NON_TEXT_EVIDENCE',$path.'.evidence_units','more than one evidence unit or verified non-text evidence',count($units),'Dieses Kriterium darf niemals ausschließlich durch ein einzelnes Zitat erfüllt werden.',$context,$server_state_hash);
            }

            foreach ($units as $unit_index=>$unit) {
                $unit_path=$path.'.evidence_units.'.$unit_index;
                $quote=(string)($unit['exact_quote']??'');
                $start=(int)($unit['quote_start_offset']??-1);
                $end=(int)($unit['quote_end_offset']??-1);
                $expected_fingerprint=hash('sha256',$content_hash.$start.$end.$quote);
                if (!self::quote_matches((string)($document['body_text']??''),$quote,$start,$end) || !hash_equals($expected_fingerprint,(string)($unit['quote_fingerprint']??''))) {
                    $review_quotes_all_verified=false;
                    $errors[]=self::err('EDITORIAL_EVIDENCE_QUOTE_INVALID','QUOTE_AND_OFFSETS_MUST_MATCH_ACTUAL_BODY_TEXT_AND_FINGERPRINT',$unit_path,array('text_slice'=>$quote,'fingerprint'=>$expected_fingerprint),$unit,'Das Review-Zitat ist falsch, ungenau oder nicht vorhanden.',$context,$server_state_hash);
                }
                if (!self::unit_in_zone($criterion,$scope,$section_id,$start,$end,$document_sections,$document)) {
                    $errors[]=self::err('REVIEW_EVIDENCE_ZONE_INVALID','EVIDENCE_MUST_ORIGINATE_IN_THE_REGION_EVALUATED_BY_THE_CRITERION',$unit_path,array('criterion'=>$criterion,'section_id'=>$section_id),array('start'=>$start,'end'=>$end),'Der Beleg stammt aus einem falschen Bereich.',$context,$server_state_hash);
                }
                $fingerprint=(string)($unit['quote_fingerprint']??'');
                if ($fingerprint!=='') {
                    $quote_occurrences[$fingerprint][]=array('cell_index'=>$index,'criterion'=>$criterion,'scope'=>$scope,'section_id'=>$section_id,'cell'=>$cell,'unit'=>$unit);
                }
            }

            if ($evidence_type==='HEADING_SEQUENCE_EVIDENCE') {
                if (!self::structure_matches($cell,$document)) {
                    $structural_all_verified=false;
                    $errors[]=self::err('EDITORIAL_NON_TEXT_EVIDENCE_INVALID','STRUCTURE_EVIDENCE_MUST_MATCH_ACTUAL_DOM_AND_HEADING_TREE',$path.'.structural_evidence',$document['structure_evidence']??null,$cell['structural_evidence']??null,'Der Strukturbeleg ist nicht gegen den tatsächlichen Überschriftenbaum verifizierbar.',$context,$server_state_hash);
                }
            }
            if ($evidence_type==='LINK_PLACEMENT_MAP') {
                if (!self::links_match($cell,$document)) {
                    $link_all_verified=false;
                    $errors[]=self::err('EDITORIAL_NON_TEXT_EVIDENCE_INVALID','LINK_EVIDENCE_MUST_MATCH_ACTUAL_LINK_POSITIONS_AND_PORTAL_EXPORT',$path.'.link_evidence',$document['links']??null,$cell['link_evidence']??null,'Der Linkbeleg ist nicht gegen die tatsächlichen Positionen und den Portal-IST-Hash verifizierbar.',$context,$server_state_hash);
                }
            }
            if ($evidence_type==='TABLE_VALUE_EVIDENCE') {
                if (!self::table_matches($cell,$document)) {
                    $table_all_verified=false;
                    $errors[]=self::err('EDITORIAL_NON_TEXT_EVIDENCE_INVALID','TABLE_EVIDENCE_MUST_MATCH_ACTUAL_CELLS_AND_COMPARISON_TEXT',$path.'.table_evidence',$document['tables']??null,$cell['table_evidence']??null,'Der Tabellenbeleg ist nicht gegen Tabellenzellen und Vergleichsstellen verifizierbar.',$context,$server_state_hash);
                }
            }
            if ($evidence_type==='CONTRACT_NOT_APPLICABLE_EVIDENCE') {
                if (($document['article_contract']['table_required']??true)!==false || !hash_equals((string)($document['article_contract']['contract_hash']??''),(string)($cell['article_contract_hash']??''))) {
                    $table_all_verified=false;
                    $errors[]=self::err('EDITORIAL_NON_TEXT_EVIDENCE_INVALID','TABLE_NOT_APPLICABLE_REQUIRES_BOUND_ARTICLE_CONTRACT',$path.'.article_contract_hash',$document['article_contract']??null,$cell['article_contract_hash']??null,'Eine nicht erforderliche Tabelle muss über den Artikelvertrag belegt sein.',$context,$server_state_hash);
                }
            }
            if (in_array($criterion,array('SECTION_QUALITY_RELATIVE_TO_GOLD_REFERENCE','GOLD_CORE_ALIGNMENT'),true)) {
                $found_gold_keys[$key]=true;
                $gold=PPM679_Gold_Core_Validator::validate_review_evidence($cell,$document,$gold_reference,$context.'.gold.'.$index,$server_state_hash);
                if (empty($gold['ok'])) { $gold_all_verified=false; $errors=array_merge($errors,$gold['errors']); }
                if (count($errors)!==$cell_errors_start) { $gold_all_verified=false; }
            }
            $cell_summaries[] = array('index'=>$index,'key'=>$key,'criterion'=>$criterion,'valid'=>count($errors)===$cell_errors_before);
        }

        foreach ($required_keys as $key=>$unused) {
            if (!isset($found_keys[$key])) {
                $errors[]=self::err('REVIEW_MATRIX_REQUIRED_CELL_MISSING','EVERY_SECTION_AND_ARTICLE_WIDE_CRITERION_REQUIRES_ONE_CELL','review.cells',$key,'missing','Eine Pflichtzelle fehlt; Abschnitts- und artikelweite Abdeckung sind getrennt erforderlich.',$context,$server_state_hash);
            }
        }

        $reuse=self::audit_reuse($quote_occurrences,$reuse_policy,$context,$server_state_hash);
        $errors=array_merge($errors,$reuse['errors']);

        $section_expected=count($review_sections)*count($section_criteria);
        $article_expected=count($article_criteria);
        $section_found=0;
        $article_found=0;
        foreach ($found_keys as $key=>$unused) {
            if (strpos($key,'|SECTION|')!==false) { $section_found++; }
            if (strpos($key,'|ARTICLE_WIDE|')!==false) { $article_found++; }
        }
        $section_coverage=($section_found===$section_expected && $section_expected>0)?'COMPLETE':'INCOMPLETE';
        $article_coverage=($article_found===$article_expected)?'COMPLETE':'INCOMPLETE';
        $total_coverage=($section_coverage==='COMPLETE'&&$article_coverage==='COMPLETE'&&count($found_keys)===count($required_keys))?'COMPLETE':'INCOMPLETE';
        $type_coverage=self::type_coverage($cells,$allowed_types)?'COMPLETE':'INCOMPLETE';
        $gold_alignment_present=self::criterion_present($cells,'GOLD_CORE_ALIGNMENT');
        $gold_cells_checked=count(array_intersect_key($found_gold_keys,$required_gold_keys));
        $gold_cells_expected=count($required_gold_keys);
        $gold_coverage_complete=$gold_cells_expected>0 && $gold_cells_checked===$gold_cells_expected;
        $gold_gate_status=$gold_cells_checked===0?'NICHT_AUSGEFÜHRT':(($gold_coverage_complete&&$gold_all_verified)?'PASS':'BLOCKED');
        $all_gold_quotes_verified=$gold_gate_status==='PASS';
        $gold_hash_match=hash_equals((string)($gold_reference['content_hash']??''),(string)($review['gold_reference_hash']??''));
        $article_type_match=(string)($document['article_type']??'')===(string)($gold_reference['article_type']??'');
        $independent_verified=($options['independent_review_verified']??false)===true;

        $hard_conditions=array(
            'TOTAL_EDITORIAL_COVERAGE'=>$total_coverage,
            'SECTION_COVERAGE'=>$section_coverage,
            'ARTICLE_WIDE_COVERAGE'=>$article_coverage,
            'REVIEW_EVIDENCE_TYPE_COVERAGE'=>$type_coverage,
            'QUOTE_REUSE_AUDIT_STATUS'=>$reuse['status'],
            'GOLD_CORE_REVIEW_GATE'=>$gold_gate_status,
            'GOLD_CORE_ALIGNMENT_CELL_PRESENT'=>$gold_alignment_present,
            'ALL_GOLD_CORE_QUOTES_VERIFIED'=>$all_gold_quotes_verified,
            'GOLD_CORE_COVERAGE'=>$gold_coverage_complete?'COMPLETE':'INCOMPLETE',
            'ALL_REVIEW_QUOTES_VERIFIED'=>$review_quotes_all_verified,
            'ALL_STRUCTURAL_EVIDENCE_VERIFIED'=>$structural_all_verified,
            'ALL_LINK_EVIDENCE_VERIFIED'=>$link_all_verified,
            'ALL_TABLE_EVIDENCE_VERIFIED'=>$table_all_verified,
            'CANDIDATE_ARTICLE_TYPE_MATCH'=>$article_type_match,
            'CURRENT_GOLD_REFERENCE_HASH_MATCH'=>$gold_hash_match,
            'CURRENT_REVIEW_MATRIX_SCHEMA_HASH_MATCH'=>hash_equals($current_matrix_hash,$review_matrix_hash),
            'CURRENT_REVIEW_EVIDENCE_SCHEMA_HASH_MATCH'=>hash_equals($current_evidence_hash,$review_evidence_hash),
            'CURRENT_QUOTE_REUSE_POLICY_HASH_MATCH'=>hash_equals($current_reuse_hash,$review_reuse_hash),
            'INDEPENDENT_REVIEW_VERIFIED'=>$independent_verified,
        );
        foreach ($hard_conditions as $name=>$value) {
            $pass=$value===true || $value==='PASS' || $value==='COMPLETE';
            if (!$pass && !in_array($name,array('INDEPENDENT_REVIEW_VERIFIED'),true)) {
                $errors[]=self::err('EDITORIAL_REVIEW_CONDITION_MISSING','EDITORIAL_REVIEW_PASS_REQUIRES_EVERY_HARD_CONDITION','conditions.'.$name,'PASS/COMPLETE/TRUE',$value,'Eine einzige fehlende Bedingung blockiert den redaktionellen Reviewstatus.',$context,$server_state_hash);
            }
        }
        $matrix_ok=!$errors;
        $editorial_status=$matrix_ok&&$independent_verified?'PASS':($matrix_ok?'NICHT_AUSGEFÜHRT':'BLOCKED');

        return array(
            'ok'=>$matrix_ok,
            'matrix_validation_status'=>$matrix_ok?'PASS':'BLOCKED',
            'editorial_review_status'=>$editorial_status,
            'gold_core_review_gate'=>$gold_gate_status,
            'gold_core_cells_checked'=>$gold_cells_checked,
            'gold_core_cells_expected'=>$gold_cells_expected,
            'quote_reuse_audit_status'=>$reuse['status'],
            'general_quote_diversity_threshold'=>'UNGEKLÄRT',
            'coverage'=>array('total'=>$total_coverage,'section'=>$section_coverage,'article_wide'=>$article_coverage,'evidence_type'=>$type_coverage),
            'quote_reuse_diagnostics'=>$reuse['diagnostics'],
            'conditions'=>$hard_conditions,
            'cell_summaries'=>$cell_summaries,
            'errors'=>$errors,
            'production_allowed'=>false,
            'draft_create_allowed'=>false,
            'publish_allowed'=>false,
            'scope_limit'=>'Deterministic matrix/evidence validation; independent review is required for EDITORIAL_REVIEW_STATUS PASS.'
        );
    }

    private static function audit_reuse($occurrences,$policy,$context,$server_state_hash) {
        $errors=array();
        $reused=0;
        $max=0;
        $cell_count=0;
        $section_single=array();
        $article_text_only=0;
        foreach ($occurrences as $fingerprint=>$items) {
            $count=count($items);
            $max=max($max,$count);
            $cell_count+=$count;
            if ($count<=1) { continue; }
            $reused++;
            $groups=array();
            $normalized_explanations=array();
            foreach ($items as $item) {
                $cell=(array)$item['cell'];
                if (($cell['quote_reuse_declared']??false)!==true || trim((string)($cell['quote_reuse_group_id']??''))==='') {
                    $errors[]=self::err('UNDECLARED_QUOTE_REUSE','EVERY_REUSED_QUOTE_FINGERPRINT_MUST_BE_DECLARED','review.cells.'.$item['cell_index'].'.quote_reuse_declared',true,$cell['quote_reuse_declared']??null,'Dasselbe quote_fingerprint erscheint in mehreren Zellen ohne deklarierte Wiederverwendung.',$context,$server_state_hash,array($fingerprint));
                }
                $groups[]=(string)($cell['quote_reuse_group_id']??'');
                $specific=trim((string)($cell['criterion_specific_explanation']??''));
                if ($specific==='') {
                    $errors[]=self::err('QUOTE_REUSE_EXPLANATION_NOT_CRITERION_SPECIFIC','REUSED_QUOTE_REQUIRES_OWN_CRITERION_SPECIFIC_EXPLANATION','review.cells.'.$item['cell_index'].'.criterion_specific_explanation','non-empty criterion-specific explanation',$specific,'Die Wiederverwendung besitzt keine eigene kriterienspezifische Begründung.',$context,$server_state_hash,array($fingerprint));
                }
                $normalized_explanations[]=self::normalize_explanation($specific,(string)$item['criterion']);
            }
            $nonempty=array_values(array_filter($groups,fn($v)=>$v!==''));
            if (count(array_unique($nonempty))>1) {
                $errors[]=self::err('UNDECLARED_QUOTE_REUSE','REUSED_FINGERPRINT_MUST_SHARE_ONE_REUSE_GROUP_ID','quote_reuse_group_id','one group id',array_values(array_unique($nonempty)),'Eine Reuse-Gruppe ist technisch nicht eindeutig.',$context,$server_state_hash,array($fingerprint));
            }
            $filtered=array_values(array_filter($normalized_explanations,fn($v)=>$v!==''));
            if (count($filtered)!==count(array_unique($filtered))) {
                $errors[]=self::err('QUOTE_REUSE_EXPLANATION_NOT_CRITERION_SPECIFIC','REUSED_QUOTE_EXPLANATIONS_MUST_DIFFER_BY_ACTUAL_REVIEW_SUBJECT','quote_reuse_explanations','distinct criterion-specific explanations',$filtered,'Identische oder nur umbenannte Begründungen sind unzulässig.',$context,$server_state_hash,array($fingerprint));
            }
        }
        $distinct=count($occurrences);
        $ratio=$cell_count>0?round(array_sum(array_map(fn($items)=>count($items)>1?count($items):0,$occurrences))/$cell_count,6):0.0;
        return array(
            'status'=>!$errors?'PASS':'BLOCKED',
            'errors'=>$errors,
            'diagnostics'=>array(
                'DISTINCT_QUOTE_COUNT'=>$distinct,
                'REUSED_QUOTE_GROUP_COUNT'=>$reused,
                'MAX_QUOTE_REUSE_COUNT'=>$max,
                'QUOTE_REUSE_CELL_RATIO'=>$ratio,
                'SECTIONS_WITH_SINGLE_QUOTE_ONLY'=>$section_single,
                'ARTICLE_WIDE_CELLS_USING_TEXT_QUOTE_ONLY'=>$article_text_only,
                'GENERAL_QUOTE_DIVERSITY_THRESHOLD'=>'UNGEKLÄRT'
            )
        );
    }

    private static function evidence_units($cell) {
        if (isset($cell['evidence_units'])&&is_array($cell['evidence_units'])) { return array_values($cell['evidence_units']); }
        if (isset($cell['exact_quote'])) {
            return array(array(
                'exact_quote'=>$cell['exact_quote'],
                'quote_start_offset'=>$cell['quote_start_offset']??null,
                'quote_end_offset'=>$cell['quote_end_offset']??null,
                'quote_fingerprint'=>$cell['quote_fingerprint']??null,
            ));
        }
        return array();
    }

    private static function is_text_type($type) {
        return in_array($type,array('EXACT_TEXT_QUOTE','TEXT_QUOTE_SET','PAIRED_CANDIDATE_REFERENCE_QUOTES','INTRO_REGION_QUOTE_SET','CONCLUSION_REGION_QUOTE_SET','MULTI_SECTION_QUOTE_SET','REPETITION_EVIDENCE_SET'),true);
    }

    private static function quote_matches($body,$quote,$start,$end) {
        return $start>=0 && $end>=$start && substr($body,$start,$end-$start)===$quote;
    }

    private static function unit_in_zone($criterion,$scope,$section_id,$start,$end,$sections,$document) {
        if ($start<0 || $end<$start) { return false; }
        if ($criterion==='INTRODUCTION_QUALITY') { return self::within_region($start,$end,(array)($document['regions']['introduction']??array())); }
        if ($criterion==='CONCLUSION_QUALITY') { return self::within_region($start,$end,(array)($document['regions']['conclusion']??array())); }
        if ($scope==='SECTION' && isset($sections[$section_id])) { return self::within_region($start,$end,$sections[$section_id]); }
        return true;
    }

    private static function within_region($start,$end,$region) {
        return isset($region['start'],$region['end']) && $start>=(int)$region['start'] && $end<=(int)$region['end'];
    }

    private static function structure_matches($cell,$document) {
        $actual=(array)($document['structure_evidence']??array());
        $given=(array)($cell['structural_evidence']??array());
        foreach (array('heading_sequence','section_order','section_metrics','source_offsets') as $field) {
            if (!array_key_exists($field,$given) || PPM679_Diagnostic::stable_hash($given[$field])!==PPM679_Diagnostic::stable_hash($actual[$field]??null)) { return false; }
        }
        return true;
    }

    private static function links_match($cell,$document) {
        $given=array_values((array)($cell['link_evidence']??array()));
        $actual=array_values((array)($document['links']??array()));
        if (count($given)!==count($actual) || !hash_equals((string)($document['portal_ist_hash']??''),(string)($cell['portal_ist_hash']??''))) { return false; }
        $fields=array('link_target','link_text','link_reason','section_id','link_start_offset','link_end_offset','portal_ist_match');
        foreach ($actual as $i=>$row) {
            foreach ($fields as $field) { if (($given[$i][$field]??null)!==($row[$field]??null)) { return false; } }
        }
        return true;
    }

    private static function table_matches($cell,$document) {
        $given=(array)($cell['table_evidence']??array());
        $tables=array_values((array)($document['tables']??array()));
        foreach ($tables as $table) {
            if ((string)($table['table_id']??'')!==(string)($given['table_id']??'')) { continue; }
            foreach (array('table_structure','table_cells','comparison_text_offsets','additional_value_metrics') as $field) {
                if (PPM679_Diagnostic::stable_hash($table[$field]??null)!==PPM679_Diagnostic::stable_hash($given[$field]??null)) { return false; }
            }
            return true;
        }
        return false;
    }

    private static function section_map($sections) {
        $out=array();
        foreach ($sections as $section) {
            $id=(string)($section['section_id']??'');
            if ($id!=='') { $out[$id]=$section; }
        }
        return $out;
    }

    private static function type_coverage($cells,$allowed) {
        foreach ((array)$cells as $cell) {
            $criterion=(string)($cell['criterion_id']??'');
            if (!in_array((string)($cell['evidence_type']??''),(array)($allowed[$criterion]??array()),true)) { return false; }
        }
        return true;
    }

    private static function criterion_present($cells,$criterion) {
        foreach ((array)$cells as $cell) { if (($cell['criterion_id']??'')===$criterion) { return true; } }
        return false;
    }

    private static function normalize_explanation($text,$criterion) {
        $lower=function_exists('mb_strtolower')?mb_strtolower((string)$text,'UTF-8'):strtolower((string)$text);
        $criterion_lower=function_exists('mb_strtolower')?mb_strtolower($criterion,'UTF-8'):strtolower($criterion);
        $text=str_replace($criterion_lower,'',$lower);
        $text=preg_replace('/[^\p{L}\p{N}]+/u',' ',$text);
        return trim((string)$text);
    }

    private static function cell_key($article_id,$content_hash,$scope,$section_id,$criterion) {
        return $article_id.'|'.$content_hash.'|'.$scope.'|'.$section_id.'|'.$criterion;
    }

    private static function load_json($relative) {
        $file=defined('PPM679_PLUGIN_DIR')?PPM679_PLUGIN_DIR.$relative:'';
        $data=$file!==''&&is_file($file)?json_decode((string)file_get_contents($file),true):null;
        return is_array($data)?$data:array();
    }

    private static function err($code,$rule,$path,$expected,$actual,$reason,$context,$server_state_hash,$refs=array()) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$context,$server_state_hash,__CLASS__,null,$refs);
    }
}
