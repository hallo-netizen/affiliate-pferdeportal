<?php
require_once __DIR__.'/fixture-builder.php';
$bad='$x=[\'category_binding\']; derive_independent(';
$i=PPM679_Category_Structure_Inspector::inspect(null,null,$bad);
ppm_test_assert(!empty($i['errors']),'plan-load-before-derive must block');
echo "PASS_V34_ORDER_VIOLATION_BLOCKED\n";
