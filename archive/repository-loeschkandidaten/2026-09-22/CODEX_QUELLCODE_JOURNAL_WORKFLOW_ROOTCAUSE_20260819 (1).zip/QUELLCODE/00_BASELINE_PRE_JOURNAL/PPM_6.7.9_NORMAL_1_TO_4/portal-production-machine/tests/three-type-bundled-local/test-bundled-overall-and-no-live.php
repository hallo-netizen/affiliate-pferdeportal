<?php
require __DIR__.'/bootstrap-three-type.php';
$r=PPM679_Three_Type_Bundled_Local_Preflight::run(ppm_three_scope());
ppm_test_assert(!empty($r['ok']),'full signed-quarantine three-type preflight must pass');
ppm_test_assert(array_keys($r['results'])===['Beratung','Vergleich','Pflege'],'results must remain type-separated and ordered');
foreach(['Beratung','Vergleich','Pflege'] as $type){ppm_test_assert(!empty($r['results'][$type]['ok']),$type.' must pass individually');}
ppm_test_assert($r['drafts_created']===0 && $r['wordpress_access_performed']===false && $r['signing_performed']===true && $r['publish_allowed']===false,'signed build must keep all live boundaries closed');
$plugin=file_get_contents(dirname(__DIR__,2).'/portal-production-machine.php');
foreach(PPM679_Three_Type_Bundled_Release_Validator::REGISTERED_COMPONENTS as $path){$name=basename($path);ppm_test_assert(substr_count($plugin,$name)===1,$name.' must be registered exactly once');}
ppm_test_assert(count(PPM679_WP::test_posts())===0,'no in-memory WordPress draft may be created');
echo json_encode(['status'=>'PASS_BUNDLED_SIGNED_QUARANTINE_OVERALL_NO_LIVE','type_results'=>array_map(fn($x)=>$x['ok'],$r['results']),'drafts_created'=>0,'wordpress_access'=>false,'bootstrap_registered'=>true,'signing_performed'=>true,'publish_allowed'=>false],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
