<?php
require_once __DIR__.'/fixture-builder.php';PPM679_WP::reset_test_state();
$b=array('name'=>'Nicht vorhanden','slug'=>'nicht-vorhanden','hierarchy_path'=>'Transport > Nicht vorhanden','taxonomy'=>'category');
$r=PPM679_WP::resolve_category_binding($b);
ppm_test_assert(empty($r['ok']),'missing live term must block');
echo "PASS_V34_LIVE_RESOLUTION_MISSING_BLOCKED\n";
