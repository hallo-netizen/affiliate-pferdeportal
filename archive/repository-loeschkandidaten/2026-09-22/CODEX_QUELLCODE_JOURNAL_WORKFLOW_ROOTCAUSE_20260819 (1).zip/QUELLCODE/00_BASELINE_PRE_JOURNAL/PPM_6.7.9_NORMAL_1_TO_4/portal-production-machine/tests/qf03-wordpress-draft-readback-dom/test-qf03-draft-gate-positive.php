<?php
require_once dirname(__DIR__).'/bootstrap-test.php';
require_once __DIR__.'/fixture-builder.php';
PPM679_WP::reset_test_state(); PPM679_WP_Draft_Adapter::reset_test_state();
$c=qf03_candidate_fixture(); $g=qf03_gate_fixture();
$r=PPM679_WP_Draft_Adapter::create_single_faq_draft($c,$g);
ppm_test_assert($r['ok']===true,'QF03 draft must pass with complete independent gate evidence');
ppm_test_assert((int)$r['post_id']>0,'Draft id must be positive');
$p=PPM679_WP::get_post_snapshot($r['post_id']);
ppm_test_assert($p['post_status']==='draft','Stored status must be draft');
ppm_test_assert(count(PPM679_WP::test_posts())===1,'Exactly one test draft must exist');
echo json_encode(array('status'=>'PASS','post_id'=>$r['post_id'],'draft_report_status'=>$r['report']['status'],'content_hash'=>hash('sha256',$c['content_html'])),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
