<?php
require_once __DIR__.'/bootstrap-test.php';
$c=json_decode(file_get_contents(dirname(__DIR__).'/contracts/g9-single-faq-approved-candidate-v1.json'),true);$h=$c['candidate']['content_html'];
foreach(array('/transport/','/transport/transport-zugfahrzeug/','/transport/transport-anhaenger/') as $url){ppm_test_assert(strpos($h,'href="'.$url.'"')!==false,'real page link missing '.$url);}
foreach(array('/transport-pferdeanhaenger/','/pferdeanhaenger-beladen/','/pferdeanhaenger-sicherheit/','Die Tabelle ordnet','keine Ersatzrechnung','führt eine Ebene höher','im Beitrag') as $bad){ppm_test_assert(stripos($h,$bad)===false,'rejected phrase/url remains: '.$bad);}
ppm_test_assert(strpos($h,'class="system-129-table pm-table pm-table--responsive comparison-table"')!==false,'canonical table class required');
ppm_test_assert(hash('sha256',$h)===$c['canonical_content_sha256'],'candidate hash binding');
ppm_test_assert(PPM679_Diagnostic::stable_hash($c['item']['quality_binding'])===$c['quality_binding_sha256'],'quality hash binding');
ppm_test_assert(($c['independent_editorial_review']['mainblock1_status']??'')==='REQUIRED_NOT_YET_OBTAINED','build must not claim Claude PASS');
echo json_encode(array('status'=>'PASS_MAINBLOCK1_CORRECTED_CANDIDATE_LOCAL','article_sha256'=>$c['canonical_content_sha256'],'quality_binding_sha256'=>$c['quality_binding_sha256'],'external_claude_review_required'=>true,'external_pass_claimed'=>false),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
