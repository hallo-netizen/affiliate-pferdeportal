<?php
require_once __DIR__.'/fixture-builder.php';
$s=v34_semantic();$s['article_type']='Beratung';
$r=PPM679_Category_Assignment_Validator::derive_independent($s,v34_snapshot());
ppm_test_assert(empty($r['ok']),'unresolved semantics must block');
ppm_test_assert(strpos((string)($r['report']['status']??''),'BLOCKED_CATEGORY_SEMANTIC_UNRESOLVED')===0,'unresolved diagnosis');
echo "PASS_V34_SEMANTIC_UNRESOLVED_BLOCKED\n";
