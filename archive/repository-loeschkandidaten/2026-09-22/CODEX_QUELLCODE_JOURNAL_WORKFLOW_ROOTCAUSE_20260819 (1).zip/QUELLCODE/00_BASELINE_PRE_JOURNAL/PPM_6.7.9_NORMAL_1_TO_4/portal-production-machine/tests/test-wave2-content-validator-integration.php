<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

$meta=json_decode((string)file_get_contents(__DIR__.'/fixtures/wave2/positive-faq.json'),true);
$html=(string)file_get_contents(__DIR__.'/fixtures/wave2/positive-faq.html');
$generated=array(
    'article_type'=>'FAQ',
    'title'=>$meta['title'],
    'content_html'=>$html,
    'content_hash'=>hash('sha256',$html),
);
$item=array(
    'article_type'=>'FAQ',
    'target_keyword'=>'Pferdeanhänger',
    'quality_binding'=>$meta['quality_binding'],
    'quality_binding_hash'=>$meta['quality_binding_hash'],
    'runtime_order'=>$meta['runtime_order'],
    'source_snapshot_id'=>'missing-wave2-local-pack',
    'validation_contract_version'=>'',
);

$gold=PPM679_Content_Validator::check_gold_reference($generated,'wave2_gold_positive','local-wave2-state',$item);
ppm_test_assert(!empty($gold['ok']),'positive FAQ gold/control path must PASS');
ppm_test_assert(($gold['checks']['known_error_gate_status']??'')==='PASS','known error gate must PASS positive FAQ');
ppm_test_assert(($gold['checks']['content_structure_language_gate_status']??'')==='PASS','Wave-2 gate must PASS positive FAQ');
ppm_test_assert(($gold['checks']['fail_closed_aggregate_status']??'')==='PASS','fail-closed merge must PASS only when all gates pass');

$legacy=PPM679_Content_Validator::check($generated,$item,'wave2_legacy_path','local-wave2-state');
ppm_test_assert(empty($legacy['ok']),'legacy runtime path without bound fact pack must remain blocked');
ppm_test_assert(($legacy['checks']['content_structure_language_gate_status']??'')==='PASS','Wave-2 gate must execute and PASS on legacy path');
ppm_test_assert(($legacy['checks']['fail_closed_aggregate_status']??'')==='BLOCKED','base failure must block merged legacy result');

$v5_item=$item;
$v5_item['validation_contract_version']='SECTION_REQUIREMENTS_V1';
$v5=PPM679_Content_Validator::check($generated,$v5_item,'wave2_v5_path','local-wave2-state');
ppm_test_assert(empty($v5['ok']),'incomplete V5 payload must remain blocked');
ppm_test_assert(($v5['checks']['content_structure_language_gate_status']??'')==='PASS','Wave-2 gate must execute and PASS on V5 path');
ppm_test_assert(($v5['checks']['fail_closed_aggregate_status']??'')==='BLOCKED','V5 base failure must block merged result');

$unknown_item=$item;
$unknown_item['validation_contract_version']='UNKNOWN_WAVE2_CONTRACT';
$unknown=PPM679_Content_Validator::check($generated,$unknown_item,'wave2_unknown_path','local-wave2-state');
ppm_test_assert(empty($unknown['ok']),'unknown validation contract must block');
ppm_test_assert(($unknown['checks']['content_structure_language_gate_status']??'')==='PASS','Wave-2 gate must execute on unknown contract path');
ppm_test_assert(($unknown['checks']['fail_closed_aggregate_status']??'')==='BLOCKED','unknown contract must remain fail-closed');

$bad_meta=json_decode((string)file_get_contents(__DIR__.'/fixtures/wave1/known-bad-faq.json'),true);
$bad_html=(string)file_get_contents(__DIR__.'/fixtures/wave1/known-bad-faq.html');
$bad_generated=array('article_type'=>'FAQ','title'=>$bad_meta['title'],'content_html'=>$bad_html,'content_hash'=>hash('sha256',$bad_html));
$bad_item=array('article_type'=>'FAQ','runtime_order'=>array('links'=>array()),'source_snapshot_id'=>'missing','validation_contract_version'=>'');
$bad=PPM679_Content_Validator::check($bad_generated,$bad_item,'wave2_known_bad_path','local-wave2-state');
ppm_test_assert(empty($bad['ok']),'known bad FAQ must remain blocked');
ppm_test_assert(($bad['checks']['known_error_gate_status']??'')==='BLOCKED','known error gate must remain active');
ppm_test_assert(($bad['checks']['content_structure_language_gate_status']??'')==='BLOCKED','Wave-2 gate must also block known bad FAQ');
ppm_test_assert(($bad['checks']['fail_closed_aggregate_status']??'')==='BLOCKED','known bad FAQ must remain fail-closed');

$summary=array(
    'contract'=>'wave2_content_validator_integration_report_v1',
    'status'=>'PASS',
    'positive_gold_path'=>array(
        'known_error_gate_status'=>$gold['checks']['known_error_gate_status'],
        'content_structure_language_gate_status'=>$gold['checks']['content_structure_language_gate_status'],
        'fail_closed_aggregate_status'=>$gold['checks']['fail_closed_aggregate_status'],
    ),
    'legacy_path'=>array(
        'content_structure_language_gate_status'=>$legacy['checks']['content_structure_language_gate_status'],
        'fail_closed_aggregate_status'=>$legacy['checks']['fail_closed_aggregate_status'],
    ),
    'v5_path'=>array(
        'content_structure_language_gate_status'=>$v5['checks']['content_structure_language_gate_status'],
        'fail_closed_aggregate_status'=>$v5['checks']['fail_closed_aggregate_status'],
    ),
    'unknown_path'=>array(
        'content_structure_language_gate_status'=>$unknown['checks']['content_structure_language_gate_status'],
        'fail_closed_aggregate_status'=>$unknown['checks']['fail_closed_aggregate_status'],
    ),
    'known_bad_path'=>array(
        'known_error_gate_status'=>$bad['checks']['known_error_gate_status'],
        'content_structure_language_gate_status'=>$bad['checks']['content_structure_language_gate_status'],
        'fail_closed_aggregate_status'=>$bad['checks']['fail_closed_aggregate_status'],
    ),
);
echo json_encode($summary,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
