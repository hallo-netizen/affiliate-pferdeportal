<?php
require_once __DIR__.'/fixture-builder.php';
$p=v31_prepare('g9-request-v31-readback-current-0009',false);$w=v31_write_prepared($p);ppm_test_assert($w['ok']===true,'write');
$s=PPM679_WP::get_post_snapshot($w['post_id']);
$ctx=array('evidence_class'=>'SERVER_USER_TRIGGERED_TEST','user_triggered'=>true,'publish_event_count'=>0,'captured_at'=>gmdate('c'),'server_instance_id'=>'ppm-test-instance-679','request_id'=>'g9-request-v31-readback-stale-0009','artifact_id'=>'v31-stale-readback');
$r=PPM679_WP_Readback_Validator::validate($s,$w['expected'],$ctx);
ppm_test_assert($r['ok']===false,'stale readback must block');
ppm_test_assert(v31_status($r)==='BLOCKED_QF03_STALE_READBACK_REQUEST','stale request diagnosis');
echo json_encode(array('status'=>'PASS_V31_S09_STALE_READBACK','blocker'=>v31_status($r)),JSON_UNESCAPED_SLASHES)."\n";
