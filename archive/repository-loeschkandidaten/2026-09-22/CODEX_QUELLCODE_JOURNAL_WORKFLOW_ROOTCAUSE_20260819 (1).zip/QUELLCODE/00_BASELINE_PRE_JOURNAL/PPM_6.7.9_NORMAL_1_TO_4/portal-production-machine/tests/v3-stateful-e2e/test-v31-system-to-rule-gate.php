<?php
require_once __DIR__.'/fixture-builder.php';
$c=json_decode(file_get_contents(dirname(__DIR__,2).'/contracts/system-inventory-v3-1.json'),true);
$bad=$c['findings'][0];$bad['hard_rule_ids']=array();
$blocked=empty($bad['hard_rule_ids'])||empty($bad['positive_scenario_ids'])||empty($bad['negative_scenario_ids']);
ppm_test_assert($blocked,'finding without rule/scenario mapping must block');
ppm_test_assert(PPM679_System_Inventory_Validator::validate()===array(),'active mapping passes');
echo json_encode(array('status'=>'PASS_V31_SYSTEM_TO_RULE_GATE','negative_mapping_detected'=>true,'system_unmapped'=>0),JSON_UNESCAPED_SLASHES)."\n";
