<?php
require_once dirname(__DIR__).'/bootstrap-test.php'; require_once __DIR__.'/fixture-builder.php';
$hash=hash('sha256',qf03_article_html()); $expected=array('title'=>'Was muss vor einer Fahrt geprüft werden?','post_id'=>101,'readback_content_hash'=>$hash);
$requests=PPM679_Rendered_DOM_Validator::build_capture_request_set(101,'https://example.test/?p=101',$hash); ppm_test_assert($requests['ok']===true && $requests['capture_executed']===false,'Capture requests must be prepared but not executed locally');
$r=PPM679_Rendered_DOM_Validator::validate_pair(qf03_capture_fixture('desktop',101,$hash),qf03_capture_fixture('mobile',101,$hash),$expected);
ppm_test_assert($r['ok']===true,'Desktop and mobile rendered DOM must pass'); ppm_test_assert($r['RENDERED_DOM_STATUS']==='PASS','Rendered status');
ppm_test_assert($r['report']['user_visual_inspection_status']==='REQUIRED_NOT_YET_COMPLETED','Machine DOM pass must not claim user visual acceptance');
echo json_encode(array('status'=>'PASS','rendered_dom_status'=>$r['RENDERED_DOM_STATUS'],'desktop_h1'=>$r['report']['RENDERED_VISIBLE_H1_COUNT']['desktop'],'mobile_h1'=>$r['report']['RENDERED_VISIBLE_H1_COUNT']['mobile'],'visual_acceptance'=>$r['report']['user_visual_inspection_status'],'capture_request_status'=>$requests['status'],'capture_executed'=>$requests['capture_executed']),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
