<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

$meta=json_decode((string)file_get_contents(__DIR__.'/fixtures/wave2/positive-faq.json'),true);
$html=(string)file_get_contents(__DIR__.'/fixtures/wave2/positive-faq.html');
ppm_test_assert(is_array($meta),'positive fixture metadata must decode');
ppm_test_assert(hash('sha256',$html)===(string)$meta['body_html_sha256'],'positive fixture HTML hash must match');
ppm_test_assert(PPM679_Diagnostic::stable_hash($meta['quality_binding'])===(string)$meta['quality_binding_hash'],'quality binding hash must match');
$generated=array(
    'article_type'=>'FAQ',
    'title'=>$meta['title'],
    'content_html'=>$html,
    'content_hash'=>hash('sha256',$html),
);
$item=array(
    'article_type'=>'FAQ',
    'quality_binding'=>$meta['quality_binding'],
    'quality_binding_hash'=>$meta['quality_binding_hash'],
    'runtime_order'=>$meta['runtime_order'],
);
$result=PPM679_Content_Structure_Language_Gate::evaluate($generated,$item,'wave2_positive_control','local-wave2-state');
if (empty($result['ok'])) {
    fwrite(STDERR,json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");
}
ppm_test_assert(!empty($result['ok']),'positive FAQ must pass Wave-2 gate');
ppm_test_assert(($result['content_structure_language_gate_status']??'')==='PASS','Wave-2 status must be PASS');
ppm_test_assert(empty($result['errors']),'positive FAQ must have zero Wave-2 errors');

echo json_encode(array(
    'contract'=>'wave2_content_structure_language_positive_report_v1',
    'status'=>'PASS',
    'article_type'=>'FAQ',
    'content_hash'=>hash('sha256',$html),
    'language_evidence_hash'=>$meta['quality_binding']['language_evidence']['raw_report_sha256'],
    'gate_status'=>$result['content_structure_language_gate_status'],
    'checks'=>$result['checks'],
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
