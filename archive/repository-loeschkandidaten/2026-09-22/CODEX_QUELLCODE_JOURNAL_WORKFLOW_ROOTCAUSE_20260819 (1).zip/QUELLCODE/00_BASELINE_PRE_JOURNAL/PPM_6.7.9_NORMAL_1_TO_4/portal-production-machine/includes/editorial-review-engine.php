<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Editorial_Review_Engine {
    const VERSION='6.7.9-wave3-quarantine';

    public static function evaluate($input,$context='wave3_editorial_review_engine',$server_state_hash='') {
        $input=is_array($input)?$input:array();
        $current=(array)($input['current_bindings']??array());
        $evidence_set=(array)($input['evidence_set']??array());
        $registry=PPM679_Evidence_Registry::validate_set($evidence_set,$current,$context.'.evidence',$server_state_hash);
        $status_gate=PPM679_Status_Gate::evaluate(
            (array)($input['statuses']??array()),
            (array)($registry['evidence_by_id']??array()),
            (array)($input['evidence_ids_by_status']??array()),
            null,
            $context.'.statuses',
            $server_state_hash
        );
        $independent_verified=($status_gate['statuses']['EDITORIAL_REVIEW_STATUS']??'')==='PASS'
            && ($status_gate['statuses']['GOLD_CORE_REVIEW_GATE']??'')==='PASS';
        $matrix=PPM679_Review_Matrix_Validator::validate(
            (array)($input['review']??array()),
            (array)($input['document']??array()),
            (array)($input['gold_reference']??array()),
            array('independent_review_verified'=>$independent_verified),
            $context.'.matrix',
            $server_state_hash
        );
        $errors=array_merge((array)($registry['errors']??array()),(array)($status_gate['errors']??array()),(array)($matrix['errors']??array()));
        $machine_statuses=(array)($input['prior_machine_statuses']??array());
        $ok=!$errors
            && ($matrix['editorial_review_status']??'')==='PASS'
            && ($status_gate['statuses']['EDITORIAL_REVIEW_STATUS']??'')==='PASS'
            && ($status_gate['statuses']['GOLD_CORE_REVIEW_GATE']??'')==='PASS';
        return array(
            'ok'=>$ok,
            'editorial_engine_status'=>$ok?'PASS':'BLOCKED',
            'editorial_review_status'=>$matrix['editorial_review_status']??'BLOCKED',
            'gold_core_review_gate'=>$matrix['gold_core_review_gate']??'BLOCKED',
            'machine_statuses_observed_but_not_inherited'=>$machine_statuses,
            'evidence_registry'=>$registry,
            'status_gate'=>$status_gate,
            'review_matrix'=>$matrix,
            'errors'=>$errors,
            'production_allowed'=>false,
            'draft_create_allowed'=>false,
            'publish_allowed'=>false,
            'article_types_production_blocked'=>array('FAQ','Beratung','Vergleich','Pflege'),
            'scope_limit'=>'Wave-3 quarantine only. A prior machine PASS never creates editorial PASS; independent raw-evidence review remains mandatory.'
        );
    }
}
