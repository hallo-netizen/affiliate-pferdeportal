<?php
if (!defined('ABSPATH')) { return; }

/**
 * Test-only FAQ release validation for the separately authorized G9 path.
 * It never changes the global four-type production release contract.
 */
final class PPM679_G9_FAQ_Test_Release_Validator {
    const VERSION='6.7.9';
    const CONTRACT_FILE='contracts/g9-faq-only-test-release-v1.json';
    const APPROVED_CANDIDATE_FILE='contracts/g9-single-faq-approved-candidate-v1.json';
    const CONTRACT='G9_FAQ_ONLY_TEST_RELEASE_GATE_V1';
    const SCOPE_MODE='G9_SINGLE_FAQ_SERVER_TEST_ONLY';
    const ACTION_CONTEXT='g9_single_faq_pre_draft';
    const ARTICLE_TYPE='FAQ';
    const ARTICLE_SHA256='075b125e243205581639b84b1b499f9509f6f91389407aedbbe6d1aa5e8ac995';
    const QUALITY_BINDING_SHA256='0f78cebd3c202e09187fae834e176602a75ec7ce726f823451110e5aad6abffc';
    const REVIEW_VERDICT='CONFIRM_PASS_MAINBLOCK1_CONSOLIDATED_RULE_COVERAGE_SIGNED_BUILD';

    public static function expected_scope() {
        return array(
            'contract'=>self::CONTRACT,
            'scope_mode'=>self::SCOPE_MODE,
            'requested_article_types'=>array(self::ARTICLE_TYPE),
            'release_contract_sha256'=>self::file_hash(self::CONTRACT_FILE),
            'approved_candidate_contract_sha256'=>self::file_hash(self::APPROVED_CANDIDATE_FILE),
            'article_sha256'=>self::ARTICLE_SHA256,
            'quality_binding_sha256'=>self::QUALITY_BINDING_SHA256,
            'global_four_type_validation_bypassed'=>false,
            'global_four_type_contract_modified'=>false,
            'publish_allowed'=>false,
        );
    }

    public static function validate($action_context,$server_state_hash,$scope,$contract_override=null,$candidate_override=null) {
        $errors=array();
        if ((string)$action_context!==self::ACTION_CONTEXT) {
            $errors[]=self::err('BLOCKED_G9_FAQ_RELEASE_ACTION_CONTEXT','G9_FAQ_TEST_RELEASE_IS_VALID_ONLY_FOR_EXACT_G9_PRE_DRAFT_CONTEXT','action_context',self::ACTION_CONTEXT,$action_context,'Die FAQ-Testfreigabe wurde außerhalb des fest gebundenen G9-Vorlaufs angefordert.',$action_context,$server_state_hash);
        }
        if (!is_array($scope)) {
            return array_merge($errors,array(self::err('BLOCKED_G9_FAQ_RELEASE_SCOPE_MISSING','G9_FAQ_TEST_RELEASE_REQUIRES_EXPLICIT_SCOPE','requirements.article_type_release_scope','exact scope object',$scope,'Die explizite FAQ-Testfreigabe fehlt.',$action_context,$server_state_hash)));
        }
        $expected=self::expected_scope();
        foreach ($expected as $field=>$value) {
            $actual=array_key_exists($field,$scope)?$scope[$field]:null;
            if (PPM679_Diagnostic::stable_hash($actual)!==PPM679_Diagnostic::stable_hash($value)) {
                $errors[]=self::err('BLOCKED_G9_FAQ_RELEASE_SCOPE_MISMATCH','G9_FAQ_TEST_RELEASE_SCOPE_MUST_MATCH_EXACT_APPROVED_BINDING','requirements.article_type_release_scope.'.$field,$value,$actual,'Die G9-Testfreigabe weicht von der exakt bestätigten FAQ-Bindung ab.',$action_context,$server_state_hash);
            }
        }

        if ($contract_override!==null && !PPM679_WP::is_test_mode()) {
            $errors[]=self::err('BLOCKED_G9_FAQ_RELEASE_CONTRACT_OVERRIDE','G9_FAQ_RELEASE_CONTRACT_OVERRIDE_ALLOWED_ONLY_IN_LOCAL_TEST_MODE','contract_override',null,'provided','Ein Vertrags-Override ist außerhalb des lokalen Tests verboten.',$action_context,$server_state_hash);
        }
        if ($candidate_override!==null && !PPM679_WP::is_test_mode()) {
            $errors[]=self::err('BLOCKED_G9_FAQ_CANDIDATE_OVERRIDE','G9_FAQ_CANDIDATE_OVERRIDE_ALLOWED_ONLY_IN_LOCAL_TEST_MODE','candidate_override',null,'provided','Ein Kandidaten-Override ist außerhalb des lokalen Tests verboten.',$action_context,$server_state_hash);
        }
        $contract=$contract_override!==null?$contract_override:self::load(self::CONTRACT_FILE);
        $candidate=$candidate_override!==null?$candidate_override:self::load(self::APPROVED_CANDIDATE_FILE);
        if (!is_array($contract)) {
            return array_merge($errors,array(self::err('BLOCKED_G9_FAQ_RELEASE_CONTRACT_MISSING','G9_FAQ_TEST_RELEASE_CONTRACT_MUST_EXIST','contract',self::CONTRACT,$contract,'Der FAQ-Testfreigabevertrag fehlt oder ist ungültig.',$action_context,$server_state_hash)));
        }
        $self=(string)($contract['contract_self_sha256']??''); $copy=$contract; unset($copy['contract_self_sha256']);
        $actual_self=PPM679_Diagnostic::stable_hash($copy);
        if ($self==='' || !hash_equals($self,$actual_self)) {
            $errors[]=self::err('BLOCKED_G9_FAQ_RELEASE_CONTRACT_SELF_HASH','G9_FAQ_TEST_RELEASE_CONTRACT_SELF_HASH_MUST_MATCH','contract.contract_self_sha256',$actual_self,$self,'Der FAQ-Testfreigabevertrag wurde verändert.',$action_context,$server_state_hash);
        }
        $pairs=array(
            'contract'=>array(self::CONTRACT,$contract['contract']??null),
            'scope_mode'=>array(self::SCOPE_MODE,$contract['scope_mode']??null),
            'action_context'=>array(self::ACTION_CONTEXT,$contract['action_context']??null),
            'requested_article_types'=>array(array(self::ARTICLE_TYPE),$contract['requested_article_types']??null),
            'global_four_type_contract_sha256'=>array(self::file_hash('contracts/article-type-templates.json'),$contract['global_four_type_contract_sha256']??null),
            'approved_candidate_contract_sha256'=>array(self::file_hash(self::APPROVED_CANDIDATE_FILE),$contract['approved_candidate_contract_sha256']??null),
            'canonical_article_sha256'=>array(self::ARTICLE_SHA256,$contract['canonical_article_sha256']??null),
            'quality_binding_sha256'=>array(self::QUALITY_BINDING_SHA256,$contract['quality_binding_sha256']??null),
            'required_independent_review_verdict'=>array(self::REVIEW_VERDICT,$contract['required_independent_review_verdict']??null),
            'test_execution_allowed'=>array(true,$contract['test_execution_allowed']??null),
            'global_production_release_allowed'=>array(false,$contract['global_production_release_allowed']??null),
            'publish_allowed'=>array(false,$contract['publish_allowed']??null),
            'four_type_validator_may_be_weakened'=>array(false,$contract['four_type_validator_may_be_weakened']??null),
            'remaining_live_state_gates_may_be_skipped'=>array(false,$contract['remaining_live_state_gates_may_be_skipped']??null),
        );
        foreach ($pairs as $field=>$pair) {
            if (PPM679_Diagnostic::stable_hash($pair[0])!==PPM679_Diagnostic::stable_hash($pair[1])) {
                $errors[]=self::err('BLOCKED_G9_FAQ_RELEASE_CONTRACT_BINDING','G9_FAQ_TEST_RELEASE_CONTRACT_FIELD_MUST_MATCH_EXACT_VALUE','contract.'.$field,$pair[0],$pair[1],'Eine feste FAQ-Testfreigabebindung weicht ab.',$action_context,$server_state_hash);
            }
        }

        $types=PPM679_Article_Type_Validator::load_contract();
        $required=array('FAQ','Beratung','Vergleich','Pflege');
        foreach ($required as $index=>$type) {
            $spec=is_array($types)&&isset($types['types'][$type])&&is_array($types['types'][$type])?$types['types'][$type]:null;
            if (!is_array($spec)) {
                $errors[]=self::err('BLOCKED_G9_FAQ_GLOBAL_TYPE_MISSING','G9_FAQ_TEST_REQUIRES_UNCHANGED_FOUR_TYPE_CONTRACT','types.'.$type,'defined type',$spec,'Der globale Vier-Typ-Vertrag ist unvollständig.',$action_context,$server_state_hash,$index);
                continue;
            }
            if (($spec['production_allowed']??null)!==false) {
                $errors[]=self::err('BLOCKED_G9_FAQ_GLOBAL_RELEASE_CHANGED','G9_FAQ_TEST_MUST_NOT_GLOBALLY_RELEASE_ANY_ARTICLE_TYPE','types.'.$type.'.production_allowed',false,$spec['production_allowed']??null,'Die G9-Testfreigabe darf keinen Beitragstyp global freischalten.',$action_context,$server_state_hash,$index);
            }
        }

        if (!is_array($candidate)) {
            return array_merge($errors,array(self::err('BLOCKED_G9_FAQ_APPROVED_CANDIDATE_MISSING','G9_FAQ_TEST_REQUIRES_APPROVED_CANDIDATE_CONTRACT','candidate',self::APPROVED_CANDIDATE_FILE,$candidate,'Der unabhängig geprüfte FAQ-Kandidatenvertrag fehlt.',$action_context,$server_state_hash)));
        }
        $review=$candidate['independent_editorial_review']??array();
        $candidate_pairs=array(
            'contract'=>array('G9_SINGLE_FAQ_APPROVED_CANDIDATE_V1',$candidate['contract']??null),
            'article_type'=>array(self::ARTICLE_TYPE,$candidate['article_type']??null),
            'canonical_content_sha256'=>array(self::ARTICLE_SHA256,$candidate['canonical_content_sha256']??null),
            'quality_binding_sha256'=>array(self::QUALITY_BINDING_SHA256,$candidate['quality_binding_sha256']??null),
            'required_mainblock1_review_verdict'=>array(self::REVIEW_VERDICT,$review['mainblock1_required_verdict']??null),
            'mainblock1_review_status_before_external_review'=>array('REQUIRED_NOT_YET_OBTAINED',$review['mainblock1_status']??null),
            'external_review_not_falsely_claimed'=>array(false,$review['mainblock1_external_review_claimed_by_build']??null),
        );
        foreach ($candidate_pairs as $field=>$pair) {
            if ((string)$pair[0] !== (string)$pair[1]) {
                $errors[]=self::err('BLOCKED_G9_FAQ_APPROVED_CANDIDATE_BINDING','G9_FAQ_TEST_REQUIRES_EXACT_INDEPENDENTLY_APPROVED_CANDIDATE','candidate.'.$field,$pair[0],$pair[1],'Der FAQ-Test ist nicht an den exakt unabhängig bestätigten Kandidaten gebunden.',$action_context,$server_state_hash);
            }
        }
        return $errors;
    }

    private static function load($relative) {
        $file=PPM679_PLUGIN_DIR.$relative;
        if (!is_file($file)) { return null; }
        $decoded=json_decode((string)file_get_contents($file),true);
        return is_array($decoded)?$decoded:null;
    }
    private static function file_hash($relative) {
        $file=PPM679_PLUGIN_DIR.$relative;
        return is_file($file)?hash_file('sha256',$file):'';
    }
    private static function err($code,$rule,$path,$expected,$actual,$reason,$context,$hash,$index=null) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$context,$hash,__CLASS__,$index,array(self::CONTRACT_FILE,self::APPROVED_CANDIDATE_FILE,'contracts/article-type-templates.json'));
    }
}
