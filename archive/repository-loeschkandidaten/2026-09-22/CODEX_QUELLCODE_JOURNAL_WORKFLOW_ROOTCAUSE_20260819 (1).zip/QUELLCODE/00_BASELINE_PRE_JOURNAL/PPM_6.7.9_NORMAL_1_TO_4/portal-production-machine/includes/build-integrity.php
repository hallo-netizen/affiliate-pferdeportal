<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Build_Integrity {
    const VERSION = '6.7.9';

    public static function verify($context, $server_state_hash = '') {
        $manifest_file = PPM679_PLUGIN_DIR . 'certification/build-manifest-v1.json';
        $signature_file = PPM679_PLUGIN_DIR . 'certification/build-manifest-v1.sig';
        $errors = array();

        if (!is_file($manifest_file) || !is_file($signature_file)) {
            $errors[] = PPM679_Diagnostic::error(
                'BLOCKED_BUILD_MANIFEST_MISSING',
                'SIGNED_BUILD_MANIFEST_MUST_EXIST',
                'certification.build_manifest',
                'manifest and detached signature',
                array('manifest'=>is_file($manifest_file),'signature'=>is_file($signature_file)),
                'Die aktive Pluginquelle besitzt keinen vollständigen signierten Buildnachweis.',
                $context,
                $server_state_hash,
                __CLASS__,
                null,
                array('certification/build-manifest-v1.json','certification/build-manifest-v1.sig')
            );
            return $errors;
        }

        $manifest_bytes = (string) file_get_contents($manifest_file);
        $manifest = json_decode($manifest_bytes, true);
        if (!is_array($manifest)) {
            $errors[] = PPM679_Diagnostic::error(
                'BLOCKED_BUILD_MANIFEST_INVALID',
                'BUILD_MANIFEST_MUST_BE_VALID_JSON',
                'certification/build_manifest',
                'valid JSON',
                $manifest_bytes,
                'Der Buildnachweis ist nicht lesbar.',
                $context,
                $server_state_hash,
                __CLASS__,
                null,
                array('certification/build-manifest-v1.json')
            );
            return $errors;
        }

        if (!function_exists('sodium_crypto_sign_verify_detached')) {
            $errors[] = PPM679_Diagnostic::error(
                'BLOCKED_BUILD_SIGNATURE_RUNTIME_UNAVAILABLE',
                'SODIUM_SIGNATURE_VERIFICATION_MUST_BE_AVAILABLE',
                'runtime.sodium_crypto_sign_verify_detached',
                true,
                false,
                'Die Pluginaktion wird blockiert, weil der signierte Buildnachweis nicht verifiziert werden kann. WordPress bleibt erreichbar.',
                $context,
                $server_state_hash,
                __CLASS__,
                null,
                array('certification/build-manifest-v1.sig')
            );
            return $errors;
        }

        $signature = base64_decode(trim((string) file_get_contents($signature_file)), true);
        $public = base64_decode((string) PPM679_BUILD_PUBLIC_KEY_B64, true);
        $signature_ok = is_string($signature) && is_string($public) && sodium_crypto_sign_verify_detached($signature, $manifest_bytes, $public);
        if (!$signature_ok) {
            $errors[] = PPM679_Diagnostic::error(
                'BLOCKED_BUILD_SIGNATURE_INVALID',
                'BUILD_MANIFEST_SIGNATURE_MUST_VERIFY',
                'certification.build_manifest.signature',
                'valid Ed25519 signature',
                'invalid',
                'Der Buildnachweis passt nicht zum fest eingebauten öffentlichen Schlüssel.',
                $context,
                $server_state_hash,
                __CLASS__,
                null,
                array('certification/build-manifest-v1.json','certification/build-manifest-v1.sig')
            );
            return $errors;
        }

        $files = isset($manifest['files']) && is_array($manifest['files']) ? $manifest['files'] : array();
        foreach ($files as $relative => $expected) {
            $file = PPM679_PLUGIN_DIR . ltrim((string) $relative, '/');
            $actual = is_file($file) ? hash_file('sha256', $file) : null;
            if (!is_string($expected) || !is_string($actual) || !hash_equals($expected, $actual)) {
                $errors[] = PPM679_Diagnostic::error(
                    'BLOCKED_ACTIVE_COMPONENT_HASH_MISMATCH',
                    'ACTIVE_COMPONENT_HASH_MUST_MATCH_SIGNED_BUILD_MANIFEST',
                    'build.files.' . $relative,
                    $expected,
                    $actual,
                    'Eine aktive Plugin-, Vertrags- oder Testfixture-Datei weicht vom signierten Build ab.',
                    $context,
                    $server_state_hash,
                    __CLASS__,
                    null,
                    array($relative,'certification/build-manifest-v1.json')
                );
            }
        }
        return $errors;
    }
}
