<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Evidence_Registry {
    const VERSION='6.7.9-wave3-quarantine';
    const CLASSES=array('STATIC_CODE_INSPECTION','LOCAL_EXECUTED_TEST','SERVER_USER_TRIGGERED_TEST');
    const REQUIRED_FIELDS=array(
        'evidence_id','evidence_class','input_file','input_hash','content_hash','plan_hash','fact_pack_hash',
        'rule_catalog_hash','review_matrix_schema_hash','review_evidence_schema_hash','quote_reuse_policy_hash',
        'gold_reference_hash','portal_ist_hash','tool_name','tool_version','tool_source_hash','command','exit_code',
        'raw_output_file','raw_output_hash','generated_at'
    );
    const MODEL_FIELDS=array(
        'review_provider','review_model_identifier','review_model_version','review_context_hash',
        'review_prompt_hash','review_parameters_hash','independence_declaration'
    );

    public static function validate_set($evidence_set,$current,$context='wave3_evidence_registry',$server_state_hash='') {
        $evidence_set=is_array($evidence_set)?$evidence_set:array();
        $errors=array();
        $contract=self::load_contract();
        $schema=(array)($contract['schema']??array());
        $declared=(string)($contract['schema_hash']??'');
        $actual=PPM679_Diagnostic::stable_hash($schema);
        if ($declared==='' || !hash_equals($actual,$declared)) {
            $errors[]=self::err('EVIDENCE_REGISTRY_CONTRACT_HASH_MISMATCH','EVIDENCE_REGISTRY_SCHEMA_MUST_MATCH_DECLARED_CANONICAL_HASH','contracts/evidence-registry-v1.json.schema_hash',$actual,$declared,'Der Evidenzregistervertrag wurde verändert oder ist nicht kanonisch gebunden.',$context,$server_state_hash);
        }
        if ((array)($schema['allowed_evidence_classes']??array())!==self::CLASSES || (array)($schema['required_fields']??array())!==self::REQUIRED_FIELDS || (array)($schema['model_review_fields']??array())!==self::MODEL_FIELDS) {
            $errors[]=self::err('EVIDENCE_REGISTRY_CONTRACT_CODE_DRIFT','EVIDENCE_REGISTRY_CONTRACT_AND_RUNTIME_CONSTANTS_MUST_MATCH','contracts/evidence-registry-v1.json.schema','exact runtime constants',$schema,'Vertrag und ausführbarer Evidenzregistercode sind auseinandergelaufen.',$context,$server_state_hash);
        }
        $validated=array();
        $ids=array();
        foreach ($evidence_set as $index=>$evidence) {
            $result=self::validate_one($evidence,$current,$context.'.'.$index,$server_state_hash);
            $validated[]=$result;
            $errors=array_merge($errors,$result['errors']);
            $id=(string)($evidence['evidence_id']??'');
            if ($id!=='' && isset($ids[$id])) {
                $errors[]=self::err('EVIDENCE_ID_DUPLICATE','EVIDENCE_ID_MUST_BE_UNIQUE','evidence_set.'.$index.'.evidence_id','unique evidence_id',$id,'Eine Beleg-ID darf nicht mehrfach registriert werden.',$context,$server_state_hash,array($id));
            }
            if ($id!=='') { $ids[$id]=true; }
        }
        return array(
            'ok'=>!$errors,
            'status'=>!$errors?'PASS':'BLOCKED',
            'evidence_registry_status'=>!$errors?'PASS':'BLOCKED',
            'validated_evidence'=>$validated,
            'evidence_by_id'=>self::index_by_id($evidence_set),
            'errors'=>$errors,
            'production_allowed'=>false,
            'draft_create_allowed'=>false,
            'publish_allowed'=>false,
        );
    }

    public static function validate_one($evidence,$current,$context='wave3_evidence',$server_state_hash='') {
        $evidence=is_array($evidence)?$evidence:array();
        $current=is_array($current)?$current:array();
        $errors=array();
        foreach (self::REQUIRED_FIELDS as $field) {
            if (!array_key_exists($field,$evidence) || (is_string($evidence[$field]) && trim($evidence[$field])==='')) {
                $errors[]=self::err('EVIDENCE_REQUIRED_FIELD_MISSING','EVERY_EVIDENCE_RECORD_REQUIRES_ALL_BOUND_FIELDS','evidence.'.$field,'present non-empty field',$evidence[$field]??null,'Der verbindliche Belegdatensatz ist unvollständig.',$context,$server_state_hash,array((string)($evidence['evidence_id']??'')));
            }
        }
        $id=(string)($evidence['evidence_id']??'');
        if ($id!=='' && preg_match('/^[A-Z0-9][A-Z0-9._:-]{7,160}$/',$id)!==1) {
            $errors[]=self::err('EVIDENCE_ID_INVALID','EVIDENCE_ID_MUST_BE_EXACT_AND_STABLE','evidence.evidence_id','stable uppercase evidence id',$id,'Die Beleg-ID ist nicht eindeutig oder nicht stabil formatiert.',$context,$server_state_hash,array($id));
        }
        $class=(string)($evidence['evidence_class']??'');
        if (!in_array($class,self::CLASSES,true)) {
            $errors[]=self::err('EVIDENCE_CLASS_INVALID','EVIDENCE_MUST_HAVE_EXACTLY_ONE_ALLOWED_ORIGIN_CLASS','evidence.evidence_class',self::CLASSES,$class,'Jeder Beleg muss genau einer zulässigen Herkunftsklasse zugeordnet sein.',$context,$server_state_hash,array($id));
        }
        foreach (array('input_hash','content_hash','plan_hash','rule_catalog_hash','review_matrix_schema_hash','review_evidence_schema_hash','quote_reuse_policy_hash','tool_source_hash') as $field) {
            if (!self::hash_or_na($evidence[$field]??null,false)) {
                $errors[]=self::err('EVIDENCE_HASH_INVALID','EVIDENCE_BOUND_HASH_MUST_BE_SHA256','evidence.'.$field,'64 hexadecimal SHA-256',(string)($evidence[$field]??''),'Ein zwingend gebundener Hash ist ungültig.',$context,$server_state_hash,array($id));
            }
        }
        foreach (array('fact_pack_hash','gold_reference_hash','portal_ist_hash') as $field) {
            if (!self::hash_or_na($evidence[$field]??null,true)) {
                $errors[]=self::err('EVIDENCE_HASH_OR_NA_INVALID','OPTIONAL_BINDING_MUST_BE_SHA256_OR_NOT_APPLICABLE','evidence.'.$field,'64 hexadecimal SHA-256 or NOT_APPLICABLE',(string)($evidence[$field]??''),'Ein optionaler gebundener Wert ist weder Hash noch ausdrücklich NOT_APPLICABLE.',$context,$server_state_hash,array($id));
            }
        }
        if (isset($evidence['exit_code']) && !is_int($evidence['exit_code'])) {
            $errors[]=self::err('EVIDENCE_EXIT_CODE_INVALID','EXECUTED_EVIDENCE_REQUIRES_INTEGER_EXIT_CODE','evidence.exit_code','integer',$evidence['exit_code'],'Der Exit-Code muss als Integer vorliegen.',$context,$server_state_hash,array($id));
        }
        if (!empty($evidence['model_assisted_review'])) {
            foreach (self::MODEL_FIELDS as $field) {
                if (!array_key_exists($field,$evidence) || $evidence[$field]==='' || $evidence[$field]===null) {
                    $errors[]=self::err('REVIEW_MODEL_IDENTITY_UNVERIFIED','MODEL_REVIEW_REQUIRES_EXACT_PROVIDER_MODEL_VERSION_CONTEXT_PROMPT_PARAMETERS_AND_INDEPENDENCE','evidence.'.$field,'verified model-review field',$evidence[$field]??null,'Die konkrete Modellkennung oder Unabhängigkeit ist nicht nachweisbar.',$context,$server_state_hash,array($id));
                }
            }
            foreach (array('review_context_hash','review_prompt_hash','review_parameters_hash') as $field) {
                if (!self::hash_or_na($evidence[$field]??null,false)) {
                    $errors[]=self::err('REVIEW_MODEL_IDENTITY_UNVERIFIED','MODEL_REVIEW_HASH_FIELDS_MUST_BE_SHA256','evidence.'.$field,'64 hexadecimal SHA-256',(string)($evidence[$field]??''),'Die Modellreview-Bindung ist nicht hashverifiziert.',$context,$server_state_hash,array($id));
                }
            }
            if (($evidence['independence_declaration']??false)!==true) {
                $errors[]=self::err('REVIEW_INDEPENDENCE_UNVERIFIED','MODEL_REVIEW_MUST_DECLARE_INDEPENDENT_RAW_EVIDENCE_INSPECTION','evidence.independence_declaration',true,$evidence['independence_declaration']??null,'Ein früheres Maschinen-PASS darf nicht lediglich übernommen werden.',$context,$server_state_hash,array($id));
            }
        }
        $raw_file=(string)($evidence['raw_output_file']??'');
        $raw_hash=(string)($evidence['raw_output_hash']??'');
        if ($raw_file!=='' && is_file($raw_file)) {
            $actual=hash_file('sha256',$raw_file);
            if (!hash_equals($raw_hash,$actual)) {
                $errors[]=self::err('EVIDENCE_RAW_OUTPUT_HASH_MISMATCH','RAW_OUTPUT_FILE_MUST_MATCH_DECLARED_HASH','evidence.raw_output_hash',$actual,$raw_hash,'Die Rohausgabe stimmt nicht mit dem gebundenen Hash überein.',$context,$server_state_hash,array($id,$raw_file));
            }
        } else if ($raw_file!=='') {
            $errors[]=self::err('EVIDENCE_RAW_OUTPUT_FILE_MISSING','RAW_OUTPUT_FILE_MUST_EXIST','evidence.raw_output_file','existing file',$raw_file,'Die angegebene Rohausgabe ist nicht vorhanden.',$context,$server_state_hash,array($id,$raw_file));
        }
        $expiry=PPM679_Evidence_Expiry_Validator::evaluate($evidence,$current,$context.'.expiry',$server_state_hash);
        $errors=array_merge($errors,$expiry['errors']);
        return array(
            'ok'=>!$errors,
            'status'=>!$errors?'PASS':'BLOCKED',
            'evidence_id'=>$id,
            'evidence_class'=>$class,
            'is_model_review'=>!empty($evidence['model_assisted_review']),
            'expiry_status'=>$expiry['evidence_expiry_status'],
            'errors'=>$errors,
        );
    }


    public static function load_contract() {
        $file=defined('PPM679_PLUGIN_DIR')?PPM679_PLUGIN_DIR.'contracts/evidence-registry-v1.json':'';
        $data=$file!==''&&is_file($file)?json_decode((string)file_get_contents($file),true):null;
        return is_array($data)?$data:array();
    }

    private static function index_by_id($records) {
        $out=array();
        foreach ((array)$records as $record) {
            $id=(string)($record['evidence_id']??'');
            if ($id!=='') { $out[$id]=$record; }
        }
        return $out;
    }

    private static function hash_or_na($value,$allow_na) {
        $value=(string)$value;
        if ($allow_na && $value==='NOT_APPLICABLE') { return true; }
        return preg_match('/^[0-9a-f]{64}$/',$value)===1;
    }

    private static function err($code,$rule,$path,$expected,$actual,$reason,$context,$server_state_hash,$refs=array()) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$context,$server_state_hash,__CLASS__,null,$refs);
    }
}
