<?php
require_once __DIR__.'/fixture-builder.php';
PPM679_WP::reset_test_state();PPM679_Storage::reset_test_state();v31_seed_foreign_slug();
$c=v31_candidate();$id=PPM679_Stateful_Write_Gate::build_identity('canonical-faq-001','ppm-test-instance-679',v31_build_hash(),'g9-request-v31-foreign-slug-0004');
ppm_test_assert($id['ok']===true,'identity');
$g=v31_gate(hash('sha256',$c['content_html']),$id['identity']['request_id']);
$p=PPM679_Stateful_Write_Gate::prepare_single_faq_plan($c,$g,$id['identity'],v31_quality_hash());
ppm_test_assert($p['ok']===false,'foreign slug must block');
ppm_test_assert(v31_status($p)==='BLOCKED_QF03_SLUG_COLLISION_FOREIGN_OBJECT','distinct foreign diagnosis');
ppm_test_assert(count(PPM679_WP::test_posts())===1,'no draft');
echo json_encode(array('status'=>'PASS_V31_S04B_FOREIGN_SLUG_BLOCKED','blocker'=>v31_status($p)),JSON_UNESCAPED_SLASHES)."\n";
