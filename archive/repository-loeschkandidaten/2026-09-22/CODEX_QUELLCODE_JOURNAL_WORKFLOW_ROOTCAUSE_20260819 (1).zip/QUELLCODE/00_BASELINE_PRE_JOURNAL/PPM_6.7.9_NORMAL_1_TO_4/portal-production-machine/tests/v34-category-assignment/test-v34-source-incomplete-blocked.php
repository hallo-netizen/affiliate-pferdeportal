<?php
require_once __DIR__.'/fixture-builder.php';
$s=v34_snapshot();unset($s['categories'][0]['hierarchy_path']);
$e=PPM679_Category_Hierarchy_Validator::validate($s);
ppm_test_assert(!empty($e),'incomplete source must block');
echo "PASS_V34_SOURCE_INCOMPLETE_BLOCKED\n";
