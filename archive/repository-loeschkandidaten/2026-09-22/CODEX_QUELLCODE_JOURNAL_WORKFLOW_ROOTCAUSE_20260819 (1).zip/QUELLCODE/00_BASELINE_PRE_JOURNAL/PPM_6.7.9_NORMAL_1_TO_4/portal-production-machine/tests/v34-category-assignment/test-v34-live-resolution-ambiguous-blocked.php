<?php
require_once __DIR__.'/fixture-builder.php';PPM679_WP::reset_test_state();
PPM679_WP::seed_test_term(array('term_id'=>2048,'name'=>'FAQ Checklisten für Pferdeanhänger','slug'=>'checklisten-fuer-pferdeanhaenger-faq','taxonomy'=>'category','parent'=>1002,'hierarchy_path'=>'Transport > Anhängerpflege > Checklisten für Pferdeanhänger > FAQ Checklisten für Pferdeanhänger','level'=>4));
$b=array('name'=>'FAQ Checklisten für Pferdeanhänger','slug'=>'checklisten-fuer-pferdeanhaenger-faq','hierarchy_path'=>'Transport > Anhängerpflege > Checklisten für Pferdeanhänger > FAQ Checklisten für Pferdeanhänger','taxonomy'=>'category');
$r=PPM679_WP::resolve_category_binding($b);
ppm_test_assert(empty($r['ok']),'ambiguous live term must block');
echo "PASS_V34_LIVE_RESOLUTION_AMBIGUOUS_BLOCKED\n";
