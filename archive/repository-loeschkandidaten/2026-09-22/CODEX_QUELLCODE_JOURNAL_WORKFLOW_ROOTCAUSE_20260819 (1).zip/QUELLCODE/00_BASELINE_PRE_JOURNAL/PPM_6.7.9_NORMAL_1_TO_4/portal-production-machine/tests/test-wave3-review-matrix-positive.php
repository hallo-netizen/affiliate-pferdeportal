<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';
require __DIR__.'/wave3-fixture-builder.php';

$fixture=ppm_wave3_positive_fixture();
$result=PPM679_Review_Matrix_Validator::validate(
    $fixture['review'],$fixture['document'],$fixture['gold_reference'],
    array('independent_review_verified'=>false),'wave3_positive_matrix','wave3-local-state'
);
if (empty($result['ok'])) {
    fwrite(STDERR,json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");
}
ppm_test_assert(!empty($result['ok']),'valid Wave-3 review matrix must pass deterministic validation');
ppm_test_assert(($result['matrix_validation_status']??'')==='PASS','matrix validation status must be PASS');
ppm_test_assert(($result['editorial_review_status']??'')==='NICHT_AUSGEFÜHRT','without independent review no editorial PASS may be claimed');
ppm_test_assert(($result['coverage']['total']??'')==='COMPLETE','total coverage must be complete');
ppm_test_assert(($result['quote_reuse_audit_status']??'')==='PASS','quote reuse audit must pass');

echo json_encode(array(
    'contract'=>'wave3_review_matrix_positive_report_v1',
    'status'=>'PASS',
    'matrix_validation_status'=>$result['matrix_validation_status'],
    'editorial_review_status'=>$result['editorial_review_status'],
    'coverage'=>$result['coverage'],
    'conditions'=>$result['conditions'],
    'quote_reuse_diagnostics'=>$result['quote_reuse_diagnostics'],
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
