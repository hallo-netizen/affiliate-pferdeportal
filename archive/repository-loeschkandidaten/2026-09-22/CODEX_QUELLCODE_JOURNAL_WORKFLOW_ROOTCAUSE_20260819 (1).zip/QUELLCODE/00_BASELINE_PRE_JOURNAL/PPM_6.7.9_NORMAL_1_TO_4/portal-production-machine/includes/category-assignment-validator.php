<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Category_Assignment_Validator {
    const VERSION='6.7.9';
    const CONTRACT_FILE='contracts/category-assignment-review-instance-v1-1.json';
    const SNAPSHOT_FILE='contracts/category-hierarchy-snapshot-v1.json';
    const DERIVER_FILE='includes/independent-semantic-category-deriver.php';
    private static $independent_evidence=array();

    private static function err($code,$rule,$path,$expected,$actual,$reason,$context='category_assignment'){
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$context,'',__CLASS__,null,array(self::CONTRACT_FILE,self::SNAPSHOT_FILE,self::DERIVER_FILE));
    }
    private static function contract(){ $p=PPM679_PLUGIN_DIR.self::CONTRACT_FILE;$d=is_file($p)?json_decode((string)file_get_contents($p),true):null;return is_array($d)?$d:null; }
    public static function governance_errors(){
        $c=self::contract();$errors=array();
        if(!is_array($c)){return array(self::err('BLOCKED_CATEGORY_SOURCE_UNBOUND','CATEGORY_REVIEW_INSTANCE_CONTRACT_MUST_EXIST','category_review.contract',self::CONTRACT_FILE,null,'Der Vertrag der Kategorie-Prüfinstanz fehlt.'));}
        $self=(string)($c['contract_self_sha256']??'');$copy=$c;unset($copy['contract_self_sha256']);$actual=PPM679_Diagnostic::stable_hash($copy);
        if($self===''||!hash_equals($self,$actual)){$errors[]=self::err('BLOCKED_CATEGORY_SOURCE_UNBOUND','CATEGORY_REVIEW_INSTANCE_SELF_HASH_MUST_MATCH','category_review.contract_self_sha256',$actual,$self,'Der Vertrag der Kategorie-Prüfinstanz wurde verändert.');}
        foreach((array)($c['blocking_counters']??array()) as $name=>$count){if((int)$count!==0){$errors[]=self::err('BLOCKED_'.$name,'ALL_CATEGORY_BLOCKING_COUNTERS_MUST_BE_ZERO','category_review.blocking_counters.'.$name,0,$count,'Ein Kategorie-Sperrzähler ist nicht null.');}}
        if(count((array)($c['blocking_counters']??array()))!==25){$errors[]=self::err('BLOCKED_CATEGORY_COUNTER_SET','CATEGORY_REVIEW_INSTANCE_REQUIRES_ALL_25_COUNTERS','category_review.blocking_counters',25,count((array)($c['blocking_counters']??array())),'Die Kategorie-Prüfinstanz enthält nicht alle 25 Sperrzähler.');}
        if(($c['absolute_completeness_claimed']??null)!==false){$errors[]=self::err('BLOCKED_CATEGORY_ABSOLUTE_COMPLETENESS_CLAIM','CATEGORY_REVIEW_MUST_NOT_CLAIM_ABSOLUTE_COMPLETENESS','category_review.absolute_completeness_claimed',false,$c['absolute_completeness_claimed']??null,'Absolute Vollständigkeit darf nicht behauptet werden.');}
        return array_merge($errors,self::structure_errors(),PPM679_Category_Hierarchy_Validator::validate(PPM679_Category_Hierarchy_Validator::load()),PPM679_Portal_WP_Structure_Validator::governance_errors());
    }
    public static function structure_errors(){
        $inspection=PPM679_Category_Structure_Inspector::inspect();
        return (array)($inspection['errors']??array());
    }
    public static function structure_evidence(){
        $inspection=PPM679_Category_Structure_Inspector::inspect();
        return (array)($inspection['evidence']??array());
    }
    public static function semantic_input($fields){
        $fields=is_array($fields)?$fields:array();
        return array(
            'title'=>(string)($fields['title']??''),
            'topic'=>(string)($fields['topic']??''),
            'search_intent'=>(string)($fields['search_intent']??''),
            'article_type'=>(string)($fields['article_type']??''),
            'outline'=>(string)($fields['outline']??''),
            'keywords'=>array_values(array_unique(array_filter(array_map('strval',(array)($fields['keywords']??array())),function($v){return trim($v)!=='';}))),
            'target_level'=>(int)($fields['target_level']??4),
            'portal_id'=>(string)($fields['portal_id']??''),
            'taxonomy'=>(string)($fields['taxonomy']??'category')
        );
    }
    public static function semantic_input_from_article_fields($title,$topic,$search_intent,$article_type,$content_html,$keywords,$target_level,$portal_id,$taxonomy){
        preg_match_all('/<h2[^>]*>(.*?)<\/h2>/isu',(string)$content_html,$m);
        $outline=trim(implode(' | ',array_map('strip_tags',(array)($m[1]??array()))));
        return self::semantic_input(array(
            'title'=>$title,'topic'=>$topic,'search_intent'=>$search_intent,'article_type'=>$article_type,
            'outline'=>$outline,'keywords'=>$keywords,'target_level'=>$target_level,'portal_id'=>$portal_id,'taxonomy'=>$taxonomy
        ));
    }
    public static function derive_independent($semantic_input,$snapshot){
        $semantic_input=is_array($semantic_input)?$semantic_input:array();$snapshot=is_array($snapshot)?$snapshot:array();
        $errors=array_merge(self::governance_errors(),PPM679_Category_Hierarchy_Validator::validate($snapshot));
        $text_signal=trim((string)($semantic_input['title']??'').' '.(string)($semantic_input['topic']??'').' '.(string)($semantic_input['outline']??'').' '.implode(' ',(array)($semantic_input['keywords']??array())));
        if(trim((string)($semantic_input['article_type']??''))===''||strlen($text_signal)<40){$errors[]=self::err('BLOCKED_CATEGORY_INPUT_INSUFFICIENT','INDEPENDENT_CATEGORY_DERIVATION_REQUIRES_ARTICLE_TYPE_AND_SUFFICIENT_TOPIC_INFORMATION','category_independent.semantic_input',array('article_type'=>'non-empty','semantic_text_length'=>'>=40'),array('article_type'=>$semantic_input['article_type']??null,'semantic_text_length'=>strlen($text_signal)),'Für eine unabhängige Kategorieentscheidung fehlen ausreichende Beitragsinformationen.');}
        foreach(array('portal_id','taxonomy','target_level') as $field){if((string)($semantic_input[$field]??'')===''){$errors[]=self::err('BLOCKED_CATEGORY_INPUT_INSUFFICIENT','SEMANTIC_CATEGORY_INPUT_REQUIRES_PORTAL_TAXONOMY_AND_TARGET_LEVEL','category_independent.semantic_input.'.$field,'non-empty',$semantic_input[$field]??null,'Der Kontext der unabhängigen Kategorieentscheidung ist unvollständig.');}}
        if((string)($semantic_input['portal_id']??'')!==(string)($snapshot['portal_id']??'')){$errors[]=self::err('BLOCKED_CATEGORY_SOURCE_UNBOUND','SEMANTIC_INPUT_PORTAL_MUST_MATCH_CATEGORY_SOURCE','category_independent.portal_id',$snapshot['portal_id']??null,$semantic_input['portal_id']??null,'Beitragseingabe und Kategorienquelle gehören nicht zum selben Portal.');}
        if((string)($semantic_input['taxonomy']??'')!==(string)($snapshot['taxonomy']??'')){$errors[]=self::err('BLOCKED_CATEGORY_SOURCE_UNBOUND','SEMANTIC_INPUT_TAXONOMY_MUST_MATCH_CATEGORY_SOURCE','category_independent.taxonomy',$snapshot['taxonomy']??null,$semantic_input['taxonomy']??null,'Beitragseingabe und Kategorienquelle verwenden nicht dieselbe Taxonomie.');}
        if((int)($semantic_input['target_level']??0)!==(int)($snapshot['target_assignable_level']??0)){$errors[]=self::err('BLOCKED_CATEGORY_LEVEL_MISMATCH','SEMANTIC_INPUT_TARGET_LEVEL_MUST_MATCH_CATEGORY_SOURCE','category_independent.target_level',$snapshot['target_assignable_level']??null,$semantic_input['target_level']??null,'Die vorgesehene Beitragsebene weicht von der Kategorienquelle ab.');}
        if($errors){return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'category_independent_derivation'));}
        $semantic_snapshot=PPM679_Category_Hierarchy_Validator::semantic_view($snapshot);
        $decision=PPM679_Independent_Semantic_Category_Deriver::derive($semantic_input,$semantic_snapshot);
        if(($decision['status']??'')==='BLOCKED_INPUT_CONTAMINATED'){$e=self::err('BLOCKED_CATEGORY_SEMANTIC_INTERFACE_CONTAMINATED','SEMANTIC_DERIVER_INPUT_MUST_CONTAIN_ONLY_ALLOWED_FIELDS','category_independent.input','allowed semantic fields only',$decision['violations']??array(),'Die unabhängige Kategorieableitung erhielt verbotene oder kontaminierte Eingabefelder.');return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($e['error_code'],array($e),'category_independent_derivation'));}
        if(($decision['status']??'')==='UNRESOLVED'){$e=self::err('BLOCKED_CATEGORY_SEMANTIC_UNRESOLVED','INDEPENDENT_CATEGORY_MUST_RESOLVE','category_independent.status','RESOLVED',$decision['status']??null,'Die Prüfinstanz fand keine fachlich passende Kategorie.');return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($e['error_code'],array($e),'category_independent_derivation'));}
        if(($decision['status']??'')!=='RESOLVED'){$e=self::err('BLOCKED_CATEGORY_SEMANTIC_AMBIGUOUS','INDEPENDENT_CATEGORY_REQUIRES_CLEAR_MARGIN','category_independent.status','RESOLVED',$decision,'Die beste und zweitbeste Kategorie sind nicht eindeutig getrennt.');return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($e['error_code'],array($e),'category_independent_derivation'));}
        self::$independent_evidence[(string)$decision['decision_sha256']]=$decision;
        return array('ok'=>true,'decision'=>$decision,'decision_persisted_before_plan_load'=>true,'evidence_hash'=>(string)$decision['decision_sha256']);
    }
    public static function compare_and_resolve($independent_result,$editorial_binding,$snapshot){
        $errors=array();$independent=(array)($independent_result['decision']??array());$best=(array)($independent['best']??array());$binding=is_array($editorial_binding)?$editorial_binding:array();
        if(($independent_result['decision_persisted_before_plan_load']??false)!==true||!isset(self::$independent_evidence[(string)($independent['decision_sha256']??'')])){$errors[]=self::err('BLOCKED_CATEGORY_SEMANTIC_EVIDENCE_UNBOUND','INDEPENDENT_DECISION_MUST_BE_PERSISTED_BEFORE_PLAN_COMPARISON','category_assignment.independent_evidence','persisted and hashed',$independent_result,'Die unabhängige Entscheidung ist nicht vor dem Planvergleich gebunden.');}
        foreach(array('name','slug','hierarchy_path','portal_path','portal_level','portal_node_types','taxonomy','article_type','category_source_snapshot_hash','portal_structure_snapshot_hash','wp_taxonomy_contract_hash','wp_taxonomy_snapshot_hash','wp_parent_chain_required','expected_wp_parent_slugs','expected_wp_taxonomy_depth') as $f){
            $missing=!array_key_exists($f,$binding);
            if(!$missing&&is_string($binding[$f])){$missing=trim($binding[$f])==='';}
            if(!$missing&&$f==='portal_node_types'){$missing=!is_array($binding[$f])||!$binding[$f];}
            if(!$missing&&$f==='expected_wp_parent_slugs'){$missing=!is_array($binding[$f]);}
            if(!$missing&&$f==='wp_parent_chain_required'){$missing=!is_bool($binding[$f]);}
            if(!$missing&&in_array($f,array('portal_level','expected_wp_taxonomy_depth'),true)){$missing=!is_int($binding[$f])||$binding[$f]<1;}
            if($missing){$errors[]=self::err('BLOCKED_CATEGORY_PLAN_UNBOUND','EDITORIAL_PLAN_REQUIRES_COMPLETE_CATEGORY_BINDING','category_assignment.editorial.'.$f,'valid bound value',$binding[$f]??null,'Die Kategoriebindung des Redaktionsplans ist unvollständig.');}
        }
        foreach(array('name','slug','taxonomy') as $f){if((string)($best[$f]??'')!==(string)($binding[$f]??'')){$errors[]=self::err('BLOCKED_CATEGORY_PLAN_MISMATCH','INDEPENDENT_AND_EDITORIAL_CATEGORY_MUST_MATCH','category_assignment.'.$f,$best[$f]??null,$binding[$f]??null,'Die unabhängig ermittelte Kategorie stimmt nicht mit dem Redaktionsplan überein.');}}
        if((string)($best['hierarchy_path']??'')!==(string)($binding['portal_path']??'')){$errors[]=self::err('BLOCKED_CATEGORY_PLAN_MISMATCH','INDEPENDENT_PORTAL_PATH_AND_EDITORIAL_PORTAL_PATH_MUST_MATCH','category_assignment.portal_path',$best['hierarchy_path']??null,$binding['portal_path']??null,'Der unabhängig ermittelte Portalpfad stimmt nicht mit dem Redaktionsplan überein.');}
        $matches=PPM679_Category_Hierarchy_Validator::find_by_slug($snapshot,(string)($binding['slug']??''),(string)($binding['taxonomy']??'category'));
        $errors=array_merge($errors,PPM679_Portal_WP_Structure_Validator::validate_editorial_binding($binding,count($matches)===1?$matches[0]:null));
        if((string)($binding['category_source_snapshot_hash']??'')!==(string)($snapshot['snapshot_sha256']??'')){$errors[]=self::err('BLOCKED_CATEGORY_SNAPSHOT_STALE','EDITORIAL_PLAN_MUST_BIND_CURRENT_CATEGORY_SNAPSHOT','category_assignment.snapshot_sha256',$snapshot['snapshot_sha256']??null,$binding['category_source_snapshot_hash']??null,'Der Redaktionsplan bindet einen anderen Kategorien-Snapshot.');}
        if($errors){return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'category_plan_comparison'));}
        $live=PPM679_WP::resolve_category_binding($binding);
        if(empty($live['ok'])){return array('ok'=>false,'report'=>$live['report']??null);}
        $decision=array('contract'=>'PPM679_FOUR_WAY_CATEGORY_ASSIGNMENT_V2','independent_semantic_category'=>$best,'independent_decision_sha256'=>(string)$independent['decision_sha256'],'editorial_plan_category'=>$binding,'portal_structure_binding'=>array('portal_level'=>$binding['portal_level'],'portal_path'=>$binding['portal_path'],'portal_node_types'=>$binding['portal_node_types'],'portal_structure_snapshot_hash'=>$binding['portal_structure_snapshot_hash']),'wordpress_taxonomy_binding'=>array('wp_taxonomy'=>$binding['taxonomy'],'wp_term_slug'=>$binding['slug'],'wp_term_name'=>$binding['name'],'wp_parent_chain_required'=>$binding['wp_parent_chain_required'],'expected_wp_parent_slugs'=>$binding['expected_wp_parent_slugs'],'expected_wp_taxonomy_depth'=>$binding['expected_wp_taxonomy_depth'],'wp_taxonomy_contract_hash'=>$binding['wp_taxonomy_contract_hash'],'wp_taxonomy_snapshot_hash'=>$binding['wp_taxonomy_snapshot_hash']),'live_resolved_category'=>$live['term'],'live_wordpress_taxonomy_snapshot'=>$live['runtime_taxonomy_snapshot']??array(),'snapshot_sha256'=>(string)$snapshot['snapshot_sha256'],'four_way_status'=>'PREWRITE_A_B_C_PASS_D_PENDING','absolute_completeness_claimed'=>false);
        $decision['category_assignment_sha256']=PPM679_Diagnostic::stable_hash($decision);
        return array('ok'=>true,'category_assignment'=>$decision);
    }
    public static function revalidate_chokepoint($assignment){
        $a=is_array($assignment)?$assignment:array();$copy=$a;$claimed=(string)($copy['category_assignment_sha256']??'');unset($copy['category_assignment_sha256']);$actual=PPM679_Diagnostic::stable_hash($copy);$errors=array();
        if($claimed===''||!hash_equals($claimed,$actual)){$errors[]=self::err('BLOCKED_CATEGORY_WRITE_UNBOUND','CATEGORY_ASSIGNMENT_HASH_MUST_MATCH_AT_CHOKEPOINT','category_assignment.category_assignment_sha256',$actual,$claimed,'Die Kategorieentscheidung wurde nach der Generalprobe verändert.','category_chokepoint');}
        $binding=(array)($a['editorial_plan_category']??array());$live=PPM679_WP::resolve_category_binding($binding);
        if(empty($live['ok'])){return (array)($live['report']['errors']??array(self::err('BLOCKED_CATEGORY_LIVE_RESOLUTION_MISSING','CATEGORY_MUST_RESOLVE_AT_CHOKEPOINT','category_assignment.live','resolved',$live,'Die Kategorie kann am Schreibpunkt nicht erneut aufgelöst werden.','category_chokepoint')));}
        if((int)($live['term']['term_id']??0)!==(int)($a['live_resolved_category']['term_id']??0)||PPM679_Diagnostic::stable_hash($live['term'])!==PPM679_Diagnostic::stable_hash($a['live_resolved_category']??array())){$errors[]=self::err('BLOCKED_CATEGORY_CHOKEPOINT_MISMATCH','CATEGORY_LIVE_RESOLUTION_MUST_REMAIN_IDENTICAL_AT_CHOKEPOINT','category_assignment.live_resolved_category',$a['live_resolved_category']??null,$live['term']??null,'Die Kategorieauflösung änderte sich zwischen Generalprobe und Schreibpunkt.','category_chokepoint');}
        return $errors;
    }
    public static function validate_readback($snapshot,$assignment){
        $snapshot=is_array($snapshot)?$snapshot:array();$a=is_array($assignment)?$assignment:array();$errors=array();$expected=(array)($a['live_resolved_category']??array());
        $ids=array_values(array_unique(array_map('intval',(array)($snapshot['category_ids']??array()))));sort($ids,SORT_NUMERIC);$wanted=array((int)($expected['term_id']??0));
        if($ids!==$wanted){$errors[]=self::err('BLOCKED_CATEGORY_READBACK_MISMATCH','READBACK_CATEGORY_IDS_MUST_MATCH_LIVE_RESOLUTION','category_readback.category_ids',$wanted,$ids,'Die tatsächlich gespeicherte Kategorie weicht von der Vierfachbindung ab.','category_readback');return $errors;}
        $actual=PPM679_WP::category_term_snapshot($wanted[0],(string)($expected['taxonomy']??'category'));
        foreach(array('name','slug','taxonomy') as $f){if((string)($actual[$f]??'')!==(string)($expected[$f]??'')){$errors[]=self::err('BLOCKED_CATEGORY_READBACK_MISMATCH','READBACK_SEMANTIC_CATEGORY_MUST_MATCH','category_readback.'.$f,$expected[$f]??null,$actual[$f]??null,'Die semantische Rückauflösung des Readbacks stimmt nicht.','category_readback');}}
        if(is_array($actual)){$errors=array_merge($errors,PPM679_Portal_WP_Structure_Validator::validate_live_term($actual,(array)($a['editorial_plan_category']??array())));}
        return $errors;
    }
    public static function reset_test_state(){self::$independent_evidence=array();}
}
