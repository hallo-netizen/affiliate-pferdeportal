<?php
require_once dirname(__DIR__).'/bootstrap-test.php'; require_once __DIR__.'/fixture-builder.php';
PPM679_WP::reset_test_state(); PPM679_WP_Draft_Adapter::reset_test_state();
$c=qf03_candidate_fixture(); $d=PPM679_WP_Draft_Adapter::create_single_faq_draft($c,qf03_gate_fixture()); ppm_test_assert($d['ok'],'draft setup');
$s=PPM679_WP::get_post_snapshot($d['post_id']);
$r=PPM679_WP_Readback_Validator::validate($s,$d['expected'],array('evidence_class'=>'SERVER_USER_TRIGGERED_TEST','user_triggered'=>true,'publish_event_count'=>0,'captured_at'=>'2026-07-27T12:00:00Z','server_instance_id'=>'ppm-test-instance-679','request_id'=>'qf03-request-001','artifact_id'=>'qf03-readback-001'));
ppm_test_assert($r['ok']===true,'Exact readback must pass'); ppm_test_assert($r['READBACK_STATUS']==='PASS','Readback status');
$b=PPM679_WP_Readback_Validator::validate_batch(array($s),array($d['expected']),array('evidence_class'=>'SERVER_USER_TRIGGERED_TEST','user_triggered'=>true,'publish_event_count'=>0,'certification_mode'=>'SINGLE_FAQ_RECERTIFICATION','captured_at'=>'2026-07-27T12:00:00Z','server_instance_id'=>'ppm-test-instance-679','request_id'=>'qf03-request-001','artifact_id'=>'qf03-readback-001'));
ppm_test_assert($b['ok']===true,'Single FAQ batch must pass current repair sequence'); ppm_test_assert($b['four_draft_requirement_status']==='NOT_YET_APPLICABLE_SINGLE_FAQ_REPAIR_SEQUENCE','Four-type readback remains later certification');
echo json_encode(array('status'=>'PASS','readback'=>$r['item'],'four_draft_requirement_status'=>$b['four_draft_requirement_status']),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
