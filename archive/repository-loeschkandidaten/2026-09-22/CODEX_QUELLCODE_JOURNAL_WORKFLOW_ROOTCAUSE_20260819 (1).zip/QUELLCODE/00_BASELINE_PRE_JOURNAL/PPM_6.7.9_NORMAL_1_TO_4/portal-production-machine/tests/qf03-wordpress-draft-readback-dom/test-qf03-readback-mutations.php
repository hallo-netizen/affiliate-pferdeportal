<?php
require_once dirname(__DIR__).'/bootstrap-test.php'; require_once __DIR__.'/fixture-builder.php';
PPM679_WP::reset_test_state(); PPM679_WP_Draft_Adapter::reset_test_state();
$c=qf03_candidate_fixture(); $d=PPM679_WP_Draft_Adapter::create_single_faq_draft($c,qf03_gate_fixture()); $base=PPM679_WP::get_post_snapshot($d['post_id']);
$context=array('evidence_class'=>'SERVER_USER_TRIGGERED_TEST','user_triggered'=>true,'publish_event_count'=>0,'captured_at'=>'2026-07-27T12:00:00Z','server_instance_id'=>'ppm-test-instance-679','request_id'=>'qf03-request-001','artifact_id'=>'qf03-readback-001');
$mut=array();
$x=$base; $x['post_status']='publish'; $mut['published']=$x;
$x=$base; $x['post_title']='Changed'; $mut['title']=$x;
$x=$base; $x['post_content'].='x'; $mut['content']=$x;
$x=$base; $x['category_ids']=array(99); $mut['category']=$x;
$x=$base; $x['meta']['_ppm679_test_marker']='wrong'; $mut['marker']=$x;
$x=$base; $x['meta']['_ppm679_publish_blocked']='0'; $mut['publish_meta']=$x;
$out=array(); foreach($mut as $name=>$snap){ $r=PPM679_WP_Readback_Validator::validate($snap,$d['expected'],$context); ppm_test_assert($r['ok']===false,$name.' must block'); $out[$name]=$r['report']['status']; }
$r=PPM679_WP_Readback_Validator::validate($base,$d['expected'],array('evidence_class'=>'LOCAL_EXECUTED_TEST','user_triggered'=>false,'publish_event_count'=>0)); ppm_test_assert($r['ok']===false,'local evidence cannot pass'); $out['local_evidence']=$r['report']['status'];
$r=PPM679_WP_Readback_Validator::validate($base,$d['expected'],array('evidence_class'=>'SERVER_USER_TRIGGERED_TEST','user_triggered'=>true,'publish_event_count'=>1)); ppm_test_assert($r['ok']===false,'publish event must block'); $out['publish_event']=$r['report']['status'];
echo json_encode(array('status'=>'PASS','blocked_mutations'=>$out),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
