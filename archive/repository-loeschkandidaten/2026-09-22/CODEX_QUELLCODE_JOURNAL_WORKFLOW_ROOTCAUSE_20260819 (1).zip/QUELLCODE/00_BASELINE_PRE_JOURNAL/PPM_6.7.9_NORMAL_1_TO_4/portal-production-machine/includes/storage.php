<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Storage {
    const VERSION = '6.7.9';
    private static $memory = array(
        'runs' => array(),
        'items' => array(),
        'tombstones' => array(),
        'fact_packs' => array(),
    );
    private static $test_faults = array();

    public static function set_test_fault($name, $value = true) {
        if (PPM679_WP::is_test_mode()) { self::$test_faults[(string) $name] = $value; }
    }

    public static function clear_test_faults() {
        self::$test_faults = array();
    }

    public static function reset_test_state() {
        self::$memory = array('runs'=>array(),'items'=>array(),'tombstones'=>array(),'fact_packs'=>array());
        self::$test_faults = array();
    }

    private static function prefix() {
        global $wpdb;
        return isset($wpdb->prefix) ? (string) $wpdb->prefix : 'wp_';
    }

    public static function table($name) {
        return self::prefix() . 'ppm679_' . $name;
    }

    public static function ensure_schema() {
        $context = 'ensure_schema';
        if (PPM679_WP::is_test_mode()) {
            if (!empty(self::$test_faults['schema_failure'])) {
                return PPM679_Diagnostic::blocked(
                    'BLOCKED_SCHEMA_SETUP_FAILED',
                    array(PPM679_Diagnostic::error(
                        'BLOCKED_SCHEMA_SETUP_FAILED',
                        'SCHEMA_SETUP_MUST_COMPLETE',
                        'storage.schema',
                        self::VERSION,
                        'simulated failure',
                        'Der isolierte Laufzeittest simuliert einen fehlgeschlagenen Schemaaufbau.',
                        $context,
                        '',
                        __CLASS__
                    )),
                    $context
                );
            }
            PPM679_WP::update_option('ppm679_schema_version', self::VERSION);
            return PPM679_Diagnostic::ok('STRUCTURAL_CHECK_OK', $context, '', array('schema_version'=>self::VERSION));
        }

        try {
            global $wpdb;
            if (!isset($wpdb) || !is_object($wpdb)) {
                throw new RuntimeException('WordPress database adapter unavailable');
            }
            if (!defined('ABSPATH')) { throw new RuntimeException('ABSPATH unavailable'); }
            $upgrade = ABSPATH . 'wp-admin/includes/upgrade.php';
            if (!function_exists('dbDelta')) {
                if (!is_file($upgrade)) { throw new RuntimeException('dbDelta include unavailable'); }
                require_once $upgrade;
            }
            $collate = method_exists($wpdb, 'get_charset_collate') ? $wpdb->get_charset_collate() : '';
            $runs = self::table('runs');
            $items = self::table('items');
            $ids = self::table('tombstones');
            $facts = self::table('fact_packs');

            dbDelta("CREATE TABLE $runs (
                run_id varchar(191) NOT NULL,
                plan_id varchar(191) NOT NULL,
                plan_hash char(64) NOT NULL,
                stage varchar(40) NOT NULL,
                plan_json longtext NOT NULL,
                workspace_json longtext NULL,
                check_report_json longtext NULL,
                readback_json longtext NULL,
                error_json longtext NULL,
                created_gmt datetime NOT NULL,
                updated_gmt datetime NOT NULL,
                PRIMARY KEY (run_id),
                KEY plan_id (plan_id),
                KEY stage (stage)
            ) $collate ENGINE=InnoDB;");

            dbDelta("CREATE TABLE $items (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                run_id varchar(191) NOT NULL,
                plan_item_key varchar(191) NOT NULL,
                article_type varchar(30) NOT NULL,
                topic text NOT NULL,
                batch_article_id varchar(191) NOT NULL,
                fact_pack_id varchar(191) NOT NULL,
                skeleton_id varchar(191) NOT NULL,
                reservation_id varchar(191) NOT NULL,
                workspace_id varchar(191) NOT NULL,
                skeleton_token varchar(191) NOT NULL,
                lease_until_gmt datetime NOT NULL,
                state varchar(40) NOT NULL,
                post_id bigint unsigned NULL,
                title text NULL,
                slug varchar(200) NULL,
                content_hash char(64) NULL,
                content_html longtext NULL,
                PRIMARY KEY (id),
                UNIQUE KEY run_item (run_id,plan_item_key),
                UNIQUE KEY batch_article_id (batch_article_id),
                UNIQUE KEY fact_pack_id (fact_pack_id),
                UNIQUE KEY skeleton_id (skeleton_id),
                UNIQUE KEY reservation_id (reservation_id),
                KEY run_id (run_id),
                KEY state (state)
            ) $collate ENGINE=InnoDB;");

            dbDelta("CREATE TABLE $ids (
                identifier_type varchar(40) NOT NULL,
                identifier_value varchar(191) NOT NULL,
                run_id varchar(191) NOT NULL,
                lifecycle_state varchar(30) NOT NULL,
                created_gmt datetime NOT NULL,
                PRIMARY KEY (identifier_type,identifier_value),
                KEY run_id (run_id),
                KEY lifecycle_state (lifecycle_state)
            ) $collate ENGINE=InnoDB;");

            dbDelta("CREATE TABLE $facts (
                source_snapshot_id varchar(191) NOT NULL,
                fact_pack_hash char(64) NOT NULL,
                fact_pack_json longtext NOT NULL,
                created_gmt datetime NOT NULL,
                PRIMARY KEY (source_snapshot_id)
            ) $collate ENGINE=InnoDB;");

            foreach (array($runs,$items,$ids,$facts) as $table) {
                $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
                if ((string) $found !== (string) $table) {
                    throw new RuntimeException('Missing table after dbDelta: ' . $table);
                }
            }
            if (!PPM679_WP::update_option('ppm679_schema_version', self::VERSION)) {
                $stored = (string) PPM679_WP::get_option('ppm679_schema_version', '');
                if ($stored !== self::VERSION) { throw new RuntimeException('Schema option readback failed'); }
            }
            return PPM679_Diagnostic::ok('STRUCTURAL_CHECK_OK', $context, '', array('schema_version'=>self::VERSION));
        } catch (Throwable $e) {
            return PPM679_Diagnostic::blocked(
                'BLOCKED_SCHEMA_SETUP_FAILED',
                array(PPM679_Diagnostic::error(
                    'BLOCKED_SCHEMA_SETUP_FAILED',
                    'SCHEMA_SETUP_MUST_COMPLETE_WITHOUT_FATAL_ERROR',
                    'storage.schema',
                    self::VERSION,
                    get_class($e) . ': ' . $e->getMessage(),
                    'Der Schemaaufbau wurde abgefangen. WordPress bleibt erreichbar; keine Produktionsaktion wurde ausgeführt.',
                    $context,
                    '',
                    __CLASS__,
                    null,
                    array('includes/storage.php')
                )),
                $context
            );
        }
    }

    public static function begin() {
        if (PPM679_WP::is_test_mode()) { return true; }
        global $wpdb;
        return $wpdb->query('START TRANSACTION') !== false;
    }

    public static function commit() {
        if (PPM679_WP::is_test_mode()) { return true; }
        global $wpdb;
        return $wpdb->query('COMMIT') !== false;
    }

    public static function rollback() {
        if (PPM679_WP::is_test_mode()) { return true; }
        global $wpdb;
        return $wpdb->query('ROLLBACK') !== false;
    }

    public static function create_run($run) {
        if (PPM679_WP::is_test_mode()) {
            self::$memory['runs'][$run['run_id']] = $run;
            return true;
        }
        global $wpdb;
        return $wpdb->insert(self::table('runs'), array(
            'run_id'=>$run['run_id'],
            'plan_id'=>$run['plan_id'],
            'plan_hash'=>$run['plan_hash'],
            'stage'=>$run['stage'],
            'plan_json'=>PPM679_Diagnostic::encode($run['plan'], true),
            'workspace_json'=>null,
            'check_report_json'=>null,
            'readback_json'=>null,
            'error_json'=>null,
            'created_gmt'=>gmdate('Y-m-d H:i:s'),
            'updated_gmt'=>gmdate('Y-m-d H:i:s'),
        ), array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')) !== false;
    }

    public static function get_run($run_id) {
        if (PPM679_WP::is_test_mode()) {
            return isset(self::$memory['runs'][$run_id]) ? self::$memory['runs'][$run_id] : null;
        }
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table('runs').' WHERE run_id=%s', $run_id), ARRAY_A);
        if (!is_array($row)) { return null; }
        foreach (array('plan_json'=>'plan','workspace_json'=>'workspace','check_report_json'=>'check_report','readback_json'=>'readback','error_json'=>'error') as $json_field=>$target) {
            $row[$target] = !empty($row[$json_field]) ? json_decode($row[$json_field], true) : null;
        }
        return $row;
    }

    public static function update_run($run_id, $fields) {
        if (PPM679_WP::is_test_mode()) {
            if (!isset(self::$memory['runs'][$run_id])) { return false; }
            self::$memory['runs'][$run_id] = array_merge(self::$memory['runs'][$run_id], $fields);
            return true;
        }
        global $wpdb;
        $data = array('updated_gmt'=>gmdate('Y-m-d H:i:s'));
        $formats = array('%s');
        foreach ($fields as $key=>$value) {
            if ($key === 'stage') { $data['stage'] = (string)$value; $formats[]='%s'; }
            elseif ($key === 'workspace') { $data['workspace_json']=PPM679_Diagnostic::encode($value,true); $formats[]='%s'; }
            elseif ($key === 'check_report') { $data['check_report_json']=PPM679_Diagnostic::encode($value,true); $formats[]='%s'; }
            elseif ($key === 'readback') { $data['readback_json']=PPM679_Diagnostic::encode($value,true); $formats[]='%s'; }
            elseif ($key === 'error') { $data['error_json']=PPM679_Diagnostic::encode($value,true); $formats[]='%s'; }
        }
        return $wpdb->update(self::table('runs'), $data, array('run_id'=>$run_id), $formats, array('%s')) !== false;
    }

    public static function add_item($item) {
        if (PPM679_WP::is_test_mode()) {
            self::$memory['items'][$item['run_id'].'|'.$item['plan_item_key']] = $item;
            return true;
        }
        global $wpdb;
        return $wpdb->insert(self::table('items'), array(
            'run_id'=>$item['run_id'],
            'plan_item_key'=>$item['plan_item_key'],
            'article_type'=>$item['article_type'],
            'topic'=>$item['topic'],
            'batch_article_id'=>$item['batch_article_id'],
            'fact_pack_id'=>$item['fact_pack_id'],
            'skeleton_id'=>$item['skeleton_id'],
            'reservation_id'=>$item['reservation_id'],
            'workspace_id'=>$item['workspace_id'],
            'skeleton_token'=>$item['skeleton_token'],
            'lease_until_gmt'=>$item['lease_until_gmt'],
            'state'=>$item['state'],
            'post_id'=>null,
            'title'=>null,
            'slug'=>null,
            'content_hash'=>null,
            'content_html'=>null,
        )) !== false;
    }

    public static function get_items($run_id) {
        if (PPM679_WP::is_test_mode()) {
            $out=array();
            foreach (self::$memory['items'] as $item) { if ($item['run_id']===$run_id) { $out[]=$item; } }
            return $out;
        }
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare('SELECT * FROM '.self::table('items').' WHERE run_id=%s ORDER BY id ASC', $run_id), ARRAY_A);
    }

    public static function update_item($run_id, $plan_item_key, $fields) {
        if (PPM679_WP::is_test_mode()) {
            $key=$run_id.'|'.$plan_item_key;
            if (!isset(self::$memory['items'][$key])) { return false; }
            self::$memory['items'][$key]=array_merge(self::$memory['items'][$key],$fields);
            return true;
        }
        global $wpdb;
        $allowed=array('state','post_id','title','slug','content_hash','content_html','lease_until_gmt');
        $data=array(); $formats=array();
        foreach ($fields as $key=>$value) {
            if (!in_array($key,$allowed,true)) { continue; }
            $data[$key]=$value;
            $formats[] = $key==='post_id' ? '%d' : '%s';
        }
        if (!$data) { return true; }
        return $wpdb->update(self::table('items'),$data,array('run_id'=>$run_id,'plan_item_key'=>$plan_item_key),$formats,array('%s','%s')) !== false;
    }

    public static function tombstone($type, $value, $run_id, $state='RESERVED') {
        if (!empty(self::$test_faults['force_identifier_collision'])) {
            self::$test_faults['force_identifier_collision']=false;
            return false;
        }
        if (PPM679_WP::is_test_mode()) {
            $key=$type.'|'.$value;
            if (isset(self::$memory['tombstones'][$key])) { return false; }
            self::$memory['tombstones'][$key]=array(
                'identifier_type'=>$type,'identifier_value'=>$value,'run_id'=>$run_id,
                'lifecycle_state'=>$state,'created_gmt'=>gmdate('Y-m-d H:i:s')
            );
            return true;
        }
        global $wpdb;
        return $wpdb->insert(self::table('tombstones'),array(
            'identifier_type'=>$type,'identifier_value'=>$value,'run_id'=>$run_id,
            'lifecycle_state'=>$state,'created_gmt'=>gmdate('Y-m-d H:i:s')
        ),array('%s','%s','%s','%s','%s')) !== false;
    }

    public static function set_tombstone_state_for_run($run_id, $state) {
        if (PPM679_WP::is_test_mode()) {
            foreach (self::$memory['tombstones'] as &$row) {
                if ($row['run_id']===$run_id) { $row['lifecycle_state']=$state; }
            }
            unset($row);
            return true;
        }
        global $wpdb;
        return $wpdb->update(self::table('tombstones'),array('lifecycle_state'=>$state),array('run_id'=>$run_id),array('%s'),array('%s')) !== false;
    }

    public static function identifier_exists($type,$value) {
        if (PPM679_WP::is_test_mode()) { return isset(self::$memory['tombstones'][$type.'|'.$value]); }
        global $wpdb;
        return (int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.self::table('tombstones').' WHERE identifier_type=%s AND identifier_value=%s',$type,$value)) > 0;
    }

    public static function load_fact_pack($snapshot_id) {
        $snapshot_id=(string)$snapshot_id;
        if (PPM679_WP::is_test_mode()) {
            if (isset(self::$memory['fact_packs'][$snapshot_id])) {
                return self::$memory['fact_packs'][$snapshot_id];
            }
            $fixture=PPM679_PLUGIN_DIR.'fixtures/fact-packs/'.basename($snapshot_id).'.json';
            if (is_file($fixture)) {
                $decoded=json_decode((string)file_get_contents($fixture),true);
                if (is_array($decoded)) { return $decoded; }
            }
            return null;
        }

        global $wpdb;
        $json=$wpdb->get_var($wpdb->prepare('SELECT fact_pack_json FROM '.self::table('fact_packs').' WHERE source_snapshot_id=%s',$snapshot_id));
        if (is_string($json) && $json!=='') {
            $decoded=json_decode($json,true);
            if (is_array($decoded)) { return $decoded; }
        }
        return null;
    }

    public static function fact_pack_hash($snapshot_id,$pack=null) {
        $snapshot_id=(string)$snapshot_id;
        if (PPM679_WP::is_test_mode()) {
            if (isset(self::$memory['fact_packs'][$snapshot_id])) {
                return hash('sha256',PPM679_Diagnostic::encode(self::$memory['fact_packs'][$snapshot_id],true));
            }
            $fixture=PPM679_PLUGIN_DIR.'fixtures/fact-packs/'.basename($snapshot_id).'.json';
            return is_file($fixture)?hash_file('sha256',$fixture):'';
        }

        global $wpdb;
        $hash=$wpdb->get_var($wpdb->prepare('SELECT fact_pack_hash FROM '.self::table('fact_packs').' WHERE source_snapshot_id=%s',$snapshot_id));
        return is_string($hash)?strtolower(trim($hash)):'';
    }

    public static function save_fact_pack($snapshot_id,$pack) {
        if (!is_array($pack)) { return false; }
        if (PPM679_WP::is_test_mode()) {
            self::$memory['fact_packs'][$snapshot_id]=$pack;
            return true;
        }
        global $wpdb;
        $json=PPM679_Diagnostic::encode($pack,true);
        $hash=hash('sha256',$json);
        $existing=$wpdb->get_var($wpdb->prepare('SELECT fact_pack_hash FROM '.self::table('fact_packs').' WHERE source_snapshot_id=%s',$snapshot_id));
        if ($existing) { return hash_equals((string)$existing,$hash); }
        return $wpdb->insert(self::table('fact_packs'),array(
            'source_snapshot_id'=>$snapshot_id,'fact_pack_hash'=>$hash,'fact_pack_json'=>$json,'created_gmt'=>gmdate('Y-m-d H:i:s')
        ),array('%s','%s','%s','%s')) !== false;
    }


    public static function registry_integrity() {
        if (PPM679_WP::is_test_mode()) {
            if (!empty(self::$test_faults['registry_corrupt'])) {
                return array('ok'=>false,'actual'=>'simulated corrupt registry','invalid_lifecycle_count'=>1,'missing_tombstone_count'=>1);
            }
            $allowed=array('RESERVED','CONSUMED','ABORTED','RELEASED','EXPIRED','CREATED');
            foreach (self::$memory['tombstones'] as $row) {
                if (!in_array((string)$row['lifecycle_state'],$allowed,true)) {
                    return array('ok'=>false,'actual'=>$row,'invalid_lifecycle_count'=>1,'missing_tombstone_count'=>0);
                }
            }
            return array('ok'=>true,'invalid_lifecycle_count'=>0,'missing_tombstone_count'=>0);
        }
        global $wpdb;
        $tomb=self::table('tombstones');
        $items=self::table('items');
        $invalid=(int)$wpdb->get_var("SELECT COUNT(*) FROM $tomb WHERE lifecycle_state NOT IN ('RESERVED','CONSUMED','ABORTED','RELEASED','EXPIRED','CREATED')");
        $missing=0;
        $columns=array(
            'batch_article_id'=>'batch_article_id',
            'fact_pack_id'=>'fact_pack_id',
            'skeleton_id'=>'skeleton_id',
            'reservation_id'=>'reservation_id',
            'skeleton_token'=>'skeleton_token'
        );
        foreach ($columns as $column=>$type) {
            $missing += (int)$wpdb->get_var(
                "SELECT COUNT(*) FROM $items i LEFT JOIN $tomb t ON t.identifier_type='".esc_sql($type)."' AND t.identifier_value=i.$column WHERE t.identifier_value IS NULL"
            );
        }
        return array('ok'=>$invalid===0&&$missing===0,'invalid_lifecycle_count'=>$invalid,'missing_tombstone_count'=>$missing);
    }

    public static function registry_state() {
        if (PPM679_WP::is_test_mode()) {
            $state=array(
                'runs'=>count(self::$memory['runs']),
                'items'=>count(self::$memory['items']),
                'tombstones'=>count(self::$memory['tombstones']),
                'fact_packs'=>count(self::$memory['fact_packs']),
                'active_leases'=>0,
            );
            foreach (self::$memory['items'] as $item) {
                if (isset($item['lease_until_gmt']) && strtotime($item['lease_until_gmt'].' UTC') > time() && in_array($item['state'],array('RESERVED','GENERATED','CHECKED'),true)) { $state['active_leases']++; }
            }
            $state['registry_hash']=PPM679_Diagnostic::stable_hash(array(
                'runs'=>self::$memory['runs'],'items'=>self::$memory['items'],
                'tombstones'=>self::$memory['tombstones'],'fact_packs'=>self::$memory['fact_packs']
            ));
            return $state;
        }
        global $wpdb;
        $tables=array('runs','items','tombstones','fact_packs');
        $state=array();
        foreach ($tables as $name) {
            $state[$name]=(int)$wpdb->get_var('SELECT COUNT(*) FROM '.self::table($name));
        }
        $state['active_leases']=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::table('items')." WHERE lease_until_gmt>UTC_TIMESTAMP() AND state IN ('RESERVED','GENERATED','CHECKED')");
        $samples=array();
        foreach ($tables as $name) {
            $table=self::table($name);
            $rows=$wpdb->get_results("SELECT * FROM $table ORDER BY 1 ASC LIMIT 200",ARRAY_A);
            $samples[$name]=is_array($rows)?$rows:array();
        }
        $state['registry_hash']=PPM679_Diagnostic::stable_hash($samples);
        return $state;
    }

    public static function memory_snapshot() {
        return self::$memory;
    }
}
