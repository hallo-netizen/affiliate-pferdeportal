<?php
require_once dirname(__DIR__).'/bootstrap-test.php';
require_once dirname(__DIR__).'/qf03-wordpress-draft-readback-dom/fixture-builder.php';

function v31_contract(){
    return json_decode((string)file_get_contents(dirname(__DIR__,2).'/contracts/g9-single-faq-approved-candidate-v1.json'),true);
}

function v31_semantic_from_contract($c,$candidate){
    $quality=(array)($c['item']['quality_binding']??array());
    $keywords=array_values(array_unique(array_merge((array)($quality['intent_terms']??array()),array((string)($c['item']['target_keyword']??''),(string)($c['item']['runtime_order']['subject_label']??'')))));
    return PPM679_Category_Assignment_Validator::semantic_input_from_article_fields(
        (string)($candidate['title']??''),(string)($c['item']['topic']??''),(string)($c['item']['search_intent']??''),
        (string)($c['item']['article_type']??''),(string)($candidate['content_html']??''),$keywords,4,'pferde-atelier','category'
    );
}
function v31_build_hash(){
    return hash_file('sha256',dirname(__DIR__,2).'/certification/build-manifest-v1.json');
}
function v31_gate($content_hash,$request_id,$server_id='ppm-test-instance-679'){
    $g=qf03_gate_fixture($content_hash);
    $g['simulation_only']=true;
    $g['evidence_class']='LOCAL_EXECUTED_TEST';
    $g['request_id']=$request_id;
    $g['server_instance_id']=$server_id;
    $g['stateful_e2e_required']=true;
    return $g;
}
function v31_candidate(){
    $c=v31_contract();
    $candidate=$c['candidate'];
    $snapshot=PPM679_Category_Hierarchy_Validator::load();
    $semantic=v31_semantic_from_contract($c,$candidate);
    $independent=PPM679_Category_Assignment_Validator::derive_independent($semantic,$snapshot);
    if(!empty($independent['ok'])){
        $category=PPM679_Category_Assignment_Validator::compare_and_resolve($independent,(array)$candidate['category_binding'],$snapshot);
        if(!empty($category['ok'])){
            $candidate['category_assignment']=$category['category_assignment'];
            $candidate['category_id']=(int)$category['category_assignment']['live_resolved_category']['term_id'];
        }
    }
    return $candidate;
}
function v31_quality_hash(){
    $c=v31_contract();
    return (string)$c['quality_binding_sha256'];
}
function v31_seed_old_10277(){
    return PPM679_WP::seed_test_post(array(
        'ID'=>10277,
        'post_title'=>'Was muss vor einer Fahrt mit Pferdeanhänger geprüft werden?',
        'post_content'=>'<p>Historischer Fehlerbeleg 10277.</p>',
        'post_name'=>'pferdeanhaenger-vor-fahrt-pruefen',
        'post_status'=>'draft',
        'post_type'=>'post',
        'category_ids'=>array(27),
        'meta'=>array(
            '_ppm679_run_id'=>'g9-request-e4f9d5362a92780e6c4e465c',
            '_ppm679_article_type'=>'faq',
            '_ppm679_content_hash'=>'c9893893eff5ab77bad227d3e9bf725e180c09df9283e6376d2512ac56157c87',
            '_ppm679_editorially_reviewed_content_hash'=>'c9893893eff5ab77bad227d3e9bf725e180c09df9283e6376d2512ac56157c87',
            '_ppm679_gold_reference_hash'=>PPM679_G9_Single_FAQ_Entrypoint::GOLD_REFERENCE_SHA256,
            '_ppm679_test_marker'=>'LT2-FAQ-001',
            '_ppm679_target_category_slug'=>'pferdetransport',
            '_ppm679_publish_blocked'=>'1',
            '_ppm679_qf03_gate'=>'PASS'
        )
    ));
}
function v31_seed_foreign_slug(){
    return PPM679_WP::seed_test_post(array(
        'ID'=>12001,
        'post_title'=>'Fremdes Objekt',
        'post_content'=>'<p>Fremd.</p>',
        'post_name'=>'pferdeanhaenger-vor-fahrt-pruefen',
        'post_status'=>'publish',
        'post_type'=>'page',
        'category_ids'=>array(),
        'meta'=>array('_ppm679_publish_blocked'=>'0')
    ));
}
function v31_prepare($request_id,$seed_old=false){
    PPM679_WP::reset_test_state();PPM679_Storage::reset_test_state();
    if($seed_old){v31_seed_old_10277();}
    $candidate=v31_candidate();
    $contract=v31_contract();
    $snapshot=PPM679_Category_Hierarchy_Validator::load();
    $semantic=v31_semantic_from_contract($contract,$candidate);
    $independent=PPM679_Category_Assignment_Validator::derive_independent($semantic,$snapshot);
    if(empty($independent['ok'])){return array('ok'=>false,'category_independent_result'=>$independent);}
    $category=PPM679_Category_Assignment_Validator::compare_and_resolve($independent,(array)$candidate['category_binding'],$snapshot);
    if(empty($category['ok'])){return array('ok'=>false,'category_result'=>$category);}
    $candidate['category_assignment']=$category['category_assignment'];
    $candidate['category_id']=(int)$category['category_assignment']['live_resolved_category']['term_id'];
    $content_hash=hash('sha256',(string)$candidate['content_html']);
    $identity=PPM679_Stateful_Write_Gate::build_identity('canonical-faq-001','ppm-test-instance-679',v31_build_hash(),$request_id);
    if(empty($identity['ok'])){return array('ok'=>false,'identity_result'=>$identity);}
    $gate=v31_gate($content_hash,$request_id);
    $plan=PPM679_Stateful_Write_Gate::prepare_single_faq_plan($candidate,$gate,$identity['identity'],v31_quality_hash());
    if(empty($plan['ok'])){return array('ok'=>false,'identity_result'=>$identity,'plan_result'=>$plan);}
    $gate['PLANNED_WRITE_FINGERPRINT']=$plan['plan']['planned_write_fingerprint'];
    $candidate['internal_test_marker']=$identity['identity']['run_marker'];
    $candidate['run_id']=$request_id;
    $candidate['slug']=$plan['plan']['payload']['slug'];
    return array('ok'=>true,'candidate'=>$candidate,'gate'=>$gate,'identity'=>$identity['identity'],'plan'=>$plan['plan']);
}
function v31_write_prepared($prepared){
    return PPM679_WP_Draft_Adapter::create_single_faq_draft($prepared['candidate'],$prepared['gate'],$prepared['plan']);
}
function v31_execute_g9($request_id){
    return PPM679_G9_Single_FAQ_Entrypoint::execute(array(
        'user_triggered'=>true,
        'nonce_verified'=>true,
        'current_user_can_manage'=>true,
        'declared_contract'=>PPM679_G9_Single_FAQ_Entrypoint::CONTRACT,
        'declared_plan_item_key'=>PPM679_G9_Single_FAQ_Entrypoint::PLAN_ITEM_KEY,
        'simulation_only'=>true,
        'evidence_class'=>'LOCAL_EXECUTED_TEST',
        'request_id_override'=>$request_id
    ));
}
function v31_status($result){return (string)($result['report']['status']??$result['status']??'');}
