<?php
require_once __DIR__.'/bootstrap-test.php';
PPM679_WP::reset_test_state();
$cases=array();
$scope=PPM679_G9_FAQ_Test_Release_Validator::expected_scope();
$bad=$scope; $bad['requested_article_types']=array('Beratung');
$cases['wrong_type']=PPM679_G9_FAQ_Test_Release_Validator::validate('g9_single_faq_pre_draft','state',$bad);
$cases['wrong_context']=PPM679_G9_FAQ_Test_Release_Validator::validate('four_type_production','state',$scope);
$contract=json_decode(file_get_contents(dirname(__DIR__).'/contracts/g9-faq-only-test-release-v1.json'),true);
$contract['publish_allowed']=true;
$cases['tampered_release_contract']=PPM679_G9_FAQ_Test_Release_Validator::validate('g9_single_faq_pre_draft','state',$scope,$contract,null);
$candidate=json_decode(file_get_contents(dirname(__DIR__).'/contracts/g9-single-faq-approved-candidate-v1.json'),true);
$candidate['independent_editorial_review']['mainblock1_required_verdict']='WRONG';
$cases['tampered_candidate']=PPM679_G9_FAQ_Test_Release_Validator::validate('g9_single_faq_pre_draft','state',$scope,null,$candidate);
$out=array();
foreach($cases as $name=>$errors){ ppm_test_assert(count($errors)>0,$name.' must block'); $out[$name]=array_values(array_unique(array_column($errors,'error_code'))); }
ppm_test_assert(in_array('BLOCKED_G9_FAQ_RELEASE_SCOPE_MISMATCH',$out['wrong_type'],true),'wrong type code');
ppm_test_assert(in_array('BLOCKED_G9_FAQ_RELEASE_ACTION_CONTEXT',$out['wrong_context'],true),'wrong context code');
ppm_test_assert(in_array('BLOCKED_G9_FAQ_RELEASE_CONTRACT_SELF_HASH',$out['tampered_release_contract'],true),'tampered release self hash');
ppm_test_assert(in_array('BLOCKED_G9_FAQ_APPROVED_CANDIDATE_BINDING',$out['tampered_candidate'],true),'tampered candidate binding');
echo json_encode(array('status'=>'PASS_G9_FAQ_ONLY_RELEASE_GATE_NEGATIVE','cases'=>$out,'publish_allowed'=>false),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n";
