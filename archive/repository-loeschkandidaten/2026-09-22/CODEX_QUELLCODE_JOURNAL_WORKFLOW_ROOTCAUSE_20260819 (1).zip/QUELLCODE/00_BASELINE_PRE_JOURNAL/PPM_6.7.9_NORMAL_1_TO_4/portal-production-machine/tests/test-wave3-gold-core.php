<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';
require __DIR__.'/wave3-fixture-builder.php';

function w3_gold_codes(array $r): array { $o=array(); foreach((array)($r['errors']??array()) as $e){$o[]=(string)($e['error_code']??'');} return array_values(array_unique($o)); }
function w3_gold_has(array $r,string $c): bool { return in_array($c,w3_gold_codes($r),true); }

$controls=array();
foreach(PPM679_Gold_Core_Validator::CONTROL_POSTS as $type=>$post){
    $controls[]=array(
        'post_id'=>$post,'article_type'=>$type,'source_file'=>'fixture-'.$post.'.html',
        'content_hash'=>hash('sha256','content-'.$post),'body_html_hash'=>hash('sha256','html-'.$post),
        'body_text_hash'=>hash('sha256','text-'.$post),'visible_title'=>'Kontrollartikel '.$type,
        'baseline_report_hash'=>hash('sha256','baseline-'.$post),'control_baseline_status'=>'PASS'
    );
}
$control_result=PPM679_Gold_Core_Validator::validate_control_baselines($controls,array(),'wave3_controls','state');
if(empty($control_result['ok'])){fwrite(STDERR,json_encode($control_result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");}
ppm_test_assert(!empty($control_result['ok']),'four exact control baselines must pass fixture validation');

$missing=$controls; array_pop($missing);
$r=PPM679_Gold_Core_Validator::validate_control_baselines($missing,array(),'wave3_control_missing','state');
ppm_test_assert(w3_gold_has($r,'CONTROL_BASELINE_MISSING'),'missing control must be detected');
$replacement=$controls; $replacement[0]['post_id']=9999;
$r=PPM679_Gold_Core_Validator::validate_control_baselines($replacement,array(),'wave3_control_replacement','state');
ppm_test_assert(w3_gold_has($r,'CONTROL_BASELINE_REPLACEMENT_NOT_APPROVED'),'silent replacement must be blocked');

$tolerance=ppm_wave3_contract('gold-core-tolerances-v1.json');
$r=PPM679_Gold_Core_Validator::validate_numeric_gate(array(),$tolerance,array(),'wave3_no_tolerance','state');
ppm_test_assert(($r['gold_core_numeric_gate']??'')==='NICHT_AUSGEFÜHRT','unapproved production tolerance must not execute');
ppm_test_assert(w3_gold_has($r,'GOLD_CORE_TOLERANCE_NOT_APPROVED'),'unapproved tolerance error required');

$metric_names=PPM679_Gold_Core_Validator::REQUIRED_METRICS;
$tol_rows=array(); $metrics=array();
foreach($metric_names as $i=>$name){
    $ref=$name==='heading_structure'?array('h2'=>4,'h3'=>2):($name==='internal_link_distribution'?array('intro'=>1,'body'=>1,'further'=>1):100+$i);
    $min=is_array($ref)?$ref:($ref-10); $max=is_array($ref)?$ref:($ref+10);
    $tol_rows[]=array(
        'metric'=>$name,'reference_value'=>$ref,'allowed_minimum'=>$min,'allowed_maximum'=>$max,
        'derivation_method'=>'fixture deterministic derivation','reference_file'=>'fixture-gold.json',
        'reference_hash'=>hash('sha256','reference-'.$name),'approved_by_human_user'=>true,
        'approval_evidence_id'=>'FIXTURE-HUMAN-APPROVAL-'.$i
    );
    $metrics[$name]=array(
        'metric_id'=>$name,'candidate_value'=>$ref,'reference_value'=>$ref,
        'allowed_minimum'=>$min,'allowed_maximum'=>$max,'derivation_method'=>'fixture deterministic derivation',
        'candidate_content_hash'=>hash('sha256','candidate'),'reference_content_hash'=>hash('sha256','reference'),
        'verdict'=>'PASS'
    );
}
$approved=array('tolerance_definition'=>array(
    'status'=>'FIXTURE_ONLY_APPROVED','metrics'=>$tol_rows,'approved_by_human_user'=>true,
    'approval_evidence_id'=>'FIXTURE-HUMAN-APPROVAL-TOLERANCES','scope_limit'=>'isolated test fixture only'
));
$r=PPM679_Gold_Core_Validator::validate_numeric_gate($metrics,$approved,array(),'wave3_numeric_positive','state');
if(empty($r['ok'])){fwrite(STDERR,json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");}
ppm_test_assert(!empty($r['ok']),'approved fixture tolerance and in-range metrics must pass');
ppm_test_assert(($r['gold_core_numeric_gate']??'')==='PASS','numeric fixture gate must pass');

$out=$metrics; $out['word_count']['candidate_value']=9999;
$r=PPM679_Gold_Core_Validator::validate_numeric_gate($out,$approved,array(),'wave3_numeric_out','state');
ppm_test_assert(w3_gold_has($r,'GOLD_CORE_METRIC_OUT_OF_RANGE'),'out-of-range metric without exception must block');
$exception=array('word_count'=>array(
    'exception_id'=>'FIXTURE-EXCEPTION-1','metric_id'=>'word_count','candidate_value'=>9999,'reference_value'=>100,
    'deviation'=>9899,'exact_reason'=>'Fixture proves the human exception branch without production approval.',
    'candidate_quote'=>'candidate quote','candidate_quote_start_offset'=>0,'candidate_quote_end_offset'=>15,
    'reference_quote'=>'reference quote','reference_quote_start_offset'=>0,'reference_quote_end_offset'=>15,
    'approved_by_human_user'=>true,'approval_evidence_id'=>'FIXTURE-HUMAN-EXCEPTION-EVIDENCE'
));
$r=PPM679_Gold_Core_Validator::validate_numeric_gate($out,$approved,$exception,'wave3_numeric_exception','state');
if(empty($r['ok'])){fwrite(STDERR,json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");}
ppm_test_assert(!empty($r['ok']),'complete fixture-only human exception must exercise pass branch');

echo json_encode(array(
    'contract'=>'wave3_gold_core_report_v1','status'=>'PASS',
    'control_baseline_positive'=>'PASS','control_missing_negative'=>'BLOCKED','silent_replacement_negative'=>'BLOCKED',
    'production_tolerance_status'=>'NICHT_AUSGEFÜHRT','fixture_numeric_positive'=>'PASS',
    'out_of_range_without_exception'=>'BLOCKED','fixture_human_exception_branch'=>'PASS',
    'scope_limit'=>'All approvals in this test are explicitly fixture-only and do not authorize production tolerances or replacements.'
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
