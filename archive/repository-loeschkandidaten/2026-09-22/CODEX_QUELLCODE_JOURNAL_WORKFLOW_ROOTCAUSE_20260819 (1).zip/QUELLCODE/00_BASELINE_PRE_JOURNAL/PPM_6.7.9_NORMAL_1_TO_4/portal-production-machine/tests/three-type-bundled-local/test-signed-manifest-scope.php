<?php
require __DIR__.'/bootstrap-three-type.php';
$file=dirname(__DIR__,2).'/certification/build-manifest-v1.json';$m=json_decode((string)file_get_contents($file),true);
ppm_test_assert(is_array($m),'build manifest valid');ppm_test_assert((int)$m['file_count']===count($m['files']),'file_count equals files cardinality');
$required=array_merge(PPM679_Three_Type_Bundled_Release_Validator::REGISTERED_COMPONENTS,[
 'contracts/system-inventory-v3-1.json',
 'contracts/three-type-bundled-approved-candidates-v1.json','contracts/three-type-bundled-local-release-v1.json','contracts/three-type-complete-category-hierarchy-snapshot-v2.json','contracts/three-type-v38-baseline-byte-identity-v1.json',
 'traceability/THREE_TYPE_BUNDLED_INTEGRATION_SCOPE.json','traceability/THREE_TYPE_BUNDLED_INTEGRATION_BINDING.json'
]);
foreach($required as $path){ppm_test_assert(isset($m['files'][$path]),$path.' must be in signed manifest');ppm_test_assert(hash_equals($m['files'][$path],hash_file('sha256',dirname(__DIR__,2).'/'.$path)),$path.' signed hash');}
echo json_encode(['status'=>'PASS_THREE_TYPE_SIGNED_MANIFEST_SCOPE','file_count'=>$m['file_count'],'required_integrated_paths'=>count($required)],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
