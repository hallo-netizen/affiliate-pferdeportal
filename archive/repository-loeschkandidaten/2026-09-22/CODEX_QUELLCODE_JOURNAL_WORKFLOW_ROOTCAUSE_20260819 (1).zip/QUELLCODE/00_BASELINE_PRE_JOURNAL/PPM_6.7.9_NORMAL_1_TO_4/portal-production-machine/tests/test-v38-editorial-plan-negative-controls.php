<?php
require __DIR__.'/bootstrap-test.php';

# The Journal route is mandatory, not optional.
PPM679_WP::reset_test_state();
PPM679_WP::seed_test_post(array(
    'ID'=>9886,
    'post_title'=>'Pferde Journal',
    'post_name'=>'journal-falsch',
    'post_status'=>'publish',
    'post_type'=>'page',
    'route'=>'/journal-falsch/',
    'meta'=>array(),
    'category_ids'=>array(),
));
$r=PPM679_Journal_Content_Block_Validator::read_only_live_snapshot();
ppm_test_assert($r['ok']===false&&$r['status']==='BLOCKED_JOURNAL_ROUTE_MISMATCH','wrong Journal route must block');
ppm_test_assert(($r['report']['write_attempted']??false)===false,'wrong Journal route blocks without write');

# A page ID can never be accepted as a taxonomy parent.
PPM679_WP::reset_test_state();
PPM679_WP::seed_test_term(array(
    'term_id'=>1481,
    'name'=>'Pferde Verstehen',
    'slug'=>'pferde-verstehen',
    'taxonomy'=>'category',
    'parent'=>9886,
    'parent_chain_slugs'=>array('journal'),
    'parent_chain_names'=>array('Pferde Journal'),
    'taxonomy_depth'=>2,
    'hierarchy_path'=>'Pferde Journal > Pferde Verstehen',
    'fixture_class'=>'SYNTHETIC_NEGATIVE_ONLY',
));
$r=PPM679_Journal_Content_Block_Validator::read_only_live_snapshot();
ppm_test_assert($r['ok']===false&&$r['status']==='BLOCKED_JOURNAL_PAGE_ID_USED_AS_TERM_PARENT','Journal page ID as term parent must block');

# Wissen is present for planning/dedup but cannot enter the production wave.
$wissen=array(array(
    'canonical_article_id'=>'journal:pferde-verstehen:wissen:grundlagen',
    'title'=>'Pferdeverhalten verstehen: Grundlagen',
    'article_type'=>'Wissen',
    'category_slug'=>'pferde-verstehen',
));
$r=PPM679_Editorial_Plan_Runtime_Gate::preflight($wissen,'negative-wissen','production');
ppm_test_assert($r['ok']===false,'Wissen production must fail closed');
ppm_test_assert(in_array($r['status'],array('BLOCKED_INITIAL_WAVE_ARTICLE_TYPE','BLOCKED_WISSEN_ARTICLE_TYPE_NOT_RELEASED','BLOCKED_EDITORIAL_PLAN_SLOT_NOT_PRODUCTION_ENABLED'),true),'Wissen failure must be explicit');

# The start wave cannot exceed four drafts and cannot repeat a type.
$wave=array(
 array('article_type'=>'FAQ'),
 array('article_type'=>'Beratung'),
 array('article_type'=>'Vergleich'),
 array('article_type'=>'Pflege'),
 array('article_type'=>'FAQ'),
);
$errors=PPM679_Production_Wave_Governor::validate($wave);
$codes=array_column($errors,'error_code');
ppm_test_assert(in_array('BLOCKED_INITIAL_WAVE_TOO_LARGE',$codes,true),'wave larger than four must block');
ppm_test_assert(in_array('BLOCKED_INITIAL_WAVE_TYPE_DUPLICATE',$codes,true),'duplicate type in wave must block');

# Category reimport cannot silently rename, move, remove, or collide.
$old=array(
 array('stable_category_id'=>'journal:a','name'=>'A','slug'=>'a','portal_path'=>'Journal > A','content_block'=>'journal','allowed_article_types'=>array('wissen'),'active'=>true),
 array('stable_category_id'=>'journal:b','name'=>'B','slug'=>'b','portal_path'=>'Journal > B','content_block'=>'journal','allowed_article_types'=>array('wissen'),'active'=>true),
);
$renamed=$old;$renamed[0]['name']='A neu';$renamed[0]['slug']='a-neu';
$r=PPM679_Category_Reimport_Validator::compare($old,$renamed);
ppm_test_assert($r['ok']===true&&$r['changes'][0]['change_type']==='RENAME_PROPOSAL'&&$r['changes'][0]['status']==='BLOCKED_PENDING_EXPLICIT_APPROVAL','silent rename must be approval-blocked');
$moved=$old;$moved[0]['portal_path']='Journal > Neu > A';
$r=PPM679_Category_Reimport_Validator::compare($old,$moved);
ppm_test_assert($r['ok']===true&&$r['changes'][0]['change_type']==='MOVE_PROPOSAL'&&$r['changes'][0]['status']==='BLOCKED_PENDING_EXPLICIT_APPROVAL','silent move must be approval-blocked');
$removed=array($old[0]);
$r=PPM679_Category_Reimport_Validator::compare($old,$removed);
ppm_test_assert($r['ok']===true&&$r['changes'][0]['change_type']==='DEACTIVATE_PROPOSAL'&&$r['changes'][0]['status']==='BLOCKED_PENDING_EXPLICIT_APPROVAL','silent removal must be approval-blocked');
$collision=$old;$collision[1]['slug']='a';
$r=PPM679_Category_Reimport_Validator::compare($old,$collision);
ppm_test_assert($r['ok']===false&&$r['status']==='BLOCKED_CATEGORY_REIMPORT_SLUG_COLLISION','slug collision must block');

# Published, regular draft, and unresolved nontechnical trash all block silent recreation.
$slot=PPM679_Editorial_Plan_Registry::find_slot(array('plan_item_key'=>'faq-hufpflege-v4'));
ppm_test_assert(is_array($slot),'negative duplicate slot resolved');
foreach(array('publish','draft','trash') as $status){
    PPM679_WP::reset_test_state();
    PPM679_WP::seed_test_post(array(
        'ID'=>40000+strlen($status),
        'post_title'=>$slot['working_title'],
        'post_name'=>'existing-'.$status,
        'post_status'=>$status,
        'post_type'=>'post',
        'meta'=>array('_ppm679_canonical_article_id'=>$slot['canonical_article_id']),
        'category_ids'=>array(),
    ));
    $r=PPM679_Editorial_Plan_Runtime_Gate::preflight(array(array(
        'canonical_article_id'=>$slot['canonical_article_id'],
        'title'=>$slot['working_title'],
        'article_type'=>$slot['article_type'],
        'category_slug'=>$slot['category_slug'],
    )),'negative-duplicate-'.$status,'production');
    ppm_test_assert($r['ok']===false&&$r['status']==='BLOCKED_SYSTEMWIDE_CONTENT_DUPLICATE',$status.' duplicate must block');
}

echo json_encode(array(
    'status'=>'PASS_V38_EDITORIAL_PLAN_NEGATIVE_CONTROLS',
    'journal_route_required'=>true,
    'page_id_as_term_parent_blocked'=>true,
    'wissen_generation_blocked'=>true,
    'wave_over_four_blocked'=>true,
    'reimport_nonadditive_changes_blocked'=>true,
    'publish_draft_trash_duplicates_blocked'=>true,
    'automatic_publish_allowed'=>false,
),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n";
