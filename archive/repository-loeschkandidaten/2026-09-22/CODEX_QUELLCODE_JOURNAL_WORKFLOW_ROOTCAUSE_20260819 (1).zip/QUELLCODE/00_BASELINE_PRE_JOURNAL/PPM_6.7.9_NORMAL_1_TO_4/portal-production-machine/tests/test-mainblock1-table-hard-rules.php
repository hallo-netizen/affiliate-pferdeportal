<?php
require_once __DIR__.'/bootstrap-test.php';
$c=json_decode(file_get_contents(dirname(__DIR__).'/contracts/g9-single-faq-approved-candidate-v1.json'),true);$html=$c['candidate']['content_html'];
ppm_test_assert(PPM679_Table_Hard_Rule_Validator::validate_source_html($html)===array(),'corrected source table must pass');
$bad1=str_replace('system-129-table ','',$html);ppm_test_assert(count(PPM679_Table_Hard_Rule_Validator::validate_source_html($bad1))>0,'missing selector must block');
$bad2=str_replace('<table class="system-129-table','<table style="border:1px solid red;background:#fff" class="system-129-table',$html);ppm_test_assert(count(PPM679_Table_Hard_Rule_Validator::validate_source_html($bad2))>0,'inline outer/background override must block');
echo json_encode(array('status'=>'PASS_MAINBLOCK1_TABLE_SOURCE_RULES','positive'=>true,'negative_cases'=>2,'publish_allowed'=>false),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
