<?php
require_once __DIR__.'/bootstrap-test.php';
PPM679_WP::reset_test_state();
PPM679_Storage::reset_test_state();
$input=json_decode((string)file_get_contents(__DIR__.'/canonical-runtime-input.json'),true);
$items=array_values($input['items']);
function ppm679_cardinality_plan($items,$id) {
    return array(
        'contract'=>'production_plan_v4',
        'plan_contract_version'=>'4.0.0',
        'required_plugin_version'=>'6.7.9',
        'plan_id'=>$id,
        'gold_core_binding'=>'FOUR_TYPE_APPROVED_GOLD_CORE_V1',
        'contract_hashes'=>PPM679_Plan_Validator::active_contract_hashes(),
        'items'=>$items,
    );
}
function ppm679_cardinality_codes($result) {
    return array_values(array_unique(array_map(static fn($error)=>(string)$error['error_code'],(array)$result['errors'])));
}
foreach (array(1,2,3,4) as $count) {
    $result=PPM679_Plan_Validator::validate(ppm679_cardinality_plan(array_slice($items,0,$count),'count-'.$count),'cardinality_positive','local');
    $codes=ppm679_cardinality_codes($result);
    ppm_test_assert(!in_array('BLOCKED_PLAN_ITEM_COUNT',$codes,true),'plan with '.$count.' item(s) must pass cardinality');
    ppm_test_assert(!in_array('BLOCKED_PLAN_REQUIRED_TYPE_MISSING',$codes,true),'plan with '.$count.' item(s) must not require absent types');
}
foreach (array(0,5) as $count) {
    $candidate=$count===0?array():array_merge($items,array($items[0]));
    $result=PPM679_Plan_Validator::validate(ppm679_cardinality_plan($candidate,'count-'.$count),'cardinality_negative','local');
    $codes=ppm679_cardinality_codes($result);
    ppm_test_assert(in_array('BLOCKED_PLAN_ITEM_COUNT',$codes,true),'plan with '.$count.' items must fail cardinality');
}
$duplicate=array($items[0],$items[0]);
$duplicate[1]['plan_item_key']='duplicate-type-second-key';
$result=PPM679_Plan_Validator::validate(ppm679_cardinality_plan($duplicate,'duplicate-type'),'duplicate_type','local');
$codes=ppm679_cardinality_codes($result);
ppm_test_assert(in_array('BLOCKED_PLAN_DUPLICATE_ARTICLE_TYPE',$codes,true),'same article type twice must remain blocked');
echo json_encode(array(
    'status'=>'PASS_PLAN_CARDINALITY_1_TO_4',
    'allowed_counts'=>array(1,2,3,4),
    'blocked_counts'=>array(0,5),
    'duplicate_type'=>'BLOCKED',
    'article_quality_rules_changed'=>false,
    'publish_allowed'=>false
),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT)."\n";
