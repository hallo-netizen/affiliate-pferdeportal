<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Journal_Content_Block_Validator {
    public static function validate_contract(){return PPM679_Editorial_Plan_Registry::validate();}
    public static function read_only_live_snapshot(){
        $registry=PPM679_Editorial_Plan_Registry::journal();$errors=array();
        if(!is_array($registry)){return self::blocked(array(self::err('BLOCKED_JOURNAL_REGISTRY_MISSING','JOURNAL_REGISTRY_MUST_LOAD','journal.registry','valid registry',null,'Das Journalregister fehlt.')));}
        $hub_id=(int)($registry['content_block']['live_object_id']??0);$hub=PPM679_WP::get_page_snapshot($hub_id);
        if(!is_array($hub)||($hub['post_type']??'')!=='page'||($hub['post_status']??'')!=='publish'){$errors[]=self::err('BLOCKED_JOURNAL_HUB_MISMATCH','JOURNAL_OBJECT_9886_MUST_BE_PUBLISHED_PAGE','journal.hub',array('ID'=>$hub_id,'post_type'=>'page','status'=>'publish'),$hub,'Der Journal-Einstieg ist live nicht als veröffentlichte Seite auflösbar.');}
        $route=(string)($hub['route']??'');if(rtrim($route,'/').'/'!=='/journal/'){$errors[]=self::err('BLOCKED_JOURNAL_ROUTE_MISMATCH','JOURNAL_HUB_ROUTE_MUST_BE_JOURNAL','journal.hub.route','/journal/',$route,'Die Journal-Seite besitzt nicht die gebundene Route.');}
        $terms=array();
        foreach((array)($registry['categories']??array()) as $i=>$c){$snap=PPM679_WP::category_term_snapshot((int)$c['wp_term_id'],'category');$terms[]=$snap;if(!is_array($snap)||($snap['taxonomy']??'')!=='category'||($snap['slug']??'')!==(string)$c['slug']||($snap['name']??'')!==(string)$c['name']){$errors[]=self::err('BLOCKED_JOURNAL_TERM_MISMATCH','EACH_JOURNAL_TERM_ID_NAME_SLUG_AND_TAXONOMY_MUST_MATCH','journal.categories['.$i.']',array('term_id'=>$c['wp_term_id'],'name'=>$c['name'],'slug'=>$c['slug'],'taxonomy'=>'category'),$snap,'Eine Journal-Kategorie stimmt live nicht mit dem bestätigten Register überein.');}if(is_array($snap)&&(int)($snap['parent']??0)===$hub_id){$errors[]=self::err('BLOCKED_JOURNAL_PAGE_ID_USED_AS_TERM_PARENT','JOURNAL_HUB_PAGE_ID_MUST_NEVER_BE_USED_AS_WORDPRESS_TERM_PARENT','journal.categories['.$i.'].parent','a real WordPress term parent or 0',(int)($snap['parent']??0),'Die Journal-Seiten-ID darf nicht als Taxonomie-Elternterm verwendet werden.');}}
        $snapshot=array('contract'=>'PPM679_READ_ONLY_JOURNAL_RUNTIME_SNAPSHOT_V1','captured_at'=>gmdate('c'),'capture_mode'=>'READ_ONLY_RUNTIME','hub'=>$hub,'terms'=>$terms,'wordpress_write_performed'=>false,'publish_allowed'=>false);
        $snapshot['snapshot_sha256']=PPM679_Diagnostic::stable_hash($snapshot);
        if($errors){return self::blocked($errors,$snapshot);}
        return array('ok'=>true,'status'=>'JOURNAL_READ_ONLY_RUNTIME_SNAPSHOT_PASS','snapshot'=>$snapshot,'publish_allowed'=>false,'write_attempted'=>false);
    }
    public static function block_wissen_generation($article_type){
        if(strtolower(trim((string)$article_type))!=='wissen'){return array();}
        return array(self::err('BLOCKED_WISSEN_ARTICLE_TYPE_NOT_RELEASED','WISSEN_MAY_BE_PLANNED_RESEARCHED_AND_DEDUPED_BUT_NOT_GENERATED','article_type','released signed Wissen contract',$article_type,'Der Beitragstyp Wissen ist noch nicht entwickelt und darf keinen Entwurf erzeugen.'));
    }
    private static function blocked($errors,$snapshot=null){return array('ok'=>false,'status'=>(string)($errors[0]['error_code']??'BLOCKED_JOURNAL'),'report'=>PPM679_Diagnostic::blocked((string)($errors[0]['error_code']??'BLOCKED_JOURNAL'),$errors,'journal_read_only_snapshot','',array('snapshot'=>$snapshot,'write_attempted'=>false)),'publish_allowed'=>false,'write_attempted'=>false);}
    private static function err($code,$rule,$path,$expected,$actual,$reason){return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'journal_content_block','',__CLASS__,null,array(PPM679_Editorial_Plan_Registry::JOURNAL));}
}
