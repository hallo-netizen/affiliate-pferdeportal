<?php
if (!defined('ABSPATH')) { return; }

/** Exact signed-quarantine release gate for Beratung, Vergleich and Pflege. No live action is exposed. */
final class PPM679_Three_Type_Bundled_Release_Validator {
    const VERSION='6.7.9';
    const CONTRACT='THREE_TYPE_BUNDLED_SIGNED_QUARANTINE_RELEASE_GATE_V1';
    const CONTRACT_FILE='contracts/three-type-bundled-local-release-v1.json';
    const BUNDLE_FILE='contracts/three-type-bundled-approved-candidates-v1.json';
    const SNAPSHOT_FILE='contracts/three-type-complete-category-hierarchy-snapshot-v2.json';
    const BASELINE_IDENTITY_FILE='contracts/three-type-v38-baseline-byte-identity-v1.json';
    const INTEGRATION_SCOPE_FILE='traceability/THREE_TYPE_BUNDLED_INTEGRATION_SCOPE.json';
    const INTEGRATION_BINDING_FILE='traceability/THREE_TYPE_BUNDLED_INTEGRATION_BINDING.json';
    const ACTION_CONTEXT='three_type_bundled_signed_quarantine_preflight';
    const SCOPE_MODE='THREE_TYPE_BUNDLED_SIGNED_QUARANTINE_NO_LIVE';
    const REVIEW_VERDICT='CONFIRM_PASS_HAUPTBLOCK_THREE_TYPE_BUNDLED_LOCAL_SOURCE_CANDIDATE';
    const SOURCE_CANDIDATE_SHA256='51ce31d9f5df992f7420d6c26a3cb3e57f7fdef6ee6ec6ad9a482eff8e77d5ef';
    const TYPES=array('Beratung','Vergleich','Pflege');
    const AUTHORIZED_EXISTING_CHANGES=array('certification/build-evidence-v1.json','certification/build-manifest-v1.json','certification/build-manifest-v1.sig','contracts/hard-rule-coverage-matrix-v1.json','contracts/hard-rule-registry-v1.json','contracts/system-inventory-v3-1.json','portal-production-machine.php');
    const REGISTERED_COMPONENTS=array(
        'includes/three-type-complete-category-source.php',
        'includes/three-type-bundled-release-validator.php',
        'includes/three-type-local-content-validator.php',
        'includes/three-type-bundled-local-preflight.php',
    );

    public static function expected_scope() {
        return array(
            'contract'=>self::CONTRACT,'scope_mode'=>self::SCOPE_MODE,'action_context'=>self::ACTION_CONTEXT,
            'requested_article_types'=>self::TYPES,
            'release_contract_file_sha256'=>self::file_hash(self::CONTRACT_FILE),
            'approved_candidate_contract_file_sha256'=>self::file_hash(self::BUNDLE_FILE),
            'complete_category_snapshot_file_sha256'=>self::file_hash(self::SNAPSHOT_FILE),
            'baseline_byte_identity_contract_file_sha256'=>self::file_hash(self::BASELINE_IDENTITY_FILE),
            'integration_scope_file_sha256'=>self::file_hash(self::INTEGRATION_SCOPE_FILE),
            'integration_binding_file_sha256'=>self::file_hash(self::INTEGRATION_BINDING_FILE),
            'preceding_source_candidate_zip_sha256'=>self::SOURCE_CANDIDATE_SHA256,
            'preceding_independent_review_verdict'=>self::REVIEW_VERDICT,
            'bootstrap_registered'=>true,'signed_build_required'=>true,'signing_performed'=>true,
            'wordpress_access_allowed'=>false,'draft_allowed'=>false,'installation_allowed'=>false,
            'publish_allowed'=>false,'wissen_allowed'=>false,
        );
    }

    public static function validate($action_context,$scope,$contract_override=null,$bundle_override=null) {
        $errors=array();
        if (!PPM679_WP::is_test_mode()) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_SIGNED_QUARANTINE_LOCAL_ONLY','THREE_TYPE_SIGNED_QUARANTINE_PREFLIGHT_MUST_RUN_ONLY_IN_LOCAL_TEST_MODE','runtime.test_mode',true,false,'Der signierte Drei-Typ-Quarantänepfad besitzt noch keine Live- oder Draft-Freigabe.');
        }
        if ((string)$action_context!==self::ACTION_CONTEXT) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_ACTION_CONTEXT','THREE_TYPE_SIGNED_QUARANTINE_REQUIRES_EXACT_ACTION_CONTEXT','action_context',self::ACTION_CONTEXT,$action_context,'Der Drei-Typ-Vertrag wurde außerhalb seines exakt gebundenen signierten Vorlaufs angefordert.');
        }
        if (!is_array($scope)) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_SCOPE_MISSING','THREE_TYPE_SIGNED_QUARANTINE_REQUIRES_EXPLICIT_SCOPE','scope','exact scope object',$scope,'Der explizite Drei-Typ-Scope fehlt.');
            return $errors;
        }
        foreach (self::expected_scope() as $field=>$expected) {
            $actual=array_key_exists($field,$scope)?$scope[$field]:null;
            if (PPM679_Diagnostic::stable_hash($expected)!==PPM679_Diagnostic::stable_hash($actual)) {
                $errors[]=self::err('BLOCKED_THREE_TYPE_SCOPE_MISMATCH','THREE_TYPE_SIGNED_SCOPE_MUST_MATCH_EXACT_APPROVED_BINDING','scope.'.$field,$expected,$actual,'Der Drei-Typ-Scope weicht von der signierten Quarantänebindung ab.');
            }
        }
        if (($contract_override!==null || $bundle_override!==null) && !PPM679_WP::is_test_mode()) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_OVERRIDE','THREE_TYPE_CONTRACT_OVERRIDES_ALLOWED_ONLY_IN_LOCAL_TEST_MODE','override',null,'provided','Ein Override ist außerhalb des lokalen Tests verboten.');
        }
        $contract=$contract_override!==null?$contract_override:self::load(self::CONTRACT_FILE);
        $bundle=$bundle_override!==null?$bundle_override:self::load(self::BUNDLE_FILE);
        $errors=array_merge($errors,self::validate_contract($contract),self::validate_bundle($bundle),self::validate_traceability());

        $global=PPM679_Article_Type_Validator::load_contract();
        foreach (array('FAQ','Beratung','Vergleich','Pflege') as $index=>$type) {
            $spec=(array)($global['types'][$type]??array());
            if (($spec['production_allowed']??null)!==false) {
                $errors[]=self::err('BLOCKED_THREE_TYPE_GLOBAL_RELEASE_CHANGED','SIGNED_THREE_TYPE_GATE_MUST_NOT_GLOBALLY_RELEASE_ANY_TYPE','types.'.$type.'.production_allowed',false,$spec['production_allowed']??null,'Der signierte Drei-Typ-Block darf den globalen Vier-Typ-Vertrag nicht freischalten.',$index);
            }
        }
        return $errors;
    }

    private static function validate_contract($c) {
        $errors=array();
        if (!is_array($c)) { return array(self::err('BLOCKED_THREE_TYPE_RELEASE_CONTRACT_MISSING','THREE_TYPE_RELEASE_CONTRACT_MUST_EXIST','release_contract',self::CONTRACT,$c,'Der signierte Drei-Typ-Freigabevertrag fehlt.')); }
        $claimed=(string)($c['contract_self_sha256']??''); $copy=$c; unset($copy['contract_self_sha256']);
        $actual=PPM679_Diagnostic::stable_hash($copy);
        if ($claimed==='' || !hash_equals($actual,$claimed)) { $errors[]=self::err('BLOCKED_THREE_TYPE_RELEASE_SELF_HASH','THREE_TYPE_RELEASE_CONTRACT_SELF_HASH_MUST_MATCH','release_contract.contract_self_sha256',$actual,$claimed,'Der signierte Drei-Typ-Vertrag wurde verändert.'); }
        $expected=array(
            'contract'=>self::CONTRACT,'scope_mode'=>self::SCOPE_MODE,'action_context'=>self::ACTION_CONTEXT,
            'requested_article_types'=>self::TYPES,'preceding_source_candidate_zip_sha256'=>self::SOURCE_CANDIDATE_SHA256,
            'preceding_independent_review_verdict'=>self::REVIEW_VERDICT,
            'approved_candidate_contract_file_sha256'=>self::file_hash(self::BUNDLE_FILE),
            'complete_category_snapshot_file_sha256'=>self::file_hash(self::SNAPSHOT_FILE),
            'baseline_byte_identity_contract_file_sha256'=>self::file_hash(self::BASELINE_IDENTITY_FILE),
            'complete_portal_category_source_file_sha256'=>self::file_hash('contracts/complete-portal-category-source-v1.json'),
            'global_four_type_contract_file_sha256'=>self::file_hash('contracts/article-type-templates.json'),
            'integration_scope_file_sha256'=>self::file_hash(self::INTEGRATION_SCOPE_FILE),
            'integration_bootstrap_file_sha256'=>self::file_hash('portal-production-machine.php'),
            'registered_component_paths'=>self::REGISTERED_COMPONENTS,
            'global_four_type_contract_modified'=>false,'authorized_existing_file_changes'=>self::AUTHORIZED_EXISTING_CHANGES,
            'global_production_release_allowed'=>false,'local_signed_quarantine_test_execution_allowed'=>true,
            'wordpress_access_allowed'=>false,'draft_allowed'=>false,'installation_allowed'=>false,
            'signing_required'=>true,'signing_performed'=>true,'publish_allowed'=>false,'wissen_allowed'=>false,
            'external_review_required'=>true,'external_review_claimed_by_build'=>true,
            'overall_pass_requires_each_type_pass'=>true,'type_specific_positive_and_negative_evidence_required'=>true,
            'one_shared_claude_package_required'=>true,'next_phase_requires_separate_user_authorization'=>true,
        );
        foreach ($expected as $field=>$value) {
            $actual_value=$c[$field]??null;
            if (PPM679_Diagnostic::stable_hash($value)!==PPM679_Diagnostic::stable_hash($actual_value)) {
                $errors[]=self::err('BLOCKED_THREE_TYPE_RELEASE_BINDING','THREE_TYPE_RELEASE_FIELD_MUST_MATCH_EXACT_VALUE','release_contract.'.$field,$value,$actual_value,'Eine feste Drei-Typ-Freigabebindung weicht ab.');
            }
        }
        return $errors;
    }

    private static function validate_bundle($b) {
        $errors=array();
        if (!is_array($b)) { return array(self::err('BLOCKED_THREE_TYPE_BUNDLE_MISSING','THREE_TYPE_APPROVED_BUNDLE_MUST_EXIST','candidate_bundle',self::BUNDLE_FILE,$b,'Der gebundene Drei-Typ-Kandidatenvertrag fehlt.')); }
        $claimed=(string)($b['contract_self_sha256']??''); $copy=$b; unset($copy['contract_self_sha256']);
        $actual=PPM679_Diagnostic::stable_hash($copy);
        if ($claimed==='' || !hash_equals($actual,$claimed)) { $errors[]=self::err('BLOCKED_THREE_TYPE_BUNDLE_SELF_HASH','THREE_TYPE_APPROVED_BUNDLE_SELF_HASH_MUST_MATCH','candidate_bundle.contract_self_sha256',$actual,$claimed,'Der Claude-bestätigte Drei-Typ-Kandidatenvertrag wurde verändert.'); }
        if (($b['contract']??'')!=='THREE_TYPE_BUNDLED_APPROVED_CANDIDATES_V1' || ($b['article_types']??null)!==self::TYPES || (int)($b['article_count']??0)!==3 || count((array)($b['items']??array()))!==3) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_BUNDLE_CARDINALITY','THREE_TYPE_BUNDLE_REQUIRES_EXACTLY_ONE_ITEM_PER_ALLOWED_TYPE','candidate_bundle',array('article_types'=>self::TYPES,'article_count'=>3),array('contract'=>$b['contract']??null,'article_types'=>$b['article_types']??null,'article_count'=>$b['article_count']??null,'items'=>count((array)($b['items']??array()))),'Der Kandidatenvertrag enthält nicht exakt Beratung, Vergleich und Pflege.');
        }
        $expected_hashes=array('Beratung'=>'6628e476bdef9362c34bd60deca05f811ac68704abe1d0b07bb23f46ada02630','Vergleich'=>'008e7c1ca3cb59bf6af9dd3436572233117841a50d3b0162822aafa85d15a4fa','Pflege'=>'770260c7e7a9d86f967b7b05d374540e8696e5bc1c35fa43f9e7f59d3ecbcfff');
        $seen=array();
        foreach ((array)($b['items']??array()) as $index=>$item) {
            $type=(string)($item['article_type']??'');
            if (!in_array($type,self::TYPES,true) || isset($seen[$type])) { $errors[]=self::err('BLOCKED_THREE_TYPE_BUNDLE_TYPE','THREE_TYPE_BUNDLE_TYPES_MUST_BE_ALLOWED_AND_UNIQUE','candidate_bundle.items['.$index.'].article_type',self::TYPES,$type,'Ein Typ fehlt, ist doppelt oder gehört nicht in den Block.',$index); }
            $seen[$type]=true;
            $body=(string)($item['canonical_article']['body_html']??'');
            $declared=(string)($item['canonical_article']['body_html_sha256']??'');
            $expected=$expected_hashes[$type]??'';
            if ($expected==='' || !hash_equals($expected,$declared) || !hash_equals($expected,hash('sha256',$body))) { $errors[]=self::err('BLOCKED_THREE_TYPE_ARTICLE_HASH','SIGNED_THREE_TYPE_ITEM_MUST_MATCH_EXACT_CLAUDE_APPROVED_BODY','candidate_bundle.items['.$index.'].canonical_article.body_html_sha256',$expected,array('declared'=>$declared,'actual'=>hash('sha256',$body)),'Ein Artikel weicht von der Claude-bestätigten Bytebindung ab.',$index); }
        }
        $local=(array)($b['local_phase']??array());
        foreach (array('wordpress_access_allowed','draft_allowed','installation_allowed','signing_performed','publish_allowed','wissen_allowed') as $field) {
            if (($local[$field]??null)!==false) { $errors[]=self::err('BLOCKED_THREE_TYPE_SOURCE_BOUNDARY','APPROVED_SOURCE_BUNDLE_MUST_RETAIN_ORIGINAL_NO_LIVE_METADATA','candidate_bundle.local_phase.'.$field,false,$local[$field]??null,'Der unveränderte Quellkandidatenvertrag öffnet eine verbotene Grenze.'); }
        }
        if (($b['independent_review']['claimed_by_build']??null)!==false || ($b['independent_review']['status']??'')!=='PENDING_CLAUDE_REVIEW') {
            $errors[]=self::err('BLOCKED_THREE_TYPE_SOURCE_REVIEW_METADATA','APPROVED_SOURCE_BUNDLE_MUST_RETAIN_PRE_REVIEW_METADATA','candidate_bundle.independent_review',array('claimed_by_build'=>false,'status'=>'PENDING_CLAUDE_REVIEW'),$b['independent_review']??null,'Der exakt geprüfte Quellvertrag darf nachträglich nicht umgeschrieben werden; das spätere PASS ist im Release-Vertrag gebunden.');
        }
        return $errors;
    }

    private static function validate_traceability() {
        $errors=array();
        $scope=self::load(self::INTEGRATION_SCOPE_FILE); $binding=self::load(self::INTEGRATION_BINDING_FILE);
        foreach (array('scope'=>$scope,'binding'=>$binding) as $label=>$data) {
            if (!is_array($data)) { $errors[]=self::err('BLOCKED_THREE_TYPE_TRACEABILITY_MISSING','THREE_TYPE_INTEGRATION_TRACEABILITY_MUST_EXIST','traceability.'.$label,'valid contract',$data,'Eine Integrations-Traceability-Datei fehlt.'); continue; }
            $claimed=(string)($data['contract_self_sha256']??''); $copy=$data; unset($copy['contract_self_sha256']); $actual=PPM679_Diagnostic::stable_hash($copy);
            if ($claimed==='' || !hash_equals($actual,$claimed)) { $errors[]=self::err('BLOCKED_THREE_TYPE_TRACEABILITY_SELF_HASH','THREE_TYPE_TRACEABILITY_SELF_HASH_MUST_MATCH','traceability.'.$label.'.contract_self_sha256',$actual,$claimed,'Eine Integrations-Traceability-Datei wurde verändert.'); }
        }
        if (!is_array($scope) || !is_array($binding)) { return $errors; }
        $scope_expected=array('preceding_source_candidate_zip_sha256'=>self::SOURCE_CANDIDATE_SHA256,'preceding_independent_review_verdict'=>self::REVIEW_VERDICT,'article_types'=>self::TYPES,'authorized_changed_existing_paths'=>self::AUTHORIZED_EXISTING_CHANGES,'publish_allowed'=>false,'wordpress_access_allowed'=>false,'draft_allowed'=>false,'installation_allowed'=>false,'wissen_allowed'=>false,'trust_root_rotation_allowed'=>false);
        foreach($scope_expected as $field=>$value){if(PPM679_Diagnostic::stable_hash($scope[$field]??null)!==PPM679_Diagnostic::stable_hash($value)){$errors[]=self::err('BLOCKED_THREE_TYPE_TRACEABILITY_SCOPE','THREE_TYPE_INTEGRATION_SCOPE_FIELD_MUST_MATCH','traceability.scope.'.$field,$value,$scope[$field]??null,'Der autorisierte Integrationsumfang weicht ab.');}}
        $map=(array)($binding['implementation_file_sha256']??array());
        foreach($map as $relative=>$expected){$actual=self::file_hash($relative);if(!is_string($expected)||$actual===''||!hash_equals($expected,$actual)){$errors[]=self::err('BLOCKED_THREE_TYPE_TRACEABILITY_FILE_HASH','THREE_TYPE_INTEGRATION_FILE_HASH_MUST_MATCH','traceability.binding.implementation_file_sha256.'.$relative,$expected,$actual,'Eine gebundene Integrationsdatei weicht ab.');}}
        if (($binding['registered_component_paths']??null)!==self::REGISTERED_COMPONENTS || ($binding['changed_existing_paths']??null)!==self::AUTHORIZED_EXISTING_CHANGES) { $errors[]=self::err('BLOCKED_THREE_TYPE_TRACEABILITY_BOUNDARY','THREE_TYPE_INTEGRATION_PATH_BOUNDARY_MUST_MATCH','traceability.binding.paths',array('registered'=>self::REGISTERED_COMPONENTS,'changed'=>self::AUTHORIZED_EXISTING_CHANGES),array('registered'=>$binding['registered_component_paths']??null,'changed'=>$binding['changed_existing_paths']??null),'Die Integrationspfadgrenze weicht ab.'); }
        return $errors;
    }

    public static function load($relative) { $file=PPM679_PLUGIN_DIR.$relative; $decoded=is_file($file)?json_decode((string)file_get_contents($file),true):null; return is_array($decoded)?$decoded:null; }
    private static function file_hash($relative) { $f=PPM679_PLUGIN_DIR.$relative; return is_file($f)?hash_file('sha256',$f):''; }
    private static function err($code,$rule,$path,$expected,$actual,$reason,$index=null) { return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,self::ACTION_CONTEXT,'',__CLASS__,$index,array(self::CONTRACT_FILE,self::BUNDLE_FILE,self::SNAPSHOT_FILE,self::BASELINE_IDENTITY_FILE,self::INTEGRATION_SCOPE_FILE,self::INTEGRATION_BINDING_FILE)); }
}
