<?php
require_once dirname(__DIR__).'/bootstrap-test.php';
foreach(array(
 'PPM679_Three_Type_Complete_Category_Source',
 'PPM679_Three_Type_Bundled_Release_Validator',
 'PPM679_Three_Type_Local_Content_Validator',
 'PPM679_Three_Type_Bundled_Local_Preflight'
) as $class){ppm_test_assert(class_exists($class),$class.' must be registered by plugin loader');}
PPM679_WP::reset_test_state();
PPM679_Storage::reset_test_state();
PPM679_Category_Assignment_Validator::reset_test_state();
function ppm_three_bundle(){return PPM679_Three_Type_Bundled_Release_Validator::load(PPM679_Three_Type_Bundled_Release_Validator::BUNDLE_FILE);}
function ppm_three_snapshot(){return PPM679_Three_Type_Complete_Category_Source::load();}
function ppm_three_scope(){return PPM679_Three_Type_Bundled_Release_Validator::expected_scope();}
function ppm_three_item($type){foreach((array)(ppm_three_bundle()['items']??array()) as $item){if(($item['article_type']??'')===$type)return $item;}return null;}
function ppm_three_pack($type){foreach((array)(ppm_three_bundle()['fact_pack_bundle']['fact_packs']??array()) as $pack){if(($pack['article_type']??'')===$type)return $pack;}return null;}
function ppm_three_generated($type){$item=ppm_three_item($type);$pack=ppm_three_pack($type);PPM679_Storage::save_fact_pack((string)$pack['fact_pack_id'],$pack);return array($item,$pack,PPM679_Content_Generator::generate($item,$pack));}
function ppm_three_codes($errors){return array_values(array_unique(array_filter(array_map(fn($e)=>(string)($e['error_code']??''),(array)$errors))));}
