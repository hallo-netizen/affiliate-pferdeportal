<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

$base=(string)file_get_contents(__DIR__.'/fixtures/wave1/positive-control-structural-faq.html');
$title='Was muss vor einer Fahrt mit Pferdeanhänger geprüft werden?';
function mut_eval($title,$html) {
    return PPM679_Known_Error_Gate::evaluate(
        array('title'=>$title,'article_type'=>'FAQ','content_html'=>$html,'content_hash'=>hash('sha256',$html)),
        array('article_type'=>'FAQ'),'wave1_mutation','local-state-hash'
    );
}
function mut_codes($r) { return array_map(fn($e)=>(string)($e['error_code']??''),$r['errors']??array()); }
function mut_case($id,$expected,$title,$html) {
    $r=mut_eval($title,$html); $codes=mut_codes($r);
    ppm_test_assert(empty($r['ok']),$id.' must block');
    ppm_test_assert(in_array($expected,$codes,true),$id.' must report '.$expected);
    return array('test_id'=>$id,'expected_error'=>$expected,'actual_error_codes'=>array_values(array_unique($codes)),'content_hash'=>hash('sha256',$html),'status'=>'MUTATION_BLOCK_CHECK_OK');
}
$cases=array();
$cases[]=mut_case('W1_NEG_BODY_H1','BLOCKED_KNOWN_BODY_H1',$title,'<h1>'.$title.'</h1>'.$base);
$cases[]=mut_case('W1_NEG_VISIBLE_MARKER','BLOCKED_KNOWN_VISIBLE_TEST_MARKER','[LT4-TEST-123] '.$title,$base);
$cases[]=mut_case('W1_NEG_TITLE_REPEAT','BLOCKED_KNOWN_TITLE_REPEATED_IN_BODY',$title,'<p>'.$title.'</p>'.$base);
$cases[]=mut_case('W1_NEG_GENERIC_HEADING','BLOCKED_KNOWN_GENERIC_HEADING',$title,str_replace('Welche Angaben müssen vor der Abfahrt zusammenpassen?','Die kurze Antwort',$base));
$cases[]=mut_case('W1_NEG_ADJACENT_HEADINGS','BLOCKED_KNOWN_ADJACENT_HEADINGS',$title,str_replace('<p>Vergleiche die zulässige Anhängelast','<h3>Direkt danach</h3><p>Vergleiche die zulässige Anhängelast',$base));
$cases[]=mut_case('W1_NEG_LIST_MISSING','BLOCKED_KNOWN_REQUIRED_LIST_MISSING',$title,preg_replace('/<ul>.*?<\/ul>/su','<p>Vier Punkte stehen nur im Fließtext.</p>',$base));
$cases[]=mut_case('W1_NEG_LIST_ONLY_THREE','BLOCKED_KNOWN_REQUIRED_LIST_MISSING',$title,preg_replace('/<li>Papiere und Fahrerlaubnis bereithalten<\/li>/u','',$base));
$cases[]=mut_case('W1_NEG_TWO_LINKS','BLOCKED_KNOWN_INTERNAL_LINK_COUNT',$title,preg_replace('/<a href="\/magazin\/pferdeanhaenger-sicher-fahren\/">.*?<\/a>/u','Pferdeanhänger sicher fahren',$base));
$cases[]=mut_case('W1_NEG_INVALID_LINK','BLOCKED_KNOWN_INTERNAL_LINK_INVALID',$title,str_replace('/pferdeanhaenger/','https://example.test/',$base));
$endLinks='<section data-block="further_information"><h2>Weiterführende Informationen zur sicheren Anhängerfahrt</h2><p><a href="/pferdeanhaenger/">Pferdeanhänger</a> <a href="/pferdeanhaenger/zugfahrzeuge/">Zugfahrzeuge</a> <a href="/magazin/pferdeanhaenger-sicher-fahren/">Sicher fahren</a></p></section>';
$clustered=preg_replace('/<a\b[^>]*>.*?<\/a>/su','Link',$base);
$clustered=preg_replace('/<section data-block="further_information">.*?<\/section>/su',$endLinks,$clustered);
$cases[]=mut_case('W1_NEG_LINKS_CLUSTERED_END','BLOCKED_KNOWN_LINKS_CLUSTERED_AT_END',$title,$clustered);
$short=preg_replace('/<section data-block="conclusion">.*?<\/section>/su','<section data-block="conclusion"><h2>Fazit</h2><p>Nur vollständig geprüft losfahren.</p></section>',$base);
$cases[]=mut_case('W1_NEG_SHORT_CONCLUSION','BLOCKED_KNOWN_SHORT_CONCLUSION',$title,$short);
$cases[]=mut_case('W1_NEG_REGRESSION_PATTERN','BLOCKED_KNOWN_REGRESSION_PATTERN',$title,str_replace('Entscheidend ist nicht','Als belastbares Ergebnis muss nicht',$base));
$cases[]=mut_case('W1_NEG_INVALID_HTML','BLOCKED_KNOWN_INVALID_HTML',$title,$base.'<div>');

$positive=mut_eval($title,$base);
ppm_test_assert(!empty($positive['ok']),'Base structural control must PASS');
$report=array(
    'contract'=>'wave1_known_error_mutation_report_v1',
    'status'=>'PASS',
    'negative_test_count'=>count($cases),
    'negative_tests'=>$cases,
    'positive_control'=>array('status'=>$positive['status'],'content_hash'=>hash('sha256',$base)),
    'code_hash'=>hash_file('sha256',dirname(__DIR__).'/includes/known-error-gate.php'),
    'contract_hash'=>hash_file('sha256',dirname(__DIR__).'/contracts/known-error-gate-v1.json')
);
echo json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
