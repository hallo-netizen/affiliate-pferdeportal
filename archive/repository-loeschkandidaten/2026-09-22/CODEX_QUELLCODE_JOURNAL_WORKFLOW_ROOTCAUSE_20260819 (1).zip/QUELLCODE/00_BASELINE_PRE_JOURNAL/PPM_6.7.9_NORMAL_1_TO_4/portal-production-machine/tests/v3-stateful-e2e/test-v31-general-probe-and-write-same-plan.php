<?php
require_once __DIR__.'/fixture-builder.php';
$p=v31_prepare('g9-request-v31-general-probe-0014',true);ppm_test_assert($p['ok']===true,'general probe');
$fp=$p['plan']['planned_write_fingerprint'];
$w=v31_write_prepared($p);ppm_test_assert($w['ok']===true,'write exact plan');
$s=PPM679_WP::get_post_snapshot($w['post_id']);
ppm_test_assert((string)PPM679_WP::scalar_meta($s['meta'],'_ppm679_planned_write_fingerprint')===$fp,'stored exact planned fingerprint');
ppm_test_assert(($w['report']['single_write_chokepoint']??'')==='PPM679_WP::insert_draft','single chokepoint');
echo json_encode(array('status'=>'PASS_V31_GENERAL_PROBE_SAME_PLAN','fingerprint'=>$fp,'post_id'=>$w['post_id']),JSON_UNESCAPED_SLASHES)."\n";
