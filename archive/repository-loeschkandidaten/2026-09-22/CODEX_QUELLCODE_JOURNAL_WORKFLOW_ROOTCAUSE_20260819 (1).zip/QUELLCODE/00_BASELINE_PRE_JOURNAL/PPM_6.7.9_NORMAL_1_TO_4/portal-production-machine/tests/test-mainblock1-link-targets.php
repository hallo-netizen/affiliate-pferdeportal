<?php
require_once __DIR__.'/bootstrap-test.php';
$c=json_decode(file_get_contents(dirname(__DIR__).'/contracts/g9-single-faq-approved-candidate-v1.json'),true);$html=$c['candidate']['content_html'];$b=$c['item']['quality_binding'];
ppm_test_assert(PPM679_WordPress_Link_Target_Validator::validate_bound_article($html,$b)===array(),'real page bindings must pass local snapshot gate');
$map=array('parent_category'=>array('id'=>101,'type'=>'page','status'=>'publish','parent_url'=>''),'semantic_related'=>array('id'=>102,'type'=>'page','status'=>'publish','parent_url'=>'https://pferde-atelier.de/transport/'),'further_information'=>array('id'=>103,'type'=>'page','status'=>'publish','parent_url'=>'https://pferde-atelier.de/transport/'));
$r=PPM679_WordPress_Link_Target_Validator::revalidate_live_before_write($b,'test',$map);ppm_test_assert($r['ok']===true,'read-only resolved pages must pass');
$bad=$map;$bad['semantic_related']['type']='post';ppm_test_assert(empty(PPM679_WordPress_Link_Target_Validator::revalidate_live_before_write($b,'test',$bad)['ok']),'post target must block');
$bad=$map;$bad['further_information']['id']=0;ppm_test_assert(empty(PPM679_WordPress_Link_Target_Validator::revalidate_live_before_write($b,'test',$bad)['ok']),'missing target must block');
$badhtml=str_replace('Weitere Grundlagen','Die zulässige Kategorie führt eine Ebene höher. Weitere Grundlagen',$html);ppm_test_assert(count(PPM679_WordPress_Link_Target_Validator::validate_bound_article($badhtml,$b))>0,'technical meta sentence must block');
echo json_encode(array('status'=>'PASS_MAINBLOCK1_REAL_LINK_TARGETS','target_count'=>3,'post_targets'=>0,'live_write_attempted'=>false,'negative_cases'=>3),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
