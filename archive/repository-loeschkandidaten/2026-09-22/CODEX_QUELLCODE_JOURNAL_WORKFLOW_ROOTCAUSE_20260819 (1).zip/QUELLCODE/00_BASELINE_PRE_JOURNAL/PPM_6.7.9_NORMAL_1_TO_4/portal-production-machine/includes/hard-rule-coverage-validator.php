<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Hard_Rule_Coverage_Validator {
    const REGISTRY='contracts/hard-rule-registry-v1.json';
    const MATRIX='contracts/hard-rule-coverage-matrix-v1.json';
    const SYSTEM_INVENTORY='contracts/system-inventory-v3-1.json';
    const TRANSITION_MATRIX='contracts/state-transition-matrix-v3-1.json';

    private static function load($f){
        $p=PPM679_PLUGIN_DIR.$f;
        $d=is_file($p)?json_decode((string)file_get_contents($p),true):null;
        return is_array($d)?$d:null;
    }
    private static function err($code,$rule,$path,$expected,$actual,$reason){
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'hard_rule_coverage','',__CLASS__,null,array(self::REGISTRY,self::MATRIX,self::SYSTEM_INVENTORY,self::TRANSITION_MATRIX));
    }
    private static function self_hash_errors($obj,$rel){
        if(!is_array($obj)){return array(self::err('BLOCKED_HARD_RULE_FILES_MISSING','REGISTRY_AND_MATRIX_MUST_EXIST',$rel,'valid JSON',null,'Die zentrale Regelabdeckung fehlt.'));}
        $self=(string)($obj['contract_self_sha256']??'');$copy=$obj;unset($copy['contract_self_sha256']);
        $actual=PPM679_Diagnostic::stable_hash($copy);
        return ($self!==''&&hash_equals($self,$actual))?array():array(self::err('BLOCKED_HARD_RULE_SELF_HASH','REGISTRY_OR_MATRIX_SELF_HASH_MUST_MATCH',$rel.'.contract_self_sha256',$actual,$self,'Regelregister oder Abdeckungsmatrix wurde verändert.'));
    }

    public static function validate($phase='LOCAL'){
        $r=self::load(self::REGISTRY);$m=self::load(self::MATRIX);$errors=array();
        $errors=array_merge($errors,self::self_hash_errors($r,self::REGISTRY),self::self_hash_errors($m,self::MATRIX));
        if(!is_array($r)||!is_array($m)){return $errors;}

        $registry_file_hash=hash_file('sha256',PPM679_PLUGIN_DIR.self::REGISTRY);
        $system_file_hash=hash_file('sha256',PPM679_PLUGIN_DIR.self::SYSTEM_INVENTORY);
        $transition_file_hash=hash_file('sha256',PPM679_PLUGIN_DIR.self::TRANSITION_MATRIX);
        foreach(array(
            'registry_sha256'=>array($registry_file_hash,$m['registry_sha256']??null),
            'system_inventory_sha256'=>array($system_file_hash,$m['system_inventory_sha256']??null),
            'state_transition_matrix_sha256'=>array($transition_file_hash,$m['state_transition_matrix_sha256']??null)
        ) as $field=>$pair){
            if($pair[0]===''||!hash_equals((string)$pair[0],(string)$pair[1])){$errors[]=self::err('BLOCKED_HARD_RULE_BINDING','COVERAGE_MATRIX_MUST_BIND_EXACT_REGISTRY_SYSTEM_INVENTORY_AND_TRANSITIONS','matrix.'.$field,$pair[0],$pair[1],'Die Abdeckungsmatrix bindet nicht exakt den geprüften Regel- und Systemstand.');}
        }

        $rows=array();foreach((array)($m['rows']??array()) as $x){$rows[(string)($x['rule_id']??'')]=$x;}
        $active_ids=array();
        $required_v31_fields=array('discovery_source','system_inventory_ids','state_transition_scenario_ids','persistence_required','cross_run_behavior','identity_scope','idempotency_expectation','live_preflight_required');
        foreach((array)($r['rules']??array()) as $rule){
            if(($rule['active']??false)!==true){continue;}
            $id=(string)($rule['rule_id']??'');$active_ids[$id]=true;$row=$rows[$id]??null;
            if($id===''||!is_array($row)||($row['mapped']??false)!==true||($row['positive_test_declared']??false)!==true||($row['negative_test_declared']??false)!==true||($row['evidence_declared']??false)!==true||in_array((string)($row['current_state']??''),array('UNKNOWN','UNMAPPED','UNTESTED',''),true)){
                $errors[]=self::err('BLOCKED_HARD_RULE_UNCOVERED','EVERY_ACTIVE_HARD_RULE_REQUIRES_MAPPING_POSITIVE_NEGATIVE_AND_EVIDENCE','hard_rules.'.$id,'fully mapped and tested',$row,'Eine aktive harte Regel ist nicht vollständig abgedeckt.');
                continue;
            }
            foreach($required_v31_fields as $field){
                if(!array_key_exists($field,$rule)){$errors[]=self::err('BLOCKED_V31_RULE_FIELD_MISSING','EVERY_ACTIVE_RULE_REQUIRES_V31_DISCOVERY_AND_STATE_FIELDS','hard_rules.'.$id.'.'.$field,'field present',null,'Eine aktive Regel besitzt nicht alle V3.1-Pflichtfelder.');}
            }
            if(!in_array((string)($rule['discovery_source']??''),array('REGISTRY','CODE','CONTRACT','PERSISTENCE','LIVE_STATE','REVIEWER'),true)){$errors[]=self::err('BLOCKED_V31_DISCOVERY_SOURCE','RULE_DISCOVERY_SOURCE_MUST_BE_DECLARED','hard_rules.'.$id.'.discovery_source','allowed source',$rule['discovery_source']??null,'Die Herkunft der Regel ist nicht nachvollziehbar.');}
            foreach(array('system_inventory_ids','state_transition_scenario_ids') as $field){if(!is_array($rule[$field]??null)){$errors[]=self::err('BLOCKED_V31_RULE_MAPPING_TYPE','V31_RULE_MAPPING_FIELDS_MUST_BE_ARRAYS','hard_rules.'.$id.'.'.$field,'array',$rule[$field]??null,'Die systemabgeleitete Regelzuordnung besitzt den falschen Typ.');}}
            foreach(array('persistence_required','live_preflight_required') as $field){if(!is_bool($rule[$field]??null)){$errors[]=self::err('BLOCKED_V31_RULE_BOOLEAN','V31_RULE_BOOLEAN_FIELDS_MUST_BE_EXPLICIT','hard_rules.'.$id.'.'.$field,'boolean',$rule[$field]??null,'Eine V3.1-Regelgrenze ist nicht explizit boolesch.');}}
            foreach(array('cross_run_behavior','identity_scope','idempotency_expectation') as $field){if(trim((string)($rule[$field]??''))===''){$errors[]=self::err('BLOCKED_V31_RULE_SEMANTICS','V31_RULE_STATE_AND_IDENTITY_SEMANTICS_MUST_BE_NON_EMPTY','hard_rules.'.$id.'.'.$field,'non-empty',$rule[$field]??null,'Eine V3.1-Regel beschreibt ihr Lauf- oder Identitätsverhalten nicht.');}}
            if(in_array((string)($rule['discovery_source']??''),array('CODE','PERSISTENCE','LIVE_STATE','CONTRACT'),true) && empty($rule['system_inventory_ids']) && empty($rule['state_transition_scenario_ids'])){
                $errors[]=self::err('BLOCKED_V31_RULE_NOT_SYSTEM_BOUND','CODE_PERSISTENCE_LIVE_OR_CONTRACT_RULE_MUST_BIND_SYSTEM_OR_STATE_DISCOVERY','hard_rules.'.$id,'system or state ids',$rule,'Eine code-, persistenz-, live- oder vertragsseitig entdeckte Regel ist nicht an Inventur oder Zustandsmatrix gebunden.');
            }
            foreach(array('positive_test','negative_test') as $field){
                $tp=(string)($rule[$field]??'');
                if($tp===''||(strpos($tp,'EXTERNAL:')!==0&&!is_file(PPM679_PLUGIN_DIR.$tp))){
                    $errors[]=self::err('BLOCKED_HARD_RULE_TEST_PATH','EVERY_DECLARED_TEST_MUST_EXIST_OR_BE_EXPLICIT_EXTERNAL_GATE','hard_rules.'.$id.'.'.$field,'existing test or EXTERNAL gate',$tp,'Die deklarierte Regelprüfung ist nicht auffindbar.');
                }
            }
        }
        foreach($rows as $id=>$row){if($id===''||!isset($active_ids[$id])){$errors[]=self::err('BLOCKED_HARD_RULE_STALE_ROW','EVERY_MATRIX_ROW_MUST_MATCH_AN_ACTIVE_RULE','hard_rules.matrix.'.$id,'active rule id',$row,'Die Matrix enthält eine veraltete oder unbekannte Regelzeile.');}}

        $count_fields=array('unknown_count','unmapped_count','untested_count','SYSTEM_UNMAPPED','WRITE_PATH_UNMAPPED','STATEFUL_FIELD_UNMAPPED','UNIQUE_IDENTIFIER_UNMAPPED','TRANSITION_UNTESTED','PERSISTENT_SCENARIO_UNTESTED','LIVE_PREFLIGHT_UNBOUND','IDENTITY_SCOPE_AMBIGUOUS');
        foreach($count_fields as $field){if((int)($m[$field]??-1)!==0){$errors[]=self::err('BLOCKED_HARD_RULE_COVERAGE_COUNTS','ALL_REGISTRY_AND_SYSTEM_DERIVED_BLOCKING_COUNTS_MUST_BE_ZERO','hard_rules.counts.'.$field,0,$m[$field]??null,'Ein Gesamt-PASS ist bei einer ungeprüften Regel oder Systemlücke verboten.');}}

        $inventory=array();foreach((array)($r['active_contract_inventory']??array()) as $x){$inventory[(string)($x['path']??'')]=$x;}
        foreach($inventory as $rel=>$x){$p=PPM679_PLUGIN_DIR.$rel;$actual=is_file($p)?hash_file('sha256',$p):'';if($actual===''||!hash_equals((string)($x['sha256']??''),$actual)){$errors[]=self::err('BLOCKED_HARD_RULE_CONTRACT_INVENTORY','ACTIVE_CONTRACT_HASH_MUST_MATCH_REGISTRY','hard_rules.contract_inventory.'.$rel,$x['sha256']??null,$actual,'Ein aktiver Vertrag ist nicht exakt inventarisiert.');}}
        foreach(array(self::SYSTEM_INVENTORY,self::TRANSITION_MATRIX,'contracts/stateful-e2e-write-gate-v3-1.json','contracts/qf03-wordpress-draft-readback-dom-v1.json') as $required){if(!isset($inventory[$required])){$errors[]=self::err('BLOCKED_V31_ACTIVE_CONTRACT_MISSING','V31_ACTIVE_CONTRACTS_MUST_BE_IN_REGISTRY_INVENTORY','hard_rules.contract_inventory.'.$required,'inventoried',null,'Ein aktiver V3.1-Vertrag fehlt im Regelregister.');}}

        $errors=array_merge($errors,PPM679_System_Inventory_Validator::validate(),PPM679_State_Transition_Validator::validate(),PPM679_Category_Assignment_Validator::governance_errors());
        return $errors;
    }
}
