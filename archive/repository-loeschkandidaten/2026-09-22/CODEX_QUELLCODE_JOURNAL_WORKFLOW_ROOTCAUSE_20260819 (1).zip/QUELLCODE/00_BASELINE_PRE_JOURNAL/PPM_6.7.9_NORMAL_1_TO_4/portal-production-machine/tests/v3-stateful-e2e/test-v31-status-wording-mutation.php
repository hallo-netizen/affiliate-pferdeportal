<?php
require_once __DIR__.'/fixture-builder.php';
$bad='Vollständigkeit bewiesen';
$forbidden=array('Vollständigkeit bewiesen','alle denkbaren Lücken ausgeschlossen','mathematisch vollständige Systemabdeckung');
$blocked=false;foreach($forbidden as $f){if(stripos($bad,$f)!==false){$blocked=true;}}
ppm_test_assert($blocked,'absolute completeness claim must block');
echo json_encode(array('status'=>'PASS_V31_STATUS_WORDING_NEGATIVE','simulated_blocker'=>'BLOCKED_V31_ABSOLUTE_COMPLETENESS_CLAIM'),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
