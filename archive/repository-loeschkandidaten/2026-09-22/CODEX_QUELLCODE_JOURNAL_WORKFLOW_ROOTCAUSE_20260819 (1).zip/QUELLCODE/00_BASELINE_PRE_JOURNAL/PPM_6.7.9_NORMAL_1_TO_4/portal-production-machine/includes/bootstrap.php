<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Plugin {
    const VERSION='6.7.9';

    public static function init() {
        PPM679_Admin::init();
        PPM679_Editorial_Plan_Admin::init();
        PPM679_G9_Single_FAQ_Entrypoint::init();
        PPM679_Three_Type_Bundled_Live_Test_Entrypoint::init();
    }
}
