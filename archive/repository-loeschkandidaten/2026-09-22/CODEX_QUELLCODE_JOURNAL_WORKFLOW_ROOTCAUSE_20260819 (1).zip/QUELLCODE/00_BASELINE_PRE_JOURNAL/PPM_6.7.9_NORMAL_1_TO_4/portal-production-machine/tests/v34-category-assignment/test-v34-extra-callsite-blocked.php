<?php
require_once __DIR__.'/fixture-builder.php';
$sources=array(
 'includes/category-assignment-validator.php'=>'PPM679_Independent_Semantic_Category_Deriver::derive(',
 'includes/rogue.php'=>'PPM679_Independent_Semantic_Category_Deriver::derive('
);
$i=PPM679_Category_Structure_Inspector::inspect(null,$sources,null);
ppm_test_assert(!empty($i['errors']),'extra callsite must block');
echo "PASS_V34_EXTRA_CALLSITE_BLOCKED\n";
