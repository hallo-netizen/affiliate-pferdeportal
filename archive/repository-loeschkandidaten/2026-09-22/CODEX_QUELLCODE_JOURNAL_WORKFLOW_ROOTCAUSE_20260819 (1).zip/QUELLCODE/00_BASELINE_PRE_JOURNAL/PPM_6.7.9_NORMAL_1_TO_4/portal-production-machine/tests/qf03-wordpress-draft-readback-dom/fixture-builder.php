<?php
function qf03_gate_fixture($content_hash=null) {
    if ($content_hash===null) { $content_hash=hash('sha256',qf03_article_html()); }
    return array(
        'TECHNICAL_STATUS'=>'PASS','FACT_AND_HASH_STATUS'=>'PASS','EDITORIAL_MACHINE_STATUS'=>'PASS','KNOWN_ERROR_GATE_V1'=>'PASS',
        'GENERAL_TEMPLATE_REPETITION_STATUS'=>'PASS','GOLD_CORE_NUMERIC_GATE'=>'PASS','EDITORIAL_REVIEW_STATUS'=>'PASS','GOLD_CORE_REVIEW_GATE'=>'PASS','CONTROL_BASELINE_STATUS'=>'PASS','SERVER_CHECK_STATUS'=>'PASS',
        'FINAL_CONTENT_HASH'=>$content_hash,'EDITORIALLY_REVIEWED_CONTENT_HASH'=>$content_hash,
        'CURRENT_GOLD_REFERENCE_HASH'=>str_repeat('a',64),'REVIEW_GOLD_REFERENCE_HASH'=>str_repeat('a',64),
        'user_triggered'=>true,'nonce_verified'=>true,'current_user_can_manage'=>true,'article_count'=>1,'article_type'=>'faq','publish_allowed'=>false,'evidence_class'=>'SERVER_USER_TRIGGERED_TEST',
        'manual_override'=>false,'time_pressure_exception'=>false,'progress_exception'=>false,'server_instance_id'=>'ppm-test-instance-679','request_id'=>'qf03-request-001','triggered_by_user_id'=>1
    );
}
function qf03_article_html() {
    return '<p>Vor der Fahrt müssen Gewichte, Kupplung und Sicherung geprüft werden.</p><h2>Gewichte und Fahrzeuggrenzen prüfen</h2><p>Vergleichen Sie die zulässigen Werte.</p><ul><li>Anhängelast</li><li>Stützlast</li><li>Gesamtgewicht</li><li>Reifendruck</li></ul><h2>Technik vor der Abfahrt prüfen</h2><p>Kontrollieren Sie Beleuchtung und Verriegelungen.</p>';
}
function qf03_candidate_fixture() {
    return array('article_type'=>'faq','title'=>'Was muss vor einer Fahrt geprüft werden?','content_html'=>qf03_article_html(),'slug'=>'fahrt-pruefen','internal_test_marker'=>'QF03-LOCAL-001','category_id'=>42,'category_slug'=>'pferdetransport','run_id'=>'qf03-local-run');
}
function qf03_rendered_html() {
    return '<!doctype html><html><body><main><article><h1>Was muss vor einer Fahrt geprüft werden?</h1>'.qf03_article_html().'</article></main></body></html>';
}
function qf03_capture_fixture($kind,$post_id,$content_hash) {
    $html=qf03_rendered_html();
    return array('html'=>$html,'html_sha256'=>hash('sha256',$html),'post_id'=>$post_id,'stored_content_hash'=>$content_hash,'capture_url'=>'https://example.test/?p='.$post_id,'captured_at'=>'2026-07-27T12:00:00Z','server_instance_id'=>'ppm-test-instance-679','request_id'=>'qf03-request-001','artifact_id'=>'qf03-dom-'.($kind==='desktop'?'desktop':'mobile').'-001','evidence_class'=>'SERVER_USER_TRIGGERED_TEST','capture_source'=>'HTTP_RESPONSE_AFTER_WORDPRESS_RENDER','user_agent'=>$kind==='desktop'?'Mozilla/5.0 Desktop':'Mozilla/5.0 Mobile','viewport'=>$kind==='desktop'?array('width'=>1440,'height'=>1000):array('width'=>390,'height'=>844));
}
