<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Category_Hierarchy_Validator {
    const VERSION='6.7.9';
    const CONTRACT_FILE='contracts/category-hierarchy-snapshot-v1.json';
    const CONTRACT='PPM679_CATEGORY_HIERARCHY_SNAPSHOT_V1';

    private static function err($code,$rule,$path,$expected,$actual,$reason){
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'category_hierarchy_snapshot','',__CLASS__,null,array(self::CONTRACT_FILE));
    }
    public static function load($override=null){
        if($override!==null){return is_array($override)?$override:null;}
        $p=PPM679_PLUGIN_DIR.self::CONTRACT_FILE;
        $d=is_file($p)?json_decode((string)file_get_contents($p),true):null;
        return is_array($d)?$d:null;
    }
    public static function validate($snapshot){
        $snapshot=is_array($snapshot)?$snapshot:array();$errors=array();
        if(($snapshot['contract']??'')!==self::CONTRACT){$errors[]=self::err('BLOCKED_CATEGORY_SOURCE_UNBOUND','CATEGORY_SOURCE_CONTRACT_MUST_MATCH','category_source.contract',self::CONTRACT,$snapshot['contract']??null,'Die Kategorienquelle ist nicht an den freigegebenen Vertrag gebunden.');}
        $self=(string)($snapshot['contract_self_sha256']??'');$copy=$snapshot;unset($copy['contract_self_sha256']);$actual=PPM679_Diagnostic::stable_hash($copy);
        if($self===''||!hash_equals($self,$actual)){$errors[]=self::err('BLOCKED_CATEGORY_SOURCE_HASH','CATEGORY_SOURCE_SELF_HASH_MUST_MATCH','category_source.contract_self_sha256',$actual,$self,'Die Kategorienquelle wurde verändert.');}
        $snap=(string)($snapshot['snapshot_sha256']??'');$snapcopy=$snapshot;unset($snapcopy['snapshot_sha256'],$snapcopy['contract_self_sha256']);$snapactual=PPM679_Diagnostic::stable_hash($snapcopy);
        if($snap===''||!hash_equals($snap,$snapactual)){$errors[]=self::err('BLOCKED_CATEGORY_SNAPSHOT_STALE','CATEGORY_SNAPSHOT_HASH_MUST_MATCH_CONTENT','category_source.snapshot_sha256',$snapactual,$snap,'Der Kategorien-Snapshot ist nicht bytegenau gebunden.');}
        if(trim((string)($snapshot['portal_id']??''))===''||trim((string)($snapshot['taxonomy']??''))===''||trim((string)($snapshot['generated_at']??''))===''){$errors[]=self::err('BLOCKED_CATEGORY_SOURCE_INCOMPLETE','CATEGORY_SOURCE_REQUIRES_PORTAL_TAXONOMY_AND_TIME','category_source.identity','complete',array('portal_id'=>$snapshot['portal_id']??null,'taxonomy'=>$snapshot['taxonomy']??null,'generated_at'=>$snapshot['generated_at']??null),'Portal-, Taxonomie- oder Zeitbindung fehlt.');}
        $seen=array();$assignable=0;
        foreach((array)($snapshot['categories']??array()) as $i=>$c){
            if(!is_array($c)){$errors[]=self::err('BLOCKED_CATEGORY_SOURCE_INCOMPLETE','EVERY_CATEGORY_MUST_BE_OBJECT','category_source.categories['.$i.']','object',$c,'Ein Kategorieeintrag ist ungültig.');continue;}
            foreach(array('semantic_key','name','slug','taxonomy','hierarchy_path','level','assignable','allowed_article_types') as $f){$missing=!array_key_exists($f,$c)||$c[$f]==='';if($f==='allowed_article_types'&&($c['assignable']??false)!==true){$missing=!array_key_exists($f,$c)||!is_array($c[$f]);}elseif($f==='allowed_article_types'){$missing=$missing||$c[$f]===array();}if($missing){$errors[]=self::err('BLOCKED_CATEGORY_SOURCE_INCOMPLETE','EVERY_CATEGORY_REQUIRES_ALL_BINDING_FIELDS','category_source.categories['.$i.'].'.$f,'present',$c[$f]??null,'Ein Kategorie-Pflichtfeld fehlt.');}}
            $key=(string)($c['taxonomy']??'').'|'.(string)($c['slug']??'');if(isset($seen[$key])){$errors[]=self::err('BLOCKED_CATEGORY_LIVE_RESOLUTION_AMBIGUOUS','CATEGORY_SLUG_MUST_BE_UNIQUE_WITHIN_TAXONOMY','category_source.categories['.$i.'].slug','unique',$key,'Der Kategorien-Snapshot enthält einen mehrdeutigen Slug.');}$seen[$key]=true;
            if(($c['assignable']??false)===true){$assignable++;}
        }
        if($assignable<1){$errors[]=self::err('BLOCKED_CATEGORY_SOURCE_INCOMPLETE','CATEGORY_SOURCE_REQUIRES_ASSIGNABLE_TARGETS','category_source.categories','at least one assignable category',$assignable,'Die Kategorienquelle enthält kein zulässiges Beitragsziel.');}
        if(($snapshot['absolute_completeness_claimed']??null)!==false){$errors[]=self::err('BLOCKED_CATEGORY_ABSOLUTE_COMPLETENESS_CLAIM','CATEGORY_SOURCE_MUST_NOT_CLAIM_ABSOLUTE_COMPLETENESS','category_source.absolute_completeness_claimed',false,$snapshot['absolute_completeness_claimed']??null,'Absolute Vollständigkeit darf nicht behauptet werden.');}
        return $errors;
    }
    public static function semantic_view($snapshot){
        $snapshot=is_array($snapshot)?$snapshot:array();$categories=array();
        foreach((array)($snapshot['categories']??array()) as $entry){
            if(!is_array($entry)){continue;}$categories[]=array(
                'semantic_key'=>(string)($entry['semantic_key']??''),
                'name'=>(string)($entry['name']??''),
                'slug'=>(string)($entry['slug']??''),
                'taxonomy'=>(string)($entry['taxonomy']??''),
                'hierarchy_path'=>(string)($entry['hierarchy_path']??''),
                'level'=>(int)($entry['level']??0),
                'assignable'=>($entry['assignable']??false)===true,
                'allowed_article_types'=>array_values((array)($entry['allowed_article_types']??array())),
                'semantic_keywords'=>array_values((array)($entry['semantic_keywords']??array()))
            );
        }
        return array(
            'contract'=>(string)($snapshot['contract']??''),'version'=>(string)($snapshot['version']??''),
            'portal_id'=>(string)($snapshot['portal_id']??''),'taxonomy'=>(string)($snapshot['taxonomy']??''),
            'generated_at'=>(string)($snapshot['generated_at']??''),'source_type'=>(string)($snapshot['source_type']??''),
            'source_reference'=>(string)($snapshot['source_reference']??''),'target_assignable_level'=>(int)($snapshot['target_assignable_level']??0),
            'required_fields'=>array_values((array)($snapshot['required_fields']??array())),'categories'=>$categories,
            'snapshot_sha256'=>(string)($snapshot['snapshot_sha256']??''),'contract_self_sha256'=>(string)($snapshot['contract_self_sha256']??'')
        );
    }
    public static function find_by_slug($snapshot,$slug,$taxonomy='category'){
        $out=array();foreach((array)($snapshot['categories']??array()) as $c){if((string)($c['slug']??'')===(string)$slug&&(string)($c['taxonomy']??'')===(string)$taxonomy){$out[]=$c;}}return $out;
    }
}
