<?php
require __DIR__.'/bootstrap-three-type.php';
$scope=ppm_three_scope();$errors=PPM679_Three_Type_Bundled_Release_Validator::validate(PPM679_Three_Type_Bundled_Release_Validator::ACTION_CONTEXT,$scope);ppm_test_assert($errors===[],'signed scope passes');
$c=PPM679_Three_Type_Bundled_Release_Validator::load(PPM679_Three_Type_Bundled_Release_Validator::CONTRACT_FILE);
foreach(['wordpress_access_allowed','draft_allowed','installation_allowed','publish_allowed','wissen_allowed'] as $field){ppm_test_assert(($c[$field]??null)===false,$field.' remains false');}
ppm_test_assert(($c['signing_performed']??null)===true,'signing must be claimed only by signed build');
$global=PPM679_Article_Type_Validator::load_contract();foreach(['FAQ','Beratung','Vergleich','Pflege'] as $type){ppm_test_assert(($global['types'][$type]['production_allowed']??null)===false,$type.' remains globally quarantined');}
ppm_test_assert(count(PPM679_WP::test_posts())===0,'no WordPress objects');
echo json_encode(['status'=>'PASS_THREE_TYPE_SIGNED_QUARANTINE_BOUNDARIES','global_quarantined_types'=>4,'publish_allowed'=>false,'drafts_created'=>0,'wissen_allowed'=>false],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
