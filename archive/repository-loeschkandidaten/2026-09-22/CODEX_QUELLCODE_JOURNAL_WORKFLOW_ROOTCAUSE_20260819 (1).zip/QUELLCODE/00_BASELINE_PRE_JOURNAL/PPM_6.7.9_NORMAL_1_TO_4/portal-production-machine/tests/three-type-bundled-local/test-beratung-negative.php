<?php
require __DIR__.'/bootstrap-three-type.php';
[$item,$pack,$g]=ppm_three_generated('Beratung');ppm_test_assert(!empty($g['ok']),'valid Beratung generation');
$g['content_html']=preg_replace('/data-block="criteria"/','data-block="criteria-mutated"',$g['content_html'],1);$g['content_hash']=hash('sha256',$g['content_html']);
$r=PPM679_Three_Type_Bundled_Local_Preflight::validate_generated_mutation($g,$item,$pack,'beratung_required_criteria');$codes=ppm_three_codes($r['errors']);
ppm_test_assert(empty($r['ok']),'mutated Beratung must block');ppm_test_assert(in_array('BLOCKED_CONTENT_REQUIRED_BLOCK_MISSING',$codes,true),'Beratung missing criteria code');
echo json_encode(['status'=>'PASS_BERATUNG_NEGATIVE_MUTATION_BLOCKED','expected_code'=>'BLOCKED_CONTENT_REQUIRED_BLOCK_MISSING','codes'=>$codes],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
