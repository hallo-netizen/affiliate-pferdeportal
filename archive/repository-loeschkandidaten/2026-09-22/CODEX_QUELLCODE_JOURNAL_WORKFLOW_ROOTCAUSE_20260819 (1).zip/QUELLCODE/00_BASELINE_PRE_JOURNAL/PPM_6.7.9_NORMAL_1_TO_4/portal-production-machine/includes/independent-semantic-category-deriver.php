<?php
if (!defined('ABSPATH')) { return; }

/**
 * Structurally isolated semantic category derivation.
 *
 * This class deliberately has no dependency on the editorial plan, WordPress,
 * write payloads, readback data, a service container, request state or caches.
 */
final class PPM679_Independent_Semantic_Category_Deriver {
    const VERSION='6.7.9';

    private static $allowed_input_fields=array(
        'title','topic','search_intent','article_type','outline','keywords',
        'target_level','portal_id','taxonomy'
    );
    private static $allowed_snapshot_fields=array(
        'contract','version','portal_id','taxonomy','generated_at','source_type',
        'source_reference','target_assignable_level','required_fields','categories',
        'snapshot_sha256','contract_self_sha256'
    );
    private static $allowed_category_fields=array(
        'semantic_key','name','slug','taxonomy','hierarchy_path','level',
        'assignable','allowed_article_types','semantic_keywords'
    );

    public static function derive($semantic_article_input,$category_hierarchy_snapshot) {
        $input=is_array($semantic_article_input)?$semantic_article_input:array();
        $snapshot=is_array($category_hierarchy_snapshot)?$category_hierarchy_snapshot:array();
        $violations=self::inputViolations($input,$snapshot);
        if($violations){
            return array(
                'contract'=>'INDEPENDENT_SEMANTIC_CATEGORY_DECISION_V1',
                'status'=>'BLOCKED_INPUT_CONTAMINATED',
                'violations'=>$violations,
                'absolute_completeness_claimed'=>false
            );
        }

        $article_type=strtoupper(trim((string)($input['article_type']??'')));
        $text=implode(' ',array(
            (string)($input['title']??''),(string)($input['topic']??''),(string)($input['search_intent']??''),
            (string)($input['outline']??''),implode(' ',(array)($input['keywords']??array()))
        ));
        $tokens=self::tokens($text);$ranked=array();
        foreach((array)($snapshot['categories']??array()) as $entry){
            if(!is_array($entry)||($entry['assignable']??false)!==true){continue;}
            if((int)($entry['level']??0)!==(int)($input['target_level']??0)){continue;}
            if((string)($entry['taxonomy']??'')!==(string)($input['taxonomy']??'')){continue;}
            $types=array_map('strtoupper',(array)($entry['allowed_article_types']??array()));
            if($article_type===''||!in_array($article_type,$types,true)){continue;}
            $category_text=(string)($entry['name']??'').' '.(string)($entry['slug']??'').' '.(string)($entry['hierarchy_path']??'').' '.implode(' ',(array)($entry['semantic_keywords']??array()));
            $category_tokens=self::tokens($category_text);
            $overlap=array_values(array_intersect(array_keys($tokens),array_keys($category_tokens)));
            $score=40+(count($overlap)*8);
            $reasons=array('article_type_match','taxonomy_match','target_level_match');
            foreach($overlap as $word){$score+=min(6,$tokens[$word]+$category_tokens[$word]);$reasons[]='token:'.$word;}
            foreach((array)($entry['semantic_keywords']??array()) as $phrase){$n=self::normal((string)$phrase);if($n!==''&&strpos(self::normal($text),$n)!==false){$score+=18;$reasons[]='phrase:'.$n;}}
            $slug=(string)($entry['slug']??'');
            if(preg_match('/(^|-)2er(-|$)/',$slug)&&!isset($tokens['2er'])&&!isset($tokens['zwei'])){$score-=35;$reasons[]='penalty:unsupported_2er_scope';}
            if(strpos($slug,'zugfahrzeug')!==false&&!isset($tokens['zugfahrzeug'])){$score-=18;$reasons[]='penalty:secondary_subject_only';}
            $ranked[]=array(
                'semantic_key'=>(string)($entry['semantic_key']??''),
                'name'=>(string)($entry['name']??''),
                'slug'=>$slug,
                'taxonomy'=>(string)($entry['taxonomy']??''),
                'hierarchy_path'=>(string)($entry['hierarchy_path']??''),
                'level'=>(int)($entry['level']??0),
                'score'=>$score,
                'reasons'=>array_values(array_unique($reasons))
            );
        }
        usort($ranked,function($a,$b){if($a['score']===$b['score']){return strcmp($a['slug'],$b['slug']);}return $a['score']>$b['score']?-1:1;});
        $best=$ranked[0]??null;$second=$ranked[1]??null;$margin=is_array($best)?(int)$best['score']-(int)($second['score']??0):0;
        $status=!is_array($best)?'UNRESOLVED':($margin<12?'AMBIGUOUS':'RESOLVED');
        $decision=array(
            'contract'=>'INDEPENDENT_SEMANTIC_CATEGORY_DECISION_V1',
            'status'=>$status,
            'input_sha256'=>self::stableHash($input),
            'snapshot_sha256'=>(string)($snapshot['snapshot_sha256']??''),
            'best'=>$best,
            'second_best'=>$second,
            'score_margin'=>$margin,
            'ranked_candidates'=>$ranked,
            'absolute_completeness_claimed'=>false
        );
        $decision['decision_sha256']=self::stableHash($decision);
        return $decision;
    }

    private static function inputViolations($input,$snapshot){
        $violations=array();
        foreach(array_keys($input) as $field){if(!in_array((string)$field,self::$allowed_input_fields,true)){$violations[]='semantic_article_input.'.$field;}}
        foreach(array_keys($snapshot) as $field){if(!in_array((string)$field,self::$allowed_snapshot_fields,true)){$violations[]='category_hierarchy_snapshot.'.$field;}}
        foreach((array)($snapshot['categories']??array()) as $index=>$category){
            if(!is_array($category)){$violations[]='category_hierarchy_snapshot.categories['.$index.']';continue;}
            foreach(array_keys($category) as $field){if(!in_array((string)$field,self::$allowed_category_fields,true)){$violations[]='category_hierarchy_snapshot.categories['.$index.'].'.$field;}}
        }
        sort($violations,SORT_STRING);return array_values(array_unique($violations));
    }
    private static function stableHash($value){return hash('sha256',json_encode(self::canonical($value),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION));}
    private static function canonical($value){
        if(!is_array($value)){return $value;}
        $keys=array_keys($value);$is_list=$keys===range(0,count($keys)-1);if($is_list){return array_map(array(__CLASS__,'canonical'),$value);}
        ksort($value,SORT_STRING);foreach($value as $key=>$item){$value[$key]=self::canonical($item);}return $value;
    }
    private static function normal($value){
        $v=strtolower((string)$value);$v=strtr($v,array('ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss','prüf'=>'pruef','kontrollieren'=>'kontrolle','kontrolliert'=>'kontrolle','geprüft'=>'pruef','prüfung'=>'pruef','checklisten'=>'checkliste','anhänger'=>'anhaenger'));
        $v=preg_replace('/[^a-z0-9]+/',' ',$v);return trim(preg_replace('/\s+/',' ',$v));
    }
    private static function tokens($value){
        $out=array();foreach(explode(' ',self::normal($value)) as $w){if(strlen($w)<3){continue;}foreach(array('pferdeanhaenger'=>'anhaenger','pferdeanhangern'=>'anhaenger','abfahrt'=>'fahrt','sicherheitspruefung'=>'pruef') as $from=>$to){if($w===$from){$out[$to]=($out[$to]??0)+1;}}$out[$w]=($out[$w]??0)+1;}return $out;
    }
}
