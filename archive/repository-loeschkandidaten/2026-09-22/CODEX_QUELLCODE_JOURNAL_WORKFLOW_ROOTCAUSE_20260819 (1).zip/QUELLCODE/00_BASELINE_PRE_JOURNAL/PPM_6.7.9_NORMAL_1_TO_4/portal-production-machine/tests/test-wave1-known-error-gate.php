<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

function wave1_fixture($name) {
    $base=__DIR__.'/fixtures/wave1/';
    $meta=json_decode((string)file_get_contents($base.$name.'.json'),true);
    ppm_test_assert(is_array($meta),$name.' metadata must decode');
    $html=(string)file_get_contents($base.$name.'.html');
    ppm_test_assert(hash('sha256',$html)===$meta['body_html_sha256'],$name.' hash must match');
    return array($meta,$html);
}
function wave1_codes($result) {
    $codes=array();
    foreach (($result['errors']??array()) as $error) {
        $code=(string)($error['error_code']??'');
        if ($code!==''&&!in_array($code,$codes,true)) { $codes[]=$code; }
    }
    sort($codes);
    return $codes;
}

$contract=json_decode((string)file_get_contents(dirname(__DIR__).'/contracts/known-error-gate-v1.json'),true);
ppm_test_assert(is_array($contract),'Known error contract must decode');
$negative_results=array();
foreach (array('faq'=>'FAQ','beratung'=>'Beratung','vergleich'=>'Vergleich','pflege'=>'Pflege') as $slug=>$type) {
    list($meta,$html)=wave1_fixture('known-bad-'.$slug);
    $result=PPM679_Known_Error_Gate::evaluate(
        array('title'=>$meta['title'],'article_type'=>$type,'content_html'=>$html,'content_hash'=>hash('sha256',$html)),
        array('article_type'=>$type),
        'wave1_known_bad_'.$slug,
        'local-state-hash'
    );
    ppm_test_assert(empty($result['ok']),$type.' known-bad fixture must block');
    ppm_test_assert(($result['known_error_gate_status']??'')==='BLOCKED',$type.' gate status must be BLOCKED');
    $codes=wave1_codes($result);
    foreach ($contract['required_error_codes_for_original_four'][$type] as $required) {
        ppm_test_assert(in_array($required,$codes,true),$type.' must report '.$required);
    }
    $negative_results[$type]=array(
        'status'=>$result['known_error_gate_status'],
        'content_hash'=>hash('sha256',$html),
        'error_codes'=>$codes,
        'checks'=>$result['checks']
    );
}

list($positive_meta,$positive_html)=wave1_fixture('positive-control-structural-faq');
$positive=PPM679_Known_Error_Gate::evaluate(
    array('title'=>$positive_meta['title'],'article_type'=>'FAQ','content_html'=>$positive_html,'content_hash'=>hash('sha256',$positive_html)),
    array('article_type'=>'FAQ'),
    'wave1_positive_control_faq',
    'local-state-hash'
);
if (empty($positive['ok'])) { fwrite(STDERR,json_encode($positive,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n"); }
ppm_test_assert(!empty($positive['ok']),'Structural FAQ positive control must not be falsely blocked');
ppm_test_assert(($positive['known_error_gate_status']??'')==='PASS','Positive control gate status must PASS');

$report=array(
    'contract'=>'wave1_known_error_gate_test_report_v1',
    'status'=>'PASS',
    'known_bad_originals'=>$negative_results,
    'positive_control'=>array(
        'status'=>$positive['known_error_gate_status'],
        'content_hash'=>hash('sha256',$positive_html),
        'checks'=>$positive['checks']
    ),
    'known_error_gate_contract_hash'=>hash_file('sha256',dirname(__DIR__).'/contracts/known-error-gate-v1.json'),
    'known_error_gate_code_hash'=>hash_file('sha256',dirname(__DIR__).'/includes/known-error-gate.php')
);
echo json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
