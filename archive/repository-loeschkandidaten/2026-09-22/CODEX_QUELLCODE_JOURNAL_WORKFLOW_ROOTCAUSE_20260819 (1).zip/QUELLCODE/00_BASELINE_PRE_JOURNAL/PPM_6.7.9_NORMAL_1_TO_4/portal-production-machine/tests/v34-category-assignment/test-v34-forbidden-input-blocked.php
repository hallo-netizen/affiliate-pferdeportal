<?php
require_once __DIR__.'/fixture-builder.php';
$s=v34_semantic();$s['plan_category']='Pflege High-Neck-Decken';
$r=PPM679_Category_Assignment_Validator::derive_independent($s,v34_snapshot());
ppm_test_assert(empty($r['ok']),'forbidden semantic input must block');
ppm_test_assert(strpos((string)($r['report']['status']??''),'BLOCKED_CATEGORY_SEMANTIC_INTERFACE_CONTAMINATED')===0,'exact contamination diagnosis');
echo "PASS_V34_FORBIDDEN_INPUT_BLOCKED\n";
