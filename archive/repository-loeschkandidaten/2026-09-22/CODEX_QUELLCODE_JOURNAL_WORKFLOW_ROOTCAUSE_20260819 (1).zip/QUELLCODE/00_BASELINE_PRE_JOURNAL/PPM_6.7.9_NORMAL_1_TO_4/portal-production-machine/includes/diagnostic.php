<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Diagnostic {
    const VERSION = '6.7.9';
    const REQUIRED_FIELDS = array(
        'error_code','failed_rule','validator_id','validator_version','field_path',
        'expected','actual','reason','severity','item_index','evidence_refs',
        'evidence_hash','detected_at','server_state_hash','action_context'
    );

    public static function canonicalize($value) {
        if (!is_array($value)) { return $value; }
        if (self::is_list($value)) {
            $out = array();
            foreach ($value as $item) { $out[] = self::canonicalize($item); }
            return $out;
        }
        ksort($value, SORT_STRING);
        foreach ($value as $key => $item) { $value[$key] = self::canonicalize($item); }
        return $value;
    }

    private static function is_list($value) {
        if (function_exists('array_is_list')) { return array_is_list($value); }
        $index = 0;
        foreach ($value as $key => $unused) {
            if ($key !== $index++) { return false; }
        }
        return true;
    }

    public static function encode($value, $pretty = false) {
        $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
        if ($pretty) { $flags |= JSON_PRETTY_PRINT; }
        $value = self::canonicalize($value);
        if (function_exists('wp_json_encode')) { return wp_json_encode($value, $flags); }
        return json_encode($value, $flags);
    }

    public static function stable_hash($value) {
        return hash('sha256', (string) self::encode($value, false));
    }

    public static function error($code, $rule, $path, $expected, $actual, $reason, $context, $server_state_hash = '', $validator = 'PPM679_Diagnostic', $item_index = null, $refs = array(), $severity = 'BLOCKING') {
        $error = array(
            'error_code' => (string) $code,
            'failed_rule' => (string) $rule,
            'validator_id' => (string) $validator,
            'validator_version' => self::VERSION,
            'field_path' => (string) $path,
            'expected' => $expected,
            'actual' => $actual,
            'reason' => (string) $reason,
            'severity' => (string) $severity,
            'item_index' => $item_index,
            'evidence_refs' => array_values((array) $refs),
            'detected_at' => gmdate('c'),
            'server_state_hash' => (string) $server_state_hash,
            'action_context' => (string) $context,
        );
        $hash_input = $error;
        $error['evidence_hash'] = self::stable_hash($hash_input);
        return $error;
    }

    public static function complete_error($error) {
        if (!is_array($error)) { return false; }
        foreach (self::REQUIRED_FIELDS as $field) {
            if (!array_key_exists($field, $error)) { return false; }
        }
        return true;
    }

    public static function blocked($code, $errors, $context, $server_state_hash = '', $extra = array()) {
        $errors = array_values((array) $errors);
        $complete = true;
        foreach ($errors as $error) {
            if (!self::complete_error($error)) { $complete = false; break; }
        }
        if (!$complete) {
            $errors[] = self::error(
                'BLOCKED_DIAGNOSTIC_EVIDENCE_INCOMPLETE',
                'EVERY_BLOCKER_MUST_IMPLEMENT_DIAGNOSTIC_CONTRACT_V3',
                'errors',
                self::REQUIRED_FIELDS,
                $errors,
                'Mindestens ein Blocker enthält nicht alle vorgeschriebenen Ursachenfelder.',
                $context,
                $server_state_hash,
                __CLASS__,
                null,
                array('contracts/diagnostic-contract-v3.json')
            );
            $code = 'BLOCKED_DIAGNOSTIC_EVIDENCE_INCOMPLETE';
        }
        $report = array_merge(array(
            'contract' => 'ppm_action_report_v1',
            'version' => self::VERSION,
            'status' => (string) $code,
            'action_context' => (string) $context,
            'server_state_hash' => (string) $server_state_hash,
            'errors' => $errors,
            'production_allowed' => false,
            'publish_allowed' => false,
            'generated_at' => gmdate('c'),
        ), is_array($extra) ? $extra : array());
        $report['report_hash'] = self::stable_hash($report);
        return $report;
    }

    public static function ok($status, $context, $server_state_hash, $extra = array()) {
        $report = array_merge(array(
            'contract' => 'ppm_action_report_v1',
            'version' => self::VERSION,
            'status' => (string) $status,
            'action_context' => (string) $context,
            'server_state_hash' => (string) $server_state_hash,
            'errors' => array(),
            'publish_allowed' => false,
            'generated_at' => gmdate('c'),
        ), is_array($extra) ? $extra : array());
        $report['report_hash'] = self::stable_hash($report);
        return $report;
    }
}
