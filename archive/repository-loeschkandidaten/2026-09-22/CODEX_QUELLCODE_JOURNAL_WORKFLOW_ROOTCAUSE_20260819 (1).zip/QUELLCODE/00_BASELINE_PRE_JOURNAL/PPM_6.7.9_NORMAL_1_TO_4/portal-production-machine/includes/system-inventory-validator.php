<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_System_Inventory_Validator {
    const VERSION='6.7.9';
    const CONTRACT_FILE='contracts/system-inventory-v3-1.json';
    const REGISTRY_FILE='contracts/hard-rule-registry-v1.json';
    const TRANSITION_FILE='contracts/state-transition-matrix-v3-1.json';

    private static function err($code,$rule,$path,$expected,$actual,$reason){
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'v31_system_inventory','',__CLASS__,null,array(self::CONTRACT_FILE,self::REGISTRY_FILE,self::TRANSITION_FILE));
    }
    private static function load_json($rel){
        $p=PPM679_PLUGIN_DIR.$rel;
        $d=is_file($p)?json_decode((string)file_get_contents($p),true):null;
        return is_array($d)?$d:null;
    }
    private static function load(){ return self::load_json(self::CONTRACT_FILE); }

    public static function discover(){
        $c=self::load();$findings=array();
        if(!is_array($c)){return $findings;}
        foreach((array)($c['scan_paths']??array()) as $rel){
            $rel=(string)$rel;$p=PPM679_PLUGIN_DIR.$rel;
            if(!is_file($p)){continue;}
            $lines=preg_split('/\R/u',(string)file_get_contents($p));
            foreach($lines as $index=>$line){
                foreach((array)($c['discovery_patterns']??array()) as $pat){
                    $regex=(string)($pat['regex']??'');if($regex===''){continue;}
                    $m=array();$ok=@preg_match_all($regex,(string)$line,$m);
                    if(!$ok){continue;}
                    foreach((array)($m[0]??array()) as $match){
                        $kind=(string)($pat['kind']??'UNKNOWN');
                        $symbol=(string)($pat['symbol']??$match);
                        $line_no=$index+1;
                        $id='SYS::'.substr(hash('sha256',$kind.'|'.$rel.'|'.$line_no.'|'.$symbol.'|'.$match),0,20);
                        $findings[$id]=array(
                            'inventory_id'=>$id,'kind'=>$kind,'source_path'=>$rel,'line'=>$line_no,
                            'symbol'=>$symbol,'match'=>(string)$match,
                            'source_line_sha256'=>hash('sha256',(string)$line)
                        );
                    }
                }
            }
        }
        ksort($findings,SORT_STRING);
        return array_values($findings);
    }

    public static function validate(){
        $c=self::load();$errors=array();
        if(!is_array($c)){return array(self::err('BLOCKED_V31_SYSTEM_INVENTORY_MISSING','SYSTEM_DERIVED_INVENTORY_MUST_EXIST','system_inventory',self::CONTRACT_FILE,null,'Die systemabgeleitete Inventur fehlt.'));}

        $self=(string)($c['contract_self_sha256']??'');$copy=$c;unset($copy['contract_self_sha256']);
        $actual_hash=PPM679_Diagnostic::stable_hash($copy);
        if($self===''||!hash_equals($self,$actual_hash)){$errors[]=self::err('BLOCKED_V31_SYSTEM_INVENTORY_HASH','SYSTEM_INVENTORY_SELF_HASH_MUST_MATCH','system_inventory.contract_self_sha256',$actual_hash,$self,'Die Systeminventur wurde verändert.');}

        $declared_scan=array();foreach((array)($c['scan_path_hashes']??array()) as $x){$declared_scan[(string)($x['path']??'')]=(string)($x['sha256']??'');}
        $actual_scan=array();
        foreach((array)($c['scan_paths']??array()) as $rel){
            $rel=(string)$rel;$p=PPM679_PLUGIN_DIR.$rel;
            if(!is_file($p)){$errors[]=self::err('BLOCKED_V31_SCAN_PATH_MISSING','EVERY_DECLARED_SCAN_PATH_MUST_EXIST','system_inventory.scan_paths.'.$rel,'existing file',null,'Ein deklarierter Quellpfad fehlt.');continue;}
            $actual_scan[]=array('path'=>$rel,'sha256'=>hash_file('sha256',$p));
            if(!isset($declared_scan[$rel])||!hash_equals($declared_scan[$rel],hash_file('sha256',$p))){
                $errors[]=self::err('BLOCKED_V31_SCAN_PATH_HASH','EVERY_SCAN_PATH_HASH_MUST_MATCH_EXAMINED_SOURCE','system_inventory.scan_path_hashes.'.$rel,hash_file('sha256',$p),$declared_scan[$rel]??null,'Der geprüfte Quellpfad weicht vom inventarisierten Stand ab.');
            }
        }
        $tree_hash=PPM679_Diagnostic::stable_hash($actual_scan);
        if(!hash_equals((string)($c['examined_source_tree_sha256']??''),$tree_hash)){
            $errors[]=self::err('BLOCKED_V31_SOURCE_TREE_HASH','EXAMINED_SOURCE_TREE_HASH_MUST_BIND_ALL_SCAN_PATHS','system_inventory.examined_source_tree_sha256',$tree_hash,$c['examined_source_tree_sha256']??null,'Die Inventur bindet nicht den tatsächlich geprüften Quellbaum.');
        }

        $registry=self::load_json(self::REGISTRY_FILE);$rule_ids=array();
        foreach((array)($registry['rules']??array()) as $r){if(($r['active']??false)===true){$rule_ids[(string)($r['rule_id']??'')]=true;}}
        $transitions=self::load_json(self::TRANSITION_FILE);$scenario_ids=array();
        foreach((array)($transitions['scenarios']??array()) as $s){$scenario_ids[(string)($s['scenario_id']??'')]=true;}

        $declared=array();foreach((array)($c['findings']??array()) as $f){$declared[(string)($f['inventory_id']??'')]=$f;}
        $actual=array();foreach(self::discover() as $f){$actual[(string)$f['inventory_id']]=$f;}
        foreach($actual as $id=>$f){
            if(!isset($declared[$id])){$errors[]=self::err('BLOCKED_V31_SYSTEM_UNMAPPED','EVERY_DISCOVERED_SYSTEM_ELEMENT_REQUIRES_RULE_MAPPING','system_inventory.actual.'.$id,'declared mapped finding',$f,'Die unabhängige Codesuche fand ein nicht inventarisiertes Systemelement.');continue;}
            $d=$declared[$id];
            foreach(array('kind','source_path','line','symbol','match','source_line_sha256') as $field){
                if((string)($d[$field]??'')!==(string)($f[$field]??'')){$errors[]=self::err('BLOCKED_V31_SYSTEM_FINDING_MISMATCH','DISCOVERED_FINDING_MUST_MATCH_DECLARED_SOURCE','system_inventory.'.$id.'.'.$field,$f[$field]??null,$d[$field]??null,'Ein inventarisiertes Systemelement weicht von der unabhängigen Codesuche ab.');}
            }
            if(empty($d['hard_rule_ids'])||empty($d['positive_scenario_ids'])||empty($d['negative_scenario_ids'])||empty($d['required_evidence'])||empty($d['validator_or_reviewer'])){
                $errors[]=self::err('BLOCKED_V31_SYSTEM_MAPPING_INCOMPLETE','DISCOVERED_SYSTEM_ELEMENT_REQUIRES_RULE_SCENARIOS_AND_EVIDENCE','system_inventory.'.$id,'complete mapping',$d,'Ein Systemelement ist nicht vollständig auf Regel, Szenarien und Evidenz abgebildet.');
            }
            foreach((array)($d['hard_rule_ids']??array()) as $rid){if(!isset($rule_ids[(string)$rid])){$errors[]=self::err('BLOCKED_V31_SYSTEM_RULE_UNKNOWN','SYSTEM_FINDING_RULE_ID_MUST_EXIST_IN_ACTIVE_REGISTRY','system_inventory.'.$id.'.hard_rule_ids','active rule id',$rid,'Ein Systemelement verweist auf keine aktive Regel.');}}
            foreach(array('positive_scenario_ids','negative_scenario_ids') as $sf){foreach((array)($d[$sf]??array()) as $sid){if(!isset($scenario_ids[(string)$sid])){$errors[]=self::err('BLOCKED_V31_SYSTEM_SCENARIO_UNKNOWN','SYSTEM_FINDING_SCENARIO_ID_MUST_EXIST','system_inventory.'.$id.'.'.$sf,'known scenario id',$sid,'Ein Systemelement verweist auf kein bekanntes Zustands-Szenario.');}}}
        }
        foreach($declared as $id=>$d){if($id===''||!isset($actual[$id])){$errors[]=self::err('BLOCKED_V31_SYSTEM_STALE_FINDING','DECLARED_SYSTEM_FINDING_MUST_STILL_EXIST_IN_CODE','system_inventory.declared.'.$id,'actual code finding',$d,'Die Inventur enthält einen veralteten oder nicht mehr auffindbaren Eintrag.');}}

        $counts=(array)($c['blocking_counts']??array());
        foreach(array('SYSTEM_UNMAPPED','WRITE_PATH_UNMAPPED','STATEFUL_FIELD_UNMAPPED','UNIQUE_IDENTIFIER_UNMAPPED','TRANSITION_UNTESTED','PERSISTENT_SCENARIO_UNTESTED','LIVE_PREFLIGHT_UNBOUND','IDENTITY_SCOPE_AMBIGUOUS') as $key){
            if((int)($counts[$key]??-1)!==0){$errors[]=self::err('BLOCKED_V31_SYSTEM_COUNT_'.$key,'ALL_SYSTEM_DERIVED_BLOCKING_COUNTS_MUST_BE_ZERO','system_inventory.blocking_counts.'.$key,0,$counts[$key]??null,'Ein systemabgeleiteter Sperrzähler ist nicht null.');}
        }
        if((int)($c['finding_count']??-1)!==count($actual)){$errors[]=self::err('BLOCKED_V31_FINDING_COUNT','DECLARED_FINDING_COUNT_MUST_MATCH_DISCOVERY','system_inventory.finding_count',count($actual),$c['finding_count']??null,'Die Anzahl inventarisierter Systemelemente stimmt nicht.');}
        if(($c['absolute_completeness_claimed']??null)!==false){$errors[]=self::err('BLOCKED_V31_ABSOLUTE_COMPLETENESS_FLAG','ABSOLUTE_COMPLETENESS_CLAIM_MUST_BE_FALSE','system_inventory.absolute_completeness_claimed',false,$c['absolute_completeness_claimed']??null,'Absolute Vollständigkeit darf nicht behauptet werden.');}
        if(empty($c['search_methods'])||empty($c['known_limits'])||empty($c['review_scope'])||empty($c['review_timestamp'])){
            $errors[]=self::err('BLOCKED_V31_SEARCH_SCOPE_DISCLOSURE','INDEPENDENT_SEARCH_SCOPE_METHODS_LIMITS_AND_TIME_MUST_BE_DISCLOSED','system_inventory.scope_disclosure','complete disclosure',array('methods'=>$c['search_methods']??null,'limits'=>$c['known_limits']??null,'scope'=>$c['review_scope']??null,'time'=>$c['review_timestamp']??null),'Prüfbereich, Methoden, Grenzen oder Zeitpunkt fehlen.');
        }
        $phrase=(string)($c['allowed_status_statement']??'');
        if(strpos($phrase,'keine weitere nicht zugeordnete Lücke gefunden')===false){$errors[]=self::err('BLOCKED_V31_STATUS_WORDING','STATUS_MUST_ONLY_CLAIM_NO_GAP_FOUND_IN_DISCLOSED_SEARCH_SCOPE','system_inventory.allowed_status_statement','limited independent-search statement',$phrase,'Die Statusformulierung behauptet keine ehrlich begrenzte Suche.');}
        foreach((array)($c['forbidden_absolute_claims']??array()) as $bad){if($bad!==''&&stripos($phrase,(string)$bad)!==false){$errors[]=self::err('BLOCKED_V31_ABSOLUTE_COMPLETENESS_CLAIM','ABSOLUTE_COMPLETENESS_CLAIMS_ARE_FORBIDDEN','system_inventory.allowed_status_statement','no absolute completeness claim',$bad,'Eine absolute Vollständigkeitsbehauptung ist verboten.');}}
        return $errors;
    }

    public static function summary(){
        $c=self::load();$actual=self::discover();
        return array(
            'status'=>self::validate()? 'BLOCKED':'NO_FURTHER_UNMAPPED_GAP_FOUND_BY_INDEPENDENT_SEARCH',
            'finding_count'=>count($actual),
            'scan_path_count'=>count((array)($c['scan_paths']??array())),
            'examined_source_tree_sha256'=>$c['examined_source_tree_sha256']??'',
            'review_scope'=>$c['review_scope']??'',
            'review_timestamp'=>$c['review_timestamp']??'',
            'search_methods'=>$c['search_methods']??array(),
            'known_limits'=>$c['known_limits']??array(),
            'allowed_status_statement'=>$c['allowed_status_statement']??'',
            'absolute_completeness_claimed'=>false
        );
    }
}
