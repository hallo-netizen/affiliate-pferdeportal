<?php
require_once __DIR__.'/fixture-builder.php';
$p=v31_prepare('g9-request-v31-fingerprint-0013',true);ppm_test_assert($p['ok']===true,'prepare');
$bad=$p['plan'];$bad['payload']['title'].=' manipuliert';
$e=PPM679_Stateful_Write_Gate::validate_plan($bad,$p['candidate'],$p['gate'],false);
ppm_test_assert(!empty($e),'tampered plan blocks');
ppm_test_assert($e[0]['error_code']==='BLOCKED_QF03_PLANNED_WRITE_FINGERPRINT_MISMATCH','fingerprint first blocker');
ppm_test_assert(count(PPM679_WP::test_posts())===1,'no write');
echo json_encode(array('status'=>'PASS_V31_PLANNED_WRITE_FINGERPRINT','blocker'=>$e[0]['error_code']),JSON_UNESCAPED_SLASHES)."\n";
