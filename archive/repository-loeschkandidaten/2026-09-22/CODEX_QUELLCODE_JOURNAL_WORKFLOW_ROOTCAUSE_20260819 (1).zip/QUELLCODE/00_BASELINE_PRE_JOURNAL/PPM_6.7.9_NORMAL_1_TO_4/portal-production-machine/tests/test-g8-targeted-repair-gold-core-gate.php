<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';
require __DIR__.'/wave3-fixture-builder.php';

$fixture=ppm_wave3_positive_fixture();
$positive=PPM679_Review_Matrix_Validator::validate($fixture['review'],$fixture['document'],$fixture['gold_reference'],array(),'g8_gold_repair_positive','local-g8-repair-state');
ppm_test_assert(($positive['gold_core_review_gate']??'')==='PASS','complete verified Gold-Core cells must yield Gold-Core PASS');
ppm_test_assert(($positive['gold_core_cells_checked']??0)===($positive['gold_core_cells_expected']??-1),'all expected Gold-Core cells must be checked');
ppm_test_assert(($positive['conditions']['GOLD_CORE_COVERAGE']??'')==='COMPLETE','complete Gold-Core coverage must be explicit');

$empty=$fixture['review'];
$empty['cells']=array();
$emptyResult=PPM679_Review_Matrix_Validator::validate($empty,$fixture['document'],$fixture['gold_reference'],array(),'g8_gold_repair_empty','local-g8-repair-state');
ppm_test_assert(($emptyResult['gold_core_review_gate']??'')==='NICHT_AUSGEFÜHRT','zero Gold-Core cells must never PASS');
ppm_test_assert(($emptyResult['conditions']['GOLD_CORE_REVIEW_GATE']??'')==='NICHT_AUSGEFÜHRT','hard condition must also report NICHT_AUSGEFÜHRT');
ppm_test_assert(($emptyResult['gold_core_cells_checked']??-1)===0,'zero cells checked must be explicit');

$missing=$fixture['review'];
foreach ($missing['cells'] as $index=>$cell) {
    if (($cell['criterion_id']??'')==='GOLD_CORE_ALIGNMENT') { array_splice($missing['cells'],$index,1); break; }
}
$missingResult=PPM679_Review_Matrix_Validator::validate($missing,$fixture['document'],$fixture['gold_reference'],array(),'g8_gold_repair_missing','local-g8-repair-state');
ppm_test_assert(($missingResult['gold_core_review_gate']??'')==='BLOCKED','missing required Gold-Core cell must remain BLOCKED');
ppm_test_assert(($missingResult['conditions']['GOLD_CORE_COVERAGE']??'')==='INCOMPLETE','missing Gold-Core cell must expose incomplete coverage');

$failed=$fixture['review'];
foreach ($failed['cells'] as &$cell) {
    if (($cell['criterion_id']??'')==='GOLD_CORE_ALIGNMENT') { $cell['reference_exact_quote']='absichtlich nicht vorhandenes Referenzzitat'; break; }
}
unset($cell);
$failedResult=PPM679_Review_Matrix_Validator::validate($failed,$fixture['document'],$fixture['gold_reference'],array(),'g8_gold_repair_failed','local-g8-repair-state');
ppm_test_assert(($failedResult['gold_core_review_gate']??'')==='BLOCKED','failed Gold-Core evidence must remain BLOCKED');

echo json_encode(array(
    'contract'=>'g8_targeted_repair_gold_core_gate_report_v1',
    'status'=>'PASS',
    'positive'=>array('gate'=>$positive['gold_core_review_gate'],'checked'=>$positive['gold_core_cells_checked'],'expected'=>$positive['gold_core_cells_expected']),
    'zero_cells'=>array('gate'=>$emptyResult['gold_core_review_gate'],'hard_condition'=>$emptyResult['conditions']['GOLD_CORE_REVIEW_GATE'],'checked'=>$emptyResult['gold_core_cells_checked']),
    'missing_cell'=>array('gate'=>$missingResult['gold_core_review_gate'],'coverage'=>$missingResult['conditions']['GOLD_CORE_COVERAGE']),
    'failed_cell'=>array('gate'=>$failedResult['gold_core_review_gate']),
    'production_allowed'=>false,
    'draft_create_allowed'=>false,
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
