<?php
require_once dirname(__DIR__).'/bootstrap-test.php';
require_once __DIR__.'/fixture-builder.php';
$cases=array(); $base=qf03_gate_fixture();
foreach (array('TECHNICAL_STATUS','FACT_AND_HASH_STATUS','EDITORIAL_MACHINE_STATUS','KNOWN_ERROR_GATE_V1','GENERAL_TEMPLATE_REPETITION_STATUS','GOLD_CORE_NUMERIC_GATE','EDITORIAL_REVIEW_STATUS','GOLD_CORE_REVIEW_GATE','CONTROL_BASELINE_STATUS','SERVER_CHECK_STATUS') as $f) { $x=$base; $x[$f]='BLOCKED'; $cases['status_'.$f]=$x; }
$x=$base; $x['FINAL_CONTENT_HASH']=str_repeat('b',64); $cases['content_hash_mismatch']=$x;
$x=$base; $x['CURRENT_GOLD_REFERENCE_HASH']=str_repeat('b',64); $cases['gold_hash_mismatch']=$x;
$x=$base; $x['article_count']=2; $cases['two_articles']=$x;
$x=$base; $x['article_type']='vergleich'; $cases['non_faq']=$x;
$x=$base; $x['evidence_class']='LOCAL_EXECUTED_TEST'; $cases['local_evidence']=$x;
$x=$base; $x['manual_override']=true; $cases['manual_override']=$x;
$blocked=array(); foreach ($cases as $name=>$gate) { $r=PPM679_WP_Draft_Adapter::evaluate_draft_gate($gate); ppm_test_assert($r['ok']===false,$name.' must block'); $blocked[$name]=$r['report']['status']; }
PPM679_WP::reset_test_state(); PPM679_WP_Draft_Adapter::reset_test_state();
$direct=PPM679_WP::insert_draft('Direct','<p>Bypass</p>','direct',array('_ppm679_publish_blocked'=>'1'),array(42));
ppm_test_assert((int)$direct===0,'Direct legacy insert_draft without QF03 token must be blocked');
ppm_test_assert(count(PPM679_WP::test_posts())===0,'Bypass must not create a draft');

PPM679_WP::reset_test_state(); PPM679_WP_Draft_Adapter::reset_test_state();
$c=qf03_candidate_fixture(); $g=qf03_gate_fixture();
$meta=array('_ppm679_test_marker'=>$c['internal_test_marker'],'_ppm679_content_hash'=>hash('sha256',$c['content_html']),'_ppm679_editorially_reviewed_content_hash'=>$g['EDITORIALLY_REVIEWED_CONTENT_HASH'],'_ppm679_gold_reference_hash'=>$g['REVIEW_GOLD_REFERENCE_HASH'],'_ppm679_publish_blocked'=>'1','_ppm679_qf03_gate'=>'PASS');
$payload=array('title'=>$c['title'],'content'=>$c['content_html'],'slug'=>$c['slug'],'meta'=>$meta,'categories'=>array($c['category_id']));
$auth=PPM679_WP_Draft_Adapter::issue_write_authorization($payload,$g); ppm_test_assert($auth['ok']===true,'one-use token setup');
$first=PPM679_WP::insert_draft($payload['title'],$payload['content'],$payload['slug'],$payload['meta'],$payload['categories'],$auth['authorization']);
$second=PPM679_WP::insert_draft($payload['title'],$payload['content'],$payload['slug'],$payload['meta'],$payload['categories'],$auth['authorization']);
ppm_test_assert((int)$first>0 && (int)$second===0,'QF03 write token must be one-use');

echo json_encode(array('status'=>'PASS','blocked_cases'=>$blocked,'legacy_direct_write_blocked'=>true,'one_use_token_enforced'=>true),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
