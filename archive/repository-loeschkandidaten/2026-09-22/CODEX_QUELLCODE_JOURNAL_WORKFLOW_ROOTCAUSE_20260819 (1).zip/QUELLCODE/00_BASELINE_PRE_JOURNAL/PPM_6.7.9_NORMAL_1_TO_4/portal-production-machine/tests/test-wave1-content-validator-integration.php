<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

$results=array();
foreach (array('faq'=>'FAQ','beratung'=>'Beratung','vergleich'=>'Vergleich','pflege'=>'Pflege') as $slug=>$type) {
    $meta=json_decode((string)file_get_contents(__DIR__.'/fixtures/wave1/known-bad-'.$slug.'.json'),true);
    $html=(string)file_get_contents(__DIR__.'/fixtures/wave1/known-bad-'.$slug.'.html');
    $generated=array('article_type'=>$type,'title'=>$meta['title'],'content_html'=>$html,'content_hash'=>hash('sha256',$html));
    $item=array(
        'article_type'=>$type,'validation_contract_version'=>'','target_keyword'=>'',
        'runtime_order'=>array('links'=>array(
            array('href'=>'/parent/','anchor'=>'Parent'),array('href'=>'/related/','anchor'=>'Related')
        )),
        'source_snapshot_id'=>'missing-local-pack'
    );
    $result=PPM679_Content_Validator::check($generated,$item,'wave1_validator_integration_'.$slug,'local-state-hash');
    ppm_test_assert(empty($result['ok']),$type.' known bad fixture must be blocked by integrated validator');
    ppm_test_assert(($result['checks']['known_error_gate_status']??'')==='BLOCKED',$type.' integrated known gate must block');
    ppm_test_assert(($result['checks']['fail_closed_aggregate_status']??'')==='BLOCKED',$type.' integrated aggregate must block');
    $codes=array_values(array_unique(array_map(fn($e)=>(string)($e['error_code']??''),$result['errors']??array())));
    foreach (array('BLOCKED_KNOWN_BODY_H1','BLOCKED_KNOWN_REQUIRED_LIST_MISSING','BLOCKED_KNOWN_INTERNAL_LINK_COUNT') as $code) {
        ppm_test_assert(in_array($code,$codes,true),$type.' integrated result must expose '.$code);
    }
    $results[$type]=array('content_hash'=>hash('sha256',$html),'known_error_gate_status'=>$result['checks']['known_error_gate_status'],'fail_closed_aggregate_status'=>$result['checks']['fail_closed_aggregate_status'],'error_codes'=>$codes);
}

echo json_encode(array('contract'=>'wave1_content_validator_integration_report_v2','status'=>'PASS','items'=>$results),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
