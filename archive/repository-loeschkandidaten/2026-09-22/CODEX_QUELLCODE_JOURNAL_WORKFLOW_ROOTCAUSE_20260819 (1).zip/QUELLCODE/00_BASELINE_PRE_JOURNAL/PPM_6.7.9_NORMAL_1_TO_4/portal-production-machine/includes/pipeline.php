<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Pipeline {
    const VERSION='6.7.9';
    const LEASE_SECONDS=900;

    public static function execute_plan($plan) {
        $context='four_type_end_to_end';
        $plan_hash=PPM679_Diagnostic::stable_hash($plan);

        $editorial_candidates=array();
        foreach((array)($plan['items']??array()) as $editorial_item){
            $category_binding=is_array($editorial_item['category_binding']??null)?$editorial_item['category_binding']:array();
            $editorial_candidates[]=array(
                'plan_item_key'=>(string)($editorial_item['plan_item_key']??''),
                'canonical_article_id'=>(string)($editorial_item['canonical_article_id']??$editorial_item['plan_item_key']??''),
                'title'=>(string)($editorial_item['canonical_article']['title']??$editorial_item['topic']??''),
                'topic'=>(string)($editorial_item['topic']??''),
                'article_type'=>(string)($editorial_item['article_type']??''),
                'category_slug'=>(string)($category_binding['slug']??'')
            );
        }
        $editorial_gate=PPM679_Editorial_Plan_Runtime_Gate::preflight($editorial_candidates,'four_type_editorial_plan_preflight','production');
        if(empty($editorial_gate['ok'])){
            $gate=PPM679_Live_State_Gate::verify_live_state_or_abort('editorial_plan_preflight_failed',$plan_hash);
            return self::result($editorial_gate['report']??array(),$gate,'ppm-four-type-editorial-plan-blocked.json');
        }

        $schema=PPM679_Storage::ensure_schema();
        if (strpos((string)($schema['status']??''),'BLOCKED_')===0) {
            $gate=PPM679_Live_State_Gate::verify_live_state_or_abort('schema_setup_failed',$plan_hash);
            return self::result($schema,$gate,'ppm-four-type-blocked.json');
        }

        $initial_gate=PPM679_Live_State_Gate::verify_live_state_or_abort(
            'plan_v4_pre_accept',
            $plan_hash,
            null,
            null,
            array('server_instance_id'=>PPM679_BOUND_SERVER_INSTANCE_ID)
        );
        if (empty($initial_gate['ok'])) {
            return self::result($initial_gate['report'],$initial_gate,'ppm-four-type-blocked.json');
        }

        $validated=PPM679_Plan_Validator::validate($plan,'plan_v4_validation',$initial_gate['state']['server_state_hash']);
        if (empty($validated['ok'])) {
            $report=PPM679_Diagnostic::blocked(
                $validated['errors'][0]['error_code'],
                $validated['errors'],
                'plan_v4_validation',
                $initial_gate['state']['server_state_hash'],
                array('plan_hash'=>$plan_hash)
            );
            return self::result($report,$initial_gate,'ppm-four-type-blocked.json');
        }

        $run_id=self::id_value('run');
        $run=array(
            'run_id'=>$run_id,
            'plan_id'=>(string)$plan['plan_id'],
            'plan_hash'=>$plan_hash,
            'stage'=>'INIT',
            'plan'=>$plan,
            'workspace'=>null,
            'check_report'=>null,
            'readback'=>null,
            'error'=>null,
            'created_gmt'=>gmdate('Y-m-d H:i:s'),
            'updated_gmt'=>gmdate('Y-m-d H:i:s'),
        );
        if (!PPM679_Storage::create_run($run)) {
            $error=PPM679_Diagnostic::error(
                'BLOCKED_RUN_CREATE_FAILED',
                'VALIDATED_PLAN_MUST_CREATE_ISOLATED_RUN',
                'storage.runs',
                'new run row',
                false,
                'Der validierte Plan konnte nicht als isolierter Lauf gespeichert werden.',
                'run_create',
                $initial_gate['state']['server_state_hash'],
                __CLASS__,
                null,
                array('includes/pipeline.php')
            );
            return self::result(PPM679_Diagnostic::blocked($error['error_code'],array($error),'run_create',$initial_gate['state']['server_state_hash']),$initial_gate,'ppm-four-type-blocked.json');
        }

        $run=PPM679_Storage::get_run($run_id);
        $gate=PPM679_Live_State_Gate::verify_live_state_or_abort('plan_accept',$plan_hash,'INIT',$run,array('server_instance_id'=>PPM679_BOUND_SERVER_INSTANCE_ID));
        if (empty($gate['ok'])) { return self::block_run($run_id,$gate['report'],$gate); }
        PPM679_Storage::update_run($run_id,array('stage'=>'PLAN_ACCEPTED'));
        $run=PPM679_Storage::get_run($run_id);

        $gate=PPM679_Live_State_Gate::verify_live_state_or_abort('bootstrap',$plan_hash,'PLAN_ACCEPTED',$run,array('server_instance_id'=>PPM679_BOUND_SERVER_INSTANCE_ID));
        if (empty($gate['ok'])) { return self::block_run($run_id,$gate['report'],$gate); }

        $bootstrap=self::bootstrap($run_id,$plan,$gate);
        if (empty($bootstrap['ok'])) { return self::block_run($run_id,$bootstrap['report'],$gate); }
        PPM679_Storage::update_run($run_id,array('workspace'=>$bootstrap['workspace'],'stage'=>'BOOTSTRAPPED'));
        $run=PPM679_Storage::get_run($run_id);

        $workspace_hash=PPM679_Diagnostic::stable_hash($bootstrap['workspace']);
        $gate=PPM679_Live_State_Gate::verify_live_state_or_abort('generation',$workspace_hash,'BOOTSTRAPPED',$run,array('server_instance_id'=>PPM679_BOUND_SERVER_INSTANCE_ID));
        if (empty($gate['ok'])) { return self::abort_run($run_id,$gate['report'],$gate); }

        $generation=self::generate_all($run_id,$plan,$gate);
        if (empty($generation['ok'])) { return self::abort_run($run_id,$generation['report'],$gate); }
        PPM679_Storage::update_run($run_id,array('stage'=>'GENERATED'));
        $run=PPM679_Storage::get_run($run_id);

        $generated_hash=PPM679_Diagnostic::stable_hash($generation['generated']);
        $gate=PPM679_Live_State_Gate::verify_live_state_or_abort('check_only',$generated_hash,'GENERATED',$run,array('server_instance_id'=>PPM679_BOUND_SERVER_INSTANCE_ID));
        if (empty($gate['ok'])) { return self::abort_run($run_id,$gate['report'],$gate); }

        $check=self::check_all($run_id,$plan,$generation['generated'],$gate);
        if (empty($check['ok']) || ($check['technical_status']??'')!=='TECHNICAL_CHECK_OK' || ($check['content_quality_status']??'')!=='CONTENT_QUALITY_CHECK_OK') {
            return self::abort_run($run_id,$check['report'],$gate);
        }
        PPM679_Storage::update_run($run_id,array('check_report'=>$check['report'],'stage'=>'CHECKED'));
        $run=PPM679_Storage::get_run($run_id);

        $check_hash=PPM679_Diagnostic::stable_hash($check['report']);
        $gate=PPM679_Live_State_Gate::verify_live_state_or_abort('draft_create',$check_hash,'CHECKED',$run,array('server_instance_id'=>PPM679_BOUND_SERVER_INSTANCE_ID));
        if (empty($gate['ok'])) { return self::abort_run($run_id,$gate['report'],$gate); }

        $drafts=self::create_drafts($run_id,$generation['generated'],$check['report'],$gate,$plan);
        if (empty($drafts['ok'])) { return self::abort_run($run_id,$drafts['report'],$gate,$drafts['created_post_ids']??array()); }
        PPM679_Storage::update_run($run_id,array('stage'=>'DRAFTED'));
        $run=PPM679_Storage::get_run($run_id);

        $draft_hash=PPM679_Diagnostic::stable_hash($drafts['drafts']);
        $gate=PPM679_Live_State_Gate::verify_live_state_or_abort('draft_readback',$draft_hash,'DRAFTED',$run,array('server_instance_id'=>PPM679_BOUND_SERVER_INSTANCE_ID));
        if (empty($gate['ok'])) { return self::abort_run($run_id,$gate['report'],$gate,$drafts['created_post_ids']); }

        $readback=self::readback($run_id,$drafts['drafts'],$gate);
        if (empty($readback['ok'])) { return self::abort_run($run_id,$readback['report'],$gate,$drafts['created_post_ids']); }

        $editorial_state=PPM679_Editorial_Plan_Runtime_Gate::record_readback((array)($editorial_gate['bindings']??array()),(array)($readback['items']??array()),'four_type_draft_readback');
        if(empty($editorial_state['ok'])){
            $error=PPM679_Diagnostic::error('BLOCKED_EDITORIAL_RUNTIME_STATE_WRITE','READBACK_MUST_UPDATE_CANONICAL_EDITORIAL_PLAN_RUNTIME_STATE','editorial_plan.runtime_state','updated state',$editorial_state,'Der Readback konnte den Laufzeitstatus des kanonischen Redaktionsplans nicht aktualisieren.','four_type_draft_readback',$gate['state']['server_state_hash'],__CLASS__,null,array('includes/editorial-plan-runtime-gate.php'));
            return self::abort_run($run_id,PPM679_Diagnostic::blocked($error['error_code'],array($error),'four_type_draft_readback',$gate['state']['server_state_hash']),$gate,$drafts['created_post_ids']);
        }

        PPM679_Storage::set_tombstone_state_for_run($run_id,'CONSUMED');
        PPM679_Storage::update_run($run_id,array('readback'=>$readback['report'],'stage'=>'READBACK'));
        $run=PPM679_Storage::get_run($run_id);

        $candidate=PPM679_Diagnostic::ok(
            'FOUR_TYPE_END_TO_END_DRAFT_READBACK_CHECK_OK_AWAITING_USER_CONTENT_REVIEW_NO_PUBLISH',
            'four_type_end_to_end_complete',
            $gate['state']['server_state_hash'],
            array(
                'run_id'=>$run_id,
                'plan_id'=>(string)$plan['plan_id'],
                'plan_hash'=>$plan_hash,
                'workspace'=>$bootstrap['workspace'],
                'check_only'=>$check['report'],
                'draft_readback'=>$readback['report'],
                'drafts'=>$readback['items'],
                'user_action_required'=>'Inhalte der vier Entwürfe prüfen. Keine Veröffentlichung wurde registriert.',
                'production_allowed'=>true,
                'check_only_allowed'=>true,
                'draft_allowed'=>true,
                'publish_allowed'=>false,
                'editorial_plan_preflight'=>$editorial_gate['report'],
                'editorial_plan_runtime_state'=>$editorial_state['state']
            )
        );

        $candidate_hash=PPM679_Diagnostic::stable_hash($candidate);
        $final_gate=PPM679_Live_State_Gate::verify_live_state_or_abort('handoff_readback',$candidate_hash,'READBACK',$run,array('server_instance_id'=>PPM679_BOUND_SERVER_INSTANCE_ID));
        if (empty($final_gate['ok'])) { return self::abort_run($run_id,$final_gate['report'],$final_gate,$drafts['created_post_ids']); }
        $candidate['server_state_hash']=$final_gate['state']['server_state_hash'];
        $candidate['report_hash']=PPM679_Diagnostic::stable_hash($candidate);

        return self::result($candidate,$final_gate,'ppm-four-type-draft-readback-6.7.9.json');
    }

    private static function bootstrap($run_id,$plan,$gate) {
        $context='bootstrap';
        $state_hash=$gate['state']['server_state_hash'];
        PPM679_Storage::begin();

        $batch=PPM679_Identifier_Service::fresh('batch_id','batch',$run_id,$context,$state_hash);
        if (empty($batch['ok'])) { PPM679_Storage::set_tombstone_state_for_run($run_id,'ABORTED'); PPM679_Storage::commit(); return $batch; }
        $workspace=PPM679_Identifier_Service::fresh('workspace_id','workspace',$run_id,$context,$state_hash);
        if (empty($workspace['ok'])) { PPM679_Storage::set_tombstone_state_for_run($run_id,'ABORTED'); PPM679_Storage::commit(); return $workspace; }

        $workspace_items=array();
        foreach ($plan['items'] as $index=>$plan_item) {
            $bundle=PPM679_Identifier_Service::create_bundle($run_id,(string)$plan_item['plan_item_key'],$context,$state_hash);
            if (empty($bundle['ok'])) {
                PPM679_Storage::set_tombstone_state_for_run($run_id,'ABORTED');
                PPM679_Storage::commit();
                return $bundle;
            }
            $ids=$bundle['bundle'];
            $item=array(
                'run_id'=>$run_id,
                'plan_item_key'=>(string)$plan_item['plan_item_key'],
                'article_type'=>(string)$plan_item['article_type'],
                'topic'=>(string)$plan_item['topic'],
                'batch_article_id'=>$ids['batch_article_id'],
                'fact_pack_id'=>$ids['fact_pack_id'],
                'skeleton_id'=>$ids['skeleton_id'],
                'reservation_id'=>$ids['reservation_id'],
                'workspace_id'=>$workspace['value'],
                'skeleton_token'=>$ids['skeleton_token'],
                'lease_until_gmt'=>gmdate('Y-m-d H:i:s',time()+self::LEASE_SECONDS),
                'state'=>'RESERVED',
                'post_id'=>null,'title'=>null,'slug'=>null,'content_hash'=>null,'content_html'=>null,
            );
            if (!PPM679_Storage::add_item($item)) {
                PPM679_Storage::set_tombstone_state_for_run($run_id,'ABORTED');
                PPM679_Storage::commit();
                $error=PPM679_Diagnostic::error(
                    'BLOCKED_BOOTSTRAP_ITEM_WRITE_FAILED',
                    'EVERY_RESERVED_IDENTIFIER_BUNDLE_MUST_BIND_TO_ITEM_ATOMICALLY',
                    'workspace.items['.$index.']',
                    'stored item',
                    false,
                    'Die atomare Bindung eines serverseitigen Identifier-Bündels an den Planeintrag ist fehlgeschlagen.',
                    $context,$state_hash,__CLASS__,$index,array('includes/pipeline.php','includes/storage.php')
                );
                return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),$context,$state_hash));
            }
            $workspace_items[]=array(
                'plan_item_key'=>$item['plan_item_key'],
                'article_type'=>$item['article_type'],
                'batch_article_id'=>$item['batch_article_id'],
                'fact_pack_id'=>$item['fact_pack_id'],
                'skeleton_id'=>$item['skeleton_id'],
                'reservation_id'=>$item['reservation_id'],
                'workspace_id'=>$item['workspace_id'],
                'skeleton_token'=>$item['skeleton_token'],
                'lease_until_gmt'=>$item['lease_until_gmt'],
                'state'=>'RESERVED'
            );
        }
        PPM679_Storage::commit();
        $workspace_report=array(
            'contract'=>'ppm_server_workspace_v1',
            'version'=>self::VERSION,
            'run_id'=>$run_id,
            'batch_id'=>$batch['value'],
            'workspace_id'=>$workspace['value'],
            'items'=>$workspace_items,
            'registry_hash_after'=>PPM679_Storage::registry_state()['registry_hash'],
            'created_at'=>gmdate('c')
        );
        $workspace_report['workspace_hash']=PPM679_Diagnostic::stable_hash($workspace_report);
        return array('ok'=>true,'workspace'=>$workspace_report);
    }

    private static function generate_all($run_id,$plan,$gate) {
        $generated=array();
        $errors=array();
        foreach ($plan['items'] as $index=>$plan_item) {
            $pack=PPM679_Storage::load_fact_pack((string)$plan_item['source_snapshot_id']);
            $article=PPM679_Content_Generator::generate($plan_item,$pack);
            if (empty($article['ok'])) {
                $errors[]=PPM679_Diagnostic::error(
                    'BLOCKED_CONTENT_GENERATION_FAILED',
                    'FACT_PACK_AND_TYPE_TEMPLATE_MUST_GENERATE_ARTICLE_CANDIDATE',
                    'plan.items['.$index.']',
                    'generated article candidate',
                    $article,
                    'Die allgemeine Typvorlage konnte aus dem gebundenen Fact-Pack keinen Artikelkandidaten erzeugen.',
                    'generation',$gate['state']['server_state_hash'],__CLASS__,$index,array('includes/content-generator.php')
                );
                continue;
            }
            $generated[$plan_item['plan_item_key']]=$article;
            PPM679_Storage::update_item($run_id,$plan_item['plan_item_key'],array(
                'state'=>'GENERATED',
                'title'=>$article['title'],
                'slug'=>$article['slug'],
                'content_hash'=>$article['content_hash'],
                'content_html'=>$article['content_html']
            ));
        }
        if ($errors) {
            return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'generation',$gate['state']['server_state_hash']));
        }
        return array('ok'=>true,'generated'=>$generated);
    }

    private static function check_all($run_id,$plan,$generated,$gate) {
        $errors=array(); $items=array();
        $technical_ok=true; $quality_ok=true;
        foreach ($plan['items'] as $index=>$plan_item) {
            $key=$plan_item['plan_item_key'];
            $candidate=$generated[$key]??array();
            $check=PPM679_Content_Validator::check($candidate,$plan_item,'check_only',$gate['state']['server_state_hash']);
            $item_technical=($check['technical_status']??'')==='TECHNICAL_CHECK_OK';
            $item_quality=($check['content_quality_status']??'')==='CONTENT_QUALITY_CHECK_OK';
            $technical_ok=$technical_ok&&$item_technical;
            $quality_ok=$quality_ok&&$item_quality;
            $items[]=array(
                'plan_item_key'=>$key,
                'article_type'=>$plan_item['article_type'],
                'status'=>($item_technical&&$item_quality)?'TECHNICAL_AND_CONTENT_QUALITY_CHECK_OK':'BLOCKED_CONTENT_VALIDATION',
                'technical_status'=>$check['technical_status']??'BLOCKED_TECHNICAL_CHECK',
                'content_quality_status'=>$check['content_quality_status']??'BLOCKED_CONTENT_QUALITY_CHECK',
                'content_hash'=>$check['content_hash']??'',
                'checks'=>$check['checks']??array(),
                'errors'=>$check['errors']
            );
            if (!$check['ok']) { $errors=array_merge($errors,$check['errors']); }
            else { PPM679_Storage::update_item($run_id,$key,array('state'=>'CHECKED')); }
        }
        $aggregate=PPM679_Fail_Closed_Aggregator::aggregate_item_results($items);
        $technical_ok=$technical_ok&&!empty($aggregate['ok']);
        $quality_ok=$quality_ok&&!empty($aggregate['ok']);
        $extra=array(
            'items'=>$items,
            'technical_status'=>$technical_ok?'TECHNICAL_CHECK_OK':'BLOCKED_TECHNICAL_CHECK',
            'content_quality_status'=>$quality_ok?'CONTENT_QUALITY_CHECK_OK':'BLOCKED_CONTENT_QUALITY_CHECK',
            'known_error_batch_gate_status'=>($aggregate['status']??'BLOCKED'),
            'draft_create_allowed'=>false,
            'publish_allowed'=>false
        );
        if (empty($aggregate['ok']) && !$errors) {
            $errors[]=PPM679_Diagnostic::error(
                'BLOCKED_FAIL_CLOSED_AGGREGATE',
                'EVERY_ITEM_AND_INTEGRITY_STATUS_MUST_EXPLICITLY_PASS',
                'check_only.fail_closed_aggregate',
                'PASS',
                $aggregate,
                'Die zusammengefasste Freigabe wurde fail-closed blockiert.',
                'check_only',$gate['state']['server_state_hash'],__CLASS__,null,array('includes/pipeline.php','includes/fail-closed-aggregator.php')
            );
        }
        if ($errors || !$technical_ok || !$quality_ok) {
            if (!$errors) {
                $errors[]=PPM679_Diagnostic::error(
                    'BLOCKED_DUAL_CONTENT_GATE_INCOMPLETE',
                    'DRAFT_REQUIRES_TECHNICAL_AND_CONTENT_QUALITY_CHECK_ON_SAME_HASH',
                    'check_only',
                    array('technical_status'=>'TECHNICAL_CHECK_OK','content_quality_status'=>'CONTENT_QUALITY_CHECK_OK'),
                    array('technical_status'=>$extra['technical_status'],'content_quality_status'=>$extra['content_quality_status']),
                    'Mindestens eines der beiden unabhängig ausgewiesenen Prüfergebnisse fehlt.',
                    'check_only',$gate['state']['server_state_hash'],__CLASS__,null,array('includes/pipeline.php','includes/content-validator.php')
                );
            }
            return array('ok'=>false,'technical_status'=>$extra['technical_status'],'content_quality_status'=>$extra['content_quality_status'],'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'check_only',$gate['state']['server_state_hash'],$extra));
        }
        $report=PPM679_Diagnostic::ok('CLOSED_CHAIN_CHECK_OK','check_only',$gate['state']['server_state_hash'],$extra);
        return array('ok'=>true,'technical_status'=>'TECHNICAL_CHECK_OK','content_quality_status'=>'CONTENT_QUALITY_CHECK_OK','report'=>$report);
    }

    private static function create_drafts($run_id,$generated,$check_report,$gate,$plan) {
        $drafts=array(); $created=array(); $errors=array(); $index=0;
        $checked=array();
        foreach ((array)($check_report['items']??array()) as $checked_item) {
            if (is_array($checked_item) && isset($checked_item['plan_item_key'])) { $checked[(string)$checked_item['plan_item_key']]=$checked_item; }
        }
        $plan_items=array();
        foreach ((array)($plan['items']??array()) as $plan_item) {
            if (is_array($plan_item) && isset($plan_item['plan_item_key'])) { $plan_items[(string)$plan_item['plan_item_key']]=$plan_item; }
        }
        foreach ($generated as $key=>$candidate) {
            $evidence=$checked[(string)$key]??array();
            $candidate_hash=(string)($candidate['content_hash']??'');
            $checked_hash=(string)($evidence['content_hash']??'');
            $dual_ok=(($evidence['technical_status']??'')==='TECHNICAL_CHECK_OK' && ($evidence['content_quality_status']??'')==='CONTENT_QUALITY_CHECK_OK');
            if (!$dual_ok || $candidate_hash==='' || $checked_hash==='' || !hash_equals($candidate_hash,$checked_hash)) {
                $errors[]=PPM679_Diagnostic::error(
                    'BLOCKED_DRAFT_DUAL_GATE_MISSING',
                    'DRAFT_REQUIRES_TECHNICAL_AND_CONTENT_QUALITY_CHECK_ON_EXACT_CONTENT_HASH',
                    'drafts['.$index.'].gate_evidence',
                    array('technical_status'=>'TECHNICAL_CHECK_OK','content_quality_status'=>'CONTENT_QUALITY_CHECK_OK','content_hash'=>$candidate_hash),
                    array('technical_status'=>$evidence['technical_status']??null,'content_quality_status'=>$evidence['content_quality_status']??null,'content_hash'=>$checked_hash),
                    'Die Draft-Erstellung wurde blockiert, weil nicht beide Prüfergebnisse für exakt denselben finalen Content-Hash vorliegen.',
                    'draft_create',$gate['state']['server_state_hash'],__CLASS__,$index,array('includes/pipeline.php','includes/content-validator.php')
                );
                break;
            }
            $plan_item=$plan_items[(string)$key]??array();
            $quality_binding=isset($plan_item['quality_binding'])&&is_array($plan_item['quality_binding'])?$plan_item['quality_binding']:array();
            $marker=trim((string)($quality_binding['internal_test_marker']??''));
            $category=isset($quality_binding['wordpress_category'])&&is_array($quality_binding['wordpress_category'])?$quality_binding['wordpress_category']:array();
            $category_id=(int)($category['id']??0);
            if ($marker==='' || $category_id<=0) {
                $errors[]=PPM679_Diagnostic::error(
                    'BLOCKED_WAVE2_WORDPRESS_BINDING_MISSING',
                    'DRAFT_REQUIRES_INTERNAL_MARKER_AND_REAL_CATEGORY',
                    'drafts['.$index.'].quality_binding',
                    array('internal_test_marker'=>'non-empty','category_id'=>'>0'),
                    array('internal_test_marker'=>$marker,'category_id'=>$category_id),
                    'Der interne Testmarker oder die Zielkategorie fehlt.',
                    'draft_create',$gate['state']['server_state_hash'],__CLASS__,$index,array('includes/pipeline.php','includes/wp-adapter.php')
                );
                break;
            }
            $collisions=PPM679_WP::find_posts_by_meta_marker($marker,'_ppm679_test_marker');
            if ($collisions) {
                $errors[]=PPM679_Diagnostic::error(
                    'BLOCKED_WAVE2_TEST_MARKER_COLLISION',
                    'INTERNAL_TEST_MARKER_MUST_BE_UNIQUE_ACROSS_ALL_POST_STATUSES',
                    'drafts['.$index.'].internal_test_marker',
                    'no existing post',
                    $collisions,
                    'Der interne Testmarker wurde bereits in WordPress verwendet.',
                    'draft_create',$gate['state']['server_state_hash'],__CLASS__,$index,array('includes/pipeline.php','includes/wp-adapter.php')
                );
                break;
            }
            $qf03_candidate=array(
                'article_type'=>$candidate['article_type'],
                'title'=>$candidate['title'],
                'content_html'=>$candidate['content_html'],
                'slug'=>$candidate['slug'],
                'internal_test_marker'=>$marker,
                'category_id'=>$category_id,
                'category_slug'=>(string)($category['slug']??''),
                'run_id'=>$run_id
            );
            $qf03_context=isset($plan['qf03_context'])&&is_array($plan['qf03_context'])?$plan['qf03_context']:array();
            $qf03_gate=array(
                'TECHNICAL_STATUS'=>(($evidence['technical_status']??'')==='TECHNICAL_CHECK_OK'?'PASS':($evidence['technical_status']??null)),
                'FACT_AND_HASH_STATUS'=>$evidence['fact_and_hash_status']??null,
                'EDITORIAL_MACHINE_STATUS'=>$evidence['editorial_machine_status']??null,
                'KNOWN_ERROR_GATE_V1'=>$evidence['known_error_gate_status']??null,
                'GENERAL_TEMPLATE_REPETITION_STATUS'=>$evidence['general_template_repetition_status']??null,
                'GOLD_CORE_NUMERIC_GATE'=>$evidence['gold_core_numeric_gate']??null,
                'EDITORIAL_REVIEW_STATUS'=>$evidence['editorial_review_status']??null,
                'GOLD_CORE_REVIEW_GATE'=>$evidence['gold_core_review_gate']??null,
                'CONTROL_BASELINE_STATUS'=>$evidence['control_baseline_status']??null,
                'SERVER_CHECK_STATUS'=>$evidence['server_check_status']??null,
                'FINAL_CONTENT_HASH'=>$candidate_hash,
                'EDITORIALLY_REVIEWED_CONTENT_HASH'=>$evidence['editorially_reviewed_content_hash']??'',
                'CURRENT_GOLD_REFERENCE_HASH'=>$evidence['current_gold_reference_hash']??'',
                'REVIEW_GOLD_REFERENCE_HASH'=>$evidence['review_gold_reference_hash']??'',
                'user_triggered'=>($qf03_context['user_triggered']??false)===true,
                'nonce_verified'=>($qf03_context['nonce_verified']??false)===true,
                'current_user_can_manage'=>PPM679_WP::current_user_can_manage(),
                'article_count'=>count($generated),
                'article_type'=>$candidate['article_type'],
                'publish_allowed'=>false,
                'evidence_class'=>(string)($qf03_context['evidence_class']??'LEGACY_PIPELINE_NOT_QF03_SERVER_USER_TRIGGERED'),
                'simulation_only'=>($qf03_context['simulation_only']??false)===true,
                'manual_override'=>false,'time_pressure_exception'=>false,'progress_exception'=>false
            );
            $qf03_result=PPM679_WP_Draft_Adapter::create_single_faq_draft($qf03_candidate,$qf03_gate);
            $post_id=$qf03_result['post_id']??0;
            if (is_object($post_id) || (int)$post_id<=0) {
                $actual=is_object($post_id)&&method_exists($post_id,'get_error_message')?$post_id->get_error_message():$post_id;
                $errors[]=PPM679_Diagnostic::error(
                    'BLOCKED_DRAFT_CREATE_FAILED',
                    'CHECKED_ARTICLE_MUST_CREATE_WORDPRESS_DRAFT_ONLY',
                    'drafts['.$index.']',
                    'positive draft post id',
                    $actual,
                    'Der geprüfte Artikel konnte nicht als WordPress-Entwurf angelegt werden.',
                    'draft_create',$gate['state']['server_state_hash'],__CLASS__,$index,array('includes/pipeline.php')
                );
                break;
            }
            $post_id=(int)$post_id;
            $created[]=$post_id;
            $draft=array(
                'plan_item_key'=>$key,
                'article_type'=>$candidate['article_type'],
                'post_id'=>$post_id,
                'title'=>$candidate['title'],
                'slug'=>$candidate['slug'],
                'expected_content_hash'=>$candidate['content_hash'],
                'expected_test_marker'=>$marker,
                'expected_category_id'=>$category_id,
                'qf03_expected'=>$qf03_result['expected']??array(),
                'qf03_evidence_class'=>(string)($qf03_context['evidence_class']??''),
                'qf03_user_triggered'=>($qf03_context['user_triggered']??false)===true,
                'qf03_simulation_only'=>($qf03_context['simulation_only']??false)===true,
                'status'=>'draft'
            );
            $drafts[]=$draft;
            PPM679_Storage::update_item($run_id,$key,array('state'=>'DRAFTED','post_id'=>$post_id));
            $index++;
        }
        if ($errors) {
            foreach ($created as $id) { PPM679_WP::delete_post($id); }
            return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'draft_create',$gate['state']['server_state_hash']),'created_post_ids'=>$created);
        }
        return array('ok'=>true,'drafts'=>$drafts,'created_post_ids'=>$created);
    }

    private static function readback($run_id,$drafts,$gate) {
        $items=array(); $errors=array();
        foreach ($drafts as $index=>$draft) {
            $post=PPM679_WP::get_post_snapshot($draft['post_id']);
            $actual_hash=is_array($post)?hash('sha256',(string)($post['post_content']??'')):null;
            $status=is_array($post)?(string)($post['post_status']??''):null;
            $title=is_array($post)?(string)($post['post_title']??''):null;
            $meta=is_array($post)&&isset($post['meta'])&&is_array($post['meta'])?$post['meta']:array();
            $marker_value=$meta['_ppm679_test_marker']??null;
            if (is_array($marker_value)) { $marker_value=reset($marker_value); }
            $categories=is_array($post)&&isset($post['category_ids'])&&is_array($post['category_ids'])?array_map('intval',$post['category_ids']):array();
            $marker_ok=(string)$marker_value===(string)($draft['expected_test_marker']??'');
            $category_ok=in_array((int)($draft['expected_category_id']??0),$categories,true);
            $qf03_readback=null;
            if (empty($draft['qf03_simulation_only'])) {
                $qf03_readback=PPM679_WP_Readback_Validator::validate(
                    $post,
                    is_array($draft['qf03_expected']??null)?$draft['qf03_expected']:array(),
                    array(
                        'evidence_class'=>(string)($draft['qf03_evidence_class']??''),
                        'user_triggered'=>($draft['qf03_user_triggered']??false)===true,
                        'publish_event_count'=>0,
                        'captured_at'=>gmdate('c')
                    )
                );
            }
            if (!is_array($post) || $status!=='draft' || $title!==$draft['title'] || $actual_hash!==$draft['expected_content_hash'] || !$marker_ok || !$category_ok || (is_array($qf03_readback) && empty($qf03_readback['ok']))) {
                $errors[]=PPM679_Diagnostic::error(
                    'BLOCKED_DRAFT_READBACK_MISMATCH',
                    'DRAFT_READBACK_MUST_MATCH_EXACT_TITLE_CONTENT_HASH_AND_STATUS',
                    'readback['.$index.']',
                    array('status'=>'draft','title'=>$draft['title'],'content_hash'=>$draft['expected_content_hash'],'test_marker'=>$draft['expected_test_marker']??'','category_id'=>$draft['expected_category_id']??0),
                    array('status'=>$status,'title'=>$title,'content_hash'=>$actual_hash,'test_marker'=>$marker_value,'category_ids'=>$categories),
                    'Der WordPress-Readback stimmt nicht exakt mit dem geprüften Entwurf überein.',
                    'draft_readback',$gate['state']['server_state_hash'],__CLASS__,$index,array('includes/pipeline.php')
                );
            }
            $items[]=array(
                'plan_item_key'=>$draft['plan_item_key'],
                'article_type'=>$draft['article_type'],
                'post_id'=>$draft['post_id'],
                'post_status'=>$status,
                'title'=>$title,
                'content_hash'=>$actual_hash,
                'test_marker'=>$marker_value,
                'category_ids'=>$categories,
                'readback_status'=>($status==='draft'&&$title===$draft['title']&&$actual_hash===$draft['expected_content_hash']&&$marker_ok&&$category_ok&&(!is_array($qf03_readback)||!empty($qf03_readback['ok'])))?(empty($draft['qf03_simulation_only'])?'PASS':'STRUCTURAL_CHECK_OK'):'BLOCKED_DRAFT_READBACK_MISMATCH',
                'qf03_readback_status'=>is_array($qf03_readback)?($qf03_readback['READBACK_STATUS']??'BLOCKED'):'NOT_EXECUTED_LOCAL_SIMULATION'
            );
        }
        if ($errors) {
            return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'draft_readback',$gate['state']['server_state_hash'],array('items'=>$items)),'items'=>$items);
        }
        $report=PPM679_Diagnostic::ok('CLOSED_CHAIN_CHECK_OK','draft_readback',$gate['state']['server_state_hash'],array('items'=>$items,'publish_allowed'=>false));
        return array('ok'=>true,'report'=>$report,'items'=>$items);
    }

    private static function block_run($run_id,$report,$gate) {
        PPM679_Storage::update_run($run_id,array('stage'=>'BLOCKED','error'=>$report));
        return self::result($report,$gate,'ppm-four-type-blocked.json');
    }

    private static function abort_run($run_id,$report,$gate,$post_ids=array()) {
        foreach ((array)$post_ids as $post_id) { PPM679_WP::delete_post($post_id); }
        PPM679_Storage::set_tombstone_state_for_run($run_id,'ABORTED');
        PPM679_Storage::update_run($run_id,array('stage'=>'BLOCKED','error'=>$report));
        return self::result($report,$gate,'ppm-four-type-blocked.json');
    }

    private static function result($artifact,$gate,$filename) {
        return array('artifact'=>$artifact,'gate'=>$gate,'filename'=>$filename);
    }

    private static function id_value($prefix) {
        try { $random=bin2hex(random_bytes(18)); }
        catch (Throwable $e) { $random=hash('sha256',microtime(true).'|'.mt_rand()); }
        return $prefix.'-'.substr($random,0,32);
    }
}
