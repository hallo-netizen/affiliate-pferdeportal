<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Handoff_Permit {
    const VERSION = '6.7.9';
    private static $issued = array();
    private static $last_error_code = '';

    public static function issue($action, $artifact_type, $artifact, $gate_result) {
        if (!is_array($gate_result) || empty($gate_result['state']['server_state_hash'])) {
            return null;
        }
        $diagnostic_only = empty($gate_result['ok']);
        if ($diagnostic_only) {
            $status = is_array($artifact) ? (string)($artifact['status'] ?? '') : '';
            if (strpos($status, 'BLOCKED_') !== 0) { return null; }
        }
        $artifact_hash = PPM679_Diagnostic::stable_hash($artifact);
        try { $nonce = bin2hex(random_bytes(24)); }
        catch (Throwable $e) { $nonce = hash('sha256', microtime(true).'|'.mt_rand().'|'.$artifact_hash); }
        $permit = array(
            'contract'=>'ppm_handoff_permit_v1',
            'version'=>self::VERSION,
            'permit_id'=>'permit-'.substr(hash('sha256',$nonce.'|'.$artifact_hash),0,32),
            'action'=>(string)$action,
            'artifact_type'=>(string)$artifact_type,
            'artifact_sha256'=>$artifact_hash,
            'server_instance_id'=>(string)$gate_result['state']['server_instance_id'],
            'server_state_hash'=>(string)$gate_result['state']['server_state_hash'],
            'contract_hashes'=>$gate_result['state']['contract_hashes'],
            'issued_at'=>gmdate('c'),
            'expires_at'=>gmdate('c',time()+120),
            'expires_at_epoch'=>time()+120,
            'nonce'=>$nonce,
            'permitted_writer_id'=>'PPM679_Handoff_Writer',
            'diagnostic_only'=>$diagnostic_only,
            'consumed'=>false,
        );
        $permit['permit_hash']=PPM679_Diagnostic::stable_hash($permit);
        self::$issued[$permit['permit_id']]=$permit;
        return $permit;
    }

    public static function consume($permit, $artifact) {
        self::$last_error_code='';
        if (!is_array($permit) || empty($permit['permit_id']) || !isset(self::$issued[$permit['permit_id']])) {
            self::$last_error_code='BLOCKED_HANDOFF_PERMIT_MISSING';
            return false;
        }
        $stored=self::$issued[$permit['permit_id']];
        if (!empty($stored['consumed'])) {
            self::$last_error_code='BLOCKED_HANDOFF_PERMIT_ALREADY_CONSUMED';
            return false;
        }
        if ((int)$stored['expires_at_epoch'] < time()) {
            self::$last_error_code='BLOCKED_HANDOFF_PERMIT_EXPIRED';
            return false;
        }
        if ((string)$stored['artifact_sha256'] !== PPM679_Diagnostic::stable_hash($artifact)) {
            self::$last_error_code='BLOCKED_HANDOFF_PERMIT_ARTIFACT_HASH_MISMATCH';
            return false;
        }
        if ((string)$stored['permitted_writer_id'] !== 'PPM679_Handoff_Writer') {
            self::$last_error_code='BLOCKED_HANDOFF_WRITER_ID_MISMATCH';
            return false;
        }
        $fresh_state = PPM679_Live_State_Gate::state('handoff_writer_consume');
        if ((string)($fresh_state['server_state_hash'] ?? '') !== (string)$stored['server_state_hash']) {
            self::$last_error_code='BLOCKED_SERVER_STATE_CHANGED_AFTER_HANDSHAKE';
            return false;
        }
        self::$issued[$permit['permit_id']]['consumed']=true;
        return true;
    }

    public static function last_error_code() {
        return self::$last_error_code!=='' ? self::$last_error_code : 'BLOCKED_HANDOFF_PERMIT_INVALID';
    }

    public static function reset_test_state() {
        self::$issued=array();
        self::$last_error_code='';
    }
}

final class PPM679_Handoff_Writer {
    const VERSION='6.7.9';

    public static function encode_json($permit, $artifact) {
        if (!PPM679_Handoff_Permit::consume($permit,$artifact)) {
            $code=PPM679_Handoff_Permit::last_error_code();
            $reasons=array(
                'BLOCKED_HANDOFF_PERMIT_MISSING'=>'Es wurde kein vom Live-State-Gate erzeugtes Handoff-Permit übergeben.',
                'BLOCKED_HANDOFF_PERMIT_ALREADY_CONSUMED'=>'Das einmalige Handoff-Permit wurde bereits verbraucht.',
                'BLOCKED_HANDOFF_PERMIT_EXPIRED'=>'Das Handoff-Permit ist abgelaufen.',
                'BLOCKED_HANDOFF_PERMIT_ARTIFACT_HASH_MISMATCH'=>'Artefakt und Permit besitzen unterschiedliche Hashbindungen.',
                'BLOCKED_HANDOFF_WRITER_ID_MISMATCH'=>'Das Permit ist nicht an den einzigen aktiven Handoff-Writer gebunden.',
                'BLOCKED_SERVER_STATE_CHANGED_AFTER_HANDSHAKE'=>'Der frische Serverzustand hat sich nach Gate-Prüfung und vor der Ausgabe verändert.',
            );
            $reason=isset($reasons[$code])?$reasons[$code]:'Der einzige Handoff-Writer verweigert die Ausgabe ohne gültiges einmaliges Permit.';
            return PPM679_Diagnostic::encode(PPM679_Diagnostic::blocked(
                $code,
                array(PPM679_Diagnostic::error(
                    $code,
                    'HANDOFF_WRITER_MUST_RECEIVE_ONE_TIME_ARTIFACT_AND_LIVE_STATE_BOUND_PERMIT',
                    'handoff.permit',
                    'valid unconsumed permit with unchanged server state',
                    $permit,
                    $reason,
                    'handoff_writer',
                    '',
                    __CLASS__,
                    null,
                    array('includes/handoff-writer.php')
                )),
                'handoff_writer'
            ),true);
        }
        return PPM679_Diagnostic::encode($artifact,true);
    }

    public static function emit_json($permit,$artifact,$filename) {
        $bytes=self::encode_json($permit,$artifact);
        if (function_exists('nocache_headers')) { nocache_headers(); }
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=utf-8');
            $safe=function_exists('sanitize_file_name')?sanitize_file_name($filename):preg_replace('/[^A-Za-z0-9._-]/','-',(string)$filename);
            header('Content-Disposition: attachment; filename="'.$safe.'"');
            header('X-Content-Type-Options: nosniff');
        }
        echo $bytes;
        exit;
    }
}
