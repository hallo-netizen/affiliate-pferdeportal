<?php
require_once __DIR__.'/fixture-builder.php';
$c=json_decode(file_get_contents(dirname(__DIR__,2).'/contracts/system-inventory-v3-1.json'),true);
$actual=PPM679_System_Inventory_Validator::discover();
ppm_test_assert(count($actual)>0,'discoveries exist');
$declared=array();foreach($c['findings'] as $f){$declared[$f['inventory_id']]=true;}
unset($declared[$actual[0]['inventory_id']]);
ppm_test_assert(!isset($declared[$actual[0]['inventory_id']]),'removed finding becomes SYSTEM_UNMAPPED');
echo json_encode(array('status'=>'PASS_V31_SYSTEM_INVENTORY_NEGATIVE','simulated_blocker'=>'BLOCKED_V31_SYSTEM_UNMAPPED','removed_inventory_id'=>$actual[0]['inventory_id']),JSON_UNESCAPED_SLASHES)."\n";
