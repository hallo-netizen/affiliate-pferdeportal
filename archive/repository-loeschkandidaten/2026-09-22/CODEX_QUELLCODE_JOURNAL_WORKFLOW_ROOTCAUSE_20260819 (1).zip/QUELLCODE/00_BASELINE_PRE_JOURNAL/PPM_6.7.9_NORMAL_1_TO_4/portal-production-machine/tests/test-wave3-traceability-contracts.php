<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

function w3_load_json(string $path): array {
    $data=json_decode((string)file_get_contents($path),true);
    ppm_test_assert(is_array($data),'JSON must decode: '.$path);
    return $data;
}
$root=dirname(__DIR__);
$matrix=w3_load_json($root.'/contracts/review-matrix-schema-v1.json');
$evidence=w3_load_json($root.'/contracts/review-evidence-schema-v1.json');
$reuse=w3_load_json($root.'/contracts/quote-reuse-policy-v1.json');
$status=w3_load_json($root.'/contracts/status-gate-v1.json');
$registry=w3_load_json($root.'/contracts/evidence-registry-v1.json');
ppm_test_assert(PPM679_Diagnostic::stable_hash($matrix['schema'])===$matrix['review_matrix_schema_hash'],'matrix schema hash must match');
ppm_test_assert(PPM679_Diagnostic::stable_hash($evidence['schema'])===$evidence['review_evidence_schema_hash'],'evidence schema hash must match');
ppm_test_assert(PPM679_Diagnostic::stable_hash($reuse['policy'])===$reuse['quote_reuse_policy_hash'],'reuse policy hash must match');
ppm_test_assert(PPM679_Diagnostic::stable_hash($status['schema'])===$status['schema_hash'],'status schema hash must match');
ppm_test_assert(PPM679_Diagnostic::stable_hash($registry['schema'])===$registry['schema_hash'],'registry schema hash must match');

$binding=w3_load_json($root.'/traceability/WAVE3_REQUIREMENT_IMPLEMENTATION_BINDING.json');
$snapshot=w3_load_json($root.'/traceability/WAVE3_REQUIREMENT_SOURCE_SNAPSHOT.json');
ppm_test_assert(($binding['assigned_requirement_count']??0)===379,'binding must contain 379 requirements');
ppm_test_assert(count($binding['rows']??array())===379,'binding row count must be 379');
ppm_test_assert(count($snapshot['requirements']??array())===379,'snapshot count must be 379');
$source_map=array(); foreach($snapshot['requirements'] as $r){$source_map[$r['requirement_id']]=$r;}
$seen=array();
foreach($binding['rows'] as $index=>$row){
    $id=(string)($row['requirement_id']??'');
    ppm_test_assert($id!==''&&!isset($seen[$id]),'binding IDs must be unique at row '.$index);
    $seen[$id]=true;
    ppm_test_assert(isset($source_map[$id]),'binding ID must exist in source snapshot: '.$id);
    ppm_test_assert(($row['exact_requirement_hash']??'')===($source_map[$id]['requirement_text_sha256']??''),'requirement hash must match snapshot: '.$id);
    $source=$root.'/'.($row['source_path']??'');
    ppm_test_assert(is_file($source),'source path must exist: '.$source);
    ppm_test_assert(hash_file('sha256',$source)===($row['source_path_sha256']??''),'source hash must match binding: '.$id);
    $function=(string)($row['function']??'');
    $parts=explode('::',$function,2);
    ppm_test_assert(count($parts)===2&&method_exists($parts[0],$parts[1]),'bound function must exist: '.$function);
    ppm_test_assert(is_file($root.'/'.($row['executed_test_file']??'')),'test file must exist: '.$id);
    ppm_test_assert(trim((string)($row['positive_test_id']??''))!==''&&trim((string)($row['negative_test_id']??''))!=='','both test IDs required: '.$id);
    ppm_test_assert(($row['production_release_status']??'')==='BLOCKED_WAVE3_QUARANTINE','all rows remain production blocked: '.$id);
}
ppm_test_assert(count($seen)===379,'all 379 unique requirements must be covered');
ppm_test_assert(($binding['families']['QF02_EDITORIAL_MATRIX_AND_GOLD_CORE']??0)===227,'QF02 count must be 227');
ppm_test_assert(($binding['families']['QF05_EVIDENCE_STATUS_AND_EXPIRY']??0)===152,'QF05 count must be 152');
ppm_test_assert(empty($binding['production_allowed'])&&empty($binding['draft_create_allowed'])&&empty($binding['publish_allowed']),'Wave-3 traceability must not authorize production');

echo json_encode(array(
    'contract'=>'wave3_traceability_contract_report_v1','status'=>'PASS',
    'assigned_requirement_count'=>379,'unique_requirement_count'=>count($seen),
    'family_counts'=>$binding['families'],'mapping_level_counts'=>$binding['mapping_level_counts'],
    'contract_hashes'=>array(
        'review_matrix_schema_hash'=>$matrix['review_matrix_schema_hash'],
        'review_evidence_schema_hash'=>$evidence['review_evidence_schema_hash'],
        'quote_reuse_policy_hash'=>$reuse['quote_reuse_policy_hash'],
        'status_schema_hash'=>$status['schema_hash'],'evidence_registry_schema_hash'=>$registry['schema_hash']
    ),
    'production_allowed'=>false,'draft_create_allowed'=>false,'publish_allowed'=>false
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
