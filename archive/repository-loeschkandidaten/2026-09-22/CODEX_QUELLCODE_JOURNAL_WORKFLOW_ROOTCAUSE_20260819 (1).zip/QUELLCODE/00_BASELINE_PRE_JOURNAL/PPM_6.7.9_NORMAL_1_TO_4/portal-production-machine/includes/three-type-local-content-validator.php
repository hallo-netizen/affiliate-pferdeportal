<?php
if (!defined('ABSPATH')) { return; }

/**
 * Isolated local-only structural/content validator for the bundled Beratung,
 * Vergleich and Pflege pre-Claude candidate. It deliberately does not claim
 * LanguageTool, human editorial approval, WordPress runtime validation or any
 * production release.
 */
final class PPM679_Three_Type_Local_Content_Validator {
    const VERSION='6.7.9-three-type-local-v1';
    const TYPES=array('Beratung','Vergleich','Pflege');
    const BINDING_CONTRACT='three_type_local_quality_binding_v1';
    const MIN_WORDS=750;
    const MAX_WORDS=1800;

    public static function evaluate($generated,$item,$fact_pack,$context='three_type_local_content') {
        $errors=array();
        $checks=array(
            'contract'=>'THREE_TYPE_LOCAL_CONTENT_VALIDATOR_V1',
            'version'=>self::VERSION,
            'scope'=>'LOCAL_UNSIGNED_PRE_CLAUDE_ONLY',
            'language_tool_pass_claimed'=>false,
            'independent_editorial_pass_claimed'=>false,
        );
        if (!PPM679_WP::is_test_mode()) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_CONTENT_LOCAL_ONLY','THREE_TYPE_LOCAL_CONTENT_VALIDATION_REQUIRES_TEST_MODE','runtime.test_mode',true,false,'Der lokale Inhaltsvalidator darf außerhalb des Testmodus nicht laufen.',$context);
            return self::result($errors,$checks);
        }
        $type=(string)($item['article_type']??'');
        $title=trim((string)($generated['title']??''));
        $html=(string)($generated['content_html']??'');
        $binding=(array)($item['quality_binding']??array());
        $checks['article_type']=$type;
        $checks['content_hash']=hash('sha256',$html);

        if (!in_array($type,self::TYPES,true)) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_CONTENT_TYPE','LOCAL_CONTENT_TYPE_MUST_BE_EXACT_ALLOWED_TYPE','item.article_type',self::TYPES,$type,'Der Beitrag gehört nicht zum gebündelten Drei-Typ-Block.',$context);
            return self::result($errors,$checks);
        }
        self::check_binding($binding,$item,$type,$errors,$checks,$context);
        self::check_basic_body($title,$html,$binding,$errors,$checks,$context);
        $sections=self::sections($html);
        self::check_sections($sections,$type,$errors,$checks,$context);
        self::check_headings($html,$binding,$errors,$checks,$context);
        self::check_lists($sections,$type,$errors,$checks,$context);
        self::check_links($sections,$html,$binding,$errors,$checks,$context);
        self::check_table($sections,$html,$errors,$checks,$context);
        self::check_conclusion($sections,$type,$html,$errors,$checks,$context);
        self::check_fact_trace($sections,$html,$fact_pack,$type,$errors,$checks,$context);
        self::check_type_meta($binding,$type,$errors,$checks,$context);
        self::check_disclosure($html,$errors,$checks,$context);
        return self::result($errors,$checks);
    }

    private static function check_binding($binding,$item,$type,&$errors,&$checks,$context) {
        if ((string)($binding['contract']??'')!==self::BINDING_CONTRACT) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_QUALITY_BINDING','THREE_TYPE_LOCAL_QUALITY_BINDING_REQUIRED','item.quality_binding.contract',self::BINDING_CONTRACT,$binding['contract']??null,'Die lokale Qualitätsbindung fehlt oder hat den falschen Vertrag.',$context);
        }
        $actual=PPM679_Diagnostic::stable_hash($binding);
        $claimed=strtolower(trim((string)($item['quality_binding_hash']??'')));
        $checks['quality_binding_hash']=$actual;
        if (!preg_match('/^[0-9a-f]{64}$/',$claimed) || !hash_equals($actual,$claimed)) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_QUALITY_BINDING_HASH','THREE_TYPE_LOCAL_QUALITY_BINDING_HASH_MUST_MATCH','item.quality_binding_hash',$actual,$claimed,'Die lokale Qualitätsbindung wurde verändert oder nicht korrekt gebunden.',$context);
        }
        $marker=trim((string)($binding['internal_test_marker']??''));
        if (!preg_match('/^LT3-(BER|VER|PFL)-[0-9]{3}$/',$marker)) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_INTERNAL_MARKER','THREE_TYPE_INTERNAL_MARKER_MUST_BE_VALID_AND_HIDDEN','item.quality_binding.internal_test_marker','LT3-(BER|VER|PFL)-NNN',$marker,'Der interne Testmarker fehlt oder ist ungültig.',$context);
        }
        foreach (array(
            'language_review_status'=>'PENDING_INDEPENDENT_CLAUDE_REVIEW_NO_LANGUAGETOOL_PASS_CLAIMED',
            'editorial_review_status'=>'PENDING_INDEPENDENT_CLAUDE_REVIEW',
            'wordpress_runtime_category_status'=>'NOT_PERFORMED_LOCAL_ONLY'
        ) as $field=>$expected) {
            $actual_value=(string)($binding[$field]??'');
            if ($actual_value!==$expected) {
                $errors[]=self::err('BLOCKED_THREE_TYPE_REVIEW_STATUS','LOCAL_CANDIDATE_MUST_NOT_CLAIM_UNPERFORMED_REVIEW_OR_RUNTIME_CHECK','item.quality_binding.'.$field,$expected,$actual_value,'Eine noch nicht ausgeführte Prüfung wird unzulässig als abgeschlossen dargestellt.',$context);
            }
        }
        $category=(array)($binding['expected_category']??array());
        $local=(array)($item['three_type_local_binding']['expected_category']??array());
        if (PPM679_Diagnostic::stable_hash($category)!==PPM679_Diagnostic::stable_hash($local)) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_CATEGORY_BINDING','LOCAL_QUALITY_AND_CATEGORY_TARGET_MUST_MATCH','item.quality_binding.expected_category',$local,$category,'Die lokale Qualitätsbindung verweist auf eine andere Zielkategorie.',$context);
        }
        if (in_array((string)($category['slug']??''),array('','uncategorized','allgemein','standard'),true)) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_CATEGORY_GENERIC','LOCAL_TARGET_CATEGORY_MUST_BE_SPECIFIC','item.quality_binding.expected_category.slug','specific non-default category',$category['slug']??null,'Die Zielkategorie ist leer oder generisch.',$context);
        }
        if ((int)($binding['minimum_word_count']??0)!==self::MIN_WORDS || ($binding['ai_disclosure_required']??null)!==true) {
            $errors[]=self::err('BLOCKED_THREE_TYPE_QUALITY_THRESHOLD','LOCAL_QUALITY_THRESHOLDS_MUST_REMAIN_HARD','item.quality_binding',array('minimum_word_count'=>self::MIN_WORDS,'ai_disclosure_required'=>true),array('minimum_word_count'=>$binding['minimum_word_count']??null,'ai_disclosure_required'=>$binding['ai_disclosure_required']??null),'Ein harter Qualitätswert wurde abgeschwächt.',$context);
        }
    }

    private static function check_basic_body($title,$html,$binding,&$errors,&$checks,$context) {
        $h1=(int)preg_match_all('/<h1\b/iu',$html,$unused);
        $text=self::plain_text($html);
        $words=self::word_count($text);
        $links=(int)preg_match_all('/<a\b/iu',$html,$unused2);
        $checks['body_h1_count']=$h1;
        $checks['word_count']=$words;
        $checks['visible_link_count']=$links;
        if ($h1!==0) $errors[]=self::err('BLOCKED_CONTENT_BODY_H1','WORDPRESS_MUST_PROVIDE_ONLY_VISIBLE_H1','content.body_h1_count',0,$h1,'Der Artikelkörper darf die WordPress-Hauptüberschrift nicht wiederholen.',$context);
        if ($title!=='' && strpos(self::normalize($text),self::normalize($title))!==false) $errors[]=self::err('BLOCKED_CONTENT_TITLE_REPEATED','ARTICLE_TITLE_MUST_NOT_REPEAT_IN_BODY','content.title_repeated',false,true,'Der Beitragstitel wird im Artikelkörper wiederholt.',$context);
        if ($words<self::MIN_WORDS || $words>self::MAX_WORDS) $errors[]=self::err('BLOCKED_CONTENT_WORD_COUNT','THREE_TYPE_LOCAL_ARTICLE_WORD_COUNT_MUST_BE_IN_RANGE','content.word_count',array(self::MIN_WORDS,self::MAX_WORDS),$words,'Der lokale Referenzartikel ist zu kurz oder unnötig aufgebläht.',$context);
        $marker=(string)($binding['internal_test_marker']??'');
        if ($marker!=='' && (stripos($title,$marker)!==false || stripos($html,$marker)!==false)) $errors[]=self::err('BLOCKED_CONTENT_VISIBLE_TEST_MARKER','INTERNAL_TEST_MARKER_MUST_NOT_BE_VISIBLE','content.visible_marker',false,true,'Der interne Testmarker ist im sichtbaren Inhalt enthalten.',$context);
        foreach (array('PENDING_CLAUDE_REVIEW','LANGUAGETOOL_PASS','STRUCTURAL_LOCAL_CANDIDATE','data-fact-id=') as $needle) {
            if (stripos($text,$needle)!==false) $errors[]=self::err('BLOCKED_CONTENT_VISIBLE_MACHINE_META','VISIBLE_ARTICLE_TEXT_MUST_NOT_CONTAIN_MACHINE_META_LANGUAGE','content.visible_text','natural editorial text',$needle,'Technische Metasprache ist im sichtbaren Artikel enthalten.',$context);
        }
        if ($links!==3) $errors[]=self::err('BLOCKED_CONTENT_LINK_COUNT','EXACTLY_THREE_VISIBLE_INTERNAL_LINKS_REQUIRED','content.visible_links',3,$links,'Der Artikel benötigt genau drei gebundene interne Links.',$context);
    }

    private static function check_sections($sections,$type,&$errors,&$checks,$context) {
        $spec=PPM679_Article_Type_Validator::type_definition($type);
        $expected=(array)($spec['required_blocks']??array());
        $actual=array_map(function($x){return $x['block'];},$sections);
        $checks['section_blocks']=$actual;
        if ($actual!==$expected) {
            $missing=array_values(array_diff($expected,$actual));
            $errors[]=self::err('BLOCKED_CONTENT_REQUIRED_BLOCK_MISSING','ARTICLE_TYPE_REQUIRES_EXACT_BLOCKS_IN_EXACT_ORDER','content.sections',$expected,array('actual'=>$actual,'missing'=>$missing),'Pflichtblöcke fehlen, sind doppelt oder stehen in falscher Reihenfolge.',$context);
        }
        if (!$sections || ($sections[0]['block']??'')!=='intro') return;
        $intro=$sections[0]['body'];
        $intro_words=self::word_count(self::plain_text($intro));
        $heading_count=(int)preg_match_all('/<h[1-6]\b/iu',$intro,$unused);
        $starts=preg_match('/^\s*<p\b/iu',$intro)===1;
        $checks['intro_word_count']=$intro_words;
        if (!$starts || $heading_count!==0 || $intro_words<30 || $intro_words>100) {
            $errors[]=self::err('BLOCKED_CONTENT_INTRO_STRUCTURE','INTRO_MUST_START_WITH_PARAGRAPH_WITHOUT_HEADING_AND_30_TO_100_WORDS','content.intro',array('starts_with_p'=>true,'headings'=>0,'words'=>array(30,100)),array('starts_with_p'=>$starts,'headings'=>$heading_count,'words'=>$intro_words),'Der Einstieg ist nicht kurz und unmittelbar genug.',$context);
        }
    }

    private static function check_headings($html,$binding,&$errors,&$checks,$context) {
        preg_match_all('/<h([2-6])\b[^>]*>(.*?)<\/h\1>/isu',$html,$m,PREG_SET_ORDER);
        $headings=array();
        foreach($m as $index=>$x) {
            $text=self::plain_text($x[2]); $headings[]=$text; $wc=self::word_count($text);
            if ($wc<1 || $wc>14) $errors[]=self::err('BLOCKED_CONTENT_HEADING_LENGTH','HEADINGS_MUST_BE_SHORT_AND_READABLE','content.headings['.$index.']',array(1,14),$wc,'Eine Überschrift ist zu kurz oder zu lang.',$context);
            $normalized=self::normalize($text);
            foreach(array('im überblick','entscheidung ableiten','prüfpunkte','teilfragen','nicht belastbar') as $fragment) if(strpos($normalized,$fragment)!==false) $errors[]=self::err('BLOCKED_CONTENT_GENERIC_HEADING','GENERIC_OR_TECHNICAL_HEADINGS_FORBIDDEN','content.headings['.$index.']','specific natural heading',$text,'Eine generische oder technische Überschrift ist nicht zulässig.',$context);
        }
        $checks['headings']=$headings;
        preg_match_all('/<h2\b/iu',$html,$h2m); $h2_count=count($h2m[0]);
        $checks['h2_count']=$h2_count;
        if ($h2_count!==5) $errors[]=self::err('BLOCKED_CONTENT_HEADING_COUNT','EXACTLY_FIVE_SECTION_H2_HEADINGS_REQUIRED','content.h2_count',5,$h2_count,'Die lokale Referenzstruktur benötigt fünf sichtbare Abschnittsüberschriften zweiter Ebene.',$context);
        if (count(array_unique(array_map(array(__CLASS__,'normalize'),$headings)))!==count($headings)) $errors[]=self::err('BLOCKED_CONTENT_DUPLICATE_HEADING','HEADINGS_MUST_BE_UNIQUE','content.headings','unique headings',$headings,'Eine Überschrift wird doppelt verwendet.',$context);
        $intent=array_values(array_filter(array_map(array(__CLASS__,'normalize'),(array)($binding['intent_terms']??array()))));
        foreach($headings as $i=>$heading) {
            if (in_array($heading,array('Fazit','Weiterführende Informationen'),true)) continue;
            $n=self::normalize($heading); $found=false;
            foreach($intent as $term) if($term!=='' && strpos($n,$term)!==false){$found=true;break;}
            if(!$found) $errors[]=self::err('BLOCKED_CONTENT_HEADING_INTENT','NON_RESERVED_HEADINGS_REQUIRE_TOPIC_INTENT_TERM','content.headings['.$i.']',$intent,$heading,'Die Überschrift ist nicht konkret an das Artikelthema gebunden.',$context);
        }
    }

    private static function check_lists($sections,$type,&$errors,&$checks,$context) {
        $spec=PPM679_Article_Type_Validator::type_definition($type);
        $required=(array)($spec['required_lists']??array());
        $found=array();
        $html=self::sections_html($sections);
        foreach($required as $name) {
            if (!preg_match('/<(ul|ol)\b[^>]*data-list=("|\')'.preg_quote($name,'/').'\2[^>]*>(.*?)<\/\1>/isu',$html,$m)) {
                $errors[]=self::err('BLOCKED_CONTENT_REQUIRED_LIST_MISSING','ARTICLE_TYPE_REQUIRES_NAMED_LIST','content.lists.'.$name,'named list with at least four items',null,'Eine typgebundene Pflichtliste fehlt.',$context); continue;
            }
            $count=(int)preg_match_all('/<li\b/iu',$m[3],$unused); $found[$name]=$count;
            if($count<4) $errors[]=self::err('BLOCKED_CONTENT_LIST_ITEMS','REQUIRED_LIST_NEEDS_AT_LEAST_FOUR_ITEMS','content.lists.'.$name.'.items','>=4',$count,'Die Pflichtliste enthält zu wenige eigenständige Punkte.',$context);
        }
        $checks['required_lists']=$found;
    }

    private static function check_links($sections,$html,$binding,&$errors,&$checks,$context) {
        $links=(array)($binding['link_bindings']??array());
        $roles=array('parent_category','semantic_related','further_information');
        if(count($links)!==3 || array_values(array_map(function($x){return (string)($x['role']??'');},$links))!==$roles) {
            $errors[]=self::err('BLOCKED_CONTENT_LINK_BINDING','EXACT_LINK_ROLES_REQUIRED_IN_FIXED_ORDER','item.quality_binding.link_bindings',$roles,$links,'Die Linkrollen fehlen oder sind falsch geordnet.',$context);
        }
        $section_map=array(); foreach($sections as $s)$section_map[$s['block']]=$s['body'];
        $used=array();
        foreach($links as $i=>$link) {
            $role=(string)($link['role']??'');$href=(string)($link['href']??'');$anchor=(string)($link['anchor']??'');$section=(string)($link['section_id']??'');
            if($href==='' || $href[0]!=='/' || strpos($href,'//')===0 || preg_match('/^[a-z]+:/i',$href)) $errors[]=self::err('BLOCKED_CONTENT_LINK_TARGET','LOCAL_LINKS_MUST_BE_RELATIVE_INTERNAL_PATHS','item.quality_binding.link_bindings['.$i.'].href','relative internal path',$href,'Ein Linkziel ist nicht intern und relativ.',$context);
            if(isset($used[$section])) $errors[]=self::err('BLOCKED_CONTENT_LINK_SECTION_DUPLICATE','EACH_LINK_ROLE_REQUIRES_DISTINCT_SECTION','item.quality_binding.link_bindings['.$i.'].section_id','distinct section',$section,'Zwei Linkrollen liegen im selben Abschnitt.',$context); $used[$section]=true;
            $body=(string)($section_map[$section]??'');
            $pattern='/<a\b[^>]*data-link-role=("|\')'.preg_quote($role,'/').'\1[^>]*href=("|\')'.preg_quote($href,'/').'\2[^>]*>'.preg_quote($anchor,'/').'<\/a>/isu';
            if(!preg_match($pattern,$body)) $errors[]=self::err('BLOCKED_CONTENT_LINK_NOT_BOUND','VISIBLE_LINK_MUST_MATCH_ROLE_TARGET_ANCHOR_AND_SECTION','content.links['.$i.']',$link,$body,'Ein sichtbarer Link stimmt nicht mit seiner Bindung überein.',$context);
        }
        $checks['link_bindings']=$links;
    }

    private static function check_table($sections,$html,&$errors,&$checks,$context) {
        $count=(int)preg_match_all('/<table\b/iu',$html,$unused);
        if($count!==1) $errors[]=self::err('BLOCKED_CONTENT_TABLE_COUNT','EXACTLY_ONE_TABLE_REQUIRED','content.table_count',1,$count,'Der Beitrag benötigt genau eine Tabelle.',$context);
        $errors=array_merge($errors,PPM679_Table_Hard_Rule_Validator::validate_source_html($html,$context));
        $table=''; foreach($sections as $s) if($s['block']==='table')$table=$s['body'];
        preg_match('/<tbody>(.*?)<\/tbody>/isu',$table,$tm);$rows=(int)preg_match_all('/<tr\b/iu',$tm[1]??'',$unused2);
        preg_match('/<thead>(.*?)<\/thead>/isu',$table,$hm);$columns=(int)preg_match_all('/<th\b/iu',$hm[1]??'',$unused3);
        $checks['table_body_rows']=$rows;$checks['table_columns']=$columns;
        if($rows<4 || $columns<3) $errors[]=self::err('BLOCKED_CONTENT_TABLE_DIMENSIONS','TABLE_REQUIRES_AT_LEAST_FOUR_ROWS_AND_THREE_COLUMNS','content.table',array('rows'=>'>=4','columns'=>'>=3'),array('rows'=>$rows,'columns'=>$columns),'Die Tabelle ist für eine belastbare Entscheidung zu klein.',$context);
        foreach(array('Punkt','Wert','Info','Information','Details','Aspekt') as $generic) if(preg_match('/<th\b[^>]*>\s*'.preg_quote($generic,'/').'\s*<\/th>/iu',$table)) $errors[]=self::err('BLOCKED_CONTENT_TABLE_GENERIC_HEADER','GENERIC_TABLE_COLUMNS_FORBIDDEN','content.table.header','specific heading',$generic,'Eine Tabellenspalte ist zu allgemein benannt.',$context);
    }

    private static function check_conclusion($sections,$type,$html,&$errors,&$checks,$context) {
        $body='';foreach($sections as $s)if($s['block']==='conclusion')$body=$s['body'];
        $paragraphs=(int)preg_match_all('/<p\b/iu',$body,$unused);$cw=self::word_count(self::plain_text($body));$all=max(1,self::word_count(self::plain_text($html)));
        $spec=PPM679_Article_Type_Validator::type_definition($type);$min=(float)($spec['conclusion_min_ratio']??0.09);$ratio=$cw/$all;
        $checks['conclusion_paragraphs']=$paragraphs;$checks['conclusion_word_ratio']=$ratio;
        if($paragraphs<2 || $ratio<$min) $errors[]=self::err('BLOCKED_CONTENT_CONCLUSION','CONCLUSION_REQUIRES_TWO_PARAGRAPHS_AND_TYPE_RATIO',array('content.conclusion.paragraphs','content.conclusion.ratio'),array('paragraphs'=>'>=2','ratio'=>'>='.$min),array('paragraphs'=>$paragraphs,'ratio'=>$ratio),'Das Fazit ist zu kurz oder nicht eigenständig genug.',$context);
    }

    private static function check_fact_trace($sections,$html,$fact_pack,$type,&$errors,&$checks,$context) {
        if(!is_array($fact_pack) || (string)($fact_pack['article_type']??'')!==$type) {
            $errors[]=self::err('BLOCKED_CONTENT_FACT_PACK','EXACT_TYPE_FACT_PACK_REQUIRED','fact_pack.article_type',$type,$fact_pack['article_type']??null,'Das Fact-Pack fehlt oder gehört zu einem anderen Typ.',$context);return;
        }
        $claims=(array)($fact_pack['claims']??array());$missing=array();
        foreach($claims as $claim) {
            $id=(string)($claim['fact_id']??'');$source=(string)($claim['source_id']??'');$hash=(string)($claim['evidence_text_sha256']??'');
            $id_ok=$id!=='' && strpos($html,$id)!==false;
            $trace_ok=$source!=='' && $hash!=='' && strpos($html,'data-source-title="'.htmlspecialchars($source,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'"')!==false && strpos($html,'data-source-hash="'.$hash.'"')!==false;
            if(!$id_ok || !$trace_ok){$missing[]=$id;}
        }
        if($missing) $errors[]=self::err('BLOCKED_CONTENT_FACT_TRACE','ALL_FACT_PACK_CLAIMS_REQUIRE_VISIBLE_BLOCK_BINDING_AND_SOURCE_TRACE','content.fact_traces','all claim ids and traces',$missing,'Mindestens eine belegte Aussage ist nicht vollständig an Quelle und Fact-ID gebunden.',$context);
        $spec=PPM679_Article_Type_Validator::type_definition($type);$required=(array)($spec['fact_trace_required_blocks']??array());
        foreach($sections as $s) if(in_array($s['block'],$required,true) && strpos($s['body'],'data-fact-ids=')===false) $errors[]=self::err('BLOCKED_CONTENT_FACT_BLOCK_TRACE','FACTUAL_REQUIRED_BLOCKS_REQUIRE_FACT_IDS','content.section.'.$s['block'],'data-fact-ids binding',null,'Ein fachlicher Pflichtblock enthält keine Fact-ID-Bindung.',$context);
        $checks['fact_claim_count']=count($claims);$checks['fact_trace_missing']=$missing;
    }

    private static function check_type_meta($binding,$type,&$errors,&$checks,$context) {
        $meta=(array)($binding['type_meta']??array());$spec=PPM679_Article_Type_Validator::type_definition($type);$schema=(array)($spec['type_meta_schema']??array());
        foreach((array)($schema['required']??array()) as $field) {
            if(!array_key_exists($field,$meta)) {$errors[]=self::err('BLOCKED_CONTENT_TYPE_META','TYPE_SPECIFIC_META_FIELD_REQUIRED','item.quality_binding.type_meta.'.$field,'required field',null,'Eine typgebundene Metainformation fehlt.',$context);continue;}
            $field_spec=(array)($schema['fields'][$field]??array());$value=$meta[$field];
            if(($field_spec['type']??'')==='string' && self::text_length(trim((string)$value))<(int)($field_spec['min_length']??1)) $errors[]=self::err('BLOCKED_CONTENT_TYPE_META','TYPE_META_STRING_MIN_LENGTH','item.quality_binding.type_meta.'.$field,$field_spec,$value,'Ein typgebundener Textwert ist zu kurz.',$context);
            if(($field_spec['type']??'')==='list') { $list=is_array($value)?$value:array(); if(count($list)<(int)($field_spec['min_items']??1) || count(array_unique($list))!==count($list)) $errors[]=self::err('BLOCKED_CONTENT_TYPE_META','TYPE_META_LIST_CARDINALITY_AND_UNIQUENESS','item.quality_binding.type_meta.'.$field,$field_spec,$value,'Eine typgebundene Liste ist zu kurz oder enthält Duplikate.',$context); }
        }
        $checks['type_meta']=$meta;
    }

    private static function check_disclosure($html,&$errors,&$checks,$context) {
        $required='Dieser Beitrag wurde mithilfe von KI vorformuliert und anschließend redaktionell geprüft und überarbeitet.';
        $ok=(bool)preg_match('/<p\b[^>]*class=("|\')[^"\']*ppm-ai-disclosure[^"\']*\1[^>]*>\s*'.preg_quote($required,'/').'\s*<\/p>\s*<\/section>\s*<\/article>\s*$/isu',$html);
        $checks['ai_disclosure_present_at_end']=$ok;
        if(!$ok) $errors[]=self::err('BLOCKED_CONTENT_AI_DISCLOSURE','EXACT_AI_DISCLOSURE_REQUIRED_AT_ARTICLE_END','content.ai_disclosure',$required,$ok,'Der verbindliche KI-Hinweis fehlt oder steht nicht am Artikelende.',$context);
    }

    private static function sections($html) {
        preg_match_all('/<section\b[^>]*data-block=("|\')([^"\']+)\1[^>]*>(.*?)<\/section>/isu',(string)$html,$m,PREG_SET_ORDER);
        $out=array();foreach($m as $x)$out[]=array('block'=>(string)$x[2],'body'=>(string)$x[3]);return $out;
    }
    private static function sections_html($sections){$x='';foreach($sections as $s)$x.=$s['body'];return $x;}
    private static function plain_text($html){$x=html_entity_decode((string)$html,ENT_QUOTES|ENT_HTML5,'UTF-8');$x=(string)preg_replace('/<[^>]+>/u',' ',$x);return trim((string)preg_replace('/\s+/u',' ',$x));}
    private static function normalize($text){$x=self::lower(self::plain_text((string)$text));$x=(string)preg_replace('/[^\p{L}\p{N}]+/u',' ',$x);return trim((string)preg_replace('/\s+/u',' ',$x));}
    private static function lower($text){ if(function_exists('mb_strtolower')) return mb_strtolower((string)$text,'UTF-8'); return strtolower(strtr((string)$text,array('Ä'=>'ä','Ö'=>'ö','Ü'=>'ü')));}
    private static function text_length($text){ if(function_exists('mb_strlen')) return mb_strlen((string)$text,'UTF-8'); return preg_match_all('/./us',(string)$text,$m);}
    private static function word_count($text){preg_match_all('/[\p{L}\p{N}]+(?:[-–][\p{L}\p{N}]+)*/u',(string)$text,$m);return count($m[0]);}
    private static function result($errors,$checks){return array('ok'=>!$errors,'status'=>$errors?'BLOCKED_THREE_TYPE_LOCAL_CONTENT':'PASS_THREE_TYPE_LOCAL_STRUCTURAL_CONTENT_PENDING_CLAUDE','errors'=>array_values($errors),'checks'=>$checks,'language_review_status'=>'PENDING_INDEPENDENT_CLAUDE_REVIEW_NO_LANGUAGETOOL_PASS_CLAIMED','editorial_review_status'=>'PENDING_INDEPENDENT_CLAUDE_REVIEW','wordpress_runtime_validation_performed'=>false,'publish_allowed'=>false);}
    private static function err($code,$rule,$path,$expected,$actual,$reason,$context){return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$context,'',__CLASS__,null,array('includes/three-type-local-content-validator.php','contracts/three-type-bundled-approved-candidates-v1.json'));}
}
