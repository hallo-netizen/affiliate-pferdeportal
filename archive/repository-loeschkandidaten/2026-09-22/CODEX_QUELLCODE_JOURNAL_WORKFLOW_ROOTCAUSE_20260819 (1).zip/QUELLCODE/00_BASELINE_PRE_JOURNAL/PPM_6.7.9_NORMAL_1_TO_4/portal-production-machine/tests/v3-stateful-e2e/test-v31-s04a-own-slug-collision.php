<?php
require_once __DIR__.'/fixture-builder.php';
$p=v31_prepare('g9-request-v31-own-slug-0004',true);
ppm_test_assert($p['ok']===true,'own prior slug must produce a prebound alternative');
ppm_test_assert($p['plan']['slug_decision']==='OWN_PRIOR_RUN_COLLISION_DERIVED_BOUND_SLUG','own prior diagnosis');
ppm_test_assert($p['plan']['payload']['slug']!=='pferdeanhaenger-vor-fahrt-pruefen','derived slug');
ppm_test_assert($p['plan']['slug_collision_post_ids']===array(10277),'own prior post identified');
echo json_encode(array('status'=>'PASS_V31_S04A_OWN_SLUG','slug'=>$p['plan']['payload']['slug'],'diagnosis'=>$p['plan']['slug_decision']),JSON_UNESCAPED_SLASHES)."\n";
