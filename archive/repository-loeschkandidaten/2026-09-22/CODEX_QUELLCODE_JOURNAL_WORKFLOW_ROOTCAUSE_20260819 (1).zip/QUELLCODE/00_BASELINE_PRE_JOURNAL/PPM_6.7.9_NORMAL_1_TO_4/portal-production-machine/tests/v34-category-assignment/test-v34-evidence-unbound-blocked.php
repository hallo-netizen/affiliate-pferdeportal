<?php
require_once __DIR__.'/fixture-builder.php';PPM679_WP::reset_test_state();
$c=v34_contract();$i=v34_independent($c);PPM679_Category_Assignment_Validator::reset_test_state();
$r=PPM679_Category_Assignment_Validator::compare_and_resolve($i,$c['candidate']['category_binding'],v34_snapshot());
ppm_test_assert(empty($r['ok']),'unbound independent evidence must block');
echo "PASS_V34_EVIDENCE_UNBOUND_BLOCKED\n";
