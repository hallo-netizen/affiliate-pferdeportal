<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Status_Gate {
    const VERSION='6.7.9-wave3-quarantine';
    const STATUS_NAMES=array(
        'TECHNICAL_STATUS','FACT_AND_HASH_STATUS','EDITORIAL_MACHINE_STATUS','KNOWN_ERROR_GATE_V1',
        'GENERAL_TEMPLATE_REPETITION_STATUS','GOLD_CORE_NUMERIC_GATE','EDITORIAL_REVIEW_STATUS',
        'GOLD_CORE_REVIEW_GATE','SERVER_CHECK_STATUS','READBACK_STATUS','RENDERED_DOM_STATUS'
    );
    const ALLOWED_VALUES=array('PASS','FAIL','BLOCKED','UNGEKLÄRT','NICHT_AUSGEFÜHRT');

    public static function evaluate($statuses,$evidence_by_id,$evidence_ids_by_status,$contract=null,$context='wave3_status_gate',$server_state_hash='') {
        $statuses=is_array($statuses)?$statuses:array();
        $evidence_by_id=is_array($evidence_by_id)?$evidence_by_id:array();
        $evidence_ids_by_status=is_array($evidence_ids_by_status)?$evidence_ids_by_status:array();
        $contract=is_array($contract)?$contract:self::load_contract();
        $schema=(array)($contract['schema']??array());
        $minimum=(array)($schema['minimum_evidence_by_status']??array());
        $definitions=(array)($schema['status_definitions']??array());
        $errors=array();
        $declared=(string)($contract['schema_hash']??'');
        $actual=PPM679_Diagnostic::stable_hash($schema);
        if ($declared==='' || !hash_equals($actual,$declared)) {
            $errors[]=self::err('STATUS_CONTRACT_HASH_MISMATCH','STATUS_SCHEMA_MUST_MATCH_DECLARED_CANONICAL_HASH','contracts/status-gate-v1.json.schema_hash',$actual,$declared,'Der Statusvertrag wurde verändert oder ist nicht kanonisch gebunden.',$context,$server_state_hash);
        }
        if ((array)($schema['required_status_names']??array())!==self::STATUS_NAMES || (array)($schema['allowed_values']??array())!==self::ALLOWED_VALUES) {
            $errors[]=self::err('STATUS_CONTRACT_CODE_DRIFT','STATUS_CONTRACT_AND_RUNTIME_CONSTANTS_MUST_MATCH','contracts/status-gate-v1.json.schema','exact runtime constants',$schema,'Vertrag und ausführbarer Statuscode sind auseinandergelaufen.',$context,$server_state_hash);
        }
        $normalized=array();
        $checks=array();

        foreach (self::STATUS_NAMES as $status_name) {
            $value=(string)($statuses[$status_name]??'UNGEKLÄRT');
            if (!in_array($value,self::ALLOWED_VALUES,true)) {
                $errors[]=self::err('STATUS_VALUE_INVALID','STATUS_VALUE_MUST_USE_EXACT_ALLOWED_JSON_VALUE','statuses.'.$status_name,self::ALLOWED_VALUES,$value,'Es dürfen ausschließlich die exakten Statuswerte verwendet werden.',$context,$server_state_hash);
                $value='BLOCKED';
            }
            $normalized[$status_name]=$value;
            if (!isset($definitions[$status_name]) || !self::complete_definition($definitions[$status_name])) {
                $errors[]=self::err('STATUS_CODE_EVIDENCE_MISSING','NEW_STATUS_REQUIRES_FILE_FUNCTION_CONDITIONS_TESTS_RAW_OUTPUT_AND_EVIDENCE_ID','contract.status_definitions.'.$status_name,'complete code evidence definition',$definitions[$status_name]??null,'Eine Statusbezeichnung darf ohne vollständigen Codebeleg nicht gelten.',$context,$server_state_hash);
                $normalized[$status_name]='UNGEKLÄRT';
            }
            $ids=array_values(array_filter((array)($evidence_ids_by_status[$status_name]??array()),'is_string'));
            $status_errors=array();
            if ($value==='PASS') {
                if (!$ids) {
                    $status_errors[]=self::err('STATUS_EVIDENCE_ID_MISSING','PASS_STATUS_REQUIRES_VALID_EVIDENCE_ID','evidence_ids_by_status.'.$status_name,'one or more evidence IDs',array(),'Ein Statusname allein ist niemals ein Beleg.',$context,$server_state_hash);
                }
                $classes=array();
                $has_independent_model=false;
                foreach ($ids as $id) {
                    if (!isset($evidence_by_id[$id]) || !is_array($evidence_by_id[$id])) {
                        $status_errors[]=self::err('STATUS_EVIDENCE_ID_UNKNOWN','STATUS_EVIDENCE_ID_MUST_RESOLVE_TO_REGISTERED_EVIDENCE','evidence_ids_by_status.'.$status_name,$id,'missing','Die angegebene Beleg-ID ist nicht im geprüften Register vorhanden.',$context,$server_state_hash,array($id));
                        continue;
                    }
                    $ev=$evidence_by_id[$id];
                    $classes[]=(string)($ev['evidence_class']??'');
                    if (!empty($ev['model_assisted_review']) && ($ev['independence_declaration']??false)===true) { $has_independent_model=true; }
                }
                foreach ((array)($minimum[$status_name]??array()) as $required) {
                    if ($required==='INDEPENDENT_MODEL_REVIEW') {
                        if (!$has_independent_model) {
                            $status_errors[]=self::err('STATUS_INDEPENDENT_REVIEW_MISSING','EDITORIAL_PASS_REQUIRES_INDEPENDENT_REVIEW_EVIDENCE','evidence_ids_by_status.'.$status_name,'independent model review evidence',$ids,'Der redaktionelle PASS darf keinen früheren Maschinen-PASS übernehmen.',$context,$server_state_hash,$ids);
                        }
                    } elseif (!in_array($required,$classes,true)) {
                        $status_errors[]=self::err('STATUS_MINIMUM_EVIDENCE_CLASS_MISSING','PASS_STATUS_REQUIRES_EXACT_MINIMUM_EVIDENCE_CLASS','evidence_ids_by_status.'.$status_name,$required,$classes,'Die vorgeschriebene Mindestbelegklasse fehlt.',$context,$server_state_hash,$ids);
                    }
                }
                if ($classes && array_unique($classes)===array('STATIC_CODE_INSPECTION')) {
                    $status_errors[]=self::err('STATIC_CODE_INSPECTION_CANNOT_PASS_ALONE','STATIC_CODE_INSPECTION_MAY_NEVER_CREATE_PASS_ALONE','evidence_ids_by_status.'.$status_name,'executed evidence in addition to static inspection',$classes,'Statische Codeinspektion allein erzeugt keinen PASS.',$context,$server_state_hash,$ids);
                }
            }
            if ($status_errors) {
                $normalized[$status_name]=($value==='PASS')?'BLOCKED':$value;
                $errors=array_merge($errors,$status_errors);
            }
            $checks[$status_name]=array('requested'=>$value,'effective'=>$normalized[$status_name],'evidence_ids'=>$ids);
        }

        foreach (array_keys($statuses) as $name) {
            if (!in_array($name,self::STATUS_NAMES,true)) {
                $errors[]=self::err('STATUS_NAME_UNKNOWN','ONLY_EXACT_REGISTERED_STATUS_NAMES_ARE_ALLOWED','statuses.'.$name,self::STATUS_NAMES,$name,'Eigene Kurzbezeichnungen oder erfundene Statusnamen sind unzulässig.',$context,$server_state_hash);
            }
        }

        return array(
            'ok'=>!$errors,
            'status_gate_status'=>!$errors?'PASS':'BLOCKED',
            'statuses'=>$normalized,
            'checks'=>$checks,
            'errors'=>$errors,
            'production_allowed'=>false,
            'draft_create_allowed'=>false,
            'publish_allowed'=>false,
        );
    }

    public static function load_contract() {
        $file=defined('PPM679_PLUGIN_DIR')?PPM679_PLUGIN_DIR.'contracts/status-gate-v1.json':'';
        $data=$file!==''&&is_file($file)?json_decode((string)file_get_contents($file),true):null;
        return is_array($data)?$data:array();
    }

    private static function complete_definition($definition) {
        if (!is_array($definition)) { return false; }
        foreach (array('code_file','function','pass_condition','blocked_condition','positive_test','negative_test','raw_output','evidence_id') as $field) {
            if (!isset($definition[$field]) || trim((string)$definition[$field])==='') { return false; }
        }
        return true;
    }

    private static function err($code,$rule,$path,$expected,$actual,$reason,$context,$server_state_hash,$refs=array()) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$context,$server_state_hash,__CLASS__,null,$refs);
    }
}
