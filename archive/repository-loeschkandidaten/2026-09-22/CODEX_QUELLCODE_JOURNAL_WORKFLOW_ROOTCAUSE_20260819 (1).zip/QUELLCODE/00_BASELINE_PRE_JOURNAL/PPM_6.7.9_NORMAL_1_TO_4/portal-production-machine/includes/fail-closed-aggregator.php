<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Fail_Closed_Aggregator {
    const VERSION='6.7.9-wave1-quarantine';
    const ALLOWED_STATUSES=array('PASS','FAIL','BLOCKED','UNGEKLÄRT','NICHT_AUSGEFÜHRT');

    public static function merge_content_validation($base,$known_gate,$context='content_validation_fail_closed') {
        $base=is_array($base)?$base:array();
        $known_gate=is_array($known_gate)?$known_gate:array();
        $errors=array_merge(
            isset($base['errors'])&&is_array($base['errors'])?$base['errors']:array(),
            isset($known_gate['errors'])&&is_array($known_gate['errors'])?$known_gate['errors']:array()
        );
        $base_ok=isset($base['ok']) && $base['ok']===true;
        $known_ok=isset($known_gate['ok']) && $known_gate['ok']===true && ($known_gate['known_error_gate_status']??'')==='PASS';
        $ok=$base_ok&&$known_ok&&!$errors;
        $base_checks=isset($base['checks'])&&is_array($base['checks'])?$base['checks']:array();
        $known_checks=isset($known_gate['checks'])&&is_array($known_gate['checks'])?$known_gate['checks']:array();
        $base['ok']=$ok;
        $base_technical_ok=$base_ok && (($base['technical_status']??'')==='TECHNICAL_CHECK_OK');
        $base['technical_status']=$base_technical_ok?'TECHNICAL_CHECK_OK':'BLOCKED_TECHNICAL_CHECK';
        $base['content_quality_status']=$ok?($base['content_quality_status']??'CONTENT_QUALITY_CHECK_OK'):'BLOCKED_CONTENT_QUALITY_CHECK';
        $base['errors']=$errors;
        $base['content_quality_errors']=array_merge(
            isset($base['content_quality_errors'])&&is_array($base['content_quality_errors'])?$base['content_quality_errors']:array(),
            isset($known_gate['errors'])&&is_array($known_gate['errors'])?$known_gate['errors']:array()
        );
        $base['checks']=array_merge($base_checks,array(
            'known_error_gate_status'=>$known_gate['known_error_gate_status']??'BLOCKED',
            'known_error_gate_checks'=>$known_checks,
            'fail_closed_aggregate_status'=>$ok?'PASS':'BLOCKED',
            'draft_create_allowed'=>false,
            'publish_allowed'=>false
        ));
        return $base;
    }


    public static function merge_content_validation_with_structure($base,$known_gate,$structure_gate,$context='content_validation_fail_closed_wave2') {
        $base=is_array($base)?$base:array();
        $known_gate=is_array($known_gate)?$known_gate:array();
        $structure_gate=is_array($structure_gate)?$structure_gate:array();
        $errors=array_merge(
            isset($base['errors'])&&is_array($base['errors'])?$base['errors']:array(),
            isset($known_gate['errors'])&&is_array($known_gate['errors'])?$known_gate['errors']:array(),
            isset($structure_gate['errors'])&&is_array($structure_gate['errors'])?$structure_gate['errors']:array()
        );
        $base_ok=isset($base['ok']) && $base['ok']===true;
        $known_ok=isset($known_gate['ok']) && $known_gate['ok']===true && ($known_gate['known_error_gate_status']??'')==='PASS';
        $structure_ok=isset($structure_gate['ok']) && $structure_gate['ok']===true && ($structure_gate['content_structure_language_gate_status']??'')==='PASS';
        $ok=$base_ok&&$known_ok&&$structure_ok&&!$errors;
        $base_checks=isset($base['checks'])&&is_array($base['checks'])?$base['checks']:array();
        $base['ok']=$ok;
        $base_technical_ok=$base_ok && (($base['technical_status']??'')==='TECHNICAL_CHECK_OK');
        $base['technical_status']=$base_technical_ok?'TECHNICAL_CHECK_OK':'BLOCKED_TECHNICAL_CHECK';
        $base['content_quality_status']=$ok?($base['content_quality_status']??'CONTENT_QUALITY_CHECK_OK'):'BLOCKED_CONTENT_QUALITY_CHECK';
        $base['errors']=$errors;
        $base['content_quality_errors']=array_merge(
            isset($base['content_quality_errors'])&&is_array($base['content_quality_errors'])?$base['content_quality_errors']:array(),
            isset($known_gate['errors'])&&is_array($known_gate['errors'])?$known_gate['errors']:array(),
            isset($structure_gate['errors'])&&is_array($structure_gate['errors'])?$structure_gate['errors']:array()
        );
        $base['checks']=array_merge($base_checks,array(
            'known_error_gate_status'=>$known_gate['known_error_gate_status']??'BLOCKED',
            'known_error_gate_checks'=>$known_gate['checks']??array(),
            'content_structure_language_gate_status'=>$structure_gate['content_structure_language_gate_status']??'BLOCKED',
            'content_structure_language_gate_checks'=>$structure_gate['checks']??array(),
            'fail_closed_aggregate_status'=>$ok?'PASS':'BLOCKED',
            'draft_create_allowed'=>false,
            'publish_allowed'=>false
        ));
        return $base;
    }

    public static function evaluate_release($statuses,$integrity=array(),$required_statuses=array(),$required_integrity=array()) {
        $statuses=is_array($statuses)?$statuses:array();
        $integrity=is_array($integrity)?$integrity:array();
        $required_statuses=is_array($required_statuses)?$required_statuses:array();
        $required_integrity=is_array($required_integrity)?$required_integrity:array();
        $errors=array();
        if (!$statuses) { $errors[]='STATUS_SET_MISSING'; }
        foreach ($required_statuses as $name) {
            if (!array_key_exists($name,$statuses)) { $errors[]='STATUS_MISSING:'.$name; }
        }
        foreach ($required_integrity as $name) {
            if (!array_key_exists($name,$integrity)) { $errors[]='INTEGRITY_MISSING:'.$name; }
        }
        foreach ($statuses as $name=>$status) {
            if (!in_array($status,self::ALLOWED_STATUSES,true)) { $errors[]='STATUS_INVALID:'.$name; continue; }
            if ($status!=='PASS') { $errors[]='STATUS_NOT_PASS:'.$name.':'.$status; }
        }
        foreach ($integrity as $name=>$value) {
            if ($value!==true) { $errors[]='INTEGRITY_NOT_TRUE:'.$name; }
        }
        $ok=!$errors;
        return array(
            'ok'=>$ok,
            'status'=>$ok?'PASS':'BLOCKED',
            'release_allowed'=>$ok,
            'draft_create_allowed'=>$ok,
            'publish_allowed'=>false,
            'errors'=>$errors,
            'checks'=>array('statuses'=>$statuses,'integrity'=>$integrity)
        );
    }

    public static function aggregate_item_results($items) {
        $statuses=array();
        $integrity=array();
        foreach ((array)$items as $index=>$item) {
            $prefix='item_'.$index;
            $statuses[$prefix.'_technical']=(($item['technical_status']??'')==='TECHNICAL_CHECK_OK')?'PASS':'BLOCKED';
            $statuses[$prefix.'_content']=(($item['content_quality_status']??'')==='CONTENT_QUALITY_CHECK_OK')?'PASS':'BLOCKED';
            $integrity[$prefix.'_content_hash']=isset($item['content_hash'])&&preg_match('/^[0-9a-f]{64}$/',(string)$item['content_hash'])===1;
            $integrity[$prefix.'_known_error_gate']=isset($item['checks']['known_error_gate_status'])&&$item['checks']['known_error_gate_status']==='PASS';
            $integrity[$prefix.'_content_structure_language_gate']=isset($item['checks']['content_structure_language_gate_status'])&&$item['checks']['content_structure_language_gate_status']==='PASS';
        }
        return self::evaluate_release($statuses,$integrity);
    }
}
