<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Portal_WP_Structure_Validator {
    const VERSION='6.7.9';
    const ARCHITECTURE_FILE='contracts/portal-wp-taxonomy-architecture-review-v1-1.json';
    const PORTAL_FILE='contracts/portal-structure-contract-v1.json';
    const WP_CONTRACT_FILE='contracts/wordpress-taxonomy-contract-v1.json';
    const WP_SNAPSHOT_FILE='contracts/wordpress-taxonomy-snapshot-v1.json';

    private static function err($code,$rule,$path,$expected,$actual,$reason,$context='portal_wp_architecture'){
        return PPM679_Diagnostic::error('BLOCKED_'.$code,$rule,$path,$expected,$actual,$reason,$context,'',__CLASS__,null,array(self::ARCHITECTURE_FILE,self::PORTAL_FILE,self::WP_CONTRACT_FILE,self::WP_SNAPSHOT_FILE));
    }
    private static function load_file($relative){$p=PPM679_PLUGIN_DIR.$relative;$d=is_file($p)?json_decode((string)file_get_contents($p),true):null;return is_array($d)?$d:null;}
    public static function portal_contract($override=null){return $override!==null?(is_array($override)?$override:null):self::load_file(self::PORTAL_FILE);}
    public static function wp_contract($override=null){return $override!==null?(is_array($override)?$override:null):self::load_file(self::WP_CONTRACT_FILE);}
    public static function wp_snapshot($override=null){return $override!==null?(is_array($override)?$override:null):self::load_file(self::WP_SNAPSHOT_FILE);}
    public static function architecture_contract($override=null){return $override!==null?(is_array($override)?$override:null):self::load_file(self::ARCHITECTURE_FILE);}
    private static function valid_self_hash($d){if(!is_array($d))return false;$h=(string)($d['contract_self_sha256']??'');$c=$d;unset($c['contract_self_sha256']);return $h!==''&&hash_equals($h,PPM679_Diagnostic::stable_hash($c));}
    private static function valid_snapshot_hash($d){if(!is_array($d))return false;$h=(string)($d['snapshot_sha256']??'');$c=$d;unset($c['snapshot_sha256'],$c['contract_self_sha256']);return $h!==''&&hash_equals($h,PPM679_Diagnostic::stable_hash($c));}

    public static function governance_errors(){
        $errors=array();$a=self::architecture_contract();$p=self::portal_contract();$w=self::wp_contract();$s=self::wp_snapshot();
        if(!is_array($a)||!self::valid_self_hash($a)){$errors[]=self::err('PORTAL_STRUCTURE_CONTRACT_UNBOUND','ARCHITECTURE_REVIEW_CONTRACT_MUST_EXIST_AND_BE_HASH_BOUND','architecture.contract','valid hash-bound contract',$a,'Der Architekturvertrag fehlt oder ist nicht hashgebunden.');return $errors;}
        $c=(array)($a['blocking_counters']??array());if(count($c)!==15){$errors[]=self::err('PORTAL_STRUCTURE_CONTRACT_UNBOUND','ARCHITECTURE_REVIEW_REQUIRES_ALL_15_COUNTERS','architecture.blocking_counters',15,count($c),'Die Architektur-Prüfinstanz enthält nicht alle 15 Sperrzähler.');}
        foreach($c as $name=>$value){if((int)$value!==0){$errors[]=self::err($name,'ALL_ARCHITECTURE_BLOCKING_COUNTERS_MUST_BE_ZERO','architecture.blocking_counters.'.$name,0,$value,'Ein Architektur-Sperrzähler ist nicht null.');}}
        $errors=array_merge($errors,self::validate_portal_contract($p),self::validate_wp_taxonomy_contract($w),self::validate_wp_snapshot($s,$w));
        return $errors;
    }
    public static function validate_portal_contract($p){
        $e=array();if(!is_array($p)||!self::valid_self_hash($p)||!self::valid_snapshot_hash($p)){return array(self::err('PORTAL_STRUCTURE_CONTRACT_UNBOUND','PORTAL_STRUCTURE_CONTRACT_MUST_EXIST_AND_BE_HASH_BOUND','portal_structure','valid portal contract',$p,'Der Portalstrukturvertrag fehlt oder ist ungültig.'));}
        foreach(array('portal_id','target_assignable_portal_level','allowed_node_types','control_assignment') as $f){if(!array_key_exists($f,$p)||$p[$f]===''||$p[$f]===array())$e[]=self::err('PORTAL_STRUCTURE_CONTRACT_UNBOUND','PORTAL_STRUCTURE_CONTRACT_REQUIRES_ALL_FIELDS','portal_structure.'.$f,'present',$p[$f]??null,'Ein Pflichtfeld des Portalstrukturvertrags fehlt.');}
        if(($p['portal_path_must_not_be_used_as_wp_parent_chain']??null)!==true||($p['portal_level_must_not_be_used_as_wp_taxonomy_depth']??null)!==true)$e[]=self::err('PORTAL_WP_STRUCTURE_FIELDS_CONFLATED','PORTAL_AND_WORDPRESS_STRUCTURES_MUST_BE_SEPARATE','portal_structure.separation',true,array($p['portal_path_must_not_be_used_as_wp_parent_chain']??null,$p['portal_level_must_not_be_used_as_wp_taxonomy_depth']??null),'Die Trennung beider Strukturarten ist nicht verbindlich.');
        if(($p['automatic_category_migration_allowed']??null)!==false)$e[]=self::err('CATEGORY_MIGRATION_UNAUTHORIZED','AUTOMATIC_CATEGORY_MIGRATION_MUST_BE_FORBIDDEN','portal_structure.automatic_category_migration_allowed',false,$p['automatic_category_migration_allowed']??null,'Eine automatische Migration ist unzulässig.');
        return $e;
    }
    public static function validate_wp_taxonomy_contract($w){
        $e=array();
        if(!is_array($w)||!self::valid_self_hash($w)||!self::valid_snapshot_hash($w)){return array(self::err('WP_TAXONOMY_CONTRACT_UNBOUND','WP_TAXONOMY_CONTRACT_MUST_EXIST_PARSE_AND_MATCH_HASH','wp_taxonomy_contract','valid hash-bound contract',$w,'Der WordPress-Taxonomievertrag fehlt, ist unparsebar oder hashwidrig.'));}
        foreach(array('portal_id','taxonomy','targets','required_target_fields','snapshot_sha256') as $f){if(!array_key_exists($f,$w)||$w[$f]===''||$w[$f]===array())$e[]=self::err('WP_TAXONOMY_CONTRACT_UNBOUND','WP_TAXONOMY_CONTRACT_REQUIRES_ALL_FIELDS','wp_taxonomy_contract.'.$f,'present',$w[$f]??null,'Ein Pflichtfeld des WordPress-Taxonomievertrags fehlt.');}
        foreach((array)($w['targets']??array()) as $slug=>$t){foreach((array)($w['required_target_fields']??array()) as $f){if(!array_key_exists($f,(array)$t))$e[]=self::err('WP_TAXONOMY_CONTRACT_UNBOUND','EVERY_WP_TAXONOMY_TARGET_REQUIRES_ALL_FIELDS','wp_taxonomy_contract.targets.'.$slug.'.'.$f,'present',$t[$f]??null,'Ein Pflichtfeld eines WordPress-Taxonomieziels fehlt.');}if(!is_bool($t['wp_parent_chain_required']??null))$e[]=self::err('WP_PARENT_REQUIREMENT_UNDECLARED','WP_PARENT_CHAIN_REQUIREMENT_MUST_BE_BOOLEAN','wp_taxonomy_contract.targets.'.$slug.'.wp_parent_chain_required','boolean',$t['wp_parent_chain_required']??null,'Die Elternkettenpflicht ist nicht eindeutig erklärt.');if(!is_array($t['expected_wp_parent_slugs']??null)||!is_int($t['expected_wp_taxonomy_depth']??null))$e[]=self::err('WP_TAXONOMY_CONTRACT_UNBOUND','WP_TAXONOMY_TARGET_TYPES_MUST_MATCH','wp_taxonomy_contract.targets.'.$slug,'array parents and integer depth',$t,'Der Zielvertrag enthält widersprüchliche Typen.');}
        if(($w['portal_path_derivation_forbidden']??null)!==true)$e[]=self::err('WP_PARENT_CHAIN_DERIVED_FROM_PORTAL_PATH','WP_PARENT_CHAIN_MUST_NOT_BE_DERIVED_FROM_PORTAL_PATH','wp_taxonomy_contract.portal_path_derivation_forbidden',true,$w['portal_path_derivation_forbidden']??null,'Die Ableitung aus dem Portalpfad ist nicht verboten.');
        if(($w['portal_level_depth_derivation_forbidden']??null)!==true)$e[]=self::err('WP_TAXONOMY_DEPTH_DERIVED_FROM_PORTAL_LEVEL','WP_DEPTH_MUST_NOT_BE_DERIVED_FROM_PORTAL_LEVEL','wp_taxonomy_contract.portal_level_depth_derivation_forbidden',true,$w['portal_level_depth_derivation_forbidden']??null,'Die Ableitung der Taxonomietiefe aus der Portalebene ist nicht verboten.');
        if(($w['automatic_category_migration_allowed']??null)!==false)$e[]=self::err('CATEGORY_MIGRATION_UNAUTHORIZED','AUTOMATIC_CATEGORY_MIGRATION_MUST_BE_FORBIDDEN','wp_taxonomy_contract.automatic_category_migration_allowed',false,$w['automatic_category_migration_allowed']??null,'Eine automatische Kategorieumhängung ist unzulässig.');
        return $e;
    }
    public static function validate_wp_snapshot($s,$w=null){
        $e=array();$w=$w?:self::wp_contract();if(!is_array($s)||!self::valid_self_hash($s)||!self::valid_snapshot_hash($s)){return array(self::err('FIXTURE_TOPOLOGY_NOT_LIVE_BOUND','WP_TAXONOMY_SNAPSHOT_MUST_EXIST_AND_BE_HASH_BOUND','wp_taxonomy_snapshot','valid snapshot',$s,'Der WordPress-Taxonomie-Snapshot fehlt oder ist nicht hashgebunden.'));}
        if((string)($s['fixture_class']??'')!=='REAL_SNAPSHOT_DERIVED')$e[]=self::err('SYNTHETIC_FIXTURE_USED_AS_LIVE_EQUIVALENT','LIVE_COMPATIBILITY_REQUIRES_REAL_SNAPSHOT_DERIVED_FIXTURE','wp_taxonomy_snapshot.fixture_class','REAL_SNAPSHOT_DERIVED',$s['fixture_class']??null,'Eine synthetische Fixture darf keinen realen Live-Zustand belegen.');
        if((string)($s['portal_id']??'')!==(string)($w['portal_id']??'')||(string)($s['taxonomy']??'')!==(string)($w['taxonomy']??''))$e[]=self::err('FIXTURE_TOPOLOGY_NOT_LIVE_BOUND','WP_SNAPSHOT_MUST_MATCH_CONTRACT_PORTAL_AND_TAXONOMY','wp_taxonomy_snapshot.binding',array($w['portal_id']??null,$w['taxonomy']??null),array($s['portal_id']??null,$s['taxonomy']??null),'Snapshot und Vertrag gehören nicht zum selben Portal oder zur selben Taxonomie.');
        return $e;
    }
    public static function target_for_slug($slug,$w=null){$w=$w?:self::wp_contract();return is_array($w['targets'][$slug]??null)?$w['targets'][$slug]:null;}
    public static function validate_editorial_binding($binding,$category_entry=null){
        $binding=is_array($binding)?$binding:array();$e=self::governance_errors();
        $required=array('name','slug','hierarchy_path','portal_path','portal_level','portal_node_types','taxonomy','article_type','category_source_snapshot_hash','portal_structure_snapshot_hash','wp_taxonomy_contract_hash','wp_taxonomy_snapshot_hash','wp_parent_chain_required','expected_wp_parent_slugs','expected_wp_taxonomy_depth');
        foreach($required as $f){if(!array_key_exists($f,$binding)||$binding[$f]===''||$binding[$f]===array()&&$f!=='expected_wp_parent_slugs')$e[]=self::err('PORTAL_STRUCTURE_CONTRACT_UNBOUND','EDITORIAL_CATEGORY_BINDING_REQUIRES_SEPARATE_PORTAL_AND_WP_FIELDS','category_binding.'.$f,'present',$binding[$f]??null,'Die getrennte Portal-/WordPress-Bindung ist unvollständig.');}
        if((string)($binding['portal_path']??'')!==(string)($binding['hierarchy_path']??''))$e[]=self::err('PORTAL_WP_STRUCTURE_FIELDS_CONFLATED','LEGACY_HIERARCHY_PATH_MUST_ALIAS_PORTAL_PATH_ONLY','category_binding.hierarchy_path',$binding['portal_path']??null,$binding['hierarchy_path']??null,'Das Legacyfeld hierarchy_path darf nur den Portalpfad spiegeln.');
        $portal=self::portal_contract();$wp=self::wp_contract();$wps=self::wp_snapshot();
        if(!hash_equals((string)($portal['snapshot_sha256']??''),(string)($binding['portal_structure_snapshot_hash']??'')))$e[]=self::err('PORTAL_STRUCTURE_CONTRACT_UNBOUND','CATEGORY_BINDING_MUST_MATCH_PORTAL_STRUCTURE_SNAPSHOT','category_binding.portal_structure_snapshot_hash',$portal['snapshot_sha256']??null,$binding['portal_structure_snapshot_hash']??null,'Die Portalstrukturbindung ist veraltet oder fremd.');
        $wp_hash=is_file(PPM679_PLUGIN_DIR.self::WP_CONTRACT_FILE)?hash_file('sha256',PPM679_PLUGIN_DIR.self::WP_CONTRACT_FILE):'';
        if($wp_hash===''||!hash_equals($wp_hash,(string)($binding['wp_taxonomy_contract_hash']??'')))$e[]=self::err('WP_TAXONOMY_CONTRACT_UNBOUND','CATEGORY_BINDING_MUST_MATCH_ACTIVE_WP_TAXONOMY_CONTRACT','category_binding.wp_taxonomy_contract_hash',$wp_hash,$binding['wp_taxonomy_contract_hash']??null,'Die WordPress-Taxonomievertragsbindung fehlt oder weicht ab.');
        if(!hash_equals((string)($wps['snapshot_sha256']??''),(string)($binding['wp_taxonomy_snapshot_hash']??'')))$e[]=self::err('FIXTURE_TOPOLOGY_NOT_LIVE_BOUND','CATEGORY_BINDING_MUST_MATCH_REAL_WP_SNAPSHOT','category_binding.wp_taxonomy_snapshot_hash',$wps['snapshot_sha256']??null,$binding['wp_taxonomy_snapshot_hash']??null,'Die WordPress-Snapshotbindung fehlt oder ist veraltet.');
        $target=self::target_for_slug((string)($binding['slug']??''),$wp);
        if(!is_array($target))$e[]=self::err('WP_TAXONOMY_CONTRACT_UNBOUND','CATEGORY_BINDING_MUST_RESOLVE_IN_WP_TAXONOMY_CONTRACT','category_binding.slug','unique target',$binding['slug']??null,'Für die Zielkategorie fehlt ein WordPress-Taxonomievertrag.');
        else{foreach(array('wp_taxonomy'=>'taxonomy','wp_term_slug'=>'slug','wp_term_name'=>'name','wp_parent_chain_required'=>'wp_parent_chain_required','expected_wp_parent_slugs'=>'expected_wp_parent_slugs','expected_wp_taxonomy_depth'=>'expected_wp_taxonomy_depth') as $tf=>$bf){if(($target[$tf]??null)!==($binding[$bf]??null))$e[]=self::err('PORTAL_WP_STRUCTURE_FIELDS_CONFLATED','EDITORIAL_BINDING_MUST_MATCH_SEPARATE_WP_TARGET_CONTRACT','category_binding.'.$bf,$target[$tf]??null,$binding[$bf]??null,'Die WordPress-Strukturbindung stimmt nicht mit dem separaten Vertrag überein.');}}
        if(is_array($category_entry)){if((int)($binding['portal_level']??0)!==(int)($category_entry['portal_level']??0)||(string)($binding['portal_path']??'')!==(string)($category_entry['portal_path']??''))$e[]=self::err('PORTAL_STRUCTURE_CONTRACT_UNBOUND','EDITORIAL_BINDING_MUST_MATCH_PORTAL_CATEGORY_ENTRY','category_binding.portal',array($category_entry['portal_level']??null,$category_entry['portal_path']??null),array($binding['portal_level']??null,$binding['portal_path']??null),'Die Portalstrukturbindung stimmt nicht mit dem Kategorien-Snapshot überein.');}
        return $e;
    }
    public static function validate_live_term($term,$binding){
        $term=is_array($term)?$term:array();$binding=is_array($binding)?$binding:array();$e=self::validate_editorial_binding($binding);
        foreach(array('name','slug','taxonomy') as $f){if((string)($term[$f]??'')!==(string)($binding[$f]??''))$e[]=self::err('WP_PARENT_CHAIN_MISMATCH','LIVE_TERM_IDENTITY_MUST_MATCH_WP_CONTRACT','live_term.'.$f,$binding[$f]??null,$term[$f]??null,'Der live aufgelöste Term stimmt nicht mit dem WordPress-Vertrag überein.','category_live_resolution');}
        $parents=array_values((array)($term['parent_chain_slugs']??array()));$expected=array_values((array)($binding['expected_wp_parent_slugs']??array()));$depth=(int)($term['taxonomy_depth']??$term['level']??0);$wanted=(int)($binding['expected_wp_taxonomy_depth']??0);
        if(($binding['wp_parent_chain_required']??null)===true&&$parents!==$expected)$e[]=self::err('WP_PARENT_CHAIN_MISMATCH','LIVE_WP_PARENT_CHAIN_MUST_MATCH_EXPLICIT_CONTRACT','live_term.parent_chain_slugs',$expected,$parents,'Die reale WordPress-Elternkette weicht vom ausdrücklichen Vertrag ab.','category_live_resolution');
        if(($binding['wp_parent_chain_required']??null)===false&&$expected===array()&&$parents!==array())$e[]=self::err('WP_PARENT_CHAIN_MISMATCH','FLAT_WP_TERM_CONTRACT_REQUIRES_NO_PARENT_CHAIN','live_term.parent_chain_slugs',array(),$parents,'Der Vertrag verlangt einen flachen WordPress-Term.','category_live_resolution');
        if($depth!==$wanted)$e[]=self::err('WP_TAXONOMY_DEPTH_MISMATCH','LIVE_WP_TAXONOMY_DEPTH_MUST_MATCH_EXPLICIT_CONTRACT','live_term.taxonomy_depth',$wanted,$depth,'Die reale WordPress-Taxonomietiefe weicht vom ausdrücklichen Vertrag ab.','category_live_resolution');
        if(($binding['wp_parent_chain_required']??null)===false&&$depth===1&&$parents===array()){/* explicitly valid flat term */}
        elseif(($binding['wp_parent_chain_required']??null)===false&&$wanted===1&&$depth!==1)$e[]=self::err('WP_FLAT_TERM_REJECTED_WITHOUT_CONTRACT_REASON','FLAT_TERM_CONTRACT_MUST_BE_HONOURED','live_term.taxonomy_depth',1,$depth,'Ein ausdrücklich flacher Zielterm wurde nicht als flach validiert.','category_live_resolution');
        return $e;
    }
    public static function runtime_snapshot($term){$term=is_array($term)?$term:array();$s=array('contract'=>'PPM679_RUNTIME_WORDPRESS_TAXONOMY_SNAPSHOT_V1','portal_id'=>'pferde-atelier','captured_at'=>gmdate('c'),'capture_mode'=>'READ_ONLY_RUNTIME','fixture_class'=>'REAL_SNAPSHOT_DERIVED','term'=>array_intersect_key($term,array_flip(array('term_id','taxonomy','slug','name','parent','parent_chain_slugs','parent_chain_names','taxonomy_depth'))),'wordpress_write_performed'=>false);$s['snapshot_sha256']=PPM679_Diagnostic::stable_hash($s);return $s;}
}
