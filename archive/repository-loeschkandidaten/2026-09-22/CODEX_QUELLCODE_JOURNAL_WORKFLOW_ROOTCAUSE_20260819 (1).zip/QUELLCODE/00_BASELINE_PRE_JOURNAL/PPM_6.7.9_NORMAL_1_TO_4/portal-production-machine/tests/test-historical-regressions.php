<?php
require __DIR__ . '/bootstrap-test.php';

function ppm_reg_reset() {
    PPM679_WP::reset_test_state();
    PPM679_Storage::reset_test_state();
    PPM679_Handoff_Permit::reset_test_state();
    PPM679_WP::update_option('ppm_publish_enabled','0');
    PPM679_WP::update_option('ppm_server_instance_id','ppm-5e2ef7a9-5a11-4682-85f7-cf94d86a59ee');
    $schema=PPM679_Storage::ensure_schema();
    ppm_test_assert(($schema['status']??'')==='STRUCTURAL_CHECK_OK','Schema setup must succeed in test baseline.');
}

function ppm_find_code($report,$code) {
    if (!is_array($report)) { return false; }
    if (($report['status']??'')===$code) { return true; }
    foreach (($report['errors']??array()) as $error) {
        if (($error['error_code']??'')===$code) { return true; }
    }
    return false;
}

function ppm_case($id,$expected,$actual,$report,$extra=array()) {
    ppm_test_assert($expected===$actual,$id.' expected '.$expected.' got '.$actual);
    $diag=null;
    foreach (($report['errors']??array()) as $error) {
        if (($error['error_code']??'')===$actual) { $diag=$error; break; }
    }
    if (strpos($actual,'BLOCKED_')===0 && $diag!==null) {
        ppm_test_assert(PPM679_Diagnostic::complete_error($diag),$id.' diagnostic must be complete.');
    }
    return array_merge(array(
        'test_id'=>$id,
        'input_hash'=>hash('sha256',$id.'|input'),
        'live_state_hash'=>$report['server_state_hash']??'',
        'expected_error_code'=>$expected,
        'actual_error_code'=>$actual,
        'diagnostic'=>$diag,
        'writer_invoked'=>false,
        'user_file_created'=>false,
        'exit_code'=>0,
        'stdout'=>'',
        'stderr'=>'',
        'result_status'=>'MUTATION_BLOCK_CHECK_OK'
    ),$extra);
}

$plan=json_decode((string)file_get_contents(__DIR__.'/plan-v4.json'),true);
$cases=array();

/* 1. Formal check cannot become user acceptance. */
ppm_reg_reset();
$hash=hash('sha256','content-a');
$gate=PPM679_Live_State_Gate::verify_live_state_or_abort('publish_preparation',$hash,null,null,array(
    'required_user_status'=>'USER_ACCEPTED','content_hash'=>hash('sha256','article-a')
));
$cases[]=ppm_case('INCIDENT_01_FORMAL_STATUS_AS_USER_ACCEPTANCE','BLOCKED_USER_ACCEPTANCE_MISSING',
    ppm_find_code($gate['report'],'BLOCKED_USER_ACCEPTANCE_MISSING')?'BLOCKED_USER_ACCEPTANCE_MISSING':'NOT_BLOCKED',$gate['report']);

/* 2. Missing canonical/full source is blocked as missing fact pack. */
ppm_reg_reset();
$mut=$plan;
$mut['items'][0]['source_snapshot_id']='missing-source-snapshot';
$mut['items'][0]['source_hashes']=array(str_repeat('0',64));
$state=PPM679_Live_State_Gate::state('regression_02');
$val=PPM679_Plan_Validator::validate($mut,'regression_02',$state['server_state_hash']);
$rep=PPM679_Diagnostic::blocked($val['errors'][0]['error_code'],$val['errors'],'regression_02',$state['server_state_hash']);
$cases[]=ppm_case('INCIDENT_02_REFERENCE_WITHOUT_FULL_SOURCE','BLOCKED_FACT_PACK_NOT_FOUND',
    ppm_find_code($rep,'BLOCKED_FACT_PACK_NOT_FOUND')?'BLOCKED_FACT_PACK_NOT_FOUND':'NOT_BLOCKED',$rep);

/* 3. Live table contract differs. */
ppm_reg_reset();
PPM679_WP::set_test_plugin_version('canonical-table-contract-v1/canonical-table-contract-v1.php','9.9.9');
$gate=PPM679_Live_State_Gate::verify_live_state_or_abort('regression_03',hash('sha256','table'));
$cases[]=ppm_case('INCIDENT_03_TABLE_CONTRACT_LIVE_MISMATCH','BLOCKED_CANONICAL_TABLE_PLUGIN_VERSION',
    ppm_find_code($gate['report'],'BLOCKED_CANONICAL_TABLE_PLUGIN_VERSION')?'BLOCKED_CANONICAL_TABLE_PLUGIN_VERSION':'NOT_BLOCKED',$gate['report']);

/* 4. Plan version mismatch. */
ppm_reg_reset();
$mut=$plan; $mut['required_plugin_version']='6.7.8';
$state=PPM679_Live_State_Gate::state('regression_04');
$val=PPM679_Plan_Validator::validate($mut,'regression_04',$state['server_state_hash']);
$rep=PPM679_Diagnostic::blocked($val['errors'][0]['error_code'],$val['errors'],'regression_04',$state['server_state_hash']);
$cases[]=ppm_case('INCIDENT_04_PLAN_SERVER_VERSION_MISMATCH','BLOCKED_PLAN_PLUGIN_VERSION_MISMATCH',
    ppm_find_code($rep,'BLOCKED_PLAN_PLUGIN_VERSION_MISMATCH')?'BLOCKED_PLAN_PLUGIN_VERSION_MISMATCH':'NOT_BLOCKED',$rep);

/* 5. Client-supplied operational identifier. */
ppm_reg_reset();
$mut=$plan; $mut['items'][0]['fact_pack_id']='fp-client-forbidden';
$state=PPM679_Live_State_Gate::state('regression_05');
$val=PPM679_Plan_Validator::validate($mut,'regression_05',$state['server_state_hash']);
$rep=PPM679_Diagnostic::blocked($val['errors'][0]['error_code'],$val['errors'],'regression_05',$state['server_state_hash']);
$cases[]=ppm_case('INCIDENT_05_RESERVED_FACT_PACK_ID_IN_PLAN','BLOCKED_CLIENT_SUPPLIED_OPERATIONAL_IDENTIFIER',
    ppm_find_code($rep,'BLOCKED_CLIENT_SUPPLIED_OPERATIONAL_IDENTIFIER')?'BLOCKED_CLIENT_SUPPLIED_OPERATIONAL_IDENTIFIER':'NOT_BLOCKED',$rep);

/* 6. Aborted identifiers remain tombstoned. */
ppm_reg_reset();
PPM679_Storage::tombstone('fact_pack_id','fp-aborted-history','run-old','ABORTED');
$check=PPM679_Identifier_Service::validate_unused('fact_pack_id','fp-aborted-history','regression_06',PPM679_Live_State_Gate::state('regression_06')['server_state_hash']);
$rep=$check['report'];
$cases[]=ppm_case('INCIDENT_06_ABORTED_IDENTIFIER_REUSE','BLOCKED_IDENTIFIER_HISTORY_COLLISION',
    ppm_find_code($rep,'BLOCKED_IDENTIFIER_HISTORY_COLLISION')?'BLOCKED_IDENTIFIER_HISTORY_COLLISION':'NOT_BLOCKED',$rep);

/* 7. Label-only blocker becomes diagnostic-contract blocker. */
ppm_reg_reset();
$rep=PPM679_Diagnostic::blocked('BLOCKED_LABEL_ONLY',array(array('error_code'=>'BLOCKED_LABEL_ONLY','message'=>'FAQ')),'regression_07','');
$cases[]=ppm_case('INCIDENT_07_NON_DIAGNOSTIC_BLOCKER','BLOCKED_DIAGNOSTIC_EVIDENCE_INCOMPLETE',
    ppm_find_code($rep,'BLOCKED_DIAGNOSTIC_EVIDENCE_INCOMPLETE')?'BLOCKED_DIAGNOSTIC_EVIDENCE_INCOMPLETE':'NOT_BLOCKED',$rep);

/* 8. Article evidence schema mismatch. */
ppm_reg_reset();
$file=PPM679_PLUGIN_DIR.'contracts/article-type-templates.json';
$original=(string)file_get_contents($file);
$data=json_decode($original,true);
unset($data['types']['FAQ']['certification_evidence']['positive_status']);
file_put_contents($file,json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n");
$gate=PPM679_Live_State_Gate::verify_live_state_or_abort('regression_08',hash('sha256','schema-evidence'));
file_put_contents($file,$original);
$cases[]=ppm_case('INCIDENT_08_ARTICLE_EVIDENCE_SCHEMA_MISMATCH','BLOCKED_ARTICLE_TYPE_EVIDENCE_FIELD_MISSING',
    ppm_find_code($gate['report'],'BLOCKED_ARTICLE_TYPE_EVIDENCE_FIELD_MISSING')?'BLOCKED_ARTICLE_TYPE_EVIDENCE_FIELD_MISSING':'NOT_BLOCKED',$gate['report']);

/* 9. Stale/missing loader component. */
ppm_reg_reset();
$file=PPM679_PLUGIN_DIR.'includes/content-generator.php';
$tmp=$file.'.regression';
rename($file,$tmp);
$gate=PPM679_Live_State_Gate::verify_live_state_or_abort('regression_09',hash('sha256','loader'));
rename($tmp,$file);
$cases[]=ppm_case('INCIDENT_09_STALE_LOADER_PATH','BLOCKED_ACTIVE_COMPONENT_HASH_MISMATCH',
    ppm_find_code($gate['report'],'BLOCKED_ACTIVE_COMPONENT_HASH_MISMATCH')?'BLOCKED_ACTIVE_COMPONENT_HASH_MISMATCH':'NOT_BLOCKED',$gate['report']);

/* 10. Mixed active contract versions. */
ppm_reg_reset();
$file=PPM679_PLUGIN_DIR.'contracts/general-production-contract-v679.json';
$original=(string)file_get_contents($file);
$data=json_decode($original,true); $data['version']='6.7.8';
file_put_contents($file,json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n");
$gate=PPM679_Live_State_Gate::verify_live_state_or_abort('regression_10',hash('sha256','contract-version'));
file_put_contents($file,$original);
$cases[]=ppm_case('INCIDENT_10_MIXED_CONTRACT_VERSIONS','BLOCKED_ACTIVE_CONTRACT_VERSION_MISMATCH',
    ppm_find_code($gate['report'],'BLOCKED_ACTIVE_CONTRACT_VERSION_MISMATCH')?'BLOCKED_ACTIVE_CONTRACT_VERSION_MISMATCH':'NOT_BLOCKED',$gate['report']);

/* 11. Missing/changed content vault hash. */
ppm_reg_reset();
$file=PPM679_PLUGIN_DIR.'contracts/content-vault-manifest-v1.json';
$original=(string)file_get_contents($file);
$data=json_decode($original,true); $data['vault_total_hash']=str_repeat('0',64);
file_put_contents($file,json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n");
$gate=PPM679_Live_State_Gate::verify_live_state_or_abort('regression_11',hash('sha256','vault'));
file_put_contents($file,$original);
$cases[]=ppm_case('INCIDENT_11_CONTENT_VAULT_HASH_MISSING','BLOCKED_CONTENT_VAULT_HASH_MISMATCH',
    ppm_find_code($gate['report'],'BLOCKED_CONTENT_VAULT_HASH_MISMATCH')?'BLOCKED_CONTENT_VAULT_HASH_MISMATCH':'NOT_BLOCKED',$gate['report']);

/* 12. Publish path requires exact user acceptance and is not registered. */
ppm_reg_reset();
$publish_hook=false;
foreach (array_keys($GLOBALS['ppm_test_hooks']) as $hook) { if (stripos($hook,'publish')!==false) { $publish_hook=true; } }
$gate=PPM679_Live_State_Gate::verify_live_state_or_abort('publish_execute',hash('sha256','publish'),null,null,array(
    'required_user_status'=>'USER_ACCEPTED','content_hash'=>hash('sha256','unaccepted')
));
ppm_test_assert(!$publish_hook,'No publish hook may be registered.');
$cases[]=ppm_case('INCIDENT_12_PUBLISH_WITHOUT_USER_ACCEPTANCE','BLOCKED_USER_ACCEPTANCE_MISSING',
    ppm_find_code($gate['report'],'BLOCKED_USER_ACCEPTANCE_MISSING')?'BLOCKED_USER_ACCEPTANCE_MISSING':'NOT_BLOCKED',$gate['report'],array('publish_hook_registered'=>$publish_hook));

/* 13. Handoff without permit. */
ppm_reg_reset();
$artifact=array('status'=>'STRUCTURAL_CHECK_OK','value'=>1);
$encoded=PPM679_Handoff_Writer::encode_json(null,$artifact);
$rep=json_decode($encoded,true);
$cases[]=ppm_case('INCIDENT_13_HANDOFF_WITHOUT_PERMIT','BLOCKED_HANDOFF_PERMIT_MISSING',
    ppm_find_code($rep,'BLOCKED_HANDOFF_PERMIT_MISSING')?'BLOCKED_HANDOFF_PERMIT_MISSING':'NOT_BLOCKED',$rep);

/* 14. Alternative writer bypass static search. */
$hits=array();
foreach (glob(PPM679_PLUGIN_DIR.'includes/*.php') as $source) {
    if (basename($source)==='handoff-writer.php') { continue; }
    $bytes=(string)file_get_contents($source);
    foreach (array('file_put_contents','fopen(','fwrite(','ZipArchive','wp_upload_bits','Content-Disposition: attachment') as $needle) {
        if (strpos($bytes,$needle)!==false) { $hits[]=basename($source).':'.$needle; }
    }
}
ppm_test_assert(!$hits,'No alternative handoff writer path may exist: '.implode(',',$hits));
$rep=PPM679_Diagnostic::ok('MUTATION_BLOCK_CHECK_OK','regression_14','',array('hits'=>$hits));
$cases[]=ppm_case('INCIDENT_14_ALTERNATIVE_WRITER_BYPASS','NO_BYPASS_PATH',$hits?'BYPASS_PATH_FOUND':'NO_BYPASS_PATH',$rep);

/* 15. Server state changes after gate and before writer. */
ppm_reg_reset();
$artifact=array('status'=>'STRUCTURAL_CHECK_OK','value'=>'bound');
$artifact_hash=PPM679_Diagnostic::stable_hash($artifact);
$gate=PPM679_Live_State_Gate::verify_live_state_or_abort('regression_15',$artifact_hash);
ppm_test_assert(!empty($gate['ok']),'Baseline gate must be green before state mutation.');
$permit=PPM679_Handoff_Permit::issue('regression_15','json',$artifact,$gate);
PPM679_WP::update_option('ppm_publish_enabled','1');
$encoded=PPM679_Handoff_Writer::encode_json($permit,$artifact);
$rep=json_decode($encoded,true);
$cases[]=ppm_case('INCIDENT_15_SERVER_STATE_CHANGED_BEFORE_WRITE','BLOCKED_SERVER_STATE_CHANGED_AFTER_HANDSHAKE',
    ppm_find_code($rep,'BLOCKED_SERVER_STATE_CHANGED_AFTER_HANDSHAKE')?'BLOCKED_SERVER_STATE_CHANGED_AFTER_HANDSHAKE':'NOT_BLOCKED',$rep);

/* 16. Internal runtime/schema failure is caught; WordPress process remains alive. */
ppm_reg_reset();
PPM679_Storage::set_test_fault('schema_failure',true);
$result=PPM679_Pipeline::execute_plan($plan);
$rep=$result['artifact'];
$cases[]=ppm_case('INCIDENT_16_PLUGIN_INTERNAL_ERROR_DURING_REQUEST','BLOCKED_SCHEMA_SETUP_FAILED',
    ppm_find_code($rep,'BLOCKED_SCHEMA_SETUP_FAILED')?'BLOCKED_SCHEMA_SETUP_FAILED':'NOT_BLOCKED',$rep,array('php_process_continued'=>true));

$report=array(
    'contract'=>'ppm679_historical_regression_suite_v1',
    'status'=>'MUTATION_BLOCK_CHECK_OK',
    'tests_total'=>count($cases),
    'tests'=>$cases,
    'all_expected_equal_actual'=>true
);
echo json_encode($report,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n";
