<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';
$errors=PPM679_Build_Integrity::verify('generator_restore_build','local-state-hash');
if ($errors) { fwrite(STDERR,json_encode($errors,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n"); exit(2); }
echo json_encode(array('status'=>'PASS','manifest_sha256'=>hash_file('sha256',dirname(__DIR__).'/certification/build-manifest-v1.json')),JSON_UNESCAPED_UNICODE)."\n";
