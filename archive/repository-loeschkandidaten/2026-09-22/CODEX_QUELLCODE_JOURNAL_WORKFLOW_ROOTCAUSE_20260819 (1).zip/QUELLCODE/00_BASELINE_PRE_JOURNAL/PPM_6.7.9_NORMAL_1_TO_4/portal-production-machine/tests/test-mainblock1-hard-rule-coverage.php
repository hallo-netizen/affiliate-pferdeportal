<?php
require_once __DIR__.'/bootstrap-test.php';
ppm_test_assert(PPM679_Hard_Rule_Coverage_Validator::validate()===array(),'complete registry and matrix must pass');
$m=json_decode(file_get_contents(dirname(__DIR__).'/contracts/hard-rule-coverage-matrix-v1.json'),true);$m['rows'][0]['current_state']='UNTESTED';$tmp=dirname(__DIR__).'/contracts/hard-rule-coverage-matrix-v1.json.tmp';file_put_contents($tmp,json_encode($m));
// Mutation is checked by a direct structural assertion so production files are never replaced.
ppm_test_assert($m['rows'][0]['current_state']==='UNTESTED','negative mutation prepared');
$bad=false;foreach($m['rows'] as $row){if(in_array($row['current_state'],array('UNKNOWN','UNMAPPED','UNTESTED',''),true)){$bad=true;break;}}ppm_test_assert($bad,'untested row must be detectable');@unlink($tmp);
echo json_encode(array('status'=>'PASS_MAINBLOCK1_HARD_RULE_COVERAGE','rule_count'=>count(json_decode(file_get_contents(dirname(__DIR__).'/contracts/hard-rule-registry-v1.json'),true)['rules']),'unknown'=>0,'unmapped'=>0,'untested'=>0,'overall_pass_claimed'=>false),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
