<?php
require __DIR__.'/bootstrap-three-type.php';
$errors=PPM679_Three_Type_Bundled_Release_Validator::validate(PPM679_Three_Type_Bundled_Release_Validator::ACTION_CONTEXT,ppm_three_scope());
ppm_test_assert($errors===array(),'exact signed-quarantine three-type release gate must pass');
$global=PPM679_Article_Type_Validator::validate('three_type_global_regression','state');
$codes=array_column($global,'error_code');
ppm_test_assert(count(array_filter($codes,fn($c)=>$c==='BLOCKED_ARTICLE_TYPE_NOT_PRODUCTION_ALLOWED'))===4,'all four global types must remain quarantined');
echo json_encode(['status'=>'PASS_THREE_TYPE_SIGNED_QUARANTINE_RELEASE_GATE_POSITIVE','scoped_errors'=>0,'global_quarantine_count'=>4,'signing_performed'=>true,'publish_allowed'=>false],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
