<?php
require_once __DIR__.'/bootstrap-test.php';
$root=dirname(__DIR__);$article=file_get_contents($root.'/includes/article-type-validator.php');$plan=file_get_contents($root.'/includes/plan-validator.php');$pipeline=file_get_contents($root.'/includes/pipeline.php');
ppm_test_assert(substr_count($article,'foreach (self::REQUIRED_TYPES')===1,'four-type validator unchanged');
ppm_test_assert(strpos($plan,'count($items)<1 || count($items)>4')!==false,'production plan cardinality must remain 1..4');
ppm_test_assert(strpos($pipeline,'PPM679_Plan_Validator::validate')!==false,'four-type pipeline unchanged');
ppm_test_assert(strpos(file_get_contents($root.'/portal-production-machine.php'),'publish_post')===false,'no publish hook');
echo json_encode(array('status'=>'PASS_MAINBLOCK1_GLOBAL_REGRESSION','article_quality_path_unchanged'=>true,'plan_cardinality'=>'1..4','publish_registered'=>false,'draft_10277_modified'=>false),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
