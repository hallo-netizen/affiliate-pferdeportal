<?php
require __DIR__.'/bootstrap-three-type.php';
$r=PPM679_Three_Type_Bundled_Local_Preflight::run(ppm_three_scope());
ppm_test_assert(!empty($r['ok']),'bundled local preflight must pass');$x=$r['results']['Pflege'];
ppm_test_assert(!empty($x['ok'])&&$x['content_status']==='PASS'&&$x['category_status']==='PASS','Pflege must separately pass');
ppm_test_assert($x['category_slug']==='gebisse-pflege','Pflege target category');
echo json_encode(['status'=>'PASS_PFLEGE_POSITIVE','result'=>$x],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
