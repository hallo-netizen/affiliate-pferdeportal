<?php
require_once dirname(__DIR__).'/bootstrap-test.php';

function nd_visible_language_text($html){
    $lines=array();
    if(preg_match_all('/<(h2|p|li|th|td|small)\b[^>]*>(.*?)<\/\1>/isu',(string)$html,$matches,PREG_SET_ORDER)){
        foreach($matches as $match){
            $text=html_entity_decode((string)$match[2],ENT_QUOTES|ENT_HTML5,'UTF-8');
            $text=(string)preg_replace('/<[^>]+>/u',' ',$text);
            $text=trim((string)preg_replace('/\s+/u',' ',$text));
            $text=(string)preg_replace('/\s+([.,;:!?])/u','$1',$text);
            if($text!=='')$lines[]=$text;
        }
    }
    return implode("\n\n",$lines);
}
function nd_language_evidence($html){
    $checked=nd_visible_language_text($html);
    $raw=json_encode(array('matches'=>array()),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    return array(
        'engine'=>'LanguageTool 6.8 / Bestand 43',
        'outer_dependency_sha256'=>'187f7c2efe7762049e9f00553dafe686e269bbf62220abe2f2715fe55df8605a',
        'inner_dependency_sha256'=>'6a7f6b67b779ae9505f7579f0c41453ea8d1bd72ae750bdc2c55ba974281467d',
        'content_hash'=>hash('sha256',$html),
        'checked_text'=>$checked,
        'checked_text_sha256'=>hash('sha256',$checked),
        'raw_report_json'=>$raw,
        'raw_report_sha256'=>hash('sha256',$raw),
        'raw_finding_count'=>0,
        'unresolved_finding_count'=>0,
        'return_code'=>0,
        'approved_exceptions'=>array(),
        'execution_record'=>array('input_sha256'=>hash('sha256',$checked),'raw_stdout_sha256'=>hash('sha256',$raw),'return_code'=>0),
    );
}
function nd_enrich_link($link){
    $link=(array)$link;
    $link['reason']=(string)($link['reason']??('Fachlich gebundener interner Link der Rolle '.($link['role']??'')));
    $link['active']=true;
    $link['target_type']='page';
    $link['target_status']='publish';
    $link['hierarchy_path']=array('Testgebundener Pfad');
    $link['snapshot_contract']='WORDPRESS_LINK_TARGET_SNAPSHOT_V1';
    return $link;
}

function nd_prepare_test_article(&$item,$pack){
    $html=(string)$item['canonical_article']['body_html'];
    $ids=array_values(array_filter(array_map(fn($c)=>(string)($c['fact_id']??''),(array)($pack['claims']??array()))));
    $joined=implode(' ',$ids);
    $html=preg_replace_callback('/<(p|li|td)\\b([^>]*)>/iu',function($m)use($joined){
        if(preg_match('/\\bdata-fact-ids=/iu',$m[0]))return $m[0];
        return '<'.$m[1].$m[2].' data-fact-ids="'.$joined.'">';
    },$html);
    if(($item['article_type']??'')==='Beratung'){
        $n=0;
        $html=preg_replace_callback('/<td\\b([^>]*)>(.*?)<\\/td>/isu',function($m)use(&$n){$n++;return '<td'.$m[1].'>'.$m[2].' Auswahlmerkmal'.$n.' Prüfvariante'.$n.'</td>';},$html);
    }
    $text=html_entity_decode($html,ENT_QUOTES|ENT_HTML5,'UTF-8');
    $text=(string)preg_replace('/<[^>]+>/u',' ',$text);
    $text=trim((string)preg_replace('/\\s+/u',' ',$text));
    $item['canonical_article']['body_html']=$html;
    $item['canonical_article']['body_text']=$text;
    $item['canonical_article']['body_html_sha256']=hash('sha256',$html);
}
function nd_quality_binding($item,$index){
    $old=(array)($item['quality_binding']??array());
    $html=(string)$item['canonical_article']['body_html'];
    $links=array_map('nd_enrich_link',(array)$item['runtime_order']['links']);
    $cat=(array)($old['expected_category']??array());
    $cat=array(
        'id'=>5000+$index,
        'slug'=>(string)($cat['slug']??('normal-draft-'.$index)),
        'name'=>(string)($cat['name']??('Normal Draft '.$index)),
        'taxonomy'=>'category',
        'hierarchy_path'=>(string)($cat['hierarchy_path']??('Bereich > Normal Draft '.$index)),
    );
    $registry=array('contract'=>'portal_link_registry_snapshot_v2','entries'=>$links);
    return array(
        'contract'=>'content_structure_language_binding_v2',
        'internal_test_marker'=>(string)($old['internal_test_marker']??('LT-NORMAL-'.$index.'001')),
        'intent_terms'=>array_values((array)($old['intent_terms']??array($item['target_keyword']??$item['article_type']))),
        'table_value_statement'=>'Die Tabelle ergänzt die Entscheidung mit konkreten Prüfkriterien und klaren Folgerungen.',
        'wordpress_category'=>$cat,
        'link_bindings'=>$links,
        'portal_link_registry'=>$registry,
        'portal_link_registry_hash'=>PPM679_Diagnostic::stable_hash($registry),
        'language_evidence'=>nd_language_evidence($html),
    );
}
function nd_fixture(){
    $faq=json_decode((string)file_get_contents(dirname(__DIR__).'/canonical-runtime-input.json'),true);
    $three=json_decode((string)file_get_contents(PPM679_PLUGIN_DIR.'contracts/three-type-bundled-approved-candidates-v1.json'),true);
    $faq_item=$faq['items'][0];
    $items=array($faq_item);
    foreach((array)$three['items'] as $item)$items[]=$item;
    $packs=array($faq['fact_pack_bundle']['fact_packs'][0]);
    foreach((array)$three['fact_pack_bundle']['fact_packs'] as $pack)$packs[]=$pack;
    $ids=array(
        'article:b94aa30f3f4063cb5f140a3e',
        'article:b3e32003d7c1a7c6c6120af9',
        'article:0bdca306dc06d2b8975e9ba3',
        'article:56150bfe5af014dda3e65e29',
    );
    foreach($items as $i=>&$item){
        $item['canonical_article_id']=$ids[$i];
        if($i>0){
            nd_prepare_test_article($item,$packs[$i]);
            $item['quality_binding']=nd_quality_binding($item,$i+1);
            $item['quality_binding_hash']=PPM679_Diagnostic::stable_hash($item['quality_binding']);
        }
        $item['source_hashes']=array();
        $item['contract_hashes']=PPM679_Plan_Validator::active_contract_hashes();
    } unset($item);
    return array('items'=>$items,'packs'=>$packs);
}
function nd_reset(){
    PPM679_WP::reset_test_state();
    PPM679_Storage::reset_test_state();
    PPM679_Handoff_Permit::reset_test_state();
    PPM679_WP::update_option('ppm_publish_enabled','0');
    PPM679_WP::update_option('ppm_server_instance_id','ppm-5e2ef7a9-5a11-4682-85f7-cf94d86a59ee');
    PPM679_Storage::ensure_schema();
}
function nd_seed_terms($items){
    foreach((array)$items as $item){
        $cat=(array)($item['quality_binding']['wordpress_category']??array());
        PPM679_WP::seed_test_term(array(
            'term_id'=>(int)$cat['id'],'name'=>(string)$cat['name'],'slug'=>(string)$cat['slug'],'taxonomy'=>'category',
            'parent'=>0,'parent_chain_slugs'=>array(),'parent_chain_names'=>array(),'taxonomy_depth'=>1,
            'hierarchy_path'=>(string)($cat['hierarchy_path']??$cat['name']),'fixture_class'=>'REAL_SNAPSHOT_DERIVED'
        ));
    }
}
function nd_build_plan($count,$request_suffix='run'){
    $fixture=nd_fixture();$items=array_slice($fixture['items'],0,$count);$packs=array_slice($fixture['packs'],0,$count);
    nd_seed_terms($items);
    $bundle=array('contract'=>'canonical_fact_pack_import_v1','fact_packs'=>$packs);
    $import=PPM679_Admin::import_fact_pack_bundle($bundle);
    ppm_test_assert(!empty($import['ok']),'Fact pack import must pass.');
    foreach($items as &$item){$item['source_hashes']=array(PPM679_Storage::fact_pack_hash((string)$item['source_snapshot_id']));}unset($item);
    $plan=array(
        'contract'=>'production_plan_v4','plan_contract_version'=>'4.0.0','required_plugin_version'=>'6.7.9',
        'plan_id'=>'normal-plan-'.$count.'-'.$request_suffix,'gold_core_binding'=>'FOUR_TYPE_APPROVED_GOLD_CORE_V1',
        'contract_hashes'=>PPM679_Plan_Validator::active_contract_hashes(),'items'=>$items
    );
    return $plan;
}
function nd_runtime($plan,$request_id){
    return array(
        'user_triggered'=>true,'nonce_verified'=>true,'user_id'=>1,
        'server_instance_id'=>'ppm-5e2ef7a9-5a11-4682-85f7-cf94d86a59ee',
        'request_id'=>$request_id,
        'build_manifest_sha256'=>hash_file('sha256',PPM679_PLUGIN_DIR.'certification/build-manifest-v1.json'),
        'evidence_class'=>'SERVER_USER_TRIGGERED_NORMAL_DRAFT_PRODUCTION','publish_allowed'=>false
    );
}
function nd_error_codes($artifact){$out=array();foreach((array)($artifact['errors']??array()) as $e){$c=(string)($e['error_code']??'');if($c!==''&&!in_array($c,$out,true))$out[]=$c;}return $out;}
