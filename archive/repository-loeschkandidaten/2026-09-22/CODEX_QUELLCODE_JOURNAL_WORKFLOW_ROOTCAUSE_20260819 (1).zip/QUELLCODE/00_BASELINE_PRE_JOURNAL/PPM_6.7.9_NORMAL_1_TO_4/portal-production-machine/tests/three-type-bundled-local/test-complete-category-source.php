<?php
require __DIR__.'/bootstrap-three-type.php';
$s=ppm_three_snapshot();$errors=PPM679_Three_Type_Complete_Category_Source::validate($s);
ppm_test_assert($errors===array(),'complete category source must validate');
ppm_test_assert(count($s['categories'])===1124,'all 1124 categories must be projected');
ppm_test_assert((int)$s['counts']['assignable_four_type_categories']===779,'assignable count must be 779');
$expected=['Beratung'=>'checklisten-fuer-pferdeanhaenger-beratung','Vergleich'=>'checklisten-fuer-pferdeanhaenger-vergleich','Pflege'=>'gebisse-pflege'];
$results=[];
foreach($expected as $type=>$slug){
  $item=ppm_three_item($type);$pack=ppm_three_pack($type);PPM679_Storage::save_fact_pack((string)$pack['fact_pack_id'],$pack);$g=PPM679_Content_Generator::generate($item,$pack);
  $local=$item['three_type_local_binding'];
  $input=PPM679_Category_Assignment_Validator::semantic_input_from_article_fields($g['title'],$item['topic'],$item['search_intent'],$type,$g['content_html'],$local['semantic_keywords'],4,'pferde-atelier','category');
  $d=PPM679_Category_Assignment_Validator::derive_independent($input,$s);
  ppm_test_assert(!empty($d['ok']),$type.' category must resolve');
  ppm_test_assert(($d['decision']['best']['slug']??'')===$slug,$type.' target slug');
  ppm_test_assert((int)($d['decision']['score_margin']??0)>=12,$type.' category margin must be hard-resolved');
  $results[$type]=['slug'=>$slug,'margin'=>$d['decision']['score_margin']];
}
echo json_encode(['status'=>'PASS_COMPLETE_1124_CATEGORY_SOURCE_AND_THREE_TYPE_DERIVATION','source_count'=>1124,'assignable_count'=>779,'results'=>$results],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
