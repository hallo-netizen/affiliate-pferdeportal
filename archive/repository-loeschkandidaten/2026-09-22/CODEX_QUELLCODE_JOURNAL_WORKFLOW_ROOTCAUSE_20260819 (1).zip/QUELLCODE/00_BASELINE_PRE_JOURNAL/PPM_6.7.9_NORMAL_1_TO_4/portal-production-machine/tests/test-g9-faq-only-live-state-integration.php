<?php
require_once __DIR__.'/bootstrap-test.php';
PPM679_WP::reset_test_state();
PPM679_WP::update_option('ppm679_schema_version','6.7.9');
PPM679_WP::update_option('ppm_publish_enabled','0');
PPM679_WP::update_option('ppm_server_instance_id',PPM679_BOUND_SERVER_INSTANCE_ID);
$scope=PPM679_G9_FAQ_Test_Release_Validator::expected_scope();
$result=PPM679_Live_State_Gate::verify_live_state_or_abort('g9_single_faq_pre_draft',PPM679_G9_FAQ_Test_Release_Validator::ARTICLE_SHA256,null,null,array('server_instance_id'=>PPM679_BOUND_SERVER_INSTANCE_ID,'article_type_release_scope'=>$scope));
$codes=array_column($result['report']['errors']??array(),'error_code');
ppm_test_assert(!in_array('BLOCKED_ARTICLE_TYPE_NOT_PRODUCTION_ALLOWED',$codes,true),'scoped G9 live state must not invoke global production release errors');
ppm_test_assert(!in_array('BLOCKED_G9_FAQ_RELEASE_SCOPE_MISMATCH',$codes,true),'exact scope must be accepted');
ppm_test_assert(in_array('BLOCKED_ACTIVE_COMPONENT_HASH_MISMATCH',$codes,true) || in_array('BLOCKED_BUILD_FILE_HASH_MISMATCH',$codes,true) || in_array('BLOCKED_BUILD_SIGNATURE_INVALID',$codes,true) || in_array('BLOCKED_BUILD_MANIFEST_HASH_MISMATCH',$codes,true),'unsigned repair tree must remain blocked by build integrity');
PPM679_WP::set_test_active_plugins(array('portal-production-machine/portal-production-machine.php'));
$result2=PPM679_Live_State_Gate::verify_live_state_or_abort('g9_single_faq_pre_draft',PPM679_G9_FAQ_Test_Release_Validator::ARTICLE_SHA256,null,null,array('server_instance_id'=>PPM679_BOUND_SERVER_INSTANCE_ID,'article_type_release_scope'=>$scope));
$codes2=array_column($result2['report']['errors']??array(),'error_code');
ppm_test_assert(in_array('BLOCKED_CANONICAL_TABLE_PLUGIN_INACTIVE',$codes2,true),'remaining live-state gates must stay active');
echo json_encode(array('status'=>'PASS_G9_FAQ_ONLY_LIVE_STATE_INTEGRATION','scoped_codes'=>$codes,'other_gate_preserved'=>in_array('BLOCKED_CANONICAL_TABLE_PLUGIN_INACTIVE',$codes2,true),'server_pass_claimed'=>false),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n";
