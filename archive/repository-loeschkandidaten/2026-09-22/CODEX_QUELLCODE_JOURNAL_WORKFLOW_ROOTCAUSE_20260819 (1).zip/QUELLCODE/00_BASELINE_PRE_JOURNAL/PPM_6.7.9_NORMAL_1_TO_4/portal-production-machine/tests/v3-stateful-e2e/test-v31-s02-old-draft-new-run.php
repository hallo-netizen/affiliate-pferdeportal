<?php
require_once __DIR__.'/fixture-builder.php';
PPM679_WP::reset_test_state();PPM679_Storage::reset_test_state();v31_seed_old_10277();
$before=PPM679_WP::get_post_snapshot(10277);
$r=v31_execute_g9('g9-request-v31-old-draft-0002');
ppm_test_assert($r['ok']===true,'new authorized run with old draft must pass');
ppm_test_assert(count(PPM679_WP::test_posts())===2,'old plus one new');
ppm_test_assert(PPM679_WP::get_post_snapshot(10277)===$before,'old draft unchanged');
ppm_test_assert($r['run_identity']['run_marker']!=='LT2-FAQ-001','fresh marker');
ppm_test_assert(strpos(PPM679_WP::get_post_snapshot($r['post_id'])['post_name'],'-kontrolllauf-')!==false,'bound derived slug');
echo json_encode(array('status'=>'PASS_V31_S02_OLD_DRAFT_NEW_RUN','old_post_id'=>10277,'new_post_id'=>$r['post_id'],'slug_decision'=>$r['slug_decision']),JSON_UNESCAPED_SLASHES)."\n";
