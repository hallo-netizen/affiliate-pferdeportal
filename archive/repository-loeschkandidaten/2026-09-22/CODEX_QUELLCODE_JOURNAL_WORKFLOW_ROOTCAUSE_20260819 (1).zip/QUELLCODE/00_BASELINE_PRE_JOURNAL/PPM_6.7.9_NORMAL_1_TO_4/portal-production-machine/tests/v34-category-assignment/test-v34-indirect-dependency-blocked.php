<?php
require_once __DIR__.'/fixture-builder.php';
$source=(string)file_get_contents(dirname(__DIR__,2).'/includes/independent-semantic-category-deriver.php');
$needle='public static function derive($semantic_article_input,$category_hierarchy_snapshot) {';
$replacement='public static function derive($semantic_article_input,$category_hierarchy_snapshot) { $x=$GLOBALS[\'plan_category\'];';
$source=str_replace($needle,$replacement,$source);
$i=PPM679_Category_Structure_Inspector::inspect($source,array('includes/category-assignment-validator.php'=>'PPM679_Independent_Semantic_Category_Deriver::derive('),(string)file_get_contents(dirname(__DIR__,2).'/includes/g9-single-faq-entrypoint.php'));
ppm_test_assert(!empty($i['errors']),'indirect global dependency must block');
echo "PASS_V34_INDIRECT_DEPENDENCY_BLOCKED\n";
