<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';
require __DIR__.'/wave3-fixture-builder.php';

function wave3_codes(array $result): array {
    $codes=array();
    foreach ((array)($result['errors']??array()) as $error) { $codes[]=(string)($error['error_code']??''); }
    return array_values(array_unique($codes));
}
function wave3_run_mutation(string $id,callable $mutator,string $expected): array {
    $fixture=ppm_wave3_positive_fixture();
    $mutator($fixture);
    $result=PPM679_Review_Matrix_Validator::validate($fixture['review'],$fixture['document'],$fixture['gold_reference'],array('independent_review_verified'=>false),'wave3_mutation_'.$id,'wave3-local-state');
    $codes=wave3_codes($result);
    ppm_test_assert(empty($result['ok']),$id.' must be BLOCKED');
    ppm_test_assert(in_array($expected,$codes,true),$id.' must report '.$expected.'; actual '.json_encode($codes));
    return array('mutation_id'=>$id,'expected_error_code'=>$expected,'actual_error_codes'=>$codes,'status'=>'BLOCKED');
}

$reports=array();
$reports[]=wave3_run_mutation('M01_DUPLICATE_CELL',function(&$f){ $f['review']['cells'][]=$f['review']['cells'][0]; },'REVIEW_MATRIX_DUPLICATE_CELL');
$reports[]=wave3_run_mutation('M02_MISSING_CELL',function(&$f){ array_pop($f['review']['cells']); },'REVIEW_MATRIX_REQUIRED_CELL_MISSING');
$reports[]=wave3_run_mutation('M03_UNKNOWN_CRITERION',function(&$f){ $f['review']['cells'][0]['criterion_id']='UNKNOWN_CRITERION'; },'REVIEW_MATRIX_UNKNOWN_CRITERION');
$reports[]=wave3_run_mutation('M04_WRONG_LINK_EVIDENCE_TYPE',function(&$f){ foreach($f['review']['cells'] as &$c){ if($c['criterion_id']==='LINK_DISTRIBUTION'){ $c['evidence_type']='EXACT_TEXT_QUOTE'; break; }} },'REVIEW_EVIDENCE_TYPE_INVALID');
$reports[]=wave3_run_mutation('M05_QUOTE_OFFSET_INVALID',function(&$f){ $f['review']['cells'][0]['evidence_units'][0]['quote_start_offset']++; },'EDITORIAL_EVIDENCE_QUOTE_INVALID');
$reports[]=wave3_run_mutation('M06_INTRO_QUOTE_FROM_CONCLUSION',function(&$f){ $target=null; foreach($f['review']['cells'] as &$c){ if($c['criterion_id']==='CONCLUSION_QUALITY'){ $target=$c['evidence_units'][0]; } } foreach($f['review']['cells'] as &$c){ if($c['criterion_id']==='INTRODUCTION_QUALITY'){ $c['evidence_units'][0]=$target; break; }} },'REVIEW_EVIDENCE_ZONE_INVALID');
$reports[]=wave3_run_mutation('M07_STRUCTURE_MISMATCH',function(&$f){ foreach($f['review']['cells'] as &$c){ if($c['criterion_id']==='OVERALL_STRUCTURE'){ $c['structural_evidence']['heading_sequence'][]='Erfundene Überschrift'; break; }} },'EDITORIAL_NON_TEXT_EVIDENCE_INVALID');
$reports[]=wave3_run_mutation('M08_LINK_MAP_MISMATCH',function(&$f){ foreach($f['review']['cells'] as &$c){ if($c['criterion_id']==='LINK_DISTRIBUTION'){ $c['link_evidence'][0]['link_target']='/falsch'; break; }} },'EDITORIAL_NON_TEXT_EVIDENCE_INVALID');
$reports[]=wave3_run_mutation('M09_TABLE_MISMATCH',function(&$f){ foreach($f['review']['cells'] as &$c){ if($c['criterion_id']==='TABLE_ADDITIONAL_VALUE'){ $c['table_evidence']['table_cells'][0][0]='falsch'; break; }} },'EDITORIAL_NON_TEXT_EVIDENCE_INVALID');
$reports[]=wave3_run_mutation('M10_STALE_MATRIX_SCHEMA',function(&$f){ $f['review']['review_matrix_schema_hash']=str_repeat('a',64); },'EVIDENCE_STALE');
$reports[]=wave3_run_mutation('M11_STALE_EVIDENCE_SCHEMA',function(&$f){ $f['review']['review_evidence_schema_hash']=str_repeat('b',64); },'EVIDENCE_STALE');
$reports[]=wave3_run_mutation('M12_STALE_REUSE_POLICY',function(&$f){ $f['review']['quote_reuse_policy_hash']=str_repeat('c',64); },'EVIDENCE_STALE');
$reports[]=wave3_run_mutation('M13_GOLD_QUOTE_INVALID',function(&$f){ foreach($f['review']['cells'] as &$c){ if($c['criterion_id']==='GOLD_CORE_ALIGNMENT'){ $c['reference_quote_start_offset']++; break; }} },'GOLD_CORE_EVIDENCE_INVALID');
$reports[]=wave3_run_mutation('M14_GOLD_TYPE_MISMATCH',function(&$f){ $f['gold_reference']['article_type']='Beratung'; },'GOLD_CORE_ARTICLE_TYPE_MISMATCH');
$reports[]=wave3_run_mutation('M15_REPETITION_SINGLE_QUOTE',function(&$f){ foreach($f['review']['cells'] as &$c){ if($c['criterion_id']==='REPETITION'){ $c['evidence_units']=array($c['evidence_units'][0]); break; }} },'REVIEW_EVIDENCE_UNITS_INSUFFICIENT');
$reports[]=wave3_run_mutation('M16_UNDECLARED_REUSE',function(&$f){ $u=$f['review']['cells'][0]['evidence_units'][0]; $f['review']['cells'][1]['evidence_units']=array($u); },'UNDECLARED_QUOTE_REUSE');
$reports[]=wave3_run_mutation('M17_NON_SPECIFIC_REUSE_EXPLANATION',function(&$f){ $u=$f['review']['cells'][0]['evidence_units'][0]; $f['review']['cells'][1]['evidence_units']=array($u); foreach(array(0,1) as $i){ $f['review']['cells'][$i]['quote_reuse_declared']=true; $f['review']['cells'][$i]['quote_reuse_group_id']='REUSE-G1'; $f['review']['cells'][$i]['quote_reuse_reason']='Ein Satz besitzt zwei Eigenschaften.'; $f['review']['cells'][$i]['criterion_specific_explanation']='Der Beleg prüft ausschließlich '.$f['review']['cells'][$i]['criterion_id'].' in sec-a.'; } },'QUOTE_REUSE_EXPLANATION_NOT_CRITERION_SPECIFIC');
$reports[]=wave3_run_mutation('M18_SECTION_ZONE_MISMATCH',function(&$f){ $f['review']['cells'][0]['section_id']='sec-b'; },'REVIEW_EVIDENCE_ZONE_INVALID');
$reports[]=wave3_run_mutation('M19_CELL_FIELD_MISSING',function(&$f){ unset($f['review']['cells'][0]['explanation']); },'REVIEW_MATRIX_CELL_INCOMPLETE');
$reports[]=wave3_run_mutation('M20_GOLD_STRUCTURE_MISSING',function(&$f){ foreach($f['review']['cells'] as &$c){ if($c['criterion_id']==='GOLD_CORE_ALIGNMENT'){ unset($c['reference_structure_evidence']); break; }} },'GOLD_CORE_EVIDENCE_INVALID');
$reports[]=wave3_run_mutation('M21_PORTAL_HASH_MISMATCH',function(&$f){ foreach($f['review']['cells'] as &$c){ if($c['criterion_id']==='LINK_DISTRIBUTION'){ $c['portal_ist_hash']=str_repeat('d',64); break; }} },'EDITORIAL_NON_TEXT_EVIDENCE_INVALID');

// Positive control: one authentic quote may legitimately support UNDERSTANDABILITY and NATURALNESS
$legal=ppm_wave3_positive_fixture();
$unit=$legal['review']['cells'][0]['evidence_units'][0];
$legal['review']['cells'][1]['evidence_units']=array($unit);
$legal['review']['cells'][0]['quote_reuse_declared']=true;
$legal['review']['cells'][0]['quote_reuse_group_id']='LEGAL-REUSE-1';
$legal['review']['cells'][0]['quote_reuse_reason']='Der Satz ist gleichzeitig klar und natürlich formuliert.';
$legal['review']['cells'][0]['criterion_specific_explanation']='Die kurze Satzstruktur macht die Information ohne Vorwissen verständlich.';
$legal['review']['cells'][1]['quote_reuse_declared']=true;
$legal['review']['cells'][1]['quote_reuse_group_id']='LEGAL-REUSE-1';
$legal['review']['cells'][1]['quote_reuse_reason']='Der Satz ist gleichzeitig klar und natürlich formuliert.';
$legal['review']['cells'][1]['criterion_specific_explanation']='Die alltagsnahe Wortwahl wirkt wie eine menschliche direkte Antwort.';
$legal_result=PPM679_Review_Matrix_Validator::validate($legal['review'],$legal['document'],$legal['gold_reference'],array('independent_review_verified'=>false),'wave3_legal_reuse','wave3-local-state');
if (empty($legal_result['ok'])) { fwrite(STDERR,json_encode($legal_result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n"); }
ppm_test_assert(!empty($legal_result['ok']),'legitimate declared quote reuse must not be overblocked');
ppm_test_assert(($legal_result['quote_reuse_audit_status']??'')==='PASS','legal quote reuse audit must pass');

echo json_encode(array(
    'contract'=>'wave3_review_matrix_mutation_report_v1',
    'status'=>'PASS',
    'mutation_count'=>count($reports),
    'mutations'=>$reports,
    'legal_reuse_positive_control'=>array('status'=>'PASS','diagnostics'=>$legal_result['quote_reuse_diagnostics']),
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
