<?php
require_once __DIR__.'/fixture-builder.php';
$c=v31_contract();$binding=$c['item']['quality_binding'];
$map=array(
 'parent_category'=>array('id'=>1,'type'=>'post','status'=>'publish','parent_url'=>''),
 'semantic_related'=>array('id'=>2,'type'=>'page','status'=>'draft','parent_url'=>'https://pferde-atelier.de/transport/'),
 'further_information'=>array('id'=>3,'type'=>'page','status'=>'publish','parent_url'=>'https://pferde-atelier.de/transport/')
);
$r=PPM679_WordPress_Link_Target_Validator::revalidate_live_before_write($binding,'v31_s11',$map);
ppm_test_assert($r['ok']===false,'wrong type/status');
ppm_test_assert(v31_status($r)==='BLOCKED_LINK_LIVE_RESOLUTION','type/status diagnosis');
echo json_encode(array('status'=>'PASS_V31_S11_TARGET_TYPE_STATUS','blocker'=>v31_status($r)),JSON_UNESCAPED_SLASHES)."\n";
