<?php
require_once __DIR__.'/fixture-builder.php';
PPM679_WP::reset_test_state();PPM679_Storage::reset_test_state();
$r=v31_execute_g9('g9-request-v31-empty-0001');
ppm_test_assert($r['ok']===true,'empty state must produce exactly one local draft');
ppm_test_assert(count(PPM679_WP::test_posts())===1,'one draft');
ppm_test_assert(($r['run_identity']['canonical_article_id']??'')==='canonical-faq-001','canonical identity');
ppm_test_assert(($r['run_identity']['run_marker']??'')!=='LT2-FAQ-001','fresh marker');
echo json_encode(array('status'=>'PASS_V31_S01_EMPTY','post_id'=>$r['post_id'],'marker'=>$r['run_identity']['run_marker'],'fingerprint'=>$r['planned_write_fingerprint']),JSON_UNESCAPED_SLASHES)."\n";
