<?php
require_once __DIR__.'/fixture-builder.php';
PPM679_WP::reset_test_state();PPM679_Storage::reset_test_state();v31_seed_old_10277();
$c=v31_candidate();$g=v31_gate(hash('sha256',$c['content_html']),'g9-request-v31-old-marker-0003');
$r=PPM679_WP_Draft_Adapter::create_single_faq_draft($c,$g);
ppm_test_assert($r['ok']===false,'deliberate old marker reuse must block');
ppm_test_assert(v31_status($r)==='BLOCKED_QF03_MARKER_COLLISION','exact marker collision');
ppm_test_assert(count(PPM679_WP::test_posts())===1,'no new draft');
echo json_encode(array('status'=>'PASS_V31_S03_OLD_MARKER_BLOCKED','blocker'=>v31_status($r)),JSON_UNESCAPED_SLASHES)."\n";
