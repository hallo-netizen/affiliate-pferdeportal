<?php
require __DIR__.'/fixture-builder.php';
$summary=array();
for($count=1;$count<=4;$count++){
    nd_reset();
    $plan=nd_build_plan($count,'positive-'.$count);
    $runtime=nd_runtime($plan,'normal-request-positive-'.$count);
    $result=PPM679_Normal_Draft_Pipeline::execute_plan($plan,$runtime);
    $artifact=$result['artifact'];
    ppm_test_assert(($artifact['status']??'')==='NORMAL_DRAFT_END_TO_END_READBACK_PASS_AWAITING_USER_CONTENT_REVIEW_NO_PUBLISH','Count '.$count.' must pass full normal draft path; got '.($artifact['status']??''));
    $posts=PPM679_WP::test_posts();
    ppm_test_assert(count($posts)===$count,'Count '.$count.' must create exact draft count.');
    foreach($posts as $post){ppm_test_assert(($post['post_status']??'')==='draft','Every created post must remain draft.');ppm_test_assert(($post['meta']['_ppm679_publish_blocked']??'')==='1','Every created post must be publish blocked.');}
    $state=PPM679_WP::get_option('ppm679_editorial_plan_runtime_state_v1',array());
    ppm_test_assert(count((array)($state['items']??array()))===$count,'Runtime editorial state must record every readback.');
    $summary[]=['count'=>$count,'status'=>$artifact['status'],'drafts'=>count($posts)];
}
echo json_encode(['status'=>'PASS_NORMAL_DRAFT_1_TO_4_END_TO_END','runs'=>$summary,'publish_allowed'=>false],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
