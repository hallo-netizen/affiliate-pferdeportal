<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Known_Error_Gate {
    const VERSION='6.7.9-wave1-quarantine';
    const CONTRACT_FILE='contracts/known-error-gate-v1.json';

    public static function evaluate($generated,$item=array(),$context='known_error_gate_v1',$server_state_hash='') {
        $contract=self::load_contract();
        $title=(string)($generated['title']??'');
        $html=(string)($generated['content_html']??'');
        $type=(string)($item['article_type']??($generated['article_type']??''));
        $content_hash=hash('sha256',$html);
        $errors=array();
        $checks=array(
            'contract'=>'known_error_gate_v1',
            'version'=>self::VERSION,
            'content_hash'=>$content_hash,
            'article_type'=>$type,
            'scope_limit'=>'known concrete defects only; no general editorial-quality claim'
        );

        if (!is_array($contract)) {
            $errors[]=self::error('BLOCKED_KNOWN_ERROR_CONTRACT_MISSING','Known Error Gate contract missing or invalid.','contract',self::CONTRACT_FILE,null,$context,$server_state_hash);
            return self::result($errors,$checks);
        }
        $checks['contract_hash']=hash('sha256',self::canonical_json($contract));

        $h1_count=(int)preg_match_all('/<h1\b[^>]*>/iu',$html,$unused);
        $checks['body_h1_count']=$h1_count;
        if ($h1_count>0) {
            $errors[]=self::error('BLOCKED_KNOWN_BODY_H1','WordPress provides the article title; body_html must not contain H1.','content.body_h1_count',0,$h1_count,$context,$server_state_hash);
        }

        $marker_regex=(string)($contract['visible_test_marker_regex']??'');
        $marker_found=false;
        if ($marker_regex!=='' && @preg_match('/'.$marker_regex.'/u',$title.' '.$html,$match)) { $marker_found=!empty($match); }
        $checks['visible_test_marker_found']=$marker_found;
        if ($marker_found) {
            $errors[]=self::error('BLOCKED_KNOWN_VISIBLE_TEST_MARKER','Test marker must remain internal and invisible in title/body.','content.visible_test_marker',false,true,$context,$server_state_hash);
        }

        $plain=self::plain_text($html);
        $normalized_title=self::normalize_title($title);
        $title_repeated=$normalized_title!=='' && self::normalize_title($plain)!=='' && strpos(self::normalize_title($plain),$normalized_title)!==false;
        $checks['title_repeated_in_body']=$title_repeated;
        if ($title_repeated) {
            $errors[]=self::error('BLOCKED_KNOWN_TITLE_REPEATED_IN_BODY','The WordPress title must not be repeated in article body.','content.title_repeated_in_body',false,true,$context,$server_state_hash);
        }

        $headings=self::headings($html);
        $normalized_headings=array();
        $duplicate_headings=array();
        $generic_matches=array();
        $generic=array_map(array(__CLASS__,'normalize_title'),(array)($contract['generic_or_known_bad_headings']??array()));
        foreach ($headings as $heading) {
            $normalized=self::normalize_title($heading['text']);
            if ($normalized==='') { continue; }
            if (isset($normalized_headings[$normalized])) { $duplicate_headings[]=$heading['text']; }
            $normalized_headings[$normalized]=true;
            if (in_array($normalized,$generic,true)) { $generic_matches[]=$heading['text']; }
        }
        $checks['duplicate_heading_count']=count($duplicate_headings);
        $checks['generic_heading_matches']=$generic_matches;
        if ($duplicate_headings) {
            $errors[]=self::error('BLOCKED_KNOWN_DUPLICATE_HEADING','Duplicate headings are forbidden.','content.duplicate_headings',array(),$duplicate_headings,$context,$server_state_hash);
        }
        if ($generic_matches) {
            $errors[]=self::error('BLOCKED_KNOWN_GENERIC_HEADING','Known generic or technical headings are forbidden.','content.generic_headings',array(),$generic_matches,$context,$server_state_hash);
        }

        $adjacent=self::adjacent_headings($html);
        $checks['adjacent_heading_count']=count($adjacent);
        if ($adjacent) {
            $errors[]=self::error('BLOCKED_KNOWN_ADJACENT_HEADINGS','Two headings may not follow each other without meaningful text.','content.adjacent_headings',array(),$adjacent,$context,$server_state_hash);
        }

        $max_list_items=self::max_list_items($html);
        $min_list=(int)($contract['minimum_list_items_in_one_list']??4);
        $checks['maximum_items_in_one_list']=$max_list_items;
        $checks['required_minimum_list_items']=$min_list;
        if ($max_list_items<$min_list) {
            $errors[]=self::error('BLOCKED_KNOWN_REQUIRED_LIST_MISSING','At least one real list with four items is required.','content.maximum_items_in_one_list','at least '.$min_list,$max_list_items,$context,$server_state_hash);
        }

        $links=self::visible_links($html);
        $required_link_count=(int)($contract['required_visible_internal_link_count']??3);
        $invalid_links=array();
        foreach ($links as $link) {
            $href=(string)($link['href']??'');
            if ($href==='' || substr($href,0,1)!=='/' || substr($href,0,2)==='//' || preg_match('/(?:example|placeholder|dummy|test)/iu',$href)) {
                $invalid_links[]=$link;
            }
        }
        $checks['visible_link_count']=count($links);
        $checks['invalid_internal_link_count']=count($invalid_links);
        $clustered_at_end=self::links_clustered_at_end($html,$links);
        $checks['links_clustered_at_end']=$clustered_at_end;
        if (count($links)!==$required_link_count) {
            $errors[]=self::error('BLOCKED_KNOWN_INTERNAL_LINK_COUNT','Exactly three visible internal links are required.','content.visible_internal_link_count',$required_link_count,count($links),$context,$server_state_hash);
        }
        if ($invalid_links) {
            $errors[]=self::error('BLOCKED_KNOWN_INTERNAL_LINK_INVALID','Every visible internal link requires a real relative portal URL.','content.invalid_internal_links',array(),$invalid_links,$context,$server_state_hash);
        }
        if ($clustered_at_end) {
            $errors[]=self::error('BLOCKED_KNOWN_LINKS_CLUSTERED_AT_END','Internal links must be distributed through the article; only the third belongs in further information.','content.links_clustered_at_end',false,true,$context,$server_state_hash);
        }

        $conclusion=self::block_body($html,'conclusion');
        $total_words=self::word_count($plain);
        $conclusion_words=$conclusion===null?0:self::word_count(self::plain_text($conclusion));
        $ratio=$total_words>0?$conclusion_words/$total_words:0.0;
        $min_ratios=(array)($contract['conclusion_min_ratio_by_type']??array());
        $min_ratio=isset($min_ratios[$type])?(float)$min_ratios[$type]:0.08;
        $checks['total_word_count']=$total_words;
        $checks['conclusion_word_count']=$conclusion_words;
        $checks['conclusion_ratio']=$ratio;
        $checks['required_conclusion_ratio']=$min_ratio;
        if ($conclusion===null || $ratio<$min_ratio) {
            $errors[]=self::error('BLOCKED_KNOWN_SHORT_CONCLUSION','Conclusion is missing or below the bound article-type ratio.','content.conclusion_ratio','at least '.$min_ratio,$ratio,$context,$server_state_hash);
        }

        $known_patterns=(array)($contract['known_regression_patterns']??array());
        $pattern_hits=array();
        foreach ($known_patterns as $pattern) {
            $count=substr_count($plain,(string)$pattern);
            if ($count>0) { $pattern_hits[(string)$pattern]=$count; }
        }
        $checks['known_regression_pattern_count']=array_sum($pattern_hits);
        $checks['known_regression_patterns']=$pattern_hits;
        if ($pattern_hits) {
            $errors[]=self::error('BLOCKED_KNOWN_REGRESSION_PATTERN','A concrete previously evidenced regression phrase was found.','content.known_regression_patterns',array(),$pattern_hits,$context,$server_state_hash);
        }

        $html_balance=self::basic_html_balance($html);
        $checks['basic_html_balance']=$html_balance;
        if (!$html_balance['ok']) {
            $errors[]=self::error('BLOCKED_KNOWN_INVALID_HTML','Basic HTML tag balance failed.','content.html_balance','balanced',$html_balance,$context,$server_state_hash);
        }

        return self::result($errors,$checks);
    }

    private static function result($errors,$checks) {
        $ok=!$errors;
        return array(
            'ok'=>$ok,
            'status'=>$ok?'PASS':'BLOCKED',
            'known_error_gate_status'=>$ok?'PASS':'BLOCKED',
            'draft_create_allowed'=>false,
            'publish_allowed'=>false,
            'errors'=>$errors,
            'checks'=>$checks
        );
    }

    private static function load_contract() {
        $file=defined('PPM679_PLUGIN_DIR')?PPM679_PLUGIN_DIR.self::CONTRACT_FILE:'';
        if ($file==='' || !is_file($file)) { return null; }
        $decoded=json_decode((string)file_get_contents($file),true);
        return is_array($decoded)?$decoded:null;
    }

    private static function error($code,$message,$field,$expected,$actual,$context,$server_state_hash) {
        return array(
            'error_code'=>$code,
            'failed_rule'=>'KNOWN_ERROR_GATE_V1_FAIL_CLOSED',
            'field_path'=>$field,
            'expected'=>$expected,
            'actual'=>$actual,
            'human_message'=>$message,
            'action_context'=>$context,
            'server_state_hash'=>$server_state_hash,
            'component'=>__CLASS__,
            'source_files'=>array('includes/known-error-gate.php',self::CONTRACT_FILE)
        );
    }

    private static function plain_text($html) {
        $text=html_entity_decode((string)$html,ENT_QUOTES|ENT_HTML5,'UTF-8');
        $text=(string)preg_replace('/<[^>]+>/u',' ',$text);
        return trim((string)preg_replace('/\s+/u',' ',$text));
    }

    private static function normalize_title($text) {
        $text=self::plain_text((string)$text);
        $text=(string)preg_replace('/^\s*\[LT[0-9A-Z-]{6,}\]\s*/u','',$text);
        $text=strtolower($text);
        $text=(string)preg_replace('/[^a-z0-9äöüß]+/u',' ',$text);
        return trim((string)preg_replace('/\s+/u',' ',$text));
    }

    private static function headings($html) {
        $out=array();
        if (preg_match_all('/<h([1-6])\b[^>]*>(.*?)<\/h\1>/isu',(string)$html,$matches,PREG_SET_ORDER)) {
            foreach ($matches as $m) { $out[]=array('level'=>(int)$m[1],'text'=>self::plain_text($m[2])); }
        }
        return $out;
    }

    private static function adjacent_headings($html) {
        $out=array();
        if (preg_match_all('/<h([1-6])\b[^>]*>(.*?)<\/h\1>\s*(?:<\/section>\s*)?(?:<section\b[^>]*>\s*)?<h([1-6])\b[^>]*>(.*?)<\/h\3>/isu',(string)$html,$matches,PREG_SET_ORDER)) {
            foreach ($matches as $m) { $out[]=array('first'=>self::plain_text($m[2]),'second'=>self::plain_text($m[4])); }
        }
        return $out;
    }

    private static function max_list_items($html) {
        $max=0;
        if (preg_match_all('/<(ul|ol)\b[^>]*>(.*?)<\/\1>/isu',(string)$html,$lists,PREG_SET_ORDER)) {
            foreach ($lists as $list) {
                $count=(int)preg_match_all('/<li\b[^>]*>/iu',$list[2],$unused);
                if ($count>$max) { $max=$count; }
            }
        }
        return $max;
    }

    private static function visible_links($html) {
        $out=array();
        if (preg_match_all('/<a\b[^>]*href=("|\')(.*?)\1[^>]*>(.*?)<\/a>/isu',(string)$html,$matches,PREG_SET_ORDER)) {
            foreach ($matches as $m) { $out[]=array('href'=>html_entity_decode($m[2],ENT_QUOTES|ENT_HTML5,'UTF-8'),'anchor'=>self::plain_text($m[3])); }
        }
        return $out;
    }

    private static function links_clustered_at_end($html,$links) {
        if (count($links)<2) { return false; }
        $further=self::block_body($html,'further_information');
        if ($further!==null) {
            $inside=(int)preg_match_all('/<a\b[^>]*href=/iu',$further,$unused);
            if ($inside===count($links)) { return true; }
        }
        $positions=array();
        if (preg_match_all('/<a\b[^>]*href=("|\')(.*?)\1[^>]*>/isu',(string)$html,$matches,PREG_OFFSET_CAPTURE)) {
            foreach ($matches[0] as $m) { $positions[]=(int)$m[1]; }
        }
        if (!$positions) { return false; }
        $threshold=(int)floor(strlen((string)$html)*0.70);
        foreach ($positions as $position) { if ($position<$threshold) { return false; } }
        return true;
    }

    private static function block_body($html,$block) {
        $pattern='/<([a-z0-9]+)\b[^>]*data-block=("|\')'.preg_quote((string)$block,'/').'\2[^>]*>(.*?)<\/\1>/isu';
        return preg_match($pattern,(string)$html,$m)?$m[3]:null;
    }

    private static function word_count($text) {
        preg_match_all('/[\p{L}\p{N}]+(?:[\'’\-][\p{L}\p{N}]+)*/u',(string)$text,$m);
        return count($m[0]);
    }

    private static function basic_html_balance($html) {
        $void=array('br'=>true,'hr'=>true,'img'=>true,'input'=>true,'meta'=>true,'link'=>true,'source'=>true,'track'=>true,'wbr'=>true);
        $stack=array();
        if (!preg_match_all('/<\/?([a-z][a-z0-9]*)\b[^>]*>/iu',(string)$html,$matches,PREG_SET_ORDER)) {
            return array('ok'=>trim((string)$html)==='','unclosed'=>array(),'unexpected_closing'=>array());
        }
        $unexpected=array();
        foreach ($matches as $m) {
            $tag=strtolower($m[1]);
            $raw=$m[0];
            if (isset($void[$tag]) || substr(rtrim($raw),-2)==='/>') { continue; }
            if (substr($raw,1,1)==='/') {
                if (!$stack || end($stack)!==$tag) { $unexpected[]=$tag; continue; }
                array_pop($stack);
            } else {
                $stack[]=$tag;
            }
        }
        return array('ok'=>!$stack&&!$unexpected,'unclosed'=>$stack,'unexpected_closing'=>$unexpected);
    }

    private static function canonical_json($value) {
        return (string)json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
    }
}
