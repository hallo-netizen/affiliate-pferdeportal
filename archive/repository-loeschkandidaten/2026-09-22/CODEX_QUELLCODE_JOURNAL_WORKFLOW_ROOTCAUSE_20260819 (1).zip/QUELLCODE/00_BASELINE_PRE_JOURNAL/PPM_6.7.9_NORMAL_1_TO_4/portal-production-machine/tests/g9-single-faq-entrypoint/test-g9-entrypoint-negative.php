<?php
require_once dirname(__DIR__).'/bootstrap-test.php';
function run_g9($override=array(),$contract=null){$base=array('user_triggered'=>true,'nonce_verified'=>true,'current_user_can_manage'=>true,'declared_contract'=>PPM679_G9_Single_FAQ_Entrypoint::CONTRACT,'declared_plan_item_key'=>PPM679_G9_Single_FAQ_Entrypoint::PLAN_ITEM_KEY,'simulation_only'=>true,'evidence_class'=>'LOCAL_EXECUTED_TEST');return PPM679_G9_Single_FAQ_Entrypoint::execute(array_merge($base,$override),$contract);}
$cases=array();
$cases['no_nonce']=run_g9(array('nonce_verified'=>false));
$cases['wrong_item']=run_g9(array('declared_plan_item_key'=>'other'));
$contract=json_decode(file_get_contents(dirname(__DIR__,2).'/contracts/g9-single-faq-approved-candidate-v1.json'),true);$contract['candidate']['content_html'].='<p>tamper</p>';
$cases['tampered_contract']=run_g9(array(),$contract);
foreach($cases as $name=>$r){ppm_test_assert(empty($r['ok']),'negative case must block: '.$name);ppm_test_assert(strpos((string)$r['status'],'BLOCKED_')===0,'negative code must be BLOCKED: '.$name);}
ppm_test_assert(count(PPM679_WP::test_posts())===0,'negative cases must create no drafts');
echo json_encode(array('status'=>'PASS','cases'=>array_map(fn($r)=>$r['status'],$cases),'drafts_created'=>0),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
