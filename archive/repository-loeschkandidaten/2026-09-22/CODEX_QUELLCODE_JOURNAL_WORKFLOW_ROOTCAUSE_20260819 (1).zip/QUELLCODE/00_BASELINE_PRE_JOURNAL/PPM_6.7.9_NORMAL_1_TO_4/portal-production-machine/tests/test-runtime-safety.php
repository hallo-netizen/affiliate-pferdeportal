<?php
ob_start();
require __DIR__ . '/bootstrap-test.php';
$load_output=ob_get_clean();

ppm_test_assert($load_output==='','Plugin load must not emit frontend output.');
ppm_test_assert(!isset($GLOBALS['ppm_test_hooks']['plugins_loaded']),'No plugins_loaded upgrade hook may be registered.');
ppm_test_assert(!isset($GLOBALS['ppm_test_hooks']['wp_loaded']),'No global wp_loaded production hook may be registered.');
foreach (array_keys($GLOBALS['ppm_test_hooks']) as $hook) {
    ppm_test_assert(stripos($hook,'cron')===false,'No cron hook may be registered.');
    ppm_test_assert(stripos($hook,'publish')===false,'No publish hook may be registered.');
}

PPM679_WP::reset_test_state();
PPM679_Storage::reset_test_state();
PPM679_WP::update_option('ppm_publish_enabled','0');
PPM679_WP::update_option('ppm_server_instance_id','ppm-5e2ef7a9-5a11-4682-85f7-cf94d86a59ee');
PPM679_WP::update_option('ppm679_schema_version','6.7.6');
$schema=PPM679_Storage::ensure_schema();
ppm_test_assert(($schema['status']??'')==='STRUCTURAL_CHECK_OK','Explicit update from stored 6.7.6 schema must complete safely.');
ppm_test_assert(PPM679_WP::get_option('ppm679_schema_version')==='6.7.9','Schema version must be updated to 6.7.9 only during explicit action.');

ob_start();
PPM679_Admin::page();
$page=ob_get_clean();
ppm_test_assert(strpos($page,'Portal Production Machine 6.7.9')!==false,'Admin page must render.');

foreach (($GLOBALS['ppm_test_hooks']['rest_api_init']??array()) as $callback) { call_user_func($callback); }
ppm_test_assert(isset($GLOBALS['ppm_test_routes']['ppm/v679/health']),'Read-only health route must register.');
$health=$GLOBALS['ppm_test_routes']['ppm/v679/health'];
ppm_test_assert(($health['methods']??'')==='GET','Only GET health route is allowed.');
foreach ($GLOBALS['ppm_test_routes'] as $route=>$args) {
    ppm_test_assert(strtoupper((string)($args['methods']??''))==='GET','No REST write route may be registered.');
}

PPM679_WP::set_test_can_manage(false);
$_POST=array('_wpnonce'=>'test-nonce');
$_FILES=array();
PPM679_Admin::handle_run();
ppm_test_assert(is_array(PPM679_WP::get_option('ppm679_last_error')),'Unauthorized action must store diagnostic without fatal error.');

PPM679_WP::set_test_can_manage(true);
$_POST=array('_wpnonce'=>'invalid');
$_FILES=array();
PPM679_Admin::handle_run();
$nonce_error=PPM679_WP::get_option('ppm679_last_error');
ppm_test_assert(($nonce_error['status']??'')==='BLOCKED_ADMIN_NONCE','Invalid nonce must block safely.');

PPM679_Storage::set_test_fault('registry_corrupt',true);
$gate=PPM679_Live_State_Gate::verify_live_state_or_abort('runtime_registry_corrupt',hash('sha256','registry'));
ppm_test_assert(empty($gate['ok']),'Corrupt registry must block.');
$found=false;
foreach (($gate['report']['errors']??array()) as $error) { if (($error['error_code']??'')==='BLOCKED_REGISTRY_INTEGRITY') { $found=true; } }
ppm_test_assert($found,'Registry blocker must be diagnostic.');
PPM679_Storage::clear_test_faults();

$report=array(
    'contract'=>'ppm679_runtime_safety_harness_v1',
    'status'=>'RUNTIME_SAFETY_CHECK_OK',
    'plugin_load_output_bytes'=>strlen($load_output),
    'registered_hooks'=>array_keys($GLOBALS['ppm_test_hooks']),
    'registered_routes'=>array_keys($GLOBALS['ppm_test_routes']),
    'activation_hook_registered'=>false,
    'global_upgrade_hook_registered'=>false,
    'cron_registered'=>false,
    'rest_write_route_registered'=>false,
    'publish_hook_registered'=>false,
    'explicit_schema_upgrade_status'=>$schema['status'],
    'invalid_nonce_status'=>$nonce_error['status'],
    'registry_corruption_blocked'=>$found,
    'php_process_continued'=>true
);
echo json_encode($report,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n";
