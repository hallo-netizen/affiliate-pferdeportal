<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Editorial_Plan_Admin {
    const SLUG='portal-production-machine-679-editorial-plan';
    public static function init(){if(function_exists('add_action')){add_action('admin_menu',array(__CLASS__,'menu'));}}
    public static function menu(){if(!function_exists('add_submenu_page')){return;}add_submenu_page(PPM679_Admin::SLUG,'Redaktionsplan-Status','Redaktionsplan-Status','manage_options',self::SLUG,array(__CLASS__,'page'));}
    public static function page(){if(!PPM679_WP::current_user_can_manage()){return;}$summary=PPM679_Editorial_Plan_Registry::summary();$inventory=PPM679_Content_Inventory_Reconciler::reconcile();$journal=PPM679_Journal_Content_Block_Validator::read_only_live_snapshot();$data=array('editorial_plan'=>$summary,'runtime_inventory'=>array('status'=>$inventory['status']??'BLOCKED','counts'=>$inventory['runtime_snapshot']['counts']??array(),'canonical_group_count'=>$inventory['canonical_group_count']??0,'write_attempted'=>false),'journal'=>$journal,'automatic_publish_allowed'=>false,'wissen_draft_allowed'=>false);$json=function_exists('wp_json_encode')?wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT):json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);echo '<div class="wrap"><h1>Vollständiger Redaktionsplan</h1><p>Schreibfreie Laufzeitansicht. Masterdateien sind nur Archive und keine Live-Datenbank.</p><pre style="white-space:pre-wrap">'.htmlspecialchars((string)$json,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</pre><p><strong>Kein Publish:</strong> automatische Veröffentlichung ist nicht registriert.</p></div>';}
}
