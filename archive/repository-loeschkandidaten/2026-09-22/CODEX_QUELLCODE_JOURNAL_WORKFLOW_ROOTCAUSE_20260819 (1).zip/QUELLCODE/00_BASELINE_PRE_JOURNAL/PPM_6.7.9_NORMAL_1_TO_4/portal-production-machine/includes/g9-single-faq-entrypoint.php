<?php
if (!defined('ABSPATH')) { return; }

/**
 * Separate, explicit G9 single-FAQ production entrypoint.
 * This class does not call or weaken the four-type production plan validator.
 */
final class PPM679_G9_Single_FAQ_Entrypoint {
    const VERSION='6.7.9';
    const ACTION='ppm679_g9_single_faq';
    const NONCE_ACTION='ppm679_g9_single_faq_nonce';
    const SLUG='portal-production-machine-679-g9-single-faq';
    const CONTRACT_FILE='contracts/g9-single-faq-approved-candidate-v1.json';
    const CONTRACT='G9_SINGLE_FAQ_APPROVED_CANDIDATE_V1';
    const PLAN_ITEM_KEY='canonical-faq-001';
    const ARTICLE_SHA256='075b125e243205581639b84b1b499f9509f6f91389407aedbbe6d1aa5e8ac995';
    const QUALITY_BINDING_SHA256='0f78cebd3c202e09187fae834e176602a75ec7ce726f823451110e5aad6abffc';
    const PARENT_SIGNED_CANDIDATE_SHA256='815a3e9cf36a0361aca5de82d243e184015351a8dfd9c02539f312ea212d5d1d';
    const GOLD_REFERENCE_SHA256='f46e806915a164e678f0d10b19b5e13279fa16c725f3a362c80262aa79ce3b11';

    public static function init() {
        if (!function_exists('add_action')) { return; }
        add_action('admin_menu',array(__CLASS__,'menu'));
        add_action('admin_post_'.self::ACTION,array(__CLASS__,'handle'));
    }

    public static function menu() {
        if (!function_exists('add_submenu_page')) { return; }
        add_submenu_page(
            PPM679_Admin::SLUG,
            'G9 Einzel-FAQ-Test',
            'G9 Einzel-FAQ-Test',
            'manage_options',
            self::SLUG,
            array(__CLASS__,'page')
        );
    }

    public static function page() {
        if (!PPM679_WP::current_user_can_manage()) { return; }
        $action=function_exists('admin_url')?admin_url('admin-post.php'):'admin-post.php';
        echo '<div class="wrap"><h1>G9 Einzel-FAQ-Test</h1>';
        echo '<p>Separater, fest gebundener Ein-FAQ-Pfad. Der Vier-Typ-Produktionspfad bleibt unverändert.</p>';
        echo '<p><strong>Artikel:</strong> Was muss vor einer Fahrt mit Pferdeanhänger geprüft werden?</p>';
        echo '<p><strong>Kein Publish:</strong> Es wird höchstens ein WordPress-Entwurf angelegt.</p>';
        echo '<form method="post" action="'.self::h($action).'">';
        echo '<input type="hidden" name="action" value="'.self::ACTION.'">';
        echo '<input type="hidden" name="g9_contract" value="'.self::CONTRACT.'">';
        echo '<input type="hidden" name="g9_plan_item_key" value="'.self::PLAN_ITEM_KEY.'">';
        if (function_exists('wp_nonce_field')) { wp_nonce_field(self::NONCE_ACTION); }
        if (function_exists('submit_button')) { submit_button('Genau einen G9-FAQ-Draft erzeugen und zurücklesen'); }
        else { echo '<button type="submit">Genau einen G9-FAQ-Draft erzeugen und zurücklesen</button>'; }
        echo '</form></div>';
    }

    public static function handle() {
        $nonce=isset($_POST['_wpnonce'])?(string)$_POST['_wpnonce']:'';
        $context=array(
            'user_triggered'=>true,
            'nonce_verified'=>PPM679_WP::verify_nonce($nonce,self::NONCE_ACTION),
            'current_user_can_manage'=>PPM679_WP::current_user_can_manage(),
            'declared_contract'=>(string)($_POST['g9_contract']??''),
            'declared_plan_item_key'=>(string)($_POST['g9_plan_item_key']??''),
            'simulation_only'=>false,
            'evidence_class'=>'SERVER_USER_TRIGGERED_TEST',
        );
        $result=self::execute($context);
        self::emit($result);
    }

    public static function execute($context,$test_contract_override=null) {
        $context=is_array($context)?$context:array();
        $simulation=($context['simulation_only']??false)===true && PPM679_WP::is_test_mode();
        $errors=array();
        if (($context['user_triggered']??false)!==true) { $errors[]=self::err('BLOCKED_G9_NOT_USER_TRIGGERED','G9_REQUIRES_EXPLICIT_USER_TRIGGER','g9.context.user_triggered',true,$context['user_triggered']??null,'Der getrennte G9-Lauf wurde nicht ausdrücklich ausgelöst.'); }
        if (($context['nonce_verified']??false)!==true) { $errors[]=self::err('BLOCKED_G9_NONCE','G9_REQUIRES_OWN_VERIFIED_NONCE','g9.context.nonce_verified',true,$context['nonce_verified']??null,'Die getrennte G9-Nonce ist nicht gültig.'); }
        if (($context['current_user_can_manage']??false)!==true) { $errors[]=self::err('BLOCKED_G9_CAPABILITY','G9_REQUIRES_MANAGE_OPTIONS','g9.context.current_user_can_manage',true,$context['current_user_can_manage']??null,'Die Administratorberechtigung fehlt.'); }
        if (($context['declared_contract']??self::CONTRACT)!==self::CONTRACT || ($context['declared_plan_item_key']??self::PLAN_ITEM_KEY)!==self::PLAN_ITEM_KEY) { $errors[]=self::err('BLOCKED_G9_EXACT_ENTRY_BINDING','G9_ENTRYPOINT_ACCEPTS_ONLY_EXACT_CONTRACT_AND_ITEM','g9.context.binding',array(self::CONTRACT,self::PLAN_ITEM_KEY),array($context['declared_contract']??null,$context['declared_plan_item_key']??null),'Der Aufruf ist nicht an den exakt freigegebenen G9-FAQ gebunden.'); }
        if (!$simulation && (($context['evidence_class']??'')!=='SERVER_USER_TRIGGERED_TEST')) { $errors[]=self::err('BLOCKED_G9_EVIDENCE_CLASS','REAL_G9_REQUIRES_SERVER_USER_TRIGGERED_TEST','g9.context.evidence_class','SERVER_USER_TRIGGERED_TEST',$context['evidence_class']??null,'Der reale G9-Pfad verlangt echte serverseitige Nutzerevidenz.'); }
        if ($errors) { return self::blocked($errors,'g9_entry_authorization'); }

        if ($test_contract_override!==null && !PPM679_WP::is_test_mode()) {
            return self::blocked(array(self::err('BLOCKED_G9_CONTRACT_OVERRIDE_FORBIDDEN','CONTRACT_OVERRIDE_ALLOWED_ONLY_IN_LOCAL_TEST_MODE','g9.contract_override',null,'provided','Ein Vertrags-Override ist außerhalb des lokalen Tests verboten.')),'g9_entry_contract');
        }
        $loaded=$test_contract_override!==null?$test_contract_override:self::load_contract();
        if (!is_array($loaded)) { return self::blocked(array(self::err('BLOCKED_G9_CONTRACT_MISSING','SIGNED_G9_APPROVED_CANDIDATE_CONTRACT_MUST_LOAD','g9.contract','valid object',$loaded,'Der gebundene G9-Kandidatenvertrag fehlt oder ist ungültig.')),'g9_entry_contract'); }
        $contract_check=self::validate_contract($loaded);
        if ($contract_check) { return self::blocked($contract_check,'g9_entry_contract'); }
        $local_rule_errors=array_merge(
            PPM679_Table_Hard_Rule_Validator::validate_source_html((string)($loaded['candidate']['content_html']??''),'g9_mainblock1_source'),
            PPM679_WordPress_Link_Target_Validator::validate_bound_article((string)($loaded['candidate']['content_html']??''),(array)($loaded['item']['quality_binding']??array()),'g9_mainblock1_source'),
            PPM679_Hard_Rule_Coverage_Validator::validate('PRE_DRAFT_LOCAL_AND_LIVE_EVIDENCE_PENDING'),
            PPM679_Category_Assignment_Validator::governance_errors()
        );
        if ($local_rule_errors) { return self::blocked($local_rule_errors,'g9_mainblock1_hard_rules'); }

        $category_snapshot=PPM679_Category_Hierarchy_Validator::load();
        $quality_for_semantics=(array)($loaded['item']['quality_binding']??array());
        $semantic_keywords=array_values(array_unique(array_merge(
            (array)($quality_for_semantics['intent_terms']??array()),
            array((string)($loaded['item']['target_keyword']??''),(string)($loaded['item']['runtime_order']['subject_label']??''))
        )));
        $semantic_category_input=PPM679_Category_Assignment_Validator::semantic_input_from_article_fields(
            (string)($loaded['candidate']['title']??''),
            (string)($loaded['item']['topic']??''),
            (string)($loaded['item']['search_intent']??''),
            (string)($loaded['item']['article_type']??''),
            (string)($loaded['candidate']['content_html']??''),
            $semantic_keywords,
            4,
            'pferde-atelier',
            'category'
        );
        $independent_category=PPM679_Category_Assignment_Validator::derive_independent($semantic_category_input,$category_snapshot);
        if(empty($independent_category['ok'])){return array('ok'=>false,'status'=>(string)($independent_category['report']['status']??'BLOCKED_CATEGORY_SEMANTIC'),'report'=>$independent_category['report']??null,'publish_allowed'=>false,'write_attempted'=>false);}

        $live_gate=null;
        if (!$simulation) {
            $build_errors=PPM679_Build_Integrity::verify('g9_single_faq_entrypoint','');
            if ($build_errors) { return self::blocked($build_errors,'g9_build_integrity'); }
            $live_gate=PPM679_Live_State_Gate::verify_live_state_or_abort(
                'g9_single_faq_pre_draft',
                self::ARTICLE_SHA256,
                null,
                null,
                array(
                    'server_instance_id'=>PPM679_BOUND_SERVER_INSTANCE_ID,
                    'article_type_release_scope'=>PPM679_G9_FAQ_Test_Release_Validator::expected_scope()
                )
            );
            if (empty($live_gate['ok'])) { return array('ok'=>false,'status'=>(string)($live_gate['report']['status']??'BLOCKED_G9_LIVE_STATE'),'report'=>$live_gate['report']??null,'publish_allowed'=>false,'four_type_path_used'=>false); }
            $link_revalidation=PPM679_WordPress_Link_Target_Validator::revalidate_live_before_write((array)($loaded['item']['quality_binding']??array()),'g9_mainblock1_live_read_only');
            if (empty($link_revalidation['ok'])) { return array('ok'=>false,'status'=>(string)($link_revalidation['report']['status']??'BLOCKED_G9_LINK_TARGET_REVALIDATION'),'report'=>$link_revalidation['report']??null,'publish_allowed'=>false,'four_type_path_used'=>false,'write_attempted'=>false); }
        }
        $editorial_category_binding=(array)($loaded['candidate']['category_binding']??array());
        $category_result=PPM679_Category_Assignment_Validator::compare_and_resolve($independent_category,$editorial_category_binding,$category_snapshot);
        if(empty($category_result['ok'])){return array('ok'=>false,'status'=>(string)($category_result['report']['status']??'BLOCKED_CATEGORY_BINDING'),'report'=>$category_result['report']??null,'publish_allowed'=>false,'write_attempted'=>false);}
        $category_assignment=$category_result['category_assignment'];

        $editorial_preflight=PPM679_Editorial_Plan_Runtime_Gate::preflight(array(array(
            'plan_item_key'=>self::PLAN_ITEM_KEY,
            'canonical_article_id'=>self::PLAN_ITEM_KEY,
            'title'=>(string)($loaded['candidate']['title']??''),
            'topic'=>(string)($loaded['item']['topic']??''),
            'article_type'=>'FAQ',
            'category_slug'=>(string)($editorial_category_binding['slug']??'')
        )),'g9_editorial_plan_preflight','technical_evidence');
        if(empty($editorial_preflight['ok'])){return array('ok'=>false,'status'=>(string)($editorial_preflight['status']??'BLOCKED_G9_EDITORIAL_PLAN'),'report'=>$editorial_preflight['report']??null,'publish_allowed'=>false,'write_attempted'=>false);}

        $schema=PPM679_Storage::ensure_schema();
        if (strpos((string)($schema['status']??''),'BLOCKED_')===0) { return array('ok'=>false,'status'=>(string)$schema['status'],'report'=>$schema,'publish_allowed'=>false,'four_type_path_used'=>false); }

        $item=$loaded['item']; $pack=$loaded['fact_pack'];
        $import=PPM679_Admin::import_fact_pack_bundle(array('contract'=>'canonical_fact_pack_import_v1','fact_packs'=>array($pack)));
        if (empty($import['ok'])) { return array('ok'=>false,'status'=>'BLOCKED_G9_FACT_PACK_IMPORT','report'=>$import['artifact']??null,'publish_allowed'=>false); }
        $item['source_hashes']=array(PPM679_Storage::fact_pack_hash((string)$item['source_snapshot_id']));
        $item['contract_hashes']=PPM679_Plan_Validator::active_contract_hashes();
        $stored_pack=PPM679_Storage::load_fact_pack((string)$item['source_snapshot_id']);
        $generated=PPM679_Content_Generator::generate($item,$stored_pack);
        if (empty($generated['ok']) || !hash_equals(self::ARTICLE_SHA256,(string)($generated['content_hash']??''))) {
            return self::blocked(array(self::err('BLOCKED_G9_GENERATED_CONTENT_HASH','G9_GENERATED_CONTENT_MUST_MATCH_APPROVED_FAQ_BYTES','g9.generated.content_hash',self::ARTICLE_SHA256,$generated['content_hash']??null,'Der erzeugte FAQ weicht vom unabhängig geprüften Artikel ab.')),'g9_generation');
        }
        $check=PPM679_Content_Validator::check($generated,$item,'g9_single_faq_entrypoint',$simulation?'local-g9-simulation':'server-g9');
        if (empty($check['ok'])) { return array('ok'=>false,'status'=>'BLOCKED_G9_CONTENT_CHECK','report'=>$check['report']??$check,'publish_allowed'=>false); }

        $user_id=PPM679_WP::is_test_mode()?1:(function_exists('get_current_user_id')?(int)get_current_user_id():0);
        $server_id=PPM679_WP::server_instance_id();
        $build_manifest_file=PPM679_PLUGIN_DIR.'certification/build-manifest-v1.json';
        $build_manifest_sha256=is_file($build_manifest_file)?hash_file('sha256',$build_manifest_file):'';
        $identity_result=PPM679_Stateful_Write_Gate::build_identity(
            self::PLAN_ITEM_KEY,
            $server_id,
            $build_manifest_sha256,
            (PPM679_WP::is_test_mode()&&isset($context['request_id_override']))?(string)$context['request_id_override']:null
        );
        if(empty($identity_result['ok'])){return array('ok'=>false,'status'=>(string)($identity_result['report']['status']??'BLOCKED_V31_IDENTITY'),'report'=>$identity_result['report']??null,'publish_allowed'=>false,'write_attempted'=>false);}
        $identity=$identity_result['identity'];
        $request_id=(string)$identity['request_id'];
        $gate=array(
            'TECHNICAL_STATUS'=>'PASS','FACT_AND_HASH_STATUS'=>'PASS','EDITORIAL_MACHINE_STATUS'=>'PASS',
            'KNOWN_ERROR_GATE_V1'=>'PASS','GENERAL_TEMPLATE_REPETITION_STATUS'=>'PASS','GOLD_CORE_NUMERIC_GATE'=>'PASS',
            'EDITORIAL_REVIEW_STATUS'=>'PASS','GOLD_CORE_REVIEW_GATE'=>'PASS','CONTROL_BASELINE_STATUS'=>'PASS','SERVER_CHECK_STATUS'=>'PASS',
            'FINAL_CONTENT_HASH'=>self::ARTICLE_SHA256,'EDITORIALLY_REVIEWED_CONTENT_HASH'=>self::ARTICLE_SHA256,
            'CURRENT_GOLD_REFERENCE_HASH'=>self::GOLD_REFERENCE_SHA256,'REVIEW_GOLD_REFERENCE_HASH'=>self::GOLD_REFERENCE_SHA256,
            'user_triggered'=>true,'nonce_verified'=>true,'current_user_can_manage'=>true,
            'article_count'=>1,'article_type'=>'faq','publish_allowed'=>false,
            'evidence_class'=>$simulation?'LOCAL_EXECUTED_TEST':'SERVER_USER_TRIGGERED_TEST','simulation_only'=>$simulation,
            'server_instance_id'=>$server_id,'request_id'=>$request_id,'triggered_by_user_id'=>$user_id,
            'stateful_e2e_required'=>true,
            'manual_override'=>false,'time_pressure_exception'=>false,'progress_exception'=>false,
        );
        $candidate=$loaded['candidate']; $candidate['content_html']=$generated['content_html'];
        $candidate['category_assignment']=$category_assignment;
        $candidate['category_id']=(int)$category_assignment['live_resolved_category']['term_id'];
        $plan_result=PPM679_Stateful_Write_Gate::prepare_single_faq_plan($candidate,$gate,$identity,self::QUALITY_BINDING_SHA256);
        if(empty($plan_result['ok'])){return array('ok'=>false,'status'=>(string)($plan_result['report']['status']??'BLOCKED_V31_WRITE_PLAN'),'report'=>$plan_result['report']??null,'publish_allowed'=>false,'write_attempted'=>false);}
        $plan=$plan_result['plan'];
        $gate['PLANNED_WRITE_FINGERPRINT']=(string)$plan['planned_write_fingerprint'];
        $candidate['internal_test_marker']=(string)$identity['run_marker'];
        $candidate['run_id']=$request_id;
        $candidate['slug']=(string)$plan['payload']['slug'];
        $draft=PPM679_WP_Draft_Adapter::create_single_faq_draft($candidate,$gate,$plan);
        if (empty($draft['ok'])) { return array('ok'=>false,'status'=>'BLOCKED_G9_DRAFT','report'=>$draft['report']??null,'publish_allowed'=>false,'planned_write_fingerprint'=>$plan['planned_write_fingerprint']??null,'write_attempted'=>false); }
        $post_id=(int)$draft['post_id'];
        $snapshot=PPM679_WP::get_post_snapshot($post_id);
        $readback_context=array('evidence_class'=>$simulation?'LOCAL_EXECUTED_TEST':'SERVER_USER_TRIGGERED_TEST','user_triggered'=>true,'publish_event_count'=>0,'captured_at'=>gmdate('c'),'server_instance_id'=>$server_id,'request_id'=>$request_id,'artifact_id'=>'g9-readback-'.$post_id);
        $readback=$simulation
            ? self::local_readback($snapshot,$draft['expected'])
            : PPM679_WP_Readback_Validator::validate($snapshot,$draft['expected'],$readback_context);
        if (empty($readback['ok'])) {
            PPM679_WP::delete_post($post_id);
            return array('ok'=>false,'status'=>'BLOCKED_G9_READBACK','report'=>$readback['report']??$readback,'post_deleted_after_failed_readback'=>true,'publish_allowed'=>false);
        }
        $editorial_state=PPM679_Editorial_Plan_Runtime_Gate::record_readback((array)($editorial_preflight['bindings']??array()),array(array('post_id'=>$post_id,'post_status'=>'draft','canonical_article_id'=>self::PLAN_ITEM_KEY,'content_hash'=>self::ARTICLE_SHA256)),'g9_readback');
        if(empty($editorial_state['ok'])){return array('ok'=>false,'status'=>'BLOCKED_G9_EDITORIAL_RUNTIME_STATE','report'=>$editorial_state,'publish_allowed'=>false,'post_id'=>$post_id);}
        return array(
            'ok'=>true,
            'status'=>$simulation?'PASS_G9_SINGLE_FAQ_LOCAL_SIMULATION_NOT_SERVER_PASS':'PASS_G9_DRAFT_AND_READBACK_AWAITING_REAL_DESKTOP_MOBILE_DOM',
            'contract'=>'G9_SINGLE_FAQ_EXECUTION_RESULT_V1','post_id'=>$post_id,'request_id'=>$request_id,
            'article_sha256'=>self::ARTICLE_SHA256,'quality_binding_sha256'=>self::QUALITY_BINDING_SHA256,
            'draft_report'=>$draft['report'],'readback'=>$readback,
            'run_identity'=>array('canonical_article_id'=>self::PLAN_ITEM_KEY,'request_id'=>$request_id,'run_marker'=>$identity['run_marker'],'server_instance_id'=>$server_id,'build_manifest_sha256'=>$build_manifest_sha256,'post_id'=>$post_id),
            'planned_write_fingerprint'=>$plan['planned_write_fingerprint'],
            'slug_decision'=>$plan['slug_decision'],
            'category_assignment'=>$category_assignment,
            'editorial_plan_preflight'=>$editorial_preflight['report'],
            'editorial_plan_runtime_state'=>$editorial_state['state'],
            'dom_capture_required'=>!$simulation,
            'dom_capture_contract'=>'QF03_RENDERED_DOM_DESKTOP_MOBILE_PAIR_REQUIRED',
            'publish_allowed'=>false,'four_type_path_used'=>false,'four_type_path_modified'=>false,
        );
    }

    private static function local_readback($snapshot,$expected) {
        $meta=is_array($snapshot['meta']??null)?$snapshot['meta']:array();
        $category_errors=PPM679_Category_Assignment_Validator::validate_readback($snapshot,(array)($expected['category_assignment']??array()));
        $ok=!$category_errors && is_array($snapshot)
            && ($snapshot['post_status']??'')==='draft'
            && ($snapshot['post_title']??'')===($expected['title']??'')
            && ($snapshot['post_name']??'')===($expected['slug']??'')
            && hash('sha256',(string)($snapshot['post_content']??''))===($expected['content_hash']??'')
            && (string)PPM679_WP::scalar_meta($meta,'_ppm679_request_id')===(string)($expected['meta']['_ppm679_request_id']??'')
            && (string)PPM679_WP::scalar_meta($meta,'_ppm679_planned_write_fingerprint')===(string)($expected['meta']['_ppm679_planned_write_fingerprint']??'');
        return array('ok'=>$ok,'READBACK_STATUS'=>$ok?'STRUCTURAL_CHECK_OK_NOT_SERVER_PASS':'BLOCKED','item'=>$snapshot,'report'=>$ok?PPM679_Diagnostic::ok('G9_LOCAL_READBACK_STRUCTURAL_CHECK_OK_NOT_SERVER_PASS','g9_local_readback',''):PPM679_Diagnostic::blocked('BLOCKED_G9_LOCAL_READBACK',array(),'g9_local_readback'));
    }

    private static function validate_contract($c) {
        $errors=array();
        $self=(string)($c['contract_self_sha256']??''); $copy=$c; unset($copy['contract_self_sha256']);
        $actual=PPM679_Diagnostic::stable_hash($copy);
        if ($self==='' || !hash_equals($self,$actual)) { $errors[]=self::err('BLOCKED_G9_CONTRACT_SELF_HASH','G9_CONTRACT_SELF_HASH_MUST_MATCH','g9.contract.contract_self_sha256',$actual,$self,'Der G9-Vertrag ist nicht unverändert.'); }
        $pairs=array(
            'contract'=>array(self::CONTRACT,$c['contract']??null),
            'plan_item_key'=>array(self::PLAN_ITEM_KEY,$c['plan_item_key']??null),
            'article_type'=>array('FAQ',$c['article_type']??null),
            'parent_signed_wave4_candidate_sha256'=>array(self::PARENT_SIGNED_CANDIDATE_SHA256,$c['parent_signed_wave4_candidate_sha256']??null),
            'canonical_content_sha256'=>array(self::ARTICLE_SHA256,$c['canonical_content_sha256']??null),
            'quality_binding_sha256'=>array(self::QUALITY_BINDING_SHA256,$c['quality_binding_sha256']??null),
            'gold_reference_sha256'=>array(self::GOLD_REFERENCE_SHA256,$c['gold_reference_sha256']??null),
            'required_mainblock1_review_verdict'=>array('CONFIRM_PASS_MAINBLOCK1_CONSOLIDATED_RULE_COVERAGE_SIGNED_BUILD',$c['independent_editorial_review']['mainblock1_required_verdict']??null),
        );
        foreach($pairs as $field=>$pair){ if((string)$pair[1]!==$pair[0]){$errors[]=self::err('BLOCKED_G9_CONTRACT_BINDING','G9_CONTRACT_FIELD_MUST_MATCH_EXACT_APPROVED_VALUE','g9.contract.'.$field,$pair[0],$pair[1],'Eine feste G9-Vertragsbindung weicht ab.');} }
        if (($c['publish_allowed']??null)!==false || ($c['four_type_path_may_be_modified']??null)!==false) { $errors[]=self::err('BLOCKED_G9_SCOPE_FLAGS','G9_CONTRACT_MUST_FORBID_PUBLISH_AND_FOUR_TYPE_MODIFICATION','g9.contract.scope_flags',false,array($c['publish_allowed']??null,$c['four_type_path_may_be_modified']??null),'Der G9-Vertrag lockert eine verbotene Grenze.'); }
        $body=(string)($c['candidate']['content_html']??'');
        if (!hash_equals(self::ARTICLE_SHA256,hash('sha256',$body))) { $errors[]=self::err('BLOCKED_G9_CONTRACT_ARTICLE_HASH','G9_CONTRACT_BODY_MUST_MATCH_APPROVED_ARTICLE','g9.contract.candidate.content_html',self::ARTICLE_SHA256,hash('sha256',$body),'Der eingebettete FAQ ist nicht byteidentisch.'); }
        if (PPM679_Diagnostic::stable_hash($c['item']['quality_binding']??array())!==self::QUALITY_BINDING_SHA256) { $errors[]=self::err('BLOCKED_G9_CONTRACT_QUALITY_HASH','G9_QUALITY_BINDING_MUST_MATCH_APPROVED_HASH','g9.contract.item.quality_binding',self::QUALITY_BINDING_SHA256,PPM679_Diagnostic::stable_hash($c['item']['quality_binding']??array()),'Die Qualitätsbindung weicht ab.'); }
        return $errors;
    }

    private static function load_contract() {
        $file=PPM679_PLUGIN_DIR.self::CONTRACT_FILE;
        if (!is_file($file)) { return null; }
        $d=json_decode((string)file_get_contents($file),true);
        return is_array($d)?$d:null;
    }
    private static function id($prefix) { try{$r=bin2hex(random_bytes(16));}catch(Throwable $e){$r=hash('sha256',microtime(true).'|'.mt_rand());} return $prefix.'-'.substr($r,0,24); }
    private static function err($code,$rule,$path,$expected,$actual,$reason) { return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'g9_single_faq_entrypoint','',__CLASS__,null,array(self::CONTRACT_FILE)); }
    private static function blocked($errors,$context) { return array('ok'=>false,'status'=>(string)($errors[0]['error_code']??'BLOCKED_G9'),'report'=>PPM679_Diagnostic::blocked((string)($errors[0]['error_code']??'BLOCKED_G9'),$errors,$context),'publish_allowed'=>false,'four_type_path_used'=>false); }
    private static function h($s) { return htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
    private static function emit($result) {
        if (function_exists('nocache_headers')) { nocache_headers(); }
        if (!headers_sent()) { header('Content-Type: application/json; charset=utf-8'); }
        echo function_exists('wp_json_encode')?wp_json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT):json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
        if (!PPM679_WP::is_test_mode()) { exit; }
    }
}
