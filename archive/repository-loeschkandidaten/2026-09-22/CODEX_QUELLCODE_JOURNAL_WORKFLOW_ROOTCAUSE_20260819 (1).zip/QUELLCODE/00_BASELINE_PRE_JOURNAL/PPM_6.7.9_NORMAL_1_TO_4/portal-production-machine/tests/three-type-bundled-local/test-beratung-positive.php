<?php
require __DIR__.'/bootstrap-three-type.php';
$r=PPM679_Three_Type_Bundled_Local_Preflight::run(ppm_three_scope());
ppm_test_assert(!empty($r['ok']),'bundled local preflight must pass');$x=$r['results']['Beratung'];
ppm_test_assert(!empty($x['ok'])&&$x['content_status']==='PASS'&&$x['category_status']==='PASS','Beratung must separately pass');
ppm_test_assert($x['category_slug']==='checklisten-fuer-pferdeanhaenger-beratung','Beratung target category');
echo json_encode(['status'=>'PASS_BERATUNG_POSITIVE','result'=>$x],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
