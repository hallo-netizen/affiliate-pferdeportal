<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

$status_names=array(
    'known_error_gate','technical','content','article_wide_coverage','section_coverage',
    'template_repetition','editorial_review','user_visual','readback'
);
$non_pass=array('FAIL','BLOCKED','UNGEKLÄRT','NICHT_AUSGEFÜHRT');
$cases=array();
$baseline=array_fill_keys($status_names,'PASS');
$integrity=array(
    'content_hash_unchanged'=>true,
    'rule_catalog_hash_unchanged'=>true,
    'review_matrix_schema_hash_unchanged'=>true,
    'validator_code_hash_unchanged'=>true,
    'gold_reference_hash_unchanged'=>true,
    'portal_export_hash_unchanged'=>true,
    'readback_hash_match'=>true,
    'draft_unchanged_after_readback'=>true,
    'evidence_fresh'=>true
);
foreach ($status_names as $name) {
    foreach ($non_pass as $status) {
        $set=$baseline; $set[$name]=$status;
        $r=PPM679_Fail_Closed_Aggregator::evaluate_release($set,$integrity,$status_names,array_keys($integrity));
        ppm_test_assert(empty($r['ok']),$name.'='.$status.' must block');
        $cases[]=['case'=>$name.'_'.$status,'expected'=>'BLOCKED','actual'=>$r['status']];
    }
    $set=$baseline; unset($set[$name]);
    $r=PPM679_Fail_Closed_Aggregator::evaluate_release($set,$integrity,$status_names,array_keys($integrity));
    ppm_test_assert(empty($r['ok']),$name.' missing must block');
    $cases[]=['case'=>$name.'_MISSING','expected'=>'BLOCKED','actual'=>$r['status']];
}
foreach (array_keys($integrity) as $name) {
    $bad=$integrity; $bad[$name]=false;
    $r=PPM679_Fail_Closed_Aggregator::evaluate_release($baseline,$bad,$status_names,array_keys($integrity));
    ppm_test_assert(empty($r['ok']),$name.' false must block');
    $cases[]=['case'=>$name.'_FALSE','expected'=>'BLOCKED','actual'=>$r['status']];
}
$invalid=PPM679_Fail_Closed_Aggregator::evaluate_release(array('gate'=>'looks good'),array('hash'=>true),array('gate'),array('hash'));
ppm_test_assert(empty($invalid['ok']),'Invalid status wording must block');
$cases[]=['case'=>'INVALID_STATUS_WORDING','expected'=>'BLOCKED','actual'=>$invalid['status']];
$empty=PPM679_Fail_Closed_Aggregator::evaluate_release(array(),$integrity,$status_names,array_keys($integrity));
ppm_test_assert(empty($empty['ok']),'Empty status set must block');
$cases[]=['case'=>'EMPTY_STATUS_SET','expected'=>'BLOCKED','actual'=>$empty['status']];
$all=PPM679_Fail_Closed_Aggregator::evaluate_release($baseline,$integrity,$status_names,array_keys($integrity));
ppm_test_assert(!empty($all['ok']),'All explicit PASS and unchanged integrity must pass');
ppm_test_assert($all['draft_create_allowed']===true,'Draft can be allowed only after all PASS');
ppm_test_assert($all['publish_allowed']===false,'Publish remains false');
$cases[]=['case'=>'ALL_EXPLICIT_PASS','expected'=>'PASS','actual'=>$all['status']];

$base=array('ok'=>true,'technical_status'=>'TECHNICAL_CHECK_OK','content_quality_status'=>'CONTENT_QUALITY_CHECK_OK','errors'=>array(),'technical_errors'=>array(),'content_quality_errors'=>array(),'checks'=>array());
$known=array('ok'=>false,'known_error_gate_status'=>'BLOCKED','errors'=>array(array('error_code'=>'BLOCKED_KNOWN_BODY_H1')),'checks'=>array('body_h1_count'=>1));
$merged=PPM679_Fail_Closed_Aggregator::merge_content_validation($base,$known,'wave1_merge');
ppm_test_assert(empty($merged['ok']),'Earlier PASS must not override later BLOCKED');
$cases[]=['case'=>'EARLIER_PASS_CANNOT_OVERRIDE_BLOCKED','expected'=>'BLOCKED','actual'=>$merged['checks']['fail_closed_aggregate_status']];

$report=array(
    'contract'=>'wave1_fail_closed_truth_table_report_v2',
    'status'=>'PASS',
    'case_count'=>count($cases),
    'cases'=>$cases,
    'aggregator_code_hash'=>hash_file('sha256',dirname(__DIR__).'/includes/fail-closed-aggregator.php')
);
echo json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
