<?php
require __DIR__.'/fixture-builder.php';
nd_reset();$f=nd_fixture();$out=array();
foreach($f['items'] as $i=>$item){
    PPM679_Storage::save_fact_pack((string)$f['packs'][$i]['fact_pack_id'],$f['packs'][$i]);
    $g=PPM679_Content_Generator::generate($item,$f['packs'][$i]);
    $c=!empty($g['ok'])?PPM679_Content_Validator::check($g,$item,'probe','x'):array('ok'=>false,'errors'=>array(array('error_code'=>$g['error']??'GEN_FAIL')));
    $out[]=array('type'=>$item['article_type'],'gen_ok'=>$g['ok']??false,'check_ok'=>$c['ok']??false,'tech'=>$c['technical_status']??null,'quality'=>$c['content_quality_status']??null,'codes'=>nd_error_codes($c),'checks'=>$c['checks']??array());
}
echo json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
