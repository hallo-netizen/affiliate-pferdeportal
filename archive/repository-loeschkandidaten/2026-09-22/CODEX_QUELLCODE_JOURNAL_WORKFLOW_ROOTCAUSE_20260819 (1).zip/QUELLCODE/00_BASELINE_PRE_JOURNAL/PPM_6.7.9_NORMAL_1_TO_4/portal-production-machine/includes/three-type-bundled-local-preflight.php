<?php
if (!defined('ABSPATH')) { return; }

/**
 * Signed-quarantine, local-only and non-writing preflight for the bundled three-type block.
 * Registered as code but exposes no WordPress route, admin action, draft or publish path.
 */
final class PPM679_Three_Type_Bundled_Local_Preflight {
    const VERSION='6.7.9';
    const ACTION_CONTEXT='three_type_bundled_signed_quarantine_preflight';
    const TYPES=array('Beratung','Vergleich','Pflege');

    public static function run($scope,$release_override=null,$bundle_override=null,$snapshot_override=null) {
        $errors=PPM679_Three_Type_Bundled_Release_Validator::validate(self::ACTION_CONTEXT,$scope,$release_override,$bundle_override);
        $build_errors=PPM679_Build_Integrity::verify(self::ACTION_CONTEXT);
        $errors=array_merge($errors,$build_errors);
        $snapshot=$snapshot_override!==null?$snapshot_override:PPM679_Three_Type_Complete_Category_Source::load();
        $errors=array_merge($errors,PPM679_Three_Type_Complete_Category_Source::validate($snapshot));
        if ($errors) { return self::blocked($errors,array()); }
        $bundle=$bundle_override!==null?$bundle_override:PPM679_Three_Type_Bundled_Release_Validator::load(PPM679_Three_Type_Bundled_Release_Validator::BUNDLE_FILE);
        $before=self::test_post_count();
        $packs=array();
        foreach ((array)($bundle['fact_pack_bundle']['fact_packs']??array()) as $pack) {
            if (is_array($pack) && trim((string)($pack['fact_pack_id']??''))!=='') {
                $pack_id=(string)$pack['fact_pack_id'];
                $packs[$pack_id]=$pack;
                PPM679_Storage::save_fact_pack($pack_id,$pack);
            }
        }
        $results=array(); $all_errors=array();
        PPM679_Category_Assignment_Validator::reset_test_state();
        foreach ((array)$bundle['items'] as $index=>$item) {
            $type=(string)($item['article_type']??'');
            $pack=$packs[(string)($item['source_snapshot_id']??'')]??null;
            $result=self::validate_item($item,$pack,$snapshot,$index);
            $results[$type]=$result;
            if (empty($result['ok'])) { $all_errors=array_merge($all_errors,(array)($result['errors']??array())); }
        }
        $after=self::test_post_count();
        if ($before!==0 || $after!==0) {
            $all_errors[]=self::err('BLOCKED_THREE_TYPE_LOCAL_WRITE','THREE_TYPE_LOCAL_PREFLIGHT_MUST_CREATE_NO_WORDPRESS_OBJECTS','wordpress.test_posts',0,array('before'=>$before,'after'=>$after),'Der lokale Drei-Typ-Vorlauf hat unerlaubt WordPress-Objekte erzeugt.');
        }
        foreach (self::TYPES as $type) {
            if (!isset($results[$type])) { $all_errors[]=self::err('BLOCKED_THREE_TYPE_RESULT_MISSING','OVERALL_PASS_REQUIRES_SEPARATE_RESULT_PER_TYPE','results.'.$type,'separate result',null,'Für einen Beitragstyp fehlt das getrennte Ergebnis.'); }
        }
        if ($all_errors) { return self::blocked($all_errors,$results); }
        return array(
            'ok'=>true,
            'status'=>'PASS_THREE_TYPE_BUNDLED_SIGNED_QUARANTINE_PREFLIGHT_AWAITING_CLAUDE_SIGNED_BUILD_REVIEW',
            'article_types'=>self::TYPES,
            'results'=>$results,
            'overall_pass_requires_each_type_pass'=>true,
            'wordpress_access_performed'=>false,
            'drafts_created'=>0,
            'installation_performed'=>false,
            'signing_performed'=>true,
            'publish_allowed'=>false,
            'external_review_claimed'=>true,
            'preceding_external_review_verdict'=>PPM679_Three_Type_Bundled_Release_Validator::REVIEW_VERDICT,
            'next_step'=>'ONE_SHARED_CLAUDE_SIGNED_BUILD_REVIEW_PACKAGE_AND_STOP',
        );
    }

    public static function validate_item($item,$fact_pack,$snapshot,$index=0) {
        $errors=array(); $type=(string)($item['article_type']??'');
        if (!in_array($type,self::TYPES,true)) { $errors[]=self::err('BLOCKED_THREE_TYPE_ITEM_TYPE','LOCAL_ITEM_TYPE_MUST_BE_ONE_OF_EXACT_THREE_TYPES','item.article_type',self::TYPES,$type,'Der lokale Einzeltest gehört nicht zum Drei-Typ-Block.',$index); }
        if (!is_array($fact_pack)) { $errors[]=self::err('BLOCKED_THREE_TYPE_FACT_PACK_MISSING','EACH_THREE_TYPE_ITEM_REQUIRES_EXACT_FACT_PACK','item.source_snapshot_id','bound fact pack',$fact_pack,'Das Fact-Pack des Beitragstyps fehlt.',$index); return array('ok'=>false,'article_type'=>$type,'errors'=>$errors); }
        $generated=PPM679_Content_Generator::generate($item,$fact_pack);
        if (empty($generated['ok'])) { $errors[]=self::err('BLOCKED_THREE_TYPE_GENERATION','APPROVED_CANONICAL_ITEM_MUST_BIND_IN_RUNTIME','item.canonical_article','runtime generation PASS',$generated,'Der gebundene kanonische Artikel konnte nicht unverändert in den Laufzeitpfad übernommen werden.',$index); return array('ok'=>false,'article_type'=>$type,'errors'=>$errors); }
        $check=PPM679_Three_Type_Local_Content_Validator::evaluate($generated,$item,$fact_pack,'three_type_local_'.$type);
        if (empty($check['ok'])) { $errors=array_merge($errors,(array)($check['errors']??array())); }

        $local=(array)($item['three_type_local_binding']??array());
        $expected=(array)($local['expected_category']??array());
        $semantic=PPM679_Category_Assignment_Validator::semantic_input_from_article_fields(
            (string)($generated['title']??''),(string)($item['topic']??''),(string)($item['search_intent']??''),$type,
            (string)($generated['content_html']??''),(array)($local['semantic_keywords']??array()),4,'pferde-atelier','category'
        );
        $derived=PPM679_Category_Assignment_Validator::derive_independent($semantic,$snapshot);
        if (empty($derived['ok'])) { $errors=array_merge($errors,(array)($derived['report']['errors']??array())); }
        else {
            $best=(array)($derived['decision']['best']??array());
            foreach (array('name','slug','taxonomy','hierarchy_path') as $field) {
                if ((string)($best[$field]??'')!==(string)($expected[$field]??'')) {
                    $errors[]=self::err('BLOCKED_THREE_TYPE_CATEGORY_MISMATCH','INDEPENDENT_CATEGORY_AND_APPROVED_LOCAL_TARGET_MUST_MATCH','item.three_type_local_binding.expected_category.'.$field,$best[$field]??null,$expected[$field]??null,'Die unabhängige Kategorieentscheidung stimmt nicht mit der gebundenen Zielkategorie überein.',$index);
                }
            }
        }
        return array(
            'ok'=>!$errors,'article_type'=>$type,'errors'=>$errors,
            'content_status'=>empty($check['ok'])?'BLOCKED':'PASS',
            'technical_status'=>$check['technical_status']??null,
            'content_quality_status'=>empty($check['ok'])?'BLOCKED':'PASS_LOCAL_STRUCTURAL_PENDING_CLAUDE',
            'language_review_status'=>$check['language_review_status']??null,
            'editorial_review_status'=>$check['editorial_review_status']??null,
            'content_hash'=>$generated['content_hash']??null,
            'category_status'=>empty($derived['ok'])?'BLOCKED':'PASS',
            'category_slug'=>$derived['decision']['best']['slug']??null,
            'category_score_margin'=>$derived['decision']['score_margin']??null,
            'wordpress_runtime_validation_performed'=>false,
            'draft_created'=>false,'publish_allowed'=>false,
        );
    }

    public static function validate_generated_mutation($generated,$item,$fact_pack,$label) {
        if (!PPM679_WP::is_test_mode()) { return array('ok'=>false,'errors'=>array(self::err('BLOCKED_THREE_TYPE_MUTATION_LOCAL_ONLY','MUTATION_EVIDENCE_IS_LOCAL_TEST_ONLY','runtime.test_mode',true,false,'Negativmutationen dürfen nur lokal ausgeführt werden.'))); }
        $check=PPM679_Three_Type_Local_Content_Validator::evaluate($generated,$item,$fact_pack,'three_type_negative_'.$label);
        return array('ok'=>!empty($check['ok']),'errors'=>(array)($check['errors']??array()),'check'=>$check);
    }

    private static function blocked($errors,$results) {
        return array('ok'=>false,'status'=>'BLOCKED_THREE_TYPE_BUNDLED_SIGNED_QUARANTINE_PREFLIGHT','errors'=>array_values($errors),'results'=>$results,'drafts_created'=>0,'publish_allowed'=>false,'automatic_retry_allowed'=>false);
    }
    private static function test_post_count() { return method_exists('PPM679_WP','test_posts')?count((array)PPM679_WP::test_posts()):0; }
    private static function err($code,$rule,$path,$expected,$actual,$reason,$index=null) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,self::ACTION_CONTEXT,'',__CLASS__,$index,array('includes/three-type-bundled-local-preflight.php'));
    }
}
