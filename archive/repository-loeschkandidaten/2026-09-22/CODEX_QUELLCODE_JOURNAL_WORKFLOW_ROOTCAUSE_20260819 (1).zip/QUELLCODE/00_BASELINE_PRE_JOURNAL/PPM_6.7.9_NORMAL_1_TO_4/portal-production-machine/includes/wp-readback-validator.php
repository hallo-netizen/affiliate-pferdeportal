<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_WP_Readback_Validator {
    const VERSION='6.7.9';

    private static function scalar_meta($meta,$key) {
        $value=is_array($meta)&&array_key_exists($key,$meta)?$meta[$key]:null;
        if (is_array($value)) { $value=reset($value); }
        return $value;
    }
    private static function error($code,$rule,$path,$expected,$actual,$reason) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'qf03_readback','',__CLASS__,null,array('contracts/qf03-wordpress-draft-readback-dom-v1.json'));
    }
    private static function sorted_ints($values) { $values=array_values(array_unique(array_map('intval',(array)$values))); sort($values,SORT_NUMERIC); return $values; }

    public static function validate($snapshot,$expected,$context) {
        $snapshot=is_array($snapshot)?$snapshot:array();
        $expected=is_array($expected)?$expected:array();
        $context=is_array($context)?$context:array();
        $errors=array();
        if (($context['evidence_class']??'')!=='SERVER_USER_TRIGGERED_TEST' || ($context['user_triggered']??false)!==true) {
            $errors[]=self::error('BLOCKED_QF03_READBACK_EVIDENCE_CLASS','READBACK_PASS_REQUIRES_SERVER_USER_TRIGGERED_TEST','readback.context.evidence_class','SERVER_USER_TRIGGERED_TEST',$context['evidence_class']??null,'Lokale oder statische Evidenz darf keinen Server-Readback-PASS erzeugen.');
        }
        if (trim((string)($context['server_instance_id']??''))==='' || trim((string)($context['request_id']??''))==='' || trim((string)($context['artifact_id']??''))==='' || trim((string)($context['captured_at']??''))==='') {
            $errors[]=self::error('BLOCKED_QF03_READBACK_PROVENANCE_INCOMPLETE','SERVER_READBACK_REQUIRES_INSTANCE_REQUEST_ARTIFACT_AND_TIMESTAMP','readback.context.provenance','complete',array('server_instance_id'=>$context['server_instance_id']??null,'request_id'=>$context['request_id']??null,'artifact_id'=>$context['artifact_id']??null,'captured_at'=>$context['captured_at']??null),'Der Server-Readback besitzt keine vollständige Herkunftsbindung.');
        }
        $fields=array(
            'post_status'=>array('draft',(string)($snapshot['post_status']??'')),
            'post_type'=>array('post',(string)($snapshot['post_type']??'')),
            'post_title'=>array((string)($expected['title']??''),(string)($snapshot['post_title']??'')),
            'post_name'=>array((string)($expected['slug']??''),(string)($snapshot['post_name']??'')),
        );
        foreach ($fields as $field=>$pair) {
            if ($pair[0]==='' || $pair[1]!==$pair[0]) { $errors[]=self::error('BLOCKED_QF03_READBACK_'.strtoupper($field).'_MISMATCH','READBACK_FIELD_MUST_MATCH_EXACTLY','readback.'.$field,$pair[0],$pair[1],'Ein gespeichertes WordPress-Feld stimmt nicht exakt überein.'); }
        }
        $content=(string)($snapshot['post_content']??'');
        $content_hash=hash('sha256',$content);
        $expected_hash=(string)($expected['content_hash']??'');
        if ($expected_hash==='' || !hash_equals($expected_hash,$content_hash)) { $errors[]=self::error('BLOCKED_QF03_READBACK_CONTENT_HASH_MISMATCH','FULL_STORED_CONTENT_HASH_MUST_MATCH','readback.post_content_sha256',$expected_hash,$content_hash,'Der vollständige gespeicherte WordPress-Inhalt weicht vom geprüften Inhalt ab.'); }
        $categories=self::sorted_ints($snapshot['category_ids']??array());
        $expected_categories=self::sorted_ints($expected['categories']??array());
        if ($categories!==$expected_categories || !$categories) { $errors[]=self::error('BLOCKED_QF03_READBACK_CATEGORY_MISMATCH','STORED_CATEGORIES_MUST_MATCH_EXACTLY','readback.category_ids',$expected_categories,$categories,'Die gespeicherte Kategoriebindung stimmt nicht exakt.'); }
        $meta=is_array($snapshot['meta']??null)?$snapshot['meta']:array();
        $expected_meta=is_array($expected['meta']??null)?$expected['meta']:array();
        $meta_fields=array('_ppm679_test_marker','_ppm679_content_hash','_ppm679_editorially_reviewed_content_hash','_ppm679_gold_reference_hash','_ppm679_publish_blocked','_ppm679_qf03_gate');
        foreach(array('_ppm679_request_id','_ppm679_canonical_article_id','_ppm679_server_instance_id','_ppm679_build_manifest_sha256','_ppm679_planned_write_fingerprint','_ppm679_slug_decision','_ppm679_category_name','_ppm679_target_category_slug','_ppm679_category_hierarchy_path','_ppm679_category_taxonomy','_ppm679_category_snapshot_sha256','_ppm679_independent_category_decision_sha256','_ppm679_category_assignment_sha256','_ppm679_portal_level','_ppm679_portal_path','_ppm679_wp_parent_chain_slugs','_ppm679_wp_taxonomy_depth','_ppm679_wp_taxonomy_contract_hash','_ppm679_wp_taxonomy_snapshot_hash') as $stateful_field){if(array_key_exists($stateful_field,$expected_meta)){$meta_fields[]=$stateful_field;}}
        foreach ($meta_fields as $field) {
            $actual=(string)self::scalar_meta($meta,$field); $wanted=(string)($expected_meta[$field]??'');
            if ($wanted==='' || $actual!==$wanted) { $errors[]=self::error('BLOCKED_QF03_READBACK_META_MISMATCH','QF03_META_MUST_MATCH_EXACTLY','readback.meta.'.$field,$wanted,$actual,'Ein gespeichertes QF03-Metafeld stimmt nicht exakt.'); }
        }
        if ((string)self::scalar_meta($meta,'_ppm679_publish_blocked')!=='1') { $errors[]=self::error('BLOCKED_QF03_READBACK_PUBLISH_NOT_BLOCKED','STORED_DRAFT_MUST_KEEP_PUBLISH_BLOCKED','readback.meta._ppm679_publish_blocked','1',self::scalar_meta($meta,'_ppm679_publish_blocked'),'Die gespeicherte Publish-Sperre fehlt.'); }
        $stored_request=(string)self::scalar_meta($meta,'_ppm679_request_id');
        if($stored_request!=='' && $stored_request!==(string)($context['request_id']??'')){$errors[]=self::error('BLOCKED_QF03_STALE_READBACK_REQUEST','READBACK_MUST_BELONG_TO_CURRENT_RUN_IDENTITY','readback.meta._ppm679_request_id',$context['request_id']??null,$stored_request,'Der Readback gehört zu einer älteren oder fremden Laufidentität.');}
        $stored_server=(string)self::scalar_meta($meta,'_ppm679_server_instance_id');
        if($stored_server!=='' && $stored_server!==(string)($context['server_instance_id']??'')){$errors[]=self::error('BLOCKED_QF03_STALE_READBACK_SERVER','READBACK_MUST_BELONG_TO_BOUND_SERVER_INSTANCE','readback.meta._ppm679_server_instance_id',$context['server_instance_id']??null,$stored_server,'Der Readback gehört zu einer anderen Serverinstanz.');}
        $category_assignment=is_array($expected['category_assignment']??null)?$expected['category_assignment']:array();
        if($category_assignment){$errors=array_merge($errors,PPM679_Category_Assignment_Validator::validate_readback($snapshot,$category_assignment));}
                if ((int)($context['publish_event_count']??0)!==0) { $errors[]=self::error('BLOCKED_QF03_PUBLISH_EVENT_DETECTED','DRAFT_READBACK_MUST_HAVE_ZERO_PUBLISH_EVENTS','readback.context.publish_event_count',0,(int)$context['publish_event_count'],'Während des Draftlaufs wurde ein Publish-Ereignis registriert.'); }
        $item=array(
            'post_id'=>(int)($snapshot['ID']??0),'post_status'=>(string)($snapshot['post_status']??''),'post_type'=>(string)($snapshot['post_type']??''),
            'title'=>(string)($snapshot['post_title']??''),'slug'=>(string)($snapshot['post_name']??''),'content_hash'=>$content_hash,
            'category_ids'=>$categories,'test_marker'=>self::scalar_meta($meta,'_ppm679_test_marker'),'canonical_article_id'=>self::scalar_meta($meta,'_ppm679_canonical_article_id'),'planned_write_fingerprint'=>self::scalar_meta($meta,'_ppm679_planned_write_fingerprint'),'raw_snapshot_hash'=>PPM679_Diagnostic::stable_hash($snapshot),
            'evidence_class'=>$context['evidence_class']??null,'captured_at'=>$context['captured_at']??gmdate('c'),'server_instance_id'=>$context['server_instance_id']??null,'request_id'=>$context['request_id']??null,'artifact_id'=>$context['artifact_id']??null,'category_assignment_sha256'=>self::scalar_meta($meta,'_ppm679_category_assignment_sha256','_ppm679_portal_level','_ppm679_portal_path','_ppm679_wp_parent_chain_slugs','_ppm679_wp_taxonomy_depth','_ppm679_wp_taxonomy_contract_hash','_ppm679_wp_taxonomy_snapshot_hash'),'category_name'=>self::scalar_meta($meta,'_ppm679_category_name'),'category_slug'=>self::scalar_meta($meta,'_ppm679_target_category_slug'),'category_hierarchy_path'=>self::scalar_meta($meta,'_ppm679_category_hierarchy_path'),'portal_level'=>self::scalar_meta($meta,'_ppm679_portal_level'),'portal_path'=>self::scalar_meta($meta,'_ppm679_portal_path'),'wp_parent_chain_slugs'=>self::scalar_meta($meta,'_ppm679_wp_parent_chain_slugs'),'wp_taxonomy_depth'=>self::scalar_meta($meta,'_ppm679_wp_taxonomy_depth')
        );
        if ($errors) { return array('ok'=>false,'READBACK_STATUS'=>'BLOCKED','item'=>$item,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'qf03_readback','',array('item'=>$item,'READBACK_STATUS'=>'BLOCKED','publish_allowed'=>false))); }
        return array('ok'=>true,'READBACK_STATUS'=>'PASS','item'=>$item,'report'=>PPM679_Diagnostic::ok('QF03_READBACK_PASS','qf03_readback','',array('item'=>$item,'READBACK_STATUS'=>'PASS','publish_allowed'=>false,'editorial_quality_claimed'=>false)));
    }

    public static function validate_rejected_legacy_drafts($snapshots) {
        $required=array(9776,9777,9778,9779); $seen=array(); $errors=array(); $evidence=array();
        foreach ((array)$snapshots as $snapshot) {
            if (!is_array($snapshot)) { continue; }
            $id=(int)($snapshot['ID']??0); if (!in_array($id,$required,true)) { continue; }
            $seen[]=$id; $meta=is_array($snapshot['meta']??null)?$snapshot['meta']:array();
            $expected_meta=array('ppm_quality_state'=>'rejected','ppm_do_not_publish'=>'1','ppm_rejection_reason'=>'editorial_quality_fail','ppm_superseded_by_post_id'=>'');
            foreach ($expected_meta as $key=>$wanted) {
                $actual=(string)self::scalar_meta($meta,$key);
                if ($actual!==$wanted) { $errors[]=self::error('BLOCKED_QF03_LEGACY_REJECTION_META','LEGACY_BAD_DRAFT_MUST_REMAIN_REJECTED_AND_NOT_PUBLISHABLE','legacy['.$id.'].meta.'.$key,$wanted,$actual,'Ein historischer Fehlerdraft besitzt nicht die vorgeschriebene Ablehnungsmetadatenbindung.'); }
            }
            if (($snapshot['post_status']??'')!=='draft') { $errors[]=self::error('BLOCKED_QF03_LEGACY_DRAFT_STATUS','LEGACY_BAD_DRAFT_MUST_NOT_BE_PUBLISHED_OR_DELETED_AUTOMATICALLY','legacy['.$id.'].post_status','draft',$snapshot['post_status']??null,'Der historische Fehlerbeleg wurde automatisch verschoben, veröffentlicht oder gelöscht.'); }
            $evidence[]=array('post_id'=>$id,'title'=>(string)($snapshot['post_title']??''),'content_hash'=>hash('sha256',(string)($snapshot['post_content']??'')),'body_html'=>(string)($snapshot['post_content']??''),'body_text'=>trim(preg_replace('/\s+/u',' ',strip_tags((string)($snapshot['post_content']??'')))),'server_report'=>$snapshot['server_report']??null,'error_report'=>$snapshot['error_report']??null);
        }
        sort($seen,SORT_NUMERIC);
        if ($seen!==$required) { $errors[]=self::error('BLOCKED_QF03_LEGACY_DRAFT_SET_INCOMPLETE','ALL_FOUR_HISTORICAL_BAD_DRAFTS_MUST_BE_PRESERVED','legacy.post_ids',$required,$seen,'Die vier historischen Fehlerdrafts sind nicht vollständig als Evidenz vorhanden.'); }
        if ($errors) { return array('ok'=>false,'status'=>'BLOCKED','evidence'=>$evidence,'automatic_delete_allowed'=>false,'automatic_overwrite_allowed'=>false,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'qf03_legacy_rejected_drafts')); }
        return array('ok'=>true,'status'=>'LEGACY_REJECTED_DRAFTS_PRESERVED','evidence'=>$evidence,'automatic_delete_allowed'=>false,'automatic_overwrite_allowed'=>false,'user_decision_required'=>'KEEP_AS_REJECTED_DRAFT_OR_MOVE_TO_TRASH','report'=>PPM679_Diagnostic::ok('QF03_LEGACY_REJECTED_DRAFTS_PRESERVED','qf03_legacy_rejected_drafts','',array('post_ids'=>$required,'automatic_delete_allowed'=>false,'automatic_overwrite_allowed'=>false)));
    }

    public static function validate_batch($snapshots,$expectations,$context) {
        $snapshots=array_values((array)$snapshots); $expectations=array_values((array)$expectations); $context=is_array($context)?$context:array();
        $mode=(string)($context['certification_mode']??'SINGLE_FAQ_RECERTIFICATION');
        $expected_count=$mode==='FOUR_TYPE_FULL_CERTIFICATION'?4:1;
        $errors=array(); $items=array();
        if (count($snapshots)!==$expected_count || count($expectations)!==$expected_count) {
            $errors[]=self::error('BLOCKED_QF03_READBACK_BATCH_COUNT','READBACK_BATCH_COUNT_MUST_MATCH_CERTIFICATION_MODE','readback_batch.count',$expected_count,array('snapshots'=>count($snapshots),'expectations'=>count($expectations),'mode'=>$mode),'Die Anzahl der Readback-Drafts stimmt nicht mit dem freigegebenen Zertifizierungsmodus überein.');
        }
        $limit=min(count($snapshots),count($expectations));
        for($i=0;$i<$limit;$i++){
            $one=self::validate($snapshots[$i],$expectations[$i],$context);
            $items[]=$one;
            if(empty($one['ok'])){ foreach((array)($one['report']['errors']??array()) as $e){$errors[]=$e;} }
        }
        $four_status=$mode==='FOUR_TYPE_FULL_CERTIFICATION'
            ? (($expected_count===4 && !$errors)?'PASS':'BLOCKED')
            : 'NOT_YET_APPLICABLE_SINGLE_FAQ_REPAIR_SEQUENCE';
        $extra=array('certification_mode'=>$mode,'expected_draft_count'=>$expected_count,'actual_draft_count'=>count($snapshots),'four_draft_requirement_status'=>$four_status,'items'=>$items,'publish_allowed'=>false);
        if($errors){ return array('ok'=>false,'READBACK_STATUS'=>'BLOCKED','four_draft_requirement_status'=>$four_status,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'qf03_readback_batch','',$extra)); }
        return array('ok'=>true,'READBACK_STATUS'=>'PASS','four_draft_requirement_status'=>$four_status,'report'=>PPM679_Diagnostic::ok('QF03_READBACK_BATCH_PASS','qf03_readback_batch','',array_merge($extra,array('READBACK_STATUS'=>'PASS','editorial_quality_claimed'=>false))));
    }

}
