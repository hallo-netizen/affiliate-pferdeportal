<?php
require __DIR__.'/bootstrap-three-type.php';
$scope=PPM679_Three_Type_Bundled_Release_Validator::load(PPM679_Three_Type_Bundled_Release_Validator::INTEGRATION_SCOPE_FILE);
$binding=PPM679_Three_Type_Bundled_Release_Validator::load(PPM679_Three_Type_Bundled_Release_Validator::INTEGRATION_BINDING_FILE);
foreach(['scope'=>$scope,'binding'=>$binding] as $label=>$data){ppm_test_assert(is_array($data),$label.' traceability contract');$claimed=$data['contract_self_sha256'];unset($data['contract_self_sha256']);ppm_test_assert(hash_equals($claimed,PPM679_Diagnostic::stable_hash($data)),$label.' self hash');}
ppm_test_assert($binding['changed_existing_paths']===PPM679_Three_Type_Bundled_Release_Validator::AUTHORIZED_EXISTING_CHANGES,'only authorized loader and certification files changed');
ppm_test_assert($binding['registered_component_paths']===PPM679_Three_Type_Bundled_Release_Validator::REGISTERED_COMPONENTS,'registered component list');
foreach($binding['implementation_file_sha256'] as $relative=>$expected){$p=dirname(__DIR__,2).'/'.$relative;ppm_test_assert(is_file($p),$relative.' exists');ppm_test_assert(hash_equals($expected,hash_file('sha256',$p)),$relative.' exact hash');}
echo json_encode(['status'=>'PASS_THREE_TYPE_SIGNED_INTEGRATION_TRACEABILITY','bound_files'=>count($binding['implementation_file_sha256']),'changed_existing_paths'=>7,'registered_components'=>4],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
