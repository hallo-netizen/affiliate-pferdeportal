<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

PPM679_WP::reset_test_state();
$meta=json_decode((string)file_get_contents(__DIR__.'/fixtures/wave2/positive-faq.json'),true);
$html=(string)file_get_contents(__DIR__.'/fixtures/wave2/positive-faq.html');
$key='wave2-faq-item';
$hash=hash('sha256',$html);
$generated=array($key=>array(
    'article_type'=>'FAQ',
    'title'=>$meta['title'],
    'slug'=>'pferdeanhaenger-vor-fahrt-pruefen',
    'content_html'=>$html,
    'content_hash'=>$hash,
));
$check=array('items'=>array(array(
    'plan_item_key'=>$key,
    'technical_status'=>'TECHNICAL_CHECK_OK',
    'content_quality_status'=>'CONTENT_QUALITY_CHECK_OK',
    'content_hash'=>$hash,
    'fact_and_hash_status'=>'PASS',
    'editorial_machine_status'=>'PASS',
    'known_error_gate_status'=>'PASS',
    'general_template_repetition_status'=>'PASS',
    'gold_core_numeric_gate'=>'PASS',
    'editorial_review_status'=>'PASS',
    'gold_core_review_gate'=>'PASS',
    'control_baseline_status'=>'PASS',
    'server_check_status'=>'PASS',
    'editorially_reviewed_content_hash'=>$hash,
    'current_gold_reference_hash'=>str_repeat('a',64),
    'review_gold_reference_hash'=>str_repeat('a',64),
)));
$plan=array('qf03_context'=>array('simulation_only'=>true,'evidence_class'=>'LOCAL_EXECUTED_TEST','user_triggered'=>false,'nonce_verified'=>false),'items'=>array(array(
    'plan_item_key'=>$key,
    'quality_binding'=>$meta['quality_binding'],
)));
$gate=array('state'=>array('server_state_hash'=>'wave2-local-server-state'));

$create=new ReflectionMethod(PPM679_Pipeline::class,'create_drafts');
$create->setAccessible(true);
$readback=new ReflectionMethod(PPM679_Pipeline::class,'readback');
$readback->setAccessible(true);

$result=$create->invoke(null,'wave2-local-run',$generated,$check,$gate,$plan);
ppm_test_assert(!empty($result['ok']),'pipeline draft creation must succeed in isolated test mode');
ppm_test_assert(count($result['drafts'])===1,'exactly one isolated draft expected');
$postId=(int)$result['drafts'][0]['post_id'];
$post=PPM679_WP::get_post_snapshot($postId);
$marker=(string)$meta['quality_binding']['internal_test_marker'];
$categoryId=(int)$meta['quality_binding']['wordpress_category']['id'];
ppm_test_assert(is_array($post),'test post snapshot must exist');
ppm_test_assert(($post['meta']['_ppm679_test_marker']??'')===$marker,'marker must be stored only as internal meta');
ppm_test_assert(in_array($categoryId,$post['category_ids'],true),'real target category must be stored');
ppm_test_assert(($post['meta']['_ppm679_target_category_slug']??'')===$meta['quality_binding']['wordpress_category']['slug'],'category slug meta must match binding');
ppm_test_assert(strpos((string)$post['post_title'],$marker)===false,'marker must not be visible in title');
ppm_test_assert(strpos((string)$post['post_content'],$marker)===false,'marker must not be visible in body');
ppm_test_assert(stripos((string)$post['post_content'],'<h1')===false,'WordPress body must not contain H1');
ppm_test_assert(PPM679_WP::find_posts_by_meta_marker($marker)===array($postId),'marker search must find the existing draft across statuses');

$read=$readback->invoke(null,'wave2-local-run',$result['drafts'],$gate);
ppm_test_assert(!empty($read['ok']),'readback must verify exact title, body hash, marker and category');
ppm_test_assert(($read['items'][0]['readback_status']??'')==='STRUCTURAL_CHECK_OK','readback status must be structural check OK');

$collision=$create->invoke(null,'wave2-local-run-2',$generated,$check,$gate,$plan);
ppm_test_assert(empty($collision['ok']),'reused internal marker must be blocked');
$collisionCode=$collision['report']['errors'][0]['error_code']??'';
ppm_test_assert($collisionCode==='BLOCKED_WAVE2_TEST_MARKER_COLLISION','collision must have exact Wave-2 error code');

$report=array(
    'contract'=>'wave2_wordpress_binding_test_report_v1',
    'status'=>'PASS',
    'test_mode_only'=>true,
    'wordpress_accessed'=>false,
    'draft_snapshot'=>array(
        'post_id'=>$postId,
        'post_status'=>$post['post_status'],
        'visible_marker_in_title'=>false,
        'visible_marker_in_body'=>false,
        'body_h1_count'=>preg_match_all('/<h1\b/i',(string)$post['post_content']),
        'internal_meta_marker'=>$post['meta']['_ppm679_test_marker'],
        'category_ids'=>$post['category_ids'],
        'readback_status'=>$read['items'][0]['readback_status'],
    ),
    'collision_status'=>'BLOCKED',
    'collision_error_code'=>$collisionCode,
    'publish_allowed'=>false,
);
echo json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
