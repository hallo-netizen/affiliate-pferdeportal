<?php
if (!defined('ABSPATH')) { return; }
final class PPM679_Three_Type_Live_Test_Release_Validator {
 const VERSION='6.7.9';
 const CONTRACT_FILE='contracts/three-type-bundled-live-test-release-v1.json';
 const CANDIDATE_FILE='contracts/three-type-bundled-approved-candidates-v1.json';
 const INVENTORY_FILE='contracts/three-type-live-test-wordpress-inventory-32-v1.json';
 const CONTRACT='THREE_TYPE_BUNDLED_LIVE_TEST_RELEASE_GATE_V1';
 const SCOPE_MODE='THREE_TYPE_BUNDLED_SINGLE_SESSION_MAX_THREE_DRAFTS';
 const ACTION_CONTEXT='three_type_bundled_live_test_pre_draft';
 public static function load($relative=self::CONTRACT_FILE){$p=PPM679_PLUGIN_DIR.$relative;$d=is_file($p)?json_decode((string)file_get_contents($p),true):null;return is_array($d)?$d:null;}
 private static function fh($r){$p=PPM679_PLUGIN_DIR.$r;return is_file($p)?hash_file('sha256',$p):'';}
 public static function expected_scope(){return array('contract'=>self::CONTRACT,'scope_mode'=>self::SCOPE_MODE,'requested_article_types'=>array('Beratung','Vergleich','Pflege'),'release_contract_sha256'=>self::fh(self::CONTRACT_FILE),'approved_candidates_contract_sha256'=>self::fh(self::CANDIDATE_FILE),'inventory_contract_sha256'=>self::fh(self::INVENTORY_FILE),'maximum_total_new_drafts'=>3,'global_production_release_allowed'=>false,'publish_allowed'=>false,'wissen_allowed'=>false);}
 public static function validate($action_context,$server_state_hash,$scope,$override=null){
  $e=array();$c=$override!==null&&PPM679_WP::is_test_mode()?$override:self::load();
  if((string)$action_context!==self::ACTION_CONTEXT)$e[]=self::err('BLOCKED_THREE_TYPE_LIVE_ACTION_CONTEXT','THREE_TYPE_LIVE_RELEASE_REQUIRES_EXACT_ACTION_CONTEXT','action_context',self::ACTION_CONTEXT,$action_context,'Der Drei-Typ-Live-Testpfad wurde im falschen Kontext aufgerufen.',$action_context,$server_state_hash);
  if(!is_array($scope))return array_merge($e,array(self::err('BLOCKED_THREE_TYPE_LIVE_SCOPE_MISSING','THREE_TYPE_LIVE_RELEASE_REQUIRES_EXACT_SCOPE','scope','object',$scope,'Der gebundene Release-Scope fehlt.',$action_context,$server_state_hash)));
  foreach(self::expected_scope() as $k=>$v){$a=$scope[$k]??null;if(PPM679_Diagnostic::stable_hash($a)!==PPM679_Diagnostic::stable_hash($v))$e[]=self::err('BLOCKED_THREE_TYPE_LIVE_SCOPE_MISMATCH','THREE_TYPE_LIVE_RELEASE_SCOPE_MUST_MATCH','scope.'.$k,$v,$a,'Der Drei-Typ-Release-Scope weicht ab.',$action_context,$server_state_hash);}
  if(!is_array($c))return array_merge($e,array(self::err('BLOCKED_THREE_TYPE_LIVE_CONTRACT_MISSING','THREE_TYPE_LIVE_RELEASE_CONTRACT_MUST_LOAD','contract',self::CONTRACT,$c,'Der Release-Vertrag fehlt.',$action_context,$server_state_hash)));
  $claimed=(string)($c['contract_self_sha256']??'');$copy=$c;unset($copy['contract_self_sha256']);$actual=PPM679_Diagnostic::stable_hash($copy);if($claimed===''||!hash_equals($claimed,$actual))$e[]=self::err('BLOCKED_THREE_TYPE_LIVE_CONTRACT_HASH','THREE_TYPE_LIVE_RELEASE_CONTRACT_SELF_HASH_MUST_MATCH','contract.contract_self_sha256',$actual,$claimed,'Der Release-Vertrag wurde verändert.',$action_context,$server_state_hash);
  $pairs=array('contract'=>array(self::CONTRACT,$c['contract']??null),'scope_mode'=>array(self::SCOPE_MODE,$c['scope_mode']??null),'action_context'=>array(self::ACTION_CONTEXT,$c['action_context']??null),'approved_candidates_contract_sha256'=>array(self::fh(self::CANDIDATE_FILE),$c['approved_candidates_contract_sha256']??null),'inventory_contract_sha256'=>array(self::fh(self::INVENTORY_FILE),$c['inventory_contract_sha256']??null),'requested_article_types'=>array(array('Beratung','Vergleich','Pflege'),$c['requested_article_types']??null),'maximum_total_new_drafts'=>array(3,$c['maximum_total_new_drafts']??null),'publish_allowed'=>array(false,$c['publish_allowed']??null),'global_production_release_allowed'=>array(false,$c['global_production_release_allowed']??null),'wissen_allowed'=>array(false,$c['wissen_allowed']??null),'review_status'=>array('PENDING_CLAUDE_REVIEW',$c['independent_signed_release_review']['status']??null),'review_claimed'=>array(false,$c['independent_signed_release_review']['claimed_by_build']??null));
  foreach($pairs as $k=>$p){if(PPM679_Diagnostic::stable_hash($p[0])!==PPM679_Diagnostic::stable_hash($p[1]))$e[]=self::err('BLOCKED_THREE_TYPE_LIVE_CONTRACT_BINDING','THREE_TYPE_LIVE_RELEASE_FIELD_MUST_MATCH','contract.'.$k,$p[0],$p[1],'Eine feste Release-Bindung weicht ab.',$action_context,$server_state_hash);}
  $types=PPM679_Article_Type_Validator::load_contract();foreach(array('FAQ','Beratung','Vergleich','Pflege') as $t){if(($types['types'][$t]['production_allowed']??null)!==false)$e[]=self::err('BLOCKED_THREE_TYPE_GLOBAL_RELEASE_CHANGED','THREE_TYPE_TEST_MUST_NOT_GLOBALLY_RELEASE_TYPES','types.'.$t.'.production_allowed',false,$types['types'][$t]['production_allowed']??null,'Ein globaler Freigabeflag wurde geöffnet.',$action_context,$server_state_hash);}
  return $e;
 }
 private static function err($code,$rule,$path,$expected,$actual,$reason,$ctx,$hash){return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$ctx,$hash,__CLASS__,null,array(self::CONTRACT_FILE,self::CANDIDATE_FILE,self::INVENTORY_FILE));}
}
