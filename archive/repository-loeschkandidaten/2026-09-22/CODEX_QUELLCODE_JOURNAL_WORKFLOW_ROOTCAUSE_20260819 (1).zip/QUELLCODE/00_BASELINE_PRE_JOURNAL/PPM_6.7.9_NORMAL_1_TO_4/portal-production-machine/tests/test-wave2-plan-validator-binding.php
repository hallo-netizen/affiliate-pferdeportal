<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';

$meta=json_decode((string)file_get_contents(__DIR__.'/fixtures/wave2/positive-faq.json'),true);
$html=(string)file_get_contents(__DIR__.'/fixtures/wave2/positive-faq.html');
$plain=html_entity_decode($html,ENT_QUOTES|ENT_HTML5,'UTF-8');
$plain=(string)preg_replace('/<[^>]+>/u',' ',$plain);
$plain=trim((string)preg_replace('/\s+/u',' ',$plain));
$title=(string)$meta['title'];
$order=array(
    'order_id'=>'wave2-order-001',
    'article_type'=>'FAQ',
    'title'=>$title,
    'slug'=>'pferdeanhaenger-vor-fahrt-pruefen',
    'subject_scope'=>'Sichere Abfahrtskontrolle für Pferdeanhänger',
    'subject_label'=>'Pferdeanhänger vor der Fahrt prüfen',
    'lead'=>'Konkrete Prüfung vor der Abfahrt',
    'conclusion'=>'Nicht losfahren, solange eine technische oder rechtliche Grenze unklar ist.',
    'links'=>$meta['runtime_order']['links'],
    'allowed_fact_ids'=>array('fact-1','fact-2','fact-3'),
);
$item=array(
    'article_type'=>'FAQ',
    'topic'=>$title,
    'source_snapshot_id'=>'canonical-wave2-local-fact-pack',
    'runtime_order'=>$order,
    'quality_binding'=>$meta['quality_binding'],
    'quality_binding_hash'=>PPM679_Diagnostic::stable_hash($meta['quality_binding']),
    'canonical_article'=>array(
        'order_id'=>$order['order_id'],
        'article_type'=>'FAQ',
        'title'=>$title,
        'slug'=>$order['slug'],
        'body_html'=>$html,
        'body_text'=>$plain,
        'body_html_sha256'=>hash('sha256',$html),
        'content_plan_hash'=>hash('sha256','wave2-local-content-plan'),
    ),
);
$method=new ReflectionMethod(PPM679_Plan_Validator::class,'validate_runtime_payload');
$method->setAccessible(true);

function wave2_runtime_errors(ReflectionMethod $method,array $item): array {
    $errors=array();
    $args=array($item,0,&$errors,'wave2_plan_binding','local-wave2-server-state',false);
    $method->invokeArgs(null,$args);
    return $errors;
}
function wave2_codes(array $errors): array {
    return array_values(array_unique(array_map(static fn($e)=>(string)($e['error_code']??''),$errors)));
}

$positive=wave2_runtime_errors($method,$item);
ppm_test_assert($positive===array(),'complete Wave-2 runtime item must pass runtime payload validation');

$twoLinks=$item;
array_pop($twoLinks['runtime_order']['links']);
$twoLinkErrors=wave2_runtime_errors($method,$twoLinks);
ppm_test_assert(in_array('BLOCKED_CANONICAL_RUNTIME_LINK_PLAN',wave2_codes($twoLinkErrors),true),'two links must block exact link count');
ppm_test_assert(in_array('BLOCKED_WAVE2_RUNTIME_LINK_ROLES',wave2_codes($twoLinkErrors),true),'two links must block exact roles');

$wrongRoles=$item;
$wrongRoles['runtime_order']['links'][1]['role']='parent_category';
$wrongRoleErrors=wave2_runtime_errors($method,$wrongRoles);
ppm_test_assert(in_array('BLOCKED_WAVE2_RUNTIME_LINK_ROLES',wave2_codes($wrongRoleErrors),true),'duplicate/wrong roles must block');

$badHash=$item;
$badHash['quality_binding_hash']=str_repeat('0',64);
$badHashErrors=wave2_runtime_errors($method,$badHash);
ppm_test_assert(in_array('BLOCKED_WAVE2_QUALITY_BINDING_HASH',wave2_codes($badHashErrors),true),'quality binding hash mismatch must block');

$missingBinding=$item;
$missingBinding['quality_binding']=array();
$missingBinding['quality_binding_hash']='';
$missingErrors=wave2_runtime_errors($method,$missingBinding);
ppm_test_assert(in_array('BLOCKED_WAVE2_QUALITY_BINDING_MISSING',wave2_codes($missingErrors),true),'missing quality binding must block');

$report=array(
    'contract'=>'wave2_plan_validator_binding_report_v1',
    'status'=>'PASS',
    'positive_error_count'=>count($positive),
    'negative_cases'=>array(
        'two_links'=>wave2_codes($twoLinkErrors),
        'wrong_roles'=>wave2_codes($wrongRoleErrors),
        'quality_binding_hash_mismatch'=>wave2_codes($badHashErrors),
        'missing_quality_binding'=>wave2_codes($missingErrors),
    ),
    'publish_allowed'=>false,
);
echo json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
