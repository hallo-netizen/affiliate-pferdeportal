<?php
require_once __DIR__.'/fixture-builder.php';
$c=json_decode(file_get_contents(dirname(__DIR__,2).'/contracts/state-transition-matrix-v3-1.json'),true);
array_pop($c['scenarios']);$ids=array_column($c['scenarios'],'scenario_id');
ppm_test_assert(!in_array('V31-S12',$ids,true),'removed transition detected');
ppm_test_assert(count($c['scenarios'])===12,'incomplete scenario set');
echo json_encode(array('status'=>'PASS_V31_TRANSITION_NEGATIVE','simulated_blocker'=>'BLOCKED_V31_TRANSITION_SET_INCOMPLETE'),JSON_UNESCAPED_SLASHES)."\n";
