<?php
if (!defined('ABSPATH')) { return; }

/**
 * QF03 executable write boundary. No real wp_insert_post call may occur without
 * a one-use, payload-bound authorization issued by this class.
 */
final class PPM679_WP_Draft_Adapter {
    const VERSION='6.7.9';
    const CONTRACT='QF03_WORDPRESS_DRAFT_READBACK_AND_RENDERED_DOM_CONTRACT_V1';
    private static $issued=array();
    private static $last_gate_report=null;

    private static function pass_value($value) {
        return in_array((string)$value,array('PASS','TECHNICAL_CHECK_OK','CONTENT_QUALITY_CHECK_OK'),true);
    }

    private static function error($code,$rule,$path,$expected,$actual,$reason) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'qf03_draft_gate','',__CLASS__,null,array('contracts/qf03-wordpress-draft-readback-dom-v1.json'));
    }

    public static function evaluate_draft_gate($gate) {
        $gate=is_array($gate)?$gate:array();
        $errors=array();
        $required=array(
            'TECHNICAL_STATUS','FACT_AND_HASH_STATUS','EDITORIAL_MACHINE_STATUS',
            'KNOWN_ERROR_GATE_V1','GENERAL_TEMPLATE_REPETITION_STATUS',
            'GOLD_CORE_NUMERIC_GATE','EDITORIAL_REVIEW_STATUS','GOLD_CORE_REVIEW_GATE',
            'CONTROL_BASELINE_STATUS','SERVER_CHECK_STATUS'
        );
        foreach ($required as $field) {
            if (!self::pass_value($gate[$field]??null)) {
                $errors[]=self::error('BLOCKED_QF03_DRAFT_STATUS_'.$field,'QF03_DRAFT_REQUIRES_EXPLICIT_PASS_FOR_EVERY_STATUS','draft_gate.'.$field,'PASS',$gate[$field]??null,'Ein erforderlicher Draft-Status ist nicht ausdrücklich PASS.');
            }
        }
        $final_hash=(string)($gate['FINAL_CONTENT_HASH']??'');
        $reviewed_hash=(string)($gate['EDITORIALLY_REVIEWED_CONTENT_HASH']??'');
        if ($final_hash==='' || $reviewed_hash==='' || !hash_equals($final_hash,$reviewed_hash)) {
            $errors[]=self::error('BLOCKED_QF03_FINAL_REVIEWED_HASH_MISMATCH','FINAL_CONTENT_HASH_MUST_EQUAL_EDITORIALLY_REVIEWED_CONTENT_HASH','draft_gate.content_hashes',$reviewed_hash,$final_hash,'Der zu speichernde Inhalt ist nicht bytegenau der unabhängig geprüfte Inhalt.');
        }
        $current_gold=(string)($gate['CURRENT_GOLD_REFERENCE_HASH']??'');
        $review_gold=(string)($gate['REVIEW_GOLD_REFERENCE_HASH']??'');
        if ($current_gold==='' || $review_gold==='' || !hash_equals($current_gold,$review_gold)) {
            $errors[]=self::error('BLOCKED_QF03_GOLD_REFERENCE_HASH_MISMATCH','CURRENT_GOLD_REFERENCE_HASH_MUST_EQUAL_REVIEW_GOLD_REFERENCE_HASH','draft_gate.gold_reference_hashes',$review_gold,$current_gold,'Die aktuelle Goldreferenz weicht von der geprüften Goldreferenz ab.');
        }
        $context=array(
            'user_triggered'=>($gate['user_triggered']??false)===true,
            'nonce_verified'=>($gate['nonce_verified']??false)===true,
            'current_user_can_manage'=>($gate['current_user_can_manage']??false)===true,
            'article_count'=>(int)($gate['article_count']??0),
            'article_type'=>strtolower((string)($gate['article_type']??'')),
            'publish_allowed'=>($gate['publish_allowed']??null),
            'evidence_class'=>(string)($gate['evidence_class']??''),
            'simulation_only'=>($gate['simulation_only']??false)===true,
            'server_instance_id'=>trim((string)($gate['server_instance_id']??'')),
            'request_id'=>trim((string)($gate['request_id']??'')),
            'triggered_by_user_id'=>(int)($gate['triggered_by_user_id']??0),
        );
        $local_simulation=$context['simulation_only'] && PPM679_WP::is_test_mode();
        if (!$local_simulation && !$context['user_triggered']) { $errors[]=self::error('BLOCKED_QF03_NOT_USER_TRIGGERED','REAL_DRAFT_REQUIRES_EXPLICIT_USER_TRIGGERED_SERVER_TEST','draft_gate.user_triggered',true,$context['user_triggered'],'Der Lauf wurde nicht als explizit vom Nutzer ausgelöster Servertest gebunden.'); }
        if (!$local_simulation && !$context['nonce_verified']) { $errors[]=self::error('BLOCKED_QF03_NONCE_NOT_VERIFIED','REAL_DRAFT_REQUIRES_VERIFIED_NONCE','draft_gate.nonce_verified',true,$context['nonce_verified'],'Die Nonce wurde nicht erfolgreich geprüft.'); }
        if (!$local_simulation && ($context['server_instance_id']==='' || $context['request_id']==='' || $context['triggered_by_user_id']<=0)) { $errors[]=self::error('BLOCKED_QF03_SERVER_TRIGGER_IDENTITY_MISSING','SERVER_USER_TRIGGERED_TEST_REQUIRES_INSTANCE_REQUEST_AND_USER_ID','draft_gate.server_identity',array('server_instance_id'=>'non-empty','request_id'=>'non-empty','triggered_by_user_id'=>'>0'),array('server_instance_id'=>$context['server_instance_id'],'request_id'=>$context['request_id'],'triggered_by_user_id'=>$context['triggered_by_user_id']),'Der reale Servertest ist nicht vollständig an Instanz, Request und auslösenden Nutzer gebunden.'); }
        if (!$context['current_user_can_manage']) { $errors[]=self::error('BLOCKED_QF03_CAPABILITY_MISSING','REAL_DRAFT_REQUIRES_MANAGE_OPTIONS_CAPABILITY','draft_gate.current_user_can_manage',true,$context['current_user_can_manage'],'Die erforderliche Administratorberechtigung fehlt.'); }
        if ($context['article_count']!==1) { $errors[]=self::error('BLOCKED_QF03_SINGLE_ARTICLE_ONLY','G9_ALLOWS_EXACTLY_ONE_ARTICLE','draft_gate.article_count',1,$context['article_count'],'G9 darf exakt einen Artikel verarbeiten.'); }
        if ($context['article_type']!=='faq') { $errors[]=self::error('BLOCKED_QF03_FAQ_ONLY','G9_ALLOWS_ONLY_ONE_FAQ','draft_gate.article_type','faq',$context['article_type'],'Vor der Rezertifizierung anderer Typen ist ausschließlich FAQ zulässig.'); }
        if ($context['publish_allowed']!==false) { $errors[]=self::error('BLOCKED_QF03_PUBLISH_FLAG_NOT_FALSE','DRAFT_GATE_MUST_EXPLICITLY_PROHIBIT_PUBLISH','draft_gate.publish_allowed',false,$context['publish_allowed'],'Der Draftlauf muss Veröffentlichung ausdrücklich verbieten.'); }
        $allowed_evidence=$local_simulation ? $context['evidence_class']==='LOCAL_EXECUTED_TEST' : $context['evidence_class']==='SERVER_USER_TRIGGERED_TEST';
        if (!$allowed_evidence) { $errors[]=self::error('BLOCKED_QF03_EVIDENCE_CLASS','ONLY_SERVER_USER_TRIGGERED_TEST_MAY_AUTHORIZE_REAL_DRAFT_LOCAL_SIMULATION_IS_NOT_SERVER_PASS','draft_gate.evidence_class',($local_simulation?'LOCAL_EXECUTED_TEST':'SERVER_USER_TRIGGERED_TEST'),$context['evidence_class'],'Lokale oder statische Evidenz darf keinen Server-Draft autorisieren.'); }
        if (($gate['manual_override']??false)!==false || ($gate['time_pressure_exception']??false)!==false || ($gate['progress_exception']??false)!==false) {
            $errors[]=self::error('BLOCKED_QF03_OVERRIDE_FORBIDDEN','NO_MANUAL_TIME_OR_PROGRESS_OVERRIDE','draft_gate.override_flags',false,array('manual_override'=>$gate['manual_override']??null,'time_pressure_exception'=>$gate['time_pressure_exception']??null,'progress_exception'=>$gate['progress_exception']??null),'Revision 8 erlaubt keine technische, zeitliche oder fortschrittsbedingte Ausnahme.');
        }
        $report=$errors
            ? PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'qf03_draft_gate','',array('DRAFT_CREATE_ALLOWED'=>false,'publish_allowed'=>false))
            : PPM679_Diagnostic::ok($local_simulation?'QF03_LOCAL_SIMULATION_GATE_PASS_NOT_SERVER_PASS':'QF03_DRAFT_GATE_PASS','qf03_draft_gate','',array('DRAFT_CREATE_ALLOWED'=>!$local_simulation,'DRAFT_CREATE_ALLOWED_SIMULATION'=>$local_simulation,'write_allowed_in_current_environment'=>true,'publish_allowed'=>false,'evidence_class'=>$context['evidence_class'],'server_pass_claimed'=>false));
        self::$last_gate_report=$report;
        return array('ok'=>!$errors,'DRAFT_CREATE_ALLOWED'=>(!$errors && !$local_simulation),'DRAFT_CREATE_ALLOWED_SIMULATION'=>(!$errors && $local_simulation),'write_allowed_in_current_environment'=>!$errors,'report'=>$report);
    }

    private static function payload_hash($payload) {
        $normalized=array(
            'title'=>(string)($payload['title']??''),
            'content'=>(string)($payload['content']??''),
            'slug'=>(string)($payload['slug']??''),
            'meta'=>is_array($payload['meta']??null)?$payload['meta']:array(),
            'categories'=>array_values(array_map('intval',(array)($payload['categories']??array()))),
            'post_status'=>'draft',
            'post_type'=>'post'
        );
        return PPM679_Diagnostic::stable_hash($normalized);
    }

    public static function issue_write_authorization($payload,$gate) {
        $result=self::evaluate_draft_gate($gate);
        if (empty($result['ok'])) { return array('ok'=>false,'authorization'=>null,'report'=>$result['report']); }
        $payload=is_array($payload)?$payload:array();
        $content_hash=hash('sha256',(string)($payload['content']??''));
        if (!hash_equals((string)$gate['FINAL_CONTENT_HASH'],$content_hash)) {
            $error=self::error('BLOCKED_QF03_PAYLOAD_CONTENT_HASH_MISMATCH','AUTHORIZED_PAYLOAD_MUST_MATCH_FINAL_REVIEWED_HASH','draft_payload.content_hash',(string)$gate['FINAL_CONTENT_HASH'],$content_hash,'Der konkrete WordPress-Payload weicht vom geprüften Inhalt ab.');
            return array('ok'=>false,'authorization'=>null,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'qf03_draft_gate','',array('DRAFT_CREATE_ALLOWED'=>false)));
        }
        $meta=is_array($payload['meta']??null)?$payload['meta']:array();
        $categories=array_values(array_filter(array_map('intval',(array)($payload['categories']??array())),function($v){return $v>0;}));
        $required_meta=array('_ppm679_test_marker','_ppm679_content_hash','_ppm679_editorially_reviewed_content_hash','_ppm679_gold_reference_hash','_ppm679_publish_blocked','_ppm679_qf03_gate');
        if (($gate['stateful_e2e_required']??false)===true) {
            $required_meta=array_merge($required_meta,array('_ppm679_request_id','_ppm679_canonical_article_id','_ppm679_server_instance_id','_ppm679_build_manifest_sha256','_ppm679_planned_write_fingerprint','_ppm679_slug_decision'));
        }
        foreach ($required_meta as $field) {
            if (!array_key_exists($field,$meta) || (string)$meta[$field]==='') {
                $error=self::error('BLOCKED_QF03_REQUIRED_META_MISSING','QF03_DRAFT_PAYLOAD_REQUIRES_COMPLETE_BINDING_META','draft_payload.meta.'.$field,'non-empty',$meta[$field]??null,'Ein bindendes QF03-Metafeld fehlt.');
                return array('ok'=>false,'authorization'=>null,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'qf03_draft_gate','',array('DRAFT_CREATE_ALLOWED'=>false)));
            }
        }
        if ((string)$meta['_ppm679_publish_blocked']!=='1' || (string)$meta['_ppm679_qf03_gate']!=='PASS') {
            $error=self::error('BLOCKED_QF03_DRAFT_META_INVALID','QF03_META_MUST_KEEP_PUBLISH_BLOCKED_AND_GATE_PASS','draft_payload.meta',array('_ppm679_publish_blocked'=>'1','_ppm679_qf03_gate'=>'PASS'),array('_ppm679_publish_blocked'=>$meta['_ppm679_publish_blocked']??null,'_ppm679_qf03_gate'=>$meta['_ppm679_qf03_gate']??null),'Der Draft-Payload enthält keine eindeutige Publish-Sperre oder QF03-Bindung.');
            return array('ok'=>false,'authorization'=>null,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'qf03_draft_gate','',array('DRAFT_CREATE_ALLOWED'=>false)));
        }
        if (($gate['stateful_e2e_required']??false)===true) {
            $fp=(string)($meta['_ppm679_planned_write_fingerprint']??'');
            if(!preg_match('/^[a-f0-9]{64}$/',$fp) || !hash_equals((string)($gate['PLANNED_WRITE_FINGERPRINT']??''),$fp)){
                $error=self::error('BLOCKED_QF03_WRITE_AUTH_FINGERPRINT','WRITE_AUTHORIZATION_MUST_BIND_EXACT_DRY_RUN_FINGERPRINT','draft_payload.meta._ppm679_planned_write_fingerprint',$gate['PLANNED_WRITE_FINGERPRINT']??null,$fp,'Die einmalige Schreibautorisierung gehört nicht zur schreibfreien Generalprobe.');
                return array('ok'=>false,'authorization'=>null,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'qf03_draft_gate','',array('DRAFT_CREATE_ALLOWED'=>false)));
            }
        }
        if (!$categories) {
            $error=self::error('BLOCKED_QF03_CATEGORY_MISSING','QF03_DRAFT_REQUIRES_REAL_CATEGORY','draft_payload.categories','one or more positive category ids',$categories,'Die Zielkategorie fehlt.');
            return array('ok'=>false,'authorization'=>null,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'qf03_draft_gate','',array('DRAFT_CREATE_ALLOWED'=>false)));
        }
        $payload_hash=self::payload_hash($payload);
        try { $random=bin2hex(random_bytes(32)); } catch (Throwable $e) { $random=hash('sha256',microtime(true).'|'.mt_rand()); }
        $token=hash('sha256',$payload_hash.'|'.PPM679_Diagnostic::stable_hash($gate).'|'.$random);
        self::$issued[$token]=array('payload_hash'=>$payload_hash,'used'=>false,'issued_at'=>gmdate('c'),'gate_hash'=>PPM679_Diagnostic::stable_hash($gate));
        return array('ok'=>true,'authorization'=>array('contract'=>self::CONTRACT,'token'=>$token,'payload_hash'=>$payload_hash,'one_use'=>true,'post_status'=>'draft','publish_allowed'=>false),'report'=>$result['report']);
    }

    public static function verify_write_authorization($authorization,$payload,$consume=false) {
        $authorization=is_array($authorization)?$authorization:array();
        $token=(string)($authorization['token']??'');
        if ($token==='' || !isset(self::$issued[$token])) { return false; }
        $record=self::$issued[$token];
        if (!empty($record['used'])) { return false; }
        $payload_hash=self::payload_hash($payload);
        if (!hash_equals((string)$record['payload_hash'],$payload_hash) || !hash_equals((string)($authorization['payload_hash']??''),$payload_hash)) { return false; }
        if (($authorization['post_status']??'')!=='draft' || ($authorization['publish_allowed']??null)!==false) { return false; }
        if ($consume) { self::$issued[$token]['used']=true; }
        return true;
    }

    public static function create_single_faq_draft($candidate,$gate,$stateful_plan=null) {
        $candidate=is_array($candidate)?$candidate:array();
        $gate=is_array($gate)?$gate:array();
        if (strtolower((string)($candidate['article_type']??''))!=='faq') {
            $error=self::error('BLOCKED_QF03_FAQ_ONLY','QF03_SINGLE_DRAFT_ADAPTER_ACCEPTS_FAQ_ONLY','candidate.article_type','faq',$candidate['article_type']??null,'Der Adapter darf vor weiterer Rezertifizierung nur einen FAQ verarbeiten.');
            return array('ok'=>false,'post_id'=>0,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'qf03_draft_create'));
        }

        if ($stateful_plan!==null) {
            if(!class_exists('PPM679_Stateful_Write_Gate')){
                $error=self::error('BLOCKED_V31_STATEFUL_GATE_MISSING','STATEFUL_WRITE_PLAN_REQUIRES_VALIDATOR','stateful_write_gate','loaded class',null,'Der V3.1-Schreibplan kann nicht geprüft werden.');
                return array('ok'=>false,'post_id'=>0,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'qf03_draft_create'));
            }
            $plan_errors=PPM679_Stateful_Write_Gate::validate_plan($stateful_plan,$candidate,$gate,true);
            if($plan_errors){return array('ok'=>false,'post_id'=>0,'report'=>PPM679_Diagnostic::blocked($plan_errors[0]['error_code'],$plan_errors,'qf03_draft_create','',array('write_attempted'=>false)));}
            $payload=(array)($stateful_plan['payload']??array());
            $gate['stateful_e2e_required']=true;
            $gate['PLANNED_WRITE_FINGERPRINT']=(string)($stateful_plan['planned_write_fingerprint']??'');
        } else {
            $content=(string)($candidate['content_html']??'');
            $content_hash=hash('sha256',$content);
            $marker=trim((string)($candidate['internal_test_marker']??''));
            $category_id=(int)($candidate['category_id']??0);
            if ($marker==='' || $category_id<=0) {
                $error=self::error('BLOCKED_QF03_BINDING_MISSING','QF03_CANDIDATE_REQUIRES_MARKER_AND_CATEGORY','candidate.binding',array('marker'=>'non-empty','category_id'=>'>0'),array('marker'=>$marker,'category_id'=>$category_id),'Marker oder Kategorie fehlt.');
                return array('ok'=>false,'post_id'=>0,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'qf03_draft_create'));
            }
            if (PPM679_WP::find_posts_by_meta_marker($marker,'_ppm679_test_marker')) {
                $error=self::error('BLOCKED_QF03_MARKER_COLLISION','QF03_TEST_MARKER_MUST_BE_GLOBALLY_UNIQUE','candidate.internal_test_marker','no existing post',$marker,'Der interne Testmarker ist bereits vorhanden.');
                return array('ok'=>false,'post_id'=>0,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'qf03_draft_create'));
            }
            $meta=array(
                '_ppm679_run_id'=>(string)($candidate['run_id']??''),
                '_ppm679_article_type'=>'faq',
                '_ppm679_content_hash'=>$content_hash,
                '_ppm679_editorially_reviewed_content_hash'=>(string)($gate['EDITORIALLY_REVIEWED_CONTENT_HASH']??''),
                '_ppm679_gold_reference_hash'=>(string)($gate['REVIEW_GOLD_REFERENCE_HASH']??''),
                '_ppm679_test_marker'=>$marker,
                '_ppm679_target_category_slug'=>(string)($candidate['category_slug']??''),
                '_ppm679_publish_blocked'=>'1',
                '_ppm679_qf03_gate'=>'PASS'
            );
            $payload=array('title'=>(string)($candidate['title']??''),'content'=>$content,'slug'=>(string)($candidate['slug']??''),'meta'=>$meta,'categories'=>array($category_id));
        }

        $auth=self::issue_write_authorization($payload,$gate);
        if (empty($auth['ok'])) { return array('ok'=>false,'post_id'=>0,'report'=>$auth['report']); }
        $post_id=PPM679_WP::insert_draft($payload['title'],$payload['content'],$payload['slug'],$payload['meta'],$payload['categories'],$auth['authorization']);
        if ((int)$post_id<=0) {
            $error=self::error('BLOCKED_QF03_WORDPRESS_DRAFT_CREATE_FAILED','AUTHORIZED_QF03_PAYLOAD_MUST_CREATE_DRAFT_ONLY','wordpress.post_id','positive integer',$post_id,'WordPress hat den autorisierten Draft nicht angelegt.');
            return array('ok'=>false,'post_id'=>0,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'qf03_draft_create'));
        }
        $simulation=($gate['simulation_only']??false)===true && PPM679_WP::is_test_mode();
        $content_hash=hash('sha256',(string)$payload['content']);
        $extra=array('post_id'=>(int)$post_id,'post_status'=>'draft','publish_allowed'=>false,'DRAFT_CREATE_ALLOWED'=>!$simulation,'DRAFT_CREATE_ALLOWED_SIMULATION'=>$simulation,'server_pass_claimed'=>false);
        if($stateful_plan!==null){$extra['planned_write_fingerprint']=(string)$stateful_plan['planned_write_fingerprint'];$extra['request_id']=(string)($stateful_plan['identity']['request_id']??'');$extra['run_marker']=(string)($stateful_plan['identity']['run_marker']??'');$extra['single_write_chokepoint']='PPM679_WP::insert_draft';}
        return array('ok'=>true,'post_id'=>(int)$post_id,'expected'=>array('post_status'=>'draft','post_type'=>'post','title'=>$payload['title'],'slug'=>$payload['slug'],'content_hash'=>$content_hash,'categories'=>array_values(array_map('intval',(array)$payload['categories'])),'meta'=>$payload['meta'],'category_assignment'=>is_array($stateful_plan)?(array)($stateful_plan['category_assignment']??array()):array()),'report'=>PPM679_Diagnostic::ok($simulation?'QF03_LOCAL_SIMULATED_FAQ_DRAFT_CREATED_NOT_SERVER_PASS':'QF03_SINGLE_FAQ_DRAFT_CREATED','qf03_draft_create','',$extra));
    }

    public static function evaluate_publish_gate($input) {
        $input=is_array($input)?$input:array();
        $required=array('DRAFT_CREATE_ALLOWED'=>true,'SERVER_CHECK_STATUS'=>'PASS','READBACK_STATUS'=>'PASS','RENDERED_DOM_STATUS'=>'PASS');
        $errors=array();
        foreach ($required as $field=>$expected) {
            $actual=$input[$field]??null;
            $ok=is_bool($expected)?$actual===$expected:(string)$actual===$expected;
            if (!$ok) { $errors[]=self::error('BLOCKED_QF03_PUBLISH_'.$field,'PUBLISH_PRECONDITION_MUST_PASS','publish_gate.'.$field,$expected,$actual,'Eine Publish-Vorbedingung fehlt.'); }
        }
        foreach (array(array('DRAFT_CONTENT_HASH','READBACK_CONTENT_HASH'),array('READBACK_CONTENT_HASH','EDITORIALLY_REVIEWED_CONTENT_HASH')) as $pair) {
            $a=(string)($input[$pair[0]]??''); $b=(string)($input[$pair[1]]??'');
            if ($a==='' || $b==='' || !hash_equals($a,$b)) { $errors[]=self::error('BLOCKED_QF03_PUBLISH_HASH_CHAIN','PUBLISH_HASH_CHAIN_MUST_BE_EXACT','publish_gate.'.$pair[0].'_vs_'.$pair[1],$b,$a,'Die Publish-Hashkette ist nicht bytegenau geschlossen.'); }
        }
        if (($input['separate_user_publish_approval']??false)!==true) { $errors[]=self::error('BLOCKED_QF03_SEPARATE_PUBLISH_APPROVAL_MISSING','PUBLISH_REQUIRES_SEPARATE_HUMAN_DECISION','publish_gate.separate_user_publish_approval',true,$input['separate_user_publish_approval']??null,'Draftabnahme und Publish-Freigabe sind getrennte Entscheidungen.'); }
        if ($errors) { return array('ok'=>false,'PUBLISH_ALLOWED'=>false,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'qf03_publish_gate')); }
        return array('ok'=>true,'PUBLISH_ALLOWED'=>true,'executor_registered'=>false,'report'=>PPM679_Diagnostic::ok('QF03_PUBLISH_PRECONDITIONS_SATISFIED_NO_EXECUTOR','qf03_publish_gate','',array('PUBLISH_ALLOWED'=>true,'executor_registered'=>false,'separate_human_action_required'=>true)));
    }

    public static function reset_test_state() { self::$issued=array(); self::$last_gate_report=null; }
    public static function last_gate_report() { return self::$last_gate_report; }
}
