<?php
require_once __DIR__.'/fixture-builder.php';
$s=v34_snapshot();$s['contract']='WRONG';
$e=PPM679_Category_Hierarchy_Validator::validate($s);
ppm_test_assert(!empty($e),'unbound source must block');
echo "PASS_V34_SOURCE_UNBOUND_BLOCKED\n";
