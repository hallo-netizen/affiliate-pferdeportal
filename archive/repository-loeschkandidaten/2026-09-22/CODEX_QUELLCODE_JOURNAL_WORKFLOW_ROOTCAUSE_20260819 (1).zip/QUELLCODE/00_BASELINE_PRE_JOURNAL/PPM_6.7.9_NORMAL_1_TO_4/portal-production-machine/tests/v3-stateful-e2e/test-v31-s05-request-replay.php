<?php
require_once __DIR__.'/fixture-builder.php';
PPM679_WP::reset_test_state();PPM679_Storage::reset_test_state();
$req='g9-request-v31-replay-0005';
$first=v31_execute_g9($req);ppm_test_assert($first['ok']===true,'first request');
PPM679_Stateful_Write_Gate::reset_test_state();
$second=v31_execute_g9($req);
ppm_test_assert($second['ok']===false,'same request replay must block');
ppm_test_assert(v31_status($second)==='BLOCKED_QF03_REQUEST_REPLAY','request replay code');
ppm_test_assert(count(PPM679_WP::test_posts())===1,'no second draft');
echo json_encode(array('status'=>'PASS_V31_S05_REQUEST_REPLAY','blocker'=>v31_status($second),'draft_count'=>1),JSON_UNESCAPED_SLASHES)."\n";
