<?php
require_once __DIR__.'/fixture-builder.php';
$p=v31_prepare('g9-request-v31-after-write-0008',true);ppm_test_assert($p['ok']===true,'prepare');
$w=v31_write_prepared($p);ppm_test_assert($w['ok']===true,'single write');
PPM679_Stateful_Write_Gate::reset_test_state();
$id=PPM679_Stateful_Write_Gate::build_identity('canonical-faq-001','ppm-test-instance-679',v31_build_hash(),'g9-request-v31-after-write-0008');
ppm_test_assert($id['ok']===false,'recovery replay cannot write a second draft');
ppm_test_assert(v31_status($id)==='BLOCKED_QF03_REQUEST_REPLAY','request persistence detected');
ppm_test_assert(count(PPM679_WP::test_posts())===2,'old plus one new');
echo json_encode(array('status'=>'PASS_V31_S08_ABORT_AFTER_WRITE','post_id'=>$w['post_id'],'replay_blocker'=>v31_status($id)),JSON_UNESCAPED_SLASHES)."\n";
