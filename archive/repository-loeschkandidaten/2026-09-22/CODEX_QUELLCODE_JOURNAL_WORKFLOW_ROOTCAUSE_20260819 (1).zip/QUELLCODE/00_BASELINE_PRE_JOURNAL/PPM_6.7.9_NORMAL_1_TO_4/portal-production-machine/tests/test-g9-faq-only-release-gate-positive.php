<?php
require_once __DIR__.'/bootstrap-test.php';
PPM679_WP::reset_test_state();
$scope=PPM679_G9_FAQ_Test_Release_Validator::expected_scope();
$errors=PPM679_G9_FAQ_Test_Release_Validator::validate('g9_single_faq_pre_draft','test-state',$scope);
ppm_test_assert($errors===array(),'exact G9 FAQ test release scope must pass');
$global=PPM679_Article_Type_Validator::validate('four_type_production','test-state');
$codes=array_column($global,'error_code');
ppm_test_assert(count(array_filter($codes,fn($c)=>$c==='BLOCKED_ARTICLE_TYPE_NOT_PRODUCTION_ALLOWED'))===4,'global validator must still block all four types');
echo json_encode(array(
 'status'=>'PASS_G9_FAQ_ONLY_RELEASE_GATE_POSITIVE',
 'scoped_error_count'=>count($errors),
 'global_not_production_allowed_count'=>count(array_filter($codes,fn($c)=>$c==='BLOCKED_ARTICLE_TYPE_NOT_PRODUCTION_ALLOWED')),
 'global_contract_modified'=>false,
 'publish_allowed'=>false
),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n";
