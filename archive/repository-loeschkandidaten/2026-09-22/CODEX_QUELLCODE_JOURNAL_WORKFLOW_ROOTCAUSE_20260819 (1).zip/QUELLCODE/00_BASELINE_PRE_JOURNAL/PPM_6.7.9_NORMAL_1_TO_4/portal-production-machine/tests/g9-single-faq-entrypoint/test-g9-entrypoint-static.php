<?php
require_once dirname(__DIR__).'/bootstrap-test.php';
$admin=file_get_contents(dirname(__DIR__,2).'/includes/admin.php');
$plan=file_get_contents(dirname(__DIR__,2).'/includes/plan-validator.php');
$entry=file_get_contents(dirname(__DIR__,2).'/includes/g9-single-faq-entrypoint.php');
ppm_test_assert(strpos($plan,'count($items)<1 || count($items)>4')!==false,'production plan cardinality must remain 1..4');
ppm_test_assert(strpos($entry,'admin_post_'."'.self::ACTION")!==false || strpos($entry,"admin_post_")!==false,'separate admin action must be registered');
ppm_test_assert(strpos($entry,'PPM679_Pipeline::execute_plan')===false,'separate G9 path must not reuse four-type pipeline');
ppm_test_assert(substr_count($admin,'PPM679_Pipeline::execute_plan($plan)')===1,'legacy four-type admin path must remain exactly once');
echo json_encode(array('status'=>'PASS','separate_action'=>true,'four_type_execute_plan_calls'=>1,'plan_validator_cardinality'=>'1..4'),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
