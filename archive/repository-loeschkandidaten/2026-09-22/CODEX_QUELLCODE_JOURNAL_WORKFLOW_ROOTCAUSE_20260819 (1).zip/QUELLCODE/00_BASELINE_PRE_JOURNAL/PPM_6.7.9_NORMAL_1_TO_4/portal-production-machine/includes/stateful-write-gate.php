<?php
if (!defined('ABSPATH')) { return; }

/**
 * V3.1 stateful pre-write gate.
 *
 * It separates canonical article identity, one-run identity and persisted post identity.
 * The same validated plan and fingerprint are used by the dry-run and the single write chokepoint.
 */
final class PPM679_Stateful_Write_Gate {
    const VERSION='6.7.9';
    const CONTRACT_FILE='contracts/stateful-e2e-write-gate-v3-1.json';
    const CONTRACT='PPM679_STATEFUL_E2E_WRITE_GATE_V3_1';
    private static $reserved_requests=array();
    private static $reserved_markers=array();

    private static function err($code,$rule,$path,$expected,$actual,$reason,$context='v31_stateful_write_gate') {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$context,'',__CLASS__,null,array(self::CONTRACT_FILE));
    }

    private static function load_contract() {
        $p=PPM679_PLUGIN_DIR.self::CONTRACT_FILE;
        $d=is_file($p)?json_decode((string)file_get_contents($p),true):null;
        return is_array($d)?$d:null;
    }

    private static function contract_errors() {
        $c=self::load_contract(); $errors=array();
        if(!is_array($c)){return array(self::err('BLOCKED_V31_STATEFUL_CONTRACT_MISSING','STATEFUL_E2E_CONTRACT_MUST_EXIST','stateful.contract',self::CONTRACT_FILE,null,'Der V3.1-Zustandsvertrag fehlt.'));}
        $self=(string)($c['contract_self_sha256']??'');$copy=$c;unset($copy['contract_self_sha256']);
        $actual=PPM679_Diagnostic::stable_hash($copy);
        if($self===''||!hash_equals($self,$actual)){$errors[]=self::err('BLOCKED_V31_STATEFUL_CONTRACT_HASH','STATEFUL_E2E_CONTRACT_SELF_HASH_MUST_MATCH','stateful.contract.contract_self_sha256',$actual,$self,'Der V3.1-Zustandsvertrag wurde verändert.');}
        if(($c['contract']??'')!==self::CONTRACT){$errors[]=self::err('BLOCKED_V31_STATEFUL_CONTRACT_ID','STATEFUL_E2E_CONTRACT_ID_MUST_MATCH','stateful.contract.contract',self::CONTRACT,$c['contract']??null,'Der V3.1-Zustandsvertrag besitzt die falsche Kennung.');}
        return $errors;
    }

    private static function valid_sha($v){return preg_match('/^[a-f0-9]{64}$/',(string)$v)===1;}

    public static function build_identity($canonical_article_id,$server_instance_id,$build_manifest_sha256,$request_id_override=null) {
        $errors=self::contract_errors();
        $canonical_article_id=trim((string)$canonical_article_id);
        $server_instance_id=trim((string)$server_instance_id);
        $build_manifest_sha256=strtolower(trim((string)$build_manifest_sha256));
        if($canonical_article_id===''){$errors[]=self::err('BLOCKED_V31_CANONICAL_ID_MISSING','CANONICAL_ARTICLE_IDENTITY_MUST_BE_NON_EMPTY','identity.canonical_article_id','non-empty',$canonical_article_id,'Die kanonische Artikelidentität fehlt.');}
        if($server_instance_id===''){$errors[]=self::err('BLOCKED_V31_SERVER_ID_MISSING','RUN_IDENTITY_MUST_BIND_SERVER_INSTANCE','identity.server_instance_id','non-empty',$server_instance_id,'Die Serverinstanzbindung fehlt.');}
        if(!self::valid_sha($build_manifest_sha256)){$errors[]=self::err('BLOCKED_V31_BUILD_HASH_INVALID','RUN_IDENTITY_MUST_BIND_BUILD_MANIFEST_SHA256','identity.build_manifest_sha256','sha256',$build_manifest_sha256,'Die Laufidentität ist nicht an einen gültigen Buildmanifest-Hash gebunden.');}
        if($request_id_override!==null && !PPM679_WP::is_test_mode()){$errors[]=self::err('BLOCKED_V31_REQUEST_OVERRIDE_FORBIDDEN','REQUEST_OVERRIDE_ALLOWED_ONLY_IN_LOCAL_TEST_MODE','identity.request_id_override',null,'provided','Eine vorgegebene Request-ID ist im echten Serverlauf verboten.');}
        if($errors){return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'v31_identity_build'));}

        if($request_id_override!==null){$request_id=trim((string)$request_id_override);}
        else{
            try{$random=bin2hex(random_bytes(24));}
            catch(Throwable $e){$random=hash('sha256',microtime(true).'|'.mt_rand().'|'.$canonical_article_id.'|'.$server_instance_id);}
            $request_id='g9-request-'.substr($random,0,32);
        }
        if(!preg_match('/^g9-request-[a-z0-9-]{12,80}$/',$request_id)){
            $error=self::err('BLOCKED_V31_REQUEST_ID_FORMAT','RUN_REQUEST_ID_MUST_MATCH_BOUND_FORMAT','identity.request_id','g9-request-*',$request_id,'Die Request-ID besitzt kein zulässiges Format.');
            return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'v31_identity_build'));
        }
        $marker='LT2-FAQ-RUN-'.strtoupper(substr(hash('sha256',$canonical_article_id.'|'.$request_id.'|'.$server_instance_id.'|'.$build_manifest_sha256),0,16));

        $request_posts=PPM679_WP::find_posts_by_meta_value('_ppm679_request_id',$request_id);
        if($request_posts || isset(self::$reserved_requests[$request_id])){
            $error=self::err('BLOCKED_QF03_REQUEST_REPLAY','QF03_REQUEST_ID_MUST_NOT_AUTHORIZE_A_SECOND_DRAFT','identity.request_id','unused request id',$request_id,'Diese Request-ID wurde bereits verwendet oder für einen laufenden Schreibplan reserviert.');
            return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'v31_identity_build','',array('existing_post_ids'=>self::ids($request_posts))));
        }
        $marker_posts=PPM679_WP::find_posts_by_meta_value('_ppm679_test_marker',$marker);
        if($marker_posts || isset(self::$reserved_markers[$marker])){
            $error=self::err('BLOCKED_QF03_MARKER_COLLISION','QF03_TEST_MARKER_MUST_BE_GLOBALLY_UNIQUE','identity.run_marker','unused marker',$marker,'Der neu abgeleitete Laufmarker kollidiert mit einem vorhandenen oder reservierten Lauf.');
            return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'v31_identity_build','',array('existing_post_ids'=>self::ids($marker_posts))));
        }
        self::$reserved_requests[$request_id]=true;
        self::$reserved_markers[$marker]=true;
        return array('ok'=>true,'identity'=>array(
            'canonical_article_id'=>$canonical_article_id,
            'request_id'=>$request_id,
            'run_marker'=>$marker,
            'server_instance_id'=>$server_instance_id,
            'build_manifest_sha256'=>$build_manifest_sha256,
            'identity_scope'=>'CANONICAL_ARTICLE_PLUS_ONE_AUTHORIZED_RUN',
            'persistence_identity'=>'ASSIGNED_ONLY_AFTER_SINGLE_WRITE_CHOKEPOINT'
        ));
    }

    private static function ids($posts){$ids=array();foreach((array)$posts as $p){$id=(int)($p['ID']??0);if($id>0){$ids[]=$id;}}sort($ids,SORT_NUMERIC);return $ids;}

    private static function legacy_marker_map() {
        $c=self::load_contract();
        return is_array($c['legacy_own_run_markers']??null)?$c['legacy_own_run_markers']:array();
    }

    private static function is_own_prior($post,$canonical_article_id) {
        $meta=is_array($post['meta']??null)?$post['meta']:array();
        $stored=(string)PPM679_WP::scalar_meta($meta,'_ppm679_canonical_article_id');
        if($stored!=='' && hash_equals($canonical_article_id,$stored)){return true;}
        $marker=(string)PPM679_WP::scalar_meta($meta,'_ppm679_test_marker');
        $map=self::legacy_marker_map();
        $legacy=(array)($map[$canonical_article_id]??array());
        return in_array($marker,$legacy,true)
            && strtolower((string)PPM679_WP::scalar_meta($meta,'_ppm679_article_type'))==='faq'
            && (string)PPM679_WP::scalar_meta($meta,'_ppm679_publish_blocked')==='1'
            && (string)PPM679_WP::scalar_meta($meta,'_ppm679_qf03_gate')==='PASS';
    }

    private static function resolve_slug($base_slug,$canonical_article_id,$request_id) {
        $base_slug=PPM679_WP::sanitize_title($base_slug);
        if($base_slug===''){
            $error=self::err('BLOCKED_QF03_SLUG_MISSING','QF03_PLANNED_WRITE_REQUIRES_NON_EMPTY_SLUG','planned_write.base_slug','non-empty',$base_slug,'Der geplante Slug fehlt.');
            return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'v31_slug_resolution'));
        }
        $collisions=PPM679_WP::find_posts_by_slug($base_slug);
        if(!$collisions){return array('ok'=>true,'slug'=>$base_slug,'decision'=>'BASE_SLUG_FREE','collision_post_ids'=>array());}
        $own=array();$foreign=array();
        foreach($collisions as $post){
            if(self::is_own_prior($post,$canonical_article_id)){$own[]=$post;}else{$foreign[]=$post;}
        }
        if($foreign){
            $error=self::err('BLOCKED_QF03_SLUG_COLLISION_FOREIGN_OBJECT','QF03_FOREIGN_OBJECT_SLUG_COLLISION_REQUIRES_SEPARATE_BOUND_DECISION','planned_write.slug',$base_slug,array('foreign_post_ids'=>self::ids($foreign),'own_post_ids'=>self::ids($own)),'Ein fremdes WordPress-Objekt belegt den Slug. Stilles Überschreiben oder ungeregeltes Anhängen ist verboten.');
            return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'v31_slug_resolution'));
        }
        $suffix=substr(hash('sha256',$canonical_article_id.'|'.$request_id.'|OWN_PRIOR_SLUG'),0,10);
        $prefix=substr($base_slug,0,max(1,180-strlen($suffix)));
        $planned=rtrim($prefix,'-').'-kontrolllauf-'.$suffix;
        $planned=PPM679_WP::sanitize_title($planned);
        $planned_collisions=PPM679_WP::find_posts_by_slug($planned);
        if($planned_collisions){
            $error=self::err('BLOCKED_QF03_SLUG_COLLISION_OWN_PRIOR_UNRESOLVED','QF03_OWN_PRIOR_SLUG_REQUIRES_PREPLANNED_COLLISION_FREE_DERIVATION','planned_write.slug',$planned,array('post_ids'=>self::ids($planned_collisions)),'Die vorab gebundene Slugstrategie für den eigenen Altlauf ist nicht kollisionsfrei.');
            return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'v31_slug_resolution'));
        }
        return array('ok'=>true,'slug'=>$planned,'decision'=>'OWN_PRIOR_RUN_COLLISION_DERIVED_BOUND_SLUG','collision_post_ids'=>self::ids($own),'base_slug'=>$base_slug);
    }

    private static function fingerprint_input($payload,$identity,$quality_binding_sha256,$slug_decision) {
        $meta=is_array($payload['meta']??null)?$payload['meta']:array();
        unset($meta['_ppm679_planned_write_fingerprint']);
        return array(
            'contract'=>self::CONTRACT,
            'canonical_article_id'=>(string)($identity['canonical_article_id']??''),
            'request_id'=>(string)($identity['request_id']??''),
            'run_marker'=>(string)($identity['run_marker']??''),
            'server_instance_id'=>(string)($identity['server_instance_id']??''),
            'build_manifest_sha256'=>(string)($identity['build_manifest_sha256']??''),
            'title'=>(string)($payload['title']??''),
            'content_sha256'=>hash('sha256',(string)($payload['content']??'')),
            'slug'=>(string)($payload['slug']??''),
            'categories'=>array_values(array_map('intval',(array)($payload['categories']??array()))),
            'category_assignment_sha256'=>(string)($payload['category_assignment']['category_assignment_sha256']??''),
            'meta'=>$meta,
            'quality_binding_sha256'=>(string)$quality_binding_sha256,
            'slug_decision'=>(string)$slug_decision,
            'post_status'=>'draft',
            'post_type'=>'post'
        );
    }

    public static function prepare_single_faq_plan($candidate,$gate,$identity,$quality_binding_sha256) {
        $candidate=is_array($candidate)?$candidate:array();
        $gate=is_array($gate)?$gate:array();
        $identity=is_array($identity)?$identity:array();
        $errors=self::contract_errors();
        if(strtolower((string)($candidate['article_type']??''))!=='faq'){$errors[]=self::err('BLOCKED_V31_FAQ_ONLY','V31_PILOT_PLAN_ACCEPTS_FAQ_ONLY','candidate.article_type','faq',$candidate['article_type']??null,'Der V3.1-Pilot bleibt auf FAQ begrenzt.');}
        if(!self::valid_sha($quality_binding_sha256)){$errors[]=self::err('BLOCKED_V31_QUALITY_BINDING','PLANNED_WRITE_MUST_BIND_QUALITY_SHA256','planned_write.quality_binding_sha256','sha256',$quality_binding_sha256,'Die Qualitätsbindung fehlt.');}
        foreach(array('canonical_article_id','request_id','run_marker','server_instance_id','build_manifest_sha256') as $f){if(trim((string)($identity[$f]??''))===''){$errors[]=self::err('BLOCKED_V31_IDENTITY_FIELD_MISSING','PLANNED_WRITE_REQUIRES_COMPLETE_RUN_IDENTITY','identity.'.$f,'non-empty',$identity[$f]??null,'Die Laufidentität ist unvollständig.');}}
        if($errors){return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($errors[0]['error_code'],$errors,'v31_plan_prepare'));}

        $slug=self::resolve_slug((string)($candidate['slug']??''),(string)$identity['canonical_article_id'],(string)$identity['request_id']);
        if(empty($slug['ok'])){return $slug;}

        $category_assignment=is_array($candidate['category_assignment']??null)?$candidate['category_assignment']:array();
        if(!$category_assignment){$error=self::err('BLOCKED_CATEGORY_WRITE_UNBOUND','PLANNED_WRITE_REQUIRES_CATEGORY_ASSIGNMENT','planned_write.category_assignment','bound four-way category assignment',null,'Die geplante Schreibaktion besitzt keine gebundene Kategorieentscheidung.');return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($error['error_code'],array($error),'v31_plan_prepare'));}
        $category_errors=PPM679_Category_Assignment_Validator::revalidate_chokepoint($category_assignment);
        if($category_errors){return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($category_errors[0]['error_code'],$category_errors,'v31_plan_prepare'));}
        $resolved_category=(array)($category_assignment['live_resolved_category']??array());

        $content=(string)($candidate['content_html']??'');
        $content_hash=hash('sha256',$content);
        $meta=array(
            '_ppm679_run_id'=>(string)$identity['request_id'],
            '_ppm679_request_id'=>(string)$identity['request_id'],
            '_ppm679_canonical_article_id'=>(string)$identity['canonical_article_id'],
            '_ppm679_server_instance_id'=>(string)$identity['server_instance_id'],
            '_ppm679_build_manifest_sha256'=>(string)$identity['build_manifest_sha256'],
            '_ppm679_article_type'=>'faq',
            '_ppm679_content_hash'=>$content_hash,
            '_ppm679_editorially_reviewed_content_hash'=>(string)($gate['EDITORIALLY_REVIEWED_CONTENT_HASH']??''),
            '_ppm679_gold_reference_hash'=>(string)($gate['REVIEW_GOLD_REFERENCE_HASH']??''),
            '_ppm679_test_marker'=>(string)$identity['run_marker'],
            '_ppm679_target_category_slug'=>(string)($resolved_category['slug']??''),
            '_ppm679_category_name'=>(string)($resolved_category['name']??''),
            '_ppm679_category_hierarchy_path'=>(string)($category_assignment['editorial_plan_category']['portal_path']??''),
            '_ppm679_portal_level'=>(string)($category_assignment['editorial_plan_category']['portal_level']??''),
            '_ppm679_portal_path'=>(string)($category_assignment['editorial_plan_category']['portal_path']??''),
            '_ppm679_wp_parent_chain_slugs'=>json_encode(array_values((array)($resolved_category['parent_chain_slugs']??array())),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
            '_ppm679_wp_taxonomy_depth'=>(string)($resolved_category['taxonomy_depth']??''),
            '_ppm679_wp_taxonomy_contract_hash'=>(string)($category_assignment['editorial_plan_category']['wp_taxonomy_contract_hash']??''),
            '_ppm679_wp_taxonomy_snapshot_hash'=>(string)($category_assignment['editorial_plan_category']['wp_taxonomy_snapshot_hash']??''),
            '_ppm679_category_taxonomy'=>(string)($resolved_category['taxonomy']??''),
            '_ppm679_category_snapshot_sha256'=>(string)($category_assignment['snapshot_sha256']??''),
            '_ppm679_independent_category_decision_sha256'=>(string)($category_assignment['independent_decision_sha256']??''),
            '_ppm679_category_assignment_sha256'=>(string)($category_assignment['category_assignment_sha256']??''),
            '_ppm679_publish_blocked'=>'1',
            '_ppm679_qf03_gate'=>'PASS',
            '_ppm679_slug_decision'=>(string)$slug['decision']
        );
        $payload=array(
            'title'=>(string)($candidate['title']??''),
            'content'=>$content,
            'slug'=>(string)$slug['slug'],
            'meta'=>$meta,
            'categories'=>array((int)($resolved_category['term_id']??0)),
            'category_assignment'=>$category_assignment
        );
        $input=self::fingerprint_input($payload,$identity,$quality_binding_sha256,(string)$slug['decision']);
        $fingerprint=PPM679_Diagnostic::stable_hash($input);
        $payload['meta']['_ppm679_planned_write_fingerprint']=$fingerprint;
        $plan=array(
            'contract'=>self::CONTRACT,
            'identity'=>$identity,
            'payload'=>$payload,
            'quality_binding_sha256'=>$quality_binding_sha256,
            'slug_decision'=>(string)$slug['decision'],
            'slug_collision_post_ids'=>(array)($slug['collision_post_ids']??array()),
            'planned_write_fingerprint'=>$fingerprint,
            'write_chokepoint'=>'PPM679_WP::insert_draft',
            'category_assignment'=>$category_assignment,
            'dry_run_complete'=>true,
            'write_performed'=>false
        );
        $check=self::validate_plan($plan,$candidate,$gate,false);
        if(!empty($check)){return array('ok'=>false,'report'=>PPM679_Diagnostic::blocked($check[0]['error_code'],$check,'v31_plan_prepare'));}
        return array('ok'=>true,'plan'=>$plan,'status'=>'PASS_V31_WRITE_PLAN_PREPARED_NO_WRITE','write_performed'=>false);
    }

    public static function validate_plan($plan,$candidate,$gate,$final_prewrite=true) {
        $plan=is_array($plan)?$plan:array();$candidate=is_array($candidate)?$candidate:array();$gate=is_array($gate)?$gate:array();$errors=self::contract_errors();
        $identity=is_array($plan['identity']??null)?$plan['identity']:array();
        $payload=is_array($plan['payload']??null)?$plan['payload']:array();
        $meta=is_array($payload['meta']??null)?$payload['meta']:array();
        $fingerprint=(string)($plan['planned_write_fingerprint']??'');
        $actual=PPM679_Diagnostic::stable_hash(self::fingerprint_input($payload,$identity,(string)($plan['quality_binding_sha256']??''),(string)($plan['slug_decision']??'')));
        if($fingerprint===''||!hash_equals($fingerprint,$actual)||!hash_equals($fingerprint,(string)($meta['_ppm679_planned_write_fingerprint']??''))){
            $errors[]=self::err('BLOCKED_QF03_PLANNED_WRITE_FINGERPRINT_MISMATCH','DRY_RUN_AND_WRITE_MUST_USE_IDENTICAL_PLANNED_WRITE_FINGERPRINT','planned_write.fingerprint',$actual,array('plan'=>$fingerprint,'meta'=>$meta['_ppm679_planned_write_fingerprint']??null),'Der Schreibdatensatz weicht von der schreibfreien Generalprobe ab.');
        }
        $category_assignment=is_array($plan['category_assignment']??null)?$plan['category_assignment']:array();
        if(!$category_assignment){$errors[]=self::err('BLOCKED_CATEGORY_WRITE_UNBOUND','CATEGORY_ASSIGNMENT_MUST_REMAIN_BOUND_TO_PLAN','planned_write.category_assignment','present',null,'Die Kategorieentscheidung fehlt im Schreibplan.');}
        elseif($final_prewrite){$errors=array_merge($errors,PPM679_Category_Assignment_Validator::revalidate_chokepoint($category_assignment));}
        $pairs=array(
            'title'=>array((string)($candidate['title']??''),(string)($payload['title']??'')),
            'content_hash'=>array(hash('sha256',(string)($candidate['content_html']??'')),hash('sha256',(string)($payload['content']??''))),
            'category_id'=>array((int)($category_assignment['live_resolved_category']['term_id']??0),(int)($payload['categories'][0]??0)),
            'category_assignment_sha256'=>array((string)($category_assignment['category_assignment_sha256']??''),(string)($payload['meta']['_ppm679_category_assignment_sha256']??'')),
            'request_id'=>array((string)($identity['request_id']??''),(string)($meta['_ppm679_request_id']??'')),
            'run_marker'=>array((string)($identity['run_marker']??''),(string)($meta['_ppm679_test_marker']??'')),
            'canonical_article_id'=>array((string)($identity['canonical_article_id']??''),(string)($meta['_ppm679_canonical_article_id']??'')),
            'server_instance_id'=>array((string)($identity['server_instance_id']??''),(string)($meta['_ppm679_server_instance_id']??'')),
            'build_manifest_sha256'=>array((string)($identity['build_manifest_sha256']??''),(string)($meta['_ppm679_build_manifest_sha256']??''))
        );
        foreach($pairs as $field=>$pair){if($pair[0]===''||$pair[0]!==$pair[1]){$errors[]=self::err('BLOCKED_QF03_PLANNED_WRITE_BINDING_MISMATCH','PLANNED_WRITE_FIELDS_MUST_MATCH_DRY_RUN_AND_CANDIDATE','planned_write.'.$field,$pair[0],$pair[1],'Die geplante Schreibbindung stimmt nicht exakt.');}}
        if((string)($gate['FINAL_CONTENT_HASH']??'')!==hash('sha256',(string)($payload['content']??''))){$errors[]=self::err('BLOCKED_QF03_PLANNED_CONTENT_HASH','PLANNED_WRITE_CONTENT_MUST_MATCH_FINAL_REVIEWED_HASH','planned_write.content_hash',$gate['FINAL_CONTENT_HASH']??null,hash('sha256',(string)($payload['content']??'')),'Der geplante Inhalt ist nicht der freigegebene Inhalt.');}
        if($final_prewrite && !$errors){
            $request_posts=PPM679_WP::find_posts_by_meta_value('_ppm679_request_id',(string)$identity['request_id']);
            if($request_posts){$errors[]=self::err('BLOCKED_QF03_REQUEST_REPLAY','QF03_REQUEST_ID_MUST_NOT_AUTHORIZE_A_SECOND_DRAFT','planned_write.request_id','unused request id',$identity['request_id'],'Die Request-ID besitzt bereits eine Persistenzidentität.');}
            $marker_posts=PPM679_WP::find_posts_by_meta_value('_ppm679_test_marker',(string)$identity['run_marker']);
            if($marker_posts){$errors[]=self::err('BLOCKED_QF03_MARKER_COLLISION','QF03_TEST_MARKER_MUST_BE_GLOBALLY_UNIQUE','planned_write.run_marker','unused marker',$identity['run_marker'],'Der Laufmarker ist unmittelbar vor dem Schreiben nicht mehr eindeutig.');}
            $slug_posts=PPM679_WP::find_posts_by_slug((string)($payload['slug']??''));
            if($slug_posts){$errors[]=self::err('BLOCKED_QF03_PLANNED_SLUG_BECAME_OCCUPIED','PLANNED_SLUG_MUST_REMAIN_FREE_UNTIL_SINGLE_WRITE_CHOKEPOINT','planned_write.slug','no existing post',array('slug'=>$payload['slug']??null,'post_ids'=>self::ids($slug_posts)),'Der vorab geprüfte Slug wurde vor dem Schreibpunkt belegt.');}
        }
        return $errors;
    }

    public static function reset_test_state(){self::$reserved_requests=array();self::$reserved_markers=array();}
}
