<?php
require_once __DIR__.'/bootstrap-test.php';
$ok=array('table_background'=>'transparent','cell_backgrounds_all_transparent'=>true,'outer_top_px'=>0,'outer_right_px'=>0,'outer_bottom_px'=>0,'outer_left_px'=>0,'header_separator_px'=>2,'inner_vertical_px'=>1,'inner_horizontal_px'=>1);
ppm_test_assert(PPM679_Table_Hard_Rule_Validator::validate_computed_evidence($ok)===array(),'correct computed evidence must pass');
foreach(array('outer_left_px'=>1,'header_separator_px'=>1,'inner_horizontal_px'=>2,'table_background'=>'rgb(255, 255, 255)') as $field=>$value){$bad=$ok;$bad[$field]=$value;ppm_test_assert(count(PPM679_Table_Hard_Rule_Validator::validate_computed_evidence($bad))>0,'mutation must block '.$field);}
echo json_encode(array('status'=>'PASS_MAINBLOCK1_TABLE_RENDERED_NEGATIVE_REGRESSIONS','negative_cases'=>4,'final_dom_still_required'=>true),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
