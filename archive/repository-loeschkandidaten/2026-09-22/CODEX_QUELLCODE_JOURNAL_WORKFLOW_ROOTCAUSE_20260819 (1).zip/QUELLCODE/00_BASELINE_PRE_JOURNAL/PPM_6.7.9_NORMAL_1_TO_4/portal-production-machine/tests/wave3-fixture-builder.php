<?php
declare(strict_types=1);

function ppm_wave3_contract(string $name): array {
    $file=dirname(__DIR__).'/contracts/'.$name;
    $data=json_decode((string)file_get_contents($file),true);
    if (!is_array($data)) { throw new RuntimeException('Cannot load contract '.$name); }
    return $data;
}

function ppm_wave3_sentence_block(string $prefix,int $count): array {
    $out=array();
    for ($i=1;$i<=$count;$i++) {
        $out[]=$prefix.' Aussage '.$i.' erklärt einen eigenständigen, konkret prüfbaren Aspekt für Pferdehalter verständlich und ohne technische Umwege.';
    }
    return $out;
}

function ppm_wave3_find_unit(string $body,string $quote,string $content_hash): array {
    $start=strpos($body,$quote);
    if ($start===false) { throw new RuntimeException('Quote not found: '.$quote); }
    $end=$start+strlen($quote);
    return array(
        'exact_quote'=>$quote,
        'quote_start_offset'=>$start,
        'quote_end_offset'=>$end,
        'quote_fingerprint'=>hash('sha256',$content_hash.$start.$end.$quote),
    );
}

function ppm_wave3_positive_fixture(): array {
    $intro=array(
        'Der Einstieg beantwortet die Nutzerfrage sofort und nennt die wichtigste Entscheidung ohne Vorrede.',
        'Er zeigt außerdem knapp, welche Angaben für eine sichere Einordnung benötigt werden.'
    );
    $a=ppm_wave3_sentence_block('Abschnitt A',15);
    $b=ppm_wave3_sentence_block('Abschnitt B',15);
    $conclusion=array(
        'Das Fazit wägt die wichtigsten Möglichkeiten gegeneinander ab und nennt eine nachvollziehbare Entscheidungshilfe.',
        'Es fasst nicht nur zusammen, sondern erklärt auch den sinnvollen nächsten Schritt für den konkreten Fall.'
    );
    $body=implode("\n",array_merge($intro,$a,$b,$conclusion));
    $content_hash=hash('sha256',$body);
    $intro_start=0;
    $intro_end=strpos($body,$a[0])-1;
    $a_start=strpos($body,$a[0]);
    $a_end=strpos($body,$b[0])-1;
    $b_start=strpos($body,$b[0]);
    $b_end=strpos($body,$conclusion[0])-1;
    $conclusion_start=strpos($body,$conclusion[0]);
    $conclusion_end=strlen($body);

    $gold_intro=array(
        'Die Goldreferenz beantwortet die Ausgangsfrage direkt und ordnet die Entscheidung in wenigen klaren Sätzen ein.',
        'Sie nennt die notwendigen Angaben, ohne den Leser mit einer abstrakten Prüfbeschreibung aufzuhalten.'
    );
    $ga=ppm_wave3_sentence_block('Gold Abschnitt A',15);
    $gb=ppm_wave3_sentence_block('Gold Abschnitt B',15);
    $gold_conclusion=array(
        'Das Goldfazit wägt die Möglichkeiten ab und führt zu einer nachvollziehbaren, ausgewogenen Empfehlung.',
        'Es nennt einen konkreten nächsten Schritt und bleibt dabei innerhalb der belegten Aussagen.'
    );
    $gold_body=implode("\n",array_merge($gold_intro,$ga,$gb,$gold_conclusion));
    $gold_hash=hash('sha256',$gold_body);

    $structure=array(
        'heading_sequence'=>array('Abschnitt A','Abschnitt B','Fazit'),
        'section_order'=>array('sec-a','sec-b','conclusion'),
        'section_metrics'=>array(
            'sec-a'=>array('sentence_count'=>15,'start'=>$a_start,'end'=>$a_end),
            'sec-b'=>array('sentence_count'=>15,'start'=>$b_start,'end'=>$b_end),
            'conclusion'=>array('sentence_count'=>2,'start'=>$conclusion_start,'end'=>$conclusion_end),
        ),
        'source_offsets'=>array(
            array('section_id'=>'sec-a','start'=>$a_start,'end'=>$a_end),
            array('section_id'=>'sec-b','start'=>$b_start,'end'=>$b_end),
            array('section_id'=>'conclusion','start'=>$conclusion_start,'end'=>$conclusion_end),
        ),
    );
    $links=array(
        array('link_target'=>'/pferdewissen','link_text'=>'Pferdewissen','link_reason'=>'parent_category','section_id'=>'sec-a','link_start_offset'=>$a_start,'link_end_offset'=>$a_start+12,'portal_ist_match'=>true),
        array('link_target'=>'/pferdegesundheit','link_text'=>'Pferdegesundheit','link_reason'=>'semantic_related','section_id'=>'sec-b','link_start_offset'=>$b_start,'link_end_offset'=>$b_start+17,'portal_ist_match'=>true),
        array('link_target'=>'/weiterfuehrende-informationen','link_text'=>'Weiterführende Informationen','link_reason'=>'further_information','section_id'=>'conclusion','link_start_offset'=>$conclusion_start,'link_end_offset'=>$conclusion_start+27,'portal_ist_match'=>true),
    );
    $table=array(
        'table_id'=>'decision-table-1',
        'table_structure'=>array('columns'=>3,'rows'=>4,'headers'=>array('Situation','Einordnung','Nächster Schritt')),
        'table_cells'=>array(
            array('unklar','weitere Angaben nötig','gezielt prüfen'),
            array('eindeutig','direkte Antwort möglich','handeln'),
            array('Risiko','fachlichen Rat einholen','absichern'),
            array('Routine','regelmäßig kontrollieren','beobachten'),
        ),
        'comparison_text_offsets'=>array(array('start'=>$a_start,'end'=>$a_start+strlen($a[0]))),
        'additional_value_metrics'=>array('unique_cell_ratio'=>0.92,'duplicates_body_text'=>0,'comparison_dimensions'=>3),
    );
    $portal_hash=hash('sha256',json_encode($links,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    $article_contract=array('table_required'=>true,'contract_hash'=>hash('sha256','fixture-article-contract'));
    $document=array(
        'article_id'=>'FAQ-WAVE3-POSITIVE',
        'article_type'=>'FAQ',
        'content_hash'=>$content_hash,
        'body_text'=>$body,
        'regions'=>array(
            'introduction'=>array('start'=>$intro_start,'end'=>$intro_end),
            'conclusion'=>array('start'=>$conclusion_start,'end'=>$conclusion_end),
        ),
        'sections'=>array(
            array('section_id'=>'sec-a','heading'=>'Abschnitt A','start'=>$a_start,'end'=>$a_end),
            array('section_id'=>'sec-b','heading'=>'Abschnitt B','start'=>$b_start,'end'=>$b_end),
        ),
        'structure_evidence'=>$structure,
        'links'=>$links,
        'portal_ist_hash'=>$portal_hash,
        'tables'=>array($table),
        'article_contract'=>$article_contract,
    );
    $gold_reference=array(
        'gold_reference_id'=>'FAQ-8841-FIXTURE-REFERENCE',
        'article_type'=>'FAQ',
        'content_hash'=>$gold_hash,
        'body_text'=>$gold_body,
        'structure_evidence'=>array(
            'heading_sequence'=>array('Gold Abschnitt A','Gold Abschnitt B','Fazit'),
            'section_order'=>array('gold-a','gold-b','gold-conclusion'),
            'section_metrics'=>array('gold-a'=>array('sentence_count'=>15),'gold-b'=>array('sentence_count'=>15),'gold-conclusion'=>array('sentence_count'=>2)),
            'source_offsets'=>array(),
        ),
    );

    $matrix_contract=ppm_wave3_contract('review-matrix-schema-v1.json');
    $evidence_contract=ppm_wave3_contract('review-evidence-schema-v1.json');
    $reuse_contract=ppm_wave3_contract('quote-reuse-policy-v1.json');
    $cells=array();
    $section_criteria=array('UNDERSTANDABILITY','NATURALNESS','USEFULNESS','REPETITION','ARGUMENTATION','ARTICLE_TYPE_FULFILLMENT','SECTION_QUALITY_RELATIVE_TO_GOLD_REFERENCE');
    foreach (array('sec-a'=>$a,'sec-b'=>$b) as $section_id=>$sentences) {
        foreach ($section_criteria as $criterion_index=>$criterion) {
            $base=array(
                'article_id'=>$document['article_id'],'content_hash'=>$content_hash,'scope'=>'SECTION',
                'section_id'=>$section_id,'section_heading'=>$section_id==='sec-a'?'Abschnitt A':'Abschnitt B',
                'criterion_id'=>$criterion,'verdict'=>'PASS','explanation'=>'Der Beleg prüft ausschließlich '.$criterion.' in '.$section_id.'.'
            );
            if ($criterion==='UNDERSTANDABILITY') {
                $base['evidence_type']='EXACT_TEXT_QUOTE';
                $base['evidence_units']=array(ppm_wave3_find_unit($body,$sentences[0],$content_hash));
            } elseif ($criterion==='NATURALNESS') {
                $base['evidence_type']='EXACT_TEXT_QUOTE';
                $base['evidence_units']=array(ppm_wave3_find_unit($body,$sentences[1],$content_hash));
            } elseif ($criterion==='USEFULNESS') {
                $base['evidence_type']='TEXT_QUOTE_SET';
                $base['evidence_units']=array(ppm_wave3_find_unit($body,$sentences[2],$content_hash),ppm_wave3_find_unit($body,$sentences[3],$content_hash));
            } elseif ($criterion==='REPETITION') {
                $base['evidence_type']='REPETITION_EVIDENCE_SET';
                $base['evidence_units']=array(ppm_wave3_find_unit($body,$sentences[4],$content_hash),ppm_wave3_find_unit($body,$sentences[5],$content_hash));
            } elseif ($criterion==='ARGUMENTATION') {
                $base['evidence_type']='TEXT_QUOTE_SET';
                $base['evidence_units']=array(ppm_wave3_find_unit($body,$sentences[6],$content_hash),ppm_wave3_find_unit($body,$sentences[7],$content_hash));
            } elseif ($criterion==='ARTICLE_TYPE_FULFILLMENT') {
                $base['evidence_type']='TEXT_QUOTE_SET';
                $base['evidence_units']=array(ppm_wave3_find_unit($body,$sentences[8],$content_hash),ppm_wave3_find_unit($body,$sentences[9],$content_hash));
            } else {
                $gold_sentence=$section_id==='sec-a'?$ga[10]:$gb[10];
                $base['evidence_type']='PAIRED_CANDIDATE_REFERENCE_QUOTES';
                $base['evidence_units']=array(ppm_wave3_find_unit($body,$sentences[10],$content_hash));
                $base['gold_reference_id']=$gold_reference['gold_reference_id'];
                $base['gold_reference_hash']=$gold_hash;
                $base['reference_exact_quote']=$gold_sentence;
                $base['reference_quote_start_offset']=strpos($gold_body,$gold_sentence);
                $base['reference_quote_end_offset']=$base['reference_quote_start_offset']+strlen($gold_sentence);
                $base['comparison_explanation']='Kandidat und Referenz behandeln denselben Abschnittstyp mit konkret vergleichbarer Informationsfunktion.';
            }
            $cells[]=$base;
        }
    }
    $cells[]=array(
        'article_id'=>$document['article_id'],'content_hash'=>$content_hash,'scope'=>'ARTICLE_WIDE','section_id'=>'ARTICLE_WIDE','section_heading'=>'ARTICLE_WIDE',
        'criterion_id'=>'OVERALL_STRUCTURE','verdict'=>'PASS','evidence_type'=>'HEADING_SEQUENCE_EVIDENCE','explanation'=>'Die vollständige Überschriftenfolge und Abschnittsmetriken entsprechen dem Dokument.',
        'structural_evidence'=>$structure
    );
    $cells[]=array(
        'article_id'=>$document['article_id'],'content_hash'=>$content_hash,'scope'=>'ARTICLE_WIDE','section_id'=>'ARTICLE_WIDE','section_heading'=>'ARTICLE_WIDE',
        'criterion_id'=>'INTRODUCTION_QUALITY','verdict'=>'PASS','evidence_type'=>'INTRO_REGION_QUOTE_SET','explanation'=>'Beide Belege stammen ausschließlich aus der technisch erkannten Einleitung.',
        'evidence_units'=>array(ppm_wave3_find_unit($body,$intro[0],$content_hash),ppm_wave3_find_unit($body,$intro[1],$content_hash))
    );
    $cells[]=array(
        'article_id'=>$document['article_id'],'content_hash'=>$content_hash,'scope'=>'ARTICLE_WIDE','section_id'=>'ARTICLE_WIDE','section_heading'=>'ARTICLE_WIDE',
        'criterion_id'=>'CONCLUSION_QUALITY','verdict'=>'PASS','evidence_type'=>'CONCLUSION_REGION_QUOTE_SET','explanation'=>'Beide Belege stammen ausschließlich aus dem technisch erkannten Fazit.',
        'evidence_units'=>array(ppm_wave3_find_unit($body,$conclusion[0],$content_hash),ppm_wave3_find_unit($body,$conclusion[1],$content_hash))
    );
    $cells[]=array(
        'article_id'=>$document['article_id'],'content_hash'=>$content_hash,'scope'=>'ARTICLE_WIDE','section_id'=>'ARTICLE_WIDE','section_heading'=>'ARTICLE_WIDE',
        'criterion_id'=>'LINK_DISTRIBUTION','verdict'=>'PASS','evidence_type'=>'LINK_PLACEMENT_MAP','explanation'=>'Die vollständige Linkliste ist mit Rollen, Abschnitten, Zielen und Offsets belegt.',
        'link_evidence'=>$links,'portal_ist_hash'=>$portal_hash
    );
    $cells[]=array(
        'article_id'=>$document['article_id'],'content_hash'=>$content_hash,'scope'=>'ARTICLE_WIDE','section_id'=>'ARTICLE_WIDE','section_heading'=>'ARTICLE_WIDE',
        'criterion_id'=>'TABLE_ADDITIONAL_VALUE','verdict'=>'PASS','evidence_type'=>'TABLE_VALUE_EVIDENCE','explanation'=>'Tabellenzellen, Struktur und Vergleichsstelle belegen den zusätzlichen Orientierungswert.',
        'table_evidence'=>$table
    );
    $cells[]=array(
        'article_id'=>$document['article_id'],'content_hash'=>$content_hash,'scope'=>'ARTICLE_WIDE','section_id'=>'ARTICLE_WIDE','section_heading'=>'ARTICLE_WIDE',
        'criterion_id'=>'ARTICLE_TYPE_FULFILLMENT_OVERALL','verdict'=>'PASS','evidence_type'=>'MULTI_SECTION_QUOTE_SET','explanation'=>'Belege aus beiden Hauptabschnitten zeigen die artikelweite Erfüllung des FAQ-Vertrags.',
        'evidence_units'=>array(ppm_wave3_find_unit($body,$a[11],$content_hash),ppm_wave3_find_unit($body,$b[11],$content_hash))
    );
    $gold_candidate=$a[12];
    $gold_ref=$ga[12];
    $cells[]=array(
        'article_id'=>$document['article_id'],'content_hash'=>$content_hash,'scope'=>'ARTICLE_WIDE','section_id'=>'ARTICLE_WIDE','section_heading'=>'ARTICLE_WIDE',
        'criterion_id'=>'GOLD_CORE_ALIGNMENT','verdict'=>'PASS','evidence_type'=>'PAIRED_CANDIDATE_REFERENCE_QUOTES','explanation'=>'Kandidat und Goldreferenz werden mit Text- und Strukturbelegen derselben Beitragsart verglichen.',
        'evidence_units'=>array(ppm_wave3_find_unit($body,$gold_candidate,$content_hash)),
        'gold_reference_id'=>$gold_reference['gold_reference_id'],'gold_reference_hash'=>$gold_hash,
        'reference_exact_quote'=>$gold_ref,'reference_quote_start_offset'=>strpos($gold_body,$gold_ref),'reference_quote_end_offset'=>strpos($gold_body,$gold_ref)+strlen($gold_ref),
        'comparison_explanation'=>'Beide Texte erfüllen dieselbe FAQ-Funktion, ohne aus dem Maschinen-PASS ein redaktionelles Urteil abzuleiten.',
        'candidate_structure_evidence'=>$structure,
        'reference_structure_evidence'=>$gold_reference['structure_evidence'],
        'candidate_metrics'=>array('section_count'=>3,'sentence_count'=>34),
        'reference_metrics'=>array('section_count'=>3,'sentence_count'=>34),
    );
    $review=array(
        'article_id'=>$document['article_id'],'content_hash'=>$content_hash,'article_type'=>'FAQ',
        'review_matrix_schema_hash'=>$matrix_contract['review_matrix_schema_hash'],
        'review_evidence_schema_hash'=>$evidence_contract['review_evidence_schema_hash'],
        'quote_reuse_policy_hash'=>$reuse_contract['quote_reuse_policy_hash'],
        'gold_reference_hash'=>$gold_hash,
        'review_sections'=>array('sec-a','sec-b'),
        'cells'=>$cells,
    );
    return array('review'=>$review,'document'=>$document,'gold_reference'=>$gold_reference);
}

function ppm_wave3_current_bindings(array $fixture): array {
    $review=$fixture['review'];
    return array(
        'content_hash'=>$fixture['document']['content_hash'],
        'rule_catalog_hash'=>hash('sha256','revision-8-fixture'),
        'review_matrix_schema_hash'=>$review['review_matrix_schema_hash'],
        'review_evidence_schema_hash'=>$review['review_evidence_schema_hash'],
        'quote_reuse_policy_hash'=>$review['quote_reuse_policy_hash'],
        'tool_source_hash'=>hash_file('sha256',dirname(__DIR__).'/includes/review-matrix-validator.php'),
        'tool_version'=>PPM679_Review_Matrix_Validator::VERSION,
        'gold_reference_hash'=>$fixture['gold_reference']['content_hash'],
        'portal_ist_hash'=>$fixture['document']['portal_ist_hash'],
        'plan_hash'=>hash('sha256','wave3-fixture-plan'),
    );
}

function ppm_wave3_evidence(string $id,string $class,array $current,string $raw_file,bool $model=false): array {
    $e=array(
        'evidence_id'=>$id,'evidence_class'=>$class,
        'input_file'=>'tests/wave3-fixture-builder.php','input_hash'=>hash_file('sha256',__FILE__),
        'content_hash'=>$current['content_hash'],'plan_hash'=>$current['plan_hash'],'fact_pack_hash'=>'NOT_APPLICABLE',
        'rule_catalog_hash'=>$current['rule_catalog_hash'],'review_matrix_schema_hash'=>$current['review_matrix_schema_hash'],
        'review_evidence_schema_hash'=>$current['review_evidence_schema_hash'],'quote_reuse_policy_hash'=>$current['quote_reuse_policy_hash'],
        'gold_reference_hash'=>$current['gold_reference_hash'],'portal_ist_hash'=>$current['portal_ist_hash'],
        'tool_name'=>'PHP CLI Wave-3 Test','tool_version'=>$current['tool_version'],'tool_source_hash'=>$current['tool_source_hash'],
        'command'=>'php tests/test-wave3-editorial-engine-integration.php','exit_code'=>0,
        'raw_output_file'=>$raw_file,'raw_output_hash'=>hash_file('sha256',$raw_file),'generated_at'=>gmdate('c'),
    );
    if ($model) {
        $e['model_assisted_review']=true;
        $e['review_provider']='INDEPENDENT_TEST_FIXTURE_PROVIDER';
        $e['review_model_identifier']='fixture-review-model';
        $e['review_model_version']='1.0';
        $e['review_context_hash']=hash('sha256','fixture context');
        $e['review_prompt_hash']=hash('sha256','fixture prompt');
        $e['review_parameters_hash']=hash('sha256','fixture parameters');
        $e['independence_declaration']=true;
    }
    return $e;
}
