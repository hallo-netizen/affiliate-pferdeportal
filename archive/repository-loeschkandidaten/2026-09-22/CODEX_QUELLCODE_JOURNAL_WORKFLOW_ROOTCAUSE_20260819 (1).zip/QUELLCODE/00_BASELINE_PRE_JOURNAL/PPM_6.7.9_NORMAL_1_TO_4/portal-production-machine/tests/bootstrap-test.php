<?php
declare(strict_types=1);
define('ABSPATH', __DIR__ . '/wp/');
define('PPM679_TEST_MODE', true);
define('ARRAY_A', 'ARRAY_A');
$GLOBALS['ppm_test_hooks'] = array();
$GLOBALS['ppm_test_routes'] = array();
$GLOBALS['ppm_test_redirects'] = array();

function add_action($hook,$callback,$priority=10,$accepted_args=1) {
    $GLOBALS['ppm_test_hooks'][$hook][] = $callback;
    return true;
}
function add_menu_page(...$args) { return 'ppm-test-hook'; }
function add_submenu_page(...$args) { return 'ppm-test-submenu-hook'; }
function get_current_user_id() { return 1; }
function register_rest_route($namespace,$route,$args) {
    $GLOBALS['ppm_test_routes'][$namespace.$route]=$args;
    return true;
}
function current_user_can($cap) { return true; }
function wp_verify_nonce($nonce,$action) { return $nonce === 'test-nonce'; }
function wp_json_encode($value,$flags=0) { return json_encode($value,$flags); }
function sanitize_title($title) {
    $title=strtolower((string)$title);
    $title=preg_replace('/[^a-z0-9äöüß]+/u','-',$title);
    return trim((string)$title,'-');
}
function wp_kses_post($html) { return (string)$html; }
function rest_ensure_response($data) { return $data; }
function admin_url($path='') { return 'https://example.test/wp-admin/'.ltrim($path,'/'); }
function wp_safe_redirect($url) { $GLOBALS['ppm_test_redirects'][]=$url; return true; }
function wp_nonce_field($action) { echo '<input type="hidden" name="_wpnonce" value="test-nonce">'; }
function submit_button($label) { echo '<button type="submit">'.htmlspecialchars($label,ENT_QUOTES,'UTF-8').'</button>'; }
function nocache_headers() {}
function sanitize_file_name($name) { return preg_replace('/[^A-Za-z0-9._-]/','-',(string)$name); }

require_once dirname(__DIR__) . '/portal-production-machine.php';

function ppm_test_assert($condition,$message) {
    if (!$condition) {
        fwrite(STDERR, "ASSERTION_FAILED: ".$message."\n");
        exit(2);
    }
}
