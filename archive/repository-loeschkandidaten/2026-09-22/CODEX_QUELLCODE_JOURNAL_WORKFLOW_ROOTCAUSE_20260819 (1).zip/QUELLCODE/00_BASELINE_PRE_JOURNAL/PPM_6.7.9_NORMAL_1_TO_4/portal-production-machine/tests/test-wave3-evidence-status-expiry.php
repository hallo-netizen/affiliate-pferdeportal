<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';
require __DIR__.'/wave3-fixture-builder.php';

function w3_error_codes(array $result): array {
    $out=array(); foreach((array)($result['errors']??array()) as $e){$out[]=(string)($e['error_code']??'');} return array_values(array_unique($out));
}
function w3_assert_code(array $result,string $code,string $label): void {
    $codes=w3_error_codes($result); ppm_test_assert(in_array($code,$codes,true),$label.' expected '.$code.' got '.json_encode($codes));
}

$fixture=ppm_wave3_positive_fixture();
$current=ppm_wave3_current_bindings($fixture);
$raw=tempnam(sys_get_temp_dir(),'ppm-wave3-raw-');
file_put_contents($raw,"wave3 raw executed evidence\n");
$local=ppm_wave3_evidence('WAVE3-LOCAL-EDITORIAL-VALIDATION-001','LOCAL_EXECUTED_TEST',$current,$raw,false);
$model=ppm_wave3_evidence('WAVE3-INDEPENDENT-REVIEW-001','STATIC_CODE_INSPECTION',$current,$raw,true);
$registry=PPM679_Evidence_Registry::validate_set(array($local,$model),$current,'wave3_evidence_positive','wave3-local-state');
if(empty($registry['ok'])){fwrite(STDERR,json_encode($registry,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");}
ppm_test_assert(!empty($registry['ok']),'valid evidence set must pass');

$statuses=array_fill_keys(PPM679_Status_Gate::STATUS_NAMES,'UNGEKLÄRT');
$statuses['EDITORIAL_REVIEW_STATUS']='PASS';
$statuses['GOLD_CORE_REVIEW_GATE']='PASS';
$ids=array(
    'EDITORIAL_REVIEW_STATUS'=>array($local['evidence_id'],$model['evidence_id']),
    'GOLD_CORE_REVIEW_GATE'=>array($local['evidence_id'],$model['evidence_id']),
);
$status=PPM679_Status_Gate::evaluate($statuses,$registry['evidence_by_id'],$ids,null,'wave3_status_positive','wave3-local-state');
if(empty($status['ok'])){fwrite(STDERR,json_encode($status,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n");}
ppm_test_assert(!empty($status['ok']),'valid separate status evidence must pass');
ppm_test_assert(($status['statuses']['EDITORIAL_REVIEW_STATUS']??'')==='PASS','editorial review status must remain PASS with both required evidences');

$mutations=array();
$bad_status=$statuses; $bad_ids=$ids; $bad_ids['EDITORIAL_REVIEW_STATUS']=array();
$r=PPM679_Status_Gate::evaluate($bad_status,$registry['evidence_by_id'],$bad_ids,null,'wave3_missing_evidence_id','state'); w3_assert_code($r,'STATUS_EVIDENCE_ID_MISSING','missing evidence id'); $mutations[]='STATUS_EVIDENCE_ID_MISSING';

$bad_ids=$ids; $bad_ids['EDITORIAL_REVIEW_STATUS']=array($model['evidence_id']);
$r=PPM679_Status_Gate::evaluate($statuses,$registry['evidence_by_id'],$bad_ids,null,'wave3_static_only','state'); w3_assert_code($r,'STATUS_MINIMUM_EVIDENCE_CLASS_MISSING','static-only editorial'); w3_assert_code($r,'STATIC_CODE_INSPECTION_CANNOT_PASS_ALONE','static-only pass'); $mutations[]='STATIC_CODE_INSPECTION_CANNOT_PASS_ALONE';

$server_statuses=array_fill_keys(PPM679_Status_Gate::STATUS_NAMES,'UNGEKLÄRT'); $server_statuses['SERVER_CHECK_STATUS']='PASS';
$server_ids=array('SERVER_CHECK_STATUS'=>array($local['evidence_id']));
$r=PPM679_Status_Gate::evaluate($server_statuses,$registry['evidence_by_id'],$server_ids,null,'wave3_server_wrong_class','state'); w3_assert_code($r,'STATUS_MINIMUM_EVIDENCE_CLASS_MISSING','server wrong class'); $mutations[]='SERVER_EVIDENCE_CLASS_MISMATCH';

$expiry_fields=array('content_hash','rule_catalog_hash','review_matrix_schema_hash','review_evidence_schema_hash','quote_reuse_policy_hash','tool_source_hash','tool_version','gold_reference_hash','portal_ist_hash','plan_hash');
$expiry_reports=array();
foreach($expiry_fields as $field){
    $changed=$current;
    $changed[$field]=$field==='tool_version'?'changed-version':str_repeat(substr(hash('sha256',$field),0,1),64);
    $res=PPM679_Evidence_Expiry_Validator::evaluate($local,$changed,'wave3_expiry_'.$field,'state');
    ppm_test_assert(empty($res['ok']),$field.' change must stale evidence');
    w3_assert_code($res,'EVIDENCE_STALE','expiry '.$field);
    ppm_test_assert(in_array($field,$res['stale_fields'],true),$field.' must be listed stale');
    $expiry_reports[]=array('field'=>$field,'status'=>'EVIDENCE_STALE');
}

$bad_model=$model; unset($bad_model['review_model_identifier']);
$r=PPM679_Evidence_Registry::validate_one($bad_model,$current,'wave3_model_identity','state'); w3_assert_code($r,'REVIEW_MODEL_IDENTITY_UNVERIFIED','model identity'); $mutations[]='REVIEW_MODEL_IDENTITY_UNVERIFIED';
$bad_model=$model; $bad_model['independence_declaration']=false;
$r=PPM679_Evidence_Registry::validate_one($bad_model,$current,'wave3_independence','state'); w3_assert_code($r,'REVIEW_INDEPENDENCE_UNVERIFIED','independence'); $mutations[]='REVIEW_INDEPENDENCE_UNVERIFIED';
$bad_raw=$local; $bad_raw['raw_output_hash']=str_repeat('f',64);
$r=PPM679_Evidence_Registry::validate_one($bad_raw,$current,'wave3_raw_hash','state'); w3_assert_code($r,'EVIDENCE_RAW_OUTPUT_HASH_MISMATCH','raw hash'); $mutations[]='EVIDENCE_RAW_OUTPUT_HASH_MISMATCH';
$r=PPM679_Evidence_Registry::validate_set(array($local,$local),$current,'wave3_duplicate_evidence','state'); w3_assert_code($r,'EVIDENCE_ID_DUPLICATE','duplicate evidence'); $mutations[]='EVIDENCE_ID_DUPLICATE';
$unknown=$statuses; $unknown['TECH_STATUS']='PASS';
$r=PPM679_Status_Gate::evaluate($unknown,$registry['evidence_by_id'],$ids,null,'wave3_unknown_status','state'); w3_assert_code($r,'STATUS_NAME_UNKNOWN','unknown status'); $mutations[]='STATUS_NAME_UNKNOWN';
$invalid=$statuses; $invalid['TECHNICAL_STATUS']='OK';
$r=PPM679_Status_Gate::evaluate($invalid,$registry['evidence_by_id'],$ids,null,'wave3_invalid_value','state'); w3_assert_code($r,'STATUS_VALUE_INVALID','invalid status value'); $mutations[]='STATUS_VALUE_INVALID';
$contract=PPM679_Status_Gate::load_contract(); unset($contract['schema']['status_definitions']['EDITORIAL_REVIEW_STATUS']);
$r=PPM679_Status_Gate::evaluate($statuses,$registry['evidence_by_id'],$ids,$contract,'wave3_status_definition','state'); w3_assert_code($r,'STATUS_CODE_EVIDENCE_MISSING','status code evidence'); $mutations[]='STATUS_CODE_EVIDENCE_MISSING';

unlink($raw);
echo json_encode(array(
    'contract'=>'wave3_evidence_status_expiry_report_v1','status'=>'PASS',
    'positive'=>array('evidence_registry_status'=>$registry['evidence_registry_status'],'status_gate_status'=>$status['status_gate_status']),
    'expiry_mutation_count'=>count($expiry_reports),'expiry_mutations'=>$expiry_reports,
    'other_mutation_count'=>count($mutations),'other_mutations'=>$mutations,
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
