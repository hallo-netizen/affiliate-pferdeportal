<?php
require __DIR__.'/bootstrap-three-type.php';
$root=dirname(__DIR__,2);$file=$root.'/contracts/three-type-v38-baseline-byte-identity-v1.json';$j=json_decode((string)file_get_contents($file),true);
ppm_test_assert(is_array($j),'baseline identity contract');ppm_test_assert(($j['baseline_candidate_zip_sha256']??'')==='b2e4bd9543cffb0eca16c66efa595dc33236caf672e296f399bbf110bf1f514d','exact V3-8 baseline zip');ppm_test_assert((int)($j['baseline_file_count']??0)===289,'baseline file count 289');
$scope=json_decode((string)file_get_contents($root.'/traceability/THREE_TYPE_BUNDLED_LIVE_TEST_RELEASE_SCOPE.json'),true);ppm_test_assert(is_array($scope),'current live-test release scope');
$allowed=array_values((array)($scope['authorized_existing_file_changes']??array()));sort($allowed,SORT_STRING);$baseline_paths=array();foreach((array)$j['baseline_files'] as $x){$baseline_paths[]=$x['path'];}
$expected=array_values(array_intersect($allowed,$baseline_paths));sort($expected,SORT_STRING);$missing=[];$mismatch=[];$matching=0;
foreach((array)$j['baseline_files'] as $x){$p=$root.'/'.$x['path'];if(!is_file($p)){$missing[]=$x['path'];continue;}if(hash_file('sha256',$p)!==$x['sha256'])$mismatch[]=$x['path'];else $matching++;}
sort($mismatch,SORT_STRING);ppm_test_assert($missing===[],'no baseline files missing');ppm_test_assert($mismatch===$expected,'all and only current authorized baseline files may differ');ppm_test_assert($matching===289-count($expected),'all non-authorized baseline files remain byte-identical');
$plugin=file_get_contents($root.'/portal-production-machine.php');foreach(PPM679_Three_Type_Bundled_Release_Validator::REGISTERED_COMPONENTS as $path){ppm_test_assert(substr_count($plugin,basename($path))===1,basename($path).' must be registered exactly once');}
echo json_encode(['status'=>'PASS_V38_BASELINE_MULTI_PHASE_CONTROLLED_BOUNDARY','baseline_files'=>289,'matching'=>$matching,'authorized_mismatch'=>$mismatch,'new_live_test_release_scope_bound'=>true],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
