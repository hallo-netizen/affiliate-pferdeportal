<?php
require_once __DIR__.'/fixture-builder.php';
$errors=PPM679_System_Inventory_Validator::validate();
ppm_test_assert($errors===array(),'system-derived inventory must match actual code search');
$s=PPM679_System_Inventory_Validator::summary();
ppm_test_assert($s['status']==='NO_FURTHER_UNMAPPED_GAP_FOUND_BY_INDEPENDENT_SEARCH','limited honest status');
ppm_test_assert($s['finding_count']>0,'discoveries');
echo json_encode(array('status'=>'PASS_V31_SYSTEM_INVENTORY','summary'=>$s,'absolute_completeness_claimed'=>false),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
