<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Evidence_Expiry_Validator {
    const VERSION='6.7.9-wave3-quarantine';
    const BINDINGS=array(
        'content_hash'=>'content_hash',
        'rule_catalog_hash'=>'rule_catalog_hash',
        'review_matrix_schema_hash'=>'review_matrix_schema_hash',
        'review_evidence_schema_hash'=>'review_evidence_schema_hash',
        'quote_reuse_policy_hash'=>'quote_reuse_policy_hash',
        'tool_source_hash'=>'tool_source_hash',
        'tool_version'=>'tool_version',
        'gold_reference_hash'=>'gold_reference_hash',
        'portal_ist_hash'=>'portal_ist_hash',
        'plan_hash'=>'plan_hash',
    );

    public static function evaluate($evidence,$current,$context='wave3_evidence_expiry',$server_state_hash='') {
        $evidence=is_array($evidence)?$evidence:array();
        $current=is_array($current)?$current:array();
        $errors=array();
        $stale_fields=array();
        foreach (self::BINDINGS as $current_field=>$evidence_field) {
            $expected=(string)($current[$current_field]??'');
            $actual=(string)($evidence[$evidence_field]??'');
            if ($expected==='' || $actual==='' || !hash_equals($expected,$actual)) {
                $stale_fields[]=$current_field;
                $errors[]=PPM679_Diagnostic::error(
                    'EVIDENCE_STALE',
                    'CURRENT_BOUND_COMPONENT_MUST_EQUAL_EVIDENCE_BOUND_COMPONENT',
                    'evidence.'.$evidence_field,
                    $expected,
                    $actual,
                    'Der gebundene Bestandteil hat sich geändert oder fehlt; ein alter PASS darf nicht fortgelten.',
                    $context,
                    $server_state_hash,
                    __CLASS__,
                    null,
                    array((string)($evidence['evidence_id']??''))
                );
            }
        }
        return array(
            'ok'=>!$errors,
            'status'=>!$errors?'PASS':'BLOCKED',
            'evidence_expiry_status'=>!$errors?'CURRENT':'EVIDENCE_STALE',
            'affected_status'=>!$errors?'UNCHANGED':'BLOCKED',
            'stale_fields'=>$stale_fields,
            'errors'=>$errors,
            'production_allowed'=>false,
            'draft_create_allowed'=>false,
            'publish_allowed'=>false,
        );
    }
}
