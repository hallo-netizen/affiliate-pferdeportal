<?php
/**
 * Plugin Name: Portal Production Machine
 * Description: Vollständige redaktionelle Produktionsmaschine mit kanonischem Gesamtredaktionsplan, Journal, systemweiter Dublettenkontrolle, Live-State-Gate, Draft und Readback. Kein Publish registriert.
 * Version: 6.7.9
 * Author: Workflow Automation
 */
if (!defined('ABSPATH')) { return; }

define('PPM679_VERSION','6.7.9');
define('PPM679_PLUGIN_DIR',__DIR__.'/');
define('PPM679_BUILD_PUBLIC_KEY_B64','3ivO6TMox5vRbBRq4GvBYP3f0M1raWpEXtW7WI9H+nk=');
define('PPM679_GOLD_CORE_SHA256','f46e806915a164e678f0d10b19b5e13279fa16c725f3a362c80262aa79ce3b11');
define('PPM679_CONTENT_VAULT_SHA256','e3d0d8fc68e48fbdf87cce2e908e87ce3eedfc8d7fae8330f6508d363abecdc2');
define('PPM679_BOUND_SERVER_INSTANCE_ID','ppm-5e2ef7a9-5a11-4682-85f7-cf94d86a59ee');

$ppm679_files=array(
    'includes/diagnostic.php',
    'includes/wp-adapter.php',
    'includes/wp-draft-adapter.php',
    'includes/wp-readback-validator.php',
    'includes/normal-draft-release-validator.php',
    'includes/normal-draft-adapter.php',
    'includes/normal-draft-readback-validator.php',
    'includes/table-hard-rule-validator.php',
    'includes/wordpress-link-target-validator.php',
    'includes/portal-wp-structure-validator.php',
    'includes/category-hierarchy-validator.php',
    'includes/independent-semantic-category-deriver.php',
    'includes/category-structure-inspector.php',
    'includes/category-assignment-validator.php',
    'includes/system-inventory-validator.php',
    'includes/state-transition-validator.php',
    'includes/hard-rule-coverage-validator.php',
    'includes/stateful-write-gate.php',
    'includes/rendered-dom-validator.php',
    'includes/storage.php',
    'includes/article-type-validator.php',
    'includes/three-type-complete-category-source.php',
    'includes/three-type-bundled-release-validator.php',
    'includes/three-type-local-content-validator.php',
    'includes/three-type-bundled-local-preflight.php',
    'includes/three-type-live-test-release-validator.php',
    'includes/three-type-live-test-write-gate.php',
    'includes/three-type-live-test-draft-adapter.php',
    'includes/three-type-live-test-readback-validator.php',
    'includes/three-type-bundled-live-test-entrypoint.php',
    'includes/g9-faq-test-release-validator.php',
    'includes/build-integrity.php',
    'includes/live-state-gate.php',
    'includes/handoff-writer.php',
    'includes/plan-validator.php',
    'includes/content-generator.php',
    'includes/known-error-gate.php',
    'includes/content-structure-language-gate.php',
    'includes/evidence-expiry-validator.php',
    'includes/evidence-registry.php',
    'includes/status-gate.php',
    'includes/gold-core-validator.php',
    'includes/review-matrix-validator.php',
    'includes/editorial-review-engine.php',
    'includes/fail-closed-aggregator.php',
    'includes/content-validator.php',
    'includes/identifier-service.php',
    'includes/editorial-plan-registry.php',
    'includes/journal-content-block-validator.php',
    'includes/content-inventory-reconciler.php',
    'includes/systemwide-duplicate-guard.php',
    'includes/production-wave-governor.php',
    'includes/category-reimport-validator.php',
    'includes/editorial-plan-runtime-gate.php',
    'includes/editorial-plan-admin.php',
    'includes/g9-single-faq-entrypoint.php',
    'includes/normal-draft-pipeline.php',
    'includes/pipeline.php',
    'includes/admin.php',
    'includes/bootstrap.php',
);

$ppm679_missing=array();
foreach ($ppm679_files as $ppm679_relative) {
    $ppm679_path=__DIR__.'/'.$ppm679_relative;
    if (!is_file($ppm679_path)) { $ppm679_missing[]=$ppm679_relative; continue; }
    require_once $ppm679_path;
}

if (!$ppm679_missing && class_exists('PPM679_Plugin')) {
    try {
        PPM679_Plugin::init();
    } catch (Throwable $ppm679_error) {
        if (function_exists('add_action')) {
            add_action('admin_notices',function() use ($ppm679_error) {
                if (function_exists('current_user_can') && !current_user_can('manage_options')) { return; }
                echo '<div class="notice notice-error"><p>Portal Production Machine 6.7.9 wurde sicher blockiert: '.htmlspecialchars($ppm679_error->getMessage(),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</p></div>';
            });
        }
    }
} elseif ($ppm679_missing && function_exists('add_action')) {
    add_action('admin_notices',function() use ($ppm679_missing) {
        if (function_exists('current_user_can') && !current_user_can('manage_options')) { return; }
        echo '<div class="notice notice-error"><p>Portal Production Machine 6.7.9 ist unvollständig. Fehlende Komponenten: '.htmlspecialchars(implode(', ',$ppm679_missing),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</p></div>';
    });
}
