<?php
require_once dirname(__DIR__).'/bootstrap-test.php';
PPM679_WP::reset_test_state(); PPM679_Storage::reset_test_state();
$input=json_decode(file_get_contents(dirname(__DIR__).'/canonical-runtime-input.json'),true);$faq=array_values(array_filter($input['items'],fn($x)=>($x['article_type']??'')==='FAQ'))[0];
$plan=array('contract'=>'production_plan_v4','plan_contract_version'=>'4.0.0','required_plugin_version'=>'6.7.9','plan_id'=>'one-item-positive','gold_core_binding'=>'FOUR_TYPE_APPROVED_GOLD_CORE_V1','contract_hashes'=>PPM679_Plan_Validator::active_contract_hashes(),'items'=>array($faq));
$v=PPM679_Plan_Validator::validate($plan,'g9_isolation','local');
$codes=array_map(fn($e)=>$e['error_code'],$v['errors']);
ppm_test_assert(!in_array('BLOCKED_PLAN_ITEM_COUNT',$codes,true),'general production plan must allow one item by cardinality');
ppm_test_assert(!in_array('BLOCKED_PLAN_REQUIRED_TYPE_MISSING',$codes,true),'general production plan must not require absent article types');
$r=PPM679_G9_Single_FAQ_Entrypoint::execute(array('user_triggered'=>true,'nonce_verified'=>true,'current_user_can_manage'=>true,'declared_contract'=>PPM679_G9_Single_FAQ_Entrypoint::CONTRACT,'declared_plan_item_key'=>PPM679_G9_Single_FAQ_Entrypoint::PLAN_ITEM_KEY,'simulation_only'=>true,'evidence_class'=>'LOCAL_EXECUTED_TEST'));
ppm_test_assert($r['ok']===true,'separate G9 path must be reachable');
ppm_test_assert(count(PPM679_WP::test_posts())===1,'separate path creates exactly one test draft');
echo json_encode(array('status'=>'PASS','general_plan_one_item'=>'PASS_CARDINALITY','separate_g9_entrypoint'=>$r['status'],'article_quality_validators_modified'=>false),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
