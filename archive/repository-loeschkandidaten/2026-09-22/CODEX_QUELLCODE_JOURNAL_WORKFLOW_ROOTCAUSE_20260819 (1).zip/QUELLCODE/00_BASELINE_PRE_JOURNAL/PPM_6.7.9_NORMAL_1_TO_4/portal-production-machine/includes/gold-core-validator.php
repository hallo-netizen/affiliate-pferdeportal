<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_Gold_Core_Validator {
    const VERSION='6.7.9-wave3-quarantine';
    const CONTROL_POSTS=array('FAQ'=>8841,'Beratung'=>8917,'Vergleich'=>8985,'Pflege'=>8997);
    const REQUIRED_METRICS=array(
        'word_count','paragraph_count','heading_structure','ul_count','ol_count','table_count',
        'table_row_count','conclusion_word_count','conclusion_ratio','average_sentence_length',
        'sentence_start_variation','internal_link_count','internal_link_distribution'
    );

    public static function validate_control_baselines($controls,$replacement_approvals=array(),$context='wave3_gold_control_baseline',$server_state_hash='') {
        $controls=is_array($controls)?$controls:array();
        $replacement_approvals=is_array($replacement_approvals)?$replacement_approvals:array();
        $errors=array();
        $seen=array();
        foreach (self::CONTROL_POSTS as $type=>$post_id) {
            $control=null;
            foreach ($controls as $candidate) {
                if ((string)($candidate['article_type']??'')===$type) { $control=$candidate; break; }
            }
            if (!is_array($control)) {
                $errors[]=self::err('CONTROL_BASELINE_MISSING','ALL_FOUR_CONTROL_ARTICLE_TYPES_REQUIRE_EXPLICIT_BASELINE','controls.'.$type,'control record',null,'Ohne bestätigte Referenz bleibt der Goldkern ungeklärt.',$context,$server_state_hash);
                continue;
            }
            $seen[$type]=true;
            foreach (array('post_id','article_type','source_file','content_hash','body_html_hash','body_text_hash','visible_title','baseline_report_hash') as $field) {
                if (!array_key_exists($field,$control) || trim((string)$control[$field])==='') {
                    $errors[]=self::err('CONTROL_BASELINE_FIELD_MISSING','CONTROL_BASELINE_REQUIRES_ALL_MANDATORY_FIELDS','controls.'.$type.'.'.$field,'present non-empty field',$control[$field]??null,'Der Kontrollartikel besitzt nicht alle Pflichtdaten.',$context,$server_state_hash);
                }
            }
            if ((int)($control['post_id']??0)!==$post_id) {
                $approval=(array)($replacement_approvals[$type]??array());
                $valid=($approval['approved_by_human_user']??false)===true
                    && trim((string)($approval['diagnosis']??''))!==''
                    && self::is_hash($approval['new_hash']??'')
                    && trim((string)($approval['reason']??''))!==''
                    && trim((string)($approval['approval_evidence_id']??''))!=='';
                if (!$valid) {
                    $errors[]=self::err('CONTROL_BASELINE_REPLACEMENT_NOT_APPROVED','CONTROL_REPLACEMENT_REQUIRES_DIAGNOSIS_NEW_HASH_REASON_AND_HUMAN_APPROVAL','controls.'.$type.'.post_id',$post_id,$control['post_id']??null,'Ein gescheiterter Kontrollkandidat darf nicht still ersetzt werden.',$context,$server_state_hash);
                }
            }
            foreach (array('content_hash','body_html_hash','body_text_hash','baseline_report_hash') as $field) {
                if (!self::is_hash($control[$field]??'')) {
                    $errors[]=self::err('CONTROL_BASELINE_HASH_INVALID','CONTROL_BASELINE_HASHES_MUST_BE_SHA256','controls.'.$type.'.'.$field,'64 hexadecimal SHA-256',$control[$field]??null,'Der Kontrollartikel ist nicht exakt hashgebunden.',$context,$server_state_hash);
                }
            }
            if (($control['control_baseline_status']??'')!=='PASS') {
                $errors[]=self::err('CONTROL_BASELINE_NOT_PASS','CONTROL_ARTICLE_MUST_HAVE_EXPLICIT_CONTROL_BASELINE_PASS','controls.'.$type.'.control_baseline_status','PASS',$control['control_baseline_status']??null,'Kein Kontrollartikel wird automatisch als fehlerfrei angenommen.',$context,$server_state_hash);
            }
        }
        return array(
            'ok'=>!$errors,
            'control_baseline_status'=>!$errors?'PASS':'UNGEKLÄRT',
            'gold_core_numeric_comparison'=>!$errors?'READY':'UNGEKLÄRT',
            'draft_create_allowed'=>false,
            'errors'=>$errors,
        );
    }

    public static function validate_numeric_gate($metrics,$tolerance_contract,$exceptions=array(),$context='wave3_gold_numeric',$server_state_hash='') {
        $metrics=is_array($metrics)?$metrics:array();
        $tolerance_contract=is_array($tolerance_contract)?$tolerance_contract:array();
        $exceptions=is_array($exceptions)?$exceptions:array();
        $definition=(array)($tolerance_contract['tolerance_definition']??array());
        if (($definition['approved_by_human_user']??false)!==true || trim((string)($definition['approval_evidence_id']??''))==='') {
            return array(
                'ok'=>false,
                'gold_core_numeric_gate'=>'NICHT_AUSGEFÜHRT',
                'draft_create_allowed'=>false,
                'errors'=>array(self::err('GOLD_CORE_TOLERANCE_NOT_APPROVED','TOLERANCE_VALUES_REQUIRE_HUMAN_APPROVAL_AND_EVIDENCE_ID','tolerance_definition','approved human-bound tolerance file',$definition,'Ohne bestätigte Toleranzdatei wird der numerische Goldkern nicht ausgeführt.',$context,$server_state_hash)),
            );
        }
        $tolerance_map=array();
        $errors=array();
        foreach ((array)($definition['metrics']??array()) as $row) {
            $metric=(string)($row['metric']??'');
            $complete=$metric!=='' && array_key_exists('reference_value',$row) && array_key_exists('allowed_minimum',$row) && array_key_exists('allowed_maximum',$row)
                && trim((string)($row['derivation_method']??''))!=='' && trim((string)($row['reference_file']??''))!==''
                && self::is_hash($row['reference_hash']??'') && ($row['approved_by_human_user']??false)===true
                && trim((string)($row['approval_evidence_id']??''))!=='';
            if (!$complete) {
                $errors[]=self::err('GOLD_CORE_TOLERANCE_ROW_INVALID','EVERY_TOLERANCE_VALUE_REQUIRES_DERIVATION_REFERENCE_HASH_AND_HUMAN_APPROVAL','tolerance.metrics.'.$metric,'complete tolerance row',$row,'Toleranzwerte dürfen nicht frei erfunden werden.',$context,$server_state_hash);
                continue;
            }
            $tolerance_map[$metric]=$row;
        }
        foreach (self::REQUIRED_METRICS as $metric) {
            if (!array_key_exists($metric,$metrics)) {
                $errors[]=self::err('GOLD_CORE_METRIC_MISSING','GOLD_CORE_NUMERIC_COMPARISON_REQUIRES_ALL_MANDATORY_METRICS','metrics.'.$metric,'metric record',null,'Eine Pflichtmetrik fehlt.',$context,$server_state_hash);
                continue;
            }
            $record=(array)$metrics[$metric];
            $tol=(array)($tolerance_map[$metric]??array());
            foreach (array('metric_id','candidate_value','reference_value','allowed_minimum','allowed_maximum','derivation_method','candidate_content_hash','reference_content_hash','verdict') as $field) {
                if (!array_key_exists($field,$record) || $record[$field]==='' || $record[$field]===null) {
                    $errors[]=self::err('GOLD_CORE_METRIC_FIELD_MISSING','EVERY_GOLD_CORE_METRIC_REQUIRES_FULL_BOUND_RECORD','metrics.'.$metric.'.'.$field,'present field',$record[$field]??null,'Die Goldkern-Metrik ist nicht vollständig belegt.',$context,$server_state_hash);
                }
            }
            if (!$tol) { continue; }
            $within=self::within($record['candidate_value']??null,$tol['allowed_minimum']??null,$tol['allowed_maximum']??null);
            if (!$within) {
                $exception=(array)($exceptions[$metric]??array());
                if (!self::valid_exception($exception,$metric)) {
                    $errors[]=self::err('GOLD_CORE_METRIC_OUT_OF_RANGE','OUT_OF_RANGE_METRIC_REQUIRES_VERIFIED_HUMAN_APPROVED_EXCEPTION','metrics.'.$metric,array('minimum'=>$tol['allowed_minimum'],'maximum'=>$tol['allowed_maximum']),$record['candidate_value']??null,'Eine Abweichung außerhalb des Toleranzbereichs besitzt keine zulässige menschliche Ausnahme.',$context,$server_state_hash);
                }
            }
        }
        return array(
            'ok'=>!$errors,
            'gold_core_numeric_gate'=>!$errors?'PASS':'BLOCKED',
            'draft_create_allowed'=>false,
            'errors'=>$errors,
        );
    }

    public static function validate_review_evidence($cell,$candidate_document,$gold_reference,$context='wave3_gold_review',$server_state_hash='') {
        $cell=is_array($cell)?$cell:array();
        $candidate_document=is_array($candidate_document)?$candidate_document:array();
        $gold_reference=is_array($gold_reference)?$gold_reference:array();
        $errors=array();
        $criterion=(string)($cell['criterion_id']??'');
        if (!in_array($criterion,array('SECTION_QUALITY_RELATIVE_TO_GOLD_REFERENCE','GOLD_CORE_ALIGNMENT'),true)) {
            return array('ok'=>true,'gold_core_review_gate'=>'NOT_APPLICABLE','errors'=>array());
        }
        foreach (array('gold_reference_id','gold_reference_hash','reference_exact_quote','reference_quote_start_offset','reference_quote_end_offset','comparison_explanation') as $field) {
            if (!array_key_exists($field,$cell) || $cell[$field]==='' || $cell[$field]===null) {
                $errors[]=self::err('GOLD_CORE_EVIDENCE_INVALID','GOLD_CORE_REVIEW_REQUIRES_BOUND_CANDIDATE_AND_REFERENCE_EVIDENCE','cell.'.$field,'present gold evidence field',$cell[$field]??null,'Der Goldkernfund besitzt keinen vollständigen Kandidaten-/Referenzbeleg.',$context,$server_state_hash);
            }
        }
        if ((string)($candidate_document['article_type']??'')!==(string)($gold_reference['article_type']??'')) {
            $errors[]=self::err('GOLD_CORE_ARTICLE_TYPE_MISMATCH','CANDIDATE_AND_GOLD_REFERENCE_MUST_SHARE_ARTICLE_TYPE','gold_reference.article_type',$candidate_document['article_type']??null,$gold_reference['article_type']??null,'Ein Goldkernvergleich über unterschiedliche Beitragsarten ist unzulässig.',$context,$server_state_hash);
        }
        if (!hash_equals((string)($gold_reference['content_hash']??''),(string)($cell['gold_reference_hash']??''))) {
            $errors[]=self::err('GOLD_CORE_REFERENCE_HASH_MISMATCH','CURRENT_GOLD_REFERENCE_HASH_MUST_MATCH_REVIEW_HASH','cell.gold_reference_hash',$gold_reference['content_hash']??null,$cell['gold_reference_hash']??null,'Der Review bindet nicht die aktuelle Goldreferenz.',$context,$server_state_hash);
        }
        $candidate_units=self::candidate_units($cell);
        if (!$candidate_units) {
            $errors[]=self::err('GOLD_CORE_EVIDENCE_INVALID','GOLD_CORE_REVIEW_REQUIRES_CANDIDATE_QUOTE','cell.evidence_units','candidate quote unit',array(),'Der Kandidatenbeleg fehlt.',$context,$server_state_hash);
        } else {
            $u=$candidate_units[0];
            if (!self::quote_matches((string)($candidate_document['body_text']??''),$u['exact_quote']??'',(int)($u['quote_start_offset']??-1),(int)($u['quote_end_offset']??-1))) {
                $errors[]=self::err('GOLD_CORE_EVIDENCE_INVALID','CANDIDATE_QUOTE_MUST_MATCH_BODY_TEXT_OFFSETS','cell.evidence_units.0','exact candidate text slice',$u,'Das Kandidatenzitat ist nicht technisch verifizierbar.',$context,$server_state_hash);
            }
        }
        if (!self::quote_matches((string)($gold_reference['body_text']??''),(string)($cell['reference_exact_quote']??''),(int)($cell['reference_quote_start_offset']??-1),(int)($cell['reference_quote_end_offset']??-1))) {
            $errors[]=self::err('GOLD_CORE_EVIDENCE_INVALID','REFERENCE_QUOTE_MUST_MATCH_GOLD_BODY_TEXT_OFFSETS','cell.reference_exact_quote','exact reference text slice',$cell['reference_exact_quote']??null,'Das Referenzzitat ist nicht technisch verifizierbar.',$context,$server_state_hash);
        }
        if ($criterion==='GOLD_CORE_ALIGNMENT') {
            foreach (array('candidate_structure_evidence','reference_structure_evidence','candidate_metrics','reference_metrics') as $field) {
                if (!isset($cell[$field]) || !is_array($cell[$field]) || !$cell[$field]) {
                    $errors[]=self::err('GOLD_CORE_EVIDENCE_INVALID','GOLD_CORE_ALIGNMENT_REQUIRES_BOTH_STRUCTURE_EVIDENCE_AND_METRICS','cell.'.$field,'non-empty structured evidence',$cell[$field]??null,'Für die artikelweite Goldkernausrichtung fehlen Strukturbelege.',$context,$server_state_hash);
                }
            }
        }
        return array(
            'ok'=>!$errors,
            'gold_core_review_gate'=>!$errors?'PASS':'BLOCKED',
            'errors'=>$errors,
        );
    }

    private static function valid_exception($exception,$metric) {
        if (!is_array($exception) || !$exception) { return false; }
        foreach (array('exception_id','metric_id','candidate_value','reference_value','deviation','exact_reason','candidate_quote','candidate_quote_start_offset','candidate_quote_end_offset','reference_quote','reference_quote_start_offset','reference_quote_end_offset','approval_evidence_id') as $field) {
            if (!array_key_exists($field,$exception) || $exception[$field]==='' || $exception[$field]===null) { return false; }
        }
        return (string)$exception['metric_id']===$metric && ($exception['approved_by_human_user']??false)===true;
    }

    private static function candidate_units($cell) {
        if (isset($cell['evidence_units']) && is_array($cell['evidence_units'])) { return $cell['evidence_units']; }
        if (isset($cell['exact_quote'])) {
            return array(array(
                'exact_quote'=>$cell['exact_quote'],
                'quote_start_offset'=>$cell['quote_start_offset']??null,
                'quote_end_offset'=>$cell['quote_end_offset']??null,
                'quote_fingerprint'=>$cell['quote_fingerprint']??null,
            ));
        }
        return array();
    }

    private static function quote_matches($body,$quote,$start,$end) {
        if ($start<0 || $end<$start) { return false; }
        return substr($body,$start,$end-$start)===$quote;
    }

    private static function within($value,$minimum,$maximum) {
        if (is_numeric($value) && is_numeric($minimum) && is_numeric($maximum)) {
            return (float)$value>=(float)$minimum && (float)$value<=(float)$maximum;
        }
        if (is_array($minimum) || is_array($maximum)) { return $value===$minimum || $value===$maximum; }
        return $value===$minimum || $value===$maximum;
    }

    private static function is_hash($value) { return preg_match('/^[0-9a-f]{64}$/',(string)$value)===1; }

    private static function err($code,$rule,$path,$expected,$actual,$reason,$context,$server_state_hash,$refs=array()) {
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,$context,$server_state_hash,__CLASS__,null,$refs);
    }
}
