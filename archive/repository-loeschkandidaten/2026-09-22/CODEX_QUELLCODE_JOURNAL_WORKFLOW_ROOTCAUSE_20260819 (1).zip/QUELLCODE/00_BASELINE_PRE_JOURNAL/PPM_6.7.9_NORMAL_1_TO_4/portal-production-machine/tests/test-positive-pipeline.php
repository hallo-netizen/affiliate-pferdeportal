<?php
require __DIR__ . '/bootstrap-test.php';

PPM679_WP::reset_test_state();
PPM679_Storage::reset_test_state();
PPM679_Handoff_Permit::reset_test_state();
PPM679_WP::update_option('ppm_publish_enabled','0');
PPM679_WP::update_option('ppm_server_instance_id','ppm-5e2ef7a9-5a11-4682-85f7-cf94d86a59ee');

$plan=json_decode((string)file_get_contents(__DIR__.'/plan-v4.json'),true);
ppm_test_assert(is_array($plan),'Legacy Plan V4 must decode.');

function ppm_positive_error_codes($artifact) {
    $codes=array();
    foreach (($artifact['errors']??array()) as $error) {
        $code=(string)($error['error_code']??'');
        if ($code!=='' && !in_array($code,$codes,true)) { $codes[]=$code; }
    }
    sort($codes);
    return $codes;
}

function ppm_positive_assert_legacy_plan_rejected($artifact,$label) {
    ppm_test_assert(($artifact['status']??'')==='BLOCKED_PLAN_ITEM_FIELD_MISSING',$label.' must be blocked at the canonical plan boundary.');
    ppm_test_assert(($artifact['action_context']??'')==='plan_v4_validation',$label.' must stop before runtime identifiers and drafts.');
    ppm_test_assert(count($artifact['drafts']??array())===0,$label.' must create no drafts.');

    $codes=ppm_positive_error_codes($artifact);
    foreach (array(
        'BLOCKED_PLAN_ITEM_FIELD_MISSING',
        'BLOCKED_CANONICAL_RUNTIME_ORDER_INCOMPLETE',
        'BLOCKED_CANONICAL_ARTICLE_PAYLOAD_INCOMPLETE',
        'BLOCKED_PRODUCTION_TEST_FACT_PACK'
    ) as $required_code) {
        ppm_test_assert(in_array($required_code,$codes,true),$label.' must report '.$required_code.'.');
    }
    return $codes;
}

$result1=PPM679_Pipeline::execute_plan($plan);
$artifact1=$result1['artifact'];
$codes1=ppm_positive_assert_legacy_plan_rejected($artifact1,'First legacy fixture-plan run');
$memory1=PPM679_Storage::memory_snapshot();
ppm_test_assert(empty($memory1['runs']??array()),'Rejected legacy plan must create no run record.');
ppm_test_assert(empty($memory1['items']??array()),'Rejected legacy plan must create no item records.');
ppm_test_assert(empty($memory1['tombstones']??array()),'Rejected legacy plan must reserve no identifiers.');
ppm_test_assert(empty($memory1['posts']??array()),'Rejected legacy plan must persist no WordPress posts.');

$result2=PPM679_Pipeline::execute_plan($plan);
$artifact2=$result2['artifact'];
$codes2=ppm_positive_assert_legacy_plan_rejected($artifact2,'Second legacy fixture-plan run');
$memory2=PPM679_Storage::memory_snapshot();
ppm_test_assert(empty($memory2['runs']??array()),'Repeated rejected legacy plan must create no run record.');
ppm_test_assert(empty($memory2['items']??array()),'Repeated rejected legacy plan must create no item records.');
ppm_test_assert(empty($memory2['tombstones']??array()),'Repeated rejected legacy plan must reserve no identifiers.');
ppm_test_assert(empty($memory2['posts']??array()),'Repeated rejected legacy plan must persist no WordPress posts.');
ppm_test_assert($codes1===$codes2,'Repeated legacy-plan rejection must report the same blocker classes.');
ppm_test_assert(PPM679_WP::get_option('ppm_publish_enabled','1')==='0','Publish must remain disabled.');

$publish_hook=false;
foreach (array_keys($GLOBALS['ppm_test_hooks']) as $hook) {
    if (stripos((string)$hook,'publish')!==false) { $publish_hook=true; }
}
ppm_test_assert(!$publish_hook,'No publish hook may be registered.');

$report=array(
    'contract'=>'ppm679_positive_pipeline_test_v3',
    'status'=>'LEGACY_FIXTURE_PLAN_REJECTED_BEFORE_RUNTIME_OK',
    'purpose'=>'Positive proof that the former fixture/mini-generator plan cannot enter the canonical runtime or create drafts.',
    'first_status'=>$artifact1['status'],
    'second_status'=>$artifact2['status'],
    'action_context'=>$artifact1['action_context'],
    'reported_error_codes'=>$codes1,
    'run_records_created'=>0,
    'identifiers_reserved'=>0,
    'drafts_created'=>0,
    'posts_persisted'=>0,
    'publish_allowed'=>false,
    'registered_hooks'=>array_keys($GLOBALS['ppm_test_hooks']),
    'registered_routes'=>array_keys($GLOBALS['ppm_test_routes'])
);
echo json_encode($report,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)."\n";
