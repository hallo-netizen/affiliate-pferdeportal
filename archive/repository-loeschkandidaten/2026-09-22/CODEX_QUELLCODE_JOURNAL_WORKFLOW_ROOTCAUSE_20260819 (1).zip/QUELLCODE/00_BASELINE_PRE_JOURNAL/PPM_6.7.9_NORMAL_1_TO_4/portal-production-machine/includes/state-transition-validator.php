<?php
if (!defined('ABSPATH')) { return; }

final class PPM679_State_Transition_Validator {
    const VERSION='6.7.9';
    const CONTRACT_FILE='contracts/state-transition-matrix-v3-1.json';
    const REGISTRY_FILE='contracts/hard-rule-registry-v1.json';

    private static function err($code,$rule,$path,$expected,$actual,$reason){
        return PPM679_Diagnostic::error($code,$rule,$path,$expected,$actual,$reason,'v31_state_transition_matrix','',__CLASS__,null,array(self::CONTRACT_FILE,self::REGISTRY_FILE));
    }
    private static function load($rel=self::CONTRACT_FILE){
        $p=PPM679_PLUGIN_DIR.$rel;
        $d=is_file($p)?json_decode((string)file_get_contents($p),true):null;
        return is_array($d)?$d:null;
    }
    public static function validate(){
        $c=self::load();$errors=array();
        if(!is_array($c)){return array(self::err('BLOCKED_V31_TRANSITION_MATRIX_MISSING','STATE_TRANSITION_MATRIX_MUST_EXIST','transitions',self::CONTRACT_FILE,null,'Die Zustands- und Übergangsmatrix fehlt.'));}
        $self=(string)($c['contract_self_sha256']??'');$copy=$c;unset($copy['contract_self_sha256']);$actual=PPM679_Diagnostic::stable_hash($copy);
        if($self===''||!hash_equals($self,$actual)){$errors[]=self::err('BLOCKED_V31_TRANSITION_MATRIX_HASH','STATE_TRANSITION_MATRIX_SELF_HASH_MUST_MATCH','transitions.contract_self_sha256',$actual,$self,'Die Zustandsmatrix wurde verändert.');}
        $required=array('V31-S01','V31-S02','V31-S03','V31-S04A','V31-S04B','V31-S05','V31-S06','V31-S07','V31-S08','V31-S09','V31-S10','V31-S11','V31-S12');
        $registry=self::load(self::REGISTRY_FILE);$rules=array();foreach((array)($registry['rules']??array()) as $r){if(($r['active']??false)===true){$rules[(string)($r['rule_id']??'')]=true;}}
        $seen=array();
        foreach((array)($c['scenarios']??array()) as $s){
            $id=(string)($s['scenario_id']??'');if($id===''){continue;}$seen[]=$id;
            foreach(array('initial_state','action','allowed_result','blocking_result','positive_test','negative_test','raw_evidence_requirement','hard_rule_ids') as $f){
                if(!isset($s[$f])||$s[$f]===''||$s[$f]===array()){$errors[]=self::err('BLOCKED_V31_TRANSITION_MAPPING_INCOMPLETE','EVERY_STATE_TRANSITION_REQUIRES_COMPLETE_MAPPING','transitions.'.$id.'.'.$f,'non-empty',$s[$f]??null,'Ein Zustandsübergang ist nicht vollständig beschrieben.');}
            }
            foreach((array)($s['hard_rule_ids']??array()) as $rid){if(!isset($rules[(string)$rid])){$errors[]=self::err('BLOCKED_V31_TRANSITION_RULE_UNKNOWN','STATE_TRANSITION_RULE_ID_MUST_EXIST_IN_ACTIVE_REGISTRY','transitions.'.$id.'.hard_rule_ids','active rule id',$rid,'Ein Szenario verweist auf keine aktive Regel.');}}
            foreach(array('positive_test','negative_test') as $f){$p=PPM679_PLUGIN_DIR.(string)($s[$f]??'');if(!is_file($p)){$errors[]=self::err('BLOCKED_V31_TRANSITION_TEST_MISSING','EVERY_STATE_TRANSITION_TEST_PATH_MUST_EXIST','transitions.'.$id.'.'.$f,'existing file',$s[$f]??null,'Ein Szenariotest fehlt.');}}
            if(($s['persistent_fixture_required']??null)!==true){$errors[]=self::err('BLOCKED_V31_PERSISTENT_SCENARIO_UNTESTED','EVERY_V31_TRANSITION_REQUIRES_PERSISTENT_FIXTURE','transitions.'.$id.'.persistent_fixture_required',true,$s['persistent_fixture_required']??null,'Das Szenario verwendet keinen persistenten Ausgangszustand.');}
        }
        sort($seen,SORT_STRING);$expected=$required;sort($expected,SORT_STRING);
        if($seen!==$expected){$errors[]=self::err('BLOCKED_V31_TRANSITION_SET_INCOMPLETE','ALL_REQUIRED_V31_STATE_SCENARIOS_MUST_BE_PRESENT','transitions.scenario_ids',$expected,$seen,'Die V3.1-Mindestszenarien sind nicht vollständig.');}
        if((int)($c['scenario_count']??-1)!==count($required)||count((array)($c['scenarios']??array()))!==count($required)){$errors[]=self::err('BLOCKED_V31_TRANSITION_COUNT_MISMATCH','DECLARED_AND_ACTUAL_SCENARIO_COUNT_MUST_BE_13','transitions.scenario_count',13,array($c['scenario_count']??null,count((array)($c['scenarios']??array()))),'Die Szenarioanzahl stimmt nicht.');}
        foreach(array('TRANSITION_UNTESTED','PERSISTENT_SCENARIO_UNTESTED') as $k){if((int)(($c['blocking_counts'][$k]??-1))!==0){$errors[]=self::err('BLOCKED_V31_TRANSITION_COUNT','TRANSITION_AND_PERSISTENT_SCENARIO_COUNTS_MUST_BE_ZERO','transitions.blocking_counts.'.$k,0,$c['blocking_counts'][$k]??null,'Ein Zustandsprüfungszähler ist nicht null.');}}
        if(($c['absolute_completeness_claimed']??null)!==false){$errors[]=self::err('BLOCKED_V31_TRANSITION_ABSOLUTE_CLAIM','TRANSITION_MATRIX_MUST_NOT_CLAIM_ABSOLUTE_COMPLETENESS','transitions.absolute_completeness_claimed',false,$c['absolute_completeness_claimed']??null,'Die Zustandsmatrix darf keine absolute Vollständigkeit behaupten.');}
        return $errors;
    }
}
