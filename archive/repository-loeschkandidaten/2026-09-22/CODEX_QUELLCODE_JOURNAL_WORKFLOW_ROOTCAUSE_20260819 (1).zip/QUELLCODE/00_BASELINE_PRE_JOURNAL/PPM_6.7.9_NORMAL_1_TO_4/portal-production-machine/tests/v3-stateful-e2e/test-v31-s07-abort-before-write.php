<?php
require_once __DIR__.'/fixture-builder.php';
$p=v31_prepare('g9-request-v31-abort-before-0007',true);
ppm_test_assert($p['ok']===true,'dry run plan');
ppm_test_assert(count(PPM679_WP::test_posts())===1,'no write during dry run');
PPM679_Stateful_Write_Gate::reset_test_state();
$r=v31_execute_g9('g9-request-v31-after-abort-0007');
ppm_test_assert($r['ok']===true,'new authorized request after prewrite abort');
ppm_test_assert(count(PPM679_WP::test_posts())===2,'one new draft only');
echo json_encode(array('status'=>'PASS_V31_S07_ABORT_BEFORE_WRITE','dry_run_fingerprint'=>$p['plan']['planned_write_fingerprint'],'new_post_id'=>$r['post_id']),JSON_UNESCAPED_SLASHES)."\n";
