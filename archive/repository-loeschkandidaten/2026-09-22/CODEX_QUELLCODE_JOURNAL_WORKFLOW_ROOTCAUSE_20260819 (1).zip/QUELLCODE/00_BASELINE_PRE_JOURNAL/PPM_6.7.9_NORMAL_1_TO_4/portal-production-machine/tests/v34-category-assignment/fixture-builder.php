<?php
require_once dirname(__DIR__).'/bootstrap-test.php';

function v34_contract(){return json_decode((string)file_get_contents(dirname(__DIR__,2).'/contracts/g9-single-faq-approved-candidate-v1.json'),true);}
function v34_snapshot(){return PPM679_Category_Hierarchy_Validator::load();}

function v34_semantic_from_contract($c){
    $quality=(array)($c['item']['quality_binding']??array());
    $keywords=array_values(array_unique(array_merge((array)($quality['intent_terms']??array()),array((string)($c['item']['target_keyword']??''),(string)($c['item']['runtime_order']['subject_label']??'')))));
    return PPM679_Category_Assignment_Validator::semantic_input_from_article_fields(
        (string)($c['candidate']['title']??''),(string)($c['item']['topic']??''),(string)($c['item']['search_intent']??''),
        (string)($c['item']['article_type']??''),(string)($c['candidate']['content_html']??''),$keywords,4,'pferde-atelier','category'
    );
}
function v34_semantic($contract=null){$c=$contract?:v34_contract();return v34_semantic_from_contract($c);}
function v34_independent($contract=null,$snapshot=null){$c=$contract?:v34_contract();$s=$snapshot?:v34_snapshot();return PPM679_Category_Assignment_Validator::derive_independent(v34_semantic($c),$s);}
function v34_assignment($contract=null,$snapshot=null){$c=$contract?:v34_contract();$s=$snapshot?:v34_snapshot();$i=PPM679_Category_Assignment_Validator::derive_independent(v34_semantic($c),$s);if(empty($i['ok']))return $i;return PPM679_Category_Assignment_Validator::compare_and_resolve($i,(array)$c['candidate']['category_binding'],$s);}

function v36_wp_contract(){return PPM679_Portal_WP_Structure_Validator::wp_contract();}
function v36_wp_snapshot(){return PPM679_Portal_WP_Structure_Validator::wp_snapshot();}
function v36_portal_contract(){return PPM679_Portal_WP_Structure_Validator::portal_contract();}
function v36_valid_binding(){return (array)v34_contract()['candidate']['category_binding'];}
