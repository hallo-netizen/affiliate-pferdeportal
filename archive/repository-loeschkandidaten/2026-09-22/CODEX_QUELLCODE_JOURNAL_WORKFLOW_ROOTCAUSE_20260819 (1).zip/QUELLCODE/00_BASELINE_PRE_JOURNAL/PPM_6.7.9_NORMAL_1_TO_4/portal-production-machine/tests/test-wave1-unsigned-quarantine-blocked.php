<?php
declare(strict_types=1);
require __DIR__.'/bootstrap-test.php';
$errors=PPM679_Build_Integrity::verify('wave1_unsigned_quarantine','local-state-hash');
ppm_test_assert(is_array($errors)&&count($errors)>0,'Unsigned quarantine must fail signed build integrity');
$codes=array_values(array_unique(array_map(fn($e)=>(string)($e['error_code']??''),$errors)));
ppm_test_assert(in_array('BLOCKED_ACTIVE_COMPONENT_HASH_MISMATCH',$codes,true),'Changed quarantine source must report active component mismatch');
echo json_encode(array(
 'contract'=>'wave1_unsigned_quarantine_build_block_report_v1',
 'status'=>'PASS',
 'expected_build_status'=>'BLOCKED',
 'actual_error_codes'=>$codes,
 'error_count'=>count($errors),
 'publish_allowed'=>false
),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
