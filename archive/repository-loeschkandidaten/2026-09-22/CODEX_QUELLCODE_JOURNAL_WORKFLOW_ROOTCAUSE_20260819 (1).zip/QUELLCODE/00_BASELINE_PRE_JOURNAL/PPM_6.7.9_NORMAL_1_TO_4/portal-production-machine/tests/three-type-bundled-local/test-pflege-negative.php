<?php
require __DIR__.'/bootstrap-three-type.php';
[$item,$pack,$g]=ppm_three_generated('Pflege');ppm_test_assert(!empty($g['ok']),'valid Pflege generation');
$g['content_html']=preg_replace('/data-block="steps"/','data-block="steps-mutated"',$g['content_html'],1);$g['content_hash']=hash('sha256',$g['content_html']);
$r=PPM679_Three_Type_Bundled_Local_Preflight::validate_generated_mutation($g,$item,$pack,'pflege_required_steps');$codes=ppm_three_codes($r['errors']);
ppm_test_assert(empty($r['ok']),'mutated Pflege must block');ppm_test_assert(in_array('BLOCKED_CONTENT_REQUIRED_BLOCK_MISSING',$codes,true),'Pflege missing steps code');
echo json_encode(['status'=>'PASS_PFLEGE_NEGATIVE_MUTATION_BLOCKED','expected_code'=>'BLOCKED_CONTENT_REQUIRED_BLOCK_MISSING','codes'=>$codes],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)."\n";
