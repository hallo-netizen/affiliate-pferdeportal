<?php
require_once dirname(__DIR__).'/bootstrap-test.php';
$root=dirname(__DIR__,2);
$source=json_decode((string)file_get_contents($root.'/traceability/WAVE4_REQUIREMENT_SOURCE_SNAPSHOT.json'),true);
$binding=json_decode((string)file_get_contents($root.'/traceability/WAVE4_REQUIREMENT_IMPLEMENTATION_BINDING.json'),true);
ppm_test_assert(is_array($source)&&($source['requirement_count']??0)===119,'source snapshot must contain 119 requirements');
ppm_test_assert(is_array($binding)&&($binding['bound_requirement_count']??0)===119,'binding must contain 119 rows');
ppm_test_assert(hash('sha256',(string)file_get_contents($root.'/traceability/WAVE4_REQUIREMENT_SOURCE_SNAPSHOT.json'))===($binding['source_snapshot_sha256']??''),'source snapshot hash binding');
$sourceMap=array(); foreach($source['requirements'] as $r){ $sourceMap[$r['requirement_id']]=$r; }
$seen=array(); $external=0; $full=0;
foreach($binding['rows'] as $row){
 $id=$row['requirement_id']??''; ppm_test_assert($id!==''&&!isset($seen[$id]),'unique requirement id '.$id); $seen[$id]=true;
 ppm_test_assert(isset($sourceMap[$id]),'bound id must exist in source '.$id);
 ppm_test_assert(($row['exact_requirement_hash']??'')===($sourceMap[$id]['requirement_text_sha256']??''),'exact hash '.$id);
 ppm_test_assert(($row['source_text_hash']??'')===($sourceMap[$id]['source_text_sha256']??''),'source hash '.$id);
 ppm_test_assert(($row['requirement_pass_claimed']??true)===false,'no local final requirement PASS '.$id);
 foreach((array)($row['implementation_path_sha256']??array()) as $path=>$hash){ ppm_test_assert(is_file($root.'/'.$path),'implementation path exists '.$path); ppm_test_assert(hash_file('sha256',$root.'/'.$path)===$hash,'implementation hash '.$path); }
 foreach(array('positive_test_path','negative_test_path') as $field){ $path=$row[$field]??''; ppm_test_assert($path!==''&&is_file($root.'/'.$path),'test path exists '.$id.' '.$field); }
 $status=$row['implementation_evidence_status']??''; if(strpos($status,'EXTERNAL_SERVER_OR_USER')!==false){$external++;} if(strpos($status,'FULL_DETERMINISTIC')===0){$full++;}
}
ppm_test_assert(count($seen)===119,'all 119 unique requirements');
ppm_test_assert($external>0,'external server/user evidence must remain explicit');
ppm_test_assert($full>0,'deterministic automated gates must be mapped');
echo json_encode(array('contract'=>'wave4_qf03_traceability_test_v1','status'=>'PASS','source_requirement_count'=>count($sourceMap),'bound_requirement_count'=>count($seen),'full_deterministic_rows'=>$full,'external_evidence_required_rows'=>$external,'final_requirement_pass_claimed'=>false),JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";
