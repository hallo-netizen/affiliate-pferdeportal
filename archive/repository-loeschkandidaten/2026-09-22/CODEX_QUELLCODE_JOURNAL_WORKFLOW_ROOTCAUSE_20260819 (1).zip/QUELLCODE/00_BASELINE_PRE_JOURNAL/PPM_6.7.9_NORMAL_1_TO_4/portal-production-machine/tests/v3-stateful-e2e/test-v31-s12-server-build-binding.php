<?php
require_once __DIR__.'/fixture-builder.php';
$p=v31_prepare('g9-request-v31-server-build-0012',false);ppm_test_assert($p['ok']===true,'prepare');
$bad=$p['plan'];$bad['identity']['server_instance_id']='ppm-other-instance';
$e=PPM679_Stateful_Write_Gate::validate_plan($bad,$p['candidate'],$p['gate'],false);
ppm_test_assert(!empty($e),'server mismatch blocks');
ppm_test_assert($e[0]['error_code']==='BLOCKED_QF03_PLANNED_WRITE_FINGERPRINT_MISMATCH'||$e[0]['error_code']==='BLOCKED_QF03_PLANNED_WRITE_BINDING_MISMATCH','fingerprint/binding detects server mutation');
$bad2=$p['plan'];$bad2['identity']['build_manifest_sha256']=str_repeat('b',64);
$e2=PPM679_Stateful_Write_Gate::validate_plan($bad2,$p['candidate'],$p['gate'],false);
ppm_test_assert(!empty($e2),'build mismatch blocks');
echo json_encode(array('status'=>'PASS_V31_S12_SERVER_BUILD_BINDING','server_error'=>$e[0]['error_code'],'build_error'=>$e2[0]['error_code']),JSON_UNESCAPED_SLASHES)."\n";
