# Portal SEO Themenengine 0.26.0

## V81 – revisionssichere Sandbox-Entscheidungen und exporttreuer Datenfluss

- Bereits manuell gespeicherte Portalrelevanz kann kontrolliert korrigiert werden (`Relevanzentscheidung ändern`).
- Jede Korrektur ist optimistisch gegen den aktuellen Entscheidungs-Hash gebunden; veraltete Formulare werden fail-closed blockiert.
- Frühere manuelle Entscheidungen und der dazugehörige Sandbox-Folgezustand werden unverändert im Revisionsarchiv erhalten.
- Eine Relevanzkorrektur verwirft abgeleitete interne Sandbox-Zuordnungen und berechnet den nachgelagerten Sandbox-Zustand aus dem aktuellen Quellbestand neu.
- Nach bereits ausgeführtem Reentry ist eine Relevanzkorrektur in diesem Workflow gesperrt.
- Semantic Sandbox erhält Statusfilter und Keyword-Suche, damit Review-Fälle gezielt auffindbar sind.
- Sandbox-Export wird nicht mehr durch generisches Credential-Scrubbing strukturell verändert. Stattdessen wird vor dem Export fail-closed auf konkrete Credential-Schlüssel und tatsächliche Secret-Werte geprüft.
- Export enthält `stored_registry_sha256` und einen selbstprüfbaren `export_sha256`.
- Keine Änderung an Textmaschine, Produktionsmaschine, Artikeln, Kategorien, HTML, Design oder dem Fünf-Feld-Handoff.
