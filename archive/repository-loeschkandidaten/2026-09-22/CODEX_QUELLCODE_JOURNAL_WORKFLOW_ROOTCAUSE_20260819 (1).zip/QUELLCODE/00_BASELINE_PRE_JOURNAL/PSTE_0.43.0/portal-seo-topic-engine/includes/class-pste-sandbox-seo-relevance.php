<?php
if (!defined('ABSPATH')) { return; }

/**
 * Read-only interpretation of real Google organic SERP evidence for Sandbox candidates.
 * It decides external portal-topic relevance only. It never assigns a family/category,
 * never changes the primary matcher and never writes portal/source data.
 *
 * V70 root rule: the portal subject alone (e.g. a site-name token) is not sufficient
 * evidence of editorial relevance. Positive automatic relevance needs independent
 * corroboration from the portal's real editorial scope (derived from taxonomy paths).
 * Missing positive evidence is never an automatic negative decision.
 */
final class PSTE_Sandbox_SEO_Relevance {
    public const CONTRACT='PSTE_SANDBOX_EXTERNAL_RELEVANCE_V2';

    /** @return array<string,mixed> */
    public static function evaluate(string $query,array $response,array $registry,string $environment): array {
        $environment=strtolower(trim($environment));
        $themeAnchors=self::portalAnchors($registry);
        $scopeAnchors=self::portalScopeAnchors($registry,$themeAnchors);
        $organic=PSTE_DataForSEO_Client::extractOrganicResults($response);
        $evidence=[];$themeHitRows=0;$scopeHitRows=0;$jointHitRows=0;$themeFreq=[];$scopeFreq=[];
        foreach($organic as $row){
            $text=implode(' ',[(string)($row['title']??''),(string)($row['description']??''),(string)($row['breadcrumb']??''),(string)($row['domain']??'')]);
            $tokens=PSTE_Token_Equivalence::tokens($text);$matchedTheme=[];$matchedScope=[];
            foreach($themeAnchors as $anchor){if(self::tokensSupportAnchor($tokens,(string)$anchor,false)){$matchedTheme[]=$anchor;$themeFreq[$anchor]=($themeFreq[$anchor]??0)+1;}}
            foreach($scopeAnchors as $anchor){if(self::tokensSupportAnchor($tokens,(string)$anchor,true)){$matchedScope[]=$anchor;$scopeFreq[$anchor]=($scopeFreq[$anchor]??0)+1;}}
            if($matchedTheme)$themeHitRows++;if($matchedScope)$scopeHitRows++;if($matchedTheme&&$matchedScope)$jointHitRows++;
            $evidence[]=[
                'rank'=>(int)($row['rank']??0),'domain'=>self::clip((string)($row['domain']??''),160),
                'url'=>self::clip((string)($row['url']??''),500),'title'=>self::clip((string)($row['title']??''),300),
                'description'=>self::clip((string)($row['description']??''),500),'breadcrumb'=>self::clip((string)($row['breadcrumb']??''),240),
                'matched_portal_anchors'=>array_values($matchedTheme),'matched_scope_anchors'=>array_values($matchedScope),
            ];
        }
        $count=count($organic);$status='UNCERTAIN_REVIEW';$reason=['PSTE_SANDBOX_SERP_EVIDENCE_INCONCLUSIVE'];
        if($environment!=='production'){$status='UNCERTAIN_PROVIDER_SANDBOX';$reason=['PSTE_SANDBOX_REAL_SEO_REQUIRES_PRODUCTION_ENVIRONMENT'];}
        elseif(!$themeAnchors){$status='UNCERTAIN_REVIEW';$reason=['PSTE_SANDBOX_PORTAL_THEME_ANCHORS_UNAVAILABLE'];}
        elseif(!$scopeAnchors){$status='UNCERTAIN_REVIEW';$reason=['PSTE_SANDBOX_PORTAL_SCOPE_ANCHORS_UNAVAILABLE'];}
        elseif($count<5){$status='UNCERTAIN_REVIEW';$reason=['PSTE_SANDBOX_SERP_TOO_FEW_ORGANIC_RESULTS'];}
        elseif($themeHitRows>=2&&$scopeHitRows>=2&&$jointHitRows>=2){$status='RELEVANT_FOR_PORTAL';$reason=['PSTE_SANDBOX_SERP_THEME_AND_EDITORIAL_SCOPE_CORROBORATED'];}
        elseif($themeHitRows>=2&&$scopeHitRows===0){$status='UNCERTAIN_REVIEW';$reason=['PSTE_SANDBOX_SERP_THEME_ONLY_NOT_ENOUGH_FOR_EDITORIAL_RELEVANCE'];}
        elseif($themeHitRows===0){$status='UNCERTAIN_REVIEW';$reason=['PSTE_SANDBOX_SERP_NO_POSITIVE_PORTAL_THEME_SIGNAL_REQUIRES_REVIEW'];}
        else{$status='UNCERTAIN_REVIEW';$reason=['PSTE_SANDBOX_SERP_SCOPE_CORROBORATION_INSUFFICIENT'];}
        arsort($themeFreq,SORT_NUMERIC);arsort($scopeFreq,SORT_NUMERIC);
        return [
            'contract'=>self::CONTRACT,'query'=>$query,'status'=>$status,'reason_codes'=>$reason,
            'environment'=>$environment,'organic_result_count'=>$count,
            'portal_anchor_hit_result_count'=>$themeHitRows,'portal_scope_hit_result_count'=>$scopeHitRows,'joint_theme_scope_hit_result_count'=>$jointHitRows,
            'portal_anchors'=>$themeAnchors,'portal_scope_anchors'=>$scopeAnchors,
            'matched_anchor_frequency'=>$themeFreq,'matched_scope_anchor_frequency'=>$scopeFreq,
            'evidence'=>$evidence,'response_sha256'=>PSTE_DataForSEO_Client::responseSha256($response),
            'retrieved_at_utc'=>PSTE_DataForSEO_Client::retrievedAtUtc($response),'cache_hit'=>PSTE_DataForSEO_Client::cacheHit($response),
            'actual_cost_usd'=>PSTE_DataForSEO_Client::responseCostUsd($response),
            'decision_scope'=>'EXTERNAL_PORTAL_RELEVANCE_ONLY','automatic_negative_decision_enabled'=>false,
            'portal_subject_alone_can_prove_relevance'=>false,'family_assignment_attempted'=>false,
            'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,
        ];
    }

    /** Portal-independent theme anchors derived only from the live registry/site identity. @return list<string> */
    public static function portalAnchors(array $registry): array {
        $families=(array)($registry['families']??[]);$familyCount=count($families);if($familyCount===0)return [];
        $freq=[];
        foreach($families as $family){
            $seen=[];$identity=(array)($family['identity_v2']??[]);
            foreach((array)($identity['portal_context_tokens']??[]) as $value)foreach(PSTE_Token_Equivalence::tokens((string)$value) as $token)$seen[$token]=true;
            foreach((array)($identity['context_groups']??[]) as $group)foreach((array)$group as $value)foreach(PSTE_Token_Equivalence::tokens((string)$value) as $token)$seen[$token]=true;
            foreach(array_keys($seen) as $token)$freq[$token]=($freq[$token]??0)+1;
        }
        $stop=self::stopwords();$min=max(2,(int)ceil($familyCount*0.08));$eligible=[];
        foreach($freq as $token=>$count){if(strlen($token)<3||isset($stop[$token])||$count<$min)continue;$eligible[$token]=$count;}
        arsort($eligible,SORT_NUMERIC);$anchors=array_slice(array_keys($eligible),0,16);
        $site=function_exists('get_bloginfo')?(string)get_bloginfo('name'):'';
        foreach(PSTE_Token_Equivalence::tokens($site) as $token)if(isset($freq[$token])&&!isset($stop[$token])&&!in_array($token,$anchors,true))$anchors[]=$token;
        return array_values(array_slice(array_unique($anchors),0,20));
    }

    /**
     * Conservative editorial-scope anchors from the broadest real taxonomy level only, never from a hard-coded industry list.
     * Deeper category/family words are deliberately excluded from automatic positive relevance because they can overfit.
     * @param list<string> $themeAnchors
     * @return list<string>
     */
    public static function portalScopeAnchors(array $registry,array $themeAnchors=[]): array {
        $stop=self::stopwords();foreach($themeAnchors as $t)$stop[(string)$t]=true;$out=[];
        foreach((array)($registry['families']??[]) as $family){
            $rows=array_values((array)($family['by_type']??[]));if(!$rows)continue;
            $path=trim((string)($rows[0]['full_path']??''));if($path==='')continue;
            $parts=array_values(array_filter(array_map('trim',explode('>',$path)),static fn($v)=>$v!==''));
            foreach(array_slice($parts,0,1) as $part){
                foreach(PSTE_Token_Equivalence::tokens($part) as $token){if(strlen($token)<3||isset($stop[$token]))continue;$out[$token]=true;}
            }
        }
        $anchors=array_keys($out);sort($anchors,SORT_STRING);return $anchors;
    }

    /** Exact/controlled German compound support. Suffix support is allowed only for broad taxonomy-scope anchors. */
    private static function tokensSupportAnchor(array $tokens,string $anchor,bool $allowSuffix): bool {
        $anchor=trim($anchor);if($anchor==='')return false;
        foreach($tokens as $token){$token=(string)$token;if(hash_equals($token,$anchor))return true;if(strlen($anchor)<3||strlen($token)<strlen($anchor)+2)continue;if(str_starts_with($token,$anchor))return true;if($allowSuffix&&str_ends_with($token,$anchor))return true;}
        return false;
    }

    /** @return array<string,bool> */
    private static function stopwords(): array {
        $out=[];
        foreach(['und','oder','der','die','das','ein','eine','einer','einen','mit','von','vom','fuer','im','in','am','an','auf','bei','zum','zur','portal','atelier','ratgeber','faq','vergleich','beratung','wissen','pflege','sicherheit','test','kauf','shop','online','de','com','www'] as $word){
            foreach(PSTE_Token_Equivalence::tokens($word) as $token)if($token!=='')$out[$token]=true;
        }
        return $out;
    }
    private static function clip(string $value,int $max): string {$value=trim(preg_replace('/\s+/u',' ',$value)??$value);return function_exists('mb_substr')?mb_substr($value,0,$max,'UTF-8'):substr($value,0,$max);}
}
