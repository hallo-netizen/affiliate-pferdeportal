<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Analytics {
    private static ?array $adminCandidatesCache=null;
    private static ?array $adminInventoryCache=null;

    private static function adminCandidates(): array {if(!is_array(self::$adminCandidatesCache))self::$adminCandidatesCache=PSTE_Repository::adminTopicPoolCandidates('all','',100000);return self::$adminCandidatesCache;}
    private static function adminInventory(): array {if(!is_array(self::$adminInventoryCache))self::$adminInventoryCache=(array)(PSTE_Snapshot::inventory()['items']??[]);return self::$adminInventoryCache;}
    public static function topicRows(): array {
        $rows=[];$inventory=self::adminInventory();
        foreach($inventory as $item){if(!in_array((string)($item['status']??''),['publish','draft'],true))continue;$rows[]=[
            'source'=>'WORDPRESS','category_id'=>(int)($item['category_id']??0),'category_name'=>(string)($item['category_name']??''),'topic'=>(string)($item['title']??''),
            'article_type'=>self::articleTypeFromCategory((string)($item['category_name']??'')),'intent'=>null,'status'=>strtoupper((string)($item['status']??'')),
            'search_volume'=>null,'priority'=>null,'canonical_article_id'=>(string)($item['canonical_article_id']??''),'post_id'=>(int)($item['post_id']??0),
        ];}
        foreach(self::adminCandidates() as $c){if(!empty($c['discovery_only'])||(string)($c['planning_suitability']??'NO')==='NO')continue;$rows[]=[
            'source'=>'PSTE','category_id'=>(int)($c['target_category_id']??0),'category_name'=>(string)($c['target_category_name']??''),'topic'=>PSTE_Editorializer::displayTitle($c),
            'article_type'=>(string)($c['proposed_article_type']??''),'intent'=>(string)($c['metrics']['search_intent']??''),'status'=>(string)($c['pool_status']??$c['decision']??'REVIEW_REQUIRED'),
            'search_volume'=>$c['metrics']['search_volume']??null,'priority'=>null,'canonical_article_id'=>'','post_id'=>0,'candidate_id'=>(string)($c['candidate_id']??''),
        ];}
        usort($rows,static fn($a,$b)=>[$a['category_name'],$a['source'],$a['topic']]<=>[$b['category_name'],$b['source'],$b['topic']]);return $rows;
    }

    public static function keywordRows(): array {
        $rows=[];foreach(self::adminCandidates() as $c){$sources=[];foreach(($c['evidence']??[]) as $e){$s=(string)($e['source']??'');if($s!=='')$sources[$s]=true;}$rows[]=[
            'category_name'=>(string)($c['target_category_name']??''),'keyword'=>PSTE_Editorializer::displayTitle($c),'raw_question'=>(string)($c['raw_user_question']??''),
            'intent'=>(string)($c['metrics']['search_intent']??''),'intent_probability'=>$c['metrics']['intent_probability']??null,'search_volume'=>$c['metrics']['search_volume']??null,
            'decision'=>(string)($c['decision']??'REVIEW_REQUIRED'),'pool_status'=>(string)($c['pool_status']??$c['decision']??'REVIEW_REQUIRED'),'article_type'=>(string)($c['proposed_article_type']??''),'sources'=>array_keys($sources),'candidate'=>$c,
        ];}usort($rows,static fn($a,$b)=>[$a['category_name'],$a['keyword']]<=>[$b['category_name'],$b['keyword']]);return $rows;
    }

    public static function coverage(): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$leaf=is_array($baseline)?($baseline['leaf_categories']??[]):[];$inventory=self::adminInventory();$candidates=self::adminCandidates();$gsc=PSTE_Repository::gscCategorySummary((string)get_option(PSTE_OPTION_GSC_SELECTED_PROPERTY,''));
        $categoryToFamily=[];$families=[];
        foreach($leaf as $cat){$id=(int)($cat['term_id']??0);$key=(string)($cat['topic_family_key']??PSTE_Normalizer::categoryFamilyKey((string)($cat['name']??'')));if($id<=0||$key==='')continue;$categoryToFamily[$id]=$key;if(!isset($families[$key]))$families[$key]=['topic_family_key'=>$key,'topic_family_name'=>(string)($cat['topic_family_name']??PSTE_Normalizer::categoryFamilyName((string)($cat['name']??''))),'category_ids'=>[]];$families[$key]['category_ids'][]=$id;}
        $actual=[];foreach($inventory as $item){if(($item['status']??'')!=='publish')continue;$key=(string)($item['topic_family_key']??'');if($key==='')$key=$categoryToFamily[(int)($item['category_id']??0)]??'';if($key!=='')$actual[$key]=($actual[$key]??0)+1;}
        $planned=[];$volumes=[];foreach($candidates as $c){if(!empty($c['discovery_only']))continue;$key=(string)($c['topic_family_key']??PSTE_Normalizer::categoryFamilyKey((string)($c['target_category_name']??'')));if($key==='')continue;if(in_array((string)($c['planning_suitability']??'NO'),['YES','PROVISIONAL'],true))$planned[$key]=($planned[$key]??0)+1;$v=max(0,(int)($c['metrics']['search_volume']??0));$volumes[$key]=($volumes[$key]??0)+$v;}
        $gscFamily=[];foreach($gsc as $categoryId=>$row){$key=$categoryToFamily[(int)$categoryId]??'';if($key==='')continue;if(!isset($gscFamily[$key]))$gscFamily[$key]=['impressions'=>0.0,'clicks'=>0.0];$gscFamily[$key]['impressions']+=(float)($row['impressions']??0);$gscFamily[$key]['clicks']+=(float)($row['clicks']??0);}
        $totalImpressions=0.0;$totalVolume=0.0;foreach($families as $key=>$family){$totalImpressions+=(float)($gscFamily[$key]['impressions']??0);$totalVolume+=(float)($volumes[$key]??0);}
        $totalActual=max(1,array_sum($actual));$rows=[];
        foreach($families as $key=>$family){$imp=(float)($gscFamily[$key]['impressions']??0);$vol=(float)($volumes[$key]??0);$hasGsc=$totalImpressions>0&&$imp>0;$hasVolume=$totalVolume>0&&$vol>0;$gscShare=$totalImpressions>0?$imp/$totalImpressions:0.0;$volumeShare=$totalVolume>0?$vol/$totalVolume:0.0;
            if($hasGsc&&$hasVolume)$demandShare=($gscShare*0.60)+($volumeShare*0.40);elseif($hasGsc)$demandShare=$gscShare;elseif($hasVolume)$demandShare=$volumeShare;else $demandShare=0.0;
            $hasData=$hasGsc||$hasVolume;$actualShare=($actual[$key]??0)/$totalActual;$expected=$hasData?max(0.5,$demandShare*$totalActual):null;$coverage=$expected!==null?round((($actual[$key]??0)/$expected)*100,1):null;$state=self::coverageState($coverage);$representative=(int)($family['category_ids'][0]??0);
            $rows[]=['category_id'=>$representative,'category_ids'=>$family['category_ids'],'category_name'=>$family['topic_family_name'],'category_slug'=>$key,'topic_family_key'=>$key,'published'=>(int)($actual[$key]??0),'planned_pass'=>(int)($planned[$key]??0),'gsc_impressions'=>$imp,'gsc_clicks'=>(float)($gscFamily[$key]['clicks']??0),'candidate_volume'=>$vol,'demand_share_pct'=>round($demandShare*100,2),'content_share_pct'=>round($actualShare*100,2),'expected_articles'=>$expected!==null?round($expected,2):null,'coverage_pct'=>$coverage,'state'=>$state,'strategic_weight'=>self::strategicWeight($representative)];
        }
        usort($rows,static function($a,$b){$rank=['UNDERREPRESENTED'=>0,'DATA_INSUFFICIENT'=>1,'BALANCED'=>2,'OVERREPRESENTED'=>3];return [$rank[$a['state']]??9,$a['coverage_pct']??999,$a['category_name']]<=>[$rank[$b['state']]??9,$b['coverage_pct']??999,$b['category_name']];});return $rows;
    }

    public static function priorities(): array {
        $coverageBy=[];foreach(self::coverage() as $row)$coverageBy[(string)$row['topic_family_key']]=$row;$rows=[];
        foreach(self::adminCandidates() as $c){$planning=(string)($c['planning_suitability']??'NO');if(!in_array($planning,['YES','PROVISIONAL'],true))continue;$decision=(string)($c['pool_status']??$c['decision']??'REVIEW_REQUIRED');$categoryId=(int)($c['target_category_id']??0);$familyKey=(string)($c['topic_family_key']??PSTE_Normalizer::categoryFamilyKey((string)($c['target_category_name']??'')));$coverage=$coverageBy[$familyKey]??null;
            $gapScore=10.0;if($coverage&&$coverage['coverage_pct']!==null)$gapScore=min(30.0,max(0.0,(100.0-(float)$coverage['coverage_pct'])*0.3));
            $sources=[];foreach(($c['evidence']??[]) as $e){$s=(string)($e['source']??'');if($s!=='')$sources[$s]=true;}$demandScore=isset($sources['GSC'])?25.0:(isset($sources['PAA'])?22.0:(isset($sources['PAA_RELATED'])?15.0:8.0));
            $volume=max(0,(float)($c['metrics']['search_volume']??0));$volumeScore=$volume>0?min(15.0,(log10(1+$volume)/log10(1001))*15.0):0.0;
            $strategic=min(10.0,max(0.0,self::strategicWeight($categoryId)));
            $risk=$decision==='PASS'?10.0:3.0;$season=self::seasonalityScore($c['metrics']['monthly_searches']??[]);$readiness=self::readinessScore($c);
            $score=self::priorityScore(['coverage_gap'=>$gapScore,'real_demand'=>$demandScore,'search_volume_trend'=>$volumeScore,'strategic_category'=>$strategic,'low_cannibalization_risk'=>$risk,'seasonality'=>$season,'data_readiness'=>$readiness]);
            $rows[]=['candidate_id'=>(string)($c['candidate_id']??''),'topic'=>PSTE_Editorializer::displayTitle($c),'category_id'=>$categoryId,'category_name'=>(string)($c['target_category_name']??''),'topic_family_key'=>$familyKey,'article_type'=>(string)($c['proposed_article_type']??''),'decision'=>$decision,'planning_suitability'=>$planning,'priority_score'=>$score,'components'=>['coverage_gap'=>round($gapScore,1),'real_demand'=>round($demandScore,1),'search_volume_trend'=>round($volumeScore,1),'strategic_category'=>round($strategic,1),'low_cannibalization_risk'=>round($risk,1),'seasonality'=>round($season,1),'data_readiness'=>round($readiness,1)],'search_volume'=>$volume,'intent'=>(string)($c['metrics']['search_intent']??''),'sources'=>array_keys($sources)];
        }
        usort($rows,static fn($a,$b)=>[$b['priority_score'],$a['topic']]<=>[$a['priority_score'],$b['topic']]);return $rows;
    }

    public static function conflicts(): array {
        $out=[];foreach(self::adminCandidates() as $c){if(!empty($c['discovery_only']))continue;if(($c['decision']??'PASS')==='PASS')continue;$out[]=['topic'=>PSTE_Editorializer::displayTitle($c),'category_name'=>(string)($c['target_category_name']??''),'decision'=>(string)($c['decision']??''),'reason_codes'=>$c['reason_codes']??[],'matches'=>$c['closest_existing_matches']??[]];}return $out;
    }

    public static function summary(): array {
        $coverage=self::coverage();$counts=['UNDERREPRESENTED'=>0,'BALANCED'=>0,'OVERREPRESENTED'=>0,'DATA_INSUFFICIENT'=>0];foreach($coverage as $r)$counts[$r['state']]++;
        $topics=self::topicRows();$priorities=self::priorities();$conflicts=self::conflicts();$pool=PSTE_Repository::adminTopicPoolStats();$research=PSTE_Repository::researchCompleteness();return ['coverage_counts'=>$counts,'topic_count'=>count($topics),'priority_ready_count'=>count(array_filter($priorities,static fn($r)=>(string)($r['planning_suitability']??'')==='YES')),'conflict_count'=>count($conflicts),'top_priorities'=>array_slice($priorities,0,5),'pool_total'=>$pool['TOTAL']??0,'pool_review_required'=>$pool['REVIEW_REQUIRED']??0,'pool_occurrences'=>$pool['OCCURRENCES']??0,'pool_green'=>$pool['GREEN']??0,'pool_yellow'=>$pool['YELLOW']??0,'pool_red'=>$pool['RED']??0,'research'=>$research];
    }

    public static function saveStrategicWeights(array $input): void {
        $clean=[];foreach($input as $id=>$value){$id=(int)$id;if($id<=0)continue;$clean[$id]=min(10,max(0,(float)$value));}update_option(PSTE_OPTION_CATEGORY_WEIGHTS,$clean,false);
    }
    public static function strategicWeight(int $categoryId): float {$weights=get_option(PSTE_OPTION_CATEGORY_WEIGHTS,[]);return is_array($weights)&&isset($weights[$categoryId])?(float)$weights[$categoryId]:5.0;}



    public static function coverageState(?float $coverage): string {
        if($coverage===null)return 'DATA_INSUFFICIENT';
        $settings=PSTE_Plugin::settings();$under=(float)($settings['coverage_under_threshold']??70.0);$over=(float)($settings['coverage_over_threshold']??130.0);
        if($coverage<$under)return 'UNDERREPRESENTED';if($coverage>$over)return 'OVERREPRESENTED';return 'BALANCED';
    }

    public static function priorityScore(array $components): float {
        return round(min(100.0,max(0.0,array_sum(array_map('floatval',$components)))),1);
    }
    private static function seasonalityScore(array $monthly): float {if(count($monthly)<3)return 2.0;$values=[];foreach($monthly as $m){$v=(float)($m['search_volume']??0);if($v>=0)$values[]=$v;}if(count($values)<3)return 2.0;$latest=$values[0]??0;$avg=array_sum($values)/count($values);return $avg>0&&$latest>$avg*1.2?5.0:2.5;}
    private static function readinessScore(array $c): float {$score=0.0;if(!empty($c['metrics']['search_intent']))$score+=1.5;if(($c['metrics']['search_volume']??null)!==null)$score+=1.0;if(!empty($c['evidence']))$score+=1.0;return min(5.0,$score);}
    private static function articleTypeFromCategory(string $name): string {return PSTE_Normalizer::categoryArticleType($name);}
}
