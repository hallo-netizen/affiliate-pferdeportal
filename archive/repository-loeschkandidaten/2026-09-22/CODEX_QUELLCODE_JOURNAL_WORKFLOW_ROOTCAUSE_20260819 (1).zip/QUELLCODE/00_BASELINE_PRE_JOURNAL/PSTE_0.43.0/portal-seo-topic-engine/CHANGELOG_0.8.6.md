# 0.8.6-staging

## Eng begrenzte Korrektur

- Verbindliche Vorrangregel: Jeder echte Fragetitel wird als `FAQ` klassifiziert.
- Die Frageprüfung erfolgt vor Pflege-, Vergleichs-, Kosten-, Sicherheits- und Beratungssignalen.
- Nicht als Frage formulierte Suchphrasen behalten die bisherige deterministische Typzuordnung.
- Keine Änderung an Textproduktion, Artikeln, Kategorien, Design, HTML oder Produktionsverträgen.
- Keine Schema- oder Migrationsänderung.
