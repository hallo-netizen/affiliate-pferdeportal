# Portal SEO Themenengine 0.21.0

Gebündelte Recovery-Etappe nach realem 0.20.0-Upgradeblocker.

- Root Cause behoben: Der Rohkeyword-Invariant verglich fälschlich neu eingeführte, abgeleitete Mirror-Felder mit Legacy-Payloads, in denen diese Felder naturgemäß noch fehlten.
- Die harte Invarianz schützt jetzt ausschließlich die echten gespeicherten Rohquellen (`raw_user_question`, `primary_longtail_query`, `canonical_query`, `query_record`, `query_aliases`).
- Die abgeleiteten Mirror-Felder `raw_keyword_preserved` und `raw_keyword_sha256` werden nach dem Rebuild separat strikt gegen die unveränderte Rohquelle validiert.
- Abweichung einer echten Rohquelle, Keywordverlust, Aliasverlust, falscher Mirror oder Topic-Verlust bleiben fail-closed und rollen die Transaktion zurück.
- Keine Änderung an Textmaschine, Produktion, Posts, Taxonomien, HTML, CSS, Design oder Promptlogik.
- Stable Compiler Read Capability bleibt unverändert; Compiler 0.9.0 benötigt daher keine neue Version.
- Zusätzlich wurde die Transaktionsannahme systemweit hart abgesichert: Jeder PSTE-Transaktionspfad prüft vor dem ersten `START TRANSACTION`, dass alle PSTE-eigenen Tabellen auf einem transaktionalen Storage-Engine laufen. Nicht-transaktionaler Storage blockiert vor dem ersten Transaktionswrite statt einen nur scheinbaren Rollback zu riskieren.
