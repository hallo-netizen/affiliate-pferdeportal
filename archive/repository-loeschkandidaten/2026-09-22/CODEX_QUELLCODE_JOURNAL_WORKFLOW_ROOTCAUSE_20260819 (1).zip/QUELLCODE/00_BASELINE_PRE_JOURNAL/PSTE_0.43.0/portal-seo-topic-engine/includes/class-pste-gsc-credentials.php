<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_GSC_Credentials {
    public static function redirectUri(): string {
        return admin_url('admin-post.php?action=pste_gsc_oauth_callback');
    }

    public static function saveClient(string $clientIdInput, string $clientSecretInput): array {
        $current = self::client();
        $clientId = trim($clientIdInput) !== '' ? sanitize_text_field($clientIdInput) : $current['client_id'];
        $secret = trim($clientSecretInput) !== '' ? trim($clientSecretInput) : $current['client_secret'];
        if ($clientId === '' || $secret === '') { throw new RuntimeException('PSTE_GSC_CLIENT_CREDENTIALS_INCOMPLETE'); }
        if (strlen($clientId) > 512 || strlen($secret) > 2048) { throw new RuntimeException('PSTE_GSC_CLIENT_CREDENTIALS_LENGTH_INVALID'); }
        $changed = !hash_equals((string)$current['client_id'], $clientId) || !hash_equals((string)$current['client_secret'], $secret);
        if (trim($clientIdInput) !== '') { update_option(PSTE_OPTION_GSC_CLIENT_ID, $clientId, false); }
        if (trim($clientSecretInput) !== '') { update_option(PSTE_OPTION_GSC_CLIENT_SECRET, PSTE_Secret_Store::encrypt($secret), false); }
        if ($changed) {
            self::clearTokens();
            self::recordStatus('CONFIGURED_UNCONNECTED', null, null);
        }
        return self::status();
    }

    public static function client(): array {
        $id = trim((string)get_option(PSTE_OPTION_GSC_CLIENT_ID, ''));
        $stored = (string)get_option(PSTE_OPTION_GSC_CLIENT_SECRET, '');
        $secret = $stored !== '' ? PSTE_Secret_Store::decrypt($stored) : '';
        return ['client_id'=>$id, 'client_secret'=>$secret];
    }

    public static function configured(): bool {
        $c = self::client(); return $c['client_id'] !== '' && $c['client_secret'] !== '';
    }

    public static function saveTokenBundle(array $bundle): void {
        $allowed = [
            'access_token'=>(string)($bundle['access_token']??''),
            'refresh_token'=>(string)($bundle['refresh_token']??''),
            'expires_at'=>(int)($bundle['expires_at']??0),
            'scope'=>(string)($bundle['scope']??''),
            'token_type'=>(string)($bundle['token_type']??'Bearer'),
            'updated_at_utc'=>gmdate('c'),
        ];
        if ($allowed['access_token']==='' && $allowed['refresh_token']==='') { throw new RuntimeException('PSTE_GSC_TOKEN_BUNDLE_EMPTY'); }
        update_option(PSTE_OPTION_GSC_TOKEN_BUNDLE, PSTE_Secret_Store::encrypt(wp_json_encode($allowed, JSON_UNESCAPED_SLASHES)), false);
    }

    public static function tokenBundle(): array {
        $stored = (string)get_option(PSTE_OPTION_GSC_TOKEN_BUNDLE, '');
        if ($stored === '') { return []; }
        $decoded = json_decode(PSTE_Secret_Store::decrypt($stored), true);
        return is_array($decoded) ? $decoded : [];
    }

    public static function clearTokens(): void {
        delete_option(PSTE_OPTION_GSC_TOKEN_BUNDLE);
        delete_option(PSTE_OPTION_GSC_SITES_CACHE);
        delete_option(PSTE_OPTION_GSC_SELECTED_PROPERTY);
        delete_option(PSTE_OPTION_GSC_LAST_SYNC);
    }

    public static function disconnect(): void {
        self::clearTokens(); self::recordStatus(self::configured()?'CONFIGURED_UNCONNECTED':'NOT_CONFIGURED', null, null);
    }

    public static function recordStatus(string $status, ?string $errorCode, ?string $accountHint): void {
        $allowed=['NOT_CONFIGURED','CONFIGURED_UNCONNECTED','CONNECTED','ERROR'];
        if(!in_array($status,$allowed,true))$status='ERROR';
        $safeError=$errorCode===null?null:substr((string)preg_replace('/[^A-Z0-9_:\-]/','_',strtoupper($errorCode)),0,160);
        update_option(PSTE_OPTION_GSC_CONNECTION_STATUS,[
            'contract'=>'PSTE_GSC_CONNECTION_STATUS_V1','status'=>$status,'provider'=>'Google Search Console',
            'tested_at_utc'=>in_array($status,['CONNECTED','ERROR'],true)?gmdate('c'):null,'error_code'=>$safeError,
            'account_hint'=>$accountHint?self::mask($accountHint):null,'updated_at_utc'=>gmdate('c'),
        ],false);
    }

    public static function status(): array {
        if(!self::configured())return self::decorate(['status'=>'NOT_CONFIGURED','tested_at_utc'=>null,'error_code'=>null,'account_hint'=>null]);
        $stored=get_option(PSTE_OPTION_GSC_CONNECTION_STATUS,[]);
        if(!is_array($stored)||!in_array((string)($stored['status']??''),['CONFIGURED_UNCONNECTED','CONNECTED','ERROR'],true))$stored=['status'=>'CONFIGURED_UNCONNECTED','tested_at_utc'=>null,'error_code'=>null,'account_hint'=>null];
        return self::decorate($stored);
    }

    private static function decorate(array $status): array {
        $labels=['NOT_CONFIGURED'=>'NICHT EINGERICHTET','CONFIGURED_UNCONNECTED'=>'EINGERICHTET · NICHT VERBUNDEN','CONNECTED'=>'VERBUNDEN','ERROR'=>'VERBINDUNGSFEHLER'];
        $state=(string)($status['status']??'NOT_CONFIGURED');$status['label']=$labels[$state]??'UNBEKANNT';$status['configured']=self::configured();
        $status['masked_client_id']=self::mask((string)(self::client()['client_id']??''));$status['redirect_uri']=self::redirectUri();return $status;
    }

    public static function mask(string $value): string {
        $len=strlen($value);if($len===0)return '—';if($len<=8)return str_repeat('•',$len);return substr($value,0,4).str_repeat('•',min(10,$len-8)).substr($value,-4);
    }

    public static function scrub($value) {
        $client=self::client();$tokens=self::tokenBundle();$secrets=array_filter([$client['client_id'],$client['client_secret'],$tokens['access_token']??'',$tokens['refresh_token']??'']);
        $walk=function($item)use(&$walk,$secrets){if(is_array($item)){$out=[];foreach($item as $k=>$v){if(preg_match('/(?:client_secret|access_token|refresh_token|authorization|oauth_token)/i',(string)$k))continue;$out[$k]=$walk($v);}return $out;}if(is_string($item)){foreach($secrets as $secret){if($secret!==''&&str_contains($item,$secret))return '[REDACTED]';}}return $item;};
        return $walk($value);
    }
}
