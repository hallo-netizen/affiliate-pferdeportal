<?php
if (!defined('ABSPATH')) { return; }

/** Mechanical token equivalence for planning-title family checks; never changes article content. */
final class PSTE_Token_Equivalence {
    /** @return list<string> */
    public static function tokens(string $value): array {
        $out=[];
        foreach(PSTE_Normalizer::tokens($value) as $token){$stem=self::stem((string)$token);if($stem!=='')$out[$stem]=true;}
        return array_keys($out);
    }
    public static function contains(string $value,string $needle): bool {
        $wanted=self::tokens($needle);$actual=self::tokens($value);
        return $wanted!==[]&&count(array_intersect($wanted,$actual))===count($wanted);
    }
    public static function completePrefix(string $value,string $phrase): string {
        $value=trim($value);$phrase=trim($phrase);if($value===''||$phrase==='')return trim($phrase.' '.$value);
        if(self::contains($value,$phrase))return $value;
        $actual=array_fill_keys(self::tokens($value),true);$missing=[];
        foreach(preg_split('/\s+/u',$phrase)?:[] as $word){
            $stems=self::tokens((string)$word);$stem=(string)($stems[0]??'');
            if($stem!==''&&!isset($actual[$stem])){$missing[]=$word;$actual[$stem]=true;}
        }
        return trim(implode(' ',$missing).' '.$value);
    }
    private static function stem(string $token): string {
        $token=trim($token);if($token==='')return '';
        foreach(['ern','en','er','es','e','n','s'] as $suffix){
            if(strlen($token)>strlen($suffix)+4&&str_ends_with($token,$suffix))return substr($token,0,-strlen($suffix));
        }
        return $token;
    }
}
