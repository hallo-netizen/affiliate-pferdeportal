# Änderungsnachweis 0.7.0-staging

## Grundlage

- Unabhängige Konzeptprüfung: `PASS MIT AUFLAGEN`.
- Unabhängiger Code-Review zu 0.6.1-staging: `PASS MIT AUFLAGEN`.

## Behobene blockierende Punkte

1. Synchroner Vollabgleich ersetzt durch batchweisen Portalabgleich.
2. DataForSEO-Zugangsdaten werden verschlüsselt gespeichert und Altwerte migriert.
3. Harte fachliche Blocks benötigen Warnbestätigung und Begründung.
4. Technische Blocks sind nicht übersteuerbar.
5. Tages- und Monatsbudget gelten auch für Live-SERP-Einzelprüfungen.
6. Globale Themenidentität verwendet unveränderliche zufällige UUIDs.
7. Semantische Ähnlichkeit erzeugt nur nicht-destruktive Merge-Kandidaten.
8. Rolle, Planung, Zielkategorie, Artikeltyp, Priorität und Ampel sind getrennt.
9. Unvollständiger Portalabgleich arbeitet fail-closed.
10. Intent-Vokabular, Artikelarten und Produktions-Metafelder sind konfigurierbar.

## Bewusst abgelehnte Forderung

Eine pauschale Sammelbestätigung grüner Themen wurde nicht eingebaut. Grün erfordert bereits keine Handlung. Riskante Sammelaktionen für Merge, Verwerfen, harte Overrides, Redaktionsplan oder Produktion bleiben verboten.
