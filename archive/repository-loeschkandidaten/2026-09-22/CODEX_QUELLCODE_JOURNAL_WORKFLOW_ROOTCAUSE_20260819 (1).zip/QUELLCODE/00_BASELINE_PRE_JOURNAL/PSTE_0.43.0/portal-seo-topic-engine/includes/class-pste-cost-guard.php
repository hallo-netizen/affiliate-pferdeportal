<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Cost_Guard {
    private const RATES = [
        'labs_keyword_suggestions_live' => ['task' => 0.012, 'item' => 0.00012],
        'labs_related_keywords_live' => ['task' => 0.012, 'item' => 0.00012],
        'labs_keyword_ideas_live' => ['task' => 0.012, 'item' => 0.00012],
        // Conservative guard. Current public Live organic price is lower; this ceiling intentionally over-reserves.
        'serp_google_organic_live_10_guard' => ['task' => 0.010, 'item' => 0.0],
    ];

    public static function estimate(string $rateKey, int $tasks, int $items): float {
        if (!isset(self::RATES[$rateKey])) { throw new InvalidArgumentException('PSTE_COST_RATE_UNKNOWN'); }
        $r = self::RATES[$rateKey];
        return round(($r['task'] * max(0, $tasks)) + ($r['item'] * max(0, $items)), 6);
    }

    public static function estimateSandboxSerpReview(int $tasks): float { return self::estimate('serp_google_organic_live_10_guard',max(0,$tasks),0); }

    public static function estimateCategoryResearch(int $candidateLimit = 100): float {
        return round(
            self::estimate('labs_keyword_suggestions_live',1,$candidateLimit)
            + self::estimate('labs_related_keywords_live',1,$candidateLimit)
            + self::estimate('labs_keyword_ideas_live',1,$candidateLimit),
            6
        );
    }

    public static function assertWithin(float $estimated, float $runBudget, float $absoluteCeiling = 10.0): void {
        if ($runBudget <= 0 || $runBudget > $absoluteCeiling) { throw new RuntimeException('PSTE_BUDGET_CONFIGURATION_INVALID'); }
        if ($estimated > $runBudget || $estimated > $absoluteCeiling) { throw new RuntimeException('PSTE_BUDGET_LIMIT_EXCEEDED'); }
    }

    public static function rates(): array { return self::RATES; }
}
