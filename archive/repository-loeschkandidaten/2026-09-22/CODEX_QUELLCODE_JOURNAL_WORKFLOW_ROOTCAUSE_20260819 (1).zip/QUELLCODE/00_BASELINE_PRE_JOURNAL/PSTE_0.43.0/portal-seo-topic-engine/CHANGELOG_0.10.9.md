# 0.10.9-staging

- Korrigiert die belegte semantische Fehlklassifikation von Preis-Longtails wie `günstig`, `guenstig`, `billig` und `preiswert`.
- Beide unabhängigen Retriever ordnen solche Suchphrasen jetzt der vorhandenen Beitragsart `Kosten` zu, sofern diese in der Themenfamilie existiert.
- Die allgemeine Editorializer-Signalerkennung wurde konsistent nachgezogen.
- Keine Änderung an Beiträgen, Artikeltexten, HTML, Design, Textmaschine, Qualitätsregeln oder WordPress-Schreibpfaden.
- Longtails werden nicht verworfen; nicht von der unveränderten Textmaschine freigegebene Typen bleiben vor dem Handoff zurückgehalten.
- Ergänzt einen einmaligen, manuellen und protokollierten Reparaturlauf für bereits gespeicherte betroffene Preis-Longtails; Schreibscope ausschließlich eigene `pste_`-Tabellen.
- Preis-Longtails behalten ihre konkrete Sparabsicht im natürlichen Metatitel, statt zu einem allgemeinen Kostenüberblick verbreitert zu werden.
