# Changelog 0.8.9-staging

## Reparatur des realen Live-Fehlers

- Die Payload-Wiederherstellung vergleicht `topic_pool.occurrence_count` nicht mehr fälschlich mit der Anzahl der Zeilen in `topic_occurrences`.
- Maßgeblich ist jetzt die Summe der gespeicherten `topic_occurrences.occurrence_count`-Gewichte.
- Eine einzelne Fundstellenzeile mit `occurrence_count=2` rekonstruiert den Themenpayload exakt zweimal und ist damit ein gültiger Positivfall.
- Ungültige, fehlende oder widersprüchliche Gewichte blockieren fail-closed.
- Nach der Reparatur wird der gesamte Themenpool erneut aus der Datenbank gelesen; die Abschlussprüfung arbeitet nicht mehr mit dem lokalen PHP-Array.

## Zusätzlicher gefundener und behobener Persistenzfehler

- `upsertTopicOccurrence()` verwendete seit 0.8.7 eine nicht initialisierte Variable `$encodedPayload`.
- Der Fundstellenpayload wird jetzt vor dem Schreiben JSON-Roundtrip-validiert.
- Payload und Fundstellenzähler werden nach Insert/Update unabhängig aus der Datenbank zurückgelesen und hash-/zählgenau geprüft.

## Grenzen

- Keine neue Keyword- oder SERP-Abfrage.
- Keine Löschung oder Änderung von Beiträgen, Kategorien, URLs, Textmaschine, Production Center, Editorial Guard oder Design.
- Reparatur ausschließlich in den eigenen `pste_`-Tabellen und vollständig transaktional.
