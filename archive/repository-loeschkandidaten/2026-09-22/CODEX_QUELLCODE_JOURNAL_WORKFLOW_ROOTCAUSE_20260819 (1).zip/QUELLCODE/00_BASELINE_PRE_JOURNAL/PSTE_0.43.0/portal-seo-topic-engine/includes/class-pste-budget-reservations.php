<?php
if (!defined('ABSPATH')) { return; }

/** Atomic reservations for all paid PSTE workflows. */
final class PSTE_Budget_Reservations {
    public const CONTRACT='PSTE_BUDGET_RESERVATIONS_V1';
    public const VERSION='1.0.0';
    private const LOCK_TTL_SECONDS=60;

    public static function reserve(string $reservationId,float $amount,array $settings,string $kind,int $ttlSeconds=3600): void {
        $reservationId=trim($reservationId);$kind=trim($kind);
        if($reservationId===''||$kind===''||$amount<=0||$ttlSeconds<60)throw new RuntimeException('PSTE_BUDGET_RESERVATION_INPUT_INVALID');
        $token=self::acquireLock();
        try{
            $registry=self::load();$now=time();$registry=self::prune($registry,$now);
            $existing=$registry['reservations'][$reservationId]??null;
            if(is_array($existing)){
                if(abs((float)$existing['amount_usd']-$amount)>0.0000005||(string)$existing['kind']!==$kind)throw new RuntimeException('PSTE_BUDGET_RESERVATION_MISMATCH');
                $existing['expires_at_utc']=gmdate('c',$now+$ttlSeconds);$registry['reservations'][$reservationId]=$existing;self::save($registry);return;
            }
            $active=0.0;foreach((array)$registry['reservations'] as $entry)$active+=(float)($entry['amount_usd']??0.0);
            $day=PSTE_Repository::actualCostSince(gmdate('Y-m-d 00:00:00'));
            $month=PSTE_Repository::actualCostSince(gmdate('Y-m-01 00:00:00'));
            if($day+$active+$amount>(float)$settings['daily_budget_usd'])throw new RuntimeException('PSTE_DAILY_BUDGET_LIMIT_EXCEEDED');
            if($month+$active+$amount>(float)$settings['monthly_budget_usd'])throw new RuntimeException('PSTE_MONTHLY_BUDGET_LIMIT_EXCEEDED');
            $registry['reservations'][$reservationId]=[
                'reservation_id'=>$reservationId,'kind'=>$kind,'amount_usd'=>round($amount,6),
                'created_at_utc'=>gmdate('c',$now),'expires_at_utc'=>gmdate('c',$now+$ttlSeconds),
            ];
            ksort($registry['reservations'],SORT_STRING);self::save($registry);
        }finally{self::releaseLock($token);}
    }


    public static function consume(string $reservationId,float $committedAmount): void {
        $reservationId=trim($reservationId);
        if($reservationId===''||$committedAmount<0)throw new RuntimeException('PSTE_BUDGET_RESERVATION_CONSUME_INPUT_INVALID');
        if($committedAmount===0.0)return;
        $token=self::acquireLock();
        try{
            $registry=self::prune(self::load(),time());
            if(!isset($registry['reservations'][$reservationId]))throw new RuntimeException('PSTE_BUDGET_RESERVATION_MISSING');
            $remaining=round(max(0.0,(float)$registry['reservations'][$reservationId]['amount_usd']-$committedAmount),6);
            if($remaining<=0.0)unset($registry['reservations'][$reservationId]);
            else $registry['reservations'][$reservationId]['amount_usd']=$remaining;
            self::save($registry);
        }finally{self::releaseLock($token);}
    }

    public static function refresh(string $reservationId,int $ttlSeconds=3600): void {
        $reservationId=trim($reservationId);
        if($reservationId===''||$ttlSeconds<60)throw new RuntimeException('PSTE_BUDGET_RESERVATION_REFRESH_INPUT_INVALID');
        $token=self::acquireLock();
        try{
            $registry=self::prune(self::load(),time());
            if(!isset($registry['reservations'][$reservationId]))throw new RuntimeException('PSTE_BUDGET_RESERVATION_MISSING');
            $registry['reservations'][$reservationId]['expires_at_utc']=gmdate('c',time()+$ttlSeconds);self::save($registry);
        }finally{self::releaseLock($token);}
    }

    public static function release(string $reservationId): void {
        $reservationId=trim($reservationId);if($reservationId==='')return;
        $token=self::acquireLock();
        try{$registry=self::prune(self::load(),time());if(isset($registry['reservations'][$reservationId])){unset($registry['reservations'][$reservationId]);self::save($registry);}}
        finally{self::releaseLock($token);}
    }

    public static function activeTotal(): float {
        $token=self::acquireLock();
        try{$registry=self::prune(self::load(),time());self::save($registry);$total=0.0;foreach($registry['reservations'] as $entry)$total+=(float)$entry['amount_usd'];return round($total,6);}
        finally{self::releaseLock($token);}
    }

    /** @return array<string,mixed> */
    private static function load(): array {
        $value=get_option(PSTE_OPTION_BUDGET_RESERVATIONS,[]);
        if($value===[])return ['contract'=>self::CONTRACT,'version'=>self::VERSION,'reservations'=>[],'updated_at_utc'=>'','sha256'=>''];
        if(!is_array($value))throw new RuntimeException('PSTE_BUDGET_RESERVATION_STORAGE_INVALID');
        self::assertRegistry($value);return $value;
    }

    /** @return array<string,mixed> */
    private static function prune(array $registry,int $now): array {
        foreach((array)$registry['reservations'] as $id=>$entry){$expires=strtotime((string)($entry['expires_at_utc']??''));if($expires===false||$expires<$now)unset($registry['reservations'][$id]);}
        ksort($registry['reservations'],SORT_STRING);return $registry;
    }

    private static function save(array $registry): void {
        $registry['contract']=self::CONTRACT;$registry['version']=self::VERSION;$registry['updated_at_utc']=gmdate('c');unset($registry['sha256']);$registry['sha256']=self::hash($registry);
        update_option(PSTE_OPTION_BUDGET_RESERVATIONS,$registry,false);
        $stored=get_option(PSTE_OPTION_BUDGET_RESERVATIONS,[]);
        if(!is_array($stored)||!hash_equals((string)$registry['sha256'],(string)($stored['sha256']??'')))throw new RuntimeException('PSTE_BUDGET_RESERVATION_READBACK_MISMATCH');
        self::assertRegistry($stored);
    }

    private static function assertRegistry(array $registry): void {
        if(($registry['contract']??'')!==self::CONTRACT||($registry['version']??'')!==self::VERSION)throw new RuntimeException('PSTE_BUDGET_RESERVATION_CONTRACT_INVALID');
        $declared=strtolower(trim((string)($registry['sha256']??'')));$copy=$registry;unset($copy['sha256']);
        if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(self::hash($copy),$declared))throw new RuntimeException('PSTE_BUDGET_RESERVATION_HASH_MISMATCH');
        foreach((array)($registry['reservations']??[]) as $id=>$entry){if(!is_array($entry)||!hash_equals((string)$id,(string)($entry['reservation_id']??''))||(float)($entry['amount_usd']??0)<=0)throw new RuntimeException('PSTE_BUDGET_RESERVATION_ENTRY_INVALID');}
    }

    private static function hash($value): string {
        if(class_exists('PSTE_Normalizer')&&method_exists('PSTE_Normalizer','stableJson'))return hash('sha256',PSTE_Normalizer::stableJson($value));
        return hash('sha256',self::canonicalJson($value));
    }
    private static function canonicalJson($value): string {$json=wp_json_encode(self::canonicalize($value),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($json))throw new RuntimeException('PSTE_BUDGET_RESERVATION_JSON_ENCODE_FAILED');return $json;}
    private static function canonicalize($value){if(!is_array($value))return $value;if($value===[])return [];$list=array_keys($value)===range(0,count($value)-1);if($list)return array_map([self::class,'canonicalize'],$value);ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=self::canonicalize($v);return $value;}

    private static function acquireLock(): string {
        $token=hash('sha256',microtime(true).'|'.(function_exists('wp_generate_uuid4')?wp_generate_uuid4():uniqid('',true)));
        $payload=['token'=>$token,'expires_at'=>time()+self::LOCK_TTL_SECONDS];
        if(add_option(PSTE_OPTION_BUDGET_LOCK,$payload,'',false))return $token;
        $existing=get_option(PSTE_OPTION_BUDGET_LOCK,[]);
        if(is_array($existing)&&(int)($existing['expires_at']??0)<time()){
            self::deleteLockIfUnchanged($existing);if(add_option(PSTE_OPTION_BUDGET_LOCK,$payload,'',false))return $token;
        }
        throw new RuntimeException('PSTE_BUDGET_RESERVATION_LOCKED');
    }
    private static function releaseLock(string $token): void {$existing=get_option(PSTE_OPTION_BUDGET_LOCK,[]);if(is_array($existing)&&hash_equals($token,(string)($existing['token']??'')))delete_option(PSTE_OPTION_BUDGET_LOCK);}
    private static function deleteLockIfUnchanged(array $existing): void {
        global $wpdb;
        if(isset($wpdb)&&isset($wpdb->options)&&method_exists($wpdb,'query')&&method_exists($wpdb,'prepare')&&function_exists('maybe_serialize')){PSTE_DB_Write_Guard::query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",PSTE_OPTION_BUDGET_LOCK,maybe_serialize($existing)),'PSTE_BUDGET_STALE_LOCK_DELETE_FAILED');if(function_exists('wp_cache_delete'))wp_cache_delete(PSTE_OPTION_BUDGET_LOCK,'options');return;}
        if(get_option(PSTE_OPTION_BUDGET_LOCK,[])===$existing)delete_option(PSTE_OPTION_BUDGET_LOCK);
    }
}
