# 0.19.0

Gebündelte End-to-End-Reparatur: gemeinsamer Relevanz-/Semantik-/Titelpfad für Recherche, Metadaten-Rebuild und Sandbox-Reentry; vollständige Rohkeyword-Erhaltung; direkte Sandbox-Aufnahme statt Dry-run-Abhängigkeit; Strukturlücken ohne erfundene Beitragsart; dauerhafte Wartungs-/Backlog-Gesundheit; stabile read-only Compiler-Fähigkeitsschnittstelle. Keine Artikel-, Taxonomie-, Textmaschinen-, HTML-, CSS- oder Designänderungen.
