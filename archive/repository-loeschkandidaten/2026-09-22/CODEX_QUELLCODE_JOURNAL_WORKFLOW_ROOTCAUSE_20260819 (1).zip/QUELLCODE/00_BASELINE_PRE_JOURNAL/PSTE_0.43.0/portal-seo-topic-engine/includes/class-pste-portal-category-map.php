<?php
if (!defined('ABSPATH')) { return; }

/**
 * Immutable, read-only mapping derived from the validated portal export.
 * It is a protection and recovery source, never a taxonomy writer.
 */
final class PSTE_Portal_Category_Map {
    /** @var array<string,mixed>|null */
    private static ?array $cache=null;

    /** @return array<string,mixed> */
    public static function load(): array {
        if(is_array(self::$cache))return self::$cache;
        $path=defined('PSTE_DIR')?PSTE_DIR.'fixtures/portal-category-map-v1.json':'';
        if($path===''||!is_file($path))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_MISSING',['path'=>'fixtures/portal-category-map-v1.json']);
        try{$raw=(string)file_get_contents($path);$data=json_decode($raw,true,512,JSON_THROW_ON_ERROR);}catch(Throwable $e){throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_JSON_INVALID');}
        if(!is_array($data)||($data['contract']??'')!=='PSTE_PORTAL_CATEGORY_MAP_V1')throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_CONTRACT_INVALID');
        $declared=(string)($data['map_sha256']??'');$copy=$data;unset($copy['map_sha256']);$actual=hash('sha256',self::json(self::canonicalize($copy)));
        if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals($declared,$actual))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_HASH_MISMATCH',['expected_sha256'=>$declared,'actual_sha256'=>$actual]);
        $entries=array_values(array_filter((array)($data['entries']??[]),'is_array'));
        if(!$entries||(int)($data['source_category_count']??0)!==count($entries))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_COUNT_INVALID',['declared_count'=>(int)($data['source_category_count']??0),'actual_count'=>count($entries)]);
        $bySlug=[];$byIdentity=[];$byName=[];$aliasCount=0;
        foreach($entries as $entry){
            $slug=trim((string)($entry['category_slug']??''));$name=trim((string)($entry['category_name']??''));$type=trim((string)($entry['article_type']??''));$family=trim((string)($entry['product_page_name']??''));$productSlug=trim((string)($entry['product_page_slug']??''));
            if($slug===''||$name===''||$type===''||$family===''||$productSlug==='')throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_ENTRY_INVALID',['category_slug'=>$slug,'category_name'=>$name]);
            if(isset($bySlug[$slug]))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_DUPLICATE_SLUG',['category_slug'=>$slug]);
            $accepted=[];foreach((array)($entry['accepted_category_names']??[]) as $alias){
                $alias=trim((string)$alias);if($alias==='')throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_ALIAS_INVALID',['category_slug'=>$slug]);
                $aliasType=PSTE_Normalizer::categoryArticleType($alias);if($aliasType===''||self::norm($aliasType)!==self::norm($type))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_ALIAS_TYPE_MISMATCH',['category_slug'=>$slug,'category_name'=>$alias,'article_type'=>$aliasType,'expected_article_type'=>$type]);
                $key=self::norm($alias);if(isset($accepted[$key]))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_ALIAS_DUPLICATE',['category_slug'=>$slug,'category_name'=>$alias]);$accepted[$key]=$alias;
            }
            if(isset($accepted[self::norm($name)]))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_ALIAS_DUPLICATES_CANONICAL_NAME',['category_slug'=>$slug,'category_name'=>$name]);
            $entry['accepted_category_names']=array_values($accepted);$aliasCount+=count($entry['accepted_category_names']);
            $bySlug[$slug]=$entry;$identity=self::identity($name,$type,$family);$byIdentity[$identity][]=$entry;$byName[self::norm($name)][]=$entry;
            foreach($entry['accepted_category_names'] as $alias)$byName[self::norm((string)$alias)][]=$entry;
        }
        $declaredAliasCount=(int)($data['source_repair_changed_term_count']??$aliasCount);if($declaredAliasCount!==$aliasCount)throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_ALIAS_COUNT_INVALID',['declared_count'=>$declaredAliasCount,'actual_count'=>$aliasCount]);
        $repairSha=(string)($data['source_repair_report_sha256']??'');if($repairSha!==''&&!preg_match('/^[a-f0-9]{64}$/',$repairSha))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_REPAIR_HASH_INVALID');
        self::$cache=['contract'=>$data['contract'],'version'=>$data['version']??'','map_sha256'=>$declared,'source_export_sha256'=>(string)($data['source_export_sha256']??''),'source_repair_report_sha256'=>$repairSha,'accepted_name_alias_count'=>$aliasCount,'entry_count'=>count($entries),'entries'=>$entries,'by_slug'=>$bySlug,'by_identity'=>$byIdentity,'by_name'=>$byName];
        return self::$cache;
    }

    /** @return array<string,mixed>|null */
    public static function match(object $term): ?array {
        $map=self::load();$slug=trim((string)($term->slug??''));$name=trim((string)($term->name??''));
        if($slug!==''&&isset($map['by_slug'][$slug])){
            $entry=(array)$map['by_slug'][$slug];$nameKey=self::norm($name);
            if($nameKey===self::norm((string)$entry['category_name']))return $entry+['match_mode'=>'PROTECTED_EXACT_SLUG_AND_NAME'];
            foreach((array)($entry['accepted_category_names']??[]) as $alias){if($nameKey===self::norm((string)$alias))return $entry+['match_mode'=>'PROTECTED_EXACT_SLUG_AND_ACCEPTED_NAME'];}
            $type=PSTE_Normalizer::categoryArticleType($name);$family=PSTE_Normalizer::categoryFamilyName($name);
            if($type!==''&&self::identity($name,$type,$family)===self::identity((string)$entry['category_name'],(string)$entry['article_type'],(string)$entry['product_page_name']))return $entry+['match_mode'=>'PROTECTED_EXACT_SLUG_SEMANTIC_NAME'];
        }
        $candidates=(array)($map['by_name'][self::norm($name)]??[]);
        if(count($candidates)===1)return (array)$candidates[0]+['match_mode'=>'PROTECTED_UNIQUE_NAME_SLUG_DRIFT'];
        if(count($candidates)>1){
            $ranked=[];foreach($candidates as $entry){$score=self::slugAffinity($slug,(string)($entry['category_slug']??''),(string)($entry['product_page_slug']??''),(string)($entry['article_type']??''));$ranked[]=['score'=>$score,'entry'=>$entry];}
            usort($ranked,static fn($a,$b)=>(int)$b['score']<=>(int)$a['score']);
            if(($ranked[0]['score']??0)>=70&&($ranked[0]['score']??0)>($ranked[1]['score']??0))return (array)$ranked[0]['entry']+['match_mode'=>'PROTECTED_NAME_WITH_UNIQUE_SLUG_AFFINITY'];
        }
        return null;
    }


    /** @return array<string,mixed>|null */
    public static function exactSlugEntry(string $slug): ?array {
        $map=self::load();$slug=trim($slug);return $slug!==''&&isset($map['by_slug'][$slug])?(array)$map['by_slug'][$slug]:null;
    }
    public static function isProtectedSlug(string $slug): bool {$map=self::load();return isset($map['by_slug'][$slug]);}
    public static function mapSha256(): string {return (string)self::load()['map_sha256'];}
    public static function protectedCount(): int {return (int)self::load()['entry_count'];}

    private static function identity(string $name,string $type,string $family): string {return self::norm($name).'|'.self::norm($type).'|'.self::norm($family);}
    private static function slugAffinity(string $actual,string $expected,string $product,string $type): int {
        if($actual===$expected)return 100;
        $typeSlug=self::slugify($type);
        if($actual===$product.'-'.$typeSlug||$actual===$typeSlug.'-'.$product)return 95;
        $a=self::tokens($actual);$e=self::tokens($expected);$p=self::tokens($product);$intersection=count(array_intersect($a,$e));$union=count(array_unique(array_merge($a,$e)));$j=$union>0?$intersection/$union:0;
        $productCoverage=$p?count(array_intersect($a,$p))/count($p):0;
        return (int)round(max($j,$productCoverage)*80);
    }
    /** @return list<string> */ private static function tokens(string $v): array {$v=self::slugify($v);return $v===''?[]:array_values(array_filter(explode('-',$v)));}
    private static function norm(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');$v=strtr(trim($v),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$v=function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);return trim((string)preg_replace('/[^a-z0-9]+/u',' ',$v));}
    private static function slugify(string $v): string {if(function_exists('sanitize_title'))return (string)sanitize_title($v);$v=strtr(trim($v),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$v=strtolower($v);return trim((string)preg_replace('/[^a-z0-9]+/','-',$v),'-');}
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
    private static function json($v): string {$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($j))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_CATEGORY_MAP_JSON_ENCODE_FAILED');return $j;}
}
