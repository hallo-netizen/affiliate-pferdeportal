<?php
if (!defined('ABSPATH')) { return; }

/** Deterministic review state for every candidate; blocked candidates never disappear silently. */
final class PSTE_Work_Queue {
    /** @return array<string,mixed> */
    public static function state(array $candidate,string $runUuid): array {
        $reasons=array_values(array_unique(array_filter(array_map('strval',(array)($candidate['reason_codes']??[])))));$decision=(string)($candidate['decision']??'BLOCKED');
        $state='READY_FOR_REVIEW';$code=$reasons[0]??'HUMAN_REVIEW_REQUIRED';$priority=50;
        if($decision==='PASS'){$state='READY_FOR_REVIEW';$code='CANDIDATE_PASSED_AUTOMATIC_GATES';$priority=20;}
        if(!empty($candidate['category_gap_proposal'])){$state='HELD_MISSING_TAXONOMY';$code='CATEGORY_GAP_REQUIRES_HUMAN_DECISION';$priority=70;}
        elseif(self::has($reasons,['PSTE_SEMANTIC_TYPE_CONSENSUS_MISSING','PSTE_SEMANTIC_CATEGORY_CONSENSUS_MISSING','PSTE_SEMANTIC_FAMILY_CONSENSUS_MISSING','A_RETRIEVER_AMBIGUOUS_REVIEW','B_RETRIEVER_AMBIGUOUS_REVIEW'])){$state='HELD_RETRIEVER_GAP';$code='SEMANTIC_RETRIEVER_REVIEW_REQUIRED';$priority=65;}
        elseif(self::has($reasons,['TYPE_EVIDENCE_CONFLICT_REVIEW'])){$state='HELD_TYPE_EVIDENCE_CONFLICT';$code='TYPE_EVIDENCE_CONFLICT_REVIEW';$priority=68;}
        elseif(self::containsPrefix($reasons,'RISK_')||self::has($reasons,['DOMAIN_RISK_BLOCKED','SELF_TREATMENT_INSTRUCTION','MEDICATION_OR_DOSAGE_REVIEW','ACUTE_EMERGENCY_REVIEW'])){$state='HELD_RISK_REVIEW';$code='DOMAIN_RISK_REVIEW_REQUIRED';$priority=80;}
        elseif(self::has($reasons,['PRE_TITLE_EXACT_DUPLICATE','PRE_TITLE_ANSWER_EQUIVALENT','DUPLICATE_WITHIN_RESEARCH_RUN','ANSWER_EQUIVALENT_EXISTING','ANSWER_EQUIVALENT_PLANNED','EXACT_NORMALIZED_QUERY_DUPLICATE','SAME_INTENT_CLUSTER'])){$state='REJECTED';$code='DUPLICATE_OR_CANNIBALIZATION';$priority=90;}
        elseif(($candidate['freshness']['status']??'CURRENT')!=='CURRENT'){$state='STALE_REVALIDATION_REQUIRED';$code='DEPENDENT_EVIDENCE_STALE';$priority=75;}
        elseif($decision!=='PASS'&&self::containsPrefix($reasons,'TITLE_')){$state='READY_FOR_REVIEW';$code='TITLE_LANGUAGE_REVIEW_REQUIRED';$priority=55;}
        $dependency=['candidate_id'=>(string)($candidate['candidate_id']??''),'semantic'=>(array)($candidate['semantic_consensus']??[]),'title'=>(string)($candidate['editorial_title']??''),'risk'=>(array)($candidate['domain_risk']??[]),'freshness'=>(array)($candidate['freshness']??[]),'registry'=>(string)($candidate['article_type_registry_sha256']??''),'reasons'=>$reasons];
        return ['contract'=>'PSTE_DETERMINISTIC_REVIEW_WORK_QUEUE_V1','state'=>$state,'reason_code'=>$code,'reason_codes'=>$reasons,'priority'=>$priority,'run_uuid'=>$runUuid,
            'dependency_sha256'=>hash('sha256',self::json($dependency)),'attempt'=>0,'correction_round'=>0,'max_correction_rounds'=>2,'created_at_utc'=>gmdate('c'),'write_target'=>'SEO_ENGINE_ISOLATED_DATA_ONLY'];
    }
    /** @param list<array<string,mixed>> $candidates */ public static function attachAll(array &$candidates,string $runUuid): void {foreach($candidates as &$c)$c['work_queue']=self::state($c,$runUuid);unset($c);usort($candidates,static fn($a,$b)=>[(int)($a['work_queue']['priority']??999),(string)($a['candidate_id']??'')]<=>[(int)($b['work_queue']['priority']??999),(string)($b['candidate_id']??'')]);}
    private static function has(array $reasons,array $needles): bool {return (bool)array_intersect($reasons,$needles);}
    private static function containsPrefix(array $reasons,string $prefix): bool {foreach($reasons as $r)if(str_starts_with($r,$prefix))return true;return false;}
    private static function json($v): string {$j=function_exists('wp_json_encode')?wp_json_encode(self::sort($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode(self::sort($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($j)?$j:'';}
    private static function sort($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'sort'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::sort($x);return $v;}
}
