# 0.27.0 – Intent-first title compatibility

- SEO intent is established before article-type acceptance, title composition and plan-slot selection.
- The independent semantic classifier must confirm the pre-established intent/type route.
- Decisive qualifiers remain the semantic focus and cannot be diluted by generic family-only secondary branches.
- One SEO seed may expose multiple research branches only when distinct SEO evidence exists; secondary branches never auto-fan-out and never create a five-field handoff directly.
- Natural title composition no longer uses the repeated `wichtige Auswahlkriterien` template.
- Portal title surface: no special characters except the terminal FAQ question mark; question marks are exclusive to FAQ.
- Style quality such as natural phrasing, keyword-staccato avoidance and phrase diversity is handled upstream as generation/retry policy, not as a new text-machine content rule.
- Intent metadata remains internal; the production handoff is still exactly `title`, `target_keyword`, `category`, `article_type`, `plan_slot`.
- Reentry, Sandbox rebuild, migration/recovery and fixture paths were aligned to the same intent-first dataflow so producer and consumers use the same evidence.
- Production/text machine remains unchanged and read-only.
- Read-only audit of Production Machine 6.7.9 confirmed an actual runtime rule in `content-validator.php`: a non-empty bound `target_keyword` must occur as a contiguous case-insensitive substring of the title. V82 therefore derives a natural, intent-bound production keyphrase separately from the immutable raw query and prevalidates the same rule upstream.
- `target_keyword` and its contract are threaded through normal path, persistence, recovery rebuild, Sandbox review proposals and compiler read capability without overwriting the raw discovery phrase.
- The compiler read capability is bumped to 1.3.0 / metadata schema V4 so producer and consumer explicitly agree on the target-keyword contract.
- Title composition remains natural while guaranteeing the exact Production Machine target-keyword binding. No Production Machine file is changed.

