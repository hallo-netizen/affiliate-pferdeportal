# Portal SEO Themenengine 0.8.0-staging

## Sicherer Start statt kritischem WordPress-Fehler

- Aktivierung und Schema-Migration fangen jeden `Throwable` intern ab.
- Ein Fehler setzt den Pluginstatus auf `BLOCKED`, lässt WordPress und das Backend aber erreichbar.
- Das Admin-Menü wird vor jeder Migrationsarbeit registriert.
- Bei blockierter Migration rendert ausschließlich eine sichere Diagnoseseite; Themenpool, Snapshots und externe APIs werden nicht abgefragt.
- Blockierte Migrationen werden nicht bei jedem Backendaufruf automatisch wiederholt.
- Ein manueller Wiederholungsversuch ist ausschließlich über `Sichere Migration erneut prüfen` möglich.
- Aktivierung startet keinen Portalabgleich und scannt nicht synchron den gesamten WordPress-Bestand.
- Die normale Adminausgabe fängt auch spätere operative Fehler ab und zeigt einen bereinigten Fehlercode, statt das Backend abstürzen zu lassen.
- `baselineStatus()` ist jetzt strikt read-only und verändert keine Themenzustände mehr.

## Unveränderte Schutzgrenzen

Keine Schreibzugriffe auf Beiträge, Kategorien, Terms, URLs, Yoast-Daten, Redaktionsplan oder Produktionssysteme. Kostenpflichtige Recherche bleibt bis zu einem bestätigten Runtime-PASS gesperrt.
