<?php
if (!defined('ABSPATH')) { return; }

/** Pure read-only resolver for topic families and exact existing leaf categories. */
final class PSTE_Category_Context {
    private const GENERIC_SITE_WORDS=['atelier','ateli','portal','magazin','journal','blog','online','website','webseit','ratgeb','wiss','welt','zentrum','zentral','markt','shop','deutschland'];

    /** @return array<string,mixed> */
    public static function selectedCategory(int $categoryId,array $baseline): array {
        $registry=PSTE_Article_Type_Registry::build($baseline);$input=null;
        foreach((array)($baseline['leaf_categories']??[]) as $leaf){if(is_array($leaf)&&(int)($leaf['term_id']??0)===$categoryId){if($input!==null)throw new RuntimeException('PSTE_TARGET_CATEGORY_AMBIGUOUS');$input=$leaf;}}
        if(!is_array($input))throw new RuntimeException('PSTE_TARGET_CATEGORY_NOT_IN_BASELINE');
        $family=trim((string)($input['topic_family_name']??PSTE_Normalizer::categoryFamilyName((string)($input['name']??''))));
        $familyKey=trim((string)($input['topic_family_key']??PSTE_Normalizer::categoryFamilyKey((string)($input['name']??''))));
        $group=$registry['families'][$familyKey]??null;if(!is_array($group))throw new RuntimeException('PSTE_TARGET_CATEGORY_FAMILY_MISSING');
        $leaves=array_values((array)$group['by_type']);usort($leaves,static fn($a,$b)=>[(int)$a['term_id'],(string)$a['name']]<=>[(int)$b['term_id'],(string)$b['name']]);
        $anchor=$leaves[0];$inputType=trim((string)($input['article_type']??PSTE_Normalizer::categoryArticleType((string)($input['name']??''))));
        return [
            'term_id'=>(int)$anchor['term_id'],'parent'=>(int)($anchor['parent']??0),'name'=>(string)$anchor['name'],'slug'=>(string)$anchor['slug'],
            'article_type'=>'','selected_input_article_type'=>$inputType,'available_article_types'=>PSTE_Article_Type_Registry::availableTypes($registry,$familyKey),
            'family_category_count'=>count($leaves),'topic_family_name'=>$family,'topic_family_key'=>$familyKey,'article_type_registry_sha256'=>(string)$registry['registry_sha256'],
        ];
    }

    /** @return list<array<string,mixed>> */
    public static function familyAnchors(array $baseline): array {
        $registry=PSTE_Article_Type_Registry::build($baseline);$out=[];
        foreach((array)$registry['families'] as $group){$leaves=array_values((array)$group['by_type']);usort($leaves,static fn($a,$b)=>(int)$a['term_id']<=>(int)$b['term_id']);$out[]=self::selectedCategory((int)$leaves[0]['term_id'],$baseline);}
        usort($out,static fn($a,$b)=>[(string)$a['topic_family_name'],(string)$a['topic_family_key']]<=>[(string)$b['topic_family_name'],(string)$b['topic_family_key']]);return $out;
    }

    /** @return array<string,mixed> */
    public static function researchContext(string $seed,array $selectedCategory,array $structureItems,string $siteName=''): array {
        $seed=self::clean($seed);if($seed==='')throw new RuntimeException('PSTE_RESEARCH_SEED_EMPTY');
        $path=self::fullPath((int)$selectedCategory['term_id'],$structureItems);$context=self::portalContextTerm($siteName,$path,(string)$selectedCategory['topic_family_name']);$effective=$seed;
        if($context!==''&&!self::containsNormalizedToken($seed,$context))$effective=trim($seed.' '.$context);
        return ['original_seed'=>$seed,'effective_seed'=>$effective,'portal_context_term'=>$context,'category_path'=>$path,'category_path_text'=>implode(' > ',array_column($path,'name')),'context_added'=>$effective!==$seed];
    }

    /** @return list<array<string,mixed>> */
    public static function fullPath(int $categoryId,array $structureItems): array {
        $byId=[];foreach($structureItems as $item)if(is_array($item)&&(int)($item['term_id']??0)>0)$byId[(int)$item['term_id']]=$item;
        if(isset($byId[$categoryId])&&is_array($byId[$categoryId]['portal_path_nodes']??null)){
            $path=[];foreach((array)$byId[$categoryId]['portal_path_nodes'] as $node){if(!is_array($node))continue;$path[]=['term_id'=>(int)($node['object_id']??0),'parent'=>(int)($node['parent_object_id']??0),'name'=>trim((string)($node['name']??'')),'slug'=>trim((string)($node['slug']??'')),'node_type'=>(string)($node['node_type']??'')];}
            if($path)return $path;
        }
        $path=[];$seen=[];$cursor=$categoryId;
        while($cursor>0){if(isset($seen[$cursor]))throw new RuntimeException('PSTE_CATEGORY_STRUCTURE_CYCLE');$seen[$cursor]=true;if(!isset($byId[$cursor]))break;$item=$byId[$cursor];array_unshift($path,['term_id'=>$cursor,'parent'=>(int)($item['parent']??0),'name'=>trim((string)($item['name']??'')),'slug'=>trim((string)($item['slug']??'')),'node_type'=>'wordpress_category']);$cursor=(int)($item['parent']??0);}
        if(!$path)throw new RuntimeException('PSTE_CATEGORY_PATH_UNRESOLVED');return $path;
    }

    /** Backward-compatible helper; productive code uses PSTE_Semantic_Classifier. */
    public static function inferArticleType(string $query,string $selectedType='',array $availableTypes=[]): string {
        if(PSTE_Normalizer::isQuestion($query))return in_array('FAQ',$availableTypes,true)?'FAQ':'';
        return count($availableTypes)===1?(string)$availableTypes[0]:'';
    }

    /** @return array<string,mixed> */
    public static function resolveTargetCategory(string $articleType,string $familyKey,array $baseline): array {return PSTE_Article_Type_Registry::resolve(PSTE_Article_Type_Registry::build($baseline),$familyKey,$articleType);}

    public static function isFamilyRelevant(string $query,string $family,string $effectiveSeed): bool {
        $synthetic=['topic_family_name'=>$family,'topic_family_key'=>hash('sha256','legacy-helper|'.$family),'by_type'=>['helper'=>['full_path'=>$family,'product_page_name'=>$family]]];
        $identity=PSTE_Family_Identity_V2::buildIdentity($synthetic,[]);$result=PSTE_Family_Identity_V2::evaluate($query,$identity);
        return (string)($result['status']??'NO_MATCH')==='MATCH';
    }

    /**
     * Read-only portal identity evidence for Sandbox routing.
     * Reuses the exact portalContextTerm()/containsNormalizedToken() logic that already
     * protects the normal research-context path; it does not change that path.
     * @return array<string,mixed>
     */
    public static function portalContextEvidence(string $query,array $baseline,string $siteName=''): array {
        $siteName=$siteName!==''?$siteName:(function_exists('get_bloginfo')?(string)get_bloginfo('name'):'');
        $terms=[];$siteTerm=self::portalContextTerm($siteName,[],'');if($siteTerm!=='')$terms[]=$siteTerm;
        if(!$terms){
            $roots=[];
            foreach((array)($baseline['leaf_categories']??[]) as $leaf){
                if(!is_array($leaf))continue;$nodes=(array)($leaf['portal_path_nodes']??[]);$name='';
                if(isset($nodes[0])&&is_array($nodes[0]))$name=trim((string)($nodes[0]['name']??''));
                elseif(!empty($leaf['portal_ancestor_page_names'][0]))$name=trim((string)$leaf['portal_ancestor_page_names'][0]);
                if($name!=='')$roots[$name]=true;
            }
            foreach(array_keys($roots) as $root){$term=self::portalContextTerm('',[['name'=>$root]],'');if($term!=='')$terms[]=$term;}
        }
        $terms=array_values(array_unique(array_filter(array_map('strval',$terms))));$matched=[];
        foreach($terms as $term)if(self::containsNormalizedToken($query,$term))$matched[]=$term;
        return [
            'contract'=>'PSTE_PORTAL_CONTEXT_EVIDENCE_V1','query'=>$query,'site_name'=>$siteName,
            'context_terms'=>$terms,'matched_terms'=>array_values(array_unique($matched)),
            'portal_context_present'=>!empty($matched),'write_attempted'=>false,
        ];
    }

    private static function portalContextTerm(string $siteName,array $path,string $family): string {
        $candidates=[];
        foreach(self::wordCandidates($siteName) as $row)if(!self::generic((string)$row['token']))$candidates[]=$row;
        if(!$candidates&&$path){foreach($path as $item){foreach(self::wordCandidates((string)($item['name']??'')) as $row)if(!self::generic((string)$row['token']))$candidates[]=$row;if($candidates)break;}}
        $familyTokens=PSTE_Family_Identity_V2::tokens($family,false);
        foreach($candidates as $row){$token=(string)$row['token'];$present=false;foreach($familyTokens as $ft)if($ft===$token||str_starts_with($ft,$token)||str_ends_with($ft,$token)){$present=true;break;}if(!$present)return (string)$row['raw'];}
        return '';
    }
    private static function containsNormalizedToken(string $haystack,string $needle): bool {$h=PSTE_Family_Identity_V2::tokens($haystack,false);foreach(PSTE_Family_Identity_V2::tokens($needle,false) as $n)foreach($h as $t)if($t===$n||str_starts_with($t,$n)||str_ends_with($t,$n))return true;return false;}
    /** @return list<array{raw:string,token:string}> */
    private static function wordCandidates(string $value): array {$raw=preg_split('/[^\p{L}\p{N}]+/u',self::clean($value))?:[];$out=[];foreach($raw as $word){$tokens=PSTE_Family_Identity_V2::tokens($word,false);if(count($tokens)!==1)continue;$out[]=['raw'=>$word,'token'=>(string)$tokens[0]];}return $out;}
    private static function generic(string $token): bool {return in_array($token,self::GENERIC_SITE_WORDS,true);}
    private static function clean(string $v): string {$v=trim(html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8'));return trim((string)preg_replace('/\s+/u',' ',$v));}
}
