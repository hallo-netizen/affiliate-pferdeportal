# 0.14.0 — Portal Context Router V3

## Ursache
Die bisherige Sandbox vermischte drei verschiedene Fragen: externe Portalrelevanz, vorhandene Familienstruktur und technische Familienzuordnung. Dadurch wurden auch eindeutig portalbezogene, aber intern noch nicht abgedeckte Longtails unnötig in die kostenpflichtige externe Relevanzprüfung geschickt.

## Gebündelte Korrektur
- Jeder `NEWLY_BLOCKED`-Longtail bleibt dauerhaft im Sandbox-Register erhalten.
- Vor kostenpflichtiger SEO-Prüfung wird ausschließlich schreibfrei der generische Portalbezug geprüft.
- Vorhandene nächste Familie -> `MATCHER_REVIEW`, keine externe SEO-Prüfung.
- Kein Familiennachbar, aber deterministischer Portalbezug -> `STRUCTURE_GAP`, keine externe SEO-Prüfung.
- Weder Portalbezug noch Familiennachbar -> `EXTERNAL_RELEVANCE_REVIEW`; nur dieser Pfad darf reale SEO-/SERP-Evidenz anfordern.
- Ausschluss-/Widerspruchsevidenz wird für jeden Datensatz gespeichert und bleibt Schutzsignal für interne Zuordnung.
- Policy-/Bindingwechsel archivieren bestehende Review-Evidenz statt sie zu löschen.
- Kein Sandboxpfad erzeugt einen Produktions-Handoff oder schreibt Posts, Postmeta, Terms oder Quelldaten.

## Hauptregel 1
Keine Änderung an Textmaschine, PPM, Compiler, Design, produktiver Titelpipeline, V2-Hauptmatcher, Normalizer oder bestehender Artikel-/Entwurfs-Ausgabe. Titel in der Sandbox sind ausschließlich schreibfreie Prüfwerte.
