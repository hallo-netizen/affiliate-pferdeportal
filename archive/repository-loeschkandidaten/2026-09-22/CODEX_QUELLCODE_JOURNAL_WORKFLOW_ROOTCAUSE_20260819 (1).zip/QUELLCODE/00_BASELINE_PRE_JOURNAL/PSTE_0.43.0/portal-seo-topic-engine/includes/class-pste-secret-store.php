<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Secret_Store {
    private const SODIUM_PREFIX = 'pste-sodium-v1:';
    private const OPENSSL_PREFIX = 'pste-openssl-v1:';

    public static function encrypt(string $plain): string {
        if ($plain === '') { return ''; }
        $key = self::key();
        if (function_exists('sodium_crypto_secretbox') && function_exists('random_bytes')) {
            $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $cipher = sodium_crypto_secretbox($plain, $nonce, $key);
            return self::SODIUM_PREFIX . base64_encode($nonce . $cipher);
        }
        if (function_exists('openssl_encrypt') && function_exists('random_bytes')) {
            $iv = random_bytes(12); $tag = '';
            $cipher = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
            if ($cipher === false || $tag === '') { throw new RuntimeException('PSTE_SECRET_ENCRYPTION_FAILED'); }
            return self::OPENSSL_PREFIX . base64_encode($iv . $tag . $cipher);
        }
        throw new RuntimeException('PSTE_SECURE_SECRET_STORAGE_UNAVAILABLE');
    }

    public static function decrypt(string $stored): string {
        if ($stored === '') { return ''; }
        $key = self::key();
        if (str_starts_with($stored, self::SODIUM_PREFIX)) {
            if (!function_exists('sodium_crypto_secretbox_open')) { throw new RuntimeException('PSTE_SECRET_DECRYPTION_UNAVAILABLE'); }
            $raw = base64_decode(substr($stored, strlen(self::SODIUM_PREFIX)), true);
            if (!is_string($raw) || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) { throw new RuntimeException('PSTE_SECRET_PAYLOAD_INVALID'); }
            $nonce = substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $cipher = substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $plain = sodium_crypto_secretbox_open($cipher, $nonce, $key);
            if ($plain === false) { throw new RuntimeException('PSTE_SECRET_DECRYPTION_FAILED'); }
            return $plain;
        }
        if (str_starts_with($stored, self::OPENSSL_PREFIX)) {
            if (!function_exists('openssl_decrypt')) { throw new RuntimeException('PSTE_SECRET_DECRYPTION_UNAVAILABLE'); }
            $raw = base64_decode(substr($stored, strlen(self::OPENSSL_PREFIX)), true);
            if (!is_string($raw) || strlen($raw) <= 28) { throw new RuntimeException('PSTE_SECRET_PAYLOAD_INVALID'); }
            $iv = substr($raw, 0, 12); $tag = substr($raw, 12, 16); $cipher = substr($raw, 28);
            $plain = openssl_decrypt($cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
            if ($plain === false) { throw new RuntimeException('PSTE_SECRET_DECRYPTION_FAILED'); }
            return $plain;
        }
        // Update migration: legacy values are readable but immediately re-encrypted on the next explicit save.
        return $stored;
    }

    private static function key(): string {
        $material = function_exists('wp_salt') ? wp_salt('auth') . '|' . wp_salt('secure_auth') : (defined('AUTH_KEY') ? AUTH_KEY : '') . '|' . (defined('SECURE_AUTH_KEY') ? SECURE_AUTH_KEY : '');
        if (trim($material, '|') === '') { throw new RuntimeException('PSTE_SECRET_KEY_MATERIAL_MISSING'); }
        return hash('sha256', 'PSTE_SECRET_STORE|' . $material, true);
    }
}
