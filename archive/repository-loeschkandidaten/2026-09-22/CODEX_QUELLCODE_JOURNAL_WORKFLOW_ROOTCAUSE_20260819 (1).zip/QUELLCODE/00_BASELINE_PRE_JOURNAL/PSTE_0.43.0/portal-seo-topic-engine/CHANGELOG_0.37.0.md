# 0.37.0 — Normal-path identity contract + full-workflow replay safety

- Fixes the real `PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_RAW_MISMATCH` failure observed during the 4-family breadth run.
- Establishes one canonical, non-semantic normal-path input normalization (HTML entity decoding, tag stripping, whitespace folding) and uses it for every normal-path identity comparison.
- Sandbox admission is now bound to the exact `normal_metadata_path.raw_query` identity while separately proving that the identity still belongs to the persisted source payload.
- A single malformed candidate is isolated; a self-inconsistent normal-path hash remains global fail-closed.
- Editorial final verification and Sandbox reentry now compare source input through the same canonical normal-path identity instead of raw source bytes.
- The historical 0.36 pause `PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_RAW_MISMATCH` is replay-safe only at local FINALIZE after all three provider steps; recovery never resends a provider request.
- STARTMASTER 0039, text machine, PSERC 0.21.0 and PPM 6.7.9 remain unchanged.

- Hardens every admin AJAX endpoint so the terminal JSON emitter is outside the business-logic catch scope; a terminating `wp_send_json_*` handler can no longer be re-caught and converted into a second JSON envelope.

- Hardens broad portal distribution across repeated waves: root selection is now based on each root's persisted processed-family count, so consecutive 1–4-family runs rotate toward underrepresented main branches instead of repeatedly starting with the same alphabetically first roots.
