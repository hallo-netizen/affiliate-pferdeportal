<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Repository {
    public static function table(string $name): string { global $wpdb; return $wpdb->prefix . 'pste_' . $name; }

    public static function createSchema(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE " . self::table('runs') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT, run_uuid char(36) NOT NULL, status varchar(64) NOT NULL,
            category_id bigint unsigned NOT NULL DEFAULT 0, seed varchar(255) NOT NULL DEFAULT '', estimated_cost decimal(10,6) NOT NULL DEFAULT 0,
            actual_cost decimal(10,6) NOT NULL DEFAULT 0, snapshot_json longtext NOT NULL, payload_json longtext NOT NULL,
            created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY (id), UNIQUE KEY run_uuid (run_uuid), KEY status (status)
        ) $charset;");
        dbDelta("CREATE TABLE " . self::table('candidates') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT, candidate_id char(64) NOT NULL, run_uuid char(36) NOT NULL,
            decision varchar(32) NOT NULL, reason_codes_json text NOT NULL, payload_json longtext NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY run_candidate (run_uuid,candidate_id), KEY candidate_id (candidate_id), KEY run_uuid (run_uuid), KEY decision (decision)
        ) $charset;");
        dbDelta("CREATE TABLE " . self::table('evidence') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT, evidence_id char(64) NOT NULL, run_uuid char(36) NOT NULL,
            source varchar(64) NOT NULL, source_reference varchar(255) NOT NULL DEFAULT '', response_sha256 char(64) NOT NULL,
            sanitized_payload_json longtext NOT NULL, captured_at datetime NOT NULL, PRIMARY KEY (id), UNIQUE KEY evidence_id (evidence_id), KEY run_uuid (run_uuid)
        ) $charset;");
        dbDelta("CREATE TABLE " . self::table('cost_ledger') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT, run_uuid char(36) NOT NULL, endpoint_key varchar(128) NOT NULL,
            estimated_cost decimal(10,6) NOT NULL DEFAULT 0, actual_cost decimal(10,6) NOT NULL DEFAULT 0,
            recorded_at datetime NOT NULL, PRIMARY KEY (id), KEY run_uuid (run_uuid), KEY recorded_at (recorded_at)
        ) $charset;");
        dbDelta("CREATE TABLE " . self::table('gsc_queries') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT, row_hash char(64) NOT NULL, property_url varchar(512) NOT NULL,
            query_text varchar(768) NOT NULL, page_url varchar(1024) NOT NULL, post_id bigint unsigned NOT NULL DEFAULT 0, category_id bigint unsigned NOT NULL DEFAULT 0,
            clicks decimal(18,4) NOT NULL DEFAULT 0, impressions decimal(18,4) NOT NULL DEFAULT 0, ctr decimal(12,8) NOT NULL DEFAULT 0, position decimal(12,4) NOT NULL DEFAULT 0,
            start_date date NOT NULL, end_date date NOT NULL, synced_at datetime NOT NULL, PRIMARY KEY (id), UNIQUE KEY row_hash (row_hash), KEY category_id (category_id), KEY post_id (post_id), KEY synced_at (synced_at)
        ) $charset;");
        dbDelta("CREATE TABLE " . self::table('topic_pool') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT, pool_key char(64) NOT NULL, normalized_key char(64) NOT NULL DEFAULT '', candidate_id char(64) NOT NULL,
            first_run_uuid char(36) NOT NULL, last_run_uuid char(36) NOT NULL, original_category_id bigint unsigned NOT NULL DEFAULT 0,
            current_category_id bigint unsigned NOT NULL DEFAULT 0, automatic_decision varchar(32) NOT NULL DEFAULT 'REVIEW_REQUIRED',
            automatic_pool_status varchar(32) NOT NULL DEFAULT 'REVIEW_REQUIRED', topic_role varchar(32) NOT NULL DEFAULT 'RESEARCH_KEYWORD', planning_suitability varchar(32) NOT NULL DEFAULT 'BLOCKED', context_state varchar(32) NOT NULL DEFAULT 'PENDING', structure_sha256 char(64) NOT NULL DEFAULT '', context_synced_at datetime NULL, manual_status varchar(32) NOT NULL DEFAULT '',
            manual_category_id bigint unsigned NOT NULL DEFAULT 0, manual_article_type varchar(32) NOT NULL DEFAULT '', manual_note text NOT NULL,
            payload_json longtext NOT NULL, occurrence_count bigint unsigned NOT NULL DEFAULT 1,
            first_seen_at datetime NOT NULL, last_seen_at datetime NOT NULL, reviewed_at datetime NULL, reviewed_by bigint unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY (id), UNIQUE KEY pool_key (pool_key), KEY normalized_key (normalized_key), KEY candidate_id (candidate_id), KEY automatic_pool_status (automatic_pool_status), KEY manual_status (manual_status), KEY current_category_id (current_category_id)
        ) $charset;");
        dbDelta("CREATE TABLE " . self::table('topic_history') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT, pool_key char(64) NOT NULL, action varchar(64) NOT NULL,
            from_status varchar(32) NOT NULL DEFAULT '', to_status varchar(32) NOT NULL DEFAULT '', details_json longtext NOT NULL,
            user_id bigint unsigned NOT NULL DEFAULT 0, created_at datetime NOT NULL,
            PRIMARY KEY (id), KEY pool_key (pool_key), KEY action (action), KEY created_at (created_at)
        ) $charset;");
        dbDelta("CREATE TABLE " . self::table('topic_occurrences') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT, occurrence_key char(64) NOT NULL, topic_key char(64) NOT NULL,
            run_uuid char(36) NOT NULL, candidate_id char(64) NOT NULL, found_category_id bigint unsigned NOT NULL DEFAULT 0,
            found_category_name varchar(255) NOT NULL DEFAULT '', found_article_type varchar(32) NOT NULL DEFAULT '',
            payload_json longtext NOT NULL, occurrence_count bigint unsigned NOT NULL DEFAULT 1,
            first_seen_at datetime NOT NULL, last_seen_at datetime NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY occurrence_key (occurrence_key), KEY topic_key (topic_key), KEY run_uuid (run_uuid), KEY found_category_id (found_category_id)
        ) $charset;");
        dbDelta("CREATE TABLE " . self::table('topic_assignments') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT, assignment_key char(64) NOT NULL, topic_key char(64) NOT NULL,
            category_id bigint unsigned NOT NULL DEFAULT 0, category_name varchar(255) NOT NULL DEFAULT '', article_type varchar(32) NOT NULL DEFAULT '',
            assignment_source varchar(64) NOT NULL, assignment_status varchar(32) NOT NULL DEFAULT 'SUGGESTED', confidence decimal(8,6) NOT NULL DEFAULT 0,
            reason_codes_json text NOT NULL, payload_json longtext NOT NULL, first_seen_at datetime NOT NULL, last_seen_at datetime NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY assignment_key (assignment_key), KEY topic_key (topic_key), KEY category_id (category_id), KEY assignment_status (assignment_status)
        ) $charset;");
        dbDelta("CREATE TABLE " . self::table('topic_identity') . " (
            normalized_key char(64) NOT NULL, topic_uuid char(36) NOT NULL, created_at datetime NOT NULL,
            PRIMARY KEY (normalized_key), UNIQUE KEY topic_uuid (topic_uuid)
        ) $charset;");
        dbDelta("CREATE TABLE " . self::table('topic_merge_candidates') . " (
            id bigint unsigned NOT NULL AUTO_INCREMENT, merge_key char(64) NOT NULL, source_topic_uuid char(36) NOT NULL, target_topic_uuid char(36) NOT NULL,
            similarity decimal(8,6) NOT NULL DEFAULT 0, match_type varchar(32) NOT NULL DEFAULT 'SEMANTIC', status varchar(32) NOT NULL DEFAULT 'SUGGESTED',
            reason_codes_json text NOT NULL, payload_json longtext NOT NULL, first_seen_at datetime NOT NULL, last_seen_at datetime NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY merge_key (merge_key), KEY source_topic_uuid (source_topic_uuid), KEY target_topic_uuid (target_topic_uuid), KEY status (status)
        ) $charset;");
    }


    public static function ensureTopicSchemaReady(): void {
        global $wpdb;
        $table=self::table('topic_pool');
        $required=[
            'normalized_key'=>"char(64) NOT NULL DEFAULT ''",
            'topic_role'=>"varchar(32) NOT NULL DEFAULT 'RESEARCH_KEYWORD'",
            'planning_suitability'=>"varchar(32) NOT NULL DEFAULT 'BLOCKED'",
            'context_state'=>"varchar(32) NOT NULL DEFAULT 'PENDING'",
            'structure_sha256'=>"char(64) NOT NULL DEFAULT ''",
            'context_synced_at'=>"datetime NULL",
        ];
        $columns=$wpdb->get_col("SHOW COLUMNS FROM $table",0)?:[];
        foreach($required as $name=>$definition){
            if(in_array($name,$columns,true))continue;
            self::checkedQuery("ALTER TABLE $table ADD COLUMN $name $definition",'PSTE_TOPIC_SCHEMA_COLUMN_FAILED_'.$name);
        }
        $columns=$wpdb->get_col("SHOW COLUMNS FROM $table",0)?:[];
        foreach(array_keys($required) as $name)if(!in_array($name,$columns,true))throw new RuntimeException('PSTE_TOPIC_SCHEMA_INCOMPLETE_'.$name);
    }

    public static function migrationBaseline(): array {
        return [
            'contract'=>'PSTE_MIGRATION_BASELINE_V1',
            'topic_pool'=>self::countRows('topic_pool'),
            'candidates'=>self::countRows('candidates'),
            'occurrences'=>self::countRows('topic_occurrences'),
            'assignments'=>self::countRows('topic_assignments'),
            'history'=>self::countRows('topic_history'),
            'identity'=>self::countRows('topic_identity'),
        ];
    }

    public static function assertMigrationPreserved(array $before,array $migration): array {
        $after=self::migrationBaseline();
        $mode=(string)($migration['mode']??'UNKNOWN');
        if($mode==='IN_PLACE_UUID_MIGRATION'){
            foreach(['topic_pool','candidates','assignments','history'] as $field){
                if((int)($before[$field]??-1)!==(int)($after[$field]??-2)){
                    throw new RuntimeException('PSTE_MIGRATION_COUNT_CHANGED_'.strtoupper($field).'_'.(int)($before[$field]??-1).'_'.(int)($after[$field]??-2));
                }
            }
            if((int)($after['occurrences']??0)<(int)($before['occurrences']??0))throw new RuntimeException('PSTE_MIGRATION_OCCURRENCE_COUNT_DECREASED');
            if((int)$after['identity']<(int)$after['topic_pool'])throw new RuntimeException('PSTE_MIGRATION_IDENTITY_COUNT_INCOMPLETE');
            self::assertTopicPoolUsesUuid();
        }elseif($mode==='EMPTY_NEW_INSTALL'){
            foreach(['topic_pool','candidates','occurrences','assignments','history'] as $field){
                if((int)($after[$field]??0)!==0)throw new RuntimeException('PSTE_EMPTY_INSTALL_UNEXPECTED_'.strtoupper($field));
            }
        }elseif($mode==='RECOVERED_FROM_CANDIDATES'){
            if((int)($before['candidates']??-1)!==(int)($after['candidates']??-2))throw new RuntimeException('PSTE_RECOVERY_CANDIDATE_COUNT_CHANGED');
            if((int)($after['topic_pool']??0)<=0)throw new RuntimeException('PSTE_RECOVERY_TOPIC_POOL_EMPTY');
            if((int)($after['occurrences']??0)<=0)throw new RuntimeException('PSTE_RECOVERY_OCCURRENCES_EMPTY');
            if((int)$after['identity']<(int)$after['topic_pool'])throw new RuntimeException('PSTE_RECOVERY_IDENTITY_COUNT_INCOMPLETE');
            self::assertTopicPoolUsesUuid();
        }else{
            throw new RuntimeException('PSTE_MIGRATION_MODE_UNKNOWN_'.$mode);
        }
        self::assertTopicRelationsConsistent();
        return $after;
    }

    private static function countRows(string $name): int {
        global $wpdb;
        $wpdb->last_error='';
        $value=$wpdb->get_var('SELECT COUNT(*) FROM '.self::table($name));
        if($value===null && (string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_MIGRATION_COUNT_READ_FAILED_'.$name.':'.self::dbError());
        return (int)$value;
    }

    private static function assertTopicPoolUsesUuid(): void {
        global $wpdb;
        $wpdb->last_error='';
        $rows=$wpdb->get_results('SELECT pool_key FROM '.self::table('topic_pool').' ORDER BY id ASC',ARRAY_A);
        if($rows===null && (string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_MIGRATION_UUID_READ_FAILED:'.self::dbError());
        foreach((array)$rows as $row){
            $key=(string)($row['pool_key']??'');
            if(!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',$key)){
                throw new RuntimeException('PSTE_MIGRATION_NON_UUID_TOPIC_KEY');
            }
        }
    }

    public static function migrateOrRepairTopicIdentity(): array {
        global $wpdb;
        $pool=self::table('topic_pool');$candidates=self::table('candidates');$occ=self::table('topic_occurrences');$assign=self::table('topic_assignments');
        $poolCount=(int)$wpdb->get_var("SELECT COUNT(*) FROM $pool");
        $candidateCount=(int)$wpdb->get_var("SELECT COUNT(*) FROM $candidates");
        $occurrenceCount=(int)$wpdb->get_var("SELECT COUNT(*) FROM $occ");
        if($poolCount===0&&$candidateCount>0){
            $historyRepaired=self::rebuildTopicPoolFromCandidatesTransactional();
            return ['recovered'=>true,'mode'=>'RECOVERED_FROM_CANDIDATES','pool_count'=>self::topicPoolCount(),'candidate_count'=>$candidateCount,'previous_occurrence_count'=>$occurrenceCount,'history_repaired'=>$historyRepaired];
        }
        if($poolCount===0&&$candidateCount===0){
            if($occurrenceCount>0)throw new RuntimeException('PSTE_ORPHAN_OCCURRENCES_WITHOUT_RECOVERY_SOURCE');
            return ['recovered'=>false,'mode'=>'EMPTY_NEW_INSTALL','pool_count'=>0,'candidate_count'=>0];
        }
        $repairs=self::migrateExistingPoolKeysInPlace();
        self::assertTopicRelationsConsistent();
        return [
            'recovered'=>false,
            'mode'=>'IN_PLACE_UUID_MIGRATION',
            'pool_count'=>self::topicPoolCount(),
            'candidate_count'=>$candidateCount,
            'payloads_repaired'=>(int)($repairs['payloads_repaired']??0),
            'payloads_quarantined'=>(int)($repairs['payloads_quarantined']??0),
            'occurrences_added'=>(int)($repairs['occurrences_added']??0),
            'history_repaired'=>(int)($repairs['history_repaired']??0),
        ];
    }


    /**
     * Initialize the legacy identity transition without processing an unbounded row set.
     * The returned mode is durable job evidence; all row work is executed by bounded batch methods below.
     * @return array<string,mixed>
     */
    public static function topicIdentityMigrationInitialize(string $jobUuid): array {
        $jobUuid=trim($jobUuid);if($jobUuid==='')throw new RuntimeException('PSTE_TOPIC_IDENTITY_JOB_UUID_REQUIRED');
        $baseline=self::migrationBaseline();$pool=(int)$baseline['topic_pool'];$candidates=(int)$baseline['candidates'];$occ=(int)$baseline['occurrences'];
        if($pool===0&&$candidates===0){if($occ>0)throw new RuntimeException('PSTE_ORPHAN_OCCURRENCES_WITHOUT_RECOVERY_SOURCE');$mode='EMPTY_NEW_INSTALL';$total=0;}
        elseif($pool===0){
            $mode='RECOVERED_FROM_CANDIDATES';$total=$candidates;
            // Clear only derived topic-domain tables exactly once. Candidate/raw evidence and history remain preserved.
            self::beginTransaction();
            try{foreach(['topic_pool','topic_occurrences','topic_assignments','topic_identity','topic_merge_candidates'] as $name)self::checkedQuery('DELETE FROM '.self::table($name),'PSTE_TOPIC_RECOVERY_CLEAR_FAILED_'.$name);self::commitTransaction();}
            catch(Throwable $e){self::rollbackTransaction();throw $e;}
        }else{$mode='IN_PLACE_UUID_MIGRATION';$total=$pool;}
        return ['contract'=>'PSTE_TOPIC_IDENTITY_MIGRATION_INIT_V1','job_uuid'=>$jobUuid,'mode'=>$mode,'work_total'=>$total,'baseline'=>$baseline,'candidate_count'=>$candidates,'previous_occurrence_count'=>$occ,'write_scope'=>'PSTE_OWN_TABLES_ONLY','article_or_taxonomy_write_attempted'=>false,'production_handoff_attempted'=>false];
    }

    /**
     * Migrate at most $limit existing topic rows to UUID identity. Payload recovery is candidate-local and bounded to
     * indexed evidence for the affected candidate; an unrecoverable row is quarantined instead of blocking peers.
     * @return array<string,mixed>
     */
    public static function topicIdentityMigrationInPlaceBatch(int $cursor,int $limit,string $jobUuid): array {
        $cursor=max(0,$cursor);$limit=max(1,min(25,$limit));$jobUuid=trim($jobUuid);if($jobUuid==='')throw new RuntimeException('PSTE_TOPIC_IDENTITY_JOB_UUID_REQUIRED');
        global $wpdb;$table=self::table('topic_pool');$total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");
        $rows=$wpdb->get_results("SELECT * FROM $table ORDER BY id ASC LIMIT ".(int)$limit." OFFSET ".(int)$cursor,ARRAY_A);if($rows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_TOPIC_IDENTITY_BATCH_READ_FAILED:'.self::dbError());
        $processed=0;$quarantined=0;$repaired=0;$occBefore=self::countRows('topic_occurrences');
        self::beginTransaction();
        try{
            foreach((array)$rows as $row){
                $payload=json_decode((string)($row['payload_json']??''),true);$isQuarantine=is_array($payload)&&json_last_error()===JSON_ERROR_NONE&&!empty($payload['recovery_quarantined']);
                $query=is_array($payload)?trim((string)(($payload['raw_user_question']??'')!==''?$payload['raw_user_question']:($payload['canonical_query']??$payload['primary_longtail_query']??''))):'';$storedNormalized=(string)($row['normalized_key']??'');
                $usable=$isQuarantine||(is_array($payload)&&json_last_error()===JSON_ERROR_NONE&&$query!=='');if($usable&&!$isQuarantine&&$storedNormalized!=='')$usable=hash_equals($storedNormalized,self::normalizedKeyForCandidate($payload));
                if(!$usable){$local=[0=>$row];$repair=self::repairOneTopicPayloadFromCandidateEvidence($local,0,$row);$row=$local[0];$payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload))throw new RuntimeException('PSTE_UUID_MIGRATION_PAYLOAD_INVALID');if(!empty($repair['quarantined']))$quarantined++;else $repaired++;}
                if(!is_array($payload))throw new RuntimeException('PSTE_UUID_MIGRATION_PAYLOAD_INVALID');
                $normalized=!empty($payload['recovery_quarantined'])?(string)($row['normalized_key']??$payload['recovery_normalized_key']??''):self::normalizedKeyForCandidate($payload);if(!preg_match('/^[a-f0-9]{64}$/',$normalized))throw new RuntimeException('PSTE_UUID_MIGRATION_NORMALIZED_KEY_INVALID');
                $oldKey=(string)$row['pool_key'];$uuid=(string)$wpdb->get_var($wpdb->prepare('SELECT topic_uuid FROM '.self::table('topic_identity').' WHERE normalized_key=%s',$normalized));
                if($uuid===''){$uuid=wp_generate_uuid4();self::checkedQuery($wpdb->prepare('INSERT INTO '.self::table('topic_identity').' (normalized_key,topic_uuid,created_at) VALUES (%s,%s,%s)',$normalized,$uuid,gmdate('Y-m-d H:i:s')),'PSTE_UUID_IDENTITY_INSERT_FAILED');}
                if($oldKey!==$uuid){$collision=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE pool_key=%s AND id<>%d",$uuid,(int)$row['id']));if($collision>0)throw new RuntimeException('PSTE_UUID_MIGRATION_COLLISION_REVIEW_REQUIRED');self::checkedUpdate($table,['pool_key'=>$uuid,'normalized_key'=>$normalized],['id'=>(int)$row['id']],['%s','%s'],['%d'],'PSTE_UUID_POOL_UPDATE_FAILED');self::checkedUpdate(self::table('topic_occurrences'),['topic_key'=>$uuid],['topic_key'=>$oldKey],['%s'],['%s'],'PSTE_UUID_OCCURRENCE_UPDATE_FAILED');self::checkedUpdate(self::table('topic_assignments'),['topic_key'=>$uuid],['topic_key'=>$oldKey],['%s'],['%s'],'PSTE_UUID_ASSIGNMENT_UPDATE_FAILED');self::checkedUpdate(self::table('topic_history'),['pool_key'=>$uuid],['pool_key'=>$oldKey],['%s'],['%s'],'PSTE_UUID_HISTORY_UPDATE_FAILED');}
                else self::checkedUpdate($table,['normalized_key'=>$normalized],['id'=>(int)$row['id']],['%s'],['%d'],'PSTE_UUID_NORMALIZED_UPDATE_FAILED');
                $processed++;
            }
            self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
        $next=$cursor+$processed;return ['contract'=>'PSTE_TOPIC_IDENTITY_MIGRATION_BATCH_V1','job_uuid'=>$jobUuid,'processed'=>$processed,'cursor'=>$next,'total'=>$total,'complete'=>$next>=$total,'payloads_repaired'=>$repaired,'payloads_quarantined'=>$quarantined,'occurrences_added'=>max(0,self::countRows('topic_occurrences')-$occBefore)];
    }

    /**
     * Rebuild a missing topic pool from at most $limit persisted candidate rows.
     * Candidate-local corruption is quarantined without mutating/deleting the candidate source row;
     * DB/storage/transaction failures remain global fail-closed.
     * @return array<string,mixed>
     */
    public static function topicIdentityRecoveryBatch(int $cursor,int $limit,string $jobUuid): array {
        $cursor=max(0,$cursor);$limit=max(1,min(25,$limit));$jobUuid=trim($jobUuid);if($jobUuid==='')throw new RuntimeException('PSTE_TOPIC_IDENTITY_JOB_UUID_REQUIRED');global $wpdb;$table=self::table('candidates');$total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");$rows=$wpdb->get_results("SELECT id,run_uuid,candidate_id,payload_json FROM $table ORDER BY id ASC LIMIT ".(int)$limit." OFFSET ".(int)$cursor,ARRAY_A);if($rows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_TOPIC_RECOVERY_SOURCE_READ_FAILED:'.self::dbError());$processed=0;$quarantined=0;
        self::beginTransaction();
        try{
            foreach((array)$rows as $row){
                $raw=(string)($row['payload_json']??'');$candidate=json_decode($raw,true);$run=trim((string)($row['run_uuid']??''));$candidateId=trim((string)($row['candidate_id']??''));$candidateError='';
                if(!is_array($candidate)||json_last_error()!==JSON_ERROR_NONE)$candidateError='PSTE_TOPIC_RECOVERY_PAYLOAD_INVALID';
                elseif($run===''||$candidateId===''||(string)($candidate['candidate_id']??'')!==$candidateId)$candidateError='PSTE_TOPIC_RECOVERY_CANDIDATE_IDENTITY_INVALID';
                else{try{self::normalizedKeyForCandidate($candidate);}catch(Throwable $e){$candidateError='PSTE_TOPIC_RECOVERY_CANDIDATE_NORMALIZATION_INVALID';}}
                if($candidateError!==''){self::quarantineCorruptedCandidateRecoveryRow($row,$candidateError);$processed++;$quarantined++;continue;}
                self::upsertTopicPool($run,$candidate);$processed++;
            }
            self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
        $next=$cursor+$processed;return ['contract'=>'PSTE_TOPIC_IDENTITY_RECOVERY_BATCH_V1','job_uuid'=>$jobUuid,'processed'=>$processed,'cursor'=>$next,'total'=>$total,'complete'=>$next>=$total,'candidate_rows_quarantined'=>$quarantined];
    }

    /**
     * Create or reuse a stable fail-closed topic for an unreadable legacy candidate row.
     * The original candidate row is deliberately untouched and therefore remains byte-for-byte evidence.
     */
    private static function quarantineCorruptedCandidateRecoveryRow(array $row,string $reasonCode): string {
        global $wpdb;$raw=(string)($row['payload_json']??'');$rowId=(int)($row['id']??0);$run=trim((string)($row['run_uuid']??''));$storedCandidate=trim((string)($row['candidate_id']??''));
        $candidateId=$storedCandidate!==''?$storedCandidate:hash('sha256','PSTE_RECOVERY_CANDIDATE_ID|'.$rowId.'|'.hash('sha256',$raw));
        $normalized=hash('sha256','PSTE_RECOVERY_CANDIDATE_QUARANTINE|'.$rowId.'|'.$run.'|'.$candidateId.'|'.hash('sha256',$raw));
        $identity=self::table('topic_identity');$topic=(string)$wpdb->get_var($wpdb->prepare("SELECT topic_uuid FROM $identity WHERE normalized_key=%s",$normalized));
        if($topic===''){
            $uuid=wp_generate_uuid4();self::checkedQuery($wpdb->prepare("INSERT IGNORE INTO $identity (normalized_key,topic_uuid,created_at) VALUES (%s,%s,%s)",$normalized,$uuid,gmdate('Y-m-d H:i:s')),'PSTE_RECOVERY_CANDIDATE_IDENTITY_INSERT_FAILED');
            $topic=(string)$wpdb->get_var($wpdb->prepare("SELECT topic_uuid FROM $identity WHERE normalized_key=%s",$normalized));if($topic==='')throw new RuntimeException('PSTE_RECOVERY_CANDIDATE_IDENTITY_NOT_PERSISTED');
        }
        $table=self::table('topic_pool');$existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE pool_key=%s",$topic),ARRAY_A);
        if(is_array($existing)){
            $p=json_decode((string)($existing['payload_json']??''),true);if(!is_array($p)||empty($p['recovery_quarantined'])||(string)($p['recovery_source']??'')!=='CANDIDATE_ROW')throw new RuntimeException('PSTE_RECOVERY_CANDIDATE_QUARANTINE_COLLISION');return $topic;
        }
        $now=gmdate('Y-m-d H:i:s');$quarantine=[
            'contract'=>'PSTE_TOPIC_PAYLOAD_RECOVERY_QUARANTINE_V1','recovery_quarantined'=>true,'recovery_source'=>'CANDIDATE_ROW','recovery_error_code'=>$reasonCode,'recovery_normalized_key'=>$normalized,'candidate_id'=>$candidateId,
            'canonical_query'=>'','primary_longtail_query'=>'','raw_user_question'=>'','decision'=>'BLOCKED','reason_codes'=>['PSTE_TOPIC_PAYLOAD_CORRUPTED',$reasonCode],'automatic_pool_status'=>'REVIEW_REQUIRED','topic_role'=>PSTE_Topic_Policy::ROLE_NON_EDITORIAL,'planning_suitability'=>'BLOCKED','context_state'=>'BLOCKED',
            'portal_context'=>['error_code'=>$reasonCode,'candidate_row_id'=>$rowId,'candidate_payload_sha256'=>hash('sha256',$raw),'candidate_payload_length'=>strlen($raw),'candidate_payload_b64'=>base64_encode($raw),'candidate_source_preserved_in_candidates'=>true,'write_scope'=>'PSTE_OWN_TABLE_ONLY'],
            'found_categories'=>[],'aliases'=>[],'evidence'=>[],'seen_in_runs'=>array_values(array_filter([$run])),'candidate_ids'=>[$candidateId],'textmachine_handoff_status'=>'BLOCKED_PAYLOAD_RECOVERY_QUARANTINE',
        ];$encoded=self::encodeJsonValue($quarantine,'PSTE_RECOVERY_CANDIDATE_QUARANTINE');$structure=(array)get_option(PSTE_OPTION_SITE_BASELINE,[]);$structureHash=(string)($structure['structure_sha256']??'');
        self::insertTopicPoolRow($table,['pool_key'=>$topic,'normalized_key'=>$normalized,'candidate_id'=>$candidateId,'first_run_uuid'=>$run,'last_run_uuid'=>$run,'original_category_id'=>0,'current_category_id'=>0,'automatic_decision'=>'BLOCKED','automatic_pool_status'=>'REVIEW_REQUIRED','topic_role'=>PSTE_Topic_Policy::ROLE_NON_EDITORIAL,'planning_suitability'=>'BLOCKED','context_state'=>'BLOCKED','structure_sha256'=>$structureHash,'manual_status'=>'','manual_category_id'=>0,'manual_article_type'=>'','manual_note'=>'','payload_json'=>$encoded,'occurrence_count'=>0,'first_seen_at'=>$now,'last_seen_at'=>$now,'reviewed_by'=>0],'PSTE_RECOVERY_CANDIDATE_QUARANTINE_INSERT_FAILED');
        self::assertTopicPayloadPersisted($topic,$encoded,'PSTE_RECOVERY_CANDIDATE_QUARANTINE');return $topic;
    }

    /** Repair at most $limit historical orphan history rows. The query always takes the first remaining rows, so replay is idempotent. @return array<string,mixed> */
    public static function topicIdentityHistoryRepairBatch(int $limit): array {
        $limit=max(1,min(25,$limit));global $wpdb;$history=self::table('topic_history');$pool=self::table('topic_pool');$occ=self::table('topic_occurrences');$identity=self::table('topic_identity');$orphans=$wpdb->get_results("SELECT h.id,h.pool_key,h.details_json FROM $history h LEFT JOIN $pool p ON p.pool_key=h.pool_key WHERE p.pool_key IS NULL ORDER BY h.id ASC LIMIT ".(int)$limit,ARRAY_A);if($orphans===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_HISTORY_ORPHAN_READ_FAILED:'.self::dbError());if(!$orphans)return ['contract'=>'PSTE_TOPIC_IDENTITY_HISTORY_BATCH_V1','processed'=>0,'repaired'=>0,'remaining'=>0,'complete'=>true];$repaired=0;
        self::beginTransaction();try{foreach((array)$orphans as $row){$details=json_decode((string)($row['details_json']??''),true);if(!is_array($details))throw new RuntimeException('PSTE_HISTORY_DETAILS_INVALID');$targets=[];$candidate=(string)($details['candidate_id']??'');if($candidate!==''){$a=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT topic_key FROM $occ WHERE candidate_id=%s",$candidate),0)?:[];$b=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT pool_key FROM $pool WHERE candidate_id=%s",$candidate),0)?:[];foreach(array_merge($a,$b) as $t)if((string)$t!=='')$targets[(string)$t]=true;}$normalized=(string)($details['normalized_key']??'');if($normalized!==''){$t=(string)$wpdb->get_var($wpdb->prepare("SELECT topic_uuid FROM $identity WHERE normalized_key=%s",$normalized));if($t!=='')$targets[$t]=true;}$targets=array_keys($targets);if(count($targets)!==1)throw new RuntimeException(count($targets)>1?'PSTE_HISTORY_IDENTITY_AMBIGUOUS':'PSTE_HISTORY_IDENTITY_UNRESOLVED');self::checkedUpdate($history,['pool_key'=>$targets[0]],['id'=>(int)$row['id']],['%s'],['%d'],'PSTE_HISTORY_REPAIR_UPDATE_FAILED');$repaired++;}self::commitTransaction();}catch(Throwable $e){self::rollbackTransaction();throw $e;}
        $remaining=(int)$wpdb->get_var("SELECT COUNT(*) FROM $history h LEFT JOIN $pool p ON p.pool_key=h.pool_key WHERE p.pool_key IS NULL");return ['contract'=>'PSTE_TOPIC_IDENTITY_HISTORY_BATCH_V1','processed'=>count($orphans),'repaired'=>$repaired,'remaining'=>$remaining,'complete'=>$remaining===0];
    }

    /** @return array<string,mixed> */
    public static function topicIdentityMigrationVerify(array $init,int $historyRepaired=0): array {
        if(($init['contract']??'')!=='PSTE_TOPIC_IDENTITY_MIGRATION_INIT_V1')throw new RuntimeException('PSTE_TOPIC_IDENTITY_MIGRATION_INIT_INVALID');$mode=(string)($init['mode']??'');$before=(array)($init['baseline']??[]);$after=self::migrationBaseline();
        if($mode==='IN_PLACE_UUID_MIGRATION'){foreach(['topic_pool','candidates','assignments','history'] as $field)if((int)($before[$field]??-1)!==(int)($after[$field]??-2))throw new RuntimeException('PSTE_MIGRATION_COUNT_CHANGED_'.strtoupper($field));if((int)$after['occurrences']<(int)($before['occurrences']??0))throw new RuntimeException('PSTE_MIGRATION_OCCURRENCE_COUNT_DECREASED');if((int)$after['identity']<(int)$after['topic_pool'])throw new RuntimeException('PSTE_MIGRATION_IDENTITY_COUNT_INCOMPLETE');self::assertTopicPoolUsesUuid();}
        elseif($mode==='RECOVERED_FROM_CANDIDATES'){if((int)($before['candidates']??-1)!==(int)($after['candidates']??-2))throw new RuntimeException('PSTE_RECOVERY_CANDIDATE_COUNT_CHANGED');if((int)$after['topic_pool']<=0|| (int)$after['occurrences']<=0)throw new RuntimeException('PSTE_RECOVERY_TOPIC_DOMAIN_EMPTY');if((int)$after['identity']<(int)$after['topic_pool'])throw new RuntimeException('PSTE_RECOVERY_IDENTITY_COUNT_INCOMPLETE');self::assertTopicPoolUsesUuid();}
        elseif($mode==='EMPTY_NEW_INSTALL'){foreach(['topic_pool','candidates','occurrences','assignments','history'] as $field)if((int)($after[$field]??0)!==0)throw new RuntimeException('PSTE_EMPTY_INSTALL_UNEXPECTED_'.strtoupper($field));}
        else throw new RuntimeException('PSTE_MIGRATION_MODE_UNKNOWN_'.$mode);
        self::assertTopicRelationsConsistent();return ['contract'=>'PSTE_TOPIC_IDENTITY_MIGRATION_VERIFY_V1','recovered'=>$mode==='RECOVERED_FROM_CANDIDATES','mode'=>$mode,'pool_count'=>(int)$after['topic_pool'],'candidate_count'=>(int)$after['candidates'],'previous_occurrence_count'=>(int)($init['previous_occurrence_count']??0),'history_repaired'=>max(0,$historyRepaired),'payloads_quarantined'=>self::countRecoveryQuarantinedTopics(),'status'=>'PASS'];
    }

    /** @param array<int,array<string,mixed>> $rows @return array<string,mixed> */
    private static function repairOneTopicPayloadFromCandidateEvidence(array &$rows,int $index,array $row): array {
        global $wpdb;$candidateId=(string)($row['candidate_id']??'');$sources=[];
        if($candidateId!==''){$candidateRows=$wpdb->get_results($wpdb->prepare('SELECT id,run_uuid,candidate_id,payload_json FROM '.self::table('candidates').' WHERE candidate_id=%s ORDER BY id ASC LIMIT 1000',$candidateId),ARRAY_A);if($candidateRows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_PAYLOAD_RECOVERY_CANDIDATE_READ_FAILED:'.self::dbError());foreach((array)$candidateRows as $candidateRow){$candidate=json_decode((string)($candidateRow['payload_json']??''),true);$run=(string)($candidateRow['run_uuid']??'');if(!is_array($candidate)||json_last_error()!==JSON_ERROR_NONE||$run===''||(string)($candidate['candidate_id']??'')!==$candidateId)continue;try{$normalized=self::normalizedKeyForCandidate($candidate);}catch(Throwable $e){continue;}$sources[]=['id'=>(int)($candidateRow['id']??0),'run_uuid'=>$run,'candidate_id'=>$candidateId,'candidate'=>$candidate,'normalized'=>$normalized];}}
        if(!$sources){$key=self::quarantineCorruptedTopicRow($rows,$index,$row,$candidateId===''?'PSTE_PAYLOAD_RECOVERY_SOURCE_MISSING':'PSTE_PAYLOAD_RECOVERY_SOURCE_INVALID');return ['repaired'=>false,'quarantined'=>true,'pool_key'=>$key];}
        usort($sources,static fn(array $a,array $b):int=>[$a['id'],$a['run_uuid']]<=>[$b['id'],$b['run_uuid']]);$merged=[];$latest=null;foreach($sources as $source){$merged=self::mergeCandidatePayload($merged,(array)$source['candidate'],(string)$source['run_uuid'],false);$latest=$source;}if(!is_array($latest)){$key=self::quarantineCorruptedTopicRow($rows,$index,$row,'PSTE_PAYLOAD_RECOVERY_SOURCE_EMPTY');return ['repaired'=>false,'quarantined'=>true,'pool_key'=>$key];}
        $normalized=self::normalizedKeyForCandidate($merged);$storedNormalized=(string)($row['normalized_key']??'');if($storedNormalized!==''&&!hash_equals($storedNormalized,$normalized)){$key=self::quarantineCorruptedTopicRow($rows,$index,$row,'PSTE_PAYLOAD_RECOVERY_IDENTITY_MISMATCH');return ['repaired'=>false,'quarantined'=>true,'pool_key'=>$key];}
        $topic=(string)$row['pool_key'];foreach($sources as $source)self::upsertTopicOccurrence($topic,(string)$source['run_uuid'],(array)$source['candidate']);$automatic=self::automaticPoolStatus($merged);$role=PSTE_Topic_Policy::classifyRole($merged);$merged['automatic_pool_status']=$automatic;$merged['topic_role']=$role;$merged['planning_suitability']='BLOCKED';$merged['context_state']='PENDING';$merged['portal_context']=[];$aggregate=self::topicOccurrenceCount($topic);if($aggregate<1)throw new RuntimeException('PSTE_PAYLOAD_RECOVERY_OCCURRENCES_EMPTY');$latestCandidate=(array)$latest['candidate'];$currentCategory=(int)($row['current_category_id']??0);if($currentCategory<=0)$currentCategory=(int)($latestCandidate['target_category_id']??0);$encoded=self::encodeJsonValue($merged,'PSTE_PAYLOAD_RECOVERY');$updated=['normalized_key'=>$normalized,'candidate_id'=>$candidateId,'last_run_uuid'=>(string)$latest['run_uuid'],'automatic_decision'=>(string)($latestCandidate['decision']??'REVIEW_REQUIRED'),'automatic_pool_status'=>$automatic,'topic_role'=>$role,'planning_suitability'=>'BLOCKED','context_state'=>'PENDING','context_synced_at'=>null,'current_category_id'=>$currentCategory,'payload_json'=>$encoded,'occurrence_count'=>$aggregate,'last_seen_at'=>gmdate('Y-m-d H:i:s')];self::checkedUpdate(self::table('topic_pool'),$updated,['id'=>(int)$row['id']],['%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%d','%s'],['%d'],'PSTE_PAYLOAD_RECOVERY_UPDATE_FAILED');self::assertTopicPayloadPersisted($topic,$encoded,'PSTE_PAYLOAD_RECOVERY');$rows[$index]=array_merge($row,$updated);return ['repaired'=>true,'quarantined'=>false,'pool_key'=>$topic];
    }

    private static function countRecoveryQuarantinedTopics(): int {global $wpdb;$rows=$wpdb->get_col('SELECT payload_json FROM '.self::table('topic_pool'),0);$count=0;foreach((array)$rows as $raw){$p=json_decode((string)$raw,true);if(is_array($p)&&!empty($p['recovery_quarantined']))$count++;}return $count;}

    private static function rebuildTopicPoolFromCandidatesTransactional(): int {
        global $wpdb;
        $rows=$wpdb->get_results("SELECT run_uuid,payload_json FROM ".self::table('candidates')." ORDER BY id ASC",ARRAY_A)?:[];
        if(!$rows)throw new RuntimeException('PSTE_TOPIC_RECOVERY_SOURCE_EMPTY');
        self::beginTransaction();
        try{
            foreach(['topic_pool','topic_occurrences','topic_assignments','topic_identity','topic_merge_candidates'] as $name){
                self::checkedQuery("DELETE FROM ".self::table($name),'PSTE_TOPIC_RECOVERY_CLEAR_FAILED_'.$name);
            }
            foreach($rows as $row){
                $candidate=json_decode((string)$row['payload_json'],true);
                if(!is_array($candidate))throw new RuntimeException('PSTE_TOPIC_RECOVERY_PAYLOAD_INVALID');
                self::upsertTopicPool((string)$row['run_uuid'],$candidate);
            }
            if(self::topicPoolCount()<=0)throw new RuntimeException('PSTE_TOPIC_RECOVERY_CREATED_ZERO_TOPICS');
            $historyRepaired=self::repairHistoricalTopicKeys();
            self::assertTopicRelationsConsistent();
            self::commitTransaction();
            return $historyRepaired;
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
    }

    private static function migrateExistingPoolKeysInPlace(): array {
        global $wpdb;
        $pool=self::table('topic_pool');$rows=$wpdb->get_results("SELECT * FROM $pool ORDER BY id ASC",ARRAY_A)?:[];
        if(!$rows)return ['payloads_repaired'=>0,'payloads_quarantined'=>0,'occurrences_added'=>0,'history_repaired'=>0];
        self::beginTransaction();
        try{
            $before=count($rows);$occurrencesBefore=self::countRows('topic_occurrences');
            $payloadRepair=self::repairTopicPayloadsFromCandidates($rows);
            foreach($rows as $row){
                $payload=json_decode((string)$row['payload_json'],true);
                if(!is_array($payload))throw new RuntimeException('PSTE_UUID_MIGRATION_PAYLOAD_INVALID');
                $normalized=!empty($payload['recovery_quarantined'])?(string)($row['normalized_key']??$payload['recovery_normalized_key']??''):self::normalizedKeyForCandidate($payload);
                if(!preg_match('/^[a-f0-9]{64}$/',$normalized))throw new RuntimeException('PSTE_UUID_MIGRATION_NORMALIZED_KEY_INVALID');
                $oldKey=(string)$row['pool_key'];
                $uuid=(string)$wpdb->get_var($wpdb->prepare("SELECT topic_uuid FROM ".self::table('topic_identity')." WHERE normalized_key=%s",$normalized));
                if($uuid===''){
                    $uuid=wp_generate_uuid4();
                    self::checkedQuery($wpdb->prepare("INSERT INTO ".self::table('topic_identity')." (normalized_key,topic_uuid,created_at) VALUES (%s,%s,%s)",$normalized,$uuid,gmdate('Y-m-d H:i:s')),'PSTE_UUID_IDENTITY_INSERT_FAILED');
                }
                if($oldKey!==$uuid){
                    $collision=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $pool WHERE pool_key=%s AND id<>%d",$uuid,(int)$row['id']));
                    if($collision>0)throw new RuntimeException('PSTE_UUID_MIGRATION_COLLISION_REVIEW_REQUIRED');
                    self::checkedUpdate($pool,['pool_key'=>$uuid,'normalized_key'=>$normalized],['id'=>(int)$row['id']],['%s','%s'],['%d'],'PSTE_UUID_POOL_UPDATE_FAILED');
                    self::checkedUpdate(self::table('topic_occurrences'),['topic_key'=>$uuid],['topic_key'=>$oldKey],['%s'],['%s'],'PSTE_UUID_OCCURRENCE_UPDATE_FAILED');
                    self::checkedUpdate(self::table('topic_assignments'),['topic_key'=>$uuid],['topic_key'=>$oldKey],['%s'],['%s'],'PSTE_UUID_ASSIGNMENT_UPDATE_FAILED');
                    self::checkedUpdate(self::table('topic_history'),['pool_key'=>$uuid],['pool_key'=>$oldKey],['%s'],['%s'],'PSTE_UUID_HISTORY_UPDATE_FAILED');
                }else{
                    self::checkedUpdate($pool,['normalized_key'=>$normalized],['id'=>(int)$row['id']],['%s'],['%d'],'PSTE_UUID_NORMALIZED_UPDATE_FAILED');
                }
            }
            $historyRepaired=self::repairHistoricalTopicKeys();
            if(self::topicPoolCount()!==$before)throw new RuntimeException('PSTE_UUID_MIGRATION_COUNT_CHANGED');
            self::assertTopicRelationsConsistent();self::commitTransaction();
            return ['payloads_repaired'=>(int)($payloadRepair['repaired']??0),'payloads_quarantined'=>(int)($payloadRepair['quarantined']??0),'invalid_candidate_rows'=>(int)($payloadRepair['invalid_candidate_rows']??0),'occurrences_added'=>max(0,self::countRows('topic_occurrences')-$occurrencesBefore),'history_repaired'=>$historyRepaired];
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
    }

    /**
     * Converts exactly one unrecoverable topic row to a valid fail-closed
     * quarantine envelope. No other topic is blocked and no portal object is
     * written. The quarantined row can be healed later by valid candidate data.
     */
    private static function quarantineCorruptedTopicRow(array &$poolRows,int $index,array $row,string $reasonCode): string {
        $table=self::table('topic_pool');$topic=(string)($row['pool_key']??'');
        if($topic==='')throw new RuntimeException('PSTE_PAYLOAD_RECOVERY_TOPIC_KEY_EMPTY');
        $storedNormalized=(string)($row['normalized_key']??'');$storedCandidate=(string)($row['candidate_id']??'');$raw=(string)($row['payload_json']??'');
        $normalized=preg_match('/^[a-f0-9]{64}$/',$storedNormalized)?$storedNormalized:hash('sha256','PSTE_RECOVERY_QUARANTINE|'.$topic.'|'.$storedCandidate);
        $candidateId=$storedCandidate!==''?$storedCandidate:hash('sha256','PSTE_RECOVERY_QUARANTINE_CANDIDATE|'.$topic);
        $quarantine=[
            'contract'=>'PSTE_TOPIC_PAYLOAD_RECOVERY_QUARANTINE_V1',
            'recovery_quarantined'=>true,
            'recovery_error_code'=>$reasonCode,
            'recovery_normalized_key'=>$normalized,
            'candidate_id'=>$candidateId,
            'canonical_query'=>'',
            'primary_longtail_query'=>'',
            'raw_user_question'=>'',
            'decision'=>'BLOCKED',
            'reason_codes'=>['PSTE_TOPIC_PAYLOAD_CORRUPTED',$reasonCode],
            'automatic_pool_status'=>'REVIEW_REQUIRED',
            'topic_role'=>PSTE_Topic_Policy::ROLE_NON_EDITORIAL,
            'planning_suitability'=>'BLOCKED',
            'context_state'=>'BLOCKED',
            'portal_context'=>[
                'error_code'=>$reasonCode,
                'corrupted_payload_sha256'=>hash('sha256',$raw),
                'corrupted_payload_length'=>strlen($raw),
                'corrupted_payload_b64'=>base64_encode($raw),
                'corrupted_payload_bytes_preserved'=>true,
                'write_scope'=>'PSTE_OWN_TABLE_ONLY',
            ],
            'found_categories'=>[],
            'aliases'=>[],
            'evidence'=>[],
            'seen_in_runs'=>array_values(array_filter([(string)($row['last_run_uuid']??'')])),
            'candidate_ids'=>[$candidateId],
            'textmachine_handoff_status'=>'BLOCKED_PAYLOAD_RECOVERY_QUARANTINE',
        ];
        $encoded=self::encodeJsonValue($quarantine,'PSTE_PAYLOAD_RECOVERY_QUARANTINE');
        $updated=[
            'normalized_key'=>$normalized,
            'candidate_id'=>$candidateId,
            'automatic_decision'=>'BLOCKED',
            'automatic_pool_status'=>'REVIEW_REQUIRED',
            'topic_role'=>PSTE_Topic_Policy::ROLE_NON_EDITORIAL,
            'planning_suitability'=>'BLOCKED',
            'context_state'=>'BLOCKED',
            'context_synced_at'=>null,
            'payload_json'=>$encoded,
            'occurrence_count'=>max(1,(int)($row['occurrence_count']??1)),
            'last_seen_at'=>gmdate('Y-m-d H:i:s'),
        ];
        self::checkedUpdate($table,$updated,['id'=>(int)$row['id']],['%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s'],['%d'],'PSTE_PAYLOAD_RECOVERY_QUARANTINE_UPDATE_FAILED');
        self::assertTopicPayloadPersisted($topic,$encoded,'PSTE_PAYLOAD_RECOVERY_QUARANTINE');
        $poolRows[$index]=array_merge($row,$updated);
        return $topic;
    }

    /**
     * Repairs corrupted topic payloads from persisted candidate evidence. If no
     * deterministic source exists, only that topic is converted to a valid,
     * non-production quarantine envelope; other topics remain usable.
     * Invalid candidate evidence is isolated and never blocks unrelated topics.
     *
     * @return array{repaired:int,quarantined:int,quarantine_keys:list<string>,invalid_candidate_rows:int}
     */
    private static function repairTopicPayloadsFromCandidates(array &$poolRows): array {
        global $wpdb;
        $needsRepair=[];
        foreach($poolRows as $index=>$row){
            $payload=json_decode((string)($row['payload_json']??''),true);
            $isQuarantine=is_array($payload)&&json_last_error()===JSON_ERROR_NONE&&!empty($payload['recovery_quarantined']);
            $query=is_array($payload)?trim((string)(($payload['raw_user_question']??'')!==''?$payload['raw_user_question']:($payload['canonical_query']??$payload['primary_longtail_query']??''))):'';
            $storedNormalized=(string)($row['normalized_key']??'');
            $usable=$isQuarantine||(is_array($payload)&&json_last_error()===JSON_ERROR_NONE&&$query!=='');
            if($usable&&!$isQuarantine&&$storedNormalized!=='')$usable=hash_equals($storedNormalized,self::normalizedKeyForCandidate($payload));
            if(!$usable)$needsRepair[$index]=$row;
        }
        if(!$needsRepair)return ['repaired'=>0,'quarantined'=>0,'quarantine_keys'=>[],'invalid_candidate_rows'=>0];

        $candidateRows=$wpdb->get_results("SELECT id,run_uuid,candidate_id,payload_json FROM ".self::table('candidates')." ORDER BY id ASC",ARRAY_A);
        if($candidateRows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_PAYLOAD_RECOVERY_CANDIDATE_READ_FAILED:'.self::dbError());
        $byNormalized=[];$byCandidateId=[];$invalidCandidateIds=[];$invalidCandidateRows=0;
        foreach((array)$candidateRows as $candidateRow){
            $candidateId=(string)($candidateRow['candidate_id']??'');$runUuid=(string)($candidateRow['run_uuid']??'');
            $candidate=json_decode((string)($candidateRow['payload_json']??''),true);
            if(!is_array($candidate)||json_last_error()!==JSON_ERROR_NONE||$runUuid===''||$candidateId===''||(string)($candidate['candidate_id']??'')!==$candidateId){
                $invalidCandidateRows++;if($candidateId!=='')$invalidCandidateIds[$candidateId]=true;continue;
            }
            try{$normalized=self::normalizedKeyForCandidate($candidate);}catch(Throwable $e){$normalized='';}
            if(!preg_match('/^[a-f0-9]{64}$/',$normalized)){$invalidCandidateRows++;$invalidCandidateIds[$candidateId]=true;continue;}
            $record=['id'=>(int)($candidateRow['id']??0),'run_uuid'=>$runUuid,'candidate_id'=>$candidateId,'candidate'=>$candidate];
            $byNormalized[$normalized][]=$record;$byCandidateId[$candidateId][]=$record;
        }

        $repaired=0;$quarantined=0;$quarantineKeys=[];$table=self::table('topic_pool');
        foreach($needsRepair as $index=>$row){
            $topic=(string)($row['pool_key']??'');$storedNormalized=(string)($row['normalized_key']??'');$storedCandidate=(string)($row['candidate_id']??'');
            $sources=(array)($byNormalized[$storedNormalized]??[]);
            if(!$sources&&$storedCandidate!=='')$sources=(array)($byCandidateId[$storedCandidate]??[]);
            if(!$sources){
                $reason=isset($invalidCandidateIds[$storedCandidate])?'PSTE_PAYLOAD_RECOVERY_SOURCE_INVALID':'PSTE_PAYLOAD_RECOVERY_SOURCE_MISSING';
                $quarantineKeys[]=self::quarantineCorruptedTopicRow($poolRows,$index,$row,$reason);$quarantined++;continue;
            }
            usort($sources,static fn(array $a,array $b):int=>[$a['id'],$a['run_uuid'],$a['candidate_id']]<=>[$b['id'],$b['run_uuid'],$b['candidate_id']]);

            // Build the deterministic payload first. No occurrence row is written
            // until the identity has been proven to match the damaged pool row.
            $merged=[];$latest=null;
            foreach($sources as $source){$merged=self::mergeCandidatePayload($merged,(array)$source['candidate'],(string)$source['run_uuid'],false);$latest=$source;}
            if(!is_array($latest)){$quarantineKeys[]=self::quarantineCorruptedTopicRow($poolRows,$index,$row,'PSTE_PAYLOAD_RECOVERY_SOURCE_EMPTY');$quarantined++;continue;}
            $normalized=self::normalizedKeyForCandidate($merged);
            if($storedNormalized!==''&&!hash_equals($storedNormalized,$normalized)){
                $quarantineKeys[]=self::quarantineCorruptedTopicRow($poolRows,$index,$row,'PSTE_PAYLOAD_RECOVERY_IDENTITY_MISMATCH');$quarantined++;continue;
            }

            foreach($sources as $source)self::upsertTopicOccurrence($topic,(string)$source['run_uuid'],(array)$source['candidate']);

            // Portal-context evidence was part of the damaged payload and is not
            // invented during recovery. It is deliberately reset fail-closed and
            // recomputed by the existing targeted context refresh on finalization.
            $contextState='PENDING';
            $automatic=self::automaticPoolStatus($merged);$role=PSTE_Topic_Policy::classifyRole($merged);$planning='BLOCKED';
            $merged['automatic_pool_status']=$automatic;$merged['topic_role']=$role;$merged['planning_suitability']=$planning;$merged['context_state']=$contextState;$merged['portal_context']=[];
            $aggregate=self::topicOccurrenceCount($topic);if($aggregate<1)throw new RuntimeException('PSTE_PAYLOAD_RECOVERY_OCCURRENCES_EMPTY');
            $latestCandidate=(array)$latest['candidate'];$currentCategory=(int)($row['current_category_id']??0);if($currentCategory<=0)$currentCategory=(int)($latestCandidate['target_category_id']??0);
            $encoded=self::encodeJsonValue($merged,'PSTE_PAYLOAD_RECOVERY');
            $updated=[
                'normalized_key'=>$normalized,
                'candidate_id'=>(string)$latest['candidate_id'],
                'last_run_uuid'=>(string)$latest['run_uuid'],
                'automatic_decision'=>(string)($latestCandidate['decision']??'REVIEW_REQUIRED'),
                'automatic_pool_status'=>$automatic,
                'topic_role'=>$role,
                'planning_suitability'=>$planning,
                'context_state'=>$contextState,
                'context_synced_at'=>null,
                'current_category_id'=>$currentCategory,
                'payload_json'=>$encoded,
                'occurrence_count'=>$aggregate,
                'last_seen_at'=>gmdate('Y-m-d H:i:s'),
            ];
            self::checkedUpdate($table,$updated,['id'=>(int)$row['id']],['%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%d','%s'],['%d'],'PSTE_PAYLOAD_RECOVERY_UPDATE_FAILED');
            self::assertTopicPayloadPersisted($topic,$encoded,'PSTE_PAYLOAD_RECOVERY');
            $poolRows[$index]=array_merge($row,$updated);$repaired++;
        }
        return ['repaired'=>$repaired,'quarantined'=>$quarantined,'quarantine_keys'=>$quarantineKeys,'invalid_candidate_rows'=>$invalidCandidateRows];
    }

    private static function repairHistoricalTopicKeys(): int {
        global $wpdb;
        $history=self::table('topic_history');$pool=self::table('topic_pool');$occ=self::table('topic_occurrences');$identity=self::table('topic_identity');
        $orphans=$wpdb->get_results("SELECT h.id,h.pool_key,h.details_json FROM $history h LEFT JOIN $pool p ON p.pool_key=h.pool_key WHERE p.pool_key IS NULL ORDER BY h.id ASC",ARRAY_A);
        if($orphans===null && (string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_HISTORY_ORPHAN_READ_FAILED:'.self::dbError());
        if(!$orphans)return 0;

        $candidateRows=$wpdb->get_results("SELECT candidate_id,topic_key FROM $occ ORDER BY id ASC",ARRAY_A);
        if($candidateRows===null && (string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_HISTORY_CANDIDATE_MAP_READ_FAILED:'.self::dbError());
        $candidateMap=[];
        foreach((array)$candidateRows as $row){
            $candidate=(string)($row['candidate_id']??'');$topic=(string)($row['topic_key']??'');
            if($candidate===''||$topic==='')continue;
            if(isset($candidateMap[$candidate])&&$candidateMap[$candidate]!==$topic)throw new RuntimeException('PSTE_HISTORY_CANDIDATE_MAP_AMBIGUOUS');
            $candidateMap[$candidate]=$topic;
        }

        $poolRows=$wpdb->get_results("SELECT candidate_id,pool_key FROM $pool ORDER BY id ASC",ARRAY_A);
        if($poolRows===null && (string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_HISTORY_POOL_MAP_READ_FAILED:'.self::dbError());
        foreach((array)$poolRows as $row){
            $candidate=(string)($row['candidate_id']??'');$topic=(string)($row['pool_key']??'');
            if($candidate===''||$topic==='')continue;
            if(isset($candidateMap[$candidate])&&$candidateMap[$candidate]!==$topic)throw new RuntimeException('PSTE_HISTORY_POOL_MAP_AMBIGUOUS');
            $candidateMap[$candidate]=$topic;
        }

        $identityRows=$wpdb->get_results("SELECT normalized_key,topic_uuid FROM $identity ORDER BY normalized_key ASC",ARRAY_A);
        if($identityRows===null && (string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_HISTORY_IDENTITY_MAP_READ_FAILED:'.self::dbError());
        $identityMap=[];
        foreach((array)$identityRows as $row){
            $normalized=(string)($row['normalized_key']??'');$topic=(string)($row['topic_uuid']??'');
            if($normalized===''||$topic==='')continue;
            if(isset($identityMap[$normalized])&&$identityMap[$normalized]!==$topic)throw new RuntimeException('PSTE_HISTORY_IDENTITY_MAP_AMBIGUOUS');
            $identityMap[$normalized]=$topic;
        }

        $oldToTargets=[];
        foreach((array)$orphans as $row){
            $old=(string)($row['pool_key']??'');
            $details=json_decode((string)($row['details_json']??''),true);
            if(!is_array($details))throw new RuntimeException('PSTE_HISTORY_DETAILS_INVALID');
            $targets=[];
            $candidate=(string)($details['candidate_id']??'');
            if($candidate!==''&&isset($candidateMap[$candidate]))$targets[$candidateMap[$candidate]]=true;
            $normalized=(string)($details['normalized_key']??'');
            if($normalized!==''&&isset($identityMap[$normalized]))$targets[$identityMap[$normalized]]=true;
            foreach(array_keys($targets) as $target)$oldToTargets[$old][$target]=true;
        }

        $mapping=[];
        foreach((array)$orphans as $row){
            $old=(string)($row['pool_key']??'');$targets=array_keys((array)($oldToTargets[$old]??[]));
            if(count($targets)!==1)throw new RuntimeException(count($targets)>1?'PSTE_HISTORY_IDENTITY_AMBIGUOUS':'PSTE_HISTORY_IDENTITY_UNRESOLVED');
            $mapping[$old]=$targets[0];
        }

        $repaired=0;
        foreach($mapping as $old=>$target){
            $result=self::checkedUpdate($history,['pool_key'=>$target],['pool_key'=>$old],['%s'],['%s'],'PSTE_HISTORY_REPAIR_UPDATE_FAILED');
            $repaired+=(int)$result;
        }
        $remaining=(int)$wpdb->get_var("SELECT COUNT(*) FROM $history h LEFT JOIN $pool p ON p.pool_key=h.pool_key WHERE p.pool_key IS NULL");
        if($remaining!==0)throw new RuntimeException('PSTE_HISTORY_REPAIR_INCOMPLETE_'.$remaining);
        return $repaired;
    }

    public static function assertTopicRelationsConsistent(): void {
        global $wpdb;$pool=self::table('topic_pool');
        $orphanOccurrences=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::table('topic_occurrences')." o LEFT JOIN $pool p ON p.pool_key=o.topic_key WHERE p.pool_key IS NULL");
        $orphanAssignments=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::table('topic_assignments')." a LEFT JOIN $pool p ON p.pool_key=a.topic_key WHERE p.pool_key IS NULL");
        $orphanHistory=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::table('topic_history')." h LEFT JOIN $pool p ON p.pool_key=h.pool_key WHERE p.pool_key IS NULL");
        if($orphanOccurrences>0||$orphanAssignments>0||$orphanHistory>0)throw new RuntimeException('PSTE_TOPIC_RELATION_ORPHANS_'.$orphanOccurrences.'_'.$orphanAssignments.'_'.$orphanHistory);
    }

    /**
     * Every code path using START TRANSACTION relies on rollback being real.
     * Fail before the first transactional write if any PSTE-owned table is backed
     * by a non-transactional engine. This protects all migrations/rebuilds, not
     * only the editorial ruleset upgrade that exposed the issue.
     *
     * @return array<string,mixed>
     */
    public static function transactionalStorageAudit(bool $refresh=false): array {
        // Safety-critical by design: never trust a prior PASS from the same request.
        // A table engine can be changed externally between two transactions.
        global $wpdb;
        $tables=['runs','candidates','evidence','cost_ledger','gsc_queries','topic_pool','topic_history','topic_occurrences','topic_assignments','topic_identity','topic_merge_candidates'];
        $engines=[];
        foreach($tables as $name){
            $table=self::table($name);$wpdb->last_error='';
            $sql=method_exists($wpdb,'prepare')?$wpdb->prepare('SHOW TABLE STATUS WHERE Name=%s',$table):"SHOW TABLE STATUS WHERE Name='".str_replace("'","''",$table)."'";
            $row=$wpdb->get_row($sql,ARRAY_A);
            if((string)($wpdb->last_error??'')!=='')throw new RuntimeException('PSTE_TRANSACTIONAL_STORAGE_READ_FAILED_'.strtoupper($name).':'.self::dbError());
            if(!is_array($row))throw new RuntimeException('PSTE_TRANSACTIONAL_STORAGE_TABLE_MISSING_'.strtoupper($name));
            $engine=strtoupper(trim((string)($row['Engine']??'')));
            if(!in_array($engine,['INNODB','XTRADB'],true))throw new RuntimeException('PSTE_TRANSACTIONAL_STORAGE_REQUIRED_'.strtoupper($name).'_'.($engine!==''?$engine:'UNKNOWN'));
            $engines[$name]=$engine;
        }
        return ['contract'=>'PSTE_TRANSACTIONAL_STORAGE_AUDIT_V2_FRESH_PER_TRANSACTION','status'=>'PASS','tables'=>$engines,'write_attempted'=>false,'cache_authoritative'=>false];
    }

    /** Single transaction owner for all PSTE table mutations that require atomic rollback. */
    public static function beginOwnedTransaction(string $code='PSTE_DB_TRANSACTION_START_FAILED'): void {self::transactionalStorageAudit(true);self::checkedQuery('START TRANSACTION',$code);}
    public static function commitOwnedTransaction(string $code='PSTE_DB_TRANSACTION_COMMIT_FAILED'): void {self::checkedQuery('COMMIT',$code);}
    public static function rollbackOwnedTransaction(string $code='PSTE_DB_TRANSACTION_ROLLBACK_FAILED'): void {PSTE_DB_Write_Guard::query('ROLLBACK',$code,false);}
    private static function beginTransaction(): void {self::beginOwnedTransaction();}
    private static function commitTransaction(): void {self::commitOwnedTransaction();}
    private static function rollbackTransaction(): void {self::rollbackOwnedTransaction();}
    private static function dbError(): string {global $wpdb;$error=preg_replace('/[^A-Za-z0-9_:\- ]/','',(string)$wpdb->last_error);return substr((string)$error,0,160);}
    private static function checkedInsert(string $table,array $data,array $formats,string $code): int {return PSTE_DB_Write_Guard::insert($table,$data,$formats,$code);}
    private static function checkedReplace(string $table,array $data,array $formats,string $code): int {return PSTE_DB_Write_Guard::replace($table,$data,$formats,$code);}
    private static function checkedUpdate(string $table,array $data,array $where,array $formats,array $whereFormats,string $code): int {return PSTE_DB_Write_Guard::update($table,$data,$where,$formats,$whereFormats,$code);}
    private static function checkedDelete(string $table,array $where,array $whereFormats,string $code): int {return PSTE_DB_Write_Guard::delete($table,$where,$whereFormats,$code);}
    private static function checkedQuery(string $query,string $code): int {return PSTE_DB_Write_Guard::query($query,$code);}

    /** @return list<string> */
    private static function topicPoolInsertFormats(): array {return ['%s','%s','%s','%s','%s','%d','%d','%s','%s','%s','%s','%s','%s','%s','%d','%s','%s','%s','%d','%s','%s','%d'];}
    /** @return list<string> */
    private static function topicPoolUpdateFormats(): array {return ['%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%s','%d','%s'];}
    private static function insertTopicPoolRow(string $table,array $data,string $code): int {return self::checkedInsert($table,$data,self::topicPoolInsertFormats(),$code);}
    private static function updateTopicPoolRow(string $table,string $poolKey,array $data,string $code): int {return self::checkedUpdate($table,$data,['pool_key'=>$poolKey],self::topicPoolUpdateFormats(),['%s'],$code);}


    private static function encodeJsonValue($value,string $code): string {
        // Persist JSON as ASCII-safe text. All non-ASCII characters are emitted
        // as JSON unicode escapes. This keeps the payload byte-stable even when
        // an older plugin table still uses a legacy database charset.
        try{$encoded=wp_json_encode($value,JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);}catch(Throwable $e){throw new RuntimeException($code.'_ENCODE_FAILED',0,$e);}
        if(!is_string($encoded)||$encoded==='')throw new RuntimeException($code.'_ENCODE_FAILED');
        if(preg_match('/[^\x00-\x7F]/',$encoded))throw new RuntimeException($code.'_ASCII_STORAGE_CONTRACT_FAILED');
        json_decode($encoded,true);
        if(json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException($code.'_ROUNDTRIP_INVALID');
        return $encoded;
    }

    private static function assertTopicPayloadPersisted(string $topicKey,string $expectedJson,string $code): void {
        global $wpdb;
        $wpdb->last_error='';
        $row=$wpdb->get_row($wpdb->prepare("SELECT payload_json FROM ".self::table('topic_pool')." WHERE pool_key=%s",$topicKey),ARRAY_A);
        if((string)$wpdb->last_error!=='')throw new RuntimeException($code.'_READBACK_QUERY_FAILED:'.self::dbError());
        if(!is_array($row))throw new RuntimeException($code.'_READBACK_MISSING');
        $stored=(string)($row['payload_json']??'');
        if($stored==='')throw new RuntimeException($code.'_READBACK_EMPTY');
        $decoded=json_decode($stored,true);
        if(!is_array($decoded)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException($code.'_NOT_VALID_JSON_LEN_'.strlen($stored));
        if(!hash_equals(hash('sha256',$expectedJson),hash('sha256',$stored)))throw new RuntimeException($code.'_READBACK_MISMATCH');
    }

    /**
     * Proves the JSON storage path against the real plugin table before any
     * paid provider request or finalization. The probe touches only a temporary
     * row in the SEO engine's own topic_pool table and removes it immediately.
     */
    public static function assertOwnJsonStorageReady(): array {
        global $wpdb;
        $table=self::table('topic_pool');
        $columns=$wpdb->get_results("SHOW FULL COLUMNS FROM $table",ARRAY_A);
        if($columns===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_TOPIC_POOL_SCHEMA_READ_FAILED:'.self::dbError());
        $payloadColumn=null;
        foreach((array)$columns as $column)if((string)($column['Field']??'')==='payload_json'){$payloadColumn=$column;break;}
        if(!is_array($payloadColumn))throw new RuntimeException('PSTE_TOPIC_POOL_PAYLOAD_COLUMN_MISSING');
        if(!str_starts_with(strtolower((string)($payloadColumn['Type']??'')),'longtext'))throw new RuntimeException('PSTE_TOPIC_POOL_PAYLOAD_COLUMN_NOT_LONGTEXT');

        $uuid=function_exists('wp_generate_uuid4')?wp_generate_uuid4():sprintf('%08x-%04x-%04x-%04x-%012x',mt_rand(),mt_rand(0,65535),mt_rand(0,65535),mt_rand(0,65535),mt_rand());
        $poolKey=hash('sha256','PSTE_JSON_STORAGE_PROBE|'.$uuid.'|'.microtime(true));
        $normalized=hash('sha256','PSTE_JSON_STORAGE_PROBE_NORMALIZED|'.$uuid);
        $candidate=hash('sha256','PSTE_JSON_STORAGE_PROBE_CANDIDATE|'.$uuid);
        $now=gmdate('Y-m-d H:i:s');
        $insertPayload=self::encodeJsonValue(['contract'=>'PSTE_JSON_STORAGE_PROBE_V2','stage'=>'INSERT','german'=>'Schutzhülle für äußere Nässe','four_byte'=>'🐴','slashes'=>'https://example.invalid/a/b'],'PSTE_JSON_STORAGE_PROBE');
        $updatePayload=self::encodeJsonValue(['contract'=>'PSTE_JSON_STORAGE_PROBE_V2','stage'=>'UPDATE','german'=>'Zügel richtig pflegen','question'=>'Bleibt das Material bei Nässe stabil?'],'PSTE_JSON_STORAGE_PROBE');
        try{
            self::insertTopicPoolRow($table,[
                'pool_key'=>$poolKey,'normalized_key'=>$normalized,'candidate_id'=>$candidate,
                'first_run_uuid'=>$uuid,'last_run_uuid'=>$uuid,'original_category_id'=>0,'current_category_id'=>0,
                'automatic_decision'=>'REVIEW_REQUIRED','automatic_pool_status'=>'REVIEW_REQUIRED','topic_role'=>'RESEARCH_KEYWORD',
                'planning_suitability'=>'BLOCKED','context_state'=>'PENDING','structure_sha256'=>'','manual_status'=>'',
                'manual_category_id'=>0,'manual_article_type'=>'','manual_note'=>'','payload_json'=>$insertPayload,
                'occurrence_count'=>1,'first_seen_at'=>$now,'last_seen_at'=>$now,'reviewed_by'=>0,
            ],'PSTE_JSON_STORAGE_PROBE_INSERT_FAILED');
            self::assertTopicPayloadPersisted($poolKey,$insertPayload,'PSTE_JSON_STORAGE_PROBE_INSERT');

            $updateData=[
                'normalized_key'=>$normalized,'candidate_id'=>$candidate,'last_run_uuid'=>$uuid,
                'automatic_decision'=>'REVIEW_REQUIRED','automatic_pool_status'=>'REVIEW_REQUIRED','topic_role'=>'RESEARCH_KEYWORD',
                'planning_suitability'=>'BLOCKED','context_state'=>'PENDING','structure_sha256'=>'','context_synced_at'=>null,
                'current_category_id'=>0,'payload_json'=>$updatePayload,'occurrence_count'=>2,'last_seen_at'=>$now,
            ];
            self::updateTopicPoolRow($table,$poolKey,$updateData,'PSTE_JSON_STORAGE_PROBE_UPDATE_FAILED');
            self::assertTopicPayloadPersisted($poolKey,$updatePayload,'PSTE_JSON_STORAGE_PROBE_UPDATE');
            // Repeat the exact UPDATE path to prove stable reprocessing.
            self::updateTopicPoolRow($table,$poolKey,$updateData,'PSTE_JSON_STORAGE_PROBE_REPEAT_UPDATE_FAILED');
            self::assertTopicPayloadPersisted($poolKey,$updatePayload,'PSTE_JSON_STORAGE_PROBE_REPEAT_UPDATE');
        }finally{
            self::checkedDelete($table,['pool_key'=>$poolKey],['%s'],'PSTE_JSON_STORAGE_PROBE_DELETE_FAILED');
            $remaining=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE pool_key=%s",$poolKey));
            if($remaining!==0)throw new RuntimeException('PSTE_JSON_STORAGE_PROBE_DELETE_NOT_PERSISTED');
        }
        return ['contract'=>'PSTE_JSON_STORAGE_PREFLIGHT_V2','status'=>'PASS','payload_column_type'=>(string)($payloadColumn['Type']??''),'payload_column_collation'=>(string)($payloadColumn['Collation']??''),'ascii_safe_json'=>true,'insert_path_verified'=>true,'update_path_verified_twice'=>true,'temporary_probe_removed'=>true,'article_or_taxonomy_write_attempted'=>false];
    }

    private static function assertOccurrencePayloadPersisted(string $occurrenceKey,string $expectedJson,int $expectedCount,string $code): void {
        global $wpdb;
        $stored=$wpdb->get_row($wpdb->prepare("SELECT payload_json,occurrence_count FROM ".self::table('topic_occurrences')." WHERE occurrence_key=%s",$occurrenceKey),ARRAY_A);
        if(!is_array($stored))throw new RuntimeException($code.'_READBACK_MISSING');
        $storedJson=(string)($stored['payload_json']??'');
        $decoded=json_decode($storedJson,true);
        if(!is_array($decoded)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException($code.'_NOT_VALID_JSON');
        if(!hash_equals(hash('sha256',$expectedJson),hash('sha256',$storedJson)))throw new RuntimeException($code.'_READBACK_MISMATCH');
        if((int)($stored['occurrence_count']??0)!==$expectedCount)throw new RuntimeException($code.'_COUNT_READBACK_MISMATCH_'.$expectedCount.'_'.(int)($stored['occurrence_count']??0));
    }

    private static function readTopicPoolRows(): array {
        global $wpdb;
        $rows=$wpdb->get_results("SELECT * FROM ".self::table('topic_pool')." ORDER BY id ASC",ARRAY_A);
        if($rows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_PAYLOAD_REPAIR_POOL_REREAD_FAILED:'.self::dbError());
        return (array)$rows;
    }

    public static function repairInvalidTopicPayloads(): array {
        global $wpdb;
        $rows=$wpdb->get_results("SELECT * FROM ".self::table('topic_pool')." ORDER BY id ASC",ARRAY_A);
        if($rows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_PAYLOAD_REPAIR_POOL_READ_FAILED:'.self::dbError());
        $rows=(array)$rows;$invalid=[];$existingQuarantine=0;
        foreach($rows as $row){
            $payload=json_decode((string)($row['payload_json']??''),true);
            $isQuarantine=is_array($payload)&&json_last_error()===JSON_ERROR_NONE&&!empty($payload['recovery_quarantined']);
            if($isQuarantine){$existingQuarantine++;continue;}
            $query=is_array($payload)?trim((string)(($payload['raw_user_question']??'')!==''?$payload['raw_user_question']:($payload['canonical_query']??$payload['primary_longtail_query']??''))):'';
            $usable=is_array($payload)&&json_last_error()===JSON_ERROR_NONE&&$query!=='';
            $storedNormalized=(string)($row['normalized_key']??'');
            if($usable&&$storedNormalized!=='')$usable=hash_equals($storedNormalized,self::normalizedKeyForCandidate($payload));
            if(!$usable)$invalid[]=(string)($row['pool_key']??'');
        }
        if(!$invalid)return ['contract'=>'PSTE_TOPIC_PAYLOAD_REPAIR_V2','invalid_before'=>0,'repaired'=>0,'quarantined_new'=>0,'quarantined_total'=>$existingQuarantine,'invalid_after'=>0,'topic_pool_count'=>count($rows),'occurrences_added'=>0,'status'=>'NOT_REQUIRED'];
        $before=['topic_pool'=>self::countRows('topic_pool'),'candidates'=>self::countRows('candidates'),'occurrences'=>self::countRows('topic_occurrences'),'assignments'=>self::countRows('topic_assignments'),'history'=>self::countRows('topic_history')];
        self::beginTransaction();
        try{
            $repair=self::repairTopicPayloadsFromCandidates($rows);
            $persistedRows=self::readTopicPoolRows();
            $invalidAfter=[];$quarantinedTotal=0;
            foreach($persistedRows as $row){
                $payload=json_decode((string)($row['payload_json']??''),true);
                $isQuarantine=is_array($payload)&&json_last_error()===JSON_ERROR_NONE&&!empty($payload['recovery_quarantined']);
                if($isQuarantine){$quarantinedTotal++;continue;}
                $query=is_array($payload)?trim((string)(($payload['raw_user_question']??'')!==''?$payload['raw_user_question']:($payload['canonical_query']??$payload['primary_longtail_query']??''))):'';
                $usable=is_array($payload)&&json_last_error()===JSON_ERROR_NONE&&$query!=='';
                $storedNormalized=(string)($row['normalized_key']??'');
                if($usable&&$storedNormalized!=='')$usable=hash_equals($storedNormalized,self::normalizedKeyForCandidate($payload));
                if(!$usable)$invalidAfter[]=(string)($row['pool_key']??'');
            }
            $after=['topic_pool'=>self::countRows('topic_pool'),'candidates'=>self::countRows('candidates'),'occurrences'=>self::countRows('topic_occurrences'),'assignments'=>self::countRows('topic_assignments'),'history'=>self::countRows('topic_history')];
            foreach(['topic_pool','candidates','assignments','history'] as $field)if($before[$field]!==$after[$field])throw new RuntimeException('PSTE_PAYLOAD_REPAIR_COUNT_CHANGED_'.strtoupper($field));
            if($after['occurrences']<$before['occurrences'])throw new RuntimeException('PSTE_PAYLOAD_REPAIR_OCCURRENCE_COUNT_DECREASED');
            if($invalidAfter)throw new RuntimeException('PSTE_PAYLOAD_REPAIR_INCOMPLETE');
            $handled=(int)($repair['repaired']??0)+(int)($repair['quarantined']??0);
            if($handled!==count($invalid))throw new RuntimeException('PSTE_PAYLOAD_REPAIR_COUNT_MISMATCH');
            self::assertTopicRelationsConsistent();
            self::commitTransaction();
            return ['contract'=>'PSTE_TOPIC_PAYLOAD_REPAIR_V2','invalid_before'=>count($invalid),'repaired'=>(int)($repair['repaired']??0),'quarantined_new'=>(int)($repair['quarantined']??0),'quarantined_total'=>$quarantinedTotal,'quarantine_keys'=>(array)($repair['quarantine_keys']??[]),'invalid_candidate_rows'=>(int)($repair['invalid_candidate_rows']??0),'invalid_after'=>0,'topic_pool_count'=>count($rows),'occurrences_added'=>max(0,$after['occurrences']-$before['occurrences']),'status'=>'PASS'];
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
    }

    public static function saveRun(array $run): void {
        self::checkedReplace(self::table('runs'), [
            'run_uuid'=>$run['run_uuid'],'status'=>$run['status'],'category_id'=>(int)$run['category_id'],'seed'=>$run['seed'],
            'estimated_cost'=>(float)$run['estimated_cost'],'actual_cost'=>(float)$run['actual_cost'],
            'snapshot_json'=>self::encodeJsonValue($run['snapshot'],'PSTE_RUN_SNAPSHOT'),
            'payload_json'=>self::encodeJsonValue($run['payload'],'PSTE_RUN_PAYLOAD'),
            'created_at'=>$run['created_at'],'updated_at'=>$run['updated_at'],
        ], ['%s','%s','%d','%s','%f','%f','%s','%s','%s','%s'],'PSTE_RUN_SAVE_FAILED');
    }

    public static function saveCandidate(string $runUuid, array $candidate): void {
        self::beginTransaction();
        try{
            self::checkedReplace(self::table('candidates'), [
                'candidate_id'=>$candidate['candidate_id'],'run_uuid'=>$runUuid,'decision'=>$candidate['decision'],
                'reason_codes_json'=>self::encodeJsonValue($candidate['reason_codes'],'PSTE_CANDIDATE_REASON_CODES'),
                'payload_json'=>self::encodeJsonValue($candidate,'PSTE_CANDIDATE_PAYLOAD'),
            ], ['%s','%s','%s','%s','%s'],'PSTE_CANDIDATE_SAVE_FAILED');
            self::upsertTopicPool($runUuid,$candidate);
            self::assertTopicRelationsConsistent();
            self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
    }

    public static function normalizedKeyForCandidate(array $candidate): string {
        $query=(string)(($candidate['raw_user_question']??'')!==''?$candidate['raw_user_question']:($candidate['canonical_query']??$candidate['primary_longtail_query']??''));
        $identity=PSTE_Normalizer::exactTopicIdentityText($query);
        if($identity==='')$identity=(string)($candidate['candidate_id']??hash('sha256',wp_json_encode($candidate)));
        return hash('sha256',$identity);
    }

    public static function globalTopicKeyForCandidate(array $candidate): string {
        $normalized=self::normalizedKeyForCandidate($candidate);
        if(!isset($GLOBALS['wpdb']))return 'test-'.substr($normalized,0,31);
        global $wpdb;$table=self::table('topic_identity');
        $existing=(string)$wpdb->get_var($wpdb->prepare("SELECT topic_uuid FROM $table WHERE normalized_key=%s",$normalized));
        if($existing!=='')return $existing;
        $uuid=wp_generate_uuid4();
        $insert=self::checkedQuery($wpdb->prepare("INSERT IGNORE INTO $table (normalized_key,topic_uuid,created_at) VALUES (%s,%s,%s)",$normalized,$uuid,gmdate('Y-m-d H:i:s')),'PSTE_TOPIC_IDENTITY_INSERT_FAILED');
        if($insert===false)throw new RuntimeException('PSTE_TOPIC_IDENTITY_INSERT_FAILED:'.self::dbError());
        $resolved=(string)$wpdb->get_var($wpdb->prepare("SELECT topic_uuid FROM $table WHERE normalized_key=%s",$normalized));
        if($resolved==='')throw new RuntimeException('PSTE_TOPIC_IDENTITY_NOT_PERSISTED');
        return $resolved;
    }

    public static function poolKeyForCandidate(array $candidate): string { return self::globalTopicKeyForCandidate($candidate); }

    public static function automaticPoolStatus(array $candidate): string {
        $decision=(string)($candidate['decision']??'REVIEW_REQUIRED');
        $query=(string)($candidate['canonical_query']??$candidate['primary_longtail_query']??'');
        $type=(string)($candidate['proposed_article_type']??'');$reasons=(array)($candidate['reason_codes']??[]);
        $semantic=(array)($candidate['semantic_consensus']??[]);if($semantic&&empty($semantic['ok']))return 'DISCOVERY_ONLY';
        if(PSTE_Normalizer::staleYear($query)!==null||in_array('STALE_YEAR_SPECIFIC_QUERY',$reasons,true))return 'DISCOVERY_ONLY';
        if(array_intersect(PSTE_Topic_Policy::nonOverridableCodes(),$reasons))return 'REVIEW_REQUIRED';
        if(array_intersect(['CONFLICTING_TARGET_ASSIGNMENTS','GLOBAL_IDENTITY_MIGRATION_CONFLICT','MERGE_CANDIDATE_REVIEW_REQUIRED'], $reasons))return 'REVIEW_REQUIRED';
        $suggested=PSTE_Normalizer::suggestReassignmentType($query,$type);
        if(array_intersect(['EXACT_NORMALIZED_QUERY_DUPLICATE','SAME_INTENT_CLUSTER','CROSS_TYPE_ANSWER_EQUIVALENCE','CANONICAL_ARTICLE_OR_PLAN_SLOT_ALREADY_OWNED','ANSWER_EQUIVALENT_EXISTING','ANSWER_EQUIVALENT_PLANNED','EXACT_EDITORIAL_INTENT_VARIANT'], $reasons))return 'BLOCKED_FOR_CATEGORY';
        $editorial=(array)($candidate['editorialization']??[]);
        $editorialQuality=(array)($candidate['editorial_quality_gate']??[]);
        if(!empty($editorial['resolved'])){
            if(($editorialQuality['contract']??'')!=='PSTE_EDITORIAL_QUALITY_GATE_V4_HARD_TITLE_SURFACE_INTENT_SAFE'||($editorialQuality['status']??'')!=='PASS'||empty($editorialQuality['ok']))return 'REVIEW_REQUIRED';
            $targetName=(string)($candidate['suggested_category_name']??'');
            $targetId=(int)($candidate['suggested_category_id']??0);
            if($targetName!==''&&!empty(self::categoryForTypeAndFamilyKey((string)($editorial['article_type']??$candidate['suggested_article_type']??''),(string)($candidate['topic_family_key']??''))))return 'AUTO_RESOLVED';
            return 'REVIEW_REQUIRED';
        }
        if(PSTE_Normalizer::hasRecommendationOrSuperlative($query)&&$suggested!==''){
            $targetName=$suggested.' '.PSTE_Normalizer::categoryFamilyName((string)($candidate['target_category_name']??''));
            return !empty(self::categoryForTypeAndFamilyKey($suggested,(string)($candidate['topic_family_key']??'')))?'PROVISIONAL_REASSIGN':'REVIEW_REQUIRED';
        }
        if(in_array('CATEGORY_HEAD_INTENT_COLLISION',$reasons,true))return 'DISCOVERY_ONLY';
        if($type==='FAQ'&&PSTE_Normalizer::isNaturalYesNoQuestion((string)($candidate['primary_longtail_query']??$query)))return 'PROVISIONAL_ACCEPTED';
        if($decision==='PASS')return 'PASS';
        if($suggested!==''){
            $targetName=$suggested.' '.PSTE_Normalizer::categoryFamilyName((string)($candidate['target_category_name']??''));
            return !empty(self::categoryForTypeAndFamilyKey($suggested,(string)($candidate['topic_family_key']??'')))?'PROVISIONAL_REASSIGN':'REVIEW_REQUIRED';
        }
        if($decision==='REVIEW_REQUIRED')return 'PROVISIONAL_ACCEPTED';
        if(!empty($candidate['discovery_only']))return 'DISCOVERY_ONLY';
        return 'BLOCKED_FOR_CATEGORY';
    }

    public static function trafficLightForStatus(string $status,string $contextState='CURRENT'): array { return PSTE_Topic_Policy::trafficLight($status,$contextState); }

    public static function mergeCandidatePayload(array $old,array $new,string $runUuid,bool $replay=false): array {
        $merged=array_merge($old,$new);
        if(!empty($old['recovery_quarantined'])){
            foreach(['recovery_quarantined','recovery_error_code','recovery_normalized_key'] as $field)unset($merged[$field]);
            if(is_array($merged['portal_context']??null)&&(string)($merged['portal_context']['error_code']??'')==='PSTE_PAYLOAD_RECOVERY_SOURCE_MISSING')$merged['portal_context']=[];
            $merged['reason_codes']=array_values(array_diff((array)($merged['reason_codes']??[]),['PSTE_TOPIC_PAYLOAD_CORRUPTED','PSTE_PAYLOAD_RECOVERY_SOURCE_MISSING']));
            $merged['textmachine_handoff_status']='BLOCKED_BEFORE_COMPILER';
            $merged['reason_codes']=array_values(array_unique(array_merge((array)($merged['reason_codes']??[]),['PSTE_RECOVERY_REQUIRES_CURRENT_NORMAL_PATH'])));
        }
        $query=(string)(($new['raw_user_question']??'')!==''?$new['raw_user_question']:($new['primary_longtail_query']??$new['canonical_query']??''));
        // Raw research identity is never editorially rewritten during merge.
        $merged['canonical_query']=trim((string)($old['canonical_query']??''))!==''?(string)$old['canonical_query']:$query;
        if(trim((string)$merged['canonical_query'])==='')$merged['canonical_query']=$query;
        $merged['reason_codes']=array_values(array_unique((array)($merged['reason_codes']??[])));
        $merged['global_topic_identity_text']=PSTE_Normalizer::exactTopicIdentityText((string)$merged['canonical_query']);
        $merged['semantic_fingerprint']=PSTE_Normalizer::semanticFingerprint((string)$merged['canonical_query']);
        $merged['normalized_key']=hash('sha256',$merged['global_topic_identity_text']);

        $aliases=[];
        foreach(array_merge((array)($old['aliases']??[]),[(string)($new['primary_longtail_query']??''),(string)($new['raw_user_question']??'')]) as $alias){
            $alias=trim((string)$alias);if($alias==='')continue;$aliases[PSTE_Normalizer::exactTopicIdentityText($alias)."|".$alias]=$alias;
        }
        $merged['aliases']=array_values($aliases);

        // Preserve every raw keyword/alias across the full lifetime of this topic.
        // A later research run may add evidence, but may never replace older raw phrases.
        $queryAliases=[];
        foreach(array_merge((array)($old['query_aliases']??[]),(array)($new['query_aliases']??[])) as $aliasRow){
            if(!is_array($aliasRow))continue;$raw=trim((string)($aliasRow['raw_query']??''));if($raw==='')continue;
            $key=hash('sha256',$raw);if(!isset($queryAliases[$key]))$queryAliases[$key]=$aliasRow;
            else{
                $existingSources=array_values(array_unique(array_map('strval',(array)($queryAliases[$key]['source_names']??[]))));
                $newSources=array_values(array_unique(array_map('strval',(array)($aliasRow['source_names']??[]))));
                $queryAliases[$key]['source_names']=array_values(array_unique(array_merge($existingSources,$newSources)));
                $existingObs=array_values(array_unique(array_map('strval',(array)($queryAliases[$key]['observation_ids']??[]))));
                $newObs=array_values(array_unique(array_map('strval',(array)($aliasRow['observation_ids']??[]))));
                $queryAliases[$key]['observation_ids']=array_values(array_unique(array_merge($existingObs,$newObs)));
            }
        }
        foreach([(string)($old['canonical_query']??''),(string)($new['canonical_query']??''),(string)($new['primary_longtail_query']??''),(string)($new['raw_user_question']??'')] as $raw){
            $raw=trim($raw);if($raw==='')continue;$key=hash('sha256',$raw);if(!isset($queryAliases[$key]))$queryAliases[$key]=['raw_query'=>$raw,'normalized_query'=>PSTE_Normalizer::text($raw),'language_corrected_query'=>$raw,'relation_to_canonical'=>'PRESERVED_RAW','source_names'=>[],'volume_status'=>'UNAVAILABLE','search_volume'=>null,'observation_ids'=>[]];
        }
        $merged['query_aliases']=array_values($queryAliases);

        $evidence=[];
        foreach(array_merge((array)($old['evidence']??[]),(array)($new['evidence']??[])) as $item){
            if(!is_array($item))continue;$k=hash('sha256',(string)($item['source']??'').'|'.(string)($item['raw_value']??'').'|'.(string)($item['raw_response_sha256']??''));$evidence[$k]=$item;
        }
        $merged['evidence']=array_values($evidence);
        $merged['seen_in_runs']=array_values(array_unique(array_filter(array_merge((array)($old['seen_in_runs']??[]),[$runUuid]))));
        $merged['candidate_ids']=array_values(array_unique(array_filter(array_merge((array)($old['candidate_ids']??[]),[(string)($new['candidate_id']??'')]))));

        $categories=[];
        foreach((array)($old['found_categories']??[]) as $cat){
            if(!is_array($cat))continue;
            $actualType=PSTE_Normalizer::categoryArticleType((string)($cat['category_name']??''));
            $storedType=(string)($cat['article_type']??'');
            $cat['historical_legacy']=$actualType!==''&&$storedType!==''&&$actualType!==$storedType;
            $k=(string)($cat['category_id']??0).'|'.(string)($cat['category_name']??'').'|'.$storedType;
            $categories[$k]=$cat;
        }
        $catId=(int)($new['target_category_id']??0);$catName=(string)($new['target_category_name']??'');$catType=(string)($new['proposed_article_type']??'');$catKey=$catId.'|'.$catName.'|'.$catType;
        $prior=$categories[$catKey]??[];
        $categories[$catKey]=[
            'category_id'=>$catId,'category_name'=>$catName,'category_slug'=>(string)($new['target_category_slug']??''),
            'article_type'=>$catType,'topic_family_key'=>(string)($new['topic_family_key']??''),
            'historical_legacy'=>false,'first_run_uuid'=>(string)($prior['first_run_uuid']??$runUuid),'last_run_uuid'=>$runUuid,'occurrence_count'=>(int)($prior['occurrence_count']??0)+($replay?0:1),
        ];
        $merged['found_categories']=array_values($categories);

        $familyKey=(string)($merged['topic_family_key']??$new['topic_family_key']??'');
        if(empty($merged['available_article_types']))$merged['available_article_types']=self::availableTypesForFamilyKey($familyKey);
        // Exactly one current release authority: every legacy/recovery/stale record must pass
        // the shared relevance-first normal path. Historical derived state is evidence only.
        $merged=PSTE_Editorializer::apply($merged);
        $merged['portal_context']=is_array($old['portal_context']??null)?$old['portal_context']:[];
        $merged['context_state']=(string)($old['context_state']??'PENDING');
        $merged['global_identity_scope']='PORTAL_WIDE';
        return $merged;
    }

    public static function categoryIdFromName(string $name): int { return self::categoryIdByName($name); }

    private static function categoryIdByName(string $name): int {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$matches=[];
        foreach((is_array($baseline)?($baseline['leaf_categories']??[]):[]) as $cat){
            $a=trim((string)($cat['name']??''));$b=trim($name);$a=function_exists('mb_strtolower')?mb_strtolower($a,'UTF-8'):strtolower($a);$b=function_exists('mb_strtolower')?mb_strtolower($b,'UTF-8'):strtolower($b);
            if($a===$b)$matches[(int)($cat['term_id']??0)]=(int)($cat['term_id']??0);
        }
        return count($matches)===1?(int)reset($matches):0;
    }

    /** @return array<string,mixed> */
    private static function categoryForTypeAndFamilyKey(string $type,string $familyKey): array {
        $type=trim($type);$familyKey=trim($familyKey);if($type===''||$familyKey==='')return [];
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$matches=[];
        foreach((is_array($baseline)?($baseline['leaf_categories']??[]):[]) as $cat){
            if(!is_array($cat))continue;
            $catType=(string)($cat['article_type']??PSTE_Normalizer::categoryArticleType((string)($cat['name']??'')));
            $catKey=(string)($cat['topic_family_key']??'');
            if($catType===$type&&$catKey===$familyKey)$matches[]=$cat;
        }
        return count($matches)===1?$matches[0]:[];
    }

    /** @return list<string> */
    private static function availableTypesForFamilyKey(string $familyKey): array {
        $familyKey=trim($familyKey);if($familyKey==='')return [];$types=[];
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        foreach((is_array($baseline)?($baseline['leaf_categories']??[]):[]) as $cat){
            if(!is_array($cat)||(string)($cat['topic_family_key']??'')!==$familyKey)continue;
            $type=(string)($cat['article_type']??PSTE_Normalizer::categoryArticleType((string)($cat['name']??'')));
            if($type!=='')$types[$type]=true;
        }
        $out=array_keys($types);sort($out,SORT_STRING);return $out;
    }

    private static function categoryNameById(int $categoryId): string {
        if($categoryId<=0)return '';
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        foreach((is_array($baseline)?($baseline['leaf_categories']??[]):[]) as $cat)if((int)($cat['term_id']??0)===$categoryId)return (string)($cat['name']??'');
        return '';
    }

    private static function categorySlugById(int $categoryId): string {
        if($categoryId<=0)return '';
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        foreach((is_array($baseline)?($baseline['leaf_categories']??[]):[]) as $cat)if((int)($cat['term_id']??0)===$categoryId)return (string)($cat['slug']??'');
        return '';
    }

    private static function occurrenceKey(string $topicKey,string $runUuid,array $candidate): string {
        return hash('sha256',$topicKey.'|'.$runUuid.'|'.(string)($candidate['candidate_id']??'').'|'.(int)($candidate['target_category_id']??0));
    }

    private static function occurrenceExists(string $topicKey,string $runUuid,array $candidate): bool {
        global $wpdb;$table=self::table('topic_occurrences');$key=self::occurrenceKey($topicKey,$runUuid,$candidate);
        return (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE occurrence_key=%s",$key))===1;
    }

    private static function upsertTopicOccurrence(string $topicKey,string $runUuid,array $candidate): void {
        global $wpdb;$table=self::table('topic_occurrences');$now=gmdate('Y-m-d H:i:s');
        $occurrenceKey=self::occurrenceKey($topicKey,$runUuid,$candidate);
        $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE occurrence_key=%s",$occurrenceKey),ARRAY_A);
        $actualType=PSTE_Normalizer::categoryArticleType((string)($candidate['target_category_name']??''));
        $foundType=(string)($candidate['proposed_article_type']??'');
        $payload=['decision'=>(string)($candidate['decision']??''),'reason_codes'=>(array)($candidate['reason_codes']??[]),'evidence_sources'=>array_values(array_unique(array_filter(array_map(static fn($e)=>(string)($e['source']??''),(array)($candidate['evidence']??[]))))),'search_volume'=>$candidate['metrics']['search_volume']??null,'intent'=>(string)($candidate['metrics']['search_intent']??''),'historical_legacy'=>$actualType!==''&&$foundType!==''&&$actualType!==$foundType];
        $encodedPayload=self::encodeJsonValue($payload,'PSTE_OCCURRENCE_PAYLOAD');
        if(!$existing){
            $expectedCount=1;
            self::checkedInsert($table,['occurrence_key'=>$occurrenceKey,'topic_key'=>$topicKey,'run_uuid'=>$runUuid,'candidate_id'=>(string)($candidate['candidate_id']??''),'found_category_id'=>(int)($candidate['target_category_id']??0),'found_category_name'=>(string)($candidate['target_category_name']??''),'found_article_type'=>$foundType,'payload_json'=>$encodedPayload,'occurrence_count'=>$expectedCount,'first_seen_at'=>$now,'last_seen_at'=>$now],['%s','%s','%s','%s','%d','%s','%s','%s','%d','%s','%s'],'PSTE_OCCURRENCE_INSERT_FAILED');
        }else{
            // Replaying the same run/candidate during FINALIZE resume is idempotent.
            // It updates the audit payload but never counts the same occurrence twice.
            $expectedCount=max(1,(int)($existing['occurrence_count']??1));
            self::checkedUpdate($table,['payload_json'=>$encodedPayload,'last_seen_at'=>$now],['occurrence_key'=>$occurrenceKey],['%s','%s'],['%s'],'PSTE_OCCURRENCE_UPDATE_FAILED');
        }
        self::assertOccurrencePayloadPersisted($occurrenceKey,$encodedPayload,$expectedCount,'PSTE_OCCURRENCE_PAYLOAD');
    }

    private static function topicOccurrenceCount(string $topicKey): int {
        global $wpdb;$table=self::table('topic_occurrences');
        $value=$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(occurrence_count),0) FROM $table WHERE topic_key=%s",$topicKey));
        if($value===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_OCCURRENCE_COUNT_READ_FAILED:'.self::dbError());
        return max(0,(int)$value);
    }

    private static function upsertTopicAssignment(string $topicKey,int $categoryId,string $categoryName,string $articleType,string $source,string $status,float $confidence,array $reasons,array $payload=[]): void {
        global $wpdb;$table=self::table('topic_assignments');$now=gmdate('Y-m-d H:i:s');
        $assignmentKey=hash('sha256',$topicKey.'|'.$categoryId.'|'.$articleType.'|'.$source);$existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE assignment_key=%s",$assignmentKey),ARRAY_A);
        $row=['topic_key'=>$topicKey,'category_id'=>$categoryId,'category_name'=>$categoryName,'article_type'=>$articleType,'assignment_source'=>$source,'assignment_status'=>$status,'confidence'=>max(0,min(1,$confidence)),'reason_codes_json'=>self::encodeJsonValue(array_values(array_unique($reasons)),'PSTE_ASSIGNMENT_REASON_CODES'),'payload_json'=>self::encodeJsonValue($payload,'PSTE_TOPIC_PAYLOAD'),'last_seen_at'=>$now];
        if(!$existing){$row['assignment_key']=$assignmentKey;$row['first_seen_at']=$now;self::checkedInsert($table,$row,['%s','%d','%s','%s','%s','%s','%f','%s','%s','%s','%s','%s'],'PSTE_ASSIGNMENT_INSERT_FAILED');}
        else{self::checkedUpdate($table,$row,['assignment_key'=>$assignmentKey],['%s','%d','%s','%s','%s','%s','%f','%s','%s','%s'],['%s'],'PSTE_ASSIGNMENT_UPDATE_FAILED');}
    }

    private static function upsertTopicPool(string $runUuid,array $candidate): void {
        global $wpdb;$table=self::table('topic_pool');$key=self::globalTopicKeyForCandidate($candidate);$normalized=self::normalizedKeyForCandidate($candidate);$now=gmdate('Y-m-d H:i:s');
        $existing=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE pool_key=%s",$key),ARRAY_A);
        $replay=is_array($existing)&&self::occurrenceExists($key,$runUuid,$candidate);
        $oldPayload=[];
        if($existing){
            $oldPayload=json_decode((string)($existing['payload_json']??''),true);
            if(!is_array($oldPayload)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException('PSTE_TOPIC_POOL_EXISTING_PAYLOAD_INVALID');
        }
        $payload=self::mergeCandidatePayload($oldPayload,$candidate,$runUuid,$replay);$automatic=self::automaticPoolStatus($payload);$payload['automatic_pool_status']=$automatic;
        $role=PSTE_Topic_Policy::classifyRole($payload);$contextState='PENDING';$planning=PSTE_Topic_Policy::planningSuitability(array_merge($payload,['topic_role'=>$role]),$automatic,$contextState);
        $structure=(array)get_option(PSTE_OPTION_SITE_BASELINE,[]);$structureHash=(string)($structure['structure_sha256']??'');
        $payload['topic_role']=$role;$payload['planning_suitability']=$planning;$payload['context_state']=$contextState;
        $encodedPayload=self::encodeJsonValue($payload,'PSTE_TOPIC_POOL_PAYLOAD');
        if(!$existing){
            self::insertTopicPoolRow($table,['pool_key'=>$key,'normalized_key'=>$normalized,'candidate_id'=>(string)($candidate['candidate_id']??''),'first_run_uuid'=>$runUuid,'last_run_uuid'=>$runUuid,'original_category_id'=>(int)($candidate['target_category_id']??0),'current_category_id'=>(int)($candidate['target_category_id']??0),'automatic_decision'=>(string)($candidate['decision']??'REVIEW_REQUIRED'),'automatic_pool_status'=>$automatic,'topic_role'=>$role,'planning_suitability'=>$planning,'context_state'=>$contextState,'structure_sha256'=>$structureHash,'manual_status'=>'','manual_category_id'=>0,'manual_article_type'=>'','manual_note'=>'','payload_json'=>$encodedPayload,'occurrence_count'=>1,'first_seen_at'=>$now,'last_seen_at'=>$now,'reviewed_by'=>0],'PSTE_TOPIC_POOL_INSERT_FAILED');
            if((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE pool_key=%s",$key))!==1)throw new RuntimeException('PSTE_TOPIC_POOL_INSERT_NOT_PERSISTED');
            self::recordTopicHistory($key,'GLOBAL_TOPIC_DISCOVERED','',$automatic,['run_uuid'=>$runUuid,'candidate_id'=>$candidate['candidate_id']??'','category_id'=>$candidate['target_category_id']??0,'normalized_key'=>$normalized],0);
        }else{
            $from=(string)$existing['automatic_pool_status'];$currentCategory=(int)$existing['current_category_id'];if($currentCategory<=0)$currentCategory=(int)($candidate['target_category_id']??0);
            $provisionalCount=max(1,(int)$existing['occurrence_count']+($replay?0:1));
            self::updateTopicPoolRow($table,$key,['normalized_key'=>$normalized,'candidate_id'=>(string)($candidate['candidate_id']??''),'last_run_uuid'=>$runUuid,'automatic_decision'=>(string)($candidate['decision']??'REVIEW_REQUIRED'),'automatic_pool_status'=>$automatic,'topic_role'=>$role,'planning_suitability'=>$planning,'context_state'=>$contextState,'structure_sha256'=>$structureHash,'context_synced_at'=>null,'current_category_id'=>$currentCategory,'payload_json'=>$encodedPayload,'occurrence_count'=>$provisionalCount,'last_seen_at'=>$now],'PSTE_TOPIC_POOL_UPDATE_FAILED');
            if($from!==$automatic)self::recordTopicHistory($key,'AUTOMATIC_REEVALUATION',$from,$automatic,['run_uuid'=>$runUuid],0);
        }
        self::assertTopicPayloadPersisted($key,$encodedPayload,'PSTE_TOPIC_POOL_PAYLOAD');
        self::upsertTopicOccurrence($key,$runUuid,$candidate);
        $aggregateCount=self::topicOccurrenceCount($key);
        if($aggregateCount<1)throw new RuntimeException('PSTE_TOPIC_POOL_OCCURRENCE_AGGREGATE_EMPTY');
        self::checkedUpdate($table,['occurrence_count'=>$aggregateCount],['pool_key'=>$key],['%d'],['%s'],'PSTE_TOPIC_POOL_OCCURRENCE_SYNC_FAILED');
        if((int)($candidate['target_category_id']??0)>0){self::upsertTopicAssignment($key,(int)$candidate['target_category_id'],(string)($candidate['target_category_name']??''),(string)($candidate['proposed_article_type']??''),'FOUND_IN_CATEGORY','OBSERVED',1.0,['DISCOVERY_ORIGIN'],['run_uuid'=>$runUuid]);}
        if((int)($payload['suggested_category_id']??0)>0){$assignmentStatus=$automatic==='PROVISIONAL_REASSIGN'?'PROVISIONAL_ACCEPTED':'SUGGESTED';self::upsertTopicAssignment($key,(int)$payload['suggested_category_id'],(string)$payload['suggested_category_name'],(string)($payload['suggested_article_type']??''),'AUTOMATIC_REASSIGNMENT',$assignmentStatus,0.75,['ARTICLE_TYPE_SIGNAL'],['run_uuid'=>$runUuid,'production_release'=>false]);}
        self::recordSemanticMergeCandidates($key,$payload);
    }

    public static function backfillTopicPool(): void { self::migrateOrRepairTopicIdentity(); }

    public static function migrateTopicPoolToGlobal(): void { self::migrateTopicIdentityToUuid(); }

    public static function migrateTopicIdentityToUuid(): void { self::migrateOrRepairTopicIdentity(); }

    /**
     * Rebuilds the normal editorial metadata and semantic consensus for every
     * non-quarantined topic already stored in the plugin's own topic pool.
     * No provider request is made. No post, term, URL, Yoast field, design
     * component or production-machine file is read for writing or modified.
     *
     * @return array<string,mixed>
     */
    public static function reclassifyTopicPool(): array {
        global $wpdb;
        $rows=$wpdb->get_results("SELECT * FROM ".self::table('topic_pool')." ORDER BY id ASC",ARRAY_A)?:[];
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SEMANTIC_BACKFILL_BASELINE_REQUIRED');
        $registry=PSTE_Article_Type_Registry::build($baseline);
        if(empty($registry['registry_sha256']))throw new RuntimeException('PSTE_SEMANTIC_BACKFILL_REGISTRY_INVALID');
        $report=[
            'contract'=>'PSTE_SEMANTIC_BACKFILL_V2',
            'scanned'=>count($rows),'reclassified'=>0,'consensus_pass'=>0,'consensus_review'=>0,
            'query_missing'=>0,'family_missing'=>0,'quarantined_skipped'=>0,'unchanged'=>0,
            'provider_requests'=>0,'write_scope'=>'PSTE_OWN_TOPIC_POOL_ONLY',
            'article_or_taxonomy_write_attempted'=>false,'production_machine_write_attempted'=>false,
            'registry_sha256'=>(string)$registry['registry_sha256'],'items'=>[],
        ];
        self::beginTransaction();
        try{
            foreach($rows as $row){
                $poolKey=(string)($row['pool_key']??'');
                $payload=json_decode((string)($row['payload_json']??''),true);
                if(!is_array($payload))throw new RuntimeException('PSTE_RECLASSIFY_PAYLOAD_INVALID');
                if(!empty($payload['recovery_quarantined'])){
                    $payload['automatic_pool_status']='REVIEW_REQUIRED';$payload['topic_role']=PSTE_Topic_Policy::ROLE_NON_EDITORIAL;$payload['planning_suitability']='BLOCKED';$payload['context_state']='BLOCKED';
                    self::checkedUpdate(self::table('topic_pool'),['automatic_decision'=>'BLOCKED','automatic_pool_status'=>'REVIEW_REQUIRED','topic_role'=>PSTE_Topic_Policy::ROLE_NON_EDITORIAL,'planning_suitability'=>'BLOCKED','context_state'=>'BLOCKED','payload_json'=>self::encodeJsonValue($payload,'PSTE_RECLASSIFY_QUARANTINE_PAYLOAD')],['pool_key'=>$poolKey],['%s','%s','%s','%s','%s','%s'],['%s'],'PSTE_RECLASSIFY_QUARANTINE_UPDATE_FAILED');
                    $report['quarantined_skipped']++;
                    continue;
                }

                $beforeSemantic=self::encodeJsonValue((array)($payload['semantic_consensus']??[]),'PSTE_SEMANTIC_BACKFILL_BEFORE');
                // Historical backfill now uses the same relevance-first normal metadata path as live research and reentry.
                $payload=self::prepareEditorialPayload($payload);$semantic=(array)($payload['semantic_consensus']??[]);
                $query=PSTE_Editorializer::sourceQuery($payload);$familyKey=(string)($payload['topic_family_key']??'');
                $semanticReasons=(array)($semantic['reason_codes']??[]);
                if(in_array('PSTE_SEMANTIC_QUERY_MISSING',$semanticReasons,true))$report['query_missing']++;
                if(in_array('PSTE_SEMANTIC_FAMILY_REGISTRY_MISSING',$semanticReasons,true))$report['family_missing']++;

                $automatic=self::automaticPoolStatus($payload);$payload['automatic_pool_status']=$automatic;
                $role=PSTE_Topic_Policy::classifyRole($payload);$context=(string)($row['context_state']??'PENDING');
                $planning=PSTE_Topic_Policy::planningSuitability(array_merge($payload,['topic_role'=>$role]),$automatic,$context);
                $payload['topic_role']=$role;$payload['planning_suitability']=$planning;$payload['context_state']=$context;
                $encoded=self::encodeJsonValue($payload,'PSTE_RECLASSIFY_PAYLOAD');
                self::checkedUpdate(self::table('topic_pool'),[
                    'automatic_pool_status'=>$automatic,'topic_role'=>$role,'planning_suitability'=>$planning,
                    'current_category_id'=>(int)($payload['target_category_id']??$row['current_category_id']??0),'payload_json'=>$encoded,
                ],['pool_key'=>$poolKey],['%s','%s','%s','%d','%s'],['%s'],'PSTE_RECLASSIFY_UPDATE_FAILED');
                self::assertTopicPayloadPersisted($poolKey,$encoded,'PSTE_SEMANTIC_BACKFILL_PAYLOAD');

                $afterSemantic=self::encodeJsonValue((array)$semantic,'PSTE_SEMANTIC_BACKFILL_AFTER');
                if(hash_equals(hash('sha256',$beforeSemantic),hash('sha256',$afterSemantic)))$report['unchanged']++;
                else $report['reclassified']++;
                if(!empty($semantic['ok']))$report['consensus_pass']++;else $report['consensus_review']++;
                $report['items'][]=[
                    'pool_key'=>$poolKey,'candidate_id'=>(string)($row['candidate_id']??''),
                    'query_sha256'=>$query!==''?hash('sha256',$query):'','family_key'=>$familyKey,
                    'semantic_status'=>(string)($semantic['status']??''),'reason_codes'=>array_values((array)($semantic['reason_codes']??[])),
                ];
            }
            self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
        $report['report_sha256']=hash('sha256',self::encodeJsonValue($report,'PSTE_SEMANTIC_BACKFILL_REPORT'));
        update_option(PSTE_OPTION_SEMANTIC_BACKFILL_REPORT,$report,false);
        $stored=get_option(PSTE_OPTION_SEMANTIC_BACKFILL_REPORT,[]);
        if(!is_array($stored)||!hash_equals((string)$report['report_sha256'],(string)($stored['report_sha256']??'')))throw new RuntimeException('PSTE_SEMANTIC_BACKFILL_REPORT_NOT_PERSISTED');
        return $report;
    }


    /**
     * One-time, narrowly scoped repair for persisted price-intent longtails.
     * Only the plugin's own pste_topic_pool, pste_topic_assignments and history are updated.
     * Posts, postmeta, terms, URLs, Yoast data and the production machine are
     * never read for writing and are never modified.
     *
     * @return array<string,mixed>
     */
    public static function repairPriceIntentCandidates(): array {
        global $wpdb;
        $rows=$wpdb->get_results("SELECT * FROM ".self::table('topic_pool')." ORDER BY id ASC",ARRAY_A)?:[];
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        $registry=PSTE_Article_Type_Registry::build($baseline);
        if(empty($registry['registry_sha256']))throw new RuntimeException('PSTE_PRICE_INTENT_REPAIR_REGISTRY_INVALID');
        $report=['contract'=>'PSTE_PRICE_INTENT_REPAIR_V2','scanned'=>count($rows),'matched'=>0,'repaired'=>0,'unchanged'=>0,'blocked'=>0,'invalid_payload'=>0,'quarantined_skipped'=>0,'blocked_items'=>[],'repaired_pool_keys'=>[],'context_refresh_pool_keys'=>[],'write_scope'=>'PSTE_OWN_TABLES_ONLY','candidate_isolation'=>'BLOCKED_SINGLE_CANDIDATE_NEVER_ROLLS_BACK_OTHER_VALID_CANDIDATES'];
        self::beginTransaction();
        try{
            foreach($rows as $row){
                $poolKey=(string)($row['pool_key']??'');
                $payload=json_decode((string)($row['payload_json']??''),true);
                if(!is_array($payload)){
                    $report['blocked']++;
                    $report['invalid_payload']++;
                    $report['blocked_items'][]=['pool_key'=>$poolKey,'candidate_id'=>(string)($row['candidate_id']??''),'query'=>'','query_sha256'=>'','reason_code'=>'PSTE_PRICE_INTENT_REPAIR_PAYLOAD_INVALID','row_unchanged'=>true];
                    continue;
                }
                if(!empty($payload['recovery_quarantined'])){$report['quarantined_skipped']++;continue;}
                $query=PSTE_Editorializer::sourceQuery($payload);
                if(!preg_match('/\b(günstig\w*|guenstig\w*|billig\w*|preiswert\w*)\b/iu',$query))continue;
                $report['matched']++;
                $beforeType=(string)($payload['suggested_article_type']??$payload['proposed_article_type']??'');
                $beforeCategory=(int)($payload['target_category_id']??$row['current_category_id']??0);
                $beforeTitle=(string)($payload['editorial_title']??'');
                $prepared=self::prepareEditorialPayload($payload);
                $afterType=(string)($prepared['suggested_article_type']??$prepared['proposed_article_type']??'');
                $afterCategory=(int)($prepared['target_category_id']??0);
                $afterTitle=(string)($prepared['editorial_title']??'');
                $familyKey=(string)($prepared['topic_family_key']??'');
                $semantic=PSTE_Semantic_Classifier::classify($query,null,$registry,$familyKey);
                $semanticCategory=(array)($semantic['resolved_category']??[]);
                if($afterType!=='Kosten'||$afterCategory<=0||empty($prepared['editorialization']['resolved'])||empty($semantic['ok'])
                    ||(string)($semantic['resolved_article_type']??'')!=='Kosten'||(int)($semanticCategory['term_id']??0)!==$afterCategory){
                    $report['blocked']++;
                    $report['blocked_items'][]=['pool_key'=>$poolKey,'candidate_id'=>(string)($row['candidate_id']??''),'query'=>$query,'query_sha256'=>hash('sha256',$query),'reason_code'=>'PSTE_PRICE_INTENT_REPAIR_TARGET_NOT_UNIQUELY_RESOLVED','before_article_type'=>$beforeType,'before_category_id'=>$beforeCategory,'proposed_article_type'=>$afterType,'proposed_category_id'=>$afterCategory,'semantic_article_type'=>(string)($semantic['resolved_article_type']??''),'semantic_category_id'=>(int)($semanticCategory['term_id']??0),'semantic_reason_codes'=>array_values((array)($semantic['reason_codes']??[])),'row_unchanged'=>true];
                    continue;
                }
                $beforeSemantic=wp_json_encode((array)($payload['semantic_consensus']??[]),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
                $afterSemantic=wp_json_encode($semantic,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
                $semanticSame=is_string($beforeSemantic)&&is_string($afterSemantic)&&hash_equals(hash('sha256',$beforeSemantic),hash('sha256',$afterSemantic));
                $beforeProductionTitle=(string)($payload['production_title']??'');
                $prepared['semantic_consensus']=$semantic;
                $prepared['article_type_registry_sha256']=(string)$registry['registry_sha256'];
                $prepared['production_title']=$afterTitle;
                if($beforeType===$afterType&&$beforeCategory===$afterCategory&&$beforeTitle===$afterTitle&&$beforeProductionTitle===$afterTitle&&$semanticSame){
                    $report['unchanged']++;
                    if(!in_array((string)($row['context_state']??'PENDING'),['CURRENT','NOT_REQUIRED'],true))$report['context_refresh_pool_keys'][]=(string)$row['pool_key'];
                    continue;
                }
                if(trim((string)($row['manual_status']??''))!==''){
                    $report['blocked']++;
                    $report['blocked_items'][]=['pool_key'=>$poolKey,'candidate_id'=>(string)($row['candidate_id']??''),'query'=>$query,'query_sha256'=>hash('sha256',$query),'reason_code'=>'PSTE_PRICE_INTENT_REPAIR_MANUAL_DECISION_PRESENT','manual_status'=>(string)$row['manual_status'],'row_unchanged'=>true];
                    continue;
                }
                $automatic=self::automaticPoolStatus($prepared);
                $prepared['automatic_pool_status']=$automatic;
                $role=PSTE_Topic_Policy::classifyRole($prepared);
                $context='PENDING';
                $planning=PSTE_Topic_Policy::planningSuitability(array_merge($prepared,['topic_role'=>$role]),$automatic,$context);
                $prepared['topic_role']=$role;$prepared['planning_suitability']=$planning;$prepared['context_state']=$context;
                self::checkedUpdate(self::table('topic_pool'),[
                    'automatic_pool_status'=>$automatic,
                    'topic_role'=>$role,
                    'planning_suitability'=>$planning,
                    'context_state'=>$context,
                    'context_synced_at'=>null,
                    'current_category_id'=>$afterCategory,
                    'payload_json'=>self::encodeJsonValue($prepared,'PSTE_PRICE_INTENT_REPAIR_PAYLOAD'),
                ],['pool_key'=>(string)$row['pool_key']],['%s','%s','%s','%s','%s','%d','%s'],['%s'],'PSTE_PRICE_INTENT_REPAIR_UPDATE_FAILED');
                self::upsertTopicAssignment((string)$row['pool_key'],$afterCategory,(string)($prepared['target_category_name']??''),$afterType,'PRICE_INTENT_REPAIR','CONFIRMED',1.0,['PRICE_INTENT_DETERMINISTIC_RECLASSIFICATION'],[
                    'query_sha256'=>hash('sha256',$query),
                    'plugin_version'=>defined('PSTE_VERSION')?PSTE_VERSION:'0.10.10-staging',
                    'production_release'=>false,
                ]);
                self::recordTopicHistory((string)$row['pool_key'],'PRICE_INTENT_REPAIR_0110',$beforeType,$afterType,[
                    'query_sha256'=>hash('sha256',$query),
                    'before_category_id'=>$beforeCategory,
                    'after_category_id'=>$afterCategory,
                    'before_title_sha256'=>hash('sha256',$beforeTitle),
                    'after_title_sha256'=>hash('sha256',$afterTitle),
                    'write_scope'=>'PSTE_OWN_TABLES_ONLY',
                ],0);
                $report['repaired']++;
                $report['repaired_pool_keys'][]=(string)$row['pool_key'];
                $report['context_refresh_pool_keys'][]=(string)$row['pool_key'];
            }
            self::assertTopicRelationsConsistent();
            self::commitTransaction();
            $resolved=(int)$report['repaired']+(int)$report['unchanged'];
            $report['status']=(int)$report['blocked']===0?'PASS':($resolved>0?'PARTIAL_PASS':'BLOCKED');
            $report['report_sha256']=hash('sha256',wp_json_encode($report,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION));
            return $report;
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
    }

    /** Initialize the schema-independent, request-bounded topic payload integrity pass. @return array<string,mixed> */
    public static function topicPayloadIntegrityInitialize(string $jobUuid): array {
        $jobUuid=trim($jobUuid);if($jobUuid==='')throw new RuntimeException('PSTE_PAYLOAD_INTEGRITY_JOB_UUID_REQUIRED');$baseline=self::migrationBaseline();
        return ['contract'=>'PSTE_TOPIC_PAYLOAD_INTEGRITY_INIT_V1','job_uuid'=>$jobUuid,'topic_count'=>(int)($baseline['topic_pool']??0),'baseline'=>$baseline,'write_scope'=>'PSTE_OWN_TOPIC_DOMAIN_ONLY','production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'textmachine_or_design_write_attempted'=>false];
    }

    /**
     * Validate/repair at most $limit topic payloads. Local payload defects are healed from immutable candidate evidence
     * or quarantined; DB/storage failures still abort globally. The stable id ordering makes cursor replay deterministic.
     * @return array<string,mixed>
     */
    public static function topicPayloadIntegrityBatch(int $cursor,int $limit,string $jobUuid): array {
        $cursor=max(0,$cursor);$limit=max(1,min(25,$limit));$jobUuid=trim($jobUuid);if($jobUuid==='')throw new RuntimeException('PSTE_PAYLOAD_INTEGRITY_JOB_UUID_REQUIRED');global $wpdb;$table=self::table('topic_pool');$total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");$rows=$wpdb->get_results("SELECT * FROM $table ORDER BY id ASC LIMIT ".(int)$limit." OFFSET ".(int)$cursor,ARRAY_A);if($rows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_PAYLOAD_INTEGRITY_BATCH_READ_FAILED:'.self::dbError());$processed=0;$repaired=0;$quarantined=0;$unchanged=0;
        self::beginTransaction();
        try{
            foreach((array)$rows as $row){
                $payload=json_decode((string)($row['payload_json']??''),true);$isQuarantine=is_array($payload)&&json_last_error()===JSON_ERROR_NONE&&!empty($payload['recovery_quarantined']);$usable=$isQuarantine;
                if(!$isQuarantine&&is_array($payload)&&json_last_error()===JSON_ERROR_NONE){$query=trim((string)(($payload['raw_user_question']??'')!==''?$payload['raw_user_question']:($payload['canonical_query']??$payload['primary_longtail_query']??'')));$usable=$query!=='';$storedNormalized=(string)($row['normalized_key']??'');if($usable&&$storedNormalized!=='')$usable=hash_equals($storedNormalized,self::normalizedKeyForCandidate($payload));}
                if(!$usable){$local=[0=>$row];$result=self::repairOneTopicPayloadFromCandidateEvidence($local,0,$row);$row=$local[0];$payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException('PSTE_PAYLOAD_INTEGRITY_RECOVERY_NOT_VALID');if(!empty($result['quarantined']))$quarantined++;else $repaired++;}else $unchanged++;
                $processed++;
            }
            self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
        $next=$cursor+$processed;return ['contract'=>'PSTE_TOPIC_PAYLOAD_INTEGRITY_BATCH_V1','job_uuid'=>$jobUuid,'processed'=>$processed,'cursor'=>$next,'total'=>$total,'complete'=>$next>=$total,'repaired'=>$repaired,'quarantined'=>$quarantined,'unchanged'=>$unchanged];
    }

    /** Global count/relation gate after every row has crossed the bounded payload-integrity pass. @return array<string,mixed> */
    public static function topicPayloadIntegrityVerify(array $init,int $cursor): array {
        if(($init['contract']??'')!=='PSTE_TOPIC_PAYLOAD_INTEGRITY_INIT_V1')throw new RuntimeException('PSTE_PAYLOAD_INTEGRITY_INIT_INVALID');$before=(array)($init['baseline']??[]);$after=self::migrationBaseline();$expected=(int)($init['topic_count']??-1);if($cursor!==$expected||(int)($after['topic_pool']??-2)!==$expected)throw new RuntimeException('PSTE_PAYLOAD_INTEGRITY_CURSOR_OR_COUNT_MISMATCH');
        foreach(['topic_pool','candidates','assignments','history','identity'] as $field)if((int)($before[$field]??-1)!==(int)($after[$field]??-2))throw new RuntimeException('PSTE_PAYLOAD_INTEGRITY_COUNT_CHANGED_'.strtoupper($field));if((int)($after['occurrences']??0)<(int)($before['occurrences']??0))throw new RuntimeException('PSTE_PAYLOAD_INTEGRITY_OCCURRENCE_COUNT_DECREASED');self::assertTopicPoolUsesUuid();self::assertTopicRelationsConsistent();
        return ['contract'=>'PSTE_TOPIC_PAYLOAD_INTEGRITY_VERIFY_V1','status'=>'PASS','topic_count'=>$expected,'occurrences_before'=>(int)($before['occurrences']??0),'occurrences_after'=>(int)($after['occurrences']??0),'relations'=>'PASS','write_scope'=>'PSTE_OWN_TOPIC_DOMAIN_ONLY','production_handoff_attempted'=>false];
    }

    /** Seed for the deterministic incremental raw-source chain used across requests. */
    public static function editorialRawSourceChainSeed(): string {return hash('sha256','PSTE_EDITORIAL_RAW_SOURCE_CHAIN_V1');}

    /** Baseline-scan at most $limit rows without changing them. @return array<string,mixed> */
    public static function editorialMigrationRawBaselineBatch(int $cursor,int $limit,string $chain): array {
        $cursor=max(0,$cursor);$limit=max(1,min(25,$limit));if(!preg_match('/^[a-f0-9]{64}$/',$chain))throw new RuntimeException('PSTE_EDITORIAL_RAW_CHAIN_INVALID');global $wpdb;$table=self::table('topic_pool');$total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");$rows=$wpdb->get_results("SELECT * FROM $table ORDER BY id ASC LIMIT ".(int)$limit." OFFSET ".(int)$cursor,ARRAY_A);if($rows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_EDITORIAL_RAW_BASELINE_READ_FAILED:'.self::dbError());$processed=0;
        foreach((array)$rows as $row){$payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException('PSTE_EDITORIAL_RAW_BASELINE_PAYLOAD_INVALID');$chain=self::rawSourceChainStep($chain,$row,$payload);$processed++;}
        $next=$cursor+$processed;return ['contract'=>'PSTE_EDITORIAL_RAW_BASELINE_BATCH_V1','processed'=>$processed,'cursor'=>$next,'total'=>$total,'complete'=>$next>=$total,'raw_source_chain_sha256'=>$chain];
    }

    /** Read at most $limit already-prepared rows and return compact duplicate-group contributions. @return array<string,mixed> */
    public static function editorialMigrationVariantScanBatch(int $cursor,int $limit,string $jobUuid): array {
        $cursor=max(0,$cursor);$limit=max(1,min(25,$limit));$jobUuid=trim($jobUuid);if($jobUuid==='')throw new RuntimeException('PSTE_EDITORIAL_MIGRATION_JOB_UUID_REQUIRED');global $wpdb;$table=self::table('topic_pool');$total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");$rows=$wpdb->get_results("SELECT * FROM $table ORDER BY id ASC LIMIT ".(int)$limit." OFFSET ".(int)$cursor,ARRAY_A);if($rows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_EDITORIAL_VARIANT_SCAN_READ_FAILED:'.self::dbError());$items=[];
        foreach((array)$rows as $row){$payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload))throw new RuntimeException('PSTE_EDITORIAL_VARIANT_SCAN_PAYLOAD_INVALID');$receipt=(array)($payload['editorial_migration_prepare_receipt']??[]);if(($receipt['contract']??'')!=='PSTE_EDITORIAL_MIGRATION_PREPARE_RECEIPT_V1'||!hash_equals($jobUuid,(string)($receipt['job_uuid']??'')))throw new RuntimeException('PSTE_EDITORIAL_VARIANT_SCAN_PREPARE_RECEIPT_MISSING');$resolved=!empty($payload['editorialization']['resolved'])&&!empty($payload['editorial_intent_key'])&&empty($payload['recovery_quarantined']);$query=PSTE_Editorializer::sourceQuery($payload);$items[]=['pool_key'=>(string)($row['pool_key']??''),'row_id'=>(int)($row['id']??0),'resolved'=>$resolved,'editorial_intent_key'=>$resolved?(string)$payload['editorial_intent_key']:'','identity_length'=>$resolved?strlen(PSTE_Normalizer::exactTopicIdentityText($query)):0,'source_query'=>$resolved?$query:'','editorial_title'=>$resolved?(string)($payload['editorial_title']??''):''];}
        $next=$cursor+count($rows);return ['contract'=>'PSTE_EDITORIAL_VARIANT_SCAN_BATCH_V1','processed'=>count($rows),'cursor'=>$next,'total'=>$total,'complete'=>$next>=$total,'items'=>$items];
    }

    /** Seal the compact cross-request duplicate-group accumulator as the sole variant plan for this job. @return array<string,mixed> */
    public static function editorialMigrationVariantPlanFromAccumulator(string $jobUuid,array $groups,int $topicCount): array {
        $clean=[];$variantCount=0;ksort($groups,SORT_STRING);foreach($groups as $intent=>$group){if(!is_array($group)||trim((string)$intent)==='')continue;$canonical=trim((string)($group['canonical_pool_key']??''));if($canonical==='')throw new RuntimeException('PSTE_EDITORIAL_VARIANT_ACCUMULATOR_CANONICAL_MISSING');$variants=array_values(array_unique(array_filter(array_map('strval',(array)($group['variant_pool_keys']??[])),'strlen')));$variants=array_values(array_filter($variants,static fn(string $v):bool=>$v!==$canonical));sort($variants,SORT_STRING);$aliases=array_values(array_unique(array_filter(array_map('strval',(array)($group['aliases']??[])),'strlen')));sort($aliases,SORT_STRING);$clean[(string)$intent]=['canonical_pool_key'=>$canonical,'canonical_sort'=>(array)($group['canonical_sort']??[]),'variant_pool_keys'=>$variants,'aliases'=>$aliases];$variantCount+=count($variants);}
        $plan=['contract'=>'PSTE_EDITORIAL_VARIANT_PLAN_V1','job_uuid'=>$jobUuid,'ruleset'=>PSTE_Editorializer::RULESET,'topic_count'=>$topicCount,'variant_count'=>$variantCount,'groups'=>$clean];$plan['sha256']=self::stableValueHash($plan);return $plan;
    }

    /**
     * Verify at most $limit finalized rows and extend the deterministic raw-source chain. This same scan is used
     * before and after Sandbox work; Sandbox admission itself has no authority to mutate topic payloads.
     * @return array<string,mixed>
     */
    public static function editorialMigrationVerifyBatch(int $cursor,int $limit,string $jobUuid,array $variantPlan,string $chain): array {
        $cursor=max(0,$cursor);$limit=max(1,min(25,$limit));if(!preg_match('/^[a-f0-9]{64}$/',$chain))throw new RuntimeException('PSTE_EDITORIAL_VERIFY_CHAIN_INVALID');$declared=(string)($variantPlan['sha256']??'');$copy=$variantPlan;unset($copy['sha256']);if(($variantPlan['contract']??'')!=='PSTE_EDITORIAL_VARIANT_PLAN_V1'||!hash_equals($jobUuid,(string)($variantPlan['job_uuid']??''))||!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(self::stableValueHash($copy),$declared))throw new RuntimeException('PSTE_EDITORIAL_VERIFY_VARIANT_PLAN_INVALID');global $wpdb;$table=self::table('topic_pool');$total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");$rows=$wpdb->get_results("SELECT * FROM $table ORDER BY id ASC LIMIT ".(int)$limit." OFFSET ".(int)$cursor,ARRAY_A);if($rows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_EDITORIAL_VERIFY_BATCH_READ_FAILED:'.self::dbError());
        foreach((array)$rows as $row){$payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException('PSTE_EDITORIAL_VERIFY_PAYLOAD_INVALID');self::assertEditorialFinalPayloadContract($payload,$jobUuid,$declared);$raw=PSTE_Editorializer::sourceQuery($payload);$expected=$raw!==''?hash('sha256',$raw):'';if(!hash_equals($raw,(string)($payload['raw_keyword_preserved']??''))||!hash_equals($expected,(string)($payload['raw_keyword_sha256']??'')))throw new RuntimeException('PSTE_EDITORIAL_RULESET_RAW_KEYWORD_MIRROR_INVALID');$chain=self::rawSourceChainStep($chain,$row,$payload);}
        $next=$cursor+count($rows);return ['contract'=>'PSTE_EDITORIAL_VERIFY_BATCH_V1','processed'=>count($rows),'cursor'=>$next,'total'=>$total,'complete'=>$next>=$total,'raw_source_chain_sha256'=>$chain];
    }

    /** Final global invariants after a complete bounded verify scan. @return array<string,mixed> */
    public static function editorialMigrationVerifyComplete(array $init,int $cursor,string $rawChain): array {
        if(($init['contract']??'')!=='PSTE_EDITORIAL_MIGRATION_INIT_V1')throw new RuntimeException('PSTE_EDITORIAL_MIGRATION_INIT_INVALID');$expected=(int)($init['topic_count']??-1);$baselineChain=(string)($init['raw_source_chain_sha256']??'');if($cursor!==$expected||!preg_match('/^[a-f0-9]{64}$/',$baselineChain)||!hash_equals($baselineChain,$rawChain))throw new RuntimeException('PSTE_EDITORIAL_RULESET_RAW_KEYWORD_INVARIANT_FAILED');$before=(array)($init['storage']??[]);$storage=self::migrationBaseline();foreach(['topic_pool','candidates','occurrences','identity'] as $field)if((int)($before[$field]??-1)!==(int)($storage[$field]??-2))throw new RuntimeException('PSTE_EDITORIAL_RULESET_STORAGE_INVARIANT_FAILED_'.strtoupper($field));self::assertTopicRelationsConsistent();return ['contract'=>'PSTE_EDITORIAL_MIGRATION_VERIFY_COMPLETE_V1','topic_count'=>$expected,'raw_source_sha256'=>$rawChain,'raw_keyword_invariant'=>'PASS','raw_keyword_mirror_invariant'=>'PASS','storage_invariant'=>'PASS','relations'=>'PASS'];
    }

    private static function rawSourceChainStep(string $chain,array $row,array $payload): string {$item=['pool_key'=>(string)($row['pool_key']??'')]+self::rawSourceFields($payload);return hash('sha256',$chain.'|'.self::stableValueHash($item));}

    private static function assertEditorialFinalPayloadContract(array $payload,string $jobUuid,string $variantPlanSha): void {
        $prep=(array)($payload['editorial_migration_prepare_receipt']??[]);$final=(array)($payload['editorial_migration_finalize_receipt']??[]);if(($prep['contract']??'')!=='PSTE_EDITORIAL_MIGRATION_PREPARE_RECEIPT_V1'||!hash_equals($jobUuid,(string)($prep['job_uuid']??''))||($final['contract']??'')!=='PSTE_EDITORIAL_MIGRATION_FINALIZE_RECEIPT_V1'||!hash_equals($jobUuid,(string)($final['job_uuid']??''))||!hash_equals($variantPlanSha,(string)($final['variant_plan_sha256']??'')))throw new RuntimeException('PSTE_EDITORIAL_FINAL_RECEIPT_INVALID');
        if(!empty($payload['recovery_quarantined'])){$guard=(array)($payload['recovery_quarantine_editorial_guard']??[]);if((string)($payload['contract']??'')!=='PSTE_TOPIC_PAYLOAD_RECOVERY_QUARANTINE_V1'||(string)($payload['automatic_pool_status']??'')!=='REVIEW_REQUIRED'||(string)($payload['planning_suitability']??'')!=='BLOCKED'||(string)($payload['textmachine_handoff_status']??'')!=='BLOCKED_PAYLOAD_RECOVERY_QUARANTINE'||isset($payload['normal_metadata_path'])||isset($payload['editorialization'])||trim((string)($payload['production_title']??''))!==''||trim((string)($payload['editorial_title']??''))!==''||($guard['contract']??'')!=='PSTE_RECOVERY_QUARANTINE_EDITORIAL_GUARD_V1'||!empty($guard['semantic_recompute_attempted'])||!empty($guard['sandbox_admission_attempted'])||!empty($guard['production_handoff_attempted'])||!empty($guard['article_or_taxonomy_write_attempted']))throw new RuntimeException('PSTE_EDITORIAL_FINAL_RECOVERY_QUARANTINE_INVALID');return;}
        $editorialization=(array)($payload['editorialization']??[]);if(!hash_equals(PSTE_Editorializer::RULESET,(string)($editorialization['contract']??'')))throw new RuntimeException('PSTE_EDITORIAL_FINAL_EDITORIALIZATION_NOT_CURRENT');$path=(array)($payload['normal_metadata_path']??[]);if((string)($path['contract']??'')!==PSTE_Normal_Metadata_Path::CONTRACT)throw new RuntimeException('PSTE_EDITORIAL_FINAL_NORMAL_PATH_NOT_CURRENT');$raw=PSTE_Editorializer::sourceQuery($payload);if(!PSTE_Normal_Metadata_Path::payloadMatchesNormalPath($payload,$path))throw new RuntimeException('PSTE_EDITORIAL_FINAL_NORMAL_PATH_RAW_HASH_MISMATCH');foreach(['five_field_handoff_created','production_handoff_attempted','article_or_taxonomy_write_attempted','write_attempted'] as $flag)if(!empty($path[$flag]))throw new RuntimeException('PSTE_EDITORIAL_FINAL_NORMAL_PATH_WRITE_BOUNDARY_VIOLATION_'.strtoupper($flag));
    }

    /**
     * Initialize the durable editorial rebuild. This captures only immutable/global evidence; no topic is changed.
     * Heavy semantic work is performed later in bounded preparation batches.
     * @return array<string,mixed>
     */
    public static function editorialMigrationInitialize(string $jobUuid): array {
        $jobUuid=trim($jobUuid);if($jobUuid==='')throw new RuntimeException('PSTE_EDITORIAL_MIGRATION_JOB_UUID_REQUIRED');$storage=self::migrationBaseline();self::assertTopicRelationsConsistent();
        return ['contract'=>'PSTE_EDITORIAL_MIGRATION_INIT_V1','job_uuid'=>$jobUuid,'ruleset'=>PSTE_Editorializer::RULESET,'topic_count'=>(int)($storage['topic_pool']??0),'raw_source_chain_sha256'=>'','storage'=>$storage,'prepare_cursor'=>0,'finalize_cursor'=>0,'request_bounded'=>true];
    }

    /**
     * Recompute the shared relevance-first/editorial path for at most $limit rows and persist only that derived payload.
     * A receipt inside the same row makes an HTTP replay after commit idempotent.
     * @return array<string,mixed>
     */
    public static function editorialMigrationPrepareBatch(int $cursor,int $limit,string $jobUuid): array {
        $cursor=max(0,$cursor);$limit=max(1,min(25,$limit));$jobUuid=trim($jobUuid);if($jobUuid==='')throw new RuntimeException('PSTE_EDITORIAL_MIGRATION_JOB_UUID_REQUIRED');
        global $wpdb;$table=self::table('topic_pool');$total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");$rows=$wpdb->get_results("SELECT * FROM $table ORDER BY id ASC LIMIT ".(int)$limit." OFFSET ".(int)$cursor,ARRAY_A);if($rows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_EDITORIAL_PREPARE_BATCH_READ_FAILED:'.self::dbError());$rows=(array)$rows;$processed=0;$replayed=0;
        self::beginTransaction();
        try{
            foreach($rows as $row){
                $poolKey=(string)($row['pool_key']??'');$payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload))throw new RuntimeException('PSTE_EDITORIAL_PREPARE_PAYLOAD_INVALID');
                $rawBefore=self::rawSourceFields($payload);$rawSha=self::stableValueHash($rawBefore);$receipt=(array)($payload['editorial_migration_prepare_receipt']??[]);
                if(($receipt['contract']??'')==='PSTE_EDITORIAL_MIGRATION_PREPARE_RECEIPT_V1'&&hash_equals($jobUuid,(string)($receipt['job_uuid']??''))&&hash_equals(PSTE_Editorializer::RULESET,(string)($receipt['ruleset']??''))&&hash_equals($rawSha,(string)($receipt['raw_source_sha256']??''))){$processed++;$replayed++;continue;}
                if(!empty($payload['recovery_quarantined'])){
                    $prepared=self::preserveRecoveryQuarantineForEditorialMigration($payload);
                }else{
                    $prepared=self::resetEditorialVariantDerivedState(self::prepareEditorialPayload($payload));
                }
                if(self::rawSourceFields($prepared)!==$rawBefore)throw new RuntimeException('PSTE_EDITORIAL_PREPARE_RAW_SOURCE_MUTATION');
                $prepared['editorial_migration_prepare_receipt']=['contract'=>'PSTE_EDITORIAL_MIGRATION_PREPARE_RECEIPT_V1','job_uuid'=>$jobUuid,'ruleset'=>PSTE_Editorializer::RULESET,'raw_source_sha256'=>$rawSha,'recovery_quarantine_preserved'=>!empty($prepared['recovery_quarantined']),'prepared_at_utc'=>gmdate('c')];
                $encoded=self::encodeJsonValue($prepared,'PSTE_EDITORIAL_MIGRATION_PREPARED_PAYLOAD');
                self::checkedUpdate(self::table('topic_pool'),['payload_json'=>$encoded],['pool_key'=>$poolKey],['%s'],['%s'],'PSTE_EDITORIAL_MIGRATION_PREPARE_UPDATE_FAILED');self::assertTopicPayloadPersisted($poolKey,$encoded,'PSTE_EDITORIAL_MIGRATION_PREPARE_PAYLOAD');$processed++;
            }
            self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
        $next=$cursor+$processed;return ['contract'=>'PSTE_EDITORIAL_MIGRATION_PREPARE_BATCH_V1','processed'=>$processed,'replayed'=>$replayed,'cursor'=>$next,'total'=>$total,'complete'=>$next>=$total];
    }

    /**
     * Build the duplicate/variant plan only after every row has been freshly prepared by this migration job.
     * This is read-only and keeps the old deterministic canonical selection semantics.
     * @return array<string,mixed>
     */
    public static function editorialMigrationVariantPlan(string $jobUuid): array {
        global $wpdb;$rows=$wpdb->get_results("SELECT * FROM ".self::table('topic_pool')." ORDER BY id ASC",ARRAY_A)?:[];$groups=[];$byKey=[];
        foreach($rows as $row){$payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload))throw new RuntimeException('PSTE_EDITORIAL_VARIANT_PLAN_PAYLOAD_INVALID');$r=(array)($payload['editorial_migration_prepare_receipt']??[]);if(($r['contract']??'')!=='PSTE_EDITORIAL_MIGRATION_PREPARE_RECEIPT_V1'||!hash_equals($jobUuid,(string)($r['job_uuid']??''))||!hash_equals(PSTE_Editorializer::RULESET,(string)($r['ruleset']??'')))throw new RuntimeException('PSTE_EDITORIAL_VARIANT_PLAN_PREPARE_RECEIPT_MISSING');$poolKey=(string)($row['pool_key']??'');$byKey[$poolKey]=['row'=>$row,'payload'=>$payload];if(!empty($payload['editorialization']['resolved'])&&(string)($payload['editorial_intent_key']??'')!=='')$groups[(string)$payload['editorial_intent_key']][]=$poolKey;}
        $variants=[];$canonicalAliases=[];$variantCount=0;
        foreach($groups as $keys){if(count($keys)<2)continue;usort($keys,static function(string $a,string $b)use($byKey):int{$qa=PSTE_Editorializer::sourceQuery((array)$byKey[$a]['payload']);$qb=PSTE_Editorializer::sourceQuery((array)$byKey[$b]['payload']);return [strlen(PSTE_Normalizer::exactTopicIdentityText($qa)),(int)($byKey[$a]['row']['id']??0)]<=>[strlen(PSTE_Normalizer::exactTopicIdentityText($qb)),(int)($byKey[$b]['row']['id']??0)];});$canonical=array_shift($keys);$aliases=[];foreach($keys as $variant){$variants[$variant]=$canonical;$vp=(array)$byKey[$variant]['payload'];foreach([PSTE_Editorializer::sourceQuery($vp),(string)($vp['editorial_title']??'')] as $alias){$alias=trim($alias);if($alias!=='')$aliases[]=$alias;}$variantCount++;}$canonicalAliases[$canonical]=array_values(array_unique($aliases));}
        $plan=['contract'=>'PSTE_EDITORIAL_VARIANT_PLAN_V1','job_uuid'=>$jobUuid,'ruleset'=>PSTE_Editorializer::RULESET,'topic_count'=>count($rows),'variant_count'=>$variantCount,'variants'=>$variants,'canonical_aliases'=>$canonicalAliases];$plan['sha256']=self::stableValueHash($plan);return $plan;
    }

    /**
     * Finalize at most $limit prepared rows: apply the global variant plan, derive status/role/planning,
     * persist assignments/history atomically with a replay receipt, and emit Sandbox queue contributions.
     * @return array<string,mixed>
     */
    public static function editorialMigrationFinalizeBatch(int $cursor,int $limit,string $jobUuid,array $variantPlan): array {
        $cursor=max(0,$cursor);$limit=max(1,min(25,$limit));if(($variantPlan['contract']??'')!=='PSTE_EDITORIAL_VARIANT_PLAN_V1'||!hash_equals($jobUuid,(string)($variantPlan['job_uuid']??''))||!hash_equals(PSTE_Editorializer::RULESET,(string)($variantPlan['ruleset']??'')))throw new RuntimeException('PSTE_EDITORIAL_VARIANT_PLAN_INVALID');$declared=(string)($variantPlan['sha256']??'');$copy=$variantPlan;unset($copy['sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(self::stableValueHash($copy),$declared))throw new RuntimeException('PSTE_EDITORIAL_VARIANT_PLAN_HASH_INVALID');
        global $wpdb;$table=self::table('topic_pool');$total=(int)$wpdb->get_var("SELECT COUNT(*) FROM $table");$rows=$wpdb->get_results("SELECT * FROM $table ORDER BY id ASC LIMIT ".(int)$limit." OFFSET ".(int)$cursor,ARRAY_A);if($rows===null&&(string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_EDITORIAL_FINALIZE_BATCH_READ_FAILED:'.self::dbError());$rows=(array)$rows;$contributions=[];$processed=0;$replayed=0;
        self::beginTransaction();
        try{
            foreach($rows as $row){
                $poolKey=(string)($row['pool_key']??'');$payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload))throw new RuntimeException('PSTE_EDITORIAL_FINALIZE_PAYLOAD_INVALID');$prep=(array)($payload['editorial_migration_prepare_receipt']??[]);if(($prep['contract']??'')!=='PSTE_EDITORIAL_MIGRATION_PREPARE_RECEIPT_V1'||!hash_equals($jobUuid,(string)($prep['job_uuid']??'')))throw new RuntimeException('PSTE_EDITORIAL_FINALIZE_PREPARE_RECEIPT_MISSING');
                $existing=(array)($payload['editorial_migration_finalize_receipt']??[]);if(($existing['contract']??'')==='PSTE_EDITORIAL_MIGRATION_FINALIZE_RECEIPT_V1'&&hash_equals($jobUuid,(string)($existing['job_uuid']??''))&&hash_equals($declared,(string)($existing['variant_plan_sha256']??''))){$c=(array)($existing['contribution']??[]);$contributions[]=$c;$processed++;$replayed++;continue;}
                $rawBefore=self::rawSourceFields($payload);
                if(!empty($payload['recovery_quarantined'])){
                    $payload=self::preserveRecoveryQuarantineForEditorialMigration($payload);
                    $contribution=['pool_key'=>$poolKey,'auto_resolved'=>0,'missing_target_category'=>0,'status_changes'=>(string)($row['automatic_pool_status']??'')==='REVIEW_REQUIRED'?0:1,'sandbox_required'=>0,'queue_item'=>null,'recovery_quarantine_preserved'=>true];
                    $payload['editorial_migration_finalize_receipt']=['contract'=>'PSTE_EDITORIAL_MIGRATION_FINALIZE_RECEIPT_V1','job_uuid'=>$jobUuid,'ruleset'=>PSTE_Editorializer::RULESET,'variant_plan_sha256'=>$declared,'raw_source_sha256'=>self::stableValueHash($rawBefore),'contribution'=>$contribution,'recovery_quarantine_preserved'=>true,'finalized_at_utc'=>gmdate('c')];
                    if(self::rawSourceFields($payload)!==$rawBefore)throw new RuntimeException('PSTE_EDITORIAL_FINALIZE_RAW_SOURCE_MUTATION');
                    self::checkedUpdate(self::table('topic_pool'),['automatic_decision'=>'BLOCKED','automatic_pool_status'=>'REVIEW_REQUIRED','topic_role'=>PSTE_Topic_Policy::ROLE_NON_EDITORIAL,'planning_suitability'=>'BLOCKED','context_state'=>'BLOCKED','context_synced_at'=>null,'payload_json'=>self::encodeJsonValue($payload,'PSTE_EDITORIAL_MIGRATION_QUARANTINE_FINAL_PAYLOAD')],['pool_key'=>$poolKey],['%s','%s','%s','%s','%s','%s','%s'],['%s'],'PSTE_EDITORIAL_MIGRATION_QUARANTINE_FINALIZE_UPDATE_FAILED');
                    $contributions[]=$contribution;$processed++;continue;
                }
                $intent=(string)($payload['editorial_intent_key']??'');$group=is_array($variantPlan['groups'][$intent]??null)?(array)$variantPlan['groups'][$intent]:[];$canonical=(string)($group['canonical_pool_key']??'');
                if($canonical!==''&&$poolKey!==$canonical){$payload['editorial_variant_of']=$canonical;$payload['reason_codes']=array_values(array_unique(array_merge((array)($payload['reason_codes']??[]),['EXACT_EDITORIAL_INTENT_VARIANT'])));}else{unset($payload['editorial_variant_of']);$payload['reason_codes']=array_values(array_diff((array)($payload['reason_codes']??[]),['EXACT_EDITORIAL_INTENT_VARIANT']));}
                if($canonical!==''&&$poolKey===$canonical&&!empty($group['aliases'])){$aliases=(array)($payload['aliases']??[]);$payload['aliases']=array_values(array_unique(array_filter(array_merge($aliases,(array)$group['aliases']),'strlen')));}
                $automatic=self::automaticPoolStatus($payload);$payload['automatic_pool_status']=$automatic;$role=PSTE_Topic_Policy::classifyRole($payload);$context=(string)($row['context_state']??'PENDING');$effective=(string)(($row['manual_status']??'')!==''?$row['manual_status']:$automatic);$planning=PSTE_Topic_Policy::planningSuitability(array_merge($payload,['topic_role'=>$role]),$effective,$context);$payload['topic_role']=$role;$payload['planning_suitability']=$planning;$payload['context_state']=$context;$currentCategory=(int)($payload['target_category_id']??$row['current_category_id']??0);$automaticDecision=$automatic==='AUTO_RESOLVED'?'PASS':(string)($payload['decision']??'REVIEW_REQUIRED');
                $normalPath=(array)($payload['normal_metadata_path']??[]);$pathStatus=(string)($normalPath['status']??'');$admissionMode=(string)($normalPath['sandbox_admission_mode']??'');$queueItem=null;$sandboxRequired=0;
                if($pathStatus==='STRUCTURE_GAP')$queueItem=['pool_key'=>$poolKey,'mode'=>'INTERNAL','path_status'=>$pathStatus,'normal_path_sha256'=>self::stableValueHash($normalPath),'reason_codes'=>['PSTE_EDITORIAL_RULESET_REBUILD_STRUCTURE_GAP_BACKLOG']];
                elseif($pathStatus==='SANDBOX_REQUIRED'&&$admissionMode==='INTERNAL_CLARIFICATION'){$queueItem=['pool_key'=>$poolKey,'mode'=>'INTERNAL','path_status'=>$pathStatus,'normal_path_sha256'=>self::stableValueHash($normalPath),'reason_codes'=>['PSTE_EDITORIAL_RULESET_REBUILD_INTERNAL_CLARIFICATION']];$sandboxRequired=1;}
                elseif($pathStatus==='SANDBOX_REQUIRED'){$queueItem=['pool_key'=>$poolKey,'mode'=>'EXTERNAL','path_status'=>$pathStatus,'normal_path_sha256'=>self::stableValueHash($normalPath),'reason_codes'=>['PSTE_EDITORIAL_RULESET_REBUILD_REQUIRES_EXTERNAL_RELEVANCE']];$sandboxRequired=1;}
                $missingTarget=(!empty($payload['editorialization']['eligible'])&&empty($payload['editorialization']['resolved'])&&(string)($payload['editorialization']['reason']??'')==='TARGET_CATEGORY_NOT_FOUND')?1:0;$before=(string)($row['automatic_pool_status']??'');$statusChange=$before!==$automatic?1:0;
                $contribution=['pool_key'=>$poolKey,'auto_resolved'=>$automatic==='AUTO_RESOLVED'?1:0,'missing_target_category'=>$missingTarget,'status_changes'=>$statusChange,'sandbox_required'=>$sandboxRequired,'queue_item'=>$queueItem];
                $payload['editorial_migration_finalize_receipt']=['contract'=>'PSTE_EDITORIAL_MIGRATION_FINALIZE_RECEIPT_V1','job_uuid'=>$jobUuid,'ruleset'=>PSTE_Editorializer::RULESET,'variant_plan_sha256'=>$declared,'raw_source_sha256'=>self::stableValueHash($rawBefore),'contribution'=>$contribution,'finalized_at_utc'=>gmdate('c')];if(self::rawSourceFields($payload)!==$rawBefore)throw new RuntimeException('PSTE_EDITORIAL_FINALIZE_RAW_SOURCE_MUTATION');
                self::checkedUpdate(self::table('topic_pool'),['automatic_decision'=>$automaticDecision,'automatic_pool_status'=>$automatic,'topic_role'=>$role,'planning_suitability'=>$planning,'current_category_id'=>$currentCategory,'payload_json'=>self::encodeJsonValue($payload,'PSTE_EDITORIAL_MIGRATION_FINAL_PAYLOAD')],['pool_key'=>$poolKey],['%s','%s','%s','%s','%d','%s'],['%s'],'PSTE_EDITORIAL_MIGRATION_FINALIZE_UPDATE_FAILED');
                if($automatic==='AUTO_RESOLVED')self::upsertTopicAssignment($poolKey,$currentCategory,(string)($payload['target_category_name']??''),(string)($payload['proposed_article_type']??''),'AUTOMATIC_EDITORIALIZATION','CONFIRMED',1.0,['DETERMINISTIC_GENERAL_RULE'],['ruleset'=>PSTE_Editorializer::RULESET,'editorial_title'=>(string)($payload['editorial_title']??''),'production_release'=>false]);
                if($statusChange)self::recordTopicHistory($poolKey,'GENERAL_EDITORIAL_RULESET_APPLIED',$before,$automatic,['ruleset'=>PSTE_Editorializer::RULESET,'editorial_title'=>(string)($payload['editorial_title']??'')],0);
                $contributions[]=$contribution;$processed++;
            }
            self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
        $next=$cursor+$processed;return ['contract'=>'PSTE_EDITORIAL_MIGRATION_FINALIZE_BATCH_V1','processed'=>$processed,'replayed'=>$replayed,'cursor'=>$next,'total'=>$total,'complete'=>$next>=$total,'contributions'=>$contributions];
    }

    /** Final invariant for the request-bounded core, before Sandbox cross-store work starts. */
    public static function editorialMigrationCoreVerify(array $init): array {
        if(($init['contract']??'')!=='PSTE_EDITORIAL_MIGRATION_INIT_V1'||!hash_equals(PSTE_Editorializer::RULESET,(string)($init['ruleset']??'')))throw new RuntimeException('PSTE_EDITORIAL_MIGRATION_INIT_INVALID');global $wpdb;$rows=$wpdb->get_results("SELECT * FROM ".self::table('topic_pool')." ORDER BY id ASC",ARRAY_A)?:[];$after=self::editorialRulesetInvariant($rows);if((int)($init['topic_count']??-1)!==(int)$after['topic_count']||!hash_equals((string)($init['raw_source_sha256']??''),(string)$after['raw_source_sha256']))throw new RuntimeException('PSTE_EDITORIAL_RULESET_RAW_KEYWORD_INVARIANT_FAILED');self::assertEditorialKeywordMirrors($rows);$before=(array)($init['storage']??[]);$storage=self::migrationBaseline();foreach(['topic_pool','candidates','occurrences','identity'] as $field)if((int)($before[$field]??-1)!==(int)($storage[$field]??-2))throw new RuntimeException('PSTE_EDITORIAL_RULESET_STORAGE_INVARIANT_FAILED_'.strtoupper($field));self::assertTopicRelationsConsistent();return ['contract'=>'PSTE_EDITORIAL_MIGRATION_CORE_VERIFY_V1','topic_count'=>(int)$after['topic_count'],'raw_source_sha256'=>(string)$after['raw_source_sha256'],'raw_keyword_invariant'=>'PASS','raw_keyword_mirror_invariant'=>'PASS','storage_invariant'=>'PASS','relations'=>'PASS'];
    }

    /** @return array<string,mixed> */
    private static function rawSourceFields(array $payload): array {return ['raw_user_question'=>$payload['raw_user_question']??null,'primary_longtail_query'=>$payload['primary_longtail_query']??null,'canonical_query'=>$payload['canonical_query']??null,'query_record'=>$payload['query_record']??null,'query_aliases'=>$payload['query_aliases']??null];}

    /**
     * A payload-recovery quarantine is an integrity state, not a semantic candidate.
     * Keep evidence/raw fields, remove stale current editorial authority and keep the
     * row explicitly non-producing until deterministic source evidence heals it.
     */
    private static function preserveRecoveryQuarantineForEditorialMigration(array $payload): array {
        if(empty($payload['recovery_quarantined'])||(string)($payload['contract']??'')!=='PSTE_TOPIC_PAYLOAD_RECOVERY_QUARANTINE_V1')throw new RuntimeException('PSTE_EDITORIAL_RECOVERY_QUARANTINE_CONTRACT_INVALID');
        foreach(['normal_metadata_path','sandbox_required','sandbox_admission_mode','structure_gap_backlog_required','retained_non_producing','category_gap_proposal','topic_family_key','topic_family_name','article_type_registry_sha256','family_identity_v2_registry_sha256','derived_state_authority','family_membership_v2','intent_analysis','semantic_consensus','intent_profile','intent_portfolio','search_intent','intent_angle','normalized_editorial_topic','domain_risk','editorial_title','production_title','target_keyword','target_keyword_contract','editorial_quality_gate','title_quality','language_quality','editorial_dual_strand','editorial_intent_key','editorial_variant_of','editorialization','suggested_article_type','proposed_article_type','target_category_id','target_category_name','target_category_slug','suggested_category_id','suggested_category_name','suggested_category_slug'] as $field)unset($payload[$field]);
        $payload['reason_codes']=array_values(array_unique(array_merge(['PSTE_TOPIC_PAYLOAD_CORRUPTED',(string)($payload['recovery_error_code']??'PSTE_PAYLOAD_RECOVERY_UNRESOLVED')],array_values(array_map('strval',(array)($payload['reason_codes']??[]))))));
        $raw=PSTE_Editorializer::sourceQuery($payload);$payload['raw_keyword_preserved']=$raw;$payload['raw_keyword_sha256']=$raw!==''?hash('sha256',$raw):'';
        $payload['automatic_pool_status']='REVIEW_REQUIRED';$payload['topic_role']=PSTE_Topic_Policy::ROLE_NON_EDITORIAL;$payload['planning_suitability']='BLOCKED';$payload['context_state']='BLOCKED';$payload['metadata_handoff_fields']=['title','target_keyword','category','article_type','plan_slot'];$payload['textmachine_handoff_status']='BLOCKED_PAYLOAD_RECOVERY_QUARANTINE';
        $payload['recovery_quarantine_editorial_guard']=['contract'=>'PSTE_RECOVERY_QUARANTINE_EDITORIAL_GUARD_V1','semantic_recompute_attempted'=>false,'sandbox_admission_attempted'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'write_scope'=>'PSTE_OWN_TOPIC_PAYLOAD_ONLY'];
        return $payload;
    }

    /** Invalidate only rebuild-owned duplicate state before deriving the current global variant plan. */
    private static function resetEditorialVariantDerivedState(array $payload): array {unset($payload['editorial_variant_of']);$payload['reason_codes']=array_values(array_diff((array)($payload['reason_codes']??[]),['EXACT_EDITORIAL_INTENT_VARIANT']));return $payload;}

    /**
     * Compatibility wrapper for non-migration callers/tests. The durable safe-migration lifecycle calls
     * applyEditorialRulesetCore() and advances the Sandbox queue in request-bounded batches instead.
     */
    public static function applyEditorialRuleset(): array {
        $core=self::applyEditorialRulesetCore();$report=(array)($core['report']??[]);$queue=array_values((array)($core['sandbox_queue']??[]));
        $jobUuid='SYNC_'.hash('sha256',PSTE_Editorializer::RULESET.'|'.(string)($report['raw_source_sha256']??'').'|'.(string)($report['sandbox_queue_sha256']??''));
        foreach(array_chunk($queue,12) as $chunk){$items=[];foreach($chunk as $q)$items[]=self::sandboxAdmissionEnvelope((array)$q);$batch=PSTE_Semantic_Review_Sandbox::admitFromNormalPathBatch($items,$jobUuid);$report=self::mergeEditorialSandboxBatchReport($report,$batch,$items);}
        $report['sandbox_candidate_failure_codes']=array_values(array_unique(array_filter(array_map('strval',(array)($report['sandbox_candidate_failure_codes']??[])))));
        return $report;
    }

    public static function applyEditorialRulesetCore(): array {
        global $wpdb;
        $rows=$wpdb->get_results("SELECT * FROM ".self::table('topic_pool')." ORDER BY id ASC",ARRAY_A)?:[];
        $invariantBefore=self::editorialRulesetInvariant($rows);
        $storageBefore=self::migrationBaseline();
        $prepared=[];$groups=[];
        foreach($rows as $row){
            $payload=json_decode((string)($row['payload_json']??''),true);
            if(!is_array($payload))throw new RuntimeException('PSTE_EDITORIAL_RULESET_PAYLOAD_INVALID');
            $payload=self::resetEditorialVariantDerivedState(self::prepareEditorialPayload($payload));
            $prepared[(string)$row['pool_key']]=['row'=>$row,'payload'=>$payload];
            if(!empty($payload['editorialization']['resolved'])&&(string)($payload['editorial_intent_key']??'')!==''){
                $groups[(string)$payload['editorial_intent_key']][]=(string)$row['pool_key'];
            }
        }

        $variants=0;
        foreach($groups as $keys){
            if(count($keys)<2)continue;
            usort($keys,static function(string $a,string $b)use($prepared):int{
                $qa=PSTE_Editorializer::sourceQuery((array)$prepared[$a]['payload']);
                $qb=PSTE_Editorializer::sourceQuery((array)$prepared[$b]['payload']);
                return [strlen(PSTE_Normalizer::exactTopicIdentityText($qa)),(int)($prepared[$a]['row']['id']??0)]
                    <=> [strlen(PSTE_Normalizer::exactTopicIdentityText($qb)),(int)($prepared[$b]['row']['id']??0)];
            });
            $canonical=array_shift($keys);
            foreach($keys as $variant){
                $payload=(array)$prepared[$variant]['payload'];
                $payload['editorial_variant_of']=$canonical;
                $payload['reason_codes']=array_values(array_unique(array_merge((array)($payload['reason_codes']??[]),['EXACT_EDITORIAL_INTENT_VARIANT'])));
                $prepared[$variant]['payload']=$payload;
                $canonicalPayload=(array)$prepared[$canonical]['payload'];
                $aliases=(array)($canonicalPayload['aliases']??[]);
                foreach([PSTE_Editorializer::sourceQuery($payload),(string)($payload['editorial_title']??'')] as $alias){
                    $alias=trim($alias);if($alias!=='')$aliases[]=$alias;
                }
                $canonicalPayload['aliases']=array_values(array_unique(array_filter(array_map('strval',$aliases))));
                $prepared[$canonical]['payload']=$canonicalPayload;
                $variants++;
            }
        }

        $report=['contract'=>PSTE_Editorializer::RULESET,'processed'=>0,'auto_resolved'=>0,'variants'=>$variants,'missing_target_category'=>0,'status_changes'=>0,'sandbox_required'=>0,'sandbox_admitted'=>0,'sandbox_external_admitted'=>0,'sandbox_internal_admitted'=>0,'structure_gap_admitted'=>0,'sandbox_candidate_failures_isolated'=>0,'sandbox_candidate_failure_codes'=>[]];$sandboxAdmissions=[];
        self::beginTransaction();
        try{
            foreach($prepared as $poolKey=>$item){
                $row=(array)$item['row'];$payload=(array)$item['payload'];
                $automatic=self::automaticPoolStatus($payload);$payload['automatic_pool_status']=$automatic;
                $role=PSTE_Topic_Policy::classifyRole($payload);$context=(string)($row['context_state']??'PENDING');
                $effective=(string)(($row['manual_status']??'')!==''?$row['manual_status']:$automatic);
                $planning=PSTE_Topic_Policy::planningSuitability(array_merge($payload,['topic_role'=>$role]),$effective,$context);
                $payload['topic_role']=$role;$payload['planning_suitability']=$planning;$payload['context_state']=$context;
                $currentCategory=(int)($payload['target_category_id']??$row['current_category_id']??0);
                $automaticDecision=$automatic==='AUTO_RESOLVED'?'PASS':(string)($payload['decision']??'REVIEW_REQUIRED');
                self::checkedUpdate(self::table('topic_pool'),[
                    'automatic_decision'=>$automaticDecision,'automatic_pool_status'=>$automatic,'topic_role'=>$role,
                    'planning_suitability'=>$planning,'current_category_id'=>$currentCategory,
                    'payload_json'=>self::encodeJsonValue($payload,'PSTE_TOPIC_PAYLOAD'),
                ],['pool_key'=>$poolKey],['%s','%s','%s','%s','%d','%s'],['%s'],'PSTE_EDITORIAL_RULESET_UPDATE_FAILED');

                $normalPath=(array)($payload['normal_metadata_path']??[]);$pathStatus=(string)($normalPath['status']??'');$admissionMode=(string)($normalPath['sandbox_admission_mode']??'');
                if($pathStatus==='STRUCTURE_GAP'){$sandboxAdmissions[$poolKey]=['mode'=>'INTERNAL','path'=>$normalPath,'reason_codes'=>['PSTE_EDITORIAL_RULESET_REBUILD_STRUCTURE_GAP_BACKLOG']];}
                elseif($pathStatus==='SANDBOX_REQUIRED'&&$admissionMode==='INTERNAL_CLARIFICATION'){$sandboxAdmissions[$poolKey]=['mode'=>'INTERNAL','path'=>$normalPath,'reason_codes'=>['PSTE_EDITORIAL_RULESET_REBUILD_INTERNAL_CLARIFICATION']];$report['sandbox_required']++;}
                elseif($pathStatus==='SANDBOX_REQUIRED'){$sandboxAdmissions[$poolKey]=['mode'=>'EXTERNAL','path'=>$normalPath,'reason_codes'=>['PSTE_EDITORIAL_RULESET_REBUILD_REQUIRES_EXTERNAL_RELEVANCE']];$report['sandbox_required']++;}
                if($automatic==='AUTO_RESOLVED'){
                    self::upsertTopicAssignment($poolKey,$currentCategory,(string)($payload['target_category_name']??''),(string)($payload['proposed_article_type']??''),'AUTOMATIC_EDITORIALIZATION','CONFIRMED',1.0,['DETERMINISTIC_GENERAL_RULE'],['ruleset'=>PSTE_Editorializer::RULESET,'editorial_title'=>(string)($payload['editorial_title']??''),'production_release'=>false]);
                    $report['auto_resolved']++;
                }elseif(!empty($payload['editorialization']['eligible'])&&empty($payload['editorialization']['resolved'])&&(string)($payload['editorialization']['reason']??'')==='TARGET_CATEGORY_NOT_FOUND'){
                    $report['missing_target_category']++;
                }
                $before=(string)($row['automatic_pool_status']??'');
                if($before!==$automatic){
                    self::recordTopicHistory($poolKey,'GENERAL_EDITORIAL_RULESET_APPLIED',$before,$automatic,['ruleset'=>PSTE_Editorializer::RULESET,'editorial_title'=>(string)($payload['editorial_title']??'')],0);
                    $report['status_changes']++;
                }
                $report['processed']++;
            }
            $rowsAfter=$wpdb->get_results("SELECT * FROM ".self::table('topic_pool')." ORDER BY id ASC",ARRAY_A)?:[];
            $invariantAfter=self::editorialRulesetInvariant($rowsAfter);
            if((int)$invariantBefore['topic_count']!==(int)$invariantAfter['topic_count']||!hash_equals((string)$invariantBefore['raw_source_sha256'],(string)$invariantAfter['raw_source_sha256'])){
                throw new RuntimeException('PSTE_EDITORIAL_RULESET_RAW_KEYWORD_INVARIANT_FAILED');
            }
            self::assertEditorialKeywordMirrors($rowsAfter);
            $storageAfter=self::migrationBaseline();
            foreach(['topic_pool','candidates','occurrences','identity'] as $field){
                if((int)($storageBefore[$field]??-1)!==(int)($storageAfter[$field]??-2)){
                    throw new RuntimeException('PSTE_EDITORIAL_RULESET_STORAGE_INVARIANT_FAILED_'.strtoupper($field));
                }
            }
            self::assertTopicRelationsConsistent();
            $report['raw_keyword_invariant']='PASS';
            $report['raw_source_sha256']=(string)$invariantAfter['raw_source_sha256'];
            $report['raw_keyword_sha256']=(string)$invariantAfter['raw_keyword_sha256'];
            $report['raw_keyword_mirror_invariant']='PASS';
            $report['topic_count']=(int)$invariantAfter['topic_count'];
            $report['storage_invariant']='PASS';
            self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
        $queue=[];
        foreach($sandboxAdmissions as $poolKey=>$admission){$path=(array)$admission['path'];$queue[]=['pool_key'=>(string)$poolKey,'mode'=>(string)($admission['mode']??''),'path_status'=>(string)($path['status']??''),'normal_path_sha256'=>self::stableValueHash($path),'reason_codes'=>array_values(array_unique(array_map('strval',(array)$admission['reason_codes'])))];}
        $report['sandbox_queue_count']=count($queue);$report['sandbox_queue_sha256']=self::stableValueHash($queue);
        $report['sandbox_candidate_failure_codes']=array_values(array_unique(array_filter(array_map('strval',$report['sandbox_candidate_failure_codes']))));
        return ['contract'=>'PSTE_EDITORIAL_RULESET_CORE_V1','ruleset'=>PSTE_Editorializer::RULESET,'report'=>$report,'sandbox_queue'=>$queue];
    }

    /** @return array<string,mixed> */
    public static function sandboxAdmissionEnvelope(array $queueItem): array {
        global $wpdb;$poolKey=trim((string)($queueItem['pool_key']??''));if($poolKey==='')throw new RuntimeException('PSTE_EDITORIAL_SANDBOX_QUEUE_POOL_KEY_REQUIRED');
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table('topic_pool')." WHERE pool_key=%s",$poolKey),ARRAY_A);
        if(!$row){if((string)$wpdb->last_error!=='')throw new RuntimeException('PSTE_SANDBOX_SOURCE_DB_READ_FAILED_'.self::dbError());throw new RuntimeException('PSTE_SANDBOX_SOURCE_POOL_ROW_MISSING');}
        $payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload))throw new RuntimeException('PSTE_SANDBOX_SOURCE_PAYLOAD_INVALID');
        $path=is_array($payload['normal_metadata_path']??null)?(array)$payload['normal_metadata_path']:[];if(!$path)throw new RuntimeException('PSTE_EDITORIAL_SANDBOX_NORMAL_PATH_MISSING');
        $sha=self::stableValueHash($path);$expected=(string)($queueItem['normal_path_sha256']??'');if($expected!==''&&!hash_equals($expected,$sha))throw new RuntimeException('PSTE_EDITORIAL_SANDBOX_NORMAL_PATH_DRIFT');
        return ['pool_key'=>$poolKey,'normal_path'=>$path,'diagnostics'=>['reason_codes'=>array_values((array)($queueItem['reason_codes']??[]))],'normal_path_sha256'=>$sha,'path_status'=>(string)($path['status']??'')];
    }

    /** @return array<string,mixed> */
    public static function mergeEditorialSandboxBatchReport(array $report,array $batch,array $items): array {
        $results=array_values((array)($batch['results']??[]));foreach($results as $idx=>$result){$result=is_array($result)?$result:[];$item=is_array($items[$idx]??null)?(array)$items[$idx]:[];
            if(!empty($result['admitted']))$report['sandbox_admitted']=(int)($report['sandbox_admitted']??0)+1;
            if((string)($result['mode']??'')==='INTERNAL')$report['sandbox_internal_admitted']=(int)($report['sandbox_internal_admitted']??0)+1;elseif((string)($result['mode']??'')==='EXTERNAL')$report['sandbox_external_admitted']=(int)($report['sandbox_external_admitted']??0)+1;
            if((string)($item['path_status']??$item['normal_path']['status']??'')==='STRUCTURE_GAP'&&!empty($result['admitted']))$report['structure_gap_admitted']=(int)($report['structure_gap_admitted']??0)+1;
            if(!empty($result['isolated_candidate_failure'])){$report['sandbox_candidate_failures_isolated']=(int)($report['sandbox_candidate_failures_isolated']??0)+1;$report['sandbox_candidate_failure_codes'][]=(string)($result['error_code']??'PSTE_SANDBOX_CANDIDATE_FAILURE');}
        }
        $report['sandbox_candidate_failure_codes']=array_values(array_unique(array_filter(array_map('strval',(array)($report['sandbox_candidate_failure_codes']??[])))));return $report;
    }

    /** Final source/storage integrity verification after all bounded Sandbox batches. @return array<string,mixed> */
    public static function verifyEditorialRulesetState(): array {
        global $wpdb;$rows=$wpdb->get_results("SELECT * FROM ".self::table('topic_pool')." ORDER BY id ASC",ARRAY_A)?:[];$inv=self::editorialRulesetInvariant($rows);self::assertEditorialKeywordMirrors($rows);$storage=self::migrationBaseline();self::assertTopicRelationsConsistent();
        foreach($rows as $row){
            $payload=json_decode((string)($row['payload_json']??''),true);
            if(!is_array($payload))throw new RuntimeException('PSTE_EDITORIAL_FINAL_PAYLOAD_INVALID');
            if(!empty($payload['recovery_quarantined'])){
                if((string)($payload['contract']??'')!=='PSTE_TOPIC_PAYLOAD_RECOVERY_QUARANTINE_V1'||(string)($payload['automatic_pool_status']??'')!=='REVIEW_REQUIRED'||(string)($payload['planning_suitability']??'')!=='BLOCKED'||(string)($payload['textmachine_handoff_status']??'')!=='BLOCKED_PAYLOAD_RECOVERY_QUARANTINE')throw new RuntimeException('PSTE_EDITORIAL_FINAL_RECOVERY_QUARANTINE_INVALID');
                if(isset($payload['normal_metadata_path'])||isset($payload['editorialization'])||trim((string)($payload['production_title']??''))!==''||trim((string)($payload['editorial_title']??''))!=='')throw new RuntimeException('PSTE_EDITORIAL_FINAL_RECOVERY_QUARANTINE_SEMANTIC_AUTHORITY_PRESENT');
                $guard=(array)($payload['recovery_quarantine_editorial_guard']??[]);if(($guard['contract']??'')!=='PSTE_RECOVERY_QUARANTINE_EDITORIAL_GUARD_V1'||!empty($guard['semantic_recompute_attempted'])||!empty($guard['sandbox_admission_attempted'])||!empty($guard['production_handoff_attempted'])||!empty($guard['article_or_taxonomy_write_attempted']))throw new RuntimeException('PSTE_EDITORIAL_FINAL_RECOVERY_QUARANTINE_GUARD_INVALID');
                continue;
            }
            $editorialization=is_array($payload['editorialization']??null)?(array)$payload['editorialization']:[];
            if(!hash_equals(PSTE_Editorializer::RULESET,(string)($editorialization['contract']??'')))throw new RuntimeException('PSTE_EDITORIAL_FINAL_EDITORIALIZATION_NOT_CURRENT');
            $path=is_array($payload['normal_metadata_path']??null)?(array)$payload['normal_metadata_path']:[];
            if((string)($path['contract']??'')!==PSTE_Normal_Metadata_Path::CONTRACT)throw new RuntimeException('PSTE_EDITORIAL_FINAL_NORMAL_PATH_NOT_CURRENT');
            $raw=PSTE_Editorializer::sourceQuery($payload);
            if(!PSTE_Normal_Metadata_Path::payloadMatchesNormalPath($payload,$path))throw new RuntimeException('PSTE_EDITORIAL_FINAL_NORMAL_PATH_RAW_HASH_MISMATCH');
            foreach(['five_field_handoff_created','production_handoff_attempted','article_or_taxonomy_write_attempted','write_attempted'] as $flag){
                if(!empty($path[$flag]))throw new RuntimeException('PSTE_EDITORIAL_FINAL_NORMAL_PATH_WRITE_BOUNDARY_VIOLATION_'.strtoupper($flag));
            }
        }
        return ['contract'=>'PSTE_EDITORIAL_RULESET_FINAL_VERIFY_V1','ruleset'=>PSTE_Editorializer::RULESET,'topic_count'=>(int)$inv['topic_count'],'raw_source_sha256'=>(string)$inv['raw_source_sha256'],'raw_keyword_sha256'=>(string)$inv['raw_keyword_sha256'],'raw_keyword_invariant'=>'PASS','raw_keyword_mirror_invariant'=>'PASS','storage'=>$storage,'relations'=>'PASS'];
    }

    /**
     * Immutable raw-source evidence across an editorial metadata rebuild.
     *
     * Important: raw_keyword_preserved/raw_keyword_sha256 are derived mirror fields
     * that did not exist in older persisted payloads. They must therefore NOT be
     * part of the before/after source invariant; otherwise the legitimate act of
     * adding those mirrors during an upgrade falsely looks like keyword mutation.
     * The mirrors are validated independently after the rebuild.
     *
     * @return array{topic_count:int,raw_source_sha256:string,raw_keyword_sha256:string}
     */
    private static function editorialRulesetInvariant(array $rows): array {
        $items=[];
        foreach($rows as $row){
            $payload=json_decode((string)($row['payload_json']??''),true);
            if(!is_array($payload))throw new RuntimeException('PSTE_EDITORIAL_RULESET_INVARIANT_PAYLOAD_INVALID');
            $items[]=[
                'pool_key'=>(string)($row['pool_key']??''),
                'raw_user_question'=>$payload['raw_user_question']??null,
                'primary_longtail_query'=>$payload['primary_longtail_query']??null,
                'canonical_query'=>$payload['canonical_query']??null,
                'query_record'=>$payload['query_record']??null,
                'query_aliases'=>$payload['query_aliases']??null,
            ];
        }
        $json=wp_json_encode($items,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
        if(!is_string($json))throw new RuntimeException('PSTE_EDITORIAL_RULESET_INVARIANT_ENCODE_FAILED');
        $sha=hash('sha256',$json);
        // raw_keyword_sha256 is kept as a report-compatibility alias.
        return ['topic_count'=>count($items),'raw_source_sha256'=>$sha,'raw_keyword_sha256'=>$sha];
    }

    /** Validate the newly materialized keyword mirror without treating it as source evidence. */
    private static function assertEditorialKeywordMirrors(array $rows): void {
        foreach($rows as $row){
            $payload=json_decode((string)($row['payload_json']??''),true);
            if(!is_array($payload))throw new RuntimeException('PSTE_EDITORIAL_RULESET_MIRROR_PAYLOAD_INVALID');
            $raw=PSTE_Editorializer::sourceQuery($payload);
            $expectedSha=$raw!==''?hash('sha256',$raw):'';
            if((string)($payload['raw_keyword_preserved']??'')!==$raw
                ||(string)($payload['raw_keyword_sha256']??'')!==$expectedSha){
                throw new RuntimeException('PSTE_EDITORIAL_RULESET_RAW_KEYWORD_MIRROR_INVALID');
            }
        }
    }

    /**
     * Applies one already relevance-cleared, dual-strand Sandbox reentry envelope to SEO metadata only.
     * Raw keyword fields are immutable; no posts, terms, PPM, compiler or production data are touched.
     * @return array<string,mixed>
     */
    public static function applySandboxReentryEnvelope(array $envelope,string $expectedEnvelopeSha256=''): array {
        $poolKey=(string)($envelope['pool_key']??'');if($poolKey==='')throw new RuntimeException('PSTE_SANDBOX_REENTRY_IDENTITY_INVALID');
        $actualEnvelopeSha=self::stableValueHash($envelope);
        if($expectedEnvelopeSha256!==''&&(!preg_match('/^[a-f0-9]{64}$/',$expectedEnvelopeSha256)||!hash_equals($actualEnvelopeSha,$expectedEnvelopeSha256)))throw new RuntimeException('PSTE_SANDBOX_REENTRY_ENVELOPE_HASH_MISMATCH');
        $envelopeSha=$expectedEnvelopeSha256!==''?$expectedEnvelopeSha256:$actualEnvelopeSha;
        global $wpdb;$table=self::table('topic_pool');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE pool_key=%s",$poolKey),ARRAY_A);if(!is_array($row))throw new RuntimeException('PSTE_SANDBOX_REENTRY_POOL_ROW_MISSING');
        $payloadJson=(string)($row['payload_json']??'');$payload=json_decode($payloadJson,true);if(!is_array($payload))throw new RuntimeException('PSTE_SANDBOX_REENTRY_PAYLOAD_INVALID');

        // Cross-store recovery: if the DB commit already succeeded but the Sandbox option
        // could not be marked afterwards, retry returns the durable receipt without writing again.
        $receipt=(array)($payload['sandbox_reentry_receipt']??[]);
        if(($receipt['contract']??'')==='PSTE_SANDBOX_REENTRY_RECEIPT_V1'&&($receipt['status']??'')==='PASS'&&hash_equals((string)($receipt['envelope_sha256']??''),$envelopeSha)){
            $receiptSha=(string)($receipt['receipt_sha256']??'');$receiptBody=$receipt;unset($receiptBody['receipt_sha256']);
            if(!preg_match('/^[a-f0-9]{64}$/',$receiptSha)||!hash_equals(self::stableValueHash($receiptBody),$receiptSha))throw new RuntimeException('PSTE_SANDBOX_REENTRY_RECEIPT_HASH_INVALID');
            $rawNow=PSTE_Editorializer::sourceQuery($payload);$pathNow=is_array($payload['normal_metadata_path']??null)?(array)$payload['normal_metadata_path']:[];$pathRawNow=PSTE_Normal_Metadata_Path::canonicalInputQuery((string)($pathNow['raw_query']??''));$titleNow=(string)($payload['production_title']??'');$typeNow=(string)($payload['proposed_article_type']??'');$categoryNow=(int)($payload['target_category_id']??0);
            if($rawNow===''||$pathRawNow===''||!PSTE_Normal_Metadata_Path::payloadMatchesNormalPath($payload,$pathNow)||!hash_equals((string)($receipt['raw_query_sha256']??''),hash('sha256',$pathRawNow))||!hash_equals((string)($receipt['title_sha256']??''),hash('sha256',$titleNow))||(string)($receipt['article_type']??'')!==$typeNow||(int)($receipt['category_id']??0)!==$categoryNow)throw new RuntimeException('PSTE_SANDBOX_REENTRY_RECEIPT_STATE_DRIFT');
            return ['contract'=>'PSTE_SANDBOX_REENTRY_APPLY_V4_ATOMIC_IDEMPOTENT','status'=>'PASS','pool_key'=>$poolKey,'automatic_pool_status'=>(string)($payload['automatic_pool_status']??'AUTO_RESOLVED'),'planning_suitability'=>(string)($payload['planning_suitability']??''),'raw_query_sha256'=>hash('sha256',$pathRawNow),'title'=>$titleNow,'category_id'=>$categoryNow,'article_type'=>$typeNow,'reentry_receipt_sha256'=>(string)($receipt['receipt_sha256']??''),'idempotent_replay'=>true,'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'seo_topic_metadata_write_only'=>true];
        }

        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_REENTRY_BASELINE_REQUIRED');
        $prepared=PSTE_Normal_Reentry_Coordinator::prepare($envelope,$payload,$baseline);$familyKey=(string)$prepared['family_key'];
        $original=['raw_user_question'=>$payload['raw_user_question']??null,'primary_longtail_query'=>$payload['primary_longtail_query']??null,'canonical_query'=>$payload['canonical_query']??null,'query_record'=>$payload['query_record']??null,'query_aliases'=>$payload['query_aliases']??null];
        $relevanceProof=(array)($prepared['relevance_proof']??[]);$payload=PSTE_Normal_Metadata_Path::applyToPayload($payload,$baseline,$familyKey,$relevanceProof);$path=(array)($payload['normal_metadata_path']??[]);
        if(($path['status']??'')!=='NORMAL_PASS'||empty($path['ok']))throw new RuntimeException('PSTE_SANDBOX_REENTRY_SHARED_NORMAL_PATH_NOT_PASS');
        foreach($original as $field=>$value)if(($payload[$field]??null)!==$value)throw new RuntimeException('PSTE_SANDBOX_REENTRY_RAW_SOURCE_FIELD_MUTATION_'.$field);
        $raw=(string)($path['raw_query']??'');$type=(string)($path['article_type']??'');$target=(array)($path['target_category']??[]);$title=(string)($path['title']??'');
        if($raw===''||$type===''||$title===''||(int)($target['term_id']??0)<=0)throw new RuntimeException('PSTE_SANDBOX_REENTRY_SHARED_PATH_OUTPUT_INCOMPLETE');
        if(!hash_equals((string)($prepared['raw_query_sha256']??''),hash('sha256',$raw))||!hash_equals((string)($prepared['family_key']??''),(string)($path['family_key']??'')))throw new RuntimeException('PSTE_SANDBOX_REENTRY_PREPARE_APPLY_DRIFT');
        $payload['reason_codes']=array_values(array_unique(array_merge((array)($payload['reason_codes']??[]),['SANDBOX_REENTRY_NORMAL_PIPELINE_PASS'])));
        $automatic=self::automaticPoolStatus($payload);if($automatic!=='AUTO_RESOLVED')throw new RuntimeException('PSTE_SANDBOX_REENTRY_NOT_AUTO_RESOLVED');
        $role=PSTE_Topic_Policy::classifyRole($payload);$context=(string)($row['context_state']??'PENDING');$planning=PSTE_Topic_Policy::planningSuitability(array_merge($payload,['topic_role'=>$role]),$automatic,$context);$payload['topic_role']=$role;$payload['planning_suitability']=$planning;$payload['context_state']=$context;$payload['automatic_pool_status']=$automatic;
        $receipt=['contract'=>'PSTE_SANDBOX_REENTRY_RECEIPT_V1','status'=>'PASS','envelope_sha256'=>$envelopeSha,'raw_query_sha256'=>hash('sha256',$raw),'family_key'=>(string)$path['family_key'],'title_sha256'=>hash('sha256',$title),'category_id'=>(int)$target['term_id'],'article_type'=>$type,'applied_at_utc'=>gmdate('c'),'five_field_handoff_created'=>false,'production_handoff_attempted'=>false];
        $receipt['receipt_sha256']=self::stableValueHash($receipt);$payload['sandbox_reentry_receipt']=$receipt;
        $newJson=self::encodeJsonValue($payload,'PSTE_SANDBOX_REENTRY_PAYLOAD');

        self::beginOwnedTransaction('PSTE_SANDBOX_REENTRY_TX_START');
        try{
            $updated=self::checkedUpdate($table,['automatic_decision'=>'PASS','automatic_pool_status'=>$automatic,'topic_role'=>$role,'planning_suitability'=>$planning,'current_category_id'=>(int)$target['term_id'],'payload_json'=>$newJson],['pool_key'=>$poolKey,'payload_json'=>$payloadJson],['%s','%s','%s','%s','%d','%s'],['%s','%s'],'PSTE_SANDBOX_REENTRY_UPDATE_FAILED');
            if($updated!==1)throw new RuntimeException('PSTE_SANDBOX_REENTRY_CONCURRENT_CHANGE_OR_UPDATE_FAILED');self::assertTopicPayloadPersisted($poolKey,$newJson,'PSTE_SANDBOX_REENTRY_READBACK_MISMATCH');
            self::upsertTopicAssignment($poolKey,(int)$target['term_id'],(string)$target['name'],$type,'SANDBOX_NORMAL_REENTRY','CONFIRMED',1.0,['SANDBOX_REENTRY_SHARED_NORMAL_PATH_PASS'],['production_release'=>false,'title'=>$title,'raw_query_sha256'=>hash('sha256',$raw),'reentry_receipt_sha256'=>(string)$receipt['receipt_sha256']]);
            self::recordTopicHistory($poolKey,'SANDBOX_NORMAL_REENTRY',(string)($row['automatic_pool_status']??''),$automatic,['raw_query_sha256'=>hash('sha256',$raw),'title_sha256'=>hash('sha256',$title),'category_id'=>(int)$target['term_id'],'article_type'=>$type,'reentry_receipt_sha256'=>(string)$receipt['receipt_sha256'],'five_field_handoff_created'=>false],0);
            self::commitOwnedTransaction('PSTE_SANDBOX_REENTRY_TX_COMMIT');
        }catch(Throwable $e){self::rollbackOwnedTransaction('PSTE_SANDBOX_REENTRY_TX_ROLLBACK');throw $e;}
        return ['contract'=>'PSTE_SANDBOX_REENTRY_APPLY_V4_ATOMIC_IDEMPOTENT','status'=>'PASS','pool_key'=>$poolKey,'automatic_pool_status'=>$automatic,'planning_suitability'=>$planning,'raw_query_sha256'=>hash('sha256',$raw),'title'=>$title,'category_id'=>(int)$target['term_id'],'article_type'=>$type,'reentry_receipt_sha256'=>(string)$receipt['receipt_sha256'],'idempotent_replay'=>false,'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'seo_topic_metadata_write_only'=>true];
    }

    private static function stableValueHash($value): string {
        $value=self::canonicalizeValue($value);$json=wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
        if(!is_string($json))throw new RuntimeException('PSTE_STABLE_HASH_ENCODE_FAILED');return hash('sha256',$json);
    }
    private static function canonicalizeValue($value){if(!is_array($value))return $value;if($value===[])return [];$list=array_keys($value)===range(0,count($value)-1);if($list)return array_map([self::class,'canonicalizeValue'],$value);ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=self::canonicalizeValue($v);return $value;}

    private static function prepareEditorialPayload(array $payload): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_NORMAL_METADATA_PATH_BASELINE_REQUIRED');
        return PSTE_Normal_Metadata_Path::applyToPayload($payload,$baseline,(string)($payload['topic_family_key']??''));
    }

    private static function recordTopicHistory(string $poolKey,string $action,string $from,string $to,array $details,int $userId): void {
        self::checkedInsert(self::table('topic_history'),['pool_key'=>$poolKey,'action'=>$action,'from_status'=>$from,'to_status'=>$to,'details_json'=>self::encodeJsonValue($details,'PSTE_TOPIC_HISTORY_DETAILS'),'user_id'=>$userId,'created_at'=>gmdate('Y-m-d H:i:s')],['%s','%s','%s','%s','%s','%d','%s'],'PSTE_TOPIC_HISTORY_INSERT_FAILED');
    }

    public static function saveManualDecision(string $poolKey,string $status,int $categoryId,string $articleType,string $note,int $userId,bool $hardOverrideConfirmed=false): void {
        global $wpdb;$allowed=['AUTO','APPROVED','REVIEW_REQUIRED','BLOCKED_FOR_CATEGORY','DISCOVERY_ONLY','REJECTED','REASSIGNED'];if(!in_array($status,$allowed,true))throw new RuntimeException('PSTE_REVIEW_ACTION_INVALID');
        $table=self::table('topic_pool');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE pool_key=%s",$poolKey),ARRAY_A);if(!$row)throw new RuntimeException('PSTE_TOPIC_POOL_ITEM_NOT_FOUND');
        $candidate=json_decode((string)$row['payload_json'],true);if(!is_array($candidate)||json_last_error()!==JSON_ERROR_NONE)throw new RuntimeException('PSTE_MANUAL_DECISION_PAYLOAD_INVALID');$hard=PSTE_Topic_Policy::presentHardCodes($candidate);$nonOverridable=PSTE_Topic_Policy::presentNonOverridableCodes($candidate);
        if($status==='APPROVED'&&$nonOverridable)throw new RuntimeException('PSTE_NON_OVERRIDABLE_HARD_BLOCK');
        if($status==='APPROVED'&&$hard&&!$hardOverrideConfirmed)throw new RuntimeException('PSTE_HARD_BLOCK_CONFIRMATION_REQUIRED');
        if($status==='APPROVED'&&$hard&&trim($note)==='')throw new RuntimeException('PSTE_HARD_BLOCK_OVERRIDE_REASON_REQUIRED');
        $from=(string)($row['manual_status']?:$row['automatic_pool_status']);$manual=$status==='AUTO'?'':$status;$currentCategory=(int)$row['original_category_id'];
        if($status==='REASSIGNED'){if($categoryId<=0)throw new RuntimeException('PSTE_REASSIGN_TARGET_REQUIRED');$currentCategory=$categoryId;}elseif($status!=='AUTO'&&(int)$row['current_category_id']>0)$currentCategory=(int)$row['current_category_id'];
        $effective=$manual!==''?$manual:(string)$row['automatic_pool_status'];$role=(string)($row['topic_role']??PSTE_Topic_Policy::classifyRole($candidate));if($status==='APPROVED'||$status==='REASSIGNED')$role=PSTE_Topic_Policy::ROLE_ARTICLE_TOPIC;elseif($status==='DISCOVERY_ONLY')$role=PSTE_Topic_Policy::ROLE_RESEARCH_KEYWORD;elseif($status==='BLOCKED_FOR_CATEGORY')$role=PSTE_Topic_Policy::ROLE_ALREADY_COVERED;elseif($status==='REJECTED')$role=PSTE_Topic_Policy::ROLE_NON_EDITORIAL;$planning=PSTE_Topic_Policy::planningSuitability(array_merge($candidate,['topic_role'=>$role]),$effective,(string)($row['context_state']??'PENDING'));
        self::beginTransaction();
        try{
            self::checkedUpdate($table,['manual_status'=>$manual,'manual_category_id'=>$status==='REASSIGNED'?$categoryId:0,'manual_article_type'=>$status==='REASSIGNED'?$articleType:'','manual_note'=>$note,'current_category_id'=>$currentCategory,'topic_role'=>$role,'planning_suitability'=>$planning,'reviewed_at'=>gmdate('Y-m-d H:i:s'),'reviewed_by'=>$userId],['pool_key'=>$poolKey],['%s','%d','%s','%s','%d','%s','%s','%s','%d'],['%s'],'PSTE_MANUAL_DECISION_UPDATE_FAILED');
            $to=$manual!==''?$manual:(string)$row['automatic_pool_status'];self::recordTopicHistory($poolKey,'MANUAL_DECISION',$from,$to,['category_id'=>$categoryId,'article_type'=>$articleType,'note'=>$note,'hard_codes'=>$hard,'hard_override_confirmed'=>$hardOverrideConfirmed],$userId);
            if($status==='REASSIGNED')self::upsertTopicAssignment($poolKey,$categoryId,self::categoryNameById($categoryId),$articleType,'MANUAL_REASSIGNMENT','CONFIRMED',1.0,['MANUAL_DECISION'],['note'=>$note,'user_id'=>$userId]);
            self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
    }

    /**
     * Persist one title-only override. No semantic reclassification, category change, plan change,
     * article-type change, content generation or production handoff is permitted here.
     * @return array<string,mixed>
     */
    public static function saveManualTitleOverride(string $poolKey,string $title,int $userId): array {
        global $wpdb;$poolKey=trim($poolKey);$title=trim((string)preg_replace('/\s+/u',' ',$title));if($poolKey===''||$title==='')throw new RuntimeException('PSTE_MANUAL_TITLE_OVERRIDE_INPUT_REQUIRED');
        $table=self::table('topic_pool');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE pool_key=%s",$poolKey),ARRAY_A);if(!is_array($row))throw new RuntimeException('PSTE_MANUAL_TITLE_OVERRIDE_TOPIC_NOT_FOUND');
        if(!in_array((string)($row['context_state']??'PENDING'),['CURRENT','NOT_REQUIRED'],true))throw new RuntimeException('PSTE_MANUAL_TITLE_OVERRIDE_CONTEXT_NOT_CURRENT');
        $payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload))throw new RuntimeException('PSTE_MANUAL_TITLE_OVERRIDE_PAYLOAD_INVALID');
        $rawSource=PSTE_Editorializer::sourceQuery($payload);$raw=PSTE_Normal_Metadata_Path::canonicalInputQuery($rawSource);$family=(string)($payload['topic_family_name']??'');$familyKey=(string)($payload['topic_family_key']??'');$type=(string)($payload['proposed_article_type']??'');$categoryId=(int)($payload['target_category_id']??0);$categorySlug=(string)($payload['target_category_slug']??'');$intentKey=(string)($payload['editorial_intent_key']??$payload['intent_profile']['intent_key']??'');$targetKeyword=(string)($payload['target_keyword']??'');$normalized=(string)($payload['normalized_editorial_topic']??'');$oldTitle=(string)($payload['production_title']??'');
        if($raw===''||$family===''||$familyKey===''||$type===''||$categoryId<=0||$categorySlug===''||$intentKey===''||$targetKeyword===''||$oldTitle==='')throw new RuntimeException('PSTE_MANUAL_TITLE_OVERRIDE_BINDING_INCOMPLETE');
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_MANUAL_TITLE_OVERRIDE_BASELINE_REQUIRED');$registry=PSTE_Article_Type_Registry::build($baseline);
        $validated=PSTE_Title_Pipeline::validateExistingTitle($title,$raw,$family,$type,$registry,(array)($payload['intent_profile']??[]),$targetKeyword,$normalized);
        if(empty($validated['ok'])){
            $overrideReasons=[];foreach(['deterministic','language','editorial_quality'] as $gate){foreach((array)($validated[$gate]['reason_codes']??[]) as $reason)$overrideReasons[]=(string)$reason;}
            throw new RuntimeException('PSTE_MANUAL_TITLE_OVERRIDE_INVALID_'.implode('_',array_values(array_unique(array_filter($overrideReasons)))));
        }
        $binding=['raw_query_sha256'=>hash('sha256',$raw),'family_key'=>$familyKey,'article_type'=>$type,'category_id'=>$categoryId,'category_slug'=>$categorySlug,'intent_key'=>$intentKey,'target_keyword_sha256'=>hash('sha256',$targetKeyword)];
        $existingOverride=is_array($payload['manual_title_override']??null)?(array)$payload['manual_title_override']:[];
        $baseTitle=(($existingOverride['contract']??'')==='PSTE_MANUAL_TITLE_OVERRIDE_V1'&&trim((string)($existingOverride['base_title']??''))!=='')?trim((string)$existingOverride['base_title']):$oldTitle;
        $override=['contract'=>'PSTE_MANUAL_TITLE_OVERRIDE_V1','title'=>$title,'base_title'=>$baseTitle,'title_sha256'=>hash('sha256',$title),'base_title_sha256'=>hash('sha256',$baseTitle),'binding'=>$binding,'saved_at_utc'=>gmdate('c'),'saved_by'=>$userId,'semantic_reassignment_allowed'=>false,'category_change_allowed'=>false,'article_type_change_allowed'=>false,'plan_or_slot_change_allowed'=>false,'content_or_design_change_allowed'=>false];
        $before=['topic_family_key'=>$familyKey,'proposed_article_type'=>$type,'target_category_id'=>$categoryId,'target_category_slug'=>$categorySlug,'editorial_intent_key'=>$intentKey,'target_keyword'=>$targetKeyword,'raw_query_sha256'=>hash('sha256',$raw)];
        $payload['manual_title_override']=$override;$payload['production_title']=$title;$payload['editorial_title']=$title;$payload['title_quality']=(array)($validated['deterministic']??[]);$payload['language_quality']=(array)($validated['language']??[]);$payload['editorial_quality_gate']=(array)($validated['editorial_quality']??[]);$payload['editorial_dual_strand']=['technical'=>(array)($validated['technical_strand']??[]),'editorial'=>(array)($validated['editorial_strand']??[])];
        if(is_array($payload['normal_metadata_path']??null)){$payload['normal_metadata_path']['title']=$title;$payload['normal_metadata_path']['title_pipeline']=$validated;$payload['normal_metadata_path']['manual_title_override_status']='APPLIED';$payload['normal_metadata_path']['manual_title_override_sha256']=hash('sha256',$title);}
        if(is_array($payload['editorialization']??null)){$payload['editorialization']['title']=$title;$payload['editorialization']['title_pipeline']=$validated;}
        $after=['topic_family_key'=>(string)($payload['topic_family_key']??''),'proposed_article_type'=>(string)($payload['proposed_article_type']??''),'target_category_id'=>(int)($payload['target_category_id']??0),'target_category_slug'=>(string)($payload['target_category_slug']??''),'editorial_intent_key'=>(string)($payload['editorial_intent_key']??''),'target_keyword'=>(string)($payload['target_keyword']??''),'raw_query_sha256'=>hash('sha256',PSTE_Normal_Metadata_Path::canonicalInputQuery(PSTE_Editorializer::sourceQuery($payload)))];
        if($before!==$after)throw new RuntimeException('PSTE_MANUAL_TITLE_OVERRIDE_NON_TITLE_STATE_CHANGED');
        $oldJson=(string)$row['payload_json'];$newJson=self::encodeJsonValue($payload,'PSTE_MANUAL_TITLE_OVERRIDE_PAYLOAD');
        self::beginTransaction();try{
            $updated=self::checkedUpdate($table,['payload_json'=>$newJson],['pool_key'=>$poolKey,'payload_json'=>$oldJson],['%s'],['%s','%s'],'PSTE_MANUAL_TITLE_OVERRIDE_UPDATE_FAILED');if($updated!==1)throw new RuntimeException('PSTE_MANUAL_TITLE_OVERRIDE_CONCURRENT_CHANGE');self::assertTopicPayloadPersisted($poolKey,$newJson,'PSTE_MANUAL_TITLE_OVERRIDE_READBACK_FAILED');
            self::recordTopicHistory($poolKey,'MANUAL_TITLE_OVERRIDE',(string)($row['manual_status']?:$row['automatic_pool_status']),(string)($row['manual_status']?:$row['automatic_pool_status']),['old_title_sha256'=>hash('sha256',$oldTitle),'new_title_sha256'=>hash('sha256',$title),'binding'=>$binding,'category_or_type_changed'=>false,'content_or_design_touched'=>false],$userId);self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
        return ['contract'=>'PSTE_MANUAL_TITLE_OVERRIDE_RESULT_V1','status'=>'PASS','pool_key'=>$poolKey,'old_title_sha256'=>hash('sha256',$oldTitle),'new_title_sha256'=>hash('sha256',$title),'binding'=>$binding,'category_or_type_changed'=>false,'intent_changed'=>false,'plan_or_slot_changed'=>false,'content_or_design_touched'=>false];
    }

    public static function hardOverrideInfo(string $poolKey): array {
        global $wpdb;$raw=(string)$wpdb->get_var($wpdb->prepare("SELECT payload_json FROM ".self::table('topic_pool')." WHERE pool_key=%s",$poolKey));$candidate=json_decode($raw,true);if(!is_array($candidate))return ['hard_codes'=>[],'non_overridable'=>[]];return ['hard_codes'=>PSTE_Topic_Policy::presentHardCodes($candidate),'non_overridable'=>PSTE_Topic_Policy::presentNonOverridableCodes($candidate)];
    }

    private static function topicOccurrences(string $topicKey,int $limit=100): array {
        global $wpdb;$limit=min(1000,max(1,$limit));$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".self::table('topic_occurrences')." WHERE topic_key=%s ORDER BY id ASC LIMIT %d",$topicKey,$limit),ARRAY_A)?:[];foreach($rows as &$row)$row['payload']=json_decode((string)$row['payload_json'],true)?:[];unset($row);return $rows;
    }

    private static function topicAssignments(string $topicKey,int $limit=100): array {
        global $wpdb;$limit=min(1000,max(1,$limit));$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".self::table('topic_assignments')." WHERE topic_key=%s ORDER BY confidence DESC,id ASC LIMIT %d",$topicKey,$limit),ARRAY_A)?:[];foreach($rows as &$row){$row['reason_codes']=json_decode((string)$row['reason_codes_json'],true)?:[];$row['payload']=json_decode((string)$row['payload_json'],true)?:[];}unset($row);return $rows;
    }

    private static function applyPoolRowWithRelations(array $row,array $occurrences,array $assignments): array {
        $candidate=json_decode((string)$row['payload_json'],true);if(!is_array($candidate))$candidate=[];
        $candidate['pool_key']=(string)$row['pool_key'];$candidate['topic_key']=(string)$row['pool_key'];$candidate['global_topic_uuid']=(string)$row['pool_key'];$candidate['normalized_key']=(string)($row['normalized_key']??'');$candidate['automatic_decision']=(string)$row['automatic_decision'];$candidate['automatic_pool_status']=(string)$row['automatic_pool_status'];$candidate['manual_status']=(string)$row['manual_status'];$candidate['pool_status']=$candidate['manual_status']!==''?$candidate['manual_status']:$candidate['automatic_pool_status'];$candidate['occurrence_count']=(int)$row['occurrence_count'];$candidate['first_seen_at']=(string)$row['first_seen_at'];$candidate['last_seen_at']=(string)$row['last_seen_at'];$candidate['manual_note']=(string)$row['manual_note'];$candidate['topic_role']=(string)($row['topic_role']??PSTE_Topic_Policy::classifyRole($candidate));$candidate['planning_suitability']=(string)($row['planning_suitability']??'BLOCKED');$candidate['context_state']=(string)($row['context_state']??'PENDING');$candidate['structure_sha256']=(string)($row['structure_sha256']??'');$candidate['context_synced_at']=(string)($row['context_synced_at']??'');
        $candidate['occurrences']=$occurrences;$candidate['assignments']=$assignments;
        $status=$candidate['pool_status'];$candidate['traffic_light']=self::trafficLightForStatus($status,$candidate['context_state']);
        if($status==='APPROVED'){$candidate['decision']='PASS';$candidate['reason_codes']=array_values(array_unique(array_merge($candidate['reason_codes']??[],['MANUAL_APPROVED'])));$candidate['discovery_only']=false;}
        elseif($status==='AUTO_RESOLVED'){$candidate['decision']='PASS';$candidate['discovery_only']=false;}
        elseif(in_array($status,['REVIEW_REQUIRED','PROVISIONAL_ACCEPTED','PROVISIONAL_REASSIGN'],true)){$candidate['decision']='REVIEW_REQUIRED';$candidate['discovery_only']=false;}
        elseif($status==='REASSIGNED'){$candidate['decision']='REVIEW_REQUIRED';$candidate['discovery_only']=false;$candidate['reason_codes']=array_values(array_unique(array_merge($candidate['reason_codes']??[],['MANUAL_REASSIGNED'])));}
        elseif(in_array($status,['BLOCKED_FOR_CATEGORY','REJECTED'],true)){$candidate['decision']='BLOCKED';$candidate['discovery_only']=false;}
        elseif($status==='DISCOVERY_ONLY'){$candidate['decision']='BLOCKED';$candidate['discovery_only']=true;}
        if((int)$row['manual_category_id']>0){$candidate['target_category_id']=(int)$row['manual_category_id'];$candidate['target_category_name']=self::categoryNameById((int)$row['manual_category_id']);$candidate['target_category_slug']='';}
        if((string)$row['manual_article_type']!=='')$candidate['proposed_article_type']=(string)$row['manual_article_type'];
        $candidate['traffic_light']=self::trafficLightForStatus((string)$candidate['pool_status'],(string)$candidate['context_state']);
        return $candidate;
    }

    private static function applyPoolRow(array $row): array {
        $key=(string)$row['pool_key'];
        return self::applyPoolRowWithRelations($row,self::topicOccurrences($key),self::topicAssignments($key));
    }

    /**
     * Admin-only read model: same candidate semantics as topicPoolCandidates(), but relation rows are
     * prefetched in two bulk SELECTs instead of two SELECTs per topic. No workflow, production,
     * persistence or decision path calls this method.
     */
    public static function adminTopicPoolCandidates(string $filter='attention',string $search='',int $limit=500): array {
        static $allCache=null;
        global $wpdb;
        $limit=min(100000,max(1,$limit));
        if(!is_array($allCache)){
            $poolRows=$wpdb->get_results("SELECT * FROM ".self::table('topic_pool')." ORDER BY last_seen_at DESC,id DESC LIMIT 100000",ARRAY_A)?:[];
            $occRows=$wpdb->get_results("SELECT * FROM ".self::table('topic_occurrences')." ORDER BY topic_key ASC,id ASC",ARRAY_A)?:[];
            $assignmentRows=$wpdb->get_results("SELECT * FROM ".self::table('topic_assignments')." ORDER BY topic_key ASC,confidence DESC,id ASC",ARRAY_A)?:[];
            $occurrences=[];
            foreach($occRows as $row){$key=(string)($row['topic_key']??'');if($key===''||count($occurrences[$key]??[])>=100)continue;$row['payload']=json_decode((string)($row['payload_json']??''),true)?:[];$occurrences[$key][]=$row;}
            $assignments=[];
            foreach($assignmentRows as $row){$key=(string)($row['topic_key']??'');if($key===''||count($assignments[$key]??[])>=100)continue;$row['reason_codes']=json_decode((string)($row['reason_codes_json']??''),true)?:[];$row['payload']=json_decode((string)($row['payload_json']??''),true)?:[];$assignments[$key][]=$row;}
            $allCache=[];
            foreach($poolRows as $row){$key=(string)($row['pool_key']??'');$allCache[]=self::applyPoolRowWithRelations($row,$occurrences[$key]??[],$assignments[$key]??[]);}
        }
        $out=[];$searchNorm=PSTE_Normalizer::exactTopicIdentityText($search);
        foreach(array_slice($allCache,0,$limit) as $candidate){$status=(string)$candidate['pool_status'];$light=(string)($candidate['traffic_light']['code']??'RED');if($filter==='attention'&&!in_array($light,['RED','YELLOW'],true))continue;if($filter==='traffic_red'&&$light!=='RED')continue;if($filter==='traffic_yellow'&&$light!=='YELLOW')continue;if($filter==='traffic_green'&&$light!=='GREEN')continue;if(!in_array($filter,['all','attention','traffic_red','traffic_yellow','traffic_green'],true)&&$status!==$filter)continue;if($searchNorm!==''&&!str_contains(PSTE_Normalizer::exactTopicIdentityText(PSTE_Editorializer::displayTitle($candidate).' '.implode(' ',array_map(static fn($c)=>(string)($c['category_name']??''),(array)($candidate['found_categories']??[])))),$searchNorm))continue;$out[]=$candidate;}
        return $out;
    }

    public static function adminTopicPoolStats(): array {
        $stats=['TOTAL'=>0,'PASS'=>0,'REVIEW_REQUIRED'=>0,'REASSIGN'=>0,'DISCOVERY_ONLY'=>0,'BLOCKED_FOR_CATEGORY'=>0,'APPROVED'=>0,'REJECTED'=>0,'REASSIGNED'=>0,'GREEN'=>0,'YELLOW'=>0,'RED'=>0];
        foreach(self::adminTopicPoolCandidates('all','',100000) as $candidate){$status=(string)($candidate['pool_status']??'REVIEW_REQUIRED');$stats['TOTAL']++;$stats[$status]=($stats[$status]??0)+1;$light=(string)($candidate['traffic_light']['code']??'RED');$stats[$light]=($stats[$light]??0)+1;}
        global $wpdb;$stats['OCCURRENCES']=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::table('topic_occurrences'));$stats['ASSIGNMENTS']=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::table('topic_assignments'));$stats['MERGE_CANDIDATES']=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::table('topic_merge_candidates')." WHERE status='SUGGESTED'");return $stats;
    }

    public static function topicPoolCandidates(string $filter='attention',string $search='',int $limit=500): array {
        global $wpdb;$limit=min(100000,max(1,$limit));$rows=$wpdb->get_results("SELECT * FROM ".self::table('topic_pool')." ORDER BY last_seen_at DESC,id DESC LIMIT $limit",ARRAY_A)?:[];$out=[];$searchNorm=PSTE_Normalizer::exactTopicIdentityText($search);
        foreach($rows as $row){$candidate=self::applyPoolRow($row);$status=(string)$candidate['pool_status'];$light=(string)($candidate['traffic_light']['code']??'RED');if($filter==='attention'&&!in_array($light,['RED','YELLOW'],true))continue;if($filter==='traffic_red'&&$light!=='RED')continue;if($filter==='traffic_yellow'&&$light!=='YELLOW')continue;if($filter==='traffic_green'&&$light!=='GREEN')continue;if(!in_array($filter,['all','attention','traffic_red','traffic_yellow','traffic_green'],true)&&$status!==$filter)continue;if($searchNorm!==''&&!str_contains(PSTE_Normalizer::exactTopicIdentityText(PSTE_Editorializer::displayTitle($candidate).' '.implode(' ',array_map(static fn($c)=>(string)($c['category_name']??''),(array)($candidate['found_categories']??[])))),$searchNorm))continue;$out[]=$candidate;}
        return $out;
    }

    public static function topicPoolStats(): array {
        $stats=['TOTAL'=>0,'PASS'=>0,'REVIEW_REQUIRED'=>0,'REASSIGN'=>0,'DISCOVERY_ONLY'=>0,'BLOCKED_FOR_CATEGORY'=>0,'APPROVED'=>0,'REJECTED'=>0,'REASSIGNED'=>0,'GREEN'=>0,'YELLOW'=>0,'RED'=>0];
        foreach(self::topicPoolCandidates('all','',100000) as $candidate){$status=(string)($candidate['pool_status']??'REVIEW_REQUIRED');$stats['TOTAL']++;$stats[$status]=($stats[$status]??0)+1;$light=(string)($candidate['traffic_light']['code']??'RED');$stats[$light]=($stats[$light]??0)+1;}
        global $wpdb;$stats['OCCURRENCES']=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::table('topic_occurrences'));$stats['ASSIGNMENTS']=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::table('topic_assignments'));$stats['MERGE_CANDIDATES']=(int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::table('topic_merge_candidates')." WHERE status='SUGGESTED'");return $stats;
    }

    public static function topicHistory(string $poolKey,int $limit=50): array {global $wpdb;$limit=min(200,max(1,$limit));return $wpdb->get_results($wpdb->prepare("SELECT * FROM ".self::table('topic_history')." WHERE pool_key=%s ORDER BY id DESC LIMIT %d",$poolKey,$limit),ARRAY_A)?:[];}

    /** Immediately refresh only the topics created by the current one-click research run. */
    public static function refreshPortalContextForKeys(array $poolKeys,array $inventory,array $plan,string $structureHash): array {
        global $wpdb;
        $poolKeys=array_values(array_unique(array_filter(array_map('strval',$poolKeys))));
        if(!$poolKeys)return ['processed'=>0,'last_id'=>0];
        if($structureHash==='')throw new RuntimeException('PSTE_CONTEXT_STRUCTURE_HASH_MISSING');
        $rows=[];
        foreach($poolKeys as $poolKey){
            $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table('topic_pool')." WHERE pool_key=%s",$poolKey),ARRAY_A);
            if(!is_array($row))throw new RuntimeException('PSTE_CONTEXT_TOPIC_NOT_FOUND_'.$poolKey);
            $rows[]=$row;
        }
        $index=PSTE_Context_Evaluator::buildIndex($inventory,$plan);
        $result=self::refreshPortalContextBatch($rows,$inventory,$plan,$index,$structureHash);
        if((int)($result['processed']??-1)!==count($poolKeys))throw new RuntimeException('PSTE_CONTEXT_TARGETED_REFRESH_INCOMPLETE');
        return $result;
    }

    public static function refreshPortalContext(): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');return PSTE_Context_Refresh::start($baseline,'LEGACY_REFRESH_REQUEST');
    }

    public static function topicPoolCount(): int { global $wpdb;return (int)$wpdb->get_var("SELECT COUNT(*) FROM ".self::table('topic_pool')); }
    public static function contextBatchRows(int $cursorId,int $limit): array {global $wpdb;$limit=min(500,max(1,$limit));return $wpdb->get_results($wpdb->prepare("SELECT * FROM ".self::table('topic_pool')." WHERE id>%d ORDER BY id ASC LIMIT %d",$cursorId,$limit),ARRAY_A)?:[];}

    public static function markAllContextPending(string $structureHash): void {
        global $wpdb;
        self::checkedQuery($wpdb->prepare(
            "UPDATE ".self::table('topic_pool')." SET context_state='PENDING',planning_suitability='BLOCKED',structure_sha256=%s,context_synced_at=NULL",
            $structureHash
        ),'PSTE_CONTEXT_PENDING_UPDATE_FAILED');
    }

    public static function markAllContextBlocked(string $reason,string $structureHash): void {
        global $wpdb;$rows=$wpdb->get_results("SELECT pool_key,payload_json FROM ".self::table('topic_pool'),ARRAY_A)?:[];self::beginTransaction();
        try{
            foreach($rows as $row){
                $payload=json_decode((string)$row['payload_json'],true);
                if(!is_array($payload))throw new RuntimeException('PSTE_CONTEXT_BLOCK_PAYLOAD_INVALID');
                $portal=(array)($payload['portal_context']??[]);
                $portal['error_code']=$reason;
                $portal['synced_at_utc']=gmdate('c');
                $payload['portal_context']=$portal;
                $payload['context_state']='BLOCKED';
                self::checkedUpdate(
                    self::table('topic_pool'),
                    [
                        'context_state'=>'BLOCKED',
                        'planning_suitability'=>'BLOCKED',
                        'structure_sha256'=>$structureHash,
                        'payload_json'=>self::encodeJsonValue($payload,'PSTE_TOPIC_PAYLOAD'),
                    ],
                    ['pool_key'=>(string)$row['pool_key']],
                    ['%s','%s','%s','%s'],
                    ['%s'],
                    'PSTE_CONTEXT_BLOCK_UPDATE_FAILED'
                );
            }
            self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
    }

    public static function refreshPortalContextBatch(array $rows,array $inventory,array $plan,array $index,string $structureHash): array {
        self::beginTransaction();
        $processed=0;$last=0;
        try{
            foreach($rows as $row){
                try{
                    self::refreshPortalContextForRow($row,$inventory,$plan,$index,$structureHash);
                }catch(Throwable $rowError){
                    throw new RuntimeException(
                        'PSTE_CONTEXT_TOPIC_'.(string)($row['pool_key']??'UNKNOWN').':'.$rowError->getMessage(),
                        0,
                        $rowError
                    );
                }
                $last=(int)($row['id']??0);
                $processed++;
            }
            self::assertTopicRelationsConsistent();
            self::commitTransaction();
            return ['processed'=>$processed,'last_id'=>$last];
        }catch(Throwable $e){
            self::rollbackTransaction();
            throw $e;
        }
    }

    public static function refreshPortalContextForRow(array $row,array $inventory,array $plan,array $index,string $structureHash): void {
        global $wpdb;
        $payload=json_decode((string)($row['payload_json']??''),true);
        if(!is_array($payload))throw new RuntimeException('PSTE_TOPIC_PAYLOAD_INVALID');
        $payload=self::prepareEditorialPayload($payload);
        $topicKey=(string)($row['pool_key']??'');
        if($topicKey==='')throw new RuntimeException('PSTE_TOPIC_KEY_MISSING');

        $evaluation=PSTE_Context_Evaluator::evaluate($payload,$inventory,$plan,$index);
        $payload=(array)$evaluation['payload'];

        if((string)$evaluation['state']!=='CURRENT'){
            self::checkedUpdate(
                self::table('topic_pool'),
                [
                    'context_state'=>'BLOCKED',
                    'planning_suitability'=>'BLOCKED',
                    'structure_sha256'=>$structureHash,
                    'context_synced_at'=>gmdate('Y-m-d H:i:s'),
                    'payload_json'=>self::encodeJsonValue($payload,'PSTE_TOPIC_PAYLOAD'),
                ],
                ['pool_key'=>$topicKey],
                ['%s','%s','%s','%s','%s'],
                ['%s'],
                'PSTE_CONTEXT_ROW_BLOCK_UPDATE_FAILED'
            );
            self::assertPoolContextPersisted($topicKey,'BLOCKED');
            return;
        }

        $automatic=self::automaticPoolStatus($payload);
        $payload['automatic_pool_status']=$automatic;
        $effective=(string)(($row['manual_status']??'')!==''?$row['manual_status']:$automatic);
        $role=(string)($row['topic_role']??PSTE_Topic_Policy::classifyRole($payload));
        if((string)($row['manual_status']??'')==='')$role=PSTE_Topic_Policy::classifyRole($payload);
        $planning=PSTE_Topic_Policy::planningSuitability(array_merge($payload,['topic_role'=>$role]),$effective,'CURRENT');
        $payload['topic_role']=$role;
        $payload['planning_suitability']=$planning;

        self::checkedQuery($wpdb->prepare(
            "DELETE FROM ".self::table('topic_assignments')." WHERE topic_key=%s AND assignment_source IN ('WORDPRESS','EDITORIAL_PLAN')",
            $topicKey
        ),'PSTE_CONTEXT_ASSIGNMENT_DELETE_FAILED');

        foreach((array)($evaluation['matches']??[]) as $match){
            $categoryId=(int)($match['category_id']??0);
            $categoryName=(string)($match['category_name']??'');
            if($categoryId<=0&&$categoryName!=='')$categoryId=self::categoryIdByName($categoryName);
            $source=(string)($match['source']??'WORDPRESS');
            self::upsertTopicAssignment(
                $topicKey,
                $categoryId,
                $categoryName,
                (string)($match['article_type']??PSTE_Normalizer::categoryArticleType($categoryName)),
                $source,
                $source==='WORDPRESS'?'EXISTING':'PLANNED',
                max((float)($match['similarity']??0),!empty($match['answer_equivalence'])?1.0:0.0),
                [!empty($match['answer_equivalence'])?'ANSWER_EQUIVALENT':'SEMANTIC_MATCH'],
                [
                    'title'=>(string)($match['title']??''),
                    'post_id'=>(int)($match['post_id']??0),
                    'structure_sha256'=>$structureHash,
                ]
            );
        }

        self::checkedUpdate(
            self::table('topic_pool'),
            [
                'automatic_pool_status'=>$automatic,
                'topic_role'=>$role,
                'planning_suitability'=>$planning,
                'context_state'=>'CURRENT',
                'structure_sha256'=>$structureHash,
                'context_synced_at'=>gmdate('Y-m-d H:i:s'),
                'payload_json'=>self::encodeJsonValue($payload,'PSTE_TOPIC_PAYLOAD'),
            ],
            ['pool_key'=>$topicKey],
            ['%s','%s','%s','%s','%s','%s','%s'],
            ['%s'],
            'PSTE_CONTEXT_POOL_UPDATE_FAILED'
        );
        self::assertPoolContextPersisted($topicKey,'CURRENT');
    }

    private static function assertPoolContextPersisted(string $topicKey,string $expected): void {
        global $wpdb;
        $actual=(string)$wpdb->get_var($wpdb->prepare(
            "SELECT context_state FROM ".self::table('topic_pool')." WHERE pool_key=%s",
            $topicKey
        ));
        if($actual!==$expected)throw new RuntimeException('PSTE_CONTEXT_POOL_UPDATE_NOT_PERSISTED_'.$expected);
    }

    public static function researchCompleteness(): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$leaf=is_array($baseline)?($baseline['leaf_categories']??[]):[];$progress=self::categoryProgress($leaf);$total=(int)($progress['total']??0);$analyzed=(int)($progress['analyzed_total']??0);$pct=$total>0?round(($analyzed/$total)*100,1):0.0;$plan=PSTE_Snapshot::editorialPlan();$context=PSTE_Context_Refresh::status();$contextComplete=(string)($context['status']??'')==='COMPLETE';$complete=$total>0&&$analyzed===$total&&$contextComplete;return ['status'=>$complete?'COMPLETE':'PROVISIONAL','analyzed_categories'=>$analyzed,'total_categories'=>$total,'percent'=>$pct,'editorial_plan_status'=>(string)($plan['status']??'AVAILABLE'),'editorial_plan_sha256'=>(string)($plan['sha256']??'NOT_AVAILABLE'),'context_refresh_status'=>(string)($context['status']??'NOT_STARTED'),'context_processed'=>(int)($context['processed']??0),'context_total'=>(int)($context['total']??0),'final_portal_prioritization_allowed'=>$complete];
    }

    private static function appendReasonCode(string $topicKey,string $reason): void {global $wpdb;$raw=(string)$wpdb->get_var($wpdb->prepare("SELECT payload_json FROM ".self::table('topic_pool')." WHERE pool_key=%s",$topicKey));$payload=json_decode($raw,true);if(!is_array($payload))throw new RuntimeException('PSTE_REASON_PAYLOAD_INVALID');$payload['reason_codes']=array_values(array_unique(array_merge((array)($payload['reason_codes']??[]),[$reason])));self::checkedUpdate(self::table('topic_pool'),['payload_json'=>self::encodeJsonValue($payload,'PSTE_TOPIC_PAYLOAD'),'automatic_pool_status'=>'REVIEW_REQUIRED','planning_suitability'=>'BLOCKED'],['pool_key'=>$topicKey],['%s','%s','%s'],['%s'],'PSTE_REASON_UPDATE_FAILED');}

    private static function recordSemanticMergeCandidates(string $topicKey,array $payload): void {
        global $wpdb;$family=(string)($payload['topic_family_key']??'');$finger=(string)($payload['semantic_fingerprint']??'');if($family===''||$finger==='')return;$rows=$wpdb->get_results($wpdb->prepare("SELECT pool_key,payload_json FROM ".self::table('topic_pool')." WHERE pool_key<>%s ORDER BY id DESC LIMIT 500",$topicKey),ARRAY_A)?:[];$table=self::table('topic_merge_candidates');$now=gmdate('Y-m-d H:i:s');
        foreach($rows as $row){$other=json_decode((string)$row['payload_json'],true);if(!is_array($other)||(string)($other['topic_family_key']??'')!==$family)continue;$otherFinger=(string)($other['semantic_fingerprint']??PSTE_Normalizer::semanticFingerprint((string)($other['canonical_query']??'')));$similarity=PSTE_Normalizer::similarity($finger,$otherFinger);if($similarity<0.78)continue;$otherKey=(string)$row['pool_key'];$a=strcmp($topicKey,$otherKey)<=0?$topicKey:$otherKey;$b=$a===$topicKey?$otherKey:$topicKey;$mergeKey=hash('sha256',$a.'|'.$b);$existing=$wpdb->get_var($wpdb->prepare("SELECT id FROM $table WHERE merge_key=%s",$mergeKey));$data=['source_topic_uuid'=>$a,'target_topic_uuid'=>$b,'similarity'=>$similarity,'match_type'=>'SEMANTIC','status'=>'SUGGESTED','reason_codes_json'=>self::encodeJsonValue(['SEMANTIC_SIMILARITY_MERGE_CANDIDATE'],'PSTE_MERGE_REASON_CODES'),'payload_json'=>self::encodeJsonValue(['non_destructive'=>true,'automatic_merge'=>false],'PSTE_MERGE_PAYLOAD'),'last_seen_at'=>$now];if($existing)self::checkedUpdate($table,$data,['merge_key'=>$mergeKey],['%s','%s','%f','%s','%s','%s','%s','%s'],['%s'],'PSTE_MERGE_CANDIDATE_UPDATE_FAILED');else{$data['merge_key']=$mergeKey;$data['first_seen_at']=$now;self::checkedInsert($table,$data,['%s','%s','%s','%f','%s','%s','%s','%s','%s','%s'],'PSTE_MERGE_CANDIDATE_INSERT_FAILED');}}
    }

    public static function recordCost(string $runUuid, string $endpoint, float $estimated, float $actual): void {
        self::checkedInsert(self::table('cost_ledger'), ['run_uuid'=>$runUuid,'endpoint_key'=>$endpoint,'estimated_cost'=>$estimated,'actual_cost'=>$actual,'recorded_at'=>gmdate('Y-m-d H:i:s')], ['%s','%s','%f','%f','%s'],'PSTE_COST_LEDGER_INSERT_FAILED');
    }

    /** Idempotent within the persistent single-worker job. */
    public static function recordCostOnce(string $runUuid,string $endpoint,float $estimated,float $actual): bool {
        global $wpdb;
        $table=self::table('cost_ledger');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT estimated_cost,actual_cost FROM $table WHERE run_uuid=%s AND endpoint_key=%s ORDER BY id ASC",$runUuid,$endpoint),ARRAY_A)?:[];
        if(count($rows)>1)throw new RuntimeException('PSTE_COST_LEDGER_DUPLICATE_ATTEMPT');
        if(count($rows)===1){
            $storedEstimated=(float)$rows[0]['estimated_cost'];$storedActual=(float)$rows[0]['actual_cost'];
            if(abs($storedEstimated-$estimated)>0.0000005||abs($storedActual-$actual)>0.0000005)throw new RuntimeException('PSTE_COST_LEDGER_ATTEMPT_MISMATCH');
            return false;
        }
        self::recordCost($runUuid,$endpoint,$estimated,$actual);
        $count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table WHERE run_uuid=%s AND endpoint_key=%s",$runUuid,$endpoint));
        if($count!==1)throw new RuntimeException('PSTE_COST_LEDGER_ATTEMPT_READBACK_MISMATCH');
        return true;
    }


    public static function saveEvidence(string $runUuid, string $source, string $sourceReference, array $sanitizedPayload, string $responseSha256): void {
        $evidenceId=hash('sha256',$runUuid.'|'.$source.'|'.$sourceReference.'|'.$responseSha256);
        self::checkedReplace(self::table('evidence'),[
            'evidence_id'=>$evidenceId,'run_uuid'=>$runUuid,'source'=>$source,'source_reference'=>$sourceReference,
            'response_sha256'=>$responseSha256,'sanitized_payload_json'=>self::encodeJsonValue($sanitizedPayload,'PSTE_EVIDENCE_PAYLOAD'),'captured_at'=>gmdate('Y-m-d H:i:s')
        ],['%s','%s','%s','%s','%s','%s','%s'],'PSTE_EVIDENCE_SAVE_FAILED');
    }

    public static function actualCostSince(string $sinceUtc): float {
        global $wpdb;
        return (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(actual_cost),0) FROM ".self::table('cost_ledger')." WHERE recorded_at >= %s",$sinceUtc));
    }

    public static function runByUuid(string $runUuid): ?array {
        global $wpdb;
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table('runs')." WHERE run_uuid=%s",$runUuid),ARRAY_A);
        if(!$row)return null;
        $row['snapshot']=json_decode($row['snapshot_json'],true)?:[];$row['payload']=json_decode($row['payload_json'],true)?:[];return $row;
    }

    public static function latestRun(): ?array {
        global $wpdb;
        $row = $wpdb->get_row("SELECT * FROM " . self::table('runs') . " ORDER BY id DESC LIMIT 1", ARRAY_A);
        if (!$row) { return null; }
        $row['snapshot'] = json_decode($row['snapshot_json'], true) ?: [];
        $row['payload'] = json_decode($row['payload_json'], true) ?: [];
        return $row;
    }


    private static function latestRunRows(): array {
        global $wpdb;
        return $wpdb->get_results("SELECT r.category_id,r.run_uuid,r.status,r.updated_at FROM ".self::table('runs')." r INNER JOIN (SELECT r2.category_id,MAX(r2.id) AS max_id FROM ".self::table('runs')." r2 INNER JOIN ".self::table('candidates')." c2 ON c2.run_uuid=r2.run_uuid GROUP BY r2.category_id) latest ON latest.max_id=r.id",ARRAY_A)?:[];
    }

    public static function previousCandidateInventory(string $excludeRunUuid = ''): array {
        $out=[];foreach(self::allCandidates() as $c){if(!in_array((string)($c['decision']??''),['PASS','REVIEW_REQUIRED'],true))continue;if($excludeRunUuid!==''&&in_array($excludeRunUuid,$c['seen_in_runs']??[],true))continue;$category=(string)($c['target_category_name']??'');$out[]=['post_id'=>0,'title'=>PSTE_Editorializer::displayTitle($c),'status'=>'draft','category_name'=>$category,'topic_family_name'=>$c['topic_family_name']??PSTE_Normalizer::categoryFamilyName($category),'topic_family_key'=>$c['topic_family_key']??PSTE_Normalizer::categoryFamilyKey($category),'headings'=>[],'intent_cluster_id'=>$c['intent_cluster_id']??'','source'=>'PSTE_TOPIC_POOL'];}return $out;
    }

    public static function allCandidates(): array {return self::topicPoolCandidates('all','',100000);}

    public static function categoryProgress(array $leafCategories): array {
        global $wpdb;
        $rows=$wpdb->get_results("SELECT category_id,status,updated_at FROM ".self::table('runs')." ORDER BY id ASC",ARRAY_A);
        $latest=[];foreach($rows as $row){$latest[(int)$row['category_id']]=$row;}
        $items=[];$counts=['NOT_ANALYZED'=>0,'ANALYZED'=>0,'BLOCKED'=>0];
        foreach($leafCategories as $category){$id=(int)($category['term_id']??0);$row=$latest[$id]??null;$state='NOT_ANALYZED';
            if($row){$status=(string)$row['status'];if($status==='BLOCKED')$state='BLOCKED';else $state='ANALYZED';}
            $counts[$state]++;$items[]=['term_id'=>$id,'name'=>(string)($category['name']??''),'slug'=>(string)($category['slug']??''),'state'=>$state,'last_run_status'=>$row['status']??'','updated_at'=>$row['updated_at']??''];
        }
        return ['counts'=>$counts,'items'=>$items,'analyzed_total'=>$counts['ANALYZED']+$counts['BLOCKED'],'total'=>count($items)];
    }

    public static function candidatesForRun(string $runUuid): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT payload_json FROM ".self::table('candidates')." WHERE run_uuid=%s ORDER BY id ASC",$runUuid),ARRAY_A);$out=[];
        foreach($rows as $row){$candidate=json_decode((string)$row['payload_json'],true);if(!is_array($candidate))continue;$key=self::globalTopicKeyForCandidate($candidate);$pool=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".self::table('topic_pool')." WHERE pool_key=%s",$key),ARRAY_A);if(!$pool){$out[]=$candidate;continue;}$global=self::applyPoolRow($pool);foreach(['pool_key','topic_key','automatic_decision','automatic_pool_status','manual_status','pool_status','occurrence_count','first_seen_at','last_seen_at','manual_note','aliases','found_categories','assignments','portal_context'] as $field)if(array_key_exists($field,$global))$candidate[$field]=$global[$field];$status=(string)($candidate['pool_status']??'');if(in_array($status,['APPROVED','AUTO_RESOLVED'],true)){$candidate['decision']='PASS';$candidate['discovery_only']=false;}elseif(in_array($status,['REVIEW_REQUIRED','PROVISIONAL_ACCEPTED','PROVISIONAL_REASSIGN','REASSIGNED'],true)){$candidate['decision']='REVIEW_REQUIRED';$candidate['discovery_only']=false;}elseif(in_array($status,['BLOCKED_FOR_CATEGORY','REJECTED'],true)){$candidate['decision']='BLOCKED';$candidate['discovery_only']=false;}elseif($status==='DISCOVERY_ONLY'){$candidate['decision']='BLOCKED';$candidate['discovery_only']=true;}$out[]=$candidate;}return $out;
    }


    public static function replaceGscRows(string $propertyUrl, string $startDate, string $endDate, array $rows): array {
        global $wpdb;$inserted=0;$synced=gmdate('Y-m-d H:i:s');self::beginTransaction();
        try{
            self::checkedQuery($wpdb->prepare("DELETE FROM ".self::table('gsc_queries')." WHERE property_url=%s",$propertyUrl),'PSTE_GSC_CLEAR_FAILED');
            foreach($rows as $row){$query=trim((string)($row['query']??''));$page=trim((string)($row['page']??''));if($query===''||$page==='')continue;$postId=(int)($row['post_id']??0);$categoryId=(int)($row['category_id']??0);$hash=hash('sha256',$propertyUrl.'|'.$startDate.'|'.$endDate.'|'.$query.'|'.$page);
                self::checkedReplace(self::table('gsc_queries'),['row_hash'=>$hash,'property_url'=>$propertyUrl,'query_text'=>$query,'page_url'=>$page,'post_id'=>$postId,'category_id'=>$categoryId,'clicks'=>(float)($row['clicks']??0),'impressions'=>(float)($row['impressions']??0),'ctr'=>(float)($row['ctr']??0),'position'=>(float)($row['position']??0),'start_date'=>$startDate,'end_date'=>$endDate,'synced_at'=>$synced],['%s','%s','%s','%s','%d','%d','%f','%f','%f','%f','%s','%s','%s'],'PSTE_GSC_ROW_SAVE_FAILED');$inserted++;}
            self::commitTransaction();
        }catch(Throwable $e){self::rollbackTransaction();throw $e;}
        return ['inserted'=>$inserted,'synced_at_utc'=>gmdate('c'),'property_url'=>$propertyUrl,'start_date'=>$startDate,'end_date'=>$endDate];
    }

    public static function gscRows(int $limit=1000): array {
        global $wpdb;$limit=min(25000,max(1,$limit));return $wpdb->get_results($wpdb->prepare("SELECT * FROM ".self::table('gsc_queries')." ORDER BY impressions DESC, clicks DESC LIMIT %d",$limit),ARRAY_A)?:[];
    }

    public static function gscCategorySummary(string $propertyUrl=''): array {
        global $wpdb;if($propertyUrl==='')return [];
        $rows=$wpdb->get_results($wpdb->prepare("SELECT category_id,COUNT(*) AS query_count,SUM(clicks) AS clicks,SUM(impressions) AS impressions,AVG(ctr) AS ctr,AVG(position) AS position FROM ".self::table('gsc_queries')." WHERE property_url=%s GROUP BY category_id",$propertyUrl),ARRAY_A)?:[];$out=[];foreach($rows as $row)$out[(int)$row['category_id']]=['query_count'=>(int)$row['query_count'],'clicks'=>(float)$row['clicks'],'impressions'=>(float)$row['impressions'],'ctr'=>(float)$row['ctr'],'position'=>(float)$row['position']];return $out;
    }
}
