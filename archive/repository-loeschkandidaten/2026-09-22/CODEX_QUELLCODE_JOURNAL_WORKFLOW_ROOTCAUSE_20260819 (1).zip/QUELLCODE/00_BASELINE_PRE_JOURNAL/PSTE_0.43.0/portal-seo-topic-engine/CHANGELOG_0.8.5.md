# Portal SEO Themenengine 0.8.5-staging

## Allgemeine Restkorrektur der Titelautomatik

- Behebt den allgemeinen Idempotenzfehler von 0.8.4: Ein bereits korrekt formulierter Titel mit bereits korrekt vorläufig umgeordnetem Artikeltyp wurde als `ALREADY_EDITORIAL` nicht erneut deterministisch aufgelöst und blieb deshalb Gelb.
- Das Regelwerk `PSTE_GENERAL_EDITORIALIZATION_V2` behandelt solche eindeutigen Fälle nun als vollständig aufgelöst und setzt sie auf `AUTO_RESOLVED`, sofern die Zielkategorie vorhanden ist und keine harte Sperre greift.
- Die Korrektur ist portal- und themenunabhängig.
- Keine Änderung an Textproduktionsmaschine, Production Center, Editorial Guard, Beiträgen, Kategorien, URLs, Yoast oder Produktionsmetadaten.
