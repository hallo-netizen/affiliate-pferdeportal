<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_GSC_Client {
    private const SCOPE='https://www.googleapis.com/auth/webmasters.readonly';
    private const AUTH_URL='https://accounts.google.com/o/oauth2/v2/auth';
    private const TOKEN_URL='https://oauth2.googleapis.com/token';
    private const API_BASE='https://www.googleapis.com/webmasters/v3';

    public static function authorizationUrl(): string {
        $client=PSTE_GSC_Credentials::client();if($client['client_id']===''||$client['client_secret']==='')throw new RuntimeException('PSTE_GSC_CLIENT_CREDENTIALS_MISSING');
        $state=wp_generate_password(48,false,false);set_transient('pste_gsc_oauth_state_'.get_current_user_id(),hash('sha256',$state),600);
        return add_query_arg([
            'client_id'=>$client['client_id'],'redirect_uri'=>PSTE_GSC_Credentials::redirectUri(),'response_type'=>'code','scope'=>self::SCOPE,
            'access_type'=>'offline','include_granted_scopes'=>'true','prompt'=>'consent','state'=>$state,
        ],self::AUTH_URL);
    }

    public static function handleCallback(string $code,string $state): array {
        $expected=get_transient('pste_gsc_oauth_state_'.get_current_user_id());delete_transient('pste_gsc_oauth_state_'.get_current_user_id());
        if(!is_string($expected)||$expected===''||!hash_equals($expected,hash('sha256',$state)))throw new RuntimeException('PSTE_GSC_OAUTH_STATE_INVALID');
        if(trim($code)==='')throw new RuntimeException('PSTE_GSC_OAUTH_CODE_MISSING');
        $client=PSTE_GSC_Credentials::client();$body=self::tokenRequest([
            'code'=>$code,'client_id'=>$client['client_id'],'client_secret'=>$client['client_secret'],'redirect_uri'=>PSTE_GSC_Credentials::redirectUri(),'grant_type'=>'authorization_code',
        ]);
        $current=PSTE_GSC_Credentials::tokenBundle();$refresh=(string)($body['refresh_token']??$current['refresh_token']??'');
        PSTE_GSC_Credentials::saveTokenBundle([
            'access_token'=>(string)($body['access_token']??''),'refresh_token'=>$refresh,'expires_at'=>time()+(int)($body['expires_in']??3600)-60,
            'scope'=>(string)($body['scope']??self::SCOPE),'token_type'=>(string)($body['token_type']??'Bearer'),
        ]);
        $sites=self::listSites();PSTE_GSC_Credentials::recordStatus('CONNECTED',null,null);return $sites;
    }

    public static function accessToken(): string {
        $bundle=PSTE_GSC_Credentials::tokenBundle();$access=(string)($bundle['access_token']??'');$expires=(int)($bundle['expires_at']??0);
        if($access!==''&&$expires>time()+30)return $access;
        $refresh=(string)($bundle['refresh_token']??'');if($refresh==='')throw new RuntimeException('PSTE_GSC_REFRESH_TOKEN_MISSING');
        $client=PSTE_GSC_Credentials::client();$body=self::tokenRequest(['client_id'=>$client['client_id'],'client_secret'=>$client['client_secret'],'refresh_token'=>$refresh,'grant_type'=>'refresh_token']);
        PSTE_GSC_Credentials::saveTokenBundle(['access_token'=>(string)($body['access_token']??''),'refresh_token'=>$refresh,'expires_at'=>time()+(int)($body['expires_in']??3600)-60,'scope'=>(string)($body['scope']??($bundle['scope']??self::SCOPE)),'token_type'=>(string)($body['token_type']??'Bearer')]);
        return (string)($body['access_token']??'');
    }

    public static function listSites(): array {
        $response=self::apiRequest('GET','/sites');$items=[];
        foreach(($response['siteEntry']??[]) as $entry){$url=(string)($entry['siteUrl']??'');if($url==='')continue;$items[]=['site_url'=>$url,'permission_level'=>(string)($entry['permissionLevel']??'')];}
        update_option(PSTE_OPTION_GSC_SITES_CACHE,['captured_at_utc'=>gmdate('c'),'items'=>$items],false);return $items;
    }

    public static function queryAnalytics(string $siteUrl,string $startDate,string $endDate,int $startRow=0,int $rowLimit=25000): array {
        if($siteUrl==='')throw new RuntimeException('PSTE_GSC_PROPERTY_MISSING');
        if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$startDate)||!preg_match('/^\d{4}-\d{2}-\d{2}$/',$endDate))throw new RuntimeException('PSTE_GSC_DATE_INVALID');
        $payload=['startDate'=>$startDate,'endDate'=>$endDate,'dimensions'=>['query','page'],'type'=>'web','aggregationType'=>'auto','rowLimit'=>min(25000,max(1,$rowLimit)),'startRow'=>max(0,$startRow),'dataState'=>'final'];
        return self::apiRequest('POST','/sites/'.rawurlencode($siteUrl).'/searchAnalytics/query',$payload);
    }

    private static function tokenRequest(array $payload): array {
        $response=wp_remote_post(self::TOKEN_URL,['timeout'=>45,'redirection'=>0,'headers'=>['Content-Type'=>'application/x-www-form-urlencoded'],'body'=>$payload]);
        if(is_wp_error($response))throw new RuntimeException('PSTE_GSC_TOKEN_TRANSPORT_ERROR');$http=(int)wp_remote_retrieve_response_code($response);$body=json_decode((string)wp_remote_retrieve_body($response),true);
        if($http<200||$http>=300||!is_array($body)){throw new RuntimeException('PSTE_GSC_TOKEN_HTTP_ERROR_'.$http);}if(!empty($body['error']))throw new RuntimeException('PSTE_GSC_TOKEN_ERROR_'.sanitize_key((string)$body['error']));return $body;
    }

    private static function apiRequest(string $method,string $path,?array $payload=null): array {
        $token=self::accessToken();$args=['method'=>$method,'timeout'=>60,'redirection'=>0,'headers'=>['Authorization'=>'Bearer '.$token,'Accept'=>'application/json']];
        if($payload!==null){$args['headers']['Content-Type']='application/json';$args['body']=wp_json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);} $response=wp_remote_request(self::API_BASE.$path,$args);
        if(is_wp_error($response))throw new RuntimeException('PSTE_GSC_API_TRANSPORT_ERROR');$http=(int)wp_remote_retrieve_response_code($response);$body=json_decode((string)wp_remote_retrieve_body($response),true);
        if($http<200||$http>=300||!is_array($body)){throw new RuntimeException('PSTE_GSC_API_HTTP_ERROR_'.$http);}return $body;
    }
}
