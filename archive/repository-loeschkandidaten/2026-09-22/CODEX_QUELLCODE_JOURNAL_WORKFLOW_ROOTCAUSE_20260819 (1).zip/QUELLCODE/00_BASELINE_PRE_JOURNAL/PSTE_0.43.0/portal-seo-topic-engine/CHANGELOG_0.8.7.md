# 0.8.7-staging – Themenpayload-Reparatur und Persistenznachweis

- Ein ungültiges `topic_pool.payload_json` wird vor dem ausdrücklich gestarteten Gesamtbestand-/Portalabgleich ausschließlich aus den bereits gespeicherten Kandidaten und Fundstellen rekonstruiert.
- Reparatur ist transaktional, verändert keine Zeilenzahlen und stoppt fail-closed, wenn Quelle, Identität oder Relationen nicht eindeutig sind.
- Neue Kandidaten- und Themenpayloads werden vor dem Schreiben JSON-Roundtrip-validiert.
- Themenpayloads werden nach dem Schreiben aus der Datenbank zurückgelesen und hashgenau geprüft.
- Portalabgleich wiederholt den Payload-Preflight vor jedem Batch.
- Keine Änderung an Beiträgen, Kategorien, URLs, Design, Production Machine, Production Center oder Editorial Guard.
