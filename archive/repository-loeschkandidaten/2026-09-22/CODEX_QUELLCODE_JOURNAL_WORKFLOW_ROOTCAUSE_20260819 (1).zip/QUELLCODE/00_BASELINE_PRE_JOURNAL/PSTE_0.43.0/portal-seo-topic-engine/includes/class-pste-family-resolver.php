<?php
if (!defined('ABSPATH')) { return; }

/** Resolves legacy/unscoped topic-family references to the current scoped portal family. */
final class PSTE_Family_Resolver {
    /** @return array<string,mixed> */
    public static function resolve(array $payload,array $registry): array {
        $families=(array)($registry['families']??[]);$strong=[];$weak=[];$evidence=[];
        $current=trim((string)($payload['topic_family_key']??''));
        if($current!==''&&isset($families[$current])){$strong[$current]=true;$evidence[]=['source'=>'EXACT_CURRENT_KEY','value'=>$current,'family_key'=>$current];}
        foreach(['target_category_id','suggested_category_id'] as $field){$id=(int)($payload[$field]??0);if($id>0){$key=(string)($registry['by_term_id'][$id]??'');if($key!==''){$strong[$key]=true;$evidence[]=['source'=>strtoupper($field),'value'=>$id,'family_key'=>$key];}}}
        foreach(['target_category_slug','suggested_category_slug'] as $field){$slug=trim((string)($payload[$field]??''));if($slug!==''){$key=(string)($registry['by_slug'][$slug]??'');if($key!==''){$strong[$key]=true;$evidence[]=['source'=>strtoupper($field),'value'=>$slug,'family_key'=>$key];}}}
        foreach(['source_target_category_id'] as $field){$id=(int)($payload[$field]??0);if($id>0){$key=(string)($registry['by_term_id'][$id]??'');if($key!==''){$weak[$key]=true;$evidence[]=['source'=>strtoupper($field),'value'=>$id,'family_key'=>$key];}}}
        foreach(['source_target_category_slug'] as $field){$slug=trim((string)($payload[$field]??''));if($slug!==''){$key=(string)($registry['by_slug'][$slug]??'');if($key!==''){$weak[$key]=true;$evidence[]=['source'=>strtoupper($field),'value'=>$slug,'family_key'=>$key];}}}
        $name=trim((string)($payload['topic_family_name']??''));
        if($name!==''){
            $n=PSTE_Normalizer::exactTopicIdentityText($name);$matches=array_values((array)($registry['family_name_index'][$n]??[]));
            if(count($matches)===1){$weak[$matches[0]]=true;$evidence[]=['source'=>'UNIQUE_FAMILY_NAME','value'=>$name,'family_key'=>$matches[0]];}
        }
        if($current!==''){
            $legacy=PSTE_Normalizer::text($current);$matches=array_values((array)($registry['legacy_key_index'][$legacy]??[]));
            if(count($matches)===1){$weak[$matches[0]]=true;$evidence[]=['source'=>'UNIQUE_LEGACY_KEY','value'=>$current,'family_key'=>$matches[0]];}
        }
        $keys=array_keys($strong?:$weak);
        if(count($keys)!==1){return ['ok'=>false,'status'=>'PSTE_FAMILY_RESOLUTION_BLOCKED','reason_codes'=>[count($keys)>1?'PSTE_FAMILY_RESOLUTION_CONFLICT':'PSTE_FAMILY_RESOLUTION_MISSING'],'legacy_family_key'=>$current,'resolved_family_key'=>'','resolved_family_name'=>'','evidence'=>$evidence,'write_attempted'=>false];}
        $key=$keys[0];$family=(array)($families[$key]??[]);
        if(!$family)return ['ok'=>false,'status'=>'PSTE_FAMILY_RESOLUTION_BLOCKED','reason_codes'=>['PSTE_FAMILY_RESOLUTION_REGISTRY_ROW_MISSING'],'legacy_family_key'=>$current,'resolved_family_key'=>'','resolved_family_name'=>'','evidence'=>$evidence,'write_attempted'=>false];
        return ['ok'=>true,'status'=>'PSTE_FAMILY_RESOLUTION_PASS','reason_codes'=>[],'legacy_family_key'=>$current,'resolved_family_key'=>$key,'resolved_family_name'=>(string)($family['topic_family_name']??''),'evidence'=>$evidence,'write_attempted'=>false];
    }
}
