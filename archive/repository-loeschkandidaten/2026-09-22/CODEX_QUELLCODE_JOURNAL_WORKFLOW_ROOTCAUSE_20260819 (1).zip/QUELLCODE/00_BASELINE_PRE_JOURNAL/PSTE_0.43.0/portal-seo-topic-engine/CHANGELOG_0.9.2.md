# 0.9.2-staging

- Behebt den real reproduzierten DataForSEO-Fehler `PSTE_PROVIDER_TASK_ERROR_40000`.
- Der Endpunkt `serp/google/organic/live/advanced` wird vertragskonform mit exakt einer Aufgabe je POST-Aufruf angesprochen.
- Kandidat und Vergleichsinventar werden weiterhin vollständig geprüft; die Einzelergebnisse werden streng über eindeutige Tags zusammengeführt.
- Bereits angefallene Kosten jedes erfolgreichen Live-SERP-Aufrufs werden vor dem nächsten kostenpflichtigen Aufruf einzeln im bestehenden Kostenledger gespeichert.
- Fehlende, doppelte oder vom Provider abweichende Tags sowie unvollständige Antwortzahlen blockieren fail-closed.
- Provider-Statusmeldung, HTTP-Code und Aufgabenindex werden bei Fehlern ohne Zugangsdaten sichtbar ausgegeben.
- Keine Artikel-, Kategorie-, Inhalts-, Design-, Produktions- oder Fremdplugin-Schreibpfade wurden ergänzt.
