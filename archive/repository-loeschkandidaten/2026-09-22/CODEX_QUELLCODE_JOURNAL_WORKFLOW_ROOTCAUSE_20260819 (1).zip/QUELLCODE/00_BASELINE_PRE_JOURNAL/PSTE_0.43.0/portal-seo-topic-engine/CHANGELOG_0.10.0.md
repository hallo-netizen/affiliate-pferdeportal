# 0.10.0-staging

- Entfernt den praktischen Google-Live-SERP-Workflow vollständig aus der aktiven Engine.
- Entfernt Live-SERP-Auftrag, SERP-Evidenzregister, Kalibrierung, Retry-/Cron-Einzelschritte und manuelle Klickschleifen.
- Führt einen alltagstauglichen Ein-Klick-Kategorienlauf mit genau zwei DataForSEO-Labs-Quellen ein: Keyword Suggestions und Related Keywords.
- Trennt die beiden kostenpflichtigen Provideraufrufe in begrenzte automatische Browserabschnitte; kein langer synchroner Mehrfachbatch und keine WP-Cron-Abhängigkeit.
- Speichert jedes Providerergebnis vor Kostenbuchung und Folgeschritt persistent, damit ein lokaler Folgefehler keinen erneuten kostenpflichtigen Abruf erzwingt.
- Wiederholt unbekannte Transportausgänge niemals automatisch; eindeutige Fehler pausieren fail-closed und erlauben nur eine ausdrückliche Fortsetzung.
- Prüft Portalbestand, Struktur, Budget und Zielzustand vor jedem noch offenen kostenpflichtigen Abschnitt.
- Ergänzt Portal-/Pferdekontext für mehrdeutige Ausgangsbegriffe.
- Wandelt Longtails deterministisch in semantisch brauchbare Titel um, ohne Artikelinhalt zu erzeugen.
- Ordnet ausschließlich exakt vorhandene Blattkategorien zu; fehlende oder mehrdeutige Ziele blockieren fail-closed.
- Prüft Doppelungen nur gegen den eigenen veröffentlichten Bestand, Entwürfe und Redaktionsplan.
- Aktualisiert den Zielkontext der im aktuellen Lauf erzeugten Themen unmittelbar; keine nachträgliche Klickschleife.
- Entfernt den unnötigen Provider-Kontostatusabruf aus jedem Produktionslauf.
- Bereinigt beim Update einmalig ausschließlich die obsoleten SEO-Live-SERP-Auftragsoptionen aus 0.9.x.
- Textmaschine, Design, Artikelinhalt, HTML und Qualitätslogik bleiben unverändert und unberührt.
