<?php
if (!defined('ABSPATH')) { return; }

/** Runtime exception carrying a strictly bounded, non-secret diagnostic payload. */
final class PSTE_Diagnostic_Exception extends RuntimeException {
    /** @var array<string,mixed> */
    private array $details;

    /** @param array<string,mixed> $details */
    public function __construct(string $message,array $details=[]) {
        parent::__construct($message);
        $this->details=$details;
    }

    /** @return array<string,mixed> */
    public function safeDetails(): array { return $this->details; }
}
