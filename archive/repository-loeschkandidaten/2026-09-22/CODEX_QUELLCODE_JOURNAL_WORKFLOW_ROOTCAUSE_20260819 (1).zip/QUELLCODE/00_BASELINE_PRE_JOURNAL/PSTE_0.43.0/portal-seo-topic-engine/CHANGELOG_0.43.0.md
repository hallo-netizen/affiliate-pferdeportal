# PSTE 0.43.0 – Portalabgleich Sandbox-Speicherfix

- Keine Änderung an Workflow, Textmaschine, PPM, PSERC, Titel-/Intent-/Kategorie-/Produktionslogik.
- Bestehender Portalabgleich und Sandbox-Rebind bleiben semantisch unverändert.
- Historische `sandbox_dataflow_archive`-Einträge werden beim nächsten Sandbox-Batch lossless in kompakte JSON-/GZIP-Hüllen überführt; aktuelle Datenflüsse bleiben unverändert.
- Neue Baseline-Rebind-Archiveinträge werden nicht mehr als tief verschachtelte PHP-Arrays dupliziert, sondern lossless kompakt gespeichert.
- Sandbox-Batchgröße von 10 auf 5 reduziert, um PHP-Peak-Memory pro Request zu begrenzen.
- Übersicht zeigt zusätzlich `Sandbox x von y`, damit der reale Fortschritt sichtbar ist.

Ziel: den bestätigten ungebremsten Speicher-/Optionswachstumspfad beim wiederholten Portalabgleich technisch begrenzen, ohne fachliche Regeln oder Reihenfolge zu verändern.
