# Portal SEO Themenengine 0.8.1-staging

## Sicherheits- und Kompatibilitätskorrektur

- Mindestanforderung auf PHP 8.0 korrigiert; 0.8.0 hatte unbegründet PHP 8.1 verlangt.
- PHP-8.1-Funktion `array_is_list()` durch interne PHP-8.0-kompatible Prüfung ersetzt.
- Aktivierung ist vollständig dormant: keine Tabellenänderung, keine Migration, kein Portalabgleich.
- Keine automatische Migration über `admin_init`.
- Menü, Plugin-Aktionslink und sichtbarer Adminhinweis werden vor jeder Datenoperation registriert.
- Migration erfolgt ausschließlich nach ausdrücklichem Klick auf der erreichbaren Diagnoseseite.
- Netzwerk-Admin erhält bei Multisite einen separaten Einstieg.
- Keine Schreibzugriffe auf Beiträge, Kategorien, URLs, Yoast, Produktionsmetadaten oder fremde Plugin-Dateien.
