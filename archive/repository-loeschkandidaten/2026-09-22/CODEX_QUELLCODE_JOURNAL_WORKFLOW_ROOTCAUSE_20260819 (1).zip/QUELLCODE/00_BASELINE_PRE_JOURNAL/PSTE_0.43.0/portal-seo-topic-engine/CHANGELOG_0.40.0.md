# 0.40.0 – Beratungstitel-Variation, sonst unverändert

- Ausschließlich die bestehende Beratungstitel-Regel harmonisiert: der generische Wiederholungsfallback `Passende … richtig auswählen` wird nicht mehr erzeugt und wird für neue/manuell geprüfte Beratungstitel fail-closed blockiert.
- Ersatz ausschließlich durch deterministische, semantisch neutrale Beratungssurfaces; das exakte Target Keyword bleibt unverändert zusammenhängend im Titel.
- Keine Änderung an Suchintention, Themenfamilie, Kategorie, Artikelart, Planplatz, Recherche, Textmaschine, Artikelinhalt, HTML, Formatierung oder Design.
- Alle anderen Titelregeln bleiben unverändert.
