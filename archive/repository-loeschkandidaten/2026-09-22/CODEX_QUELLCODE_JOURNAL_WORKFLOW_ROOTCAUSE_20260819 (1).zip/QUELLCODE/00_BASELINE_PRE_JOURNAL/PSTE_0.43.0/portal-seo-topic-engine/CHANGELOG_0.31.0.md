# Portal SEO Themenengine 0.31.0

- Bugfix innerhalb der bestehenden Titelstufe: die bereits feststehende Artikelart muss im Titel sichtbar sein und ist jetzt ein hartes Upstream-Freigabegate.
- Beratungstitel dürfen nicht mehr als bloße Keyword-/Themenphrase passieren; bei fehlendem Beratungssignal ergänzt ausschließlich der Titelgenerator eine natürliche Entscheidungsoberfläche (`richtig auswählen`).
- Sicherheit und Übungen erhalten bei fehlendem bereits sichtbarem Typsignal ebenfalls eine eindeutige, natürliche Titeloberfläche.
- Keine Re-Klassifizierung: Artikelart, Intent, Keywordrecherche, Kategorie, Kategorie-Gap, Planplatz und canonical_article_id bleiben außerhalb der Titelautorität.
- PPM/Textmaschine 6.7.9, Content-, HTML-, Format- und Designlogik bleiben unverändert.
- Safe-Migration-Protokoll/Editorial-Ruleset werden nur deshalb angehoben, damit bereits gespeicherte PSTE-Titel kontrolliert unter denselben bestehenden Zuordnungen neu aufgebaut werden.
