# 0.9.1-staging

- Vollständige, hashgebundene DataForSEO-Artikeltest-Evidenzen werden zusätzlich in einem eigenen rollierenden Register gespeichert.
- Das Register behält ausschließlich Evidenzen innerhalb des bereits bestehenden Sieben-Tage-Frischefensters und genau die neueste Evidenz je Kandidat.
- Der bisherige Einzeleintrag `pste_last_live_check_v1` bleibt unverändert für die bestehende Administrationsanzeige erhalten.
- Keine Artikel-, Kategorie-, Inhalts-, Design-, Produktions- oder Fremdplugin-Schreibpfade wurden ergänzt.
