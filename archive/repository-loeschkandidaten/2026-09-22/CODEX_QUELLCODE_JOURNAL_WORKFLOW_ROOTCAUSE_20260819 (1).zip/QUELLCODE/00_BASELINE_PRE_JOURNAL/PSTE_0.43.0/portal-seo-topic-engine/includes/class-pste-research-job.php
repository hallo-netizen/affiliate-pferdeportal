<?php
if (!defined('ABSPATH')) { return; }

/** One-click, automatically chained, resumable longtail research job. */
final class PSTE_Research_Job {
    public const CONTRACT='PSTE_AUTOMATIC_LONGTAIL_RESEARCH_JOB_V2';
    public const VERSION='2.1.0';
    private const COMPATIBLE_VERSIONS=['2.1.0','2.2.0'];
    private const PROVIDER_STEPS=3;
    private const STEP_LOCK_TTL=90;
    private const IN_FLIGHT_UNKNOWN_AFTER=75;
    private const TRANSIENT_COORDINATION_CODES=['PSTE_SANDBOX_LOCKED','PSTE_BUDGET_RESERVATION_LOCKED'];
    private const REPLAY_SAFE_LOCAL_FINALIZE_CODES=['PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_RAW_MISMATCH','PSTE_SNAPSHOT_STALE_OR_CHANGED'];

    public static function start(int $categoryId,string $seed,array $settings): array {
        PSTE_Plugin::assertReady();
        PSTE_Repository::assertOwnJsonStorageReady();
        PSTE_Repository::repairInvalidTopicPayloads();
        if(empty($settings['feature_enabled']))throw new RuntimeException('PSTE_FEATURE_DISABLED');
        if(!PSTE_Credentials::configured())throw new RuntimeException('PSTE_CREDENTIALS_MISSING');
        $seed=trim($seed);if($categoryId<=0||strlen($seed)<3)throw new RuntimeException('PSTE_RESEARCH_INPUT_INVALID');
        if(self::rawJob()!==null)throw new RuntimeException('PSTE_RESEARCH_JOB_ALREADY_ACTIVE');
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        $rebase=PSTE_Snapshot::rebaseResearchBaselineIfSafe($baseline);
        if(empty($rebase['ok']))throw new RuntimeException((string)($rebase['error_code']??'PSTE_SITE_BASELINE_STALE'));
        $baseline=(array)$rebase['baseline'];
        $selected=PSTE_Category_Context::selectedCategory($categoryId,$baseline);$categoryId=(int)$selected['term_id'];
        $run=PSTE_Runner::createRunSkeleton($categoryId,$seed,$settings);
        $context=PSTE_Category_Context::researchContext($seed,$selected,(array)($run['snapshot']['structure']['items']??[]),function_exists('get_bloginfo')?(string)get_bloginfo('name'):'');
        $uuid=wp_generate_uuid4();$now=gmdate('c');
        $run['run_uuid']=$uuid;$run['status']='RESEARCH_RUNNING';$run['payload']['research_context']=$context;$run['payload']['selected_category']=$selected;
        $run['payload']['execution_mode']='ONE_CLICK_AUTOMATIC_BROWSER_SEQUENCE';$run['payload']['provider_calls']=self::PROVIDER_STEPS;$run['payload']['provider_steps_completed']=0;$run['payload']['manual_followup_steps_required']=0;
        $job=[
            'contract'=>self::CONTRACT,'version'=>self::VERSION,'job_uuid'=>$uuid,'status'=>'RUNNING','phase'=>'KEYWORD_SUGGESTIONS','phase_state'=>'IDLE',
            'progress'=>0,'total_provider_steps'=>self::PROVIDER_STEPS,'category_id'=>$categoryId,'seed'=>$seed,
            'environment'=>(string)$settings['environment'],'location'=>(string)$settings['location'],'language'=>(string)$settings['language'],
            'estimated_cost'=>(float)$run['estimated_cost'],'actual_cost'=>0.0,'budget_reserved'=>false,'selected_category'=>$selected,'research_context'=>$context,
            'snapshot'=>$run['snapshot'],'sources'=>[],'last_error'=>'','created_at_utc'=>$now,'updated_at_utc'=>$now,'run_created_at'=>(string)$run['created_at'],
        ];
        $job=self::withHash($job);if(!add_option(PSTE_OPTION_ACTIVE_RESEARCH_JOB,$job,'',false))throw new RuntimeException('PSTE_RESEARCH_JOB_ALREADY_ACTIVE');
        try{
            PSTE_Budget_Reservations::reserve($uuid,(float)$job['estimated_cost'],$settings,'CATEGORY_LONGTAIL_RESEARCH',1800);$job['budget_reserved']=true;$job['updated_at_utc']=gmdate('c');self::save($job);PSTE_Repository::saveRun($run);return self::summary($job);
        }catch(Throwable $e){try{PSTE_Budget_Reservations::release($uuid);}catch(Throwable $ignored){}self::deleteIfSame($job);throw $e;}
    }

    public static function advance(string $jobUuid,array $settings,bool $explicitResume=false): array {
        PSTE_Plugin::assertReady();
        $token=self::acquireStepLock();
        try{
            PSTE_Repository::assertOwnJsonStorageReady();
            PSTE_Repository::repairInvalidTopicPayloads();
            $job=self::load();if(!hash_equals((string)$job['job_uuid'],trim($jobUuid)))throw new RuntimeException('PSTE_RESEARCH_JOB_ID_MISMATCH');
            if((string)$job['status']==='OUTCOME_UNKNOWN')return self::summary($job);
            if((string)$job['status']==='PAUSED_ERROR'){
                $pausedCode=(string)($job['last_error']??'');
                if(self::isTransientCoordinationCode($pausedCode)){$job=self::recoverTransientCoordinationPause($job,$pausedCode);}
                elseif($pausedCode==='PSTE_SITE_BASELINE_STALE'){$job=self::recoverSafeSiteContextPause($job);}
                elseif(self::isReplaySafeLocalFinalizeCode($pausedCode)&&self::canReplayLocalFinalize($job)){$job=self::recoverReplaySafeLocalFinalizePause($job,$pausedCode);}
                elseif(!$explicitResume)return self::summary($job);
                else{$job['status']='RUNNING';$job['last_error']='';$job['phase_state']='IDLE';unset($job['coordination_wait_code'],$job['coordination_wait_since_utc']);$job['updated_at_utc']=gmdate('c');self::save($job);}
            }
            if((string)$job['status']!=='RUNNING')return self::summary($job);
            if((string)$job['phase_state']==='IN_FLIGHT'){
                $cached=self::peekPhaseResponse($job);
                if(is_array($cached))return self::runProviderStep($job,$cached);
                $age=time()-(strtotime((string)$job['updated_at_utc'])?:time());if($age>=self::IN_FLIGHT_UNKNOWN_AFTER){$job['status']='OUTCOME_UNKNOWN';$job['last_error']='PSTE_PROVIDER_TRANSPORT_OUTCOME_UNKNOWN';$job['updated_at_utc']=gmdate('c');self::save($job);}return self::summary($job);
            }
            $phase=(string)$job['phase'];
            if(in_array($phase,['KEYWORD_SUGGESTIONS','RELATED_KEYWORDS','KEYWORD_IDEAS'],true)){
                try{$job=self::ensureInputsCurrent($job);self::ensureReservation($job,$settings);}catch(Throwable $e){$code=self::errorCode($e);if(self::isTransientCoordinationCode($code))return self::coordinationWait($job,$code);$job['status']='PAUSED_ERROR';$job['phase_state']='IDLE';$job['last_error']=$code;$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);}
                return self::runProviderStep($job);
            }
            if($phase==='FINALIZE'){$job=self::ensureInputsCurrent($job);return self::finalize($job);}
            throw new RuntimeException('PSTE_RESEARCH_JOB_PHASE_INVALID');
        }finally{self::releaseStepLock($token);}
    }

    public static function cancelAfterProviderCheck(string $jobUuid,bool $confirmed): array {
        PSTE_Plugin::assertReady();if(!$confirmed)throw new RuntimeException('PSTE_PROVIDER_CHECK_CONFIRMATION_REQUIRED');$token=self::acquireStepLock();
        try{$job=self::load();if(!hash_equals((string)$job['job_uuid'],trim($jobUuid)))throw new RuntimeException('PSTE_RESEARCH_JOB_ID_MISMATCH');if(!in_array((string)$job['status'],['OUTCOME_UNKNOWN','PAUSED_ERROR'],true))throw new RuntimeException('PSTE_RESEARCH_JOB_CANCEL_NOT_ALLOWED');try{PSTE_Budget_Reservations::release((string)$job['job_uuid']);}catch(Throwable $ignored){}$job['status']='CANCELLED_AFTER_PROVIDER_CHECK';$job['budget_reserved']=false;$job['updated_at_utc']=gmdate('c');self::saveProgressRun($job);self::deleteIfSame($job);return self::summary($job);}finally{self::releaseStepLock($token);}
    }

    public static function current(): ?array {$job=self::rawJob();if($job===null)return null;self::assertJob($job);if((string)($job['status']??'')==='PAUSED_ERROR'){$code=(string)($job['last_error']??'');if(self::isTransientCoordinationCode($code))$job=self::recoverTransientCoordinationPause($job,$code);elseif($code==='PSTE_SITE_BASELINE_STALE')$job=self::recoverSafeSiteContextPause($job);elseif(self::isReplaySafeLocalFinalizeCode($code)&&self::canReplayLocalFinalize($job))$job=self::recoverReplaySafeLocalFinalizePause($job,$code);}return self::summary($job);}

    private static function runProviderStep(array $job,?array $recoveredResponse=null): array {
        $phase=(string)$job['phase'];$meta=self::providerMeta($phase);$source=(string)$meta['source'];$uuid=(string)$job['job_uuid'];
        try{
            $stored=(array)($job['sources'][$source]??[]);
            if(empty($stored['response_sha256'])||!is_array($stored['items']??null)){
                $response=$recoveredResponse;
                if($response===null)$response=self::peekPhaseResponse($job);
                if($response===null){
                    $job['phase_state']='IN_FLIGHT';$job['provider_call_expected_fresh']=true;$job['updated_at_utc']=gmdate('c');self::save($job);
                    $response=self::fetchPhaseResponse($job);
                }
                $items=array_values(array_slice(PSTE_DataForSEO_Client::extractKeywords($response),0,1000));
                $responseHash=PSTE_DataForSEO_Client::responseSha256($response);$captured=PSTE_DataForSEO_Client::retrievedAtUtc($response);$root=(string)($job['research_context']['effective_seed']??$job['seed']);
                foreach($items as $index=>&$item){$raw=(string)($item['keyword']??'');$depth=$phase==='KEYWORD_IDEAS'?2:1;$parent=$depth===2?'obs:'.substr(hash('sha256',$uuid.'|ROOT|'.$root),0,32):'';$item['observation']=['observation_id'=>'obs:'.substr(hash('sha256',$uuid.'|'.$source.'|'.$index.'|'.$raw.'|'.$responseHash),0,32),'canonical_term_id'=>'','source_class'=>$source,'provider'=>'DATAFORSEO_LABS','query_kind'=>$source,'root_query'=>$root,'parent_observation_id'=>$parent,'depth'=>$depth,'raw_value'=>$raw,'locale'=>(string)$job['location'],'language'=>(string)$job['language'],'parameters'=>['path'=>(string)$meta['path'],'limit'=>100,'depth_limit'=>2,'branch_limit'=>20],'retrieved_at_utc'=>$captured,'raw_response_sha256'=>$responseHash,'measurement_status'=>is_numeric($item['search_volume']??null)?'MEASURED':'UNMEASURED','relation'=>$source==='RELATED_SEARCH'?'RELATED_ENTITY':($source==='KEYWORD_IDEA'?'NARROWER_TOPIC':'DISCOVERED'),'relation_evidence'=>[$source],'freshness_status'=>'CURRENT','valid_until'=>gmdate('c',(strtotime($captured)?:time())+90*86400)];}unset($item);
                $cost=PSTE_Runner::responseCost($response);
                if(!empty($job['provider_call_expected_fresh'])&&PSTE_DataForSEO_Client::cacheHit($response))$cost=(float)(PSTE_DataForSEO_Client::externalResponse($response)['cost']??0.0);
                $stored=['path'=>(string)$meta['path'],'response_sha256'=>$responseHash,'items'=>$items,
                    'cost'=>$cost,'captured_at_utc'=>$captured,'accounting_complete'=>false,'sanitized_summary'=>PSTE_DataForSEO_Client::sanitizedSummary($response)];
                $job['sources'][$source]=$stored;unset($job['provider_call_expected_fresh']);$job['phase_state']='PERSISTING';$job['updated_at_utc']=gmdate('c');self::save($job);
            }
            $stored=(array)$job['sources'][$source];PSTE_Repository::saveEvidence($uuid,$source,(string)$meta['path'],(array)($stored['sanitized_summary']??[]),(string)$stored['response_sha256']);
            $billingItems=100;
            PSTE_Repository::recordCostOnce($uuid,(string)$meta['ledger'],PSTE_Cost_Guard::estimate((string)$meta['rate'],1,$billingItems),(float)($stored['cost']??0.0));
            $stored['accounting_complete']=true;$job['sources'][$source]=$stored;$job['actual_cost']=0.0;foreach((array)$job['sources'] as $saved)if(!empty($saved['accounting_complete']))$job['actual_cost']+=(float)($saved['cost']??0.0);
            $job['actual_cost']=round($job['actual_cost'],6);$job['progress']=(int)$job['progress']+1;$job['phase']=(string)$meta['next'];$job['phase_state']='IDLE';$job['last_error']='';unset($job['coordination_wait_code'],$job['coordination_wait_since_utc']);$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);
        }catch(Throwable $e){$code=self::errorCode($e);$job=self::load();$job['status']=$code==='PSTE_PROVIDER_TRANSPORT_OUTCOME_UNKNOWN'?'OUTCOME_UNKNOWN':'PAUSED_ERROR';$job['phase_state']=$job['status']==='OUTCOME_UNKNOWN'?'IN_FLIGHT':'IDLE';$job['last_error']=$code;$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);return self::summary($job);}
    }

    private static function fetchPhaseResponse(array $job): array {
        $client=new PSTE_DataForSEO_Client((string)$job['environment']);$phase=(string)$job['phase'];$seed=(string)($job['research_context']['effective_seed']??$job['seed']);
        if($phase==='KEYWORD_SUGGESTIONS')return $client->keywordSuggestions($seed,(string)$job['location'],(string)$job['language'],100);
        if($phase==='RELATED_KEYWORDS')return $client->relatedKeywords($seed,(string)$job['location'],(string)$job['language'],100);
        if($phase==='KEYWORD_IDEAS')return $client->keywordIdeas(self::discoverySeeds($job),(string)$job['location'],(string)$job['language'],100);
        throw new RuntimeException('PSTE_RESEARCH_PROVIDER_PHASE_INVALID');
    }

    private static function peekPhaseResponse(array $job): ?array {
        $client=new PSTE_DataForSEO_Client((string)$job['environment']);$phase=(string)$job['phase'];$seed=(string)($job['research_context']['effective_seed']??$job['seed']);
        if($phase==='KEYWORD_SUGGESTIONS')return $client->peekKeywordSuggestions($seed,(string)$job['location'],(string)$job['language'],100);
        if($phase==='RELATED_KEYWORDS')return $client->peekRelatedKeywords($seed,(string)$job['location'],(string)$job['language'],100);
        if($phase==='KEYWORD_IDEAS')return $client->peekKeywordIdeas(self::discoverySeeds($job),(string)$job['location'],(string)$job['language'],100);
        return null;
    }

    private static function providerMeta(string $phase): array {
        return match($phase){
            'KEYWORD_SUGGESTIONS'=>['source'=>'KEYWORD_SUGGESTION','path'=>'dataforseo_labs/google/keyword_suggestions/live','ledger'=>'keyword_suggestions','rate'=>'labs_keyword_suggestions_live','next'=>'RELATED_KEYWORDS'],
            'RELATED_KEYWORDS'=>['source'=>'RELATED_SEARCH','path'=>'dataforseo_labs/google/related_keywords/live','ledger'=>'related_keywords','rate'=>'labs_related_keywords_live','next'=>'KEYWORD_IDEAS'],
            'KEYWORD_IDEAS'=>['source'=>'KEYWORD_IDEA','path'=>'dataforseo_labs/google/keyword_ideas/live','ledger'=>'keyword_ideas','rate'=>'labs_keyword_ideas_live','next'=>'FINALIZE'],
            default=>throw new RuntimeException('PSTE_RESEARCH_PROVIDER_PHASE_INVALID'),
        };
    }

    /** @return list<string> */
    private static function discoverySeeds(array $job): array {
        $rows=[];foreach(['KEYWORD_SUGGESTION','RELATED_SEARCH'] as $source)foreach((array)($job['sources'][$source]['items']??[]) as $item){$q=trim((string)($item['keyword']??''));if($q!=='')$rows[$q]=(int)($item['search_volume']??0);}
        arsort($rows,SORT_NUMERIC);$seeds=array_slice(array_keys($rows),0,20);if(!$seeds)$seeds=[(string)($job['research_context']['effective_seed']??$job['seed'])];return $seeds;
    }
    private static function finalize(array $job): array {
        try{foreach(['KEYWORD_SUGGESTION','RELATED_SEARCH','KEYWORD_IDEA'] as $source)if(!isset($job['sources'][$source]['items'])||!is_array($job['sources'][$source]['items']))throw new RuntimeException('PSTE_RESEARCH_SOURCE_INCOMPLETE_'.$source);
            $run=PSTE_Runner::finalizeResearchJob($job);$job['status']='COMPLETE';$job['phase']='COMPLETE';$job['phase_state']='IDLE';$job['last_error']='';$job['updated_at_utc']=gmdate('c');try{PSTE_Budget_Reservations::release((string)$job['job_uuid']);}catch(Throwable $ignored){}$job['budget_reserved']=false;self::deleteIfSame($job);$summary=self::summary($job);$summary['usable_candidate_count']=(int)($run['payload']['usable_candidate_count']??0);$summary['candidate_count']=(int)($run['payload']['candidate_count']??0);return $summary;
        }catch(Throwable $e){$job=self::load();$code=self::errorCode($e);if(self::isTransientCoordinationCode($code))return self::coordinationWait($job,$code);$job['status']='PAUSED_ERROR';$job['phase_state']='IDLE';$job['last_error']=$code;$job['updated_at_utc']=gmdate('c');self::save($job);self::saveProgressRun($job);try{PSTE_Budget_Reservations::release((string)$job['job_uuid']);$job['budget_reserved']=false;self::save($job);}catch(Throwable $ignored){}return self::summary($job);}
    }

    private static function ensureInputsCurrent(array $job): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        $rebase=PSTE_Snapshot::rebaseResearchBaselineIfSafe($baseline);
        if(empty($rebase['ok']))throw new RuntimeException((string)($rebase['error_code']??'PSTE_SITE_BASELINE_STALE'));
        $baseline=(array)$rebase['baseline'];
        $inventory=PSTE_Snapshot::inventory();$structure=PSTE_Snapshot::structure();$plan=PSTE_Snapshot::editorialPlan();
        if(!hash_equals((string)($baseline['structure_sha256']??''),(string)($structure['sha256']??'')))throw new RuntimeException('PSTE_SITE_STRUCTURE_STALE');

        $selected=PSTE_Category_Context::selectedCategory((int)$job['category_id'],$baseline);
        $oldSelected=(array)($job['selected_category']??[]);
        foreach(['term_id','slug','topic_family_key'] as $field)if((string)($oldSelected[$field]??'')!==(string)($selected[$field]??''))throw new RuntimeException('PSTE_RESEARCH_SELECTED_CATEGORY_IDENTITY_CHANGED_'.$field);

        $snapshot=(array)($job['snapshot']??[]);
        if(!is_array($snapshot['inventory']??null)||!is_array($snapshot['structure']??null)||!is_array($snapshot['editorial_plan']??null))throw new RuntimeException('PSTE_RESEARCH_JOB_SNAPSHOT_INVALID');
        $changed=!hash_equals((string)($snapshot['inventory']['sha256']??''),(string)($inventory['sha256']??''))
            ||!hash_equals((string)($snapshot['structure']['sha256']??''),(string)($structure['sha256']??''))
            ||!hash_equals((string)($snapshot['editorial_plan']['sha256']??''),(string)($plan['sha256']??''));
        if($changed){
            $receipt=[
                'contract'=>'PSTE_RESEARCH_SITE_CONTEXT_REBASE_V1','mode'=>(string)($rebase['mode']??'SAFE_DYNAMIC_CONTEXT_REBASE'),
                'old_inventory_sha256'=>(string)($snapshot['inventory']['sha256']??''),'new_inventory_sha256'=>(string)($inventory['sha256']??''),
                'old_structure_sha256'=>(string)($snapshot['structure']['sha256']??''),'new_structure_sha256'=>(string)($structure['sha256']??''),
                'old_editorial_plan_sha256'=>(string)($snapshot['editorial_plan']['sha256']??''),'new_editorial_plan_sha256'=>(string)($plan['sha256']??''),
                'old_baseline_sha256'=>(string)($rebase['old_baseline_sha256']??''),'new_baseline_sha256'=>(string)($rebase['new_baseline_sha256']??''),
                'provider_request_repeated'=>false,'rebased_at_utc'=>gmdate('c'),
            ];
            $receipt['sha256']=hash('sha256',self::canonicalJson($receipt));
            $job['snapshot']=['inventory'=>$inventory,'structure'=>$structure,'editorial_plan'=>$plan];$job['selected_category']=$selected;
            $job['site_context_rebase_receipt']=$receipt;$job['site_context_rebase_count']=(int)($job['site_context_rebase_count']??0)+1;
            $job['coordination_wait_code']='PSTE_SITE_CONTEXT_REBASED_SAFE';$job['coordination_wait_since_utc']=gmdate('c');$job['updated_at_utc']=gmdate('c');self::save($job);
        }
        return $job;
    }

    private static function recoverSafeSiteContextPause(array $job): array {
        try{$job=self::ensureInputsCurrent($job);}catch(Throwable $e){return $job;}
        $job['status']='RUNNING';$job['phase_state']='IDLE';$job['last_error']='';$job['coordination_wait_code']='PSTE_SITE_CONTEXT_REBASED_SAFE';$job['coordination_wait_since_utc']=gmdate('c');$job['updated_at_utc']=gmdate('c');self::save($job);return $job;
    }
    private static function ensureReservation(array &$job,array $settings): void {PSTE_Cost_Guard::assertWithin((float)$job['estimated_cost'],(float)$settings['run_budget_usd'],(float)$settings['absolute_ceiling_usd']);PSTE_Budget_Reservations::reserve((string)$job['job_uuid'],(float)$job['estimated_cost'],$settings,'CATEGORY_LONGTAIL_RESEARCH',1800);if(empty($job['budget_reserved'])){$job['budget_reserved']=true;$job['updated_at_utc']=gmdate('c');self::save($job);}}
    private static function saveProgressRun(array $job): void {$now=gmdate('Y-m-d H:i:s');PSTE_Repository::saveRun(['run_uuid'=>(string)$job['job_uuid'],'status'=>(string)$job['status'],'category_id'=>(int)$job['category_id'],'seed'=>(string)$job['seed'],'estimated_cost'=>(float)$job['estimated_cost'],'actual_cost'=>(float)$job['actual_cost'],'snapshot'=>(array)$job['snapshot'],'payload'=>['workflow'=>'LONGTAIL_RESEARCH_TO_METADATA_V2','execution_mode'=>'ONE_CLICK_AUTOMATIC_BROWSER_SEQUENCE','provider_calls'=>self::PROVIDER_STEPS,'provider_steps_completed'=>(int)$job['progress'],'google_live_serp_used'=>false,'manual_followup_steps_required'=>0,'phase'=>(string)$job['phase'],'last_error'=>(string)$job['last_error'],'coordination_wait_code'=>(string)($job['coordination_wait_code']??''),'research_context'=>(array)$job['research_context'],'selected_category'=>(array)$job['selected_category']],'created_at'=>self::mysqlDate((string)$job['run_created_at']),'updated_at'=>$now]);}
    private static function summary(array $job): array {return ['contract'=>self::CONTRACT,'job_uuid'=>(string)$job['job_uuid'],'status'=>(string)$job['status'],'phase'=>(string)$job['phase'],'phase_state'=>(string)$job['phase_state'],'progress'=>(int)$job['progress'],'total_provider_steps'=>(int)$job['total_provider_steps'],'category_id'=>(int)$job['category_id'],'seed'=>(string)$job['seed'],'effective_seed'=>(string)($job['research_context']['effective_seed']??$job['seed']),'estimated_cost'=>(float)$job['estimated_cost'],'actual_cost'=>(float)$job['actual_cost'],'last_error'=>(string)$job['last_error'],'coordination_wait_code'=>(string)($job['coordination_wait_code']??''),'coordination_wait_since_utc'=>(string)($job['coordination_wait_since_utc']??''),'manual_followup_steps_required'=>0,'google_live_serp_used'=>false,'updated_at_utc'=>(string)$job['updated_at_utc']];}
    private static function isTransientCoordinationCode(string $code): bool {return in_array($code,self::TRANSIENT_COORDINATION_CODES,true);}
    private static function isReplaySafeLocalFinalizeCode(string $code): bool {return in_array($code,self::REPLAY_SAFE_LOCAL_FINALIZE_CODES,true);}
    private static function canReplayLocalFinalize(array $job): bool {if((string)($job['phase']??'')!=='FINALIZE'||(int)($job['progress']??-1)!==self::PROVIDER_STEPS)return false;foreach(['KEYWORD_SUGGESTION','RELATED_SEARCH','KEYWORD_IDEA'] as $source)if(!is_array($job['sources'][$source]['items']??null))return false;return true;}
    private static function recoverReplaySafeLocalFinalizePause(array $job,string $code): array {$receipt=hash('sha256','PSTE_LOCAL_FINALIZE_REPLAY_V1|'.(string)$job['job_uuid'].'|'.$code.'|'.(string)$job['progress']);if(hash_equals($receipt,(string)($job['local_finalize_replay_receipt']??'')))return $job;$job['status']='RUNNING';$job['phase_state']='IDLE';$job['last_error']='';$job['coordination_wait_code']='PSTE_LOCAL_FINALIZE_REPLAY_SAFE';$job['coordination_wait_since_utc']=gmdate('c');$job['local_finalize_replay_source_error']=$code;$job['local_finalize_replay_receipt']=$receipt;$job['updated_at_utc']=gmdate('c');self::save($job);return $job;}
    private static function coordinationWait(array $job,string $code): array {$job['status']='RUNNING';$job['phase_state']='IDLE';$job['last_error']='';if((string)($job['coordination_wait_code']??'')!==$code)$job['coordination_wait_since_utc']=gmdate('c');$job['coordination_wait_code']=$code;$job['updated_at_utc']=gmdate('c');self::save($job);return self::summary($job);}
    private static function recoverTransientCoordinationPause(array $job,string $code): array {$job['status']='RUNNING';$job['phase_state']='IDLE';$job['last_error']='';$job['coordination_wait_code']=$code;$job['coordination_wait_since_utc']=(string)($job['coordination_wait_since_utc']??gmdate('c'));$job['updated_at_utc']=gmdate('c');self::save($job);return $job;}
    private static function load(): array {$job=self::rawJob();if($job===null)throw new RuntimeException('PSTE_RESEARCH_JOB_MISSING');self::assertJob($job);return $job;}
    private static function rawJob(): ?array {$v=get_option(PSTE_OPTION_ACTIVE_RESEARCH_JOB,null);if($v===null||$v===false||$v==='')return null;if(!is_array($v))throw new RuntimeException('PSTE_RESEARCH_JOB_STORAGE_INVALID');return $v;}
    private static function save(array $job): void {$job=self::withHash($job);update_option(PSTE_OPTION_ACTIVE_RESEARCH_JOB,$job,false);$stored=get_option(PSTE_OPTION_ACTIVE_RESEARCH_JOB,null);if(!is_array($stored)||!hash_equals((string)$job['sha256'],(string)($stored['sha256']??'')))throw new RuntimeException('PSTE_RESEARCH_JOB_READBACK_MISMATCH');self::assertJob($stored);}
    private static function deleteIfSame(array $job): void {$stored=self::rawJob();if($stored!==null&&hash_equals((string)$job['job_uuid'],(string)($stored['job_uuid']??'')))delete_option(PSTE_OPTION_ACTIVE_RESEARCH_JOB);}
    private static function withHash(array $job): array {$job['contract']=self::CONTRACT;$job['version']=self::VERSION;unset($job['sha256']);$job['sha256']=hash('sha256',self::canonicalJson($job));return $job;}
    private static function assertJob(array $job): void {if(($job['contract']??'')!==self::CONTRACT||!in_array((string)($job['version']??''),self::COMPATIBLE_VERSIONS,true))throw new RuntimeException('PSTE_RESEARCH_JOB_CONTRACT_INVALID');$declared=(string)($job['sha256']??'');$copy=$job;unset($copy['sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(hash('sha256',self::canonicalJson($copy)),$declared))throw new RuntimeException('PSTE_RESEARCH_JOB_HASH_MISMATCH');if(!preg_match('/^[a-f0-9-]{20,64}$/i',(string)($job['job_uuid']??'')))throw new RuntimeException('PSTE_RESEARCH_JOB_UUID_INVALID');if((int)($job['total_provider_steps']??0)!==self::PROVIDER_STEPS||(int)($job['progress']??-1)<0||(int)$job['progress']>self::PROVIDER_STEPS)throw new RuntimeException('PSTE_RESEARCH_JOB_PROGRESS_INVALID');if(!in_array((string)($job['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_RESEARCH_JOB_STATUS_INVALID');if(!in_array((string)($job['phase']??''),['KEYWORD_SUGGESTIONS','RELATED_KEYWORDS','KEYWORD_IDEAS','FINALIZE'],true))throw new RuntimeException('PSTE_RESEARCH_JOB_PHASE_INVALID');}
    private static function canonicalJson($value): string {$json=wp_json_encode(self::canonicalize($value),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($json))throw new RuntimeException('PSTE_RESEARCH_JOB_JSON_ENCODE_FAILED');return $json;}
    private static function canonicalize($value){if(!is_array($value))return $value;if($value===[])return [];$list=array_keys($value)===range(0,count($value)-1);if($list)return array_map([self::class,'canonicalize'],$value);ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=self::canonicalize($v);return $value;}
    private static function acquireStepLock(): string {$token=hash('sha256',microtime(true).'|'.wp_generate_uuid4());$payload=['token'=>$token,'expires_at'=>time()+self::STEP_LOCK_TTL];if(add_option(PSTE_OPTION_RESEARCH_STEP_LOCK,$payload,'',false))return $token;$existing=get_option(PSTE_OPTION_RESEARCH_STEP_LOCK,[]);if(is_array($existing)&&(int)($existing['expires_at']??0)<time()){if(get_option(PSTE_OPTION_RESEARCH_STEP_LOCK,[])===$existing)delete_option(PSTE_OPTION_RESEARCH_STEP_LOCK);if(add_option(PSTE_OPTION_RESEARCH_STEP_LOCK,$payload,'',false))return $token;}throw new RuntimeException('PSTE_RESEARCH_STEP_ALREADY_RUNNING');}
    private static function releaseStepLock(string $token): void {$existing=get_option(PSTE_OPTION_RESEARCH_STEP_LOCK,[]);if(is_array($existing)&&hash_equals($token,(string)($existing['token']??'')))delete_option(PSTE_OPTION_RESEARCH_STEP_LOCK);}
    private static function errorCode(Throwable $e): string {$code=strtoupper(trim($e->getMessage()));$code=(string)preg_replace('/[^A-Z0-9_:\-]/','_',$code);return substr($code!==''?$code:'PSTE_RESEARCH_JOB_FAILED',0,180);}
    private static function mysqlDate(string $value): string {$ts=strtotime($value);return gmdate('Y-m-d H:i:s',$ts===false?time():$ts);}
}
