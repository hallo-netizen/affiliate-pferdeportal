# 0.22.0 — gebündelte Ursachenreparatur

- echter 0.20.0-Legacy-Rohkeywordzustand als Release-Fixture; echte Rohquellen getrennt von Mirrors
- frischer transaktionaler Storage-Preflight vor jeder PSTE-Transaktion; ein zentraler Transaction Owner
- Family-Reclassification nutzt denselben Transaction Owner
- Sandbox-Reentry atomar und mit durablem/idempotentem DB-Receipt für Cross-Store-Retry
- Portalrelevanz ist erster semantischer Decision Owner; Familienzuordnung erst nach Relevanz-PASS
- keine Artikel-, Taxonomie-, Textmaschinen-, Prompt-, Content- oder Designwrites
