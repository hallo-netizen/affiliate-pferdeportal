# Portal SEO Themenengine 0.8.2-staging

## Sicherheitskorrekturen vor der ersten Live-Migration

- Keine operative Admin-Aktion ist vor `READY` registriert; erreichbar bleibt ausschließlich der ausdrücklich manuelle Migrationsendpunkt.
- Kontext-/Portalabgleich ist vor `READY` auf Start, Batch, Cron und Scheduler hart gesperrt.
- Der erste Migrationsstatus liegt jetzt innerhalb der vollständigen `Throwable`-Eindämmung und muss nachweisbar gespeichert sein, bevor Repository- oder Schemaarbeit beginnt.
- Der Migrations-Lock verwendet ein eigenes Token, wird nach dem Schreiben zurückgelesen und nur vom eigenen Lauf entfernt.
- Unterbrochene Migrationszustände werden ohne automatischen Wiederholungsversuch als `BLOCKED` ausgewiesen.
- Zulässige Ausgangsschemata werden vor jeder Repository-Arbeit geprüft; Schema 7 ist ausdrücklich abgedeckt.
- Vor und nach der Migration werden Themen, Kandidaten, Fundstellen, Zuordnungen, Historie und Identitäten gezählt.
- Schema 9 wird erst geschrieben, nachdem Anzahlserhalt, UUID-Identitäten und Relationskonsistenz bestätigt sind.
- Neuer exakter Schema-7-Test mit 22 globalen Themen und 61 Fundstellen sowie erzwungenem Rollbackfehler.

## Unverändert geschützt

- Keine Änderung an Textproduktionsmaschine, Production Center oder Editorial Guard.
- Keine Schreibzugriffe auf Beiträge, Kategorien, URLs, Yoast, Post-/Term-Metadaten oder fremde Plugins.
- Keine Recherche, keine kostenpflichtige API-Abfrage und keine Produktionsübergabe während Aktivierung oder Migration.
- Produktionsanbindung bleibt `NO_CONNECTION_INFORMATIONAL_ONLY` und ist nicht Bestandteil dieser Version.
