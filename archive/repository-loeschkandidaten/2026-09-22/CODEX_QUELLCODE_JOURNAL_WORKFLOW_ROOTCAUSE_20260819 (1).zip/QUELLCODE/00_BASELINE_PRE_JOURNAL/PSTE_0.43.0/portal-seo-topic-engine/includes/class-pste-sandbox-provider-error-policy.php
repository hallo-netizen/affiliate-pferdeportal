<?php
if (!defined('ABSPATH')) { return; }

/**
 * Pure provider-fault scope classifier for the Semantic Review Sandbox.
 * It never makes SEO relevance, family, category, title or production decisions.
 */
final class PSTE_Sandbox_Provider_Error_Policy {
    public const CONTRACT='PSTE_SANDBOX_PROVIDER_ERROR_POLICY_V1';
    public const CIRCUIT_BREAKER_THRESHOLD=3;
    public const MAX_DEFERRED_RETRY_CYCLES=2;

    /** @return array<string,mixed> */
    public static function classifyMachineCode(string $machineCode,array $safeDetails=[]): array {
        $machineCode=strtoupper(trim($machineCode));
        $providerCode=(int)($safeDetails['provider_status_code']??0);
        if($providerCode<=0&&preg_match('/^PSTE_PROVIDER_TASK_ERROR_(\d+)$/',$machineCode,$m))$providerCode=(int)$m[1];

        if($machineCode==='PSTE_PROVIDER_TRANSPORT_OUTCOME_UNKNOWN')return self::result('GLOBAL_OUTCOME_UNKNOWN','OUTCOME_UNKNOWN',false,false,$providerCode);

        if(str_starts_with($machineCode,'PSTE_PROVIDER_TASK_ERROR_')){
            // Explicit allowlist for the Google Organic SERP Live review path. Unknown or endpoint-foreign
            // task codes are contract/system conditions and therefore fail closed job-wide.
            if($providerCode===40102)return self::result('CANDIDATE_NO_RESULTS','UNCERTAIN_REVIEW',false,false,$providerCode);
            if(in_array($providerCode,[40101,40103,50401],true))return self::result('CANDIDATE_DEFER_RETRY','DEFERRED_PROVIDER_ERROR',true,false,$providerCode);
            return self::result('GLOBAL_PAUSE','PAUSED_ERROR',false,true,$providerCode);
        }

        // HTTP/general/account/auth/billing/rate/configuration/provider-global failures are job-scoped.
        return self::result('GLOBAL_PAUSE','PAUSED_ERROR',false,true,$providerCode);
    }

    /** @return array<string,mixed> */
    public static function classifyException(PSTE_Provider_Exception $e): array {
        return self::classifyMachineCode((string)$e->getMessage(),$e->safeDetails());
    }

    public static function knownCostUsd(array $safeDetails): float {
        $current=max(0.0,(float)($safeDetails['response_cost']??0.0));
        $prior=max(0.0,(float)($safeDetails['retry_known_cost_usd']??0.0));
        return round($current+$prior,6);
    }

    /** @return array<string,mixed> */
    private static function result(string $scope,string $candidateStatus,bool $deferredRetry,bool $globalPause,int $providerCode): array {
        return [
            'contract'=>self::CONTRACT,
            'scope'=>$scope,
            'candidate_status'=>$candidateStatus,
            'deferred_retry_allowed'=>$deferredRetry,
            'global_pause'=>$globalPause,
            'provider_status_code'=>$providerCode,
        ];
    }
}
