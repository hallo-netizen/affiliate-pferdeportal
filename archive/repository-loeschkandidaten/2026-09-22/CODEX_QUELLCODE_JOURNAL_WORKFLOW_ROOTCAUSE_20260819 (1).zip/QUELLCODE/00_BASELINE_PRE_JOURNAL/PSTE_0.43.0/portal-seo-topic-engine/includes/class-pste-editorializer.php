<?php
if (!defined('ABSPATH')) { return; }

/**
 * Metadata-only editorial orchestration. One title owner: PSTE_Title_Pipeline.
 * It never creates or passes article content, outline, facts, HTML, links, formatting or design.
 */
final class PSTE_Editorializer {
    public const RULESET='PSTE_PRACTICAL_EDITORIALIZATION_V13_ARTICLE_INTENT_TITLE_GATE';
    private const RESOLVED_REASON_CODES=['FAQ_NON_QUESTION_DISCOVERY_TERM','FAQ_INTENT_MISMATCH','FAQ_RECOMMENDATION_OR_SUPERLATIVE_REVIEW','COMMERCIAL_QUERY_NOT_FAQ'];

    public static function apply(array $candidate): array {
        $baseline=function_exists('get_option')?get_option(defined('PSTE_OPTION_SITE_BASELINE')?PSTE_OPTION_SITE_BASELINE:'pste_site_baseline_v1',[]):[];
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1'){
            $candidate['editorialization']=['contract'=>self::RULESET,'eligible'=>false,'resolved'=>false,'ambiguous'=>false,'article_type'=>'','title'=>'','normalized_topic'=>'','intent_key'=>'','signals'=>[],'reason'=>'BASELINE_REQUIRED','title_pipeline'=>[]];
            return $candidate;
        }
        return PSTE_Normal_Metadata_Path::applyToPayload($candidate,$baseline,(string)($candidate['topic_family_key']??''));
    }

    /** @return array<string,mixed> */
    public static function analyze(string $query,string $family,string $currentType='',array $availableTypes=[],array $registry=[]): array {
        $query=self::cleanRaw($query);$family=self::cleanRaw($family);
        $base=['contract'=>self::RULESET,'eligible'=>false,'resolved'=>false,'ambiguous'=>false,'article_type'=>'','title'=>'','normalized_topic'=>'','intent_key'=>'','signals'=>[],'reason'=>'','title_pipeline'=>[]];
        if($query===''||$family===''){$base['reason']='QUERY_OR_FAMILY_MISSING';return $base;}
        if(PSTE_Normalizer::staleYear($query)!==null){$base['reason']='STALE_YEAR_SPECIFIC_QUERY';return $base;}
        if(self::isPureTransactionalQuery($query)){$base['reason']='TRANSACTIONAL_QUERY';return $base;}

        $question=PSTE_Normalizer::isQuestion($query);$signals=$question?['FAQ']:self::signals($query,$availableTypes);$base['signals']=$signals;
        if(count($signals)>1){$base['eligible']=true;$base['ambiguous']=true;$base['reason']='MULTIPLE_ARTICLE_TYPE_SIGNALS';return $base;}
        $type=$signals?(string)$signals[0]:'';
        if($type===''){
            $base['reason']='NO_DETERMINISTIC_EDITORIAL_SIGNAL';
            return $base;
        }
        if(!$registry&&function_exists('get_option')){$b=get_option(defined('PSTE_OPTION_SITE_BASELINE')?PSTE_OPTION_SITE_BASELINE:'pste_site_baseline_v1',[]);if(is_array($b)&&($b['contract']??'')==='PSTE_SITE_BASELINE_V1')$registry=PSTE_Article_Type_Registry::build($b);}
        $record=['raw_query'=>$query,'language_corrected_query'=>$query];
        $normalization=PSTE_Editorial_Topic_Normalizer::normalize($query,$family,[]);
        $preIntent=PSTE_Intent_Profile::analyzeBeforeType($query,$normalization,$family,[]);
        $canon=PSTE_Article_Type_Registry::canonicalType($type);$intent=$canon==='faq'?'QUESTION_INFORMATION':($canon==='vergleich'?'COMPARISON_INFORMATION':($canon==='kosten'?'COST_INFORMATION':'EDITORIAL_INFORMATION'));
        $semanticStub=['resolved_article_type'=>$type,'intent_consensus'=>true,'strand_a'=>['search_intent'=>$intent],'strand_b'=>['search_intent'=>$intent]];
        $familyKey='';foreach((array)($registry['families']??[]) as $k=>$f){if(PSTE_Normalizer::categoryFamilyKey((string)($f['topic_family_name']??''))===PSTE_Normalizer::categoryFamilyKey($family)){$familyKey=(string)$k;break;}}
        if($familyKey==='')$familyKey=(string)array_key_first((array)($registry['families']??[]));
        $intentProfile=PSTE_Intent_Profile::bindArticleType($preIntent,$semanticStub,$registry,$familyKey);
        $pipeline=PSTE_Title_Pipeline::build($record,$family,$type,$registry,[],$intentProfile);
        $base['eligible']=true;$base['article_type']=$type;$base['title_pipeline']=$pipeline;$base['title']=(string)($pipeline['title']??'');$base['target_keyword']=(string)($pipeline['target_keyword']??'');$base['normalized_topic']=(string)($pipeline['normalization']['normalized_topic']??'');
        if(empty($pipeline['ok'])){$base['reason']='DUAL_STRAND_TITLE_PIPELINE_NOT_PASS';return $base;}
        $base['resolved']=true;$base['intent_key']=(string)($intentProfile['intent_key']??hash('sha256',implode('|',[PSTE_Normalizer::categoryFamilyKey($family),$type,PSTE_Normalizer::exactTopicIdentityText((string)$base['normalized_topic'])])));$base['intent_profile']=$intentProfile;$base['reason']='DUAL_STRAND_EDITORIAL_METADATA_PASS';
        return $base;
    }

    public static function displayTitle(array $candidate): string {
        $title='';foreach(['editorial_title','canonical_query','raw_user_question','primary_longtail_query'] as $field){$v=trim((string)($candidate[$field]??''));if($v!==''){$title=$v;break;}}
        if($title==='')return '';
        // Read-time harmonization only for legacy automatically generated Beratung titles that use the
        // now forbidden repeated generic schema. No stored candidate, assignment, intent or article data is changed.
        $manual=is_array($candidate['manual_title_override']??null)?(array)$candidate['manual_title_override']:[];
        $type=(string)($candidate['suggested_article_type']??$candidate['proposed_article_type']??'');
        if(($manual['contract']??'')!=='PSTE_MANUAL_TITLE_OVERRIDE_V1'&&PSTE_Article_Type_Registry::canonicalType($type)==='beratung'&&PSTE_Title_Validator::isRepeatedGenericBeratungSchema($title)){
            $family=trim((string)($candidate['topic_family_name']??''));$keyword=trim((string)($candidate['target_keyword']??''));$source=self::sourceQuery($candidate);
            if($family!==''&&$keyword!==''&&$source!==''){
                $fresh=PSTE_Title_Composer::compose($source,$family,$type,[],is_array($candidate['intent_profile']??null)?(array)$candidate['intent_profile']:[],$keyword);
                if($fresh!=='')return $fresh;
            }
        }
        return $title;
    }
    public static function sourceQuery(array $candidate): string {foreach(['raw_user_question','primary_longtail_query','canonical_query'] as $field){$v=trim((string)($candidate[$field]??''));if($v!=='')return $v;}return '';}

    /** @return list<string> */
    private static function signals(string $query,array $availableTypes=[]): array {
        return PSTE_Article_Type_Intent_Ontology::strongSignals($query,$availableTypes);
    }
    private static function isPureTransactionalQuery(string $query): bool {$transactional=(bool)preg_match('/\b(sale|angebot|angebote|rabatt|gutschein|coupon|shop|online\s+kaufen|bestellen)\b/iu',$query);return $transactional&&!PSTE_Article_Type_Intent_Ontology::hasExplicitIntentOrAmbiguity($query);}
    private static function cleanRaw(string $value): string {$value=trim(html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($value):strip_tags($value),ENT_QUOTES|ENT_HTML5,'UTF-8'));return trim((string)preg_replace('/\s+/u',' ',$value));}
}
