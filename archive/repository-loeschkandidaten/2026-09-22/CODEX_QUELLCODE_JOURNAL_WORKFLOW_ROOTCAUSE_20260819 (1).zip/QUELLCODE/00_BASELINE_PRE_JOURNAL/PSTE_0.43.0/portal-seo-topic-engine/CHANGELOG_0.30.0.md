# Portal SEO Themenengine 0.30.0

- Existing mandatory title-quality rules are enforced as hard upstream release gates.
- Target keyword must be the exact case-insensitive title prefix.
- Artificial generator filler and keyword staccato block instead of passing downstream.
- Title composer no longer adds semantically empty filler phrases.
- Manual title override is title-only, revalidated, identity-bound and has zero authority over intent, article type, category, semantic duplicate identity, plan slot, content or design.
- Safe migration protocol/ruleset bumped so stored planning titles are rebuilt under the same semantic bindings.
- PPM/Textmaschine remains untouched.
