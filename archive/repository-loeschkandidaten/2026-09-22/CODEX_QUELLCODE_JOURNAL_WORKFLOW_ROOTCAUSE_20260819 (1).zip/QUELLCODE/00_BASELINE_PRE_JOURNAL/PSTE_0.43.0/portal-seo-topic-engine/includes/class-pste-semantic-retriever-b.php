<?php
if (!defined('ABSPATH')) { return; }

/** Independent semantic strand B with a separate syntax/ontology implementation. */
final class PSTE_Semantic_Retriever_B {
    /** @return array<string,mixed> */
    public static function retrieve(string $query,array $registry,string $familyKey): array {
        $family=$registry['families'][$familyKey]??null;if(!is_array($family))return self::blocked('B_FAMILY_SCOPE_NOT_IN_REGISTRY',$registry,$familyKey,[]);
        $available=[];foreach((array)($family['by_type']??[]) as $row)$available[]=(string)($row['article_type']??'');
        $points=[];$why=[];$intentQuery=self::withoutFamilyPhrase($query,(string)($family['topic_family_name']??''));$trim=trim($intentQuery);$firstRaw=(string)(preg_split('/\s+/u',$trim)[0]??'');$first=PSTE_Normalizer::exactTopicIdentityText($firstRaw);
        $interrogatives=['wie','was','wann','warum','wieso','weshalb','welche','welcher','welches','kann','koennen','darf','soll','ist','sind','gibt','braucht','benoetigt','frieren','friert','passen','passt','eignen','eignet','reichen','reicht','helfen','hilft','schaden','schadet','waermen','waermt','bleiben','bleibt'];
        if(str_ends_with($trim,'?')||in_array($first,$interrogatives,true))self::put($points,$why,'FAQ',121,'B_INTERROGATIVE_SYNTAX',$available);
        $explicit=self::nomenclatureMatch($intentQuery,$registry,$available);if($explicit!=='')self::put($points,$why,$explicit,109,'B_REGISTRY_NOMENCLATURE',$available);
        foreach(PSTE_Article_Type_Intent_Ontology::strongSignals($intentQuery,$available) as $type)self::put($points,$why,$type,86,'B_EXPLICIT_INTENT_ONTOLOGY_SIGNAL',$available);
        $ambiguous=PSTE_Article_Type_Intent_Ontology::ambiguousNonSignalHits($intentQuery);
        if(!$points&&!$ambiguous&&!self::commercial($intentQuery)&&count(PSTE_Normalizer::tokens($intentQuery))>=1)self::put($points,$why,'Beratung',51,'B_INFORMATIONAL_SENTENCE_SHAPE',$available);
        if(!$points&&$ambiguous)$why['__review__']=$ambiguous;
        return self::complete($points,$why,$registry,$familyKey,$family);
    }

    /** @return array<string,mixed> */
    private static function complete(array $points,array $why,array $registry,string $familyKey,array $family): array {
        arsort($points,SORT_NUMERIC);$candidates=[];
        foreach($points as $canonical=>$score){$type=PSTE_Article_Type_Registry::visibleType($registry,$canonical);$resolved=PSTE_Article_Type_Registry::resolve($registry,$familyKey,$type);$candidates[]=['canonical_type_id'=>$canonical,'article_type'=>$type,'score'=>$score,'reason_codes'=>array_values(array_unique((array)($why[$canonical]??[]))),
            'category_id'=>!empty($resolved['ok'])?(int)$resolved['term_id']:0,'category_slug'=>!empty($resolved['ok'])?(string)$resolved['slug']:'','category_name'=>!empty($resolved['ok'])?(string)$resolved['name']:'','category_full_path'=>!empty($resolved['ok'])?(string)($resolved['full_path']??''):'','topic_family_key'=>$familyKey,'topic_family_name'=>(string)($family['topic_family_name']??''),'category_available'=>!empty($resolved['ok'])];}
        $top=(int)($candidates[0]['score']??0);$second=(int)($candidates[1]['score']??0);$margin=$top-$second;$assigned=false;$reason='B_NO_UNAMBIGUOUS_SIGNAL';
        if(count($candidates)===1){$assigned=true;$reason=(string)($candidates[0]['reason_codes'][0]??'B_ASSIGNED');}
        elseif(count($candidates)>1&&$margin>=25){$assigned=true;$reason=(string)($candidates[0]['reason_codes'][0]??'B_ASSIGNED_MARGIN');}
        elseif(count($candidates)>1)$reason='B_RETRIEVER_AMBIGUOUS_REVIEW';
        $chosen=$assigned?(array)$candidates[0]:[];$target=[];if($assigned&&!empty($chosen['category_available']))$target=PSTE_Article_Type_Registry::resolve($registry,$familyKey,(string)$chosen['article_type']);
        $canonical=PSTE_Article_Type_Registry::canonicalType((string)($chosen['article_type']??''));$intent=$canonical==='faq'?'QUESTION_INFORMATION':($canonical==='vergleich'?'COMPARISON_INFORMATION':($canonical==='kosten'?'COST_INFORMATION':'EDITORIAL_INFORMATION'));
        return ['contract'=>'PSTE_RETRIEVER_RESULT_V1','strand'=>'B','status'=>$assigned?'ASSIGNED':'BLOCKED','article_type'=>$assigned?(string)$chosen['article_type']:'','reason'=>$reason,'meaning'=>$canonical===''?'':'PORTAL_TOPIC_'.strtoupper(str_replace(' ','_',$canonical)),'search_intent'=>$intent,
            'topic_family_key'=>$familyKey,'topic_family_name'=>(string)($family['topic_family_name']??''),'target_category'=>$target,'candidates'=>$candidates,'top_score'=>$top,'runner_up_score'=>$second,'score_margin'=>$margin,
            'candidate_set_hash'=>hash('sha256',self::stable($candidates)),'coverage_status'=>$candidates?'COVERAGE_PRESENT':'COVERAGE_MISSING','ambiguity_status'=>count($candidates)>1&&$margin<25?'AMBIGUOUS':'CLEAR',
            'index_hash'=>hash('sha256',self::stable(['rows'=>(array)($family['by_type']??[]),'registry'=>(string)($registry['registry_sha256']??'')])),'structure_hash'=>(string)($registry['structure_sha256']??''),
            'input_contract'=>['query_only'=>true,'family_scope_only'=>true,'proposed_type_received'=>false,'proposed_category_received'=>false,'other_strand_received'=>false]];
    }
    /** @return array<string,mixed> */
    private static function blocked(string $reason,array $registry,string $familyKey,array $rows): array {return ['contract'=>'PSTE_RETRIEVER_RESULT_V1','strand'=>'B','status'=>'BLOCKED','article_type'=>'','reason'=>$reason,'meaning'=>'','search_intent'=>'UNKNOWN','topic_family_key'=>$familyKey,'topic_family_name'=>'','target_category'=>[],'candidates'=>$rows,'top_score'=>0,'runner_up_score'=>0,'score_margin'=>0,'candidate_set_hash'=>hash('sha256',self::stable($rows)),'coverage_status'=>'COVERAGE_MISSING','ambiguity_status'=>'CLEAR','index_hash'=>hash('sha256',self::stable($registry)),'structure_hash'=>(string)($registry['structure_sha256']??''),'input_contract'=>['query_only'=>true,'family_scope_only'=>true,'proposed_type_received'=>false,'proposed_category_received'=>false,'other_strand_received'=>false]];}
    private static function put(array &$points,array &$why,string $type,int $score,string $reason,array $available): void {$wanted=PSTE_Article_Type_Registry::canonicalType($type);$actual='';foreach($available as $x)if(PSTE_Article_Type_Registry::canonicalType($x)===$wanted){$actual=$wanted;break;}if($actual==='')return;$points[$actual]=max((int)($points[$actual]??0),$score);$why[$actual][]=$reason;}
    private static function nomenclatureMatch(string $query,array $registry,array $available): string {$hay=PSTE_Normalizer::exactTopicIdentityText($query);foreach($available as $type){$aliases=PSTE_Article_Type_Registry::aliasesFor($registry,$type);usort($aliases,static fn($x,$y)=>strlen((string)$y)<=>strlen((string)$x));foreach($aliases as $alias){$needle=PSTE_Normalizer::exactTopicIdentityText((string)$alias);if($needle!==''&&preg_match('/(?:^|\s)'.preg_quote($needle,'/').'(?:\s|$)/u',$hay))return $type;}}return '';}
    private static function withoutFamilyPhrase(string $query,string $family): string {
        $family=trim($family);if($family==='')return trim($query);
        $stripped=preg_replace('/'.preg_quote($family,'/').'/iu',' ',trim($query),1);
        return trim((string)preg_replace('/\s+/u',' ',$stripped??$query));
    }
    private static function commercial(string $q): bool {return (bool)preg_match('/\b(sale|coupon|gutschein|rabatt|shop|bestellen|online\s+kaufen)\b/iu',$q);}
    private static function stable($value): string {$value=self::sort($value);$j=function_exists('wp_json_encode')?wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($j)?$j:'';}
    private static function sort($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'sort'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::sort($x);return $v;}
}
