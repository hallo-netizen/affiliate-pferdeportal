# 0.10.4-staging

- Korrigiert die falsche Annahme, dass die Portalhierarchie als verschachtelte WordPress-Kategorietaxonomie vorliegt.
- Liest die reale Struktur read-only als WordPress-Seitenbaum der Ebenen 1–3 plus flache WordPress-Themenkategorien der Ebene 4.
- Verknüpft jede Produktionskategorie eindeutig über Produktseiten-Slug, Seitentitel und vollständigen Seitenpfad; sachfremde Zusatzkategorien werden getrennt ignoriert.
- Unterstützt weitere Beitragsarten dynamisch über Namens-/Slugvertrag oder explizites `pste_article_type`-Term-Meta, ohne die Textmaschine zu verändern.
- Korrigiert den Baseline-SHA-256 auf kanonische JSON-Bildung, damit der read-only Compiler die Live-Baseline reproduzierbar prüfen kann.
- Entfernt den Erfassungszeitpunkt aus dem Struktur-Digest. Eine unveränderte Struktur bleibt dadurch auch nach einem Sekundenwechsel tatsächlich `CURRENT`.
- Änderungen an ausdrücklich ignorierten, sachfremden WordPress-Kategorien machen die SEO-Struktur nicht mehr fälschlich veraltet.
- Doppelte oder defekte Seitenzweige außerhalb der erkannten Portalwurzeln blockieren die SEO-Engine nicht; echte Mehrdeutigkeit oder ein defekter verwendeter Portalpfad blockiert weiterhin fail-closed.
- Die Frischeprüfung meldet neu auftretende, nicht auflösbare Produktionskategorien mit dem konkreten Strukturfehler statt nur pauschal `STALE`.
- Nach dem Gesamtbestandsabgleich wird der erste rein lokale Portalabgleich-Batch sofort verarbeitet; beim aktuellen 81-Themen-Bestand entfällt dadurch ein zusätzlicher manueller Fortsetzungsschritt.
- Keine Schreibzugriffe auf Beiträge, Kategorien, Seiten, Design, HTML oder Textmaschine.
