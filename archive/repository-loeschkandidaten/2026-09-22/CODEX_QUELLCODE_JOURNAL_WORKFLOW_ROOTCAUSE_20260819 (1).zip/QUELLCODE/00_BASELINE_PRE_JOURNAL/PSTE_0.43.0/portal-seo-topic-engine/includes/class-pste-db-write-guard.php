<?php
if (!defined('ABSPATH')) { return; }

/**
 * Central fail-closed guard for every direct database write performed by PSTE.
 *
 * The guard enforces both field/format parity and the storage boundary: direct
 * SQL writes may target only PSTE's own prefixed tables. The sole exception is
 * a DELETE against the WordPress options table for an atomic PSTE lock cleanup.
 * Posts, postmeta, terms, termmeta and all other WordPress tables are rejected.
 */
final class PSTE_DB_Write_Guard {
    public static function assertFieldFormatCountsMatch(array $data,array $formats,string $code,string $scope='DATA'): void {
        $dataCount=count($data);$formatCount=count($formats);
        if($dataCount!==$formatCount)throw new RuntimeException($code.'_'.$scope.'_FIELD_FORMAT_COUNT_MISMATCH_'.$dataCount.'_'.$formatCount);
        foreach($formats as $index=>$format){
            if(!in_array($format,['%s','%d','%f'],true))throw new RuntimeException($code.'_'.$scope.'_FORMAT_INVALID_'.$index);
        }
    }

    public static function insert(string $table,array $data,array $formats,string $code): int {
        global $wpdb;self::assertTableAllowed($table,$code,false);self::assertFieldFormatCountsMatch($data,$formats,$code);$result=$wpdb->insert($table,$data,$formats);if($result===false)throw new RuntimeException($code.':'.self::dbError());return (int)$result;
    }
    public static function replace(string $table,array $data,array $formats,string $code): int {
        global $wpdb;self::assertTableAllowed($table,$code,false);self::assertFieldFormatCountsMatch($data,$formats,$code);$result=$wpdb->replace($table,$data,$formats);if($result===false)throw new RuntimeException($code.':'.self::dbError());return (int)$result;
    }
    public static function update(string $table,array $data,array $where,array $formats,array $whereFormats,string $code): int {
        global $wpdb;self::assertTableAllowed($table,$code,false);self::assertFieldFormatCountsMatch($data,$formats,$code,'DATA');self::assertFieldFormatCountsMatch($where,$whereFormats,$code,'WHERE');$result=$wpdb->update($table,$data,$where,$formats,$whereFormats);if($result===false)throw new RuntimeException($code.':'.self::dbError());return (int)$result;
    }
    public static function delete(string $table,array $where,array $whereFormats,string $code): int {
        global $wpdb;self::assertTableAllowed($table,$code,false);self::assertFieldFormatCountsMatch($where,$whereFormats,$code,'WHERE');$result=$wpdb->delete($table,$where,$whereFormats);if($result===false)throw new RuntimeException($code.':'.self::dbError());return (int)$result;
    }
    public static function query(string $query,string $code,bool $throw=true): int {
        global $wpdb;
        try{self::assertQueryAllowed($query,$code);}catch(Throwable $e){if($throw)throw $e;return -1;}
        $result=$wpdb->query($query);if($result===false&&$throw)throw new RuntimeException($code.':'.self::dbError());return $result===false?-1:(int)$result;
    }

    private static function assertTableAllowed(string $table,string $code,bool $allowOptionsDelete): void {
        global $wpdb;$table=trim($table," `\t\n\r\0\x0B");$own=(string)($wpdb->prefix??'').'pste_';
        if($own!==''&&str_starts_with($table,$own))return;
        if($allowOptionsDelete&&isset($wpdb->options)&&hash_equals((string)$wpdb->options,$table))return;
        throw new RuntimeException($code.'_WRITE_TABLE_NOT_ALLOWED');
    }

    private static function assertQueryAllowed(string $query,string $code): void {
        $sql=trim($query);$upper=strtoupper($sql);
        if(in_array($upper,['START TRANSACTION','COMMIT','ROLLBACK'],true))return;
        if(!preg_match('/^(ALTER\s+TABLE|DELETE\s+FROM|INSERT(?:\s+IGNORE)?\s+INTO|UPDATE|DROP\s+TABLE\s+IF\s+EXISTS)\s+(`?[^`\s(]+`?)/i',$sql,$match)){
            throw new RuntimeException($code.'_WRITE_QUERY_NOT_ALLOWLISTED');
        }
        $operation=strtoupper((string)$match[1]);$table=trim((string)$match[2]," `\t\n\r\0\x0B");
        $allowOptionsDelete=$operation==='DELETE FROM';
        self::assertTableAllowed($table,$code,$allowOptionsDelete);
        global $wpdb;
        if($allowOptionsDelete&&isset($wpdb->options)&&hash_equals((string)$wpdb->options,$table))self::assertOwnOptionsDelete($sql,$code);
    }

    private static function assertOwnOptionsDelete(string $sql,string $code): void {
        if(!preg_match('/\bWHERE\s+option_name\s*(=|LIKE)\s*([\'"])([^\'"]+)\2/i',$sql,$match))throw new RuntimeException($code.'_OPTIONS_DELETE_SCOPE_INVALID');
        $operator=strtoupper((string)$match[1]);$name=(string)$match[3];
        if($operator==='='){
            if(str_starts_with($name,'pste_'))return;
            throw new RuntimeException($code.'_OPTIONS_DELETE_SCOPE_INVALID');
        }
        foreach(['_transient_pste_','_transient_timeout_pste_'] as $prefix)if(str_starts_with($name,$prefix))return;
        throw new RuntimeException($code.'_OPTIONS_DELETE_SCOPE_INVALID');
    }

    private static function dbError(): string {
        global $wpdb;$error=preg_replace('/[^A-Za-z0-9_:\- ]/','',(string)($wpdb->last_error??''));return substr((string)$error,0,160);
    }
}
