# Portal SEO Themenengine 0.8.4-staging

## Allgemeine Titel- und Fragenautomatik

- Neues allgemeines Regelwerk `PSTE_GENERAL_EDITORIALIZATION_V1` ohne portal- oder branchenspezifisches Kernvokabular.
- Eindeutige Suchphrasen werden automatisch zu redaktionellen Titeln oder Fragen und vorhandenen Artikeltypen derselben Themenfamilie zugeordnet.
- Mehrdeutige Mehrfachsignale bleiben ungeklärt; rein transaktionale Suchphrasen bleiben Recherchebegriffe.
- Identische redaktionelle Intentionen werden nicht gelöscht oder destruktiv verschmolzen. Ein Hauptthema bleibt erhalten, Varianten bleiben als nicht produzierende Keywordvarianten bestehen.
- Einmaliger Backend-Schritt `Titelautomatik jetzt gesammelt anwenden` verarbeitet den gesamten Themenpool und aktualisiert den Portalabgleich im selben Bedienvorgang.
- Originalphrase, Fundstellen, Evidenz, UUIDs, Zuordnungen und Historie bleiben erhalten.
- Keine Änderung oder Übergabe an Textproduktionsmaschine, Production Center, Editorial Guard, Beiträge, Kategorien, URLs oder Yoast.
