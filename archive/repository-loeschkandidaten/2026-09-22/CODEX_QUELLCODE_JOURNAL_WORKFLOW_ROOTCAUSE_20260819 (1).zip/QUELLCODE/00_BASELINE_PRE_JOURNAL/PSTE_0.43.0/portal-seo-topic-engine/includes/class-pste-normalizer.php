<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Normalizer {
    private const STOPWORDS = ['der','die','das','den','dem','des','ein','eine','einer','einem','einen','und','oder','von','für','fuer','bei','beim','im','in','auf','mit','zu','zum','zur','ich','du','man','muss','musst','soll','sollte','solltest','ist','sind','was','wie','welche','welcher','welches','wann','warum','wieso','weshalb','dazu','hier','richtig','nach'];
    private const MAP = [
        'beachten' => 'achten', 'achtet' => 'achten', 'wichtig' => 'achten', 'worauf' => 'achten', 'darauf' => 'achten',
        'auswaehlen' => 'auswahl', 'waehlen' => 'auswahl', 'entscheidung' => 'auswahl', 'entscheiden' => 'auswahl', 'kaufen' => 'auswahl',
        'vergleichen' => 'vergleich', 'unterschiede' => 'vergleich', 'unterschied' => 'vergleich', 'unterscheidet' => 'vergleich', 'unterscheiden' => 'vergleich', 'gegenueber' => 'vergleich', 'versus' => 'vergleich', 'vs' => 'vergleich',
        'reinigen' => 'pflege', 'pflegen' => 'pflege', 'saeubern' => 'pflege', 'trocknen' => 'pflege', 'lagern' => 'lagerung', 'aufbewahren' => 'lagerung',
        'materialunterschiede' => 'material', 'materialunterschied' => 'material', 'preisunterschiede' => 'preis', 'preisunterschied' => 'preis',
        'fehler' => 'problem', 'probleme' => 'problem', 'sinnvoll' => 'eignung', 'geeignet' => 'eignung', 'eignet' => 'eignung',
    ];
    private const ARTICLE_TYPES = ['FAQ','Beratung','Vergleich','Pflege','Kosten','Sicherheit','Installation','Anwendung','Lagerung','Übungen','Wissen'];

    public static function articleTypes(): array {
        $types=self::ARTICLE_TYPES;
        if(function_exists('apply_filters'))$types=(array)apply_filters('pste_article_types',$types);
        return array_values(array_unique(array_filter(array_map('strval',$types))));
    }

    public static function text(string $value): string {
        $value = trim(html_entity_decode(wp_strip_all_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        $value = strtr($value, ['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss','–'=>' ','—'=>' ','-'=>'']);
        $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
        $value = preg_replace('/[^a-z0-9\s]+/u', ' ', $value) ?? '';
        $tokens = preg_split('/\s+/', trim($value)) ?: [];
        $out = [];
        foreach ($tokens as $token) {
            if ($token === '' || in_array($token, self::STOPWORDS, true)) { continue; }
            $out[] = self::MAP[$token] ?? self::stem($token);
        }
        $out = array_values(array_unique($out));
        sort($out, SORT_STRING);
        return implode(' ', $out);
    }

    private static function stem(string $token): string {
        foreach (['ern','en','er','es','e','n','s'] as $suffix) {
            if (strlen($token) > strlen($suffix) + 4 && str_ends_with($token, $suffix)) { return substr($token, 0, -strlen($suffix)); }
        }
        return $token;
    }

    public static function tokens(string $value): array {
        $n = self::text($value);
        return $n === '' ? [] : explode(' ', $n);
    }

    public static function similarity(string $a, string $b): float {
        $ta = self::tokens($a); $tb = self::tokens($b);
        if (!$ta || !$tb) { return 0.0; }
        $intersection = count(array_intersect($ta, $tb));
        $union = count(array_unique(array_merge($ta, $tb)));
        return $union > 0 ? round($intersection / $union, 6) : 0.0;
    }

    public static function categoryArticleType(string $categoryName): string {
        $name = trim($categoryName);
        foreach (self::articleTypes() as $type) {
            if (preg_match('/^'.preg_quote($type,'/').'\s+/iu', $name)) { return $type; }
        }
        return '';
    }

    public static function categoryFamilyName(string $categoryName): string {
        $pattern = '/^('.implode('|', array_map(static fn($v)=>preg_quote($v,'/'), self::articleTypes())).')\s+/iu';
        return trim((string)(preg_replace($pattern, '', trim($categoryName)) ?? $categoryName));
    }

    public static function categoryFamilyKey(string $categoryName): string {
        return self::text(self::categoryFamilyName($categoryName));
    }

    /** Stable identity for same-named families in different portal branches. */
    public static function categoryFamilyScopedKey(string $categoryName,string $parentSlug=''): string {
        $family=self::categoryFamilyKey($categoryName);
        $scope=self::text($parentSlug);
        if($family==='')return '';
        return $scope===''?$family:hash('sha256',$scope.'|'.$family);
    }

    public static function categoryHeadText(string $categoryName): string {
        return self::categoryFamilyName($categoryName);
    }

    public static function categoryHead(string $categoryName): string {
        return self::categoryFamilyKey($categoryName);
    }

    public static function isQuestion(string $value): bool {
        return self::isExplicitQuestion($value) || self::isNaturalYesNoQuestion($value);
    }

    public static function isExplicitQuestion(string $value): bool {
        $raw=trim($value);
        return str_ends_with($raw,'?') || (bool)preg_match('/^(wie|was|wann|warum|wieso|weshalb|welche|welcher|welches|worauf|wieviel|wie viel|kann|koennen|können|darf|soll|sind|ist|gibt|braucht|benötigt|benoetigt)\b/iu',$raw);
    }

    public static function isNaturalYesNoQuestion(string $value): bool {
        $raw=trim($value);
        if($raw==='' || str_ends_with($raw,'?'))return false;
        return (bool)preg_match('/^(frieren|friert|brauchen|braucht|benoetigen|benötigen|benoetigt|benötigt|tragen|traegt|trägt|halten|haelt|hält|schuetzen|schützen|schuetzt|schützt|passen|passt|verursachen|verursacht|machen|macht|werden|wird|koennen|können|kann|duerfen|dürfen|darf|sollen|soll|muessen|müssen|muss|eignen|eignet|reichen|reicht|helfen|hilft|schaden|schadet|waermen|wärmen|waermt|wärmt|bleiben|bleibt)\s+\S+/iu',$raw);
    }

    public static function canonicalQuestion(string $value): string {
        $raw=rtrim(trim($value)," ?\t\n\r\0\x0B");
        if($raw==='')return '';
        $first=function_exists('mb_substr')?mb_substr($raw,0,1,'UTF-8'):substr($raw,0,1);
        $rest=function_exists('mb_substr')?mb_substr($raw,1,null,'UTF-8'):substr($raw,1);
        $first=function_exists('mb_strtoupper')?mb_strtoupper($first,'UTF-8'):strtoupper($first);
        return $first.$rest.'?';
    }

    public static function exactTopicIdentityText(string $value): string {
        $value=trim(html_entity_decode(wp_strip_all_tags($value),ENT_QUOTES|ENT_HTML5,'UTF-8'));
        $value=strtr($value,['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss','–'=>' ','—'=>' ','-'=>' ']);
        $value=function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);
        $value=preg_replace('/[^a-z0-9\s]+/u',' ',$value)??'';
        return trim((string)preg_replace('/\s+/u',' ',$value));
    }

    public static function globalTopicIdentityText(string $value): string {
        // Backward-compatible alias. Since 0.7.0 this is exact/deterministic only; synonyms never define the technical ID.
        return self::exactTopicIdentityText($value);
    }

    public static function semanticFingerprint(string $value): string { return self::text($value); }

    public static function hasCommercialModifier(string $value): bool {
        return (bool)preg_match('/\b(sale|angebot|angebote|rabatt|gutschein|coupon|guenstig|günstig|billig|kaufen|shop|preis|preise|kosten|testsieger|testbericht)\b/iu', $value);
    }

    public static function suggestReassignmentType(string $value, string $currentType = ''): string {
        $raw=trim($value);
        if(self::isQuestion($raw))$target='FAQ';
        else{
            $signals=PSTE_Article_Type_Intent_Ontology::strongSignals($raw);
            $target=count($signals)===1?(string)$signals[0]:'';
        }
        if($target===$currentType)return '';
        return $target;
    }

    public static function hasRecommendationOrSuperlative(string $value): bool {
        return (bool)preg_match('/\b(beste|bester|bestes|besten|am\s+besten|testsieger|test-sieger|empfehlung|empfehlungen|kaufempfehlung|kaufempfehlungen|top-?empfehlung|welche\s+variante\s+ist\s+am\s+besten)\b/iu', trim($value));
    }

    public static function staleYear(string $value, ?int $referenceYear = null): ?int {
        $referenceYear = $referenceYear ?? (int)gmdate('Y');
        if (!preg_match_all('/\b(19\d{2}|20\d{2})\b/u', $value, $m)) { return null; }
        foreach ($m[1] as $year) {
            $year = (int)$year;
            if ($year < $referenceYear - 2) { return $year; }
        }
        return null;
    }

    public static function intentTuple(string $query, string $categoryName, string $answerPromise = ''): array {
        $entity = self::categoryHead($categoryName);
        $queryNorm = self::text($query);
        $tokens = self::tokens($query);
        $vocabulary=['achten','auswahl','vergleich','pflege','lagerung','installation','anwendung','uebung','problem','eignung','kontroll','sicherheit','passform','kosten'];
        if(function_exists('apply_filters'))$vocabulary=(array)apply_filters('pste_intent_goal_vocabulary',$vocabulary,$query,$categoryName);
        $goals = array_values(array_intersect($tokens,array_values(array_unique(array_map('strval',$vocabulary)))));
        $goal = $goals ? implode('-', array_unique($goals)) : 'information';
        $contextTokens = array_values(array_diff($tokens, self::tokens($entity), $goals));
        return [
            'entity' => $entity,
            'user_goal' => $goal,
            'decision_or_problem' => implode(' ', $contextTokens),
            'context' => implode(' ', $contextTokens),
            'answer_promise' => self::text($answerPromise !== '' ? $answerPromise : $queryNorm),
        ];
    }

    public static function clusterId(array $tuple): string {
        $basis = implode('|', [$tuple['entity'] ?? '', $tuple['user_goal'] ?? '', $tuple['decision_or_problem'] ?? '', $tuple['context'] ?? '', $tuple['answer_promise'] ?? '']);
        return 'intent:' . substr(hash('sha256', $basis), 0, 24);
    }

    public static function answerEquivalent(string $a, string $b, string $categoryA = '', string $categoryB = ''): bool {
        $ta = self::intentTuple($a, $categoryA ?: $categoryB);
        $tb = self::intentTuple($b, $categoryB ?: $categoryA);
        if ($ta['entity'] !== '' && $tb['entity'] !== '' && $ta['entity'] !== $tb['entity']) { return false; }
        if ($ta['user_goal'] === $tb['user_goal'] && $ta['user_goal'] !== 'information') {
            $contextA=(string)$ta['context'];$contextB=(string)$tb['context'];
            if($contextA==='' && $contextB==='')return true;
            if($contextA!=='' && $contextB!=='' && self::similarity($contextA,$contextB)>=0.55)return true;
        }
        return self::similarity($a, $b) >= 0.78;
    }
}
