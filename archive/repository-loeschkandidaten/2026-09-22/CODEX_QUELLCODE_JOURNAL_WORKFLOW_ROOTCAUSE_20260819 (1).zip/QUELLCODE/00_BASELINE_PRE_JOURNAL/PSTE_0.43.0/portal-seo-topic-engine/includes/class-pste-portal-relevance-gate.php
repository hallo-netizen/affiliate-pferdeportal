<?php
if (!defined('ABSPATH')) { return; }

/**
 * Independent read-only portal relevance gate for the normal metadata path.
 * A family match proves only "what family this resembles", never "this is about this portal".
 * Ambiguous audience/context shifts are sent to Sandbox external review rather than guessed.
 */
final class PSTE_Portal_Relevance_Gate {
    public const CONTRACT='PSTE_PORTAL_RELEVANCE_GATE_V1';


    /**
     * First decision owner for a raw keyword. Family resolution here is evidence-only:
     * it is never returned as an assignment authority and is re-run after relevance PASS.
     * @return array<string,mixed>
     */
    public static function evaluateBeforeAssignment(string $raw,array $baseline,array $registry,string $preferredFamilyKey='',array $proof=[]): array {
        $raw=self::clean($raw);$hintKey='';$hintName='';$hintMembership=[];$hintResolution=[];
        $probe=PSTE_Editorial_Topic_Normalizer::semanticProbe($raw);
        if($preferredFamilyKey!==''&&isset($registry['families'][$preferredFamilyKey])){
            $hintMembership=PSTE_Family_Membership::evaluate($probe!==''?$probe:$raw,$registry,$preferredFamilyKey);
            if(!empty($hintMembership['ok'])){$hintKey=$preferredFamilyKey;$hintName=(string)($registry['families'][$hintKey]['topic_family_name']??'');$hintResolution=['status'=>'MATCH','source'=>'RELEVANCE_EVIDENCE_PREFERRED_FAMILY','winner'=>['family_key'=>$hintKey,'topic_family_name'=>$hintName]];}
        }
        if($hintKey===''){
            $hintResolution=PSTE_Family_Identity_V2::resolve($probe!==''?$probe:$raw,$registry);
            if(($hintResolution['status']??'')==='MATCH'&&is_array($hintResolution['winner']??null)){
                $candidateKey=(string)($hintResolution['winner']['family_key']??'');$candidateFamily=(array)($registry['families'][$candidateKey]??[]);
                if($candidateKey!==''&&$candidateFamily){$m=PSTE_Family_Membership::evaluate($probe!==''?$probe:$raw,$registry,$candidateKey);if(!empty($m['ok'])){$hintKey=$candidateKey;$hintName=(string)($candidateFamily['topic_family_name']??'');$hintMembership=$m;}}
            }
        }
        $result=self::evaluate($raw,$hintName,$baseline,$proof);
        $result['decision_order']='PORTAL_RELEVANCE_FIRST';
        $result['family_hint']=['evidence_only'=>true,'family_key'=>$hintKey,'family_name'=>$hintName,'resolution'=>$hintResolution,'membership'=>$hintMembership,'assignment_authority'=>false];
        return $result;
    }
    /** @return array<string,mixed> */
    public static function evaluate(string $raw,string $family,array $baseline,array $proof=[]): array {
        $raw=self::clean($raw);$family=self::clean($family);$sha=$raw!==''?hash('sha256',$raw):'';
        $base=['contract'=>self::CONTRACT,'ok'=>false,'status'=>'EXTERNAL_REVIEW_REQUIRED','raw_query_sha256'=>$sha,'family'=>$family,'source'=>'UNPROVEN','reason_codes'=>[],'context_evidence'=>[],'proof_used'=>false,'write_attempted'=>false];
        if($raw===''){$base['status']='BLOCKED';$base['reason_codes']=['PSTE_PORTAL_RELEVANCE_INPUT_MISSING'];return $base;}

        $proofCheck=self::verifyProof($proof,$raw,$family);
        if(($proofCheck['status']??'')==='PASS'){
            $base['ok']=true;$base['status']='PASS';$base['source']='BOUND_RELEVANCE_PROOF';$base['proof_used']=true;$base['reason_codes']=['PSTE_PORTAL_RELEVANCE_BOUND_PROOF_PASS'];return $base;
        }
        if(($proofCheck['status']??'')==='INVALID'){
            $base['status']='BLOCKED';$base['source']='INVALID_BOUND_PROOF';$base['reason_codes']=(array)$proofCheck['reason_codes'];return $base;
        }

        $context=PSTE_Category_Context::portalContextEvidence($raw,$baseline);$base['context_evidence']=$context;
        if(!empty($context['portal_context_present'])){
            $base['ok']=true;$base['status']='PASS';$base['source']='CURRENT_PORTAL_CONTEXT';$base['reason_codes']=['PSTE_PORTAL_RELEVANCE_CURRENT_CONTEXT_PASS'];return $base;
        }

        if($family===''){$base['reason_codes']=['PSTE_PORTAL_RELEVANCE_FAMILY_EVIDENCE_REQUIRED'];return $base;}

        $split=self::splitAroundFamily($raw,$family);
        if(empty($split['matched'])){$base['reason_codes']=['PSTE_PORTAL_RELEVANCE_FAMILY_SURFACE_NOT_LOCATABLE'];return $base;}
        $before=self::stripNonTopicIntent((string)$split['before']);$after=self::stripNonTopicIntent((string)$split['after']);
        if($before===''&&$after===''){
            $base['ok']=true;$base['status']='PASS';$base['source']='FAMILY_ONLY_OR_EDITORIAL_INTENT';$base['reason_codes']=['PSTE_PORTAL_RELEVANCE_NO_TOPIC_SHIFT_RESIDUAL'];return $base;
        }
        if(PSTE_Normalizer::isQuestion($raw)&&!preg_match('/\bf(?:ü|ue)r\s+[^?]+/iu',$raw)){
            $base['ok']=true;$base['status']='PASS';$base['source']='QUESTION_WITHOUT_AUDIENCE_SHIFT';$base['reason_codes']=['PSTE_PORTAL_RELEVANCE_QUESTION_NO_AUDIENCE_SHIFT'];return $base;
        }

        // Property/material relations are not audience shifts. Keep these on the local path.
        if($before===''&&preg_match('/^(mit|ohne|aus|gegen)\s+\S+/iu',$after)){
            $base['ok']=true;$base['status']='PASS';$base['source']='NON_AUDIENCE_PROPERTY_RELATION';$base['reason_codes']=['PSTE_PORTAL_RELEVANCE_PROPERTY_RELATION_PASS'];return $base;
        }

        // A "für X" relation or an unbound pre/post-family residual can change the target audience/domain.
        // Never guess; preserve the keyword and ask Sandbox for independent relevance evidence.
        $base['source']='AMBIGUOUS_CONTEXT_SHIFT';
        $base['reason_codes']=['PSTE_PORTAL_RELEVANCE_EXTERNAL_EVIDENCE_REQUIRED'];
        return $base;
    }

    /** @return array<string,mixed> */
    public static function proofFromExternal(array $external,string $raw,string $family=''): array {
        $raw=self::clean($raw);$family=self::clean($family);
        return ['contract'=>'PSTE_PORTAL_RELEVANCE_PROOF_V1','status'=>(string)($external['status']??''),'raw_query'=>$raw,'raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'','family_name'=>$family,'evidence_contract'=>(string)($external['contract']??''),'evidence_sha256'=>self::stableHash($external),'decision_source'=>(string)($external['decision_source']??$external['source']??'SANDBOX_EXTERNAL_OR_REVIEW'),'write_attempted'=>false];
    }

    /** @return array<string,mixed> */
    private static function verifyProof(array $proof,string $raw,string $family): array {
        if(!$proof)return ['status'=>'NONE','reason_codes'=>[]];
        if(($proof['contract']??'')!=='PSTE_PORTAL_RELEVANCE_PROOF_V1')return ['status'=>'INVALID','reason_codes'=>['PSTE_PORTAL_RELEVANCE_PROOF_CONTRACT_INVALID']];
        if(($proof['status']??'')!=='RELEVANT_FOR_PORTAL')return ['status'=>'INVALID','reason_codes'=>['PSTE_PORTAL_RELEVANCE_PROOF_NOT_POSITIVE']];
        $sha=(string)($proof['raw_query_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$sha)||!hash_equals(hash('sha256',$raw),$sha))return ['status'=>'INVALID','reason_codes'=>['PSTE_PORTAL_RELEVANCE_PROOF_RAW_MISMATCH']];
        $boundFamily=self::clean((string)($proof['family_name']??''));if($boundFamily!==''&&$family==='')return ['status'=>'INVALID','reason_codes'=>['PSTE_PORTAL_RELEVANCE_PROOF_FAMILY_HINT_MISSING']];if($boundFamily!==''&&!PSTE_Token_Equivalence::contains($family,$boundFamily)&&!PSTE_Token_Equivalence::contains($boundFamily,$family))return ['status'=>'INVALID','reason_codes'=>['PSTE_PORTAL_RELEVANCE_PROOF_FAMILY_MISMATCH']];
        return ['status'=>'PASS','reason_codes'=>[]];
    }

    /** @return array{matched:bool,before:string,after:string} */
    private static function splitAroundFamily(string $raw,string $family): array {
        $words=preg_split('/\s+/u',self::clean($raw))?:[];$familyTokens=array_fill_keys(PSTE_Token_Equivalence::tokens(str_replace('-',' ',$family)),true);$hits=[];
        foreach($words as $i=>$word){foreach(PSTE_Token_Equivalence::tokens(trim($word,".,!?;:()[]{}\"'")) as $token)if(isset($familyTokens[$token])){$hits[]=$i;break;}}
        if(!$hits)return ['matched'=>false,'before'=>'','after'=>''];$first=min($hits);$last=max($hits);
        return ['matched'=>true,'before'=>self::clean(implode(' ',array_slice($words,0,$first))),'after'=>self::clean(implode(' ',array_slice($words,$last+1)))];
    }
    private static function stripNonTopicIntent(string $v): string {
        $v=self::clean($v);if($v==='')return '';
        $patterns=[
            '/\b(test|tests|testbericht|vergleich|vergleichen|kaufberatung|beratung|ratgeber|auswahl|auswählen|auswaehlen|wählen|waehlen|empfehlung|empfehlungen)\b/iu',
            '/\b(preis|preise|kosten|kostet|budget|günstig\w*|guenstig\w*|preiswert\w*|billig\w*)\b/iu',
            '/\b(imprägnieren|impraegnieren|reparieren|reinigen|reinigung|waschen|trocknen|pflegen|pflege|warten|wartung)\b/iu',
            '/\b(installieren|installation|montieren|montage|aufbauen|anschließen|anschliessen|einbauen|befestigen|anbringen|einrichten)\b/iu',
            '/\b(anwenden|anwendung|benutzen|verwenden|einsetzen|dosieren|anlegen|lagern|lagerung|aufbewahren|aufbewahrung|verstauen|übung|übungen|uebung|uebungen)\b/iu',
            '/\b(sicherheit|sicher|unsicher|gefahr|gefahren|gefährlich|gefaehrlich|risiko|risiken|unfall|schutz)\b/iu',
            '/\b(sale|angebot|angebote|rabatt|gutschein|coupon|shop|bestellen|online|kaufen)\b/iu',
            '/\b(20\d{2})\b/u'
        ];
        foreach($patterns as $p)$v=(string)(preg_replace($p,' ',$v)??$v);
        $v=(string)(preg_replace('/\b(wie|was|wann|warum|wieso|weshalb|welche|welcher|welches|kann|können|koennen|darf|soll|ist|sind|gibt|braucht|eine|ein|einer|einem|einen|der|die|das)\b/iu',' ',$v)??$v);
        $v=self::clean(trim($v," ?!.,;:"));
        $v=(string)(preg_replace('/^(mit|für|fuer|ohne|gegen|bei|von|aus|im|in|auf|unter|über|ueber|zum|zur)\s*$/iu','',$v)??$v);
        return self::clean($v);
    }
    private static function stableHash($v): string {$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return hash('sha256',(string)$j);}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');return trim((string)preg_replace('/\s+/u',' ',$v));}
}
