<?php
if (!defined('ABSPATH')) { return; }

/** Durable, read-only-to-production health record for the Sandbox/backlog maintenance loop. */
final class PSTE_Sandbox_Maintenance_Health {
    public const CONTRACT='PSTE_SANDBOX_MAINTENANCE_HEALTH_V2';

    /** @return array<string,mixed> */
    public static function snapshot(): array {
        $stored=get_option(PSTE_OPTION_SANDBOX_MAINTENANCE_HEALTH,[]);if(!is_array($stored))$stored=[];
        $next=function_exists('wp_next_scheduled')?wp_next_scheduled(PSTE_SANDBOX_INTERNAL_RECHECK_CRON_HOOK):false;
        $lastSuccess=(string)($stored['last_success_at_utc']??'');$successTs=$lastSuccess!==''?strtotime($lastSuccess):false;
        $scheduleStatus=$next?'SCHEDULED':'MISSING';$lastStatus=(string)($stored['last_status']??'');$historicalError=(string)($stored['last_error_code']??'');
        $engineReady=null;if(class_exists('PSTE_Plugin')&&method_exists('PSTE_Plugin','isReady')){try{$engineReady=PSTE_Plugin::isReady();}catch(Throwable $e){$engineReady=false;}}
        $runHealth='UNKNOWN';$currentError=$historicalError;$healthReason='NO_CURRENT_RUN_EVIDENCE';
        if($engineReady===true&&$lastStatus==='FAIL'&&$historicalError==='PSTE_SANDBOX_MAINTENANCE_ENGINE_NOT_READY'){
            // Keep the historical failure as evidence, but it no longer describes current health after READY.
            $runHealth='PENDING_AFTER_READY';$currentError='';$healthReason='HISTORICAL_PRE_READY_FAILURE_RETAINED_NOT_CURRENT';
        }elseif($lastStatus==='FAIL'){$runHealth='FAIL';$healthReason='LATEST_RUN_FAILED';}
        elseif($successTs!==false&&time()-$successTs<=2*DAY_IN_SECONDS){$runHealth='PASS';$currentError='';$healthReason='RECENT_SUCCESS';}
        elseif($successTs!==false){$runHealth='OVERDUE';$currentError='';$healthReason='LAST_SUCCESS_OVERDUE';}
        elseif((string)($stored['last_attempt_at_utc']??'')!==''){$runHealth=$lastStatus==='RUNNING'?'RUNNING':'FAIL';$healthReason='ATTEMPT_WITHOUT_SUCCESS';}
        return [
            'contract'=>self::CONTRACT,'schedule_status'=>$scheduleStatus,'next_scheduled_utc'=>$next?gmdate('c',(int)$next):'',
            'run_health'=>$runHealth,'current_health_reason'=>$healthReason,'engine_ready'=>$engineReady,
            'last_attempt_at_utc'=>(string)($stored['last_attempt_at_utc']??''),'last_success_at_utc'=>$lastSuccess,'last_status'=>$lastStatus,
            'current_error_code'=>$currentError,'historical_last_error_code'=>$historicalError,'last_error_code'=>$historicalError,
            'last_report'=>(array)($stored['last_report']??[]),'consecutive_failures'=>(int)($stored['consecutive_failures']??0),
            'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,
        ];
    }

    public static function recordAttempt(string $trigger): void {self::write(['last_attempt_at_utc'=>gmdate('c'),'last_trigger'=>self::safe($trigger),'last_status'=>'RUNNING','last_error_code'=>'']);}
    public static function recordSuccess(string $trigger,array $report): void {self::write(['last_attempt_at_utc'=>(string)(self::current()['last_attempt_at_utc']??gmdate('c')),'last_success_at_utc'=>gmdate('c'),'last_trigger'=>self::safe($trigger),'last_status'=>'PASS','last_error_code'=>'','last_report'=>$report,'consecutive_failures'=>0]);}
    public static function recordFailure(string $trigger,string $code,array $report=[]): void {$cur=self::current();self::write(['last_attempt_at_utc'=>(string)($cur['last_attempt_at_utc']??gmdate('c')),'last_trigger'=>self::safe($trigger),'last_status'=>'FAIL','last_error_code'=>self::safe($code),'last_report'=>$report,'consecutive_failures'=>(int)($cur['consecutive_failures']??0)+1]);}
    public static function recordScheduleState(bool $scheduled,string $trigger): void {self::write(['schedule_last_checked_at_utc'=>gmdate('c'),'schedule_last_trigger'=>self::safe($trigger),'schedule_last_status'=>$scheduled?'SCHEDULED':'MISSING']);}

    /** @return array<string,mixed> */
    private static function current(): array {$v=get_option(PSTE_OPTION_SANDBOX_MAINTENANCE_HEALTH,[]);return is_array($v)?$v:[];}
    /** @param array<string,mixed> $patch */
    private static function write(array $patch): void {
        $v=array_merge(self::current(),$patch,['contract'=>self::CONTRACT,'updated_at_utc'=>gmdate('c'),'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false]);
        update_option(PSTE_OPTION_SANDBOX_MAINTENANCE_HEALTH,$v,false);$stored=get_option(PSTE_OPTION_SANDBOX_MAINTENANCE_HEALTH,[]);
        if(!is_array($stored)||($stored['contract']??'')!==self::CONTRACT||(string)($stored['last_status']??'')!==(string)$v['last_status'])throw new RuntimeException('PSTE_SANDBOX_MAINTENANCE_HEALTH_NOT_PERSISTED');
    }
    private static function safe(string $v): string {$v=strtoupper(trim($v));$v=(string)preg_replace('/[^A-Z0-9_:\-]+/','_',$v);return substr($v!==''?$v:'UNKNOWN',0,160);}
}
