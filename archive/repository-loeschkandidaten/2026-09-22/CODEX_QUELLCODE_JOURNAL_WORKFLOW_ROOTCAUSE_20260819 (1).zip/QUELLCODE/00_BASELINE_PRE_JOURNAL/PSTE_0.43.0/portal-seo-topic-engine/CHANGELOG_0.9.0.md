# Portal SEO Themenengine 0.9.0-staging

- Ersetzt die unvollständige einzelne Google-Live-Abfrage durch eine vollständige, kostenbestätigte read-only Artikeltest-SERP-Evidenz.
- Prüft Kandidat, aktuelle Bestandsbeiträge derselben Themenfamilie, weitere freigegebene Themen derselben Familie und den Kategorieoberbegriff.
- Ruft Google-Top-10 und Suchintent frisch ab, bindet Plan, Datenquelle, Baseline, Vergleichsinventur und Providerkonfiguration per SHA-256.
- Erzeugt keine Artikel und startet keine Produktion.
- Bestehende Pluginmigration, Themenlogik, Oberfläche und Portalgrenzen bleiben unverändert.
