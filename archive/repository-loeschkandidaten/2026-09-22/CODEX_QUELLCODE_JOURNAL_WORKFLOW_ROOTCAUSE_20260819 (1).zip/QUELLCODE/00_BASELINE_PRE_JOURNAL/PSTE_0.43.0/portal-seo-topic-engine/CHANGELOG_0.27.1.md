# 0.27.1 – Safe product-page display-name drift

- Reine sichtbare Umbenennungen geschützter Produktseiten dürfen eine bestehende SEO-/Redaktionsplan-Identität nicht in eine neue Kategorie/Themenfamilie verwandeln.
- `baselineStatus()` akzeptiert eine Abweichung nur dann als `CURRENT`, wenn vollständig bewiesen ist, dass ausschließlich der sichtbare Titel der Produktseite geändert wurde.
- IDs, Slugs, Elternketten, Leaf-Namen, Artikeltypen, kanonische Themenfamilien, Protected Map, Quarantäne-/Ignored-Bestand, Editorial-Plan und alle nicht abgeleiteten Post-/Content-/Meta-Felder müssen unverändert sein.
- Der alte kanonische Themenfamilienname bleibt absichtlich stabil; der neue Seitentitel ist reine Darstellung.
- Keine automatische Baseline-Neuschreibung, kein Kontext-Refresh, kein Sandbox-Rebind, keine Textproduktion.
- Echte Struktur-, Inhalts-, Plan-, Slug-, ID-, Parent-, Leaf-Namens- oder dynamische Familienänderungen bleiben `STALE`/fail-closed.
