# Portal SEO Themenengine 0.12.0 — Semantic Review Sandbox

## Ziel

Gebündelte, vollständig nicht-anwendende Review-Strecke für `NEWLY_BLOCKED`-Longtails. Wertvolle Grenzfälle bleiben dauerhaft erhalten und können mit realer SEO-Evidenz fachlich geprüft werden, ohne den FINAL-PASS-V2-Matcher oder irgendeinen Produktions-/Artikelpfad zu verändern.

## Hauptregel 1

Unverändert und übergeordnet: keine Änderung an Artikelinhalt, HTML, CSS, Design, bestehenden Beiträgen/Entwürfen, Postmeta/Terms, PPM/Textmaschine, Compiler oder den geschützten Titel-/Matcher-Komponenten. Die Sandbox besitzt keinen Apply- und keinen Produktions-Handoff.

## Workflow

1. V2-Hauptgate bleibt unverändert streng.
2. Alle `NEWLY_BLOCKED`-Datensätze werden verlustfrei im eigenen Sandbox-Register erhalten.
3. Externe SEO-Prüfung erhalten nur die von Claude bestätigten Eintrittsfälle: mindestens eine echte nächstplausible Familie, Kontextfehler, kein aktiver Ausschlusstreffer, unveränderter Quelldatensatz.
4. Externe Relevanz nutzt reale DataForSEO-Google-Organic-Live-SERPs nur in `Production` und ausschließlich in der Sandbox.
5. Positive Portalrelevanz wird nur bei belastbarer, registry-abgeleiteter Evidenz festgestellt. Fehlende positive SERP-Signale führen konservativ zu `UNCERTAIN_REVIEW`, niemals automatisch zum Verlust des Keywords.
6. Nach bestätigter externer Relevanz bestimmen die bestehenden unabhängigen Semantik-Stränge A und B in der bereits plausiblen Familie Artikeltyp und exakte vorhandene Zielkategorie neu. Alte Artikeltypzuordnungen sind dabei nicht maßgeblich.
7. Die unveränderte bestehende Titelpipeline wird nur als schreibfreie, nicht finale Titelprobe ausgeführt.
8. Es wird kein 5-Felder-Handoff erzeugt. Eine spätere Rückführung muss ausdrücklich freigegeben werden und erneut den normalen Pfad Familie → Kategorie → Artikeltyp → Planplatz → Kannibalisierung → 5-Felder-Handoff durchlaufen.

## Verlustschutz

- Kein Sandbox-Datensatz wird bei späteren Synchronisierungen gelöscht.
- Nicht eingelassene Fälle bleiben als `RETAINED_PRIMARY_BLOCKED` erhalten.
- Später nicht mehr im aktuellen Blocked-Set vorhandene Fälle bleiben als `RETAINED_HISTORICAL_NOT_IN_CURRENT_BLOCKED_SET` erhalten.
- Original-Longtail, Suchvolumen/Quellen soweit vorhanden, Diagnose, Binding und Historie bleiben gespeichert.
- Registry-/Familien-/Dry-run-Bindingänderungen invalidieren frühere Review-Ergebnisse und erzwingen erneute Prüfung.

## Provider/Kosten

- Neuer erlaubter Endpoint ausschließlich für die Sandbox: `POST /v3/serp/google/organic/live/advanced`.
- Ein SERP-Task je offenem zugelassenem Sandbox-Kandidaten, Tiefe 10.
- Konservative Kostenreservierung mit 0,010 USD je Task; tatsächliche Providerkosten werden aus der Antwort übernommen, Cachetreffer zählen mit 0 USD Zusatzkosten.
- Bestehende Run-/Tages-/Monatsbudgets und Budgetreservierungen bleiben wirksam.

## Nicht enthalten

- Kein Sandbox-Apply.
- Keine automatische Freigabe in den Redaktionsplan.
- Keine Textproduktion.
- Keine Änderung der V2-Familienentscheidung.
- Keine Änderung der bestehenden Titelpipeline.
- Keine Bearbeitung des beobachteten langsamen ersten Backend-Aufrufs; dies bleibt bewusst außerhalb dieses Funktionsumfangs.
