<?php
if (!defined('ABSPATH')) { return; }

/** Read-only topic/title safety gate. It never creates article content. */
final class PSTE_Domain_Risk_Gate {
    /** @return array<string,mixed> */
    public static function evaluate(string $query,string $articleType): array {
        $q=trim($query);$reasons=[];$status='RISK_NONE';
        $emergency=(bool)preg_match('/\b(notfall|akut\w*|kolik|vergiftung|giftpflanze\w*|atemnot|starke\s+blutung|schock)\b/iu',$q);
        $dose=(bool)preg_match('/\b(dosier\w*|dosis|milligramm|mg\b|medikament\w*|wurmkur\w*|impf\w*)\b/iu',$q);
        $selfTreatment=(bool)preg_match('/\b(selbst\s+behandeln|selber\s+behandeln|ohne\s+tierarzt|hausmittel\s+statt|medikament\w*\s+geben)\b/iu',$q);
        if($selfTreatment){$status='RISK_TOPIC_BLOCKED';$reasons[]='RISK_SELF_TREATMENT_INSTRUCTION';}
        elseif($dose){$status='RISK_TITLE_BLOCKED';$reasons[]='RISK_MEDICATION_OR_DOSAGE';}
        elseif($emergency){$status='RISK_REVIEW_REQUIRED';$reasons[]='RISK_ACUTE_OR_EMERGENCY_TOPIC';}
        elseif(preg_match('/\b(diagnos\w*|symptom\w*|verletzung\w*|krankheit\w*)\b/iu',$q)){$status='RISK_INFORMATIONAL_CONTROLLED';$reasons[]='RISK_HEALTH_INFORMATIONAL';}
        if($status!=='RISK_NONE'&&PSTE_Article_Type_Registry::canonicalType($articleType)!=='faq')$reasons[]='RISK_NON_FAQ_TYPE_REVIEW';
        return ['contract'=>'PSTE_DOMAIN_RISK_GATE_V1','status'=>$status,'ok'=>in_array($status,['RISK_NONE','RISK_INFORMATIONAL_CONTROLLED'],true),'reason_codes'=>array_values(array_unique($reasons)),'write_attempted'=>false];
    }
}
