<?php
if (!defined('ABSPATH')) { return; }

/** Stable read-only compatibility contract for the editorial-plan compiler. */
final class PSTE_Compiler_Read_Capability {
    public const CONTRACT='PSTE_COMPILER_READ_CAPABILITY_V1';
    public const CAPABILITY_VERSION='1.4.0';
    public const TOPIC_METADATA_SCHEMA='PSTE_COMPILER_TOPIC_METADATA_V4_INTENT_TITLE_KEYWORD_BOUND';

    /** @return array<string,mixed> */
    public static function describe(): array {
        $required=[
            'PSTE_Plugin::isReady','PSTE_Repository::allCandidates','PSTE_Analytics::priorities',
            'PSTE_Editorializer::RULESET','PSTE_Editorial_Quality_Gate::CONTRACT','PSTE_Intent_Profile::CONTRACT','PSTE_Intent_Profile::targetKeyword',
        ];
        $out=[
            'contract'=>self::CONTRACT,'capability_version'=>self::CAPABILITY_VERSION,
            'topic_metadata_schema'=>self::TOPIC_METADATA_SCHEMA,
            'engine_schema'=>(string)(defined('PSTE_SCHEMA_VERSION')?PSTE_SCHEMA_VERSION:12),
            'editorial_ruleset'=>(string)PSTE_Editorializer::RULESET,
            'editorial_quality_contract'=>(string)PSTE_Editorial_Quality_Gate::CONTRACT,
            'intent_profile_contract'=>(string)PSTE_Intent_Profile::CONTRACT,
            'target_keyword_contract'=>'PSTE_TARGET_KEYWORD_V1_INTENT_BOUND_PPM_TITLE_COMPATIBLE',
            'intent_first'=>true,
            'intent_metadata_internal_only'=>true,
            'required_read_symbols'=>$required,
            'handoff_fields'=>['title','target_keyword','category','article_type','plan_slot'],
            'content_or_design_payload_allowed'=>false,'write_capability_exposed'=>false,
        ];
        $out['capability_sha256']=self::hash($out);
        return $out;
    }

    public static function validateRuntime(): array {
        $missing=[];
        foreach(['PSTE_Plugin'=>['isReady'],'PSTE_Repository'=>['allCandidates'],'PSTE_Analytics'=>['priorities']] as $class=>$methods){
            if(!class_exists($class)){$missing[]=$class;continue;}foreach($methods as $m)if(!method_exists($class,$m))$missing[]=$class.'::'.$m;
        }
        foreach(['PSTE_Editorializer','PSTE_Editorial_Quality_Gate','PSTE_Intent_Profile'] as $class)if(!class_exists($class))$missing[]=$class;
        if(class_exists('PSTE_Editorializer')&&!defined('PSTE_Editorializer::RULESET'))$missing[]='PSTE_Editorializer::RULESET';
        if(class_exists('PSTE_Editorial_Quality_Gate')&&!defined('PSTE_Editorial_Quality_Gate::CONTRACT'))$missing[]='PSTE_Editorial_Quality_Gate::CONTRACT';
        if(class_exists('PSTE_Intent_Profile')&&!defined('PSTE_Intent_Profile::CONTRACT'))$missing[]='PSTE_Intent_Profile::CONTRACT';
        if(class_exists('PSTE_Intent_Profile')&&!method_exists('PSTE_Intent_Profile','targetKeyword'))$missing[]='PSTE_Intent_Profile::targetKeyword';
        if($missing)return ['ok'=>false,'status'=>'PSTE_COMPILER_READ_CAPABILITY_BLOCKED','reason_codes'=>['PSTE_COMPILER_READ_SYMBOL_MISSING'],'missing'=>array_values(array_unique($missing)),'capability'=>[],'write_attempted'=>false];
        try{$d=self::describe();}catch(Throwable $e){return ['ok'=>false,'status'=>'PSTE_COMPILER_READ_CAPABILITY_BLOCKED','reason_codes'=>['PSTE_COMPILER_READ_CAPABILITY_DESCRIBE_FAILED'],'missing'=>[],'capability'=>[],'error_code'=>self::safeCode($e->getMessage()),'write_attempted'=>false];}
        return ['ok'=>true,'status'=>'PSTE_COMPILER_READ_CAPABILITY_PASS','capability'=>$d,'write_attempted'=>false];
    }

    private static function safeCode(string $v): string {$v=strtoupper(trim($v));$v=(string)preg_replace('/[^A-Z0-9_:\-]+/','_',$v);return substr($v!==''?$v:'PSTE_COMPILER_CAPABILITY_FAILED',0,160);}

    private static function hash(array $v): string {
        $copy=$v;unset($copy['capability_sha256']);$copy=self::canonicalize($copy);
        $json=function_exists('wp_json_encode')?wp_json_encode($copy,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($copy,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
        if(!is_string($json))throw new RuntimeException('PSTE_COMPILER_CAPABILITY_HASH_FAILED');return hash('sha256',$json);
    }
    private static function canonicalize($v){
        if(!is_array($v))return $v;if($v===[])return [];
        $isList=array_keys($v)===range(0,count($v)-1);if($isList)return array_map([self::class,'canonicalize'],$v);
        ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;
    }
}
