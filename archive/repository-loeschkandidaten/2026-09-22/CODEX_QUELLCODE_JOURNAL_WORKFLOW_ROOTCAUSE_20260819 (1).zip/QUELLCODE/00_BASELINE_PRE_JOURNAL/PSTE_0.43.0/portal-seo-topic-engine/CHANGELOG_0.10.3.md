# 0.10.3-staging

- Schließt den praktischen Ein-Klick-Longtail-Workflow ab: Keyword Suggestions, Related Keywords und Keyword Ideas werden begrenzt, getrennt und automatisch nacheinander verarbeitet.
- Korrigiert die Provider-Cache-Provenienz: Cache ist jetzt umgebung-, konto- und payloadgebunden; ursprünglicher Abrufzeitpunkt und Hash der unveränderten Providerantwort bleiben erhalten.
- Beschädigte oder alte Cacheeinträge werden fail-closed verworfen. Cachetreffer erzeugen keine erneute Kostenbuchung.
- Schließt das letzte Persistenzfenster: Liegt nach einem unterbrochenen Serverrequest bereits eine valide, identische Providerantwort im Cache, wird sie ohne erneute Anfrage in denselben Auftrag übernommen und korrekt verbucht.
- Entfernt keine und verändert keine Funktionen der Textmaschine. Artikelinhalt, HTML, Design, Formatierung und Qualitätslogik bleiben außerhalb des Scopes.
- Deinstallationsbereinigung auf die aktuellen, ausschließlich eigenen SEO-Optionen und transienten Arbeitsdaten synchronisiert.
