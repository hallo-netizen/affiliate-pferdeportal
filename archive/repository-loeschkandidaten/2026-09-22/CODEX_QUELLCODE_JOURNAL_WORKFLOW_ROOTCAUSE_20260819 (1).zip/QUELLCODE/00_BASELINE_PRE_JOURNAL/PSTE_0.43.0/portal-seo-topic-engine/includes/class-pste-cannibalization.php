<?php
if (!defined('ABSPATH')) { return; }

/** Portal-internal duplicate and category-head protection. No SERP comparison. */
final class PSTE_Cannibalization {
    public static function decide(array $candidate,array $inventoryItems,array $categoryItems,array $unusedCalibration=[]): array {
        $reasons=[];$decision='PASS';$matches=[];
        $query=trim((string)($candidate['editorial_title']??$candidate['primary_longtail_query']??''));
        $sourceQuery=trim((string)($candidate['primary_longtail_query']??$query));
        $categoryName=(string)($candidate['target_category_name']??'');
        $articleType=(string)($candidate['proposed_article_type']??'');
        $queryNorm=PSTE_Normalizer::exactTopicIdentityText($query);
        $headNorm=PSTE_Normalizer::exactTopicIdentityText(PSTE_Normalizer::categoryFamilyName($categoryName));
        $familyKey=(string)($candidate['topic_family_key']??PSTE_Normalizer::categoryFamilyKey($categoryName));
        $sources=array_values(array_unique(array_filter(array_map(static fn($e)=>(string)($e['source']??''),(array)($candidate['evidence']??[])))));

        if(!$sources)return ['decision'=>'BLOCKED','reason_codes'=>['SOURCE_PROVENANCE_MISSING'],'matches'=>[]];
        if($queryNorm===''||$queryNorm===$headNorm)return ['decision'=>'BLOCKED','reason_codes'=>['CATEGORY_HEAD_INTENT_COLLISION'],'matches'=>[]];
        if(PSTE_Normalizer::staleYear($sourceQuery)!==null)return ['decision'=>'BLOCKED','reason_codes'=>['STALE_YEAR_SPECIFIC_QUERY'],'matches'=>[]];
        if(self::pureTransactional($sourceQuery))return ['decision'=>'BLOCKED','reason_codes'=>['NON_EDITORIAL_TRANSACTIONAL_QUERY'],'matches'=>[]];
        if(empty($candidate['editorialization']['resolved'])){
            $reason=(string)($candidate['editorialization']['reason']??'EDITORIAL_TITLE_UNRESOLVED');
            return ['decision'=>'BLOCKED','reason_codes'=>[$reason],'matches'=>[]];
        }
        if($articleType==='FAQ'&&!PSTE_Normalizer::isQuestion($query))return ['decision'=>'BLOCKED','reason_codes'=>['FAQ_NON_QUESTION_DISCOVERY_TERM'],'matches'=>[]];
        if($articleType!=='FAQ'&&PSTE_Normalizer::isQuestion($query))return ['decision'=>'BLOCKED','reason_codes'=>['QUESTION_TITLE_NOT_FAQ'],'matches'=>[]];

        foreach($inventoryItems as $item){
            if(!in_array((string)($item['status']??''),['publish','draft'],true))continue;
            $title=trim((string)($item['title']??''));if($title==='')continue;
            $itemCategory=(string)($item['category_name']??'');
            $itemFamily=(string)($item['topic_family_key']??PSTE_Normalizer::categoryFamilyKey($itemCategory));
            $sameFamily=$familyKey!==''&&$itemFamily!==''&&hash_equals($familyKey,$itemFamily);
            $fields=[['type'=>'TITLE','text'=>$title]];
            foreach((array)($item['headings']??[]) as $heading){$heading=trim((string)$heading);if($heading!=='')$fields[]=['type'=>'HEADING','text'=>$heading];}
            $best=0.0;$bestField='TITLE';$bestText=$title;$equivalent=false;$exact=false;
            foreach($fields as $field){
                $text=(string)$field['text'];$sim=PSTE_Normalizer::similarity($query,$text);
                $isExact=PSTE_Normalizer::exactTopicIdentityText($query)===PSTE_Normalizer::exactTopicIdentityText($text);
                $isEquivalent=PSTE_Normalizer::answerEquivalent($query,$text,PSTE_Normalizer::categoryFamilyName($categoryName),PSTE_Normalizer::categoryFamilyName($itemCategory));
                if($sim>$best){$best=$sim;$bestField=(string)$field['type'];$bestText=$text;}
                $exact=$exact||$isExact;$equivalent=$equivalent||$isEquivalent;
            }
            if($exact){$reasons[]='EXACT_NORMALIZED_QUERY_DUPLICATE';$decision='BLOCKED';}
            if($equivalent){$reasons[]='CROSS_TYPE_ANSWER_EQUIVALENCE';$decision='BLOCKED';}
            if(($candidate['intent_cluster_id']??'')!==''&&hash_equals((string)$candidate['intent_cluster_id'],(string)($item['intent_cluster_id']??''))){$reasons[]='SAME_INTENT_CLUSTER';$decision='BLOCKED';}
            if($best>=0.40||$equivalent||$sameFamily){
                $matches[]=[
                    'post_id'=>(int)($item['post_id']??0),'title'=>$title,'category_name'=>$itemCategory,
                    'matched_field'=>$bestField,'matched_text'=>$bestText,'intent_similarity'=>$best,
                    'answer_equivalence'=>$equivalent,'same_topic_family'=>$sameFamily,
                    'context_only'=>$sameFamily&&!$equivalent&&$best<0.40,'source'=>(string)($item['source']??'WORDPRESS'),
                ];
            }
        }
        usort($matches,static fn($a,$b)=>[(int)$b['answer_equivalence'],(float)$b['intent_similarity']]<=>[(int)$a['answer_equivalence'],(float)$a['intent_similarity']]);
        $matches=array_slice($matches,0,8);

        foreach($categoryItems as $category){
            if((int)($category['term_id']??0)===(int)($candidate['target_category_id']??0))continue;
            $otherHead=PSTE_Normalizer::exactTopicIdentityText((string)($category['topic_family_name']??$category['name']??''));
            if($otherHead!==''&&$queryNorm===$otherHead){$reasons[]='CATEGORY_HEAD_INTENT_COLLISION';$decision='BLOCKED';}
        }
        if(($candidate['metrics']['search_volume']??null)===0)$reasons[]='ZERO_REPORTED_SEARCH_VOLUME_NOT_AUTOMATICALLY_REJECTED';
        if(!$matches&&$decision==='PASS')$reasons[]='PORTAL_INTERNAL_TOPIC_FREE';
        elseif($matches&&$decision==='PASS')$reasons[]='PORTAL_INTERNAL_FAMILY_CONTEXT_CHECKED';
        return ['decision'=>$decision,'reason_codes'=>array_values(array_unique($reasons)),'matches'=>$matches];
    }

    private static function pureTransactional(string $query): bool {
        $transactional=(bool)preg_match('/\b(sale|angebot|angebote|rabatt|gutschein|coupon|shop|online\s+kaufen|bestellen)\b/iu',$query);
        $informational=(bool)preg_match('/\b(preis|preise|kosten|vergleich|test|pflege|reinigen|waschen|ratgeber)\b/iu',$query);
        return $transactional&&!$informational;
    }
}
