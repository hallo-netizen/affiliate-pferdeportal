<?php
if (!defined('ABSPATH')) { return; }

final class PSTE_Context_Refresh {
    private const LOCK='pste_context_refresh_lock_v1';
    private const CONTRACT='PSTE_CONTEXT_REFRESH_JOB_V3';
    private const LEGACY_CONTRACTS=['PSTE_CONTEXT_REFRESH_JOB_V2','PSTE_CONTEXT_REFRESH_JOB_V1'];
    private const SANDBOX_BATCH_SIZE=5;

    public static function start(array $baseline,string $reason='MANUAL'): array {
        PSTE_Plugin::assertReady();
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1'){
            throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        }

        $total=PSTE_Repository::topicPoolCount();
        $sandboxIds=PSTE_Semantic_Review_Sandbox::bindingRefreshRecordIds();
        $sandboxTotal=count($sandboxIds);
        $hasWork=$total>0||$sandboxTotal>0;
        $job=[
            'contract'=>self::CONTRACT,
            'status'=>$hasWork?'PENDING':'COMPLETE',
            'reason'=>$reason,
            'cursor_id'=>0,
            'processed'=>0,
            'total'=>$total,
            'batch_size'=>max(25,min(500,(int)(PSTE_Plugin::settings()['context_batch_size']??100))),
            'inventory_sha256'=>(string)($baseline['inventory_sha256']??''),
            'structure_sha256'=>(string)($baseline['structure_sha256']??''),
            'editorial_plan_sha256'=>(string)($baseline['editorial_plan_sha256']??'NOT_AVAILABLE'),
            'payload_repair_completed'=>$total===0,
            'payload_repair_status'=>$total===0?'NOT_REQUIRED':'PENDING',
            'payloads_repaired'=>0,
            'sandbox_binding_status'=>$sandboxTotal>0?'PENDING':'COMPLETE',
            'sandbox_binding_outcome'=>$sandboxTotal>0?'PENDING':'PASS',
            'sandbox_record_ids'=>$sandboxIds,
            'sandbox_record_ids_sha256'=>self::recordIdsSha256($sandboxIds),
            'sandbox_cursor'=>0,
            'sandbox_processed'=>0,
            'sandbox_total'=>$sandboxTotal,
            'sandbox_updated'=>0,
            'sandbox_source_stale'=>0,
            'sandbox_record_missing'=>0,
            'started_at_utc'=>gmdate('c'),
            'updated_at_utc'=>gmdate('c'),
            'completed_at_utc'=>$hasWork?null:gmdate('c'),
            'error_code'=>null,
            'error_message'=>null,
            'failed_topic_uuid'=>null,
        ];

        self::saveJob($job);
        PSTE_Repository::markAllContextPending((string)$job['structure_sha256']);
        if($hasWork)self::schedule();
        return $job;
    }

    public static function status(): array {
        if(!PSTE_Plugin::isReady())return self::notReadyStatus();
        $job=get_option(PSTE_OPTION_CONTEXT_JOB,[]);
        if(!is_array($job)||!in_array((string)($job['contract']??''),array_merge([self::CONTRACT],self::LEGACY_CONTRACTS),true)){
            return self::defaultStatus();
        }
        return array_merge(self::defaultStatus(),$job);
    }

    public static function processCron(): void {
        if(!PSTE_Plugin::isReady())return;
        self::processBatch();
    }

    public static function processBatch(?int $limit=null): array {
        if(!PSTE_Plugin::isReady())return self::notReadyStatus();
        $job=self::status();
        if((string)($job['status']??'')==='BLOCKED')return $job;
        if(get_transient(self::LOCK))return $job;

        set_transient(self::LOCK,1,300);
        $phase='PREPARE';
        try{
            $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
            if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1'){
                throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
            }

            if((string)($job['contract']??'')!==self::CONTRACT){
                $job=self::upgradeLegacyJob($job,$baseline);
            }
            self::assertRecordIdsIntegrity($job);

            if(empty($job['payload_repair_completed'])){
                $phase='PAYLOAD_REPAIR';
                if((int)($job['total']??0)>0){
                    $payloadRepair=PSTE_Repository::repairInvalidTopicPayloads();
                    $job['payload_repair_status']=(string)($payloadRepair['status']??'UNKNOWN');
                    $job['payloads_repaired']=(int)($job['payloads_repaired']??0)+(int)($payloadRepair['repaired']??0);
                }else{
                    $job['payload_repair_status']='NOT_REQUIRED';
                }
                $job['payload_repair_completed']=true;
            }

            $phase='SNAPSHOT_VERIFY';
            $inventory=PSTE_Snapshot::inventory();
            $structure=PSTE_Snapshot::structure();
            $plan=PSTE_Snapshot::editorialPlan();

            if((string)($job['inventory_sha256']??'')!==(string)($inventory['sha256']??'')
                ||(string)($job['structure_sha256']??'')!==(string)($structure['sha256']??'')
                ||(string)($job['editorial_plan_sha256']??'NOT_AVAILABLE')!==(string)($plan['sha256']??'NOT_AVAILABLE')){
                return self::blockJob($job,'PSTE_CONTEXT_REFRESH_STALE','Snapshot hashes changed before the batch.',(string)($structure['sha256']??''),'',true);
            }

            $contextDone=(int)($job['processed']??0)>=(int)($job['total']??0);
            if(!$contextDone){
                $phase='PORTAL_CONTEXT_BATCH';
                $batch=max(1,min(500,$limit??(int)($job['batch_size']??100)));
                $rows=PSTE_Repository::contextBatchRows((int)($job['cursor_id']??0),$batch);
                $index=PSTE_Context_Evaluator::buildIndex($inventory,$plan);

                $result=PSTE_Repository::refreshPortalContextBatch(
                    $rows,
                    $inventory,
                    $plan,
                    $index,
                    (string)$job['structure_sha256']
                );

                $processed=(int)($result['processed']??0);
                $job['cursor_id']=(int)($result['last_id']??($job['cursor_id']??0));
                $job['processed']=(int)($job['processed']??0)+$processed;
                $contextDone=!$rows||count($rows)<$batch||$job['processed']>=(int)($job['total']??0);
            }

            $sandboxDone=(string)($job['sandbox_binding_status']??'PENDING')==='COMPLETE';
            if(!$sandboxDone){
                $phase='SANDBOX_BINDING_BATCH';
                $registry=PSTE_Article_Type_Registry::build($baseline);
                $sandbox=PSTE_Semantic_Review_Sandbox::refreshBindingsAfterBaselineChangeBatch(
                    array_values((array)($job['sandbox_record_ids']??[])),
                    (int)($job['sandbox_cursor']??0),
                    self::SANDBOX_BATCH_SIZE,
                    $baseline,
                    $inventory,
                    $registry,
                    (int)($job['sandbox_updated']??0),
                    (int)($job['sandbox_source_stale']??0),
                    (int)($job['sandbox_record_missing']??0)
                );
                $job['sandbox_cursor']=(int)($sandbox['next_cursor']??$job['sandbox_cursor']??0);
                $job['sandbox_processed']=$job['sandbox_cursor'];
                $job['sandbox_updated']=(int)($sandbox['updated_total']??$job['sandbox_updated']??0);
                $job['sandbox_source_stale']=(int)($sandbox['source_stale_total']??$job['sandbox_source_stale']??0);
                $job['sandbox_record_missing']=(int)($sandbox['record_missing_total']??$job['sandbox_record_missing']??0);
                $job['sandbox_binding_status']=(string)($sandbox['status']??'RUNNING');
                $job['sandbox_binding_outcome']=(string)($sandbox['outcome']??'PENDING');
                $sandboxDone=$job['sandbox_binding_status']==='COMPLETE';
            }

            $job['updated_at_utc']=gmdate('c');
            $job['error_code']=null;
            $job['error_message']=null;
            $job['failed_topic_uuid']=null;

            if($contextDone&&$sandboxDone){
                $job['status']='COMPLETE';
                $job['completed_at_utc']=gmdate('c');
            }else{
                $job['status']='RUNNING';
                $job['completed_at_utc']=null;
            }

            self::saveJob($job);
            if($job['status']!=='COMPLETE')self::schedule();
            return $job;
        }catch(Throwable $e){
            $failed='';
            if(preg_match('/PSTE_CONTEXT_TOPIC_([0-9a-f-]{36}):/i',(string)$e->getMessage(),$match))$failed=(string)$match[1];
            $markContext=$phase!=='SANDBOX_BINDING_BATCH';
            return self::blockJob(
                $job,
                self::errorCode($e),
                self::errorMessage($e),
                '',
                $failed,
                $markContext
            );
        }finally{
            delete_transient(self::LOCK);
        }
    }

    private static function upgradeLegacyJob(array $job,array $baseline): array {
        $ids=PSTE_Semantic_Review_Sandbox::bindingRefreshRecordIds();
        $contextDone=(int)($job['processed']??0)>=(int)($job['total']??0);
        $sandboxDone=count($ids)===0;
        $job['contract']=self::CONTRACT;
        $job['payload_repair_completed']=array_key_exists('payload_repair_status',$job)||((int)($job['processed']??0)>0)||((int)($job['total']??0)===0);
        $job['payload_repair_status']=(string)($job['payload_repair_status']??($job['payload_repair_completed']?'PASS':'PENDING'));
        $job['payloads_repaired']=(int)($job['payloads_repaired']??0);
        $job['sandbox_binding_status']=$sandboxDone?'COMPLETE':'PENDING';
        $job['sandbox_binding_outcome']=$sandboxDone?'PASS':'PENDING';
        $job['sandbox_record_ids']=$ids;
        $job['sandbox_record_ids_sha256']=self::recordIdsSha256($ids);
        $job['sandbox_cursor']=0;
        $job['sandbox_processed']=0;
        $job['sandbox_total']=count($ids);
        $job['sandbox_updated']=0;
        $job['sandbox_source_stale']=0;
        $job['sandbox_record_missing']=0;
        $job['status']=$contextDone&&$sandboxDone?'COMPLETE':'RUNNING';
        $job['completed_at_utc']=$job['status']==='COMPLETE'?($job['completed_at_utc']??gmdate('c')):null;
        $job['updated_at_utc']=gmdate('c');
        self::saveJob($job);
        return $job;
    }

    private static function blockJob(array $job,string $code,string $message,string $structureHash='',string $failedTopic='',bool $markContext=true): array {
        $job['status']='BLOCKED';
        $job['error_code']=$code;
        $job['error_message']=$message;
        $job['failed_topic_uuid']=$failedTopic!==''?$failedTopic:null;
        $job['updated_at_utc']=gmdate('c');
        self::saveJob($job);

        if($markContext){
            try{
                PSTE_Repository::markAllContextBlocked($code,$structureHash);
            }catch(Throwable $stateError){
                $job['error_message']=$message.' | CONTEXT_STATE_WRITE_FAILED: '.self::errorMessage($stateError);
                self::saveJob($job);
            }
        }
        return $job;
    }

    private static function saveJob(array $job): void {
        update_option(PSTE_OPTION_CONTEXT_JOB,$job,false);
        $stored=get_option(PSTE_OPTION_CONTEXT_JOB,[]);
        if(!is_array($stored))throw new RuntimeException('PSTE_CONTEXT_JOB_STATE_NOT_PERSISTED');
        foreach(['contract','status','cursor_id','processed','total','sandbox_cursor','sandbox_processed','sandbox_total','sandbox_binding_status','error_code'] as $field){
            if(($stored[$field]??null)!==($job[$field]??null))throw new RuntimeException('PSTE_CONTEXT_JOB_STATE_NOT_PERSISTED_'.$field);
        }
    }

    private static function recordIdsSha256(array $ids): string {
        $ids=array_values(array_map('strval',$ids));$json=wp_json_encode($ids,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
        if(!is_string($json))throw new RuntimeException('PSTE_CONTEXT_SANDBOX_RECORD_IDS_JSON_FAILED');
        return hash('sha256',$json);
    }

    private static function assertRecordIdsIntegrity(array $job): void {
        $ids=array_values((array)($job['sandbox_record_ids']??[]));$declared=(string)($job['sandbox_record_ids_sha256']??'');
        if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals($declared,self::recordIdsSha256($ids)))throw new RuntimeException('PSTE_CONTEXT_SANDBOX_RECORD_IDS_HASH_MISMATCH');
        if((int)($job['sandbox_total']??-1)!==count($ids))throw new RuntimeException('PSTE_CONTEXT_SANDBOX_RECORD_IDS_COUNT_MISMATCH');
        $cursor=(int)($job['sandbox_cursor']??0);if($cursor<0||$cursor>count($ids))throw new RuntimeException('PSTE_CONTEXT_SANDBOX_CURSOR_INVALID');
    }

    private static function errorCode(Throwable $e): string {
        $raw=strtoupper(trim((string)$e->getMessage()));
        $raw=(string)preg_replace('/[^A-Z0-9_:-]+/','_',$raw);
        return substr($raw!==''?$raw:'PSTE_CONTEXT_REFRESH_FAILED',0,160);
    }

    private static function errorMessage(Throwable $e): string {
        $raw=trim((string)$e->getMessage());
        $raw=(string)preg_replace('/[^A-Za-z0-9_:\- .]/','',$raw);
        return substr($raw!==''?$raw:'PSTE_CONTEXT_REFRESH_FAILED',0,240);
    }

    private static function defaultStatus(): array {
        return [
            'contract'=>self::CONTRACT,
            'status'=>'NOT_STARTED',
            'processed'=>0,
            'total'=>PSTE_Repository::topicPoolCount(),
            'payload_repair_completed'=>false,
            'payload_repair_status'=>'NOT_STARTED',
            'sandbox_binding_status'=>'NOT_INITIALIZED',
            'sandbox_binding_outcome'=>'NOT_INITIALIZED',
            'sandbox_record_ids'=>[],
            'sandbox_record_ids_sha256'=>self::recordIdsSha256([]),
            'sandbox_cursor'=>0,
            'sandbox_processed'=>0,
            'sandbox_total'=>0,
            'sandbox_updated'=>0,
            'sandbox_source_stale'=>0,
            'sandbox_record_missing'=>0,
            'error_code'=>null,
            'error_message'=>null,
            'failed_topic_uuid'=>null,
        ];
    }

    private static function notReadyStatus(): array {
        return [
            'contract'=>self::CONTRACT,'status'=>'NOT_STARTED','processed'=>0,'total'=>0,
            'payload_repair_completed'=>false,'payload_repair_status'=>'NOT_STARTED',
            'sandbox_binding_status'=>'NOT_INITIALIZED','sandbox_binding_outcome'=>'NOT_INITIALIZED',
            'sandbox_record_ids'=>[],'sandbox_record_ids_sha256'=>hash('sha256','[]'),'sandbox_cursor'=>0,'sandbox_processed'=>0,'sandbox_total'=>0,
            'sandbox_updated'=>0,'sandbox_source_stale'=>0,'sandbox_record_missing'=>0,
            'error_code'=>'PSTE_SAFE_BOOT_NOT_READY','error_message'=>'Der Portalabgleich bleibt bis zum sicheren Status READY gesperrt.','failed_topic_uuid'=>null,
        ];
    }

    private static function schedule(): void {
        if(!PSTE_Plugin::isReady())return;
        if(function_exists('wp_next_scheduled')&&!wp_next_scheduled(PSTE_CONTEXT_CRON_HOOK)){
            wp_schedule_single_event(time()+10,PSTE_CONTEXT_CRON_HOOK);
        }
    }
}
