<?php
if (!defined('ABSPATH')) { return; }

/** Orchestrates query-family membership plus two independently implemented retrievers and an exact consensus gate. */
final class PSTE_Semantic_Classifier {
    /** @return array<string,mixed> */
    public static function classify(string $query,?string $providerIntent,array $registry,string $familyKey): array {
        $membership=PSTE_Family_Membership::evaluate($query,$registry,$familyKey);
        if(empty($membership['ok']))return self::blockedByMembership($membership,$familyKey);
        // Provider intent is intentionally ignored: discovery sources observe queries but do not decide category/type.
        $a=PSTE_Semantic_Retriever_A::retrieve($query,$registry,$familyKey);
        $b=PSTE_Semantic_Retriever_B::retrieve($query,$registry,$familyKey);
        $aAssigned=($a['status']??'')==='ASSIGNED';$bAssigned=($b['status']??'')==='ASSIGNED';
        $aType=PSTE_Article_Type_Registry::canonicalType((string)($a['article_type']??''));$bType=PSTE_Article_Type_Registry::canonicalType((string)($b['article_type']??''));
        $typeConsensus=$aAssigned&&$bAssigned&&$aType!==''&&hash_equals($aType,$bType);
        $aTarget=(array)($a['target_category']??[]);$bTarget=(array)($b['target_category']??[]);
        $categoryConsensus=$typeConsensus&&!empty($aTarget['ok'])&&!empty($bTarget['ok'])
            &&(int)($aTarget['term_id']??0)>0&&(int)$aTarget['term_id']===(int)($bTarget['term_id']??0)
            &&hash_equals((string)($aTarget['slug']??''),(string)($bTarget['slug']??''))
            &&hash_equals((string)($aTarget['full_path']??''),(string)($bTarget['full_path']??''))
            &&hash_equals((string)($aTarget['topic_family_key']??$familyKey),(string)($bTarget['topic_family_key']??$familyKey));
        $familyConsensus=$aAssigned&&$bAssigned&&hash_equals((string)($a['topic_family_key']??''),(string)($b['topic_family_key']??''))&&hash_equals((string)($a['topic_family_key']??''),$familyKey);
        $meaningConsensus=$aAssigned&&$bAssigned&&hash_equals((string)($a['meaning']??''),(string)($b['meaning']??''));
        $intentConsensus=$aAssigned&&$bAssigned&&hash_equals((string)($a['search_intent']??''),(string)($b['search_intent']??''));
        $ok=$typeConsensus&&$categoryConsensus&&$familyConsensus&&$meaningConsensus&&$intentConsensus;
        $reasons=[];
        if(!$aAssigned)$reasons[]=(string)($a['reason']??'A_NOT_ASSIGNED');if(!$bAssigned)$reasons[]=(string)($b['reason']??'B_NOT_ASSIGNED');
        if($aAssigned&&$bAssigned&&!$typeConsensus)$reasons[]='PSTE_SEMANTIC_TYPE_CONSENSUS_MISSING';
        if($typeConsensus&&!$categoryConsensus)$reasons[]='PSTE_SEMANTIC_CATEGORY_CONSENSUS_MISSING';
        if(!$familyConsensus)$reasons[]='PSTE_SEMANTIC_FAMILY_CONSENSUS_MISSING';if(!$meaningConsensus)$reasons[]='PSTE_SEMANTIC_MEANING_CONSENSUS_MISSING';if(!$intentConsensus)$reasons[]='PSTE_SEMANTIC_INTENT_CONSENSUS_MISSING';
        $resolvedType=$typeConsensus?(string)($a['article_type']??''):'';$resolved=$categoryConsensus?$aTarget:[];$family=(array)($registry['families'][$familyKey]??[]);
        return ['contract'=>'PSTE_SEMANTIC_DOUBLE_STRAND_V3','ok'=>$ok,'status'=>$ok?'CONSENSUS_PASS':($typeConsensus&&!$categoryConsensus?'CATEGORY_GAP_REVIEW':'CONSENSUS_REVIEW'),
            'type_consensus'=>$typeConsensus,'category_consensus'=>$categoryConsensus,'family_consensus'=>$familyConsensus,'meaning_consensus'=>$meaningConsensus,'intent_consensus'=>$intentConsensus,
            'family_membership_gate'=>$membership,'strand_a'=>$a,'strand_b'=>$b,'resolved_article_type'=>$resolvedType,'resolved_category'=>$resolved,
            'resolved_family'=>(string)($family['topic_family_name']??''),'resolved_family_key'=>$familyKey,
            'reason_codes'=>array_values(array_unique(array_filter($reasons))),'independence'=>'FAMILY_MEMBERSHIP_PLUS_TWO_IMPLEMENTATIONS_NO_SHARED_TYPE_OR_CATEGORY_DECISION','provider_intent_used'=>false];
    }

    /** Independent A/B article-type consensus without claiming an existing family/category. @return array<string,mixed> */
    public static function classifyTypeOnly(string $query,array $registry): array {
        $key='__pste_type_only__';$synthetic=$registry;$rows=[];$n=1;
        foreach((array)($registry['types']??[]) as $canonical=>$definition){$visible=(string)($definition['visible_name']??'');if($visible==='')continue;$rows[(string)$canonical]=['term_id'=>$n++,'parent'=>0,'name'=>$visible.' __proposal__','slug'=>'proposal-'.$canonical,'article_type'=>$visible,'canonical_type_id'=>(string)$canonical,'topic_family_name'=>'','topic_family_key'=>$key,'full_path'=>'','head_intent'=>'','product_page_id'=>0,'product_page_name'=>'','product_page_slug'=>''];}
        $synthetic['families'][$key]=['topic_family_name'=>'','topic_family_key'=>$key,'by_type'=>$rows];
        $a=PSTE_Semantic_Retriever_A::retrieve($query,$synthetic,$key);$b=PSTE_Semantic_Retriever_B::retrieve($query,$synthetic,$key);
        $aAssigned=($a['status']??'')==='ASSIGNED';$bAssigned=($b['status']??'')==='ASSIGNED';$aType=PSTE_Article_Type_Registry::canonicalType((string)($a['article_type']??''));$bType=PSTE_Article_Type_Registry::canonicalType((string)($b['article_type']??''));
        $ok=$aAssigned&&$bAssigned&&$aType!==''&&hash_equals($aType,$bType)&&hash_equals((string)($a['meaning']??''),(string)($b['meaning']??''))&&hash_equals((string)($a['search_intent']??''),(string)($b['search_intent']??''));
        return ['contract'=>'PSTE_SEMANTIC_TYPE_ONLY_DOUBLE_STRAND_V1','ok'=>$ok,'status'=>$ok?'TYPE_CONSENSUS_PASS':'TYPE_CONSENSUS_REVIEW','resolved_article_type'=>$ok?(string)($a['article_type']??''):'','strand_a'=>$a,'strand_b'=>$b,'category_or_family_claimed'=>false,'reason_codes'=>$ok?[]:['PSTE_TYPE_ONLY_CONSENSUS_NOT_PROVEN'],'write_attempted'=>false];
    }

    /** @return array<string,mixed> */
    private static function blockedByMembership(array $membership,string $familyKey): array {return [
        'contract'=>'PSTE_SEMANTIC_DOUBLE_STRAND_V3','ok'=>false,'status'=>'FAMILY_MEMBERSHIP_REVIEW','type_consensus'=>false,'category_consensus'=>false,'family_consensus'=>false,'meaning_consensus'=>false,'intent_consensus'=>false,
        'family_membership_gate'=>$membership,'strand_a'=>[],'strand_b'=>[],'resolved_article_type'=>'','resolved_category'=>[],'resolved_family'=>(string)($membership['topic_family_name']??''),'resolved_family_key'=>$familyKey,
        'reason_codes'=>array_values((array)($membership['reason_codes']??['PSTE_FAMILY_MEMBERSHIP_BLOCKED'])),'independence'=>'FAMILY_MEMBERSHIP_PLUS_TWO_IMPLEMENTATIONS_NO_SHARED_TYPE_OR_CATEGORY_DECISION','provider_intent_used'=>false,
    ];}
}
