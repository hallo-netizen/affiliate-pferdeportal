# PSTE 0.36.0 – Coordination-Lock Recovery + replay-sichere Research-Finalisierung

- Behebt den realen Breitenlauf-Abbruch `PSTE_SANDBOX_LOCKED`.
- Behandelt interne Kurzzeitsperren `PSTE_SANDBOX_LOCKED`, `PSTE_BUDGET_RESERVATION_LOCKED` und `PSTE_RESEARCH_STEP_ALREADY_RUNNING` als Koordinationszustände statt fachliche Fehler.
- Bestehende 0.35-PAUSED_ERROR-Zustände werden nur für diese exakt freigegebenen transienten Codes automatisch wieder aufgenommen.
- Echte fachliche, Snapshot-, Provider- und Integritätsfehler bleiben fail-closed.
- Research-Finalisierung nutzt replay-sichere Sandbox-Batches mit deterministischen Receipts; ein Retry nach Lock-Kollision dupliziert keine bereits bestätigten Sandbox-Aufnahmen.
- Breitenqueue fängt zusätzlich den Race `PSTE_RESEARCH_JOB_ALREADY_ACTIVE` ab und übernimmt nur einen exakt zur aktuellen Familie passenden Kindjob.
- Keine Änderung an Textmaschine, STARTMASTER 0039, PSERC, PPM, Artikelinhalt, HTML, Design oder Publish-Logik.
- Backend-Hinweistext ist themen- und portalneutral formuliert.
