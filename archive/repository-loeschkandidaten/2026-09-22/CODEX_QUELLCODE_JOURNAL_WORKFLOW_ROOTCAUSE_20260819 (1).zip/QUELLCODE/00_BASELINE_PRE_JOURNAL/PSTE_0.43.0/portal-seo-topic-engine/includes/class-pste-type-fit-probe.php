<?php
if (!defined('ABSPATH')) { return; }

/** Post-consensus evidence probe. It can only support, stay neutral or request review. */
final class PSTE_Type_Fit_Probe {
    /** @return array<string,mixed> */
    public static function evaluate(array $semantic,array $records,array $registry): array {
        if(empty($semantic['ok'])||empty($semantic['type_consensus'])||empty($semantic['category_consensus']))return ['contract'=>'PSTE_TYPE_FIT_EVIDENCE_PROBE_V1','status'=>'TYPE_PROBE_UNAVAILABLE','ok'=>false,'reason_codes'=>['TYPE_PROBE_REQUIRES_A_B_CONSENSUS'],'resolved_article_type'=>(string)($semantic['resolved_article_type']??''),'resolved_category_id'=>(int)($semantic['resolved_category']['term_id']??0),'mutation_attempted'=>false];
        $resolved=(string)$semantic['resolved_article_type'];$resolvedCanonical=PSTE_Article_Type_Registry::canonicalType($resolved);$support=0;$conflicts=[];$observed=[];
        foreach($records as $record){$q=(string)($record['language_corrected_query']??$record['raw_query']??'');if($q==='')continue;$observed[]=hash('sha256',PSTE_Normalizer::exactTopicIdentityText($q));
            foreach((array)($registry['types']??[]) as $canonical=>$row){foreach((array)($row['aliases']??[]) as $alias){$needle=PSTE_Normalizer::exactTopicIdentityText((string)$alias);$hay=PSTE_Normalizer::exactTopicIdentityText($q);if($needle===''||!preg_match('/(?:^|\s)'.preg_quote($needle,'/').'(?:\s|$)/u',$hay))continue;if((string)$canonical===$resolvedCanonical)$support++;else $conflicts[(string)$canonical]=($conflicts[(string)$canonical]??0)+1;break;}}
        }
        arsort($conflicts,SORT_NUMERIC);$topConflict=(int)(reset($conflicts)?:0);
        if($topConflict>$support&&$topConflict>=2)$status='TYPE_EVIDENCE_CONFLICT_REVIEW';elseif($support>0)$status='TYPE_FIT_SUPPORTED';else $status='TYPE_FIT_NEUTRAL';
        return ['contract'=>'PSTE_TYPE_FIT_EVIDENCE_PROBE_V1','status'=>$status,'ok'=>$status!=='TYPE_EVIDENCE_CONFLICT_REVIEW','reason_codes'=>$status==='TYPE_EVIDENCE_CONFLICT_REVIEW'?['TYPE_EVIDENCE_CONFLICT_REVIEW']:[],
            'support_count'=>$support,'conflict_counts'=>$conflicts,'observation_hashes'=>array_values(array_unique($observed)),'resolved_article_type'=>$resolved,'resolved_category_id'=>(int)($semantic['resolved_category']['term_id']??0),
            'category_or_type_changed'=>false,'mutation_attempted'=>false,'input_to_retrievers'=>false];
    }
}
