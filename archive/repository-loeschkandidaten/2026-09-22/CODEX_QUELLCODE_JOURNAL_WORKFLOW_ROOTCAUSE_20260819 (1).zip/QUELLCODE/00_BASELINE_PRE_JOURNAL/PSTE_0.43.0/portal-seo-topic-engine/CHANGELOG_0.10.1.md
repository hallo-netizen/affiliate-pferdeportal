# 0.10.1-staging

- Stellt den verbindlichen Workflow wieder her: Longtail-Discovery, getrennte Roh-/Normal-/Sprachform, dynamische Artikeltyp-Registry, unabhängiger Doppelstrang-Konsens, exakte reale Kategorie, Vor-/Nach-Titel-Dublettenprüfung und Metadaten-Handoff.
- Ein Startklick führt automatisch durch drei begrenzte DataForSEO-Labs-Quellen: Keyword Suggestions, Related Keywords und Keyword Ideas. Suchintention und Beitragstyp werden portalbezogen durch zwei getrennte lokale Semantikstränge bestimmt; es gibt keinen zusätzlichen externen Intent- oder Live-SERP-Schritt. Keine separate Google-Live-SERP-Prüfung, keine Cron- oder manuelle Klickschleife.
- Alte Live-SERP-Daten werden vor Deaktivierung archiviert, nicht gelöscht.
- Artikeltypen werden aus der realen Taxonomie gelesen. Neue Typen erfordern keine feste Typenliste in der SEO-Engine.
- Fehlende Typblätter erzeugen ausschließlich read-only Kategorienlücken-Vorschläge; WordPress-Kategorien werden nie verändert.
- Keine Änderung an Beiträgen, Textmaschine, Artikelqualität, HTML, Design oder Formatierung.
- Behebt eine Rohdatenkollision: Providerbegriffe werden nicht mehr über gestemmte, sortierte Tokens vorab zusammengelegt. Exakte Rohformulierungen bleiben getrennt erhalten.
- Führt konservative Synonym-/Schreibvarianten-Gruppen erst nach Rohdatenerhalt ein und speichert bis zu 300 relevante Gruppen statt nur der ersten 50.
