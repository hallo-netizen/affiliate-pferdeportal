# Portal SEO Themenengine 0.11.0

## Gebündelter Ursachenbau: Familienidentität V2

- Neue, versionierte Familienidentität V2 ausschließlich für Familien- und Kontextbindung.
- Der globale Legacy-Normalizer `PSTE_Normalizer::text()` und sämtliche bestehenden Legacy-Hashes bleiben unverändert.
- Sachgegenstände werden nur als exaktes Token oder als kontrollierter rechter deutscher Kompositumkopf erkannt. Freie Teilstringtreffer sind verboten.
- Familien können getrennt gepflegte Kontext-, Pflichtmerkmal-, Ausschluss-, Alternativ-, Zahlen- und Einheitengruppen besitzen.
- Explizite Gegenkontexte blockieren; impliziter Portalkontext ist nur bei dafür freigegebenen Familien zulässig.
- Genau eine spezifischste Familie darf gewinnen. Mehrdeutige Zweige oder gleich starke Treffer bleiben `REVIEW_REQUIRED`.
- Der Recherchelauf exportiert Filterzahlen und konkrete Ablehnungsgründe statt eines unbegründeten Null-Kandidaten-Status.
- Vollständiger V2-Bestandsaudit über alle gespeicherten Longtails und zugehörigen Tabellen.
- Der Audit liest den Quellbestand schreibfrei und speichert ausschließlich sein eigenes PSTE-Auditprotokoll.
- Apply bleibt technisch gesperrt, bis ein Claude-Dry-run-PASS und eine snapshotgebundene Nutzerfreigabe importiert wurden.
- Apply ändert ausschließlich eindeutig autorisierte interne PSTE-Zuordnungen. Rohkeywords bleiben byteidentisch.
- Idempotenter Apply, exakter Rollback, Snapshot-/Registry-/Artikelwächter und vollständige Rückleseprüfungen.
- Ein neuer Auditzyklus ist vor dem Rollback eines aktiven Apply gesperrt.

## Absolute Schutzgrenze

Veröffentlichte Artikel und Entwürfe werden ausschließlich read-only gehasht. Beiträge, Titel, Slugs, Kategorien, Metadaten, Inhalte, HTML, CSS, Design, PPM, Compiler, Textmaschine und Qualitätsregeln werden weder direkt noch indirekt verändert.

## Claude-Korrektur vor Live-Dry-run

- Der aktive Legacy-Fallback enthaelt keine branchenspezifische Sonderbehandlung fuer numerische Modifikatoren mehr.
- Die bereits vorhandene generische numerische Erkennung bleibt allein zustaendig; `2 Pferdeanhänger`, `2 Hundeanhänger` und vergleichbare portalunabhaengige Formen werden ueber denselben Codepfad behandelt.
- Neuer expliziter Legacy-Fallback-Negativ-/Positivtest verhindert eine Wiederkehr branchenspezifischer Sonderlogik.
- Keine Aenderung an V2-Identitaet, globalem Legacy-Normalizer, Textmaschine, PPM, Compiler, HTML, CSS, Design oder Qualitaetsregeln.
