# Portal SEO Themenengine 0.34.0

## Anlass
Der reale Longtail-Start konnte im Browser mit `PSTE_AJAX_RESPONSE_INVALID` abbrechen. 0.33.0 versuchte AJAX-Antworten unmittelbar als JSON zu parsen und verlor bei einer beschädigten Transporthülle jede verwertbare Zustandsinformation. Gleichzeitig war die reguläre breite Portalrecherche unnötig auf Einzelklicks je Themenfamilie angewiesen.

## Root-Cause-Fix: AJAX-Grenze
- Alle PSTE-Admin-AJAX-Endpunkte erhalten eine eigene Output-Buffer-Grenze.
- Versehentliche PHP-/Plugin-Ausgaben innerhalb des PSTE-AJAX-Aufrufs werden vor der JSON-Antwort verworfen.
- Browsercode liest zuerst den Rohtext und parst anschließend strikt JSON; der alte undiagnostische `response.json()`-Blindpfad ist entfernt.
- Bei ungültiger Transportantwort wird **keine Provideranfrage automatisch wiederholt**. Stattdessen wird der persistierte Serverstatus über einen sicheren Seiten-Reload neu eingelesen.
- Ein bereits autorisierter `RUNNING`-Rechercheauftrag wird nach diesem Readback automatisch fortgesetzt; `PAUSED_ERROR` und `OUTCOME_UNKNOWN` bleiben fail-closed.

## Breitenrecherche
- Neuer persistenter Breitenlauf für 1 bis 4 noch nicht analysierte Themenfamilien.
- Auswahl erfolgt dynamisch aus dem aktuellen Portalbestand.
- Zuerst werden unterschiedliche Portal-Hauptzweige bedient; danach weitere offene Familien.
- Keine portalspezifischen oder themenspezifischen Namen sind in der Auswahl fest codiert.
- Eine explizite Kostenbestätigung startet die gewählte Serie; jeder Kindlauf behält die bestehende Einzelbudgetgrenze.
- Kindläufe verwenden unverändert `PSTE_Research_Job`; Provider-Unknown wird niemals automatisch wiederholt.

## Unverändert
- Title Authority / Titelregeln aus 0.33.0
- Exact Five
- STARTMASTER 0039 / Textmaschine
- PSERC / Workflow-Supervisor
- PPM 6.7.9
- Artikelinhalt, HTML, Design, Kategorien, URLs, Yoast und Veröffentlichung
