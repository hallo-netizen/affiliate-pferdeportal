# PSTE 0.38.0 — Site-context lifecycle + full workflow recovery

- Separates hard portal-structure identity from dynamic read-only inventory/editorial-plan context.
- Safely rebases dynamic context during an active research/breadth run without repeating provider requests.
- Material structure changes remain fail-closed.
- Existing 0.37 `PSTE_SITE_BASELINE_STALE` pauses can auto-recover only after a proven safe rebase.
- Finalize rechecks inventory, structure and editorial plan before any persistent candidate/work-queue write.
- `PSTE_SNAPSHOT_STALE_OR_CHANGED` is replay-safe only in FINALIZE with all provider responses already persisted.
- Settings UI recovers active safe context before rendering the baseline badge.
