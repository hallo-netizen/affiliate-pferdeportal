<?php
if (!defined('ABSPATH')) { return; }

/** Independent German surface/mechanics reviewer; it cannot alter, compose or semantically approve a title. */
final class PSTE_German_Title_Reviewer {
    /** @return array<string,mixed> */
    public static function review(string $title,string $family,string $type): array {
        $r=[];
        if($title!==self::capitalize($title))$r[]='TITLE_SENTENCE_START_CASE';
        if(preg_match('/\s{2,}/u',$title))$r[]='TITLE_WHITESPACE_INVALID';
        $words=preg_split('/\s+/u',trim(rtrim($title,'?')))?:[];if(count($words)<3||count($words)>16)$r[]='TITLE_LENGTH_OUTSIDE_SAFE_RANGE';
        if(preg_match('/\b(and|the|best|guide|review|how\s+to)\b/iu',$title))$r[]='UNCLEAR_LANGUAGE_MIX';
        if(preg_match('/\b(mit|für|fuer|ohne|gegen|von|bei|im|in|auf|unter|zum|zur)\s+(im\s+Vergleich|sinnvoll|richtig|sicher)\b/iu',$title))$r[]='GERMAN_DANGLING_RELATION';
        if(str_contains($title,'mit Schwerpunkt'))$r[]='GENERIC_KEYWORD_BRIDGE_PHRASE_FORBIDDEN';
        if(PSTE_Title_Validator::hasArtificialGeneratorPhrase($title))$r[]='GERMAN_ARTIFICIAL_GENERATOR_PHRASE_FORBIDDEN';
        if(self::questionSubjectCaseSuspect($title))$r[]='GERMAN_QUESTION_SUBJECT_CASE_SUSPECT';
        if(self::telegraphicQuestionSuspect($title))$r[]='GERMAN_TELEGRAPHIC_QUESTION_SUSPECT';
        $canonical=PSTE_Article_Type_Registry::canonicalType($type);
        if($canonical==='faq'&&(!PSTE_Normalizer::isQuestion($title)||!str_ends_with($title,'?')))$r[]='FAQ_TITLE_NOT_GRAMMATICAL_QUESTION';
        if($canonical!=='faq'&&str_contains($title,'?'))$r[]='NONFAQ_TITLE_IS_QUESTION';
        return ['ok'=>!$r,'status'=>$r?'LANGUAGE_REVIEW':'LANGUAGE_PASS','reason_codes'=>array_values(array_unique($r)),'semantic_quality_claimed'=>false,'review_scope'=>'INDEPENDENT_GERMAN_PLANNING_TITLE_SURFACE_MECHANICS_NO_ARTICLE_CONTENT','write_attempted'=>false,'reviewer_contract'=>'PSTE_GERMAN_TITLE_REVIEWER_V7_HARD_SURFACE_LENGTH_GUARD'];
    }

    private static function telegraphicQuestionSuspect(string $title): bool {
        if(!PSTE_Normalizer::isQuestion($title)||str_contains($title,'–'))return false;
        $q=self::lower(trim(rtrim($title,'?')));
        if(preg_match('/^wie\s+\S+\s+(installier\w*|reinig\w*|reparier\w*|montier\w*|anwend\w*|lager\w*|pfleg\w*)$/u',$q))return true;
        if(preg_match('/^was\s+kostet\s+\S+$/u',$q))return true;
        if(preg_match('/^(welcher|welche|welches|kann)\s+\S+\s+\S+$/u',$q))return true;
        return false;
    }

    private static function questionSubjectCaseSuspect(string $title): bool {
        if(!PSTE_Normalizer::isQuestion($title)||str_contains($title,'–'))return false;$clean=trim(rtrim($title,'?'));$parts=preg_split('/\s+/u',$clean)?:[];if(count($parts)<2)return false;
        $first=self::lower((string)$parts[0]);if(in_array($first,['wie','was','welche','welcher','welches','wann','warum','wieso','weshalb','wo','wer','wem','wen'],true))return false;
        $second=(string)$parts[1];$lower=self::lower($second);if(in_array($lower,['ich','du','er','sie','es','wir','ihr','man','mir','dir','ihm','ihr','uns','euch','mein','meine','dein','deine','sein','seine','eine','ein','der','die','das'],true))return false;
        $firstChar=function_exists('mb_substr')?mb_substr($second,0,1,'UTF-8'):substr($second,0,1);$upper=function_exists('mb_strtoupper')?mb_strtoupper($firstChar,'UTF-8'):strtoupper($firstChar);return $firstChar!==$upper;
    }
    private static function lower(string $v): string{return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
    private static function capitalize(string $v): string {if($v==='')return '';$f=function_exists('mb_substr')?mb_substr($v,0,1,'UTF-8'):substr($v,0,1);$r=function_exists('mb_substr')?mb_substr($v,1,null,'UTF-8'):substr($v,1);$f=function_exists('mb_strtoupper')?mb_strtoupper($f,'UTF-8'):strtoupper($f);return $f.$r;}
}
