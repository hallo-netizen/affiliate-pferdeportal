<?php
if (!defined('ABSPATH')) { return; }

/**
 * Durable, request-bounded safe migration coordinator.
 *
 * It owns lifecycle/cursor/step-lock only. Semantic authority remains in the existing shared normal path,
 * Sandbox and repository. It never reads or writes posts, postmeta, terms, design or production/text-machine data.
 */
final class PSTE_Safe_Migration_Job {
    public const CONTRACT='PSTE_SAFE_MIGRATION_JOB_V3';
    private const STEP_LOCK_TTL=90;
    private const LEGACY_IDENTITY_BATCH_SIZE=10;
    private const EDITORIAL_BATCH_SIZE=10;
    private const SANDBOX_BATCH_SIZE=10;

    /** @return array<string,mixed>|null */
    public static function current(): ?array {
        $v=get_option(PSTE_OPTION_SAFE_MIGRATION_JOB,null);if($v===null||$v===false||$v===[])return null;if(!is_array($v))throw new RuntimeException('PSTE_SAFE_MIGRATION_JOB_STORAGE_INVALID');self::assertJob($v);return $v;
    }

    /** @return array<string,mixed> */
    public static function start(string $trigger='MANUAL_RETRY'): array {
        $existing=self::current();
        if(is_array($existing)&&hash_equals(PSTE_SAFE_MIGRATION_PROTOCOL,(string)($existing['protocol']??''))){$status=(string)($existing['status']??'');if(in_array($status,['RUNNING','PAUSED_ERROR'],true))return self::publicState($existing);if($status==='COMPLETE'&&PSTE_Plugin::isReady())return self::publicState($existing);}
        $sourceSchema=(string)get_option(PSTE_OPTION_SCHEMA,'');if(!PSTE_Plugin::supportedSourceSchema($sourceSchema))throw new RuntimeException('PSTE_UNSUPPORTED_SOURCE_SCHEMA_'.$sourceSchema);
        $uuid=function_exists('wp_generate_uuid4')?wp_generate_uuid4():uniqid('pste-safe-',true);$previous=[];
        if(is_array($existing))$previous=['protocol'=>(string)($existing['protocol']??''),'status'=>(string)($existing['status']??''),'phase'=>(string)($existing['phase']??''),'job_uuid'=>(string)($existing['job_uuid']??''),'last_error'=>(string)($existing['last_error']??'')];
        $job=['contract'=>self::CONTRACT,'protocol'=>PSTE_SAFE_MIGRATION_PROTOCOL,'plugin_version'=>PSTE_VERSION,'job_uuid'=>$uuid,'trigger'=>$trigger,'status'=>'RUNNING','phase'=>'PREPARE','source_schema'=>$sourceSchema,'target_schema'=>PSTE_Plugin::targetSchemaVersion(),'started_at_utc'=>gmdate('c'),'updated_at_utc'=>gmdate('c'),'completed_at_utc'=>'','last_error'=>'','last_error_phase'=>'','payload_integrity_cursor'=>0,'payload_integrity_total'=>0,'payload_integrity_init'=>[],'payload_integrity_report'=>[],'editorial_raw_cursor'=>0,'editorial_raw_chain'=>'','editorial_prepare_cursor'=>0,'editorial_variant_cursor'=>0,'editorial_variant_groups'=>[],'editorial_finalize_cursor'=>0,'editorial_core_verify_cursor'=>0,'editorial_core_verify_chain'=>'','editorial_final_verify_cursor'=>0,'editorial_final_verify_chain'=>'','editorial_total'=>0,'editorial_init'=>[],'editorial_variant_plan'=>[],'sandbox_cursor'=>0,'sandbox_total'=>0,'sandbox_queue'=>[],'sandbox_receipts'=>[],'editorial_report'=>[],'final_verify'=>[],'legacy'=>['identity_cursor'=>0,'identity_total'=>0,'identity_mode'=>'','identity_history_repaired'=>0],'previous_job'=>$previous,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'textmachine_or_design_write_attempted'=>false];
        self::save($job);PSTE_Plugin::migrationBootStatus('PENDING','SAFE_MIGRATION_PREPARE','', 'Sichere Migration wurde als fortsetzbarer Job gestartet.', ['job_uuid'=>$uuid,'protocol'=>PSTE_SAFE_MIGRATION_PROTOCOL]);return self::publicState($job);
    }

    /** @return array<string,mixed> */
    public static function advance(string $jobUuid,bool $explicitResume=false): array {
        $job=self::current();if(!is_array($job)||!hash_equals(trim($jobUuid),(string)($job['job_uuid']??'')))throw new RuntimeException('PSTE_SAFE_MIGRATION_JOB_NOT_FOUND');
        if(!hash_equals(PSTE_SAFE_MIGRATION_PROTOCOL,(string)($job['protocol']??'')))throw new RuntimeException('PSTE_SAFE_MIGRATION_PROTOCOL_MISMATCH');
        if((string)$job['status']==='COMPLETE')return self::publicState($job);
        if((string)$job['status']==='PAUSED_ERROR'&&!$explicitResume)return self::publicState($job);
        if(!in_array((string)$job['status'],['RUNNING','PAUSED_ERROR'],true))throw new RuntimeException('PSTE_SAFE_MIGRATION_JOB_NOT_RESUMABLE');
        $token=self::acquireStepLock((string)$job['job_uuid']);
        try{
            // Re-read after lock so concurrent clients cannot advance a stale snapshot.
            $fresh=self::current();if(!is_array($fresh)||!hash_equals((string)$fresh['job_uuid'],(string)$job['job_uuid']))throw new RuntimeException('PSTE_SAFE_MIGRATION_JOB_CHANGED');$job=$fresh;$job['status']='RUNNING';$job['last_error']='';$job['last_error_phase']='';
            $phase=(string)($job['phase']??'PREPARE');PSTE_Plugin::migrationBootStatus('PENDING','SAFE_MIGRATION_'.$phase,'','Sichere Migration läuft request-bounded und fortsetzbar.',['job_uuid'=>$job['job_uuid'],'phase'=>$phase]);
            self::executeOnePhase($job);$job['updated_at_utc']=gmdate('c');self::save($job);return self::publicState($job);
        }catch(Throwable $e){
            try{$latest=self::current();if(is_array($latest)&&hash_equals((string)($latest['job_uuid']??''),(string)($job['job_uuid']??'')))$job=$latest;$job['status']='PAUSED_ERROR';$job['last_error']=self::safeCode($e->getMessage());$job['last_error_phase']=(string)($job['phase']??'UNKNOWN');$job['updated_at_utc']=gmdate('c');self::save($job);PSTE_Plugin::migrationBootStatus('PENDING','SAFE_MIGRATION_PAUSED_'.$job['last_error_phase'],$job['last_error'],'Die Migration wurde an einer dauerhaften Grenze angehalten und kann kontrolliert fortgesetzt werden.',['job_uuid'=>$job['job_uuid'],'phase'=>$job['last_error_phase']]);}catch(Throwable $stateError){}
            throw $e;
        }finally{self::releaseStepLock($token);}
    }

    /** @param array<string,mixed> $job */
    private static function executeOnePhase(array &$job): void {
        $phase=(string)$job['phase'];$target=PSTE_Plugin::targetSchemaVersion();
        if($phase==='PREPARE'){
            PSTE_Plugin::safeMigrationPreparation();$job['phase']=((string)$job['source_schema']===$target)?'PAYLOAD_INTEGRITY_INIT':'CREATE_SCHEMA';return;
        }
        if($phase==='CREATE_SCHEMA'){PSTE_Repository::createSchema();$job['phase']='MIGRATION_BASELINE';return;}
        if($phase==='MIGRATION_BASELINE'){$job['legacy']['before']=PSTE_Repository::migrationBaseline();$job['phase']='SETTINGS';return;}
        if($phase==='SETTINGS'){PSTE_Plugin::safeMigrationSettingsPhase();$job['phase']='CREDENTIAL_ENCRYPTION';return;}
        if($phase==='CREDENTIAL_ENCRYPTION'){PSTE_Credentials::migrateLegacyEncryption();$job['phase']='TOPIC_SCHEMA';return;}
        if($phase==='TOPIC_SCHEMA'){PSTE_Repository::ensureTopicSchemaReady();$job['phase']='TOPIC_IDENTITY_INIT';return;}
        if($phase==='TOPIC_IDENTITY_INIT'){
            $identity=PSTE_Repository::topicIdentityMigrationInitialize((string)$job['job_uuid']);if(($identity['contract']??'')!=='PSTE_TOPIC_IDENTITY_MIGRATION_INIT_V1')throw new RuntimeException('PSTE_TOPIC_IDENTITY_MIGRATION_INIT_INVALID');$job['legacy']['identity_init']=$identity;$job['legacy']['identity_cursor']=0;$job['legacy']['identity_total']=(int)($identity['work_total']??0);$job['legacy']['identity_mode']=(string)($identity['mode']??'');$job['legacy']['identity_history_repaired']=0;
            if((string)$identity['mode']==='IN_PLACE_UUID_MIGRATION')$job['phase']=$job['legacy']['identity_total']>0?'TOPIC_IDENTITY_IN_PLACE_BATCH':'TOPIC_IDENTITY_HISTORY_BATCH';
            elseif((string)$identity['mode']==='RECOVERED_FROM_CANDIDATES')$job['phase']=$job['legacy']['identity_total']>0?'TOPIC_IDENTITY_RECOVERY_BATCH':'TOPIC_IDENTITY_HISTORY_BATCH';
            elseif((string)$identity['mode']==='EMPTY_NEW_INSTALL')$job['phase']='TOPIC_IDENTITY_VERIFY';
            else throw new RuntimeException('PSTE_TOPIC_IDENTITY_MIGRATION_MODE_INVALID');return;
        }
        if($phase==='TOPIC_IDENTITY_IN_PLACE_BATCH'){
            $batch=PSTE_Repository::topicIdentityMigrationInPlaceBatch((int)($job['legacy']['identity_cursor']??0),self::LEGACY_IDENTITY_BATCH_SIZE,(string)$job['job_uuid']);if(($batch['contract']??'')!=='PSTE_TOPIC_IDENTITY_MIGRATION_BATCH_V1')throw new RuntimeException('PSTE_TOPIC_IDENTITY_MIGRATION_BATCH_INVALID');$job['legacy']['identity_cursor']=(int)$batch['cursor'];$job['legacy']['identity_total']=(int)$batch['total'];if(!empty($batch['complete']))$job['phase']='TOPIC_IDENTITY_HISTORY_BATCH';return;
        }
        if($phase==='TOPIC_IDENTITY_RECOVERY_BATCH'){
            $batch=PSTE_Repository::topicIdentityRecoveryBatch((int)($job['legacy']['identity_cursor']??0),self::LEGACY_IDENTITY_BATCH_SIZE,(string)$job['job_uuid']);if(($batch['contract']??'')!=='PSTE_TOPIC_IDENTITY_RECOVERY_BATCH_V1')throw new RuntimeException('PSTE_TOPIC_IDENTITY_RECOVERY_BATCH_INVALID');$job['legacy']['identity_cursor']=(int)$batch['cursor'];$job['legacy']['identity_total']=(int)$batch['total'];$job['legacy']['candidate_rows_quarantined']=(int)($job['legacy']['candidate_rows_quarantined']??0)+(int)($batch['candidate_rows_quarantined']??0);if(!empty($batch['complete']))$job['phase']='TOPIC_IDENTITY_HISTORY_BATCH';return;
        }
        if($phase==='TOPIC_IDENTITY_HISTORY_BATCH'){
            $batch=PSTE_Repository::topicIdentityHistoryRepairBatch(self::LEGACY_IDENTITY_BATCH_SIZE);if(($batch['contract']??'')!=='PSTE_TOPIC_IDENTITY_HISTORY_BATCH_V1')throw new RuntimeException('PSTE_TOPIC_IDENTITY_HISTORY_BATCH_INVALID');$job['legacy']['identity_history_repaired']=(int)($job['legacy']['identity_history_repaired']??0)+(int)($batch['repaired']??0);if(!empty($batch['complete']))$job['phase']='TOPIC_IDENTITY_VERIFY';return;
        }
        if($phase==='TOPIC_IDENTITY_VERIFY'){
            $migration=PSTE_Repository::topicIdentityMigrationVerify((array)($job['legacy']['identity_init']??[]),(int)($job['legacy']['identity_history_repaired']??0));if(!is_array($migration)||!in_array((string)($migration['mode']??''),['IN_PLACE_UUID_MIGRATION','RECOVERED_FROM_CANDIDATES','EMPTY_NEW_INSTALL'],true))throw new RuntimeException('PSTE_TOPIC_MIGRATION_RESULT_INVALID');$job['legacy']['identity_migration']=$migration;$job['phase']='STORAGE_PREFLIGHT';return;
        }
        if($phase==='STORAGE_PREFLIGHT'){$storage=PSTE_Repository::assertOwnJsonStorageReady();if((string)($storage['status']??'')!=='PASS')throw new RuntimeException('PSTE_JSON_STORAGE_PREFLIGHT_FAILED');$job['legacy']['storage_preflight']=$storage;$job['phase']='TOPIC_RECLASSIFICATION';return;}
        if($phase==='TOPIC_RECLASSIFICATION'){
            $job['legacy']['semantic_backfill']=['contract'=>'PSTE_SEMANTIC_BACKFILL_V2','status'=>'SUPERSEDED_BY_REQUEST_BOUNDED_EDITORIAL_REBUILD','provider_requests'=>0,'write_attempted'=>false,'production_handoff_attempted'=>false];$job['phase']='PAYLOAD_INTEGRITY_INIT';return;
        }
        if($phase==='PAYLOAD_INTEGRITY_INIT'){
            $init=PSTE_Repository::topicPayloadIntegrityInitialize((string)$job['job_uuid']);if(($init['contract']??'')!=='PSTE_TOPIC_PAYLOAD_INTEGRITY_INIT_V1')throw new RuntimeException('PSTE_PAYLOAD_INTEGRITY_INIT_INVALID');$job['payload_integrity_init']=$init;$job['payload_integrity_cursor']=0;$job['payload_integrity_total']=(int)($init['topic_count']??0);$job['payload_integrity_report']=['repaired'=>0,'quarantined'=>0,'unchanged'=>0];$job['phase']=$job['payload_integrity_total']>0?'PAYLOAD_INTEGRITY_BATCH':'PAYLOAD_INTEGRITY_VERIFY';return;
        }
        if($phase==='PAYLOAD_INTEGRITY_BATCH'){
            $batch=PSTE_Repository::topicPayloadIntegrityBatch((int)($job['payload_integrity_cursor']??0),self::LEGACY_IDENTITY_BATCH_SIZE,(string)$job['job_uuid']);if(($batch['contract']??'')!=='PSTE_TOPIC_PAYLOAD_INTEGRITY_BATCH_V1')throw new RuntimeException('PSTE_PAYLOAD_INTEGRITY_BATCH_INVALID');$job['payload_integrity_cursor']=(int)$batch['cursor'];$job['payload_integrity_total']=(int)$batch['total'];foreach(['repaired','quarantined','unchanged'] as $k)$job['payload_integrity_report'][$k]=(int)($job['payload_integrity_report'][$k]??0)+(int)($batch[$k]??0);if(!empty($batch['complete']))$job['phase']='PAYLOAD_INTEGRITY_VERIFY';return;
        }
        if($phase==='PAYLOAD_INTEGRITY_VERIFY'){
            $job['payload_integrity_report']['verify']=PSTE_Repository::topicPayloadIntegrityVerify((array)$job['payload_integrity_init'],(int)$job['payload_integrity_cursor']);$job['phase']='EDITORIAL_INIT';return;
        }
        if($phase==='EDITORIAL_INIT'){
            $init=PSTE_Repository::editorialMigrationInitialize((string)$job['job_uuid']);if(($init['contract']??'')!=='PSTE_EDITORIAL_MIGRATION_INIT_V1')throw new RuntimeException('PSTE_EDITORIAL_MIGRATION_INIT_INVALID');$job['editorial_init']=$init;$job['editorial_total']=(int)($init['topic_count']??0);$job['editorial_raw_cursor']=0;$job['editorial_raw_chain']=PSTE_Repository::editorialRawSourceChainSeed();$job['editorial_prepare_cursor']=0;$job['editorial_variant_cursor']=0;$job['editorial_variant_groups']=[];$job['editorial_finalize_cursor']=0;$job['editorial_variant_plan']=[];$job['sandbox_queue']=[];$job['sandbox_cursor']=0;$job['sandbox_total']=0;$job['sandbox_receipts']=[];$job['editorial_report']=['contract'=>PSTE_Editorializer::RULESET,'processed'=>0,'auto_resolved'=>0,'variants'=>0,'missing_target_category'=>0,'status_changes'=>0,'sandbox_required'=>0,'sandbox_admitted'=>0,'sandbox_external_admitted'=>0,'sandbox_internal_admitted'=>0,'structure_gap_admitted'=>0,'sandbox_candidate_failures_isolated'=>0,'sandbox_candidate_failure_codes'=>[]];$job['phase']=$job['editorial_total']>0?'EDITORIAL_RAW_BASELINE_BATCH':'EDITORIAL_VARIANT_PLAN';return;
        }
        if($phase==='EDITORIAL_RAW_BASELINE_BATCH'){
            $batch=PSTE_Repository::editorialMigrationRawBaselineBatch((int)$job['editorial_raw_cursor'],self::EDITORIAL_BATCH_SIZE,(string)$job['editorial_raw_chain']);if(($batch['contract']??'')!=='PSTE_EDITORIAL_RAW_BASELINE_BATCH_V1')throw new RuntimeException('PSTE_EDITORIAL_RAW_BASELINE_BATCH_INVALID');$job['editorial_raw_cursor']=(int)$batch['cursor'];$job['editorial_raw_chain']=(string)$batch['raw_source_chain_sha256'];if(!empty($batch['complete'])){$job['editorial_init']['raw_source_chain_sha256']=$job['editorial_raw_chain'];$job['phase']='EDITORIAL_PREPARE_BATCH';}return;
        }
        if($phase==='EDITORIAL_PREPARE_BATCH'){
            $batch=PSTE_Repository::editorialMigrationPrepareBatch((int)($job['editorial_prepare_cursor']??0),self::EDITORIAL_BATCH_SIZE,(string)$job['job_uuid']);if(($batch['contract']??'')!=='PSTE_EDITORIAL_MIGRATION_PREPARE_BATCH_V1')throw new RuntimeException('PSTE_EDITORIAL_MIGRATION_PREPARE_BATCH_INVALID');$job['editorial_prepare_cursor']=(int)$batch['cursor'];$job['editorial_total']=(int)$batch['total'];if(!empty($batch['complete']))$job['phase']='EDITORIAL_VARIANT_SCAN_BATCH';return;
        }
        if($phase==='EDITORIAL_VARIANT_SCAN_BATCH'){
            $batch=PSTE_Repository::editorialMigrationVariantScanBatch((int)($job['editorial_variant_cursor']??0),self::EDITORIAL_BATCH_SIZE,(string)$job['job_uuid']);if(($batch['contract']??'')!=='PSTE_EDITORIAL_VARIANT_SCAN_BATCH_V1')throw new RuntimeException('PSTE_EDITORIAL_VARIANT_SCAN_BATCH_INVALID');$job['editorial_variant_groups']=self::mergeVariantScanItems((array)$job['editorial_variant_groups'],(array)$batch['items']);$job['editorial_variant_cursor']=(int)$batch['cursor'];if(!empty($batch['complete']))$job['phase']='EDITORIAL_VARIANT_PLAN';return;
        }
        if($phase==='EDITORIAL_VARIANT_PLAN'){
            $plan=PSTE_Repository::editorialMigrationVariantPlanFromAccumulator((string)$job['job_uuid'],(array)$job['editorial_variant_groups'],(int)$job['editorial_total']);if(($plan['contract']??'')!=='PSTE_EDITORIAL_VARIANT_PLAN_V1')throw new RuntimeException('PSTE_EDITORIAL_VARIANT_PLAN_INVALID');$job['editorial_variant_plan']=$plan;$job['editorial_report']['variants']=(int)($plan['variant_count']??0);$job['editorial_finalize_cursor']=0;$job['phase']=$job['editorial_total']>0?'EDITORIAL_FINALIZE_BATCH':'EDITORIAL_CORE_VERIFY_FINAL';return;
        }
        if($phase==='EDITORIAL_FINALIZE_BATCH'){
            $batch=PSTE_Repository::editorialMigrationFinalizeBatch((int)($job['editorial_finalize_cursor']??0),self::EDITORIAL_BATCH_SIZE,(string)$job['job_uuid'],(array)$job['editorial_variant_plan']);if(($batch['contract']??'')!=='PSTE_EDITORIAL_MIGRATION_FINALIZE_BATCH_V1')throw new RuntimeException('PSTE_EDITORIAL_MIGRATION_FINALIZE_BATCH_INVALID');$report=(array)$job['editorial_report'];$queue=array_values((array)($job['sandbox_queue']??[]));
            foreach((array)($batch['contributions']??[]) as $c){$c=is_array($c)?$c:[];$report['processed']=(int)($report['processed']??0)+1;$report['auto_resolved']=(int)($report['auto_resolved']??0)+(int)($c['auto_resolved']??0);$report['missing_target_category']=(int)($report['missing_target_category']??0)+(int)($c['missing_target_category']??0);$report['status_changes']=(int)($report['status_changes']??0)+(int)($c['status_changes']??0);$report['sandbox_required']=(int)($report['sandbox_required']??0)+(int)($c['sandbox_required']??0);$q=is_array($c['queue_item']??null)?(array)$c['queue_item']:null;if($q){$exists=false;foreach($queue as $existing)if((string)($existing['pool_key']??'')===(string)($q['pool_key']??'')){$exists=true;break;}if(!$exists)$queue[]=$q;}}
            $job['editorial_report']=$report;$job['sandbox_queue']=$queue;$job['editorial_finalize_cursor']=(int)$batch['cursor'];if(!empty($batch['complete'])){$job['editorial_core_verify_cursor']=0;$job['editorial_core_verify_chain']=PSTE_Repository::editorialRawSourceChainSeed();$job['phase']='EDITORIAL_CORE_VERIFY_BATCH';}return;
        }
        if($phase==='EDITORIAL_CORE_VERIFY_BATCH'){
            $batch=PSTE_Repository::editorialMigrationVerifyBatch((int)$job['editorial_core_verify_cursor'],self::EDITORIAL_BATCH_SIZE,(string)$job['job_uuid'],(array)$job['editorial_variant_plan'],(string)$job['editorial_core_verify_chain']);if(($batch['contract']??'')!=='PSTE_EDITORIAL_VERIFY_BATCH_V1')throw new RuntimeException('PSTE_EDITORIAL_CORE_VERIFY_BATCH_INVALID');$job['editorial_core_verify_cursor']=(int)$batch['cursor'];$job['editorial_core_verify_chain']=(string)$batch['raw_source_chain_sha256'];if(!empty($batch['complete']))$job['phase']='EDITORIAL_CORE_VERIFY_FINAL';return;
        }
        if($phase==='EDITORIAL_CORE_VERIFY_FINAL'){
            $verify=PSTE_Repository::editorialMigrationVerifyComplete((array)$job['editorial_init'],(int)$job['editorial_core_verify_cursor'],(string)($job['editorial_core_verify_chain']?:PSTE_Repository::editorialRawSourceChainSeed()));$report=(array)$job['editorial_report'];$report['raw_keyword_invariant']='PASS';$report['raw_source_sha256']=(string)($verify['raw_source_sha256']??'');$report['raw_keyword_sha256']=(string)($verify['raw_source_sha256']??'');$report['raw_keyword_mirror_invariant']='PASS';$report['topic_count']=(int)($verify['topic_count']??0);$report['storage_invariant']='PASS';$queue=array_values((array)($job['sandbox_queue']??[]));$report['sandbox_queue_count']=count($queue);$report['sandbox_queue_sha256']=self::hash($queue);$job['editorial_report']=$report;$job['core_verify']=$verify;$job['sandbox_total']=count($queue);$job['sandbox_cursor']=0;if($queue)$job['phase']='SANDBOX_BATCH';else{$job['editorial_final_verify_cursor']=0;$job['editorial_final_verify_chain']=PSTE_Repository::editorialRawSourceChainSeed();$job['phase']='FINAL_TOPIC_VERIFY_BATCH';}return;
        }
        if($phase==='SANDBOX_BATCH'){
            $queue=array_values((array)($job['sandbox_queue']??[]));$cursor=max(0,(int)($job['sandbox_cursor']??0));if($cursor>=count($queue)){$job['editorial_final_verify_cursor']=0;$job['editorial_final_verify_chain']=PSTE_Repository::editorialRawSourceChainSeed();$job['phase']='FINAL_TOPIC_VERIFY_BATCH';return;}
            $slice=array_slice($queue,$cursor,self::SANDBOX_BATCH_SIZE);$items=[];foreach($slice as $q)$items[]=PSTE_Repository::sandboxAdmissionEnvelope((array)$q);
            $batch=PSTE_Semantic_Review_Sandbox::admitFromNormalPathBatch($items,(string)$job['job_uuid']);if(($batch['contract']??'')!=='PSTE_SANDBOX_MIGRATION_BATCH_V1'||(int)($batch['processed']??-1)!==count($items))throw new RuntimeException('PSTE_SANDBOX_MIGRATION_BATCH_INVALID');
            $job['editorial_report']=PSTE_Repository::mergeEditorialSandboxBatchReport((array)$job['editorial_report'],$batch,$items);$job['sandbox_receipts']=array_values(array_unique(array_merge((array)$job['sandbox_receipts'],array_values((array)($batch['receipts']??[])))));$job['sandbox_cursor']=$cursor+count($items);if((int)$job['sandbox_cursor']>=count($queue)){$job['editorial_final_verify_cursor']=0;$job['editorial_final_verify_chain']=PSTE_Repository::editorialRawSourceChainSeed();$job['phase']='FINAL_TOPIC_VERIFY_BATCH';}return;
        }
        if($phase==='FINAL_TOPIC_VERIFY_BATCH'){
            $batch=PSTE_Repository::editorialMigrationVerifyBatch((int)$job['editorial_final_verify_cursor'],self::EDITORIAL_BATCH_SIZE,(string)$job['job_uuid'],(array)$job['editorial_variant_plan'],(string)$job['editorial_final_verify_chain']);if(($batch['contract']??'')!=='PSTE_EDITORIAL_VERIFY_BATCH_V1')throw new RuntimeException('PSTE_EDITORIAL_FINAL_VERIFY_BATCH_INVALID');$job['editorial_final_verify_cursor']=(int)$batch['cursor'];$job['editorial_final_verify_chain']=(string)$batch['raw_source_chain_sha256'];if(!empty($batch['complete']))$job['phase']='FINAL_VERIFY';return;
        }
        if($phase==='FINAL_VERIFY'){
            $verify=PSTE_Repository::editorialMigrationVerifyComplete((array)$job['editorial_init'],(int)$job['editorial_final_verify_cursor'],(string)($job['editorial_final_verify_chain']?:PSTE_Repository::editorialRawSourceChainSeed()));$receiptAudit=PSTE_Semantic_Review_Sandbox::verifyMigrationAdmissionReceipts((array)($job['sandbox_receipts']??[]));$dataflowAudit=PSTE_Semantic_Review_Sandbox::verifyMigrationDataflow((array)($job['sandbox_receipts']??[]));$verify['sandbox_receipts']=$receiptAudit;$verify['sandbox_dataflow']=$dataflowAudit;if(!hash_equals((string)($job['core_verify']['raw_source_sha256']??''),(string)($verify['raw_source_sha256']??'')))throw new RuntimeException('PSTE_EDITORIAL_CORE_FINAL_VERIFY_DRIFT');
            if((string)$job['source_schema']!==$target){$migration=(array)($job['legacy']['identity_migration']??[]);$before=(array)($job['legacy']['before']??[]);if(!$migration||!$before)throw new RuntimeException('PSTE_SAFE_MIGRATION_LEGACY_EVIDENCE_MISSING');$job['legacy']['after']=PSTE_Repository::assertMigrationPreserved($before,$migration);}
            $job['final_verify']=$verify;$job['phase']='FINALIZE';return;
        }
        if($phase==='FINALIZE'){
            $report=(array)($job['editorial_report']??[]);$report['sandbox_candidate_failure_codes']=array_values(array_unique(array_filter(array_map('strval',(array)($report['sandbox_candidate_failure_codes']??[])))));$report['request_bounded_migration']='PASS';$report['payload_integrity']=(array)($job['payload_integrity_report']??[]);$report['sandbox_batches_completed']=(int)ceil(max(0,(int)($job['sandbox_total']??0))/self::SANDBOX_BATCH_SIZE);$report['final_verify']=(array)($job['final_verify']??[]);$job['editorial_report']=$report;
            $job['finalization']=PSTE_Plugin::finalizeSafeMigration($report,$job);$job['status']='COMPLETE';$job['phase']='COMPLETE';$job['completed_at_utc']=gmdate('c');$job['sandbox_queue']=[];$job['editorial_variant_groups']=[];return;
        }
        if($phase==='COMPLETE'){$job['status']='COMPLETE';return;}
        throw new RuntimeException('PSTE_SAFE_MIGRATION_PHASE_UNKNOWN_'.self::safeCode($phase));
    }

    /** Merge one bounded variant scan into a compact replay-safe accumulator. @return array<string,mixed> */
    private static function mergeVariantScanItems(array $groups,array $items): array {
        foreach($items as $item){if(!is_array($item)||empty($item['resolved']))continue;$intent=(string)($item['editorial_intent_key']??'');$pool=(string)($item['pool_key']??'');if($intent===''||$pool==='')continue;$sort=[(int)($item['identity_length']??0),(int)($item['row_id']??0)];$source=(string)($item['source_query']??'');$title=(string)($item['editorial_title']??'');
            if(!isset($groups[$intent])||!is_array($groups[$intent])){$groups[$intent]=['canonical_pool_key'=>$pool,'canonical_sort'=>$sort,'canonical_source_query'=>$source,'canonical_editorial_title'=>$title,'variant_pool_keys'=>[],'aliases'=>[]];continue;}
            $g=(array)$groups[$intent];$canonical=(string)($g['canonical_pool_key']??'');$variants=array_values((array)($g['variant_pool_keys']??[]));if($pool===$canonical||in_array($pool,$variants,true))continue;$oldSort=array_values((array)($g['canonical_sort']??[PHP_INT_MAX,PHP_INT_MAX]));$isBetter=[$sort[0],$sort[1]]<[(int)($oldSort[0]??PHP_INT_MAX),(int)($oldSort[1]??PHP_INT_MAX)];$aliases=array_values((array)($g['aliases']??[]));
            if($isBetter){if($canonical!=='')$variants[]=$canonical;foreach([(string)($g['canonical_source_query']??''),(string)($g['canonical_editorial_title']??'')] as $a)if($a!=='')$aliases[]=$a;$g['canonical_pool_key']=$pool;$g['canonical_sort']=$sort;$g['canonical_source_query']=$source;$g['canonical_editorial_title']=$title;}
            else{$variants[]=$pool;foreach([$source,$title] as $a)if($a!=='')$aliases[]=$a;}
            $g['variant_pool_keys']=array_values(array_unique(array_filter(array_map('strval',$variants),'strlen')));$g['aliases']=array_values(array_unique(array_filter(array_map('strval',$aliases),'strlen')));$groups[$intent]=$g;
        }
        return $groups;
    }

    /** @return array<string,mixed> */
    public static function publicState(?array $job=null): array {
        if($job===null)$job=self::current()??[];$total=max(0,(int)($job['sandbox_total']??0));$cursor=max(0,(int)($job['sandbox_cursor']??0));
        return ['contract'=>self::CONTRACT,'protocol'=>(string)($job['protocol']??''),'job_uuid'=>(string)($job['job_uuid']??''),'status'=>(string)($job['status']??'NOT_STARTED'),'phase'=>(string)($job['phase']??'NOT_STARTED'),'source_schema'=>(string)($job['source_schema']??''),'target_schema'=>(string)($job['target_schema']??''),'legacy_identity_progress'=>max(0,(int)($job['legacy']['identity_cursor']??0)),'legacy_identity_total'=>max(0,(int)($job['legacy']['identity_total']??0)),'payload_integrity_progress'=>max(0,(int)($job['payload_integrity_cursor']??0)),'payload_integrity_total'=>max(0,(int)($job['payload_integrity_total']??0)),'editorial_raw_progress'=>max(0,(int)($job['editorial_raw_cursor']??0)),'editorial_prepare_progress'=>max(0,(int)($job['editorial_prepare_cursor']??0)),'editorial_variant_progress'=>max(0,(int)($job['editorial_variant_cursor']??0)),'editorial_finalize_progress'=>max(0,(int)($job['editorial_finalize_cursor']??0)),'editorial_verify_progress'=>max((int)($job['editorial_core_verify_cursor']??0),(int)($job['editorial_final_verify_cursor']??0)),'editorial_total'=>max(0,(int)($job['editorial_total']??0)),'sandbox_progress'=>$cursor,'sandbox_total'=>$total,'last_error'=>(string)($job['last_error']??''),'last_error_phase'=>(string)($job['last_error_phase']??''),'started_at_utc'=>(string)($job['started_at_utc']??''),'updated_at_utc'=>(string)($job['updated_at_utc']??''),'completed_at_utc'=>(string)($job['completed_at_utc']??''),'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'textmachine_or_design_write_attempted'=>false];
    }

    /** @param array<string,mixed> $job */
    private static function save(array &$job): void {
        $job['contract']=self::CONTRACT;$job['protocol']=PSTE_SAFE_MIGRATION_PROTOCOL;$job['plugin_version']=PSTE_VERSION;$job['updated_at_utc']=gmdate('c');$job['production_handoff_attempted']=false;$job['article_or_taxonomy_write_attempted']=false;$job['textmachine_or_design_write_attempted']=false;unset($job['sha256']);$job['sha256']=self::hash($job);update_option(PSTE_OPTION_SAFE_MIGRATION_JOB,$job,false);$stored=get_option(PSTE_OPTION_SAFE_MIGRATION_JOB,[]);if(!is_array($stored)||!hash_equals((string)$job['sha256'],(string)($stored['sha256']??'')))throw new RuntimeException('PSTE_SAFE_MIGRATION_JOB_READBACK_MISMATCH');self::assertJob($stored);
    }

    /** @param array<string,mixed> $job */
    private static function assertJob(array $job): void {if(($job['contract']??'')!==self::CONTRACT)throw new RuntimeException('PSTE_SAFE_MIGRATION_JOB_CONTRACT_INVALID');$declared=(string)($job['sha256']??'');$copy=$job;unset($copy['sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(self::hash($copy),$declared))throw new RuntimeException('PSTE_SAFE_MIGRATION_JOB_HASH_INVALID');}

    private static function acquireStepLock(string $jobUuid): string {
        $token=hash('sha256',$jobUuid.'|'.microtime(true).'|'.(function_exists('wp_generate_uuid4')?wp_generate_uuid4():uniqid('',true)));$payload=['contract'=>'PSTE_SAFE_MIGRATION_STEP_LOCK_V1','job_uuid'=>$jobUuid,'token'=>$token,'expires_at'=>time()+self::STEP_LOCK_TTL];
        if(add_option(PSTE_OPTION_SAFE_MIGRATION_STEP_LOCK,$payload,'',false))return $token;$old=get_option(PSTE_OPTION_SAFE_MIGRATION_STEP_LOCK,[]);
        if(is_array($old)&&(int)($old['expires_at']??0)<time()){if(get_option(PSTE_OPTION_SAFE_MIGRATION_STEP_LOCK,[])===$old)delete_option(PSTE_OPTION_SAFE_MIGRATION_STEP_LOCK);if(add_option(PSTE_OPTION_SAFE_MIGRATION_STEP_LOCK,$payload,'',false))return $token;}
        throw new RuntimeException('PSTE_SAFE_MIGRATION_STEP_ALREADY_RUNNING');
    }
    private static function releaseStepLock(string $token): void {try{$old=get_option(PSTE_OPTION_SAFE_MIGRATION_STEP_LOCK,[]);if(is_array($old)&&hash_equals($token,(string)($old['token']??'')))delete_option(PSTE_OPTION_SAFE_MIGRATION_STEP_LOCK);}catch(Throwable $e){}}

    private static function hash($value): string {return hash('sha256',self::json(self::canonicalize($value)));}
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
    private static function json($v): string {$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($j))throw new RuntimeException('PSTE_SAFE_MIGRATION_JSON_FAILED');return $j;}
    private static function safeCode(string $v): string {$v=strtoupper(trim($v));$v=(string)preg_replace('/[^A-Z0-9_:\-]+/','_',$v);return substr($v!==''?$v:'PSTE_SAFE_MIGRATION_FAILED',0,180);}
}
