# Portal SEO Themenengine 0.32.0

## Scope

Hardening der bereits isolierten Titelstufe ohne Änderung an Textmaschine, Design, Kategorien, Slot-Identität oder Exact-Five-Vertrag.

## Änderungen

- Nicht-FAQ-Titel werden hart blockiert, wenn die vom Titelgenerator hinzugefügte Oberfläche neben der bereits gebundenen Artikelart eine widersprechende starke Artikelart-Semantik erzeugt. Wörter innerhalb des unveränderlichen Zielkeywords werden dabei nicht neu als Routing-/Typautorität interpretiert.
- Sicherheitstitel verwenden eine natürliche, von der bestehenden Sicherheit-Ontologie erkannte Oberfläche: `Gefahren erkennen und vermeiden`.
- Übungs-Titel verwenden eine intent-sichtbare, lesbare Oberfläche `Übungen für das Training` statt der sachlich schiefen Konstruktion `mit Übungen trainieren`.
- Natürliche `Wie <Verb> ich/man ...?`-Fragen werden als gültige FAQ-Satzoberfläche erkannt, ohne telegraphische `Wie X installieren?`-Fragmente freizugeben.
- Der bereits vorhandene Anwendung-Intent wird beim semantischen Familien-Probe wie die übrigen vorhandenen Artikelarten als Intent-Signal entfernt. Die Anwendung-Typregeln selbst bleiben unverändert; dadurch werden keine neuen Wort→Typ- oder Wort→Slot-Regeln eingeführt.
- Safe-Migration-Protokoll und Editorializer-Ruleset bleiben unverändert, da diese Korrektur keine gespeicherten Zuordnungs-/Slotdaten migriert.

## Unverändert

- PPM/Textmaschine 6.7.9
- PSERC/Compiler 0.16.0
- Exact-Five-Handoff
- Kategorie-/Slot-/canonical_article_id-Logik
- Text-, HTML-, Format- und Designlogik
