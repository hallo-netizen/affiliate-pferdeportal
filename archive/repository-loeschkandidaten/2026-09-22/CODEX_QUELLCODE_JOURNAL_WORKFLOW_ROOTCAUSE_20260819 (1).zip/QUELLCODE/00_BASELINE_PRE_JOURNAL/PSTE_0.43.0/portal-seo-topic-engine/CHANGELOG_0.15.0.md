# 0.15.0 – Evidence before internal routing

## Ursache
V69 behandelte lokale Portalbegriffe als fertigen Relevanzbeweis. Dadurch konnten fachlich völlig unterschiedliche, vom Hauptmatcher blockierte Longtails vor einer unabhängigen Relevanzprüfung automatisch als `STRUCTURE_GAP` oder `MATCHER_REVIEW` erscheinen. Die lokale Testmatrix bestätigte diese Annahme selbst und war deshalb als fachliches Abnahmetor ungeeignet.

## Korrektur
- Jeder aktuelle `NEWLY_BLOCKED`-Datensatz wird verlustfrei erhalten und zunächst `PENDING_EXTERNAL_RELEVANCE`.
- Portalbezug, Familiennähe, Ausschlüsse und Suchvolumen bleiben vollständig gespeicherte Diagnoseevidenz, dürfen aber keine Portalrelevanz entscheiden.
- Keine Familie, Kategorie oder Titelprobe wird vor `RELEVANT_FOR_PORTAL` erzeugt.
- Erst eine getrennte externe Relevanzentscheidung darf den internen Sandbox-Planer freigeben.
- `RELEVANT_FOR_PORTAL` + keine reale nahe Familie => `STRUCTURE_GAP`.
- `RELEVANT_FOR_PORTAL` + reale nahe, aber vom Hauptgate abgelehnte Familie => `MATCHER_REVIEW`; diagnostische Kategorie-/Titelprobe erlaubt, aber niemals als freigabereifer Vorschlag.
- `UNCERTAIN_REVIEW` und `NOT_RELEVANT_FOR_PORTAL` bleiben erhalten und erzeugen keinen internen Vorschlag.
- Fehlende positive SERP-Evidenz wird niemals automatisch als negativ interpretiert.
- Positive automatische externe Relevanz benötigt neben dem portalweit abgeleiteten Themenanker zusätzlich redaktionelle Scope-Evidenz aus der realen Taxonomiestruktur; der Portalbegriff allein reicht nicht.
- Policy-/Bindingwechsel archivieren vorhandene Reviewevidenz statt Datensätze zu löschen.
- Kein Sandbox-Pfad erzeugt einen Produktions-Handoff.

## Hauptregel 1
Keine Änderung an Textmaschine/PPM/Compiler, normalem Hauptmatcher, normaler Familienidentität, Normalizer, produktiver Titelpipeline, Kannibalisierung, bestehenden Beiträgen/Entwürfen, HTML/CSS oder deren Metadaten/Terms.
