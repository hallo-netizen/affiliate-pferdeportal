<?php
if (!defined('ABSPATH')) { return; }

if (!class_exists('PSTE_Provider_Exception')) {
    final class PSTE_Provider_Exception extends RuntimeException {
        /** @var array<string,mixed> */
        private array $safeDetails;
        /** @param array<string,mixed> $safeDetails */
        public function __construct(string $machineCode,array $safeDetails=[]) {
            parent::__construct($machineCode);
            $this->safeDetails=$safeDetails;
        }
        /** @return array<string,mixed> */
        public function safeDetails(): array { return $this->safeDetails; }
    }
}

final class PSTE_DataForSEO_Client {
    private const ALLOWLIST = [
        'GET:/v3/appendix/user_data',
        'GET:/v3/dataforseo_labs/locations_and_languages',
        'GET:/v3/dataforseo_labs/status',
        'POST:/v3/dataforseo_labs/google/keyword_suggestions/live',
        'POST:/v3/dataforseo_labs/google/related_keywords/live',
        'POST:/v3/dataforseo_labs/google/keyword_ideas/live',
        'POST:/v3/serp/google/organic/live/advanced',
    ];

    private string $baseUrl;
    private string $login;
    private string $password;

    public function __construct(string $environment = 'sandbox') {
        $credentials = PSTE_Credentials::resolve();
        $this->login = $credentials['login'];
        $this->password = $credentials['password'];
        $this->baseUrl = $environment === 'production' ? 'https://api.dataforseo.com' : 'https://sandbox.dataforseo.com';
    }

    public static function endpointAllowed(string $method, string $path): bool {
        $key = strtoupper($method) . ':' . $path;
        if (in_array($key, self::ALLOWLIST, true)) { return true; }
        return false;
    }

    public function request(string $method, string $path, ?array $payload = null): array {
        return $this->requestWithPolicy($method,$path,$payload,true);
    }

    private function requestWithPolicy(string $method,string $path,?array $payload,bool $allowSafeRetry): array {
        $method = strtoupper($method);
        if (!self::endpointAllowed($method, $path)) { throw new RuntimeException('PSTE_ENDPOINT_NOT_ALLOWLISTED'); }
        if ($this->login === '' || $this->password === '') { throw new RuntimeException('PSTE_CREDENTIALS_MISSING'); }
        $args = [
            'method' => $method,
            'timeout' => 45,
            'redirection' => 0,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode($this->login . ':' . $this->password),
                'Content-Type' => 'application/json',
            ],
        ];
        if ($payload !== null) { $args['body'] = wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); }
        $attemptLimit=$allowSafeRetry?2:1;
        $retryKnownCost=0.0;
        for ($attempt = 1; $attempt <= $attemptLimit; $attempt++) {
            $response = wp_remote_request($this->baseUrl . $path, $args);
            if (is_wp_error($response)) {
                $providerMessage=method_exists($response,'get_error_message')?(string)$response->get_error_message():'';
                throw new PSTE_Provider_Exception('PSTE_PROVIDER_TRANSPORT_OUTCOME_UNKNOWN',[
                    'provider_message'=>self::safeProviderMessage($providerMessage),
                    'method'=>$method,'path'=>$path,'attempt'=>$attempt,
                ]);
            }
            $httpCode = (int)wp_remote_retrieve_response_code($response);
            if ($allowSafeRetry && in_array($httpCode, [429, 500, 503], true) && $attempt === 1) { usleep(250000); continue; }
            $rawBody=(string)wp_remote_retrieve_body($response);
            $body = json_decode($rawBody, true);
            if (!is_array($body)) {
                throw new PSTE_Provider_Exception('PSTE_PROVIDER_RESPONSE_INVALID_JSON',[
                    'http_code'=>$httpCode,'method'=>$method,'path'=>$path,
                    'response_sha256'=>hash('sha256',$rawBody),
                ]);
            }
            try {
                $validated=self::validateResponse($body, $httpCode);
                if($retryKnownCost>0)$validated['_pste_retry_known_cost_usd']=round($retryKnownCost,6);
                return $validated;
            } catch (PSTE_Provider_Exception $e) {
                if ($allowSafeRetry && $attempt === 1 && in_array($e->getMessage(), ['PSTE_PROVIDER_TASK_ERROR_40101','PSTE_PROVIDER_TASK_ERROR_40103','PSTE_PROVIDER_TASK_ERROR_50401'], true)) {
                    $d=$e->safeDetails();$retryKnownCost+=max(0.0,(float)($d['response_cost']??0.0));
                    usleep(500000);
                    continue;
                }
                if($retryKnownCost>0){$d=$e->safeDetails();$d['retry_known_cost_usd']=round($retryKnownCost,6);throw new PSTE_Provider_Exception((string)$e->getMessage(),$d);}
                throw $e;
            }
        }
        throw new RuntimeException('PSTE_PROVIDER_REQUEST_POLICY_EXHAUSTED');
    }

    public static function validateResponse(array $body, int $httpCode): array {
        if ($httpCode < 200 || $httpCode >= 300) {
            throw new PSTE_Provider_Exception('PSTE_PROVIDER_HTTP_ERROR_' . $httpCode,[
                'http_code'=>$httpCode,
                'provider_status_code'=>(int)($body['status_code']??0),
                'provider_message'=>self::safeProviderMessage((string)($body['status_message']??'')),
                'response_cost'=>(float)($body['cost']??0.0),
                'response_sha256'=>hash('sha256',wp_json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),
            ]);
        }
        $generalCode = (int)($body['status_code'] ?? 0);
        if ($generalCode !== 20000) {
            throw new PSTE_Provider_Exception('PSTE_PROVIDER_GENERAL_ERROR_' . $generalCode,[
                'http_code'=>$httpCode,'provider_status_code'=>$generalCode,
                'provider_message'=>self::safeProviderMessage((string)($body['status_message']??'')),
                'tasks_count'=>(int)($body['tasks_count']??count((array)($body['tasks']??[]))),
                'tasks_error'=>(int)($body['tasks_error']??0),
                'response_cost'=>(float)($body['cost']??0.0),
                'response_sha256'=>hash('sha256',wp_json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),
            ]);
        }
        foreach (array_values((array)($body['tasks'] ?? [])) as $index=>$task) {
            $code = (int)($task['status_code'] ?? 0);
            if ($code !== 20000) {
                throw new PSTE_Provider_Exception('PSTE_PROVIDER_TASK_ERROR_' . $code,[
                    'http_code'=>$httpCode,'provider_status_code'=>$code,
                    'provider_message'=>self::safeProviderMessage((string)($task['status_message']??'')),
                    'task_index'=>$index,
                    'tasks_count'=>(int)($body['tasks_count']??count((array)($body['tasks']??[]))),
                    'tasks_error'=>(int)($body['tasks_error']??0),
                    'response_cost'=>(float)($body['cost']??0.0),
                    'response_sha256'=>hash('sha256',wp_json_encode($body,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),
                ]);
            }
        }
        return $body;
    }

    private static function safeProviderMessage(string $message): string {
        $message=preg_replace('/[\x00-\x1F\x7F]+/u',' ',trim($message))??'';
        $message=preg_replace('/\s+/u',' ',$message)??$message;
        return function_exists('mb_substr')?mb_substr($message,0,240,'UTF-8'):substr($message,0,240);
    }


    public function requestCached(string $method, string $path, ?array $payload = null, int $ttl = 86400): array {
        $method=strtoupper($method);
        [$cacheKey,$requestFingerprint]=$this->cacheIdentity($method,$path,$payload);
        $cached=$this->readCachedEnvelope($cacheKey,$requestFingerprint);
        if($cached!==null)return $cached;
        $rawResponse=$this->request($method,$path,$payload);$retryKnownCost=max(0.0,(float)($rawResponse['_pste_retry_known_cost_usd']??0.0));
        $response=self::externalResponse($rawResponse);
        $retrievedAt=gmdate('c');
        $responseHash=self::responseSha256($response);
        $envelope=[
            'contract'=>'PSTE_PROVIDER_CACHE_ENVELOPE_V1',
            'request_fingerprint'=>$requestFingerprint,
            'retrieved_at_utc'=>$retrievedAt,
            'response_sha256'=>$responseHash,
            'response'=>$response,
        ];
        set_transient($cacheKey,$envelope,max(60,$ttl));
        $decorated=self::decorateResponse($response,false,$retrievedAt,$responseHash);if($retryKnownCost>0)$decorated['_pste_retry_known_cost_usd']=round($retryKnownCost,6);return $decorated;
    }

    /** Read an already validated identical response without sending a provider request. */
    public function peekCached(string $method,string $path,?array $payload=null): ?array {
        [$cacheKey,$requestFingerprint]=$this->cacheIdentity(strtoupper($method),$path,$payload);
        return $this->readCachedEnvelope($cacheKey,$requestFingerprint);
    }

    /** @return array{0:string,1:string} */
    private function cacheIdentity(string $method,string $path,?array $payload): array {
        $requestFingerprint=hash('sha256',self::json([
            'base_url'=>$this->baseUrl,
            'account_fingerprint'=>hash('sha256',$this->login),
            'method'=>$method,
            'path'=>$path,
            'payload'=>$payload,
        ]));
        return ['pste_api_'.$requestFingerprint,$requestFingerprint];
    }

    private function readCachedEnvelope(string $cacheKey,string $requestFingerprint): ?array {
        $cached=get_transient($cacheKey);
        if(is_array($cached)&&self::validCacheEnvelope($cached,$requestFingerprint)){
            return self::decorateResponse((array)$cached['response'],true,(string)$cached['retrieved_at_utc'],(string)$cached['response_sha256']);
        }
        if($cached!==false&&$cached!==null&&function_exists('delete_transient'))delete_transient($cacheKey);
        return null;
    }

    /** Provider payload without local cache/provenance metadata. */
    public static function externalResponse(array $response): array {
        foreach(array_keys($response) as $key){
            if(is_string($key)&&str_starts_with($key,'_pste_'))unset($response[$key]);
        }
        return $response;
    }

    public static function responseSha256(array $response): string {
        return hash('sha256',self::json(self::externalResponse($response)));
    }

    public static function retrievedAtUtc(array $response): string {
        $value=(string)($response['_pste_retrieved_at_utc']??'');
        return $value!==''&&strtotime($value)!==false?$value:gmdate('c');
    }

    public static function cacheHit(array $response): bool {
        return ($response['_pste_cache_hit']??false)===true;
    }

    private static function validCacheEnvelope(array $cached,string $requestFingerprint): bool {
        if(($cached['contract']??'')!=='PSTE_PROVIDER_CACHE_ENVELOPE_V1')return false;
        if(!hash_equals($requestFingerprint,(string)($cached['request_fingerprint']??'')))return false;
        $retrieved=(string)($cached['retrieved_at_utc']??'');
        $declared=(string)($cached['response_sha256']??'');
        $response=$cached['response']??null;
        if($retrieved===''||strtotime($retrieved)===false||!is_array($response)||!preg_match('/^[a-f0-9]{64}$/',$declared))return false;
        return hash_equals($declared,self::responseSha256($response));
    }

    private static function decorateResponse(array $response,bool $cacheHit,string $retrievedAt,string $responseHash): array {
        $response=self::externalResponse($response);
        $response['_pste_cache_hit']=$cacheHit;
        $response['_pste_retrieved_at_utc']=$retrievedAt;
        $response['_pste_response_sha256']=$responseHash;
        $response['_pste_cache_contract']='PSTE_PROVIDER_CACHE_ENVELOPE_V1';
        return $response;
    }

    private static function json($value): string {
        $json=wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
        if(!is_string($json))throw new RuntimeException('PSTE_PROVIDER_JSON_ENCODE_FAILED');
        return $json;
    }

    public function keywordSuggestions(string $keyword, string $location, string $language, int $limit = 100): array {
        return $this->requestCached('POST','/v3/dataforseo_labs/google/keyword_suggestions/live',self::keywordSuggestionsPayload($keyword,$location,$language,$limit));
    }
    public function peekKeywordSuggestions(string $keyword,string $location,string $language,int $limit=100): ?array {
        return $this->peekCached('POST','/v3/dataforseo_labs/google/keyword_suggestions/live',self::keywordSuggestionsPayload($keyword,$location,$language,$limit));
    }

    public function relatedKeywords(string $keyword, string $location, string $language, int $limit = 100): array {
        return $this->requestCached('POST','/v3/dataforseo_labs/google/related_keywords/live',self::relatedKeywordsPayload($keyword,$location,$language,$limit));
    }
    public function peekRelatedKeywords(string $keyword,string $location,string $language,int $limit=100): ?array {
        return $this->peekCached('POST','/v3/dataforseo_labs/google/related_keywords/live',self::relatedKeywordsPayload($keyword,$location,$language,$limit));
    }

    public function keywordIdeas(array $keywords, string $location, string $language, int $limit = 100): array {
        return $this->requestCached('POST','/v3/dataforseo_labs/google/keyword_ideas/live',self::keywordIdeasPayload($keywords,$location,$language,$limit));
    }
    public function peekKeywordIdeas(array $keywords,string $location,string $language,int $limit=100): ?array {
        return $this->peekCached('POST','/v3/dataforseo_labs/google/keyword_ideas/live',self::keywordIdeasPayload($keywords,$location,$language,$limit));
    }

    /** Real Google organic SERP evidence used only by the isolated Semantic Review Sandbox. */
    public function googleOrganicSerp(string $keyword,string $location,string $language,int $depth=10): array {
        return $this->requestCached('POST','/v3/serp/google/organic/live/advanced',self::googleOrganicSerpPayload($keyword,$location,$language,$depth),21600);
    }
    public function peekGoogleOrganicSerp(string $keyword,string $location,string $language,int $depth=10): ?array {
        return $this->peekCached('POST','/v3/serp/google/organic/live/advanced',self::googleOrganicSerpPayload($keyword,$location,$language,$depth));
    }
    private static function googleOrganicSerpPayload(string $keyword,string $location,string $language,int $depth): array {
        $keyword=trim($keyword);if($keyword==='')throw new RuntimeException('PSTE_SERP_KEYWORD_MISSING');
        return [[
            'keyword'=>$keyword,'location_name'=>$location,'language_name'=>$language,
            'device'=>'desktop','os'=>'windows','depth'=>10,
        ]];
    }

    /** @return list<array<string,mixed>> */
    public static function extractOrganicResults(array $response): array {
        $out=[];
        foreach((array)($response['tasks']??[]) as $task){
            foreach((array)($task['result']??[]) as $result){
                foreach((array)($result['items']??[]) as $item){
                    if(!is_array($item)||(string)($item['type']??'')!=='organic')continue;
                    $rank=(int)($item['rank_absolute']??$item['rank_group']??0);
                    $out[]=[
                        'rank'=>$rank,'domain'=>trim((string)($item['domain']??'')),
                        'url'=>trim((string)($item['url']??'')),'title'=>trim((string)($item['title']??'')),
                        'description'=>trim((string)($item['description']??'')),
                        'breadcrumb'=>trim((string)($item['breadcrumb']??'')),
                    ];
                }
            }
        }
        usort($out,static fn($a,$b)=>[(int)($a['rank']??0),(string)($a['domain']??'')]<=>[(int)($b['rank']??0),(string)($b['domain']??'')]);
        return array_slice($out,0,10);
    }

    public static function responseCostUsd(array $response): float {
        if(self::cacheHit($response))return 0.0;
        $external=self::externalResponse($response);$cost=(float)($external['cost']??0.0);
        if($cost<=0.0){foreach((array)($external['tasks']??[]) as $task)$cost+=(float)($task['cost']??0.0);}
        $cost+=max(0.0,(float)($response['_pste_retry_known_cost_usd']??0.0));
        return round(max(0.0,$cost),6);
    }

    /** Alias kept for sandbox/job tests; responseCostUsd is now retry-cost complete. */
    public static function knownRequestCostUsd(array $response): float {return self::responseCostUsd($response);}

    private static function keywordSuggestionsPayload(string $keyword,string $location,string $language,int $limit): array {
        return [['keyword'=>$keyword,'location_name'=>$location,'language_name'=>$language,'limit'=>min(1000,max(1,$limit)),'include_serp_info'=>false]];
    }
    private static function relatedKeywordsPayload(string $keyword,string $location,string $language,int $limit): array {
        return [['keyword'=>$keyword,'location_name'=>$location,'language_name'=>$language,'depth'=>1,'limit'=>min(1000,max(1,$limit)),'include_seed_keyword'=>true]];
    }
    private static function keywordIdeasPayload(array $keywords,string $location,string $language,int $limit): array {
        $keywords=array_values(array_slice(array_unique(array_filter(array_map('strval',$keywords))),0,200));
        if(!$keywords)throw new RuntimeException('PSTE_KEYWORD_IDEAS_SEEDS_MISSING');
        return [['keywords'=>$keywords,'location_name'=>$location,'language_name'=>$language,'limit'=>min(1000,max(1,$limit)),'include_serp_info'=>false,'include_clickstream_data'=>false]];
    }

    public static function extractKeywords(array $response): array {
        // Preserve every provider row exactly as returned. Canonical grouping happens
        // only after raw values and individual observations have been persisted.
        $out=[];
        foreach (($response['tasks']??[]) as $task) {
            foreach (($task['result']??[]) as $result) {
                foreach (($result['items']??[]) as $item) {
                    $keyword=(string)($item['keyword_data']['keyword']??$item['keyword']??'');
                    if(trim($keyword)==='' || PSTE_Normalizer::exactTopicIdentityText($keyword)==='')continue;
                    $info=$item['keyword_data']['keyword_info']??$item['keyword_info']??[];
                    $out[]=[
                        'keyword'=>$keyword,
                        'search_volume'=>$info['search_volume']??null,
                        'monthly_searches'=>$info['monthly_searches']??[],
                        'competition'=>$info['competition']??null,
                        'cpc'=>$info['cpc']??null,
                    ];
                }
            }
        }
        return $out;
    }


    public static function extractAccountStatus(array $response): array {
        $result=$response['tasks'][0]['result'][0]??[];
        return [
            'balance_usd'=>isset($result['money']['balance'])?(float)$result['money']['balance']:null,
            'total_deposited_usd'=>isset($result['money']['total'])?(float)$result['money']['total']:null,
            'account_pricing_present'=>!empty($result['price']),
            'captured_response_sha256'=>self::responseSha256($response)
        ];
    }

    public static function sanitizedSummary(array $response): array {
        $external=self::externalResponse($response);
        return [
            'status_code'=>(int)($external['status_code']??0),
            'status_message'=>(string)($external['status_message']??''),
            'provider_reported_cost'=>(float)($external['cost']??0),
            'incremental_cost'=>self::cacheHit($response)?0.0:(float)($external['cost']??0),
            'cache_hit'=>self::cacheHit($response),
            'retrieved_at_utc'=>self::retrievedAtUtc($response),
            'tasks_count'=>(int)($external['tasks_count']??0),
            'tasks_error'=>(int)($external['tasks_error']??0),
            'response_sha256'=>self::responseSha256($external),
        ];
    }
}
