# Änderungsnachweis 0.7.2-staging

## Anlass

Der erste Runtime-Batch von 0.7.1 endete mit `Portalabgleich BLOCKED`, `0 von 22 Themen`, während alle 22 Themen in der Ampel pauschal Rot erschienen. Dadurch wurde ein technischer Systemfehler fälschlich wie ein fachlicher manueller Prüfbedarf dargestellt. Zusätzlich zeigte die Oberfläche den gespeicherten Fehlercode nicht an.

## Verbindliche Korrekturen

1. Die Ampel beantwortet nur noch die Frage, ob eine fachliche menschliche Entscheidung nötig ist.
2. Der technische Systemzustand `CURRENT`, `PENDING` oder `BLOCKED` wird getrennt angezeigt.
3. Ein technischer Block sperrt Planung fail-closed, verändert aber nicht die fachliche Ampelfarbe.
4. Der Portalabgleich verwendet einen reinen, schreibfreien Evaluator vor jeder Datenbankänderung.
5. Ein Batch läuft transaktional; jeder DELETE-, INSERT- und UPDATE-Rückgabewert wird geprüft.
6. Der endgültige `context_state` wird nach dem UPDATE nochmals aus der Datenbank gelesen und verifiziert.
7. Bei jedem Fehler erfolgt Rollback; vorhandene Kontextzuordnungen bleiben erhalten.
8. Der exakte Fehlercode wird im Portalabgleich und in der Fehlermeldung sichtbar.
9. Ein blockierter Batch erzeugt keine irreführende Erfolgsmeldung.
10. Beim Update von 0.7.1 wird ein vorhandener aktueller Baseline-Snapshot automatisch in einen neuen PENDING-Batch überführt; bei veraltetem Baseline-Snapshot wird nachvollziehbar `PSTE_BASELINE_RECAPTURE_REQUIRED` gesetzt.
11. Alle kritischen Datenbank-Schreibpfade für Lauf, Kandidat, Themenidentität, Themenpool, Historie, manuelle Entscheidung, Merge-Kandidaten, Kosten, Evidenz und GSC werden auf Fehler geprüft.
12. Kandidat und globales Thema, manuelle Entscheidung und Historie sowie GSC-Austausch laufen jeweils transaktional.
13. Eine erzeugte Themen-UUID darf nie zurückgegeben werden, bevor ihre Persistenz aus der Datenbank zurückgelesen wurde.
14. Eine fehlgeschlagene oder nur scheinbar erfolgreiche Speicherung führt fail-closed zu einem konkreten Fehlercode.

## Regression

- Die Frage `Welche Regendecken haben eine Abschwitzfunktion für Pferde?` bleibt fachlich `PASS`, Rolle `ARTICLE_TOPIC`, Ampel Grün. Bei blockiertem Systemkontext bleibt die Ampel Grün, während Planung getrennt auf `BLOCKED` steht.
- Keine Artikel-, Kategorien-, URL-, Yoast-, Redaktionsplan- oder Produktionsschreibzugriffe.
- Keine kostenpflichtigen API-Aufrufe während Migration oder Portalabgleich.
