# 0.24.0 – request-bounded Safe Migration / Ursachenreparatur

Auslöser: realer WordPress-`Gateway Timeout` beim 0.23.0-Rebuild. Der Fehler wurde nicht als Timeout-Sonderfall gepatcht, sondern der gesamte Upgrade-/Migration-/Sandbox-/Retry-Lifecycle neu gegen den End-to-End-Vertrag abgesichert.

- Sichere Migration ist als dauerhafter, request-bounded Job mit Cursor, kurzem Step-Lock, explizitem Resume und versioniertem Abschlussprotokoll umgesetzt.
- Current-Schema und Legacy-Schema durchlaufen vor Semantik denselben bounded Payload-Integrity-/Recovery-Gate.
- 104er Editorial-Rebuild wird vollständig in bounded Rohbaseline-, Prepare-, Variant-Scan-, Finalize- und Verify-Seiten verarbeitet; kein aktiver Migrationsschritt lädt den kompletten Topic-Pool.
- Sandbox-Aufnahmen laufen batchweise, idempotent und mit Migration-Receipts; kandidatenlokale fachliche Sandboxfehler werden isoliert, globale Raw-/Storage-/Relationsfehler bleiben fail-closed.
- Relevanz bleibt erste fachliche Autorität; ungelöste Familien dürfen nach bewiesener Relevanz in die interne Sandbox, ohne künstlichen `family_key`-Zwang.
- Historische Derived-State-Felder sind keine aktuelle Autorität; aktuelle Pfad-/Variant-/Statuszustände werden neu erzeugt.
- Recovery-Quarantäne ist vom fachlichen Workflow getrennt; beschädigte Originalbytes werden forensisch erhalten und nie an Compiler/Textmaschine weitergereicht.
- Finalverify prüft reale Verträge, Rohkeyword-Invarianz, Mirrors, Storage/Relations und Sandbox-Receipts.
- Regel 1 unverändert: keine Post-/Postmeta-/Taxonomie-/Design-/Inhaltswrites und kein Zugriff auf Text-/Produktionsmaschine; einzig mögliche spätere Schnittstelle bleiben `title`, `target_keyword`, `category`, `article_type`, `plan_slot`.

Status dieser Version vor Liveinstallation: `LOCAL_FIXTURE_HARNESS_PACKAGE_PASS / CLAUDE_ENDAUDIT_PENDING / NOT_REAL_WORDPRESS_E2E`.
