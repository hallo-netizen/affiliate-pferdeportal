<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Plugin {
    private const TARGET_SCHEMA='12';
    private const SUPPORTED_SOURCE_SCHEMAS=['','6','7','8','9','10','11','12'];
    private static bool $migrationAttempted=false;
    private static string $migrationStage='NOT_STARTED';

    public static function init(): void {
        // The plugin is not considered READY until the current editorial metadata
        // ruleset is durably applied. This is intentionally independent of the
        // numeric DB schema because editorial metadata contracts may change
        // without a schema-version bump.
        // Request bootstrap is registration-only. All migration/cleanup/scheduling
        // writes are deferred to explicit lifecycle contexts below.

        // Admin GET is registration/read-only only. Migration, cleanup and scheduling
        // are owned exclusively by the explicit manual migration POST.
        if (function_exists('is_admin') && is_admin()) {
            PSTE_Admin::init();
        }

        add_action(PSTE_CONTEXT_CRON_HOOK,['PSTE_Context_Refresh','processCron']);
        add_action(PSTE_SANDBOX_INTERNAL_RECHECK_CRON_HOOK,['PSTE_Normal_Reentry_Coordinator','processCron']);
        add_action(PSTE_EDITORIAL_METADATA_REBUILD_CRON_HOOK,['PSTE_Normal_Reentry_Coordinator','processEditorialMetadataRebuild']);

    }

    /** Legacy callable retained for compatibility; intentionally read/write dormant. */
    public static function maybeRunOwnAdminMaintenance(): void { return; }

    private static function ensureRecurringSchedules(): void {
        if(!self::isReady())return;
        if(function_exists('wp_next_scheduled')&&function_exists('wp_schedule_event')&&!wp_next_scheduled(PSTE_SANDBOX_INTERNAL_RECHECK_CRON_HOOK)){
            wp_schedule_event(time()+3600,'daily',PSTE_SANDBOX_INTERNAL_RECHECK_CRON_HOOK);
        }
        if(class_exists('PSTE_Sandbox_Maintenance_Health')&&function_exists('wp_next_scheduled')){
            PSTE_Sandbox_Maintenance_Health::recordScheduleState((bool)wp_next_scheduled(PSTE_SANDBOX_INTERNAL_RECHECK_CRON_HOOK),'ENSURE_RECURRING_SCHEDULES');
        }
    }

    private static function cleanupRemovedLiveWorkflow(): void {
        // One-time, lossless archive of obsolete live-SERP and V1 research state.
        // Only SEO-engine options/hooks are touched; posts, terms, content,
        // design and the production machine are never accessed.
        try {
            $marker='pste_0101_archive_removed_workflows_v1';
            if((string)get_option($marker,'')==='COMPLETE')return;
            $keys=['pste_last_live_check_v1','pste_live_evidence_registry_v1','pste_live_serp_job_v1','pste_live_serp_worker_lock_v1','pste_active_longtail_research_job_v1','pste_longtail_research_step_lock_v1'];
            $values=[];
            foreach($keys as $key){$value=get_option($key,null);if($value!==null&&$value!==false&&$value!=='')$values[$key]=$value;}
            $archive=['contract'=>'PSTE_LEGACY_WORKFLOW_ARCHIVE_V1','archived_at_utc'=>gmdate('c'),'source_version'=>(string)PSTE_VERSION,'values'=>$values];
            $archive['sha256']=hash('sha256',wp_json_encode($archive,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION));
            update_option(PSTE_OPTION_LEGACY_LIVE_ARCHIVE,$archive,false);
            $stored=get_option(PSTE_OPTION_LEGACY_LIVE_ARCHIVE,[]);
            if(!is_array($stored)||!hash_equals((string)$archive['sha256'],(string)($stored['sha256']??'')))return;
            foreach($keys as $key)delete_option($key);
            if(function_exists('wp_clear_scheduled_hook'))wp_clear_scheduled_hook('pste_live_serp_job_step');
            $storedSettings=get_option(PSTE_OPTION_SETTINGS,[]);if(is_array($storedSettings))update_option(PSTE_OPTION_SETTINGS,self::migrateSettings($storedSettings),false);
            update_option($marker,'COMPLETE',false);
        } catch (Throwable $e) {
            // Keep all legacy data, but never hide a failed maintenance step.
            throw new RuntimeException('PSTE_LEGACY_WORKFLOW_ARCHIVE_FAILED_'.self::errorCode($e),0,$e);
        }
    }

    public static function activate(): void {
        // Dormant activation: no cleanup, migration, scheduling, portal scan or retry.
        // Only the safe boot state is persisted so the explicit migration action can be offered.
        try {
            $schema=(string)get_option(PSTE_OPTION_SCHEMA,'');
            if ($schema === self::TARGET_SCHEMA && self::editorialMetadataCurrent() && self::safeMigrationProtocolCurrent()) {
                self::writeBootStatus('READY','READY','', 'Schema und redaktionelle Metadaten sind aktuell.');
            } elseif ($schema === self::TARGET_SCHEMA) {
                self::writeBootStatus('PENDING','EDITORIAL_METADATA_REBUILD_REQUIRED','PSTE_EDITORIAL_METADATA_REBUILD_REQUIRED','Explizite sichere Migration erforderlich.');
            } else {
                self::writeBootStatus('PENDING','AWAITING_MANUAL_MIGRATION','', 'Explizite sichere Migration erforderlich.');
            }
        } catch (Throwable $e) {
            self::writeBootStatus('BLOCKED','ACTIVATION_STATUS_ONLY',self::errorCode($e),self::errorMessage($e),['trigger'=>'ACTIVATION_STATUS_ONLY']);
        }
    }

    public static function maybeMigrate(): void {
        // Backward-compatible no-op. All migration work is owned by PSTE_Safe_Migration_Job.
    }

    private static function editorialMetadataCurrent(): bool {
        try {
            if ((string)get_option(PSTE_OPTION_EDITORIAL_REBUILD_MARKER,'') !== PSTE_Editorializer::RULESET) return false;
            $audit=get_option(PSTE_OPTION_EDITORIAL_REBUILD_REPORT,[]);if(!is_array($audit))return false;
            if(($audit['contract']??'')!=='PSTE_EDITORIAL_METADATA_REBUILD_AUDIT_V1')return false;
            if(!hash_equals(PSTE_Editorializer::RULESET,(string)($audit['ruleset']??'')))return false;
            $report=(array)($audit['report']??[]);if(!hash_equals(PSTE_Editorializer::RULESET,(string)($report['contract']??'')))return false;
            return true;
        } catch (Throwable $e) { return false; }
    }

    public static function isReady(): bool {
        try {
            if ((string)get_option(PSTE_OPTION_SCHEMA,'') !== self::TARGET_SCHEMA) return false;
            if (!self::editorialMetadataCurrent() || !self::safeMigrationProtocolCurrent()) return false;
            return (string)(self::bootStatus()['status']??'') === 'READY';
        } catch (Throwable $e) { return false; }
    }

    public static function safeMigrationProtocolCurrent(): bool {
        try{$marker=get_option(PSTE_OPTION_SAFE_MIGRATION_PROTOCOL,[]);if(!is_array($marker)||($marker['contract']??'')!=='PSTE_SAFE_MIGRATION_PROTOCOL_MARKER_V1'||!hash_equals(PSTE_SAFE_MIGRATION_PROTOCOL,(string)($marker['protocol']??'')))return false;$declared=(string)($marker['sha256']??'');$copy=$marker;unset($copy['sha256']);$json=wp_json_encode($copy,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($json)&&preg_match('/^[a-f0-9]{64}$/',$declared)&&hash_equals(hash('sha256',$json),$declared);}catch(Throwable $e){return false;}
    }

    public static function targetSchemaVersion(): string {return self::TARGET_SCHEMA;}
    public static function supportedSourceSchema(string $schema): bool {return in_array($schema,self::SUPPORTED_SOURCE_SCHEMAS,true);}

    public static function assertReady(): void {
        if (!self::isReady()) throw new RuntimeException('PSTE_SAFE_BOOT_NOT_READY');
    }

    /**
     * Backward-compatible explicit start entry. Heavy work is never executed here: it only creates/resumes
     * the durable request-bounded migration job. The admin AJAX lifecycle advances the job phase by phase.
     */
    public static function safeMigrate(string $trigger='MANUAL_RETRY'): bool {
        try{$job=PSTE_Safe_Migration_Job::start($trigger);return (string)($job['status']??'')==='COMPLETE'&&self::isReady();}
        catch(Throwable $e){self::writeBootStatus('PENDING','SAFE_MIGRATION_START_FAILED',self::errorCode($e),self::errorMessage($e),['trigger'=>$trigger]);return false;}
    }

    /** Explicit safe-migration lifecycle helpers. They touch PSTE-owned state only. */
    public static function safeMigrationPreparation(): void {self::cleanupRemovedLiveWorkflow();}
    public static function safeMigrationSettingsPhase(): void {
        $existing=get_option(PSTE_OPTION_SETTINGS,null);
        if($existing===null){if(!add_option(PSTE_OPTION_SETTINGS,self::defaults(),'',false)&&get_option(PSTE_OPTION_SETTINGS,null)===null)throw new RuntimeException('PSTE_SETTINGS_CREATE_FAILED');}
        elseif(is_array($existing)){$m=self::migrateSettings($existing);if($m!==$existing){update_option(PSTE_OPTION_SETTINGS,$m,false);if(!is_array(get_option(PSTE_OPTION_SETTINGS,null)))throw new RuntimeException('PSTE_SETTINGS_UPDATE_NOT_PERSISTED');}}
        else throw new RuntimeException('PSTE_SETTINGS_INVALID_TYPE');
    }
    public static function migrationBootStatus(string $status,string $stage,string $errorCode,string $message,array $details=[]): void {self::requireBootStatus($status,$stage,$errorCode,$message,$details);}
    public static function safeMigrationEnsureSchedules(): void {self::ensureRecurringSchedules();}
    /** @return array<string,mixed> */
    public static function finalizeSafeMigration(array $editorialReport,array $job): array {
        if(!hash_equals(PSTE_Editorializer::RULESET,(string)($editorialReport['contract']??'')))throw new RuntimeException('PSTE_EDITORIAL_REBUILD_REPORT_INVALID');
        update_option(PSTE_OPTION_EDITORIAL_REBUILD_MARKER,PSTE_Editorializer::RULESET,false);if((string)get_option(PSTE_OPTION_EDITORIAL_REBUILD_MARKER,'')!==PSTE_Editorializer::RULESET)throw new RuntimeException('PSTE_EDITORIAL_REBUILD_MARKER_NOT_PERSISTED');
        $audit=['contract'=>'PSTE_EDITORIAL_METADATA_REBUILD_AUDIT_V1','version'=>PSTE_VERSION,'ruleset'=>PSTE_Editorializer::RULESET,'completed_at_utc'=>gmdate('c'),'trigger'=>(string)($job['trigger']??'SAFE_MIGRATION_JOB'),'report'=>$editorialReport];
        update_option(PSTE_OPTION_EDITORIAL_REBUILD_REPORT,$audit,false);$stored=get_option(PSTE_OPTION_EDITORIAL_REBUILD_REPORT,[]);if(!is_array($stored)||!hash_equals(PSTE_Editorializer::RULESET,(string)($stored['ruleset']??'')))throw new RuntimeException('PSTE_EDITORIAL_REBUILD_AUDIT_NOT_PERSISTED');
        update_option(PSTE_OPTION_SCHEMA,self::TARGET_SCHEMA,false);if((string)get_option(PSTE_OPTION_SCHEMA,'')!==self::TARGET_SCHEMA)throw new RuntimeException('PSTE_SCHEMA_VERSION_NOT_PERSISTED');
        $protocol=['contract'=>'PSTE_SAFE_MIGRATION_PROTOCOL_MARKER_V1','protocol'=>PSTE_SAFE_MIGRATION_PROTOCOL,'plugin_version'=>PSTE_VERSION,'job_uuid'=>(string)($job['job_uuid']??''),'completed_at_utc'=>gmdate('c'),'editorial_ruleset'=>PSTE_Editorializer::RULESET,'source_schema'=>(string)($job['source_schema']??'')];
        $protocol['sha256']=hash('sha256',wp_json_encode($protocol,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION));update_option(PSTE_OPTION_SAFE_MIGRATION_PROTOCOL,$protocol,false);$read=get_option(PSTE_OPTION_SAFE_MIGRATION_PROTOCOL,[]);if(!is_array($read)||!hash_equals((string)$protocol['sha256'],(string)($read['sha256']??''))||!self::safeMigrationProtocolCurrent())throw new RuntimeException('PSTE_SAFE_MIGRATION_PROTOCOL_NOT_PERSISTED');
        self::requireBootStatus('READY','COMPLETE','', 'Sichere Migration vollständig abgeschlossen.', ['job_uuid'=>(string)($job['job_uuid']??''),'protocol'=>PSTE_SAFE_MIGRATION_PROTOCOL,'editorial_rebuild'=>$editorialReport]);self::ensureRecurringSchedules();
        return ['contract'=>'PSTE_SAFE_MIGRATION_FINALIZATION_V1','status'=>'PASS','protocol'=>PSTE_SAFE_MIGRATION_PROTOCOL,'schema'=>self::TARGET_SCHEMA,'ruleset'=>PSTE_Editorializer::RULESET];
    }

    private static function assertSupportedMigrationSource(): void {
        $schema=(string)get_option(PSTE_OPTION_SCHEMA,'');
        if (!in_array($schema,self::SUPPORTED_SOURCE_SCHEMAS,true)) {
            throw new RuntimeException('PSTE_UNSUPPORTED_SOURCE_SCHEMA_'.$schema);
        }
    }

    public static function bootStatus(): array {
        try {
            $schema=(string)get_option(PSTE_OPTION_SCHEMA,'');$stored=get_option(PSTE_OPTION_BOOT_STATUS,[]);if(!is_array($stored))$stored=[];
            $default=['contract'=>'PSTE_SAFE_BOOT_STATUS_V1','status'=>'PENDING','stage'=>$schema===self::TARGET_SCHEMA?'READY_STATUS_CONFIRMATION_REQUIRED':'AWAITING_MANUAL_MIGRATION','error_code'=>'','message'=>'','version'=>PSTE_VERSION,'schema'=>$schema,'updated_at_utc'=>'','details'=>[]];$boot=array_merge($default,$stored);$boot['version']=PSTE_VERSION;$boot['schema']=$schema;
            $job=null;try{$job=PSTE_Safe_Migration_Job::current();}catch(Throwable $jobError){$boot['status']='BLOCKED';$boot['stage']='SAFE_MIGRATION_JOB_INVALID';$boot['error_code']=self::errorCode($jobError);$boot['message']='Der dauerhafte Migrationszustand ist beschädigt und wurde nicht automatisch verändert.';return $boot;}
            if(is_array($job)&&hash_equals(PSTE_SAFE_MIGRATION_PROTOCOL,(string)($job['protocol']??''))){$js=(string)($job['status']??'');if(in_array($js,['RUNNING','PAUSED_ERROR'],true)){$boot['status']='PENDING';$boot['stage']=$js==='PAUSED_ERROR'?'SAFE_MIGRATION_PAUSED_'.(string)($job['phase']??'UNKNOWN'):'SAFE_MIGRATION_'.(string)($job['phase']??'UNKNOWN');$boot['error_code']=$js==='PAUSED_ERROR'?(string)($job['last_error']??''):'';$boot['message']=$js==='PAUSED_ERROR'?'Die sichere Migration ist an einer dauerhaften Grenze angehalten und kann fortgesetzt werden.':'Die sichere Migration ist fortsetzbar; zwischen einzelnen Requests ist kein globaler Lock erforderlich.';$boot['details']=array_merge((array)($boot['details']??[]),['job_uuid'=>(string)($job['job_uuid']??''),'migration_phase'=>(string)($job['phase']??''),'editorial_prepare_progress'=>(int)($job['editorial_prepare_cursor']??0),'editorial_finalize_progress'=>(int)($job['editorial_finalize_cursor']??0),'editorial_total'=>(int)($job['editorial_total']??0),'sandbox_progress'=>(int)($job['sandbox_cursor']??0),'sandbox_total'=>(int)($job['sandbox_total']??0)]);return $boot;}}
            $editorial=self::editorialMetadataCurrent();$protocol=self::safeMigrationProtocolCurrent();
            if($schema!==self::TARGET_SCHEMA){$boot['status']='PENDING';$boot['stage']='AWAITING_MANUAL_MIGRATION';$boot['error_code']='';$boot['message']='Sichere Migration muss im Backend ausdrücklich gestartet bzw. fortgesetzt werden.';return $boot;}
            if(!$editorial||!$protocol){$previous=['status'=>(string)($stored['status']??''),'stage'=>(string)($stored['stage']??''),'error_code'=>(string)($stored['error_code']??'')];$boot['status']='PENDING';$boot['stage']=!$protocol?'SAFE_MIGRATION_PROTOCOL_REQUIRED':'EDITORIAL_METADATA_REBUILD_REQUIRED';$boot['error_code']=!$protocol?'PSTE_SAFE_MIGRATION_PROTOCOL_REQUIRED':'PSTE_EDITORIAL_METADATA_REBUILD_REQUIRED';$boot['message']='Der gespeicherte Altstatus ist keine Freigabeautorität. Die aktuelle sichere Migration muss vollständig abgeschlossen werden.';$boot['details']=array_merge((array)($boot['details']??[]),['previous_boot_evidence'=>$previous]);return $boot;}
            if((string)($boot['status']??'')!=='READY'){$boot['status']='PENDING';$boot['stage']='READY_STATUS_CONFIRMATION_REQUIRED';$boot['error_code']='';$boot['message']='Schema, Regelstand und Migrationsprotokoll sind aktuell; die persistierte READY-Abschlussbestätigung fehlt.';}
            return $boot;
        } catch (Throwable $e) {
            return ['contract'=>'PSTE_SAFE_BOOT_STATUS_V1','status'=>'BLOCKED','stage'=>'STATUS_UNAVAILABLE','error_code'=>'PSTE_BOOT_STATUS_READ_FAILED','message'=>'Der sichere Startstatus konnte nicht gelesen werden.','version'=>PSTE_VERSION,'schema'=>'','updated_at_utc'=>'','details'=>[]];
        }
    }

    private static function requireBootStatus(string $status,string $stage,string $errorCode,string $message,array $details=[]): void {
        if(!self::writeBootStatus($status,$stage,$errorCode,$message,$details)){
            throw new RuntimeException('PSTE_BOOT_STATUS_NOT_PERSISTED_'.$stage);
        }
    }

    private static function writeBootStatus(string $status,string $stage,string $errorCode,string $message,array $details=[]): bool {
        try {
            $payload=[
                'contract'=>'PSTE_SAFE_BOOT_STATUS_V1','status'=>$status,'stage'=>$stage,
                'error_code'=>$errorCode,'message'=>$message,'version'=>PSTE_VERSION,
                'schema'=>(string)get_option(PSTE_OPTION_SCHEMA,''),'updated_at_utc'=>gmdate('c'),
                'details'=>self::scrubDetails($details),
            ];
            update_option(PSTE_OPTION_BOOT_STATUS,$payload,false);
            $stored=get_option(PSTE_OPTION_BOOT_STATUS,[]);
            if(!is_array($stored))return false;
            foreach(['contract','status','stage','error_code','version','schema'] as $field){
                if((string)($stored[$field]??'')!==(string)$payload[$field])return false;
            }
            return true;
        } catch (Throwable $e) {
            return false;
        }
    }

    private static function errorCode(Throwable $e): string {
        $raw=strtoupper(trim((string)$e->getMessage()));
        $raw=(string)preg_replace('/[^A-Z0-9_:-]+/','_',$raw);
        return substr($raw!==''?$raw:'PSTE_MIGRATION_FAILED',0,160);
    }

    private static function errorMessage(Throwable $e): string {
        $raw=trim((string)$e->getMessage());
        $raw=(string)preg_replace('/[^A-Za-z0-9_:\- .]/','',$raw);
        return substr($raw!==''?$raw:'PSTE_MIGRATION_FAILED',0,240);
    }

    private static function scrubDetails(array $details): array {
        foreach($details as $key=>$value){
            if(preg_match('/(?:password|secret|token|authorization|credential)/i',(string)$key))unset($details[$key]);
            elseif(is_array($value))$details[$key]=self::scrubDetails($value);
        }
        return $details;
    }

    public static function defaults(): array { return [
        'feature_enabled'=>false,'environment'=>'sandbox','location'=>'Germany','language'=>'German','run_budget_usd'=>8.0,'absolute_ceiling_usd'=>10.0,
        'daily_budget_usd'=>15.0,'monthly_budget_usd'=>25.0,'domain_profile'=>'generic','taxonomy_source'=>'dynamic_wordpress_categories',
        'coverage_under_threshold'=>70.0,'coverage_over_threshold'=>130.0,'gsc_default_days'=>90,'context_batch_size'=>100,
    ]; }
    public static function migrateSettings(array $existing): array { $defaults=self::defaults();return array_merge($defaults,array_intersect_key($existing,$defaults)); }
    public static function settings(): array {$stored=get_option(PSTE_OPTION_SETTINGS,[]);return PSTE_Credentials::scrub(self::migrateSettings(is_array($stored)?$stored:[]));}
}
