# Portal SEO Themenengine 0.8.3-staging

## Reparatur des realen Schema-7-Datenbestands

Die Auswertung des vor der Migration erstellten WPvivid-Datenbankbackups zeigte zwei voneinander getrennte Altlasten im ausschließlich eigenen `pste_`-Datenbestand:

- 21 von 22 Themenzeilen enthielten statt des vollständigen Themen-Payloads nur noch einen minimalen technischen Fehlerstatus.
- 102 von 139 Historieneinträgen verwiesen noch auf frühere Themen-IDs, während Themenpool, Fundstellen, Zuordnungen und Identitätstabelle bereits die aktuellen globalen UUIDs verwendeten.

0.8.3 ergänzt eine strikt transaktionale, kostenfreie Wiederherstellung:

- beschädigte Themen-Payloads werden ausschließlich aus den vorhandenen Kandidaten und Fundstellen rekonstruiert;
- die rekonstruierte Identität muss exakt zum bereits gespeicherten normalisierten Schlüssel passen;
- Historien-IDs werden nur bei eindeutigem Ziel über Kandidaten-ID oder normalisierten Schlüssel repariert;
- fehlende oder mehrdeutige Quellen blockieren fail-closed;
- ein Fehler rollt Payload-, Identitäts- und Historienänderungen gemeinsam zurück;
- Relationsprüfung umfasst jetzt Fundstellen, Zuordnungen und Historie;
- der Migrationsbericht weist die Zahl reparierter Payloads und Historienzeilen aus.

## Unverändert geschützt

- Keine neue Recherche, keine API-Abfrage und kein Portalvollscan während der Migration.
- Keine Änderung an Textproduktionsmaschine, Production Center, Editorial Guard, Beiträgen, Kategorien, URLs, Yoast, Post-/Term-Metadaten oder fremden Plugins.
- Produktionsanbindung bleibt `NO_CONNECTION_INFORMATIONAL_ONLY`.
