<?php
if (!defined('ABSPATH')) { return; }

/**
 * Preserves an arbitrary research phrase and derives two metadata-only views:
 *  - semantic_probe: family-matching probe with editorial intent noise removed
 *  - subject_topic: meaning-preserving subject phrase used by the title composer
 *
 * It never changes the stored raw query and never creates article content, structure or formatting.
 */
final class PSTE_Editorial_Topic_Normalizer {
    private const RELATIONS=['mit','für','fuer','ohne','gegen','bei','von','aus','im','in','auf','unter','über','ueber','zum','zur'];
    private const JOINERS=['und','oder'];

    /** Lexical intent policy is owned centrally by PSTE_Article_Type_Intent_Ontology. */

    /** @return array<string,mixed> */
    public static function normalize(string $raw,string $family='',array $portalContextTerms=[]): array {
        $raw=self::clean($raw);$family=self::clean($family);
        $base=[
            'contract'=>'PSTE_EDITORIAL_TOPIC_NORMALIZER_V2',
            'raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),'family'=>$family,
            'normalized_topic'=>'','subject_topic'=>'','semantic_probe'=>'','qualifier'=>'','relation'=>'',
            'detected_action'=>self::detectAction($raw),'intent_signals'=>self::intentSignals($raw),
            'status'=>'REVIEW_REQUIRED','reason_codes'=>[],'review_flags'=>[],
            'raw_query_modified'=>false,'write_attempted'=>false,
        ];
        if($raw===''){ $base['reason_codes']=['EDITORIAL_TOPIC_RAW_QUERY_EMPTY']; return $base; }

        $probe=self::semanticProbe($raw);$base['semantic_probe']=$probe!==''?$probe:$raw;
        if($family===''){
            $topic=self::surfaceLoose($probe!==''?$probe:$raw);
            $base['normalized_topic']=$topic;$base['subject_topic']=$topic;
            $base['status']=$topic!==''?'PASS':'REVIEW_REQUIRED';
            $base['reason_codes']=$topic!==''?['EDITORIAL_TOPIC_NORMALIZED_WITHOUT_CONFIRMED_FAMILY_PROPOSAL_ONLY']:['EDITORIAL_TOPIC_NORMALIZATION_FAILED'];
            $base['review_flags'][]='EDITORIAL_TOPIC_NO_CONFIRMED_FAMILY';
            return $base;
        }

        if(!PSTE_Token_Equivalence::contains($raw,$family)){
            $base['reason_codes']=['EDITORIAL_TOPIC_FAMILY_NOT_SEMANTICALLY_PRESENT'];
            return $base;
        }

        // Natural questions keep their full semantic sentence. The composer may only normalize
        // punctuation/casing of the family surface; it must not synthesize a different question.
        if(PSTE_Normalizer::isQuestion($raw)){
            $base['normalized_topic']=self::surfaceSentence($raw);
            $base['subject_topic']=$family;
            $base['status']='PASS';
            $base['reason_codes']=['EDITORIAL_TOPIC_NATURAL_QUESTION_PRESERVED'];
            return $base;
        }

        $split=self::splitAroundFamily($raw,$family);
        if(empty($split['matched'])){
            $base['reason_codes']=['EDITORIAL_TOPIC_FAMILY_TOKEN_SPLIT_FAILED'];
            return $base;
        }

        $before=self::clean((string)$split['before']);$after=self::clean((string)$split['after']);
        $beforeSubject=self::stripIntentOnly($before);$afterSubject=self::stripIntentOnly($after);
        $beforeSubject=self::trimDanglingRelations($beforeSubject);$afterSubject=self::trimDanglingRelations($afterSubject);

        $subject=$family;$relation='';$qualifier='';$review=[];
        $beforeCount=self::wordCount($beforeSubject);$afterCount=self::wordCount($afterSubject);

        if($beforeSubject!==''&&$afterSubject===''){
            if($beforeCount===1&&!self::isRelation($beforeSubject)){
                $qualifier=self::surfaceToken($beforeSubject);
                if(self::matchesPortalContext($beforeSubject,$portalContextTerms)){
                    // A preposed portal-context token (e.g. context + family) has one safe, evidence-bound relation.
                    // The context comes from the current portal identity, never from a topic-specific word list.
                    $relation='für';$subject=trim($family.' für '.self::surfaceQualifier($beforeSubject));
                }else{
                    $relation='preposed_qualifier';$subject=trim($qualifier.' '.$family);
                }
            }else{
                $review[]='EDITORIAL_TOPIC_PREPOSED_MULTIWORD_QUALIFIER_REVIEW';
            }
        }elseif($beforeSubject===''&&$afterSubject!==''){
            if(preg_match('/^(mit|für|fuer|ohne|gegen|bei|von|aus|im|in|auf|unter|über|ueber|zum|zur)\s+(.+)$/iu',$afterSubject,$m)){
                $relation=self::normalizeRelation((string)$m[1]);$q=self::clean((string)$m[2]);
                if($q!==''&&!self::isIntentOnly($q)){
                    if(self::wordCount($q)===1){$qualifier=self::surfaceQualifier($q);$subject=$family.' '.$relation.' '.$qualifier;}
                    else $review[]='EDITORIAL_TOPIC_LONG_RELATIONAL_QUALIFIER_REVIEW';
                }
            }elseif($afterSubject!==''&&!self::isIntentOnly($afterSubject)){
                // A bare token after the family can mean brand, audience, material, location or something else.
                // Inventing a relation is unsafe, so the editorial strand must review it.
                $review[]='EDITORIAL_TOPIC_UNBOUND_POST_FAMILY_QUALIFIER_REVIEW';
            }
        }elseif($beforeSubject!==''&&$afterSubject!==''){
            // Two-sided residuals are frequently search-engine fragments. Never invent a relation.
            $review[]='EDITORIAL_TOPIC_TWO_SIDED_RESIDUAL_REVIEW';
        }

        // Preserve explicit type/action semantics in normalized_topic for the independent semantic classifier,
        // while subject_topic remains the clean subject for title composition.
        $normalized=self::canonicalFamilySurface($raw,$family);
        $normalized=self::surfaceSentence($normalized);
        $subject=self::clean($subject);
        $base['normalized_topic']=$normalized!==''?$normalized:$subject;
        $base['subject_topic']=$subject;
        $base['qualifier']=$qualifier;$base['relation']=$relation;$base['review_flags']=$review;
        $base['status']=$subject!==''&&!$review?'PASS':'REVIEW_REQUIRED';
        $base['reason_codes']=$base['status']==='PASS'?['EDITORIAL_TOPIC_MEANING_PRESERVING_NORMALIZATION']:array_values(array_unique(array_merge(['EDITORIAL_TOPIC_NORMALIZATION_REVIEW_REQUIRED'],$review)));
        return $base;
    }

    /** Family-matcher probe: removes only generic editorial/type signals, never source data. */
    public static function semanticProbe(string $raw): string {
        $value=self::clean($raw);if($value==='')return '';
        $value=PSTE_Article_Type_Intent_Ontology::stripIntentSignals($value);
        $value=self::clean((string)preg_replace('/[?:;!]+/u',' ',$value));
        return self::trimDanglingRelations($value);
    }

    /** Tokens that carry subject meaning after generic editorial intent has been removed. @return list<string> */
    public static function semanticContentTokens(string $raw,string $family=''): array {
        $probe=self::semanticProbe($raw);$tokens=PSTE_Token_Equivalence::tokens(str_replace('-',' ',$probe));
        if($family!=='')$tokens=array_values(array_diff($tokens,PSTE_Token_Equivalence::tokens(str_replace('-',' ',$family))));
        $stop=['fuer','mit','ohne','gegen','bei','von','aus','im','in','auf','unter','ueber','zum','zur','und','oder','ein','eine','einer','einem','einen','der','die','das','den','dem','des'];
        return array_values(array_unique(array_diff($tokens,$stop)));
    }

    /** Generic, non-applying suggestion used only after current portal structure has been rechecked. @return array<string,mixed> */
    public static function structureProposal(string $raw,string $articleType='',array $sourceEvidence=[],array $intentAnalysis=[]): array {
        $raw=self::clean($raw);$probe=self::semanticProbe($raw);$family=self::surfaceLoose($probe!==''?$probe:$raw);$type=trim($articleType);
        $title='';$titleQuality=[];
        if(!$intentAnalysis&&$family!==''){
            $proposalNormalization=self::normalize($raw,'');
            $intentAnalysis=PSTE_Intent_Profile::analyzeBeforeType($raw,$proposalNormalization,$family,$sourceEvidence);
        }
        if($family!==''&&$type!==''){
            $title=PSTE_Title_Composer::compose($raw,$family,$type,[],$intentAnalysis);
            if($title!=='')$titleQuality=PSTE_Editorial_Quality_Gate::evaluate($title,$raw,$probe,$family,$type,$intentAnalysis);
        }
        // Without a confirmed existing family/category, a proposal may not self-certify its own title.
        // Keep the candidate for later review/recheck, but it can never directly unlock reentry or production.
        $titleStatus='REVIEW_REQUIRED';
        return [
            'contract'=>'PSTE_STRUCTURE_PROPOSAL_V3_RETAINED_REVIEW_GATED','status'=>$family!==''?'PROPOSAL_ONLY':'REVIEW_REQUIRED',
            'raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),'normalized_topic'=>$probe,'proposed_family_name'=>$family,
            'proposed_category_name'=>$family!==''&&$type!==''?trim($type.' '.$family):'','proposed_article_type'=>$type,
            'proposed_article_type_status'=>$type!==''?'SEMANTICALLY_PROVEN':'REVIEW_REQUIRED',
            'intent_analysis'=>$intentAnalysis,'intent_first'=>true,
            'planning_title_proposal'=>$title,'planning_title_status'=>$titleStatus,'planning_title_quality'=>$titleQuality,
            'planning_title_quality_scope'=>'PROVISIONAL_ONLY_NO_CONFIRMED_FAMILY_SELF_APPROVAL_FORBIDDEN',
            'planning_title_may_enter_reentry'=>false,
            'proposal_requires_review'=>true,'taxonomy_write_attempted'=>false,'production_handoff_attempted'=>false,'write_attempted'=>false,
        ];
    }

    /** @return list<string> */
    private static function intentSignals(string $raw): array {
        $s=PSTE_Normalizer::isQuestion($raw)?['FAQ']:[];
        foreach(PSTE_Article_Type_Intent_Ontology::strongSignals($raw) as $type)$s[]=strtoupper(PSTE_Article_Type_Registry::canonicalType($type));
        return array_values(array_unique($s));
    }

    private static function detectAction(string $raw): string {
        $map=[
            '/\bimprägnier\w*\b/iu'=>'imprägnieren','/\bimpraegnier\w*\b/iu'=>'imprägnieren','/\breparier\w*\b/iu'=>'reparieren','/\breinig\w*\b/iu'=>'reinigen','/\bwasch\w*\b/iu'=>'waschen','/\btrockn\w*\b/iu'=>'trocknen','/\bpfleg\w*\b/iu'=>'pflegen','/\bwart\w*\b/iu'=>'warten',
            '/\binstallier\w*\b/iu'=>'installieren','/\bmontier\w*\b/iu'=>'montieren','/\baufbau\w*\b/iu'=>'aufbauen','/\banschließ\w*\b/iu'=>'anschließen','/\banschliess\w*\b/iu'=>'anschließen','/\beinbau\w*\b/iu'=>'einbauen','/\bbefestig\w*\b/iu'=>'befestigen','/\banbring\w*\b/iu'=>'anbringen','/\beinricht\w*\b/iu'=>'einrichten',
            '/\banwend\w*\b/iu'=>'anwenden','/\bbenutz\w*\b/iu'=>'benutzen','/\bverwend\w*\b/iu'=>'verwenden','/\beinsetz\w*\b/iu'=>'einsetzen','/\bdosier\w*\b/iu'=>'dosieren','/\banleg\w*\b/iu'=>'anlegen',
            '/\blager\w*\b/iu'=>'lagern','/\baufbewahr\w*\b/iu'=>'aufbewahren','/\bverstau\w*\b/iu'=>'verstauen',
        ];
        foreach($map as $pattern=>$action)if(preg_match($pattern,$raw))return $action;return '';
    }

    /** @return array{matched:bool,before:string,after:string} */
    private static function splitAroundFamily(string $raw,string $family): array {
        $words=preg_split('/\s+/u',self::clean($raw))?:[];$familyTokens=array_fill_keys(PSTE_Token_Equivalence::tokens(str_replace('-',' ',$family)),true);$hits=[];
        foreach($words as $i=>$word){foreach(PSTE_Token_Equivalence::tokens(trim($word,".,!?;:()[]{}\"'")) as $token)if(isset($familyTokens[$token])){$hits[]=$i;break;}}
        if(!$hits)return ['matched'=>false,'before'=>'','after'=>''];$first=min($hits);$last=max($hits);
        return ['matched'=>true,'before'=>self::clean(implode(' ',array_slice($words,0,$first))),'after'=>self::clean(implode(' ',array_slice($words,$last+1)))];
    }

    private static function canonicalFamilySurface(string $raw,string $family): string {
        $words=preg_split('/\s+/u',self::clean($raw))?:[];$familyTokens=array_fill_keys(PSTE_Token_Equivalence::tokens(str_replace('-',' ',$family)),true);$out=[];$inserted=false;
        foreach($words as $word){$isFamily=false;foreach(PSTE_Token_Equivalence::tokens(trim($word,".,!?;:()[]{}\"'")) as $token)if(isset($familyTokens[$token])){$isFamily=true;break;}if($isFamily){if(!$inserted){$out[]=$family;$inserted=true;}continue;}$out[]=$word;}
        return self::clean(implode(' ',$out));
    }

    private static function stripIntentOnly(string $value): string {return self::clean(PSTE_Article_Type_Intent_Ontology::stripIntentSignals($value));}
    private static function isIntentOnly(string $value): bool {return self::semanticProbe($value)==='';}
    private static function trimDanglingRelations(string $value): string {$value=self::clean($value);do{$old=$value;$value=(string)(preg_replace('/^(mit|für|fuer|ohne|gegen|bei|von|aus|im|in|auf|unter|über|ueber|zum|zur)\s*$/iu','',$value)??$value);$value=(string)(preg_replace('/\b(mit|für|fuer|ohne|gegen|bei|von|aus|im|in|auf|unter|über|ueber|zum|zur)\s*$/iu','',$value)??$value);$value=self::clean($value);}while($value!==$old);return $value;}
    private static function looksLikeVerb(string $value): bool {return (bool)preg_match('/(ieren|ieren$|en$|ern$)/iu',$value);}
    private static function isRelation(string $v): bool{return in_array(self::lower(self::clean($v)),self::RELATIONS,true);}
    private static function matchesPortalContext(string $value,array $terms): bool {
        $valueTokens=PSTE_Token_Equivalence::tokens($value);if(count($valueTokens)!==1)return false;
        foreach($terms as $term){$termTokens=PSTE_Token_Equivalence::tokens((string)$term);if(count($termTokens)===1&&$termTokens[0]===$valueTokens[0])return true;}
        return false;
    }
    private static function normalizeRelation(string $v): string {$v=self::lower($v);return $v==='fuer'?'für':($v==='ueber'?'über':$v);}

    private static function surfaceQualifier(string $value): string {
        $value=self::clean($value);if($value==='')return '';$parts=preg_split('/\s+/u',$value)?:[];$out=[];
        foreach($parts as $i=>$w){$l=self::lower($w);if(in_array($l,self::RELATIONS,true)){$out[]=self::normalizeRelation($l);continue;}if(in_array($l,self::JOINERS,true)){$out[]=$l;continue;}if($i===0)$w=self::uppercaseFirst($w);$out[]=$w;}
        return self::clean(implode(' ',$out));
    }
    private static function surfaceToken(string $value): string {return self::uppercaseFirst(self::clean($value));}
    private static function surfaceLoose(string $value): string {return self::surfaceSentence(self::clean($value));}
    private static function surfaceSentence(string $value): string {$value=self::clean($value);return $value===''?'':self::uppercaseFirst($value);}
    private static function wordCount(string $v): int {return count(array_values(array_filter(preg_split('/\s+/u',self::clean($v))?:[])));}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');$v=trim((string)preg_replace('/\s+/u',' ',$v));return trim($v," \t\n\r\0\x0B?:;!");}
    private static function uppercaseFirst(string $v): string {if($v==='')return '';$f=self::substr($v,0,1);$r=self::substr($v,1);$f=function_exists('mb_strtoupper')?mb_strtoupper($f,'UTF-8'):strtoupper($f);return $f.$r;}
    private static function lower(string $v): string{return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
    private static function substr(string $v,int $start,?int $length=null): string{return function_exists('mb_substr')?($length===null?mb_substr($v,$start,null,'UTF-8'):mb_substr($v,$start,$length,'UTF-8')):($length===null?substr($v,$start):substr($v,$start,$length));}
}
