<?php
if (!defined('ABSPATH')) { return; }

/** Pure orchestration: independent technical and editorial strands; no domain logic in the final AND gate. */
final class PSTE_Title_Pipeline {
    /** @return array<string,mixed> */
    public static function build(array $queryRecord,string $family,string $type,array $registry,array $portalContextTerms=[],array $intentProfile=[]): array {
        $raw=(string)($queryRecord['raw_query']??'');$source=(string)($queryRecord['language_corrected_query']??$raw);if(trim($raw)==='')$raw=$source;
        $normalization=PSTE_Editorial_Topic_Normalizer::normalize($source,$family,$portalContextTerms);
        $targetKeywordMeta=PSTE_Intent_Profile::targetKeyword($source,$normalization,$type,$intentProfile);$targetKeyword=(string)($targetKeywordMeta['target_keyword']??'');
        $title=PSTE_Title_Composer::compose($source,$family,$type,$portalContextTerms,$intentProfile,$targetKeyword);
        return self::evaluateExisting($title,$raw,$source,$family,$type,$registry,$normalization,$intentProfile,$targetKeywordMeta,false);
    }

    /**
     * Validates a manually supplied planning title against the exact same hard gates without
     * recomputing intent, article type, category or target keyword. This is deliberately title-only.
     * @return array<string,mixed>
     */
    public static function validateExistingTitle(string $title,string $raw,string $family,string $type,array $registry,array $intentProfile,string $targetKeyword,string $normalizedTopic=''): array {
        $normalization=['status'=>'PASS','normalized_topic'=>$normalizedTopic!==''?$normalizedTopic:$raw,'subject_topic'=>$family,'reason_codes'=>[]];
        $targetKeywordMeta=['contract'=>'PSTE_TARGET_KEYWORD_V1_INTENT_BOUND_PPM_TITLE_COMPATIBLE','status'=>$targetKeyword!==''?'PASS':'REVIEW_REQUIRED','ok'=>$targetKeyword!=='','target_keyword'=>$targetKeyword,'source'=>'PRESERVED_EXISTING_TARGET_KEYWORD','raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'','raw_query_remains_separately_preserved'=>true,'target_keyword_is_not_required_to_equal_raw_query'=>true,'ppm_exact_title_substring_required'=>true,'portal_exact_title_prefix_required'=>false,'portal_keyword_position_1_required'=>false,'intent_profile_sha256'=>(string)($intentProfile['profile_sha256']??''),'reason_codes'=>$targetKeyword!==''?[]:['PSTE_TARGET_KEYWORD_EMPTY'],'write_attempted'=>false,'target_keyword_sha256'=>$targetKeyword!==''?hash('sha256',$targetKeyword):''];
        return self::evaluateExisting($title,$raw,$raw,$family,$type,$registry,$normalization,$intentProfile,$targetKeywordMeta,true);
    }

    /** @return array<string,mixed> */
    private static function evaluateExisting(string $title,string $raw,string $source,string $family,string $type,array $registry,array $normalization,array $intentProfile,array $targetKeywordMeta,bool $manualOverride): array {
        $targetKeyword=(string)($targetKeywordMeta['target_keyword']??'');
        $det=PSTE_Title_Validator::validate($title,$source,$family,$type,$registry,$targetKeyword);
        $lang=PSTE_German_Title_Reviewer::review($title,$family,$type);
        $editorial=PSTE_Editorial_Quality_Gate::evaluate($title,$raw,(string)($normalization['normalized_topic']??''),$family,$type,$intentProfile,$targetKeyword);
        $techStatus=!empty($targetKeywordMeta['ok'])&&!empty($det['ok'])&&!empty($lang['ok'])?'PASS':'FAIL';
        $editorialStatus=(($normalization['status']??'')==='PASS'&&!empty($editorial['ok']))?'PASS':'FAIL';
        $ok=$techStatus==='PASS'&&$editorialStatus==='PASS';
        return ['contract'=>'PSTE_TITLE_PIPELINE_V8_SINGLE_TITLE_AUTHORITY_HARD_QUALITY_GATE','title'=>$title,'target_keyword'=>$targetKeyword,'target_keyword_contract'=>$targetKeywordMeta,'normalization'=>$normalization,'deterministic'=>$det,'language'=>$lang,'editorial_quality'=>$editorial,'ok'=>$ok,
            'technical_strand'=>['status'=>$techStatus,'deterministic_status'=>(string)($det['status']??''),'language_status'=>(string)($lang['status']??''),'semantic_quality_claimed'=>false],
            'editorial_strand'=>['status'=>$editorialStatus,'normalization_status'=>(string)($normalization['status']??''),'quality_contract'=>(string)($editorial['contract']??''),'technical_result_consumed'=>false],
            'final_gate'=>['operator'=>'AND','technical_required'=>'PASS','editorial_required'=>'PASS','status'=>$ok?'PASS':'FAIL','domain_logic_present'=>false],
            'intent_profile'=>$intentProfile,'intent_profile_contract'=>(string)($intentProfile['contract']??''),'composition_contract'=>PSTE_Title_Composer::CONTRACT,'manual_override'=>$manualOverride,'manual_override_changes_intent_or_assignment'=>false,'independence'=>'COMPOSER_AND_EDITORIAL_QUALITY_GATE_SEPARATE_CLASSES_NO_SELF_APPROVAL','raw_query_preserved'=>true,'write_attempted'=>false];
    }
}
