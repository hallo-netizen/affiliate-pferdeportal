<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Credentials {
    private const SENSITIVE_KEY_PATTERN = '/(?:password|passwd|secret|token|authorization|api[_-]?key|api[_-]?login|credentials?|dataforseo[_-]?(?:login|password))/i';

    public static function resolve(): array {
        $storedLoginRaw = (string)get_option(PSTE_OPTION_CREDENTIAL_LOGIN, '');
        $storedPasswordRaw = (string)get_option(PSTE_OPTION_CREDENTIAL_PASSWORD, '');
        $storedLogin = $storedLoginRaw !== '' ? PSTE_Secret_Store::decrypt($storedLoginRaw) : '';
        $storedPassword = $storedPasswordRaw !== '' ? PSTE_Secret_Store::decrypt($storedPasswordRaw) : '';
        $login = $storedLogin !== '' ? $storedLogin : (defined('PSTE_DATAFORSEO_LOGIN') ? (string)PSTE_DATAFORSEO_LOGIN : (string)getenv('DATAFORSEO_LOGIN'));
        $password = $storedPassword !== '' ? $storedPassword : (defined('PSTE_DATAFORSEO_PASSWORD') ? (string)PSTE_DATAFORSEO_PASSWORD : (string)getenv('DATAFORSEO_PASSWORD'));
        return ['login'=>trim($login), 'password'=>trim($password)];
    }

    public static function configured(): bool {
        try {
            $c = self::resolve();
            return $c['login'] !== '' && $c['password'] !== '';
        } catch (Throwable $e) {
            return false;
        }
    }

    public static function status(): array {
        $storedLoginRaw = (string)get_option(PSTE_OPTION_CREDENTIAL_LOGIN, '');
        $storedPasswordRaw = (string)get_option(PSTE_OPTION_CREDENTIAL_PASSWORD, '');
        try {
            $storedLogin = $storedLoginRaw !== '' ? PSTE_Secret_Store::decrypt($storedLoginRaw) : '';
            $storedPassword = $storedPasswordRaw !== '' ? PSTE_Secret_Store::decrypt($storedPasswordRaw) : '';
            $loginSource = $storedLogin !== '' ? 'wordpress-option-autoload-false' : (defined('PSTE_DATAFORSEO_LOGIN') ? 'wp-config-constant' : (getenv('DATAFORSEO_LOGIN') ? 'environment' : 'missing'));
            $passwordSource = $storedPassword !== '' ? 'wordpress-option-autoload-false' : (defined('PSTE_DATAFORSEO_PASSWORD') ? 'wp-config-constant' : (getenv('DATAFORSEO_PASSWORD') ? 'environment' : 'missing'));
            $c = self::resolve();
            return [
                'configured'=>$c['login'] !== '' && $c['password'] !== '',
                'stored_in_wordpress'=>$storedLogin !== '' || $storedPassword !== '',
                'login_source'=>$loginSource,
                'password_source'=>$passwordSource,
                'encrypted_at_rest'=>($storedLoginRaw===''||str_starts_with($storedLoginRaw,'pste-sodium-v1:')||str_starts_with($storedLoginRaw,'pste-openssl-v1:'))&&($storedPasswordRaw===''||str_starts_with($storedPasswordRaw,'pste-sodium-v1:')||str_starts_with($storedPasswordRaw,'pste-openssl-v1:')),
                'masked_login'=>self::mask($c['login']),
                'update_invariant'=>true,
                'included_in_plugin_files'=>false,
                'included_in_exports'=>false,
                'deleted_on_uninstall'=>false,
                'error_code'=>null,
            ];
        } catch (Throwable $e) {
            return [
                'configured'=>false,'stored_in_wordpress'=>$storedLoginRaw!==''||$storedPasswordRaw!=='',
                'login_source'=>'encrypted-option-error','password_source'=>'encrypted-option-error','encrypted_at_rest'=>true,
                'masked_login'=>'—','update_invariant'=>true,'included_in_plugin_files'=>false,'included_in_exports'=>false,
                'deleted_on_uninstall'=>false,'error_code'=>'PSTE_SECRET_DECRYPTION_FAILED',
            ];
        }
    }

    public static function saveFromAdmin(string $loginInput, string $passwordInput, string $base64Input = ''): array {
        $current = self::resolve();
        $loginInput = trim($loginInput);
        $passwordInput = trim($passwordInput);
        $base64Input = trim($base64Input);

        if ($base64Input !== '' && ($loginInput !== '' || $passwordInput !== '')) {
            throw new RuntimeException('PSTE_CREDENTIAL_INPUT_AMBIGUOUS');
        }

        $usingBase64 = $base64Input !== '';
        if ($usingBase64) {
            $decoded = self::decodeBase64Credential($base64Input);
            $login = $decoded['login'];
            $password = $decoded['password'];
        } else {
            $login = $loginInput !== '' ? sanitize_text_field($loginInput) : $current['login'];
            $password = $passwordInput !== '' ? $passwordInput : $current['password'];
        }

        if ($login === '' || $password === '') { throw new RuntimeException('PSTE_CREDENTIALS_INCOMPLETE'); }
        if (strlen($login) > 255 || strlen($password) > 1024) { throw new RuntimeException('PSTE_CREDENTIALS_LENGTH_INVALID'); }
        $changed = !hash_equals((string)$current['login'], $login) || !hash_equals((string)$current['password'], $password);

        // Only this explicit administrator action writes the dedicated credential options.
        // The Base64 transport value itself is never stored.
        if ($usingBase64 || $loginInput !== '') { update_option(PSTE_OPTION_CREDENTIAL_LOGIN, PSTE_Secret_Store::encrypt($login), false); }
        if ($usingBase64 || $passwordInput !== '') { update_option(PSTE_OPTION_CREDENTIAL_PASSWORD, PSTE_Secret_Store::encrypt($password), false); }
        if ($changed) {
            update_option(PSTE_OPTION_CONNECTION_STATUS, [
                'contract'=>'PSTE_DATAFORSEO_CONNECTION_STATUS_V1',
                'status'=>'CONFIGURED_UNTESTED',
                'provider'=>'DataForSEO',
                'tested_at_utc'=>null,
                'environment'=>null,
                'error_code'=>null,
                'updated_at_utc'=>gmdate('c'),
            ], false);
        }
        return self::status();
    }


    public static function migrateLegacyEncryption(): void {
        foreach ([PSTE_OPTION_CREDENTIAL_LOGIN,PSTE_OPTION_CREDENTIAL_PASSWORD] as $option) {
            $raw=(string)get_option($option,'');
            if($raw===''||str_starts_with($raw,'pste-sodium-v1:')||str_starts_with($raw,'pste-openssl-v1:'))continue;
            update_option($option,PSTE_Secret_Store::encrypt(PSTE_Secret_Store::decrypt($raw)),false);
        }
    }

    public static function decodeBase64Credential(string $input): array {
        $normalized = trim($input);
        if (strncasecmp($normalized, 'Basic ', 6) === 0) {
            $normalized = trim(substr($normalized, 6));
        }
        $normalized = (string)preg_replace('/\s+/', '', $normalized);
        if ($normalized === '' || strlen($normalized) > 4096) {
            throw new RuntimeException('PSTE_BASE64_CREDENTIAL_INVALID');
        }
        if (!preg_match('/^[A-Za-z0-9+\/]*={0,2}$/', $normalized)) {
            throw new RuntimeException('PSTE_BASE64_CREDENTIAL_INVALID');
        }
        $padding = strlen($normalized) % 4;
        if ($padding !== 0) { $normalized .= str_repeat('=', 4 - $padding); }
        $decoded = base64_decode($normalized, true);
        if (!is_string($decoded) || $decoded === '' || str_contains($decoded, "\0")) {
            throw new RuntimeException('PSTE_BASE64_CREDENTIAL_INVALID');
        }
        if (rtrim(base64_encode($decoded), '=') !== rtrim($normalized, '=')) {
            throw new RuntimeException('PSTE_BASE64_CREDENTIAL_INVALID');
        }
        $separator = strpos($decoded, ':');
        if ($separator === false) {
            throw new RuntimeException('PSTE_BASE64_CREDENTIAL_FORMAT_INVALID');
        }
        $login = sanitize_text_field(substr($decoded, 0, $separator));
        $password = substr($decoded, $separator + 1);
        if ($login === '' || $password === '' || preg_match('/[\x00-\x1F\x7F]/', $login . $password)) {
            throw new RuntimeException('PSTE_BASE64_CREDENTIAL_FORMAT_INVALID');
        }
        if (strlen($login) > 255 || strlen($password) > 1024) {
            throw new RuntimeException('PSTE_CREDENTIALS_LENGTH_INVALID');
        }
        return ['login'=>$login, 'password'=>$password];
    }

    public static function connectionStatus(): array {
        $credentialStatus=self::status();
        if (!empty($credentialStatus['error_code'])) {
            return ['contract'=>'PSTE_DATAFORSEO_CONNECTION_STATUS_V1','status'=>'ERROR','label'=>'ZUGANG NICHT LESBAR','provider'=>'DataForSEO','tested_at_utc'=>null,'environment'=>null,'error_code'=>(string)$credentialStatus['error_code']];
        }
        if (empty($credentialStatus['configured'])) {
            return [
                'contract'=>'PSTE_DATAFORSEO_CONNECTION_STATUS_V1',
                'status'=>'NOT_CONFIGURED',
                'label'=>'NICHT EINGERICHTET',
                'provider'=>'DataForSEO',
                'tested_at_utc'=>null,
                'environment'=>null,
                'error_code'=>null,
            ];
        }
        $stored = get_option(PSTE_OPTION_CONNECTION_STATUS, []);
        $allowed = ['CONFIGURED_UNTESTED','CONNECTED','ERROR'];
        if (!is_array($stored) || !in_array((string)($stored['status'] ?? ''), $allowed, true)) {
            $stored = [
                'contract'=>'PSTE_DATAFORSEO_CONNECTION_STATUS_V1',
                'status'=>'CONFIGURED_UNTESTED',
                'provider'=>'DataForSEO',
                'tested_at_utc'=>null,
                'environment'=>null,
                'error_code'=>null,
            ];
        }
        $labels = [
            'CONFIGURED_UNTESTED'=>'EINGERICHTET · NOCH NICHT GEPRÜFT',
            'CONNECTED'=>'VERBUNDEN',
            'ERROR'=>'VERBINDUNGSFEHLER',
        ];
        $stored['label'] = $labels[$stored['status']] ?? 'UNBEKANNT';
        return $stored;
    }

    public static function recordConnectionSuccess(string $environment): array {
        $status = [
            'contract'=>'PSTE_DATAFORSEO_CONNECTION_STATUS_V1',
            'status'=>'CONNECTED',
            'provider'=>'DataForSEO',
            'tested_at_utc'=>gmdate('c'),
            'environment'=>$environment,
            'error_code'=>null,
            'updated_at_utc'=>gmdate('c'),
        ];
        update_option(PSTE_OPTION_CONNECTION_STATUS, $status, false);
        return self::connectionStatus();
    }

    public static function recordConnectionError(string $environment, string $errorCode): array {
        $safeError = substr((string)preg_replace('/[^A-Z0-9_:\-]/', '_', strtoupper($errorCode)), 0, 160);
        $status = [
            'contract'=>'PSTE_DATAFORSEO_CONNECTION_STATUS_V1',
            'status'=>'ERROR',
            'provider'=>'DataForSEO',
            'tested_at_utc'=>gmdate('c'),
            'environment'=>$environment,
            'error_code'=>$safeError !== '' ? $safeError : 'PSTE_CONNECTION_TEST_FAILED',
            'updated_at_utc'=>gmdate('c'),
        ];
        update_option(PSTE_OPTION_CONNECTION_STATUS, $status, false);
        return self::connectionStatus();
    }

    public static function mask(string $value): string {
        $len = strlen($value);
        if ($len === 0) { return '—'; }
        if ($len <= 4) { return str_repeat('•', $len); }
        return substr($value, 0, 2) . str_repeat('•', min(8, $len - 4)) . substr($value, -2);
    }

    public static function assertNoCredentialPayload(array $payload): void {
        $walk = function (array $value) use (&$walk): void {
            foreach ($value as $key => $item) {
                if (preg_match(self::SENSITIVE_KEY_PATTERN, (string)$key)) { throw new RuntimeException('PSTE_CREDENTIAL_WRITE_ATTEMPT_BLOCKED'); }
                if (is_array($item)) { $walk($item); }
            }
        };
        $walk($payload);
    }

    public static function scrub($value) {
        $credentials = self::resolve();
        $secrets = array_values(array_filter([$credentials['login'], $credentials['password']]));
        $rawBase64 = ($credentials['login'] !== '' && $credentials['password'] !== '') ? base64_encode($credentials['login'] . ':' . $credentials['password']) : '';
        $authorization = $rawBase64 !== '' ? 'Basic ' . $rawBase64 : '';
        $walk = function ($item) use (&$walk, $secrets, $rawBase64, $authorization) {
            if (is_array($item)) {
                $clean = [];
                foreach ($item as $key => $child) {
                    if (preg_match(self::SENSITIVE_KEY_PATTERN, (string)$key)) { continue; }
                    $clean[$key] = $walk($child);
                }
                return $clean;
            }
            if (is_string($item)) {
                foreach ($secrets as $secret) {
                    if ($secret !== '' && (hash_equals($secret, $item) || str_contains($item, $secret))) { return '[REDACTED]'; }
                }
                if (($rawBase64 !== '' && str_contains($item, $rawBase64)) || ($authorization !== '' && str_contains($item, $authorization))) { return '[REDACTED]'; }
            }
            return $item;
        };
        return $walk($value);
    }
}
