<?php
if (!defined('ABSPATH')) { return; }

/**
 * Coordinates the controlled return from Sandbox into the normal SEO metadata path.
 * It owns no relevance/family/title decision rules; prepare() merely reruns the existing normal gates.
 */
final class PSTE_Normal_Reentry_Coordinator {
    /** Pure/read-only reentry preparation used by runtime and fixtures. @return array<string,mixed> */
    public static function prepare(array $envelope,array $currentPayload,array $baseline): array {
        if(($envelope['contract']??'')!=='PSTE_SANDBOX_REENTRY_ENVELOPE_V1'||($envelope['status']??'')!=='AUTO_REENTRY_ELIGIBLE')throw new RuntimeException('PSTE_SANDBOX_REENTRY_ENVELOPE_NOT_ELIGIBLE');
        if(!empty($envelope['five_field_handoff_created'])||!empty($envelope['production_handoff_attempted'])||!empty($envelope['article_or_taxonomy_write_attempted']))throw new RuntimeException('PSTE_SANDBOX_REENTRY_BOUNDARY_VIOLATION');
        $poolKey=(string)($envelope['pool_key']??'');$raw=(string)($envelope['raw_query']??'');$review=(array)($envelope['review_proposal']??[]);
        if($poolKey===''||$raw===''||!preg_match('/^[a-f0-9]{64}$/',(string)($envelope['raw_query_sha256']??''))||!hash_equals(hash('sha256',$raw),(string)$envelope['raw_query_sha256']))throw new RuntimeException('PSTE_SANDBOX_REENTRY_IDENTITY_INVALID');
        $storedRaw=PSTE_Normal_Metadata_Path::canonicalInputQuery(PSTE_Editorializer::sourceQuery($currentPayload));if($storedRaw===''||!hash_equals(hash('sha256',PSTE_Normal_Metadata_Path::canonicalInputQuery($raw)),hash('sha256',$storedRaw)))throw new RuntimeException('PSTE_SANDBOX_REENTRY_RAW_QUERY_CHANGED');$raw=PSTE_Normal_Metadata_Path::canonicalInputQuery($raw);
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_REENTRY_BASELINE_REQUIRED');
        $reviewFamilyKey=(string)($review['family_key']??'');if($reviewFamilyKey==='')throw new RuntimeException('PSTE_SANDBOX_REENTRY_FAMILY_REVIEW_MISSING');
        $relevanceProof=is_array($envelope['relevance_proof']??null)?(array)$envelope['relevance_proof']:(array)($review['relevance_proof']??[]);if(!$relevanceProof)throw new RuntimeException('PSTE_SANDBOX_REENTRY_RELEVANCE_PROOF_MISSING');
        $path=PSTE_Normal_Metadata_Path::evaluateRaw($raw,$baseline,$reviewFamilyKey,$relevanceProof,$currentPayload);
        if(($path['status']??'')!=='NORMAL_PASS'||empty($path['ok']))throw new RuntimeException('PSTE_SANDBOX_REENTRY_NORMAL_PATH_NOT_PASS_'.self::safeCode((string)($path['status']??'REVIEW_REQUIRED')));
        if(!hash_equals($reviewFamilyKey,(string)($path['family_key']??'')))throw new RuntimeException('PSTE_SANDBOX_REENTRY_FAMILY_CHANGED_REVIEW_REQUIRED');
        return ['contract'=>'PSTE_SANDBOX_REENTRY_PREPARE_V2_SHARED_NORMAL_PATH','status'=>'PASS','pool_key'=>$poolKey,'raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),'family_key'=>(string)$path['family_key'],'family_name'=>(string)$path['family_name'],'article_type'=>(string)$path['article_type'],'target_category'=>(array)$path['target_category'],'normalization'=>(array)$path['normalization'],'intent_analysis'=>(array)($path['intent_analysis']??[]),'semantic_consensus'=>(array)$path['semantic_consensus'],'intent_profile'=>(array)($path['intent_profile']??[]),'title_pipeline'=>(array)$path['title_pipeline'],'relevance_proof'=>$relevanceProof,'normal_metadata_path'=>$path,'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'write_attempted'=>false];
    }

    public static function processCron(): void {
        $trigger='SANDBOX_DAILY_CRON';
        try{
            PSTE_Sandbox_Maintenance_Health::recordAttempt($trigger);
            if(!PSTE_Plugin::isReady()){
                PSTE_Sandbox_Maintenance_Health::recordFailure($trigger,'PSTE_SANDBOX_MAINTENANCE_ENGINE_NOT_READY',['status'=>'BLOCKED_NOT_READY']);
                return;
            }
            $backlog=PSTE_Semantic_Review_Sandbox::refreshInternalStructureBacklog(false);
            $reentryChecked=0;$reentryApplied=0;$reentryFailed=0;$reentryFailures=[];
            foreach(PSTE_Semantic_Review_Sandbox::automaticReentryEnvelopes(25) as $row){
                $sandboxId=(string)($row['sandbox_id']??'');$envelope=(array)($row['envelope']??[]);if($sandboxId===''||!$envelope)continue;$reentryChecked++;
                $envelopeSha=(string)($row['envelope_sha256']??'');
                try{$result=PSTE_Repository::applySandboxReentryEnvelope($envelope,$envelopeSha);}
                catch(Throwable $e){$code=self::safeCode($e->getMessage());$reentryFailed++;$reentryFailures[]=['sandbox_id'=>$sandboxId,'error_code'=>$code,'stage'=>'DB_APPLY'];PSTE_Semantic_Review_Sandbox::markNormalReentryFailed($sandboxId,$envelopeSha,$code);continue;}
                try{PSTE_Semantic_Review_Sandbox::markNormalReentryApplied($sandboxId,$envelopeSha,$result);$reentryApplied++;}
                catch(Throwable $e){$code=self::safeCode($e->getMessage());$reentryFailed++;$reentryFailures[]=['sandbox_id'=>$sandboxId,'error_code'=>$code,'stage'=>'SANDBOX_MARK_PENDING_RETRY'];/* DB receipt is durable; keep envelope eligible so next run can idempotently finish the mark. */}
            }
            $report=['contract'=>'PSTE_SANDBOX_MAINTENANCE_RUN_V1','backlog'=>$backlog,'reentry_checked'=>$reentryChecked,'reentry_applied'=>$reentryApplied,'reentry_failed'=>$reentryFailed,'reentry_failures'=>$reentryFailures,'production_handoff_created_by_sandbox'=>false,'article_or_taxonomy_write_attempted_by_sandbox'=>false];
            if((string)($backlog['status']??'')==='PARTIAL_FAILURE')PSTE_Sandbox_Maintenance_Health::recordFailure($trigger,'PSTE_SANDBOX_BACKLOG_PARTIAL_FAILURE',$report);
            else PSTE_Sandbox_Maintenance_Health::recordSuccess($trigger,$report);
        }catch(Throwable $e){
            $code=self::safeCode($e->getMessage());
            try{PSTE_Sandbox_Maintenance_Health::recordFailure($trigger,$code,['status'=>'OUTER_FAILURE']);}catch(Throwable $healthError){throw $healthError;}
        }
    }

    /** Legacy hook target. Automatic migration/retry is forbidden; explicit safe migration owns rebuilds. */
    public static function processEditorialMetadataRebuild(): void { return; }

    private static function safeCode(string $v): string {$v=strtoupper(trim($v));$v=(string)preg_replace('/[^A-Z0-9_:\-]+/','_',$v);return substr($v!==''?$v:'PSTE_NORMAL_REENTRY_FAILED',0,160);}
}
