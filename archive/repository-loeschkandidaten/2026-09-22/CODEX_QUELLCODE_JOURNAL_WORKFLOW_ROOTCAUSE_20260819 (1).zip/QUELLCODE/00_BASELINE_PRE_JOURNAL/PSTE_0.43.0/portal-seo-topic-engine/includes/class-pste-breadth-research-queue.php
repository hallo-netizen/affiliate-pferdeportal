<?php
if (!defined('ABSPATH')) { return; }

/** Persistent, fail-closed orchestrator for 1-4 thematically broad longtail research runs. */
final class PSTE_Breadth_Research_Queue {
    public const CONTRACT='PSTE_BREADTH_RESEARCH_QUEUE_V1';
    public const VERSION='1.0.0';
    private const COMPATIBLE_VERSIONS=['1.0.0','1.1.0'];
    private const MAX_ITEMS=4;
    private const TRANSIENT_COORDINATION_CODES=['PSTE_RESEARCH_STEP_ALREADY_RUNNING','PSTE_SANDBOX_LOCKED','PSTE_BUDGET_RESERVATION_LOCKED'];
    private const REPLAY_SAFE_LOCAL_FINALIZE_CODES=['PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_RAW_MISMATCH','PSTE_SNAPSHOT_STALE_OR_CHANGED'];

    public static function start(int $requestedCount,array $settings): array {
        PSTE_Plugin::assertReady();
        $requestedCount=max(1,min(self::MAX_ITEMS,$requestedCount));
        $existing=self::raw();
        if(is_array($existing)&&in_array((string)($existing['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_BREADTH_QUEUE_ALREADY_ACTIVE');
        if(PSTE_Research_Job::current()!==null)throw new RuntimeException('PSTE_RESEARCH_JOB_ALREADY_ACTIVE');
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
        $rebase=PSTE_Snapshot::rebaseResearchBaselineIfSafe($baseline);if(empty($rebase['ok']))throw new RuntimeException((string)($rebase['error_code']??'PSTE_SITE_BASELINE_STALE'));
        $baseline=(array)$rebase['baseline'];
        $candidates=self::openFamilies($baseline);
        if(!$candidates)throw new RuntimeException('PSTE_BREADTH_NO_OPEN_FAMILIES');
        $selected=self::spread($candidates,$requestedCount);
        $uuid=wp_generate_uuid4();$now=gmdate('c');
        $items=[];
        foreach($selected as $row)$items[]=[
            'category_id'=>(int)$row['category_id'],'seed'=>(string)$row['seed'],'family'=>(string)$row['family'],'root'=>(string)$row['root'],
            'status'=>'PENDING','child_job_uuid'=>'','actual_cost'=>0.0,'last_error'=>'','coordination_wait_code'=>'',
        ];
        $queue=[
            'contract'=>self::CONTRACT,'version'=>self::VERSION,'queue_uuid'=>$uuid,'status'=>'RUNNING','requested_count'=>$requestedCount,
            'item_count'=>count($items),'current_index'=>0,'completed_count'=>0,'items'=>$items,'last_error'=>'','coordination_wait_code'=>'','created_at_utc'=>$now,'updated_at_utc'=>$now,
        ];
        self::save($queue);
        return self::summary($queue);
    }

    public static function advance(string $queueUuid,array $settings,bool $explicitResume=false): array {
        $queue=self::load();
        if(!hash_equals((string)$queue['queue_uuid'],trim($queueUuid)))throw new RuntimeException('PSTE_BREADTH_QUEUE_ID_MISMATCH');
        if((string)$queue['status']==='COMPLETE')return self::summary($queue);
        if((string)$queue['status']==='OUTCOME_UNKNOWN')return self::summary($queue);
        try{$child=PSTE_Research_Job::current();}catch(Throwable $e){return self::pause($queue,self::errorCode($e));}
        $queue=self::recoverTransientCoordinationPause($queue,$child);$queue=self::recoverSafeSiteContextPause($queue,$child);
        if((string)$queue['status']==='PAUSED_ERROR'){
            if(!$explicitResume)return self::summary($queue,$child);
            $queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']='';$queue['updated_at_utc']=gmdate('c');self::save($queue);
        }
        if((string)$queue['status']!=='RUNNING')throw new RuntimeException('PSTE_BREADTH_QUEUE_STATUS_INVALID');
        $idx=(int)$queue['current_index'];
        if($idx>=(int)$queue['item_count'])return self::complete($queue);
        $item=(array)$queue['items'][$idx];
        if($child===null){
            try{
                $child=PSTE_Research_Job::start((int)$item['category_id'],(string)$item['seed'],$settings);
                $queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['child_job_uuid']=(string)$child['job_uuid'];$queue['updated_at_utc']=gmdate('c');self::save($queue);
                return self::summary($queue,$child);
            }catch(Throwable $e){$code=self::errorCode($e);if($code==='PSTE_RESEARCH_JOB_ALREADY_ACTIVE'){try{$raced=PSTE_Research_Job::current();}catch(Throwable $ignored){$raced=null;}if(is_array($raced)&&self::childMatchesItem($raced,$item)){$queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['child_job_uuid']=(string)$raced['job_uuid'];$queue['coordination_wait_code']='PSTE_RESEARCH_JOB_ALREADY_ACTIVE';$queue['items'][$idx]['coordination_wait_code']='PSTE_RESEARCH_JOB_ALREADY_ACTIVE';$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue,$raced);}return self::pause($queue,'PSTE_BREADTH_CHILD_JOB_MISMATCH');}if(self::isTransientCoordinationCode($code))return self::coordinationWait($queue,$code,null);return self::pause($queue,$code);}
        }
        $expected=(string)($queue['items'][$idx]['child_job_uuid']??'');
        if($expected!==''&&!hash_equals($expected,(string)$child['job_uuid']))return self::pause($queue,'PSTE_BREADTH_CHILD_JOB_MISMATCH');
        if($expected===''){$queue['items'][$idx]['child_job_uuid']=(string)$child['job_uuid'];$queue['items'][$idx]['status']='RUNNING';self::save($queue);}
        try{$child=PSTE_Research_Job::advance((string)$child['job_uuid'],$settings,$explicitResume);}catch(Throwable $e){
            $code=self::errorCode($e);
            if(self::isTransientCoordinationCode($code))return self::coordinationWait($queue,$code,$child);
            return self::pause($queue,$code);
        }
        $childStatus=(string)($child['status']??'');
        if($childStatus==='COMPLETE'){
            $queue['items'][$idx]['status']='COMPLETE';$queue['items'][$idx]['actual_cost']=(float)($child['actual_cost']??0.0);$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']='';$queue['coordination_wait_code']='';
            $queue['current_index']=$idx+1;$queue['completed_count']=(int)$queue['completed_count']+1;$queue['updated_at_utc']=gmdate('c');
            if((int)$queue['current_index']>=(int)$queue['item_count'])return self::complete($queue);
            self::save($queue);return self::summary($queue,null);
        }
        if($childStatus==='PAUSED_ERROR'){
            $queue['items'][$idx]['status']='PAUSED_ERROR';$queue['items'][$idx]['last_error']=(string)($child['last_error']??'PSTE_RESEARCH_PAUSED');
            return self::pause($queue,(string)$queue['items'][$idx]['last_error']);
        }
        if($childStatus==='OUTCOME_UNKNOWN'){
            $queue['items'][$idx]['status']='OUTCOME_UNKNOWN';$queue['items'][$idx]['last_error']=(string)($child['last_error']??'PSTE_PROVIDER_TRANSPORT_OUTCOME_UNKNOWN');
            $queue['status']='OUTCOME_UNKNOWN';$queue['last_error']=(string)$queue['items'][$idx]['last_error'];$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue,$child);
        }
        $wait=(string)($child['coordination_wait_code']??'');$queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['coordination_wait_code']=$wait;$queue['coordination_wait_code']=$wait;$queue['last_error']='';$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue,$child);
    }

    public static function current(): ?array {
        $q=self::raw();if($q===null)return null;self::assertQueue($q);$child=null;try{$child=PSTE_Research_Job::current();}catch(Throwable $ignored){}
        $q=self::recoverTransientCoordinationPause($q,$child);$q=self::recoverSafeSiteContextPause($q,$child);
        return self::summary($q,$child);
    }

    /** @return list<array{category_id:int,seed:string,family:string,root:string}> */
    public static function openFamilies(array $baseline): array {
        $families=PSTE_Category_Context::familyAnchors($baseline);
        $input=array_map(static fn(array $f)=>['term_id'=>(int)$f['term_id'],'name'=>(string)$f['topic_family_name'],'slug'=>(string)$f['topic_family_key']],$families);
        $progress=PSTE_Repository::categoryProgress($input);$states=[];
        foreach((array)($progress['items']??[]) as $p)$states[(int)($p['term_id']??0)]=(string)($p['state']??'');
        $rootStats=[];
        foreach($families as $f){
            $id=(int)$f['term_id'];$root=self::rootKey($id,$baseline);
            if(!isset($rootStats[$root]))$rootStats[$root]=['total'=>0,'processed'=>0];
            $rootStats[$root]['total']++;
            if(($states[$id]??'')!=='NOT_ANALYZED')$rootStats[$root]['processed']++;
        }
        $out=[];
        foreach($families as $f){$id=(int)$f['term_id'];if(($states[$id]??'')!=='NOT_ANALYZED')continue;$root=self::rootKey($id,$baseline);$out[]=['category_id'=>$id,'seed'=>(string)$f['topic_family_name'],'family'=>(string)$f['topic_family_name'],'root'=>$root,'root_processed_count'=>(int)($rootStats[$root]['processed']??0),'root_total_count'=>(int)($rootStats[$root]['total']??0)];}
        usort($out,static fn($a,$b)=>[(int)($a['root_processed_count']??0),(string)$a['root'],(string)$a['family'],(int)$a['category_id']]<=>[(int)($b['root_processed_count']??0),(string)$b['root'],(string)$b['family'],(int)$b['category_id']]);return $out;
    }

    /** @param list<array{category_id:int,seed:string,family:string,root:string}> $rows */
    public static function spread(array $rows,int $count): array {
        $count=max(1,min(self::MAX_ITEMS,$count));$groups=[];$processed=[];
        foreach($rows as $r){$root=(string)$r['root'];$groups[$root][]=$r;$processed[$root]=(int)($r['root_processed_count']??($processed[$root]??0));}
        foreach($groups as &$g)usort($g,static fn($a,$b)=>[(string)$a['family'],(int)$a['category_id']]<=>[(string)$b['family'],(int)$b['category_id']]);unset($g);
        $selected=[];
        while(count($selected)<$count){
            $roots=array_keys(array_filter($groups,static fn($g)=>$g!==[]));
            if(!$roots)break;
            usort($roots,static fn($a,$b)=>[(int)($processed[$a]??0),(string)$a]<=>[(int)($processed[$b]??0),(string)$b]);
            $moved=false;
            foreach($roots as $root){if(!$groups[$root])continue;$row=array_shift($groups[$root]);$selected[]=$row;$processed[$root]=(int)($processed[$root]??0)+1;$moved=true;if(count($selected)>=$count)break;}
            if(!$moved)break;
        }
        return $selected;
    }

    private static function rootKey(int $termId,array $baseline): string {
        foreach((array)($baseline['leaf_categories']??[]) as $leaf){if(!is_array($leaf)||(int)($leaf['term_id']??0)!==$termId)continue;$nodes=(array)($leaf['portal_path_nodes']??[]);if(isset($nodes[0])&&is_array($nodes[0])){$slug=trim((string)($nodes[0]['slug']??''));$name=trim((string)($nodes[0]['name']??''));if($slug!==''||$name!=='')return $slug!==''?$slug:$name;}$names=(array)($leaf['portal_ancestor_page_names']??[]);if(isset($names[0])&&trim((string)$names[0])!=='')return trim((string)$names[0]);}
        return 'ROOT_UNRESOLVED';
    }
    private static function recoverTransientCoordinationPause(array $queue,?array $child): array {
        $code=(string)($queue['last_error']??'');
        if((string)($queue['status']??'')!=='PAUSED_ERROR'||(!self::isTransientCoordinationCode($code)&&!self::isReplaySafeLocalFinalizeCode($code)))return $queue;
        if(!is_array($child)||(string)($child['status']??'')!=='RUNNING')return $queue;
        $idx=(int)($queue['current_index']??0);if(!isset($queue['items'][$idx])||!is_array($queue['items'][$idx]))return $queue;
        if(!self::childMatchesItem($child,(array)$queue['items'][$idx]))return $queue;
        $actual=(string)($child['job_uuid']??'');if($actual==='')return $queue;$expected=(string)($queue['items'][$idx]['child_job_uuid']??'');
        if($expected==='')$queue['items'][$idx]['child_job_uuid']=$actual;
        $queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']=$code;$queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']=$code;$queue['updated_at_utc']=gmdate('c');self::save($queue);
        return $queue;
    }
    private static function recoverSafeSiteContextPause(array $queue,?array $child): array {
        if((string)($queue['status']??'')!=='PAUSED_ERROR'||(string)($queue['last_error']??'')!=='PSTE_SITE_BASELINE_STALE')return $queue;
        if(!is_array($child)||(string)($child['status']??'')!=='RUNNING'||(string)($child['coordination_wait_code']??'')!=='PSTE_SITE_CONTEXT_REBASED_SAFE')return $queue;
        $idx=(int)($queue['current_index']??0);if(!isset($queue['items'][$idx])||!is_array($queue['items'][$idx])||!self::childMatchesItem($child,(array)$queue['items'][$idx]))return $queue;
        $queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']='PSTE_SITE_CONTEXT_REBASED_SAFE';$queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']='PSTE_SITE_CONTEXT_REBASED_SAFE';$queue['updated_at_utc']=gmdate('c');self::save($queue);return $queue;
    }

    private static function isTransientCoordinationCode(string $code): bool {return in_array($code,self::TRANSIENT_COORDINATION_CODES,true);}
    private static function isReplaySafeLocalFinalizeCode(string $code): bool {return in_array($code,self::REPLAY_SAFE_LOCAL_FINALIZE_CODES,true);}
    private static function childMatchesItem(array $child,array $item): bool {$expected=(string)($item['child_job_uuid']??'');$actual=(string)($child['job_uuid']??'');if($actual===''||($expected!==''&&!hash_equals($expected,$actual)))return false;if(isset($child['category_id'])&&(int)$child['category_id']!==(int)($item['category_id']??0))return false;if(isset($child['seed'])&&trim((string)$child['seed'])!==trim((string)($item['seed']??$child['seed'])))return false;return true;}
    private static function coordinationWait(array $queue,string $code,?array $child): array {$idx=(int)($queue['current_index']??0);if(isset($queue['items'][$idx])&&is_array($queue['items'][$idx])){$queue['items'][$idx]['status']='RUNNING';$queue['items'][$idx]['last_error']='';$queue['items'][$idx]['coordination_wait_code']=$code;}if(is_array($child)&&isset($queue['items'][$idx])&&(string)($queue['items'][$idx]['child_job_uuid']??'')==='')$queue['items'][$idx]['child_job_uuid']=(string)($child['job_uuid']??'');$queue['status']='RUNNING';$queue['last_error']='';$queue['coordination_wait_code']=$code;$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue,$child);}

    private static function complete(array $queue): array {$queue['status']='COMPLETE';$queue['last_error']='';$queue['coordination_wait_code']='';$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue);}
    private static function pause(array $queue,string $error): array {$idx=(int)$queue['current_index'];if(isset($queue['items'][$idx])){$queue['items'][$idx]['status']='PAUSED_ERROR';$queue['items'][$idx]['last_error']=$error;$queue['items'][$idx]['coordination_wait_code']='';}$queue['status']='PAUSED_ERROR';$queue['last_error']=$error;$queue['coordination_wait_code']='';$queue['updated_at_utc']=gmdate('c');self::save($queue);return self::summary($queue);}
    private static function summary(array $q,?array $child=null): array {return ['contract'=>self::CONTRACT,'queue_uuid'=>(string)$q['queue_uuid'],'status'=>(string)$q['status'],'requested_count'=>(int)$q['requested_count'],'item_count'=>(int)$q['item_count'],'current_index'=>(int)$q['current_index'],'completed_count'=>(int)$q['completed_count'],'last_error'=>(string)$q['last_error'],'coordination_wait_code'=>(string)($q['coordination_wait_code']??''),'items'=>array_map(static fn($i)=>['category_id'=>(int)$i['category_id'],'family'=>(string)$i['family'],'root'=>(string)$i['root'],'status'=>(string)$i['status'],'actual_cost'=>(float)$i['actual_cost'],'last_error'=>(string)$i['last_error'],'coordination_wait_code'=>(string)($i['coordination_wait_code']??'')],(array)$q['items']),'child'=>$child,'updated_at_utc'=>(string)$q['updated_at_utc']];}
    private static function raw(): ?array {$v=get_option(PSTE_OPTION_BREADTH_RESEARCH_QUEUE,null);if($v===null||$v===false||$v==='')return null;if(!is_array($v))throw new RuntimeException('PSTE_BREADTH_QUEUE_STORAGE_INVALID');return $v;}
    private static function load(): array {$q=self::raw();if($q===null)throw new RuntimeException('PSTE_BREADTH_QUEUE_MISSING');self::assertQueue($q);return $q;}
    private static function save(array $q): void {$q=self::withHash($q);update_option(PSTE_OPTION_BREADTH_RESEARCH_QUEUE,$q,false);$stored=get_option(PSTE_OPTION_BREADTH_RESEARCH_QUEUE,null);if(!is_array($stored)||!hash_equals((string)$q['sha256'],(string)($stored['sha256']??'')))throw new RuntimeException('PSTE_BREADTH_QUEUE_READBACK_MISMATCH');self::assertQueue($stored);}
    private static function withHash(array $q): array {$q['contract']=self::CONTRACT;$q['version']=self::VERSION;unset($q['sha256']);$q['sha256']=hash('sha256',self::canonicalJson($q));return $q;}
    private static function assertQueue(array $q): void {if(($q['contract']??'')!==self::CONTRACT||!in_array((string)($q['version']??''),self::COMPATIBLE_VERSIONS,true))throw new RuntimeException('PSTE_BREADTH_QUEUE_CONTRACT_INVALID');$decl=(string)($q['sha256']??'');$copy=$q;unset($copy['sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$decl)||!hash_equals(hash('sha256',self::canonicalJson($copy)),$decl))throw new RuntimeException('PSTE_BREADTH_QUEUE_HASH_MISMATCH');if((int)($q['item_count']??0)<1||(int)$q['item_count']>self::MAX_ITEMS)throw new RuntimeException('PSTE_BREADTH_QUEUE_SIZE_INVALID');if(!in_array((string)($q['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN','COMPLETE'],true))throw new RuntimeException('PSTE_BREADTH_QUEUE_STATUS_INVALID');}
    private static function canonicalJson($value): string {$json=wp_json_encode(self::canonicalize($value),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($json))throw new RuntimeException('PSTE_BREADTH_QUEUE_JSON_ENCODE_FAILED');return $json;}
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
    private static function errorCode(Throwable $e): string {$code=strtoupper(trim((string)$e->getMessage()));$code=(string)preg_replace('/[^A-Z0-9_:\-]/','_',$code);return substr($code!==''?$code:'PSTE_BREADTH_QUEUE_FAILED',0,180);}
}
