# Portal SEO Themenengine 0.35.0

## Anlass
Der reale PSTE-0.34-Breitenlauf konnte nach Transport-Recovery mit `PSTE_RESEARCH_STEP_ALREADY_RUNNING` fälschlich als `PAUSED_ERROR` stoppen, obwohl der Kindlauf serverseitig korrekt weiterlief.

## Root Cause
Der Kindlauf besitzt absichtlich einen 90-Sekunden-Step-Lock. Nach einer beschädigten/abgebrochenen AJAX-Transporthülle kann der Browser schneller neu laden als der ursprüngliche Serverrequest endet. 0.34.0 behandelte diesen **temporären Busy-Zustand** in der Breitenqueue wie einen fachlichen Fehler und persistierte ihn als `PAUSED_ERROR`.

## Fix
- `PSTE_RESEARCH_STEP_ALREADY_RUNNING` ist in der Breitenqueue kein Fehler mehr, sondern ein transienter Busy-Zustand.
- Die Queue bleibt `RUNNING`; es wird nichts neu gestartet und keine Provideranfrage doppelt gesendet.
- Der AJAX-Endpunkt antwortet bei Busy mit dem aktuellen persistenten Queue-Readback und einem Retry-Hinweis.
- Der Browser wartet mit Backoff und fragt anschließend erneut ab.
- 0.34.0-Queues, die ausschließlich wegen dieses bekannten Busy-Codes in `PAUSED_ERROR` stehen, werden beim sicheren Readback automatisch auf `RUNNING` zurückgeführt, sofern exakt der gebundene Kindlauf noch `RUNNING` ist.
- Echte `PAUSED_ERROR`- und `OUTCOME_UNKNOWN`-Zustände bleiben unverändert fail-closed.

## Unverändert
- Title Authority / Titelregeln
- Breiten-Auswahl und Root-Streuung
- STARTMASTER 0039 / Textmaschine
- PSERC / Workflow-Supervisor
- PPM 6.7.9
- Artikelinhalt, HTML, Design, Kategorien, URLs, Yoast und Veröffentlichung
