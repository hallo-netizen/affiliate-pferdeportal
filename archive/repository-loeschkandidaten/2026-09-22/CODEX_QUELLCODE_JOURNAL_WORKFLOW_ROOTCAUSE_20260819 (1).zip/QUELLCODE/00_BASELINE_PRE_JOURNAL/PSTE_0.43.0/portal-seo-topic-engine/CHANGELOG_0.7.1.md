# Änderungsnachweis 0.7.1-staging

## Anlass

Runtime-Befund nach Update auf 0.7.0: 61 Fundstellen, aber 0 globale Themen; Portalabgleich fälschlich COMPLETE 0/0.

## Behoben

1. Themenmigration löscht den bestehenden Themenpool nicht mehr vorab.
2. Vorhandene 0.6.1-Themen werden transaktional und in-place auf UUIDs umgestellt.
3. Ein durch 0.7.0 geleerter Themenpool wird automatisch aus der unveränderten Kandidatentabelle rekonstruiert.
4. Orphan-Fundstellen und -Zuordnungen werden erkannt und blockieren fail-closed.
5. Jeder Datenbank-Insert/Update des Themenpools, der Fundstellen und Zuordnungen wird auf Erfolg geprüft.
6. Der Portalabgleich startet erst nach bestandener Konsistenzprüfung.
7. Fehlende 0.7.x-Spalten werden vor der Migration explizit geprüft und ergänzt.
8. Erfolgreiche automatische Wiederherstellung wird im WordPress-Admin sichtbar gemeldet.

## Unverändert

Keine Änderungen an Beiträgen, Kategorien, URLs, Yoast, Redaktionsplan oder Produktionsfreigaben. Keine kostenpflichtige API-Ausführung bei Migration oder Wiederherstellung.
