<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Overlay {
    public static function build(array $run, array $candidates): array {
        $overlay = [
            'contract'=>'SEO_TOPIC_OVERLAY_V1','schema_version'=>1,
            'source_plugin'=>['slug'=>'portal-seo-topic-engine','version'=>PSTE_VERSION],
            'run'=>[
                'run_id'=>$run['run_uuid'],'created_at_utc'=>gmdate('Y-m-d\TH:i:s\Z',strtotime($run['created_at'].' UTC')),'expires_at_utc'=>gmdate('Y-m-d\TH:i:s\Z', strtotime($run['created_at'].' UTC +30 days')),
                'location'=>$run['payload']['location'] ?? 'Germany','language'=>$run['payload']['language'] ?? 'German',
                'inventory_snapshot_sha256'=>$run['snapshot']['inventory']['sha256'] ?? '',
                'structure_snapshot_sha256'=>$run['snapshot']['structure']['sha256'] ?? '',
                'editorial_plan_snapshot_sha256'=>$run['snapshot']['editorial_plan']['sha256'] ?? 'NOT_AVAILABLE',
                'estimated_cost_usd'=>(float)$run['estimated_cost'],'actual_cost_usd'=>(float)$run['actual_cost'],'status'=>$run['status'],
                'family_filter_diagnostics'=>(array)($run['payload']['family_filter_diagnostics']??[]),
                'family_identity_v2_registry_sha256'=>(string)($run['payload']['family_identity_v2_registry_sha256']??''),
            ],
            'candidates'=>$candidates,
            'topic_pool_summary'=>PSTE_Repository::topicPoolStats(),
            'portal_research_completeness'=>PSTE_Repository::researchCompleteness(),
            'writes_to_existing_system'=>false,'production_gate_active'=>false,
        ];
        $overlay = PSTE_Credentials::scrub($overlay);
        $overlay['overlay_sha256'] = hash('sha256', wp_json_encode($overlay, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        return $overlay;
    }


    public static function buildGlobalMap(array $baseline, array $progress, array $candidates): array {
        $map=[
            'contract'=>'SEO_TOPIC_MAP_V1','schema_version'=>1,
            'source_plugin'=>['slug'=>'portal-seo-topic-engine','version'=>PSTE_VERSION],
            'generated_at_utc'=>gmdate('c'),
            'site_baseline'=>$baseline,
            'category_progress'=>$progress,
            'candidates'=>$candidates,
            'topic_pool_summary'=>PSTE_Repository::topicPoolStats(),
            'portal_research_completeness'=>PSTE_Repository::researchCompleteness(),
            'writes_to_existing_system'=>false,
            'production_gate_active'=>false,
            'family_identity_v2_dry_run_status'=>self::dryRunStatus(),
            'ppc_connection'=>'NONE_INFORMATIONAL_ONLY',
        ];
        $map=PSTE_Credentials::scrub($map);
        $map['topic_map_sha256']=hash('sha256',wp_json_encode($map,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        return $map;
    }

    private static function dryRunStatus(): array {$dry=get_option(PSTE_OPTION_FAMILY_V2_DRY_RUN,[]);return is_array($dry)&&($dry['contract']??'')===PSTE_Family_Reclassification_V2::DRY_RUN_CONTRACT?['status'=>'AVAILABLE','dry_run_sha256'=>(string)($dry['dry_run_sha256']??''),'source_snapshot_sha256'=>(string)($dry['source_snapshot_sha256']??''),'item_count'=>(int)($dry['item_count']??0)]:['status'=>'NOT_RUN'];}

    public static function validate(array $overlay): void {
        if (($overlay['contract'] ?? '') !== 'SEO_TOPIC_OVERLAY_V1' || ($overlay['schema_version'] ?? 0) !== 1) { throw new RuntimeException('PSTE_OVERLAY_CONTRACT_INVALID'); }
        if (($overlay['writes_to_existing_system'] ?? true) !== false || ($overlay['production_gate_active'] ?? true) !== false) { throw new RuntimeException('PSTE_OVERLAY_SCOPE_INVALID'); }
        $hash = $overlay['overlay_sha256'] ?? ''; unset($overlay['overlay_sha256']);
        $actual = hash('sha256', wp_json_encode($overlay, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        if (!hash_equals((string)$hash, $actual)) { throw new RuntimeException('PSTE_OVERLAY_HASH_INVALID'); }
    }
}
