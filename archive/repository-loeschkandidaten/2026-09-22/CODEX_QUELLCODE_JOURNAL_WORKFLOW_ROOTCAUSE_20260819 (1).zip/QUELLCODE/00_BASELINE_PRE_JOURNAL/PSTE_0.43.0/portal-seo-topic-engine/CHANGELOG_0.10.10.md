# 0.10.10-staging

- Repariert den live belegten Batch-Radiusfehler der einmaligen Preis-Longtail-Korrektur.
- Ein semantisch nicht eindeutig auflösbarer oder manuell gebundener Einzelkandidat bleibt unverändert und wird mit Query, Pool-Schlüssel und Fehlercode protokolliert.
- Eindeutig auflösbare Kandidaten werden nicht mehr durch einen fremden Einzelproblemfall zurückgerollt.
- Nur echte globale Integritäts-, Transaktions- oder Datenbankschreibfehler führen weiterhin zum vollständigen Rollback.
- Der Adminbericht unterscheidet PASS, PARTIAL_PASS und BLOCKED und zeigt zurückgehaltene Einzelfälle an.
- Keine Änderung an Textmaschine, Artikelinhalten, HTML, Design, Qualitätsregeln, WordPress-Beiträgen, Kategorien, URLs oder Yoast-Daten.
