<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Topic_Policy {
    public const ROLE_ARTICLE_TOPIC='ARTICLE_TOPIC';
    public const ROLE_RESEARCH_KEYWORD='RESEARCH_KEYWORD';
    public const ROLE_RESEARCH_CLUSTER='RESEARCH_CLUSTER';
    public const ROLE_HEAD_TERM='HEAD_TERM';
    public const ROLE_ALREADY_COVERED='ALREADY_COVERED';
    public const ROLE_STALE='STALE_RESEARCH_TERM';
    public const ROLE_KEYWORD_VARIANT='KEYWORD_VARIANT';
    public const ROLE_NON_EDITORIAL='NON_EDITORIAL';

    public const PLAN_YES='YES';
    public const PLAN_PROVISIONAL='PROVISIONAL';
    public const PLAN_NO='NO';
    public const PLAN_BLOCKED='BLOCKED';

    public static function hardBlockCodes(): array {
        return [
            'EXACT_NORMALIZED_QUERY_DUPLICATE','SAME_INTENT_CLUSTER','CROSS_TYPE_ANSWER_EQUIVALENCE',
            'CATEGORY_HEAD_INTENT_COLLISION','CANONICAL_ARTICLE_OR_PLAN_SLOT_ALREADY_OWNED',
            'SOURCE_PROVENANCE_MISSING','SNAPSHOT_STALE_OR_CHANGED','API_DATA_INCONSISTENT',
            'BUDGET_LIMIT_EXCEEDED','PSTE_SITE_BASELINE_STALE','PSTE_TARGET_CATEGORY_NOT_FOUND',
            'STRUCTURE_CHANGED_REVIEW_REQUIRED','CONTEXT_REFRESH_FAILED','CONTEXT_REFRESH_STALE',
            'GLOBAL_IDENTITY_MIGRATION_CONFLICT','MERGE_CANDIDATE_REVIEW_REQUIRED'
        ];
    }

    public static function nonOverridableCodes(): array {
        return [
            'SOURCE_PROVENANCE_MISSING','SNAPSHOT_STALE_OR_CHANGED','API_DATA_INCONSISTENT',
            'BUDGET_LIMIT_EXCEEDED','PSTE_SITE_BASELINE_STALE','PSTE_TARGET_CATEGORY_NOT_FOUND',
            'STRUCTURE_CHANGED_REVIEW_REQUIRED','CONTEXT_REFRESH_FAILED','CONTEXT_REFRESH_STALE',
            'GLOBAL_IDENTITY_MIGRATION_CONFLICT'
        ];
    }

    public static function presentHardCodes(array $candidate): array {
        return array_values(array_intersect(self::hardBlockCodes(),array_values(array_unique(array_map('strval',(array)($candidate['reason_codes']??[]))))));
    }

    public static function presentNonOverridableCodes(array $candidate): array {
        return array_values(array_intersect(self::nonOverridableCodes(),self::presentHardCodes($candidate)));
    }

    public static function classifyRole(array $candidate): string {
        $query=PSTE_Editorializer::displayTitle($candidate);
        $reasons=(array)($candidate['reason_codes']??[]);
        $status=(string)($candidate['automatic_pool_status']??'');
        if(PSTE_Normalizer::staleYear($query)!==null||in_array('STALE_YEAR_SPECIFIC_QUERY',$reasons,true))return self::ROLE_STALE;
        if(in_array('CATEGORY_HEAD_INTENT_COLLISION',$reasons,true))return self::ROLE_HEAD_TERM;
        if(array_intersect(['EXACT_NORMALIZED_QUERY_DUPLICATE','SAME_INTENT_CLUSTER','CROSS_TYPE_ANSWER_EQUIVALENCE','CANONICAL_ARTICLE_OR_PLAN_SLOT_ALREADY_OWNED','ANSWER_EQUIVALENT_EXISTING','ANSWER_EQUIVALENT_PLANNED'],$reasons))return self::ROLE_ALREADY_COVERED;
        if(array_intersect(['EXACT_KEYWORD_VARIANT','EXACT_EDITORIAL_INTENT_VARIANT'],$reasons))return self::ROLE_KEYWORD_VARIANT;
        if(!empty($candidate['discovery_only'])){
            $sources=[];foreach((array)($candidate['evidence']??[]) as $e)$sources[]=(string)($e['source']??'');
            if(array_intersect(['PAA','PAA_RELATED'],$sources))return self::ROLE_RESEARCH_CLUSTER;
            if(PSTE_Normalizer::hasCommercialModifier($query))return self::ROLE_NON_EDITORIAL;
            return self::ROLE_RESEARCH_KEYWORD;
        }
        if(in_array($status,['PROVISIONAL_REASSIGN','REASSIGNED','REASSIGN','AUTO_RESOLVED'],true))return self::ROLE_ARTICLE_TOPIC;
        if(PSTE_Normalizer::isQuestion($query)||(string)($candidate['decision']??'')==='PASS')return self::ROLE_ARTICLE_TOPIC;
        return self::ROLE_RESEARCH_KEYWORD;
    }

    public static function planningSuitability(array $candidate,string $status,string $contextState='CURRENT'): string {
        if(!in_array($contextState,['CURRENT','NOT_REQUIRED'],true))return self::PLAN_BLOCKED;
        $role=(string)($candidate['topic_role']??self::classifyRole($candidate));
        if(in_array($status,['REVIEW_REQUIRED'],true))return self::PLAN_BLOCKED;
        if(in_array($role,[self::ROLE_RESEARCH_KEYWORD,self::ROLE_RESEARCH_CLUSTER,self::ROLE_HEAD_TERM,self::ROLE_ALREADY_COVERED,self::ROLE_STALE,self::ROLE_KEYWORD_VARIANT,self::ROLE_NON_EDITORIAL],true))return self::PLAN_NO;
        if(in_array($status,['PROVISIONAL_ACCEPTED','PROVISIONAL_REASSIGN','REASSIGN','REASSIGNED'],true))return self::PLAN_PROVISIONAL;
        if(in_array($status,['PASS','APPROVED','AUTO_RESOLVED'],true))return self::PLAN_YES;
        return self::PLAN_NO;
    }

    public static function trafficLight(string $status,string $contextState='CURRENT'): array {
        // The traffic light answers one question only: does a human need to review the topic?
        // Technical/context readiness is displayed separately and may block planning, but must
        // never repaint otherwise clear topic decisions as red.
        if($status==='REVIEW_REQUIRED')return ['code'=>'RED','label'=>'Rot','meaning'=>'Aktive fachliche Entscheidung erforderlich','action_required'=>true];
        if(in_array($status,['PROVISIONAL_ACCEPTED','PROVISIONAL_REASSIGN','REASSIGN'],true))return ['code'=>'YELLOW','label'=>'Gelb','meaning'=>'Vorläufig eingeordnet – nur eingreifen, wenn falsch','action_required'=>false];
        if(in_array($status,['PASS','APPROVED','AUTO_RESOLVED','DISCOVERY_ONLY','BLOCKED_FOR_CATEGORY','REJECTED','REASSIGNED'],true))return ['code'=>'GREEN','label'=>'Grün','meaning'=>'Keine manuelle Fachprüfung erforderlich','action_required'=>false];
        return ['code'=>'RED','label'=>'Rot','meaning'=>'Unbekannter Fachstatus – aktive Klärung erforderlich','action_required'=>true];
    }

    public static function systemState(string $contextState): array {
        if(in_array($contextState,['CURRENT','NOT_REQUIRED'],true))return ['code'=>'CURRENT','label'=>'Aktuell','blocking'=>false];
        if($contextState==='PENDING')return ['code'=>'PENDING','label'=>'Ausstehend','blocking'=>true];
        return ['code'=>'BLOCKED','label'=>'Blockiert','blocking'=>true];
    }

    public static function roleLabel(string $role): string {
        return [
            self::ROLE_ARTICLE_TOPIC=>'Artikelthema',self::ROLE_RESEARCH_KEYWORD=>'Recherchekeyword',self::ROLE_RESEARCH_CLUSTER=>'Themencluster',
            self::ROLE_HEAD_TERM=>'Oberbegriff',self::ROLE_ALREADY_COVERED=>'Bereits abgedeckt',self::ROLE_STALE=>'Veralteter Recherchebegriff',
            self::ROLE_KEYWORD_VARIANT=>'Keywordvariante',self::ROLE_NON_EDITORIAL=>'Nicht redaktioneller Suchbegriff'
        ][$role]??'Ungeklärt';
    }

    public static function planningLabel(string $value): string {
        return [self::PLAN_YES=>'JA',self::PLAN_PROVISIONAL=>'VORLÄUFIG',self::PLAN_NO=>'NEIN',self::PLAN_BLOCKED=>'BLOCKIERT'][$value]??'BLOCKIERT';
    }
}
