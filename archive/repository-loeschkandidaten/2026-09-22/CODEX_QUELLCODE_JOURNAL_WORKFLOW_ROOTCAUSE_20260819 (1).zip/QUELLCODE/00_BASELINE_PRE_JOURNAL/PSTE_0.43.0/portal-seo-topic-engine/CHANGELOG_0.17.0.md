# 0.17.0 – Sandbox Provider Fault Isolation

- Separates candidate-scoped provider task failures from job-global failures.
- One isolated retryable task failure no longer pauses the whole Sandbox batch.
- Handles DataForSEO 40101, 40103 and live-timeout 50401 with one bounded safe retry, then retains only that candidate as deferred.
- Handles 40102 as retained `UNCERTAIN_REVIEW` without automatic retry.
- Unknown or endpoint-foreign task statuses fail closed job-wide instead of being silently treated as candidate semantics.
- Preserves failed candidates with explicit provider-error evidence/history and counts every known provider-reported error/retry cost.
- Adds bounded deferred retry and a consecutive-error circuit breaker.
- Migrates an already V71-paused task error safely on explicit resume without blind resend.
- No changes to matcher, relevance semantics, text machine, PPM, compiler, HTML/CSS/design, articles or production handoff.
