# Portal SEO Themenengine 0.18.0 – Dual-Strang + Sandbox-Reentry

## Ziel
Ein durchgehender Metadatenprozess vom unveränderten Rohkeyword bis zu redaktionell geprüften Planungsmetadaten. Die Textmaschine, Artikelinhalte, HTML, Design und bestehende Beiträge bleiben außerhalb des Schreib- und Entscheidungsbereichs.

## Änderungen
- Rohkeyword bleibt unverändert erhalten und wird per SHA-256 gebunden.
- Redaktionelle Themen-Normalisierung vor Titelbildung und vor echter Strukturlückenentscheidung.
- Getrennte Titel-Erzeugung und unabhängige redaktionelle Qualitätsprüfung.
- Technischer und redaktionell-semantischer Prüfstrang mit hartem AND-Gate.
- Kein Verbatim-/Wortstamm-Zwang zwischen Zielkeyword und Titel.
- Sandbox in denselben Gesamtprozess integriert: Relevanz/Evidenz -> Normalisierung -> aktuelle Strukturprüfung -> kontrollierter Reentry.
- `STRUCTURE_GAP` erst nach erneuter Prüfung gegen die aktuelle Portalstruktur.
- Strukturlücken behalten Rohkeyword und Planungskandidat; Kategorievorschläge sind ausschließlich Vorschläge und können keine Taxonomie anlegen.
- Planungstitel bei unbestätigter Struktur sind immer `REVIEW_REQUIRED` und können keinen Reentry freischalten.
- Regelmäßige providerfreie interne Neuprüfung relevanter Strukturlücken (7-Tage-Fälligkeit, täglich registrierter Cron).
- Automatischer Reentry nur nach vollständigem Neu-Durchlauf der normalen Semantik- und Titelgates; Sandbox erzeugt nie den 5-Feld-Handoff selbst.
- Bestehende Provider-Fault-Isolation bleibt unverändert.

## Unveränderte Grenze
Nur der spätere Compiler darf exakt `title`, `target_keyword`, `category`, `article_type`, `plan_slot` weiterreichen. Kein Inhalt, keine Gliederung, keine Fakten, keine Format-/Designvorgaben.
