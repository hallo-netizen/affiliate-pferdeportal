# 0.18.1

- Behebt den live nachgewiesenen Upgradefehler von 0.18.0: Ein unverändertes DB-Schema 12 durfte die Themenengine als READY markieren, obwohl der neue redaktionelle Metadaten-Regelstand noch nicht auf den bestehenden Themenpool angewendet war.
- READY verlangt jetzt zusätzlich den aktuellen `PSTE_Editorializer::RULESET`-Marker.
- Der Metadaten-Rebuild ist nicht mehr von einem best-effort WP-Cron abhängig: Er wird für die eigene SEO-Metadatenbank deterministisch und fail-closed beim nächsten Admin-Boot ausgeführt; Aktivierung und sichere Migration benutzen denselben zentralen Pfad.
- Fehler bleiben sichtbar als BLOCKED statt still im Cron verschluckt zu werden.
- Der Rebuild protokolliert einen eigenen Auditdatensatz.
- Rohkeywords/Keyword-Evidenz bleiben durch eine transaktionale Invarianzprüfung geschützt.
- Keine Beiträge, Terms, Textmaschine, Produktionsprompts, Design- oder Inhaltsdaten werden geändert.
