# 0.23.0 – E2E Root-Cause / Fault-Isolation / Derived-State Authority

- Behebt den realen WordPress-Liveblocker von 0.22.0 als Ursachenklasse: ein portalrelevantes Keyword darf bei ungeklärter Familie in die interne Sandbox aufgenommen werden.
- Führt einen gemeinsamen Sandbox-Zulassungsrouter mit Trennung von kandidatenbezogenen Fehlern und globalen Infrastruktur-/Integritätsfehlern ein. Kandidatenfehler bleiben sichtbar und retained; sie blockieren nicht den gesamten Bestand.
- Bewahrt historische externe/humane Relevanzevidenz unverändert; aktuelle interne Relevanz wird separat als `current_relevance_proof` geführt.
- Historische abgeleitete Pfad-/Status-/Familienfelder sind keine aktuelle Autorität. Der aktuelle Derived-State wird vollständig neu berechnet und mit `PSTE_DERIVED_STATE_AUTHORITY_V1` gebunden.
- `READY_FOR_COMPILER_CAPABILITY_CHECK` besitzt nur noch eine Autorität: den aktuellen gemeinsamen Normalpfad. Recovery-/Legacy-Backfill darf nicht READY setzen.
- Portalrelevanz bleibt die erste fachliche Entscheidung; Familienhinweise davor sind Evidence-only und besitzen keine Assignment-Autorität.
- Aktivierung, Admin-GET und der historische Editorial-Rebuild-Cron migrieren nicht mehr automatisch. Migration/Cleanup/Scheduling gehören ausschließlich dem expliziten sicheren Migrations-POST.
- Rohkeywords, Sandboxbestand, Strukturlücken und Reentry-Evidenz bleiben unverlierbar; keine Artikel-/Taxonomie-/Design-/Textmaschinen-Schreibpfade hinzugefügt.
- Textmaschinen-Grenze unverändert: ausschließlich `title`, `target_keyword`, `category`, `article_type`, `plan_slot`.
