<?php
if (!defined('ABSPATH')) { return; }

/**
 * Independent semantic strand A.
 * It receives the query, the read-only taxonomy registry and a research-family scope.
 * It never receives a proposed target category, a proposed type or strand B output.
 */
final class PSTE_Semantic_Retriever_A {
    /** @return array<string,mixed> */
    public static function retrieve(string $query,array $registry,string $familyKey): array {
        $family=self::family($registry,$familyKey);
        if(!$family)return self::blocked('A_FAMILY_SCOPE_NOT_IN_REGISTRY',$registry,$familyKey,[]);
        $scores=[];$reasons=[];$available=self::available($family);$intentQuery=self::withoutFamilyPhrase($query,(string)($family['topic_family_name']??''));
        if(PSTE_Normalizer::isQuestion($intentQuery))self::score($scores,$reasons,'FAQ',120,'A_QUESTION_MEANING',$available);
        $alias=self::registryAlias($intentQuery,$registry,$available);if($alias!=='')self::score($scores,$reasons,$alias,110,'A_EXPLICIT_TYPE_ALIAS',$available);
        foreach(PSTE_Article_Type_Intent_Ontology::strongSignals($intentQuery,$available) as $type)self::score($scores,$reasons,$type,88,'A_EXPLICIT_INTENT_ONTOLOGY_SIGNAL',$available);
        $ambiguous=PSTE_Article_Type_Intent_Ontology::ambiguousNonSignalHits($intentQuery);
        if(!$scores&&!$ambiguous&&!self::transactional($intentQuery)&&count(PSTE_Normalizer::tokens($intentQuery))>=1)self::score($scores,$reasons,'Beratung',52,'A_NEUTRAL_INFORMATIONAL_TOPIC',$available);
        if(!$scores&&$ambiguous)$reasons['__review__']=$ambiguous;
        return self::finish($scores,$reasons,$registry,$familyKey,$family);
    }

    /** @return array<string,mixed> */
    private static function finish(array $scores,array $reasons,array $registry,string $familyKey,array $family): array {
        arsort($scores,SORT_NUMERIC);$rows=[];
        foreach($scores as $canonical=>$score){
            $type=PSTE_Article_Type_Registry::visibleType($registry,$canonical);$target=PSTE_Article_Type_Registry::resolve($registry,$familyKey,$type);
            $rows[]=['canonical_type_id'=>$canonical,'article_type'=>$type,'score'=>$score,'reason_codes'=>array_values(array_unique((array)($reasons[$canonical]??[]))),
                'category_id'=>!empty($target['ok'])?(int)$target['term_id']:0,'category_slug'=>!empty($target['ok'])?(string)$target['slug']:'','category_name'=>!empty($target['ok'])?(string)$target['name']:'',
                'category_full_path'=>!empty($target['ok'])?(string)($target['full_path']??''):'','topic_family_key'=>$familyKey,'topic_family_name'=>(string)($family['topic_family_name']??''),'category_available'=>!empty($target['ok'])];
        }
        $top=(int)($rows[0]['score']??0);$runner=(int)($rows[1]['score']??0);$margin=$top-$runner;$assigned=false;$reason='A_NO_UNAMBIGUOUS_SIGNAL';
        if(count($rows)===1){$assigned=true;$reason=(string)($rows[0]['reason_codes'][0]??'A_ASSIGNED');}
        elseif(count($rows)>1&&$margin>=25){$assigned=true;$reason=(string)($rows[0]['reason_codes'][0]??'A_ASSIGNED_MARGIN');}
        elseif(count($rows)>1)$reason='A_RETRIEVER_AMBIGUOUS_REVIEW';
        $topRow=$assigned?(array)$rows[0]:[];$target=[];
        if($assigned&&!empty($topRow['category_available']))$target=PSTE_Article_Type_Registry::resolve($registry,$familyKey,(string)$topRow['article_type']);
        return ['contract'=>'PSTE_RETRIEVER_RESULT_V1','strand'=>'A','status'=>$assigned?'ASSIGNED':'BLOCKED','article_type'=>$assigned?(string)$topRow['article_type']:'','reason'=>$reason,
            'meaning'=>self::meaning($topRow),'search_intent'=>self::intent($topRow),'topic_family_key'=>$familyKey,'topic_family_name'=>(string)($family['topic_family_name']??''),'target_category'=>$target,
            'candidates'=>$rows,'top_score'=>$top,'runner_up_score'=>$runner,'score_margin'=>$margin,'candidate_set_hash'=>hash('sha256',self::json($rows)),
            'coverage_status'=>$rows?'COVERAGE_PRESENT':'COVERAGE_MISSING','ambiguity_status'=>count($rows)>1&&$margin<25?'AMBIGUOUS':'CLEAR',
            'index_hash'=>hash('sha256',self::json(['family'=>$family,'registry_sha256'=>(string)($registry['registry_sha256']??'')])),'structure_hash'=>(string)($registry['structure_sha256']??''),
            'input_contract'=>['query_only'=>true,'family_scope_only'=>true,'proposed_type_received'=>false,'proposed_category_received'=>false,'other_strand_received'=>false]];
    }

    /** @return array<string,mixed> */
    private static function blocked(string $reason,array $registry,string $familyKey,array $rows): array {return ['contract'=>'PSTE_RETRIEVER_RESULT_V1','strand'=>'A','status'=>'BLOCKED','article_type'=>'','reason'=>$reason,'meaning'=>'','search_intent'=>'UNKNOWN','topic_family_key'=>$familyKey,'topic_family_name'=>'','target_category'=>[],'candidates'=>$rows,'top_score'=>0,'runner_up_score'=>0,'score_margin'=>0,'candidate_set_hash'=>hash('sha256',self::json($rows)),'coverage_status'=>'COVERAGE_MISSING','ambiguity_status'=>'CLEAR','index_hash'=>hash('sha256',self::json($registry)),'structure_hash'=>(string)($registry['structure_sha256']??''),'input_contract'=>['query_only'=>true,'family_scope_only'=>true,'proposed_type_received'=>false,'proposed_category_received'=>false,'other_strand_received'=>false]];}
    private static function family(array $registry,string $key): array {$v=$registry['families'][$key]??null;return is_array($v)?$v:[];}
    /** @return list<string> */ private static function available(array $family): array {$out=[];foreach((array)($family['by_type']??[]) as $row)$out[]=(string)($row['article_type']??'');return array_values(array_filter($out));}
    private static function score(array &$scores,array &$reasons,string $type,int $score,string $reason,array $available): void {$canonical=PSTE_Article_Type_Registry::canonicalType($type);$found=false;foreach($available as $x)if(PSTE_Article_Type_Registry::canonicalType($x)===$canonical){$found=true;break;}if(!$found)return;$scores[$canonical]=max((int)($scores[$canonical]??0),$score);$reasons[$canonical][]=$reason;}
    private static function registryAlias(string $query,array $registry,array $available): string {$q=PSTE_Normalizer::exactTopicIdentityText($query);foreach($available as $type){foreach(PSTE_Article_Type_Registry::aliasesFor($registry,$type) as $alias){$a=PSTE_Normalizer::exactTopicIdentityText($alias);if($a!==''&&preg_match('/(?:^|\s)'.preg_quote($a,'/').'(?:\s|$)/u',$q))return $type;}}return '';}
    private static function withoutFamilyPhrase(string $query,string $family): string {
        $family=trim($family);if($family==='')return trim($query);
        $stripped=preg_replace('/'.preg_quote($family,'/').'/iu',' ',trim($query),1);
        return trim((string)preg_replace('/\s+/u',' ',$stripped??$query));
    }
    private static function transactional(string $q): bool {return (bool)preg_match('/\b(sale|rabatt|gutschein|coupon|shop|online\s+kaufen|bestellen)\b/iu',$q);}
    private static function meaning(array $row): string {return (string)($row['article_type']??'')===''?'':('PORTAL_TOPIC_'.strtoupper(str_replace(' ','_',PSTE_Article_Type_Registry::canonicalType((string)$row['article_type']))));}
    private static function intent(array $row): string {$c=PSTE_Article_Type_Registry::canonicalType((string)($row['article_type']??''));return $c==='faq'?'QUESTION_INFORMATION':($c==='vergleich'?'COMPARISON_INFORMATION':($c==='kosten'?'COST_INFORMATION':'EDITORIAL_INFORMATION'));}
    private static function json($v): string {$j=function_exists('wp_json_encode')?wp_json_encode(self::canonicalize($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode(self::canonicalize($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($j)?$j:'';}
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
}
