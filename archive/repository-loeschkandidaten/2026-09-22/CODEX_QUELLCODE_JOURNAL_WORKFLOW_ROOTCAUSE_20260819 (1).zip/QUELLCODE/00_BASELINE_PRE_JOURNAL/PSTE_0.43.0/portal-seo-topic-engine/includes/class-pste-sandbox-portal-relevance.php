<?php
if (!defined('ABSPATH')) { return; }

/**
 * Read-only diagnostics for NEWLY_BLOCKED longtails.
 * IMPORTANT: local portal-context, family proximity and exclusion signals are evidence only.
 * They MUST NOT decide portal relevance. Relevance is established separately from real SEO/SERP
 * evidence (or a later explicit human review), before any internal family/category/title planning.
 */
final class PSTE_Sandbox_Portal_Relevance {
    public const CONTRACT='PSTE_SANDBOX_PORTAL_RELEVANCE_DIAGNOSTICS_V2';
    public const POLICY='EVIDENCE_BEFORE_INTERNAL_V4';

    /** @return array<string,mixed> */
    public static function route(string $query,array $item,array $registry,array $baseline,bool $sourceCurrent=true): array {
        $diag=(array)($item['resolution']['rejection_diagnostics']??[]);
        $nearest=array_values((array)($diag['nearest_rejected_families']??[]));
        $portal=PSTE_Category_Context::portalContextEvidence($query,$baseline);
        $exclusions=self::exclusionEvidence($query,$registry,$nearest);
        if(!$sourceCurrent){
            return [
                'contract'=>self::CONTRACT,'policy'=>self::POLICY,'query'=>$query,
                'workflow_lane'=>'SOURCE_STALE_REVIEW_REQUIRED','status'=>'SOURCE_STALE_REVIEW_REQUIRED',
                'requires_external_review'=>false,'reason_codes'=>['PSTE_SANDBOX_SOURCE_ROW_CHANGED_SINCE_DRY_RUN'],
                'nearest_count'=>count($nearest),'portal_context'=>$portal,'exclusion_evidence'=>$exclusions,'source_current'=>false,
                'local_relevance_decision_enabled'=>false,'production_handoff_attempted'=>false,'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,
            ];
        }
        $reasons=['PSTE_SANDBOX_RELEVANCE_EVIDENCE_REQUIRED_BEFORE_INTERNAL_ROUTING'];
        if(count($nearest)>=1)$reasons[]='PSTE_SANDBOX_NEAREST_FAMILY_DIAGNOSTIC_ONLY';
        if(!empty($portal['portal_context_present']))$reasons[]='PSTE_SANDBOX_PORTAL_CONTEXT_DIAGNOSTIC_ONLY';
        if(!empty($exclusions['nearest_family_active'])||!empty($exclusions['registry_wide_hit_count']))$reasons[]='PSTE_SANDBOX_EXCLUSION_EVIDENCE_RETAINED_NOT_RELEVANCE_VERDICT';
        return [
            'contract'=>self::CONTRACT,'policy'=>self::POLICY,'query'=>$query,
            'workflow_lane'=>'EXTERNAL_RELEVANCE_REVIEW','status'=>'PENDING_EXTERNAL_RELEVANCE',
            'requires_external_review'=>true,'reason_codes'=>$reasons,'nearest_count'=>count($nearest),
            'portal_context'=>$portal,'exclusion_evidence'=>$exclusions,'source_current'=>true,
            'local_relevance_decision_enabled'=>false,'production_handoff_attempted'=>false,'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,
        ];
    }

    /** Every record gets an explicit exclusion-evidence object, even when there are zero hits. @return array<string,mixed> */
    public static function exclusionEvidence(string $query,array $registry,array $nearest=[]): array {
        $nearestHits=[];
        foreach($nearest as $row){
            if(!is_array($row))continue;$excluded=array_values((array)($row['details']['excluded_matches']??$row['excluded_matches']??[]));
            if($excluded)$nearestHits[]=['family_key'=>(string)($row['family_key']??''),'family_name'=>(string)($row['family_name']??''),'excluded_matches'=>$excluded];
        }
        $registryHits=[];$definitions=[];
        foreach((array)($registry['families']??[]) as $key=>$family){
            $identity=(array)($family['identity_v2']??[]);
            $defs=['excluded_concept_groups'=>(array)($identity['excluded_concept_groups']??[]),'excluded_phrases'=>(array)($identity['excluded_phrases']??[]),'forbidden_relation_tokens'=>(array)($identity['forbidden_relation_tokens']??[])];
            if($defs['excluded_concept_groups']||$defs['excluded_phrases']||$defs['forbidden_relation_tokens'])$definitions[(string)$key]=$defs;
            if(!$identity)continue;$evaluation=PSTE_Family_Identity_V2::evaluate($query,$identity);$details=(array)($evaluation['details']??[]);$excluded=array_values((array)($details['excluded_matches']??[]));$codes=array_values(array_intersect((array)($evaluation['reason_codes']??[]),['PSTE_FAMILY_V2_EXCLUDED_PHRASE','PSTE_FAMILY_V2_EXCLUDED_CONCEPT','PSTE_FAMILY_V2_EXCLUDED_CONTEXT_IN_COMPARISON']));
            $context=(array)($details['context']??[]);if((string)($context['source']??'')==='FORBIDDEN_RELATION')$codes[]='PSTE_FAMILY_V2_FORBIDDEN_RELATION';
            if($excluded||$codes)$registryHits[]=['family_key'=>(string)$key,'family_name'=>(string)($family['topic_family_name']??''),'excluded_matches'=>$excluded,'reason_codes'=>array_values(array_unique($codes))];
        }
        ksort($definitions,SORT_STRING);
        return [
            'contract'=>'PSTE_SANDBOX_EXCLUSION_EVIDENCE_V1','nearest_family_active'=>!empty($nearestHits),'nearest_family_hits'=>$nearestHits,
            'registry_wide_hit_count'=>count($registryHits),'registry_wide_hits'=>$registryHits,
            'registry_exclusion_definitions_sha256'=>self::hash($definitions),'evaluated_family_count'=>count((array)($registry['families']??[])),
            'decision_scope'=>'DIAGNOSTIC_AND_POST_RELEVANCE_INTERNAL_ASSIGNMENT_GUARD_ONLY','portal_relevance_auto_rejection_enabled'=>false,'write_attempted'=>false,
        ];
    }

    /** Retained only as an explicit non-decision evidence envelope. It may never unlock the planner. @return array<string,mixed> */
    public static function localReviewEvidence(array $route): array {
        return [
            'contract'=>'PSTE_SANDBOX_LOCAL_DIAGNOSTIC_EVIDENCE_V2','status'=>'DIAGNOSTIC_ONLY_NOT_A_RELEVANCE_DECISION',
            'reason_codes'=>(array)($route['reason_codes']??[]),'workflow_lane'=>(string)($route['workflow_lane']??''),
            'portal_context'=>(array)($route['portal_context']??[]),'exclusion_evidence'=>(array)($route['exclusion_evidence']??[]),
            'decision_scope'=>'DIAGNOSTIC_ONLY','automatic_production_enabled'=>false,'may_unlock_internal_planner'=>false,
            'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,
        ];
    }

    private static function hash($v): string {$j=function_exists('wp_json_encode')?wp_json_encode(self::canonicalize($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode(self::canonicalize($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return hash('sha256',(string)$j);}
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
}
