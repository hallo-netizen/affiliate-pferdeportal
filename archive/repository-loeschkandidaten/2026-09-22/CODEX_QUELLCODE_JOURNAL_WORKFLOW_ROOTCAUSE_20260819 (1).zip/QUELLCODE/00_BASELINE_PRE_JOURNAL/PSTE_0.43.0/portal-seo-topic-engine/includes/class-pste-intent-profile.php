<?php
if (!defined('ABSPATH')) { return; }

/**
 * SEO-first intent evidence for metadata planning only.
 * Two phase contract:
 * 1) analyzeBeforeType() establishes the searched goal/focus before an article type is accepted.
 * 2) bindArticleType() verifies that the independent semantic classifier chose a compatible type.
 *
 * It never writes content, taxonomy, prompts, HTML, formatting or production payloads.
 */
final class PSTE_Intent_Profile {
    public const CONTRACT='PSTE_INTENT_PROFILE_V2_SEO_FIRST_EVIDENCE_BOUND_MULTI_BRANCH';

    /** @return array<string,mixed> */
    public static function analyzeBeforeType(string $raw,array $normalization,string $family,array $sourceEvidence=[]): array {
        $raw=self::clean($raw);$family=self::clean($family);
        $qualifier=self::clean((string)($normalization['qualifier']??''));
        $subject=self::clean((string)($normalization['subject_topic']??$normalization['normalized_topic']??$raw));
        $relation=self::clean((string)($normalization['relation']??''));
        $providerIntent=self::clean((string)($sourceEvidence['metrics']['search_intent']??$sourceEvidence['search_intent']??''));
        $providerProbability=(float)($sourceEvidence['metrics']['intent_probability']??$sourceEvidence['intent_probability']??0.0);
        $intentTuple=is_array($sourceEvidence['intent_tuple']??null)?(array)$sourceEvidence['intent_tuple']:[];
        $decision=self::clean((string)($intentTuple['decision_or_problem']??''));
        $context=self::clean((string)($intentTuple['context']??''));
        $answerPromise=self::clean((string)($intentTuple['answer_promise']??''));
        $goal=self::clean((string)($intentTuple['user_goal']??''));
        $focus=$qualifier!==''?$qualifier:($decision!==''?$decision:$subject);

        [$primaryGoal,$primaryType,$angle]=self::primaryIntent($raw,$qualifier,$decision);
        $secondary=self::secondaryFromSeoEvidence($raw,$family,$qualifier,$sourceEvidence,$primaryType);
        $basis=[];
        if($providerIntent!=='')$basis[]='DATAFORSEO_SEARCH_INTENT';
        if($intentTuple)$basis[]='SEO_INTENT_TUPLE';
        if(!empty($sourceEvidence['evidence']))$basis[]='SEO_OBSERVATION_EVIDENCE';
        if(!$basis)$basis[]='LEXICAL_QUERY_FALLBACK_NO_PROVIDER_PAYLOAD';

        $reasons=[];
        if($raw==='')$reasons[]='PSTE_INTENT_RAW_QUERY_MISSING';
        if($family==='')$reasons[]='PSTE_INTENT_FAMILY_MISSING';
        if($primaryGoal==='')$reasons[]='PSTE_INTENT_PRIMARY_GOAL_MISSING';
        if($primaryType==='')$reasons[]='PSTE_INTENT_PRIMARY_TYPE_CANDIDATE_MISSING';
        if($angle==='')$reasons[]='PSTE_INTENT_ANGLE_MISSING';
        if(!$reasons)$reasons[]='PSTE_INTENT_SEO_FIRST_ANALYSIS_PASS';
        $status=count($reasons)===1&&$reasons[0]==='PSTE_INTENT_SEO_FIRST_ANALYSIS_PASS'?'PASS':'REVIEW_REQUIRED';
        $out=[
            'contract'=>self::CONTRACT,'phase'=>'PRE_TYPE','status'=>$status,'ok'=>$status==='PASS','intent_first'=>true,
            'raw_query'=>$raw,'family'=>$family,'subject_topic'=>$subject,'qualifier'=>$qualifier,'qualifier_relation'=>$relation,'focus_term'=>$focus,
            'qualifier_must_be_preserved'=>$qualifier!=='','primary_user_goal'=>$primaryGoal,'primary_article_type_candidate'=>$primaryType,'intent_angle'=>$angle,
            'provider_search_intent'=>$providerIntent,'provider_intent_probability'=>$providerProbability,
            'intent_tuple'=>['user_goal'=>$goal,'decision_or_problem'=>$decision,'context'=>$context,'answer_promise'=>$answerPromise],
            'seo_basis'=>$basis,'secondary_branches'=>$secondary,
            'secondary_branch_policy'=>'ONLY_WHEN_DISTINCT_SEO_EVIDENCE_EXISTS_RESEARCH_PROPOSAL_ONLY',
            'auto_fanout_allowed'=>false,'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'write_attempted'=>false,
            'reason_codes'=>$reasons,
        ];
        $out['analysis_sha256']=self::hash($out);
        return $out;
    }

    /** @return array<string,mixed> */
    public static function bindArticleType(array $analysis,array $semantic,array $registry,string $familyKey): array {
        $type=trim((string)($semantic['resolved_article_type']??''));
        $canon=PSTE_Article_Type_Registry::canonicalType($type);
        $intentA=trim((string)($semantic['strand_a']['search_intent']??''));
        $intentB=trim((string)($semantic['strand_b']['search_intent']??''));
        $intentConsensus=!empty($semantic['intent_consensus'])&&$intentA!==''&&hash_equals($intentA,$intentB);
        $searchIntent=$intentConsensus?$intentA:'';
        $expectedCanon=PSTE_Article_Type_Registry::canonicalType((string)($analysis['primary_article_type_candidate']??''));
        $typeCompatible=$expectedCanon===''||$canon===$expectedCanon||self::compatibleFallback($expectedCanon,$canon);
        $available=PSTE_Article_Type_Registry::availableTypes($registry,$familyKey);
        $typeAvailable=$type!==''&&in_array($type,$available,true);
        $reasons=[];
        if(($analysis['status']??'')!=='PASS')$reasons[]='PSTE_INTENT_PRE_TYPE_ANALYSIS_NOT_PASS';
        if($type==='')$reasons[]='PSTE_INTENT_ARTICLE_TYPE_MISSING';
        if($searchIntent==='')$reasons[]='PSTE_INTENT_SEARCH_INTENT_NOT_CONSENSUS_PROVEN';
        if(!$typeCompatible)$reasons[]='PSTE_INTENT_CLASSIFIER_TYPE_CONFLICT';
        if(!$typeAvailable)$reasons[]='PSTE_INTENT_ARTICLE_TYPE_NOT_AVAILABLE_IN_FAMILY';
        if(!$reasons)$reasons[]='PSTE_INTENT_PRIMARY_ROUTE_PROVEN';
        $status=count($reasons)===1&&$reasons[0]==='PSTE_INTENT_PRIMARY_ROUTE_PROVEN'?'PASS':'REVIEW_REQUIRED';

        $identity=implode('|',[
            PSTE_Normalizer::categoryFamilyKey((string)($analysis['family']??'')),$type,$searchIntent,(string)($analysis['intent_angle']??''),
            PSTE_Normalizer::exactTopicIdentityText((string)($analysis['subject_topic']??$analysis['raw_query']??'')),
            PSTE_Normalizer::exactTopicIdentityText((string)($analysis['focus_term']??'')),
        ]);
        $out=$analysis;
        $out['phase']='BOUND_TYPE';$out['status']=$status;$out['ok']=$status==='PASS';$out['article_type']=$type;$out['search_intent']=$searchIntent;
        $out['semantic_intent_consensus']=$intentConsensus;$out['classifier_type_compatible_with_pre_type_intent']=$typeCompatible;$out['article_type_available']=$typeAvailable;
        $out['intent_key']=hash('sha256',$identity);$out['reason_codes']=$reasons;
        $out['secondary_branches']=array_values(array_map(static function($b)use($available){$b=is_array($b)?$b:[];$t=(string)($b['article_type']??'');$b['article_type_available']=in_array($t,$available,true);$b['production_eligible']=false;$b['auto_fanout']=false;$b['five_field_handoff_allowed']=false;return $b;},(array)($analysis['secondary_branches']??[])));
        unset($out['analysis_sha256']);$out['profile_sha256']=self::hash($out);
        return $out;
    }

    /**
     * Derives the SEO target keyphrase that the unchanged Production Machine can bind verbatim inside the title.
     * The raw discovery query remains separately immutable; target_keyword is a meaning-preserving production keyphrase,
     * not an excuse to force awkward raw-keyword word order into the headline.
     * @return array<string,mixed>
     */
    public static function targetKeyword(string $raw,array $normalization,string $type,array $intentProfile=[]): array {
        $raw=self::clean($raw);$canon=PSTE_Article_Type_Registry::canonicalType($type);
        $subject=self::keywordSurface((string)($normalization['subject_topic']??$normalization['normalized_topic']??$raw));
        $action=self::keywordSurface((string)($normalization['detected_action']??''));
        $keyword='';$source='NORMALIZED_SUBJECT';
        if($canon==='faq'){
            $keyword=self::keywordSurface(rtrim(PSTE_Normalizer::canonicalQuestion($raw),'?'));
            $source='CANONICAL_QUESTION_WITHOUT_PUNCTUATION';
        }elseif($canon==='pflege'&&$subject!==''&&$action!==''){
            $keyword=trim($subject.' '.$action);$source='NORMALIZED_SUBJECT_PLUS_PROCEDURAL_ACTION';
        }elseif($canon==='kosten'&&$subject!==''){
            $keyword=trim('Kosten für '.$subject);$source='NORMALIZED_SUBJECT_PLUS_COST_INTENT';
        }elseif($canon==='beratung'&&$subject!==''&&preg_match('/\b(kaufen|kaufberatung)\b/iu',$raw)){
            $keyword=trim($subject.' kaufen');$source='NORMALIZED_SUBJECT_PLUS_EXPLICIT_BUY_INTENT';
        }else{
            $keyword=$subject;
        }
        $reasons=[];
        if($keyword==='')$reasons[]='PSTE_TARGET_KEYWORD_EMPTY';
        if($subject!==''&&$keyword!==''&&!PSTE_Token_Equivalence::contains($keyword,$subject))$reasons[]='PSTE_TARGET_KEYWORD_SUBJECT_NOT_PRESERVED';
        $qualifier=self::keywordSurface((string)($intentProfile['qualifier']??$normalization['qualifier']??''));
        if($qualifier!==''&&!PSTE_Token_Equivalence::contains($keyword,$qualifier)&&PSTE_Token_Equivalence::contains($subject,$qualifier))$reasons[]='PSTE_TARGET_KEYWORD_QUALIFIER_NOT_PRESERVED';
        $ok=$reasons===[];
        $out=[
            'contract'=>'PSTE_TARGET_KEYWORD_V1_INTENT_BOUND_PPM_TITLE_COMPATIBLE','status'=>$ok?'PASS':'REVIEW_REQUIRED','ok'=>$ok,
            'target_keyword'=>$keyword,'source'=>$source,'raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'',
            'raw_query_remains_separately_preserved'=>true,'target_keyword_is_not_required_to_equal_raw_query'=>true,
            'ppm_exact_title_substring_required'=>true,'intent_profile_sha256'=>(string)($intentProfile['profile_sha256']??''),
            'reason_codes'=>$reasons,'write_attempted'=>false,
        ];
        $out['target_keyword_sha256']=$keyword!==''?hash('sha256',$keyword):'';
        return $out;
    }

    /** Backward-compatible one-call helper for local tests and non-production analysis. @return array<string,mixed> */
    public static function resolve(string $raw,array $normalization,string $family,array $semantic,array $registry,string $familyKey,array $sourceEvidence=[]): array {
        return self::bindArticleType(self::analyzeBeforeType($raw,$normalization,$family,$sourceEvidence),$semantic,$registry,$familyKey);
    }

    /** @return array{0:string,1:string,2:string} */
    private static function primaryIntent(string $raw,string $qualifier,string $decision): array {
        $q=self::lower($raw);
        if(PSTE_Normalizer::isQuestion($raw)){
            $angle='question_answer';
            if(preg_match('/^warum\b/u',$q))$angle='reason';elseif(preg_match('/^wann\b/u',$q))$angle='timing_suitability';elseif(preg_match('/^wie\b/u',$q))$angle='method_or_degree';elseif(preg_match('/^(welcher|welche|welches)\b/u',$q))$angle='selection_question';elseif(preg_match('/^was\b/u',$q))$angle='definition_or_cost_question';
            return ['DIRECT_QUESTION','FAQ',$angle];
        }
        $signals=PSTE_Article_Type_Intent_Ontology::strongSignals($raw);
        if(count($signals)>1)return ['AMBIGUOUS_EXPLICIT_INTENT','',''];
        if(count($signals)===1){
            $type=(string)$signals[0];
            $goal=PSTE_Article_Type_Intent_Ontology::searchIntent($type);
            $angle=PSTE_Article_Type_Intent_Ontology::genericAngle($type);
            if(PSTE_Article_Type_Registry::canonicalType($type)==='vergleich'&&preg_match('/\bunterschied\w*\b/iu',$raw))$angle='differences';
            return [$goal,$type,$angle];
        }
        if(PSTE_Article_Type_Intent_Ontology::ambiguousNonSignalHits($raw)!==[])return ['AMBIGUOUS_REVIEW_ONLY_SIGNAL','',''];
        if($qualifier!==''||$decision!=='')return ['INFORMATIONAL_FOCUS','Beratung','qualifier_role'];
        return ['EDITORIAL_INFORMATION','Beratung','orientation'];
    }

    /** @return list<array<string,mixed>> */
    private static function secondaryFromSeoEvidence(string $raw,string $family,string $qualifier,array $sourceEvidence,string $primaryType): array {
        $groups=[];$focus=$qualifier!==''?$qualifier:$family;
        foreach((array)($sourceEvidence['evidence']??[]) as $ev){
            if(!is_array($ev))continue;$value=self::clean((string)($ev['raw_value']??''));if($value===''||self::same($value,$raw))continue;
            if(!self::relatedToFocus($value,$focus,$family))continue;
            $type='';$angle='';
            if(PSTE_Normalizer::isQuestion($value)){$type='FAQ';$angle='qualifier_question';}
            else{
                $signals=PSTE_Article_Type_Intent_Ontology::strongSignals($value);
                if(count($signals)===1){$type=(string)$signals[0];$angle='qualifier_'.PSTE_Article_Type_Intent_Ontology::genericAngle($type);}
            }
            if($type===''||hash_equals(PSTE_Article_Type_Registry::canonicalType($type),PSTE_Article_Type_Registry::canonicalType($primaryType)))continue;
            $key=$type.'|'.$angle;if(!isset($groups[$key]))$groups[$key]=['article_type'=>$type,'intent_angle'=>$angle,'focus_term'=>$focus,'evidence_status'=>'DISTINCT_SEO_EVIDENCE_PRESENT_RESEARCH_ONLY','production_eligible'=>false,'auto_fanout'=>false,'five_field_handoff_allowed'=>false,'reason_code'=>'PSTE_INTENT_SECONDARY_BRANCH_RESEARCH_ONLY','evidence_examples'=>[],'evidence_sha256'=>[]];
            if(count($groups[$key]['evidence_examples'])<3)$groups[$key]['evidence_examples'][]=$value;
            $sha=(string)($ev['raw_response_sha256']??'');if(preg_match('/^[a-f0-9]{64}$/',$sha))$groups[$key]['evidence_sha256'][]=$sha;
        }
        $out=[];foreach($groups as $g){$g['evidence_examples']=array_values(array_unique($g['evidence_examples']));$g['evidence_sha256']=array_values(array_unique($g['evidence_sha256']));$g['distinct_evidence_count']=count($g['evidence_examples']);$out[]=$g;if(count($out)>=3)break;}return $out;
    }

    private static function compatibleFallback(string $expected,string $actual): bool {
        // Only structurally compatible fallbacks are tolerated; style or wording can never change the type.
        return $expected==='beratung'&&in_array($actual,['beratung'],true);
    }
    private static function relatedToFocus(string $value,string $focus,string $family): bool {
        // A decisive qualifier is the semantic focus. Secondary branches may not drift back to a generic family-only topic.
        if($focus!=='')return PSTE_Token_Equivalence::contains($value,$focus);
        return $family!==''&&PSTE_Token_Equivalence::contains($value,$family);
    }
    private static function same(string $a,string $b): bool{return hash_equals(PSTE_Normalizer::exactTopicIdentityText($a),PSTE_Normalizer::exactTopicIdentityText($b));}
    private static function keywordSurface(string $v): string {$v=self::clean($v);$v=(string)preg_replace('/[^\p{L}\p{N}\s]+/u',' ',$v);return trim((string)preg_replace('/\s+/u',' ',$v));}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');return trim((string)preg_replace('/\s+/u',' ',$v));}
    private static function lower(string $v): string{return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
    private static function hash(array $v): string {$copy=$v;unset($copy['analysis_sha256'],$copy['profile_sha256']);$copy=self::stable($copy);$json=function_exists('wp_json_encode')?wp_json_encode($copy,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($copy,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return hash('sha256',(string)$json);}
    private static function stable($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'stable'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::stable($x);return $v;}
}
