# PSTE 0.39.0 — persistent-state compatibility / full lifecycle gate

- Root-cause correction: persisted job/queue schema versions are no longer coupled to the plugin implementation version.
- Research-job schema remains 2.1.0 for newly created states and accepts the compatible 0.38 transient schema 2.2.0.
- Breadth-queue schema remains 1.0.0 for newly created states and accepts the compatible 0.38 transient schema 1.1.0.
- Existing 0.37 active states therefore load without mutation, reset or provider replay.
- Existing 0.38-created compatible states remain readable and resumable.
- The 0.38 dynamic site-context rebind/fail-closed structure logic is retained unchanged.
- Release gate requires predecessor-state upgrade tests at every workflow checkpoint plus full workflow/recovery/regression/package tests.
