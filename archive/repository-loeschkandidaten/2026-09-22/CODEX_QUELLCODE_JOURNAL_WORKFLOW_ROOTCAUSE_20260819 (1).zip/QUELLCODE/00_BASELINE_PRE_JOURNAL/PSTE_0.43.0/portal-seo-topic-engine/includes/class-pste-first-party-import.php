<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_First_Party_Import {
    public static function parseCsv(string $path, int $maxRows = 5000): array {
        if (!is_readable($path)) { throw new RuntimeException('PSTE_GSC_FILE_UNREADABLE'); }
        if (filesize($path) > 2 * 1024 * 1024) { throw new RuntimeException('PSTE_GSC_FILE_TOO_LARGE'); }
        $fh=fopen($path,'rb'); if(!$fh)throw new RuntimeException('PSTE_GSC_FILE_OPEN_FAILED');
        $header=fgetcsv($fh,0,',','"','\\'); if(!$header){fclose($fh);throw new RuntimeException('PSTE_GSC_HEADER_MISSING');}
        $normalized=array_map(static fn($v)=>PSTE_Normalizer::text((string)$v),$header);
        $queryIndex=self::findColumn($normalized,['query','queri','suchanfrag','anfrag']);
        $clicksIndex=self::findColumn($normalized,['click','klick']);
        $impressionsIndex=self::findColumn($normalized,['impression']);
        $positionIndex=self::findColumn($normalized,['position']);
        if($queryIndex===null){fclose($fh);throw new RuntimeException('PSTE_GSC_QUERY_COLUMN_MISSING');}
        $items=[];$rejected=0;
        while(($row=fgetcsv($fh,0,',','"','\\'))!==false && count($items)<$maxRows){
            $query=trim((string)($row[$queryIndex]??'')); if($query===''||self::containsPii($query)){$rejected++;continue;}
            $key=PSTE_Normalizer::text($query); if($key==='')continue;
            $items[$key]=[
                'query'=>$query,'clicks'=>$clicksIndex===null?null:(int)($row[$clicksIndex]??0),
                'impressions'=>$impressionsIndex===null?null:(int)($row[$impressionsIndex]??0),
                'position'=>$positionIndex===null?null:(float)str_replace(',','.',(string)($row[$positionIndex]??0)),
                'source'=>'GSC','imported_at_utc'=>gmdate('c')
            ];
        }
        fclose($fh);
        return ['contract'=>'PSTE_FIRST_PARTY_QUERY_IMPORT_V1','items'=>array_values($items),'rejected_personal_or_invalid'=>$rejected,'source_file_sha256'=>hash_file('sha256',$path)];
    }
    public static function matching(string $seed,string $categoryName,array $bundle): array {
        $seedTokens=array_unique(array_merge(PSTE_Normalizer::tokens($seed),PSTE_Normalizer::tokens(PSTE_Normalizer::categoryHead($categoryName))));$out=[];
        foreach(($bundle['items']??[]) as $item){$tokens=PSTE_Normalizer::tokens((string)($item['query']??''));if(array_intersect($seedTokens,$tokens))$out[]=$item;}
        usort($out,static fn($a,$b)=>(int)($b['impressions']??0)<=>(int)($a['impressions']??0));return array_slice($out,0,100);
    }
    public static function containsPii(string $query): bool {
        return (bool)(preg_match('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i',$query)||preg_match('/(?:\+?\d[\d\s\/-]{7,}\d)/',$query)||preg_match('#https?://|www\.#i',$query));
    }
    private static function findColumn(array $headers,array $needles): ?int {
        foreach($headers as $i=>$header)foreach($needles as $needle)if(str_contains($header,$needle))return $i;return null;
    }
}
