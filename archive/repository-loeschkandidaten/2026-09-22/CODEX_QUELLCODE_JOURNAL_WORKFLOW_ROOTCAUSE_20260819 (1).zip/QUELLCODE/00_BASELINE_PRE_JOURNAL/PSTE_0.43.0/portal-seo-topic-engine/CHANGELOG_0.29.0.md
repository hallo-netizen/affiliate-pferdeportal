# Portal SEO Themenengine 0.29.0

## Systemweite Ursachenhärtung Artikeltyp-Intent

- Ersetzt die zentrale Artikeltyp-Ontologie V1 durch V2 mit konservativen, expliziten Intent-Signalen.
- Entfernt mehrdeutige Wörter als harte Artikeltyp-Autorität (u. a. `aufbau`, `nutzung`, `benutzen`, `verwenden`, `einsetzen`, `trainingsplan`, `test`, `alternative`, generisches `oder`, `günstig`, `billig`, generisches `sicher`, `unsicher`, `worauf`, `geeignet`, `passend`, `kaufen`, `vorteil`, `nutzen`, `sinnvoll`).
- Fragen bleiben absolut FAQ-priorisiert.
- Lexikalische Regeln dürfen ausschließlich die Artikelart bestimmen und niemals einen kanonischen Planplatz.
- Editorial-Ruleset V11 zwingt vorhandene abgeleitete SEO-Metadaten vor READY durch die bestehende explizite sichere Migration/Rebuild-Strecke.
- Safe-Migration-Protokoll V5 verhindert, dass ein alter READY-Marker die neue Ontologie stillschweigend freigibt.
- Keine Änderungen an Beiträgen, Termen, URLs, Yoast, Textproduktion, Inhalt, HTML, Formatierung oder Design.
