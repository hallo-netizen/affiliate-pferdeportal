<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Auth {
    public static function assertAdmin(string $nonceAction = '', string $nonce = ''): void {
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            throw new RuntimeException('PSTE_NOT_AUTHORIZED');
        }
        if ($nonceAction !== '' && !wp_verify_nonce($nonce, $nonceAction)) {
            throw new RuntimeException('PSTE_NONCE_INVALID');
        }
    }
}
