# Portal SEO Themenengine 0.33.0

## Scope
Einziger Titelboss vor der Textmaschine; keine Änderung an Textmaschine/PPM, Inhalt, HTML, Design, Kategorie, Artikelart, Intent oder Planplatz.

## Änderungen
- Die frühere Portal-Sonderregel „Target Keyword muss Titelpräfix sein“ ist entfernt.
- Verbindlich bleibt die unveränderte PPM-6.7.9-Regel: das exakte Target Keyword muss als zusammenhängende Zeichenfolge im Titel vorkommen.
- Position 1 ist nur noch mögliche natürliche Position, kein Hard Gate.
- Der Titelcomposer bleibt alleinige upstream Titelautorität und darf nur bereits gebundene Artikelart-/Intent-Signale sprachlich sichtbar machen.
- Beratung/Pflege/Vergleich können natürliche Titel erzeugen, in denen das Target Keyword nicht an Position 1 steht.
- FAQ-, Doppelungs-, Sprach-, Stakkato-, künstliche Generatorphrasen- und Intent-Konflikt-Gates bleiben aktiv.
- Keine automatische Downstream-Reparatur: ein abgelehnter Titel muss zurück zur Titelautorität.

## Unverändert
- Exact Five
- Recherche-/Textmaschine STARTMASTER 0039
- PPM 6.7.9
- Language/Qualität/HTML/Design
- Kategorie-/Slot-/canonical_article_id-Logik
