# PSTE 0.42.0 — Admin-Leseperformance ohne Workflowänderung

- Ausschließlich read-only Admin-Datenpfad optimiert.
- Themenpool-Fundstellen und Zuordnungen werden für Admin-Ansichten gebündelt gelesen statt je Thema mit zwei Einzelabfragen.
- Analytics verwendet innerhalb eines Admin-Requests denselben read-only Kandidaten- und Inventar-Snapshot mehrfach.
- Produktions-/Recherche-/Portalabgleich-/Titel-/Textmaschinenlogik unverändert.
- Keine Änderung an Artikeln, HTML, Design, Kategorien, URLs oder PPM.
