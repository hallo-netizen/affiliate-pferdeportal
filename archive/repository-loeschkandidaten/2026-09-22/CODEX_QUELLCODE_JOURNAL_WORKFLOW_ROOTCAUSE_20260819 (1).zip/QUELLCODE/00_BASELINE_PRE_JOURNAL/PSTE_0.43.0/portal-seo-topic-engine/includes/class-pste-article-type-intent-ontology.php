<?php
if (!defined('ABSPATH')) { return; }

/**
 * Transparent, domain-neutral article-type intent policy for metadata routing only.
 * It owns every lexical article-type assignment rule. It never creates content,
 * title wording, HTML, formatting, design, taxonomy or production payloads.
 */
final class PSTE_Article_Type_Intent_Ontology {
    private const CONTRACT='PSTE_ARTICLE_TYPE_INTENT_ONTOLOGY_V2';
    private static ?array $cache=null;

    /** @return array<string,mixed> */
    public static function contract(): array {
        if(self::$cache!==null)return self::$cache;
        $path=defined('PSTE_DIR')?PSTE_DIR.'contracts/article-type-intent-ontology-v2.json':dirname(__DIR__).'/contracts/article-type-intent-ontology-v2.json';
        $raw=@file_get_contents($path);$data=is_string($raw)?json_decode($raw,true):null;
        if(!is_array($data)||($data['contract']??'')!==self::CONTRACT)throw new RuntimeException('PSTE_ARTICLE_TYPE_INTENT_ONTOLOGY_INVALID');
        foreach((array)($data['types']??[]) as $type=>$row){
            if(!is_array($row)||empty($row['patterns']))throw new RuntimeException('PSTE_ARTICLE_TYPE_INTENT_ONTOLOGY_TYPE_INVALID');
            foreach((array)$row['patterns'] as $pattern){$ok=@preg_match('/'.$pattern.'/iu','');if($ok===false)throw new RuntimeException('PSTE_ARTICLE_TYPE_INTENT_ONTOLOGY_REGEX_INVALID');}
        }
        foreach((array)($data['probe_noise_patterns']??[]) as $pattern){$ok=@preg_match('/'.$pattern.'/iu','');if($ok===false)throw new RuntimeException('PSTE_ARTICLE_TYPE_INTENT_ONTOLOGY_PROBE_REGEX_INVALID');}
        foreach((array)($data['neutral_fallback_block_patterns']??[]) as $group=>$patterns){
            foreach((array)$patterns as $pattern){$ok=@preg_match('/'.$pattern.'/iu','');if($ok===false)throw new RuntimeException('PSTE_ARTICLE_TYPE_INTENT_ONTOLOGY_AMBIGUOUS_REGEX_INVALID');}
        }
        return self::$cache=$data;
    }

    /** @return list<string> */
    public static function strongSignals(string $query,array $availableTypes=[]): array {
        $query=trim($query);if($query==='')return [];
        $available=[];foreach($availableTypes as $t)$available[self::canon((string)$t)]=true;
        $out=[];foreach((array)(self::contract()['types']??[]) as $type=>$row){
            if($availableTypes&&!isset($available[self::canon((string)$type)]))continue;
            foreach((array)($row['patterns']??[]) as $pattern){
                if(preg_match('/'.$pattern.'/iu',$query)){ $out[]=(string)$type; break; }
            }
        }
        return array_values(array_unique($out));
    }

    public static function searchIntent(string $type): string {
        foreach((array)(self::contract()['types']??[]) as $visible=>$row)if(self::canon((string)$visible)===self::canon($type))return (string)($row['intent']??'EDITORIAL_INFORMATION');
        return 'EDITORIAL_INFORMATION';
    }
    public static function genericAngle(string $type): string {
        foreach((array)(self::contract()['types']??[]) as $visible=>$row)if(self::canon((string)$visible)===self::canon($type))return (string)($row['angle']??'orientation');
        return 'orientation';
    }

    public static function stripIntentSignals(string $value): string {
        $value=trim($value);if($value==='')return '';
        // Family-probe noise removal is intentionally separate from article-type evidence.
        // This preserves the existing semantic family probe while preventing generic words
        // such as recommendation/protection/warten from becoming routing authority.
        $patterns=(array)(self::contract()['probe_noise_patterns']??[]);
        if(!$patterns){foreach((array)(self::contract()['types']??[]) as $row)foreach((array)($row['patterns']??[]) as $pattern)$patterns[]=$pattern;}
        foreach($patterns as $pattern)$value=(string)(preg_replace('/'.$pattern.'/iu',' ',$value)??$value);
        return trim((string)preg_replace('/\s+/u',' ',$value));
    }

    /** @return array<string,list<string>> */
    public static function explicitNonSignals(): array {return (array)(self::contract()['explicit_non_signals']??[]);}

    /**
     * Ambiguous lexical cues are deliberately NOT article-type evidence.
     * They only veto the generic neutral-Beratung fallback when no strong signal exists.
     * @return list<string> group labels whose review-only patterns matched
     */
    public static function ambiguousNonSignalHits(string $query): array {
        $query=trim($query);if($query==='')return [];
        $out=[];foreach((array)(self::contract()['neutral_fallback_block_patterns']??[]) as $group=>$patterns){
            foreach((array)$patterns as $pattern){if(preg_match('/'.$pattern.'/iu',$query)){ $out[]=(string)$group; break; }}
        }
        return array_values(array_unique($out));
    }

    /** True when a query has editorial-looking evidence but no safe type should be inferred from that fact alone. */
    public static function hasExplicitIntentOrAmbiguity(string $query,array $availableTypes=[]): bool {
        if(class_exists('PSTE_Normalizer')&&PSTE_Normalizer::isQuestion($query))return true;
        return self::strongSignals($query,$availableTypes)!==[]||self::ambiguousNonSignalHits($query)!==[];
    }

    private static function canon(string $v): string {
        if(class_exists('PSTE_Article_Type_Registry'))return PSTE_Article_Type_Registry::canonicalType($v);
        $v=strtr(trim($v),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$v=strtolower($v);return trim((string)preg_replace('/[^a-z0-9]+/','_',$v),'_');
    }
}
