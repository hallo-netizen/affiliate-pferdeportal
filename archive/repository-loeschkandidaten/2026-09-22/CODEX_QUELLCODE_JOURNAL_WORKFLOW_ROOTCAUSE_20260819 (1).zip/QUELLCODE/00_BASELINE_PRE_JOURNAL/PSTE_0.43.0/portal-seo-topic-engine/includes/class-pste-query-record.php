<?php
if (!defined('ABSPATH')) { return; }

/** Preserves byte-faithful raw discovery data and derives separate analysis forms. */
final class PSTE_Query_Record {
    // Built-in corrections are deliberately domain-neutral. Site- or portal-specific
    // spelling evidence may be injected explicitly through the existing filter, while
    // raw_query always remains byte-faithful.
    private const SAFE_CORRECTIONS = [];
    /** @return array<string,mixed> */
    public static function make(
        string $raw,
        ?int $volume,
        array $monthly,
        array $sources,
        array $hashes,
        string $captured,
        array $observations = []
    ): array {
        // raw_query and measured_query deliberately keep the original bytes.
        $analysis = self::cleanForAnalysis($raw);
        $normalized = PSTE_Normalizer::text($analysis);
        $corrected = self::correct($analysis);
        $relation = PSTE_Normalizer::exactTopicIdentityText($corrected) !== PSTE_Normalizer::exactTopicIdentityText($analysis)
            ? 'SPELLING_VARIANT'
            : (PSTE_Normalizer::isQuestion($analysis) ? 'QUESTION' : 'CANONICAL_FORM');
        $sourceNames = array_values(array_unique(array_filter(array_map('strval', $sources))));

        if (!$observations) {
            foreach ($sourceNames as $source) {
                $observations[] = self::observation($source, $raw, $captured, (string)($hashes[$source] ?? ''));
            }
        }
        $observations = self::validateObservations($observations, $raw, $captured);
        $validUntil = self::earliestValidUntil($observations, $captured);

        return [
            'raw_query' => $raw,
            'raw_query_sha256' => hash('sha256', $raw),
            'normalized_query' => $normalized,
            'language_corrected_query' => $corrected,
            'relation_to_canonical' => $relation,
            'source_names' => $sourceNames,
            'source_hashes' => $hashes,
            'captured_at_utc' => $captured,
            'observations' => $observations,
            'volume_status' => $volume === null ? 'UNMEASURED' : 'MEASURED',
            'measured_query' => $volume === null ? '' : $raw,
            'measured_query_sha256' => $volume === null ? '' : hash('sha256', $raw),
            'search_volume' => $volume,
            'monthly_searches' => $monthly,
            'freshness' => [
                'status' => 'CURRENT',
                'retrieved_at' => $captured,
                'valid_until' => $validUntil,
                'revalidation_class' => 'REGULARLY_CHANGING',
            ],
        ];
    }

    public static function canonicalKey(array $record): string {
        return PSTE_Normalizer::exactTopicIdentityText((string)($record['language_corrected_query'] ?? $record['normalized_query'] ?? ''));
    }

    public static function aliasKey(array $record): string {
        $query = (string)($record['language_corrected_query'] ?? $record['normalized_query'] ?? '');
        $semantic = PSTE_Normalizer::semanticFingerprint($query);
        if ($semantic === '') { return ''; }
        $kind = (($record['relation_to_canonical'] ?? '') === 'QUESTION' || PSTE_Normalizer::isQuestion($query)) ? 'QUESTION' : 'STATEMENT';
        return hash('sha256', $kind . '|' . $semantic);
    }

    public static function correct(string $raw): string {
        $clean = self::cleanForAnalysis($raw);
        $map = self::SAFE_CORRECTIONS;
        if (function_exists('apply_filters')) {
            $map = (array)apply_filters('pste_safe_spelling_corrections', $map);
        }
        $identity = PSTE_Normalizer::exactTopicIdentityText($clean);
        foreach ($map as $from => $to) {
            if (PSTE_Normalizer::exactTopicIdentityText((string)$from) === $identity) {
                return (string)$to;
            }
        }
        return $clean;
    }

    private static function cleanForAnalysis(string $value): string {
        $value = html_entity_decode(
            function_exists('wp_strip_all_tags') ? wp_strip_all_tags($value) : strip_tags($value),
            ENT_QUOTES | ENT_HTML5,
            'UTF-8'
        );
        return trim((string)preg_replace('/\s+/u', ' ', $value));
    }

    /** @return array<string,mixed> */
    private static function observation(string $source, string $raw, string $captured, string $hash): array {
        $valid = gmdate('c', (strtotime($captured) ?: time()) + 90 * 86400);
        return [
            'observation_id' => 'obs:' . substr(hash('sha256', $source . '|' . $raw . '|' . $captured . '|' . $hash), 0, 32),
            'canonical_term_id' => '',
            'source_class' => $source,
            'provider' => $source === 'GSC' ? 'GOOGLE_SEARCH_CONSOLE' : 'DATAFORSEO_LABS',
            'query_kind' => $source,
            'root_query' => $raw,
            'parent_observation_id' => '',
            'depth' => 0,
            'raw_value' => $raw,
            'locale' => '',
            'language' => '',
            'parameters' => [],
            'retrieved_at_utc' => $captured,
            'raw_response_sha256' => $hash,
            'measurement_status' => 'OBSERVED',
            'relation' => 'DISCOVERED',
            'relation_evidence' => [],
            'freshness_status' => 'CURRENT',
            'valid_until' => $valid,
        ];
    }

    /** @return list<array<string,mixed>> */
    private static function validateObservations(array $observations, string $raw, string $captured): array {
        $out = [];
        foreach ($observations as $index => $observation) {
            if (!is_array($observation)) { continue; }
            $source = (string)($observation['source_class'] ?? '');
            $hash = (string)($observation['raw_response_sha256'] ?? '');
            $observation['raw_value'] = array_key_exists('raw_value', $observation) ? (string)$observation['raw_value'] : $raw;
            $observation['retrieved_at_utc'] = (string)($observation['retrieved_at_utc'] ?? $captured);
            $observation['observation_id'] = (string)($observation['observation_id'] ?? '');
            if ($observation['observation_id'] === '') {
                $observation['observation_id'] = 'obs:' . substr(hash(
                    'sha256',
                    $source . '|' . $observation['raw_value'] . '|' . $observation['retrieved_at_utc'] . '|' . $hash . '|' . $index
                ), 0, 32);
            }
            $observation['root_query'] = (string)($observation['root_query'] ?? $raw);
            $observation['parent_observation_id'] = (string)($observation['parent_observation_id'] ?? '');
            $observation['depth'] = (int)($observation['depth'] ?? 0);
            $observation['query_kind'] = (string)($observation['query_kind'] ?? $source);
            $observation['provider'] = (string)($observation['provider'] ?? '');
            $observation['locale'] = (string)($observation['locale'] ?? '');
            $observation['language'] = (string)($observation['language'] ?? '');
            $observation['parameters'] = is_array($observation['parameters'] ?? null) ? $observation['parameters'] : [];
            $observation['measurement_status'] = (string)($observation['measurement_status'] ?? 'OBSERVED');
            $observation['relation'] = (string)($observation['relation'] ?? 'DISCOVERED');
            $observation['relation_evidence'] = is_array($observation['relation_evidence'] ?? null) ? $observation['relation_evidence'] : [];
            $observation['freshness_status'] = (string)($observation['freshness_status'] ?? 'CURRENT');
            $observation['valid_until'] = (string)($observation['valid_until'] ?? gmdate(
                'c',
                (strtotime($observation['retrieved_at_utc']) ?: time()) + 90 * 86400
            ));
            $out[] = $observation;
        }
        return $out;
    }

    private static function earliestValidUntil(array $observations, string $captured): string {
        $times = [];
        foreach ($observations as $observation) {
            $time = strtotime((string)($observation['valid_until'] ?? ''));
            if ($time !== false) { $times[] = $time; }
        }
        return gmdate('c', $times ? min($times) : (strtotime($captured) ?: time()) + 90 * 86400);
    }
}
