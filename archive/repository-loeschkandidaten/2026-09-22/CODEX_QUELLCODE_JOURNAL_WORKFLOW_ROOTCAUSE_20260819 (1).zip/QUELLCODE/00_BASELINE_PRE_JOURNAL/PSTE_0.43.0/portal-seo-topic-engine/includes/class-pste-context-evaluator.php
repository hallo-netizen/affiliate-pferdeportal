<?php
if (!defined('ABSPATH')) { return; }

/**
 * Pure, read-only portal-context evaluation.
 *
 * This class performs no database writes. It exists so the complete
 * classification can be tested before any persistent state is changed.
 */
final class PSTE_Context_Evaluator {
    public static function buildIndex(array $inventory, array $plan): array {
        $index = ['WORDPRESS' => [], 'EDITORIAL_PLAN' => []];

        foreach ((array)($inventory['items'] ?? []) as $item) {
            if (!is_array($item)) { continue; }
            $family = (string)($item['topic_family_key'] ?? PSTE_Normalizer::categoryFamilyKey((string)($item['category_name'] ?? '')));
            if ($family === '') { continue; }
            $index['WORDPRESS'][$family][] = $item;
        }

        foreach ((array)($plan['items'] ?? []) as $item) {
            if (!is_array($item)) { continue; }
            $family = (string)($item['topic_family_key'] ?? PSTE_Normalizer::categoryFamilyKey((string)($item['category_name'] ?? '')));
            if ($family === '') { continue; }
            $index['EDITORIAL_PLAN'][$family][] = $item;
        }

        return $index;
    }

    public static function evaluate(array $payload, array $inventory, array $plan, array $index): array {
        $query = trim((string)($payload['editorial_title'] ?? $payload['canonical_query'] ?? $payload['primary_longtail_query'] ?? ''));
        $family = trim((string)($payload['topic_family_key'] ?? ''));

        if ($query === '') {
            return [
                'state' => 'BLOCKED',
                'reason_code' => 'PSTE_CONTEXT_QUERY_MISSING',
                'matches' => [],
                'payload' => self::withContextError($payload, 'PSTE_CONTEXT_QUERY_MISSING', $inventory, $plan),
            ];
        }
        if ($family === '') {
            return [
                'state' => 'BLOCKED',
                'reason_code' => 'CONTEXT_FAMILY_MISSING',
                'matches' => [],
                'payload' => self::withContextError($payload, 'CONTEXT_FAMILY_MISSING', $inventory, $plan),
            ];
        }

        $matches = [];
        foreach (['WORDPRESS', 'EDITORIAL_PLAN'] as $source) {
            foreach ((array)($index[$source][$family] ?? []) as $item) {
                if (!is_array($item)) { continue; }
                $title = trim((string)($item['title'] ?? $item['primary_longtail_query'] ?? ''));
                if ($title === '') { continue; }

                $categoryName = (string)($item['category_name'] ?? '');
                $best = PSTE_Normalizer::similarity($query, $title);
                $field = 'TITLE';
                $matched = $title;

                foreach ((array)($item['headings'] ?? []) as $heading) {
                    $heading = trim((string)$heading);
                    if ($heading === '') { continue; }
                    $similarity = PSTE_Normalizer::similarity($query, $heading);
                    if ($similarity > $best) {
                        $best = $similarity;
                        $field = 'HEADING';
                        $matched = $heading;
                    }
                }

                $equivalent = PSTE_Normalizer::answerEquivalent(
                    $query,
                    $matched,
                    PSTE_Normalizer::categoryFamilyName((string)($payload['target_category_name'] ?? '')),
                    PSTE_Normalizer::categoryFamilyName($categoryName)
                );

                if (!$equivalent && $best < 0.55) { continue; }

                $matches[] = [
                    'source' => $source,
                    'post_id' => (int)($item['post_id'] ?? 0),
                    'title' => $title,
                    'category_id' => (int)($item['category_id'] ?? 0),
                    'category_name' => $categoryName,
                    'article_type' => (string)($item['article_type'] ?? PSTE_Normalizer::categoryArticleType($categoryName)),
                    'matched_field' => $field,
                    'matched_text' => $matched,
                    'similarity' => $best,
                    'answer_equivalence' => $equivalent,
                    'same_topic_family' => true,
                    'status' => (string)($item['status'] ?? ($source === 'EDITORIAL_PLAN' ? 'PLANNED' : '')),
                ];
            }
        }

        usort($matches, static function (array $a, array $b): int {
            return [(int)$b['answer_equivalence'], (float)$b['similarity']]
                <=> [(int)$a['answer_equivalence'], (float)$a['similarity']];
        });

        $reasons = array_values(array_diff(
            (array)($payload['reason_codes'] ?? []),
            [
                'ANSWER_EQUIVALENT_EXISTING',
                'ANSWER_EQUIVALENT_PLANNED',
                'CONTEXT_REFRESH_FAILED',
                'CONTEXT_REFRESH_STALE',
                'CONTEXT_FAMILY_MISSING',
            ]
        ));

        foreach ($matches as $match) {
            if (empty($match['answer_equivalence'])) { continue; }
            $reasons[] = $match['source'] === 'WORDPRESS'
                ? 'ANSWER_EQUIVALENT_EXISTING'
                : 'ANSWER_EQUIVALENT_PLANNED';
        }

        $payload['reason_codes'] = array_values(array_unique($reasons));
        $payload['portal_context'] = [
            'inventory_snapshot_sha256' => (string)($inventory['sha256'] ?? ''),
            'editorial_plan_snapshot_sha256' => (string)($plan['sha256'] ?? 'NOT_AVAILABLE'),
            'editorial_plan_status' => (string)($plan['status'] ?? 'AVAILABLE'),
            'matches' => array_slice($matches, 0, 20),
            'synced_at_utc' => gmdate('c'),
        ];
        $payload['context_state'] = 'CURRENT';

        return [
            'state' => 'CURRENT',
            'reason_code' => null,
            'matches' => $matches,
            'payload' => $payload,
        ];
    }

    private static function withContextError(array $payload, string $reason, array $inventory, array $plan): array {
        $payload['reason_codes'] = array_values(array_unique(array_merge((array)($payload['reason_codes'] ?? []), [$reason])));
        $payload['portal_context'] = [
            'inventory_snapshot_sha256' => (string)($inventory['sha256'] ?? ''),
            'editorial_plan_snapshot_sha256' => (string)($plan['sha256'] ?? 'NOT_AVAILABLE'),
            'editorial_plan_status' => (string)($plan['status'] ?? 'AVAILABLE'),
            'matches' => [],
            'synced_at_utc' => gmdate('c'),
            'error_code' => $reason,
        ];
        $payload['context_state'] = 'BLOCKED';
        return $payload;
    }
}
