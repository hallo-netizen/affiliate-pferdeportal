# 0.16.0 – V71 Complete Review Loop

- V70 Evidence-before-internal architecture remains the primary decision boundary.
- Adds an explicit human relevance adjudication only for real Production-SERP outcomes that remain `UNCERTAIN_REVIEW`.
- Human relevance decisions are bound to the exact external response hash, query/source identity and current Dry-run/registry/baseline binding.
- Raw external evidence is retained unchanged; adjudication is stored separately and historically archived on later binding/policy changes.
- Adds explicit sandbox-only confirmation of safe internal proposals as `READY_FOR_NORMAL_REENTRY_REVIEW`; this creates no five-field handoff and no production write.
- State fields are normalized after external/internal review so completed rows cannot be silently requeued as paid external work.
- No automatic negative relevance rule was added. No keyword/domain special cases were added.
- Hauptregel 1 unchanged: no post, postmeta, term, text-machine, PPM, compiler, HTML, CSS or design writes.
- V71 hardening: explicit relevance review additionally verifies the stored evidence belongs to the exact candidate query; empty/unattributed reviews fail closed.
- Internal confirmation additionally requires relevance to be confirmed and rejects empty/unattributed reviews.
- Sandbox review archives and event histories are no longer silently truncated; prior evidence remains preserved across policy/binding changes.
- Admin counters expose retained not-relevant items and pending internal semantic reviews separately so retained candidates do not disappear operationally.
