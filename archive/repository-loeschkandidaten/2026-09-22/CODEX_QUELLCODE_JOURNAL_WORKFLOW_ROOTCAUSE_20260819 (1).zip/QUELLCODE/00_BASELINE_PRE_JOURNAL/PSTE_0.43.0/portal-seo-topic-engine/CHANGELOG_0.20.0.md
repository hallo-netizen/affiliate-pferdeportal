# 0.20.0

Gebündelte End-to-End-Ursachenreparatur:
- unabhängige Portalrelevanz vor Editorialisierung; Familienmatch allein reicht nicht mehr
- grammatikrobuste Titeltemplates und strengere unabhängige FAQ-/Titelprüfung
- echte Strukturlücken erhalten konkrete, nur vorschlagsweise Typ-/Kategorie-/Titelhinweise
- Sandbox-Reentry trägt gebundene Relevanzevidenz zurück in denselben Normalpfad
- Editorial-Metadaten-Readiness verlangt Marker + gültigen Auditreport und kann Teilfehler sauber wiederaufnehmen
- keine Änderungen an Textmaschine, Artikeln, Taxonomien, Design oder Fünf-Feld-Grenze
