<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Category_Gap {
    /** @return array<string,mixed> */
    public static function analyze(string $family,string $familyKey,string $type,array $consensus,array $evidence,string $structureHash,array $registry=[],bool $alreadyCovered=false): array {
        $familyExists=is_array($registry['families'][$familyKey]??null);$exact=$familyExists?PSTE_Article_Type_Registry::resolve($registry,$familyKey,$type):['ok'=>false];
        $retrieverCoverage=(($consensus['strand_a']['coverage_status']??'')==='COVERAGE_PRESENT'&&($consensus['strand_b']['coverage_status']??'')==='COVERAGE_PRESENT');
        $aliasHint=!empty($consensus['alias_or_naming_hint']);
        if(!empty($exact['ok'])){
            if(!$retrieverCoverage)$gap='RETRIEVER_OR_ONTOLOGY_GAP';
            elseif($aliasHint)$gap='ALIAS_OR_NAMING_GAP';
            elseif($alreadyCovered)$gap='NO_GAP_ALREADY_COVERED';
            else $gap='CONTENT_GAP_CANDIDATE';
        }elseif(!$familyExists)$gap='CATEGORY_GAP_CANDIDATE';
        else $gap='ARTICLE_TYPE_LEAF_GAP';
        $proposalType=match($gap){'CATEGORY_GAP_CANDIDATE'=>'MISSING_TOPIC_FAMILY','ARTICLE_TYPE_LEAF_GAP'=>'MISSING_ARTICLE_TYPE_LEAF','ALIAS_OR_NAMING_GAP'=>'TAXONOMY_ALIAS_OR_NAMING_GAP','RETRIEVER_OR_ONTOLOGY_GAP'=>'RETRIEVER_OR_ONTOLOGY_GAP',default=>''};
        $sourceClasses=[];foreach($evidence as $row){$s=(string)($row['source']??'');if($s!=='')$sourceClasses[$s]=true;}
        $basis=[$family,$familyKey,$type,$gap,array_keys($sourceClasses),$structureHash,(string)($registry['registry_sha256']??'')];
        return ['contract'=>'PSTE_CATEGORY_GAP_ANALYSIS_V2','proposal_id'=>'gap:'.substr(hash('sha256',self::json($basis)),0,24),'status'=>$proposalType!==''?'CATEGORY_GAP_PROPOSED':'GAP_ANALYZED',
            'gap_class'=>$gap,'proposal_type'=>$proposalType,'proposed_name'=>$proposalType!==''?trim($type.' '.$family):'','proposed_parent_family'=>$family,'proposed_parent_family_key'=>$familyKey,'required_article_type'=>$type,
            'semantic_consensus'=>$consensus,'independent_source_classes'=>array_keys($sourceClasses),'evidence_source_count'=>count($sourceClasses),'structure_sha256'=>$structureHash,'registry_sha256'=>(string)($registry['registry_sha256']??''),
            'wordpress_write_attempted'=>false,'treat_as_existing_before_new_snapshot'=>false];
    }
    /** @return array<string,mixed> */
    public static function proposal(string $family,string $familyKey,string $type,array $consensus,array $evidence,string $structureHash,array $registry=[]): array {return self::analyze($family,$familyKey,$type,$consensus,$evidence,$structureHash,$registry,false);}
    private static function json($v): string {$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);return is_string($j)?$j:'';}
}
