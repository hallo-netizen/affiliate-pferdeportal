# Changelog 0.8.8-staging

- Schließt ausschließlich die von der unabhängigen Prüfung gefundene Rückleselücke im beschädigten `topic_pool.payload_json`-Reparaturpfad.
- Nach jedem reparierenden `UPDATE` wird der tatsächlich in der Datenbank gespeicherte JSON-String innerhalb derselben offenen Transaktion erneut per `SELECT` gelesen.
- Gültigkeit und SHA-256-Identität des Rücklesewerts werden gegen den erwarteten Wert geprüft.
- Bei stiller Kürzung, Zeichensatzänderung oder sonstiger Abweichung erfolgt `PSTE_PAYLOAD_RECOVERY_READBACK_MISMATCH` und die komplette Reparatur wird zurückgerollt.
- Keine Änderungen an Beiträgen, Kategorien, URLs, Textproduktion, Production Center, Editorial Guard oder Design.
