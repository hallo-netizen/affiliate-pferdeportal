# 0.10.8-staging

Gebündelter Reparatur- und Abschlusskandidat für den real aufgetretenen Fehler `PSTE_TOPIC_POOL_PAYLOAD_NOT_VALID_JSON_LEN_1`.

- Behebt den exakt nachgewiesenen 14-Felder-/13-Formate-Fehler im UPDATE-Zweig von `upsertTopicPool()`; `payload_json` wird wieder als `%s` gespeichert.
- Führt eine zentrale Schreibgrenze für sämtliche direkten PSTE-Datenbankwrites ein: exakte Feld-/Formatparität, exakte WHERE-Parität und ausschließlich eigene `pste_`-Tabellen als Schreibziel.
- Begrenzte Options-DELETE-Ausnahme akzeptiert ausschließlich eigene `pste_`-Optionen beziehungsweise eigene PSTE-Transients; fremde WordPress-Optionen werden vor dem SQL-Aufruf blockiert.
- Prüft den realen Themenpool-Speicherpfad über INSERT und denselben UPDATE-Zweig zweimal.
- Repariert bereits beschädigte `payload_json="0"`-Datensätze deterministisch aus vorhandenen eigenen Kandidatendaten, ohne erneuten Providerabruf.
- Isoliert fehlende, ungültige oder identitätswidrige Reparaturquellen pro Thema; kein einzelnes Thema blockiert den übrigen Themenpool.
- Rekonstruiert fehlende Fundstellen idempotent und verhindert Doppelzählung bei Wiederholung desselben Laufes.
- Behebt zusätzlich eine beim vollständigen Schreibpfad-Audit gefundene 13-Felder-/14-Formate-Abweichung im GSC-Speicherpfad.
- Migration auf Schema 10 führt Reparatur, Speichervorprüfung, Re-Klassifizierung und Relationstest in festgelegter Reihenfolge aus.
- Serialisiert Speichervorprüfung, Reparatur und Lauf-Fortsetzung unter demselben Schritt-Lock, damit zwei parallele Fortsetzungsaufrufe keine Prüf- oder Reparaturwrites gegeneinander ausführen.
- Keine Änderung an Beiträgen, Post-Meta, Kategorien, Term-Meta, HTML, Tabellen, Design, Textmaschine oder deren Qualitätslogik.
