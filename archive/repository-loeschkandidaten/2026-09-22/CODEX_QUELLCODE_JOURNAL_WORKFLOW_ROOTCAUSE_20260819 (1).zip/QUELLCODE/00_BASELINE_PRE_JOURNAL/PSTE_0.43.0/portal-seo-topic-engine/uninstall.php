<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
// Fail-safe: Analyse-, OAuth- und Zugangsdaten bleiben bei normaler Deinstallation/Neuinstallation erhalten.
// Vollständiges Löschen eigener Analysedaten ist nur mit ausdrücklicher Konstante möglich.
if (!defined('PSTE_ALLOW_DATA_DELETION') || PSTE_ALLOW_DATA_DELETION !== true) { return; }
global $wpdb;
require_once __DIR__ . '/includes/class-pste-db-write-guard.php';
foreach (['runs','candidates','evidence','cost_ledger','gsc_queries','topic_pool','topic_history','topic_occurrences','topic_assignments','topic_identity','topic_merge_candidates'] as $suffix) {
    $table = $wpdb->prefix . 'pste_' . $suffix;
    PSTE_DB_Write_Guard::query("DROP TABLE IF EXISTS `" . esc_sql($table) . "`",'PSTE_UNINSTALL_DROP_FAILED_'.$suffix);
}
foreach ([
    'pste_settings_v1','pste_serp_calibration_v1','pste_schema_version','pste_first_party_queries_v1','pste_site_baseline_v1',
    'pste_connection_status_v1','pste_category_weights_v1','pste_gsc_connection_status_v1','pste_gsc_sites_cache_v1','pste_gsc_selected_property_v1',
    'pste_gsc_last_sync_v1','pste_last_live_check_v1','pste_live_evidence_registry_v1','pste_live_serp_job_v1','pste_live_serp_worker_lock_v1',
    'pste_budget_reservations_v1','pste_budget_reservation_lock_v1','pste_context_refresh_job_v1','pste_editorial_plan_import_v1','pste_boot_status_v1',
    'pste_editorial_ruleset_v1','pste_active_longtail_research_job_v1','pste_active_longtail_research_job_v2','pste_longtail_research_step_lock_v1',
    'pste_longtail_research_step_lock_v2','pste_legacy_live_archive_v1','pste_0100_removed_live_workflow_cleanup_v1','pste_0101_archive_removed_workflows_v1',
    'pste_family_v2_dry_run_v1','pste_family_v2_apply_authorization_v1','pste_family_v2_apply_v1','pste_family_v2_rollback_v1'
] as $option) { delete_option($option); }
foreach (['pste_connection_test_result','pste_migration_lock_v1','pste_last_error','pste_migration_notice','pste_context_notice','pste_context_refresh_lock_v1'] as $transient) {
    delete_transient($transient);
}
// Nur eigene dynamische Cache-/OAuth-State-Transients entfernen. Fremde Optionen und Inhalte bleiben unberührt.
if (isset($wpdb->options)) {
    $patterns=['_transient_pste_api_%','_transient_timeout_pste_api_%','_transient_pste_gsc_oauth_state_%','_transient_timeout_pste_gsc_oauth_state_%'];
    foreach($patterns as $pattern){PSTE_DB_Write_Guard::query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",$pattern),'PSTE_UNINSTALL_TRANSIENT_DELETE_FAILED');}
}
if(function_exists('wp_clear_scheduled_hook')){
    wp_clear_scheduled_hook('pste_live_serp_job_step');
    wp_clear_scheduled_hook('pste_context_refresh_batch');
}
// DataForSEO login/password, Google client ID/secret and OAuth token bundle werden absichtlich nicht gelöscht.
