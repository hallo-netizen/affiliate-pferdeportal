<?php
if (!defined('ABSPATH')) { return; }

/** Pure metadata backfill for persisted topic payloads. Never calls providers or writes WordPress content. */
final class PSTE_Semantic_Backfill {
    /** @return array<string,mixed> */
    public static function rebuild(array $payload,array $registry): array {
        $query=PSTE_Editorializer::sourceQuery($payload);$resolution=PSTE_Family_Resolver::resolve($payload,$registry);
        $legacyKey=trim((string)($payload['topic_family_key']??''));
        if(empty($resolution['ok'])){
            $semantic=self::blocked((string)($resolution['reason_codes'][0]??'PSTE_FAMILY_RESOLUTION_BLOCKED'),$legacyKey,['family_resolution'=>$resolution]);
            return self::result($payload,$semantic,$query,$legacyKey,$registry,$resolution);
        }
        $familyKey=(string)$resolution['resolved_family_key'];$familyName=(string)$resolution['resolved_family_name'];
        if($legacyKey!==''&&!hash_equals($legacyKey,$familyKey))$payload['legacy_topic_family_key']=$legacyKey;
        $payload['topic_family_key']=$familyKey;$payload['topic_family_name']=$familyName;$payload['family_resolution']=$resolution;
        if($query==='')return self::result($payload,self::blocked('PSTE_SEMANTIC_QUERY_MISSING',$familyKey,['family_resolution'=>$resolution]),$query,$familyKey,$registry,$resolution);
        try{$semantic=PSTE_Semantic_Classifier::classify($query,(string)($payload['metrics']['search_intent']??$payload['search_intent']??''),$registry,$familyKey);}
        catch(Throwable $error){$semantic=self::blocked('PSTE_SEMANTIC_RECLASSIFY_CANDIDATE_ERROR',$familyKey,['error_code'=>self::safeErrorCode($error),'family_resolution'=>$resolution]);}
        $payload=self::synchronizeMetadata($payload,$semantic,$query,$familyName,$familyKey,$registry);
        return self::result($payload,$semantic,$query,$familyKey,$registry,$resolution);
    }

    /** @return array<string,mixed> */
    private static function synchronizeMetadata(array $payload,array $semantic,string $query,string $familyName,string $familyKey,array $registry): array {
        $payload['semantic_consensus']=$semantic;
        $stale=['PSTE_SEMANTIC_FAMILY_REGISTRY_MISSING','PSTE_SEMANTIC_QUERY_MISSING','PSTE_SEMANTIC_TYPE_CONSENSUS_MISSING','PSTE_SEMANTIC_MEANING_CONSENSUS_MISSING','PSTE_SEMANTIC_INTENT_CONSENSUS_MISSING','PSTE_SEMANTIC_FAMILY_CONSENSUS_MISSING','ARTICLE_TYPE_UNRESOLVED','EDITORIAL_TARGET_CATEGORY_MISSING','TARGET_CATEGORY_NOT_FOUND','TITLE_GENERATION_FAILED','TITLE_FAMILY_MISSING'];
        $reasons=array_values(array_diff(array_map('strval',(array)($payload['reason_codes']??[])),$stale));
        if(empty($semantic['ok'])){
            $payload['decision']='BLOCKED';$payload['human_review_required']=true;$payload['discovery_only']=true;
            $payload['reason_codes']=array_values(array_unique(array_merge($reasons,(array)($semantic['reason_codes']??[]))));
            $payload['textmachine_handoff_status']='BLOCKED_BEFORE_COMPILER';
            return $payload;
        }
        $type=(string)($semantic['resolved_article_type']??'');$target=(array)($semantic['resolved_category']??[]);
        if($type===''||empty($target['ok'])){
            $payload['decision']='BLOCKED';$payload['human_review_required']=true;$payload['discovery_only']=true;$payload['reason_codes']=array_values(array_unique(array_merge($reasons,['PSTE_SEMANTIC_RESOLVED_TARGET_INCOMPLETE'])));return $payload;
        }
        $payload['source_target_category_id']=$payload['source_target_category_id']??(int)($payload['target_category_id']??0);
        $payload['source_target_category_name']=$payload['source_target_category_name']??(string)($payload['target_category_name']??'');
        $payload['source_target_category_slug']=$payload['source_target_category_slug']??(string)($payload['target_category_slug']??'');
        $payload['source_proposed_article_type']=$payload['source_proposed_article_type']??(string)($payload['proposed_article_type']??'');
        $payload['suggested_article_type']=$type;$payload['proposed_article_type']=$type;
        $payload['suggested_category_id']=(int)$target['term_id'];$payload['target_category_id']=(int)$target['term_id'];
        $payload['suggested_category_name']=(string)$target['name'];$payload['target_category_name']=(string)$target['name'];
        $payload['suggested_category_slug']=(string)$target['slug'];$payload['target_category_slug']=(string)$target['slug'];
        $payload['available_article_types']=PSTE_Article_Type_Registry::availableTypes($registry,$familyKey);
        $intentNormalization=PSTE_Editorial_Topic_Normalizer::normalize($query,$familyName);
        $intentAnalysis=PSTE_Intent_Profile::analyzeBeforeType($query,$intentNormalization,$familyName,$payload);
        $intentProfile=PSTE_Intent_Profile::bindArticleType($intentAnalysis,$semantic,$registry,$familyKey);
        $payload['intent_analysis']=$intentAnalysis;$payload['intent_profile']=$intentProfile;$payload['intent_portfolio']=(array)($intentProfile['secondary_branches']??[]);$payload['search_intent']=(string)($intentProfile['search_intent']??'');$payload['intent_angle']=(string)($intentProfile['intent_angle']??'');
        if(empty($intentProfile['ok'])){$payload['decision']='BLOCKED';$payload['human_review_required']=true;$payload['discovery_only']=true;$payload['reason_codes']=array_values(array_unique(array_merge($reasons,['PSTE_LEGACY_BACKFILL_INTENT_BINDING_NOT_PASS'],(array)($intentProfile['reason_codes']??[]))));$payload['textmachine_handoff_status']='BLOCKED_BEFORE_COMPILER';return $payload;}
        $record=self::queryRecord($payload,$query);$payload['query_record']=$record;
        $title=PSTE_Title_Pipeline::build($record,$familyName,$type,$registry,[],$intentProfile);
        $payload['title_quality']=(array)($title['deterministic']??[]);$payload['language_quality']=(array)($title['language']??[]);
        $payload['production_title']=(string)($title['title']??'');$payload['editorial_title']=(string)($title['title']??'');$payload['target_keyword']=(string)($title['target_keyword']??'');$payload['target_keyword_contract']=(array)($title['target_keyword_contract']??[]);
        $payload['editorialization']=['contract'=>'PSTE_EDITORIALIZATION_V3','resolved'=>!empty($title['ok']),'eligible'=>!empty($title['ok']),'title'=>(string)($title['title']??''),'article_type'=>$type,'category_id'=>(int)$target['term_id'],'category_slug'=>(string)$target['slug'],'category_name'=>(string)$target['name'],'reason'=>'SEMANTIC_BACKFILL_INTENT_FIRST_TITLE_PIPELINE_V6_PPM_KEYWORD_BOUND','intent_first'=>true,'intent_key'=>(string)($intentProfile['intent_key']??'')];
        $payload['article_type_registry_sha256']=(string)($registry['registry_sha256']??'');
        $payload['research_job_contract']='PSTE_AUTOMATIC_LONGTAIL_RESEARCH_JOB_V2';$payload['research_run_status']='COMPLETE';
        $payload['metadata_handoff_fields']=['title','target_keyword','category','article_type','plan_slot'];
        $payload['textmachine_handoff_status']='BLOCKED_BEFORE_COMPILER';
        $payload['domain_risk']=is_array($payload['domain_risk']??null)&&array_key_exists('ok',$payload['domain_risk'])?$payload['domain_risk']:PSTE_Domain_Risk_Gate::evaluate($query,$type);
        $payload['freshness']=is_array($payload['freshness']??null)&&!empty($payload['freshness']['status'])?$payload['freshness']:(array)($record['freshness']??['status'=>'CURRENT']);
        if(!is_array($payload['pre_title_duplicate_gate']??null)||($payload['pre_title_duplicate_gate']['contract']??'')!=='PSTE_PRE_TITLE_DUPLICATE_GATE_V1'){
            $dupCodes=['PRE_TITLE_EXACT_DUPLICATE','PRE_TITLE_ANSWER_EQUIVALENT','EXACT_NORMALIZED_QUERY_DUPLICATE','SAME_INTENT_CLUSTER','CROSS_TYPE_ANSWER_EQUIVALENCE'];$found=array_values(array_intersect($dupCodes,$reasons));
            $payload['pre_title_duplicate_gate']=['contract'=>'PSTE_PRE_TITLE_DUPLICATE_GATE_V1','ok'=>!$found,'reason_codes'=>$found,'matches'=>[],'migration_scope'=>'LEGACY_STORED_REASON_RECONCILIATION_PLUS_COMPILER_LIVE_INVENTORY_RECHECK','write_attempted'=>false];
        }
        $payload['reason_codes']=array_values(array_unique(array_merge($reasons,(array)($title['deterministic']['reason_codes']??[]),(array)($title['language']['reason_codes']??[]))));
        $payload['decision']='BLOCKED';$payload['reason_codes']=array_values(array_unique(array_merge((array)($payload['reason_codes']??[]),['PSTE_LEGACY_BACKFILL_NO_RELEASE_AUTHORITY_CURRENT_NORMAL_PATH_REQUIRED'])));
        $payload['human_review_required']=$payload['decision']!=='PASS';$payload['discovery_only']=$payload['decision']!=='PASS';
        $payload['legacy_metadata_migration']=['contract'=>'PSTE_LEGACY_METADATA_MIGRATION_V1','provider_requests'=>0,'query_record_rebuilt'=>true,'compiler_live_inventory_recheck_required'=>true,'completed_at_utc'=>gmdate('c')];
        return $payload;
    }

    /** @return array<string,mixed> */
    private static function queryRecord(array $payload,string $query): array {
        $existing=$payload['query_record']??null;if(is_array($existing)&&trim((string)($existing['raw_query']??''))!=='')return $existing;
        $sources=[];$hashes=[];$observations=[];$captured='';
        foreach((array)($payload['evidence']??[]) as $e){if(!is_array($e))continue;$source=trim((string)($e['source']??''));$hash=trim((string)($e['raw_response_sha256']??''));if($source==='')continue;$sources[]=$source;if(preg_match('/^[a-f0-9]{64}$/',$hash))$hashes[$source]=$hash;$date=(string)($e['captured_at_utc']??'');if($date!==''&&($captured===''||(strtotime($date)?:0)>(strtotime($captured)?:0)))$captured=$date;$observations[]=['source_class'=>$source,'raw_value'=>(string)($e['raw_value']??$query),'retrieved_at_utc'=>$date?:gmdate('c'),'raw_response_sha256'=>$hash,'observation_id'=>(string)($e['observation_id']??''),'root_query'=>(string)($e['root_query']??$query),'parent_observation_id'=>(string)($e['parent_observation_id']??''),'depth'=>(int)($e['depth']??0),'query_kind'=>(string)($e['query_kind']??$source),'locale'=>(string)($e['location']??''),'language'=>(string)($e['language']??''),'freshness_status'=>(string)($e['freshness_status']??'CURRENT')];}
        if($captured==='')$captured=(string)($payload['first_seen_at']??$payload['last_seen_at']??gmdate('c'));if(strtotime($captured)===false)$captured=gmdate('c');
        $volume=is_numeric($payload['metrics']['search_volume']??null)?(int)$payload['metrics']['search_volume']:null;$monthly=(array)($payload['metrics']['monthly_searches']??[]);
        return PSTE_Query_Record::make($query,$volume,$monthly,array_values(array_unique($sources)),$hashes,$captured,$observations);
    }

    /** @return array<string,mixed> */
    private static function result(array $payload,array $semantic,string $query,string $familyKey,array $registry,array $resolution=[]): array {
        $payload['semantic_consensus']=$semantic;$payload['family_resolution']=$resolution;
        $payload['semantic_backfill']=['contract'=>'PSTE_SEMANTIC_BACKFILL_ITEM_V2','version'=>(string)PSTE_VERSION,'query_sha256'=>$query!==''?hash('sha256',$query):'','family_key'=>$familyKey,'registry_sha256'=>(string)($registry['registry_sha256']??''),'status'=>!empty($semantic['ok'])?'CONSENSUS_PASS':'CONSENSUS_REVIEW','provider_requests'=>0,'completed_at_utc'=>gmdate('c')];
        return ['payload'=>$payload,'semantic'=>$semantic,'query'=>$query,'family_key'=>$familyKey,'family_resolution'=>$resolution];
    }
    /** @return array<string,mixed> */
    private static function blocked(string $reason,string $familyKey,array $extra=[]): array {return array_merge(['contract'=>'PSTE_SEMANTIC_DOUBLE_STRAND_V3','ok'=>false,'status'=>'CONSENSUS_REVIEW','type_consensus'=>false,'category_consensus'=>false,'family_consensus'=>false,'meaning_consensus'=>false,'intent_consensus'=>false,'family_membership_gate'=>[],'strand_a'=>[],'strand_b'=>[],'resolved_article_type'=>'','resolved_category'=>[],'resolved_family'=>'','resolved_family_key'=>$familyKey,'reason_codes'=>[$reason],'independence'=>'FAMILY_MEMBERSHIP_PLUS_TWO_IMPLEMENTATIONS_NO_SHARED_TYPE_OR_CATEGORY_DECISION','provider_intent_used'=>false],$extra);}
    private static function safeErrorCode(Throwable $error): string {$message=trim((string)$error->getMessage());if($message==='')return 'PSTE_SEMANTIC_RECLASSIFY_UNKNOWN_ERROR';$code=strtoupper((string)preg_replace('/[^A-Z0-9_]+/','_',strtr($message,['ä'=>'AE','ö'=>'OE','ü'=>'UE','Ä'=>'AE','Ö'=>'OE','Ü'=>'UE','ß'=>'SS'])));return substr(trim($code,'_'),0,160)?:'PSTE_SEMANTIC_RECLASSIFY_UNKNOWN_ERROR';}
}
