# 0.10.6-staging — absichtliche Kategorienamen-Reparatur sicher gebunden

- Verarbeitet die elf am 30.07.2026 bewusst umbenannten Kategorien mit ihren aktuellen Namen.
- Bindet jede Umbenennung explizit und hashgebunden an den unveränderten Kategorie-Slug, die richtige Produktseite und die richtige Beitragsart.
- Verändert keine Kategorie, URL, Beitragszuordnung, Artikel, Textmaschine, Qualitätslogik oder Gestaltung.
- Ein geschützter Slug mit nicht freigegebenem Namen fällt nicht mehr in die dynamische Zuordnung zurück, sondern wird nur selbst mit genauer Diagnose blockiert.
- Der unveränderte restliche Portalbestand bleibt vollständig nutzbar.
