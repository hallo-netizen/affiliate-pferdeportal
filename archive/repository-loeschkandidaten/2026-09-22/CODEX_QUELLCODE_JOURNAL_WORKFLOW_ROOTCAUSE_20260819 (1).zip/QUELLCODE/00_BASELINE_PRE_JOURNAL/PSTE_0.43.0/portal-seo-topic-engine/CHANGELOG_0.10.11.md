# 0.10.11-staging

- Repariert den live belegten Finalisierungsfehler `PSTE_CONTEXT_QUERY_MISSING` im Ein-Klick-Recherchelauf.
- Ein einzelner Themenpool-Datensatz ohne auswertbare Query wird jetzt fail-closed mit `PSTE_CONTEXT_QUERY_MISSING` blockiert, statt den gesamten Lauf und alle übrigen Kandidaten zurückzurollen.
- Die Kandidatenisolation gilt sowohl für gezielte Kontextaktualisierungen des aktuellen Recherchelaufs als auch für allgemeine Kontext-Batches.
- Ein bereits bis `FINALIZE` gelaufener, sicher pausierter Rechercheauftrag kann nach dem Update ausdrücklich fortgesetzt werden; die drei gespeicherten Providerantworten werden dabei nicht erneut angefordert.
- Keine Änderung an DataForSEO-Endpunkten, Budgetlogik, Textmaschine, Artikelinhalten, HTML, Design, Kategorien, URLs, Yoast-Daten oder WordPress-Beiträgen.
