# 0.9.3-staging

- Ersetzt den synchronen Live-SERP-Batch durch einen persistenten, wiederaufnehmbaren Einzelstep-Auftrag.
- Höchstens eine kostenpflichtige Provideranfrage je Worker-Schritt.
- Sofortige persistente Speicherung jedes einzelnen SERP-Ergebnisses und jedes Intent-Ergebnisses.
- Begrenzter Backoff-Retry für DataForSEO 40101/40103 und HTTP 429/500/503.
- Kein blinder Retry bei unbekanntem Transportausgang oder ungültigem JSON.
- Idempotente Kostenbuchung je Versuch und fail-closed In-Flight-Erkennung.
- Vorabvalidierung der Evidence Registry und der letzten Evidenz vor dem ersten Provideraufruf.
- Keine Änderung an Artikeln, Inhalt, HTML, Design, Textengine, Produktionsmaschine oder Qualitätslogik.
- Atomare Tages-/Monatsbudget-Reservierung für parallele kostenpflichtige SEO-Läufe; Verpflichtungen werden erst nach idempotenter Kostenbuchung reduziert.
- WP-Cron bleibt bei nicht freigegebenem Safe-Boot-Status hart inaktiv.
- Ein Auftrag mit unbekanntem Providerausgang kann erst nach ausdrücklicher manueller Kostenabgleich-Bestätigung abgebrochen werden.
