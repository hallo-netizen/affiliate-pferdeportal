# 0.10.12-staging

- Reclassifies every non-quarantined persisted topic against the current read-only portal baseline.
- Backfills a valid `PSTE_SEMANTIC_DOUBLE_STRAND_V2` result for legacy topics without `semantic_consensus`.
- Isolates topic-level classification failures; one malformed topic never rolls back valid topics.
- Makes zero provider requests during the backfill and writes only to the SEO engine own topic-pool data and audit option.
- Does not modify posts, terms, URLs, Yoast data, design, article content or the production machine.
- Schema 11 exists solely to execute and prove this one-time semantic backfill.
