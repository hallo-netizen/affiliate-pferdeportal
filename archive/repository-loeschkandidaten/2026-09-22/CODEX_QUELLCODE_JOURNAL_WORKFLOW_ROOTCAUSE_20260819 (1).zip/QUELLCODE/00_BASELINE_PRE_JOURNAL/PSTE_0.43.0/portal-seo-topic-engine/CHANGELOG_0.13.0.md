# Portal SEO Themenengine 0.13.0 — External-Relevance-First Sandbox

## Ursache

Die erste Sandbox-Architektur koppelte die externe SEO-Relevanzprüfung fälschlich an eine bereits vorhandene interne Familiennähe. Dadurch konnten fachlich wertvolle, vom Hauptmatcher blockierte Longtails ohne passende aktuelle Familienstruktur von der realen SEO-Prüfung ausgeschlossen werden. Interne Zuordenbarkeit und externe Themenrelevanz waren in der falschen Reihenfolge gekoppelt.

## Gebündelte Korrektur

1. Alle aktuellen `NEWLY_BLOCKED`-Longtails werden weiterhin verlustfrei gespeichert.
2. Jeder Kandidat mit unverändertem Quelldatensatz ist unabhängig von Familiennähe, Kontextfehler oder interner Ausschlussdiagnose für die externe Google-/SEO-Relevanzprüfung zugelassen.
3. Erst nach `RELEVANT_FOR_PORTAL` wird die interne Portalzuordnung ausgeführt.
4. Fehlt für ein extern relevantes Keyword eine belastbare bestehende Familie, entsteht `STRUCTURE_GAP` statt `TRUE_NO_MATCH`.
5. Aktive Ausschlussdiagnosen des Hauptmatchers dürfen extern nicht die Relevanzprüfung verhindern, blockieren aber weiterhin eine automatische interne Familienproposition.
6. Vorherige Review-Evidenz wird bei Policy-/Binding-Wechseln archiviert, nicht gelöscht.
7. Bestehende Kostenlimits werden nicht verändert. Ist der offene Bestand größer als das vorhandene Run-/Tages-/Monatsbudget, wird nur ein budgetkonformer Teilblock verarbeitet; alle übrigen Kandidaten bleiben offen erhalten.

## Hauptregel 1

Keine Änderung an Hauptmatcher, Family Identity V2, Normalizer, Textmaschine/PPM, Compiler, Titelpipeline, Artikel-/Entwurfsinhalten, Postmeta, Terms, HTML, CSS oder Design. Die Sandbox besitzt weiterhin keinen Apply- und keinen Produktions-Handoff.
