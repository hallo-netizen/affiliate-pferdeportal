# 0.18.2

- Behebt den adversarial bestätigten V5-Blocker als Fehlerklasse: Das Laden der Themenengine bei einem beliebigen WordPress-Request ist jetzt **registrierungs-only** und löst keine Migration, keinen Legacy-Cleanup und keine Cron-Neuplanung aus.
- Der automatische redaktionelle Metadaten-Rebuild ist an `admin_init` gebunden und zusätzlich strikt auf die eigenen Seiten der Portal SEO Themenengine begrenzt.
- Die Themenengine selbst besitzt die exakte Whitelist ihrer Admin-Slugs; Dashboard, Beitragslisten, Compiler-Vorschau, fremde Adminseiten, Prefix-Lookalikes und Requests ohne PSTE-Seitenkontext lösen keine PSTE-Wartung aus.
- Legacy-Cleanup und interne tägliche Recheck-Planung laufen ebenfalls nur in expliziten PSTE-Lifecycle-Kontexten: Aktivierung, manueller Migrations-/Retry-Pfad oder eigene PSTE-Adminseiten.
- READY bleibt an DB-Schema **und** aktuellen Editorial-Ruleset-Marker gebunden; Rebuildfehler bleiben fail-closed sichtbar.
- Keine Änderungen an Artikeln, Terms, Postmeta, Textmaschine, Produktionsprompts, Design oder Inhaltsdaten.
