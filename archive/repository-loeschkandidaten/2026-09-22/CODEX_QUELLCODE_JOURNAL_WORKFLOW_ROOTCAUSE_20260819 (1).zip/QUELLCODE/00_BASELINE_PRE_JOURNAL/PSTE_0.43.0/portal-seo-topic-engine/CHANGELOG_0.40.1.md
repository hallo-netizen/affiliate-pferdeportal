# 0.40.1 – Backend-Performance ohne Workflowänderung

- Ausschließlich Performancekorrektur im read-only Snapshotpfad.
- `PSTE_Snapshot::structure()` wird innerhalb **eines PHP-Requests** exakt einmal aufgebaut und danach request-lokal bytegleich wiederverwendet.
- Beseitigt die mehrfachen vollständigen 1124-Kategorien-/Portalstruktur-Scans in `Gesamtbestand neu abgleichen`, Baseline-Freshness und PSERC-Metadatenvorschau.
- Keine persistente Cache-Schicht, keine TTL, keine Veränderung der Live-Freshness zwischen Requests.
- Keine Änderung an Workflow, Reihenfolge, Gates, Recherche, Themenwahl, Titelregeln, Textmaschine, PPM, Artikelinhalt, HTML, CSS oder Design.
- Keine Änderung an WordPress-Beiträgen, Seiten, Kategorien oder URLs.
