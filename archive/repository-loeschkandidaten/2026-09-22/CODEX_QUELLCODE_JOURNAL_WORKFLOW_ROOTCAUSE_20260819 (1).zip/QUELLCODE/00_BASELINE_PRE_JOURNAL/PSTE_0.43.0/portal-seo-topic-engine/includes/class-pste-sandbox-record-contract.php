<?php
if (!defined('ABSPATH')) { return; }

/**
 * Canonical producer→persisted-record→consumer contract for Sandbox diagnostics.
 *
 * This class owns no relevance decision, article/content generation or production handoff.
 * It only binds evidence already produced from the immutable raw query + current portal baseline
 * to one durable Sandbox record and proves that later consumers read the exact stored values.
 */
final class PSTE_Sandbox_Record_Contract {
    public const CONTRACT='PSTE_SANDBOX_RECORD_DATAFLOW_V1';
    public const ADMIN_VIEW_CONTRACT='PSTE_SANDBOX_ADMIN_VIEW_V1';

    /** @return array<string,mixed> */
    public static function fromNormalPath(string $query,array $normalPath,array $baseline,array $registry): array {
        $query=self::clean($query);if($query==='')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_QUERY_REQUIRED');
        if(($normalPath['contract']??'')!==PSTE_Normal_Metadata_Path::CONTRACT)throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_CONTRACT_INVALID');
        $rawSha=(string)($normalPath['raw_query_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$rawSha)||!hash_equals(hash('sha256',$query),$rawSha))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_RAW_MISMATCH');
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_BASELINE_REQUIRED');
        if(empty($registry['registry_sha256']))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_REGISTRY_REQUIRED');

        // One canonical producer for the visible local portal evidence. Never copy a partial gate object.
        $portalContext=PSTE_Category_Context::portalContextEvidence($query,$baseline);
        if(($portalContext['contract']??'')!=='PSTE_PORTAL_CONTEXT_EVIDENCE_V1')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_PORTAL_CONTEXT_INVALID');

        $gate=(array)($normalPath['portal_relevance_gate']??[]);
        $portal=$portalContext;
        $portal['status']=(string)($normalPath['portal_relevance']??'UNPROVEN');
        $portal['decision_status']=$portal['status'];
        $portal['source']=(string)($gate['source']??'CURRENT_NORMAL_PATH');
        $portal['decision_gate_contract']=(string)($gate['contract']??'');
        $portal['decision_gate_sha256']=$gate?self::hash($gate):'';
        $portal['diagnostic_only']=true;

        $nearest=self::nearestFromNormalPath($normalPath);
        $nearestFailures=self::nearestFailureReasons($normalPath);
        $exclusions=PSTE_Sandbox_Portal_Relevance::exclusionEvidence($query,$registry,$nearest);
        if(($exclusions['contract']??'')!=='PSTE_SANDBOX_EXCLUSION_EVIDENCE_V1')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_EXCLUSION_EVIDENCE_INVALID');

        $payload=[
            'contract'=>self::CONTRACT,
            'producer'=>'PSTE_NORMAL_PATH_PLUS_CURRENT_PORTAL_CONTEXT',
            'query_sha256'=>hash('sha256',$query),
            'normal_path_sha256'=>self::hash($normalPath),
            'portal_relevance'=>$portal,
            'nearest_rejected_families'=>$nearest,
            'nearest_failure_reason_codes'=>$nearestFailures,
            'exclusion_evidence'=>$exclusions,
            'write_attempted'=>false,
            'production_handoff_attempted'=>false,
        ];
        $payload['portal_relevance_sha256']=self::hash($portal);
        $payload['nearest_rejected_families_sha256']=self::hash($nearest);
        $payload['exclusion_evidence_sha256']=self::hash($exclusions);
        $payload['dataflow_sha256']=self::hash($payload);
        return $payload;
    }

    /** Compatibility producer for the legacy dry-run lane; values still pass through the same record contract. @return array<string,mixed> */
    public static function fromLegacyRoute(string $query,array $route,array $nearest,array $nearestFailureReasons=[],array $normalPath=[]): array {
        $query=self::clean($query);if($query==='')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_QUERY_REQUIRED');
        $portal=(array)($route['portal_context']??[]);$exclusions=(array)($route['exclusion_evidence']??[]);
        if(($portal['contract']??'')!=='PSTE_PORTAL_CONTEXT_EVIDENCE_V1')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_LEGACY_PORTAL_CONTEXT_INVALID');
        if(($exclusions['contract']??'')!=='PSTE_SANDBOX_EXCLUSION_EVIDENCE_V1')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_LEGACY_EXCLUSION_INVALID');
        $portal['status']='UNPROVEN';$portal['decision_status']='UNPROVEN';$portal['source']='LEGACY_DRY_RUN_DIAGNOSTIC';$portal['diagnostic_only']=true;
        $nearest=array_values($nearest);
        $payload=['contract'=>self::CONTRACT,'producer'=>'PSTE_LEGACY_DRY_RUN_ROUTE','query_sha256'=>hash('sha256',$query),'normal_path_sha256'=>$normalPath?self::hash($normalPath):'','portal_relevance'=>$portal,'nearest_rejected_families'=>$nearest,'nearest_failure_reason_codes'=>array_values(array_unique(array_filter(array_map('strval',$nearestFailureReasons),'strlen'))),'exclusion_evidence'=>$exclusions,'write_attempted'=>false,'production_handoff_attempted'=>false];
        $payload['portal_relevance_sha256']=self::hash($portal);$payload['nearest_rejected_families_sha256']=self::hash($nearest);$payload['exclusion_evidence_sha256']=self::hash($exclusions);$payload['dataflow_sha256']=self::hash($payload);return $payload;
    }

    /** @return array<string,mixed> */
    public static function applyToRecord(array $record,array $flow,array $normalPath=[]): array {
        self::assertFlow($flow);
        $record['portal_relevance']=(array)$flow['portal_relevance'];
        $record['nearest_rejected_families']=array_values((array)$flow['nearest_rejected_families']);
        $record['nearest_failure_reason_codes']=array_values(array_map('strval',(array)$flow['nearest_failure_reason_codes']));
        $record['exclusion_evidence']=(array)$flow['exclusion_evidence'];
        if($normalPath)$record['normal_path_admission']=$normalPath;
        $record['sandbox_dataflow']=$flow;
        return $record;
    }

    /** @return array<string,mixed> */
    public static function verifyRecordAgainstNormalPath(array $record,array $normalPath,array $baseline,array $registry): array {
        $query=self::clean((string)($record['query']??''));$expected=self::fromNormalPath($query,$normalPath,$baseline,$registry);
        $stored=(array)($record['sandbox_dataflow']??[]);self::assertFlow($stored);
        foreach(['portal_relevance','nearest_rejected_families','nearest_failure_reason_codes','exclusion_evidence'] as $field){
            if(self::hash($record[$field]??null)!==self::hash($expected[$field]??null))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_RECORD_FIELD_MISMATCH_'.strtoupper($field));
        }
        if(!hash_equals((string)$expected['normal_path_sha256'],(string)($stored['normal_path_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NORMAL_PATH_HASH_MISMATCH');
        if(!hash_equals((string)$expected['portal_relevance_sha256'],(string)($stored['portal_relevance_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_PORTAL_HASH_MISMATCH');
        if(!hash_equals((string)$expected['nearest_rejected_families_sha256'],(string)($stored['nearest_rejected_families_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NEAREST_HASH_MISMATCH');
        if(!hash_equals((string)$expected['exclusion_evidence_sha256'],(string)($stored['exclusion_evidence_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_EXCLUSION_HASH_MISMATCH');
        if(self::hash((array)($record['normal_path_admission']??[]))!==self::hash($normalPath))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_ADMISSION_PATH_MISMATCH');
        return ['contract'=>'PSTE_SANDBOX_RECORD_DATAFLOW_VERIFY_V1','status'=>'PASS','query_sha256'=>(string)$expected['query_sha256'],'dataflow_sha256'=>(string)$stored['dataflow_sha256'],'write_attempted'=>false,'production_handoff_attempted'=>false];
    }

    /** @return array<string,mixed> */
    public static function adminView(array $record): array {
        $flow=(array)($record['sandbox_dataflow']??[]);self::assertFlow($flow);
        foreach(['portal_relevance','nearest_rejected_families','nearest_failure_reason_codes','exclusion_evidence'] as $field){if(self::hash($record[$field]??null)!==self::hash($flow[$field]??null))throw new RuntimeException('PSTE_SANDBOX_ADMIN_CONSUMER_DATAFLOW_MISMATCH_'.strtoupper($field));}
        return [
            'contract'=>self::ADMIN_VIEW_CONTRACT,
            'sandbox_id'=>(string)($record['sandbox_id']??''),'query'=>(string)($record['query']??''),'search_volume'=>$record['search_volume']??null,
            'local_matched_terms'=>array_values((array)($flow['portal_relevance']['matched_terms']??[])),
            'portal_relevance'=>(array)$flow['portal_relevance'],'exclusion_evidence'=>(array)$flow['exclusion_evidence'],
            'nearest_rejected_families'=>array_values((array)$flow['nearest_rejected_families']),
            'external_relevance'=>$record['external_relevance']??null,'relevance_adjudication'=>$record['relevance_adjudication']??null,'relevance_revision_count'=>count((array)($record['relevance_revision_archive']??[])),
            'current_relevance_proof'=>$record['current_relevance_proof']??null,'relevance_conflict'=>$record['relevance_conflict']??null,
            'internal_proposal'=>$record['internal_proposal']??null,'internal_proposal_sha256'=>(string)($record['internal_proposal_sha256']??''),
            'status'=>(string)($record['status']??''),'workflow_lane'=>(string)($record['workflow_lane']??''),
            'dataflow_status'=>'VERIFIED','dataflow_sha256'=>(string)$flow['dataflow_sha256'],'write_attempted'=>false,'production_handoff_attempted'=>false,
        ];
    }

    /** Validate one persisted current-contract record without recomputing domain decisions. */
    public static function verifyStoredRecordSelfConsistency(array $record): array {
        $flow=(array)($record['sandbox_dataflow']??[]);self::assertFlow($flow);
        $query=self::clean((string)($record['query']??''));
        if($query===''||!hash_equals((string)($flow['query_sha256']??''),hash('sha256',$query)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_STORED_QUERY_MISMATCH');
        foreach(['portal_relevance','nearest_rejected_families','nearest_failure_reason_codes','exclusion_evidence'] as $field){
            if(self::hash($record[$field]??null)!==self::hash($flow[$field]??null))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_STORED_FIELD_MISMATCH_'.strtoupper($field));
        }
        $normalHash=(string)($flow['normal_path_sha256']??'');
        if($normalHash!==''){
            $admission=(array)($record['normal_path_admission']??[]);
            if(!$admission||!hash_equals($normalHash,self::hash($admission)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_STORED_ADMISSION_PATH_MISMATCH');
        }
        return ['contract'=>'PSTE_SANDBOX_STORED_RECORD_SELF_VERIFY_V1','status'=>'PASS','dataflow_sha256'=>(string)$flow['dataflow_sha256'],'write_attempted'=>false,'production_handoff_attempted'=>false];
    }

    public static function hasCurrentContract(array $record): bool {try{self::assertFlow((array)($record['sandbox_dataflow']??[]));return true;}catch(Throwable $e){return false;}}

    /** @return array<int,array<string,mixed>> */
    private static function nearestFromNormalPath(array $normalPath): array {
        $fr=(array)($normalPath['family_resolution']??[]);$diag=(array)($fr['rejection_diagnostics']??[]);$nearest=(array)($diag['nearest_rejected_families']??$fr['nearest_rejected_families']??[]);
        if(!$nearest){$hint=(array)($normalPath['portal_relevance_gate']['family_hint']['resolution']??[]);$hd=(array)($hint['rejection_diagnostics']??[]);$nearest=(array)($hd['nearest_rejected_families']??$hint['nearest_rejected_families']??[]);}
        return array_values($nearest);
    }
    /** @return list<string> */
    private static function nearestFailureReasons(array $normalPath): array {
        $codes=[];$membership=(array)($normalPath['family_membership']??[]);$codes=array_merge($codes,(array)($membership['reason_codes']??[]));$fr=(array)($normalPath['family_resolution']??[]);$diag=(array)($fr['rejection_diagnostics']??[]);$codes=array_merge($codes,(array)($diag['nearest_failure_reason_codes']??[]));
        return array_values(array_unique(array_filter(array_map('strval',$codes),'strlen')));
    }
    private static function assertFlow(array $flow): void {
        if(($flow['contract']??'')!==self::CONTRACT)throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_CONTRACT_INVALID');
        $declared=(string)($flow['dataflow_sha256']??'');$copy=$flow;unset($copy['dataflow_sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(self::hash($copy),$declared))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_HASH_INVALID');
        foreach(['portal_relevance_sha256','nearest_rejected_families_sha256','exclusion_evidence_sha256'] as $f)if(!preg_match('/^[a-f0-9]{64}$/',(string)($flow[$f]??'')))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_COMPONENT_HASH_INVALID');
        if(!hash_equals((string)$flow['portal_relevance_sha256'],self::hash($flow['portal_relevance']??null)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_PORTAL_COMPONENT_DRIFT');
        if(!hash_equals((string)$flow['nearest_rejected_families_sha256'],self::hash($flow['nearest_rejected_families']??null)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_NEAREST_COMPONENT_DRIFT');
        if(!hash_equals((string)$flow['exclusion_evidence_sha256'],self::hash($flow['exclusion_evidence']??null)))throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_EXCLUSION_COMPONENT_DRIFT');
    }
    private static function clean(string $v): string {return PSTE_Normal_Metadata_Path::canonicalInputQuery($v);}
    private static function hash($v): string {$j=function_exists('wp_json_encode')?wp_json_encode(self::canonicalize($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode(self::canonicalize($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return hash('sha256',(string)$j);}
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
}
