<?php
if (!defined('ABSPATH')) { return; }

final class PSTE_Runner {
    /** @return array<string,mixed> */
    public static function makeCandidate(string $query,array $context): array {
        $categoryName=(string)($context['category_name']??'');$familyName=trim((string)($context['topic_family_name']??PSTE_Normalizer::categoryFamilyName($categoryName)));$familyKey=trim((string)($context['topic_family_key']??PSTE_Normalizer::categoryFamilyKey($categoryName)));
        $tuple=PSTE_Normalizer::intentTuple($query,$categoryName,(string)($context['answer_promise']??$query));$type=(string)($context['article_type']??'');
        return [
            'candidate_id'=>hash('sha256',$familyKey.'|'.PSTE_Normalizer::exactTopicIdentityText($query).'|'.PSTE_Article_Type_Registry::canonicalType($type)),
            'target_category_id'=>(int)($context['category_id']??0),'target_category_slug'=>(string)($context['category_slug']??''),'target_category_name'=>$categoryName,
            'suggested_category_id'=>(int)($context['category_id']??0),'suggested_category_slug'=>(string)($context['category_slug']??''),'suggested_category_name'=>$categoryName,
            'topic_family_name'=>$familyName,'topic_family_key'=>$familyKey,'proposed_article_type'=>$type,'suggested_article_type'=>$type,'article_type_source'=>'PSTE_SEMANTIC_DOUBLE_STRAND_V2',
            'primary_longtail_query'=>$query,'canonical_query'=>$query,'raw_user_question'=>PSTE_Normalizer::isQuestion($query)?PSTE_Normalizer::canonicalQuestion($query):'',
            'discovery_only'=>false,'candidate_role'=>'ARTICLE_TOPIC','derived_from_candidate_id'=>'','intent_cluster_id'=>PSTE_Normalizer::clusterId($tuple),'intent_tuple'=>$tuple,
            'head_term_collision'=>PSTE_Normalizer::text($query)===PSTE_Normalizer::categoryHead($categoryName),'evidence'=>array_values((array)($context['evidence']??[])),
            'metrics'=>$context['metrics']??['search_volume'=>null,'monthly_searches'=>[],'trend'=>null,'search_intent'=>null,'intent_probability'=>null],
            'closest_existing_matches'=>[],'decision'=>'REVIEW_REQUIRED','reason_codes'=>[],'human_review_required'=>false,'research_context'=>(array)($context['research_context']??[]),
        ];
    }

    /** Local fixture helper using the current semantic/title path, no network and no writes. */
    public static function fixturePilot(array $rawCandidates,array $inventory,array $structure,array $baseline=[]): array {
        if(!$baseline)$baseline=['contract'=>'PSTE_SITE_BASELINE_V1','taxonomy_contract'=>'PSTE_PORTAL_TAXONOMY_SNAPSHOT_V3','leaf_categories'=>array_values(array_filter($structure,static fn($r)=>!empty($r['is_leaf']))),'status'=>'CURRENT'];
        $registry=PSTE_Article_Type_Registry::build($baseline);$out=[];
        foreach($rawCandidates as $raw){
            $familyKey=(string)($raw['topic_family_key']??'');$family=(string)($raw['topic_family_name']??'');$query=(string)($raw['query']??'');
            $normalization=PSTE_Editorial_Topic_Normalizer::normalize($query,$family);$sourceEvidence=['metrics'=>['search_intent'=>$raw['search_intent']??null,'intent_probability'=>$raw['intent_probability']??null],'evidence'=>(array)($raw['evidence']??[])];
            $intentAnalysis=PSTE_Intent_Profile::analyzeBeforeType($query,$normalization,$family,$sourceEvidence);
            $semantic=PSTE_Semantic_Classifier::classify($query,(string)($raw['search_intent']??''),$registry,$familyKey);if(empty($semantic['ok'])){$out[]=['query'=>$query,'decision'=>'BLOCKED','intent_analysis'=>$intentAnalysis,'semantic_consensus'=>$semantic];continue;}
            $intentProfile=PSTE_Intent_Profile::bindArticleType($intentAnalysis,$semantic,$registry,$familyKey);if(empty($intentProfile['ok'])){$out[]=['query'=>$query,'decision'=>'BLOCKED','intent_analysis'=>$intentAnalysis,'intent_profile'=>$intentProfile,'semantic_consensus'=>$semantic];continue;}
            $target=(array)$semantic['resolved_category'];$record=PSTE_Query_Record::make($query,$raw['search_volume']??null,[],['FIXTURE'],[],gmdate('c'));$title=PSTE_Title_Pipeline::build($record,$family,(string)$semantic['resolved_article_type'],$registry,[],$intentProfile);$candidate=self::makeCandidate((string)$record['language_corrected_query'],['category_id'=>$target['term_id'],'category_slug'=>$target['slug'],'category_name'=>$target['name'],'topic_family_name'=>$family,'topic_family_key'=>$familyKey,'article_type'=>$semantic['resolved_article_type'],'evidence'=>(array)($raw['evidence']??[['source'=>'FIXTURE']]),'metrics'=>$sourceEvidence['metrics']]);$candidate['intent_analysis']=$intentAnalysis;$candidate['intent_profile']=$intentProfile;$candidate['editorial_title']=$title['title'];$candidate['production_title']=$title['title'];$candidate['target_keyword']=(string)($title['target_keyword']??'');$candidate['target_keyword_contract']=(array)($title['target_keyword_contract']??[]);$candidate['editorialization']=['contract'=>PSTE_Editorializer::RULESET,'resolved'=>$title['ok'],'eligible'=>$title['ok'],'title'=>$title['title'],'article_type'=>$semantic['resolved_article_type'],'intent_first'=>true];$decision=PSTE_Cannibalization::decide($candidate,$inventory,$structure,[]);$candidate['decision']=$title['ok']?$decision['decision']:'BLOCKED';$candidate['reason_codes']=array_values(array_unique(array_merge((array)($title['deterministic']['reason_codes']??[]),(array)($title['language']['reason_codes']??[]),$decision['reason_codes'])));$out[]=$candidate;
        }
        return $out;
    }

    public static function createRunSkeleton(int $categoryId,string $seed,array $settings): array {
        $inventory=PSTE_Snapshot::inventory();$structure=PSTE_Snapshot::structure();$plan=PSTE_Snapshot::editorialPlan();$estimated=PSTE_Cost_Guard::estimateCategoryResearch(100);
        PSTE_Cost_Guard::assertWithin($estimated,(float)$settings['run_budget_usd'],(float)$settings['absolute_ceiling_usd']);$now=gmdate('Y-m-d H:i:s');
        return ['run_uuid'=>wp_generate_uuid4(),'status'=>'READY_FOR_LONGTAIL_RESEARCH','category_id'=>$categoryId,'seed'=>$seed,'estimated_cost'=>$estimated,'actual_cost'=>0.0,'snapshot'=>['inventory'=>$inventory,'structure'=>$structure,'editorial_plan'=>$plan],
            'payload'=>['location'=>$settings['location'],'language'=>$settings['language'],'environment'=>$settings['environment'],'workflow'=>'LONGTAIL_RESEARCH_TO_METADATA_V2','provider_calls'=>3,'google_live_serp_used'=>false,'textmachine_write_attempted'=>false],'created_at'=>$now,'updated_at'=>$now];
    }

    public static function captureSiteBaseline(): array {
        $baseline=PSTE_Snapshot::siteBaseline();update_option(PSTE_OPTION_SITE_BASELINE,$baseline,false);$stored=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($stored)||!hash_equals((string)$baseline['baseline_sha256'],(string)($stored['baseline_sha256']??'')))throw new RuntimeException('PSTE_SITE_BASELINE_READBACK_MISMATCH');
        if(($baseline['status']??'')!=='CURRENT')return $baseline;
        $registry=PSTE_Article_Type_Registry::build($baseline);update_option(PSTE_OPTION_EDITORIAL_RULESET,['contract'=>'PSTE_SEMANTIC_TITLE_CONTRACT_V2','article_type_registry_sha256'=>$registry['registry_sha256'],'captured_at_utc'=>gmdate('c'),'legacy_reclassification_executed'=>false],false);
        $context=PSTE_Context_Refresh::start($baseline,'BASELINE_CAPTURE');
        $baseline['article_type_registry_sha256']=$registry['registry_sha256'];$baseline['portal_context_sync']=$context;
        $baseline['sandbox_binding_refresh']=[
            'contract'=>'PSTE_SANDBOX_BINDING_REFRESH_V2_BATCHED',
            'status'=>(string)($context['sandbox_binding_status']??'PENDING'),
            'total'=>(int)($context['sandbox_total']??0),
            'processed'=>(int)($context['sandbox_processed']??0),
            'source_stale'=>(int)($context['sandbox_source_stale']??0),
            'execution'=>'EXISTING_PORTAL_CONTEXT_JOB_REQUEST_BOUNDED',
            'external_provider_calls'=>0,
            'production_handoff_attempted'=>false,
            'article_or_taxonomy_write_attempted'=>false,
        ];
        return $baseline;
    }

    public static function aggregateRunStatus(array $decisions): string {$decisions=array_values(array_filter(array_map('strval',$decisions)));if(!$decisions)return 'ANALYZED_NO_ELIGIBLE_CANDIDATE';return in_array('PASS',$decisions,true)?'ANALYZED':'ANALYZED_NO_ELIGIBLE_CANDIDATE';}
    public static function connectionTest(string $environment): array {$client=new PSTE_DataForSEO_Client($environment);$locations=$client->request('GET','/v3/dataforseo_labs/locations_and_languages');$status=$client->request('GET','/v3/dataforseo_labs/status');$result=['status'=>'PASS','locations'=>PSTE_DataForSEO_Client::sanitizedSummary($locations),'labs_status'=>PSTE_DataForSEO_Client::sanitizedSummary($status),'credentials'=>PSTE_Credentials::status()];if($environment==='production'){$user=$client->request('GET','/v3/appendix/user_data');$result['account']=PSTE_DataForSEO_Client::extractAccountStatus($user);}return $result;}
    public static function runPilot(int $categoryId,string $seed,array $settings): array {throw new RuntimeException('PSTE_SYNCHRONOUS_RESEARCH_WORKFLOW_REMOVED');}

    /** Final local processing after three bounded keyword-source steps. No network, post, term or text-machine writes. */
    public static function finalizeResearchJob(array $job): array {
        if(($job['contract']??'')!==PSTE_Research_Job::CONTRACT)throw new RuntimeException('PSTE_RESEARCH_JOB_CONTRACT_INVALID');$siteBaseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($siteBaseline)||($siteBaseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');$baselineState=PSTE_Snapshot::baselineStatus($siteBaseline);if(empty($baselineState['current']))throw new RuntimeException('PSTE_SITE_BASELINE_STALE');
        $registry=PSTE_Article_Type_Registry::build($siteBaseline);$selected=(array)($job['selected_category']??[]);$researchContext=(array)($job['research_context']??[]);$effectiveSeed=(string)($researchContext['effective_seed']??$job['seed']??'');$family=(string)($selected['topic_family_name']??'');$familyKey=(string)($selected['topic_family_key']??'');if($effectiveSeed===''||$family===''||$familyKey==='')throw new RuntimeException('PSTE_RESEARCH_JOB_CONTEXT_INVALID');
        $sourceDefinitions=['KEYWORD_SUGGESTION'=>'dataforseo_labs/google/keyword_suggestions/live','RELATED_SEARCH'=>'dataforseo_labs/google/related_keywords/live','KEYWORD_IDEA'=>'dataforseo_labs/google/keyword_ideas/live'];
        $exact=[];$captured=gmdate('c');
        foreach($sourceDefinitions as $source=>$path){$stored=(array)($job['sources'][$source]??[]);self::assertStoredSource($source,$stored);$sourceCaptured=(string)($stored['captured_at_utc']??'');if($sourceCaptured===''||strtotime($sourceCaptured)===false)throw new RuntimeException('PSTE_RESEARCH_SOURCE_CAPTURED_AT_INVALID_'.$source);foreach((array)$stored['items'] as $item){$raw=(string)($item['keyword']??'');if(trim($raw)==='')continue;self::appendExact($exact,$raw,$item['search_volume']??null,(array)($item['monthly_searches']??[]),$source,(string)$stored['response_sha256'],$sourceCaptured,null,(array)($item['observation']??[]));}}
        foreach(PSTE_First_Party_Import::matching($effectiveSeed,(string)($selected['name']??''),get_option(PSTE_OPTION_FIRST_PARTY,[])) as $item){$raw=(string)($item['query']??'');if(trim($raw)==='')continue;$hash=hash('sha256',self::json($item));$obs=['observation_id'=>'obs:'.substr(hash('sha256',(string)$job['job_uuid'].'|GSC|'.$raw.'|'.$hash),0,32),'source_class'=>'GSC','provider'=>'GOOGLE_SEARCH_CONSOLE','query_kind'=>'FIRST_PARTY_QUERY','root_query'=>$effectiveSeed,'parent_observation_id'=>'','depth'=>1,'raw_value'=>$raw,'locale'=>(string)$job['location'],'language'=>(string)$job['language'],'parameters'=>['read_only'=>true],'retrieved_at_utc'=>$captured,'raw_response_sha256'=>$hash,'measurement_status'=>'UNMEASURED','relation'=>'RELATED_ENTITY','relation_evidence'=>['portal_query_match'],'freshness_status'=>'CURRENT','valid_until'=>gmdate('c',(strtotime($captured)?:time())+90*86400)];self::appendExact($exact,$raw,null,[],'GSC',$hash,$captured,$item,$obs);}
        $groups=self::aliasGroups($exact);$ranked=[];$familyFilter=['contract'=>'PSTE_FAMILY_FILTER_DIAGNOSTICS_V2','provider_rows_before_exact_dedup'=>array_sum(array_map(static fn($s)=>count((array)($s['items']??[])),(array)($job['sources']??[]))),'exact_rows_after_dedup'=>count($exact),'alias_groups_before_family_gate'=>count($groups),'family_match'=>0,'family_review'=>0,'family_no_match'=>0,'rejection_reason_counts'=>[],'rejection_samples'=>[]];
        foreach($groups as $group){
            $record=$group['canonical_record'];$query=(string)$record['language_corrected_query'];$membership=PSTE_Family_Membership::evaluate(PSTE_Editorial_Topic_Normalizer::semanticProbe($query),$registry,$familyKey);$v2Status=(string)($membership['v2_status']??(!empty($membership['ok'])?'MATCH':'REVIEW'));
            if($v2Status==='MATCH')$familyFilter['family_match']++;
            else{
                $bucket=$v2Status==='REVIEW'?'family_review':'family_no_match';$familyFilter[$bucket]++;
                foreach((array)($membership['reason_codes']??[]) as $reason)$familyFilter['rejection_reason_counts'][(string)$reason]=($familyFilter['rejection_reason_counts'][(string)$reason]??0)+1;
                if(count($familyFilter['rejection_samples'])<50)$familyFilter['rejection_samples'][]=['query'=>$query,'status'=>$v2Status,'reason_codes'=>array_values((array)($membership['reason_codes']??[])),'diagnostics'=>(array)($membership['diagnostics']??[])];
            }
            // Hard preservation rule: REVIEW/NO_MATCH is retained and routed, never dropped.
            $group['family_membership_v2']=$membership;$group['research_origin_family_status']=$v2Status;$group['intent']=['search_intent'=>null,'intent_probability'=>null];$group['rank_score']=self::rankScore($record,(array)$group['aliases'],$group['first_party']??null);$ranked[]=$group;
        }
        ksort($familyFilter['rejection_reason_counts'],SORT_STRING);$familyFilter['alias_groups_after_family_gate']=count($ranked);$familyFilter['all_deduped_groups_persisted']=true;
        usort($ranked,static function($a,$b){$score=(int)$b['rank_score']<=>(int)$a['rank_score'];return $score!==0?$score:strcmp((string)$a['canonical_key'],(string)$b['canonical_key']);});
        $snapshot=(array)($job['snapshot']??[]);$structure=(array)($snapshot['structure']['items']??[]);$inventory=array_merge((array)($snapshot['inventory']['items']??[]),PSTE_Repository::previousCandidateInventory((string)$job['job_uuid']),self::planItemsAsInventory((array)($snapshot['editorial_plan']['items']??[]),$structure));$candidates=[];
        foreach($ranked as $group)$candidates[]=self::candidateFromGroup($group,$job,$siteBaseline,$registry,$family,$familyKey,$researchContext,$inventory,$structure,$sourceDefinitions);
        self::applyInternalDuplicates($candidates);
        PSTE_Snapshot::assertUnchanged((array)$snapshot['inventory'],PSTE_Snapshot::inventory());PSTE_Snapshot::assertUnchanged((array)$snapshot['structure'],PSTE_Snapshot::structure());PSTE_Snapshot::assertUnchanged((array)$snapshot['editorial_plan'],PSTE_Snapshot::editorialPlan());
        PSTE_Work_Queue::attachAll($candidates,(string)$job['job_uuid']);
        $decisions=array_column($candidates,'decision');$usable=count(array_filter($candidates,static fn($c)=>($c['decision']??'')==='PASS'));$now=gmdate('Y-m-d H:i:s');
        $run=['run_uuid'=>(string)$job['job_uuid'],'status'=>self::aggregateRunStatus($decisions),'category_id'=>(int)$job['category_id'],'seed'=>(string)$job['seed'],'estimated_cost'=>(float)$job['estimated_cost'],'actual_cost'=>(float)$job['actual_cost'],'snapshot'=>$snapshot,
            'payload'=>['location'=>(string)$job['location'],'language'=>(string)$job['language'],'environment'=>(string)$job['environment'],'workflow'=>'LONGTAIL_RESEARCH_TO_METADATA_V2','execution_mode'=>'ONE_CLICK_AUTOMATIC_BROWSER_SEQUENCE','provider_calls'=>3,'provider_steps_completed'=>3,'google_live_serp_used'=>false,'completed_automatically'=>true,'manual_followup_steps_required'=>0,
                'research_limits'=>['depth_limit'=>2,'branch_limit'=>20,'provider_item_limit'=>100,'candidate_limit'=>'NO_DROP_ALL_DEDUPED_GROUPS_PERSISTED','cycle_protection'=>'EXACT_AND_SEMANTIC_ALIAS_HASH_DEDUPLICATION','repeat_paid_measurement'=>'FORBIDDEN_WITHIN_JOB'],
                'research_context'=>$researchContext,'selected_category'=>$selected,'article_type_registry_sha256'=>$registry['registry_sha256'],'family_identity_v2_registry_sha256'=>(string)($registry['family_identity_v2_registry_sha256']??''),'family_filter_diagnostics'=>$familyFilter,'candidate_summary'=>array_count_values($decisions),'candidate_count'=>count($candidates),'usable_candidate_count'=>$usable,'textmachine_write_attempted'=>false],
            'created_at'=>self::mysqlDate((string)($job['run_created_at']??'')),'updated_at'=>$now];
        PSTE_Repository::saveRun($run);$poolKeys=[];$sandboxAdmissions=0;$structureGapAdmissions=0;$internalClarificationAdmissions=0;$sandboxCandidateFailures=0;$sandboxCandidateFailureCodes=[];$admissionItems=[];
        foreach($candidates as $candidate){
            PSTE_Repository::saveCandidate((string)$job['job_uuid'],$candidate);$poolKey=PSTE_Repository::globalTopicKeyForCandidate($candidate);$poolKeys[]=$poolKey;
            $path=(array)($candidate['normal_metadata_path']??[]);$diag=['reason_codes'=>(array)($candidate['reason_codes']??[]),'research_origin_family_key'=>(string)($candidate['research_origin_family_key']??''),'research_origin_family_name'=>(string)($candidate['research_origin_family_name']??''),'family_membership'=>(array)($candidate['family_membership_v2']??[])];
            $admissionItems[]=['pool_key'=>$poolKey,'normal_path'=>$path,'diagnostics'=>$diag];
        }
        foreach(array_chunk($admissionItems,12) as $chunk){$batch=PSTE_Semantic_Review_Sandbox::admitFromResearchFinalizeBatch($chunk,(string)$job['job_uuid']);if(($batch['contract']??'')!=='PSTE_SANDBOX_RESEARCH_ADMISSION_BATCH_V1'||(int)($batch['processed']??-1)!==count($chunk))throw new RuntimeException('PSTE_SANDBOX_RESEARCH_BATCH_INVALID');foreach((array)($batch['results']??[]) as $offset=>$admission){$item=(array)($chunk[$offset]??[]);$path=(array)($item['normal_path']??[]);$pathStatus=(string)($path['status']??'');$mode=(string)($path['sandbox_admission_mode']??'');if(!empty($admission['admitted']))$sandboxAdmissions++;if($pathStatus==='STRUCTURE_GAP'&&!empty($admission['admitted']))$structureGapAdmissions++;if($pathStatus==='SANDBOX_REQUIRED'&&$mode==='INTERNAL_CLARIFICATION'&&!empty($admission['admitted']))$internalClarificationAdmissions++;if(!empty($admission['isolated_candidate_failure'])){$sandboxCandidateFailures++;$sandboxCandidateFailureCodes[]=(string)($admission['error_code']??'PSTE_SANDBOX_CANDIDATE_FAILURE');}}}
        $run['payload']['sandbox_admissions']=$sandboxAdmissions;$run['payload']['structure_gap_backlog_admissions']=$structureGapAdmissions;$run['payload']['internal_clarification_admissions']=$internalClarificationAdmissions;$run['payload']['sandbox_candidate_failures_isolated']=$sandboxCandidateFailures;$run['payload']['sandbox_candidate_failure_codes']=array_values(array_unique(array_filter(array_map('strval',$sandboxCandidateFailureCodes))));$run['payload']['raw_keyword_preservation']='ALL_DEDUPED_GROUPS_PERSISTED';PSTE_Repository::saveRun($run);if($poolKeys)PSTE_Repository::refreshPortalContextForKeys(array_values(array_unique($poolKeys)),(array)$snapshot['inventory'],(array)$snapshot['editorial_plan'],(string)($siteBaseline['structure_sha256']??''));return $run;
    }

    /** @return array<string,mixed> */
    private static function candidateFromGroup(array $group,array $job,array $baseline,array $registry,string $family,string $familyKey,array $researchContext,array $inventory,array $structure,array $sourceDefinitions): array {
        $record=(array)$group['canonical_record'];$query=(string)$record['language_corrected_query'];$intent=(array)$group['intent'];$evidence=[];
        foreach((array)$group['all_records'] as $aliasRecord){
            $observations=(array)($aliasRecord['observations']??[]);
            if($observations){foreach($observations as $obs){if(!is_array($obs))continue;$source=(string)($obs['source_class']??'');$evidence[]=['source'=>$source,'source_reference'=>$source==='GSC'?'Search Console read-only import':($sourceDefinitions[$source]??'DataForSEO Labs'),'observation_id'=>(string)($obs['observation_id']??''),'root_query'=>(string)($obs['root_query']??''),'parent_observation_id'=>(string)($obs['parent_observation_id']??''),'depth'=>(int)($obs['depth']??0),'query_kind'=>(string)($obs['query_kind']??''),'captured_at_utc'=>(string)($obs['retrieved_at_utc']??$aliasRecord['captured_at_utc']??''),'location'=>(string)($obs['locale']??$job['location']),'language'=>(string)($obs['language']??$job['language']),'raw_value'=>(string)($obs['raw_value']??$aliasRecord['raw_query']??''),'raw_response_sha256'=>(string)($obs['raw_response_sha256']??''),'freshness_status'=>(string)($obs['freshness_status']??'CURRENT')];}}
            else foreach((array)$aliasRecord['source_names'] as $source)$evidence[]=['source'=>$source,'source_reference'=>$source==='GSC'?'Search Console read-only import':($sourceDefinitions[$source]??'DataForSEO Labs'),'captured_at_utc'=>(string)$aliasRecord['captured_at_utc'],'location'=>(string)$job['location'],'language'=>(string)$job['language'],'raw_value'=>(string)$aliasRecord['raw_query'],'raw_response_sha256'=>(string)($aliasRecord['source_hashes'][$source]??'')];
        }
        $candidate=self::makeCandidate($query,['category_id'=>0,'category_slug'=>'','category_name'=>'','topic_family_name'=>$family,'topic_family_key'=>$familyKey,'article_type'=>'','answer_promise'=>$query,'evidence'=>$evidence,'research_context'=>$researchContext,'metrics'=>['search_volume'=>$record['search_volume'],'volume_status'=>$record['volume_status'],'measured_query'=>$record['measured_query'],'monthly_searches'=>$record['monthly_searches'],'trend'=>null,'search_intent'=>$intent['search_intent']??null,'intent_probability'=>$intent['intent_probability']??null]]);
        $candidate['query_record']=$record;$candidate['query_aliases']=array_values((array)$group['aliases']);$candidate['canonical_query']=$query;
        $candidate['research_origin_family_key']=$familyKey;$candidate['research_origin_family_name']=$family;$candidate['research_origin_category_id']=(int)$job['category_id'];$candidate['research_origin_family_status']=(string)($group['research_origin_family_status']??'');
        $candidate['family_membership_v2']=(array)($group['family_membership_v2']??[]);
        $candidate['article_type_registry_sha256']=(string)$registry['registry_sha256'];$candidate['research_job_contract']=PSTE_Research_Job::CONTRACT;$candidate['research_run_status']='COMPLETE';$candidate['research_rank_score']=(int)$group['rank_score'];
        $candidate['freshness']=is_array($record['freshness']??null)?$record['freshness']:['status'=>'CURRENT','retrieved_at'=>(string)$record['captured_at_utc'],'revalidation_class'=>'REGULARLY_CHANGING','valid_until'=>gmdate('c',(strtotime((string)$record['captured_at_utc'])?:time())+90*86400)];
        $candidate=PSTE_Normal_Metadata_Path::applyToPayload($candidate,$baseline,$familyKey);
        $path=(array)($candidate['normal_metadata_path']??[]);$pathStatus=(string)($path['status']??'REVIEW_REQUIRED');$resolvedFamilyKey=(string)($path['family_key']??'');
        $reasons=(array)($candidate['reason_codes']??[]);$decision=$pathStatus==='NORMAL_PASS'?'PASS':'BLOCKED';
        $pre=['contract'=>'PSTE_PRE_TITLE_DUPLICATE_GATE_V1','ok'=>true,'reason_codes'=>[],'matches'=>[],'write_attempted'=>false];
        if($resolvedFamilyKey!==''){$pre=self::preTitleDuplicate($query,$resolvedFamilyKey,$inventory);if(!$pre['ok']){$decision='BLOCKED';$reasons=array_merge($reasons,$pre['reason_codes']);}}
        $candidate['pre_title_duplicate_gate']=$pre;
        $semantic=(array)($candidate['semantic_consensus']??[]);$candidate['type_fit_evidence']=PSTE_Type_Fit_Probe::evaluate($semantic,(array)$group['all_records'],$registry);
        if(($candidate['type_fit_evidence']['status']??'')==='TYPE_EVIDENCE_CONFLICT_REVIEW'){$decision='BLOCKED';$reasons=array_merge($reasons,(array)$candidate['type_fit_evidence']['reason_codes']);}
        if(!empty($group['measurement_inconsistent'])){$decision='BLOCKED';$reasons[]='API_DATA_INCONSISTENT';}
        if($decision==='PASS'){$post=PSTE_Cannibalization::decide($candidate,$inventory,$structure,[]);$decision=$post['decision'];$reasons=array_merge($reasons,$post['reason_codes']);$candidate['closest_existing_matches']=$post['matches'];}
        if($pathStatus==='STRUCTURE_GAP'&&$resolvedFamilyKey!==''){$candidate['category_gap_proposal']=PSTE_Category_Gap::proposal((string)$path['family_name'],$resolvedFamilyKey,(string)$path['article_type'],$semantic,$evidence,(string)($baseline['structure_sha256']??''),$registry);}
        $candidate['decision']=$decision;$candidate['reason_codes']=array_values(array_unique(array_filter(array_map('strval',$reasons))));$candidate['human_review_required']=$decision!=='PASS';$candidate['discovery_only']=$decision!=='PASS';if($decision!=='PASS')$candidate['candidate_role']='DISCOVERY_PROBE';
        $candidate['sandbox_required']=$pathStatus==='SANDBOX_REQUIRED';$candidate['structure_gap_backlog_required']=$pathStatus==='STRUCTURE_GAP';$candidate['sandbox_admission_mode']=(string)($path['sandbox_admission_mode']??'');
        return $candidate;
    }

    /** @return array<string,mixed> */
    private static function preTitleDuplicate(string $query,string $familyKey,array $inventory): array {$reasons=[];$matches=[];foreach($inventory as $item){if(!in_array((string)($item['status']??''),['publish','draft'],true))continue;$title=trim((string)($item['title']??''));if($title==='')continue;$itemFamily=(string)($item['topic_family_key']??'');$exact=PSTE_Normalizer::exactTopicIdentityText($query)===PSTE_Normalizer::exactTopicIdentityText($title);$equiv=PSTE_Normalizer::answerEquivalent($query,$title,'',(string)($item['topic_family_name']??''));if($exact||($equiv&&$familyKey!==''&&$itemFamily!==''&&hash_equals($familyKey,$itemFamily))){$reasons[]=$exact?'PRE_TITLE_EXACT_DUPLICATE':'PRE_TITLE_ANSWER_EQUIVALENT';$matches[]=['post_id'=>(int)($item['post_id']??0),'title'=>$title,'source'=>(string)($item['source']??'WORDPRESS_READ_ONLY')];}}
        return ['contract'=>'PSTE_PRE_TITLE_DUPLICATE_GATE_V1','ok'=>!$reasons,'reason_codes'=>array_values(array_unique($reasons)),'matches'=>array_slice($matches,0,8),'write_attempted'=>false];}
    private static function assertStoredSource(string $source,array $stored): void {$hash=(string)($stored['response_sha256']??'');if(!is_array($stored['items']??null)||!preg_match('/^[a-f0-9]{64}$/',$hash))throw new RuntimeException('PSTE_RESEARCH_SOURCE_INVALID_'.$source);}
    /** @param array<string,mixed> $exact */
    private static function appendExact(array &$exact,string $raw,$volume,array $monthly,string $source,string $hash,string $captured,?array $firstParty,array $observation=[]): void {
        if(PSTE_Normalizer::exactTopicIdentityText($raw)==='')return;
        // The raw byte string is the first identity boundary. Case, punctuation and
        // spelling variants must survive separately until alias clustering.
        $key=hash('sha256',$raw);$volume=is_numeric($volume)?(int)$volume:null;
        if(!isset($exact[$key]))$exact[$key]=['raw'=>$raw,'volumes'=>[],'monthly'=>[],'sources'=>[],'hashes'=>[],'first_party'=>null,'observations'=>[]];
        $exact[$key]['sources'][$source]=true;$exact[$key]['hashes'][$source]=$hash;
        if($volume!==null)$exact[$key]['volumes'][$source]=$volume;if($monthly)$exact[$key]['monthly']=$monthly;
        if($firstParty)$exact[$key]['first_party']=$firstParty;if($observation)$exact[$key]['observations'][]=$observation;$previous=(string)($exact[$key]['captured']??'');if($previous===''||(strtotime($captured)?:0)>(strtotime($previous)?:0))$exact[$key]['captured']=$captured;
    }
    /** @return array<string,mixed> */
    private static function aliasGroups(array $exact): array {
        $groups=[];
        foreach($exact as $row){
            $values=array_values(array_unique(array_map('intval',(array)$row['volumes'])));
            $inconsistent=count($values)>1;$volume=$inconsistent?null:($values[0]??null);
            $record=PSTE_Query_Record::make((string)$row['raw'],$volume,(array)$row['monthly'],array_keys((array)$row['sources']),(array)$row['hashes'],(string)$row['captured'],(array)($row['observations']??[]));
            if($inconsistent){$record['volume_status']='UNAVAILABLE';$record['measured_query']='';$record['search_volume']=null;}
            $aliasKey=PSTE_Query_Record::aliasKey($record);if($aliasKey==='')continue;
            $groups[$aliasKey]['canonical_key']=$aliasKey;$groups[$aliasKey]['all_records'][]=$record;
            $groups[$aliasKey]['measurement_inconsistent']=!empty($groups[$aliasKey]['measurement_inconsistent'])||$inconsistent;
            if($row['first_party'])$groups[$aliasKey]['first_party']=$row['first_party'];
        }
        foreach($groups as &$group){
            usort($group['all_records'],static function($a,$b){
                $ac=(int)((string)$a['raw_query']===(string)$a['language_corrected_query']);$bc=(int)((string)$b['raw_query']===(string)$b['language_corrected_query']);
                return [$bc,count((array)$b['source_names']),(int)($b['search_volume']??-1)]<=>[$ac,count((array)$a['source_names']),(int)($a['search_volume']??-1)];
            });
            $group['canonical_record']=$group['all_records'][0];$canonicalExact=PSTE_Query_Record::canonicalKey($group['canonical_record']);
            $group['aliases']=[];
            foreach($group['all_records'] as $r){
                $relation=(string)$r['relation_to_canonical'];
                if(PSTE_Query_Record::canonicalKey($r)!==$canonicalExact)$relation='SYNONYM';
                $group['aliases'][]=['raw_query'=>$r['raw_query'],'normalized_query'=>$r['normalized_query'],'language_corrected_query'=>$r['language_corrected_query'],'relation_to_canonical'=>$relation,'source_names'=>$r['source_names'],'volume_status'=>$r['volume_status'],'search_volume'=>$r['search_volume'],'observation_ids'=>array_values(array_filter(array_map(static fn($o)=>is_array($o)?(string)($o['observation_id']??''):'',(array)($r['observations']??[]))))];
            }
        }
        unset($group);return $groups;
    }
    private static function rankScore(array $record,array $aliases,?array $firstParty): int {$score=(int)($record['search_volume']??0);$sources=[];foreach($aliases as $a)foreach((array)($a['source_names']??[]) as $s)$sources[$s]=true;$score+=count($sources)*5000;$score+=(int)($firstParty['impressions']??0);if(PSTE_Normalizer::isQuestion((string)$record['language_corrected_query']) )$score+=2000;return $score;}
    public static function syncSearchConsole(string $siteUrl,string $startDate,string $endDate): array {$rows=[];$sourceCount=0;$responseHashes=[];for($pageIndex=0;$pageIndex<4;$pageIndex++){$response=PSTE_GSC_Client::queryAnalytics($siteUrl,$startDate,$endDate,$pageIndex*25000,25000);$batch=$response['rows']??[];$sourceCount+=count($batch);$responseHashes[]=hash('sha256',self::json($response));foreach($batch as $row){$keys=$row['keys']??[];$query=trim((string)($keys[0]??''));$page=trim((string)($keys[1]??''));if($query===''||$page===''||PSTE_First_Party_Import::containsPii($query))continue;[$postId,$categoryId]=self::resolvePageCategory($page);$rows[]=['query'=>$query,'page'=>$page,'post_id'=>$postId,'category_id'=>$categoryId,'clicks'=>(float)($row['clicks']??0),'impressions'=>(float)($row['impressions']??0),'ctr'=>(float)($row['ctr']??0),'position'=>(float)($row['position']??0)];}if(count($batch)<25000)break;}$saved=PSTE_Repository::replaceGscRows($siteUrl,$startDate,$endDate,$rows);$saved['source_row_count']=$sourceCount;$saved['accepted_row_count']=count($rows);$saved['response_bundle_sha256']=hash('sha256',implode('|',$responseHashes));$saved['pagination_limit_rows']=100000;update_option(PSTE_OPTION_GSC_LAST_SYNC,$saved,false);return $saved;}
    private static function resolvePageCategory(string $pageUrl): array {$postId=function_exists('url_to_postid')?(int)url_to_postid($pageUrl):0;if($postId>0){$cats=wp_get_post_categories($postId,['fields'=>'ids']);return[$postId,is_array($cats)&&$cats?(int)reset($cats):0];}$terms=get_categories(['hide_empty'=>false]);foreach($terms as $term){$link=get_category_link((int)$term->term_id);if(!is_wp_error($link)&&untrailingslashit((string)$link)===untrailingslashit($pageUrl))return[0,(int)$term->term_id];}return[0,0];}
    private static function applyInternalDuplicates(array &$candidates): void {
        $order=array_keys($candidates);
        usort($order,static function(int $a,int $b)use($candidates):int{
            $pa=self::duplicatePriority((array)$candidates[$a]);$pb=self::duplicatePriority((array)$candidates[$b]);
            for($i=0;$i<3;$i++){if($pa[$i]!==$pb[$i])return $pb[$i]<=>$pa[$i];}
            return strcmp((string)($candidates[$a]['candidate_id']??''),(string)($candidates[$b]['candidate_id']??''));
        });
        $accepted=[];
        foreach($order as $index){
            if(($candidates[$index]['decision']??'')!=='PASS')continue;
            $duplicateOf=null;
            foreach($accepted as $owner){if(self::sameAnswerIntent((array)$candidates[$index],(array)$candidates[$owner])){$duplicateOf=$owner;break;}}
            if($duplicateOf===null){$accepted[]=$index;continue;}
            $crossType=PSTE_Article_Type_Registry::canonicalType((string)($candidates[$index]['proposed_article_type']??''))!==PSTE_Article_Type_Registry::canonicalType((string)($candidates[$duplicateOf]['proposed_article_type']??''));
            $candidates[$index]['decision']='BLOCKED';$candidates[$index]['discovery_only']=true;$candidates[$index]['candidate_role']='DISCOVERY_PROBE';$candidates[$index]['human_review_required']=true;
            $codes=['DUPLICATE_WITHIN_RESEARCH_RUN'];if($crossType)$codes[]='CROSS_TYPE_ANSWER_EQUIVALENCE';
            $candidates[$index]['reason_codes']=array_values(array_unique(array_merge((array)($candidates[$index]['reason_codes']??[]),$codes)));
            $candidates[$index]['duplicate_of_candidate_id']=(string)($candidates[$duplicateOf]['candidate_id']??'');
            $candidates[$index]['duplicate_of_title']=PSTE_Editorializer::displayTitle((array)$candidates[$duplicateOf]);
        }
    }
    /** @return array{0:int,1:int,2:int} */
    private static function duplicatePriority(array $candidate): array {
        $sources=[];foreach((array)($candidate['evidence']??[]) as $e)if(is_array($e)&&trim((string)($e['source']??''))!=='')$sources[(string)$e['source']]=true;
        return [(int)($candidate['research_rank_score']??0),(int)($candidate['metrics']['search_volume']??-1),count($sources)];
    }
    private static function sameAnswerIntent(array $a,array $b): bool {
        $familyA=(string)($a['topic_family_key']??'');$familyB=(string)($b['topic_family_key']??'');if($familyA===''||$familyB===''||!hash_equals($familyA,$familyB))return false;
        $clusterA=(string)($a['intent_cluster_id']??'');$clusterB=(string)($b['intent_cluster_id']??'');if($clusterA!==''&&$clusterB!==''&&hash_equals($clusterA,$clusterB))return true;
        $queryA=(string)($a['primary_longtail_query']??$a['canonical_query']??'');$queryB=(string)($b['primary_longtail_query']??$b['canonical_query']??'');
        $categoryA=(string)($a['target_category_name']??'');$categoryB=(string)($b['target_category_name']??'');
        if(PSTE_Normalizer::answerEquivalent($queryA,$queryB,$categoryA,$categoryB))return true;
        return PSTE_Normalizer::answerEquivalent(PSTE_Editorializer::displayTitle($a),PSTE_Editorializer::displayTitle($b),$categoryA,$categoryB);
    }
    private static function planItemsAsInventory(array $items,array $structure): array {$byId=[];$bySlug=[];foreach($structure as $row){if(!is_array($row))continue;$id=(int)($row['term_id']??0);$slug=trim((string)($row['slug']??''));if($id>0)$byId[$id]=$row;if($slug!=='')$bySlug[$slug]=$row;}$out=[];foreach($items as $item){$title=(string)($item['title']??$item['primary_longtail_query']??'');if($title==='')continue;$category=(string)($item['category_name']??'');$id=(int)($item['category_id']??0);$slug=trim((string)($item['category_slug']??''));$matched=$id>0&&isset($byId[$id])?$byId[$id]:($slug!==''&&isset($bySlug[$slug])?$bySlug[$slug]:[]);$key=(string)($matched['topic_family_key']??$item['topic_family_key']??PSTE_Normalizer::categoryFamilyKey($category));$out[]=['post_id'=>0,'title'=>$title,'status'=>'draft','category_name'=>$category,'topic_family_name'=>(string)($matched['topic_family_name']??PSTE_Normalizer::categoryFamilyName($category)),'topic_family_key'=>$key,'headings'=>is_array($item['headings']??null)?$item['headings']:[],'intent_cluster_id'=>(string)($item['intent_cluster_id']??''),'source'=>'EDITORIAL_PLAN_READ_ONLY'];}return $out;}
    private static function mysqlDate(string $value): string {$ts=strtotime($value);return gmdate('Y-m-d H:i:s',$ts===false?time():$ts);}
    private static function json($value): string {$json=function_exists('wp_json_encode')?wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return is_string($json)?$json:'';}
    public static function responseCost(array $response): float {return PSTE_DataForSEO_Client::cacheHit($response)?0.0:(float)(PSTE_DataForSEO_Client::externalResponse($response)['cost']??0.0);}
}
