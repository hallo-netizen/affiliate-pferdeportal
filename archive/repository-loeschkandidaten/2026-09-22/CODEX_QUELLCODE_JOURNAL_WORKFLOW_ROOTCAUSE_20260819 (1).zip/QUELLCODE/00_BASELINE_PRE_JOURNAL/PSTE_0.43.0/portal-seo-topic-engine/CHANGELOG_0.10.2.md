# 0.10.2-staging

- Behebt einen realen PHP-Parsefehler im neuen Query-Record-Modul; der vorherige lokale Prüfnachweis war dadurch ungültig.
- Korrigiert die kanonische Artikeltyp-ID: Beitragstypen werden jetzt ohne sprachliches Stemming stabil aus der realen Taxonomie gelesen. Dadurch funktionieren bestehende und später ergänzte Typen zuverlässig.
- Bewahrt jede vom Provider gelieferte Rohform bis zur nachgelagerten Aliasbildung; Groß-/Kleinschreibung, Interpunktion und Schreibvarianten werden nicht vorzeitig vernichtet.
- Schließt Kannibalisierung innerhalb desselben Recherchelaufs auch über unterschiedliche Beitragstypen hinweg. Eine Frage und ein Ratgebertitel mit demselben Antwortversprechen erzeugen nicht mehr zwei konkurrierende Artikel.
- Synchronisiert den praktischen Workflowvertrag mit den tatsächlich drei automatisch ausgeführten Longtail-Quellen.
- Keine Änderung an Textmaschine, Artikelinhalt, HTML, Design, Formatierung oder Qualitätslogik.
