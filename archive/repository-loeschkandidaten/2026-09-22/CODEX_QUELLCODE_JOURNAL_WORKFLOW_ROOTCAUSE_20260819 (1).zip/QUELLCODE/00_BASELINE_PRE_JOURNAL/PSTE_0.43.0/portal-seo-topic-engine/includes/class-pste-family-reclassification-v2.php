<?php
if (!defined('ABSPATH')) { return; }

/**
 * Read-only inventory replay and tightly authorized V2 family reassignment.
 *
 * Absolute boundary: this class may read WordPress posts/terms/meta, but may
 * write only PSTE topic tables plus PSTE-owned audit options. It never invokes
 * post, term, meta, editor, PPM, compiler, HTML, CSS or design write APIs.
 */
final class PSTE_Family_Reclassification_V2 {
    public const SNAPSHOT_CONTRACT='PSTE_FAMILY_V2_FRESH_SNAPSHOT_V1';
    public const DRY_RUN_CONTRACT='PSTE_FAMILY_V2_DRY_RUN_V1';
    public const AUTH_CONTRACT='PSTE_FAMILY_V2_APPLY_AUTHORIZATION_V1';
    public const APPLY_CONTRACT='PSTE_FAMILY_V2_APPLY_REPORT_V1';
    public const ROLLBACK_CONTRACT='PSTE_FAMILY_V2_ROLLBACK_REPORT_V1';

    private const TABLES=['runs','candidates','evidence','cost_ledger','gsc_queries','topic_pool','topic_history','topic_occurrences','topic_assignments','topic_identity','topic_merge_candidates'];
    private const APPLY_ELIGIBLE=['MOVE_UNAMBIGUOUS','NEWLY_ELIGIBLE'];

    /** Create one internally consistent, fresh, read-only source snapshot. */
    public static function freshSnapshot(): array {
        PSTE_Plugin::assertReady();
        global $wpdb;
        $baseline=PSTE_Snapshot::siteBaseline();
        $inventory=PSTE_Snapshot::inventory();
        if(!hash_equals((string)($baseline['inventory_sha256']??''),(string)($inventory['sha256']??'')))throw new RuntimeException('PSTE_FAMILY_V2_INVENTORY_CHANGED_DURING_SNAPSHOT');
        $tables=[];
        foreach(self::TABLES as $name){
            $table=PSTE_Repository::table($name);
            $order=$name==='topic_identity'?'normalized_key ASC':'id ASC';
            $rows=$wpdb->get_results("SELECT * FROM $table ORDER BY $order",ARRAY_A);
            if($rows===null&&trim((string)$wpdb->last_error)!=='')throw new RuntimeException('PSTE_FAMILY_V2_SNAPSHOT_READ_FAILED_'.strtoupper($name));
            $rows=array_values(array_map([self::class,'stringifyRow'],(array)$rows));
            $tables[$name]=['count'=>count($rows),'rows_sha256'=>self::hash($rows),'rows'=>$rows];
        }
        $articles=self::articleGuardSnapshot();
        $snapshot=[
            'contract'=>self::SNAPSHOT_CONTRACT,
            'captured_at_utc'=>gmdate('c'),
            'plugin_version'=>PSTE_VERSION,
            'baseline'=>$baseline,
            'baseline_sha256'=>(string)($baseline['baseline_sha256']??self::hash($baseline)),
            'inventory'=>$inventory,
            'tables'=>$tables,
            'article_guard'=>$articles,
            'write_attempted'=>false,
        ];
        $snapshot['source_snapshot_sha256']=self::hash(['baseline_identity'=>self::baselineIdentity($baseline),'inventory_sha256'=>(string)($inventory['sha256']??''),'table_hashes'=>array_map(static fn($v)=>(string)$v['rows_sha256'],$tables),'table_counts'=>array_map(static fn($v)=>(int)$v['count'],$tables),'article_guard_sha256'=>(string)$articles['sha256']]);
        return $snapshot;
    }

    /** Execute and persist a complete source-data-read-only replay of all stored longtails. */
    public static function runDryRun(): array {
        $priorApply=self::storedApply();$priorRollback=self::storedRollback();
        if(($priorApply['contract']??'')===self::APPLY_CONTRACT&&($priorApply['status']??'')==='PASS'&&($priorRollback['status']??'')!=='PASS')throw new RuntimeException('PSTE_FAMILY_V2_ROLLBACK_REQUIRED_BEFORE_NEW_DRY_RUN');
        if(($priorApply['status']??'')==='ROLLED_BACK'||($priorRollback['status']??'')==='PASS'){
            delete_option(PSTE_OPTION_FAMILY_V2_APPLY);delete_option(PSTE_OPTION_FAMILY_V2_ROLLBACK);delete_option(PSTE_OPTION_FAMILY_V2_AUTHORIZATION);
        }
        $snapshot=self::freshSnapshot();
        $registry=PSTE_Article_Type_Registry::build((array)$snapshot['baseline']);
        $report=self::simulateSnapshot($snapshot,$registry);
        update_option(PSTE_OPTION_FAMILY_V2_DRY_RUN,$report,false);
        $stored=get_option(PSTE_OPTION_FAMILY_V2_DRY_RUN,[]);
        if(!is_array($stored)||!hash_equals((string)$report['dry_run_sha256'],(string)($stored['dry_run_sha256']??'')))throw new RuntimeException('PSTE_FAMILY_V2_DRY_RUN_READBACK_FAILED');
        delete_option(PSTE_OPTION_FAMILY_V2_AUTHORIZATION);
        return $report;
    }

    /** Pure replay helper used by local fixtures and by the live dry-run. */
    public static function simulateSnapshot(array $snapshot,array $registry): array {
        if(($snapshot['contract']??'')!==self::SNAPSHOT_CONTRACT)throw new RuntimeException('PSTE_FAMILY_V2_SNAPSHOT_CONTRACT_INVALID');
        $poolRows=(array)($snapshot['tables']['topic_pool']['rows']??[]);
        $candidateRows=(array)($snapshot['tables']['candidates']['rows']??[]);
        $occurrenceRows=(array)($snapshot['tables']['topic_occurrences']['rows']??[]);
        $assignmentRows=(array)($snapshot['tables']['topic_assignments']['rows']??[]);
        $historyRows=(array)($snapshot['tables']['topic_history']['rows']??[]);
        $identityRows=(array)($snapshot['tables']['topic_identity']['rows']??[]);
        $mergeRows=(array)($snapshot['tables']['topic_merge_candidates']['rows']??[]);
        $candidateIndex=self::indexRows($candidateRows,'candidate_id');
        $occurrenceIndex=self::indexRows($occurrenceRows,'topic_key');
        $assignmentIndex=self::indexRows($assignmentRows,'topic_key');
        $historyIndex=self::indexRows($historyRows,'pool_key');
        $identityIndex=self::indexRows($identityRows,'topic_uuid');
        $mergeIndex=self::mergeIndex($mergeRows);
        $coverage=self::coverageAudit($poolRows,$candidateRows,$occurrenceRows,$assignmentRows,$historyRows,$identityRows,$mergeRows,$registry);
        $collisions=self::identityCollisions($registry);
        $collisionKeys=[];foreach($collisions as $collision)foreach((array)$collision['family_keys'] as $key)$collisionKeys[(string)$key]=true;
        $items=[];$counts=[];$eligible=[];
        foreach($poolRows as $row){
            $item=self::simulatePoolRow($row,$registry,$collisionKeys,(array)($snapshot['inventory']['items']??[]),(array)($snapshot['baseline']['leaf_categories']??[]));
            $poolKey=(string)($row['pool_key']??'');$candidateId=(string)($row['candidate_id']??'');
            $item['related_rows']=[
                'candidate_ids'=>array_values(array_map(static fn($r)=>(int)($r['id']??0),(array)($candidateIndex[$candidateId]??[]))),
                'occurrence_ids'=>array_values(array_map(static fn($r)=>(int)($r['id']??0),(array)($occurrenceIndex[$poolKey]??[]))),
                'assignment_ids'=>array_values(array_map(static fn($r)=>(int)($r['id']??0),(array)($assignmentIndex[$poolKey]??[]))),
                'history_ids'=>array_values(array_map(static fn($r)=>(int)($r['id']??0),(array)($historyIndex[$poolKey]??[]))),
                'identity_rows'=>count((array)($identityIndex[$poolKey]??[])),
                'merge_rows'=>count((array)($mergeIndex[$poolKey]??[])),
            ];
            $items[]=$item;$classification=(string)$item['classification'];$counts[$classification]=($counts[$classification]??0)+1;
            if(!empty($item['eligible_for_apply']))$eligible[]=(string)$item['change_id'];
        }
        ksort($counts,SORT_STRING);sort($eligible,SORT_STRING);
        if(($coverage['status']??'')!=='PASS')$eligible=[];
        $report=[
            'contract'=>self::DRY_RUN_CONTRACT,
            'created_at_utc'=>gmdate('c'),
            'plugin_version'=>PSTE_VERSION,
            'source_snapshot_sha256'=>(string)$snapshot['source_snapshot_sha256'],
            'source_table_hashes'=>array_map(static fn($v)=>(string)($v['rows_sha256']??''),(array)$snapshot['tables']),
            'source_table_counts'=>array_map(static fn($v)=>(int)($v['count']??0),(array)$snapshot['tables']),
            'article_guard_sha256'=>(string)($snapshot['article_guard']['sha256']??''),
            'article_guard_counts'=>(array)($snapshot['article_guard']['counts']??[]),
            'baseline_sha256'=>(string)$snapshot['baseline_sha256'],
            'registry_sha256'=>(string)($registry['registry_sha256']??''),
            'family_identity_v2_registry_sha256'=>self::familyRegistryHash($registry),
            'identity_v2_collisions'=>$collisions,
            'coverage_audit'=>$coverage,
            'classification_counts'=>$counts,
            'item_count'=>count($items),
            'eligible_change_ids'=>$eligible,
            'items'=>$items,
            'source_data_write_attempted'=>false,
            'audit_report_option_written'=>true,
            'write_attempted'=>false,
            'published_or_draft_article_write_attempted'=>false,
            'apply_status'=>'LOCKED_PENDING_CLAUDE_DRY_RUN_PASS_AND_USER_AUTHORIZATION',
        ];
        $report['dry_run_sha256']=self::hash(self::withoutKey($report,'dry_run_sha256'));
        return $report;
    }

    public static function storedDryRun(): array {$v=get_option(PSTE_OPTION_FAMILY_V2_DRY_RUN,[]);return is_array($v)?$v:[];}
    public static function storedAuthorization(): array {$v=get_option(PSTE_OPTION_FAMILY_V2_AUTHORIZATION,[]);return is_array($v)?$v:[];}
    public static function storedApply(): array {$v=get_option(PSTE_OPTION_FAMILY_V2_APPLY,[]);return is_array($v)?$v:[];}
    public static function storedRollback(): array {$v=get_option(PSTE_OPTION_FAMILY_V2_ROLLBACK,[]);return is_array($v)?$v:[];}

    /** Import Claude/user authorization. Importing never applies changes. */
    public static function importAuthorization(array $authorization): array {
        self::assertAuthorizationShape($authorization);self::assertAuthorizationIntegrity($authorization);
        $dry=self::storedDryRun();if(!$dry)throw new RuntimeException('PSTE_FAMILY_V2_DRY_RUN_REQUIRED');self::assertDryRunIntegrity($dry);
        foreach(['dry_run_sha256','source_snapshot_sha256','registry_sha256','family_identity_v2_registry_sha256'] as $field){
            if(!hash_equals((string)($dry[$field]??''),(string)($authorization[$field]??'')))throw new RuntimeException('PSTE_FAMILY_V2_AUTHORIZATION_BINDING_MISMATCH_'.strtoupper($field));
        }
        $eligible=array_fill_keys(array_map('strval',(array)($dry['eligible_change_ids']??[])),true);
        $approved=array_values(array_unique(array_filter(array_map('strval',(array)($authorization['approved_change_ids']??[])))));
        foreach($approved as $id)if(!isset($eligible[$id]))throw new RuntimeException('PSTE_FAMILY_V2_AUTHORIZATION_CHANGE_NOT_ELIGIBLE');
        sort($approved,SORT_STRING);$authorization['approved_change_ids']=$approved;$authorization['imported_at_utc']=gmdate('c');
        $authorization['authorization_sha256']=self::hash(self::withoutKey($authorization,'authorization_sha256'));
        update_option(PSTE_OPTION_FAMILY_V2_AUTHORIZATION,$authorization,false);
        $stored=self::storedAuthorization();if(!hash_equals((string)$authorization['authorization_sha256'],(string)($stored['authorization_sha256']??'')))throw new RuntimeException('PSTE_FAMILY_V2_AUTHORIZATION_READBACK_FAILED');
        return $authorization;
    }

    /** Controlled apply; remains fail-closed until an exact authorization exists. */
    public static function apply(): array {
        $existing=self::storedApply();
        if(($existing['contract']??'')===self::APPLY_CONTRACT&&($existing['status']??'')==='PASS')return ['contract'=>self::APPLY_CONTRACT,'status'=>'IDEMPOTENT_NOOP','write_count'=>0,'apply_sha256'=>(string)($existing['apply_sha256']??''),'article_guard_sha256'=>(string)($existing['article_guard_after_sha256']??'')];
        $dry=self::storedDryRun();$auth=self::storedAuthorization();
        if(($dry['contract']??'')!==self::DRY_RUN_CONTRACT)throw new RuntimeException('PSTE_FAMILY_V2_DRY_RUN_REQUIRED');
        self::assertDryRunIntegrity($dry);self::assertAuthorizationShape($auth);self::assertAuthorizationIntegrity($auth);
        if(!hash_equals((string)$dry['dry_run_sha256'],(string)$auth['dry_run_sha256']))throw new RuntimeException('PSTE_FAMILY_V2_APPLY_DRY_RUN_HASH_MISMATCH');
        $fresh=self::freshSnapshot();
        self::assertSnapshotStillIdentical($dry,$fresh);
        $items=[];foreach((array)$dry['items'] as $item)$items[(string)($item['change_id']??'')]=$item;
        $approved=array_values(array_unique(array_map('strval',(array)$auth['approved_change_ids'])));
        if(!$approved)throw new RuntimeException('PSTE_FAMILY_V2_APPLY_NOTHING_APPROVED');
        global $wpdb;$beforeRows=[];$inserted=[];$writes=0;$articleBefore=(string)$fresh['article_guard']['sha256'];
        PSTE_Repository::beginOwnedTransaction('PSTE_FAMILY_V2_APPLY_TX_START');
        try{
            foreach($approved as $changeId){
                $item=$items[$changeId]??null;if(!is_array($item)||empty($item['eligible_for_apply'])||!in_array((string)($item['classification']??''),self::APPLY_ELIGIBLE,true))throw new RuntimeException('PSTE_FAMILY_V2_APPLY_CHANGE_INVALID');
                if((int)($item['target_category_id']??0)<=0||trim((string)($item['target_category_name']??''))===''||trim((string)($item['target_category_slug']??''))==='')throw new RuntimeException('PSTE_FAMILY_V2_APPLY_TARGET_CATEGORY_INVALID');
                $poolId=(int)$item['pool_id'];$pool=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.PSTE_Repository::table('topic_pool').' WHERE id=%d',$poolId),ARRAY_A);
                if(!is_array($pool)||!hash_equals((string)$item['before_row_sha256'],self::hash(self::stringifyRow($pool))))throw new RuntimeException('PSTE_FAMILY_V2_APPLY_ROW_DRIFT_'.$poolId);
                $payload=self::decodeObject((string)$pool['payload_json']);$queryBefore=self::rawQueryFingerprint($payload);
                $beforeRows[]=['table'=>'topic_pool','id'=>$poolId,'row'=>self::stringifyRow($pool)];
                $payload=self::applyFamilyPayload($payload,$item);
                if(!hash_equals($queryBefore,self::rawQueryFingerprint($payload)))throw new RuntimeException('PSTE_FAMILY_V2_RAW_QUERY_MUTATION_BLOCKED');
                $data=['payload_json'=>self::json($payload),'automatic_pool_status'=>'REVIEW_REQUIRED','context_state'=>'PENDING'];
                if((int)($item['target_category_id']??0)>0)$data['current_category_id']=(int)$item['target_category_id'];
                $formats=['%s','%s','%s'];if(array_key_exists('current_category_id',$data))$formats[]='%d';
                $writes+=PSTE_DB_Write_Guard::update(PSTE_Repository::table('topic_pool'),$data,['id'=>$poolId],$formats,['%d'],'PSTE_FAMILY_V2_APPLY_POOL_UPDATE');
                $poolReadback=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.PSTE_Repository::table('topic_pool').' WHERE id=%d',$poolId),ARRAY_A);if(!is_array($poolReadback))throw new RuntimeException('PSTE_FAMILY_V2_APPLY_POOL_READBACK_MISSING');$payloadReadback=self::decodeObject((string)$poolReadback['payload_json']);if(!hash_equals($queryBefore,self::rawQueryFingerprint($payloadReadback)))throw new RuntimeException('PSTE_FAMILY_V2_APPLY_POOL_QUERY_READBACK_MISMATCH');if(!hash_equals((string)$item['new_family_key'],(string)($payloadReadback['topic_family_key']??'')))throw new RuntimeException('PSTE_FAMILY_V2_APPLY_POOL_FAMILY_READBACK_MISMATCH');

                $candidateId=(string)($pool['candidate_id']??'');
                if($candidateId!==''){
                    $candidateRows=$wpdb->get_results($wpdb->prepare('SELECT * FROM '.PSTE_Repository::table('candidates').' WHERE candidate_id=%s ORDER BY id ASC',$candidateId),ARRAY_A)?:[];
                    foreach($candidateRows as $candidateRow){
                        $cp=self::decodeObject((string)$candidateRow['payload_json']);$qfp=self::rawQueryFingerprint($cp);$beforeRows[]=['table'=>'candidates','id'=>(int)$candidateRow['id'],'row'=>self::stringifyRow($candidateRow)];
                        $cp=self::applyFamilyPayload($cp,$item);if(!hash_equals($qfp,self::rawQueryFingerprint($cp)))throw new RuntimeException('PSTE_FAMILY_V2_CANDIDATE_QUERY_MUTATION_BLOCKED');
                        $writes+=PSTE_DB_Write_Guard::update(PSTE_Repository::table('candidates'),['payload_json'=>self::json($cp)],['id'=>(int)$candidateRow['id']],['%s'],['%d'],'PSTE_FAMILY_V2_APPLY_CANDIDATE_UPDATE');$candidateReadback=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.PSTE_Repository::table('candidates').' WHERE id=%d',(int)$candidateRow['id']),ARRAY_A);if(!is_array($candidateReadback))throw new RuntimeException('PSTE_FAMILY_V2_APPLY_CANDIDATE_READBACK_MISSING');$candidatePayloadReadback=self::decodeObject((string)$candidateReadback['payload_json']);if(!hash_equals($qfp,self::rawQueryFingerprint($candidatePayloadReadback)))throw new RuntimeException('PSTE_FAMILY_V2_APPLY_CANDIDATE_QUERY_READBACK_MISMATCH');
                    }
                }
                $targetCategory=(int)($item['target_category_id']??0);$articleType=(string)($item['article_type']??'');
                if($targetCategory>0){
                    $assignmentKey=hash('sha256',(string)$pool['pool_key'].'|'.$targetCategory.'|'.$articleType.'|FAMILY_IDENTITY_V2');
                    $existingAssignment=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.PSTE_Repository::table('topic_assignments').' WHERE assignment_key=%s',$assignmentKey),ARRAY_A);
                    if(!$existingAssignment){
                        $now=gmdate('Y-m-d H:i:s');$assignmentPayload=['contract'=>'PSTE_FAMILY_V2_ASSIGNMENT_V1','change_id'=>$changeId,'dry_run_sha256'=>(string)$dry['dry_run_sha256'],'topic_family_key'=>(string)$item['new_family_key'],'topic_family_name'=>(string)$item['new_family_name'],'identity_key_v2'=>(string)$item['identity_key_v2']];
                        PSTE_DB_Write_Guard::insert(PSTE_Repository::table('topic_assignments'),['assignment_key'=>$assignmentKey,'topic_key'=>(string)$pool['pool_key'],'category_id'=>$targetCategory,'category_name'=>(string)($item['target_category_name']??''),'article_type'=>$articleType,'assignment_source'=>'FAMILY_IDENTITY_V2','assignment_status'=>'SUGGESTED','confidence'=>1.0,'reason_codes_json'=>self::json(['PSTE_FAMILY_V2_UNAMBIGUOUS']),'payload_json'=>self::json($assignmentPayload),'first_seen_at'=>$now,'last_seen_at'=>$now],['%s','%s','%d','%s','%s','%s','%s','%f','%s','%s','%s','%s'],'PSTE_FAMILY_V2_ASSIGNMENT_INSERT');
                        $inserted[]=['table'=>'topic_assignments','id'=>(int)$wpdb->insert_id,'key'=>$assignmentKey];$writes++;
                    }
                }
                $historyPayload=['contract'=>'PSTE_FAMILY_V2_HISTORY_V1','change_id'=>$changeId,'old_family_key'=>(string)$item['old_family_key'],'new_family_key'=>(string)$item['new_family_key'],'dry_run_sha256'=>(string)$dry['dry_run_sha256'],'authorization_sha256'=>(string)$auth['authorization_sha256']];
                PSTE_DB_Write_Guard::insert(PSTE_Repository::table('topic_history'),['pool_key'=>(string)$pool['pool_key'],'action'=>'FAMILY_IDENTITY_V2_APPLY','from_status'=>(string)$pool['automatic_pool_status'],'to_status'=>'REVIEW_REQUIRED','details_json'=>self::json($historyPayload),'user_id'=>function_exists('get_current_user_id')?(int)get_current_user_id():0,'created_at'=>gmdate('Y-m-d H:i:s')],['%s','%s','%s','%s','%s','%d','%s'],'PSTE_FAMILY_V2_HISTORY_INSERT');
                $inserted[]=['table'=>'topic_history','id'=>(int)$wpdb->insert_id,'key'=>''];$writes++;
            }
            $articleAfter=self::articleGuardSnapshot();if(!hash_equals($articleBefore,(string)$articleAfter['sha256']))throw new RuntimeException('PSTE_FAMILY_V2_ARTICLE_GUARD_CHANGED');
            PSTE_Repository::commitOwnedTransaction('PSTE_FAMILY_V2_APPLY_TX_COMMIT');
        }catch(Throwable $e){PSTE_Repository::rollbackOwnedTransaction('PSTE_FAMILY_V2_APPLY_TX_ROLLBACK');throw $e;}
        $after=self::freshSnapshot();
        $report=['contract'=>self::APPLY_CONTRACT,'status'=>'PASS','applied_at_utc'=>gmdate('c'),'dry_run_sha256'=>(string)$dry['dry_run_sha256'],'authorization_sha256'=>(string)$auth['authorization_sha256'],'source_snapshot_sha256'=>(string)$fresh['source_snapshot_sha256'],'post_apply_snapshot_sha256'=>(string)$after['source_snapshot_sha256'],'article_guard_before_sha256'=>$articleBefore,'article_guard_after_sha256'=>(string)$after['article_guard']['sha256'],'approved_change_ids'=>$approved,'write_count'=>$writes,'before_rows'=>$beforeRows,'inserted_rows'=>$inserted,'published_or_draft_article_write_attempted'=>false];
        $report['apply_sha256']=self::hash(self::withoutKey($report,'apply_sha256'));update_option(PSTE_OPTION_FAMILY_V2_APPLY,$report,false);$stored=self::storedApply();if(!hash_equals((string)$report['apply_sha256'],(string)($stored['apply_sha256']??'')))throw new RuntimeException('PSTE_FAMILY_V2_APPLY_READBACK_FAILED');
        return $report;
    }

    /** Exact rollback of the one stored apply report. */
    public static function rollback(): array {
        $existing=self::storedRollback();if(($existing['contract']??'')===self::ROLLBACK_CONTRACT&&($existing['status']??'')==='PASS')return ['contract'=>self::ROLLBACK_CONTRACT,'status'=>'IDEMPOTENT_NOOP','write_count'=>0,'rollback_sha256'=>(string)($existing['rollback_sha256']??'')];
        $apply=self::storedApply();if(($apply['contract']??'')!==self::APPLY_CONTRACT||($apply['status']??'')!=='PASS')throw new RuntimeException('PSTE_FAMILY_V2_ROLLBACK_APPLY_REPORT_REQUIRED');
        $articleBefore=self::articleGuardSnapshot();if(!hash_equals((string)$apply['article_guard_after_sha256'],(string)$articleBefore['sha256']))throw new RuntimeException('PSTE_FAMILY_V2_ROLLBACK_ARTICLE_GUARD_DRIFT');
        global $wpdb;$writes=0;PSTE_Repository::beginOwnedTransaction('PSTE_FAMILY_V2_ROLLBACK_TX_START');
        try{
            foreach(array_reverse((array)$apply['inserted_rows']) as $inserted){$table=(string)$inserted['table'];$id=(int)$inserted['id'];if($id>0)$writes+=PSTE_DB_Write_Guard::delete(PSTE_Repository::table($table),['id'=>$id],['%d'],'PSTE_FAMILY_V2_ROLLBACK_DELETE');}
            foreach(array_reverse((array)$apply['before_rows']) as $entry){$table=(string)$entry['table'];$row=(array)$entry['row'];$id=(int)($row['id']??0);if($id<=0)throw new RuntimeException('PSTE_FAMILY_V2_ROLLBACK_ROW_ID_MISSING');$restore=$row;unset($restore['id']);$formats=[];foreach($restore as $value)$formats[]=is_int($value)?'%d':(is_float($value)?'%f':'%s');$writes+=PSTE_DB_Write_Guard::update(PSTE_Repository::table($table),$restore,['id'=>$id],$formats,['%d'],'PSTE_FAMILY_V2_ROLLBACK_RESTORE');}
            $articleAfter=self::articleGuardSnapshot();if(!hash_equals((string)$articleBefore['sha256'],(string)$articleAfter['sha256']))throw new RuntimeException('PSTE_FAMILY_V2_ROLLBACK_ARTICLE_GUARD_CHANGED');
            $restored=self::freshSnapshot();if(!hash_equals((string)$apply['source_snapshot_sha256'],(string)$restored['source_snapshot_sha256']))throw new RuntimeException('PSTE_FAMILY_V2_ROLLBACK_SOURCE_SNAPSHOT_MISMATCH');
            PSTE_Repository::commitOwnedTransaction('PSTE_FAMILY_V2_ROLLBACK_TX_COMMIT');
        }catch(Throwable $e){PSTE_Repository::rollbackOwnedTransaction('PSTE_FAMILY_V2_ROLLBACK_TX_ROLLBACK');throw $e;}
        $report=['contract'=>self::ROLLBACK_CONTRACT,'status'=>'PASS','rolled_back_at_utc'=>gmdate('c'),'apply_sha256'=>(string)$apply['apply_sha256'],'write_count'=>$writes,'article_guard_sha256'=>(string)$articleBefore['sha256'],'restored_source_snapshot_sha256'=>(string)$apply['source_snapshot_sha256'],'published_or_draft_article_write_attempted'=>false];$report['rollback_sha256']=self::hash(self::withoutKey($report,'rollback_sha256'));update_option(PSTE_OPTION_FAMILY_V2_ROLLBACK,$report,false);$apply['status']='ROLLED_BACK';$apply['rolled_back_by_sha256']=$report['rollback_sha256'];$apply['original_apply_sha256']=$apply['apply_sha256'];$apply['apply_sha256']=self::hash(self::withoutKey($apply,'apply_sha256'));update_option(PSTE_OPTION_FAMILY_V2_APPLY,$apply,false);delete_option(PSTE_OPTION_FAMILY_V2_AUTHORIZATION);$stored=self::storedRollback();if(!hash_equals((string)$report['rollback_sha256'],(string)($stored['rollback_sha256']??'')))throw new RuntimeException('PSTE_FAMILY_V2_ROLLBACK_READBACK_FAILED');return $report;
    }

    /** @return array<string,mixed> */
    private static function simulatePoolRow(array $row,array $registry,array $collisionKeys,array $inventoryItems,array $categoryItems): array {
        $payload=self::decodeObject((string)($row['payload_json']??''));$query=self::queryFromPayload($payload);$current=self::currentFamily($row,$payload,$registry);$currentKey=(string)$current['key'];$manual=trim((string)($row['manual_status']??''))!==''||(int)($row['manual_category_id']??0)>0||trim((string)($row['manual_article_type']??''))!==''||trim((string)($row['manual_note']??''))!=='';$articleLinked=self::linkedToExistingArticle($payload,$inventoryItems);
        $classification='ORPHANED';$resolution=['status'=>'NO_MATCH','winner'=>null,'matches'=>[],'reviews'=>[]];$reason=[];$winner=null;
        if($query==='')$reason[]='PSTE_FAMILY_V2_RAW_QUERY_MISSING';else $resolution=PSTE_Family_Identity_V2::resolve($query,$registry);
        if(!empty($current['conflict'])){$classification='CONFLICT_REVIEW';$reason[]='PSTE_FAMILY_V2_CURRENT_FAMILY_CONFLICT';}
        elseif($manual){$classification='CONFLICT_REVIEW';$reason[]='PSTE_FAMILY_V2_MANUAL_DECISION_PROTECTED';}
        elseif($articleLinked){$classification='CONFLICT_REVIEW';$reason[]='PSTE_FAMILY_V2_PUBLISHED_OR_DRAFT_ARTICLE_LINK_PROTECTED';}
        elseif(isset($collisionKeys[$currentKey])){$classification='HASH_COLLISION';$reason[]='PSTE_FAMILY_V2_IDENTITY_COLLISION';}
        elseif($query==='')$classification='ORPHANED';
        elseif(($resolution['status']??'')==='MATCH'){
            $winner=(array)$resolution['winner'];$newKey=(string)($winner['family_key']??'');
            if(isset($collisionKeys[$newKey])){$classification='HASH_COLLISION';$reason[]='PSTE_FAMILY_V2_IDENTITY_COLLISION';}
            elseif($currentKey==='')$classification='NEWLY_ELIGIBLE';
            elseif(hash_equals($currentKey,$newKey))$classification='UNCHANGED';
            else $classification='MOVE_UNAMBIGUOUS';
        }elseif(($resolution['status']??'')==='REVIEW_REQUIRED'){$classification='CONFLICT_REVIEW';$reason[]=(string)($resolution['reason_code']??'PSTE_FAMILY_V2_MULTIPLE_PLAUSIBLE_FAMILIES');}
        else {$classification=$currentKey!==''?'NEWLY_BLOCKED':'ORPHANED';$reason[]='PSTE_FAMILY_V2_NO_FAMILY_MATCH';}
        if($articleLinked){$classification='CONFLICT_REVIEW';$reason[]='PSTE_FAMILY_V2_PUBLISHED_OR_DRAFT_ARTICLE_LINK_PROTECTED';}
        $newKey=$winner?(string)($winner['family_key']??''):'';$newFamily=$newKey!==''?(array)($registry['families'][$newKey]??[]):[];$identity=(array)($newFamily['identity_v2']??[]);
        $articleType=self::articleTypeFrom($row,$payload);$target=$newKey!==''&&$articleType!==''?PSTE_Article_Type_Registry::resolve($registry,$newKey,$articleType):['ok'=>false];
        $targetValid=!empty($target['ok'])&&(int)($target['term_id']??0)>0&&trim((string)($target['name']??''))!==''&&trim((string)($target['slug']??''))!=='';
        if(in_array($classification,self::APPLY_ELIGIBLE,true)&&!$targetValid){$classification='CONFLICT_REVIEW';$reason[]='PSTE_FAMILY_V2_TARGET_CATEGORY_REQUIRED_FOR_APPLY';}
        if(($resolution['status']??'')==='NO_MATCH')foreach((array)($resolution['rejection_diagnostics']['nearest_failure_reason_codes']??['PSTE_FAMILY_V2_SUBJECT_HEAD_MISSING']) as $failure)$reason[]='PSTE_FAMILY_V2_FAILED_STAGE_'.preg_replace('/^PSTE_FAMILY_V2_/','',(string)$failure);
        $recheckCandidate=$payload;if($newKey!==''){$recheckCandidate['topic_family_key']=$newKey;$recheckCandidate['topic_family_name']=(string)($newFamily['topic_family_name']??'');}if($targetValid){$recheckCandidate['target_category_id']=(int)$target['term_id'];$recheckCandidate['target_category_name']=(string)$target['name'];$recheckCandidate['target_category_slug']=(string)$target['slug'];$recheckCandidate['proposed_article_type']=$articleType;}$cannibalization=class_exists('PSTE_Cannibalization')?PSTE_Cannibalization::decide($recheckCandidate,$inventoryItems,$categoryItems):['decision'=>'NOT_EXECUTED','reason_codes'=>['PSTE_CANNIBALIZATION_CLASS_NOT_LOADED'],'matches'=>[]];
        $before=self::stringifyRow($row);$eligible=in_array($classification,self::APPLY_ELIGIBLE,true)&&!$manual&&$newKey!==''&&$targetValid;
        $changeId=hash('sha256',(string)($row['pool_key']??'').'|'.self::hash($before).'|'.$classification.'|'.$newKey.'|'.(string)($target['term_id']??0));
        return [
            'change_id'=>$changeId,'pool_id'=>(int)($row['id']??0),'pool_key'=>(string)($row['pool_key']??''),'candidate_id'=>(string)($row['candidate_id']??''),
            'query'=>$query,'query_sha256'=>$query!==''?hash('sha256',$query):'','raw_query_fingerprint'=>self::rawQueryFingerprint($payload),
            'classification'=>$classification,'eligible_for_apply'=>$eligible,'reason_codes'=>array_values(array_unique(array_filter($reason))),
            'old_family_key'=>$currentKey,'old_family_name'=>(string)$current['name'],'new_family_key'=>$newKey,'new_family_name'=>(string)($newFamily['topic_family_name']??''),'identity_key_v2'=>(string)($identity['identity_key_v2']??''),
            'article_type'=>$articleType,'target_category_id'=>(int)($target['term_id']??0),'target_category_name'=>(string)($target['name']??''),'target_category_slug'=>(string)($target['slug']??''),
            'resolution'=>$resolution,'cannibalization_recheck'=>$cannibalization,'before_row_sha256'=>self::hash($before),'manual_decision_protected'=>$manual,
        ];
    }

    /** @return array{key:string,name:string,sources:list<string>} */
    private static function currentFamily(array $row,array $payload,array $registry): array {
        $keys=[];$names=[];$sources=[];
        foreach(['topic_family_key'] as $field)if(trim((string)($payload[$field]??''))!==''){$keys[]=(string)$payload[$field];$sources[]='payload.'.$field;}
        if(trim((string)($payload['semantic_backfill']['family_key']??''))!==''){$keys[]=(string)$payload['semantic_backfill']['family_key'];$sources[]='payload.semantic_backfill.family_key';}
        $categoryId=(int)($row['current_category_id']??0);if($categoryId>0&&isset($registry['by_term_id'][$categoryId])){$mapped=$registry['by_term_id'][$categoryId];$mappedKey=is_array($mapped)?(string)($mapped['topic_family_key']??''):(string)$mapped;if($mappedKey!==''){$keys[]=$mappedKey;$sources[]='current_category_id';}}
        foreach(['topic_family_name'] as $field)if(trim((string)($payload[$field]??''))!=='')$names[]=(string)$payload[$field];
        $keys=array_values(array_unique(array_filter($keys)));$key=count($keys)===1?$keys[0]:'';
        if(count($keys)>1)$sources[]='CONFLICTING_CURRENT_KEYS';
        $name=$key!==''?(string)($registry['families'][$key]['topic_family_name']??''):($names[0]??'');
        return ['key'=>$key,'name'=>$name,'sources'=>array_values(array_unique($sources)),'conflict'=>count($keys)>1];
    }

    private static function linkedToExistingArticle(array $payload,array $inventoryItems): bool {$candidateIds=[];foreach(['canonical_article_id','plan_slot_sha256'] as $k){$v=trim((string)($payload[$k]??''));if($v!=='')$candidateIds[$k]=$v;}foreach((array)$inventoryItems as $article){foreach($candidateIds as $k=>$v)if(trim((string)($article[$k]??''))!==''&&hash_equals($v,trim((string)$article[$k])))return true;$articleTitle=PSTE_Normalizer::exactTopicIdentityText((string)($article['title']??''));if($articleTitle==='')continue;foreach(['production_title','editorial_title'] as $field){$candidateTitle=PSTE_Normalizer::exactTopicIdentityText((string)($payload[$field]??''));if($candidateTitle!==''&&hash_equals($candidateTitle,$articleTitle))return true;}}return false;}

    private static function queryFromPayload(array $payload): string {foreach(['primary_longtail_query','canonical_query','raw_user_question'] as $key){$v=trim((string)($payload[$key]??''));if($v!=='')return $v;}foreach(['language_corrected_query','raw_query','normalized_query'] as $key){$v=trim((string)($payload['query_record'][$key]??''));if($v!=='')return $v;}return '';}
    private static function articleTypeFrom(array $row,array $payload): string {foreach(['manual_article_type'] as $field){$v=trim((string)($row[$field]??''));if($v!=='')return $v;}foreach(['proposed_article_type','suggested_article_type'] as $field){$v=trim((string)($payload[$field]??''));if($v!=='')return $v;}return '';}
    private static function applyFamilyPayload(array $payload,array $item): array {$payload['topic_family_key']=(string)$item['new_family_key'];$payload['topic_family_name']=(string)$item['new_family_name'];$payload['family_identity_v2_assignment']=['contract'=>'PSTE_FAMILY_IDENTITY_V2_ASSIGNMENT_V1','identity_key_v2'=>(string)$item['identity_key_v2'],'change_id'=>(string)$item['change_id'],'classification'=>(string)$item['classification'],'assigned_at_utc'=>gmdate('c')];if((int)($item['target_category_id']??0)>0){$payload['suggested_category_id']=(int)$item['target_category_id'];$payload['suggested_category_name']=(string)$item['target_category_name'];$payload['suggested_category_slug']=(string)$item['target_category_slug'];}return $payload;}

    private static function assertDryRunIntegrity(array $dry): void {if(($dry['contract']??'')!==self::DRY_RUN_CONTRACT)throw new RuntimeException('PSTE_FAMILY_V2_DRY_RUN_CONTRACT_INVALID');$actual=(string)($dry['dry_run_sha256']??'');$expected=self::hash(self::withoutKey($dry,'dry_run_sha256'));if(!preg_match('/^[a-f0-9]{64}$/',$actual)||!hash_equals($expected,$actual))throw new RuntimeException('PSTE_FAMILY_V2_DRY_RUN_INTEGRITY_FAILED');}
    private static function assertAuthorizationIntegrity(array $authorization): void {$actual=(string)($authorization['authorization_sha256']??'');$expected=self::hash(self::withoutKey($authorization,'authorization_sha256'));if(!preg_match('/^[a-f0-9]{64}$/',$actual)||!hash_equals($expected,$actual))throw new RuntimeException('PSTE_FAMILY_V2_AUTHORIZATION_INTEGRITY_FAILED');}

    private static function assertAuthorizationShape(array $a): void {
        if(($a['contract']??'')!==self::AUTH_CONTRACT)throw new RuntimeException('PSTE_FAMILY_V2_AUTHORIZATION_CONTRACT_INVALID');
        if(($a['claude_verdict']??'')!=='CLAUDE_DRY_RUN_PASS')throw new RuntimeException('PSTE_FAMILY_V2_CLAUDE_DRY_RUN_PASS_REQUIRED');
        if(empty($a['user_authorized']))throw new RuntimeException('PSTE_FAMILY_V2_USER_AUTHORIZATION_REQUIRED');
        foreach(['dry_run_sha256','source_snapshot_sha256','registry_sha256','family_identity_v2_registry_sha256'] as $field)if(!preg_match('/^[a-f0-9]{64}$/',(string)($a[$field]??'')))throw new RuntimeException('PSTE_FAMILY_V2_AUTHORIZATION_HASH_INVALID_'.strtoupper($field));
        if(!is_array($a['approved_change_ids']??null))throw new RuntimeException('PSTE_FAMILY_V2_AUTHORIZATION_CHANGE_LIST_INVALID');
    }
    private static function assertSnapshotStillIdentical(array $dry,array $fresh): void {
        if(!hash_equals((string)$dry['source_snapshot_sha256'],(string)$fresh['source_snapshot_sha256']))throw new RuntimeException('PSTE_FAMILY_V2_SOURCE_SNAPSHOT_STALE');
        if(!hash_equals((string)$dry['article_guard_sha256'],(string)$fresh['article_guard']['sha256']))throw new RuntimeException('PSTE_FAMILY_V2_ARTICLE_GUARD_STALE');
        $registry=PSTE_Article_Type_Registry::build((array)$fresh['baseline']);if(!hash_equals((string)$dry['registry_sha256'],(string)$registry['registry_sha256']))throw new RuntimeException('PSTE_FAMILY_V2_REGISTRY_STALE');
        if(!hash_equals((string)$dry['family_identity_v2_registry_sha256'],self::familyRegistryHash($registry)))throw new RuntimeException('PSTE_FAMILY_V2_IDENTITY_REGISTRY_STALE');
    }

    /** Published/draft articles are read only; every relevant byte/value is hashed. */
    private static function articleGuardSnapshot(): array {
        global $wpdb;$posts=$wpdb->get_results("SELECT ID,post_type,post_status,post_title,post_name,post_content,post_excerpt,post_parent,menu_order FROM {$wpdb->posts} WHERE post_status IN ('publish','draft') ORDER BY ID ASC",ARRAY_A)?:[];$ids=array_map('intval',array_column($posts,'ID'));
        $relations=[];$meta=[];
        if($ids){$in=implode(',',array_map('intval',$ids));$relations=$wpdb->get_results("SELECT tr.object_id,tt.term_taxonomy_id,tt.term_id,tt.taxonomy,t.slug,t.name FROM {$wpdb->term_relationships} tr JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id JOIN {$wpdb->terms} t ON t.term_id=tt.term_id WHERE tr.object_id IN ($in) ORDER BY tr.object_id,tt.taxonomy,tt.term_id",ARRAY_A)?:[];$meta=$wpdb->get_results("SELECT post_id,meta_key,meta_value FROM {$wpdb->postmeta} WHERE post_id IN ($in) ORDER BY post_id,meta_key,meta_id",ARRAY_A)?:[];}
        $payload=['posts'=>array_map([self::class,'stringifyRow'],$posts),'term_relationships'=>array_map([self::class,'stringifyRow'],$relations),'postmeta'=>array_map([self::class,'stringifyRow'],$meta)];
        return ['contract'=>'PSTE_PUBLISHED_DRAFT_ARTICLE_GUARD_V1','counts'=>['posts'=>count($posts),'term_relationships'=>count($relations),'postmeta'=>count($meta)],'sha256'=>self::hash($payload),'write_attempted'=>false];
    }

    private static function baselineIdentity(array $baseline): array {return [
        'inventory_sha256'=>(string)($baseline['inventory_sha256']??''),
        'structure_sha256'=>(string)($baseline['structure_sha256']??$baseline['structure_hash']??''),
        'editorial_plan_sha256'=>(string)($baseline['editorial_plan_sha256']??''),
        'post_counts'=>(array)($baseline['post_counts']??[]),
        'category_count'=>(int)($baseline['category_count']??0),
        'leaf_category_count'=>(int)($baseline['leaf_category_count']??0),
        'protected_category_map_sha256'=>(string)($baseline['protected_category_map_sha256']??''),
    ];}
    private static function familyRegistryHash(array $registry): string {$x=[];foreach((array)($registry['families']??[]) as $k=>$f)$x[$k]=(array)($f['identity_v2']??[]);ksort($x,SORT_STRING);return self::hash($x);}
    private static function identityCollisions(array $registry): array {$map=[];foreach((array)($registry['families']??[]) as $key=>$family){$id=(string)($family['identity_v2']['identity_key_v2']??'');if($id!=='')$map[$id][]=(string)$key;}$out=[];foreach($map as $id=>$keys)if(count($keys)>1)$out[]=['identity_key_v2'=>$id,'family_keys'=>$keys];return $out;}
    /** Prove that every stored Longtail-related row is represented by the dry-run. */
    private static function coverageAudit(array $poolRows,array $candidateRows,array $occurrenceRows,array $assignmentRows,array $historyRows,array $identityRows,array $mergeRows,array $registry): array {
        $poolKeys=[];$candidateIds=[];$topicUuids=[];
        foreach($poolRows as $row){
            $poolKey=(string)($row['pool_key']??'');if($poolKey!==''){$poolKeys[$poolKey]=true;$topicUuids[$poolKey]=true;}
            $candidateId=(string)($row['candidate_id']??'');if($candidateId!=='')$candidateIds[$candidateId]=true;
            // Legacy payload UUIDs remain accepted for backwards compatibility, but the
            // canonical live relation is pool_key -> topic_identity.topic_uuid.
            try{$payload=self::decodeObject((string)($row['payload_json']??''));}catch(Throwable $e){$payload=[];}
            foreach(['global_topic_uuid','topic_uuid'] as $field){$uuid=trim((string)($payload[$field]??''));if($uuid!=='')$topicUuids[$uuid]=true;}
        }
        $orphans=['candidates'=>[],'topic_occurrences'=>[],'topic_assignments'=>[],'topic_history'=>[],'topic_identity'=>[],'topic_merge_candidates'=>[]];$historical=[];
        foreach($candidateRows as $row){
            $key=(string)($row['candidate_id']??'');
            if($key===''){$orphans['candidates'][]=(int)($row['id']??0);continue;}
            if(isset($candidateIds[$key]))continue;
            try{$payload=self::decodeObject((string)($row['payload_json']??''));$query=self::queryFromPayload($payload);}catch(Throwable $e){$payload=[];$query='';}
            $resolution=$query!==''?PSTE_Family_Identity_V2::resolve($query,$registry):['status'=>'NO_MATCH','reason_code'=>'PSTE_FAMILY_V2_RAW_QUERY_MISSING','rejection_diagnostics'=>[]];
            $historical[]=['row_id'=>(int)($row['id']??0),'candidate_id'=>$key,'query'=>$query,'query_sha256'=>$query!==''?hash('sha256',$query):'','classification'=>'HISTORICAL_UNPOOLED_CANDIDATE_AUDITED','resolution_status'=>(string)($resolution['status']??''),'winner_family_key'=>(string)($resolution['winner']['family_key']??''),'winner_family_name'=>(string)($resolution['winner']['topic_family_name']??''),'reason_code'=>(string)($resolution['reason_code']??''),'rejection_diagnostics'=>(array)($resolution['rejection_diagnostics']??[]),'write_attempted'=>false];
        }
        foreach($occurrenceRows as $row){$key=(string)($row['topic_key']??'');if($key===''||!isset($poolKeys[$key]))$orphans['topic_occurrences'][]=(int)($row['id']??0);}
        foreach($assignmentRows as $row){$key=(string)($row['topic_key']??'');if($key===''||!isset($poolKeys[$key]))$orphans['topic_assignments'][]=(int)($row['id']??0);}
        foreach($historyRows as $row){$key=(string)($row['pool_key']??'');if($key===''||!isset($poolKeys[$key]))$orphans['topic_history'][]=(int)($row['id']??0);}
        foreach($identityRows as $row){$key=(string)($row['topic_uuid']??'');if($key===''||!isset($topicUuids[$key]))$orphans['topic_identity'][]=(string)($row['normalized_key']??'');}
        foreach($mergeRows as $row){$source=(string)($row['source_topic_uuid']??'');$target=(string)($row['target_topic_uuid']??'');if($source===''||$target===''||!isset($topicUuids[$source])||!isset($topicUuids[$target]))$orphans['topic_merge_candidates'][]=(int)($row['id']??0);}
        $orphanCount=0;foreach($orphans as &$ids){$ids=array_values(array_unique($ids));$orphanCount+=count($ids);}unset($ids);
        return ['contract'=>'PSTE_FAMILY_V2_FULL_ROW_COVERAGE_AUDIT_V2','status'=>$orphanCount===0?'PASS':'REVIEW_REQUIRED','pool_rows_replayed'=>count($poolRows),'related_row_counts'=>['candidates'=>count($candidateRows),'topic_occurrences'=>count($occurrenceRows),'topic_assignments'=>count($assignmentRows),'topic_history'=>count($historyRows),'topic_identity'=>count($identityRows),'topic_merge_candidates'=>count($mergeRows)],'orphan_count'=>$orphanCount,'orphan_row_ids'=>$orphans,'historical_unpooled_candidate_count'=>count($historical),'historical_unpooled_candidates'=>$historical,'all_candidate_rows_audited'=>count($candidateRows)===count(array_filter($candidateRows,static fn($r)=>(string)($r['candidate_id']??'')!=='')),'write_attempted'=>false];
    }

    private static function indexRows(array $rows,string $field): array {$out=[];foreach($rows as $row)$out[(string)($row[$field]??'')][]=$row;return $out;}
    private static function mergeIndex(array $rows): array {$out=[];foreach($rows as $row){$out[(string)($row['source_topic_uuid']??'')][]=$row;$out[(string)($row['target_topic_uuid']??'')][]=$row;}return $out;}
    private static function rawQueryFingerprint(array $payload): string {$values=[];foreach(['primary_longtail_query','canonical_query','raw_user_question','global_topic_identity_text','semantic_fingerprint','normalized_key'] as $k)$values[$k]=$payload[$k]??null;$values['query_record']=$payload['query_record']??null;$values['aliases']=$payload['aliases']??null;return self::hash($values);}
    private static function decodeObject(string $json): array {$v=json_decode($json,true);if(!is_array($v))throw new RuntimeException('PSTE_FAMILY_V2_STORED_JSON_INVALID');return $v;}
    private static function stringifyRow(array $row): array {$out=[];foreach($row as $k=>$v)$out[(string)$k]=(is_scalar($v)||$v===null)?($v===null?null:(string)$v):self::json($v);return $out;}
    private static function withoutKey(array $v,string $key): array {unset($v[$key]);return $v;}
    private static function hash($v): string {return hash('sha256',self::json(self::canonicalize($v)));}
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
    private static function json($v): string {$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($j))throw new RuntimeException('PSTE_FAMILY_V2_JSON_ENCODING_FAILED');return $j;}
}
