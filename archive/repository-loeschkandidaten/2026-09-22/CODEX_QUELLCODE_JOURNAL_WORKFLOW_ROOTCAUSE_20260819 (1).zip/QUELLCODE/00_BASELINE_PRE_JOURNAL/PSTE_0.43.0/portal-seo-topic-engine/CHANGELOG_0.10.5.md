# 0.10.5-staging — realer Portalbestand und Kategorien-Quarantäne

- Die Portalstruktur wird gegen den echten, read-only exportierten Seiten- und Kategorienbestand geprüft.
- Die 1.124 validierten Produktionskategorien werden über eine unveränderliche, hashgebundene Portalzuordnung erkannt; historische Slug-Abweichungen können über eindeutige stabile Identität aufgefangen werden.
- Neue, eindeutig erkennbare Beitragsarten können dynamisch einer vorhandenen Produktseite zugeordnet werden.
- Eine einzelne unklare oder doppelte Kategorie wird ausschließlich selbst fail-closed quarantänisiert. Sie blockiert nicht mehr den vollständigen Portalbestand.
- Diagnoseinformationen wie Term-ID, Name, Slug, Grund und Kandidaten bleiben bis zur Backendanzeige erhalten.
- Echte Strukturfehler wie doppelte IDs, fehlende Seiteneltern oder Seitenzyklen bleiben global fail-closed.
- Keine Schreibzugriffe auf Beiträge, Kategorien, Seiten, Taxonomien, Yoast, Design oder Produktionsmaschine.
