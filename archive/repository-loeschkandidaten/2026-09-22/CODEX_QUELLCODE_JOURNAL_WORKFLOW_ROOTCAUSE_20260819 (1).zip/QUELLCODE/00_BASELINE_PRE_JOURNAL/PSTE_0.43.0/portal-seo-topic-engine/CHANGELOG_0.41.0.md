# PSTE 0.41.0 – backend baseline request-bounded repair

Scope: ausschließlich technische Entlastung des Admin-Requests `Gesamtbestand neu abgleichen` nach dem Live-Timeout-/Critical-Error-Stand 0.40.2.

## Geändert
- Baseline-Capture startet den bereits vorhandenen Portal-Kontextjob, führt aber weder dessen ersten Kontext-Batch noch den vollständigen Sandbox-Rebind synchron im Browser-Request aus.
- Der bestehende Kontextjob verarbeitet die bisherige Sandbox-Baseline-Neubindung request-begrenzt mit derselben fachlichen Rebind-Logik.
- Die vorhandene Topic-Payload-Reparatur wird pro dauerhaftem Kontextjob einmal ausgeführt statt vor jedem Batch erneut über den Gesamtbestand zu laufen.
- Bestehende ältere Kontextjob-Zustände werden fail-closed/kompatibel in den request-begrenzten technischen Zustand übernommen.

## Nicht geändert
- keine Änderung der fachlichen Workflow-Reihenfolge;
- keine Änderung an STARTMASTER 0039 oder Textmaschine;
- keine Änderung an PPM 6.7.9 oder PSERC 0.22.0;
- keine Änderung an Mengen- oder Titelregeln;
- keine Änderung an Recherche, Themenwahl, Kategorie-/Artikeltyp-/Planplatzbindung oder Gates;
- keine Änderung an Artikelinhalt, HTML, Formatierung oder Design;
- keine neuen Provider-Aufrufe oder WordPress-Beitrags-/Taxonomie-Schreibrechte.

0.40.2 ist wegen des gemeldeten Live-Critical-Errors RETIRED und darf nicht erneut installiert werden.
