<?php
if (!defined('ABSPATH')) { return; }

/**
 * Sandbox planner inside the single E2E system. Sandbox clarifies blocked keywords, but never creates
 * a five-field production handoff. Existing structure is re-checked after meaning-preserving normalization
 * before a true structure gap is declared.
 */
final class PSTE_Sandbox_Internal_Planner {
    public const CONTRACT='PSTE_SANDBOX_INTERNAL_PROPOSAL_V2_DUAL_STRAND';
    private const DOWNSTREAM_HANDOFF_FIELDS=['title','target_keyword','category','article_type','plan_slot'];

    /** @return array<string,mixed> */
    public static function plan(array $record,array $registry,array $baseline,array $external,array $sourcePayload,array $inventory): array {
        if(($external['status']??'')!=='RELEVANT_FOR_PORTAL')return self::blocked('RELEVANCE_NOT_CONFIRMED',['PSTE_SANDBOX_RELEVANCE_CONFIRMATION_REQUIRED']);
        $query=trim((string)($record['query']??''));if($query==='')return self::blocked('REVIEW_REQUIRED',['PSTE_SANDBOX_QUERY_MISSING']);
        $nearest=array_values((array)($record['nearest_rejected_families']??[]));$nearestFailures=array_values(array_map('strval',(array)($record['nearest_failure_reason_codes']??[])));

        // Mandatory pre-gap recovery: normalize only the research phrase, then rerun the real family gate.
        $probe=PSTE_Editorial_Topic_Normalizer::semanticProbe($query);
        $primaryResolution=PSTE_Family_Identity_V2::resolve($probe,$registry);
        $familyKey='';$family=[];$familySource='';
        if(($primaryResolution['status']??'')==='MATCH'&&is_array($primaryResolution['winner']??null)){
            $familyKey=(string)($primaryResolution['winner']['family_key']??'');$family=(array)($registry['families'][$familyKey]??[]);$familySource='NORMALIZED_PRIMARY_FAMILY_GATE';
        }elseif(count($nearest)===1){
            $nearestRow=(array)$nearest[0];
            if(!empty($nearestRow['details']['excluded_matches'])||!empty($nearestRow['excluded_matches']))return self::blocked('REVIEW_REQUIRED',['PSTE_SANDBOX_PRIMARY_EXCLUSION_PREVENTS_NEAREST_FAMILY_PROPOSAL'],['nearest_rejected_family'=>$nearestRow,'normalized_family_resolution'=>$primaryResolution]);
            $familyKey=(string)($nearestRow['family_key']??'');$family=(array)($registry['families'][$familyKey]??[]);$familySource='HISTORICAL_NEAREST_FAMILY_REVIEW_ONLY';
        }elseif(count($nearest)>1||($primaryResolution['status']??'')==='REVIEW_REQUIRED'){
            return self::blocked('MULTIPLE_FAMILIES_REVIEW',['PSTE_SANDBOX_MULTIPLE_FAMILIES_AFTER_NORMALIZATION'],['normalized_family_resolution'=>$primaryResolution]);
        }

        if($familyKey===''||!$family){
            $proposalNormalization=PSTE_Editorial_Topic_Normalizer::normalize($query,'');
            $proposedFamily=trim((string)($proposalNormalization['subject_topic']??$proposalNormalization['normalized_topic']??''));
            $intentAnalysis=$proposedFamily!==''?PSTE_Intent_Profile::analyzeBeforeType($query,$proposalNormalization,$proposedFamily,$sourcePayload):[];
            $typeOnly=PSTE_Semantic_Classifier::classifyTypeOnly($query,$registry);$type=!empty($typeOnly['ok'])?(string)($typeOnly['resolved_article_type']??''):'';
            $expectedType=PSTE_Article_Type_Registry::canonicalType((string)($intentAnalysis['primary_article_type_candidate']??''));$actualType=PSTE_Article_Type_Registry::canonicalType($type);$intentTypeConsistent=$expectedType===''||$actualType===''||hash_equals($expectedType,$actualType);
            $structure=PSTE_Editorial_Topic_Normalizer::structureProposal($query,$type,$sourcePayload,$intentAnalysis);$structure['type_only_consensus']=$typeOnly;$structure['intent_type_consistent']=$intentTypeConsistent;
            if(!$intentTypeConsistent)$structure['proposed_article_type_status']='REVIEW_REQUIRED_INTENT_TYPE_CONFLICT';
            $quality=(array)($structure['planning_title_quality']??[]);
            $structure['editorial_quality']=$quality;$structure['periodic_internal_recheck_required']=true;
            return self::blocked('STRUCTURE_GAP',['PSTE_SANDBOX_RELEVANT_NO_EXISTING_FAMILY_AFTER_EDITORIAL_NORMALIZATION'],[
                'normalized_family_resolution'=>$primaryResolution,'structure_gap'=>['query'=>$query,'historical_family_key'=>(string)($record['old_family_key']??''),'historical_family_name'=>(string)($record['old_family_name']??''),'requires_internal_structure_review'=>true],
                'structure_proposal'=>$structure,'retained_keyword'=>$query,'retained_title'=>(string)($structure['planning_title_proposal']??''),'retained_title_status'=>(string)($structure['planning_title_status']??'REVIEW_REQUIRED'),'periodic_internal_recheck_required'=>true,
            ]);
        }

        $familyName=(string)($family['topic_family_name']??'');$normalization=PSTE_Editorial_Topic_Normalizer::normalize($query,$familyName);
        $intentAnalysis=PSTE_Intent_Profile::analyzeBeforeType($query,$normalization,$familyName,$sourcePayload);
        if(empty($intentAnalysis['ok']))return self::blocked('REVIEW_REQUIRED',array_merge(['PSTE_SANDBOX_INTENT_NOT_PROVEN_BEFORE_TYPE'],(array)($intentAnalysis['reason_codes']??[])),['family_key'=>$familyKey,'family_name'=>$familyName,'normalized_topic'=>$normalization,'intent_analysis'=>$intentAnalysis,'normalized_family_resolution'=>$primaryResolution]);
        $normalizedTopic=(string)($normalization['normalized_topic']??'');
        $semantic=PSTE_Semantic_Classifier::classify($normalizedTopic!==''?$normalizedTopic:$query,null,$registry,$familyKey);
        if(empty($semantic['ok'])){
            $status=!empty($semantic['type_consensus'])&&empty($semantic['category_consensus'])?'STRUCTURE_GAP':'REVIEW_REQUIRED';
            $extra=['family_key'=>$familyKey,'family_name'=>$familyName,'family_resolution_source'=>$familySource,'normalized_topic'=>$normalization,'semantic_assignment'=>$semantic,'normalized_family_resolution'=>$primaryResolution];
            if($status==='STRUCTURE_GAP'){
                $type=(string)($semantic['resolved_article_type']??'');
                $gap=PSTE_Category_Gap::proposal($familyName,$familyKey,$type,$semantic,(array)($sourcePayload['evidence']??[]),(string)($baseline['structure_sha256']??''),$registry);
                $extra['structure_proposal']=$gap;$extra['retained_keyword']=$query;$extra['periodic_internal_recheck_required']=true;
            }
            return self::blocked($status,array_merge(['PSTE_SANDBOX_NORMALIZED_PRIMARY_SEMANTIC_CONSENSUS_REQUIRED'],(array)($semantic['reason_codes']??[])),$extra);
        }
        $intentProfile=PSTE_Intent_Profile::bindArticleType($intentAnalysis,$semantic,$registry,$familyKey);
        if(empty($intentProfile['ok']))return self::blocked('REVIEW_REQUIRED',array_merge(['PSTE_SANDBOX_INTENT_TYPE_BINDING_NOT_PROVEN'],(array)($intentProfile['reason_codes']??[])),['family_key'=>$familyKey,'family_name'=>$familyName,'normalized_topic'=>$normalization,'intent_analysis'=>$intentAnalysis,'intent_profile'=>$intentProfile,'semantic_assignment'=>$semantic,'normalized_family_resolution'=>$primaryResolution]);
        $articleType=(string)$semantic['resolved_article_type'];$target=(array)$semantic['resolved_category'];
        if((int)($target['term_id']??0)<=0||(string)($target['slug']??'')==='')return self::blocked('STRUCTURE_GAP',['PSTE_SANDBOX_TARGET_CATEGORY_MISSING_AFTER_NORMALIZATION'],['family_key'=>$familyKey,'family_name'=>$familyName,'semantic_assignment'=>$semantic,'intent_analysis'=>$intentAnalysis,'intent_profile'=>$intentProfile,'retained_keyword'=>$query,'periodic_internal_recheck_required'=>true]);

        $queryRecord=is_array($sourcePayload['query_record']??null)?(array)$sourcePayload['query_record']:[];
        $queryRecord['raw_query']=$query; // exact Sandbox raw phrase remains authoritative for preservation.
        if(trim((string)($queryRecord['language_corrected_query']??''))==='')$queryRecord['language_corrected_query']=$query;
        $title=PSTE_Title_Pipeline::build($queryRecord,$familyName,$articleType,$registry,[],$intentProfile);
        $risk=PSTE_Domain_Risk_Gate::evaluate($query,$articleType);
        $sources=array_values(array_unique(array_filter(array_map('strval',(array)($record['source_names']??[])))));if(!$sources)$sources=['SEMANTIC_SANDBOX_REVIEW_EVIDENCE'];
        $candidate=['editorial_title'=>(string)($title['title']??''),'primary_longtail_query'=>$query,'target_category_id'=>(int)($target['term_id']??0),'target_category_name'=>(string)($target['name']??''),'proposed_article_type'=>$articleType,'topic_family_key'=>$familyKey,'evidence'=>array_map(static fn($s)=>['source'=>$s],$sources),'editorialization'=>['resolved'=>!empty($title['ok']),'reason'=>!empty($title['ok'])?'PSTE_SANDBOX_DUAL_STRAND_TITLE_PASS':'PSTE_SANDBOX_DUAL_STRAND_TITLE_REVIEW'],'metrics'=>['search_volume'=>$record['search_volume']??null]];
        $cannibalization=PSTE_Cannibalization::decide($candidate,(array)($inventory['items']??[]),(array)($baseline['leaf_categories']??[]));
        $subjectGroup=self::subjectGroup($familyKey,$registry);

        $autoSafe=$familySource==='NORMALIZED_PRIMARY_FAMILY_GATE'&&empty($nearestFailures)&&count($subjectGroup)===1&&!empty($title['ok'])&&!empty($risk['ok'])&&(string)($cannibalization['decision']??'BLOCKED')==='PASS';
        $status=$autoSafe?'AUTO_REENTRY_ELIGIBLE':'PROPOSAL_READY_FOR_REVIEW';$reasons=[$autoSafe?'PSTE_SANDBOX_FULL_NORMAL_PIPELINE_REENTRY_ELIGIBLE':'PSTE_SANDBOX_INTERNAL_PROPOSAL_COMPLETE_NON_APPLYING'];
        if(count($subjectGroup)!==1){$status='MULTIPLE_FAMILIES_REVIEW';$reasons[]='PSTE_SANDBOX_SUBJECT_HEAD_NOT_PORTAL_UNIQUE';}
        if(empty($title['ok'])){$status='REVIEW_REQUIRED';$reasons[]='PSTE_SANDBOX_EDITORIAL_STRAND_NOT_PASS';}
        if(empty($risk['ok'])){$status='REVIEW_REQUIRED';$reasons[]='PSTE_SANDBOX_DOMAIN_RISK_REVIEW_REQUIRED';}
        if((string)($cannibalization['decision']??'BLOCKED')!=='PASS'){$status='REVIEW_REQUIRED';$reasons[]='PSTE_SANDBOX_CANNIBALIZATION_REVIEW_REQUIRED';}
        if($nearestFailures&&$familySource!=='NORMALIZED_PRIMARY_FAMILY_GATE'){$status='MATCHER_REVIEW';$reasons[]='PSTE_SANDBOX_PRIMARY_FAMILY_CONFIRMATION_REQUIRED';}

        $relevanceProof=PSTE_Portal_Relevance_Gate::proofFromExternal($external,$query,$familyName);
        $reviewProposal=['target_keyword'=>(string)($title['target_keyword']??''),'raw_keyword'=>$query,'raw_keyword_sha256'=>hash('sha256',$query),'normalized_topic'=>$normalizedTopic,'family_key'=>$familyKey,'family_name'=>$familyName,'category_id'=>(int)($target['term_id']??0),'category_name'=>(string)($target['name']??''),'category_slug'=>(string)($target['slug']??''),'article_type'=>$articleType,'planning_title'=>(string)($title['title']??''),'title_pipeline'=>$title,'semantic_consensus'=>$semantic,'family_resolution_source'=>$familySource,'historical_article_type'=>(string)($record['article_type']??''),'historical_plan_slot'=>self::existingPlanSlot($sourcePayload),'relevance_proof'=>$relevanceProof];
        $reentryProposal=$autoSafe?['contract'=>'PSTE_SANDBOX_REENTRY_ENVELOPE_V1','status'=>'AUTO_REENTRY_ELIGIBLE','pool_key'=>(string)($record['pool_key']??''),'source_row_sha256'=>(string)($record['source']['row_sha256']??''),'raw_query'=>$query,'raw_query_sha256'=>hash('sha256',$query),'relevance_proof'=>$relevanceProof,'review_proposal'=>$reviewProposal,'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false]:null;
        return ['contract'=>self::CONTRACT,'status'=>$status,'reason_codes'=>array_values(array_unique($reasons)),'relevance_evidence'=>$external,'family_key'=>$familyKey,'family_name'=>$familyName,'family_resolution_source'=>$familySource,'normalized_topic'=>$normalization,'normalized_family_resolution'=>$primaryResolution,'subject_head_family_keys'=>$subjectGroup,'subject_head_portal_unique'=>count($subjectGroup)===1,'semantic_assignment'=>$semantic,'target_category'=>['term_id'=>(int)($target['term_id']??0),'name'=>(string)($target['name']??''),'slug'=>(string)($target['slug']??'')],'article_type'=>$articleType,'title_pipeline'=>$title,'domain_risk'=>$risk,'cannibalization'=>$cannibalization,'review_proposal'=>$reviewProposal,'normal_reentry'=>['status'=>$autoSafe?'ELIGIBLE_NOT_YET_APPLIED':'NOT_EXECUTED','required_sequence'=>['RELEVANCE','NORMALIZATION','FAMILY','CATEGORY','ARTICLE_TYPE','TITLE_DUAL_STRAND','CANNIBALIZATION','NORMAL_PIPELINE','FIVE_FIELD_HANDOFF'],'downstream_five_field_names'=>self::DOWNSTREAM_HANDOFF_FIELDS,'five_field_handoff_created'=>false,'explicit_review_required'=>!$autoSafe,'binding_recheck_required'=>true],'reentry_proposal'=>$reentryProposal,'reentry_gate'=>$autoSafe?'AUTO_SAFE_NORMAL_PIPELINE_REENTRY_ALLOWED':'BLOCKED_UNTIL_REVIEW_AND_NORMAL_PIPELINE','reentry_applied'=>false,'production_handoff_attempted'=>false,'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false];
    }

    /** @return list<string> */
    private static function subjectGroup(string $familyKey,array $registry): array {$identity=(array)($registry['families'][$familyKey]['identity_v2']??[]);$heads=array_fill_keys(array_map('strval',(array)($identity['subject_heads']??[])),true);if(!$heads)return [];$keys=[];foreach((array)($registry['families']??[]) as $key=>$family){$other=(array)($family['identity_v2']['subject_heads']??[]);if(array_intersect(array_keys($heads),array_map('strval',$other)))$keys[]=(string)$key;}sort($keys,SORT_STRING);return array_values(array_unique($keys));}
    private static function existingPlanSlot(array $payload){foreach(['plan_slot','editorial_plan_slot','plan_slot_id'] as $field){$v=$payload[$field]??null;if(is_string($v)&&trim($v)!=='')return trim($v);if(is_int($v)&&$v>0)return $v;}return null;}
    /** @return array<string,mixed> */
    private static function blocked(string $status,array $reasons,array $extra=[]): array {return array_merge(['contract'=>self::CONTRACT,'status'=>$status,'reason_codes'=>array_values(array_unique(array_filter(array_map('strval',$reasons)))),'review_proposal'=>null,'normal_reentry'=>['status'=>'NOT_EXECUTED','downstream_five_field_names'=>self::DOWNSTREAM_HANDOFF_FIELDS,'five_field_handoff_created'=>false,'explicit_review_required'=>true],'reentry_proposal'=>null,'reentry_gate'=>'BLOCKED','reentry_applied'=>false,'production_handoff_attempted'=>false,'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false],$extra);}
}
