# 0.10.7-staging

- Behebt `PSTE_TOPIC_POOL_PAYLOAD_NOT_VALID_JSON` ohne manuellen Datenbankzugriff.
- JSON in den eigenen SEO-Tabellen wird ASCII-sicher gespeichert; Umlaute und Vierbytezeichen bleiben als standardkonforme Unicode-Escapes erhalten.
- Vor jedem kostenpflichtigen Recherchelauf und vor jeder Wiederaufnahme wird der reale JSON-Speicherpfad mit einem sofort entfernten Probeeintrag geprüft.
- Bereits ungültige Themenpool-Payloads werden vor dem Providerlauf ausschließlich aus vorhandenen SEO-Kandidatendaten repariert; stilles Verwerfen als leeres Array ist entfernt.
- Keine Änderung an Beiträgen, Post-Meta, Kategorien, Term-Meta, Frontend, Design oder Textmaschine.
