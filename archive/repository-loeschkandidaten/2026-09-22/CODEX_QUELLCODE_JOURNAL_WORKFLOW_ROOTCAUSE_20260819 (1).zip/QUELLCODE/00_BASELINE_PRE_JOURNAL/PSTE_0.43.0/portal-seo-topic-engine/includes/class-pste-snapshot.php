<?php
if (!defined('ABSPATH')) { return; }

final class PSTE_Snapshot {
    /** @var array<string,mixed>|null */
    private static ?array $portalPageModel=null;
    /**
     * Request-local memoization of the immutable live taxonomy/page snapshot.
     * PSTE never writes WordPress posts, pages or taxonomy terms in these read paths,
     * so repeated structure() calls inside one PHP request must resolve to the exact
     * same snapshot. This removes duplicate full-site scans without changing any
     * persisted state, workflow decision, content or design.
     * @var array<string,mixed>|null
     */
    private static ?array $structureSnapshotCache=null;

    public static function productionMetaKeys(): array {
        $keys=['canonical_article_id'=>'_ppm679_canonical_article_id','plan_slot_sha256'=>'_ppm679_plan_slot_sha256'];
        if(function_exists('apply_filters'))$keys=(array)apply_filters('pste_production_meta_keys',$keys);
        return [
            'canonical_article_id'=>(string)($keys['canonical_article_id']??'_ppm679_canonical_article_id'),
            'plan_slot_sha256'=>(string)($keys['plan_slot_sha256']??'_ppm679_plan_slot_sha256'),
        ];
    }

    /** @return array<string,mixed> */
    public static function inventory(): array {
        $posts=get_posts(['post_type'=>'post','post_status'=>['publish','draft','trash','auto-draft'],'numberposts'=>-1,'orderby'=>'ID','order'=>'ASC','suppress_filters'=>false]);
        $structure=self::structure();$resolved=[];foreach((array)$structure['items'] as $row)$resolved[(int)$row['term_id']]=$row;$items=[];
        foreach((array)$posts as $post){
            if(!is_object($post))continue;$cats=wp_get_post_categories((int)$post->ID,['fields'=>'all']);$descriptors=[];
            foreach((array)$cats as $cat){if(!is_object($cat))continue;$id=(int)($cat->term_id??0);if(isset($resolved[$id]))$descriptors[$id]=$resolved[$id];}
            if(count($descriptors)>1)throw new PSTE_Diagnostic_Exception('PSTE_POST_MULTIPLE_PRODUCTION_CATEGORIES_'.(int)$post->ID,['post_id'=>(int)$post->ID,'category_ids'=>array_keys($descriptors)]);
            $category=$descriptors?reset($descriptors):null;$content=(string)($post->post_content??'');preg_match_all('/<h[23][^>]*>(.*?)<\/h[23]>/isu',$content,$m);$headings=array_map(static fn($v)=>trim(wp_strip_all_tags($v)),$m[1]??[]);
            $items[]=[
                'post_id'=>(int)$post->ID,'title'=>(string)($post->post_title??''),'status'=>(string)($post->post_status??''),
                'category_id'=>$category?(int)$category['term_id']:0,'category_name'=>$category?(string)$category['name']:'','category_slug'=>$category?(string)$category['slug']:'',
                'article_type'=>$category?(string)$category['article_type']:'','topic_family_name'=>$category?(string)$category['topic_family_name']:'',
                'topic_family_key'=>$category?(string)$category['topic_family_key']:'','topic_family_parent_slug'=>$category?(string)$category['product_page_slug']:'',
                'portal_path'=>$category?(string)$category['full_path']:'','canonical_article_id'=>(string)get_post_meta((int)$post->ID,self::productionMetaKeys()['canonical_article_id'],true),
                'plan_slot_sha256'=>(string)get_post_meta((int)$post->ID,self::productionMetaKeys()['plan_slot_sha256'],true),'headings'=>$headings,
                'content_fingerprint'=>hash('sha256',PSTE_Normalizer::text($content)),'source'=>'WORDPRESS_READ_ONLY',
            ];
        }
        return self::bind('PSTE_INVENTORY_SNAPSHOT_V2',$items);
    }

    /** @return array<string,mixed> */
    public static function structure(): array {
        if(is_array(self::$structureSnapshotCache))return self::$structureSnapshotCache;
        $terms=get_categories(['hide_empty'=>false,'orderby'=>'term_id','order'=>'ASC']);$pageModel=self::portalPageModel();$items=[];$ignored=[];$quarantined=[];$termIds=[];
        foreach((array)$terms as $term){
            if(!is_object($term))continue;$id=(int)($term->term_id??0);if($id<=0)throw new PSTE_Diagnostic_Exception('PSTE_TAXONOMY_TERM_ID_INVALID');
            if(isset($termIds[$id]))throw new PSTE_Diagnostic_Exception('PSTE_TAXONOMY_DUPLICATE_TERM_ID_'.$id,['term_id'=>$id]);$termIds[$id]=true;
            $attempt=self::resolveCategory($term,$pageModel);
            if(is_array($attempt['descriptor']??null)){$items[]=$attempt['descriptor'];continue;}
            $row=['term_id'=>$id,'name'=>(string)($term->name??''),'slug'=>(string)($term->slug??''),'wp_parent_id'=>(int)($term->parent??0)];
            if(!empty($attempt['production_like'])){$quarantined[]=array_merge($row,(array)($attempt['diagnostic']??[]));}else{$ignored[]=$row;}
        }
        [$items,$duplicateQuarantine]=self::quarantineDuplicateAssignments($items);$quarantined=array_merge($quarantined,$duplicateQuarantine);
        foreach([$items,$ignored,$quarantined] as &$rows)usort($rows,static fn($a,$b)=>(int)($a['term_id']??0)<=>(int)($b['term_id']??0));unset($rows);
        $portalSeed=self::portalSeedForItems($items,$pageModel);
        $structureSeed=[
            'map_sha256'=>PSTE_Portal_Category_Map::mapSha256(),'pages'=>$portalSeed,
            'production_categories'=>array_map(static fn($r)=>[
                'term_id'=>(int)$r['term_id'],'wp_parent_id'=>(int)$r['wp_parent_id'],'name'=>(string)$r['name'],'slug'=>(string)$r['slug'],
                'article_type'=>(string)$r['article_type'],'product_page_id'=>(int)$r['product_page_id'],'product_page_slug'=>(string)$r['product_page_slug'],'full_path'=>(string)$r['full_path'],'mapping_status'=>(string)$r['mapping_status'],
            ],$items),
            'quarantined_categories'=>$quarantined,
        ];
        $structureHash=hash('sha256',self::canonicalJson($structureSeed));$created=gmdate('c');
        foreach($items as &$item){$item['structure_hash']=$structureHash;unset($item['snapshot_created_at']);}unset($item);
        $validation=self::validateStructure($items,$ignored,$quarantined,$portalSeed,$structureHash);
        $payload=self::bind('PSTE_PORTAL_TAXONOMY_SNAPSHOT_V3',$items);$payload['structure_hash']=$structureHash;$payload['snapshot_created_at']=$created;
        $payload['ignored_categories']=$ignored;$payload['unresolved_production_categories']=$quarantined;$payload['quarantined_categories']=$quarantined;$payload['validation']=$validation;
        self::$structureSnapshotCache=$payload;return self::$structureSnapshotCache;
    }

    /** @return array<string,mixed> */
    public static function editorialPlan(): array {
        $external=apply_filters('pste_read_only_editorial_plan_snapshot',null);if(!is_array($external))$external=get_option(PSTE_OPTION_EDITORIAL_PLAN_IMPORT,null);
        if(!is_array($external))return ['contract'=>'PSTE_EDITORIAL_PLAN_SNAPSHOT_V1','status'=>'NOT_AVAILABLE','sha256'=>'NOT_AVAILABLE','items'=>[]];
        $items=isset($external['items'])&&is_array($external['items'])?$external['items']:$external;return self::bind('PSTE_EDITORIAL_PLAN_SNAPSHOT_V1',$items);
    }

    /** @return array<string,mixed> */
    public static function siteBaseline(): array {
        $structure=self::structure();if(empty($structure['validation']['ok'])){
            $validation=(array)($structure['validation']??[]);$reason=(string)($validation['reason_code']??'PSTE_PORTAL_TAXONOMY_SNAPSHOT_INVALID');
            throw new PSTE_Diagnostic_Exception($reason,$validation);
        }
        $inventory=self::inventory();$plan=self::editorialPlan();$leaf=array_values((array)$structure['items']);$unclassified=array_values(array_filter($leaf,static fn($row)=>trim((string)($row['article_type']??''))===''));
        $counts=['publish'=>0,'draft'=>0,'trash'=>0,'auto-draft'=>0];foreach((array)$inventory['items'] as $item){$status=(string)($item['status']??'');if(array_key_exists($status,$counts))$counts[$status]++;}
        $families=[];foreach($leaf as $cat){$type=(string)($cat['article_type']??'');$key=(string)($cat['topic_family_key']??'');if($type===''||$key==='')continue;if(!isset($families[$key]))$families[$key]=['topic_family_key'=>$key,'topic_family_name'=>(string)($cat['topic_family_name']??$cat['name']??''),'product_page_id'=>(int)($cat['product_page_id']??0),'product_page_slug'=>(string)($cat['product_page_slug']??''),'portal_path'=>(string)($cat['product_page_path']??''),'category_ids'=>[],'article_types'=>[]];$families[$key]['category_ids'][]=(int)$cat['term_id'];$families[$key]['article_types'][$type]=true;}
        foreach($families as &$family){sort($family['category_ids']);$family['article_types']=array_keys($family['article_types']);sort($family['article_types'],SORT_NATURAL|SORT_FLAG_CASE);}unset($family);
        $quarantined=array_values((array)($structure['quarantined_categories']??[]));
        $baseline=[
            'contract'=>'PSTE_SITE_BASELINE_V1','taxonomy_contract'=>'PSTE_PORTAL_TAXONOMY_SNAPSHOT_V3','captured_at_utc'=>gmdate('c'),
            'inventory_sha256'=>$inventory['sha256'],'structure_sha256'=>$structure['sha256'],'structure_hash'=>(string)$structure['structure_hash'],'editorial_plan_sha256'=>$plan['sha256'],
            'post_counts'=>$counts,'category_count'=>count($leaf)+count((array)$structure['ignored_categories'])+count($quarantined),'leaf_category_count'=>count($leaf),'leaf_categories'=>$leaf,
            'protected_category_map_count'=>PSTE_Portal_Category_Map::protectedCount(),'protected_category_map_sha256'=>PSTE_Portal_Category_Map::mapSha256(),
            'ignored_unrelated_category_count'=>count((array)$structure['ignored_categories']),'ignored_unrelated_categories_sha256'=>(string)($structure['validation']['ignored_unrelated_categories_sha256']??''),
            'quarantined_category_count'=>count($quarantined),'quarantined_categories_sha256'=>(string)($structure['validation']['quarantined_categories_sha256']??''),'quarantined_categories_preview'=>array_slice($quarantined,0,25),
            'unclassified_leaf_count'=>count($unclassified),'unclassified_leaf_ids'=>array_values(array_map(static fn($r)=>(int)$r['term_id'],$unclassified)),
            'topic_family_count'=>count($families),'topic_families'=>array_values($families),'taxonomy_validation'=>$structure['validation'],
            'status'=>count($unclassified)===0?'CURRENT':'BLOCKED_UNCLASSIFIED_LEAVES',
        ];
        $baseline['baseline_sha256']=hash('sha256',self::canonicalJson($baseline));return $baseline;
    }

    /** @return array<string,mixed> */
    public static function baselineStatus(array $baseline): array {
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return ['status'=>'NOT_CAPTURED','current'=>false];
        if(($baseline['taxonomy_contract']??'')!=='PSTE_PORTAL_TAXONOMY_SNAPSHOT_V3'||!empty($baseline['unclassified_leaf_count'])||empty($baseline['taxonomy_validation']['ok']))return ['status'=>'BLOCKED','current'=>false,'reason'=>'PSTE_PORTAL_TAXONOMY_V3_INCOMPLETE'];
        try{$inventory=self::inventory();$structure=self::structure();$plan=self::editorialPlan();}catch(Throwable $e){return ['status'=>'BLOCKED','current'=>false,'reason'=>$e->getMessage()];}
        if(empty($structure['validation']['ok']))return ['status'=>'BLOCKED','current'=>false,'reason'=>(string)($structure['validation']['reason_code']??'PSTE_PORTAL_TAXONOMY_V3_INCOMPLETE'),'taxonomy_validation'=>$structure['validation']];
        $inventoryCurrent=hash_equals((string)($baseline['inventory_sha256']??''),(string)($inventory['sha256']??''));
        $structureCurrent=hash_equals((string)($baseline['structure_sha256']??''),(string)($structure['sha256']??''));
        $planCurrent=hash_equals((string)($baseline['editorial_plan_sha256']??''),(string)($plan['sha256']??''));
        $current=$inventoryCurrent&&$structureCurrent&&$planCurrent;
        $nameOnly=['ok'=>false,'rename_count'=>0,'renames'=>[]];
        if(!$current)$nameOnly=self::safeProductPageDisplayNameDrift($baseline,$inventory,$structure,$plan);
        if(!empty($nameOnly['ok'])){
            return [
                'status'=>'CURRENT','current'=>true,'freshness_mode'=>'SAFE_PRODUCT_PAGE_DISPLAY_NAME_ONLY',
                'display_name_only_drift'=>true,'display_name_rename_count'=>(int)($nameOnly['rename_count']??0),'display_name_renames'=>(array)($nameOnly['renames']??[]),
                'inventory_current_sha256'=>$inventory['sha256']??'','structure_current_sha256'=>$structure['sha256']??'','editorial_plan_current_sha256'=>$plan['sha256']??'',
                'inventory_changed'=>!$inventoryCurrent,'structure_changed'=>!$structureCurrent,'editorial_plan_changed'=>!$planCurrent,
                'quarantined_category_count'=>(int)($structure['validation']['quarantined_category_count']??0),'write_attempted'=>false,
            ];
        }
        return [
            'status'=>$current?'CURRENT':'STALE','current'=>$current,'freshness_mode'=>$current?'EXACT':'STALE',
            'display_name_only_drift'=>false,'inventory_current_sha256'=>$inventory['sha256']??'','structure_current_sha256'=>$structure['sha256']??'','editorial_plan_current_sha256'=>$plan['sha256']??'',
            'inventory_changed'=>!$inventoryCurrent,'structure_changed'=>!$structureCurrent,'editorial_plan_changed'=>!$planCurrent,
            'quarantined_category_count'=>(int)($structure['validation']['quarantined_category_count']??0),'write_attempted'=>false,
        ];
    }

    /**
     * Proves that a stale capture differs only by the visible title of protected level-3 product pages.
     * Canonical family identity, term/page IDs, slugs, parent chains, article types, post content/status/meta,
     * ignored/quarantined categories and the editorial plan must remain byte/identity-equivalent.
     * No option, term, post, plan or Sandbox state is written here.
     * @return array<string,mixed>
     */
    private static function safeProductPageDisplayNameDrift(array $baseline,array $inventory,array $structure,array $plan): array {
        $blocked=static fn(string $reason): array=>['ok'=>false,'reason'=>$reason,'rename_count'=>0,'renames'=>[]];
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1'||($baseline['taxonomy_contract']??'')!=='PSTE_PORTAL_TAXONOMY_SNAPSHOT_V3')return $blocked('BASELINE_CONTRACT');
        if(($structure['contract']??'')!=='PSTE_PORTAL_TAXONOMY_SNAPSHOT_V3'||($inventory['contract']??'')!=='PSTE_INVENTORY_SNAPSHOT_V2'||($plan['contract']??'')!=='PSTE_EDITORIAL_PLAN_SNAPSHOT_V1')return $blocked('CURRENT_CONTRACT');
        if(!hash_equals((string)($baseline['editorial_plan_sha256']??''),(string)($plan['sha256']??'')))return $blocked('EDITORIAL_PLAN_CHANGED');
        if((int)($baseline['protected_category_map_count']??-1)!==PSTE_Portal_Category_Map::protectedCount()||!hash_equals((string)($baseline['protected_category_map_sha256']??''),PSTE_Portal_Category_Map::mapSha256()))return $blocked('PROTECTED_MAP_CHANGED');
        $validation=(array)($structure['validation']??[]);
        if((int)($baseline['ignored_unrelated_category_count']??-1)!==(int)($validation['ignored_unrelated_category_count']??-2)||!hash_equals((string)($baseline['ignored_unrelated_categories_sha256']??''),(string)($validation['ignored_unrelated_categories_sha256']??'')))return $blocked('IGNORED_CATEGORY_SET_CHANGED');
        if((int)($baseline['quarantined_category_count']??-1)!==(int)($validation['quarantined_category_count']??-2)||!hash_equals((string)($baseline['quarantined_categories_sha256']??''),(string)($validation['quarantined_categories_sha256']??'')))return $blocked('QUARANTINE_SET_CHANGED');

        $oldRows=array_values(array_filter((array)($baseline['leaf_categories']??[]),'is_array'));$newRows=array_values(array_filter((array)($structure['items']??[]),'is_array'));
        if((int)($baseline['leaf_category_count']??-1)!==count($oldRows)||count($oldRows)!==count($newRows))return $blocked('LEAF_COUNT_CHANGED');
        $oldById=[];$newById=[];foreach($oldRows as $row){$id=(int)($row['term_id']??0);if($id<=0||isset($oldById[$id]))return $blocked('OLD_TERM_ID_INVALID');$oldById[$id]=$row;}foreach($newRows as $row){$id=(int)($row['term_id']??0);if($id<=0||isset($newById[$id]))return $blocked('NEW_TERM_ID_INVALID');$newById[$id]=$row;}ksort($oldById,SORT_NUMERIC);ksort($newById,SORT_NUMERIC);if(array_keys($oldById)!==array_keys($newById))return $blocked('TERM_ID_SET_CHANGED');

        $stableFields=['term_id','parent','parent_id','wp_parent_id','wp_taxonomy_depth','ancestor_ids','ancestor_names','portal_ancestor_page_ids','portal_ancestor_page_slugs','portal_level','portal_hierarchy_source','name','visible_name','slug','product_page_id','product_page_slug','product_page_name','head_intent','article_type','canonical_article_type','topic_family_name','topic_family','topic_family_key','topic_family_parent_slug','is_leaf','node_status','mapping_status','branch_hash'];
        $renames=[];
        foreach($oldById as $id=>$old){
            $new=$newById[$id];
            foreach($stableFields as $field)if(self::canonicalJson($old[$field]??null)!==self::canonicalJson($new[$field]??null))return $blocked('STABLE_FIELD_CHANGED_'.$field);
            $oldNames=array_values(array_map('strval',(array)($old['portal_ancestor_page_names']??[])));$newNames=array_values(array_map('strval',(array)($new['portal_ancestor_page_names']??[])));
            if(count($oldNames)!==count($newNames)||!$oldNames)return $blocked('ANCESTOR_NAME_SHAPE_CHANGED');
            $last=count($oldNames)-1;for($i=0;$i<$last;$i++)if($oldNames[$i]!==$newNames[$i])return $blocked('NON_PRODUCT_PAGE_NAME_CHANGED');
            $productId=(int)($old['product_page_id']??0);$oldNodes=array_values(array_filter((array)($old['portal_path_nodes']??[]),'is_array'));$newNodes=array_values(array_filter((array)($new['portal_path_nodes']??[]),'is_array'));if(count($oldNodes)!==count($newNodes))return $blocked('PORTAL_NODE_COUNT_CHANGED');
            foreach($oldNodes as $i=>$oldNode){$newNode=$newNodes[$i]??[];foreach(['node_type','object_id','parent_object_id','slug'] as $field)if(self::canonicalJson($oldNode[$field]??null)!==self::canonicalJson($newNode[$field]??null))return $blocked('PORTAL_NODE_IDENTITY_CHANGED_'.$field);$allowName=(string)($oldNode['node_type']??'')==='page'&&(int)($oldNode['object_id']??0)===$productId;if(!$allowName&&(string)($oldNode['name']??'')!==(string)($newNode['name']??''))return $blocked('NON_PRODUCT_PORTAL_NODE_NAME_CHANGED');}
            $expectedNewProduct=implode(' > ',$newNames);$expectedNewFull=implode(' > ',array_merge($newNames,[(string)($new['name']??'')]));if((string)($new['product_page_path']??'')!==$expectedNewProduct||(string)($new['full_path']??'')!==$expectedNewFull)return $blocked('CURRENT_PATH_NOT_DERIVED_FROM_NAMES');
            $expectedOldProduct=implode(' > ',$oldNames);$expectedOldFull=implode(' > ',array_merge($oldNames,[(string)($old['name']??'')]));if((string)($old['product_page_path']??'')!==$expectedOldProduct||(string)($old['full_path']??'')!==$expectedOldFull)return $blocked('BASELINE_PATH_NOT_DERIVED_FROM_NAMES');
            if($oldNames[$last]!==$newNames[$last]){
                if(!str_starts_with((string)($old['mapping_status']??''),'PROTECTED_'))return $blocked('DYNAMIC_FAMILY_DISPLAY_NAME_CHANGED');
                $key=(string)$productId;$rename=['product_page_id'=>$productId,'product_page_slug'=>(string)($old['product_page_slug']??''),'canonical_family'=>(string)($old['topic_family_name']??''),'old_visible_name'=>$oldNames[$last],'new_visible_name'=>$newNames[$last]];
                if(isset($renames[$key])&&self::canonicalJson($renames[$key])!==self::canonicalJson($rename))return $blocked('INCONSISTENT_PRODUCT_PAGE_RENAME');$renames[$key]=$rename;
            }
        }
        if(!$renames)return $blocked('NO_PRODUCT_PAGE_DISPLAY_RENAME');

        $compatItems=[];foreach((array)($inventory['items']??[]) as $item){if(!is_array($item))return $blocked('INVENTORY_ITEM_INVALID');$compat=$item;$categoryId=(int)($compat['category_id']??0);if($categoryId>0){if(!isset($oldById[$categoryId])||!isset($newById[$categoryId]))return $blocked('INVENTORY_CATEGORY_SET_CHANGED');$compat['portal_path']=(string)($oldById[$categoryId]['full_path']??'');}$compatItems[]=$compat;}
        $compatInventory=self::bind('PSTE_INVENTORY_SNAPSHOT_V2',$compatItems);if(!hash_equals((string)($baseline['inventory_sha256']??''),(string)($compatInventory['sha256']??'')))return $blocked('INVENTORY_CHANGED_BEYOND_DERIVED_DISPLAY_PATH');
        $renames=array_values($renames);usort($renames,static fn($a,$b)=>(int)$a['product_page_id']<=>(int)$b['product_page_id']);
        return ['ok'=>true,'reason'=>'SAFE_PRODUCT_PAGE_DISPLAY_NAME_ONLY','rename_count'=>count($renames),'renames'=>$renames,'write_attempted'=>false];
    }


    /**
     * Research-only baseline rebase.
     *
     * The portal structure remains the hard identity boundary. Inventory and editorial-plan
     * drift are dynamic read-only context and may be rebound at a safe checkpoint without
     * repeating a provider request. A structural change is fail-closed, except for the
     * already proven protected product-page display-name-only drift.
     *
     * @return array<string,mixed>
     */
    public static function rebaseResearchBaselineIfSafe(array $baseline): array {
        $blocked=static function(string $code,array $status=[]): array {
            return ['ok'=>false,'changed'=>false,'error_code'=>$code,'status'=>$status,'write_attempted'=>false];
        };
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return $blocked('PSTE_SITE_BASELINE_REQUIRED');
        $status=self::baselineStatus($baseline);
        $displayOnly=(string)($status['freshness_mode']??'')==='SAFE_PRODUCT_PAGE_DISPLAY_NAME_ONLY';
        if(!empty($status['current'])&&!$displayOnly)return [
            'ok'=>true,'changed'=>false,'mode'=>'EXACT','baseline'=>$baseline,'status'=>$status,
            'old_baseline_sha256'=>(string)($baseline['baseline_sha256']??''),'new_baseline_sha256'=>(string)($baseline['baseline_sha256']??''),
            'write_attempted'=>false,
        ];
        if(($status['status']??'')==='BLOCKED')return $blocked('PSTE_SITE_STRUCTURE_STALE',$status);

        $structureChanged=!empty($status['structure_changed']);
        if($structureChanged&&!$displayOnly)return $blocked('PSTE_SITE_STRUCTURE_STALE',$status);

        $fresh=self::siteBaseline();
        if(($fresh['status']??'')!=='CURRENT')return $blocked('PSTE_SITE_BASELINE_REBASE_BLOCKED',$status);
        $observedStructure=(string)($status['structure_current_sha256']??'');
        if($observedStructure!==''&&!hash_equals($observedStructure,(string)($fresh['structure_sha256']??'')))return $blocked('PSTE_SITE_STRUCTURE_CHANGED_DURING_REBASE',$status);
        if(!$structureChanged&&!hash_equals((string)($baseline['structure_sha256']??''),(string)($fresh['structure_sha256']??'')))return $blocked('PSTE_SITE_STRUCTURE_CHANGED_DURING_REBASE',$status);

        $mode=$displayOnly?'SAFE_DISPLAY_NAME_AND_DYNAMIC_CONTEXT_REBASE':'SAFE_DYNAMIC_CONTEXT_REBASE';
        update_option(PSTE_OPTION_SITE_BASELINE,$fresh,false);
        $stored=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        if(!is_array($stored)||!hash_equals((string)($fresh['baseline_sha256']??''),(string)($stored['baseline_sha256']??'')))throw new RuntimeException('PSTE_SITE_BASELINE_REBASE_READBACK_MISMATCH');
        return [
            'ok'=>true,'changed'=>true,'mode'=>$mode,'baseline'=>$stored,'status'=>$status,
            'inventory_changed'=>!empty($status['inventory_changed']),'editorial_plan_changed'=>!empty($status['editorial_plan_changed']),
            'structure_changed'=>$structureChanged,'display_name_only_drift'=>$displayOnly,
            'old_baseline_sha256'=>(string)($baseline['baseline_sha256']??''),'new_baseline_sha256'=>(string)($stored['baseline_sha256']??''),
            'write_attempted'=>true,
        ];
    }

    public static function assertUnchanged(array $before,array $after): void {if(!hash_equals((string)($before['sha256']??''),(string)($after['sha256']??'')))throw new PSTE_Diagnostic_Exception('PSTE_SNAPSHOT_STALE_OR_CHANGED');}

    /** @return array{descriptor:?array,production_like:bool,diagnostic:array<string,mixed>} */
    private static function resolveCategory(object $term,array $pageModel): array {
        $id=(int)($term->term_id??0);$name=trim((string)($term->name??''));$slug=trim((string)($term->slug??''));
        if($id<=0||$name===''||$slug==='')return ['descriptor'=>null,'production_like'=>false,'diagnostic'=>['reason_code'=>'PSTE_CATEGORY_IDENTITY_INCOMPLETE']];
        $protected=PSTE_Portal_Category_Map::match($term);
        if(is_array($protected)){
            $page=self::resolveProtectedPage($protected,$pageModel);
            if(is_object($page))return ['descriptor'=>self::descriptor($term,$page,(string)$protected['article_type'],(string)$protected['product_page_name'],(string)($protected['match_mode']??'PROTECTED_MAP')),'production_like'=>true,'diagnostic'=>[]];
            return ['descriptor'=>null,'production_like'=>true,'diagnostic'=>['reason_code'=>'PSTE_PROTECTED_PRODUCT_PAGE_UNRESOLVED','article_type'=>(string)$protected['article_type'],'expected_product_page_slug'=>(string)$protected['product_page_slug'],'mapping_status'=>(string)($protected['match_mode']??'PROTECTED_MAP')]];
        }
        $protectedBySlug=PSTE_Portal_Category_Map::exactSlugEntry($slug);
        if(is_array($protectedBySlug)){
            $accepted=array_values(array_filter(array_merge([(string)($protectedBySlug['category_name']??'')],array_map('strval',(array)($protectedBySlug['accepted_category_names']??[])))));
            return ['descriptor'=>null,'production_like'=>true,'diagnostic'=>[
                'reason_code'=>'PSTE_PROTECTED_CATEGORY_NAME_NOT_ACCEPTED','article_type'=>PSTE_Normalizer::categoryArticleType($name),
                'expected_article_type'=>(string)($protectedBySlug['article_type']??''),'expected_product_page_slug'=>(string)($protectedBySlug['product_page_slug']??''),
                'accepted_category_names'=>$accepted,'mapping_status'=>'PROTECTED_EXACT_SLUG_NAME_GUARD',
            ]];
        }
        $dynamic=self::dynamicResolution($term,$pageModel);
        if(is_array($dynamic['page']??null)||is_object($dynamic['page']??null)){
            /** @var object $page */$page=$dynamic['page'];
            return ['descriptor'=>self::descriptor($term,$page,(string)$dynamic['article_type'],(string)$dynamic['family'],'DYNAMIC_UNIQUE_PAGE_AND_NAME'),'production_like'=>true,'diagnostic'=>[]];
        }
        $explicit=self::explicitType($term);$knownType=PSTE_Normalizer::categoryArticleType($name);$productionLike=$explicit!==''||$knownType!==''||!empty($dynamic['production_like'])||PSTE_Portal_Category_Map::isProtectedSlug($slug);
        return ['descriptor'=>null,'production_like'=>$productionLike,'diagnostic'=>array_merge(['reason_code'=>(string)($dynamic['reason_code']??'PSTE_CATEGORY_NOT_MAPPED'),'article_type'=>$explicit!==''?$explicit:$knownType],(array)($dynamic['diagnostic']??[]))];
    }

    /** @return object|null */
    private static function resolveProtectedPage(array $entry,array $pageModel): ?object {
        $slug=trim((string)($entry['product_page_slug']??''));$pages=array_values(array_filter((array)($pageModel['by_slug'][$slug]??[]),'is_object'));
        if(count($pages)===1)return $pages[0];
        if(count($pages)>1){$matched=[];foreach($pages as $page){try{$path=self::pagePath((int)$page->ID,(array)$pageModel['by_id']);}catch(Throwable $e){continue;}$slugs=array_column($path,'slug');if(in_array((string)($entry['main_hub_slug']??''),$slugs,true)&&in_array((string)($entry['section_hub_slug']??''),$slugs,true))$matched[]=$page;}if(count($matched)===1)return $matched[0];return null;}
        $titleKey=self::norm((string)($entry['product_page_name']??''));$fallback=array_values(array_filter((array)($pageModel['by_title'][$titleKey]??[]),'is_object'));
        if(count($fallback)===1)return $fallback[0];
        if(count($fallback)>1){$matched=[];foreach($fallback as $page){try{$path=self::pagePath((int)$page->ID,(array)$pageModel['by_id']);}catch(Throwable $e){continue;}$slugs=array_column($path,'slug');if(in_array((string)($entry['main_hub_slug']??''),$slugs,true)&&in_array((string)($entry['section_hub_slug']??''),$slugs,true))$matched[]=$page;}if(count($matched)===1)return $matched[0];}
        return null;
    }

    /** @return array<string,mixed> */
    private static function dynamicResolution(object $term,array $pageModel): array {
        $name=trim((string)($term->name??''));$slug=trim((string)($term->slug??''));$explicit=self::explicitType($term);$candidates=[];$sawShape=false;
        foreach((array)$pageModel['by_title'] as $pages){
            foreach((array)$pages as $page){
                if(!is_object($page))continue;$family=trim((string)($page->post_title??''));if($family==='')continue;
                $type=self::typeAroundFamily($name,$family,$explicit);if($type==='')continue;$sawShape=true;
                try{$path=self::pagePath((int)$page->ID,(array)$pageModel['by_id']);}catch(Throwable $e){continue;}
                if(count($path)!==3)continue;
                $score=self::dynamicScore($slug,(string)($page->post_name??''),$family,$type,count((array)($pageModel['by_title'][self::norm($family)]??[]))===1);
                if($score<70)continue;$candidates[]=['score'=>$score,'page'=>$page,'family'=>$family,'article_type'=>$type,'path'=>$path];
            }
        }
        usort($candidates,static fn($a,$b)=>(int)$b['score']<=>(int)$a['score'] ?: (int)$a['page']->ID<=>(int)$b['page']->ID);
        if(!$candidates)return ['page'=>null,'production_like'=>$sawShape,'reason_code'=>$sawShape?'PSTE_DYNAMIC_PRODUCT_PAGE_NOT_UNIQUELY_RESOLVED':'PSTE_CATEGORY_NOT_PRODUCTION_SHAPED'];
        $top=(int)$candidates[0]['score'];$same=array_values(array_filter($candidates,static fn($r)=>(int)$r['score']===$top));
        if(count($same)!==1)return ['page'=>null,'production_like'=>true,'reason_code'=>'PSTE_DYNAMIC_PRODUCT_PAGE_AMBIGUOUS','diagnostic'=>['candidate_count'=>count($same),'candidate_page_ids'=>array_map(static fn($r)=>(int)$r['page']->ID,array_slice($same,0,10))]];
        return $candidates[0]+['production_like'=>true,'reason_code'=>''];
    }

    private static function dynamicScore(string $categorySlug,string $pageSlug,string $family,string $type,bool $uniqueTitle): int {
        $typeSlug=self::slugify($type);if($categorySlug===$pageSlug.'-'.$typeSlug||$categorySlug===$typeSlug.'-'.$pageSlug)return 120;
        if(str_contains($categorySlug,$pageSlug))return 105;
        $actual=self::slugTokens($categorySlug);$page=self::slugTokens($pageSlug);$familyTokens=self::slugTokens($family);$typeTokens=self::slugTokens($type);
        $withoutType=array_values(array_diff($actual,$typeTokens));$familyCoverage=$familyTokens?count(array_intersect($withoutType,$familyTokens))/count($familyTokens):0;$pageCoverage=$page?count(array_intersect($withoutType,$page))/count($page):0;
        $score=(int)round(max($familyCoverage,$pageCoverage)*90);if($uniqueTitle)$score+=15;return min(119,$score);
    }

    private static function typeAroundFamily(string $name,string $family,string $explicit=''): string {
        $name=trim($name);$family=trim($family);if($name===''||$family==='')return '';
        if($explicit!==''){
            if(preg_match('/^'.preg_quote($explicit,'/').'\s+'.preg_quote($family,'/').'$/iu',$name)||preg_match('/^'.preg_quote($family,'/').'\s+'.preg_quote($explicit,'/').'$/iu',$name))return $explicit;
        }
        if(preg_match('/^(.+?)\s+'.preg_quote($family,'/').'$/iu',$name,$m))return trim((string)$m[1]);
        if(preg_match('/^'.preg_quote($family,'/').'\s+(.+)$/iu',$name,$m))return trim((string)$m[1]);
        return '';
    }

    /** @return array<string,mixed> */
    private static function descriptor(object $term,object $page,string $type,string $family,string $mappingStatus): array {
        $id=(int)$term->term_id;$name=trim((string)$term->name);$slug=trim((string)$term->slug);$wpParent=(int)($term->parent??0);$pagePath=self::pagePath((int)$page->ID,self::portalPageModel()['by_id']);$portalNodes=[];$ancestorPageIds=[];$ancestorPageNames=[];$ancestorPageSlugs=[];
        foreach($pagePath as $row){$portalNodes[]=['node_type'=>'page','object_id'=>(int)$row['id'],'parent_object_id'=>(int)$row['parent'],'name'=>(string)$row['name'],'slug'=>(string)$row['slug']];$ancestorPageIds[]=(int)$row['id'];$ancestorPageNames[]=(string)$row['name'];$ancestorPageSlugs[]=(string)$row['slug'];}
        $portalNodes[]=['node_type'=>'wordpress_category','object_id'=>$id,'parent_object_id'=>(int)$page->ID,'name'=>$name,'slug'=>$slug];$fullPath=implode(' > ',array_merge($ancestorPageNames,[$name]));$productPath=implode(' > ',$ancestorPageNames);$pageSlug=(string)$page->post_name;
        $familyKey=hash('sha256',PSTE_Normalizer::text($pageSlug).'|'.PSTE_Normalizer::text($family));$branchHash=hash('sha256',implode('>',array_map('strval',$ancestorPageIds)).'|term:'.$id.'|'.$slug.'|'.$type);
        return [
            'term_id'=>$id,'parent'=>$wpParent,'parent_id'=>$wpParent,'wp_parent_id'=>$wpParent,'wp_taxonomy_depth'=>self::termDepth($term),
            'ancestor_ids'=>[],'ancestor_names'=>[],'portal_ancestor_page_ids'=>$ancestorPageIds,'portal_ancestor_page_names'=>$ancestorPageNames,'portal_ancestor_page_slugs'=>$ancestorPageSlugs,
            'portal_path_nodes'=>$portalNodes,'portal_level'=>count($portalNodes),'portal_hierarchy_source'=>'WORDPRESS_PAGE_TREE_PLUS_FLAT_CATEGORY_READ_ONLY',
            'name'=>$name,'visible_name'=>$name,'slug'=>$slug,'full_path'=>$fullPath,'product_page_path'=>$productPath,
            'product_page_id'=>(int)$page->ID,'product_page_slug'=>$pageSlug,'product_page_name'=>$family,
            'head_intent'=>PSTE_Normalizer::categoryHead($name),'article_type'=>$type,'canonical_article_type'=>$type,
            'topic_family_name'=>$family,'topic_family'=>$family,'topic_family_key'=>$familyKey,'topic_family_parent_slug'=>$pageSlug,
            'is_leaf'=>true,'node_status'=>'PRODUCTION_LEAF','mapping_status'=>$mappingStatus,'branch_hash'=>$branchHash,'structure_hash'=>'',
        ];
    }

    /** @return array{0:list<array<string,mixed>>,1:list<array<string,mixed>>} */
    private static function quarantineDuplicateAssignments(array $items): array {
        $groups=[];foreach($items as $i=>$row){$key=(string)$row['topic_family_key'].'|'.PSTE_Article_Type_Registry::canonicalType((string)$row['article_type']);$groups[$key][]=$i;}
        $drop=[];$quarantine=[];
        foreach($groups as $key=>$indexes){
            if(count($indexes)<2)continue;
            $priority=static function(array $row): int {
                return match((string)($row['mapping_status']??'')){
                    'PROTECTED_EXACT_SLUG_AND_NAME'=>500,
                    'PROTECTED_EXACT_SLUG_SEMANTIC_NAME'=>450,
                    'PROTECTED_NAME_WITH_UNIQUE_SLUG_AFFINITY'=>400,
                    'PROTECTED_UNIQUE_NAME_SLUG_DRIFT'=>350,
                    'DYNAMIC_UNIQUE_PAGE_AND_NAME'=>200,
                    default=>100,
                };
            };
            $ranked=$indexes;usort($ranked,static fn($a,$b)=>$priority($items[$b])<=>$priority($items[$a]) ?: (int)$items[$a]['term_id']<=>(int)$items[$b]['term_id']);
            $keep=$ranked[0];$topPriority=$priority($items[$keep]);
            if(count($ranked)>1&&$priority($items[$ranked[1]])===$topPriority&&$topPriority<500)$keep=null;
            foreach($indexes as $i){
                if($keep!==null&&$i===$keep)continue;
                $row=$items[$i];$drop[$i]=true;$quarantine[]=['term_id'=>(int)$row['term_id'],'name'=>(string)$row['name'],'slug'=>(string)$row['slug'],'wp_parent_id'=>(int)$row['wp_parent_id'],'article_type'=>(string)$row['article_type'],'mapping_status'=>(string)($row['mapping_status']??''),'reason_code'=>'PSTE_PORTAL_CATEGORY_DUPLICATE_FAMILY_TYPE_QUARANTINED','duplicate_key'=>$key,'kept_term_id'=>$keep!==null?(int)$items[$keep]['term_id']:0];
            }
        }
        $kept=[];foreach($items as $i=>$row)if(!isset($drop[$i]))$kept[]=$row;return [$kept,$quarantine];
    }

    /** @return array<string,mixed> */
    private static function portalPageModel(): array {
        if(is_array(self::$portalPageModel))return self::$portalPageModel;
        $posts=get_posts(['post_type'=>'page','post_status'=>['publish','draft','pending','private','future'],'numberposts'=>-1,'orderby'=>'ID','order'=>'ASC','suppress_filters'=>false]);$byId=[];$bySlug=[];$byTitle=[];
        foreach((array)$posts as $post){if(!is_object($post))continue;$id=(int)($post->ID??0);$slug=trim((string)($post->post_name??''));$name=trim((string)($post->post_title??''));if($id<=0||$slug===''||$name==='')continue;if(isset($byId[$id]))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_PAGE_DUPLICATE_ID_'.$id,['page_id'=>$id]);$byId[$id]=$post;$bySlug[$slug][]=$post;$byTitle[self::norm($name)][]=$post;}
        self::$portalPageModel=['by_id'=>$byId,'by_slug'=>$bySlug,'by_title'=>$byTitle];return self::$portalPageModel;
    }

    /** @return list<array{id:int,parent:int,name:string,slug:string}> */
    private static function pagePath(int $id,array $byId): array {$path=[];$seen=[];$cursor=$id;while($cursor>0){if(isset($seen[$cursor]))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_PAGE_CYCLE_'.$id,['page_id'=>$id,'cycle_at'=>$cursor]);$seen[$cursor]=true;if(!isset($byId[$cursor]))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_PAGE_PARENT_MISSING_'.$id,['page_id'=>$id,'missing_parent_id'=>$cursor]);$page=$byId[$cursor];array_unshift($path,['id'=>$cursor,'parent'=>(int)($page->post_parent??0),'name'=>(string)($page->post_title??''),'slug'=>(string)($page->post_name??'')]);$cursor=(int)($page->post_parent??0);}return $path;}

    /** @return list<array{page_id:int,parent_page_id:int,name:string,slug:string}> */
    private static function portalSeedForItems(array $items,array $pageModel): array {
        $ids=[];foreach($items as $row)foreach((array)($row['portal_ancestor_page_ids']??[]) as $id)$ids[(int)$id]=true;$seed=[];
        foreach(array_keys($ids) as $id){$post=$pageModel['by_id'][$id]??null;if(!is_object($post))throw new PSTE_Diagnostic_Exception('PSTE_PORTAL_PAGE_PARENT_MISSING_'.$id,['page_id'=>$id]);$seed[]=['page_id'=>$id,'parent_page_id'=>(int)($post->post_parent??0),'name'=>(string)($post->post_title??''),'slug'=>(string)($post->post_name??'')];}
        usort($seed,static fn($a,$b)=>(int)$a['page_id']<=>(int)$b['page_id']);return $seed;
    }

    /** @return array<string,mixed> */
    private static function validateStructure(array $items,array $ignored,array $quarantined,array $portalSeed,string $structureHash): array {
        if(!$items)return ['ok'=>false,'reason_code'=>'PSTE_PORTAL_PRODUCTION_CATEGORY_SET_EMPTY','quarantined_category_count'=>count($quarantined),'first_quarantined'=>$quarantined[0]??null,'write_attempted'=>false];
        $bySlug=[];$byFamilyType=[];$ids=[];
        foreach($items as $row){$id=(int)$row['term_id'];$slug=(string)$row['slug'];$type=(string)$row['article_type'];$familyKey=(string)$row['topic_family_key'];if(isset($ids[$id]))return ['ok'=>false,'reason_code'=>'PSTE_PORTAL_CATEGORY_DUPLICATE_TERM_ID','term_id'=>$id,'write_attempted'=>false];if(isset($bySlug[$slug]))return ['ok'=>false,'reason_code'=>'PSTE_PORTAL_CATEGORY_DUPLICATE_SLUG','slug'=>$slug,'write_attempted'=>false];$tuple=$familyKey.'|'.PSTE_Article_Type_Registry::canonicalType($type);if(isset($byFamilyType[$tuple]))return ['ok'=>false,'reason_code'=>'PSTE_PORTAL_CATEGORY_DUPLICATE_FAMILY_TYPE_INTERNAL','slug'=>$slug,'other_slug'=>$byFamilyType[$tuple],'write_attempted'=>false];if((string)($row['structure_hash']??'')!==$structureHash)return ['ok'=>false,'reason_code'=>'PSTE_PORTAL_STRUCTURE_HASH_MISMATCH','term_id'=>$id,'write_attempted'=>false];$ids[$id]=true;$bySlug[$slug]=true;$byFamilyType[$tuple]=$slug;}
        $qCount=count($quarantined);return [
            'ok'=>true,'status'=>$qCount>0?'PSTE_PORTAL_TAXONOMY_SNAPSHOT_V3_PASS_WITH_QUARANTINE':'PSTE_PORTAL_TAXONOMY_SNAPSHOT_V3_PASS',
            'production_category_count'=>count($items),'portal_page_count'=>count($portalSeed),'protected_category_map_count'=>PSTE_Portal_Category_Map::protectedCount(),'protected_category_map_sha256'=>PSTE_Portal_Category_Map::mapSha256(),
            'ignored_unrelated_category_count'=>count($ignored),'ignored_unrelated_categories_sha256'=>hash('sha256',self::canonicalJson($ignored)),
            'quarantined_category_count'=>$qCount,'quarantined_categories_sha256'=>hash('sha256',self::canonicalJson($quarantined)),'first_quarantined'=>$quarantined[0]??null,'quarantine_is_per_category'=>true,
            'flat_wordpress_categories_supported'=>true,'portal_and_wordpress_hierarchies_separate'=>true,'write_attempted'=>false,
        ];
    }

    private static function explicitType(object $category): string {$id=(int)($category->term_id??0);return $id>0&&function_exists('get_term_meta')?trim((string)get_term_meta($id,'pste_article_type',true)):'';}
    private static function slugify(string $value): string {if(function_exists('sanitize_title'))return (string)sanitize_title($value);$value=strtr(trim($value),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$value=strtolower($value);return trim((string)preg_replace('/[^a-z0-9]+/','-',$value),'-');}
    /** @return list<string> */ private static function slugTokens(string $value): array {$slug=self::slugify($value);return $slug===''?[]:array_values(array_filter(explode('-',$slug)));}
    private static function norm(string $value): string {$value=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($value):strip_tags($value),ENT_QUOTES|ENT_HTML5,'UTF-8');$value=strtr(trim($value),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$value=function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);return trim((string)preg_replace('/[^a-z0-9]+/u',' ',$value));}
    private static function termDepth(object $term): int {$depth=1;$parent=(int)($term->parent??0);$guard=0;while($parent>0&&$guard++<64){if(!function_exists('get_category'))break;$p=get_category($parent);if(!is_object($p)||function_exists('is_wp_error')&&is_wp_error($p))break;$depth++;$parent=(int)($p->parent??0);}return $depth;}
    private static function canonicalJson($value): string {return self::json(self::canonicalize($value));}
    private static function canonicalize($value){if(!is_array($value))return $value;if($value===[])return [];$isList=array_keys($value)===range(0,count($value)-1);if($isList)return array_map([self::class,'canonicalize'],$value);ksort($value,SORT_STRING);foreach($value as $key=>$item)$value[$key]=self::canonicalize($item);return $value;}
    private static function bind(string $contract,array $items): array {$payload=['contract'=>$contract,'items'=>$items];$payload['sha256']=hash('sha256',self::canonicalJson($payload));return $payload;}
    private static function json($value): string {$json=function_exists('wp_json_encode')?wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($json))throw new PSTE_Diagnostic_Exception('PSTE_SNAPSHOT_JSON_FAILED');return $json;}
}
