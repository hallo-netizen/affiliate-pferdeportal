<?php
if (!defined('ABSPATH')) { return; }

/** Query-to-family membership gate. It uses the raw query, never an auto-prefixed title. */
final class PSTE_Family_Membership {
    /** @return array<string,mixed> */
    public static function evaluate(string $query,array $registry,string $familyKey): array {
        $family=(array)($registry['families'][$familyKey]??[]);
        $identityV2=(array)($family['identity_v2']??[]);
        if(($identityV2['contract']??'')===PSTE_Family_Identity_V2::CONTRACT){
            $result=PSTE_Family_Identity_V2::evaluate($query,$identityV2);
            return [
                'contract'=>'PSTE_FAMILY_MEMBERSHIP_GATE_V2',
                'ok'=>($result['status']??'')==='MATCH',
                'status'=>($result['status']??'')==='MATCH'?'FAMILY_PASS':'FAMILY_REVIEW',
                'reason_codes'=>array_values((array)($result['reason_codes']??[])),
                'query_sha256'=>(string)($result['query_sha256']??''),
                'topic_family_key'=>$familyKey,
                'topic_family_name'=>(string)($family['topic_family_name']??''),
                'identity_key_v2'=>(string)($result['identity_key_v2']??''),
                'specificity_score'=>(int)($result['specificity_score']??0),
                'v2_status'=>(string)($result['status']??'NO_MATCH'),
                'diagnostics'=>(array)($result['details']??[]),
                'write_attempted'=>false,
            ];
        }
        return self::evaluateLegacy($query,$registry,$familyKey);
    }

    /** @return array<string,mixed> */
    private static function evaluateLegacy(string $query,array $registry,string $familyKey): array {
        $family=(array)($registry['families'][$familyKey]??[]);$name=trim((string)($family['topic_family_name']??''));
        if(trim($query)==='')return self::blocked('PSTE_FAMILY_MEMBERSHIP_QUERY_MISSING',$query,$name,[],[]);
        if(!$family||$name==='')return self::blocked('PSTE_FAMILY_MEMBERSHIP_FAMILY_MISSING',$query,$name,[],[]);
        $identity=(array)($family['identity']??[]);$anchors=array_values((array)($identity['anchor_tokens']??[]));
        if(!$anchors)$anchors=self::anchors($family);
        $queryTokens=PSTE_Token_Equivalence::tokens($query);$anchorMatches=array_values(array_intersect($anchors,$queryTokens));
        $reasons=[];
        if(!$anchorMatches)$reasons[]='PSTE_FAMILY_MEMBERSHIP_CORE_TOKEN_MISSING';
        $qualifiers=array_values((array)($identity['qualifier_tokens']??[]));$qualifierMatched=true;
        if(!empty($identity['qualifier_required'])){$qualifierMatched=(bool)array_intersect($qualifiers,$queryTokens);if(!$qualifierMatched)$reasons[]='PSTE_FAMILY_MEMBERSHIP_QUALIFIER_MISSING';}
        $modifier=(string)($identity['numeric_modifier']??self::numericModifier($name));
        $modifierOk=$modifier===''||self::containsModifier($query,$modifier);
        if(!$modifierOk)$reasons[]='PSTE_FAMILY_MEMBERSHIP_DISCRIMINATOR_MISSING';
        return ['contract'=>'PSTE_FAMILY_MEMBERSHIP_GATE_V1_LEGACY_FALLBACK','ok'=>!$reasons,'status'=>$reasons?'FAMILY_REVIEW':'FAMILY_PASS','reason_codes'=>$reasons,'query_sha256'=>hash('sha256',$query),'topic_family_key'=>$familyKey,'topic_family_name'=>$name,'anchor_tokens'=>$anchors,'matched_anchor_tokens'=>$anchorMatches,'qualifier_tokens'=>$qualifiers,'qualifier_matched'=>$qualifierMatched,'numeric_modifier'=>$modifier,'numeric_modifier_matched'=>$modifierOk,'write_attempted'=>false];
    }
    /** @return list<string> */
    private static function anchors(array $family): array {
        $values=[(string)($family['topic_family_name']??'')];
        foreach((array)($family['by_type']??[]) as $row){$values[]=(string)($row['head_intent']??'');$values[]=(string)($row['product_page_name']??'');}
        $tokens=[];foreach($values as $value)foreach(PSTE_Token_Equivalence::tokens($value) as $token)if(!preg_match('/^\d/',$token))$tokens[$token]=true;
        $tokens=array_keys($tokens);if(!$tokens)return [];$max=max(array_map('strlen',$tokens));
        return array_values(array_filter($tokens,static fn($t)=>strlen($t)===$max));
    }
    private static function numericModifier(string $name): string {
        if(preg_match('/\b(\d+(?:[,.]\d+)?)\s*er\b/iu',$name,$m))return str_replace(',','.',$m[1]);
        return '';
    }
    private static function containsModifier(string $query,string $modifier): bool {
        $q=PSTE_Normalizer::exactTopicIdentityText($query);$m=str_replace('.', ' ', $modifier);$compact=str_replace(' ','',$m);
        return (bool)preg_match('/(?:^|\s)'.preg_quote($m,'/').'(?:\s*er)?(?:\s|$)/u',$q)||(bool)preg_match('/(?:^|\s)'.preg_quote($compact,'/').'er(?:\s|$)/u',$q);
    }
    /** @return array<string,mixed> */
    private static function blocked(string $reason,string $query,string $name,array $anchors,array $matches): array {return ['contract'=>'PSTE_FAMILY_MEMBERSHIP_GATE_V1','ok'=>false,'status'=>'FAMILY_REVIEW','reason_codes'=>[$reason],'query_sha256'=>$query!==''?hash('sha256',$query):'','topic_family_key'=>'','topic_family_name'=>$name,'anchor_tokens'=>$anchors,'matched_anchor_tokens'=>$matches,'numeric_modifier'=>'','numeric_modifier_matched'=>false,'write_attempted'=>false];}
}
