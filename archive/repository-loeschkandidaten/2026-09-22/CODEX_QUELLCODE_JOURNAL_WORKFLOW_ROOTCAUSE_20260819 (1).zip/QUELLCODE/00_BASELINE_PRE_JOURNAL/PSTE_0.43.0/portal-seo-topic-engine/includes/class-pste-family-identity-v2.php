<?php
if (!defined('ABSPATH')) { return; }

/**
 * Versioned, family-only identity and context matcher.
 *
 * This class deliberately does not call or modify PSTE_Normalizer::text().
 * Legacy topic/family hashes and every downstream text/HTML path stay intact.
 */
final class PSTE_Family_Identity_V2 {
    public const CONTRACT='PSTE_FAMILY_IDENTITY_V2';
    public const REGISTRY_CONTRACT='PSTE_FAMILY_IDENTITY_REGISTRY_V2';
    public const MATCH_CONTRACT='PSTE_FAMILY_MEMBERSHIP_GATE_V2';

    private const GENERIC_PORTAL_WORDS=['atelier','portal','magazin','journal','blog','online','website','webseite','ratgeber','wissen','welt','zentrum','zentrale','markt','shop','deutschland'];
    private const RELATION_WORDS=['fuer','für','im','in','am','an','auf','mit','inklusive','ohne','neben','versus','vs','gegen','aus','geeignet'];
    private const STOPWORDS=['der','die','das','den','dem','des','ein','eine','einer','einem','einen','und','oder','von','bei','beim','zum','zur','ist','sind','richtig','welche','welcher','welches','wie','was'];
    private const NEGATION_WORDS=['nicht','kein','keine','keinen','ohne'];
    private const NUMBER_WORDS=['null'=>'0','eins'=>'1','ein'=>'1','eine'=>'1','einen'=>'1','zwei'=>'2','drei'=>'3','vier'=>'4','fuenf'=>'5','fünf'=>'5','sechs'=>'6','sieben'=>'7','acht'=>'8','neun'=>'9','zehn'=>'10'];
    private static ?array $overrides=null;

    /** @return list<string> */
    public static function tokens(string $value,bool $keepRelations=false): array {
        $value=self::plain($value);
        $value=strtr($value,['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss','–'=>' ','—'=>' ','‑'=>' ','‐'=>' ','-'=>' ']);
        $value=function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);
        $value=(string)preg_replace('/(?<=\d),(?=\d)/u','.',$value);
        $value=(string)preg_replace('/[^a-z0-9.\s]+/u',' ',$value);
        $raw=preg_split('/\s+/',trim($value))?:[];$out=[];
        foreach($raw as $token){
            if($token==='')continue;
            if(isset(self::NUMBER_WORDS[$token]))$token=self::NUMBER_WORDS[$token];
            $relation=in_array($token,self::RELATION_WORDS,true)||in_array($token,self::NEGATION_WORDS,true);
            if(!$keepRelations&&!$relation&&in_array($token,self::STOPWORDS,true))continue;
            if(!$keepRelations&&$relation)continue;
            if(!$relation)$token=self::stem($token);
            if($token==='')continue;
            $out[]=$token;
        }
        return array_values($out);
    }

    public static function normalizedPhrase(string $value,bool $keepRelations=false): string {return implode(' ',self::tokens($value,$keepRelations));}

    /** @return array<string,mixed> */
    public static function buildIdentity(array $family,array $baseline=[]): array {
        $name=trim((string)($family['topic_family_name']??''));
        if($name==='')throw new RuntimeException('PSTE_FAMILY_IDENTITY_V2_NAME_MISSING');
        $override=self::overrideFor($name);
        $path=self::pathNames($family);
        $portalContext=self::portalContextTokens($path,$baseline);
        $generated=self::generateIdentity($name,$family,$path,$portalContext);
        // Generated values already passed through the V2 tokenizer exactly once. Only
        // explicit registry overrides are normalized here. Re-tokenizing generated
        // stems would strip a second suffix and make a family fail against its own label.
        $subjectHeads=array_key_exists('subject_heads',$override)?self::normalizeGroups((array)$override['subject_heads'],false):self::preparedFlat((array)($generated['subject_heads']??[]));
        $contextGroups=array_key_exists('context_groups',$override)?self::normalizeNestedGroups((array)$override['context_groups']):self::preparedNested((array)($generated['context_groups']??[]));
        $requiredGroups=array_key_exists('required_discriminator_groups',$override)?self::normalizeNestedGroups((array)$override['required_discriminator_groups']):self::preparedNested((array)($generated['required_discriminator_groups']??[]));
        $optionalGroups=array_key_exists('optional_discriminator_groups',$override)?self::normalizeNestedGroups((array)$override['optional_discriminator_groups']):self::preparedNested((array)($generated['optional_discriminator_groups']??[]));
        $excludedGroups=array_key_exists('excluded_concept_groups',$override)?self::normalizeNestedGroups((array)$override['excluded_concept_groups']):self::preparedNested((array)($generated['excluded_concept_groups']??[]));
        $alternativeSets=array_key_exists('alternative_required_sets',$override)?self::normalizeNestedGroups((array)$override['alternative_required_sets']):self::preparedNested((array)($generated['alternative_required_sets']??[]));
        $numericDefs=array_key_exists('numeric_and_unit_discriminators',$override)?self::normalizeNumeric((array)$override['numeric_and_unit_discriminators']):(array)($generated['numeric_and_unit_discriminators']??[]);
        $excludedPhrases=array_key_exists('excluded_phrases',$override)?array_values(array_unique(array_filter(array_map(static fn($v)=>self::normalizedPhrase((string)$v,true),(array)$override['excluded_phrases'])))):(array)($generated['excluded_phrases']??[]);
        $forbiddenRelations=array_key_exists('forbidden_relation_tokens',$override)?array_values(array_unique(array_filter(array_map(static fn($v)=>self::stem(self::asciiLower((string)$v)),(array)$override['forbidden_relation_tokens'])))):(array)($generated['forbidden_relation_tokens']??[]);

        $identity=[
            'contract'=>self::CONTRACT,
            'identity_version'=>2,
            'topic_family_name'=>$name,
            'legacy_topic_family_key'=>(string)($family['topic_family_key']??''),
            'subject_heads'=>$subjectHeads,
            'context_groups'=>$contextGroups,
            'context_policy'=>self::enum((string)($override['context_policy']??$generated['context_policy']??'NOT_REQUIRED'),['REQUIRED','IMPLICIT_ALLOWED','NOT_REQUIRED'],'NOT_REQUIRED'),
            'required_discriminator_groups'=>$requiredGroups,
            'optional_discriminator_groups'=>$optionalGroups,
            'excluded_concept_groups'=>$excludedGroups,
            'alternative_required_sets'=>$alternativeSets,
            'numeric_and_unit_discriminators'=>$numericDefs,
            'excluded_phrases'=>$excludedPhrases,
            'forbidden_relation_tokens'=>$forbiddenRelations,
            'relation_policy'=>self::enum((string)($override['relation_policy']??$generated['relation_policy']??'GENERIC'),['GENERIC','STRICT_CONTEXT','SUBJECT_TO_CONTEXT'],'GENERIC'),
            'hierarchy_depth'=>count($path),
            'branch_ids'=>self::branchIds($family),
            'portal_context_tokens'=>$portalContext,
            'provenance'=>(string)($override['provenance']??$generated['provenance']??'AUTO_FROM_PORTAL_STRUCTURE_V2'),
            'source_values'=>['family_name'=>$name,'path'=>$path,'product_page_names'=>self::productNames($family)],
            'legacy_hash_unchanged'=>true,
        ];
        if(!$identity['subject_heads'])$identity['subject_heads']=[self::stem(self::asciiLower($name))];
        $identity['specificity_score']=self::specificity($identity);
        $hashPayload=$identity;unset($hashPayload['identity_key_v2']);
        $identity['identity_key_v2']=hash('sha256',self::canonicalJson($hashPayload));
        return $identity;
    }

    /** @return array<string,mixed> */
    public static function evaluate(string $query,array $identity): array {
        if(($identity['contract']??'')!==self::CONTRACT)return self::blocked('PSTE_FAMILY_IDENTITY_V2_INVALID',$query,$identity);
        $raw=self::plain($query);$tokens=self::tokens($raw,false);$allTokens=self::tokens($raw,true);
        if(!$tokens)return self::blocked('PSTE_FAMILY_MEMBERSHIP_QUERY_MISSING',$query,$identity);
        $reason=[];$review=[];$details=[];
        $subject=self::subjectMatch($allTokens,(array)$identity['subject_heads'],$identity);
        if(!$subject['matched'])$reason[]='PSTE_FAMILY_V2_SUBJECT_HEAD_MISSING';
        elseif(!empty($subject['primary_modifier_compound']))$reason[]='PSTE_FAMILY_V2_SUBJECT_USED_AS_ACCESSORY_MODIFIER';
        elseif($subject['foreign_prefixes'])$reason[]='PSTE_FAMILY_V2_FOREIGN_COMPOUND_PREFIX';

        $normalizedRaw=self::normalizedPhrase($raw,true);
        foreach((array)$identity['excluded_phrases'] as $phrase){if($phrase!==''&&str_contains(' '.$normalizedRaw.' ',' '.$phrase.' '))$reason[]='PSTE_FAMILY_V2_EXCLUDED_PHRASE';}
        if(self::negatesRequiredContext($allTokens,(array)$identity['context_groups']))$reason[]='PSTE_FAMILY_V2_CONTEXT_NEGATED';

        $comparisonReview=self::hasComparison($allTokens);$multipleContextReview=self::hasMultipleContextTargets($raw,(array)$identity['context_groups']);
        $excluded=self::matchedGroups($tokens,(array)$identity['excluded_concept_groups'],true);
        if($excluded&&!$comparisonReview&&!$multipleContextReview)$reason[]='PSTE_FAMILY_V2_EXCLUDED_CONCEPT';
        elseif($excluded)$review[]='PSTE_FAMILY_V2_EXCLUDED_CONTEXT_IN_COMPARISON';

        $required=self::requiredGroups($tokens,(array)$identity['required_discriminator_groups'],$subject);
        if(!$required['ok'])$reason[]='PSTE_FAMILY_V2_REQUIRED_DISCRIMINATOR_MISSING';
        $alternative=self::alternativeSets($tokens,(array)$identity['alternative_required_sets'],$subject);
        if(!$alternative['ok'])$reason[]='PSTE_FAMILY_V2_ALTERNATIVE_REQUIRED_SET_MISSING';
        $numeric=self::numericMatches($raw,$tokens,(array)$identity['numeric_and_unit_discriminators']);
        if(!$numeric['ok'])$reason[]='PSTE_FAMILY_V2_NUMERIC_DISCRIMINATOR_MISSING';

        $context=self::contextMatch($raw,$tokens,$allTokens,$subject,(array)$identity['context_groups'],(string)$identity['context_policy'],(array)$identity['forbidden_relation_tokens']);
        if($context['status']==='NO_MATCH')$reason[]='PSTE_FAMILY_V2_CONTEXT_MISSING_OR_CONFLICT';
        elseif($context['status']==='REVIEW')$review[]='PSTE_FAMILY_V2_CONTEXT_AMBIGUOUS';

        if($comparisonReview)$review[]='PSTE_FAMILY_V2_COMPARISON_CONTEXT_REVIEW';
        if($multipleContextReview)$review[]='PSTE_FAMILY_V2_MULTIPLE_CONTEXTS_REVIEW';
        if((string)$identity['relation_policy']==='SUBJECT_TO_CONTEXT'&&self::isReversedForRelation($allTokens,$subject,(array)$identity['context_groups']))$review[]='PSTE_FAMILY_V2_RELATION_DIRECTION_REVIEW';

        $reason=array_values(array_unique($reason));$review=array_values(array_unique($review));
        if(($comparisonReview||$multipleContextReview)&&!empty($subject['matched'])){$status='REVIEW';}else{$status=$reason?'NO_MATCH':($review?'REVIEW':'MATCH');}
        $details=[
            'query_tokens_v2'=>$tokens,
            'query_tokens_with_relations_v2'=>$allTokens,
            'subject'=>$subject,
            'context'=>$context,
            'required_discriminators'=>$required,
            'alternative_required_sets'=>$alternative,
            'numeric_discriminators'=>$numeric,
            'excluded_matches'=>$excluded,
        ];
        return [
            'contract'=>self::MATCH_CONTRACT,'ok'=>$status==='MATCH','status'=>$status,
            'reason_codes'=>array_values(array_unique(array_merge($reason,$review))),
            'query_sha256'=>hash('sha256',$query),'topic_family_name'=>(string)$identity['topic_family_name'],
            'topic_family_key'=>(string)$identity['legacy_topic_family_key'],'identity_key_v2'=>(string)$identity['identity_key_v2'],
            'specificity_score'=>(int)$identity['specificity_score'],'details'=>$details,'write_attempted'=>false,
        ];
    }

    /** @return array<string,mixed> */
    public static function resolve(string $query,array $registry): array {
        $matches=[];$reviews=[];$near=[];$evaluated=[];$exact=[];$queryLabel=self::normalizedPhrase($query,false);
        foreach((array)($registry['families']??[]) as $key=>$family){
            $identity=(array)($family['identity_v2']??[]);if(!$identity)continue;
            $result=self::evaluate($query,$identity);$result['family_key']=(string)$key;$evaluated[]=$result;
            if($queryLabel!==''&&self::normalizedPhrase((string)($family['topic_family_name']??''),false)===$queryLabel&&in_array($result['status'],['MATCH','REVIEW'],true))$exact[]=$result;
            if($result['status']==='MATCH')$matches[]=$result;elseif($result['status']==='REVIEW')$reviews[]=$result;elseif(self::corePlausibleMissingDiscriminator($result))$near[]=$result;
        }
        $diag=self::rejectionDiagnostics($evaluated,$near);
        if(count($exact)>1)return ['contract'=>'PSTE_FAMILY_RESOLUTION_V2','status'=>'REVIEW_REQUIRED','winner'=>null,'matches'=>$exact,'reviews'=>$reviews,'reason_code'=>'PSTE_FAMILY_V2_EXACT_LABEL_BRANCH_AMBIGUOUS','rejection_diagnostics'=>$diag,'write_attempted'=>false];
        if(count($exact)===1&&$exact[0]['status']==='MATCH')return ['contract'=>'PSTE_FAMILY_RESOLUTION_V2','status'=>'MATCH','winner'=>$exact[0],'matches'=>$matches,'reviews'=>$reviews,'reason_code'=>'PSTE_FAMILY_V2_EXACT_UNIQUE_LABEL','rejection_diagnostics'=>$diag,'write_attempted'=>false];
        if(!$matches){
            if(count($near)>=2)return ['contract'=>'PSTE_FAMILY_RESOLUTION_V2','status'=>'REVIEW_REQUIRED','winner'=>null,'matches'=>[],'reviews'=>array_values(array_merge($reviews,$near)),'reason_code'=>'PSTE_FAMILY_V2_MULTIPLE_CORE_PLAUSIBLE_DISCRIMINATOR_MISSING','rejection_diagnostics'=>$diag,'write_attempted'=>false];
            return ['contract'=>'PSTE_FAMILY_RESOLUTION_V2','status'=>$reviews?'REVIEW_REQUIRED':'NO_MATCH','winner'=>null,'matches'=>[],'reviews'=>$reviews,'reason_code'=>$reviews?'PSTE_FAMILY_V2_REVIEW_CANDIDATE':'PSTE_FAMILY_V2_NO_FAMILY_MATCH','rejection_diagnostics'=>$diag,'write_attempted'=>false];
        }
        if(count($matches)===1)return ['contract'=>'PSTE_FAMILY_RESOLUTION_V2','status'=>'MATCH','winner'=>$matches[0],'matches'=>$matches,'reviews'=>$reviews,'reason_code'=>'PSTE_FAMILY_V2_SINGLE_CONTENT_MATCH','rejection_diagnostics'=>$diag,'write_attempted'=>false];
        foreach($matches as &$m)$m['query_evidence_score']=self::queryEvidenceScore($m);unset($m);
        usort($matches,static fn($a,$b)=>[(int)$b['query_evidence_score'],(string)$a['family_key']]<=>[(int)$a['query_evidence_score'],(string)$b['family_key']]);
        $top=(int)($matches[0]['query_evidence_score']??0);$topMatches=array_values(array_filter($matches,static fn($m)=>(int)($m['query_evidence_score']??0)===$top));
        if($top<=0||count($topMatches)!==1)return ['contract'=>'PSTE_FAMILY_RESOLUTION_V2','status'=>'REVIEW_REQUIRED','winner'=>null,'matches'=>$matches,'reviews'=>$reviews,'reason_code'=>'PSTE_FAMILY_V2_MULTIPLE_CONTENT_MATCHES_NO_UNIQUE_EVIDENCE','rejection_diagnostics'=>$diag,'write_attempted'=>false];
        return ['contract'=>'PSTE_FAMILY_RESOLUTION_V2','status'=>'MATCH','winner'=>$topMatches[0],'matches'=>$matches,'reviews'=>$reviews,'reason_code'=>'PSTE_FAMILY_V2_QUERY_EVIDENCE_DOMINANT','rejection_diagnostics'=>$diag,'write_attempted'=>false];
    }

    /** @return array<string,mixed> */
    private static function generateIdentity(string $name,array $family,array $path,array $portalContext): array {
        $relation=self::relationParts($name);$familyTokens=self::tokens($name,false);$subjectHeads=[];$contexts=[];$required=[];$numeric=[];$relationBindsContext=false;
        if($relation){
            $subjectPhrase=(string)$relation['before'];$contextPhrase=(string)$relation['after'];$subjectTokens=self::tokens($subjectPhrase,false);$contextTokens=self::tokens($contextPhrase,false);
            if($subjectTokens)$subjectHeads=[end($subjectTokens)];
            $relationName=(string)$relation['relation'];
            if($contextTokens&&in_array($relationName,['fuer','im','in'],true)&&self::tokensOverlapByComponent($contextTokens,$portalContext)){
                // The relation names the actual portal/audience context. Preserve any
                // distinguishing prefix bound into that context compound (for example
                // Compound nouns may contain both contextual and discriminating tokens.
                $contexts=[$portalContext?:$contextTokens];$relationBindsContext=true;
                foreach($contextTokens as $contextToken)foreach(self::rightContextResidualGroups($contextToken,$contexts) as $group)$required[]=$group;
            }elseif($contextTokens&&in_array($relationName,['fuer','im','in','mit'],true)){
                // A non-portal relation is a property/use discriminator, not a domain
                // context. Every meaningful term is required, so "Heunetze" cannot
                // steal the more specific family "Heunetze für staubarmes Heu".
                $required=array_map(static fn($v)=>[$v],$contextTokens);
            }
        }
        $parentTokens=self::nearestParentTokens($path,$name);
        if(!$subjectHeads){
            foreach(array_reverse($parentTokens) as $candidate){foreach($familyTokens as $token){if($token===$candidate||self::structuralRightHead($token,$candidate)){$subjectHeads=[$candidate];break 2;}}}
        }
        if(!$subjectHeads&&$familyTokens)$subjectHeads=[end($familyTokens)];
        $head=(string)($subjectHeads[0]??'');
        $contextPolicy='NOT_REQUIRED';
        if(!$contexts&&$portalContext)$contexts=[$portalContext];
        if($contexts){
            $contextPolicy=self::familyContainsContext($familyTokens,$contexts,$head)?'REQUIRED':'IMPLICIT_ALLOWED';
            if($relationBindsContext)$contextPolicy='REQUIRED';
        }
        foreach($familyTokens as $token){
            if($token===$head)continue;
            foreach(self::rightContextResidualGroups($token,$contexts) as $group)$required[]=$group;
            if(self::tokenBelongsToGroups($token,$contexts)||self::tokenBelongsToGroups($token,$required))continue;
            $prefix=$head!==''&&self::structuralRightHead($token,$head)?substr($token,0,-strlen($head)):'';
            if($prefix!==''){
                $left=self::stripKnownPrefixComponents($prefix,$contexts);
                if($left!=='')$required[]=[$left];
                continue;
            }
            if(preg_match('/^\d+(?:\.\d+)?(?:er)?$/',$token)){$value=preg_replace('/er$/','',$token);$numeric[]=['value'=>$value,'aliases'=>[$token,$value],'unit'=>'','required'=>true];continue;}
            if(!in_array($token,$subjectHeads,true))$required[]=[$token];
        }
        return [
            'subject_heads'=>$subjectHeads,'context_groups'=>$contexts,'context_policy'=>$contextPolicy,
            'required_discriminator_groups'=>$required,'optional_discriminator_groups'=>[],
            'excluded_concept_groups'=>[],'numeric_and_unit_discriminators'=>$numeric,
            'relation_policy'=>$relation?'SUBJECT_TO_CONTEXT':'GENERIC','provenance'=>'AUTO_FROM_PORTAL_STRUCTURE_V2',
        ];
    }

    /** @return array<string,mixed> */
    private static function subjectMatch(array $tokens,array $heads,array $identity): array {
        $matched=[];$headTokenIndexes=[];$foreign=[];$modifierCompounds=[];
        $allowed=[];
        foreach((array)$identity['context_groups'] as $g)foreach((array)$g as $v)$allowed[$v]=true;
        foreach((array)$identity['required_discriminator_groups'] as $g)foreach((array)$g as $v)$allowed[$v]=true;
        foreach((array)$identity['optional_discriminator_groups'] as $g)foreach((array)$g as $v)$allowed[$v]=true;
        foreach((array)$identity['alternative_required_sets'] as $g)foreach((array)$g as $v)$allowed[$v]=true;
        foreach($tokens as $index=>$token){foreach($heads as $head){
            if($token!==$head&&self::startsComponent($token,$head)&&!self::controlledSubjectHeadMatch($token,$head,$identity))$modifierCompounds[]=['token'=>$token,'head'=>$head,'index'=>$index];
            if(self::controlledSubjectHeadMatch($token,$head,$identity)){
                $matched[$head]=true;$headTokenIndexes[]=$index;
                if($token!==$head){$prefix=substr($token,0,-strlen($head));$unknown=self::unknownPrefix($prefix,array_keys($allowed));if($unknown!=='')$foreign[]=$unknown;}
            }
        }}
        $primaryModifier=false;if($modifierCompounds&&$headTokenIndexes){$firstHead=min($headTokenIndexes);foreach($modifierCompounds as $m)if((int)$m['index']<$firstHead){$primaryModifier=true;break;}}
        return ['matched'=>(bool)$matched,'matched_heads'=>array_keys($matched),'head_token_indexes'=>array_values(array_unique($headTokenIndexes)),'foreign_prefixes'=>array_values(array_unique($foreign)),'modifier_compounds'=>$modifierCompounds,'primary_modifier_compound'=>$primaryModifier];
    }

    /** @return array<string,mixed> */
    private static function requiredGroups(array $tokens,array $groups,array $subject): array {
        $matched=[];$missing=[];
        foreach($groups as $i=>$group){$ok=false;foreach($group as $term){if(self::termPresent($tokens,$term,$subject)){$ok=true;$matched[]=$term;break;}}if(!$ok)$missing[]=$i;}
        return ['ok'=>!$missing,'matched'=>array_values(array_unique($matched)),'missing_group_indexes'=>$missing];
    }
    /** @return array<string,mixed> */
    private static function alternativeSets(array $tokens,array $sets,array $subject): array {
        if(!$sets)return ['ok'=>true,'matched_set'=>[]];
        foreach($sets as $set){$ok=true;foreach($set as $term)if(!self::termPresent($tokens,$term,$subject)){$ok=false;break;}if($ok)return ['ok'=>true,'matched_set'=>$set];}
        return ['ok'=>false,'matched_set'=>[]];
    }

    /** @return array<string,mixed> */
    private static function contextMatch(string $raw,array $tokens,array $allTokens,array $subject,array $groups,string $policy,array $forbiddenRelations): array {
        if(!$groups||$policy==='NOT_REQUIRED')return ['status'=>'MATCH','source'=>'NOT_REQUIRED','matched'=>[]];
        if(in_array('neben',$allTokens,true))return ['status'=>'NO_MATCH','source'=>'NON_BINDING_PROXIMITY_RELATION','matched'=>[]];
        foreach($forbiddenRelations as $forbidden)if(in_array($forbidden,$allTokens,true))return ['status'=>'NO_MATCH','source'=>'FORBIDDEN_RELATION','matched'=>[]];
        $matched=[];$subjectIndexes=(array)($subject['head_token_indexes']??[]);
        foreach($groups as $group)foreach($group as $term){
            foreach($allTokens as $idx=>$token){
                if((self::startsComponent($token,$term)||self::rightHead($token,$term))&&in_array($idx,$subjectIndexes,true)){$matched[]=['term'=>$term,'token'=>$token,'index'=>$idx,'source'=>'SUBJECT_COMPOUND'];continue;}
                if($token===$term||self::startsComponent($token,$term)||self::rightHead($token,$term)){
                    if(self::nearAcceptedRelation($allTokens,$idx)||self::adjacentWithoutForbiddenRelation($allTokens,$idx,$subjectIndexes))$matched[]=['term'=>$term,'token'=>$token,'index'=>$idx,'source'=>$token===$term?'EXACT_RELATIONAL_OR_ADJACENT':'RELATIONAL_OR_ADJACENT'];
                }
            }
        }
        $foreign=$policy==='REQUIRED'?self::explicitForeignTarget($allTokens,$groups):[];
        if($foreign&&$matched)return ['status'=>'REVIEW','source'=>'MULTIPLE_EXPLICIT_CONTEXTS','matched'=>$matched,'foreign'=>$foreign];
        if($foreign)return ['status'=>'NO_MATCH','source'=>'EXPLICIT_FOREIGN_CONTEXT','matched'=>[],'foreign'=>$foreign];
        if($matched)return ['status'=>'MATCH','source'=>'EXPLICIT_OR_COMPOUND','matched'=>$matched];
        if($policy==='IMPLICIT_ALLOWED')return ['status'=>'MATCH','source'=>'PORTAL_IMPLICIT','matched'=>[]];
        return ['status'=>'NO_MATCH','source'=>'REQUIRED_CONTEXT_MISSING','matched'=>[]];
    }

    /** @return array<string,mixed> */
    private static function numericMatches(string $raw,array $tokens,array $defs): array {
        $missing=[];$matched=[];$lower=str_replace(',','.',self::asciiLower($raw));
        foreach($defs as $i=>$def){
            if(empty($def['required']))continue;
            $aliases=array_values(array_filter(array_map(static fn($v)=>str_replace(',','.',self::asciiLower((string)$v)),(array)($def['aliases']??[])),static fn($v)=>$v!==''));
            $unitAliases=array_values(array_filter(array_map(static fn($v)=>self::asciiLower((string)$v),(array)($def['unit_aliases']??[]))));
            $ok=false;
            foreach($aliases as $alias){
                if(!preg_match('/^\d+(?:\.\d+)?$/',$alias)){
                    $a=self::stem($alias);if($a!==''&&in_array($a,$tokens,true)){$ok=true;break;}continue;
                }
                $numberPattern='(?<![0-9.])'.preg_quote($alias,'/').'(?![0-9.])';
                if(!$unitAliases){if(preg_match('/'.$numberPattern.'(?:er)?\b/u',$lower)){$ok=true;break;}continue;}
                foreach($unitAliases as $unit){
                    $unitPattern=preg_quote($unit,'/');
                    if(preg_match('/'.$numberPattern.'\s*(?:er\s*)?'.$unitPattern.'\b/u',$lower)){$ok=true;break;}
                    if(preg_match('/'.$numberPattern.'\s*(?:er\b)/u',$lower)&&self::rawContainsUnitComponent($lower,$unit)){$ok=true;break;}
                }
                if($ok)break;
            }
            if($ok)$matched[]=$i;else $missing[]=$i;
        }
        return ['ok'=>!$missing,'matched_indexes'=>$matched,'missing_indexes'=>$missing];
    }

    private static function rawContainsUnitComponent(string $raw,string $unit): bool {
        if($unit==='')return false;
        return (bool)preg_match('/\b'.preg_quote($unit,'/').'\b/u',$raw)||str_contains($raw,$unit);
    }

    private static function termPresent(array $tokens,string $term,array $subject): bool {
        if(in_array($term,$tokens,true))return true;
        foreach($tokens as $token){if(self::startsComponent($token,$term)||self::rightHead($token,$term))return true;}
        return false;
    }
    private static function matchedGroups(array $tokens,array $groups,bool $component): array {$out=[];foreach($groups as $i=>$group)foreach($group as $term)foreach($tokens as $token)if($token===$term||($component&&(self::startsComponent($token,$term)||self::rightHead($token,$term)))){$out[]=['group'=>$i,'term'=>$term,'token'=>$token];break 2;}return $out;}

    private static function explicitForeignTarget(array $tokens,array $groups): array {
        $allowed=[];foreach($groups as $g)foreach($g as $v)$allowed[$v]=true;$foreign=[];
        foreach($tokens as $i=>$token){if(!in_array($token,['fuer','für'],true))continue;for($j=$i+1;$j<min(count($tokens),$i+5);$j++){$t=$tokens[$j];if(in_array($t,['und','oder'],true))continue;if(in_array($t,self::RELATION_WORDS,true))break;$isAllowed=false;foreach(array_keys($allowed) as $a)if($t===$a||self::startsComponent($t,$a)||self::rightHead($t,$a)){$isAllowed=true;break;}if(!$isAllowed&&strlen($t)>=4)$foreign[]=$t;}}
        return array_values(array_unique($foreign));
    }
    private static function negatesRequiredContext(array $tokens,array $groups): bool {for($i=0;$i<count($tokens);$i++){if(!in_array($tokens[$i],self::NEGATION_WORDS,true))continue;for($j=$i+1;$j<min(count($tokens),$i+5);$j++)foreach($groups as $g)foreach($g as $term)if($tokens[$j]===$term||self::startsComponent($tokens[$j],$term)||self::rightHead($tokens[$j],$term))return true;}return false;}
    private static function hasComparison(array $tokens): bool {return (bool)array_intersect($tokens,['versus','vs','gegen']);}
    private static function hasMultipleContextTargets(string $raw,array $groups): bool {
        $n=self::normalizedPhrase($raw,true);
        return (bool)preg_match('/\bfuer\b[^,;]*\bund\b/u',$n);
    }
    private static function isReversedForRelation(array $tokens,array $subject,array $groups): bool {foreach($tokens as $i=>$t)if(in_array($t,['fuer','für'],true)){foreach((array)($subject['head_token_indexes']??[]) as $si)if($si>$i)return true;}return false;}
    private static function nearAcceptedRelation(array $tokens,int $index): bool {for($i=max(0,$index-3);$i<$index;$i++)if(in_array($tokens[$i],['fuer','für','im','in','mit'],true))return true;return false;}
    private static function nearSubject(int $index,array $subjectIndexes): bool {foreach($subjectIndexes as $s)if(abs($index-(int)$s)<=2)return true;return false;}
    private static function adjacentWithoutForbiddenRelation(array $tokens,int $index,array $subjectIndexes): bool {foreach($subjectIndexes as $s){$lo=min($index,(int)$s);$hi=max($index,(int)$s);if($hi-$lo>2)continue;$between=array_slice($tokens,$lo+1,max(0,$hi-$lo-1));if(array_intersect($between,['neben','gegen','versus','vs','ohne','nicht']))continue;return true;}return false;}
    private static function anyTokenComponent(array $tokens,string $term): bool {foreach($tokens as $token)if($token===$term||self::startsComponent($token,$term)||self::rightHead($token,$term))return true;return false;}

    private static function unknownPrefix(string $prefix,array $allowed): string {
        $prefix=trim($prefix);if($prefix==='')return '';
        $remaining=$prefix;$allowed=array_values(array_unique(array_filter($allowed,static fn($v)=>strlen($v)>=2)));usort($allowed,static fn($a,$b)=>strlen($b)<=>strlen($a));
        $guard=0;while($remaining!==''&&$guard++<20){$matched=false;foreach($allowed as $a){foreach([$a,$a.'e',$a.'en',$a.'er',$a.'es',$a.'s',$a.'n'] as $variant){if(str_starts_with($remaining,$variant)){$remaining=substr($remaining,strlen($variant));$matched=true;break 2;}}}if(!$matched)break;}
        return strlen($remaining)>=3?$remaining:'';
    }
    private static function stripKnownPrefixComponents(string $prefix,array $groups): string {$allowed=[];foreach($groups as $g)foreach($g as $v)$allowed[]=$v;$unknown=self::unknownPrefix($prefix,$allowed);return $unknown;}
    private static function startsComponent(string $token,string $component): bool {if($component===''||strlen($component)<3)return false;if($token===$component)return true;foreach([$component,$component.'e',$component.'en',$component.'er',$component.'es',$component.'s',$component.'n'] as $v)if(str_starts_with($token,$v))return true;return false;}
    private static function rightHead(string $token,string $head): bool {return strlen($head)>=4&&strlen($token)>=strlen($head)&&str_ends_with($token,$head);}
    private static function structuralRightHead(string $token,string $head): bool {return strlen($head)>=3&&strlen($token)>=strlen($head)&&str_ends_with($token,$head);}
    private static function controlledSubjectHeadMatch(string $token,string $head,array $identity): bool {
        if($token===$head||self::rightHead($token,$head))return true;
        if(!self::structuralRightHead($token,$head))return false;
        $prefix=substr($token,0,-strlen($head));if(strlen($prefix)<3)return false;$allowed=[];
        foreach(['context_groups','required_discriminator_groups','optional_discriminator_groups','alternative_required_sets'] as $field)foreach((array)($identity[$field]??[]) as $group)foreach((array)$group as $term)$allowed[]=(string)$term;
        return self::unknownPrefix($prefix,$allowed)==='';
    }

    /** @return list<list<string>> */
    private static function rightContextResidualGroups(string $token,array $contextGroups): array {
        $out=[];
        foreach($contextGroups as $group)foreach((array)$group as $term){
            $term=trim((string)$term);if($term===''||$token===$term||!self::rightHead($token,$term))continue;
            $prefix=substr($token,0,-strlen($term));$prefix=self::stem(trim($prefix));
            if(strlen($prefix)>=3)$out[]=[$prefix];
        }
        return self::preparedNested($out);
    }

    private static function corePlausibleMissingDiscriminator(array $result): bool {
        if(($result['status']??'')!=='NO_MATCH')return false;$details=(array)($result['details']??[]);$subject=(array)($details['subject']??[]);$context=(array)($details['context']??[]);
        if(empty($subject['matched'])||!empty($subject['primary_modifier_compound'])||!empty($subject['foreign_prefixes']))return false;
        if(($context['status']??'')!=='MATCH')return false;
        if(!empty($details['excluded_matches']))return false;
        $allowed=['PSTE_FAMILY_V2_REQUIRED_DISCRIMINATOR_MISSING','PSTE_FAMILY_V2_ALTERNATIVE_REQUIRED_SET_MISSING','PSTE_FAMILY_V2_NUMERIC_DISCRIMINATOR_MISSING'];
        $reasons=array_values(array_unique((array)($result['reason_codes']??[])));if(!$reasons)return false;
        foreach($reasons as $reason)if(!in_array($reason,$allowed,true))return false;
        return true;
    }

    private static function queryEvidenceScore(array $result): int {
        $d=(array)($result['details']??[]);$score=0;
        $score+=count((array)($d['required_discriminators']['matched']??[]))*30;
        $score+=count((array)($d['alternative_required_sets']['matched_set']??[]))*25;
        $score+=count((array)($d['numeric_discriminators']['matched_indexes']??[]))*35;
        $context=(array)($d['context']??[]);if(($context['source']??'')==='EXPLICIT_OR_COMPOUND')$score+=10;
        return $score;
    }

    private static function rejectionDiagnostics(array $evaluated,array $near): array {
        $stageCounts=[];$plausible=[];
        foreach($evaluated as $r){
            foreach((array)($r['reason_codes']??[]) as $code)$stageCounts[(string)$code]=($stageCounts[(string)$code]??0)+1;
        }
        ksort($stageCounts,SORT_STRING);
        foreach(array_slice($near,0,20) as $r)$plausible[]=['family_key'=>(string)($r['family_key']??''),'family_name'=>(string)($r['topic_family_name']??''),'reason_codes'=>(array)($r['reason_codes']??[]),'required_discriminators'=>(array)($r['details']['required_discriminators']??[]),'numeric_discriminators'=>(array)($r['details']['numeric_discriminators']??[])];

        // Decision diagnostics must describe the actually nearest rejected family/families,
        // not the union of failures produced by hundreds of unrelated families. This is
        // diagnostics only: it never changes MATCH/REVIEW/NO_MATCH resolution.
        $nearest=self::nearestRejectedFamilies($evaluated);
        $nearestReasons=[];
        foreach($nearest as $candidate)foreach((array)($candidate['reason_codes']??[]) as $code)$nearestReasons[(string)$code]=true;
        if(!$nearestReasons){
            // If no family even reached a subject match, the decisive failure is the
            // subject head itself. Do not fabricate a misleading "nearest" family.
            $nearestReasons['PSTE_FAMILY_V2_SUBJECT_HEAD_MISSING']=true;
        }
        $nearestReasonCodes=array_keys($nearestReasons);sort($nearestReasonCodes,SORT_STRING);
        return [
            'evaluated_family_count'=>count($evaluated),
            'failure_reason_counts'=>$stageCounts,
            'core_plausible_missing_discriminator_count'=>count($near),
            'core_plausible_families'=>$plausible,
            'nearest_rejected_family_count'=>count($nearest),
            'nearest_rejected_families'=>$nearest,
            'nearest_failure_reason_codes'=>$nearestReasonCodes,
            'nearest_diagnostic_basis'=>'SUBJECT_FIRST_STAGE_PROGRESS_V1',
        ];
    }

    /** @return list<array<string,mixed>> */
    private static function nearestRejectedFamilies(array $evaluated): array {
        $ranked=[];$bestVector=null;
        foreach($evaluated as $r){
            if(($r['status']??'')!=='NO_MATCH')continue;
            $vector=self::rejectionProgressVector($r);
            // A family with no subject evidence is not a meaningful semantic neighbour.
            if((int)$vector[0]===0)continue;
            if($bestVector===null||self::compareProgressVector($vector,$bestVector)>0){$bestVector=$vector;$ranked=[$r];}
            elseif(self::compareProgressVector($vector,$bestVector)===0)$ranked[]=$r;
        }
        if($bestVector===null)return [];
        usort($ranked,static fn($a,$b)=>strcmp((string)($a['family_key']??''),(string)($b['family_key']??'')));
        $out=[];
        foreach(array_slice($ranked,0,20) as $r){
            $d=(array)($r['details']??[]);
            $out[]=[
                'family_key'=>(string)($r['family_key']??''),
                'family_name'=>(string)($r['topic_family_name']??''),
                'reason_codes'=>array_values(array_unique((array)($r['reason_codes']??[]))),
                'progress_vector'=>$bestVector,
                'subject'=>(array)($d['subject']??[]),
                'context'=>(array)($d['context']??[]),
                'required_discriminators'=>(array)($d['required_discriminators']??[]),
                'alternative_required_sets'=>(array)($d['alternative_required_sets']??[]),
                'numeric_discriminators'=>(array)($d['numeric_discriminators']??[]),
                'excluded_matches'=>(array)($d['excluded_matches']??[]),
            ];
        }
        return $out;
    }

    /** @return list<int> */
    private static function rejectionProgressVector(array $result): array {
        $d=(array)($result['details']??[]);$subject=(array)($d['subject']??[]);$context=(array)($d['context']??[]);
        $subjectTier=0;
        if(!empty($subject['matched'])){
            if(!empty($subject['primary_modifier_compound']))$subjectTier=1;
            elseif(!empty($subject['foreign_prefixes']))$subjectTier=2;
            else $subjectTier=3;
        }
        $contextTier=($context['status']??'')==='MATCH'?2:(($context['status']??'')==='REVIEW'?1:0);
        $excludedEmpty=empty($d['excluded_matches'])?1:0;
        $requiredMatched=count((array)($d['required_discriminators']['matched']??[]));
        $alternativeMatched=count((array)($d['alternative_required_sets']['matched_set']??[]));
        $numericMatched=count((array)($d['numeric_discriminators']['matched_indexes']??[]));
        $failurePenalty=-count(array_unique((array)($result['reason_codes']??[])));
        return [$subjectTier,$contextTier,$excludedEmpty,$requiredMatched,$alternativeMatched,$numericMatched,$failurePenalty];
    }

    private static function compareProgressVector(array $a,array $b): int {
        $n=max(count($a),count($b));
        for($i=0;$i<$n;$i++){$av=(int)($a[$i]??0);$bv=(int)($b[$i]??0);if($av===$bv)continue;return $av<=>$bv;}
        return 0;
    }

    /** @return array<string,mixed>|null */
    private static function relationParts(string $name): ?array {
        $plain=self::plain($name);
        if(preg_match('/^(.+?)\s+(für|fuer|im|in|mit)\s+(.+)$/iu',$plain,$m))return ['before'=>trim($m[1]),'relation'=>self::asciiLower($m[2]),'after'=>trim($m[3])];
        return null;
    }
    private static function tokensOverlapByComponent(array $left,array $right): bool {foreach($left as $a)foreach($right as $b)if($a===$b||self::startsComponent($a,$b)||self::rightHead($a,$b)||self::startsComponent($b,$a)||self::rightHead($b,$a))return true;return false;}
    private static function familyContainsContext(array $familyTokens,array $groups,string $head): bool {foreach($familyTokens as $token)foreach($groups as $g)foreach($g as $term)if($token===$term||($head!==''&&self::structuralRightHead($token,$head)&&self::startsComponent($token,$term)))return true;return false;}
    private static function tokenBelongsToGroups(string $token,array $groups): bool {foreach($groups as $g)foreach($g as $v)if($token===$v||self::startsComponent($token,$v)||self::rightHead($token,$v))return true;return false;}

    /** @return list<string> */
    private static function pathNames(array $family): array {$names=[];foreach((array)($family['by_type']??[]) as $row){$full=trim((string)($row['full_path']??''));if($full!==''){$parts=array_values(array_filter(array_map('trim',explode('>',$full))));if($parts){array_pop($parts);$names=$parts;break;}}}return $names;}
    /** @return list<string> */
    private static function productNames(array $family): array {$out=[];foreach((array)($family['by_type']??[]) as $row){$v=trim((string)($row['product_page_name']??''));if($v!=='')$out[$v]=true;}return array_keys($out);}
    /** @return list<int> */
    private static function branchIds(array $family): array {$out=[];foreach((array)($family['by_type']??[]) as $row){foreach(['product_page_id','term_id','parent'] as $k){$v=(int)($row[$k]??0);if($v>0)$out[$v]=true;}}$ids=array_keys($out);sort($ids,SORT_NUMERIC);return $ids;}
    /** @return list<string> */
    private static function portalContextTokens(array $path,array $baseline): array {
        $site='';if(function_exists('get_bloginfo'))$site=(string)get_bloginfo('name');if($site==='')$site=(string)($baseline['site_name']??'');
        $tokens=[];foreach(self::tokens($site,false) as $t)if(!self::isGenericPortalToken($t))$tokens[$t]=true;
        if(!$tokens&&$path){$first=(string)$path[0];foreach(self::tokens($first,false) as $t)if(!self::isGenericPortalToken($t))$tokens[$t]=true;}
        return array_keys($tokens);
    }
    /** @return list<string> */
    private static function nearestParentTokens(array $path,string $familyName): array {if(!$path)return [];$familyNorm=self::normalizedPhrase($familyName,false);for($i=count($path)-1;$i>=0;$i--){$n=self::normalizedPhrase((string)$path[$i],false);if($n===''||$n===$familyNorm)continue;return self::tokens((string)$path[$i],false);}return [];}

    /** @return array<string,mixed> */
    private static function overrideFor(string $name): array {$all=self::overrides();return (array)($all['families'][$name]??[]);}
    /** @return array<string,mixed> */
    private static function overrides(): array {if(is_array(self::$overrides))return self::$overrides;$path=defined('PSTE_DIR')?PSTE_DIR.'contracts/family-identity-v2.json':'';$data=[];if($path!==''&&is_file($path)){$decoded=json_decode((string)file_get_contents($path),true);if(is_array($decoded)&&($decoded['contract']??'')==='PSTE_FAMILY_IDENTITY_V2_OVERRIDES_V1')$data=$decoded;}self::$overrides=$data?:['families'=>[]];return self::$overrides;}

    /** @return list<string> */
    private static function preparedFlat(array $values): array {return array_values(array_unique(array_filter(array_map(static fn($v)=>trim((string)$v),$values),static fn($v)=>$v!=='')));}
    /** @return list<list<string>> */
    private static function preparedNested(array $groups): array {$out=[];$seen=[];foreach($groups as $group){$clean=self::preparedFlat((array)$group);sort($clean,SORT_STRING);$key=implode('|',$clean);if($clean&&!isset($seen[$key])){$seen[$key]=true;$out[]=$clean;}}return $out;}
    private static function isGenericPortalToken(string $token): bool {foreach(self::GENERIC_PORTAL_WORDS as $word)if($token===self::stem(self::asciiLower($word)))return true;return false;}

    /** @return list<string> */
    private static function normalizeGroups(array $values,bool $phrases): array {$out=[];foreach($values as $v){if(is_array($v)){foreach($v as $x)$out=array_merge($out,self::tokens((string)$x,false));}else{$tokens=self::tokens((string)$v,false);if($phrases&&count($tokens)>1)$out[]=implode('_',$tokens);else $out=array_merge($out,$tokens);}}return array_values(array_unique(array_filter($out)));}
    /** @return list<list<string>> */
    private static function normalizeNestedGroups(array $groups): array {$out=[];$seen=[];foreach($groups as $group){$tokens=[];foreach((array)$group as $v){$parts=self::tokens((string)$v,false);if(count($parts)>1)$tokens[]=implode('_',$parts);else $tokens=array_merge($tokens,$parts);}$tokens=array_values(array_unique(array_filter($tokens)));sort($tokens,SORT_STRING);$key=implode('|',$tokens);if($tokens&&!isset($seen[$key])){$seen[$key]=true;$out[]=$tokens;}}return $out;}
    /** @return list<array<string,mixed>> */
    private static function normalizeNumeric(array $defs): array {$out=[];foreach($defs as $def){if(!is_array($def))continue;$value=str_replace(',','.',trim((string)($def['value']??'')));if($value==='')continue;$aliases=array_values(array_unique(array_filter(array_map(static fn($v)=>str_replace(',','.',self::asciiLower((string)$v)),(array)($def['aliases']??[$value])),static fn($v)=>$v!=='')));$units=array_values(array_unique(array_filter(array_map(static fn($v)=>self::stem(self::asciiLower((string)$v)),(array)($def['unit_aliases']??array_filter([(string)($def['unit']??'')]))))));$out[]=['value'=>$value,'aliases'=>$aliases?:[$value],'unit'=>(string)($def['unit']??''),'unit_aliases'=>$units,'required'=>!array_key_exists('required',$def)||!empty($def['required'])];}return $out;}
    private static function specificity(array $identity): int {return 100+count((array)$identity['subject_heads'])*5+count((array)$identity['required_discriminator_groups'])*30+count((array)$identity['numeric_and_unit_discriminators'])*35+((string)$identity['context_policy']==='REQUIRED'?20:0)+(int)$identity['hierarchy_depth'];}
    private static function enum(string $v,array $allowed,string $default): string {$v=strtoupper(trim($v));return in_array($v,$allowed,true)?$v:$default;}
    private static function plain(string $v): string {$v=trim(html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8'));return trim((string)preg_replace('/\s+/u',' ',$v));}
    private static function asciiLower(string $v): string {$v=strtr(trim($v),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
    private static function stem(string $token): string {
        if(preg_match('/^\d+(?:\.\d+)?(?:er)?$/',$token))return (string)preg_replace('/er$/','',$token);
        if(strlen($token)>4&&str_ends_with($token,'en'))return substr($token,0,-2);
        if(strlen($token)>4&&str_ends_with($token,'e'))return substr($token,0,-1);
        if(strlen($token)>5&&str_ends_with($token,'er'))return substr($token,0,-2);
        if(strlen($token)>5&&str_ends_with($token,'es'))return substr($token,0,-2);
        if(strlen($token)>5&&str_ends_with($token,'n'))return substr($token,0,-1);
        if(strlen($token)>5&&str_ends_with($token,'s'))return substr($token,0,-1);
        return $token;
    }
    private static function canonicalJson($v): string {$j=function_exists('wp_json_encode')?wp_json_encode(self::canonicalize($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode(self::canonicalize($v),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($j))throw new RuntimeException('PSTE_FAMILY_V2_JSON_FAILED');return $j;}
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
    /** @return array<string,mixed> */
    private static function blocked(string $reason,string $query,array $identity): array {return ['contract'=>self::MATCH_CONTRACT,'ok'=>false,'status'=>'NO_MATCH','reason_codes'=>[$reason],'query_sha256'=>$query!==''?hash('sha256',$query):'','topic_family_name'=>(string)($identity['topic_family_name']??''),'topic_family_key'=>(string)($identity['legacy_topic_family_key']??''),'identity_key_v2'=>(string)($identity['identity_key_v2']??''),'specificity_score'=>(int)($identity['specificity_score']??0),'details'=>[],'write_attempted'=>false];}
}
