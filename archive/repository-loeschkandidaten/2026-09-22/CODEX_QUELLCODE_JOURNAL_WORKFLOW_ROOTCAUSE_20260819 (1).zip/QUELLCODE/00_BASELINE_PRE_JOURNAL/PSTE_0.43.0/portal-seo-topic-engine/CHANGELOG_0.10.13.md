# 0.10.13

- resolves legacy unscoped family keys against the current scoped portal registry using exact category evidence;
- checks raw-query membership before classification, blocking cross-family legacy/provider noise;
- rebuilds legacy query/title metadata without provider calls and without article/content writes;
- aligns retriever B with retriever A for explicit test/comparison intent;
- reclassifies the complete stored topic pool under schema 12 with candidate isolation.
- blocks short bare noun-chain titles instead of forwarding unreadable metadata titles;
- keeps the valid „2er Pferdeanhänger für zwei Pferde“ query explicitly tied to the family discriminator.
