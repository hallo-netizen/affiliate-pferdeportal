# 0.7.1-pste-0.10.10-source-binding

- Repariert ausschließlich den live belegten Folgefehler `PSERC_SEO_SOURCE_DRIFT` nach Installation der geprüften Themenengine 0.10.10-staging.
- Aktualisiert den exakten Quellvertrag von PSTE 0.10.9 auf PSTE 0.10.10: 108 Dateien, vollständige SHA-256- und Bytebindung, Schema 10.
- Die Compiler-, Semantik-, Titel-, Planplatz-, Metadaten- und Schreibfreiheitslogik bleibt byteidentisch zu 0.7.0.
- Fehlende, zusätzliche oder veränderte Engine-Dateien sowie Versions- und Schemaabweichungen bleiben fail-closed blockiert.
- Keine Änderung an Textmaschine, Artikelinhalt, HTML, Design, WordPress-Beiträgen, Kategorien, URLs, Yoast-Daten oder Produktionsregeln.
