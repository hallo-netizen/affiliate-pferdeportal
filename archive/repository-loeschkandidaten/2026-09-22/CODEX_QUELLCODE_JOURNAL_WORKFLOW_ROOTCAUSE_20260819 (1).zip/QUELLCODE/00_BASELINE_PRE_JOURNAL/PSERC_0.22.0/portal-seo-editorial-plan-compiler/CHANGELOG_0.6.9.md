# 0.6.9-schema-contract-readonly

- Korrigiert die nachgewiesene Inkompatibilität: PSTE 0.10.8 arbeitet mit Schema 10, während PSERC 0.6.8 fälschlich Schema 9 verlangte.
- Das erwartete Laufzeitschema ist nicht mehr separat im Reader fest codiert, sondern Teil des signierten SEO-Quellvertrags.
- Positive Prüfung: exakt gebundene PSTE-Version 0.10.8-staging mit Schema 10 wird gelesen.
- Negative Prüfung: Schema 9, leeres Schema, manipulierte Schema-Bindung und Quellabweichungen werden fail-closed blockiert.
- Unverändert schreibfrei: keine Artikelproduktion, kein Inhalt, kein HTML, keine Tabellen, keine Links, kein Design und keine Qualitätsparameter.
- Übergabe weiterhin ausschließlich mit exakt fünf skalaren Metadatenfeldern: `title`, `target_keyword`, `category`, `article_type`, `plan_slot`.
