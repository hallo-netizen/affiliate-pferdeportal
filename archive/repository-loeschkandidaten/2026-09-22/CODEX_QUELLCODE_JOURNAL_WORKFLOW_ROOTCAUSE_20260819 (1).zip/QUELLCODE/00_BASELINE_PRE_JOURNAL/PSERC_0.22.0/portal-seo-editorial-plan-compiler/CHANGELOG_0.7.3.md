# 0.7.3 – Kanonische Planplatzabsicht fail-closed

- Behebt E-070: Ein allgemeiner Titel konnte bislang auf einen fachlich spezielleren freien Planplatz ausweichen, wenn der semantisch passendere Planplatz bereits belegt war.
- Der Compiler bewertet jetzt immer sämtliche kanonischen Planplätze derselben Kategorie und Beitragsart – nicht nur die freien.
- Exakt übereinstimmende kanonische Arbeitstitel werden eindeutig gebunden.
- Andere Titel werden nur bei einem eindeutig besten, ausreichend starken und nicht konkurrierenden slotspezifischen Nachweis gebunden.
- Allgemeine, schwache oder mehrere Planplatzabsichten zugleich belegende Titel bleiben fail-closed zurückgehalten.
- Ist der eindeutig beste Planplatz bereits belegt oder reserviert, wird kein schwächer passender Ersatzplatz verwendet.
- Der Metadatenbericht dokumentiert die Entscheidung im `slot_intent_gate` einschließlich Bestwert, Zweitwert, Abstand und Konkurrenzverhältnis.
- Themen und Longtails werden weder gelöscht noch umbenannt. Es erfolgt kein WordPress-Schreibvorgang und keine Textproduktion.
- Keine Änderung an Themenengine, Textmaschine, Artikelinhalt, HTML, Design, Kategorien, URLs, Yoast oder Produktionsregeln.
