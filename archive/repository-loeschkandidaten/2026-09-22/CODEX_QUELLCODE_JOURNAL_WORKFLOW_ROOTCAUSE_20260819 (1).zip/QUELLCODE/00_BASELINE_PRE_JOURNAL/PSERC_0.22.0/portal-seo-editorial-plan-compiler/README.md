# Portal SEO Editorial Plan Compiler 0.20.0

## 0.20.0 – signierte READY-Teilmenge für kontrollierte 1–4-Artikel-Läufe

Der aktuelle Compiler kann mehrere READY Kandidaten anzeigen. Der Produktionsstart verwendet nur diejenige 1–4-Teilmenge, die in der offline signierten Workflow-Supervisor-Freigabe gebunden ist. Damit kann ein einzelner kontrollierter E2E-Test ausgeführt werden, ohne die restlichen READY Kandidaten zu starten. Die Auswahl selbst erzeugt oder verändert keinerlei Artikelinhalt.

# Portal SEO Editorial Plan Compiler 0.20.0

## 0.19.0 – signierter 0039-Herkunfts- und Unveränderlichkeits-Supervisor

Der Produktionsstart verlangt eine offline Ed25519-signierte Workflow-Freigabe. Sie bindet den unveränderten Nullpunkt STARTMASTER 0039, den exakten historischen 0039-Produktionsprompt, Exact Five, unabhängige Recherche-/Herkunfts-/Language-Qualitätsattestationen sowie Fact-Pack, Produktionsplan und Artikelkörper-Hashes. Im WordPress-Plugin liegt ausschließlich der öffentliche Prüfschlüssel. Artikelinhalt/HTML werden weder erzeugt noch verändert. PPM 6.7.9 bleibt unverändert.


## 0.14.0 – stabile Planplatzidentität und korrekter Gesamtworkflow

- `plan_slot` ist ein opaker V2-Token, der ausschließlich aus `canonical_article_id` abgeleitet wird. `working_title`, `intent_angle`, Keyword und generierter Titel sind ausdrücklich ausgeschlossen.
- Der exakt fünfskalare Handoff geht **nicht direkt** in PPM 6.7.9. Verbraucher ist der freigegebene Recherche-/Textprozess. Erst dieser erzeugt auf Basis seiner bestehenden Quellen-/Fact-Pack-/Qualitätsregeln das vollständige PPM-V4/V5-Produktionspaket.
- Nach der Fünf-Felder-Grenze darf der freigegebene Prozess den `plan_slot` intern deterministisch auf `canonical_article_id` auflösen. Dieses interne Identitätsfeld ist kein sechstes externes Handoff-Feld.
- Vor PPM-Preflight muss das Produktionspaket `canonical_article_id` explizit tragen. Dadurch greift PPMs unveränderter Legacy-Fallback über `working_title` im freigegebenen Pfad nicht.
- Compiler und Identitätsbrücke erzeugen keine Artikeltexte, Fact-Packs, HTML, Links, Formatierung oder Design.


## 0.13.0 – systemische Trennung von Semantik und Planplatz

- Inhaltsgleichheit/Kannibalisierung wird in einem eigenen read-only Semantik-Gate geprüft.
- Kanonische Planplätze sind ausschließlich technische Kapazität innerhalb bereits feststehender Kategorie + Beitragsart.
- Kein Schlüsselwort, kein `intent_angle`, kein Produktions-/Arbeitstitel und kein `working_title` darf einen Planplatz semantisch auswählen.
- Eindeutige Dubletten blockieren; starke, aber nicht eindeutige Überschneidungen bleiben zur Prüfung zurückgehalten.
- Die Textmaschine 6.7.9, Text-/HTML-/Format-/Designlogik und der exakt fünfskalare Handoff bleiben unverändert.

Der Compiler liest freigegebene Themen der Portal SEO Themenengine ausschließlich schreibfrei und prüft sie gegen:

- die aktuelle Portal-Kategoriestruktur,
- die semantische Titel-/Typzuordnung,
- den vorhandenen Artikel- und Entwurfsbestand,
- den kanonischen Redaktionsplan,
- die unveränderte Production Machine 6.7.9.

Externe SERP-Evidenz ist weder erforderlich noch Teil der Freigabe. Entscheidend sind Longtail-Herkunft, semantisch brauchbarer Titel, exakt vorhandene Zielkategorie und die Doppelungsprüfung innerhalb des eigenen Portals.

Der einzige zulässige Handoff an die Textmaschine enthält je Position exakt fünf skalare Metadatenfelder:

1. `title`
2. `target_keyword`
3. `category`
4. `article_type`
5. `plan_slot`

Artikeltext, HTML, Überschriften, Tabellen, Listen, Links, Design-, Format- oder Qualitätsdaten sind verboten und führen fail-closed zur Blockade. Der Compiler schreibt weder WordPress-Daten noch Pluginoptionen und startet keine Artikelproduktion.

Neue oder später ergänzte Beitragstypen werden aus der SEO-Taxonomie gelesen und semantisch geprüft. Solange die unveränderte Production Machine 6.7.9 einen Typ nicht registriert und freigibt, bleibt der Titel im Compiler sicher zurückgehalten; die Textmaschine wird dafür nicht verändert.

Die 1.124 geschützten Ausgangskategorien bilden den validierten Referenzbestand. Eine fehlende, umbenannte oder unklare Einzelkategorie blockiert nicht mehr den vollständigen Compilerlauf: Nur die betroffene Kategorie bleibt ausgeschlossen und wird diagnostisch ausgewiesen. Eindeutig identifizierte Slug-Abweichungen sowie neue vollständige, technisch flache Kategorien und Beitragstypen werden read-only akzeptiert. Unbekannte Typen werden nicht in die Textmaschine gedrückt, sondern bis zu deren eigener späterer Freigabe zurückgehalten. Echte Strukturdefekte innerhalb einer als nutzbar ausgewiesenen Kategorie bleiben global fail-closed.


## 0.6.8

Die Quellbindung ist auf PSTE 0.10.8-staging aktualisiert. Der Handoff besitzt zusätzlich eine exakt geschlossene Top-Level- und Positionsstruktur; jedes unbekannte oder nicht skalare Feld blockiert fail-closed.

## Exakte Übergabegrenze 0.6.8

Der an die Textmaschine gerichtete Metadatenblock besitzt eine feste Top-Level-Struktur. Jede Position enthält ausschließlich die fünf skalaren Felder `title`, `target_keyword`, `category`, `article_type` und `plan_slot`. Zusätzliche Felder, verschachtelte Werte, Markup, Veröffentlichungsfreigaben oder Inhalts-/Formatkennzeichen blockieren den gesamten Handoff fail-closed. Der Compiler liest Produktionsverträge und vorhandene Inhalte nur zur Kompatibilitäts- und Dublettenprüfung; er schreibt weder in WordPress noch in die Textmaschine.


## Signierte Laufzeitschema-Bindung

Die Compiler-Vorschau akzeptiert ausschließlich die im geprüften SEO-Quellvertrag gebundene Kombination aus Engine-Version und Datenbankschema. Für PSTE 0.10.13-staging ist dies Schema 12. Abweichende oder fehlende Schemata werden schreibfrei und fail-closed blockiert.



## 0.7.2

- Numerische WordPress-Version `0.7.2`, separater Buildmarker `0.7.2-pste-0.10.10-hardchain-verified`.
- Schreibfreie Selbstintegritätsprüfung des Compilerpakets vor jeder Vorschau.
- Kandidaten mit `body_html`, `body_text`, `post_content`, Fact-Packs, Claims oder Formatpayloads werden einzeln fail-closed zurückgehalten statt stillschweigend bereinigt.
- Konkrete Diagnose bei alter, gemischter oder unvollständig ersetzter Installation.
- Quellbindung bleibt exakt auf PSTE 0.10.10-staging / Schema 10.

## 0.7.1

- Aktualisiert ausschließlich die exakte, schreibfreie SEO-Quellbindung auf PSTE 0.10.10-staging mit 108 gebundenen Dateien und Schema 10.
- Keine Änderung an Compilerlogik, Slotzuordnung, Metadatenvertrag, Textmaschine, Artikelinhalt, HTML, Design oder WordPress-Schreibpfaden.
- Abweichende, fehlende, zusätzliche oder manipulierte Engine-Dateien bleiben fail-closed blockiert.

> **Historischer Hinweis:** Die nachfolgenden 0.7.x-Abschnitte dokumentieren frühere, inzwischen ausdrücklich supersedierte Slot-Intent-Logik. Seit 0.13.0 besitzen `intent_angle`, Schlüsselwörter und `working_title` keinerlei Planplatz-Auswahlrecht mehr; Dublettenprüfung und technische Kapazität sind getrennt.

## 0.7.0

Ein freier kanonischer Slot wird nur noch vergeben, wenn der konkrete Titel neben dem gemeinsamen Themenfamilienbegriff mindestens ein belegbares slotspezifisches Intent-Signal mit dem kanonischen Slot teilt. Reine Familiengleichheit darf keinen beliebigen Slot mehr belegen. Fehlt ein kompatibler Slot, bleibt das Thema schreibfrei mit `BLOCKED_NO_SEMANTICALLY_COMPATIBLE_CANONICAL_SLOT` zurückgehalten.

## 0.7.3: Kanonische Planplatzabsicht fail-closed

Der Compiler bewertet für jeden Kandidaten sämtliche kanonischen Planplätze derselben Kategorie und Beitragsart. Ein Kandidat wird nur an einen eindeutig nachgewiesenen Planplatz gebunden. Allgemeine, schwache oder konkurrierende Absichten werden zurückgehalten. Ist der beste semantische Planplatz bereits belegt, gibt es keinen Rückfall auf einen schlechter passenden freien Platz. Der Nachweis wird schreibfrei im `slot_intent_gate` ausgegeben.


## 0.7.4: Quellbindung auf PSTE 0.10.11

Der Compiler akzeptiert die Themenengine 0.10.11-staging mit der isolierten, fail-closed Behandlung einzelner Kontextdatensätze ohne Query. Die Compiler-, Planplatz- und Metadatenlogik bleibt gegenüber 0.7.3 unverändert.


## 0.7.6 / reale Altbestandskette

Der Compiler akzeptiert ausschließlich den V3-Semantikkonsens der Themenengine 0.10.13 und prüft zusätzlich den vorgeschalteten Rohquery-zu-Familie-Nachweis. Planplätze werden nur bei einer eindeutig belegten Metadatenabsicht vergeben; ein belegter bester Platz führt niemals zu einem schlechteren Ersatzplatz. PAA-Evidenz aus dem bereits gespeicherten Themenbestand ist als Longtail-Herkunft zulässig. Der Handoff bleibt unverändert auf exakt fünf skalare Metadatenfelder begrenzt.

## 0.8.0: Dual-Strang-Freigabe
Der Compiler gibt einen Kandidaten nur frei, wenn technische Konsistenz, unabhängige redaktionelle Qualität und der vollständige E2E-Status PASS sind. Das Recherchekeyword bleibt unverändert und muss nicht wortwörtlich oder per Wortstamm im Titel stehen. An die Textmaschine dürfen weiterhin ausschließlich fünf skalare Metadatenfelder übergeben werden.

## 0.11.0 – unabhängige technische und redaktionelle Prüfung

Für jeden vom SEO-Quellvertrag als compilerfähig gelieferten Kandidaten laufen technischer und redaktioneller Prüfstrang unabhängig und erzeugen jeweils einen eigenen Prüfbericht. Erst danach werden beide Ergebnisse zusammen mit Duplicate-/Kannibalisierungs-, Planplatz- und finalem E2E-Gate aggregiert. Ein Strang kann den anderen weder überspringen noch ersetzen.

Der Compiler bleibt read-only. Die einzige zulässige Grenze zur geschützten Text-/Produktionsmaschine sind exakt fünf skalare Metadatenfelder: `title`, `target_keyword`, `category`, `article_type`, `plan_slot`.
