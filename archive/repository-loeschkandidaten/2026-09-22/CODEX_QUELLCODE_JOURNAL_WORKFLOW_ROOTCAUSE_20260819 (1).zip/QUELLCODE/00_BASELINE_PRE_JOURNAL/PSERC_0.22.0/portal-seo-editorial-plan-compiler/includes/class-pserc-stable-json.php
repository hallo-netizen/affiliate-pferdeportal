<?php
if (!defined('ABSPATH')) { return; }

final class PSERC_Stable_Json {
    public static function canonicalize($value) {
        if (!is_array($value)) { return $value; }
        if (self::isList($value)) {
            $out=[];
            foreach ($value as $item) { $out[]=self::canonicalize($item); }
            return $out;
        }
        $keys=array_keys($value);
        sort($keys, SORT_STRING);
        $out=[];
        foreach ($keys as $key) { $out[(string)$key]=self::canonicalize($value[$key]); }
        return $out;
    }

    public static function encode($value): string {
        $flags=JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION;
        $json=function_exists('wp_json_encode') ? wp_json_encode(self::canonicalize($value),$flags) : json_encode(self::canonicalize($value),$flags);
        if (!is_string($json)) { throw new RuntimeException('PSERC_JSON_ENCODE_FAILED'); }
        return $json;
    }

    public static function hash($value): string { return hash('sha256',self::encode($value)); }

    public static function isList(array $value): bool {
        $index=0;
        foreach ($value as $key=>$_) { if ($key!==$index++) { return false; } }
        return true;
    }
}
