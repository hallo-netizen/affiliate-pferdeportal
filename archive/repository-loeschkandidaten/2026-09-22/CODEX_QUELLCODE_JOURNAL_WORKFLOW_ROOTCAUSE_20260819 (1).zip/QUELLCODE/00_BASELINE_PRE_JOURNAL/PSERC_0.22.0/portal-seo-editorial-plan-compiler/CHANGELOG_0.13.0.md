# 0.13.0 – Root-Cause Intent/Slot Separation

- Entfernt jede Wort-/Intent-/Titel-zu-Slot-Zuordnung aus dem Compiler.
- Planplätze sind nur technische, deterministische Kapazität für bereits geprüfte Kategorie + Beitragsart.
- Neues separates read-only Semantic-Duplicate-Gate für Bestand und Kandidaten untereinander.
- Eindeutige semantische Dubletten blockieren; mehrdeutige Cross-Type-Überschneidungen werden review-pflichtig statt umgedeutet.
- Keine Änderung an PPM 6.7.9, Textqualität, Textstruktur, HTML, Formatierung oder Design.
