<?php
if (!defined('ABSPATH')) { return; }

final class PSERC_Plugin {
    public static function init(): void {
        PSERC_PPM_Bypass_Guard::init();
        if (is_admin()) {
            PSERC_Admin::init();
            PSERC_Production_Trigger::init();
        }
    }
}
