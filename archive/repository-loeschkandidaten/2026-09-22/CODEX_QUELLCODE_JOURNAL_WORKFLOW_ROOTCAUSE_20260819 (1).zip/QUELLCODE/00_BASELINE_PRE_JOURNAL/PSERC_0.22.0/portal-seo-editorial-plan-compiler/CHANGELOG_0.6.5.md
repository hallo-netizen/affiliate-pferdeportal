# 0.6.5-category-quarantine-readonly

- Akzeptiert den aktuellen PSTE-V3-Baselinevertrag mit kategorieweiser Quarantäne.
- Fehlende historische Schutzkategorien werden diagnostiziert, blockieren aber nicht mehr alle eindeutig aufgelösten Kategorien.
- Neue, vollständig belegte Beitragsarten und Kategorien werden dynamisch read-only registriert.
- Malforme, verschachtelte, doppelte oder pfadinkonsistente aufgelöste Kategorien bleiben fail-closed blockiert.
- Übergabe bleibt strikt auf fünf Metadatenfelder begrenzt: title, target_keyword, category, article_type, plan_slot.
- Keine Änderung an Textmaschine, Inhaltsqualität, HTML, Design oder Produktionslogik.
