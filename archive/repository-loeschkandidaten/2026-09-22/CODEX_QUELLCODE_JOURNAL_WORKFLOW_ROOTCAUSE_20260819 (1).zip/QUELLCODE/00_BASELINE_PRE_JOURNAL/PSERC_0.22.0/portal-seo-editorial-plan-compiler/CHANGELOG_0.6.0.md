# 0.6.0-portal-evidence-readonly

- Ersetzt die externe Live-SERP-Evidenzpflicht durch eine schreibfreie Portal-Themenevidenz.
- Akzeptiert nur Longtail-Herkunft aus Keyword Suggestions und Related Keywords sowie optional GSC/Internal Search.
- Verlangt aktuellen Portal-Kontext und eine exakt validierte bestehende Kategorie.
- Ergänzt den fail-closed Schutz gegen Artikelinhalt, HTML, Design-, Format- und Qualitätsfelder.
- Erlaubt neutrale, familienbezogene Beratung-Longtails ohne künstliches Beratungsschlagwort, sofern kein widersprüchliches Typsignal vorliegt und die bestehende Beratungskategorie exakt validiert ist.
- Handoff bleibt strikt auf exakt fünf skalare Metadatenfelder begrenzt.
- Production Machine 6.7.9 und Textproduktionslogik bleiben unverändert.
