# 0.6.4-portal-taxonomy-v3-readonly

- Bindet ausschließlich PSTE 0.10.4-staging.
- Prüft den neuen read-only Strukturvertrag V3: Portal-Seitenpfad und flache WordPress-Kategorie bleiben getrennte Hierarchien.
- Prüft bei allen geschützten Kategorien den vollständigen Portalpfad sowie Name, Beitragstyp und Themenfamilie.
- Blockiert fehlende geschützte Kategorien, verschachtelte Produktionskategorien, unvollständige Produktseitenbindungen und widersprüchliche Portalpfade.
- Akzeptiert zusätzliche, später ergänzte Beitragstyp-Kategorien nur als vollständige, eindeutige und flache Live-V3-Kategorien; die Textmaschinenfähigkeit wird weiterhin separat und read-only geprüft.
- Die SEO-Quellbindung blockiert neben geänderten und fehlenden Dateien nun auch jede nicht deklarierte Zusatzdatei im SEO-Pluginordner.
- Compiler-Handoff bleibt unverändert auf exakt fünf skalare Metadatenfelder begrenzt.
- Keine Änderung an Textmaschine, Inhalt, Qualität, HTML oder Design.
