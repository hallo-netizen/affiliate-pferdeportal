<?php
if (!defined('ABSPATH')) { return; }
/** @deprecated Compatibility wrapper. Use PSERC_Assignment_Consistency_Gate. */
final class PSERC_Semantic_Assignment_Gate {
    public static function evaluate(array $topic,?array $forcedBaseline=null,?array $validatedStructure=null): array {return PSERC_Assignment_Consistency_Gate::evaluate($topic,$forcedBaseline,$validatedStructure);}
}
