# 0.5.4

- Ausschließlich die exakte read-only Quellbindung auf PSTE 0.9.3-staging aktualisiert.
- Compilerlogik, fünf Metadatenfelder, semantische Firewall, Produktionsmaschinenbindung und alle Qualitäts-/Freigaberegeln bleiben byteidentisch zu 0.5.3.
- Keine Text-, HTML-, Design-, Artikel- oder WordPress-Inhaltsschreibpfade.
