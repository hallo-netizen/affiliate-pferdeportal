# Portal SEO Redaktionsplan Compiler 0.14.0

## Systemweite Planplatz-Identität V2

- Planplätze bleiben rein technische Kapazität innerhalb bereits feststehender Kategorie + Artikelart.
- `plan_slot` wird domain-separiert ausschließlich aus `canonical_article_id` erzeugt.
- `working_title`, `intent_angle`, Suchbegriffe, Produktions-/Arbeitstitel, sichtbare Kategorienamen sowie alle Inhalts-/Format-/Designwerte haben keinerlei Identitäts- oder Routingautorität.
- Der exakt fünfskalare Handoff bleibt unverändert. Der reale Verbraucher ist der freigegebene Recherche-/Textprozess, nicht PPM direkt.
- Das vollständige PPM-Paket muss vor PPM-Preflight die intern aus `plan_slot` aufgelöste `canonical_article_id` tragen; andernfalls blockiert der vorgeschaltete Verifier.
- Keine Änderung an PPM 6.7.9, Artikelerzeugung, Textqualität, HTML, Formatierung oder Design.
