<?php
if (!defined('ABSPATH')) { return; }

/**
 * Exact-five -> approved production-package -> unchanged PPM 6.7.9 bridge.
 *
 * This class owns identity continuity only. It never creates, edits or derives
 * article content, HTML, formatting, prompts, fact packs, quality bindings or design.
 * Content-bearing production-package fields remain opaque and byte/value-identical.
 */
final class PSERC_PPM_Intake_Bridge {
    public const CONTRACT='PSERC_PPM_INTAKE_BRIDGE_V3_UNBOUNDED_READY_SET_INTERNAL_PPM679_CHUNKS';
    private const EXACT_KEYS=['title','target_keyword','category','article_type','plan_slot'];

    /**
     * Validate the exact-five batch and an already approved PPM production package.
     * The returned package is exactly the input package; no content-bearing field is rewritten.
     *
     * @return array<string,mixed>
     */
    public static function prepare(array $batch,array $productionPackage,?array $productionSnapshot=null): array {
        $boundary=PSERC_Metadata_Boundary::validateBatch($batch);
        if(empty($boundary['ok']))return self::blocked('PSERC_BRIDGE_METADATA_BOUNDARY_BLOCKED',['boundary'=>$boundary]);

        $snapshot=$productionSnapshot??PSERC_Production_Reader::snapshot();
        if(empty($snapshot['ok']))return self::blocked('PSERC_BRIDGE_PRODUCTION_CAPABILITY_BLOCKED',['production_snapshot'=>$snapshot]);
        if((string)($snapshot['version']??'')!=='6.7.9')return self::blocked('PSERC_BRIDGE_PPM_VERSION_UNSUPPORTED',['actual'=>$snapshot['version']??null]);

        $plan=is_array($snapshot['plan']??null)?$snapshot['plan']:[];
        $slots=array_values(array_filter((array)($plan['slots']??[]),'is_array'));
        if(!$slots)return self::blocked('PSERC_BRIDGE_CANONICAL_PLAN_MISSING');

        $byToken=[];$tokenCollisions=[];
        foreach($slots as $slot){
            $cid=trim((string)($slot['canonical_article_id']??''));
            if($cid==='')return self::blocked('PSERC_BRIDGE_CANONICAL_ID_MISSING');
            try{$token=PSERC_Plan_Slot_Identity::tokenFromCanonicalId($cid);}catch(Throwable $e){return self::blocked('PSERC_BRIDGE_PLAN_SLOT_IDENTITY_FAILED',['error'=>$e->getMessage()]);}
            if(isset($byToken[$token]))$tokenCollisions[]=$token;
            $byToken[$token]=$slot;
        }
        if($tokenCollisions)return self::blocked('PSERC_BRIDGE_PLAN_SLOT_TOKEN_COLLISION',['count'=>count(array_unique($tokenCollisions))]);

        $contract=(string)($productionPackage['contract']??'');
        if(!in_array($contract,['production_plan_v4','production_plan_v5'],true))return self::blocked('PSERC_BRIDGE_PPM_PLAN_CONTRACT_UNSUPPORTED',['contract'=>$contract]);
        if((string)($productionPackage['required_plugin_version']??'')!=='6.7.9')return self::blocked('PSERC_BRIDGE_PPM_PLAN_VERSION_MISMATCH',['actual'=>$productionPackage['required_plugin_version']??null]);
        $pitems=$productionPackage['items']??null;$mitems=$batch['items']??null;
        if(!is_array($pitems)||!is_array($mitems)||count($pitems)!==count($mitems))return self::blocked('PSERC_BRIDGE_ITEM_COUNT_MISMATCH',['metadata_count'=>is_array($mitems)?count($mitems):-1,'package_count'=>is_array($pitems)?count($pitems):-1]);
        if(count($pitems)<1)return self::blocked('PSERC_BRIDGE_ITEM_COUNT_OUT_OF_RELEASE_SCOPE',['count'=>count($pitems)]);

        $byCanonical=[];
        foreach($pitems as $i=>$pitem){
            if(!is_array($pitem))return self::blocked('PSERC_BRIDGE_PACKAGE_ITEM_INVALID',['index'=>$i]);
            $cid=trim((string)($pitem['canonical_article_id']??''));
            if($cid==='')return self::blocked('PSERC_BRIDGE_CANONICAL_ID_REQUIRED_BEFORE_PPM',['index'=>$i]);
            if(isset($byCanonical[$cid]))return self::blocked('PSERC_BRIDGE_DUPLICATE_CANONICAL_ID',['index'=>$i,'canonical_article_id'=>$cid]);
            $byCanonical[$cid]=$pitem;
        }

        $resolved=[];$seenCanonical=[];
        foreach($mitems as $i=>$item){
            if(!is_array($item))return self::blocked('PSERC_BRIDGE_EXACT_FIVE_SHAPE_DRIFT',['index'=>$i,'keys'=>[]]);
            $actualKeys=array_keys($item);$expectedKeys=self::EXACT_KEYS;sort($actualKeys);sort($expectedKeys);
            if($actualKeys!==$expectedKeys)return self::blocked('PSERC_BRIDGE_EXACT_FIVE_SHAPE_DRIFT',['index'=>$i,'keys'=>array_keys($item)]);
            $token=(string)$item['plan_slot'];$slot=$byToken[$token]??null;
            if(!is_array($slot))return self::blocked('PSERC_BRIDGE_UNKNOWN_PLAN_SLOT',['index'=>$i]);
            $cid=(string)$slot['canonical_article_id'];
            if(isset($seenCanonical[$cid]))return self::blocked('PSERC_BRIDGE_DUPLICATE_RESOLVED_CANONICAL_ID',['index'=>$i,'canonical_article_id'=>$cid]);
            $seenCanonical[$cid]=true;
            if((string)($slot['category_slug']??'')!==(string)$item['category'])return self::blocked('PSERC_BRIDGE_CATEGORY_SLOT_MISMATCH',['index'=>$i,'canonical_article_id'=>$cid]);
            if((string)($slot['article_type']??'')!==(string)$item['article_type'])return self::blocked('PSERC_BRIDGE_TYPE_SLOT_MISMATCH',['index'=>$i,'canonical_article_id'=>$cid]);
            if(($slot['production_supported_by_current_engine']??false)!==true||($slot['draft_generation_allowed']??false)!==true||($slot['publish_allowed']??null)!==false)return self::blocked('PSERC_BRIDGE_SLOT_NOT_NORMAL_DRAFT_ENABLED',['index'=>$i,'canonical_article_id'=>$cid]);
            $pitem=$byCanonical[$cid]??null;
            if(!is_array($pitem))return self::blocked('PSERC_BRIDGE_RESOLVED_ID_NOT_IN_PPM_PACKAGE',['index'=>$i,'canonical_article_id'=>$cid]);
            $check=self::verifyPackageItem($item,$pitem,$slot,$i);
            if(empty($check['ok']))return $check;
            $resolved[]=[
                'index'=>$i,
                'plan_slot'=>$token,
                'canonical_article_id'=>$cid,
                'category'=>(string)$item['category'],
                'article_type'=>(string)$item['article_type'],
                'working_title_consumed'=>false,
                'intent_angle_consumed'=>false,
                'content_or_design_modified'=>false,
            ];
        }
        if(count($seenCanonical)!==count($byCanonical))return self::blocked('PSERC_BRIDGE_PACKAGE_CONTAINS_UNREQUESTED_CANONICAL_ITEM');

        $contentBefore=self::opaqueContentFingerprint($productionPackage);
        $report=[
            'contract'=>self::CONTRACT,
            'status'=>'PSERC_PPM_INTAKE_BRIDGE_PREPARED',
            'exact_five_boundary_status'=>(string)$boundary['status'],
            'external_handoff_fields'=>self::EXACT_KEYS,
            'external_handoff_field_count'=>5,
            'plan_slot_identity_contract'=>PSERC_Plan_Slot_Identity::CONTRACT,
            'resolved_items'=>$resolved,
            'canonical_article_id_present_before_ppm'=>true,
            'working_title_identity_allowed'=>false,
            'intent_angle_identity_allowed'=>false,
            'title_identity_allowed'=>false,
            'content_or_design_generation_allowed'=>false,
            'content_or_design_rewrite_allowed'=>false,
            'ppm_version'=>'6.7.9',
            'ppm_package_content_surface_sha256'=>$contentBefore,
            'write_attempted_by_bridge'=>false,
            'publish_allowed'=>false,
        ];
        $report['report_sha256']=PSERC_Stable_Json::hash($report);
        return ['ok'=>true,'status'=>$report['status'],'report'=>$report,'production_package'=>$productionPackage,'production_snapshot'=>$snapshot];
    }

    /**
     * Execute the unchanged PPM normal-draft pipeline after identity verification.
     * The approved STARTMASTER 0039 research/text process owns the finished canonical content. PPM remains unchanged and only validates the bound package, creates the draft and verifies readback.
     *
     * @return array<string,mixed>
     */
    public static function execute(array $batch,array $productionPackage,array $runtimeContext,?array $productionSnapshot=null): array {
        $prepared=self::prepare($batch,$productionPackage,$productionSnapshot);
        if(empty($prepared['ok']))return $prepared;
        if(!defined('PPM679_VERSION')||(string)PPM679_VERSION!=='6.7.9'||!class_exists('PPM679_Normal_Draft_Pipeline')||!class_exists('PPM679_Editorial_Plan_Registry'))return self::blocked('PSERC_BRIDGE_PPM_RUNTIME_NOT_LOADED');

        $identityProof=self::proveRuntimeCanonicalIdentity((array)$prepared['report']['resolved_items']);
        if(empty($identityProof['ok']))return self::blocked('PSERC_BRIDGE_PPM_CANONICAL_ID_PATH_UNPROVEN',['identity_proof'=>$identityProof]);

        $package=(array)$prepared['production_package'];
        $before=PSERC_Stable_Json::hash($package);$contentBefore=(string)$prepared['report']['ppm_package_content_surface_sha256'];
        $chunks=self::buildInternalPpmChunks($package);
        if(empty($chunks['ok']))return $chunks;
        $results=[];$articleCount=0;
        foreach((array)$chunks['chunks'] as $chunkIndex=>$chunk){
            $chunkContext=$runtimeContext;
            $baseRequest=(string)($runtimeContext['request_id']??'');
            if($baseRequest==='')return self::blocked('PSERC_BRIDGE_RUNTIME_REQUEST_ID_MISSING');
            $chunkHash=PSERC_Stable_Json::hash($chunk);
            $chunkContext['request_id']='pserc-ppm-chunk-'.substr(hash('sha256',$baseRequest.'|'.(string)$chunkIndex.'|'.$chunkHash),0,40);
            $result=PPM679_Normal_Draft_Pipeline::execute_plan($chunk,$chunkContext);
            $ppmStatus=(string)($result['artifact']['status']??'');
            if($ppmStatus!=='NORMAL_DRAFT_END_TO_END_READBACK_PASS_AWAITING_USER_CONTENT_REVIEW_NO_PUBLISH')return self::blocked('PSERC_BRIDGE_PPM_EXECUTION_NOT_SUCCESSFUL',['failed_chunk_index'=>$chunkIndex,'completed_chunk_count'=>count($results),'ppm_result'=>$result,'ppm_status'=>$ppmStatus,'runtime_identity_proof'=>$identityProof]);
            $results[]=$result;$articleCount+=(int)($result['artifact']['article_count']??count((array)($chunk['items']??[])));
        }
        $after=PSERC_Stable_Json::hash($package);$contentAfter=self::opaqueContentFingerprint($package);
        if(!hash_equals($before,$after)||!hash_equals($contentBefore,$contentAfter))return self::blocked('PSERC_BRIDGE_INPUT_PACKAGE_MUTATED_DURING_EXECUTION');

        $ppmResult=count($results)===1?$results[0]:self::aggregatePpmResults($results,$articleCount);
        return [
            'ok'=>true,
            'status'=>'PSERC_PPM_INTAKE_BRIDGE_EXECUTED',
            'bridge_report'=>$prepared['report'],
            'runtime_identity_proof'=>$identityProof,
            'ppm_internal_chunk_count'=>count($results),
            'ppm_internal_execution_policy'=>['maximum_articles_per_chunk'=>4,'maximum_articles_per_type_per_chunk'=>1,'user_facing_quantity_limit'=>false],
            'ppm_result'=>$ppmResult,
            'ppm_chunk_results'=>$results,
            'input_package_sha256_before'=>$before,
            'input_package_sha256_after'=>$after,
            'content_design_surface_sha256_before'=>$contentBefore,
            'content_design_surface_sha256_after'=>$contentAfter,
            'content_design_surface_identical'=>hash_equals($contentBefore,$contentAfter),
            'working_title_fallback_required'=>false,
            'write_attempted_by_bridge'=>false,
            'publish_allowed'=>false,
        ];
    }

    /** Split only the execution wrapper. Every item remains byte/value-identical and PPM 6.7.9 stays unchanged. */
    private static function buildInternalPpmChunks(array $package): array {
        $items=array_values(array_filter((array)($package['items']??[]),'is_array'));if(!$items)return self::blocked('PSERC_BRIDGE_INTERNAL_CHUNK_SOURCE_EMPTY');
        $pending=$items;$chunks=[];
        while($pending){
            $used=[];$chunkItems=[];$rest=[];
            foreach($pending as $item){
                $type=(string)($item['article_type']??'');
                if(count($chunkItems)<4&&!isset($used[$type])){$chunkItems[]=$item;$used[$type]=true;}else{$rest[]=$item;}
            }
            if(!$chunkItems)return self::blocked('PSERC_BRIDGE_INTERNAL_CHUNK_PROGRESS_FAILED');
            $chunk=$package;$chunk['items']=$chunkItems;$chunks[]=$chunk;$pending=$rest;
        }
        return ['ok'=>true,'status'=>'PSERC_BRIDGE_INTERNAL_PPM_CHUNKS_READY','chunks'=>$chunks,'chunk_count'=>count($chunks),'user_facing_quantity_limit'=>false];
    }

    /** Preserve the familiar PPM success status while exposing all unchanged internal PPM results. */
    private static function aggregatePpmResults(array $results,int $articleCount): array {
        $drafts=[];$readbackItems=[];$checkItems=[];
        foreach($results as $r){$a=(array)($r['artifact']??[]);foreach((array)($a['drafts']??[]) as $x)$drafts[]=$x;foreach((array)($a['draft_readback']['items']??[]) as $x)$readbackItems[]=$x;foreach((array)($a['check_only']['items']??[]) as $x)$checkItems[]=$x;}
        $artifact=[
            'contract'=>'PSERC_PPM679_INTERNAL_MULTI_EXECUTION_AGGREGATE_V1','version'=>'6.7.9','status'=>'NORMAL_DRAFT_END_TO_END_READBACK_PASS_AWAITING_USER_CONTENT_REVIEW_NO_PUBLISH',
            'article_count'=>$articleCount,'internal_ppm_run_count'=>count($results),'check_only'=>['status'=>'CLOSED_CHAIN_CHECK_OK','items'=>$checkItems],
            'draft_readback'=>['status'=>'NORMAL_DRAFT_READBACK_BATCH_PASS','items'=>$readbackItems],'drafts'=>$drafts,'user_action_required'=>'CONTENT_REVIEW_NO_PUBLISH','publish_allowed'=>false,
        ];
        $artifact['report_hash']=PSERC_Stable_Json::hash($artifact);
        return ['artifact'=>$artifact,'gate'=>['ok'=>true,'status'=>'PSERC_PPM679_INTERNAL_MULTI_EXECUTION_ALL_PASS'],'filename'=>'ppm-normal-draft-multi-run-pass.json'];
    }

    /** @return array<string,mixed> */
    private static function verifyPackageItem(array $meta,array $pitem,array $slot,int $index): array {
        $cid=(string)$slot['canonical_article_id'];
        if((string)($pitem['canonical_article_id']??'')!==$cid)return self::blocked('PSERC_BRIDGE_PACKAGE_CANONICAL_ID_MISMATCH',['index'=>$index]);
        // STARTMASTER 0039 / PPM production_plan_v4 does not carry the external Exact-Five plan_slot.
        // The opaque plan_slot is derived upstream from canonical_article_id and must be proven against
        // the frozen canonical plan slot here. Injecting plan_slot into the protected PPM plan is forbidden.
        if(array_key_exists('plan_slot',$pitem))return self::blocked('PSERC_BRIDGE_FOREIGN_PLAN_SLOT_FIELD_FORBIDDEN_IN_PPM_PACKAGE',['index'=>$index]);
        $expectedToken=PSERC_Plan_Slot_Identity::token($slot);
        if(!hash_equals($expectedToken,(string)$meta['plan_slot']))return self::blocked('PSERC_BRIDGE_EXTERNAL_PLAN_SLOT_CANONICAL_ID_MISMATCH',['index'=>$index,'canonical_article_id'=>$cid]);
        if((string)($pitem['topic']??'')!==(string)$meta['title'])return self::blocked('PSERC_BRIDGE_PACKAGE_TITLE_MISMATCH',['index'=>$index]);
        if((string)($pitem['target_keyword']??'')!==(string)$meta['target_keyword'])return self::blocked('PSERC_BRIDGE_PACKAGE_TARGET_KEYWORD_MISMATCH',['index'=>$index]);
        if((string)($pitem['article_type']??'')!==(string)$meta['article_type'])return self::blocked('PSERC_BRIDGE_PACKAGE_ARTICLE_TYPE_MISMATCH',['index'=>$index]);

        $canonical=is_array($pitem['canonical_article']??null)?$pitem['canonical_article']:null;
        $runtime=is_array($pitem['runtime_order']??null)?$pitem['runtime_order']:null;
        if(!$canonical||!$runtime)return self::blocked('PSERC_BRIDGE_APPROVED_TEXT_PROCESS_PACKAGE_INCOMPLETE',['index'=>$index]);
        if((string)($canonical['title']??'')!==(string)$meta['title'])return self::blocked('PSERC_BRIDGE_CANONICAL_ARTICLE_TITLE_DRIFT',['index'=>$index]);
        if((string)($canonical['article_type']??'')!==(string)$meta['article_type'])return self::blocked('PSERC_BRIDGE_CANONICAL_ARTICLE_TYPE_DRIFT',['index'=>$index]);
        if((string)($runtime['title']??'')!==(string)$meta['title'])return self::blocked('PSERC_BRIDGE_RUNTIME_ORDER_TITLE_DRIFT',['index'=>$index]);
        if((string)($runtime['article_type']??'')!==(string)$meta['article_type'])return self::blocked('PSERC_BRIDGE_RUNTIME_ORDER_TYPE_DRIFT',['index'=>$index]);

        $categorySlug='';
        if(is_array($pitem['category_binding']??null))$categorySlug=(string)($pitem['category_binding']['slug']??'');
        if($categorySlug===''&&is_array($pitem['quality_binding']??null)){
            $q=(array)$pitem['quality_binding'];
            if(is_array($q['wordpress_category']??null))$categorySlug=(string)($q['wordpress_category']['slug']??'');
            elseif(is_array($q['expected_category']??null))$categorySlug=(string)($q['expected_category']['slug']??'');
        }
        if($categorySlug!==''&&$categorySlug!==(string)$meta['category'])return self::blocked('PSERC_BRIDGE_PACKAGE_CATEGORY_DRIFT',['index'=>$index,'actual'=>$categorySlug,'expected'=>$meta['category']]);
        return ['ok'=>true];
    }

    /** @return array<string,mixed> */
    private static function proveRuntimeCanonicalIdentity(array $resolved): array {
        $rows=[];
        foreach($resolved as $row){
            $cid=(string)($row['canonical_article_id']??'');
            $category=(string)($row['category']??'');$type=(string)($row['article_type']??'');
            // Intentionally wrong title: a PASS proves the canonical-id branch wins before working_title fallback.
            $probe=['canonical_article_id'=>$cid,'plan_item_key'=>'','title'=>'__PSERC_CANONICAL_IDENTITY_PROBE_MUST_NOT_MATCH_WORKING_TITLE__','topic'=>'__PSERC_CANONICAL_IDENTITY_PROBE_MUST_NOT_MATCH_WORKING_TITLE__','category_slug'=>$category,'article_type'=>$type];
            $slot=PPM679_Editorial_Plan_Registry::find_slot($probe);
            $ok=is_array($slot)&&(string)($slot['canonical_article_id']??'')===$cid;
            $rows[]=['canonical_article_id'=>$cid,'ok'=>$ok,'working_title_probe_used'=>false,'returned_canonical_article_id'=>is_array($slot)?(string)($slot['canonical_article_id']??''):''];
            if(!$ok)return ['ok'=>false,'status'=>'PPM_CANONICAL_ID_FIRST_BRANCH_NOT_PROVEN','rows'=>$rows];
        }
        return ['ok'=>true,'status'=>'PPM_CANONICAL_ID_FIRST_BRANCH_PROVEN_WITH_NONMATCHING_TITLE','rows'=>$rows,'working_title_fallback_reachable_on_approved_path'=>false];
    }

    /** Hash only content/quality/design-bearing package fields; never interpret or rewrite them. */
    private static function opaqueContentFingerprint(array $package): string {
        $rows=[];
        foreach((array)($package['items']??[]) as $item){
            if(!is_array($item))continue;
            $keep=[];
            foreach(['source_order_id','source_snapshot_id','source_hashes','contract_hashes','gold_core_binding','runtime_order','canonical_article','quality_binding','quality_binding_hash','section_requirements','section_requirements_hash'] as $key){if(array_key_exists($key,$item))$keep[$key]=$item[$key];}
            $rows[]=$keep;
        }
        return PSERC_Stable_Json::hash($rows);
    }

    /** @return array<string,mixed> */
    private static function blocked(string $reason,array $extra=[]): array{return array_merge(['ok'=>false,'status'=>'PSERC_PPM_INTAKE_BRIDGE_BLOCKED','reason_codes'=>[$reason],'message'=>$reason,'write_attempted_by_bridge'=>false,'publish_allowed'=>false],$extra);}
}
