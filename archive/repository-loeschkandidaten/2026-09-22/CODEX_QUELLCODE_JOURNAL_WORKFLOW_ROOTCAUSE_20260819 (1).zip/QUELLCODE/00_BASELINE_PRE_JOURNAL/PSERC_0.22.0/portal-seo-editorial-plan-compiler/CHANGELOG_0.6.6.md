# 0.6.6-category-name-alias-readonly

- Aktualisiert ausschließlich die exakte, schreibfreie Quellbindung auf PSTE 0.10.6.
- Akzeptiert die von PSTE korrekt aufgelösten aktuellen Kategorienamen und unveränderten Slugs.
- Handoff bleibt auf exakt fünf skalare Metadatenfelder begrenzt.
- Keine Änderung an Textmaschine, Artikelerzeugung, Inhalt, HTML, Qualität oder Design.
