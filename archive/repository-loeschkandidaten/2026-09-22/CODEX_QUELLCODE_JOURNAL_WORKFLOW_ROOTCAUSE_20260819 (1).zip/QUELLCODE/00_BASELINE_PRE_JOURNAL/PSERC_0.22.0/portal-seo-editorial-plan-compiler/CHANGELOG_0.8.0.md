# Portal SEO Editorial Plan Compiler 0.8.0 – Dual-Strang Release Gate

## Änderungen
- Ehrlich benanntes Assignment-Consistency-Gate statt semantischer Qualitätsbehauptung.
- Unabhängiges Editorial-Outcome-Gate bindet das Ergebnis der SEO-Titelqualitätsprüfung kryptografisch an Rohkeyword, Titel, Familie und Artikeltyp.
- Reiner Release-Aggregator: READY nur bei TECH_PASS + EDITORIAL_PASS + E2E_PASS.
- Zielkeyword bleibt das unveränderte Recherchekeyword; kein Verbatim- oder Wortstamm-Zwang im Titel.
- Mechanische Titel-/Sprachgates machen keine semantische Qualitätsbehauptung.
- 5-Feld-Grenze bleibt exakt und enthält keine Inhalts-, Format-, Design- oder Promptdaten.
