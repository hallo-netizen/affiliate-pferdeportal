# 0.5.2-semantic-firewall-readonly

- Aktualisiert die exakte read-only Quellbindung auf Portal SEO Themenengine 0.9.2-staging.
- Behebt die Überblockierung des Struktur-Gates: alle 1.124 geschützten P4-Kategorien müssen weiterhin exakt nach Slug, Name und Typ übereinstimmen; sachfremde zusätzliche WordPress-Kategorien werden nicht mehr pauschal blockiert.
- Neue, nicht registrierte Kategorien mit den Produktionsarten FAQ, Beratung, Vergleich oder Pflege blockieren weiterhin fail-closed.
- Blockierungsseiten zeigen nun die bereits intern vorhandene, sicher begrenzte technische Ursache an, darunter Zählwerte, Slugs und Hashpräfixe; keine Zugangsdaten oder Inhalte.
- Der Metadaten-Handoff bleibt auf exakt fünf skalare Felder begrenzt.
- Keine Änderung an Production Machine, Artikelinhalt, HTML, Design, Kategorien oder Veröffentlichungslogik.
