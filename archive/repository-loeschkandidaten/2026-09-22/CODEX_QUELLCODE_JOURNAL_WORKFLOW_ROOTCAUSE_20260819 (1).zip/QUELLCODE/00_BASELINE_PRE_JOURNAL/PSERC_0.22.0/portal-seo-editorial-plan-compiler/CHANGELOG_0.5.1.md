# 0.5.1-semantic-firewall-readonly

- Der SERP-Nachweis wird kandidatengenau aus dem hashgebundenen Evidenzregister der Themenengine gelesen.
- Direkte Einzelevidenz bleibt für den kontrollierten Einartikelpfad und lokale Tests kompatibel.
- Fehlende, doppelte, beschädigte, veraltete oder nicht exakt an Kandidat und Zielkeyword gebundene Evidenz blockiert weiterhin fail-closed.
- Metadaten-Handoff bleibt exakt auf `title`, `target_keyword`, `category`, `article_type`, `plan_slot` begrenzt.
- Keine Änderungen an Production Machine, Artikelinhalt, Qualitätsprüfungen, Design oder Frontend.
