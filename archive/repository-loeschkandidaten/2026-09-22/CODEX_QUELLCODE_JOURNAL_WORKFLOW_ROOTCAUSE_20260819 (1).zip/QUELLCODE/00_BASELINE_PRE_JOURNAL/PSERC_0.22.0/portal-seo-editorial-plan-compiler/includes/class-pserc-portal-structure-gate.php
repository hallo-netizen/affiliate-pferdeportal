<?php
if (!defined('ABSPATH')) { return; }

/** Read-only validation of the current portal/page plus flat WordPress-category snapshot. */
final class PSERC_Portal_Structure_Gate {
    /** @return array<string,mixed> */
    public static function validate(?array $forcedBaseline=null,?array $forcedRegistry=null): array {
        $baseline=$forcedBaseline;
        if($baseline===null){$key=defined('PSTE_OPTION_SITE_BASELINE')?PSTE_OPTION_SITE_BASELINE:'pste_site_baseline_v1';$baseline=function_exists('get_option')?get_option($key,[]):[];}
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return self::blocked('PORTAL_STRUCTURE_LIVE_BASELINE_MISSING');
        if(($baseline['taxonomy_contract']??'')!=='PSTE_PORTAL_TAXONOMY_SNAPSHOT_V3')return self::blocked('PORTAL_STRUCTURE_TAXONOMY_CONTRACT_INVALID');
        $declared=(string)($baseline['baseline_sha256']??'');$copy=$baseline;unset($copy['baseline_sha256']);
        if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals($declared,PSERC_Stable_Json::hash($copy)))return self::blocked('PORTAL_STRUCTURE_LIVE_BASELINE_HASH_MISMATCH');
        if(($baseline['status']??'')!=='CURRENT'||!empty($baseline['unclassified_leaf_count'])||empty($baseline['taxonomy_validation']['ok']))return self::blocked('PORTAL_STRUCTURE_LIVE_BASELINE_NOT_CURRENT');
        if($forcedBaseline===null&&class_exists('PSTE_Snapshot')&&method_exists('PSTE_Snapshot','baselineStatus')){try{$fresh=PSTE_Snapshot::baselineStatus($baseline);}catch(Throwable $e){return self::blocked('PORTAL_STRUCTURE_LIVE_FRESHNESS_CHECK_FAILED');}if(empty($fresh['current']))return self::blocked('PORTAL_STRUCTURE_LIVE_BASELINE_STALE',['freshness'=>$fresh]);}

        $registry=$forcedRegistry;
        if($registry===null){$path=defined('PSERC_DIR')?PSERC_DIR.'contracts/portal-structure-registry-v1.json':'';if($path===''||!is_file($path))return self::blocked('PORTAL_STRUCTURE_REGISTRY_FILE_MISSING');try{$registry=json_decode((string)file_get_contents($path),true,512,JSON_THROW_ON_ERROR);}catch(Throwable $e){return self::blocked('PORTAL_STRUCTURE_REGISTRY_JSON_INVALID');}}
        if(!is_array($registry)||($registry['contract']??'')!=='PSERC_PORTAL_STRUCTURE_REGISTRY_V1')return self::blocked('PORTAL_STRUCTURE_REGISTRY_CONTRACT_INVALID');
        $registryHash=(string)($registry['registry_sha256']??'');$registryCopy=$registry;unset($registryCopy['registry_sha256']);
        if(!preg_match('/^[a-f0-9]{64}$/',$registryHash)||!hash_equals($registryHash,PSERC_Stable_Json::hash($registryCopy)))return self::blocked('PORTAL_STRUCTURE_REGISTRY_HASH_MISMATCH');

        $staticBySlug=[];$staticByIdentity=[];$staticEntries=[];
        foreach(array_values(array_filter((array)($registry['entries']??[]),'is_array')) as $index=>$entry){
            $slug=trim((string)($entry['category_slug']??''));$name=trim((string)($entry['category_name']??''));$type=trim((string)($entry['canonical_article_type']??''));$family=trim((string)($entry['topic_family']??''));
            if($slug===''||$name===''||$type===''||$family===''||isset($staticBySlug[$slug]))return self::blocked('PORTAL_STRUCTURE_REGISTRY_ENTRY_INVALID',['slug'=>$slug]);
            $entry['_index']=$index;$staticEntries[$index]=$entry;$staticBySlug[$slug]=$entry;$staticByIdentity[self::identity($name,$type,$family)][]=$entry;
        }

        $live=array_values(array_filter((array)($baseline['leaf_categories']??[]),'is_array'));
        if((int)($baseline['leaf_category_count']??-1)!==count($live))return self::blocked('PORTAL_STRUCTURE_LIVE_DECLARED_COUNT_MISMATCH');
        $bySlug=[];$byFamilyType=[];$ids=[];$matchedStatic=[];$staticDrift=[];
        foreach($live as $leaf){
            $id=(int)($leaf['term_id']??0);$slug=trim((string)($leaf['slug']??''));$name=trim((string)($leaf['name']??''));$type=trim((string)($leaf['article_type']??$leaf['canonical_article_type']??''));$family=trim((string)($leaf['topic_family_name']??$leaf['topic_family']??''));$familyKey=trim((string)($leaf['topic_family_key']??''));$path=trim((string)($leaf['full_path']??''));$wpParent=(int)($leaf['wp_parent_id']??$leaf['parent_id']??$leaf['parent']??0);$portalAncestors=array_values(array_map('intval',(array)($leaf['portal_ancestor_page_ids']??[])));$portalAncestorNames=array_values(array_map(static fn($v)=>trim((string)$v),(array)($leaf['portal_ancestor_page_names']??[])));$productPageId=(int)($leaf['product_page_id']??0);$productPageSlug=trim((string)($leaf['product_page_slug']??''));
            if($id<=0||$slug===''||$name===''||$type===''||$family===''||$familyKey===''||$path===''||$productPageId<=0||$productPageSlug===''||!$portalAncestors)return self::blocked('PORTAL_STRUCTURE_LIVE_ENTRY_INCOMPLETE',['term_id'=>$id,'slug'=>$slug]);
            if($wpParent!==0)return self::blocked('PORTAL_STRUCTURE_LIVE_CATEGORY_NOT_FLAT',['term_id'=>$id,'slug'=>$slug,'wp_parent_id'=>$wpParent]);
            if((int)end($portalAncestors)!==$productPageId)return self::blocked('PORTAL_STRUCTURE_LIVE_PRODUCT_PAGE_CHAIN_MISMATCH',['term_id'=>$id,'slug'=>$slug]);
            $segments=array_values(array_filter(array_map('trim',explode('>',$path)),static fn($v)=>$v!==''));$expectedSegments=array_merge($portalAncestorNames,[$name]);if(!$portalAncestorNames||count($portalAncestorNames)!==count($portalAncestors)||count($segments)!==count($expectedSegments))return self::blocked('PORTAL_STRUCTURE_LIVE_PATH_SHAPE_INVALID',['term_id'=>$id,'slug'=>$slug,'path'=>$path]);foreach($expectedSegments as $segmentIndex=>$expectedSegment){if(self::norm((string)($segments[$segmentIndex]??''))!==self::norm((string)$expectedSegment))return self::blocked('PORTAL_STRUCTURE_LIVE_PATH_SHAPE_INVALID',['term_id'=>$id,'slug'=>$slug,'path'=>$path,'segment_index'=>$segmentIndex]);}
            if(isset($bySlug[$slug]))return self::blocked('PORTAL_STRUCTURE_LIVE_DUPLICATE_SLUG',['slug'=>$slug]);if(isset($ids[$id]))return self::blocked('PORTAL_STRUCTURE_LIVE_DUPLICATE_TERM_ID',['term_id'=>$id]);
            $tuple=self::norm($familyKey).'|'.self::norm($type);if(isset($byFamilyType[$tuple]))return self::blocked('PORTAL_STRUCTURE_LIVE_DUPLICATE_FAMILY_TYPE',['first'=>$byFamilyType[$tuple],'second'=>$slug]);
            $ids[$id]=true;$byFamilyType[$tuple]=$slug;
            $entry=['term_id'=>$id,'category_slug'=>$slug,'category_name'=>$name,'canonical_article_type'=>$type,'topic_family'=>$family,'topic_family_key'=>$familyKey,'full_path'=>$path,'parent_id'=>$wpParent,'ancestor_ids'=>array_values((array)($leaf['ancestor_ids']??[])),'portal_ancestor_page_ids'=>$portalAncestors,'product_page_id'=>$productPageId,'product_page_slug'=>$productPageSlug,'branch_hash'=>(string)($leaf['branch_hash']??''),'runtime_registry_status'=>'LIVE_DYNAMIC_REGISTERED'];
            $static=$staticBySlug[$slug]??null;
            if(!is_array($static)){$matches=(array)($staticByIdentity[self::identity($name,$type,$family)]??[]);if(count($matches)===1)$static=$matches[0];}
            if(is_array($static)){
                $matchedStatic[(int)$static['_index']]=true;$entry['runtime_registry_status']='STATIC_AND_LIVE_VALIDATED';
                $drift=[];if(self::norm((string)($static['category_slug']??''))!==self::norm($slug))$drift[]='SLUG';if(self::norm((string)($static['full_path']??''))!==self::norm($path))$drift[]='PATH';
                if($drift)$staticDrift[]=['term_id'=>$id,'slug'=>$slug,'protected_slug'=>(string)($static['category_slug']??''),'drift'=>$drift];
            }
            $bySlug[$slug]=$entry;
        }
        $missingProtected=[];foreach($staticEntries as $index=>$entry)if(!isset($matchedStatic[$index]))$missingProtected[]=(string)$entry['category_slug'];
        $vocabulary=(array)($registry['capitalization_vocabulary']??[]);foreach($vocabulary as $lower=>$canonical)if(!is_string($lower)||!is_string($canonical)||$lower===''||$canonical==='')return self::blocked('PORTAL_STRUCTURE_CAPITALIZATION_VOCABULARY_INVALID');
        foreach($live as $leaf){$name=(string)($leaf['name']??'');foreach(preg_split('/\s+/u',$name)?:[] as $word){$key=function_exists('mb_strtolower')?mb_strtolower($word,'UTF-8'):strtolower($word);if($key!==''&&!isset($vocabulary[$key]))$vocabulary[$key]=$word;}}
        ksort($bySlug,SORT_STRING);ksort($vocabulary,SORT_STRING);
        return ['ok'=>true,'status'=>'PSERC_PORTAL_STRUCTURE_PASS','reason_codes'=>[],'registry_sha256'=>$registryHash,'registry_source'=>(array)($registry['source']??[]),'category_count'=>count($bySlug),'by_slug'=>$bySlug,'capitalization_vocabulary'=>$vocabulary,'live_total_leaf_category_count'=>count($live),'protected_live_category_count'=>count($matchedStatic),'dynamic_live_category_count'=>count(array_filter($bySlug,static fn($e)=>($e['runtime_registry_status']??'')==='LIVE_DYNAMIC_REGISTERED')),'missing_protected_category_count'=>count($missingProtected),'missing_protected_category_slugs'=>array_slice($missingProtected,0,25),'static_drift_count'=>count($staticDrift),'static_drift_preview'=>array_slice($staticDrift,0,25),'quarantined_category_count'=>(int)($baseline['quarantined_category_count']??0),'live_baseline_sha256'=>$declared,'live_structure_hash'=>(string)($baseline['structure_hash']??''),'write_attempted'=>false];
    }

    /** @return array<string,mixed>|null */
    public static function entry(array $validated,string $slug): ?array {$entry=$validated['by_slug'][$slug]??null;return is_array($entry)?$entry:null;}
    private static function identity(string $name,string $type,string $family): string {return self::norm($name).'|'.self::norm($type).'|'.self::norm($family);}
    private static function norm(string $v): string {$v=strtr(trim($v),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$v=function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);return trim((string)preg_replace('/[^a-z0-9]+/u',' ',$v));}
    /** @return array<string,mixed> */
    private static function blocked(string $reason,array $extra=[]): array{return array_merge(['ok'=>false,'status'=>'PSERC_PORTAL_STRUCTURE_BLOCKED','reason_codes'=>[$reason],'message'=>$reason,'write_attempted'=>false],$extra);}
}
