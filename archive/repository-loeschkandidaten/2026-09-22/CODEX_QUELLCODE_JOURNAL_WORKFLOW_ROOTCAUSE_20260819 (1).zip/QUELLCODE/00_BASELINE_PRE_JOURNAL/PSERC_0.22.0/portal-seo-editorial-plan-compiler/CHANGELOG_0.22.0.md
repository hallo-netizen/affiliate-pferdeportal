# 0.22.0 – Unbegrenzte READY-Auswahl und harmonisierte Beratungstitel-Regel

- Entfernt ausschließlich die künstliche Benutzer-/Compiler-Obergrenze für schreibbare READY-Artikel sowie die künstliche Obergrenze je Artikeltyp.
- Der Metadatenblock behält seine bestehende V2-Form; `maximum_articles = 0` und `maximum_articles_per_type = 0` bedeuten verbindlich unbegrenzt.
- PPM 6.7.9 bleibt vollständig unverändert. Größere freigegebene Mengen werden intern transparent in unveränderte PPM-6.7.9-Ausführungseinheiten zerlegt (max. 4 und max. 1 je Typ nur innerhalb der internen PPM-Einheit). Dies ist keine Benutzer-/Produktionsmengenbegrenzung und erfordert keine neue Entscheidung.
- Ausschließlich die bereits bestehende Beratungstitel-Regel `Passende … richtig auswählen` wird als wiederholtes generisches Schema verbindlich hart ausgewiesen. Alle übrigen Titelregeln bleiben unverändert und PPM-kompatibel.
- Keine Änderung an Workflow-Reihenfolge, Recherche, Textmaschine, Fact-Pack-Inhalt, Artikelinhalt, HTML, Formatierung, Design, Kategorie, Artikelart, Planplatz oder Veröffentlichung.
