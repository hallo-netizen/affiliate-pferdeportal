# Portal SEO Redaktionsplan Compiler 0.5.0-semantic-firewall-readonly

- Blockiert semantisch falsche Kategorie- und Artikeltypzuordnungen statt sie automatisch umzuhängen.
- Bindet die aktuelle P4-Struktur und den exakten Quellstand der Themenengine per SHA-256.
- Akzeptiert ausschließlich vollständige Artikeltest-SERP-Evidenz mit Kandidat und vollständiger Vergleichsinventur.
- Berechnet SERP-Überschneidungen lokal neu; alte einzelne Google-Live-Prüfungen bleiben blockiert.
- Übergibt weiterhin ausschließlich fünf skalare Metadatenfelder und startet keine Textproduktion.
