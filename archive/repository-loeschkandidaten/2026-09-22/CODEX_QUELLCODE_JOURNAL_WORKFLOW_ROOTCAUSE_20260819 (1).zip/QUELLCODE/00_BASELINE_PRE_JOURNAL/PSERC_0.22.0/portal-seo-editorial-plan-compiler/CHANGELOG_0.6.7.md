# 0.6.7-json-storage-readonly

- Aktualisiert ausschließlich die schreibfreie Quellbindung auf PSTE 0.10.7.
- Der Compiler bleibt unverändert metadata-only: exakt fünf skalare Felder, kein Text, kein HTML, keine Tabellen-, Listen-, Link-, Format-, Qualitäts- oder Designparameter.
- Keine Aktivierungs-, Migrations-, Cron-, REST- oder Produktionshooks.
