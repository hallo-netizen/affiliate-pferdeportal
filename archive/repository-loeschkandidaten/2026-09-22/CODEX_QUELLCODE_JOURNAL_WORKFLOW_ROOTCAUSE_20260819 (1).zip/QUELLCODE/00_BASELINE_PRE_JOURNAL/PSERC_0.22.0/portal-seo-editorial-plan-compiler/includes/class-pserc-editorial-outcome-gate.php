<?php
if (!defined('ABSPATH')) { return; }

/** Verifies the independent SEO editorial-quality verdict without composing or repairing anything. */
final class PSERC_Editorial_Outcome_Gate {
    /** @return array<string,mixed> */
    public static function evaluate(array $topic,string $finalTitle,string $family,string $type): array {
        $quality=(array)($topic['editorial_quality_gate']??[]);$dual=(array)($topic['editorial_dual_strand']??[]);$raw=(string)($topic['source_query']??'');$reasons=[];
        if(($quality['contract']??'')!=='PSTE_EDITORIAL_QUALITY_GATE_V4_HARD_TITLE_SURFACE_INTENT_SAFE')$reasons[]='EDITORIAL_QUALITY_CONTRACT_MISSING';
        if(($quality['status']??'')!=='PASS'||empty($quality['ok']))$reasons[]='EDITORIAL_QUALITY_NOT_PASS';
        if(($quality['composer_called']??true)!==false)$reasons[]='EDITORIAL_REVIEWER_COMPOSER_INDEPENDENCE_FAILED';
        if(($quality['title_modified']??true)!==false)$reasons[]='EDITORIAL_REVIEWER_MODIFIED_TITLE';
        if(($quality['technical_gate_result_consumed']??true)!==false)$reasons[]='EDITORIAL_REVIEWER_CONSUMED_TECHNICAL_RESULT';
        if($raw===''||!hash_equals(hash('sha256',$raw),(string)($quality['raw_query_sha256']??'')))$reasons[]='EDITORIAL_RAW_QUERY_BINDING_MISMATCH';
        if($finalTitle===''||!hash_equals(hash('sha256',$finalTitle),(string)($quality['title_sha256']??'')))$reasons[]='EDITORIAL_TITLE_BINDING_MISMATCH';
        if($family===''||!hash_equals(hash('sha256',$family),(string)($quality['family_sha256']??'')))$reasons[]='EDITORIAL_FAMILY_BINDING_MISMATCH';
        if(trim((string)($quality['article_type']??''))!==trim($type))$reasons[]='EDITORIAL_ARTICLE_TYPE_BINDING_MISMATCH';
        if((string)($dual['editorial']['status']??'')!=='PASS')$reasons[]='EDITORIAL_STRAND_NOT_PASS';
        return ['ok'=>$reasons===[],'status'=>$reasons===[]?'PSERC_EDITORIAL_OUTCOME_PASS':'PSERC_EDITORIAL_OUTCOME_BLOCKED','reason_codes'=>array_values(array_unique($reasons)),'quality_gate_sha256'=>$quality?PSERC_Stable_Json::hash($quality):'','raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'','title_sha256'=>$finalTitle!==''?hash('sha256',$finalTitle):'','write_attempted'=>false,'title_modified'=>false];
    }
}
