# Portal SEO Redaktionsplan Compiler 0.18.0

## Scope
Workflow-Supervisor-Gate und Titelvertragskorrektur vor der unveränderten PPM 6.7.9.

## Änderungen
- PSERC rewritet weiterhin niemals Titel; es validiert den von PSTE/Title Authority eingefrorenen FINAL_TITLE.
- Die alte zusätzliche Portal-Prefixregel wurde entfernt. Das exakte Target Keyword muss gemäß PPM 6.7.9 weiterhin irgendwo zusammenhängend im Titel vorkommen.
- Neuer Workflow Supervisor erzwingt die Reihenfolge Start-Gate → Bindungen → Title Lock → Exact Five → Recherche-/Provenienzattestation → Paketbindung → PPM.
- Produktionsstart verlangt vor Fact-Pack-Import eine hashgebundene Supervisor-Freigabe.
- Fehlende, veraltete oder auf andere Exact-Five-/Plan-/Fact-Pack-Hashes gebundene Freigaben blockieren fail-closed.

## Unverändert
- PPM 6.7.9
- Text-/HTML-/Format-/Designlogik
- Exact Five
- keine Recherche oder Prosa in PSERC
