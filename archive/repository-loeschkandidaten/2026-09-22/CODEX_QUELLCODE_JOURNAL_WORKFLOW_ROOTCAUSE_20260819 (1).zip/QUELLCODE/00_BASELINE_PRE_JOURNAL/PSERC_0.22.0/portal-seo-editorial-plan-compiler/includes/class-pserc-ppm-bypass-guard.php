<?php
if (!defined('ABSPATH')) { return; }

/**
 * Disables legacy/direct PPM 6.7.9 browser production entrypoints without modifying PPM bytes.
 * The PPM classes remain available to the signed PSERC supervisor/bridge internally.
 */
final class PSERC_PPM_Bypass_Guard {
    public const CONTRACT='PSERC_PPM_DIRECT_ENTRYPOINT_GUARD_V1';

    public static function init(): void {
        if(function_exists('add_action')){
            add_action('plugins_loaded',[__CLASS__,'enforce'],PHP_INT_MAX);
            add_action('admin_menu',[__CLASS__,'hideLegacyProductionMenus'],PHP_INT_MAX);
        }
    }

    public static function enforce(): void {
        if(!function_exists('remove_action'))return;
        if(class_exists('PPM679_Admin')){
            remove_action('admin_post_'.PPM679_Admin::ACTION,['PPM679_Admin','handle_run']);
            remove_action('admin_post_'.PPM679_Admin::NORMAL_ACTION,['PPM679_Admin','handle_normal_run']);
        }
        if(class_exists('PPM679_G9_Single_FAQ_Entrypoint'))remove_action('admin_post_'.PPM679_G9_Single_FAQ_Entrypoint::ACTION,['PPM679_G9_Single_FAQ_Entrypoint','handle']);
        if(class_exists('PPM679_Three_Type_Bundled_Live_Test_Entrypoint'))remove_action('admin_post_'.PPM679_Three_Type_Bundled_Live_Test_Entrypoint::ACTION,['PPM679_Three_Type_Bundled_Live_Test_Entrypoint','handle']);
    }

    public static function hideLegacyProductionMenus(): void {
        if(function_exists('remove_menu_page')&&class_exists('PPM679_Admin'))remove_menu_page(PPM679_Admin::SLUG);
        if(function_exists('remove_submenu_page')&&class_exists('PPM679_G9_Single_FAQ_Entrypoint'))remove_submenu_page('tools.php',PPM679_G9_Single_FAQ_Entrypoint::SLUG);
        if(function_exists('remove_submenu_page')&&class_exists('PPM679_Three_Type_Bundled_Live_Test_Entrypoint'))remove_submenu_page('tools.php',PPM679_Three_Type_Bundled_Live_Test_Entrypoint::SLUG);
    }

    /** @return array<string,mixed> */
    public static function declaredProtection(): array {
        return [
            'contract'=>self::CONTRACT,
            'ppm_modified'=>false,
            'legacy_admin_post_entrypoints_disabled'=>[
                'ppm679_run_v4','ppm679_run_normal_draft','ppm679_g9_single_faq','ppm679_three_type_bundled_live_test'
            ],
            'signed_supervisor_path_required'=>true,
            'content_or_html_generation_performed'=>false,
            'publish_allowed'=>false,
        ];
    }
}
