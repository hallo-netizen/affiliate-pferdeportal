# 0.11.0 – unabhängiger Dualstrang und finales E2E-Gate

- Technischer und redaktioneller Compiler-Strang werden für jeden compilerfähigen Themenkandidaten unabhängig voneinander ausgeführt.
- Technische Sperren dürfen die redaktionelle Prüfung nicht überspringen; redaktionelle Sperren dürfen technische Evidenz nicht ersetzen.
- READY entsteht erst nach beiden realen Prüfberichten und dem abschließenden E2E-/Slot-/Duplicate-Gate.
- Keine synthetisch aus einem Endstatus erzeugten Strand-PASS/FAIL-Berichte mehr.
- Compiler bleibt vollständig schreibfrei und verändert weder WordPress-Inhalte noch Production-/Textmaschine oder Design.
- Handoff unverändert exakt fünf skalare Felder: `title`, `target_keyword`, `category`, `article_type`, `plan_slot`.
