# 0.5.3

- Production-Machine-Bindung von starren fremden Dateihashes auf selbstgehashte Schnittstellen-, Freigabe- und Qualitätsverträge umgestellt.
- Planpositionszahl wird aus dem selbstgehashten kanonischen Plan gelesen und intern gegen reale eindeutige Slots geprüft; keine doppelte Compiler-Hardcodierung.
- Historische P4-Registry-Abweichungen blockieren nicht mehr den gesamten Compiler. Aktuelle Kandidaten bleiben pro Kategorie fail-closed geprüft.
- Keine automatische Umzuordnung, keine WordPress-Schreibpfade, weiterhin exakt fünf skalare Metadatenfelder.
