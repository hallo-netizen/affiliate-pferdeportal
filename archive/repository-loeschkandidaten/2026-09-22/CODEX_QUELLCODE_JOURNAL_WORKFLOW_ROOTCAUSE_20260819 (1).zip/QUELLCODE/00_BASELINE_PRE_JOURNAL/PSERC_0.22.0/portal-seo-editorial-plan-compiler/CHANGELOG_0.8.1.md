# 0.8.1

- Quellbindung auf Portal SEO Themenengine 0.18.1 aktualisiert.
- Keine Änderung der Compiler-Fachlogik oder der Fünf-Feld-Grenze.
- Der bestehende read-only SEO-Reader blockiert jetzt automatisch, solange die Themenengine wegen eines ausstehenden/fehlgeschlagenen redaktionellen Metadaten-Rebuilds nicht READY ist.
- Textmaschine, Produktionslogik, Artikelinhalt und Design bleiben unangetastet.
