<?php
if (!defined('ABSPATH')) { return; }

/**
 * Cryptographically enforced, fail-closed sequence supervisor for the STARTMASTER 0039 production path.
 *
 * IMPORTANT: This class NEVER creates or changes titles, research, claims, fact packs, article content,
 * HTML, formatting or design. It validates an offline Ed25519-signed approval that binds the exact
 * metadata, the exact 0039 production package and all independent evidence attestations before PPM 6.7.9
 * is touched. Only the public verification key is embedded here.
 */
final class PSERC_Workflow_Supervisor {
    public const CONTRACT='PSERC_WORKFLOW_SUPERVISOR_V2_SIGNED_STARTMASTER_0039';
    public const RELEASE_CONTRACT='WORKFLOW_SUPERVISOR_RELEASE_V2_SIGNED';
    private const NULLPUNKT='STARTMASTER_0039';
    private const NULLPUNKT_SHA256='9aa4f27d133f2c07543ac52df4deb7bdf1407af8d8a5b60065c3d2e98efdf862';
    private const FROZEN_WORKFLOW_SHA256='2697f1bea0aaf5d0a5d472a13a6cdbce3401e96be2fabff0d2b2d5827a82e16e';
    private const AUTHORING_PROMPT_SHA256='f3043f05daee675b8c789efff77db7467a0c43aa9b2cdeacc3b344d0ca32772f';
    private const SIGNING_KEY_ID='workflow-ed25519-153d2518dba7b025';
    private const SIGNING_PUBLIC_KEY_SHA256='153d2518dba7b025c92036583fcf86e31288a2b9f9e0977fce655225446f2a59';
    private const SIGNING_PUBLIC_KEY_B64='Mcl55V5yPSscQZjGC0BPPHoSxp2xiDNzicGDopaZDPQ=';
    private const SEQUENCE=[
        'START_GATE_PASS',
        'ASSIGNMENT_AND_PLAN_SLOT_BOUND',
        'FINAL_TITLE_LOCKED',
        'EXACT_FIVE_PASS',
        'RESEARCH_EVIDENCE_GATE_PASS',
        'AUTHORIZED_0039_RESEARCH_TEXT_PROCESS',
        'ARTICLE_ORIGIN_AND_IMMUTABILITY_GATE_PASS',
        'LANGUAGE_AND_QUALITY_PASS',
        'FACT_PACK_AND_PLAN_BOUND',
        'PPM_6_7_9_READY',
    ];
    private const RELEASE_KEYS=[
        'contract','status','nullpunkt','nullpunkt_sha256','frozen_workflow_sha256','authoring_prompt_sha256','authoring_role','created_at_utc',
        'exact_five_batch_sha256','exact_five_item_count','items','production_plan_sha256','fact_pack_bundle_sha256','ppm_version','ppm_baseline_sha256',
        'sequence','research_evidence_policy','article_origin_policy','content_generation_performed_by_supervisor','wordpress_write_performed',
        'signature_algorithm','signing_key_id','signing_public_key_sha256','release_payload_sha256','signature_b64','release_sha256'
    ];
    private const ITEM_KEYS=[
        'plan_slot','metadata_handoff_sha256','final_title_sha256','canonical_article_id','body_html_sha256','body_text_sha256','content_plan_hash','fact_pack_hash',
        'source_snapshot_id','research_evidence_gate_status','research_evidence_attestation_sha256','article_origin_gate_status','article_origin_attestation_sha256',
        'language_quality_gate_status','language_evidence_sha256','quality_evidence_sha256','authoring_process','external_rewrite_detected','trusted_self_approval','content_hash_locked'
    ];

    /** @return array<string,mixed> */
    public static function validate(array $batch,array $bundle,array $plan,array $release,array $compilerManifest,?array $productionSnapshot=null): array {
        $boundary=PSERC_Metadata_Boundary::validateBatch($batch);
        if(empty($boundary['ok']))return self::blocked('SUPERVISOR_EXACT_FIVE_BOUNDARY_BLOCKED',['boundary'=>$boundary]);
        if((int)($batch['item_count']??0)<1)return self::blocked('SUPERVISOR_EXACT_FIVE_EMPTY');

        $compiler=self::validateCompilerManifest($compilerManifest,$batch);
        if(empty($compiler['ok']))return $compiler;

        $snapshot=$productionSnapshot??PSERC_Production_Reader::snapshot();
        if(empty($snapshot['ok']))return self::blocked('SUPERVISOR_PPM_CAPABILITY_BLOCKED',['production_snapshot'=>$snapshot]);
        if((string)($snapshot['version']??'')!=='6.7.9')return self::blocked('SUPERVISOR_PPM_VERSION_DRIFT',['actual'=>$snapshot['version']??null]);

        $shape=self::exactKeys($release,self::RELEASE_KEYS,'release');
        if($shape!==null)return self::blocked('SUPERVISOR_RELEASE_SCHEMA_INVALID',['detail'=>$shape]);
        if((string)$release['contract']!==self::RELEASE_CONTRACT)return self::blocked('SUPERVISOR_RELEASE_CONTRACT_INVALID');
        if((string)$release['status']!=='PASS')return self::blocked('SUPERVISOR_RELEASE_NOT_PASS');
        if((string)$release['nullpunkt']!==self::NULLPUNKT||!hash_equals(self::NULLPUNKT_SHA256,(string)$release['nullpunkt_sha256']))return self::blocked('SUPERVISOR_NULLPUNKT_MISMATCH');
        if(!hash_equals(self::FROZEN_WORKFLOW_SHA256,(string)$release['frozen_workflow_sha256']))return self::blocked('SUPERVISOR_FROZEN_WORKFLOW_HASH_MISMATCH');
        if(!hash_equals(self::AUTHORING_PROMPT_SHA256,(string)$release['authoring_prompt_sha256']))return self::blocked('SUPERVISOR_AUTHORING_PROMPT_HASH_MISMATCH');
        if((string)$release['authoring_role']!=='CHAT_OR_APPROVED_RESEARCH_TEXT_PROCESS')return self::blocked('SUPERVISOR_AUTHORING_ROLE_INVALID');
        if((string)$release['ppm_version']!=='6.7.9')return self::blocked('SUPERVISOR_RELEASE_PPM_VERSION_MISMATCH');
        if(!hash_equals((string)($snapshot['baseline_sha256']??''),(string)$release['ppm_baseline_sha256']))return self::blocked('SUPERVISOR_PPM_BASELINE_MISMATCH');
        if(($release['content_generation_performed_by_supervisor']??null)!==false)return self::blocked('SUPERVISOR_MUST_NOT_GENERATE_CONTENT');
        if(($release['wordpress_write_performed']??null)!==false)return self::blocked('SUPERVISOR_MUST_NOT_WRITE_WORDPRESS');
        if((string)$release['research_evidence_policy']!=='PRE_TEXT_INDEPENDENT_HASH_BOUND_FAIL_CLOSED')return self::blocked('SUPERVISOR_RESEARCH_EVIDENCE_POLICY_INVALID');
        if((string)$release['article_origin_policy']!=='POST_TEXT_SIGNED_0039_ORIGIN_AND_NO_REWRITE')return self::blocked('SUPERVISOR_ARTICLE_ORIGIN_POLICY_INVALID');
        if(array_values((array)$release['sequence'])!==self::SEQUENCE)return self::blocked('SUPERVISOR_SEQUENCE_INVALID',['expected'=>self::SEQUENCE,'actual'=>$release['sequence']]);

        $sig=self::validateSignedRelease($release);
        if(empty($sig['ok']))return $sig;

        if(!hash_equals((string)$batch['batch_sha256'],(string)$release['exact_five_batch_sha256']))return self::blocked('SUPERVISOR_EXACT_FIVE_BATCH_BINDING_MISMATCH');
        if((int)$release['exact_five_item_count']!==(int)$batch['item_count'])return self::blocked('SUPERVISOR_EXACT_FIVE_COUNT_MISMATCH');
        if(!hash_equals(PSERC_Stable_Json::hash($plan),(string)$release['production_plan_sha256']))return self::blocked('SUPERVISOR_PRODUCTION_PLAN_HASH_MISMATCH');
        if(!hash_equals(PSERC_Stable_Json::hash($bundle),(string)$release['fact_pack_bundle_sha256']))return self::blocked('SUPERVISOR_FACT_PACK_BUNDLE_HASH_MISMATCH');

        $bundlePlan=self::validateBundlePlanSet($bundle,$plan);
        if(empty($bundlePlan['ok']))return $bundlePlan;

        $planBySlot=self::planByExternalSlot($plan);
        if(empty($planBySlot['ok']))return $planBySlot;
        $slotMap=(array)$planBySlot['items'];

        $rItems=array_values((array)$release['items']);$mItems=array_values((array)$batch['items']);
        if(count($rItems)!==count($mItems))return self::blocked('SUPERVISOR_RELEASE_ITEM_COUNT_MISMATCH');
        $releaseBySlot=[];
        foreach($rItems as $i=>$ri){
            if(!is_array($ri))return self::blocked('SUPERVISOR_RELEASE_ITEM_INVALID',['index'=>$i]);
            $shape=self::exactKeys($ri,self::ITEM_KEYS,'items['.$i.']');if($shape!==null)return self::blocked('SUPERVISOR_RELEASE_ITEM_SCHEMA_INVALID',['detail'=>$shape]);
            $slot=(string)$ri['plan_slot'];if(!self::sha($slot)||isset($releaseBySlot[$slot]))return self::blocked('SUPERVISOR_RELEASE_PLAN_SLOT_INVALID_OR_DUPLICATE',['index'=>$i]);
            $releaseBySlot[$slot]=$ri;
        }

        $itemReports=[];
        foreach($mItems as $i=>$meta){
            $slot=(string)$meta['plan_slot'];$ri=$releaseBySlot[$slot]??null;$pitem=$slotMap[$slot]??null;
            if(!is_array($ri)||!is_array($pitem))return self::blocked('SUPERVISOR_RELEASE_OR_PLAN_ITEM_MISSING_FOR_SLOT',['index'=>$i]);
            if(!hash_equals(PSERC_Stable_Json::hash($meta),(string)$ri['metadata_handoff_sha256']))return self::blocked('SUPERVISOR_METADATA_HANDOFF_HASH_MISMATCH',['index'=>$i]);
            if(!hash_equals(hash('sha256',(string)$meta['title']),(string)$ri['final_title_sha256']))return self::blocked('SUPERVISOR_FINAL_TITLE_LOCK_MISMATCH',['index'=>$i]);
            $ca=is_array($pitem['canonical_article']??null)?$pitem['canonical_article']:[];
            if((string)$ri['canonical_article_id']!==(string)($pitem['canonical_article_id']??''))return self::blocked('SUPERVISOR_CANONICAL_ARTICLE_ID_MISMATCH',['index'=>$i]);
            $bodyHtml=(string)($ca['body_html']??'');$bodyText=(string)($ca['body_text']??'');
            if($bodyHtml===''||$bodyText==='')return self::blocked('SUPERVISOR_CANONICAL_ARTICLE_BODY_MISSING',['index'=>$i]);
            $bodyHtmlSha=hash('sha256',$bodyHtml);$bodyTextSha=hash('sha256',$bodyText);
            if(!hash_equals($bodyHtmlSha,(string)$ri['body_html_sha256'])||!hash_equals($bodyTextSha,(string)$ri['body_text_sha256']))return self::blocked('SUPERVISOR_ARTICLE_BODY_HASH_MISMATCH',['index'=>$i]);
            if(isset($ca['body_html_sha256'])&&!hash_equals($bodyHtmlSha,(string)$ca['body_html_sha256']))return self::blocked('SUPERVISOR_PLAN_DECLARED_HTML_HASH_INVALID',['index'=>$i]);
            foreach(['content_plan_hash','fact_pack_hash'] as $f){if(!self::sha((string)$ri[$f])||!hash_equals((string)($ca[$f]??''),(string)$ri[$f]))return self::blocked('SUPERVISOR_ARTICLE_BINDING_HASH_MISMATCH',['index'=>$i,'field'=>$f]);}
            if((string)$ri['source_snapshot_id']!==(string)($pitem['source_snapshot_id']??''))return self::blocked('SUPERVISOR_SOURCE_SNAPSHOT_BINDING_MISMATCH',['index'=>$i]);
            if((string)$ri['research_evidence_gate_status']!=='PASS'||!self::sha((string)$ri['research_evidence_attestation_sha256']))return self::blocked('SUPERVISOR_RESEARCH_EVIDENCE_GATE_NOT_PASS',['index'=>$i]);
            if((string)$ri['article_origin_gate_status']!=='PASS'||!self::sha((string)$ri['article_origin_attestation_sha256']))return self::blocked('SUPERVISOR_ARTICLE_ORIGIN_GATE_NOT_PASS',['index'=>$i]);
            if((string)$ri['language_quality_gate_status']!=='PASS'||!self::sha((string)$ri['language_evidence_sha256'])||!self::sha((string)$ri['quality_evidence_sha256']))return self::blocked('SUPERVISOR_LANGUAGE_QUALITY_GATE_NOT_PASS',['index'=>$i]);
            if((string)$ri['authoring_process']!=='STARTMASTER_0039_CHAT_OR_APPROVED_RESEARCH_TEXT_PROCESS')return self::blocked('SUPERVISOR_UNAUTHORIZED_AUTHORING_PROCESS',['index'=>$i]);
            if(($ri['external_rewrite_detected']??null)!==false||($ri['trusted_self_approval']??null)!==false||($ri['content_hash_locked']??null)!==true)return self::blocked('SUPERVISOR_ORIGIN_OR_IMMUTABILITY_RISK',['index'=>$i]);
            $itemReports[]=['index'=>$i,'plan_slot'=>$slot,'canonical_article_id'=>$ri['canonical_article_id'],'body_html_sha256'=>$bodyHtmlSha,'body_text_sha256'=>$bodyTextSha,'status'=>'PASS'];
        }

        $bridge=PSERC_PPM_Intake_Bridge::prepare($batch,$plan,$snapshot);
        if(empty($bridge['ok']))return self::blocked('SUPERVISOR_ORIGINAL_PPM_PLAN_BINDING_BLOCKED',['bridge'=>$bridge]);

        $report=[
            'contract'=>self::CONTRACT,'status'=>'PSERC_WORKFLOW_SUPERVISOR_PASS','ok'=>true,'nullpunkt'=>self::NULLPUNKT,
            'nullpunkt_sha256'=>self::NULLPUNKT_SHA256,'frozen_workflow_sha256'=>self::FROZEN_WORKFLOW_SHA256,'authoring_prompt_sha256'=>self::AUTHORING_PROMPT_SHA256,
            'compiler_manifest_sha256'=>(string)$compilerManifest['manifest_sha256'],'exact_five_batch_sha256'=>(string)$batch['batch_sha256'],
            'sequence'=>self::SEQUENCE,'items'=>$itemReports,'release_sha256'=>(string)$release['release_sha256'],'release_payload_sha256'=>(string)$release['release_payload_sha256'],
            'signature_status'=>'ED25519_VALID','signing_key_id'=>self::SIGNING_KEY_ID,'ppm_version'=>'6.7.9','ppm_baseline_sha256'=>(string)$snapshot['baseline_sha256'],
            'original_0039_plan_slot_field_injected'=>false,'content_or_design_generation_allowed'=>false,'content_or_design_rewrite_allowed'=>false,
            'wordpress_write_attempted'=>false,'publish_allowed'=>false,
        ];
        $report['report_sha256']=PSERC_Stable_Json::hash($report);
        return $report;
    }

    /** @return array<string,mixed> */
    private static function validateSignedRelease(array $release): array {
        if((string)$release['signature_algorithm']!=='ED25519')return self::blocked('SUPERVISOR_SIGNATURE_ALGORITHM_INVALID');
        if((string)$release['signing_key_id']!==self::SIGNING_KEY_ID||!hash_equals(self::SIGNING_PUBLIC_KEY_SHA256,(string)$release['signing_public_key_sha256']))return self::blocked('SUPERVISOR_SIGNING_KEY_IDENTITY_MISMATCH');
        if(!function_exists('sodium_crypto_sign_verify_detached'))return self::blocked('SUPERVISOR_ED25519_RUNTIME_UNAVAILABLE');
        $payload=$release;unset($payload['release_payload_sha256'],$payload['signature_b64'],$payload['release_sha256']);
        $payloadSha=PSERC_Stable_Json::hash($payload);
        if(!self::sha((string)$release['release_payload_sha256'])||!hash_equals($payloadSha,(string)$release['release_payload_sha256']))return self::blocked('SUPERVISOR_SIGNED_PAYLOAD_HASH_MISMATCH');
        $signature=base64_decode((string)$release['signature_b64'],true);$public=base64_decode(self::SIGNING_PUBLIC_KEY_B64,true);
        if(!is_string($signature)||strlen($signature)!==SODIUM_CRYPTO_SIGN_BYTES||!is_string($public)||strlen($public)!==SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES)return self::blocked('SUPERVISOR_SIGNATURE_ENCODING_INVALID');
        if(!sodium_crypto_sign_verify_detached($signature,$payloadSha,$public))return self::blocked('SUPERVISOR_SIGNATURE_INVALID');
        $copy=$release;unset($copy['release_sha256']);$releaseSha=PSERC_Stable_Json::hash($copy);
        if(!self::sha((string)$release['release_sha256'])||!hash_equals($releaseSha,(string)$release['release_sha256']))return self::blocked('SUPERVISOR_RELEASE_HASH_MISMATCH');
        return ['ok'=>true,'status'=>'SUPERVISOR_SIGNED_RELEASE_VALID'];
    }

    /** @return array<string,mixed> */
    private static function validateCompilerManifest(array $manifest,array $batch): array {
        if((string)($manifest['mode']??'')!=='READ_ONLY_METADATA_ONLY_EXACT_FIVE_FIELDS')return self::blocked('SUPERVISOR_COMPILER_MODE_INVALID');
        $claimed=(string)($manifest['manifest_sha256']??'');$copy=$manifest;unset($copy['manifest_sha256']);
        if(!self::sha($claimed)||!hash_equals(PSERC_Stable_Json::hash($copy),$claimed))return self::blocked('SUPERVISOR_COMPILER_MANIFEST_HASH_MISMATCH');
        $mb=(array)($manifest['next_textmachine_metadata_batch']??[]);
        $fullBoundary=PSERC_Metadata_Boundary::validateBatch($mb);
        if(empty($fullBoundary['ok']))return self::blocked('SUPERVISOR_COMPILER_FULL_BATCH_INVALID',['boundary'=>$fullBoundary]);
        if((int)($batch['item_count']??0)<1||(int)($batch['item_count']??0)>(int)($mb['item_count']??0))return self::blocked('SUPERVISOR_COMPILER_SELECTED_BATCH_COUNT_INVALID');
        $fullByHash=[];foreach((array)($mb['items']??[]) as $fullMeta){if(is_array($fullMeta))$fullByHash[PSERC_Stable_Json::hash($fullMeta)]=true;}
        foreach((array)($batch['items']??[]) as $i=>$selectedMeta){if(!is_array($selectedMeta)||!isset($fullByHash[PSERC_Stable_Json::hash($selectedMeta)]))return self::blocked('SUPERVISOR_COMPILER_SELECTED_ITEM_NOT_IN_CURRENT_BATCH',['index'=>$i]);}
        $sys=(array)($manifest['system_boundary']??[]);
        foreach(['production_started','draft_created','wordpress_database_write_attempted','article_text_emitted','html_emitted','fact_pack_emitted','headings_tables_lists_links_emitted'] as $f){if(($sys[$f]??null)!==false)return self::blocked('SUPERVISOR_COMPILER_BOUNDARY_VIOLATION',['field'=>$f,'actual'=>$sys[$f]??null]);}
        if(($sys['publish_allowed']??null)!==false)return self::blocked('SUPERVISOR_COMPILER_PUBLISH_BOUNDARY_INVALID');
        $rules=(array)($manifest['hard_rules']??[]);$expected=['title','target_keyword','category','article_type','plan_slot'];
        if(array_values((array)($rules['metadata_handoff_exact_scalar_fields']??[]))!==$expected)return self::blocked('SUPERVISOR_COMPILER_EXACT_FIVE_RULE_DRIFT');
        if(($rules['approved_research_text_process_required']??null)!==true)return self::blocked('SUPERVISOR_APPROVED_RESEARCH_PROCESS_RULE_MISSING');
        $readyByHash=[];
        foreach((array)($manifest['items']??[]) as $it){if(!is_array($it)||($it['status']??'')!=='READY_FOR_METADATA_HANDOFF')continue;$binding=(array)($it['metadata_binding']??[]);$readyByHash[PSERC_Stable_Json::hash($binding)]=$it;}
        foreach((array)($batch['items']??[]) as $i=>$meta){
            $it=$readyByHash[PSERC_Stable_Json::hash($meta)]??null;if(!is_array($it))return self::blocked('SUPERVISOR_START_GATE_READY_ITEM_NOT_PROVEN',['index'=>$i]);
            if((string)($it['technical_strand_report']['status']??'')!=='PASS'||(string)($it['editorial_strand_report']['status']??'')!=='PASS'||empty($it['release_decision']['ready']))return self::blocked('SUPERVISOR_UPSTREAM_RELEASE_NOT_FULL_PASS',['index'=>$i]);
            foreach(['assignment_consistency_gate','semantic_assignment_gate','technical_slot_capacity_gate','slot_intent_gate','editorial_outcome_gate','language_gate','portal_topic_evidence_gate','semantic_duplicate_gate'] as $gate){if(($it[$gate]['ok']??null)!==true)return self::blocked('SUPERVISOR_START_GATE_COMPONENT_NOT_PASS',['index'=>$i,'gate'=>$gate,'status'=>$it[$gate]['status']??null]);}
            if(!empty($it['duplicate_match']))return self::blocked('SUPERVISOR_START_GATE_DUPLICATE_PRESENT',['index'=>$i]);
            if((string)($it['target_keyword']['status']??'')!=='PASS'||(string)($it['title']['production_title_sha256']??'')!==hash('sha256',(string)$meta['title']))return self::blocked('SUPERVISOR_TITLE_OR_KEYWORD_NOT_LOCKED',['index'=>$i]);
        }
        return ['ok'=>true,'status'=>'SUPERVISOR_COMPILER_START_GATE_AND_TITLE_LOCK_PASS','manifest_sha256'=>$claimed];
    }

    /** @return array<string,mixed> */
    private static function validateBundlePlanSet(array $bundle,array $plan): array {
        if((string)($bundle['contract']??'')!=='canonical_fact_pack_import_v1')return self::blocked('SUPERVISOR_FACT_PACK_CONTRACT_INVALID');
        $packs=array_values(array_filter((array)($bundle['fact_packs']??[]),'is_array'));$items=array_values(array_filter((array)($plan['items']??[]),'is_array'));
        if(!$packs||!$items)return self::blocked('SUPERVISOR_FACT_PACK_OR_PLAN_EMPTY');
        $packIds=[];foreach($packs as $p){$id=(string)($p['fact_pack_id']??'');if($id===''||isset($packIds[$id]))return self::blocked('SUPERVISOR_FACT_PACK_ID_INVALID_OR_DUPLICATE');$packIds[$id]=true;}
        $required=[];foreach($items as $i=>$item){if(array_key_exists('plan_slot',$item))return self::blocked('SUPERVISOR_FOREIGN_PLAN_SLOT_FIELD_FORBIDDEN_IN_0039_PPM_PLAN',['index'=>$i]);$id=(string)($item['source_snapshot_id']??'');if($id==='')return self::blocked('SUPERVISOR_PLAN_SOURCE_SNAPSHOT_ID_MISSING',['index'=>$i]);$required[$id]=true;}
        $extra=array_values(array_diff(array_keys($packIds),array_keys($required)));$missing=array_values(array_diff(array_keys($required),array_keys($packIds)));
        if($extra||$missing)return self::blocked('SUPERVISOR_FACT_PACK_PLAN_SET_MISMATCH',['extra'=>$extra,'missing'=>$missing]);
        return ['ok'=>true,'status'=>'SUPERVISOR_FACT_PACK_PLAN_SET_PASS'];
    }

    /** @return array<string,mixed> */
    private static function planByExternalSlot(array $plan): array {
        $out=[];
        foreach((array)($plan['items']??[]) as $i=>$item){
            if(!is_array($item))return self::blocked('SUPERVISOR_PLAN_ITEM_INVALID',['index'=>$i]);
            $cid=trim((string)($item['canonical_article_id']??''));if($cid==='')return self::blocked('SUPERVISOR_PLAN_CANONICAL_ID_MISSING',['index'=>$i]);
            try{$slot=PSERC_Plan_Slot_Identity::tokenFromCanonicalId($cid);}catch(Throwable $e){return self::blocked('SUPERVISOR_PLAN_SLOT_TOKEN_FAILED',['index'=>$i]);}
            if(isset($out[$slot]))return self::blocked('SUPERVISOR_PLAN_SLOT_TOKEN_DUPLICATE',['index'=>$i]);$out[$slot]=$item;
        }
        return ['ok'=>true,'items'=>$out];
    }

    private static function exactKeys(array $obj,array $allowed,string $path): ?array {$a=array_keys($obj);$b=$allowed;sort($a);sort($b);return $a===$b?null:['path'=>$path,'actual'=>$a,'expected'=>$b];}
    private static function sha(string $v): bool {return (bool)preg_match('/^[a-f0-9]{64}$/',$v);}
    /** @return array<string,mixed> */
    private static function blocked(string $reason,array $extra=[]): array {return array_merge(['ok'=>false,'contract'=>self::CONTRACT,'status'=>'PSERC_WORKFLOW_SUPERVISOR_BLOCKED','reason_codes'=>[$reason],'wordpress_write_attempted'=>false,'publish_allowed'=>false],$extra);}
}
