# 0.7.2

- Verwendet eine reine numerische WordPress-Pluginversion `0.7.2` und einen separaten Buildmarker `0.7.2-pste-0.10.10-hardchain-verified`.
- Ergänzt einen schreibfreien Compiler-Selbstintegritätswächter gegen unvollständige oder gemischte Installationen.
- Verhindert, dass verbotene Inhalts- oder Formatfelder bereits im SEO-Reader stillschweigend entfernt werden: Der betroffene Kandidat wird isoliert zurückgehalten und protokolliert; andere saubere Kandidaten laufen weiter.
- Zeigt bei Blockaden die aktive Compilerfassung und die konkrete verschachtelte Quellbindungsursache an.
- Die bestehende Semantik-, Planplatz-, Metadaten-, Titel- und Textmaschinenlogik bleibt unverändert; vorgeschaltet wird ausschließlich eine fail-closed Paketprüfung.
- Keine Änderung an Textmaschine, Artikelinhalt, HTML, Design, Kategorien, URLs, Yoast oder WordPress-Schreibpfaden.
