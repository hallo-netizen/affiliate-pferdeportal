<?php
if (!defined('ABSPATH')) { return; }

/** Pure status aggregator. It contains no regex, vocabulary, thresholds or domain logic. */
final class PSERC_Release_Aggregator {
    /** @return array<string,mixed> */
    public static function decide(string $technical,string $editorial,string $e2e): array {
        $technical=strtoupper(trim($technical));$editorial=strtoupper(trim($editorial));$e2e=strtoupper(trim($e2e));
        if($technical==='FAIL')$status='BLOCKED_TECHNICAL';
        elseif($editorial==='FAIL')$status='BLOCKED_EDITORIAL';
        elseif($technical==='REVIEW'||$editorial==='REVIEW'||$e2e==='REVIEW')$status='REVIEW_REQUIRED';
        elseif($technical==='PASS'&&$editorial==='PASS'&&$e2e==='PASS')$status='READY';
        else $status='BLOCKED_E2E';
        return ['contract'=>'PSERC_DUAL_STRAND_RELEASE_AGGREGATOR_V1','status'=>$status,'technical_strand'=>$technical,'editorial_strand'=>$editorial,'e2e_gate'=>$e2e,'ready'=>$status==='READY','logic'=>'STATUS_ONLY_NO_DOMAIN_RULES','write_attempted'=>false];
    }
}
