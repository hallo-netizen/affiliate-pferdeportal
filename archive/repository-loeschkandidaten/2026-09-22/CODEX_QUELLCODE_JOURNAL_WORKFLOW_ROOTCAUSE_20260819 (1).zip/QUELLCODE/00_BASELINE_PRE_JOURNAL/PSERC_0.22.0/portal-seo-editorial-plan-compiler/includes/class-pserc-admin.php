<?php
if (!defined('ABSPATH')) { return; }

final class PSERC_Admin {
    private const SLUG='portal-seo-editorial-plan-compiler';

    public static function init(): void {
        add_action('admin_menu',[self::class,'menu'],40);
        add_action('admin_post_pserc_export_live_preview',[self::class,'exportLivePreview']);
    }

    public static function menu(): void {
        $parent=class_exists('PSTE_Admin')?'portal-seo-topic-engine':null;
        if ($parent) {
            add_submenu_page($parent,'SEO Redaktionsplan','SEO Redaktionsplan','manage_options',self::SLUG,[self::class,'page']);
        } else {
            add_menu_page('SEO Redaktionsplan','SEO Redaktionsplan','manage_options',self::SLUG,[self::class,'page'],'dashicons-media-spreadsheet',59);
        }
    }

    public static function page(): void {
        if (!current_user_can('manage_options')) { return; }

        echo '<div class="wrap"><h1>SEO-Redaktionsplan Metadaten-Vorschau <small>'.esc_html(defined('PSERC_BUILD')?PSERC_BUILD:PSERC_VERSION).'</small></h1>';
        echo '<div class="notice notice-info inline"><p><strong>Schreibfreier Metadatenmodus:</strong> Diese Seite liest SEO-Themen, Produktionsverträge und freie Planplätze. Sie übergibt ausschließlich Titel-, Keyword-, Typ-, Kategorie- und Planplatzdaten. Sie erzeugt keinen Text, kein HTML, keine Tabellen, keine Links und startet keine Textproduktion.</p></div>';

        try {
            $result=PSERC_Compiler::compile();
        } catch (Throwable $e) {
            self::renderBlocked('PSERC_UNCAUGHT_PREVIEW_ERROR',$e->getMessage(),[]);
            echo '</div>';
            return;
        }

        if (empty($result['ok'])) {
            self::renderBlocked((string)($result['status']??'PSERC_PREVIEW_BLOCKED'),(string)($result['message']??'Die Metadaten-Vorschau wurde sicher blockiert.'),$result);
            echo '</div>';
            return;
        }

        $manifest=(array)$result['manifest'];
        $counts=(array)($manifest['counts']??[]);
        $batch=(array)($manifest['next_textmachine_metadata_batch']??[]);
        $release=(array)($manifest['production_release']??[]);
        $bindings=(array)($manifest['bindings']??[]);

        if((int)($batch['item_count']??0)>0){echo '<div class="notice notice-success inline"><p><strong>METADATEN-VORSCHAU PASS:</strong> Textmaschine, Design und Bestandsinhalte wurden nicht verändert. '.esc_html((string)$batch['item_count']).' Position(en) enthalten je exakt fünf freigegebene Planungsfelder.</p></div>';}else{echo '<div class="notice notice-warning inline"><p><strong>KEIN PRÜFARTIKEL FREIGEGEBEN:</strong> Alle Kandidaten wurden fail-closed zurückgehalten. Es wurde nichts verändert.</p></div>';}
        echo '<p><strong>SEO:</strong> Version <code>'.esc_html((string)($bindings['seo_version']??'')).'</code>, Schema <code>'.esc_html((string)($bindings['seo_schema']??'')).'</code><br>';
        echo '<strong>Textmaschine:</strong> Version <code>'.esc_html((string)($bindings['production_version']??'')).'</code>, Baseline <code>'.esc_html(substr((string)($bindings['production_baseline_sha256']??''),0,16)).'…</code><br>';
        echo '<strong>Modus:</strong> <code>READ_ONLY_METADATA_ONLY</code> · <strong>Veröffentlichen:</strong> nein</p>';

        echo '<h2>Nächster reiner Metadatenblock</h2>';
        $items=(array)($batch['items']??[]);
        if (!$items) {
            echo '<div class="notice notice-warning inline"><p>Aktuell ist kein vollständig kompatibler Metadatenblock verfügbar. Es wurde nichts verändert.</p></div>';
        } else {
            echo '<table class="widefat striped"><thead><tr><th>Beitragsart</th><th>SEO-geprüfter Titel</th><th>Longtail-Zielkeyword</th><th>Kategorie</th><th>Planplatz</th></tr></thead><tbody>';
            foreach ($items as $item) {
                echo '<tr>';
                echo '<td><strong>'.esc_html((string)($item['article_type']??'')).'</strong></td>';
                echo '<td>'.esc_html((string)($item['title']??'')).'</td>';
                echo '<td><code>'.esc_html((string)($item['target_keyword']??'')).'</code></td>';
                echo '<td><code>'.esc_html((string)($item['category']??'')).'</code></td>';
                echo '<td><code>'.esc_html((string)($item['plan_slot']??'')).'</code></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        }

        echo '<h2>Gesamtstatus</h2>';
        echo '<p><strong>SEO-Themen gesamt:</strong> '.esc_html((string)($counts['seo_all']??0)).' · <strong>geeignet:</strong> '.esc_html((string)($counts['seo_eligible']??0)).' · <strong>zurückgehalten:</strong> '.esc_html((string)($counts['seo_held']??0)).'<br>';
        echo '<strong>Metadaten-Handoff bereit:</strong> '.esc_html((string)($counts['READY_FOR_METADATA_HANDOFF']??0)).' · <strong>Semantisch blockiert:</strong> '.esc_html((string)($counts['BLOCKED_SEMANTIC_ASSIGNMENT']??0)).' · <strong>Sprachlich blockiert:</strong> '.esc_html((string)($counts['BLOCKED_LANGUAGE_GATE']??0)).' · <strong>Portalprüfung blockiert:</strong> '.esc_html((string)($counts['BLOCKED_PORTAL_TOPIC_EVIDENCE']??0)).'</p>';

        echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page='.self::SLUG)).'">Metadaten-Vorschau neu einlesen</a></p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
        wp_nonce_field('pserc_export_live_preview');
        echo '<input type="hidden" name="action" value="pserc_export_live_preview">';
        submit_button('Reine Metadaten-Vorschau als JSON herunterladen','secondary','submit',false);
        echo '</form>';

        echo '<details style="margin-top:18px"><summary>Technische Bindungen anzeigen</summary><pre style="white-space:pre-wrap">'.esc_html(wp_json_encode([
            'manifest_sha256'=>$manifest['manifest_sha256']??'',
            'system_boundary'=>$manifest['system_boundary']??[],
            'bindings'=>$bindings,
            'production_release'=>$release,
            'counts'=>$counts,
        ],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)).'</pre></details>';
        PSERC_Production_Trigger::renderPanel($batch,$release);
        echo '</div>';
    }

    public static function exportLivePreview(): void {
        if (!current_user_can('manage_options')) { wp_die('Nicht erlaubt.'); }
        check_admin_referer('pserc_export_live_preview');
        $result=PSERC_Compiler::compile();
        if (empty($result['ok'])) {
            wp_die(esc_html((string)($result['status']??'PSERC_PREVIEW_BLOCKED')).': '.esc_html((string)($result['message']??'')));
        }
        $manifest=(array)$result['manifest'];
        $json=wp_json_encode($manifest,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
        $hash=(string)($manifest['manifest_sha256']??'preview');
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="seo-redaktionsplan-metadaten-vorschau-'.$hash.'.json"');
        echo $json;
        exit;
    }

    /** @param array<string,mixed> $context */
    private static function renderBlocked(string $code,string $message,array $context=[]): void {
        $diagnostics=self::safeDiagnostics($context);
        echo '<div class="notice notice-error inline"><p><strong>METADATEN-VORSCHAU BLOCKED:</strong> <code>'.esc_html($code).'</code><br>'.esc_html($message).'<br><strong>Es wurde nichts verändert.</strong></p>';
        if($diagnostics){
            echo '<details open style="margin:0 0 12px 0"><summary><strong>Technische Ursache</strong></summary><pre style="white-space:pre-wrap">'.esc_html(wp_json_encode($diagnostics,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT)).'</pre></details>';
        }
        echo '</div>';
    }

    /** @param array<string,mixed> $context @return array<string,mixed> */
    private static function safeDiagnostics(array $context): array {
        $keys=['reason_codes','expected','actual','declared','slug','name','article_type','term_id','missing_count','first_missing','freshness','mismatch_count','undeclared_count','undeclared_files'];
        $out=[
            'active_compiler_version'=>defined('PSERC_VERSION')?(string)PSERC_VERSION:'UNDEFINED',
            'active_compiler_build'=>defined('PSERC_BUILD')?(string)PSERC_BUILD:'UNDEFINED',
        ];
        foreach($keys as $key){if(array_key_exists($key,$context))$out[$key]=self::sanitizeDiagnosticValue($context[$key]);}
        foreach(['package_integrity','seo','source_binding'] as $nestedKey){
            if(!isset($context[$nestedKey])||!is_array($context[$nestedKey]))continue;
            $nested=(array)$context[$nestedKey];
            $safe=['status'=>(string)($nested['status']??''),'message'=>(string)($nested['message']??''),'reason_codes'=>(array)($nested['reason_codes']??[])];
            foreach(['expected','actual','mismatch_count','undeclared_count','undeclared_files','package_version','package_build','engine_version','engine_schema','required_file_count'] as $key){if(array_key_exists($key,$nested))$safe[$key]=self::sanitizeDiagnosticValue($nested[$key]);}
            if(isset($nested['source_binding'])&&is_array($nested['source_binding'])){
                $sb=(array)$nested['source_binding'];
                $safe['source_binding']=['status'=>(string)($sb['status']??''),'message'=>(string)($sb['message']??''),'reason_codes'=>(array)($sb['reason_codes']??[])];
                foreach(['expected','actual','mismatch_count','undeclared_count','undeclared_files','engine_version','engine_schema','required_file_count'] as $key){if(array_key_exists($key,$sb))$safe['source_binding'][$key]=self::sanitizeDiagnosticValue($sb[$key]);}
                if(isset($sb['mismatches'])&&is_array($sb['mismatches']))$safe['source_binding']['mismatches']=self::safeMismatchList($sb['mismatches']);
            }
            if(isset($nested['mismatches'])&&is_array($nested['mismatches']))$safe['mismatches']=self::safeMismatchList($nested['mismatches']);
            $out[$nestedKey]=$safe;
        }
        if(isset($context['mismatches'])&&is_array($context['mismatches']))$out['mismatches']=self::safeMismatchList($context['mismatches']);
        return $out;
    }
    /** @param array<int|string,mixed> $mismatches @return array<int,array<string,mixed>> */
    private static function safeMismatchList(array $mismatches): array {
        $safe=[];
        foreach(array_slice(array_values($mismatches),0,5) as $pair){
            if(!is_array($pair))continue;
            $safe[]=[
                'file'=>substr((string)($pair['file']??''),0,180),
                'expected_sha256_prefix'=>substr((string)($pair['expected_sha256']??$pair['expected']??''),0,16),
                'actual_sha256_prefix'=>substr((string)($pair['actual_sha256']??$pair['actual']??''),0,16),
                'expected_bytes'=>(int)($pair['expected_bytes']??-1),
                'actual_bytes'=>(int)($pair['actual_bytes']??-1),
            ];
        }
        return $safe;
    }
    private static function sanitizeDiagnosticValue($value){
        if(is_int($value)||is_float($value)||is_bool($value)||$value===null)return $value;
        if(is_string($value))return function_exists('mb_substr')?mb_substr($value,0,240,'UTF-8'):substr($value,0,240);
        if(is_array($value)){
            $out=[];$i=0;
            foreach($value as $key=>$item){if($i++>=20)break;$safeKey=is_int($key)?$key:substr((string)$key,0,80);$out[$safeKey]=self::sanitizeDiagnosticValue($item);}
            return $out;
        }
        return gettype($value);
    }
}
