# 0.7.6

- binds exactly to Portal SEO Themenengine 0.10.13/schema 12;
- verifies the new raw-query family-membership gate before semantic handoff;
- preserves detailed semantic reason codes for fail-closed diagnosis;
- no article content, HTML, design, quality or production-machine code changed.
- maps the explicit „zwei Pferde“ requirement to the Bedarf slot instead of a generic Einsteiger slot;
- recognizes stored PAA evidence while preserving the exact-five-field metadata boundary.
