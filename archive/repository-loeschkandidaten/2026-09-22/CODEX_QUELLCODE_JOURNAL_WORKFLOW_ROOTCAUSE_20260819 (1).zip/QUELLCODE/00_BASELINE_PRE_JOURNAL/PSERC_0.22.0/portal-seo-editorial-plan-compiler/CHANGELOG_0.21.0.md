# 0.21.0 – Live-Pfadform gegen kanonische Familienidentität entkoppelt

- Behebt ausschließlich `PORTAL_STRUCTURE_LIVE_PATH_SHAPE_INVALID` nach einem gültigen Gesamtbestand-Abgleich.
- `full_path` wird jetzt gegen die realen `portal_ancestor_page_names` plus Kategoriename geprüft.
- Der sichtbare Titel der Produktseite darf dadurch – wie von PSTE 0.33.0 ausdrücklich vorgesehen – von der stabilen kanonischen `topic_family_name` abweichen.
- IDs, Slugs, Page-Chain, flache WordPress-Kategorie, Familien-/Typ-Eindeutigkeit, Registry-Hash und Baseline-Freshness bleiben fail-closed.
- Keine Text-, Recherche-, HTML-, PPM-, Publish- oder Designlogik geändert.
