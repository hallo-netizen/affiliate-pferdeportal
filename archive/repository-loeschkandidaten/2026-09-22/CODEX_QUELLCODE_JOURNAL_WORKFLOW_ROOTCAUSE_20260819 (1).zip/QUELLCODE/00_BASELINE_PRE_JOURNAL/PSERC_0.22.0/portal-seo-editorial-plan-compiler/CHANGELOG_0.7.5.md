# 0.7.5

- Binds exactly to Portal SEO Themenengine 0.10.12-staging / schema 11.
- Corrects the mechanical topic-family membership check so repeated title tokens cannot create a false `LANGUAGE_TOPIC_FAMILY_MISSING`.
- Does not rewrite titles, article content, HTML, formatting, design or production-machine behavior.
- Keeps all existing fail-closed semantic, language, evidence, duplicate and canonical-slot gates.
