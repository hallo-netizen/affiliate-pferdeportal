# 0.10.0 — gebündelte Live-Legacy-Kompatibilität

- SEO-Reader wählt die erste nicht-leere erhaltene Rohquery statt leerer Legacy-Felder
- stabile Read-Capability bleibt unverändert
- exakt fünf skalare Handoff-Felder; keine Content-/Design-/Promptdaten und keine Writes
