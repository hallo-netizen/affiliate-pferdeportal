<?php
if (!defined('ABSPATH')) { return; }

/** Pure check-only compatibility gate. It never repairs or rewrites an upstream title. */
final class PSERC_Title_Gate {
    public static function evaluate(string $rawTitle,string $articleType,array $titleContract,string $targetKeyword=''): array {
        return self::verify($rawTitle,$articleType,$titleContract,$targetKeyword);
    }

    public static function verify(string $title,string $articleType,array $titleContract,string $targetKeyword=''): array {
        $original=trim(html_entity_decode(strip_tags($title),ENT_QUOTES|ENT_HTML5,'UTF-8'));$errors=[];$warnings=[];$canon=self::norm($articleType);$isFaq=$canon==='faq';
        if($original==='')$errors[]='TITLE_EMPTY';
        if($original!==trim((string)preg_replace('/\s+/u',' ',$original)))$errors[]='TITLE_WHITESPACE_NOT_CANONICAL';
        $words=preg_split('/\s+/u',trim(rtrim($original,'?')))?:[];if(count($words)<3||count($words)>16)$errors[]='PORTAL_TITLE_LENGTH_OUTSIDE_SAFE_RANGE';
        if(preg_match('/[^\p{L}\p{N}\s?–-]/u',$original))$errors[]='PORTAL_SPECIAL_CHARACTER_FORBIDDEN';
        $qCount=substr_count($original,'?');
        if($isFaq){if($qCount!==1||!str_ends_with($original,'?'))$errors[]='PORTAL_FAQ_REQUIRES_SINGLE_TERMINAL_QUESTION_MARK';}
        elseif($qCount>0)$errors[]='PORTAL_QUESTION_MARK_EXCLUSIVE_TO_FAQ';

        $ppmQuestion=strtoupper(trim((string)($titleContract['question_mark']??'OPTIONAL')));
        if($ppmQuestion==='REQUIRED'&&!str_ends_with($original,'?'))$errors[]='PPM_QUESTION_MARK_REQUIRED';
        if($ppmQuestion==='FORBIDDEN'&&str_contains($original,'?'))$errors[]='PPM_QUESTION_MARK_FORBIDDEN';
        if(!empty($titleContract['colon_forbidden'])&&str_contains($original,':'))$errors[]='PPM_COLON_FORBIDDEN';
        $targetKeyword=trim($targetKeyword);
        if(!empty($titleContract['keyword_required'])){
            if($targetKeyword==='')$errors[]='PPM_TARGET_KEYWORD_REQUIRED';
            elseif(!self::containsKeyword($original,$targetKeyword))$errors[]='PPM_TARGET_KEYWORD_EXACT_SUBSTRING_REQUIRED';
        }
        if(self::hasArtificialGeneratorPhrase($original))$errors[]='PORTAL_ARTIFICIAL_GENERATOR_PHRASE_FORBIDDEN';
        if($canon==='beratung'&&self::isRepeatedGenericBeratungSchema($original))$errors[]='PORTAL_BERATUNG_REPEATED_GENERIC_SCHEMA_FORBIDDEN';
        if(!$isFaq&&self::isKeywordStaccato($original,$articleType))$errors[]='PORTAL_KEYWORD_STACCATO_FORBIDDEN';
        if(!function_exists('pspell_check'))$warnings[]='SPELLCHECK_PROVIDER_NOT_AVAILABLE';

        $errors=array_values(array_unique($errors));$warnings=array_values(array_unique($warnings));
        return [
            'status'=>$errors?'REVIEW_REQUIRED':'PASS','original_title'=>$original,'production_title'=>$original,'article_type'=>$articleType,
            'target_keyword_checked'=>$targetKeyword,'target_keyword_title_coupling'=>'PPM_EXACT_SUBSTRING_ANY_POSITION','keyword_position_1_required'=>false,'changes'=>[],
            'errors'=>$errors,'warnings'=>$warnings,'title_sha256'=>hash('sha256',$original),'meaning_changed'=>false,
            'check_only'=>true,'automatic_repair_scope'=>'NONE','portal_policy_applied'=>true,'ppm_contract_applied'=>true,
        ];
    }
    private static function isRepeatedGenericBeratungSchema(string $title): bool {
        if(class_exists('PSTE_Title_Validator')&&method_exists('PSTE_Title_Validator','isRepeatedGenericBeratungSchema'))return PSTE_Title_Validator::isRepeatedGenericBeratungSchema($title);
        $clean=trim((string)preg_replace('/\s+/u',' ',$title));return (bool)preg_match('/^Passend(?:e|er|es|en|em)?\s+.+\s+richtig\s+ausw(?:ä|ae)hlen$/iu',$clean);
    }
    private static function containsKeyword(string $title,string $keyword): bool {$t=self::lower(trim(rtrim($title,'?')));$k=self::lower(trim($keyword));if($t===''||$k==='')return false;return function_exists('mb_strpos')?mb_strpos($t,$k,0,'UTF-8')!==false:strpos($t,$k)!==false;}
    private static function hasArtificialGeneratorPhrase(string $title): bool {if(class_exists('PSTE_Title_Validator')&&method_exists('PSTE_Title_Validator','hasArtificialGeneratorPhrase'))return PSTE_Title_Validator::hasArtificialGeneratorPhrase($title);return (bool)preg_match('/\b(?:fachgerecht\s+umsetzen|sinnvoll\s+einordnen|nach\s+Nutzen\s+und\s+Einsatz\s+beurteilen|nach\s+Nutzen\s+und\s+Anforderungen\s+beurteilen|hinsichtlich\s+Nutzen\s+und\s+Einsatz\s+einordnen|passend\s+zum\s+Bedarf\s+einordnen|nach\s+Bedarf\s+beurteilen|nach\s+Anforderungen\s+beurteilen|passend\s+zum\s+Einsatz\s+einordnen|mit\s+einem\s+klaren\s+Vorgehen|sinnvoll\s+in\s+die\s+Praxis\s+umsetzen|transparent\s+beurteilen|realistisch\s+einordnen)\b/iu',$title);}
    private static function isKeywordStaccato(string $title,string $articleType): bool {
        if(class_exists('PSTE_Title_Validator')&&method_exists('PSTE_Title_Validator','isKeywordStaccato'))return PSTE_Title_Validator::isKeywordStaccato($title,$articleType);
        $clean=self::lower(trim((string)preg_replace('/\s+/u',' ',rtrim($title,'?'))));$parts=preg_split('/\s+/u',$clean)?:[];if(count($parts)<3)return false;
        if(preg_match('/\b(?:der|die|das|den|dem|des|ein|eine|einer|einem|einen|mit|für|fuer|ohne|gegen|von|bei|beim|im|in|auf|unter|zum|zur|am|an|als|aus|durch|nach|vor|über|ueber|zwischen|und|oder)\b/u',$clean))return false;
        if(preg_match('/\b(?:auswähl\w*|auswaehl\w*|wähl\w*|waehl\w*|find\w*|beacht\w*|entscheid\w*|plan\w*|pfleg\w*|reinig\w*|wasch\w*|kost\w*|preis\w*|sicher\w*|installier\w*|montier\w*|anwend\w*|benutz\w*|verwend\w*|nutz\w*|einsetz\w*|lager\w*|aufbewahr\w*|trainier\w*|übung\w*|uebung\w*|ist|sind|kann|können|koennen|soll|sollen|muss|müssen|muessen|eignet|braucht|imprägnier\w*|impraegnier\w*|reparier\w*|trockn\w*|wart\w*|fahr\w*|schütz\w*|schuetz\w*|vermeid\w*|prüf\w*|pruef\w*)\b/u',$clean))return false;
        return true;
    }
    private static function lower(string $v): string{return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
    private static function norm(string $v): string {$v=strtr(trim($v),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$v=strtolower($v);return trim((string)preg_replace('/[^a-z0-9]+/','',$v));}
}
