# 0.6.1-research-evidence-readonly

- Bindet ausschließlich die fertiggestellte SEO-Themenengine 0.10.1-staging.
- Freigabe basiert auf gespeicherter Longtail-Herkunft, zwei unabhängig gebildeten Semantiksträngen, realer Zielkategorie, Dublettenprüfung, Titel-/Sprachprüfung und dem eigenen Portalbestand.
- Externe Live-SERP- oder Search-Intent-Evidenz ist nicht erforderlich.
- Neue Taxonomie-Beitragstypen werden gelesen und geprüft, aber vor der unveränderten Textmaschine gehalten, solange PPM 6.7.9 sie nicht selbst freigibt.
- Handoff unverändert exakt fünf skalare Metadatenfelder. Keine Inhalts-, HTML-, Design- oder Qualitätsdaten.
