<?php
if (!defined('ABSPATH')) { return; }

/** Stable read-capability binding for the active Portal SEO Themenengine. */
final class PSERC_SEO_Source_Binding {
    /** @return array<string,mixed> */
    public static function validate(?string $forcedRoot=null,?array $forcedContract=null,?array $forcedCapability=null): array {
        $contract=$forcedContract;
        if($contract===null){
            $path=defined('PSERC_DIR')?PSERC_DIR.'contracts/seo-engine-capability-binding-v2.json':'';
            if($path===''||!is_file($path))return self::blocked('PSERC_SEO_CAPABILITY_BINDING_FILE_MISSING');
            try{$contract=json_decode((string)file_get_contents($path),true,512,JSON_THROW_ON_ERROR);}catch(Throwable $e){return self::blocked('PSERC_SEO_CAPABILITY_BINDING_JSON_INVALID');}
        }
        if(!is_array($contract)||($contract['contract']??'')!=='PSERC_SEO_ENGINE_CAPABILITY_BINDING_V2')return self::blocked('PSERC_SEO_CAPABILITY_BINDING_CONTRACT_INVALID');
        $declared=(string)($contract['binding_sha256']??'');$copy=$contract;unset($copy['binding_sha256']);
        if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(PSERC_Stable_Json::hash($copy),$declared))return self::blocked('PSERC_SEO_CAPABILITY_BINDING_HASH_MISMATCH');

        if($forcedCapability!==null){$cap=$forcedCapability;$runtime=['ok'=>true,'status'=>'FORCED_TEST_CAPABILITY','capability'=>$cap];}
        else{
            if(!class_exists('PSTE_Compiler_Read_Capability')||!method_exists('PSTE_Compiler_Read_Capability','validateRuntime'))return self::blocked('PSERC_SEO_CAPABILITY_PROVIDER_MISSING');
            try{$runtime=PSTE_Compiler_Read_Capability::validateRuntime();}catch(Throwable $e){return self::blocked('PSERC_SEO_CAPABILITY_RUNTIME_INVALID',['runtime'=>['ok'=>false,'status'=>'PSTE_COMPILER_READ_CAPABILITY_THROWN','reason_codes'=>['PSTE_COMPILER_READ_CAPABILITY_THROWN'],'write_attempted'=>false]]);}
            if(empty($runtime['ok']))return self::blocked('PSERC_SEO_CAPABILITY_RUNTIME_INVALID',['runtime'=>$runtime]);
            $cap=(array)($runtime['capability']??[]);
        }
        $checks=[
            'contract'=>(string)($contract['expected_capability_contract']??''),
            'capability_version'=>(string)($contract['expected_capability_version']??''),
            'topic_metadata_schema'=>(string)($contract['expected_topic_metadata_schema']??''),
            'editorial_quality_contract'=>(string)($contract['expected_editorial_quality_contract']??''),
            'intent_profile_contract'=>(string)($contract['expected_intent_profile_contract']??''),
            'target_keyword_contract'=>(string)($contract['expected_target_keyword_contract']??''),
        ];
        foreach($checks as $field=>$expected)if($expected===''||!hash_equals($expected,(string)($cap[$field]??'')))return self::blocked('PSERC_SEO_CAPABILITY_FIELD_MISMATCH',['field'=>$field,'expected'=>$expected,'actual'=>(string)($cap[$field]??'')]);
        $engineSchema=(string)($cap['engine_schema']??'');$supported=array_map('strval',(array)($contract['supported_engine_schemas']??[]));if($engineSchema===''||!in_array($engineSchema,$supported,true))return self::blocked('PSERC_SEO_CAPABILITY_SCHEMA_UNSUPPORTED',['actual'=>$engineSchema,'supported'=>$supported]);
        $expectedFields=array_values(array_map('strval',(array)($contract['exact_handoff_fields']??[])));$actualFields=array_values(array_map('strval',(array)($cap['handoff_fields']??[])));
        if($expectedFields!==['title','target_keyword','category','article_type','plan_slot']||$actualFields!==$expectedFields)return self::blocked('PSERC_SEO_CAPABILITY_HANDOFF_FIELDS_INVALID',['expected'=>$expectedFields,'actual'=>$actualFields]);
        if(($cap['intent_first']??null)!==true||($cap['intent_metadata_internal_only']??null)!==true)return self::blocked('PSERC_SEO_CAPABILITY_INTENT_CONTRACT_INVALID');
        if(($cap['content_or_design_payload_allowed']??null)!==false||($cap['write_capability_exposed']??null)!==false)return self::blocked('PSERC_SEO_CAPABILITY_FIREWALL_VIOLATION');
        $capSha=(string)($cap['capability_sha256']??'');$capCopy=$cap;unset($capCopy['capability_sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$capSha)||!hash_equals(PSERC_Stable_Json::hash($capCopy),$capSha))return self::blocked('PSERC_SEO_CAPABILITY_HASH_INVALID');
        return ['ok'=>true,'status'=>'PSERC_SEO_CAPABILITY_BINDING_PASS','binding_sha256'=>$declared,'capability_sha256'=>$capSha,'engine_version'=>defined('PSTE_VERSION')?(string)PSTE_VERSION:'unknown','engine_schema'=>$engineSchema,'required_file_count'=>0,'required_symbol_count'=>count((array)($cap['required_read_symbols']??[])),'capability'=>$cap,'write_attempted'=>false];
    }
    /** @return array<string,mixed> */
    private static function blocked(string $reason,array $extra=[]): array{return array_merge(['ok'=>false,'status'=>'PSERC_SEO_CAPABILITY_BINDING_BLOCKED','reason_codes'=>[$reason],'message'=>$reason,'write_attempted'=>false],$extra);}
}
