# 0.17.0 – Approved Production Trigger

- Adds only the controlled admin start path from the current exact-five compiler batch to the already existing `PSERC_PPM_Intake_Bridge` and unchanged PPM 6.7.9 normal-draft runtime.
- Requires an already approved canonical Fact-Pack bundle and production plan; performs no research, writing, title repair, category/intent/slot change, HTML generation or design work.
- Recompiles the current metadata batch at click time and bridge-validates plan identity before importing Fact-Packs or invoking PPM.
- Publish remains forbidden.
