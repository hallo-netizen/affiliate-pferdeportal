# 0.6.3-research-evidence-readonly

- Bindet ausschließlich den vollständig geprüften Quellstand der SEO-Themenengine 0.10.3-staging.
- Der Metadaten-Handoff bleibt unverändert auf exakt fünf skalare Felder begrenzt: title, target_keyword, category, article_type, plan_slot.
- Keine Schreibpfade zu WordPress, keine Artikelproduktion und keinerlei Änderung an Textmaschine, Inhalt, HTML, Design oder Qualitätslogik.
