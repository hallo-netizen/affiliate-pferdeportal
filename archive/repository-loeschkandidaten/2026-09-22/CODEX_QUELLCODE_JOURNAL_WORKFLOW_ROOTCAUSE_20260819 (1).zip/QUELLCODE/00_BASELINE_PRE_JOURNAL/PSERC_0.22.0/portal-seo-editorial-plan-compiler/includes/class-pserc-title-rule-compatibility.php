<?php
if (!defined('ABSPATH')) { return; }

/**
 * Single read-only compatibility view for the active Production Machine article-type/title contracts
 * plus the stricter portal title surface. It never changes the Production Machine or SEO source.
 */
final class PSERC_Title_Rule_Compatibility {
    public const CONTRACT='PSERC_TITLE_RULE_COMPATIBILITY_V3_PPM_READ_ONLY_SINGLE_TITLE_AUTHORITY';

    public static function inspect(array $production): array {
        $rows=[];$conflicts=[];$types=array_values(array_unique(array_map('strval',(array)($production['registered_article_types']??[]))));
        $definitions=(array)($production['article_type_contract']['types']??[]);
        foreach($types as $type){
            $definition=is_array($definitions[$type]??null)?(array)$definitions[$type]:[];
            $ppm=PSERC_Production_Reader::titleContract($production,$type);$isFaq=self::norm($type)==='faq';
            $ppmQuestion=strtoupper(trim((string)($ppm['question_mark']??'OPTIONAL')));
            $portalQuestion=$isFaq?'REQUIRED':'FORBIDDEN';$rowConflicts=[];
            if($ppmQuestion==='REQUIRED'&&!$isFaq)$rowConflicts[]='PPM_REQUIRES_QUESTION_MARK_FOR_NONFAQ';
            if($ppmQuestion==='FORBIDDEN'&&$isFaq)$rowConflicts[]='PPM_FORBIDS_REQUIRED_FAQ_QUESTION_MARK';
            if(($ppm['colon_forbidden']??null)===false){/* portal is stricter; not a contradiction */}
            $rows[$type]=[
                'article_type'=>$type,
                'ppm_semantic_contract'=>[
                    'search_intent'=>(string)($definition['search_intent']??''),
                    'purpose'=>(string)($definition['purpose']??''),
                    'boundary'=>(array)($definition['boundary']??[]),
                    'structure_profile'=>(string)($definition['structure_profile']??''),
                ],
                'ppm_title_contract'=>$ppm,
                'portal_policy'=>[
                    'question_mark'=>$portalQuestion,
                    'allowed_special_characters'=>$isFaq?['?']:[],
                    'special_characters_other_than_terminal_faq_question_mark'=>'FORBIDDEN',
                    'natural_sentence_surface'=>'HARD_UPSTREAM_RELEASE_GATE',
                    'phrase_diversity'=>self::norm($type)==='beratung'?'HARD_NO_REPEATED_GENERIC_BERATUNG_SCHEMA':'OPTIONAL_NONBLOCKING',
                    'qualifier_preservation'=>'SEMANTIC_GENERATION_REQUIREMENT',
                    'target_keyword_binding'=>!empty($ppm['keyword_required'])?'EXACT_SUBSTRING_ANY_POSITION_MATCHES_UNCHANGED_PPM':'NOT_REQUIRED_BY_PPM',
                    'target_keyword_position_1'=>'NOT_REQUIRED',
                    'raw_query_target_keyword_relation'=>'RAW_QUERY_PRESERVED_SEPARATELY_TARGET_KEYWORD_MAY_BE_MEANING_PRESERVING_NORMALIZED_KEYPHRASE',
                    'keyword_staccato'=>'HARD_UPSTREAM_RELEASE_GATE',
                    'multiple_article_types_per_seed'=>'ALLOWED_ONLY_AS_DISTINCT_SEO_EVIDENCE_BRANCHES_NO_AUTO_FANOUT',
                ],
                'compatibility'=>$rowConflicts?'CONFLICT':'COMPATIBLE_STRICTER_UPSTREAM',
                'conflicts'=>$rowConflicts,
            ];
            foreach($rowConflicts as $c)$conflicts[]=$type.':'.$c;
        }
        $out=[
            'contract'=>self::CONTRACT,'status'=>$conflicts?'CONFLICT':'PASS','ok'=>!$conflicts,
            'production_version'=>(string)($production['version']??''),'production_baseline_sha256'=>(string)($production['baseline_sha256']??''),
            'rows'=>$rows,'conflicts'=>$conflicts,
            'rule_precedence'=>[
                'SEO_INTENT_DETERMINES_WHAT_THE_ARTICLE_MUST_ANSWER',
                'ACTIVE_PPM_ARTICLE_TYPE_AND_TITLE_CONTRACT_IS_READ_ONLY_TECHNICAL_AND_CONTENT_STRUCTURE_AUTHORITY',
                'PORTAL_TITLE_POLICY_MAY_BE_STRICTER_BUT_MUST_NEVER_CONTRADICT_PPM',
                'MANDATORY_TITLE_QUALITY_RULES_BLOCK_UPSTREAM_BERATUNG_REPEAT_SCHEMA_HARD_OTHER_DIVERSITY_NONBLOCKING',
                'FINAL_HANDOFF_REMAINS_EXACTLY_FIVE_SCALAR_FIELDS_NO_HIDDEN_SIXTH_FIELD',
            ],
            'write_attempted'=>false,
        ];
        $out['sha256']=PSERC_Stable_Json::hash($out);return $out;
    }
    private static function norm(string $v): string {$v=strtr(trim($v),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$v=strtolower($v);return trim((string)preg_replace('/[^a-z0-9]+/','',$v));}
}
