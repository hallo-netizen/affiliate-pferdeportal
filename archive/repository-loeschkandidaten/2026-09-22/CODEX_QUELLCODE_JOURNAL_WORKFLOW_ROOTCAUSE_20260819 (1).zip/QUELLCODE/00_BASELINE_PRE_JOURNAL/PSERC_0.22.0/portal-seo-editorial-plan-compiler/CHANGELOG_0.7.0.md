# 0.7.0-semantic-slot-fail-closed

- Verhindert die belegte Zwangszuordnung eines Longtails zu einem nur formal freien, inhaltlich aber unpassenden kanonischen Planplatz.
- Gemeinsame Themenfamilienwörter allein reichen nicht mehr für eine Slotfreigabe.
- Ohne belegbares slotspezifisches Intent-Signal wird schreibfrei mit `BLOCKED_NO_SEMANTICALLY_COMPATIBLE_CANONICAL_SLOT` gestoppt.
- Aktualisiert die exakte Quellbindung auf PSTE 0.10.9-staging.
- Keine Änderung an Textmaschine, Artikeln, HTML, Design, Qualitätsregeln oder WordPress-Schreibpfaden.
