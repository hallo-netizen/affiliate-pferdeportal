<?php
if (!defined('ABSPATH')) { return; }

/**
 * Stable opaque identity for the exact-five `plan_slot` field.
 *
 * IMPORTANT: the token is derived only from the immutable canonical_article_id.
 * It deliberately excludes working_title, intent_angle, keywords, generated title,
 * category display name and any content/format/design data.
 */
final class PSERC_Plan_Slot_Identity {
    public const CONTRACT='PSERC_PLAN_SLOT_IDENTITY_V2_CANONICAL_ID_ONLY';
    private const DOMAIN='pserc-plan-slot-v2|';

    public static function token(array $slot): string {
        $id=trim((string)($slot['canonical_article_id']??''));
        if($id==='')throw new RuntimeException('PSERC_PLAN_SLOT_CANONICAL_ID_MISSING');
        return self::tokenFromCanonicalId($id);
    }

    public static function tokenFromCanonicalId(string $canonicalId): string {
        $canonicalId=trim($canonicalId);
        if($canonicalId==='')throw new RuntimeException('PSERC_PLAN_SLOT_CANONICAL_ID_MISSING');
        return hash('sha256',self::DOMAIN.$canonicalId);
    }

    public static function contract(): array {
        return [
            'contract'=>self::CONTRACT,
            'algorithm'=>'SHA256_DOMAIN_SEPARATED_CANONICAL_ARTICLE_ID',
            'domain'=>self::DOMAIN,
            'includes'=>['canonical_article_id'],
            'excludes'=>['working_title','intent_angle','search_intent_key','keyword_ownership_key','generated_title','target_keyword','category_name','body_html','body_text','content','format','design'],
            'semantic_routing_authority'=>false,
            'content_or_design_authority'=>false,
        ];
    }
}
