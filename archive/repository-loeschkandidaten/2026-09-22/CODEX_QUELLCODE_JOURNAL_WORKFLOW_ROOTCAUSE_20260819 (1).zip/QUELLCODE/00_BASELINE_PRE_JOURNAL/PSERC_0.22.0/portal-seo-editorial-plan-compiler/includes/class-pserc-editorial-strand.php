<?php
if (!defined('ABSPATH')) { return; }

/**
 * Independent editorial/content-quality compiler strand. It verifies only the already persisted SEO editorial verdict.
 * It does not consume technical compiler results, PPM slot capability, or any content/format payload.
 */
final class PSERC_Editorial_Strand {
    /** @return array<string,mixed> */
    public static function evaluate(array $topic): array {
        $title=trim((string)($topic['production_title']??''));$family=trim((string)($topic['topic_family_name']??''));$type=trim((string)($topic['article_type']??''));
        $outcome=PSERC_Editorial_Outcome_Gate::evaluate($topic,$title,$family,$type);$ok=!empty($outcome['ok']);
        return [
            'contract'=>'PSERC_EDITORIAL_STRAND_V1','status'=>$ok?'PASS':'FAIL','ok'=>$ok,'primary_status'=>$ok?'PASS':'BLOCKED_EDITORIAL_STRAND',
            'reason_codes'=>array_values(array_unique(array_map('strval',(array)($outcome['reason_codes']??[])))),'editorial_outcome_gate'=>$outcome,
            'technical_result_consumed'=>false,'ppm_capability_consumed'=>false,'title_modified'=>false,'content_or_format_created'=>false,'write_attempted'=>false,
        ];
    }
}
