# Portal SEO Redaktionsplan Compiler 0.19.0

- ersetzt die unsignierte Workflow-Freigabe V1 durch `WORKFLOW_SUPERVISOR_RELEASE_V2_SIGNED`;
- bindet STARTMASTER 0039, den eingefrorenen Workflowvertrag und den exakten 0039-Produktionsprompt kryptografisch;
- verlangt getrenntes Pre-Text-Recherche-Evidence-Gate und Post-Text-Article-Origin/Immutability-Gate;
- bindet Exact Five, finale Titel, Fact-Pack, Produktionsplan sowie body_html/body_text-Hashes;
- prüft Ed25519 ausschließlich mit eingebettetem öffentlichen Schlüssel; der private Schlüssel ist nicht Bestandteil des Plugins;
- blockiert vor jedem Fact-Pack-Import/PPM-Zugriff bei fehlender, manipulierten oder falsch signierter Freigabe;
- erzeugt/verändert weiterhin weder Artikeltext noch HTML/Design und verändert PPM 6.7.9 nicht.
- sperrt zusätzlich die vier historischen direkten PPM-Admin-Produktionsaktionen und blendet deren Produktionsmenüs aus, ohne PPM-Dateien zu verändern; der interne PPM-Aufruf über den signierten PSERC-Pfad bleibt verfügbar.
