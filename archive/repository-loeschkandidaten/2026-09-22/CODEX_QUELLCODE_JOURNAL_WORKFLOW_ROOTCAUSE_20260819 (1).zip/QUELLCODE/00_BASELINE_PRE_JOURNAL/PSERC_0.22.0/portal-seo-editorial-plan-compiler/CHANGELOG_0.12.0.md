# 0.12.0 – Intent-first title-rule compatibility

- Added a single read-only compatibility view of the active Production Machine title/article-type contracts and the stricter portal title surface.
- True rule contradictions fail closed before compilation; permissive Production Machine rules may be narrowed by compatible portal rules without being treated as a conflict.
- Title gate is check-only and never rewrites titles.
- Question mark is required for FAQ and forbidden for non-FAQ by portal policy; other special characters are rejected before handoff.
- Intent profile and intent angle are internal compiler evidence for slot selection only and never become a sixth handoff field.
- Slot ranking now considers the bound intent angle/focus while preserving the exact five-field metadata boundary.
- Compiler source capability binding now requires the intent-first PSTE read capability.
- Production/text machine remains unchanged and read-only.
- Root-cause audit of the unchanged Production Machine 6.7.9 confirmed that `content-validator.php` itself blocks when the bound target keyword is absent from the title. The compiler now mirrors that exact runtime requirement before handoff and requires the upstream `PSTE_TARGET_KEYWORD_V1_INTENT_BOUND_PPM_TITLE_COMPATIBLE` contract.
- Canonical slot selection is now two-stage: source-query/SEO evidence must first prove a concrete canonical `intent_angle`; only already-admitted slots may then be ranked. Generated title wording cannot create or upgrade intent.
- Generic comparison terms such as `test` prove comparison intent but do not invent a material, price, variant or other canonical angle. Unsupported care actions such as repair/impregnation remain blocked if the immutable plan has no matching angle.
- Capability binding is upgraded to PSTE 1.3.0 / metadata schema V4 with explicit target-keyword contract validation.
- Root-cause independence repair: the technical `target_keyword` gate validates only upstream target-keyword/raw-query/intent-profile bindings and never consumes the editorial-quality verdict; an editorial fault therefore cannot contaminate the technical strand.
