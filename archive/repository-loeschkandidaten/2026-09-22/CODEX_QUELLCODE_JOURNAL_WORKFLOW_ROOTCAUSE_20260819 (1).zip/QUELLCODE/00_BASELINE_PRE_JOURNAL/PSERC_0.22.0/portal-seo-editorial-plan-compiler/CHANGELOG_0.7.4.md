# 0.7.4 – Quellbindung auf PSTE 0.10.11

- Aktualisiert ausschließlich die exakte, schreibfreie SEO-Quellbindung auf PSTE `0.10.11-staging`, Schema 10.
- Bindet die Themenengine vollständig mit SHA-256 und Bytezahl einschließlich der neuen fail-closed Kandidatenisolation für `PSTE_CONTEXT_QUERY_MISSING`.
- Keine Änderung an Planplatzlogik, Metadatenvertrag, Textmaschine, Artikelinhalt, HTML, Design, WordPress-Schreibpfaden oder Produktionsregeln.
