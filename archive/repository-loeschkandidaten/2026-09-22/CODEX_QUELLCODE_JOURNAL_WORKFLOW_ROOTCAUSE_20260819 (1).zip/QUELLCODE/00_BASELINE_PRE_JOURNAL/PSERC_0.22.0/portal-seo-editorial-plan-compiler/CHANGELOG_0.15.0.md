# Portal SEO Redaktionsplan Compiler 0.15.0

## Systemweiter Ursachenfix: realer Exact-Five→PPM-Consumer

- Ergänzt einen tatsächlich ausführbaren Consumer zwischen exakt fünf Metadatenfeldern und der unveränderten Portal Production Machine 6.7.9.
- `plan_slot` wird ausschließlich über die kanonische ID-Identität V2 auf `canonical_article_id` aufgelöst.
- Vor PPM muss jedes Produktionspaket die kanonische ID bereits explizit tragen; `working_title`, `intent_angle` und Titelvergleich besitzen keinerlei Identitäts- oder Routingautorität.
- Der Bridge-Lauf beweist zur Laufzeit den Canonical-ID-Erstpfad mit absichtlich nicht passendem Titel, bevor PPM ausgeführt werden darf.
- Der Bridge-Code erzeugt und verändert keinerlei Artikeltext, HTML, Formatierung, Prompts, Fact-Packs, Qualitätsbindungen oder Designwerte. Inhaltstragende Paketfelder werden nur gehasht und unverändert an PPM weitergereicht.
- PPM 6.7.9 bleibt byteidentisch unverändert und alleinige Autorität für Inhalt, Qualität, Struktur, Format und Entwurfserzeugung.
- Publish bleibt gesperrt.
