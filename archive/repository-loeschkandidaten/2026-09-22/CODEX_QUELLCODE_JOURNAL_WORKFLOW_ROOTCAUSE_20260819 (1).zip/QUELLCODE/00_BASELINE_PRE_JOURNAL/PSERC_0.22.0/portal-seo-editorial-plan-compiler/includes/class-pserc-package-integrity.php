<?php
if (!defined('ABSPATH')) { return; }

/** Read-only self-integrity gate for the installed compiler package. */
final class PSERC_Package_Integrity {
    /** @return array<string,mixed> */
    public static function validate(?string $forcedRoot=null, ?array $forcedContract=null): array {
        $root=$forcedRoot!==null?rtrim($forcedRoot,'/\\').DIRECTORY_SEPARATOR:(defined('PSERC_DIR')?rtrim((string)PSERC_DIR,'/\\').DIRECTORY_SEPARATOR:'');
        if($root==='')return self::blocked('PSERC_COMPILER_PACKAGE_ROOT_MISSING');
        $contract=$forcedContract;
        if($contract===null){
            $path=$root.'contracts'.DIRECTORY_SEPARATOR.'compiler-package-binding-v1.json';
            if(!is_file($path))return self::blocked('PSERC_COMPILER_PACKAGE_BINDING_MISSING');
            try{$contract=json_decode((string)file_get_contents($path),true,512,JSON_THROW_ON_ERROR);}catch(Throwable $e){return self::blocked('PSERC_COMPILER_PACKAGE_BINDING_JSON_INVALID');}
        }
        if(!is_array($contract)||($contract['contract']??'')!=='PSERC_COMPILER_PACKAGE_BINDING_V1')return self::blocked('PSERC_COMPILER_PACKAGE_BINDING_CONTRACT_INVALID');
        $declared=(string)($contract['binding_sha256']??'');$copy=$contract;unset($copy['binding_sha256']);
        if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(PSERC_Stable_Json::hash($copy),$declared))return self::blocked('PSERC_COMPILER_PACKAGE_BINDING_HASH_MISMATCH');
        $required=(array)($contract['required_files']??[]);
        if(!$required||(int)($contract['required_file_count']??0)!==count($required))return self::blocked('PSERC_COMPILER_PACKAGE_REQUIRED_FILES_INVALID');
        $mismatches=[];
        foreach($required as $relative=>$spec){
            $relative=(string)$relative;$spec=is_array($spec)?$spec:[];$path=$root.ltrim($relative,'/\\');
            $expected=(string)($spec['sha256']??'');$expectedBytes=(int)($spec['bytes']??-1);
            $actual=is_file($path)?hash_file('sha256',$path):'';$actualBytes=is_file($path)?(int)filesize($path):-1;
            if($actual===''||!preg_match('/^[a-f0-9]{64}$/',$expected)||!hash_equals($expected,$actual)||$expectedBytes!==$actualBytes){
                $mismatches[]=['file'=>$relative,'expected_sha256'=>$expected,'actual_sha256'=>$actual,'expected_bytes'=>$expectedBytes,'actual_bytes'=>$actualBytes];
            }
        }
        if($mismatches)return self::blocked('PSERC_COMPILER_PACKAGE_DRIFT',['mismatch_count'=>count($mismatches),'mismatches'=>$mismatches]);
        $expectedVersion=(string)($contract['package_version']??'');
        $expectedBuild=(string)($contract['package_build']??'');
        if(!defined('PSERC_VERSION')||!hash_equals($expectedVersion,(string)PSERC_VERSION))return self::blocked('PSERC_COMPILER_VERSION_DRIFT',['expected'=>$expectedVersion,'actual'=>defined('PSERC_VERSION')?(string)PSERC_VERSION:'UNDEFINED']);
        if(!defined('PSERC_BUILD')||!hash_equals($expectedBuild,(string)PSERC_BUILD))return self::blocked('PSERC_COMPILER_BUILD_DRIFT',['expected'=>$expectedBuild,'actual'=>defined('PSERC_BUILD')?(string)PSERC_BUILD:'UNDEFINED']);
        return ['ok'=>true,'status'=>'PSERC_COMPILER_PACKAGE_INTEGRITY_PASS','binding_sha256'=>$declared,'package_version'=>$expectedVersion,'package_build'=>$expectedBuild,'required_file_count'=>count($required),'write_attempted'=>false];
    }
    /** @return array<string,mixed> */
    private static function blocked(string $reason,array $extra=[]): array{return array_merge(['ok'=>false,'status'=>'PSERC_COMPILER_PACKAGE_INTEGRITY_BLOCKED','reason_codes'=>[$reason],'message'=>$reason,'write_attempted'=>false],$extra);}
}
