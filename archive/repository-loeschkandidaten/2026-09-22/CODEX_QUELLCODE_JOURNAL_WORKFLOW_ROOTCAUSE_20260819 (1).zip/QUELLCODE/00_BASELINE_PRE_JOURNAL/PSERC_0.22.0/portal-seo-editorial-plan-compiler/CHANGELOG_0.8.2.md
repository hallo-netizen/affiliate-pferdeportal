# 0.8.2

- Quellbindung auf Portal SEO Themenengine 0.18.2 aktualisiert.
- Keine Änderung der Compiler-Fachlogik, Dualstranglogik oder der exakten Fünf-Feld-Grenze.
- Die read-only Compiler-Vorschau löst keinen PSTE-Metadaten-Rebuild aus; bei veraltetem PSTE-Regelstand bleibt der Reader fail-closed.
- Textmaschine, Produktionslogik, Artikelinhalt und Design bleiben unangetastet.
