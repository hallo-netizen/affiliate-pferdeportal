# 0.9.0

Gebündelte Schnittstellenreparatur: Compiler bindet sich an einen stabilen read-only Fähigkeitsvertrag der Themenengine statt an den kompletten Plugin-Dateibaum. Die exakt fünf skalaren Handoff-Felder und die Text-/Design-Firewall bleiben unverändert.
