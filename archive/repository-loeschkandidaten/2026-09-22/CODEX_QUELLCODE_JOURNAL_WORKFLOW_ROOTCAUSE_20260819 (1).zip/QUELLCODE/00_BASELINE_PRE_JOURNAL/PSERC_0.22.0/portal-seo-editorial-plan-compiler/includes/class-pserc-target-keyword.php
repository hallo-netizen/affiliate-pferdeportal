<?php
if (!defined('ABSPATH')) { return; }

/**
 * Technical read-only verification of the SEO-intent-bound production target keyword.
 * It deliberately does NOT consume the editorial-quality verdict; semantic/editorial acceptance
 * remains the independent editorial strand. Raw discovery query remains separately preserved.
 */
final class PSERC_Target_Keyword {
    public static function derive(array $topic,string $productionTitle,?array $slot=null): array {
        $keyword=self::clean((string)($topic['target_keyword']??''));$contract=(array)($topic['target_keyword_contract']??[]);$errors=[];
        if($keyword==='')$errors[]='TARGET_KEYWORD_SOURCE_MISSING';
        if(self::length($keyword)>220)$errors[]='TARGET_KEYWORD_TOO_LONG';
        if(($contract['contract']??'')!=='PSTE_TARGET_KEYWORD_V1_INTENT_BOUND_PPM_TITLE_COMPATIBLE'||($contract['status']??'')!=='PASS'||empty($contract['ok']))$errors[]='TARGET_KEYWORD_UPSTREAM_CONTRACT_NOT_PASS';
        if($keyword!==''&&!hash_equals(hash('sha256',$keyword),(string)($contract['target_keyword_sha256']??'')))$errors[]='TARGET_KEYWORD_CONTRACT_HASH_MISMATCH';
        $raw=self::firstRawKeyword($topic);$rawSha=(string)($contract['raw_query_sha256']??'');
        if($raw!==''&&(!preg_match('/^[a-f0-9]{64}$/',$rawSha)||!hash_equals(hash('sha256',$raw),$rawSha)))$errors[]='TARGET_KEYWORD_RAW_QUERY_CONTRACT_HASH_MISMATCH';
        $profile=(array)($topic['intent_profile']??[]);$expectedProfile=(string)($contract['intent_profile_sha256']??'');$actualProfile=(string)($profile['profile_sha256']??'');
        if($expectedProfile!==''&&($actualProfile===''||!hash_equals($expectedProfile,$actualProfile)))$errors[]='TARGET_KEYWORD_INTENT_PROFILE_HASH_MISMATCH';
        if($keyword!==''&&($productionTitle===''||stripos($productionTitle,$keyword)===false))$errors[]='TARGET_KEYWORD_REQUIRED_BY_PPM_NOT_VERBATIM_IN_TITLE';
        return [
            'status'=>$errors?'REVIEW_REQUIRED':'PASS','target_keyword'=>$keyword,'source'=>'SEO_INTENT_BOUND_TARGET_KEYWORD',
            'raw_keyword_preserved'=>$raw,'raw_keyword_sha256'=>$raw!==''?hash('sha256',$raw):'',
            'technical_binding'=>'UPSTREAM_TARGET_KEYWORD_CONTRACT_PLUS_RAW_QUERY_AND_INTENT_PROFILE_HASH',
            'editorial_quality_result_consumed'=>false,
            'verbatim_title_binding'=>true,'ppm_exact_title_substring_required'=>true,'raw_query_may_differ_from_target_keyword'=>true,
            'longtail_fallback_used'=>false,'errors'=>array_values(array_unique($errors)),'target_keyword_sha256'=>$keyword!==''?hash('sha256',$keyword):'',
        ];
    }
    private static function firstRawKeyword(array $topic): string {
        $record=(array)($topic['query_record']??[]);foreach(['raw_query','measured_query','language_corrected_query'] as $field){$v=self::clean((string)($record[$field]??''));if($v!=='')return $v;}
        foreach(['source_query','raw_user_question','primary_longtail_query','canonical_query'] as $field){$v=self::clean((string)($topic[$field]??''));if($v!=='')return $v;}return '';
    }
    private static function clean(string $v): string {$v=trim(html_entity_decode(strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8'));return trim((string)preg_replace('/\s+/u',' ',$v));}
    private static function length(string $v): int{return function_exists('mb_strlen')?mb_strlen($v,'UTF-8'):strlen($v);}
}
