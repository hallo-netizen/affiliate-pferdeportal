# 0.6.8-metadata-boundary-readonly

- Bindet den vollständigen Quellstand PSTE 0.10.8-staging read-only.
- Verlangt für den Textmaschinen-Handoff zusätzlich eine exakt definierte Top-Level-Struktur.
- Blockiert zusätzliche Top-Level-Felder, Veröffentlichungsfreigaben und jedes Inhalts-/Formatpayload.
- Jede Position bleibt auf exakt fünf skalare Metadatenfelder begrenzt: `title`, `target_keyword`, `category`, `article_type`, `plan_slot`.
- Keine Änderung an Textmaschine, Artikelinhalt, HTML, Überschriften, Tabellen, Listen, Links, Design oder Qualitätslogik.
