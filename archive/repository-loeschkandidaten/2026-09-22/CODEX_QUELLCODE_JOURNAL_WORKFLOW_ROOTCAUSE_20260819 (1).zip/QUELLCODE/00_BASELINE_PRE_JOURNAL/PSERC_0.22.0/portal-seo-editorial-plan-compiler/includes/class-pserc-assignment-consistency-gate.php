<?php
if (!defined('ABSPATH')) { return; }

/**
 * Read-only consistency verification of the SEO engine's already completed semantic decision.
 * Despite validating semantic-consensus fields, this class makes no semantic editorial decision. The compiler never reclassifies or repairs a candidate.
 */
final class PSERC_Assignment_Consistency_Gate {
    /** @return array<string,mixed> */
    public static function evaluate(array $topic, ?array $forcedBaseline=null, ?array $validatedStructure=null): array {
        $baseline=$forcedBaseline;
        if($baseline===null){
            $key=defined('PSTE_OPTION_SITE_BASELINE')?PSTE_OPTION_SITE_BASELINE:'pste_site_baseline_v1';
            $baseline=function_exists('get_option')?get_option($key,[]):[];
        }
        if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return self::blocked('SEMANTIC_BASELINE_NOT_AVAILABLE');
        if(!is_array($validatedStructure)||empty($validatedStructure['ok']))return self::blocked('SEMANTIC_LOGICAL_STRUCTURE_NOT_VALIDATED');

        $leaf=self::assignedLeaf($topic,array_values(array_filter((array)($baseline['leaf_categories']??[]),'is_array')));
        if(empty($leaf['ok']))return $leaf;
        $assigned=(array)$leaf['leaf'];
        $slug=(string)($assigned['slug']??'');
        $entry=PSERC_Portal_Structure_Gate::entry($validatedStructure,$slug);
        if(!is_array($entry))return self::blocked('CATEGORY_NOT_IN_VALIDATED_LOGICAL_STRUCTURE');

        $topicType=trim((string)($topic['article_type']??''));
        $topicFamily=trim((string)($topic['topic_family_name']??''));
        $entryType=trim((string)($entry['canonical_article_type']??''));
        $entryFamily=trim((string)($entry['topic_family']??''));
        if($topicType===''||$entryType===''||self::norm($topicType)!==self::norm($entryType))return self::blocked('CATEGORY_DECLARED_TYPE_MISMATCH',['assigned_type'=>$topicType,'declared_type'=>$entryType]);
        if($topicFamily===''||$entryFamily===''||self::norm($topicFamily)!==self::norm($entryFamily))return self::blocked('CATEGORY_SUBJECT_FAMILY_MISMATCH',['assigned_family'=>$topicFamily,'declared_family'=>$entryFamily]);

        $consensus=(array)($topic['semantic_consensus']??[]);
        if(($consensus['contract']??'')!=='PSTE_SEMANTIC_DOUBLE_STRAND_V3')return self::blocked('SEMANTIC_CONSENSUS_CONTRACT_INVALID',['semantic_reason_codes'=>(array)($consensus['reason_codes']??[])]);
        $membership=(array)($consensus['family_membership_gate']??[]);
        if(($membership['contract']??'')!=='PSTE_FAMILY_MEMBERSHIP_GATE_V2'||empty($membership['ok']))return self::blocked('SEMANTIC_FAMILY_MEMBERSHIP_NOT_PASSED',['semantic_reason_codes'=>(array)($membership['reason_codes']??[]),'family_membership_gate'=>$membership]);
        if(empty($consensus['ok'])||empty($consensus['type_consensus'])||empty($consensus['category_consensus'])||empty($consensus['family_consensus'])||($consensus['status']??'')!=='CONSENSUS_PASS')return self::blocked('SEMANTIC_CONSENSUS_NOT_PASSED',['semantic_reason_codes'=>(array)($consensus['reason_codes']??[]),'family_membership_gate'=>$membership]);
        $resolvedType=trim((string)($consensus['resolved_article_type']??''));
        if($resolvedType===''||self::norm($resolvedType)!==self::norm($topicType))return self::blocked('SEMANTIC_CONSENSUS_TYPE_MISMATCH');

        $a=self::validateStrand((array)($consensus['strand_a']??[]),'A',$topicType,$assigned);
        if(empty($a['ok']))return $a;
        $b=self::validateStrand((array)($consensus['strand_b']??[]),'B',$topicType,$assigned);
        if(empty($b['ok']))return $b;

        $resolved=(array)($consensus['resolved_category']??[]);
        if((int)($resolved['term_id']??0)!==(int)($assigned['term_id']??0))return self::blocked('SEMANTIC_RESOLVED_CATEGORY_ID_MISMATCH');
        if(!hash_equals((string)($resolved['slug']??''),$slug))return self::blocked('SEMANTIC_RESOLVED_CATEGORY_SLUG_MISMATCH');
        if(strcasecmp(trim((string)($resolved['name']??'')),trim((string)($assigned['name']??'')))!==0)return self::blocked('SEMANTIC_RESOLVED_CATEGORY_NAME_MISMATCH');
        if(self::norm((string)($resolved['article_type']??''))!==self::norm($topicType))return self::blocked('SEMANTIC_RESOLVED_CATEGORY_TYPE_MISMATCH');
        if(self::norm((string)($resolved['topic_family_name']??''))!==self::norm($topicFamily))return self::blocked('SEMANTIC_RESOLVED_CATEGORY_FAMILY_MISMATCH');

        return [
            'ok'=>true,'status'=>'PSERC_ASSIGNMENT_CONSISTENCY_PASS','reason_codes'=>[],
            'assigned_category_id'=>(int)($assigned['term_id']??0),'assigned_category_name'=>(string)($assigned['name']??''),'assigned_category_slug'=>$slug,
            'assigned_full_path'=>(string)($entry['full_path']??''),'assigned_family'=>$entryFamily,'resolved_family'=>$topicFamily,
            'assigned_article_type'=>$entryType,'resolved_article_type'=>$resolvedType,'family_membership_gate'=>$membership,'strand_a'=>$a['strand'],'strand_b'=>$b['strand'],
            'semantic_consensus_sha256'=>PSERC_Stable_Json::hash($consensus),'write_attempted'=>false,
        ];
    }

    /** @return array<string,mixed> */
    private static function assignedLeaf(array $topic,array $leaves): array {
        $id=(int)($topic['category_id']??0);$name=trim((string)($topic['category_name']??''));$slug=trim((string)($topic['category_slug']??''));$matches=[];
        foreach($leaves as $leaf){
            $lid=(int)($leaf['term_id']??0);$lslug=trim((string)($leaf['slug']??''));
            if(($id>0&&$lid===$id)||($slug!==''&&hash_equals($lslug,$slug)))$matches[$lid]=$leaf;
        }
        $matches=array_values($matches);
        if(count($matches)!==1)return self::blocked(count($matches)>1?'CATEGORY_ASSIGNMENT_AMBIGUOUS':'CATEGORY_NOT_IN_CURRENT_BASELINE');
        $leaf=$matches[0];
        if($id<=0||$slug===''||$name==='')return self::blocked('CATEGORY_ASSIGNMENT_INCOMPLETE');
        if((int)($leaf['term_id']??0)!==$id)return self::blocked('CATEGORY_ID_MISMATCH');
        if(!hash_equals((string)($leaf['slug']??''),$slug))return self::blocked('CATEGORY_SLUG_MISMATCH');
        if(strcasecmp((string)($leaf['name']??''),$name)!==0)return self::blocked('CATEGORY_NAME_MISMATCH');
        return ['ok'=>true,'leaf'=>$leaf];
    }

    /** @return array<string,mixed> */
    private static function validateStrand(array $strand,string $wantedStrand,string $topicType,array $assigned): array {
        if(($strand['contract']??'')!=='PSTE_RETRIEVER_RESULT_V1')return self::blocked('SEMANTIC_STRAND_CONTRACT_INVALID_'.$wantedStrand);
        if(strtoupper((string)($strand['strand']??''))!==$wantedStrand)return self::blocked('SEMANTIC_STRAND_ID_MISMATCH_'.$wantedStrand);
        if(($strand['status']??'')!=='ASSIGNED')return self::blocked('SEMANTIC_STRAND_NOT_ASSIGNED_'.$wantedStrand);
        if(self::norm((string)($strand['article_type']??''))!==self::norm($topicType))return self::blocked('SEMANTIC_STRAND_TYPE_MISMATCH_'.$wantedStrand);
        $candidates=array_values(array_filter((array)($strand['candidates']??[]),'is_array'));
        if(!$candidates)return self::blocked('SEMANTIC_STRAND_CANDIDATES_MISSING_'.$wantedStrand);
        $declared=(string)($strand['candidate_set_hash']??'');
        if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals($declared,PSERC_Stable_Json::hash($candidates)))return self::blocked('SEMANTIC_STRAND_CANDIDATE_HASH_MISMATCH_'.$wantedStrand);
        $top=(array)$candidates[0];
        if(self::norm((string)($top['article_type']??''))!==self::norm($topicType))return self::blocked('SEMANTIC_STRAND_TOP_CANDIDATE_MISMATCH_'.$wantedStrand);
        if(($strand['coverage_status']??'')!=='COVERAGE_PRESENT')return self::blocked('SEMANTIC_STRAND_COVERAGE_MISSING_'.$wantedStrand);
        if(($strand['ambiguity_status']??'')!=='CLEAR')return self::blocked('SEMANTIC_STRAND_AMBIGUOUS_'.$wantedStrand);
        $target=(array)($strand['target_category']??[]);
        if(empty($target['ok']))return self::blocked('SEMANTIC_STRAND_TARGET_CATEGORY_MISSING_'.$wantedStrand);
        if((int)($target['term_id']??0)!==(int)($assigned['term_id']??0))return self::blocked('SEMANTIC_STRAND_TARGET_CATEGORY_ID_MISMATCH_'.$wantedStrand);
        if(!hash_equals((string)($target['slug']??''),(string)($assigned['slug']??'')))return self::blocked('SEMANTIC_STRAND_TARGET_CATEGORY_SLUG_MISMATCH_'.$wantedStrand);
        $input=(array)($strand['input_contract']??[]);
        if(($input['proposed_type_received']??true)!==false||($input['proposed_category_received']??true)!==false||($input['other_strand_received']??true)!==false)return self::blocked('SEMANTIC_STRAND_INDEPENDENCE_CONTRACT_FAILED_'.$wantedStrand);
        return ['ok'=>true,'strand'=>$strand];
    }

    private static function norm(string $value): string {
        $value=strtr(trim($value),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);
        $value=function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);
        return trim((string)preg_replace('/[^a-z0-9]+/u',' ',$value));
    }
    /** @return array<string,mixed> */
    private static function blocked(string $reason,array $extra=[]): array {return array_merge(['ok'=>false,'status'=>'PSERC_ASSIGNMENT_CONSISTENCY_BLOCKED','reason_codes'=>[$reason],'message'=>$reason,'write_attempted'=>false],$extra);}
}
