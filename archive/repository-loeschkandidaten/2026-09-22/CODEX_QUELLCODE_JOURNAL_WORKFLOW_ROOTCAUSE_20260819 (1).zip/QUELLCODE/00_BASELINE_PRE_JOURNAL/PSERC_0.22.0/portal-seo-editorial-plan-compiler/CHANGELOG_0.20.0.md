# Portal SEO Redaktionsplan Compiler 0.20.0

## Root-Cause-Fix: signierte 1–4-READY-Teilmenge

- Der Produktionsstart verwendet nicht mehr zwangsweise den gesamten aktuell angezeigten Exact-Five-Batch.
- Ausschließlich die kryptografisch signierte `WORKFLOW_SUPERVISOR_RELEASE_V2_SIGNED` darf 1 bis 4 aktuell READY Planplätze auswählen.
- Die Auswahl wird aus den aktuellen Compiler-Metadaten rekonstruiert; keine Release-Inhaltsdaten werden als Metadaten übernommen.
- Jeder ausgewählte Exact-Five-Datensatz muss byte-/hashidentisch im aktuellen vollständigen Compiler-Batch vorhanden und weiterhin vollständig READY sein.
- Nicht signierte Formular- oder Plan-Auswahl bleibt unmöglich.
- STARTMASTER 0039, Textmaschine, PPM 6.7.9, Fact-Pack-/Planverträge sowie Artikelinhalt/HTML bleiben unverändert.
- Zweck: kontrollierter realer Einzelartikel-E2E-Test ohne die zwei weiteren gleichzeitig READY Kandidaten mitzustarten.
