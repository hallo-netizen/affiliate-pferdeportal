<?php
if (!defined('ABSPATH')) { return; }

/**
 * Independent technical compiler strand. It verifies structure/capability/mechanical contracts only.
 * It never reads an editorial-strand result and never composes, repairs or changes a title.
 */
final class PSERC_Technical_Strand {
    /** @return array<string,mixed> */
    public static function evaluate(array $topic,array $production,array $structure,?array $forcedBaseline=null): array {
        $type=trim((string)($topic['article_type']??''));$title=trim((string)($topic['production_title']??''));$family=trim((string)($topic['topic_family_name']??''));
        $failures=[];$primary='';
        $add=static function(string $status,array $codes)use(&$failures,&$primary): void {if($primary==='')$primary=$status;foreach($codes as $code){$code=(string)$code;if($code!=='')$failures[]=$code;}};

        if(PSERC_Metadata_Boundary::isQuestionTitle($title)&&!in_array($type,['FAQ','Journal'],true))$add('BLOCKED_QUESTION_TITLE_NOT_FAQ',['QUESTION_TITLE_NOT_FAQ']);
        if(!self::categoryMatchesStructure($topic,$type,$structure))$add('BLOCKED_CATEGORY_ARTICLE_TYPE_MISMATCH',['CATEGORY_ARTICLE_TYPE_MISMATCH']);
        $planningRegistered=array_values(array_unique(array_merge((array)($production['registered_article_types']??[]),(array)($production['planning_registered_article_types']??[]))));
        if(!in_array($type,$planningRegistered,true))$add('HELD_UNSUPPORTED_ARTICLE_TYPE',['ARTICLE_TYPE_NOT_REGISTERED_BY_UNCHANGED_TEXTMACHINE']);
        if(!in_array($type,(array)($production['supported_article_types']??[]),true))$add('HELD_NO_ACTIVE_NORMAL_DRAFT_RELEASE',['ARTICLE_TYPE_NOT_RELEASED_BY_UNCHANGED_TEXTMACHINE']);

        $assignment=PSERC_Assignment_Consistency_Gate::evaluate($topic,$forcedBaseline,$structure);
        if(empty($assignment['ok']))$add('BLOCKED_ASSIGNMENT_CONSISTENCY',(array)($assignment['reason_codes']??['ASSIGNMENT_CONSISTENCY_BLOCKED']));

        $contract=PSERC_Production_Reader::titleContract($production,$type);$titleGate=[];$keyword=PSERC_Target_Keyword::derive($topic,$title,null);
        if(($keyword['status']??'')!=='PASS')$add('REVIEW_REQUIRED_TARGET_KEYWORD',(array)($keyword['errors']??['TARGET_KEYWORD_BLOCKED']));
        if(!$contract)$add('HELD_NO_TITLE_CONTRACT',['TITLE_CONTRACT_MISSING']);
        else{
            $titleGate=PSERC_Title_Gate::verify($title,$type,$contract,(string)($keyword['target_keyword']??''));
            if(($titleGate['status']??'')!=='PASS')$add('REVIEW_REQUIRED_TITLE_COMPATIBILITY',(array)($titleGate['errors']??['TITLE_GATE_BLOCKED']));
        }

        // This gate is check-only and returns the input title byte-for-byte.
        $language=PSERC_Language_Gate::normalizeAndEvaluate($title,$type,$family,(array)($structure['capitalization_vocabulary']??[]));
        if(empty($language['ok']))$add('BLOCKED_LANGUAGE_GATE',(array)($language['reason_codes']??['LANGUAGE_GATE_BLOCKED']));
        if((string)($language['production_title']??'')!==$title)$add('BLOCKED_LANGUAGE_GATE',['LANGUAGE_GATE_MODIFIED_TITLE_FORBIDDEN']);

        $failures=array_values(array_unique(array_filter(array_map('strval',$failures))));$ok=$failures===[];
        return [
            'contract'=>'PSERC_TECHNICAL_STRAND_V1','status'=>$ok?'PASS':'FAIL','ok'=>$ok,'primary_status'=>$ok?'PASS':$primary,'reason_codes'=>$failures,
            'assignment_consistency_gate'=>$assignment,'target_keyword_gate'=>$keyword,'title_contract_available'=>(bool)$contract,'title_gate'=>$titleGate,'language_gate'=>$language,
            'question_type_check'=>!(PSERC_Metadata_Boundary::isQuestionTitle($title)&&!in_array($type,['FAQ','Journal'],true)),'category_structure_check'=>self::categoryMatchesStructure($topic,$type,$structure),
            'ppm_registered_type'=>in_array($type,(array)($production['registered_article_types']??[]),true),'planning_registered_type'=>in_array($type,$planningRegistered,true),'ppm_released_type'=>in_array($type,(array)($production['supported_article_types']??[]),true),
            'editorial_result_consumed'=>false,'title_modified'=>false,'content_or_format_created'=>false,'write_attempted'=>false,
        ];
    }

    private static function categoryMatchesStructure(array $topic,string $type,array $structure): bool {
        $slug=trim((string)($topic['category_slug']??''));if($slug===''||$type==='')return false;
        $entry=PSERC_Portal_Structure_Gate::entry($structure,$slug);if(!is_array($entry))return false;
        return self::norm((string)($entry['canonical_article_type']??''))===self::norm($type);
    }
    private static function norm(string $value): string {$value=strtr(trim($value),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$value=function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);return trim((string)preg_replace('/[^a-z0-9]+/u',' ',$value));}
}
