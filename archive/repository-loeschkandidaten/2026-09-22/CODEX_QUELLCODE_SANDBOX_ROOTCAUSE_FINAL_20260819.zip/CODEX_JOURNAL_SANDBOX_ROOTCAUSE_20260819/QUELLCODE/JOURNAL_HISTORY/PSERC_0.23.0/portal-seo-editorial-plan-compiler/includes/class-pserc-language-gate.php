<?php
if (!defined('ABSPATH')) { return; }

/** Independent mechanical language verification in check-only mode; it never repairs the editorial title. */
final class PSERC_Language_Gate {
    /** @return array<string,mixed> */
    public static function normalizeAndEvaluate(string $title,string $articleType,string $family,array $capitalizationVocabulary=[]): array {
        $original=trim($title);$wouldBe=self::normalize($original,$family,$capitalizationVocabulary);$reasons=[];
        if($original==='')$reasons[]='LANGUAGE_TITLE_EMPTY';
        if($wouldBe!==$original)$reasons[]='LANGUAGE_UPSTREAM_SURFACE_NORMALIZATION_REQUIRED';
        if(str_contains($original,':'))$reasons[]='LANGUAGE_COLON_FORBIDDEN';
        if(preg_match('/[<>]|\{\{|\[\[|<\/?[a-z]/iu',$original))$reasons[]='LANGUAGE_MARKUP_FORBIDDEN';
        $words=preg_split('/\s+/u',rtrim($original,'?'))?:[];if(count($words)<3||count($words)>16)$reasons[]='LANGUAGE_TITLE_LENGTH_OUTSIDE_SAFE_RANGE';
        if(preg_match('/\b([\p{L}\d-]+)\s+\1\b/iu',$original))$reasons[]='LANGUAGE_REPEATED_WORD';
        $question=self::isQuestion($original);$canon=self::norm($articleType);if($canon==='faq'){if(!$question||!str_ends_with($original,'?'))$reasons[]='LANGUAGE_FAQ_QUESTION_REQUIRED';}elseif($canon==='journal'){if(str_contains($original,'?')&&(!$question||!str_ends_with($original,'?')))$reasons[]='LANGUAGE_JOURNAL_QUESTION_MARK_INVALID';}elseif($question||str_contains($original,'?'))$reasons[]='LANGUAGE_NONFAQ_QUESTION_FORBIDDEN';
        $reasons=array_values(array_unique($reasons));
        return ['ok'=>$reasons===[],'status'=>$reasons===[]?'PSERC_LANGUAGE_GATE_PASS':'PSERC_LANGUAGE_GATE_BLOCKED','original_title'=>$original,'production_title'=>$original,'automatic_changes'=>[],'reason_codes'=>$reasons,'review_scope'=>'CHECK_ONLY_MECHANICAL_LANGUAGE_NO_SEMANTIC_CLAIM_NO_EDITORIAL_REPAIR_NO_ARTICLE_CONTENT','capitalization_vocabulary_sha256'=>PSERC_Stable_Json::hash($capitalizationVocabulary),'write_attempted'=>false];
    }
    private static function normalize(string $title,string $family,array $vocabulary): string {$title=trim((string)preg_replace('/\s+/u',' ',$title));if($title==='')return '';$title=self::uppercaseFirst($title);if($family!=='')$title=(string)preg_replace('/\b'.preg_quote($family,'/').'\b/iu',$family,$title);$title=(string)preg_replace_callback('/\b[\p{L}][\p{L}-]*\b/u',static function(array $m)use($vocabulary): string {$word=(string)$m[0];$key=self::lower($word);$canonical=$vocabulary[$key]??null;return is_string($canonical)&&$canonical!==''?$canonical:$word;},$title);return trim($title);}
    private static function isQuestion(string $value): bool {return str_ends_with(trim($value),'?')||(bool)preg_match('/^(wie|was|wann|warum|wieso|weshalb|welche|welcher|welches|worauf|wieviel|wie viel|kann|können|koennen|darf|dürfen|duerfen|soll|sollen|muss|müssen|muessen|sind|ist|gibt|braucht|benötigt|benoetigt)\b/iu',trim($value));}
    private static function containsFamily(string $title,string $family): bool {$title=array_values(array_unique(self::tokens($title)));$family=array_values(array_unique(self::tokens($family)));return $family!==[]&&count(array_intersect($family,$title))===count($family);}
    private static function tokens(string $value): array {$value=strtr($value,['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$value=self::lower($value);$value=preg_replace('/[^a-z0-9]+/u',' ',$value)??'';$out=[];foreach(array_values(array_filter(preg_split('/\s+/u',trim($value))?:[])) as $token){if(in_array($token,['der','die','das','den','dem','des','ein','eine','einer','einem','einen','und','oder','von','fuer','fur','bei','beim','im','in','auf','mit','zu','zum','zur'],true))continue;foreach(['ern','en','er','es','e','n','s'] as $suffix){if(strlen($token)>strlen($suffix)+4&&str_ends_with($token,$suffix)){$token=substr($token,0,-strlen($suffix));break;}}if($token!=='')$out[]=$token;}return $out;}
    private static function norm(string $v): string {return implode(' ',self::tokens($v));}
    private static function uppercaseFirst(string $v): string {if($v==='')return '';$f=function_exists('mb_substr')?mb_substr($v,0,1,'UTF-8'):substr($v,0,1);$r=function_exists('mb_substr')?mb_substr($v,1,null,'UTF-8'):substr($v,1);$f=function_exists('mb_strtoupper')?mb_strtoupper($f,'UTF-8'):strtoupper($f);return $f.$r;}
    private static function lower(string $v): string{return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
}
