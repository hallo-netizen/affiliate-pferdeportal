<?php
if (!defined('ABSPATH')) { return; }

/**
 * Read-only capability binding to unchanged signed Portal Production Machine 6.7.9.
 * Journal is registered additively in PSERC as planning-only by reading the already-existing
 * dormant PPM Journal/Wissen plan; PPM files and its signed release gate remain untouched.
 *
 * Unlike the old implementation this does not freeze unrelated source bytes in
 * the compiler. It validates the production machine's own self-hashed contracts,
 * the protected quality hashes declared by the normal-draft release contract,
 * the exact public intake policy and the internally declared editorial-plan
 * counts. Any relevant drift still blocks; harmless comments or unrelated files
 * no longer require a compiler rebuild.
 */
final class PSERC_Production_Reader {
    private const REQUIRED_INTERFACE_FILES=[
        'portal-production-machine.php',
        'contracts/article-type-templates.json',
        'contracts/editorial-plan-governance-v1.json',
        'contracts/canonical-complete-editorial-plan-v1.json',
        'contracts/normal-draft-release-v1.json',
        'contracts/production-plan-v4.json',
        'contracts/production-plan-v5.json',
        'includes/content-validator.php',
        'includes/plan-validator.php',
        'includes/editorial-plan-registry.php',
        'includes/normal-draft-pipeline.php',
        'includes/normal-draft-release-validator.php',
        'includes/normal-draft-adapter.php',
        'includes/article-type-validator.php',
        'includes/systemwide-duplicate-guard.php',
        'includes/production-wave-governor.php',
    ];

    public static function snapshot(?string $forcedRoot=null): array {
        $root=$forcedRoot!==null?rtrim($forcedRoot,'/\\').DIRECTORY_SEPARATOR:self::locateRoot();
        if($root==='')return self::blocked('PSERC_PRODUCTION_MACHINE_NOT_FOUND','Portal Production Machine wurde nicht gefunden.');
        foreach(self::REQUIRED_INTERFACE_FILES as $relative){if(!is_file($root.$relative))return self::blocked('PSERC_PRODUCTION_INTERFACE_FILE_MISSING','Eine erforderliche Produktionsschnittstelle fehlt.',['file'=>$relative]);}
        $version=self::pluginVersion($root.'portal-production-machine.php');
        if(!hash_equals('6.7.9',$version))return self::blocked('PSERC_PRODUCTION_VERSION_UNSUPPORTED','Die installierte Production Machine besitzt nicht die freigegebene Version 6.7.9.',['expected'=>'6.7.9','actual'=>$version]);

        $types=self::readJson($root.'contracts/article-type-templates.json');
        $governance=self::readJson($root.'contracts/editorial-plan-governance-v1.json');
        $plan=self::readJson($root.'contracts/canonical-complete-editorial-plan-v1.json');
        $normalRelease=self::readJson($root.'contracts/normal-draft-release-v1.json');
        $planV4=self::readJson($root.'contracts/production-plan-v4.json');
        $planV5=self::readJson($root.'contracts/production-plan-v5.json');
        if(!$types||!$governance||!$plan||!$normalRelease||!$planV4||!$planV5)return self::blocked('PSERC_PRODUCTION_CONTRACT_INVALID','Mindestens ein benötigter Produktionsvertrag ist keine gültige JSON-Datei.');
        $journalRegistration=self::journalRegistration($root,$plan);
        if(empty($journalRegistration['ok']))return $journalRegistration;
        foreach([
            'contracts/canonical-complete-editorial-plan-v1.json'=>$plan,
            'contracts/normal-draft-release-v1.json'=>$normalRelease,
        ] as $relative=>$contract){$check=self::validateSelfHash($contract,$relative);if(empty($check['ok']))return $check;}
        foreach([
            'contracts/article-type-templates.json'=>$types,
            'contracts/editorial-plan-governance-v1.json'=>$governance,
        ] as $relative=>$contract){if(isset($contract['contract_self_sha256'])){$check=self::validateSelfHash($contract,$relative);if(empty($check['ok']))return $check;}}

        $releaseCheck=self::validateNormalRelease($root,$normalRelease,$types);if(empty($releaseCheck['ok']))return $releaseCheck;
        $slots=array_values(array_filter((array)($plan['slots']??[]),'is_array'));
        $declared=(int)($plan['counts']['total_slots']??0);
        if($declared<=0||count($slots)!==$declared)return self::blocked('PSERC_EDITORIAL_PLAN_DECLARED_COUNT_MISMATCH','Die intern deklarierte Planpositionszahl stimmt nicht mit dem selbstgehashten Plan überein.',['declared'=>$declared,'actual'=>count($slots)]);
        $ids=[];foreach($slots as $slot){$id=trim((string)($slot['canonical_article_id']??''));if($id===''||isset($ids[$id]))return self::blocked('PSERC_EDITORIAL_PLAN_SLOT_ID_INVALID','Der kanonische Plan enthält eine leere oder doppelte Plan-ID.',['canonical_article_id'=>$id]);$ids[$id]=true;}

        $governanceAllowed=array_values(array_unique(array_map('strval',(array)($governance['first_wave']['allowed_article_types']??[]))));
        $definitions=(array)($types['types']??[]);$requiredCertification=strtoupper(trim((string)($types['certification_policy']['production_requires']??'CERTIFIED')));
        $releaseAllowed=array_values(array_unique(array_map('strval',(array)($normalRelease['allowed_article_types']??[]))));$releaseBindings=(array)($normalRelease['type_bindings']??[]);
        $registered=[];$globallyCertified=[];$normalDraftSupported=[];$runtime=[];
        foreach($governanceAllowed as $type){if(!isset($definitions[$type])||!is_array($definitions[$type]))continue;$definition=$definitions[$type];$productionAllowed=($definition['production_allowed']??false)===true;$certificationStatus=strtoupper(trim((string)($definition['certification_status']??'')));$globallyReady=$productionAllowed&&$requiredCertification!==''&&hash_equals($requiredCertification,$certificationStatus);$releaseListed=in_array($type,$releaseAllowed,true);$bindingMatches=$releaseListed&&isset($releaseBindings[$type])&&is_array($releaseBindings[$type])&&self::bindingMatches($definition,$releaseBindings[$type]);$normalReady=$releaseListed&&$bindingMatches;$registered[]=$type;if($globallyReady)$globallyCertified[]=$type;if($normalReady)$normalDraftSupported[]=$type;$runtime[$type]=['governance_allowed'=>true,'definition_present'=>true,'global_production_allowed'=>$productionAllowed,'global_certification_status'=>$certificationStatus,'global_required_certification_status'=>$requiredCertification,'global_production_ready'=>$globallyReady,'normal_draft_release_listed'=>$releaseListed,'normal_draft_type_binding_matches'=>$bindingMatches,'normal_draft_production_ready'=>$normalReady,'effective_release_path'=>$normalReady?'NORMAL_DRAFT_RELEASE_SCOPE_V1':'NONE','reason_codes'=>$normalReady?[]:['NORMAL_DRAFT_RELEASE_TYPE_BINDING_MISMATCH']];}
        $planningRegistered=['Journal'];
        $runtime['Journal']=['governance_allowed'=>false,'planning_only_registered'=>true,'definition_present'=>true,'global_production_allowed'=>false,'global_certification_status'=>'REGISTERED_PLANNING_ONLY','global_required_certification_status'=>$requiredCertification,'global_production_ready'=>false,'normal_draft_release_listed'=>false,'normal_draft_type_binding_matches'=>false,'normal_draft_production_ready'=>false,'effective_release_path'=>'NONE','reason_codes'=>['JOURNAL_REGISTERED_PLANNING_ONLY_SIGNED_PPM_DRAFT_RELEASE_PENDING']];
        if(!$registered)return self::blocked('PSERC_NO_REGISTERED_ARTICLE_TYPES','Kein Beitragstyp des Produktionsvertrags konnte gelesen werden.');
        if(!$normalDraftSupported)return self::blocked('PSERC_NORMAL_DRAFT_RELEASE_HAS_NO_SUPPORTED_TYPES','Der normale Draft-Freigabepfad gibt aktuell keinen Beitragstyp frei.');

        $hashes=[];foreach(self::REQUIRED_INTERFACE_FILES as $relative)$hashes[$relative]=hash_file('sha256',$root.$relative);
        return ['ok'=>true,'status'=>'PRODUCTION_READ_ONLY_NORMAL_DRAFT_CAPABILITY_PASS','root'=>$root,'version'=>$version,'hashes'=>$hashes,'baseline_sha256'=>PSERC_Stable_Json::hash(['version'=>$version,'release_self_hash'=>(string)$normalRelease['contract_self_sha256'],'plan_self_hash'=>(string)$plan['contract_self_sha256'],'protected_quality_hashes'=>(array)($normalRelease['protected_quality_hashes']??[])]),'article_type_contract'=>$types,'governance'=>$governance,'plan'=>$plan,'production_plan_v4'=>$planV4,'production_plan_v5'=>$planV5,'normal_draft_release'=>$normalRelease,'normal_draft_release_sha256'=>hash_file('sha256',$root.'contracts/normal-draft-release-v1.json'),'normal_draft_release_self_hash'=>(string)$normalRelease['contract_self_sha256'],'registered_article_types'=>$registered,'planning_registered_article_types'=>$planningRegistered,'globally_certified_article_types'=>$globallyCertified,'supported_article_types'=>$normalDraftSupported,'normal_draft_supported_article_types'=>$normalDraftSupported,'article_type_runtime'=>$runtime,'journal_registration'=>$journalRegistration,'required_certification_status'=>$requiredCertification,'batch_policy'=>['minimum_articles'=>(int)$normalRelease['minimum_articles'],'maximum_articles'=>(int)$normalRelease['maximum_articles'],'maximum_articles_per_type'=>(int)$normalRelease['maximum_articles_per_type'],'publish_allowed'=>(bool)$normalRelease['publish_allowed'],'wissen_allowed'=>(bool)$normalRelease['wissen_allowed'],'scope_mode'=>(string)$normalRelease['scope_mode']],'editorial_plan_slot_count'=>$declared,'binding_mode'=>'SELF_HASHED_CAPABILITY_AND_PROTECTED_QUALITY','write_attempted'=>false];
    }

    public static function titleContract(array $snapshot,string $articleType): array {if(strtolower(trim($articleType))==='journal')return (array)($snapshot['journal_registration']['title_contract']??[]);$types=(array)($snapshot['article_type_contract']['types']??[]);return isset($types[$articleType]['title_contract'])&&is_array($types[$articleType]['title_contract'])?$types[$articleType]['title_contract']:[];}
    private static function journalRegistration(string $ppmRoot,array $plan): array {
        $localRoot=defined('PSERC_DIR')?rtrim((string)PSERC_DIR,'/\\').DIRECTORY_SEPARATOR:dirname(__DIR__).DIRECTORY_SEPARATOR;
        $localPath=$localRoot.'contracts'.DIRECTORY_SEPARATOR.'journal-article-type-v1.json';
        $ppmJournalPath=$ppmRoot.'contracts'.DIRECTORY_SEPARATOR.'journal-content-block-v1.json';
        if(!is_file($localPath)||!is_file($ppmJournalPath))return self::blocked('PSERC_JOURNAL_REGISTRATION_CONTRACT_MISSING','Journal-Registrierungsvertrag oder vorhandenes PPM-Journalregister fehlt.');
        $local=self::readJson($localPath);$ppmJournal=self::readJson($ppmJournalPath);
        if(!$local||!$ppmJournal)return self::blocked('PSERC_JOURNAL_REGISTRATION_CONTRACT_INVALID','Journal-Registrierungsvertrag oder PPM-Journalregister ist ungültig.');
        $claimed=strtolower(trim((string)($local['contract_self_sha256']??'')));$copy=$local;unset($copy['contract_self_sha256']);$actual=PSERC_Stable_Json::hash($copy);
        if(!preg_match('/^[a-f0-9]{64}$/',$claimed)||!hash_equals($claimed,$actual))return self::blocked('PSERC_JOURNAL_REGISTRATION_SELF_HASH_MISMATCH','Der lokale Journal-Registrierungsvertrag ist nicht selbstkonsistent.');
        if((string)($local['article_type']??'')!=='Journal'||(string)($local['ppm_bridge']['required_ppm_version']??'')!=='6.7.9')return self::blocked('PSERC_JOURNAL_REGISTRATION_SCOPE_INVALID','Der Journal-Registrierungsvertrag besitzt nicht den freigegebenen Scope.');
        $block=(array)($ppmJournal['content_block']??[]);$allowed=array_values(array_map('strtolower',array_map('strval',(array)($block['allowed_article_types']??[]))));
        if(!in_array('wissen',$allowed,true)||($block['draft_generation_allowed']??null)!==false||($block['automatic_publish_allowed']??null)!==false)return self::blocked('PSERC_PPM679_DORMANT_JOURNAL_BRIDGE_INVALID','Das unveränderte PPM-6.7.9-Journalregister besitzt nicht mehr den erwarteten gesperrten Wissen-Planstatus.');
        $journalSlots=[];$ids=[];
        foreach((array)($plan['slots']??[]) as $slot){if(!is_array($slot)||strtolower((string)($slot['content_block']??''))!=='journal')continue;if((string)($slot['article_type']??'')!=='Wissen')return self::blocked('PSERC_PPM679_JOURNAL_SLOT_TYPE_DRIFT','Ein vorhandener Journal-Planplatz ist nicht mehr der erwartete interne Wissen-Platzhalter.');if(($slot['draft_generation_allowed']??null)!==false||($slot['publish_allowed']??null)!==false)return self::blocked('PSERC_PPM679_JOURNAL_SLOT_RELEASE_DRIFT','Ein vorhandener Journal-Planplatz ist unerwartet produktiv freigegeben.');$id=trim((string)($slot['canonical_article_id']??''));if($id===''||isset($ids[$id]))return self::blocked('PSERC_PPM679_JOURNAL_SLOT_ID_INVALID','Journal-Plan-ID fehlt oder ist doppelt.');$ids[$id]=true;$journalSlots[]=$slot;}
        $expected=(int)($local['ppm_bridge']['expected_existing_journal_slot_count']??40);if(count($journalSlots)!==$expected)return self::blocked('PSERC_PPM679_JOURNAL_SLOT_COUNT_DRIFT','Die Zahl der vorhandenen dormant Journal-Planplätze hat sich geändert.',['expected'=>$expected,'actual'=>count($journalSlots)]);
        $categories=array_values(array_filter((array)($ppmJournal['categories']??[]),'is_array'));
        if(count($categories)!==(int)($ppmJournal['category_count']??-1))return self::blocked('PSERC_PPM679_JOURNAL_CATEGORY_COUNT_DRIFT','Das vorhandene PPM-Journalregister ist intern inkonsistent.');
        return ['ok'=>true,'status'=>'PSERC_JOURNAL_PLANNING_REGISTRATION_PASS','article_type'=>'Journal','canonical_type_id'=>'journal','scope'=>'JOURNAL_CONTENT_BLOCK_ONLY','title_contract'=>(array)($local['title_contract']??[]),'structure_contract'=>(array)($local['structure_contract']??[]),'selection_policy'=>(string)($local['selection_policy']??''),'ppm_bridge'=>['version'=>'6.7.9','legacy_internal_article_type'=>'Wissen','external_article_type'=>'Journal','canonical_slot_count'=>count($journalSlots),'canonical_article_ids'=>array_keys($ids),'canonical_article_ids_sha256'=>PSERC_Stable_Json::hash(array_keys($ids)),'active_journal_category_count'=>count($categories),'ppm_journal_registry_sha256'=>hash_file('sha256',$ppmJournalPath),'ppm_canonical_plan_sha256'=>hash_file('sha256',$ppmRoot.'contracts'.DIRECTORY_SEPARATOR.'canonical-complete-editorial-plan-v1.json'),'ppm_files_modified'=>false,'normal_draft_release_active'=>false],'pending_category'=>(array)($local['category_scope']['pending_category']??[]),'five_field_handoff'=>(array)($local['five_field_handoff']??[]),'runtime_route_activation'=>(string)($local['runtime_route_activation']??''),'normal_draft_release'=>false,'publish_allowed'=>false,'workflow_change'=>false,'textmachine_change'=>false,'other_article_type_rule_change'=>false,'write_attempted'=>false];
    }

    private static function validateSelfHash(array $contract,string $relative): array {$claimed=strtolower(trim((string)($contract['contract_self_sha256']??'')));$copy=$contract;unset($copy['contract_self_sha256']);$actual=PSERC_Stable_Json::hash($copy);return preg_match('/^[a-f0-9]{64}$/',$claimed)&&hash_equals($claimed,$actual)?['ok'=>true]:self::blocked('PSERC_PRODUCTION_CONTRACT_SELF_HASH_MISMATCH','Ein Produktionsvertrag ist nicht selbstkonsistent.',['file'=>$relative,'expected'=>$actual,'actual'=>$claimed]);}
    private static function validateNormalRelease(string $root,array $release,array $types): array {
        $exact=['contract'=>'NORMAL_DRAFT_RELEASE_SCOPE_V1','version'=>'1.0.0','scope_mode'=>'REUSABLE_NORMAL_DRAFT_1_TO_4','minimum_articles'=>1,'maximum_articles'=>4,'maximum_articles_per_type'=>1,'wissen_allowed'=>false,'publish_allowed'=>false,'global_article_type_flags_may_change'=>false,'canonical_articles_must_be_pre_researched'=>true,'plugin_text_generation_allowed'=>false,'existing_content_update_allowed'=>false,'existing_content_delete_allowed'=>false];
        foreach($exact as $field=>$wanted)if(PSERC_Stable_Json::hash($release[$field]??null)!==PSERC_Stable_Json::hash($wanted))return self::blocked('PSERC_NORMAL_DRAFT_RELEASE_POLICY_MISMATCH','Der normale Draft-Freigabevertrag besitzt nicht die geprüfte Sicherheitsgrenze.',['field'=>$field,'expected'=>$wanted,'actual'=>$release[$field]??null]);
        $allowed=array_values((array)($release['allowed_article_types']??[]));if(!$allowed||count($allowed)!==count(array_unique(array_map('strval',$allowed))))return self::blocked('PSERC_NORMAL_DRAFT_RELEASE_TYPES_INVALID','Die Typfreigabe ist leer oder enthält Duplikate.');
        $definitions=(array)($types['types']??[]);$bindings=(array)($release['type_bindings']??[]);foreach($allowed as $type){$type=(string)$type;if(!isset($definitions[$type])||!is_array($definitions[$type])||!isset($bindings[$type])||!is_array($bindings[$type])||!self::bindingMatches($definitions[$type],$bindings[$type]))return self::blocked('PSERC_NORMAL_DRAFT_RELEASE_TYPE_BINDING_MISMATCH','Ein freigegebener Beitragstyp besitzt keine gültige Bindung.',['article_type'=>$type]);}
        foreach((array)($release['protected_quality_hashes']??[]) as $relative=>$wanted){$path=$root.ltrim((string)$relative,'/\\');$got=is_file($path)?hash_file('sha256',$path):'';if($got===''||!hash_equals((string)$wanted,$got))return self::blocked('PSERC_NORMAL_DRAFT_RELEASE_PROTECTED_HASH_MISMATCH','Eine geschützte Qualitätsdatei ist verändert.',['file'=>$relative,'expected'=>$wanted,'actual'=>$got]);}
        return ['ok'=>true,'status'=>'NORMAL_DRAFT_RELEASE_READ_ONLY_PASS','write_attempted'=>false];
    }
    private static function bindingMatches(array $definition,array $binding): bool {$actual=['production_allowed'=>$definition['production_allowed']??null,'certification_status'=>$definition['certification_status']??null,'definition_hash'=>$definition['certification_evidence']['definition_hash']??null,'evidence_hash'=>$definition['certification_evidence']['evidence_hash']??null];return hash_equals(PSERC_Stable_Json::hash($binding),PSERC_Stable_Json::hash($actual));}
    private static function pluginVersion(string $path): string {$head=(string)file_get_contents($path,false,null,0,8192);return preg_match('/^[ \t\/*#@]*Version:\s*(.+)$/mi',$head,$m)?trim((string)$m[1]):'';}
    private static function locateRoot(): string {$base=defined('WP_PLUGIN_DIR')?rtrim((string)WP_PLUGIN_DIR,'/\\').DIRECTORY_SEPARATOR:'';if($base==='')return '';$direct=$base.'portal-production-machine'.DIRECTORY_SEPARATOR;if(is_file($direct.'portal-production-machine.php'))return $direct;$matches=glob($base.'*'.DIRECTORY_SEPARATOR.'portal-production-machine.php')?:[];return count($matches)===1?dirname($matches[0]).DIRECTORY_SEPARATOR:'';}
    private static function readJson(string $path): ?array {if(!is_file($path))return null;$decoded=json_decode((string)file_get_contents($path),true);return is_array($decoded)?$decoded:null;}
    private static function blocked(string $status,string $message,array $extra=[]): array {return array_merge(['ok'=>false,'status'=>$status,'message'=>$message,'write_attempted'=>false],$extra);}
}
