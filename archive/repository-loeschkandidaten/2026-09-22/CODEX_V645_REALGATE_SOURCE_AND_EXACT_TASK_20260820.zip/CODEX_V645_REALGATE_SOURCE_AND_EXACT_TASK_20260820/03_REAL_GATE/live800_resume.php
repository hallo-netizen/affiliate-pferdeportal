<?php
require __DIR__.'/lib.php';
rg_settings_business_only();$uuid='110e36b0-ad6-live-v644-realdb';
rg_reset_run(rg_base_run($uuid,800,537));
$ticks=0;$last=0;
while(($r=rg_run()) && ($r['phase']??'')==='selection_prepare' && $ticks<60){rg_tick();$ticks++;$a=rg_run();$c=absint($a['phase_state']['selection']['prepare_business_index']??0);rg_assert($c>=$last,'live-800 recovery cursor is monotone on every persisted package');$last=$c;}
$f=rg_run();
rg_assert($ticks===39,'V6.44-style package-800 run needs exactly 39 real BUSINESS prepare packages');
rg_assert(($f['run_uuid']??'')===$uuid,'V6.44-style package-800 recovery keeps same UUID');
rg_assert(($f['phase']??'')==='business_select','V6.44-style package-800 run exits selection_prepare');
rg_assert(absint($f['phase_state']['selection']['prepare_business_index']??0)===311,'V6.44-style package-800 run reaches all 311 families');
rg_assert(absint($f['transport_tick_count']??0)===839,'historical transport count is preserved; only 39 real packages are added');
rg_assert(absint($f['phase_tick_count']??0)===39,'phase tick count reflects only the resumed selection_prepare work');
rg_assert(absint($f['selection_prepare_tick_limit']??0)===41,'BUSINESS-only hard prepare budget is derived as 41 packages');
rg_assert(absint($f['no_progress_count']??0)===0,'V6.44-style resume records genuine progress throughout');
echo "LIVE800_OK ticks=$ticks transport=".absint($f['transport_tick_count']??0)." cursor=".absint($f['phase_state']['selection']['prepare_business_index']??0)."\n";
