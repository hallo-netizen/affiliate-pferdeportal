<?php
require __DIR__.'/lib.php';
global $wpdb;
rg_assert((string)get_bloginfo('version')==='7.0.1','WordPress core is exactly 7.0.1');
rg_assert(version_compare(PHP_VERSION,'8.4.0','>=') && version_compare(PHP_VERSION,'8.5.0','<'),'PHP runtime is 8.4.x');
rg_assert(extension_loaded('mysqli'),'mysqli extension is loaded');
rg_assert(is_object($wpdb) && !empty($wpdb->options),'real wpdb options table is active');
$v=(string)$wpdb->get_var('SELECT VERSION()');
rg_assert(stripos($v,'MariaDB')!==false,'real MariaDB server is active: '.$v);
$table=$wpdb->prefix.'ppar_ebay_items';
$exists=(string)$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table));
rg_assert($exists===$table,'production ppar_ebay_items schema exists in MariaDB');
rg_assert(Pferdeportal_Affiliate_Router::VERSION==='6.45.0','tested plugin version is 6.45.0');
echo 'ENVIRONMENT_OK WP='.get_bloginfo('version').' PHP='.PHP_VERSION.' DB='.$v."\n";
