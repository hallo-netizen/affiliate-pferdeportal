<?php
require __DIR__.'/lib.php';
$dir=getenv('RG_SHARED_DIR') ?: '/shared';
$id=getenv('RG_WORKER_ID') ?: (string)getmypid();
$before=rg_run();
@file_put_contents($dir.'/ready-'.$id,'1');
$deadline=microtime(true)+60;
while(!file_exists($dir.'/go')) { if(microtime(true)>$deadline){@file_put_contents($dir.'/result-'.$id,'TIMEOUT');exit(2);} usleep(10000); }
$p=rg_plugin();
$ref=new ReflectionMethod($p,'ebay_run_acquire_lease');
$ref->setAccessible(true);
$run=$before;
$args=array(&$run);
$token=$ref->invokeArgs($p,$args);
$line=json_encode(array(
  'id'=>$id,
  'acquired'=>($token!==false ? 1 : 0),
  'token'=>($token!==false ? (string)$token : ''),
  'before_owner'=>(string)($before['owner']??''),
  'after_owner'=>(string)($run['owner']??''),
  'uuid'=>(string)($run['run_uuid']??''),
),JSON_UNESCAPED_SLASHES);
@file_put_contents($dir.'/result-'.$id,$line);
echo $line."\n";
