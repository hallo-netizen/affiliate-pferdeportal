<?php
require __DIR__.'/lib.php';
$dir=getenv('RG_SHARED_DIR') ?: '/shared';
$files=glob($dir.'/result-*') ?: array();
$acquired=0;
foreach($files as $f){$x=json_decode((string)file_get_contents($f),true);if(is_array($x)&&!empty($x['acquired']))$acquired++;}
$r=rg_run();$t=absint($r['transport_tick_count']??0);$c=absint($r['phase_state']['selection']['prepare_business_index']??0);
rg_assert(count($files)===5,'exactly five synchronized full worker processes returned results');
rg_assert($acquired>=1 && $acquired<=5,'at least one and at most five full workers acquire canonical work');
rg_assert($t===$acquired,'durable transport count equals exactly full workers that acquired canonical work');
rg_assert($c===min(311,$acquired*8),'durable BUSINESS cursor equals monotone real 8-family batches after concurrent full-worker burst');
rg_assert(($r['phase']??'')==='selection_prepare','five-worker burst remains inside bounded selection_prepare');
rg_assert(($r['run_uuid']??'')==='v645-realdb-concurrent','full worker burst preserves immutable UUID');
rg_assert((string)($r['owner']??'')==='' && absint($r['lease_expires_at']??0)===0,'full workers durably release lease after progress accounting');
rg_assert(absint($r['no_progress_count']??0)===0,'concurrent/rejected full workers do not create false no-progress state');
echo "CONCURRENT_TICK_BURST_OK acquired=$acquired transport=$t cursor=$c\n";
