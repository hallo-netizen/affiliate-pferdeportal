<?php
require __DIR__.'/lib.php';
rg_settings_business_only();
// Initial selection_prepare hard bound: 39 BUSINESS batches + 2 guard margin = 41.
$r=rg_base_run('v645-realdb-limit-selection',41,41);$r['phase_tick_phase']='selection_prepare';$r['phase_tick_count']=41;rg_reset_run($r);rg_tick();$a=rg_run();
rg_assert(($a['status']??'')==='failed' && ($a['phase']??'')==='failed','selection_prepare exceeding hard budget fails closed in real DB');
rg_assert(($a['error_code']??'')==='selection_prepare_tick_limit_exceeded','selection_prepare hard-stop uses explicit failure code');
// Gap-fill reuses real selector: one missing BUSINESS concept => ceil(1/8)+2 = 3.
$r=rg_base_run('v645-realdb-limit-gapfill',3,3);$r['phase']='gapfill_select';$r['phase_tick_phase']='gapfill_select';$r['phase_tick_count']=3;$r['gapfill']=array('attempts'=>1,'missing'=>array('reitstiefel'));$r['phase_state']['selection']=array('status'=>'preparing','phase'=>'prepare','reason'=>'canonical_gapfill','selection_scope'=>'business','owner'=>'run:v645-realdb-limit-gapfill','business_target_concepts'=>array('reitstiefel'));rg_reset_run($r);rg_tick();$b=rg_run();
rg_assert(($b['status']??'')==='failed' && ($b['phase']??'')==='failed','gapfill_select prepare exceeding derived budget fails closed in real DB');
rg_assert(($b['error_code']??'')==='selection_prepare_tick_limit_exceeded','gapfill_select hard-stop shares explicit selection prepare failure code');
echo "NEGATIVE_LIMITS_OK\n";
