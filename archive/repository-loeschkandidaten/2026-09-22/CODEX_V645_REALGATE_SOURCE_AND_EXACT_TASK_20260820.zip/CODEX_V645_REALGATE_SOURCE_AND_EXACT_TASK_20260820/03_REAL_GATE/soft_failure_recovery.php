<?php
require __DIR__.'/lib.php';
rg_settings_business_only();
$uuid='v645-realdb-soft-recovery';
$sel=array('status'=>'failed','phase'=>'failed','failure_reason'=>'business_recovery_incomplete','stats'=>array('business'=>array('errors'=>array(array('item_id'=>'soft-1','code'=>'ebay_business_materialization_not_active')),'verification'=>array('expected'=>44,'materialized'=>43,'errors'=>1))));
$run=array('schema'=>'1.0','build'=>'6.44.0-business-materialization-gapfill-rootfix-20260820','run_uuid'=>$uuid,'status'=>'failed','phase'=>'failed','finished_at'=>1000,'owner'=>'','lease_expires_at'=>0,'worker_transport'=>'admin_ajax','progress_contract_version'=>'2.0','error_code'=>'business_recovery_incomplete','error_message'=>'business_recovery_incomplete','phase_state'=>array('maintenance'=>array('cursor'=>50),'refresh'=>array('last_id'=>2000),'selection'=>$sel),'coverage'=>array('covered'=>37),'gapfill'=>array('attempts'=>0,'missing'=>array()),'errors'=>array(array('code'=>'business_recovery_incomplete','at'=>1000,'details'=>array('phase'=>'business_materialize','build'=>'6.44.0-business-materialization-gapfill-rootfix-20260820'))),'start_manifest'=>array('x'=>1),'end_manifest'=>array('bad'=>1),'recovery_history'=>array());
rg_reset_run($run);update_option(Pferdeportal_Affiliate_Router::OPTION_EBAY_SELECTION_STATE,$sel,false);
$p=rg_plugin();$p->maybe_migrate_ebay_business_materialization_v6440();$a=rg_run();
rg_assert(($a['run_uuid']??'')===$uuid,'soft candidate failure recovery keeps exact failed-run UUID');
rg_assert(($a['status']??'')==='running' && ($a['phase']??'')==='selection_prepare','proven soft candidate failure reopens only at derived selection boundary');
rg_assert(($a['phase_state']['maintenance']??array())===array('cursor'=>50) && ($a['phase_state']['refresh']??array())===array('last_id'=>2000),'soft recovery preserves prior source/refresh progress');
rg_assert(($a['phase_state']['selection']??array())===array(),'soft recovery clears only derived selection tail');
rg_assert(get_option(Pferdeportal_Affiliate_Router::OPTION_EBAY_SELECTION_STATE,array())===array(),'legacy selection state is cleared only after successful real DB CAS');
$once=$a;$p->maybe_migrate_ebay_business_materialization_v6440();rg_assert(rg_run()===$once,'soft recovery migration is idempotent in real WordPress DB');
// Resume at least one real package from the recovered persisted state.
rg_tick();$b=rg_run();
rg_assert(($b['run_uuid']??'')===$uuid && absint($b['phase_state']['selection']['prepare_business_index']??0)===8,'recovered failed run resumes real selector with same UUID at first 8-family checkpoint');
echo "SOFT_RECOVERY_OK\n";
