<?php
function rg_fail($message) {
    fwrite(STDERR, "FAIL $message\n");
    exit(1);
}
function rg_pass($message) { echo "PASS $message\n"; }
function rg_assert($cond, $message) { if (!$cond) rg_fail($message); rg_pass($message); }
function rg_plugin() {
    if (!class_exists('Pferdeportal_Affiliate_Router')) rg_fail('plugin class not loaded');
    return Pferdeportal_Affiliate_Router::instance();
}
function rg_run() { $r=get_option(Pferdeportal_Affiliate_Router::OPTION_EBAY_RUN_STATE, array()); return is_array($r)?$r:array(); }
function rg_settings_business_only() {
    $p=rg_plugin();
    $s=$p->ebay_settings_defaults();
    $s['enabled']=1; $s['private_enabled']=0; $s['business_enabled']=1;
    $s['business_active_cap']=1000; $s['business_candidate_pool_per_concept']=10; $s['business_reserve_per_concept']=2; $s['business_max_same_seller_per_block']=1;
    update_option(Pferdeportal_Affiliate_Router::OPTION_NETWORK_EBAY,$s,false);
    return $s;
}
function rg_base_run($uuid,$transport=0,$progress=0) {
    return array(
        'schema'=>'1.0',
        'build'=>'6.44.0-business-materialization-gapfill-rootfix-20260820',
        'run_uuid'=>$uuid,
        'status'=>'running',
        'phase'=>'selection_prepare',
        'operation'=>'refresh',
        'started_at'=>time()-1000,
        'finished_at'=>0,
        'owner'=>'',
        'lease_expires_at'=>0,
        'worker_transport'=>'admin_ajax',
        'resume_reason'=>'',
        'no_progress_count'=>0,
        'progress_seq'=>$progress,
        'progress_contract_version'=>'2.0',
        'transport_tick_count'=>$transport,
        'last_transport_tick_at'=>time()-10,
        'config_snapshot'=>array(
            'seller_routes'=>array('private'=>0,'business'=>1),
            'settings'=>array(
                'enabled'=>1,'private_enabled'=>0,'business_enabled'=>1,
                'business_active_cap'=>1000,'business_candidate_pool_per_concept'=>10,
                'business_reserve_per_concept'=>2,'business_max_same_seller_per_block'=>1,
            ),
        ),
        'phase_state'=>array(),
        'coverage'=>array(),
        'gapfill'=>array('attempts'=>0,'missing'=>array()),
        'errors'=>array(),
    );
}
function rg_reset_run($run) {
    delete_option(Pferdeportal_Affiliate_Router::OPTION_EBAY_SELECTION_STATE);
    update_option(Pferdeportal_Affiliate_Router::OPTION_EBAY_SELECTION_STATE,array(),false);
    update_option(Pferdeportal_Affiliate_Router::OPTION_EBAY_RUN_STATE,$run,false);
    wp_cache_delete(Pferdeportal_Affiliate_Router::OPTION_EBAY_RUN_STATE,'options');
}
function rg_tick() { return rg_plugin()->run_ebay_admin_ajax_tick(); }
