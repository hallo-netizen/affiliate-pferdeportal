<?php
require __DIR__.'/lib.php';
$r0=rg_run();$uuid=(string)($r0['run_uuid']??'');$start=absint($r0['transport_tick_count']??0);$last=absint($r0['phase_state']['selection']['prepare_business_index']??0);$ticks=0;
while(($r=rg_run()) && ($r['phase']??'')==='selection_prepare' && $ticks<50){rg_tick();$ticks++;$a=rg_run();$c=absint($a['phase_state']['selection']['prepare_business_index']??0);rg_assert($c>=$last,'persisted BUSINESS cursor never regresses while resuming concurrent checkpoint');$last=$c;}
$f=rg_run();
rg_assert(($f['run_uuid']??'')===$uuid,'checkpoint resume preserves immutable UUID');
rg_assert(($f['phase']??'')==='business_select','persisted concurrent checkpoint terminates selection_prepare at business_select');
rg_assert(absint($f['phase_state']['selection']['prepare_business_index']??0)===311,'checkpoint resume reaches full 311-family cursor');
rg_assert(absint($f['no_progress_count']??0)===0,'checkpoint resume has no false no-progress accumulation');
rg_assert(absint($f['phase_tick_count']??0)<=absint($f['selection_prepare_tick_limit']??0),'checkpoint resume remains within derived termination budget');
echo 'CHECKPOINT_RESUME_OK start_transport='.$start.' added='.$ticks.' final_transport='.absint($f['transport_tick_count']??0)."\n";
