<?php
require __DIR__.'/lib.php';
rg_settings_business_only();
$uuid='v645-realdb-concurrent';
rg_reset_run(rg_base_run($uuid,0,0));
$r=rg_run();
rg_assert(($r['run_uuid']??'')===$uuid,'concurrent scenario persisted same seed UUID');
rg_assert(($r['phase']??'')==='selection_prepare','concurrent scenario starts in selection_prepare');
