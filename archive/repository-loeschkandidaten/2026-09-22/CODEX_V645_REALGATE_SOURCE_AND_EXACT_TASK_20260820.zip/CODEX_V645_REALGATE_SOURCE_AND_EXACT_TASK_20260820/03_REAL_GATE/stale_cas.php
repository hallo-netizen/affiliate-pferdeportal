<?php
require __DIR__.'/lib.php';
rg_settings_business_only();$uuid='v645-realdb-cas';$a=rg_base_run($uuid,0,0);rg_reset_run($a);
$p=rg_plugin();$ref=new ReflectionMethod($p,'ebay_run_compare_and_swap');$ref->setAccessible(true);
$stale=rg_run();$advanced=$stale;$advanced['transport_tick_count']=7;$advanced['progress_seq']=7;$advanced['phase_state']['selection']=array('prepare_business_initialized'=>1,'prepare_business_index'=>56);update_option(Pferdeportal_Affiliate_Router::OPTION_EBAY_RUN_STATE,$advanced,false);wp_cache_delete(Pferdeportal_Affiliate_Router::OPTION_EBAY_RUN_STATE,'options');
$candidate=$stale;$candidate['resume_reason']='stale-writer';$ret=$ref->invoke($p,$stale,$candidate);$after=rg_run();
rg_assert($ret===false,'real MariaDB compare-and-swap rejects stale whole-run snapshot');
rg_assert(absint($after['transport_tick_count']??0)===7 && absint($after['phase_state']['selection']['prepare_business_index']??0)===56,'stale CAS cannot roll back a concurrently advanced persistent cursor');
rg_assert(($after['run_uuid']??'')===$uuid,'stale CAS rejection preserves UUID');
echo "STALE_CAS_OK\n";
