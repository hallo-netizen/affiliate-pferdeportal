<?php
require __DIR__.'/lib.php';
$dir=getenv('RG_SHARED_DIR') ?: '/shared';
$files=glob($dir.'/result-*') ?: array();
$acquired=0;$rejected=0;
foreach($files as $f){$x=json_decode((string)file_get_contents($f),true);if(!is_array($x))continue;if(!empty($x['acquired']))$acquired++;else$rejected++;}
$r=rg_run();
rg_assert(count($files)===5,'exactly five synchronized independent PHP workers returned lease results');
rg_assert($acquired===1,'exactly one genuinely concurrent request acquires the real MariaDB-backed worker lease');
rg_assert($rejected===4,'the other four concurrent requests are rejected by the atomic lease');
rg_assert(absint($r['transport_tick_count']??0)===0,'lease acquisition alone does not mutate transport progress');
rg_assert(absint($r['phase_state']['selection']['prepare_business_index']??0)===0,'lease acquisition alone does not mutate selector cursor');
rg_assert(($r['run_uuid']??'')==='v645-realdb-concurrent','concurrent lease requests preserve immutable UUID');
rg_assert((string)($r['owner']??'')!=='' && absint($r['lease_expires_at']??0)>time(),'winning lease remains durably owned until explicit release');
$p=rg_plugin();$ref=new ReflectionMethod($p,'ebay_run_release_lease');$ref->setAccessible(true);$ref->invoke($p,(string)$r['owner']);$released=rg_run();
rg_assert((string)($released['owner']??'')==='' && absint($released['lease_expires_at']??0)===0,'real MariaDB-backed lease releases only for the winning token');
echo "CONCURRENT_LEASE_OK acquired=$acquired rejected=$rejected\n";
