<?php
require __DIR__.'/lib.php';
$dir=getenv('RG_SHARED_DIR') ?: '/shared';
$id=getenv('RG_WORKER_ID') ?: (string)getmypid();
@file_put_contents($dir.'/ready-'.$id,'1');
$deadline=microtime(true)+60;
while(!file_exists($dir.'/go')) { if(microtime(true)>$deadline){@file_put_contents($dir.'/result-'.$id,'TIMEOUT');exit(2);} usleep(10000); }
$before=rg_run();
$ret=rg_tick();
$after=rg_run();
$acquired=is_array($ret) ? 1 : 0;
$line=json_encode(array(
  'id'=>$id,'acquired'=>$acquired,
  'before_transport'=>absint($before['transport_tick_count']??0),
  'after_transport'=>absint($after['transport_tick_count']??0),
  'after_cursor'=>absint($after['phase_state']['selection']['prepare_business_index']??0),
  'phase'=>(string)($after['phase']??''),'uuid'=>(string)($after['run_uuid']??''),
),JSON_UNESCAPED_SLASHES);
@file_put_contents($dir.'/result-'.$id,$line);
echo $line."\n";
