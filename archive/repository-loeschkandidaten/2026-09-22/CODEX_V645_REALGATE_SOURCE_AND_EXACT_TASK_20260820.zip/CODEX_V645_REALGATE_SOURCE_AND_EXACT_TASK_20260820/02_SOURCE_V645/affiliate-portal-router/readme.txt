Affiliate-Zentrale 6.45.0 – CANONICAL RUN PERSISTENCE / RACE ROOTFIX
Stable tag: 6.45.0

Korrektur 6.45.0
- Kanonische Admin-AJAX-Ticks schreiben vor Lease-Erwerb keinen kompletten Run-Snapshot mehr zurück. Ein abgewiesener Parallelrequest verändert weder Cursor noch Paket-/Fortschrittszähler.
- Fortschrittsabrechnung bleibt bis einschließlich No-Progress-Entscheidung unter derselben persistenten Lease; erst danach wird die Lease freigegeben. Damit kann kein zweiter Worker zwischen Release und einem veralteten Post-Worker-Save vorlaufen und anschließend zurückgerollt werden.
- Zustandsmigrationen auf `init` verwenden Compare-and-Swap auf den exakt gelesenen Run-Snapshot. Eine verspätete V6.44-Soft-Recovery darf einen inzwischen weitergelaufenen `selection_prepare`-Cursor, eine fremde Lease oder Paket-/Fortschrittswerte nicht mehr überschreiben.
- Sekundäre Selection-Reset-Mutationen einer Migration erfolgen erst nach erfolgreichem CAS. Eine verlorene/stale Migration mutiert keinerlei Selection-Zustand.
- Der gemeinsam genutzte Selection-Prepare-Schritt besitzt zusätzlich monotone Cursor-Guards und eine aus Scope, realem 311er BUSINESS-Manifest, Batchgröße und persistiertem PRIVATE-Kandidatenbudget abgeleitete harte Terminierungsgrenze. Das gilt sowohl für den initialen `selection_prepare` als auch für den gezielten `gapfill_select`; ein bewegter Endlosloop kann den normalen No-Progress-Fingerprint nicht mehr umgehen.
- Reale Produktionsimplementierung geprüft: 311 BUSINESS-Familien bei 8er-Batches verlassen `selection_prepare` nach exakt 39 Worker-Paketen und wechseln zu `business_select`.
- Fachlogik unverändert: keine Änderung an Acceptance, BUSINESS-/PRIVATE-Klassifikation, Artikel-/Prompt-/Designlogik, HivePress-Ausgabe, Produktzuordnung, Coverage-Definition oder Gap-Fill-Scope.

Korrektur 6.44.0
- Ein kandidatenspezifischer BUSINESS-Materialisierungsfehler `ebay_business_materialization_not_active` beendet nicht mehr den gesamten 311-Familien-Lauf. Der Kandidat bleibt Review/Last-Known-Good und die kanonische Coverage/Gap-Fill-Phase entscheidet über die Familie.
- Verifizierte Storage-/Commit-/Source-Fehler bleiben unverändert terminal/fail-closed.
- Ein historischer `business_selection_commit_failed` wird nur dann als alter Soft-Fall erkannt, wenn die gespeicherte Quellzeile `review_last_good` plus `[ebay_business_materialization_not_active]` beweist.
- Canonical Gap-Fill plant und pruned ausschließlich die exakte fehlende Familienliste; bereits versorgte Familien werden dabei nicht angefasst.
- Upgrade-Recovery ist zustandsbasiert, idempotent und bewahrt Run-UUID sowie Source-/Refresh-Cursor. Unbekannte Fehler bleiben `failed`.
- Keine Änderung an Artikel-, Design-, Prompt-, HivePress-Frontend-, Acceptance-, Klassifikations- oder allgemeinen Materialisierungsverträgen.

Affiliate-Zentrale 6.43.0 – CANONICAL PARTIAL RESUME ROOTFIX

Korrektur 6.43.0
- PARTIAL ist im kanonischen Discovery-/Gap-Fill-Lauf kein Neustartsignal mehr.
- Fortsetzbare Checkpoints werden mit identischem Job-/Run-Cursor wieder aufgenommen.
- Nicht fortsetzbare PARTIAL-Zustaende fail-closed mit konkretem Fehlercode statt globalem Neustart.
- BUSINESS-Recovery darf denselben business_recovery-Checkpoint fortsetzen.
- Keine Aenderung an Artikel-, Design-, Prompt-, HivePress-Frontend- oder fachlicher Materialisierungslogik.


Anlass
V6.41.3 ist im Realtest mit `canonical_worker_no_progress` während `selection_prepare` fehlgeschlagen, obwohl die faire PRIVATE-Vorbereitung bereits echte per-Leaf-Cursor fortgeschrieben hatte.

Nachgewiesene Ursache
Der No-Progress-Fingerprint enthielt weiterhin den alten globalen PRIVATE-Offset, aber nicht die seit V6.41 verwendeten dauerhaften Fairness-Cursor `prepare_private_leaf_index`, `prepare_private_leaf_offsets` und `prepare_private_scanned`. Reale bounded Leaf-Pakete mit Scanfortschritt, aber 0 geeigneten Kandidaten wurden dadurch fälschlich als Stillstand gewertet. Der kanonische Coordinator hatte zusätzlich eine eigene unvollständige Selection-Fingerprint-Liste.

Korrektur 6.42.1
- Der Selection-Fingerprint enthält sämtliche dauerhaften Prepare-/Apply-Cursor, insbesondere die realen per-Leaf-PRIVATE-Cursor.
- Der kanonische Run verwendet exakt denselben vollständigen Selection-Fingerprint statt einer zweiten Teildefinition.
- Exakt der bekannte V6.41.3-Fail wird nur bei belegtem Fehler `canonical_worker_no_progress`, Fehlphase `selection_prepare`, offenem Selection-State und nachweisbarem per-Leaf-PRIVATE-Fortschritt state-only wieder aufgenommen. Andere Fehler bleiben terminal.
- Der Qualitätskorpus belegte zusätzlich eine zentrale Policy-Lücke für primäre Souvenir-Produkte. Content-Policy 6.4 ergänzt ausschließlich `souvenir`/`souvenirartikel`; dieselbe zentrale Policy gilt für PRIVATE, BUSINESS, Maintenance und Public-Gates.
- Weil sich damit der Policy-/Katalogvertrag ändert, darf ein unter V6.41.3 offener/fehlgeschlagener Run keinen alten Selection-Plan fortsetzen. Derselbe Run-UUID bleibt erhalten, Remote-/Source-Cursor und Seller-Snapshot bleiben erhalten, aber der Run geht einmalig state-only nach `reconcile_local`; nur abgeleitete Selection-/Coverage-/Gap-Fill-/Endmanifest-Daten werden verworfen und unter Policy 6.4 neu erzeugt.
- Die V6.42-Migration läuft vor älteren eBay-Transportmigrationen, damit der persistierte V6.41.3-Ursprungsstand vor dem ersten Save unter neuer Runtime-ID geprüft wird.

Bewusst unverändert
Acceptance, BUSINESS-/PRIVATE-Klassifikation, HivePress-Materialisierung, Kampagnen-/Outputlogik, Medien, Portalstruktur, Design/CSS/JS und Nachbar-Traits wurden nicht neu gebaut. Im Katalog wurde ausschließlich die belegte zentrale Souvenir-Policy ergänzt; sonstige Katalogfelder bleiben unverändert.

Transport – explizite Betriebsabweichung
Der Nutzer hat keinen Serverzugriff. Deshalb arbeitet der reale Hosting-Modus weiterhin über genau einen authentifizierten, sequenziellen Admin-AJAX-Taktgeber. Beim Schließen der Providerseite pausiert der persistente Run und setzt beim Wiederöffnen mit derselben UUID und denselben Cursorn fort. Kein Plugin-Self-HTTP und kein konkurrierender eBay-Worker. Damit ist die Browser-Unabhängigkeit aus Zielvertrag §3 ausdrücklich NICHT erfüllt und wird nicht als PASS bezeichnet.

Freigabe
Lokale/packaged Tests können nur den Code-/State-/Harness-Vertrag belegen. Produktionsfreigabe setzt zusätzlich einen realen WordPress/HivePress/eBay-Lauf voraus. Die fachliche 311er-Sollmenge wird aus dem verbindlichen vorhandenen Manifest übernommen; ihre externe semantische Einstufung als physische Produktfamilien wird durch diesen Build nicht neu behauptet.


Korrektur 6.42.1
- Persistente No-Progress-Recovery ist nicht mehr an einen globalen Einmal-Schalter gebunden.
- Nachweislich vom alten PRIVATE-Fingerprint betroffene 6.41.2/6.41.3-Runs werden pro Run/Fehlerereignis idempotent migriert.
- Bei Policy-/Katalogwechsel bleibt dieselbe Run-ID erhalten; nur abgeleitete Selection/Coverage-Zustaende werden neu aufgebaut.
- Neue Fehler speichern Build, Progress-Contract und fehlgeschlagene Phase direkt im Error-Eintrag.
