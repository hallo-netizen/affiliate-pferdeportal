<?php
// Hard local integration harness: raw Browse item -> acceptance -> strict classifier
// -> real eBay item upsert -> real creative library upsert -> real output planner
// -> real campaign materializer -> real public router. Business pipeline methods are NOT overridden.
define('ABSPATH','/tmp/ppar-wp/'); define('ARRAY_A','ARRAY_A'); define('OBJECT','OBJECT'); define('HOUR_IN_SECONDS',3600); define('MINUTE_IN_SECONDS',60); define('DAY_IN_SECONDS',86400);
@mkdir(ABSPATH.'wp-admin/includes',0777,true); if(!file_exists(ABSPATH.'wp-admin/includes/upgrade.php')) file_put_contents(ABSPATH.'wp-admin/includes/upgrade.php','<?php');
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}
class WP_Post{public $ID=0,$post_type='',$post_status='publish',$post_name='',$post_title='',$post_content='',$post_excerpt='',$post_parent=0,$menu_order=0;function __construct($a=[]){foreach($a as $k=>$v)$this->$k=$v;}}
class Pferde_Template_Kit{const AFFILIATE_CONTRACT='1.0';static function affiliate_contract_version(){return '1.0';}static function design_profile(){return 'pferde_atelier';}static function design_profile_contract_version(){return '1.0';}static function affiliate_page_type($id){return $GLOBALS['page_context'][$id]??'leaf';}}
function add_action(){return true;} function add_filter(){return true;} function add_shortcode(){return true;} function register_activation_hook(){return true;} function register_deactivation_hook(){return true;} function register_post_type(){return true;} function register_taxonomy(){return true;} function register_rest_route(){return true;}
function apply_filters($tag,$value,...$args){return $value;} function do_action(){return null;} function is_admin(){return false;} function wp_doing_ajax(){return false;} function is_multisite(){return false;} function get_sites(){return [];}
function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_title($v){$v=strtolower(strtr((string)$v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']));return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_textarea_field($v){return trim(strip_tags((string)$v));} function sanitize_html_class($v){return sanitize_key($v);}
function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return strtr((string)$v,['ä'=>'a','ö'=>'o','ü'=>'o','Ä'=>'A','Ö'=>'O','Ü'=>'U','ß'=>'ss']);}
function wp_json_encode($v,$o=0){return json_encode($v,$o);} function wp_parse_args($a,$d=[]){return array_merge($d,is_array($a)?$a:[]);} function maybe_serialize($v){return is_scalar($v)?$v:serialize($v);} function maybe_unserialize($v){$x=@unserialize($v);return $x===false&&$v!=='b:0;'?$v:$x;}
function esc_url_raw($v){return (string)$v;} function esc_url($v){return (string)$v;} function esc_attr($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function esc_html($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function wp_http_validate_url($v){return filter_var((string)$v,FILTER_VALIDATE_URL)!==false;} function wp_parse_url($u,$c=-1){return parse_url($u,$c);} function home_url($p='/'){return 'https://pferde-atelier.test'.$p;} function admin_url($p=''){return 'https://pferde-atelier.test/wp-admin/'.$p;} function get_bloginfo($k=''){return $k==='name'?'Pferde Atelier':'Pferde Atelier';} function get_current_blog_id(){return 1;} function get_home_url($id,$p='/'){return home_url($p);}
function current_time($t){return $t==='timestamp'?time():($t==='Y-m-d'?gmdate('Y-m-d'):time());} function wp_date($f,$ts=null){return date($f,$ts?:time());} function wp_generate_uuid4(){return '11111111-2222-4333-8444-555555555555';} function wp_generate_password(){return 'worker-token';}
function current_user_can(){return true;} function post_type_exists(){return true;} function taxonomy_exists($t){return false;} function get_terms(){return [];} function has_shortcode(){return false;} function get_ancestors(){return [];} function get_post_ancestors(){return [];} function get_the_terms(){return [];} function get_term(){return false;} function get_term_by(){return false;} function get_the_title($id){$p=get_post($id);return $p?$p->post_title:'';} function wp_next_scheduled(){return false;} function wp_schedule_event(){return true;} function wp_schedule_single_event(){return true;} function wp_clear_scheduled_hook(){return true;} function get_transient(){return false;} function set_transient(){return true;} function delete_transient(){return true;} function dbDelta(){return true;} function wp_remote_post(){return ['response'=>['code'=>200]];}
$GLOBALS['options']=[
 'ppar_enabled'=>'1','ppar_creative_library_schema_version'=>'3.0','ppar_output_schema_version'=>'1.3','ppar_control_schema_version'=>'1.1','ppar_ebay_schema_version'=>'2.0',
 'ppar_control_settings_v1'=>['emergency_stop'=>0], 'ppar_provider_access_state_v1'=>['ebay'=>['status'=>'connected','last_checked'=>time(),'message'=>'connected']], 'ppar_portal_registry_v1'=>[],
 'ppar_network_ebay_v1'=>['enabled'=>1,'environment'=>'production','client_id'=>'client','client_secret'=>'secret','epn_campaign_id'=>'1234567890','marketplace_id'=>'EBAY_DE','delivery_country'=>'DE','private_enabled'=>1,'business_enabled'=>1],
];
function get_option($k,$d=false){return array_key_exists($k,$GLOBALS['options'])?$GLOBALS['options'][$k]:$d;} function update_option($k,$v,$autoload=null){$GLOBALS['options'][$k]=$v;return true;} function delete_option($k){unset($GLOBALS['options'][$k]);return true;}
$GLOBALS['meta']=[];$GLOBALS['posts']=[];$GLOBALS['pages']=[];$GLOBALS['page_context']=[];$GLOBALS['next_post_id']=5000;
function get_post_meta($id,$k='',$single=true){if($k==='')return $GLOBALS['meta'][$id]??[];return $GLOBALS['meta'][$id][$k]??'';} function update_post_meta($id,$k,$v){$GLOBALS['meta'][$id][$k]=$v;return true;} function delete_post_meta($id,$k){unset($GLOBALS['meta'][$id][$k]);return true;}
function wp_insert_post($a,$err=false){$id=++$GLOBALS['next_post_id'];$a['ID']=$id;$a['post_name']=$a['post_name']??sanitize_title($a['post_title']??('post-'.$id));$GLOBALS['posts'][$id]=new WP_Post($a);return $id;} function wp_update_post($a,$err=false){$id=absint($a['ID']??0);if(!$id||!isset($GLOBALS['posts'][$id]))return $err?new WP_Error('post_missing','missing'):0;foreach($a as $k=>$v){if($k!=='ID')$GLOBALS['posts'][$id]->$k=$v;}return $id;} function get_post($id){return $GLOBALS['posts'][$id]??($GLOBALS['pages'][$id]??null);} function get_post_field($f,$id){$p=get_post($id);return $p&&isset($p->$f)?$p->$f:'';} function get_post_status($id){$p=get_post($id);return $p?$p->post_status:false;}
function get_pages($a=[]){return array_values($GLOBALS['pages']);}
function get_posts($a=[]){$pt=$a['post_type']??'';$out=[];if($pt==='ap_campaign'){foreach($GLOBALS['posts'] as $p){if($p->post_type!=='ap_campaign')continue;if(isset($a['meta_key'])){if((string)get_post_meta($p->ID,$a['meta_key'],true)!==(string)($a['meta_value']??''))continue;} $out[]=(($a['fields']??'')==='ids')?$p->ID:$p;} } return $out;}
class MemDB{
 public $prefix='wp_',$base_prefix='wp_',$posts='wp_posts',$insert_id=0; public $tables=[];
 function get_charset_collate(){return '';}
 function prepare($q,...$args){foreach($args as $a){$rep=is_numeric($a)&&!is_string($a)?(string)$a:"'".str_replace("'","''",(string)$a)."'";$q=preg_replace('/%[sdf]/',$rep,$q,1);}return $q;}
 private function table($q){return preg_match('/\bFROM\s+([A-Za-z0-9_]+)/i',$q,$m)?$m[1]:'';}
 private function val($q,$field){return preg_match('/\b'.preg_quote($field,'/').'\s*=\s*(?:\'([^\']*)\'|([0-9]+))/i',$q,$m)?($m[1]!==''?$m[1]:$m[2]):null;}
 private function matches($row,$q){foreach(['id','portal_key','item_id','identity_hash','object_key','creative_identity_hash','output_type','rule_id'] as $f){$v=$this->val($q,$f);if($v!==null&&(string)($row[$f]??'')!==(string)$v)return false;}if(stripos($q,"seller_account_type='BUSINESS'")!==false&&($row['seller_account_type']??'')!=='BUSINESS')return false; if(preg_match("/object_key\s*<>\s*'([^']+)'/i",$q,$m)&&(string)($row['object_key']??'')===(string)$m[1])return false; return true;}
 function get_row($q,$mode=null){$t=$this->table($q);$rows=$this->tables[$t]??[];$found=[];foreach($rows as $r){if($this->matches($r,$q))$found[]=$r;}if(stripos($q,'ORDER BY id DESC')!==false)usort($found,fn($a,$b)=>($b['id']??0)<=>($a['id']??0));return $found?array_values($found)[0]:null;}
 function get_results($q,$mode=null){$t=$this->table($q);$rows=[];$cursor=0;$limit=999999;if(preg_match('/\bid>(\d+)/i',$q,$m))$cursor=(int)$m[1];if(preg_match('/LIMIT\s+(\d+)/i',$q,$m))$limit=(int)$m[1];foreach($this->tables[$t]??[] as $r){if(!$this->matches($r,$q))continue;if((int)($r['id']??0)<=$cursor&&stripos($q,'id>')!==false)continue;$rows[]=$r;}if(stripos($q,'ORDER BY id ASC')!==false)usort($rows,fn($a,$b)=>(int)($a['id']??0)<=>(int)($b['id']??0));if(stripos($q,'ORDER BY last_seen DESC')!==false)usort($rows,fn($a,$b)=>((int)($b['last_seen']??0)<=>(int)($a['last_seen']??0)) ?: ((int)($b['id']??0)<=>(int)($a['id']??0)));elseif(stripos($q,'ORDER BY id DESC')!==false)usort($rows,fn($a,$b)=>(int)($b['id']??0)<=>(int)($a['id']??0));return array_slice($rows,0,$limit);}
 function get_var($q){if(preg_match('/COUNT\(/i',$q)){return count($this->get_results($q,ARRAY_A));}return null;}
 function insert($t,$d,$f=null){$id=++$this->insert_id;$d['id']=$d['id']??$id;$this->tables[$t][]=$d;$this->insert_id=$d['id'];return 1;}
 function update($t,$d,$w,$f=null,$wf=null){$n=0;foreach($this->tables[$t]??[] as $i=>$r){$ok=true;foreach($w as $k=>$v){if((string)($r[$k]??'')!==(string)$v){$ok=false;break;}}if($ok){$this->tables[$t][$i]=array_merge($r,$d);$n++;}}return $n;}
}
$GLOBALS['wpdb']=new MemDB;
$root=getenv('PPAR_TEST_PLUGIN_DIR')?:'/mnt/data/final624_extract/affiliate-portal-router'; require $root.'/pferdeportal-affiliate-router.php';
$r=Pferdeportal_Affiliate_Router::instance();$rc=new ReflectionClass($r);$fail=0;$assertions=0;function ck($ok,$m){global $fail,$assertions;$assertions++;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$fail++;}function inv($n,$a=[]){global $r,$rc;$m=$rc->getMethod($n);$m->setAccessible(true);return $m->invokeArgs($r,$a);}
$catalog=json_decode(file_get_contents($root.'/assets/ebay-portal-catalog-v2.json'),true);
$pid=100;foreach($catalog['product_targets'] as $target){$slug=sanitize_title($target['slug']??'');if($slug==='')continue;$p=new WP_Post(['ID'=>++$pid,'post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>$target['product_title']??$slug,'post_parent'=>0]);$GLOBALS['pages'][$p->ID]=$p;$GLOBALS['page_context'][$p->ID]='leaf';}
$settings=inv('ebay_normalize_settings',[array_merge(inv('ebay_settings_defaults'),[
 'enabled'=>1,'environment'=>'production','client_id'=>'c','client_secret'=>'s','epn_campaign_id'=>'1234567890','marketplace_id'=>'EBAY_DE','delivery_country'=>'DE','private_enabled'=>1,'business_enabled'=>1,
 'business_active_cap'=>1000,'business_candidate_pool_per_concept'=>10,'business_reserve_per_concept'=>2,'business_min_feedback_percentage'=>99.0,'business_min_feedback_score'=>100,
]),true]);
$profiles=inv('ebay_sync_profiles',[$settings]);
function profx($profiles,$cid){foreach($profiles as $k=>$p){if(($p['seller_type']??'')==='BUSINESS'&&($p['expected_business_concept_id']??'')===$cid)return $p;}return null;}
function rawsel($id,$title,$cat,$aspect,$seller,$pct,$score,$price){return ['itemId'=>$id,'seller'=>['sellerAccountType'=>'BUSINESS','username'=>$seller,'feedbackPercentage'=>$pct,'feedbackScore'=>$score],'listingMarketplaceId'=>'EBAY_DE','buyingOptions'=>['FIXED_PRICE'],'itemAffiliateWebUrl'=>'https://www.ebay.de/itm/'.$id.'?campid=1','itemWebUrl'=>'https://www.ebay.de/itm/'.$id,'image'=>['imageUrl'=>'https://i.ebayimg.com/images/g/'.$id.'/s-l1600.jpg'],'title'=>$title,'price'=>['value'=>(string)$price,'currency'=>'EUR'],'categories'=>[['categoryId'=>'1','categoryName'=>$cat]],'localizedAspects'=>[['name'=>'Produktart','value'=>$aspect]],'returnTerms'=>['returnsAccepted'=>true],'shippingOptions'=>[['shippingCost'=>['value'=>'0.00','currency'=>'EUR']]],'itemCreationDate'=>date('c',time()-86400*5),'itemEndDate'=>date('c',time()+86400*30)];}
$blocked=['concept-ausrustung-grundlagen'=>1,'concept-futterung-grundlagen'=>1,'concept-gesundheitsvorsorge-grundlagen'=>1,'concept-pferdehaltung-grundlagen'=>1,'concept-weidemanagement-grundlagen'=>1];
$concepts=[];foreach($catalog['business_concepts'] as $c){$cid=sanitize_key($c['id']??'');if(isset($blocked[$cid]))continue;$concepts[]=$c;if(count($concepts)>=11)break;}
$total_inserted=0;$concept_item_ids=[];
foreach($concepts as $ci=>$concept){$cid=sanitize_key($concept['id']);$p=profx($profiles,$cid);ck(is_array($p),"Profile exists $cid");if(!$p)continue;$count=$ci===0?12:6;for($j=0;$j<$count;$j++){
 $id='SEL-'.$ci.'-'.$j;$seller=($ci===0&&$j<3)?'same-seller':('seller-'.$ci.'-'.$j);$brand=['Ariat','Uvex','Kerbl','Waldhausen','Eskadron','Sprenger'][$j%6];$title=$brand.' Modell'.chr(65+$j).' '.$concept['title'].' Pferd';$raw=rawsel($id,$title,$concept['title'],$concept['title'],$seller,99.9-($j*0.01),5000-$j*100,80+$j*5);
 $it=inv('ebay_accept_item',[$raw,'BUSINESS',$settings]);if(is_wp_error($it)){echo "INSERT_ACCEPT_FAIL $cid $id ".$it->get_error_code()."\n";continue;}$cl=inv('ebay_business_classify_portal_item_strict',[$it,$p['rule']]);if(is_wp_error($cl)){echo "INSERT_CLASS_FAIL $cid $id ".$cl->get_error_code()."\n";continue;}$it['portal_classification']=$cl;$q=inv('ebay_business_quality_assess',[$it,$cl,$p['rule'],$settings,0]);if(is_wp_error($q)){echo "INSERT_Q_FAIL $cid $id ".$q->get_error_code()."\n";continue;}$it['business_quality']=$q;$it['business_selection']=['role'=>'candidate','rank'=>0];$row=inv('ebay_upsert_item',[$it,$p['rule'],'business_affiliate',0,$settings]);if(!is_wp_error($row)){$concept_item_ids[$cid][]=$id;$total_inserted++;}
}}
ck($total_inserted===72,'Synthetic BUSINESS pool inserts 72 valid candidates');
$plan=inv('ebay_business_selection_plan',[$settings]);ck(is_array($plan),'V6.20 pure BUSINESS planner returns plan without materializing');
ck(count($plan['active']??[])<=1000,'V6.20 pure planner honors the hard global safety ceiling');
ck(absint($plan['pool']??0)===70,'V6.20 planner enforces top-10 pool per concept');
$rows=$GLOBALS['wpdb']->tables['wp_ppar_ebay_items']??[];$conceptByItem=[];$sellerByItem=[];$titleByItem=[];
foreach($rows as $row){$sp=json_decode($row['source_payload']??'',true);$conceptByItem[(string)$row['item_id']]=sanitize_key($sp['portal_classification']['product_concept_id']??'');$sellerByItem[(string)$row['item_id']]=(string)($row['seller_username']??'');$titleByItem[(string)$row['item_id']]=(string)($row['title']??'');}
$byConcept=[];$sellerCounts=[];
foreach(($plan['active']??[]) as $item=>$rank){$cid=$conceptByItem[$item]??'';$byConcept[$cid]=($byConcept[$cid]??0)+1;$seller=$sellerByItem[$item]??'';$sellerCounts[$cid][$seller]=($sellerCounts[$cid][$seller]??0)+1;}
$perOk=true;foreach($byConcept as $cid=>$n2){if($n2>3)$perOk=false;}ck($perOk,'No concept has more than three visible winners');
$first=sanitize_key($concepts[0]['id']);ck(($byConcept[$first]??0)===3,'Reit/product concept fills three slots even when its top three candidates share one seller');
ck(count($plan['reserve']??[])>0,'Qualified non-visible candidates are retained as reserves');
// The planner must remain pure: no campaign was materialized and no source role changed yet.
ck(count(get_posts(['post_type'=>'ap_campaign']))===0,'Planning phase does not materialize campaigns');
$mutated=false;foreach($GLOBALS['wpdb']->tables['wp_ppar_ebay_items']??[] as $row){$sp=json_decode($row['source_payload']??'',true);if(($sp['business_selection']['role']??'candidate')!=='candidate'){$mutated=true;break;}}ck(!$mutated,'Planning phase does not mutate source selection roles');
ck(count($plan['active']??[])===33,'Eleven qualified concepts can each fill all three visible slots without the old 300-cap starvation');
// V6.28 NEGATIVE: one selected source loses its raw payload before BUSINESS recovery apply.
$brokenItem=array_key_first($plan['active']);
foreach($GLOBALS['wpdb']->tables['wp_ppar_ebay_items']??[] as $i=>$row){
 if((string)($row['item_id']??'')===(string)$brokenItem){
   $payload=json_decode((string)($row['source_payload']??''),true); if(!is_array($payload))$payload=[]; unset($payload['raw']);
   $GLOBALS['wpdb']->tables['wp_ppar_ebay_items'][$i]['source_payload']=wp_json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); break;
 }
}
$state=['status'=>'running','phase'=>'business','selection_scope'=>'business','business_cursor'=>0,'business_active'=>$plan['active'],'business_reserve'=>$plan['reserve'],'stats'=>['business'=>['scanned'=>0,'active'=>0,'reserve'=>0,'candidate'=>0,'deactivated'=>0,'materialized'=>0,'errors'=>[]]]];
$apply=$rc->getMethod('ebay_selection_apply_business_batch');$apply->setAccessible(true);$ticks=0;
while(($state['phase']??'business')==='business'&&$ticks<20){$args=[$settings,&$state,15];$apply->invokeArgs($r,$args);$ticks++;}
ck(($state['status']??'')==='failed','BUSINESS recovery fails hard when any selected source cannot be materialized');
ck(($state['phase']??'')==='failed','BUSINESS recovery enters failed phase, never complete');
ck(($state['failure_reason']??'')==='business_recovery_incomplete','BUSINESS recovery records explicit incomplete verification reason');
$ver=$state['stats']['business']['verification']??[];
ck(absint($ver['expected']??0)===33,'Verification knows all 33 planned active BUSINESS products');
ck(absint($ver['materialized']??0)===32,'Verification detects exactly one missing materialization');
ck(absint($ver['errors']??0)>=1,'Verification records materialization error count');
ck(count(get_posts(['post_type'=>'ap_campaign']))===32,'Only 32 campaigns materialize after one deliberate source corruption');
echo "ASSERTIONS=$assertions FAIL=$fail STATUS=".($state['status']??'')." MATERIALIZED=".absint($ver['materialized']??0)." EXPECTED=".absint($ver['expected']??0)."\n";exit($fail?1:0);
