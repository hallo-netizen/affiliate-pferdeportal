<?php
// Hard local integration harness: raw Browse item -> acceptance -> strict classifier
// -> real eBay item upsert -> real creative library upsert -> real output planner
// -> real campaign materializer -> real public router. Business pipeline methods are NOT overridden.
define('ABSPATH','/tmp/ppar-wp/'); define('ARRAY_A','ARRAY_A'); define('OBJECT','OBJECT'); define('HOUR_IN_SECONDS',3600); define('MINUTE_IN_SECONDS',60); define('DAY_IN_SECONDS',86400);
@mkdir(ABSPATH.'wp-admin/includes',0777,true); if(!file_exists(ABSPATH.'wp-admin/includes/upgrade.php')) file_put_contents(ABSPATH.'wp-admin/includes/upgrade.php','<?php');
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}
class WP_Post{public $ID=0,$post_type='',$post_status='publish',$post_name='',$post_title='',$post_content='',$post_excerpt='',$post_parent=0,$menu_order=0;function __construct($a=[]){foreach($a as $k=>$v)$this->$k=$v;}}
class Pferde_Template_Kit{const AFFILIATE_CONTRACT='1.0';static function affiliate_contract_version(){return '1.0';}static function design_profile(){return 'pferde_atelier';}static function design_profile_contract_version(){return '1.0';}static function affiliate_page_type($id){return $GLOBALS['page_context'][$id]??'leaf';}}
function add_action(){return true;} function add_filter(){return true;} function add_shortcode(){return true;} function register_activation_hook(){return true;} function register_deactivation_hook(){return true;} function register_post_type(){return true;} function register_taxonomy(){return true;} function register_rest_route(){return true;}
function apply_filters($tag,$value,...$args){return $value;} function do_action(){return null;} function is_admin(){return false;} function wp_doing_ajax(){return false;} function is_multisite(){return false;} function get_sites(){return [];}
function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_title($v){$v=strtolower(strtr((string)$v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']));return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_textarea_field($v){return trim(strip_tags((string)$v));} function sanitize_html_class($v){return sanitize_key($v);}
function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return strtr((string)$v,['ä'=>'a','ö'=>'o','ü'=>'o','Ä'=>'A','Ö'=>'O','Ü'=>'U','ß'=>'ss']);}
function wp_json_encode($v,$o=0){return json_encode($v,$o);} function wp_parse_args($a,$d=[]){return array_merge($d,is_array($a)?$a:[]);} function maybe_serialize($v){return is_scalar($v)?$v:serialize($v);} function maybe_unserialize($v){$x=@unserialize($v);return $x===false&&$v!=='b:0;'?$v:$x;}
function esc_url_raw($v){return (string)$v;} function esc_url($v){return (string)$v;} function esc_attr($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function esc_html($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function wp_http_validate_url($v){return filter_var((string)$v,FILTER_VALIDATE_URL)!==false;} function wp_parse_url($u,$c=-1){return parse_url($u,$c);} function home_url($p='/'){return 'https://pferde-atelier.test'.$p;} function admin_url($p=''){return 'https://pferde-atelier.test/wp-admin/'.$p;} function get_bloginfo($k=''){return $k==='name'?'Pferde Atelier':'Pferde Atelier';} function get_current_blog_id(){return 1;} function get_home_url($id,$p='/'){return home_url($p);}
function current_time($t){return $t==='timestamp'?time():($t==='Y-m-d'?gmdate('Y-m-d'):time());} function wp_date($f,$ts=null){return date($f,$ts?:time());} function wp_generate_uuid4(){return '11111111-2222-4333-8444-555555555555';} function wp_generate_password(){return 'worker-token';}
function current_user_can(){return true;} function post_type_exists(){return true;} function taxonomy_exists($t){return false;} function get_terms(){return [];} function has_shortcode(){return false;} function get_ancestors(){return [];} function get_post_ancestors(){return [];} function get_the_terms(){return [];} function get_term(){return false;} function get_term_by(){return false;} function get_the_title($id){$p=get_post($id);return $p?$p->post_title:'';} function wp_next_scheduled(){return false;} function wp_schedule_event(){return true;} function wp_schedule_single_event(){return true;} function wp_clear_scheduled_hook(){return true;} function get_transient(){return false;} function set_transient(){return true;} function delete_transient(){return true;} function dbDelta(){return true;} function wp_remote_post(){return ['response'=>['code'=>200]];}
$GLOBALS['options']=[
 'ppar_enabled'=>'1','ppar_creative_library_schema_version'=>'3.0','ppar_output_schema_version'=>'1.3','ppar_control_schema_version'=>'1.1','ppar_ebay_schema_version'=>'2.0',
 'ppar_control_settings_v1'=>['emergency_stop'=>0], 'ppar_provider_access_state_v1'=>['ebay'=>['status'=>'connected','last_checked'=>time(),'message'=>'connected']], 'ppar_portal_registry_v1'=>[],
 'ppar_network_ebay_v1'=>['enabled'=>1,'environment'=>'production','client_id'=>'client','client_secret'=>'secret','epn_campaign_id'=>'1234567890','marketplace_id'=>'EBAY_DE','delivery_country'=>'DE','private_enabled'=>1,'business_enabled'=>1],
];
function get_option($k,$d=false){return array_key_exists($k,$GLOBALS['options'])?$GLOBALS['options'][$k]:$d;} function update_option($k,$v,$autoload=null){$GLOBALS['options'][$k]=$v;return true;} function delete_option($k){unset($GLOBALS['options'][$k]);return true;}
$GLOBALS['meta']=[];$GLOBALS['posts']=[];$GLOBALS['pages']=[];$GLOBALS['page_context']=[];$GLOBALS['next_post_id']=5000;
function get_post_meta($id,$k='',$single=true){if($k==='')return $GLOBALS['meta'][$id]??[];return $GLOBALS['meta'][$id][$k]??'';} function update_post_meta($id,$k,$v){$GLOBALS['meta'][$id][$k]=$v;return true;} function delete_post_meta($id,$k){unset($GLOBALS['meta'][$id][$k]);return true;}
function wp_insert_post($a,$err=false){$id=++$GLOBALS['next_post_id'];$a['ID']=$id;$a['post_name']=$a['post_name']??sanitize_title($a['post_title']??('post-'.$id));$GLOBALS['posts'][$id]=new WP_Post($a);return $id;} function wp_update_post($a,$err=false){$id=absint($a['ID']??0);if(!$id||!isset($GLOBALS['posts'][$id]))return $err?new WP_Error('post_missing','missing'):0;foreach($a as $k=>$v){if($k!=='ID')$GLOBALS['posts'][$id]->$k=$v;}return $id;} function get_post($id){return $GLOBALS['posts'][$id]??($GLOBALS['pages'][$id]??null);} function get_post_field($f,$id){$p=get_post($id);return $p&&isset($p->$f)?$p->$f:'';} function get_post_status($id){$p=get_post($id);return $p?$p->post_status:false;}
function get_pages($a=[]){return array_values($GLOBALS['pages']);}
function get_posts($a=[]){$pt=$a['post_type']??'';$out=[];if($pt==='ap_campaign'){foreach($GLOBALS['posts'] as $p){if($p->post_type!=='ap_campaign')continue;if(isset($a['meta_key'])){if((string)get_post_meta($p->ID,$a['meta_key'],true)!==(string)($a['meta_value']??''))continue;} $out[]=(($a['fields']??'')==='ids')?$p->ID:$p;} } return $out;}
class MemDB{
 public $prefix='wp_',$base_prefix='wp_',$posts='wp_posts',$insert_id=0; public $tables=[];
 function get_charset_collate(){return '';}
 function prepare($q,...$args){foreach($args as $a){$rep=is_numeric($a)&&!is_string($a)?(string)$a:"'".str_replace("'","''",(string)$a)."'";$q=preg_replace('/%[sdf]/',$rep,$q,1);}return $q;}
 private function table($q){return preg_match('/\bFROM\s+([A-Za-z0-9_]+)/i',$q,$m)?$m[1]:'';}
 private function val($q,$field){return preg_match('/\b'.preg_quote($field,'/').'\s*=\s*(?:\'([^\']*)\'|([0-9]+))/i',$q,$m)?($m[1]!==''?$m[1]:$m[2]):null;}
 private function matches($row,$q){foreach(['id','portal_key','item_id','identity_hash','object_key','creative_identity_hash','output_type','rule_id'] as $f){$v=$this->val($q,$f);if($v!==null&&(string)($row[$f]??'')!==(string)$v)return false;}if(stripos($q,"seller_account_type='BUSINESS'")!==false&&($row['seller_account_type']??'')!=='BUSINESS')return false; if(preg_match("/object_key\s*<>\s*'([^']+)'/i",$q,$m)&&(string)($row['object_key']??'')===(string)$m[1])return false; return true;}
 function get_row($q,$mode=null){$t=$this->table($q);$rows=$this->tables[$t]??[];$found=[];foreach($rows as $r){if($this->matches($r,$q))$found[]=$r;}if(stripos($q,'ORDER BY id DESC')!==false)usort($found,fn($a,$b)=>($b['id']??0)<=>($a['id']??0));return $found?array_values($found)[0]:null;}
 function get_results($q,$mode=null){$t=$this->table($q);$rows=[];foreach($this->tables[$t]??[] as $r){if($this->matches($r,$q))$rows[]=$r;}return $rows;}
 function get_var($q){if(preg_match('/COUNT\(/i',$q)){return count($this->get_results($q,ARRAY_A));}return null;}
 function insert($t,$d,$f=null){$id=++$this->insert_id;$d['id']=$d['id']??$id;$this->tables[$t][]=$d;$this->insert_id=$d['id'];return 1;}
 function update($t,$d,$w,$f=null,$wf=null){$n=0;foreach($this->tables[$t]??[] as $i=>$r){$ok=true;foreach($w as $k=>$v){if((string)($r[$k]??'')!==(string)$v){$ok=false;break;}}if($ok){$this->tables[$t][$i]=array_merge($r,$d);$n++;}}return $n;}
}
$GLOBALS['wpdb']=new MemDB;
$root=getenv('PPAR_TEST_PLUGIN_DIR')?:'/mnt/data/final624_extract/affiliate-portal-router'; require $root.'/pferdeportal-affiliate-router.php';
$r=Pferdeportal_Affiliate_Router::instance();$rc=new ReflectionClass($r);$fail=0;$assertions=0;function ck($ok,$m){global $fail,$assertions;$assertions++;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$fail++;}function inv($n,$a=[]){global $r,$rc;$m=$rc->getMethod($n);$m->setAccessible(true);return $m->invokeArgs($r,$a);}

$fail=0;$assertions=0;
function ck2($ok,$m){global $fail,$assertions;$assertions++;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$fail++;}
function inv2($n,$a=[]){global $r,$rc;$m=$rc->getMethod($n);$m->setAccessible(true);return $m->invokeArgs($r,$a);}
$defaults=inv2('ebay_settings_defaults');
$settings=inv2('ebay_normalize_settings',[array_merge($defaults,['private_active_cap'=>250,'private_leaf_cap'=>30]),true]);
ck2(($settings['private_active_cap']??0)===250,'Default/configured PRIVATE global active cap is 250');
ck2(($settings['private_leaf_cap']??0)===30,'Default/configured PRIVATE per-leaf active cap is 30');
$rows=[];$id=0;
// 40 leaf categories x 40 candidates = 1600 eligible rows. Scores are descending
// within each leaf so the pure planner must keep the strongest/freshest candidates.
for($leaf=1;$leaf<=40;$leaf++){
  for($j=0;$j<40;$j++){
    $id++;
    $score=100-$j;
    $rows[]=[
      'id'=>$id,'item_id'=>'P-'.$leaf.'-'.$j,'target_term_id'=>$leaf,
      'image_url'=>($j%3===0?'https://i.ebayimg.com/'.$id.'.jpg':''),
      'last_seen'=>time()-$j,
      'source_payload'=>json_encode(['portal_classification'=>['score'=>$score,'private_bucket_slug'=>'leaf-'.$leaf]])
    ];
  }
}
// Invalid/no-leaf rows must never consume capacity.
for($j=0;$j<20;$j++){$id++;$rows[]=['id'=>$id,'item_id'=>'INVALID-'.$j,'target_term_id'=>0,'image_url'=>'x','last_seen'=>time(),'source_payload'=>json_encode(['portal_classification'=>['score'=>100]])];}
$selected=inv2('ebay_private_select_rows_for_capacity',[$rows,$settings]);
ck2(count($selected)===250,'PRIVATE planner selects exactly 250 active rows when enough eligible inventory exists');
$per=[];$invalid=false;
foreach($selected as $row){$leaf=absint($row['target_term_id']??0);if($leaf<=0)$invalid=true;$per[$leaf]=($per[$leaf]??0)+1;}
$max=$per?max($per):0;
ck2($max<=30,'With many populated leaves, fair first-pass target remains at most 30 before refill is needed');
ck2(!$invalid,'Rows without a valid leaf target are never selected');
ck2(count($per)===40,'Fair round-robin retains representation across all 40 eligible leaves');
$min=$per?min($per):0;$max2=$per?max($per):0;
ck2(($max2-$min)<=1,'Global cap is distributed fairly across leaves before deeper ranks are filled');
// V6.26+ two-leaf stress: 30 is a fair first-pass target, not a starvation ceiling; qualified surplus fills the global cap.
$small=[];$k=0;for($leaf=1;$leaf<=2;$leaf++){for($j=0;$j<100;$j++){$k++;$small[]=['id'=>$k,'item_id'=>'S-'.$leaf.'-'.$j,'target_term_id'=>$leaf,'image_url'=>'https://i.ebayimg.com/'.$k.'.jpg','last_seen'=>time()-$j,'source_payload'=>json_encode(['portal_classification'=>['score'=>100-$j]])];}}
$smallSel=inv2('ebay_private_select_rows_for_capacity',[$small,$settings]);
$sp=[];foreach($smallSel as $row){$leaf=absint($row['target_term_id']);$sp[$leaf]=($sp[$leaf]??0)+1;}
ck2(count($smallSel)===200,'With only 200 qualified rows across two leaves, planner keeps all 200 instead of starving at 60');
ck2(($sp[1]??0)===100 && ($sp[2]??0)===100,'Two equally populated leaves remain fair while qualified surplus refills beyond the 30 first-pass target');

// V6.28 asymmetric product-pool stress: a large helmet/hose pool must not starve a small but valid Reitstiefel pool.
$mix=[];$mid=0;
foreach([['concept-reithelme',100],['private-hit-reithose',100],['concept-reitstiefel',3],['concept-reithandschuhe',12],['private-hit-reitweste',8]] as [$concept,$count]){
  for($j=0;$j<$count;$j++){$mid++;$mix[]=['id'=>$mid,'item_id'=>'M-'.$concept.'-'.$j,'target_term_id'=>7,'image_url'=>'https://i.ebayimg.com/'.$mid.'.jpg','last_seen'=>time()-$j,'source_payload'=>json_encode(['portal_classification'=>['score'=>100-$j,'private_product_concept_id'=>$concept,'hits'=>[$concept]]])];}
}
$mixSel=inv2('ebay_private_select_rows_for_capacity',[$mix,$settings]);
$mc=[];foreach($mixSel as $row){$payload=json_decode($row['source_payload'],true);$c=$payload['portal_classification']['private_product_concept_id']??'';$mc[$c]=($mc[$c]??0)+1;}
ck2(($mc['concept-reitstiefel']??0)===3,'Asymmetric pool keeps all three valid Reitstiefel before deeper helmet/hose ranks');
ck2(($mc['concept-reithelme']??0)>=3 && ($mc['private-hit-reithose']??0)>=3,'Large pools still receive multiple places after breadth rounds');

$main=file_get_contents($root.'/pferdeportal-affiliate-router.php');
$ebay=file_get_contents($root.'/includes/trait-ppar-ebay.php');
ck2(strpos($ebay,"_ppar_ebay_private_public_limit', 9")!==false && strpos($ebay,'ebay_private_parent_refill_posts($safe, $query, $parent_id, $now, 9)')!==false,'Existing PRIVATE parent max-9 contract remains present');
echo "ASSERTIONS=$assertions FAIL=$fail SELECTED=".count($selected)." MAX_LEAF=$max\n";
exit($fail?1:0);
