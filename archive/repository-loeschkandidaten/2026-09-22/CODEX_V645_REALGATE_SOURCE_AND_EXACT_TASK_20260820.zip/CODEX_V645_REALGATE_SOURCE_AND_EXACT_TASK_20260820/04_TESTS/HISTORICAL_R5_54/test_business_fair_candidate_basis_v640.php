<?php
define('ABSPATH','/tmp/ppar-wp/'); define('ARRAY_A','ARRAY_A'); define('HOUR_IN_SECONDS',3600); define('MINUTE_IN_SECONDS',60); define('DAY_IN_SECONDS',86400);
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;} function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));} function sanitize_text_field($v){return trim(strip_tags((string)$v));}
function wp_json_encode($v,$o=0){return json_encode($v,$o);} function get_option($k,$d=false){return $d;} function update_option(){return true;} function wp_parse_args($a,$d=[]){return array_merge($d,is_array($a)?$a:[]);} function esc_url_raw($v){return (string)$v;} function wp_http_validate_url($v){return true;} function wp_parse_url($u,$c=-1){return parse_url($u,$c);} function remove_accents($v){return (string)$v;} function wp_strip_all_tags($v){return strip_tags((string)$v);} function sanitize_title($v){return sanitize_key(str_replace(' ','-',strtolower((string)$v)));} function current_time($t){return time();} function wp_date($f,$ts=null){return date($f,$ts?:time());}
class FairDB{
 public $queries=[],$tables=[];
 function prepare($q,...$args){foreach($args as $a){$rep=is_numeric($a)&&!is_string($a)?(string)$a:"'".str_replace("'","''",(string)$a)."'";$q=preg_replace('/%[sdf]/',$rep,$q,1);}return $q;}
 function get_results($q,$mode=null){$this->queries[]=$q;$rows=$this->tables['wp_ppar_ebay_items']??[];$out=[];$rule=null;if(preg_match("/rule_id='([^']+)'/i",$q,$m))$rule=$m[1];foreach($rows as $r){if(($r['seller_account_type']??'')!=='BUSINESS')continue;if(($r['source_state']??'')!=='available'||($r['policy_state']??'')!=='allowed'||!in_array(($r['route_state']??''),['ready','review_last_good'],true))continue;if($rule!==null&&(string)($r['rule_id']??'')!==$rule)continue;$out[]=$r;}usort($out,fn($a,$b)=>((int)($b['last_seen']??0)<=> (int)($a['last_seen']??0)) ?: ((int)($b['id']??0)<=> (int)($a['id']??0)));$limit=PHP_INT_MAX;if(preg_match('/LIMIT\s+(\d+)/i',$q,$m))$limit=(int)$m[1];return array_slice($out,0,$limit);}
}
$root=getenv('PPAR_TEST_PLUGIN_DIR'); if(!$root){fwrite(STDERR,"PPAR_TEST_PLUGIN_DIR missing\n");exit(2);} require $root.'/includes/trait-ppar-ebay.php';
class FairHarness{
 use PPAR_Ebay_Trait;
 const OPTION_EBAY_CURATION='cur', EBAY_CONTENT_POLICY_VERSION='6.2', EBAY_PRIVATE_CLASSIFIER_VERSION='4.0', EBAY_BUSINESS_CLASSIFIER_VERSION='6.1';
 private function ebay_items_table(){return 'wp_ppar_ebay_items';}
 private function ebay_normalize_settings($s,$strict=false){return is_array($s)?$s:[];}
 private function ebay_business_source_row_item($row,$settings){return ['item_id'=>(string)$row['item_id'],'seller_username'=>(string)$row['seller_username'],'title'=>(string)$row['title'],'price_value'=>(string)$row['price_value'],'portal_classification'=>['product_concept_id'=>(string)$row['rule_id']]];}
 private function ebay_rule_by_id($id,$settings=null){return ['id'=>$id];}
 private function ebay_business_quality_assess($item,$classification,$rule,$settings,$median=0.0){return ['score'=>100,'reason'=>'test'];}
 private function ebay_business_candidate_sort(&$candidates){usort($candidates,fn($a,$b)=>((int)($b['row']['last_seen']??0)<=> (int)($a['row']['last_seen']??0)));}
 private function ebay_topic_text($v){return strtolower(trim((string)$v));}
 private function ebay_business_required_product_concept_ids(){return ['concept-common','concept-rare'];}
 public function plan($settings){return $this->ebay_business_selection_plan($settings);}
}
$GLOBALS['wpdb']=new FairDB();$id=0;$now=time();
for($i=0;$i<5000;$i++){$GLOBALS['wpdb']->tables['wp_ppar_ebay_items'][]=['id'=>++$id,'item_id'=>'COMMON-'.$i,'seller_account_type'=>'BUSINESS','seller_username'=>'seller-'.$i,'rule_id'=>'concept-common','source_state'=>'available','policy_state'=>'allowed','route_state'=>'ready','output_state'=>'candidate','last_seen'=>$now-$i,'item_end_at'=>$now+86400,'title'=>md5('COMMON-'.$i),'price_value'=>'100'];}
for($i=0;$i<3;$i++){$GLOBALS['wpdb']->tables['wp_ppar_ebay_items'][]=['id'=>++$id,'item_id'=>'RARE-'.$i,'seller_account_type'=>'BUSINESS','seller_username'=>'rare-'.$i,'rule_id'=>'concept-rare','source_state'=>'available','policy_state'=>'allowed','route_state'=>'ready','output_state'=>'candidate','last_seen'=>$now-10000-$i,'item_end_at'=>$now+86400,'title'=>md5('RARE-'.$i),'price_value'=>'90'];}
$h=new FairHarness();$settings=['business_candidate_pool_per_concept'=>10,'business_reserve_per_concept'=>2,'business_max_same_seller_per_block'=>1,'business_active_cap'=>1000];$plan=$h->plan($settings);
$fail=0;$n=0;function ck($x,$m){global $fail,$n;$n++;echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$fail++;}
$active=array_keys((array)($plan['active']??[]));$rare=count(array_filter($active,fn($id)=>str_starts_with($id,'RARE-')));$common=count(array_filter($active,fn($id)=>str_starts_with($id,'COMMON-')));
ck($common===3,'Common high-volume concept remains capped at three visible winners');
ck($rare===3,'Rare product concept older than the global 5,000 newest rows still receives three winners');
ck(count($active)===6,'Fair candidate basis supplies both product identities instead of source-recency starvation');
$targeted=0;foreach($GLOBALS['wpdb']->queries as $q){if(stripos($q,"rule_id='concept-rare'")!==false)$targeted++;}
ck($targeted>=1,'Planner performs bounded product-identity recovery when a required concept is absent from the global recent window');
echo "ASSERTIONS=$n FAIL=$fail ACTIVE=".count($active)." RARE=$rare QUERIES=".count($GLOBALS['wpdb']->queries)." TARGETED=$targeted\n";exit($fail?1:0);
