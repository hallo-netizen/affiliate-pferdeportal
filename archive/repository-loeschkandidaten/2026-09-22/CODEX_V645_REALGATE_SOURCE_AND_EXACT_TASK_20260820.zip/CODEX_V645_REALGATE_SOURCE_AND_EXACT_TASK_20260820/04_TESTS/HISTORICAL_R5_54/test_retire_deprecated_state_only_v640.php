<?php
if (!defined('ABSPATH')) { define('ABSPATH', __DIR__ . '/'); }
$GLOBALS['opts'] = array();
$GLOBALS['cleared_hooks'] = array();
$GLOBALS['deleted_transients'] = array();
$GLOBALS['inventory_sentinel'] = array(
    'private_posts' => array(101,102,103),
    'business_campaigns' => array(201,202),
    'source_rows' => array('A','B','C'),
    'native_hivepress' => array(901,902),
);
function get_option($k,$d=false){ return array_key_exists($k,$GLOBALS['opts']) ? $GLOBALS['opts'][$k] : $d; }
function update_option($k,$v,$autoload=null){ $GLOBALS['opts'][$k]=$v; return true; }
function sanitize_key($v){ $v=strtolower((string)$v); return preg_replace('/[^a-z0-9_\-]/','',$v); }
function wp_clear_scheduled_hook($hook){ $GLOBALS['cleared_hooks'][]=$hook; return 1; }
function delete_transient($k){ $GLOBALS['deleted_transients'][]=$k; return true; }

$root=getenv('PPAR_TEST_PLUGIN_DIR');
require $root.'/includes/trait-ppar-ebay.php';
class RetireHarness {
    use PPAR_Ebay_Trait;
    const EBAY_RUNTIME_BUILD='6.40.0-controlled-orchestrator-rebuild-unreleased-20260812';
    const OPTION_EBAY_SELECTION_STATE='ppar_ebay_selection_state_v2';
    const OPTION_EBAY_SYNC_JOB='ppar_ebay_sync_job_v2';
    const OPTION_EBAY_REFRESH_JOB='ppar_ebay_refresh_job_v1';
    const EBAY_WORKER_HOOK='ppar_ebay_sync_worker';
}
$fail=0;$n=0;
function ck($ok,$msg){global$fail,$n;$n++;echo($ok?'PASS ':'FAIL ').$msg."\n";if(!$ok)$fail++;}
function reset_env(){
    $GLOBALS['opts']=array();$GLOBALS['cleared_hooks']=array();$GLOBALS['deleted_transients']=array();
}
$h=new RetireHarness();
$marker='ppar_ebay_controlled_rebuild_transport_retired_20260812';

// POSITIVE: stale failed-V6.40 lifecycle states are retired without inventory work.
reset_env();
$before_inventory=$GLOBALS['inventory_sentinel'];
$GLOBALS['opts'][RetireHarness::OPTION_EBAY_SELECTION_STATE]=array('status'=>'running','phase'=>'private','build'=>'old-v640');
$GLOBALS['opts'][RetireHarness::OPTION_EBAY_SYNC_JOB]=array('status'=>'queued','schema'=>'2.0','engine'=>'resumable-background','build'=>'old-v640');
$GLOBALS['opts'][RetireHarness::OPTION_EBAY_REFRESH_JOB]=array('status'=>'running','schema'=>'1.0','engine'=>'targeted-getitem-refresh','build'=>'old-v640');
$GLOBALS['opts']['ppar_ebay_business_local_recovery_state_v1']=array('status'=>'running','phase'=>'reclassify','build'=>'old-v640');
$h->maybe_retire_deprecated_ebay_recovery_transports();
ck(($GLOBALS['opts'][RetireHarness::OPTION_EBAY_SELECTION_STATE]['status']??'')==='failed' && ($GLOBALS['opts'][RetireHarness::OPTION_EBAY_SELECTION_STATE]['phase']??'')==='retired','stale open selection is retired');
ck(($GLOBALS['opts'][RetireHarness::OPTION_EBAY_SYNC_JOB]['status']??'')==='failed' && ($GLOBALS['opts'][RetireHarness::OPTION_EBAY_SYNC_JOB]['failure_reason']??'')==='failed_v640_runtime_retired','stale queued discovery job is retired using raw status, not compatibility-aware is_open');
ck(($GLOBALS['opts'][RetireHarness::OPTION_EBAY_REFRESH_JOB]['status']??'')==='failed' && ($GLOBALS['opts'][RetireHarness::OPTION_EBAY_REFRESH_JOB]['failure_reason']??'')==='failed_v640_runtime_retired','stale running refresh job is retired using raw status');
ck(($GLOBALS['opts']['ppar_ebay_business_local_recovery_state_v1']['status']??'')==='failed' && ($GLOBALS['opts']['ppar_ebay_business_local_recovery_state_v1']['phase']??'')==='retired','deprecated browser BUSINESS recovery state is retired');
ck(($GLOBALS['opts'][$marker]??'')===RetireHarness::EBAY_RUNTIME_BUILD,'retirement marker is stamped for current controlled build');
ck(in_array(RetireHarness::EBAY_WORKER_HOOK,$GLOBALS['cleared_hooks'],true),'stale shared worker hook is cleared when no valid discovery owner remains');
ck($GLOBALS['inventory_sentinel']===$before_inventory,'retirement is state-only: PRIVATE/BUSINESS/source/native HivePress sentinels unchanged');

// IDEMPOTENCE: second/third/fourth invocation is exact no-op after marker.
$after_first=$GLOBALS['opts'];$clears=count($GLOBALS['cleared_hooks']);$deletes=count($GLOBALS['deleted_transients']);
for($i=2;$i<=4;$i++){$h->maybe_retire_deprecated_ebay_recovery_transports();}
ck($GLOBALS['opts']===$after_first,'retirement runs 2/3/4 are option-state no-ops');
ck(count($GLOBALS['cleared_hooks'])===$clears && count($GLOBALS['deleted_transients'])===$deletes,'retirement runs 2/3/4 do not repeat transport cleanup');
ck($GLOBALS['inventory_sentinel']===$before_inventory,'retirement runs 2/3/4 remain inventory no-ops');

// NEGATIVE: a valid current-build discovery/refresh owner must NOT be killed.
reset_env();
$GLOBALS['opts'][RetireHarness::OPTION_EBAY_SELECTION_STATE]=array('status'=>'complete','phase'=>'done','build'=>RetireHarness::EBAY_RUNTIME_BUILD);
$valid_sync=array('status'=>'running','schema'=>'2.0','engine'=>'resumable-background','build'=>RetireHarness::EBAY_RUNTIME_BUILD);
$valid_refresh=array('status'=>'queued','schema'=>'1.0','engine'=>'targeted-getitem-refresh','build'=>RetireHarness::EBAY_RUNTIME_BUILD);
$GLOBALS['opts'][RetireHarness::OPTION_EBAY_SYNC_JOB]=$valid_sync;
$GLOBALS['opts'][RetireHarness::OPTION_EBAY_REFRESH_JOB]=$valid_refresh;
$before_inventory=$GLOBALS['inventory_sentinel'];
$h->maybe_retire_deprecated_ebay_recovery_transports();
$sync_now=$GLOBALS['opts'][RetireHarness::OPTION_EBAY_SYNC_JOB];$refresh_now=$GLOBALS['opts'][RetireHarness::OPTION_EBAY_REFRESH_JOB];
ck(($sync_now['status']??'')==='running' && empty($sync_now['failure_reason']),'current compatible discovery owner is preserved');
ck(($refresh_now['status']??'')==='queued' && empty($refresh_now['failure_reason']),'current compatible refresh owner is preserved');
ck(!in_array(RetireHarness::EBAY_WORKER_HOOK,$GLOBALS['cleared_hooks'],true),'worker hook is not cleared while valid discovery owner is open');
ck($GLOBALS['inventory_sentinel']===$before_inventory,'negative/current-owner case does not mutate inventory sentinels');

echo "ASSERTIONS=$n FAIL=$fail\n";exit($fail?1:0);
