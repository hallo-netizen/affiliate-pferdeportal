<?php
$root=getenv('PPAR_TEST_PLUGIN_DIR');$src=file_get_contents($root.'/includes/trait-ppar-ebay.php');$n=0;$f=0;function ck($x,$m){global$n,$f;$n++;echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$f++;}
ck(strpos($src,"'ppar_three_hours'")!==false && strpos($src,"3 * HOUR_IN_SECONDS")!==false,'Discovery interval remains three hours');
ck(strpos($src,"wp_schedule_event(time() + 30, 'ppar_three_hours', self::EBAY_CRON_HOOK)")!==false,'Discovery cron schedules the eBay discovery hook every three hours');
ck(strpos($src,"wp_schedule_event(time() + 60, 'hourly', self::EBAY_REFRESH_CRON_HOOK)")!==false,'Inventory refresh remains hourly');
ck(strpos($src,"inventory_refresh_enabled")!==false,'Inventory refresh retains explicit enable gate');
ck(strpos($src,"wp_schedule_event(time()+15,'hourly',self::EBAY_MAINTENANCE_CRON_HOOK)")===false,'Maintenance has no independent hourly mutation schedule');
ck(strpos($src,'run_ebay_maintenance_v2(min(25, $local_remaining), false, 4, true)')!==false,'Hourly refresh embeds bounded classifier/maintenance reconciliation');
echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
