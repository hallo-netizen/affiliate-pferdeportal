<?php
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A'); define('OBJECT','OBJECT'); define('HOUR_IN_SECONDS',3600); define('MINUTE_IN_SECONDS',60); define('DAY_IN_SECONDS',86400);
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}
class WP_Post {public $ID=0,$post_type='',$post_status='publish',$post_name='',$post_title='',$post_content=''; function __construct($a=[]){foreach($a as $k=>$v)$this->$k=$v;}}
function add_action(){return true;} function add_filter(){return true;} function add_shortcode(){return true;} function register_activation_hook(){return true;} function register_deactivation_hook(){return true;}
function apply_filters($tag,$value){return $value;} function do_action(){return null;} function is_admin(){return false;} $GLOBALS['is_ajax']=false; function wp_doing_ajax(){return !empty($GLOBALS['is_ajax']);}
function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_title($v){$v=strtolower(strtr((string)$v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']));return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_textarea_field($v){return trim(strip_tags((string)$v));}
function sanitize_html_class($v){return sanitize_key($v);} function esc_url_raw($v){return (string)$v;} function esc_url($v){return (string)$v;}
function esc_attr($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function esc_html($v){return htmlspecialchars((string)$v,ENT_QUOTES);}
function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return $v;} function wp_json_encode($v,$o=0){return json_encode($v,$o);}
function wp_http_validate_url($v){return filter_var($v,FILTER_VALIDATE_URL)!==false;} function wp_parse_args($a,$d=[]){return array_merge($d,is_array($a)?$a:[]);}
function wp_parse_url($u,$component=-1){return parse_url($u,$component);} function home_url($p='/'){return 'https://pferde-atelier.test'.$p;}
function current_time($t){return $t==='Y-m-d'?gmdate('Y-m-d'):time();} function post_type_exists($pt){return true;} function register_post_type(){return true;} function get_current_blog_id(){return 1;}
function taxonomy_exists($t){return true;} function current_user_can(){return true;} function wp_next_scheduled(){return false;} function wp_schedule_event(){return true;} function wp_schedule_single_event(){return true;}
$GLOBALS['options']=[
 'ppar_enabled'=>'1',
 'ppar_control_settings_v1'=>['emergency_stop'=>0],
 'ppar_network_ebay_v1'=>['enabled'=>1,'client_id'=>'client','client_secret'=>'secret','epn_campaign_id'=>'1234567890','environment'=>'production'],
 'ppar_provider_access_state_v1'=>['ebay'=>['status'=>'connected']],
];
function get_option($k,$d=false){return array_key_exists($k,$GLOBALS['options'])?$GLOBALS['options'][$k]:$d;} function update_option($k,$v,$autoload=null){$GLOBALS['options'][$k]=$v;return true;}
$GLOBALS['meta']=[]; function get_post_meta($id,$k,$s=true){return $GLOBALS['meta'][$id][$k]??'';} function update_post_meta($id,$k,$v){$GLOBALS['meta'][$id][$k]=$v;return true;} function delete_post_meta($id,$k){unset($GLOBALS['meta'][$id][$k]);return true;}
$GLOBALS['posts']=[];$GLOBALS['campaign_get_posts_calls']=0;
function get_posts($args=[]){
  if(($args['post_type']??'')==='ap_campaign'){ $GLOBALS['campaign_get_posts_calls']++; return array_values($GLOBALS['posts']); }
  return [];
}
function get_post($id){return $GLOBALS['posts'][$id]??null;} function get_post_field($f,$id){$p=get_post($id); return $p&&isset($p->$f)?$p->$f:'';}
function get_the_title($id){$p=get_post($id);return $p?$p->post_title:'';} function get_post_ancestors($id){return [];} function get_the_terms($id,$tax){return [];}
function get_ancestors($id,$tax,$type=''){return [];} function get_term($id,$tax=''){return false;} function get_term_by(){return false;}
class DB {
 public $prefix='wp_'; public $base_prefix='wp_'; public $posts='wp_posts'; public $source_rows=[];
 function prepare($q,...$args){foreach($args as $a){$q=preg_replace('/%[sdf]/', is_numeric($a)?(string)$a:"'".addslashes((string)$a)."'", $q, 1);} return $q;}
 function get_row($q,$mode=null){
   if(strpos($q,'ppar_ebay_items')!==false){ foreach($this->source_rows as $row){ if(strpos($q,(string)$row['creative_identity_hash'])!==false || count($this->source_rows)===1) return $row; } }
   return null;
 }
 function get_results($q,$mode=null){return [];} function get_var($q){return null;} function update(){return 1;} function insert(){return 1;}
}
$GLOBALS['wpdb']=new DB;
$root=getenv('PPAR_TEST_PLUGIN_DIR')?:'/mnt/data/final624_extract/affiliate-portal-router'; require $root.'/pferdeportal-affiliate-router.php';
$r=Pferdeportal_Affiliate_Router::instance(); $rc=new ReflectionClass($r); $fail=0;
function ck($ok,$m){global $fail;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$fail++;}
function inv($n,$a=[]){global $r,$rc;$m=$rc->getMethod($n);$m->setAccessible(true);return $m->invokeArgs($r,$a);}
$hash=str_repeat('a',64); $cid=7001;
$campaign=[
 'id'=>'ebay-fliegenmaske','name'=>'eBay – Fliegenmaske','active'=>true,'creative_type'=>'product','network'=>'ebay','advertiser_id'=>'seller1',
 'programme_name'=>'eBay Seller','programme_status'=>'active','quality_manual_status'=>'auto_verified','render_mode'=>'image_link','dimensions'=>'600x600',
 'assignment_mode'=>'page_tree','match_descendants'=>false,'automation_target_keys'=>['page:gesundheit-insekten-und-schutz-fliegenmasken','page:fliegenmasken'],
 'placements'=>['hub_product_1','hub_product_2','hub_product_3','category_product_1','category_product_2','category_product_3','journal_product_1','journal_product_2','journal_product_3','post_bottom_products'],
 'priority'=>90,'start_date'=>'','end_date'=>'','label'=>'eBay-Angebot · Affiliate','title'=>'Bucas Freedom Fly Mask Fliegenmaske','description'=>'Fliegenmaske für Pferde',
 'image_url'=>'https://i.ebayimg.com/images/g/mask/s-l1600.jpg','url'=>'https://www.ebay.de/itm/123?campid=1','target'=>'_blank','health_check_enabled'=>true,'source'=>'output_object_v4','external_id'=>'123'
];
$GLOBALS['posts'][$cid]=new WP_Post(['ID'=>$cid,'post_type'=>'ap_campaign','post_status'=>'publish','post_name'=>'ebay-fliegenmaske','post_title'=>'eBay – Fliegenmaske']);
$GLOBALS['meta'][$cid]=[
 'ppar_campaign_data'=>$campaign,
 '_ppar_ebay_business_auto'=>1,
 '_ppar_ebay_business_match_contract'=>'concept_v3',
 '_ppar_creative_identity_hash'=>$hash,
 'ppar_output_object_id'=>9001,
];
$GLOBALS['wpdb']->source_rows[]=[
 'id'=>1,'creative_identity_hash'=>$hash,'seller_account_type'=>'BUSINESS','source_state'=>'available','policy_state'=>'allowed','route_state'=>'ready',
 'classifier_version'=>'4.0','item_end_at'=>time()+86400,'title'=>'Bucas Freedom Fly Mask Fliegenmaske','source_payload'=>json_encode(['raw'=>['title'=>'Bucas Freedom Fly Mask Fliegenmaske']])
];
$context=['primary_slug'=>'gesundheit-insekten-und-schutz-fliegenmasken','post_type'=>'page','post_id'=>501,'slugs'=>['gesundheit-insekten-und-schutz-fliegenmasken'],'names'=>['Fliegenmasken'],'haystack'=>'fliegenmasken','ancestor_ids'=>[],'term_ids'=>[],'direct_term_slugs'=>[]];
$ranked=inv('ranked_campaigns_for_slot',[$context,'category_product_1']);
ck(count($ranked)===1,'Actual full router keeps one valid eBay BUSINESS product after all public delivery gates');
ck((int)($ranked[0]['campaign']['post_id']??0)===$cid,'Actual full router candidate is the persisted eBay campaign');
$selected=inv('select_campaign_for_slot',[$context,'category_product_1']);
ck(is_array($selected) && (int)($selected['campaign']['post_id']??0)===$cid,'Actual select_campaign_for_slot returns the BUSINESS product winner');
// V6.20 performance: three product slots in one page request share one campaign load.
$rank2=inv('ranked_campaigns_for_slot',[$context,'category_product_2']);
$rank3=inv('ranked_campaigns_for_slot',[$context,'category_product_3']);
ck(count($rank2)===1 && count($rank3)===1,'All three product slots still resolve the valid BUSINESS campaign');
ck(($GLOBALS['campaign_get_posts_calls']??0)===1,'Three slot rankings load ap_campaign posts exactly once per request');
// Search AJAX must not execute content affiliate injection at all.
$GLOBALS['is_ajax']=true;$ajaxOut=$r->filter_the_content('SEARCH-SNIPPET');
ck($ajaxOut==='SEARCH-SNIPPET','AJAX search/content lookup bypasses affiliate injection unchanged');
ck(($GLOBALS['campaign_get_posts_calls']??0)===1,'AJAX content bypass triggers no additional campaign inventory read');
// Negative source lifecycle still fail-closes from the cached campaign cohort.
$GLOBALS['wpdb']->source_rows[0]['source_state']='ended';
$ended=inv('ranked_campaigns_for_slot',[$context,'category_product_1']);
ck(count($ended)===0,'Cached campaign cohort still rechecks durable eBay source state and hides ended offer');
echo "ASSERTIONS_PERF_DONE GET_POSTS=".($GLOBALS['campaign_get_posts_calls']??-1)."\n";exit($fail?1:0);
