<?php
// Hard local integration harness: raw Browse item -> acceptance -> strict classifier
// -> real eBay item upsert -> real creative library upsert -> real output planner
// -> real campaign materializer -> real public router. Business pipeline methods are NOT overridden.
define('ABSPATH','/tmp/ppar-wp/'); define('ARRAY_A','ARRAY_A'); define('OBJECT','OBJECT'); define('HOUR_IN_SECONDS',3600); define('MINUTE_IN_SECONDS',60); define('DAY_IN_SECONDS',86400);
@mkdir(ABSPATH.'wp-admin/includes',0777,true); if(!file_exists(ABSPATH.'wp-admin/includes/upgrade.php')) file_put_contents(ABSPATH.'wp-admin/includes/upgrade.php','<?php');
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}
class WP_Post{public $ID=0,$post_type='',$post_status='publish',$post_name='',$post_title='',$post_content='',$post_excerpt='',$post_parent=0,$menu_order=0;function __construct($a=[]){foreach($a as $k=>$v)$this->$k=$v;}}
class Pferde_Template_Kit{const AFFILIATE_CONTRACT='1.0';static function affiliate_contract_version(){return '1.0';}static function design_profile(){return 'pferde_atelier';}static function design_profile_contract_version(){return '1.0';}static function affiliate_page_type($id){return $GLOBALS['page_context'][$id]??'leaf';}}
function add_action(){return true;} function add_filter(){return true;} function add_shortcode(){return true;} function register_activation_hook(){return true;} function register_deactivation_hook(){return true;} function register_post_type(){return true;} function register_taxonomy(){return true;} function register_rest_route(){return true;}
function apply_filters($tag,$value,...$args){return $value;} function do_action(){return null;} function is_admin(){return false;} function wp_doing_ajax(){return false;} function is_multisite(){return false;} function get_sites(){return [];}
function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_title($v){$v=strtolower(strtr((string)$v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']));return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_textarea_field($v){return trim(strip_tags((string)$v));} function sanitize_html_class($v){return sanitize_key($v);}
function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return strtr((string)$v,['ä'=>'a','ö'=>'o','ü'=>'o','Ä'=>'A','Ö'=>'O','Ü'=>'U','ß'=>'ss']);}
function wp_json_encode($v,$o=0){return json_encode($v,$o);} function wp_parse_args($a,$d=[]){return array_merge($d,is_array($a)?$a:[]);} function maybe_serialize($v){return is_scalar($v)?$v:serialize($v);} function maybe_unserialize($v){$x=@unserialize($v);return $x===false&&$v!=='b:0;'?$v:$x;}
function esc_url_raw($v){return (string)$v;} function esc_url($v){return (string)$v;} function esc_attr($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function esc_html($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function wp_http_validate_url($v){return filter_var((string)$v,FILTER_VALIDATE_URL)!==false;} function wp_parse_url($u,$c=-1){return parse_url($u,$c);} function home_url($p='/'){return 'https://pferde-atelier.test'.$p;} function admin_url($p=''){return 'https://pferde-atelier.test/wp-admin/'.$p;} function get_bloginfo($k=''){return $k==='name'?'Pferde Atelier':'Pferde Atelier';} function get_current_blog_id(){return 1;} function get_home_url($id,$p='/'){return home_url($p);}
function current_time($t){return $t==='timestamp'?time():($t==='Y-m-d'?gmdate('Y-m-d'):time());} function wp_date($f,$ts=null){return date($f,$ts?:time());} function wp_generate_uuid4(){return '11111111-2222-4333-8444-555555555555';} function wp_generate_password(){return 'worker-token';}
function current_user_can(){return true;} function post_type_exists(){return true;} function taxonomy_exists($t){return false;} function get_terms(){return [];} function has_shortcode(){return false;} function get_ancestors(){return [];} function get_post_ancestors(){return [];} function get_the_terms($id=null,$tax=null){$ids=$GLOBALS['post_terms'][$id]??[];return array_values(array_filter(array_map(fn($tid)=>$GLOBALS['terms_by_id'][$tid]??null,$ids)));} function get_term(){return false;} function get_term_by(){return false;} function get_the_title($id){$p=get_post($id);return $p?$p->post_title:'';} function wp_next_scheduled(){return false;} function wp_schedule_event(){return true;} function wp_schedule_single_event(){return true;} function wp_clear_scheduled_hook(){return true;} function get_transient(){return false;} function set_transient(){return true;} function delete_transient(){return true;} function dbDelta(){return true;} function wp_remote_post(){return ['response'=>['code'=>200]];}
$GLOBALS['options']=[
 'ppar_enabled'=>'1','ppar_creative_library_schema_version'=>'3.0','ppar_output_schema_version'=>'1.3','ppar_control_schema_version'=>'1.1','ppar_ebay_schema_version'=>'2.0',
 'ppar_control_settings_v1'=>['emergency_stop'=>0], 'ppar_provider_access_state_v1'=>['ebay'=>['status'=>'connected','last_checked'=>time(),'message'=>'connected']], 'ppar_portal_registry_v1'=>[],
 'ppar_network_ebay_v1'=>['enabled'=>1,'environment'=>'production','client_id'=>'client','client_secret'=>'secret','epn_campaign_id'=>'1234567890','marketplace_id'=>'EBAY_DE','delivery_country'=>'DE','private_enabled'=>1,'business_enabled'=>1],
];
function get_option($k,$d=false){return array_key_exists($k,$GLOBALS['options'])?$GLOBALS['options'][$k]:$d;} function update_option($k,$v,$autoload=null){$GLOBALS['options'][$k]=$v;return true;} function delete_option($k){unset($GLOBALS['options'][$k]);return true;}
$GLOBALS['meta']=[];$GLOBALS['posts']=[];$GLOBALS['pages']=[];$GLOBALS['page_context']=[];$GLOBALS['next_post_id']=5000;
function get_post_meta($id,$k='',$single=true){if($k==='')return $GLOBALS['meta'][$id]??[];return $GLOBALS['meta'][$id][$k]??'';} function update_post_meta($id,$k,$v){$GLOBALS['meta'][$id][$k]=$v;return true;} function delete_post_meta($id,$k){unset($GLOBALS['meta'][$id][$k]);return true;}
function wp_insert_post($a,$err=false){$id=++$GLOBALS['next_post_id'];$a['ID']=$id;$a['post_name']=$a['post_name']??sanitize_title($a['post_title']??('post-'.$id));$GLOBALS['posts'][$id]=new WP_Post($a);return $id;} function wp_update_post($a,$err=false){$id=absint($a['ID']??0);if(!$id||!isset($GLOBALS['posts'][$id]))return $err?new WP_Error('post_missing','missing'):0;foreach($a as $k=>$v){if($k!=='ID')$GLOBALS['posts'][$id]->$k=$v;}return $id;} function get_post($id){return $GLOBALS['posts'][$id]??($GLOBALS['pages'][$id]??null);} function get_post_field($f,$id){$p=get_post($id);return $p&&isset($p->$f)?$p->$f:'';} function get_post_status($id){$p=get_post($id);return $p?$p->post_status:false;}
function get_pages($a=[]){return array_values($GLOBALS['pages']);}
function get_posts($a=[]){$pt=$a['post_type']??'';$out=[];if($pt==='ap_campaign'){foreach($GLOBALS['posts'] as $p){if($p->post_type!=='ap_campaign')continue;if(isset($a['meta_key'])){if((string)get_post_meta($p->ID,$a['meta_key'],true)!==(string)($a['meta_value']??''))continue;} $out[]=(($a['fields']??'')==='ids')?$p->ID:$p;} } return $out;}
class MemDB{
 public $prefix='wp_',$base_prefix='wp_',$posts='wp_posts',$insert_id=0; public $tables=[];
 function get_charset_collate(){return '';}
 function prepare($q,...$args){foreach($args as $a){$rep=is_numeric($a)&&!is_string($a)?(string)$a:"'".str_replace("'","''",(string)$a)."'";$q=preg_replace('/%[sdf]/',$rep,$q,1);}return $q;}
 private function table($q){return preg_match('/\bFROM\s+([A-Za-z0-9_]+)/i',$q,$m)?$m[1]:'';}
 private function val($q,$field){return preg_match('/\b'.preg_quote($field,'/').'\s*=\s*(?:\'([^\']*)\'|([0-9]+))/i',$q,$m)?($m[1]!==''?$m[1]:$m[2]):null;}
 private function matches($row,$q){foreach(['id','portal_key','item_id','identity_hash','object_key','creative_identity_hash','output_type','rule_id'] as $f){$v=$this->val($q,$f);if($v!==null&&(string)($row[$f]??'')!==(string)$v)return false;}if(stripos($q,"seller_account_type='BUSINESS'")!==false&&($row['seller_account_type']??'')!=='BUSINESS')return false; if(preg_match("/object_key\s*<>\s*'([^']+)'/i",$q,$m)&&(string)($row['object_key']??'')===(string)$m[1])return false; return true;}
 function get_row($q,$mode=null){$t=$this->table($q);$rows=$this->tables[$t]??[];$found=[];foreach($rows as $r){if($this->matches($r,$q))$found[]=$r;}if(stripos($q,'ORDER BY id DESC')!==false)usort($found,fn($a,$b)=>($b['id']??0)<=>($a['id']??0));return $found?array_values($found)[0]:null;}
 function get_results($q,$mode=null){$t=$this->table($q);$rows=[];foreach($this->tables[$t]??[] as $r){if($this->matches($r,$q))$rows[]=$r;}return $rows;}
 function get_var($q){if(preg_match('/COUNT\(/i',$q)){return count($this->get_results($q,ARRAY_A));}return null;}
 function insert($t,$d,$f=null){$id=++$this->insert_id;$d['id']=$d['id']??$id;$this->tables[$t][]=$d;$this->insert_id=$d['id'];return 1;}
 function update($t,$d,$w,$f=null,$wf=null){$n=0;foreach($this->tables[$t]??[] as $i=>$r){$ok=true;foreach($w as $k=>$v){if((string)($r[$k]??'')!==(string)$v){$ok=false;break;}}if($ok){$this->tables[$t][$i]=array_merge($r,$d);$n++;}}return $n;}
}
$GLOBALS['wpdb']=new MemDB;
$root=getenv('PPAR_TEST_PLUGIN_DIR')?:'/mnt/data/final624_extract/affiliate-portal-router'; require $root.'/pferdeportal-affiliate-router.php';

function wp_salt($scheme='auth'){return 'test-salt';}
function get_post_type($id){$p=get_post($id);return $p?$p->post_type:'';}
function wp_get_post_categories($id,$args=[]){return $GLOBALS['post_terms'][$id]??[];}
function post_password_required($id=0){return false;}
function is_feed(){return false;} function is_preview(){return false;} function is_singular($t=''){return true;} function in_the_loop(){return true;} function is_main_query(){return true;}
function get_the_ID(){return $GLOBALS['current_post_id']??0;}
function do_blocks($v){return $v;} function shortcode_unautop($v){return $v;} function do_shortcode($v){return $v;}
function wpautop($v){$parts=preg_split('/\\n\\s*\\n/',trim((string)$v));return implode("\\n",array_map(fn($x)=>preg_match('/^<h[1-6]/i',trim($x))?trim($x):'<p>'.trim($x).'</p>',$parts));}
function wp_is_post_revision($id){return false;} function wp_is_post_autosave($id){return false;}
function add_query_arg($a,$u=''){if(is_string($a)){return $u;}return $u.(strpos($u,'?')===false?'?':'&').http_build_query($a);}
function wp_kses($html,$allowed){return $html;} function wp_kses_post($html){return $html;}
function wp_allowed_protocols(){return ['http','https'];}
function trailingslashit($v){return rtrim($v,'/').'/';}
function selected(){return '';} function checked(){return '';} function __($v){return $v;}
class TermObj{public $term_id,$slug,$name;function __construct($id,$slug,$name){$this->term_id=$id;$this->slug=$slug;$this->name=$name;}}
$GLOBALS['terms_by_id']=[];$GLOBALS['post_terms']=[];
function get_the_terms_article($id,$tax){$ids=$GLOBALS['post_terms'][$id]??[];return array_map(fn($tid)=>$GLOBALS['terms_by_id'][$tid],$ids);}

$r=Pferdeportal_Affiliate_Router::instance();$rc=new ReflectionClass($r);$fail=0;$assertions=0;
function ck($ok,$m){global $fail,$assertions;$assertions++;echo($ok?'PASS ':'FAIL ').$m."\\n";if(!$ok)$fail++;}
function inv($n,$a=[]){global $r,$rc;$m=$rc->getMethod($n);$m->setAccessible(true);return $m->invokeArgs($r,$a);}

// Global enable + article hybrid enable.
$GLOBALS['options']['ppar_enabled']='1';
$GLOBALS['options']['ppar_article_hybrid_v1']=['enabled'=>1];
$GLOBALS['options']['ppar_article_plan_revision_v1']=1;
$GLOBALS['options']['ppar_article_preview_v1']=['enabled'=>0];
$GLOBALS['options']['ppar_article_plan_log_v1']=[];
$GLOBALS['options']['ppar_disclosure']='Werbung / Affiliate-Link';

// One realistic article/category context: Regendecken.
$term=new TermObj(77,'pferdedecken-regendecken','Regendecken');$GLOBALS['terms_by_id'][77]=$term;
$article_id=9001;
$content='<p>Einleitung zu Regendecken.</p><h2>Passform und Schnitt</h2><p>Die Passform entscheidet über Bewegungsfreiheit und Scheuerschutz.</p><p>Auch Brustverschluss und Schulterbereich müssen zum Pferd passen.</p><h2>Wasserdichtigkeit und Atmungsaktivität</h2><p>Material und Nähte bestimmen den Wetterschutz.</p><h2>Pflege</h2><p>Regelmäßige Reinigung erhält die Funktion.</p>';
$GLOBALS['posts'][$article_id]=new WP_Post(['ID'=>$article_id,'post_type'=>'post','post_status'=>'publish','post_name'=>'regendecke-ratgeber','post_title'=>'Regendecke richtig auswählen','post_content'=>$content]);
$GLOBALS['post_terms'][$article_id]=[77];$GLOBALS['current_post_id']=$article_id;

function mk_campaign($id,$title,$external,$active=1,$manual='approved',$programme='active',$placements=['post_bottom_products']){
  $p=new WP_Post(['ID'=>$id,'post_type'=>'ap_campaign','post_status'=>'publish','post_name'=>'c'.$id,'post_title'=>$title]);
  $GLOBALS['posts'][$id]=$p;
  $GLOBALS['meta'][$id]['ppar_campaign_data']=[
    'id'=>'c'.$id,'name'=>$title,'title'=>$title,'creative_type'=>'product','render_mode'=>'image_link','network'=>'manual','source'=>'direct',
    'external_id'=>$external,'active'=>$active,'assignment_mode'=>'keywords','match_keywords'=>['regendecke'],'placements'=>$placements,
    'url'=>'https://www.ebay.de/itm/'.$external,'image_url'=>'https://i.ebayimg.com/images/g/'.$external.'/s-l1600.jpg','button_text'=>'Zum Angebot',
    'programme_status'=>$programme,'programme_status_source'=>'ebay_api','programme_status_checked_at'=>time(),'quality_manual_status'=>$manual,'last_synced'=>time(),
    'health_check_enabled'=>false,'priority'=>80,'price'=>'79.90','currency'=>'EUR','availability'=>'available'
  ];
  return $id;
}
mk_campaign(9101,'Horseware Amigo Regendecke 0g','EB1');
mk_campaign(9102,'Waldhausen Comfort Regendecke 50g','EB2');
mk_campaign(9103,'Bucas Smartex Regendecke','EB3');
mk_campaign(9104,'Horseware Amigo Regendecke 0g Größe 145','EB4'); // near duplicate; should not displace diversity
mk_campaign(9105,'Ungeprüfte Regendecke','EB5',1,'unknown'); // WARN, not PASS
mk_campaign(9106,'Beendete Regendecke','EB6',1,'approved','ended'); // hard fail
mk_campaign(9107,'Falscher Slot Regendecke','EB7',1,'approved','active',['category_product_1']);

// Ensure request cache starts empty after synthetic inserts.
$prop=$rc->getProperty('campaigns_request_cache');$prop->setAccessible(true);$prop->setValue($r,null);
$camps=inv('get_campaigns'); $ctx=inv('get_content_context',[$article_id]); echo 'CTX='.json_encode($ctx,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n"; $c=$camps[0]; $ranked=inv('ranked_campaigns_for_slot',[$ctx,'post_bottom_products']); $plan=inv('article_plan_build',[$article_id,'test_article_product_e2e']);
ck(is_array($plan),'Article plan builds for a published post');
ck(($plan['products']['status']??'')==='ready','Product block becomes ready');
$ids=array_values($plan['products']['campaign_post_ids']??[]);
ck(count($ids)===3,'Exactly three products are selected when three qualified distinct offers exist');
ck(count(array_unique($ids))===3,'Selected product campaign IDs are unique');
ck(in_array(9101,$ids,true)&&in_array(9102,$ids,true)&&in_array(9103,$ids,true),'Three qualified Regendecken are selected');
ck(!in_array(9105,$ids,true),'Unreviewed WARN product is excluded');
ck(!in_array(9106,$ids,true),'Ended programme product is excluded');
ck(!in_array(9107,$ids,true),'Product without article placement is excluded');
ck(!in_array(9104,$ids,true),'Near-duplicate product title is excluded when three diverse products exist');

$stored_before=$GLOBALS['posts'][$article_id]->post_content;
$rendered=inv('article_plan_apply_to_content',[$content,$article_id]);
ck(strpos($rendered,'ppar-article-product-block')!==false,'Public render appends the article product block');
ck(substr_count($rendered,'ppar-article-product-card')===3,'Public render contains exactly three product cards');
ck(strpos($rendered,'Produktvorschläge')!==false,'Product block has the intended section label');
ck($GLOBALS['posts'][$article_id]->post_content===$stored_before,'Rendering never mutates stored post_content');

// Runtime invalidation/fallback: disable one planned product and require replacement, not blank block.
$GLOBALS['meta'][9102]['ppar_campaign_data']['active']=0;$prop->setValue($r,null);
$rendered_fallback=inv('article_plan_apply_to_content',[$content,$article_id]);
ck(strpos($rendered_fallback,'ppar-article-product-block')!==false,'Block survives one planned product becoming unavailable');
ck(substr_count($rendered_fallback,'ppar-article-product-card')===3,'Fallback restores the intended three-card count');

// Stale plan must fail closed after article changes, until rebuilt.
$GLOBALS['posts'][$article_id]->post_content=$content.'<p>Neue redaktionelle Ergänzung.</p>';
$stale=inv('article_plan_apply_to_content',[$GLOBALS['posts'][$article_id]->post_content,$article_id]);
ck(strpos($stale,'ppar-article-product-block')===false,'Stale plan is not rendered after article content changes');

// Rebuild and verify output returns.
$plan2=inv('article_plan_build',[$article_id,'after_content_change']);
$rerender=inv('article_plan_apply_to_content',[$GLOBALS['posts'][$article_id]->post_content,$article_id]);
ck(strpos($rerender,'ppar-article-product-block')!==false,'Rebuilt current plan restores product output');

// Fail closed when article feature is disabled.
$GLOBALS['options']['ppar_article_hybrid_v1']=['enabled'=>0];
ck(inv('article_hybrid_enabled')===false,'Article hybrid switch disables automatic article output');

// Static contract: eBay BUSINESS materializer authorizes the exact article product slot.
$ebay=file_get_contents($root.'/includes/trait-ppar-ebay.php');
ck(strpos($ebay,"'post_bottom_products'")!==false,'eBay BUSINESS product campaigns include the article product placement');

// Static contract: automatic content filter is registered and shortcodes suppress duplication.
$main=file_get_contents($root.'/pferdeportal-affiliate-router.php');
ck(strpos($main,"add_filter('the_content', array(\$this, 'filter_the_content'), 20)")!==false,'the_content integration is registered');
ck(strpos($main,"has_shortcode(\$raw_post_content, 'pp_affiliate_slot')")!==false,'Manual affiliate shortcode suppresses automatic duplicate injection');

echo "ASSERTIONS=$assertions FAIL=$fail SELECTED=".implode(',',$ids)."\\n";exit($fail?1:0);
