<?php
// Hard local integration harness: raw Browse item -> acceptance -> strict classifier
// -> real eBay item upsert -> real creative library upsert -> real output planner
// -> real campaign materializer -> real public router. Business pipeline methods are NOT overridden.
define('ABSPATH','/tmp/ppar-wp/'); define('ARRAY_A','ARRAY_A'); define('OBJECT','OBJECT'); define('HOUR_IN_SECONDS',3600); define('MINUTE_IN_SECONDS',60); define('DAY_IN_SECONDS',86400);
@mkdir(ABSPATH.'wp-admin/includes',0777,true); if(!file_exists(ABSPATH.'wp-admin/includes/upgrade.php')) file_put_contents(ABSPATH.'wp-admin/includes/upgrade.php','<?php');
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}
class WP_Post{public $ID=0,$post_type='',$post_status='publish',$post_name='',$post_title='',$post_content='',$post_excerpt='',$post_parent=0,$menu_order=0;function __construct($a=[]){foreach($a as $k=>$v)$this->$k=$v;}}
class Pferde_Template_Kit{const AFFILIATE_CONTRACT='1.0';static function affiliate_contract_version(){return '1.0';}static function design_profile(){return 'pferde_atelier';}static function design_profile_contract_version(){return '1.0';}static function affiliate_page_type($id){return $GLOBALS['page_context'][$id]??'leaf';}}
function add_action(){return true;} function add_filter(){return true;} function add_shortcode(){return true;} function register_activation_hook(){return true;} function register_deactivation_hook(){return true;} function register_post_type(){return true;} function register_taxonomy(){return true;} function register_rest_route(){return true;}
function apply_filters($tag,$value,...$args){return $value;} function do_action(){return null;} function is_admin(){return false;} function wp_doing_ajax(){return false;} function is_multisite(){return false;} function get_sites(){return [];}
function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_title($v){$v=strtolower(strtr((string)$v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']));return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_textarea_field($v){return trim(strip_tags((string)$v));} function sanitize_html_class($v){return sanitize_key($v);}
function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return strtr((string)$v,['ä'=>'a','ö'=>'o','ü'=>'o','Ä'=>'A','Ö'=>'O','Ü'=>'U','ß'=>'ss']);}
function wp_json_encode($v,$o=0){return json_encode($v,$o);} function wp_parse_args($a,$d=[]){return array_merge($d,is_array($a)?$a:[]);} function maybe_serialize($v){return is_scalar($v)?$v:serialize($v);} function maybe_unserialize($v){$x=@unserialize($v);return $x===false&&$v!=='b:0;'?$v:$x;}
function esc_url_raw($v){return (string)$v;} function esc_url($v){return (string)$v;} function esc_attr($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function esc_html($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function wp_http_validate_url($v){return filter_var((string)$v,FILTER_VALIDATE_URL)!==false;} function wp_parse_url($u,$c=-1){return parse_url($u,$c);} function home_url($p='/'){return 'https://pferde-atelier.test'.$p;} function admin_url($p=''){return 'https://pferde-atelier.test/wp-admin/'.$p;} function get_bloginfo($k=''){return $k==='name'?'Pferde Atelier':'Pferde Atelier';} function get_current_blog_id(){return 1;} function get_home_url($id,$p='/'){return home_url($p);}
function current_time($t){return $t==='timestamp'?time():($t==='Y-m-d'?gmdate('Y-m-d'):time());} function wp_date($f,$ts=null){return date($f,$ts?:time());} function wp_generate_uuid4(){return '11111111-2222-4333-8444-555555555555';} function wp_generate_password(){return 'worker-token';}
function current_user_can(){return true;} function post_type_exists(){return true;} function taxonomy_exists($t){return false;} function get_terms(){return [];} function has_shortcode(){return false;} function get_ancestors(){return [];} function get_post_ancestors(){return [];} function get_the_terms(){return [];} function get_term(){return false;} function get_term_by(){return false;} function get_the_title($id){$p=get_post($id);return $p?$p->post_title:'';} function wp_next_scheduled(){return false;} function wp_schedule_event(){return true;} function wp_schedule_single_event(){return true;} function wp_clear_scheduled_hook(){return true;} function get_transient(){return false;} function set_transient(){return true;} function delete_transient(){return true;} function dbDelta(){return true;} function wp_remote_post(){return ['response'=>['code'=>200]];}
$GLOBALS['options']=[
 'ppar_enabled'=>'1','ppar_creative_library_schema_version'=>'3.0','ppar_output_schema_version'=>'1.3','ppar_control_schema_version'=>'1.1','ppar_ebay_schema_version'=>'2.0',
 'ppar_control_settings_v1'=>['emergency_stop'=>0], 'ppar_provider_access_state_v1'=>['ebay'=>['status'=>'connected','last_checked'=>time(),'message'=>'connected']], 'ppar_portal_registry_v1'=>[],
 'ppar_network_ebay_v1'=>['enabled'=>1,'environment'=>'production','client_id'=>'client','client_secret'=>'secret','epn_campaign_id'=>'1234567890','marketplace_id'=>'EBAY_DE','delivery_country'=>'DE','private_enabled'=>1,'business_enabled'=>1],
];
function get_option($k,$d=false){return array_key_exists($k,$GLOBALS['options'])?$GLOBALS['options'][$k]:$d;} function update_option($k,$v,$autoload=null){$GLOBALS['options'][$k]=$v;return true;} function delete_option($k){unset($GLOBALS['options'][$k]);return true;}
$GLOBALS['meta']=[];$GLOBALS['posts']=[];$GLOBALS['pages']=[];$GLOBALS['page_context']=[];$GLOBALS['next_post_id']=5000;
function get_post_meta($id,$k='',$single=true){if($k==='')return $GLOBALS['meta'][$id]??[];return $GLOBALS['meta'][$id][$k]??'';} function update_post_meta($id,$k,$v){$GLOBALS['meta'][$id][$k]=$v;return true;} function delete_post_meta($id,$k){unset($GLOBALS['meta'][$id][$k]);return true;}
function wp_insert_post($a,$err=false){$id=++$GLOBALS['next_post_id'];$a['ID']=$id;$a['post_name']=$a['post_name']??sanitize_title($a['post_title']??('post-'.$id));$GLOBALS['posts'][$id]=new WP_Post($a);return $id;} function wp_update_post($a,$err=false){$id=absint($a['ID']??0);if(!$id||!isset($GLOBALS['posts'][$id]))return $err?new WP_Error('post_missing','missing'):0;foreach($a as $k=>$v){if($k!=='ID')$GLOBALS['posts'][$id]->$k=$v;}return $id;} function get_post($id){return $GLOBALS['posts'][$id]??($GLOBALS['pages'][$id]??null);} function get_post_field($f,$id){$p=get_post($id);return $p&&isset($p->$f)?$p->$f:'';} function get_post_status($id){$p=get_post($id);return $p?$p->post_status:false;}
function get_pages($a=[]){return array_values($GLOBALS['pages']);}
function get_posts($a=[]){$pt=$a['post_type']??'';$out=[];if($pt==='ap_campaign'){foreach($GLOBALS['posts'] as $p){if($p->post_type!=='ap_campaign')continue;if(isset($a['meta_key'])){if((string)get_post_meta($p->ID,$a['meta_key'],true)!==(string)($a['meta_value']??''))continue;} $out[]=(($a['fields']??'')==='ids')?$p->ID:$p;} } return $out;}
class MemDB{
 public $prefix='wp_',$base_prefix='wp_',$posts='wp_posts',$insert_id=0; public $tables=[];
 function get_charset_collate(){return '';}
 function prepare($q,...$args){foreach($args as $a){$rep=is_numeric($a)&&!is_string($a)?(string)$a:"'".str_replace("'","''",(string)$a)."'";$q=preg_replace('/%[sdf]/',$rep,$q,1);}return $q;}
 private function table($q){return preg_match('/\bFROM\s+([A-Za-z0-9_]+)/i',$q,$m)?$m[1]:'';}
 private function val($q,$field){return preg_match('/\b'.preg_quote($field,'/').'\s*=\s*(?:\'([^\']*)\'|([0-9]+))/i',$q,$m)?($m[1]!==''?$m[1]:$m[2]):null;}
 private function matches($row,$q){foreach(['id','portal_key','item_id','identity_hash','object_key','creative_identity_hash','output_type','rule_id'] as $f){$v=$this->val($q,$f);if($v!==null&&(string)($row[$f]??'')!==(string)$v)return false;}if(stripos($q,"seller_account_type='BUSINESS'")!==false&&($row['seller_account_type']??'')!=='BUSINESS')return false; if(preg_match("/object_key\s*<>\s*'([^']+)'/i",$q,$m)&&(string)($row['object_key']??'')===(string)$m[1])return false; return true;}
 function get_row($q,$mode=null){$t=$this->table($q);$rows=$this->tables[$t]??[];$found=[];foreach($rows as $r){if($this->matches($r,$q))$found[]=$r;}if(stripos($q,'ORDER BY id DESC')!==false)usort($found,fn($a,$b)=>($b['id']??0)<=>($a['id']??0));return $found?array_values($found)[0]:null;}
 function get_results($q,$mode=null){$t=$this->table($q);$rows=[];foreach($this->tables[$t]??[] as $r){if($this->matches($r,$q))$rows[]=$r;}return $rows;}
 function get_var($q){if(preg_match('/COUNT\(/i',$q)){return count($this->get_results($q,ARRAY_A));}return null;}
 function insert($t,$d,$f=null){$id=++$this->insert_id;$d['id']=$d['id']??$id;$this->tables[$t][]=$d;$this->insert_id=$d['id'];return 1;}
 function update($t,$d,$w,$f=null,$wf=null){$n=0;foreach($this->tables[$t]??[] as $i=>$r){$ok=true;foreach($w as $k=>$v){if((string)($r[$k]??'')!==(string)$v){$ok=false;break;}}if($ok){$this->tables[$t][$i]=array_merge($r,$d);$n++;}}return $n;}
}
$GLOBALS['wpdb']=new MemDB;
$root=getenv('PPAR_TEST_PLUGIN_DIR')?:'/mnt/data/final624_extract/affiliate-portal-router'; require $root.'/pferdeportal-affiliate-router.php';
$r=Pferdeportal_Affiliate_Router::instance();$rc=new ReflectionClass($r);$fail=0;$assertions=0;function ck($ok,$m){global $fail,$assertions;$assertions++;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$fail++;}function inv($n,$a=[]){global $r,$rc;$m=$rc->getMethod($n);$m->setAccessible(true);return $m->invokeArgs($r,$a);}

function run_business_selection_orchestrator_v640($settings,$reason){
  $state=inv('ebay_selection_request',[$reason,'test:legacy-rebalance-migrated',true,'business']);
  $ticks=0;
  while(is_array($state)&&in_array(sanitize_key((string)($state['status']??'')),['pending','preparing','running'],true)&&$ticks<500){
    $state=inv('ebay_selection_process_tick',[$settings,$state]);
    $ticks++;
  }
  $stats=(array)($state['stats']['business']??[]);
  $stats['selection_status']=(string)($state['status']??'');
  $stats['selection_ticks']=$ticks;
  return $stats;
}


$catalog=json_decode(file_get_contents($root.'/assets/ebay-portal-catalog-v2.json'),true);
$pid=100;foreach($catalog['product_targets'] as $target){$slug=sanitize_title($target['slug']??'');if($slug==='')continue;$p=new WP_Post(['ID'=>++$pid,'post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>$target['product_title']??$slug,'post_parent'=>0]);$GLOBALS['pages'][$p->ID]=$p;$GLOBALS['page_context'][$p->ID]='leaf';}
$settings=inv('ebay_normalize_settings',[array_merge(inv('ebay_settings_defaults'),['enabled'=>1,'environment'=>'production','client_id'=>'c','client_secret'=>'s','epn_campaign_id'=>'1234567890','marketplace_id'=>'EBAY_DE','delivery_country'=>'DE','private_enabled'=>false,'business_enabled'=>true,'business_active_cap'=>300,'business_candidate_pool_per_concept'=>10,'business_reserve_per_concept'=>2,'business_min_feedback_percentage'=>99.0,'business_min_feedback_score'=>100]),true]);
$profiles=inv('ebay_sync_profiles',[$settings]);$prof=null;foreach($profiles as $p){if(($p['seller_type']??'')==='BUSINESS'&&($p['expected_business_concept_id']??'')==='concept-reitstiefel'){$prof=$p;break;}}
$fail=0;$assertions=0;function lck($ok,$m){global $fail,$assertions;$assertions++;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$fail++;}
lck(is_array($prof),'Reitstiefel profile exists for LKG/capacity swap test');
function rawlkg($id,$brand,$seller,$pct,$score,$price){return ['itemId'=>$id,'seller'=>['sellerAccountType'=>'BUSINESS','username'=>$seller,'feedbackPercentage'=>$pct,'feedbackScore'=>$score],'listingMarketplaceId'=>'EBAY_DE','buyingOptions'=>['FIXED_PRICE'],'itemAffiliateWebUrl'=>'https://www.ebay.de/itm/'.$id.'?campid=1','itemWebUrl'=>'https://www.ebay.de/itm/'.$id,'image'=>['imageUrl'=>'https://i.ebayimg.com/images/g/'.$id.'/s-l1600.jpg'],'title'=>$brand.' '.$id.' Reitstiefel Leder','price'=>['value'=>(string)$price,'currency'=>'EUR'],'categories'=>[['categoryId'=>'1','categoryName'=>'Reitstiefel']], 'localizedAspects'=>[['name'=>'Produktart','value'=>'Reitstiefel'],['name'=>'Marke','value'=>$brand]],'returnTerms'=>['returnsAccepted'=>true],'shippingOptions'=>[['shippingCost'=>['value'=>'0.00','currency'=>'EUR']]],'itemCreationDate'=>date('c',time()-86400*5),'itemEndDate'=>date('c',time()+86400*30)];}
$items=[];
foreach([
 ['LKG-A','Ariat','seller-a',99.9,5000,130],
 ['LKG-B','Uvex','seller-b',99.8,3500,125],
 ['LKG-C','Waldhausen','seller-c',99.7,2500,120],
 ['LKG-D','Kerbl','seller-d',99.6,1800,115],
 ['LKG-E','HKM','seller-e',99.5,900,110],
] as $d){[$id,$brand,$seller,$pct,$score,$price]=$d;$it=inv('ebay_accept_item',[rawlkg($id,$brand,$seller,$pct,$score,$price),'BUSINESS',$settings]);$cl=!is_wp_error($it)?inv('ebay_business_classify_portal_item_strict',[$it,$prof['rule']]):$it;lck(!is_wp_error($cl),"$id classifies");if(is_wp_error($cl))continue;$it['portal_classification']=$cl;$q=inv('ebay_business_quality_assess',[$it,$cl,$prof['rule'],$settings,120]);lck(!is_wp_error($q),"$id quality passes");if(is_wp_error($q))continue;$it['business_quality']=$q;$row=inv('ebay_upsert_item',[$it,$prof['rule'],'business_affiliate',0,$settings]);$res=inv('ebay_route_business',[$row,$it,$prof['rule'],'pre-v619-'.$id,$cl]);lck(!is_wp_error($res),"$id simulates an already materialized V6.18/LKG campaign");$items[$id]=['item'=>$it,'row'=>$row];}
function activeCampaignIds(){ $ids=[];foreach($GLOBALS['posts'] as $p){if($p->post_type!=='ap_campaign')continue;$c=get_post_meta($p->ID,'ppar_campaign_data',true);if(!empty($c['active']))$ids[(string)($c['external_id']??'')]=$p->ID;}return $ids;}
lck(count(activeCampaignIds())===5,'Precondition: five old materialized campaigns are active');
$stats1=run_business_selection_orchestrator_v640($settings,'lkg_initial');$active1=activeCampaignIds();lck(count($active1)===3,'Quality/cap rebalance atomically reduces five old campaigns to top 3');
$rows=$GLOBALS['wpdb']->tables['wp_ppar_ebay_items']??[];$roles=[];$hashByItem=[];foreach($rows as $row){$p=json_decode($row['source_payload']??'',true);$roles[(string)$row['item_id']]=$p['business_selection']['role']??'';$hashByItem[(string)$row['item_id']]=(string)($row['creative_identity_hash']??'');}
lck(count(array_filter($roles,fn($x)=>$x==='active_selected'))===3 && count(array_filter($roles,fn($x)=>$x==='reserve'))===2,'Demoted LKG rows become exactly two internal reserves');
$demoted=array_keys(array_filter($roles,fn($x)=>$x==='reserve'));$creativeTable=$GLOBALS['wpdb']->tables['wp_ppar_creative_library']??[];$verifiedPreserved=true;foreach($demoted as $id){$hash=$hashByItem[$id]??'';$found=null;foreach($creativeTable as $cr){if(($cr['identity_hash']??'')===$hash){$found=$cr;break;}}$payload=is_array($found)?json_decode($found['payload']??'',true):[];if(empty($payload['ebay_verified_product_concept'])||empty($payload['ebay_verified_product_targets']))$verifiedPreserved=false;}
lck($verifiedPreserved,'Capacity demotion preserves verified creative/target contract for safe reserve promotion');
// V6.20 lifecycle: end one active winner. A qualified reserve must be promoted
// in the same refresh operation, before the ended winner is tombstoned.
$activeBefore=activeCampaignIds();$endedId=array_key_first($activeBefore);$endedRow=null;
foreach($GLOBALS['wpdb']->tables['wp_ppar_ebay_items']??[] as $row){if(($row['item_id']??'')===$endedId){$endedRow=$row;break;}}
lck(is_array($endedRow) && ($endedRow['output_state']??'')==='creative_ready','Precondition: chosen ended item is a public BUSINESS winner');
$mark=$rc->getMethod('ebay_refresh_mark_ended');$mark->setAccessible(true);$endedResult=$mark->invoke($r,$endedRow,'test ended',$settings);
lck(!empty($endedResult['replacement']['promoted']),'Ended BUSINESS winner immediately promotes a qualified reserve');
$activeAfter=activeCampaignIds();lck(count($activeAfter)===3,'BUSINESS visible cardinality remains three after seamless replacement');
lck(!isset($activeAfter[$endedId]),'Ended BUSINESS item is no longer publicly active');
$replacementIds=array_values(array_diff(array_keys($activeAfter),array_keys($activeBefore)));lck(count($replacementIds)===1,'Exactly one reserve replaces exactly one ended winner');
$endedStored=null;foreach($GLOBALS['wpdb']->tables['wp_ppar_ebay_items']??[] as $row){if(($row['item_id']??'')===$endedId){$endedStored=$row;break;}}
lck(($endedStored['source_state']??'')==='ended' && ($endedStored['output_state']??'')==='inactive','Ended source is durably tombstoned/fail-closed');
// Negative: make every non-public replacement candidate actually ended. The next
// public end must not resurrect an ended/invalid reserve just to fill the slot.
$current=activeCampaignIds();$secondId=array_key_first($current);
foreach($GLOBALS['wpdb']->tables['wp_ppar_ebay_items']??[] as $i=>$row){if(($row['item_id']??'')===$secondId)continue;if(($row['output_state']??'')!=='creative_ready'){$GLOBALS['wpdb']->tables['wp_ppar_ebay_items'][$i]['item_end_at']=time()-10;}}
$secondRow=null;foreach($GLOBALS['wpdb']->tables['wp_ppar_ebay_items']??[] as $row){if(($row['item_id']??'')===$secondId){$secondRow=$row;break;}}
$res2=$mark->invoke($r,$secondRow,'test ended without reserve',$settings);
lck(empty($res2['replacement']['promoted']),'No ended/expired reserve is promoted when no qualified replacement exists');
$activeFinal=activeCampaignIds();lck(count($activeFinal)===2,'Fail-closed lifecycle prefers an empty slot over an invalid replacement');
lck(!isset($activeFinal[$secondId]),'Second ended item is also absent from public output');
echo "ASSERTIONS=$assertions FAIL=$fail ACTIVE_BEFORE=".count($activeBefore)." ACTIVE_AFTER=".count($activeAfter)." ACTIVE_FINAL=".count($activeFinal)."\n";exit($fail?1:0);
