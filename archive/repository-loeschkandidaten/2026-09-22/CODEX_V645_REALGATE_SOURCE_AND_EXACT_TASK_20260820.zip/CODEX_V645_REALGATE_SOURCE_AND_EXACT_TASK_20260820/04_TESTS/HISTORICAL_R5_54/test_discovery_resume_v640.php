<?php
// Discovery resume contract: a segment-time-budget partial current-build job
// resumes from its exact durable cursor/page state. No fresh job/reset is allowed.
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A');
function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_text_field($v){return trim(strip_tags((string)$v));}
function absint($v){return abs((int)$v);} function wp_generate_password($l=48,$s=false,$e=false){return str_repeat('T',$l);} function apply_filters($t,$v){return $v;}
$GLOBALS['opts']=[]; function get_option($k,$d=false){return array_key_exists($k,$GLOBALS['opts'])?$GLOBALS['opts'][$k]:$d;} function update_option($k,$v,$a=false){$GLOBALS['opts'][$k]=$v;return true;}
$root=getenv('PPAR_TEST_PLUGIN_DIR'); require $root.'/includes/trait-ppar-ebay.php';
class T{use PPAR_Ebay_Trait; const OPTION_EBAY_SYNC_JOB='sync',EBAY_RUNTIME_BUILD='controlled-rebuild-test'; public function resumable($j){return $this->ebay_sync_job_is_resumable_partial($j);} public function resume($j,$a){return $this->ebay_sync_resume_partial_job($j,$a);} public function open($j){return $this->ebay_sync_job_is_open($j);} public function load(){return $this->ebay_sync_job_load();}}
$f=0;$n=0;function ck($x,$m){global$f,$n;$n++;echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$f++;}
$t=new T;
$job=[
 'schema'=>'2.0','engine'=>'resumable-background','build'=>'controlled-rebuild-test','status'=>'partial','run_uuid'=>'RUN-DISCOVERY-1','worker_token'=>'tok','scope'=>'all','listing_author_id'=>5,
 'profile_cursor'=>17,'current_page'=>['profile_key'=>'concept-x|BUSINESS|q1','index'=>7,'items'=>[['itemId'=>'A'],['itemId'=>'B']],'next'=>'NEXT-TOKEN'],
 'requests_in_batch'=>19,'routed_items'=>['OLD'=>'business_affiliate'],'soft_pending'=>['SOFT'=>['code'=>'review']],
 'summary'=>['status'=>'partial','requests'=>24,'pages'=>9,'segments'=>2,'budget'=>['stopped_reason'=>'segment_time_budget']],
 'finished_at'=>123,'created_at'=>100,'segment_started_at'=>100,'updated_at'=>120,
];
ck($t->resumable($job)===true,'Current-build discovery partial with segment_time_budget is resumable');
$res=$t->resume($job,42);
ck(($res['status']??'')==='queued','Discovery resume reopens the same job as queued');
ck(($res['run_uuid']??'')==='RUN-DISCOVERY-1','Discovery resume preserves run_uuid instead of creating a fresh job');
ck((int)($res['profile_cursor']??-1)===17,'Discovery resume preserves profile cursor');
ck(($res['current_page']??[])===$job['current_page'],'Discovery resume preserves exact in-page item cursor and continuation token');
ck((int)($res['requests_in_batch']??-1)===19,'Discovery resume preserves request-batch cursor');
ck(($res['routed_items']??[])===$job['routed_items']&&($res['soft_pending']??[])===$job['soft_pending'],'Discovery resume preserves dedupe/review durable state');
ck((int)($res['summary']['requests']??-1)===24&&(int)($res['summary']['pages']??-1)===9,'Discovery resume preserves accumulated request/page counters');
ck((int)($res['summary']['segments']??0)===3,'Discovery resume increments segment count exactly once');
ck(($res['summary']['budget']['stopped_reason']??'x')==='','Discovery resume clears only the segment stop reason');
ck((int)($res['listing_author_id']??0)===42,'Discovery resume updates required runtime listing owner without resetting work');
ck($t->open($res)===true,'Resumed discovery job is runtime-compatible and open');
ck($t->load()===$res,'Resumed discovery state is durably saved exactly as returned');
ck($t->resume($res,42)===[],'Already-open resumed discovery cannot be resumed/reset a second time');
$wrong=$job;$wrong['build']='old-build';ck($t->resumable($wrong)===false,'Old-build partial discovery is not silently resumed across runtime contract');
echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
