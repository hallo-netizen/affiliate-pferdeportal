<?php
// Hard local integration harness: raw Browse item -> acceptance -> strict classifier
// -> real eBay item upsert -> real creative library upsert -> real output planner
// -> real campaign materializer -> real public router. Business pipeline methods are NOT overridden.
define('ABSPATH','/tmp/ppar-wp/'); define('ARRAY_A','ARRAY_A'); define('OBJECT','OBJECT'); define('HOUR_IN_SECONDS',3600); define('MINUTE_IN_SECONDS',60); define('DAY_IN_SECONDS',86400);
@mkdir(ABSPATH.'wp-admin/includes',0777,true); if(!file_exists(ABSPATH.'wp-admin/includes/upgrade.php')) file_put_contents(ABSPATH.'wp-admin/includes/upgrade.php','<?php');
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}
class WP_Post{public $ID=0,$post_type='',$post_status='publish',$post_name='',$post_title='',$post_content='',$post_excerpt='',$post_parent=0,$menu_order=0;function __construct($a=[]){foreach($a as $k=>$v)$this->$k=$v;}}
class Pferde_Template_Kit{const AFFILIATE_CONTRACT='1.0';static function affiliate_contract_version(){return '1.0';}static function design_profile(){return 'pferde_atelier';}static function design_profile_contract_version(){return '1.0';}static function affiliate_page_type($id){return $GLOBALS['page_context'][$id]??'leaf';}}
function add_action(){return true;} function add_filter(){return true;} function add_shortcode(){return true;} function register_activation_hook(){return true;} function register_deactivation_hook(){return true;} function register_post_type(){return true;} function register_taxonomy(){return true;} function register_rest_route(){return true;}
function apply_filters($tag,$value,...$args){return $value;} function do_action(){return null;} function is_admin(){return false;} function wp_doing_ajax(){return false;} function is_multisite(){return false;} function get_sites(){return [];}
function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_title($v){$v=strtolower(strtr((string)$v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']));return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_textarea_field($v){return trim(strip_tags((string)$v));} function sanitize_html_class($v){return sanitize_key($v);}
function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return strtr((string)$v,['ä'=>'a','ö'=>'o','ü'=>'o','Ä'=>'A','Ö'=>'O','Ü'=>'U','ß'=>'ss']);}
function wp_json_encode($v,$o=0){return json_encode($v,$o);} function wp_parse_args($a,$d=[]){return array_merge($d,is_array($a)?$a:[]);} function maybe_serialize($v){return is_scalar($v)?$v:serialize($v);} function maybe_unserialize($v){$x=@unserialize($v);return $x===false&&$v!=='b:0;'?$v:$x;}
function esc_url_raw($v){return (string)$v;} function esc_url($v){return (string)$v;} function esc_attr($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function esc_html($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function wp_http_validate_url($v){return filter_var((string)$v,FILTER_VALIDATE_URL)!==false;} function wp_parse_url($u,$c=-1){return parse_url($u,$c);} function home_url($p='/'){return 'https://pferde-atelier.test'.$p;} function admin_url($p=''){return 'https://pferde-atelier.test/wp-admin/'.$p;} function get_bloginfo($k=''){return $k==='name'?'Pferde Atelier':'Pferde Atelier';} function get_current_blog_id(){return 1;} function get_home_url($id,$p='/'){return home_url($p);}
function current_time($t){return $t==='timestamp'?time():($t==='Y-m-d'?gmdate('Y-m-d'):time());} function wp_date($f,$ts=null){return date($f,$ts?:time());} function wp_generate_uuid4(){return '11111111-2222-4333-8444-555555555555';} function wp_generate_password(){return 'worker-token';}
function current_user_can(){return true;} function post_type_exists(){return true;} function taxonomy_exists($t){return false;} function get_terms(){return [];} function has_shortcode(){return false;} function get_ancestors(){return [];} function get_post_ancestors(){return [];} function get_the_terms(){return [];} function get_term(){return false;} function get_term_by(){return false;} function get_the_title($id){$p=get_post($id);return $p?$p->post_title:'';} function wp_next_scheduled(){return false;} function wp_schedule_event(){return true;} function wp_schedule_single_event(){return true;} function wp_clear_scheduled_hook(){return true;} function get_transient(){return false;} function set_transient(){return true;} function delete_transient(){return true;} function dbDelta(){return true;} function wp_remote_post(){return ['response'=>['code'=>200]];}
$GLOBALS['options']=[
 'ppar_enabled'=>'1','ppar_creative_library_schema_version'=>'3.0','ppar_output_schema_version'=>'1.3','ppar_control_schema_version'=>'1.1','ppar_ebay_schema_version'=>'2.0',
 'ppar_control_settings_v1'=>['emergency_stop'=>0], 'ppar_provider_access_state_v1'=>['ebay'=>['status'=>'connected','last_checked'=>time(),'message'=>'connected']], 'ppar_portal_registry_v1'=>[],
 'ppar_network_ebay_v1'=>['enabled'=>1,'environment'=>'production','client_id'=>'client','client_secret'=>'secret','epn_campaign_id'=>'1234567890','marketplace_id'=>'EBAY_DE','delivery_country'=>'DE','private_enabled'=>1,'business_enabled'=>1],
];
function get_option($k,$d=false){return array_key_exists($k,$GLOBALS['options'])?$GLOBALS['options'][$k]:$d;} function update_option($k,$v,$autoload=null){$GLOBALS['options'][$k]=$v;return true;} function delete_option($k){unset($GLOBALS['options'][$k]);return true;}
$GLOBALS['meta']=[];$GLOBALS['posts']=[];$GLOBALS['pages']=[];$GLOBALS['page_context']=[];$GLOBALS['next_post_id']=5000;
function get_post_meta($id,$k='',$single=true){if($k==='')return $GLOBALS['meta'][$id]??[];return $GLOBALS['meta'][$id][$k]??'';} function update_post_meta($id,$k,$v){$GLOBALS['meta'][$id][$k]=$v;return true;} function delete_post_meta($id,$k){unset($GLOBALS['meta'][$id][$k]);return true;}
function wp_insert_post($a,$err=false){$id=++$GLOBALS['next_post_id'];$a['ID']=$id;$a['post_name']=$a['post_name']??sanitize_title($a['post_title']??('post-'.$id));$GLOBALS['posts'][$id]=new WP_Post($a);return $id;} function wp_update_post($a,$err=false){$id=absint($a['ID']??0);if(!$id||!isset($GLOBALS['posts'][$id]))return $err?new WP_Error('post_missing','missing'):0;foreach($a as $k=>$v){if($k!=='ID')$GLOBALS['posts'][$id]->$k=$v;}return $id;} function get_post($id){return $GLOBALS['posts'][$id]??($GLOBALS['pages'][$id]??null);} function get_post_field($f,$id){$p=get_post($id);return $p&&isset($p->$f)?$p->$f:'';} function get_post_status($id){$p=get_post($id);return $p?$p->post_status:false;}
function get_pages($a=[]){return array_values($GLOBALS['pages']);}
function get_posts($a=[]){$pt=$a['post_type']??'';$out=[];if($pt==='ap_campaign'){foreach($GLOBALS['posts'] as $p){if($p->post_type!=='ap_campaign')continue;if(isset($a['meta_key'])){if((string)get_post_meta($p->ID,$a['meta_key'],true)!==(string)($a['meta_value']??''))continue;} $out[]=(($a['fields']??'')==='ids')?$p->ID:$p;} } return $out;}
class MemDB{
 public $prefix='wp_',$base_prefix='wp_',$posts='wp_posts',$insert_id=0; public $tables=[];
 function get_charset_collate(){return '';}
 function prepare($q,...$args){foreach($args as $a){$rep=is_numeric($a)&&!is_string($a)?(string)$a:"'".str_replace("'","''",(string)$a)."'";$q=preg_replace('/%[sdf]/',$rep,$q,1);}return $q;}
 private function table($q){return preg_match('/\bFROM\s+([A-Za-z0-9_]+)/i',$q,$m)?$m[1]:'';}
 private function val($q,$field){return preg_match('/\b'.preg_quote($field,'/').'\s*=\s*(?:\'([^\']*)\'|([0-9]+))/i',$q,$m)?($m[1]!==''?$m[1]:$m[2]):null;}
 private function matches($row,$q){foreach(['id','portal_key','item_id','identity_hash','object_key','creative_identity_hash','output_type','rule_id'] as $f){$v=$this->val($q,$f);if($v!==null&&(string)($row[$f]??'')!==(string)$v)return false;}if(stripos($q,"seller_account_type='BUSINESS'")!==false&&($row['seller_account_type']??'')!=='BUSINESS')return false; if(preg_match("/object_key\s*<>\s*'([^']+)'/i",$q,$m)&&(string)($row['object_key']??'')===(string)$m[1])return false; return true;}
 function get_row($q,$mode=null){$t=$this->table($q);$rows=$this->tables[$t]??[];$found=[];foreach($rows as $r){if($this->matches($r,$q))$found[]=$r;}if(stripos($q,'ORDER BY id DESC')!==false)usort($found,fn($a,$b)=>($b['id']??0)<=>($a['id']??0));return $found?array_values($found)[0]:null;}
 function get_results($q,$mode=null){$t=$this->table($q);$rows=[];foreach($this->tables[$t]??[] as $r){if($this->matches($r,$q))$rows[]=$r;}return $rows;}
 function get_var($q){if(preg_match('/COUNT\(/i',$q)){return count($this->get_results($q,ARRAY_A));}return null;}
 function insert($t,$d,$f=null){$id=++$this->insert_id;$d['id']=$d['id']??$id;$this->tables[$t][]=$d;$this->insert_id=$d['id'];return 1;}
 function update($t,$d,$w,$f=null,$wf=null){$n=0;foreach($this->tables[$t]??[] as $i=>$r){$ok=true;foreach($w as $k=>$v){if((string)($r[$k]??'')!==(string)$v){$ok=false;break;}}if($ok){$this->tables[$t][$i]=array_merge($r,$d);$n++;}}return $n;}
}
$GLOBALS['wpdb']=new MemDB;
$root=getenv('PPAR_TEST_PLUGIN_DIR')?:'/mnt/data/final624_extract/affiliate-portal-router'; require $root.'/pferdeportal-affiliate-router.php';
$r=Pferdeportal_Affiliate_Router::instance();$rc=new ReflectionClass($r);$fail=0;$assertions=0;function ck($ok,$m){global $fail,$assertions;$assertions++;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$fail++;}function inv($n,$a=[]){global $r,$rc;$m=$rc->getMethod($n);$m->setAccessible(true);return $m->invokeArgs($r,$a);}

function run_business_selection_orchestrator_v640($settings,$reason){
  $state=inv('ebay_selection_request',[$reason,'test:legacy-rebalance-migrated',true,'business']);
  $ticks=0;
  while(is_array($state)&&in_array(sanitize_key((string)($state['status']??'')),['pending','preparing','running'],true)&&$ticks<500){
    $state=inv('ebay_selection_process_tick',[$settings,$state]);
    $ticks++;
  }
  $stats=(array)($state['stats']['business']??[]);
  $stats['selection_status']=(string)($state['status']??'');
  $stats['selection_ticks']=$ticks;
  return $stats;
}


$catalog=json_decode(file_get_contents($root.'/assets/ebay-portal-catalog-v2.json'),true);
// Complete configuration so the gap-fill can be queued in this local harness.
$GLOBALS['options']['ppar_network_ebay_v1']=array_merge($GLOBALS['options']['ppar_network_ebay_v1'],['enabled'=>1,'environment'=>'sandbox','private_enabled'=>0,'business_enabled'=>1,'api_terms_confirmed'=>1,'privacy_policy_confirmed'=>1,'catalog_verified_at'=>time(),'catalog_verified_sha256'=>(string)($catalog['source_sha256']??''),'rules'=>(array)($catalog['search_rules']??[]),'private_listing_author_id'=>1]);
$pid=100;foreach($catalog['product_targets'] as $target){$slug=sanitize_title($target['slug']??'');if($slug==='')continue;$p=new WP_Post(['ID'=>++$pid,'post_type'=>'page','post_status'=>'publish','post_name'=>$slug,'post_title'=>$target['product_title']??$slug,'post_parent'=>0]);$GLOBALS['pages'][$p->ID]=$p;$GLOBALS['page_context'][$p->ID]='leaf';}
$settings=inv('ebay_normalize_settings',[array_merge(inv('ebay_settings_defaults'),[
 'enabled'=>1,'environment'=>'production','client_id'=>'c','client_secret'=>'s','epn_campaign_id'=>'1234567890','marketplace_id'=>'EBAY_DE','delivery_country'=>'DE','private_enabled'=>false,'business_enabled'=>true,
 'business_active_cap'=>300,'business_candidate_pool_per_concept'=>10,'business_reserve_per_concept'=>2,'business_min_feedback_percentage'=>99.0,'business_min_feedback_score'=>100,
]),true]);
$profiles=inv('ebay_sync_profiles',[$settings]);
function pkey619($profiles,$cid){foreach($profiles as $k=>$p){if(($p['seller_type']??'')==='BUSINESS'&&($p['expected_business_concept_id']??'')===$cid)return $k;}return '';}
function raw619($id,$title,$cat,$aspect,$seller='seller-good',$pct=99.8,$score=1200){return ['itemId'=>$id,'seller'=>['sellerAccountType'=>'BUSINESS','username'=>$seller,'feedbackPercentage'=>$pct,'feedbackScore'=>$score],'listingMarketplaceId'=>'EBAY_DE','buyingOptions'=>['FIXED_PRICE'],'itemAffiliateWebUrl'=>'https://www.ebay.de/itm/'.$id.'?campid=1','itemWebUrl'=>'https://www.ebay.de/itm/'.$id,'image'=>['imageUrl'=>'https://i.ebayimg.com/images/g/'.$id.'/s-l1600.jpg'],'title'=>$title,'price'=>['value'=>'79.90','currency'=>'EUR'],'categories'=>[['categoryId'=>'1','categoryName'=>$cat]],'localizedAspects'=>[['name'=>'Produktart','value'=>$aspect],['name'=>'Marke','value'=>'TestMarke']], 'returnTerms'=>['returnsAccepted'=>true], 'shippingOptions'=>[['shippingCost'=>['value'=>'0.00','currency'=>'EUR']]], 'itemCreationDate'=>date('c',time()-86400*5),'itemEndDate'=>date('c',time()+86400*30)];}
$sum=inv('ebay_sync_summary_new',[$settings,'run-v619',$profiles]);
$job=['profiles'=>$profiles,'summary'=>$sum,'routed_items'=>[],'hard_seen'=>[],'technical_valid'=>[],'manual_veto_seen'=>[],'soft_pending'=>[],'unique_received'=>[],'run_uuid'=>'run-v619','business_concept_accept_counts'=>[]];
$proc=$rc->getMethod('ebay_sync_process_item');$proc->setAccessible(true);
$positives=[
 ['CTRL-GLOVE','concept-reithandschuhe','Roeckl Reithandschuhe Damen Leder','Reithandschuhe','Reithandschuhe','reithandschuhe'],
 ['HELM','concept-reithelme','Uvex Exxential III Reithelm Größe 57','Reithelme','Reithelm','reithelme'],
 ['BOOT','concept-reitstiefel','Ariat Heritage Contour II Reitstiefel Damen Leder','Reitstiefel','Reitstiefel','reitstiefel'],
 ['BIT','concept-gebisse','Sprenger Wassertrense Gebiss Edelstahl 14 mm','Gebisse & Trensen','Gebiss','gebisse'],
 ['FENCE','concept-weidezaungerate','AKO Weidezaungerät 12V Duo Power','Weidezaun','Weidezaungeräte','weidezaungeraete'],
 ['RUG','concept-regendecken','Horseware Amigo Regendecke 0g wasserdicht','Pferdedecken','Regendecken','pferdedecken-regendecken'],
 ['FEED','concept-futterautomaten','Kerbl Futterautomat 12 Liter','Fütterung','Futterautomaten','futterautomaten'],
 ['MIN','concept-mineralfutter-fur-pferde','Agrobs Mineralfutter für Pferde Naturmineral 10 kg','Pferdefutter','Mineralfutter für Pferde','mineralfutter-fuer-pferde'],
 ['STALL','concept-boxenmatten','Pferdebox Boxenmatten Gummimatten Stall 18 mm','Pferdestall','Boxenmatten','boxenmatten'],
 ['HEALTH','concept-fliegensprays','Fliegenspray Pferd Insektenschutz 1 Liter','Pferdepflege','Fliegensprays','fliegensprays'],
 ['TRAIN','concept-cavaletti','Cavaletti Pferd Training Kunststoff Set','Reitsport Training','Cavaletti','cavaletti'],
 ['TRANS','concept-anhangerbeleuchtung','Anhängerbeleuchtung Pferdeanhänger LED Set','Pferdeanhänger Zubehör','Anhängerbeleuchtung','anhaengerbeleuchtung'],
];
foreach($positives as $idx=>[$id,$cid,$title,$cat,$aspect,$slug]){$key=pkey619($profiles,$cid);ck($key!=='',"$id exact discovery profile exists");if($key==='')continue;$proc->invokeArgs($r,[&$job,raw619($id,$title,$cat,$aspect,'seller-'.$id),$key,$settings]);ck(($job['routed_items'][$id]??'')==='business_affiliate',"$id raw Browse item is accepted into deferred BUSINESS candidate route");}
ck(count(get_posts(['post_type'=>'ap_campaign']))===0,'BUSINESS sync does not first-seen materialize before quality rebalance');
// Negatives through the same raw Browse processing path.
$neg=[
 ['NEG-SPAR','concept-reitstiefel','XXL Spardose Pferdesattel und Reitstiefel','Reitstiefel','Reitstiefel'],
 ['NEG-STICK','concept-reitstiefel','Alter Aufkleber Reitsport Pferdesport Ausrüstung Reitstiefel','Reitstiefel','Reitstiefel'],
 ['NEG-HELM','concept-reithelme','Helmtasche passend für Reithelm','Reithelme','Reithelm'],
 ['NEG-DOG','concept-regendecken','Hund Regendecke wasserdicht','Hundebekleidung','Regendecke'],
 ['NEG-TOY','concept-reithelme','PLAYMOBIL Reithelm Spielzeug Kinder','Spielzeug','Reithelm'],
 ['NEG-SELLER','concept-reithelme','Reithelm Größe 57','Reithelme','Reithelm'],
];
foreach($neg as [$id,$cid,$title,$cat,$aspect]){$key=pkey619($profiles,$cid);ck($key!=='',"$id profile exists");if($key==='')continue;$raw=raw619($id,$title,$cat,$aspect,'seller-'.$id,$id==='NEG-SELLER'?98.5:99.8,$id==='NEG-SELLER'?5000:1200);$proc->invokeArgs($r,[&$job,$raw,$key,$settings]);ck(($job['routed_items'][$id]??'')!=='business_affiliate',"$id is fail-closed before BUSINESS candidate selection");}
$stats=run_business_selection_orchestrator_v640($settings,'full_chain_v619');
ck(absint($stats['active']??0)===count($positives),'Final quality rebalance selects every valid representative positive in this matrix');
ck(absint($stats['materialized']??0)===count($positives),'Final quality rebalance materializes the valid BUSINESS winners');
$campaigns=get_posts(['post_type'=>'ap_campaign']);ck(count($campaigns)===count($positives),'Exactly the positive matrix becomes real BUSINESS campaigns');
foreach($positives as [$id,$cid,$title,$cat,$aspect,$slug]){
 $found=null;foreach($campaigns as $p){$c=get_post_meta($p->ID,'ppar_campaign_data',true);if(($c['external_id']??'')===$id){$found=['post'=>$p,'campaign'=>$c];break;}}
 ck(is_array($found),"$id real campaign persisted after selection");if(!$found)continue;
 ck(!empty($found['campaign']['active']),"$id persisted campaign is active");
 ck(in_array('page:'.$slug,$found['campaign']['automation_target_keys']??[],true),"$id campaign contains exact target page:$slug");
 $context=['primary_slug'=>$slug,'post_type'=>'page','post_id'=>1,'slugs'=>[$slug],'names'=>[$title],'haystack'=>$title,'ancestor_ids'=>[],'term_ids'=>[],'direct_term_slugs'=>[]];
 $ranked=inv('ranked_campaigns_for_slot',[$context,'category_product_1']);$hit=false;foreach($ranked as $x){if((int)($x['campaign']['post_id']??0)===(int)$found['post']->ID){$hit=true;break;}}
 ck($hit,"$id unchanged public router can deliver selected campaign on exact page");
}

// Main-hub coverage: campaigns derived from descendant product concepts must remain routable on all major portal hubs.
$hubExpected=['ausruestung','stall','weide','fuetterung','gesundheit','training','transport'];
foreach($hubExpected as $hub){
 $context=['primary_slug'=>$hub,'post_type'=>'page','post_id'=>1,'slugs'=>[$hub],'names'=>[$hub],'haystack'=>$hub,'ancestor_ids'=>[],'term_ids'=>[],'direct_term_slugs'=>[]];
 $ranked=inv('ranked_campaigns_for_slot',[$context,'hub_product_1']);
 ck(count($ranked)>=1,'Main hub '.$hub.' receives at least one verified BUSINESS product from descendant concepts');
}

$ebayRows=$GLOBALS['wpdb']->tables['wp_ppar_ebay_items']??[];$ready=0;$badPublic=0;foreach($ebayRows as $row){if(($row['seller_account_type']??'')!=='BUSINESS')continue;if(($row['route_state']??'')==='ready'&&($row['output_state']??'')==='creative_ready')$ready++;if(str_starts_with((string)($row['item_id']??''),'NEG-')&&($row['output_state']??'')==='creative_ready')$badPublic++;}
ck($ready===count($positives),'All positives finish source route_state=ready/output_state=creative_ready');
ck($badPublic===0,'No negative fixture reaches creative_ready/public state');

// Controlled-rebuild contract: the provider page is strictly read-only. Gap
// detection is computed by the background planner, and a targeted
// business_recovery job queries only missing physical concepts. The old V6.32
// expectation that provider-page ticks mutate/restore inventory is deliberately
// forbidden because that browser coupling caused the V6.40 timeout/loop family.
$plan=inv('ebay_business_selection_plan',[$settings]);
$coverage=inv('ebay_business_selection_coverage',[$plan]);
$missing=absint($coverage['missing']??0);$covered=absint($coverage['covered']??0);$required=absint($coverage['required']??0);
ck($required===311,'Coverage contract requires all 311 physical BUSINESS product concepts');
ck($covered===count($positives),'The locally stored product families are counted as covered, not mistaken for full portal supply');
ck($missing===311-count($positives),'Every absent physical product family is explicitly counted as a gap');

// Add one PRIVATE sentinel and route the historical browser-recovery test
// through the real scoped Selection-State-Machine. Request creation may mutate
// only the canonical selection state; it must not directly mutate source rows,
// BUSINESS campaigns or PRIVATE listings.
$GLOBALS['wpdb']->tables['wp_ppar_ebay_items'][]=['id'=>9999,'item_id'=>'PRIVATE-SENTINEL','seller_account_type'=>'INDIVIDUAL','source_state'=>'available','policy_state'=>'allowed','route_state'=>'ready','output_state'=>'listing_ready','title'=>'Reithelm privat','source_payload'=>'{}'];
$beforeRows=serialize($GLOBALS['wpdb']->tables['wp_ppar_ebay_items']);$beforePosts=serialize($GLOBALS['posts']);$beforeSelectionState=get_option(Pferdeportal_Affiliate_Router::OPTION_EBAY_SELECTION_STATE,[]);
$selectionRequest=inv('ebay_selection_request',['gapfill-canonical-selection','test:gapfill',true,'business']);
ck(($selectionRequest['status']??'')==='pending'&&($selectionRequest['selection_scope']??'')==='business','Historical browser recovery path is replaced by a real scoped BUSINESS Selection-State-Machine request');
ck(serialize($GLOBALS['wpdb']->tables['wp_ppar_ebay_items'])===$beforeRows,'Canonical selection request does not directly mutate eBay source rows');
ck(serialize($GLOBALS['posts'])===$beforePosts,'Canonical selection request does not directly mutate BUSINESS campaigns or PRIVATE listings');
$sentinelBeforeWorker=null;foreach($GLOBALS['wpdb']->tables['wp_ppar_ebay_items'] as $row){if(($row['item_id']??'')==='PRIVATE-SENTINEL'){$sentinelBeforeWorker=$row;break;}}
ck(($sentinelBeforeWorker['output_state']??'')==='listing_ready','BUSINESS-scoped canonical request leaves PRIVATE sentinel untouched before worker execution');
// Restore the pre-check terminal selection snapshot so the following independent
// background gap-fill scenario starts from the same lifecycle precondition as before.
update_option(Pferdeportal_Affiliate_Router::OPTION_EBAY_SELECTION_STATE,$beforeSelectionState,false);

// Background gap-fill is explicit and BUSINESS-only. Queuing it must preserve
// existing public campaigns while requesting exactly the currently missing
// product concepts.
$queued=inv('ebay_start_sync_job',[false,'business_recovery','background']);
ck(!is_wp_error($queued)&&in_array(sanitize_key((string)($queued['status']??'')),['queued','already_running'],true),'Missing BUSINESS coverage can queue a background gap-fill');
$sj=get_option(Pferdeportal_Affiliate_Router::OPTION_EBAY_SYNC_JOB,[]);ck(sanitize_key((string)($sj['scope']??''))==='business_recovery','Gap-fill job is BUSINESS-only');
$privateProfiles=array_filter((array)($sj['profiles']??[]),fn($x)=>strtoupper((string)($x['seller_type']??''))==='INDIVIDUAL');ck(count($privateProfiles)===0,'BUSINESS gap-fill contains zero PRIVATE profiles');
$productExact=array_filter((array)($sj['profiles']??[]),fn($x)=>sanitize_key((string)($x['profile_kind']??''))==='business_product_concept');$hubExact=array_filter((array)($sj['profiles']??[]),fn($x)=>sanitize_key((string)($x['profile_kind']??''))==='business_hub_concept');ck(count($productExact)===$missing&&count($hubExact)===0,'BUSINESS gap-fill queries exactly the missing physical product concepts instead of rescanning the whole catalog');
$activeEbay=0;foreach(get_posts(['post_type'=>'ap_campaign']) as $p){$c=get_post_meta($p->ID,'ppar_campaign_data',true);if(($c['network']??'')==='ebay'&&!empty($c['active']))$activeEbay++;}ck($activeEbay>=count($positives),'Existing valid BUSINESS campaigns remain public while missing concepts are merely queued');
$sentinel=null;foreach($GLOBALS['wpdb']->tables['wp_ppar_ebay_items'] as $row){if(($row['item_id']??'')==='PRIVATE-SENTINEL'){$sentinel=$row;break;}}ck(($sentinel['output_state']??'')==='listing_ready','BUSINESS gap-fill leaves PRIVATE sentinel untouched');
echo "ASSERTIONS=$assertions FAIL=$fail COVERED=$covered MISSING=$missing\n";exit($fail?1:0);
