<?php
/*
 * HivePress container-runtime contract test for V6.15.
 * Contract source verified against official hivepress/hivepress commit
 * 88530e366db319b157641540d6bc94d28f0cc254:
 * - includes/blocks/class-block.php: constructor applies hivepress/v1/blocks/{type}
 *   before setting properties.
 * - includes/blocks/class-container.php: child blocks receive the same context and
 *   are instantiated only after the container properties filter has run.
 * This test deliberately does NOT use the old FakeHPTemplate/merge_blocks path.
 */
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A');
class WP_Error{private $c,$m;function __construct($c,$m){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}
$GLOBALS['filters']=[];$GLOBALS['meta']=[];$GLOBALS['thumbs']=[];$GLOBALS['source_rows']=[];$GLOBALS['source_queries']=0;$GLOBALS['meta_writes']=0;
function add_filter($tag,$cb,$priority=10,$accepted=1){$GLOBALS['filters'][$tag][$priority][]=[$cb,$accepted];return true;}
function apply_filters($tag,$value,...$args){if(empty($GLOBALS['filters'][$tag]))return $value;ksort($GLOBALS['filters'][$tag]);foreach($GLOBALS['filters'][$tag] as $cbs){foreach($cbs as [$cb,$accepted]){$params=array_merge([$value],$args);$value=call_user_func_array($cb,array_slice($params,0,$accepted));}}return $value;}
function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));} function sanitize_title($v){return sanitize_key($v);} function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_textarea_field($v){return trim(strip_tags((string)$v));} function wp_strip_all_tags($v){return strip_tags($v);} function remove_accents($v){return $v;} function esc_url_raw($v){return trim((string)$v);} function esc_url($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function esc_attr($v){return htmlspecialchars((string)$v,ENT_QUOTES);} function get_permalink($id){return 'https://portal.test/listing/'.$id.'/';} function get_option($k,$d=null){return $d;} function get_the_title($id){return 'Listing '.$id;} function wp_json_encode($v,$o=0){return json_encode($v,$o);}
function get_post_meta($id,$k,$single=true){return $GLOBALS['meta'][$id][$k]??'';} function update_post_meta($id,$k,$v){$GLOBALS['meta_writes']++;$GLOBALS['meta'][$id][$k]=$v;return true;} function get_post_thumbnail_id($id){return (int)($GLOBALS['thumbs'][$id]??0);}
class FakeWpdb{public $prefix='wp_';function prepare($q,...$a){return $q;}function get_results($q,$mode){$GLOBALS['source_queries']++;return array_values($GLOBALS['source_rows']);}}
$GLOBALS['wpdb']=new FakeWpdb();
class HPRouter{function get_url($r,$a){return 'https://portal.test/hp/'.$a['listing_id'].'/';}} class HPAsset{function get_aspect_ratio($x){return $x==='landscape_small'?'4/3':'16/9';}}
$GLOBALS['hp']=(object)['router'=>new HPRouter(),'asset'=>new HPAsset()]; function hivepress(){return $GLOBALS['hp'];}
class ListingX{function __construct(private $id,private $title='Listing'){}function get_id(){return $this->id;}function get_title(){return $this->title;}}

/* Exact relevant HivePress runtime shape: filter Container props first, then instantiate child tree with inherited context. */
class HPContractContainer{
    private $args;
    function __construct($args){$this->args=apply_filters('hivepress/v1/blocks/container',$args,$this);}
    private function renderTree($tree,$context){$out='';foreach($tree as $name=>$args){if(!is_array($args))continue;$type=$args['type']??'container';if($type==='content'){$out.=(string)($args['content']??'');}elseif($type==='container'){$child=$args;$child['context']=$context;$out.=(new self($child))->render();}elseif($type==='part'){$out.='[PART:'.($args['path']??'').']';}else{if(isset($args['blocks'])){$child=$args;$child['context']=$context;$out.=(new self($child))->render();}}}return $out;}
    function render(){return $this->renderTree((array)($this->args['blocks']??[]),(array)($this->args['context']??[]));}
    function args(){return $this->args;}
}

$root=getenv('PPAR_TEST_PLUGIN_DIR')?:'/mnt/data/final624_extract/affiliate-portal-router';require $root.'/includes/trait-ppar-ebay.php';
class T{use PPAR_Ebay_Trait;const OPTION_NETWORK_EBAY='x',OPTION_EBAY_CONTENT_FILTER_STATE='y',OPTION_EBAY_BUSINESS_MATCH_STATE='z',OPTION_EBAY_MAINTENANCE_STATE='m',OPTION_EBAY_SCHEMA_VERSION='a',OPTION_EBAY_MEDIA_CLEANUP_STATE='cleanup',EBAY_SCHEMA_VERSION='2.0',EBAY_CONTENT_POLICY_VERSION='6.0',EBAY_PRIVATE_CLASSIFIER_VERSION='4.0',EBAY_BUSINESS_CLASSIFIER_VERSION='5.0',EBAY_MAINTENANCE_CRON_HOOK='mm',EBAY_MEDIA_CLEANUP_HOOK='mc',EBAY_MEDIA_CLEANUP_VERSION='1.0',EBAY_CRON_HOOK='c',EBAY_WORKER_HOOK='w',EBAY_REFRESH_CRON_HOOK='r',EBAY_REFRESH_WORKER_HOOK='rw',EBAY_RUNTIME_BUILD='v615';}
$t=new T; add_filter('hivepress/v1/blocks/container',[$t,'ebay_remote_image_container_blocks'],1000,2);
$n=0;$f=0;function ck615($ok,$m){global $n,$f;$n++;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$f++;}

// Exact live recovery shape: eBay PRIVATE listing, old media deleted, no remote meta, durable source row remains.
$GLOBALS['meta'][501]=['_ppar_ebay_item_id'=>'ITEM-A','_ppar_ebay_seller_type'=>'INDIVIDUAL'];
$GLOBALS['source_rows']=[['id'=>10,'item_id'=>'ITEM-A','seller_account_type'=>'INDIVIDUAL','listing_post_id'=>501,'image_url'=>'https://i.ebayimg.com/images/g/a/s-l1600.jpg','source_state'=>'available','policy_state'=>'allowed']];
$listing=new ListingX(501,'Reithelm');
$cardTree=['listing_container'=>['type'=>'container','blocks'=>['listing_header'=>['type'=>'container','blocks'=>['listing_image'=>['type'=>'part','path'=>'listing/view/block/listing-image','_order'=>20]]]]]];
$html=(new HPContractContainer(['context'=>['listing'=>$listing],'blocks'=>$cardTree]))->render();
ck615(strpos($html,'https://i.ebayimg.com/images/g/a/s-l1600.jpg')!==false,'Saved/default HivePress Container path renders recovered remote PRIVATE image');
ck615(strpos($html,'[PART:listing/view/block/listing-image]')===false,'Native image part is replaced before child Part instantiation');
ck615($GLOBALS['source_queries']===1,'Remote fallback performs one bounded source lookup on first card render');
ck615($GLOBALS['meta_writes']===0,'Container render performs zero frontend meta writes');

// Re-render: request-local source cache must prevent per-card SQL.
$html2=(new HPContractContainer(['context'=>['listing'=>$listing],'blocks'=>$cardTree]))->render();
ck615(strpos($html2,'i.ebayimg.com')!==false && $GLOBALS['source_queries']===1,'Second render reuses request-local source cache');

// Single page canonical listing_images block.
$pageTree=['page_content'=>['type'=>'container','blocks'=>['listing_images'=>['type'=>'part','path'=>'listing/view/page/listing-images','_order'=>40]]]];
$page=(new HPContractContainer(['context'=>['listing'=>$listing],'blocks'=>$pageTree]))->render();
ck615(strpos($page,'ppar-ebay-remote-images')!==false && strpos($page,'i.ebayimg.com')!==false,'HivePress single-page Container path renders remote image');

// Editor/saved-template-like wrapper: class-specific Listing_View_* filter is intentionally not called.
$customTree=['custom_wrapper'=>['type'=>'container','blocks'=>['custom_inner'=>['type'=>'container','blocks'=>['listing_image'=>['type'=>'part','path'=>'listing/view/block/listing-image']]]]]];
$custom=(new HPContractContainer(['context'=>['listing'=>$listing],'blocks'=>$customTree]))->render();
ck615(strpos($custom,'i.ebayimg.com')!==false,'Saved hp_template-like nested Container path is covered without template-class filter');

// Normal HivePress listing remains native.
$GLOBALS['meta'][777]=[];$normal=new ListingX(777,'Normal');
$normalHtml=(new HPContractContainer(['context'=>['listing'=>$normal],'blocks'=>$cardTree]))->render();
ck615(strpos($normalHtml,'[PART:listing/view/block/listing-image]')!==false,'Normal HivePress listing remains on native image Part');
ck615(strpos($normalHtml,'ppar-ebay-remote-image')===false,'Normal listing receives no eBay remote markup');

// eBay marker with non-PRIVATE seller meta is not modified.
$GLOBALS['meta'][778]=['_ppar_ebay_item_id'=>'BUS-1','_ppar_ebay_seller_type'=>'BUSINESS'];$business=new ListingX(778,'Business');
$businessHtml=(new HPContractContainer(['context'=>['listing'=>$business],'blocks'=>$cardTree]))->render();
ck615(strpos($businessHtml,'[PART:listing/view/block/listing-image]')!==false,'BUSINESS marker can never activate PRIVATE HivePress renderer');

// Invalid host: fail closed, native part stays instead of injecting hostile URL.
$GLOBALS['meta'][779]=['_ppar_ebay_item_id'=>'ITEM-X','_ppar_ebay_seller_type'=>'INDIVIDUAL'];
$GLOBALS['source_rows']=[['id'=>11,'item_id'=>'ITEM-X','seller_account_type'=>'INDIVIDUAL','listing_post_id'=>779,'image_url'=>'https://ebayimg.com.evil.example/x.jpg','source_state'=>'available','policy_state'=>'allowed']];
$bad=(new HPContractContainer(['context'=>['listing'=>new ListingX(779,'Bad')],'blocks'=>$cardTree]))->render();
ck615(strpos($bad,'evil.example')===false && strpos($bad,'[PART:listing/view/block/listing-image]')!==false,'Lookalike image host is rejected and native fallback remains');

echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
