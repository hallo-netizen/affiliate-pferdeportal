<?php
define('ABSPATH','/tmp/'); define('HOUR_IN_SECONDS',3600); define('ARRAY_A','ARRAY_A');
class WP_Error{private $c,$m;function __construct($c,$m){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}
function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_title($v){$v=strtolower(strtr((string)$v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']));return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_textarea_field($v){return trim(strip_tags((string)$v));}
function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return strtr((string)$v,['ä'=>'a','ö'=>'o','ü'=>'u','Ä'=>'A','Ö'=>'O','Ü'=>'U','ß'=>'ss']);}
function wp_json_encode($v,$o=0){return json_encode($v,$o);} function esc_url_raw($v){return $v;} function wp_http_validate_url($v){return true;}
$root=getenv('PPAR_TEST_PLUGIN_DIR')?:'/mnt/data/final624_extract/affiliate-portal-router'; require $root.'/includes/trait-ppar-ebay.php';
class T{use PPAR_Ebay_Trait; const OPTION_NETWORK_EBAY='x',OPTION_EBAY_CONTENT_FILTER_STATE='y',OPTION_EBAY_BUSINESS_MATCH_STATE='z',OPTION_EBAY_MAINTENANCE_STATE='m',OPTION_EBAY_SCHEMA_VERSION='a',EBAY_SCHEMA_VERSION='2.0',EBAY_CONTENT_POLICY_VERSION='4.0',EBAY_PRIVATE_CLASSIFIER_VERSION='3.0',EBAY_BUSINESS_CLASSIFIER_VERSION='4.0',EBAY_MAINTENANCE_CRON_HOOK='mm',EBAY_CRON_HOOK='c',EBAY_WORKER_HOOK='w',EBAY_REFRESH_CRON_HOOK='r',EBAY_REFRESH_WORKER_HOOK='rw',EBAY_RUNTIME_BUILD='b'; private function output_local_portal_key(){return 'local';}}
$t=new T;$rc=new ReflectionClass($t);$fail=0;$assertions=0;
function inv660($n,$a=[]){global $t,$rc;$m=$rc->getMethod($n);$m->setAccessible(true);return $m->invokeArgs($t,$a);} 
function ck660($ok,$m){global $fail,$assertions;$assertions++; echo($ok?'PASS ':'FAIL ').$m."\n"; if(!$ok)$fail++;}
function item660($title,$category='Reitsport',$aspect='Pferd',$description=''){return ['title'=>$title,'short_description'=>$description,'category_names'=>[$category],'raw'=>['title'=>$title,'shortDescription'=>$description,'categories'=>[['categoryName'=>$category]],'localizedAspects'=>[['name'=>'Produktart','value'=>$aspect]]]];}
$catalog=json_decode(file_get_contents($root.'/assets/ebay-portal-catalog-v2.json'),true); $concepts=(array)$catalog['business_concepts'];
$all=0;$allok=0;$one=0;$oneok=0;$accessoryok=0;$details=[];
foreach($concepts as $c){
    $all++;
    $title=(string)$c['title'];
    $r=inv660('ebay_business_classify_portal_item_strict',[item660($title.' Pferd'),[]]);
    if(!is_wp_error($r) && ($r['product_concept_id']??'')===($c['id']??'')){$allok++;} else {$details[]='GENERIC '.($c['id']??'?').' => '.(is_wp_error($r)?$r->get_error_code():($r['product_concept_id']??'wrong'));}
    $tokens=inv660('ebay_business_distinctive_tokens',[$title]);
    if(count($tokens)!==1){continue;}
    $one++;
    $token=(string)$tokens[0];
    $direct=inv660('ebay_business_classify_portal_item_strict',[item660($title.' Pferd'),[]]);
    if(!is_wp_error($direct) && ($direct['product_concept_id']??'')===($c['id']??'')){$oneok++;}
    $acc=inv660('ebay_business_classify_portal_item_strict',[item660('Ersatzhalter passend für '.$title.' Pferd','Reitsport','Ersatzteil'),[]]);
    if(is_wp_error($acc) || ($acc['product_concept_id']??'')!==($c['id']??'')){$accessoryok++;} else {$details[]='ACCESSORY FALSE POSITIVE '.($c['id']??'?');}
}
ck660($all===316,'Katalog besitzt weiterhin exakt 316 BUSINESS-Leaf-Konzepte');
ck660($allok===$all,"Alle 316 Konzepte self-classify bei eindeutigem Produkttitel + generischem Reitsportkontext ($allok/$all)");
ck660($one===209,'Exakt 209 Leaf-Konzepte fallen unter den bisherigen Ein-Wort-Sondervertrag');
ck660($oneok===$one,"Alle 209 Ein-Wort-Konzepte werden bei direktem primaerem Titelbegriff automatisch zugeordnet ($oneok/$one)");
ck660($accessoryok===$one,"Alle 209 relationalen Zubehoernennungen hinter 'passend fuer' bleiben ohne Produkt-Corroboration fail-closed ($accessoryok/$one)");
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Roeckl Lisboa Reithandschuhe Damen Leder','Reitsport','Handschuhe'),[]]);
ck660(!is_wp_error($r) && ($r['product_concept_id']??'')==='concept-reithandschuhe','Live-Beispiel: eindeutige Reithandschuhe brauchen keine zweite produktgleiche eBay-Kategorie');
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Roeckl Lisboa Reithandschuh Damen Leder','Reitsport','Handschuhe'),[]]);
ck660(!is_wp_error($r) && ($r['product_concept_id']??'')==='concept-reithandschuhe','Reithandschuh Singular routet auf Reithandschuhe');
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Fliegenmaske Pferd UV Schutz','Reitsport','Maske'),[]]);
ck660(!is_wp_error($r) && ($r['product_concept_id']??'')==='concept-fliegenmasken','Fliegenmaske Singular routet auf Fliegenmasken');
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Reithelm Pferd Sicherheitshelm','Reitsport','Helm'),[]]);
ck660(!is_wp_error($r) && ($r['product_concept_id']??'')==='concept-reithelme','Reithelm Singular routet auf Reithelme');
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Sattelgurt Pferd Leder 125 cm','Reitsport','Gurt'),[]]);
ck660(!is_wp_error($r) && ($r['product_concept_id']??'')==='concept-sattelgurte','Sattelgurt Singular routet auf Sattelgurte');
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Panik-Haken Edelstahl passend für Führstrick Pferd','Reitsport','Karabiner'),[]]);
ck660(is_wp_error($r),'Negativ: Panik-Haken fuer Fuehrstrick wird nicht zum Fuehrstrick-Produkt umgedeutet');
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Helmtasche passend für Reithelm Pferd','Reitsport','Tasche'),[]]);
ck660(is_wp_error($r),'Negativ: Helmtasche fuer Reithelm wird nicht zum Reithelm umgedeutet');
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Fliegenmaske und Reithelm Pferd','Reitsport','Pferd'),[]]);
ck660(is_wp_error($r) && $r->get_error_code()==='ebay_business_concept_ambiguous','Negativ: zwei gleich plausible primaere Produktkonzepte bleiben Review');
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Playmobil Reithandschuhe Pferd','Reitsport','Pferd'),[]]);
ck660(is_wp_error($r) && $r->get_error_code()==='ebay_content_policy_blocked','Negativ: zentrale Spielzeugpolicy hat Vorrang vor eindeutigem Produkttitel');
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Reithandschuhe Damen Leder','Mode','Handschuhe'),[]]);
ck660(!is_wp_error($r) && ($r['product_concept_id']??'')==='concept-reithandschuhe','Eindeutiger Reit-Produktbegriff traegt den Pferde-/Reitsportkontext selbst');
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Uvex Fahrradhelm City','Fahrradhelme','Helm'),[]]);
ck660(is_wp_error($r) && $r->get_error_code()==='ebay_portal_topic_negative','Negativ: fachfremder Fahrradhelm bleibt durch Hard-Negative fail-closed');
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Roeckl Handschuhe Damen','Reitsport','Handschuhe','Premium Reithandschuhe für Damen'),[]]);
ck660(is_wp_error($r),'Negativ: Description allein darf weiterhin kein Leaf-Konzept erzeugen');

// V6.40 real-world root-cause cases: editorial portal context must not become
// a mandatory marketplace title token. Exact discovery profile supplies only
// domain scope after the offer itself proves the product identity.
function concept660($id){global $concepts;foreach($concepts as $c){if(($c['id']??'')===$id)return $c;}return null;}
foreach([
 ['concept-reitstiefel','Reitstiefel Leder Damen Größe 39','Reitsport','Reitstiefel','Reitstiefel'],
 ['concept-kameras-im-stall','4G Überwachungskamera LTE Outdoor','Überwachungskameras','Kamera','Kameras im Stall Pferd'],
 ['concept-desinfektionsmittel-fur-stall','Desinfektionsmittel Konzentrat 1 Liter','Desinfektion','Desinfektionsmittel','Desinfektionsmittel für Stall Pferd'],
] as [$cid,$title,$cat,$ptype,$expectedQuery]){
 $c=concept660($cid); ck660(is_array($c),'Rootcase catalog concept exists '.$cid); if(!is_array($c))continue;
 $q=inv660('ebay_business_concept_query',[$c]); ck660($q===$expectedQuery,'Rootcase discovery query uses product identity for '.$cid.' => '.$q);
 $rule=['business_concept_id'=>$cid,'query'=>$q];
 $r=inv660('ebay_business_classify_portal_item_strict',[item660($title,$cat,$ptype),$rule]);
 ck660(!is_wp_error($r) && ($r['product_concept_id']??'')===$cid,'Rootcase real marketplace title classifies '.$cid);
}
$r=inv660('ebay_business_classify_portal_item_strict',[item660('Playmobil Pferdestall Kamera Spielset','Spielzeug','Spielzeug'),['business_concept_id'=>'concept-kameras-im-stall','query'=>'Kameras im Stall Pferd']]);
ck660(is_wp_error($r) && $r->get_error_code()==='ebay_content_policy_blocked','Rootcase negative: toy camera cannot pass exact profile');
if($details){foreach(array_slice($details,0,40) as $d)echo "DETAIL $d\n";if(count($details)>40)echo 'DETAIL ... '.(count($details)-40)." more\n";}
echo "ASSERTIONS=$assertions FAIL=$fail\n"; exit($fail?1:0);
