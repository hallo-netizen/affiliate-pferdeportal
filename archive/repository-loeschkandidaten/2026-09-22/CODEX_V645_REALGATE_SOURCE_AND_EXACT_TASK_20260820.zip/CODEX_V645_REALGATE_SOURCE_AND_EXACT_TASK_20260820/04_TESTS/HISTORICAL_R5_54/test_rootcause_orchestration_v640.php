<?php
$root=getenv('PPAR_TEST_PLUGIN_DIR');$f=file_get_contents($root.'/includes/trait-ppar-ebay.php');$run=file_get_contents($root.'/includes/trait-ppar-ebay-run.php');$main=file_get_contents($root.'/pferdeportal-affiliate-router.php');$fail=0;$n=0;
function ck($x,$m){global $fail,$n;$n++;echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$fail++;}
function block($s,$a,$b){$p=strpos($s,$a);if($p===false)return'';$q=strpos($s,$b,$p+strlen($a));return $q===false?substr($s,$p):substr($s,$p,$q-$p);}
$recover=block($f,'public function ensure_ebay_selection_recovery_schedule','Only the private eBay importer');
$profiles=block($f,'private function ebay_sync_profiles','private function ebay_sync_summary_new');
$manual=block($f,'public function handle_ebay_run_sync()','public function handle_ebay_worker_now()');
$runStart=block($run,'private function ebay_run_start','private function ebay_run_fail');
$gap=block($run,'private function ebay_run_tick_gapfill','private function ebay_run_tick_gapfill_select');
$gapSelect=block($run,'private function ebay_run_tick_gapfill_select','private function ebay_run_tick_public_verify');
$render=substr($f,strpos($f,'public function render_ebay_page()'),62000);
ck(strpos($recover,'ebay_selection_request(')===false,'Deprecated init recovery cannot start a selection');
ck(strpos($recover,'return $this->ebay_selection_state_load()')!==false,'Deprecated recovery method is read-only');
ck(strpos($main,"add_action(self::EBAY_WORKER_HOOK, array(\$this, 'run_ebay_canonical_worker'))")===false && substr_count($main,"add_action('wp_ajax_ppar_ebay_canonical_tick', array(\$this, 'handle_ebay_canonical_tick'))")===1,'Exactly one canonical authenticated admin-AJAX transport owns eBay orchestration');
ck(strpos($main,"add_action(self::EBAY_REFRESH_WORKER_HOOK")===false,'No second refresh worker hook is registered');
ck(strpos($main,"admin_post_ppar_ebay_worker_tick")===false && strpos($main,"admin_post_nopriv_ppar_ebay_worker_tick")===false,'Discovery self-HTTP endpoints are not registered');
ck(strpos($main,"admin_post_ppar_ebay_refresh_worker_tick")===false && strpos($main,"admin_post_nopriv_ppar_ebay_refresh_worker_tick")===false,'Refresh self-HTTP endpoints are not registered');
ck(strpos($manual,'run_ebay_sync(true)')!==false && strpos($manual,'run_ebay_sync_worker')===false && strpos($manual,'run_ebay_canonical_worker')===false,'Explicit Start only creates/continues the canonical run; no synchronous worker package');
ck(strpos($runStart,"'phase'=>'reconcile_local'")!==false && strpos($runStart,"'status'=>'running'")!==false,'New work always starts as one durable running run at reconcile_local');
ck(strpos($gap,"\$run['gapfill']['missing']")!==false && strpos($gap,"ebay_start_sync_job(false,'business_recovery','background')")!==false,'BUSINESS gap-fill consumes exactly the canonical missing-family set');
ck(strpos($gapSelect,"ebay_selection_request('canonical_gapfill'")!==false && strpos($gapSelect,"true,'business'")!==false,'Gap-fill selection is BUSINESS-only inside the same canonical run');
ck(strpos($profiles,"array('all','business_recovery')")!==false,'Discovery scopes exclude PRIVATE symptom-repair modes');
ck(strpos($f,'private_boot_recovery')===false,'PRIVATE boot-recovery runtime scope is removed');
ck(strpos($f,"ebay_start_reitstiefel_supply_repair_if_needed() {\n        // Deprecated symptom-repair path")!==false,'Reitstiefel special repair starter is inert');
ck(strpos($f,"ebay_start_private_enrichment_if_needed() {\n        // Deprecated symptom-repair path")!==false,'PRIVATE enrichment special starter is inert');
ck(strpos($render,'window.location.reload()')===false && strpos($f,'ppar_ebay_admin_pump')===false && strpos($render,"body.append('action','ppar_ebay_canonical_tick')")!==false,'Admin page has no legacy/reload worker loop and can only drive the canonical sequential transport');
ck(strpos($main,"ensure_ebay_selection_recovery_schedule'), 27")===false,'Old V6.22 init loop hook is absent');
ck(strpos($f,'private_public_cap_exceeded')!==false && strpos($f,"private_active_cap")!==false,'PRIVATE final verifier enforces configured cap and fails closed above it');
echo "ASSERTIONS=$n FAIL=$fail\n";exit($fail?1:0);
