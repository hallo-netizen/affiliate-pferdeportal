<?php
// Change 45 contract: one BUSINESS selection path only; selected role is durably
// committed on the source without overwriting the authoritative creative_ready
// public output state; commit failure must be fail-closed.
$root=getenv('PPAR_TEST_PLUGIN_DIR')?:'/mnt/data/final624_extract/affiliate-portal-router';
$src=file_get_contents($root.'/includes/trait-ppar-ebay.php');
$fail=0;$assertions=0;function ck($ok,$m){global $fail,$assertions;$assertions++;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$fail++;}
ck(strpos($src,'function handle_ebay_selection_worker_tick')===false,'Legacy authenticated selection-loopback method is physically absent');
ck(strpos($src,'function ebay_business_rebalance_inventory')===false,'Legacy one-shot BUSINESS rebalance method is physically absent');
ck(strpos($src,'function ebay_business_commit_selected_source_role')!==false,'Verified selected-source role commit exists as shared helper');
$applyPos=strpos($src,'private function ebay_selection_apply_business_batch');
$apply=$applyPos===false?'':substr($src,$applyPos,9000);
ck(strpos($apply,'ebay_business_commit_selected_source_role')!==false,'Real bounded BUSINESS materialization calls verified selected-source commit');
ck(strpos($apply,"'business_selection_commit_failed'")!==false,'Selected-source commit failure has explicit fail-closed error code/path');
$helperPos=strpos($src,'private function ebay_business_commit_selected_source_role');
$helper=$helperPos===false?'':substr($src,$helperPos,6000);
ck($helper!=='' && strpos($helper,"'output_state'=>'creative_ready'")===false,'Selected-role helper never writes output_state=active_selected or rewrites creative_ready');
ck($helper!=='' && strpos($helper,"'business_selection'")!==false && strpos($helper,"'active_selected'")!==false,'Selected-role helper durably stores active_selected inside source payload');
ck($helper!=='' && strpos($helper,'get_row')!==false && strpos($helper,'creative_ready')!==false,'Selected-role commit verifies persisted payload and preserved creative_ready state');
echo "ASSERTIONS=$assertions FAIL=$fail\n";exit($fail?1:0);
