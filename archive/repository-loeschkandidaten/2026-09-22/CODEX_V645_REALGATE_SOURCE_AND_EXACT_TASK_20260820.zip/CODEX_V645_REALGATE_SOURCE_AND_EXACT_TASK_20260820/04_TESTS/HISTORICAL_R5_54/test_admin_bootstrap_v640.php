<?php
// V6.40 hard contract after browser/BUSINESS recovery transport retirement:
// the six old controller roots are physically absent and admin/lifecycle work
// routes only through the canonical scoped Selection-State-Machine.
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A');
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return$this->c;}function get_error_message(){return$this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}
function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_text_field($v){return trim(strip_tags((string)$v));}
function absint($v){return abs((int)$v);} function wp_generate_password($l=48,$s=false,$e=false){return str_repeat('T',$l);} function apply_filters($a,$b){return$b;} function admin_url($p=''){return 'https://example.test/wp-admin/'.$p;}
$GLOBALS['opts']=[];$GLOBALS['cron']=[];$GLOBALS['loopbacks']=[];
function get_option($k,$d=false){return array_key_exists($k,$GLOBALS['opts'])?$GLOBALS['opts'][$k]:$d;} function update_option($k,$v,$a=false){$GLOBALS['opts'][$k]=$v;return true;}
function wp_next_scheduled($h){return $GLOBALS['cron'][$h]??false;} function wp_schedule_single_event($t,$h){$GLOBALS['cron'][$h]=$t;return true;} function wp_remote_post($u,$a){$GLOBALS['loopbacks'][]=[$u,$a];return true;}
$root=getenv('PPAR_TEST_PLUGIN_DIR'); require $root.'/includes/trait-ppar-ebay.php';
class T{use PPAR_Ebay_Trait; const OPTION_EBAY_SYNC_JOB='sync',OPTION_EBAY_REFRESH_JOB='refresh',OPTION_EBAY_SELECTION_STATE='sel',EBAY_WORKER_HOOK='worker',EBAY_RUNTIME_BUILD='controlled-rebuild-test'; public function req($scope,$owner='test'){return $this->ebay_selection_request('test',$owner,true,$scope);} }
$f=0;$n=0;function ck($x,$m){global$f,$n;$n++;echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$f++;}
$src=file_get_contents($root.'/includes/trait-ppar-ebay.php');$main=file_get_contents($root.'/pferdeportal-affiliate-router.php');
$legacy=['ebay_business_restore_needed','ebay_start_business_restore_if_needed','ebay_admin_supersede_incompatible_recovery_jobs','ebay_admin_bootstrap_current_build_workflow','ebay_admin_drive_one_tick','handle_ebay_admin_pump'];
foreach($legacy as $name){ck(!preg_match('/function\s+'.preg_quote($name,'/').'\s*\(/',$src),'Legacy Browser/BUSINESS recovery root physically absent: '.$name);}
$t=new T;$GLOBALS['opts']['sel']=[];$GLOBALS['cron']=[];
$business=$t->req('business','canonical-business');
ck(($business['status']??'')==='pending'&&($business['selection_scope']??'')==='business','Real Selection-State-Machine accepts scoped BUSINESS request');
$same=$t->req('private','must-not-replace-open-owner');
ck(($same['owner']??'')==='canonical-business'&&($same['selection_scope']??'')==='business','Open canonical selection cannot be reset/replaced by another scope');
$GLOBALS['opts']['sel']=[];$bad=$t->req('nonsense','invalid');
ck(($bad['status']??'')==='failed'&&($bad['failure_reason']??'')==='invalid_selection_scope','Canonical Selection-State-Machine fails closed on invalid scope');
ck(strpos($src,'public function run_ebay_selection_worker(')!==false,'Canonical background Selection worker exists');
ck(strpos($src,'selection_worker_no_progress')!==false,'Canonical worker owns fail-closed three-tick no-progress guard');
$rpos=strpos($src,'public function render_ebay_page()');$render=$rpos===false?'':substr($src,$rpos,42000);
ck(strpos($render,'ebay_admin_bootstrap_current_build_workflow(')===false&&strpos($render,'ebay_admin_drive_one_tick(')===false,'Provider page has no browser lifecycle execution path');
ck(strpos($main,"add_action('wp_ajax_ppar_ebay_admin_pump'")===false,'Browser AJAX lifecycle pump is not registered');
ck(strpos($main,"add_action('init', array(\$this, 'ensure_ebay_selection_recovery_schedule')")===false,'Legacy init recovery hook is not registered');
ck(strpos($src,"ebay_selection_request('manual_curation'")===false&&strpos($src,"ebay_selection_request('manual_private_approval'")===false&&substr_count($src,"ebay_run_start(true,'refresh')")>=2,'Explicit admin mutations never create standalone selection owners and route through the canonical run');
echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
