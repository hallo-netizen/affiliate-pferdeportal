<?php
$root=getenv('PPAR_TEST_PLUGIN_DIR');
$src=file_get_contents($root.'/includes/trait-ppar-ebay.php');
$run=file_get_contents($root.'/includes/trait-ppar-ebay-run.php');
$main=file_get_contents($root.'/pferdeportal-affiliate-router.php');
$fail=0;$n=0;
function ck($x,$m){global $fail,$n;$n++;echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$fail++;}
function fnblock($s,$start,$next){$p=strpos($s,$start);if($p===false)return'';$q=strpos($s,$next,$p+strlen($start));return $q===false?substr($s,$p):substr($s,$p,$q-$p);}
$sync=fnblock($src,'private function ebay_start_sync_job','private function ebay_sync_transport');
$refresh=fnblock($src,'private function ebay_start_inventory_refresh_job','private function ebay_refresh_dispatch_worker');
$maint=fnblock($src,'public function run_ebay_maintenance_v2','private function ebay_maintenance_set_review_state');
$runStart=fnblock($run,'private function ebay_run_start','private function ebay_run_fail');
$runScope=fnblock($run,'private function ebay_run_selection_scope','private function ebay_run_new_uuid');
$runEffective=fnblock($run,'private function ebay_run_effective_settings','private function ebay_run_selection_scope');
ck(strpos($sync,'deferred_selection_running')!==false,'Legacy discovery substate refuses to start while selection owns its nested lifecycle state');
ck(strpos($refresh,'deferred_discovery_running')!==false,'Legacy refresh substate refuses to race an open discovery substate');
ck(strpos($maint,"'status'=>'deferred_busy'")!==false,'Standalone maintenance fails/deferred closed while nested sync/refresh/selection is busy');
ck(strpos($maint,'$allow_during_refresh')!==false,'Only the refresh subphase can explicitly embed bounded maintenance');
ck(strpos($src,'run_ebay_maintenance_v2(min(25, $local_remaining), false, 4, true)')!==false,'Refresh embeds maintenance with explicit allow-during-refresh flag');
$maintSchedule=fnblock($src,'public function ensure_ebay_maintenance_schedule','public function reschedule_ebay_maintenance_cron');
ck(strpos($maintSchedule,'wp_schedule_event')===false,'Maintenance never schedules an independent hourly mutation owner');
ck(strpos($main,"add_action(self::EBAY_MAINTENANCE_CRON_HOOK, array(\$this, 'run_ebay_maintenance_v2'))")===false,'No standalone maintenance cron hook can mutate beside canonical worker');
ck(strpos($maint,'$private_touched')!==false && strpos($maint,'$business_touched')!==false,'Maintenance still records touched seller domains for diagnostics');
ck(strpos($runStart,"'config_snapshot'=>array('seller_routes'")!==false,'Canonical run freezes seller-route snapshot exactly at run start');
ck(strpos($runScope,"['config_snapshot']['seller_routes']")!==false && strpos($runScope,'ebay_settings()')===false,'Selection scope is derived only from immutable run seller-route snapshot');
ck(strpos($runEffective,"['config_snapshot']['settings']")!==false,'Canonical worker reads frozen behavioural settings snapshot');
ck(strpos($runEffective,'$live[$key] = $value')!==false,'Frozen run settings override later live behavioural setting changes');
ck(strpos($main,"add_action('init', array(\$this, 'ensure_ebay_selection_recovery_schedule')")===false,'No init hook can acquire PRIVATE recovery ownership');
ck(strpos($main,"add_action('wp_ajax_ppar_ebay_admin_pump'")===false,'No admin AJAX pump can race lifecycle workers');
ck(strpos($main,"add_action(self::EBAY_WORKER_HOOK, array(\$this, 'run_ebay_canonical_worker'))")===false && substr_count($main,"add_action('wp_ajax_ppar_ebay_canonical_tick', array(\$this, 'handle_ebay_canonical_tick'))")===1,'Exactly one environment-bound canonical eBay transport owns orchestration');
echo "ASSERTIONS=$n FAIL=$fail\n";exit($fail?1:0);
