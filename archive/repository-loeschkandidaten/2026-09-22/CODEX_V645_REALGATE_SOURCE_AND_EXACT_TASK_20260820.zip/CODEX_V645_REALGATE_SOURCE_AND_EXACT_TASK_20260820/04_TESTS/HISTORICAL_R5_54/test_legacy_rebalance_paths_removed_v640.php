<?php
$root=getenv('PPAR_TEST_PLUGIN_DIR')?:'/mnt/data/final624_extract/affiliate-portal-router';
$src=file_get_contents($root.'/includes/trait-ppar-ebay.php');
$fail=0;$assertions=0;
function ck($ok,$m){global $fail,$assertions;$assertions++;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$fail++;}
ck(strpos($src,'private function ebay_business_rebalance_inventory')===false,'Legacy one-shot BUSINESS rebalance path is physically absent');
ck(strpos($src,'private function ebay_private_rebalance_inventory')===false,'Legacy one-shot PRIVATE rebalance path is physically absent');
ck(strpos($src,'private function ebay_selection_request')!==false,'Canonical selection request exists');
ck(strpos($src,'private function ebay_selection_process_tick')!==false,'Canonical selection state-machine tick exists');
$businessCalls=preg_match_all('/ebay_business_rebalance_inventory\s*\(/',$src,$m1);
$privateCalls=preg_match_all('/ebay_private_rebalance_inventory\s*\(/',$src,$m2);
ck($businessCalls===0,'No executable BUSINESS rebalance call remains in production source');
ck($privateCalls===0,'No executable PRIVATE rebalance call remains in production source');
echo "ASSERTIONS=$assertions FAIL=$fail\n";exit($fail?1:0);
