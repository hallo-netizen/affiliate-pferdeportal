<?php
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A'); define('HOUR_IN_SECONDS',3600); define('DAY_IN_SECONDS',86400);
class WP_Error { private $c,$m; function __construct($c,$m){$this->c=$c;$this->m=$m;} function get_error_code(){return $this->c;} function get_error_message(){return $this->m;} }
function is_wp_error($x){return $x instanceof WP_Error;}
function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_title($v){$v=strtolower((string)$v);$v=strtr($v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return strtr((string)$v,['ä'=>'a','ö'=>'o','ü'=>'u','Ä'=>'A','Ö'=>'O','Ü'=>'U','ß'=>'ss']);}
function get_option($k,$d=false){return $d;} function apply_filters($t,$v){return $v;} function wp_json_encode($v,$o=0){return json_encode($v,$o);} function esc_url_raw($v){return (string)$v;} function wp_http_validate_url($v){return true;}
$GLOBALS['meta']=[]; $GLOBALS['terms_for_post']=[]; $GLOBALS['posts_by_child']=[]; $GLOBALS['source_rows']=[];
function get_post_meta($id,$k,$single=true){return $GLOBALS['meta'][$id][$k]??'';}
function wp_get_post_terms($id,$tax,$args=[]){return $GLOBALS['terms_for_post'][$id]??[];}
function get_terms($args=[]){ if(($args['taxonomy']??'')==='hp_listing_category' && (int)($args['parent']??0)===100){ return [101,102,103,104,105,106,107,108]; } return []; }
function get_term_children($parent,$tax){return [101,102,103,104,105,106,107,108];}
function get_term($id,$tax){return (object)['term_id'=>(int)$id,'parent'=>100,'taxonomy'=>$tax];}
function get_term_by($field,$value,$tax){ if($tax==='hp_listing_category' && $field==='slug' && $value==='private-anzeigen') return (object)['term_id'=>100,'slug'=>'private-anzeigen','taxonomy'=>$tax]; return false; }
function get_posts($args=[]){
  $term=(int)($args['tax_query'][0]['terms'][0]??0); $rows=$GLOBALS['posts_by_child'][$term]??[]; $lim=(int)($args['posts_per_page']??6); return array_slice($rows,0,$lim);
}
function get_post_status($id){return 'publish';} function get_post_type($id){return 'hp_listing';}
class DB { public $prefix='wp_'; function prepare($q,...$args){ if(count($args)===1 && is_array($args[0])){$args=$args[0];} foreach($args as $a){$q=preg_replace('/%s/',"'".str_replace("'","''",(string)$a)."'",$q,1);} return $q; } function get_results($q,$mode=null){ $out=[]; foreach($GLOBALS['source_rows'] as $r){ if(strpos($q,"'".$r['item_id']."'")===false) continue; if(strpos($q,"seller_account_type='INDIVIDUAL'")!==false && ($r['seller_account_type']??'')!=='INDIVIDUAL') continue; $out[]=$r; } usort($out,fn($a,$b)=>(int)$b['id']<=>(int)$a['id']); return $out; } }
$GLOBALS['wpdb']=new DB;
$PLUGIN_ROOT=getenv('PPAR_TEST_PLUGIN_DIR') ?: '/mnt/data/v634_work/affiliate-portal-router'; require $PLUGIN_ROOT.'/includes/trait-ppar-ebay.php';
class T { use PPAR_Ebay_Trait; const EBAY_CONTENT_POLICY_VERSION='6.1', EBAY_PRIVATE_CLASSIFIER_VERSION='4.0', EBAY_BUSINESS_CLASSIFIER_VERSION='6.1'; public function run($safe,$query,$parent,$now,$limit=9){$r=new ReflectionMethod($this,'ebay_private_parent_refill_posts');$r->setAccessible(true);return $r->invoke($this,$safe,$query,$parent,$now,$limit);} }
class Q { public $posts=[]; private $v=[]; function __construct($posts){$this->posts=$posts;$this->v=['hp_listing_category'=>'private-anzeigen'];} function get($k){return $this->v[$k]??null;} function is_tax($tax,$term){return $tax==='hp_listing_category'&&$term==='private-anzeigen';} }
$f=0;$n=0; function ck($ok,$m){global $f,$n;$n++;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$f++;}
function mk($id,$child,$title){ $p=(object)['ID'=>$id,'post_type'=>'hp_listing','post_status'=>'publish','post_title'=>$title]; $item='I'.$id; $GLOBALS['meta'][$id]=['_ppar_ebay_item_id'=>$item,'_ppar_ebay_target_term_id'=>$child,'_ppar_ebay_lifecycle_state'=>'active','_ppar_ebay_seller_username'=>'seller'.$id]; $GLOBALS['terms_for_post'][$id]=[$child]; $GLOBALS['source_rows'][$item]=['id'=>$id,'item_id'=>$item,'seller_account_type'=>'INDIVIDUAL','source_state'=>'available','policy_state'=>'allowed','route_state'=>'ready','item_end_at'=>time()+86400,'title'=>$title,'source_payload'=>json_encode(['raw'=>['itemId'=>$item,'title'=>$title,'seller'=>['sellerAccountType'=>'INDIVIDUAL','username'=>'seller'.$id],'listingMarketplaceId'=>'EBAY_DE','itemWebUrl'=>'https://www.ebay.de/itm/'.$item,'image'=>['imageUrl'=>'https://i.ebayimg.com/x.jpg'],'price'=>['value'=>'20','currency'=>'EUR'],'categories'=>[['categoryId'=>'1','categoryName'=>'Reitsport']]]])]; return $p; }
// Child 101 represents newly enriched boots and monopolises the nine newest SQL rows.
$newest=[]; for($i=1;$i<=12;$i++){ $p=mk(1000+$i,101,'Reitstiefel '.$i); $GLOBALS['posts_by_child'][101][]=$p; if($i<=9)$newest[]=$p; }
$labels=[102=>'Reithelme',103=>'Reithosen',104=>'Pferdedecken',105=>'Sattel',106=>'Weidezaun',107=>'Futtertrog',108=>'Putzzeug'];
foreach($labels as $child=>$label){ for($i=1;$i<=2;$i++) $GLOBALS['posts_by_child'][$child][]=mk($child*10+$i,$child,$label.' '.$i); }
$t=new T; $q=new Q($newest); $out=$t->run($newest,$q,100,time(),9);
$ids=array_map(fn($p)=>(int)$p->ID,$out); $buckets=array_map(fn($id)=>(int)($GLOBALS['meta'][$id]['_ppar_ebay_target_term_id']??0),$ids); $counts=array_count_values($buckets);
ck(count($out)===9,'PRIVATE parent returns exactly nine cards');
ck(count($counts)>=8,'Nine-card parent preview spans all eight direct PRIVATE child categories when supply exists');
ck(($counts[101]??0)<=2,'Fresh Reitstiefel enrichment cannot monopolise parent preview');
foreach(array_keys($labels) as $child){ck(($counts[$child]??0)>=1,'Direct child '.$child.' remains represented');}
// Negative: blocked/ended candidates from a child must not be used. Make 108 ended and rerun; output remains safe and does not include ended child.
foreach($GLOBALS['posts_by_child'][108] as $p){$item=$GLOBALS['meta'][$p->ID]['_ppar_ebay_item_id'];$GLOBALS['source_rows'][$item]['source_state']='ended';}
$out2=$t->run($newest,$q,100,time(),9); $b2=array_map(fn($p)=>(int)($GLOBALS['meta'][$p->ID]['_ppar_ebay_target_term_id']??0),$out2);
ck(!in_array(108,$b2,true),'Ended child candidates are rejected by the public gate');
ck(count($out2)===9,'Preview still fills to nine from remaining valid categories when possible');
// Invariance: function only chooses output rows; it must not change the durable 250-selection state or post status.
$before=$GLOBALS['meta']; $t->run($newest,$q,100,time(),9); ck($before===$GLOBALS['meta'],'Parent preview selection does not mutate durable listing metadata');
echo 'BUCKETS='.json_encode($counts).' ASSERTIONS='.$n.' FAIL='.$f."\n"; exit($f?1:0);
