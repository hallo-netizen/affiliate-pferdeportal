<?php
// Refresh resume contract: a current-build refresh stopped only by the segment
// time budget must resume from the exact durable phase/cursor/counters. It must
// not be replaced by a fresh run_uuid/last_id=0 job.
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A');
function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_text_field($v){return trim(strip_tags((string)$v));}
function absint($v){return abs((int)$v);} function apply_filters($t,$v){return $v;}
$GLOBALS['opts']=[]; function get_option($k,$d=false){return array_key_exists($k,$GLOBALS['opts'])?$GLOBALS['opts'][$k]:$d;} function update_option($k,$v,$a=false){$GLOBALS['opts'][$k]=$v;return true;}
$root=getenv('PPAR_TEST_PLUGIN_DIR'); require $root.'/includes/trait-ppar-ebay.php';
class T{use PPAR_Ebay_Trait; const OPTION_EBAY_REFRESH_JOB='refresh',EBAY_RUNTIME_BUILD='controlled-rebuild-test';
 public function hasResume(){return method_exists($this,'ebay_refresh_job_is_resumable_partial')&&method_exists($this,'ebay_refresh_resume_partial_job');}
 public function resumable($j){return method_exists($this,'ebay_refresh_job_is_resumable_partial')?$this->ebay_refresh_job_is_resumable_partial($j):false;}
 public function resume($j){return method_exists($this,'ebay_refresh_resume_partial_job')?$this->ebay_refresh_resume_partial_job($j):array();}
 public function load(){return $this->ebay_refresh_job_load();}
}
$f=0;$n=0;function ck($x,$m){global$f,$n;$n++;echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$f++;}
$t=new T;
$job=[
 'schema'=>'1.0','engine'=>'targeted-getitem-refresh','build'=>'controlled-rebuild-test','status'=>'partial','run_uuid'=>'RUN-REFRESH-1','worker_token'=>'refresh-token','manual'=>false,
 'created_at'=>100,'segment_started_at'=>100,'updated_at'=>120,'finished_at'=>123,'last_worker_at'=>119,'last_progress_at'=>118,'last_id'=>777,'due_before'=>999999,
 'progress_seq'=>44,
 'summary'=>[
   'status'=>'partial','phase'=>'source_refresh','started_at'=>100,'finished_at'=>123,'checked'=>41,'requests'=>29,'available'=>20,'updated'=>19,'revived'=>2,'ended'=>3,'excluded'=>1,'reviewed'=>1,
   'transient_errors'=>2,'technical_errors'=>0,'errors'=>[['item_id'=>'X','code'=>'transient','error'=>'retry']],
   'maintenance'=>['scanned'=>75,'ready_private'=>40,'ready_business'=>30,'review'=>3,'blocked'=>2,'errors'=>0,'completed'=>1,'deferred'=>0],
   'asset_verification'=>['processed'=>8,'verified'=>7,'blocked'=>1,'remaining'=>0,'completed'=>1,'deferred'=>0],
   'max_local_reconcile_rows'=>500,'max_asset_verifications'=>50,'max_checks'=>1200,'segment_limit_seconds'=>2700,'stopped_reason'=>'segment_time_budget','segments'=>2,
 ]
];
ck($t->hasResume()===true,'Refresh exposes a dedicated resumable-partial contract instead of fresh-start fallback');
ck($t->resumable($job)===true,'Current-build refresh partial with segment_time_budget is resumable');
$res=$t->resume($job);
ck(($res['status']??'')==='queued','Refresh resume reopens the same job as queued');
ck(($res['run_uuid']??'')==='RUN-REFRESH-1'&&($res['worker_token']??'')==='refresh-token','Refresh resume preserves run_uuid and worker token');
ck((int)($res['last_id']??-1)===777&&(int)($res['due_before']??-1)===999999,'Refresh resume preserves exact source cursor and due boundary');
ck(($res['summary']['phase']??'')==='source_refresh','Refresh resume preserves exact workflow phase');
ck((int)($res['summary']['checked']??-1)===41&&(int)($res['summary']['requests']??-1)===29&&(int)($res['summary']['maintenance']['scanned']??-1)===75,'Refresh resume preserves accumulated source and maintenance counters');
ck(($res['summary']['asset_verification']??[])===$job['summary']['asset_verification'],'Refresh resume preserves asset-verification durable state');
ck(($res['summary']['errors']??[])===$job['summary']['errors'],'Refresh resume preserves existing error/retry history');
ck(($res['summary']['stopped_reason']??'x')==='','Refresh resume clears only the segment stop reason');
ck((int)($res['summary']['segments']??0)===3,'Refresh resume increments segment count exactly once');
ck((int)($res['finished_at']??-1)===0&&(int)($res['summary']['finished_at']??-1)===0,'Refresh resume clears terminal timestamps without resetting work');
ck($t->load()===$res,'Resumed refresh state is durably saved exactly as returned');
ck($t->resume($res)===[],'Already-open resumed refresh cannot be resumed/reset a second time');
$wrong=$job;$wrong['build']='old-build';ck($t->resumable($wrong)===false,'Old-build partial refresh is not silently resumed across runtime contract');
$other=$job;$other['summary']['stopped_reason']='max_checks';ck($t->resumable($other)===false,'Non-time-budget partial refresh is not silently resumed');
$terminal=$job;$terminal['status']='completed';ck($t->resumable($terminal)===false,'Terminal completed refresh is never treated as resumable');
$src=file_get_contents($root.'/includes/trait-ppar-ebay.php');
$startPos=strpos($src,'private function ebay_start_inventory_refresh_job');$endPos=strpos($src,'public function run_ebay_inventory_refresh',$startPos);$start=substr($src,$startPos,$endPos-$startPos);
ck(strpos($start,'ebay_refresh_job_is_resumable_partial($existing)')!==false&&strpos($start,'ebay_refresh_resume_partial_job($existing)')!==false,'Refresh start path wires partial resume before fresh job creation');
echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
