<?php
$root=getenv('PPAR_TEST_PLUGIN_DIR');$src=file_get_contents($root.'/includes/trait-ppar-ebay.php');$fail=0;$n=0;
function ck($x,$m){global $fail,$n;$n++;echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$fail++;}
function block_between($s,$a,$b){$p=strpos($s,$a);if($p===false)return'';$q=strpos($s,$b,$p+1);return$q===false?substr($s,$p):substr($s,$p,$q-$p);}
$prepare=block_between($src,'private function ebay_selection_prepare_pending','private function ebay_selection_apply_business_batch');
$prune=block_between($src,'private function ebay_selection_apply_private_post_batch','private function ebay_selection_verify_private_final');
$verify=block_between($src,'private function ebay_selection_verify_private_final','private function ebay_selection_process_tick');
$approve=block_between($src,'public function handle_ebay_review_decision','private function ebay_sync_job_load');$follow=block_between($src,'private function ebay_review_selection_after_approval','public function handle_ebay_review_decision');
ck(strpos($src,"min(250, absint(\$settings['private_active_cap'] ?? 250))")!==false,'Settings normalization hard-clamps PRIVATE cap to 250');
ck(strpos($src,"\$global=min(250,max(50,absint(\$settings['private_active_cap']??250)))")!==false,'PRIVATE capacity selector cannot choose more than 250 winners');
ck(strpos($prepare,"'private_prune'")!==false,'PRIVATE selection starts in prune phase');
ck(strpos($prune,"\$state['phase']='private'")!==false,'Only after prune completion may PRIVATE materialization begin');
ck(strpos($prune,'post_deactivation_errors')!==false && strpos($prune,"\$state['status']='failed'")!==false,'Prune errors fail closed before any winner publishing');
ck(strpos($verify,'wp_update_post')===false && strpos($verify,'update_post_meta')===false && strpos($verify,'ebay_materialize_private_listing')===false,'Final PRIVATE verifier is read-only');
ck(strpos($verify,'private_public_cap_exceeded')!==false,'Final verifier fails closed if actual public plugin inventory exceeds cap');
ck(strpos($approve,'ebay_materialize_private_listing')===false,'Manual PRIVATE approval cannot publish directly around the cap owner');
ck(strpos($approve,"ebay_selection_request('manual_private_approval'")===false && strpos($approve,'ebay_review_selection_after_approval')!==false && strpos($follow,"ebay_run_start(true,'refresh')")!==false && strpos($follow,'ebay_selection_request(')===false,'Manual PRIVATE approval cannot create a standalone selector and resumes only through the canonical run owner');
echo "ASSERTIONS=$n FAIL=$fail\n";exit($fail?1:0);
