<?php
$root=getenv('PPAR_TEST_PLUGIN_DIR');$src=file_get_contents($root.'/includes/trait-ppar-ebay.php');$main=file_get_contents($root.'/pferdeportal-affiliate-router.php');$fail=0;$n=0;
function ck($x,$m){global$fail,$n;$n++;echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$fail++;}
$p=strpos($src,'public function render_ebay_page()');$render=$p===false?'':substr($src,$p,62000);
ck($render!=='','eBay admin renderer exists');
foreach(array(
    'ebay_admin_bootstrap_current_build_workflow('=>'no bootstrap mutation',
    'ebay_admin_drive_one_tick('=>'no synchronous worker tick',
    'run_ebay_sync_worker('=>'no synchronous sync worker',
    'run_ebay_inventory_refresh_worker('=>'no synchronous refresh worker',
    'run_ebay_maintenance_v2('=>'no synchronous maintenance scan',
    'ebay_private_reitstiefel_supply_snapshot('=>'no 5,000-row product-specific source scan',
    'ebay_business_selection_plan('=>'no full BUSINESS coverage plan on page render',
    'wp_remote_post('=>'no loopback transport',
    'window.location.reload()'=>'no reload loop'
) as $needle=>$label){ck(strpos($render,$needle)===false,$label);}
ck(strpos($render,'Provider-Seite: read-only für Fachlogik')!==false,'Admin UI states that provider rendering is read-only for BUSINESS/PRIVATE Fachlogik');
ck(strpos($render,'ebay_review_candidates(100)')!==false,'Admin review table requests a bounded 100-row window only');
$reviewPos=strpos($src,'private function ebay_review_candidates');$reviewBlock=$reviewPos===false?'':substr($src,$reviewPos,900);
ck(strpos($reviewBlock,'min(250, absint($limit))')!==false && strpos($reviewBlock,'LIMIT %d')!==false,'Review-candidate query has a hard 250-row cap and SQL LIMIT');
ck(strpos($main,"add_action('init', array(\$this, 'ensure_ebay_selection_recovery_schedule')")===false,'Normal WordPress init does not start selection recovery');
ck(strpos($main,"add_action('init', array(\$this, 'maybe_migrate_ebay_private_flat_structure')")===false,'Normal WordPress init does not run inventory migration');
ck(strpos($main,"add_action('wp_ajax_ppar_ebay_admin_pump'")===false && substr_count($main,"add_action('wp_ajax_ppar_ebay_canonical_tick', array(\$this, 'handle_ebay_canonical_tick'))")===1,'No legacy multi-worker AJAX pump exists; exactly one canonical authenticated transport endpoint is registered');
echo "ASSERTIONS=$n FAIL=$fail\n";exit($fail?1:0);
