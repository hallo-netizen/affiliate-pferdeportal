<?php
// Terminal idempotence contract: already-terminal discovery, refresh and
// selection states must be exact no-ops under repeated worker invocations.
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A');
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return$this->c;}function get_error_message(){return$this->m;}} function is_wp_error($x){return $x instanceof WP_Error;}
function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));} function sanitize_text_field($v){return trim(strip_tags((string)$v));} function absint($v){return abs((int)$v);} function wp_json_encode($v,$o=0){return json_encode($v,$o);} function apply_filters($t,$v){return $v;}
$GLOBALS['opts']=[];$GLOBALS['writes']=[];$GLOBALS['cron']=[];$GLOBALS['transients']=[];
function get_option($k,$d=false){return array_key_exists($k,$GLOBALS['opts'])?$GLOBALS['opts'][$k]:$d;} function update_option($k,$v,$a=false){$GLOBALS['opts'][$k]=$v;$GLOBALS['writes'][]=$k;return true;}
function get_transient($k){return $GLOBALS['transients'][$k]??false;} function set_transient($k,$v,$ttl){$GLOBALS['transients'][$k]=$v;return true;} function delete_transient($k){unset($GLOBALS['transients'][$k]);return true;}
function wp_next_scheduled($h){return $GLOBALS['cron'][$h]??false;} function wp_schedule_single_event($t,$h){$GLOBALS['cron'][$h]=$t;return true;} function wp_clear_scheduled_hook($h){unset($GLOBALS['cron'][$h]);return true;}
$root=getenv('PPAR_TEST_PLUGIN_DIR');require $root.'/includes/trait-ppar-ebay.php';
class T{use PPAR_Ebay_Trait; const OPTION_EBAY_SYNC_JOB='sync',OPTION_EBAY_REFRESH_JOB='refresh',OPTION_EBAY_SELECTION_STATE='sel',OPTION_NETWORK_EBAY='net',EBAY_WORKER_HOOK='worker',EBAY_REFRESH_WORKER_HOOK='refresh_worker',EBAY_RUNTIME_BUILD='controlled-rebuild-test';
 private function ebay_settings(){return ['enabled'=>true,'inventory_refresh_enabled'=>true];}
}
$f=0;$n=0;function ck($x,$m){global$f,$n;$n++;echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$f++;}
$t=new T;
$discovery=['schema'=>'2.0','engine'=>'resumable-background','build'=>'controlled-rebuild-test','status'=>'completed','run_uuid'=>'D1','worker_token'=>'d','scope'=>'all','finished_at'=>500,'summary'=>['status'=>'completed','finished_at'=>500]];
$refresh=['schema'=>'1.0','engine'=>'targeted-getitem-refresh','build'=>'controlled-rebuild-test','status'=>'completed','run_uuid'=>'R1','worker_token'=>'r','finished_at'=>600,'last_id'=>88,'summary'=>['status'=>'completed','finished_at'=>600,'checked'=>88]];
$selection=['version'=>'2.0','status'=>'complete','phase'=>'complete','owner'=>'terminal','selection_scope'=>'all','completed_at'=>700,'verified_public_private'=>250,'article_plan_revision_bumped'=>123];
$GLOBALS['opts']=['sync'=>$discovery,'refresh'=>$refresh,'sel'=>$selection,'net'=>['sentinel'=>'unchanged']];
$before=$GLOBALS['opts'];$GLOBALS['writes']=[];$GLOBALS['cron']=[];
for($repeat=2;$repeat<=4;$repeat++){
  $a=$t->run_ebay_sync_worker(true);$b=$t->run_ebay_inventory_refresh_worker(true);$c=$t->run_ebay_selection_worker(true);
  ck($a===false&&$b===false&&$c===false,'Terminal workers are no-op on repeat '.$repeat);
  ck($GLOBALS['opts']===$before,'Terminal states remain byte-equivalent on repeat '.$repeat);
}
ck($GLOBALS['writes']===[],'Terminal worker repeats perform no durable option writes');
ck($GLOBALS['cron']===[],'Terminal worker repeats schedule no new lifecycle work');
ck($GLOBALS['transients']===[],'Terminal worker lock transients are fully released after no-op repeats');
// Failed terminal states are also final for workers: no automatic resurrection.
$GLOBALS['opts']['sync']=$discovery;$GLOBALS['opts']['sync']['status']='failed';$GLOBALS['opts']['sync']['summary']['status']='failed';
$GLOBALS['opts']['refresh']=$refresh;$GLOBALS['opts']['refresh']['status']='failed';$GLOBALS['opts']['refresh']['summary']['status']='failed';
$GLOBALS['opts']['sel']=$selection;$GLOBALS['opts']['sel']['status']='failed';$GLOBALS['opts']['sel']['phase']='failed';
$failed_before=$GLOBALS['opts'];$GLOBALS['writes']=[];$GLOBALS['cron']=[];
ck($t->run_ebay_sync_worker(true)===false&&$t->run_ebay_inventory_refresh_worker(true)===false&&$t->run_ebay_selection_worker(true)===false,'Failed terminal workers do not resurrect themselves');
ck($GLOBALS['opts']===$failed_before&&$GLOBALS['writes']===[]&&$GLOBALS['cron']===[],'Failed terminal states remain exact durable no-ops');
// A segment-budget partial is resumable only through the explicit start/resume
// path; the old worker invocation itself must never silently reopen/reset it.
$GLOBALS['opts']['sync']=$discovery;$GLOBALS['opts']['sync']['status']='partial';$GLOBALS['opts']['sync']['summary']=['status'=>'partial','budget'=>['stopped_reason'=>'segment_time_budget']];
$GLOBALS['opts']['refresh']=$refresh;$GLOBALS['opts']['refresh']['status']='partial';$GLOBALS['opts']['refresh']['summary']=['status'=>'partial','stopped_reason'=>'segment_time_budget','checked'=>88];
$GLOBALS['opts']['sel']=$selection;
$partial_before=$GLOBALS['opts'];$GLOBALS['writes']=[];$GLOBALS['cron']=[];
ck($t->run_ebay_sync_worker(true)===false&&$t->run_ebay_inventory_refresh_worker(true)===false,'Partial workers do not self-resume outside the explicit resume gate');
ck($GLOBALS['opts']===$partial_before&&$GLOBALS['writes']===[]&&$GLOBALS['cron']===[],'Partial worker no-op preserves exact resumable durable state');
echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
