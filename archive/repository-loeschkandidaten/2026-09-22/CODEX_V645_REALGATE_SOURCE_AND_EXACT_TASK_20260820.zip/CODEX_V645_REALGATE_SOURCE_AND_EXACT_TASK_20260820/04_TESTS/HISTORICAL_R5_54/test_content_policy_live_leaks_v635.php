<?php
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A'); define('HOUR_IN_SECONDS',3600); define('DAY_IN_SECONDS',86400);
class WP_Error { private $c,$m; function __construct($c,$m){$this->c=$c;$this->m=$m;} function get_error_code(){return $this->c;} function get_error_message(){return $this->m;} }
function is_wp_error($x){return $x instanceof WP_Error;}
function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_title($v){$v=strtolower((string)$v);$v=strtr($v,['ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return strtr((string)$v,['ä'=>'a','ö'=>'o','ü'=>'u','Ä'=>'A','Ö'=>'O','Ü'=>'U','ß'=>'ss']);}
function get_option($k,$d=false){return $d;} function apply_filters($t,$v){return $v;} function wp_json_encode($v,$o=0){return json_encode($v,$o);} function esc_url_raw($v){return (string)$v;} function wp_http_validate_url($v){return true;}
$GLOBALS['meta']=[];
function get_post_meta($id,$k,$single=true){return $GLOBALS['meta'][$id][$k]??'';}
function get_post_status($id){return 'publish';} function get_post_type($id){return 'hp_listing';}
class DB { public $prefix='wp_'; function prepare($q,...$args){return $q;} function get_results($q,$mode=null){return [];} }
$GLOBALS['wpdb']=new DB;
$PLUGIN_ROOT=getenv('PPAR_TEST_PLUGIN_DIR') ?: '/mnt/data/v635_work/affiliate-portal-router'; require $PLUGIN_ROOT.'/includes/trait-ppar-ebay.php';
class T { use PPAR_Ebay_Trait; const EBAY_CONTENT_POLICY_VERSION='6.2', EBAY_PRIVATE_CLASSIFIER_VERSION='4.0', EBAY_BUSINESS_CLASSIFIER_VERSION='6.1';
  public function reason($item){$r=new ReflectionMethod($this,'ebay_content_policy_reason');$r->setAccessible(true);return $r->invoke($this,$item);} 
  public function allowed($post,$row){$r=new ReflectionMethod($this,'ebay_private_public_post_allowed');$r->setAccessible(true);return $r->invoke($this,$post,$row,true,time());}
}
$f=0;$n=0; function ck($ok,$m){global $f,$n;$n++;echo($ok?'PASS ':'FAIL ').$m."\n";if(!$ok)$f++;}
function raw($title,$category='Reitsport',$desc=''){return ['title'=>$title,'shortDescription'=>$desc,'categories'=>[['categoryId'=>'x','categoryName'=>$category]],'localizedAspects'=>[]];}
$t=new T;
$toyTitle='2 kleine Pony / Pferde Spielzeug / Kopf drehbar – Vintage – 90 er Jahre';
$r=$t->reason(['raw'=>raw($toyTitle,'Pferde & Ponys')]); ck($r!=='','Live-Leak: explizites standalone Spielzeug im Titel wird hart blockiert, auch bei Pferde-Kategorie');
$r=$t->reason(['raw'=>raw('Pferdespielzeug Ball mit Griff','Reitsport')]); ck($r!=='','Pferdespielzeug-Compound wird nach Nutzervertrag ebenfalls blockiert');
$r=$t->reason(['raw'=>raw('Horse toy figure vintage','Equestrian')]); ck($r!=='','Englisches toy-Signal wird blockiert');
$bookTitle='Die drei !!!, Einsatz im Pferdestall (drei Ausrufezeichen) von Kari Erlhoff';
$r=$t->reason(['raw'=>raw($bookTitle,'Pferde & Ponys')]); ck($r!=='','Live-Leak: Die-drei-Buchtitel wird auch bei falsch einsortierter Pferde-Kategorie blockiert');
$r=$t->reason(['raw'=>raw('Pferdegeschichten Band 4 Taschenbuch','Reitsport')]); ck($r!=='','Taschenbuch-Signatur wird titelbasiert blockiert');
$r=$t->reason(['raw'=>raw('Dressur Schabracke Pferd Sattelunterlage HKM','Reitsport')]); ck($r==='','Echtes Reitsportprodukt bleibt erlaubt');
$r=$t->reason(['raw'=>raw('Reitstiefel Gummi Größe 39','Reitsport')]); ck($r==='','Echte Reitstiefel bleiben erlaubt');
$r=$t->reason(['raw'=>raw('Pferdeball Spielball für Box und Weide','Pferdebedarf')]); ck($r==='','Nicht als Spielzeug deklarierter funktionaler Pferdeball wird nicht durch unscharfe Wortstämme blockiert');
// Public boundary: current source payload is re-evaluated, independent of stored allowed policy_state.
$post=(object)['ID'=>9001,'post_type'=>'hp_listing','post_status'=>'publish','post_title'=>$toyTitle];
$GLOBALS['meta'][9001]=['_ppar_ebay_item_id'=>'TOY1','_ppar_ebay_lifecycle_state'=>'active','_ppar_ebay_seller_username'=>'seller','_ppar_ebay_target_term_id'=>101];
$row=['id'=>1,'item_id'=>'TOY1','seller_account_type'=>'INDIVIDUAL','source_state'=>'available','policy_state'=>'allowed','item_end_at'=>time()+86400,'title'=>$toyTitle,'source_payload'=>json_encode(['raw'=>raw($toyTitle,'Pferde & Ponys')])];
ck($t->allowed($post,$row)===false,'Public gate blockiert bereits gespeichertes Legacy-Spielzeug trotz altem policy_state=allowed');
$post2=(object)['ID'=>9002,'post_type'=>'hp_listing','post_status'=>'publish','post_title'=>'Reitstiefel Gummi Größe 39'];
$GLOBALS['meta'][9002]=['_ppar_ebay_item_id'=>'BOOT1','_ppar_ebay_lifecycle_state'=>'active','_ppar_ebay_seller_username'=>'seller','_ppar_ebay_target_term_id'=>101];
$row2=['id'=>2,'item_id'=>'BOOT1','seller_account_type'=>'INDIVIDUAL','source_state'=>'available','policy_state'=>'allowed','item_end_at'=>time()+86400,'title'=>$post2->post_title,'source_payload'=>json_encode(['raw'=>raw($post2->post_title,'Reitsport')])];
ck($t->allowed($post2,$row2)===true,'Public gate lässt echtes Reitsportprodukt weiterhin durch');
echo "ASSERTIONS=$n FAIL=$f\n"; exit($f?1:0);
