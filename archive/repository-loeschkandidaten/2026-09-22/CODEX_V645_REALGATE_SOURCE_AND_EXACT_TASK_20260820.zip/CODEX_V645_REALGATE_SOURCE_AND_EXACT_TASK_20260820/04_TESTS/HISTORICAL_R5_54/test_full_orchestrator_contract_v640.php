<?php
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A');
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return$this->c;}function get_error_message(){return$this->m;}} function is_wp_error($x){return $x instanceof WP_Error;}
function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));} function sanitize_text_field($v){return trim(strip_tags((string)$v));} function absint($v){return abs((int)$v);} function wp_generate_password($l=48,$s=false,$e=false){return str_repeat('T',$l);} function apply_filters($a,$b){return$b;} function admin_url($p=''){return 'https://example.test/wp-admin/'.$p;}
$GLOBALS['opts']=[];$GLOBALS['cron']=[];$GLOBALS['loopbacks']=[]; function get_option($k,$d=false){return $GLOBALS['opts'][$k]??$d;} function update_option($k,$v,$a=false){$GLOBALS['opts'][$k]=$v;return true;} function wp_next_scheduled($h){return $GLOBALS['cron'][$h]??false;} function wp_schedule_single_event($t,$h){$GLOBALS['cron'][$h]=$t;return true;} function wp_remote_post($u,$a){$GLOBALS['loopbacks'][]=[$u,$a];return true;}
$root=getenv('PPAR_TEST_PLUGIN_DIR'); require $root.'/includes/trait-ppar-ebay.php';
class T{use PPAR_Ebay_Trait; const OPTION_EBAY_SYNC_JOB='sync',OPTION_EBAY_REFRESH_JOB='refresh',OPTION_EBAY_SELECTION_STATE='sel',EBAY_WORKER_HOOK='worker',EBAY_RUNTIME_BUILD='controlled-rebuild-test'; public function req($scope,$owner='test'){return $this->ebay_selection_request('test',$owner,true,$scope);} }
$f=0;$n=0;function ck($x,$m){global$f,$n;$n++;echo($x?'PASS ':'FAIL ').$m."\n";if(!$x)$f++;}
$t=new T;
$st=$t->req('business'); ck(($st['selection_scope']??'')==='business','Central selection request preserves BUSINESS scope');
$GLOBALS['opts']['sel']=[];$GLOBALS['cron']=[];$st=$t->req('private'); ck(($st['selection_scope']??'')==='private','Central selection request preserves PRIVATE scope');
$GLOBALS['opts']['sel']=[];$bad=$t->req('nonsense'); ck(($bad['status']??'')==='failed'&&($bad['failure_reason']??'')==='invalid_selection_scope','Unknown selection scope fails closed instead of falling back to ALL');
$GLOBALS['opts']['sel']=['status'=>'running','phase'=>'private','owner'=>'first','selection_scope'=>'private','started_at'=>123];$same=$t->req('business','second'); ck(($same['owner']??'')==='first'&&($same['started_at']??0)===123&&($same['selection_scope']??'')==='private','Force request cannot replace/reset an open selection owner');
// Hard build gate: once a correct terminal state exists, ordinary lifecycle
// compatibility checks must be exact no-ops on runs 2/3/4; a build/page request
// may never reopen recovery merely because it was invoked again.
$GLOBALS['opts']['sel']=['status'=>'complete','phase'=>'complete','owner'=>'completed-owner','selection_scope'=>'all','verified_public_private'=>250,'completed_at'=>456];
$terminal_before=$GLOBALS['opts']['sel'];
for($repeat=2;$repeat<=4;$repeat++){
    $seen=$t->ensure_ebay_selection_recovery_schedule();
    ck($seen===$terminal_before && $GLOBALS['opts']['sel']===$terminal_before,'Terminal selection no-op Lauf '.$repeat.' bleibt exakt zustandsidentisch');
}
$src=file_get_contents($root.'/includes/trait-ppar-ebay.php');$main=file_get_contents($root.'/pferdeportal-affiliate-router.php');
$rpos=strpos($src,'public function render_ebay_page()'); $render=substr($src,$rpos,36000);
ck(strpos($render,'$this->ebay_admin_bootstrap_current_build_workflow($settings);')===false,'eBay page never bootstraps lifecycle work');
ck(strpos($render,'$this->ebay_admin_drive_one_tick();')===false,'eBay page never executes a lifecycle worker');
ck(strpos($render,'window.location.reload()')===false,'eBay page has no reload transport');
ck(strpos($render,'Provider-Seite: read-only für Fachlogik')!==false,'eBay page explicitly exposes read-only Fachlogik status');
ck(strpos($main,"add_action('wp_ajax_ppar_ebay_admin_pump'")===false,'Admin AJAX lifecycle pump is not registered');
ck(strpos($main,"admin_post_ppar_ebay_selection_worker_tick")===false,'Standalone self-HTTP selection endpoint is not registered');
ck(strpos($main,"add_action('init', array(\$this, 'ensure_ebay_selection_recovery_schedule')")===false,'Legacy init recovery hook is absent');
ck(strpos($main,"add_action('init', array(\$this, 'maybe_migrate_ebay_private_flat_structure')")===false,'Inventory/taxonomy migration is not automatic on every page init');
$prepStart=strpos($src,'private function ebay_selection_prepare_pending');$prep=substr($src,$prepStart,6500);ck(strpos($prep,"\$state['phase'] = \$scope === 'private' ? 'private_prune' : 'business_materialize'")!==false || strpos($prep,"\$state['phase']=\$scope==='private'?'private_prune':'business_materialize'")!==false,'PRIVATE begins with prune-before-publish');
$processStart=strpos($src,'private function ebay_selection_process_tick');$process=substr($src,$processStart,2800);$pp=strpos($process,"==='private_prune'");$pm=strpos($process,"==='private'");$pv=strpos($process,"==='private_verify'");ck($pp!==false&&$pm!==false&&$pv!==false&&$pp<$pm&&$pm<$pv,'PRIVATE phase order is prune → materialize → read-only verify');
ck(strpos($src,"ebay_selection_request('manual_curation'")===false && strpos($src,"ebay_run_start(true,'refresh')")!==false,'BUSINESS curation never creates a second selection owner and hands off to canonical refresh');
ck(strpos($src,"ebay_selection_request('manual_private_approval'")===false && strpos($src,'ebay_review_selection_after_approval')!==false,'PRIVATE approval never creates a second selection owner and hands off through canonical run helper');
ck(strpos($src,"'ppar_three_hours'")!==false&&strpos($src,"'hourly'")!==false,'Periodic 3h discovery and hourly lifecycle schedules remain');
echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
