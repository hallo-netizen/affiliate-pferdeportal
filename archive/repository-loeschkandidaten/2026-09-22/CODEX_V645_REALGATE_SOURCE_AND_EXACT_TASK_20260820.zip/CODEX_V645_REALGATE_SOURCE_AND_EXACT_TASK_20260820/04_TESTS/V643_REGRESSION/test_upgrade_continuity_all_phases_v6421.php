<?php
error_reporting(E_ALL);define('ABSPATH','/tmp/');define('ARRAY_A','ARRAY_A');
$GLOBALS['opts']=[];class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}function is_wp_error($x){return $x instanceof WP_Error;}function absint($v){return abs((int)$v);}function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}function sanitize_text_field($v){return trim(strip_tags((string)$v));}function wp_json_encode($v,$o=0){return json_encode($v,$o);}function get_option($k,$d=[]){return array_key_exists($k,$GLOBALS['opts'])?$GLOBALS['opts'][$k]:$d;}function update_option($k,$v,$a=false){$GLOBALS['opts'][$k]=$v;return true;}function wp_clear_scheduled_hook($h){$GLOBALS['cleared'][]=$h;return 1;}function wp_next_scheduled($h){return false;}function wp_schedule_single_event($t,$h){return true;}
$root=getenv('PPAR_TEST_PLUGIN_DIR');if(!$root){exit(2);}require $root.'/includes/trait-ppar-ebay-run.php';
class H{use PPAR_Ebay_Run_Trait;const OPTION_EBAY_RUN_STATE='run',OPTION_EBAY_SYNC_JOB='sync',OPTION_EBAY_REFRESH_JOB='refresh',OPTION_EBAY_SELECTION_STATE='selection',OPTION_EBAY_MAINTENANCE_STATE='maintenance',OPTION_EBAY_WORKER_TRANSPORT_MIGRATION='tm',OPTION_EBAY_PROGRESS_CONTRACT_MIGRATION='pm',EBAY_WORKER_HOOK='w',EBAY_REFRESH_WORKER_HOOK='rw',EBAY_RUNTIME_BUILD='6.42.1-test',EBAY_CONTENT_POLICY_VERSION='p',EBAY_PRIVATE_CLASSIFIER_VERSION='pc',EBAY_BUSINESS_CLASSIFIER_VERSION='bc';public $ebay_canonical_worker_active=false,$ebay_run_settings_override=null;public function migrateTransport(){return $this->maybe_migrate_ebay_worker_transport_v6412();}public function migrateProgress(){return $this->maybe_recover_ebay_false_no_progress_v6420();}public function run(){return get_option('run',[]);} }
$f=0;$n=0;function ck($v,$m){global$f,$n;$n++;echo($v?'PASS ':'FAIL ').$m."\n";if(!$v)$f++;}
$catalogHash=hash_file('sha256',$root.'/assets/ebay-portal-catalog-v2.json')?:'';
$phases=['reconcile_local','refresh_remote','selection_prepare','business_select','business_materialize','private_select','private_materialize','coverage_verify','gapfill_discovery','gapfill_select','public_verify'];
function seedRun($idx,$phase,$policy,$catalog){
  return ['schema'=>'1.0','build'=>'6.41.3-canonical-component-state-sync-rootfix-20260819','run_uuid'=>'upgrade-'.$idx,'status'=>'running','phase'=>$phase,'started_at'=>100,'updated_at'=>200,'finished_at'=>0,'owner'=>'owner-'.$idx,'lease_expires_at'=>9999999999,'worker_transport'=>'admin_ajax','resume_reason'=>'checkpoint','no_progress_count'=>2,'progress_seq'=>50+$idx,'config_snapshot'=>['seller_routes'=>['private'=>1,'business'=>1],'settings'=>['private_enabled'=>1,'business_enabled'=>1]],'catalog_version'=>$catalog,'policy_version'=>$policy,'private_classifier_version'=>'pc','business_classifier_version'=>'bc','phase_state'=>['maintenance'=>['cursor'=>25+$idx,'status'=>'running'],'refresh'=>['status'=>'running','last_id'=>2000+$idx,'inventory_last_id'=>1500+$idx],'selection'=>['status'=>'running','phase'=>'business_materialize','business_cursor'=>300+$idx,'prepare_business_concept_index'=>12+$idx,'prepare_private_leaf_index'=>4,'prepare_private_leaf_offsets'=>['a'=>100+$idx],'prepare_private_scanned'=>500+$idx,'private_cursor'=>40+$idx]],'coverage'=>['covered'=>4,'missing'=>['x','y']],'gapfill'=>['attempts'=>1,'missing'=>['x']],'errors'=>[],'start_manifest'=>['operation'=>'sync','marker'=>'start-'.$idx],'end_manifest'=>['marker'=>'derived-'.$idx],'recovery_history'=>[]];
}

// A. If the persisted run already matches the current policy/catalog contract,
// an update may not move the phase or mutate any durable workflow cursor/state.
foreach($phases as $idx=>$phase){
  $GLOBALS['opts']=[];$GLOBALS['cleared']=[];
  $state=seedRun($idx,$phase,'p',$catalogHash);update_option('run',$state,false);update_option('selection',$state['phase_state']['selection'],false);
  $h=new H();$h->migrateProgress();$h->migrateTransport();$after=$h->run();
  ck(($after['status']??'')==='running' && ($after['phase']??'')===$phase,"current-contract update preserves open phase $phase");
  ck(($after['run_uuid']??'')===($state['run_uuid']??''),"current-contract update preserves run_uuid in $phase");
  ck(($after['phase_state']??[])===($state['phase_state']??[]),"current-contract update preserves all nested cursors in $phase");
  ck(($after['coverage']??[])===($state['coverage']??[]) && ($after['gapfill']??[])===($state['gapfill']??[]),"current-contract update preserves coverage/gapfill in $phase");
  ck(($after['config_snapshot']??[])===($state['config_snapshot']??[]) && ($after['progress_seq']??null)===($state['progress_seq']??null),"current-contract update preserves seller snapshot/progress in $phase");
  ck(($after['start_manifest']??[])===($state['start_manifest']??[]) && ($after['end_manifest']??[])===($state['end_manifest']??[]),"current-contract update preserves manifests in $phase");
}

// B. V6.42 changes the central content-policy contract (6.3 -> 6.4). An open
// V6.41.3 run must keep its UUID and source/remote state, but it must not continue
// a selection plan prepared under the stale policy. It re-enters reconcile_local
// once, clearing only derived selection/coverage/gapfill/end-manifest state.
foreach($phases as $idx=>$phase){
  $GLOBALS['opts']=[];$GLOBALS['cleared']=[];
  $state=seedRun(100+$idx,$phase,'old-policy','old-catalog');update_option('run',$state,false);update_option('selection',$state['phase_state']['selection'],false);
  $h=new H();$h->migrateProgress();$h->migrateTransport();$after=$h->run();
  ck(($after['status']??'')==='running' && ($after['phase']??'')==='reconcile_local',"old-contract update re-enters reconcile_local from $phase");
  ck(($after['run_uuid']??'')===($state['run_uuid']??''),"old-contract update preserves run_uuid from $phase");
  ck(($after['phase_state']['maintenance']??[])===($state['phase_state']['maintenance']??[]) && ($after['phase_state']['refresh']??[])===($state['phase_state']['refresh']??[]),"old-contract update preserves source/remote cursors from $phase");
  ck(($after['phase_state']['selection']??[])===[] && get_option('selection',[])===[],"old-contract update clears only stale selection plan from $phase");
  ck(($after['coverage']??[])===[] && ($after['gapfill']??[])===['attempts'=>0,'missing'=>[]] && ($after['end_manifest']??[])===[],"old-contract update clears stale coverage/gapfill/end-manifest from $phase");
  ck(($after['config_snapshot']??[])===($state['config_snapshot']??[]) && ($after['start_manifest']??[])===($state['start_manifest']??[]) && ($after['progress_seq']??null)===($state['progress_seq']??null),"old-contract update preserves seller snapshot/start manifest/progress from $phase");
  ck(($after['policy_version']??'')==='p' && ($after['catalog_version']??'')===$catalogHash,"old-contract update persists current policy/catalog from $phase");
  ck(($after['owner']??'')==='' && (int)($after['lease_expires_at']??1)===0 && ($after['no_progress_count']??9)===0,"old-contract update releases stale lease/no-progress guard from $phase");
  ck(($after['resume_reason']??'')==='progress_contract_policy_reconcile' && ($after['recovery_history'][0]['reason']??'')==='progress_contract_upgrade_open_run',"old-contract update records explicit migration reason from $phase");
  $once=$after;$h->migrateProgress();ck($h->run()===$once,"old-contract migration is idempotent after $phase");
}

echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
