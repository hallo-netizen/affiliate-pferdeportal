<?php
error_reporting(E_ALL);
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A'); define('HOUR_IN_SECONDS',3600);
$GLOBALS['opts']=array(); $GLOBALS['scheduled']=array();
class WP_Error{private $c,$m; function __construct($c,$m){$this->c=$c;$this->m=$m;} function get_error_code(){return $this->c;} function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;} function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function wp_json_encode($v,$o=0){return json_encode($v,$o);} function wp_generate_uuid4(){static $i=0;$i++;return sprintf('00000000-0000-4000-8000-%012d',$i);} function maybe_serialize($v){return serialize($v);} function wp_cache_delete($a,$b=''){return true;}
function get_option($k,$d=array()){return array_key_exists($k,$GLOBALS['opts'])?$GLOBALS['opts'][$k]:$d;} function update_option($k,$v,$autoload=false){$GLOBALS['opts'][$k]=$v;return true;}
function wp_next_scheduled($hook){return !empty($GLOBALS['scheduled'][$hook])?$GLOBALS['scheduled'][$hook]:false;} function wp_schedule_single_event($ts,$hook){$GLOBALS['scheduled'][$hook]=$ts;return true;} function wp_clear_scheduled_hook($hook){unset($GLOBALS['scheduled'][$hook]);return 1;}
$root=getenv('PPAR_TEST_PLUGIN_DIR') ?: dirname(__DIR__,2); require $root.'/includes/trait-ppar-ebay-run.php';

class CanonicalHarness {
    use PPAR_Ebay_Run_Trait;
    const OPTION_EBAY_RUN_STATE='run'; const OPTION_EBAY_SYNC_JOB='sync'; const OPTION_EBAY_REFRESH_JOB='refresh'; const OPTION_EBAY_SELECTION_STATE='selection'; const OPTION_EBAY_MAINTENANCE_STATE='maintenance'; const OPTION_EBAY_WORKER_TRANSPORT_MIGRATION='migration';
    const OPTION_NETWORK_EBAY='settings'; const EBAY_WORKER_HOOK='worker'; const EBAY_REFRESH_WORKER_HOOK='refresh-worker'; const EBAY_RUNTIME_BUILD='6.41.2-test'; const EBAY_CONTENT_POLICY_VERSION='5.0'; const EBAY_PRIVATE_CLASSIFIER_VERSION='4.0'; const EBAY_BUSINESS_CLASSIFIER_VERSION='5.0';
    public $ebay_canonical_worker_active=false,$ebay_run_settings_override=null,$seen_settings=array(),$selection_scope_seen=array(),$gapfill_requested=array(),$private_verify_calls=0,$private_public_mutations=0,$coverage_calls=0,$stall=false,$provider_fail=false,$materialized=array(),$gapfilled=false,$gapfill_cannot_fill=false;
    public $live=array('enabled'=>1,'private_enabled'=>1,'business_enabled'=>1,'inventory_refresh_enabled'=>1,'rules'=>array());
    private function ebay_normalize_settings($s,$keep=true){return is_array($s)?$s:array();}
    private function ebay_settings(){if(isset($this->ebay_run_settings_override)&&is_array($this->ebay_run_settings_override))return $this->ebay_run_settings_override;return $this->live;}
    private function ebay_catalog_rules(){return array();}
    private function ebay_configuration_errors($s){return array();}
    private function ebay_selection_scope_for_enabled_routes($scope,$s){$p=!empty($s['private_enabled']);$b=!empty($s['business_enabled']);return $p&&$b?'all':($p?'private':($b?'business':''));}
    private function ebay_business_required_product_concept_ids(){return array('concept-a','concept-b','concept-c');}
    private function ebay_remote_image_url_validate($u){return $u;}

    private function ebay_maintenance_state_load(){return $this->ebay_run_phase_state_load('maintenance');}
    private function ebay_maintenance_state_is_current($s=null){$s=is_array($s)?$s:$this->ebay_maintenance_state_load(); return !empty($s['completed_at']);}
    public function run_ebay_maintenance_v2($limit=25,$force=false,$budget=4,$allow=true){
        $this->seen_settings[]=$this->ebay_settings(); if($this->stall)return array('status'=>'deferred_busy');
        $s=$this->ebay_maintenance_state_load();$s['cursor']=absint($s['cursor']??0)+25;if($s['cursor']>=50)$s['completed_at']=time();$this->ebay_run_phase_state_save('maintenance',$s);return array('status'=>'running','scanned'=>25);
    }

    private function ebay_sync_job_load(){return $this->ebay_run_phase_state_load('discovery');}
    private function ebay_sync_job_is_open($j){return in_array(sanitize_key((string)($j['status']??'')),array('queued','running'),true);}
    private function ebay_start_sync_job($manual=false,$scope='all',$transport='background'){
        if($scope==='business_recovery'){$run=$this->ebay_run_load();$this->gapfill_requested=(array)($run['gapfill']['missing']??array());}
        $run=$this->ebay_run_load();$j=array('status'=>'queued','scope'=>$scope,'run_uuid'=>(string)($run['run_uuid']??''),'profile_cursor'=>0,'summary'=>array('errors'=>array()));$this->ebay_run_phase_state_save('discovery',$j);return array('status'=>'queued','run_uuid'=>$j['run_uuid']);
    }
    public function run_ebay_sync_worker($external=false){$this->seen_settings[]=$this->ebay_settings();$j=$this->ebay_sync_job_load();if(!$this->ebay_sync_job_is_open($j))return false;$j['status']='running';$j['profile_cursor']=absint($j['profile_cursor']??0)+1;if($this->provider_fail){$j['status']='failed';$j['failure_reason']='provider_timeout';$j['summary']['errors'][]=array('code'=>'provider_timeout','error'=>'Provider Timeout');}
        elseif($j['profile_cursor']>=2){$j['status']='completed'; if(($j['scope']??'')==='business_recovery')$this->gapfilled=true;}
        $this->ebay_run_phase_state_save('discovery',$j);return true;}

    private function ebay_refresh_job_load(){return $this->ebay_run_phase_state_load('refresh');}
    private function ebay_refresh_job_is_open($j){return in_array(sanitize_key((string)($j['status']??'')),array('queued','running'),true);}
    private function ebay_refresh_job_is_resumable_partial($j){return false;}
    private function ebay_refresh_resume_partial_job($j){return $j;}
    private function ebay_refresh_job_is_bounded_manual_partial($j){return sanitize_key((string)($j['status']??''))==='partial' && sanitize_key((string)($j['summary']['stopped_reason']??''))==='max_checks_limit';}
    private function ebay_refresh_resume_bounded_remote_job($j){$j['status']='queued';$j['summary']['status']='queued';$j['summary']['stopped_reason']='';$j['segments']=absint($j['segments']??1)+1;$this->ebay_run_phase_state_save('refresh',$j);return $j;}
    private function ebay_start_inventory_refresh_job($manual=true,$skip=true){$run=$this->ebay_run_load();$j=array('status'=>'queued','manual'=>1,'run_uuid'=>(string)($run['run_uuid']??''),'last_id'=>0,'segments'=>1,'summary'=>array('checked'=>0,'errors'=>array(),'stopped_reason'=>'','status'=>'queued'));$this->ebay_run_phase_state_save('refresh',$j);return $j;}
    public function run_ebay_inventory_refresh_worker($external=false){$this->seen_settings[]=$this->ebay_settings();$j=$this->ebay_refresh_job_load();if(!$this->ebay_refresh_job_is_open($j))return false;$j['status']='running';$j['last_id']=absint($j['last_id']??0)+1000;$j['summary']['checked']=absint($j['summary']['checked']??0)+1000;
        if($j['summary']['checked']===2000){$j['status']='partial';$j['summary']['status']='partial';$j['summary']['stopped_reason']='max_checks_limit';}
        elseif($j['summary']['checked']>=3000){$j['status']='completed';$j['summary']['status']='completed';$j['summary']['stopped_reason']='';}
        $this->ebay_run_phase_state_save('refresh',$j);return true;}

    private function ebay_selection_state_load(){return $this->ebay_run_phase_state_load('selection');}
    private function ebay_selection_state_is_open($s){return in_array(sanitize_key((string)($s['status']??'')),array('pending','preparing','running'),true);}
    private function ebay_selection_request($reason,$owner,$force,$scope){$this->selection_scope_seen[]=$scope;$s=array('status'=>'pending','phase'=>'prepare','owner'=>$owner,'selection_scope'=>$scope,'step'=>0);$this->ebay_run_phase_state_save('selection',$s);return $s;}
    private function ebay_selection_process_tick($settings,$s){$this->seen_settings[]=$settings;$s['status']='running';$s['step']=absint($s['step']??0)+1;
        $seq=($s['selection_scope']??'all')==='business'?array('business_materialize','business_prune','complete'):array('business_materialize','business_prune','private_prune','private','private_verify','complete');
        $phase=$seq[min(count($seq)-1,$s['step']-1)]; if($phase==='complete'){$s['status']='complete';$s['phase']='complete';}else{$s['phase']=$phase;}
        if(in_array($phase,array('business_materialize','private'),true)){$key=($s['selection_scope']??'all').':'.$phase;$this->materialized[$key]=1;}
        $this->ebay_run_phase_state_save('selection',$s);return $s;}

    // In this orchestrator test public gates are controlled deterministic fixtures.
    private function ebay_run_public_business_coverage(){ $this->coverage_calls++; if($this->gapfill_cannot_fill)return array('required'=>3,'covered'=>1,'missing'=>array('concept-b','concept-c'),'counts'=>array('concept-a'=>1)); if(!$this->gapfilled && $this->coverage_calls<=1)return array('required'=>3,'covered'=>1,'missing'=>array('concept-b','concept-c'),'counts'=>array('concept-a'=>1)); return array('required'=>3,'covered'=>3,'missing'=>array(),'counts'=>array('concept-a'=>1,'concept-b'=>1,'concept-c'=>1)); }
    private function ebay_run_verify_private_public($settings){$this->private_verify_calls++;if(empty($settings['private_enabled']))return array('status'=>'disabled','public'=>0,'invalid'=>array());$this->private_public_mutations++;return array('status'=>'pass','public'=>250,'invalid'=>array());}

    public function start($op='sync'){return $this->ebay_run_start(true,$op);} public function tick(){return $this->run_ebay_admin_ajax_tick();} public function runstate(){return $this->ebay_run_load();}
    public function adopt(){return $this->ebay_run_adopt_legacy_if_needed();}
}

$fail=0;$n=0; function ck($ok,$msg){global$fail,$n;$n++;echo($ok?'PASS ':'FAIL ').$msg."\n";if(!$ok)$fail++;}
function reset_env(){ $GLOBALS['opts']=array();$GLOBALS['scheduled']=array(); }


// V6.42 operational no-server mode: closing the page means no transport request,
// therefore the durable run must remain byte-stable and resume through a new
// authenticated transport request with the same UUID/cursors.
reset_env();
$h=new CanonicalHarness();
$start=$h->start('sync');
$uuid=$start['run_uuid'];
for($i=0;$i<4;$i++){$h->tick();}
$before=$h->runstate();
$before_serial=serialize($before);
// Simulated closed page: intentionally no tick call at all.
$paused=$h->runstate();
ck(serialize($paused)===$before_serial,'closed admin page causes zero hidden workflow mutation');
ck(($paused['run_uuid']??'')===$uuid,'paused run keeps identical run_uuid');
$phase_before=$paused['phase']??'';
$progress_before=absint($paused['progress_seq']??0);
$transport_before=absint($paused['transport_tick_count']??0);
// Simulate reopening the page: a new request object reaches the same persisted options.
$h2=new CanonicalHarness();
$res=$h2->tick();
$after=$h2->runstate();
ck(($after['run_uuid']??'')===$uuid,'reopened page resumes identical persistent run_uuid');
ck(absint($after['transport_tick_count']??0)===$transport_before+1,'reopened page executes exactly one next sequential transport package');
ck(($after['phase']??'')!==$phase_before || absint($after['progress_seq']??0)>=$progress_before,'resume continues from persisted phase/cursor without restart');

echo "ASSERTIONS=$n FAIL=$fail\n";exit($fail?1:0);
