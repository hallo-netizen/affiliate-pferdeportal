<?php
$root=getenv('PPAR_TEST_PLUGIN_DIR');
$master=getenv('PPAR_TEST_MASTER_ROOT');
if(!$root||!$master){fwrite(STDERR,"missing env\n");exit(2);} 
$f=0;$n=0;function ck($v,$m){global$f,$n;$n++;echo($v?'PASS ':'FAIL ').$m."\n";if(!$v)$f++;}
$workflow=file_get_contents($master.'/04_TESTS/V644_ROOTCAUSE/test_business_soft_failure_canonical_workflow_v644.php');
$ebay=file_get_contents($root.'/includes/trait-ppar-ebay.php');
$run=file_get_contents($root.'/includes/trait-ppar-ebay-run.php');
$catalog=json_decode(file_get_contents($root.'/assets/ebay-portal-catalog-v2.json'),true);
$ids=(array)($catalog['business_supply_contract']['required_product_concept_ids']??[]);
$decl=(int)($catalog['business_supply_contract']['required_count']??0);
ck($decl===311&&count(array_unique($ids))===311,'production BUSINESS manifest is exactly 311 unique concepts');
ck(strpos($ebay,'ebay_selection_prepare_business_batch($settings,$state,8)')!==false,'production selection_prepare uses BUSINESS batch size 8');
$expected=(int)ceil(311/8);
ck($expected===39,'monotone BUSINESS prepare upper count is 39 production batches');
$stubs=(strpos($workflow,'private function ebay_selection_request(')!==false)&&(strpos($workflow,'private function ebay_selection_process_tick(')!==false);
ck(!$stubs,'release workflow test must not replace production selection_request/process_tick');
$threeConcepts=strpos($workflow,"return ['concept-a','concept-b','concept-c'];")!==false;
ck(!$threeConcepts,'release workflow test must execute the real 311-concept manifest, not a 3-concept substitute');
$hasPhaseBudget=(strpos($run,'phase_tick_count')!==false||strpos($run,'phase_tick_limit')!==false||strpos($run,'selection_prepare_tick_limit')!==false);
ck($hasPhaseBudget,'canonical worker must enforce a hard per-phase termination budget');
$hasMonotonic=(strpos($run,'prepare_business_index_regressed')!==false||strpos($run,'cursor_regressed')!==false||strpos($run,'progress_regressed')!==false);
ck($hasMonotonic,'canonical worker must fail closed on non-monotonic prepare cursor movement');
echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
