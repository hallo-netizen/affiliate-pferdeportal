<?php
error_reporting(E_ALL); define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A');
$GLOBALS['opts']=array();$GLOBALS['prelease_write_seen']=false;$GLOBALS['rollback_observed']=false;$GLOBALS['inject']=true;
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}function absint($v){return abs((int)$v);}function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}function sanitize_text_field($v){return trim(strip_tags((string)$v));}function wp_json_encode($v,$o=0){return json_encode($v,$o);}function wp_generate_uuid4(){return 'u';}function maybe_serialize($v){return serialize($v);}function wp_cache_delete($a,$b=''){return true;}
function get_option($k,$d=array()){return array_key_exists($k,$GLOBALS['opts'])?$GLOBALS['opts'][$k]:$d;}
function update_option($k,$v,$autoload=false){
    if($k==='run' && !empty($GLOBALS['inject']) && is_array($v) && absint($v['transport_tick_count']??0)===801 && empty($GLOBALS['prelease_write_seen'])){
        // Deterministic interleaving: another request has already advanced the
        // durable selector after this request loaded its old snapshot.
        $advanced=$GLOBALS['opts']['run'];$advanced['phase_state']['selection']['prepare_business_index']=16;$advanced['owner']='other-worker';$advanced['lease_expires_at']=time()+60;$GLOBALS['opts']['run']=$advanced;
        $GLOBALS['prelease_write_seen']=true;
        if(absint($v['phase_state']['selection']['prepare_business_index']??0)<16){$GLOBALS['rollback_observed']=true;}
    }
    $GLOBALS['opts'][$k]=$v;return true;
}
class DB{public $options='wp_options';function prepare($q,...$a){return array('sql'=>$q,'args'=>$a);}function query($p){
    // Candidate path reaches lease acquisition without a pre-lease write. Inject
    // the same concurrent advancement here and make CAS fail. It must survive.
    if(empty($GLOBALS['prelease_write_seen'])){$advanced=$GLOBALS['opts']['run'];$advanced['phase_state']['selection']['prepare_business_index']=16;$advanced['owner']='other-worker';$advanced['lease_expires_at']=time()+60;$GLOBALS['opts']['run']=$advanced;}
    return 0;
}}
$GLOBALS['wpdb']=new DB();
$root=getenv('PPAR_TEST_PLUGIN_DIR');require $root.'/includes/trait-ppar-ebay-run.php';
class H{use PPAR_Ebay_Run_Trait;const OPTION_EBAY_RUN_STATE='run',OPTION_EBAY_SYNC_JOB='sync',OPTION_EBAY_REFRESH_JOB='refresh',OPTION_EBAY_SELECTION_STATE='selection',OPTION_EBAY_MAINTENANCE_STATE='maintenance',OPTION_NETWORK_EBAY='settings',OPTION_EBAY_WORKER_TRANSPORT_MIGRATION='tm';const EBAY_RUNTIME_BUILD='race-test',EBAY_CONTENT_POLICY_VERSION='x',EBAY_PRIVATE_CLASSIFIER_VERSION='x',EBAY_BUSINESS_CLASSIFIER_VERSION='x',EBAY_PROGRESS_CONTRACT_VERSION='2.0';public $ebay_canonical_worker_active=false,$ebay_run_settings_override=null;private function ebay_normalize_settings($s,$k=true){return is_array($s)?$s:array();}private function ebay_settings(){return array('business_enabled'=>1,'private_enabled'=>0,'rules'=>array());}private function ebay_catalog_rules(){return array();}}
$run=array('schema'=>'1.0','build'=>'race-test','run_uuid'=>'same','status'=>'running','phase'=>'selection_prepare','owner'=>'','lease_expires_at'=>0,'worker_transport'=>'admin_ajax','resume_reason'=>'','transport_tick_count'=>800,'progress_seq'=>10,'progress_contract_version'=>'2.0','config_snapshot'=>array('seller_routes'=>array('private'=>0,'business'=>1),'settings'=>array('business_enabled'=>1,'private_enabled'=>0)),'phase_state'=>array('selection'=>array('status'=>'preparing','phase'=>'prepare','selection_scope'=>'business','prepare_business_initialized'=>1,'prepare_business_index'=>8,'business_target_concepts'=>array_fill(0,311,'x'))));update_option('run',$run,false);$GLOBALS['inject']=true;$GLOBALS['prelease_write_seen']=false;$GLOBALS['rollback_observed']=false;
$h=new H();$h->run_ebay_admin_ajax_tick();$after=get_option('run',array());
$f=0;$n=0;function ck($v,$m){global$f,$n;$n++;echo($v?'PASS ':'FAIL ').$m."\n";if(!$v)$f++;}
ck(empty($GLOBALS['prelease_write_seen']),'admin transport performs no durable pre-lease write');
ck(empty($GLOBALS['rollback_observed']),'stale pre-lease snapshot cannot overwrite a concurrently advanced selector');
ck(absint($after['phase_state']['selection']['prepare_business_index']??0)===16,'concurrent durable selector advancement survives failed lease acquisition');
ck(($after['owner']??'')==='other-worker','failed CAS preserves the real concurrent lease owner');
ck(absint($after['transport_tick_count']??0)===800,'rejected concurrent request is not counted as an executed package');
echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
