<?php
error_reporting(E_ALL);
define('ABSPATH','/tmp/');
$GLOBALS['opts']=array();
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}
function absint($v){return abs((int)$v);}function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}function sanitize_text_field($v){return trim(strip_tags((string)$v));}
function wp_json_encode($v,$o=0){return json_encode($v,$o);}function wp_generate_uuid4(){return 'uuid';}
function get_option($k,$d=array()){return array_key_exists($k,$GLOBALS['opts'])?$GLOBALS['opts'][$k]:$d;}function update_option($k,$v,$a=false){$GLOBALS['opts'][$k]=$v;return true;}
$root=getenv('PPAR_TEST_PLUGIN_DIR');if(!$root){fwrite(STDERR,"missing root\n");exit(2);}require $root.'/includes/trait-ppar-ebay-run.php';
class H{
    use PPAR_Ebay_Run_Trait;
    const OPTION_EBAY_RUN_STATE='run',OPTION_EBAY_SYNC_JOB='sync',OPTION_EBAY_REFRESH_JOB='refresh',OPTION_EBAY_SELECTION_STATE='selection',OPTION_EBAY_MAINTENANCE_STATE='maintenance';
    const EBAY_RUNTIME_BUILD='6.45.0-test',EBAY_PROGRESS_CONTRACT_VERSION='2.0',EBAY_CONTENT_POLICY_VERSION='p',EBAY_PRIVATE_CLASSIFIER_VERSION='pc',EBAY_BUSINESS_CLASSIFIER_VERSION='bc',EBAY_WORKER_HOOK='w',EBAY_REFRESH_WORKER_HOOK='rw';
    public $ebay_canonical_worker_active=false,$ebay_run_settings_override=null;
    public function active($run){if(!method_exists($this,'ebay_run_selection_prepare_guard_active'))return false;return $this->ebay_run_selection_prepare_guard_active($run);}public function regress($b,$a){if(!method_exists($this,'ebay_run_selection_prepare_regression'))return new WP_Error('missing_prepare_regression_guard','missing');return $this->ebay_run_selection_prepare_regression($b,$a);}public function tick(){if(!method_exists($this,'ebay_run_selection_prepare_guard_active'))return false;return $this->run_ebay_canonical_worker();}
}
$f=0;$n=0;function ck($v,$m){global$f,$n;$n++;echo($v?'PASS ':'FAIL ').$m."\n";if(!$v)$f++;}
$h=new H();$uuid='gapfill-guard';$base=array('schema'=>'1.0','build'=>H::EBAY_RUNTIME_BUILD,'run_uuid'=>$uuid,'status'=>'running','phase'=>'gapfill_select','started_at'=>1,'finished_at'=>0,'owner'=>'','lease_expires_at'=>0,'worker_transport'=>'admin_ajax','resume_reason'=>'','no_progress_count'=>0,'progress_seq'=>0,'progress_contract_version'=>'2.0','transport_tick_count'=>0,'phase_tick_phase'=>'gapfill_select','phase_tick_count'=>0,'config_snapshot'=>array('seller_routes'=>array('private'=>0,'business'=>1)),'phase_state'=>array('selection'=>array()),'coverage'=>array(),'gapfill'=>array('attempts'=>1,'missing'=>array('concept-a')),'errors'=>array());
$oldTerminal=$base;$oldTerminal['phase_state']['selection']=array('status'=>'complete','phase'=>'complete','reason'=>'canonical_run','owner'=>'run:'.$uuid,'selection_scope'=>'all','prepare_business_initialized'=>1,'prepare_business_index'=>311,'business_target_concepts'=>array_fill(0,311,'x'));
ck($h->active($oldTerminal)===true,'gapfill_select first package is guarded even when the prior full selection is terminal');
$materialize=$base;$materialize['phase_state']['selection']=array('status'=>'running','phase'=>'business_materialize','reason'=>'canonical_gapfill','owner'=>'run:'.$uuid,'selection_scope'=>'business','prepare_business_initialized'=>1,'prepare_business_index'=>1,'business_target_concepts'=>array('concept-a'));
ck($h->active($materialize)===false,'gapfill materialization is not charged against the prepare-only hard budget');
$before=$base;$before['phase_state']['selection']=array('status'=>'preparing','phase'=>'prepare','reason'=>'canonical_gapfill','owner'=>'run:'.$uuid,'selection_scope'=>'business','prepare_business_initialized'=>1,'prepare_business_index'=>16,'business_target_concepts'=>array('a','b','c'));
$after=$before;$after['phase_state']['selection']['prepare_business_index']=8;
$err=$h->regress($before,$after);ck(is_wp_error($err)&&$err->get_error_code()==='selection_prepare_business_cursor_regressed','gapfill nested BUSINESS cursor regression fails closed under the same monotone guard');
$loop=$base;$loop['phase_state']['selection']=array('status'=>'preparing','phase'=>'prepare','reason'=>'canonical_gapfill','owner'=>'run:'.$uuid,'selection_scope'=>'business','prepare_business_initialized'=>1,'prepare_business_index'=>1,'business_target_concepts'=>array('concept-a'));
// One target concept => ceil(1/8)+2 = 3 prepare packages maximum. Seed exactly
// that many already executed packages; the next package must fail before nested work.
$loop['phase_tick_count']=3;update_option('run',$loop,false);$h->tick();$failed=get_option('run',array());
ck(($failed['status']??'')==='failed'&&($failed['error_code']??'')==='selection_prepare_tick_limit_exceeded','moving/stuck gapfill prepare cannot exceed its derived hard package limit');
$details=end($failed['errors']);$details=is_array($details['details']??null)?$details['details']:array();
ck(($details['phase']??'')==='gapfill_select'&&absint($details['phase_tick_count']??0)===4&&absint($details['phase_tick_limit']??0)===3,'gapfill hard-stop records canonical phase, actual package count and derived bound');
echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
