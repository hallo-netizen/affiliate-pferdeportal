<?php
error_reporting(E_ALL);define('ABSPATH','/tmp/');define('ARRAY_A','ARRAY_A');
$GLOBALS['opts']=array();$GLOBALS['inject']=true;$GLOBALS['race_injected']=false;$GLOBALS['rollback_observed']=false;$GLOBALS['legacy_selection_cleared']=false;
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;}function absint($v){return abs((int)$v);}function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}function sanitize_text_field($v){return trim(strip_tags((string)$v));}function wp_json_encode($v,$o=0){return json_encode($v,$o);}function wp_generate_uuid4(){return 'u';}function maybe_serialize($v){return serialize($v);}function maybe_unserialize($v){$x=@unserialize($v);return $x===false&&$v!=='b:0;'?$v:$x;}function wp_cache_delete($a,$b=''){return true;}
function get_option($k,$d=array()){return array_key_exists($k,$GLOBALS['opts'])?$GLOBALS['opts'][$k]:$d;}
function concurrent_advanced_run(){
    $cur=$GLOBALS['opts']['run'];
    $cur['status']='running';$cur['phase']='selection_prepare';$cur['finished_at']=0;$cur['error_code']='';$cur['error_message']='';
    $cur['owner']='worker:other';$cur['lease_expires_at']=time()+60;$cur['worker_transport']='admin_ajax';$cur['resume_reason']='business_materialization_soft_candidate_recovery';
    if(!isset($cur['phase_state'])||!is_array($cur['phase_state']))$cur['phase_state']=array();
    $cur['phase_state']['selection']=array('status'=>'preparing','phase'=>'prepare','selection_scope'=>'business','prepare_business_initialized'=>1,'prepare_business_index'=>16,'business_target_concepts'=>array_fill(0,311,'x'));
    $cur['transport_tick_count']=2;$cur['progress_seq']=2;$cur['updated_at']=time();
    return $cur;
}
function update_option($k,$v,$autoload=false){
    if($k==='selection' && $v===array()){$GLOBALS['legacy_selection_cleared']=true;}
    if($k==='run' && !empty($GLOBALS['inject']) && is_array($v) && ($v['resume_reason']??'')==='business_materialization_soft_candidate_recovery' && empty($GLOBALS['race_injected'])){
        $GLOBALS['opts']['run']=concurrent_advanced_run();$GLOBALS['race_injected']=true;
        if(absint($v['phase_state']['selection']['prepare_business_index']??0)<16){$GLOBALS['rollback_observed']=true;}
    }
    $GLOBALS['opts'][$k]=$v;return true;
}
class DB{public $options='wp_options';function prepare($q,...$a){return array('sql'=>$q,'args'=>$a);}function query($p){
    $a=$p['args'];$after=$a[0];$key=$a[1];$before=$a[2];
    $decoded=maybe_unserialize($after);
    if($key==='run' && !empty($GLOBALS['inject']) && is_array($decoded) && ($decoded['resume_reason']??'')==='business_materialization_soft_candidate_recovery' && empty($GLOBALS['race_injected'])){
        $GLOBALS['opts']['run']=concurrent_advanced_run();$GLOBALS['race_injected']=true;
    }
    $cur=maybe_serialize(get_option($key,array()));if(!hash_equals((string)$before,(string)$cur))return 0;
    $GLOBALS['opts'][$key]=maybe_unserialize($after);return 1;
}}
$GLOBALS['wpdb']=new DB();
$root=getenv('PPAR_TEST_PLUGIN_DIR');require $root.'/includes/trait-ppar-ebay-run.php';
class H{use PPAR_Ebay_Run_Trait;const OPTION_EBAY_RUN_STATE='run',OPTION_EBAY_SYNC_JOB='sync',OPTION_EBAY_REFRESH_JOB='refresh',OPTION_EBAY_SELECTION_STATE='selection',OPTION_EBAY_MAINTENANCE_STATE='maintenance',OPTION_EBAY_WORKER_TRANSPORT_MIGRATION='tm';const EBAY_RUNTIME_BUILD='race-test',EBAY_CONTENT_POLICY_VERSION='x',EBAY_PRIVATE_CLASSIFIER_VERSION='x',EBAY_BUSINESS_CLASSIFIER_VERSION='x',EBAY_PROGRESS_CONTRACT_VERSION='2.0';}
$failed=array(
 'schema'=>'1.0','build'=>'6.44.0-business-materialization-gapfill-rootfix-20260820','run_uuid'=>'same','status'=>'failed','phase'=>'failed','finished_at'=>100,'owner'=>'','lease_expires_at'=>0,'worker_transport'=>'admin_ajax','progress_contract_version'=>'2.0',
 'error_code'=>'business_recovery_incomplete','error_message'=>'old failure','errors'=>array(array('code'=>'business_recovery_incomplete','message'=>'x','at'=>100,'details'=>array('phase'=>'business_materialize'))),
 'phase_state'=>array('selection'=>array('failure_reason'=>'business_recovery_incomplete','stats'=>array('business'=>array('errors'=>array(array('code'=>'ebay_business_materialization_not_active','item_id'=>'soft-1')))))),
 'coverage'=>array('covered'=>0,'missing'=>array('a')),'gapfill'=>array('attempts'=>0,'missing'=>array()),'end_manifest'=>array(),
);
$GLOBALS['opts']['run']=$failed;$GLOBALS['opts']['selection']=array('status'=>'failed','old'=>1);
$h=new H();$h->maybe_migrate_ebay_business_materialization_v6440();$after=get_option('run',array());
$f=0;$n=0;function ck($v,$m){global$f,$n;$n++;echo($v?'PASS ':'FAIL ').$m."\n";if(!$v)$f++;}
ck(!empty($GLOBALS['race_injected']),'deterministic concurrent recovery/worker advancement is injected at migration persistence boundary');
ck(empty($GLOBALS['rollback_observed']),'stale init migration never overwrites a concurrently advanced canonical selection state');
ck(absint($after['phase_state']['selection']['prepare_business_index']??0)===16,'concurrently advanced BUSINESS prepare cursor survives losing init migration');
ck((string)($after['owner']??'')==='worker:other','concurrent worker lease survives losing init migration');
ck(absint($after['transport_tick_count']??0)===2,'concurrent worker package accounting survives losing init migration');
ck(empty($GLOBALS['legacy_selection_cleared']),'losing stale migration performs zero secondary legacy-selection mutation');
echo "ASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
