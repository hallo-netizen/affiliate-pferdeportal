<?php
error_reporting(E_ALL);
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A'); define('HOUR_IN_SECONDS',3600); define('DAY_IN_SECONDS',86400);
$GLOBALS['opts']=array();
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;} function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_title($v){$v=strtolower(strtr((string)$v,array('ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss')));return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function wp_json_encode($v,$o=0){return json_encode($v,$o);} function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return strtr((string)$v,array('ä'=>'a','ö'=>'o','ü'=>'u','ß'=>'ss'));}
function esc_url_raw($v){return $v;} function wp_http_validate_url($v){return true;} function apply_filters($a,$b){return $b;} function wp_doing_ajax(){return false;} function current_user_can(){return true;}
function get_option($k,$d=array()){return array_key_exists($k,$GLOBALS['opts'])?$GLOBALS['opts'][$k]:$d;} function update_option($k,$v,$autoload=false){$GLOBALS['opts'][$k]=$v;return true;}
function maybe_serialize($v){return serialize($v);} function maybe_unserialize($v){$x=@unserialize($v);return $x===false&&$v!=='b:0;'?$v:$x;} function wp_cache_delete($a,$b=''){return true;} function wp_generate_uuid4(){return '11111111-1111-4111-8111-111111111111';}
function wp_next_scheduled($h){return false;} function wp_schedule_single_event($t,$h){return true;} function wp_clear_scheduled_hook($h){return 1;}
function get_post_meta(){return '';} function get_post_status(){return '';} function get_post_type(){return '';} function update_post_meta(){return true;} function wp_update_post(){return 1;}
class DB{
    public $prefix='wp_',$options='wp_options',$queries=array();
    function prepare($q,...$args){return array('sql'=>$q,'args'=>$args);}
    private function render($p){if(!is_array($p))return (string)$p;$q=(string)($p['sql']??'');foreach((array)($p['args']??array()) as $v){$rep=is_numeric($v)?(string)$v:"'".str_replace("'","''",(string)$v)."'";$q=preg_replace('/%[sd]/',$rep,$q,1);}return $q;}
    function query($p){$this->queries[]=$p;if(!is_array($p))return 0;$sql=(string)($p['sql']??'');$a=(array)($p['args']??array());if(strpos($sql,'UPDATE '.$this->options.' SET option_value=')===0){$after=$a[0]??'';$key=$a[1]??'';$before=$a[2]??'';$cur=maybe_serialize(get_option($key,array()));if(!hash_equals((string)$before,(string)$cur))return 0;$GLOBALS['opts'][$key]=maybe_unserialize($after);return 1;}return 0;}
    function get_col($q){$this->queries[]=$q;$q=$this->render($q); if(strpos($q,"SELECT DISTINCT target_term_id")!==false){return array(101,102,103,104,105,106,107,108);} return array();}
    function get_row($q,$mode=null){$this->queries[]=$q;return null;}
    function get_results($q,$mode=null){
        $this->queries[]=$q;$q=$this->render($q);
        if(strpos($q,"seller_account_type='INDIVIDUAL'")!==false && preg_match('/target_term_id=(\d+).*LIMIT (\d+) OFFSET (\d+)/',$q,$m)){
            $leaf=(int)$m[1];$limit=(int)$m[2];$offset=(int)$m[3];$max=125;
            if($offset>=$max)return array();
            $take=min($limit,$max-$offset);$rows=array();
            for($i=0;$i<$take;$i++){
                $n=$offset+$i+1;
                $rows[]=array('id'=>$leaf*1000+$n,'item_id'=>'private-'.$leaf.'-'.$n,'target_term_id'=>$leaf,'listing_post_id'=>0,'image_url'=>'','last_seen'=>100000-$n,'rule_id'=>'','title'=>'invalid fixture row','source_payload'=>'{}');
            }
            return $rows;
        }
        // BUSINESS source fixtures intentionally empty; the real selector still
        // traverses all 311 product identities and persists the real cursor.
        return array();
    }
}
$GLOBALS['wpdb']=new DB();
$root=getenv('PPAR_TEST_PLUGIN_DIR'); if(!$root){fwrite(STDERR,"missing root\n");exit(2);} require $root.'/includes/trait-ppar-ebay.php'; require $root.'/includes/trait-ppar-ebay-run.php';
class H{
    use PPAR_Ebay_Trait; use PPAR_Ebay_Run_Trait;
    const OPTION_EBAY_RUN_STATE='run',OPTION_EBAY_SYNC_JOB='sync',OPTION_EBAY_REFRESH_JOB='refresh',OPTION_EBAY_SELECTION_STATE='selection',OPTION_EBAY_MAINTENANCE_STATE='maintenance',OPTION_NETWORK_EBAY='settings',OPTION_EBAY_CONTENT_FILTER_STATE='cf',OPTION_EBAY_BUSINESS_MATCH_STATE='bm',OPTION_EBAY_SCHEMA_VERSION='schema',OPTION_EBAY_WORKER_TRANSPORT_MIGRATION='tm';
    const EBAY_RUNTIME_BUILD='6.45.0-test',EBAY_CONTENT_POLICY_VERSION='6.1',EBAY_PRIVATE_CLASSIFIER_VERSION='4.0',EBAY_BUSINESS_CLASSIFIER_VERSION='6.1',EBAY_PROGRESS_CONTRACT_VERSION='2.0',EBAY_SCHEMA_VERSION='2.0',EBAY_MAINTENANCE_CRON_HOOK='mc',EBAY_MEDIA_CLEANUP_HOOK='mcl',EBAY_MEDIA_CLEANUP_VERSION='1.1',EBAY_CRON_HOOK='ec',EBAY_WORKER_HOOK='ew',EBAY_REFRESH_CRON_HOOK='rc',EBAY_REFRESH_WORKER_HOOK='rw';
    public $ebay_canonical_worker_active=false,$ebay_run_settings_override=null;
    private function ebay_normalize_settings($s,$keep=true){return is_array($s)?$s:array();}
    private function ebay_settings(){return is_array($this->ebay_run_settings_override)?$this->ebay_run_settings_override:array('enabled'=>1,'private_enabled'=>1,'business_enabled'=>1,'private_auto_publish'=>1,'private_active_cap'=>250,'private_leaf_cap'=>30,'business_active_cap'=>1000,'business_candidate_pool_per_concept'=>10,'business_reserve_per_concept'=>2,'business_max_same_seller_per_block'=>1,'rules'=>array());}
    private function ebay_selection_scope_for_enabled_routes($scope,$s){$p=!empty($s['private_enabled']);$b=!empty($s['business_enabled']);return $p&&$b?'all':($p?'private':($b?'business':''));}
    private function ebay_remote_image_url_validate($u){return $u;}
    public function tick(){return $this->run_ebay_admin_ajax_tick();}
    public function state(){return $this->ebay_run_load();}
    public function required(){return $this->ebay_business_required_product_concept_ids();}
}
$f=0;$n=0; function ck($v,$m){global$f,$n;$n++;echo($v?'PASS ':'FAIL ').$m."\n";if(!$v)$f++;}
$h=new H();$required=$h->required();ck(count($required)===311&&count(array_unique($required))===311,'real ALL-route fixture uses the production 311-family BUSINESS manifest');
$uuid='110e36b0-ad6-live-all-routes';
$run=array('schema'=>'1.0','build'=>'6.44.0-business-materialization-gapfill-rootfix-20260820','run_uuid'=>$uuid,'status'=>'running','phase'=>'selection_prepare','operation'=>'refresh','started_at'=>time()-1000,'finished_at'=>0,'owner'=>'','lease_expires_at'=>0,'worker_transport'=>'admin_ajax','resume_reason'=>'business_materialization_soft_candidate_recovery','no_progress_count'=>0,'progress_seq'=>537,'progress_contract_version'=>'2.0','transport_tick_count'=>800,'last_transport_tick_at'=>time()-10,'config_snapshot'=>array('seller_routes'=>array('private'=>1,'business'=>1),'settings'=>array('enabled'=>1,'private_enabled'=>1,'business_enabled'=>1,'private_auto_publish'=>1,'private_active_cap'=>250,'private_leaf_cap'=>30,'business_active_cap'=>1000,'business_candidate_pool_per_concept'=>10,'business_reserve_per_concept'=>2,'business_max_same_seller_per_block'=>1)),'phase_state'=>array(),'coverage'=>array('required'=>311,'covered'=>0,'missing'=>array()),'gapfill'=>array('attempts'=>0,'missing'=>array()),'errors'=>array());
update_option('run',$run,false);
$ticks=0;$failed=false;$same=true;$businessMono=true;$privateMono=true;$lastBusiness=0;$lastLeaf=0;$lastScanned=0;$privateSeen=false;
while($ticks<70){$r=$h->state();if(($r['phase']??'')!=='selection_prepare')break;$h->tick();$ticks++;$a=$h->state();$same=$same&&(($a['run_uuid']??'')===$uuid);if(($a['status']??'')==='failed'){$failed=true;break;}$s=(array)($a['phase_state']['selection']??array());$bi=absint($s['prepare_business_index']??0);if($bi<$lastBusiness)$businessMono=false;$lastBusiness=$bi;if(!empty($s['prepare_private_initialized'])){$privateSeen=true;$li=absint($s['prepare_private_leaf_index']??0);$sc=absint($s['prepare_private_scanned']??0);if($li<$lastLeaf||$sc<$lastScanned)$privateMono=false;$lastLeaf=$li;$lastScanned=$sc;}}
$final=$h->state();$sel=(array)($final['phase_state']['selection']??array());
ck(!$failed,'old V6.44 ALL-route live-class run resumes without failure');
ck($same,'ALL-route recovery keeps the identical canonical run UUID');
ck($businessMono&&$lastBusiness===311,'real BUSINESS prepare cursor is monotone and reaches all 311 families');
ck($privateSeen&&$privateMono,'real PRIVATE prepare cursors are initialized and remain monotone after BUSINESS prepare');
ck(absint($sel['prepare_private_scanned']??0)===1000,'real PRIVATE prepare consumes the configured bounded 1,000-candidate fixture and no more');
ck(absint($sel['prepare_private_leaf_index']??0)===8,'real PRIVATE prepare completes all eight coarse fixture leaves');
ck($ticks===48,'combined real 311-family BUSINESS plus bounded 1,000-row PRIVATE prepare exits in exactly 48 acquired packages (final BUSINESS batch also starts PRIVATE prepare)');
ck(($final['phase']??'')==='business_select','combined ALL-route selection_prepare advances to the BUSINESS select checkpoint');
ck(absint($final['transport_tick_count']??0)===848,'historical 800 transport packages are preserved and only 48 newly acquired packages are added');
ck(absint($final['phase_tick_count']??0)===48 && absint($final['selection_prepare_tick_limit']??0)===53,'combined prepare stays below the derived 53-package hard phase limit');
ck(absint($final['no_progress_count']??0)===0,'every real combined prepare package is recognized as genuine workflow progress');
echo "ASSERTIONS=$n FAIL=$f TICKS=$ticks BUSINESS=$lastBusiness PRIVATE_SCANNED=".absint($sel['prepare_private_scanned']??0)." PHASE=".($final['phase']??'')." LIMIT=".absint($final['selection_prepare_tick_limit']??0)."\n";exit($f?1:0);
