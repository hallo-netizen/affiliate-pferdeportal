<?php
$root=getenv('PPAR_TEST_PLUGIN_DIR');$base=getenv('PPAR_BASELINE_PLUGIN_DIR');if(!$root||!$base)exit(2);
$main=file_get_contents($root.'/pferdeportal-affiliate-router.php');$readme=file_get_contents($root.'/readme.txt');$run=file_get_contents($root.'/includes/trait-ppar-ebay-run.php');
$f=0;$n=0;function ck($v,$m){global$f,$n;$n++;echo($v?'PASS ':'FAIL ').$m."\n";if(!$v)$f++;}
ck(strpos($main,"const VERSION = '6.45.0';")!==false&&strpos($main,'Version: 6.45.0')!==false&&strpos($readme,'Stable tag: 6.45.0')!==false&&strpos($main,'6.45.0-canonical-run-persistence-race-rootfix-20260820')!==false,'header/runtime/readme identify one consolidated V6.45.0 build');
ck(strpos($run,'private function ebay_run_compare_and_swap')!==false,'state-only migrations have a canonical compare-and-swap primitive');
ck(substr_count($run,'ebay_run_compare_and_swap(')>=6,'all run-state migration families route through CAS instead of stale whole-snapshot saves');
ck(strpos($run,"selection_prepare_tick_limit_exceeded")!==false&&strpos($run,'ebay_run_selection_prepare_regression')!==false,'selection_prepare has hard termination and monotone-cursor fail-closed guards');
ck(strpos($run,'private function ebay_run_selection_prepare_guard_active')!==false&&strpos($run,"\$phase!=='gapfill_select'")!==false,'the same prepare guard explicitly covers targeted canonical gapfill_select');
ck(strpos($run,"array('selection_prepare','gapfill_select')")!==false,'monotone prepare-cursor regression guard covers both initial selection and targeted gap-fill');
$adminStart=strpos($run,'public function run_ebay_admin_ajax_tick()');$workerCall=strpos($run,'return $this->run_ebay_canonical_worker();',$adminStart);$pre=substr($run,$adminStart,$workerCall-$adminStart);ck(strpos($pre,'ebay_run_save(')===false,'admin AJAX transport performs no durable pre-lease run save');
$allowed=['pferdeportal-affiliate-router.php','includes/trait-ppar-ebay-run.php','readme.txt'];$changed=[];$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));foreach($it as$p){if(!$p->isFile())continue;$rel=substr($p->getPathname(),strlen($root)+1);$bp=$base.'/'.$rel;if(!file_exists($bp)){continue;}if(hash_file('sha256',$p->getPathname())!==hash_file('sha256',$bp)){$changed[]=$rel;ck(in_array($rel,$allowed,true),'changed production file remains in V6.45 root-cause scope: '.$rel);}}
sort($changed);sort($allowed);ck($changed===$allowed,'exactly three production files changed versus V6.44 baseline');
echo 'CHANGED='.implode(',',$changed)."\nASSERTIONS=$n FAIL=$f\n";exit($f?1:0);
