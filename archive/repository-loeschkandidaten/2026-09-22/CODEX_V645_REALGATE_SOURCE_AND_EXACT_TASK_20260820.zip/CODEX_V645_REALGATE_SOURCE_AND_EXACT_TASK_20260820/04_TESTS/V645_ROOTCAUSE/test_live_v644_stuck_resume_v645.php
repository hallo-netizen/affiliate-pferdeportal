<?php
error_reporting(E_ALL);
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A'); define('HOUR_IN_SECONDS',3600); define('DAY_IN_SECONDS',86400);
$GLOBALS['opts']=array();
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;} function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_title($v){$v=strtolower(strtr((string)$v,array('ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss')));return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function wp_json_encode($v,$o=0){return json_encode($v,$o);} function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return strtr((string)$v,array('ä'=>'a','ö'=>'o','ü'=>'u','ß'=>'ss'));}
function esc_url_raw($v){return $v;} function wp_http_validate_url($v){return true;} function apply_filters($a,$b){return $b;} function wp_doing_ajax(){return false;} function current_user_can(){return true;}
function get_option($k,$d=array()){return array_key_exists($k,$GLOBALS['opts'])?$GLOBALS['opts'][$k]:$d;} function update_option($k,$v,$autoload=false){$GLOBALS['opts'][$k]=$v;return true;}
function maybe_serialize($v){return serialize($v);} function maybe_unserialize($v){$x=@unserialize($v);return $x===false&&$v!=='b:0;'?$v:$x;} function wp_cache_delete($a,$b=''){return true;} function wp_generate_uuid4(){return '11111111-1111-4111-8111-111111111111';}
function wp_next_scheduled($h){return false;} function wp_schedule_single_event($t,$h){return true;} function wp_clear_scheduled_hook($h){return 1;}
function get_post_meta(){return '';} function get_post_status(){return '';} function get_post_type(){return '';} function update_post_meta(){return true;} function wp_update_post(){return 1;}
class DB{
    public $prefix='wp_',$options='wp_options',$queries=array();
    function prepare($q,...$args){return array('sql'=>$q,'args'=>$args);}
    function query($p){$this->queries[]=$p; if(!is_array($p))return 0; $sql=$p['sql'];$a=$p['args']; if(strpos($sql,'UPDATE '.$this->options.' SET option_value=')===0){$after=$a[0]??'';$key=$a[1]??'';$before=$a[2]??'';$cur=maybe_serialize(get_option($key,array())); if(!hash_equals((string)$before,(string)$cur))return 0; $GLOBALS['opts'][$key]=maybe_unserialize($after); return 1;} return 0;}
    function get_results($q,$mode=null){$this->queries[]=$q;return array();}
    function get_row($q,$mode=null){$this->queries[]=$q;return null;}
    function get_col($q){$this->queries[]=$q;return array();}
}
$GLOBALS['wpdb']=new DB();
$root=getenv('PPAR_TEST_PLUGIN_DIR'); if(!$root){fwrite(STDERR,"missing root\n");exit(2);} require $root.'/includes/trait-ppar-ebay.php'; require $root.'/includes/trait-ppar-ebay-run.php';
class H{
    use PPAR_Ebay_Trait; use PPAR_Ebay_Run_Trait;
    const OPTION_EBAY_RUN_STATE='run',OPTION_EBAY_SYNC_JOB='sync',OPTION_EBAY_REFRESH_JOB='refresh',OPTION_EBAY_SELECTION_STATE='selection',OPTION_EBAY_MAINTENANCE_STATE='maintenance',OPTION_NETWORK_EBAY='settings',OPTION_EBAY_CONTENT_FILTER_STATE='cf',OPTION_EBAY_BUSINESS_MATCH_STATE='bm',OPTION_EBAY_SCHEMA_VERSION='schema',OPTION_EBAY_WORKER_TRANSPORT_MIGRATION='tm';
    const EBAY_RUNTIME_BUILD='6.45.0-test',EBAY_CONTENT_POLICY_VERSION='6.1',EBAY_PRIVATE_CLASSIFIER_VERSION='4.0',EBAY_BUSINESS_CLASSIFIER_VERSION='6.1',EBAY_PROGRESS_CONTRACT_VERSION='2.0',EBAY_SCHEMA_VERSION='2.0',EBAY_MAINTENANCE_CRON_HOOK='mc',EBAY_MEDIA_CLEANUP_HOOK='mcl',EBAY_MEDIA_CLEANUP_VERSION='1.1',EBAY_CRON_HOOK='ec',EBAY_WORKER_HOOK='ew',EBAY_REFRESH_CRON_HOOK='rc',EBAY_REFRESH_WORKER_HOOK='rw';
    public $ebay_canonical_worker_active=false,$ebay_run_settings_override=null;
    private function ebay_normalize_settings($s,$keep=true){return is_array($s)?$s:array();}
    private function ebay_settings(){return is_array($this->ebay_run_settings_override)?$this->ebay_run_settings_override:array('enabled'=>1,'private_enabled'=>0,'business_enabled'=>1,'business_active_cap'=>1000,'business_candidate_pool_per_concept'=>10,'business_reserve_per_concept'=>2,'business_max_same_seller_per_block'=>1,'rules'=>array());}
    private function ebay_selection_scope_for_enabled_routes($scope,$s){$p=!empty($s['private_enabled']);$b=!empty($s['business_enabled']);return $p&&$b?'all':($p?'private':($b?'business':''));}
    private function ebay_remote_image_url_validate($u){return $u;}
    public function tick(){return $this->run_ebay_admin_ajax_tick();}
    public function state(){return $this->ebay_run_load();}
}
$f=0;$n=0; function ck($v,$m){global$f,$n;$n++;echo($v?'PASS ':'FAIL ').$m."\n";if(!$v)$f++;}
function old_open_run($uuid,$selection=array()){
    return array('schema'=>'1.0','build'=>'6.44.0-business-materialization-gapfill-rootfix-20260820','run_uuid'=>$uuid,'status'=>'running','phase'=>'selection_prepare','operation'=>'refresh','started_at'=>time()-1000,'finished_at'=>0,'owner'=>'','lease_expires_at'=>0,'worker_transport'=>'admin_ajax','resume_reason'=>'business_materialization_soft_candidate_recovery','no_progress_count'=>0,'progress_seq'=>537,'progress_contract_version'=>'2.0','transport_tick_count'=>800,'last_transport_tick_at'=>time()-10,'config_snapshot'=>array('seller_routes'=>array('private'=>0,'business'=>1),'settings'=>array('enabled'=>1,'private_enabled'=>0,'business_enabled'=>1,'business_active_cap'=>1000,'business_candidate_pool_per_concept'=>10,'business_reserve_per_concept'=>2,'business_max_same_seller_per_block'=>1)),'phase_state'=>$selection?array('selection'=>$selection):array(),'coverage'=>array('required'=>311,'covered'=>0,'missing'=>array()),'gapfill'=>array('attempts'=>0,'missing'=>array()),'errors'=>array());
}
$h=new H();
// Case A: the exact live-visible class -- old build, same open phase, very high old transport count,
// but no usable nested selection cursor. V6.45 must not create a new UUID or use old transport count as phase budget.
$uuidA='110e36b0-ad6-live-empty'; update_option('run',old_open_run($uuidA),false);
$ticksA=0;$sameA=true;$failedA=false;$monoA=true;$lastA=0;
while($ticksA<60){$r=$h->state();if(($r['phase']??'')!=='selection_prepare')break;$h->tick();$ticksA++;$a=$h->state();$sameA=$sameA&&(($a['run_uuid']??'')===$uuidA);if(($a['status']??'')==='failed'){$failedA=true;break;}$idx=absint($a['phase_state']['selection']['prepare_business_index']??0);if($idx<$lastA)$monoA=false;$lastA=$idx;}
$finalA=$h->state();
ck(!$failedA,'old open V6.44 live-class run with empty nested selection resumes without failure');
ck($sameA,'old open V6.44 live-class run keeps the identical UUID');
ck($monoA && $lastA===311,'empty/corrupt derived selection is rebuilt monotonically to the real 311-family boundary');
ck($ticksA===39 && ($finalA['phase']??'')==='business_select','old 800-transport-count run ignores historical tick total and exits selection_prepare in the real 39-package bound');
ck(absint($finalA['transport_tick_count']??0)===839,'only newly acquired V6.45 worker packages are added to the historical transport count');

// Case B: a partially advanced old V6.44 state. Generate a real persisted 8-family state first, then
// rewrite only old-build metadata to model an upgrade while preserving the actual derived cursor.
$GLOBALS['opts']=array();$uuidB='110e36b0-ad6-live-partial';update_option('run',old_open_run($uuidB),false);$h=new H();$h->tick();$partial=$h->state();
ck(absint($partial['phase_state']['selection']['prepare_business_index']??0)===8,'fixture obtains a real persisted 8-family selection_prepare checkpoint');
$partial['build']='6.44.0-business-materialization-gapfill-rootfix-20260820';$partial['run_uuid']=$uuidB;$partial['transport_tick_count']=800;$partial['progress_seq']=537;$partial['phase']='selection_prepare';$partial['status']='running';$partial['owner']='';$partial['lease_expires_at']=0;$partial['worker_transport']='admin_ajax';$partial['resume_reason']='business_materialization_soft_candidate_recovery';unset($partial['phase_tick_phase'],$partial['phase_tick_count'],$partial['selection_prepare_tick_limit']);update_option('run',$partial,false);
$ticksB=0;$lastB=8;$monoB=true;$sameB=true;$failedB=false;
while($ticksB<60){$r=$h->state();if(($r['phase']??'')!=='selection_prepare')break;$h->tick();$ticksB++;$a=$h->state();$sameB=$sameB&&(($a['run_uuid']??'')===$uuidB);if(($a['status']??'')==='failed'){$failedB=true;break;}$idx=absint($a['phase_state']['selection']['prepare_business_index']??0);if($idx<$lastB)$monoB=false;$lastB=$idx;}
$finalB=$h->state();
ck(!$failedB && $sameB,'partially advanced V6.44 checkpoint resumes under V6.45 without failure or UUID replacement');
ck($monoB && $lastB===311,'partially advanced real BUSINESS cursor never regresses and reaches 311');
ck($ticksB===38 && ($finalB['phase']??'')==='business_select','8-family V6.44 checkpoint needs exactly the remaining 38 real 8-family packages');
ck(absint($finalB['transport_tick_count']??0)===838,'rejected historical package history is preserved while only 38 new acquired packages are counted');
echo "ASSERTIONS=$n FAIL=$f CASE_A_TICKS=$ticksA CASE_B_TICKS=$ticksB\n";exit($f?1:0);
