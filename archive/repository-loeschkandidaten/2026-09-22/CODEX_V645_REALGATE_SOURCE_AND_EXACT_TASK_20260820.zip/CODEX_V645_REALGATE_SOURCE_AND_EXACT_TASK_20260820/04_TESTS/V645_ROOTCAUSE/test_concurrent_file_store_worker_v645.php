<?php
error_reporting(E_ALL);
define('ABSPATH','/tmp/'); define('ARRAY_A','ARRAY_A'); define('HOUR_IN_SECONDS',3600); define('DAY_IN_SECONDS',86400);
$store=sys_get_temp_dir().'/ppar-v645-concurrent-'.getmypid().'-'.bin2hex(random_bytes(4)).'.ser';
$GLOBALS['store_path']=$store;
file_put_contents($store,serialize(array()));
function store_read_all(){ $p=$GLOBALS['store_path']; $fh=fopen($p,'c+'); flock($fh,LOCK_SH); rewind($fh); $raw=stream_get_contents($fh); $all=$raw!==''?@unserialize($raw):array(); if(!is_array($all))$all=array(); flock($fh,LOCK_UN); fclose($fh); return $all; }
function store_update($fn){ $p=$GLOBALS['store_path']; $fh=fopen($p,'c+'); flock($fh,LOCK_EX); rewind($fh); $raw=stream_get_contents($fh); $all=$raw!==''?@unserialize($raw):array(); if(!is_array($all))$all=array(); $ret=$fn($all); ftruncate($fh,0); rewind($fh); fwrite($fh,serialize($all)); fflush($fh); flock($fh,LOCK_UN); fclose($fh); return $ret; }
class WP_Error{private $c,$m;function __construct($c='',$m=''){$this->c=$c;$this->m=$m;}function get_error_code(){return $this->c;}function get_error_message(){return $this->m;}}
function is_wp_error($x){return $x instanceof WP_Error;} function absint($v){return abs((int)$v);} function sanitize_key($v){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$v));}
function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_title($v){$v=strtolower(strtr((string)$v,array('ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss')));return trim(preg_replace('/[^a-z0-9]+/','-',$v),'-');}
function wp_json_encode($v,$o=0){return json_encode($v,$o);} function wp_strip_all_tags($v){return strip_tags((string)$v);} function remove_accents($v){return strtr((string)$v,array('ä'=>'a','ö'=>'o','ü'=>'u','ß'=>'ss'));}
function esc_url_raw($v){return $v;} function wp_http_validate_url($v){return true;} function apply_filters($a,$b){return $b;} function wp_doing_ajax(){return false;} function current_user_can(){return true;}
function get_option($k,$d=array()){ $all=store_read_all(); return array_key_exists($k,$all)?$all[$k]:$d; }
function update_option($k,$v,$autoload=false){ return store_update(function(&$all)use($k,$v){$all[$k]=$v;return true;}); }
function maybe_serialize($v){return serialize($v);} function maybe_unserialize($v){$x=@unserialize($v);return $x===false&&$v!=='b:0;'?$v:$x;} function wp_cache_delete($a,$b=''){return true;} function wp_generate_uuid4(){return '11111111-1111-4111-8111-111111111111';}
function wp_next_scheduled($h){return false;} function wp_schedule_single_event($t,$h){return true;} function wp_clear_scheduled_hook($h){return 1;}
function get_post_meta(){return '';} function get_post_status(){return '';} function get_post_type(){return '';} function update_post_meta(){return true;} function wp_update_post(){return 1;}
class DB{
    public $prefix='wp_',$options='wp_options';
    function prepare($q,...$args){return array('sql'=>$q,'args'=>$args);}
    function query($p){ if(!is_array($p))return 0; $sql=(string)($p['sql']??'');$a=(array)($p['args']??array()); if(strpos($sql,'UPDATE '.$this->options.' SET option_value=')===0){$after=(string)($a[0]??'');$key=(string)($a[1]??'');$before=(string)($a[2]??'');return store_update(function(&$all)use($after,$key,$before){$cur=maybe_serialize($all[$key]??array());if(!hash_equals($before,$cur))return 0;$all[$key]=maybe_unserialize($after);return 1;});} return 0; }
    function get_results($q,$mode=null){ usleep(50000); return array(); }
    function get_row($q,$mode=null){return null;} function get_col($q){return array();}
}
$GLOBALS['wpdb']=new DB();
$root=getenv('PPAR_TEST_PLUGIN_DIR'); if(!$root){fwrite(STDERR,"missing root\n");@unlink($store);exit(2);} require $root.'/includes/trait-ppar-ebay.php'; require $root.'/includes/trait-ppar-ebay-run.php';
class H{
    use PPAR_Ebay_Trait; use PPAR_Ebay_Run_Trait;
    const OPTION_EBAY_RUN_STATE='run',OPTION_EBAY_SYNC_JOB='sync',OPTION_EBAY_REFRESH_JOB='refresh',OPTION_EBAY_SELECTION_STATE='selection',OPTION_EBAY_MAINTENANCE_STATE='maintenance',OPTION_NETWORK_EBAY='settings',OPTION_EBAY_CONTENT_FILTER_STATE='cf',OPTION_EBAY_BUSINESS_MATCH_STATE='bm',OPTION_EBAY_SCHEMA_VERSION='schema',OPTION_EBAY_WORKER_TRANSPORT_MIGRATION='tm';
    const EBAY_RUNTIME_BUILD='6.45.0-test',EBAY_CONTENT_POLICY_VERSION='6.1',EBAY_PRIVATE_CLASSIFIER_VERSION='4.0',EBAY_BUSINESS_CLASSIFIER_VERSION='6.1',EBAY_PROGRESS_CONTRACT_VERSION='2.0',EBAY_SCHEMA_VERSION='2.0',EBAY_MAINTENANCE_CRON_HOOK='mc',EBAY_MEDIA_CLEANUP_HOOK='mcl',EBAY_MEDIA_CLEANUP_VERSION='1.1',EBAY_CRON_HOOK='ec',EBAY_WORKER_HOOK='ew',EBAY_REFRESH_CRON_HOOK='rc',EBAY_REFRESH_WORKER_HOOK='rw';
    public $ebay_canonical_worker_active=false,$ebay_run_settings_override=null;
    private function ebay_normalize_settings($s,$keep=true){return is_array($s)?$s:array();}
    private function ebay_settings(){return is_array($this->ebay_run_settings_override)?$this->ebay_run_settings_override:array('enabled'=>1,'private_enabled'=>0,'business_enabled'=>1,'business_active_cap'=>1000,'business_candidate_pool_per_concept'=>10,'business_reserve_per_concept'=>2,'business_max_same_seller_per_block'=>1,'rules'=>array());}
    private function ebay_selection_scope_for_enabled_routes($scope,$s){$p=!empty($s['private_enabled']);$b=!empty($s['business_enabled']);return $p&&$b?'all':($p?'private':($b?'business':''));}
    private function ebay_remote_image_url_validate($u){return $u;}
    public function tick(){return $this->run_ebay_admin_ajax_tick();} public function state(){return $this->ebay_run_load();}
}
$f=0;$n=0; function ck($v,$m){global$f,$n;$n++;echo($v?'PASS ':'FAIL ').$m."\n";if(!$v)$f++;}
$uuid='concurrent-file-store-v645';
$run=array('schema'=>'1.0','build'=>H::EBAY_RUNTIME_BUILD,'run_uuid'=>$uuid,'status'=>'running','phase'=>'selection_prepare','operation'=>'refresh','started_at'=>time(),'finished_at'=>0,'owner'=>'','lease_expires_at'=>0,'worker_transport'=>'admin_ajax','resume_reason'=>'','no_progress_count'=>0,'progress_seq'=>0,'progress_contract_version'=>'2.0','transport_tick_count'=>0,'config_snapshot'=>array('seller_routes'=>array('private'=>0,'business'=>1),'settings'=>array('enabled'=>1,'private_enabled'=>0,'business_enabled'=>1,'business_active_cap'=>1000,'business_candidate_pool_per_concept'=>10,'business_reserve_per_concept'=>2,'business_max_same_seller_per_block'=>1)),'phase_state'=>array(),'coverage'=>array(),'gapfill'=>array('attempts'=>0,'missing'=>array()),'errors'=>array());
update_option('run',$run,false);
$barrier=$store.'.go';$results=array();$children=array();
for($i=0;$i<5;$i++){
    $pid=pcntl_fork();
    if($pid===0){while(!file_exists($barrier)){usleep(1000);} $h=new H();$ret=$h->tick();$st=$h->state();file_put_contents($store.'.child.'.getmypid(),serialize(array('returned'=>is_array($ret),'transport'=>absint($st['transport_tick_count']??0),'cursor'=>absint($st['phase_state']['selection']['prepare_business_index']??0),'owner'=>(string)($st['owner']??''))));exit(0);} $children[]=$pid;
}
usleep(50000);file_put_contents($barrier,'go');foreach($children as $pid){pcntl_waitpid($pid,$status);}
$after=get_option('run',array());
ck(absint($after['transport_tick_count']??0)===1,'five simultaneous file-backed requests execute exactly one acquired canonical package');
ck(absint($after['phase_state']['selection']['prepare_business_index']??0)===8,'winning concurrent request persists exactly one real 8-family BUSINESS batch');
ck((string)($after['owner']??'')===''&&absint($after['lease_expires_at']??0)===0,'winning request releases the durable lease after progress accounting');
ck(($after['run_uuid']??'')===$uuid,'concurrent requests preserve the immutable run UUID');
ck(absint($after['no_progress_count']??0)===0,'rejected concurrent requests do not create false no-progress accounting');
$h=new H();$extra=0;while(($h->state()['phase']??'')==='selection_prepare'&&$extra<50){$h->tick();$extra++;}$final=$h->state();
ck($extra===38,'after the concurrent first package only the remaining 38 real BUSINESS packages are required');
ck(absint($final['transport_tick_count']??0)===39,'transport count equals the 39 actually acquired packages after concurrent plus sequential completion');
ck(absint($final['phase_state']['selection']['prepare_business_index']??0)===311,'file-backed persistent selector reaches the complete 311-family cursor');
ck(($final['phase']??'')==='business_select'&&($final['status']??'')==='running','file-backed concurrent run terminates selection_prepare at the canonical business_select checkpoint');
ck(absint($final['phase_tick_count']??0)===39&&absint($final['selection_prepare_tick_limit']??0)>=39,'hard phase budget remains coherent after real process concurrency');
foreach(glob($store.'.child.*')?:array() as $p)@unlink($p);@unlink($barrier);@unlink($store);
echo "ASSERTIONS=$n FAIL=$f EXTRA=$extra FINAL_TRANSPORT=".absint($final['transport_tick_count']??0)." CURSOR=".absint($final['phase_state']['selection']['prepare_business_index']??0)."\n";exit($f?1:0);
