# CODEX-AUFTRAG – V6.45 REAL-GATE MIT ECHTEM WORDPRESS + ECHTER MARIADB

## 0. STATUS / ZWECK

Dies ist **kein Entwicklungsauftrag für neue Funktionen** und **keine Installationsfreigabe**.

Ziel ist ausschließlich, den aktuell vorbereiteten V6.45-Quellstand gegen den **realen kritischen Produktionspfad** zu prüfen, den der lokale Stub-/Mock-Testbestand nicht beweisen kann.

**Kein Produktivsystem verwenden.** Nur eine frische isolierte Testumgebung.

Vor jeder Aktion vollständig lesen:

1. `01_MASTER_BINDING/HARTER_PRUEF_BUILD_UND_FREIGABEVERTRAG.md`
2. `01_MASTER_BINDING/MASTER_AFFILIATE_ZENTRALE_V6_44_0_LIVE_FAIL_HARD_CONTRACT_POSTMORTEM_BLOCKED_20260820.zip`
3. aktuellen V6.45-Source unter `02_SOURCE_V645/affiliate-portal-router/`
4. alle Tests unter `04_TESTS/`
5. die Real-Gate-Skripte unter `03_REAL_GATE/`

MASTER + tatsächlich geprüfter Quellcode sind bindend. Bei Unklarheit: **BLOCKED**. Nicht raten.

---

# 1. ABSOLUTE VERBOTE

Du darfst in diesem Auftrag **nicht**:

- Produktionscode verändern;
- Fachlogik, Titel-/Textlogik, Artikeltypen, Design, HTML, SEO-Regeln oder Ausgabe verändern;
- Tests abschwächen, Assertions entfernen oder erwartete Werte passend machen;
- den V6.44-Postmortem-Gap-Test künstlich grün machen;
- echte WordPress-/MariaDB-Persistenz durch SQLite, Arrays, Files, Mocks, Stubs oder Fake-`wpdb` ersetzen;
- eine neue Plugin-Version erfinden;
- eine Installations-ZIP freigeben oder eine Installation empfehlen;
- einen fehlenden Test durch „Code sieht korrekt aus“ ersetzen;
- auf ein Live-/Produktivsystem ausweichen.

Wenn ein Pflichtpunkt technisch nicht ausführbar ist: **BLOCKED – REALER PRODUKTIONSPFAD NICHT VOLLSTÄNDIG VERIFIZIERBAR.**

---

# 2. EXAKTER ZU PRÜFENDER SOURCE

Zu prüfen ist ausschließlich:

`02_SOURCE_V645/affiliate-portal-router/`

Vor jedem Test:

```bash
cd 02_SOURCE_V645
sha256sum -c SOURCE_SHA256.txt
```

Alle Einträge müssen `OK` sein. Bei nur einer Abweichung: **BLOCKED**.

Der Source muss sich gegenüber V6.44 auf exakt diese drei Produktionsdateien beschränken:

- `pferdeportal-affiliate-router.php`
- `includes/trait-ppar-ebay-run.php`
- `readme.txt`

Referenz: `06_DIFF_AND_HASHES/V644_TO_V645_FULL.diff` und `CHANGED_FILES_V644_TO_V645.txt`.

Keine weitere Produktionsdatei darf verändert sein.

---

# 3. SOURCE-/REGRESSIONS-GATES ZUERST

Führe zuerst aus:

```bash
07_RUNNERS/run_source_gates.sh
```

Erwartete Pflichtresultate des aktuellen Kandidaten:

- V6.45 Rootcause/Race: **10 Tests, 0 Fehler, 78 Assertions**
- V6.43 Gesamtworkflow-Regression: **11 Tests, 0 Fehler, 363 Assertions**
- V6.44 funktionale Regression gegen V6.45 (ohne versionsspezifischen V6.44-Architekturtest): **4 Tests, 0 Fehler, 70 Assertions**
- Historische R5-Suite: **54 eindeutige Tests, 0 Fehler, 2903 Assertions**
- alle Produktions-PHP-Dateien syntaktisch fehlerfrei
- beide Produktions-JSON-Dateien valide
- Source-SHA256 vollständig `OK`

## WICHTIG: V6.44-POSTMORTEM-DIAGNOSTIK

`04_TESTS/V644_POSTMORTEM/test_v644_release_gate_gaps.php` ist absichtlich ein Detektor des alten, unzureichenden Release-Beweises.

Er muss im jetzigen Bestand **genau zwei bekannte FAIL-Zeilen** zeigen:

1. `release workflow test must not replace production selection_request/process_tick`
2. `release workflow test must execute the real 311-concept manifest, not a 3-concept substitute`

Diese zwei Diagnosen dürfen **nicht** durch Änderung des Tests beseitigt werden. Ihre Schließung muss durch das nachfolgende echte Real-Gate erfolgen.

Wenn andere oder zusätzliche Fehler auftreten: **BLOCKED**.

---

# 4. ZWINGENDE REALE TESTUMGEBUNG

Erstelle eine vollständig isolierte frische Umgebung mit exakt:

- **WordPress 7.0.1**
- **PHP 8.4.x**
- PHP-Erweiterung **mysqli**
- **MariaDB 11.4.x** (echter Server, InnoDB)
- frische WordPress-Datenbank
- V6.45-Source unverändert als Plugin `affiliate-portal-router`
- Plugin aktiviert

Kein bestehendes Portal, keine Produktionsdatenbank, kein Live-Test.

Die Tabelle `{$wpdb->prefix}ppar_ebay_items` muss durch die echte Plugin-Aktivierung/Migration existieren.

Danach muss `03_REAL_GATE/verify_environment.php` vollständig PASS liefern. Wenn die Umgebung nicht exakt nachweisbar ist: **BLOCKED**.

---

# 5. REAL-GATE – PFLICHTREIHENFOLGE

Alle folgenden Prüfungen müssen mit der **echten Plugin-Klasse**, dem **echten Worker**, der **echten WordPress Options API**, echtem `wpdb` und echter MariaDB laufen.

Du kannst nach Einrichtung der Umgebung den vorbereiteten Runner verwenden:

```bash
WP_ROOT=/pfad/zum/frischen/wordpress \
WP=/pfad/zu/wp-cli \
07_RUNNERS/run_real_gate_from_existing_wordpress.sh
```

## Gate A – V6.44-artiger persistierter Paket-800-Zwischenzustand

`03_REAL_GATE/live800_resume.php`

Es muss nachgewiesen werden:

- Start mit `transport_tick_count = 800`
- gleiche Run-UUID bleibt unverändert
- echte BUSINESS-Prepare-Verarbeitung über den realen 311-Familien-Manifestpfad
- Cursor monoton bei jedem persistierten Paket
- exakt **39** reale Prepare-Pakete
- Abschluss `prepare_business_index = 311`
- Folgezustand `business_select`
- `transport_tick_count = 839`
- `phase_tick_count = 39`
- abgeleitetes `selection_prepare_tick_limit = 41`
- `no_progress_count = 0`

Kein Stub-Selector und kein 3-Konzept-Ersatz.

## Gate B – negative Terminierungsgrenzen

`03_REAL_GATE/negative_limits.php`

Es muss nachgewiesen werden:

- `selection_prepare` stoppt fail-closed bei Überschreitung der abgeleiteten Obergrenze;
- Fehlercode exakt `selection_prepare_tick_limit_exceeded`;
- zielgerichtetes `gapfill_select` hat ebenfalls eine abgeleitete Obergrenze;
- ein fehlendes BUSINESS-Konzept ergibt den realen Gap-Fill-Prepare-Budgetpfad und stoppt bei Überschreitung mit demselben expliziten Code.

## Gate C – stale whole-run CAS

`03_REAL_GATE/stale_cas.php`

Mit echter MariaDB muss nachgewiesen werden:

- ein veralteter Snapshot kann einen inzwischen weitergelaufenen Run nicht überschreiben;
- CAS liefert `false`;
- fortgeschrittener Transportzähler/Cursor bleiben erhalten;
- Run-UUID bleibt identisch.

## Gate D – Soft-Failure-Recovery aus echtem persistiertem Fehlerzustand

`03_REAL_GATE/soft_failure_recovery.php`

Es muss nachgewiesen werden:

- exakt dieselbe fehlgeschlagene Run-UUID wird fortgesetzt;
- nur der zulässige abgeleitete Selection-Tail wird neu geöffnet;
- Maintenance-/Refresh-Fortschritt bleibt erhalten;
- Legacy-Selection-State wird erst nach erfolgreichem echten DB-CAS gelöscht;
- Migration ist idempotent;
- anschließend läuft ein echter Worker-Tick und persistiert den ersten 8-Familien-Checkpoint.

## Gate E – echte atomare Lease-Konkurrenz

Zuerst `setup_concurrent.php`, dann **fünf wirklich parallele unabhängige PHP-Prozesse** mit `lease_barrier.php`, synchron über die bereitgestellte Barrier.

Danach `assert_concurrent.php`.

Zwingend:

- exakt 5 Worker-Ergebnisse;
- **exakt 1** Lease-Gewinner;
- **exakt 4** atomare Ablehnungen;
- reine Lease-Akquisition verändert weder Transportzähler noch Selector-Cursor;
- UUID bleibt unverändert;
- Gewinner-Lease ist persistent vorhanden;
- Lease lässt sich nur mit Gewinner-Token korrekt lösen.

Keine sequentielle Simulation.

## Gate F – echter paralleler Canonical-Worker-Burst

Persistierten Zustand mit `setup_concurrent.php` frisch setzen.

Dann **fünf parallele unabhängige PHP-Prozesse** mit `tick_barrier.php` synchron starten.

Danach `assert_tick_burst.php`.

Zwingend:

- exakt 5 Full-Worker-Ergebnisse;
- mindestens 1 und höchstens 5 Worker erwerben kanonische Arbeit;
- `transport_tick_count` entspricht exakt der Anzahl tatsächlich erfolgreicher Worker;
- BUSINESS-Cursor entspricht `min(311, erfolgreiche_worker * 8)`;
- Cursor geht nicht rückwärts;
- UUID bleibt unverändert;
- Lease ist nach vollständigem Worker-/Progress-Accounting sauber freigegeben;
- abgewiesene konkurrierende Requests erzeugen keinen falschen No-Progress-Zustand.

## Gate G – Wiederaufnahme des konkurrierend erzeugten Checkpoints

`03_REAL_GATE/continue_concurrent_checkpoint.php`

Zwingend:

- Resume mit unveränderter UUID;
- persistierter Cursor ist monoton;
- `selection_prepare` terminiert bei `business_select`;
- Endcursor exakt 311;
- `no_progress_count = 0`;
- `phase_tick_count <= selection_prepare_tick_limit`.

## Gate H – Datenbank-/Plugin-Sanity

Zum Schluss:

- echtes `SELECT 1` über WordPress-`wpdb` muss erfolgreich sein;
- Plugin weiterhin aktiv;
- finalen `OPTION_EBAY_RUN_STATE` als JSON sichern;
- keine PHP-Fatal-Errors, keine DB-Errors, keine ungeklärten Warnings im Testlauf.

---

# 6. GEGENBEWEIS / VERSUCH DEN FIX ZU WIDERLEGEN

Nach erfolgreichen Gates ausdrücklich prüfen, ob derselbe oder ein angrenzender Fehler unter diesen realistischen Bedingungen erneut entstehen kann:

- stale Migration schreibt nach bereits fortgeschrittenem Worker;
- zwei oder mehr Requests starten exakt gleichzeitig;
- Lease wird während konkurrierender Anfrage gehalten;
- persistierter Zwischenzustand startet bei Transport 800;
- Resume aus zulässigem Soft-Failure;
- Überschreitung der Phasenobergrenze;
- Gap-Fill mit nur einem fehlenden Konzept;
- Cursor-/State-Rückschritt.

Diese Gegenbeweise sind durch die obigen Gates abzudecken. Wenn ein Gegenbeweis gelingt: **BLOCKED**.

---

# 7. BEWEISE, DIE CODEX ZURÜCKGEBEN MUSS

Erzeuge **genau ein Evidence-ZIP**, keine Installations-ZIP:

`CODEX_V645_REALGATE_EVIDENCE_20260820.zip`

Es muss enthalten:

1. `ENVIRONMENT.txt`
   - OS
   - WordPress-Version
   - PHP-Version
   - `php -m` / Nachweis mysqli
   - MariaDB-Version
2. `SOURCE_SHA256_VERIFIED.txt`
3. vollständige Rohlogs von `run_source_gates.sh`
4. vollständige Rohlogs jedes Real-Gates A–H
5. die fünf Roh-Worker-Ergebnisse aus Lease-Test
6. die fünf Roh-Worker-Ergebnisse aus Full-Worker-Burst
7. DB-/Options-Snapshots vor/nach kritischen Gates, mindestens Run-State/UUID/Cursor/Owner/Lease/Transport/No-Progress/Phase
8. Exitcodes aller Befehle
9. `CHANGED_FILES_AFTER_TEST.txt` – Nachweis, dass Produktionssource nach Test byteidentisch zum gelieferten Source blieb
10. `REAL_GATE_REPORT.md`

`REAL_GATE_REPORT.md` muss die MASTER-Matrix exakt beantworten:

- Realer kritischer Pfad getestet: JA / NEIN
- Echte Worker-Implementierung: JA / NEIN
- Persistierter Zwischenzustand: JA / NEIN
- Terminierung bewiesen: JA / NEIN
- No-Progress-Abbruch bewiesen: JA / NEIN
- Positive Fälle: PASS / FAIL
- Negative Fälle: PASS / FAIL
- Recovery: PASS / FAIL
- Gesamtworkflow-Regression: PASS / FAIL
- Source nach Tests unverändert: JA / NEIN
- Installations-ZIP: **NICHT GEBAUT – ABSICHTLICH**

Außerdem jeden einzelnen Gate A–H mit Befehl, Exitcode und Rohlog-Datei referenzieren.

---

# 8. ENTSCHEIDUNGSREGEL

Nur zwei zulässige Resultate für diesen Codex-Auftrag:

## REAL-GATE-EVIDENCE VOLLSTÄNDIG

Nur wenn **jeder** geforderte Prüfpunkt tatsächlich ausgeführt und belegt ist.

Das ist **noch keine Installationsfreigabe**. Die Belege werden anschließend unabhängig gegen MASTER geprüft.

oder

## BLOCKED

Sobald ein Pflichtpunkt:

- nicht ausführbar,
- nicht eindeutig,
- fehlgeschlagen,
- ersetzt/gemockt,
- übersprungen,
- nicht reproduzierbar

ist.

Dann keine Codeänderung, keine Installations-ZIP, keine Freigabe. Nur Ursache + Rohbelege zurückgeben.
