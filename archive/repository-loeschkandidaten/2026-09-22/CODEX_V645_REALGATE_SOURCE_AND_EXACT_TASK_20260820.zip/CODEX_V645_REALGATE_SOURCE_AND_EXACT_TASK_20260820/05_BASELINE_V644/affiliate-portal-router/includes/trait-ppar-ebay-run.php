<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Canonical durable eBay run coordinator.
 *
 * This trait deliberately does not replace the proven acceptance, classification,
 * source upsert, HivePress materialisation or BUSINESS campaign materialisation
 * code. It only owns orchestration, persistence, leases and terminal verification.
 */
trait PPAR_Ebay_Run_Trait {
    private function ebay_run_option_key() {
        $constant = static::class . '::OPTION_EBAY_RUN_STATE';
        return defined($constant) ? (string)constant($constant) : 'ppar_ebay_run_state_v1';
    }

    private function ebay_run_load() {
        $run = get_option($this->ebay_run_option_key(), array());
        return is_array($run) ? $run : array();
    }

    private function ebay_run_save($run) {
        $run = is_array($run) ? $run : array();
        $run['schema'] = '1.0';
        $run['build'] = self::EBAY_RUNTIME_BUILD;
        $run['updated_at'] = time();
        update_option($this->ebay_run_option_key(), $run, false);
        return $run;
    }

    private function ebay_run_is_open($run = null) {
        if (!is_array($run)) { $run = $this->ebay_run_load(); }
        return (string)($run['schema'] ?? '') === '1.0'
            && in_array(sanitize_key((string)($run['status'] ?? '')), array('running'), true)
            && !in_array(sanitize_key((string)($run['phase'] ?? '')), array('completed','failed'), true);
    }

    private function ebay_run_phase_state_load($key) {
        $key = sanitize_key((string)$key);
        if ($key === '') { return array(); }
        $run = $this->ebay_run_load();
        if ($this->ebay_run_is_open($run) || (string)($run['schema'] ?? '') === '1.0') {
            $phase_state = is_array($run['phase_state'] ?? null) ? $run['phase_state'] : array();
            $state = $phase_state[$key] ?? array();
            return is_array($state) ? $state : array();
        }
        return array();
    }

    private function ebay_run_phase_state_save($key, $state) {
        $key = sanitize_key((string)$key);
        if ($key === '') { return false; }
        $run = $this->ebay_run_load();
        if ((string)($run['schema'] ?? '') !== '1.0') { return false; }
        if (!isset($run['phase_state']) || !is_array($run['phase_state'])) { $run['phase_state'] = array(); }
        $run['phase_state'][$key] = is_array($state) ? $state : array();
        $this->ebay_run_save($run);
        return true;
    }

    private function ebay_run_context_active() {
        return !empty($this->ebay_canonical_worker_active) && $this->ebay_run_is_open();
    }

    private function ebay_run_worker_transport_migration_key() {
        $constant = static::class . '::OPTION_EBAY_WORKER_TRANSPORT_MIGRATION';
        return defined($constant) ? (string)constant($constant) : 'ppar_ebay_worker_transport_migration_v6412';
    }

    /**
     * V6.41.2 environment-bound transport contract.
     *
     * The hosting has no available server-cron/WP-CLI executor. Therefore one
     * authenticated same-origin admin-AJAX endpoint is the sole executor for an
     * open canonical run. It executes exactly one bounded canonical worker tick
     * per request. There is no WP-Cron worker hook and no plugin self-HTTP.
     * Closing the provider page merely pauses the durable run; reopening it
     * resumes the same UUID/cursors through the same transport.
     */
    private function ebay_run_schedule_worker($delay = 10) {
        $run = $this->ebay_run_load();
        if (!$this->ebay_run_is_open($run)) { return false; }
        return (string)($run['worker_transport'] ?? '') === 'admin_ajax';
    }

    /** State-only migration for an already-open V6.41.0/V6.41.1 run. No cursor,
     * source, listing, campaign, taxonomy or selection plan is reset/mutated. */
    public function maybe_migrate_ebay_worker_transport_v6412() {
        if ((string)get_option($this->ebay_run_worker_transport_migration_key(), '') === 'done') { return; }
        if (function_exists('wp_clear_scheduled_hook')) {
            wp_clear_scheduled_hook(self::EBAY_WORKER_HOOK);
            if (defined(static::class . '::EBAY_REFRESH_WORKER_HOOK')) {
                wp_clear_scheduled_hook(self::EBAY_REFRESH_WORKER_HOOK);
            }
        }
        $run = $this->ebay_run_load();
        if ((string)($run['schema'] ?? '') === '1.0') {
            $run['worker_transport'] = 'admin_ajax';
            if (sanitize_key((string)($run['resume_reason'] ?? '')) === 'awaiting_server_cron') {
                $run['resume_reason'] = 'awaiting_admin_ajax';
            }
            $this->ebay_run_save($run);
        }
        update_option($this->ebay_run_worker_transport_migration_key(), 'done', false);
    }

    /** Current durable progress-contract version. Kept separate from the plugin
     * build so state migration is based on the persisted contract, not on a
     * brittle one-off version prefix. */
    private function ebay_run_progress_contract_version() {
        $constant = static::class . '::EBAY_PROGRESS_CONTRACT_VERSION';
        return defined($constant) ? (string)constant($constant) : '2.0';
    }

    /** Return the last matching persistent failure entry without mutating state. */
    private function ebay_run_last_failure_entry($run, $code = '') {
        $errors = is_array($run['errors'] ?? null) ? $run['errors'] : array();
        $code = sanitize_key((string)$code);
        for ($i = count($errors) - 1; $i >= 0; $i--) {
            $entry = is_array($errors[$i] ?? null) ? $errors[$i] : array();
            if ($code !== '' && sanitize_key((string)($entry['code'] ?? '')) !== $code) { continue; }
            return $entry;
        }
        return array();
    }

    /**
     * V6.42.1 state-only migration for the proven old progress-contract defect.
     *
     * Root cause: V6.41.2/V6.41.3 could advance fair PRIVATE per-leaf prepare
     * cursors while the canonical no-progress fingerprint stayed unchanged.
     * V6.42 fixed the fingerprint itself, but its recovery was incorrectly tied
     * to one build prefix plus one global option. A real V6.41.2 failed run could
     * therefore remain terminal forever even though it had the exact proven
     * false-stall shape.
     *
     * This migration is per run + per failure event, fail-closed and state-only.
     * It never reopens a current-contract failure. It never mutates source rows,
     * listings, campaigns or taxonomies. If policy/catalog changed since the
     * failed run, only derived selection/coverage state is invalidated and the
     * same immutable run UUID re-enters reconcile_local.
     */
    public function maybe_migrate_ebay_progress_contract_v6421() {
        $run = $this->ebay_run_load();
        if ((string)($run['schema'] ?? '') !== '1.0') { return; }

        $current_contract = $this->ebay_run_progress_contract_version();
        $current_catalog = hash_file('sha256', __DIR__ . '/../assets/ebay-portal-catalog-v2.json') ?: '';
        $status = sanitize_key((string)($run['status'] ?? ''));
        $run_contract = sanitize_text_field((string)($run['progress_contract_version'] ?? ''));
        $build = sanitize_text_field((string)($run['build'] ?? ''));
        $affected_build = strpos($build, '6.41.2-') === 0 || strpos($build, '6.41.3-') === 0;
        $contract_changed = (string)($run['policy_version'] ?? '') !== (string)self::EBAY_CONTENT_POLICY_VERSION
            || ($current_catalog !== '' && (string)($run['catalog_version'] ?? '') !== $current_catalog);

        // Open affected old-contract run: upgrade the contract in-place. If the
        // policy/catalog also changed, a derived selection plan is unsafe to
        // resume; preserve remote/source cursors and re-enter reconciliation.
        if ($this->ebay_run_is_open($run) && ($run_contract !== $current_contract || $affected_build)) {
            $history = is_array($run['recovery_history'] ?? null) ? $run['recovery_history'] : array();
            $marker = hash('sha256', (string)($run['run_uuid'] ?? '').'|open|'.$current_contract.'|'.$build.'|'.($contract_changed?'1':'0'));
            foreach ($history as $entry) {
                if (is_array($entry) && hash_equals($marker, (string)($entry['migration_key'] ?? ''))) { return; }
            }
            $history[] = array('at'=>time(),'from_build'=>$build,'reason'=>'progress_contract_upgrade_open_run','migration_key'=>$marker,'contract_reconcile'=>$contract_changed?1:0);
            if (count($history) > 8) { $history = array_slice($history, -8); }
            $run['recovery_history'] = $history;
            $run['progress_contract_version'] = $current_contract;
            $run['owner'] = '';
            $run['lease_expires_at'] = 0;
            $run['worker_transport'] = 'admin_ajax';
            $run['no_progress_count'] = 0;
            if ($contract_changed) {
                $run['phase'] = 'reconcile_local';
                $run['resume_reason'] = 'progress_contract_policy_reconcile';
                if (!isset($run['phase_state']) || !is_array($run['phase_state'])) { $run['phase_state'] = array(); }
                $run['phase_state']['selection'] = array();
                $run['coverage'] = array();
                $run['gapfill'] = array('attempts'=>0,'missing'=>array());
                $run['end_manifest'] = array();
                $run['policy_version'] = (string)self::EBAY_CONTENT_POLICY_VERSION;
                if ($current_catalog !== '') { $run['catalog_version'] = $current_catalog; }
                update_option(self::OPTION_EBAY_SELECTION_STATE, array(), false);
            } else {
                $run['resume_reason'] = 'progress_contract_upgraded_in_place';
            }
            $this->ebay_run_save($run);
            return;
        }

        if ($status !== 'failed' || sanitize_key((string)($run['error_code'] ?? '')) !== 'canonical_worker_no_progress') { return; }

        $failure = $this->ebay_run_last_failure_entry($run, 'canonical_worker_no_progress');
        $details = is_array($failure['details'] ?? null) ? $failure['details'] : array();
        $failed_phase = sanitize_key((string)($details['phase'] ?? ''));
        $failure_build = sanitize_text_field((string)($details['build'] ?? $build));
        $failure_contract = sanitize_text_field((string)($details['progress_contract_version'] ?? $run_contract));
        $affected_failure_build = strpos($failure_build, '6.41.2-') === 0 || strpos($failure_build, '6.41.3-') === 0;

        // A failure explicitly produced under the current progress contract is a
        // real failure until separately diagnosed. Never auto-recover it.
        if ($failure_contract !== '' && hash_equals($current_contract, $failure_contract)) { return; }
        if (!$affected_failure_build) { return; }

        $selection = is_array($run['phase_state']['selection'] ?? null) ? $run['phase_state']['selection'] : array();
        $selection_status = sanitize_key((string)($selection['status'] ?? ''));
        $leaf_offsets = is_array($selection['prepare_private_leaf_offsets'] ?? null) ? $selection['prepare_private_leaf_offsets'] : array();
        $leaf_offset_progress = 0;
        foreach ($leaf_offsets as $offset) { $leaf_offset_progress += absint($offset); }
        $proven_private_prepare_progress = !empty($selection['prepare_private_initialized'])
            && empty($selection['prepare_private_complete'])
            && (absint($selection['prepare_private_scanned'] ?? 0) > 0
                || absint($selection['prepare_private_leaf_index'] ?? 0) > 0
                || $leaf_offset_progress > 0);
        $exact_false_failure = $failed_phase === 'selection_prepare'
            && in_array($selection_status, array('pending','preparing'), true)
            && $proven_private_prepare_progress;
        if (!$exact_false_failure) { return; }

        $failure_at = absint($failure['at'] ?? $run['finished_at'] ?? 0);
        $migration_key = hash('sha256', (string)($run['run_uuid'] ?? '').'|'.$failure_at.'|canonical_worker_no_progress|selection_prepare|'.$current_contract);
        $history = is_array($run['recovery_history'] ?? null) ? $run['recovery_history'] : array();
        foreach ($history as $entry) {
            if (is_array($entry) && hash_equals($migration_key, (string)($entry['migration_key'] ?? ''))) { return; }
        }

        $history[] = array(
            'at'=>time(),'from_build'=>$failure_build,'from_progress_contract'=>$failure_contract,
            'error_code'=>'canonical_worker_no_progress','reason'=>'legacy_private_prepare_progress_fingerprint_omission',
            'migration_key'=>$migration_key,'contract_reconcile'=>$contract_changed?1:0,
        );
        if (count($history) > 8) { $history = array_slice($history, -8); }
        $run['recovery_history'] = $history;
        $run['status'] = 'running';
        $run['phase'] = $contract_changed ? 'reconcile_local' : 'selection_prepare';
        $run['finished_at'] = 0;
        $run['owner'] = '';
        $run['lease_expires_at'] = 0;
        $run['worker_transport'] = 'admin_ajax';
        $run['resume_reason'] = $contract_changed ? 'legacy_false_stall_policy_reconcile' : 'legacy_false_stall_recovered';
        $run['no_progress_count'] = 0;
        $run['error_code'] = '';
        $run['error_message'] = '';
        $run['last_progress_at'] = time();
        $run['progress_contract_version'] = $current_contract;
        if ($contract_changed) {
            if (!isset($run['phase_state']) || !is_array($run['phase_state'])) { $run['phase_state'] = array(); }
            $run['phase_state']['selection'] = array();
            $run['coverage'] = array();
            $run['gapfill'] = array('attempts'=>0,'missing'=>array());
            $run['end_manifest'] = array();
            $run['policy_version'] = (string)self::EBAY_CONTENT_POLICY_VERSION;
            if ($current_catalog !== '') { $run['catalog_version'] = $current_catalog; }
            update_option(self::OPTION_EBAY_SELECTION_STATE, array(), false);
        }
        $this->ebay_run_save($run);
    }


    /**
     * V6.43.0 state-only migration for one proven canonical PARTIAL-checkpoint
     * false stall. It reopens a failed run only when the persisted nested
     * discovery state itself proves that the same run stopped on a resumable
     * segment_time_budget checkpoint in the exact matching scope. Unknown or
     * current failures remain terminal.
     */
    public function maybe_migrate_ebay_partial_checkpoint_v6430() {
        $run=$this->ebay_run_load();
        if((string)($run['schema']??'')!=='1.0') { return; }
        if(sanitize_key((string)($run['status']??''))!=='failed' || sanitize_key((string)($run['error_code']??''))!=='canonical_worker_no_progress') { return; }
        $failure=$this->ebay_run_last_failure_entry($run,'canonical_worker_no_progress');
        $details=is_array($failure['details']??null)?$failure['details']:array();
        $failed_phase=sanitize_key((string)($details['phase']??''));
        if(!in_array($failed_phase,array('refresh_remote','gapfill_discovery'),true)) { return; }
        $job=is_array($run['phase_state']['discovery']??null)?$run['phase_state']['discovery']:array();
        if(!$this->ebay_sync_job_is_resumable_partial($job)) { return; }
        $scope=sanitize_key((string)($job['scope']??''));
        $expected_scope=$failed_phase==='gapfill_discovery'?'business_recovery':'all';
        if($scope!==$expected_scope) { return; }
        $run_uuid=sanitize_text_field((string)($run['run_uuid']??''));
        $job_uuid=sanitize_text_field((string)($job['run_uuid']??''));
        if($run_uuid==='' || $job_uuid==='' || !hash_equals($run_uuid,$job_uuid)) { return; }
        $history=is_array($run['recovery_history']??null)?$run['recovery_history']:array();
        $failure_at=absint($failure['at']??$run['finished_at']??0);
        $marker=hash('sha256',$run_uuid.'|'.$failure_at.'|partial_checkpoint|'.$failed_phase.'|'.$scope);
        foreach($history as $entry){if(is_array($entry)&&hash_equals($marker,(string)($entry['migration_key']??''))){return;}}
        $history[]=array('at'=>time(),'reason'=>'canonical_partial_checkpoint_resume','phase'=>$failed_phase,'scope'=>$scope,'migration_key'=>$marker);
        if(count($history)>8){$history=array_slice($history,-8);}
        $run['recovery_history']=$history;$run['status']='running';$run['phase']=$failed_phase;$run['finished_at']=0;$run['owner']='';$run['lease_expires_at']=0;$run['worker_transport']='admin_ajax';$run['resume_reason']='partial_checkpoint_resume';$run['no_progress_count']=0;$run['error_code']='';$run['error_message']='';$run['last_progress_at']=time();
        $this->ebay_run_save($run);
    }

    /**
     * V6.44.0 state-only recovery for the proven BUSINESS materialisation
     * dead-end. The old selector treated one candidate-local soft output-plan
     * failure as a terminal failure of the whole 311-family run, so the
     * canonical coverage/gap-fill phases could never do the job they own.
     *
     * Recovery is deliberately fail-closed: the same run UUID is reopened only
     * when every persisted materialisation error is independently proven soft.
     * Storage/source/commit/unknown errors remain terminal.
     */
    private function ebay_run_business_materialization_error_is_proven_soft_v6440($entry) {
        $entry=is_array($entry)?$entry:array();
        $code=sanitize_key((string)($entry['code']??''));
        if($code==='ebay_business_materialization_not_active'){return true;}
        if($code!=='business_selection_commit_failed'){return false;}
        // One historical edge case: route_business already preserved a verified
        // Last-Known-Good output, then the generic active-selected commit rejected
        // that intentional review_last_good state. Prove that exact row state
        // before treating the old commit failure as candidate-local.
        $item_id=sanitize_text_field((string)($entry['item_id']??''));
        if($item_id==='' || !method_exists($this,'ebay_items_table')){return false;}
        global $wpdb;
        if(!is_object($wpdb)||!method_exists($wpdb,'get_row')||!method_exists($wpdb,'prepare')){return false;}
        $row=$wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->ebay_items_table()} WHERE item_id=%s AND seller_account_type='BUSINESS' ORDER BY id DESC LIMIT 1",
            $item_id
        ),ARRAY_A);
        if(!is_array($row)){return false;}
        $route=sanitize_key((string)($row['route_state']??''));
        $reason=sanitize_text_field((string)($row['rejection_reason']??''));
        return $route==='review_last_good' && strpos($reason,'[ebay_business_materialization_not_active]')!==false;
    }

    public function maybe_migrate_ebay_business_materialization_v6440() {
        $run=$this->ebay_run_load();
        if((string)($run['schema']??'')!=='1.0') { return; }
        if(sanitize_key((string)($run['status']??''))!=='failed'
            || sanitize_key((string)($run['error_code']??''))!=='business_recovery_incomplete'){return;}
        $failure=$this->ebay_run_last_failure_entry($run,'business_recovery_incomplete');
        $details=is_array($failure['details']??null)?$failure['details']:array();
        $failed_phase=sanitize_key((string)($details['phase']??''));
        if($failed_phase!=='' && $failed_phase!=='business_materialize'){return;}
        $selection=is_array($run['phase_state']['selection']??null)?$run['phase_state']['selection']:array();
        if(sanitize_key((string)($selection['failure_reason']??''))!=='business_recovery_incomplete'){return;}
        $errors=is_array($selection['stats']['business']['errors']??null)?$selection['stats']['business']['errors']:array();
        if(!$errors){return;}
        foreach($errors as $entry){if(!$this->ebay_run_business_materialization_error_is_proven_soft_v6440($entry)){return;}}

        $uuid=sanitize_text_field((string)($run['run_uuid']??''));
        if($uuid===''){return;}
        $failure_at=absint($failure['at']??$run['finished_at']??0);
        $marker=hash('sha256',$uuid.'|'.$failure_at.'|business_materialization_soft_candidates|6.44.0');
        $history=is_array($run['recovery_history']??null)?$run['recovery_history']:array();
        foreach($history as $entry){if(is_array($entry)&&hash_equals($marker,(string)($entry['migration_key']??''))){return;}}
        $history[]=array('at'=>time(),'reason'=>'business_materialization_soft_candidate_recovery','error_code'=>'business_recovery_incomplete','migration_key'=>$marker,'soft_errors'=>count($errors));
        if(count($history)>8){$history=array_slice($history,-8);}

        // Preserve source/refresh state and immutable run identity. Only the
        // derived selection/coverage tail is rebuilt under the corrected rule.
        $run['recovery_history']=$history;$run['status']='running';$run['phase']='selection_prepare';$run['finished_at']=0;
        $run['owner']='';$run['lease_expires_at']=0;$run['worker_transport']='admin_ajax';
        $run['resume_reason']='business_materialization_soft_candidate_recovery';$run['no_progress_count']=0;
        $run['error_code']='';$run['error_message']='';$run['last_progress_at']=time();
        if(!isset($run['phase_state'])||!is_array($run['phase_state'])){$run['phase_state']=array();}
        $run['phase_state']['selection']=array();$run['coverage']=array();$run['gapfill']=array('attempts'=>0,'missing'=>array());$run['end_manifest']=array();
        update_option(self::OPTION_EBAY_SELECTION_STATE,array(),false);
        $this->ebay_run_save($run);
    }

    /** Backward-compatible entry point retained for older test harnesses. */
    public function maybe_recover_ebay_false_no_progress_v6420() {
        return $this->maybe_migrate_ebay_progress_contract_v6421();
    }

    /** One authenticated browser request processes exactly one bounded package.
     * This is the only executable transport for the canonical eBay run. */
    public function run_ebay_admin_ajax_tick() {
        $run = $this->ebay_run_adopt_legacy_if_needed();
        if (!$this->ebay_run_is_open($run)) {
            return array('status'=>'idle','transport'=>'admin_ajax','run_uuid'=>(string)($run['run_uuid'] ?? ''));
        }
        if ((string)($run['worker_transport'] ?? '') !== 'admin_ajax') {
            return new WP_Error('ebay_transport_mismatch', 'Der offene eBay-Gesamtlauf gehört nicht dem Admin-AJAX-Transport.');
        }
        $run['last_transport_tick_at'] = time();
        $run['transport_tick_count'] = absint($run['transport_tick_count'] ?? 0) + 1;
        if (sanitize_key((string)($run['resume_reason'] ?? '')) === 'awaiting_admin_ajax') {
            $run['resume_reason'] = '';
        }
        $this->ebay_run_save($run);
        return $this->run_ebay_canonical_worker();
    }

    /** Snapshot only operational values. Provider credentials are intentionally
     * not duplicated into the durable run option; current credentials are merged
     * at worker time while all behavioural/routing settings stay frozen. */
    private function ebay_run_settings_snapshot($settings) {
        $settings = is_array($settings) ? $this->ebay_normalize_settings($settings, true) : array();
        $drop = array('client_id','client_secret','last_test','last_sync','last_refresh','rules');
        foreach ($drop as $key) { unset($settings[$key]); }
        return $settings;
    }

    private function ebay_run_effective_settings($run) {
        $override = $this->ebay_run_settings_override;
        $this->ebay_run_settings_override = null;
        $live = $this->ebay_settings();
        $this->ebay_run_settings_override = $override;
        $snapshot = is_array($run['config_snapshot']['settings'] ?? null) ? $run['config_snapshot']['settings'] : array();
        foreach ($snapshot as $key => $value) {
            if (in_array($key, array('client_id','client_secret','last_test','last_sync','last_refresh','rules'), true)) { continue; }
            $live[$key] = $value;
        }
        // Rules are immutable plugin catalog data for this build. Credentials are
        // live operational secrets and may be rotated without mutating run scope.
        $live['rules'] = $this->ebay_catalog_rules();
        return $this->ebay_normalize_settings($live, true);
    }

    private function ebay_run_selection_scope($run) {
        $routes = is_array($run['config_snapshot']['seller_routes'] ?? null) ? $run['config_snapshot']['seller_routes'] : array();
        $private = !empty($routes['private']);
        $business = !empty($routes['business']);
        return $private && $business ? 'all' : ($private ? 'private' : ($business ? 'business' : ''));
    }

    private function ebay_run_new_uuid() {
        return function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : substr(hash('sha256', microtime(true) . '|canonical|' . mt_rand()), 0, 36);
    }

    private function ebay_run_legacy_raw_states() {
        return array(
            'discovery'=>is_array(get_option(self::OPTION_EBAY_SYNC_JOB, array())) ? get_option(self::OPTION_EBAY_SYNC_JOB, array()) : array(),
            'refresh'=>is_array(get_option(self::OPTION_EBAY_REFRESH_JOB, array())) ? get_option(self::OPTION_EBAY_REFRESH_JOB, array()) : array(),
            'selection'=>is_array(get_option(self::OPTION_EBAY_SELECTION_STATE, array())) ? get_option(self::OPTION_EBAY_SELECTION_STATE, array()) : array(),
            'maintenance'=>is_array(get_option(self::OPTION_EBAY_MAINTENANCE_STATE, array())) ? get_option(self::OPTION_EBAY_MAINTENANCE_STATE, array()) : array(),
        );
    }

    /** State-only adoption of one compatible V6.40 open chain. No source/post/
     * campaign mutation occurs here. Ambiguous competing owners fail closed. */
    private function ebay_run_adopt_legacy_if_needed() {
        $current = $this->ebay_run_load();
        if ((string)($current['schema'] ?? '') === '1.0') { return $current; }
        $legacy = $this->ebay_run_legacy_raw_states();
        $sync = $legacy['discovery']; $refresh = $legacy['refresh']; $selection = $legacy['selection'];
        $sync_open = in_array(sanitize_key((string)($sync['status'] ?? '')), array('queued','running','partial'), true);
        $refresh_open = in_array(sanitize_key((string)($refresh['status'] ?? '')), array('queued','running','partial'), true);
        $selection_open = in_array(sanitize_key((string)($selection['status'] ?? '')), array('pending','preparing','running'), true);
        if (!$sync_open && !$refresh_open && !$selection_open) { return array(); }

        $uuid = '';
        $operation = 'refresh';
        $phase = 'reconcile_local';
        $remote_subphase = 'inventory';
        $compatible = true;
        if ($sync_open) {
            $uuid = sanitize_text_field((string)($sync['run_uuid'] ?? ''));
            $operation = 'sync'; $phase = 'refresh_remote'; $remote_subphase = 'discovery';
        }
        if ($refresh_open) {
            $r_uuid = sanitize_text_field((string)($refresh['run_uuid'] ?? ''));
            if ($uuid !== '' && $r_uuid !== '' && !hash_equals($uuid, $r_uuid)) { $compatible = false; }
            if ($uuid === '') { $uuid = $r_uuid; }
            $operation = 'refresh';
            $rphase = sanitize_key((string)($refresh['summary']['phase'] ?? ''));
            $phase = in_array($rphase, array('local_reconciliation','asset_verification'), true) ? 'reconcile_local' : 'refresh_remote';
            $remote_subphase = 'inventory';
        }
        if ($selection_open) {
            $owner = sanitize_text_field((string)($selection['owner'] ?? ''));
            if (strpos($owner, 'sync:') === 0) { $s_uuid = substr($owner, 5); }
            elseif (strpos($owner, 'refresh:') === 0) { $s_uuid = substr($owner, 8); }
            elseif (strpos($owner, 'run:') === 0) { $s_uuid = substr($owner, 4); }
            else { $s_uuid = ''; }
            if ($uuid !== '' && $s_uuid !== '' && !hash_equals($uuid, $s_uuid)) { $compatible = false; }
            if ($uuid === '' && $s_uuid !== '') { $uuid = $s_uuid; }
            if (!$sync_open && !$refresh_open) { $operation = 'selection'; }
            $phase = 'selection_prepare';
        }
        if (!$compatible || $uuid === '') {
            $blocked = array(
                'schema'=>'1.0','build'=>self::EBAY_RUNTIME_BUILD,'run_uuid'=>$uuid !== '' ? $uuid : $this->ebay_run_new_uuid(),
                'status'=>'failed','phase'=>'failed','started_at'=>time(),'updated_at'=>time(),'finished_at'=>time(),
                'error_code'=>'blocked_migration_required','error_message'=>'Mehrere alte eBay-Workerzustände besitzen keine eindeutig gemeinsame Run-Identität.',
                'phase_state'=>$legacy,
            );
            return $this->ebay_run_save($blocked);
        }
        $settings = $this->ebay_settings();
        $run = array(
            'schema'=>'1.0','build'=>self::EBAY_RUNTIME_BUILD,'run_uuid'=>$uuid,'status'=>'running','phase'=>$phase,
            'operation'=>$operation,'remote_subphase'=>$remote_subphase,'started_at'=>min(array_filter(array_map('absint', array($sync['created_at']??0,$refresh['created_at']??0,$selection['started_at']??0))) ?: array(time())),
            'updated_at'=>time(),'finished_at'=>0,'owner'=>'','lease_expires_at'=>0,'worker_transport'=>'admin_ajax','resume_reason'=>'adopted_legacy_state',
            'no_progress_count'=>0,'last_progress_at'=>time(),'progress_seq'=>0,
            'config_snapshot'=>array('seller_routes'=>array('private'=>!empty($settings['private_enabled']),'business'=>!empty($settings['business_enabled'])),'settings'=>$this->ebay_run_settings_snapshot($settings)),
            'catalog_version'=>hash_file('sha256', __DIR__ . '/../assets/ebay-portal-catalog-v2.json') ?: '',
            'policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,'private_classifier_version'=>self::EBAY_PRIVATE_CLASSIFIER_VERSION,'business_classifier_version'=>self::EBAY_BUSINESS_CLASSIFIER_VERSION,'progress_contract_version'=>$this->ebay_run_progress_contract_version(),
            'phase_state'=>$legacy,'coverage'=>array(),'errors'=>array(),'start_manifest'=>array('adopted_legacy'=>1),'end_manifest'=>array(),
        );
        return $this->ebay_run_save($run);
    }

    private function ebay_run_start($manual = false, $operation = 'sync') {
        $operation = sanitize_key((string)$operation);
        if (!in_array($operation, array('sync','refresh'), true)) { return new WP_Error('ebay_run_operation_invalid', 'Ungültiger eBay-Gesamtlauf.'); }
        $run = $this->ebay_run_adopt_legacy_if_needed();
        if ($this->ebay_run_is_open($run)) {
            if ((string)($run['worker_transport'] ?? '') !== 'admin_ajax') {
                $run['worker_transport'] = 'admin_ajax';
                if (sanitize_key((string)($run['resume_reason'] ?? '')) === 'awaiting_server_cron') { $run['resume_reason'] = 'awaiting_admin_ajax'; }
                $this->ebay_run_save($run);
            }
            return array('status'=>'already_running','run_uuid'=>(string)$run['run_uuid'],'phase'=>(string)$run['phase'],'transport'=>'admin_ajax');
        }
        if ((string)($run['schema'] ?? '') === '1.0' && sanitize_key((string)($run['status'] ?? '')) === 'failed'
            && sanitize_key((string)($run['error_code'] ?? '')) === 'blocked_migration_required') {
            return new WP_Error('blocked_migration_required', sanitize_text_field((string)($run['error_message'] ?? 'Offener Altzustand muss kontrolliert migriert werden.')));
        }
        $settings = $this->ebay_settings();
        if (empty($settings['enabled']) && !$manual) { return array('status'=>'disabled'); }
        $errors = $this->ebay_configuration_errors($settings);
        if ($errors) { return new WP_Error('ebay_configuration_invalid', implode(' ', $errors)); }
        $scope = $this->ebay_selection_scope_for_enabled_routes('all', $settings);
        if ($scope === '') { return new WP_Error('ebay_routes_disabled', 'PRIVATE und BUSINESS sind beide deaktiviert.'); }
        $uuid = $this->ebay_run_new_uuid();
        $run = array(
            'schema'=>'1.0','build'=>self::EBAY_RUNTIME_BUILD,'run_uuid'=>$uuid,'status'=>'running','phase'=>'reconcile_local','operation'=>$operation,
            'remote_subphase'=>$operation === 'sync' ? 'discovery' : 'inventory','started_at'=>time(),'updated_at'=>time(),'finished_at'=>0,
            'owner'=>'','lease_expires_at'=>0,'worker_transport'=>'admin_ajax','resume_reason'=>'awaiting_admin_ajax','no_progress_count'=>0,'last_progress_at'=>time(),'progress_seq'=>0,'last_transport_tick_at'=>0,'transport_tick_count'=>0,
            'config_snapshot'=>array('seller_routes'=>array('private'=>!empty($settings['private_enabled']),'business'=>!empty($settings['business_enabled'])),'settings'=>$this->ebay_run_settings_snapshot($settings)),
            'catalog_version'=>hash_file('sha256', __DIR__ . '/../assets/ebay-portal-catalog-v2.json') ?: '',
            'policy_version'=>self::EBAY_CONTENT_POLICY_VERSION,'private_classifier_version'=>self::EBAY_PRIVATE_CLASSIFIER_VERSION,'business_classifier_version'=>self::EBAY_BUSINESS_CLASSIFIER_VERSION,'progress_contract_version'=>$this->ebay_run_progress_contract_version(),
            'phase_state'=>array(),'coverage'=>array(),'gapfill'=>array('attempts'=>0,'missing'=>array()),'errors'=>array(),
            'start_manifest'=>array('operation'=>$operation,'selection_scope'=>$scope,'seller_routes'=>array('private'=>!empty($settings['private_enabled']),'business'=>!empty($settings['business_enabled']))),
            'end_manifest'=>array(),
        );
        $this->ebay_run_save($run);
        $this->ebay_run_schedule_worker(10);
        return array('status'=>'queued','run_uuid'=>$uuid,'phase'=>'reconcile_local');
    }

    private function ebay_run_fail($code, $message, $details = array()) {
        $run = $this->ebay_run_load();
        if ((string)($run['schema'] ?? '') !== '1.0') { $run = array('schema'=>'1.0','run_uuid'=>$this->ebay_run_new_uuid(),'started_at'=>time()); }
        $failed_phase=sanitize_key((string)($run['phase']??''));
        $details=is_array($details)?$details:array();
        if(empty($details['phase'])){$details['phase']=$failed_phase;}
        if(empty($details['build'])){$details['build']=self::EBAY_RUNTIME_BUILD;}
        if(empty($details['progress_contract_version'])){$details['progress_contract_version']=$this->ebay_run_progress_contract_version();}
        $run['status']='failed';$run['phase']='failed';$run['finished_at']=time();
        $run['error_code']=sanitize_key((string)$code);$run['error_message']=sanitize_text_field((string)$message);
        $run['progress_contract_version']=$this->ebay_run_progress_contract_version();
        if (!isset($run['errors']) || !is_array($run['errors'])) { $run['errors']=array(); }
        $run['errors'][]=array('code'=>$run['error_code'],'message'=>$run['error_message'],'at'=>time(),'details'=>$details);
        $run['owner']='';$run['lease_expires_at']=0;
        return $this->ebay_run_save($run);
    }

    private function ebay_run_complete($manifest = array()) {
        $run=$this->ebay_run_load();
        $run['status']='completed';$run['phase']='completed';$run['finished_at']=time();$run['resume_reason']='';
        $run['end_manifest']=is_array($manifest)?$manifest:array();$run['owner']='';$run['lease_expires_at']=0;
        return $this->ebay_run_save($run);
    }

    /** Mirror the real component cursor/state into the one durable canonical run.
     * Legacy workers still persist their own bounded job state; the canonical run
     * must snapshot that real state after every tick so progress/no-progress,
     * reloads and upgrades observe the same cursors instead of stale phase_state. */
    private function ebay_run_capture_component_state($run = null, $keys = array()) {
        $run=is_array($run)?$run:$this->ebay_run_load();
        if(!$this->ebay_run_is_open($run)){return $run;}
        $keys=$keys?array_values(array_unique(array_map('sanitize_key',(array)$keys))):array('maintenance','discovery','refresh','selection');
        if(!isset($run['phase_state'])||!is_array($run['phase_state'])){$run['phase_state']=array();}
        foreach($keys as $key){
            $state=array();
            if($key==='maintenance' && method_exists($this,'ebay_maintenance_state_load')){$state=$this->ebay_maintenance_state_load();}
            elseif($key==='discovery' && method_exists($this,'ebay_sync_job_load')){$state=$this->ebay_sync_job_load();}
            elseif($key==='refresh' && method_exists($this,'ebay_refresh_job_load')){$state=$this->ebay_refresh_job_load();}
            elseif($key==='selection' && method_exists($this,'ebay_selection_state_load')){$state=$this->ebay_selection_state_load();}
            if(is_array($state)&&$state){$run['phase_state'][$key]=$state;}
        }
        return $this->ebay_run_save($run);
    }

    private function ebay_run_progress_fingerprint($run) {
        $run=is_array($run)?$run:array();$phase_state=is_array($run['phase_state']??null)?$run['phase_state']:array();
        $sync=is_array($phase_state['discovery']??null)?$phase_state['discovery']:array();
        $refresh=is_array($phase_state['refresh']??null)?$phase_state['refresh']:array();
        $selection=is_array($phase_state['selection']??null)?$phase_state['selection']:array();
        $maintenance=is_array($phase_state['maintenance']??null)?$phase_state['maintenance']:array();
        return hash('sha256', wp_json_encode(array(
            'phase'=>sanitize_key((string)($run['phase']??'')),'remote_subphase'=>sanitize_key((string)($run['remote_subphase']??'')),'progress_contract_version'=>sanitize_text_field((string)($run['progress_contract_version']??'')),
            'sync'=>array('status'=>$sync['status']??'','profile_cursor'=>absint($sync['profile_cursor']??0),'progress_seq'=>absint($sync['progress_seq']??0),'current_page_index'=>absint($sync['current_page']['index']??0)),
            'refresh'=>array('status'=>$refresh['status']??'','last_id'=>absint($refresh['last_id']??0),'progress_seq'=>absint($refresh['progress_seq']??0),'checked'=>absint($refresh['summary']['checked']??0),'phase'=>$refresh['summary']['phase']??''),
            // One authoritative selection progress contract. Do not duplicate
            // a partial cursor list here: that omission caused the V6.41.3
            // production false-stall during fair PRIVATE per-leaf preparation.
            'selection_fingerprint'=>method_exists($this,'ebay_selection_progress_fingerprint') ? $this->ebay_selection_progress_fingerprint($selection) : '',
            'maintenance'=>array('cursor'=>absint($maintenance['cursor']??0),'completed_at'=>absint($maintenance['completed_at']??0)),
            'coverage'=>array('covered'=>absint($run['coverage']['covered']??0),'missing'=>count((array)($run['coverage']['missing']??array()))),
            'gapfill_attempts'=>absint($run['gapfill']['attempts']??0),
        ), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    }

    private function ebay_run_acquire_lease(&$run) {
        $run=$this->ebay_run_load();
        if(!$this->ebay_run_is_open($run)){return false;}
        $now=time();$owner=sanitize_text_field((string)($run['owner']??''));$expires=absint($run['lease_expires_at']??0);
        if($owner!=='' && $expires>$now){return false;}
        $token='worker:'.substr(hash('sha256', self::EBAY_RUNTIME_BUILD.'|'.microtime(true).'|'.mt_rand()),0,24);
        $candidate=$run;$candidate['owner']=$token;$candidate['lease_expires_at']=$now+45;$candidate['last_worker_at']=$now;$candidate['schema']='1.0';$candidate['build']=self::EBAY_RUNTIME_BUILD;$candidate['updated_at']=$now;

        // Acquire the persistent lease atomically. Two simultaneous cron requests
        // must not both become owner after reading the same expired state.
        global $wpdb;
        if(is_object($wpdb) && isset($wpdb->options) && method_exists($wpdb,'query') && method_exists($wpdb,'prepare') && function_exists('maybe_serialize')){
            $key=$this->ebay_run_option_key();$before=maybe_serialize($run);$after=maybe_serialize($candidate);
            $changed=$wpdb->query($wpdb->prepare("UPDATE {$wpdb->options} SET option_value=%s WHERE option_name=%s AND option_value=%s",$after,$key,$before));
            if((int)$changed!==1){$run=$this->ebay_run_load();return false;}
            if(function_exists('wp_cache_delete')){wp_cache_delete($key,'options');wp_cache_delete('alloptions','options');}
            $run=$candidate;return $token;
        }

        // Test/stub fallback: WordPress without a query-capable options table.
        $this->ebay_run_save($candidate);$verify=$this->ebay_run_load();
        if(!hash_equals($token,sanitize_text_field((string)($verify['owner']??'')))){return false;}
        $run=$verify;return $token;
    }

    private function ebay_run_release_lease($token) {
        $run=$this->ebay_run_load();$owner=sanitize_text_field((string)($run['owner']??''));
        if ($token!=='' && $owner!=='' && hash_equals($owner,$token)) {$run['owner']='';$run['lease_expires_at']=0;$this->ebay_run_save($run);}
    }

    private function ebay_run_set_phase($phase, $resume_reason = '') {
        $run=$this->ebay_run_load();if(!$this->ebay_run_is_open($run)){return $run;}
        $run['phase']=sanitize_key((string)$phase);$run['resume_reason']=sanitize_key((string)$resume_reason);$run['progress_seq']=absint($run['progress_seq']??0)+1;$run['last_progress_at']=time();$run['no_progress_count']=0;
        return $this->ebay_run_save($run);
    }

    private function ebay_run_tick_reconcile($run, $settings) {
        $stats=$this->run_ebay_maintenance_v2(25,false,4,true);
        if (is_wp_error($stats)) { $this->ebay_run_fail($stats->get_error_code(),$stats->get_error_message()); return; }
        $this->ebay_run_capture_component_state(null,array('maintenance'));
        $state=$this->ebay_maintenance_state_load();
        if ($this->ebay_maintenance_state_is_current($state)) {
            $this->ebay_run_set_phase('refresh_remote','');
        }
    }

    private function ebay_run_tick_remote($run, $settings) {
        $sub=sanitize_key((string)($run['remote_subphase']??'inventory'));
        if ($sub==='discovery') {
            $job=$this->ebay_sync_job_load();
            $status=sanitize_key((string)($job['status']??''));
            if ($status==='partial') {
                if ($this->ebay_sync_job_is_resumable_partial($job) && sanitize_key((string)($job['scope']??''))==='all') {
                    $author_id=absint($job['listing_author_id']??0);
                    $job=$this->ebay_sync_resume_partial_job($job,$author_id);
                    if(!$job){$this->ebay_run_fail('discovery_partial_resume_failed','Persistierter Discovery-Checkpoint konnte nicht fortgesetzt werden.',array('stopped_reason'=>sanitize_key((string)($job['summary']['budget']['stopped_reason']??''))));return;}
                } else {
                    $reason=sanitize_key((string)($job['summary']['budget']['stopped_reason']??'discovery_partial_unresumable'));
                    $this->ebay_run_fail('discovery_partial_unresumable','Discovery endete in einem nicht fortsetzbaren PARTIAL-Zustand.',array('stopped_reason'=>$reason,'scope'=>sanitize_key((string)($job['scope']??''))));return;
                }
            } elseif (!$this->ebay_sync_job_is_open($job) && $status!=='completed') {
                $start=$this->ebay_start_sync_job(false,'all','background');
                if (is_wp_error($start)) {$this->ebay_run_fail($start->get_error_code(),$start->get_error_message());return;}
            }
            $this->run_ebay_sync_worker(true);
            $this->ebay_run_capture_component_state(null,array('discovery'));
            $job=$this->ebay_sync_job_load();$status=sanitize_key((string)($job['status']??''));
            if ($status==='failed') {
                $error_list=is_array($job['summary']['errors']??null)?$job['summary']['errors']:array();
                $last=$error_list ? (array)$error_list[count($error_list)-1] : array();
                $code=sanitize_key((string)($last['code']??$job['failure_reason']??'discovery_failed'));
                $msg=sanitize_text_field((string)($last['error']??$job['failure_reason']??'eBay-Discovery ist fehlgeschlagen.'));
                $this->ebay_run_fail($code!==''?$code:'discovery_failed',$msg);return;
            }
            if ($status==='completed') {
                $run=$this->ebay_run_load();$run['remote_subphase']='inventory';$run['resume_reason']='';$run['progress_seq']=absint($run['progress_seq']??0)+1;$run['last_progress_at']=time();$this->ebay_run_save($run);
            }
            return;
        }

        $job=$this->ebay_refresh_job_load();
        if (!$this->ebay_refresh_job_is_open($job)) {
            if ($this->ebay_refresh_job_is_resumable_partial($job)) {
                $job=$this->ebay_refresh_resume_partial_job($job);
            } elseif ($this->ebay_refresh_job_is_bounded_manual_partial($job)) {
                $job=$this->ebay_refresh_resume_bounded_remote_job($job);
            } elseif (sanitize_key((string)($job['status']??''))!=='completed') {
                $start=$this->ebay_start_inventory_refresh_job(true,true);
                if (is_wp_error($start)) {$this->ebay_run_fail($start->get_error_code(),$start->get_error_message());return;}
                $job=$this->ebay_refresh_job_load();
            }
        }
        if ($this->ebay_refresh_job_is_open($job)) {$this->run_ebay_inventory_refresh_worker(true);$job=$this->ebay_refresh_job_load();}
        $this->ebay_run_capture_component_state(null,array('refresh'));
        $status=sanitize_key((string)($job['status']??''));
        if ($status==='failed') {
            $code=sanitize_key((string)($job['summary']['failure_reason']??$job['failure_reason']??'inventory_refresh_failed'));
            $this->ebay_run_fail($code!==''?$code:'inventory_refresh_failed',sanitize_text_field((string)($job['summary']['stopped_reason']??$job['summary']['failure_reason']??'eBay-Bestandsabgleich ist fehlgeschlagen.')));return;
        }
        if ($status==='partial') {
            $run=$this->ebay_run_load();$run['resume_reason']=sanitize_key((string)($job['summary']['stopped_reason']??'bounded_checkpoint'));$this->ebay_run_save($run);return;
        }
        if ($status==='completed') {$this->ebay_run_set_phase('selection_prepare','');}
    }

    private function ebay_run_tick_selection($run, $settings) {
        $scope=$this->ebay_run_selection_scope($run);
        if($scope===''){$this->ebay_run_fail('selection_scope_empty','Der beim Runstart gespeicherte Seller-Routen-Snapshot enthält keine aktive Route.');return;}
        $canonical_phase=sanitize_key((string)($run['phase']??''));
        $selection=$this->ebay_selection_state_load();
        if(!$this->ebay_selection_state_is_open($selection) && sanitize_key((string)($selection['status']??''))!=='complete'){
            $selection=$this->ebay_selection_request('canonical_run','run:'.sanitize_text_field((string)$run['run_uuid']),true,$scope);
            $this->ebay_run_capture_component_state(null,array('selection'));
        }
        if(sanitize_key((string)($selection['status']??''))==='failed'){
            $this->ebay_run_fail(sanitize_key((string)($selection['failure_reason']??'selection_failed')),sanitize_text_field((string)($selection['error']??$selection['failure_reason']??'Bestandsauswahl ist fehlgeschlagen.')));return;
        }
        if(sanitize_key((string)($selection['status']??''))==='complete'){$this->ebay_run_set_phase('coverage_verify','');return;}
        // The target contract names BUSINESS selection as its own durable phase.
        // Winner ranking is produced during bounded selection_prepare. Expose one
        // state-only checkpoint before materialisation so the canonical run never
        // jumps directly from prepare to mutation. No winner/source/output data is
        // changed here; an inconsistent nested selection fails closed.
        if($canonical_phase==='business_select'){
            $nested_phase=sanitize_key((string)($selection['phase']??''));
            if(!in_array($nested_phase,array('business_materialize','business_prune'),true)){
                $this->ebay_run_fail('business_select_checkpoint_invalid','BUSINESS-Select-Checkpoint passt nicht zum persistenten Selection-Zustand.',array('selection_phase'=>$nested_phase));return;
            }
            $this->ebay_run_set_phase('business_materialize','');
            return;
        }
        $selection=$this->ebay_selection_process_tick($settings,$selection);
        $this->ebay_run_capture_component_state(null,array('selection'));
        if(sanitize_key((string)($selection['status']??''))==='failed'){
            $this->ebay_run_fail(sanitize_key((string)($selection['failure_reason']??'selection_failed')),sanitize_text_field((string)($selection['error']??$selection['failure_reason']??'Bestandsauswahl ist fehlgeschlagen.')));return;
        }
        $phase=sanitize_key((string)($selection['phase']??''));
        $mapped='selection_prepare';
        if(in_array($phase,array('business_materialize','business_prune'),true)){
            $mapped=($canonical_phase==='selection_prepare' && $phase==='business_materialize')?'business_select':'business_materialize';
        }
        elseif(in_array($phase,array('private_prune','private','private_verify'),true)){$mapped=in_array($phase,array('private','private_verify'),true)?'private_materialize':'private_select';}
        $run=$this->ebay_run_load();if($this->ebay_run_is_open($run)){$run['phase']=$mapped;$this->ebay_run_save($run);}
        if(sanitize_key((string)($selection['status']??''))==='complete'){$this->ebay_run_set_phase('coverage_verify','');}
    }

    /** Public BUSINESS coverage from actual published output objects plus the
     * current source/policy/product-identity contract. The query is hard bounded;
     * a bound overflow fails closed instead of turning into an unbounded scan. */
    private function ebay_run_public_business_coverage() {
        $required=array_values(array_filter(array_map('sanitize_key',$this->ebay_business_required_product_concept_ids())));
        if(!$required){return array('required'=>0,'covered'=>0,'missing'=>array(),'counts'=>array(),'invalid'=>array(),'error_code'=>'business_supply_contract_invalid');}
        $required_map=array_fill_keys($required,true);$covered=array();$counts=array();$invalid=array();
        global $wpdb;
        if(!is_object($wpdb)||!method_exists($wpdb,'get_results')||!method_exists($this,'output_objects_table')){
            return array('required'=>count($required),'covered'=>0,'missing'=>$required,'counts'=>array(),'invalid'=>array(),'error_code'=>'business_public_storage_unavailable');
        }
        $output_table=$this->output_objects_table();$limit=1201;
        $objects=(array)$wpdb->get_results("SELECT * FROM {$output_table} WHERE provider='ebay' AND output_type='product_campaign' AND status='published' AND campaign_post_id>0 ORDER BY id ASC LIMIT {$limit}",ARRAY_A);
        if(count($objects)>1200){
            return array('required'=>count($required),'covered'=>0,'missing'=>$required,'counts'=>array(),'invalid'=>array(),'error_code'=>'business_public_object_bound_exceeded');
        }
        $now=time();
        foreach($objects as $object){
            $oid=absint($object['id']??0);$hash=strtolower(sanitize_text_field((string)($object['creative_identity_hash']??'')));
            if(!preg_match('/^[a-f0-9]{64}$/',$hash)){$invalid[$oid?:count($invalid)+1]='creative_identity_missing';continue;}
            $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->ebay_items_table()} WHERE creative_identity_hash=%s AND seller_account_type='BUSINESS' ORDER BY id DESC LIMIT 1",$hash),ARRAY_A);
            if(!is_array($row)){$invalid[$oid]='source_missing';continue;}
            if(sanitize_key((string)($row['status']??''))==='blocked_manual'){$invalid[$oid]='manual_block';continue;}
            if(sanitize_key((string)($row['source_state']??''))!=='available'){$invalid[$oid]='source_not_available';continue;}
            if(sanitize_key((string)($row['policy_state']??''))!=='allowed'){$invalid[$oid]='policy_not_allowed';continue;}
            if(!in_array(sanitize_key((string)($row['route_state']??'')),array('ready','review_last_good'),true)){$invalid[$oid]='route_not_public';continue;}
            if(absint($row['fresh_until']??0)<=$now){$invalid[$oid]='source_stale';continue;}
            $end=absint($row['item_end_at']??0);if($end>0&&$end<=$now){$invalid[$oid]='source_ended';continue;}
            if($this->ebay_public_content_policy_reason_from_source_row($row,(string)($row['title']??''))!==''){$invalid[$oid]='content_policy';continue;}
            $image=$this->ebay_remote_image_url_validate((string)($object['image_url']??$row['image_url']??''));
            if($image===''){$invalid[$oid]='image_invalid';continue;}

            $payload=json_decode((string)($row['source_payload']??''),true);$payload=is_array($payload)?$payload:array();
            $class=is_array($payload['portal_classification']??null)?$payload['portal_classification']:array();
            $concept=sanitize_key((string)($class['product_concept_id']??''));
            if($concept===''||!isset($required_map[$concept])||sanitize_key((string)($row['rule_id']??''))!==$concept){$invalid[$oid]='concept_identity_mismatch';continue;}
            if(sanitize_key((string)($class['business_match_contract']??''))!=='concept_v3'){$invalid[$oid]='concept_contract_missing';continue;}

            $campaign_id=absint($object['campaign_post_id']??0);
            $campaign=method_exists($this,'output_campaign_by_post_id')?$this->output_campaign_by_post_id($campaign_id):null;
            if(!is_array($campaign) && function_exists('get_post')){$post=get_post($campaign_id);$campaign=$post?$this->campaign_from_post($post):null;}
            if(!is_array($campaign)||empty($campaign['active'])||sanitize_key((string)($campaign['network']??''))!=='ebay'||sanitize_key((string)($campaign['creative_type']??''))!=='product'){$invalid[$oid]='campaign_not_public';continue;}
            $actual=array_values(array_unique(array_filter(array_map(array($this,'automation_normalize_target_key'),(array)($campaign['automation_target_keys']??array())))));
            $expected=array_values(array_unique(array_filter(array_map(array($this,'automation_normalize_target_key'),$this->ebay_business_campaign_target_keys($row)))));
            if(!$actual||!$expected||!array_intersect($actual,$expected)){$invalid[$oid]='target_mismatch';continue;}

            $covered[$concept]=1;$counts[$concept]=absint($counts[$concept]??0)+1;
        }
        $over=array();foreach($counts as $concept=>$count){if($count>3){$over[$concept]=$count;}}
        $missing=array_values(array_diff($required,array_keys($covered)));sort($missing,SORT_STRING);
        $out=array('required'=>count($required),'covered'=>count($covered),'missing'=>$missing,'counts'=>$counts,'invalid'=>$invalid,'over_capacity'=>$over);
        if($over){$out['error_code']='business_family_cap_exceeded';}
        return $out;
    }

    private function ebay_run_verify_private_public($settings) {
        if(empty($settings['private_enabled'])){return array('status'=>'disabled','public'=>0,'invalid'=>array());}
        global $wpdb;$invalid=array();$public=0;$cap=min(250,max(1,absint($settings['private_active_cap']??250)));
        if(!is_object($wpdb)||!method_exists($wpdb,'get_results')||!method_exists($wpdb,'get_row')){return array('status'=>'failed','error_code'=>'private_public_storage_unavailable','public'=>0,'invalid'=>array());}
        $postmeta=isset($wpdb->postmeta)?$wpdb->postmeta:$wpdb->prefix.'postmeta';
        $markers=array('_ppar_ebay_item_id','_ppar_ebay_seller_type','_ppar_ebay_affiliate_url','_ppar_ebay_source_hash','_ppar_ebay_portal_path','_ppar_ebay_target_term_id');
        $quoted=array_map(static function($v){return "'".esc_sql($v)."'";},$markers);
        $sql="SELECT DISTINCT p.ID FROM {$wpdb->posts} p INNER JOIN {$postmeta} pm ON pm.post_id=p.ID WHERE p.post_type='hp_listing' AND p.post_status='publish' AND pm.meta_key IN (".implode(',',$quoted).") ORDER BY p.ID ASC LIMIT 1001";
        $posts=(array)$wpdb->get_results($sql,ARRAY_A);
        if(count($posts)>1000){return array('status'=>'failed','error_code'=>'private_public_bound_exceeded','public'=>count($posts),'invalid'=>array());}
        $now=time();
        foreach($posts as $post){
            $id=absint($post['ID']??0);if($id<=0){continue;}$own=$this->ebay_private_post_ownership($id);if(empty($own['owned'])){continue;}$public++;
            $hard=$this->ebay_private_post_hard_negative_reason($id);if($hard!==''){$invalid[$id]='hard_negative:'.$hard;continue;}
            $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->ebay_items_table()} WHERE listing_post_id=%d AND seller_account_type='INDIVIDUAL' ORDER BY id DESC LIMIT 1",$id),ARRAY_A);
            if(!is_array($row)){$invalid[$id]='source_missing';continue;}
            if(sanitize_key((string)($row['status']??''))==='blocked_manual'){$invalid[$id]='manual_block';continue;}
            if(sanitize_key((string)($row['source_state']??''))!=='available'){$invalid[$id]='source_not_available';continue;}
            if(sanitize_key((string)($row['policy_state']??''))!=='allowed'){$invalid[$id]='policy_not_allowed';continue;}
            if(sanitize_key((string)($row['route_state']??''))!=='ready'){$invalid[$id]='route_not_ready';continue;}
            $target=absint($row['target_term_id']??0);if($target<=0){$invalid[$id]='target_missing';continue;}
            if(absint($row['fresh_until']??0)<=$now){$invalid[$id]='source_stale';continue;}
            $end=absint($row['item_end_at']??0);if($end>0&&$end<=$now){$invalid[$id]='ended';continue;}
            $reason=$this->ebay_public_content_policy_reason_from_source_row($row,(string)($row['title']??''));if($reason!==''){$invalid[$id]='policy:'.$reason;continue;}
            if($this->ebay_remote_image_url_validate((string)($row['image_url']??''))===''){$invalid[$id]='image_invalid';continue;}
            if(function_exists('wp_get_post_terms')){
                $terms=wp_get_post_terms($id,'hp_listing_category',array('fields'=>'ids'));
                if(is_wp_error($terms)||!in_array($target,array_map('absint',(array)$terms),true)){$invalid[$id]='target_taxonomy_mismatch';continue;}
            }
        }
        if($public>$cap){return array('status'=>'failed','error_code'=>'private_public_cap_exceeded','public'=>$public,'invalid'=>$invalid);}
        if($invalid){return array('status'=>'failed','error_code'=>'private_public_gate_failed','public'=>$public,'invalid'=>$invalid);}
        return array('status'=>'pass','public'=>$public,'invalid'=>array());
    }

    private function ebay_run_tick_coverage($run, $settings) {
        $coverage=empty($settings['business_enabled'])?array('required'=>0,'covered'=>0,'missing'=>array(),'counts'=>array()):$this->ebay_run_public_business_coverage();
        if(!empty($coverage['error_code'])){$this->ebay_run_fail((string)$coverage['error_code'],'BUSINESS-Coverage-Gate ist technisch oder fachlich fehlgeschlagen.',array('coverage'=>$coverage));return;}
        $run=$this->ebay_run_load();$run['coverage']=$coverage;$run['progress_seq']=absint($run['progress_seq']??0)+1;$run['last_progress_at']=time();$this->ebay_run_save($run);
        if(!empty($settings['business_enabled']) && !empty($coverage['missing'])){
            $attempts=absint($run['gapfill']['attempts']??0);
            if($attempts<1){$run['gapfill']['attempts']=$attempts+1;$run['gapfill']['missing']=$coverage['missing'];$run['phase']='gapfill_discovery';$run['resume_reason']='business_coverage_missing';$this->ebay_run_save($run);return;}
            $exceptions=array();foreach($coverage['missing'] as $id){$exceptions[$id]=array('code'=>'insufficient_safe_sources','approved'=>0);}
            $run['coverage']['exceptions']=$exceptions;$this->ebay_run_save($run);
            $this->ebay_run_fail('insufficient_safe_sources','Nach gezieltem Gap-Fill fehlen weiterhin '.count($coverage['missing']).' BUSINESS-Produktfamilien.',array('missing'=>$coverage['missing']));return;
        }
        $this->ebay_run_set_phase('public_verify','');
    }

    private function ebay_run_tick_gapfill($run, $settings) {
        $missing=array_values(array_unique(array_filter(array_map('sanitize_key',(array)($run['gapfill']['missing']??array())))));
        if(!$missing){$this->ebay_run_set_phase('public_verify','');return;}
        // Store the exact missing list in canonical state. Existing discovery
        // profile construction reads this list through ebay_business_recovery_missing_concept_ids().
        $run['coverage']['missing']=$missing;$this->ebay_run_save($run);
        $job=$this->ebay_sync_job_load();
        // A completed full-discovery substate must not suppress the one targeted
        // recovery pass. Reset only the nested discovery phase state, never the run.
        if(sanitize_key((string)($job['status']??''))==='completed' && sanitize_key((string)($job['scope']??''))!=='business_recovery'){$this->ebay_run_phase_state_save('discovery',array());$job=array();}
        $status=sanitize_key((string)($job['status']??''));
        if($status==='partial'){
            if($this->ebay_sync_job_is_resumable_partial($job) && sanitize_key((string)($job['scope']??''))==='business_recovery'){
                $author_id=absint($job['listing_author_id']??0);
                $job=$this->ebay_sync_resume_partial_job($job,$author_id);
                if(!$job){$this->ebay_run_fail('gapfill_partial_resume_failed','Persistierter Gap-Fill-Checkpoint konnte nicht fortgesetzt werden.',array('stopped_reason'=>sanitize_key((string)($job['summary']['budget']['stopped_reason']??''))));return;}
            }else{
                $reason=sanitize_key((string)($job['summary']['budget']['stopped_reason']??'gapfill_partial_unresumable'));
                $this->ebay_run_fail('gapfill_partial_unresumable','BUSINESS-Gap-Fill endete in einem nicht fortsetzbaren PARTIAL-Zustand.',array('stopped_reason'=>$reason,'scope'=>sanitize_key((string)($job['scope']??''))));return;
            }
        }elseif(!$this->ebay_sync_job_is_open($job) && $status!=='completed'){
            $start=$this->ebay_start_sync_job(false,'business_recovery','background');if(is_wp_error($start)){$this->ebay_run_fail($start->get_error_code(),$start->get_error_message());return;}
        }
        $this->run_ebay_sync_worker(true);$this->ebay_run_capture_component_state(null,array('discovery'));$job=$this->ebay_sync_job_load();$status=sanitize_key((string)($job['status']??''));
        if($status==='failed'){$this->ebay_run_fail('gapfill_discovery_failed','Gezielte BUSINESS-Gap-Fill-Discovery ist fehlgeschlagen.');return;}
        if($status==='completed'){
            // Re-run BUSINESS selection through the same run. PRIVATE is frozen
            // and must not participate in gap-fill.
            $this->ebay_run_phase_state_save('selection',array());
            $run=$this->ebay_run_load();$run['phase']='gapfill_select';$run['resume_reason']='';$this->ebay_run_save($run);
        }
    }

    private function ebay_run_tick_gapfill_select($run, $settings) {
        $selection=$this->ebay_selection_state_load();
        $expected_owner='run:'.sanitize_text_field((string)$run['run_uuid']);
        $selection_status=sanitize_key((string)($selection['status']??''));
        $is_expected_terminal=$selection_status==='complete'
            && sanitize_key((string)($selection['reason']??''))==='canonical_gapfill'
            && sanitize_key((string)($selection['selection_scope']??''))==='business'
            && sanitize_text_field((string)($selection['owner']??''))===$expected_owner;
        // The initial all-routes selection is terminal when gap-fill begins.
        // It must never be mistaken for the required targeted BUSINESS rerun.
        // Production selection state lives in its own durable option, so clearing
        // only canonical phase_state is insufficient. Request a fresh terminal-to-
        // new BUSINESS selection unless the stored state already belongs to this
        // exact canonical gap-fill run.
        if(!$this->ebay_selection_state_is_open($selection) && !$is_expected_terminal){
            $selection=$this->ebay_selection_request('canonical_gapfill',$expected_owner,true,'business');
            $this->ebay_run_capture_component_state(null,array('selection'));
        }
        if(sanitize_key((string)($selection['status']??''))==='failed'){$this->ebay_run_fail(sanitize_key((string)($selection['failure_reason']??'gapfill_selection_failed')),sanitize_text_field((string)($selection['error']??'Gap-Fill-Auswahl ist fehlgeschlagen.')));return;}
        if(sanitize_key((string)($selection['status']??''))!=='complete'){$selection=$this->ebay_selection_process_tick($settings,$selection);$this->ebay_run_capture_component_state(null,array('selection'));}
        if(sanitize_key((string)($selection['status']??''))==='complete'){$this->ebay_run_set_phase('coverage_verify','');}
    }

    private function ebay_run_tick_public_verify($run, $settings) {
        $business=empty($settings['business_enabled'])?array('required'=>0,'covered'=>0,'missing'=>array(),'counts'=>array()):$this->ebay_run_public_business_coverage();
        if(!empty($business['error_code'])){$this->ebay_run_fail((string)$business['error_code'],'BUSINESS-Public-Gate ist technisch oder fachlich fehlgeschlagen.',array('business'=>$business));return;}
        if(!empty($settings['business_enabled']) && !empty($business['missing'])){$this->ebay_run_fail('public_business_coverage_failed','Public-Gate findet '.count($business['missing']).' unversorgte BUSINESS-Produktfamilien.',array('missing'=>$business['missing']));return;}
        $private=$this->ebay_run_verify_private_public($settings);if(($private['status']??'')==='failed'){$this->ebay_run_fail((string)($private['error_code']??'private_public_gate_failed'),'PRIVATE-Public-Gate ist fehlgeschlagen.',array('invalid'=>$private['invalid']??array(),'public'=>$private['public']??0));return;}
        $manifest=array('business'=>$business,'private'=>$private,'verified_at'=>time(),'run_uuid'=>(string)$run['run_uuid']);$this->ebay_run_complete($manifest);
    }

    public function run_ebay_canonical_worker() {
        $run=$this->ebay_run_adopt_legacy_if_needed();if(!$this->ebay_run_is_open($run)){return false;}
        $current_progress_contract=$this->ebay_run_progress_contract_version();
        if(!hash_equals($current_progress_contract,sanitize_text_field((string)($run['progress_contract_version']??'')))){
            $run['progress_contract_version']=$current_progress_contract;$run=$this->ebay_run_save($run);
        }
        $token=$this->ebay_run_acquire_lease($run);if($token===false){return false;}
        $before=$this->ebay_run_progress_fingerprint($this->ebay_run_load());
        $this->ebay_canonical_worker_active=true;
        $this->ebay_run_settings_override=$this->ebay_run_effective_settings($run);
        try{
            $run=$this->ebay_run_load();$settings=$this->ebay_run_settings_override;$phase=sanitize_key((string)($run['phase']??''));
            if($phase==='reconcile_local'){$this->ebay_run_tick_reconcile($run,$settings);}
            elseif($phase==='refresh_remote'){$this->ebay_run_tick_remote($run,$settings);}
            elseif(in_array($phase,array('selection_prepare','business_select','business_materialize','private_select','private_materialize'),true)){$this->ebay_run_tick_selection($run,$settings);}
            elseif($phase==='coverage_verify'){$this->ebay_run_tick_coverage($run,$settings);}
            elseif($phase==='gapfill_discovery'){$this->ebay_run_tick_gapfill($run,$settings);}
            elseif($phase==='gapfill_select'){$this->ebay_run_tick_gapfill_select($run,$settings);}
            elseif($phase==='public_verify'){$this->ebay_run_tick_public_verify($run,$settings);}
            else{$this->ebay_run_fail('canonical_phase_unknown','Unbekannte kanonische eBay-Phase: '.$phase);}
        }catch(Throwable $e){$this->ebay_run_fail('canonical_worker_runtime_error',$e->getMessage());}
        finally{
            $this->ebay_run_settings_override=null;$this->ebay_canonical_worker_active=false;$this->ebay_run_release_lease($token);
        }
        $fresh=$this->ebay_run_load();
        if($this->ebay_run_is_open($fresh)){
            $after=$this->ebay_run_progress_fingerprint($fresh);
            if(hash_equals($before,$after)){$fresh['no_progress_count']=absint($fresh['no_progress_count']??0)+1;}else{$fresh['no_progress_count']=0;$fresh['last_progress_at']=time();$fresh['progress_seq']=absint($fresh['progress_seq']??0)+1;}
            $this->ebay_run_save($fresh);
            if(absint($fresh['no_progress_count']??0)>=3){$this->ebay_run_fail('canonical_worker_no_progress','Drei aufeinanderfolgende Worker-Ticks ohne echten Workflow-Fortschritt.',array('phase'=>$fresh['phase']??''));return false;}
            $this->ebay_run_schedule_worker(10);
        }
        return $this->ebay_run_load();
    }
}
