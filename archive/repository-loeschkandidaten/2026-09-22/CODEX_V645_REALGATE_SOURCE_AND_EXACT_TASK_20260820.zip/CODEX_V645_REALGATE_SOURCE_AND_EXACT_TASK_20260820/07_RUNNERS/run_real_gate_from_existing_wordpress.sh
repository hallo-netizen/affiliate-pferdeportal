#!/usr/bin/env bash
set -euo pipefail
# Usage:
#   WP_ROOT=/path/to/fresh-wordpress-7.0.1 WP=/path/to/wp-cli ./run_real_gate_from_existing_wordpress.sh
# Preconditions are intentionally strict: fresh isolated WP 7.0.1, PHP 8.4.x, real MariaDB, mysqli, V6.45 source copied and activated.
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${WP_ROOT:?set WP_ROOT}"
: "${WP:?set WP path}"
RG="$ROOT/03_REAL_GATE"
LOG="$ROOT/CODEX_EVIDENCE_REAL_GATE"
mkdir -p "$LOG"
cd "$WP_ROOT"

run_eval() { local n="$1" f="$2"; "$WP" eval-file "$RG/$f" --allow-root 2>&1 | tee "$LOG/$n-$f.log"; }

run_eval 01 verify_environment.php
run_eval 02 live800_resume.php
run_eval 03 negative_limits.php
run_eval 04 stale_cas.php
run_eval 05 soft_failure_recovery.php

# Lease-only concurrency: exactly one winner, four atomic rejects.
run_eval 06 setup_concurrent.php
shared=$(mktemp -d)
pids=()
for i in 1 2 3 4 5; do
  RG_SHARED_DIR="$shared" RG_WORKER_ID="$i" "$WP" eval-file "$RG/lease_barrier.php" --allow-root >"$shared/stdout-$i" 2>&1 & pids+=("$!")
done
for i in 1 2 3 4 5; do
  for n in $(seq 1 400); do [ -f "$shared/ready-$i" ] && break; sleep .05; done
  [ -f "$shared/ready-$i" ]
done
touch "$shared/go"
rc=0; for p in "${pids[@]}"; do wait "$p" || rc=1; done; [ "$rc" -eq 0 ]
cp -a "$shared" "$LOG/07_lease_workers"
RG_SHARED_DIR="$shared" "$WP" eval-file "$RG/assert_concurrent.php" --allow-root 2>&1 | tee "$LOG/08_assert_concurrent.log"
rm -rf "$shared"

# Full canonical-worker burst from a fresh persisted seed, then resume checkpoint to phase end.
run_eval 09 setup_concurrent.php
shared=$(mktemp -d)
pids=()
for i in 1 2 3 4 5; do
  RG_SHARED_DIR="$shared" RG_WORKER_ID="$i" "$WP" eval-file "$RG/tick_barrier.php" --allow-root >"$shared/stdout-$i" 2>&1 & pids+=("$!")
done
for i in 1 2 3 4 5; do
  for n in $(seq 1 400); do [ -f "$shared/ready-$i" ] && break; sleep .05; done
  [ -f "$shared/ready-$i" ]
done
touch "$shared/go"
rc=0; for p in "${pids[@]}"; do wait "$p" || rc=1; done; [ "$rc" -eq 0 ]
cp -a "$shared" "$LOG/10_tick_workers"
RG_SHARED_DIR="$shared" "$WP" eval-file "$RG/assert_tick_burst.php" --allow-root 2>&1 | tee "$LOG/11_assert_tick_burst.log"
rm -rf "$shared"
run_eval 12 continue_concurrent_checkpoint.php

# Final DB/plugin sanity and durable run dump.
"$WP" eval '$v=$GLOBALS["wpdb"]->get_var("SELECT 1"); if ((string)$v!=="1") { fwrite(STDERR,"DB_SANITY_FAIL\n"); exit(1); } echo "DB_SANITY_PASS\n";' --allow-root 2>&1 | tee "$LOG/13_db_sanity.log"
"$WP" plugin status affiliate-portal-router --allow-root 2>&1 | tee "$LOG/14_plugin_status.log"
"$WP" eval '$r=get_option(Pferdeportal_Affiliate_Router::OPTION_EBAY_RUN_STATE,array()); echo wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n";' --allow-root > "$LOG/15_final_run_state.json"

echo REAL_GATE_COMPLETE
