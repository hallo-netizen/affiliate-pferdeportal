#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/02_SOURCE_V645/affiliate-portal-router"
BASE="$ROOT/05_BASELINE_V644/affiliate-portal-router"
LOG="$ROOT/CODEX_EVIDENCE_SOURCE"
mkdir -p "$LOG"

# 1) Exact source identity
( cd "$ROOT/02_SOURCE_V645" && sha256sum -c SOURCE_SHA256.txt ) | tee "$LOG/01_source_sha256.log"

# 2) PHP syntax + JSON validity
find "$SRC" -type f -name '*.php' -print0 | sort -z | xargs -0 -n1 php -l | tee "$LOG/02_php_lint.log"
for f in "$SRC/assets/ebay-portal-catalog-v2.json" "$SRC/assets/portal-structure-v279.json"; do
  php -r '$f=$argv[1]; $x=json_decode(file_get_contents($f),true); if(json_last_error()!==JSON_ERROR_NONE){fwrite(STDERR,"JSON_FAIL $f ".json_last_error_msg()."\n"); exit(1);} echo "JSON_OK $f\n";' "$f"
done | tee "$LOG/03_json.log"

run_dir() {
  local dir="$1" out="$2"; shift 2
  : > "$out"
  local fail=0 count=0 assertions=0
  while IFS= read -r -d '' f; do
    count=$((count+1)); echo "===== $(basename "$f") =====" >> "$out"
    set +e
    PPAR_TEST_PLUGIN_DIR="$SRC" PPAR_BASELINE_PLUGIN_DIR="$BASE" PPAR_TEST_MASTER_ROOT="$ROOT" php "$f" >> "$out" 2>&1
    rc=$?
    set -e
    echo "__TEST_EXIT__ $rc $(basename "$f")" >> "$out"
    if [ "$rc" -ne 0 ]; then fail=$((fail+1)); fi
  done < <(find "$dir" -maxdepth 1 -type f -name '*.php' -print0 | sort -z)
  assertions=$(grep -oE 'ASSERTIONS=[0-9]+' "$out" | cut -d= -f2 | awk '{s+=$1} END{print s+0}')
  echo "COUNT=$count FAIL=$fail ASSERTIONS=$assertions" | tee -a "$out"
  [ "$fail" -eq 0 ]
}

# 3) V6.45 cause/race suite against exact V6.44 baseline
run_dir "$ROOT/04_TESTS/V645_ROOTCAUSE" "$LOG/04_v645_rootcause.log"

# 4) Existing V6.43 total-workflow regression against V6.45
run_dir "$ROOT/04_TESTS/V643_REGRESSION" "$LOG/05_v643_regression.log"

# 5) V6.44 functional regression against V6.45; architecture test is version-specific and is intentionally excluded here.
mkdir -p "$LOG/v644_functional_tmp"
find "$ROOT/04_TESTS/V644_ROOTCAUSE" -maxdepth 1 -type f -name '*.php' ! -name 'test_architecture_v644.php' -exec cp {} "$LOG/v644_functional_tmp/" \;
run_dir "$LOG/v644_functional_tmp" "$LOG/06_v644_functional.log"
rm -rf "$LOG/v644_functional_tmp"

# 6) V6.44 postmortem diagnostic. This test is intentionally a detector for the old mocked release proof.
# It MUST NOT be "repaired" or weakened merely to turn green. The exact expected diagnostic is two FAIL lines:
#   - release workflow test must not replace production selection_request/process_tick
#   - release workflow test must execute the real 311-concept manifest, not a 3-concept substitute
# Closure of these two gaps is the purpose of the separate REAL-GATE below, not a source-test rewrite.
POST="$LOG/07_v644_postmortem_gap_diagnostic.log"
set +e
PPAR_TEST_PLUGIN_DIR="$SRC" PPAR_BASELINE_PLUGIN_DIR="$BASE" PPAR_TEST_MASTER_ROOT="$ROOT" php "$ROOT/04_TESTS/V644_POSTMORTEM/test_v644_release_gate_gaps.php" > "$POST" 2>&1
post_rc=$?
set -e
cat "$POST"
[ "$post_rc" -ne 0 ]
grep -Fq 'FAIL release workflow test must not replace production selection_request/process_tick' "$POST"
grep -Fq 'FAIL release workflow test must execute the real 311-concept manifest, not a 3-concept substitute' "$POST"
[ "$(grep -c '^FAIL ' "$POST")" -eq 2 ]
echo 'POSTMORTEM_DIAGNOSTIC_EXPECTED_GAP_CONFIRMED' | tee -a "$POST"

# 7) Historical R5 regression
run_dir "$ROOT/04_TESTS/HISTORICAL_R5_54" "$LOG/08_historical_r5.log"

echo SOURCE_GATES_COMPLETE
