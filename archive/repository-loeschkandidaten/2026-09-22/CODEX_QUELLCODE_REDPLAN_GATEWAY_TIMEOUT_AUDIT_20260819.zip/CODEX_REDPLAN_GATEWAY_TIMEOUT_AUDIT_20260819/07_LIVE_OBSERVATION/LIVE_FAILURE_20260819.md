# Aktueller Live-Fehler – 19.08.2026

## Installierter Kandidat zum Fehlerzeitpunkt
- PSTE 0.53.0 REDPLAN_TIMEOUT_BULK_READ_ROOTFIX
- PSERC 0.25.3 REDPLAN_TIMEOUT_BULK_READ_ROOTFIX
- PPM 6.7.9 unverändert

## Vorbedingung
- Portalabgleich PSTE 0.52 zuvor LIVE COMPLETE.
- 562/562 Themen abgeschlossen.
- 549/549 Sandbox abgeschlossen.

## Beobachtung
Beim direkten Öffnen des WordPress-Menüpunkts **SEO Redaktionsplan** lädt die Seite zu lange und endet erneut in **Gateway Timeout**.

Das ist derselbe Fehlerbereich, der bereits in Schritt 12 ausdrücklich dokumentiert war: `SEO Redaktionsplan timeout`.

## Wichtige Konsequenz
Der lokale QA-Claim des 0.53/0.25.3-Pakets (u.a. synthetischer 42-Post-Hotpath 170→5 und ein kleiner Fresh-Compile) hat den realen synchronen Redaktionsplan-Ladepfad nicht ausreichend repräsentiert. Diese QA darf NICHT als Beweis übernommen werden, sondern muss von Codex unabhängig widerlegt/bestätigt werden.

## Nicht verfügbar
Server-/FPM-Logs stehen dem Nutzer nicht zur Verfügung. Der Auftrag darf deshalb nicht von Logzugriff abhängig gemacht werden. Falls der exakte FPM-Abbruchgrund ohne Log nicht beweisbar ist, ist stattdessen der source-seitig belegte ungebundene/zu teure synchrone Pfad exakt zu identifizieren und zu quantifizieren.
