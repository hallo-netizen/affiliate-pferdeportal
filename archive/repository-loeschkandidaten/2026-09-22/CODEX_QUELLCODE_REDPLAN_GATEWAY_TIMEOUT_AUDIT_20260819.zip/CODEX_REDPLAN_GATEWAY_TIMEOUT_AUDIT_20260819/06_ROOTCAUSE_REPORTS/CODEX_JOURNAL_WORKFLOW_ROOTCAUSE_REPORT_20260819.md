# Journal-Integration PSTE → PSERC → PPM: Root-Cause- und Architekturprüfung

**Prüfstand:** 2026-08-19  
**Ergebnis:** **BLOCKED – kein Installationskandidat freigegeben**

## 1. Entscheidung und belastbare Root Cause

Der beobachtete Browsercode `PSTE_CONTEXT_AJAX_INVALID_JSON_HTTP_500_LEN_205` ist **kein PHP-Fehlercode**. Er wird erst im Browser gebildet, wenn `admin-ajax.php` HTTP 500 und einen 205 Byte langen, nicht als JSON parsebaren Body liefert. Ohne PHP-/Webserver-Fatal-Log und den Response-Body kann aus diesem Code nicht zwischen Fatal, Memory Exhaustion, Timeout/Upstream-Abbruch oder fremder HTML-/Warning-Ausgabe unterschieden werden. Der exakte Live-Fatal ist daher nicht bewiesen.

Aus dem Quellcode sind dagegen zwei Architekturfehler des Live-Stands PSTE 0.49.0 bewiesen:

1. **Legacy-Reentry ruft innerhalb des AJAX-Ticks erneut den schweren Startpfad auf.** `PSTE_Context_Refresh::processBatch()` löscht für V1–V4 den Lock und ruft `start()` auf. `start()` erzeugt synchron Inventory und Redaktionsplan, baut die Article-Type-Registry, liest alle Sandbox-IDs, initialisiert den Payload-Audit, persistiert das gesamte Bundle und setzt den gesamten Pool auf `PENDING`. Damit ist gerade der erste Recovery-Tick nicht request-bounded.
2. **Jeder Context-Tick materialisiert trotz Batchgröße 5 globale Daten.** Nach dem Laden und vollständigen Hashen/Canonicalisieren des Snapshot-Bundles wird `PSTE_Context_Evaluator::buildIndex($inventory, $plan)` in jedem Context-Batch erneut aufgerufen. Ein Zeilenlimit begrenzt daher weder Speicher noch Laufzeit des Requests.

Zusätzlich ist der Abschluss-Tick ungebunden: `PSTE_Snapshot::baselineStatus()` baut die Live-Prüfungen erneut zusammen. Die Fehler bestanden als ungebundene Vollbestandsarbeit bereits vor Journal; Journal vergrößerte Daten- und Reentry-Fläche und machte sie im Live-Datensatz sichtbar. Journal ist somit Auslöser der Last-/Zustandskonstellation, aber nicht die technische Ursache des ungültigen JSON-Vertrags.

PSTE 0.50.0 erkennt diese Punkte, ist aber nicht freigabefähig: Der Kandidat verschiebt Vollbestandsarbeit in einzelne Stages, beweist jedoch keine harte Byte-/Element-/Zeitobergrenze für `stageInventory`, `stagePlan`, `stageRegistry` oder `buildFromStages`. Insbesondere der einmalige Shard-Build bleibt ein Vollbestandsrequest. Außerdem fehlt im Paket eine ausführbare WordPress-Integrationsmatrix für die geforderten persistierten Zustände. „Einmalig“ ist nicht gleich „request-bounded“.

## 2. Historischer semantischer Diff

| Stufe | Fachlogik | Technische Infrastruktur / neu entstandener Zustand |
|---|---|---|
| PSTE 0.43 | Pre-Journal-Referenz | Context-, Snapshot-, Sandbox- und Vollbestandsmechanismen existieren bereits; daher kein garantiert fehlerfreier Nullpunkt. |
| 0.44 | Journal-Registry, Titelregeln, Ontologie; Journal-Klasse/Vertrag | Keine Context-Architekturänderung. Erstmals Typkenntnis in mehreren Klassen/Verträgen. |
| 0.45 | Journal-Fallback-Router und Kategorieauflösung | Router wird in Normal Metadata, Sandbox Planner und Titelvalidierung verdrahtet; Cross-Core-Kopplung steigt. |
| 0.46 | Aktivierung gegen signierten kanonischen Plan | Kein Request-Budget-Fix. |
| 0.47 | Journal Live-Reentry/Pool-Freigabe | Automatischer AJAX-Reentry wird eingeführt; Repository/Admin werden geändert. Das ist der erste direkte zeitliche Eintritt des heutigen Fehlerpfads. |
| 0.48 | Fachlogik laut Diff unverändert | V4-Phasen, Bundle, Snapshot-/Sandbox-Batching, Bulk-Reads und globales fail-closed Update. Zeilenbatches kaschieren weiterhin globale Arbeit. |
| 0.49 live | Fachlogik laut Diff unverändert | V5-Audit; Legacy-BLOCKED wird automatisch reentered. Schwerer `start()` bleibt im AJAX-Reentry; Bundle und Index bleiben global. |
| 0.50 Kandidat | Fachlogik soll unverändert bleiben | V6-Stages und Shards; Legacy-Adoption ist verbessert. Stages und Shard-Materialisierung bleiben ohne nachgewiesene harte Request-Grenze. |

PSERC 0.23–0.25.2 erweitert Journal nicht über eine zentrale Schnittstelle, sondern ändert Compiler, Reader, Slot Allocator, Title/Language/Metadata/Topic-Evidence Gates und später Production Trigger/SEO Reader. PPM ändert neben signierten Verträgen auch Article-Type-, Content-, Plan-, Draft- und WordPress-Adapterpfade. Damit ist die neue Beitragsart gegenwärtig in allen drei Kernen mehrfach hart verdrahtet.

## 3. Reale Callgraph des Portalabgleichs (PSTE 0.49 live)

```text
Browser renderContextAutoSequence()
  └─ POST admin-ajax.php?action=pste_context_advance (20-s Abort)
     └─ PSTE_Admin::contextAdvanceAjax()
        ├─ output buffer starten
        ├─ PSTE_Auth::assertAdmin()
        └─ PSTE_Context_Refresh::processBatch()
           ├─ status() → get_option(job), ggf. topicPoolCount()
           ├─ Legacy: delete_transient(lock)
           ├─ get/set_transient(lock)
           ├─ get_option(baseline)
           ├─ Legacy: start()
           │  ├─ topicPoolCount()
           │  ├─ createSnapshotBundle()
           │  │  ├─ PSTE_Snapshot::inventory()             [global]
           │  │  ├─ PSTE_Snapshot::editorialPlan()         [global]
           │  │  ├─ PSTE_Article_Type_Registry::build()
           │  │  └─ canonicalize + JSON + hash + option write/read [global]
           │  ├─ Sandbox::bindingRefreshRecordIds()            [full option/registry]
           │  ├─ topicPayloadIntegrityInitialize()
           │  ├─ saveJob() write + readback
           │  └─ markAllContextPending()                       [global UPDATE]
           ├─ Payload phase: max. 10 rows + verify/save/schedule
           ├─ Other phases: loadSnapshotBundle()
           │  └─ full option decode + canonicalize + JSON/hash of inventory/plan/registry
           ├─ Context phase: max. 5 rows
           │  ├─ Context_Evaluator::buildIndex(inventory, plan) [global, every tick]
           │  └─ refreshPortalContextBatch()                    [bounded rows only]
           ├─ Sandbox phase: max. 3 records (full bound bundle still loaded)
           ├─ Final: Snapshot::baselineStatus()                     [global live rebuild]
           ├─ Exception: save BLOCKED; optional markAllContextBlocked() [global UPDATE]
           └─ finally delete_transient(lock)
        └─ clean buffer + wp_send_json_success/error()
```

PHP-Exceptions innerhalb des `try` werden zu JSON/400. Nicht abfangbare Engine-Fatals, Memory Exhaustion vor verfügbarem Handler, Webserver/PHP-FPM Timeout, Prozessabbruch und Ausgaben außerhalb/ nach der Boundary können dagegen HTML oder leere Antworten mit HTTP 500 liefern. Ein Fatal kann außerdem Lock und teilweise persistierten Job/Pool hinterlassen.

## 4. Weshalb die vorhandenen lokalen PASS-Berichte Live nicht ausschließen

Die Step-12-Berichte testen Quell-/Fresh-Unpack-Parität und simulierte Verträge. Sie liefern keinen Messlauf gegen die reale WordPress-Datenmenge, PHP-FPM-Memory-/Timeout-Limits, Optionsgröße, Object Cache, Datenbanklatenz und die tatsächliche 0.48/0.49 Job-/Lock-Kombination. Ein Mock kann Batch-Kardinalität bestätigen, ohne die innerhalb eines Batches ausgeführte globale Snapshot-/Indexarbeit realistisch zu materialisieren. Fresh-Unpack beweist Artefaktidentität, nicht Laufzeit-Boundedness. Der Live-Screenshot beweist den Transportfehler, aber weder Fatal-Klasse noch Serverursache.

## 5. Abgrenzung nach Regel 1

### Geschützt und byte-identisch zu halten

- PSTE: Journal Router/Article Type, Ontologie, Title Composer/Validator/Reviewer, Editorializer/Quality Gate, Normal Metadata Path, Intent-/Topic-Policy und alle Prompt-/Payload-Fachverträge.
- PSERC vollständig, bis PSTE technisch stabil und seine Handoff-Bytes nachgewiesen sind; insbesondere Compiler, Slot Allocator, Title/Language/Planning Gates, Production Reader/Trigger und Signing-Verträge.
- PPM vollständig; insbesondere Content Generator/Validator, Article Type/Plan/Exact-Five/Workflow Release, Draft Adapter, WP Adapter, Readback/Hash, HTML/Design und signierte Build-Manifeste.
- Die zwei Journal-Goldstandard-Fixtures/Artikel sowie alle bestehenden Artikel-/Plan-Fixtures.

### Zulässiger Reparaturscope

Nur PSTE Admin-AJAX-Boundary, Context-Refresh-Orchestrator, technischer Context-Index-Store, eng begrenzte Repository-Reader/Statusupdates, technische Options-/Lock-/Cron-Konstanten, Uninstall-Aufräumung und dazugehörige Infrastrukturtests. Keine Post-, Term-, Postmeta-, Prompt-, Titel-, Typ-, Slot-, HTML- oder Publish-Schreiblogik.

## 6. Ein zusammenhängender Reparaturblock

1. Einen versionierten V6/V7-Job als expliziten Zustandsautomaten mit CAS-artigem Lease (`job_uuid`, `generation`, `lease_token`, Ablaufzeit) definieren. Doppelklick/Cron dürfen denselben Tick nicht parallel ausführen.
2. Legacy-Zustand ausschließlich adoptieren; im Adoptionstick keine Snapshots, Sandbox-Vollreads oder Pool-Rebuilds. Unbekannte Verträge bleiben `BLOCKED`.
3. Inventory, Plan, Registry und Sandbox-ID-Ermittlung cursor-/keyset-basiert in harte Byte- **und** Elementbudgets zerlegen. Keine `OFFSET`-Scans und kein einzelner globaler Shard-Build.
4. Index inkrementell pro Family/Shard materialisieren; jeden Shard mit Job-, Baseline-, Quellhash, Cursor und HMAC/Hash binden. Manifest erst nach vollständigem Readback atomar aktivieren.
5. Jeder Context-Tick liest nur die für maximal fünf Zeilen benötigten Shards. Fehlender/manipulierter Shard blockiert ohne Kandidateninhalt zu rekonstruieren.
6. Finale Freshness ebenfalls cursor-basiert gegen deterministische Aggregate prüfen; `COMPLETE` erst nach separater Structure-, Inventory-, Plan-, Registry-, Sandbox- und Context-Readback-Verifikation.
7. Shutdown-Diagnostik registrieren, die ausschließlich technische Metadaten (`job_uuid`, Phase, Tick, Peak Memory, elapsed, letzte DB-Operation, PHP error type/message hash) in einen kleinen Ringpuffer schreibt. AJAX antwortet bei fangbaren Fehlern stets mit korrelationsfähigem JSON; keine Artikelbytes in Logs.
8. Erst nach kompletter Matrix Source bauen, Fresh-Unpack hashvergleichen und **denselben** Testlauf auf dem entpackten Artefakt wiederholen. Danach genau ein Kandidat; nie automatische Installation/Veröffentlichung.

### Zu ändernde Dateien (geplanter Scope, noch nicht umgesetzt)

- `portal-seo-topic-engine/includes/class-pste-context-refresh.php`
- `portal-seo-topic-engine/includes/class-pste-context-index-store.php` (neu bzw. grundlegend zu härten)
- `portal-seo-topic-engine/includes/class-pste-admin.php`
- `portal-seo-topic-engine/includes/class-pste-repository.php` (nur technische cursor-/keyset-Reader und Statuswrites)
- `portal-seo-topic-engine/includes/class-pste-plugin.php` und `portal-seo-topic-engine/portal-seo-topic-engine.php` (nur Options-/Hook-/Versionsregistrierung)
- `portal-seo-topic-engine/uninstall.php` (nur neue technische Stores)
- neue automatisierte WordPress-Integrations-/Fault-Injection-Tests und technischer Jobvertrag

## 7. Beitragsart-Erweiterungsarchitektur (Folgeschritt, nicht implementieren)

Eine zentrale, signierte `ARTICLE_TYPE_EXTENSION_MANIFEST_V1`-Schnittstelle soll Identität, erlaubte Titelmodi, Kategorie-Capability, Handoff-Schema und Validator-Capabilities deklarieren. PSTE, PSERC und PPM konsumieren dasselbe kanonisch serialisierte Manifest über versionsgebundene Adapter; sie enthalten keine Typnamen-Switches. Die Registrierung invalidiert nur den kleinen Registry-Hash, niemals Inventory/Context/Sandbox global. Vor Implementierung sind Golden-Master-Tests erforderlich, die für jeden bestehenden Typ die kanonischen PSTE-Handoff-, PSERC-Release- und PPM-Draft/Readback-Bytes vergleichen. Ohne Byte-/Semantikidentität bleibt dies ausdrücklich ein Folgeschritt.

## 8. Verbindliche Positiv-/Negativ-Testmatrix

| Bereich | Fall | Erwartung / Beweis |
|---|---|---|
| Migration + | kein Job; COMPLETE; 0.48 V4 mid-flight/BLOCKED; 0.49 BLOCKED mit Live-Code | deterministische Adoption ab Cursor 0; niemals stilles COMPLETE; keine schwere Arbeit im Adoptionstick |
| Migration − | Lock ohne Job; Job ohne Lock; unbekannter Vertrag; manipulierte Generation | fail-closed bzw. abgelaufenen technischen Lease sicher ersetzen; kein PASS |
| Concurrency − | Reload, Doppelklick, AJAX+Cron, gleicher Tick zweimal | genau ein Lease-Owner; idempotenter Readback; keine Cursor-Doppelung |
| Snapshot + | unveränderter Bestand, leere/große Datenmenge | jeder Tick unter Element-/Byte-/Query-/Zeitbudget; COMPLETE nach Readback |
| Snapshot − | stale Baseline, manipuliertes Bundle/Manifest/Shard, fehlender Shard | Hash/Binding-Fehler, BLOCKED, kein Context-PASS |
| Storage − | DB read/write failure in jeder Phase; Partial Write; Object-Cache stale | BLOCKED mit Korrelation; kein Cursorfortschritt ohne Readback |
| Transport − | Exception, Warning/HTML, Timeout, Memory-/Abbruchsimulation | JSON bei fangbar; Shutdown-Diagnose bei Fatal; Job bleibt resumierbar/fail-closed |
| Sandbox +/− | leer, unverändert, stale Source, defekter Record, Registry-Manipulation | bounded/no-op bzw. BLOCKED; kein globaler Rewrite ohne Bedarf |
| Workflow + | alle bisherigen Nicht-Journal-Typen; beide Journal-Goldstandards | PSTE-Handoff, PSERC-Release, PPM-HTML/Draft/Readback byte-/semantikidentisch |
| Workflow + | Supervisor → Start Gate → Bindings → Title → Exact Five → Research → Provenance → Gates → signed releases → draft → hash | vollständiger lokaler PASS auf Source **und gebautem Fresh-Unpack**; Live separat zu kennzeichnen |
| Workflow − | Kategorie, Typ, Titel, Planplatz oder Payload manipuliert; Signatur/Binding ungültig | jeweiliges Gate BLOCKED; kein Draft/Content-Write |
| Publish − | `post_status=publish`, Statuseskalation, direkter Adapteraufruf | hart abweisen; ausschließlich Draft |
| Performance | 0/1/5/10/100/realistische Maximalmenge, große Options und langsame DB | pro Tick gemessene Obergrenzen; kein N+1; Peak Memory/Queries/Bytes protokolliert |
| Regel 1 | Hashliste aller geschützten Dateien und Goldstandard-Payloads vor/nach Build | exakt identisch; jede Abweichung BLOCKED |

## 9. Offene Live-Belege und Status

Vor einem `PASS` werden zwingend benötigt: korrelierter PHP-Fatal-/FPM-/Webserver-Logeintrag zum 500, der unveränderte 205-Byte-Response-Body, PHP-/FPM-Limits, Query-/Peak-Memory-/Zeitmessung je Phase sowie ein read-only Export der technischen Context-Job-/Lock-/Bundle-Metadaten (ohne Artikelinhalt). Danach ist die vollständige Matrix in einer repräsentativen WordPress-Stagingkopie auszuführen.

Bis diese Nachweise und die Implementierung des zusammenhängenden Reparaturblocks vorliegen, ist der Status **BLOCKED**. Entsprechend wurde weder PSTE/PSERC/PPM-Produktionscode verändert noch ein Installer oder Installationskandidat erzeugt. Das ist die durch Regel 1 vorgeschriebene fail-closed Entscheidung.
