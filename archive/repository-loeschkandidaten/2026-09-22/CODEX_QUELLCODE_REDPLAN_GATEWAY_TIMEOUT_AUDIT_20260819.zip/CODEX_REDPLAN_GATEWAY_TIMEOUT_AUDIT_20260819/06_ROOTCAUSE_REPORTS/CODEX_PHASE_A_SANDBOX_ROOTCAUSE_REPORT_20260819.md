# Phase A – Journal/Sandbox root-cause and target architecture

Date: 2026-08-19
Scope: supplied PSTE 0.50.0, PSERC 0.25.2, PPM 6.7.9 and the pre-Journal/history references
Decision: **BLOCKED – no installer may be built yet**

## Executive result

The observed failure has an objective architectural precursor in PSTE 0.50.0. The
`SANDBOX_BINDING_BATCH` cursor is limited to three IDs, but every fresh AJAX request
loads and verifies the complete monolithic Sandbox option. It then walks all records
again for archive compaction. A dirty batch hashes and rewrites that complete option,
reads it back, and verifies every record again. Thus the cursor bounds only the number
of candidates whose decisions are recomputed; it does **not** bound bytes, records,
memory, hashing, verification, or persistence.

The supplied evidence does not contain the failing server's PHP/hosting fatal log or
an export of the real 549-record Sandbox option. Consequently the exact HTTP 500
mechanism (memory limit, execution timeout, database packet/option limit, or another
hard termination) cannot be distinguished. Calling any of these the proven immediate
cause would violate the fail-closed instruction. The full-store amplification is,
however, proved directly from source and is sufficient to reject 0.50.0's persistence
architecture.

No PSTE/PSERC/PPM runtime source and no installer is changed in Phase A. In particular,
no editorial or production path is changed.

## Exact 0.50.0 call chain and cost

1. `PSTE_Context_Refresh::processBatch()` enters `SANDBOX_BINDING_BATCH` and calls
   `PSTE_Semantic_Review_Sandbox::refreshBindingsAfterBaselineChangeBatch()` with
   `SANDBOX_BATCH_SIZE` (three).
2. The method slices the captured ID list, but then calls `stored()` before iterating
   that slice.
3. `stored()` calls WordPress `get_option(PSTE_OPTION_SEMANTIC_SANDBOX)`, receiving and
   unserializing the whole option, then `assertRegistry()`.
4. `assertRegistry()` hashes the full registry and iterates all records; adjudication
   chains are verified for every record and current dataflow records receive a further
   self-consistency verification.
5. The batch next calls `compactLegacyDataflowArchives($store)`, which independently
   loops over every record and every archive entry.
6. Only now does the method loop over the maximum-three-record slice.
7. If any record is dirty, `save()` calls `persistRegistry()`. It canonicalizes/hashes
   the entire registry, calls `update_option()` with the entire registry, reads the
   entire option back, compares the hash, and calls `assertRegistry()` again.

Let `N` be all Sandbox records, `H` all history/archive elements, `B <= 3` the slice,
and `S` the serialized store size. A no-op request performs `O(S + N + H + B)` work
and retains the full deserialized store. A dirty request additionally performs full
canonicalization/hash, serialization/database write, readback/deserialization, and
full verification: still `O(S + N + H + B)`, with large transient copies. Across
`ceil(549/3)=183` dirty AJAX requests, this is repeated full-store work, not `O(549)`.

Request-local caching does not alter that conclusion: each AJAX call starts a new PHP
request and its static cache is empty.

## Why normal article changes globally invalidate records

`stableBaselineIdentitySha256()` hashes `inventory_sha256` and `post_counts` together
with structure/editorial/category components. The inventory contains every relevant
WordPress post row, including state, title, categories, type, plan/canonical IDs,
headings, and a content fingerprint. A normal draft creation, publication, content
edit, or state transition therefore changes the inventory hash and/or counts.

Every record's `sameSemanticBinding` comparison requires equality with that one global
stable-baseline hash. One unrelated post change consequently makes every record appear
semantically stale. The additive Journal isolation in `PSTE_Article_Type_Registry`
does preserve its legacy `registry_sha256` and emits Journal's separate
`journal_registration_sha256`, but the global baseline hash bypasses that isolation.

## Dependency analysis: pre-Journal → Journal → 0.50.0

The history shows two distinct concerns that were incorrectly coupled:

| Concern | Actual inputs | Must not depend on |
|---|---|---|
| External/manual relevance evidence | canonical query, source-row identity, relevance policy/provider response/adjudication chain | inventory, post counts, Journal registration |
| Shared normal-path evidence/dataflow | canonical query/source payload, structure, protected category map, legacy registry/family identity components used by that candidate | unrelated posts and unrelated additive types |
| Internal proposal/planning | the normal-path result plus only planner-consumed inventory projection and applicable type/family components | external evidence/review history mutation |
| Audit history/archive | its own chained hashes and immutable prior values | current baseline identity |

Pre-Journal 0.43.0 is the semantic reference. Journal releases 0.44–0.47 add Journal
routing/type registration while attempting additive identity isolation. Step 12 / 0.48
adds request-local caching and batching, but its proof only covers repeated reads inside
one request. Versions through 0.50 retain the monolithic option and global baseline
binding, so neither issue is resolved. PSERC and PPM consume the resulting approved
handoff and are not on the failing persistence call chain; Phase B should therefore
change PSTE only unless later executable integration evidence disproves that boundary.

## Required target architecture

### Storage layout

Use dedicated PSTE tables rather than thousands of autoload-disabled options:

* `pste_sandbox_manifest`: singleton generation/state, schema version, immutable
  migration-source hash, cursor, record count, and a manifest hash over small metadata.
* `pste_sandbox_records`: one row per record ID, canonical JSON/blob, record hash,
  dependency fingerprints, generation, and optimistic revision.
* `pste_sandbox_index`: small indexed columns needed to select work (record ID,
  pool key hash, lane/status, component versions). No evidence is duplicated here.

Rows are addressed by the already stable record ID. A binding request selects at most
`B` index rows and at most `B` record rows, verifies each record locally, computes only
its dependencies, and transactionally updates at most `B` records plus one small job
cursor/receipt. There is no manifest Merkle-root rewrite whose computation requires
reading every record. The manifest binds schema/generation/index contract; each index
entry binds its record hash. Offline/explicit full audits may scan the store, but the
normal AJAX binding path may not.

Instrumentation is part of the contract and returned/tested per request:
`index_rows_read`, `record_rows_read`, `record_rows_written`, `record_rows_verified`,
`manifest_rows_read/written`, bytes read/written, provider calls, and forbidden write
classes. Each record counter must be `<= B`; metadata counters must be constant.

### Component fingerprints

Replace `stable_baseline_identity_sha256` as an invalidation key with named,
versioned hashes:

* `source_fp = H(canonical query, source row/payload identity)`;
* `relevance_fp = H(source_fp, relevance-policy contract)`;
* `normal_path_fp = H(source_fp, relevant structure projection, protected category
  projection, applicable legacy registry/family projection, normal-path contract)`;
* `planner_fp = H(normal_path output identity, planner contract, candidate-specific
  inventory projection)` only for records that actually run the internal planner;
* `journal_registration_fp` is stored separately and is consulted only for a record
  whose resolved/applicable type set includes Journal.

The inventory projection must be produced by an instrumented planner dependency
collector. It contains only fields actually read for the candidate. If that read set
cannot be proved complete, planner recomputation remains BLOCKED; relevance and its
history still remain untouched.

Invalidation is a DAG: a changed source row invalidates that record's downstream
normal path/planner; a relevant structure/family component invalidates only records
whose stored dependency set names it; an unrelated draft/publish changes no record;
an applicable inventory projection change invalidates only the internal proposal.

### Integrity and concurrency

* Record hashes cover the complete canonical record, including unchanged external
  evidence and review-history chains.
* Compare-and-swap revisions prevent lost updates; every record batch and cursor
  advancement occur in one database transaction.
* Missing rows, hash mismatch, manifest mismatch, duplicate IDs, unexpected generation,
  or dependency-contract mismatch fail closed. They are never silently recreated.
* Locks are generation/job scoped, have fenced monotonically increasing tokens, and
  cannot permit an expired worker to commit.
* Provider, post, term, postmeta, prompt, production, and publish APIs are prohibited
  by a write/call firewall during migration and recovery.

## Request-bounded migration

1. Create schema without switching readers; record the immutable legacy option hash,
   count, and migration generation in a small migration manifest.
2. Because a WordPress option cannot be partially fetched, reading the legacy option
   is inherently `O(N)`. Perform it **once** in a deliberately separate preflight whose
   measured peak memory fits the declared budget. If it does not fit, migration is
   BLOCKED and requires a server-side streaming/export mechanism; never repeatedly
   read it in normal AJAX batches.
3. Validate the complete legacy registry before any target write. Freeze its hash;
   any source-option change thereafter blocks migration.
4. Stage records in bounded transactions (`B` rows). Each insert is `INSERT ... ON
   DUPLICATE KEY` with identical-hash acceptance only. Persist a receipt and cursor in
   the same transaction. A crash before commit changes nothing; a crash after commit
   replays to the identical receipt.
5. Verify staged records locally as written. At completion compare count/ID-set using
   an incrementally accumulated commutative/set digest plus independently sorted final
   audit. Preserve every byte-semantic field, external/manual evidence, review archive,
   and history; only the storage envelope may differ.
6. Atomically mark the generation readable. Keep the legacy option read-only for
   rollback; do not delete it in this release.
7. Readers fail closed if neither a complete new generation nor the unchanged verified
   legacy store exists. Writers never dual-write editorial decisions.

The migration's one legacy preflight is a separately disclosed unavoidable conversion
cost. Every subsequent migration request and every steady-state binding request is
bounded by `B`; claiming the legacy decoding itself is bounded would be false.

## Rule 1 determination

**BLOCKED.** The source-level root cause and a safe target design are established, but
the mandatory 549 real-record/history-rich load tests, actual memory/request budget,
real migration crash/restart tests, full fresh-unpack workflow, and live fatal evidence
are not present in the supplied package. The supplied Step-12 results cannot substitute:
they prove a request-local cache, not cross-request locality. Under Rule 1, Phase B and
an installer are forbidden until every item in `TEST_MATRIX.md` is executable and PASS.

