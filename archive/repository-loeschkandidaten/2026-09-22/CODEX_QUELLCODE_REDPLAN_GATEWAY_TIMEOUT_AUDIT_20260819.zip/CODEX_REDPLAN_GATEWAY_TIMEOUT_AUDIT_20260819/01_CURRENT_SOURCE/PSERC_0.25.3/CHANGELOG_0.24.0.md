# PSERC 0.24.0 — Journal routing / canonical plan binding

- Journal-only assignment consistency gate consumes the proven PSTE Journal routing result.
- Existing eight Journal categories are bridged read-only to the already signed PPM 6.7.9 Journal/Wissen canonical slots.
- `Pferdewissen & Grundlagen` is registered as runtime category but deliberately has no invented signed PPM slot.
- Journal candidates in existing signed Journal categories can reserve a canonical slot for planning comparison, but remain `HELD_NO_ACTIVE_NORMAL_DRAFT_RELEASE`.
- Journal candidates in the new category remain `HELD_JOURNAL_CATEGORY_NOT_IN_SIGNED_CANONICAL_PLAN`.
- Sandbox remains review/reentry only and is never a second editorial plan or direct production path.
- No changes to Textmaschine, PPM 6.7.9, workflow, content/HTML/design or rules of any existing article type.
- Journal-spezifische freie Frage-/Aussagetitel erlauben Doppelpunkte gemäß Journal-Vertrag; andere Beitragstypen bleiben unverändert.
