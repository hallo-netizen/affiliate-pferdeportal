# 0.25.1 – Journal registration status binding fix

- Korrigiert ausschließlich die interne PSERC-Journal-Gate-Bindung auf den bereits von PSERC 0.25.x erzeugten signierten Status `PSERC_JOURNAL_SIGNED_NORMAL_DRAFT_REGISTRATION_PASS`.
- Kein Routing-, Sandbox-, Produktions-, Textmaschinen-, Artikeltyp- oder Publish-Workflow wird verändert.
- Alter/nicht signierter PPM-Zustand bleibt über `PSERC_Production_Reader` fail-closed blockiert.
- Versionssprung dient der eindeutigen Live-Build-Erkennung.
