<?php
if (!defined('ABSPATH')) { return; }

/** Hard exact-five-field boundary to the protected text-production workflow. */
final class PSERC_Metadata_Boundary {
    private const BATCH_KEYS = ['contract','status','item_count','maximum_articles','maximum_articles_per_type','publish_allowed','content_or_format_payload_present','items','batch_sha256'];
    private const ITEM_KEYS = ['title','target_keyword','category','article_type','plan_slot'];
    private const FORBIDDEN_EXACT_KEYS = [
        'body_html','body_text','content_html','post_content','canonical_article','article_content','fact_pack',
        'claim','claims','source_trace','quality_binding','language_evidence','heading','headings','table','tables','list','lists',
        'paragraph','paragraphs','section','sections','intro','introduction','conclusion','link_registry','visible_link','html_class',
        'css','style','styles','shortcode','formatting','design_payload','quality_payload','prompt','system_prompt','user_prompt',
        'content_prompt','outline','tone_instruction','voice_instruction'
    ];
    private const FORBIDDEN_STRICT_PREFIXES = [
        'body_html','body_text','content_html','post_content','canonical_article','article_content','fact_pack','source_trace',
        'link_registry','visible_link','html_class','design_payload','quality_payload','system_prompt','user_prompt','content_prompt'
    ];
    private const FORBIDDEN_GENERIC_PAYLOAD_ROOTS = ['claim','claims','heading','headings','table','tables','list','lists','paragraph','paragraphs','section','sections','intro','introduction','conclusion','css','style','styles','shortcode','formatting','prompt','outline'];

    /** @return array{ok:bool,status:string,message:string} */
    public static function validateBatch(array $batch): array {
        if (($batch['contract'] ?? '') !== 'PSERC_TEXTMACHINE_METADATA_BATCH_V2') {
            return self::blocked('PSERC_METADATA_BATCH_CONTRACT_INVALID','Der Metadatenblock besitzt nicht den verbindlichen V2-Vertrag.');
        }
        $batchKeys=array_keys($batch);sort($batchKeys);$allowedBatch=self::BATCH_KEYS;sort($allowedBatch);
        if($batchKeys!==$allowedBatch)return self::blocked('PSERC_METADATA_BATCH_KEYS_INVALID','Der Metadatenblock enthält nicht exakt die erlaubten Steuer- und Metadatenfelder.');
        if(($batch['publish_allowed']??null)!==false)return self::blocked('PSERC_METADATA_BATCH_PUBLISH_FORBIDDEN','Der Metadatenblock darf keine Veröffentlichung freigeben.');
        if(($batch['content_or_format_payload_present']??null)!==false)return self::blocked('PSERC_METADATA_BATCH_CONTENT_PAYLOAD_FORBIDDEN','Der Metadatenblock darf keine Inhalts- oder Formatdaten enthalten.');
        if(!is_int($batch['maximum_articles']??null)||!is_int($batch['maximum_articles_per_type']??null)||(int)$batch['maximum_articles']!==0||(int)$batch['maximum_articles_per_type']!==0)return self::blocked('PSERC_METADATA_BATCH_LIMITS_INVALID','Die Metadatenblockgrenzen müssen als 0 = unbegrenzt deklariert sein.');
        $items=$batch['items']??null;
        if(!is_array($items))return self::blocked('PSERC_METADATA_BATCH_ITEMS_INVALID','Die Metadatenpositionen fehlen.');
        if((int)($batch['item_count']??-1)!==count($items))return self::blocked('PSERC_METADATA_BATCH_COUNT_MISMATCH','Die Zahl der Metadatenpositionen stimmt nicht.');
        $seenTitles=[];$seenSlots=[];
        foreach($items as $index=>$item){
            if(!is_array($item))return self::blocked('PSERC_METADATA_ITEM_INVALID','Eine Metadatenposition ist kein Objekt: '.(string)$index);
            $keys=array_keys($item);sort($keys);$allowed=self::ITEM_KEYS;sort($allowed);
            if($keys!==$allowed)return self::blocked('PSERC_METADATA_ITEM_KEYS_INVALID','Eine Metadatenposition enthält nicht exakt die fünf erlaubten Felder: '.(string)$index);
            foreach(self::ITEM_KEYS as $field){
                if(!is_scalar($item[$field]??null))return self::blocked('PSERC_METADATA_ITEM_SCALAR_REQUIRED','Das Feld '.$field.' ist nicht skalar: '.(string)$index);
            }
            foreach(['title','target_keyword','category','article_type'] as $field){
                $value=(string)$item[$field];
                $stripped=function_exists('wp_strip_all_tags')?wp_strip_all_tags($value):strip_tags($value);
                if($value!==$stripped||preg_match('/[<>]/u',$value))return self::blocked('PSERC_METADATA_MARKUP_FORBIDDEN','Markup ist in '.$field.' verboten: '.(string)$index);
            }
            $title=trim((string)$item['title']);$keyword=trim((string)$item['target_keyword']);$category=trim((string)$item['category']);$type=trim((string)$item['article_type']);$slot=trim((string)$item['plan_slot']);
            if($title===''||$keyword===''||$category===''||$type==='')return self::blocked('PSERC_METADATA_REQUIRED_FIELD_EMPTY','Ein erlaubtes Metadatenfeld ist leer: '.(string)$index);
            if(!preg_match('/^[a-f0-9]{64}$/',$slot))return self::blocked('PSERC_METADATA_PLAN_SLOT_INVALID','Der Planplatz ist kein gebundener SHA-256-Wert: '.(string)$index);
            if(self::isQuestionTitle($title)&&!in_array($type,['FAQ','Journal'],true))return self::blocked('PSERC_QUESTION_TITLE_NOT_FAQ','Ein Fragetitel ist nicht FAQ zugeordnet: '.(string)$index);
            $normalized=self::normalize($title);
            if(isset($seenTitles[$normalized]))return self::blocked('PSERC_DUPLICATE_METADATA_TITLE','Doppelter Titel im Metadatenstapel: '.(string)$index);
            if(isset($seenSlots[$slot]))return self::blocked('PSERC_DUPLICATE_PLAN_SLOT','Doppelter Planplatz im Metadatenstapel: '.(string)$index);
            $seenTitles[$normalized]=true;$seenSlots[$slot]=true;
            $scan=self::forbiddenContentPath($item);
            if($scan!=='')return self::blocked('PSERC_FORBIDDEN_CONTENT_FIELD','Verbotenes Inhalts- oder Formatfeld gefunden: '.$scan);
        }
        $declared=(string)($batch['batch_sha256']??'');$copy=$batch;unset($copy['batch_sha256']);
        if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(PSERC_Stable_Json::hash($copy),$declared))return self::blocked('PSERC_METADATA_BATCH_HASH_MISMATCH','Der Metadatenblock-Hash stimmt nicht.');
        return ['ok'=>true,'status'=>'PSERC_METADATA_BOUNDARY_PASS','message'=>'Der Handoff enthält je Position exakt fünf skalare Planungsfelder.'];
    }

    public static function isQuestionTitle(string $title): bool {
        $raw=trim($title);if($raw==='')return false;if(str_ends_with($raw,'?'))return true;
        return (bool)preg_match('/^(wie|was|wann|warum|wieso|weshalb|welche|welcher|welches|welchen|wem|wen|wessen|worauf|wieviel|wie viel|kann|können|koennen|darf|dürfen|duerfen|soll|sollen|muss|müssen|muessen|sind|ist|gibt|braucht|benötigt|benoetigt|frieren|friert|tragen|trägt|traegt|halten|hält|haelt|passen|passt|helfen|hilft)\b/iu',$raw);
    }
    /** Central Rule-1 detector for hidden content/design/prompt payload keys. Diagnostic words such as
     * `semantic_quality_claimed` are allowed; only complete dangerous key segments are blocked. @param mixed $value */
    public static function forbiddenContentPath($value,string $path=''): string {
        if(!is_array($value))return '';
        foreach($value as $key=>$child){
            $name=strtolower((string)$key);$here=$path===''?(string)$key:$path.'.'.(string)$key;
            if(self::isForbiddenKeyName($name))return $here;
            $nested=self::forbiddenContentPath($child,$here);if($nested!=='')return $nested;
        }
        return '';
    }
    private static function isForbiddenKeyName(string $name): bool {
        if(in_array($name,self::FORBIDDEN_EXACT_KEYS,true))return true;
        foreach(self::FORBIDDEN_STRICT_PREFIXES as $root){
            if(str_starts_with($name,$root.'_')||str_ends_with($name,'_'.$root)||str_contains($name,'_'.$root.'_'))return true;
        }
        foreach(self::FORBIDDEN_GENERIC_PAYLOAD_ROOTS as $root){
            foreach(['payload','content','text','html','data','items','values','instructions','instruction'] as $suffix){
                foreach([$root.'_'.$suffix,$suffix.'_'.$root] as $pattern){
                    if($name===$pattern||str_starts_with($name,$pattern.'_')||str_ends_with($name,'_'.$pattern)||str_contains($name,'_'.$pattern.'_'))return true;
                }
            }
        }
        return false;
    }
    private static function normalize(string $value): string{$value=trim((string)preg_replace('/\s+/u',' ',$value));return function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);}
    /** @return array{ok:false,status:string,message:string} */
    private static function blocked(string $status,string $message): array{return ['ok'=>false,'status'=>$status,'message'=>$message];}
}
