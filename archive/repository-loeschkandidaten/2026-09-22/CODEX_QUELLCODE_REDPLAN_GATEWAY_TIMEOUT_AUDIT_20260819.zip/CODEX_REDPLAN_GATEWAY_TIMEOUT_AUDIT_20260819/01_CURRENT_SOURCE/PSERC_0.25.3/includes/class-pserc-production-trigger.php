<?php
if (!defined('ABSPATH')) { return; }

/**
 * Controlled admin start path for an already approved research/text package.
 *
 * Responsibilities are deliberately narrow:
 * - re-read the current exact-five compiler batch at click time;
 * - accept the already approved canonical Fact-Pack bundle + PPM production plan;
 * - verify plan identity through PSERC_PPM_Intake_Bridge before any PPM run;
 * - import Fact-Packs through the unchanged PPM 6.7.9 public import path;
 * - execute the unchanged PPM 6.7.9 normal-draft pipeline through the bridge.
 *
 * It never researches, generates, rewrites, repairs or interprets article content,
 * HTML, formatting, prompts or design.
 */
final class PSERC_Production_Trigger {
    public const ACTION='pserc_run_approved_normal_draft';
    public const NONCE_ACTION='pserc_run_approved_normal_draft_nonce';
    public const CONTRACT='PSERC_APPROVED_PRODUCTION_TRIGGER_V3_SIGNED_SUBSET_SUPERVISED';
    private const MAX_FACT_PACK_BYTES=8388608; // mirrors PPM admin upload limit
    private const MAX_PLAN_BYTES=2097152;      // mirrors PPM normal plan upload limit
    private const MAX_WORKFLOW_RELEASE_BYTES=1048576; // supervisor attestation only; never article content

    public static function init(): void {
        if (function_exists('add_action')) {
            add_action('admin_post_'.self::ACTION,[self::class,'handle']);
        }
    }

    /** @param array<string,mixed> $batch @param array<string,mixed> $release */
    public static function renderPanel(array $batch,array $release=[]): void {
        $count=(int)($batch['item_count']??0);
        echo '<hr><h2>Kontrollierter Produktionsstart</h2>';
        echo '<p><strong>Dieser Knopf erzeugt echte WordPress-Entwürfe.</strong> Er darf nur mit dem bereits geprüften Fact-Pack-Bundle und Produktionsplan für exakt den oben angezeigten Metadatenblock verwendet werden.</p>';
        echo '<p>Der Produktionsstart verändert weder Titel, Keyword, Artikelart, Kategorie noch Planplatz. Der gebundene STARTMASTER-0039-Recherche-/Textprozess liefert den fertigen Inhalt; PPM 6.7.9 bleibt unverändert und übernimmt Vertragsprüfung, Draft und Readback. Veröffentlichung bleibt gesperrt.</p>';
        echo '<p><strong>Vor jedem Import läuft der Workflow Supervisor.</strong> Ohne START-Gate-, FINAL-TITLE-, Exact-Five-, Provenienz-, Fact-Pack-/Plan- und PPM-Identitätsnachweis wird fail-closed gestoppt.</p>';
        if($count<1){
            echo '<div class="notice notice-warning inline"><p><strong>BLOCKED:</strong> Kein aktueller Exact-Five-Block vorhanden. Produktionsstart ist nicht möglich.</p></div>';
            return;
        }
        $ppmReady=defined('PPM679_VERSION')&&(string)PPM679_VERSION==='6.7.9'&&class_exists('PPM679_Admin')&&class_exists('PPM679_Normal_Draft_Pipeline');
        if(!$ppmReady){
            echo '<div class="notice notice-error inline"><p><strong>BLOCKED:</strong> Die unveränderte Production Machine 6.7.9 ist in dieser WordPress-Anfrage nicht vollständig geladen.</p></div>';
            return;
        }
        $action=function_exists('admin_url')?admin_url('admin-post.php'):'admin-post.php';
        echo '<form method="post" enctype="multipart/form-data" action="'.esc_url($action).'">';
        echo '<input type="hidden" name="action" value="'.esc_attr(self::ACTION).'">';
        if(function_exists('wp_nonce_field'))wp_nonce_field(self::NONCE_ACTION);
        echo '<p><label for="pserc_fact_packs"><strong>Kanonisches Fact-Pack-Bundle</strong></label><br>';
        echo '<input type="file" id="pserc_fact_packs" name="pserc_fact_packs" accept="application/json,.json" required></p>';
        echo '<p><label for="pserc_production_plan"><strong>Produktionsplan V4/V5 – original 0039-kompatibel, ohne plan_slot-Fremdfeld</strong></label><br>';
        echo '<input type="file" id="pserc_production_plan" name="pserc_production_plan" accept="application/json,.json" required></p>';
        echo '<p><label for="pserc_workflow_release"><strong>Kryptografisch signierte Workflow-Supervisor-Freigabe</strong></label><br>';
        echo '<input type="file" id="pserc_workflow_release" name="pserc_workflow_release" accept="application/json,.json" required></p>';
        echo '<p><code>'.esc_html((string)$count).'</code> aktuell freigegebene Position(en). <strong>Die signierte Workflow-Supervisor-Freigabe bestimmt fail-closed, welche dieser READY-Positionen in diesem Lauf verwendet werden. Es gibt keine konfigurierte Artikelobergrenze.</strong> Veröffentlichung: <strong>nein</strong></p>';
        if(function_exists('submit_button'))submit_button('Geprüften Draft-Lauf starten','primary','submit',false);
        else echo '<button type="submit">Geprüften Draft-Lauf starten</button>';
        echo '</form>';
    }

    public static function handle(): void {
        if(!function_exists('current_user_can')||!current_user_can('manage_options')){
            self::emit(self::blocked('PSERC_PRODUCTION_TRIGGER_CAPABILITY_BLOCKED'));
        }
        if(function_exists('check_admin_referer')){
            check_admin_referer(self::NONCE_ACTION);
        } else {
            self::emit(self::blocked('PSERC_PRODUCTION_TRIGGER_NONCE_API_MISSING'));
        }

        if(!defined('PPM679_VERSION')||(string)PPM679_VERSION!=='6.7.9'||!class_exists('PPM679_Admin')||!class_exists('PPM679_Normal_Draft_Pipeline')||!class_exists('PPM679_Diagnostic')||!class_exists('PPM679_WP')){
            self::emit(self::blocked('PSERC_PRODUCTION_TRIGGER_PPM_679_RUNTIME_REQUIRED'));
        }

        try{$compiled=PSERC_Compiler::compile();}
        catch(Throwable $e){self::emit(self::blocked('PSERC_PRODUCTION_TRIGGER_COMPILER_EXCEPTION',['exception_class'=>get_class($e),'message_detail'=>$e->getMessage()]));}
        if(empty($compiled['ok']))self::emit(self::blocked('PSERC_PRODUCTION_TRIGGER_CURRENT_METADATA_NOT_READY',['compiler_status'=>$compiled['status']??null,'compiler_message'=>$compiled['message']??null]));
        $manifest=(array)($compiled['manifest']??[]);
        $fullBatch=(array)($manifest['next_textmachine_metadata_batch']??[]);
        $boundary=PSERC_Metadata_Boundary::validateBatch($fullBatch);
        if(empty($boundary['ok'])||(int)($fullBatch['item_count']??0)<1)self::emit(self::blocked('PSERC_PRODUCTION_TRIGGER_EXACT_FIVE_NOT_READY',['boundary'=>$boundary]));

        $bundle=self::decodeUpload('pserc_fact_packs',self::MAX_FACT_PACK_BYTES,'PSERC_PRODUCTION_TRIGGER_FACT_PACK_UPLOAD_INVALID');
        $plan=self::decodeUpload('pserc_production_plan',self::MAX_PLAN_BYTES,'PSERC_PRODUCTION_TRIGGER_PLAN_UPLOAD_INVALID');
        $workflowRelease=self::decodeUpload('pserc_workflow_release',self::MAX_WORKFLOW_RELEASE_BYTES,'PSERC_PRODUCTION_TRIGGER_WORKFLOW_RELEASE_UPLOAD_INVALID');

        // The signed release is the only selector. It may authorize any non-empty READY subset of the current full compiler batch.
        // No unsigned checkbox, request field or plan payload can choose candidates.
        $selected=self::selectBatchFromSignedRelease($fullBatch,$workflowRelease);
        if(empty($selected['ok']))self::emit($selected);
        $batch=(array)$selected['batch'];

        $planHash=PPM679_Diagnostic::stable_hash($plan);
        $serverInstanceId=(string)PPM679_WP::server_instance_id();
        $userId=(int)PPM679_WP::current_user_id();
        $nonce=isset($_POST['_wpnonce'])?(string)$_POST['_wpnonce']:'';
        $buildManifestFile=defined('PPM679_PLUGIN_DIR')?PPM679_PLUGIN_DIR.'certification/build-manifest-v1.json':'';
        $buildManifestSha256=$buildManifestFile!==''&&is_file($buildManifestFile)?hash_file('sha256',$buildManifestFile):'';
        if($serverInstanceId===''||$userId<1||$buildManifestSha256==='')self::emit(self::blocked('PSERC_PRODUCTION_TRIGGER_RUNTIME_BINDING_INCOMPLETE',['server_instance_id_present'=>$serverInstanceId!=='','user_id'=>$userId,'build_manifest_sha256_present'=>$buildManifestSha256!=='']));
        $requestId='pserc-normal-request-'.substr(hash('sha256',$serverInstanceId.'|'.$userId.'|'.$nonce.'|'.$planHash.'|'.$buildManifestSha256),0,40);
        $runtime=[
            'user_triggered'=>true,
            'nonce_verified'=>true,
            'user_id'=>$userId,
            'server_instance_id'=>$serverInstanceId,
            'request_id'=>$requestId,
            'build_manifest_sha256'=>$buildManifestSha256,
            'evidence_class'=>'SERVER_USER_TRIGGERED_NORMAL_DRAFT_PRODUCTION_VIA_PSERC_BRIDGE',
            'publish_allowed'=>false,
        ];

        $run=self::executeApproved($batch,$bundle,$plan,$runtime,null,$workflowRelease,$manifest);
        self::emit($run);
    }


    /**
     * Testable core of the start path. It accepts already parsed inputs and returns
     * a result instead of emitting/terminating. In production the admin handler is
     * the only caller that obtains these values from user uploads.
     *
     * @return array<string,mixed>
     */
    public static function executeApproved(array $batch,array $bundle,array $plan,array $runtime,?array $productionSnapshot=null,?array $workflowRelease=null,?array $compilerManifest=null): array {
        $boundary=PSERC_Metadata_Boundary::validateBatch($batch);
        if(empty($boundary['ok'])||(int)($batch['item_count']??0)<1)return self::blocked('PSERC_PRODUCTION_TRIGGER_EXACT_FIVE_NOT_READY',['boundary'=>$boundary]);
        if(!defined('PPM679_VERSION')||(string)PPM679_VERSION!=='6.7.9'||!class_exists('PPM679_Admin')||!class_exists('PPM679_Normal_Draft_Pipeline'))return self::blocked('PSERC_PRODUCTION_TRIGGER_PPM_679_RUNTIME_REQUIRED');

        if(!is_array($workflowRelease)||!is_array($compilerManifest))return self::blocked('PSERC_PRODUCTION_TRIGGER_SUPERVISOR_RELEASE_REQUIRED');

        // Absolute ordering law: the complete supervisor must PASS before any PPM Fact-Pack storage or write path is touched.
        $supervisor=PSERC_Workflow_Supervisor::validate($batch,$bundle,$plan,$workflowRelease,$compilerManifest,$productionSnapshot);
        if(empty($supervisor['ok']))return self::blocked('PSERC_PRODUCTION_TRIGGER_WORKFLOW_SUPERVISOR_BLOCKED',['workflow_supervisor'=>$supervisor]);

        // Defense in depth after the supervisor: recheck the content-free package set before import.
        $bundleCheck=self::validateBundlePlanRelationship($bundle,$plan);
        if(empty($bundleCheck['ok']))return $bundleCheck;

        // Use the unchanged PPM's own canonical import gate. No duplicate content validation here.
        $import=PPM679_Admin::import_fact_pack_bundle($bundle);
        if(empty($import['ok']))return self::blocked('PSERC_PRODUCTION_TRIGGER_PPM_FACT_PACK_IMPORT_BLOCKED',['ppm_import'=>$import]);

        $result=PSERC_PPM_Intake_Bridge::execute($batch,$plan,$runtime,$productionSnapshot);
        if(empty($result['ok']))return self::blocked('PSERC_PRODUCTION_TRIGGER_EXECUTION_BLOCKED',['bridge_execution'=>$result,'fact_pack_imported'=>true]);

        return [
            'ok'=>true,
            'contract'=>self::CONTRACT,
            'status'=>'PSERC_APPROVED_PRODUCTION_TRIGGER_EXECUTED',
            'exact_five_batch_sha256'=>(string)($batch['batch_sha256']??''),
            'exact_five_item_count'=>(int)($batch['item_count']??0),
            'workflow_supervisor_status'=>(string)($supervisor['status']??''),
            'workflow_supervisor_report_sha256'=>(string)($supervisor['report_sha256']??''),
            'workflow_release_sha256'=>(string)($workflowRelease['release_sha256']??''),
            'bridge_status'=>(string)($result['status']??''),
            'ppm_status'=>(string)($result['ppm_result']['artifact']['status']??''),
            'ppm_result'=>$result['ppm_result']??[],
            'content_design_surface_identical'=>(bool)($result['content_design_surface_identical']??false),
            'working_title_fallback_required'=>(bool)($result['working_title_fallback_required']??true),
            'publish_allowed'=>false,
        ];
    }


    /**
     * Derive a strict subset of the current READY Exact-Five batch exclusively from the plan_slot values
     * present in the signed supervisor release. The signature itself is verified later by the supervisor;
     * this method only performs fail-closed preselection and never trusts any content fields from the release.
     * @return array<string,mixed>
     */
    public static function selectBatchFromSignedRelease(array $fullBatch,array $workflowRelease): array {
        $boundary=PSERC_Metadata_Boundary::validateBatch($fullBatch);
        if(empty($boundary['ok']))return self::blocked('PSERC_PRODUCTION_TRIGGER_FULL_BATCH_INVALID',['boundary'=>$boundary]);
        if((string)($workflowRelease['contract']??'')!=='WORKFLOW_SUPERVISOR_RELEASE_V2_SIGNED')return self::blocked('PSERC_PRODUCTION_TRIGGER_RELEASE_SELECTOR_CONTRACT_INVALID');
        $releaseItems=array_values(array_filter((array)($workflowRelease['items']??[]),'is_array'));
        $count=count($releaseItems);
        if($count<1)return self::blocked('PSERC_PRODUCTION_TRIGGER_RELEASE_SELECTOR_COUNT_INVALID',['selected_count'=>$count]);
        $fullBySlot=[];
        foreach((array)($fullBatch['items']??[]) as $i=>$meta){
            if(!is_array($meta))return self::blocked('PSERC_PRODUCTION_TRIGGER_FULL_BATCH_ITEM_INVALID',['index'=>$i]);
            $slot=trim((string)($meta['plan_slot']??''));
            if($slot===''||isset($fullBySlot[$slot]))return self::blocked('PSERC_PRODUCTION_TRIGGER_FULL_BATCH_SLOT_INVALID_OR_DUPLICATE',['index'=>$i]);
            $fullBySlot[$slot]=$meta;
        }
        $selected=[];$seen=[];
        foreach($releaseItems as $i=>$ri){
            $slot=trim((string)($ri['plan_slot']??''));
            if(!preg_match('/^[a-f0-9]{64}$/',$slot)||isset($seen[$slot]))return self::blocked('PSERC_PRODUCTION_TRIGGER_RELEASE_SELECTOR_SLOT_INVALID_OR_DUPLICATE',['index'=>$i]);
            if(!isset($fullBySlot[$slot]))return self::blocked('PSERC_PRODUCTION_TRIGGER_RELEASE_SELECTOR_SLOT_NOT_CURRENT_READY',['index'=>$i,'plan_slot'=>$slot]);
            $seen[$slot]=true;$selected[]=$fullBySlot[$slot];
        }
        $batch=$fullBatch;$batch['items']=$selected;$batch['item_count']=count($selected);unset($batch['batch_sha256']);$batch['batch_sha256']=PSERC_Stable_Json::hash($batch);
        $subBoundary=PSERC_Metadata_Boundary::validateBatch($batch);
        if(empty($subBoundary['ok']))return self::blocked('PSERC_PRODUCTION_TRIGGER_RELEASE_SELECTOR_BATCH_INVALID',['boundary'=>$subBoundary]);
        return ['ok'=>true,'status'=>'PSERC_PRODUCTION_TRIGGER_SIGNED_READY_SUBSET_SELECTED','batch'=>$batch,'selected_count'=>count($selected),'full_count'=>(int)$fullBatch['item_count'],'publish_allowed'=>false];
    }

    /** @return array<string,mixed> */
    private static function decodeUpload(string $field,int $maxBytes,string $code): array {
        $file=isset($_FILES[$field])&&is_array($_FILES[$field])?$_FILES[$field]:[];
        $tmp=(string)($file['tmp_name']??'');$size=(int)($file['size']??0);
        if($tmp===''||!is_file($tmp)||$size<1||$size>$maxBytes)self::emit(self::blocked($code,['field'=>$field,'tmp_exists'=>$tmp!==''&&is_file($tmp),'size'=>$size,'max_bytes'=>$maxBytes]));
        try{$decoded=json_decode((string)file_get_contents($tmp),true,512,JSON_THROW_ON_ERROR);}
        catch(Throwable $e){self::emit(self::blocked($code,['field'=>$field,'json_error'=>$e->getMessage()]));}
        if(!is_array($decoded))self::emit(self::blocked($code,['field'=>$field,'decoded_type'=>gettype($decoded)]));
        return $decoded;
    }

    /** @return array<string,mixed> */
    private static function validateBundlePlanRelationship(array $bundle,array $plan): array {
        if((string)($bundle['contract']??'')!=='canonical_fact_pack_import_v1')return self::blocked('PSERC_PRODUCTION_TRIGGER_FACT_PACK_CONTRACT_INVALID');
        $packs=array_values(array_filter((array)($bundle['fact_packs']??[]),'is_array'));
        $items=array_values(array_filter((array)($plan['items']??[]),'is_array'));
        if(!$packs||!$items)return self::blocked('PSERC_PRODUCTION_TRIGGER_FACT_PACK_OR_PLAN_EMPTY');
        $packIds=[];foreach($packs as $p){$id=trim((string)($p['fact_pack_id']??''));if($id==='')return self::blocked('PSERC_PRODUCTION_TRIGGER_FACT_PACK_ID_MISSING');if(isset($packIds[$id]))return self::blocked('PSERC_PRODUCTION_TRIGGER_DUPLICATE_FACT_PACK_ID',['fact_pack_id'=>$id]);$packIds[$id]=true;}
        $required=[];foreach($items as $i=>$item){if(array_key_exists('plan_slot',$item))return self::blocked('PSERC_PRODUCTION_TRIGGER_FOREIGN_PLAN_SLOT_FIELD_FORBIDDEN_IN_0039_PPM_PLAN',['index'=>$i]);$id=trim((string)($item['source_snapshot_id']??''));if($id==='')return self::blocked('PSERC_PRODUCTION_TRIGGER_PLAN_SOURCE_SNAPSHOT_ID_MISSING',['index'=>$i]);$required[$id]=true;}
        $extra=array_values(array_diff(array_keys($packIds),array_keys($required)));
        $missing=array_values(array_diff(array_keys($required),array_keys($packIds)));
        if($extra||$missing)return self::blocked('PSERC_PRODUCTION_TRIGGER_FACT_PACK_PLAN_SET_MISMATCH',['extra_fact_pack_ids'=>$extra,'missing_fact_pack_ids'=>$missing]);
        return ['ok'=>true,'status'=>'PSERC_PRODUCTION_TRIGGER_FACT_PACK_PLAN_SET_PASS','fact_pack_count'=>count($packs),'plan_item_count'=>count($items)];
    }

    /** @return array<string,mixed> */
    private static function blocked(string $reason,array $extra=[]): array {
        return array_merge(['ok'=>false,'contract'=>self::CONTRACT,'status'=>'PSERC_APPROVED_PRODUCTION_TRIGGER_BLOCKED','reason_codes'=>[$reason],'publish_allowed'=>false],$extra);
    }

    /** @param array<string,mixed> $payload */
    private static function emit(array $payload): void {
        $payload['emitted_at_utc']=gmdate('c');
        $payload['result_sha256']=PSERC_Stable_Json::hash($payload);
        if(!headers_sent()){
            if(function_exists('nocache_headers'))nocache_headers();
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="pserc-production-trigger-result-'.substr((string)$payload['result_sha256'],0,16).'.json"');
        }
        echo function_exists('wp_json_encode')?wp_json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT|JSON_PRESERVE_ZERO_FRACTION):json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT|JSON_PRESERVE_ZERO_FRACTION);
        exit;
    }
}
