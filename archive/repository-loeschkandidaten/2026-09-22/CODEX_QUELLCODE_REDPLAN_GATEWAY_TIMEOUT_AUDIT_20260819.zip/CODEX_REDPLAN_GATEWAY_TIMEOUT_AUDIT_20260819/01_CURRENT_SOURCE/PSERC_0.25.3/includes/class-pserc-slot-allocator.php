<?php
if (!defined('ABSPATH')) { return; }

/** Canonical slots are technical capacity only. No keyword, title, intent-angle or working-title routing. */
final class PSERC_Slot_Allocator {
    public static function allocate(array $topics,array $production,array $occupiedIds=[]): array {
        $slots=(array)($production['plan']['slots']??[]);
        $registered=array_values(array_unique(array_merge((array)($production['registered_article_types']??[]),(array)($production['planning_registered_article_types']??[]))));
        $supported=(array)($production['supported_article_types']??[]);
        $runtime=(array)($production['article_type_runtime']??[]);
        $occupied=array_fill_keys(array_map('strval',$occupiedIds),true);
        foreach($slots as $slot){
            foreach((array)($slot['existing_content_bindings']??[]) as $binding){
                if((int)($binding['post_id']??0)>0){$id=trim((string)($slot['canonical_article_id']??''));if($id!=='')$occupied[$id]=true;}
            }
        }
        $byKey=[];
        foreach($slots as $slot){
            $key=self::key((string)($slot['category_slug']??''),(string)($slot['article_type']??''));
            if($key!=='|')$byKey[$key][]=$slot;
        }
        foreach($byKey as &$group){usort($group,static fn($a,$b)=>[(int)($a['slot_number']??0),(string)($a['canonical_article_id']??'')]<=>[(int)($b['slot_number']??0),(string)($b['canonical_article_id']??'')]);}unset($group);

        $items=[];$reserved=[];
        foreach($topics as $topic){
            $type=(string)($topic['article_type']??'');
            $typeRuntime=is_array($runtime[$type]??null)?$runtime[$type]:[];
            if(!in_array($type,$registered,true)){$items[]=self::row($topic,'HELD_UNSUPPORTED_ARTICLE_TYPE',false,['ARTICLE_TYPE_NOT_REGISTERED'],$typeRuntime,null,self::notEvaluated('ARTICLE_TYPE_NOT_REGISTERED'));continue;}
            if(strtolower(trim($type))==='journal'){
                $routing=(array)($topic['journal_routing']??[]);$canonical=trim((string)($routing['canonical_plan_category_slug']??''));
                if($canonical===''){$items[]=self::row($topic,'HELD_JOURNAL_CATEGORY_NOT_IN_SIGNED_CANONICAL_PLAN',false,['JOURNAL_CATEGORY_NOT_IN_SIGNED_CANONICAL_PLAN'],$typeRuntime,null,self::notEvaluated('JOURNAL_CATEGORY_NOT_IN_SIGNED_CANONICAL_PLAN'));continue;}
                $group=(array)($byKey[self::key($canonical,'Journal')]??[]);
                if(!$group){$items[]=self::row($topic,'HELD_JOURNAL_CATEGORY_NOT_IN_SIGNED_CANONICAL_PLAN',false,['JOURNAL_SIGNED_CANONICAL_CATEGORY_SLOT_MISSING'],$typeRuntime,null,self::notEvaluated('JOURNAL_SIGNED_CANONICAL_CATEGORY_SLOT_MISSING'));continue;}
                $slot=null;foreach($group as $candidate){$id=trim((string)($candidate['canonical_article_id']??''));if($id!==''&&!isset($occupied[$id])&&!isset($reserved[$id])){$slot=$candidate;break;}}
                if(!is_array($slot)){$items[]=self::row($topic,'BLOCKED_NO_FREE_CANONICAL_SLOT',false,['NO_FREE_CANONICAL_JOURNAL_SLOT'],$typeRuntime,null,self::notEvaluated('NO_FREE_CANONICAL_JOURNAL_SLOT'));continue;}
                $id=(string)$slot['canonical_article_id'];$reserved[$id]=true;
                $slotEnabled=in_array('Journal',$supported,true)&&(bool)($slot['production_supported_by_current_engine']??false)&&(bool)($slot['draft_generation_allowed']??false)&&(($slot['publish_allowed']??null)===false);
                $status=$slotEnabled?'READY_FOR_METADATA_HANDOFF':'HELD_NO_ACTIVE_NORMAL_DRAFT_RELEASE';
                $items[]=self::row($topic,$status,$slotEnabled,$slotEnabled?[]:(array)($typeRuntime['reason_codes']??['JOURNAL_DRAFT_RELEASE_NOT_ACTIVE']),$typeRuntime,$slot,self::capacityPass($slot,'DETERMINISTIC_FIRST_FREE_SIGNED_JOURNAL_SLOT_SAME_CANONICAL_CATEGORY'));continue;
            }
            if(!in_array($type,$supported,true)){$items[]=self::row($topic,'HELD_NO_ACTIVE_NORMAL_DRAFT_RELEASE',false,(array)($typeRuntime['reason_codes']??['ARTICLE_TYPE_NOT_RELEASED_FOR_NORMAL_DRAFT']),$typeRuntime,null,self::notEvaluated('ARTICLE_TYPE_NOT_RELEASED_FOR_NORMAL_DRAFT'));continue;}
            $group=(array)($byKey[self::key((string)($topic['category_slug']??''),$type)]??[]);
            if(!$group){$items[]=self::row($topic,'BLOCKED_NO_FREE_CANONICAL_SLOT',true,['NO_CANONICAL_SLOT_FOR_CATEGORY_AND_TYPE'],$typeRuntime,null,self::notEvaluated('NO_CANONICAL_SLOT_FOR_CATEGORY_AND_TYPE'));continue;}
            $slot=null;
            foreach($group as $candidate){$id=trim((string)($candidate['canonical_article_id']??''));if($id!==''&&!isset($occupied[$id])&&!isset($reserved[$id])){$slot=$candidate;break;}}
            if(!is_array($slot)){$items[]=self::row($topic,'BLOCKED_NO_FREE_CANONICAL_SLOT',true,['NO_FREE_CANONICAL_SLOT'],$typeRuntime,null,self::notEvaluated('NO_FREE_CANONICAL_SLOT'));continue;}
            $id=(string)$slot['canonical_article_id'];$reserved[$id]=true;
            $slotEnabled=(bool)($slot['production_supported_by_current_engine']??false)&&(bool)($slot['draft_generation_allowed']??false);
            $status=$slotEnabled?'READY_FOR_METADATA_HANDOFF':'HELD_SLOT_NOT_PRODUCTION_ENABLED';
            $items[]=self::row($topic,$status,$slotEnabled,$slotEnabled?[]:['CANONICAL_SLOT_NOT_PRODUCTION_ENABLED'],$typeRuntime,$slot,self::capacityPass($slot));
        }
        return ['items'=>$items,'occupied_ids'=>array_keys($occupied),'reserved_ids'=>array_keys($reserved)];
    }

    public static function occupiedCanonicalIds(): array {
        $ids=[];
        if(function_exists('get_option')){$state=get_option('ppm679_editorial_plan_runtime_state_v1',[]);foreach((array)($state['items']??[]) as $id=>$row){$canonical=trim((string)($row['canonical_article_id']??$id));if($canonical!=='')$ids[$canonical]=true;}}
        global $wpdb;
        if(isset($wpdb)&&is_object($wpdb)&&isset($wpdb->postmeta)&&method_exists($wpdb,'get_col')){$rows=$wpdb->get_col("SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key='_ppm679_canonical_article_id'");foreach((array)$rows as $id){$id=trim((string)$id);if($id!=='')$ids[$id]=true;}}
        return array_keys($ids);
    }

    private static function capacityPass(array $slot,string $matchingMode='DETERMINISTIC_FIRST_FREE_SLOT_SAME_CATEGORY_AND_ARTICLE_TYPE'): array {
        return [
            'ok'=>true,'status'=>'PSERC_TECHNICAL_SLOT_CAPACITY_PASS','reason_codes'=>[],
            'matching_mode'=>$matchingMode,
            'best_canonical_article_id'=>(string)($slot['canonical_article_id']??''),'best_slot_number'=>(int)($slot['slot_number']??0),
            'best_intent_angle'=>'','best_score'=>0.0,'runner_up_score'=>0.0,'score_margin'=>0.0,'competing_ratio'=>0.0,'top_candidates'=>[],
            'best_slot_free'=>true,'resolved_topic_intent_angle'=>'','matched_intent_angles'=>[],'assigned_slot_intent_angle'=>'','intent_evidence'=>[],
            'semantic_role'=>'NONE_TECHNICAL_CAPACITY_ONLY','canonical_working_title_semantic_role'=>'NONE_UNTRUSTED_LEGACY_LABEL',
            'title_used_for_intent_admission'=>false,'working_title_used_for_slot_allocation'=>false,'intent_angle_used_for_slot_allocation'=>false,'write_attempted'=>false,
        ];
    }
    private static function notEvaluated(string $reason): array {
        return ['ok'=>false,'status'=>'PSERC_TECHNICAL_SLOT_CAPACITY_NOT_EVALUATED','reason_codes'=>[$reason],'matching_mode'=>'NOT_EVALUATED','best_canonical_article_id'=>'','best_slot_number'=>0,'best_intent_angle'=>'','best_score'=>0.0,'runner_up_score'=>0.0,'score_margin'=>0.0,'competing_ratio'=>0.0,'top_candidates'=>[],'best_slot_free'=>false,'semantic_role'=>'NONE_TECHNICAL_CAPACITY_ONLY','title_used_for_intent_admission'=>false,'working_title_used_for_slot_allocation'=>false,'intent_angle_used_for_slot_allocation'=>false,'write_attempted'=>false];
    }
    private static function row(array $topic,string $status,bool $supported,array $reasons,array $runtime,?array $slot,array $gate): array{return ['topic'=>$topic,'status'=>$status,'production_supported'=>$supported,'production_reason_codes'=>array_values(array_unique(array_map('strval',$reasons))),'article_type_runtime'=>$runtime,'slot'=>$slot,'slot_intent_gate'=>$gate];}
    private static function key(string $slug,string $type): string{return strtolower(trim($slug)).'|'.strtolower(trim($type));}
}
