<?php
if (!defined('ABSPATH')) { return; }

final class PSERC_Compiler {
    public static function compile(
        ?string $forcedProductionRoot=null,
        ?array $forcedSeoSnapshot=null,
        ?array $forcedOccupied=null,
        ?array $forcedExistingContent=null,
        ?array $forcedBaseline=null,
        ?array $forcedPortalEvidence=null,
        ?array $forcedProductionSnapshot=null,
        ?array $forcedStructureRegistry=null
    ): array {
        $packageIntegrity=PSERC_Package_Integrity::validate();
        if(empty($packageIntegrity['ok']))return self::blocked((string)$packageIntegrity['status'],(string)($packageIntegrity['message']??'PSERC_COMPILER_PACKAGE_INTEGRITY_BLOCKED'),['package_integrity'=>$packageIntegrity]);
        $production=($forcedProductionSnapshot!==null&&defined('PSERC_TEST_MODE')&&PSERC_TEST_MODE)
            ? $forcedProductionSnapshot
            : PSERC_Production_Reader::snapshot($forcedProductionRoot);
        if(empty($production['ok']))return self::blocked((string)$production['status'],(string)$production['message'],['production'=>$production]);
        $titleRuleCompatibility=PSERC_Title_Rule_Compatibility::inspect($production);
        if(empty($titleRuleCompatibility['ok']))return self::blocked('PSERC_TITLE_RULE_CONTRACT_CONFLICT','Aktive Textmaschinen-Titelregeln und Portal-Titelregeln widersprechen sich.',['title_rule_compatibility'=>$titleRuleCompatibility]);
        $structure=PSERC_Portal_Structure_Gate::validate($forcedBaseline,$forcedStructureRegistry);
        if(empty($structure['ok']))return self::blocked((string)$structure['status'],(string)($structure['message']??'PORTAL_STRUCTURE_BLOCKED'),['portal_structure'=>$structure]);
        $seo=$forcedSeoSnapshot??PSERC_SEO_Reader::snapshot();
        if(empty($seo['ok']))return self::blocked((string)$seo['status'],(string)$seo['message'],['seo'=>$seo]);
        $existing=PSERC_Existing_Content_Reader::snapshot($forcedExistingContent);
        if(empty($existing['ok']))return self::blocked((string)$existing['status'],(string)$existing['message'],['existing_content'=>$existing]);

        $prepared=[];$review=[];$candidateIdentity=[];
        foreach((array)$seo['eligible'] as $rawTopic){
            $topic=(array)$rawTopic;$title=trim((string)($topic['production_title']??''));

            // Both strands are always executed for every compiler-eligible SEO topic before any candidate-level hold.
            // Neither receives nor consumes the result of the other.
            $technical=PSERC_Technical_Strand::evaluate($topic,$production,$structure,$forcedBaseline);
            $editorial=PSERC_Editorial_Strand::evaluate($topic);
            $topic['technical_strand_report']=$technical;$topic['editorial_strand_report']=$editorial;
            $topic['assignment_consistency_gate']=(array)($technical['assignment_consistency_gate']??[]);
            $topic['semantic_assignment_gate']=$topic['assignment_consistency_gate']; // compatibility export only
            $topic['title_gate_initial']=(array)($technical['title_gate']??[]);
            $topic['language_gate']=(array)($technical['language_gate']??[]);
            $topic['editorial_outcome_gate']=(array)($editorial['editorial_outcome_gate']??[]);

            if(empty($technical['ok'])){
                $review[]=self::review($topic,(string)($technical['primary_status']??'BLOCKED_TECHNICAL_STRAND'),(array)($technical['reason_codes']??['TECHNICAL_STRAND_BLOCKED']));continue;
            }
            if(empty($editorial['ok'])){
                $review[]=self::review($topic,'BLOCKED_EDITORIAL_STRAND',(array)($editorial['reason_codes']??['EDITORIAL_STRAND_BLOCKED']));continue;
            }

            // Semantic uniqueness is a separate read-only gate. Canonical plan slots are never
            // used as duplicate/cannibalisation evidence and cannot reinterpret the topic.
            $existingSemantic=PSERC_Semantic_Duplicate_Gate::againstExisting($topic,$existing);
            $topic['semantic_duplicate_gate']=$existingSemantic;
            if(($existingSemantic['decision']??'PASS')==='BLOCKED_DUPLICATE'){
                $review[]=self::review($topic,'BLOCKED_EXISTING_CONTENT_DUPLICATE',(array)($existingSemantic['reason_codes']??['EXISTING_CONTENT_DUPLICATE']),$existingSemantic);continue;
            }
            if(($existingSemantic['decision']??'PASS')==='REVIEW_REQUIRED'){
                $review[]=self::review($topic,'REVIEW_REQUIRED_SEMANTIC_OVERLAP',(array)($existingSemantic['reason_codes']??['SEMANTIC_OVERLAP_REVIEW_REQUIRED']),$existingSemantic);continue;
            }
            $candidateSemantic=PSERC_Semantic_Duplicate_Gate::againstPreparedCandidates($topic,$prepared);
            $topic['semantic_duplicate_gate']=$candidateSemantic;
            if(($candidateSemantic['decision']??'PASS')==='BLOCKED_DUPLICATE'){
                $review[]=self::review($topic,'BLOCKED_DUPLICATE_METADATA_CANDIDATE',(array)($candidateSemantic['reason_codes']??['DUPLICATE_WITHIN_METADATA_CANDIDATES']),$candidateSemantic);continue;
            }
            if(($candidateSemantic['decision']??'PASS')==='REVIEW_REQUIRED'){
                $review[]=self::review($topic,'REVIEW_REQUIRED_SEMANTIC_OVERLAP',(array)($candidateSemantic['reason_codes']??['SEMANTIC_OVERLAP_REVIEW_REQUIRED']),$candidateSemantic);continue;
            }

            $keyword=PSERC_Target_Keyword::derive($topic,$title,null);$topic['preallocation_keyword']=$keyword;
            if(($keyword['status']??'')!=='PASS'){$review[]=self::review($topic,'REVIEW_REQUIRED_TARGET_KEYWORD',(array)($keyword['errors']??['TARGET_KEYWORD_BLOCKED']));continue;}
            $portalEvidence=PSERC_Portal_Topic_Evidence_Gate::evaluate(self::upstreamEvidenceView($topic),$structure);$topic['portal_topic_evidence_gate']=$portalEvidence;
            if(empty($portalEvidence['ok'])){$review[]=self::review($topic,'BLOCKED_PORTAL_TOPIC_EVIDENCE',(array)($portalEvidence['reason_codes']??['PORTAL_TOPIC_EVIDENCE_BLOCKED']));continue;}

            $prepared[]=$topic;
        }

        $occupied=$forcedOccupied!==null?$forcedOccupied:PSERC_Slot_Allocator::occupiedCanonicalIds();
        $allocation=PSERC_Slot_Allocator::allocate($prepared,$production,$occupied);
        $items=[];$counts=self::emptyCounts();
        foreach($review as $row){$counts[$row['status']]=($counts[$row['status']]??0)+1;$items[]=self::itemFromReview($row);}

        foreach((array)$allocation['items'] as $row){
            $topic=(array)$row['topic'];$slot=is_array($row['slot']??null)?$row['slot']:null;$status=(string)$row['status'];
            $title=(string)($topic['production_title']??'');$type=(string)($topic['article_type']??'');
            $contract=PSERC_Production_Reader::titleContract($production,$type);
            $keyword=PSERC_Target_Keyword::derive($topic,$title,$slot);
            $finalGate=(array)($topic['title_gate_initial']??[]);
            $portalEvidence=(array)($topic['portal_topic_evidence_gate']??[]);

            if(PSERC_Metadata_Boundary::isQuestionTitle($title)&&!in_array($type,['FAQ','Journal'],true))$status='BLOCKED_QUESTION_TITLE_NOT_FAQ';
            elseif(!self::categoryMatchesStructure($topic,$type,$structure))$status='BLOCKED_CATEGORY_ARTICLE_TYPE_MISMATCH';
            elseif($slot&&($keyword['status']??'')==='PASS'){
                $finalGate=PSERC_Title_Gate::verify($title,$type,$contract,(string)($keyword['target_keyword']??''));
                if(($finalGate['status']??'')!=='PASS')$status='REVIEW_REQUIRED_TITLE_COMPATIBILITY';
                else{
                    $portalEvidence=PSERC_Portal_Topic_Evidence_Gate::evaluate(self::upstreamEvidenceView($topic),$structure);
                    if(empty($portalEvidence['ok']))$status='BLOCKED_PORTAL_TOPIC_EVIDENCE';
                }
            }elseif($slot)$status='REVIEW_REQUIRED_TARGET_KEYWORD';

            $technicalPass=(string)($topic['technical_strand_report']['status']??'FAIL')==='PASS';
            $editorialPass=(string)($topic['editorial_strand_report']['status']??'FAIL')==='PASS';
            $e2ePass=$status==='READY_FOR_METADATA_HANDOFF'&&$technicalPass&&$editorialPass&&$slot!==null&&($finalGate['status']??'')==='PASS'&&!empty($portalEvidence['ok'])&&($keyword['status']??'')==='PASS';
            $release=PSERC_Release_Aggregator::decide($technicalPass?'PASS':'FAIL',$editorialPass?'PASS':'FAIL',$e2ePass?'PASS':'FAIL');
            if($status==='READY_FOR_METADATA_HANDOFF'&&empty($release['ready']))$status='BLOCKED_DUAL_STRAND_RELEASE';

            $counts[$status]=($counts[$status]??0)+1;
            $targetKeyword=($keyword['status']??'')==='PASS'?(string)$keyword['target_keyword']:'';
            $slotHash=$slot?PSERC_Plan_Slot_Identity::token($slot):'';
            $items[]=[
                'seo_topic_id'=>(string)($topic['candidate_id']??$topic['pool_key']??''),
                'status'=>$status,
                'article_type'=>$type,
                'production_reason_codes'=>array_values(array_unique(array_merge((array)($row['production_reason_codes']??[]),$status==='BLOCKED_PORTAL_TOPIC_EVIDENCE'?(array)($portalEvidence['reason_codes']??[]):[]))),
                'category'=>['id'=>(int)($topic['category_id']??0),'name'=>(string)($topic['category_name']??''),'slug'=>(string)($topic['category_slug']??'')],
                'title'=>[
                    'production_title'=>$title,
                    'production_title_sha256'=>$title!==''?hash('sha256',$title):'',
                    'automatic_changes'=>array_values(array_unique(array_merge((array)($finalGate['changes']??[]),(array)($topic['language_gate']['automatic_changes']??[])))),
                    'errors'=>(array)($finalGate['errors']??[]),
                    'warnings'=>(array)($finalGate['warnings']??[]),
                    'question_title'=>PSERC_Metadata_Boundary::isQuestionTitle($title),
                ],
                'target_keyword'=>['value'=>$targetKeyword,'sha256'=>(string)($keyword['target_keyword_sha256']??''),'status'=>(string)($keyword['status']??'REVIEW_REQUIRED'),'errors'=>(array)($keyword['errors']??[]),'verbatim_title_binding'=>($keyword['status']??'')==='PASS','semantic_title_binding'=>($keyword['status']??'')==='PASS','raw_query_may_differ_from_target_keyword'=>true],
                'canonical_slot'=>$slot?['canonical_article_id'=>(string)($slot['canonical_article_id']??''),'slot_number'=>(int)($slot['slot_number']??0),'plan_slot_sha256'=>$slotHash]:null,
                'technical_slot_capacity_gate'=>(array)($row['slot_intent_gate']??[]),
                'slot_intent_gate'=>(array)($row['slot_intent_gate']??[]),
                'intent_profile'=>(array)($topic['intent_profile']??[]),
                'metadata_binding'=>$status==='READY_FOR_METADATA_HANDOFF'?[
                    'title'=>$title,
                    'target_keyword'=>$targetKeyword,
                    'category'=>(string)($topic['category_slug']??''),
                    'article_type'=>$type,
                    'plan_slot'=>$slotHash,
                ]:null,
                'assignment_consistency_gate'=>(array)($topic['assignment_consistency_gate']??[]),
                'semantic_assignment_gate'=>(array)($topic['semantic_assignment_gate']??[]),
                'technical_strand_report'=>(array)($topic['technical_strand_report']??[]),
                'editorial_strand_report'=>(array)($topic['editorial_strand_report']??[]),
                'editorial_outcome_gate'=>(array)($topic['editorial_outcome_gate']??[]),
                'language_gate'=>(array)($topic['language_gate']??[]),
                'portal_topic_evidence_gate'=>$portalEvidence,
                'content_or_format_payload_present'=>false,
                'production_started'=>false,
                'wordpress_write_attempted'=>false,
                'duplicate_match'=>[],
                'semantic_duplicate_gate'=>(array)($topic['semantic_duplicate_gate']??[]),
                'release_decision'=>$release,
                'runtime_assignment'=>['changed'=>false,'reason'=>(string)($topic['runtime_assignment_reason']??'RUNTIME_REASSIGNMENT_DISABLED_FAIL_CLOSED')],
            ];
        }

        usort($items,static fn($a,$b)=>[self::statusOrder((string)$a['status']),(string)($a['title']['production_title']??'')]<=>[self::statusOrder((string)$b['status']),(string)($b['title']['production_title']??'')]);
        $nextBatch=self::selectNextMetadataBatch($items,(array)$production['batch_policy']);
        $boundary=PSERC_Metadata_Boundary::validateBatch($nextBatch);
        if(empty($boundary['ok']))return self::blocked((string)$boundary['status'],(string)$boundary['message'],['metadata_batch'=>$nextBatch]);

        $manifest=[
            'contract'=>'PSERC_METADATA_ONLY_READ_ONLY_PREVIEW_V5_DUAL_STRAND',
            'version'=>'5.0.0',
            'compiler_version'=>defined('PSERC_VERSION')?PSERC_VERSION:'0.6.8-metadata-boundary-readonly',
            'created_at_utc'=>gmdate('c'),
            'mode'=>'READ_ONLY_METADATA_ONLY_EXACT_FIVE_FIELDS',
            'system_boundary'=>[
                'production_machine_modified'=>false,'production_center_modified'=>false,'editorial_guard_modified'=>false,'design_plugin_modified'=>false,
                'posts_terms_urls_yoast_modified'=>false,'existing_articles_modified'=>false,'production_started'=>false,'draft_created'=>false,'publish_allowed'=>false,
                'wordpress_database_write_attempted'=>false,'plugin_option_write_attempted'=>false,'server_file_write_attempted'=>false,'article_text_emitted'=>false,'html_emitted'=>false,
                'fact_pack_emitted'=>false,'headings_tables_lists_links_emitted'=>false,
            ],
            'hard_rules'=>[
                'question_title_always_faq'=>true,'journal_question_title_registered_exception'=>true,'category_must_match_article_type'=>true,'semantic_category_family_must_match_source_query'=>true,
                'runtime_reassignment_forbidden'=>true,'portal_internal_topic_evidence_required'=>true,'external_serp_evidence_required'=>false,'text_machine_is_only_content_and_format_authority'=>true,
                'metadata_handoff_exact_scalar_fields'=>['title','target_keyword','category','article_type','plan_slot'],
                'unsupported_metadata_only_intake_must_block'=>true,'existing_title_slug_and_topic_duplicates_blocked'=>true,
                'canonical_slot_is_technical_capacity_only'=>true,'direct_ppm_consumer_claimed'=>false,'approved_research_text_process_required'=>true,'ppm_package_requires_canonical_article_id_before_preflight'=>true,'plan_slot_identity_contract'=>PSERC_Plan_Slot_Identity::CONTRACT,'plan_slot_identity_excludes_working_title_and_intent_angle'=>true,'semantic_duplicate_gate_is_separate_from_slot_capacity'=>true,'ready_requires_technical_editorial_and_e2e_pass'=>true,'textmachine_target_keyword_exact_title_binding_prevalidated'=>true,'raw_keyword_remains_separately_preserved'=>true,
            ],
            'bindings'=>[
                'compiler_version'=>(string)PSERC_VERSION,'compiler_build'=>(string)PSERC_BUILD,'compiler_package_binding_sha256'=>(string)$packageIntegrity['binding_sha256'],
                'production_version'=>(string)$production['version'],'production_baseline_sha256'=>(string)$production['baseline_sha256'],'production_file_hashes'=>$production['hashes'],
                'canonical_plan_file_sha256'=>(string)$production['hashes']['contracts/canonical-complete-editorial-plan-v1.json'],
                'normal_draft_release_sha256'=>(string)$production['normal_draft_release_sha256'],'normal_draft_release_self_hash'=>(string)$production['normal_draft_release_self_hash'],
                'seo_version'=>(string)$seo['version'],'seo_schema'=>(string)$seo['schema'],'seo_snapshot_sha256'=>(string)$seo['snapshot_sha256'],
                'seo_source_binding_sha256'=>(string)($seo['source_binding_sha256']??''),'seo_source_binding_file_count'=>(int)($seo['source_binding_file_count']??0),
                'seo_capability_binding_sha256'=>(string)($seo['capability_binding_sha256']??''),'seo_capability_required_symbol_count'=>(int)($seo['capability_required_symbol_count']??0),
                'portal_structure_registry_sha256'=>(string)$structure['registry_sha256'],'portal_structure_category_count'=>(int)$structure['category_count'],
                'portal_structure_live_baseline_sha256'=>(string)$structure['live_baseline_sha256'],
                'occupied_canonical_ids_sha256'=>PSERC_Stable_Json::hash(array_values((array)$allocation['occupied_ids'])),'plan_slot_identity'=>PSERC_Plan_Slot_Identity::contract(),
                'existing_content_snapshot_sha256'=>(string)$existing['snapshot_sha256'],'existing_content_item_count'=>(int)$existing['item_count'],
            ],
            'existing_content_inventory'=>['status'=>(string)$existing['status'],'source'=>(string)$existing['source'],'item_count'=>(int)$existing['item_count'],'snapshot_sha256'=>(string)$existing['snapshot_sha256'],'write_attempted'=>false],
            'production_release'=>['registered_article_types'=>$production['registered_article_types'],'planning_registered_article_types'=>(array)($production['planning_registered_article_types']??[]),'journal_registration'=>(array)($production['journal_registration']??[]),'metadata_candidate_article_types'=>$production['supported_article_types'],'batch_policy'=>['minimum_articles'=>1,'maximum_articles'=>0,'maximum_articles_per_type'=>0,'zero_means_unbounded'=>true,'scope_mode'=>'USER_SELECTED_READY_SET_UNBOUNDED','publish_allowed'=>false,'wissen_allowed'=>true],'ppm_internal_execution_policy'=>$production['batch_policy'],'publish_allowed'=>false],
            'title_rule_compatibility'=>$titleRuleCompatibility,
            'counts'=>array_merge(['seo_all'=>(int)$seo['all_count'],'seo_eligible'=>(int)$seo['eligible_count'],'seo_held'=>(int)$seo['held_count'],'compiled_items'=>count($items),'next_metadata_batch_items'=>(int)$nextBatch['item_count']],$counts),
            'items'=>$items,
            'next_textmachine_metadata_batch'=>$nextBatch,
            'metadata_boundary'=>$boundary,
            'persistence'=>['server_storage'=>false,'wordpress_option_storage'=>false,'preview_exists_only_in_current_response_or_browser_download'=>true],
            'next_step'=>$nextBatch['item_count']>0?'APPROVED_RESEARCH_TEXT_PROCESS_INTAKE_REQUIRED':'NO_ARTICLE_TEST_ITEM_FAIL_CLOSED',
        ];
        $manifest['manifest_sha256']=PSERC_Stable_Json::hash($manifest);
        return ['ok'=>true,'status'=>'PSERC_METADATA_ONLY_PREVIEW_PASS','manifest'=>$manifest,'ready_count'=>(int)($counts['READY_FOR_METADATA_HANDOFF']??0),'batch_count'=>(int)$nextBatch['item_count'],'write_attempted'=>false];
    }

    private static function selectNextMetadataBatch(array $items,array $policy): array {
        // User-facing READY selection has no artificial quantity ceiling and no per-type ceiling.
        // The unchanged PPM 6.7.9 release scope is handled later only as an internal execution detail.
        $selected=[];
        foreach($items as $item){
            if((string)($item['status']??'')!=='READY_FOR_METADATA_HANDOFF')continue;
            $binding=(array)($item['metadata_binding']??[]);
            $selected[]=[
                'title'=>(string)($binding['title']??''),
                'target_keyword'=>(string)($binding['target_keyword']??''),
                'category'=>(string)($binding['category']??''),
                'article_type'=>(string)($binding['article_type']??''),
                'plan_slot'=>(string)($binding['plan_slot']??''),
            ];
        }
        $batch=[
            'contract'=>'PSERC_TEXTMACHINE_METADATA_BATCH_V2',
            'status'=>$selected?'READY_FOR_TEXTMACHINE_METADATA_INTAKE':'NO_READY_ITEMS',
            'item_count'=>count($selected),
            'maximum_articles'=>0,
            'maximum_articles_per_type'=>0,
            'publish_allowed'=>false,
            'content_or_format_payload_present'=>false,
            'items'=>$selected,
        ];
        $batch['batch_sha256']=PSERC_Stable_Json::hash($batch);
        return $batch;
    }

    private static function review(array $topic,string $status,array $reasons=[],array $duplicate=[]): array{return ['topic'=>$topic,'status'=>$status,'reason_codes'=>array_values(array_unique(array_map('strval',$reasons))),'duplicate_match'=>$duplicate];}
    private static function itemFromReview(array $row): array {
        $topic=(array)$row['topic'];$gate=(array)($topic['title_gate_initial']??[]);$language=(array)($topic['language_gate']??[]);
        $title=(string)($topic['production_title']??$language['production_title']??$gate['production_title']??'');
        $technical=(array)($topic['technical_strand_report']??[]);$editorial=(array)($topic['editorial_strand_report']??[]);
        $technicalStatus=(string)($technical['status']??'FAIL');$editorialStatus=(string)($editorial['status']??'FAIL');
        $release=PSERC_Release_Aggregator::decide($technicalStatus==='PASS'?'PASS':'FAIL',$editorialStatus==='PASS'?'PASS':'FAIL','FAIL');
        $keyword=PSERC_Target_Keyword::derive($topic,$title,null);$preservedKeyword=(string)($keyword['target_keyword']??'');
        return [
            'seo_topic_id'=>(string)($topic['candidate_id']??$topic['pool_key']??''),'status'=>(string)$row['status'],'article_type'=>(string)($topic['article_type']??''),
            'production_reason_codes'=>(array)($row['reason_codes']??[]),
            'category'=>['id'=>(int)($topic['category_id']??0),'name'=>(string)($topic['category_name']??''),'slug'=>(string)($topic['category_slug']??'')],
            'title'=>['production_title'=>$title,'production_title_sha256'=>$title!==''?hash('sha256',$title):'','automatic_changes'=>[],'errors'=>(array)($gate['errors']??[]),'warnings'=>(array)($gate['warnings']??[]),'question_title'=>PSERC_Metadata_Boundary::isQuestionTitle($title)],
            'target_keyword'=>['value'=>$preservedKeyword,'sha256'=>$preservedKeyword!==''?hash('sha256',$preservedKeyword):'','status'=>(string)($keyword['status']??'REVIEW_REQUIRED'),'errors'=>(array)($keyword['errors']??[]),'verbatim_title_binding'=>false,'preserved_even_when_blocked'=>true],
            'canonical_slot'=>null,'technical_slot_capacity_gate'=>['ok'=>false,'status'=>'PSERC_TECHNICAL_SLOT_CAPACITY_NOT_EVALUATED','reason_codes'=>['PREALLOCATION_GATE_BLOCKED'],'semantic_role'=>'NONE_TECHNICAL_CAPACITY_ONLY','write_attempted'=>false],'slot_intent_gate'=>['ok'=>false,'status'=>'PSERC_TECHNICAL_SLOT_CAPACITY_NOT_EVALUATED','reason_codes'=>['PREALLOCATION_GATE_BLOCKED'],'semantic_role'=>'NONE_TECHNICAL_CAPACITY_ONLY','write_attempted'=>false],'metadata_binding'=>null,'intent_profile'=>(array)($topic['intent_profile']??[]),
            'assignment_consistency_gate'=>(array)($topic['assignment_consistency_gate']??[]),'semantic_assignment_gate'=>(array)($topic['semantic_assignment_gate']??[]),
            'technical_strand_report'=>$technical,'editorial_strand_report'=>$editorial,'editorial_outcome_gate'=>(array)($topic['editorial_outcome_gate']??[]),'language_gate'=>$language,'portal_topic_evidence_gate'=>(array)($topic['portal_topic_evidence_gate']??[]),
            'content_or_format_payload_present'=>false,'production_started'=>false,'wordpress_write_attempted'=>false,
            'duplicate_match'=>(array)($row['duplicate_match']??[]),'semantic_duplicate_gate'=>(array)($topic['semantic_duplicate_gate']??[]),'release_decision'=>$release,
            'runtime_assignment'=>['changed'=>false,'reason'=>(string)($topic['runtime_assignment_reason']??'RUNTIME_REASSIGNMENT_DISABLED_FAIL_CLOSED')],
        ];
    }

    private static function emptyCounts(): array{return array_fill_keys([
        'READY_FOR_METADATA_HANDOFF','HELD_NO_ACTIVE_NORMAL_DRAFT_RELEASE','HELD_JOURNAL_CATEGORY_NOT_IN_SIGNED_CANONICAL_PLAN','HELD_UNSUPPORTED_ARTICLE_TYPE','HELD_SLOT_NOT_PRODUCTION_ENABLED','BLOCKED_NO_FREE_CANONICAL_SLOT','BLOCKED_NO_SEMANTICALLY_COMPATIBLE_CANONICAL_SLOT',
        'REVIEW_REQUIRED_TITLE_COMPATIBILITY','REVIEW_REQUIRED_TARGET_KEYWORD','HELD_NO_TITLE_CONTRACT','BLOCKED_QUESTION_TITLE_NOT_FAQ','BLOCKED_CATEGORY_ARTICLE_TYPE_MISMATCH',
        'BLOCKED_EXISTING_CONTENT_DUPLICATE','BLOCKED_DUPLICATE_METADATA_CANDIDATE','REVIEW_REQUIRED_SEMANTIC_OVERLAP','BLOCKED_ASSIGNMENT_CONSISTENCY','BLOCKED_EDITORIAL_STRAND','BLOCKED_DUAL_STRAND_RELEASE','BLOCKED_LANGUAGE_GATE','BLOCKED_PORTAL_TOPIC_EVIDENCE'
    ],0);}
    private static function upstreamEvidenceView(array $topic): array {
        // The portal-evidence gate validates only the immutable upstream PSTE metadata.
        // Compiler-internal strand/duplicate/keyword diagnostics are deliberately excluded; they are
        // evaluated by their own gates and must never become hidden content payload at this boundary.
        foreach(['technical_strand_report','editorial_strand_report','assignment_consistency_gate','semantic_assignment_gate','title_gate_initial','language_gate','editorial_outcome_gate','semantic_duplicate_gate','preallocation_keyword','portal_topic_evidence_gate'] as $key)unset($topic[$key]);
        return $topic;
    }

    private static function categoryMatchesStructure(array $topic,string $type,array $structure): bool {
        $slug=trim((string)($topic['category_slug']??''));if($slug===''||$type==='')return false;
        if(self::norm($type)==='journal'){
            $routing=(array)($topic['journal_routing']??[]);$target=(array)($routing['target_category']??[]);$semantic=(array)($topic['semantic_consensus']??[]);
            return ($routing['contract']??'')==='PSTE_JOURNAL_ROUTER_V1'&&($routing['status']??'')==='JOURNAL_ROUTE_PASS'&&!empty($routing['ok'])&&($semantic['contract']??'')==='PSTE_JOURNAL_ROUTING_CONSENSUS_V1'&&!empty($semantic['ok'])&&hash_equals(trim((string)($target['slug']??'')),$slug)&&(int)($target['term_id']??0)===(int)($topic['category_id']??0);
        }
        $entry=PSERC_Portal_Structure_Gate::entry($structure,$slug);if(!is_array($entry))return false;
        return self::norm((string)($entry['canonical_article_type']??''))===self::norm($type);
    }
    private static function norm(string $value): string {$value=strtr(trim($value),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$value=function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);return trim((string)preg_replace('/[^a-z0-9]+/u',' ',$value));}
    private static function statusOrder(string $status): int{$order=['READY_FOR_METADATA_HANDOFF'=>0,'BLOCKED_ASSIGNMENT_CONSISTENCY'=>4,'BLOCKED_EDITORIAL_STRAND'=>5,'BLOCKED_DUAL_STRAND_RELEASE'=>6,'BLOCKED_LANGUAGE_GATE'=>7,'BLOCKED_PORTAL_TOPIC_EVIDENCE'=>8,'BLOCKED_QUESTION_TITLE_NOT_FAQ'=>7,'BLOCKED_CATEGORY_ARTICLE_TYPE_MISMATCH'=>8,'BLOCKED_EXISTING_CONTENT_DUPLICATE'=>9,'BLOCKED_DUPLICATE_METADATA_CANDIDATE'=>10,'REVIEW_REQUIRED_SEMANTIC_OVERLAP'=>11,'REVIEW_REQUIRED_TARGET_KEYWORD'=>12,'REVIEW_REQUIRED_TITLE_COMPATIBILITY'=>13,'HELD_NO_ACTIVE_NORMAL_DRAFT_RELEASE'=>20,'HELD_JOURNAL_CATEGORY_NOT_IN_SIGNED_CANONICAL_PLAN'=>21,'HELD_SLOT_NOT_PRODUCTION_ENABLED'=>22,'HELD_UNSUPPORTED_ARTICLE_TYPE'=>23,'HELD_NO_TITLE_CONTRACT'=>24,'BLOCKED_NO_SEMANTICALLY_COMPATIBLE_CANONICAL_SLOT'=>29,'BLOCKED_NO_FREE_CANONICAL_SLOT'=>30];return $order[$status]??99;}
    private static function contains(string $haystack,string $needle): bool{$h=function_exists('mb_strtolower')?mb_strtolower($haystack,'UTF-8'):strtolower($haystack);$n=function_exists('mb_strtolower')?mb_strtolower($needle,'UTF-8'):strtolower($needle);return $n!==''&&str_contains($h,$n);}
    private static function blocked(string $status,string $message,array $extra=[]): array{return array_merge(['ok'=>false,'status'=>$status,'message'=>$message,'write_attempted'=>false],$extra);}
}
