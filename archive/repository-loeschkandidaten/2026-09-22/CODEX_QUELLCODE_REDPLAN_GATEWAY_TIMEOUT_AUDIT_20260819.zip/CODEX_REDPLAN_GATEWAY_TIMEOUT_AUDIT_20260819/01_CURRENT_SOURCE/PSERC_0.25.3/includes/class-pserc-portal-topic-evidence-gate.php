<?php
if (!defined('ABSPATH')) { return; }

/** Read-only proof that a topic completed the approved portal workflow. */
final class PSERC_Portal_Topic_Evidence_Gate {
    private const DISCOVERY_SOURCES=['KEYWORD_SUGGESTION','RELATED_SEARCH','KEYWORD_IDEA','PAA','GSC','INTERNAL_SEARCH'];
    private const HARD_BLOCK_REASONS=[
        'SOURCE_PROVENANCE_MISSING','SNAPSHOT_STALE_OR_CHANGED','API_DATA_INCONSISTENT','PSTE_SITE_BASELINE_STALE',
        'PSTE_TARGET_CATEGORY_NOT_FOUND','PSTE_TARGET_CATEGORY_EXACT_MATCH_MISSING','PSTE_TARGET_CATEGORY_AMBIGUOUS',
        'EDITORIAL_TARGET_CATEGORY_MISSING','STRUCTURE_CHANGED_REVIEW_REQUIRED','CONTEXT_REFRESH_FAILED','CONTEXT_REFRESH_STALE',
        'ANSWER_EQUIVALENT_EXISTING','ANSWER_EQUIVALENT_PLANNED','EXACT_NORMALIZED_QUERY_DUPLICATE','SAME_INTENT_CLUSTER',
        'CROSS_TYPE_ANSWER_EQUIVALENCE','DUPLICATE_WITHIN_RESEARCH_RUN','DUPLICATE_WITHIN_METADATA_CANDIDATES',
        'PRE_TITLE_EXACT_DUPLICATE','PRE_TITLE_ANSWER_EQUIVALENT','NON_EDITORIAL_TRANSACTIONAL_QUERY','TRANSACTIONAL_QUERY',
        'STALE_YEAR_SPECIFIC_QUERY','CATEGORY_HEAD_INTENT_COLLISION','QUESTION_TITLE_NOT_FAQ','ARTICLE_TYPE_UNRESOLVED',
        'TITLE_GENERATION_FAILED','TITLE_FAMILY_MISSING','NO_DETERMINISTIC_EDITORIAL_SIGNAL','MULTIPLE_ARTICLE_TYPE_SIGNALS',
        'TARGET_CATEGORY_NOT_FOUND','DOMAIN_RISK_BLOCKED','SELF_TREATMENT_INSTRUCTION','MEDICATION_OR_DOSAGE_REVIEW','ACUTE_EMERGENCY_REVIEW'
    ];


    /** @return array<string,mixed> */
    public static function evaluate(array $topic,array $structure): array {
        $forbidden=PSERC_Metadata_Boundary::forbiddenContentPath($topic,'topic');if($forbidden!=='')return self::blocked('PORTAL_TOPIC_FORBIDDEN_CONTENT_FIELD',['forbidden_field'=>$forbidden]);
        if(($topic['research_job_contract']??'')!=='PSTE_AUTOMATIC_LONGTAIL_RESEARCH_JOB_V2')return self::blocked('PORTAL_TOPIC_RESEARCH_JOB_CONTRACT_INVALID');
        if(($topic['research_run_status']??'')!=='COMPLETE')return self::blocked('PORTAL_TOPIC_RESEARCH_RUN_NOT_COMPLETE');
        if(($topic['textmachine_handoff_status']??'')!=='READY_FOR_COMPILER_CAPABILITY_CHECK')return self::blocked('PORTAL_TOPIC_COMPILER_CAPABILITY_STATE_INVALID');
        if(array_values((array)($topic['metadata_handoff_fields']??[]))!==['title','target_keyword','category','article_type','plan_slot'])return self::blocked('PORTAL_TOPIC_METADATA_FIELD_CONTRACT_INVALID');

        $context=strtoupper(trim((string)($topic['context_state']??'')));
        if(!in_array($context,['CURRENT','NOT_REQUIRED'],true))return self::blocked('PORTAL_TOPIC_CONTEXT_NOT_CURRENT',['context_state'=>$context]);

        $record=(array)($topic['query_record']??[]);
        foreach(['raw_query','normalized_query','language_corrected_query'] as $field)if(trim((string)($record[$field]??''))==='')return self::blocked('PORTAL_TOPIC_QUERY_RECORD_INCOMPLETE',['field'=>$field]);
        $volumeStatus=strtoupper(trim((string)($record['volume_status']??'')));
        if(!in_array($volumeStatus,['MEASURED','UNMEASURED','UNAVAILABLE'],true))return self::blocked('PORTAL_TOPIC_VOLUME_STATUS_INVALID');
        if($volumeStatus==='MEASURED'){
            $measured=trim((string)($record['measured_query']??''));$raw=trim((string)$record['raw_query']);
            if($measured===''||!hash_equals(self::normalize($measured),self::normalize($raw)))return self::blocked('PORTAL_TOPIC_VOLUME_INHERITANCE_FORBIDDEN');
            if(!is_int($record['search_volume']??null)&&!is_float($record['search_volume']??null))return self::blocked('PORTAL_TOPIC_MEASURED_VOLUME_MISSING');
        }elseif(trim((string)($record['measured_query']??''))!==''||($record['search_volume']??null)!==null){
            return self::blocked('PORTAL_TOPIC_UNMEASURED_VOLUME_MUST_BE_EMPTY');
        }

        $evidence=array_values(array_filter((array)($topic['evidence']??[]),'is_array'));$discovery=[];
        foreach($evidence as $item){
            $source=strtoupper(trim((string)($item['source']??'')));$hash=trim((string)($item['raw_response_sha256']??''));
            if($source===''||!preg_match('/^[a-f0-9]{64}$/',$hash))continue;
            if(in_array($source,self::DISCOVERY_SOURCES,true))$discovery[$source]=true;
        }
        if(!$discovery)return self::blocked('PORTAL_TOPIC_LONGTAIL_EVIDENCE_MISSING');

        $reasons=array_values(array_unique(array_map('strval',(array)($topic['reason_codes']??[]))));
        $hard=array_values(array_intersect(self::HARD_BLOCK_REASONS,$reasons));if($hard)return self::blocked('PORTAL_TOPIC_HARD_REASON_PRESENT',['hard_reason_codes'=>$hard]);
        if(strtoupper(trim((string)($topic['decision']??'')))!=='PASS')return self::blocked('PORTAL_TOPIC_DECISION_NOT_PASS');

        // Topic-metadata schema V2 separates mechanical title validity from editorial quality.
        // This gate only verifies already-produced evidence; it never composes, repairs or reclassifies.
        $semantic=(array)($topic['semantic_consensus']??[]);$isJournal=self::normalize((string)($topic['article_type']??''))==='journal';
        if($isJournal){
            if(($semantic['contract']??'')!=='PSTE_JOURNAL_ROUTING_CONSENSUS_V1'||empty($semantic['ok'])||empty($semantic['type_consensus'])||empty($semantic['category_consensus'])||empty($semantic['family_consensus'])||($semantic['status']??'')!=='CONSENSUS_PASS')return self::blocked('PORTAL_TOPIC_JOURNAL_SEMANTIC_CONSENSUS_NOT_PASSED');
            $routing=(array)($topic['journal_routing']??[]);if(($routing['contract']??'')!=='PSTE_JOURNAL_ROUTER_V1'||($routing['status']??'')!=='JOURNAL_ROUTE_PASS'||empty($routing['ok']))return self::blocked('PORTAL_TOPIC_JOURNAL_ROUTING_PROOF_NOT_PASSED');
        }else{
            $membership=(array)($semantic['family_membership_gate']??[]);
            if(($semantic['contract']??'')!=='PSTE_SEMANTIC_DOUBLE_STRAND_V3'||empty($semantic['ok'])||empty($semantic['type_consensus'])||empty($semantic['category_consensus'])||empty($semantic['family_consensus'])||($semantic['status']??'')!=='CONSENSUS_PASS')return self::blocked('PORTAL_TOPIC_SEMANTIC_CONSENSUS_NOT_PASSED');
            if(($membership['contract']??'')!=='PSTE_FAMILY_MEMBERSHIP_GATE_V2'||empty($membership['ok'])||($membership['status']??'')!=='FAMILY_PASS')return self::blocked('PORTAL_TOPIC_FAMILY_MEMBERSHIP_NOT_PASSED');
        }

        $title=(array)($topic['title_quality']??[]);
        if(empty($title['ok'])||($title['status']??'')!=='TITLE_TECHNICAL_PASS'||($title['semantic_quality_claimed']??true)!==false)return self::blocked('PORTAL_TOPIC_TITLE_TECHNICAL_NOT_PASSED');
        $language=(array)($topic['language_quality']??[]);
        if(empty($language['ok'])||($language['status']??'')!=='LANGUAGE_PASS'||($language['semantic_quality_claimed']??true)!==false)return self::blocked('PORTAL_TOPIC_LANGUAGE_QUALITY_NOT_PASSED');

        $editorial=(array)($topic['editorial_quality_gate']??[]);
        if(($editorial['contract']??'')!=='PSTE_EDITORIAL_QUALITY_GATE_V4_HARD_TITLE_SURFACE_INTENT_SAFE'||empty($editorial['ok'])||($editorial['status']??'')!=='PASS')return self::blocked('PORTAL_TOPIC_EDITORIAL_QUALITY_NOT_PASSED');
        if(($editorial['composer_called']??true)!==false||($editorial['title_modified']??true)!==false||($editorial['technical_gate_result_consumed']??true)!==false)return self::blocked('PORTAL_TOPIC_EDITORIAL_INDEPENDENCE_NOT_PROVEN');
        $dual=(array)($topic['editorial_dual_strand']??[]);
        if(($dual['technical']['status']??'')!=='PASS'||($dual['editorial']['status']??'')!=='PASS'||($dual['editorial']['technical_result_consumed']??true)!==false)return self::blocked('PORTAL_TOPIC_DUAL_STRAND_NOT_PASSED');
        $risk=(array)($topic['domain_risk']??[]);if(empty($risk['ok']))return self::blocked('PORTAL_TOPIC_DOMAIN_RISK_NOT_PASSED');
        $fresh=(array)($topic['freshness']??[]);if(($fresh['status']??'')!=='CURRENT')return self::blocked('PORTAL_TOPIC_FRESHNESS_NOT_CURRENT');
        if(!empty($fresh['valid_until'])&&strtotime((string)$fresh['valid_until'])!==false&&strtotime((string)$fresh['valid_until'])<time())return self::blocked('PORTAL_TOPIC_FRESHNESS_EXPIRED');
        $pre=(array)($topic['pre_title_duplicate_gate']??[]);if(($pre['contract']??'')!=='PSTE_PRE_TITLE_DUPLICATE_GATE_V1'||empty($pre['ok']))return self::blocked('PORTAL_TOPIC_PRE_TITLE_DUPLICATE_GATE_NOT_PASSED');
        if(!empty($topic['category_gap_proposal']))return self::blocked('PORTAL_TOPIC_CATEGORY_GAP_NOT_PRODUCTION_READY');

        $slug=trim((string)($topic['category_slug']??''));$type=trim((string)($topic['article_type']??''));$family=trim((string)($topic['topic_family_name']??''));
        if($slug===''||$type===''||$family==='')return self::blocked('PORTAL_TOPIC_ASSIGNMENT_INCOMPLETE');
        if($isJournal){
            $routing=(array)($topic['journal_routing']??[]);$target=(array)($routing['target_category']??[]);
            if((int)($target['term_id']??0)!==(int)($topic['category_id']??0)||!hash_equals(trim((string)($target['slug']??'')),$slug)||strcasecmp(trim((string)($target['name']??'')),trim((string)($topic['category_name']??'')))!==0)return self::blocked('PORTAL_TOPIC_JOURNAL_CATEGORY_ROUTING_MISMATCH');
            if(self::normalize($type)!=='journal')return self::blocked('PORTAL_TOPIC_JOURNAL_TYPE_MISMATCH');
        }else{
            $entry=PSERC_Portal_Structure_Gate::entry($structure,$slug);if(!is_array($entry))return self::blocked('PORTAL_TOPIC_CATEGORY_NOT_IN_VALIDATED_STRUCTURE',['category_slug'=>$slug]);
            if(self::normalize($type)!==self::normalize((string)($entry['canonical_article_type']??'')))return self::blocked('PORTAL_TOPIC_CATEGORY_TYPE_MISMATCH');
            if(self::normalize($family)!==self::normalize((string)($entry['topic_family']??'')))return self::blocked('PORTAL_TOPIC_CATEGORY_FAMILY_MISMATCH');
        }
        if(trim((string)($topic['article_type_registry_sha256']??''))===''||!preg_match('/^[a-f0-9]{64}$/',(string)$topic['article_type_registry_sha256']))return self::blocked('PORTAL_TOPIC_ARTICLE_TYPE_REGISTRY_BINDING_INVALID');

        return ['ok'=>true,'status'=>'PSERC_PORTAL_TOPIC_EVIDENCE_PASS','reason_codes'=>[],'evidence_sources'=>array_keys($discovery),'enrichment_sources'=>[],'context_state'=>$context,'category_slug'=>$slug,'article_type'=>$type,'topic_family'=>$family,'query_record_sha256'=>PSERC_Stable_Json::hash($record),'write_attempted'=>false];
    }

    private static function normalize(string $value): string {$value=strtr(trim($value),['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss']);$value=function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);return trim((string)preg_replace('/[^a-z0-9]+/u',' ',$value));}
    /** @return array<string,mixed> */
    private static function blocked(string $reason,array $extra=[]): array {return array_merge(['ok'=>false,'status'=>'PSERC_PORTAL_TOPIC_EVIDENCE_BLOCKED','reason_codes'=>[$reason],'message'=>$reason,'write_attempted'=>false],$extra);}
}
