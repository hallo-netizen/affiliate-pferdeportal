<?php
if (!defined('ABSPATH')) { return; }

/** Read-only inventory of existing WordPress posts for duplicate and cannibalisation protection. */
final class PSERC_Existing_Content_Reader {
    public static function snapshot(?array $forced=null): array {
        if ($forced!==null) { return self::fromRows($forced,'FORCED_TEST_FIXTURE'); }
        global $wpdb;
        if (!isset($wpdb)||!is_object($wpdb)||!isset($wpdb->posts)||!isset($wpdb->postmeta)||!method_exists($wpdb,'get_results')) {
            if (defined('PSERC_TEST_MODE')&&PSERC_TEST_MODE) { return self::fromRows([],'EMPTY_TEST_CONTEXT'); }
            return ['ok'=>false,'status'=>'PSERC_EXISTING_CONTENT_INVENTORY_UNAVAILABLE','message'=>'Der schreibfreie WordPress-Inhaltsbestand konnte nicht gelesen werden.','write_attempted'=>false];
        }
        $sql="SELECT p.ID, p.post_title, p.post_name, p.post_status, p.post_content,\n"
            ."MAX(CASE WHEN pm.meta_key='_ppm679_canonical_article_id' THEN pm.meta_value ELSE '' END) AS canonical_article_id,\n"
            ."MAX(CASE WHEN pm.meta_key='_ppm679_plan_slot_sha256' THEN pm.meta_value ELSE '' END) AS plan_slot_sha256\n"
            ."FROM {$wpdb->posts} p\n"
            ."LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id=p.ID AND pm.meta_key IN ('_ppm679_canonical_article_id','_ppm679_plan_slot_sha256')\n"
            ."WHERE p.post_type='post' AND p.post_status IN ('publish','draft','trash','auto-draft','pending','private','future')\n"
            ."GROUP BY p.ID, p.post_title, p.post_name, p.post_status, p.post_content\n"
            ."ORDER BY p.ID ASC";
        $rows=$wpdb->get_results($sql,defined('ARRAY_A')?ARRAY_A:'ARRAY_A');
        if (!is_array($rows)) {
            return ['ok'=>false,'status'=>'PSERC_EXISTING_CONTENT_INVENTORY_READ_FAILED','message'=>'Die schreibfreie Titelabfrage lieferte kein gültiges Ergebnis.','write_attempted'=>false];
        }
        $categoryBulk=self::bulkFirstCategories($rows);$categoryByPost=(array)($categoryBulk['by_post']??[]);$categoryBulkOk=!empty($categoryBulk['ok']);
        foreach($rows as &$row){
            if(is_object($row))$row=(array)$row;
            $postId=(int)($row['ID']??0);$category=is_array($categoryByPost[$postId]??null)?(array)$categoryByPost[$postId]:null;
            if(is_array($category)){
                $row['category_id']=(int)($category['term_id']??0);
                $row['category_name']=(string)($category['name']??'');
                $row['category_slug']=(string)($category['slug']??'');
            }elseif(!$categoryBulkOk&&$postId>0&&function_exists('wp_get_post_categories')){
                // Fail-safe compatibility fallback only when the bulk taxonomy read itself is unavailable.
                $categories=wp_get_post_categories($postId,['fields'=>'all']);$fallback=is_array($categories)&&$categories?reset($categories):null;
                if(is_object($fallback)){$row['category_id']=(int)($fallback->term_id??0);$row['category_name']=(string)($fallback->name??'');$row['category_slug']=(string)($fallback->slug??'');}
            }
        }unset($row);
        return self::fromRows($rows,'WORDPRESS_READ_ONLY_SELECT');
    }

    /**
     * Bulk-load the same first category that wp_get_post_categories(..., fields=all)
     * would expose to this reader, ordered by term_id for deterministic parity.
     * @param array<int,mixed> $rows
     * @return array<int,array<string,mixed>>
     */
    private static function bulkFirstCategories(array $rows): array {
        $ids=[];foreach($rows as $row){if(is_object($row))$row=(array)$row;$id=(int)($row['ID']??0);if($id>0)$ids[$id]=true;}
        if(!$ids)return ['ok'=>true,'by_post'=>[]];
        global $wpdb;
        foreach(['term_relationships','term_taxonomy','terms'] as $prop)if(!isset($wpdb)||!is_object($wpdb)||empty($wpdb->{$prop})||!method_exists($wpdb,'get_results'))return ['ok'=>false,'by_post'=>[]];
        $idSql=implode(',',array_keys($ids));
        $sql="SELECT tr.object_id AS post_id, t.term_id, t.name, t.slug FROM {$wpdb->term_relationships} tr INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id INNER JOIN {$wpdb->terms} t ON t.term_id=tt.term_id WHERE tt.taxonomy='category' AND tr.object_id IN ({$idSql}) ORDER BY tr.object_id ASC, t.name ASC, t.term_id ASC";
        $found=$wpdb->get_results($sql,defined('ARRAY_A')?ARRAY_A:'ARRAY_A');if(!is_array($found))return ['ok'=>false,'by_post'=>[]];$out=[];
        foreach($found as $row){if(is_object($row))$row=(array)$row;$postId=(int)($row['post_id']??0);if($postId>0&&!isset($out[$postId]))$out[$postId]=['term_id'=>(int)($row['term_id']??0),'name'=>(string)($row['name']??''),'slug'=>(string)($row['slug']??'')];}
        return ['ok'=>true,'by_post'=>$out];
    }

    public static function match(array $snapshot,string $title): ?array {
        $exact=self::normalizeExact($title);$slug=self::slug($title);$identity=self::topicIdentity($title);
        foreach ((array)($snapshot['items']??[]) as $item) {
            $reason='';
            if ($exact!==''&&hash_equals((string)$item['normalized_title'],$exact)) $reason='EXACT_NORMALIZED_TITLE';
            elseif ($slug!==''&&hash_equals((string)$item['normalized_slug'],$slug)) $reason='NORMALIZED_SLUG';
            elseif ($identity!==''&&(string)$item['topic_identity']!==''&&hash_equals((string)$item['topic_identity'],$identity)) $reason='SEMANTIC_TOPIC_IDENTITY';
            if ($reason!=='') return ['reason'=>$reason,'post_id'=>(int)$item['post_id'],'status'=>(string)$item['status'],'title'=>(string)$item['title'],'slug'=>(string)$item['slug'],'canonical_article_id'=>(string)$item['canonical_article_id'],'topic_identity'=>(string)$item['topic_identity']];
        }
        return null;
    }

    /** @return list<array<string,mixed>> */
    public static function comparisonEvidence(array $snapshot,string $title,int $limit=5): array {
        $rows=[];
        foreach ((array)($snapshot['items']??[]) as $item) {
            if (!is_array($item)) { continue; }
            $other=trim((string)($item['title']??''));
            if ($other==='') { continue; }
            $similarity=self::similarity($title,$other);
            $equivalent=self::answerEquivalent($title,$other,$similarity);
            $rows[]=[
                'post_id'=>(int)($item['post_id']??0),'status'=>(string)($item['status']??''),'title'=>$other,
                'slug'=>(string)($item['slug']??''),'canonical_article_id'=>(string)($item['canonical_article_id']??''),
                'intent_similarity'=>$similarity,'answer_equivalence'=>$equivalent,
                'inventory_snapshot_sha256'=>(string)($snapshot['snapshot_sha256']??''),
                'comparison_method'=>class_exists('PSTE_Normalizer')?'PSTE_NORMALIZER_CURRENT_RUNTIME':'PSERC_DETERMINISTIC_FALLBACK',
            ];
        }
        usort($rows,static fn($a,$b)=>[-(float)$a['intent_similarity'],(int)$a['post_id'],(string)$a['title']]<=>[-(float)$b['intent_similarity'],(int)$b['post_id'],(string)$b['title']]);
        return array_slice($rows,0,max(1,$limit));
    }

    public static function normalizeExact(string $value): string {
        $value=trim(html_entity_decode(wp_strip_all_tags($value),ENT_QUOTES|ENT_HTML5,'UTF-8'));
        $value=strtr($value,['Ä'=>'Ae','Ö'=>'Oe','Ü'=>'Ue','ä'=>'ae','ö'=>'oe','ü'=>'ue','ß'=>'ss','–'=>' ','—'=>' ','-'=>' ']);
        $value=function_exists('mb_strtolower')?mb_strtolower($value,'UTF-8'):strtolower($value);
        $value=(string)preg_replace('/[^a-z0-9\s]+/u',' ',$value);
        return trim((string)preg_replace('/\s+/u',' ',$value));
    }

    public static function topicIdentity(string $value): string {
        $n=self::normalizeExact($value);if ($n==='') return '';
        $stop=['der','die','das','den','dem','des','ein','eine','einer','einem','einen','und','oder','von','fuer','bei','beim','im','in','auf','mit','zu','zum','zur','ich','du','man','muss','muessen','soll','sollte','sollen','ist','sind','was','wie','welche','welcher','welches','welchen','wann','warum','wieso','weshalb','worauf','kann','koennen','darf','duerfen','gibt','braucht','benoetigt','richtig','vorgehen','ueberblick','beste','bester','bestes','besten','am','test','tests','testbericht','testsieger','vergleich','vergleichen'];
        $tokens=[];foreach (explode(' ',$n) as $token) {if ($token===''||in_array($token,$stop,true)) continue;foreach (['ern','en','er','es','e','n','s'] as $suffix) {if (strlen($token)>strlen($suffix)+4&&str_ends_with($token,$suffix)) {$token=substr($token,0,-strlen($suffix));break;}}if ($token!=='')$tokens[$token]=true;}
        $tokens=array_keys($tokens);sort($tokens,SORT_STRING);return count($tokens)>=2?implode(' ',$tokens):'';
    }

    /** Exact engine-compatible inventory hash used by the read-only portal duplicate check. */
    public static function engineInventorySha256(array $snapshot): string {
        return (string)($snapshot['engine_inventory_sha256']??'');
    }

    private static function fromRows(array $rows,string $source): array {
        $items=[];$engineItems=[];
        foreach ($rows as $row) {
            if (is_object($row)) $row=(array)$row;if (!is_array($row)) continue;
            $title=trim((string)($row['post_title']??$row['title']??''));$slug=trim((string)($row['post_name']??$row['slug']??''));if ($title==='') continue;
            $postId=(int)($row['ID']??$row['post_id']??0);$status=(string)($row['post_status']??$row['status']??'');$content=(string)($row['post_content']??$row['content']??'');
            $categoryName=trim((string)($row['category_name']??''));$categorySlug=trim((string)($row['category_slug']??''));$categoryId=(int)($row['category_id']??0);
            $articleType=trim((string)($row['article_type']??self::categoryArticleType($categoryName)));
            $familyName=trim((string)($row['topic_family_name']??self::categoryFamilyName($categoryName)));
            $familyKey=trim((string)($row['topic_family_key']??self::familyKey($familyName)));
            $headings=array_values(array_map('strval',(array)($row['headings']??self::extractHeadings($content))));
            $contentFingerprint=trim((string)($row['content_fingerprint']??''));if($contentFingerprint==='')$contentFingerprint=hash('sha256',self::normalizerText($content));
            $canonical=trim((string)($row['canonical_article_id']??''));$planSlot=trim((string)($row['plan_slot_sha256']??''));
            $items[]=[
                'post_id'=>$postId,'status'=>$status,'title'=>$title,'slug'=>$slug,'canonical_article_id'=>$canonical,'plan_slot_sha256'=>$planSlot,
                'category_id'=>$categoryId,'category_name'=>$categoryName,'category_slug'=>$categorySlug,'article_type'=>$articleType,
                'topic_family_name'=>$familyName,'topic_family_key'=>$familyKey,'headings'=>$headings,'content_fingerprint'=>$contentFingerprint,
                'normalized_title'=>self::normalizeExact($title),'normalized_slug'=>$slug!==''?self::slug($slug):self::slug($title),'topic_identity'=>self::topicIdentity($title),
            ];
            if(in_array($status,['publish','draft','trash','auto-draft'],true)){
                $engineItems[]=[
                    'post_id'=>$postId,'title'=>$title,'status'=>$status,'category_id'=>$categoryId,'category_name'=>$categoryName,'category_slug'=>$categorySlug,
                    'article_type'=>$articleType,'topic_family_name'=>$familyName,'topic_family_key'=>$familyKey,'canonical_article_id'=>$canonical,
                    'plan_slot_sha256'=>$planSlot,'headings'=>$headings,'content_fingerprint'=>$contentFingerprint,'source'=>'WORDPRESS',
                ];
            }
        }
        usort($items,static fn($a,$b)=>[$a['post_id'],$a['normalized_title']]<=>[$b['post_id'],$b['normalized_title']]);
        usort($engineItems,static fn($a,$b)=>[(int)$a['post_id'],(string)$a['title']]<=>[(int)$b['post_id'],(string)$b['title']]);
        $enginePayload=['contract'=>'PSTE_INVENTORY_SNAPSHOT_V1','items'=>$engineItems];
        $engineJson=function_exists('wp_json_encode')?wp_json_encode($enginePayload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES):json_encode($enginePayload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $engineHash=is_string($engineJson)?hash('sha256',$engineJson):'';
        return ['ok'=>true,'status'=>'PSERC_EXISTING_CONTENT_READ_ONLY_PASS','source'=>$source,'item_count'=>count($items),'items'=>$items,'snapshot_sha256'=>PSERC_Stable_Json::hash($items),'engine_inventory_item_count'=>count($engineItems),'engine_inventory_items'=>$engineItems,'engine_inventory_sha256'=>$engineHash,'write_attempted'=>false];
    }

    /** @return list<string> */
    private static function extractHeadings(string $content): array {preg_match_all('/<h[23][^>]*>(.*?)<\/h[23]>/isu',$content,$m);return array_map(static fn($v)=>trim(wp_strip_all_tags((string)$v)),(array)($m[1]??[]));}
    private static function categoryArticleType(string $name): string {if(class_exists('PSTE_Normalizer'))return PSTE_Normalizer::categoryArticleType($name);if(preg_match('/^([^\s]+)\s+/u',$name,$m))return (string)$m[1];return '';}
    private static function categoryFamilyName(string $name): string {if(class_exists('PSTE_Normalizer'))return PSTE_Normalizer::categoryFamilyName($name);return trim((string)preg_replace('/^[^\s]+\s+/u','',$name));}
    private static function familyKey(string $name): string {return self::normalizerText($name);}
    private static function normalizerText(string $value): string {return class_exists('PSTE_Normalizer')?PSTE_Normalizer::text($value):self::normalizeExact($value);}
    private static function answerEquivalent(string $a,string $b,float $similarity): bool {if(class_exists('PSTE_Normalizer')&&method_exists('PSTE_Normalizer','answerEquivalent'))return (bool)PSTE_Normalizer::answerEquivalent($a,$b);$ia=self::topicIdentity($a);$ib=self::topicIdentity($b);return ($ia!==''&&$ib!==''&&hash_equals($ia,$ib))||$similarity>=0.78;}
    private static function similarity(string $a,string $b): float {if(class_exists('PSTE_Normalizer')&&method_exists('PSTE_Normalizer','similarity'))return max(0.0,min(1.0,round((float)PSTE_Normalizer::similarity($a,$b),6)));$ta=self::tokens($a);$tb=self::tokens($b);if(!$ta||!$tb)return 0.0;$intersection=count(array_intersect($ta,$tb));$union=count(array_unique(array_merge($ta,$tb)));return $union?round($intersection/$union,6):0.0;}
    /** @return list<string> */private static function tokens(string $value): array {$n=self::normalizeExact($value);$out=[];foreach(explode(' ',$n) as $token){if(strlen($token)<3)continue;$out[$token]=true;}$out=array_keys($out);sort($out,SORT_STRING);return $out;}
    private static function slug(string $value): string {$n=self::normalizeExact(str_replace('-',' ',$value));return trim(str_replace(' ','-',$n),'-');}
}
