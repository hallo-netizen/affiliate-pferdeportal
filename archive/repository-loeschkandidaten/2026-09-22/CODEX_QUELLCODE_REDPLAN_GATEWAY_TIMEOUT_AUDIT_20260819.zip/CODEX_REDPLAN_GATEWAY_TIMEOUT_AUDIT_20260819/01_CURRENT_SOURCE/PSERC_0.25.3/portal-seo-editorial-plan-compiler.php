<?php
/**
 * Plugin Name: Portal SEO Redaktionsplan Compiler
 * Description: Schreibfreie, fail-closed geprüfte Metadaten-Vorschau mit exakt fünf skalaren Feldern: Titel, Zielkeyword, Kategorie, Beitragsart und Planplatz. Erzeugt weder Text noch HTML und verändert weder Textproduktion, Design noch Inhalte.
 * Version: 0.25.3
 * Requires PHP: 8.0
 * Author: Workflow Automation
 */
if (!defined('ABSPATH')) { return; }

define('PSERC_VERSION', '0.25.3');
define('PSERC_BUILD','0.25.3-redaktionsplan-bulk-read-rootfix-ppm679');
define('PSERC_DIR', __DIR__ . '/');

foreach ([
    'includes/class-pserc-stable-json.php',
    'includes/class-pserc-plan-slot-identity.php',
    'includes/class-pserc-package-integrity.php',
    'includes/class-pserc-production-reader.php',
    'includes/class-pserc-seo-source-binding.php',
    'includes/class-pserc-seo-reader.php',
    'includes/class-pserc-portal-structure-gate.php',
    'includes/class-pserc-title-rule-compatibility.php',
    'includes/class-pserc-title-gate.php',
    'includes/class-pserc-journal-planning-gate.php',
    'includes/class-pserc-assignment-consistency-gate.php',
    'includes/class-pserc-semantic-assignment-gate.php',
    'includes/class-pserc-language-gate.php',
    'includes/class-pserc-editorial-outcome-gate.php',
    'includes/class-pserc-technical-strand.php',
    'includes/class-pserc-editorial-strand.php',
    'includes/class-pserc-portal-topic-evidence-gate.php',
    'includes/class-pserc-target-keyword.php',
    'includes/class-pserc-existing-content-reader.php',
    'includes/class-pserc-semantic-duplicate-gate.php',
    'includes/class-pserc-slot-allocator.php',
    'includes/class-pserc-metadata-boundary.php',
    'includes/class-pserc-ppm-intake-bridge.php',
    'includes/class-pserc-release-aggregator.php',
    'includes/class-pserc-ppm-bypass-guard.php',
    'includes/class-pserc-workflow-supervisor.php',
    'includes/class-pserc-production-trigger.php',
    'includes/class-pserc-compiler.php',
    'includes/class-pserc-admin.php',
    'includes/class-pserc-plugin.php',
] as $relative) {
    require_once PSERC_DIR . $relative;
}

// Absichtlich kein Aktivierungs-, Deaktivierungs-, Cron-, REST- oder Migrationshook.
PSERC_Plugin::init();
