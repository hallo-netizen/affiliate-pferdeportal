# 0.25.2 – Journal Live-Compiler-Readthrough

- Der read-only SEO-Adapter übernimmt den bereits von PSTE erzeugten `journal_routing`-Beleg ausschließlich für `Journal` unverändert in den internen Compiler-Kandidaten. Nicht-Journal-Normalisierungen bleiben byte-identisch zu 0.25.1.
- Der technische Target-Keyword-Gate verwendet für Journal den ausdrücklich separat erhaltenen `raw_keyword_preserved`-Wert als Raw-Query-Bindung; fehlt er, bleibt der bisherige Fallback unverändert. FAQ/Beratung/Vergleich/Pflege behalten exakt die bisherige Reihenfolge.
- Der Journal-Live-Term-Check vergleicht Kategorie-Namen weiterhin exakt, dekodiert aber auf beiden Seiten HTML-Entities (`&amp;` ↔ `&`) vor dem Vergleich. ID, Taxonomie und Slug müssen weiterhin exakt stimmen; keine unscharfe Zuordnung.
- Der Portal-Evidence-Gate erhält ausschließlich die unveränderte upstream PSTE-Metadatenansicht. Erst innerhalb PSERC erzeugte technische/editoriale Diagnoseblöcke werden vor diesem Boundary-Check explizit entfernt; ihre eigenen Gates bleiben vollständig aktiv. Damit kann ein legitimer signierter Journal-Bridge-Beleg nicht selbst als verbotener Inhalts-Payload fehlklassifiziert werden.
- Keine neue Zuweisungslogik, kein Runtime-Reassignment, kein Inhalts-/Format-Handoff, kein Write und keine Publish-Freigabe.
- JSON-Downloads der Metadaten-Vorschau und des Produktions-Readbacks erhalten `0.0`/Float-Typen mit `JSON_PRESERVE_ZERO_FRACTION`, damit die bereits vorhandenen Stable-JSON-Selbsthashes nach Download/Upload byte- und typstabil verifizierbar bleiben. Keine Änderung der Daten oder Gates.
