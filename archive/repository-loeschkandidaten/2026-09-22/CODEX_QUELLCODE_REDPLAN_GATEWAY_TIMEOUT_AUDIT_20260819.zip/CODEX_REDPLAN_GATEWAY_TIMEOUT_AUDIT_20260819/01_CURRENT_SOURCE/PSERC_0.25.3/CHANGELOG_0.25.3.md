# PSERC 0.25.3 – Redaktionsplan Bulk-Read Rootfix

- Rein technischer Read-Path-Rootfix; Compilerregeln und fachliche Ausgaben bleiben unverändert.
- Bestehender WordPress-Inhaltsbestand: Kategoriebeziehungen werden gebündelt gelesen statt `wp_get_post_categories()` pro Beitrag.
- Fail-safe Rückfall auf den bisherigen WordPress-Lesepfad, falls die gebündelte Core-Tabellenabfrage nicht verfügbar ist.
- Keine Änderung an Titel-, Keyword-, Artikeltyp-, Kategorie-, Slot-, Exact-Five-, Inhalts-, Design-, PPM- oder Publish-Entscheidung.
- Auch kategorielose Beiträge bleiben im erfolgreichen Bulk-Pfad; ein leerer Category-Treffer löst keinen per-Post-Fallback aus.
