# PSERC 0.25.0 – signed Journal normal-draft release binding

- Akzeptiert Journal ausschließlich bei vollständig selbstkonsistentem, signiertem PPM-6.7.9-Journal-Release.
- Verlangt 9 Journal-Kategorien und 45 signierte Journal-Slots; die 40 historischen Journal/Wissen-IDs bleiben als migrierte Identität nachweisbar.
- `Pferdewissen & Grundlagen` muss den signierten kanonischen Slug `pferdewissen-grundlagen` besitzen.
- Journal-Slots werden erst nach normalem PSTE/Sandbox-Reentry und der bestehenden PSERC-Gate-Kette für den normalen Metadata-Handoff freigegeben.
- Kein Direktwrite, kein Parallelplan, kein Publish; PPM-interne 1–4/1-pro-Typ-Grenzen bleiben unverändert.
