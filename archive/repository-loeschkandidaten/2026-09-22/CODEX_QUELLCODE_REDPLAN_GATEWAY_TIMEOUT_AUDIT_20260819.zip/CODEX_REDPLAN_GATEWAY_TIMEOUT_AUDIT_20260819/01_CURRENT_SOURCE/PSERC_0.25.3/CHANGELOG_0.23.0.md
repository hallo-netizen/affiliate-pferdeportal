# 0.23.0 – Beitragsart Journal: additive Planungsregistrierung

- `Journal` als eigene Planungs-Beitragsart registriert; Frage oder Aussage im Titel erlaubt.
- unveränderte signierte Portal Production Machine 6.7.9 bleibt verbindlich und wird nicht verändert.
- die bereits vorhandenen 40 gesperrten Journal/`Wissen`-Planplätze in PPM 6.7.9 werden read-only als bestehende kanonische Planidentitäten erkannt; keine Parallelplanung und keine neue Plan-ID.
- `Journal` bleibt in diesem Schritt bewusst außerhalb der normalen Draft-Freigabe; automatische Journal-Routinglogik folgt separat.
- `Pferdewissen & Grundlagen` ist mit Slug `pferdewissen-grundlagen` als pending Runtime-Bindung registriert; Term-ID wird nicht geraten.
- bestehende Beitragstypen und deren PPM-Freigabe bleiben unverändert.
- Textmaschine, Workflow, Inhalt, HTML und Design bleiben unverändert.
