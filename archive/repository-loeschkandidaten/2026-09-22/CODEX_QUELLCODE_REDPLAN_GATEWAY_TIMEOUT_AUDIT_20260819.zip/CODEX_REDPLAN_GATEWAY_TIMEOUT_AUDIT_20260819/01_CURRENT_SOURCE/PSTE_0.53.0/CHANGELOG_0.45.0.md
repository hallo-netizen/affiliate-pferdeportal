# PSTE 0.45.0 – Journal Routing Schritt 2

- additive Journal-Routinglogik ausschließlich nach Fehlschlag des unveränderten bestehenden Produktfamilienpfads
- read-only Laufzeitauflösung der Journal-Kategorie über erlaubte Slug-Aliase; keine Kategorie wird angelegt oder verändert
- Sandbox verwendet denselben bestehenden Reentry-Mechanismus; kein zweiter Produktionsweg
- Frage- und Aussagetitel für Journal bleiben erlaubt
- andere Beitragsarten, Textmaschine, Workflow, Inhalt, HTML und Design unverändert
- Journal erzeugt weiterhin nur SEO-Metadaten; Draft-Freigabe bleibt außerhalb dieses Schritts gesperrt

- Journal-spezifisch sind Frage- oder Aussagetitel frei; Doppelpunkte werden entsprechend dem Journal-Vertrag zugelassen. Andere Beitragstypen bleiben unverändert.
