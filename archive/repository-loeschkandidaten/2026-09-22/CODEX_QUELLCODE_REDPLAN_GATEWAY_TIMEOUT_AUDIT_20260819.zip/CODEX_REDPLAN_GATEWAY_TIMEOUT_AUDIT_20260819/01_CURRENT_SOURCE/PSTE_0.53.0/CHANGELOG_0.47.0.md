# PSTE 0.47.0 – Journal Live-Reentry und request-begrenzter Portalabgleich

- Schließt die echte Live-Lücke zwischen bereits erfolgreichem Journal-Routing und Themenpool-Freigabe: Journal wird nur bei vollständig nachgewiesenem `PSTE_JOURNAL_ROUTER_V1` + `PSTE_JOURNAL_ROUTING_CONSENSUS_V1` + aktuellem Normal-Path-PASS als `AUTO_RESOLVED` behandelt. Ein bloßer Typname oder eine manuelle Kategorie reicht ausdrücklich nicht.
- Der bereits vorhandene Portal-Kontextjob wird auf der Übersicht automatisch über einzelne request-begrenzte AJAX-Batches bis `COMPLETE` fortgesetzt. Baseline-Capture selbst bleibt leichtgewichtig und führt weiterhin keinen schweren Kontextbatch synchron aus. Der bestehende manuelle Fortsetzen-Button bleibt als Fallback erhalten.
- Für den bereits fachlich als Journal/Pferde-Thema belegten Titelpfad wird ausschließlich die deutsche Nominalschreibweise `Pferde` in Titel- und Target-Keyword-Oberfläche normalisiert. Raw Query, SEO-Evidenz und Suchvolumen bleiben byte-identisch; es findet keine fachliche Umdeutung statt.
- Keine neue fachliche Workflowstufe, kein neuer Nutzerentscheid, keine Provider-Aufrufe, kein Artikel-/Taxonomie-/Text-/HTML-/Design-Write.
- FAQ/Beratung/Vergleich/Pflege und alle nicht-Journal-Statusregeln bleiben unverändert.
- PPM bleibt unverändert. Der zugehörige PSERC-Companion-Fix 0.25.2 liest lediglich den bereits von PSTE erzeugten Journal-Routing-Beleg durch; er erzeugt keine neue Zuweisung.
