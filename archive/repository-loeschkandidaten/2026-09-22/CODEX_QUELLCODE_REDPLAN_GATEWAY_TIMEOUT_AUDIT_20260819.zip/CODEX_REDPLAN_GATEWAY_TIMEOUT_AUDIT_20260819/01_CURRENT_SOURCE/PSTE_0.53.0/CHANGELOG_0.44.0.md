# 0.44.0 – Beitragsart Journal registriert

- `Journal` additiv als Typ auf Registry-Ebene registriert, ohne Produktfamilien/Kategorien automatisch zuzuordnen;
- Journal-Titel dürfen Frage oder Aussage sein; keine Titelschablone;
- bestehende FAQ-/Beratung-/Vergleich-/Pflege-/weitere Typregeln bleiben außerhalb `Journal` unverändert;
- automatische Journal-Routinglogik ist in diesem Schritt bewusst noch nicht aktiviert;
- neue Kategorie `Pferdewissen & Grundlagen` mit Slug bekannt, Term-ID pending und nicht geraten;
- kein Inhalt/HTML/Design/Textmaschinen-Write.
