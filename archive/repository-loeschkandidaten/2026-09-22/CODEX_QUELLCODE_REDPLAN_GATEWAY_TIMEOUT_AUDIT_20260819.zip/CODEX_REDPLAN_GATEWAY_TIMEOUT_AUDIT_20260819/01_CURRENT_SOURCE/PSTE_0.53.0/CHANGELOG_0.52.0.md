# Portal SEO Themenengine 0.52.0

## Dynamic Context Rebase Rootfix

- Behebt den live belegten V7-Blocker `PSTE_CONTEXT_REFRESH_STALE_FINAL_INVENTORY`.
- Ein nach erfolgreicher Sandbox-Migration verändertes read-only Inventory/Redaktionsplan-Umfeld löst keine erneute Sandbox-Migration aus.
- V7 BLOCKED am finalen Inventory-/Plan-Gate wird kontrolliert in V8 übernommen; der vorhandene record-lokale 549er Sandbox-Store und die abgeschlossene komponentenlokale Sandbox-Bindung bleiben erhalten.
- Nur der technische Portal-Context wird gegen die sicher neu gebundene dynamische Baseline neu berechnet. Strukturänderungen bleiben fail-closed.
- Maximal drei automatische dynamische Rebase-Zyklen; wiederholte Drift blockiert mit eigenem Code statt Endlosschleife.
- Lokale Sandbox-Planner-Abhängigkeiten prüfen zusätzlich ihren beobachteten Inventory-Hash und bleiben bei Drift individuell fail-closed.
- AJAX zeigt bei HTTP 400 nun den tatsächlichen serverseitigen `error_code` statt nur `PSTE_CONTEXT_AJAX_FAILED_HTTP_400`.
- Keine Änderungen an Artikelinhalt, Promptlogik, Titelbildung, Artikeltyp-/Kategorieentscheidung, PSERC, PPM, HTML, Design oder Publish.
