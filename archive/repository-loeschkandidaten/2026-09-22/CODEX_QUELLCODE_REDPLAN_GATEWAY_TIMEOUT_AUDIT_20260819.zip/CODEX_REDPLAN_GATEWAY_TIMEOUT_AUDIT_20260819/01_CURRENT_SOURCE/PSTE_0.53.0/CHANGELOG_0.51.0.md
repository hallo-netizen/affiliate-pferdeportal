# 0.51.0 – Record-local Sandbox recovery

Technical infrastructure only. Editorial, title, article-type, category, planning, content, design and publish semantics are unchanged.

- Adds lossless request-bounded migration of the legacy monolithic Sandbox option into record-local WordPress options.
- Legacy Sandbox remains read-only rollback authority and is not deleted by the migration.
- Verifies the reconstructed 549-record registry against the legacy canonical registry hash before activation.
- Replaces global Sandbox baseline invalidation with record/component-local technical binding fingerprints.
- Preserves an already completed V6 562-topic Context run and restarts only the failed Sandbox technical boundary.
- Adds fenced option-backed Context leases for reload/AJAX/Cron concurrency safety.
- Adds a technical fatal-diagnostic ring without article, keyword, prompt or payload bytes.
- Shows bounded Sandbox migration/verification progress in the existing overview auto-sequence.
- Hashes the raw legacy Sandbox option in bounded 1 MiB windows before and after migration; no request asks MySQL/PHP to hash or decode the complete legacy option.
