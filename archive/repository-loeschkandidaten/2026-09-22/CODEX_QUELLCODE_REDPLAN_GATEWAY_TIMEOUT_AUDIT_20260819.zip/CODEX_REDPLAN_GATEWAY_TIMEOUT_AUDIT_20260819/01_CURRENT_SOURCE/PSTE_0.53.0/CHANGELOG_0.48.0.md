# PSTE 0.48.0 – Request-Budget-Rootfix für Portalabgleich und Compiler-Read

## Ursache

Die bisherigen Schutzmaßnahmen begrenzten zwar die Anzahl der pro Portalabgleich verarbeiteten Themen, aber nicht alle teuren Arbeiten innerhalb desselben HTTP-Requests. Dadurch konnten weiterhin lange Requests entstehen:

- der Payload-Reparaturpfad konnte vor dem eigentlichen Batch den gesamten Themenpool prüfen,
- WordPress-Inventar und Redaktionsplan wurden in jedem Context-Batch erneut vollständig erzeugt,
- Context-Refresh und Sandbox-Binding konnten in demselben Request zusammenfallen,
- unveränderte Sandbox-Bindings konnten den kompletten Sandbox-Optionsspeicher erneut schreiben,
- der Compiler-Read `allCandidates()` lud Relationsdaten pro Thema einzeln (N+1), obwohl bereits ein semantisch identischer Bulk-Read existierte,
- selbst der globale Fail-Closed-Pfad schrieb im Fehlerfall alle Themen-Payloads einzeln neu und konnte dadurch einen ursprünglichen Fehler in einen zusätzlichen Timeout/Invalid-JSON-Fehler verwandeln.

Das sind technische Request-/Read-Pfadfehler. Editoriale Regeln, Journal-Routing, Produktionsfreigaben und der bestehende Master-Workflow werden nicht verändert.

## Änderung

- Context-Refresh V4 läuft strikt phasenweise und request-begrenzt:
  1. bestehende Payload-Integritätsprüfung in Batches von maximal 25,
  2. Portal-Kontext in Batches von maximal 10,
  3. Sandbox-Bindings separat in Batches von maximal 3,
  4. einmaliger frischer Live-Baseline-Gate vor `COMPLETE`.
- Der Context-Job bindet einen unveränderlichen, hashgesicherten Inventar-/Redaktionsplan-Snapshot an den Baseline-Lauf. Eine Änderung während des Laufs blockiert am finalen Live-Gate statt mit veralteten Daten freizugeben.
- Ein laufender Legacy-V1/V2/V3-Context-Job wird nicht unter gemischten Regeln fortgesetzt, sondern über denselben bestehenden Portalabgleich mit V4 von Cursor 0 neu aufgenommen.
- `PSTE_Repository::allCandidates()` verwendet den bereits vorhandenen Bulk-Relationsread statt zwei zusätzlichen SELECTs je Thema. Ausgabe und Entscheidungslogik bleiben identisch.
- Sandbox-Registry wird pro Request nur einmal vollständig verifiziert. Semantisch unveränderte Bindings erzeugen kein Archiv und keinen vollständigen Options-Write.
- Inventar-Snapshot wird innerhalb desselben PHP-Requests memoisiert; es gibt keinen requestübergreifenden Cache.
- Der globale Context-Fail-Closed setzt die wirksamen Statusspalten mit genau einem Bulk-UPDATE auf `BLOCKED`; der autoritative Fehlercode bleibt am Context-Job. Damit existiert auch im Fehlerpfad keine 562er JSON-Rewrite-Schleife mehr.
- Der Browser-Abgleich hat einen expliziten 20-Sekunden-Transport-Abbruch und liefert bei Nicht-JSON-Antworten HTTP-Status und Antwortlänge als Diagnosecode.

## Harte Grenzen

- keine Änderung an Beiträgen, Kategorien, URLs, Yoast, Design, PPM oder Textmaschine,
- keine direkte Produktion und kein Publish,
- kein Bypass von Sandbox, Exact Five, Supervisor, PPM-Draft oder Readback/Hash,
- unbekannte oder veränderte Baseline bleibt fail-closed.
