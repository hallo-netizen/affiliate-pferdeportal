# PSTE 0.50.0 — Portalabgleich Architektur-Rootfix

- Root cause: legacy re-entry no longer calls the heavy `start()` path inside AJAX.
- Fresh start no longer rebuilds inventory/editorial-plan/sandbox state synchronously a second time.
- Payload audit remains max 10 rows and never uses candidate-evidence reconstruction.
- Inventory, editorial plan, article-type registry and Sandbox-ID discovery are isolated into separate hash-bound phases.
- Context index is materialized once into family shards; context batches load only the required family shard.
- Context batch max 5, Sandbox batch max 3.
- Current 0.49 V5 and prior V4/V3/V2/V1 jobs are adopted into V6 without continuing mixed state.
- Existing context evaluator, Journal router, article-type registry logic, title/editorial/content/design paths remain unchanged.
- No production/publish/content/design write authority added.
- Final freshness verification is split into isolated structure, inventory and editorial-plan requests; no final request recomputes all three global snapshots together.
