# PSTE 0.53.0 – Redaktionsplan Bulk-Read Rootfix

- Rein technischer Read-Path-Rootfix für den SEO-Redaktionsplan.
- `PSTE_Snapshot::inventory()` behält Auswahl, Sortierung, Hash-/Inhaltssemantik unverändert, lädt Kategoriebeziehungen und die zwei PPM-Identitätsmetafelder jedoch gebündelt statt pro Beitrag.
- Fail-safe Rückfall auf den bisherigen WordPress-Lesepfad, falls die gebündelte Core-Tabellenabfrage nicht verfügbar ist.
- Keine Änderung an Titel-, Artikeltyp-, Kategorie-, Prompt-, Content-, Design-, Exact-Five-, PPM- oder Publish-Logik.
- Query-Budget des Inventory-Readbacks wird unabhängig von der Beitragszahl auf den Bulk-Pfad begrenzt; fachliche Snapshot-Felder bleiben byte-semantisch identisch.
