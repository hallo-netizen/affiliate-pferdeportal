# Portal SEO Themenengine 0.49.0

Technischer Architektur-Recovery des bestehenden Journal-fähigen Workflows.

- Keine Änderung an Journal-Routing, Artikeltypen, Kategorien, Titel-, Intent-, Editorial-, Qualitäts-, Exact-Five- oder Compiler-Read-Regeln.
- Normaler Portalabgleich führt keine historische Candidate-Evidence-Payload-Rekonstruktion mehr innerhalb eines AJAX-Requests aus.
- Payload-Integrität ist ein reiner, request-begrenzter Audit (max. 10 Zeilen); defekte Zeilen werden einzeln fail-closed quarantänisiert, Originalbytes bleiben erhalten.
- Snapshot-Bundle wird erst nach Abschluss des Payload-Audits geladen; damit entfällt die wiederholte große Bundle-Materialisierung in der ersten Phase.
- Article-Type-Registry wird einmal an das immutable Snapshot-Bundle gebunden und in Sandbox-Batches wiederverwendet.
- Context-Batch max. 5, Sandbox-Batch max. 3; laufende oder durch den alten HTTP-500 blockierte V4-/Recovery-V4-Jobs werden ohne Cleaner sauber als V5 neu aufgenommen.
- Diagnose zeigt Phase; Browser-Guard ist auf lange, strikt sequenzielle Bounded-Läufe ausgelegt.
- Keine Post-/Term-/Postmeta-/Textmaschinen-/Design-Schreibschnittstelle hinzugefügt.
