# Portal SEO Themenengine 0.48.0

## Aufgabe

Die Engine erledigt pro ausgewählter Themenfamilie genau den praktischen SEO-Vorlauf:

1. Longtail-Begriffe recherchieren.
2. Begriffe auf die ausgewählte Portal-Themenfamilie begrenzen.
3. Aus brauchbaren Longtails semantisch klare Titel bilden.
4. Den Titel genau einer bereits vorhandenen Portalkategorie zuordnen.
5. Gegen veröffentlichte Beiträge, Entwürfe und den Redaktionsplan des eigenen Portals auf Doppelungen prüfen.
6. Nur freigabefähige SEO-/Planungsmetadaten im eigenen Themenpool speichern.

## Bedienung

Ein Lauf wird im Backend genau einmal gestartet. Der Browser führt danach automatisch drei kurze, getrennte Providerabschnitte und die lokale Auswertung aus. Es gibt im normalen Erfolgsfall keine manuelle Einzelschrittfolge, keine Google-Live-SERP-Prüfung und keine WP-Cron-Abhängigkeit.

Der Lauf verwendet genau drei DataForSEO-Labs-Abfragen:

- Keyword Suggestions
- Related Keywords
- Keyword Ideas aus höchstens 20 priorisierten, bereits gefundenen Begriffen

Jede kostenpflichtige Abfrage läuft in einem eigenen begrenzten Serverrequest. Das verhindert einen langen synchronen Mehrfachbatch. Das Ergebnis jeder Quelle wird unmittelbar gespeichert, bevor Kostenbuchung und nächster Abschnitt folgen.

Bei einem eindeutig gemeldeten Provider- oder lokalen Vorprüffehler hält der Lauf sicher an und kann nach Behebung ausdrücklich einmal fortgesetzt werden. Bei unbekanntem Transportausgang wird dieselbe möglicherweise berechnete Anfrage niemals automatisch erneut gesendet.

## Harte Systemgrenze

Die Engine erzeugt oder verändert niemals:

- Artikeltext oder HTML,
- Überschriften, Tabellen, Listen oder Links,
- Design, CSS oder Formatierung,
- Qualitätslogik der Textmaschine,
- Beiträge, Kategorien, URLs oder Yoast-Daten.

Sie schreibt ausschließlich in ihre eigenen SEO-Engine-Speicher. Die Textmaschine bleibt alleinige Instanz für Inhalt, Gestaltung und Qualität.

## Kategoriezuordnung

Eine Zuordnung ist nur zulässig, wenn genau eine bestehende Blattkategorie mit derselben Themenfamilie und demselben Beitragstyp vorhanden ist. Fehlt die Kategorie oder ist sie mehrdeutig, wird der Kandidat blockiert. Es wird keine Kategorie erzeugt und keine Ersatzkategorie geraten.

## Titelbildung

Die Titelbildung ist deterministisch und auf Metadaten begrenzt. Beispiele:

- `Frieren Pferde unter Regendecken` → `Frieren Pferde unter Regendecken?` → FAQ Regendecken
- `Regendecken waschen` → `Regendecken richtig waschen` → Pflege Regendecken
- `Regendecke oder Winterdecke` → `Regendecke oder Winterdecke im Vergleich` → Vergleich Regendecken
- `Regendecken Kosten` → `Regendecken Preise und Kosten im Überblick` → Kosten Regendecken
- `Regendecken für ungeschorene Pferde` → unverfälschter Longtail-Titel → Beratung Regendecken

Fragen werden ausschließlich FAQ zugeordnet. Veraltete Jahresbegriffe, rein transaktionale Suchbegriffe, unklare Mehrfachsignale und interne Doppelungen werden fail-closed blockiert.

## Portalstruktur und Status

Die Portalhierarchie wird nicht aus einer erfundenen Kategorieverschachtelung abgeleitet. Maßgeblich sind der echte WordPress-Seitenbaum bis zur Produktseite und die darunter logisch zugeordnete, technisch flache WordPress-Themenkategorie. Der Struktur-Digest ist zeitunabhängig; sachfremde Kategorien werden dokumentiert, verändern aber nicht den SEO-Strukturstand.

Seit Version 0.10.6 bindet die Engine die elf am 30.07.2026 bewusst umbenannten Kategorien über explizite, hashgebundene Namensaliasse an ihre unveränderten Slugs, Produktseiten und Beitragsarten. Die Kategorien bleiben mit ihren aktuellen sichtbaren Namen nutzbar; weder Kategorien noch Beiträge werden geschrieben. Ein unbekannter Name auf einem geschützten Slug wird präzise pro Kategorie blockiert und darf nicht auf eine dynamische, möglicherweise falsche Produktseite ausweichen. Der reale Longtail-Lauf bleibt Teil der anschließenden Live-Abnahme.

## Datensammlung und spätere Beitragstypen

Alle innerhalb der ausgewählten Themenfamilie relevanten Rohbegriffe, Schreibvarianten, konservativ erkannten Synonyme, Quellen, Einzelmesswerte und Prüfentscheidungen werden im eigenen SEO-Themenpool gespeichert. Pro Lauf werden bis zu 300 relevante Kandidatengruppen verarbeitet; nicht freigabefähige Begriffe bleiben als Prüf- oder Discovery-Datensatz erhalten. Neue Beitragstypen werden aus der realen Taxonomie gelesen. Der Compiler hält sie nur dann zurück, wenn die unveränderte Textmaschine den Typ noch nicht freigegeben hat.

## Kategorien-Quarantäne

Eine nicht eindeutig auflösbare oder doppelte Kategorie wird einzeln gesperrt und mit Term-ID, Name, Slug und Grund ausgewiesen. Sie wird weder recherchiert noch an den Compiler übergeben. Alle anderen eindeutig aufgelösten Kategorien bleiben nutzbar. Nur echte globale Strukturdefekte – etwa doppelte Term-IDs, fehlende Seiteneltern, Seitenzyklen oder ein vollständig leerer Produktionsbestand – blockieren die gesamte Baseline.


## Datenbank- und Wiederaufnahme-Sicherheit 0.10.8

Alle direkten Datenbankschreibpfade der Engine laufen über eine gemeinsame, fail-closed arbeitende Schreibgrenze. Vor jedem Schreiben werden Datenfelder und Formatangaben sowie WHERE-Felder und WHERE-Formate exakt gezählt. Schreibziele außerhalb der eigenen `pste_`-Tabellen werden blockiert; Beiträge, Post-Meta, Kategorien und Term-Meta sind als Schreibziel technisch nicht zugelassen.

Der eigene JSON-Speicher wird mit einem sofort entfernten Probeeintrag über INSERT und denselben UPDATE-Pfad zweimal geprüft. Ein durch den früheren 14-Felder-/13-Formate-Fehler zu `"0"` beschädigter Themenpool-Datensatz wird deterministisch aus bereits vorhandenen eigenen Kandidatendaten rekonstruiert. Bereits bezahlte, gespeicherte Providerquellen werden dabei nicht erneut abgerufen. Fehlt eine eindeutige Rekonstruktionsquelle, wird nur das betroffene Thema fail-closed quarantänisiert; alle anderen Themen bleiben nutzbar.

Die Engine erzeugt keine Inhalts-, Format- oder Qualitätsdaten für die Textmaschine. Beiträge, HTML, Überschriften, Tabellen, Listen, Links, CSS, Design und Qualitätslogik werden weder direkt geschrieben noch indirekt als Übergabedaten geliefert.


## Schema 12 / Altbestands-Neuklassifizierung 0.10.13

Die manuell gestartete sichere Migration klassifiziert den bereits gespeicherten Themenpool ohne neue Providerabfragen neu. Legacy-Familienschlüssel werden anhand der aktuellen, read-only gelesenen Portalstruktur aufgelöst. Vor jeder Artikelart- und Kategorieentscheidung muss der rohe Suchbegriff die konkrete Themenfamilie belegen; numerische Familien wie „2er Pferdeanhänger“ verlangen zusätzlich den Zahlbezug. Sachfremde Altbegriffe bleiben als Discovery-/Prüfdatensatz gespeichert, werden aber nicht an den Compiler freigegeben. Der Backfill schreibt ausschließlich in die eigenen `pste_`-Tabellen und erzeugt keine Artikel-, Inhalts-, Design-, Format- oder Qualitätsdaten.

## Familienidentität V2 und Bestandsaudit 0.11.0

Version 0.11.0 ergänzt eine eigenständige, versionierte Identität ausschließlich für die Familien- und Kontextbindung. Der globale Legacy-Normalizer und die vorhandenen Legacy-Identitäten bleiben unverändert.

Die V2-Bindung unterscheidet getrennt:

- den Sachkopf, der nur als exaktes Token oder kontrollierter rechter Kompositumkopf gelten darf;
- den Portal-/Einsatzkontext;
- verpflichtende und optionale Merkmale;
- explizite Ausschlusskonzepte;
- numerische und einheitengebundene Diskriminatoren;
- konkurrierende Familien und Zweige.

Dadurch können bedeutungsgleiche Formen wie `Alu-Pferdeanhänger`, `Pferdeanhänger aus Aluminium` und `Aluanhänger für Pferde` derselben Familie zugeordnet werden. Zubehörbegriffe wie `Anhängerkupplung`, `Anhängerkamera` und `Pferdedeckenhalter` bleiben wegen ihres anderen rechten Kompositumkopfs ausgeschlossen.

### Kontrollierter Bestandsweg

Unter **SEO Themenengine → Einstellungen** kann ein vollständiger **V2-Bestandsaudit (Quellbestand schreibfrei)** gestartet werden. Dabei wird zuerst ein neuer, einzelner Live-Snapshot aller gespeicherten Longtails und zugehörigen PSTE-Tabellen erstellt. Der Quellbestand wird nicht verändert; gespeichert wird ausschließlich das eigene PSTE-Auditprotokoll.

Der Audit ordnet jede gespeicherte Zeile einer festen Klasse zu:

- `UNCHANGED`
- `MOVE_UNAMBIGUOUS`
- `NEWLY_ELIGIBLE`
- `NEWLY_BLOCKED`
- `CONFLICT_REVIEW`
- `ORPHANED`
- `HASH_COLLISION`

Ein Apply ist standardmäßig technisch gesperrt. Er ist nur möglich, wenn eine externe Freigabedatei gleichzeitig an den exakten Dry-run-, Snapshot-, Legacy-Registry- und V2-Registry-Hash gebunden ist, `CLAUDE_DRY_RUN_PASS` enthält und jede freigegebene Änderungs-ID einzeln nennt. Ein Import startet niemals automatisch einen Apply.

Der Apply darf ausschließlich eindeutig freigegebene interne PSTE-Zuordnungen aktualisieren. Rohkeywordtexte werden vor und nach jedem Schreibvorgang gehasht. Veröffentliche Artikel und Entwürfe werden nur read-only als Artikelwächter erfasst. Ein exakter, idempotenter Rollback ist Bestandteil desselben Plugins.

Ein neuer Dry-run ist gesperrt, solange ein Apply noch nicht zurückgerollt wurde. Nach einem erfolgreichen Rollback beginnt ein neuer Auditzyklus ohne alte Autorisierung.

## 0.18.0: End-to-End-Dualstrang
Rohkeywords bleiben erhalten. Automatische Metadatenfreigabe setzt einen getrennten technischen und redaktionell-semantischen PASS voraus. Blockierte/unklare Fälle gehen in die bestehende Sandbox und können erst nach Relevanzklärung, Normalisierung, erneuter aktueller Strukturprüfung und vollständigem Reentry in den Normalweg wieder freigegeben werden. Echte Strukturlücken bleiben gespeichert, erhalten einen nicht anwendenden Strukturvorschlag und werden regelmäßig intern neu geprüft. Artikelinhalt, Textmaschinenlogik und Design bleiben außerhalb dieses Plugins.

## 0.23.0 – systemweite Fehlerisolation und historische Zustandsautorität

Der aktuelle Workflow behandelt Portalrelevanz als erste fachliche Entscheidung. Ungeklärte oder nicht ausreichend belegte Keywords werden nicht gelöscht, sondern kontrolliert in Sandbox/Review gehalten. Ein kandidatenbezogener Sandboxfehler darf andere Kandidaten nicht blockieren; nur echte globale Infrastruktur- oder Integritätsfehler blockieren den Gesamtlauf.

Historische abgeleitete Felder wie Pfad-, Familien- oder READY-Status sind nach einer Regeländerung niemals automatisch aktuelle Autorität. Sie werden vollständig neu berechnet oder gegen eine explizite aktuelle Provenienz gebunden. Die einzige READY-Autorität ist der gemeinsame aktuelle Normalpfad.

Aktivierung und reine Seitenaufrufe sind migrationsfrei. Eine Migration wird ausschließlich ausdrücklich über den sicheren Migrationsweg gestartet. Die Schutzgrenze bleibt unverändert: Dieses Plugin darf keine Artikelinhalte, HTML-, Design-, Format- oder Textmaschinenlogik erzeugen oder beeinflussen.

## 0.24.0 – request-bounded Safe Migration

Der sichere Upgradepfad ist ein dauerhafter, fortsetzbarer Job. Jede HTTP-Anfrage verarbeitet nur eine begrenzte Phase bzw. einen begrenzten Batch. Topic-Payload-Integrität, Rohkeyword-Baseline, redaktionelle Neuberechnung, Variantenermittlung, Finalisierung, Sandbox-Aufnahme und Finalverify sind getrennte, wiederaufnehmbare Grenzen. Ein Kandidatenfehler in der fachlichen Sandbox wird isoliert; Rohkeyword-, Storage-, Relations- und Sicherheitsgrenzen bleiben global fail-closed.

Die fachliche Reihenfolge bleibt unverändert: Portalrelevanz zuerst, danach Normalweg oder Sandbox. Die Sandbox ist ein vollständiger kontrollierter Prozesszweig und besitzt keinen direkten Produktionsweg. Der Compiler bleibt die einzige verbindliche READY-/Fünf-Feld-Grenze. Textmaschine, Produktionsmaschine, Inhalte und Design bleiben vollständig außerhalb des Schreibbereichs.
