<?php
if (!defined('ABSPATH')) { return; }
final class PSTE_Admin {
    private const PARENT='portal-seo-topic-engine';
    private const TABS=[
        'overview'=>['slug'=>'portal-seo-topic-engine','label'=>'Übersicht'],
        'topics'=>['slug'=>'portal-seo-topic-engine-topics','label'=>'Themenkarte'],
        'keywords'=>['slug'=>'portal-seo-topic-engine-keywords','label'=>'Keywords & Longtails'],
        'review'=>['slug'=>'portal-seo-topic-engine-review','label'=>'Themenprüfung'],
        'coverage'=>['slug'=>'portal-seo-topic-engine-coverage','label'=>'Abdeckung'],
        'priorities'=>['slug'=>'portal-seo-topic-engine-priorities','label'=>'Prioritäten'],
        'conflicts'=>['slug'=>'portal-seo-topic-engine-conflicts','label'=>'Konflikte'],
        'sandbox'=>['slug'=>'portal-seo-topic-engine-sandbox','label'=>'Semantic Sandbox'],
        'sources'=>['slug'=>'portal-seo-topic-engine-sources','label'=>'Datenquellen'],
        'settings'=>['slug'=>'portal-seo-topic-engine-settings','label'=>'Einstellungen'],
    ];

    public static function isOwnPageRequest(): bool {
        $page=isset($_GET['page'])?(string)$_GET['page']:'';
        if($page==='')return false;
        $allowed=[self::PARENT];
        foreach(self::TABS as $tab)$allowed[]=(string)($tab['slug']??'');
        return in_array($page,array_values(array_unique(array_filter($allowed,'strlen'))),true);
    }

    public static function init(): void {
        add_action('admin_menu',[self::class,'menu'],20);
        add_action('admin_notices',[self::class,'activeNotice'],20);
        add_action('admin_bar_menu',[self::class,'adminBar'],99);
        add_filter('plugin_action_links_'.plugin_basename(PSTE_DIR.'portal-seo-topic-engine.php'),[self::class,'pluginActionLinks']);
        $actions=['pste_retry_safe_migration'=>'retrySafeMigration'];
        if(PSTE_Plugin::isReady()){
            $actions=array_merge($actions,[
                'pste_save_settings'=>'saveSettings','pste_save_credentials'=>'saveCredentials','pste_capture_baseline'=>'captureBaseline',
                'pste_connection_test'=>'connectionTest','pste_export_overlay'=>'exportOverlay','pste_export_topic_map'=>'exportTopicMap',
                'pste_import_gsc'=>'importGsc','pste_save_gsc_client'=>'saveGscClient','pste_gsc_connect'=>'gscConnect',
                'pste_gsc_oauth_callback'=>'gscOauthCallback','pste_gsc_test'=>'gscTest','pste_gsc_save_property'=>'gscSaveProperty','pste_gsc_sync'=>'gscSync',
                'pste_gsc_disconnect'=>'gscDisconnect','pste_save_category_weights'=>'saveCategoryWeights','pste_import_editorial_plan'=>'importEditorialPlan',
                'pste_review_candidate'=>'reviewCandidate','pste_override_title'=>'overrideTitle','pste_process_context_batch'=>'processContextBatch','pste_repair_price_intents'=>'repairPriceIntents',
                'pste_family_v2_dry_run'=>'familyV2DryRun','pste_family_v2_export_dry_run'=>'familyV2ExportDryRun','pste_family_v2_import_authorization'=>'familyV2ImportAuthorization','pste_family_v2_apply'=>'familyV2Apply','pste_family_v2_rollback'=>'familyV2Rollback',
                'pste_sandbox_sync'=>'sandboxSync','pste_sandbox_export'=>'sandboxExport','pste_sandbox_review_relevance'=>'sandboxReviewRelevance','pste_sandbox_confirm_internal'=>'sandboxConfirmInternal',
            ]);
        }
        foreach($actions as $action=>$method)add_action('admin_post_'.$action,[self::class,$method]);
        add_action('wp_ajax_pste_safe_migration_start',[self::class,'safeMigrationStartAjax']);
        add_action('wp_ajax_pste_safe_migration_advance',[self::class,'safeMigrationAdvanceAjax']);
        if(PSTE_Plugin::isReady()){
            add_action('wp_ajax_pste_context_advance',[self::class,'contextAdvanceAjax']);
            add_action('wp_ajax_pste_research_start',[self::class,'researchStartAjax']);
            add_action('wp_ajax_pste_research_advance',[self::class,'researchAdvanceAjax']);
            add_action('wp_ajax_pste_research_cancel',[self::class,'researchCancelAjax']);
            add_action('wp_ajax_pste_breadth_research_start',[self::class,'breadthResearchStartAjax']);
            add_action('wp_ajax_pste_breadth_research_advance',[self::class,'breadthResearchAdvanceAjax']);
            add_action('wp_ajax_pste_sandbox_start',[self::class,'sandboxStartAjax']);
            add_action('wp_ajax_pste_sandbox_advance',[self::class,'sandboxAdvanceAjax']);
            add_action('wp_ajax_pste_sandbox_cancel_unknown',[self::class,'sandboxCancelUnknownAjax']);
        }
    }

    public static function menu(): void {
        add_menu_page('Portal SEO Themenengine','SEO Themenengine','manage_options',self::PARENT,[self::class,'pageOverview'],'dashicons-chart-area',58);
        add_submenu_page(self::PARENT,'Übersicht','Übersicht','manage_options',self::PARENT,[self::class,'pageOverview']);
        foreach(self::TABS as $key=>$tab){if($key==='overview')continue;add_submenu_page(self::PARENT,$tab['label'],$tab['label'],'manage_options',$tab['slug'],[self::class,'page'.ucfirst($key)]);}
    }
    public static function activeNotice(): void {
        if(!current_user_can('manage_options'))return;
        if(isset($_GET['page'])&&str_starts_with((string)$_GET['page'],'portal-seo-topic-engine'))return;
        $boot=PSTE_Plugin::bootStatus();
        $status=(string)($boot['status']??'PENDING');
        $label=$status==='READY'?'einsatzbereit':'aktiv, Datenmigration noch nicht ausgeführt';
        echo '<div class="notice notice-info"><p><strong>Portal SEO Themenengine ist '.esc_html($label).'.</strong> <a href="'.esc_url(admin_url('admin.php?page='.self::PARENT)).'">Themenengine öffnen</a></p></div>';
    }
    public static function adminBar($bar): void {if(current_user_can('manage_options'))$bar->add_node(['id'=>'pste-admin-bar','title'=>'SEO Themenengine','href'=>admin_url('admin.php?page='.self::PARENT)]);}
    public static function pluginActionLinks(array $links): array {array_unshift($links,'<a href="'.esc_url(admin_url('admin.php?page='.self::PARENT)).'">Öffnen</a>');return $links;}

    public static function pageOverview(): void {self::render('overview');} public static function pageTopics(): void {self::render('topics');}
    public static function pageKeywords(): void {self::render('keywords');} public static function pageCoverage(): void {self::render('coverage');}
    public static function pagePriorities(): void {self::render('priorities');} public static function pageConflicts(): void {self::render('conflicts');}
    public static function pageReview(): void {self::render('review');} public static function pageSandbox(): void {self::render('sandbox');} public static function pageSources(): void {self::render('sources');} public static function pageSettings(): void {self::render('settings');}

    private static function render(string $tab): void {
        PSTE_Auth::assertAdmin();echo '<div class="wrap pste-wrap"><h1>Portal SEO Themenengine <span style="font-size:14px;font-weight:400">'.esc_html(PSTE_VERSION).'</span></h1>';self::styles();self::notices();
        $boot=PSTE_Plugin::bootStatus();
        if(!PSTE_Plugin::isReady()){
            self::renderSafeBoot($boot);
            echo '</div>';
            return;
        }
        self::tabs($tab);
        echo '<div class="notice notice-info"><p><strong>Read-only gegenüber dem Portal:</strong> Die Engine schreibt nur in eigene <code>pste_</code>-Speicher. Keine Artikel, Kategorien, URLs, Yoast-Einstellungen oder Produktionsregeln werden verändert.</p></div>';
        try{
            match($tab){'topics'=>self::renderTopics(),'keywords'=>self::renderKeywords(),'review'=>self::renderReview(),'coverage'=>self::renderCoverage(),'priorities'=>self::renderPriorities(),'conflicts'=>self::renderConflicts(),'sandbox'=>self::renderSandbox(),'sources'=>self::renderSources(),'settings'=>self::renderSettings(),default=>self::renderOverview()};
        }catch(Throwable $e){
            self::renderOperationalFailure($e);
        }
        echo '</div>';
    }

    private static function renderOperationalFailure(Throwable $e): void {
        $raw=strtoupper(trim((string)$e->getMessage()));
        $code=(string)preg_replace('/[^A-Z0-9_:-]+/','_',$raw);
        $code=substr($code!==''?$code:'PSTE_ADMIN_PAGE_FAILED',0,160);
        echo '<div class="notice notice-error inline"><p><strong>Diese Themenengine-Seite wurde sicher blockiert.</strong><br>WordPress und das übrige Backend bleiben erreichbar.<br><strong>Fehlercode:</strong> <code>'.esc_html($code).'</code></p></div>';
    }

    private static function renderSafeBoot(array $boot): void {
        $status=(string)($boot['status']??'PENDING');
        $stage=(string)($boot['stage']??'NOT_STARTED');
        $code=(string)($boot['error_code']??'');
        $message=(string)($boot['message']??'');
        $class=$status==='BLOCKED'?'notice-error':'notice-warning';
        echo '<div class="notice '.esc_attr($class).' inline"><p><strong>Sicherer Pluginstart: '.esc_html($status).'</strong></p>';
        echo '<p><strong>Stufe:</strong> <code>'.esc_html($stage).'</code>';
        if($code!=='')echo '<br><strong>Fehlercode:</strong> <code>'.esc_html($code).'</code>';
        if($message!=='')echo '<br><strong>Meldung:</strong> '.esc_html($message);
        echo '</p><p>Die Themenengine führt in diesem Zustand keine Recherche, keinen Portalabgleich und keine Produktionsübergabe aus. Das WordPress-Backend bleibt erreichbar.</p></div>';
        echo '<section class="pste-box"><h2>Sichere Migration</h2>';
        $job=PSTE_Safe_Migration_Job::current();$public=is_array($job)?PSTE_Safe_Migration_Job::publicState($job):[];$jobStatus=(string)($public['status']??'NOT_STARTED');
        $buttonLabel=in_array($jobStatus,['RUNNING','PAUSED_ERROR'],true)?'Sichere Migration fortsetzen':'Sichere Datenmigration starten';
        echo '<button type="button" class="button button-primary" id="pste-safe-migration-start">'.esc_html($buttonLabel).'</button><div id="pste-safe-migration-feedback" class="notice notice-info inline" style="display:none;margin-top:12px"><p></p></div>';
        if($public){echo '<p><strong>Job:</strong> <code>'.esc_html($jobStatus).'</code> · <strong>Phase:</strong> <code>'.esc_html((string)($public['phase']??'')).'</code><br><strong>Legacy/Identität:</strong> '.esc_html((string)($public['legacy_identity_progress']??0)).' / '.esc_html((string)($public['legacy_identity_total']??0)).' · <strong>Editorial vorbereiten:</strong> '.esc_html((string)($public['editorial_prepare_progress']??0)).' / '.esc_html((string)($public['editorial_total']??0)).' · <strong>Editorial finalisieren:</strong> '.esc_html((string)($public['editorial_finalize_progress']??0)).' / '.esc_html((string)($public['editorial_total']??0)).' · <strong>Sandbox:</strong> '.esc_html((string)($public['sandbox_progress']??0)).' / '.esc_html((string)($public['sandbox_total']??0)).'</p>';}
        echo '<p><strong>Gespeichertes Schema:</strong> <code>'.esc_html((string)($boot['schema']??'')).'</code> · <strong>Pluginversion:</strong> <code>'.esc_html((string)($boot['version']??PSTE_VERSION)).'</code></p>';
        $cfg=wp_json_encode(['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('pste_safe_migration_ajax'),'job'=>$public,'redirect'=>admin_url('admin.php?page='.self::PARENT.'&safe_migration_complete=1')],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        echo '<script>(function(){"use strict";const cfg='.$cfg.',btn=document.getElementById("pste-safe-migration-start"),box=document.getElementById("pste-safe-migration-feedback");const sleep=ms=>new Promise(r=>setTimeout(r,ms));function msg(t,e){if(!box)return;box.style.display="block";box.className="notice "+(e?"notice-error":"notice-info")+" inline";box.querySelector("p").textContent=t;}function show(j){msg("Migration: "+j.status+" · Phase "+j.phase+" · Identität "+j.legacy_identity_progress+" / "+j.legacy_identity_total+" · Editorial "+j.editorial_prepare_progress+" / "+j.editorial_total+" → "+j.editorial_finalize_progress+" / "+j.editorial_total+" · Sandbox "+j.sandbox_progress+" / "+j.sandbox_total,false);}async function call(a,d){const body=new URLSearchParams(Object.assign({action:a,nonce:cfg.nonce},d||{}));const r=await fetch(cfg.ajax_url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8"},body:body.toString()});const raw=await r.text();let j;try{j=JSON.parse((raw||"").replace(/^\uFEFF/,"").trim());}catch(e){throw new Error("PSTE_SAFE_MIGRATION_AJAX_INVALID_JSON_HTTP_"+r.status+"_LEN_"+(raw||"").length);}if(!r.ok||!j.success)throw new Error((j.data&&j.data.error_code)||"PSTE_SAFE_MIGRATION_AJAX_FAILED");return j.data;}async function loop(job,resume){let cur=job,first=!!resume;for(let guard=0;guard<160;guard++){show(cur);if(cur.status==="COMPLETE"){window.location.href=cfg.redirect;return;}if(cur.status==="PAUSED_ERROR"&&!first){msg("Sicher angehalten: "+(cur.last_error||"PSTE_SAFE_MIGRATION_PAUSED"),true);return;}await sleep(180);const d=await call("pste_safe_migration_advance",{job_uuid:cur.job_uuid,explicit_resume:first?"1":"0"});cur=d.job;first=false;}throw new Error("PSTE_SAFE_MIGRATION_LOOP_GUARD");}if(btn)btn.addEventListener("click",async()=>{btn.disabled=true;try{let job=cfg.job;if(!job||!job.job_uuid||job.status==="COMPLETE"){const d=await call("pste_safe_migration_start",{});job=d.job;}await loop(job,job.status==="PAUSED_ERROR");}catch(e){msg(e.message||"PSTE_SAFE_MIGRATION_FAILED",true);btn.disabled=false;}});})();</script></section>';
    }

    private static function renderOverview(): void {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$baselineState=is_array($baseline)?PSTE_Snapshot::baselineStatus($baseline):['status'=>'NOT_CAPTURED'];$context=PSTE_Context_Refresh::status();$data=PSTE_Credentials::connectionStatus();$gsc=PSTE_GSC_Credentials::status();$summary=PSTE_Analytics::summary();$lastSync=get_option(PSTE_OPTION_GSC_LAST_SYNC,[]);$editorialRuleset=get_option(PSTE_OPTION_EDITORIAL_RULESET,[]);
        $priceRepair=get_option(PSTE_OPTION_PRICE_INTENT_REPAIR,[]);
        $priceRepairStatus=is_array($priceRepair)?(string)($priceRepair['status']??''):'';
        if(!in_array($priceRepairStatus,['PASS','PARTIAL_PASS','BLOCKED'],true)){
            echo '<div class="notice notice-warning inline"><p><strong>Einmalige Preis-Longtail-Korrektur ausstehend.</strong> Betroffene Begriffe wie „günstig“, „billig“ und „preiswert“ werden ausschließlich im internen Themenpool korrekt der vorhandenen Kosten-Kategorie zugeordnet. Artikel, Texte, Design und Textmaschine bleiben unberührt.</p>';
            self::actionForm('pste_repair_price_intents','pste_repair_price_intents','Preis-Longtails sicher neu zuordnen','primary');
            echo '</div>';
        }elseif(in_array($priceRepairStatus,['PARTIAL_PASS','BLOCKED'],true)){
            $priceReport=(array)($priceRepair['report']??[]);$blockedItems=array_values((array)($priceReport['blocked_items']??[]));
            echo '<div class="notice notice-warning inline"><p><strong>Preis-Longtail-Korrektur mit einzeln abgegrenzten Problemfällen abgeschlossen.</strong> Eindeutige Fälle: '.esc_html((string)((int)($priceReport['repaired']??0)+(int)($priceReport['unchanged']??0))).' · unverändert zurückgehalten: '.esc_html((string)(int)($priceReport['blocked']??0)).'. Ein einzelner Problemfall hat keine anderen Themen zurückgerollt.</p>';
            if($blockedItems){echo '<ul style="margin-left:18px">';foreach(array_slice($blockedItems,0,20) as $item){$label=trim((string)($item['query']??''));if($label==='')$label='Pool-Schlüssel '.(string)($item['pool_key']??'');echo '<li>'.esc_html($label).' · <code>'.esc_html((string)($item['reason_code']??'PSTE_PRICE_INTENT_REPAIR_CANDIDATE_BLOCKED')).'</code></li>';}echo '</ul>';}
            echo '<p>Diese Einzelfälle wurden weder geändert noch an die Textmaschine übergeben.</p></div>';
        }
        echo '<div class="pste-grid">';
        self::card('DataForSEO',self::badge((string)$data['status'],(string)$data['label']),!empty($data['tested_at_utc'])?'Geprüft: '.esc_html((string)$data['tested_at_utc']).' UTC':'Kostenpflichtige Datenquelle');
        self::card('Google Search Console',self::badge((string)$gsc['status'],(string)$gsc['label']),!empty($lastSync['synced_at_utc'])?'Letzte Daten: '.esc_html((string)$lastSync['synced_at_utc']):'Kostenfreie First-Party-Daten');
        $baselineNote=is_array($baseline)?(($baseline['post_counts']['publish']??0).' Beiträge · '.($baseline['topic_family_count']??0).' Themenfamilien · '.($baseline['leaf_category_count']??0).' nutzbare Kategorien'): 'Noch nicht erfasst';
        if(is_array($baseline)&&(int)($baseline['quarantined_category_count']??0)>0)$baselineNote.=' · '.(int)$baseline['quarantined_category_count'].' einzeln gesperrt';
        self::card('Website-Gesamtbild',self::badge((string)($baselineState['status']??'NOT_CAPTURED'),(string)($baselineState['status']??'NOT_CAPTURED')),esc_html($baselineNote));
        self::card('Rechercheworkflow',self::badge('PASS','EINFACH'),'Ein Klick je Themenfamilie · keine Live-SERP-Schleife');
        $research=$summary['research']??[];
        $contextDetail=($context['processed']??0).' von '.($context['total']??0).' Themen abgeglichen';
        if((int)($context['sandbox_total']??0)>0)$contextDetail.=' · Sandbox '.(int)($context['sandbox_processed']??0).' von '.(int)($context['sandbox_total']??0);
        if((string)($context['status']??'')==='BLOCKED')$contextDetail.=' · Fehler: '.(string)($context['error_code']??'PSTE_CONTEXT_REFRESH_FAILED');
        self::card('Portalabgleich',self::badge((string)($context['status']??'NOT_STARTED'),(string)($context['status']??'NOT_STARTED')),esc_html($contextDetail));
        self::card('Portalweite Recherche',self::badge((string)($research['status']??'PROVISIONAL'),(string)($research['status']??'PROVISIONAL')),esc_html(($research['analyzed_categories']??0).' von '.($research['total_categories']??0).' Kategorien · '.($research['percent']??0).' %'));
        echo '</div>';
        echo '<section class="pste-box"><h2>Semantik- und Titelvertrag</h2><p>Neue Rechercheläufe verwenden den dynamischen Artikeltyp-Registry-, Doppelstrang-, Dubletten- und Titelworkflow. Bestehende Themen werden nicht nachträglich blind umgeschrieben.</p></section>';
        if(is_array($baseline)&&(int)($baseline['quarantined_category_count']??0)>0){
            $preview=array_values((array)($baseline['quarantined_categories_preview']??[]));
            echo '<div class="notice notice-warning inline"><p><strong>Einzelne Kategorien sind sicher gesperrt, der übrige Portalbestand bleibt nutzbar.</strong> Betroffen: '.esc_html((string)(int)$baseline['quarantined_category_count']).'. Diese Kategorien werden weder automatisch zugeordnet noch an den Compiler übergeben.</p>';
            if($preview){echo '<ul style="margin-left:18px">';foreach(array_slice($preview,0,10) as $row)echo '<li><code>'.esc_html((string)($row['term_id']??0)).'</code> · '.esc_html((string)($row['name']??'')).' · <code>'.esc_html((string)($row['slug']??'')).'</code> · '.esc_html((string)($row['reason_code']??'PSTE_CATEGORY_QUARANTINED')).'</li>';echo '</ul>';}
            echo '</div>';
        }
        if((string)($context['status']??'')==='BLOCKED'){
            echo '<div class="notice notice-error inline"><p><strong>Portalabgleich technisch blockiert.</strong> Planung bleibt gesperrt; die Ampelfarben darunter zeigen ausschließlich die fachliche Themenbewertung.<br><strong>Fehlercode:</strong> <code>'.esc_html((string)($context['error_code']??'PSTE_CONTEXT_REFRESH_FAILED')).'</code></p></div>';
        }

        echo '<section class="pste-box"><h2>Ampel der Themenprüfung</h2><p><strong>Die Ampel zeigt nur den fachlichen menschlichen Prüfbedarf.</strong> Grün: kein Eingriff nötig. Gelb: vorläufig eingeordnet; nur bei Fehler korrigieren. Rot: aktive fachliche Entscheidung erforderlich. Der technische Portalabgleich und die Planungssperre werden getrennt angezeigt.</p><div class="pste-traffic-grid">';
        self::trafficCard('GREEN','Grün',(int)($summary['pool_green']??0),'Kein manueller Eingriff nötig','traffic_green');
        self::trafficCard('YELLOW','Gelb',(int)($summary['pool_yellow']??0),'Vorläufig angenommen – nur Fehler ablehnen','traffic_yellow');
        self::trafficCard('RED','Rot',(int)($summary['pool_red']??0),'Aktive Entscheidung erforderlich','traffic_red');
        echo '</div></section>';

        echo '<div class="pste-grid">';self::metric('Unterrepräsentiert',$summary['coverage_counts']['UNDERREPRESENTED']??0);self::metric('Ausgeglichen',$summary['coverage_counts']['BALANCED']??0);self::metric('Überrepräsentiert',$summary['coverage_counts']['OVERREPRESENTED']??0);self::metric('Daten fehlen',$summary['coverage_counts']['DATA_INSUFFICIENT']??0);self::metric('Konflikte',$summary['conflict_count']);self::metric('Produktionsreife Themen',$summary['priority_ready_count']);self::metric('Globale Themen',$summary['pool_total']??0);self::metric('Fundstellen',$summary['pool_occurrences']??0);echo '</div>';
        echo '<div class="pste-two"><section><h2>Nächste sinnvolle Themen</h2>';self::priorityTable($summary['top_priorities']);echo '<p><a class="button" href="'.esc_url(admin_url('admin.php?page='.self::TABS['priorities']['slug'])).'">Alle Prioritäten anzeigen</a></p></section><section><h2>Einmalige Grundschritte</h2>';
        self::actionForm('pste_capture_baseline','pste_capture_baseline',($baselineState['status']??'')==='NOT_CAPTURED'?'Gesamtbestand erfassen':'Gesamtbestand neu abgleichen','primary');if(in_array((string)($context['status']??''),['PENDING','RUNNING'],true))self::actionForm('pste_process_context_batch','pste_process_context_batch','Portalabgleich jetzt fortsetzen');echo '<p>Danach unter <strong>Datenquellen</strong> DataForSEO und optional Search Console verbinden. Eine Recherche läuft mit genau einem Startklick vollständig durch.</p>';
        self::renderContextAutoSequence($context);
        echo '</section></div>';
    }

    private static function renderTopics(): void {$rows=PSTE_Analytics::topicRows();echo '<h2>Zentrale Themenkarte</h2><p>Bestand und Themenkandidaten in einer Ansicht. Ein bestehender Beitrag und ein geplanter Kandidat mit gleichem Antwortversprechen werden blockiert.</p>';echo '<table class="widefat striped pste-table"><thead><tr><th>Kategorie</th><th>Thema</th><th>Quelle</th><th>Artikeltyp</th><th>Status</th><th>Volumen</th></tr></thead><tbody>';foreach($rows as $r)echo '<tr><td>'.esc_html($r['category_name']).'</td><td>'.esc_html($r['topic']).'</td><td>'.esc_html($r['source']).'</td><td>'.esc_html($r['article_type']).'</td><td>'.self::badge($r['status'],$r['status']).'</td><td>'.esc_html($r['search_volume']===null?'—':(string)$r['search_volume']).'</td></tr>';if(!$rows)self::emptyRow(6,'Noch keine Themen vorhanden.');echo '</tbody></table>';}

    private static function renderKeywords(): void {
        $rows=PSTE_Analytics::keywordRows();echo '<h2>Longtails und daraus gebildete Themen</h2><p>Gezeigt werden Recherchebegriff, zugeordneter Beitragstyp, vorhandene Zielkategorie, Datenquelle und Freigabestatus. Es gibt keine externe SERP-Bewertung.</p><table class="widefat striped pste-table"><thead><tr><th>Zielkategorie</th><th>Longtail/Nutzerfrage</th><th>Beitragstyp</th><th>Volumen</th><th>Quellen</th><th>Status</th></tr></thead><tbody>';
        foreach($rows as $r)echo '<tr><td>'.esc_html($r['category_name']).'</td><td>'.esc_html($r['keyword']).'</td><td>'.esc_html($r['article_type']).'</td><td>'.esc_html($r['search_volume']===null?'—':(string)$r['search_volume']).'</td><td>'.esc_html(implode(', ',$r['sources'])).'</td><td>'.self::badge($r['pool_status'],$r['pool_status']).'</td></tr>';
        if(!$rows)self::emptyRow(6,'Noch keine Longtaildaten vorhanden.');echo '</tbody></table>';
    }

    private static function renderReview(): void {
        $filter=sanitize_key((string)($_GET['pool_filter']??'attention'));$allowed=['attention','all','traffic_red','traffic_yellow','traffic_green','PASS','AUTO_RESOLVED','REVIEW_REQUIRED','PROVISIONAL_ACCEPTED','PROVISIONAL_REASSIGN','DISCOVERY_ONLY','BLOCKED_FOR_CATEGORY','APPROVED','REJECTED'];if(!in_array($filter,$allowed,true))$filter='attention';$search=sanitize_text_field((string)($_GET['pool_search']??''));$rows=PSTE_Repository::adminTopicPoolCandidates($filter,$search,500);$stats=PSTE_Repository::adminTopicPoolStats();$context=PSTE_Context_Refresh::status();
        echo '<h2>Portalweite Themenprüfung</h2><p><strong>Die Ampel zeigt ausschließlich den menschlichen Prüfbedarf.</strong> Rolle, Planungseignung, Kategorie, Artikeltyp und Priorität sind davon getrennt.</p>';
        if((string)($context['status']??'NOT_STARTED')!=='COMPLETE'){
            $contextError=(string)($context['error_code']??'');
            echo '<div class="notice notice-error inline"><p><strong>Systemprüfung nicht abgeschlossen:</strong> Portalabgleich '.esc_html((string)($context['status']??'NOT_STARTED')).' ('.esc_html((string)($context['processed']??0)).' von '.esc_html((string)($context['total']??0)).'). Planung bleibt fail-closed blockiert. Die Themenampel zeigt weiterhin nur den fachlichen Prüfbedarf.';
            if($contextError!=='')echo '<br><strong>Fehlercode:</strong> <code>'.esc_html($contextError).'</code>';
            echo '</p></div>';
        }
        echo '<div class="pste-grid">';self::metric('Globale Themen',$stats['TOTAL']??0);self::metric('Fundstellen',$stats['OCCURRENCES']??0);self::metric('Rot',$stats['RED']??0);self::metric('Gelb',$stats['YELLOW']??0);self::metric('Merge-Kandidaten',$stats['MERGE_CANDIDATES']??0);echo '</div>';
        echo '<form method="get" class="pste-box"><input type="hidden" name="page" value="'.esc_attr(self::TABS['review']['slug']).'"><label>Ansicht <select name="pool_filter">';$labels=['attention'=>'Rot und Gelb','traffic_red'=>'Nur Rot','traffic_yellow'=>'Nur Gelb','traffic_green'=>'Nur Grün','all'=>'Alle globalen Themen','PASS'=>'Automatisch eingeordnete Artikelthemen','AUTO_RESOLVED'=>'Automatisch erzeugte Titel/Fragen','DISCOVERY_ONLY'=>'Recherchebegriffe/Oberbegriffe','BLOCKED_FOR_CATEGORY'=>'Bereits abgedeckt oder blockiert','APPROVED'=>'Manuell freigegeben','REJECTED'=>'Verworfen'];foreach($labels as $value=>$label)echo '<option value="'.esc_attr($value).'" '.selected($filter,$value,false).'>'.esc_html($label).'</option>';echo '</select></label> <label>Suche <input type="search" name="pool_search" value="'.esc_attr($search).'" placeholder="Thema oder Kategorie"></label> ';submit_button('Ansicht filtern','secondary','submit',false);echo '</form>';
        echo '<table class="widefat striped pste-table pste-review-table"><thead><tr><th>Ampel</th><th>Globales Thema</th><th>Rolle</th><th>Zielkategorie</th><th>Artikeltyp</th><th>Planung</th><th>Prüfgrund</th><th>Aktion</th></tr></thead><tbody>';
        foreach($rows as $c){$light=(array)($c['traffic_light']??PSTE_Repository::trafficLightForStatus((string)($c['pool_status']??'REVIEW_REQUIRED'),(string)($c['context_state']??'PENDING')));$role=(string)($c['topic_role']??'RESEARCH_KEYWORD');$planning=(string)($c['planning_suitability']??'BLOCKED');$assign=self::primaryAssignment($c);$hard=PSTE_Topic_Policy::presentHardCodes($c);$nonOver=PSTE_Topic_Policy::presentNonOverridableCodes($c);$reason=self::humanReviewReason($c);
            echo '<tr><td><span class="pste-light pste-light-'.esc_attr(strtolower((string)$light['code'])).'">'.esc_html((string)$light['label']).'</span><br><small>'.esc_html((string)$light['meaning']).'</small></td>';
            echo '<td><strong>'.esc_html(PSTE_Editorializer::displayTitle($c)).'</strong><br><small>ID: '.esc_html((string)$c['pool_key']).'</small><details><summary>Technische Details</summary><p><strong>Fundstellen:</strong> '.esc_html((string)count((array)($c['occurrences']??[]))).'<br><strong>Reason Codes:</strong> '.esc_html(implode(', ',(array)($c['reason_codes']??[]))).'<br><strong>Kontext:</strong> '.esc_html((string)($c['context_state']??'PENDING')).'</p></details>';
            $currentTitle=trim((string)($c['production_title']??''));$targetKeyword=trim((string)($c['target_keyword']??''));
            if(in_array((string)($c['context_state']??'PENDING'),['CURRENT','NOT_REQUIRED'],true)&&$currentTitle!==''&&$targetKeyword!==''){
                echo '<details style="margin-top:8px"><summary>Titel händisch ändern</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-top:8px">';wp_nonce_field('pste_override_title');echo '<input type="hidden" name="action" value="pste_override_title"><input type="hidden" name="pool_key" value="'.esc_attr((string)$c['pool_key']).'"><p><small>Zielkeyword muss am Titelanfang stehen. Kategorie, Artikeltyp, Intent und Planlogik bleiben unverändert.</small></p><input type="text" name="manual_title" class="regular-text" value="'.esc_attr($currentTitle).'" required><br><small>Zielkeyword: <code>'.esc_html($targetKeyword).'</code></small><br>';submit_button('Nur Titel speichern','secondary','submit',false);echo '</form></details>';
            }
            echo '</td>';
            $system=PSTE_Topic_Policy::systemState((string)($c['context_state']??'PENDING'));
            echo '<td>'.esc_html(PSTE_Topic_Policy::roleLabel($role)).'</td><td>'.esc_html((string)($assign['category_name']??'—')).'</td><td>'.esc_html((string)($assign['article_type']??($c['proposed_article_type']??'—'))).'</td><td><strong>'.esc_html(PSTE_Topic_Policy::planningLabel($planning)).'</strong><br><small>Systemprüfung: '.esc_html((string)$system['label']).'</small></td><td>'.esc_html($reason).'</td><td>';
            if(!in_array((string)($c['context_state']??'PENDING'),['CURRENT','NOT_REQUIRED'],true)){echo '<em>Keine manuelle Entscheidung möglich. Zuerst Portalabgleich abschließen.</em>';}elseif((string)$light['code']==='GREEN'){echo '<em>Keine Aktion nötig.</em>';}else{echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_review_candidate');echo '<input type="hidden" name="action" value="pste_review_candidate"><input type="hidden" name="pool_key" value="'.esc_attr((string)$c['pool_key']).'"><select name="review_status"><option value="AUTO">Keine Änderung – Automatik beibehalten</option>';
                if(!$nonOver)echo '<option value="APPROVED">Als Thema freigeben</option>';echo '<option value="REVIEW_REQUIRED">Weiter offen lassen</option><option value="BLOCKED_FOR_CATEGORY">Als bereits abgedeckt/blockiert markieren</option><option value="DISCOVERY_ONLY">Nur als Recherchebegriff behalten</option><option value="REASSIGNED">Anderer Kategorie zuordnen</option><option value="REJECTED">Endgültig verwerfen</option></select><br><input list="pste-global-category-list" name="target_category_name" class="regular-text" placeholder="Zielkategorie (nur Umordnung)"><br><select name="target_article_type"><option value="">Artikeltyp aus Zielkategorie</option>';foreach(self::availableArticleTypes() as $type)echo '<option value="'.esc_attr($type).'">'.esc_html($type).'</option>';echo '</select><br><input type="text" name="review_note" class="regular-text" placeholder="Begründung">';if($hard&&!$nonOver)echo '<p class="pste-hard-warning"><label><input type="checkbox" name="confirm_hard_override" value="1"> Harte Sperre bewusst übersteuern</label><br><small>Nur mit Begründung. Betroffene Regeln: '.esc_html(implode(', ',$hard)).'</small></p>';if($nonOver)echo '<p class="pste-hard-warning"><strong>Nicht übersteuerbare technische Sperre:</strong> '.esc_html(implode(', ',$nonOver)).'</p>';submit_button('Entscheidung speichern','secondary','submit',false);echo '</form>';}
            echo '</td></tr>';
        }
        if(!$rows)self::emptyRow(8,$filter==='attention'?'Keine roten oder gelben Fälle.':'Keine Themen für diesen Filter.');echo '</tbody></table>';self::globalCategoryDatalist();
    }

    private static function primaryAssignment(array $candidate): array {
        $assignments=(array)($candidate['assignments']??[]);$rank=['CONFIRMED'=>0,'PROVISIONAL_ACCEPTED'=>1,'OBSERVED'=>2,'SUGGESTED'=>3,'EXISTING'=>4,'PLANNED'=>5];usort($assignments,static fn($a,$b)=>[$rank[(string)($a['assignment_status']??'')]??9,-(float)($a['confidence']??0)]<=>[$rank[(string)($b['assignment_status']??'')]??9,-(float)($b['confidence']??0)]);return $assignments[0]??['category_name'=>(string)($candidate['target_category_name']??''),'article_type'=>(string)($candidate['proposed_article_type']??'')];
    }

    private static function humanReviewReason(array $candidate): string {
        $codes=(array)($candidate['reason_codes']??[]);$labels=['FAQ_NATURAL_QUESTION_WITHOUT_PUNCTUATION'=>'Natürliche Frage ohne Fragezeichen erkannt','FAQ_RECOMMENDATION_OR_SUPERLATIVE_REVIEW'=>'Empfehlungs-/Vergleichsabsicht erkannt','CONFLICTING_TARGET_ASSIGNMENTS'=>'Mehrere gleich plausible Zielkategorien','ANSWER_EQUIVALENT_EXISTING'=>'Inhalt vermutlich bereits vorhanden','ANSWER_EQUIVALENT_PLANNED'=>'Thema vermutlich bereits geplant','CATEGORY_HEAD_INTENT_COLLISION'=>'Oberbegriff wird bereits durch die Kategorie abgedeckt','STALE_YEAR_SPECIFIC_QUERY'=>'Veralteter Jahresbegriff','CONTEXT_REFRESH_FAILED'=>'Technischer Portalabgleich fehlgeschlagen','CONTEXT_REFRESH_STALE'=>'Bestand änderte sich während des Abgleichs','GLOBAL_IDENTITY_MIGRATION_CONFLICT'=>'Widersprüchliche Altentscheidungen','MERGE_CANDIDATE_REVIEW_REQUIRED'=>'Mögliche Themenzusammenführung prüfen','EXACT_EDITORIAL_INTENT_VARIANT'=>'Gleiche redaktionelle Suchintention bereits als Hauptthema vorhanden','EDITORIAL_TARGET_CATEGORY_MISSING'=>'Passende vorhandene Zielkategorie fehlt'];foreach($labels as $code=>$label)if(in_array($code,$codes,true))return $label;$status=(string)($candidate['pool_status']??'');if($status==='PROVISIONAL_REASSIGN')return 'Eindeutige Umordnung vorläufig angenommen';if($status==='PROVISIONAL_ACCEPTED')return 'Plausible automatische Einordnung';if($status==='DISCOVERY_ONLY')return 'Kein eigenständiges Produktionsthema';if($status==='BLOCKED_FOR_CATEGORY')return 'Bereits abgedeckt oder für diese Zuordnung ungeeignet';return 'Automatisch eindeutig eingeordnet';
    }

    private static function renderCoverage(): void {$rows=PSTE_Analytics::coverage();echo '<h2>Thematische Abdeckung</h2><p><strong>Abdeckung</strong> vergleicht den Anteil vorhandener Beiträge mit dem durch GSC-Impressionen und bestätigte Keywordnachfrage abgeleiteten Bedarfsanteil. Ohne belastbare Nachfragedaten wird nicht geraten, sondern „Daten fehlen“ angezeigt.</p>';echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_save_category_weights');echo '<input type="hidden" name="action" value="pste_save_category_weights"><table class="widefat striped pste-table"><thead><tr><th>Themenfamilie</th><th>Beiträge</th><th>PASS geplant</th><th>GSC-Impressionen</th><th>Keywordvolumen</th><th>Bedarfsanteil</th><th>Inhaltsanteil</th><th>Abdeckung</th><th>Status</th><th>Strategie 0–10</th></tr></thead><tbody>';foreach($rows as $r)echo '<tr><td>'.esc_html($r['category_name']).'</td><td>'.esc_html((string)$r['published']).'</td><td>'.esc_html((string)$r['planned_pass']).'</td><td>'.esc_html(number_format((float)$r['gsc_impressions'],0,',','.')).'</td><td>'.esc_html(number_format((float)$r['candidate_volume'],0,',','.')).'</td><td>'.esc_html(number_format((float)$r['demand_share_pct'],2,',','.').' %').'</td><td>'.esc_html(number_format((float)$r['content_share_pct'],2,',','.').' %').'</td><td>'.esc_html($r['coverage_pct']===null?'—':number_format((float)$r['coverage_pct'],1,',','.').' %').'</td><td>'.self::badge($r['state'],self::coverageLabel($r['state'])).'</td><td><input style="width:70px" type="number" min="0" max="10" step="0.5" name="weights['.esc_attr((string)$r['category_id']).']" value="'.esc_attr((string)$r['strategic_weight']).'"></td></tr>';if(!$rows)self::emptyRow(10,'Gesamtbestand noch nicht erfasst.');echo '</tbody></table>';submit_button('Strategische Gewichtung speichern','secondary');echo '</form><p><strong>Yoast-Hinweis:</strong> Die Engine ändert Yoast niemals automatisch. Bei starken Unter-/Überdeckungen zeigt sie lediglich, wo Kategorie-Indexierung, SEO-Titel, interne Schwerpunktsetzung oder Zusammenlegung redaktionell geprüft werden sollten.</p>';}

    private static function renderPriorities(): void {$rows=PSTE_Analytics::priorities();$research=PSTE_Repository::researchCompleteness();echo '<h2>Priorisierte nächste Artikelerstellungen</h2>';if(($research['status']??'PROVISIONAL')!=='COMPLETE')echo '<div class="notice notice-warning inline"><p><strong>Vorläufig:</strong> Erst '.esc_html((string)($research['analyzed_categories']??0)).' von '.esc_html((string)($research['total_categories']??0)).' Kategorien wurden recherchiert. Keine endgültige portalweite Gesamtpriorisierung.</p></div>';echo '<p>Harte Dubletten- und Kannibalisierungsregeln stehen immer über Punkten. Nur <strong>PASS</strong>-Themen sind innerhalb des aktuellen Datenstands fachlich freigegeben; der bestehende Produktions- und Qualitätsprozess bleibt danach vollständig bestehen.</p>';self::priorityTable($rows,true);}
    private static function renderConflicts(): void {$rows=PSTE_Analytics::conflicts();echo '<h2>Portalinterne Konflikte und Überschneidungen</h2><table class="widefat striped pste-table"><thead><tr><th>Kategorie</th><th>Thema</th><th>Status</th><th>Gründe</th><th>Ähnlichste vorhandene Stellen</th></tr></thead><tbody>';foreach($rows as $r){$matches=[];foreach($r['matches'] as $m)$matches[]=(string)($m['title']??$m['matched_value']??'');echo '<tr><td>'.esc_html($r['category_name']).'</td><td>'.esc_html($r['topic']).'</td><td>'.self::badge($r['decision'],$r['decision']).'</td><td>'.esc_html(implode(', ',$r['reason_codes'])).'</td><td>'.esc_html(implode(' | ',array_slice($matches,0,3))).'</td></tr>';}if(!$rows)self::emptyRow(5,'Keine Konflikte im vorhandenen Kandidatenbestand.');echo '</tbody></table>';}

    private static function renderSources(): void {
        $data=PSTE_Credentials::status();$dataConnection=PSTE_Credentials::connectionStatus();$gsc=PSTE_GSC_Credentials::status();$sites=get_option(PSTE_OPTION_GSC_SITES_CACHE,[]);$selected=(string)get_option(PSTE_OPTION_GSC_SELECTED_PROPERTY,'');$lastSync=get_option(PSTE_OPTION_GSC_LAST_SYNC,[]);
        echo '<h2>Datenquellen</h2><div class="notice notice-info inline"><p><strong>Klare Aufgabe:</strong> DataForSEO liefert Longtail-Vorschläge, verwandte Suchbegriffe, Keyword-Ideen und jeweils das exakt zugehörige Suchvolumen. Die Engine bildet daraus lokale Titel, ordnet sie vorhandenen Portalkategorien zu und prüft sie gegen den eigenen Bestand. Im normalen Rechercheworkflow gibt es keine Google-Live-SERP-Prüfung. Reale Google-SERPs werden ausschließlich im isolierten Semantic-Sandbox-Review verwendet und haben keinen direkten Produktionspfad.</p></div><div class="pste-two"><section>';
        self::connectionPanel('DataForSEO',$dataConnection,'Longtail-Vorschläge, verwandte Keywords und Suchvolumen');
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_save_credentials');echo '<input type="hidden" name="action" value="pste_save_credentials"><table class="form-table"><tr><th>API-Zugangscode (Base64)</th><td><input class="large-text code" type="password" name="api_credentials_base64" autocomplete="new-password" placeholder="Base64-Code aus der DataForSEO-E-Mail einfügen"><p class="description">Der Base64-Code wird nicht gespeichert.</p></td></tr><tr><th colspan="2"><hr><span style="font-weight:400">Alternativ getrennt eingeben:</span></th></tr><tr><th>API Login</th><td><input class="regular-text" name="api_login" autocomplete="off" placeholder="'.esc_attr($data['configured']?'gespeichert: '.$data['masked_login']:'API Login eingeben').'"><p class="description">Leer lassen = gespeichert behalten.</p></td></tr><tr><th>API Password</th><td><input class="regular-text" type="password" name="api_password" autocomplete="new-password" placeholder="'.esc_attr($data['configured']?'gespeichert – leer lassen':'API Password eingeben').'"></td></tr></table>';submit_button('DataForSEO-Zugang speichern');echo '</form>';if($data['configured'])self::actionForm('pste_connection_test','pste_connection_test','Verbindung kostenfrei prüfen');echo '</section><section>';
        self::connectionPanel('Google Search Console',$gsc,'Optional: reale eigene Suchanfragen und Impressionen');
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_save_gsc_client');echo '<input type="hidden" name="action" value="pste_save_gsc_client"><table class="form-table"><tr><th>Google OAuth Client ID</th><td><input class="regular-text" name="client_id" autocomplete="off" placeholder="'.esc_attr($gsc['configured']?'gespeichert: '.$gsc['masked_client_id']:'Client ID eingeben').'"></td></tr><tr><th>Google OAuth Client Secret</th><td><input class="regular-text" type="password" name="client_secret" autocomplete="new-password" placeholder="'.esc_attr($gsc['configured']?'gespeichert – leer lassen':'Client Secret eingeben').'"></td></tr><tr><th>Authorized redirect URI</th><td><input class="large-text code" readonly value="'.esc_attr($gsc['redirect_uri']).'"></td></tr></table>';submit_button('Google-Zugang speichern');echo '</form>';
        if($gsc['configured']&&$gsc['status']!=='CONNECTED')self::actionForm('pste_gsc_connect','pste_gsc_connect','Mit Google verbinden','primary');
        if($gsc['status']==='CONNECTED'){self::actionForm('pste_gsc_test','pste_gsc_test','Verbindung und Properties neu prüfen');self::actionForm('pste_gsc_disconnect','pste_gsc_disconnect','Google-Verbindung trennen');}
        echo '</section></div>';
        if($gsc['status']==='CONNECTED'){
            echo '<section class="pste-box"><h3>Search-Console-Property und Datenabruf</h3><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_gsc_save_property');echo '<input type="hidden" name="action" value="pste_gsc_save_property"><select name="property_url" required><option value="">Property auswählen</option>';
            foreach(($sites['items']??[]) as $site){$url=(string)$site['site_url'];echo '<option value="'.esc_attr($url).'" '.selected($selected,$url,false).'>'.esc_html($url.' · '.$site['permission_level']).'</option>';}
            echo '</select> ';submit_button('Property speichern','secondary','submit',false);echo '</form>';
            if($selected!==''){self::actionForm('pste_gsc_sync','pste_gsc_sync','Search-Console-Daten jetzt read-only abrufen','primary');if(!empty($lastSync['synced_at_utc']))echo '<p>Letzter Abruf: '.esc_html((string)$lastSync['synced_at_utc']).' · '.esc_html((string)($lastSync['saved_rows']??0)).' gespeicherte Zeilen</p>';}
            echo '</section>';
        }
        echo '<section class="pste-box"><h3>Manueller Search-Console-CSV-Fallback</h3><form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_import_gsc');echo '<input type="hidden" name="action" value="pste_import_gsc"><input type="file" name="gsc_csv" accept=".csv,text/csv" required> ';submit_button('CSV read-only importieren','secondary','submit',false);echo '</form></section>';
    }

    private static function renderSandbox(): void {
        $sandboxRegistry=PSTE_Semantic_Review_Sandbox::stored();$summary=PSTE_Semantic_Review_Sandbox::summary($sandboxRegistry);$records=PSTE_Semantic_Review_Sandbox::recordsForAdmin($sandboxRegistry);$s=PSTE_Plugin::settings();$job=$summary['job']??null;$c=(array)($summary['counts']??[]);
        echo '<h2>Semantic Review Sandbox</h2>';
        echo '<div class="notice notice-warning inline"><p><strong>Hauptregel 1:</strong> Diese Sandbox ist vollständig getrennt von Artikeln, Textmaschine, PPM, Compiler, HTML und Design. Sie erzeugt keinen Produktions-Handoff und besitzt keinen Apply-Button.</p></div>';
        $maintenance=PSTE_Sandbox_Maintenance_Health::snapshot();$maintenanceBad=(string)($maintenance['schedule_status']??'MISSING')!=='SCHEDULED'||in_array((string)($maintenance['run_health']??'UNKNOWN'),['FAIL','OVERDUE'],true);
        echo '<div class="notice '.($maintenanceBad?'notice-error':'notice-info').' inline"><p><strong>Interne Wiederprüfung:</strong> Zeitplan '.esc_html((string)($maintenance['schedule_status']??'UNKNOWN')).' · Laufstatus '.esc_html((string)($maintenance['run_health']??'UNKNOWN')).(($maintenance['current_error_code']??'')!==''?' · Fehler <code>'.esc_html((string)$maintenance['current_error_code']).'</code>':'').'. Strukturlücken bleiben gespeichert; ein ausgefallener Wartungslauf wird sichtbar protokolliert.</p></div>';
        echo '<p><strong>Workflow:</strong> V2-Hauptgate → alle blockierten Longtails dauerhaft erhalten → <strong>Relevanz zuerst</strong> anhand realer SEO-/SERP-Evidenz → nur bestätigte relevante Fälle werden danach intern auf Familie, Kategorie und Titelprobe geprüft. Lokaler Portalbegriff, Familiennähe und Ausschlüsse sind vorher ausschließlich Hinweise und niemals ein Relevanzurteil.</p>';
        echo '<div class="pste-grid">';
        $internalReviewCount=(int)($c['MATCHER_REVIEW']??0)+(int)($c['PROPOSAL_READY_FOR_REVIEW']??0)+(int)($c['MULTIPLE_FAMILIES_REVIEW']??0)+(int)($c['REVIEW_REQUIRED']??0);
        foreach([['Gespeichert',(int)($c['TOTAL_RETAINED']??0)],['Relevanzprüfung offen',(int)($c['PENDING_EXTERNAL_RELEVANCE']??0)],['Providerfehler zurückgestellt',(int)($c['DEFERRED_PROVIDER_ERROR']??0)],['Providerfehler · manuell prüfen',(int)($c['PROVIDER_TASK_REVIEW_REQUIRED']??0)],['Extern relevant',(int)($c['RELEVANT_FOR_PORTAL']??0)],['Extern unklar / manuell prüfen',(int)($c['UNCERTAIN_REVIEW']??0)],['Nicht relevant · gespeichert',(int)($c['RETAINED_NOT_RELEVANT']??0)],['Interne Zuordnung prüfen',$internalReviewCount],['Strukturlücken nach Relevanz',(int)($c['STRUCTURE_GAP']??0)],['Für normalen Reentry vorgemerkt',(int)($c['READY_FOR_NORMAL_REENTRY_REVIEW']??0)]] as $m)echo '<div class="pste-metric"><strong>'.esc_html((string)$m[1]).'</strong><span>'.esc_html($m[0]).'</span></div>';
        echo '</div>';
        $binding=(array)($summary['binding']??[]);if($binding)echo '<p><strong>Gebunden an Dry-run:</strong> <code>'.esc_html(substr((string)($binding['dry_run_sha256']??''),0,16)).'…</code> · <strong>Registry:</strong> <code>'.esc_html(substr((string)($binding['registry_sha256']??''),0,16)).'…</code></p>';
        self::actionForm('pste_sandbox_sync','pste_sandbox_sync','Aktuellen Dry-run schreibfrei in Sandbox synchronisieren','secondary');
        if($records)self::actionForm('pste_sandbox_export','pste_sandbox_export','Sandbox vollständig exportieren','secondary');
        $externalOpen=(int)($c['PENDING_EXTERNAL_RELEVANCE']??0)+(int)($c['STALE_REVIEW_REQUIRED']??0)+(int)($c['DEFERRED_PROVIDER_ERROR']??0);
        if($externalOpen>0){
            if((string)($s['environment']??'sandbox')!=='production')echo '<div class="notice notice-warning inline"><p><strong>Reale Relevanzprüfung gesperrt:</strong> DataForSEO steht aktuell auf Sandbox; für echte Google-SERP-Evidenz ist Production erforderlich.</p></div>';
            elseif(empty($s['feature_enabled']))echo '<div class="notice notice-warning inline"><p>Kostenpflichtige Recherche ist in den Einstellungen deaktiviert.</p></div>';
            else{
                $nonce=wp_create_nonce('pste_sandbox_ajax');$redirect=admin_url('admin.php?page='.self::TABS['sandbox']['slug'].'&sandbox_complete=1');
                if(is_array($job)&&in_array((string)($job['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))echo '<div class="pste-box"><p><strong>Sandbox-Lauf:</strong> <span id="pste-sandbox-status">'.esc_html((string)$job['status']).'</span> · <span id="pste-sandbox-progress">'.esc_html((string)$job['progress'].' von '.(string)$job['total']).'</span> · Kosten <span id="pste-sandbox-cost">'.esc_html(number_format((float)$job['actual_cost'],6,'.','')).' USD</span> · danach noch <span id="pste-sandbox-remaining">'.esc_html((string)($job['remaining_open_after_batch']??0)).'</span> offen</p>'.((string)$job['last_error']!==''?'<p><strong>Letzter Fehler:</strong> <code>'.esc_html((string)$job['last_error']).'</code></p>':'').'<button type="button" class="button button-primary" id="pste-sandbox-resume">Lauf fortsetzen</button>'.((string)$job['status']==='OUTCOME_UNKNOWN'?'<p><label><input type="checkbox" id="pste-sandbox-provider-checked"> Providerkonto auf die möglicherweise berechnete Anfrage geprüft</label></p><button type="button" class="button" id="pste-sandbox-cancel">Geprüften unklaren Lauf verwerfen</button>':'').'</div>';
                else echo '<p><label><input type="checkbox" id="pste-sandbox-confirm-cost"> Kosten für den nächsten Block realer Google-SERP-Relevanzprüfungen bestätigen</label> <button type="button" class="button button-primary" id="pste-sandbox-start">Nächsten Relevanz-Prüfblock starten</button></p>';
                echo '<div id="pste-sandbox-feedback" class="notice notice-info inline" style="display:none"><p></p></div>';
                $config=wp_json_encode(['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>$nonce,'redirect'=>$redirect,'job'=>$job],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
                echo '<script>(function(){"use strict";const cfg='.$config.',feedback=document.getElementById("pste-sandbox-feedback"),start=document.getElementById("pste-sandbox-start"),resume=document.getElementById("pste-sandbox-resume"),cancel=document.getElementById("pste-sandbox-cancel");const sleep=ms=>new Promise(r=>setTimeout(r,ms));function msg(t,e){if(!feedback)return;feedback.style.display="block";feedback.className="notice "+(e?"notice-error":"notice-info")+" inline";feedback.querySelector("p").textContent=t;}function render(j){const s=document.getElementById("pste-sandbox-status"),p=document.getElementById("pste-sandbox-progress"),c=document.getElementById("pste-sandbox-cost"),r=document.getElementById("pste-sandbox-remaining");if(s)s.textContent=j.status;if(p)p.textContent=j.progress+" von "+j.total;if(c)c.textContent=Number(j.actual_cost||0).toFixed(6)+" USD";if(r)r.textContent=String(j.remaining_open_after_batch||0);msg("Sandbox: "+j.status+" · "+j.progress+" von "+j.total,false);}async function call(a,d){const body=new URLSearchParams(Object.assign({action:a,nonce:cfg.nonce},d||{}));const r=await fetch(cfg.ajax_url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8"},body:body.toString()});const raw=await r.text();let j;try{j=JSON.parse((raw||"").replace(/^\uFEFF/,"").trim());}catch(e){throw new Error("PSTE_SANDBOX_AJAX_INVALID_JSON_HTTP_"+r.status+"_LEN_"+(raw||"").length);}if(!r.ok||!j.success)throw new Error((j.data&&j.data.error_code)||"PSTE_SANDBOX_AJAX_FAILED");return j.data;}async function loop(job,explicit){let cur=job,first=!!explicit;for(let guard=0;guard<200;guard++){render(cur);if(cur.status==="COMPLETE"||cur.status==="NOTHING_TO_DO"){window.location.href=cfg.redirect;return;}if(cur.status==="PAUSED_ERROR"&&!first){msg("Sicher angehalten: "+(cur.last_error||"PSTE_SANDBOX_PAUSED"),true);return;}if(cur.status==="OUTCOME_UNKNOWN"){msg("Unbekannter Providerausgang. Keine automatische Wiederholung.",true);return;}await sleep(250);const d=await call("pste_sandbox_advance",{job_uuid:cur.job_uuid,explicit_resume:first?"1":"0"});cur=d.job;first=false;}throw new Error("PSTE_SANDBOX_LOOP_GUARD");}if(start)start.addEventListener("click",async()=>{try{if(!document.getElementById("pste-sandbox-confirm-cost").checked)throw new Error("Bitte Kosten bestätigen.");start.disabled=true;const d=await call("pste_sandbox_start",{confirm_cost:"1"});await loop(d.job,false);}catch(e){msg(e.message,true);start.disabled=false;}});if(resume)resume.addEventListener("click",async()=>{try{resume.disabled=true;await loop(cfg.job,true);}catch(e){msg(e.message,true);resume.disabled=false;}});if(cancel)cancel.addEventListener("click",async()=>{try{const checked=document.getElementById("pste-sandbox-provider-checked");if(!checked||!checked.checked)throw new Error("Providerkonto zuerst prüfen.");const d=await call("pste_sandbox_cancel_unknown",{job_uuid:cfg.job.job_uuid,provider_checked:"1"});render(d.job);window.location.reload();}catch(e){msg(e.message,true);}});})();</script>';
            }
        }
        $statusFilter=trim((string)($_GET['sandbox_status']??''));$queryFilter=trim((string)($_GET['sandbox_query']??''));
        $allowedFilters=['','manual','uncertain','internal','structure','not_relevant','reentry'];if(!in_array($statusFilter,$allowedFilters,true))$statusFilter='';
        $filteredRecords=array_values(array_filter($records,static function($r)use($statusFilter,$queryFilter){
            if($queryFilter!==''){if(function_exists('mb_stripos')){$match=mb_stripos((string)($r['query']??''),$queryFilter,0,'UTF-8')!==false;}else{$match=stripos((string)($r['query']??''),$queryFilter)!==false;}if(!$match)return false;}
            $status=(string)($r['status']??'');$ad=(array)($r['relevance_adjudication']??[]);$manual=in_array((string)($ad['decision']??''),['RELEVANT_FOR_PORTAL','NOT_RELEVANT_FOR_PORTAL'],true)&&in_array((string)($ad['decision_source']??''),['EXPLICIT_ADMIN_REVIEW','EXPLICIT_ADMIN_REVIEW_REVISION'],true);
            if($statusFilter==='manual')return $manual;
            if($statusFilter==='uncertain')return $status==='UNCERTAIN_REVIEW';
            if($statusFilter==='internal')return in_array($status,['MATCHER_REVIEW','PROPOSAL_READY_FOR_REVIEW','MULTIPLE_FAMILIES_REVIEW','REVIEW_REQUIRED'],true);
            if($statusFilter==='structure')return $status==='STRUCTURE_GAP';
            if($statusFilter==='not_relevant')return $status==='RETAINED_NOT_RELEVANT';
            if($statusFilter==='reentry')return in_array($status,['READY_FOR_NORMAL_REENTRY_REVIEW','AUTO_REENTRY_ELIGIBLE','REENTERED_TO_NORMAL_PIPELINE','REENTRY_REVIEW_REQUIRED'],true);
            return true;
        }));
        echo '<h3>Erhaltene Kandidaten</h3><form method="get" style="margin:0 0 12px 0"><input type="hidden" name="page" value="'.esc_attr(self::TABS['sandbox']['slug']).'"><label>Status <select name="sandbox_status"><option value="" '.($statusFilter===''?'selected':'').'>Alle</option><option value="manual" '.($statusFilter==='manual'?'selected':'').'>Manuell entschieden</option><option value="uncertain" '.($statusFilter==='uncertain'?'selected':'').'>Relevanz unklar</option><option value="internal" '.($statusFilter==='internal'?'selected':'').'>Interne Zuordnung prüfen</option><option value="structure" '.($statusFilter==='structure'?'selected':'').'>Strukturlücken</option><option value="not_relevant" '.($statusFilter==='not_relevant'?'selected':'').'>Nicht relevant</option><option value="reentry" '.($statusFilter==='reentry'?'selected':'').'>Reentry</option></select></label> <label>Keyword <input type="search" name="sandbox_query" value="'.esc_attr($queryFilter).'" placeholder="z. B. wassertröge"></label> ';submit_button('Filtern','secondary','submit',false);echo ' <a class="button" href="'.esc_url(admin_url('admin.php?page='.self::TABS['sandbox']['slug'])).'">Filter zurücksetzen</a><span style="margin-left:12px">'.esc_html((string)count($filteredRecords)).' von '.esc_html((string)count($records)).' Einträgen</span></form>';
        echo '<table class="widefat striped pste-table"><thead><tr><th>Longtail</th><th>Lokale Hinweise (nur Evidenz)</th><th>Ausschlüsse</th><th>Externe Relevanz</th><th>Nächste Familie (nur Diagnose)</th><th>Interner Vorschlag erst nach Relevanz</th><th>Status</th><th>Review</th></tr></thead><tbody>';
        if(!$filteredRecords)self::emptyRow(8,$records?'Keine Einträge für diesen Filter.':'Noch keine Sandbox-Synchronisierung.');
        foreach(array_slice($filteredRecords,0,500) as $r){
            $nearest=array_values((array)($r['nearest_rejected_families']??[]));$names=[];foreach($nearest as $n)$names[]=trim((string)($n['family_name']??''));
            $dataflowStatus=(string)($r['dataflow_status']??'MIGRATION_REQUIRED');$portal=(array)($r['portal_relevance']??[]);$matched=array_values((array)($r['local_matched_terms']??[]));$ex=(array)($r['exclusion_evidence']??[]);$nearestEx=(array)($ex['nearest_family_hits']??[]);
            $ext=(array)($r['external_relevance']??[]);$in=(array)($r['internal_proposal']??[]);$proposal=(array)($in['review_proposal']??[]);
            $localText=$dataflowStatus!=='VERIFIED'?'Datenfluss noch nicht verifiziert':($matched?('Portalwort erkannt: '.implode(', ',$matched).' · kein Relevanzurteil'):'kein eindeutiger lokaler Portalhinweis');$registryEx=(int)($ex['registry_wide_hit_count']??0);$exText=$dataflowStatus!=='VERIFIED'?'Datenfluss noch nicht verifiziert':($nearestEx?(count($nearestEx).' Treffer bei nächster Familie · '.$registryEx.' registryweit'):($registryEx>0?($registryEx.' registryweite Ausschlusstreffer · nur Evidenz'):'keine aktiven Ausschlusstreffer'));
            $extText=PSTE_Semantic_Review_Sandbox::effectiveRelevanceStatusForAdmin($r);$status=(string)($r['status']??'');
            echo '<tr><td><strong>'.esc_html((string)$r['query']).'</strong><br><small>Volumen: '.esc_html($r['search_volume']===null?'—':(string)$r['search_volume']).'</small></td><td>'.esc_html($localText).'</td><td>'.esc_html($exText).'<br><small>'.esc_html($dataflowStatus==='VERIFIED'?'vollständig gespeichert und Datenfluss verifiziert':'Migration/Verifikation erforderlich').'</small></td><td>'.esc_html($extText);
            if($ext){$ev=array_slice((array)($ext['evidence']??[]),0,5);if($ev){echo '<details><summary>SERP-Evidenz</summary><ol>';foreach($ev as $e)echo '<li><strong>'.esc_html((string)($e['title']??'' )).'</strong><br><small>'.esc_html((string)($e['domain']??'')).'</small></li>';echo '</ol></details>';}}
            echo '</td><td>'.esc_html($names?implode(' / ',$names):'—').'</td><td>'.esc_html((string)($proposal['planning_title_probe']??'—')).'<br><small>'.esc_html((string)($proposal['category_slug']??'')).' '.esc_html((string)($proposal['article_type']??'')).'</small></td><td><code>'.esc_html($status).'</code></td><td>';
            $reviewableExternal=((($ext['contract']??'')===PSTE_Sandbox_SEO_Relevance::CONTRACT)||(($ext['contract']??'')==='PSTE_SANDBOX_EXTERNAL_PROVIDER_OUTCOME_V1'&&!empty($ext['reviewable_external_evidence'])))&&(string)($ext['environment']??'')==='production'&&(string)($ext['status']??'')==='UNCERTAIN_REVIEW'&&preg_match('/^[a-f0-9]{64}$/',(string)($ext['response_sha256']??''));
            $currentAd=(array)($r['relevance_adjudication']??[]);$currentDecision=(string)($currentAd['decision']??'');$manualDecision=in_array($currentDecision,['RELEVANT_FOR_PORTAL','NOT_RELEVANT_FOR_PORTAL'],true)&&in_array((string)($currentAd['decision_source']??''),['EXPLICIT_ADMIN_REVIEW','EXPLICIT_ADMIN_REVIEW_REVISION'],true)&&preg_match('/^[a-f0-9]{64}$/',(string)($currentAd['decision_sha256']??''));$renderedReview=false;
            if($reviewableExternal&&($status==='UNCERTAIN_REVIEW'||$manualDecision)){
                $currentSha=$manualDecision?(string)($currentAd['decision_sha256']??''):'';
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin-bottom:8px">';wp_nonce_field('pste_sandbox_review_relevance');echo '<input type="hidden" name="action" value="pste_sandbox_review_relevance"><input type="hidden" name="sandbox_id" value="'.esc_attr((string)$r['sandbox_id']).'"><input type="hidden" name="expected_response_sha256" value="'.esc_attr((string)$ext['response_sha256']).'"><input type="hidden" name="expected_current_decision_sha256" value="'.esc_attr($currentSha).'"><select name="relevance_decision" required><option value="">Entscheidung…</option><option value="RELEVANT_FOR_PORTAL" '.($currentDecision==='RELEVANT_FOR_PORTAL'?'selected':'').'>Für Portal relevant</option><option value="NOT_RELEVANT_FOR_PORTAL" '.($currentDecision==='NOT_RELEVANT_FOR_PORTAL'?'selected':'').'>Nicht relevant</option></select><br><input type="text" class="regular-text" name="review_note" placeholder="'.esc_attr($manualDecision?'Korrektur begründen':'Kurze Begründung').'" required> ';submit_button($manualDecision?'Relevanzentscheidung ändern':'Relevanzentscheidung speichern','secondary','submit',false);if($manualDecision)echo '<br><small>Alte Entscheidung bleibt revisionssicher erhalten · aktuelle Revision: '.esc_html((string)max(1,(int)($currentAd['revision']??1))).'</small>';echo '</form>';$renderedReview=true;
            }
            if(in_array($status,['MATCHER_REVIEW','PROPOSAL_READY_FOR_REVIEW'],true)&&$in&&$proposal){
                $proposalSha=(string)($r['internal_proposal_sha256']??'');
                echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_sandbox_confirm_internal');echo '<input type="hidden" name="action" value="pste_sandbox_confirm_internal"><input type="hidden" name="sandbox_id" value="'.esc_attr((string)$r['sandbox_id']).'"><input type="hidden" name="expected_proposal_sha256" value="'.esc_attr($proposalSha).'"><input type="text" class="regular-text" name="review_note" placeholder="Zuordnung geprüft" required> ';submit_button('Für normalen Reentry vormerken','secondary','submit',false);echo '</form>';$renderedReview=true;
            }
            if(!$renderedReview){if($status==='DEFERRED_PROVIDER_ERROR')echo '<em>Providerfehler isoliert; Kandidat bleibt erhalten und wird erst nach den normalen offenen Fällen erneut versucht.</em>';elseif($status==='PROVIDER_TASK_REVIEW_REQUIRED')echo '<em>Providerfehler dauerhaft gespeichert; keine automatische Wiederholung mehr.</em>';elseif($status==='STRUCTURE_GAP')echo '<em>Strukturlücke bleibt erhalten; keine automatische Zuordnung.</em>';elseif($status==='READY_FOR_NORMAL_REENTRY_REVIEW')echo '<strong>Vorgemerkt.</strong><br><small>Noch kein Produktions-Handoff.</small>';else echo '—';}
            echo '</td></tr>';
        }
        echo '</tbody></table><p><small>Kein Datensatz wird gelöscht. Lokale Hinweise, Ausschlusssignale, Familiennähe, externe Evidenz und Review-Historie bleiben je Kandidat erhalten. Vor bestätigter Relevanz wird keine Familie, Kategorie oder Titelprobe freigegeben. Unklare externe Evidenz kann ausschließlich ausdrücklich menschlich entschieden werden; auch eine interne Bestätigung erzeugt noch keinen Produktions-Handoff.</small></p>';
    }

    private static function renderSettings(): void {
        try{PSTE_Research_Job::current();}catch(Throwable $ignored){}try{PSTE_Breadth_Research_Queue::current();}catch(Throwable $ignored){}
        $s=PSTE_Plugin::settings();$baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$state=is_array($baseline)?PSTE_Snapshot::baselineStatus($baseline):['status'=>'NOT_CAPTURED'];
        echo '<h2>Einstellungen und einheitlicher Rechercheworkflow</h2><p><strong>Ein Themenlauf = ein Klick.</strong> Danach sind Longtails recherchiert, zu Titeln verarbeitet, vorhandenen Kategorien zugeordnet und gegen den eigenen Portalbestand geprüft.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_save_settings');echo '<input type="hidden" name="action" value="pste_save_settings"><table class="form-table"><tr><th>Kostenpflichtige Longtail-Recherche</th><td><label><input type="checkbox" name="feature_enabled" value="1" '.checked(!empty($s['feature_enabled']),true,false).'> aktivieren</label></td></tr><tr><th>DataForSEO-Umgebung</th><td><select name="environment"><option value="sandbox" '.selected($s['environment'],'sandbox',false).'>Sandbox</option><option value="production" '.selected($s['environment'],'production',false).'>Production</option></select></td></tr><tr><th>Location</th><td><input name="location" value="'.esc_attr($s['location']).'"></td></tr><tr><th>Language</th><td><input name="language" value="'.esc_attr($s['language']).'"></td></tr><tr><th>Maximum Cost per Run</th><td><input type="number" step="0.01" min="0.01" max="10" name="run_budget_usd" value="'.esc_attr((string)$s['run_budget_usd']).'"> USD</td></tr><tr><th>GSC-Standardzeitraum</th><td><input type="number" min="7" max="480" name="gsc_default_days" value="'.esc_attr((string)$s['gsc_default_days']).'"> Tage</td></tr></table>';submit_button('Einstellungen speichern');echo '</form>';
        echo '<h3>Harte Grenzen</h3><table class="widefat striped" style="max-width:850px"><tbody>';self::row('Website-Gesamtbild',(string)($state['status']??'NOT_CAPTURED'));self::row('Google-Live-SERP-Prüfung','NUR SEMANTIC SANDBOX · KEIN HAUPTFILTER / KEINE PRODUKTION');self::row('Artikelinhalt / HTML / Design','UNANTASTBAR');self::row('Automatische Yoast-Änderungen','VERBOTEN');self::row('Automatische Artikelproduktion','VERBOTEN');echo '</tbody></table>';
        self::renderFamilyV2Audit();self::actionForm('pste_capture_baseline','pste_capture_baseline','Gesamtbestand neu erfassen');self::renderRunControls();
    }

    private static function renderRunControls(): void {
        $s=PSTE_Plugin::settings();
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
        $families=is_array($baseline)?PSTE_Category_Context::familyAnchors($baseline):[];
        $familyProgressInput=array_map(static fn(array $family)=>['term_id'=>(int)$family['term_id'],'name'=>(string)$family['topic_family_name'],'slug'=>(string)$family['topic_family_key']],$families);
        $progress=PSTE_Repository::categoryProgress($familyProgressInput);
        $latest=PSTE_Repository::latestRun();
        $active=null;$activeError='';$breadth=null;$breadthError='';
        try{$active=PSTE_Research_Job::current();}catch(Throwable $e){$activeError=sanitize_text_field((string)$e->getMessage());}
        try{$breadth=PSTE_Breadth_Research_Queue::current();}catch(Throwable $e){$breadthError=sanitize_text_field((string)$e->getMessage());}
        echo '<h3>Longtails recherchieren, Titel bilden und Kategorien zuordnen</h3>';
        echo '<p><strong>Normalbetrieb:</strong> Für Einzelprüfungen bleibt der bisherige Ein-Familien-Lauf erhalten. Für die reguläre Portalbefüllung gibt es jetzt den <strong>Breitenlauf</strong>: 1 bis 4 noch nicht analysierte Themenfamilien werden automatisch aus möglichst unterschiedlichen Portal-Hauptzweigen gewählt und nacheinander recherchiert. Eine Kostenbestätigung startet die komplette gewählte Serie; jeder Einzellauf behält seine eigene Budgetgrenze.</p>';
        if(empty($s['feature_enabled'])){echo '<p><em>Kostenpflichtige Longtail-Recherche ist AUS.</em></p>';return;}
        if($activeError!==''||$breadthError!==''){echo '<div class="notice notice-error inline"><p><strong>Gespeicherter Rechercheauftrag ist ungültig:</strong> '.esc_html(trim($activeError.' '.$breadthError)).'</p></div>';return;}
        $nonce=wp_create_nonce('pste_research_ajax');
        $redirect=admin_url('admin.php?page='.self::TABS['settings']['slug'].'&research_complete=1');
        $breadthStatus=is_array($breadth)?(string)($breadth['status']??''):'';
        if(is_array($breadth)&&in_array($breadthStatus,['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true)){
            echo '<div class="pste-box" id="pste-active-breadth"><p><strong>Breitenlauf:</strong> <span id="pste-breadth-status">'.esc_html($breadthStatus).'</span> · Familien <span id="pste-breadth-progress">'.esc_html((string)($breadth['completed_count']??0)).' von '.esc_html((string)($breadth['item_count']??0)).'</span></p>';
            $current=(array)($breadth['items'][(int)($breadth['current_index']??0)]??[]);
            if($current)echo '<p><strong>Aktuell:</strong> '.esc_html((string)($current['family']??'')).' · Hauptzweig <code>'.esc_html((string)($current['root']??'')).'</code></p>';
            if((string)($breadth['last_error']??'')!=='')echo '<p><strong>Letzter Fehler:</strong> <code>'.esc_html((string)$breadth['last_error']).'</code></p>';elseif((string)($breadth['coordination_wait_code']??'')!=='')echo '<p><strong>Interne Koordination:</strong> <code>'.esc_html((string)$breadth['coordination_wait_code']).'</code> · wird automatisch fortgesetzt.</p>';
            if($breadthStatus==='PAUSED_ERROR')echo '<button type="button" class="button button-primary" id="pste-breadth-resume">Breitenlauf sicher fortsetzen</button>';
            if($breadthStatus==='OUTCOME_UNKNOWN')echo '<p><strong>Fail-closed:</strong> Der Provider-Ausgang eines bereits gesendeten Kindlaufs ist unbekannt. Es wird nichts automatisch erneut gesendet.</p>';
            echo '</div>';
        }elseif(is_array($active)){
            $status=(string)$active['status'];
            echo '<div class="pste-box" id="pste-active-research"><p><strong>Gespeicherter Einzellauf:</strong> <span id="pste-job-status">'.esc_html($status).'</span> · Datenquellen <span id="pste-job-progress">'.esc_html((string)$active['progress']).' von '.esc_html((string)$active['total_provider_steps']).'</span> · Kosten <span id="pste-job-cost">'.esc_html(number_format((float)$active['actual_cost'],6,'.','')).' USD</span></p><p id="pste-job-message">'.esc_html($status==='PAUSED_ERROR'?'Der Lauf wurde nach einem klaren Fehler sicher angehalten. Ein Klick setzt nur den offenen Abschnitt fort.':($status==='OUTCOME_UNKNOWN'?'Der Ausgang einer gesendeten Provideranfrage ist unbekannt. Es erfolgt keine automatische Wiederholung.':'Der bereits freigegebene Lauf wird nach Seitenaufruf automatisch sicher fortgesetzt.')).'</p>';
            if((string)$active['last_error']!=='')echo '<p><strong>Letzter Fehler:</strong> <code id="pste-job-error">'.esc_html((string)$active['last_error']).'</code></p>';
            if($status==='PAUSED_ERROR')echo '<button type="button" class="button button-primary" id="pste-resume-research">Lauf automatisch fortsetzen</button>';
            if($status==='OUTCOME_UNKNOWN')echo '<p><label><input type="checkbox" id="pste-provider-checked"> Providerkonto wurde auf die möglicherweise berechnete Anfrage geprüft</label></p><button type="button" class="button" id="pste-cancel-research">Geprüften unklaren Lauf verwerfen</button>';
            echo '</div>';
        }else{
            if(is_array($breadth)&&$breadthStatus==='COMPLETE')echo '<div class="notice notice-success inline"><p><strong>Letzter Breitenlauf abgeschlossen:</strong> '.esc_html((string)($breadth['completed_count']??0)).' von '.esc_html((string)($breadth['item_count']??0)).' Themenfamilien.</p></div>';
            echo '<div class="pste-box"><h4>Breitenrecherche · empfohlen für die reguläre Portalbefüllung</h4><p>Das System wählt dynamisch offene Familien und streut zuerst über unterschiedliche Hauptzweige. Keine fest codierten Themen oder Portalnamen.</p><label><strong>Anzahl Themenfamilien:</strong> <select id="pste-breadth-count"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4" selected>4</option></select></label> &nbsp; <label><input type="checkbox" id="pste-breadth-confirm-cost"> Kosten für bis zu diese Anzahl regulärer Einzelläufe bestätigen</label> <button type="button" class="button button-primary" id="pste-breadth-start">Breitenrecherche starten</button></div>';
            $rank=['NOT_ANALYZED'=>0,'BLOCKED'=>1,'ANALYZED'=>2];
            usort($progress['items'],static fn($a,$b)=>[$rank[$a['state']]??9,$a['name']]<=>[$rank[$b['state']]??9,$b['name']]);
            echo '<details style="margin-top:14px"><summary>Einzelne Themenfamilie manuell recherchieren</summary><form id="pste-run-form" style="margin-top:12px"><div class="pste-run-grid"><label><strong>Themenfamilie suchen</strong><br><input id="pste-category-search" class="regular-text" type="search" placeholder="z. B. Themenbegriff"></label><label><strong>Themenfamilie</strong><br><select id="pste-category-select" name="category_id" required><option value="">Themenfamilie auswählen</option>';
            foreach($progress['items'] as $i){if(strcasecmp((string)$i['name'],'Uncategorized')===0)continue;echo '<option value="'.esc_attr((string)$i['term_id']).'" data-name="'.esc_attr(strtolower((string)$i['name'])).'" data-state="'.esc_attr((string)$i['state']).'" data-seed="'.esc_attr((string)$i['name']).'">'.esc_html($i['name'].' · '.$i['state']).'</option>';}
            echo '</select></label><label><strong>Ausgangsbegriff</strong><br><input id="pste-seed" name="seed" required placeholder="wird aus Themenfamilie übernommen"></label></div><p><button type="button" class="button" id="pste-next-category">Nächste offene Themenfamilie auswählen</button></p><label><input type="checkbox" id="pste-confirm-cost" name="confirm_cost" value="1" required> Kosten bestätigen</label> <button type="submit" class="button" id="pste-start-research">Einzellauf starten</button></form></details>';
        }
        if(isset($_GET['transport_recovery']))echo '<div class="notice notice-warning inline"><p><strong>Transportstatus neu eingelesen.</strong> Eine unvollständige AJAX-Antwort wurde nicht erneut gesendet. Ein bereits angelegter RUNNING-Auftrag wird aus dem persistenten Serverstatus sicher fortgesetzt.</p></div>';
        echo '<div id="pste-research-feedback" class="notice notice-info inline" style="display:none"><p></p></div>';
        $config=wp_json_encode(['ajax_url'=>admin_url('admin-ajax.php'),'nonce'=>$nonce,'redirect'=>$redirect,'active'=>$active,'breadth'=>$breadth],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        echo '<script>(function(){"use strict";const cfg='.$config.',feedback=document.getElementById("pste-research-feedback"),form=document.getElementById("pste-run-form"),resume=document.getElementById("pste-resume-research"),cancel=document.getElementById("pste-cancel-research"),breadthStart=document.getElementById("pste-breadth-start"),breadthResume=document.getElementById("pste-breadth-resume");const sleep=ms=>new Promise(r=>setTimeout(r,ms));function message(text,error){if(!feedback)return;feedback.style.display="block";feedback.className="notice "+(error?"notice-error":"notice-info")+" inline";feedback.querySelector("p").textContent=text;}function transportRecovery(action,status,length){try{sessionStorage.setItem("pste_transport_recovery",JSON.stringify({action:action,status:status,length:length,at:Date.now()}));}catch(e){}const join=cfg.redirect.indexOf("?")>=0?"&":"?";window.location.href=cfg.redirect+join+"transport_recovery=1";}async function call(action,data){const body=new URLSearchParams(Object.assign({action:action,nonce:cfg.nonce},data||{}));const response=await fetch(cfg.ajax_url,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8","Accept":"application/json"},body:body.toString()});const raw=await response.text();let json;try{json=JSON.parse((raw||"").replace(/^\\uFEFF/,"").trim());}catch(e){transportRecovery(action,response.status,(raw||"").length);return new Promise(()=>{});}if(!response.ok||!json.success)throw new Error((json.data&&json.data.error_code)||("PSTE_AJAX_REQUEST_FAILED_HTTP_"+response.status));return json.data;}function renderJob(job){const s=document.getElementById("pste-job-status"),p=document.getElementById("pste-job-progress"),c=document.getElementById("pste-job-cost");if(s)s.textContent=job.status;if(p)p.textContent=job.progress+" von "+job.total_provider_steps;if(c)c.textContent=Number(job.actual_cost||0).toFixed(6)+" USD";message("Einzellauf: "+job.status+" · Datenquellen "+job.progress+" von "+job.total_provider_steps,false);}async function singleLoop(job,explicitResume){let current=job,first=!!explicitResume;for(let guard=0;guard<120;guard++){renderJob(current);if(current.status==="COMPLETE"){window.location.href=cfg.redirect;return;}if(current.status==="PAUSED_ERROR"&&!first){message("Sicher angehalten: "+(current.last_error||"PSTE_RESEARCH_PAUSED"),true);return;}if(current.status==="OUTCOME_UNKNOWN"){message("Nicht erneut gesendet: "+(current.last_error||"PSTE_PROVIDER_TRANSPORT_OUTCOME_UNKNOWN"),true);return;}await sleep(300);const data=await call("pste_research_advance",{job_uuid:current.job_uuid,explicit_resume:first?"1":"0"});current=data.job;first=false;if(data.busy){message("Einzellauf wartet auf interne Koordination – sicherer Readback, keine Doppelanfrage …",false);await sleep(Math.max(750,Number(data.retry_after_ms||1500)));}}throw new Error("PSTE_AUTOMATIC_SEQUENCE_GUARD_EXCEEDED");}function renderBreadth(q){const s=document.getElementById("pste-breadth-status"),p=document.getElementById("pste-breadth-progress");if(s)s.textContent=q.status;if(p)p.textContent=q.completed_count+" von "+q.item_count;const cur=(q.items||[])[q.current_index];message("Breitenlauf: "+q.status+" · "+q.completed_count+" von "+q.item_count+(cur?" · aktuell "+cur.family:""),false);}async function breadthLoop(queue,explicitResume){let q=queue,first=!!explicitResume;for(let guard=0;guard<180;guard++){renderBreadth(q);if(q.status==="COMPLETE"){window.location.href=cfg.redirect+"&breadth_complete=1";return;}if(q.status==="PAUSED_ERROR"&&!first){message("Breitenlauf sicher angehalten: "+(q.last_error||"PSTE_BREADTH_QUEUE_PAUSED"),true);return;}if(q.status==="OUTCOME_UNKNOWN"){message("Breitenlauf fail-closed: Provider-Ausgang unbekannt; keine automatische Wiederholung.",true);return;}await sleep(300);const data=await call("pste_breadth_research_advance",{queue_uuid:q.queue_uuid,explicit_resume:first?"1":"0"});q=data.queue;first=false;if(data.busy){message("Breitenlauf läuft bereits serverseitig weiter – warte auf sicheren Readback …",false);await sleep(Math.max(750,Number(data.retry_after_ms||1500)));}}throw new Error("PSTE_BREADTH_SEQUENCE_GUARD_EXCEEDED");}if(breadthStart)breadthStart.addEventListener("click",async()=>{breadthStart.disabled=true;try{const confirm=document.getElementById("pste-breadth-confirm-cost"),count=document.getElementById("pste-breadth-count");if(!confirm||!confirm.checked)throw new Error("Bitte Kosten für den Breitenlauf bestätigen.");const data=await call("pste_breadth_research_start",{count:count?count.value:"4",confirm_cost:"1"});await breadthLoop(data.queue,false);}catch(e){message(e.message||"PSTE_BREADTH_START_FAILED",true);breadthStart.disabled=false;}});if(breadthResume)breadthResume.addEventListener("click",async()=>{breadthResume.disabled=true;try{await breadthLoop(cfg.breadth,true);}catch(e){message(e.message||"PSTE_BREADTH_RESUME_FAILED",true);breadthResume.disabled=false;}});if(form){const search=document.getElementById("pste-category-search"),sel=document.getElementById("pste-category-select"),seed=document.getElementById("pste-seed"),next=document.getElementById("pste-next-category"),start=document.getElementById("pste-start-research");function filter(){const q=(search.value||"").toLowerCase();for(const o of sel.options){if(!o.value)continue;o.hidden=!!q&&!o.dataset.name.includes(q);}if(sel.selectedOptions[0]&&sel.selectedOptions[0].hidden){sel.value="";seed.value="";}}function choose(o){sel.value=o.value;seed.value=o.dataset.seed||"";}search.addEventListener("input",filter);sel.addEventListener("change",()=>{const o=sel.selectedOptions[0];if(o&&o.value)seed.value=o.dataset.seed||"";});next.addEventListener("click",()=>{const candidates=[...sel.options].filter(o=>o.value&&!o.hidden&&o.dataset.state==="NOT_ANALYZED");if(candidates.length)choose(candidates[0]);});form.addEventListener("submit",async e=>{e.preventDefault();if(!form.reportValidity())return;start.disabled=true;message("Recherche wird gestartet …",false);try{const data=await call("pste_research_start",{category_id:sel.value,seed:seed.value,confirm_cost:document.getElementById("pste-confirm-cost").checked?"1":"0"});await singleLoop(data.job,false);}catch(err){message(err.message||"PSTE_RESEARCH_START_FAILED",true);start.disabled=false;}});}if(resume)resume.addEventListener("click",async()=>{resume.disabled=true;try{await singleLoop(cfg.active,true);}catch(err){message(err.message||"PSTE_RESEARCH_RESUME_FAILED",true);resume.disabled=false;}});if(cancel)cancel.addEventListener("click",async()=>{const checked=document.getElementById("pste-provider-checked");if(!checked||!checked.checked){message("Providerprüfung muss ausdrücklich bestätigt werden.",true);return;}cancel.disabled=true;try{await call("pste_research_cancel",{job_uuid:cfg.active.job_uuid,provider_checked:"1"});window.location.reload();}catch(err){message(err.message||"PSTE_RESEARCH_CANCEL_FAILED",true);cancel.disabled=false;}});if(cfg.breadth&&cfg.breadth.status==="RUNNING")setTimeout(()=>breadthLoop(cfg.breadth,false).catch(e=>message(e.message,true)),250);else if(cfg.active&&cfg.active.status==="RUNNING")setTimeout(()=>singleLoop(cfg.active,false).catch(e=>message(e.message,true)),250);})();</script>';
        if($latest){echo '<p><strong>Letzter abgeschlossener Lauf:</strong> '.esc_html((string)$latest['status']).' · '.esc_html((string)($latest['payload']['usable_candidate_count']??0)).' direkt nutzbare Themen · '.esc_html((string)($latest['payload']['manual_followup_steps_required']??0)).' erforderliche Folgeklicks.</p>';self::actionForm('pste_export_overlay','pste_export_overlay','Letztes Overlay exportieren');self::actionForm('pste_export_topic_map','pste_export_topic_map','Gesamte Themenkarte exportieren');}
    }

    private static function renderFamilyV2Audit(): void {
        $dry=PSTE_Family_Reclassification_V2::storedDryRun();$auth=PSTE_Family_Reclassification_V2::storedAuthorization();$apply=PSTE_Family_Reclassification_V2::storedApply();$rollback=PSTE_Family_Reclassification_V2::storedRollback();
        echo '<section class="pste-box"><h3>Familienidentität V2 · Bestandsaudit und kontrollierte Korrektur</h3><p><strong>Hauptregel 1:</strong> Dieser Ablauf liest veröffentlichte Artikel und Entwürfe ausschließlich zum Hashvergleich. Er verändert niemals Beiträge, Titel, Slugs, Kategorien, Metadaten, Text, HTML, CSS, Design, PPM, Compiler oder Qualitätsregeln.</p>';
        if(($dry['contract']??'')===PSTE_Family_Reclassification_V2::DRY_RUN_CONTRACT){echo '<p><strong>Dry-run:</strong> vorhanden · '.esc_html((string)($dry['item_count']??0)).' gespeicherte Longtails geprüft · Hash <code>'.esc_html(substr((string)($dry['dry_run_sha256']??''),0,16)).'…</code></p>';echo '<p><strong>Ergebnisse:</strong> '.esc_html(wp_json_encode((array)($dry['classification_counts']??[]),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'</p>';self::actionForm('pste_family_v2_export_dry_run','pste_family_v2_export_dry_run','V2-Dry-run vollständig exportieren');}else echo '<p><strong>Dry-run:</strong> noch nicht ausgeführt. Der Start erzeugt zuerst einen neuen, einzelnen und widerspruchsfreien Live-Snapshot.</p>';
        self::actionForm('pste_family_v2_dry_run','pste_family_v2_dry_run','Vollständigen V2-Bestandsaudit (Quellbestand schreibfrei) starten','primary');
        echo '<hr><h4>Claude-/Nutzerfreigabe importieren</h4><p>Ein Import entsperrt noch nichts automatisch. Er muss an exakt denselben Snapshot-, Registry- und Dry-run-Hash gebunden sein und die freigegebenen Änderungs-IDs einzeln nennen.</p><form method="post" enctype="multipart/form-data" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_family_v2_import_authorization');echo '<input type="hidden" name="action" value="pste_family_v2_import_authorization"><input type="file" name="authorization_json" accept=".json,application/json" required> ';submit_button('Freigabedatei nur prüfen und importieren','secondary','submit',false);echo '</form>';
        $authorized=($auth['contract']??'')===PSTE_Family_Reclassification_V2::AUTH_CONTRACT;echo '<p><strong>Apply:</strong> '.($authorized?'<span class="pste-badge pste-review_required">AUTORISIERUNG IMPORTIERT</span>':'<span class="pste-badge pste-blocked">TECHNISCH GESPERRT</span>').'</p>';
        if($authorized&&(($apply['status']??'')!=='PASS')){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_family_v2_apply');echo '<input type="hidden" name="action" value="pste_family_v2_apply"><label><input type="checkbox" name="confirm_apply" value="1" required> Exakt autorisierten, snapshotgebundenen Apply ausführen</label> ';submit_button('Kontrollierten V2-Apply ausführen','secondary','submit',false);echo '</form>';}
        if(($apply['status']??'')==='PASS'){echo '<p><strong>Letzter Apply:</strong> PASS · '.esc_html((string)($apply['write_count']??0)).' interne PSTE-Schreiboperationen · Artikelwächter unverändert.</p>';if(($rollback['status']??'')!=='PASS'){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';wp_nonce_field('pste_family_v2_rollback');echo '<input type="hidden" name="action" value="pste_family_v2_rollback"><label><input type="checkbox" name="confirm_rollback" value="1" required> Exakten V2-Apply zurücksetzen</label> ';submit_button('Kontrollierten Rollback ausführen','secondary','submit',false);echo '</form>';}}
        if(($rollback['status']??'')==='PASS')echo '<p><strong>Rollback:</strong> PASS.</p>';
        echo '</section>';
    }

    public static function saveSettings(): void {try{PSTE_Auth::assertAdmin('pste_save_settings',(string)($_POST['_wpnonce']??''));PSTE_Credentials::assertNoCredentialPayload($_POST);$s=PSTE_Plugin::settings();$s['feature_enabled']=isset($_POST['feature_enabled']);$s['environment']=($_POST['environment']??'sandbox')==='production'?'production':'sandbox';$s['location']=sanitize_text_field((string)($_POST['location']??'Germany'));$s['language']=sanitize_text_field((string)($_POST['language']??'German'));$s['run_budget_usd']=min(10,max(.01,(float)($_POST['run_budget_usd']??8)));$s['gsc_default_days']=min(480,max(7,(int)($_POST['gsc_default_days']??90)));update_option(PSTE_OPTION_SETTINGS,$s,false);self::redirect('settings','updated=1');}catch(Throwable $e){self::blocked('settings',$e);}}
    public static function saveCredentials(): void {try{PSTE_Auth::assertAdmin('pste_save_credentials',(string)($_POST['_wpnonce']??''));PSTE_Credentials::saveFromAdmin((string)($_POST['api_login']??''),(string)($_POST['api_password']??''),(string)($_POST['api_credentials_base64']??''));self::redirect('sources','credentials_saved=1');}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function captureBaseline(): void {try{PSTE_Auth::assertAdmin('pste_capture_baseline',(string)($_POST['_wpnonce']??''));PSTE_Runner::captureSiteBaseline();self::redirect('overview','baseline_captured=1');}catch(Throwable $e){self::blocked('overview',$e);}}
    public static function connectionTest(): void {PSTE_Auth::assertAdmin('pste_connection_test',(string)($_POST['_wpnonce']??''));$s=PSTE_Plugin::settings();try{$r=PSTE_Runner::connectionTest($s['environment']);PSTE_Credentials::recordConnectionSuccess($s['environment']);set_transient('pste_connection_test_result',$r,300);self::redirect('sources','connection_ok=1');}catch(Throwable $e){PSTE_Credentials::recordConnectionError($s['environment'],$e->getMessage());self::blocked('sources',$e);}}
    public static function saveGscClient(): void {try{PSTE_Auth::assertAdmin('pste_save_gsc_client',(string)($_POST['_wpnonce']??''));PSTE_GSC_Credentials::saveClient((string)($_POST['client_id']??''),(string)($_POST['client_secret']??''));self::redirect('sources','gsc_client_saved=1');}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function gscConnect(): void {try{PSTE_Auth::assertAdmin('pste_gsc_connect',(string)($_POST['_wpnonce']??''));wp_safe_redirect(PSTE_GSC_Client::authorizationUrl());exit;}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function gscOauthCallback(): void {try{PSTE_Auth::assertAdmin();if(!empty($_GET['error']))throw new RuntimeException('PSTE_GSC_OAUTH_'.sanitize_key((string)$_GET['error']));PSTE_GSC_Client::handleCallback(sanitize_text_field((string)($_GET['code']??'')),sanitize_text_field((string)($_GET['state']??'')));self::redirect('sources','gsc_connected=1');}catch(Throwable $e){PSTE_GSC_Credentials::recordStatus('ERROR',$e->getMessage(),null);self::blocked('sources',$e);}}
    public static function gscTest(): void {try{PSTE_Auth::assertAdmin('pste_gsc_test',(string)($_POST['_wpnonce']??''));PSTE_GSC_Client::listSites();PSTE_GSC_Credentials::recordStatus('CONNECTED',null,null);self::redirect('sources','gsc_test_ok=1');}catch(Throwable $e){PSTE_GSC_Credentials::recordStatus('ERROR',$e->getMessage(),null);self::blocked('sources',$e);}}
    public static function gscSaveProperty(): void {try{PSTE_Auth::assertAdmin('pste_gsc_save_property',(string)($_POST['_wpnonce']??''));$url=sanitize_text_field((string)($_POST['property_url']??''));$sites=get_option(PSTE_OPTION_GSC_SITES_CACHE,[]);$allowed=array_column($sites['items']??[],'site_url');if($url===''||!in_array($url,$allowed,true))throw new RuntimeException('PSTE_GSC_PROPERTY_NOT_ALLOWED');update_option(PSTE_OPTION_GSC_SELECTED_PROPERTY,$url,false);self::redirect('sources','gsc_property_saved=1');}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function gscSync(): void {try{PSTE_Auth::assertAdmin('pste_gsc_sync',(string)($_POST['_wpnonce']??''));$property=(string)get_option(PSTE_OPTION_GSC_SELECTED_PROPERTY,'');PSTE_Runner::syncSearchConsole($property,sanitize_text_field((string)($_POST['start_date']??'')),sanitize_text_field((string)($_POST['end_date']??'')));self::redirect('sources','gsc_synced=1');}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function gscDisconnect(): void {PSTE_Auth::assertAdmin('pste_gsc_disconnect',(string)($_POST['_wpnonce']??''));PSTE_GSC_Credentials::disconnect();self::redirect('sources','gsc_disconnected=1');}
    public static function saveCategoryWeights(): void {try{PSTE_Auth::assertAdmin('pste_save_category_weights',(string)($_POST['_wpnonce']??''));PSTE_Analytics::saveStrategicWeights(is_array($_POST['weights']??null)?$_POST['weights']:[]);self::redirect('coverage','weights_saved=1');}catch(Throwable $e){self::blocked('coverage',$e);}}
    public static function importEditorialPlan(): void {PSTE_Auth::assertAdmin('pste_import_editorial_plan',(string)($_POST['_wpnonce']??''));if(empty($_FILES['editorial_plan_json']['tmp_name'])||!is_uploaded_file($_FILES['editorial_plan_json']['tmp_name']))wp_die('PSTE_EDITORIAL_PLAN_UPLOAD_MISSING');try{$raw=(string)file_get_contents($_FILES['editorial_plan_json']['tmp_name']);$decoded=json_decode($raw,true,512,JSON_THROW_ON_ERROR);$items=[];if(isset($decoded['items'])&&is_array($decoded['items']))$items=$decoded['items'];elseif(isset($decoded['articles'])&&is_array($decoded['articles']))$items=$decoded['articles'];elseif(self::isList($decoded))$items=$decoded;if(!$items)throw new RuntimeException('PSTE_EDITORIAL_PLAN_ITEMS_MISSING');$clean=[];foreach($items as $item){if(!is_array($item))continue;$title=trim((string)($item['title']??$item['primary_longtail_query']??$item['article_title']??''));if($title==='')continue;$clean[]=['title'=>$title,'primary_longtail_query'=>(string)($item['primary_longtail_query']??$title),'category_name'=>(string)($item['category_name']??$item['target_category_name']??''),'intent_cluster_id'=>(string)($item['intent_cluster_id']??''),'headings'=>is_array($item['headings']??null)?array_values($item['headings']):[],'source_reference'=>(string)($item['canonical_article_id']??$item['plan_slot_sha256']??'')];}if(!$clean)throw new RuntimeException('PSTE_EDITORIAL_PLAN_VALID_ITEMS_MISSING');update_option(PSTE_OPTION_EDITORIAL_PLAN_IMPORT,['contract'=>'PSTE_IMPORTED_EDITORIAL_PLAN_V1','imported_at_utc'=>gmdate('c'),'items'=>$clean],false);self::redirect('sources','editorial_plan_imported=1');}catch(Throwable $e){self::blocked('sources',$e);}}

    public static function overrideTitle(): void {
        PSTE_Auth::assertAdmin('pste_override_title',(string)($_POST['_wpnonce']??''));
        try{$poolKey=sanitize_text_field((string)($_POST['pool_key']??''));$title=sanitize_text_field((string)($_POST['manual_title']??''));PSTE_Repository::saveManualTitleOverride($poolKey,$title,get_current_user_id());self::redirect('review','title_override_saved=1');}catch(Throwable $e){self::blocked('review',$e);}
    }

    public static function reviewCandidate(): void {
        PSTE_Auth::assertAdmin('pste_review_candidate',(string)($_POST['_wpnonce']??''));
        try{$poolKey=sanitize_text_field((string)($_POST['pool_key']??''));$status=sanitize_key((string)($_POST['review_status']??''));$status=strtoupper($status);$categoryId=(int)($_POST['target_category_id']??0);$categoryName=sanitize_text_field((string)($_POST['target_category_name']??''));if($categoryId<=0&&$categoryName!=='')$categoryId=PSTE_Repository::categoryIdFromName($categoryName);$articleType=sanitize_text_field((string)($_POST['target_article_type']??''));$note=sanitize_text_field((string)($_POST['review_note']??''));PSTE_Repository::saveManualDecision($poolKey,$status,$categoryId,$articleType,$note,get_current_user_id(),!empty($_POST['confirm_hard_override']));self::redirect('review','review_saved=1');}catch(Throwable $e){self::blocked('review',$e);}
    }


    public static function retrySafeMigration(): void {
        PSTE_Auth::assertAdmin('pste_retry_safe_migration',(string)($_POST['_wpnonce']??''));
        try{PSTE_Safe_Migration_Job::start('MANUAL_POST_FALLBACK');self::redirect('overview','safe_migration_started=1');}catch(Throwable $e){self::blocked('overview',$e);}
    }

    public static function safeMigrationStartAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{PSTE_Auth::assertAdmin('pste_safe_migration_ajax',(string)($_POST['nonce']??''));$job=PSTE_Safe_Migration_Job::start('MANUAL_AJAX');self::ajaxSuccess(['job'=>$job],$level);}
        catch(Throwable $e){self::ajaxError($e,$level,400);}
    }
    public static function safeMigrationAdvanceAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_safe_migration_ajax',(string)($_POST['nonce']??''));
            $job=PSTE_Safe_Migration_Job::advance(sanitize_text_field((string)($_POST['job_uuid']??'')),!empty($_POST['explicit_resume']));
            self::ajaxSuccess(['job'=>$job],$level);
        }catch(Throwable $e){
            if((string)$e->getMessage()==='PSTE_SAFE_MIGRATION_STEP_ALREADY_RUNNING'){
                try{$cur=PSTE_Safe_Migration_Job::current();if(is_array($cur)){self::ajaxSuccess(['job'=>PSTE_Safe_Migration_Job::publicState($cur),'busy'=>true],$level);}}catch(Throwable $ignored){}
            }
            self::ajaxError($e,$level,400);
        }
    }

    public static function processContextBatch(): void {try{PSTE_Auth::assertAdmin('pste_process_context_batch',(string)($_POST['_wpnonce']??''));$job=PSTE_Context_Refresh::processBatch();if((string)($job['status']??'')==='BLOCKED')throw new RuntimeException((string)($job['error_code']??'PSTE_CONTEXT_REFRESH_FAILED'));self::redirect('overview','context_batch_processed=1');}catch(Throwable $e){self::blocked('overview',$e);}}

    public static function contextAdvanceAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_context_ajax',(string)($_POST['nonce']??''));
            $job=PSTE_Context_Refresh::processBatch();
            if((string)($job['status']??'')==='BLOCKED')throw new RuntimeException((string)($job['error_code']??'PSTE_CONTEXT_REFRESH_FAILED'));
            self::ajaxSuccess(['job'=>self::contextPublicState($job)],$level);
        }catch(Throwable $e){self::ajaxError($e,$level,400);}
    }

    public static function importGsc(): void {PSTE_Auth::assertAdmin('pste_import_gsc',(string)($_POST['_wpnonce']??''));if(empty($_FILES['gsc_csv']['tmp_name'])||!is_uploaded_file($_FILES['gsc_csv']['tmp_name']))wp_die('PSTE_GSC_UPLOAD_MISSING');try{update_option(PSTE_OPTION_FIRST_PARTY,PSTE_First_Party_Import::parseCsv($_FILES['gsc_csv']['tmp_name']),false);self::redirect('sources','gsc_imported=1');}catch(Throwable $e){self::blocked('sources',$e);}}
    public static function repairPriceIntents(): void {
        PSTE_Auth::assertAdmin('pste_repair_price_intents',(string)($_POST['_wpnonce']??''));
        try{
            $report=PSTE_Repository::repairPriceIntentCandidates();
            $reportStatus=(string)($report['status']??'');
            if(!in_array($reportStatus,['PASS','PARTIAL_PASS','BLOCKED'],true))throw new RuntimeException('PSTE_PRICE_INTENT_REPAIR_NOT_PASSED');
            $keys=array_values(array_unique(array_filter(array_map('strval',(array)($report['context_refresh_pool_keys']??[])))));
            if($keys){
                $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);
                if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');
                $inventory=PSTE_Snapshot::inventory();$structure=PSTE_Snapshot::structure();$plan=PSTE_Snapshot::editorialPlan();
                if((string)($baseline['inventory_sha256']??'')!==(string)($inventory['sha256']??'')
                    ||(string)($baseline['structure_sha256']??'')!==(string)($structure['sha256']??'')
                    ||(string)($baseline['editorial_plan_sha256']??'NOT_AVAILABLE')!==(string)($plan['sha256']??'NOT_AVAILABLE')){
                    throw new RuntimeException('PSTE_PRICE_INTENT_REPAIR_SNAPSHOT_STALE');
                }
                $context=PSTE_Repository::refreshPortalContextForKeys($keys,$inventory,$plan,(string)$structure['sha256']);
                if((int)($context['processed']??-1)!==count($keys))throw new RuntimeException('PSTE_PRICE_INTENT_REPAIR_CONTEXT_REFRESH_INCOMPLETE');
                $report['context_refresh']=$context;
            }
            $marker=['status'=>$reportStatus,'completed_at_utc'=>gmdate('c'),'plugin_version'=>PSTE_VERSION,'report'=>$report];
            $marker['sha256']=hash('sha256',wp_json_encode($marker,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION));
            update_option(PSTE_OPTION_PRICE_INTENT_REPAIR,$marker,false);
            $readback=get_option(PSTE_OPTION_PRICE_INTENT_REPAIR,[]);
            if(!is_array($readback)||!hash_equals((string)$marker['sha256'],(string)($readback['sha256']??'')))throw new RuntimeException('PSTE_PRICE_INTENT_REPAIR_MARKER_NOT_PERSISTED');
            self::redirect('overview',$reportStatus==='PASS'?'price_intent_repaired=1':'price_intent_partial=1');
        }catch(Throwable $e){self::blocked('overview',$e);}
    }

    public static function researchStartAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            if(empty($_POST['confirm_cost']))throw new RuntimeException('PSTE_COST_CONFIRMATION_REQUIRED');
            $job=PSTE_Research_Job::start((int)($_POST['category_id']??0),sanitize_text_field((string)($_POST['seed']??'')),PSTE_Plugin::settings());
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job],$level);
    }
    public static function researchAdvanceAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            $job=PSTE_Research_Job::advance(sanitize_text_field((string)($_POST['job_uuid']??'')),PSTE_Plugin::settings(),!empty($_POST['explicit_resume']));
        }catch(Throwable $e){
            if((string)$e->getMessage()==='PSTE_RESEARCH_STEP_ALREADY_RUNNING'){
                try{$current=PSTE_Research_Job::current();}catch(Throwable $ignored){$current=null;}
                if(is_array($current)){self::ajaxSuccess(['job'=>$current,'busy'=>true,'retry_after_ms'=>1500],$level);return;}
            }
            self::ajaxError($e,$level,400);return;
        }
        $busy=(string)($job['coordination_wait_code']??'')!=='';
        self::ajaxSuccess(['job'=>$job,'busy'=>$busy,'retry_after_ms'=>$busy?1500:0],$level);
    }
    public static function breadthResearchStartAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            if(empty($_POST['confirm_cost']))throw new RuntimeException('PSTE_COST_CONFIRMATION_REQUIRED');
            $queue=PSTE_Breadth_Research_Queue::start((int)($_POST['count']??4),PSTE_Plugin::settings());
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['queue'=>$queue],$level);
    }
    public static function breadthResearchAdvanceAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            $queue=PSTE_Breadth_Research_Queue::advance(sanitize_text_field((string)($_POST['queue_uuid']??'')),PSTE_Plugin::settings(),!empty($_POST['explicit_resume']));
        }catch(Throwable $e){
            if((string)$e->getMessage()==='PSTE_RESEARCH_STEP_ALREADY_RUNNING'){
                try{$current=PSTE_Breadth_Research_Queue::current();}catch(Throwable $ignored){$current=null;}
                if(is_array($current)){self::ajaxSuccess(['queue'=>$current,'busy'=>true,'retry_after_ms'=>1500],$level);return;}
            }
            self::ajaxError($e,$level,400);return;
        }
        $busy=(string)($queue['coordination_wait_code']??'')!=='';
        self::ajaxSuccess(['queue'=>$queue,'busy'=>$busy,'retry_after_ms'=>$busy?1500:0],$level);
    }

    public static function exportOverlay(): void {PSTE_Auth::assertAdmin('pste_export_overlay',(string)($_POST['_wpnonce']??''));$run=PSTE_Repository::latestRun();if(!$run)wp_die('PSTE_NO_RUN_AVAILABLE');self::jsonDownload(PSTE_Overlay::build($run,PSTE_Repository::candidatesForRun($run['run_uuid'])),'pste-seo-topic-overlay-'.gmdate('Ymd-His').'-utc.json');}
    public static function exportTopicMap(): void {PSTE_Auth::assertAdmin('pste_export_topic_map',(string)($_POST['_wpnonce']??''));$baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')wp_die('PSTE_SITE_BASELINE_REQUIRED');self::jsonDownload(PSTE_Overlay::buildGlobalMap($baseline,PSTE_Repository::categoryProgress($baseline['leaf_categories']??[]),PSTE_Repository::allCandidates()),'pste-global-seo-topic-map-'.gmdate('Ymd-His').'-utc.json');}

    public static function familyV2DryRun(): void {try{PSTE_Auth::assertAdmin('pste_family_v2_dry_run',(string)($_POST['_wpnonce']??''));PSTE_Family_Reclassification_V2::runDryRun();self::redirect('settings','family_v2_dry_run_ok=1');}catch(Throwable $e){self::blocked('settings',$e);}}
    public static function familyV2ExportDryRun(): void {PSTE_Auth::assertAdmin('pste_family_v2_export_dry_run',(string)($_POST['_wpnonce']??''));$dry=PSTE_Family_Reclassification_V2::storedDryRun();if(($dry['contract']??'')!==PSTE_Family_Reclassification_V2::DRY_RUN_CONTRACT)wp_die('PSTE_FAMILY_V2_DRY_RUN_REQUIRED');self::jsonDownload($dry,'pste-family-v2-dry-run-'.gmdate('Ymd-His').'-utc.json',false);}
    public static function familyV2ImportAuthorization(): void {try{PSTE_Auth::assertAdmin('pste_family_v2_import_authorization',(string)($_POST['_wpnonce']??''));$tmp=(string)($_FILES['authorization_json']['tmp_name']??'');if($tmp===''||!is_uploaded_file($tmp))throw new RuntimeException('PSTE_FAMILY_V2_AUTHORIZATION_UPLOAD_REQUIRED');$raw=(string)file_get_contents($tmp);if(strlen($raw)>5*1024*1024)throw new RuntimeException('PSTE_FAMILY_V2_AUTHORIZATION_FILE_TOO_LARGE');$data=json_decode($raw,true);if(!is_array($data))throw new RuntimeException('PSTE_FAMILY_V2_AUTHORIZATION_JSON_INVALID');PSTE_Family_Reclassification_V2::importAuthorization($data);self::redirect('settings','family_v2_authorization_ok=1');}catch(Throwable $e){self::blocked('settings',$e);}}
    public static function familyV2Apply(): void {try{PSTE_Auth::assertAdmin('pste_family_v2_apply',(string)($_POST['_wpnonce']??''));if(empty($_POST['confirm_apply']))throw new RuntimeException('PSTE_FAMILY_V2_APPLY_CONFIRMATION_REQUIRED');PSTE_Family_Reclassification_V2::apply();self::redirect('settings','family_v2_apply_ok=1');}catch(Throwable $e){self::blocked('settings',$e);}}
    public static function familyV2Rollback(): void {try{PSTE_Auth::assertAdmin('pste_family_v2_rollback',(string)($_POST['_wpnonce']??''));if(empty($_POST['confirm_rollback']))throw new RuntimeException('PSTE_FAMILY_V2_ROLLBACK_CONFIRMATION_REQUIRED');PSTE_Family_Reclassification_V2::rollback();self::redirect('settings','family_v2_rollback_ok=1');}catch(Throwable $e){self::blocked('settings',$e);}}

    public static function sandboxSync(): void {try{PSTE_Auth::assertAdmin('pste_sandbox_sync',(string)($_POST['_wpnonce']??''));PSTE_Semantic_Review_Sandbox::syncFromCurrentDryRun();self::redirect('sandbox','sandbox_synced=1');}catch(Throwable $e){self::blocked('sandbox',$e);}}
    public static function sandboxExport(): void {PSTE_Auth::assertAdmin('pste_sandbox_export',(string)($_POST['_wpnonce']??''));$payload=PSTE_Semantic_Review_Sandbox::exportPayload();self::assertCredentialFreeArtifact($payload);self::jsonDownload($payload,'pste-semantic-review-sandbox-'.gmdate('Ymd-His').'-utc.json',false);}
    public static function sandboxReviewRelevance(): void {try{PSTE_Auth::assertAdmin('pste_sandbox_review_relevance',(string)($_POST['_wpnonce']??''));$id=sanitize_text_field((string)($_POST['sandbox_id']??''));$decision=sanitize_text_field((string)($_POST['relevance_decision']??''));$expected=strtolower(sanitize_text_field((string)($_POST['expected_response_sha256']??'')));$expectedCurrent=strtolower(sanitize_text_field((string)($_POST['expected_current_decision_sha256']??'')));$note=sanitize_text_field((string)($_POST['review_note']??''));if($note==='')throw new RuntimeException('PSTE_SANDBOX_EXPLICIT_REVIEW_NOTE_REQUIRED');PSTE_Semantic_Review_Sandbox::reviewOrReviseRelevance($id,$decision,$expected,$expectedCurrent,$note,get_current_user_id());self::redirect('sandbox','sandbox_relevance_reviewed=1');}catch(Throwable $e){self::blocked('sandbox',$e);}}
    public static function sandboxConfirmInternal(): void {try{PSTE_Auth::assertAdmin('pste_sandbox_confirm_internal',(string)($_POST['_wpnonce']??''));$id=sanitize_text_field((string)($_POST['sandbox_id']??''));$expected=strtolower(sanitize_text_field((string)($_POST['expected_proposal_sha256']??'')));$note=sanitize_text_field((string)($_POST['review_note']??''));if($note==='')throw new RuntimeException('PSTE_SANDBOX_INTERNAL_REVIEW_NOTE_REQUIRED');PSTE_Semantic_Review_Sandbox::confirmInternalProposalForNormalReentry($id,$expected,$note,get_current_user_id());self::redirect('sandbox','sandbox_internal_confirmed=1');}catch(Throwable $e){self::blocked('sandbox',$e);}}
    public static function sandboxStartAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_sandbox_ajax',(string)($_POST['nonce']??''));
            if(empty($_POST['confirm_cost']))throw new RuntimeException('PSTE_COST_CONFIRMATION_REQUIRED');
            $job=PSTE_Semantic_Review_Sandbox::startAnalysis(PSTE_Plugin::settings());
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job],$level);
    }
    public static function sandboxAdvanceAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_sandbox_ajax',(string)($_POST['nonce']??''));
            $job=PSTE_Semantic_Review_Sandbox::advanceAnalysis(sanitize_text_field((string)($_POST['job_uuid']??'')),PSTE_Plugin::settings(),!empty($_POST['explicit_resume']));
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job],$level);
    }
    public static function sandboxCancelUnknownAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_sandbox_ajax',(string)($_POST['nonce']??''));
            if(empty($_POST['provider_checked']))throw new RuntimeException('PSTE_PROVIDER_ACCOUNT_CHECK_REQUIRED');
            $job=PSTE_Semantic_Review_Sandbox::cancelUnknownJob(sanitize_text_field((string)($_POST['job_uuid']??'')));
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job],$level);
    }

    public static function researchCancelAjax(): void {
        $level=self::ajaxBoundaryBegin();
        try{
            PSTE_Auth::assertAdmin('pste_research_ajax',(string)($_POST['nonce']??''));
            $job=PSTE_Research_Job::cancelAfterProviderCheck(sanitize_text_field((string)($_POST['job_uuid']??'')),!empty($_POST['provider_checked']));
        }catch(Throwable $e){self::ajaxError($e,$level,400);return;}
        self::ajaxSuccess(['job'=>$job],$level);
    }

    /**
     * Hard JSON boundary for every PSTE admin AJAX response.
     * Any warning/notice/accidental echo emitted inside the PSTE action is discarded before
     * the JSON envelope is written. No provider request is retried here.
     */
    private static function ajaxBoundaryBegin(): int {
        $level=ob_get_level();
        ob_start();
        return $level;
    }
    private static function ajaxBoundaryClean(int $level): void {
        while(ob_get_level()>$level){@ob_end_clean();}
    }
    private static function ajaxSuccess(array $data,int $level): void {
        self::ajaxBoundaryClean($level);
        if(!headers_sent())header('X-PSTE-Ajax-Contract: PSTE_JSON_BOUNDARY_V1');
        wp_send_json_success($data);
    }
    private static function ajaxError(Throwable $e,int $level,int $status=400): void {
        self::ajaxBoundaryClean($level);
        if(!headers_sent())header('X-PSTE-Ajax-Contract: PSTE_JSON_BOUNDARY_V1');
        wp_send_json_error(['error_code'=>self::safeErrorCode($e)],$status);
    }

    private static function safeErrorCode(Throwable $e): string {$code=strtoupper(trim((string)$e->getMessage()));$code=(string)preg_replace('/[^A-Z0-9_:\-]/','_',$code);return substr($code!==''?$code:'PSTE_REQUEST_FAILED',0,180);}

    private static function isList($value): bool {
        if(!is_array($value))return false;
        $expected=0;
        foreach($value as $key=>$_){if($key!==$expected++)return false;}
        return true;
    }

    private static function globalCategoryDatalist(): void {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);echo '<datalist id="pste-global-category-list">';foreach((is_array($baseline)?($baseline['leaf_categories']??[]):[]) as $cat)echo '<option value="'.esc_attr((string)($cat['name']??'')).'"></option>';echo '</datalist>';
    }

    private static function familyCategoryOptions(string $familyKey): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$out=[];foreach((is_array($baseline)?($baseline['leaf_categories']??[]):[]) as $cat){if((string)($cat['topic_family_key']??'')===$familyKey)$out[]=['term_id'=>(int)$cat['term_id'],'name'=>(string)$cat['name']];}usort($out,static fn($a,$b)=>$a['name']<=>$b['name']);return $out;
    }

    private static function tabs(string $active): void {echo '<nav class="nav-tab-wrapper">';foreach(self::TABS as $key=>$tab)echo '<a class="nav-tab '.($active===$key?'nav-tab-active':'').'" href="'.esc_url(admin_url('admin.php?page='.$tab['slug'])).'">'.esc_html($tab['label']).'</a>';echo '</nav>';}
    private static function connectionPanel(string $title,array $status,string $desc): void {echo '<div class="pste-connection"><h3>'.esc_html($title).' '.self::badge((string)$status['status'],(string)$status['label']).'</h3><p>'.esc_html($desc).'</p>';if(!empty($status['tested_at_utc']))echo '<p>Zuletzt geprüft: '.esc_html((string)$status['tested_at_utc']).' UTC</p>';if(!empty($status['error_code']))echo '<p>Fehlercode: <code>'.esc_html((string)$status['error_code']).'</code></p>';echo '</div>';}
    private static function statusLabel(string $status): string {
        return match($status){
            'PASS'=>'Automatisch freigegeben','AUTO_RESOLVED'=>'Automatisch erzeugt und eingeordnet','PROVISIONAL_ACCEPTED'=>'Vorläufig angenommen','PROVISIONAL_REASSIGN'=>'Vorläufig umgeordnet',
            'REVIEW_REQUIRED'=>'Aktive Prüfung erforderlich','DISCOVERY_ONLY'=>'Recherchebegriff','BLOCKED_FOR_CATEGORY'=>'Für diese Zuordnung blockiert',
            'APPROVED'=>'Manuell freigegeben','REASSIGNED'=>'Manuell umgeordnet','REJECTED'=>'Endgültig verworfen',default=>$status,
        };
    }

    private static function trafficBadge(array $light): string {
        $code=strtolower((string)($light['code']??'GREY'));$label=(string)($light['label']??'Grau');$meaning=(string)($light['meaning']??'');
        return '<span class="pste-traffic pste-traffic-'.$code.'"><span class="pste-traffic-dot" aria-hidden="true"></span><strong>'.esc_html($label).'</strong><small>'.esc_html($meaning).'</small></span>';
    }

    private static function trafficCard(string $code,string $label,int $count,string $meaning,string $filter): void {
        $href=admin_url('admin.php?page='.self::TABS['review']['slug'].'&pool_filter='.$filter);
        echo '<a class="pste-traffic-card pste-traffic-card-'.esc_attr(strtolower($code)).'" href="'.esc_url($href).'"><span class="pste-traffic-dot" aria-hidden="true"></span><strong>'.esc_html((string)$count).' · '.esc_html($label).'</strong><small>'.esc_html($meaning).'</small></a>';
    }

    private static function priorityTable(array $rows,bool $full=false): void {echo '<table class="widefat striped pste-table"><thead><tr><th>Priorität</th><th>Kategorie</th><th>Thema</th><th>Typ</th><th>Status</th><th>Volumen</th>'.($full?'<th>Gewichtung</th>':'').'</tr></thead><tbody>';foreach($rows as $r){$parts=[];foreach(($r['components']??[]) as $k=>$v)$parts[]=$k.' '.$v;echo '<tr><td><strong>'.esc_html(number_format((float)$r['priority_score'],1,',','.')).'/100</strong></td><td>'.esc_html($r['category_name']).'</td><td>'.esc_html($r['topic']).'</td><td>'.esc_html($r['article_type']).'</td><td>'.self::badge($r['decision'],$r['decision']).'</td><td>'.esc_html(number_format((float)$r['search_volume'],0,',','.')).'</td>'.($full?'<td>'.esc_html(implode(' · ',$parts)).'</td>':'').'</tr>';}if(!$rows)self::emptyRow($full?7:6,'Noch keine priorisierbaren Themen.');echo '</tbody></table>';}
    /** @return list<string> */
    private static function availableArticleTypes(): array {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$types=[];
        foreach((is_array($baseline)?(array)($baseline['leaf_categories']??[]):[]) as $leaf){$type=trim((string)($leaf['article_type']??''));if($type!=='')$types[$type]=true;}
        $out=array_keys($types);sort($out,SORT_NATURAL|SORT_FLAG_CASE);return $out;
    }

    private static function card(string $title,string $value,string $note): void {echo '<section class="pste-card"><h3>'.esc_html($title).'</h3><div class="pste-card-value">'.$value.'</div><p>'.esc_html($note).'</p></section>';}
    private static function metric(string $label,$value): void {echo '<section class="pste-metric"><strong>'.esc_html((string)$value).'</strong><span>'.esc_html($label).'</span></section>';}
    private static function badge(string $state,string $label): string {$safe=strtolower(preg_replace('/[^a-z0-9_-]/i','-',$state));return '<span class="pste-badge pste-'.$safe.'">'.esc_html($label).'</span>';}
    private static function coverageLabel(string $state): string {return ['UNDERREPRESENTED'=>'UNTERBELICHTET','BALANCED'=>'AUSGEGLICHEN','OVERREPRESENTED'=>'ÜBERREPRÄSENTIERT','DATA_INSUFFICIENT'=>'DATEN FEHLEN'][$state]??$state;}
    private static function contextPublicState(array $job): array {
        $out=[];foreach(['contract','status','phase','payload_repair_status','payload_repair_cursor','payload_repair_total','processed','total','sandbox_record_store_status','sandbox_record_store_migration_status','sandbox_record_store_migration_cursor','sandbox_record_store_verification_cursor','sandbox_record_store_count','sandbox_binding_status','sandbox_processed','sandbox_total','dynamic_rebase_count','last_dynamic_rebase_reason','error_code'] as $key)$out[$key]=$job[$key]??null;return $out;
    }
    private static function renderContextAutoSequence(array $context): void {
        $status=(string)($context['status']??'');
        $contract=(string)($context['contract']??'');
        $legacyBlocked=$status==='BLOCKED'&&in_array($contract,['PSTE_CONTEXT_REFRESH_JOB_V7_RECORD_LOCAL_SANDBOX_ROOTFIX','PSTE_CONTEXT_REFRESH_JOB_V6_STAGED_SHARDED_ROOTFIX','PSTE_CONTEXT_REFRESH_JOB_V5_BOUNDED_AUDIT_NO_REBUILD','PSTE_CONTEXT_REFRESH_JOB_V5_SHARDED_INDEX','PSTE_CONTEXT_REFRESH_JOB_V4_PREJOURNAL_TECHNICAL_RECOVERY','PSTE_CONTEXT_REFRESH_JOB_V4_TRUE_REQUEST_BUDGET','PSTE_CONTEXT_REFRESH_JOB_V3','PSTE_CONTEXT_REFRESH_JOB_V2','PSTE_CONTEXT_REFRESH_JOB_V1'],true);
        if(!$legacyBlocked&&!in_array($status,['PENDING','RUNNING'],true))return;
        $initial=self::contextPublicState($context);
        // A legacy BLOCKED job belongs to an obsolete request contract. Present exactly one technical re-entry
        // opportunity to the existing AJAX worker; processBatch() adopts it under V7. A V6 Sandbox-boundary job preserves its completed 562-topic state; older contracts restart fail-closed.
        if($legacyBlocked){$initial['status']='PENDING';$initial['phase']='LEGACY_REENTRY_PENDING';}
        $cfg=['ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('pste_context_ajax'),'redirect'=>admin_url('admin.php?page='.self::PARENT.'&context_complete=1'),'initial'=>$initial];
        echo '<div id="pste-context-auto" class="notice notice-info inline"><p><strong>Portalabgleich läuft automatisch request-begrenzt weiter.</strong> <span id="pste-context-auto-state"></span></p></div>';
        echo '<script>(function(){const cfg='.wp_json_encode($cfg,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).',el=document.getElementById("pste-context-auto-state");if(!cfg||!cfg.initial)return;let stopped=false;const sleep=ms=>new Promise(r=>setTimeout(r,ms));function render(j){if(!el)return;let t="";if(j.payload_repair_status&&j.payload_repair_status!=="PASS"&&j.payload_repair_status!=="NOT_REQUIRED")t="Integrität "+(j.payload_repair_cursor||0)+" von "+(j.payload_repair_total||0)+" · ";t+=(j.processed||0)+" von "+(j.total||0)+" Themen";if(j.phase==="SANDBOX_RECORD_STORE_MIGRATION"&&j.sandbox_record_store_status!=="PASS"){const n=Number(j.sandbox_total||j.sandbox_record_store_count||0),m=Number(j.sandbox_record_store_migration_cursor||0),v=Number(j.sandbox_record_store_verification_cursor||0);t+=" · Sandbox-Migration "+m+(n>0?" von "+n:"");if(v>0)t+=" · Verifikation "+v+(n>0?" von "+n:"");}else if(Number(j.sandbox_total||0)>0)t+=" · Sandbox "+(j.sandbox_processed||0)+" von "+j.sandbox_total;el.textContent=j.status+" · "+t;}async function advance(){let j=cfg.initial;for(let guard=0;guard<900&&!stopped;guard++){render(j);if(j.status==="COMPLETE"){window.location.href=cfg.redirect;return;}if(j.status==="BLOCKED"){stopped=true;return;}if(j.status!=="PENDING"&&j.status!=="RUNNING"){stopped=true;return;}await sleep(250);const body=new URLSearchParams({action:"pste_context_advance",nonce:cfg.nonce});const ctrl=new AbortController(),timer=setTimeout(()=>ctrl.abort(),20000);let res,raw="";try{res=await fetch(cfg.ajax,{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/x-www-form-urlencoded; charset=UTF-8"},body:body.toString(),signal:ctrl.signal});raw=await res.text();}catch(e){clearTimeout(timer);throw new Error(e&&e.name==="AbortError"?"PSTE_CONTEXT_AJAX_HTTP_TIMEOUT":"PSTE_CONTEXT_AJAX_NETWORK_FAILED");}clearTimeout(timer);let data=null;try{data=JSON.parse(raw);}catch(e){throw new Error("PSTE_CONTEXT_AJAX_INVALID_JSON_PHASE_"+(j.phase||"UNKNOWN")+"_HTTP_"+(res?res.status:0)+"_LEN_"+raw.length);}if(!res.ok||!data||!data.success||!data.data||!data.data.job){const code=(data&&data.data&&data.data.error_code)||(data&&data.data&&data.data.job&&data.data.job.error_code)||(data&&data.data&&data.data.message)||"PSTE_CONTEXT_AJAX_FAILED_HTTP_"+(res?res.status:0);throw new Error(code);}j=data.data.job;}throw new Error("PSTE_CONTEXT_AUTOMATIC_SEQUENCE_GUARD_EXCEEDED");}advance().catch(e=>{stopped=true;if(el)el.textContent="BLOCKED · "+(e.message||"PSTE_CONTEXT_AUTOMATIC_SEQUENCE_FAILED");});})();</script>';
    }

    private static function actionForm(string $action,string $nonce,string $label,string $class='secondary'): void {echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="display:inline-block;margin:8px 8px 8px 0">';wp_nonce_field($nonce);echo '<input type="hidden" name="action" value="'.esc_attr($action).'">';submit_button($label,$class,'submit',false);echo '</form>';}
    private static function row(string $k,string $v): void {echo '<tr><th style="width:280px">'.esc_html($k).'</th><td>'.esc_html($v).'</td></tr>';}
    private static function emptyRow(int $cols,string $text): void {echo '<tr><td colspan="'.esc_attr((string)$cols).'"><em>'.esc_html($text).'</em></td></tr>';}
    private static function redirect(string $tab,string $flag): void {$slug=self::TABS[$tab]['slug']??self::PARENT;wp_safe_redirect(admin_url('admin.php?page='.$slug.'&'.$flag));exit;}
    private static function blocked(string $tab,Throwable $e): void {
        $details=[];
        if(method_exists($e,'safeDetails'))$details=(array)$e->safeDetails();
        set_transient('pste_last_error',['status'=>'BLOCKED','error'=>$e->getMessage(),'details'=>self::safeDiagnosticDetails($details)],300);
        self::redirect($tab,'blocked=1');
    }
    /** @param array<string,mixed> $details @return array<string,mixed> */
    private static function safeDiagnosticDetails(array $details): array {
        $allowed=['http_code','provider_status_code','provider_message','task_index','tasks_count','tasks_error','method','path','attempt','response_sha256','reason_code','term_id','name','slug','article_type','expected_article_type','accepted_category_names','mapping_status','expected_product_page_slug','quarantined_category_count','unresolved_count','first_unresolved','first_quarantined','candidate_count','candidate_page_ids','post_id','category_ids','page_id','missing_parent_id','cycle_at','declared_count','actual_count','expected_sha256','actual_sha256'];
        $out=[];
        $clean=static function($value,int $depth=0) use (&$clean){
            if(is_int($value)||is_float($value)||is_bool($value))return $value;
            if(is_string($value)){$value=preg_replace('/[\x00-\x1F\x7F]+/u',' ',trim($value))??'';return function_exists('mb_substr')?mb_substr($value,0,240,'UTF-8'):substr($value,0,240);}
            if(!is_array($value)||$depth>=2)return null;
            $result=[];$count=0;foreach($value as $k=>$v){if($count++>=20)break;$safe=$clean($v,$depth+1);if($safe!==null)$result[is_int($k)?$k:(string)$k]=$safe;}return $result;
        };
        foreach($allowed as $key){
            if(!array_key_exists($key,$details))continue;$safe=$clean($details[$key]);if($safe!==null)$out[$key]=$safe;
        }
        return $out;
    }
    private static function assertCredentialFreeArtifact(array $payload): void {
        $badKey='/(?:^|_)(?:password|passwd|secret|authorization|api[_-]?key|api[_-]?login|credentials?|dataforseo[_-]?(?:login|password)|client_secret|access_token|refresh_token|oauth_token)(?:$|_)/i';
        $walk=function($item)use(&$walk,$badKey):void{if(!is_array($item))return;foreach($item as $k=>$v){if(preg_match($badKey,(string)$k))throw new RuntimeException('PSTE_EXPORT_SENSITIVE_KEY_PRESENT');if(is_array($v))$walk($v);}};$walk($payload);
        try{$dfs=PSTE_Credentials::resolve();$gsc=PSTE_GSC_Credentials::client();$tok=PSTE_GSC_Credentials::tokenBundle();}catch(Throwable $e){throw new RuntimeException('PSTE_EXPORT_CREDENTIAL_SAFETY_CHECK_FAILED');}
        $secrets=array_values(array_filter([(string)($dfs['login']??''),(string)($dfs['password']??''),(string)($gsc['client_id']??''),(string)($gsc['client_secret']??''),(string)($tok['access_token']??''),(string)($tok['refresh_token']??'')],static fn($v)=>$v!==''));
        $raw=wp_json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($raw))throw new RuntimeException('PSTE_EXPORT_CREDENTIAL_SCAN_JSON_FAILED');foreach($secrets as $secret)if(str_contains($raw,$secret))throw new RuntimeException('PSTE_EXPORT_SECRET_VALUE_PRESENT');
    }

    private static function jsonDownload(array $payload,string $filename,bool $scrub=true): void {nocache_headers();header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="'.$filename.'"');$out=$scrub?PSTE_GSC_Credentials::scrub(PSTE_Credentials::scrub($payload)):$payload;echo wp_json_encode($out,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);exit;}
    private static function notices(): void {
        foreach(['pste_migration_notice','pste_context_notice'] as $noticeKey){
            $notice=get_transient($noticeKey);
            if(!is_array($notice))continue;
            delete_transient($noticeKey);
            $type=(string)($notice['type']??'success');
            $class=$type==='error'?'notice-error':($type==='info'?'notice-info':'notice-success');
            echo '<div class="notice '.esc_attr($class).'"><p>'.esc_html((string)($notice['message']??'Vorgang abgeschlossen.')).'</p></div>';
        }
        $messages=['updated'=>'Einstellungen gespeichert.','credentials_saved'=>'DataForSEO-Zugang gespeichert.','connection_ok'=>'DataForSEO-Verbindung erfolgreich geprüft.','baseline_captured'=>'Gesamtbestand erfasst.','gsc_client_saved'=>'Google-OAuth-Zugang gespeichert.','gsc_connected'=>'Search Console verbunden.','gsc_test_ok'=>'Search-Console-Verbindung erfolgreich geprüft.','gsc_property_saved'=>'Search-Console-Property gespeichert.','gsc_synced'=>'Search-Console-Daten abgerufen.','gsc_disconnected'=>'Google-Verbindung getrennt.','weights_saved'=>'Strategische Gewichtung gespeichert.','gsc_imported'=>'CSV importiert.','editorial_plan_imported'=>'Redaktionsplan-Snapshot read-only importiert.','research_complete'=>'Longtail-Recherche, Titelbildung, Kategoriezuordnung und portalinterne Prüfung vollständig abgeschlossen.','review_saved'=>'Themenentscheidung gespeichert.','title_override_saved'=>'Titelkorrektur gespeichert. Kategorie, Artikeltyp und Zuordnung wurden nicht verändert.','context_batch_processed'=>'Portalabgleich-Batch erfolgreich verarbeitet.','context_complete'=>'Portalabgleich vollständig abgeschlossen.','safe_migration_ok'=>'Sichere Migration vollständig abgeschlossen.','price_intent_repaired'=>'Preis-Longtails wurden im internen Themenpool sicher neu zugeordnet.','price_intent_partial'=>'Preis-Longtail-Korrektur abgeschlossen: eindeutige Fälle wurden übernommen, unklare Einzelfälle blieben unverändert und sind auf der Übersicht protokolliert.','family_v2_dry_run_ok'=>'V2-Bestandsaudit am Quellbestand schreibfrei abgeschlossen.','family_v2_authorization_ok'=>'V2-Freigabedatei geprüft und importiert. Apply wurde nicht automatisch gestartet.','family_v2_apply_ok'=>'Exakt autorisierter V2-Apply abgeschlossen.','family_v2_rollback_ok'=>'V2-Apply vollständig zurückgesetzt.','sandbox_synced'=>'Alle aktuellen NEWLY_BLOCKED-Longtails wurden verlustfrei in die isolierte Sandbox übernommen.','sandbox_relevance_reviewed'=>'Explizite Relevanzentscheidung wurde ausschließlich im Sandbox-Register gespeichert.','sandbox_internal_confirmed'=>'Interne Zuordnung wurde ausschließlich für den späteren normalen Reentry vorgemerkt. Kein Produktions-Handoff wurde erzeugt.','sandbox_complete'=>'Sandbox-Prüfung abgeschlossen. Kein Apply und keine Produktionsübergabe wurde ausgeführt.'];
        foreach($messages as $key=>$text)if(isset($_GET[$key])){$class=$key==='price_intent_partial'?'notice-warning':'notice-success';echo '<div class="notice '.esc_attr($class).'"><p>'.esc_html($text).'</p></div>';}
        $err=get_transient('pste_last_error');
        if(is_array($err)){
            delete_transient('pste_last_error');
            $details=is_array($err['details']??null)?$err['details']:[];
            echo '<div class="notice notice-error"><p><strong>BLOCKED:</strong> <code>'.esc_html((string)($err['error']??'UNBEKANNT')).'</code>';
            if($details){
                $message=trim((string)($details['provider_message']??''));
                if($message!=='')echo '<br><strong>Provider:</strong> '.esc_html($message);
                $technical=$details;unset($technical['provider_message']);
                if($technical)echo '<br><strong>Technische Details:</strong> <code>'.esc_html(wp_json_encode($technical,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'</code>';
            }
            echo '</p></div>';
        }
    }
    private static function styles(): void {echo '<style>
.pste-wrap .nav-tab-wrapper{margin-bottom:18px}.pste-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin:16px 0}.pste-card,.pste-metric,.pste-box,.pste-connection{background:#fff;border:1px solid #dcdcde;padding:16px}.pste-card h3,.pste-connection h3{margin-top:0}.pste-card-value{font-size:18px;font-weight:700}.pste-metric{text-align:center}.pste-metric strong{display:block;font-size:28px}.pste-metric span{display:block}.pste-two{display:grid;grid-template-columns:repeat(auto-fit,minmax(360px,1fr));gap:18px}.pste-run-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;align-items:end}.pste-run-grid input,.pste-run-grid select{width:100%;max-width:100%}.pste-table td{vertical-align:top}.pste-badge{display:inline-block;padding:3px 8px;border-radius:999px;background:#e2e3e5;font-weight:700;font-size:12px}.pste-connected,.pste-pass,.pste-auto_resolved,.pste-current,.pste-balanced,.pste-publish,.pste-approved{background:#d7f0dd;color:#145c2b}.pste-error,.pste-blocked,.pste-stale,.pste-overrepresented,.pste-rejected,.pste-blocked_for_category{background:#f8d7da;color:#8a1f28}.pste-configured_untested,.pste-configured-unconnected,.pste-review_required,.pste-underrepresented,.pste-draft,.pste-reassign,.pste-reassigned,.pste-provisional_accepted,.pste-provisional_reassign{background:#fff3cd;color:#6f5100}.pste-discovery_only{background:#d7f0dd;color:#145c2b}.pste-data_insufficient,.pste-not_configured,.pste-not-captured,.pste-not_run{background:#e2e3e5;color:#41464b}
.pste-traffic-grid{display:grid;grid-template-columns:repeat(3,minmax(180px,1fr));gap:14px;margin:14px 0}.pste-traffic-card{display:grid;grid-template-columns:22px 1fr;column-gap:9px;align-items:center;text-decoration:none;background:#fff;border:2px solid #dcdcde;border-radius:8px;padding:14px;color:#1d2327}.pste-traffic-card strong{font-size:18px}.pste-traffic-card small{grid-column:2;display:block;margin-top:3px}.pste-traffic-dot{display:inline-block;width:16px;height:16px;border-radius:50%;background:#8c8f94;box-shadow:0 0 0 3px rgba(140,143,148,.15)}.pste-traffic-card-green{border-color:#46b450}.pste-traffic-card-yellow{border-color:#dba617}.pste-traffic-card-red{border-color:#d63638}.pste-traffic-card-green .pste-traffic-dot,.pste-traffic-green .pste-traffic-dot{background:#46b450}.pste-traffic-card-yellow .pste-traffic-dot,.pste-traffic-yellow .pste-traffic-dot{background:#dba617}.pste-traffic-card-red .pste-traffic-dot,.pste-traffic-red .pste-traffic-dot{background:#d63638}.pste-traffic{display:grid;grid-template-columns:18px 1fr;column-gap:7px;align-items:center;min-width:145px}.pste-traffic strong{font-size:13px}.pste-traffic small{grid-column:2;display:block;margin-top:2px}.pste-row-yellow td:first-child{border-left:4px solid #dba617}.pste-row-red td:first-child{border-left:4px solid #d63638}.pste-row-green td:first-child{border-left:4px solid #46b450}@media(max-width:782px){.pste-traffic-grid{grid-template-columns:1fr}}
.pste-review-table th:nth-child(1){width:110px}.pste-light{display:inline-block;padding:4px 10px;border-radius:999px;font-weight:700}.pste-light-green{background:#d7f0dd;color:#145c2b}.pste-light-yellow{background:#fff3cd;color:#6f5100}.pste-light-red{background:#f8d7da;color:#8a1f28}.pste-hard-warning{padding:8px;background:#fff3cd;border-left:4px solid #dba617}.pste-review-table details{margin-top:8px}.pste-review-table td{min-width:100px}</style>';}
}
