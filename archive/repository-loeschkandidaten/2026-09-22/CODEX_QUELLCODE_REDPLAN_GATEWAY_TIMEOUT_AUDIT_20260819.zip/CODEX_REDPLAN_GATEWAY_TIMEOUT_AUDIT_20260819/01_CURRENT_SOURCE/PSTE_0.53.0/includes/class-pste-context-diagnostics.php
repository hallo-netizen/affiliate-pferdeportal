<?php
if (!defined('ABSPATH')) { return; }

/**
 * Tiny technical fatal ring buffer for the context worker.
 * Never records article/keyword/prompt/payload bytes.
 */
final class PSTE_Context_Diagnostics {
    private static bool $armed=false;
    private static bool $finished=false;
    private static string $jobUuid='';
    private static string $phase='UNKNOWN';
    private static string $lastDbOp='';
    private static float $started=0.0;
    private static string $reserve='';

    public static function begin(string $jobUuid,string $phase='UNKNOWN'): void {
        self::$jobUuid=substr(preg_replace('/[^A-Za-z0-9_-]/','',$jobUuid)??'',0,80);
        self::$phase=self::cleanToken($phase);
        self::$lastDbOp='';self::$started=microtime(true);self::$finished=false;
        if(!self::$armed){self::$armed=true;self::$reserve=str_repeat('x',262144);register_shutdown_function([self::class,'shutdown']);}
    }
    public static function phase(string $phase): void {self::$phase=self::cleanToken($phase);}
    public static function dbOp(string $op): void {self::$lastDbOp=substr(hash('sha256',$op),0,24);}
    public static function finish(): void {self::$finished=true;self::$reserve='';}
    public static function shutdown(): void {
        if(self::$finished)return;$err=error_get_last();if(!is_array($err))return;
        $fatal=[E_ERROR,E_PARSE,E_CORE_ERROR,E_COMPILE_ERROR,E_USER_ERROR,E_RECOVERABLE_ERROR];if(!in_array((int)($err['type']??0),$fatal,true))return;
        self::$reserve='';
        $row=[
            'contract'=>'PSTE_CONTEXT_FATAL_DIAGNOSTIC_V1','at_utc'=>gmdate('c'),'job_uuid'=>self::$jobUuid,
            'phase'=>self::$phase,'php_error_type'=>(int)($err['type']??0),'message_sha256'=>hash('sha256',(string)($err['message']??'')),
            'peak_memory_bytes'=>memory_get_peak_usage(true),'elapsed_ms'=>(int)round((microtime(true)-self::$started)*1000),
            'last_db_op_sha256'=>self::$lastDbOp,
        ];
        $ring=get_option(PSTE_OPTION_CONTEXT_DIAGNOSTICS_RING,[]);if(!is_array($ring))$ring=[];$ring[]=$row;if(count($ring)>10)$ring=array_slice($ring,-10);
        update_option(PSTE_OPTION_CONTEXT_DIAGNOSTICS_RING,$ring,false);
    }
    private static function cleanToken(string $v): string {$v=strtoupper(trim($v));$v=preg_replace('/[^A-Z0-9_-]+/','_',$v)??'UNKNOWN';return substr($v!==''?$v:'UNKNOWN',0,80);}
}
