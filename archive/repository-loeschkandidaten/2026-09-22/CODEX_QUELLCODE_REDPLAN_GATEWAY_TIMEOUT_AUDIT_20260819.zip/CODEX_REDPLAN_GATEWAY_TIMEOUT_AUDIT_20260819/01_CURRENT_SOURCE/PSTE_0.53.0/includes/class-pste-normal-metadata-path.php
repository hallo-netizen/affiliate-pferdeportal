<?php
if (!defined('ABSPATH')) { return; }

/**
 * Single read-only semantic/editorial decision path for normal research, stored-topic rebuilds and Sandbox reentry.
 * It owns no persistence and can never create an article/text/design payload or a five-field production handoff.
 */
final class PSTE_Normal_Metadata_Path {
    public const CONTRACT='PSTE_NORMAL_METADATA_PATH_V2';

    /** @return array<string,mixed> */
    public static function evaluateRaw(string $raw,array $baseline,string $preferredFamilyKey='',array $relevanceProof=[],array $seoEvidence=[]): array {
        $raw=self::canonicalInputQuery($raw);
        $base=[
            'contract'=>self::CONTRACT,'status'=>'REVIEW_REQUIRED','ok'=>false,'raw_query'=>$raw,
            'raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'','portal_relevance'=>'UNPROVEN',
            'family_key'=>'','family_name'=>'','family_resolution'=>[],'family_membership'=>[],
            'article_type_registry_sha256'=>'','family_identity_v2_registry_sha256'=>'',
            'portal_relevance_gate'=>[],'normalization'=>[],'intent_analysis'=>[],'semantic_consensus'=>[],'intent_profile'=>[],'article_type'=>'','target_category'=>[],
            'title_pipeline'=>[],'title'=>'','target_keyword'=>'','category_gap_proposal'=>[],'domain_risk'=>[],
            'reason_codes'=>[],'title_generated'=>false,'sandbox_required'=>false,'sandbox_admission_mode'=>'',
            'structure_gap_backlog_required'=>false,'retained_non_producing'=>false,
            'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,
            'article_or_taxonomy_write_attempted'=>false,'write_attempted'=>false,
        ];
        if($raw==='')return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_NORMAL_PATH_RAW_QUERY_MISSING']);
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_NORMAL_PATH_BASELINE_REQUIRED']);
        $registry=PSTE_Article_Type_Registry::build($baseline);
        if(empty($registry['registry_sha256']))return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_NORMAL_PATH_REGISTRY_INVALID']);
        $base['article_type_registry_sha256']=(string)$registry['registry_sha256'];
        $base['family_identity_v2_registry_sha256']=(string)($registry['family_identity_v2_registry_sha256']??'');

        // Hard ordering contract: portal relevance is the first semantic decision owner.
        // Any family resolution performed by that gate is temporary evidence only.
        $relevance=PSTE_Portal_Relevance_Gate::evaluateBeforeAssignment($raw,$baseline,$registry,$preferredFamilyKey,$relevanceProof);$base['portal_relevance_gate']=$relevance;
        if(empty($relevance['ok'])){
            $base['portal_relevance']='UNPROVEN';$base['sandbox_required']=true;$base['sandbox_admission_mode']='EXTERNAL_RELEVANCE';
            return self::withReasons($base,'SANDBOX_REQUIRED',array_merge(['PSTE_PORTAL_RELEVANCE_NOT_PROVEN','PSTE_SANDBOX_REQUIRED_BEFORE_EDITORIALIZATION'],(array)($relevance['reason_codes']??[])));
        }
        $base['portal_relevance']='PROVEN';

        // Only after relevance PASS may a family become assignment authority.
        $probe=PSTE_Editorial_Topic_Normalizer::semanticProbe($raw);
        $familyKey='';$family=[];$membership=[];$familyResolution=[];
        $hint=(array)($relevance['family_hint']??[]);
        $assignmentPreferred=$preferredFamilyKey!==''?$preferredFamilyKey:(string)($hint['family_key']??'');
        if($assignmentPreferred!==''&&isset($registry['families'][$assignmentPreferred])){
            $membership=PSTE_Family_Membership::evaluate($probe!==''?$probe:$raw,$registry,$assignmentPreferred);
            if(!empty($membership['ok'])){
                $familyKey=$assignmentPreferred;$family=(array)$registry['families'][$familyKey];
                $familyResolution=['status'=>'MATCH','source'=>'POST_RELEVANCE_FAMILY_REVALIDATED','winner'=>['family_key'=>$familyKey,'topic_family_name'=>(string)($family['topic_family_name']??'')]];
            }
        }
        if($familyKey===''){
            $familyResolution=PSTE_Family_Identity_V2::resolve($probe!==''?$probe:$raw,$registry);
            if(($familyResolution['status']??'')==='MATCH'&&is_array($familyResolution['winner']??null)){
                $familyKey=(string)($familyResolution['winner']['family_key']??'');$family=(array)($registry['families'][$familyKey]??[]);
                if($familyKey!==''&&$family)$membership=PSTE_Family_Membership::evaluate($probe!==''?$probe:$raw,$registry,$familyKey);
            }
        }
        $base['family_resolution']=$familyResolution;$base['family_membership']=$membership;
        if($familyKey===''||!$family||empty($membership['ok'])){
            // Additive Journal route: only after the unchanged existing family path has failed.
            // A NOT_APPLICABLE result preserves the exact historical Sandbox outcome.
            if(class_exists('PSTE_Journal_Router')){
                $journal=PSTE_Journal_Router::evaluateAfterFamilyMiss($raw,$baseline,$registry,$relevance,$seoEvidence);
                if(($journal['status']??'')==='JOURNAL_ROUTE_PASS'&&!empty($journal['ok'])){
                    $base['family_key']=(string)$journal['family_key'];$base['family_name']=(string)$journal['family_name'];
                    $base['family_resolution']=['status'=>'JOURNAL_ROUTE_MATCH','source'=>'PSTE_JOURNAL_ROUTER_V1','winner'=>['family_key'=>(string)$journal['family_key'],'topic_family_name'=>(string)$journal['family_name']]];
                    $base['family_membership']=['contract'=>'PSTE_JOURNAL_FAMILY_SCOPE_V1','status'=>'JOURNAL_SCOPE_PASS','ok'=>true,'reason_codes'=>['PSTE_JOURNAL_SCOPE_AFTER_PRODUCT_FAMILY_MISS_PASS'],'write_attempted'=>false];
                    $base['normalization']=(array)$journal['normalization'];$base['intent_analysis']=(array)$journal['intent_profile'];$base['intent_profile']=(array)$journal['intent_profile'];
                    $base['semantic_consensus']=(array)$journal['semantic_consensus'];$base['article_type']='Journal';$base['target_category']=(array)$journal['target_category'];
                    $base['title_pipeline']=(array)$journal['title_pipeline'];$base['title']=(string)$journal['title'];$base['target_keyword']=(string)$journal['target_keyword'];$base['title_generated']=$base['title']!=='';
                    $base['domain_risk']=(array)$journal['domain_risk'];$base['journal_routing']=$journal;$base['ok']=true;$base['status']='NORMAL_PASS';$base['reason_codes']=['PSTE_NORMAL_METADATA_PATH_PASS','PSTE_JOURNAL_ROUTER_PASS'];
                    return $base;
                }
                if(in_array((string)($journal['status']??''),['CATEGORY_UNAVAILABLE','REVIEW_REQUIRED'],true)){
                    $base['journal_routing']=$journal;$base['sandbox_required']=true;$base['sandbox_admission_mode']='INTERNAL_CLARIFICATION';
                    return self::withReasons($base,'SANDBOX_REQUIRED',array_values(array_unique(array_merge(['PSTE_PORTAL_RELEVANCE_PROVEN_FAMILY_ASSIGNMENT_NOT_PROVEN','PSTE_SANDBOX_INTERNAL_CLARIFICATION_REQUIRED'],(array)($journal['reason_codes']??[])))));
                }
            }
            $base['sandbox_required']=true;$base['sandbox_admission_mode']='INTERNAL_CLARIFICATION';
            return self::withReasons($base,'SANDBOX_REQUIRED',array_values(array_unique(array_merge(['PSTE_PORTAL_RELEVANCE_PROVEN_FAMILY_ASSIGNMENT_NOT_PROVEN','PSTE_SANDBOX_INTERNAL_CLARIFICATION_REQUIRED'],(array)($membership['reason_codes']??[]),(array)($familyResolution['reason_codes']??[])))));
        }
        $familyName=(string)($family['topic_family_name']??'');$base['family_key']=$familyKey;$base['family_name']=$familyName;

        // Deterministic non-article intents are retained, but never sent to external relevance review
        // and never allowed to become production metadata merely because a family matched.
        $retention=self::retentionDecision($raw,$familyName);
        if($retention!==null){
            $base['retained_non_producing']=true;
            return self::withReasons($base,'RETAINED_NON_PRODUCING',(array)$retention['reason_codes']);
        }

        $contextTerms=array_values(array_unique(array_filter(array_map('strval',(array)($relevance['context_evidence']['matched_terms']??[])))));
        $normalization=PSTE_Editorial_Topic_Normalizer::normalize($raw,$familyName,$contextTerms);$base['normalization']=$normalization;
        if(($normalization['status']??'')==='PASS'&&($normalization['relation']??'')==='preposed_qualifier'){
            // A bare token before the family can be brand, audience, product line or another domain.
            // If current portal context did not prove the relation, do not turn the keyword chain into READY metadata.
            $base['sandbox_required']=true;$base['sandbox_admission_mode']='INTERNAL_CLARIFICATION';
            return self::withReasons($base,'SANDBOX_REQUIRED',['PSTE_EDITORIAL_TOPIC_PREPOSED_RELATION_UNPROVEN','PSTE_SANDBOX_INTERNAL_CLARIFICATION_REQUIRED']);
        }
        if(($normalization['status']??'')!=='PASS'){
            $base['sandbox_required']=true;$base['sandbox_admission_mode']='INTERNAL_CLARIFICATION';
            return self::withReasons($base,'SANDBOX_REQUIRED',array_merge(['PSTE_EDITORIAL_TOPIC_NORMALIZATION_NOT_PASS','PSTE_SANDBOX_INTERNAL_CLARIFICATION_REQUIRED'],(array)($normalization['reason_codes']??[])));
        }
        $normalized=(string)($normalization['normalized_topic']??'');if($normalized==='')$normalized=$raw;

        // SEO intention is established before article-type acceptance. The classifier remains independent and must confirm it.
        $intentAnalysis=PSTE_Intent_Profile::analyzeBeforeType($raw,$normalization,$familyName,$seoEvidence);$base['intent_analysis']=$intentAnalysis;
        if(empty($intentAnalysis['ok'])){$base['sandbox_required']=true;$base['sandbox_admission_mode']='INTERNAL_CLARIFICATION';return self::withReasons($base,'SANDBOX_REQUIRED',array_merge(['PSTE_NORMAL_PATH_INTENT_NOT_PROVEN_BEFORE_TYPE','PSTE_SANDBOX_INTERNAL_CLARIFICATION_REQUIRED'],(array)($intentAnalysis['reason_codes']??[])));}

        // Historical/proposed article type is intentionally not accepted as an input authority.
        $semantic=PSTE_Semantic_Classifier::classify($normalized,null,$registry,$familyKey);$base['semantic_consensus']=$semantic;
        $type=(string)($semantic['resolved_article_type']??'');$base['article_type']=$type;
        $risk=PSTE_Domain_Risk_Gate::evaluate($raw,$type);$base['domain_risk']=$risk;
        if($type===''){$base['sandbox_required']=true;$base['sandbox_admission_mode']='INTERNAL_CLARIFICATION';return self::withReasons($base,'SANDBOX_REQUIRED',array_merge(['PSTE_NORMAL_PATH_ARTICLE_TYPE_NOT_PROVEN','PSTE_SANDBOX_INTERNAL_CLARIFICATION_REQUIRED'],(array)($semantic['reason_codes']??[]),(array)($risk['reason_codes']??[])));}

        // Bind the independently classified type back to the already established SEO intent.
        $intent=PSTE_Intent_Profile::bindArticleType($intentAnalysis,$semantic,$registry,$familyKey);$base['intent_profile']=$intent;
        if(empty($intent['ok'])){$base['sandbox_required']=true;$base['sandbox_admission_mode']='INTERNAL_CLARIFICATION';return self::withReasons($base,'SANDBOX_REQUIRED',array_merge(['PSTE_NORMAL_PATH_INTENT_TYPE_BINDING_NOT_PROVEN','PSTE_SANDBOX_INTERNAL_CLARIFICATION_REQUIRED'],(array)($intent['reason_codes']??[]),(array)($risk['reason_codes']??[])));}

        // A title may only be composed after current intent is explicitly bound.
        $pipeline=PSTE_Title_Pipeline::build(['raw_query'=>$raw,'language_corrected_query'=>$raw],$familyName,$type,$registry,$contextTerms,$intent);
        $base['title_pipeline']=$pipeline;$base['title']=(string)($pipeline['title']??'');$base['target_keyword']=(string)($pipeline['target_keyword']??'');$base['title_generated']=$base['title']!=='';
        if(empty($pipeline['ok'])){$base['sandbox_required']=true;$base['sandbox_admission_mode']='INTERNAL_CLARIFICATION';return self::withReasons($base,'SANDBOX_REQUIRED',array_merge(['PSTE_NORMAL_PATH_EDITORIAL_DUAL_STRAND_NOT_PASS','PSTE_SANDBOX_INTERNAL_CLARIFICATION_REQUIRED'],self::pipelineReasons($pipeline),(array)($risk['reason_codes']??[])));}
        if(empty($risk['ok'])){$base['sandbox_required']=true;$base['sandbox_admission_mode']='INTERNAL_CLARIFICATION';return self::withReasons($base,'SANDBOX_REQUIRED',array_merge(['PSTE_NORMAL_PATH_DOMAIN_RISK_NOT_PASS','PSTE_SANDBOX_INTERNAL_CLARIFICATION_REQUIRED'],(array)($risk['reason_codes']??[])));}

        $target=(array)($semantic['resolved_category']??[]);$base['target_category']=$target;
        if(empty($semantic['category_consensus'])||(int)($target['term_id']??0)<=0||(string)($target['slug']??'')===''){
            $gap=PSTE_Category_Gap::proposal($familyName,$familyKey,$type,$semantic,[],(string)($baseline['structure_sha256']??''),$registry);
            $base['category_gap_proposal']=$gap;$base['structure_gap_backlog_required']=true;
            return self::withReasons($base,'STRUCTURE_GAP',array_merge(['PSTE_RELEVANT_TOPIC_CATEGORY_GAP_RETAINED'],(array)($semantic['reason_codes']??[])));
        }
        if(empty($semantic['ok'])){$base['sandbox_required']=true;$base['sandbox_admission_mode']='INTERNAL_CLARIFICATION';return self::withReasons($base,'SANDBOX_REQUIRED',array_merge(['PSTE_NORMAL_PATH_SEMANTIC_CONSENSUS_NOT_PASS','PSTE_SANDBOX_INTERNAL_CLARIFICATION_REQUIRED'],(array)($semantic['reason_codes']??[])));}

        $base['ok']=true;$base['status']='NORMAL_PASS';$base['reason_codes']=['PSTE_NORMAL_METADATA_PATH_PASS'];
        return $base;
    }

    /** Apply only SEO-topic metadata derived by evaluateRaw(); raw source fields remain byte-identical. */
    public static function applyToPayload(array $payload,array $baseline,string $preferredFamilyKey='',array $relevanceProof=[]): array {
        $raw=PSTE_Editorializer::sourceQuery($payload);
        $before=self::rawSourceInvariant($payload);
        // Historical derived family assignments are evidence only and must never become current authority
        // merely because they are present in a legacy payload. A preferred family is trusted only when its
        // current provenance is explicit: current research origin or a bound Sandbox reentry proof.
        $providedPreferred=trim($preferredFamilyKey);
        $researchPreferred=trim((string)($payload['research_origin_family_key']??''));
        $researchContract=trim((string)($payload['research_job_contract']??''));
        $trustedResearch=$providedPreferred!==''&&$researchPreferred!==''&&$researchContract!==''&&hash_equals($providedPreferred,$researchPreferred);
        $trustedReentry=$providedPreferred!==''&&!empty($relevanceProof);
        $preferredFamilyKey=($trustedResearch||$trustedReentry)?$providedPreferred:'';
        $result=self::evaluateRaw($raw,$baseline,$preferredFamilyKey,$relevanceProof,$payload);
        $result=self::applyManualTitleOverride($payload,$result,$raw,$baseline);
        $payload['normal_metadata_path']=$result;
        $payload['raw_keyword_preserved']=$raw;$payload['raw_keyword_sha256']=$raw!==''?hash('sha256',$raw):'';
        $payload['metadata_handoff_fields']=['title','target_keyword','category','article_type','plan_slot'];
        $payload['textmachine_handoff_status']='BLOCKED_BEFORE_COMPILER';
        $payload['sandbox_required']=($result['status']??'')==='SANDBOX_REQUIRED';
        $payload['sandbox_admission_mode']=(string)($result['sandbox_admission_mode']??'');
        $payload['structure_gap_backlog_required']=!empty($result['structure_gap_backlog_required']);
        $payload['retained_non_producing']=!empty($result['retained_non_producing']);
        $payload['category_gap_proposal']=(array)($result['category_gap_proposal']??[]);

        // Preserve former derived decisions as history/evidence, never as current authority.
        if(!isset($payload['source_target_category_id']))$payload['source_target_category_id']=(int)($payload['target_category_id']??0);
        if(!isset($payload['source_target_category_name']))$payload['source_target_category_name']=(string)($payload['target_category_name']??'');
        if(!isset($payload['source_proposed_article_type']))$payload['source_proposed_article_type']=(string)($payload['proposed_article_type']??'');
        if(!isset($payload['source_topic_family_key']))$payload['source_topic_family_key']=(string)($payload['topic_family_key']??'');
        if(!isset($payload['source_topic_family_name']))$payload['source_topic_family_name']=(string)($payload['topic_family_name']??'');
        if(!isset($payload['source_article_type_registry_sha256']))$payload['source_article_type_registry_sha256']=(string)($payload['article_type_registry_sha256']??'');

        // Current derived authority is always overwritten from the freshly recomputed path.
        // An unresolved current family must never leave a historical family looking current.
        $familyKey=(string)($result['family_key']??'');$familyName=(string)($result['family_name']??'');
        $payload['topic_family_key']=$familyKey;$payload['topic_family_name']=$familyName;
        $payload['article_type_registry_sha256']=(string)($result['article_type_registry_sha256']??'');
        $payload['family_identity_v2_registry_sha256']=(string)($result['family_identity_v2_registry_sha256']??'');
        $payload['derived_state_authority']=[
            'contract'=>'PSTE_DERIVED_STATE_AUTHORITY_V1',
            'normal_metadata_path_contract'=>self::CONTRACT,
            'editorial_ruleset'=>PSTE_Editorializer::RULESET,
            'raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'',
            'article_type_registry_sha256'=>(string)($result['article_type_registry_sha256']??''),
            'family_identity_v2_registry_sha256'=>(string)($result['family_identity_v2_registry_sha256']??''),
            'recomputed'=>true,
            'historical_derived_fields_authoritative'=>false,
        ];
        $payload['family_membership_v2']=(array)($result['family_membership']??[]);
        $payload['intent_analysis']=(array)($result['intent_analysis']??[]);
        $payload['semantic_consensus']=(array)($result['semantic_consensus']??[]);
        $payload['intent_profile']=(array)($result['intent_profile']??[]);
        $payload['intent_portfolio']=(array)($result['intent_profile']['secondary_branches']??[]);
        $payload['search_intent']=(string)($result['intent_profile']['search_intent']??'');
        $payload['intent_angle']=(string)($result['intent_profile']['intent_angle']??'');
        $payload['normalized_editorial_topic']=(string)($result['normalization']['normalized_topic']??'');
        $payload['domain_risk']=(array)($result['domain_risk']??[]);
        if(!empty($result['journal_routing'])&&is_array($result['journal_routing']))$payload['journal_routing']=(array)$result['journal_routing'];

        $title=(string)($result['title']??'');$type=(string)($result['article_type']??'');$pipeline=(array)($result['title_pipeline']??[]);
        $payload['editorial_title']=$title;$payload['production_title']=$title;$payload['target_keyword']=(string)($result['target_keyword']??$pipeline['target_keyword']??'');$payload['target_keyword_contract']=(array)($pipeline['target_keyword_contract']??[]);
        $payload['editorial_quality_gate']=(array)($pipeline['editorial_quality']??[]);
        $payload['title_quality']=(array)($pipeline['deterministic']??[]);
        $payload['language_quality']=(array)($pipeline['language']??[]);
        $payload['editorial_dual_strand']=['technical'=>(array)($pipeline['technical_strand']??[]),'editorial'=>(array)($pipeline['editorial_strand']??[])];
        $payload['editorial_intent_key']=(string)($result['intent_profile']['intent_key']??'');

        $status=(string)($result['status']??'REVIEW_REQUIRED');
        $resolved=$status==='NORMAL_PASS';$eligible=$resolved&&$title!==''&&$type!=='';
        if($resolved)$payload['textmachine_handoff_status']='READY_FOR_COMPILER_CAPABILITY_CHECK';
        $payload['editorialization']=[
            'contract'=>PSTE_Editorializer::RULESET,'eligible'=>$eligible,'resolved'=>$resolved,'ambiguous'=>false,
            'article_type'=>$type,'title'=>$title,'normalized_topic'=>(string)($result['normalization']['normalized_topic']??''),
            'intent_key'=>(string)($result['intent_profile']['intent_key']??''),'search_intent'=>(string)($result['intent_profile']['search_intent']??''),'intent_angle'=>(string)($result['intent_profile']['intent_angle']??''),'intent_first'=>true,'seo_basis'=>(array)($result['intent_profile']['seo_basis']??[]),'signals'=>[],'reason'=>$status,'title_pipeline'=>$pipeline,
        ];
        if($type!==''){$payload['suggested_article_type']=$type;$payload['proposed_article_type']=$type;}
        else{$payload['suggested_article_type']='';$payload['proposed_article_type']='';}

        if($resolved){
            $target=(array)$result['target_category'];$id=(int)($target['term_id']??0);$name=(string)($target['name']??'');$slug=(string)($target['slug']??'');
            $payload['target_category_id']=$id;$payload['target_category_name']=$name;$payload['target_category_slug']=$slug;
            $payload['suggested_category_id']=$id;$payload['suggested_category_name']=$name;$payload['suggested_category_slug']=$slug;
            $intentKey=(string)($result['intent_profile']['intent_key']??'');
            $payload['editorialization']['intent_key']=$intentKey;$payload['editorial_intent_key']=$intentKey;
        }else{
            $payload['target_category_id']=0;$payload['target_category_name']='';$payload['target_category_slug']='';
            $payload['suggested_category_id']=0;$payload['suggested_category_name']='';$payload['suggested_category_slug']='';
        }

        $reasons=array_values(array_unique(array_filter(array_merge((array)($payload['reason_codes']??[]),(array)($result['reason_codes']??[])))));
        // Remove obsolete pass claims before adding the current result.
        $reasons=array_values(array_diff($reasons,['EDITORIAL_TITLE_PIPELINE_V4_PASS','EDITORIAL_TITLE_PIPELINE_V5_PASS','ARTICLE_TYPE_AUTOMATICALLY_RESOLVED','PSTE_NORMAL_METADATA_PATH_PASS']));
        if($resolved){$reasons[]='PSTE_NORMAL_METADATA_PATH_PASS';$reasons[]='EDITORIAL_TITLE_PIPELINE_V5_PASS';$reasons[]='ARTICLE_TYPE_AUTOMATICALLY_RESOLVED';}
        $payload['reason_codes']=array_values(array_unique($reasons));
        if($status==='NORMAL_PASS'){$payload['decision']='PASS';$payload['human_review_required']=false;$payload['discovery_only']=false;}
        else{$payload['decision']='BLOCKED';$payload['human_review_required']=true;$payload['discovery_only']=true;}

        if(self::rawSourceInvariant($payload)!==$before)throw new RuntimeException('PSTE_NORMAL_PATH_RAW_SOURCE_FIELD_MUTATION');
        return $payload;
    }


    /**
     * Re-applies an explicitly stored title-only override after the semantic path has been recomputed.
     * The override has zero authority over intent, category, article type or slot identity.
     * A stale/invalid override is ignored fail-safe; the freshly generated valid title remains authoritative.
     * @return array<string,mixed>
     */
    private static function applyManualTitleOverride(array $sourcePayload,array $result,string $raw,array $baseline): array {
        $override=is_array($sourcePayload['manual_title_override']??null)?(array)$sourcePayload['manual_title_override']:[];
        if(!$override||($override['contract']??'')!=='PSTE_MANUAL_TITLE_OVERRIDE_V1')return $result;
        if(($result['status']??'')!=='NORMAL_PASS'||empty($result['ok']))return $result;
        $title=trim((string)($override['title']??''));$binding=(array)($override['binding']??[]);
        $pipeline=(array)($result['title_pipeline']??[]);$targetKeyword=(string)($result['target_keyword']??$pipeline['target_keyword']??'');
        $current=[
            'raw_query_sha256'=>$raw!==''?hash('sha256',$raw):'',
            'family_key'=>(string)($result['family_key']??''),
            'article_type'=>(string)($result['article_type']??''),
            'category_id'=>(int)($result['target_category']['term_id']??0),
            'category_slug'=>(string)($result['target_category']['slug']??''),
            'intent_key'=>(string)($result['intent_profile']['intent_key']??''),
            'target_keyword_sha256'=>$targetKeyword!==''?hash('sha256',$targetKeyword):'',
        ];
        foreach($current as $key=>$value){if(!array_key_exists($key,$binding)||(string)$binding[$key]!== (string)$value){$result['manual_title_override_status']='STALE_NOT_APPLIED';$result['manual_title_override_reason']='BINDING_DRIFT_'.$key;return $result;}}
        $registry=PSTE_Article_Type_Registry::build($baseline);
        $validated=PSTE_Title_Pipeline::validateExistingTitle($title,$raw,(string)($result['family_name']??''),(string)($result['article_type']??''),$registry,(array)($result['intent_profile']??[]),$targetKeyword,(string)($result['normalization']['normalized_topic']??''));
        if(empty($validated['ok'])){$result['manual_title_override_status']='INVALID_NOT_APPLIED';$result['manual_title_override_reason_codes']=self::pipelineReasons($validated);return $result;}
        $result['title']=$title;$result['title_pipeline']=$validated;$result['manual_title_override_status']='APPLIED';$result['manual_title_override_sha256']=hash('sha256',$title);return $result;
    }

    /** @return array<string,mixed> */
    private static function rawSourceInvariant(array $payload): array {return [
        'raw_user_question'=>$payload['raw_user_question']??null,'primary_longtail_query'=>$payload['primary_longtail_query']??null,
        'canonical_query'=>$payload['canonical_query']??null,'query_record'=>$payload['query_record']??null,'query_aliases'=>$payload['query_aliases']??null,
    ];}

    /** @return array<string,mixed>|null */
    private static function retentionDecision(string $raw,string $family): ?array {
        if(PSTE_Normalizer::staleYear($raw)!==null)return ['reason_codes'=>['PSTE_RETAINED_NON_PRODUCING_STALE_YEAR_QUERY']];
        $transactional=(bool)preg_match('/\b(sale|angebot|angebote|rabatt|gutschein|coupon|shop|online\s+kaufen|bestellen|gebraucht\s+kaufen)\b/iu',$raw);
        $editorialSignal=PSTE_Article_Type_Intent_Ontology::hasExplicitIntentOrAmbiguity($raw);
        if($transactional&&!$editorialSignal)return ['reason_codes'=>['PSTE_RETAINED_NON_PRODUCING_TRANSACTIONAL_QUERY']];
        $probe=PSTE_Editorial_Topic_Normalizer::semanticProbe($raw);
        if(!self::hasEditorialIntentSignal($raw)&&self::sameTokenSet($probe,$family))return ['reason_codes'=>['PSTE_RETAINED_NON_PRODUCING_CATEGORY_HEAD_QUERY']];
        return null;
    }
    private static function hasEditorialIntentSignal(string $raw): bool {
        return PSTE_Article_Type_Intent_Ontology::hasExplicitIntentOrAmbiguity($raw);
    }

    private static function sameTokenSet(string $a,string $b): bool {
        $x=PSTE_Token_Equivalence::tokens(str_replace('-',' ',$a));$y=PSTE_Token_Equivalence::tokens(str_replace('-',' ',$b));
        $x=array_values(array_unique($x));$y=array_values(array_unique($y));sort($x,SORT_STRING);sort($y,SORT_STRING);return $x!==[]&&$x===$y;
    }

    /** @return list<string> */
    private static function pipelineReasons(array $p): array {return array_values(array_unique(array_filter(array_merge((array)($p['deterministic']['reason_codes']??[]),(array)($p['language']['reason_codes']??[]),(array)($p['editorial_quality']['reason_codes']??[])))));}
    public static function canonicalInputQuery(string $v): string {$v=trim(html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8'));return trim((string)preg_replace('/\s+/u',' ',$v));}
    public static function sourceMatchesNormalPath(string $source,array $path): bool {$canonical=self::canonicalInputQuery($source);$pathRaw=self::canonicalInputQuery((string)($path['raw_query']??''));$pathSha=(string)($path['raw_query_sha256']??'');return $canonical!==''&&$pathRaw!==''&&preg_match('/^[a-f0-9]{64}$/',$pathSha)===1&&hash_equals($canonical,$pathRaw)&&hash_equals(hash('sha256',$pathRaw),$pathSha);}
    public static function payloadMatchesNormalPath(array $payload,array $path): bool {$pathRaw=self::canonicalInputQuery((string)($path['raw_query']??''));$pathSha=(string)($path['raw_query_sha256']??'');if($pathRaw===''||preg_match('/^[a-f0-9]{64}$/',$pathSha)!==1||!hash_equals(hash('sha256',$pathRaw),$pathSha))return false;$record=is_array($payload['query_record']??null)?(array)$payload['query_record']:[];$candidates=[PSTE_Editorializer::sourceQuery($payload),(string)($payload['primary_longtail_query']??''),(string)($payload['canonical_query']??''),(string)($payload['raw_user_question']??''),(string)($record['language_corrected_query']??''),(string)($record['raw_query']??'')];foreach($candidates as $candidate){$candidate=self::canonicalInputQuery((string)$candidate);if($candidate!==''&&hash_equals($candidate,$pathRaw))return true;}return false;}
    private static function clean(string $v): string {return self::canonicalInputQuery($v);}
    /** @return array<string,mixed> */
    private static function withReasons(array $base,string $status,array $reasons): array {$base['status']=$status;$base['ok']=$status==='NORMAL_PASS';$base['reason_codes']=array_values(array_unique(array_filter(array_map('strval',$reasons))));return $base;}
}
