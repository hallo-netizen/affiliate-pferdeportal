<?php
if (!defined('ABSPATH')) { return; }

/** Additive Journal article-type registration. It owns no family, category, slot, content or routing decision. */
final class PSTE_Journal_Article_Type {
    public const CONTRACT='PSTE_JOURNAL_ARTICLE_TYPE_V1';
    private static ?array $cache=null;
    public static function definition(): array {
        if(self::$cache!==null)return self::$cache;
        $path=defined('PSTE_DIR')?PSTE_DIR.'contracts/journal-article-type-v1.json':dirname(__DIR__).'/contracts/journal-article-type-v1.json';
        $data=is_file($path)?json_decode((string)file_get_contents($path),true):null;
        if(!is_array($data)||($data['contract']??'')!==self::CONTRACT||($data['article_type']??'')!=='Journal')throw new RuntimeException('PSTE_JOURNAL_ARTICLE_TYPE_CONTRACT_INVALID');
        return self::$cache=$data;
    }
    /** Type-level only: no family/category assignment is created here. */
    public static function registerType(array $types): array {
        $d=self::definition();$key='journal';
        if(isset($types[$key]))throw new RuntimeException('PSTE_JOURNAL_ARTICLE_TYPE_ALREADY_REGISTERED');
        $types[$key]=[
            'canonical_type_id'=>'journal','visible_name'=>'Journal','aliases'=>['Journal','journal'],
            'question_allowed'=>true,'handoff_code'=>'Journal','leaf_count'=>0,
            'scope'=>'JOURNAL_CONTENT_BLOCK_ONLY','selection_policy'=>(string)$d['selection_policy'],
            'lexical_auto_routing_allowed'=>(bool)($d['lexical_auto_routing_allowed']??false),'runtime_route_activation'=>(string)$d['runtime_route_activation'],
        ];
        return $types;
    }
    public static function isJournal(string $type): bool {return PSTE_Article_Type_Registry::canonicalType($type)==='journal';}
}
