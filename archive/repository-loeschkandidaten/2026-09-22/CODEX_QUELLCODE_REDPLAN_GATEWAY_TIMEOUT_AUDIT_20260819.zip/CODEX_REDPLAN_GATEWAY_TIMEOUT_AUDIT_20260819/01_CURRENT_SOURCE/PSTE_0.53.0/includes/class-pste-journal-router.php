<?php
if (!defined('ABSPATH')) { return; }

/**
 * Isolated Journal routing after the unchanged product-family path has failed.
 * It is metadata-only, read-only and cannot create taxonomy, content, HTML or production output.
 */
final class PSTE_Journal_Router {
    public const CONTRACT='PSTE_JOURNAL_ROUTER_V1';
    private const TYPE='Journal';

    /** @return array<string,mixed> */
    public static function evaluateAfterFamilyMiss(string $raw,array $baseline,array $registry,array $relevance,array $seoEvidence=[]): array {
        $raw=self::clean($raw);
        $base=['contract'=>self::CONTRACT,'status'=>'NOT_APPLICABLE','ok'=>false,'article_type'=>self::TYPE,'raw_query'=>$raw,'reason_codes'=>[],
            'target_category'=>[],'canonical_plan_category_slug'=>'','family_key'=>'','family_name'=>'','normalization'=>[],'intent_profile'=>[],
            'semantic_consensus'=>[],'title_pipeline'=>[],'title'=>'','target_keyword'=>'','domain_risk'=>[],'runtime_category_resolution'=>[],
            'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'write_attempted'=>false];
        if($raw===''||empty($relevance['ok']))return self::withReasons($base,'NOT_APPLICABLE',['PSTE_JOURNAL_ROUTER_RELEVANCE_REQUIRED']);
        if(!PSTE_Token_Equivalence::contains($raw,'Pferde'))return self::withReasons($base,'NOT_APPLICABLE',['PSTE_JOURNAL_ROUTER_HORSE_SUBJECT_REQUIRED']);

        // Existing article-type signals keep their existing owners. Journal is fallback-only after family miss.
        $strong=array_values(array_unique(array_filter(array_map('strval',PSTE_Article_Type_Intent_Ontology::strongSignals($raw)))));
        if($strong)return self::withReasons($base,'NOT_APPLICABLE',['PSTE_JOURNAL_ROUTER_EXISTING_TYPE_SIGNAL_PRESENT']);
        if(PSTE_Normalizer::hasCommercialModifier($raw)||preg_match('/\b(kaufen|bestellen|shop|angebot|rabatt|gutschein|preis|preise|kosten|vergleich|vergleichen|testsieger|empfehlung|kaufberatung)\b/iu',$raw))return self::withReasons($base,'NOT_APPLICABLE',['PSTE_JOURNAL_ROUTER_COMMERCIAL_OR_COMPARISON_INTENT']);
        if(preg_match('/\b(imprägnier\w*|impraegnier\w*|reparier\w*|reinig\w*|wasch\w*|trockn\w*|pfleg\w*|wart\w*|installier\w*|montier\w*|anwend\w*|dosier\w*|lager\w*|aufbewahr\w*)\b/iu',$raw))return self::withReasons($base,'NOT_APPLICABLE',['PSTE_JOURNAL_ROUTER_PROCEDURAL_INTENT']);

        $risk=PSTE_Domain_Risk_Gate::evaluate($raw,self::TYPE);$base['domain_risk']=$risk;
        if(empty($risk['ok']))return self::withReasons($base,'REVIEW_REQUIRED',array_merge(['PSTE_JOURNAL_ROUTER_DOMAIN_RISK_REVIEW'],(array)($risk['reason_codes']??[])));

        $categorySpec=self::categorySpec($raw);
        if(!$categorySpec)return self::withReasons($base,'REVIEW_REQUIRED',['PSTE_JOURNAL_ROUTER_CATEGORY_NOT_DETERMINISTIC']);
        $resolved=self::resolveRuntimeCategory($categorySpec);$base['runtime_category_resolution']=$resolved;
        if(empty($resolved['ok']))return self::withReasons($base,'CATEGORY_UNAVAILABLE',array_merge(['PSTE_JOURNAL_ROUTER_RUNTIME_CATEGORY_NOT_CONFIRMED'],(array)($resolved['reason_codes']??[])));

        $target=['ok'=>true,'term_id'=>(int)$resolved['term_id'],'name'=>(string)$resolved['name'],'slug'=>(string)$resolved['slug'],'taxonomy'=>'category','article_type'=>self::TYPE,'topic_family_name'=>'Pferde','journal_category'=>true];
        $familyKey=hash('sha256','PSTE_JOURNAL_TOPIC_V1|'.PSTE_Normalizer::exactTopicIdentityText($raw));
        $familyName='Pferde';
        $normalization=['contract'=>'PSTE_EDITORIAL_TOPIC_NORMALIZER_V2','raw_query'=>$raw,'raw_query_sha256'=>hash('sha256',$raw),'family'=>$familyName,
            'normalized_topic'=>rtrim($raw," ?\t\n\r\0\x0B"),'subject_topic'=>$familyName,'semantic_probe'=>PSTE_Editorial_Topic_Normalizer::semanticProbe($raw),
            'qualifier'=>'','relation'=>'','detected_action'=>'','intent_signals'=>['JOURNAL'],'status'=>'PASS','reason_codes'=>['PSTE_JOURNAL_ROUTER_MEANING_PRESERVED'],
            'review_flags'=>[],'raw_query_modified'=>false,'write_attempted'=>false];
        $intent=self::intentProfile($raw,$familyName,$categorySpec,$seoEvidence);
        $surface=self::journalTitleSurface($raw);
        $targetKeyword=self::targetKeyword($surface);
        $title=PSTE_Normalizer::isQuestion($surface)?PSTE_Normalizer::canonicalQuestion($surface):self::sentence($surface);
        $pipeline=PSTE_Title_Pipeline::validateExistingTitle($title,$raw,$familyName,self::TYPE,$registry,$intent,$targetKeyword,(string)$normalization['normalized_topic']);
        $base['title_pipeline']=$pipeline;$base['title']=(string)($pipeline['title']??'');$base['target_keyword']=(string)($pipeline['target_keyword']??'');
        if(empty($pipeline['ok']))return self::withReasons($base,'REVIEW_REQUIRED',array_merge(['PSTE_JOURNAL_ROUTER_TITLE_PIPELINE_NOT_PASS'],self::pipelineReasons($pipeline)));

        $semantic=self::journalConsensus($familyKey,$familyName,$target,$categorySpec);
        $base['target_category']=$target;$base['canonical_plan_category_slug']=(string)($categorySpec['canonical_plan_slug']??'');$base['family_key']=$familyKey;$base['family_name']=$familyName;
        $base['normalization']=$normalization;$base['intent_profile']=$intent;$base['semantic_consensus']=$semantic;
        $base['ok']=true;$base['status']='JOURNAL_ROUTE_PASS';$base['reason_codes']=['PSTE_JOURNAL_ROUTER_PASS'];
        return $base;
    }

    /** @return array<string,mixed> */
    private static function categorySpec(string $raw): array {
        $q=self::lower($raw);
        $map=self::categories();
        if(preg_match('/\b(alt|alter|altern|lebensalter|lebenserwart|lebensdauer|senior|gesundheit|krankheit|organ|zahn|zähne|zaehne|puls|atmung)\w*\b/u',$q))return $map['health'];
        if(preg_match('/\b(futter|fütter|fuetter|ernähr|ernaehr|verdau|magen|darm|heu|gras|wasserbedarf|trinken|nährstoff|naehrstoff)\w*\b/u',$q))return $map['feeding'];
        if(preg_match('/\b(training|ausbildung|reitweise|reiten|lernen|lernt|lernverhalten|bodenarbeit|dressur|springen|longier)\w*\b/u',$q))return $map['training'];
        if(preg_match('/\b(rasse|rassen|pony|ponys|warmblut|kaltblut|vollblut|pferdetyp|größe|groesse|stockmaß|stockmass)\w*\b/u',$q))return $map['breeds'];
        if(preg_match('/\b(recht|haftung|versicherung|vertrag|finanz|steuer|organisation|gesetz|vorschrift)\w*\b/u',$q))return $map['law'];
        if(preg_match('/\b(reiterleben|gemeinschaft|community|turnieralltag|miteinander|verein|veranstaltung)\w*\b/u',$q))return $map['community'];
        if(preg_match('/\b(haltung|stallalltag|stall|weide|offenstall|boxenhaltung|paddock|unterbringung)\w*\b/u',$q))return $map['housing'];
        if(preg_match('/\b(verhalten|körpersprache|koerpersprache|kommunikation|wahrnehmung|sehen|hören|hoeren|riechen|schlaf|schlafen|wohlfühl|wohlfuehl|angst|stress|vertrauen)\w*\b/u',$q))return $map['understanding'];
        return $map['general'];
    }

    /** @return array<string,array<string,mixed>> */
    public static function categories(): array {
        return [
            'understanding'=>['name'=>'Pferde Verstehen','canonical_plan_slug'=>'pferde-verstehen','runtime_slugs'=>['pferde-verstehen']],
            'breeds'=>['name'=>'Pferderassen & Pferdetypen','canonical_plan_slug'=>'pferderassen-und-pferdetypen','runtime_slugs'=>['pferderassen-und-pferdetypen','pferderassen-pferdetypen']],
            'law'=>['name'=>'Recht, Finanzen & Organisation','canonical_plan_slug'=>'recht-finanzen-und-organisation','runtime_slugs'=>['recht-finanzen-und-organisation','recht-finanzen-organisation']],
            'community'=>['name'=>'Reiterleben & Community','canonical_plan_slug'=>'reiterleben-und-community','runtime_slugs'=>['reiterleben-und-community','reiterleben-community']],
            'training'=>['name'=>'Ausbildung & Reitweisen','canonical_plan_slug'=>'ausbildung-und-reitweisen','runtime_slugs'=>['ausbildung-und-reitweisen','ausbildung-reitweisen']],
            'feeding'=>['name'=>'Pferdeernährung verstehen','canonical_plan_slug'=>'pferdeernaehrung-verstehen','runtime_slugs'=>['pferdeernaehrung-verstehen']],
            'health'=>['name'=>'Pferdegesundheit verstehen','canonical_plan_slug'=>'pferdegesundheit-verstehen','runtime_slugs'=>['pferdegesundheit-verstehen']],
            'housing'=>['name'=>'Alltags-Pferde-Haltungsformen','canonical_plan_slug'=>'alltags-pferde-haltungsformen','runtime_slugs'=>['alltags-pferde-haltungsformen']],
            'general'=>['name'=>'Pferdewissen & Grundlagen','canonical_plan_slug'=>'pferdewissen-grundlagen','runtime_slugs'=>['pferdewissen-grundlagen']],
        ];
    }

    /** @return array<string,mixed> */
    private static function resolveRuntimeCategory(array $spec): array {
        if(!function_exists('get_term_by'))return ['ok'=>false,'status'=>'WORDPRESS_TERM_API_UNAVAILABLE','reason_codes'=>['PSTE_JOURNAL_ROUTER_TERM_API_UNAVAILABLE'],'term_id'=>0,'name'=>'','slug'=>''];
        $matches=[];
        foreach((array)($spec['runtime_slugs']??[]) as $slug){$term=get_term_by('slug',(string)$slug,'category');if(!$term|| (function_exists('is_wp_error')&&is_wp_error($term)))continue;$id=(int)($term->term_id??0);$actualSlug=trim((string)($term->slug??''));$name=trim((string)($term->name??''));if($id>0&&$actualSlug!=='')$matches[$id]=['term_id'=>$id,'name'=>$name,'slug'=>$actualSlug,'taxonomy'=>(string)($term->taxonomy??'category'),'parent'=>(int)($term->parent??0)];}
        if(count($matches)!==1)return ['ok'=>false,'status'=>count($matches)>1?'AMBIGUOUS':'NOT_FOUND','reason_codes'=>[count($matches)>1?'PSTE_JOURNAL_ROUTER_CATEGORY_AMBIGUOUS':'PSTE_JOURNAL_ROUTER_CATEGORY_NOT_FOUND'],'term_id'=>0,'name'=>'','slug'=>''];
        $m=array_values($matches)[0];if((string)$m['taxonomy']!=='category')return ['ok'=>false,'status'=>'TAXONOMY_MISMATCH','reason_codes'=>['PSTE_JOURNAL_ROUTER_CATEGORY_TAXONOMY_MISMATCH'],'term_id'=>0,'name'=>'','slug'=>''];
        return array_merge(['ok'=>true,'status'=>'CONFIRMED','reason_codes'=>[]],$m);
    }

    /** @return array<string,mixed> */
    private static function intentProfile(string $raw,string $family,array $category,array $seoEvidence): array {
        $basis=[];if(!empty($seoEvidence['metrics']['search_intent'])||!empty($seoEvidence['search_intent']))$basis[]='DATAFORSEO_SEARCH_INTENT';if(!empty($seoEvidence['intent_tuple']))$basis[]='SEO_INTENT_TUPLE';if(!empty($seoEvidence['evidence']))$basis[]='SEO_OBSERVATION_EVIDENCE';if(!$basis)$basis[]='JOURNAL_INTENT_FALLBACK_AFTER_PRODUCT_FAMILY_MISS';
        $out=['contract'=>PSTE_Intent_Profile::CONTRACT,'phase'=>'BOUND_TYPE','status'=>'PASS','ok'=>true,'intent_first'=>true,'raw_query'=>$raw,'family'=>$family,'subject_topic'=>$family,'qualifier'=>'','qualifier_relation'=>'','focus_term'=>$family,'qualifier_must_be_preserved'=>false,
            'primary_user_goal'=>'EDITORIAL_INFORMATION','primary_article_type_candidate'=>self::TYPE,'intent_angle'=>'journal_explanatory','provider_search_intent'=>(string)($seoEvidence['metrics']['search_intent']??$seoEvidence['search_intent']??''),'provider_intent_probability'=>(float)($seoEvidence['metrics']['intent_probability']??$seoEvidence['intent_probability']??0),
            'intent_tuple'=>is_array($seoEvidence['intent_tuple']??null)?(array)$seoEvidence['intent_tuple']:['user_goal'=>'information','decision_or_problem'=>PSTE_Normalizer::exactTopicIdentityText($raw),'context'=>PSTE_Normalizer::exactTopicIdentityText($raw),'answer_promise'=>PSTE_Normalizer::exactTopicIdentityText($raw)],
            'seo_basis'=>$basis,'secondary_branches'=>[],'secondary_branch_policy'=>'ONLY_WHEN_DISTINCT_SEO_EVIDENCE_EXISTS_RESEARCH_PROPOSAL_ONLY','auto_fanout_allowed'=>false,'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'write_attempted'=>false,
            'article_type'=>self::TYPE,'search_intent'=>'EDITORIAL_INFORMATION','semantic_intent_consensus'=>true,'classifier_type_compatible_with_pre_type_intent'=>true,'article_type_available'=>true,
            'intent_key'=>hash('sha256','PSTE_JOURNAL_INTENT_V1|'.PSTE_Normalizer::exactTopicIdentityText($raw).'|'.(string)($category['canonical_plan_slug']??'')),'reason_codes'=>['PSTE_JOURNAL_INTENT_ROUTE_PROVEN']];
        $copy=$out;unset($copy['profile_sha256']);$out['profile_sha256']=self::stableHash($copy);return $out;
    }

    private static function journalTitleSurface(string $raw): string {
        // Raw SEO evidence remains untouched. Journal already proves the horse subject before this point;
        // normalize only the German noun surface used by title/target-keyword authority.
        return (string)preg_replace('/\bpferde\b/ui','Pferde',self::clean($raw));
    }
    private static function targetKeyword(string $raw): string {return trim(rtrim(self::sentence($raw),'?'));}
    private static function sentence(string $raw): string {$v=self::clean($raw);if($v==='')return '';$f=function_exists('mb_substr')?mb_substr($v,0,1,'UTF-8'):substr($v,0,1);$r=function_exists('mb_substr')?mb_substr($v,1,null,'UTF-8'):substr($v,1);$f=function_exists('mb_strtoupper')?mb_strtoupper($f,'UTF-8'):strtoupper($f);return $f.$r;}

    /** @return array<string,mixed> */
    private static function journalConsensus(string $familyKey,string $familyName,array $target,array $category): array {
        return ['contract'=>'PSTE_JOURNAL_ROUTING_CONSENSUS_V1','status'=>'CONSENSUS_PASS','ok'=>true,'type_consensus'=>true,'category_consensus'=>true,'family_consensus'=>true,
            'resolved_article_type'=>self::TYPE,'resolved_category'=>$target,'journal_family_key'=>$familyKey,'journal_family_name'=>$familyName,'canonical_plan_category_slug'=>(string)($category['canonical_plan_slug']??''),
            'selection_policy'=>'FALLBACK_ONLY_AFTER_EXISTING_PRODUCT_FAMILY_MISS','other_article_type_routing_consumed'=>false,'write_attempted'=>false,'reason_codes'=>['PSTE_JOURNAL_ROUTING_CONSENSUS_PASS']];
    }
    /** @return list<string> */
    private static function pipelineReasons(array $pipeline): array {$out=[];foreach(['deterministic','language','editorial_quality'] as $k)foreach((array)($pipeline[$k]['reason_codes']??$pipeline[$k]['errors']??[]) as $r)$out[]=(string)$r;return array_values(array_unique(array_filter($out)));}
    private static function withReasons(array $base,string $status,array $reasons): array {$base['status']=$status;$base['ok']=false;$base['reason_codes']=array_values(array_unique(array_filter(array_map('strval',$reasons))));return $base;}
    private static function stableHash($v): string {if(is_array($v)){if(array_keys($v)!==range(0,count($v)-1)){ksort($v,SORT_STRING);}foreach($v as $k=>$x)$v[$k]=is_array($x)?self::stableValue($x):$x;}$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);return hash('sha256',(string)$j);}
    private static function stableValue($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if(!$list)ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::stableValue($x);return $v;}
    private static function clean(string $v): string {$v=html_entity_decode(function_exists('wp_strip_all_tags')?wp_strip_all_tags($v):strip_tags($v),ENT_QUOTES|ENT_HTML5,'UTF-8');return trim((string)preg_replace('/\s+/u',' ',$v));}
    private static function lower(string $v): string {return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
}
