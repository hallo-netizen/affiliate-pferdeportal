<?php
if (!defined('ABSPATH')) { return; }

/** Mechanical portal title invariants only. Semantic intent is owned by the independent editorial/intent strand. */
final class PSTE_Title_Validator {
    /** @return array<string,mixed> */
    public static function validate(string $title,string $source,string $family,string $type,array $registry,string $targetKeyword=''): array {
        $r=[];$len=function_exists('mb_strlen')?mb_strlen($title,'UTF-8'):strlen($title);$canon=PSTE_Article_Type_Registry::canonicalType($type);$isFaq=$canon==='faq';$isJournal=$canon==='journal';
        if($title==='')$r[]='TITLE_EMPTY';if($len<8)$r[]='TITLE_TOO_SHORT';if($len>110)$r[]='TITLE_TOO_LONG';
        if(preg_match($isJournal?'/[^\p{L}\p{N}\s?:?–-]/u':'/[^\p{L}\p{N}\s?–-]/u',$title))$r[]='TITLE_SPECIAL_CHARACTER_FORBIDDEN';
        $qCount=substr_count($title,'?');
        if($isFaq){if($qCount!==1||!str_ends_with($title,'?'))$r[]='FAQ_TITLE_REQUIRES_SINGLE_TERMINAL_QUESTION_MARK';}
        elseif($isJournal){if($qCount>1||($qCount===1&&!str_ends_with($title,'?')))$r[]='JOURNAL_QUESTION_MARK_MUST_BE_SINGLE_TERMINAL_WHEN_USED';}
        else{if($qCount>0)$r[]='QUESTION_MARK_EXCLUSIVE_TO_FAQ';}
        if(preg_match('/<[^>]+>|\{\{|\[\[/u',$title))$r[]='TITLE_MARKUP_OR_TEMPLATE_ARTIFACT';
        if(preg_match('/\b([\p{L}\d]+)\s+\1\b/iu',$title))$r[]='TITLE_REPEATED_WORD';
        if(preg_match('/\s{2,}/u',$title))$r[]='TITLE_WHITESPACE_INVALID';
        if(self::hasArtificialGeneratorPhrase($title))$r[]='TITLE_ARTIFICIAL_GENERATOR_PHRASE_FORBIDDEN';
        if($canon==='beratung'&&self::isRepeatedGenericBeratungSchema($title))$r[]='TITLE_BERATUNG_REPEATED_GENERIC_SCHEMA_FORBIDDEN';
        if(!$isFaq&&self::isKeywordStaccato($title,$type))$r[]='TITLE_KEYWORD_STACCATO_FORBIDDEN';
        $targetKeyword=trim($targetKeyword);
        if($targetKeyword==='')$r[]='TITLE_TARGET_KEYWORD_MISSING';
        elseif(!self::containsKeyword($title,$targetKeyword))$r[]='TITLE_TARGET_KEYWORD_EXACT_SUBSTRING_REQUIRED';
        return ['ok'=>!$r,'status'=>$r?'TITLE_TECHNICAL_REVIEW':'TITLE_TECHNICAL_PASS','reason_codes'=>array_values(array_unique($r)),'semantic_quality_claimed'=>false,'write_attempted'=>false,'target_keyword'=>$targetKeyword,'ppm_target_keyword_binding_prevalidated'=>true,'keyword_prefix_enforced'=>false,'keyword_position_1_required'=>false,'keyword_coverage_rule'=>'EXACT_SUBSTRING_ANY_POSITION','validator_contract'=>'PSTE_TECHNICAL_TITLE_VALIDATOR_V8_BERATUNG_REPEAT_SCHEMA_HARD'];
    }

    public static function containsKeyword(string $title,string $keyword): bool {
        $title=trim(rtrim($title,'?'));$keyword=trim($keyword);if($title===''||$keyword==='')return false;
        $t=self::lower($title);$k=self::lower($keyword);return function_exists('mb_strpos')?mb_strpos($t,$k,0,'UTF-8')!==false:strpos($t,$k)!==false;
    }

    public static function isKeywordStaccato(string $title,string $type=''): bool {
        $canon=class_exists('PSTE_Article_Type_Registry')?PSTE_Article_Type_Registry::canonicalType($type):'';
        if($canon==='faq'||str_contains($title,'?'))return false;
        $clean=self::lower(trim((string)preg_replace('/\s+/u',' ',rtrim($title,'?'))));
        $parts=preg_split('/\s+/u',$clean)?:[];if(count($parts)<3)return false;
        // Natural German noun phrases are not staccato when they contain a grammatical relation.
        if(preg_match('/\b(?:der|die|das|den|dem|des|ein|eine|einer|einem|einen|mit|für|fuer|ohne|gegen|von|bei|beim|im|in|auf|unter|zum|zur|am|an|als|aus|durch|nach|vor|über|ueber|zwischen|und|oder)\b/u',$clean))return false;
        // Procedural/finite verb surfaces are natural compact titles, not keyword chains.
        if(preg_match('/\b(?:auswähl\w*|auswaehl\w*|wähl\w*|waehl\w*|find\w*|beacht\w*|entscheid\w*|plan\w*|pfleg\w*|reinig\w*|wasch\w*|kost\w*|preis\w*|sicher\w*|installier\w*|montier\w*|anwend\w*|benutz\w*|verwend\w*|nutz\w*|einsetz\w*|lager\w*|aufbewahr\w*|trainier\w*|übung\w*|uebung\w*|ist|sind|kann|können|koennen|soll|sollen|muss|müssen|muessen|eignet|braucht|imprägnier\w*|impraegnier\w*|reparier\w*|trockn\w*|wart\w*|fahr\w*|schütz\w*|schuetz\w*|vermeid\w*|prüf\w*|pruef\w*)\b/u',$clean))return false;
        return true;
    }
    public static function isRepeatedGenericBeratungSchema(string $title): bool {
        $clean=trim((string)preg_replace('/\s+/u',' ',$title));
        return (bool)preg_match('/^Passend(?:e|er|es|en|em)?\s+.+\s+richtig\s+ausw(?:ä|ae)hlen$/iu',$clean);
    }
    public static function hasArtificialGeneratorPhrase(string $title): bool {
        return (bool)preg_match('/\b(?:fachgerecht\s+umsetzen|sinnvoll\s+einordnen|nach\s+Nutzen\s+und\s+Einsatz\s+beurteilen|nach\s+Nutzen\s+und\s+Anforderungen\s+beurteilen|hinsichtlich\s+Nutzen\s+und\s+Einsatz\s+einordnen|passend\s+zum\s+Bedarf\s+einordnen|nach\s+Bedarf\s+beurteilen|nach\s+Anforderungen\s+beurteilen|passend\s+zum\s+Einsatz\s+einordnen|mit\s+einem\s+klaren\s+Vorgehen|sinnvoll\s+in\s+die\s+Praxis\s+umsetzen|transparent\s+beurteilen|realistisch\s+einordnen)\b/iu',$title);
    }
    private static function lower(string $v): string{return function_exists('mb_strtolower')?mb_strtolower($v,'UTF-8'):strtolower($v);}
}
