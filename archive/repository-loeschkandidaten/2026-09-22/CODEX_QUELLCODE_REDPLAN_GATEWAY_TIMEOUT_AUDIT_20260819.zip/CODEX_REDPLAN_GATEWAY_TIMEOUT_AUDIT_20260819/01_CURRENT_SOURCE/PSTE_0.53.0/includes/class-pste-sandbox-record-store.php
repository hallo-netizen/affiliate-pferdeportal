<?php
if (!defined('ABSPATH')) { return; }

/**
 * Record-local technical Sandbox store and request-bounded legacy migration.
 *
 * The legacy WordPress option stays untouched as rollback authority. Migration reads the
 * serialized option directly from wp_options in small binary chunks, so no request ever
 * unserializes the complete ~58 MiB registry. At most B records are decoded, written and
 * read back per request. A resumable canonical SHA-256 verification then proves that the
 * record-local generation reconstructs the exact legacy registry hash.
 *
 * No article, taxonomy, prompt, title, plan, production or publish write authority exists here.
 */
final class PSTE_Sandbox_Record_Store {
    public const MANIFEST_CONTRACT='PSTE_SANDBOX_RECORD_STORE_MANIFEST_V3_STREAMING';
    public const RECORD_CONTRACT='PSTE_SANDBOX_RECORD_STORE_RECORD_V1';
    public const MIGRATION_CONTRACT='PSTE_SANDBOX_RECORD_STORE_MIGRATION_V3_DB_STREAM';
    private const STATUS_SOURCE_HASH_BEFORE='SOURCE_HASH_BEFORE';
    private const STATUS_INIT_PARSE='INIT_PARSE';
    private const STATUS_MIGRATING='MIGRATING';
    private const STATUS_HASH_VERIFY='HASH_VERIFY';
    private const STATUS_SOURCE_HASH_AFTER='SOURCE_HASH_AFTER';
    private const STATUS_COMPLETE='COMPLETE';
    private const MAX_BATCH=25;
    private const SOURCE_CHUNK_BYTES=262144; // 256 KiB parser window.
    private const HASH_CHUNK_BYTES=1048576; // 1 MiB raw source hash window.
    private const MAX_RECORD_SERIALIZED_BYTES=2097152; // hard per-record safety ceiling.

    /** @var array<string,int> */
    private static array $metrics=[
        'record_reads'=>0,'record_writes'=>0,'record_verifies'=>0,
        'manifest_reads'=>0,'manifest_writes'=>0,'legacy_full_reads'=>0,
        'source_chunks_read'=>0,'source_bytes_read'=>0,'source_records_read'=>0,
        'source_meta_reads'=>0,'canonical_hash_records'=>0,
    ];

    /** @return array<string,int> */
    public static function metrics(): array { return self::$metrics; }
    public static function resetMetrics(): void { foreach(self::$metrics as $k=>$v) self::$metrics[$k]=0; }
    /** Internal stream-reader metric hook. */
    public static function noteSourceChunk(int $bytes): void {self::$metrics['source_chunks_read']++;self::$metrics['source_bytes_read']+=max(0,$bytes);}

    public static function isComplete(): bool {$m=self::manifest(false);return is_array($m)&&self::manifestCompleteAndConsistent($m);}
    public static function migrationActive(): bool {$m=self::manifest(false);return is_array($m)&&($m['contract']??'')===self::MANIFEST_CONTRACT&&in_array((string)($m['status']??''),[self::STATUS_SOURCE_HASH_BEFORE,self::STATUS_INIT_PARSE,self::STATUS_MIGRATING,self::STATUS_HASH_VERIFY,self::STATUS_SOURCE_HASH_AFTER],true);}
    public static function assertLegacyWriteAllowed(): void {if(self::migrationActive())throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_MIGRATION_ACTIVE_LEGACY_WRITE_BLOCKED');}

    /**
     * Initialize streaming migration by parsing only the top-level prefix and the records array header.
     * @return array<string,mixed>
     */
    public static function stageSourceIfNeeded(): array {
        $m=self::manifest(false);if(self::manifestUsable($m))return $m;
        if(is_array($m)&&$m&&($m['contract']??'')===self::MANIFEST_CONTRACT)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_SOURCE_STALE_OR_BLOCKED');
        $meta=self::sourceMetaCheap();$nonce=function_exists('wp_generate_uuid4')?wp_generate_uuid4():uniqid('',true);$generation=substr(hash('sha256','PSTE_SANDBOX_RECORD_STORE_V3|'.$meta['option_id'].'|'.$meta['bytes'].'|'.$nonce),0,24);
        $m=[
            'contract'=>self::MANIFEST_CONTRACT,'migration_contract'=>self::MIGRATION_CONTRACT,'status'=>self::STATUS_SOURCE_HASH_BEFORE,'generation'=>$generation,
            'source_option_id'=>$meta['option_id'],'source_bytes'=>$meta['bytes'],'source_raw_sha256'=>'','source_declared_registry_sha256'=>'',
            'prehash_cursor'=>0,'prehash_context_b64'=>'','posthash_cursor'=>0,'posthash_context_b64'=>'',
            'top_level_count'=>0,'top_level_consumed'=>0,'legacy_header'=>[],
            'record_count'=>0,'record_ids'=>[],'record_ids_sha256'=>'','source_offset'=>0,'migration_cursor'=>0,
            'hash_cursor'=>0,'hash_context_b64'=>'','hash_prefix_done'=>false,'source_complete'=>false,
            'last_receipt_sha256'=>'','started_at_utc'=>gmdate('c'),'completed_at_utc'=>null,
            'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,'production_handoff_attempted'=>false,
        ];self::writeManifest($m);return self::manifest(true);
    }

    /** Advance at most $limit source/target records. @return array<string,mixed> */
    public static function advanceMigration(int $limit=3): array {
        $limit=max(1,min(self::MAX_BATCH,$limit));$m=self::stageSourceIfNeeded();if(self::manifestCompleteAndConsistent($m))return $m;
        self::assertSourceIdentityCheap($m);$status=(string)($m['status']??'');
        if($status===self::STATUS_SOURCE_HASH_BEFORE)return self::advanceRawSourceHash($m,$limit,true);
        if($status===self::STATUS_INIT_PARSE)return self::initializeParseState($m);
        if($status===self::STATUS_MIGRATING)return self::advanceSourceRecords($m,$limit);
        if($status===self::STATUS_HASH_VERIFY)return self::advanceCanonicalHashVerify($m,$limit);
        if($status===self::STATUS_SOURCE_HASH_AFTER)return self::advanceRawSourceHash($m,$limit,false);
        throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_MIGRATION_STATE_INVALID');
    }

    /** @return list<string> */
    public static function sourceRecordIds(): array {$m=self::requireComplete();return array_values(array_map('strval',(array)$m['record_ids']));}
    /** @return list<string> */
    public static function recordIds(): array {return self::sourceRecordIds();}
    /** @return array<string,mixed> */
    public static function getRecord(string $id): array {$m=self::requireComplete();$env=self::readRecordEnvelope($id,(string)$m['generation']);return (array)$env['record'];}

    /** @param array<string,array<string,mixed>> $records */
    public static function putRecordsBatch(array $records): void {
        if(count($records)>self::MAX_BATCH)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_BATCH_LIMIT_EXCEEDED');$m=self::requireComplete();$generation=(string)$m['generation'];$allowed=array_fill_keys(array_map('strval',(array)$m['record_ids']),true);
        foreach($records as $id=>$record){$id=(string)$id;if(!isset($allowed[$id]))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_UNKNOWN_ID');self::writeRecordEnvelope($id,(array)$record,$generation,self::stableHash($record));}
    }

    /** Small technical summary update; never scans records. */
    public static function updateRefreshSummary(array $summary): void {$m=self::requireComplete();$m['last_binding_refresh_at_utc']=gmdate('c');$m['last_binding_refresh_counts']=['updated'=>(int)($summary['updated']??0),'source_stale'=>(int)($summary['source_stale']??0),'missing'=>(int)($summary['missing']??0)];self::writeManifest($m);}

    /** Explicit full audit only; never used by normal binding/AJAX. @return array<string,mixed> */
    public static function logicalRegistry(): array {$m=self::requireComplete();$header=(array)($m['legacy_header']??[]);$records=[];foreach(self::recordIds() as $id)$records[$id]=self::getRecord($id);$header['records']=$records;unset($header['sha256']);$header['sha256']=self::stableHash($header);return $header;}

    /** Canonical legacy writes make the current generation stale; legacy remains rollback authority. */
    public static function invalidateAfterLegacyWrite(string $legacySha=''): void {$m=self::manifest(false);if(!is_array($m)||($m['contract']??'')!==self::MANIFEST_CONTRACT)return;$m['status']='STALE_LEGACY_CHANGED';$m['stale_source_registry_sha256']=$legacySha;$m['stale_at_utc']=gmdate('c');self::writeManifest($m);}

    /** @return array<string,mixed> */
    private static function advanceRawSourceHash(array $m,int $limit,bool $before): array {
        $cursorField=$before?'prehash_cursor':'posthash_cursor';$ctxField=$before?'prehash_context_b64':'posthash_context_b64';$cursor=(int)($m[$cursorField]??0);$total=(int)($m['source_bytes']??-1);if($cursor<0||$total<=0||$cursor>$total)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_RAW_HASH_CURSOR_INVALID');
        $raw=(string)($m[$ctxField]??'');if($raw===''){$ctx=hash_init('sha256');}else{$decoded=base64_decode($raw,true);$ctx=$decoded===false?false:@unserialize($decoded,['allowed_classes'=>['HashContext']]);if(!$ctx instanceof HashContext)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_RAW_HASH_CONTEXT_INVALID');}
        $chunks=0;while($cursor<$total&&$chunks<$limit){$want=min(self::HASH_CHUNK_BYTES,$total-$cursor);$chunk=self::readRawSourceChunk($cursor,$want);if(strlen($chunk)!==$want)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_RAW_HASH_SHORT_READ');hash_update($ctx,$chunk);$cursor+=$want;$chunks++;}
        $m[$cursorField]=$cursor;$m[$ctxField]=base64_encode(serialize($ctx));$m['last_receipt_sha256']=self::stableHash(['phase'=>$before?'SOURCE_HASH_BEFORE':'SOURCE_HASH_AFTER','cursor'=>$cursor,'bytes'=>$total]);
        if($cursor<$total){self::writeManifest($m);return self::manifest(true);}
        $actual=hash_final($ctx);$m[$ctxField]='';if($before){$m['source_raw_sha256']=$actual;$m['status']=self::STATUS_INIT_PARSE;$m['last_receipt_sha256']=self::stableHash(['phase'=>'SOURCE_HASH_BEFORE_COMPLETE','sha256'=>$actual,'bytes'=>$total]);}
        else{if(!preg_match('/^[a-f0-9]{64}$/',(string)($m['source_raw_sha256']??''))||!hash_equals((string)$m['source_raw_sha256'],$actual))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_SOURCE_CHANGED_DURING_MIGRATION');$m['source_post_sha256']=$actual;$m['status']=self::STATUS_COMPLETE;$m['completed_at_utc']=gmdate('c');$m['last_receipt_sha256']=self::stableHash(['phase'=>'COMPLETE','record_count'=>count((array)$m['record_ids']),'record_ids_sha256'=>(string)$m['record_ids_sha256'],'logical_registry_sha256'=>(string)$m['logical_registry_sha256'],'source_raw_sha256'=>$actual]);}
        self::writeManifest($m);$stored=self::manifest(true);if(!$before&&!self::manifestCompleteAndConsistent($stored))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_MANIFEST_READBACK_FAILED');return $stored;
    }

    /** @return array<string,mixed> */
    private static function initializeParseState(array $m): array {
        if(!preg_match('/^[a-f0-9]{64}$/',(string)($m['source_raw_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_PREHASH_REQUIRED');
        $reader=new PSTE_Sandbox_Legacy_Option_Stream(0,self::SOURCE_CHUNK_BYTES);$topCount=$reader->readArrayHeader();$header=[];$consumed=0;$recordsCount=null;
        while($consumed<$topCount){$key=$reader->readValue();if(!is_string($key))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_TOP_KEY_INVALID');$consumed++;if($key==='records'){$recordsCount=$reader->readArrayHeader();break;}$header[$key]=$reader->readValue();}
        if($recordsCount===null||$recordsCount<0)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_RECORDS_FIELD_MISSING');if((string)($header['contract']??'')!==PSTE_Semantic_Review_Sandbox::CONTRACT)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_LEGACY_CONTRACT_INVALID');if(!in_array((string)($header['version']??''),['1.0.0','1.1.0','1.2.0','1.3.0','1.4.0','1.5.0'],true))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_LEGACY_VERSION_INVALID');
        $m['top_level_count']=$topCount;$m['top_level_consumed']=$consumed;$m['legacy_header']=$header;$m['record_count']=$recordsCount;$m['record_ids']=[];$m['record_ids_sha256']='';$m['source_offset']=$reader->offset();$m['migration_cursor']=0;$m['status']=self::STATUS_MIGRATING;$m['last_receipt_sha256']=self::stableHash(['phase'=>'INIT_PARSE','records'=>$recordsCount,'source_offset'=>$reader->offset()]);self::writeManifest($m);return self::manifest(true);
    }

    private static function readRawSourceChunk(int $offset,int $length): string {global $wpdb;if($offset<0||$length<=0||$length>self::HASH_CHUNK_BYTES)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_RAW_CHUNK_ARGUMENT_INVALID');if(!isset($wpdb)||!isset($wpdb->options)||!method_exists($wpdb,'get_var')||!method_exists($wpdb,'prepare'))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_DB_STREAM_UNAVAILABLE');$sql=$wpdb->prepare("SELECT SUBSTRING(CAST(option_value AS BINARY), %d, %d) FROM {$wpdb->options} WHERE option_name=%s LIMIT 1",$offset+1,$length,PSTE_OPTION_SEMANTIC_SANDBOX);$chunk=$wpdb->get_var($sql);if(!is_string($chunk))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_RAW_CHUNK_READ_FAILED');self::noteSourceChunk(strlen($chunk));return $chunk;}

    /** @return array<string,mixed> */
    private static function advanceSourceRecords(array $m,int $limit): array {
        $cursor=(int)($m['migration_cursor']??0);$total=(int)($m['record_count']??-1);if($cursor<0||$total<0||$cursor>$total)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_MIGRATION_CURSOR_INVALID');
        $reader=new PSTE_Sandbox_Legacy_Option_Stream((int)($m['source_offset']??0),self::SOURCE_CHUNK_BYTES);$ids=array_values(array_map('strval',(array)($m['record_ids']??[])));$seen=array_fill_keys($ids,true);$receipt=[];$processed=0;
        while($cursor<$total&&$processed<$limit){$id=$reader->readValue();if(!is_string($id)||!preg_match('/^[a-f0-9]{64}$/',$id)||isset($seen[$id]))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_LEGACY_RECORD_ID_INVALID');$recordStart=$reader->offset();$record=$reader->readValue();$recordBytes=$reader->offset()-$recordStart;if($recordBytes>self::MAX_RECORD_SERIALIZED_BYTES)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_RECORD_SIZE_LIMIT_EXCEEDED');if(!is_array($record))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_LEGACY_RECORD_INVALID');
            if((string)($record['sandbox_id']??'')!==$id)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_RECORD_ID_MISMATCH');PSTE_Semantic_Review_Sandbox::verifyRecordForStorage($record);$sha=self::stableHash($record);self::writeRecordEnvelope($id,$record,(string)$m['generation'],$sha);$ids[]=$id;$seen[$id]=true;$receipt[]=[$id,$sha];$cursor++;$processed++;self::$metrics['source_records_read']++;
        }
        $m['record_ids']=$ids;$m['migration_cursor']=$cursor;$m['source_offset']=$reader->offset();$m['last_receipt_sha256']=self::stableHash(['phase'=>'MIGRATING','cursor'=>$cursor,'rows'=>$receipt]);
        if($cursor===$total){$reader->expectArrayClose();$m['source_offset']=$reader->offset();$m=self::parseSourceTail($m,$reader);$sorted=$ids;sort($sorted,SORT_STRING);$m['record_ids']=$sorted;$m['record_ids_sha256']=self::stableHash($sorted);$m['status']=self::STATUS_HASH_VERIFY;$m['hash_cursor']=0;$m['hash_context_b64']='';$m['hash_prefix_done']=false;$m['source_complete']=true;}
        self::writeManifest($m);return self::manifest(true);
    }

    /** @return array<string,mixed> */
    private static function parseSourceTail(array $m,PSTE_Sandbox_Legacy_Option_Stream $reader): array {
        $header=(array)($m['legacy_header']??[]);$consumed=(int)($m['top_level_consumed']??0);$top=(int)($m['top_level_count']??-1);
        while($consumed<$top){$key=$reader->readValue();if(!is_string($key)||$key==='records'||array_key_exists($key,$header))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_TOP_TAIL_KEY_INVALID');$header[$key]=$reader->readValue();$consumed++;}
        $reader->expectArrayClose();if($reader->offset()!==(int)$m['source_bytes'])throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_SOURCE_TRAILING_BYTES');
        $decl=(string)($header['sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$decl))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_LEGACY_HASH_REQUIRED');unset($header['sha256']);$m['legacy_header']=$header;$m['source_declared_registry_sha256']=$decl;$m['top_level_consumed']=$consumed;$m['source_offset']=$reader->offset();return $m;
    }

    /** @return array<string,mixed> */
    private static function advanceCanonicalHashVerify(array $m,int $limit): array {
        if(empty($m['source_complete']))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_SOURCE_NOT_COMPLETE');$ids=array_values(array_map('strval',(array)$m['record_ids']));self::assertIds($m,$ids);$cursor=(int)($m['hash_cursor']??0);if($cursor<0||$cursor>count($ids))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_HASH_CURSOR_INVALID');
        if(empty($m['hash_prefix_done'])){$ctx=hash_init('sha256');self::hashRegistryPrefixThroughRecords($ctx,(array)$m['legacy_header']);$m['hash_context_b64']=base64_encode(serialize($ctx));$m['hash_prefix_done']=true;}else{$raw=base64_decode((string)($m['hash_context_b64']??''),true);$ctx=$raw===false?false:@unserialize($raw,['allowed_classes'=>['HashContext']]);if(!$ctx instanceof HashContext)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_HASH_CONTEXT_INVALID');}
        $end=min(count($ids),$cursor+$limit);for($i=$cursor;$i<$end;$i++){$id=$ids[$i];$env=self::readRecordEnvelope($id,(string)$m['generation']);if($i>0)hash_update($ctx,',');hash_update($ctx,self::json($id));hash_update($ctx,':');self::streamCanonicalValue($ctx,(array)$env['record']);self::$metrics['canonical_hash_records']++;}$cursor=$end;$m['hash_cursor']=$cursor;
        if($cursor<count($ids)){$m['hash_context_b64']=base64_encode(serialize($ctx));$m['last_receipt_sha256']=self::stableHash(['phase'=>'HASH_VERIFY','cursor'=>$cursor]);self::writeManifest($m);return self::manifest(true);}
        self::hashRegistrySuffixAfterRecords($ctx,(array)$m['legacy_header']);$actual=hash_final($ctx);$decl=(string)($m['source_declared_registry_sha256']??'');if(!hash_equals($decl,$actual))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_LOGICAL_REGISTRY_HASH_MISMATCH');
        $m['status']=self::STATUS_SOURCE_HASH_AFTER;$m['logical_registry_sha256']=$actual;$m['migration_verified_record_count']=count($ids);$m['hash_context_b64']='';$m['posthash_cursor']=0;$m['posthash_context_b64']='';$m['last_receipt_sha256']=self::stableHash(['phase'=>'HASH_VERIFY_COMPLETE','record_count'=>count($ids),'record_ids_sha256'=>$m['record_ids_sha256'],'logical_registry_sha256'=>$actual]);self::writeManifest($m);return self::manifest(true);
    }

    /** Feed canonical top-level keys before "records" plus the records-object opener. */
    private static function hashRegistryPrefixThroughRecords($ctx,array $header): void {$keys=array_keys($header);$keys[]='records';sort($keys,SORT_STRING);hash_update($ctx,'{');$first=true;foreach($keys as $key){if($key==='records'){if(!$first)hash_update($ctx,',');hash_update($ctx,self::json('records'));hash_update($ctx,':{');return;}if(!$first)hash_update($ctx,',');hash_update($ctx,self::json((string)$key));hash_update($ctx,':');self::streamCanonicalValue($ctx,$header[$key]);$first=false;}throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_HASH_RECORDS_KEY_ORDER_INVALID');}
    /** Close records and feed all canonical top-level keys after "records". */
    private static function hashRegistrySuffixAfterRecords($ctx,array $header): void {$keys=array_keys($header);sort($keys,SORT_STRING);hash_update($ctx,'}');foreach($keys as $key){if(strcmp((string)$key,'records')<=0)continue;hash_update($ctx,',');hash_update($ctx,self::json((string)$key));hash_update($ctx,':');self::streamCanonicalValue($ctx,$header[$key]);}hash_update($ctx,'}');}

    /** @return array{option_id:int,bytes:int} */
    private static function sourceMetaCheap(): array {global $wpdb;self::$metrics['source_meta_reads']++;if(!isset($wpdb)||!isset($wpdb->options)||!method_exists($wpdb,'get_row')||!method_exists($wpdb,'prepare'))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_DB_STREAM_UNAVAILABLE');$sql=$wpdb->prepare("SELECT option_id, OCTET_LENGTH(option_value) AS bytes FROM {$wpdb->options} WHERE option_name=%s LIMIT 1",PSTE_OPTION_SEMANTIC_SANDBOX);$row=$wpdb->get_row($sql,ARRAY_A);if(!is_array($row))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_LEGACY_OPTION_MISSING');$bytes=(int)($row['bytes']??-1);$id=(int)($row['option_id']??0);if($id<=0||$bytes<=0)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_SOURCE_META_INVALID');return ['option_id'=>$id,'bytes'=>$bytes];}
    private static function assertSourceIdentityCheap(array $m): void {global $wpdb;if(!isset($wpdb)||!isset($wpdb->options)||!method_exists($wpdb,'get_row')||!method_exists($wpdb,'prepare'))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_DB_STREAM_UNAVAILABLE');$sql=$wpdb->prepare("SELECT option_id, OCTET_LENGTH(option_value) AS bytes FROM {$wpdb->options} WHERE option_name=%s LIMIT 1",PSTE_OPTION_SEMANTIC_SANDBOX);$row=$wpdb->get_row($sql,ARRAY_A);if(!is_array($row)||(int)($row['option_id']??0)!==(int)($m['source_option_id']??0)||(int)($row['bytes']??-1)!==(int)($m['source_bytes']??-2))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_SOURCE_IDENTITY_CHANGED');}

    /** @return array<string,mixed> */
    private static function requireComplete(): array {$m=self::manifest(true);if(!self::manifestCompleteAndConsistent($m))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_MIGRATION_INCOMPLETE');return $m;}
    private static function assertIds(array $m,array $ids): void {if((int)($m['record_count']??-1)!==count($ids)||!hash_equals((string)($m['record_ids_sha256']??''),self::stableHash($ids)))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_ID_SET_INVALID');}

    /** @return array<string,mixed> */
    private static function manifest(bool $verify=true): array {self::$metrics['manifest_reads']++;$m=get_option(PSTE_OPTION_SANDBOX_RECORD_MANIFEST,[]);if(!is_array($m))return [];if($verify&&$m){$decl=(string)($m['manifest_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$decl)||!hash_equals($decl,self::manifestHash($m)))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_MANIFEST_HASH_MISMATCH');}return $m;}
    private static function manifestUsable(array $m): bool {if(($m['contract']??'')!==self::MANIFEST_CONTRACT)return false;$status=(string)($m['status']??'');if(!in_array($status,[self::STATUS_SOURCE_HASH_BEFORE,self::STATUS_INIT_PARSE,self::STATUS_MIGRATING,self::STATUS_HASH_VERIFY,self::STATUS_SOURCE_HASH_AFTER,self::STATUS_COMPLETE],true))return false;$decl=(string)($m['manifest_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$decl)||!hash_equals($decl,self::manifestHash($m)))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_MANIFEST_HASH_MISMATCH');if($status===self::STATUS_COMPLETE)self::assertIds($m,array_values(array_map('strval',(array)($m['record_ids']??[]))));return true;}
    private static function manifestCompleteAndConsistent(array $m): bool {if(!self::manifestUsable($m)||($m['status']??'')!==self::STATUS_COMPLETE)return false;$n=count((array)$m['record_ids']);return (int)($m['migration_cursor']??-1)===$n&&(int)($m['hash_cursor']??-1)===$n&&(int)($m['migration_verified_record_count']??-1)===$n&&(int)($m['posthash_cursor']??-1)===(int)($m['source_bytes']??-2)&&preg_match('/^[a-f0-9]{64}$/',(string)($m['logical_registry_sha256']??''))===1&&preg_match('/^[a-f0-9]{64}$/',(string)($m['source_raw_sha256']??''))===1&&hash_equals((string)($m['source_raw_sha256']??''),(string)($m['source_post_sha256']??''));}
    private static function writeManifest(array $m): void {unset($m['manifest_sha256']);$m['manifest_sha256']=self::manifestHash($m);self::$metrics['manifest_writes']++;update_option(PSTE_OPTION_SANDBOX_RECORD_MANIFEST,$m,false);$read=get_option(PSTE_OPTION_SANDBOX_RECORD_MANIFEST,[]);if(!is_array($read)||!hash_equals((string)$m['manifest_sha256'],(string)($read['manifest_sha256']??''))||!hash_equals((string)$m['manifest_sha256'],self::manifestHash($read)))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_MANIFEST_WRITE_FAILED');}

    /** @return array<string,mixed> */
    private static function readRecordEnvelope(string $id,string $generation): array {if(!preg_match('/^[a-f0-9]{64}$/',$id))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_ID_INVALID');self::$metrics['record_reads']++;$env=get_option(PSTE_SANDBOX_RECORD_PREFIX.$id,[]);if(!is_array($env)||($env['contract']??'')!==self::RECORD_CONTRACT)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_RECORD_MISSING');if(!hash_equals($generation,(string)($env['generation']??'')))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_GENERATION_MISMATCH');$record=(array)($env['record']??[]);$decl=(string)($env['record_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$decl)||!hash_equals($decl,self::stableHash($record)))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_RECORD_HASH_MISMATCH');self::$metrics['record_verifies']++;return $env;}
    private static function writeRecordEnvelope(string $id,array $record,string $generation,string $expectedHash): void {if(!hash_equals($expectedHash,self::stableHash($record)))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_SOURCE_RECORD_HASH_MISMATCH');$key=PSTE_SANDBOX_RECORD_PREFIX.$id;$current=get_option($key,[]);if(is_array($current)&&($current['contract']??'')===self::RECORD_CONTRACT&&hash_equals($generation,(string)($current['generation']??''))){$curHash=(string)($current['record_sha256']??'');if(hash_equals($expectedHash,$curHash)){self::readRecordEnvelope($id,$generation);return;}$revision=max(1,(int)($current['revision']??0)+1);}else{$revision=1;}$env=['contract'=>self::RECORD_CONTRACT,'sandbox_id'=>$id,'generation'=>$generation,'revision'=>$revision,'record_sha256'=>$expectedHash,'record'=>$record];self::$metrics['record_writes']++;update_option($key,$env,false);$read=self::readRecordEnvelope($id,$generation);if((int)($read['revision']??0)!==$revision||!hash_equals($expectedHash,(string)($read['record_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_RECORD_READBACK_FAILED');}

    private static function manifestHash(array $m): string {$copy=$m;unset($copy['manifest_sha256']);return self::stableHash($copy);}
    private static function stableHash($value): string {return hash('sha256',self::json(self::canonicalize($value)));}
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
    private static function streamCanonicalValue($ctx,$value): void {if(!is_array($value)){hash_update($ctx,self::json($value));return;}if($value===[]){hash_update($ctx,'[]');return;}$keys=array_keys($value);$list=$keys===range(0,count($value)-1);if($list){hash_update($ctx,'[');$first=true;foreach($value as $v){if(!$first)hash_update($ctx,',');self::streamCanonicalValue($ctx,$v);$first=false;}hash_update($ctx,']');return;}usort($keys,static fn($a,$b)=>strcmp((string)$a,(string)$b));hash_update($ctx,'{');$first=true;foreach($keys as $k){if(!$first)hash_update($ctx,',');hash_update($ctx,self::json((string)$k));hash_update($ctx,':');self::streamCanonicalValue($ctx,$value[$k]);$first=false;}hash_update($ctx,'}');}
    private static function json($v): string {$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($j))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_JSON_FAILED');return $j;}
}

/** Binary, seekable, bounded parser for PHP serialize() data stored in one wp_options row. */
final class PSTE_Sandbox_Legacy_Option_Stream {
    private int $offset;private int $chunkBytes;private string $buffer='';private int $bufferStart=0;
    public function __construct(int $offset,int $chunkBytes){if($offset<0||$chunkBytes<4096)throw new RuntimeException('PSTE_SANDBOX_STREAM_ARGUMENT_INVALID');$this->offset=$offset;$this->chunkBytes=$chunkBytes;}
    public function offset(): int {return $this->offset;}
    public function readArrayHeader(): int {$this->expect('a:');$n=$this->readUnsignedUntil(':');$this->expect('{');return $n;}
    public function expectArrayClose(): void {$this->expect('}');}
    public function readValue(){
        $type=$this->read(1);
        if($type==='N'){$this->expect(';');return null;}
        if($type==='b'){$this->expect(':');$v=$this->readUntil(';');if($v!=='0'&&$v!=='1')throw new RuntimeException('PSTE_SANDBOX_STREAM_BOOL_INVALID');return $v==='1';}
        if($type==='i'){$this->expect(':');$v=$this->readUntil(';');if(!preg_match('/^-?[0-9]+$/',$v))throw new RuntimeException('PSTE_SANDBOX_STREAM_INT_INVALID');return (int)$v;}
        if($type==='d'){$this->expect(':');$v=$this->readUntil(';');if(!is_numeric($v)&&!in_array($v,['NAN','INF','-INF'],true))throw new RuntimeException('PSTE_SANDBOX_STREAM_FLOAT_INVALID');return (float)$v;}
        if($type==='s'){$this->expect(':');$len=$this->readUnsignedUntil(':');$this->expect('"');$v=$this->read($len);$this->expect('";');return $v;}
        if($type==='a'){$this->expect(':');$count=$this->readUnsignedUntil(':');$this->expect('{');$out=[];for($i=0;$i<$count;$i++){$k=$this->readValue();if(!is_int($k)&&!is_string($k))throw new RuntimeException('PSTE_SANDBOX_STREAM_ARRAY_KEY_INVALID');$out[$k]=$this->readValue();}$this->expect('}');return $out;}
        throw new RuntimeException('PSTE_SANDBOX_STREAM_UNSUPPORTED_TYPE_'.preg_replace('/[^A-Za-z0-9]/','_',bin2hex($type)));
    }
    private function readUnsignedUntil(string $delimiter): int {$v=$this->readUntil($delimiter);if($v===''||!ctype_digit($v))throw new RuntimeException('PSTE_SANDBOX_STREAM_LENGTH_INVALID');$n=(int)$v;if($n<0)throw new RuntimeException('PSTE_SANDBOX_STREAM_LENGTH_INVALID');return $n;}
    private function readUntil(string $delimiter): string {$out='';while(true){$c=$this->read(1);if($c===$delimiter)return $out;$out.=$c;if(strlen($out)>64)throw new RuntimeException('PSTE_SANDBOX_STREAM_TOKEN_TOO_LONG');}}
    private function expect(string $expected): void {$got=$this->read(strlen($expected));if($got!==$expected)throw new RuntimeException('PSTE_SANDBOX_STREAM_FORMAT_MISMATCH');}
    private function read(int $length): string {if($length<0)throw new RuntimeException('PSTE_SANDBOX_STREAM_READ_INVALID');if($length===0)return '';$out='';while(strlen($out)<$length){$this->ensure();$idx=$this->offset-$this->bufferStart;$available=strlen($this->buffer)-$idx;if($available<=0)throw new RuntimeException('PSTE_SANDBOX_STREAM_EOF');$take=min($length-strlen($out),$available);$out.=substr($this->buffer,$idx,$take);$this->offset+=$take;}return $out;}
    private function ensure(): void {if($this->buffer!==''&&$this->offset>=$this->bufferStart&&$this->offset<$this->bufferStart+strlen($this->buffer))return;global $wpdb;if(!isset($wpdb)||!isset($wpdb->options)||!method_exists($wpdb,'get_var')||!method_exists($wpdb,'prepare'))throw new RuntimeException('PSTE_SANDBOX_STREAM_DB_UNAVAILABLE');$sql=$wpdb->prepare("SELECT SUBSTRING(CAST(option_value AS BINARY), %d, %d) FROM {$wpdb->options} WHERE option_name=%s LIMIT 1",$this->offset+1,$this->chunkBytes,PSTE_OPTION_SEMANTIC_SANDBOX);$chunk=$wpdb->get_var($sql);if(!is_string($chunk)||$chunk==='')throw new RuntimeException('PSTE_SANDBOX_STREAM_EOF');$this->buffer=$chunk;$this->bufferStart=$this->offset;PSTE_Sandbox_Record_Store::noteSourceChunk(strlen($chunk));}
}

