<?php
if (!defined('ABSPATH')) { return; }

final class PSTE_Context_Refresh {
    private const LOCK='pste_context_refresh_lock_v1';
    private const CONTRACT='PSTE_CONTEXT_REFRESH_JOB_V8_DYNAMIC_CONTEXT_REBASE_ROOTFIX';
    private const LEGACY_CONTRACTS=[
        'PSTE_CONTEXT_REFRESH_JOB_V7_RECORD_LOCAL_SANDBOX_ROOTFIX',
        'PSTE_CONTEXT_REFRESH_JOB_V6_STAGED_SHARDED_ROOTFIX',
        'PSTE_CONTEXT_REFRESH_JOB_V5_BOUNDED_AUDIT_NO_REBUILD',
        'PSTE_CONTEXT_REFRESH_JOB_V5_SHARDED_INDEX',
        'PSTE_CONTEXT_REFRESH_JOB_V4_PREJOURNAL_TECHNICAL_RECOVERY',
        'PSTE_CONTEXT_REFRESH_JOB_V4_TRUE_REQUEST_BUDGET',
        'PSTE_CONTEXT_REFRESH_JOB_V3','PSTE_CONTEXT_REFRESH_JOB_V2','PSTE_CONTEXT_REFRESH_JOB_V1'
    ];
    private const SANDBOX_BATCH_SIZE=3;
    private const CONTEXT_BATCH_SIZE=5;
    private const PAYLOAD_BATCH_SIZE=10;
    private const LEASE_TTL=120;
    private static string $leaseToken='';
    private static int $leaseFence=0;
    private static int $leaseGeneration=0;

    /** Fresh baseline start is deliberately lightweight: no second full snapshot, no Sandbox full read. */
    public static function start(array $baseline,string $reason='MANUAL'): array {
        PSTE_Plugin::assertReady();self::assertBaseline($baseline);
        $jobUuid=function_exists('wp_generate_uuid4')?wp_generate_uuid4():hash('sha256',microtime(true).'|'.mt_rand());
        $leaseProbe=['job_uuid'=>$jobUuid,'generation'=>1];
        if(!self::acquireLease($leaseProbe))return self::status();
        try{
            $job=self::newJob($baseline,$jobUuid,$reason,PSTE_Repository::topicPoolCount());$job['generation']=self::$leaseGeneration;$job['lease_fence']=self::$leaseFence;
            self::saveJob($job);PSTE_Repository::markAllContextPending((string)$job['structure_sha256']);self::schedule();return $job;
        }finally{PSTE_Context_Diagnostics::finish();self::releaseLease();}
    }

    public static function status(): array {
        if(!PSTE_Plugin::isReady())return self::notReadyStatus();
        $job=get_option(PSTE_OPTION_CONTEXT_JOB,[]);$allowed=array_merge([self::CONTRACT],self::LEGACY_CONTRACTS);
        if(!is_array($job)||!in_array((string)($job['contract']??''),$allowed,true))return self::defaultStatus();
        return array_merge(self::defaultStatus(),$job);
    }

    public static function processCron(): void {if(PSTE_Plugin::isReady())self::processBatch();}

    public static function processBatch(?int $limit=null): array {
        if(!PSTE_Plugin::isReady())return self::notReadyStatus();
        $job=self::status();$contract=(string)($job['contract']??'');$legacy=in_array($contract,self::LEGACY_CONTRACTS,true);
        if(!$legacy&&$contract===self::CONTRACT&&in_array((string)($job['status']??''),['BLOCKED','COMPLETE'],true))return $job;
        // Retire only the obsolete transient lock; V7 concurrency uses an atomic option-backed fenced lease.
        if($legacy)delete_transient(self::LOCK);
        if(!self::acquireLease($job))return $job;
        $job['generation']=self::$leaseGeneration;$job['lease_fence']=self::$leaseFence;$phase='PREPARE';
        PSTE_Context_Diagnostics::begin((string)($job['job_uuid']??''),$phase);
        try{
            $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);self::assertBaseline(is_array($baseline)?$baseline:[]);

            // Critical root fix: legacy re-entry only adopts state. It never calls start(), Snapshot, Registry or Sandbox.
            if($legacy){
                $phase='LEGACY_STATE_ADOPTION';
                $job=self::adoptLegacyJob($job,$baseline);
                self::saveJob($job);if((string)($job['phase']??'')!=='LEGACY_V6_SANDBOX_RESUME')PSTE_Repository::markAllContextPending((string)$job['structure_sha256']);self::schedule();return $job;
            }
            if($contract!==self::CONTRACT)throw new RuntimeException('PSTE_CONTEXT_JOB_CONTRACT_UNSUPPORTED');

            // 1) Isolated lightweight storage baseline. No topic rows touched in this request.
            if(empty($job['payload_repair_init'])||!is_array($job['payload_repair_init'])){
                $phase='PAYLOAD_INTEGRITY_INIT';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);
                $init=PSTE_Repository::topicPayloadIntegrityInitialize((string)$job['job_uuid']);
                $expected=(int)($init['topic_count']??-1);if($expected<0)throw new RuntimeException('PSTE_PAYLOAD_INTEGRITY_INIT_COUNT_INVALID');
                if((int)($job['total']??$expected)!==$expected){$job['total']=$expected;$job['payload_repair_total']=$expected;}
                $job['payload_repair_init']=$init;$job['payload_repair_completed']=$expected===0;$job['payload_repair_status']=$expected===0?'NOT_REQUIRED':'PENDING';
                return self::persistAndContinue($job);
            }

            // 2) Maximum ten topic rows, no candidate-evidence reconstruction.
            if(empty($job['payload_repair_completed'])){
                $phase='PAYLOAD_INTEGRITY_AUDIT';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);
                $repair=PSTE_Repository::topicPayloadIntegrityBatch((int)($job['payload_repair_cursor']??0),self::PAYLOAD_BATCH_SIZE,(string)$job['job_uuid']);
                $job['payload_repair_cursor']=(int)($repair['cursor']??$job['payload_repair_cursor']??0);
                $job['payloads_repaired']=(int)($job['payloads_repaired']??0)+(int)($repair['repaired']??0);$job['payloads_quarantined']=(int)($job['payloads_quarantined']??0)+(int)($repair['quarantined']??0);$job['payloads_unchanged']=(int)($job['payloads_unchanged']??0)+(int)($repair['unchanged']??0);
                if(!empty($repair['complete'])){PSTE_Repository::topicPayloadIntegrityVerify((array)$job['payload_repair_init'],(int)$job['payload_repair_cursor']);$job['payload_repair_completed']=true;$job['payload_repair_status']='PASS';}else{$job['payload_repair_status']='RUNNING';}
                return self::persistAndContinue($job);
            }

            // 3-5) Global inputs are intentionally isolated into separate HTTP requests. Each is hash-bound and size-capped.
            if((string)($job['inventory_stage_status']??'PENDING')!=='PASS'){
                $phase='STAGE_INVENTORY_SNAPSHOT';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);$job['inventory_stage_meta']=PSTE_Context_Index_Store::stageInventory($baseline,(string)$job['job_uuid']);$job['inventory_stage_status']='PASS';return self::persistAndContinue($job);
            }
            if((string)($job['plan_stage_status']??'PENDING')!=='PASS'){
                $phase='STAGE_EDITORIAL_PLAN_SNAPSHOT';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);$job['plan_stage_meta']=PSTE_Context_Index_Store::stagePlan($baseline,(string)$job['job_uuid']);$job['plan_stage_status']='PASS';return self::persistAndContinue($job);
            }
            if((string)($job['registry_stage_status']??'PENDING')!=='PASS'){
                $phase='STAGE_ARTICLE_TYPE_REGISTRY';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);$job['registry_stage_meta']=PSTE_Context_Index_Store::stageRegistry($baseline,(string)$job['job_uuid']);$job['registry_stage_status']='PASS';return self::persistAndContinue($job);
            }

            // 6) Request-bounded legacy -> record-local Sandbox migration. The legacy option is streamed from DB;
            // no request loads/unserializes the complete registry and at most three records are touched per tick.
            if((string)($job['sandbox_record_store_status']??'PENDING')!=='PASS'){
                $phase='SANDBOX_RECORD_STORE_MIGRATION';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);PSTE_Sandbox_Record_Store::resetMetrics();$manifest=PSTE_Sandbox_Record_Store::advanceMigration(self::SANDBOX_BATCH_SIZE);$metrics=PSTE_Sandbox_Record_Store::metrics();
                if((int)($metrics['record_writes']??0)>self::SANDBOX_BATCH_SIZE||(int)($metrics['record_reads']??0)>self::SANDBOX_BATCH_SIZE||(int)($metrics['source_records_read']??0)>self::SANDBOX_BATCH_SIZE||(int)($metrics['canonical_hash_records']??0)>self::SANDBOX_BATCH_SIZE||(int)($metrics['legacy_full_reads']??0)!==0||(int)($metrics['source_bytes_read']??0)>8388608)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_MIGRATION_BUDGET_VIOLATION');
                $job['sandbox_record_store_count']=(int)($manifest['record_count']??0);$job['sandbox_record_store_source_sha256']=(string)($manifest['source_declared_registry_sha256']??$manifest['logical_registry_sha256']??'');$job['sandbox_record_store_metrics']=$metrics;$job['sandbox_record_store_migration_status']=(string)($manifest['status']??'');$job['sandbox_record_store_migration_cursor']=(int)($manifest['migration_cursor']??0);$job['sandbox_record_store_verification_cursor']=(int)($manifest['hash_cursor']??0);
                if(PSTE_Sandbox_Record_Store::isComplete()&&(string)($job['sandbox_ids_status']??'')==='PASS'&&(int)($job['sandbox_total']??0)>0&&(int)$job['sandbox_record_store_count']!==(int)$job['sandbox_total'])throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_COUNT_MISMATCH');
                $job['sandbox_record_store_status']=PSTE_Sandbox_Record_Store::isComplete()?'PASS':'RUNNING';return self::persistAndContinue($job);
            }

            // 7) IDs come from the verified record-local generation and are immutable/hash-bound for this job.
            if((string)($job['sandbox_ids_status']??'PENDING')!=='PASS'){
                $phase='STAGE_SANDBOX_RECORD_IDS';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);$ids=array_values(PSTE_Sandbox_Record_Store::recordIds());$job['sandbox_record_ids']=$ids;$job['sandbox_record_ids_sha256']=self::recordIdsSha256($ids);$job['sandbox_total']=count($ids);$job['sandbox_ids_status']='PASS';$job['sandbox_binding_status']=count($ids)>0?'PENDING':'COMPLETE';$job['sandbox_binding_outcome']=count($ids)>0?'PENDING':'PASS';return self::persistAndContinue($job);
            }
            self::assertRecordIdsIntegrity($job);
            if((int)($job['sandbox_record_store_count']??0)!==(int)($job['sandbox_total']??0))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_COUNT_MISMATCH');
            $jobIds=array_values(array_map('strval',(array)$job['sandbox_record_ids']));$storeIds=PSTE_Sandbox_Record_Store::recordIds();sort($jobIds,SORT_STRING);sort($storeIds,SORT_STRING);if($jobIds!==$storeIds)throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_ID_SET_MISMATCH');

            // 8) One capped materialization converts staged immutable data into small family shards.
            if((string)($job['context_index_status']??'PENDING')!=='PASS'){
                $phase='BUILD_FAMILY_SHARDED_CONTEXT_INDEX';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);$manifest=PSTE_Context_Index_Store::buildFromStages($baseline,$job);$job['context_index_manifest_sha256']=(string)($manifest['manifest_sha256']??'');$job['context_index_family_count']=(int)($manifest['family_count']??0);$job['context_index_shard_count']=(int)($manifest['shard_count']??0);$job['context_index_total_json_bytes']=(int)($manifest['total_json_bytes']??0);$job['context_index_status']='PASS';PSTE_Context_Index_Store::cleanupLegacyBundle();return self::persistAndContinue($job);
            }

            // 9) Context evaluation keeps the original evaluator byte-semantics; only the requested family shard is loaded.
            if((int)($job['processed']??0)<(int)($job['total']??0)){
                $phase='PORTAL_CONTEXT_BATCH';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);$batch=max(1,min(self::CONTEXT_BATCH_SIZE,$limit??self::CONTEXT_BATCH_SIZE));$rows=PSTE_Repository::contextBatchRows((int)($job['cursor_id']??0),$batch);$binding=PSTE_Context_Index_Store::runtimeBinding($job,$baseline);$inventory=(array)$binding['inventory_meta'];$plan=(array)$binding['editorial_plan_meta'];$index=['__pste_context_index_binding'=>$binding];$result=PSTE_Repository::refreshPortalContextBatch($rows,$inventory,$plan,$index,(string)$job['structure_sha256']);$processed=(int)($result['processed']??0);if($processed<0||$processed>count($rows))throw new RuntimeException('PSTE_CONTEXT_BATCH_PROCESSED_COUNT_INVALID');$job['cursor_id']=(int)($result['last_id']??($job['cursor_id']??0));$job['processed']=(int)($job['processed']??0)+$processed;return self::persistAndContinue($job);
            }

            // 10) Maximum three Sandbox records; no monolithic Sandbox read/write is allowed.
            if((string)($job['sandbox_binding_status']??'PENDING')!=='COMPLETE'){
                $phase='SANDBOX_BINDING_BATCH';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);self::assertRecordIdsIntegrity($job);$binding=PSTE_Context_Index_Store::runtimeBinding($job,$baseline);$inventory=['contract'=>'PSTE_INVENTORY_SNAPSHOT_V2','sha256'=>(string)($job['inventory_sha256']??''),'items'=>[]];$registry=PSTE_Context_Index_Store::registrySnapshot($binding);PSTE_Sandbox_Record_Store::resetMetrics();$sandbox=PSTE_Semantic_Review_Sandbox::refreshBindingsAfterBaselineChangeBatch(array_values((array)$job['sandbox_record_ids']),(int)($job['sandbox_cursor']??0),self::SANDBOX_BATCH_SIZE,$baseline,$inventory,$registry,(int)($job['sandbox_updated']??0),(int)($job['sandbox_source_stale']??0),(int)($job['sandbox_record_missing']??0),$binding);$metrics=(array)($sandbox['record_store_metrics']??[]);if((int)($metrics['record_reads']??0)>self::SANDBOX_BATCH_SIZE*3||(int)($metrics['record_writes']??0)>self::SANDBOX_BATCH_SIZE||(int)($metrics['legacy_full_reads']??0)>0)throw new RuntimeException('PSTE_SANDBOX_RECORD_LOCAL_BUDGET_VIOLATION');$job['sandbox_cursor']=(int)($sandbox['next_cursor']??$job['sandbox_cursor']??0);$job['sandbox_processed']=$job['sandbox_cursor'];$job['sandbox_updated']=(int)($sandbox['updated_total']??$job['sandbox_updated']??0);$job['sandbox_source_stale']=(int)($sandbox['source_stale_total']??$job['sandbox_source_stale']??0);$job['sandbox_record_missing']=(int)($sandbox['record_missing_total']??$job['sandbox_record_missing']??0);$job['sandbox_binding_status']=(string)($sandbox['status']??'RUNNING');$job['sandbox_binding_outcome']=(string)($sandbox['outcome']??'PENDING');return self::persistAndContinue($job);
            }

            // 11-13) Final live freshness is split across three isolated requests.
            // No request recomputes inventory + structure + plan together. No content/design write authority exists here.
            if((string)($job['final_structure_status']??'PENDING')!=='PASS'){
                $phase='FINAL_FRESH_STRUCTURE';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);$structure=PSTE_Snapshot::structure();
                if(empty($structure['validation']['ok']))return self::blockJob($job,(string)($structure['validation']['reason_code']??'PSTE_CONTEXT_FINAL_STRUCTURE_INVALID'),'Live portal taxonomy validation failed before completion.',(string)($structure['sha256']??''),'',true);
                $current=(string)($structure['sha256']??'');if($current===''||!hash_equals((string)$job['structure_sha256'],$current))return self::blockJob($job,'PSTE_CONTEXT_REFRESH_STALE_FINAL_STRUCTURE','Live portal structure changed before completion.',$current,'',true);
                $job['final_structure_status']='PASS';$job['final_structure_sha256']=$current;return self::persistAndContinue($job);
            }
            if((string)($job['final_inventory_status']??'PENDING')!=='PASS'){
                $phase='FINAL_FRESH_INVENTORY';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);$inventory=PSTE_Snapshot::inventory();$current=(string)($inventory['sha256']??'');
                if($current===''||!hash_equals((string)$job['inventory_sha256'],$current)){
                    $job=self::rebaseDynamicContextAndRestart($job,$baseline,'FINAL_INVENTORY_DRIFT');
                    PSTE_Repository::markAllContextPending((string)$job['structure_sha256']);
                    return self::persistAndContinue($job);
                }
                $job['final_inventory_status']='PASS';$job['final_inventory_sha256']=$current;return self::persistAndContinue($job);
            }
            if((string)($job['final_plan_status']??'PENDING')!=='PASS'){
                $phase='FINAL_FRESH_EDITORIAL_PLAN';$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);$plan=PSTE_Snapshot::editorialPlan();$current=(string)($plan['sha256']??'NOT_AVAILABLE');
                if(!hash_equals((string)$job['editorial_plan_sha256'],$current)){
                    $job=self::rebaseDynamicContextAndRestart($job,$baseline,'FINAL_EDITORIAL_PLAN_DRIFT');
                    PSTE_Repository::markAllContextPending((string)$job['structure_sha256']);
                    return self::persistAndContinue($job);
                }
                $job['final_plan_status']='PASS';$job['final_plan_sha256']=$current;return self::persistAndContinue($job);
            }
            $job['status']='COMPLETE';$job['phase']='COMPLETE';PSTE_Context_Diagnostics::phase('COMPLETE');$job['completed_at_utc']=gmdate('c');$job['updated_at_utc']=gmdate('c');$job['error_code']=null;$job['error_message']=null;$job['failed_topic_uuid']=null;self::saveJob($job);PSTE_Context_Index_Store::cleanupCompletedJobArtifacts();return $job;
        }catch(Throwable $e){
            $failed='';if(preg_match('/PSTE_CONTEXT_TOPIC_([0-9a-f-]{36}):/i',(string)$e->getMessage(),$m))$failed=(string)$m[1];$markContext=!in_array($phase,['LEGACY_STATE_ADOPTION','PAYLOAD_INTEGRITY_INIT','PAYLOAD_INTEGRITY_AUDIT','STAGE_INVENTORY_SNAPSHOT','STAGE_EDITORIAL_PLAN_SNAPSHOT','STAGE_ARTICLE_TYPE_REGISTRY','STAGE_SANDBOX_RECORD_IDS','SANDBOX_RECORD_STORE_MIGRATION','SANDBOX_BINDING_BATCH'],true);$job['phase']=$phase;PSTE_Context_Diagnostics::phase($phase);return self::blockJob($job,self::errorCode($e),self::errorMessage($e),'',$failed,$markContext);
        }finally{PSTE_Context_Diagnostics::finish();self::releaseLease();}
    }

    private static function adoptLegacyJob(array $legacy,array $baseline): array {
        $legacyContract=(string)($legacy['contract']??'');
        // V7 may reach the final freshness gate after a long, successful one-time Sandbox migration.
        // Inventory/plan drift is dynamic read-only context, not a reason to remigrate 549 Sandbox records.
        if($legacyContract==='PSTE_CONTEXT_REFRESH_JOB_V7_RECORD_LOCAL_SANDBOX_ROOTFIX'
            &&(string)($legacy['status']??'')==='BLOCKED'
            &&in_array((string)($legacy['error_code']??''),['PSTE_CONTEXT_REFRESH_STALE_FINAL_INVENTORY','PSTE_CONTEXT_REFRESH_STALE_FINAL_EDITORIAL_PLAN'],true)){
            if((int)($legacy['processed']??0)!==(int)($legacy['total']??0))throw new RuntimeException('PSTE_CONTEXT_V7_DYNAMIC_REBASE_CONTEXT_NOT_COMPLETE');
            if((string)($legacy['sandbox_record_store_status']??'')!=='PASS'||!PSTE_Sandbox_Record_Store::isComplete())throw new RuntimeException('PSTE_CONTEXT_V7_DYNAMIC_REBASE_RECORD_STORE_NOT_COMPLETE');
            if((string)($legacy['sandbox_binding_status']??'')!=='COMPLETE')throw new RuntimeException('PSTE_CONTEXT_V7_DYNAMIC_REBASE_SANDBOX_BINDING_NOT_COMPLETE');
            if((string)($legacy['final_structure_status']??'')!=='PASS')throw new RuntimeException('PSTE_CONTEXT_V7_DYNAMIC_REBASE_STRUCTURE_NOT_VERIFIED');
            $job=$legacy;$job['contract']=self::CONTRACT;$job['generation']=self::$leaseGeneration;$job['lease_fence']=self::$leaseFence;
            $job=self::rebaseDynamicContextAndRestart($job,$baseline,'LEGACY_V7_FINAL_DYNAMIC_CONTEXT_DRIFT');
            $job['legacy_contract']=$legacyContract;$job['legacy_status']=(string)($legacy['status']??'');$job['legacy_error_code']=(string)($legacy['error_code']??'');
            return $job;
        }
        // The failed 0.50 V6 job may be resumed in-place only at the proven Sandbox boundary.
        // All already-completed 562 topic/context work and immutable staged hashes remain bound to the same baseline.
        if($legacyContract==='PSTE_CONTEXT_REFRESH_JOB_V6_STAGED_SHARDED_ROOTFIX'&&in_array((string)($legacy['phase']??''),['SANDBOX_BINDING_BATCH','LEGACY_V6_SANDBOX_RESUME'],true)){
            $job=$legacy;$job['contract']=self::CONTRACT;$job['generation']=self::$leaseGeneration;$job['lease_fence']=self::$leaseFence;$job['status']='RUNNING';$job['phase']='LEGACY_V6_SANDBOX_RESUME';$job['legacy_contract']=$legacyContract;$job['legacy_status']=(string)($legacy['status']??'');$job['legacy_error_code']=(string)($legacy['error_code']??'');$job['error_code']=null;$job['error_message']=null;$job['failed_topic_uuid']=null;$job['updated_at_utc']=gmdate('c');
            // Re-run only the Sandbox technical binding from zero under V7. The already-complete 562 topic/context state is preserved.
            $job['sandbox_cursor']=0;$job['sandbox_processed']=0;$job['sandbox_updated']=0;$job['sandbox_source_stale']=0;$job['sandbox_record_missing']=0;$job['sandbox_binding_status']='PENDING';$job['sandbox_binding_outcome']='PENDING';$job['sandbox_record_store_status']='PENDING';$job['sandbox_record_store_migration_status']='NOT_STARTED';$job['sandbox_record_store_migration_cursor']=0;$job['sandbox_record_store_verification_cursor']=0;
            foreach(['inventory_sha256','structure_sha256','editorial_plan_sha256'] as $field){$want=(string)($baseline[$field]??($field==='editorial_plan_sha256'?'NOT_AVAILABLE':''));$have=(string)($job[$field]??'');if($have===''||$want===''||!hash_equals($have,$want))throw new RuntimeException('PSTE_CONTEXT_V6_RESUME_BASELINE_MISMATCH_'.$field);}
            if((int)($job['processed']??0)!==(int)($job['total']??0))throw new RuntimeException('PSTE_CONTEXT_V6_RESUME_CONTEXT_NOT_COMPLETE');
            if((string)($job['context_index_status']??'')!=='PASS'||(string)($job['registry_stage_status']??'')!=='PASS'||(string)($job['sandbox_ids_status']??'')!=='PASS')throw new RuntimeException('PSTE_CONTEXT_V6_RESUME_STAGE_NOT_COMPLETE');
            return $job;
        }
        $uuid=function_exists('wp_generate_uuid4')?wp_generate_uuid4():hash('sha256',microtime(true).'|'.mt_rand());$total=(int)($legacy['total']??0);if($total<=0)$total=PSTE_Repository::topicPoolCount();$job=self::newJob($baseline,$uuid,'LEGACY_CONTEXT_JOB_ADOPTED_TO_V7',$total);$job['legacy_contract']=$legacyContract;$job['legacy_status']=(string)($legacy['status']??'');$job['legacy_error_code']=(string)($legacy['error_code']??'');$job['phase']='LEGACY_STATE_ADOPTION_COMPLETE';return $job;
    }
    private static function rebaseDynamicContextAndRestart(array $job,array $baseline,string $reason): array {
        $count=max(0,(int)($job['dynamic_rebase_count']??0))+1;
        if($count>3)throw new RuntimeException('PSTE_CONTEXT_DYNAMIC_CONTEXT_DRIFT_REPEATED');
        $rebase=PSTE_Snapshot::rebaseResearchBaselineIfSafe($baseline);
        if(empty($rebase['ok'])||!is_array($rebase['baseline']??null)){
            $code=(string)($rebase['error_code']??'PSTE_CONTEXT_DYNAMIC_CONTEXT_REBASE_BLOCKED');
            throw new RuntimeException($code!==''?$code:'PSTE_CONTEXT_DYNAMIC_CONTEXT_REBASE_BLOCKED');
        }
        $fresh=(array)$rebase['baseline'];self::assertBaseline($fresh);
        $oldStructure=(string)($job['structure_sha256']??'');$newStructure=(string)($fresh['structure_sha256']??'');
        if($oldStructure===''||$newStructure===''||!hash_equals($oldStructure,$newStructure))throw new RuntimeException('PSTE_CONTEXT_DYNAMIC_REBASE_STRUCTURE_CHANGED');
        $job['inventory_sha256']=(string)($fresh['inventory_sha256']??'');$job['structure_sha256']=$newStructure;$job['editorial_plan_sha256']=(string)($fresh['editorial_plan_sha256']??'NOT_AVAILABLE');
        $job['cursor_id']=0;$job['processed']=0;
        $job['inventory_stage_status']='PENDING';$job['inventory_stage_meta']=[];$job['plan_stage_status']='PENDING';$job['plan_stage_meta']=[];$job['registry_stage_status']='PENDING';$job['registry_stage_meta']=[];
        $job['context_index_status']='PENDING';$job['context_index_manifest_sha256']='';$job['context_index_family_count']=0;$job['context_index_shard_count']=0;$job['context_index_total_json_bytes']=0;
        $job['final_structure_status']='PENDING';$job['final_structure_sha256']='';$job['final_inventory_status']='PENDING';$job['final_inventory_sha256']='';$job['final_plan_status']='PENDING';$job['final_plan_sha256']='';
        // The V7 record-local Sandbox store and completed component binding are preserved. Inventory-sensitive
        // internal planner proposals remain individually fail-closed through planner_inventory_observed_sha256.
        $job['dynamic_rebase_count']=$count;$job['last_dynamic_rebase_reason']=$reason;$job['last_dynamic_rebase_mode']=(string)($rebase['mode']??'SAFE_DYNAMIC_CONTEXT_REBASE');
        $job['status']='RUNNING';$job['phase']='DYNAMIC_CONTEXT_REBASE_COMPLETE';$job['error_code']=null;$job['error_message']=null;$job['failed_topic_uuid']=null;$job['updated_at_utc']=gmdate('c');$job['completed_at_utc']=null;
        return $job;
    }

    private static function newJob(array $baseline,string $jobUuid,string $reason,int $total): array {return [
        'contract'=>self::CONTRACT,'job_uuid'=>$jobUuid,'generation'=>1,'lease_fence'=>0,'status'=>'PENDING','reason'=>$reason,'phase'=>'PAYLOAD_INTEGRITY_INIT','cursor_id'=>0,'processed'=>0,'total'=>max(0,$total),'batch_size'=>self::CONTEXT_BATCH_SIZE,
        'inventory_sha256'=>(string)($baseline['inventory_sha256']??''),'structure_sha256'=>(string)($baseline['structure_sha256']??''),'editorial_plan_sha256'=>(string)($baseline['editorial_plan_sha256']??'NOT_AVAILABLE'),
        'payload_repair_completed'=>false,'payload_repair_status'=>'NOT_STARTED','payload_integrity_mode'=>'AUDIT_AND_FAIL_CLOSED_QUARANTINE_NO_CANDIDATE_REBUILD','payload_repair_cursor'=>0,'payload_repair_total'=>max(0,$total),'payload_repair_init'=>[],'payloads_repaired'=>0,'payloads_quarantined'=>0,'payloads_unchanged'=>0,
        'inventory_stage_status'=>'PENDING','inventory_stage_meta'=>[],'plan_stage_status'=>'PENDING','plan_stage_meta'=>[],'registry_stage_status'=>'PENDING','registry_stage_meta'=>[],'sandbox_ids_status'=>'PENDING','sandbox_record_store_status'=>'PENDING','sandbox_record_store_count'=>0,'sandbox_record_store_source_sha256'=>'','sandbox_record_store_metrics'=>[],'sandbox_record_store_migration_status'=>'NOT_STARTED','sandbox_record_store_migration_cursor'=>0,'sandbox_record_store_verification_cursor'=>0,
        'context_index_status'=>'PENDING','context_index_manifest_sha256'=>'','context_index_family_count'=>0,'context_index_shard_count'=>0,'context_index_total_json_bytes'=>0,
        'final_structure_status'=>'PENDING','final_structure_sha256'=>'','final_inventory_status'=>'PENDING','final_inventory_sha256'=>'','final_plan_status'=>'PENDING','final_plan_sha256'=>'',
        'sandbox_binding_status'=>'PENDING','sandbox_binding_outcome'=>'PENDING','sandbox_record_ids'=>[],'sandbox_record_ids_sha256'=>self::recordIdsSha256([]),'sandbox_cursor'=>0,'sandbox_processed'=>0,'sandbox_total'=>0,'sandbox_updated'=>0,'sandbox_source_stale'=>0,'sandbox_record_missing'=>0,
        'dynamic_rebase_count'=>0,'last_dynamic_rebase_reason'=>'','last_dynamic_rebase_mode'=>'',
        'started_at_utc'=>gmdate('c'),'updated_at_utc'=>gmdate('c'),'completed_at_utc'=>null,'error_code'=>null,'error_message'=>null,'failed_topic_uuid'=>null,
    ];}
    private static function persistAndContinue(array $job): array {$job['status']='RUNNING';$job['updated_at_utc']=gmdate('c');$job['completed_at_utc']=null;$job['error_code']=null;$job['error_message']=null;$job['failed_topic_uuid']=null;self::saveJob($job);self::schedule();return $job;}
    private static function blockJob(array $job,string $code,string $message,string $structureHash='',string $failedTopic='',bool $markContext=true): array {$job['status']='BLOCKED';$job['error_code']=$code;$job['error_message']=$message;$job['failed_topic_uuid']=$failedTopic!==''?$failedTopic:null;$job['updated_at_utc']=gmdate('c');self::saveJob($job);if($markContext){try{PSTE_Repository::markAllContextBlocked($code,$structureHash);}catch(Throwable $stateError){$job['error_message']=$message.' | CONTEXT_STATE_WRITE_FAILED: '.self::errorMessage($stateError);self::saveJob($job);}}return $job;}
    private static function saveJob(array $job): void {self::assertLeaseForJob($job);update_option(PSTE_OPTION_CONTEXT_JOB,$job,false);$stored=get_option(PSTE_OPTION_CONTEXT_JOB,[]);if(!is_array($stored))throw new RuntimeException('PSTE_CONTEXT_JOB_STATE_NOT_PERSISTED');foreach(['contract','job_uuid','generation','lease_fence','status','phase','payload_repair_cursor','payload_repair_completed','cursor_id','processed','total','inventory_stage_status','plan_stage_status','registry_stage_status','sandbox_ids_status','sandbox_record_store_status','sandbox_record_store_count','sandbox_record_store_migration_status','sandbox_record_store_migration_cursor','sandbox_record_store_verification_cursor','context_index_status','context_index_manifest_sha256','final_structure_status','final_structure_sha256','final_inventory_status','final_inventory_sha256','final_plan_status','final_plan_sha256','sandbox_cursor','sandbox_processed','sandbox_total','sandbox_binding_status','dynamic_rebase_count','last_dynamic_rebase_reason','last_dynamic_rebase_mode','error_code'] as $field)if(($stored[$field]??null)!==($job[$field]??null))throw new RuntimeException('PSTE_CONTEXT_JOB_STATE_NOT_PERSISTED_'.$field);}
    private static function acquireLease(array $job): bool {
        $jobUuid=(string)($job['job_uuid']??'');if($jobUuid==='')$jobUuid='PSTE_CONTEXT_NO_JOB';$generation=max(1,(int)($job['generation']??0));
        $token=hash('sha256',$jobUuid.'|'.$generation.'|'.microtime(true).'|'.(function_exists('wp_generate_uuid4')?wp_generate_uuid4():uniqid('',true)));
        $payload=['contract'=>'PSTE_CONTEXT_LEASE_V1','token'=>$token,'job_uuid'=>$jobUuid,'generation'=>$generation,'fence'=>0,'expires_at'=>time()+self::LEASE_TTL];
        $owned=add_option(PSTE_OPTION_CONTEXT_LEASE,$payload,'',false);
        if(!$owned){$old=get_option(PSTE_OPTION_CONTEXT_LEASE,[]);if(!is_array($old)||(int)($old['expires_at']??0)>=time())return false;if(get_option(PSTE_OPTION_CONTEXT_LEASE,[])===$old)delete_option(PSTE_OPTION_CONTEXT_LEASE);$owned=add_option(PSTE_OPTION_CONTEXT_LEASE,$payload,'',false);if(!$owned)return false;}
        $fence=max(0,(int)get_option(PSTE_OPTION_CONTEXT_FENCE,0))+1;update_option(PSTE_OPTION_CONTEXT_FENCE,$fence,false);$payload['fence']=$fence;update_option(PSTE_OPTION_CONTEXT_LEASE,$payload,false);$read=get_option(PSTE_OPTION_CONTEXT_LEASE,[]);
        if(!is_array($read)||!hash_equals($token,(string)($read['token']??''))||(int)($read['fence']??0)!==$fence)throw new RuntimeException('PSTE_CONTEXT_LEASE_ACQUIRE_READBACK_FAILED');
        self::$leaseToken=$token;self::$leaseFence=$fence;self::$leaseGeneration=$generation;return true;
    }
    private static function assertLeaseForJob(array $job): void {
        if(self::$leaseToken==='')return;$lease=get_option(PSTE_OPTION_CONTEXT_LEASE,[]);if(!is_array($lease)||!hash_equals(self::$leaseToken,(string)($lease['token']??''))||(int)($lease['fence']??0)!==self::$leaseFence||(int)($lease['generation']??0)!==self::$leaseGeneration||(int)($lease['expires_at']??0)<time())throw new RuntimeException('PSTE_CONTEXT_LEASE_LOST');
        if(!hash_equals((string)($lease['job_uuid']??''),(string)($job['job_uuid']??'')))throw new RuntimeException('PSTE_CONTEXT_LEASE_JOB_UUID_MISMATCH');
        if((int)($job['generation']??0)!==self::$leaseGeneration||(int)($job['lease_fence']??0)!==self::$leaseFence)throw new RuntimeException('PSTE_CONTEXT_LEASE_JOB_BINDING_MISMATCH');
    }
    private static function releaseLease(): void {
        if(self::$leaseToken!==''){$lease=get_option(PSTE_OPTION_CONTEXT_LEASE,[]);if(is_array($lease)&&hash_equals(self::$leaseToken,(string)($lease['token']??''))&&(int)($lease['fence']??0)===self::$leaseFence)delete_option(PSTE_OPTION_CONTEXT_LEASE);}
        self::$leaseToken='';self::$leaseFence=0;self::$leaseGeneration=0;
    }
    private static function assertBaseline(array $baseline): void {if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SITE_BASELINE_REQUIRED');}
    private static function recordIdsSha256(array $ids): string {$ids=array_values(array_map('strval',$ids));$json=wp_json_encode($ids,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($json))throw new RuntimeException('PSTE_CONTEXT_SANDBOX_RECORD_IDS_JSON_FAILED');return hash('sha256',$json);}
    private static function assertRecordIdsIntegrity(array $job): void {$ids=array_values((array)($job['sandbox_record_ids']??[]));$declared=(string)($job['sandbox_record_ids_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals($declared,self::recordIdsSha256($ids)))throw new RuntimeException('PSTE_CONTEXT_SANDBOX_RECORD_IDS_HASH_MISMATCH');if((int)($job['sandbox_total']??-1)!==count($ids))throw new RuntimeException('PSTE_CONTEXT_SANDBOX_RECORD_IDS_COUNT_MISMATCH');$cursor=(int)($job['sandbox_cursor']??0);if($cursor<0||$cursor>count($ids))throw new RuntimeException('PSTE_CONTEXT_SANDBOX_CURSOR_INVALID');}
    private static function errorCode(Throwable $e): string {$raw=strtoupper(trim((string)$e->getMessage()));$raw=(string)preg_replace('/[^A-Z0-9_:-]+/','_',$raw);return substr($raw!==''?$raw:'PSTE_CONTEXT_REFRESH_FAILED',0,160);}private static function errorMessage(Throwable $e): string {$raw=trim((string)$e->getMessage());$raw=(string)preg_replace('/[^A-Za-z0-9_:\- .]/','',$raw);return substr($raw!==''?$raw:'PSTE_CONTEXT_REFRESH_FAILED',0,240);}
    private static function defaultStatus(): array {return ['contract'=>self::CONTRACT,'status'=>'NOT_STARTED','phase'=>'NOT_STARTED','job_uuid'=>'','generation'=>0,'lease_fence'=>0,'processed'=>0,'total'=>PSTE_Repository::topicPoolCount(),'payload_repair_completed'=>false,'payload_repair_status'=>'NOT_STARTED','payload_repair_cursor'=>0,'payload_repair_total'=>0,'payload_repair_init'=>[],'payloads_repaired'=>0,'payloads_quarantined'=>0,'payloads_unchanged'=>0,'inventory_stage_status'=>'NOT_STARTED','inventory_stage_meta'=>[],'plan_stage_status'=>'NOT_STARTED','plan_stage_meta'=>[],'registry_stage_status'=>'NOT_STARTED','registry_stage_meta'=>[],'sandbox_ids_status'=>'NOT_STARTED','sandbox_record_store_status'=>'NOT_STARTED','sandbox_record_store_count'=>0,'sandbox_record_store_source_sha256'=>'','sandbox_record_store_metrics'=>[],'sandbox_record_store_migration_status'=>'NOT_STARTED','sandbox_record_store_migration_cursor'=>0,'sandbox_record_store_verification_cursor'=>0,'context_index_status'=>'NOT_STARTED','context_index_manifest_sha256'=>'','context_index_family_count'=>0,'context_index_shard_count'=>0,'context_index_total_json_bytes'=>0,'final_structure_status'=>'NOT_STARTED','final_structure_sha256'=>'','final_inventory_status'=>'NOT_STARTED','final_inventory_sha256'=>'','final_plan_status'=>'NOT_STARTED','final_plan_sha256'=>'','sandbox_binding_status'=>'NOT_INITIALIZED','sandbox_binding_outcome'=>'NOT_INITIALIZED','sandbox_record_ids'=>[],'sandbox_record_ids_sha256'=>self::recordIdsSha256([]),'sandbox_cursor'=>0,'sandbox_processed'=>0,'sandbox_total'=>0,'sandbox_updated'=>0,'sandbox_source_stale'=>0,'sandbox_record_missing'=>0,'dynamic_rebase_count'=>0,'last_dynamic_rebase_reason'=>'','last_dynamic_rebase_mode'=>'','error_code'=>null,'error_message'=>null,'failed_topic_uuid'=>null];}
    private static function notReadyStatus(): array {$x=self::defaultStatus();$x['total']=0;$x['error_code']='PSTE_SAFE_BOOT_NOT_READY';$x['error_message']='Der Portalabgleich bleibt bis zum sicheren Status READY gesperrt.';return $x;}
    private static function schedule(): void {if(PSTE_Plugin::isReady()&&function_exists('wp_next_scheduled')&&!wp_next_scheduled(PSTE_CONTEXT_CRON_HOOK))wp_schedule_single_event(time()+10,PSTE_CONTEXT_CRON_HOOK);}
}
