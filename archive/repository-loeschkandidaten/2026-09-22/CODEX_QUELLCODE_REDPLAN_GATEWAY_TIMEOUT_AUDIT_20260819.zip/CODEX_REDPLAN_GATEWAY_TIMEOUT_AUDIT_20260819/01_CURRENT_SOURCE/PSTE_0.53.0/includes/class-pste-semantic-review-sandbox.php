<?php
if (!defined('ABSPATH')) { return; }

/**
 * Persistent, isolated review quarantine for blocked but potentially valuable Longtails.
 * It preserves every current blocked candidate and requires a separate relevance decision before any
 * internal family/category/title review. Local portal/family signals stay diagnostic only. It never writes
 * topic source tables, posts, terms, postmeta, PPM/compiler/text-machine data.
 */
final class PSTE_Semantic_Review_Sandbox {
    public const CONTRACT='PSTE_SEMANTIC_REVIEW_SANDBOX_V1';
    public const JOB_CONTRACT='PSTE_SEMANTIC_REVIEW_SANDBOX_JOB_V1';
    public const REVIEW_POLICY='EVIDENCE_BEFORE_SHARED_NORMAL_PATH_REENTRY_V9_CANONICAL_DATAFLOW';
    private const LOCK_TTL=90;
    /** @var array<string,mixed>|null Request-local batch context for bounded migration admissions. */
    private static ?array $admissionBatchContext=null;
    /** Request-local verified registry cache; avoids repeated full-registry hashing/verification on one admin/AJAX request. */
    private static ?array $requestStoreCache=null;

    /** @return array<string,mixed> */
    public static function stored(): array {
        if(self::$admissionBatchContext!==null&&isset(self::$admissionBatchContext['store'])&&is_array(self::$admissionBatchContext['store']))return (array)self::$admissionBatchContext['store'];
        if(is_array(self::$requestStoreCache))return self::$requestStoreCache;
        $v=get_option(PSTE_OPTION_SEMANTIC_SANDBOX,[]);
        if($v===[]||$v===false||$v===null){self::$requestStoreCache=self::emptyRegistry();return self::$requestStoreCache;}
        if(!is_array($v))throw new RuntimeException('PSTE_SANDBOX_STORAGE_INVALID');self::assertRegistry($v);self::$requestStoreCache=$v;return self::$requestStoreCache;
    }

    /** Technical migration verifier; exposes no mutation authority. */
    public static function verifyRegistryForStorage(array $registry): void { self::assertRegistry($registry); }
    /** Technical migration integrity wrapper; never mutates record semantics. */
    public static function verifyRecordForStorage(array $record): void { self::assertRelevanceAdjudicationChain($record); if(array_key_exists('sandbox_dataflow',$record)) PSTE_Sandbox_Record_Contract::verifyStoredRecordSelfConsistency($record); }

    /**
     * Single admission router for the shared normal path. Candidate-local defects are retained in the Sandbox
     * and returned as isolated failures; storage/baseline/lock/integrity failures remain global fail-closed.
     * @return array<string,mixed>
     */
    public static function admitFromNormalPath(string $poolKey,array $normalPath,array $diagnostics=[]): array {
        $status=(string)($normalPath['status']??'');$mode=(string)($normalPath['sandbox_admission_mode']??'');
        if(!in_array($status,['SANDBOX_REQUIRED','STRUCTURE_GAP'],true))return ['ok'=>true,'admitted'=>false,'isolated_candidate_failure'=>false,'status'=>'NOT_REQUIRED'];
        try{
            if($status==='STRUCTURE_GAP'||($status==='SANDBOX_REQUIRED'&&$mode==='INTERNAL_CLARIFICATION')){
                $record=self::admitLiveInternalCandidate($poolKey,$normalPath,$diagnostics);$admissionMode='INTERNAL';
            }elseif($status==='SANDBOX_REQUIRED'){
                $record=self::admitLiveBlockedCandidate($poolKey,$diagnostics,$normalPath);$admissionMode='EXTERNAL';
            }else return ['ok'=>true,'admitted'=>false,'isolated_candidate_failure'=>false,'status'=>'NOT_REQUIRED'];
            return ['ok'=>true,'admitted'=>true,'isolated_candidate_failure'=>false,'status'=>(string)($record['status']??'REVIEW_REQUIRED'),'mode'=>$admissionMode,'record'=>$record];
        }catch(Throwable $e){
            if(!self::isCandidateScopedFailure($e))throw $e;
            $code=self::safeCode($e->getMessage());$record=self::retainAdmissionFailure($poolKey,$normalPath,$diagnostics,$code);
            return ['ok'=>false,'admitted'=>true,'isolated_candidate_failure'=>true,'status'=>'ADMISSION_REVIEW_REQUIRED','mode'=>$status==='STRUCTURE_GAP'||$mode==='INTERNAL_CLARIFICATION'?'INTERNAL':'EXTERNAL','error_code'=>$code,'record'=>$record];
        }
    }

    /**
     * Bounded, single-persistence admission batch used only by the durable safe-migration lifecycle.
     * The exact same per-candidate semantics are executed, but baseline/registry/inventory and the Sandbox
     * option are loaded once and the registry is persisted once. A durable receipt makes replay idempotent
     * when an HTTP response is lost after persistence but before the migration cursor advances.
     * @param array<int,array<string,mixed>> $items
     * @return array<string,mixed>
     */
    public static function admitFromNormalPathBatch(array $items,string $jobUuid): array {
        $jobUuid=trim($jobUuid);if($jobUuid==='')throw new RuntimeException('PSTE_SANDBOX_MIGRATION_JOB_UUID_REQUIRED');
        if(count($items)>25)throw new RuntimeException('PSTE_SANDBOX_MIGRATION_BATCH_TOO_LARGE');
        if(!$items)return ['contract'=>'PSTE_SANDBOX_MIGRATION_BATCH_V1','processed'=>0,'admitted'=>0,'candidate_failures'=>0,'receipts'=>[],'persisted'=>false];
        if(self::$admissionBatchContext!==null)throw new RuntimeException('PSTE_SANDBOX_MIGRATION_BATCH_NESTED');
        $token=self::acquireLock();
        try{
            $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_BASELINE_REQUIRED');
            $state=PSTE_Snapshot::baselineStatus($baseline);if(($state['status']??'')!=='CURRENT')throw new RuntimeException('PSTE_SANDBOX_BASELINE_MUST_BE_CURRENT');
            $articleRegistry=PSTE_Article_Type_Registry::build($baseline);$inventory=PSTE_Snapshot::inventory();$store=self::stored();
            self::$admissionBatchContext=['store'=>$store,'baseline'=>$baseline,'article_registry'=>$articleRegistry,'inventory'=>$inventory,'dirty'=>false];
            $results=[];$receipts=[];$admitted=0;$candidateFailures=0;
            foreach($items as $item){
                $poolKey=trim((string)($item['pool_key']??''));$normalPath=is_array($item['normal_path']??null)?(array)$item['normal_path']:[];$diagnostics=is_array($item['diagnostics']??null)?(array)$item['diagnostics']:[];
                if($poolKey===''||!$normalPath)throw new RuntimeException('PSTE_SANDBOX_MIGRATION_BATCH_ITEM_INVALID');
                $pathSha=self::hash($normalPath);$receipt=hash('sha256','PSTE_SAFE_MIGRATION_ADMISSION_V1|'.$jobUuid.'|'.$poolKey.'|'.$pathSha);
                $diagnostics['_migration_admission_receipt']=$receipt;
                $result=self::admitFromNormalPath($poolKey,$normalPath,$diagnostics);$results[]=$result;$receipts[]=$receipt;
                if(!empty($result['admitted']))$admitted++;if(!empty($result['isolated_candidate_failure']))$candidateFailures++;
            }
            $persisted=!empty(self::$admissionBatchContext['dirty']);
            if($persisted)self::persistRegistry((array)self::$admissionBatchContext['store']);
            return ['contract'=>'PSTE_SANDBOX_MIGRATION_BATCH_V1','processed'=>count($items),'admitted'=>$admitted,'candidate_failures'=>$candidateFailures,'receipts'=>$receipts,'results'=>$results,'persisted'=>$persisted];
        }finally{self::$admissionBatchContext=null;self::releaseLock($token);}
    }

    /**
     * Bounded, replay-safe batch admission for a completed research job. It uses the same normal-path
     * semantics as live admission but binds every admitted record to a deterministic research-finalize
     * receipt so retry after lock contention cannot duplicate review history or mutate source data twice.
     * @param array<int,array<string,mixed>> $items
     * @return array<string,mixed>
     */
    public static function admitFromResearchFinalizeBatch(array $items,string $jobUuid): array {
        $jobUuid=trim($jobUuid);if($jobUuid==='')throw new RuntimeException('PSTE_SANDBOX_RESEARCH_JOB_UUID_REQUIRED');
        if(count($items)>25)throw new RuntimeException('PSTE_SANDBOX_RESEARCH_BATCH_TOO_LARGE');
        if(!$items)return ['contract'=>'PSTE_SANDBOX_RESEARCH_ADMISSION_BATCH_V1','processed'=>0,'admitted'=>0,'candidate_failures'=>0,'results'=>[],'persisted'=>false];
        if(self::$admissionBatchContext!==null)throw new RuntimeException('PSTE_SANDBOX_RESEARCH_BATCH_NESTED');
        $token=self::acquireLock();
        try{
            $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_BASELINE_REQUIRED');
            $state=PSTE_Snapshot::baselineStatus($baseline);if(($state['status']??'')!=='CURRENT')throw new RuntimeException('PSTE_SANDBOX_BASELINE_MUST_BE_CURRENT');
            $articleRegistry=PSTE_Article_Type_Registry::build($baseline);$inventory=PSTE_Snapshot::inventory();$store=self::stored();
            self::$admissionBatchContext=['store'=>$store,'baseline'=>$baseline,'article_registry'=>$articleRegistry,'inventory'=>$inventory,'dirty'=>false];
            $results=[];$admitted=0;$candidateFailures=0;
            foreach($items as $item){
                $poolKey=trim((string)($item['pool_key']??''));$normalPath=is_array($item['normal_path']??null)?(array)$item['normal_path']:[];$diagnostics=is_array($item['diagnostics']??null)?(array)$item['diagnostics']:[];
                if($poolKey===''||!$normalPath)throw new RuntimeException('PSTE_SANDBOX_RESEARCH_BATCH_ITEM_INVALID');
                $pathSha=self::hash($normalPath);$receipt=hash('sha256','PSTE_RESEARCH_FINALIZE_ADMISSION_V1|'.$jobUuid.'|'.$poolKey.'|'.$pathSha);
                $diagnostics['_research_finalize_admission_receipt']=$receipt;
                $result=self::admitFromNormalPath($poolKey,$normalPath,$diagnostics);$results[]=$result;
                if(!empty($result['admitted']))$admitted++;if(!empty($result['isolated_candidate_failure']))$candidateFailures++;
            }
            $persisted=!empty(self::$admissionBatchContext['dirty']);
            if($persisted)self::persistRegistry((array)self::$admissionBatchContext['store']);
            return ['contract'=>'PSTE_SANDBOX_RESEARCH_ADMISSION_BATCH_V1','processed'=>count($items),'admitted'=>$admitted,'candidate_failures'=>$candidateFailures,'results'=>$results,'persisted'=>$persisted];
        }finally{self::$admissionBatchContext=null;self::releaseLock($token);}
    }

    /** @param array<int,string> $receipts @return array<string,mixed> */
    public static function verifyMigrationAdmissionReceipts(array $receipts): array {
        $wanted=array_values(array_unique(array_filter(array_map('strval',$receipts),'strlen')));$store=self::stored();$found=[];
        foreach((array)($store['records']??[]) as $record){if(!is_array($record))continue;$r=(string)($record['migration_admission_receipt']??'');if($r!=='')$found[$r]=true;}
        $missing=[];foreach($wanted as $receipt)if(empty($found[$receipt]))$missing[]=$receipt;
        if($missing)throw new RuntimeException('PSTE_SANDBOX_MIGRATION_RECEIPT_MISSING');
        return ['contract'=>'PSTE_SANDBOX_MIGRATION_RECEIPT_AUDIT_V1','expected'=>count($wanted),'found'=>count($wanted),'status'=>'PASS'];
    }

    /** Prove producer→persisted-record fidelity for every Sandbox record created by one migration job. @return array<string,mixed> */
    public static function verifyMigrationDataflow(array $receipts): array {
        $wanted=array_fill_keys(array_values(array_unique(array_filter(array_map('strval',$receipts),'strlen'))),true);
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_VERIFY_BASELINE_REQUIRED');
        $registry=PSTE_Article_Type_Registry::build($baseline);$store=self::stored();$verified=[];$componentHashes=[];
        foreach((array)($store['records']??[]) as $record){
            if(!is_array($record))continue;$receipt=(string)($record['migration_admission_receipt']??'');if($receipt===''||!isset($wanted[$receipt]))continue;
            $source=self::sourceSummary((string)($record['pool_key']??''));$payload=(array)($source['payload']??[]);$normalPath=(array)($payload['normal_metadata_path']??[]);if(!$normalPath)throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_VERIFY_NORMAL_PATH_MISSING');
            $result=PSTE_Sandbox_Record_Contract::verifyRecordAgainstNormalPath($record,$normalPath,$baseline,$registry);$verified[$receipt]=true;$componentHashes[]=(string)($result['dataflow_sha256']??'');
        }
        $missing=[];foreach(array_keys($wanted) as $receipt)if(empty($verified[$receipt]))$missing[]=$receipt;if($missing)throw new RuntimeException('PSTE_SANDBOX_DATAFLOW_VERIFY_RECEIPT_MISSING');
        sort($componentHashes,SORT_STRING);return ['contract'=>'PSTE_SANDBOX_MIGRATION_DATAFLOW_AUDIT_V1','status'=>'PASS','expected'=>count($wanted),'verified'=>count($verified),'dataflow_set_sha256'=>self::hash($componentHashes),'producer_to_persistence'=>'PASS','persistence_to_admin_consumer'=>'PASS','write_attempted'=>false,'production_handoff_attempted'=>false];
    }

    /**
     * Standard live admission for a newly blocked research/stored topic. Every raw keyword is already persisted
     * in PSTE's own topic pool before this call. Admission never performs an external request or production handoff.
     * @return array<string,mixed>
     */
    public static function admitLiveBlockedCandidate(string $poolKey,array $diagnostics=[],array $normalPath=[]): array {
        $poolKey=trim($poolKey);if($poolKey==='')throw new RuntimeException('PSTE_SANDBOX_LIVE_ADMISSION_POOL_KEY_REQUIRED');
        $token=self::acquireLock();
        try{
            $baseline=self::admissionBaseline();
            $state=PSTE_Snapshot::baselineStatus($baseline);if(($state['status']??'')!=='CURRENT')throw new RuntimeException('PSTE_SANDBOX_BASELINE_MUST_BE_CURRENT');
            $registry=self::admissionArticleRegistry($baseline);$source=self::sourceSummary($poolKey);$payload=(array)$source['payload'];
            $sourceQuery=PSTE_Editorializer::sourceQuery($payload);if($sourceQuery==='')throw new RuntimeException('PSTE_SANDBOX_LIVE_ADMISSION_QUERY_MISSING');
            if(!$normalPath){$preferred=(string)($payload['research_origin_family_key']??'');$normalPath=PSTE_Normal_Metadata_Path::evaluateRaw($sourceQuery,$baseline,$preferred,[],$payload);}
            $query=self::normalPathBoundQuery($normalPath,$payload,'PSTE_SANDBOX_LIVE_ADMISSION');
            $dataflow=PSTE_Sandbox_Record_Contract::fromNormalPath($query,$normalPath,$baseline,$registry);
            $querySha=hash('sha256',$query);$id=hash('sha256',$poolKey.'|'.$querySha);$store=self::stored();$old=is_array($store['records'][$id]??null)?(array)$store['records'][$id]:[];$receiptInfo=self::admissionReceiptFromDiagnostics($diagnostics);$receipt=(string)$receiptInfo['value'];$receiptField=(string)$receiptInfo['field'];if($receipt!==''&&hash_equals($receipt,(string)($old[$receiptField]??'')))return $old;$now=gmdate('c');
            $history=array_values((array)($old['history']??[]));$archive=array_values((array)($old['review_archive']??[]));
            $sameQuery=$old&&hash_equals((string)($old['query_sha256']??''),$querySha);$samePolicy=$old&&hash_equals((string)($old['review_policy_version']??''),self::REVIEW_POLICY);
            // External relevance evidence is bound to the unchanged raw query, not to the internal planning policy.
            // A policy/ruleset upgrade may invalidate only the internal proposal; it must not throw away paid or reviewed external evidence.
            $external=$sameQuery?($old['external_relevance']??null):null;$adjudication=$sameQuery?($old['relevance_adjudication']??null):null;
            $providerError=$sameQuery?($old['provider_error']??null):null;$providerHistory=$sameQuery?array_values((array)($old['provider_error_history']??[])):[];$retryCycles=$sameQuery?(int)($old['provider_error_retry_cycles']??0):0;
            if(!$old)$history[]=self::event('LIVE_ADMISSION_CREATED','PSTE_SANDBOX_LIVE_BLOCKED_KEYWORD_PRESERVED');
            elseif(!$sameQuery||!$samePolicy){$archive[]=self::archivedReview($old,!$samePolicy?'INTERNAL_REVIEW_POLICY_CHANGED_EXTERNAL_EVIDENCE_PRESERVED':'RAW_QUERY_CHANGED');$history[]=self::event('LIVE_ADMISSION_RESET',!$sameQuery?'PSTE_SANDBOX_RAW_QUERY_CHANGED_EXTERNAL_REVIEW_REQUIRED':'PSTE_SANDBOX_INTERNAL_POLICY_CHANGED_EXTERNAL_EVIDENCE_PRESERVED');}
            else $history[]=self::event('LIVE_ADMISSION_REFRESHED','PSTE_SANDBOX_SOURCE_BINDING_REFRESHED');
            $binding=['mode'=>'LIVE_TOPIC_POOL_V1','registry_sha256'=>(string)$registry['registry_sha256'],'family_identity_v2_registry_sha256'=>self::familyIdentityRegistrySha256($registry),'stable_baseline_identity_sha256'=>self::stableBaselineIdentitySha256($baseline),'source_identity_sha256'=>(string)$source['source_identity_sha256']];
            $record=[
                'sandbox_id'=>$id,'query'=>$query,'query_sha256'=>$querySha,'pool_id'=>(int)($old['pool_id']??0),'pool_key'=>$poolKey,'candidate_id'=>(string)($payload['candidate_id']??$old['candidate_id']??''),
                'original_classification'=>'LIVE_RESEARCH_BLOCKED','original_reason_codes'=>array_values(array_unique(array_map('strval',(array)($diagnostics['reason_codes']??$payload['reason_codes']??[])))),
                'old_family_key'=>(string)($diagnostics['research_origin_family_key']??$payload['research_origin_family_key']??$payload['topic_family_key']??''),'old_family_name'=>(string)($diagnostics['research_origin_family_name']??$payload['research_origin_family_name']??$payload['topic_family_name']??''),'article_type'=>(string)($payload['source_proposed_article_type']??$payload['proposed_article_type']??''),
                'nearest_rejected_families'=>[],'nearest_failure_reason_codes'=>[],
                'review_policy_version'=>self::REVIEW_POLICY,'workflow_lane'=>'EXTERNAL_RELEVANCE_REVIEW','requires_external_review'=>true,'admitted_to_external_review'=>true,
                'admission_reason_codes'=>['PSTE_SANDBOX_LIVE_BLOCKED_REQUIRES_EXTERNAL_RELEVANCE'],'status'=>'PENDING_EXTERNAL_RELEVANCE','portal_relevance'=>[],'exclusion_evidence'=>[],
                'search_volume'=>$source['search_volume'],'source_names'=>$source['source_names'],'source'=>$source,'binding'=>$binding,
                'external_relevance'=>$external,'relevance_adjudication'=>$adjudication,'internal_proposal'=>null,'internal_proposal_sha256'=>'','internal_adjudication'=>null,
                'provider_error'=>$providerError,'provider_error_history'=>$providerHistory,'provider_error_retry_cycles'=>$retryCycles,'review_archive'=>$archive,'history'=>$history,
                'first_seen_at_utc'=>(string)($old['first_seen_at_utc']??$now),'updated_at_utc'=>$now,'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,'production_handoff_attempted'=>false,
            ];
            $record=PSTE_Sandbox_Record_Contract::applyToRecord($record,$dataflow,$normalPath);
            if($receipt!=='')$record[$receiptField]=$receipt;
            // Preserve independent external evidence for the identical raw query, but always rebuild internal semantics against current structure.
            $effectiveStatus=(string)($adjudication['decision']??(is_array($external)?($external['status']??'') : ''));
            if($effectiveStatus==='RELEVANT_FOR_PORTAL'){
                $effective=is_array($external)?$external:[];$effective['status']='RELEVANT_FOR_PORTAL';
                $transition=self::postRelevanceDecision($record,$effective,$registry,$baseline,$payload,self::admissionInventory());
                $record['internal_proposal']=$transition['internal_proposal'];$record['internal_proposal_sha256']=is_array($transition['internal_proposal'])?self::hash($transition['internal_proposal']):'';$record['status']=(string)$transition['status'];$record['workflow_lane']=self::workflowLaneForStatus($record['status']);$record['requires_external_review']=false;
            }elseif($effectiveStatus==='NOT_RELEVANT_FOR_PORTAL'){$record['status']='RETAINED_NOT_RELEVANT';$record['workflow_lane']='RETAINED_NOT_RELEVANT';$record['requires_external_review']=false;}
            elseif($effectiveStatus==='UNCERTAIN_REVIEW'){$record['status']='UNCERTAIN_REVIEW';$record['workflow_lane']='EXTERNAL_RELEVANCE_REVIEW';$record['requires_external_review']=false;}
            $store['records'][$id]=$record;$store['last_live_admission_at_utc']=$now;self::save($store);return $record;
        }finally{self::releaseLock($token);}
    }

    /**
     * Provider-free live admission after the normal path has already proven current portal-family relevance.
     * Used for editorial clarification and true category structure gaps. It never calls an external provider,
     * creates taxonomy, or creates production metadata.
     * @return array<string,mixed>
     */
    public static function admitLiveInternalCandidate(string $poolKey,array $normalPath,array $diagnostics=[]): array {
        $poolKey=trim($poolKey);if($poolKey==='')throw new RuntimeException('PSTE_SANDBOX_INTERNAL_ADMISSION_POOL_KEY_REQUIRED');
        $status=(string)($normalPath['status']??'');
        if(!in_array($status,['SANDBOX_REQUIRED','STRUCTURE_GAP'],true))throw new RuntimeException('PSTE_SANDBOX_INTERNAL_ADMISSION_STATUS_INVALID');
        if((string)($normalPath['portal_relevance']??'')!=='PROVEN'||empty($normalPath['portal_relevance_gate']['ok']))throw new RuntimeException('PSTE_SANDBOX_INTERNAL_ADMISSION_RELEVANCE_NOT_PROVEN');
        if($status==='SANDBOX_REQUIRED'&&(string)($normalPath['sandbox_admission_mode']??'')!=='INTERNAL_CLARIFICATION')throw new RuntimeException('PSTE_SANDBOX_INTERNAL_ADMISSION_MODE_INVALID');
        $token=self::acquireLock();
        try{
            $baseline=self::admissionBaseline();
            $state=PSTE_Snapshot::baselineStatus($baseline);if(($state['status']??'')!=='CURRENT')throw new RuntimeException('PSTE_SANDBOX_BASELINE_MUST_BE_CURRENT');
            $registry=self::admissionArticleRegistry($baseline);$source=self::sourceSummary($poolKey);$payload=(array)$source['payload'];
            $query=self::normalPathBoundQuery($normalPath,$payload,'PSTE_SANDBOX_INTERNAL_ADMISSION');
            $dataflow=PSTE_Sandbox_Record_Contract::fromNormalPath($query,$normalPath,$baseline,$registry);
            $querySha=hash('sha256',$query);
            $id=hash('sha256',$poolKey.'|'.$querySha);$store=self::stored();$old=is_array($store['records'][$id]??null)?(array)$store['records'][$id]:[];$receiptInfo=self::admissionReceiptFromDiagnostics($diagnostics);$receipt=(string)$receiptInfo['value'];$receiptField=(string)$receiptInfo['field'];if($receipt!==''&&hash_equals($receipt,(string)($old[$receiptField]??'')))return $old;$now=gmdate('c');
            $sameQuery=$old&&hash_equals((string)($old['query_sha256']??''),$querySha);
            $history=array_values((array)($old['history']??[]));$history[]=self::event('LIVE_INTERNAL_ADMISSION',$status==='STRUCTURE_GAP'?'PSTE_SANDBOX_CURRENT_STRUCTURE_GAP_RETAINED':'PSTE_SANDBOX_EDITORIAL_CLARIFICATION_RETAINED');
            // Current relevance proof and historical external/human evidence have different roles.
            // Never overwrite provider/review evidence for the same immutable raw query merely because the
            // current normal path can now prove portal relevance locally.
            $currentProof=['contract'=>'PSTE_SANDBOX_INTERNAL_PORTAL_RELEVANCE_PROOF_V2','status'=>'RELEVANT_FOR_PORTAL','source'=>'CURRENT_NORMAL_PATH_RELEVANCE_GATE','provider_calls'=>0,'query_sha256'=>$querySha,'family_key'=>(string)($normalPath['family_key']??''),'family_name'=>(string)($normalPath['family_name']??''),'normal_path_contract'=>(string)($normalPath['contract']??''),'ruleset'=>(string)($normalPath['ruleset']??PSTE_Editorializer::RULESET),'write_attempted'=>false];
            $external=$sameQuery&&is_array($old['external_relevance']??null)?(array)$old['external_relevance']:null;
            $adjudication=$sameQuery&&is_array($old['relevance_adjudication']??null)?(array)$old['relevance_adjudication']:null;
            $binding=['mode'=>'LIVE_TOPIC_POOL_V1','registry_sha256'=>(string)$registry['registry_sha256'],'family_identity_v2_registry_sha256'=>self::familyIdentityRegistrySha256($registry),'stable_baseline_identity_sha256'=>self::stableBaselineIdentitySha256($baseline),'source_identity_sha256'=>(string)$source['source_identity_sha256']];
            $oldFamilyKey=self::firstNonEmpty([(string)($normalPath['family_key']??''),(string)($diagnostics['research_origin_family_key']??''),(string)($payload['source_topic_family_key']??''),(string)($payload['research_origin_family_key']??''),(string)($old['old_family_key']??'')]);
            $oldFamilyName=self::firstNonEmpty([(string)($normalPath['family_name']??''),(string)($diagnostics['research_origin_family_name']??''),(string)($payload['source_topic_family_name']??''),(string)($payload['research_origin_family_name']??''),(string)($old['old_family_name']??'')]);
            $record=[
                'sandbox_id'=>$id,'query'=>$query,'query_sha256'=>$querySha,'pool_id'=>(int)($old['pool_id']??0),'pool_key'=>$poolKey,'candidate_id'=>(string)($payload['candidate_id']??$old['candidate_id']??''),
                'original_classification'=>$status==='STRUCTURE_GAP'?'LIVE_STRUCTURE_GAP':'LIVE_EDITORIAL_CLARIFICATION','original_reason_codes'=>array_values(array_unique(array_map('strval',(array)($diagnostics['reason_codes']??$normalPath['reason_codes']??[])))),
                'old_family_key'=>$oldFamilyKey,'old_family_name'=>$oldFamilyName,'article_type'=>(string)($normalPath['article_type']??''),
                'nearest_rejected_families'=>[],'nearest_failure_reason_codes'=>[],
                'review_policy_version'=>self::REVIEW_POLICY,'workflow_lane'=>$status==='STRUCTURE_GAP'?'STRUCTURE_GAP':'MATCHER_REVIEW','requires_external_review'=>false,'admitted_to_external_review'=>false,
                'admission_reason_codes'=>[$status==='STRUCTURE_GAP'?'PSTE_SANDBOX_STRUCTURE_GAP_INTERNAL_ADMISSION':'PSTE_SANDBOX_INTERNAL_CLARIFICATION_ADMISSION'],'status'=>$status==='STRUCTURE_GAP'?'STRUCTURE_GAP':'REVIEW_REQUIRED',
                'portal_relevance'=>[],'exclusion_evidence'=>[],
                'search_volume'=>$source['search_volume'],'source_names'=>$source['source_names'],'source'=>$source,'binding'=>$binding,
                'external_relevance'=>$external,'relevance_adjudication'=>$adjudication,'current_relevance_proof'=>$currentProof,'internal_proposal'=>null,'internal_proposal_sha256'=>'','internal_adjudication'=>null,
                'provider_error'=>$old['provider_error']??null,'provider_error_history'=>array_values((array)($old['provider_error_history']??[])),'provider_error_retry_cycles'=>(int)($old['provider_error_retry_cycles']??0),
                'review_archive'=>array_values((array)($old['review_archive']??[])),'history'=>$history,
                'normal_path_admission'=>$normalPath,'periodic_internal_recheck_required'=>true,
                'first_seen_at_utc'=>(string)($old['first_seen_at_utc']??$now),'updated_at_utc'=>$now,'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,'production_handoff_attempted'=>false,
            ];
            $record=PSTE_Sandbox_Record_Contract::applyToRecord($record,$dataflow,$normalPath);
            if($receipt!=='')$record[$receiptField]=$receipt;
            $priorDecision=(string)($adjudication['decision']??'');$priorExternal=(string)($external['status']??'');
            if($priorDecision==='NOT_RELEVANT_FOR_PORTAL'){
                $record['status']='RETAINED_NOT_RELEVANT';$record['workflow_lane']='RETAINED_NOT_RELEVANT';$record['requires_external_review']=false;
                $record['relevance_conflict']=['status'=>'CURRENT_LOCAL_PROOF_CONFLICTS_WITH_EXPLICIT_NOT_RELEVANT','requires_review'=>false,'explicit_decision_preserved'=>true];
                $record['history'][]=self::event('CURRENT_RELEVANCE_PROOF_RECORDED_EXPLICIT_NOT_RELEVANT_PRESERVED','PSTE_SANDBOX_EXPLICIT_RELEVANCE_ADJUDICATION_IS_IMMUTABLE_EVIDENCE');
            }elseif($priorDecision===''&&$priorExternal==='NOT_RELEVANT_FOR_PORTAL'){
                $record['status']='RELEVANCE_CONFLICT_REVIEW_REQUIRED';$record['workflow_lane']='RELEVANCE_CONFLICT_REVIEW_REQUIRED';$record['requires_external_review']=false;
                $record['relevance_conflict']=['status'=>'CURRENT_LOCAL_PROOF_CONFLICTS_WITH_HISTORICAL_EXTERNAL_NOT_RELEVANT','requires_review'=>true,'external_evidence_preserved'=>true];
                $record['history'][]=self::event('RELEVANCE_EVIDENCE_CONFLICT_RETAINED','PSTE_SANDBOX_CURRENT_LOCAL_VS_HISTORICAL_EXTERNAL_CONFLICT');
            }else{
                $transition=self::postRelevanceDecision($record,$currentProof,$registry,$baseline,$payload,self::admissionInventory());
                $record['internal_proposal']=$transition['internal_proposal'];$record['internal_proposal_sha256']=is_array($transition['internal_proposal'])?self::hash($transition['internal_proposal']):'';
                $record['status']=(string)$transition['status'];$record['workflow_lane']=self::workflowLaneForStatus($record['status']);$record['requires_external_review']=false;
            }
            // A main-path structure gap remains a structure-gap backlog item even if the older Sandbox planner
            // is more conservative; the actual reentry still reruns the shared current normal path.
            if($status==='STRUCTURE_GAP'&&!in_array($record['status'],['STRUCTURE_GAP','SOURCE_STALE_REVIEW_REQUIRED','RETAINED_NOT_RELEVANT','RELEVANCE_CONFLICT_REVIEW_REQUIRED'],true)){$record['status']='STRUCTURE_GAP';$record['workflow_lane']='STRUCTURE_GAP';$record['internal_proposal']=$normalPath['category_gap_proposal']??$record['internal_proposal'];$record['internal_proposal_sha256']=is_array($record['internal_proposal'])?self::hash($record['internal_proposal']):'';}
            $store['records'][$id]=$record;$store['last_live_admission_at_utc']=$now;self::save($store);return $record;
        }finally{self::releaseLock($token);}
    }

    /**
     * Snapshot the exact Sandbox record identities that existed when an explicit portal-baseline refresh started.
     * This is read-only and intentionally does not perform any semantic/relevance work. The IDs are consumed by
     * the already existing portal-context job in bounded requests, so no article/workflow semantics are changed.
     * @return list<string>
     */
    public static function bindingRefreshRecordIds(): array {
        if(class_exists('PSTE_Sandbox_Record_Store'))return PSTE_Sandbox_Record_Store::sourceRecordIds();
        $store=self::stored();$ids=[];foreach((array)($store['records']??[]) as $id=>$record)if(is_array($record))$ids[]=(string)$id;sort($ids,SORT_STRING);return $ids;
    }

    /**
     * Request-bounded equivalent of refreshBindingsAfterBaselineChange(). It executes the same provider-free
     * rebinding logic for only the requested slice of the baseline-capture record set. The caller must already
     * have verified that the supplied baseline/inventory snapshots are current for the durable context job.
     * @param list<string> $recordIds
     * @return array<string,mixed>
     */
    public static function refreshBindingsAfterBaselineChangeBatch(array $recordIds,int $offset,int $limit,array $baseline,array $inventory,array $registry,int $updatedBefore=0,int $staleBefore=0,int $missingBefore=0,array $runtimeBinding=[]): array {
        if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_BASELINE_REQUIRED');
        if(empty($registry['registry_sha256']))throw new RuntimeException('PSTE_SANDBOX_REGISTRY_INVALID');
        if(!class_exists('PSTE_Sandbox_Record_Store'))throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_REQUIRED');
        if(!PSTE_Sandbox_Record_Store::isComplete())throw new RuntimeException('PSTE_SANDBOX_RECORD_STORE_MIGRATION_INCOMPLETE');
        $offset=max(0,$offset);$limit=max(1,min(25,$limit));$total=count($recordIds);$slice=array_slice($recordIds,$offset,$limit);
        $token=self::acquireLock();
        try{
            $updated=0;$stale=0;$missing=0;$writes=[];
            $registrySha=(string)$registry['registry_sha256'];$familyRegistrySha=self::familyIdentityRegistrySha256($registry);
            $structureSha=(string)($baseline['structure_sha256']??$baseline['structure_hash']??'');$protectedSha=(string)($baseline['protected_category_map_sha256']??'');
            $journalRegistrationSha=(string)($registry['journal_registration_sha256']??'');
            foreach($slice as $id){
                $id=(string)$id;
                try{$record=PSTE_Sandbox_Record_Store::getRecord($id);}catch(Throwable $e){if(str_starts_with(self::safeCode($e->getMessage()),'PSTE_SANDBOX_RECORD_STORE_RECORD_MISSING')){$missing++;continue;}throw $e;}
                $poolKey=(string)($record['pool_key']??'');if($poolKey===''){$missing++;continue;}
                try{$source=self::sourceSummary($poolKey);}catch(Throwable $e){if(!self::isCandidateScopedFailure($e))throw $e;$record['binding_dependency_review_required']=true;$record['binding_dependency_error_code']=self::safeCode($e->getMessage());$writes[$id]=$record;$stale++;continue;}
                $query=(string)($record['query']??'');$currentSourceQuery=PSTE_Editorializer::sourceQuery((array)$source['payload']);$currentQuery=PSTE_Normal_Metadata_Path::canonicalInputQuery($currentSourceQuery);
                if($query===''||$currentQuery===''||!hash_equals(hash('sha256',$query),hash('sha256',$currentQuery))){$record['binding_dependency_review_required']=true;$record['binding_dependency_error_code']='PSTE_SANDBOX_RAW_QUERY_CHANGED';$writes[$id]=$record;$stale++;continue;}
                $old=(array)($record['binding']??[]);$oldReg=(string)($old['registry_sha256']??'');$oldFamily=(string)($old['family_identity_v2_registry_sha256']??'');$oldSource=(string)($old['source_identity_sha256']??$record['source']['source_identity_sha256']??'');
                // Migration from the old global baseline binding is deliberately non-semantic: existing evidence,
                // status, history, title/category/type decisions and internal proposals are preserved byte-for-byte.
                $legacyCompatible=($oldReg===''||hash_equals($oldReg,$registrySha))&&($oldFamily===''||hash_equals($oldFamily,$familyRegistrySha))&&($oldSource===''||hash_equals($oldSource,(string)$source['source_identity_sha256']));
                $depCurrent=(string)($old['dependency_contract']??'')==='PSTE_SANDBOX_BINDING_DEPENDENCIES_V1'
                    &&hash_equals((string)($old['registry_sha256']??''),$registrySha)
                    &&hash_equals((string)($old['family_identity_v2_registry_sha256']??''),$familyRegistrySha)
                    &&hash_equals((string)($old['source_identity_sha256']??''),(string)$source['source_identity_sha256'])
                    &&hash_equals((string)($old['structure_sha256']??''),$structureSha)
                    &&hash_equals((string)($old['protected_category_map_sha256']??''),$protectedSha);
                $appliesJournal=PSTE_Article_Type_Registry::canonicalType(self::firstNonEmpty([(string)($record['article_type']??''),(string)($record['internal_proposal']['article_type']??''),(string)($source['payload']['proposed_article_type']??'')]))==='journal';
                if($depCurrent&&(!$appliesJournal||hash_equals((string)($old['journal_registration_sha256']??''),$journalRegistrationSha)))continue;
                if(!$legacyCompatible){$record['binding_dependency_review_required']=true;$record['binding_dependency_error_code']='PSTE_SANDBOX_BINDING_COMPONENT_CHANGED';$writes[$id]=$record;$stale++;continue;}
                $new=$old;
                $new['dependency_contract']='PSTE_SANDBOX_BINDING_DEPENDENCIES_V1';$new['registry_sha256']=$registrySha;$new['family_identity_v2_registry_sha256']=$familyRegistrySha;$new['source_identity_sha256']=(string)$source['source_identity_sha256'];$new['structure_sha256']=$structureSha;$new['protected_category_map_sha256']=$protectedSha;$new['journal_registration_sha256']=$appliesJournal?$journalRegistrationSha:'';
                // Keep the historical global baseline hash for audit only; it is no longer an invalidation key.
                if(isset($old['stable_baseline_identity_sha256']))$new['legacy_stable_baseline_identity_sha256']=(string)$old['stable_baseline_identity_sha256'];unset($new['stable_baseline_identity_sha256']);
                $effective=self::effectiveRelevanceStatus($record);
                if($effective==='RELEVANT_FOR_PORTAL'&&is_array($record['internal_proposal']??null)){$new['planner_inventory_recheck_required']=true;$new['planner_inventory_observed_sha256']=(string)($baseline['inventory_sha256']??'');}
                $record['binding']=$new;unset($record['binding_dependency_error_code']);$record['binding_dependency_review_required']=false;$writes[$id]=$record;$updated++;
            }
            if($writes)PSTE_Sandbox_Record_Store::putRecordsBatch($writes);
            $next=min($total,$offset+count($slice));$complete=$next>=$total;$cumUpdated=max(0,$updatedBefore)+$updated;$cumStale=max(0,$staleBefore)+$stale;$cumMissing=max(0,$missingBefore)+$missing;
            if($complete)PSTE_Sandbox_Record_Store::updateRefreshSummary(['updated'=>$cumUpdated,'source_stale'=>$cumStale,'missing'=>$cumMissing]);
            return ['contract'=>'PSTE_SANDBOX_BINDING_REFRESH_V3_RECORD_LOCAL','status'=>$complete?'COMPLETE':'RUNNING','outcome'=>$complete?(($cumStale===0&&$cumMissing===0)?'PASS':'PARTIAL_REVIEW_REQUIRED'):'PENDING','offset'=>$offset,'next_cursor'=>$next,'batch_processed'=>count($slice),'total'=>$total,'updated_batch'=>$updated,'source_stale_batch'=>$stale,'record_missing_batch'=>$missing,'updated_total'=>$cumUpdated,'source_stale_total'=>$cumStale,'record_missing_total'=>$cumMissing,'external_provider_calls'=>0,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false,'record_store_metrics'=>PSTE_Sandbox_Record_Store::metrics()];
        }finally{self::releaseLock($token);}
    }

    /**
     * Preserve the complete previous dataflow losslessly without retaining it as a deeply nested PHP array.
     * The archive is audit-only: no runtime decision/consumer reads sandbox_dataflow_archive. JSON string storage
     * removes the large zval/hash-table amplification; gzip is used when available and falls back to plain JSON.
     * @return array<string,mixed>
     */
    private static function compactArchiveEntryFromFlow(array $flow,string $archivedAt,string $reason): array {
        $json=wp_json_encode($flow,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);
        if(!is_string($json)||$json==='')throw new RuntimeException('PSTE_SANDBOX_ARCHIVE_JSON_FAILED');
        $encoding='JSON';$payload=$json;
        if(function_exists('gzencode')){$gz=gzencode($json,6);if(is_string($gz)&&$gz!==''){$encoding='GZIP_BASE64_JSON';$payload=base64_encode($gz);}}
        $entry=[
            'contract'=>'PSTE_SANDBOX_DATAFLOW_ARCHIVE_COMPACT_V1',
            'archived_at_utc'=>$archivedAt,
            'reason'=>$reason,
            'encoding'=>$encoding,
            'payload'=>$payload,
            'payload_sha256'=>hash('sha256',$payload),
            'json_sha256'=>hash('sha256',$json),
            'dataflow_sha256'=>(string)($flow['dataflow_sha256']??''),
            'query_sha256'=>(string)($flow['query_sha256']??''),
            'normal_path_sha256'=>(string)($flow['normal_path_sha256']??''),
        ];
        $copy=$entry;$entry['archive_sha256']=self::hash($copy);return $entry;
    }

    /** @return array{store:array<string,mixed>,converted:int} */
    private static function compactLegacyDataflowArchives(array $store): array {
        $converted=0;
        foreach((array)($store['records']??[]) as $id=>$record){
            if(!is_array($record))continue;$archive=(array)($record['sandbox_dataflow_archive']??[]);if(!$archive)continue;$changed=false;$out=[];
            foreach($archive as $entry){
                if(!is_array($entry)){$out[]=$entry;continue;}
                if(($entry['contract']??'')==='PSTE_SANDBOX_DATAFLOW_ARCHIVE_COMPACT_V1'){$out[]=$entry;continue;}
                $flow=is_array($entry['dataflow']??null)?(array)$entry['dataflow']:[];
                if(!$flow){$out[]=$entry;continue;}
                $out[]=self::compactArchiveEntryFromFlow($flow,(string)($entry['archived_at_utc']??gmdate('c')),(string)($entry['reason']??'BASELINE_BINDING_REFRESHED'));
                $converted++;$changed=true;
            }
            if($changed){$record['sandbox_dataflow_archive']=array_values($out);$store['records'][$id]=$record;}
        }
        return ['store'=>$store,'converted'=>$converted];
    }

    /** Compact only one record; never scans the Sandbox store. */
    private static function compactLegacyDataflowArchivesInRecord(array $record): array {
        $archive=(array)($record['sandbox_dataflow_archive']??[]);if(!$archive)return $record;$changed=false;$out=[];
        foreach($archive as $entry){if(!is_array($entry)||($entry['contract']??'')==='PSTE_SANDBOX_DATAFLOW_ARCHIVE_COMPACT_V1'){$out[]=$entry;continue;}$flow=is_array($entry['dataflow']??null)?(array)$entry['dataflow']:[];if(!$flow){$out[]=$entry;continue;}$out[]=self::compactArchiveEntryFromFlow($flow,(string)($entry['archived_at_utc']??gmdate('c')),(string)($entry['reason']??'BASELINE_BINDING_REFRESHED'));$changed=true;}
        if($changed)$record['sandbox_dataflow_archive']=array_values($out);return $record;
    }

    /** Provider-free rebinding after an explicit portal-baseline refresh. External evidence is preserved for unchanged raw queries. @return array<string,mixed> */
    public static function refreshBindingsAfterBaselineChange(): array {
        $token=self::acquireLock();
        try{
            $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_BASELINE_REQUIRED');
            $state=PSTE_Snapshot::baselineStatus($baseline);if(($state['status']??'')!=='CURRENT')throw new RuntimeException('PSTE_SANDBOX_BASELINE_STALE');
            $registry=PSTE_Article_Type_Registry::build($baseline);$inventory=PSTE_Snapshot::inventory();$store=self::stored();$compaction=self::compactLegacyDataflowArchives($store);$store=(array)$compaction['store'];$updated=0;$stale=0;$now=gmdate('c');
            foreach((array)$store['records'] as $id=>$record){
                if(!is_array($record))continue;$poolKey=(string)($record['pool_key']??'');if($poolKey==='')continue;
                try{$source=self::sourceSummary($poolKey);}catch(Throwable $e){if(!self::isCandidateScopedFailure($e))throw $e;$record=self::markCandidateReviewFailure($record,self::safeCode($e->getMessage()),'SOURCE_STALE_REVIEW_REQUIRED');$record['updated_at_utc']=$now;$store['records'][$id]=$record;$stale++;continue;}
                $query=(string)($record['query']??'');$currentSourceQuery=PSTE_Editorializer::sourceQuery((array)$source['payload']);$currentQuery=PSTE_Normal_Metadata_Path::canonicalInputQuery($currentSourceQuery);
                if($query===''||$currentQuery===''||!hash_equals(hash('sha256',$query),hash('sha256',$currentQuery))){$record['status']='SOURCE_STALE_REVIEW_REQUIRED';$record['workflow_lane']='SOURCE_STALE_REVIEW_REQUIRED';$record['source_refresh_error_code']='PSTE_SANDBOX_RAW_QUERY_CHANGED';$record['updated_at_utc']=$now;$store['records'][$id]=$record;$stale++;continue;}
                $record['source']=$source;$record['binding']=['mode'=>'LIVE_TOPIC_POOL_V1','registry_sha256'=>(string)$registry['registry_sha256'],'family_identity_v2_registry_sha256'=>self::familyIdentityRegistrySha256($registry),'stable_baseline_identity_sha256'=>self::stableBaselineIdentitySha256($baseline),'source_identity_sha256'=>(string)$source['source_identity_sha256']];$record['review_policy_version']=self::REVIEW_POLICY;$record['source_refresh_error_code']='';
                $external=is_array($record['external_relevance']??null)?(array)$record['external_relevance']:[];$effective=(string)($record['relevance_adjudication']['decision']??($external['status']??''));
                $proof=[];if($effective==='RELEVANT_FOR_PORTAL'){$effectiveProof=$external;$effectiveProof['status']='RELEVANT_FOR_PORTAL';$proof=PSTE_Portal_Relevance_Gate::proofFromExternal($effectiveProof,$query,'');}
                $normalPath=PSTE_Normal_Metadata_Path::evaluateRaw($currentSourceQuery,$baseline,'',$proof,(array)$source['payload']);$query=self::normalPathBoundQuery($normalPath,(array)$source['payload'],'PSTE_SANDBOX_BINDING_REFRESH');$dataflow=PSTE_Sandbox_Record_Contract::fromNormalPath($query,$normalPath,$baseline,$registry);
                $archiveFlow=array_values((array)($record['sandbox_dataflow_archive']??[]));if(is_array($record['sandbox_dataflow']??null))$archiveFlow[]=self::compactArchiveEntryFromFlow((array)$record['sandbox_dataflow'],$now,'BASELINE_BINDING_REFRESHED');$record['sandbox_dataflow_archive']=$archiveFlow;$record=PSTE_Sandbox_Record_Contract::applyToRecord($record,$dataflow,$normalPath);
                if($effective==='RELEVANT_FOR_PORTAL'){$external['status']='RELEVANT_FOR_PORTAL';try{$transition=self::postRelevanceDecision($record,$external,$registry,$baseline,(array)$source['payload'],$inventory);$record['internal_proposal']=$transition['internal_proposal'];$record['internal_proposal_sha256']=is_array($transition['internal_proposal'])?self::hash($transition['internal_proposal']):'';$record['status']=(string)$transition['status'];$record['workflow_lane']=self::workflowLaneForStatus($record['status']);$record['requires_external_review']=false;}catch(Throwable $e){if(!self::isCandidateScopedFailure($e))throw $e;$record=self::markCandidateReviewFailure($record,self::safeCode($e->getMessage()),'INTERNAL_REVIEW_FAILED_RETRYABLE');$stale++;}}
                elseif($effective==='NOT_RELEVANT_FOR_PORTAL'){$record['status']='RETAINED_NOT_RELEVANT';$record['workflow_lane']='RETAINED_NOT_RELEVANT';$record['requires_external_review']=false;}
                elseif($effective==='UNCERTAIN_REVIEW'){$record['status']='UNCERTAIN_REVIEW';$record['workflow_lane']='EXTERNAL_RELEVANCE_REVIEW';$record['requires_external_review']=false;}
                $history=array_values((array)($record['history']??[]));$history[]=self::event('BASELINE_BINDING_REFRESHED','PSTE_SANDBOX_EXTERNAL_EVIDENCE_PRESERVED_RAW_QUERY_UNCHANGED');$record['history']=$history;$record['updated_at_utc']=$now;$store['records'][$id]=$record;$updated++;
            }
            $store['last_binding_refresh_at_utc']=$now;$store['last_binding_refresh_counts']=['updated'=>$updated,'source_stale'=>$stale];self::save($store);
            return ['contract'=>'PSTE_SANDBOX_BINDING_REFRESH_V1','status'=>$stale===0?'PASS':'PARTIAL_REVIEW_REQUIRED','updated'=>$updated,'source_stale'=>$stale,'external_provider_calls'=>0,'production_handoff_attempted'=>false,'article_or_taxonomy_write_attempted'=>false];
        }finally{self::releaseLock($token);}
    }

    /** Merge every NEWLY_BLOCKED row from the current verified dry-run. Nothing is deleted. */
    public static function syncFromCurrentDryRun(): array {
        PSTE_Plugin::assertReady();$token=self::acquireLock();
        try{
            $dry=PSTE_Family_Reclassification_V2::storedDryRun();self::assertDryRun($dry);
            if(($dry['coverage_audit']['status']??'')!=='PASS')throw new RuntimeException('PSTE_SANDBOX_DRY_RUN_COVERAGE_PASS_REQUIRED');
            $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_BASELINE_REQUIRED');
            $baselineState=PSTE_Snapshot::baselineStatus($baseline);if(($baselineState['status']??'')!=='CURRENT')throw new RuntimeException('PSTE_SANDBOX_BASELINE_MUST_BE_CURRENT');
            $registry=PSTE_Article_Type_Registry::build($baseline);self::assertBinding($dry,$baseline,$registry);
            $stored=self::stored();$activeJob=(array)($stored['job']??[]);if(in_array((string)($activeJob['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_SANDBOX_JOB_ACTIVE_SYNC_BLOCKED');
            $now=gmdate('c');$seen=[];$new=0;$updated=0;$inventory=null;
            foreach((array)($dry['items']??[]) as $item){
                if((string)($item['classification']??'')!=='NEWLY_BLOCKED')continue;
                $poolKey=(string)($item['pool_key']??'');$query=(string)($item['query']??'');if($poolKey===''||$query==='')throw new RuntimeException('PSTE_SANDBOX_BLOCKED_ITEM_IDENTITY_MISSING');
                $id=hash('sha256',$poolKey.'|'.(string)($item['query_sha256']??hash('sha256',$query)));$seen[$id]=true;
                // Legacy dry-run sync is seed-only compatibility. It may never downgrade or replace
                // a current live-bound record, even when the same id appears in the old dry-run.
                $authoritative=is_array($stored['records'][$id]??null)?(array)$stored['records'][$id]:[];
                if($authoritative&&(string)($authoritative['binding']['mode']??'')==='LIVE_TOPIC_POOL_V1'){$updated++;continue;}
                $source=self::sourceSummary($poolKey);$currentSourceQuery=PSTE_Editorializer::sourceQuery((array)$source['payload']);$itemQuery=PSTE_Normal_Metadata_Path::canonicalInputQuery($query);$currentQuery=PSTE_Normal_Metadata_Path::canonicalInputQuery($currentSourceQuery);$sourceCurrent=$itemQuery!==''&&$currentQuery!==''&&hash_equals(hash('sha256',$itemQuery),hash('sha256',$currentQuery));
                $diag=(array)($item['resolution']['rejection_diagnostics']??[]);$nearest=array_values((array)($diag['nearest_rejected_families']??[]));$nearestFailures=array_values(array_map('strval',(array)($diag['nearest_failure_reason_codes']??[])));
                $route=PSTE_Sandbox_Portal_Relevance::route($query,$item,$registry,$baseline,$sourceCurrent);$lane=(string)$route['workflow_lane'];$requiresExternal=!empty($route['requires_external_review']);$admittedExternal=$requiresExternal;
                $old=is_array($stored['records'][$id]??null)?(array)$stored['records'][$id]:[];$sameQuery=$old&&hash_equals((string)($old['query_sha256']??''),(string)($item['query_sha256']??hash('sha256',$query)));
                $sameBinding=$old&&hash_equals((string)($old['binding']['dry_run_sha256']??''),(string)$dry['dry_run_sha256'])&&hash_equals((string)($old['binding']['registry_sha256']??''),(string)$dry['registry_sha256'])&&hash_equals((string)($old['binding']['stable_baseline_identity_sha256']??''),self::stableBaselineIdentitySha256($baseline))&&hash_equals((string)($old['source']['row_sha256']??''),(string)$source['row_sha256']);
                $samePolicy=$old&&hash_equals((string)($old['review_policy_version']??''),self::REVIEW_POLICY);
                $history=array_values((array)($old['history']??[]));$reviewArchive=array_values((array)($old['review_archive']??[]));
                if(!$old){$history[]=self::event('SYNC_CREATED','PSTE_SANDBOX_NEW_BLOCKED_CANDIDATE_PRESERVED');$new++;}else{$updated++;}
                $status=(string)$route['status'];$external=null;$internal=null;$adjudication=null;$internalAdjudication=null;$providerError=$old['provider_error']??null;$providerErrorHistory=array_values((array)($old['provider_error_history']??[]));$providerErrorRetryCycles=(int)($old['provider_error_retry_cycles']??0);
                if($sameBinding&&$samePolicy){
                    $status=(string)($old['status']??$status);$external=$old['external_relevance']??null;$internal=$old['internal_proposal']??null;$adjudication=$old['relevance_adjudication']??null;$internalAdjudication=$old['internal_adjudication']??null;$lane=(string)($old['workflow_lane']??$lane);$requiresExternal=!empty($old['requires_external_review']);$admittedExternal=array_key_exists('admitted_to_external_review',$old)?!empty($old['admitted_to_external_review']):$admittedExternal;
                }elseif($old){
                    if(($old['external_relevance']??null)!==null||($old['internal_proposal']??null)!==null||($old['relevance_adjudication']??null)!==null||($old['internal_adjudication']??null)!==null){$reviewArchive[]=self::archivedReview($old,$samePolicy?'BINDING_CHANGED':'REVIEW_POLICY_CHANGED');}
                    if(!$samePolicy)$history[]=self::event('REVIEW_POLICY_CHANGED','PSTE_SANDBOX_PORTAL_CONTEXT_ROUTER_POLICY_REQUIRES_REVIEW');
                    if(!$sameBinding)$history[]=self::event('BINDING_CHANGED','PSTE_SANDBOX_PRIOR_REVIEW_INVALIDATED_BY_BINDING_CHANGE');
                }
                $legacyDataflow=PSTE_Sandbox_Record_Contract::fromLegacyRoute($query,$route,$nearest,$nearestFailures);
                $record=[
                    'sandbox_id'=>$id,'query'=>$query,'query_sha256'=>(string)($item['query_sha256']??hash('sha256',$query)),
                    'pool_id'=>(int)($item['pool_id']??0),'pool_key'=>$poolKey,'candidate_id'=>(string)($item['candidate_id']??''),
                    'original_classification'=>'NEWLY_BLOCKED','original_reason_codes'=>array_values((array)($item['reason_codes']??[])),
                    'old_family_key'=>(string)($item['old_family_key']??''),'old_family_name'=>(string)($item['old_family_name']??''),'article_type'=>(string)($item['article_type']??''),
                    'nearest_rejected_families'=>$nearest,'nearest_failure_reason_codes'=>$nearestFailures,
                    'review_policy_version'=>self::REVIEW_POLICY,'workflow_lane'=>$lane,'requires_external_review'=>$requiresExternal,
                    'admitted_to_external_review'=>$admittedExternal,'admission_reason_codes'=>(array)$route['reason_codes'],'status'=>$status,
                    'portal_relevance'=>(array)$route['portal_context'],'exclusion_evidence'=>(array)$route['exclusion_evidence'],
                    'search_volume'=>$source['search_volume'],'source_names'=>$source['source_names'],'source'=>$source,
                    'binding'=>[
                        'mode'=>'LEGACY_DRY_RUN_V1','dry_run_sha256'=>(string)$dry['dry_run_sha256'],'source_snapshot_sha256'=>(string)$dry['source_snapshot_sha256'],
                        'baseline_sha256'=>(string)$dry['baseline_sha256'],'registry_sha256'=>(string)$dry['registry_sha256'],
                        'family_identity_v2_registry_sha256'=>(string)$dry['family_identity_v2_registry_sha256'],
                        'stable_baseline_identity_sha256'=>self::stableBaselineIdentitySha256($baseline),
                    ],
                    'external_relevance'=>$external,'relevance_adjudication'=>$adjudication,'internal_proposal'=>$internal,'internal_proposal_sha256'=>is_array($internal)?self::hash($internal):'','internal_adjudication'=>$internalAdjudication,'provider_error'=>$providerError,'provider_error_history'=>$providerErrorHistory,'provider_error_retry_cycles'=>$providerErrorRetryCycles,'review_archive'=>$reviewArchive,'history'=>$history,
                    'first_seen_at_utc'=>(string)($old['first_seen_at_utc']??$now),'updated_at_utc'=>$now,
                    'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,'production_handoff_attempted'=>false,
                ];
                $record=PSTE_Sandbox_Record_Contract::applyToRecord($record,$legacyDataflow);
                if($sourceCurrent&&!($sameBinding&&$samePolicy)){
                    // Internal policy/binding changes invalidate only the internal proposal. Independent external
                    // evidence remains reusable for the identical raw query and is never thrown away just because
                    // editorial metadata changed.
                    $record['internal_proposal']=null;$record['internal_proposal_sha256']='';$record['internal_adjudication']=null;
                    $canReuseExternal=$sameQuery&&is_array($old['external_relevance']??null);
                    if($canReuseExternal){
                        $record['external_relevance']=$old['external_relevance'];$record['relevance_adjudication']=$old['relevance_adjudication']??null;$record['provider_error']=$old['provider_error']??null;$record['provider_error_history']=array_values((array)($old['provider_error_history']??[]));$record['provider_error_retry_cycles']=(int)($old['provider_error_retry_cycles']??0);
                        $effective=(array)$record['external_relevance'];$effectiveStatus=(string)($record['relevance_adjudication']['decision']??($effective['status']??''));
                        if($effectiveStatus==='RELEVANT_FOR_PORTAL'){$effective['status']='RELEVANT_FOR_PORTAL';if($inventory===null)$inventory=PSTE_Snapshot::inventory();$transition=self::postRelevanceDecision($record,$effective,$registry,$baseline,(array)$source['payload'],$inventory);$record['internal_proposal']=$transition['internal_proposal'];$record['internal_proposal_sha256']=is_array($transition['internal_proposal'])?self::hash($transition['internal_proposal']):'';$record['status']=(string)$transition['status'];$record['workflow_lane']=self::workflowLaneForStatus($record['status']);$record['requires_external_review']=false;}
                        elseif($effectiveStatus==='NOT_RELEVANT_FOR_PORTAL'){$record['status']='RETAINED_NOT_RELEVANT';$record['workflow_lane']='RETAINED_NOT_RELEVANT';$record['requires_external_review']=false;}
                        elseif($effectiveStatus==='UNCERTAIN_REVIEW'){$record['status']='UNCERTAIN_REVIEW';$record['workflow_lane']='EXTERNAL_RELEVANCE_REVIEW';$record['requires_external_review']=false;}
                        else{$record['status']='PENDING_EXTERNAL_RELEVANCE';$record['workflow_lane']='EXTERNAL_RELEVANCE_REVIEW';$record['requires_external_review']=true;}
                        $history[]=self::event('EXTERNAL_EVIDENCE_PRESERVED_INTERNAL_REVIEW_REFRESHED','PSTE_SANDBOX_EXTERNAL_EVIDENCE_BOUND_TO_UNCHANGED_RAW_QUERY');$record['history']=$history;
                    }else{
                        $record['external_relevance']=null;$record['relevance_adjudication']=null;$record['provider_error']=null;$record['provider_error_retry_cycles']=0;$record['status']='PENDING_EXTERNAL_RELEVANCE';$record['workflow_lane']='EXTERNAL_RELEVANCE_REVIEW';$record['requires_external_review']=true;$record['admitted_to_external_review']=true;$history[]=self::event('EXTERNAL_RELEVANCE_REQUIRED','PSTE_SANDBOX_RELEVANCE_EVIDENCE_REQUIRED_BEFORE_INTERNAL_ROUTING');$record['history']=$history;
                    }
                }
                $stored['records'][$id]=$record;
            }
            foreach((array)$stored['records'] as $id=>$record){
                if(isset($seen[$id]))continue;
                // This is only a compatibility sync for old dry-run-bound records. Live-admitted
                // records are authoritative retained backlog items and must never be demoted merely
                // because an unrelated historical dry-run no longer lists them.
                if((string)($record['binding']['mode']??'')==='LIVE_TOPIC_POOL_V1')continue;
                $history=array_values((array)($record['history']??[]));
                if((string)($record['status']??'')!=='RETAINED_HISTORICAL_NOT_IN_CURRENT_BLOCKED_SET')$history[]=self::event('RETAINED_HISTORICAL','PSTE_SANDBOX_RECORD_NOT_DELETED_WHEN_ABSENT_FROM_CURRENT_BLOCKED_SET');
                $record['status']='RETAINED_HISTORICAL_NOT_IN_CURRENT_BLOCKED_SET';$record['history']=$history;$record['updated_at_utc']=$now;$stored['records'][$id]=$record;
            }
            $stored['review_policy_version']=self::REVIEW_POLICY;$stored['binding']=['dry_run_sha256'=>(string)$dry['dry_run_sha256'],'source_snapshot_sha256'=>(string)$dry['source_snapshot_sha256'],'baseline_sha256'=>(string)$dry['baseline_sha256'],'registry_sha256'=>(string)$dry['registry_sha256'],'family_identity_v2_registry_sha256'=>(string)$dry['family_identity_v2_registry_sha256'],'stable_baseline_identity_sha256'=>self::stableBaselineIdentitySha256($baseline)];
            $stored['last_sync_at_utc']=$now;$stored['last_sync_counts']=['current_newly_blocked'=>count($seen),'created'=>$new,'updated'=>$updated];$stored['job']=null;
            self::save($stored);return self::summary($stored);
        }finally{self::releaseLock($token);}
    }

    /** Backward-compatible diagnostic wrapper around the evidence-before-internal router. @return array<string,mixed> */
    public static function admissionDecision(array $item,bool $sourceCurrent=true,array $registry=[],array $baseline=[]): array {
        if((string)($item['classification']??'')!=='NEWLY_BLOCKED')return ['admitted'=>false,'requires_external_review'=>false,'workflow_lane'=>'NOT_ELIGIBLE','reason_codes'=>['PSTE_SANDBOX_ONLY_NEWLY_BLOCKED_ALLOWED'],'nearest_count'=>0,'active_exclusion'=>false,'source_current'=>$sourceCurrent,'review_policy_version'=>self::REVIEW_POLICY];
        if(!$baseline&&function_exists('get_option')){$b=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(is_array($b))$baseline=$b;}
        if(!$registry&&$baseline)$registry=PSTE_Article_Type_Registry::build($baseline);
        $route=PSTE_Sandbox_Portal_Relevance::route((string)($item['query']??''),$item,$registry,$baseline,$sourceCurrent);
        return ['admitted'=>$sourceCurrent&&((string)($item['classification']??'')==='NEWLY_BLOCKED'),'requires_external_review'=>!empty($route['requires_external_review']),'workflow_lane'=>(string)$route['workflow_lane'],'reason_codes'=>(array)$route['reason_codes'],'nearest_count'=>(int)$route['nearest_count'],'active_exclusion'=>!empty($route['exclusion_evidence']['nearest_family_active']),'source_current'=>$sourceCurrent,'review_policy_version'=>self::REVIEW_POLICY,'portal_context'=>(array)$route['portal_context'],'exclusion_evidence'=>(array)$route['exclusion_evidence']];
    }

    /** Start one bounded job. Real SERP evidence is mandatory, therefore production environment only. */
    public static function startAnalysis(array $settings): array {
        PSTE_Plugin::assertReady();$token=self::acquireLock();
        try{
            if(empty($settings['feature_enabled']))throw new RuntimeException('PSTE_SANDBOX_PAID_RESEARCH_DISABLED');
            if((string)($settings['environment']??'sandbox')!=='production')throw new RuntimeException('PSTE_SANDBOX_REAL_SEO_REQUIRES_PRODUCTION_ENVIRONMENT');
            if(!PSTE_Credentials::configured())throw new RuntimeException('PSTE_SANDBOX_DATAFORSEO_CREDENTIALS_REQUIRED');
            $registry=self::stored();self::assertCurrentBinding($registry);$activeJob=(array)($registry['job']??[]);if(in_array((string)($activeJob['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_SANDBOX_JOB_ALREADY_ACTIVE');
            $primary=[];$deferred=[];
            foreach((array)$registry['records'] as $id=>$record){
                if(empty($record['requires_external_review']))continue;$status=(string)($record['status']??'');
                if(in_array($status,['PENDING_EXTERNAL_RELEVANCE','STALE_REVIEW_REQUIRED'],true))$primary[]=(string)$id;
                elseif($status==='DEFERRED_PROVIDER_ERROR'&&(int)($record['provider_error_retry_cycles']??0)<PSTE_Sandbox_Provider_Error_Policy::MAX_DEFERRED_RETRY_CYCLES)$deferred[]=(string)$id;
            }
            sort($primary,SORT_STRING);sort($deferred,SORT_STRING);$queueMode=$primary?'PRIMARY':($deferred?'DEFERRED_RETRY':'');$open=$primary?:$deferred;
            if(!$open)return ['contract'=>self::JOB_CONTRACT,'status'=>'NOTHING_TO_DO','job_uuid'=>'','progress'=>0,'total'=>0,'estimated_cost'=>0.0,'actual_cost'=>0.0,'remaining_open_after_batch'=>0,'queue_mode'=>''];
            $capacity=self::safeBatchCapacity($registry,$settings,count($open));if($capacity<1)throw new RuntimeException('PSTE_SANDBOX_NO_BUDGET_CAPACITY_FOR_ONE_SERP_TASK');
            $queue=array_slice($open,0,$capacity);$estimated=self::estimateWorstCaseBatchCost(count($queue));
            PSTE_Cost_Guard::assertWithin($estimated,(float)$settings['run_budget_usd'],(float)$settings['absolute_ceiling_usd']);self::assertSandboxHistoricalBudgets($registry,$estimated,$settings);
            $uuid=function_exists('wp_generate_uuid4')?wp_generate_uuid4():hash('sha256',microtime(true).'|'.uniqid('',true));
            PSTE_Budget_Reservations::reserve($uuid,$estimated,$settings,'SEMANTIC_SANDBOX_SERP_RELEVANCE',3600);
            $job=['contract'=>self::JOB_CONTRACT,'job_uuid'=>$uuid,'status'=>'RUNNING','queue'=>$queue,'queue_mode'=>$queueMode,'cursor'=>0,'progress'=>0,'total'=>count($queue),'open_before_batch'=>count($open),'remaining_open_after_batch'=>max(0,count($open)-count($queue)),'estimated_cost'=>$estimated,'actual_cost'=>0.0,'last_error'=>'','provider_error_policy_version'=>PSTE_Sandbox_Provider_Error_Policy::CONTRACT,'consecutive_task_error_code'=>'','consecutive_task_error_count'=>0,'started_at_utc'=>gmdate('c'),'updated_at_utc'=>gmdate('c'),'reservation_active'=>true];
            $registry['job']=$job;self::save($registry);return self::publicJob($job);
        }finally{self::releaseLock($token);}
    }

    /** Process exactly one candidate per request; the admin JS chains these safely. */
    public static function advanceAnalysis(string $jobUuid,array $settings,bool $explicitResume=false): array {
        PSTE_Plugin::assertReady();$token=self::acquireLock();
        try{
            $registry=self::stored();$job=is_array($registry['job']??null)?(array)$registry['job']:[];
            if(($job['contract']??'')!==self::JOB_CONTRACT||!hash_equals((string)($job['job_uuid']??''),$jobUuid))throw new RuntimeException('PSTE_SANDBOX_JOB_NOT_FOUND');
            if((string)($settings['environment']??'')!=='production')throw new RuntimeException('PSTE_SANDBOX_REAL_SEO_REQUIRES_PRODUCTION_ENVIRONMENT');
            if((string)($job['status']??'')==='COMPLETE')return self::publicJob($job);
            if((string)($job['status']??'')==='OUTCOME_UNKNOWN')return self::publicJob($job);
            if((string)($job['status']??'')==='PAUSED_ERROR'){
                if(!$explicitResume)return self::publicJob($job);
                if(self::resumeLegacyCandidatePauseWithoutResend($registry,$job))return self::publicJob((array)$registry['job']);
                $job['status']='RUNNING';$job['last_error']='';$job['updated_at_utc']=gmdate('c');$registry['job']=$job;self::save($registry);
            }
            self::normalizeLegacyJobBudgetEnvelope($job);$registry['job']=$job;self::save($registry);
            self::assertCurrentBinding($registry);$remaining=round(max(0.000001,(float)$job['estimated_cost']-(float)$job['actual_cost']),6);PSTE_Budget_Reservations::reserve($jobUuid,$remaining,$settings,'SEMANTIC_SANDBOX_SERP_RELEVANCE',3600);
            $queue=array_values((array)$job['queue']);$cursor=(int)($job['cursor']??0);
            if($cursor>=count($queue)){self::completeJob($registry,$job);self::save($registry);return self::publicJob($registry['job']);}
            $id=(string)$queue[$cursor];$record=is_array($registry['records'][$id]??null)?(array)$registry['records'][$id]:[];if(!$record)throw new RuntimeException('PSTE_SANDBOX_QUEUE_RECORD_MISSING');
            self::assertRecordCurrent($record);
            try{
                $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);$currentRegistry=PSTE_Article_Type_Registry::build(is_array($baseline)?$baseline:[]);
                $client=new PSTE_DataForSEO_Client('production');
                $response=$client->googleOrganicSerp((string)$record['query'],(string)$settings['location'],(string)$settings['language'],10);
                $external=PSTE_Sandbox_SEO_Relevance::evaluate((string)$record['query'],$response,$currentRegistry,'production');
                $cost=(float)($external['actual_cost_usd']??0.0);self::consumeKnownJobCost($jobUuid,$job,$cost);
                $source=self::sourceSummary((string)$record['pool_key']);
                if(!hash_equals((string)$record['source']['row_sha256'],(string)$source['row_sha256']))throw new RuntimeException('PSTE_SANDBOX_SOURCE_ROW_STALE_DURING_REVIEW');
                $decision=self::postRelevanceDecision($record,$external,$currentRegistry,(array)$baseline,(array)$source['payload'],PSTE_Snapshot::inventory());
                $internal=$decision['internal_proposal'];$status=(string)$decision['status'];
                $history=array_values((array)($record['history']??[]));$history[]=self::event('EXTERNAL_RELEVANCE_CHECKED',(string)$external['status']);if(is_array($internal))$history[]=self::event('INTERNAL_PROPOSAL_BUILT',(string)($internal['status']??'REVIEW_REQUIRED'));
                $record['external_relevance']=$external;$record['relevance_adjudication']=null;$record['internal_proposal']=$internal;$record['internal_proposal_sha256']=is_array($internal)?self::hash($internal):'';$record['internal_adjudication']=null;$record['status']=$status;$record['workflow_lane']=self::workflowLaneForStatus($status);$record['requires_external_review']=false;$record['updated_at_utc']=gmdate('c');$record['history']=$history;$registry['records'][$id]=$record;
                self::advanceJobAfterCandidate($job,$cursor,true,'');$registry['job']=$job;
                if((int)$job['cursor']>=count($queue)){self::completeJob($registry,$job);$job=(array)$registry['job'];}
                self::save($registry);return self::publicJob($job);
            }catch(PSTE_Provider_Exception $e){
                $policy=PSTE_Sandbox_Provider_Error_Policy::classifyException($e);
                // A provider-declared response has a known outcome even when it is an error. Count any
                // provider-reported cost before deciding whether the scope is candidate- or job-wide.
                $knownCost=PSTE_Sandbox_Provider_Error_Policy::knownCostUsd($e->safeDetails());self::consumeKnownJobCost($jobUuid,$job,$knownCost);
                if((string)$policy['scope']==='GLOBAL_OUTCOME_UNKNOWN'){$job['last_error']=$e->getMessage();$job['status']='OUTCOME_UNKNOWN';$job['updated_at_utc']=gmdate('c');$registry['job']=$job;self::save($registry);return self::publicJob($job);}
                if(!str_starts_with((string)$policy['scope'],'CANDIDATE_')){$job['last_error']=$e->getMessage();$job['status']='PAUSED_ERROR';$job['updated_at_utc']=gmdate('c');$registry['job']=$job;self::save($registry);return self::publicJob($job);}
                self::applyCandidateProviderFailure($record,$e,$policy,(string)($job['queue_mode']??'PRIMARY'));$registry['records'][$id]=$record;
                self::advanceJobAfterCandidate($job,$cursor,false,(string)$e->getMessage());$registry['job']=$job;
                if((int)($job['consecutive_task_error_count']??0)>=PSTE_Sandbox_Provider_Error_Policy::CIRCUIT_BREAKER_THRESHOLD){$job['status']='PAUSED_ERROR';$job['last_error']='PSTE_SANDBOX_PROVIDER_CIRCUIT_BREAKER_'.self::safeCode((string)$e->getMessage());$job['updated_at_utc']=gmdate('c');$registry['job']=$job;self::save($registry);return self::publicJob($job);}
                if((int)$job['cursor']>=count($queue)){self::completeJob($registry,$job);$job=(array)$registry['job'];}
                self::save($registry);return self::publicJob($job);
            }catch(Throwable $e){$job['last_error']=self::safeCode($e->getMessage());$job['status']='PAUSED_ERROR';$job['updated_at_utc']=gmdate('c');$registry['job']=$job;self::save($registry);return self::publicJob($job);}
        }finally{self::releaseLock($token);}
    }

    /**
     * Pure post-relevance transition. Local query text, portal-context hints and family proximity
     * cannot call this path by themselves; a separate relevance outcome is mandatory.
     * @return array{status:string,internal_proposal:?array}
     */
    public static function postRelevanceDecision(array $record,array $external,array $registry,array $baseline,array $sourcePayload,array $inventory): array {
        $externalStatus=(string)($external['status']??'');
        if($externalStatus==='RELEVANT_FOR_PORTAL'){
            $internal=PSTE_Sandbox_Internal_Planner::plan($record,$registry,$baseline,$external,$sourcePayload,$inventory);
            return ['status'=>(string)($internal['status']??'REVIEW_REQUIRED'),'internal_proposal'=>$internal];
        }
        if($externalStatus==='NOT_RELEVANT_FOR_PORTAL')return ['status'=>'RETAINED_NOT_RELEVANT','internal_proposal'=>null];
        return ['status'=>'UNCERTAIN_REVIEW','internal_proposal'=>null];
    }


    /**
     * Backward-compatible entry point for the first explicit review of an externally UNCERTAIN candidate.
     * @return array<string,mixed>
     */
    public static function reviewUncertainRelevance(string $sandboxId,string $decision,string $expectedResponseSha256,string $note,int $userId): array {
        return self::reviewOrReviseRelevance($sandboxId,$decision,$expectedResponseSha256,'',$note,$userId);
    }

    /**
     * Create OR revise a manual relevance decision. The raw external SERP evidence is immutable.
     * Every revision is optimistic-lock bound to the currently stored decision hash, archives the
     * superseded decision plus all downstream Sandbox review state, and recomputes the post-relevance
     * path from the current baseline. Reentry already handed back to the normal pipeline is never
     * silently reversed here.
     * @return array<string,mixed>
     */
    public static function reviewOrReviseRelevance(string $sandboxId,string $decision,string $expectedResponseSha256,string $expectedCurrentDecisionSha256,string $note,int $userId): array {
        PSTE_Plugin::assertReady();$token=self::acquireLock();
        try{
            $registry=self::stored();self::assertNoActiveJob($registry);self::assertCurrentBinding($registry);
            $record=is_array($registry['records'][$sandboxId]??null)?(array)$registry['records'][$sandboxId]:[];if(!$record)throw new RuntimeException('PSTE_SANDBOX_REVIEW_RECORD_NOT_FOUND');
            self::assertRecordCurrent($record);self::assertRelevanceAdjudicationChain($record);

            $external=is_array($record['external_relevance']??null)?(array)$record['external_relevance']:[];
            $externalContract=(string)($external['contract']??'');
            $reviewableContract=$externalContract===PSTE_Sandbox_SEO_Relevance::CONTRACT||($externalContract==='PSTE_SANDBOX_EXTERNAL_PROVIDER_OUTCOME_V1'&&!empty($external['reviewable_external_evidence']));
            if(!$reviewableContract||(string)($external['environment']??'')!=='production'||(string)($external['status']??'')!=='UNCERTAIN_REVIEW')throw new RuntimeException('PSTE_SANDBOX_REAL_EXTERNAL_EVIDENCE_REQUIRED_FOR_EXPLICIT_REVIEW');

            $recordQuery=(string)($record['query']??'');$externalQuery=(string)($external['query']??'');
            if($recordQuery===''||$externalQuery===''||!hash_equals($recordQuery,$externalQuery)||!hash_equals((string)($record['query_sha256']??''),hash('sha256',$externalQuery)))throw new RuntimeException('PSTE_SANDBOX_EXTERNAL_EVIDENCE_QUERY_MISMATCH');
            $responseSha=(string)($external['response_sha256']??'');
            if(!preg_match('/^[a-f0-9]{64}$/',$responseSha)||!hash_equals($responseSha,$expectedResponseSha256))throw new RuntimeException('PSTE_SANDBOX_EXTERNAL_EVIDENCE_HASH_MISMATCH');

            $decision=strtoupper(trim($decision));
            if(!in_array($decision,['RELEVANT_FOR_PORTAL','NOT_RELEVANT_FOR_PORTAL'],true))throw new RuntimeException('PSTE_SANDBOX_EXPLICIT_RELEVANCE_DECISION_INVALID');
            $note=trim($note);if($note==='')throw new RuntimeException('PSTE_SANDBOX_EXPLICIT_REVIEW_NOTE_REQUIRED');if($userId<=0)throw new RuntimeException('PSTE_SANDBOX_EXPLICIT_REVIEW_USER_REQUIRED');

            $previous=is_array($record['relevance_adjudication']??null)?(array)$record['relevance_adjudication']:[];
            $previousDecision=(string)($previous['decision']??'');$previousSource=(string)($previous['decision_source']??'');
            $isRevision=in_array($previousDecision,['RELEVANT_FOR_PORTAL','NOT_RELEVANT_FOR_PORTAL'],true)&&in_array($previousSource,['EXPLICIT_ADMIN_REVIEW','EXPLICIT_ADMIN_REVIEW_REVISION'],true)&&preg_match('/^[a-f0-9]{64}$/',(string)($previous['decision_sha256']??''));
            if(!$isRevision){
                if((string)($record['status']??'')!=='UNCERTAIN_REVIEW')throw new RuntimeException('PSTE_SANDBOX_EXPLICIT_RELEVANCE_REVIEW_REQUIRES_UNCERTAIN');
                if(trim($expectedCurrentDecisionSha256)!=='')throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_UNEXPECTED_CURRENT_HASH');
            }else{
                $blockedStatuses=['AUTO_REENTRY_ELIGIBLE','REENTERED_TO_NORMAL_PIPELINE','REENTRY_REVIEW_REQUIRED'];
                if(in_array((string)($record['status']??''),$blockedStatuses,true)||!empty($record['reentry_result'])||!empty($record['internal_proposal']['reentry_applied']))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_AFTER_REENTRY_FORBIDDEN');
                $previousSha=(string)($previous['decision_sha256']??'');
                if(!preg_match('/^[a-f0-9]{64}$/',$previousSha)||!preg_match('/^[a-f0-9]{64}$/',$expectedCurrentDecisionSha256)||!hash_equals($previousSha,$expectedCurrentDecisionSha256))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_STALE_DECISION_HASH');
                if(hash_equals($previousDecision,$decision))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_NO_CHANGE');
            }

            $source=self::sourceSummary((string)$record['pool_key']);
            $revision=$isRevision?max(2,(int)($previous['revision']??1)+1):1;
            $adjudication=[
                'contract'=>'PSTE_SANDBOX_RELEVANCE_ADJUDICATION_V2','revision'=>$revision,'decision'=>$decision,
                'decision_source'=>$isRevision?'EXPLICIT_ADMIN_REVIEW_REVISION':'EXPLICIT_ADMIN_REVIEW',
                'reviewed_at_utc'=>gmdate('c'),'reviewed_by'=>$userId,'note'=>$note,'query_sha256'=>(string)($record['query_sha256']??''),
                'external_response_sha256'=>$responseSha,'external_evidence_sha256'=>self::hash($external),'source_row_sha256'=>(string)$source['row_sha256'],
                'binding'=>(array)($record['binding']??[]),'automatic_external_status'=>(string)$external['status'],
                'supersedes_decision_sha256'=>$isRevision?(string)($previous['decision_sha256']??''):'',
                'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,'production_handoff_attempted'=>false,
            ];
            $adjudication['decision_sha256']=self::hash($adjudication);

            if($isRevision){
                $archive=array_values((array)($record['relevance_revision_archive']??[]));
                $entry=[
                    'contract'=>'PSTE_SANDBOX_RELEVANCE_REVISION_ARCHIVE_V1','archived_at_utc'=>gmdate('c'),'reason'=>'EXPLICIT_ADMIN_RELEVANCE_CORRECTION',
                    'previous_decision_sha256'=>(string)$previous['decision_sha256'],'superseded_by_decision_sha256'=>(string)$adjudication['decision_sha256'],
                    'previous_relevance_adjudication'=>$previous,'previous_status'=>(string)($record['status']??''),'previous_workflow_lane'=>(string)($record['workflow_lane']??''),
                    'previous_internal_proposal'=>$record['internal_proposal']??null,'previous_internal_proposal_sha256'=>(string)($record['internal_proposal_sha256']??''),
                    'previous_internal_adjudication'=>$record['internal_adjudication']??null,
                    'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,'production_handoff_attempted'=>false,
                ];
                $entry['archive_sha256']=self::hash($entry);$archive[]=$entry;$record['relevance_revision_archive']=$archive;
            }

            $effective=$external;$effective['automatic_status_before_explicit_review']=(string)$external['status'];$effective['status']=$decision;$effective['decision_source']=(string)$adjudication['decision_source'];$effective['relevance_adjudication_sha256']=$adjudication['decision_sha256'];
            $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline))throw new RuntimeException('PSTE_SANDBOX_BASELINE_REQUIRED');$currentRegistry=PSTE_Article_Type_Registry::build($baseline);
            $planningRecord=$record;$planningRecord['relevance_adjudication']=$adjudication;$planningRecord['internal_adjudication']=null;$planningRecord['internal_proposal']=null;$planningRecord['internal_proposal_sha256']='';
            $transition=self::postRelevanceDecision($planningRecord,$effective,$currentRegistry,$baseline,(array)$source['payload'],PSTE_Snapshot::inventory());

            $history=array_values((array)($record['history']??[]));$history[]=self::event($isRevision?'EXPLICIT_RELEVANCE_REVIEW_REVISED':'EXPLICIT_RELEVANCE_REVIEW',$isRevision?($previousDecision.'_TO_'.$decision):$decision);
            $record['relevance_adjudication']=$adjudication;$record['internal_adjudication']=null;$record['internal_proposal']=$transition['internal_proposal'];$record['internal_proposal_sha256']=is_array($transition['internal_proposal'])?self::hash($transition['internal_proposal']):'';
            unset($record['reentry_result'],$record['reentry_result_sha256'],$record['reentry_error_code']);
            $record['status']=(string)$transition['status'];$record['workflow_lane']=self::workflowLaneForStatus((string)$transition['status']);$record['requires_external_review']=false;$record['updated_at_utc']=gmdate('c');$record['history']=$history;
            self::assertRelevanceAdjudicationChain($record);$registry['records'][$sandboxId]=$record;
            self::save($registry);return $record;
        }finally{self::releaseLock($token);}
    }

    /**
     * Confirm a completed Sandbox internal proposal only as ready for the normal reentry review.
     * This is NOT a five-field handoff and writes no topic/source/article data.
     * @return array<string,mixed>
     */
    public static function confirmInternalProposalForNormalReentry(string $sandboxId,string $expectedProposalSha256,string $note,int $userId): array {
        PSTE_Plugin::assertReady();$token=self::acquireLock();
        try{
            $registry=self::stored();self::assertNoActiveJob($registry);self::assertCurrentBinding($registry);
            $record=is_array($registry['records'][$sandboxId]??null)?(array)$registry['records'][$sandboxId]:[];if(!$record)throw new RuntimeException('PSTE_SANDBOX_INTERNAL_REVIEW_RECORD_NOT_FOUND');self::assertRecordCurrent($record);
            $status=(string)($record['status']??'');if(!in_array($status,['MATCHER_REVIEW','PROPOSAL_READY_FOR_REVIEW'],true))throw new RuntimeException('PSTE_SANDBOX_INTERNAL_PROPOSAL_NOT_CONFIRMABLE');
            $effectiveRelevance=self::effectiveRelevanceStatus($record);if($effectiveRelevance!=='RELEVANT_FOR_PORTAL')throw new RuntimeException('PSTE_SANDBOX_INTERNAL_CONFIRMATION_RELEVANCE_REQUIRED');
            $note=trim($note);if($note==='')throw new RuntimeException('PSTE_SANDBOX_INTERNAL_REVIEW_NOTE_REQUIRED');if($userId<=0)throw new RuntimeException('PSTE_SANDBOX_INTERNAL_REVIEW_USER_REQUIRED');
            $proposal=is_array($record['internal_proposal']??null)?(array)$record['internal_proposal']:[];$review=(array)($proposal['review_proposal']??[]);if(!$proposal||!$review)throw new RuntimeException('PSTE_SANDBOX_INTERNAL_PROPOSAL_REQUIRED');
            $proposalSha=self::hash($proposal);$storedProposalSha=(string)($record['internal_proposal_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$storedProposalSha)||!hash_equals($proposalSha,$storedProposalSha)||!preg_match('/^[a-f0-9]{64}$/',$expectedProposalSha256)||!hash_equals($proposalSha,$expectedProposalSha256))throw new RuntimeException('PSTE_SANDBOX_INTERNAL_PROPOSAL_HASH_MISMATCH');
            if(empty($proposal['normal_reentry']['explicit_review_required'])||!empty($proposal['normal_reentry']['five_field_handoff_created'])||!empty($proposal['production_handoff_attempted']))throw new RuntimeException('PSTE_SANDBOX_INTERNAL_PROPOSAL_SAFETY_CONTRACT_INVALID');
            $adjudication=[
                'contract'=>'PSTE_SANDBOX_INTERNAL_ADJUDICATION_V1','decision'=>'READY_FOR_NORMAL_REENTRY_REVIEW','decision_source'=>'EXPLICIT_ADMIN_REVIEW',
                'reviewed_at_utc'=>gmdate('c'),'reviewed_by'=>$userId,'note'=>$note,'query_sha256'=>(string)($record['query_sha256']??''),
                'internal_proposal_sha256'=>$proposalSha,'source_row_sha256'=>(string)($record['source']['row_sha256']??''),'binding'=>(array)($record['binding']??[]),
                'five_field_handoff_created'=>false,'production_handoff_attempted'=>false,'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,
            ];$adjudication['decision_sha256']=self::hash($adjudication);
            $history=array_values((array)($record['history']??[]));$history[]=self::event('INTERNAL_PROPOSAL_CONFIRMED_FOR_NORMAL_REENTRY_REVIEW','PSTE_SANDBOX_NO_PRODUCTION_HANDOFF_CREATED');
            $record['internal_adjudication']=$adjudication;$record['status']='READY_FOR_NORMAL_REENTRY_REVIEW';$record['workflow_lane']='READY_FOR_NORMAL_REENTRY_REVIEW';$record['requires_external_review']=false;$record['updated_at_utc']=gmdate('c');$record['history']=$history;$registry['records'][$sandboxId]=$record;self::save($registry);return $record;
        }finally{self::releaseLock($token);}
    }

    /**
     * Periodic, provider-free internal recheck of retained relevant structure gaps.
     * It only refreshes Sandbox review metadata; it never writes the topic pool, taxonomy or articles.
     * @return array<string,mixed>
     */
    public static function refreshInternalStructureBacklog(bool $force=false): array {
        PSTE_Plugin::assertReady();$token=self::acquireLock();
        try{
            $store=self::stored();self::assertNoActiveJob($store);
            $last=(string)($store['last_internal_structure_recheck_at_utc']??'');
            if(!$force&&$last!==''&&strtotime($last)!==false&&time()-strtotime($last)<7*DAY_IN_SECONDS)return ['contract'=>'PSTE_SANDBOX_PERIODIC_RECHECK_V2_HEALTH','status'=>'NOT_DUE','checked'=>0,'changed'=>0,'failed'=>0,'provider_calls'=>0,'source_data_write_attempted'=>false,'production_handoff_attempted'=>false];
            $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_RECHECK_BASELINE_REQUIRED');
            $registry=PSTE_Article_Type_Registry::build($baseline);$inventory=PSTE_Snapshot::inventory();$checked=0;$changed=0;$failed=0;$failures=[];$now=gmdate('c');
            $store['last_internal_structure_recheck_attempt_at_utc']=$now;
            foreach((array)$store['records'] as $id=>$record){
                if(!is_array($record)||!in_array((string)($record['status']??''),['STRUCTURE_GAP','MATCHER_REVIEW','PROPOSAL_READY_FOR_REVIEW','REVIEW_REQUIRED'],true))continue;
                $decision=self::effectiveRelevanceStatus($record);if($decision!=='RELEVANT_FOR_PORTAL')continue;
                $checked++;$record['last_internal_structure_recheck_attempt_at_utc']=$now;
                try{
                    $source=self::sourceSummary((string)($record['pool_key']??''));
                    $external=is_array($record['external_relevance']??null)?(array)$record['external_relevance']:[];$external['status']='RELEVANT_FOR_PORTAL';$external['decision_source']=$record['relevance_adjudication']['decision_source']??($external['decision_source']??'STORED_RELEVANCE_EVIDENCE');
                    $proposal=PSTE_Sandbox_Internal_Planner::plan($record,$registry,$baseline,$external,(array)$source['payload'],$inventory);
                    $oldSha=(string)($record['internal_proposal_sha256']??'');$newSha=self::hash($proposal);if(!hash_equals($oldSha,$newSha))$changed++;
                    $history=array_values((array)($record['history']??[]));$history[]=self::event('PERIODIC_INTERNAL_STRUCTURE_RECHECK',(string)($proposal['status']??'REVIEW_REQUIRED'));
                    $record['internal_proposal']=$proposal;$record['internal_proposal_sha256']=$newSha;$record['status']=(string)($proposal['status']??'REVIEW_REQUIRED');$record['workflow_lane']=self::workflowLaneForStatus($record['status']);$record['updated_at_utc']=$now;$record['history']=$history;$record['last_internal_structure_recheck_at_utc']=$now;$record['structure_recheck_health']='PASS';$record['structure_recheck_error_code']='';
                }catch(Throwable $e){
                    $failed++;$code=self::safeCode($e->getMessage());$failures[]=['sandbox_id'=>(string)$id,'pool_key'=>(string)($record['pool_key']??''),'error_code'=>$code];
                    $history=array_values((array)($record['history']??[]));$history[]=self::event('PERIODIC_INTERNAL_STRUCTURE_RECHECK_FAILED',$code);
                    $record['structure_recheck_health']='FAIL';$record['structure_recheck_error_code']=$code;$record['structure_recheck_failure_count']=(int)($record['structure_recheck_failure_count']??0)+1;$record['updated_at_utc']=$now;$record['history']=$history;
                    // Keep the semantic/status lane intact so the retained keyword remains eligible for the next provider-free retry.
                }
                $store['records'][$id]=$record;
            }
            $report=['contract'=>'PSTE_SANDBOX_PERIODIC_RECHECK_V2_HEALTH','status'=>$failed===0?'PASS':'PARTIAL_FAILURE','checked'=>$checked,'changed'=>$changed,'failed'=>$failed,'failures'=>$failures,'provider_calls'=>0,'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,'production_handoff_attempted'=>false];
            $store['last_internal_structure_recheck_report']=$report;
            if($failed===0)$store['last_internal_structure_recheck_at_utc']=$now;
            self::save($store);
            return $report;
        }finally{self::releaseLock($token);}
    }

    /** Return only fully proven automatic reentry envelopes; read-only. @return list<array<string,mixed>> */
    public static function automaticReentryEnvelopes(int $limit=25): array {
        $store=self::stored();$out=[];$limit=max(1,min(100,$limit));
        foreach((array)$store['records'] as $id=>$record){if(count($out)>=$limit)break;if(!is_array($record)||(string)($record['status']??'')!=='AUTO_REENTRY_ELIGIBLE')continue;
            $proposal=(array)($record['internal_proposal']??[]);$envelope=(array)($proposal['reentry_proposal']??[]);if(($envelope['contract']??'')!=='PSTE_SANDBOX_REENTRY_ENVELOPE_V1'||($envelope['status']??'')!=='AUTO_REENTRY_ELIGIBLE')continue;
            $sha=self::hash($envelope);$out[]=['sandbox_id'=>(string)$id,'envelope'=>$envelope,'envelope_sha256'=>$sha];}
        return $out;
    }

    /** Mark the result after the separate normal reentry coordinator has written SEO metadata. */
    public static function markNormalReentryApplied(string $sandboxId,string $expectedEnvelopeSha256,array $result): array {
        $token=self::acquireLock();try{$store=self::stored();$record=is_array($store['records'][$sandboxId]??null)?(array)$store['records'][$sandboxId]:[];if(!$record)throw new RuntimeException('PSTE_SANDBOX_REENTRY_RECORD_NOT_FOUND');$proposal=(array)($record['internal_proposal']??[]);$envelope=(array)($proposal['reentry_proposal']??[]);$sha=self::hash($envelope);if(!preg_match('/^[a-f0-9]{64}$/',$expectedEnvelopeSha256)||!hash_equals($sha,$expectedEnvelopeSha256))throw new RuntimeException('PSTE_SANDBOX_REENTRY_ENVELOPE_HASH_MISMATCH');if(($result['status']??'')!=='PASS')throw new RuntimeException('PSTE_SANDBOX_REENTRY_RESULT_NOT_PASS');$history=array_values((array)($record['history']??[]));$history[]=self::event('NORMAL_REENTRY_APPLIED','PSTE_SANDBOX_RETURNED_TO_NORMAL_METADATA_PIPELINE');$record['status']='REENTERED_TO_NORMAL_PIPELINE';$record['workflow_lane']='REENTERED_TO_NORMAL_PIPELINE';$record['reentry_result']=$result;$record['reentry_result_sha256']=self::hash($result);$record['updated_at_utc']=gmdate('c');$record['history']=$history;try{$record['source']=self::sourceSummary((string)$record['pool_key']);$record['source_refresh_error_code']='';}catch(Throwable $e){$record['source_refresh_error_code']=self::safeCode($e->getMessage());$record['history'][]=self::event('REENTRY_SOURCE_REFRESH_FAILED',$record['source_refresh_error_code']);}$store['records'][$sandboxId]=$record;self::save($store);return $record;}finally{self::releaseLock($token);}
    }

    /** Retain failed automatic reentries for review; never retry-blindly inside this method. */
    public static function markNormalReentryFailed(string $sandboxId,string $expectedEnvelopeSha256,string $code): array {
        $token=self::acquireLock();try{$store=self::stored();$record=is_array($store['records'][$sandboxId]??null)?(array)$store['records'][$sandboxId]:[];if(!$record)throw new RuntimeException('PSTE_SANDBOX_REENTRY_RECORD_NOT_FOUND');$proposal=(array)($record['internal_proposal']??[]);$envelope=(array)($proposal['reentry_proposal']??[]);$sha=self::hash($envelope);if(!preg_match('/^[a-f0-9]{64}$/',$expectedEnvelopeSha256)||!hash_equals($sha,$expectedEnvelopeSha256))throw new RuntimeException('PSTE_SANDBOX_REENTRY_ENVELOPE_HASH_MISMATCH');$history=array_values((array)($record['history']??[]));$history[]=self::event('NORMAL_REENTRY_FAILED',$code);$record['status']='REENTRY_REVIEW_REQUIRED';$record['workflow_lane']='REENTRY_REVIEW_REQUIRED';$record['reentry_error_code']=$code;$record['updated_at_utc']=gmdate('c');$record['history']=$history;$store['records'][$sandboxId]=$record;self::save($store);return $record;}finally{self::releaseLock($token);}
    }

    /** @return string */
    public static function effectiveRelevanceStatusForAdmin(array $record): string {
        $adjudication=(array)($record['relevance_adjudication']??[]);$decision=(string)($adjudication['decision']??'');$source=(string)($adjudication['decision_source']??'');
        if(in_array($decision,['RELEVANT_FOR_PORTAL','NOT_RELEVANT_FOR_PORTAL'],true)){
            if(in_array($source,['EXPLICIT_ADMIN_REVIEW','EXPLICIT_ADMIN_REVIEW_REVISION'],true)){$revision=max(1,(int)($adjudication['revision']??1));return $decision.' (manuell bestätigt · Revision '.$revision.')';}
            return $decision.' (bestehende Relevanzbestätigung)';
        }
        $effective=self::effectiveRelevanceStatus($record);if($effective==='CONFLICT')return 'WIDERSPRÜCHLICHE RELEVANZEVIDENZ';
        return $effective!==''?$effective:'NOCH NICHT GEPRÜFT';
    }

    /** Current decision authority without destroying historical external evidence. */
    private static function effectiveRelevanceStatus(array $record): string {
        $adjudication=(array)($record['relevance_adjudication']??[]);$decision=(string)($adjudication['decision']??'');
        if(in_array($decision,['RELEVANT_FOR_PORTAL','NOT_RELEVANT_FOR_PORTAL'],true))return $decision;
        if(!empty($record['relevance_conflict']['requires_review']))return 'CONFLICT';
        $proof=(array)($record['current_relevance_proof']??[]);$proofStatus=(string)($proof['status']??'');
        if(in_array($proofStatus,['RELEVANT_FOR_PORTAL','NOT_RELEVANT_FOR_PORTAL'],true))return $proofStatus;
        return (string)($record['external_relevance']['status']??'');
    }

    public static function cancelUnknownJob(string $jobUuid): array {
        $token=self::acquireLock();try{$registry=self::stored();$job=(array)($registry['job']??[]);if(!hash_equals((string)($job['job_uuid']??''),$jobUuid)||(string)($job['status']??'')!=='OUTCOME_UNKNOWN')throw new RuntimeException('PSTE_SANDBOX_UNKNOWN_JOB_REQUIRED');PSTE_Budget_Reservations::release($jobUuid);$job['reservation_active']=false;$job['status']='CANCELLED_AFTER_PROVIDER_ACCOUNT_CHECK';$job['updated_at_utc']=gmdate('c');$registry['job']=$job;self::save($registry);return self::publicJob($job);}finally{self::releaseLock($token);}
    }

    /** @return array<string,mixed> */
    public static function summary(?array $registry=null): array {
        $r=$registry??self::stored();$counts=['TOTAL_RETAINED'=>0,'MATCHER_REVIEW'=>0,'STRUCTURE_GAP'=>0,'EXTERNAL_RELEVANCE_REVIEW'=>0,'SOURCE_STALE_REVIEW_REQUIRED'=>0,'PENDING_EXTERNAL_RELEVANCE'=>0,'DEFERRED_PROVIDER_ERROR'=>0,'PROVIDER_TASK_REVIEW_REQUIRED'=>0,'RELEVANT_FOR_PORTAL'=>0,'NOT_RELEVANT_FOR_PORTAL'=>0,'RETAINED_NOT_RELEVANT'=>0,'UNCERTAIN_REVIEW'=>0,'PROPOSAL_READY_FOR_REVIEW'=>0,'MULTIPLE_FAMILIES_REVIEW'=>0,'REVIEW_REQUIRED'=>0,'TRUE_NO_MATCH'=>0,'STALE_REVIEW_REQUIRED'=>0,'READY_FOR_NORMAL_REENTRY_REVIEW'=>0,'AUTO_REENTRY_ELIGIBLE'=>0,'REENTERED_TO_NORMAL_PIPELINE'=>0,'REENTRY_REVIEW_REQUIRED'=>0,'RELEVANCE_CONFLICT_REVIEW_REQUIRED'=>0,'EXPLICIT_RELEVANCE_REVIEWED'=>0,'HISTORICAL'=>0];
        foreach((array)$r['records'] as $record){$counts['TOTAL_RETAINED']++;$lane=(string)($record['workflow_lane']??'');if(isset($counts[$lane]))$counts[$lane]++;$status=(string)($record['status']??'');if(isset($counts[$status])&&$status!==$lane)$counts[$status]++;if($status==='RETAINED_HISTORICAL_NOT_IN_CURRENT_BLOCKED_SET')$counts['HISTORICAL']++;$ad=(string)($record['relevance_adjudication']['decision']??'');$effective=self::effectiveRelevanceStatus((array)$record);if($ad!=='')$counts['EXPLICIT_RELEVANCE_REVIEWED']++;if($effective==='RELEVANT_FOR_PORTAL')$counts['RELEVANT_FOR_PORTAL']++;elseif($effective==='NOT_RELEVANT_FOR_PORTAL')$counts['NOT_RELEVANT_FOR_PORTAL']++;}
        return ['contract'=>'PSTE_SEMANTIC_REVIEW_SANDBOX_SUMMARY_V1','counts'=>$counts,'binding'=>(array)($r['binding']??[]),'last_sync_at_utc'=>(string)($r['last_sync_at_utc']??''),'job'=>is_array($r['job']??null)?self::publicJob((array)$r['job']):null,'registry_sha256'=>(string)($r['sha256']??''),'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false];
    }

    /** @return list<array<string,mixed>> */
    public static function recordsForAdmin(?array $registry=null): array {
        $r=$registry??self::stored();$rows=[];
        foreach((array)($r['records']??[]) as $record){
            if(!is_array($record))continue;
            try{$rows[]=PSTE_Sandbox_Record_Contract::adminView($record);}
            catch(Throwable $e){
                // Never invent a local hint for an unverified legacy record. Before the explicit current
                // migration it remains visible only as migration-required evidence, not as a false statement.
                $rows[]=['contract'=>PSTE_Sandbox_Record_Contract::ADMIN_VIEW_CONTRACT,'sandbox_id'=>(string)($record['sandbox_id']??''),'query'=>(string)($record['query']??''),'search_volume'=>$record['search_volume']??null,'local_matched_terms'=>[],'portal_relevance'=>[],'exclusion_evidence'=>[],'nearest_rejected_families'=>[],'external_relevance'=>$record['external_relevance']??null,'relevance_adjudication'=>$record['relevance_adjudication']??null,'current_relevance_proof'=>$record['current_relevance_proof']??null,'relevance_conflict'=>$record['relevance_conflict']??null,'internal_proposal'=>$record['internal_proposal']??null,'internal_proposal_sha256'=>(string)($record['internal_proposal_sha256']??''),'status'=>(string)($record['status']??''),'workflow_lane'=>(string)($record['workflow_lane']??''),'dataflow_status'=>'MIGRATION_REQUIRED','dataflow_error_code'=>self::safeCode($e->getMessage()),'write_attempted'=>false,'production_handoff_attempted'=>false];
            }
        }
        $order=['RELEVANCE_CONFLICT_REVIEW_REQUIRED'=>0,'EXTERNAL_RELEVANCE_REVIEW'=>1,'SOURCE_STALE_REVIEW_REQUIRED'=>2,'MATCHER_REVIEW'=>3,'STRUCTURE_GAP'=>4];usort($rows,static fn($a,$b)=>[($order[(string)($a['workflow_lane']??'')]??9),(string)($a['query']??'')]<=>[($order[(string)($b['workflow_lane']??'')]??9),(string)($b['query']??'')]);return $rows;
    }

    /** @return array<string,mixed> */
    public static function exportPayload(): array {$r=self::stored();$r['exported_at_utc']=gmdate('c');$r['export_statement']='SANDBOX_ONLY_NO_SOURCE_OR_ARTICLE_WRITES_NO_PRODUCTION_HANDOFF';$r['stored_registry_sha256']=(string)($r['sha256']??'');unset($r['export_sha256']);$r['export_sha256']=self::hash($r);return $r;}

    /** @return array<string,mixed> */
    private static function sourceSummary(string $poolKey): array {
        global $wpdb;$table=PSTE_Repository::table('topic_pool');$row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE pool_key=%s",$poolKey),ARRAY_A);if(trim((string)($wpdb->last_error??''))!=='')throw new RuntimeException('PSTE_SANDBOX_SOURCE_DB_READ_FAILED');if(!is_array($row))throw new RuntimeException('PSTE_SANDBOX_SOURCE_POOL_ROW_MISSING');$stringRow=self::stringifyRow($row);$payload=json_decode((string)($row['payload_json']??''),true);if(!is_array($payload))throw new RuntimeException('PSTE_SANDBOX_SOURCE_PAYLOAD_INVALID');
        $vol=null;foreach([['metrics','search_volume'],['query_record','search_volume']] as $path){$v=$payload[$path[0]][$path[1]]??null;if(is_numeric($v)){$vol=(float)$v;break;}}if($vol===null&&is_numeric($payload['search_volume']??null))$vol=(float)$payload['search_volume'];
        $sources=[];foreach((array)($payload['evidence']??[]) as $ev){$s=trim((string)($ev['source']??$ev['provider']??''));if($s!=='')$sources[]=$s;}foreach((array)($payload['source_names']??[]) as $s)if(trim((string)$s)!=='')$sources[]=trim((string)$s);if(trim((string)($payload['query_record']['source']??''))!=='')$sources[]=trim((string)$payload['query_record']['source']);
        $sourceIdentity=['pool_key'=>$poolKey,'raw_user_question'=>$payload['raw_user_question']??null,'primary_longtail_query'=>$payload['primary_longtail_query']??null,'canonical_query'=>$payload['canonical_query']??null,'query_record'=>$payload['query_record']??null,'query_aliases'=>$payload['query_aliases']??null,'evidence'=>$payload['evidence']??null];
        return ['row_sha256'=>self::hash($stringRow),'payload_sha256'=>self::hash($payload),'source_identity_sha256'=>self::hash($sourceIdentity),'search_volume'=>$vol,'source_names'=>array_values(array_unique($sources)),'payload'=>$payload];
    }

    /** Return the exact analysis identity owned by the normal path and prove it still belongs to the persisted source payload. */
    private static function normalPathBoundQuery(array $normalPath,array $payload,string $scope): string {
        $pathQuery=PSTE_Normal_Metadata_Path::canonicalInputQuery((string)($normalPath['raw_query']??''));
        $pathSha=(string)($normalPath['raw_query_sha256']??'');
        if($pathQuery===''||!preg_match('/^[a-f0-9]{64}$/',$pathSha)||!hash_equals(hash('sha256',$pathQuery),$pathSha))throw new RuntimeException('PSTE_SANDBOX_NORMAL_PATH_IDENTITY_INVALID');
        if(PSTE_Normal_Metadata_Path::payloadMatchesNormalPath($payload,$normalPath))return $pathQuery;
        throw new RuntimeException('PSTE_SANDBOX_SOURCE_NORMAL_PATH_IDENTITY_MISMATCH');
    }

    private static function workflowLaneForStatus(string $status): string {
        if(in_array($status,['PENDING_EXTERNAL_RELEVANCE','UNCERTAIN_REVIEW','STALE_REVIEW_REQUIRED'],true))return 'EXTERNAL_RELEVANCE_REVIEW';
        if($status==='DEFERRED_PROVIDER_ERROR')return 'PROVIDER_RETRY_DEFERRED';
        if($status==='PROVIDER_TASK_REVIEW_REQUIRED')return 'PROVIDER_TASK_REVIEW_REQUIRED';
        if($status==='STRUCTURE_GAP')return 'STRUCTURE_GAP';
        if($status==='RETAINED_NOT_RELEVANT')return 'RETAINED_NOT_RELEVANT';
        if($status==='READY_FOR_NORMAL_REENTRY_REVIEW')return 'READY_FOR_NORMAL_REENTRY_REVIEW';
        if($status==='AUTO_REENTRY_ELIGIBLE')return 'AUTO_REENTRY_ELIGIBLE';
        if($status==='REENTERED_TO_NORMAL_PIPELINE')return 'REENTERED_TO_NORMAL_PIPELINE';
        if($status==='REENTRY_REVIEW_REQUIRED')return 'REENTRY_REVIEW_REQUIRED';
        if(in_array($status,['MATCHER_REVIEW','PROPOSAL_READY_FOR_REVIEW','MULTIPLE_FAMILIES_REVIEW','REVIEW_REQUIRED'],true))return 'INTERNAL_SEMANTIC_REVIEW';
        return $status!==''?$status:'REVIEW_REQUIRED';
    }

    /** Convert a V71 task-scoped PAUSED_ERROR into a retained deferred candidate without blind provider resend. */
    private static function resumeLegacyCandidatePauseWithoutResend(array &$registry,array &$job): bool {
        $last=(string)($job['last_error']??'');if($last===''||!str_starts_with($last,'PSTE_PROVIDER_TASK_ERROR_'))return false;
        $policy=PSTE_Sandbox_Provider_Error_Policy::classifyMachineCode($last,[]);if(!str_starts_with((string)$policy['scope'],'CANDIDATE_'))return false;
        self::assertCurrentBinding($registry);$queue=array_values((array)($job['queue']??[]));$cursor=(int)($job['cursor']??0);if($cursor>=count($queue))return false;
        $id=(string)$queue[$cursor];$record=is_array($registry['records'][$id]??null)?(array)$registry['records'][$id]:[];if(!$record)throw new RuntimeException('PSTE_SANDBOX_QUEUE_RECORD_MISSING');self::assertRecordCurrent($record);
        $providerCode=(int)($policy['provider_status_code']??0);$e=new PSTE_Provider_Exception($last,['provider_status_code'=>$providerCode,'legacy_v71_pause_migrated'=>true,'response_cost'=>0.0]);
        self::applyCandidateProviderFailure($record,$e,$policy,'PRIMARY');$history=array_values((array)($record['history']??[]));$history[]=self::event('LEGACY_PAUSED_TASK_ERROR_MIGRATED_WITHOUT_RESEND','PSTE_SANDBOX_V71_TASK_ERROR_NOT_BLINDLY_RESENT');$record['history']=$history;$registry['records'][$id]=$record;
        self::advanceJobAfterCandidate($job,$cursor,false,$last);$job['status']='RUNNING';$job['last_error']='';$job['updated_at_utc']=gmdate('c');self::normalizeLegacyJobBudgetEnvelope($job);$registry['job']=$job;if((int)$job['cursor']>=count((array)$job['queue']))self::completeJob($registry,$job);self::save($registry);return true;
    }

    /**
     * V71 jobs reserved only one nominal task cost per candidate although the client already allowed one safe retry.
     * On first V72 touch, shrink only the unprocessed queue tail to the worst-case retry-safe capacity.
     * Dropped tail records remain PENDING in the registry and are picked up by later jobs; nothing is deleted.
     */
    private static function normalizeLegacyJobBudgetEnvelope(array &$job): void {
        if((string)($job['provider_error_policy_version']??'')===PSTE_Sandbox_Provider_Error_Policy::CONTRACT)return;
        $queue=array_values((array)($job['queue']??[]));$cursor=max(0,(int)($job['cursor']??0));$remainingBudget=max(0.0,(float)($job['estimated_cost']??0.0)-(float)($job['actual_cost']??0.0));$unit=self::estimateWorstCaseBatchCost(1);$safeRemaining=$unit>0?(int)floor(($remainingBudget+1e-9)/$unit):0;$keep=min(count($queue),$cursor+max(0,$safeRemaining));
        if($keep<count($queue)){$dropped=count($queue)-$keep;$job['queue']=array_slice($queue,0,$keep);$job['total']=$keep;$job['remaining_open_after_batch']=(int)($job['remaining_open_after_batch']??0)+$dropped;$job['legacy_budget_tail_deferred_count']=$dropped;}
        $job['provider_error_policy_version']=PSTE_Sandbox_Provider_Error_Policy::CONTRACT;$job['updated_at_utc']=gmdate('c');
    }

    /** Apply a known task-scoped provider failure to one candidate only. */
    private static function applyCandidateProviderFailure(array &$record,PSTE_Provider_Exception $e,array $policy,string $queueMode): void {
        $details=$e->safeDetails();$machine=(string)$e->getMessage();$knownCost=PSTE_Sandbox_Provider_Error_Policy::knownCostUsd($details);$now=gmdate('c');
        $safe=[];foreach(['provider_status_code','provider_message','http_code','task_index','tasks_count','tasks_error','response_sha256','response_cost','retry_known_cost_usd','legacy_v71_pause_migrated'] as $k)if(array_key_exists($k,$details))$safe[$k]=$details[$k];
        $cycles=(int)($record['provider_error_retry_cycles']??0);$status=(string)($policy['candidate_status']??'PROVIDER_TASK_REVIEW_REQUIRED');
        if((string)$policy['scope']==='CANDIDATE_DEFER_RETRY'){$cycles++;if($cycles>=PSTE_Sandbox_Provider_Error_Policy::MAX_DEFERRED_RETRY_CYCLES||$queueMode==='DEFERRED_RETRY')$status='PROVIDER_TASK_REVIEW_REQUIRED';else $status='DEFERRED_PROVIDER_ERROR';}
        $error=['contract'=>'PSTE_SANDBOX_PROVIDER_ERROR_RECORD_V1','machine_code'=>$machine,'scope'=>(string)$policy['scope'],'provider_status_code'=>(int)($policy['provider_status_code']??0),'known_cost_usd'=>$knownCost,'retry_cycle'=>$cycles,'occurred_at_utc'=>$now,'safe_details'=>$safe];$error['error_sha256']=self::hash($error);
        $errorHistory=array_values((array)($record['provider_error_history']??[]));$errorHistory[]=$error;$record['provider_error_history']=$errorHistory;$record['provider_error']=$error;$record['provider_error_retry_cycles']=$cycles;
        $history=array_values((array)($record['history']??[]));$history[]=self::event('PROVIDER_TASK_ERROR_ISOLATED',$machine);
        $record['internal_proposal']=null;$record['internal_proposal_sha256']='';$record['internal_adjudication']=null;$record['relevance_adjudication']=null;$record['updated_at_utc']=$now;
        if((string)$policy['scope']==='CANDIDATE_NO_RESULTS'){
            $responseSha=(string)($safe['response_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$responseSha))$responseSha=self::hash(['query'=>(string)$record['query'],'provider_error'=>$error]);
            $record['external_relevance']=['contract'=>'PSTE_SANDBOX_EXTERNAL_PROVIDER_OUTCOME_V1','query'=>(string)$record['query'],'status'=>'UNCERTAIN_REVIEW','reason_codes'=>['PSTE_SANDBOX_PROVIDER_NO_SEARCH_RESULTS'],'environment'=>'production','evidence'=>[],'provider_error'=>$error,'response_sha256'=>$responseSha,'retrieved_at_utc'=>$now,'actual_cost_usd'=>$knownCost,'decision_scope'=>'EXTERNAL_PORTAL_RELEVANCE_ONLY','reviewable_external_evidence'=>true,'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false];
            $record['status']='UNCERTAIN_REVIEW';$record['workflow_lane']='EXTERNAL_RELEVANCE_REVIEW';$record['requires_external_review']=false;$history[]=self::event('EXTERNAL_RELEVANCE_UNCERTAIN_NO_RESULTS','PSTE_SANDBOX_PROVIDER_NO_SEARCH_RESULTS');
        }else{
            $record['external_relevance']=null;$record['status']=$status;$record['workflow_lane']=self::workflowLaneForStatus($status);$record['requires_external_review']=$status==='DEFERRED_PROVIDER_ERROR';
            $history[]=self::event($status==='DEFERRED_PROVIDER_ERROR'?'PROVIDER_RETRY_DEFERRED':'PROVIDER_TASK_REVIEW_REQUIRED',$machine);
        }
        $record['history']=$history;
    }

    private static function advanceJobAfterCandidate(array &$job,int $cursor,bool $success,string $taskErrorCode): void {
        $job['cursor']=$cursor+1;$job['progress']=$cursor+1;$job['last_error']='';$job['status']='RUNNING';$job['updated_at_utc']=gmdate('c');
        if($success){$job['consecutive_task_error_code']='';$job['consecutive_task_error_count']=0;$job['last_candidate_error']='';return;}
        $prev=(string)($job['consecutive_task_error_code']??'');$job['consecutive_task_error_code']=$taskErrorCode;$job['consecutive_task_error_count']=hash_equals($prev,$taskErrorCode)?((int)($job['consecutive_task_error_count']??0)+1):1;$job['last_candidate_error']=$taskErrorCode;
    }

    private static function consumeKnownJobCost(string $jobUuid,array &$job,float $cost): void {if($cost<=0)return;PSTE_Budget_Reservations::consume($jobUuid,$cost);$job['actual_cost']=round((float)($job['actual_cost']??0.0)+$cost,6);}

    /** Worst-case reservation includes the already-existing one safe retry per SERP task. */
    private static function estimateWorstCaseBatchCost(int $candidateCount): float {return PSTE_Cost_Guard::estimateSandboxSerpReview(max(0,$candidateCount)*2);}

    private static function assertNoActiveJob(array $registry): void {
        $job=(array)($registry['job']??[]);if(in_array((string)($job['status']??''),['RUNNING','PAUSED_ERROR','OUTCOME_UNKNOWN'],true))throw new RuntimeException('PSTE_SANDBOX_REVIEW_BLOCKED_WHILE_JOB_ACTIVE');
    }

    private static function assertCurrentBinding(array $sandbox): void {
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_BASELINE_REQUIRED');
        $state=PSTE_Snapshot::baselineStatus($baseline);if(($state['status']??'')!=='CURRENT')throw new RuntimeException('PSTE_SANDBOX_BASELINE_STALE');
        $registry=PSTE_Article_Type_Registry::build($baseline);if(empty($registry['registry_sha256']))throw new RuntimeException('PSTE_SANDBOX_REGISTRY_INVALID');
    }

    private static function assertRecordCurrent(array $record): void {
        if(!hash_equals(self::REVIEW_POLICY,(string)($record['review_policy_version']??'')))throw new RuntimeException('PSTE_SANDBOX_REVIEW_POLICY_STALE');
        if(!empty($record['binding_dependency_review_required']))throw new RuntimeException('PSTE_SANDBOX_BINDING_DEPENDENCY_REVIEW_REQUIRED');
        $binding=(array)($record['binding']??[]);
        // Technical mirror supplies only the current dependency binding; semantic fields remain legacy-authoritative.
        $sandboxId=(string)($record['sandbox_id']??'');
        if($sandboxId!==''&&class_exists('PSTE_Sandbox_Record_Store')&&PSTE_Sandbox_Record_Store::isComplete()){
            try{$mirror=PSTE_Sandbox_Record_Store::getRecord($sandboxId);if(is_array($mirror['binding']??null)){$binding=(array)$mirror['binding'];if(!empty($mirror['binding_dependency_review_required']))throw new RuntimeException('PSTE_SANDBOX_BINDING_DEPENDENCY_REVIEW_REQUIRED');}}catch(RuntimeException $e){throw $e;}
        }
        $source=self::sourceSummary((string)($record['pool_key']??''));$storedIdentity=(string)($record['source']['source_identity_sha256']??$binding['source_identity_sha256']??'');
        if($storedIdentity!==''&&!hash_equals($storedIdentity,(string)($source['source_identity_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_SOURCE_IDENTITY_STALE');
        $baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline))throw new RuntimeException('PSTE_SANDBOX_BASELINE_REQUIRED');$registry=PSTE_Article_Type_Registry::build($baseline);
        $reg=(string)($binding['registry_sha256']??'');if($reg!==''&&!hash_equals($reg,(string)($registry['registry_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_RECORD_REGISTRY_STALE');
        if((string)($binding['dependency_contract']??'')==='PSTE_SANDBOX_BINDING_DEPENDENCIES_V1'){
            if(!hash_equals((string)($binding['structure_sha256']??''),(string)($baseline['structure_sha256']??$baseline['structure_hash']??'')))throw new RuntimeException('PSTE_SANDBOX_RECORD_STRUCTURE_STALE');
            if(!hash_equals((string)($binding['protected_category_map_sha256']??''),(string)($baseline['protected_category_map_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_RECORD_CATEGORY_MAP_STALE');
            if(!empty($binding['planner_inventory_recheck_required']))throw new RuntimeException('PSTE_SANDBOX_PLANNER_INVENTORY_RECHECK_REQUIRED');
            return;
        }
        // Legacy compatibility before the explicit record-local migration only.
        $stable=(string)($binding['stable_baseline_identity_sha256']??'');if($stable!==''&&!hash_equals($stable,self::stableBaselineIdentitySha256($baseline)))throw new RuntimeException('PSTE_SANDBOX_RECORD_BASELINE_STALE');
    }

    /**
     * Bind the Sandbox to content identity, not to PSTE_SITE_BASELINE_V1's capture-instance hash.
     * baseline_sha256 includes captured_at_utc by design and therefore changes on every fresh
     * baseline capture even when the portal is byte/content-identical. Using it as a cross-capture
     * equality gate made every valid Dry-run -> Sandbox handoff fail closed for the wrong reason.
     * Currentness + the two registry hashes are the semantic safety gate; every Sandbox source row
     * is additionally read back and hash-compared before preservation/review.
     */
    private static function assertBinding(array $dry,array $baseline,array $registry): void {
        $state=PSTE_Snapshot::baselineStatus($baseline);if(($state['status']??'')!=='CURRENT')throw new RuntimeException('PSTE_SANDBOX_BASELINE_STALE');
        if(!hash_equals((string)($dry['registry_sha256']??''),(string)($registry['registry_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_REGISTRY_HASH_MISMATCH');
        // The Dry-run producer PSTE_Family_Reclassification_V2 hashes identity_v2 families
        // with its canonical recursive hash. PSTE_Article_Type_Registry also exposes a
        // family_identity_v2_registry_sha256 field, but that field is produced by a
        // different (top-level-only ordered) serialization and is therefore not the
        // authoritative binding hash for a Dry-run. Recompute the exact Dry-run identity
        // hash from the current registry instead of comparing two different hash contracts.
        if(!hash_equals((string)($dry['family_identity_v2_registry_sha256']??''),self::familyIdentityRegistrySha256($registry)))throw new RuntimeException('PSTE_SANDBOX_IDENTITY_REGISTRY_HASH_MISMATCH');
    }

    private static function familyIdentityRegistrySha256(array $registry): string {
        $identities=[];
        foreach((array)($registry['families']??[]) as $key=>$family)$identities[(string)$key]=(array)($family['identity_v2']??[]);
        ksort($identities,SORT_STRING);
        return self::hash($identities);
    }

    private static function stableBaselineIdentitySha256(array $baseline): string {return self::hash([
        'inventory_sha256'=>(string)($baseline['inventory_sha256']??''),
        'structure_sha256'=>(string)($baseline['structure_sha256']??$baseline['structure_hash']??''),
        'editorial_plan_sha256'=>(string)($baseline['editorial_plan_sha256']??''),
        'post_counts'=>(array)($baseline['post_counts']??[]),
        'category_count'=>(int)($baseline['category_count']??0),
        'leaf_category_count'=>(int)($baseline['leaf_category_count']??0),
        'protected_category_map_sha256'=>(string)($baseline['protected_category_map_sha256']??''),
    ]);}

    private static function isCandidateScopedFailure(Throwable $e): bool {
        $code=self::safeCode($e->getMessage());
        foreach([
            'PSTE_SANDBOX_SOURCE_POOL_ROW_MISSING','PSTE_SANDBOX_SOURCE_PAYLOAD_INVALID',
            'PSTE_SANDBOX_LIVE_ADMISSION_QUERY_MISSING','PSTE_SANDBOX_INTERNAL_ADMISSION_QUERY_MISSING',
            'PSTE_SANDBOX_INTERNAL_ADMISSION_RAW_MISMATCH','PSTE_SANDBOX_SOURCE_NORMAL_PATH_IDENTITY_MISMATCH'
        ] as $candidateCode)if(str_starts_with($code,$candidateCode))return true;
        return false;
    }

    /** Persist a visible retained Sandbox record without mutating the source topic row. @return array<string,mixed> */
    private static function retainAdmissionFailure(string $poolKey,array $normalPath,array $diagnostics,string $code): array {
        $token=self::acquireLock();
        try{
            $query=trim((string)($normalPath['raw_query']??$diagnostics['raw_query']??''));$querySha=$query!==''?hash('sha256',$query):hash('sha256','UNREADABLE|'.$poolKey);
            $baseline=self::admissionBaseline();$registry=self::admissionArticleRegistry($baseline);$dataflow=$query!==''?PSTE_Sandbox_Record_Contract::fromNormalPath($query,$normalPath,$baseline,$registry):[];
            $id=hash('sha256',$poolKey.'|'.$querySha);$store=self::stored();$old=is_array($store['records'][$id]??null)?(array)$store['records'][$id]:[];$receiptInfo=self::admissionReceiptFromDiagnostics($diagnostics);$receipt=(string)$receiptInfo['value'];$receiptField=(string)$receiptInfo['field'];if($receipt!==''&&hash_equals($receipt,(string)($old[$receiptField]??'')))return $old;$now=gmdate('c');$history=array_values((array)($old['history']??[]));$history[]=self::event('LIVE_ADMISSION_CANDIDATE_FAILURE_ISOLATED',$code);
            $record=array_merge($old,[
                'sandbox_id'=>$id,'query'=>$query,'query_sha256'=>$query!==''?hash('sha256',$query):'','pool_key'=>$poolKey,
                'original_classification'=>'LIVE_ADMISSION_CANDIDATE_FAILURE','original_reason_codes'=>array_values(array_unique(array_merge((array)($normalPath['reason_codes']??[]),(array)($diagnostics['reason_codes']??[]),[$code]))),
                'review_policy_version'=>self::REVIEW_POLICY,'workflow_lane'=>'ADMISSION_REVIEW_REQUIRED','requires_external_review'=>false,'admitted_to_external_review'=>false,
                'admission_reason_codes'=>['PSTE_SANDBOX_CANDIDATE_FAILURE_ISOLATED',$code],'status'=>'ADMISSION_REVIEW_REQUIRED',
                'portal_relevance'=>[],'exclusion_evidence'=>[],
                'normal_path_admission'=>$normalPath,'admission_failure'=>['error_code'=>$code,'scope'=>'CANDIDATE','retained_source_row'=>true,'retryable'=>true],
                'history'=>$history,'first_seen_at_utc'=>(string)($old['first_seen_at_utc']??$now),'updated_at_utc'=>$now,
                'source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,'production_handoff_attempted'=>false,
            ]);
            if($dataflow)$record=PSTE_Sandbox_Record_Contract::applyToRecord($record,$dataflow,$normalPath);
            if($receipt!=='')$record[$receiptField]=$receipt;
            $store['records'][$id]=$record;$store['last_live_admission_at_utc']=$now;self::save($store);return $record;
        }finally{self::releaseLock($token);}
    }

    /** @return array<string,mixed> */
    private static function markCandidateReviewFailure(array $record,string $code,string $status): array {
        $history=array_values((array)($record['history']??[]));$history[]=self::event('CANDIDATE_FAILURE_ISOLATED',$code);
        $record['status']=$status;$record['workflow_lane']=$status;$record['candidate_failure_error_code']=$code;$record['requires_external_review']=false;$record['history']=$history;$record['updated_at_utc']=gmdate('c');return $record;
    }

    /** Preserve prior review evidence when a binding or review-policy change forces re-evaluation. @return array<string,mixed> */
    private static function archivedReview(array $record,string $reason): array {return [
        'archived_at_utc'=>gmdate('c'),'reason'=>$reason,'status'=>(string)($record['status']??''),'review_policy_version'=>(string)($record['review_policy_version']??''),
        'binding'=>(array)($record['binding']??[]),'workflow_lane'=>(string)($record['workflow_lane']??''),'portal_relevance'=>$record['portal_relevance']??null,'exclusion_evidence'=>$record['exclusion_evidence']??null,'external_relevance'=>$record['external_relevance']??null,'relevance_adjudication'=>$record['relevance_adjudication']??null,'current_relevance_proof'=>$record['current_relevance_proof']??null,'relevance_conflict'=>$record['relevance_conflict']??null,'internal_proposal'=>$record['internal_proposal']??null,'internal_proposal_sha256'=>(string)($record['internal_proposal_sha256']??''),'internal_adjudication'=>$record['internal_adjudication']??null,'provider_error'=>$record['provider_error']??null,'provider_error_history'=>$record['provider_error_history']??[],'provider_error_retry_cycles'=>(int)($record['provider_error_retry_cycles']??0),
    ];}

    /**
     * Determine a budget-safe batch size without changing the user's configured budgets.
     * Remaining candidates stay pending and are never deleted or silently skipped.
     */
    private static function safeBatchCapacity(array $registry,array $settings,int $openCount): int {
        if($openCount<=0)return 0;$unit=self::estimateWorstCaseBatchCost(1);if($unit<=0)return 0;
        $runLimit=min((float)($settings['run_budget_usd']??0),(float)($settings['absolute_ceiling_usd']??0));
        $dayStart=strtotime(gmdate('Y-m-d 00:00:00'));$monthStart=strtotime(gmdate('Y-m-01 00:00:00'));$sandboxDay=0.0;$sandboxMonth=0.0;
        foreach((array)($registry['records']??[]) as $record){[$d,$m]=self::recordedProviderCostWindows((array)$record,$dayStart,$monthStart);$sandboxDay+=$d;$sandboxMonth+=$m;}
        $repoDay=PSTE_Repository::actualCostSince(gmdate('Y-m-d 00:00:00'));$repoMonth=PSTE_Repository::actualCostSince(gmdate('Y-m-01 00:00:00'));
        $remainingDay=max(0.0,(float)($settings['daily_budget_usd']??0)-$repoDay-$sandboxDay);$remainingMonth=max(0.0,(float)($settings['monthly_budget_usd']??0)-$repoMonth-$sandboxMonth);
        $available=min($runLimit,$remainingDay,$remainingMonth);if($available+1e-9<$unit)return 0;
        return max(0,min($openCount,(int)floor(($available+1e-9)/$unit)));
    }

    private static function assertSandboxHistoricalBudgets(array $registry,float $estimated,array $settings): void {
        $dayStart=strtotime(gmdate('Y-m-d 00:00:00'));$monthStart=strtotime(gmdate('Y-m-01 00:00:00'));$day=0.0;$month=0.0;
        foreach((array)$registry['records'] as $record){[$d,$m]=self::recordedProviderCostWindows((array)$record,$dayStart,$monthStart);$day+=$d;$month+=$m;}
        $repoDay=PSTE_Repository::actualCostSince(gmdate('Y-m-d 00:00:00'));$repoMonth=PSTE_Repository::actualCostSince(gmdate('Y-m-01 00:00:00'));
        if($repoDay+$day+$estimated>(float)$settings['daily_budget_usd'])throw new RuntimeException('PSTE_SANDBOX_DAILY_BUDGET_LIMIT_EXCEEDED');if($repoMonth+$month+$estimated>(float)$settings['monthly_budget_usd'])throw new RuntimeException('PSTE_SANDBOX_MONTHLY_BUDGET_LIMIT_EXCEEDED');
    }

    /** @return array{0:float,1:float} */
    private static function recordedProviderCostWindows(array $record,int $dayStart,int $monthStart): array {
        $day=0.0;$month=0.0;$ext=(array)($record['external_relevance']??[]);
        if((string)($ext['contract']??'')!=='PSTE_SANDBOX_EXTERNAL_PROVIDER_OUTCOME_V1'){$ts=strtotime((string)($ext['retrieved_at_utc']??''));$cost=max(0.0,(float)($ext['actual_cost_usd']??0.0));if($ts!==false&&$cost>0){if($ts>=$dayStart)$day+=$cost;if($ts>=$monthStart)$month+=$cost;}}
        foreach((array)($record['provider_error_history']??[]) as $error){$ts=strtotime((string)($error['occurred_at_utc']??''));$cost=max(0.0,(float)($error['known_cost_usd']??0.0));if($ts!==false&&$cost>0){if($ts>=$dayStart)$day+=$cost;if($ts>=$monthStart)$month+=$cost;}}
        return [round($day,6),round($month,6)];
    }

    private static function completeJob(array &$registry,array &$job): void {if(!empty($job['reservation_active'])){PSTE_Budget_Reservations::release((string)$job['job_uuid']);$job['reservation_active']=false;}$job['status']='COMPLETE';$job['cursor']=count((array)$job['queue']);$job['progress']=$job['cursor'];$job['updated_at_utc']=gmdate('c');$job['completed_at_utc']=gmdate('c');$registry['job']=$job;}
    private static function publicJob(array $job): array {return ['contract'=>self::JOB_CONTRACT,'job_uuid'=>(string)($job['job_uuid']??''),'status'=>(string)($job['status']??''),'queue_mode'=>(string)($job['queue_mode']??'PRIMARY'),'progress'=>(int)($job['progress']??0),'total'=>(int)($job['total']??0),'open_before_batch'=>(int)($job['open_before_batch']??$job['total']??0),'remaining_open_after_batch'=>(int)($job['remaining_open_after_batch']??0),'estimated_cost'=>(float)($job['estimated_cost']??0.0),'actual_cost'=>(float)($job['actual_cost']??0.0),'last_error'=>(string)($job['last_error']??''),'last_candidate_error'=>(string)($job['last_candidate_error']??''),'consecutive_task_error_count'=>(int)($job['consecutive_task_error_count']??0),'started_at_utc'=>(string)($job['started_at_utc']??''),'updated_at_utc'=>(string)($job['updated_at_utc']??'')];}

    private static function emptyRegistry(): array {return ['contract'=>self::CONTRACT,'version'=>'1.5.0','review_policy_version'=>self::REVIEW_POLICY,'records'=>[],'binding'=>[],'last_sync_at_utc'=>'','last_sync_counts'=>[],'job'=>null,'updated_at_utc'=>'','sha256'=>'','source_data_write_attempted'=>false,'published_or_draft_article_write_attempted'=>false,'production_handoff_attempted'=>false];}
    private static function assertRelevanceAdjudicationChain(array $record): void {
        $current=is_array($record['relevance_adjudication']??null)?(array)$record['relevance_adjudication']:[];
        $archive=array_values((array)($record['relevance_revision_archive']??[]));
        if(!$current){if($archive)throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_ARCHIVE_WITHOUT_CURRENT_DECISION');return;}
        $decision=(string)($current['decision']??'');if(!in_array($decision,['RELEVANT_FOR_PORTAL','NOT_RELEVANT_FOR_PORTAL'],true))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_ADJUDICATION_DECISION_INVALID');
        $decisionSource=(string)($current['decision_source']??'');$explicit=in_array($decisionSource,['EXPLICIT_ADMIN_REVIEW','EXPLICIT_ADMIN_REVIEW_REVISION'],true);
        if(!$explicit){if($archive)throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_ARCHIVE_FOR_NONEXPLICIT_DECISION');return;}
        $querySha=(string)($record['query_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$querySha)||!hash_equals($querySha,(string)($current['query_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_ADJUDICATION_QUERY_MISMATCH');
        $external=(array)($record['external_relevance']??[]);$responseSha=(string)($external['response_sha256']??'');if($responseSha!==''&&!hash_equals($responseSha,(string)($current['external_response_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_ADJUDICATION_EXTERNAL_RESPONSE_MISMATCH');
        $declared=(string)($current['decision_sha256']??'');$copy=$current;unset($copy['decision_sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(self::hash($copy),$declared))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_ADJUDICATION_HASH_INVALID');
        $expectedPrev='';foreach($archive as $idx=>$entry){
            if(!is_array($entry)||($entry['contract']??'')!=='PSTE_SANDBOX_RELEVANCE_REVISION_ARCHIVE_V1')throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_ARCHIVE_CONTRACT_INVALID');
            $archiveSha=(string)($entry['archive_sha256']??'');$entryCopy=$entry;unset($entryCopy['archive_sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$archiveSha)||!hash_equals(self::hash($entryCopy),$archiveSha))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_ARCHIVE_HASH_INVALID');
            $old=(array)($entry['previous_relevance_adjudication']??[]);$oldSha=(string)($old['decision_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$oldSha)||!hash_equals($oldSha,(string)($entry['previous_decision_sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_ARCHIVE_PREVIOUS_HASH_MISMATCH');
            $oldCopy=$old;unset($oldCopy['decision_sha256']);if(!hash_equals(self::hash($oldCopy),$oldSha))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_ARCHIVE_PREVIOUS_DECISION_INVALID');
            if($expectedPrev!==''&&!hash_equals($expectedPrev,$oldSha))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_CHAIN_GAP');
            $expectedPrev=(string)($entry['superseded_by_decision_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$expectedPrev))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_ARCHIVE_NEXT_HASH_INVALID');
        }
        if($archive&&!hash_equals($expectedPrev,$declared))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_CURRENT_HASH_MISMATCH');
        if($archive){$firstOld=(array)($archive[0]['previous_relevance_adjudication']??[]);$firstRevision=max(1,(int)($firstOld['revision']??1));$currentRevision=max(1,(int)($current['revision']??1));if($currentRevision!==$firstRevision+count($archive))throw new RuntimeException('PSTE_SANDBOX_RELEVANCE_REVISION_NUMBER_MISMATCH');}
    }

    private static function save(array $registry): void {if(self::$admissionBatchContext!==null){self::$admissionBatchContext['store']=$registry;self::$admissionBatchContext['dirty']=true;return;}self::persistRegistry($registry);}
    private static function persistRegistry(array $registry): void {
        if(class_exists('PSTE_Sandbox_Record_Store'))PSTE_Sandbox_Record_Store::assertLegacyWriteAllowed();
        $registry['contract']=self::CONTRACT;$registry['version']='1.5.0';$registry['review_policy_version']=self::REVIEW_POLICY;$registry['updated_at_utc']=gmdate('c');$registry['source_data_write_attempted']=false;$registry['published_or_draft_article_write_attempted']=false;$registry['production_handoff_attempted']=false;unset($registry['sha256']);$registry['sha256']=self::hash($registry);
        update_option(PSTE_OPTION_SEMANTIC_SANDBOX,$registry,false);$stored=get_option(PSTE_OPTION_SEMANTIC_SANDBOX,[]);if(!is_array($stored)||!hash_equals((string)$registry['sha256'],(string)($stored['sha256']??'')))throw new RuntimeException('PSTE_SANDBOX_READBACK_MISMATCH');self::assertRegistry($stored);self::$requestStoreCache=$stored;
        if(class_exists('PSTE_Sandbox_Record_Store'))PSTE_Sandbox_Record_Store::invalidateAfterLegacyWrite((string)$registry['sha256']);
    }
    /** @return array<string,mixed> */
    private static function admissionBaseline(): array {if(self::$admissionBatchContext!==null&&is_array(self::$admissionBatchContext['baseline']??null))return (array)self::$admissionBatchContext['baseline'];$baseline=get_option(PSTE_OPTION_SITE_BASELINE,[]);if(!is_array($baseline)||($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_SANDBOX_BASELINE_REQUIRED');return $baseline;}
    /** @return array<string,mixed> */
    private static function admissionArticleRegistry(array $baseline): array {if(self::$admissionBatchContext!==null&&is_array(self::$admissionBatchContext['article_registry']??null))return (array)self::$admissionBatchContext['article_registry'];return PSTE_Article_Type_Registry::build($baseline);}
    /** @return array<string,mixed> */
    private static function admissionInventory(): array {if(self::$admissionBatchContext!==null&&is_array(self::$admissionBatchContext['inventory']??null))return (array)self::$admissionBatchContext['inventory'];return PSTE_Snapshot::inventory();}
    private static function admissionReceiptFromDiagnostics(array $diagnostics): array {$migration=trim((string)($diagnostics['_migration_admission_receipt']??''));$research=trim((string)($diagnostics['_research_finalize_admission_receipt']??''));if($migration!==''&&$research!=='')throw new RuntimeException('PSTE_SANDBOX_ADMISSION_RECEIPT_DOMAIN_CONFLICT');if($migration!==''){if(!preg_match('/^[a-f0-9]{64}$/',$migration))throw new RuntimeException('PSTE_SANDBOX_MIGRATION_RECEIPT_INVALID');return ['field'=>'migration_admission_receipt','value'=>$migration];}if($research!==''){if(!preg_match('/^[a-f0-9]{64}$/',$research))throw new RuntimeException('PSTE_SANDBOX_RESEARCH_RECEIPT_INVALID');return ['field'=>'research_finalize_admission_receipt','value'=>$research];}return ['field'=>'','value'=>''];}
    private static function migrationReceiptFromDiagnostics(array $diagnostics): string {$r=self::admissionReceiptFromDiagnostics($diagnostics);return (string)($r['field']==='migration_admission_receipt'?$r['value']:'');}
    private static function assertRegistry(array $registry): void {
        if(($registry['contract']??'')!==self::CONTRACT||!in_array((string)($registry['version']??''),['1.0.0','1.1.0','1.2.0','1.3.0','1.4.0','1.5.0'],true))throw new RuntimeException('PSTE_SANDBOX_CONTRACT_INVALID');
        $declared=(string)($registry['sha256']??'');$copy=$registry;unset($copy['sha256']);
        if($declared!==''&&(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(self::hash($copy),$declared)))throw new RuntimeException('PSTE_SANDBOX_HASH_MISMATCH');
        // Legacy records remain readable until explicit migration. Any record already declaring
        // the current dataflow contract must be internally consistent at every persistence boundary.
        foreach((array)($registry['records']??[]) as $record){
            if(!is_array($record))continue;
            self::assertRelevanceAdjudicationChain($record);
            if(!array_key_exists('sandbox_dataflow',$record))continue;
            PSTE_Sandbox_Record_Contract::verifyStoredRecordSelfConsistency($record);
        }
    }
    private static function assertDryRun(array $dry): void {if(($dry['contract']??'')!==PSTE_Family_Reclassification_V2::DRY_RUN_CONTRACT)throw new RuntimeException('PSTE_SANDBOX_DRY_RUN_REQUIRED');$declared=(string)($dry['dry_run_sha256']??'');$copy=$dry;unset($copy['dry_run_sha256']);if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals(self::hash($copy),$declared))throw new RuntimeException('PSTE_SANDBOX_DRY_RUN_HASH_INVALID');}
    private static function event(string $event,string $reason): array {return ['at_utc'=>gmdate('c'),'event'=>$event,'reason_code'=>$reason];}
    private static function stringifyRow(array $row): array {$out=[];foreach($row as $k=>$v)$out[(string)$k]=(is_scalar($v)||$v===null)?($v===null?null:(string)$v):self::json($v);return $out;}
    private static function hash($v): string {return hash('sha256',self::json(self::canonicalize($v)));}
    private static function canonicalize($v){if(!is_array($v))return $v;if($v===[])return [];$list=array_keys($v)===range(0,count($v)-1);if($list)return array_map([self::class,'canonicalize'],$v);ksort($v,SORT_STRING);foreach($v as $k=>$x)$v[$k]=self::canonicalize($x);return $v;}
    private static function json($v): string {$j=function_exists('wp_json_encode')?wp_json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($v,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($j))throw new RuntimeException('PSTE_SANDBOX_JSON_FAILED');return $j;}
    /** @param array<int,string> $values */
    private static function firstNonEmpty(array $values): string {foreach($values as $value){$value=trim((string)$value);if($value!=='')return $value;}return '';}

    private static function safeCode(string $v): string {$v=strtoupper(trim($v));$v=(string)preg_replace('/[^A-Z0-9_:\-]+/','_',$v);return substr($v!==''?$v:'PSTE_SANDBOX_FAILED',0,160);}

    private static function acquireLock(): string {if(self::$admissionBatchContext!==null)return 'PSTE_BATCH_CONTEXT_LOCK';$token=hash('sha256',microtime(true).'|'.(function_exists('wp_generate_uuid4')?wp_generate_uuid4():uniqid('',true)));$payload=['token'=>$token,'expires_at'=>time()+self::LOCK_TTL];if(add_option(PSTE_OPTION_SEMANTIC_SANDBOX_LOCK,$payload,'',false))return $token;$old=get_option(PSTE_OPTION_SEMANTIC_SANDBOX_LOCK,[]);if(is_array($old)&&(int)($old['expires_at']??0)<time()){if(get_option(PSTE_OPTION_SEMANTIC_SANDBOX_LOCK,[])===$old)delete_option(PSTE_OPTION_SEMANTIC_SANDBOX_LOCK);if(add_option(PSTE_OPTION_SEMANTIC_SANDBOX_LOCK,$payload,'',false))return $token;}throw new RuntimeException('PSTE_SANDBOX_LOCKED');}
    private static function releaseLock(string $token): void {if($token==='PSTE_BATCH_CONTEXT_LOCK')return;$old=get_option(PSTE_OPTION_SEMANTIC_SANDBOX_LOCK,[]);if(is_array($old)&&hash_equals($token,(string)($old['token']??'')))delete_option(PSTE_OPTION_SEMANTIC_SANDBOX_LOCK);}
}
