<?php
if (!defined('ABSPATH')) { return; }

/**
 * Technical request-bounded staging and immutable family-sharded context index.
 * No article/content/title/design decision is implemented here.
 */
final class PSTE_Context_Index_Store {
    public const CONTRACT='PSTE_CONTEXT_INDEX_MANIFEST_V2_STAGED';
    private const SHARD_CONTRACT='PSTE_CONTEXT_INDEX_SHARD_V2';
    private const BUILD_CONTRACT='PSTE_CONTEXT_INDEX_BUILD_V2';
    private const TARGET_SHARD_BYTES=196608;      // ~192 KiB target.
    private const MAX_SINGLE_FAMILY_BYTES=1048576; // hard fail-closed family bound.
    private const MAX_INVENTORY_BYTES=8388608;     // 8 MiB raw JSON.
    private const MAX_PLAN_BYTES=33554432;         // 32 MiB raw JSON.
    private const MAX_REGISTRY_BYTES=8388608;      // 8 MiB raw JSON.

    /** @var array<string,array<string,mixed>> */ private static array $manifestCache=[];
    /** @var array<string,array<string,mixed>> */ private static array $shardCache=[];
    /** @var array<string,array<string,mixed>> */ private static array $stageCache=[];

    /** @return array<string,mixed> */
    public static function stageInventory(array $baseline,string $jobUuid): array {
        self::assertBaseline($baseline,$jobUuid);
        $snapshot=PSTE_Snapshot::inventory();
        self::assertBoundSnapshot($snapshot,'PSTE_INVENTORY_SNAPSHOT_V2',(string)($baseline['inventory_sha256']??''),'PSTE_CONTEXT_STAGE_INVENTORY');
        return self::writeStage(PSTE_OPTION_CONTEXT_STAGE_INVENTORY,$snapshot,self::MAX_INVENTORY_BYTES,$jobUuid,(string)($baseline['baseline_sha256']??''),'INVENTORY');
    }

    /** @return array<string,mixed> */
    public static function stagePlan(array $baseline,string $jobUuid): array {
        self::assertBaseline($baseline,$jobUuid);
        $snapshot=PSTE_Snapshot::editorialPlan();
        self::assertBoundSnapshot($snapshot,'PSTE_EDITORIAL_PLAN_SNAPSHOT_V1',(string)($baseline['editorial_plan_sha256']??'NOT_AVAILABLE'),'PSTE_CONTEXT_STAGE_PLAN');
        return self::writeStage(PSTE_OPTION_CONTEXT_STAGE_PLAN,$snapshot,self::MAX_PLAN_BYTES,$jobUuid,(string)($baseline['baseline_sha256']??''),'EDITORIAL_PLAN');
    }

    /** @return array<string,mixed> */
    public static function stageRegistry(array $baseline,string $jobUuid): array {
        self::assertBaseline($baseline,$jobUuid);
        $registry=PSTE_Article_Type_Registry::build($baseline);
        if(!is_array($registry)||trim((string)($registry['registry_sha256']??''))==='')throw new RuntimeException('PSTE_CONTEXT_STAGE_REGISTRY_INVALID');
        return self::writeStage(PSTE_OPTION_CONTEXT_STAGE_REGISTRY,$registry,self::MAX_REGISTRY_BYTES,$jobUuid,(string)($baseline['baseline_sha256']??''),'ARTICLE_TYPE_REGISTRY');
    }

    /** @return array<string,mixed> */
    public static function buildFromStages(array $baseline,array $job): array {
        $jobUuid=(string)($job['job_uuid']??'');self::assertBaseline($baseline,$jobUuid);
        self::cleanupPendingBuild();
        $previous=get_option(PSTE_OPTION_CONTEXT_INDEX_MANIFEST,[]);if(!is_array($previous))$previous=[];
        $inventory=self::loadStage((array)($job['inventory_stage_meta']??[]),PSTE_OPTION_CONTEXT_STAGE_INVENTORY,'INVENTORY',self::MAX_INVENTORY_BYTES);
        $plan=self::loadStage((array)($job['plan_stage_meta']??[]),PSTE_OPTION_CONTEXT_STAGE_PLAN,'EDITORIAL_PLAN',self::MAX_PLAN_BYTES);
        self::assertBoundSnapshot($inventory,'PSTE_INVENTORY_SNAPSHOT_V2',(string)($baseline['inventory_sha256']??''),'PSTE_CONTEXT_INDEX_INVENTORY');
        self::assertBoundSnapshot($plan,'PSTE_EDITORIAL_PLAN_SNAPSHOT_V1',(string)($baseline['editorial_plan_sha256']??'NOT_AVAILABLE'),'PSTE_CONTEXT_INDEX_PLAN');

        $planStatus=(string)($plan['status']??'AVAILABLE');
        $fullIndex=PSTE_Context_Evaluator::buildIndex($inventory,$plan);
        $families=[];
        foreach(['WORDPRESS','EDITORIAL_PLAN'] as $source){
            foreach((array)($fullIndex[$source]??[]) as $family=>$items){
                $family=(string)$family;if($family==='')continue;
                if(!isset($families[$family]))$families[$family]=['WORDPRESS'=>[],'EDITORIAL_PLAN'=>[]];
                $families[$family][$source]=array_values((array)$items);
            }
        }
        ksort($families,SORT_STRING);
        $shards=[];$current=[];$currentEstimate=0;
        foreach($families as $family=>$sources){
            $one=self::json(['contract'=>self::SHARD_CONTRACT,'families'=>[$family=>$sources]]);$oneBytes=strlen($one);
            if($oneBytes>self::MAX_SINGLE_FAMILY_BYTES)throw new RuntimeException('PSTE_CONTEXT_INDEX_FAMILY_OVERSIZE');
            if($current!==[]&&$currentEstimate+$oneBytes>self::TARGET_SHARD_BYTES){$shards[]=$current;$current=[];$currentEstimate=0;}
            $current[$family]=$sources;$currentEstimate+=$oneBytes;
        }
        if($current!==[]||$shards===[])$shards[]=$current;
        unset($fullIndex,$families,$plan);

        $generation=substr(hash('sha256',$jobUuid.'|'.(string)($baseline['baseline_sha256']??'')),0,20);
        $keys=[];foreach(array_keys($shards) as $i)$keys[]=PSTE_CONTEXT_INDEX_SHARD_PREFIX.$generation.'_'.str_pad((string)$i,4,'0',STR_PAD_LEFT);
        $pending=['contract'=>self::BUILD_CONTRACT,'job_uuid'=>$jobUuid,'keys'=>$keys,'created_at_utc'=>gmdate('c')];
        update_option(PSTE_OPTION_CONTEXT_INDEX_BUILD,$pending,false);
        $pendingRead=get_option(PSTE_OPTION_CONTEXT_INDEX_BUILD,[]);
        if(!is_array($pendingRead)||($pendingRead['contract']??'')!==self::BUILD_CONTRACT||(array)($pendingRead['keys']??[])!==$keys)throw new RuntimeException('PSTE_CONTEXT_INDEX_PENDING_STATE_NOT_PERSISTED');

        $shardMeta=[];$familyToShard=[];$totalBytes=0;
        foreach($shards as $i=>$familyMap){
            $key=$keys[$i];$raw=self::json(['contract'=>self::SHARD_CONTRACT,'families'=>$familyMap]);$hash=hash('sha256',$raw);$bytes=strlen($raw);
            update_option($key,$raw,false);$read=get_option($key,null);
            if(!is_string($read)||strlen($read)!==$bytes||!hash_equals($hash,hash('sha256',$read)))throw new RuntimeException('PSTE_CONTEXT_INDEX_SHARD_READBACK_MISMATCH');
            foreach(array_keys($familyMap) as $family)$familyToShard[(string)$family]=$i;
            $shardMeta[]=['index'=>$i,'option_key'=>$key,'sha256'=>$hash,'bytes'=>$bytes,'family_count'=>count($familyMap)];$totalBytes+=$bytes;
        }
        ksort($familyToShard,SORT_STRING);
        $manifest=[
            'contract'=>self::CONTRACT,'job_uuid'=>$jobUuid,'baseline_sha256'=>(string)($baseline['baseline_sha256']??''),
            'inventory_sha256'=>(string)($baseline['inventory_sha256']??''),'structure_sha256'=>(string)($baseline['structure_sha256']??''),'editorial_plan_sha256'=>(string)($baseline['editorial_plan_sha256']??'NOT_AVAILABLE'),
            'inventory_stage_meta'=>(array)($job['inventory_stage_meta']??[]),'registry_stage_meta'=>(array)($job['registry_stage_meta']??[]),
            'editorial_plan_status'=>$planStatus,'family_to_shard'=>$familyToShard,'shards'=>$shardMeta,
            'family_count'=>count($familyToShard),'shard_count'=>count($shardMeta),'total_json_bytes'=>$totalBytes,'created_at_utc'=>gmdate('c'),
        ];
        $manifest['manifest_sha256']=self::manifestHash($manifest);
        update_option(PSTE_OPTION_CONTEXT_INDEX_MANIFEST,$manifest,false);$stored=get_option(PSTE_OPTION_CONTEXT_INDEX_MANIFEST,[]);
        self::assertManifest($stored,['job_uuid'=>$jobUuid,'manifest_sha256'=>$manifest['manifest_sha256'],'baseline_sha256'=>(string)($baseline['baseline_sha256']??''),'inventory_sha256'=>(string)($baseline['inventory_sha256']??''),'structure_sha256'=>(string)($baseline['structure_sha256']??''),'editorial_plan_sha256'=>(string)($baseline['editorial_plan_sha256']??'NOT_AVAILABLE')]);
        self::deleteManifestShards($previous,$keys);delete_option(PSTE_OPTION_CONTEXT_INDEX_BUILD);delete_option(PSTE_OPTION_CONTEXT_STAGE_PLAN);
        self::$manifestCache=[];self::$shardCache=[];self::$stageCache=[];return $manifest;
    }

    /** @return array<string,mixed> */
    public static function runtimeBinding(array $job,array $baseline): array {
        $expected=['job_uuid'=>(string)($job['job_uuid']??''),'manifest_sha256'=>(string)($job['context_index_manifest_sha256']??''),'baseline_sha256'=>(string)($baseline['baseline_sha256']??''),'inventory_sha256'=>(string)($job['inventory_sha256']??''),'structure_sha256'=>(string)($job['structure_sha256']??''),'editorial_plan_sha256'=>(string)($job['editorial_plan_sha256']??'NOT_AVAILABLE')];
        $manifest=self::loadManifest($expected);
        return ['contract'=>'PSTE_CONTEXT_INDEX_RUNTIME_BINDING_V2','job_uuid'=>$expected['job_uuid'],'manifest_sha256'=>(string)$manifest['manifest_sha256'],'baseline_sha256'=>$expected['baseline_sha256'],'inventory_sha256'=>$expected['inventory_sha256'],'structure_sha256'=>$expected['structure_sha256'],'editorial_plan_sha256'=>$expected['editorial_plan_sha256'],'inventory_meta'=>['contract'=>'PSTE_INVENTORY_SNAPSHOT_V2','sha256'=>$expected['inventory_sha256'],'items'=>[]],'editorial_plan_meta'=>['contract'=>'PSTE_EDITORIAL_PLAN_SNAPSHOT_V1','status'=>(string)($manifest['editorial_plan_status']??'AVAILABLE'),'sha256'=>$expected['editorial_plan_sha256'],'items'=>[]]];
    }

    /** @return array{WORDPRESS:array<string,array>,EDITORIAL_PLAN:array<string,array>} */
    public static function familyIndex(array $binding,string $family): array {
        if(($binding['contract']??'')!=='PSTE_CONTEXT_INDEX_RUNTIME_BINDING_V2')throw new RuntimeException('PSTE_CONTEXT_INDEX_RUNTIME_BINDING_INVALID');
        $family=trim($family);if($family==='')return ['WORDPRESS'=>[],'EDITORIAL_PLAN'=>[]];
        $manifest=self::loadManifest(['job_uuid'=>(string)($binding['job_uuid']??''),'manifest_sha256'=>(string)($binding['manifest_sha256']??''),'baseline_sha256'=>(string)($binding['baseline_sha256']??''),'inventory_sha256'=>(string)($binding['inventory_sha256']??''),'structure_sha256'=>(string)($binding['structure_sha256']??''),'editorial_plan_sha256'=>(string)($binding['editorial_plan_sha256']??'NOT_AVAILABLE')]);
        $map=(array)($manifest['family_to_shard']??[]);if(!array_key_exists($family,$map))return ['WORDPRESS'=>[],'EDITORIAL_PLAN'=>[]];
        $idx=(int)$map[$family];$meta=null;foreach((array)($manifest['shards']??[]) as $row)if((int)($row['index']??-1)===$idx){$meta=(array)$row;break;}if(!$meta)throw new RuntimeException('PSTE_CONTEXT_INDEX_SHARD_META_MISSING');
        $cacheKey=(string)$manifest['manifest_sha256'].'|'.$idx;
        if(!isset(self::$shardCache[$cacheKey])){
            $raw=get_option((string)($meta['option_key']??''),null);if(!is_string($raw))throw new RuntimeException('PSTE_CONTEXT_INDEX_SHARD_MISSING');
            if((int)($meta['bytes']??-1)!==strlen($raw))throw new RuntimeException('PSTE_CONTEXT_INDEX_SHARD_LENGTH_MISMATCH');$declared=(string)($meta['sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals($declared,hash('sha256',$raw)))throw new RuntimeException('PSTE_CONTEXT_INDEX_SHARD_HASH_MISMATCH');
            $decoded=json_decode($raw,true);if(!is_array($decoded)||($decoded['contract']??'')!==self::SHARD_CONTRACT||!is_array($decoded['families']??null))throw new RuntimeException('PSTE_CONTEXT_INDEX_SHARD_JSON_INVALID');self::$shardCache[$cacheKey]=$decoded;
        }
        $sources=(array)(self::$shardCache[$cacheKey]['families'][$family]??[]);return ['WORDPRESS'=>[$family=>array_values((array)($sources['WORDPRESS']??[]))],'EDITORIAL_PLAN'=>[$family=>array_values((array)($sources['EDITORIAL_PLAN']??[]))]];
    }

    public static function inventorySnapshot(array $binding): array {
        $manifest=self::manifestForBinding($binding);return self::loadStage((array)($manifest['inventory_stage_meta']??[]),PSTE_OPTION_CONTEXT_STAGE_INVENTORY,'INVENTORY',self::MAX_INVENTORY_BYTES);
    }
    public static function registrySnapshot(array $binding): array {
        $manifest=self::manifestForBinding($binding);return self::loadStage((array)($manifest['registry_stage_meta']??[]),PSTE_OPTION_CONTEXT_STAGE_REGISTRY,'ARTICLE_TYPE_REGISTRY',self::MAX_REGISTRY_BYTES);
    }

    public static function cleanupLegacyBundle(): void {delete_option(PSTE_OPTION_CONTEXT_SNAPSHOT_BUNDLE);}
    public static function cleanupCompletedJobArtifacts(): void {
        $manifest=get_option(PSTE_OPTION_CONTEXT_INDEX_MANIFEST,[]);if(is_array($manifest))self::deleteManifestShards($manifest,[]);
        delete_option(PSTE_OPTION_CONTEXT_INDEX_MANIFEST);delete_option(PSTE_OPTION_CONTEXT_INDEX_BUILD);delete_option(PSTE_OPTION_CONTEXT_STAGE_INVENTORY);delete_option(PSTE_OPTION_CONTEXT_STAGE_PLAN);delete_option(PSTE_OPTION_CONTEXT_STAGE_REGISTRY);delete_option(PSTE_OPTION_CONTEXT_SNAPSHOT_BUNDLE);
        self::$manifestCache=[];self::$shardCache=[];self::$stageCache=[];
    }

    private static function manifestForBinding(array $binding): array {
        if(($binding['contract']??'')!=='PSTE_CONTEXT_INDEX_RUNTIME_BINDING_V2')throw new RuntimeException('PSTE_CONTEXT_INDEX_RUNTIME_BINDING_INVALID');
        return self::loadManifest(['job_uuid'=>(string)($binding['job_uuid']??''),'manifest_sha256'=>(string)($binding['manifest_sha256']??''),'baseline_sha256'=>(string)($binding['baseline_sha256']??''),'inventory_sha256'=>(string)($binding['inventory_sha256']??''),'structure_sha256'=>(string)($binding['structure_sha256']??''),'editorial_plan_sha256'=>(string)($binding['editorial_plan_sha256']??'NOT_AVAILABLE')]);
    }
    private static function assertBaseline(array $baseline,string $jobUuid): void {if(($baseline['contract']??'')!=='PSTE_SITE_BASELINE_V1')throw new RuntimeException('PSTE_CONTEXT_INDEX_BASELINE_REQUIRED');if(trim($jobUuid)==='')throw new RuntimeException('PSTE_CONTEXT_INDEX_JOB_UUID_REQUIRED');}
    private static function assertBoundSnapshot(array $snapshot,string $contract,string $expectedSha,string $prefix): void {
        if(($snapshot['contract']??'')!==$contract)throw new RuntimeException($prefix.'_CONTRACT_INVALID');$declared=(string)($snapshot['sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$declared))throw new RuntimeException($prefix.'_HASH_MISSING');$copy=$snapshot;unset($copy['sha256']);if(!hash_equals($declared,self::stableHash($copy)))throw new RuntimeException($prefix.'_PAYLOAD_HASH_MISMATCH');if($expectedSha!==''&&!hash_equals($expectedSha,$declared))throw new RuntimeException($prefix.'_BASELINE_HASH_MISMATCH');
    }
    private static function writeStage(string $key,array $value,int $maxBytes,string $jobUuid,string $baselineSha,string $kind): array {
        $raw=self::json($value);$bytes=strlen($raw);if($bytes>$maxBytes)throw new RuntimeException('PSTE_CONTEXT_STAGE_'.$kind.'_SIZE_LIMIT_EXCEEDED');$hash=hash('sha256',$raw);update_option($key,$raw,false);$read=get_option($key,null);if(!is_string($read)||strlen($read)!==$bytes||!hash_equals($hash,hash('sha256',$read)))throw new RuntimeException('PSTE_CONTEXT_STAGE_'.$kind.'_READBACK_MISMATCH');return ['contract'=>'PSTE_CONTEXT_STAGE_META_V1','kind'=>$kind,'job_uuid'=>$jobUuid,'baseline_sha256'=>$baselineSha,'raw_sha256'=>$hash,'bytes'=>$bytes];
    }
    private static function loadStage(array $meta,string $key,string $kind,int $maxBytes): array {
        if(($meta['contract']??'')!=='PSTE_CONTEXT_STAGE_META_V1'||($meta['kind']??'')!==$kind)throw new RuntimeException('PSTE_CONTEXT_STAGE_'.$kind.'_META_INVALID');$bytes=(int)($meta['bytes']??-1);if($bytes<0||$bytes>$maxBytes)throw new RuntimeException('PSTE_CONTEXT_STAGE_'.$kind.'_SIZE_INVALID');$cacheKey=$key.'|'.(string)($meta['raw_sha256']??'');if(isset(self::$stageCache[$cacheKey]))return self::$stageCache[$cacheKey];$raw=get_option($key,null);if(!is_string($raw))throw new RuntimeException('PSTE_CONTEXT_STAGE_'.$kind.'_MISSING');if(strlen($raw)!==$bytes)throw new RuntimeException('PSTE_CONTEXT_STAGE_'.$kind.'_LENGTH_MISMATCH');$declared=(string)($meta['raw_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals($declared,hash('sha256',$raw)))throw new RuntimeException('PSTE_CONTEXT_STAGE_'.$kind.'_HASH_MISMATCH');$decoded=json_decode($raw,true);if(!is_array($decoded))throw new RuntimeException('PSTE_CONTEXT_STAGE_'.$kind.'_JSON_INVALID');self::$stageCache[$cacheKey]=$decoded;return $decoded;
    }
    private static function loadManifest(array $expected): array {$cacheKey=(string)($expected['manifest_sha256']??'');if($cacheKey!==''&&isset(self::$manifestCache[$cacheKey]))return self::$manifestCache[$cacheKey];$manifest=get_option(PSTE_OPTION_CONTEXT_INDEX_MANIFEST,[]);self::assertManifest($manifest,$expected);self::$manifestCache[(string)$manifest['manifest_sha256']]=$manifest;return $manifest;}
    private static function assertManifest($manifest,array $expected): void {if(!is_array($manifest)||($manifest['contract']??'')!==self::CONTRACT)throw new RuntimeException('PSTE_CONTEXT_INDEX_MANIFEST_MISSING');$declared=(string)($manifest['manifest_sha256']??'');if(!preg_match('/^[a-f0-9]{64}$/',$declared)||!hash_equals($declared,self::manifestHash($manifest)))throw new RuntimeException('PSTE_CONTEXT_INDEX_MANIFEST_HASH_MISMATCH');foreach(['job_uuid','baseline_sha256','inventory_sha256','structure_sha256','editorial_plan_sha256'] as $field){$want=(string)($expected[$field]??'');if($want===''||!hash_equals($want,(string)($manifest[$field]??'')))throw new RuntimeException('PSTE_CONTEXT_INDEX_MANIFEST_BINDING_MISMATCH_'.$field);}if(($expected['manifest_sha256']??'')!==''&&!hash_equals((string)$expected['manifest_sha256'],$declared))throw new RuntimeException('PSTE_CONTEXT_INDEX_JOB_MANIFEST_MISMATCH');if((int)($manifest['shard_count']??-1)!==count((array)($manifest['shards']??[])))throw new RuntimeException('PSTE_CONTEXT_INDEX_SHARD_COUNT_MISMATCH');if((int)($manifest['family_count']??-1)!==count((array)($manifest['family_to_shard']??[])))throw new RuntimeException('PSTE_CONTEXT_INDEX_FAMILY_COUNT_MISMATCH');}
    private static function cleanupPendingBuild(): void {$pending=get_option(PSTE_OPTION_CONTEXT_INDEX_BUILD,[]);if(!is_array($pending)||($pending['contract']??'')!==self::BUILD_CONTRACT)return;foreach((array)($pending['keys']??[]) as $key){$key=(string)$key;if(str_starts_with($key,PSTE_CONTEXT_INDEX_SHARD_PREFIX))delete_option($key);}delete_option(PSTE_OPTION_CONTEXT_INDEX_BUILD);}
    private static function deleteManifestShards(array $manifest,array $keepKeys=[]): void {$keep=array_fill_keys(array_map('strval',$keepKeys),true);if(($manifest['contract']??'')!==self::CONTRACT)return;foreach((array)($manifest['shards']??[]) as $row){$key=(string)($row['option_key']??'');if($key!==''&&str_starts_with($key,PSTE_CONTEXT_INDEX_SHARD_PREFIX)&&!isset($keep[$key]))delete_option($key);}}
    private static function manifestHash(array $manifest): string {$copy=$manifest;unset($copy['manifest_sha256']);return self::stableHash($copy);}private static function stableHash($value): string{return hash('sha256',self::json(self::canonicalize($value)));}private static function canonicalize($value){if(!is_array($value))return $value;if($value===[])return [];$list=array_keys($value)===range(0,count($value)-1);if($list)return array_map([self::class,'canonicalize'],$value);ksort($value,SORT_STRING);foreach($value as $k=>$v)$value[$k]=self::canonicalize($v);return $value;}private static function json($value): string{$json=function_exists('wp_json_encode')?wp_json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION):json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION);if(!is_string($json))throw new RuntimeException('PSTE_CONTEXT_INDEX_JSON_FAILED');return $json;}
}
