# PSTE 0.46.0 – Journal signed canonical-plan activation

- Aktiviert ausschließlich die bereits vorhandene `Pferdewissen & Grundlagen`-Journalroute für den nun signierten kanonischen PPM-Plan (`pferdewissen-grundlagen`).
- Reihenfolge unverändert: bestehende Produktfamilienauflösung zuerst, Journal nur nach Family-Miss.
- Normal Metadata Path, Domain-Risk-/Titel-/Dubletten-/Kannibalisierungsprüfungen und Sandbox-Reentry unverändert.
- Keine Artikelproduktion, kein direkter Sandbox-Write, keine WordPress-Term-ID wird geraten oder hardcodiert.
