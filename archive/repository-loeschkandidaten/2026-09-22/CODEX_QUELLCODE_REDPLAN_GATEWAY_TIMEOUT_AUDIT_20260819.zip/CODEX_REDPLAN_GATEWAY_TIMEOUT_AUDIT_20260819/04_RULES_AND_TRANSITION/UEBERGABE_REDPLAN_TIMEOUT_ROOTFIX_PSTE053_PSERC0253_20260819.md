# ÜBERGABE – SEO-REDAKTIONSPLAN TIMEOUT ROOTFIX – 19.08.2026

## Verbindlicher Ausgangspunkt
- PSTE 0.52.0: Portalabgleich live **COMPLETE** mit 562/562 Themen und 549/549 Sandbox-Records.
- Beim anschließenden Öffnen von **SEO Redaktionsplan** trat live erneut der bereits historisch dokumentierte Timeout auf.
- Der alte Step-12-Fix `PSTE_Repository::allCandidates()` / Topic-Pool `1125 -> 3 Queries` ist im aktuellen PSTE weiterhin vorhanden. Er wurde nicht regressiert.

## Neu isolierte Ursache
Der Redaktionsplan-Ladeweg besitzt zusätzlich zum bereits reparierten Topic-Pool zwei weitere synchrone N+1-Lesepfade:
1. `PSTE_Snapshot::inventory()` las je WordPress-Beitrag Kategorien plus zwei PPM-Identitätsmetafelder einzeln.
2. `PSERC_Existing_Content_Reader::snapshot()` las je WordPress-Beitrag die Kategorien einzeln.

Im 42-Post-Paritätsharness ergeben diese beiden Pfade zusammen 170 logische Reads. Der neue Bulk-Read-Weg benötigt bei semantisch identischem Ergebnis 5 Reads. Es wird nichts geschrieben.

## Releasekandidat
- PSTE **0.53.0** – ausschließlich Bulk-Read in `class-pste-snapshot.php` + Versionsdatei/Changelog.
- PSERC **0.25.3** – ausschließlich Bulk-Kategorielesen in `class-pserc-existing-content-reader.php` + Versions-/Package-Binding/Changelog.
- PPM **6.7.9 unverändert**; keine Installation erforderlich.

## Regel 1
Nicht verändert wurden Titelboss, Titelregeln, Artikeltypentscheidungen, Kategorieentscheidungen, Plan-Slots, Exact Five, Prompts, Recherchelogik, Inhalte, HTML, Design, Qualität, Publish-Regeln oder PPM-Produktion.

Die angesprochene Beratung-Titelvariation ist ausdrücklich **nicht** Bestandteil dieses technischen Rootfixes. Sie bleibt ein separater redaktioneller Block nach technischem Live-PASS.

## Keyword-/Datenintegrität
- Realer 562er Themenbestand: semantischer Hash unverändert `0248aacc9b5857a8b3d4a81672f17f397d03fb14649f9fde109d945a5ef15723`.
- Realer 549er Sandbox-Bestand: logischer Registry-Hash vor/nach identisch `b2bdaf888588137bbe49cbaa35a5875f97b7e11a6a2151e986de35724d571933`.
- Die neuen Änderungen enthalten **keinen** Keyword-/Topic-/Relations-/Sandbox-Migrations- oder Schreibpfad.

## Golden Masters
Der neue PSERC-Fresh-Unpack erzeugt für die beiden bestehenden Journal-Piloten exakt denselben Exact-Five-Metadatenbatch wie Schritt 11:
`c83c75e3d51f6c12bc9d9ccdb59f83b5dc33d025d31cf44eb2ace09ef5929cea`.

Bestehende Artikel-HTML-Goldhashes bleiben unverändert gebunden:
- Wie alt werden Pferde?: `7b32dce9aae301fd3bac9c8146ea760e49455423537efd9c513da305979e3aa7`
- Können Pferde schwimmen?: `7caa414e51b639a522fe11e9abc998ab7c38c798559a02a2a9b5143119554de5`

## Lokale/Fresh-Unpack-Prüfung
PASS:
- PSTE Source/Fresh: 198/198 Dateien identisch.
- PSERC Source/Fresh: 91/91 Dateien identisch.
- PSTE PHP 70/70, JSON 51/51.
- PSERC PHP 31/31, JSON 13/13.
- realer 562er Topic-Pool: 1125 -> 3, semantisch identisch.
- realer 549er Sandbox-/Binding-/Negativpfad unverändert PASS.
- PSTE 0.52-Regressionssuite gegen 0.53-Fresh-Unpack PASS.
- PSERC Normalisierung und kompletter 21-Kandidaten-Compile geschäftssemantisch identisch zu 0.25.2.
- Journal-Goldbatch exakt identisch.
- PSERC Package Integrity PASS; Capability-/Binding-Vertrag unverändert.
- PPM 6.7.9 aktive Step-12-Suite erneut 136/136 PASS.

## Zwingender Liveweg
1. PSTE 0.53.0 installieren.
2. PSERC 0.25.3 installieren.
3. **Keinen** Gesamtbestand neu abgleichen. **Keine** Sandbox erneut starten.
4. SEO Redaktionsplan einmal öffnen.
5. Erst wenn diese Seite live normal lädt, ist der Redaktionsplan-Ladeweg LIVE PASS.
6. Vor Artikelproduktion weiterhin Exact-Five/Workflowzustand prüfen; kein automatisches Publish.

Status vor Installation: **PASS_LOCAL_RELEASE_CANDIDATE / LIVE_REDPLAN_NOCH_NICHT_VERIFIZIERT**.
