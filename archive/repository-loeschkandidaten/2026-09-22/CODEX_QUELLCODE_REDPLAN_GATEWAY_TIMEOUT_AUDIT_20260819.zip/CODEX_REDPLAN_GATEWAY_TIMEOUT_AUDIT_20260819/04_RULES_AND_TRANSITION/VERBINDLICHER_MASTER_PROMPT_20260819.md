# VERBINDLICHER MASTER-PROMPT

Arbeite diesen Auftrag **vollständig in einem zusammenhängenden Arbeitsblock bis zum belastbaren Endergebnis** ab.

Keine Zwischenmeldungen. Keine Mini-Fixes. Keine Plugin-Serie. Keine symptomatischen Reparaturen. Keine eigenen fachlichen Entscheidungen.

## 1. OBERSTE AUTORITÄT

Maßgeblich sind ausschließlich:

1. die aktuelle Masterdatei,
2. die vollständigen Übergabeprotokolle,
3. die vorhandenen Fehlerkataloge und Prüfberichte,
4. die beiden Codex-Root-Cause-/Architekturprüfungen,
5. die vorhandenen Quellstände und Golden-Master-Belege,
6. dieser Auftrag.

Widersprechen sich ältere Zwischenstände mit einem später belegten Stand, muss der Widerspruch zuerst nachvollziehbar aufgelöst werden.

**Nicht raten. Nicht aus Erinnerungen ergänzen. Nicht aufgrund vermeintlicher Plausibilität entscheiden.**

Ein unbekannter, nicht reproduzierter oder nicht vollständig geprüfter Zustand ist:

**BLOCKED**

---

# 2. REGEL 1 – ABSOLUTE SPERRE

Keine Änderung darf direkt oder indirekt Einfluss haben auf:

- Artikelinhalt,
- Wortlaut,
- Fakten,
- Struktur,
- HTML,
- Formatierung,
- Design,
- CSS,
- Bilder,
- Promptlogik,
- Recherchelogik,
- Titel,
- Titelentscheidung,
- Artikeltypentscheidung,
- Kategorieentscheidung,
- Planplatzentscheidung,
- Exact-Five-Entscheidung,
- Produktionslogik,
- Qualitätsregeln,
- Publish-Entscheidung,
- WordPress-Ausgabe,
- bestehende fachliche Semantik.

Änderungen sind ausschließlich in der technisch notwendigen Infrastruktur zulässig.

Sobald nicht zweifelsfrei nachgewiesen werden kann, dass eine Änderung fachlich neutral ist:

**BLOCKED.**

Bestehende geschützte Dateien und Golden-Master-Ausgaben müssen vor und nach dem Umbau byte-identisch bzw. nach ihrem bestehenden Vertrag semantisch identisch sein.

Es darf niemals eine bestehende fachliche Entscheidung durch eine neue eigene Entscheidung ersetzt werden.

---

# 3. KEYWORDS SIND UNVERLETZLICHER PRIMÄRBESTAND

Keywords, Longtails, Themen und ihre Beziehungen sind einer der wertvollsten Datenbestände des Systems.

Deshalb gilt zusätzlich als harte Regel:

**KEIN KEYWORD DARF DURCH DEN UMBAU VERLOREN GEHEN.**

Dies betrifft insbesondere:

- Keywords,
- Longtail-Keywords,
- Themen,
- Kandidaten,
- Fundstellen,
- Suchvolumina,
- Quellenbezüge,
- Kategorienzuordnungen,
- Familien-/Clusterzuordnungen,
- Statuswerte,
- Prioritäten,
- Konfliktinformationen,
- Relationsdaten,
- Sandbox-Evidence,
- Review-Historien,
- Provenance,
- IDs,
- Hash-Bindings,
- vorhandene Metadaten und Beziehungen.

Ohne ausdrücklichen bestehenden Mastervertrag darf kein Datensatz:

- gelöscht,
- verworfen,
- überschrieben,
- zusammengeführt,
- dedupliziert,
- umbenannt,
- normalisiert,
- neu klassifiziert,
- einer anderen Kategorie zugeordnet,
- in seinem Status verändert,
- von Relationen getrennt,
- oder stillschweigend neu erzeugt werden.

## Zwingende Keyword-Sicherung VOR jeder Migration

Vor dem ersten schreibenden Eingriff ist ein read-only Golden Inventory des vollständigen keywordbezogenen Bestands zu erzeugen.

Mindestens zu erfassen:

- Gesamtzahl aller Keywords,
- Gesamtzahl aller Longtails,
- Gesamtzahl aller Themen/Kandidaten,
- eindeutige IDs,
- exakter Rohwert jedes Keywords,
- zugehörige Beziehungen,
- Kategorien,
- Status,
- Quellen,
- Relationszahlen,
- Hashes der einzelnen Datensätze,
- Hash des vollständigen ID-Sets,
- Hash der vollständigen Relationship-Struktur,
- Hash des kanonischen Gesamtbestands.

Das Ausgangsinventar ist unveränderlich aufzubewahren.

## Zwingende Prüfung NACH jeder Migration

Nach jedem migrationsrelevanten Schritt müssen mindestens gelten:

- `keyword_count_before == keyword_count_after`
- `keyword_id_set_before == keyword_id_set_after`
- `keyword_value_hash_before == keyword_value_hash_after`
- `relationship_set_before == relationship_set_after`
- `relationship_hash_before == relationship_hash_after`
- keine verwaisten Datensätze,
- keine unbekannten neuen Datensätze,
- keine verlorenen Quellen,
- keine verlorenen Statusinformationen,
- keine verlorene Sandbox-/Review-Historie.

Jede Abweichung:

**BLOCKED + sofortiger Abbruch des Releasepfads.**

Keine automatische „Reparatur“ eines solchen Unterschieds.

---

# 4. AUSGANGSLAGE

Vor Einführung der Beitragsart **Journal** funktionierte der produktive Ablauf.

Journal selbst ist fachlich grundsätzlich funktionsfähig:

Die beiden bereits erzeugten Journal-Goldstandards haben den vorgesehenen Workflow erfolgreich durchlaufen.

Sie sind ab jetzt verbindliche Regression-Goldstandards und dürfen weder neu interpretiert noch inhaltlich verändert werden.

Die bisherige Prüfung zeigt gleichzeitig:

- Journal wurde an mehreren Stellen in PSTE, PSERC und PPM hart verdrahtet.
- Die eigentliche Live-Störung liegt im technischen PSTE-Context-/Snapshot-/Sandbox-Bereich.
- Angeblich request-begrenzte Requests führen weiterhin globale Arbeit aus.
- Die Sandbox wird monolithisch verarbeitet.
- Ein kleiner Sandbox-Batch kann trotzdem den kompletten Sandbox-Bestand lesen, prüfen, hashen und schreiben.
- globale `inventory_sha256`-/`post_counts`-Bindungen können fachlich unabhängige Artikeländerungen auf alle Sandbox-Records ausweiten.
- dadurch kann ein einzelner neuer Artikel oder eine neue Beitragsart unnötig große technische Revalidierungen auslösen.
- PSERC und PPM gehören nach aktuellem Beleg nicht zum fehlerhaften Sandbox-Persistenzpfad.

Der exakte PHP-/FPM-Grund des HTTP-500 darf ohne Serverbeleg **nicht erfunden** werden.

---

# 5. ZIEL

Das System soll wieder technisch stabil werden und anschließend so aufgebaut sein, dass neue Beitragsarten zukünftig **einfach, zentral und ohne tiefen Eingriff in mehrere Kernsysteme** integriert werden können.

Das muss in einem großen, kohärenten Architekturblock erfolgen.

Nicht Ziel ist:

- Journal fachlich neu zu entwickeln,
- Inhalte zu verändern,
- Prompts umzubauen,
- bestehende Entscheidungen neu zu treffen,
- Keywords neu zu bewerten,
- bestehende Themen neu zu klassifizieren.

---

# 6. PHASE A – VOLLSTÄNDIGE FORENSISCHE PRÜFUNG

Bevor Code verändert wird:

1. Alle vorhandenen Quellstände und Übergaben vollständig erfassen.
2. Pre-Journal → Journal → aktueller Live-/Kandidatenstand diffen.
3. Den tatsächlichen vollständigen Callgraph rekonstruieren:
   - Browser/AJAX,
   - Admin Boundary,
   - Job State,
   - Locks/Leases,
   - Snapshot,
   - Inventory,
   - Plan,
   - Registry,
   - Context,
   - Sandbox,
   - Repository,
   - Final Freshness,
   - Error/Shutdown.
4. Für jeden Request bestimmen:
   - Records gelesen,
   - Records geschrieben,
   - Bytes gelesen,
   - Bytes geschrieben,
   - Datenbankqueries,
   - globale Materialisierungen,
   - Hashoperationen,
   - Peak Memory,
   - Laufzeitkomplexität.
5. Alle globalen Invalidierungsabhängigkeiten dokumentieren.
6. Feststellen, welche davon wirklich fachlich notwendig sind.
7. Alle bestehenden Keyword-/Topic-/Relation-Stores vollständig inventarisieren.
8. Vor jedem Umbau Golden-Master-Hashes erstellen.

Erst danach darf die Zielimplementierung beginnen.

---

# 7. PHASE B – EIN ZUSAMMENHÄNGENDER TECHNISCHER REBUILD

Der Reparaturblock muss die **Ursache** beseitigen.

## Sandbox

Die monolithische Sandbox-Persistenz ist durch record-lokale, request-begrenzte Speicherung zu ersetzen.

Zielarchitektur beispielsweise:

- kleines Manifest,
- record-lokaler Store,
- kleiner technischer Index,
- stabile Record-ID,
- Record-Hash,
- Dependency-Fingerprints,
- Generation,
- Revision/CAS.

Ein normaler Sandbox-Request mit Batchgröße `B` darf maximal:

- `B` Indexrecords,
- `B` Sandboxrecords

lesen, verifizieren und schreiben.

Kein versteckter Full-Store-Read.

Kein Full-Store-Hash.

Kein Full-Store-Write.

Kein Full-Store-Readback.

## Abhängigkeiten

Globale Invalidierung über einen einzigen universellen Baseline-Hash beseitigen.

Stattdessen ausschließlich nachgewiesene komponentenspezifische Fingerprints verwenden, beispielsweise:

- `source_fp`
- `relevance_fp`
- `normal_path_fp`
- `planner_fp`
- relevante Structure-/Category-/Family-Komponenten
- separat gebundene Article-Type-Registrierung.

Eine Änderung darf nur diejenigen Records invalidieren, die von genau dieser Komponente tatsächlich abhängen.

Verbindliche Negativanforderung:

**+1 fachlich unabhängiger Draft darf nicht sämtliche Sandbox-Records invalidieren.**

Ebenso:

**+1 veröffentlichter unabhängiger Artikel darf nicht sämtliche Sandbox-Records invalidieren.**

Und:

**+1 additive Beitragsart darf bestehende Typen und unabhängige Sandbox-Records nicht global invalidieren.**

## Context / Snapshot

Auch Inventory, Plan, Registry, Context-Index und Final-Freshness müssen tatsächlich request-begrenzt sein.

„Einmal pro Stage“ gilt ausdrücklich **nicht** als request-begrenzt.

Verwende:

- Cursor/Keyset,
- Elementbudget,
- Bytebudget,
- Querybudget,
- Zeitbudget,
- inkrementelle Shards/Projektionen,
- atomare Manifest-Aktivierung,
- Readback-Verifikation.

Kein einzelner Request darf wieder den vollständigen Bestand materialisieren.

## Jobsteuerung

Ein expliziter versionierter Zustandsautomat ist erforderlich mit:

- `job_uuid`
- `generation`
- Lease/Fencing Token
- Ablaufzeit
- Cursor
- Phase
- Readback Receipt
- deterministischem Resume.

Doppelklick, Reload, Cron und paralleles AJAX dürfen niemals zwei konkurrierende Worker erzeugen.

Legacy-Zustände dürfen nur kontrolliert adoptiert werden.

Unbekannte Zustände:

**BLOCKED.**

## Fatal-/Transportdiagnose

Technische Shutdown-Diagnostik einbauen.

Erlaubt sind ausschließlich technische Daten wie:

- Job-ID,
- Phase,
- Tick,
- Peak Memory,
- elapsed time,
- letzte technische DB-Operation,
- Error-Type,
- gehashte Fehlermeldung/Korrelation.

Keine Artikeltexte.

Keine Keywords im Log.

Keine Prompts.

Keine fachlichen Payloads.

---

# 8. MIGRATION MUSS VERLUSTFREI SEIN

Der bestehende Sandbox-/Keyword-/Topic-Bestand darf niemals einfach ersetzt oder gelöscht werden.

Migration:

1. Legacy-Quelle read-only einfrieren.
2. Hash und Recordzahl sichern.
3. Zielstruktur erstellen.
4. Recordweise kopieren.
5. Jede Kopie lokal hashen und readback-verifizieren.
6. Cursor + Receipt atomar speichern.
7. Crash an jedem möglichen Punkt simulieren.
8. Wiederaufnahme muss idempotent zum identischen Ergebnis führen.
9. Erst nach vollständiger Gleichheit neue Generation aktivieren.
10. Legacy-Quelle in diesem Release **nicht löschen**.
11. Rollback muss lesbar bleiben.

Wichtig:

Wenn die einmalige notwendige Legacy-Decodierung aufgrund realer Servergrenzen nicht sicher ausführbar ist:

**BLOCKED.**

Keine Tricks, kein stilles Partial-Loading behaupten, wenn WordPress technisch die ganze Option laden muss.

---

# 9. BEITRAGSART-ARCHITEKTUR FÜR DIE ZUKUNFT

Erst nachdem der technische PSTE-Rebuild vollständig PASS ist, darf im selben Gesamtauftrag die Erweiterungsarchitektur umgesetzt werden.

Ziel:

eine zentrale, signierte, versionierte Beitragsart-Schnittstelle, z. B.

`ARTICLE_TYPE_EXTENSION_MANIFEST`

Diese soll nur deklarieren, was der bestehende Master bereits vorgibt, z. B.:

- technische Identität,
- zulässige Capabilities,
- bestehende Kategorie-Capability,
- Handoff-Schema,
- vorhandene Validator-Capabilities,
- benötigte Slots.

Keine neue fachliche Entscheidungslogik.

PSTE, PSERC und PPM sollen dieses eine kanonische Manifest konsumieren, statt Typnamen an zahlreichen Stellen hart zu verdrahten.

Aber:

Diese Refaktorierung darf bestehende Artikeltypen in keiner Weise verändern.

Vor Freigabe muss für jeden bestehenden Typ bewiesen werden:

- gleicher PSTE-Handoff,
- gleicher PSERC-Release,
- gleicher PPM-Input,
- gleicher Draft,
- gleicher Readback,
- gleiche Artikelbytes,
- gleiche fachliche Entscheidung.

Bei der geringsten Abweichung:

**BLOCKED.**

---

# 10. ZWINGENDE POSITIV-/NEGATIV-TESTMATRIX

JEDER einzelne Änderungsschritt ist nicht nur isoliert, sondern gegen den **gesamten Workflow** zu prüfen.

Nach **jeder** Codeänderung:

1. betroffene Unit-/Contract-Tests,
2. Positivtest,
3. Negativtest,
4. Keyword-Unversehrtheit,
5. Regel-1-Diff,
6. kompletter Workflow-Regressionslauf.

Am Ende mindestens:

### Datenbestand

- kompletter realer Themenbestand,
- kompletter Keywordbestand,
- kompletter Longtailbestand,
- alle Relationsdaten,
- realistische maximale Sandbox-Menge,
- history-/archive-reicher Bestand.

### Sandbox

- leer,
- 1 Record,
- Batchgrenze,
- 100 Records,
- realer Maximalbestand,
- unverändert,
- genau 1 geänderter Record,
- korrupter Record,
- fehlender Record,
- falscher Hash,
- falsche Generation,
- stale Dependency,
- irrelevanter neuer Draft,
- relevanter neuer Draft,
- Publish,
- Journal-Registrierung,
- unabhängige neue Beitragsart.

### Job/Concurrency

- kein Job,
- alter Job,
- BLOCKED Job,
- mid-flight,
- Lock ohne Job,
- Job ohne Lock,
- abgelaufene Lease,
- aktive Lease,
- Reload,
- Doppelklick,
- AJAX + Cron,
- Crash vor Write,
- Crash nach Write,
- Resume.

### Datenbank/Transport

- Read Failure,
- Write Failure,
- Partial Failure,
- stale Object Cache,
- Exception,
- ungültiges JSON,
- Warning-Ausgabe,
- Timeout-Simulation,
- Memory-/Fatal-Simulation.

### Regel 1 / Produktion

Für alle bestehenden Beitragsarten einschließlich:

- FAQ,
- Beratung,
- Vergleich,
- Pflege,
- Journal.

Kompletter Workflow:

`Supervisor`
→ `Start Gate`
→ `Topic/Category/Article-Type/Plan-Slot Binding`
→ `Title Authority`
→ `Exact Five`
→ `Research`
→ `Provenance`
→ `Language/Structure/Facts/Links/Quality`
→ `Signed Release`
→ `PPM`
→ `WordPress Draft`
→ `Readback Hash`

Positiv und negativ.

Manipulation von:

- Kategorie,
- Artikeltyp,
- Titel,
- Planplatz,
- Payload,
- Signatur,
- Handoff,
- Status

muss weiterhin genau am vorgesehenen Gate zu:

**BLOCKED**

führen.

Publish-Eskalation muss hart abgewiesen werden.

---

# 11. DIE ZWEI JOURNAL-ARTIKEL SIND GOLDSTANDARD

Die beiden bereits erfolgreich erzeugten Journal-Artikel sind unveränderliche Regression-Goldstandards.

Keine Neuerstellung als Ersatzbeweis.

Keine neue Interpretation.

Keine Textänderung.

Keine Designänderung.

Es muss nachgewiesen werden, dass der neue technische Stack für dieselben fachlichen Inputs exakt dieselben geschützten Outputs erzeugt.

Dasselbe gilt für Golden-Master-Beispiele aller bestehenden Nicht-Journal-Typen.

---

# 12. PERFORMANCE-BEWEIS

„Funktioniert lokal“ reicht nicht.

Für jeden relevanten Request messen und dokumentieren:

- Anzahl DB-Queries,
- Anzahl Records gelesen,
- Anzahl Records geschrieben,
- Anzahl Records verifiziert,
- Bytes gelesen,
- Bytes geschrieben,
- Peak Memory,
- Laufzeit,
- Provider Calls,
- verbotene Writes.

Harte Invariante:

Ein `B`-Record-Batch darf nicht durch versteckte globale Arbeit wieder `O(N)` werden.

---

# 13. BUILD-SPERRE

Keine Installationsdatei erzeugen, solange nicht:

- alle Pflichtdaten vorhanden sind,
- die reale Migration geprüft ist,
- Keywordbestand vollständig identisch ist,
- Relationbestand vollständig identisch ist,
- sämtliche Positivtests PASS sind,
- sämtliche Negativtests PASS sind,
- kompletter Workflow PASS ist,
- Regel 1 PASS ist,
- alle geschützten Dateien/Outputs identisch sind,
- alle Golden Masters PASS sind.

Ein Teil-PASS ist **kein Release-PASS**.

Ein unbekannter Zustand ist **BLOCKED**.

---

# 14. FRESH-UNPACK-PFLICHT

Wenn Source vollständig PASS ist:

1. genau **einen** Installationskandidaten bauen,
2. ZIP neu und sauber entpacken,
3. Source↔Fresh-Unpack vollständig hashen,
4. komplette Testmatrix **erneut gegen den Fresh-Unpack** ausführen,
5. vollständigen Workflow erneut positiv und negativ prüfen,
6. Keyword- und Relationsinventar erneut vergleichen.

Erst dann darf ein Installer ausgegeben werden.

---

# 15. LIVE-GRENZE

Lokaler PASS darf niemals als Live-PASS bezeichnet werden.

Nach Installation:

- nur der zuvor definierte technische Liveweg,
- keine spontanen Reparaturklicks,
- kein automatisches Publish,
- keine neue Artikelproduktion vor technischem COMPLETE,
- korrelierte technische Messwerte prüfen,
- anschließend vollständigen Readback durchführen.

Erst danach:

**LIVE E2E PASS**

---

# 16. AUSGABE

Während der Bearbeitung:

**keine Zwischenmeldungen.**

Melde dich erst wieder, wenn entweder:

### A. VOLLSTÄNDIG PASS

Dann liefere nur:

1. eine kurze klare Zusammenfassung der tatsächlich gefundenen Ursachen,
2. exakt was technisch geändert wurde,
3. Nachweis, dass Regel 1 eingehalten wurde,
4. Nachweis der Keyword-/Relations-Unversehrtheit,
5. vollständiges Positiv-/Negativ-Ergebnis,
6. klare Aussage, was gegenüber dem vorherigen Stand verändert wurde,
7. ob Installation erforderlich ist,
8. **nur die Dateien, die ich tatsächlich verwenden/installieren muss**.

Keine zusätzlichen Prüfbericht-Downloads, solange ich sie nicht ausdrücklich verlange.

### B. BLOCKED

Dann liefere:

1. den exakt belegten Blocker,
2. warum ohne diesen Beleg keine sichere Fortsetzung möglich ist,
3. **genau die eine konkrete Information oder Datei**, die von mir noch benötigt wird.

Keine neue Plugin-Version.

Keine Behelfslösung.

Keine Symptombehandlung.

---

# 17. ENDZIEL

Der Abschluss ist erst erreicht, wenn gleichzeitig gilt:

**PSTE technisch stabil + Sandbox wirklich request-begrenzt + Context/Snapshot wirklich request-begrenzt + vollständiger Keyword-/Relationsbestand verlustfrei + Journal-Goldstandards unverändert + alle bisherigen Beitragsarten unverändert + PSERC/PPM fachlich unverändert + Gesamtworkflow positiv/negativ PASS + Regel 1 PASS + zukünftige Beitragsarten zentral und ohne erneute Cross-Core-Bastelei integrierbar.**

Bis dahin gilt:

**NICHT FERTIG.**