# FEHLERKATALOG – JOURNAL / PORTALABGLEICH / RECOVERY BIS PSTE 0.52.0

## EK-01 – Unzulässiger Recovery-Rollback
**Fehler:** PSTE/PSERC/PPM wurden auf ältere bzw. hybride Stände zurückgesetzt, obwohl Journal bereits erfolgreich integriert war.
**Wirkung:** Architektur-/Vertragsregression statt Ursachenreparatur.
**Status:** VERWORFEN / NICHT WIEDERHOLEN.

## EK-02 – Gesamtbestand-Abgleich nach falschem Stack
**Fehler:** Abgleich wurde auf nicht korrekt gebundenem Recovery-Stack gestartet.
**Wirkung:** HTTP-500 / Context-AJAX-Fehler.
**Status:** HISTORISCH / NICHT WIEDERHOLEN.

## EK-03 – 0.49 Release-Binding-Mismatch
**Fehler:** Prüfung vermischte tatsächlich ausgelieferten 0.49-Installer mit einem anderen 0.49-Quellbranch.
**Wirkung:** Freigabe basierte nicht vollständig auf dem ausgelieferten Artefakt.
**Status:** ERKANNT / FREIGABEPRAXIS VERSCHÄRFT.

## EK-04 – 0.49 Legacy-Reentry nicht request-begrenzt
**Fehler:** Legacy-Reentry konnte im AJAX-Tick wieder schweren `start()`-Pfad auslösen.
**Status:** DURCH SPÄTERE ARCHITEKTUR ABGELÖST.

## EK-05 – Context-Batches mit versteckter globaler Arbeit
**Fehler:** Zeilenlimit begrenzte nicht zwingend Snapshot-/Index-/Baseline-Materialisierung.
**Status:** DURCH 0.50/0.51/0.52 ARCHITEKTURBLOCK BEARBEITET.

## EK-06 – Sandbox monolithisch trotz Batchgröße 3
**Fehler:** Jeder SANDBOX_BINDING_BATCH lud/verifizierte/kompaktierte den kompletten Sandbox-Store; Dirty Batch konnte kompletten Store hashen, schreiben, zurücklesen und erneut verifizieren.
**Status:** **BEHOBEN IN 0.51.0** durch record-lokale Persistenz/Index/Manifest.

## EK-07 – Globale Sandbox-Invalidierung durch Inventory/Post Counts
**Fehler:** `stable_baseline_identity_sha256` koppelte unabhängige Draft-/Publish-/Content-/Statusänderungen an alle Sandbox-Records.
**Status:** **BEHOBEN IN 0.51.0** durch komponenten-/record-lokale Abhängigkeiten.

## EK-08 – Fehlende reale 549er Fixture
**Fehler:** Frühere lokale Tests arbeiteten ohne realen history-reichen Sandbox-Bestand.
**Status:** **BEHOBEN** – realer Export vom 19.08.2026 liegt im Master und wurde als Golden Fixture genutzt.

## EK-09 – 0.51 finale Inventory-Drift fälschlich Hardblock
**Fehlercode:** `PSTE_CONTEXT_REFRESH_STALE_FINAL_INVENTORY`
**Fehler:** Nach erfolgreicher langer Sandbox-Verarbeitung wurde dynamischer read-only Inventory-Drift gegen Jobstart als globaler Hardblock behandelt.
**Status:** **BEHOBEN IN 0.52.0** durch begrenzten Dynamic Context Rebase; Structure-Drift bleibt BLOCKED.

## EK-10 – 0.51 AJAX-Frontend maskierte konkreten 400-Fehler
**Anzeige:** `PSTE_CONTEXT_AJAX_FAILED_HTTP_400`
**Fehler:** Browser zeigte generischen HTTP-400-Code statt des gespeicherten konkreten Jobfehlers.
**Status:** Diagnosepfad im 0.52-Adminblock berücksichtigt; kein fachlicher Workfloweingriff.

## EK-11 – Plugin-Serie / zu kleine Reparaturschritte
**Fehler:** Mehrere aufeinanderfolgende Versionen belasteten den Livebetrieb und den Nutzer unnötig.
**Verbindliche Folge:** Keine neue Version für Einzelsymptome. Erst vollständige Ursachenprüfung + Gesamtworkflow-Positiv/Negativtest + Fresh-Unpack.

## EK-12 – Beratungstitel weiterhin zu ähnlich
**Beispiele:** wiederkehrende Muster „passend auswählen“, „gezielt auswählen“, „nach wichtigen Kriterien auswählen“.
**Status:** **OFFEN.**
**Scope:** TITLE AUTHORITY vor der Textmaschine. Kein Sandbox-/Context-Thema. Keine Textmaschinen-/Inhaltsänderung ohne separate, vollständige Regel-/Workflowprüfung.
