# ARBEITSPROTOKOLL – RECOVERY 18./19.08.2026

## Ausgangslage
Vor Journal lief der Produktionsworkflow. Zwei Journal-Artikel wurden anschließend erfolgreich als Goldstandards erstellt. Danach traten Architektur-/Runtimefehler im Portalabgleich/Redaktionsplan auf.

## Fehlpfade / Erkenntnisse
1. Ein falscher Recovery-Rollback auf ältere/hybride PSTE-/PSERC-/PPM-Stände war nicht zulässig und wurde verworfen.
2. Der anschließende Gesamtbestand-Abgleich reproduzierte HTTP-500/INVALID-JSON-Probleme.
3. 0.49 enthielt einen Release-Binding-/Quellbranch-Mismatch in der Prüfung; deshalb war die frühere Freigabe nicht belastbar.
4. 0.50 beseitigte mehrere globale Context-Probleme, aber die reale Sandbox blieb intern monolithisch.
5. Codex-Analyse A und B bestätigten unabhängig:
   - SANDBOX_BINDING_BATCH begrenzte nur Kandidatenentscheidungen, nicht den vollständigen Store-Read/Hash/Write;
   - globale `inventory_sha256` / `post_counts`-Bindung konnte unabhängige Änderungen global invalidieren;
   - PSERC/PPM lagen nicht im fehlerhaften Persistenzpfad.
6. Realer Sandbox-Export mit 549 Records wurde gesichert.
7. 0.51 baute die Sandbox record-lokal/request-begrenzt um.
8. Live 0.51: Migration 549/549 und Sandbox 549/549 liefen durch; danach finaler technischer Inventory-Block.
9. 0.52 korrigierte ausschließlich diese finale dynamische Context-Rebase-Grenze.
10. Live 0.52: **COMPLETE**.

## Datenintegrität
Golden-Bestand und Hashes siehe 0.52-QA.
- 562 Themen/Kandidaten erhalten.
- 549 Sandbox-Records erhalten.
- Sandbox-Semantikprojektion erhalten.
- Unabhängiger Draft/Publish/additive Beitragsart erzeugen keine globale Sandbox-Rebind-Welle.

## Fachlogik
Geschützte Journal-, Titel-, Intent-, Artikeltyp-, Context-Evaluator- und Compiler-Read-Capability-Dateien blieben im 0.52-Block byte-identisch zu 0.51.

## Live-Abschluss
- Portalabgleich: COMPLETE.
- Nächster Schritt: SEO Redaktionsplan live öffnen.
- Offener Punkt: Titelvariation in der TITLE AUTHORITY prüfen; nicht in technische Infrastruktur mischen.
