Open CODEX_TASK_PROMPT.txt and give the entire folder/ZIP to Codex.
CURRENT_V6.61.10 = live failing source.
BASELINE_V6.61.8 = visual-spacing baseline only; it still has unequal card heights.
READ_ONLY_CONTEXT = design/CSS context; never modify it.
