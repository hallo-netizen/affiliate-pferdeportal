<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Provideruebergreifendes Partner-/Einnahmen-Cockpit.
 *
 * V6.72.111: alle bekannten Provider/Quellen bleiben sichtbar; zusaetzlich werden
 * konkrete Partnerprogramme aus Originalreports einzeln darunter gefuehrt.
 * Keine Eigenaggregation, keine lokalen Ersatzwerte.
 */
final class PPAR_Partner_Analytics_Admin {
    const OPTION_REPORT_CACHE = 'ppar_partner_analytics_report_cache_v2';
    const CONTRACT_VERSION = '2.0';
    const CAMPAIGN_POST_TYPE = 'ap_campaign';
    const REFRESH_ACTION = 'ppar_partner_analytics_refresh_now';

    private static $booted = false;

    public static function bootstrap() {
        if (self::$booted) { return; }
        self::$booted = true;
        add_action('admin_menu', array(__CLASS__, 'register_menu'), 999);
        add_action('ppar_partner_analytics_ingest', array(__CLASS__, 'ingest_report'), 10, 2);
        add_action('ppar_partner_analytics_reconcile', array(__CLASS__, 'reconcile_provider'), 10, 2);
        add_action('admin_post_' . self::REFRESH_ACTION, array(__CLASS__, 'handle_refresh_now'));
    }

    public static function register_menu() {
        if (!function_exists('remove_submenu_page') || !function_exists('add_submenu_page')) { return; }
        remove_submenu_page('affiliate-portal-zentrale', 'affiliate-portal-stats');
        add_submenu_page(
            'affiliate-portal-zentrale',
            'Partner & Einnahmen',
            'Partner & Einnahmen',
            'manage_options',
            'affiliate-portal-stats',
            array(__CLASS__, 'render_page')
        );
    }

    private static function provider_defaults() {
        // Vollstaendige Quellenliste bleibt sichtbar, auch wenn ein Portal fuer
        // den gewaehlten Zeitraum keine Originalwerte liefert. Adapter duerfen
        // diese Liste erweitern; fehlende Werte bleiben strikt `nicht verfuegbar`.
        $providers = array(
            'amazon'=>array('label'=>'Amazon','type'=>'Produktquelle','state'=>'prepared','source_network'=>'amazon'),
            'otto'=>array('label'=>'OTTO','type'=>'Produktquelle','state'=>'prepared','source_network'=>'awin'),
            'kelkoo'=>array('label'=>'Kelkoo','type'=>'Produkt- & Dealquelle','state'=>'prepared','source_network'=>'kelkoo'),
            'idealo'=>array('label'=>'idealo','type'=>'Preisvergleich / Produktquelle','state'=>'active','source_network'=>'idealo'),
            'ebay'=>array('label'=>'eBay','type'=>'Produktquelle','state'=>'active','source_network'=>'ebay'),
            'awin'=>array('label'=>'Awin','type'=>'Banner-/Partnernetzwerk','state'=>'active','source_network'=>'awin'),
            'adcell'=>array('label'=>'ADCELL','type'=>'Banner-/Partnernetzwerk','state'=>'active','source_network'=>'adcell'),
            'digistore24'=>array('label'=>'Digistore24','type'=>'Banner-/Partnernetzwerk','state'=>'active','source_network'=>'digistore24'),
            'direct'=>array('label'=>'Direktpartner','type'=>'Direktpartner','state'=>'active','source_network'=>'direct'),
        );
        $filtered = apply_filters('ppar_partner_analytics_providers', $providers, self::CONTRACT_VERSION);
        return is_array($filtered) ? $filtered : $providers;
    }

    private static function normalize_range($raw) {
        $raw = sanitize_key((string)$raw);
        return in_array($raw, array('today','7','30','all'), true) ? $raw : '30';
    }

    private static function range_label($range) {
        if ($range === 'today') { return 'Heute'; }
        if ($range === '7') { return '7 Tage'; }
        if ($range === 'all') { return 'Gesamt'; }
        return '30 Tage';
    }

    private static function report_cache() {
        $cache = get_option(self::OPTION_REPORT_CACHE, array());
        return is_array($cache) ? $cache : array();
    }

    private static function cache_key($provider, $external_id, $partner_name = '') {
        $provider = sanitize_key((string)$provider);
        $external_id = trim(sanitize_text_field((string)$external_id));
        if ($external_id === '') {
            $partner_name = trim(sanitize_text_field((string)$partner_name));
            $external_id = $partner_name !== '' ? 'name-' . substr(hash('sha256', strtolower($partner_name)), 0, 20) : 'provider';
        }
        return $provider . ':' . $external_id;
    }

    public static function ingest_report($provider, $report) {
        $provider = sanitize_key((string)$provider);
        if ($provider === '' || !is_array($report)) { return false; }
        $external_id = sanitize_text_field((string)($report['partner_external_id'] ?? $report['advertiser_id'] ?? $report['program_id'] ?? ''));
        $partner_name = sanitize_text_field((string)($report['partner_name'] ?? $report['advertiser_name'] ?? $report['program_name'] ?? ''));
        if ($partner_name === '') { $partner_name = strtoupper($provider) . ($external_id !== '' ? ' ' . $external_id : ''); }
        $periods = array();
        foreach (array('today','7','30','all') as $period) {
            $row = isset($report['periods'][$period]) && is_array($report['periods'][$period]) ? $report['periods'][$period] : array();
            $periods[$period] = array(
                'clicks' => array_key_exists('clicks', $row) && is_numeric($row['clicks']) ? max(0, (int)$row['clicks']) : null,
                'orders' => array_key_exists('orders', $row) && is_numeric($row['orders']) ? max(0, (int)$row['orders']) : null,
                'sales' => array_key_exists('sales', $row) && is_numeric($row['sales']) ? max(0, (float)$row['sales']) : null,
                'commission' => array_key_exists('commission', $row) && is_numeric($row['commission']) ? (float)$row['commission'] : null,
                'conversion' => array_key_exists('conversion', $row) && is_numeric($row['conversion']) ? (float)$row['conversion'] : null,
            );
        }
        $currency = strtoupper((string)($report['currency'] ?? 'EUR'));
        if (!preg_match('/^[A-Z]{3}$/', $currency)) { $currency = 'EUR'; }
        $cache = self::report_cache();
        $key = self::cache_key($provider, $external_id, $partner_name);
        $cache[$key] = array(
            'provider' => $provider,
            'partner_external_id' => $external_id,
            'partner_name' => $partner_name,
            'role' => sanitize_text_field((string)($report['role'] ?? 'Partnerprogramm')),
            'source' => sanitize_text_field((string)($report['source'] ?? 'provider_api')),
            'currency' => $currency,
            'updated_at' => absint($report['updated_at'] ?? time()),
            'periods' => $periods,
        );
        update_option(self::OPTION_REPORT_CACHE, $cache, false);
        return true;
    }

    public static function reconcile_provider($provider, $active_external_ids) {
        $provider = sanitize_key((string)$provider);
        if ($provider === '') { return; }
        $allowed = array_fill_keys(array_map('strval', array_values(array_filter((array)$active_external_ids, static function($id){ return trim((string)$id) !== ''; }))), true);
        $cache = self::report_cache();
        $changed = false;
        foreach ($cache as $key=>$entry) {
            if (!is_array($entry) || sanitize_key((string)($entry['provider'] ?? '')) !== $provider) { continue; }
            $external_id = (string)($entry['partner_external_id'] ?? '');
            if ($external_id !== '' && !isset($allowed[$external_id])) { unset($cache[$key]); $changed = true; }
        }
        if ($changed) { update_option(self::OPTION_REPORT_CACHE, $cache, false); }
    }

    private static function rows_for_range($range) {
        $rows = array();

        // Erst jede bekannte Quelle sichtbar machen. Das ist reine Navigation/
        // Vollstaendigkeit und erzeugt keinerlei Kennzahl.
        foreach (self::provider_defaults() as $provider_key=>$definition) {
            if (!is_array($definition)) { continue; }
            $provider_key=sanitize_key((string)$provider_key);
            if ($provider_key==='') { continue; }
            $rows[] = array(
                'cache_key'=>'provider:'.$provider_key,
                'provider'=>$provider_key,
                'partner_external_id'=>'',
                'partner_name'=>sanitize_text_field((string)($definition['label']??strtoupper($provider_key))),
                'role'=>sanitize_text_field((string)($definition['type']??'Provider / Quelle')),
                'source'=>'', 'currency'=>'EUR', 'updated_at'=>0,
                'clicks'=>null,'orders'=>null,'sales'=>null,'commission'=>null,'conversion'=>null,
                'is_provider_overview'=>1,
            );
        }

        // Danach die echten partnerweisen Originalreport-Zeilen. Keine Summierung,
        // keine Ersetzung der Providerzeilen und keine lokalen Messwerte.
        foreach (self::report_cache() as $key=>$entry) {
            if (!is_array($entry)) { continue; }
            $period = isset($entry['periods'][$range]) && is_array($entry['periods'][$range]) ? $entry['periods'][$range] : array();
            $rows[] = array(
                'cache_key'=>(string)$key,
                'provider'=>sanitize_key((string)($entry['provider'] ?? '')),
                'partner_external_id'=>sanitize_text_field((string)($entry['partner_external_id'] ?? '')),
                'partner_name'=>sanitize_text_field((string)($entry['partner_name'] ?? '')),
                'role'=>sanitize_text_field((string)($entry['role'] ?? 'Partnerprogramm')),
                'source'=>(string)($entry['source'] ?? ''),
                'currency'=>(string)($entry['currency'] ?? 'EUR'),
                'updated_at'=>absint($entry['updated_at'] ?? 0),
                'clicks'=>array_key_exists('clicks',$period)?$period['clicks']:null,
                'orders'=>array_key_exists('orders',$period)?$period['orders']:null,
                'sales'=>array_key_exists('sales',$period)?$period['sales']:null,
                'commission'=>array_key_exists('commission',$period)?$period['commission']:null,
                'conversion'=>array_key_exists('conversion',$period)?$period['conversion']:null,
                'is_provider_overview'=>0,
            );
        }
        return array_values($rows);
    }

    private static function provider_label($provider) {
        $labels = array('awin'=>'Awin','adcell'=>'ADCELL','digistore24'=>'Digistore24','ebay'=>'eBay','idealo'=>'idealo','direct'=>'Direktpartner','manual'=>'Direktpartner');
        $provider = sanitize_key((string)$provider);
        return $labels[$provider] ?? strtoupper($provider);
    }

    private static function na($value, $format = 'number', $currency = 'EUR') {
        if ($value === null) { return '<span class="description">nicht verfügbar</span>'; }
        if ($format === 'percent') { return esc_html(number_format_i18n((float)$value, 2) . ' %'); }
        if ($format === 'money') {
            $currency = strtoupper((string)$currency);
            if (!preg_match('/^[A-Z]{3}$/', $currency)) { $currency = 'EUR'; }
            return esc_html(number_format_i18n((float)$value, 2) . ' ' . $currency);
        }
        return esc_html(number_format_i18n((float)$value, 0));
    }

    public static function handle_refresh_now() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        check_admin_referer('ppar_partner_analytics_refresh_now','ppar_partner_analytics_refresh_nonce');
        $ok = false; $message = '';
        if (class_exists('Pferdeportal_Affiliate_Router')) {
            $router = Pferdeportal_Affiliate_Router::instance();
            if (is_object($router) && method_exists($router,'run_partner_analytics_refresh')) {
                $result = $router->run_partner_analytics_refresh();
                $ok = is_array($result);
                $message = $ok ? 'Originaldaten der Partnerportale wurden aktualisiert.' : 'Providerdaten konnten nicht vollständig aktualisiert werden.';
            }
        }
        if ($message === '') { $message = 'Statistik-Aktualisierung ist nicht verfügbar.'; }
        wp_safe_redirect(add_query_arg(array(
            'page'=>'affiliate-portal-kiss-partners',
            'ppar_partner_refresh'=>$ok?'ok':'failed',
            'ppar_partner_refresh_message'=>rawurlencode($message),
        ), admin_url('admin.php')));
        exit;
    }

    public static function render_page() {
        if (!current_user_can('manage_options')) { wp_die('Keine Berechtigung.'); }
        $range = self::normalize_range($_GET['range'] ?? '30');
        $rows = self::rows_for_range($range);
        $base = admin_url('admin.php?page=affiliate-portal-kiss-partners');
        $notice = sanitize_key((string)($_GET['ppar_partner_refresh'] ?? ''));
        $notice_message = rawurldecode((string)($_GET['ppar_partner_refresh_message'] ?? ''));
        ?>
        <div class="wrap" style="max-width:1240px">
            <h1>Partner &amp; Einnahmen</h1>
            <p><strong>Nur Originaldaten der Partnerportale.</strong> Alle bekannten Provider/Quellen bleiben sichtbar; konkrete Partnerprogramme aus Providerreports erscheinen zusätzlich einzeln. Fehlende Originalwerte bleiben „nicht verfügbar“.</p>
            <?php if ($notice === 'ok') : ?><div class="notice notice-success inline"><p><?php echo esc_html($notice_message); ?></p></div><?php endif; ?>
            <?php if ($notice === 'failed') : ?><div class="notice notice-warning inline"><p><?php echo esc_html($notice_message); ?></p></div><?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin:12px 0 16px">
                <input type="hidden" name="action" value="<?php echo esc_attr(self::REFRESH_ACTION); ?>">
                <?php wp_nonce_field('ppar_partner_analytics_refresh_now','ppar_partner_analytics_refresh_nonce'); ?>
                <button class="button button-primary" type="submit">Originaldaten jetzt aktualisieren</button>
                <span class="description" style="margin-left:8px">Zusätzlich automatische tägliche Aktualisierung.</span>
            </form>
            <p class="subsubsub" style="float:none;margin:12px 0 18px">
                <?php foreach (array('today'=>'Heute','7'=>'7 Tage','30'=>'30 Tage','all'=>'Gesamt') as $value=>$label) : ?>
                    <a href="<?php echo esc_url(add_query_arg('range',$value,$base)); ?>" <?php echo $range===$value?'style="font-weight:700"':''; ?>><?php echo esc_html($label); ?></a><?php echo $value!=='all'?' &nbsp;|&nbsp; ':''; ?>
                <?php endforeach; ?>
            </p>
            <h2><?php echo esc_html(self::range_label($range)); ?></h2>
            <table class="widefat striped"><thead><tr><th>Partner</th><th>Portal</th><th>Provider-Klicks</th><th>Verkäufe/Leads</th><th>Umsatz</th><th>Provision</th><th>Conversion</th><th>Datenstand</th></tr></thead><tbody>
            <?php if (!$rows) : ?><tr><td colspan="8">Noch keine Original-Partnerdaten geladen. „Originaldaten jetzt aktualisieren“ ausführen.</td></tr><?php endif; ?>
            <?php foreach ($rows as $r) : ?>
                <tr>
                    <td><strong><?php echo esc_html((string)$r['partner_name']); ?></strong><?php if ($r['partner_external_id']!=='') : ?><br><span class="description">ID <?php echo esc_html((string)$r['partner_external_id']); ?></span><?php endif; ?></td>
                    <td><?php echo esc_html(self::provider_label($r['provider'])); ?><br><span class="description"><?php echo esc_html((string)$r['role']); ?></span></td>
                    <td><?php echo self::na($r['clicks']); ?></td>
                    <td><?php echo self::na($r['orders']); ?></td>
                    <td><?php echo self::na($r['sales'],'money',$r['currency']); ?></td>
                    <td><?php echo self::na($r['commission'],'money',$r['currency']); ?></td>
                    <td><?php echo self::na($r['conversion'],'percent'); ?></td>
                    <td><?php if ($r['updated_at']>0) { echo esc_html(wp_date('d.m.Y H:i',$r['updated_at'])); if ($r['source']!=='') { echo '<br><span class="description">'.esc_html($r['source']).'</span>'; } } else { echo '<span class="description">noch kein Report</span>'; } ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody></table>
            <p class="description" style="margin-top:12px">Fehlende Providerwerte bleiben „nicht verfügbar“. Unterschiedliche Partner und Währungen werden nicht von uns zusammengerechnet.</p>
        </div>
        <?php
    }
}
