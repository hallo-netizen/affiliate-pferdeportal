# START HIER – LEAN FULL RUN

1. Lies `07_CODEX_FULLRUN_LEAN.md`.
2. Lies danach `01_MASTER_BINDING/` vollständig.
3. Arbeite in EINEM Lauf bis Gesamt-PASS oder objektivem BLOCKED.
4. Den riesigen Original-Liveexport NICHT vollständig in den Kontext laden. Nutze die kompakten echten Liveextrakte und gezielte Scripts.
5. `06_CODEX_PHASE1_ROOTCAUSE_ONLY.md` ist nur Reserve und bei diesem Lauf NICHT zu verwenden.
