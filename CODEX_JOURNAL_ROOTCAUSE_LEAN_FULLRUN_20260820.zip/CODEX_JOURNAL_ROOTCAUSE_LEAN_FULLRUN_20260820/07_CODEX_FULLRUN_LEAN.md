# CODEX – KOMPLETTER REPARATURLAUF, KONTEXTKLEIN, MASTER VERBINDLICH

## Zwingende Arbeitsweise
Arbeite den **gesamten Reparaturauftrag in einem einzigen Lauf bis PASS oder objektivem BLOCKED** ab. Keine Zwischenantwort. Keine Mini-Fixes. Keine neue Architektur.

Der bisherige Codex-Lauf ist wegen Kontext-/Dateigröße abgebrochen. Deshalb gilt zusätzlich:
- Den 37-MB-Liveexport **niemals vollständig catten/öffnen/ausgeben**.
- Nutze ausschließlich die deterministisch extrahierten Live-Daten unter `04_LIVE_EVIDENCE_COMPACT/`.
- Falls der Originalexport im Repo zur Verifikation nötig ist, benutze `05_TOOLS/verify_compact_evidence.py <pfad-zum-original-json>` oder eigene kleine Python/jq-Abfragen und gib nur Aggregat-/Trefferzeilen aus.
- Keine rekursiven Source-Dumps.
- Große Testsuiten ausführen, aber nur Exitcode + Summen + relevante FAIL-Zeilen in den Kontext holen.
- Dateien gezielt per `rg/grep` finden und nur notwendige Bereiche mit `sed` lesen.

## Oberste Autorität
Lies `01_MASTER_BINDING/` vollständig. Diese Regeln sind verbindlich. Insbesondere:
- Textmaschine / bestehende Ergebnisse unantastbar.
- Core-Beitragsarten eingefroren.
- neue Beitragsart nur additiv.
- kein Family-/Type-/Category-Miss als Extension-Beweis.
- keine Selbstbestätigung.
- Workflow unverändert.
- kein Build vor vollständigem PASS.
- Source + Fresh-Unpack + voller Workflow + Realbestand.

## Echter Livebefund
`04_LIVE_EVIDENCE_COMPACT/00_live_summary.json` ist aus dem echten 562er Export extrahiert und durch SHA an das Original gebunden.
Es muss gelten:
- 562 Kandidaten gesamt.
- 67 PASS + planning YES.
- davon 55 Journal, 11 Beratung, 1 Pflege.
- alle 55 Journal tragen noch `PSTE_JOURNAL_ROUTER_V1`.
- alle 55 Journal tragen `FALLBACK_ONLY_AFTER_EXISTING_PRODUCT_FAMILY_MISS`.
- alle 55 besitzen keinen aktuellen `article_type_extension_routing`-Vertrag.
- darunter 2 Goldfälle, 53 unerlaubte alte Journal-PASS.

Der beigefügte PSERC-Live-Snapshot zeigt:
- 0 READY,
- 55 `BLOCKED_CATEGORY_ARTICLE_TYPE_MISMATCH`,
- 12 `HELD_NO_ACTIVE_NORMAL_DRAFT_RELEASE`.

## Auftrag
### 1. Root Cause beweisen
Verfolge konkret:
- Laden/rehydrieren bestehender Topic-Pool-/Candidate-Payloads,
- Merge-/Persistenzpfad,
- aktuelle Editorializer-/Normal-Metadata-Revalidation,
- `automaticPoolStatus()` / `verifiedExtensionAutomaticRelease()`,
- Export/Compiler-Read nach PSERC,
- PSERC Category/Extension Gate.

Beweise exakt, **welches persistierte/abgeleitete Feld** die 55 alten Journal-Zustände trotz neuem Source weiterhin planungsrelevant macht und warum es beim Update nicht fail-closed invalidiert/revalidiert wurde.

### 2. Falschen lokalen 2/560-PASS erklären und Testlücke schließen
Beweise, warum der lokale Realbestandstest `2 Journal-Gold / 560 nicht Journal` PASS melden konnte, während der echte persistierte Liveexport 55 Journal-PASS enthält.
Der neue Regressionstest muss den **rehydrierten/persistierten/exportierten** Pfad prüfen, nicht nur frisch erzeugte Kandidaten/Fixtures.

### 3. Minimalen ursachenbezogenen Patch umsetzen
Nur wenn Root Cause PROVEN.
Ziel:
- zwei autorisierte Goldfälle werden deterministisch über den aktuellen generischen Extension-Vertrag revalidiert und Journal-PASS,
- 53 alte Journal-PASS fallen fail-closed aus Journal heraus,
- keine willkürliche Core-Neuzuordnung,
- keine globale Bestandslöschung,
- kein globaler Rebuild als Reparaturstrategie,
- keine Journal-Sonderfreigabe in PSERC,
- kein blindes Umetikettieren alter Routerbeweise,
- keine Änderung Core/Textmaschine/Titel/Prompt/Design/Publish.

Falls eine Migration erforderlich ist: nur extension-abhängige Felder/Records, deterministisch, bounded, fail-closed.

### 4. 12 Core-Holds separat behandeln
11 Beratung + 1 Pflege nicht mit Journal vermischen.
Wenn sie bereits durch unveränderte Releaseverträge gehalten werden: dokumentieren, nicht ändern.
Wenn Journal sie verändert hat: Regression beweisen und nur die Journal-Nebenwirkung beseitigen.

### 5. Pflichtprüfung
Mindestens:
- echter 562er Persistenz-/Export-Regressionsinput,
- 2 Gold Journal PASS,
- 53 alte Journal-PASS -> kein Journal-PASS,
- 560 Nicht-Gold durch Journal unverändert/nicht automatisch Journal,
- Core vor/nach Patch identisch gemäß Master,
- alter `PSTE_JOURNAL_ROUTER_V1` niemals neuer READY-Beweis,
- `FALLBACK_ONLY_AFTER_EXISTING_PRODUCT_FAMILY_MISS` fail-closed,
- +1 Extension Isolation,
- bestehende PSTE/PSERC Regressionen,
- PPM vollständige aktive Suite,
- keine neuen verbotenen Write-Callsites,
- Source PASS,
- Installer nur bei Gesamt-PASS,
- Fresh-Unpack: Hashparität + relevante komplette Regressionen erneut.

## Source-Nutzung
Für Root Cause zuerst die kleinen relevanten Source-Auszüge in diesem Paket verwenden.
Wenn der Patch weitere Originaldateien oder Tests braucht, nutze den bereits im Repo vorhandenen vollständigen aktuellen Source/Originalauftrag, aber **öffne nur konkrete Dateien**. Archive dürfen lokal entpackt werden; nicht komplett in den Modellkontext dumpen.

## Ergebnis
Erst am Ende antworten.

Bei PASS:
1. Root-Cause-Report.
2. exakte geänderte Produktionsdateien.
3. Testmatrix mit Summen.
4. Source-/Fresh-Unpack-/Hash-/Signaturstatus.
5. welche Plugins tatsächlich installiert werden müssen.
6. fertige Installationsdateien nur bei vollständigem PASS.

Bei nicht beweisbarer Ursache oder fehlender zwingender Information:
`BLOCKED` + exakt fehlender Beweis/Datei. Kein Patch.
