# CODEX PHASE 1 – NUR ROOT-CAUSE, KONTEXTKLEIN

## Ziel
Beweise exakt, warum der aktuell installierte Source PSTE 0.55.0 einen Livebestand exportiert, in dem **55 Journal-PASS-Kandidaten** noch `PSTE_JOURNAL_ROUTER_V1` + `FALLBACK_ONLY_AFTER_EXISTING_PRODUCT_FAMILY_MISS` tragen, obwohl der aktuelle Extension-Vertrag genau das nicht als gültigen neuen Beweis akzeptiert.

**Noch nichts reparieren.** Kein Patch, kein Build, kein Installer. Nur Ursache + minimal notwendiger Änderungsumfang.

## Oberste Autorität
1. `01_MASTER_BINDING/VERBINDLICHER_REPARATUR_UND_ARCHITEKTURPROMPT_20260820.md`
2. übrige Dateien unter `01_MASTER_BINDING/`
3. echter Livebefund unter `04_LIVE_EVIDENCE_COMPACT/`
4. aktueller Source unter `02_PSTE_RELEVANT_SOURCE/` und `03_PSERC_RELEVANT_SOURCE/`

Keine eigene Fachregel erfinden.

## Bereits deterministisch extrahierter Livebefund
`04_LIVE_EVIDENCE_COMPACT/00_live_summary.json` muss ergeben:
- 562 Kandidaten gesamt
- 67 PASS + planning YES
- davon 55 Journal, 11 Beratung, 1 Pflege
- alle 55 Journal: `journal_routing.contract=PSTE_JOURNAL_ROUTER_V1`
- alle 55 Journal: `semantic_consensus.selection_policy=FALLBACK_ONLY_AFTER_EXISTING_PRODUCT_FAMILY_MISS`
- alle 55 Journal: kein aktueller `article_type_extension_routing.contract`
- zwei Goldfälle sind unter den 55, 53 sind nicht autorisierte alte Journal-PASS

Der PSERC-Live-Snapshot zeigt anschließend:
- 0 READY
- 55 `BLOCKED_CATEGORY_ARTICLE_TYPE_MISMATCH`
- 12 `HELD_NO_ACTIVE_NORMAL_DRAFT_RELEASE`

## Arbeitsweise – zwingend klein
- Keine großen Dateien komplett ausgeben.
- Keine rekursiven Dumps von JSON/Source.
- Nur `grep`, `rg`, `sed` auf gezielte Funktionen/Strings.
- Wenn weitere Dateien aus dem bestehenden Repo nötig sind: nur die konkrete Datei öffnen, nicht Archive vollständig lesen.
- Keine Testausgaben mit tausenden Zeilen.

## Zu beweisende Fragen

### A. Wo entsteht der Mix aus altem persistiertem Zustand und neuem Source?
Verfolge ausschließlich diesen Weg:
1. Laden bestehender Topic-Pool-/Candidate-Payloads.
2. `mergeCandidatePayload()` / vergleichbare Merge-/Rehydration-Pfade.
3. aktuelle `PSTE_Editorializer::apply()` / Normal-Metadata-Path-Revalidation.
4. `automaticPoolStatus()` und `verifiedExtensionAutomaticRelease()`.
5. Export/Compiler-Read-Pfad, der `decision`, `planning_suitability`, `journal_routing`, `semantic_consensus` und Extension-Beweise an PSERC weitergibt.

Beweise für jeden Schritt:
- welche alten Felder erhalten bleiben,
- welche Felder neu berechnet werden,
- welche Felder **nicht** invalidiert/überschrieben werden,
- welches Feld letztlich die 55 Kandidaten weiterhin als planungsgeeignet exportieren lässt.

### B. Warum schließt der aktuelle Source die 55 nicht fail-closed aus?
Besonders prüfen:
- `class-pste-repository.php`
- `class-pste-editorializer.php`
- `class-pste-normal-metadata-path.php`
- `class-pste-article-type-extension-router.php`
- `class-pste-article-type-extension-registry.php`
- `class-pste-snapshot.php`
- `class-pste-compiler-read-capability.php`
- Sandbox-/Record-Store nur soweit tatsächlich am aktiven Export beteiligt.

Nicht aus dem Vorhandensein eines alten Feldes allein auf Persistenzursache schließen. Den **konkreten aktiven Codepfad** beweisen.

### C. Warum meldete der lokale 562er-Test fälschlich 2/560 PASS?
Lies den QA-Nachweis im Master und finde im Source/Testbestand den Test, der diese Aussage erzeugt hat. Beweise:
- welchen Datenstand er geprüft hat,
- ob er frisch berechnete Kandidaten statt rehydrierte/persistierte Live-Records geprüft hat,
- welche Persistenz-/Merge-/Exportstufe dadurch fehlte.

### D. 12 Core-Holds strikt getrennt
Nur feststellen, ob die 11 Beratung + 1 Pflege **Journal-regressionsbedingt** sind oder bereits durch unveränderte Release-Unterstützung gehalten werden.
Keine Core-Regeln ändern und nicht in die Journal-Reparatur ziehen, wenn sie unabhängig sind.

## Erwartete Ausgabe – maximal 150 Zeilen
1. **ROOT CAUSE: PROVEN / NOT PROVEN**
2. Exakte Fehlerkette in höchstens 10 Schritten.
3. Je Schritt: Datei + Funktion/Methode + relevante Bedingung.
4. Warum 55 Journal-PASS live erhalten bleiben.
5. Warum PSERC sie korrekt blockiert oder nicht korrekt blockiert.
6. Warum der lokale 2/560-Test die Lücke nicht gesehen hat.
7. Minimaler notwendiger Änderungsumfang: konkrete Dateien, **noch kein Patch**.
8. Tests, die Phase 2 zwingend braucht.
9. Falls etwas nicht beweisbar ist: `BLOCKED` + exakt fehlende Datei/Information.

## Verboten
- Kein neuer Architekturvorschlag.
- Kein Rollback.
- Kein Journal-Sonderallow in PSERC.
- Kein Umbenennen alter Routerdaten in neue Extensiondaten.
- Kein globaler Rebuild als Lösung.
- Keine Textmaschinen-/Titel-/Prompt-/Designänderung.
- Keine Installationsdatei.

Ziel dieser Phase ist **nur ein belastbarer, kleiner Root-Cause-Beweis**, damit Phase 2 anschließend gezielt und kurz repariert werden kann.
