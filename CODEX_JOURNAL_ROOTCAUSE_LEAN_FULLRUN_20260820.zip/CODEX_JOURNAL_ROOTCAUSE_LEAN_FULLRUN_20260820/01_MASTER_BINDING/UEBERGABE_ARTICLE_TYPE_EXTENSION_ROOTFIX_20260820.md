# ÜBERGABE – ADDITIVE SIGNIERTE BEITRAGSART-ARCHITEKTUR / JOURNAL ROOTFIX

## Installieren

Es sind **drei** Plugin-Dateien zu installieren:

1. `portal-seo-topic-engine_0.55.0_SIGNED_ADDITIVE_ARTICLE_TYPE_ROOTFIX_FINAL.zip`
2. `portal-seo-editorial-plan-compiler_0.27.0_SIGNED_ADDITIVE_ARTICLE_TYPE_ROOTFIX_FINAL.zip`
3. `PORTAL_PRODUCTION_MACHINE_V6.7.9_SIGNED_ARTICLE_TYPE_EXTENSION_ROOTFIX_FINAL.zip`

Alle drei gehören zusammen. Kein Mischbetrieb mit PSTE 0.54.0 / PSERC 0.26.0 / altem PPM-Build.

## Was geändert wurde

### Architektur

- eine zentrale signierte `ARTICLE_TYPE_EXTENSION_MANIFEST_V1` wird von PSTE, PSERC und PPM konsumiert;
- neue Beitragsarten sind additive Extensions statt Core-Hartverdrahtung;
- Extension-Zulassung braucht positiven unabhängigen Scope+Intent-Beweis;
- ein Core-Miss ist niemals Extension-Beweis;
- selbst erzeugte Router-Evidenz darf sich nicht selbst freigeben;
- Release bleibt fail-closed.

### Journal

- kein Journal-Fallback aus Family-Miss;
- keine automatische Rohsuchphrase -> Journal-Produktionstitel;
- bestehende Titelregeln gelten auf gebundene Journal-Titel;
- zusätzliche Journal-only harte Keywordketten-Sperre;
- Extension-only Phrasenwiederholungs-Veto;
- die beiden bestehenden Goldpiloten bleiben die autorisierten ersten Journalfälle.

### Technik

- bounded/resumable Architektur aus PSTE 0.54 / PSERC 0.26 bleibt erhalten;
- Extension-Fingerprint ist von Legacy-/Family-Fingerprint getrennt;
- PPM mit unverändertem Trust Root neu signiert.

## Was NICHT geändert wurde

- kein Artikeltext,
- kein Golden-Master-HTML,
- keine bestehende Promptlogik,
- keine bestehende FAQ-/Beratung-/Vergleich-/Pflege-Titelentscheidung,
- keine bestehende Kategorieentscheidung dieser Core-Typen,
- kein Design,
- keine Publish-Eskalation,
- kein manueller Workflow-Bypass.

## Lokaler Prüfstatus

- Source PASS,
- Fresh-Unpack PASS,
- PPM 136/136 PASS auf Source und Fresh-Unpack,
- 562er Realbestandstest PASS,
- +1 Extension-Isolationstest PASS,
- Manifest-/Signaturprüfung PASS,
- Nicht-Journal-Titelregression byteidentisch,
- keine neuen verbotenen WordPress-Write-Callsites.

## Nach Installation

Noch **kein LIVE E2E PASS** behauptet.

Der nächste Live-Schritt ist ausschließlich der normale bestehende Workflow. Keine manuelle Beitragsanlegung und kein Produktionsweg am Redaktionsplan vorbei. Erstes Live-Ziel sind die zwei gebundenen Journal-Goldpiloten:

- `Wie alt werden Pferde?`
- `Können Pferde schwimmen?`

Erst nach `Exact Five -> Supervisor -> PPM -> WordPress Draft -> Readback` ist der Live-Pfad PASS.
