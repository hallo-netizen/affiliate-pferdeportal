#!/usr/bin/env python3
"""Optional: run against the original full live JSON in the repo without printing it."""
import json, sys, collections
p=sys.argv[1]
with open(p,'r',encoding='utf-8') as f:d=json.load(f)
c=d['candidates']
ready=[x for x in c if x.get('decision')=='PASS' and x.get('planning_suitability')=='YES']
j=[x for x in ready if x.get('proposed_article_type')=='Journal']
print('total',len(c))
print('pass_planning_yes',len(ready))
print('types',dict(collections.Counter(x.get('proposed_article_type') for x in ready)))
print('journal_router_contracts',dict(collections.Counter((x.get('journal_routing') or {}).get('contract') for x in j)))
print('journal_selection_policies',dict(collections.Counter((x.get('semantic_consensus') or {}).get('selection_policy') for x in j)))
print('journal_extension_route_contracts',dict(collections.Counter(str((x.get('article_type_extension_routing') or {}).get('contract')) for x in j)))
print('gold',[x.get('canonical_query') for x in j if x.get('canonical_query') in {'Wie alt werden pferde?','Können pferde schwimmen?'}])
