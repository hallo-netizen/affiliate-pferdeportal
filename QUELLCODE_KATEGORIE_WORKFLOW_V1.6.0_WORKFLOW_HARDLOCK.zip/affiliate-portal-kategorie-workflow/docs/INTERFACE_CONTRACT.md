# Schnittstellenvertrag V1.6.0 – HARDLOCK

Kategorie- und Research-Schema bleiben technisch 1.4-kompatibel; V1.6.0 ergänzt zusätzliche Review-Felder und verschärft deren Gate-Bedeutung.

## RESEARCH_DRAFT vor Global-Coverage
Zusätzlich zwingend:
`initial_human_sight_review` mit
- `status=APPROVED_INITIAL_TREE`
- `review_scope_sha256`
- `approved_at_utc`
- `review_summary`

Der Hash bindet Projekt, Research-Cluster, Nodes und Default-Targets. Jede Änderung => neuer sichtbarer Erst-Review.

## Korrigierter RESEARCH_DRAFT vor Detailresearch
Zusätzlich zwingend:
`global_coverage_binding` mit Package-ID + Hash des Global-Pakets und
`global_gap_human_review` mit
- `status=APPROVED_GLOBAL_GAP_CORRECTION`
- `review_scope_sha256`
- `approved_at_utc`
- `review_summary`

Der Hash bindet Projekt, Cluster, Nodes, Global-Entscheidungen, Default-Targets und Global-Paket-Bindung.

## READ_ONLY_PREVIEW
Benötigt gültige Research-Bindung. Alle DataForSEO-/Struktur-/Longtail-Gates müssen PASS sein. `DEFERRED` ist nicht finalisierbar.

## FINAL_APPROVED
Zusätzlich `human_sight_review` mit `APPROVED_AFTER_VISIBLE_REVIEW` und passendem finalen Review-Scope-Hash. Jede inhaltliche Änderung danach => BLOCK.

## Sicherheit
Keine WordPress-/HivePress-Content-Writes. Finalprüfung ohne externe Requests.
