# Known limitations V1.6.0

- Keine technische Recherche kann mathematisch beweisen, dass in einem offenen Themenraum absolut nichts fehlt. Der Workflow reduziert dieses Risiko deshalb zwingend über drei getrennte Instanzen: Chat/Master-Konzeptaudit, DataForSEO-Coverage/Detail-Evidenz und sichtbare Nutzerprüfung.
- DataForSEO liefert Keyword-/SERP-Evidenz, aber keine autonome fachliche Architekturentscheidung.
- Semantische Ausnahmen können begründet werden, führen aber erst nach sichtbarer Finalfreigabe zu FINAL.
- `DEFERRED` ist absichtlich kein schließender Status.
- V1.6.0 bleibt bis zu einem echten WordPress-/DataForSEO-Lauf TESTKANDIDAT; lokale Tests sind kein Live-PASS.
