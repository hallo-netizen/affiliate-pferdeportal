# Changelog

## 1.6.0
- Workflow-Hardlock: drei sichtbare, hashgebundene Nutzerfreigaben.
- Erst-Sichtprüfung zwingend vor Global-Coverage.
- Global-Gap-Sichtprüfung zwingend vor Detailresearch.
- `DEFERRED` blockiert Detailresearch und READY/FINAL.
- Admin-Workflow an die verbindliche Reihenfolge angepasst.
- 100 automatisierte Positiv-/Negativtests.
- Keine Portal-Content-Writes.

## 1.5.0
- Contentkategorie-Rootfix: tragfähige Beitragsrichtungen können echte Content-Kategorien sein.
