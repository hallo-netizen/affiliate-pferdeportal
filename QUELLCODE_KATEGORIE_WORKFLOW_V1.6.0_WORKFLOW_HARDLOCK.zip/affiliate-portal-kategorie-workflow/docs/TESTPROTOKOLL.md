# Testprotokoll V1.6.0

Automatisierte Suite: 100 Positiv-/Negativtests.

Zusätzliche HARDLOCK-Fälle gegenüber V1.5.0:
- Paid Global ohne Erst-Sichtreview => BLOCK + 0 Requests.
- Strukturänderung nach Erst-Sichtreview => Hash BLOCK.
- Detailresearch ohne Global-Gap-Sichtreview => BLOCK + 0 Requests.
- Strukturänderung nach Global-Gap-Sichtreview => Hash BLOCK.
- Global `DEFERRED` => Detail BLOCK.
- Cluster `DEFERRED` => READY/FINAL BLOCK.
- historischer Paid-Global-Lauf ohne Erst-Sichtreview => kein neuer Workflow-PASS.

Weiterhin geprüft: 3/2-Longtail-Grenze, FAQ-Endkategorie, Tiefenseeds, Namensdubletten, Ownership, Scope-Bindung, Providerfehler, Kostenkontrolle, read-only Finalpfad, verbotene Write-APIs.
