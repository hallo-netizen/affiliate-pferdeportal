# Workflow V1.6.0 – HARDLOCK

Kein Schritt darf übersprungen, zusammengelegt oder in anderer Reihenfolge ausgeführt werden.

1. **MASTER LOCK** – ausschließlich `ALLGEMEINGUELTIGER_KATEGORIE_MASTER_016_WORKFLOW_HARDLOCK.zip` ist aktive Regelquelle.
2. **PROJECT CONTRACT** – Projektkonzept, Scope, Ausschlüsse und Discovery-Seeds vollständig festlegen.
3. **INITIAL TREE** – Chat/Master erstellt vollständigen Content + Marketplace/HivePress + Journal Erstentwurf; Content bis zur letzten fachlich plausiblen Kandidatenebene.
4. **INITIAL VISIBLE REVIEW** – kompletter Erstbaum wird im Chat sichtbar geprüft. Erst nach ausdrücklicher Freigabe wird `initial_human_sight_review` mit Hash des exakt gesehenen Scopes gesetzt.
5. **FREE PREFLIGHT** – 0 externe Requests. Ohne gültige Erst-Sichtfreigabe = BLOCKED.
6. **GLOBAL COVERAGE** – genau 1 ausdrücklich bestätigter Paid Keyword-Ideas-Call. Keine andere Paid-Abfrage in dieser Stufe.
7. **GLOBAL GAP CORRECTION** – jeder ausgewählte Global-Core wird entweder durch den korrigierten Baum abgedeckt oder als MAIN_TOPIC/SUBTOPIC/ARTICLE_ONLY/OUT_OF_SCOPE entschieden. `DEFERRED` bleibt BLOCKED.
8. **GLOBAL GAP VISIBLE REVIEW** – korrigierter Baum + alle Global-Entscheidungen werden sichtbar geprüft und hashgebunden als `global_gap_human_review` freigegeben.
9. **DETAIL PREFLIGHT** – 0 externe Requests. Ohne gültige Global-Gap-Sichtfreigabe = BLOCKED.
10. **DETAIL RESEARCH** – exakt 1 Keyword-Ideas-Call je deklariertem Cluster plus erforderliche Keyword-Overview-Batches. Global-Coverage wird wiederverwendet; 0 neue Global-Calls.
11. **DATA-INFORMED CORRECTION** – Chat/Master korrigiert Namen, Hierarchie, fehlende Gruppen, Intents, Longtails und Overlaps. Kein autonomer DataForSEO-Umbau.
12. **READ-ONLY TOTAL AUDIT** – Schema + Research-Bindung + DataForSEO-Evidenz + Longtails + Ownership + Live-Bestandsvorschau. 0 externe Requests, 0 Content-Writes. `DEFERRED` kann READY/FINAL nicht schließen.
13. **FINAL VISIBLE REVIEW** – vollständiger korrigierter Drei-Säulen-Baum sichtbar im Chat. Erst nach ausdrücklicher Freigabe wird `human_sight_review` auf den exakten Review-Scope gesetzt.
14. **FINAL VALIDATION** – jede Scopeänderung invalidiert die Freigabe. Nur unverändert + alle Gates PASS => `PASS_FINAL_APPROVED`.

## Content-Hardrule
Eine Content-Kategorie ist nur tragfähig, wenn mindestens 3 wichtige, eigenständige, node-gebundene DataForSEO-Longtails belegt sind. FAQ, Tipps, Beratung, Vergleich, Ausrüstung/Werkzeug usw. können selbst Kategorien sein, wenn sie dieselbe Mindestsubstanz erfüllen.

## Keine Selbstfreigabe
Chat/Master können Entwürfe, Empfehlungen und Begründungen erzeugen, aber keinen sichtbaren Review-Hash freigeben. Jeder strukturelle Freigabepunkt benötigt die ausdrückliche sichtbare Nutzerfreigabe des exakt dargestellten Scopes.
